// The module `Syntax.Sexp`, from `target/bootstrap/cpp-src/prismc/syntax/sexp.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (claude/backend.md). Edit the Prism source, not this file.
#include <syntax/sexp/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/sexp/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>

namespace crate::syntax::sexp {

/// Nl: fn Nat -> Text
Text nl(const Nat& d) {
    return prism_rtl::cat("\n", indent(d));
}


/// Indent: fn Nat -> Text
Text indent(const Nat& d) {
    auto&& _m = d.checked_sub(Nat(1u));
    if (prism_rtl::is_some(_m)) {
        auto&& m = prism_rtl::some_of(_m);
        return prism_rtl::cat("  ", indent(m));
    }
    if (prism_rtl::is_none(_m)) {
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}


/// Path: fn [Text] -> Text
Text path_(const Array<Text>& p_) {
    return crate::syntax::lexer::chars::join(p_, Text::lit("."));
}


/// SNameText: fn SName -> Text
Text sname_text(const crate::syntax::SName& n) {
    return prism_rtl::cat(n.sigils, crate::syntax::sexp::path_(n->path_));
}


/// SexpModule: fn Module -> Text
Text sexp_module(const crate::syntax::Module& m) {
    auto name_1 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = m.name;
        if (prism_rtl::is_some(_m)) {
            auto&& n = prism_rtl::some_of(_m);
            _v.set(prism_rtl::cat(nl(Nat(1u)), "(name ", crate::syntax::sexp::path_(n->path_), ")"));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto emits = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = m.emit_row;
        if (prism_rtl::is_some(_m)) {
            auto&& r = prism_rtl::some_of(_m);
            _v.set(prism_rtl::cat(nl(Nat(1u)), "(emit ", sexp_row(r), ")"));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto mods = concat(each(m.mods, [&](const crate::syntax::ModLine& l) { return prism_rtl::cat(nl(Nat(1u)), "(", l.is_test ? Text::lit("test-mod") : Text::lit("mod"), " ", l.name.name, ")"); }));
    auto uses = concat(each(m.uses, [&](const crate::syntax::Use& u) { return prism_rtl::cat(nl(Nat(1u)), "(use ", crate::syntax::sexp::path_(u->target->path_), u.star ? Text::lit(".*") : Text::lit(""), ")"); }));
    auto template_ = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = m.template_;
        if (prism_rtl::is_some(_m)) {
            auto&& t = prism_rtl::some_of(_m);
            _v.set(prism_rtl::cat(nl(Nat(1u)), sexp_template(t, Nat(1u))));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto decls_2 = concat(each(m.decls, [&](const crate::syntax::decls::Decl& d) { return prism_rtl::cat(nl(Nat(1u)), sexp_decl(d, Nat(1u))); }));
    return prism_rtl::cat("(module", name_1, emits, mods, uses, template_, decls_2, ")\n");
}


/// SexpRow: fn Row -> Text
Text sexp_row(const crate::syntax::Row_& r) {
    return prism_rtl::cat("(row", spaced(r.terms, ({
        auto f = prism_rtl::rc(sexp_row_term);
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::syntax::RowTerm)>>(prism_rtl::rc([=](crate::syntax::RowTerm a0) {
        return ({
            auto f_1 = f;
            once_job([=]() { return prism_rtl::finished(f_1(a0)); });
        });
    })));
    })), ")");
}


/// SexpRowTerm: fn RowTerm -> Text
Text sexp_row_term(const crate::syntax::RowTerm& row_term0) {
    if (prism_rtl::is<crate::syntax::RowTerm::RFamily>(row_term0)) {
        auto&& q = prism_rtl::as<crate::syntax::RowTerm::RFamily>(row_term0).a0;
        return prism_rtl::cat(crate::syntax::sexp::path_(q->path_), ".*");
    }
    if (prism_rtl::is<crate::syntax::RowTerm::RVar>(row_term0)) {
        auto&& v_ = prism_rtl::as<crate::syntax::RowTerm::RVar>(row_term0).a0;
        return prism_rtl::cat("(var ", v_.name, ")");
    }
    if (prism_rtl::is<crate::syntax::RowTerm::RType>(row_term0)) {
        auto&& t = prism_rtl::as<crate::syntax::RowTerm::RType>(row_term0).a0;
        return sexp_type(t);
    }
    prism_rtl::unreachable("no arm matched");
}


/// SexpDecl: fn Decl, Nat -> Text
Text sexp_decl(const crate::syntax::decls::Decl& d, const Nat& depth) {
    auto&& _m = d.kind;
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DSignature>(_m)) {
        auto&& s = prism_rtl::as<crate::syntax::decls::DeclKind::DSignature>(_m).a0;
        return sexp_signature(s);
    }
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DFn>(_m)) {
        auto&& f = prism_rtl::as<crate::syntax::decls::DeclKind::DFn>(_m).a0;
        return sexp_fn(f, depth);
    }
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DLet>(_m)) {
        auto&& l = prism_rtl::as<crate::syntax::decls::DeclKind::DLet>(_m).a0;
        return prism_rtl::cat("(let ", sexp_pattern(l.pattern, depth), opt_type(l.ty), " ", sexp_expr(l->value, depth), ")");
    }
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DWidget>(_m)) {
        auto&& w = prism_rtl::as<crate::syntax::decls::DeclKind::DWidget>(_m).a0;
        return prism_rtl::cat("(widget ", sname_text(w.name), sexp_block(w.body, depth), ")");
    }
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DType>(_m)) {
        auto&& t = prism_rtl::as<crate::syntax::decls::DeclKind::DType>(_m).a0;
        return prism_rtl::cat("(type ", crate::syntax::sexp::path_(t.name->path_), concat(each(t.params, [&](const crate::syntax::Ident& p_) { return prism_rtl::cat(" ", p_.name); })), sexp_type_body(t.body, depth), ")");
    }
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DTag>(_m)) {
        auto&& t = prism_rtl::as<crate::syntax::decls::DeclKind::DTag>(_m).a0;
        return prism_rtl::cat("(tag ", crate::syntax::sexp::path_(t.name->path_), " ", sexp_type(t.of_type), sexp_bounds(t.bounds), sexp_fields(t.fields, depth), ")");
    }
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DDerive>(_m)) {
        auto&& ts = prism_rtl::as<crate::syntax::decls::DeclKind::DDerive>(_m).a0;
        return prism_rtl::cat("(derive", concat(each(ts, [&](const crate::syntax::TraitRef& t) { return prism_rtl::cat(" ^", crate::syntax::sexp::path_(t->path_)); })), ")");
    }
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DTrait>(_m)) {
        auto&& t = prism_rtl::as<crate::syntax::decls::DeclKind::DTrait>(_m).a0;
        return prism_rtl::cat("(trait ^", crate::syntax::sexp::path_(t.name->path_), concat(each(t.params, [&](const crate::syntax::Ident& p_) { return prism_rtl::cat(" ", p_.name); })), sexp_bounds(t.bounds), sexp_items(t.items, depth), ")");
    }
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DImpl>(_m)) {
        auto&& i = prism_rtl::as<crate::syntax::decls::DeclKind::DImpl>(_m).a0;
        return prism_rtl::cat("(impl ^", crate::syntax::sexp::path_(i.trait_ref->path_), " ", sexp_type(i.ty), sexp_bounds(i.bounds), sexp_items(i.items, depth), ")");
    }
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DCheck>(_m)) {
        auto&& c = prism_rtl::as<crate::syntax::decls::DeclKind::DCheck>(_m).a0;
        return prism_rtl::cat("(check ", c.name.name, concat(each(c.lines, [&](const crate::syntax::decls::CheckLine& l) { return prism_rtl::cat(nl(depth + Nat(1u)), "(line ", sexp_expr(l.expr, depth + Nat(1u)), check_pattern(l.pattern, depth + Nat(1u)), ")"); })), ")");
    }
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DTest>(_m)) {
        auto&& t = prism_rtl::as<crate::syntax::decls::DeclKind::DTest>(_m).a0;
        return sexp_test(t, depth);
    }
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DStmt>(_m)) {
        auto&& s = prism_rtl::as<crate::syntax::decls::DeclKind::DStmt>(_m).a0;
        return sexp_stmt(s, depth);
    }
    prism_rtl::unreachable("no arm matched");
}


/// OptType: fn ?Type -> Text
Text opt_type(const std::optional<crate::syntax::Type>& opt0) {
    if (prism_rtl::is_none(opt0)) {
        return Text::lit("");
    }
    if (prism_rtl::is_some(opt0)) {
        auto&& t = prism_rtl::some_of(opt0);
        return prism_rtl::cat(" ", sexp_type(t));
    }
    prism_rtl::unreachable("no arm matched");
}


/// CheckPattern: fn ?Pattern, Nat -> Text
Text check_pattern(const std::optional<crate::syntax::Pattern_>& opt0, const Nat& n1) {
    auto&& _m = std::tuple{opt0, n1};
    if (prism_rtl::is_none(std::get<0>(_m))) {
        return Text::lit("");
    }
    if (prism_rtl::is_some(std::get<0>(_m))) {
        auto&& p_ = prism_rtl::some_of(std::get<0>(_m));
        auto&& d = std::get<1>(_m);
        return prism_rtl::cat(" => ", sexp_pattern(p_, d));
    }
    prism_rtl::unreachable("no arm matched");
}


/// SexpTypeBody: fn ?TypeBody, Nat -> Text
Text sexp_type_body(const std::optional<crate::syntax::decls::TypeBody>& opt0, const Nat& n1) {
    auto&& _m = std::tuple{opt0, n1};
    if (prism_rtl::is_none(std::get<0>(_m))) {
        return Text::lit(" opaque");
    }
    if (prism_rtl::is_some(std::get<0>(_m))) {
        auto&& b = prism_rtl::some_of(std::get<0>(_m));
        auto&& depth = std::get<1>(_m);
        if (prism_rtl::is<crate::syntax::decls::TypeBody::TbRecord>(b)) {
            auto&& fs = prism_rtl::as<crate::syntax::decls::TypeBody::TbRecord>(b).a0;
            return prism_rtl::cat(" record", sexp_fields(fs, depth));
        }
        if (prism_rtl::is<crate::syntax::decls::TypeBody::TbChoice>(b)) {
            auto&& cs = prism_rtl::as<crate::syntax::decls::TypeBody::TbChoice>(b).a0;
            return prism_rtl::cat(" choice", concat(each(cs, [&](const crate::syntax::decls::Case_& c) { return prism_rtl::cat(nl(depth + Nat(1u)), sexp_case(c)); })));
        }
        if (prism_rtl::is<crate::syntax::decls::TypeBody::TbRow>(b)) {
            return Text::lit(" row");
        }
        if (prism_rtl::is<crate::syntax::decls::TypeBody::TbNewtype>(b)) {
            auto&& c = prism_rtl::as<crate::syntax::decls::TypeBody::TbNewtype>(b).a0;
            return prism_rtl::cat(" newtype ", sexp_case(c));
        }
        if (prism_rtl::is<crate::syntax::decls::TypeBody::TbUnit>(b)) {
            auto&& i = prism_rtl::as<crate::syntax::decls::TypeBody::TbUnit>(b).a0;
            return prism_rtl::cat(" unit ", i.name);
        }
        if (prism_rtl::is<crate::syntax::decls::TypeBody::TbAlias>(b)) {
            auto&& t = prism_rtl::as<crate::syntax::decls::TypeBody::TbAlias>(b).a0;
            return prism_rtl::cat(" alias ", sexp_type(t));
        }
        prism_rtl::unreachable("no arm matched");
    }
    prism_rtl::unreachable("no arm matched");
}


/// SexpSignature: fn Signature -> Text
Text sexp_signature(const crate::syntax::decls::Signature& s) {
    return prism_rtl::cat("(sig ", sexp_def_name(s.name), " ", sexp_type(s.ty), sexp_bounds(s.bounds), ")");
}


/// SexpDefName: fn DefName -> Text
Text sexp_def_name(const crate::syntax::decls::DefName& def_name0) {
    if (prism_rtl::is<crate::syntax::decls::DefName::DefSName>(def_name0)) {
        auto&& n = prism_rtl::as<crate::syntax::decls::DefName::DefSName>(def_name0).a0;
        return sname_text(n);
    }
    if (prism_rtl::is<crate::syntax::decls::DefName::DefOp>(def_name0)) {
        auto&& o = prism_rtl::as<crate::syntax::decls::DefName::DefOp>(def_name0).a0;
        return prism_rtl::cat("(op ", o, ")");
    }
    prism_rtl::unreachable("no arm matched");
}


/// SexpBounds: fn [Bound] -> Text
Text sexp_bounds(const Array<crate::syntax::decls::Bound>& bs) {
    return concat(each(bs, [&](const crate::syntax::decls::Bound& b) { return prism_rtl::cat(" (where ", b.var.name, concat(each(b.traits, [&](const crate::syntax::TraitRef& t) { return prism_rtl::cat(" ^", crate::syntax::sexp::path_(t->path_)); })), ")"); }));
}


/// SexpFn: fn FnClause, Nat -> Text
Text sexp_fn(const crate::syntax::decls::FnClause& f, const Nat& depth) {
    auto body = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = f.body;
        if (prism_rtl::is<crate::syntax::decls::FnBody::BodyExpr>(_m)) {
            auto&& e = prism_rtl::as<crate::syntax::decls::FnBody::BodyExpr>(_m).a0;
            _v.set(prism_rtl::cat(nl(depth + Nat(1u)), sexp_expr(e, depth + Nat(1u))));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::decls::FnBody::BodyBlock>(_m)) {
            auto&& b = prism_rtl::as<crate::syntax::decls::FnBody::BodyBlock>(_m).a0;
            _v.set(sexp_block(b, depth));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return prism_rtl::cat("(fn ", sexp_def_name(f.name), " (params", concat(each(f.params, [&](const crate::syntax::Pattern_& p_) { return prism_rtl::cat(" ", sexp_pattern(p_, depth)); })), ")", body, ")");
}


/// SexpFields: fn [Field], Nat -> Text
Text sexp_fields(const Array<crate::syntax::decls::Field>& fs, const Nat& depth) {
    return concat(each(fs, [&](const crate::syntax::decls::Field& f) { return prism_rtl::cat(nl(depth + Nat(1u)), "(field ", f.name.name, " ", sexp_type(f.ty), ")"); }));
}


/// SexpCase: fn Case -> Text
Text sexp_case(const crate::syntax::decls::Case_& c) {
    auto indexed = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = c.indexed;
        if (prism_rtl::is_some(_m)) {
            auto&& r = prism_rtl::some_of(_m);
            _v.set(prism_rtl::cat(" -> ", sexp_type(r)));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return prism_rtl::cat("(case ", sname_text(c.name), spaced(c->args, ({
        auto f = prism_rtl::rc(sexp_type);
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::syntax::Type)>>(prism_rtl::rc([=](crate::syntax::Type a0) {
        return ({
            auto f_1 = f;
            once_job([=]() { return prism_rtl::finished(f_1(a0)); });
        });
    })));
    })), indexed, ")");
}


/// SexpItems: fn [TraitItem], Nat -> Text
Text sexp_items(const Array<crate::syntax::decls::TraitItem>& items, const Nat& depth) {
    return concat(each(items, [&](const crate::syntax::decls::TraitItem& it) { return prism_rtl::cat(nl(depth + Nat(1u)), sexp_item(it, depth + Nat(1u))); }));
}


/// SexpItem: fn TraitItem, Nat -> Text
Text sexp_item(const crate::syntax::decls::TraitItem& trait_item0, const Nat& n1) {
    auto&& _m = std::tuple{trait_item0, n1};
    if (prism_rtl::is<crate::syntax::decls::TraitItem::TiSignature>(std::get<0>(_m))) {
        auto&& s = prism_rtl::as<crate::syntax::decls::TraitItem::TiSignature>(std::get<0>(_m)).a0;
        return sexp_signature(s);
    }
    if (prism_rtl::is<crate::syntax::decls::TraitItem::TiFn>(std::get<0>(_m))) {
        auto&& f = prism_rtl::as<crate::syntax::decls::TraitItem::TiFn>(std::get<0>(_m)).a0;
        auto&& d = std::get<1>(_m);
        return sexp_fn(f, d);
    }
    if (prism_rtl::is<crate::syntax::decls::TraitItem::TiAssocType>(std::get<0>(_m))) {
        auto&& name = prism_rtl::as<crate::syntax::decls::TraitItem::TiAssocType>(std::get<0>(_m)).a0;
        auto&& params = prism_rtl::as<crate::syntax::decls::TraitItem::TiAssocType>(std::get<0>(_m)).a1;
        auto&& value_opt = prism_rtl::as<crate::syntax::decls::TraitItem::TiAssocType>(std::get<0>(_m)).a2;
        return prism_rtl::cat("(assoc-type ", name.name, concat(each(params, [&](const crate::syntax::Ident& p_) { return prism_rtl::cat(" ", p_.name); })), opt_type(value_opt), ")");
    }
    if (prism_rtl::is<crate::syntax::decls::TraitItem::TiAssocRow>(std::get<0>(_m))) {
        auto&& name = prism_rtl::as<crate::syntax::decls::TraitItem::TiAssocRow>(std::get<0>(_m)).a0;
        return prism_rtl::cat("(assoc-row ", sname_text(name), ")");
    }
    prism_rtl::unreachable("no arm matched");
}


/// SexpTest: fn TestDecl, Nat -> Text
Text sexp_test(const crate::syntax::decls::TestDecl& t, const Nat& depth) {
    auto seed_1 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = t.seed;
        if (prism_rtl::is_some(_m)) {
            auto&& s = prism_rtl::some_of(_m);
            _v.set(prism_rtl::cat(" (seed ", s, ")"));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return prism_rtl::cat("(test ", t.name.name, " ", sexp_expr(t.blueprint, depth), seed_1, concat(each(t.steps, [&](const crate::syntax::decls::TestStep& s) { return prism_rtl::cat(nl(depth + Nat(1u)), sexp_step(s, depth + Nat(1u))); })), ")");
}


/// SexpStep: fn TestStep, Nat -> Text
Text sexp_step(const crate::syntax::decls::TestStep& s, const Nat& d) {
    auto withs = concat(each(s.withs, [&](const crate::syntax::decls::Entry& w) { return prism_rtl::cat(" (with ", sexp_expr(w.element, d), " ", sexp_expr(w->value, d), ")"); }));
    auto checks = concat(each(s.checks, [&](const crate::syntax::decls::TestCheck& c) { return prism_rtl::cat(nl(d + Nat(1u)), sexp_check(c, d + Nat(1u))); }));
    return prism_rtl::cat("(step", withs, " ", sexp_action(s.action, d), checks, ")");
}


/// SexpAction: fn StepAction, Nat -> Text
Text sexp_action(const crate::syntax::decls::StepAction& step_action0, const Nat& n1) {
    auto&& _m = std::tuple{step_action0, n1};
    if (prism_rtl::is<crate::syntax::decls::StepAction::SaBuild>(std::get<0>(_m))) {
        return Text::lit("build");
    }
    if (prism_rtl::is<crate::syntax::decls::StepAction::SaTick>(std::get<0>(_m))) {
        return Text::lit("tick");
    }
    if (prism_rtl::is<crate::syntax::decls::StepAction::SaCompute>(std::get<0>(_m)) && prism_rtl::as<crate::syntax::decls::StepAction::SaCompute>(std::get<0>(_m)).a0) {
        return Text::lit("compute-until-idle");
    }
    if (prism_rtl::is<crate::syntax::decls::StepAction::SaCompute>(std::get<0>(_m)) && !prism_rtl::as<crate::syntax::decls::StepAction::SaCompute>(std::get<0>(_m)).a0) {
        return Text::lit("compute");
    }
    if (prism_rtl::is<crate::syntax::decls::StepAction::SaWithOnly>(std::get<0>(_m))) {
        return Text::lit("with-only");
    }
    if (prism_rtl::is<crate::syntax::decls::StepAction::SaPush>(std::get<0>(_m))) {
        auto&& e = prism_rtl::as<crate::syntax::decls::StepAction::SaPush>(std::get<0>(_m)).a0;
        auto&& d = std::get<1>(_m);
        return prism_rtl::cat("(push ", sexp_expr(e.element, d), " ", sexp_expr(e->value, d), ")");
    }
    if (prism_rtl::is<crate::syntax::decls::StepAction::SaDeliver>(std::get<0>(_m))) {
        auto&& ds = prism_rtl::as<crate::syntax::decls::StepAction::SaDeliver>(std::get<0>(_m)).a0;
        auto&& d = std::get<1>(_m);
        return crate::syntax::lexer::chars::join(each(ds, [&](const crate::syntax::decls::Delivery& x) { return sexp_delivery(x, d); }), Text::lit(" "));
    }
    prism_rtl::unreachable("no arm matched");
}


/// SexpDelivery: fn Delivery, Nat -> Text
Text sexp_delivery(const crate::syntax::decls::Delivery& x, const Nat& d) {
    auto word = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = x.kind;
        if (prism_rtl::is<crate::syntax::decls::DeliveryKind::DkSend>(_m)) {
            _v.set(Text::lit("send"));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::decls::DeliveryKind::DkClick>(_m)) {
            _v.set(Text::lit("click"));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::decls::DeliveryKind::DkAnswer>(_m)) {
            _v.set(Text::lit("answer"));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto value = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = x.kind;
        if (prism_rtl::is<crate::syntax::decls::DeliveryKind::DkSend>(_m)) {
            auto&& v_ = prism_rtl::as<crate::syntax::decls::DeliveryKind::DkSend>(_m).a0;
            _v.set(prism_rtl::cat(" ", sexp_expr(v_, d)));
            goto _done;
        }
        {
            _v.set(Text::lit(""));
            goto _done;
        }
    _done:
        _v.take();
    });
    return prism_rtl::cat("(", word, " ", sexp_target(x->target, d), value, ")");
}


/// SexpTarget: fn Target, Nat -> Text
Text sexp_target(const crate::syntax::decls::Target& target0, const Nat& d) {
    if (prism_rtl::is<crate::syntax::decls::Target::TgPattern>(target0)) {
        auto&& p_ = prism_rtl::as<crate::syntax::decls::Target::TgPattern>(target0).a0;
        return sexp_pattern(p_, d);
    }
    if (prism_rtl::is<crate::syntax::decls::Target::TgPath>(target0)) {
        auto&& p_ = prism_rtl::as<crate::syntax::decls::Target::TgPath>(target0).a0;
        return sexp_path(Text::lit("at"), p_, d);
    }
    if (prism_rtl::is<crate::syntax::decls::Target::TgElement>(target0)) {
        auto&& p_ = prism_rtl::as<crate::syntax::decls::Target::TgElement>(target0).a0;
        return sexp_path(Text::lit("element"), p_, d);
    }
    prism_rtl::unreachable("no arm matched");
}


/// SexpPath: fn Text, TestPath, Nat -> Text
Text sexp_path(const Text& word, const crate::syntax::decls::TestPath& p_, const Nat& d) {
    return prism_rtl::cat("(", word, concat(each(p_.segments, [&](const crate::syntax::decls::PathSeg& s) { return sexp_path_seg(s, d); })), ")");
}


/// SexpPathSeg: fn PathSeg, Nat -> Text
Text sexp_path_seg(const crate::syntax::decls::PathSeg& path_seg0, const Nat& n1) {
    auto&& _m = std::tuple{path_seg0, n1};
    if (prism_rtl::is<crate::syntax::decls::PathSeg::PsNum>(std::get<0>(_m))) {
        auto&& n = prism_rtl::as<crate::syntax::decls::PathSeg::PsNum>(std::get<0>(_m)).a0;
        return prism_rtl::cat(" ", n);
    }
    if (prism_rtl::is<crate::syntax::decls::PathSeg::PsGen>(std::get<0>(_m))) {
        auto&& n = prism_rtl::as<crate::syntax::decls::PathSeg::PsGen>(std::get<0>(_m)).a0;
        return prism_rtl::cat(" #", n);
    }
    if (prism_rtl::is<crate::syntax::decls::PathSeg::PsKey>(std::get<0>(_m))) {
        auto&& e = prism_rtl::as<crate::syntax::decls::PathSeg::PsKey>(std::get<0>(_m)).a0;
        auto&& d = std::get<1>(_m);
        return prism_rtl::cat(" [", sexp_expr(e, d), "]");
    }
    prism_rtl::unreachable("no arm matched");
}


/// SexpCheck: fn TestCheck, Nat -> Text
Text sexp_check(const crate::syntax::decls::TestCheck& c, const Nat& d) {
    auto&& _m = c.kind;
    if (prism_rtl::is<crate::syntax::decls::TestCheckKind::CkExpect>(_m)) {
        auto&& p_ = prism_rtl::as<crate::syntax::decls::TestCheckKind::CkExpect>(_m).a0;
        return prism_rtl::cat("(=> expect ", sexp_pattern(p_, d), ")");
    }
    if (prism_rtl::is<crate::syntax::decls::TestCheckKind::CkExpectNone>(_m)) {
        auto&& p_ = prism_rtl::as<crate::syntax::decls::TestCheckKind::CkExpectNone>(_m).a0;
        return prism_rtl::cat("(=> expect_none ", sexp_pattern(p_, d), ")");
    }
    if (prism_rtl::is<crate::syntax::decls::TestCheckKind::CkExpectCount>(_m)) {
        auto&& p_ = prism_rtl::as<crate::syntax::decls::TestCheckKind::CkExpectCount>(_m).a0;
        auto&& n = prism_rtl::as<crate::syntax::decls::TestCheckKind::CkExpectCount>(_m).a1;
        return prism_rtl::cat("(=> expect_count ", sexp_pattern(p_, d), " ", n, ")");
    }
    if (prism_rtl::is<crate::syntax::decls::TestCheckKind::CkExpectTop>(_m)) {
        auto&& p_ = prism_rtl::as<crate::syntax::decls::TestCheckKind::CkExpectTop>(_m).a0;
        return prism_rtl::cat("(=> expect_top ", sexp_pattern(p_, d), ")");
    }
    if (prism_rtl::is<crate::syntax::decls::TestCheckKind::CkExpectTopNone>(_m)) {
        auto&& p_ = prism_rtl::as<crate::syntax::decls::TestCheckKind::CkExpectTopNone>(_m).a0;
        return prism_rtl::cat("(=> expect_top_none ", sexp_pattern(p_, d), ")");
    }
    if (prism_rtl::is<crate::syntax::decls::TestCheckKind::CkRequested>(_m)) {
        auto&& p_ = prism_rtl::as<crate::syntax::decls::TestCheckKind::CkRequested>(_m).a0;
        auto&& v_ = prism_rtl::as<crate::syntax::decls::TestCheckKind::CkRequested>(_m).a1;
        return prism_rtl::cat("(=> requested ", sexp_pattern(p_, d), " ", sexp_pattern(v_, d), ")");
    }
    if (prism_rtl::is<crate::syntax::decls::TestCheckKind::CkUnrequested>(_m)) {
        auto&& p_ = prism_rtl::as<crate::syntax::decls::TestCheckKind::CkUnrequested>(_m).a0;
        return prism_rtl::cat("(=> unrequested ", sexp_pattern(p_, d), ")");
    }
    if (prism_rtl::is<crate::syntax::decls::TestCheckKind::CkReturns>(_m)) {
        auto&& p_ = prism_rtl::as<crate::syntax::decls::TestCheckKind::CkReturns>(_m).a0;
        return prism_rtl::cat("(=> returns ", sexp_pattern(p_, d), ")");
    }
    if (prism_rtl::is<crate::syntax::decls::TestCheckKind::CkFired>(_m)) {
        auto&& p_ = prism_rtl::as<crate::syntax::decls::TestCheckKind::CkFired>(_m).a0;
        return prism_rtl::cat("(=> fired ", sexp_pattern(p_, d), ")");
    }
    if (prism_rtl::is<crate::syntax::decls::TestCheckKind::CkQuiet>(_m)) {
        return Text::lit("(=> quiet)");
    }
    if (prism_rtl::is<crate::syntax::decls::TestCheckKind::CkSettles>(_m)) {
        return Text::lit("(=> settles)");
    }
    if (prism_rtl::is<crate::syntax::decls::TestCheckKind::CkAborted>(_m)) {
        return Text::lit("(=> aborted)");
    }
    if (prism_rtl::is<crate::syntax::decls::TestCheckKind::CkSnapshot>(_m)) {
        auto&& s = prism_rtl::as<crate::syntax::decls::TestCheckKind::CkSnapshot>(_m).a0;
        return prism_rtl::cat("(=> snapshot ", crate::syntax::lexer::corpus::debug_text(s), ")");
    }
    prism_rtl::unreachable("no arm matched");
}


/// SexpBlock: fn Block, Nat -> Text
Text sexp_block(const crate::syntax::Block& b, const Nat& d) {
    return b.inline_
        ? prism_rtl::cat(" (inline", concat(each(b.stmts, [&](const crate::syntax::Stmt& s) { return prism_rtl::cat(" ", sexp_stmt(s, d)); })), ")")
        : concat(each(b.stmts, [&](const crate::syntax::Stmt& s) { return prism_rtl::cat(nl(d + Nat(1u)), sexp_stmt(s, d + Nat(1u))); }));
}


/// SexpStmt: fn Stmt, Nat -> Text
Text sexp_stmt(const crate::syntax::Stmt& s, const Nat& d) {
    auto&& _m = s.kind;
    if (prism_rtl::is<crate::syntax::StmtKind::SEmit>(_m)) {
        auto&& r = prism_rtl::as<crate::syntax::StmtKind::SEmit>(_m).a0;
        return prism_rtl::cat("(emit ", sexp_row(r), ")");
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) && prism_rtl::is_none(prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2)) {
        auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a0;
        auto&& v_ = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a1;
        return prism_rtl::cat("(bind ", sexp_pattern(p_, d), " ", sexp_expr(v_, d), ")");
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) && prism_rtl::is_some(prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2)) {
        auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a0;
        auto&& v_ = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a1;
        auto&& t = prism_rtl::some_of(prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2);
        return prism_rtl::cat("(hold ", sexp_pattern(p_, d), " ", sexp_expr(v_, d), " then ", sexp_expr(t, d), ")");
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SIgnore>(_m)) {
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SIgnore>(_m).a0;
        return prism_rtl::cat("(ignore ", sexp_expr(e, d), ")");
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SLet>(_m)) {
        auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
        auto&& ty_opt = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a1;
        auto&& v_ = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
        return prism_rtl::cat("(let ", sexp_pattern(p_, d), opt_type(ty_opt), " ", sexp_expr(v_, d), ")");
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SSignature>(_m)) {
        auto&& sg = prism_rtl::as<crate::syntax::StmtKind::SSignature>(_m).a0;
        return sexp_signature(sg);
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SFn>(_m)) {
        auto&& f = prism_rtl::as<crate::syntax::StmtKind::SFn>(_m).a0;
        return sexp_fn(f, d);
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SWidget>(_m)) {
        auto&& w = prism_rtl::as<crate::syntax::StmtKind::SWidget>(_m).a0;
        return prism_rtl::cat("(widget ", sname_text(w.name), sexp_block(w.body, d), ")");
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SSet>(_m)) {
        auto&& t = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a0;
        auto&& v_ = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a1;
        return prism_rtl::cat("(set ", sexp_expr(t, d), " ", sexp_expr(v_, d), ")");
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SAccum>(_m)) {
        auto&& t = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a0;
        auto&& op = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a1;
        auto&& v_ = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a2;
        return prism_rtl::cat("(", op, " ", sexp_expr(t, d), " ", sexp_expr(v_, d), ")");
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SRequire>(_m)) {
        auto&& c = prism_rtl::as<crate::syntax::StmtKind::SRequire>(_m).a0;
        return prism_rtl::cat("(require ", sexp_expr(c, d), ")");
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SForbid>(_m)) {
        auto&& c = prism_rtl::as<crate::syntax::StmtKind::SForbid>(_m).a0;
        return prism_rtl::cat("(forbid ", sexp_expr(c, d), ")");
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SWhile>(_m)) {
        auto&& c = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a0;
        auto&& body = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a1;
        return prism_rtl::cat("(while ", sexp_cond(c, d), sexp_block(body, d), ")");
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SReturn>(_m)) {
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SReturn>(_m).a0;
        return prism_rtl::cat("(return ", sexp_expr(e, d), ")");
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m)) {
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
        return sexp_expr(e, d);
    }
    prism_rtl::unreachable("no arm matched");
}


/// SexpCond: fn Cond, Nat -> Text
Text sexp_cond(const crate::syntax::Cond& cond0, const Nat& d) {
    if (prism_rtl::is<crate::syntax::Cond::CondExpr>(cond0)) {
        auto&& e = prism_rtl::as<crate::syntax::Cond::CondExpr>(cond0).a0;
        return sexp_expr(e, d);
    }
    if (prism_rtl::is<crate::syntax::Cond::CondBind>(cond0)) {
        auto&& p_ = prism_rtl::as<crate::syntax::Cond::CondBind>(cond0).a0;
        auto&& v_ = prism_rtl::as<crate::syntax::Cond::CondBind>(cond0).a1;
        auto&& g_opt = prism_rtl::as<crate::syntax::Cond::CondBind>(cond0).a2;
        return prism_rtl::cat("(<- ", sexp_pattern(p_, d), " ", sexp_expr(v_, d), sexp_guard(g_opt, d), ")");
    }
    prism_rtl::unreachable("no arm matched");
}


/// SexpGuard: fn ?Expr, Nat -> Text
Text sexp_guard(const std::optional<crate::syntax::Expr>& opt0, const Nat& n1) {
    auto&& _m = std::tuple{opt0, n1};
    if (prism_rtl::is_none(std::get<0>(_m))) {
        return Text::lit("");
    }
    if (prism_rtl::is_some(std::get<0>(_m))) {
        auto&& g = prism_rtl::some_of(std::get<0>(_m));
        auto&& d = std::get<1>(_m);
        return prism_rtl::cat(" (if ", sexp_expr(g, d), ")");
    }
    prism_rtl::unreachable("no arm matched");
}


/// SexpLiteral: fn Literal, Nat -> Text
Text sexp_literal(const crate::syntax::Literal& l, const Nat& d) {
    auto&& _m = l.kind;
    if (prism_rtl::is<crate::syntax::LitKind::LInt>(_m)) {
        auto&& s = prism_rtl::as<crate::syntax::LitKind::LInt>(_m).a0;
        return prism_rtl::cat(l.marks, s);
    }
    if (prism_rtl::is<crate::syntax::LitKind::LFloat>(_m)) {
        auto&& s = prism_rtl::as<crate::syntax::LitKind::LFloat>(_m).a0;
        return prism_rtl::cat(l.marks, s);
    }
    if (prism_rtl::is<crate::syntax::LitKind::LDuration>(_m)) {
        auto&& digits = prism_rtl::as<crate::syntax::LitKind::LDuration>(_m).a0;
        auto&& u = prism_rtl::as<crate::syntax::LitKind::LDuration>(_m).a1;
        return prism_rtl::cat(l.marks, digits, u);
    }
    if (prism_rtl::is<crate::syntax::LitKind::LChar>(_m)) {
        auto&& c = prism_rtl::as<crate::syntax::LitKind::LChar>(_m).a0;
        return prism_rtl::cat(l.marks, crate::syntax::lexer::corpus::debug_char(c));
    }
    if (prism_rtl::is<crate::syntax::LitKind::LRegex>(_m)) {
        auto&& r = prism_rtl::as<crate::syntax::LitKind::LRegex>(_m).a0;
        auto&& _m = r.replacement;
        if (prism_rtl::is_none(_m)) {
            return prism_rtl::cat("(", l.marks, "regex ", crate::syntax::lexer::corpus::debug_text(r.pattern), " ", crate::syntax::lexer::corpus::debug_text(r.flags), ")");
        }
        if (prism_rtl::is_some(_m)) {
            auto&& t = prism_rtl::some_of(_m);
            return prism_rtl::cat("(", l.marks, "regex-replacement ", crate::syntax::lexer::corpus::debug_text(r.pattern), " ", crate::syntax::lexer::corpus::debug_text(t), " ", crate::syntax::lexer::corpus::debug_text(r.flags), ")");
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<crate::syntax::LitKind::LText>(_m)) {
        auto&& segs = prism_rtl::as<crate::syntax::LitKind::LText>(_m).a0;
        return all_plain_segs(segs)
            ? prism_rtl::cat(l.marks, crate::syntax::lexer::corpus::debug_text(concat(each(segs, plain_seg_text))))
            : prism_rtl::cat("(", l.marks, "text", concat(each(segs, [&](const crate::syntax::TextSeg& s) { return prism_rtl::cat(" ", sexp_seg(s, d)); })), ")");
    }
    prism_rtl::unreachable("no arm matched");
}


/// AllPlainSegs: fn [TextSeg] -> Bool
bool all_plain_segs(const Array<crate::syntax::TextSeg>& segs) {
    return fold(segs, true, [&](const bool& ok, const crate::syntax::TextSeg& s) { return ok && is_plain_text_seg(s); });
}


/// IsPlainTextSeg: fn TextSeg -> Bool
bool is_plain_text_seg(const crate::syntax::TextSeg& text_seg0) {
    if (prism_rtl::is<crate::syntax::TextSeg::SegPlain>(text_seg0)) {
        return true;
    }
    {
        return false;
    }
}


/// PlainSegText: fn TextSeg -> Text
Text plain_seg_text(const crate::syntax::TextSeg& text_seg0) {
    if (prism_rtl::is<crate::syntax::TextSeg::SegPlain>(text_seg0)) {
        auto&& s = prism_rtl::as<crate::syntax::TextSeg::SegPlain>(text_seg0).a0;
        return s;
    }
    {
        return Text::lit("");
    }
}


/// SexpSeg: fn TextSeg, Nat -> Text
Text sexp_seg(const crate::syntax::TextSeg& text_seg0, const Nat& n1) {
    auto&& _m = std::tuple{text_seg0, n1};
    if (prism_rtl::is<crate::syntax::TextSeg::SegPlain>(std::get<0>(_m))) {
        auto&& p_ = prism_rtl::as<crate::syntax::TextSeg::SegPlain>(std::get<0>(_m)).a0;
        return crate::syntax::lexer::corpus::debug_text(p_);
    }
    if (prism_rtl::is<crate::syntax::TextSeg::SegPlaceholder>(std::get<0>(_m))) {
        auto&& e = prism_rtl::as<crate::syntax::TextSeg::SegPlaceholder>(std::get<0>(_m)).a0;
        auto&& d = std::get<1>(_m);
        return prism_rtl::cat("{", sexp_expr(e, d), "}");
    }
    prism_rtl::unreachable("no arm matched");
}


/// SexpArgs: fn [Arg], Nat -> Text
Text sexp_args(const Array<crate::syntax::Arg>& args, const Nat& d) {
    return concat(each(args, [&](const crate::syntax::Arg& a) { return prism_rtl::cat(" ", arg_name(a.name), sexp_expr(a->value, d)); }));
}


/// ArgName: fn ?Ident -> Text
Text arg_name(const std::optional<crate::syntax::Ident>& opt0) {
    if (prism_rtl::is_none(opt0)) {
        return Text::lit("");
    }
    if (prism_rtl::is_some(opt0)) {
        auto&& n = prism_rtl::some_of(opt0);
        return prism_rtl::cat(n.name, "=");
    }
    prism_rtl::unreachable("no arm matched");
}


/// SexpExprs: fn [Expr], Nat -> Text
Text sexp_exprs(const Array<crate::syntax::Expr>& es, const Nat& d) {
    return concat(each(es, [&](const crate::syntax::Expr& x) { return prism_rtl::cat(" ", sexp_expr(x, d)); }));
}


/// SexpExpr: fn Expr, Nat -> Text
Text sexp_expr(const crate::syntax::Expr& e, const Nat& d) {
    auto&& _m = e.kind;
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        return sname_text(n);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ELit>(_m)) {
        auto&& l = prism_rtl::as<crate::syntax::ExprKind::ELit>(_m).a0;
        return sexp_literal(l, d);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EUnit>(_m)) {
        auto&& s = prism_rtl::as<crate::syntax::ExprKind::EUnit>(_m).a0;
        return prism_rtl::cat(s, "unit");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ENil>(_m)) {
        auto&& s = prism_rtl::as<crate::syntax::ExprKind::ENil>(_m).a0;
        return prism_rtl::cat(s, "nil");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EBound>(_m)) {
        auto&& b = prism_rtl::as<crate::syntax::ExprKind::EBound>(_m).a0;
        return b;
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ETuple>(_m)) {
        auto&& es = prism_rtl::as<crate::syntax::ExprKind::ETuple>(_m).a0;
        return prism_rtl::cat("(tuple", sexp_exprs(es, d), ")");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EArray>(_m)) {
        auto&& es = prism_rtl::as<crate::syntax::ExprKind::EArray>(_m).a0;
        return prism_rtl::cat("(array", sexp_exprs(es, d), ")");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMap>(_m)) {
        auto&& es = prism_rtl::as<crate::syntax::ExprKind::EMap>(_m).a0;
        return prism_rtl::cat("(map", concat(each(es, [&](const std::tuple<crate::syntax::Expr, crate::syntax::Expr>& _p0) {
            auto&& k = std::get<0>(_p0);
            auto&& v_ = std::get<1>(_p0);
            return prism_rtl::cat(" (", sexp_expr(k, d), ": ", sexp_expr(v_, d), ")");
        })), ")");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return prism_rtl::cat("(group ", sexp_expr(x, d), ")");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
        auto&& callee = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
        auto&& args = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
        auto&& parens = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a2;
        auto&& rest = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a3;
        return prism_rtl::cat("(", parens ? Text::lit("call()") : Text::lit("call"), " ", sexp_expr(callee, d), sexp_args(args, d), rest ? Text::lit(" ..") : Text::lit(""), ")");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EBinary>(_m)) {
        auto&& op = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a0;
        auto&& lhs = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
        auto&& rhs = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a2;
        return prism_rtl::cat("(", op, " ", sexp_expr(lhs, d), " ", sexp_expr(rhs, d), ")");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ESuffixed>(_m)) {
        auto&& op = prism_rtl::as<crate::syntax::ExprKind::ESuffixed>(_m).a0;
        auto&& ty = prism_rtl::as<crate::syntax::ExprKind::ESuffixed>(_m).a1;
        auto&& lhs = prism_rtl::as<crate::syntax::ExprKind::ESuffixed>(_m).a2;
        auto&& rhs = prism_rtl::as<crate::syntax::ExprKind::ESuffixed>(_m).a3;
        return prism_rtl::cat("(", op, crate::syntax::sexp::path_(ty->path_), " ", sexp_expr(lhs, d), " ", sexp_expr(rhs, d), ")");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EUnary>(_m)) {
        auto&& op = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a0;
        auto&& operand = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a1;
        return prism_rtl::cat("(", op, " ", sexp_expr(operand, d), ")");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m)) {
        auto&& s = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
        auto&& operand = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
        return prism_rtl::cat("(free", s, " ", sexp_expr(operand, d), ")");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EField>(_m)) {
        auto&& recv = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a0;
        auto&& sigils = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a1;
        auto&& name = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a2;
        return prism_rtl::cat("(. ", sexp_expr(recv, d), " ", sigils, name.name, ")");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m)) {
        auto&& recv = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
        auto&& index = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a1;
        return prism_rtl::cat("(index ", sexp_expr(recv, d), " ", sexp_expr(index, d), ")");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ETopicField>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::ETopicField>(_m).a0;
        return prism_rtl::cat("(. _ ", n.name, ")");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ETopicIndex>(_m)) {
        auto&& i = prism_rtl::as<crate::syntax::ExprKind::ETopicIndex>(_m).a0;
        return prism_rtl::cat("(index _ ", sexp_expr(i, d), ")");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMethod>(_m)) {
        auto&& recv = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a0;
        auto&& method = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a1;
        auto&& args = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a2;
        return prism_rtl::cat("(.", sname_text(method), " ", sexp_expr(recv, d), sexp_args(args, d), ")");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ETypeArgs>(_m)) {
        auto&& target = prism_rtl::as<crate::syntax::ExprKind::ETypeArgs>(_m).a0;
        auto&& types = prism_rtl::as<crate::syntax::ExprKind::ETypeArgs>(_m).a1;
        return prism_rtl::cat("(<<>> ", sexp_expr(target, d), spaced(types, ({
            auto f = prism_rtl::rc(sexp_type);
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::syntax::Type)>>(prism_rtl::rc([=](crate::syntax::Type a0) {
            return ({
                auto f_1 = f;
                once_job([=]() { return prism_rtl::finished(f_1(a0)); });
            });
        })));
        })), ")");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ECast>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::ECast>(_m).a0;
        auto&& ty = prism_rtl::as<crate::syntax::ExprKind::ECast>(_m).a1;
        auto&& checked = prism_rtl::as<crate::syntax::ExprKind::ECast>(_m).a2;
        return prism_rtl::cat("(", checked ? Text::lit("as?") : Text::lit("as"), " ", sexp_expr(x, d), " ", sexp_type(ty), ")");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ENonEmpty>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::ENonEmpty>(_m).a0;
        return prism_rtl::cat("(nonempty ", sexp_expr(x, d), ")");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EAbsent>(_m)) {
        return Text::lit("absent");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ERest>(_m)) {
        return Text::lit("..");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m)) {
        auto&& params_opt = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0;
        auto&& body = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a1;
        return prism_rtl::cat("(lambda", sexp_lambda_params(params_opt, d), sexp_lambda_body(body, d), ")");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EIf>(_m)) {
        auto&& c = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
        auto&& then_block = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
        auto&& else_block_opt = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
        return prism_rtl::cat("(if ", sexp_cond(c, d), sexp_block(then_block, d), sexp_else(else_block_opt, d), ")");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m)) {
        auto&& scrutinee = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
        auto&& arms = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
        return prism_rtl::cat("(match ", sexp_expr(scrutinee, d), concat(each(arms, [&](const crate::syntax::Arm& a) { return prism_rtl::cat(nl(d + Nat(1u)), sexp_arm(a, d + Nat(1u))); })), ")");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ERebuild>(_m)) {
        auto&& scrutinee = prism_rtl::as<crate::syntax::ExprKind::ERebuild>(_m).a0;
        auto&& body = prism_rtl::as<crate::syntax::ExprKind::ERebuild>(_m).a1;
        return prism_rtl::cat("(rebuild ", sexp_expr(scrutinee, d), sexp_block(body, d), ")");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EFor>(_m)) {
        auto&& binders_opt = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a0;
        auto&& source = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a1;
        auto&& body = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a2;
        return prism_rtl::cat("(for", sexp_binders(binders_opt, d), " ", sexp_expr(source, d), sexp_block(body, d), ")");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGiven>(_m)) {
        auto&& b = prism_rtl::as<crate::syntax::ExprKind::EGiven>(_m).a0;
        return prism_rtl::cat("(given", sexp_block(b, d), ")");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EUpdate>(_m)) {
        auto&& target = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a0;
        auto&& body = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a1;
        return prism_rtl::cat("(update ", sexp_expr(target, d), sexp_block(body, d), ")");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EWidgetBlock>(_m)) {
        auto&& b = prism_rtl::as<crate::syntax::ExprKind::EWidgetBlock>(_m).a0;
        return prism_rtl::cat("(@widget", sexp_block(b, d), ")");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMonad>(_m)) {
        auto&& m = prism_rtl::as<crate::syntax::ExprKind::EMonad>(_m).a0;
        auto&& body = prism_rtl::as<crate::syntax::ExprKind::EMonad>(_m).a1;
        return prism_rtl::cat("(monad ", sexp_expr(m, d), sexp_block(body, d), ")");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ETemplate>(_m)) {
        auto&& t = prism_rtl::as<crate::syntax::ExprKind::ETemplate>(_m).a0;
        return sexp_template(t, d);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EAny>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EAny>(_m).a0;
        return prism_rtl::cat("(any ", sexp_expr(x, d), ")");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ELens>(_m)) {
        auto&& path__ = prism_rtl::as<crate::syntax::ExprKind::ELens>(_m).a0;
        return prism_rtl::cat("(lens ", crate::syntax::lexer::chars::join(each(path__, [&](const crate::syntax::Ident& i) { return i.name; }), Text::lit(".")), ")");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EError>(_m)) {
        return Text::lit("<error>");
    }
    prism_rtl::unreachable("no arm matched");
}


/// SexpLambdaParams: fn ?[Pattern], Nat -> Text
Text sexp_lambda_params(const std::optional<Array<crate::syntax::Pattern_>>& opt0, const Nat& n1) {
    auto&& _m = std::tuple{opt0, n1};
    if (prism_rtl::is_none(std::get<0>(_m))) {
        return Text::lit(" topic");
    }
    if (prism_rtl::is_some(std::get<0>(_m))) {
        auto&& ps = prism_rtl::some_of(std::get<0>(_m));
        auto&& d = std::get<1>(_m);
        return prism_rtl::cat(" (params", concat(each(ps, [&](const crate::syntax::Pattern_& p_) { return prism_rtl::cat(" ", sexp_pattern(p_, d)); })), ")");
    }
    prism_rtl::unreachable("no arm matched");
}


/// SexpLambdaBody: fn LambdaBody, Nat -> Text
Text sexp_lambda_body(const crate::syntax::LambdaBody& lambda_body0, const Nat& d) {
    if (prism_rtl::is<crate::syntax::LambdaBody::LbExpr>(lambda_body0)) {
        auto&& e = prism_rtl::as<crate::syntax::LambdaBody::LbExpr>(lambda_body0).a0;
        return prism_rtl::cat(" ", sexp_expr(e, d));
    }
    if (prism_rtl::is<crate::syntax::LambdaBody::LbBlock>(lambda_body0)) {
        auto&& b = prism_rtl::as<crate::syntax::LambdaBody::LbBlock>(lambda_body0).a0;
        return sexp_block(b, d);
    }
    prism_rtl::unreachable("no arm matched");
}


/// SexpElse: fn ?Block, Nat -> Text
Text sexp_else(const std::optional<crate::syntax::Block>& opt0, const Nat& n1) {
    auto&& _m = std::tuple{opt0, n1};
    if (prism_rtl::is_none(std::get<0>(_m))) {
        return Text::lit("");
    }
    if (prism_rtl::is_some(std::get<0>(_m))) {
        auto&& b = prism_rtl::some_of(std::get<0>(_m));
        auto&& d = std::get<1>(_m);
        return prism_rtl::cat(b.inline_ ? Text::lit("") : nl(d), " else", sexp_block(b, d));
    }
    prism_rtl::unreachable("no arm matched");
}


/// SexpArm: fn Arm, Nat -> Text
Text sexp_arm(const crate::syntax::Arm& a, const Nat& d) {
    auto pattern = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = a.pattern;
        if (prism_rtl::is_some(_m)) {
            auto&& p_ = prism_rtl::some_of(_m);
            _v.set(sexp_pattern(p_, d));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text::lit("otherwise"));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return prism_rtl::cat("(arm ", pattern, sexp_guard(a.guard, d), sexp_block(a.body, d), ")");
}


/// SexpBinders: fn ?ForBinders, Nat -> Text
Text sexp_binders(const std::optional<crate::syntax::ForBinders>& opt0, const Nat& n1) {
    auto&& _m = std::tuple{opt0, n1};
    if (prism_rtl::is_none(std::get<0>(_m))) {
        return Text::lit("");
    }
    if (prism_rtl::is_some(std::get<0>(_m))) {
        auto&& b = prism_rtl::some_of(std::get<0>(_m));
        auto&& d = std::get<1>(_m);
        auto second = ({
            __label__ _done;
            prism_rtl::Slot<Text> _v;
            auto&& _m = b.second;
            if (prism_rtl::is_some(_m)) {
                auto&& s = prism_rtl::some_of(_m);
                _v.set(prism_rtl::cat(", ", sexp_pattern(s, d)));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(Text::lit(""));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        return prism_rtl::cat(" ", sexp_pattern(b.first, d), second, " <-");
    }
    prism_rtl::unreachable("no arm matched");
}


/// SexpTemplate: fn Template, Nat -> Text
Text sexp_template(const crate::syntax::Template& t, const Nat& d) {
    return prism_rtl::cat("(template ", t.keyword, " <", t.lang, ">", sexp_parts(t.parts, d + Nat(1u)), ")");
}


/// SexpParts: fn [TemplatePart], Nat -> Text
Text sexp_parts(const Array<crate::syntax::TemplatePart>& parts, const Nat& d) {
    return concat(each(parts, [&](const crate::syntax::TemplatePart& p_) { return prism_rtl::cat(nl(d), sexp_part(p_, d)); }));
}


/// SexpPart: fn TemplatePart, Nat -> Text
Text sexp_part(const crate::syntax::TemplatePart& template_part0, const Nat& n1) {
    auto&& _m = std::tuple{template_part0, n1};
    if (prism_rtl::is<crate::syntax::TemplatePart::TpText>(std::get<0>(_m))) {
        auto&& s = prism_rtl::as<crate::syntax::TemplatePart::TpText>(std::get<0>(_m)).a0;
        return crate::syntax::lexer::corpus::debug_text(s);
    }
    if (prism_rtl::is<crate::syntax::TemplatePart::TpPlaceholder>(std::get<0>(_m))) {
        auto&& e = prism_rtl::as<crate::syntax::TemplatePart::TpPlaceholder>(std::get<0>(_m)).a0;
        auto&& col_opt = prism_rtl::as<crate::syntax::TemplatePart::TpPlaceholder>(std::get<0>(_m)).a1;
        auto&& d = std::get<1>(_m);
        return prism_rtl::cat("{{", sexp_expr(e, d), "}}", column_text(col_opt));
    }
    if (prism_rtl::is<crate::syntax::TemplatePart::TpBlock>(std::get<0>(_m))) {
        auto&& b = prism_rtl::as<crate::syntax::TemplatePart::TpBlock>(std::get<0>(_m)).a0;
        auto&& d = std::get<1>(_m);
        return prism_rtl::cat("(brace-block", sexp_block(b, d), ")");
    }
    if (prism_rtl::is<crate::syntax::TemplatePart::TpCall>(std::get<0>(_m))) {
        auto&& name = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(std::get<0>(_m)).a0;
        auto&& attrs = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(std::get<0>(_m)).a1;
        auto&& body_opt = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(std::get<0>(_m)).a2;
        auto&& d = std::get<1>(_m);
        return prism_rtl::cat("(call ", sname_text(name), sexp_args(attrs, d), call_parts(body_opt, d), ")");
    }
    prism_rtl::unreachable("no arm matched");
}


/// ColumnText: fn ?Nat -> Text
Text column_text(const std::optional<Nat>& opt0) {
    if (prism_rtl::is_none(opt0)) {
        return Text::lit("");
    }
    if (prism_rtl::is_some(opt0)) {
        auto&& c = prism_rtl::some_of(opt0);
        return prism_rtl::cat(" @col ", c);
    }
    prism_rtl::unreachable("no arm matched");
}


/// CallParts: fn ?[TemplatePart], Nat -> Text
Text call_parts(const std::optional<Array<crate::syntax::TemplatePart>>& opt0, const Nat& n1) {
    auto&& _m = std::tuple{opt0, n1};
    if (prism_rtl::is_none(std::get<0>(_m))) {
        return Text::lit("");
    }
    if (prism_rtl::is_some(std::get<0>(_m))) {
        auto&& parts = prism_rtl::some_of(std::get<0>(_m));
        auto&& d = std::get<1>(_m);
        return sexp_parts(parts, d + Nat(1u));
    }
    prism_rtl::unreachable("no arm matched");
}


/// SexpPattern: fn Pattern, Nat -> Text
Text sexp_pattern(const crate::syntax::Pattern_& p_, const Nat& d) {
    auto&& _m = p_.kind;
    if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        return sname_text(n);
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PIgnore>(_m)) {
        return Text::lit("ignore");
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PLit>(_m)) {
        auto&& l = prism_rtl::as<crate::syntax::PatternKind::PLit>(_m).a0;
        return sexp_literal(l, d);
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PNeg>(_m)) {
        auto&& l = prism_rtl::as<crate::syntax::PatternKind::PNeg>(_m).a0;
        return prism_rtl::cat("-", sexp_literal(l, d));
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PUnit>(_m)) {
        return Text::lit("unit");
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PNil>(_m)) {
        return Text::lit("nil");
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PCtor>(_m)) {
        auto&& name = prism_rtl::as<crate::syntax::PatternKind::PCtor>(_m).a0;
        auto&& args = prism_rtl::as<crate::syntax::PatternKind::PCtor>(_m).a1;
        return prism_rtl::cat("(ctor ", sname_text(name), concat(each(args, [&](const crate::syntax::Pattern_& a) { return prism_rtl::cat(" ", sexp_pattern(a, d)); })), ")");
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PRecord>(_m)) {
        auto&& name = prism_rtl::as<crate::syntax::PatternKind::PRecord>(_m).a0;
        auto&& fields = prism_rtl::as<crate::syntax::PatternKind::PRecord>(_m).a1;
        auto&& rest = prism_rtl::as<crate::syntax::PatternKind::PRecord>(_m).a2;
        return prism_rtl::cat("(record ", sname_text(name), concat(each(fields, [&](const crate::syntax::FieldPat& f) { return prism_rtl::cat(" ", arg_name(f.name), sexp_pattern(f.pattern, d)); })), rest ? Text::lit(" ..") : Text::lit(""), ")");
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PSigil>(_m)) {
        auto&& s = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a0;
        auto&& inner = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a1;
        return prism_rtl::cat("(free", s, " ", sexp_pattern(inner, d), ")");
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PTuple>(_m)) {
        auto&& ps = prism_rtl::as<crate::syntax::PatternKind::PTuple>(_m).a0;
        return prism_rtl::cat("(tuple", concat(each(ps, [&](const crate::syntax::Pattern_& x) { return prism_rtl::cat(" ", sexp_pattern(x, d)); })), ")");
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PArray>(_m)) {
        auto&& ps = prism_rtl::as<crate::syntax::PatternKind::PArray>(_m).a0;
        return prism_rtl::cat("(array", concat(each(ps, [&](const crate::syntax::Pattern_& x) { return prism_rtl::cat(" ", sexp_pattern(x, d)); })), ")");
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::PatternKind::PGroup>(_m).a0;
        return prism_rtl::cat("(group ", sexp_pattern(x, d), ")");
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PFamily>(_m)) {
        auto&& q = prism_rtl::as<crate::syntax::PatternKind::PFamily>(_m).a0;
        return prism_rtl::cat(crate::syntax::sexp::path_(q->path_), ".*");
    }
    prism_rtl::unreachable("no arm matched");
}


/// SexpType: fn Type -> Text
Text sexp_type(const crate::syntax::Type& t) {
    auto&& _m = t.kind;
    if (prism_rtl::is<crate::syntax::TypeKind::TName>(_m)) {
        auto&& name = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a0;
        auto&& m16591_0_1 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a1;
        if (m16591_0_1.size() == 0u) {
            return sname_text(name);
        }
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TName>(_m)) {
        auto&& name = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a0;
        auto&& args = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a1;
        return prism_rtl::cat("(", sname_text(name), concat(each(args, [&](const crate::syntax::Type& a) { return prism_rtl::cat(" ", sexp_type(a)); })), ")");
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TSigiled>(_m)) {
        auto&& sigils = prism_rtl::as<crate::syntax::TypeKind::TSigiled>(_m).a0;
        auto&& inner = prism_rtl::as<crate::syntax::TypeKind::TSigiled>(_m).a1;
        return prism_rtl::cat("(free", sigils, " ", sexp_type(inner), ")");
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TArray>(_m) && prism_rtl::as<crate::syntax::TypeKind::TArray>(_m).a1) {
        auto&& elem = prism_rtl::as<crate::syntax::TypeKind::TArray>(_m).a0;
        return prism_rtl::cat("[[", sexp_type(elem), "]]");
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TArray>(_m) && !prism_rtl::as<crate::syntax::TypeKind::TArray>(_m).a1) {
        auto&& elem = prism_rtl::as<crate::syntax::TypeKind::TArray>(_m).a0;
        return prism_rtl::cat("[", sexp_type(elem), "]");
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TTuple>(_m)) {
        auto&& ts = prism_rtl::as<crate::syntax::TypeKind::TTuple>(_m).a0;
        return prism_rtl::cat("(tuple", concat(each(ts, [&](const crate::syntax::Type& x) { return prism_rtl::cat(" ", sexp_type(x)); })), ")");
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::TypeKind::TGroup>(_m).a0;
        return prism_rtl::cat("(group ", sexp_type(x), ")");
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TMap>(_m)) {
        auto&& k = prism_rtl::as<crate::syntax::TypeKind::TMap>(_m).a0;
        auto&& v_ = prism_rtl::as<crate::syntax::TypeKind::TMap>(_m).a1;
        return prism_rtl::cat("(==> ", sexp_type(k), " ", sexp_type(v_), ")");
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TFn>(_m)) {
        auto&& color = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a0;
        auto&& params = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a1;
        auto&& result = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a2;
        return prism_rtl::cat("(", color_text(color), "fn", concat(each(params, [&](const crate::syntax::Type& x) { return prism_rtl::cat(" ", sexp_type(x)); })), " -> ", sexp_type(result), ")");
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TEmit>(_m)) {
        auto&& ty = prism_rtl::as<crate::syntax::TypeKind::TEmit>(_m).a0;
        auto&& r = prism_rtl::as<crate::syntax::TypeKind::TEmit>(_m).a1;
        return prism_rtl::cat("(emit ", sexp_type(ty), " ", sexp_type(r), ")");
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TRowUnion>(_m)) {
        auto&& ts = prism_rtl::as<crate::syntax::TypeKind::TRowUnion>(_m).a0;
        return prism_rtl::cat("(|", concat(each(ts, [&](const crate::syntax::Type& x) { return prism_rtl::cat(" ", sexp_type(x)); })), ")");
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TFamily>(_m)) {
        auto&& q = prism_rtl::as<crate::syntax::TypeKind::TFamily>(_m).a0;
        return prism_rtl::cat(crate::syntax::sexp::path_(q->path_), ".*");
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TAny>(_m)) {
        auto&& tr = prism_rtl::as<crate::syntax::TypeKind::TAny>(_m).a0;
        return prism_rtl::cat("(any ^", crate::syntax::sexp::path_(tr->path_), ")");
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TUnit>(_m)) {
        auto&& s = prism_rtl::as<crate::syntax::TypeKind::TUnit>(_m).a0;
        return prism_rtl::cat(s, "unit");
    }
    if (prism_rtl::is<crate::syntax::TypeKind::THole>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::TypeKind::THole>(_m).a0;
        return sname_text(n);
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TAbsent>(_m)) {
        return Text::lit("absent");
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TNonEmpty>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::TypeKind::TNonEmpty>(_m).a0;
        return prism_rtl::cat("(nonempty ", sexp_type(x), ")");
    }
    prism_rtl::unreachable("no arm matched");
}


/// ColorText: fn Color -> Text
Text color_text(const crate::syntax::Color& color0) {
    if (prism_rtl::is<crate::syntax::Color::Bounded>(color0)) {
        return Text::lit("");
    }
    if (prism_rtl::is<crate::syntax::Color::Unbounded>(color0)) {
        return Text::lit("unbounded ");
    }
    if (prism_rtl::is<crate::syntax::Color::ColorVar>(color0)) {
        auto&& v_ = prism_rtl::as<crate::syntax::Color::ColorVar>(color0).a0;
        return prism_rtl::cat(v_.name, " ");
    }
    prism_rtl::unreachable("no arm matched");
}

}  // namespace crate::syntax::sexp
