// The module `Syntax.Sexp`: its generic functions' and types' definitions, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <syntax/sexp/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>

namespace crate {

using namespace prelude;

namespace syntax::sexp {

/// Spaced: fn [a], (fn a -> Text) -> Text
template <class A>
Text spaced(const Array<A>& xs_p0, const prism_rtl::Fn<prism_rtl::JobRef<Text>(A)>& f_f1) {
    return concat(run_to_end(each_job(xs_p0, ({
        auto f_f1_1 = f_f1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(A)>>(prism_rtl::rc([=, f_f1_1 = std::move(f_f1_1)](A p0) {
        return ({
            auto f_f1_1_2 = f_f1_1;
            entered(once_job([=, f_f1_1_2 = std::move(f_f1_1_2)]() {
            return ({
                auto x_p2 = p0;
                call_value(f_f1_1_2(x_p2), [=](Text f_1272) { return prism_rtl::finished(prism_rtl::cat(" ", f_1272)); });
            });
        }));
        });
    })));
    }))));
}


}  // namespace syntax::sexp

}  // namespace crate
