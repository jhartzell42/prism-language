// The module `Syntax.Sexp`: its generic functions' and types' definitions, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <syntax/sexp/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>

namespace crate {

using namespace prelude;

namespace syntax::sexp {

/// Spaced: fn [a], (fn a -> Text) -> Text
template <class A>
Text spaced_f(const Array<A>& xs_p0, const prism_rtl::Fn<prism_rtl::JobRef<Text>(A)>& f_f1) {
    return crate::prelude::concat(crate::prelude::run_to_end(crate::prelude::each_job(xs_p0, ({
        auto f_f1x = f_f1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(A)>>(prism_rtl::rc([=, f_f1x = std::move(f_f1x)](A p0) {
        return ({
            auto f_f1xy = f_f1x;
            (crate::prelude::entered(crate::prelude::once_job([=, f_f1xy = std::move(f_f1xy)]() {
            return ({
                auto x_p2 = p0;
                (crate::prelude::call_value(f_f1xy(x_p2), [=](Text f_1176) { return prism_rtl::finished(prism_rtl::cat(" ", f_1176)); }));
            });
        })));
        });
    })));
    }))));
}


}  // namespace syntax::sexp

}  // namespace crate
