// The module `Syntax.Sexp`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <syntax/sexp/types.hpp>
#include "elem.types.hpp"
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>

namespace crate {

using namespace prelude;

namespace syntax::sexp {

Text nl_f(const Nat& d_p0);

Text indent_f(const Nat& d_p0);

template <class A>
Text spaced_f(const Array<A>& xs_p0, const prism_rtl::Fn<prism_rtl::JobRef<Text>(A)>& f_f1);

Text path_f(const Array<Text>& p_p0);

Text sname_text_f(const crate::syntax::SName& n_p0);

Text sexp_module_f(const crate::syntax::Module& m_p0);

Text sexp_row_f(const crate::syntax::Row_& r_p0);

Text sexp_row_term_f(const crate::syntax::RowTerm& row_term0);

Text sexp_decl_f(const crate::syntax::decls::Decl& d_p0, const Nat& depth_p1);

Text opt_type_f(const std::optional<crate::syntax::Type>& opt0);

Text check_pattern_f(const std::optional<crate::syntax::Pattern_>& opt0, const Nat& n1);

Text sexp_type_body_f(const std::optional<crate::syntax::decls::TypeBody>& opt0, const Nat& n1);

Text sexp_signature_f(const crate::syntax::decls::Signature& s_p0);

Text sexp_def_name_f(const crate::syntax::decls::DefName& def_name0);

Text sexp_bounds_f(const Array<crate::syntax::decls::Bound>& bs_p0);

Text sexp_fn_f(const crate::syntax::decls::FnClause& f_p0, const Nat& depth_p1);

Text sexp_fields_f(const Array<crate::syntax::decls::Field>& fs_p0, const Nat& depth_p1);

Text sexp_case_f(const crate::syntax::decls::Case_& c_p0);

Text sexp_items_f(const Array<crate::syntax::decls::TraitItem>& items_p0, const Nat& depth_p1);

Text sexp_item_f(const crate::syntax::decls::TraitItem& trait_item0, const Nat& n1);

Text sexp_test_f(const crate::syntax::decls::TestDecl& t_p0, const Nat& depth_p1);

Text sexp_step_f(const crate::syntax::decls::TestStep& s_p0, const Nat& d_p1);

Text sexp_action_f(const crate::syntax::decls::StepAction& step_action0, const Nat& n1);

Text sexp_delivery_f(const crate::syntax::decls::Delivery& x_p0, const Nat& d_p1);

Text sexp_target_f(const crate::syntax::decls::Target& target0, const Nat& d_p1);

Text sexp_path_f(const Text& word_p0, const crate::syntax::decls::TestPath& p_p1, const Nat& d_p2);

Text sexp_path_seg_f(const crate::syntax::decls::PathSeg& path_seg0, const Nat& n1);

Text sexp_check_f(const crate::syntax::decls::TestCheck& c_p0, const Nat& d_p1);

Text sexp_block_f(const crate::syntax::Block& b_p0, const Nat& d_p1);

Text sexp_stmt_f(const crate::syntax::Stmt& s_p0, const Nat& d_p1);

Text sexp_cond_f(const crate::syntax::Cond& cond0, const Nat& d_p1);

Text sexp_guard_f(const std::optional<crate::syntax::Expr>& opt0, const Nat& n1);

Text sexp_literal_f(const crate::syntax::Literal& l_p0, const Nat& d_p1);

bool all_plain_segs_f(const Array<crate::syntax::TextSeg>& segs_p0);

bool is_plain_text_seg_f(const crate::syntax::TextSeg& text_seg0);

Text plain_seg_text_f(const crate::syntax::TextSeg& text_seg0);

Text sexp_seg_f(const crate::syntax::TextSeg& text_seg0, const Nat& n1);

Text sexp_args_f(const Array<crate::syntax::Arg>& args_p0, const Nat& d_p1);

Text arg_name_f(const std::optional<crate::syntax::Ident>& opt0);

Text sexp_exprs_f(const Array<crate::syntax::Expr>& es_p0, const Nat& d_p1);

Text sexp_expr_f(const crate::syntax::Expr& e_p0, const Nat& d_p1);

Text sexp_lambda_params_f(const std::optional<Array<crate::syntax::Pattern_>>& opt0, const Nat& n1);

Text sexp_lambda_body_f(const crate::syntax::LambdaBody& lambda_body0, const Nat& d_p1);

Text sexp_else_f(const std::optional<crate::syntax::Block>& opt0, const Nat& n1);

Text sexp_arm_f(const crate::syntax::Arm& a_p0, const Nat& d_p1);

Text sexp_binders_f(const std::optional<crate::syntax::ForBinders>& opt0, const Nat& n1);

Text sexp_template_f(const crate::syntax::Template& t_p0, const Nat& d_p1);

Text sexp_parts_f(const Array<crate::syntax::TemplatePart>& parts_p0, const Nat& d_p1);

Text sexp_part_f(const crate::syntax::TemplatePart& template_part0, const Nat& n1);

Text column_text_f(const std::optional<Nat>& opt0);

Text call_parts_f(const std::optional<Array<crate::syntax::TemplatePart>>& opt0, const Nat& n1);

Text sexp_pattern_f(const crate::syntax::Pattern_& p_p0, const Nat& d_p1);

Text sexp_type_f(const crate::syntax::Type& t_p0);

Text color_text_f(const crate::syntax::Color& color0);

}  // namespace syntax::sexp



}  // namespace crate
