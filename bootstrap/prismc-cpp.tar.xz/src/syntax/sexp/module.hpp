// The module `Syntax.Sexp`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <syntax/sexp/types.hpp>
#include "elem.types.hpp"
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>

namespace crate {

using namespace prelude;

namespace syntax::sexp {

Text nl(const Nat& d);

Text indent(const Nat& d);

template <class A>
Text spaced(const Array<A>& xs, const prism_rtl::Fn<prism_rtl::JobRef<Text>(A)>& f_fn);

Text path_(const Array<Text>& p_);

Text sname_text(const crate::syntax::SName& n);

Text sexp_module(const crate::syntax::Module& m);

Text sexp_row(const crate::syntax::Row_& r);

Text sexp_row_term(const crate::syntax::RowTerm& row_term0);

Text sexp_decl(const crate::syntax::decls::Decl& d, const Nat& depth);

Text opt_type(const std::optional<crate::syntax::Type>& opt0);

Text check_pattern(const std::optional<crate::syntax::Pattern_>& opt0, const Nat& n1);

Text sexp_type_body(const std::optional<crate::syntax::decls::TypeBody>& opt0, const Nat& n1);

Text sexp_signature(const crate::syntax::decls::Signature& s);

Text sexp_def_name(const crate::syntax::decls::DefName& def_name0);

Text sexp_bounds(const Array<crate::syntax::decls::Bound>& bs);

Text sexp_fn(const crate::syntax::decls::FnClause& f, const Nat& depth);

Text sexp_fields(const Array<crate::syntax::decls::Field>& fs, const Nat& depth);

Text sexp_case(const crate::syntax::decls::Case_& c);

Text sexp_items(const Array<crate::syntax::decls::TraitItem>& items, const Nat& depth);

Text sexp_item(const crate::syntax::decls::TraitItem& trait_item0, const Nat& n1);

Text sexp_test(const crate::syntax::decls::TestDecl& t, const Nat& depth);

Text sexp_step(const crate::syntax::decls::TestStep& s, const Nat& d);

Text sexp_action(const crate::syntax::decls::StepAction& step_action0, const Nat& n1);

Text sexp_delivery(const crate::syntax::decls::Delivery& x, const Nat& d);

Text sexp_target(const crate::syntax::decls::Target& target0, const Nat& d);

Text sexp_path(const Text& word, const crate::syntax::decls::TestPath& p_, const Nat& d);

Text sexp_path_seg(const crate::syntax::decls::PathSeg& path_seg0, const Nat& n1);

Text sexp_check(const crate::syntax::decls::TestCheck& c, const Nat& d);

Text sexp_block(const crate::syntax::Block& b, const Nat& d);

Text sexp_stmt(const crate::syntax::Stmt& s, const Nat& d);

Text sexp_cond(const crate::syntax::Cond& cond0, const Nat& d);

Text sexp_guard(const std::optional<crate::syntax::Expr>& opt0, const Nat& n1);

Text sexp_literal(const crate::syntax::Literal& l, const Nat& d);

bool all_plain_segs(const Array<crate::syntax::TextSeg>& segs);

bool is_plain_text_seg(const crate::syntax::TextSeg& text_seg0);

Text plain_seg_text(const crate::syntax::TextSeg& text_seg0);

Text sexp_seg(const crate::syntax::TextSeg& text_seg0, const Nat& n1);

Text sexp_args(const Array<crate::syntax::Arg>& args, const Nat& d);

Text arg_name(const std::optional<crate::syntax::Ident>& opt0);

Text sexp_exprs(const Array<crate::syntax::Expr>& es, const Nat& d);

Text sexp_expr(const crate::syntax::Expr& e, const Nat& d);

Text sexp_lambda_params(const std::optional<Array<crate::syntax::Pattern_>>& opt0, const Nat& n1);

Text sexp_lambda_body(const crate::syntax::LambdaBody& lambda_body0, const Nat& d);

Text sexp_else(const std::optional<crate::syntax::Block>& opt0, const Nat& n1);

Text sexp_arm(const crate::syntax::Arm& a, const Nat& d);

Text sexp_binders(const std::optional<crate::syntax::ForBinders>& opt0, const Nat& n1);

Text sexp_template(const crate::syntax::Template& t, const Nat& d);

Text sexp_parts(const Array<crate::syntax::TemplatePart>& parts, const Nat& d);

Text sexp_part(const crate::syntax::TemplatePart& template_part0, const Nat& n1);

Text column_text(const std::optional<Nat>& opt0);

Text call_parts(const std::optional<Array<crate::syntax::TemplatePart>>& opt0, const Nat& n1);

Text sexp_pattern(const crate::syntax::Pattern_& p_, const Nat& d);

Text sexp_type(const crate::syntax::Type& t);

Text color_text(const crate::syntax::Color& color0);

}  // namespace syntax::sexp



}  // namespace crate
