// The module `Syntax.Sexp`: its records, tags and newtypes (each after the types it holds) and its
// choices' cases, emitted by prismc (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <syntax/sexp/decl.hpp>
#include "elem.decl.hpp"
#include <syntax/decl.hpp>
#include <syntax/lexer/decl.hpp>

namespace crate {

using namespace prelude;



}  // namespace crate
