// The module `Syntax`: its types, nodes and jobs declared, and its choices' handles, emitted by
// prismc (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace syntax {

struct Arg;

struct Arm;

struct Block;

class Color;

class Cond;

struct Diag;

struct Expr;

class ExprKind;

struct FieldPat;

struct ForBinders;

struct Ident;

class LambdaBody;

class LitKind;

struct Literal;

struct ModLine;

struct Module;

struct Pattern_;

class PatternKind;

struct QualName;

struct Range;

struct Row_;

class RowTerm;

struct SName;

struct Stmt;

class StmtKind;

struct Template;

class TemplatePart;

class TextSeg;

struct TraitRef;

struct Type;

class TypeKind;

struct Use;

}  // namespace syntax

namespace syntax {

/// `Color`:
///
/// ```prism
/// type Color = choice:
/// ```
class Color {
public:
    using prism_value = void;
    struct Bounded;
    struct Unbounded;
    struct ColorVar;
    using Cases = std::variant<Bounded, Unbounded, ColorVar>;
    template <class C>
        requires prism_rtl::one_of<C, Bounded, Unbounded, ColorVar>
    Color(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Color> from_pod(const Pod& whole);
    friend inline bool operator==(const Color& a, const Color& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


/// `Cond`:
///
/// ```prism
/// type Cond = choice:
/// ```
class Cond {
public:
    using prism_value = void;
    struct CondExpr;
    struct CondBind;
    using Cases = std::variant<CondExpr, CondBind>;
    template <class C>
        requires prism_rtl::one_of<C, CondExpr, CondBind>
    Cond(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Cond> from_pod(const Pod& whole);
    friend inline bool operator==(const Cond& a, const Cond& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


/// `ExprKind`:
///
/// ```prism
/// type ExprKind = choice:
/// ```
class ExprKind {
public:
    using prism_value = void;
    struct EName;
    struct ELit;
    struct EUnit;
    struct ENil;
    struct EBound;
    struct ETuple;
    struct EArray;
    struct EMap;
    struct EGroup;
    struct ECall;
    struct EBinary;
    struct EUnary;
    struct ESuffixed;
    struct EFreeSigil;
    struct EField;
    struct EIndex;
    struct ETopicField;
    struct ETopicIndex;
    struct EMethod;
    struct ETypeArgs;
    struct ECast;
    struct ENonEmpty;
    struct EAbsent;
    struct ERest;
    struct ELambda;
    struct EIf;
    struct EMatch;
    struct ERebuild;
    struct EFor;
    struct EGiven;
    struct EUpdate;
    struct EWidgetBlock;
    struct EMonad;
    struct ETemplate;
    struct EAny;
    struct ELens;
    struct EError;
    using Cases = std::variant<EName, ELit, EUnit, ENil, EBound, ETuple, EArray, EMap, EGroup, ECall, EBinary, EUnary, ESuffixed, EFreeSigil, EField, EIndex, ETopicField, ETopicIndex, EMethod, ETypeArgs, ECast, ENonEmpty, EAbsent, ERest, ELambda, EIf, EMatch, ERebuild, EFor, EGiven, EUpdate, EWidgetBlock, EMonad, ETemplate, EAny, ELens, EError>;
    template <class C>
        requires prism_rtl::one_of<C, EName, ELit, EUnit, ENil, EBound, ETuple, EArray, EMap, EGroup, ECall, EBinary, EUnary, ESuffixed, EFreeSigil, EField, EIndex, ETopicField, ETopicIndex, EMethod, ETypeArgs, ECast, ENonEmpty, EAbsent, ERest, ELambda, EIf, EMatch, ERebuild, EFor, EGiven, EUpdate, EWidgetBlock, EMonad, ETemplate, EAny, ELens, EError>
    ExprKind(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<ExprKind> from_pod(const Pod& whole);
    friend inline bool operator==(const ExprKind& a, const ExprKind& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


/// `LambdaBody`:
///
/// ```prism
/// type LambdaBody = choice:
/// ```
class LambdaBody {
public:
    using prism_value = void;
    struct LbExpr;
    struct LbBlock;
    using Cases = std::variant<LbExpr, LbBlock>;
    template <class C>
        requires prism_rtl::one_of<C, LbExpr, LbBlock>
    LambdaBody(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<LambdaBody> from_pod(const Pod& whole);
    friend inline bool operator==(const LambdaBody& a, const LambdaBody& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


/// `LitKind`:
///
/// ```prism
/// type LitKind = choice:
/// ```
class LitKind {
public:
    using prism_value = void;
    struct LInt;
    struct LFloat;
    struct LDuration;
    struct LChar;
    struct LText;
    using Cases = std::variant<LInt, LFloat, LDuration, LChar, LText>;
    template <class C>
        requires prism_rtl::one_of<C, LInt, LFloat, LDuration, LChar, LText>
    LitKind(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<LitKind> from_pod(const Pod& whole);
    friend inline bool operator==(const LitKind& a, const LitKind& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


/// `PatternKind`:
///
/// ```prism
/// type PatternKind = choice:
/// ```
class PatternKind {
public:
    using prism_value = void;
    struct PName;
    struct PIgnore;
    struct PLit;
    struct PNeg;
    struct PUnit;
    struct PNil;
    struct PCtor;
    struct PRecord;
    struct PSigil;
    struct PTuple;
    struct PArray;
    struct PGroup;
    struct PFamily;
    using Cases = std::variant<PName, PIgnore, PLit, PNeg, PUnit, PNil, PCtor, PRecord, PSigil, PTuple, PArray, PGroup, PFamily>;
    template <class C>
        requires prism_rtl::one_of<C, PName, PIgnore, PLit, PNeg, PUnit, PNil, PCtor, PRecord, PSigil, PTuple, PArray, PGroup, PFamily>
    PatternKind(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<PatternKind> from_pod(const Pod& whole);
    friend inline bool operator==(const PatternKind& a, const PatternKind& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


/// `RowTerm`:
///
/// ```prism
/// type RowTerm = choice:
/// ```
class RowTerm {
public:
    using prism_value = void;
    struct RFamily;
    struct RType;
    struct RVar;
    using Cases = std::variant<RFamily, RType, RVar>;
    template <class C>
        requires prism_rtl::one_of<C, RFamily, RType, RVar>
    RowTerm(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<RowTerm> from_pod(const Pod& whole);
    friend inline bool operator==(const RowTerm& a, const RowTerm& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


/// `StmtKind`:
///
/// ```prism
/// type StmtKind = choice:
/// ```
class StmtKind {
public:
    using prism_value = void;
    struct SEmit;
    struct SBind;
    struct SIgnore;
    struct SLet;
    struct SSignature;
    struct SFn;
    struct SWidget;
    struct SSet;
    struct SAccum;
    struct SRequire;
    struct SForbid;
    struct SWhile;
    struct SReturn;
    struct SExpr;
    using Cases = std::variant<SEmit, SBind, SIgnore, SLet, SSignature, SFn, SWidget, SSet, SAccum, SRequire, SForbid, SWhile, SReturn, SExpr>;
    template <class C>
        requires prism_rtl::one_of<C, SEmit, SBind, SIgnore, SLet, SSignature, SFn, SWidget, SSet, SAccum, SRequire, SForbid, SWhile, SReturn, SExpr>
    StmtKind(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<StmtKind> from_pod(const Pod& whole);
    friend inline bool operator==(const StmtKind& a, const StmtKind& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


/// `TemplatePart`:
///
/// ```prism
/// type TemplatePart = choice:
/// ```
class TemplatePart {
public:
    using prism_value = void;
    struct TpText;
    struct TpPlaceholder;
    struct TpBlock;
    struct TpCall;
    using Cases = std::variant<TpText, TpPlaceholder, TpBlock, TpCall>;
    template <class C>
        requires prism_rtl::one_of<C, TpText, TpPlaceholder, TpBlock, TpCall>
    TemplatePart(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<TemplatePart> from_pod(const Pod& whole);
    friend inline bool operator==(const TemplatePart& a, const TemplatePart& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


/// `TextSeg`:
///
/// ```prism
/// type TextSeg = choice:
/// ```
class TextSeg {
public:
    using prism_value = void;
    struct SegPlain;
    struct SegPlaceholder;
    using Cases = std::variant<SegPlain, SegPlaceholder>;
    template <class C>
        requires prism_rtl::one_of<C, SegPlain, SegPlaceholder>
    TextSeg(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<TextSeg> from_pod(const Pod& whole);
    friend inline bool operator==(const TextSeg& a, const TextSeg& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


/// `TypeKind`:
///
/// ```prism
/// type TypeKind = choice:
/// ```
class TypeKind {
public:
    using prism_value = void;
    struct TName;
    struct TSigiled;
    struct TArray;
    struct TTuple;
    struct TGroup;
    struct TMap;
    struct TFn;
    struct TEmit;
    struct TRowUnion;
    struct TFamily;
    struct TAny;
    struct TUnit;
    struct THole;
    struct TAbsent;
    struct TNonEmpty;
    using Cases = std::variant<TName, TSigiled, TArray, TTuple, TGroup, TMap, TFn, TEmit, TRowUnion, TFamily, TAny, TUnit, THole, TAbsent, TNonEmpty>;
    template <class C>
        requires prism_rtl::one_of<C, TName, TSigiled, TArray, TTuple, TGroup, TMap, TFn, TEmit, TRowUnion, TFamily, TAny, TUnit, THole, TAbsent, TNonEmpty>
    TypeKind(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<TypeKind> from_pod(const Pod& whole);
    friend inline bool operator==(const TypeKind& a, const TypeKind& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


}  // namespace syntax

}  // namespace crate
