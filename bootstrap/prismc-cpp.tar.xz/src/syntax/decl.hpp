// The module `Syntax`: its types, nodes and jobs declared, emitted by prismc (claude/backend.md).
// Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace syntax {

struct Arg;

struct Arm;

struct Block;

class Color;

class Cond;

struct Diag;

struct Expr;

class ExprKind;

struct FieldPat;

struct ForBinders;

struct Ident;

class LambdaBody;

class LitKind;

struct Literal;

struct ModLine;

struct Module;

struct Pattern_;

class PatternKind;

struct QualName;

struct Range;

struct RegexLit;

struct Row_;

class RowTerm;

struct SName;

struct Stmt;

class StmtKind;

struct Template;

class TemplatePart;

class TextSeg;

struct TraitRef;

struct Type;

class TypeKind;

struct Use;

}  // namespace syntax

}  // namespace crate
