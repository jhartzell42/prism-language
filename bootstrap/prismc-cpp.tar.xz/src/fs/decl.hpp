// The module `Fs`: its types, nodes and jobs declared, emitted by prismc (claude/backend.md).
// Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace fs {

struct Contents;

class FileRequest;

class WriteState;

struct FsContents;

struct FsFile;

struct FsList_;

struct FsOutput;

}  // namespace fs

}  // namespace crate
