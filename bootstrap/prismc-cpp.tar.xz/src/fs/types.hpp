// The module `Fs`: its value types (records, tags, newtypes and choices with their cases), each
// after the types it holds by value, emitted by prismc (claude/backend.md). Edit the Prism
// source, not this file.
#pragma once

#include <fs/decl.hpp>
#include "elem.decl.hpp"

namespace crate {

using namespace prelude;

namespace fs {

/// `Contents`:
///
/// ```prism
/// type Contents = record:
/// ```
struct Contents {
    using prism_value = void;
    Text text;
    const Contents* operator->() const { return this; }
    Contents* operator->() { return this; }
    bool operator==(const Contents&) const = default;
    auto operator<=>(const Contents&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Contents> from_pod(const Pod& whole);
};


}  // namespace fs

namespace fs {

/// `FileRequest`:
///
/// ```prism
/// type FileRequest = choice:
/// ```
class FileRequest {
public:
    using prism_value = void;
    struct Read {
        bool operator==(const Read&) const = default;
    };

    struct Write {
        Text a0;
        bool operator==(const Write&) const = default;
    };
    using Cases = std::variant<Read, Write>;
    template <class C>
        requires prism_rtl::one_of<C, Read, Write>
    FileRequest(C c) : cases_(std::move(c)) {}
    const Cases& cases() const { return cases_; }
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<FileRequest> from_pod(const Pod& whole);

private:
    Cases cases_;
};

inline bool operator==(const FileRequest& a, const FileRequest& b) { return a.cases() == b.cases(); }

}  // namespace fs

namespace fs {

/// `WriteState`:
///
/// ```prism
/// type WriteState = choice:
/// ```
class WriteState {
public:
    using prism_value = void;
    struct Writing {
        bool operator==(const Writing&) const = default;
    };

    struct Written {
        bool operator==(const Written&) const = default;
    };

    struct WriteFailed {
        Error a0;
        bool operator==(const WriteFailed&) const = default;
    };
    using Cases = std::variant<Writing, Written, WriteFailed>;
    template <class C>
        requires prism_rtl::one_of<C, Writing, Written, WriteFailed>
    WriteState(C c) : cases_(std::move(c)) {}
    const Cases& cases() const { return cases_; }
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<WriteState> from_pod(const Pod& whole);

private:
    Cases cases_;
};

inline bool operator==(const WriteState& a, const WriteState& b) { return a.cases() == b.cases(); }

}  // namespace fs

namespace fs {

/// The `Level` of `Fs.Contents`:
///
/// ```prism
/// tag Fs.Contents of Element $~Contents:
/// ```
struct FsContents {
    using prism_value = void;
    /// The tag's qualified name, as its `Pod` carries it.
    static constexpr const char* TAG = "Fs.Contents";
    Text path_;
    const FsContents* operator->() const { return this; }
    FsContents* operator->() { return this; }
    Pod to_pod() const;
    void show(Printer& p) const;
    bool operator==(const FsContents&) const = default;
    static Result<FsContents> from_pod(const Pod& p);
};


}  // namespace fs

namespace fs {

/// The `Level` of `Fs.File`:
///
/// ```prism
/// tag Fs.File of Element !~Contents:
/// ```
struct FsFile {
    using prism_value = void;
    /// The tag's qualified name, as its `Pod` carries it.
    static constexpr const char* TAG = "Fs.File";
    Text path_;
    const FsFile* operator->() const { return this; }
    FsFile* operator->() { return this; }
    Pod to_pod() const;
    void show(Printer& p) const;
    bool operator==(const FsFile&) const = default;
    static Result<FsFile> from_pod(const Pod& p);
};


}  // namespace fs

namespace fs {

/// The `Level` of `Fs.List`:
///
/// ```prism
/// tag Fs.List of Element $[Text]:
/// ```
struct FsList_ {
    using prism_value = void;
    /// The tag's qualified name, as its `Pod` carries it.
    static constexpr const char* TAG = "Fs.List";
    Text dir;
    const FsList_* operator->() const { return this; }
    FsList_* operator->() { return this; }
    Pod to_pod() const;
    void show(Printer& p) const;
    bool operator==(const FsList_&) const = default;
    static Result<FsList_> from_pod(const Pod& p);
};


}  // namespace fs

namespace fs {

/// The `Level` of `Fs.Output`:
///
/// ```prism
/// tag Fs.Output of Element $WriteState:
/// ```
struct FsOutput {
    using prism_value = void;
    /// The tag's qualified name, as its `Pod` carries it.
    static constexpr const char* TAG = "Fs.Output";
    Text path_;
    Text text;
    const FsOutput* operator->() const { return this; }
    FsOutput* operator->() { return this; }
    Pod to_pod() const;
    void show(Printer& p) const;
    bool operator==(const FsOutput&) const = default;
    static Result<FsOutput> from_pod(const Pod& p);
};


}  // namespace fs

}  // namespace crate
