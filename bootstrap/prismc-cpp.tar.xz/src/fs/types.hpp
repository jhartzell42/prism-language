// The module `Fs`: its records, tags and newtypes (each after the types it holds) and its
// choices' cases, emitted by prismc (docs/backend.md). Edit the Prism source, not this file.
#pragma once

#include <fs/decl.hpp>
#include "elem.decl.hpp"

namespace crate {

using namespace prelude;

namespace fs {

/// `Contents`:
///
/// ```prism
/// type Contents = record:
/// ```
struct Contents {
    using prism_value = void;
    Text text;
    const Contents* operator->() const { return this; }
    Contents* operator->() { return this; }
    bool operator==(const Contents&) const = default;
    auto operator<=>(const Contents&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Contents> from_pod(const Pod& whole);
};


}  // namespace fs

namespace fs {

/// The `Level` of `Fs.Contents`:
///
/// ```prism
/// tag Fs.Contents of Element $~Contents:
/// ```
struct FsContents {
    using prism_value = void;
    /// The tag's qualified name, as its `Pod` carries it.
    static constexpr const char* TAG = "Fs.Contents";
    Text path_;
    const FsContents* operator->() const { return this; }
    FsContents* operator->() { return this; }
    Pod to_pod() const;
    void show(Printer& p) const;
    bool operator==(const FsContents&) const = default;
    static Result<FsContents> from_pod(const Pod& p);
};


}  // namespace fs

namespace fs {

/// The `Level` of `Fs.File`:
///
/// ```prism
/// tag Fs.File of Element !~Contents:
/// ```
struct FsFile {
    using prism_value = void;
    /// The tag's qualified name, as its `Pod` carries it.
    static constexpr const char* TAG = "Fs.File";
    Text path_;
    const FsFile* operator->() const { return this; }
    FsFile* operator->() { return this; }
    Pod to_pod() const;
    void show(Printer& p) const;
    bool operator==(const FsFile&) const = default;
    static Result<FsFile> from_pod(const Pod& p);
};


}  // namespace fs

namespace fs {

/// The `Level` of `Fs.List`:
///
/// ```prism
/// tag Fs.List of Element $[Text]:
/// ```
struct FsList_ {
    using prism_value = void;
    /// The tag's qualified name, as its `Pod` carries it.
    static constexpr const char* TAG = "Fs.List";
    Text dir;
    const FsList_* operator->() const { return this; }
    FsList_* operator->() { return this; }
    Pod to_pod() const;
    void show(Printer& p) const;
    bool operator==(const FsList_&) const = default;
    static Result<FsList_> from_pod(const Pod& p);
};


}  // namespace fs

namespace fs {

/// The `Level` of `Fs.Output`:
///
/// ```prism
/// tag Fs.Output of Element $WriteState:
/// ```
struct FsOutput {
    using prism_value = void;
    /// The tag's qualified name, as its `Pod` carries it.
    static constexpr const char* TAG = "Fs.Output";
    Text path_;
    Text text;
    const FsOutput* operator->() const { return this; }
    FsOutput* operator->() { return this; }
    Pod to_pod() const;
    void show(Printer& p) const;
    bool operator==(const FsOutput&) const = default;
    static Result<FsOutput> from_pod(const Pod& p);
};


}  // namespace fs

namespace fs {

struct FileRequest::Read {
    bool operator==(const Read&) const = default;
};


struct FileRequest::Write {
    Text a0;
    bool operator==(const Write&) const = default;
};


inline const FileRequest::Cases& FileRequest::cases() const { return *cases_; }

inline bool operator==(const FileRequest& a, const FileRequest& b) { return a.cases() == b.cases(); }

struct WriteState::Writing {
    bool operator==(const Writing&) const = default;
};


struct WriteState::Written {
    bool operator==(const Written&) const = default;
};


struct WriteState::WriteFailed {
    Error a0;
    bool operator==(const WriteFailed&) const = default;
};


inline const WriteState::Cases& WriteState::cases() const { return *cases_; }

inline bool operator==(const WriteState& a, const WriteState& b) { return a.cases() == b.cases(); }

}  // namespace fs

}  // namespace crate
