// The module `Ast`: its types, nodes and jobs declared, and its choices' handles, emitted by
// prismc (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace ast {

struct Arg;

struct Arm;

struct Block;

struct Bound;

struct Case_;

struct CheckDecl;

struct CheckLine;

class Color;

class Cond;

struct Decl;

class DeclKind;

class DefName;

struct Delivery;

class DeliveryKind;

struct Diag;

struct Entry;

struct Expr;

class ExprKind;

struct Field;

struct FieldPat;

class FnBody;

struct FnClause;

struct ForBinders;

struct Ident;

struct ImplDecl;

class LambdaBody;

struct LetDecl;

class LitKind;

struct Literal;

struct Module;

class PathSeg;

struct Pattern_;

class PatternKind;

struct QualName;

struct Range;

struct Row_;

class RowTerm;

struct SName;

struct Signature;

class StepAction;

struct Stmt;

class StmtKind;

struct TagDecl;

class Target;

struct Template;

class TemplatePart;

struct TestCheck;

class TestCheckKind;

struct TestDecl;

struct TestPath;

struct TestStep;

class TextSeg;

struct TraitDecl;

class TraitItem;

struct TraitRef;

struct Type;

class TypeBody;

struct TypeDecl;

class TypeKind;

struct Use;

struct WidgetDecl;

}  // namespace ast

namespace ast {

/// `Color`:
///
/// ```prism
/// type Color = choice:
/// ```
class Color {
public:
    using prism_value = void;
    struct Bounded;
    struct Unbounded;
    struct ColorVar;
    using Cases = std::variant<Bounded, Unbounded, ColorVar>;
    template <class C>
        requires prism_rtl::one_of<C, Bounded, Unbounded, ColorVar>
    Color(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Color> from_pod(const Pod& whole);
    friend inline bool operator==(const Color& a, const Color& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


/// `Cond`:
///
/// ```prism
/// type Cond = choice:
/// ```
class Cond {
public:
    using prism_value = void;
    struct CondExpr;
    struct CondBind;
    using Cases = std::variant<CondExpr, CondBind>;
    template <class C>
        requires prism_rtl::one_of<C, CondExpr, CondBind>
    Cond(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Cond> from_pod(const Pod& whole);
    friend inline bool operator==(const Cond& a, const Cond& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


/// `DeclKind`:
///
/// ```prism
/// type DeclKind = choice:
/// ```
class DeclKind {
public:
    using prism_value = void;
    struct DSignature;
    struct DFn;
    struct DLet;
    struct DWidget;
    struct DType;
    struct DTag;
    struct DDerive;
    struct DTrait;
    struct DImpl;
    struct DCheck;
    struct DTest;
    struct DStmt;
    using Cases = std::variant<DSignature, DFn, DLet, DWidget, DType, DTag, DDerive, DTrait, DImpl, DCheck, DTest, DStmt>;
    template <class C>
        requires prism_rtl::one_of<C, DSignature, DFn, DLet, DWidget, DType, DTag, DDerive, DTrait, DImpl, DCheck, DTest, DStmt>
    DeclKind(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<DeclKind> from_pod(const Pod& whole);
    friend inline bool operator==(const DeclKind& a, const DeclKind& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


/// `DefName`:
///
/// ```prism
/// type DefName = choice:
/// ```
class DefName {
public:
    using prism_value = void;
    struct DefSName;
    struct DefOp;
    using Cases = std::variant<DefSName, DefOp>;
    template <class C>
        requires prism_rtl::one_of<C, DefSName, DefOp>
    DefName(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<DefName> from_pod(const Pod& whole);
    friend inline bool operator==(const DefName& a, const DefName& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


/// `DeliveryKind`:
///
/// ```prism
/// type DeliveryKind = choice:
/// ```
class DeliveryKind {
public:
    using prism_value = void;
    struct DkSend;
    struct DkClick;
    struct DkAnswer;
    using Cases = std::variant<DkSend, DkClick, DkAnswer>;
    template <class C>
        requires prism_rtl::one_of<C, DkSend, DkClick, DkAnswer>
    DeliveryKind(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<DeliveryKind> from_pod(const Pod& whole);
    friend inline bool operator==(const DeliveryKind& a, const DeliveryKind& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


/// `ExprKind`:
///
/// ```prism
/// type ExprKind = choice:
/// ```
class ExprKind {
public:
    using prism_value = void;
    struct EName;
    struct ELit;
    struct EUnit;
    struct ENil;
    struct EBound;
    struct ETuple;
    struct EArray;
    struct EMap;
    struct EGroup;
    struct ECall;
    struct EBinary;
    struct EUnary;
    struct ESuffixed;
    struct EFreeSigil;
    struct EField;
    struct EIndex;
    struct ETopicField;
    struct ETopicIndex;
    struct EMethod;
    struct ETypeArgs;
    struct ECast;
    struct ENonEmpty;
    struct EAbsent;
    struct ERest;
    struct ELambda;
    struct EIf;
    struct EMatch;
    struct ERebuild;
    struct EFor;
    struct EGiven;
    struct EUpdate;
    struct EWidgetBlock;
    struct EMonad;
    struct ETemplate;
    struct EAny;
    struct ELens;
    struct EError;
    using Cases = std::variant<EName, ELit, EUnit, ENil, EBound, ETuple, EArray, EMap, EGroup, ECall, EBinary, EUnary, ESuffixed, EFreeSigil, EField, EIndex, ETopicField, ETopicIndex, EMethod, ETypeArgs, ECast, ENonEmpty, EAbsent, ERest, ELambda, EIf, EMatch, ERebuild, EFor, EGiven, EUpdate, EWidgetBlock, EMonad, ETemplate, EAny, ELens, EError>;
    template <class C>
        requires prism_rtl::one_of<C, EName, ELit, EUnit, ENil, EBound, ETuple, EArray, EMap, EGroup, ECall, EBinary, EUnary, ESuffixed, EFreeSigil, EField, EIndex, ETopicField, ETopicIndex, EMethod, ETypeArgs, ECast, ENonEmpty, EAbsent, ERest, ELambda, EIf, EMatch, ERebuild, EFor, EGiven, EUpdate, EWidgetBlock, EMonad, ETemplate, EAny, ELens, EError>
    ExprKind(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<ExprKind> from_pod(const Pod& whole);
    friend inline bool operator==(const ExprKind& a, const ExprKind& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


/// `FnBody`:
///
/// ```prism
/// type FnBody = choice:
/// ```
class FnBody {
public:
    using prism_value = void;
    struct BodyExpr;
    struct BodyBlock;
    using Cases = std::variant<BodyExpr, BodyBlock>;
    template <class C>
        requires prism_rtl::one_of<C, BodyExpr, BodyBlock>
    FnBody(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<FnBody> from_pod(const Pod& whole);
    friend inline bool operator==(const FnBody& a, const FnBody& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


/// `LambdaBody`:
///
/// ```prism
/// type LambdaBody = choice:
/// ```
class LambdaBody {
public:
    using prism_value = void;
    struct LbExpr;
    struct LbBlock;
    using Cases = std::variant<LbExpr, LbBlock>;
    template <class C>
        requires prism_rtl::one_of<C, LbExpr, LbBlock>
    LambdaBody(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<LambdaBody> from_pod(const Pod& whole);
    friend inline bool operator==(const LambdaBody& a, const LambdaBody& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


/// `LitKind`:
///
/// ```prism
/// type LitKind = choice:
/// ```
class LitKind {
public:
    using prism_value = void;
    struct LInt;
    struct LFloat;
    struct LDuration;
    struct LChar;
    struct LText;
    using Cases = std::variant<LInt, LFloat, LDuration, LChar, LText>;
    template <class C>
        requires prism_rtl::one_of<C, LInt, LFloat, LDuration, LChar, LText>
    LitKind(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<LitKind> from_pod(const Pod& whole);
    friend inline bool operator==(const LitKind& a, const LitKind& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


/// `PathSeg`:
///
/// ```prism
/// type PathSeg = choice:
/// ```
class PathSeg {
public:
    using prism_value = void;
    struct PsNum;
    struct PsGen;
    struct PsKey;
    using Cases = std::variant<PsNum, PsGen, PsKey>;
    template <class C>
        requires prism_rtl::one_of<C, PsNum, PsGen, PsKey>
    PathSeg(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<PathSeg> from_pod(const Pod& whole);
    friend inline bool operator==(const PathSeg& a, const PathSeg& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


/// `PatternKind`:
///
/// ```prism
/// type PatternKind = choice:
/// ```
class PatternKind {
public:
    using prism_value = void;
    struct PName;
    struct PIgnore;
    struct PLit;
    struct PNeg;
    struct PUnit;
    struct PNil;
    struct PCtor;
    struct PRecord;
    struct PSigil;
    struct PTuple;
    struct PArray;
    struct PGroup;
    struct PFamily;
    using Cases = std::variant<PName, PIgnore, PLit, PNeg, PUnit, PNil, PCtor, PRecord, PSigil, PTuple, PArray, PGroup, PFamily>;
    template <class C>
        requires prism_rtl::one_of<C, PName, PIgnore, PLit, PNeg, PUnit, PNil, PCtor, PRecord, PSigil, PTuple, PArray, PGroup, PFamily>
    PatternKind(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<PatternKind> from_pod(const Pod& whole);
    friend inline bool operator==(const PatternKind& a, const PatternKind& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


/// `RowTerm`:
///
/// ```prism
/// type RowTerm = choice:
/// ```
class RowTerm {
public:
    using prism_value = void;
    struct RFamily;
    struct RType;
    struct RVar;
    using Cases = std::variant<RFamily, RType, RVar>;
    template <class C>
        requires prism_rtl::one_of<C, RFamily, RType, RVar>
    RowTerm(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<RowTerm> from_pod(const Pod& whole);
    friend inline bool operator==(const RowTerm& a, const RowTerm& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


/// `StepAction`:
///
/// ```prism
/// type StepAction = choice:
/// ```
class StepAction {
public:
    using prism_value = void;
    struct SaBuild;
    struct SaTick;
    struct SaCompute;
    struct SaPush;
    struct SaDeliver;
    struct SaWithOnly;
    using Cases = std::variant<SaBuild, SaTick, SaCompute, SaPush, SaDeliver, SaWithOnly>;
    template <class C>
        requires prism_rtl::one_of<C, SaBuild, SaTick, SaCompute, SaPush, SaDeliver, SaWithOnly>
    StepAction(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<StepAction> from_pod(const Pod& whole);
    friend inline bool operator==(const StepAction& a, const StepAction& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


/// `StmtKind`:
///
/// ```prism
/// type StmtKind = choice:
/// ```
class StmtKind {
public:
    using prism_value = void;
    struct SEmit;
    struct SBind;
    struct SIgnore;
    struct SLet;
    struct SSignature;
    struct SFn;
    struct SWidget;
    struct SSet;
    struct SAccum;
    struct SRequire;
    struct SForbid;
    struct SWhile;
    struct SReturn;
    struct SExpr;
    using Cases = std::variant<SEmit, SBind, SIgnore, SLet, SSignature, SFn, SWidget, SSet, SAccum, SRequire, SForbid, SWhile, SReturn, SExpr>;
    template <class C>
        requires prism_rtl::one_of<C, SEmit, SBind, SIgnore, SLet, SSignature, SFn, SWidget, SSet, SAccum, SRequire, SForbid, SWhile, SReturn, SExpr>
    StmtKind(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<StmtKind> from_pod(const Pod& whole);
    friend inline bool operator==(const StmtKind& a, const StmtKind& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


/// `Target`:
///
/// ```prism
/// type Target = choice:
/// ```
class Target {
public:
    using prism_value = void;
    struct TgPattern;
    struct TgPath;
    struct TgElement;
    using Cases = std::variant<TgPattern, TgPath, TgElement>;
    template <class C>
        requires prism_rtl::one_of<C, TgPattern, TgPath, TgElement>
    Target(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Target> from_pod(const Pod& whole);
    friend inline bool operator==(const Target& a, const Target& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


/// `TemplatePart`:
///
/// ```prism
/// type TemplatePart = choice:
/// ```
class TemplatePart {
public:
    using prism_value = void;
    struct TpText;
    struct TpPlaceholder;
    struct TpBlock;
    struct TpCall;
    using Cases = std::variant<TpText, TpPlaceholder, TpBlock, TpCall>;
    template <class C>
        requires prism_rtl::one_of<C, TpText, TpPlaceholder, TpBlock, TpCall>
    TemplatePart(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<TemplatePart> from_pod(const Pod& whole);
    friend inline bool operator==(const TemplatePart& a, const TemplatePart& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


/// `TestCheckKind`:
///
/// ```prism
/// type TestCheckKind = choice:
/// ```
class TestCheckKind {
public:
    using prism_value = void;
    struct CkExpect;
    struct CkExpectNone;
    struct CkExpectCount;
    struct CkExpectTop;
    struct CkExpectTopNone;
    struct CkRequested;
    struct CkUnrequested;
    struct CkReturns;
    struct CkFired;
    struct CkQuiet;
    struct CkSettles;
    struct CkAborted;
    struct CkSnapshot;
    using Cases = std::variant<CkExpect, CkExpectNone, CkExpectCount, CkExpectTop, CkExpectTopNone, CkRequested, CkUnrequested, CkReturns, CkFired, CkQuiet, CkSettles, CkAborted, CkSnapshot>;
    template <class C>
        requires prism_rtl::one_of<C, CkExpect, CkExpectNone, CkExpectCount, CkExpectTop, CkExpectTopNone, CkRequested, CkUnrequested, CkReturns, CkFired, CkQuiet, CkSettles, CkAborted, CkSnapshot>
    TestCheckKind(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<TestCheckKind> from_pod(const Pod& whole);
    friend inline bool operator==(const TestCheckKind& a, const TestCheckKind& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


/// `TextSeg`:
///
/// ```prism
/// type TextSeg = choice:
/// ```
class TextSeg {
public:
    using prism_value = void;
    struct SegPlain;
    struct SegPlaceholder;
    using Cases = std::variant<SegPlain, SegPlaceholder>;
    template <class C>
        requires prism_rtl::one_of<C, SegPlain, SegPlaceholder>
    TextSeg(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<TextSeg> from_pod(const Pod& whole);
    friend inline bool operator==(const TextSeg& a, const TextSeg& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


/// `TraitItem`:
///
/// ```prism
/// type TraitItem = choice:
/// ```
class TraitItem {
public:
    using prism_value = void;
    struct TiSignature;
    struct TiFn;
    struct TiAssocType;
    struct TiAssocRow;
    using Cases = std::variant<TiSignature, TiFn, TiAssocType, TiAssocRow>;
    template <class C>
        requires prism_rtl::one_of<C, TiSignature, TiFn, TiAssocType, TiAssocRow>
    TraitItem(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<TraitItem> from_pod(const Pod& whole);
    friend inline bool operator==(const TraitItem& a, const TraitItem& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


/// `TypeBody`:
///
/// ```prism
/// type TypeBody = choice:
/// ```
class TypeBody {
public:
    using prism_value = void;
    struct TbRecord;
    struct TbChoice;
    struct TbRow;
    struct TbNewtype;
    struct TbUnit;
    struct TbAlias;
    using Cases = std::variant<TbRecord, TbChoice, TbRow, TbNewtype, TbUnit, TbAlias>;
    template <class C>
        requires prism_rtl::one_of<C, TbRecord, TbChoice, TbRow, TbNewtype, TbUnit, TbAlias>
    TypeBody(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<TypeBody> from_pod(const Pod& whole);
    friend inline bool operator==(const TypeBody& a, const TypeBody& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


/// `TypeKind`:
///
/// ```prism
/// type TypeKind = choice:
/// ```
class TypeKind {
public:
    using prism_value = void;
    struct TName;
    struct TSigiled;
    struct TArray;
    struct TTuple;
    struct TGroup;
    struct TMap;
    struct TFn;
    struct TEmit;
    struct TRowUnion;
    struct TFamily;
    struct TAny;
    struct TUnit;
    struct THole;
    struct TAbsent;
    struct TNonEmpty;
    using Cases = std::variant<TName, TSigiled, TArray, TTuple, TGroup, TMap, TFn, TEmit, TRowUnion, TFamily, TAny, TUnit, THole, TAbsent, TNonEmpty>;
    template <class C>
        requires prism_rtl::one_of<C, TName, TSigiled, TArray, TTuple, TGroup, TMap, TFn, TEmit, TRowUnion, TFamily, TAny, TUnit, THole, TAbsent, TNonEmpty>
    TypeKind(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<TypeKind> from_pod(const Pod& whole);
    friend inline bool operator==(const TypeKind& a, const TypeKind& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


}  // namespace ast

}  // namespace crate
