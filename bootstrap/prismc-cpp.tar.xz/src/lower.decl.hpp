// The module `Lower`: its types, nodes and jobs declared, and its choices' handles, emitted by
// prismc (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace lower {

struct AnswerCase;

struct AnswerDef;

class Bn;

struct CaseDef;

class Cc;

struct CheckDef;

struct ClauseRow;

class CxArg;

class Do;

struct Env;

struct EvRef;

class Ex;

struct FlatDef;

struct FnDef;

struct ForDef;

struct GenCase;

struct GenDef;

struct GenRow;

struct Gn;

class GnKind;

class Holding;

struct HostDef;

class HostForm;

class HowBound;

struct ImplDef;

class Item;

struct JobDef;

class Layer;

struct Lx;

struct MethDef;

struct ModDef;

struct Model;

struct NodeDef;

struct Out;

class OutTy;

class Pa;

struct PatOut;

struct PendingRow;

struct Place;

struct Pos_;

struct ProgDef;

class Read;

class Recv;

struct RowDef;

class RowKind;

struct RowLocal;

struct RowMarks;

class Shown;

struct Sinks;

class Sk;

struct SnapDef;

struct TagDef;

struct TraitDef;

struct TyDef;

class TyShape;

class Vl;

class Wres;

struct Wx;

struct XArm;

struct OutTyOf;

struct RustTyOfParams;

struct NamedTy;

struct Layouts;

struct Reaches;

struct Floaty;

struct Podable;

struct LiteralValue;

struct TextValue;

struct SegEx;

struct ValueOf;

struct UnboundValueOf;

struct IsEventValue;

struct HasEventSource;

struct IsEventSource;

struct EventValueOf;

struct ValueByKind;

struct PureBlueprint;

struct PlainBlueprint;

struct DynamicBlueprint;

struct ElementBlueprint;

struct NameValue;

struct GlobalValue;

struct Application;

struct InlineLocalFn;

struct Argument;

struct ArgumentByKind;

struct TagValue;

struct GlobalCall;

struct ArgsFor;

struct CtorApp;

struct CtorFn;

struct CtorArgs;

struct MethodCall;

struct PreludeMethod;

struct BinaryValue;

struct PreludeCall;

struct PreludeJob;

struct PreludeJobCall;

struct AsJobValue;

struct NamedArgsOwned;

struct StartArgs;

struct FieldValue;

struct FieldInfo;

struct Instantiated;

struct IndexValue;

struct ReadNames;

struct LambdaExprs;

struct LambdaValue;

struct PlainLambda;

struct LambdaParamTys;

struct IsKnownTy;

struct JobLambda;

struct LambdaArg;

struct LambdaBodyValue;

struct ClosureParams;

struct IfValue;

struct MatchValue;

struct ArmPat;

struct BlockValue;

struct BlockTy;

struct PlainBlockValue;

struct BlockStmt;

struct GenericLet;

struct Instantiations;

struct Expanded;

struct OpenQ;

struct OpenTyQs;

struct WidgetLetLx;

struct PlainLet;

struct RustPat;

struct WrapPat;

struct LitPat;

struct CtorPat;

struct SubPat;

struct BehindRc;

struct RecordPat;

struct FieldsPat;

struct TagPat;

struct LiveFieldPat;

struct FamilyPat;

struct ErrorPat;

struct ArrayPat;

struct TemplateValue;

struct TemplatePartDos;

struct TemplateArgs;

struct GivenValue;

struct UpdateValue;

struct UpdStmts;

struct UpdStmt;

struct UpdFor;

struct UpdForRefs;

struct UpdForValues;

struct UpdIf;

struct UpdMatch;

struct GuardConds;

struct PlaceOf;

struct Assign;

struct ClausesBody;

struct FnBodyValue;

struct FnDefOf;

struct LetGetter;

struct Tail;

struct TailHere;

struct TailBlock;

struct TailFrom;

struct UpdTail;

struct UpdTailFrom;

struct StmtJob;

struct WhileJob;

struct StmtsThen;

struct IfJob;

struct MatchJob;

struct ForJob;

struct FrameCall;

struct FirstFrame;

struct Frame;

struct LocalJobFn;

struct TailBody;

struct TailMatch;

struct JobFieldNames;

struct JobDefOf;

struct JobClauses;

struct IdPipe;

struct NodeDefOf;

struct BlockInto;

struct PreBind;

struct PreBindName;

struct ManyInstances;

struct WidgetStmt;

struct ResultOf;

struct ResultOfTyped;

struct HoldLine;

struct LetLine;

struct BuildLine;

struct ElementLine;

struct WidgetLine;

struct InlineBlock;

struct DynamicExpr;

struct EventRef;

struct FiringCode;

struct FinishNode;

struct FinishPending;

struct LowerProgram;

struct WithNeeds;

struct NamedMods;

struct WithGroups;

struct ReachedBy;

struct NeededMods;

struct ModRefs;

struct ProgDefOf;

struct JobRoots;

struct UnboundedValues;

struct RunTargets;

struct TailTargets;

struct TailsOfBody;

struct ModDefOf;

struct DefItems;

struct TyDefs;

struct TyPodable;

struct CaseField;

struct TagDefOf;

struct RowDefOf;

struct ElemRow;

struct AnswerEnum;

struct AnswerTy;

struct CheckDefOf;

struct ForLine;

struct RebuildLine;

struct SelfIn;

struct TraitDefOf;

struct ImplDefOf;

struct IfGenLine;

}  // namespace lower

namespace lower {

/// `Bn`:
///
/// ```prism
/// type Bn = choice:
/// ```
class Bn {
public:
    using prism_value = void;
    struct BnLocal;
    struct BnHold;
    struct BnDyn;
    struct BnEv;
    struct BnParts;
    struct BnWidget;
    struct BnLocalFn;
    using Cases = std::variant<BnLocal, BnHold, BnDyn, BnEv, BnParts, BnWidget, BnLocalFn>;
    template <class C>
        requires prism_rtl::one_of<C, BnLocal, BnHold, BnDyn, BnEv, BnParts, BnWidget, BnLocalFn>
    Bn(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;

private:
    prism_rtl::Rc<const Cases> cases_;
};


/// `Cc`:
///
/// ```prism
/// type Cc = choice:
/// ```
class Cc {
public:
    using prism_value = void;
    struct CcIf;
    struct CcLet;
    using Cases = std::variant<CcIf, CcLet>;
    template <class C>
        requires prism_rtl::one_of<C, CcIf, CcLet>
    Cc(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Cc> from_pod(const Pod& whole);
    friend inline bool operator==(const Cc& a, const Cc& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


/// `CxArg`:
///
/// ```prism
/// type CxArg = choice:
/// ```
class CxArg {
public:
    using prism_value = void;
    struct CxMut;
    struct CxRef;
    struct CxNone;
    using Cases = std::variant<CxMut, CxRef, CxNone>;
    template <class C>
        requires prism_rtl::one_of<C, CxMut, CxRef, CxNone>
    CxArg(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<CxArg> from_pod(const Pod& whole);
    friend inline bool operator==(const CxArg& a, const CxArg& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


/// `Do`:
///
/// ```prism
/// type Do = choice:
/// ```
class Do {
public:
    using prism_value = void;
    struct DoLet;
    struct DoLetElse;
    struct DoAssign;
    struct DoWhile;
    struct DoWhileLet;
    struct DoFor;
    struct DoExpr;
    struct DoIf;
    struct DoIfLet;
    struct DoMatch;
    struct DoReturn;
    struct DoBlock;
    struct DoScope;
    struct DoLine;
    struct DoNote;
    using Cases = std::variant<DoLet, DoLetElse, DoAssign, DoWhile, DoWhileLet, DoFor, DoExpr, DoIf, DoIfLet, DoMatch, DoReturn, DoBlock, DoScope, DoLine, DoNote>;
    template <class C>
        requires prism_rtl::one_of<C, DoLet, DoLetElse, DoAssign, DoWhile, DoWhileLet, DoFor, DoExpr, DoIf, DoIfLet, DoMatch, DoReturn, DoBlock, DoScope, DoLine, DoNote>
    Do(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Do> from_pod(const Pod& whole);
    friend inline bool operator==(const Do& a, const Do& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


/// `Ex`:
///
/// ```prism
/// type Ex = choice:
/// ```
class Ex {
public:
    using prism_value = void;
    struct XVar;
    struct XPath;
    struct XSelf;
    struct XCx;
    struct XConst;
    struct XUnit;
    struct XNone;
    struct XBool;
    struct XNat;
    struct XInt;
    struct XByte;
    struct XFloat;
    struct XIndex;
    struct XChar;
    struct XStr;
    struct XRef;
    struct XRefMut;
    struct XDeref;
    struct XTarget;
    struct XClone;
    struct XWeak;
    struct XUpgrade;
    struct XBreak;
    struct XBreakLoop;
    struct XLater;
    struct XFormatStr;
    struct XIsCase;
    struct XRefusal;
    struct XUnreachable;
    struct XCall;
    struct XApply;
    struct XMethod;
    struct XBin;
    struct XUnary;
    struct XCtor;
    struct XRecord;
    struct XTuple;
    struct XVec;
    struct XText;
    struct XFormat;
    struct XMatch;
    struct XChain;
    struct XIf;
    struct XBlock;
    struct XLabeled;
    struct XClosure;
    struct XTry;
    struct XField;
    struct XPart;
    struct XDecode;
    struct XCast;
    struct XTyped;
    using Cases = std::variant<XVar, XPath, XSelf, XCx, XConst, XUnit, XNone, XBool, XNat, XInt, XByte, XFloat, XIndex, XChar, XStr, XRef, XRefMut, XDeref, XTarget, XClone, XWeak, XUpgrade, XBreak, XBreakLoop, XLater, XFormatStr, XIsCase, XRefusal, XUnreachable, XCall, XApply, XMethod, XBin, XUnary, XCtor, XRecord, XTuple, XVec, XText, XFormat, XMatch, XChain, XIf, XBlock, XLabeled, XClosure, XTry, XField, XPart, XDecode, XCast, XTyped>;
    template <class C>
        requires prism_rtl::one_of<C, XVar, XPath, XSelf, XCx, XConst, XUnit, XNone, XBool, XNat, XInt, XByte, XFloat, XIndex, XChar, XStr, XRef, XRefMut, XDeref, XTarget, XClone, XWeak, XUpgrade, XBreak, XBreakLoop, XLater, XFormatStr, XIsCase, XRefusal, XUnreachable, XCall, XApply, XMethod, XBin, XUnary, XCtor, XRecord, XTuple, XVec, XText, XFormat, XMatch, XChain, XIf, XBlock, XLabeled, XClosure, XTry, XField, XPart, XDecode, XCast, XTyped>
    Ex(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Ex> from_pod(const Pod& whole);
    friend inline bool operator==(const Ex& a, const Ex& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


/// `GnKind`:
///
/// ```prism
/// type GnKind = choice:
/// ```
class GnKind {
public:
    using prism_value = void;
    struct GnNamed;
    struct GnAnswer;
    struct GnStarted;
    struct GnDeferred;
    struct GnPort;
    struct GnMerge;
    struct GnUnion;
    struct GnBoth;
    struct GnExcept;
    struct GnMergeAll;
    struct GnGather;
    struct GnUpdated;
    struct GnNever;
    using Cases = std::variant<GnNamed, GnAnswer, GnStarted, GnDeferred, GnPort, GnMerge, GnUnion, GnBoth, GnExcept, GnMergeAll, GnGather, GnUpdated, GnNever>;
    template <class C>
        requires prism_rtl::one_of<C, GnNamed, GnAnswer, GnStarted, GnDeferred, GnPort, GnMerge, GnUnion, GnBoth, GnExcept, GnMergeAll, GnGather, GnUpdated, GnNever>
    GnKind(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<GnKind> from_pod(const Pod& whole);
    friend inline bool operator==(const GnKind& a, const GnKind& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


/// `Holding`:
///
/// ```prism
/// type Holding = choice:
/// ```
class Holding {
public:
    using prism_value = void;
    struct ByRef;
    struct Owned;
    struct RcRef;
    struct RcOwned;
    using Cases = std::variant<ByRef, Owned, RcRef, RcOwned>;
    template <class C>
        requires prism_rtl::one_of<C, ByRef, Owned, RcRef, RcOwned>
    Holding(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Holding> from_pod(const Pod& whole);
    friend inline bool operator==(const Holding& a, const Holding& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


/// `HostForm`:
///
/// ```prism
/// type HostForm = choice:
/// ```
class HostForm {
public:
    using prism_value = void;
    struct HostEach;
    struct HostSome;
    using Cases = std::variant<HostEach, HostSome>;
    template <class C>
        requires prism_rtl::one_of<C, HostEach, HostSome>
    HostForm(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<HostForm> from_pod(const Pod& whole);
    friend inline bool operator==(const HostForm& a, const HostForm& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


/// `HowBound`:
///
/// ```prism
/// type HowBound = choice:
/// ```
class HowBound {
public:
    using prism_value = void;
    struct AsHold;
    struct AsBind;
    struct AsLet;
    using Cases = std::variant<AsHold, AsBind, AsLet>;
    template <class C>
        requires prism_rtl::one_of<C, AsHold, AsBind, AsLet>
    HowBound(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<HowBound> from_pod(const Pod& whole);
    friend inline bool operator==(const HowBound& a, const HowBound& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


/// `Item`:
///
/// ```prism
/// type Item = choice:
/// ```
class Item {
public:
    using prism_value = void;
    struct ItTrait;
    struct ItImpl;
    struct ItType;
    struct ItTag;
    struct ItRow;
    struct ItFn;
    struct ItJob;
    struct ItNode;
    struct ItNote;
    struct ItRefused;
    using Cases = std::variant<ItTrait, ItImpl, ItType, ItTag, ItRow, ItFn, ItJob, ItNode, ItNote, ItRefused>;
    template <class C>
        requires prism_rtl::one_of<C, ItTrait, ItImpl, ItType, ItTag, ItRow, ItFn, ItJob, ItNode, ItNote, ItRefused>
    Item(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Item> from_pod(const Pod& whole);
    friend inline bool operator==(const Item& a, const Item& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


/// `Layer`:
///
/// ```prism
/// type Layer = choice:
/// ```
class Layer {
public:
    using prism_value = void;
    struct LyPlain;
    struct LyDyn;
    struct LyEv;
    struct LyBlueprint;
    using Cases = std::variant<LyPlain, LyDyn, LyEv, LyBlueprint>;
    template <class C>
        requires prism_rtl::one_of<C, LyPlain, LyDyn, LyEv, LyBlueprint>
    Layer(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Layer> from_pod(const Pod& whole);
    friend inline bool operator==(const Layer& a, const Layer& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


/// `OutTy`:
///
/// ```prism
/// type OutTy = choice:
/// ```
class OutTy {
public:
    using prism_value = void;
    struct OutNat;
    struct OutInt;
    struct OutU8;
    struct OutFloat;
    struct OutBool;
    struct OutChar;
    struct OutText;
    struct OutCursor;
    struct OutUnit;
    struct OutPath;
    struct OutDuration;
    struct OutError;
    struct OutNamed;
    struct OutOpt;
    struct OutRes;
    struct OutTuple;
    struct OutArray;
    struct OutMap;
    struct OutFn;
    struct OutJobFn;
    struct OutJob;
    struct OutEvent;
    struct OutDyn;
    struct OutGen;
    struct OutRc;
    struct OutRef;
    struct OutPod;
    struct OutShowAny;
    struct OutHold;
    struct OutStamped;
    struct OutSnapshot;
    struct OutDefer;
    struct OutWeak;
    struct OutCell;
    struct OutWakes;
    struct OutCount;
    struct OutObj;
    struct OutSlice;
    struct OutPort;
    struct OutLive;
    struct OutQuantified;
    struct OutUnknown;
    using Cases = std::variant<OutNat, OutInt, OutU8, OutFloat, OutBool, OutChar, OutText, OutCursor, OutUnit, OutPath, OutDuration, OutError, OutNamed, OutOpt, OutRes, OutTuple, OutArray, OutMap, OutFn, OutJobFn, OutJob, OutEvent, OutDyn, OutGen, OutRc, OutRef, OutPod, OutShowAny, OutHold, OutStamped, OutSnapshot, OutDefer, OutWeak, OutCell, OutWakes, OutCount, OutObj, OutSlice, OutPort, OutLive, OutQuantified, OutUnknown>;
    template <class C>
        requires prism_rtl::one_of<C, OutNat, OutInt, OutU8, OutFloat, OutBool, OutChar, OutText, OutCursor, OutUnit, OutPath, OutDuration, OutError, OutNamed, OutOpt, OutRes, OutTuple, OutArray, OutMap, OutFn, OutJobFn, OutJob, OutEvent, OutDyn, OutGen, OutRc, OutRef, OutPod, OutShowAny, OutHold, OutStamped, OutSnapshot, OutDefer, OutWeak, OutCell, OutWakes, OutCount, OutObj, OutSlice, OutPort, OutLive, OutQuantified, OutUnknown>
    OutTy(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<OutTy> from_pod(const Pod& whole);
    friend inline bool operator==(const OutTy& a, const OutTy& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


/// `Pa`:
///
/// ```prism
/// type Pa = choice:
/// ```
class Pa {
public:
    using prism_value = void;
    struct PaWild;
    struct PaBind;
    struct PaMut;
    struct PaCtor;
    struct PaUnit;
    struct PaRecord;
    struct PaTuple;
    struct PaChar;
    struct PaBool;
    struct PaIndex;
    struct PaConst;
    struct PaSlice;
    struct PaRest;
    struct PaTyped;
    using Cases = std::variant<PaWild, PaBind, PaMut, PaCtor, PaUnit, PaRecord, PaTuple, PaChar, PaBool, PaIndex, PaConst, PaSlice, PaRest, PaTyped>;
    template <class C>
        requires prism_rtl::one_of<C, PaWild, PaBind, PaMut, PaCtor, PaUnit, PaRecord, PaTuple, PaChar, PaBool, PaIndex, PaConst, PaSlice, PaRest, PaTyped>
    Pa(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Pa> from_pod(const Pod& whole);
    friend inline bool operator==(const Pa& a, const Pa& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


/// `Read`:
///
/// ```prism
/// type Read = choice:
/// ```
class Read {
public:
    using prism_value = void;
    struct OwnRead;
    struct ParentRead;
    using Cases = std::variant<OwnRead, ParentRead>;
    template <class C>
        requires prism_rtl::one_of<C, OwnRead, ParentRead>
    Read(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Read> from_pod(const Pod& whole);
    friend inline bool operator==(const Read& a, const Read& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


/// `Recv`:
///
/// ```prism
/// type Recv = choice:
/// ```
class Recv {
public:
    using prism_value = void;
    struct RecvRc;
    struct RecvRef;
    struct RecvOwned;
    using Cases = std::variant<RecvRc, RecvRef, RecvOwned>;
    template <class C>
        requires prism_rtl::one_of<C, RecvRc, RecvRef, RecvOwned>
    Recv(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Recv> from_pod(const Pod& whole);
    friend inline bool operator==(const Recv& a, const Recv& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


/// `RowKind`:
///
/// ```prism
/// type RowKind = choice:
/// ```
class RowKind {
public:
    using prism_value = void;
    struct ForRow;
    struct GenerationRow;
    struct NotARow;
    using Cases = std::variant<ForRow, GenerationRow, NotARow>;
    template <class C>
        requires prism_rtl::one_of<C, ForRow, GenerationRow, NotARow>
    RowKind(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<RowKind> from_pod(const Pod& whole);
    friend inline bool operator==(const RowKind& a, const RowKind& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


/// `Shown`:
///
/// ```prism
/// type Shown = choice:
/// ```
class Shown {
public:
    using prism_value = void;
    struct ShownOwn;
    struct ShownDerived;
    struct NotShown;
    using Cases = std::variant<ShownOwn, ShownDerived, NotShown>;
    template <class C>
        requires prism_rtl::one_of<C, ShownOwn, ShownDerived, NotShown>
    Shown(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Shown> from_pod(const Pod& whole);
    friend inline bool operator==(const Shown& a, const Shown& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


/// `Sk`:
///
/// ```prism
/// type Sk = choice:
/// ```
class Sk {
public:
    using prism_value = void;
    struct SkNode;
    struct SkIn;
    struct SkHold;
    struct SkRequest;
    struct SkResult;
    struct SkArm;
    struct SkCycle;
    struct SkUp;
    struct SkPort;
    struct SkMachine;
    using Cases = std::variant<SkNode, SkIn, SkHold, SkRequest, SkResult, SkArm, SkCycle, SkUp, SkPort, SkMachine>;
    template <class C>
        requires prism_rtl::one_of<C, SkNode, SkIn, SkHold, SkRequest, SkResult, SkArm, SkCycle, SkUp, SkPort, SkMachine>
    Sk(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    Pod to_pod() const;
    static Result<Sk> from_pod(const Pod& whole);

private:
    prism_rtl::Rc<const Cases> cases_;
};


/// `TyShape`:
///
/// ```prism
/// type TyShape = choice:
/// ```
class TyShape {
public:
    using prism_value = void;
    struct ShapeRecord;
    struct ShapeChoice;
    struct ShapeNewtype;
    struct ShapeUnit;
    using Cases = std::variant<ShapeRecord, ShapeChoice, ShapeNewtype, ShapeUnit>;
    template <class C>
        requires prism_rtl::one_of<C, ShapeRecord, ShapeChoice, ShapeNewtype, ShapeUnit>
    TyShape(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<TyShape> from_pod(const Pod& whole);
    friend inline bool operator==(const TyShape& a, const TyShape& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


/// `Vl`:
///
/// ```prism
/// type Vl = choice:
/// ```
class Vl {
public:
    using prism_value = void;
    struct VlPlace;
    struct VlOwned;
    using Cases = std::variant<VlPlace, VlOwned>;
    template <class C>
        requires prism_rtl::one_of<C, VlPlace, VlOwned>
    Vl(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    Pod to_pod() const;
    static Result<Vl> from_pod(const Pod& whole);

private:
    prism_rtl::Rc<const Cases> cases_;
};


/// `Wres`:
///
/// ```prism
/// type Wres = choice:
/// ```
class Wres {
public:
    using prism_value = void;
    struct WrEv;
    struct WrDyn;
    struct WrPlain;
    struct WrUnit;
    struct WrHosted;
    using Cases = std::variant<WrEv, WrDyn, WrPlain, WrUnit, WrHosted>;
    template <class C>
        requires prism_rtl::one_of<C, WrEv, WrDyn, WrPlain, WrUnit, WrHosted>
    Wres(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;

private:
    prism_rtl::Rc<const Cases> cases_;
};


}  // namespace lower

}  // namespace crate
