// The module `Lower`, from `target/bootstrap/cpp-src/prismc/lower.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (docs/backend.md). Edit the Prism source, not this file.
#include "crate.hpp"

namespace crate::lower {

/// `Start FinishNode, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<NodeDef> start_finish_node(Wx wx0, Text qk, Array<std::tuple<Text, OutTy>> params, bool is_row) {
    return std::make_shared<FinishNode>(wx0, qk, params, is_row);
}


/// IsGeneration: fn Wx, Text -> Bool
bool is_generation(const Wx& wx, const Text& name) {
    return len(filter(wx.gens, [&](const GenDef& gd) { return gd.name == name; })) > Nat(0u);
}


/// FlattenMethods: fn Sinks -> [MethDef]
Array<MethDef> flatten_methods(const Sinks& sk) {
    auto wx = sk.wx;
    auto adopts_1 = each(wx.flattens, [&](const FlatDef& fl) {
        return ({
            auto set_1 = Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(fl.name, "_inner")})), Text("set"), Array(std::vector{Ex(Ex::XCtor{Text("Some"), Array(std::vector{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XSelf{})), fl.outer, Array(std::vector{Ex(Ex::XCx{})})})})}), Ex(Ex::XCx{})})})});
            MethDef{.name = prism_rtl::cat(fl.name, "_adopt"), .recv = Recv(Recv::RecvRc{}), .params = Array<std::tuple<Text, OutTy>>{}, .cx_ = CxArg(CxArg::CxMut{}), .ret = OutTy(OutTy::OutUnit{}), .body = append(Array(std::vector{set_1}), hold_written(sk, prism_rtl::cat(fl.name, "_inner"))), .tail = Ex(Ex::XUnit{}), .doc = Text("`@Flatten` adopts the inner its `rebuild`'s dynamic held after the tick before, among this tick's first firings: from here on it reads that inner (Semantics ch. 7).")};
        });
    });
    auto dyn_gens = filter(wx.gens, [&](const GenDef& gd) { return len(filter(wx.snaps, [&](const SnapDef& sn) { return sn.builder == gd.name; })) > Nat(0u); });
    auto moved_2 = each(dyn_gens, [&](const GenDef& gd) {
        return ({
            auto marks = fold(filter(wx.flattens, [&](const FlatDef& fl) { return fl->generation == gd.name; }), Array<Do>{}, [&](const Array<Do>& acc, const FlatDef& fl) { return append(acc, hold_written(sk, prism_rtl::cat(fl.name, "_inner"))); });
            MethDef{.name = prism_rtl::cat(gd.name, "_result_moved"), .recv = Recv(Recv::RecvRc{}), .params = Array<std::tuple<Text, OutTy>>{}, .cx_ = CxArg(CxArg::CxMut{}), .ret = OutTy(OutTy::OutUnit{}), .body = marks, .tail = Ex(Ex::XUnit{}), .doc = Text("The current generation's result moved: what reads a `@Flatten` over it reads it again.")};
        });
    });
    return append(adopts_1, moved_2);
}


/// HostMoved: fn Sinks, HostDef -> MethDef
MethDef host_moved(const Sinks& sk, const HostDef& h) {
    return MethDef{.name = prism_rtl::cat(h.name, "_moved"), .recv = Recv(Recv::RecvRc{}), .params = Array<std::tuple<Text, OutTy>>{}, .cx_ = CxArg(CxArg::CxMut{}), .ret = OutTy(OutTy::OutUnit{}), .body = hold_written(sk, prism_rtl::cat(h.name, "_doc_now")), .tail = Ex(Ex::XUnit{}), .doc = prism_rtl::cat("A node of the child hosted at place ", place_text(h.pos), " wrote behind its document: the structure is marked as for a write of a hold it reads (pick HO), the snapshot listed to be taken; the program's `$doc` moves when it is published, the tick after (pick ST).")};
}


/// BuildSteps: fn Sinks, Bool -> [Do]
Array<Do> build_steps(const Sinks& sk, const bool& at_build) {
    auto wx = sk.wx;
    auto recv = at_build ? Ex(Ex::XVar{Text("node")}) : Ex(Ex::XSelf{});
    auto take_fn = ({
        auto at_build_1 = at_build;
        auto sk_2 = sk;
        (prism_rtl::rc([=](const SnapDef& sn) { return at_build_1 ? snap_take_at_build(sn) : snap_take(sk_2, sn); }));
    });
    auto builder_fn = ({
        auto wx_1 = wx;
        auto take_fn_2 = take_fn;
        auto recv_3 = recv;
        (prism_rtl::rc([=](const ForDef& b) {
        return ({
            auto before = each(filter(wx_1.snaps, [&](const SnapDef& sn) { return sn.before && (sn.builder == b.name); }), take_fn_2);
            auto after = each(filter(wx_1.snaps, [&](const SnapDef& sn) { return (!sn.before) && (sn.builder == b.name); }), take_fn_2);
            append(prelude::push(before, Do(Do::DoExpr{try_of(Ex(Ex::XMethod{prism_rtl::rc(recv_3), prism_rtl::cat(b.name, "_build"), Array(std::vector{Ex(Ex::XCx{})})}))})), after);
        });
    }));
    });
    auto gen__fn = ({
        auto at_build_1 = at_build;
        auto recv_2 = recv;
        auto wx_3 = wx;
        auto take_fn_4 = take_fn;
        (prism_rtl::rc([=](const GenDef& gd) {
        return ({
            auto built = at_build_1
                ? Do(Do::DoExpr{try_of(Ex(Ex::XMethod{prism_rtl::rc(recv_2), prism_rtl::cat(gd.name, "_build"), Array(std::vector{Ex(Ex::XCx{})})}))})
                : Do(Do::DoIf{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(gd.name, "_stale")})), Text("replace"), Array(std::vector{Ex(Ex::XBool{false})})}), Array(std::vector{Do(Do::DoExpr{try_of(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(gd.name, "_build"), Array(std::vector{Ex(Ex::XCx{})})}))})}), Array<Do>{}});
            append(Array(std::vector{built}), each(filter(wx_3.snaps, [&](const SnapDef& sn) { return (!sn.before) && (sn.builder == gd.name); }), take_fn_4));
        });
    }));
    });
    return fold(check_errors::range0(len(wx.scopes) + Nat(1u)), Array<Do>{}, [&](const Array<Do>& acc, const Nat& i) {
        return ({
            auto k = or_(len(wx.scopes).checked_sub(i), Nat(0u));
            auto builders = fold(filter(wx.builders, [&](const ForDef& b) { return b.pos.scope == k; }), Array<Do>{}, [&](const Array<Do>& a, const ForDef& b) { return append(a, builder_fn(b)); });
            append(append(acc, builders), fold(filter(wx.gens, [&](const GenDef& gd) { return gd.pos.scope == k; }), Array<Do>{}, [&](const Array<Do>& a, const GenDef& gd) { return append(a, gen__fn(gd)); }));
        });
    });
}


/// SnapTakeAtBuild: fn SnapDef -> Do
Do snap_take_at_build(const SnapDef& sn) {
    return Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XVar{Text("node")})), prism_rtl::cat(sn.name, "_snap")})), Text("take"), Array(std::vector{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text("node")})), prism_rtl::cat(sn.name, "_now"), Array(std::vector{Ex(Ex::XCx{})})}), Ex(Ex::XCx{})})})});
}


/// SnapTake: fn Sinks, SnapDef -> Do
Do snap_take(const Sinks& sk, const SnapDef& sn) {
    auto now = Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(sn.name, "_now"), Array(std::vector{Ex(Ex::XCx{})})});
    auto take_ = Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(sn.name, "_snap")})), sn.eq ? Text("take_compared") : Text("take"), Array(std::vector{now, Ex(Ex::XCx{})})})});
    auto queue = Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XCx{})), Text("answer_later"), Array(std::vector{Ex(Ex::XLater{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text("node")})), prism_rtl::cat(sn.name, "_publish"), Array(std::vector{Ex(Ex::XCx{})})}))})})})});
    auto queued = Do(Do::DoIf{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(sn.name, "_snap")})), Text("queue"), Array(std::vector{Ex(Ex::XCx{})})}), Array(std::vector{Do(Do::DoLet{Pa(Pa::PaBind{Text("node")}), Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XSelf{}))})}), queue}), Array<Do>{}});
    return Do(Do::DoIf{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(sn.name, "_snap")})), Text("marked"), Array(std::vector{Ex(Ex::XCx{})})}), Array(std::vector{take_, queued}), Array<Do>{}});
}


/// SnapPublish: fn Sinks, SnapDef -> MethDef
MethDef snap_publish(const Sinks& sk, const SnapDef& sn) {
    return MethDef{.name = prism_rtl::cat(sn.name, "_publish"), .recv = Recv(Recv::RecvRc{}), .params = Array<std::tuple<Text, OutTy>>{}, .cx_ = CxArg(CxArg::CxMut{}), .ret = OutTy(OutTy::OutUnit{}), .body = Array(std::vector{Do(Do::DoIf{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(sn.name, "_snap")})), Text("published"), Array(std::vector{Ex(Ex::XCx{})})}), hold_written(sk, sn.name), Array<Do>{}})}), .tail = Ex(Ex::XUnit{}), .doc = prism_rtl::cat(sn.what, ", published: its snapshot of the tick before moved it, written as a hold is (pick ST).")};
}


/// GatheredMoved: fn SnapDef -> MethDef
MethDef gathered_moved(const SnapDef& sn) {
    return MethDef{.name = prism_rtl::cat(sn.name, "_moved"), .recv = Recv(Recv::RecvRc{}), .params = Array<std::tuple<Text, OutTy>>{}, .cx_ = CxArg(CxArg::CxMut{}), .ret = OutTy(OutTy::OutUnit{}), .body = Array(std::vector{Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(sn.name, "_snap")})), Text("mark"), Array(std::vector{Ex(Ex::XCx{})})})}), Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XCx{})), Text("build_later"), Array(std::vector{Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XSelf{}))})})})})}), .tail = Ex(Ex::XUnit{}), .doc = Text("A row's result moved: the `for`'s gathered dynamic is marked, and its snapshot taken after the builder (pick ST).")};
}


/// DocumentGetter: fn Wx -> MethDef
MethDef document_getter(const Wx& wx) {
    auto is_own_fn = prism_rtl::rc([=](const Pos_& p_) { return p_.scope == Nat(0u); });
    auto body = document_body(({
        auto f = prism_rtl::rc(vec_push);
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Do>(std::tuple<Ex, Ex>)>>(prism_rtl::rc([=](std::tuple<Ex, Ex> _p0) {
        auto&& a0 = std::get<0>(_p0);
        auto&& a1 = std::get<1>(_p0);
        return ({
            auto f_1 = f;
            once_job([=]() { return prism_rtl::finished(f_1(a0, a1)); });
        });
    })));
    }), filter(wx.places, [&](const Place& pl) { return is_own_fn(pl.pos); }), filter(wx.builders, [&](const ForDef& b) { return is_own_fn(b.pos); }), filter(wx.gens, [&](const GenDef& gd) { return is_own_fn(gd.pos); }));
    return MethDef{.name = Text("document"), .recv = Recv(Recv::RecvRef{}), .params = Array<std::tuple<Text, OutTy>>{}, .cx_ = CxArg(CxArg::CxRef{}), .ret = OutTy(OutTy::OutNamed{Text("Vec"), Array(std::vector{OutTy(OutTy::OutTuple{Array(std::vector{OutTy(OutTy::OutPath{}), elem_ty()})})})}), .body = append(Array(std::vector{Do(Do::DoLet{Pa(Pa::PaTyped{prism_rtl::rc(Pa(Pa::PaMut{Text("doc")})), OutTy(OutTy::OutNamed{Text("Vec"), Array(std::vector{OutTy(OutTy::OutTuple{Array(std::vector{OutTy(OutTy::OutPath{}), elem_ty()})})})})}), Ex(Ex::XCall{Text("Vec::new"), Array<Ex>{}})})}), body), .tail = Ex(Ex::XVar{Text("doc")}), .doc = Text("The row's own places, entries of its host's document, by their paths relative to the row (pick HO).")};
}


/// DocumentMoved: fn Text -> MethDef
MethDef document_moved(const Text& m) {
    return MethDef{.name = Text("document_moved"), .recv = Recv(Recv::RecvRc{}), .params = Array<std::tuple<Text, OutTy>>{}, .cx_ = CxArg(CxArg::CxMut{}), .ret = OutTy(OutTy::OutUnit{}), .body = Array(std::vector{Do(Do::DoIfLet{Pa(Pa::PaCtor{Text("Some"), Array(std::vector{Pa(Pa::PaBind{Text("parent")})})}), Ex(Ex::XUpgrade{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), Text("parent")}))}), Array(std::vector{Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text("parent")})), m, Array(std::vector{Ex(Ex::XCx{})})})})}), Array<Do>{}})}), .tail = Ex(Ex::XUnit{}), .doc = Text("A place of this row may have moved: its host's document moved, and the host's readers and rows are marked (pick HO).")};
}


/// DocumentBody: fn (fn Ex, Ex -> Do), [Place], [ForDef], [GenDef] -> [Do]
Array<Do> document_body(const prism_rtl::Fn<prism_rtl::JobRef<Do>(std::tuple<Ex, Ex>)>& add_fn, const Array<Place>& places, const Array<ForDef>& builders, const Array<GenDef>& gens) {
    auto statics = run_to_end(each_job(places, ({
        auto add_fn_1 = add_fn;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Do>(Place)>>(prism_rtl::rc([=](Place p0) {
        return ({
            auto add_fn_1_2 = add_fn_1;
            entered(once_job([=]() {
            return ({
                auto pl = p0;
                ({
                auto level = pl.getter == Text("")
                    ? pl.level
                    : Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XSelf{})), pl.getter, Array(std::vector{Ex(Ex::XCx{})})});
                add_fn_1_2(std::tuple{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XCall{Text("Path::root"), Array<Ex>{}})), Text("at"), Array(std::vector{Ex(Ex::XIndex{pl.pos.at})})}), level})->cycle();
            });
            });
        }));
        });
    })));
    })));
    auto rows = run_to_end(each_job(builders, ({
        auto add_fn_1 = add_fn;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Do>(ForDef)>>(prism_rtl::rc([=](ForDef p0) {
        return ({
            auto add_fn_1_2 = add_fn_1;
            entered(once_job([=]() {
            return ({
                auto b = p0;
                call_value(add_fn_1_2(std::tuple{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XCall{Text("Path::root"), Array<Ex>{}})), Text("at"), Array(std::vector{Ex(Ex::XIndex{b.pos.at})})})), Text("child"), Array(std::vector{Ex(Ex::XCtor{Text("Segment::Key"), Array(std::vector{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text("k")})), Text("to_pod"), Array<Ex>{}})})})})})), Text("join"), Array(std::vector{Ex(Ex::XRef{prism_rtl::rc(Ex(Ex::XVar{Text("p")}))})})}), Ex(Ex::XVar{Text("e")})}), [=](Do add_279553) { return prism_rtl::finished(Do(Do::DoFor{Pa(Pa::PaTuple{Array(std::vector{Pa(Pa::PaBind{Text("k")}), Pa(Pa::PaBind{Text("row")})})}), Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), b.name})), Text("borrow"), Array<Ex>{}})), Text("iter"), Array<Ex>{}}), Array(std::vector{Do(Do::DoFor{Pa(Pa::PaTuple{Array(std::vector{Pa(Pa::PaBind{Text("p")}), Pa(Pa::PaBind{Text("e")})})}), Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text("row")})), Text("document"), Array(std::vector{Ex(Ex::XCx{})})}), Array(std::vector{add_279553})})})})); });
            });
        }));
        });
    })));
    })));
    auto generations = run_to_end(each_job(gens, ({
        auto add_fn_1 = add_fn;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Do>(GenDef)>>(prism_rtl::rc([=](GenDef p0) {
        return ({
            auto add_fn_1_2 = add_fn_1;
            entered(once_job([=]() {
            return ({
                auto gd = p0;
                call_value(add_fn_1_2(std::tuple{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XCall{Text("Path::root"), Array<Ex>{}})), Text("at"), Array(std::vector{Ex(Ex::XIndex{gd.pos.at})})})), Text("child"), Array(std::vector{Ex(Ex::XCtor{Text("Segment::Gen"), Array(std::vector{Ex(Ex::XVar{Text("g")})})})})})), Text("join"), Array(std::vector{Ex(Ex::XRef{prism_rtl::rc(Ex(Ex::XVar{Text("p")}))})})}), Ex(Ex::XVar{Text("e")})}), [=](Do add_280125) { return prism_rtl::finished(Do(Do::DoIfLet{Pa(Pa::PaCtor{Text("Some"), Array(std::vector{Pa(Pa::PaBind{Text("row")})})}), Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), gd.name})), Text("borrow"), Array<Ex>{}})), Text("as_ref"), Array<Ex>{}}), Array(std::vector{Do(Do::DoLet{Pa(Pa::PaBind{Text("g")}), Ex(Ex::XBin{Text("-"), prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(gd.name, "_count")})), Text("get"), Array<Ex>{}})), prism_rtl::rc(Ex(Ex::XIndex{Nat(1u)}))})}), Do(Do::DoFor{Pa(Pa::PaTuple{Array(std::vector{Pa(Pa::PaBind{Text("p")}), Pa(Pa::PaBind{Text("e")})})}), Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text("row")})), Text("document"), Array(std::vector{Ex(Ex::XCx{})})}), Array(std::vector{add_280125})})}), Array<Do>{}})); });
            });
        }));
        });
    })));
    })));
    return append(append(statics, rows), generations);
}


/// MapInsert: fn Ex, Ex -> Do
Do map_insert(const Ex& path_, const Ex& e) {
    return Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text("doc")})), Text("insert"), Array(std::vector{path_, e})})});
}


/// VecPush: fn Ex, Ex -> Do
Do vec_push(const Ex& path_, const Ex& e) {
    return Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text("doc")})), Text("push"), Array(std::vector{Ex(Ex::XTuple{Array(std::vector{path_, e})})})})});
}


/// DynAnswerArm: fn Sinks, Pos, Text, OutTy -> ((Pa, Ex))
std::tuple<Pa, Ex> dyn_answer_arm(const Sinks& sk, const Pos_& pos, const Text& f, const OutTy& t) {
    return std::tuple{pos_pat(pos, Array<Pa>{}), Ex(Ex::XBlock{dyn_place_write(sk, f, Ex(Ex::XDecode{t, prism_rtl::rc(Ex(Ex::XVar{Text("v")}))})), prism_rtl::rc(Ex(Ex::XUnit{}))})};
}


/// DynPlaceWrite: fn Sinks, Text, Ex -> [Do]
Array<Do> dyn_place_write(const Sinks& sk, const Text& f, const Ex& value) {
    return append(Array(std::vector{Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(f)})), Text("set"), Array(std::vector{value, Ex(Ex::XCx{})})})})}), hold_written(sk, f));
}


/// UpdatedGaps: fn Wx, [Gn], Bool -> [Do]
Array<Do> updated_gaps(const Wx& wx, const Array<Gn>& gns, const bool& is_gen) {
    auto holds = fold(wx.fields, Array<Text>{}, [&](const Array<Text>& acc, const std::tuple<Text, OutTy, Text>& _p1) {
        auto&& f = std::get<0>(_p1);
        auto&& t = std::get<1>(_p1);
        return is_hold(t) ? prelude::push(acc, f) : acc;
    });
    auto derived = keys(wx.dyn_reads);
    auto roots = snap_names(wx);
    auto own_ = fold(filter(gns, [&](const Gn& g) { return g.kind == GnKind(GnKind::GnUpdated{}); }), Array<Do>{}, [&](const Array<Do>& acc, const Gn& g) {
        return fold(g.reads, acc, [&](const Array<Do>& a, const Read& r) {
            return ({
                __label__ _done;
                prism_rtl::Slot<Array<Do>> _v;
                if (prism_rtl::is<Read::ParentRead>(r)) {
                    auto&& f = prism_rtl::as<Read::ParentRead>(r).a0;
                    _v.set(is_gen
                        ? prelude::push(a, refusal_do(prism_rtl::cat("`!Updated` of a dynamic in a generation that reads its block's `", f, "`, which the block does not tell a generation of (gap DY)")))
                        : a);
                    goto _done;
                }
                if (prism_rtl::is<Read::OwnRead>(r)) {
                    auto&& f = prism_rtl::as<Read::OwnRead>(r).a0;
                    _v.set((check_types::has_text(holds, f) || check_types::has_text(derived, f)) || check_types::has_text(roots, f)
                        ? a
                        : prelude::push(a, refusal_do(prism_rtl::cat("`!Updated` of a dynamic that reads `", f, "`, which no sink of this node writes (no height for its event)"))));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
        });
    });
    return fold(wx.pending, own_, [&](const Array<Do>& acc, const PendingRow& p_) {
        return fold(row_hears(p_.wx), acc, [&](const Array<Do>& a, const Text& m) {
            return ({
                auto behind = reads_closed(wx.dyn_reads, Array(std::vector{Read(Read::OwnRead{m})}));
                auto written = fold(behind, false, [&](const bool& w, const Read& r) {
                    return w || ({
                        __label__ _done;
                        prism_rtl::Slot<bool> _v;
                        if (prism_rtl::is<Read::OwnRead>(r)) {
                            auto&& h = prism_rtl::as<Read::OwnRead>(r).a0;
                            _v.set(check_types::has_text(holds, h));
                            goto _done;
                        }
                        if (prism_rtl::is<Read::ParentRead>(r)) {
                            _v.set(true);
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                });
                (check_types::has_text(roots, m) || reaches_snap(roots, behind)
                ? prelude::push(a, refusal_do(prism_rtl::cat("`!Updated` of a dynamic in a row that reads its block's `", m, "`, a structural dynamic the block publishes at the start of a tick, not lowered for a row's `!Updated` (gap SU)")))
                : written || check_types::has_text(derived, m)
                ? a
                : prelude::push(a, refusal_do(prism_rtl::cat("`!Updated` of a dynamic in a row that reads its block's `", m, "`, which no sink of the block writes (no height for its event)"))));
            });
        });
    });
}


/// FinishPending: unbounded fn Wx, [Gn] -> (([NodeDef], [Gn]))
std::tuple<Array<NodeDef>, Array<Gn>> finish_pending(const Wx& wx, const Array<Gn>& gns) {
    return run_to_end(fold_job(wx.pending, std::tuple{Array<NodeDef>{}, gns}, ({
        auto wx_1 = wx;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<NodeDef>, Array<Gn>>>(std::tuple<std::tuple<Array<NodeDef>, Array<Gn>>, PendingRow>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<NodeDef>, Array<Gn>>, PendingRow> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto wx_1_2 = wx_1;
            entered(once_job([=]() {
            return ({
                auto [defs, cur] = p0;
                auto p_ = p1;
                ({
                auto floors = fold(row_hears(p_.wx), Map<Text, Nat>{}, [&](const Map<Text, Nat>& acc, const Text& m) { return insert(acc, m, parent_floor(wx_1_2, cur, Array(std::vector{Read(Read::ParentRead{m})}))); });
                auto floored = ({
                    Wx this_ = p_.wx;
                    this_.floors = floors;
                    this_.gns = each(this_.gns, [&](const Gn& g) {
                        return g.kind == GnKind(GnKind::GnUpdated{})
                            ? with_floor(g, parent_floor(wx_1_2, cur, reads_closed(p_.wx.dyn_reads, g.reads)))
                            : g;
                    });
                    this_;
                });
                call_then(start_finish_node(floored, p_.qk, p_.params, true), [=](NodeDef finish_node_284391) {
                return ({
                    auto def = finish_node_284391;
                    auto next = ({
                        __label__ _done;
                        prism_rtl::Slot<Array<Gn>> _v;
                        auto&& _m = p_.gather;
                        if (prism_rtl::is_some(_m)) {
                            auto&& gid = prism_rtl::some_of(_m);
                            _v.set(each(cur, [&](const Gn& g) { return g.id == gid ? with_height(g, def.top + Nat(1u)) : g; }));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(cur);
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                    (prism_rtl::finished(std::tuple{prelude::push(defs, def), next}));
                });
            });
            });
            });
        }));
        });
    }));
    })));
}


prism_rtl::Turn<std::tuple<Array<NodeDef>, Array<Gn>>> FinishPending::cycle() const {
    const auto& wx = this->wx;
    const auto& gns = this->gns;
    return fold_job(wx.pending, std::tuple{Array<NodeDef>{}, gns}, ({
        auto wx_1 = wx;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<NodeDef>, Array<Gn>>>(std::tuple<std::tuple<Array<NodeDef>, Array<Gn>>, PendingRow>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<NodeDef>, Array<Gn>>, PendingRow> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto wx_1_2 = wx_1;
            entered(once_job([=]() {
            return ({
                auto [defs, cur] = p0;
                auto p_ = p1;
                ({
                auto floors = fold(row_hears(p_.wx), Map<Text, Nat>{}, [&](const Map<Text, Nat>& acc, const Text& m) { return insert(acc, m, parent_floor(wx_1_2, cur, Array(std::vector{Read(Read::ParentRead{m})}))); });
                auto floored = ({
                    Wx this_ = p_.wx;
                    this_.floors = floors;
                    this_.gns = each(this_.gns, [&](const Gn& g) {
                        return g.kind == GnKind(GnKind::GnUpdated{})
                            ? with_floor(g, parent_floor(wx_1_2, cur, reads_closed(p_.wx.dyn_reads, g.reads)))
                            : g;
                    });
                    this_;
                });
                call_then(start_finish_node(floored, p_.qk, p_.params, true), [=](NodeDef finish_node_284391) {
                return ({
                    auto def = finish_node_284391;
                    auto next = ({
                        __label__ _done;
                        prism_rtl::Slot<Array<Gn>> _v;
                        auto&& _m = p_.gather;
                        if (prism_rtl::is_some(_m)) {
                            auto&& gid = prism_rtl::some_of(_m);
                            _v.set(each(cur, [&](const Gn& g) { return g.id == gid ? with_height(g, def.top + Nat(1u)) : g; }));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(cur);
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                    (prism_rtl::finished(std::tuple{prelude::push(defs, def), next}));
                });
            });
            });
            });
        }));
        });
    }));
    }))->cycle();
}


/// `Start FinishPending, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<NodeDef>, Array<Gn>>> start_finish_pending(Wx wx, Array<Gn> gns) {
    return std::make_shared<FinishPending>(wx, gns);
}


/// ParentFloor: fn Wx, [Gn], [Read] -> Nat
Nat parent_floor(const Wx& wx, const Array<Gn>& gns, const Array<Read>& reads) {
    return fold(reads, Nat(0u), [&](const Nat& hi, const Read& r) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Nat> _v;
            if (prism_rtl::is<Read::ParentRead>(r)) {
                auto&& m = prism_rtl::as<Read::ParentRead>(r).a0;
                _v.set(fold(reads_closed(wx.dyn_reads, Array(std::vector{Read(Read::OwnRead{m})})), hi, [&](const Nat& h2, const Read& hr) {
                    return ({
                        __label__ _done;
                        prism_rtl::Slot<Nat> _v;
                        if (prism_rtl::is<Read::OwnRead>(hr)) {
                            auto&& f = prism_rtl::as<Read::OwnRead>(hr).a0;
                            _v.set(fold(gns, h2, [&](const Nat& h3, const Gn& g) { return writes_hold(g, f) ? prelude::max(h3, g.height + Nat(1u)) : h3; }));
                            goto _done;
                        }
                        if (prism_rtl::is<Read::ParentRead>(hr)) {
                            auto&& up = prism_rtl::as<Read::ParentRead>(hr).a0;
                            _v.set(prelude::max(h2, or_(prelude::get(wx.floors, up), Nat(0u))));
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                }));
                goto _done;
            }
            if (prism_rtl::is<Read::OwnRead>(r)) {
                _v.set(hi);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
}


/// WritesHold: fn Gn, Text -> Bool
bool writes_hold(const Gn& g, const Text& f) {
    return fold(g.outs, false, [&](const bool& acc, const Out& o) { return acc || sink_writes_hold(o.sink, f); });
}


/// SinkWritesHold: fn Sk, Text -> Bool
bool sink_writes_hold(const Sk& sk0, const Text& f) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        if (prism_rtl::is<Sk::SkHold>(sk0)) {
            auto&& h = prism_rtl::as<Sk::SkHold>(sk0).a0;
            _v.set(h == f);
            goto _done;
        }
        if (prism_rtl::is<Sk::SkMachine>(sk0)) {
            auto&& h = prism_rtl::as<Sk::SkMachine>(sk0).a0;
            _v.set(h == f);
            goto _done;
        }
        {
            auto&& other = sk0;
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// WithFloor: fn Gn, Nat -> Gn
Gn with_floor(const Gn& g, const Nat& h) {
    Gn this_ = g;
    this_.floor = h;
    return this_;
}


/// WithHeight: fn Gn, Nat -> Gn
Gn with_height(const Gn& g, const Nat& h) {
    Gn this_ = g;
    this_.height = h;
    return this_;
}


/// RowHears: fn Wx -> [Text]
Array<Text> row_hears(const Wx& wx) {
    auto from_updated = fold(filter(wx.gns, [&](const Gn& g) { return g.kind == GnKind(GnKind::GnUpdated{}); }), Array<Read>{}, [&](const Array<Read>& acc, const Gn& g) { return union_reads(acc, reads_closed(wx.dyn_reads, g.reads)); });
    auto from_rows = fold(wx.row_marks, Array<Read>{}, [&](const Array<Read>& acc, const RowMarks& rm) { return union_reads(acc, reads_closed(wx.dyn_reads, append(rm.reads, each(rm.wrote, [&](const Text& m) { return Read(Read::OwnRead{m}); })))); });
    return fold(union_reads(from_updated, from_rows), Array<Text>{}, [&](const Array<Text>& acc, const Read& r) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            if (prism_rtl::is<Read::ParentRead>(r)) {
                auto&& m = prism_rtl::as<Read::ParentRead>(r).a0;
                _v.set(check_types::add_text(acc, m));
                goto _done;
            }
            if (prism_rtl::is<Read::OwnRead>(r)) {
                _v.set(acc);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
}


/// RowWritten: fn Wx, RowMarks, Read -> [Do]
Array<Do> row_written(const Wx& wx, const RowMarks& rm, const Read& r) {
    auto dirty_1 = has_read(reads_closed(wx.dyn_reads, rm.reads), r)
        ? Array(std::vector{Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XCx{})), Text("dirty"), Array(std::vector{Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{Text("row")}))})})})})})
        : Array<Do>{};
    auto told = fold(rm.wrote, Array<Do>{}, [&](const Array<Do>& acc, const Text& m) {
        return has_read(reads_closed(wx.dyn_reads, Array(std::vector{Read(Read::OwnRead{m})})), r)
            ? prelude::push(acc, Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text("row")})), prism_rtl::cat("parent_wrote_", m), Array(std::vector{Ex(Ex::XCx{})})})}))
            : acc;
    });
    auto body = append(dirty_1, told);
    return len(body) == Nat(0u)
        ? Array<Do>{}
        : ({
        __label__ _done;
        prism_rtl::Slot<Array<Do>> _v;
        auto&& _m = rm.kind;
        if (prism_rtl::is<RowKind::GenerationRow>(_m)) {
            _v.set(Array(std::vector{Do(Do::DoIfLet{Pa(Pa::PaCtor{Text("Some"), Array(std::vector{Pa(Pa::PaBind{Text("row")})})}), Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), rm.builder})), Text("borrow"), Array<Ex>{}})), Text("as_ref"), Array<Ex>{}}), body, Array<Do>{}})}));
            goto _done;
        }
        {
            _v.set(Array(std::vector{Do(Do::DoFor{Pa(Pa::PaBind{Text("row")}), Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), rm.builder})), Text("borrow"), Array<Ex>{}})), Text("values"), Array<Ex>{}}), body})}));
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// PatchPlace: fn Wx, Place -> [Do]
Array<Do> patch_place(const Wx& wx, const Place& p_) {
    auto pull = Do(Do::DoLet{Pa(Pa::PaBind{p_.getter}), Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XSelf{})), p_.getter, Array(std::vector{Ex(Ex::XCx{})})})});
    auto at = place_at(wx, Text("self"), p_.pos);
    return Array(std::vector{pull, Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XCx{})), Text("changed"), Array(std::vector{at, Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{p_.getter})), Text("to_pod"), Array<Ex>{}})})})})});
}


/// Emits: fn Wx, Pos -> Bool
bool emits(const Wx& wx, const Pos_& pos) {
    return (pos.scope == Nat(0u)) && (wx.hosted_by == std::optional<Text>{});
}


/// ResultTold: fn Ex -> [Do]
Array<Do> result_told(const Ex& node_) {
    auto r_1 = Do(Do::DoLet{Pa(Pa::PaBind{Text("r")}), Ex(Ex::XMethod{prism_rtl::rc(node_), Text("result_value"), Array(std::vector{Ex(Ex::XCx{})})})});
    return Array(std::vector{r_1, result_kept(node_), result_tell()});
}


/// ResultMoved: fn Ex -> [Do]
Array<Do> result_moved(const Ex& node_) {
    auto r_1 = Do(Do::DoLet{Pa(Pa::PaBind{Text("r")}), Ex(Ex::XMethod{prism_rtl::rc(node_), Text("result_value"), Array(std::vector{Ex(Ex::XCx{})})})});
    auto last = Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(node_), Text("result_last")})), Text("borrow"), Array<Ex>{}})), Text("as_ref"), Array<Ex>{}});
    auto differs = Ex(Ex::XBin{Text("!="), prism_rtl::rc(last), prism_rtl::rc(Ex(Ex::XCtor{Text("Some"), Array(std::vector{Ex(Ex::XRef{prism_rtl::rc(Ex(Ex::XVar{Text("r")}))})})}))});
    return Array(std::vector{r_1, Do(Do::DoIf{differs, Array(std::vector{result_kept(node_), result_tell()}), Array<Do>{}})});
}


/// ResultKept: fn Ex -> Do
Do result_kept(const Ex& node_) {
    return Do(Do::DoAssign{Ex(Ex::XDeref{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(node_), Text("result_last")})), Text("borrow_mut"), Array<Ex>{}}))}), Ex(Ex::XCtor{Text("Some"), Array(std::vector{Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{Text("r")}))})})})});
}


/// let resultTell
Do result_tell() {
    return Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XCx{})), Text("result"), Array(std::vector{Ex(Ex::XCtor{Text("Outcome::Value"), Array(std::vector{Ex(Ex::XVar{Text("r")})})})})})});
}


/// Adoption: fn FlatDef -> [Do]
Array<Do> adoption(const FlatDef& fl) {
    auto adopt = Ex(Ex::XLater{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text("node")})), prism_rtl::cat(fl.name, "_adopt"), Array(std::vector{Ex(Ex::XCx{})})}))});
    return Array(std::vector{Do(Do::DoLet{Pa(Pa::PaBind{Text("node")}), Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XSelf{}))})}), Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XCx{})), Text("answer_later"), Array(std::vector{adopt})})})});
}


/// PlaceAt: fn Wx, Text, Pos -> Ex
Ex place_at(const Wx& wx, const Text& recv, const Pos_& pos) {
    auto at = Array(std::vector{Ex(Ex::XIndex{pos.at})});
    return emits(wx, pos)
        ? Ex(Ex::XMethod{prism_rtl::rc(recv == Text("")
        ? Ex(Ex::XVar{Text("path")})
        : recv == Text("self")
        ? Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), Text("path")})
        : Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XVar{recv})), Text("path")})), Text("at"), at})
        : Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XCall{Text("Path::root"), Array<Ex>{}})), Text("at"), at});
}


/// PosPat: fn Pos, [Pa] -> Pa
Pa pos_pat(const Pos_& pos, const Array<Pa>& tail_) {
    return Pa(Pa::PaSlice{append(Array(std::vector{Pa(Pa::PaCtor{Text("Segment::Pos"), Array(std::vector{Pa(Pa::PaIndex{pos.at})})})}), tail_)});
}


/// let keyTail
Array<Pa> key_tail() {
    return Array(std::vector{Pa(Pa::PaCtor{Text("Segment::Key"), Array(std::vector{Pa(Pa::PaBind{Text("k")})})}), Pa(Pa::PaRest{Text("rest")})});
}


/// let genTail
Array<Pa> gen_tail() {
    return Array(std::vector{Pa(Pa::PaCtor{Text("Segment::Gen"), Array(std::vector{Pa(Pa::PaBind{Text("g")})})}), Pa(Pa::PaRest{Text("rest")})});
}


/// ?HostedRows: fn Wx -> ?Text
std::optional<Text> hosted_rows(const Wx& wx) {
    return wx.pos.scope > Nat(0u)
        ? std::optional(prism_rtl::cat(or_(index(wx.scopes, lexer::dec(wx.pos.scope)), Text("")), "_moved"))
        : ({
        __label__ _done;
        prism_rtl::Slot<std::optional<Text>> _v;
        auto&& _m = wx.hosted_by;
        if (prism_rtl::is_some(_m)) {
            _v.set(std::optional(Text("document_moved")));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(std::optional<Text>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// RootDynPatch: fn Wx -> [Do]
Array<Do> root_dyn_patch(const Wx& wx) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Array<Do>> _v;
        auto&& _m = wx.root_dyn;
        if (prism_rtl::is_some(_m)) {
            _v.set(Array(std::vector{Do(Do::DoLine{result_moved(Ex(Ex::XSelf{}))})}));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Array<Do>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// AnswerArm: fn Wx, Pos, Nat, OutTy -> ((Pa, Ex))
std::tuple<Pa, Ex> answer_arm(const Wx& wx, const Pos_& pos, const Nat& id, const OutTy& t) {
    auto call = Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XSelf{})), gn_of(wx, id).name, Array(std::vector{Ex(Ex::XDecode{t, prism_rtl::rc(Ex(Ex::XVar{Text("v")}))}), Ex(Ex::XCx{})})});
    return std::tuple{pos_pat(pos, Array<Pa>{}), call};
}


/// TypedAnswerArm: fn Wx, Pos, Nat, Text -> ((Pa, [Do]))
std::tuple<Pa, Array<Do>> typed_answer_arm(const Wx& wx, const Pos_& pos, const Nat& id, const Text& acc) {
    return std::tuple{pos_pat(pos, Array<Pa>{}), Array(std::vector{self_call(gn_of(wx, id).name, Array(std::vector{try_of(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text("v")})), acc, Array<Ex>{}}))}))})};
}


/// TypedDynArm: fn Sinks, Pos, Text, Text -> ((Pa, [Do]))
std::tuple<Pa, Array<Do>> typed_dyn_arm(const Sinks& sk, const Pos_& pos, const Text& f, const Text& acc) {
    return std::tuple{pos_pat(pos, Array<Pa>{}), dyn_place_write(sk, f, try_of(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text("v")})), acc, Array<Ex>{}})))};
}


/// TypedForwardArm: fn ForDef, Ex -> ((Pa, [Do]))
std::tuple<Pa, Array<Do>> typed_forward_arm(const ForDef& b, const Ex& segs) {
    auto row_of = Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(b.name)})), Text("borrow"), Array<Ex>{}})), Text("get"), Array(std::vector{Ex(Ex::XRef{prism_rtl::rc(Ex(Ex::XDecode{b.key_ty, prism_rtl::rc(Ex(Ex::XVar{Text("k")}))}))})})})), Text("cloned"), Array<Ex>{}});
    return std::tuple{pos_pat(b.pos, key_tail()), Array(std::vector{Do(Do::DoLet{Pa(Pa::PaBind{Text("row")}), row_of}), Do(Do::DoMatch{Ex(Ex::XVar{Text("row")}), Array(std::vector{std::tuple{Pa(Pa::PaCtor{Text("Some"), Array(std::vector{Pa(Pa::PaBind{Text("row")})})}), Array(std::vector{Do(Do::DoExpr{try_of(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text("row")})), Text("deliver"), Array(std::vector{Ex(Ex::XVar{Text("rest")}), Ex(Ex::XVar{Text("v")}), Ex(Ex::XCx{})})}))})})}, std::tuple{Pa(Pa::PaUnit{Text("None")}), Array(std::vector{Do(Do::DoReturn{Ex(Ex::XCtor{Text("Err"), Array(std::vector{Ex(Ex::XCall{Text("Fault::answer"), Array(std::vector{Ex(Ex::XFormatStr{Array(std::vector{Ex(Ex::XText{Text("no row ")}), Ex(Ex::XVar{Text("k")}), Ex(Ex::XText{Text(" under the hosted place ")}), Ex(Ex::XCtor{Text("Path"), Array(std::vector{Ex(Ex::XMethod{prism_rtl::rc(segs), Text("to_vec"), Array<Ex>{}})})})})})})})})})})})}})})})};
}


/// TypedGenArm: fn GenDef -> ((Pa, [Do]))
std::tuple<Pa, Array<Do>> typed_gen_arm(const GenDef& gd) {
    auto current = Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(gd.name)})), Text("borrow"), Array<Ex>{}}))});
    auto is_current = Ex(Ex::XBin{Text("=="), prism_rtl::rc(Ex(Ex::XBin{Text("+"), prism_rtl::rc(Ex(Ex::XDeref{prism_rtl::rc(Ex(Ex::XVar{Text("g")}))})), prism_rtl::rc(Ex(Ex::XIndex{Nat(1u)}))})), prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(gd.name, "_count")})), Text("get"), Array<Ex>{}}))});
    return std::tuple{pos_pat(gd.pos, gen_tail()), Array(std::vector{Do(Do::DoLet{Pa(Pa::PaBind{Text("row")}), current}), Do(Do::DoIfLet{Pa(Pa::PaCtor{Text("Some"), Array(std::vector{Pa(Pa::PaBind{Text("row")})})}), Ex(Ex::XVar{Text("row")}), Array(std::vector{Do(Do::DoIf{is_current, Array(std::vector{Do(Do::DoExpr{try_of(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text("row")})), Text("deliver"), Array(std::vector{Ex(Ex::XVar{Text("rest")}), Ex(Ex::XVar{Text("v")}), Ex(Ex::XCx{})})}))})}), Array<Do>{}})}), Array<Do>{}})})};
}


/// TypedDispatch: fn Sinks, Text, Nat -> MethDef
MethDef typed_dispatch(const Sinks& sk, const Text& name, const Nat& scope) {
    auto wx = sk.wx;
    auto in_scope_fn = ({
        auto scope_1 = scope;
        (prism_rtl::rc([=](const Pos_& p_) { return p_.scope == scope_1; }));
    });
    auto [recv, param, segs, doc] = scope > Nat(0u)
        ? std::tuple{Recv(Recv::RecvRc{}), std::tuple{Text("place"), OutTy(OutTy::OutRef{prism_rtl::rc(OutTy(OutTy::OutPath{}))})}, Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text("place")})), Text("segments"), Array<Ex>{}}), prism_rtl::cat("The host at place ", place_text(or_(index(wx.hosts, lexer::dec(scope)), dummy_host()).pos), " answers its child's place `place` (pick HO): into the child's input method, a hold the place's element answers, or the row of a `for` or `rebuild` under it.")}
        : std::tuple{Recv(Recv::RecvOwned{}), std::tuple{Text("at"), OutTy(OutTy::OutRef{prism_rtl::rc(OutTy(OutTy::OutSlice{prism_rtl::rc(OutTy(OutTy::OutNamed{Text("Segment"), Array<OutTy>{}}))}))})}, Ex(Ex::XVar{Text("at")}), Text("A host's answer to a place of this row's own, `at` under the row (pick HO): into the input method, a hold, or a row under it.")};
    auto answers = each(filter(wx.answers, [&](const std::tuple<Pos_, Nat, OutTy, Text>& _p0) {
        auto&& pos = std::get<0>(_p0);
        return in_scope_fn(pos);
    }), [&](const std::tuple<Pos_, Nat, OutTy, Text>& _p0) {
        auto&& pos = std::get<0>(_p0);
        auto&& id = std::get<1>(_p0);
        auto&& acc = std::get<3>(_p0);
        return typed_answer_arm(wx, pos, id, acc);
    });
    auto dyns = each(filter(wx.dyn_places, [&](const std::tuple<Pos_, Text, OutTy, Text>& _p0) {
        auto&& pos = std::get<0>(_p0);
        return in_scope_fn(pos);
    }), [&](const std::tuple<Pos_, Text, OutTy, Text>& _p0) {
        auto&& pos = std::get<0>(_p0);
        auto&& f = std::get<1>(_p0);
        auto&& acc = std::get<3>(_p0);
        return typed_dyn_arm(sk, pos, f, acc);
    });
    auto rows = each(filter(wx.builders, [&](const ForDef& b) { return in_scope_fn(b.pos); }), [&](const ForDef& b) { return typed_forward_arm(b, segs); });
    auto gens = each(filter(wx.gens, [&](const GenDef& gd) { return in_scope_fn(gd.pos); }), [&](const GenDef& gd) { return typed_gen_arm(gd); });
    auto none = std::tuple{Pa(Pa::PaWild{}), Array(std::vector{Do(Do::DoReturn{Ex(Ex::XCtor{Text("Err"), Array(std::vector{Ex(Ex::XCall{Text("Fault::answer"), Array(std::vector{Ex(Ex::XFormatStr{Array(std::vector{Ex(Ex::XText{Text("no hosted place at ")}), Ex(Ex::XCtor{Text("Path"), Array(std::vector{Ex(Ex::XMethod{prism_rtl::rc(segs), Text("to_vec"), Array<Ex>{}})})}), Ex(Ex::XText{Text(" to answer")})})})})})})})})})};
    auto arms = prelude::push(append(append(append(answers, dyns), rows), gens), none);
    return MethDef{.name = name, .recv = recv, .params = Array(std::vector{param, std::tuple{Text("v"), OutTy(OutTy::OutRef{prism_rtl::rc(answer_ty_value())})}}), .cx_ = CxArg(CxArg::CxMut{}), .ret = OutTy(OutTy::OutNamed{Text("Done"), Array<OutTy>{}}), .body = Array(std::vector{Do(Do::DoMatch{segs, arms})}), .tail = Ex(Ex::XCtor{Text("Ok"), Array(std::vector{Ex(Ex::XUnit{})})}), .doc = doc};
}


/// let dummyHost
HostDef dummy_host() {
    return HostDef{.pos = pos0(), .name = Text(""), .scope = Nat(0u)};
}


/// SortNats: fn [Nat] -> [Nat]
Array<Nat> sort_nats(const Array<Nat>& xs) {
    return fold(xs, Array<Nat>{}, [&](const Array<Nat>& acc, const Nat& x) { return append(prelude::push(filter(acc, [&](const Nat& y) { return y < x; }), x), filter(acc, [&](const Nat& y) { return !(y < x); })); });
}


/// AskWake: fn Sinks, Nat -> [Do]
Array<Do> ask_wake(const Sinks& sk, const Nat& h) {
    auto c = Ex(Ex::XConst{wake_const(sk.heights, h)});
    auto ask_1 = Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), Text("wakes")})), Text("ask"), Array(std::vector{c})})});
    auto wake_2 = Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XCx{})), Text("wake"), Array(std::vector{c, Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XSelf{}))})})})});
    return sk.many ? Array(std::vector{ask_1, wake_2}) : Array(std::vector{wake_2});
}


/// GatherIn: fn Sinks, Gn -> MethDef
MethDef gather_in(const Sinks& sk, const Gn& g) {
    auto field = or_(index(g.inputs, Nat(0u)), Text(""));
    auto kt = ({
        __label__ _done;
        prism_rtl::Slot<OutTy> _v;
        auto&& _m = g.ty;
        if (prism_rtl::is<OutTy::OutMap>(_m)) {
            auto&& k = prism_rtl::as<OutTy::OutMap>(_m).a0;
            _v.set(k);
            goto _done;
        }
        {
            _v.set(OutTy(OutTy::OutUnit{}));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto vt = ({
        __label__ _done;
        prism_rtl::Slot<OutTy> _v;
        auto&& _m = g.ty;
        if (prism_rtl::is<OutTy::OutMap>(_m)) {
            auto&& v_ = prism_rtl::as<OutTy::OutMap>(_m).a1;
            _v.set(v_);
            goto _done;
        }
        {
            _v.set(OutTy(OutTy::OutUnit{}));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto current = Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(field)})), Text("get"), Array(std::vector{Ex(Ex::XCx{})})})), Text("unwrap_or_default"), Array<Ex>{}});
    auto collect = Array(std::vector{Do(Do::DoLet{Pa(Pa::PaMut{Text("all")}), current}), Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text("all")})), Text("insert"), Array(std::vector{Ex(Ex::XVar{Text("k")}), Ex(Ex::XVar{Text("v")})})})}), Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(field)})), Text("set"), Array(std::vector{Ex(Ex::XVar{Text("all")}), Ex(Ex::XCx{})})})})});
    auto body = append(collect, ask_wake(sk, g.height));
    return MethDef{.name = prism_rtl::cat(g.name, "_in"), .recv = Recv(Recv::RecvRc{}), .params = Array(std::vector{std::tuple{Text("k"), kt}, std::tuple{Text("v"), vt}}), .cx_ = CxArg(CxArg::CxMut{}), .ret = OutTy(OutTy::OutUnit{}), .body = body, .tail = Ex(Ex::XUnit{}), .doc = Text("A row's firing, gathered by its key.")};
}


/// Decide: fn Gn -> Do
Do decide(const Gn& g) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Do> _v;
        auto&& _m = g.kind;
        if (prism_rtl::is<GnKind::GnGather>(_m)) {
            _v.set(Do(Do::DoIfLet{Pa(Pa::PaCtor{Text("Some"), Array(std::vector{Pa(Pa::PaBind{Text("v")})})}), Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(or_(index(g.inputs, Nat(0u)), Text("")))})), Text("take"), Array(std::vector{Ex(Ex::XCx{})})}), Array(std::vector{self_call(g.name, Array(std::vector{Ex(Ex::XVar{Text("v")})}))}), Array<Do>{}}));
            goto _done;
        }
        if (prism_rtl::is<GnKind::GnMerge>(_m)) {
            _v.set(merge_decide(g));
            goto _done;
        }
        if (prism_rtl::is<GnKind::GnUpdated>(_m)) {
            _v.set(updated_decide(g));
            goto _done;
        }
        if (prism_rtl::is<GnKind::GnMergeAll>(_m)) {
            _v.set(({
                auto pushes = each(g.inputs, [&](const Text& f) { return Do(Do::DoIfLet{Pa(Pa::PaCtor{Text("Some"), Array(std::vector{Pa(Pa::PaBind{Text("x")})})}), Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(f)})), Text("take"), Array(std::vector{Ex(Ex::XCx{})})}), Array(std::vector{Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text("all")})), Text("push_back"), Array(std::vector{Ex(Ex::XVar{Text("x")})})})})}), Array<Do>{}}); });
                auto start = Do(Do::DoLet{Pa(Pa::PaTyped{prism_rtl::rc(Pa(Pa::PaMut{Text("all")})), g.ty}), Ex(Ex::XCall{Text("Array::new"), Array<Ex>{}})});
                auto fire = Do(Do::DoIf{Ex(Ex::XUnary{Text("!"), prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text("all")})), Text("is_empty"), Array<Ex>{}}))}), Array(std::vector{self_call(g.name, Array(std::vector{Ex(Ex::XVar{Text("all")})}))}), Array<Do>{}});
                (Do(Do::DoIf{Ex(Ex::XBool{true}), prelude::push(append(Array(std::vector{start}), pushes), fire), Array<Do>{}}));
            }));
            goto _done;
        }
        {
            auto&& kind = _m;
            _v.set(pair_decide(g, kind));
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// UpdatedDecide: fn Gn -> Do
Do updated_decide(const Gn& g) {
    return Do(Do::DoIf{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(g.name, "_moved")})), Text("replace"), Array(std::vector{Ex(Ex::XBool{false})})}), Array(std::vector{Do(Do::DoLet{Pa(Pa::PaBind{Text("after")}), Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XCx{})), Text("after"), Array(std::vector{Ex(Ex::XClosure{false, Array(std::vector{Pa(Pa::PaBind{Text("cx")})}), prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(g.name, "_value"), Array(std::vector{Ex(Ex::XCx{})})}))})})})}), self_call(g.name, Array(std::vector{Ex(Ex::XVar{Text("after")})}))}), Array<Do>{}});
}


/// PairDecide: fn Gn, GnKind -> Do
Do pair_decide(const Gn& g, const GnKind& kind) {
    auto get_l = Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(or_(index(g.inputs, Nat(0u)), Text("")))})), Text("take"), Array(std::vector{Ex(Ex::XCx{})})});
    auto get_r = Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(or_(index(g.inputs, Nat(1u)), Text("")))})), Text("take"), Array(std::vector{Ex(Ex::XCx{})})});
    auto both_ = Ex(Ex::XTuple{Array(std::vector{get_l, get_r})});
    auto fire_fn = ({
        auto g_1 = g;
        (prism_rtl::rc([=](const Ex& x) { return Array(std::vector{self_call(g_1.name, Array(std::vector{x}))}); }));
    });
    auto sa = Pa(Pa::PaCtor{Text("Some"), Array(std::vector{Pa(Pa::PaBind{Text("a")})})});
    auto sb = Pa(Pa::PaCtor{Text("Some"), Array(std::vector{Pa(Pa::PaBind{Text("b")})})});
    auto some2 = Pa(Pa::PaTuple{Array(std::vector{sa, sb})});
    auto left = Pa(Pa::PaTuple{Array(std::vector{sa, Pa(Pa::PaUnit{Text("None")})})});
    auto right = Pa(Pa::PaTuple{Array(std::vector{Pa(Pa::PaUnit{Text("None")}), sb})});
    auto cases = ({
        __label__ _done;
        prism_rtl::Slot<Array<std::tuple<Pa, Array<Do>>>> _v;
        if (prism_rtl::is<GnKind::GnUnion>(kind)) {
            _v.set(Array(std::vector{std::tuple{some2, fire_fn(Ex(Ex::XCall{Text("union"), Array(std::vector{Ex(Ex::XRef{prism_rtl::rc(Ex(Ex::XVar{Text("a")}))}), Ex(Ex::XRef{prism_rtl::rc(Ex(Ex::XVar{Text("b")}))})})}))}, std::tuple{left, fire_fn(Ex(Ex::XVar{Text("a")}))}, std::tuple{right, fire_fn(Ex(Ex::XVar{Text("b")}))}, std::tuple{Pa(Pa::PaWild{}), Array<Do>{}}}));
            goto _done;
        }
        if (prism_rtl::is<GnKind::GnBoth>(kind)) {
            _v.set(Array(std::vector{std::tuple{some2, fire_fn(Ex(Ex::XTuple{Array(std::vector{Ex(Ex::XVar{Text("a")}), Ex(Ex::XVar{Text("b")})})}))}, std::tuple{Pa(Pa::PaWild{}), Array<Do>{}}}));
            goto _done;
        }
        {
            _v.set(Array(std::vector{std::tuple{left, fire_fn(Ex(Ex::XVar{Text("a")}))}, std::tuple{Pa(Pa::PaWild{}), Array<Do>{}}}));
            goto _done;
        }
    _done:
        _v.take();
    });
    return Do(Do::DoMatch{both_, cases});
}


/// WakeByHeight: fn [Gn], [Nat] -> Do
Do wake_by_height(const Array<Gn>& combs, const Array<Nat>& heights_) {
    return Do(Do::DoMatch{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), Text("wakes")})), Text("next"), Array<Ex>{}}), prelude::push(each(heights_, [&](const Nat& h) { return std::tuple{Pa(Pa::PaConst{wake_const(heights_, h)}), each(filter(combs, [&](const Gn& g) { return g.height == h; }), [&](const Gn& g) { return decide(g); })}; }), std::tuple{Pa(Pa::PaWild{}), Array<Do>{}})});
}


/// ForwardAnswer: fn ForDef -> Ex
Ex forward_answer(const ForDef& b) {
    auto row_of = Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(b.name)})), Text("borrow"), Array<Ex>{}})), Text("get"), Array(std::vector{Ex(Ex::XRef{prism_rtl::rc(Ex(Ex::XDecode{b.key_ty, prism_rtl::rc(Ex(Ex::XVar{Text("k")}))}))})})})), Text("cloned"), Array<Ex>{}});
    return Ex(Ex::XBlock{Array(std::vector{Do(Do::DoLet{Pa(Pa::PaBind{Text("row")}), row_of}), Do(Do::DoIfLet{Pa(Pa::PaCtor{Text("Some"), Array(std::vector{Pa(Pa::PaBind{Text("row")})})}), Ex(Ex::XVar{Text("row")}), Array(std::vector{Do(Do::DoExpr{try_of(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text("row")})), Text("answer"), Array(std::vector{Ex(Ex::XVar{Text("rest")}), Ex(Ex::XVar{Text("v")}), Ex(Ex::XCx{})})}))})}), Array<Do>{}})}), prism_rtl::rc(Ex(Ex::XUnit{}))});
}


/// IsHold: fn OutTy -> Bool
bool is_hold(const OutTy& out_ty0) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        if (prism_rtl::is<OutTy::OutHold>(out_ty0)) {
            _v.set(true);
            goto _done;
        }
        {
            auto&& other = out_ty0;
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// RowMethods: fn Wx -> [MethDef]
Array<MethDef> row_methods(const Wx& wx) {
    auto removes = each(filter(wx.places, [&](const Place& p_) { return emits(wx, p_.pos); }), [&](const Place& p_) { return Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XCx{})), Text("removed"), Array(std::vector{place_at(wx, Text("self"), p_.pos)})})}); });
    auto nested = append(each(wx.builders, [&](const ForDef& b) { return Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), b.name})), Text("borrow"), Array<Ex>{}})), Text("values"), Array<Ex>{}})), Text("for_each"), Array(std::vector{Ex(Ex::XClosure{false, Array(std::vector{Pa(Pa::PaBind{Text("row")})}), prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text("row")})), Text("leave_row"), Array(std::vector{Ex(Ex::XCx{})})}))})})})}); }), each(wx.gens, [&](const GenDef& gd) { return Do(Do::DoIfLet{Pa(Pa::PaCtor{Text("Some"), Array(std::vector{Pa(Pa::PaBind{Text("row")})})}), Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), gd.name})), Text("borrow"), Array<Ex>{}})), Text("as_ref"), Array<Ex>{}}), Array(std::vector{Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text("row")})), Text("leave_row"), Array(std::vector{Ex(Ex::XCx{})})})})}), Array<Do>{}}); }));
    return Array(std::vector{MethDef{.name = Text("remove_places"), .recv = Recv(Recv::RecvRef{}), .params = Array<std::tuple<Text, OutTy>>{}, .cx_ = CxArg(CxArg::CxMut{}), .ret = OutTy(OutTy::OutUnit{}), .body = append(removes, nested), .tail = Ex(Ex::XUnit{}), .doc = Text("The row left: its places are torn down.")}});
}


/// GnDoc: fn Gn -> Text
Text gn_doc(const Gn& g) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = g.kind;
        if (prism_rtl::is<GnKind::GnAnswer>(_m)) {
            _v.set(prism_rtl::cat("`", g.name, "`: an answer at its place."));
            goto _done;
        }
        if (prism_rtl::is<GnKind::GnStarted>(_m)) {
            _v.set(Text("`@started`, the tick after the build."));
            goto _done;
        }
        if (prism_rtl::is<GnKind::GnDeferred>(_m)) {
            _v.set(Text("An `@Defer` firing, the tick after it was armed."));
            goto _done;
        }
        if (prism_rtl::is<GnKind::GnMerge>(_m)) {
            _v.set(prism_rtl::cat("The merge `", g.name, "`, decided in the wake."));
            goto _done;
        }
        if (prism_rtl::is<GnKind::GnUpdated>(_m)) {
            _v.set(Text("`!Updated`: the dynamic's value after the tick, fired in the wake when a hold it reads was written (or a structural dynamic it reads was published, pick ST)."));
            goto _done;
        }
        {
            _v.set(prism_rtl::cat("`!", g.name, "`."));
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// MergeDecide: fn Gn -> Do
Do merge_decide(const Gn& g) {
    auto call = Array(std::vector{self_call(g.name, Array(std::vector{Ex(Ex::XVar{Text("v")})}))});
    auto take_l = Do(Do::DoLet{Pa(Pa::PaBind{Text("left")}), Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(or_(index(g.inputs, Nat(0u)), Text("")))})), Text("take"), Array(std::vector{Ex(Ex::XCx{})})})});
    auto take_r = Do(Do::DoLet{Pa(Pa::PaBind{Text("right")}), Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(or_(index(g.inputs, Nat(1u)), Text("")))})), Text("take"), Array(std::vector{Ex(Ex::XCx{})})})});
    auto right_1 = Do(Do::DoIfLet{Pa(Pa::PaCtor{Text("Some"), Array(std::vector{Pa(Pa::PaBind{Text("v")})})}), Ex(Ex::XVar{Text("right")}), call, Array<Do>{}});
    return Do(Do::DoIf{Ex(Ex::XBool{true}), Array(std::vector{take_l, take_r, Do(Do::DoIfLet{Pa(Pa::PaCtor{Text("Some"), Array(std::vector{Pa(Pa::PaBind{Text("v")})})}), Ex(Ex::XVar{Text("left")}), call, Array(std::vector{right_1})})}), Array<Do>{}});
}


/// InModule: fn Lx, Nat, Text -> Lx
Lx in_module(const Lx& lx, const Nat& file, const Text& home) {
    Lx this_ = lx;
    this_.file = file;
    this_.home = home;
    this_.site = home;
    return this_;
}


/// InModuleAt: fn Lx, Nat, Text, Text -> Lx
Lx in_module_at(const Lx& lx, const Nat& file, const Text& home, const Text& site) {
    Lx this_ = lx;
    this_.file = file;
    this_.home = home;
    this_.site = site;
    return this_;
}


/// LowerProgram: unbounded fn [Src], [Module], Nat, TProgram, Text -> Model
Model lower_program(const Array<check_errors::Src>& srcs, const Array<ast::Module>& trees, const Nat& shown, const typed::TProgram& tp, const Text& name) {
    auto&& _g = check_env::build_g(srcs, trees);
    auto&& g = std::get<0>(_g);
    auto [tys, apps, bs, ims] = typed_tables(tp);
    auto gens = fold(tp.gens, Map<Text, typed::GenNote>{}, [&](const Map<Text, typed::GenNote>& m, const typed::GenNote& n) { return insert(m, typed::at_key(n.at), n); });
    auto insts = fold(tp.insts, Map<Text, Array<typed::InstNote>>{}, [&](const Map<Text, Array<typed::InstNote>>& m, const typed::InstNote& n) { return insert(m, inst_key(n), prelude::push(or_(prelude::get(m, inst_key(n)), Array<typed::InstNote>{}), n)); });
    auto quants = fold(tp.gens, Map<Text, Text>{}, [&](const Map<Text, Text>& m, const typed::GenNote& n) { return fold(append(n.tys, n.cols), m, [&](const Map<Text, Text>& m2, const Text& q) { return insert(m2, q, n.name); }); });
    auto gen_of_q = fold(tp.gens, Map<Text, typed::GenNote>{}, [&](const Map<Text, typed::GenNote>& m, const typed::GenNote& n) { return fold(append(n.tys, n.cols), m, [&](const Map<Text, typed::GenNote>& m2, const Text& q) { return insert(m2, q, n); }); });
    auto use_insts = fold(tp.insts, Map<Text, typed::InstNote>{}, [&](const Map<Text, typed::InstNote>& m, const typed::InstNote& n) { return insert(m, typed::at_key(n.at), n); });
    auto mods = needed_mods(g, shown);
    auto rs_mods = fold(mods, Map<Text, Text>{}, [&](const Map<Text, Text>& acc, const Text& m) { return insert(acc, m, rust_mod_name(m)); });
    auto lx0 = Lx{.g = g, .tys = tys, .apps = apps, .binders = bs, .impls = ims, .file = Nat(0u), .home = Text(""), .site = Text(""), .rs_mods = rs_mods, .rs_names = value_names(g), .layouts = layouts(g), .unbs = Array<Text>{}, .notes = Array<Text>{}, .globals = global_names(g), .in_node = false, .unshrunk = fold(tp.unshrunk, Map<Text, bool>{}, [&](const Map<Text, bool>& m, const typed::At& a) { return insert(m, typed::at_key(a), true); }), .gens = gens, .insts = insts, .quants = quants, .gen_of_q = gen_of_q, .use_insts = use_insts, .subst = Map<Text, check_types::Ty>{}, .csubst = Map<Text, check_types::Col>{}};
    auto lx = ({
        Lx this_ = lx0;
        this_.unbs = job_roots(lx0);
        this_;
    });
    auto roots = root_widgets(lx);
    auto mod_defs = run_to_end(each_job(mods, ({
        auto lx_1 = lx;
        auto roots_2 = roots;
        auto g_3 = g;
        auto mods_4 = mods;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<ModDef>(Text)>>(prism_rtl::rc([=](Text p0) {
        return ({
            auto lx_1_5 = lx_1;
            auto roots_2_5 = roots_2;
            auto g_3_5 = g_3;
            auto mods_4_5 = mods_4;
            entered(once_job([=]() {
            return ({
                auto m = p0;
                (prism_rtl::more(prism_rtl::rc(ModDefOf(lx_1_5, m, roots_2_5, or_(prelude::get(g_3_5.mods, m), check_env::dummy_mod()), mods_4_5))));
            });
        }));
        });
    })));
    })));
    auto programs = run_to_end(each_job(roots, ({
        auto lx_1 = lx;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<ProgDef>(std::tuple<Text, bool>)>>(prism_rtl::rc([=](std::tuple<Text, bool> p0) {
        return ({
            auto lx_1_2 = lx_1;
            entered(once_job([=]() {
            return ({
                auto&& _qk = p0;
                auto&& qk = std::get<0>(_qk);
                (prism_rtl::more(prism_rtl::rc(ProgDefOf(lx_1_2, qk))));
            });
        }));
        });
    })));
    })));
    auto main_qk = fold(g.defs, Text(""), [&](const Text& found, const check_env::Def& d) { return (found == Text("")) && is_main(d.qk) ? d.qk : found; });
    auto root_opt = main_qk == Text("")
        ? std::optional<ProgDef>{}
        : std::optional(prog_def_of(lx, main_qk));
    auto checks = run_to_end(fold_job(g.defs, Array<CheckDef>{}, ({
        auto lx_1 = lx;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<CheckDef>>(std::tuple<Array<CheckDef>, check_env::Def>)>>(prism_rtl::rc([=](std::tuple<Array<CheckDef>, check_env::Def> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_1_2 = lx_1;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto d = p1;
                ({
                auto&& _m = d.body;
                prism_rtl::is<check_env::DefBody::DbCheck>(_m) ? ({
                auto&& c = prism_rtl::as<check_env::DefBody::DbCheck>(_m).a0;
                ({
                auto c_2 = c;
                call_then(start_check_def_of(in_module_at(lx_1_2, d->file, d.home, Text("\000main"sv)), c_2), [=](CheckDef check_def_of_305060) { return prism_rtl::finished(prelude::push(acc, check_def_of_305060)); });
            });
            })
                : prism_rtl::finished(acc);
            });
            });
        }));
        });
    })));
    })));
    return Model{.name = name, .mods = mod_defs, .programs = programs, .root = root_opt, .checks = checks, .elem = elem_row(lx, mods), .answer = answer_enum(in_module_at(lx, Nat(0u), Text(""), Text("\000main"sv)), mods), .scripts = Array<Text>{}, .notes = Array<Text>{}};
}


prism_rtl::Turn<Model> LowerProgram::cycle() const {
    const auto& srcs = this->srcs;
    const auto& trees = this->trees;
    const auto& shown = this->shown;
    const auto& tp = this->tp;
    const auto& name = this->name;
    auto name_1 = name;
    auto shown_2 = shown;
    auto srcs_3 = srcs;
    auto tp_4 = tp;
    auto trees_5 = trees;
    return call_then(check_env::start_build_g(srcs_3, trees_5), [=](std::tuple<check_env::G, check_types::St> build_g_303569) {
        return ({
            auto&& _g = build_g_303569;
            auto&& g = std::get<0>(_g);
            auto [tys, apps, bs, ims] = typed_tables(tp_4);
            auto gens = fold(tp_4.gens, Map<Text, typed::GenNote>{}, [&](const Map<Text, typed::GenNote>& m, const typed::GenNote& n) { return insert(m, typed::at_key(n.at), n); });
            auto insts = fold(tp_4.insts, Map<Text, Array<typed::InstNote>>{}, [&](const Map<Text, Array<typed::InstNote>>& m, const typed::InstNote& n) { return insert(m, inst_key(n), prelude::push(or_(prelude::get(m, inst_key(n)), Array<typed::InstNote>{}), n)); });
            auto quants = fold(tp_4.gens, Map<Text, Text>{}, [&](const Map<Text, Text>& m, const typed::GenNote& n) { return fold(append(n.tys, n.cols), m, [&](const Map<Text, Text>& m2, const Text& q) { return insert(m2, q, n.name); }); });
            auto gen_of_q = fold(tp_4.gens, Map<Text, typed::GenNote>{}, [&](const Map<Text, typed::GenNote>& m, const typed::GenNote& n) { return fold(append(n.tys, n.cols), m, [&](const Map<Text, typed::GenNote>& m2, const Text& q) { return insert(m2, q, n); }); });
            auto use_insts = fold(tp_4.insts, Map<Text, typed::InstNote>{}, [&](const Map<Text, typed::InstNote>& m, const typed::InstNote& n) { return insert(m, typed::at_key(n.at), n); });
            call_then(start_needed_mods(g, shown_2), [=](Array<Text> needed_mods_304095) {
            return ({
                auto mods = needed_mods_304095;
                auto rs_mods = fold(mods, Map<Text, Text>{}, [&](const Map<Text, Text>& acc, const Text& m) { return insert(acc, m, rust_mod_name(m)); });
                call_then(start_layouts(g), [=](Map<Text, Array<bool>> layouts_304327) {
                return ({
                    auto lx0 = Lx{.g = g, .tys = tys, .apps = apps, .binders = bs, .impls = ims, .file = Nat(0u), .home = Text(""), .site = Text(""), .rs_mods = rs_mods, .rs_names = value_names(g), .layouts = layouts_304327, .unbs = Array<Text>{}, .notes = Array<Text>{}, .globals = global_names(g), .in_node = false, .unshrunk = fold(tp_4.unshrunk, Map<Text, bool>{}, [&](const Map<Text, bool>& m, const typed::At& a) { return insert(m, typed::at_key(a), true); }), .gens = gens, .insts = insts, .quants = quants, .gen_of_q = gen_of_q, .use_insts = use_insts, .subst = Map<Text, check_types::Ty>{}, .csubst = Map<Text, check_types::Col>{}};
                    auto lx = ({
                        Lx this_ = lx0;
                        this_.unbs = job_roots(lx0);
                        this_;
                    });
                    auto roots = root_widgets(lx);
                    call_value(each_job(mods, ({
                    auto lx_6 = lx;
                    auto roots_7 = roots;
                    auto g_8 = g;
                    auto mods_9 = mods;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<ModDef>(Text)>>(prism_rtl::rc([=](Text p0) {
                    return ({
                        auto lx_6_10 = lx_6;
                        auto roots_7_10 = roots_7;
                        auto g_8_10 = g_8;
                        auto mods_9_10 = mods_9;
                        entered(once_job([=]() {
                        return ({
                            auto m = p0;
                            (prism_rtl::more(prism_rtl::rc(ModDefOf(lx_6_10, m, roots_7_10, or_(prelude::get(g_8_10.mods, m), check_env::dummy_mod()), mods_9_10))));
                        });
                    }));
                    });
                })));
                })), [=](Array<ModDef> each_304669) {
                    return ({
                        auto mod_defs = each_304669;
                        call_value(each_job(roots, ({
                        auto lx_6 = lx;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<ProgDef>(std::tuple<Text, bool>)>>(prism_rtl::rc([=](std::tuple<Text, bool> p0) {
                        return ({
                            auto lx_6_7 = lx_6;
                            entered(once_job([=]() {
                            return ({
                                auto&& _qk = p0;
                                auto&& qk = std::get<0>(_qk);
                                (prism_rtl::more(prism_rtl::rc(ProgDefOf(lx_6_7, qk))));
                            });
                        }));
                        });
                    })));
                    })), [=](Array<ProgDef> each_304758) {
                        return ({
                            auto programs = each_304758;
                            auto main_qk = fold(g.defs, Text(""), [&](const Text& found, const check_env::Def& d) { return (found == Text("")) && is_main(d.qk) ? d.qk : found; });
                            auto root_opt = main_qk == Text("")
                                ? std::optional<ProgDef>{}
                                : std::optional(prog_def_of(lx, main_qk));
                            call_value(fold_job(g.defs, Array<CheckDef>{}, ({
                            auto lx_6 = lx;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<CheckDef>>(std::tuple<Array<CheckDef>, check_env::Def>)>>(prism_rtl::rc([=](std::tuple<Array<CheckDef>, check_env::Def> _p0) {
                            auto&& p0 = std::get<0>(_p0);
                            auto&& p1 = std::get<1>(_p0);
                            return ({
                                auto lx_6_7 = lx_6;
                                entered(once_job([=]() {
                                return ({
                                    auto acc = p0;
                                    auto d = p1;
                                    ({
                                    auto&& _m = d.body;
                                    prism_rtl::is<check_env::DefBody::DbCheck>(_m) ? ({
                                    auto&& c = prism_rtl::as<check_env::DefBody::DbCheck>(_m).a0;
                                    ({
                                    auto c_7 = c;
                                    call_then(start_check_def_of(in_module_at(lx_6_7, d->file, d.home, Text("\000main"sv)), c_7), [=](CheckDef check_def_of_305060) { return prism_rtl::finished(prelude::push(acc, check_def_of_305060)); });
                                });
                                })
                                    : prism_rtl::finished(acc);
                                });
                                });
                            }));
                            });
                        })));
                        })), [=](Array<CheckDef> fold_304987) {
                            return ({
                                auto checks = fold_304987;
                                call_then(start_elem_row(lx, mods), [=](RowDef elem_row_305230) { return call_then(start_answer_enum(in_module_at(lx, Nat(0u), Text(""), Text("\000main"sv)), mods), [=](AnswerDef answer_enum_305257) { return prism_rtl::finished(Model{.name = name_1, .mods = mod_defs, .programs = programs, .root = root_opt, .checks = checks, .elem = elem_row_305230, .answer = answer_enum_305257, .scripts = Array<Text>{}, .notes = Array<Text>{}}); }); });
                            });
                        });
                        });
                    });
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start LowerProgram, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Model> start_lower_program(Array<check_errors::Src> srcs, Array<ast::Module> trees, Nat shown, typed::TProgram tp, Text name) {
    return std::make_shared<LowerProgram>(srcs, trees, shown, tp, name);
}


/// NeededMods: unbounded fn G, Nat -> [Text]
Array<Text> needed_mods(const check_env::G& g, const Nat& shown) {
    auto own_ = filter(keys(g.mods), [&](const Text& m) { return (or_(prelude::get(g.mods, m), check_env::dummy_mod())->file < shown) && (m != Text("Prelude")); });
    auto grown = run_to_end(fold_job(check_errors::range0(Nat(6u)), own_, ({
        auto g_1 = g;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Nat>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_1_2 = g_1;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                static_cast<void>(p1);
                fold_job(acc, acc, ({
                auto g_1_2_2 = g_1_2;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Text>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, Text> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto g_1_2_2_2 = g_1_2_2;
                    entered(once_job([=]() {
                    return ({
                        auto a = p0;
                        auto m = p1;
                        call_then(start_mod_refs(g_1_2_2_2, m), [=](Array<Text> mod_refs_305753) { return prism_rtl::finished(check_types::union_texts(a, mod_refs_305753)); });
                    });
                }));
                });
            })));
            }))->cycle();
            });
        }));
        });
    })));
    })));
    return filter(keys(g.mods), [&](const Text& m) { return (m != Text("Prelude")) && check_types::has_text(grown, m); });
}


prism_rtl::Turn<Array<Text>> NeededMods::cycle() const {
    const auto& g = this->g;
    const auto& shown = this->shown;
    auto own_ = filter(keys(g.mods), [&](const Text& m) { return (or_(prelude::get(g.mods, m), check_env::dummy_mod())->file < shown) && (m != Text("Prelude")); });
    auto g_1 = g;
    return call_value(fold_job(check_errors::range0(Nat(6u)), own_, ({
        auto g_1_2 = g_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Nat>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_1_2_2 = g_1_2;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                static_cast<void>(p1);
                fold_job(acc, acc, ({
                auto g_1_2_2_2 = g_1_2_2;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Text>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, Text> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto g_1_2_2_2_2 = g_1_2_2_2;
                    entered(once_job([=]() {
                    return ({
                        auto a = p0;
                        auto m = p1;
                        call_then(start_mod_refs(g_1_2_2_2_2, m), [=](Array<Text> mod_refs_305753) { return prism_rtl::finished(check_types::union_texts(a, mod_refs_305753)); });
                    });
                }));
                });
            })));
            }))->cycle();
            });
        }));
        });
    })));
    })), [=](Array<Text> fold_305678) {
        return ({
            auto grown = fold_305678;
            (prism_rtl::finished(filter(keys(g_1.mods), [&](const Text& m) { return (m != Text("Prelude")) && check_types::has_text(grown, m); })));
        });
    });
}


/// `Start NeededMods, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_needed_mods(check_env::G g, Nat shown) {
    return std::make_shared<NeededMods>(g, shown);
}


/// ModRefs: unbounded fn G, Text -> [Text]
Array<Text> mod_refs(const check_env::G& g, const Text& m) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Array<Text>> _v;
        auto&& _m = prelude::get(g.mods, m);
        if (prism_rtl::is_some(_m)) {
            auto&& info = prism_rtl::some_of(_m);
            _v.set(({
                auto used = each(info.uses, [&](const std::tuple<Text, bool>& _p0) {
                    auto&& u = std::get<0>(_p0);
                    return u;
                });
                auto fams = ({
                    __label__ _done;
                    prism_rtl::Slot<Array<Text>> _v;
                    auto&& _m = info.tree.emit_row;
                    if (prism_rtl::is_some(_m)) {
                        auto&& rw = prism_rtl::some_of(_m);
                        _v.set(fold(rw.terms, Array<Text>{}, [&](const Array<Text>& acc, const ast::RowTerm& t) {
                            return ({
                                __label__ _done;
                                prism_rtl::Slot<Array<Text>> _v;
                                if (prism_rtl::is<ast::RowTerm::RFamily>(t)) {
                                    auto&& q = prism_rtl::as<ast::RowTerm::RFamily>(t).a0;
                                    _v.set(prelude::push(acc, or_(prelude::get(g.fam_owner, check_env::dotted(q->path_)), check_env::dotted(q->path_))));
                                    goto _done;
                                }
                                {
                                    _v.set(acc);
                                    goto _done;
                                }
                            _done:
                                _v.take();
                            });
                        }));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(Array<Text>{});
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                filter(append(used, fams), [&](const Text& x) { return check_env::has_key(g.mods, x); });
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Array<Text>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Array<Text>> ModRefs::cycle() const {
    const auto& g = this->g;
    const auto& m = this->m;
    return ({
        auto&& _m = prelude::get(g.mods, m);
        prism_rtl::is_some(_m) ? ({
        auto&& info = prism_rtl::some_of(_m);
        ({
        auto used = each(info.uses, [&](const std::tuple<Text, bool>& _p0) {
            auto&& u = std::get<0>(_p0);
            return u;
        });
        auto fams = ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = info.tree.emit_row;
            if (prism_rtl::is_some(_m)) {
                auto&& rw = prism_rtl::some_of(_m);
                _v.set(fold(rw.terms, Array<Text>{}, [&](const Array<Text>& acc, const ast::RowTerm& t) {
                    return ({
                        __label__ _done;
                        prism_rtl::Slot<Array<Text>> _v;
                        if (prism_rtl::is<ast::RowTerm::RFamily>(t)) {
                            auto&& q = prism_rtl::as<ast::RowTerm::RFamily>(t).a0;
                            _v.set(prelude::push(acc, or_(prelude::get(g.fam_owner, check_env::dotted(q->path_)), check_env::dotted(q->path_))));
                            goto _done;
                        }
                        {
                            _v.set(acc);
                            goto _done;
                        }
                    _done:
                        _v.take();
                    });
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(Array<Text>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        (prism_rtl::finished(filter(append(used, fams), [&](const Text& x) { return check_env::has_key(g.mods, x); })));
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(Array<Text>{})
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ModRefs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_mod_refs(check_env::G g, Text m) {
    return std::make_shared<ModRefs>(g, m);
}


/// RootWidgets: fn Lx -> [((Text, Bool))]
Array<std::tuple<Text, bool>> root_widgets(const Lx& lx) {
    auto tested = fold(lx.g.defs, Array<std::tuple<Text, bool>>{}, [&](const Array<std::tuple<Text, bool>>& acc, const check_env::Def& d) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<std::tuple<Text, bool>>> _v;
            auto&& _m = d.body;
            if (prism_rtl::is<check_env::DefBody::DbTest>(_m)) {
                auto&& t = prism_rtl::as<check_env::DefBody::DbTest>(_m).a0;
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Array<std::tuple<Text, bool>>> _v;
                    auto&& _m = blueprint_qk(in_module(lx, d->file, d.home), t.blueprint);
                    {
                        auto&& m306507_0 = _m;
                        if (m306507_0 == Text("")) {
                            _v.set(acc);
                            goto _done;
                        }
                    }
                    {
                        auto&& qk = _m;
                        _v.set(check_types::has_text(each(acc, [&](const std::tuple<Text, bool>& _p0) {
                            auto&& q = std::get<0>(_p0);
                            return q;
                        }), qk)
                            ? acc
                            : prelude::push(acc, std::tuple{qk, true}));
                        goto _done;
                    }
                _done:
                    _v.take();
                }));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto main = fold(lx.g.defs, Array<std::tuple<Text, bool>>{}, [&](const Array<std::tuple<Text, bool>>& acc, const check_env::Def& d) { return is_main(d.qk) ? prelude::push(acc, std::tuple{d.qk, false}) : acc; });
    return fold(main, tested, [&](const Array<std::tuple<Text, bool>>& acc, const std::tuple<Text, bool>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& b = std::get<1>(_p1);
        return check_types::has_text(each(acc, [&](const std::tuple<Text, bool>& _p0) {
            auto&& q = std::get<0>(_p0);
            return q;
        }), k)
            ? acc
            : prelude::push(acc, std::tuple{k, b});
    });
}


/// IsMain: fn Text -> Bool
bool is_main(const Text& qk) {
    return ((owner_of(qk) == Text("")) && (base(check_types::bare_name(qk)) == Text("main"))) && (take_text(check_types::bare_name(qk), Nat(1u)) == Text("@"));
}


/// BlueprintQk: fn Lx, Expr -> Text
Text blueprint_qk(const Lx& lx, const ast::Expr& e) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = e.kind;
        if (prism_rtl::is<ast::ExprKind::ECall>(_m)) {
            auto&& c = prism_rtl::as<ast::ExprKind::ECall>(_m).a0;
            _v.set(blueprint_qk(lx, c));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EGroup>(_m)) {
            auto&& x = prism_rtl::as<ast::ExprKind::EGroup>(_m).a0;
            _v.set(blueprint_qk(lx, x));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
            auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
            _v.set(({
                auto&& _q_opt = check_env::resolve_value(lx.g, lx.home, n);
                auto&& q_opt = std::get<0>(_q_opt);
                or_(q_opt, Text(""));
            }));
            goto _done;
        }
        {
            _v.set(Text(""));
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// ValOf: fn Lx, Text -> ValInfo
check_env::ValInfo val_of(const Lx& lx, const Text& qk) {
    return ({
        __label__ _done;
        prism_rtl::Slot<check_env::ValInfo> _v;
        auto&& _m = prelude::get(lx.g.vals, qk);
        if (prism_rtl::is_some(_m)) {
            auto&& v_ = prism_rtl::some_of(_m);
            _v.set(v_);
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(({
                auto d = fold(lx.g.defs, check_env::dummy_def(), [&](const check_env::Def& found, const check_env::Def& df) { return df.qk == qk ? df : found; });
                check_env::ValInfo{.qk = qk, .scheme = check_types::mono(check_types::Ty(check_types::Ty::TyErr{})), .sort = Text("fn"), .has_sig = false, .home = d.home, .file = d->file, .span = d.span};
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// ProgDefOf: unbounded fn Lx, Text -> ProgDef
ProgDef prog_def_of(const Lx& lx, const Text& qk) {
    auto v_ = val_of(lx, qk);
    auto ptys = ({
        __label__ _done;
        prism_rtl::Slot<Array<check_types::Ty>> _v;
        auto&& _m = v_.scheme.ty;
        if (prism_rtl::is<check_types::Ty::TyFn>(_m)) {
            auto&& ps = prism_rtl::as<check_types::Ty::TyFn>(_m).a1;
            _v.set(ps);
            goto _done;
        }
        {
            _v.set(Array<check_types::Ty>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto lxm = in_module_at(lx, v_->file, v_.home, Text("\000main"sv));
    auto params = run_to_end(each_job(check_errors::range0(len(ptys)), ({
        auto lxm_1 = lxm;
        auto ptys_2 = ptys;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, OutTy>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto lxm_1_3 = lxm_1;
            auto ptys_2_3 = ptys_2;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                call_then(start_out_ty_of(lxm_1_3, peel(or_(index(ptys_2_3, i), check_types::Ty(check_types::Ty::TyErr{})))), [=](OutTy out_ty_of_308082) { return prism_rtl::finished(std::tuple{prism_rtl::cat("arg", i), out_ty_of_308082}); });
            });
        }));
        });
    }));
    })));
    auto node_ = prism_rtl::cat(rust_mod_name(v_.home), "::", camel(check_types::bare_name(qk)));
    auto fams = or_(prelude::get(lx.g.mods, v_.home), check_env::dummy_mod()).emit_rw.fams;
    auto world = check_types::has_text(fams, Text("Gui"))
        ? Text("canvas")
        : check_types::has_text(fams, Text("Ui")) ? Text("none") : Text("cli");
    return ProgDef{.name = prism_rtl::cat(camel(check_types::bare_name(qk)), "Program"), .prism = drop_text(check_types::bare_name(qk), Nat(1u)), .node_ = node_, .params = params, .fallible = true, .world = world};
}


prism_rtl::Turn<ProgDef> ProgDefOf::cycle() const {
    const auto& lx = this->lx;
    const auto& qk = this->qk;
    auto v_ = val_of(lx, qk);
    auto ptys = ({
        __label__ _done;
        prism_rtl::Slot<Array<check_types::Ty>> _v;
        auto&& _m = v_.scheme.ty;
        if (prism_rtl::is<check_types::Ty::TyFn>(_m)) {
            auto&& ps = prism_rtl::as<check_types::Ty::TyFn>(_m).a1;
            _v.set(ps);
            goto _done;
        }
        {
            _v.set(Array<check_types::Ty>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto lxm = in_module_at(lx, v_->file, v_.home, Text("\000main"sv));
    auto lx_1 = lx;
    auto qk_2 = qk;
    return call_value(each_job(check_errors::range0(len(ptys)), ({
        auto lxm_3 = lxm;
        auto ptys_4 = ptys;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, OutTy>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto lxm_3_5 = lxm_3;
            auto ptys_4_5 = ptys_4;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                call_then(start_out_ty_of(lxm_3_5, peel(or_(index(ptys_4_5, i), check_types::Ty(check_types::Ty::TyErr{})))), [=](OutTy out_ty_of_308082) { return prism_rtl::finished(std::tuple{prism_rtl::cat("arg", i), out_ty_of_308082}); });
            });
        }));
        });
    }));
    })), [=](Array<std::tuple<Text, OutTy>> each_308038) {
        return ({
            auto params = each_308038;
            auto node_ = prism_rtl::cat(rust_mod_name(v_.home), "::", camel(check_types::bare_name(qk_2)));
            auto fams = or_(prelude::get(lx_1.g.mods, v_.home), check_env::dummy_mod()).emit_rw.fams;
            auto world = check_types::has_text(fams, Text("Gui"))
                ? Text("canvas")
                : check_types::has_text(fams, Text("Ui")) ? Text("none") : Text("cli");
            (prism_rtl::finished(ProgDef{.name = prism_rtl::cat(camel(check_types::bare_name(qk_2)), "Program"), .prism = drop_text(check_types::bare_name(qk_2), Nat(1u)), .node_ = node_, .params = params, .fallible = true, .world = world}));
        });
    });
}


/// `Start ProgDefOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<ProgDef> start_prog_def_of(Lx lx, Text qk) {
    return std::make_shared<ProgDefOf>(lx, qk);
}


/// JobRoots: unbounded fn Lx -> [Text]
Array<Text> job_roots(const Lx& lx) {
    auto direct = run_to_end(fold_job(lx.g.defs, Array<Text>{}, ({
        auto lx_1 = lx;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, check_env::Def>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, check_env::Def> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_1_2 = lx_1;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto d = p1;
                ({
                auto lxd = in_module(lx_1_2, d->file, d.home);
                call_then(start_run_targets(lxd, d), [=](Array<Text> run_targets_308914) { return call_then(start_unbounded_values(lxd, d), [=](Array<Text> unbounded_values_308936) { return prism_rtl::finished(check_types::union_texts(check_types::union_texts(acc, run_targets_308914), unbounded_values_308936)); }); });
            });
            });
        }));
        });
    })));
    })));
    return run_to_end(fold_job(check_errors::range0(Nat(8u)), direct, ({
        auto lx_1 = lx;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Nat>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_1_2 = lx_1;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                static_cast<void>(p1);
                fold_job(acc, acc, ({
                auto lx_1_2_2 = lx_1_2;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Text>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, Text> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto lx_1_2_2_2 = lx_1_2_2;
                    entered(once_job([=]() {
                    return ({
                        auto a = p0;
                        auto qk = p1;
                        call_then(start_tail_targets(lx_1_2_2_2, qk), [=](Array<Text> tail_targets_309043) { return prism_rtl::finished(check_types::union_texts(a, tail_targets_309043)); });
                    });
                }));
                });
            })));
            }))->cycle();
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<Array<Text>> JobRoots::cycle() const {
    const auto& lx = this->lx;
    auto lx_1 = lx;
    return call_value(fold_job(lx_1.g.defs, Array<Text>{}, ({
        auto lx_1_2 = lx_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, check_env::Def>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, check_env::Def> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_1_2_2 = lx_1_2;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto d = p1;
                ({
                auto lxd = in_module(lx_1_2_2, d->file, d.home);
                call_then(start_run_targets(lxd, d), [=](Array<Text> run_targets_308914) { return call_then(start_unbounded_values(lxd, d), [=](Array<Text> unbounded_values_308936) { return prism_rtl::finished(check_types::union_texts(check_types::union_texts(acc, run_targets_308914), unbounded_values_308936)); }); });
            });
            });
        }));
        });
    })));
    })), [=](Array<Text> fold_308799) {
        return ({
            auto direct = fold_308799;
            fold_job(check_errors::range0(Nat(8u)), direct, ({
            auto lx_1_2 = lx_1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Nat>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, Nat> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto lx_1_2_2 = lx_1_2;
                entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    static_cast<void>(p1);
                    fold_job(acc, acc, ({
                    auto lx_1_2_2_2 = lx_1_2_2;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Text>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, Text> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto lx_1_2_2_2_2 = lx_1_2_2_2;
                        entered(once_job([=]() {
                        return ({
                            auto a = p0;
                            auto qk = p1;
                            call_then(start_tail_targets(lx_1_2_2_2_2, qk), [=](Array<Text> tail_targets_309043) { return prism_rtl::finished(check_types::union_texts(a, tail_targets_309043)); });
                        });
                    }));
                    });
                })));
                }))->cycle();
                });
            }));
            });
        })));
        }))->cycle();
        });
    });
}


/// `Start JobRoots, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_job_roots(Lx lx) {
    return std::make_shared<JobRoots>(lx);
}


/// UnboundedValues: unbounded fn Lx, Def -> [Text]
Array<Text> unbounded_values(const Lx& lx, const check_env::Def& d) {
    auto es = ({
        __label__ _done;
        prism_rtl::Slot<Array<ast::Expr>> _v;
        auto&& _m = d.body;
        if (prism_rtl::is<check_env::DefBody::DbWidget>(_m)) {
            auto&& w = prism_rtl::as<check_env::DefBody::DbWidget>(_m).a0;
            _v.set(typed::block_exprs(w.body));
            goto _done;
        }
        if (prism_rtl::is<check_env::DefBody::DbFn>(_m)) {
            auto&& cs = prism_rtl::as<check_env::DefBody::DbFn>(_m).a0;
            _v.set(run_to_end(fold_job(cs, Array<ast::Expr>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<ast::Expr>>(std::tuple<Array<ast::Expr>, ast::FnClause>)>>(prism_rtl::rc([=](std::tuple<Array<ast::Expr>, ast::FnClause> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return entered(once_job([=]() {
                    return ({
                        auto acc = p0;
                        auto c = p1;
                        call_then(typed::start_body_exprs(c.body), [=](Array<ast::Expr> body_exprs_309392) { return prism_rtl::finished(append(acc, body_exprs_309392)); });
                    });
                }));
            })))));
            goto _done;
        }
        if (prism_rtl::is<check_env::DefBody::DbLet>(_m)) {
            auto&& l = prism_rtl::as<check_env::DefBody::DbLet>(_m).a0;
            _v.set(typed::exprs_in(l->value));
            goto _done;
        }
        {
            _v.set(Array<ast::Expr>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto callees = fold(es, Array<Text>{}, [&](const Array<Text>& acc, const ast::Expr& e) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = e.kind;
            if (prism_rtl::is<ast::ExprKind::ECall>(_m)) {
                auto&& c = prism_rtl::as<ast::ExprKind::ECall>(_m).a0;
                _v.set(prelude::push(acc, place_key(lx, c.span)));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    return fold(es, Array<Text>{}, [&](const Array<Text>& acc, const ast::Expr& e) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = e.kind;
            if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
                auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
                _v.set(check_types::has_text(callees, place_key(lx, e.span))
                    ? acc
                    : ({
                    auto&& _q_opt = check_env::resolve_value(lx.g, lx.home, n);
                    auto&& q_opt = std::get<0>(_q_opt);
                    ({
                    __label__ _done;
                    prism_rtl::Slot<Array<Text>> _v;
                    if (prism_rtl::is_some(q_opt)) {
                        auto&& q = prism_rtl::some_of(q_opt);
                        _v.set(is_unbounded(lx, q) ? check_types::add_text(acc, q) : acc);
                        goto _done;
                    }
                    if (prism_rtl::is_none(q_opt)) {
                        _v.set(acc);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                }));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


prism_rtl::Turn<Array<Text>> UnboundedValues::cycle() const {
    const auto& lx = this->lx;
    const auto& d = this->d;
    auto es = ({
        __label__ _done;
        prism_rtl::Slot<Array<ast::Expr>> _v;
        auto&& _m = d.body;
        if (prism_rtl::is<check_env::DefBody::DbWidget>(_m)) {
            auto&& w = prism_rtl::as<check_env::DefBody::DbWidget>(_m).a0;
            _v.set(typed::block_exprs(w.body));
            goto _done;
        }
        if (prism_rtl::is<check_env::DefBody::DbFn>(_m)) {
            auto&& cs = prism_rtl::as<check_env::DefBody::DbFn>(_m).a0;
            _v.set(run_to_end(fold_job(cs, Array<ast::Expr>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<ast::Expr>>(std::tuple<Array<ast::Expr>, ast::FnClause>)>>(prism_rtl::rc([=](std::tuple<Array<ast::Expr>, ast::FnClause> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return entered(once_job([=]() {
                    return ({
                        auto acc = p0;
                        auto c = p1;
                        call_then(typed::start_body_exprs(c.body), [=](Array<ast::Expr> body_exprs_309392) { return prism_rtl::finished(append(acc, body_exprs_309392)); });
                    });
                }));
            })))));
            goto _done;
        }
        if (prism_rtl::is<check_env::DefBody::DbLet>(_m)) {
            auto&& l = prism_rtl::as<check_env::DefBody::DbLet>(_m).a0;
            _v.set(typed::exprs_in(l->value));
            goto _done;
        }
        {
            _v.set(Array<ast::Expr>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto callees = fold(es, Array<Text>{}, [&](const Array<Text>& acc, const ast::Expr& e) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = e.kind;
            if (prism_rtl::is<ast::ExprKind::ECall>(_m)) {
                auto&& c = prism_rtl::as<ast::ExprKind::ECall>(_m).a0;
                _v.set(prelude::push(acc, place_key(lx, c.span)));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    return prism_rtl::finished(fold(es, Array<Text>{}, [&](const Array<Text>& acc, const ast::Expr& e) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = e.kind;
            if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
                auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
                _v.set(check_types::has_text(callees, place_key(lx, e.span))
                    ? acc
                    : ({
                    auto&& _q_opt = check_env::resolve_value(lx.g, lx.home, n);
                    auto&& q_opt = std::get<0>(_q_opt);
                    ({
                    __label__ _done;
                    prism_rtl::Slot<Array<Text>> _v;
                    if (prism_rtl::is_some(q_opt)) {
                        auto&& q = prism_rtl::some_of(q_opt);
                        _v.set(is_unbounded(lx, q) ? check_types::add_text(acc, q) : acc);
                        goto _done;
                    }
                    if (prism_rtl::is_none(q_opt)) {
                        _v.set(acc);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                }));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    }));
}


/// `Start UnboundedValues, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_unbounded_values(Lx lx, check_env::Def d) {
    return std::make_shared<UnboundedValues>(lx, d);
}


/// InPrelude: fn Lx, Text -> Bool
bool in_prelude(const Lx& lx, const Text& q) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = prelude::get(lx.g.vals, q);
        if (prism_rtl::is_some(_m)) {
            auto&& v_ = prism_rtl::some_of(_m);
            _v.set(v_.home == Text("Prelude"));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(false);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// IsColorPoly: fn Lx, Text -> Bool
bool is_color_poly(const Lx& lx, const Text& q) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = prelude::get(lx.g.vals, q);
        if (prism_rtl::is_some(_m)) {
            auto&& v_ = prism_rtl::some_of(_m);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<bool> _v;
                auto&& _m = v_.scheme.ty;
                if (prism_rtl::is<check_types::Ty::TyFn>(_m) && prism_rtl::is<check_types::Col::CQ>(prism_rtl::as<check_types::Ty::TyFn>(_m).a0)) {
                    _v.set(true);
                    goto _done;
                }
                if (prism_rtl::is<check_types::Ty::TyFn>(_m) && prism_rtl::is<check_types::Col::CRigid>(prism_rtl::as<check_types::Ty::TyFn>(_m).a0)) {
                    _v.set(true);
                    goto _done;
                }
                {
                    _v.set(false);
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(false);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// EntersAtOnce: fn Lx, Text, [Arg] -> Bool
bool enters_at_once(const Lx& lx, const Text& q, const Array<ast::Arg>& args) {
    return is_color_poly(lx, q) && (!fold(args, false, [&](const bool& seen, const ast::Arg& a) { return seen || is_unbounded_arg(lx, a); }));
}


/// IsUnboundedArg: fn Lx, Arg -> Bool
bool is_unbounded_arg(const Lx& lx, const ast::Arg& a) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = peel(type_at(lx, a->value.span));
        if (prism_rtl::is<check_types::Ty::TyFn>(_m) && prism_rtl::is<check_types::Col::CUnbound>(prism_rtl::as<check_types::Ty::TyFn>(_m).a0)) {
            _v.set(true);
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// IsUnbounded: fn Lx, Text -> Bool
bool is_unbounded(const Lx& lx, const Text& q) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = prelude::get(lx.g.vals, q);
        if (prism_rtl::is_some(_m)) {
            auto&& v_ = prism_rtl::some_of(_m);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<bool> _v;
                auto&& _m = v_.scheme.ty;
                if (prism_rtl::is<check_types::Ty::TyFn>(_m) && prism_rtl::is<check_types::Col::CBound>(prism_rtl::as<check_types::Ty::TyFn>(_m).a0)) {
                    _v.set(false);
                    goto _done;
                }
                if (prism_rtl::is<check_types::Ty::TyFn>(_m)) {
                    _v.set(true);
                    goto _done;
                }
                {
                    _v.set(false);
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(false);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// RunTargets: unbounded fn Lx, Def -> [Text]
Array<Text> run_targets(const Lx& lx, const check_env::Def& d) {
    auto es = ({
        __label__ _done;
        prism_rtl::Slot<Array<ast::Expr>> _v;
        auto&& _m = d.body;
        if (prism_rtl::is<check_env::DefBody::DbWidget>(_m)) {
            auto&& w = prism_rtl::as<check_env::DefBody::DbWidget>(_m).a0;
            _v.set(typed::block_exprs(w.body));
            goto _done;
        }
        if (prism_rtl::is<check_env::DefBody::DbFn>(_m)) {
            auto&& cs = prism_rtl::as<check_env::DefBody::DbFn>(_m).a0;
            _v.set(run_to_end(fold_job(cs, Array<ast::Expr>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<ast::Expr>>(std::tuple<Array<ast::Expr>, ast::FnClause>)>>(prism_rtl::rc([=](std::tuple<Array<ast::Expr>, ast::FnClause> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return entered(once_job([=]() {
                    return ({
                        auto acc = p0;
                        auto c = p1;
                        call_then(typed::start_body_exprs(c.body), [=](Array<ast::Expr> body_exprs_311621) { return prism_rtl::finished(append(acc, body_exprs_311621)); });
                    });
                }));
            })))));
            goto _done;
        }
        {
            _v.set(Array<ast::Expr>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    return fold(es, Array<Text>{}, [&](const Array<Text>& acc, const ast::Expr& e) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = e.kind;
            if (prism_rtl::is<ast::ExprKind::ECall>(_m)) {
                auto&& c = prism_rtl::as<ast::ExprKind::ECall>(_m).a0;
                auto&& args = prism_rtl::as<ast::ExprKind::ECall>(_m).a1;
                _v.set(blueprint_qk(lx, c) == Text("Prelude.@Run")
                    ? ({
                    __label__ _done;
                    prism_rtl::Slot<Array<Text>> _v;
                    auto&& _m = index(args, Nat(0u));
                    if (prism_rtl::is_some(_m)) {
                        auto&& a = prism_rtl::some_of(_m);
                        _v.set(({
                            __label__ _done;
                            prism_rtl::Slot<Array<Text>> _v;
                            auto&& _m = a->value.kind;
                            if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
                                auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
                                _v.set(({
                                    auto&& _q_opt = check_env::resolve_value(lx.g, lx.home, n);
                                    auto&& q_opt = std::get<0>(_q_opt);
                                    ({
                                    __label__ _done;
                                    prism_rtl::Slot<Array<Text>> _v;
                                    if (prism_rtl::is_some(q_opt)) {
                                        auto&& q = prism_rtl::some_of(q_opt);
                                        _v.set(check_types::add_text(acc, q));
                                        goto _done;
                                    }
                                    if (prism_rtl::is_none(q_opt)) {
                                        _v.set(acc);
                                        goto _done;
                                    }
                                    prism_rtl::unreachable("no arm matched");
                                _done:
                                    _v.take();
                                });
                                }));
                                goto _done;
                            }
                            {
                                _v.set(acc);
                                goto _done;
                            }
                        _done:
                            _v.take();
                        }));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(acc);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                })
                    : acc);
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


prism_rtl::Turn<Array<Text>> RunTargets::cycle() const {
    const auto& lx = this->lx;
    const auto& d = this->d;
    auto es = ({
        __label__ _done;
        prism_rtl::Slot<Array<ast::Expr>> _v;
        auto&& _m = d.body;
        if (prism_rtl::is<check_env::DefBody::DbWidget>(_m)) {
            auto&& w = prism_rtl::as<check_env::DefBody::DbWidget>(_m).a0;
            _v.set(typed::block_exprs(w.body));
            goto _done;
        }
        if (prism_rtl::is<check_env::DefBody::DbFn>(_m)) {
            auto&& cs = prism_rtl::as<check_env::DefBody::DbFn>(_m).a0;
            _v.set(run_to_end(fold_job(cs, Array<ast::Expr>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<ast::Expr>>(std::tuple<Array<ast::Expr>, ast::FnClause>)>>(prism_rtl::rc([=](std::tuple<Array<ast::Expr>, ast::FnClause> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return entered(once_job([=]() {
                    return ({
                        auto acc = p0;
                        auto c = p1;
                        call_then(typed::start_body_exprs(c.body), [=](Array<ast::Expr> body_exprs_311621) { return prism_rtl::finished(append(acc, body_exprs_311621)); });
                    });
                }));
            })))));
            goto _done;
        }
        {
            _v.set(Array<ast::Expr>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    return prism_rtl::finished(fold(es, Array<Text>{}, [&](const Array<Text>& acc, const ast::Expr& e) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = e.kind;
            if (prism_rtl::is<ast::ExprKind::ECall>(_m)) {
                auto&& c = prism_rtl::as<ast::ExprKind::ECall>(_m).a0;
                auto&& args = prism_rtl::as<ast::ExprKind::ECall>(_m).a1;
                _v.set(blueprint_qk(lx, c) == Text("Prelude.@Run")
                    ? ({
                    __label__ _done;
                    prism_rtl::Slot<Array<Text>> _v;
                    auto&& _m = index(args, Nat(0u));
                    if (prism_rtl::is_some(_m)) {
                        auto&& a = prism_rtl::some_of(_m);
                        _v.set(({
                            __label__ _done;
                            prism_rtl::Slot<Array<Text>> _v;
                            auto&& _m = a->value.kind;
                            if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
                                auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
                                _v.set(({
                                    auto&& _q_opt = check_env::resolve_value(lx.g, lx.home, n);
                                    auto&& q_opt = std::get<0>(_q_opt);
                                    ({
                                    __label__ _done;
                                    prism_rtl::Slot<Array<Text>> _v;
                                    if (prism_rtl::is_some(q_opt)) {
                                        auto&& q = prism_rtl::some_of(q_opt);
                                        _v.set(check_types::add_text(acc, q));
                                        goto _done;
                                    }
                                    if (prism_rtl::is_none(q_opt)) {
                                        _v.set(acc);
                                        goto _done;
                                    }
                                    prism_rtl::unreachable("no arm matched");
                                _done:
                                    _v.take();
                                });
                                }));
                                goto _done;
                            }
                            {
                                _v.set(acc);
                                goto _done;
                            }
                        _done:
                            _v.take();
                        }));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(acc);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                })
                    : acc);
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    }));
}


/// `Start RunTargets, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_run_targets(Lx lx, check_env::Def d) {
    return std::make_shared<RunTargets>(lx, d);
}


/// TailTargets: unbounded fn Lx, Text -> [Text]
Array<Text> tail_targets(const Lx& lx, const Text& qk) {
    auto v_ = or_(prelude::get(lx.g.vals, qk), check_env::builtin(qk, check_types::mono(check_types::Ty(check_types::Ty::TyErr{}))));
    auto lxm = in_module(lx, v_->file, v_.home);
    return run_to_end(fold_job(clauses_of(lx.g, qk), Array<Text>{}, ({
        auto lxm_1 = lxm;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, ast::FnClause>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, ast::FnClause> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lxm_1_2 = lxm_1;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto c = p1;
                call_then(start_tails_of_body(lxm_1_2, c.body), [=](Array<Text> tails_of_body_312500) { return prism_rtl::finished(check_types::union_texts(acc, tails_of_body_312500)); });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<Array<Text>> TailTargets::cycle() const {
    const auto& lx = this->lx;
    const auto& qk = this->qk;
    auto v_ = or_(prelude::get(lx.g.vals, qk), check_env::builtin(qk, check_types::mono(check_types::Ty(check_types::Ty::TyErr{}))));
    auto lxm = in_module(lx, v_->file, v_.home);
    return fold_job(clauses_of(lx.g, qk), Array<Text>{}, ({
        auto lxm_1 = lxm;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, ast::FnClause>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, ast::FnClause> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lxm_1_2 = lxm_1;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto c = p1;
                call_then(start_tails_of_body(lxm_1_2, c.body), [=](Array<Text> tails_of_body_312500) { return prism_rtl::finished(check_types::union_texts(acc, tails_of_body_312500)); });
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start TailTargets, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_tail_targets(Lx lx, Text qk) {
    return std::make_shared<TailTargets>(lx, qk);
}


/// TailsOfBody: unbounded fn Lx, FnBody -> [Text]
Array<Text> tails_of_body(const Lx& lx, const ast::FnBody& body) {
    return fold(typed::body_exprs(body), Array<Text>{}, [&](const Array<Text>& acc, const ast::Expr& e) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = e.kind;
            if (prism_rtl::is<ast::ExprKind::ECall>(_m)) {
                auto&& c = prism_rtl::as<ast::ExprKind::ECall>(_m).a0;
                _v.set(({
                    auto q = blueprint_qk(lx, c);
                    ({
                    __label__ _done;
                    prism_rtl::Slot<Array<Text>> _v;
                    auto&& _m = prelude::get(lx.g.vals, q);
                    if (prism_rtl::is_some(_m)) {
                        auto&& v_ = prism_rtl::some_of(_m);
                        _v.set(({
                            __label__ _done;
                            prism_rtl::Slot<Array<Text>> _v;
                            auto&& _m = v_.scheme.ty;
                            if (prism_rtl::is<check_types::Ty::TyFn>(_m) && prism_rtl::is<check_types::Col::CBound>(prism_rtl::as<check_types::Ty::TyFn>(_m).a0)) {
                                _v.set(acc);
                                goto _done;
                            }
                            if (prism_rtl::is<check_types::Ty::TyFn>(_m)) {
                                _v.set(check_types::add_text(acc, q));
                                goto _done;
                            }
                            {
                                _v.set(acc);
                                goto _done;
                            }
                        _done:
                            _v.take();
                        }));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(acc);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                }));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


prism_rtl::Turn<Array<Text>> TailsOfBody::cycle() const {
    const auto& lx = this->lx;
    const auto& body = this->body;
    auto body_1 = body;
    auto lx_2 = lx;
    return call_then(typed::start_body_exprs(body_1), [=](Array<ast::Expr> body_exprs_312605) {
        return prism_rtl::finished(fold(body_exprs_312605, Array<Text>{}, [&](const Array<Text>& acc, const ast::Expr& e) {
            return ({
                __label__ _done;
                prism_rtl::Slot<Array<Text>> _v;
                auto&& _m = e.kind;
                if (prism_rtl::is<ast::ExprKind::ECall>(_m)) {
                    auto&& c = prism_rtl::as<ast::ExprKind::ECall>(_m).a0;
                    _v.set(({
                        auto q = blueprint_qk(lx_2, c);
                        ({
                        __label__ _done;
                        prism_rtl::Slot<Array<Text>> _v;
                        auto&& _m = prelude::get(lx_2.g.vals, q);
                        if (prism_rtl::is_some(_m)) {
                            auto&& v_ = prism_rtl::some_of(_m);
                            _v.set(({
                                __label__ _done;
                                prism_rtl::Slot<Array<Text>> _v;
                                auto&& _m = v_.scheme.ty;
                                if (prism_rtl::is<check_types::Ty::TyFn>(_m) && prism_rtl::is<check_types::Col::CBound>(prism_rtl::as<check_types::Ty::TyFn>(_m).a0)) {
                                    _v.set(acc);
                                    goto _done;
                                }
                                if (prism_rtl::is<check_types::Ty::TyFn>(_m)) {
                                    _v.set(check_types::add_text(acc, q));
                                    goto _done;
                                }
                                {
                                    _v.set(acc);
                                    goto _done;
                                }
                            _done:
                                _v.take();
                            }));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(acc);
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                    }));
                    goto _done;
                }
                {
                    _v.set(acc);
                    goto _done;
                }
            _done:
                _v.take();
            });
        }));
    });
}


/// `Start TailsOfBody, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_tails_of_body(Lx lx, ast::FnBody body) {
    return std::make_shared<TailsOfBody>(lx, body);
}


/// ModDefOf: unbounded fn Lx, Text, [((Text, Bool))], ModInfo, [Text] -> ModDef
ModDef mod_def_of(const Lx& lx0, const Text& m, const Array<std::tuple<Text, bool>>& roots, const check_env::ModInfo& info, const Array<Text>& mods) {
    auto lx = in_module(lx0, info->file, m);
    auto path_ = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = index(lx.g.srcs, info->file);
        if (prism_rtl::is_some(_m)) {
            auto&& src = prism_rtl::some_of(_m);
            _v.set(src->path_);
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto types = run_to_end(fold_job(values(lx.g.types), Array<Item>{}, ({
        auto m_1 = m;
        auto lx_2 = lx;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Item>>(std::tuple<Array<Item>, check_env::TyInfo>)>>(prism_rtl::rc([=](std::tuple<Array<Item>, check_env::TyInfo> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto m_1_3 = m_1;
            auto lx_2_3 = lx_2;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto ti = p1;
                ti.home == m_1_3
                ? call_then(start_ty_defs(lx_2_3, ti), [=](Array<Item> ty_defs_313330) { return prism_rtl::finished(append(acc, ty_defs_313330)); })
                : prism_rtl::finished(acc);
            });
        }));
        });
    })));
    })));
    auto tags = run_to_end(fold_job(values(lx.g.tags), Array<Item>{}, ({
        auto m_1 = m;
        auto lx_2 = lx;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Item>>(std::tuple<Array<Item>, check_env::TagInfo>)>>(prism_rtl::rc([=](std::tuple<Array<Item>, check_env::TagInfo> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto m_1_3 = m_1;
            auto lx_2_3 = lx_2;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto tg = p1;
                (tg.home == m_1_3) && (tg.kind != Text("Prelude.Fault"))
                ? call_then(start_tag_def_of(lx_2_3, tg), [=](TagDef tag_def_of_313478) { return prism_rtl::finished(prelude::push(acc, Item(Item::ItTag{tag_def_of_313478}))); })
                : prism_rtl::finished(acc);
            });
        }));
        });
    })));
    })));
    auto defs = run_to_end(fold_job(lx.g.defs, Array<Item>{}, ({
        auto m_1 = m;
        auto lx_2 = lx;
        auto roots_3 = roots;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Item>>(std::tuple<Array<Item>, check_env::Def>)>>(prism_rtl::rc([=](std::tuple<Array<Item>, check_env::Def> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto m_1_4 = m_1;
            auto lx_2_4 = lx_2;
            auto roots_3_4 = roots_3;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto d = p1;
                d.home == m_1_4
                ? call_then(start_def_items(in_module(lx_2_4, d->file, m_1_4), d, roots_3_4), [=](Array<Item> def_items_313582) { return prism_rtl::finished(append(acc, def_items_313582)); })
                : prism_rtl::finished(acc);
            });
        }));
        });
    })));
    })));
    auto traits = run_to_end(fold_job(values(lx.g.traits), Array<Item>{}, ({
        auto m_1 = m;
        auto lx_2 = lx;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Item>>(std::tuple<Array<Item>, check_env::TraitInfo>)>>(prism_rtl::rc([=](std::tuple<Array<Item>, check_env::TraitInfo> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto m_1_3 = m_1;
            auto lx_2_3 = lx_2;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto tr = p1;
                tr.home == m_1_3
                ? call_then(start_trait_def_of(lx_2_3, tr), [=](TraitDef trait_def_of_313735) { return prism_rtl::finished(prelude::push(acc, Item(Item::ItTrait{trait_def_of_313735}))); })
                : prism_rtl::finished(acc);
            });
        }));
        });
    })));
    })));
    auto impls = run_to_end(fold_job(values(lx.g.impls), Array<Item>{}, ({
        auto m_1 = m;
        auto lx_2 = lx;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Item>>(std::tuple<Array<Item>, Array<check_env::ImplInfo>>)>>(prism_rtl::rc([=](std::tuple<Array<Item>, Array<check_env::ImplInfo>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto m_1_3 = m_1;
            auto lx_2_3 = lx_2;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto ims = p1;
                fold_job(ims, acc, ({
                auto m_1_3_3 = m_1_3;
                auto lx_2_3_3 = lx_2_3;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Item>>(std::tuple<Array<Item>, check_env::ImplInfo>)>>(prism_rtl::rc([=](std::tuple<Array<Item>, check_env::ImplInfo> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto m_1_3_3_3 = m_1_3_3;
                    auto lx_2_3_3_3 = lx_2_3_3;
                    entered(once_job([=]() {
                    return ({
                        auto a = p0;
                        auto im = p1;
                        (im.home == m_1_3_3_3) && (!im.derived)
                        ? call_then(start_impl_def_of(in_module(lx_2_3_3_3, im->file, m_1_3_3_3), im), [=](ImplDef impl_def_of_313902) { return prism_rtl::finished(prelude::push(a, Item(Item::ItImpl{impl_def_of_313902}))); })
                        : prism_rtl::finished(a);
                    });
                }));
                });
            })));
            }))->cycle();
            });
        }));
        });
    })));
    })));
    auto uses = filter(each(mods, [&](const Text& o) { return rust_mod_name(o); }), [&](const Text& o) { return o != rust_mod_name(m); });
    return ModDef{.name = rust_mod_name(m), .prism = m, .path_ = path_, .uses = uses, .items = append(append(append(append(types, tags), traits), impls), defs)};
}


prism_rtl::Turn<ModDef> ModDefOf::cycle() const {
    const auto& lx0 = this->lx0;
    const auto& m = this->m;
    const auto& roots = this->roots;
    const auto& info = this->info;
    const auto& mods = this->mods;
    auto lx = in_module(lx0, info->file, m);
    auto path_ = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = index(lx.g.srcs, info->file);
        if (prism_rtl::is_some(_m)) {
            auto&& src = prism_rtl::some_of(_m);
            _v.set(src->path_);
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto m_1 = m;
    auto mods_2 = mods;
    auto roots_3 = roots;
    return call_value(fold_job(values(lx.g.types), Array<Item>{}, ({
        auto m_1_4 = m_1;
        auto lx_4 = lx;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Item>>(std::tuple<Array<Item>, check_env::TyInfo>)>>(prism_rtl::rc([=](std::tuple<Array<Item>, check_env::TyInfo> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto m_1_4_5 = m_1_4;
            auto lx_4_5 = lx_4;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto ti = p1;
                ti.home == m_1_4_5
                ? call_then(start_ty_defs(lx_4_5, ti), [=](Array<Item> ty_defs_313330) { return prism_rtl::finished(append(acc, ty_defs_313330)); })
                : prism_rtl::finished(acc);
            });
        }));
        });
    })));
    })), [=](Array<Item> fold_313257) {
        return ({
            auto types = fold_313257;
            call_value(fold_job(values(lx.g.tags), Array<Item>{}, ({
            auto m_1_4 = m_1;
            auto lx_4 = lx;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Item>>(std::tuple<Array<Item>, check_env::TagInfo>)>>(prism_rtl::rc([=](std::tuple<Array<Item>, check_env::TagInfo> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto m_1_4_5 = m_1_4;
                auto lx_4_5 = lx_4;
                entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto tg = p1;
                    (tg.home == m_1_4_5) && (tg.kind != Text("Prelude.Fault"))
                    ? call_then(start_tag_def_of(lx_4_5, tg), [=](TagDef tag_def_of_313478) { return prism_rtl::finished(prelude::push(acc, Item(Item::ItTag{tag_def_of_313478}))); })
                    : prism_rtl::finished(acc);
                });
            }));
            });
        })));
        })), [=](Array<Item> fold_313370) {
            return ({
                auto tags = fold_313370;
                call_value(fold_job(lx.g.defs, Array<Item>{}, ({
                auto m_1_4 = m_1;
                auto lx_4 = lx;
                auto roots_3_5 = roots_3;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Item>>(std::tuple<Array<Item>, check_env::Def>)>>(prism_rtl::rc([=](std::tuple<Array<Item>, check_env::Def> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto m_1_4_5 = m_1_4;
                    auto lx_4_5 = lx_4;
                    auto roots_3_5_5 = roots_3_5;
                    entered(once_job([=]() {
                    return ({
                        auto acc = p0;
                        auto d = p1;
                        d.home == m_1_4_5
                        ? call_then(start_def_items(in_module(lx_4_5, d->file, m_1_4_5), d, roots_3_5_5), [=](Array<Item> def_items_313582) { return prism_rtl::finished(append(acc, def_items_313582)); })
                        : prism_rtl::finished(acc);
                    });
                }));
                });
            })));
            })), [=](Array<Item> fold_313521) {
                return ({
                    auto defs = fold_313521;
                    call_value(fold_job(values(lx.g.traits), Array<Item>{}, ({
                    auto m_1_4 = m_1;
                    auto lx_4 = lx;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Item>>(std::tuple<Array<Item>, check_env::TraitInfo>)>>(prism_rtl::rc([=](std::tuple<Array<Item>, check_env::TraitInfo> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto m_1_4_5 = m_1_4;
                        auto lx_4_5 = lx_4;
                        entered(once_job([=]() {
                        return ({
                            auto acc = p0;
                            auto tr = p1;
                            tr.home == m_1_4_5
                            ? call_then(start_trait_def_of(lx_4_5, tr), [=](TraitDef trait_def_of_313735) { return prism_rtl::finished(prelude::push(acc, Item(Item::ItTrait{trait_def_of_313735}))); })
                            : prism_rtl::finished(acc);
                        });
                    }));
                    });
                })));
                })), [=](Array<Item> fold_313654) {
                    return ({
                        auto traits = fold_313654;
                        call_value(fold_job(values(lx.g.impls), Array<Item>{}, ({
                        auto m_1_4 = m_1;
                        auto lx_4 = lx;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Item>>(std::tuple<Array<Item>, Array<check_env::ImplInfo>>)>>(prism_rtl::rc([=](std::tuple<Array<Item>, Array<check_env::ImplInfo>> _p0) {
                        auto&& p0 = std::get<0>(_p0);
                        auto&& p1 = std::get<1>(_p0);
                        return ({
                            auto m_1_4_5 = m_1_4;
                            auto lx_4_5 = lx_4;
                            entered(once_job([=]() {
                            return ({
                                auto acc = p0;
                                auto ims = p1;
                                fold_job(ims, acc, ({
                                auto m_1_4_5_5 = m_1_4_5;
                                auto lx_4_5_5 = lx_4_5;
                                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Item>>(std::tuple<Array<Item>, check_env::ImplInfo>)>>(prism_rtl::rc([=](std::tuple<Array<Item>, check_env::ImplInfo> _p0) {
                                auto&& p0 = std::get<0>(_p0);
                                auto&& p1 = std::get<1>(_p0);
                                return ({
                                    auto m_1_4_5_5_5 = m_1_4_5_5;
                                    auto lx_4_5_5_5 = lx_4_5_5;
                                    entered(once_job([=]() {
                                    return ({
                                        auto a = p0;
                                        auto im = p1;
                                        (im.home == m_1_4_5_5_5) && (!im.derived)
                                        ? call_then(start_impl_def_of(in_module(lx_4_5_5_5, im->file, m_1_4_5_5_5), im), [=](ImplDef impl_def_of_313902) { return prism_rtl::finished(prelude::push(a, Item(Item::ItImpl{impl_def_of_313902}))); })
                                        : prism_rtl::finished(a);
                                    });
                                }));
                                });
                            })));
                            }))->cycle();
                            });
                        }));
                        });
                    })));
                    })), [=](Array<Item> fold_313781) {
                        return ({
                            auto impls = fold_313781;
                            auto uses = filter(each(mods_2, [&](const Text& o) { return rust_mod_name(o); }), [&](const Text& o) { return o != rust_mod_name(m_1); });
                            (prism_rtl::finished(ModDef{.name = rust_mod_name(m_1), .prism = m_1, .path_ = path_, .uses = uses, .items = append(append(append(append(types, tags), traits), impls), defs)}));
                        });
                    });
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start ModDefOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<ModDef> start_mod_def_of(Lx lx0, Text m, Array<std::tuple<Text, bool>> roots, check_env::ModInfo info, Array<Text> mods) {
    return std::make_shared<ModDefOf>(lx0, m, roots, info, mods);
}


/// DefItems: unbounded fn Lx, Def, [((Text, Bool))] -> [Item]
Array<Item> def_items(const Lx& lx, const check_env::Def& d, const Array<std::tuple<Text, bool>>& roots) {
    auto is_root = check_types::has_text(each(roots, [&](const std::tuple<Text, bool>& _p0) {
        auto&& q = std::get<0>(_p0);
        return q;
    }), d.qk);
    return ({
        __label__ _done;
        prism_rtl::Slot<Array<Item>> _v;
        auto&& _m = d.body;
        if (prism_rtl::is<check_env::DefBody::DbWidget>(_m)) {
            auto&& w = prism_rtl::as<check_env::DefBody::DbWidget>(_m).a0;
            _v.set(is_root
                ? node_items(node_def_of(lx, d.qk, Array<ast::Pattern_>{}, w.body, or_(prelude::get(lx.g.vals, d.qk), check_env::builtin(d.qk, check_types::mono(check_types::Ty(check_types::Ty::TyErr{})))).scheme, true))
                : Array(std::vector{Item(Item::ItNote{prism_rtl::cat("`", d.name, "` is inlined where it is applied.")})}));
            goto _done;
        }
        if (prism_rtl::is<check_env::DefBody::DbFn>(_m)) {
            auto&& clauses = prism_rtl::as<check_env::DefBody::DbFn>(_m).a0;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<Array<Item>> _v;
                auto&& _m = prelude::get(lx.g.vals, d.qk);
                if (prism_rtl::is_none(_m)) {
                    _v.set(Array<Item>{});
                    goto _done;
                }
                if (prism_rtl::is_some(_m)) {
                    auto&& v_ = prism_rtl::some_of(_m);
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<Array<Item>> _v;
                        auto&& _m = v_.scheme.ty;
                        if (prism_rtl::is<check_types::Ty::TyFn>(_m)) {
                            auto&& m314774_0_2 = prism_rtl::as<check_types::Ty::TyFn>(_m).a2;
                            if (prism_rtl::is<check_types::Ty::TyAt>(m314774_0_2)) {
                                _v.set(!is_root
                                    ? Array(std::vector{Item(Item::ItNote{prism_rtl::cat("`", d.name, "` is inlined where it is applied.")})})
                                    : ({
                                    __label__ _done;
                                    prism_rtl::Slot<Array<Item>> _v;
                                    {
                                        auto&& m314970_0 = clauses;
                                        if (m314970_0.size() == 1u) {
                                            {
                                                auto&& _c1 = index(m314970_0, Nat(0u));
                                                if (prism_rtl::is_some(_c1)) {
                                                    auto&& c = prism_rtl::some_of(_c1);
                                                    _v.set(({
                                                        __label__ _done;
                                                        prism_rtl::Slot<Array<Item>> _v;
                                                        auto&& _m = c.body;
                                                        if (prism_rtl::is<ast::FnBody::BodyBlock>(_m)) {
                                                            auto&& b = prism_rtl::as<ast::FnBody::BodyBlock>(_m).a0;
                                                            _v.set(node_items(node_def_of(lx, d.qk, c.params, b, v_.scheme, true)));
                                                            goto _done;
                                                        }
                                                        {
                                                            _v.set(Array(std::vector{Item(Item::ItRefused{prism_rtl::cat("`", d.name, "`, a root widget whose body is one expression")})}));
                                                            goto _done;
                                                        }
                                                    _done:
                                                        _v.take();
                                                    }));
                                                    goto _done;
                                                }
                                            }
                                        }
                                    }
                                    {
                                        _v.set(Array(std::vector{Item(Item::ItRefused{prism_rtl::cat("`", d.name, "`, a root widget of several clauses")})}));
                                        goto _done;
                                    }
                                _done:
                                    _v.take();
                                }));
                                goto _done;
                            }
                        }
                        {
                            _v.set(({
                                auto f = Item(Item::ItFn{fn_def_of(lx, d.qk, clauses, v_.scheme)});
                                (check_types::has_text(lx.unbs, d.qk)
                                ? Array(std::vector{f, Item(Item::ItJob{job_def_of(lx, d.qk, clauses, v_.scheme)})})
                                : Array(std::vector{f}));
                            }));
                            goto _done;
                        }
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is<check_env::DefBody::DbLet>(_m)) {
            auto&& l = prism_rtl::as<check_env::DefBody::DbLet>(_m).a0;
            _v.set(Array(std::vector{Item(Item::ItFn{let_getter(lx, d.qk, l)})}));
            goto _done;
        }
        {
            _v.set(Array<Item>{});
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Array<Item>> DefItems::cycle() const {
    const auto& lx = this->lx;
    const auto& d = this->d;
    const auto& roots = this->roots;
    auto is_root = check_types::has_text(each(roots, [&](const std::tuple<Text, bool>& _p0) {
        auto&& q = std::get<0>(_p0);
        return q;
    }), d.qk);
    return ({
        auto&& _m = d.body;
        prism_rtl::is<check_env::DefBody::DbWidget>(_m) ? ({
        auto&& w = prism_rtl::as<check_env::DefBody::DbWidget>(_m).a0;
        is_root
        ? ({
        auto d_1 = d;
        auto lx_2 = lx;
        auto w_3 = w;
        call_then(start_node_def_of(lx_2, d_1.qk, Array<ast::Pattern_>{}, w_3.body, or_(prelude::get(lx_2.g.vals, d_1.qk), check_env::builtin(d_1.qk, check_types::mono(check_types::Ty(check_types::Ty::TyErr{})))).scheme, true), [=](NodeDef node_def_of_314517) { return prism_rtl::finished(node_items(node_def_of_314517)); });
    })
        : prism_rtl::finished(Array(std::vector{Item(Item::ItNote{prism_rtl::cat("`", d.name, "` is inlined where it is applied.")})}));
    })
        : prism_rtl::is<check_env::DefBody::DbFn>(_m) ? ({
        auto&& clauses = prism_rtl::as<check_env::DefBody::DbFn>(_m).a0;
        ({
        auto&& _m = prelude::get(lx.g.vals, d.qk);
        prism_rtl::is_none(_m) ? prism_rtl::finished(Array<Item>{})
        : prism_rtl::is_some(_m) ? ({
        auto&& v_ = prism_rtl::some_of(_m);
        ({
        auto&& _m = v_.scheme.ty;
        prism_rtl::is<check_types::Ty::TyFn>(_m) && ({
        auto&& m314774_0_2 = prism_rtl::as<check_types::Ty::TyFn>(_m).a2;
        prism_rtl::is<check_types::Ty::TyAt>(m314774_0_2);
    }) ? ({
        auto&& m314774_0_2 = prism_rtl::as<check_types::Ty::TyFn>(_m).a2;
        !is_root
        ? prism_rtl::finished(Array(std::vector{Item(Item::ItNote{prism_rtl::cat("`", d.name, "` is inlined where it is applied.")})}))
        : ({
        ({
        auto&& m314970_0 = clauses;
        (m314970_0.size() == 1u) && ({
        auto&& _c1 = index(m314970_0, Nat(0u));
        prism_rtl::is_some(_c1);
    });
    }) ? ({
        auto&& m314970_0 = clauses;
        auto&& _c1 = index(m314970_0, Nat(0u));
        auto&& c = prism_rtl::some_of(_c1);
        ({
        auto&& _m = c.body;
        prism_rtl::is<ast::FnBody::BodyBlock>(_m) ? ({
        auto&& b = prism_rtl::as<ast::FnBody::BodyBlock>(_m).a0;
        ({
        auto b_1 = b;
        auto d_2 = d;
        auto lx_3 = lx;
        call_then(start_node_def_of(lx_3, d_2.qk, c.params, b_1, v_.scheme, true), [=](NodeDef node_def_of_315082) { return prism_rtl::finished(node_items(node_def_of_315082)); });
    });
    })
        : prism_rtl::finished(Array(std::vector{Item(Item::ItRefused{prism_rtl::cat("`", d.name, "`, a root widget whose body is one expression")})}));
    });
    })
        : prism_rtl::finished(Array(std::vector{Item(Item::ItRefused{prism_rtl::cat("`", d.name, "`, a root widget of several clauses")})}));
    });
    })
        : ({
        auto clauses_1 = clauses;
        auto d_2 = d;
        auto lx_3 = lx;
        call_then(start_fn_def_of(lx_3, d_2.qk, clauses_1, v_.scheme), [=](FnDef fn_def_of_315398) {
        return ({
            auto f = Item(Item::ItFn{fn_def_of_315398});
            (check_types::has_text(lx_3.unbs, d_2.qk)
            ? call_then(start_job_def_of(lx_3, d_2.qk, clauses_1, v_.scheme), [=](JobDef job_def_of_315493) { return prism_rtl::finished(Array(std::vector{f, Item(Item::ItJob{job_def_of_315493})})); })
            : prism_rtl::finished(Array(std::vector{f})));
        });
    });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : prism_rtl::is<check_env::DefBody::DbLet>(_m) ? ({
        auto&& l = prism_rtl::as<check_env::DefBody::DbLet>(_m).a0;
        ({
        auto d_1 = d;
        auto l_2 = l;
        auto lx_3 = lx;
        call_then(start_let_getter(lx_3, d_1.qk, l_2), [=](FnDef let_getter_315570) { return prism_rtl::finished(Array(std::vector{Item(Item::ItFn{let_getter_315570})})); });
    });
    })
        : prism_rtl::finished(Array<Item>{});
    });
}


/// `Start DefItems, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Item>> start_def_items(Lx lx, check_env::Def d, Array<std::tuple<Text, bool>> roots) {
    return std::make_shared<DefItems>(lx, d, roots);
}


/// NodeItems: fn NodeDef -> [Item]
Array<Item> node_items(const NodeDef& n) {
    return append(Array(std::vector{Item(Item::ItNode{n})}), each(n.children, [&](const NodeDef& c) { return Item(Item::ItNode{c}); }));
}


/// TyDefs: unbounded fn Lx, TyInfo -> [Item]
Array<Item> ty_defs(const Lx& lx, const check_env::TyInfo& ti) {
    auto derives = each(ti.derives, [&](const Text& dn) { return check_types::bare_name(dn); });
    auto params = each(ti.params, [&](const Text& p_) { return camel(p_); });
    auto floaty_ = floaty(lx.g, check_types::Ty(check_types::Ty::TyCon{ti.name, Array<check_types::Ty>{}}), Array<Text>{});
    auto bare = check_types::bare_name(ti.name);
    auto mk_fn = ({
        auto bare_1 = bare;
        auto params_2 = params;
        auto derives_3 = derives;
        auto floaty__4 = floaty_;
        auto lx_5 = lx;
        auto ti_6 = ti;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<TyDef>(std::tuple<TyShape, Array<CaseDef>>)>>(prism_rtl::rc([=](std::tuple<TyShape, Array<CaseDef>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto bare_1_7 = bare_1;
            auto params_2_7 = params_2;
            auto derives_3_7 = derives_3;
            auto floaty__4_7 = floaty__4;
            auto lx_5_7 = lx_5;
            auto ti_6_7 = ti_6;
            entered(once_job([=]() {
            return ({
                auto shape = p0;
                auto cases = p1;
                call_then(start_ty_podable(lx_5_7, check_types::Ty(check_types::Ty::TyCon{ti_6_7.name, Array<check_types::Ty>{}}), Array<Text>{}), [=](bool ty_podable_316360) {
                return prism_rtl::finished(TyDef{.name = camel(bare_1_7), .prism = bare_1_7, .params = params_2_7, .shape = shape, .cases_ = cases, .eq = check_types::has_text(derives_3_7, Text("Eq")), .ord = check_types::has_text(derives_3_7, Text("Ord")), .floaty = floaty__4_7, .show_ = has_own_show(lx_5_7, ti_6_7.name)
                    ? Shown(Shown::ShownOwn{})
                    : check_types::has_text(derives_3_7, Text("Show"))
                    ? Shown(Shown::ShownDerived{})
                    : Shown(Shown::NotShown{}), .pod = ty_podable_316360 && run_to_end(fold_job(cases, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, CaseDef>)>>(prism_rtl::rc([=](std::tuple<bool, CaseDef> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return entered(once_job([=]() {
                        return ({
                            auto ok = p0;
                            auto c = p1;
                            (prism_rtl::finished(ok && run_to_end(fold_job(c.fields, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, OutTy>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<Text, OutTy>> _p0) {
                            auto&& p0 = std::get<0>(_p0);
                            auto&& p1 = std::get<1>(_p0);
                            return entered(once_job([=]() {
                                return ({
                                    auto ok2 = p0;
                                    auto&& _ft = p1;
                                    auto&& ft = std::get<1>(_ft);
                                    (prism_rtl::finished(ok2 && podable(ft)));
                                });
                            }));
                        }))))));
                        });
                    }));
                })))), .doc = type_doc(lx_5_7, ti_6_7)});
            });
            });
        }));
        });
    })));
    });
    return ({
        __label__ _done;
        prism_rtl::Slot<Array<Item>> _v;
        auto&& _m = ti.body;
        if (prism_rtl::is<check_env::TyBody::BRecord>(_m)) {
            auto&& fs = prism_rtl::as<check_env::TyBody::BRecord>(_m).a0;
            _v.set(({
                auto fields = run_to_end(each_job(check_errors::range0(len(fs)), ({
                    auto fs_1 = fs;
                    auto lx_2 = lx;
                    auto ti_3 = ti;
                    static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, OutTy>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
                    return ({
                        auto fs_1_4 = fs_1;
                        auto lx_2_4 = lx_2;
                        auto ti_3_4 = ti_3;
                        entered(once_job([=]() {
                        return ({
                            auto i = p0;
                            ({
                            auto [fname, ft] = or_(index(fs_1_4, i), std::tuple{Text(""), check_types::Ty(check_types::Ty::TyErr{})});
                            call_then(start_out_ty_of(lx_2_4, ft), [=](OutTy out_ty_of_316706) {
                            return ({
                                auto rt = out_ty_of_316706;
                                (prism_rtl::finished(std::tuple{snake(fname), rc_field(lx_2_4, ti_3_4.name, i)
                                ? OutTy(OutTy::OutRc{prism_rtl::rc(rt)})
                                : rt}));
                            });
                        });
                        });
                        });
                    }));
                    });
                }));
                })));
                (Array(std::vector{Item(Item::ItType{run_to_end(mk_fn(std::tuple{TyShape(TyShape::ShapeRecord{}), Array(std::vector{CaseDef{.name = camel(bare), .prism = bare, .fields = fields}})}))})}));
            }));
            goto _done;
        }
        if (prism_rtl::is<check_env::TyBody::BChoice>(_m)) {
            auto&& cases = prism_rtl::as<check_env::TyBody::BChoice>(_m).a0;
            _v.set(({
                auto defs = run_to_end(each_job(cases, ({
                    auto ti_1 = ti;
                    auto lx_2 = lx;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<CaseDef>(std::tuple<Text, Array<check_types::Ty>>)>>(prism_rtl::rc([=](std::tuple<Text, Array<check_types::Ty>> p0) {
                    return ({
                        auto ti_1_3 = ti_1;
                        auto lx_2_3 = lx_2;
                        entered(once_job([=]() {
                        return ({
                            auto [cn, ats] = p0;
                            ({
                            auto ck = check_env::qual_key(ti_1_3.home, cn);
                            call_value(each_job(check_errors::range0(len(ats)), ({
                            auto lx_2_3_3 = lx_2_3;
                            auto ck_3 = ck;
                            auto ats_4 = ats;
                            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, OutTy>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
                            return ({
                                auto lx_2_3_3_5 = lx_2_3_3;
                                auto ck_3_5 = ck_3;
                                auto ats_4_5 = ats_4;
                                entered(once_job([=]() {
                                return ({
                                    auto i = p0;
                                    call_then(start_case_field(lx_2_3_3_5, ck_3_5, i, or_(index(ats_4_5, i), check_types::Ty(check_types::Ty::TyErr{}))), [=](OutTy case_field_317114) { return prism_rtl::finished(std::tuple{Text(""), case_field_317114}); });
                                });
                            }));
                            });
                        }));
                        })), [=](Array<std::tuple<Text, OutTy>> each_317077) { return prism_rtl::finished(CaseDef{.name = camel(cn), .prism = cn, .fields = each_317077}); });
                        });
                        });
                    }));
                    });
                })));
                })));
                auto shape = ({
                    __label__ _done;
                    prism_rtl::Slot<TyShape> _v;
                    {
                        auto&& m317183_0 = cases;
                        if (m317183_0.size() == 1u) {
                            {
                                auto&& _c2 = index(m317183_0, Nat(0u));
                                if (prism_rtl::is_some(_c2)) {
                                    auto&& cn = std::get<0>(prism_rtl::some_of(_c2));
                                    auto&& m317183_0_0_1 = std::get<1>(prism_rtl::some_of(_c2));
                                    if (m317183_0_0_1.size() == 0u) {
                                        _v.set(check_env::is_lower_text(cn)
                                            ? TyShape(TyShape::ShapeUnit{})
                                            : TyShape(TyShape::ShapeChoice{}));
                                        goto _done;
                                    }
                                }
                            }
                        }
                    }
                    {
                        auto&& m317183_1 = cases;
                        if (m317183_1.size() == 1u) {
                            {
                                auto&& _c1 = index(m317183_1, Nat(0u));
                                if (prism_rtl::is_some(_c1)) {
                                    auto&& cn = std::get<0>(prism_rtl::some_of(_c1));
                                    _v.set(cn == bare
                                        ? TyShape(TyShape::ShapeNewtype{})
                                        : TyShape(TyShape::ShapeChoice{}));
                                    goto _done;
                                }
                            }
                        }
                    }
                    {
                        _v.set(TyShape(TyShape::ShapeChoice{}));
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                (Array(std::vector{Item(Item::ItType{run_to_end(mk_fn(std::tuple{shape, defs}))})}));
            }));
            goto _done;
        }
        if (prism_rtl::is<check_env::TyBody::BRowKind>(_m)) {
            _v.set(ti.name == Text("Prelude.Fault")
                ? Array<Item>{}
                : Array(std::vector{Item(Item::ItRow{row_def_of(lx, ti)})}));
            goto _done;
        }
        {
            _v.set(Array<Item>{});
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Array<Item>> TyDefs::cycle() const {
    const auto& lx = this->lx;
    const auto& ti = this->ti;
    auto derives = each(ti.derives, [&](const Text& dn) { return check_types::bare_name(dn); });
    auto params = each(ti.params, [&](const Text& p_) { return camel(p_); });
    auto lx_1 = lx;
    auto ti_2 = ti;
    return call_then(start_floaty(lx_1.g, check_types::Ty(check_types::Ty::TyCon{ti_2.name, Array<check_types::Ty>{}}), Array<Text>{}), [=](bool floaty_315995) {
        return ({
            auto floaty_ = floaty_315995;
            auto bare = check_types::bare_name(ti_2.name);
            auto mk_fn = ({
                auto bare_3 = bare;
                auto params_4 = params;
                auto derives_5 = derives;
                auto floaty__6 = floaty_;
                auto lx_1_7 = lx_1;
                auto ti_2_7 = ti_2;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<TyDef>(std::tuple<TyShape, Array<CaseDef>>)>>(prism_rtl::rc([=](std::tuple<TyShape, Array<CaseDef>> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto bare_3_7 = bare_3;
                    auto params_4_7 = params_4;
                    auto derives_5_7 = derives_5;
                    auto floaty__6_7 = floaty__6;
                    auto lx_1_7_7 = lx_1_7;
                    auto ti_2_7_7 = ti_2_7;
                    entered(once_job([=]() {
                    return ({
                        auto shape = p0;
                        auto cases = p1;
                        call_then(start_ty_podable(lx_1_7_7, check_types::Ty(check_types::Ty::TyCon{ti_2_7_7.name, Array<check_types::Ty>{}}), Array<Text>{}), [=](bool ty_podable_316360) {
                        return prism_rtl::finished(TyDef{.name = camel(bare_3_7), .prism = bare_3_7, .params = params_4_7, .shape = shape, .cases_ = cases, .eq = check_types::has_text(derives_5_7, Text("Eq")), .ord = check_types::has_text(derives_5_7, Text("Ord")), .floaty = floaty__6_7, .show_ = has_own_show(lx_1_7_7, ti_2_7_7.name)
                            ? Shown(Shown::ShownOwn{})
                            : check_types::has_text(derives_5_7, Text("Show"))
                            ? Shown(Shown::ShownDerived{})
                            : Shown(Shown::NotShown{}), .pod = ty_podable_316360 && run_to_end(fold_job(cases, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, CaseDef>)>>(prism_rtl::rc([=](std::tuple<bool, CaseDef> _p0) {
                            auto&& p0 = std::get<0>(_p0);
                            auto&& p1 = std::get<1>(_p0);
                            return entered(once_job([=]() {
                                return ({
                                    auto ok = p0;
                                    auto c = p1;
                                    (prism_rtl::finished(ok && run_to_end(fold_job(c.fields, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, OutTy>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<Text, OutTy>> _p0) {
                                    auto&& p0 = std::get<0>(_p0);
                                    auto&& p1 = std::get<1>(_p0);
                                    return entered(once_job([=]() {
                                        return ({
                                            auto ok2 = p0;
                                            auto&& _ft = p1;
                                            auto&& ft = std::get<1>(_ft);
                                            (prism_rtl::finished(ok2 && podable(ft)));
                                        });
                                    }));
                                }))))));
                                });
                            }));
                        })))), .doc = type_doc(lx_1_7_7, ti_2_7_7)});
                    });
                    });
                }));
                });
            })));
            });
            ({
            auto&& _m = ti_2.body;
            prism_rtl::is<check_env::TyBody::BRecord>(_m) ? ({
            auto&& fs = prism_rtl::as<check_env::TyBody::BRecord>(_m).a0;
            ({
            auto fs_3 = fs;
            call_value(each_job(check_errors::range0(len(fs_3)), ({
            auto fs_3_4 = fs_3;
            auto lx_1_4 = lx_1;
            auto ti_2_4 = ti_2;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, OutTy>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
            return ({
                auto fs_3_4_4 = fs_3_4;
                auto lx_1_4_4 = lx_1_4;
                auto ti_2_4_4 = ti_2_4;
                entered(once_job([=]() {
                return ({
                    auto i = p0;
                    ({
                    auto [fname, ft] = or_(index(fs_3_4_4, i), std::tuple{Text(""), check_types::Ty(check_types::Ty::TyErr{})});
                    call_then(start_out_ty_of(lx_1_4_4, ft), [=](OutTy out_ty_of_316706) {
                    return ({
                        auto rt = out_ty_of_316706;
                        (prism_rtl::finished(std::tuple{snake(fname), rc_field(lx_1_4_4, ti_2_4_4.name, i)
                        ? OutTy(OutTy::OutRc{prism_rtl::rc(rt)})
                        : rt}));
                    });
                });
                });
                });
            }));
            });
        }));
        })), [=](Array<std::tuple<Text, OutTy>> each_316592) {
            return ({
                auto fields = each_316592;
                call_value(mk_fn(std::tuple{TyShape(TyShape::ShapeRecord{}), Array(std::vector{CaseDef{.name = camel(bare), .prism = bare, .fields = fields}})}), [=](TyDef mk_316823) { return prism_rtl::finished(Array(std::vector{Item(Item::ItType{mk_316823})})); });
            });
        });
        });
        })
            : prism_rtl::is<check_env::TyBody::BChoice>(_m) ? ({
            auto&& cases = prism_rtl::as<check_env::TyBody::BChoice>(_m).a0;
            ({
            auto cases_3 = cases;
            call_value(each_job(cases_3, ({
            auto ti_2_4 = ti_2;
            auto lx_1_4 = lx_1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<CaseDef>(std::tuple<Text, Array<check_types::Ty>>)>>(prism_rtl::rc([=](std::tuple<Text, Array<check_types::Ty>> p0) {
            return ({
                auto ti_2_4_4 = ti_2_4;
                auto lx_1_4_4 = lx_1_4;
                entered(once_job([=]() {
                return ({
                    auto [cn, ats] = p0;
                    ({
                    auto ck = check_env::qual_key(ti_2_4_4.home, cn);
                    call_value(each_job(check_errors::range0(len(ats)), ({
                    auto lx_1_4_4_4 = lx_1_4_4;
                    auto ck_4 = ck;
                    auto ats_5 = ats;
                    static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, OutTy>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
                    return ({
                        auto lx_1_4_4_4_6 = lx_1_4_4_4;
                        auto ck_4_6 = ck_4;
                        auto ats_5_6 = ats_5;
                        entered(once_job([=]() {
                        return ({
                            auto i = p0;
                            call_then(start_case_field(lx_1_4_4_4_6, ck_4_6, i, or_(index(ats_5_6, i), check_types::Ty(check_types::Ty::TyErr{}))), [=](OutTy case_field_317114) { return prism_rtl::finished(std::tuple{Text(""), case_field_317114}); });
                        });
                    }));
                    });
                }));
                })), [=](Array<std::tuple<Text, OutTy>> each_317077) { return prism_rtl::finished(CaseDef{.name = camel(cn), .prism = cn, .fields = each_317077}); });
                });
                });
            }));
            });
        })));
        })), [=](Array<CaseDef> each_316946) {
            return ({
                auto defs = each_316946;
                auto shape = ({
                    __label__ _done;
                    prism_rtl::Slot<TyShape> _v;
                    {
                        auto&& m317183_0 = cases;
                        if (m317183_0.size() == 1u) {
                            {
                                auto&& _c2 = index(m317183_0, Nat(0u));
                                if (prism_rtl::is_some(_c2)) {
                                    auto&& cn = std::get<0>(prism_rtl::some_of(_c2));
                                    auto&& m317183_0_0_1 = std::get<1>(prism_rtl::some_of(_c2));
                                    if (m317183_0_0_1.size() == 0u) {
                                        _v.set(check_env::is_lower_text(cn)
                                            ? TyShape(TyShape::ShapeUnit{})
                                            : TyShape(TyShape::ShapeChoice{}));
                                        goto _done;
                                    }
                                }
                            }
                        }
                    }
                    {
                        auto&& m317183_1 = cases;
                        if (m317183_1.size() == 1u) {
                            {
                                auto&& _c1 = index(m317183_1, Nat(0u));
                                if (prism_rtl::is_some(_c1)) {
                                    auto&& cn = std::get<0>(prism_rtl::some_of(_c1));
                                    _v.set(cn == bare
                                        ? TyShape(TyShape::ShapeNewtype{})
                                        : TyShape(TyShape::ShapeChoice{}));
                                    goto _done;
                                }
                            }
                        }
                    }
                    {
                        _v.set(TyShape(TyShape::ShapeChoice{}));
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                call_value(mk_fn(std::tuple{shape, defs}), [=](TyDef mk_317420) { return prism_rtl::finished(Array(std::vector{Item(Item::ItType{mk_317420})})); });
            });
        });
        });
        })
            : prism_rtl::is<check_env::TyBody::BRowKind>(_m) ? ti_2.name == Text("Prelude.Fault")
            ? prism_rtl::finished(Array<Item>{})
            : call_then(start_row_def_of(lx_1, ti_2), [=](RowDef row_def_of_317507) { return prism_rtl::finished(Array(std::vector{Item(Item::ItRow{row_def_of_317507})})); })
            : prism_rtl::finished(Array<Item>{});
        });
        });
    });
}


/// `Start TyDefs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Item>> start_ty_defs(Lx lx, check_env::TyInfo ti) {
    return std::make_shared<TyDefs>(lx, ti);
}


/// TyPodable: unbounded fn Lx, Ty, [Text] -> Bool
bool ty_podable(const Lx& lx, const check_types::Ty& t, const Array<Text>& seen) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        if (prism_rtl::is<check_types::Ty::TyFn>(t)) {
            _v.set(false);
            goto _done;
        }
        if (prism_rtl::is<check_types::Ty::TyAt>(t)) {
            _v.set(false);
            goto _done;
        }
        if (prism_rtl::is<check_types::Ty::TySig>(t)) {
            auto&& m317828_2_0 = prism_rtl::as<check_types::Ty::TySig>(t).a0;
            if (m317828_2_0 == Text("!")) {
                _v.set(false);
                goto _done;
            }
        }
        if (prism_rtl::is<check_types::Ty::TySig>(t)) {
            auto&& m317828_3_0 = prism_rtl::as<check_types::Ty::TySig>(t).a0;
            if (m317828_3_0 == Text("$")) {
                _v.set(false);
                goto _done;
            }
        }
        if (prism_rtl::is<check_types::Ty::TySig>(t)) {
            auto&& i = prism_rtl::as<check_types::Ty::TySig>(t).a1;
            _v.set(ty_podable(lx, i, seen));
            goto _done;
        }
        if (prism_rtl::is<check_types::Ty::TyTuple>(t)) {
            auto&& ts = prism_rtl::as<check_types::Ty::TyTuple>(t).a0;
            _v.set(run_to_end(fold_job(ts, true, ({
                auto lx_1 = lx;
                auto seen_2 = seen;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, check_types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, check_types::Ty> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto lx_1_3 = lx_1;
                    auto seen_2_3 = seen_2;
                    entered(once_job([=]() {
                    return ({
                        auto ok = p0;
                        auto x = p1;
                        (prism_rtl::finished(ok && ty_podable(lx_1_3, x, seen_2_3)));
                    });
                }));
                });
            })));
            }))));
            goto _done;
        }
        if (prism_rtl::is<check_types::Ty::TyArray>(t)) {
            auto&& e = prism_rtl::as<check_types::Ty::TyArray>(t).a0;
            _v.set(ty_podable(lx, e, seen));
            goto _done;
        }
        if (prism_rtl::is<check_types::Ty::TyMap>(t)) {
            auto&& k = prism_rtl::as<check_types::Ty::TyMap>(t).a0;
            auto&& v_ = prism_rtl::as<check_types::Ty::TyMap>(t).a1;
            _v.set(ty_podable(lx, k, seen) && ty_podable(lx, v_, seen));
            goto _done;
        }
        if (prism_rtl::is<check_types::Ty::TyCon>(t)) {
            auto&& n = prism_rtl::as<check_types::Ty::TyCon>(t).a0;
            auto&& args = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
            _v.set(check_types::has_text(seen, n)
                ? true
                : ({
                auto more = prelude::push(seen, n);
                auto args_ok = run_to_end(fold_job(args, true, ({
                    auto lx_1 = lx;
                    auto more_2 = more;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, check_types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, check_types::Ty> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto lx_1_3 = lx_1;
                        auto more_2_3 = more_2;
                        entered(once_job([=]() {
                        return ({
                            auto ok = p0;
                            auto x = p1;
                            (prism_rtl::finished(ok && ty_podable(lx_1_3, x, more_2_3)));
                        });
                    }));
                    });
                })));
                })));
                args_ok && ({
                __label__ _done;
                prism_rtl::Slot<bool> _v;
                auto&& _m = prelude::get(lx.g.types, n);
                if (prism_rtl::is_some(_m)) {
                    auto&& ti = prism_rtl::some_of(_m);
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<bool> _v;
                        auto&& _m = ti.body;
                        if (prism_rtl::is<check_env::TyBody::BRecord>(_m)) {
                            auto&& fs = prism_rtl::as<check_env::TyBody::BRecord>(_m).a0;
                            _v.set(run_to_end(fold_job(fs, true, ({
                                auto lx_1 = lx;
                                auto more_2 = more;
                                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, check_types::Ty>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<Text, check_types::Ty>> _p0) {
                                auto&& p0 = std::get<0>(_p0);
                                auto&& p1 = std::get<1>(_p0);
                                return ({
                                    auto lx_1_3 = lx_1;
                                    auto more_2_3 = more_2;
                                    entered(once_job([=]() {
                                    return ({
                                        auto ok = p0;
                                        auto&& _ft = p1;
                                        auto&& ft = std::get<1>(_ft);
                                        (prism_rtl::finished(ok && ty_podable(lx_1_3, ft, more_2_3)));
                                    });
                                }));
                                });
                            })));
                            }))));
                            goto _done;
                        }
                        if (prism_rtl::is<check_env::TyBody::BChoice>(_m)) {
                            auto&& cs = prism_rtl::as<check_env::TyBody::BChoice>(_m).a0;
                            _v.set(run_to_end(fold_job(cs, true, ({
                                auto lx_1 = lx;
                                auto more_2 = more;
                                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, Array<check_types::Ty>>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<Text, Array<check_types::Ty>>> _p0) {
                                auto&& p0 = std::get<0>(_p0);
                                auto&& p1 = std::get<1>(_p0);
                                return ({
                                    auto lx_1_3 = lx_1;
                                    auto more_2_3 = more_2;
                                    entered(once_job([=]() {
                                    return ({
                                        auto ok = p0;
                                        auto&& _ats = p1;
                                        auto&& ats = std::get<1>(_ats);
                                        (prism_rtl::finished(ok && run_to_end(fold_job(ats, true, ({
                                        auto lx_1_3_3 = lx_1_3;
                                        auto more_2_3_3 = more_2_3;
                                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, check_types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, check_types::Ty> _p0) {
                                        auto&& p0 = std::get<0>(_p0);
                                        auto&& p1 = std::get<1>(_p0);
                                        return ({
                                            auto lx_1_3_3_3 = lx_1_3_3;
                                            auto more_2_3_3_3 = more_2_3_3;
                                            entered(once_job([=]() {
                                            return ({
                                                auto ok2 = p0;
                                                auto x = p1;
                                                (prism_rtl::finished(ok2 && ty_podable(lx_1_3_3_3, x, more_2_3_3_3)));
                                            });
                                        }));
                                        });
                                    })));
                                    })))));
                                    });
                                }));
                                });
                            })));
                            }))));
                            goto _done;
                        }
                        if (prism_rtl::is<check_env::TyBody::BAlias>(_m)) {
                            auto&& a = prism_rtl::as<check_env::TyBody::BAlias>(_m).a0;
                            _v.set(ty_podable(lx, a, more));
                            goto _done;
                        }
                        {
                            _v.set(true);
                            goto _done;
                        }
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(true);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            }));
            goto _done;
        }
        {
            _v.set(true);
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<bool> TyPodable::cycle() const {
    const auto& lx = this->lx;
    const auto& t = this->t;
    const auto& seen = this->seen;
    return ({
        prism_rtl::is<check_types::Ty::TyFn>(t) ? prism_rtl::finished(false)
        : prism_rtl::is<check_types::Ty::TyAt>(t) ? prism_rtl::finished(false)
        : prism_rtl::is<check_types::Ty::TySig>(t) && ({
        auto&& m317828_2_0 = prism_rtl::as<check_types::Ty::TySig>(t).a0;
        (m317828_2_0 == Text("!"));
    }) ? ({
        auto&& m317828_2_0 = prism_rtl::as<check_types::Ty::TySig>(t).a0;
        prism_rtl::finished(false);
    })
        : prism_rtl::is<check_types::Ty::TySig>(t) && ({
        auto&& m317828_3_0 = prism_rtl::as<check_types::Ty::TySig>(t).a0;
        (m317828_3_0 == Text("$"));
    }) ? ({
        auto&& m317828_3_0 = prism_rtl::as<check_types::Ty::TySig>(t).a0;
        prism_rtl::finished(false);
    })
        : prism_rtl::is<check_types::Ty::TySig>(t) ? ({
        auto&& i = prism_rtl::as<check_types::Ty::TySig>(t).a1;
        prism_rtl::more(prism_rtl::rc(TyPodable(lx, i, seen)));
    })
        : prism_rtl::is<check_types::Ty::TyTuple>(t) ? ({
        auto&& ts = prism_rtl::as<check_types::Ty::TyTuple>(t).a0;
        fold_job(ts, true, ({
        auto lx_1 = lx;
        auto seen_2 = seen;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, check_types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, check_types::Ty> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_1_3 = lx_1;
            auto seen_2_3 = seen_2;
            entered(once_job([=]() {
            return ({
                auto ok = p0;
                auto x = p1;
                (prism_rtl::finished(ok && ty_podable(lx_1_3, x, seen_2_3)));
            });
        }));
        });
    })));
    }))->cycle();
    })
        : prism_rtl::is<check_types::Ty::TyArray>(t) ? ({
        auto&& e = prism_rtl::as<check_types::Ty::TyArray>(t).a0;
        prism_rtl::more(prism_rtl::rc(TyPodable(lx, e, seen)));
    })
        : prism_rtl::is<check_types::Ty::TyMap>(t) ? ({
        auto&& k = prism_rtl::as<check_types::Ty::TyMap>(t).a0;
        auto&& v_ = prism_rtl::as<check_types::Ty::TyMap>(t).a1;
        ({
        auto k_1 = k;
        auto lx_2 = lx;
        auto seen_3 = seen;
        auto v__4 = v_;
        call_then(start_ty_podable(lx_2, k_1, seen_3), [=](bool ty_podable_318131) { return prism_rtl::finished(ty_podable_318131 && ty_podable(lx_2, v__4, seen_3)); });
    });
    })
        : prism_rtl::is<check_types::Ty::TyCon>(t) ? ({
        auto&& n = prism_rtl::as<check_types::Ty::TyCon>(t).a0;
        auto&& args = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
        check_types::has_text(seen, n)
        ? prism_rtl::finished(true)
        : ({
        auto more = prelude::push(seen, n);
        auto args_1 = args;
        auto lx_2 = lx;
        auto n_3 = n;
        call_value(fold_job(args_1, true, ({
        auto lx_2_4 = lx_2;
        auto more_4 = more;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, check_types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, check_types::Ty> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_2_4_5 = lx_2_4;
            auto more_4_5 = more_4;
            entered(once_job([=]() {
            return ({
                auto ok = p0;
                auto x = p1;
                (prism_rtl::finished(ok && ty_podable(lx_2_4_5, x, more_4_5)));
            });
        }));
        });
    })));
    })), [=](bool fold_318307) {
        return ({
            auto args_ok = fold_318307;
            (prism_rtl::finished(args_ok && ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            auto&& _m = prelude::get(lx_2.g.types, n_3);
            if (prism_rtl::is_some(_m)) {
                auto&& ti = prism_rtl::some_of(_m);
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<bool> _v;
                    auto&& _m = ti.body;
                    if (prism_rtl::is<check_env::TyBody::BRecord>(_m)) {
                        auto&& fs = prism_rtl::as<check_env::TyBody::BRecord>(_m).a0;
                        _v.set(run_to_end(fold_job(fs, true, ({
                            auto lx_2_4 = lx_2;
                            auto more_4 = more;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, check_types::Ty>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<Text, check_types::Ty>> _p0) {
                            auto&& p0 = std::get<0>(_p0);
                            auto&& p1 = std::get<1>(_p0);
                            return ({
                                auto lx_2_4_5 = lx_2_4;
                                auto more_4_5 = more_4;
                                entered(once_job([=]() {
                                return ({
                                    auto ok = p0;
                                    auto&& _ft = p1;
                                    auto&& ft = std::get<1>(_ft);
                                    (prism_rtl::finished(ok && ty_podable(lx_2_4_5, ft, more_4_5)));
                                });
                            }));
                            });
                        })));
                        }))));
                        goto _done;
                    }
                    if (prism_rtl::is<check_env::TyBody::BChoice>(_m)) {
                        auto&& cs = prism_rtl::as<check_env::TyBody::BChoice>(_m).a0;
                        _v.set(run_to_end(fold_job(cs, true, ({
                            auto lx_2_4 = lx_2;
                            auto more_4 = more;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, Array<check_types::Ty>>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<Text, Array<check_types::Ty>>> _p0) {
                            auto&& p0 = std::get<0>(_p0);
                            auto&& p1 = std::get<1>(_p0);
                            return ({
                                auto lx_2_4_5 = lx_2_4;
                                auto more_4_5 = more_4;
                                entered(once_job([=]() {
                                return ({
                                    auto ok = p0;
                                    auto&& _ats = p1;
                                    auto&& ats = std::get<1>(_ats);
                                    (prism_rtl::finished(ok && run_to_end(fold_job(ats, true, ({
                                    auto lx_2_4_5_5 = lx_2_4_5;
                                    auto more_4_5_5 = more_4_5;
                                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, check_types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, check_types::Ty> _p0) {
                                    auto&& p0 = std::get<0>(_p0);
                                    auto&& p1 = std::get<1>(_p0);
                                    return ({
                                        auto lx_2_4_5_5_5 = lx_2_4_5_5;
                                        auto more_4_5_5_5 = more_4_5_5;
                                        entered(once_job([=]() {
                                        return ({
                                            auto ok2 = p0;
                                            auto x = p1;
                                            (prism_rtl::finished(ok2 && ty_podable(lx_2_4_5_5_5, x, more_4_5_5_5)));
                                        });
                                    }));
                                    });
                                })));
                                })))));
                                });
                            }));
                            });
                        })));
                        }))));
                        goto _done;
                    }
                    if (prism_rtl::is<check_env::TyBody::BAlias>(_m)) {
                        auto&& a = prism_rtl::as<check_env::TyBody::BAlias>(_m).a0;
                        _v.set(ty_podable(lx_2, a, more));
                        goto _done;
                    }
                    {
                        _v.set(true);
                        goto _done;
                    }
                _done:
                    _v.take();
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(true);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        })));
        });
    });
    });
    })
        : prism_rtl::finished(true);
    });
}


/// `Start TyPodable, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_ty_podable(Lx lx, check_types::Ty t, Array<Text> seen) {
    return std::make_shared<TyPodable>(lx, t, seen);
}


/// TyHasEq: unbounded fn Lx, Ty, [Text] -> Bool
bool ty_has_eq(const Lx& lx, const check_types::Ty& t, const Array<Text>& seen) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        if (prism_rtl::is<check_types::Ty::TyFn>(t)) {
            _v.set(false);
            goto _done;
        }
        if (prism_rtl::is<check_types::Ty::TyAt>(t)) {
            _v.set(false);
            goto _done;
        }
        if (prism_rtl::is<check_types::Ty::TySig>(t)) {
            auto&& m319261_2_0 = prism_rtl::as<check_types::Ty::TySig>(t).a0;
            if (m319261_2_0 == Text("!")) {
                _v.set(false);
                goto _done;
            }
        }
        if (prism_rtl::is<check_types::Ty::TySig>(t)) {
            auto&& m319261_3_0 = prism_rtl::as<check_types::Ty::TySig>(t).a0;
            if (m319261_3_0 == Text("$")) {
                _v.set(false);
                goto _done;
            }
        }
        if (prism_rtl::is<check_types::Ty::TySig>(t)) {
            auto&& i = prism_rtl::as<check_types::Ty::TySig>(t).a1;
            _v.set(ty_has_eq(lx, i, seen));
            goto _done;
        }
        if (prism_rtl::is<check_types::Ty::TyTuple>(t)) {
            auto&& ts = prism_rtl::as<check_types::Ty::TyTuple>(t).a0;
            _v.set(run_to_end(fold_job(ts, true, ({
                auto lx_1 = lx;
                auto seen_2 = seen;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, check_types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, check_types::Ty> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto lx_1_3 = lx_1;
                    auto seen_2_3 = seen_2;
                    entered(once_job([=]() {
                    return ({
                        auto ok = p0;
                        auto x = p1;
                        (prism_rtl::finished(ok && ty_has_eq(lx_1_3, x, seen_2_3)));
                    });
                }));
                });
            })));
            }))));
            goto _done;
        }
        if (prism_rtl::is<check_types::Ty::TyArray>(t)) {
            auto&& e = prism_rtl::as<check_types::Ty::TyArray>(t).a0;
            _v.set(ty_has_eq(lx, e, seen));
            goto _done;
        }
        if (prism_rtl::is<check_types::Ty::TyMap>(t)) {
            auto&& k = prism_rtl::as<check_types::Ty::TyMap>(t).a0;
            auto&& v_ = prism_rtl::as<check_types::Ty::TyMap>(t).a1;
            _v.set(ty_has_eq(lx, k, seen) && ty_has_eq(lx, v_, seen));
            goto _done;
        }
        if (prism_rtl::is<check_types::Ty::TyElem>(t)) {
            _v.set(true);
            goto _done;
        }
        if (prism_rtl::is<check_types::Ty::TyElemAny>(t)) {
            _v.set(true);
            goto _done;
        }
        if (prism_rtl::is<check_types::Ty::TyCon>(t)) {
            auto&& n = prism_rtl::as<check_types::Ty::TyCon>(t).a0;
            auto&& args = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
            _v.set(check_types::has_text(seen, n)
                ? true
                : ({
                auto args_ok = run_to_end(fold_job(args, true, ({
                    auto lx_1 = lx;
                    auto seen_2 = seen;
                    auto n_3 = n;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, check_types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, check_types::Ty> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto lx_1_4 = lx_1;
                        auto seen_2_4 = seen_2;
                        auto n_3_4 = n_3;
                        entered(once_job([=]() {
                        return ({
                            auto ok = p0;
                            auto x = p1;
                            (prism_rtl::finished(ok && ty_has_eq(lx_1_4, x, prelude::push(seen_2_4, n_3_4))));
                        });
                    }));
                    });
                })));
                })));
                args_ok && ({
                __label__ _done;
                prism_rtl::Slot<bool> _v;
                auto&& _m = prelude::get(lx.g.types, n);
                if (prism_rtl::is_some(_m)) {
                    auto&& ti = prism_rtl::some_of(_m);
                    _v.set(fold(ti.derives, false, [&](const bool& f, const Text& d) { return f || (check_types::bare_name(d) == Text("Eq")); }) || has_own_eq(lx, n));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(true);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            }));
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// HasOwnEq: fn Lx, Text -> Bool
bool has_own_eq(const Lx& lx, const Text& tn) {
    return fold(or_(prelude::get(lx.g.impls, Text("Prelude.Eq")), Array<check_env::ImplInfo>{}), false, [&](const bool& f, const check_env::ImplInfo& im) { return f || (head_name(im.head) == tn); });
}


/// CaseField: unbounded fn Lx, Text, Nat, Ty -> OutTy
OutTy case_field(const Lx& lx, const Text& ck, const Nat& i, const check_types::Ty& t) {
    auto rt = out_ty_of(lx, t);
    return rc_field(lx, ck, i) ? OutTy(OutTy::OutRc{prism_rtl::rc(rt)}) : rt;
}


prism_rtl::Turn<OutTy> CaseField::cycle() const {
    const auto& lx = this->lx;
    const auto& ck = this->ck;
    const auto& i = this->i;
    const auto& t = this->t;
    auto ck_1 = ck;
    auto i_2 = i;
    auto lx_3 = lx;
    auto t_4 = t;
    return call_then(start_out_ty_of(lx_3, t_4), [=](OutTy out_ty_of_320239) {
        return ({
            auto rt = out_ty_of_320239;
            rc_field(lx_3, ck_1, i_2)
            ? prism_rtl::finished(OutTy(OutTy::OutRc{prism_rtl::rc(rt)}))
            : prism_rtl::finished(rt);
        });
    });
}


/// `Start CaseField, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<OutTy> start_case_field(Lx lx, Text ck, Nat i, check_types::Ty t) {
    return std::make_shared<CaseField>(lx, ck, i, t);
}


/// TypeDoc: fn Lx, TyInfo -> Text
Text type_doc(const Lx& lx, const check_env::TyInfo& ti) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = index(lx.g.srcs, ti->file);
        if (prism_rtl::is_some(_m)) {
            auto&& src = prism_rtl::some_of(_m);
            _v.set(lexer::trim(check_errors::line_text(src, check_errors::cline_of(src.starts, ti.span.start))));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(ti.name);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// TagDefOf: unbounded fn Lx, TagInfo -> TagDef
TagDef tag_def_of(const Lx& lx, const check_env::TagInfo& tg) {
    auto fields = run_to_end(each_job(level_fields(tg), ({
        auto lx_1 = lx;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, Text, OutTy>>(std::tuple<Text, check_types::Ty>)>>(prism_rtl::rc([=](std::tuple<Text, check_types::Ty> p0) {
        return ({
            auto lx_1_2 = lx_1;
            entered(once_job([=]() {
            return ({
                auto [fname, ft] = p0;
                call_then(start_out_ty_of(lx_1_2, peel(ft)), [=](OutTy out_ty_of_320749) { return prism_rtl::finished(std::tuple{fname, snake(fname), out_ty_of_320749}); });
            });
        }));
        });
    }));
    })));
    return TagDef{.name = tag_struct(tg.name), .tag_name = tg.name, .fields = fields, .doc = type_doc(lx, check_env::TyInfo{.name = tg.name, .home = tg.home, .params = Array<Text>{}, .body = check_env::TyBody(check_env::TyBody::BOpaque{}), .derives = Array<Text>{}, .file = tg->file, .span = tg.span}), .pod = run_to_end(fold_job(fields, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, Text, OutTy>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<Text, Text, OutTy>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto ok = p0;
                auto&& _t = p1;
                auto&& t = std::get<2>(_t);
                (prism_rtl::finished(ok && podable(t)));
            });
        }));
    }))))};
}


prism_rtl::Turn<TagDef> TagDefOf::cycle() const {
    const auto& lx = this->lx;
    const auto& tg = this->tg;
    auto lx_1 = lx;
    auto tg_2 = tg;
    return call_value(each_job(level_fields(tg_2), ({
        auto lx_1_3 = lx_1;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, Text, OutTy>>(std::tuple<Text, check_types::Ty>)>>(prism_rtl::rc([=](std::tuple<Text, check_types::Ty> p0) {
        return ({
            auto lx_1_3_3 = lx_1_3;
            entered(once_job([=]() {
            return ({
                auto [fname, ft] = p0;
                call_then(start_out_ty_of(lx_1_3_3, peel(ft)), [=](OutTy out_ty_of_320749) { return prism_rtl::finished(std::tuple{fname, snake(fname), out_ty_of_320749}); });
            });
        }));
        });
    }));
    })), [=](Array<std::tuple<Text, Text, OutTy>> each_320684) {
        return ({
            auto fields = each_320684;
            call_value(fold_job(fields, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, Text, OutTy>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<Text, Text, OutTy>> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto ok = p0;
                    auto&& _t = p1;
                    auto&& t = std::get<2>(_t);
                    (prism_rtl::finished(ok && podable(t)));
                });
            }));
        }))), [=](bool fold_320973) { return prism_rtl::finished(TagDef{.name = tag_struct(tg_2.name), .tag_name = tg_2.name, .fields = fields, .doc = type_doc(lx_1, check_env::TyInfo{.name = tg_2.name, .home = tg_2.home, .params = Array<Text>{}, .body = check_env::TyBody(check_env::TyBody::BOpaque{}), .derives = Array<Text>{}, .file = tg_2->file, .span = tg_2.span}), .pod = fold_320973}); });
        });
    });
}


/// `Start TagDefOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<TagDef> start_tag_def_of(Lx lx, check_env::TagInfo tg) {
    return std::make_shared<TagDefOf>(lx, tg);
}


/// LevelFields: fn TagInfo -> [((Text, Ty))]
Array<std::tuple<Text, check_types::Ty>> level_fields(const check_env::TagInfo& tg) {
    return filter(tg.fields, [&](const std::tuple<Text, check_types::Ty>& _p0) {
        auto&& ft = std::get<1>(_p0);
        return layer_of(ft) != Layer(Layer::LyEv{});
    });
}


/// KindTags: fn Lx, Text, [Text] -> [TagInfo]
Array<check_env::TagInfo> kind_tags(const Lx& lx, const Text& kind, const Array<Text>& mods) {
    return filter(values(lx.g.tags), [&](const check_env::TagInfo& tg) { return (tg.kind == kind) && check_types::has_text(mods, tg.home); });
}


/// RowDefOf: unbounded fn Lx, TyInfo -> RowDef
RowDef row_def_of(const Lx& lx, const check_env::TyInfo& ti) {
    auto tags = kind_tags(lx, ti.name, keys(lx.rs_mods));
    auto cases = each(tags, [&](const check_env::TagInfo& tg) { return std::tuple{tag_struct(tg.name), path_in(lx, tg.home, tag_struct(tg.name))}; });
    auto pod = run_to_end(fold_job(tags, true, ({
        auto lx_1 = lx;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, check_env::TagInfo>)>>(prism_rtl::rc([=](std::tuple<bool, check_env::TagInfo> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_1_2 = lx_1;
            entered(once_job([=]() {
            return ({
                auto ok = p0;
                auto tg = p1;
                (prism_rtl::finished(ok && tag_def_of(lx_1_2, tg).pod));
            });
        }));
        });
    })));
    })));
    return RowDef{.name = camel(check_types::bare_name(ti.name)), .prism = ti.name, .cases_ = cases, .pod = pod, .doc = type_doc(lx, ti)};
}


prism_rtl::Turn<RowDef> RowDefOf::cycle() const {
    const auto& lx = this->lx;
    const auto& ti = this->ti;
    auto tags = kind_tags(lx, ti.name, keys(lx.rs_mods));
    auto cases = each(tags, [&](const check_env::TagInfo& tg) { return std::tuple{tag_struct(tg.name), path_in(lx, tg.home, tag_struct(tg.name))}; });
    auto lx_1 = lx;
    auto ti_2 = ti;
    return call_value(fold_job(tags, true, ({
        auto lx_1_3 = lx_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, check_env::TagInfo>)>>(prism_rtl::rc([=](std::tuple<bool, check_env::TagInfo> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_1_3_3 = lx_1_3;
            entered(once_job([=]() {
            return ({
                auto ok = p0;
                auto tg = p1;
                (prism_rtl::finished(ok && tag_def_of(lx_1_3_3, tg).pod));
            });
        }));
        });
    })));
    })), [=](bool fold_321687) {
        return ({
            auto pod = fold_321687;
            (prism_rtl::finished(RowDef{.name = camel(check_types::bare_name(ti_2.name)), .prism = ti_2.name, .cases_ = cases, .pod = pod, .doc = type_doc(lx_1, ti_2)}));
        });
    });
}


/// `Start RowDefOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<RowDef> start_row_def_of(Lx lx, check_env::TyInfo ti) {
    return std::make_shared<RowDefOf>(lx, ti);
}


/// ElemRow: unbounded fn Lx, [Text] -> RowDef
RowDef elem_row(const Lx& lx, const Array<Text>& mods) {
    auto tags = kind_tags(lx, Text("Element"), prelude::push(mods, Text("Prelude")));
    auto cases = each(tags, [&](const check_env::TagInfo& tg) { return std::tuple{tag_struct(tg.name), prism_rtl::cat(rust_mod_name(tg.home), "::", tag_struct(tg.name))}; });
    auto pod = run_to_end(fold_job(tags, true, ({
        auto lx_1 = lx;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, check_env::TagInfo>)>>(prism_rtl::rc([=](std::tuple<bool, check_env::TagInfo> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_1_2 = lx_1;
            entered(once_job([=]() {
            return ({
                auto ok = p0;
                auto tg = p1;
                (prism_rtl::finished(ok && tag_def_of(lx_1_2, tg).pod));
            });
        }));
        });
    })));
    })));
    return RowDef{.name = Text("Elem"), .prism = Text("Elem"), .cases_ = cases, .pod = pod, .doc = Text("`Elem r`: an element as a document holds it, its `Level` in a tick.")};
}


prism_rtl::Turn<RowDef> ElemRow::cycle() const {
    const auto& lx = this->lx;
    const auto& mods = this->mods;
    auto tags = kind_tags(lx, Text("Element"), prelude::push(mods, Text("Prelude")));
    auto cases = each(tags, [&](const check_env::TagInfo& tg) { return std::tuple{tag_struct(tg.name), prism_rtl::cat(rust_mod_name(tg.home), "::", tag_struct(tg.name))}; });
    auto lx_1 = lx;
    return call_value(fold_job(tags, true, ({
        auto lx_1_2 = lx_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, check_env::TagInfo>)>>(prism_rtl::rc([=](std::tuple<bool, check_env::TagInfo> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_1_2_2 = lx_1_2;
            entered(once_job([=]() {
            return ({
                auto ok = p0;
                auto tg = p1;
                (prism_rtl::finished(ok && tag_def_of(lx_1_2_2, tg).pod));
            });
        }));
        });
    })));
    })), [=](bool fold_322289) {
        return ({
            auto pod = fold_322289;
            (prism_rtl::finished(RowDef{.name = Text("Elem"), .prism = Text("Elem"), .cases_ = cases, .pod = pod, .doc = Text("`Elem r`: an element as a document holds it, its `Level` in a tick.")}));
        });
    });
}


/// `Start ElemRow, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<RowDef> start_elem_row(Lx lx, Array<Text> mods) {
    return std::make_shared<ElemRow>(lx, mods);
}


/// AnswerEnum: unbounded fn Lx, [Text] -> AnswerDef
AnswerDef answer_enum(const Lx& lx, const Array<Text>& mods) {
    auto tags = kind_tags(lx, Text("Element"), prelude::push(mods, Text("Prelude")));
    return AnswerDef{.cases_ = run_to_end(each_job(tags, ({
        auto lx_1 = lx;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<AnswerCase>(check_env::TagInfo)>>(prism_rtl::rc([=](check_env::TagInfo p0) {
        return ({
            auto lx_1_2 = lx_1;
            entered(once_job([=]() {
            return ({
                auto tg = p0;
                call_then(start_answer_ty(lx_1_2, tg), [=](OutTy answer_ty_322880) { return prism_rtl::finished(AnswerCase{.variant = tag_struct(tg.name), .accessor = answer_accessor(tg), .struct_path = prism_rtl::cat(rust_mod_name(tg.home), "::", tag_struct(tg.name)), .tag_name = tg.name, .ty = answer_ty_322880}); });
            });
        }));
        });
    })));
    })))};
}


prism_rtl::Turn<AnswerDef> AnswerEnum::cycle() const {
    const auto& lx = this->lx;
    const auto& mods = this->mods;
    auto tags = kind_tags(lx, Text("Element"), prelude::push(mods, Text("Prelude")));
    auto lx_1 = lx;
    return call_value(each_job(tags, ({
        auto lx_1_2 = lx_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<AnswerCase>(check_env::TagInfo)>>(prism_rtl::rc([=](check_env::TagInfo p0) {
        return ({
            auto lx_1_2_2 = lx_1_2;
            entered(once_job([=]() {
            return ({
                auto tg = p0;
                call_then(start_answer_ty(lx_1_2_2, tg), [=](OutTy answer_ty_322880) { return prism_rtl::finished(AnswerCase{.variant = tag_struct(tg.name), .accessor = answer_accessor(tg), .struct_path = prism_rtl::cat(rust_mod_name(tg.home), "::", tag_struct(tg.name)), .tag_name = tg.name, .ty = answer_ty_322880}); });
            });
        }));
        });
    })));
    })), [=](Array<AnswerCase> each_322715) { return prism_rtl::finished(AnswerDef{.cases_ = each_322715}); });
}


/// `Start AnswerEnum, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<AnswerDef> start_answer_enum(Lx lx, Array<Text> mods) {
    return std::make_shared<AnswerEnum>(lx, mods);
}


/// AnswerTy: unbounded fn Lx, TagInfo -> OutTy
OutTy answer_ty(const Lx& lx, const check_env::TagInfo& tg) {
    auto out = peel(tg->out);
    auto part = ({
        __label__ _done;
        prism_rtl::Slot<check_types::Ty> _v;
        if (prism_rtl::is<check_types::Ty::TyTuple>(out)) {
            auto&& cs = prism_rtl::as<check_types::Ty::TyTuple>(out).a0;
            _v.set(fold(cs, out, [&](const check_types::Ty& found, const check_types::Ty& c) { return layer_of(c) == Layer(Layer::LyEv{}) ? peel(c) : found; }));
            goto _done;
        }
        {
            _v.set(out);
            goto _done;
        }
    _done:
        _v.take();
    });
    return ({
        __label__ _done;
        prism_rtl::Slot<OutTy> _v;
        auto&& _m = out_ty_of(lx, part);
        if (prism_rtl::is<OutTy::OutGen>(_m)) {
            _v.set(OutTy(OutTy::OutPod{}));
            goto _done;
        }
        {
            auto&& t = _m;
            _v.set(t);
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<OutTy> AnswerTy::cycle() const {
    const auto& lx = this->lx;
    const auto& tg = this->tg;
    auto out = peel(tg->out);
    auto part = ({
        __label__ _done;
        prism_rtl::Slot<check_types::Ty> _v;
        if (prism_rtl::is<check_types::Ty::TyTuple>(out)) {
            auto&& cs = prism_rtl::as<check_types::Ty::TyTuple>(out).a0;
            _v.set(fold(cs, out, [&](const check_types::Ty& found, const check_types::Ty& c) { return layer_of(c) == Layer(Layer::LyEv{}) ? peel(c) : found; }));
            goto _done;
        }
        {
            _v.set(out);
            goto _done;
        }
    _done:
        _v.take();
    });
    auto lx_1 = lx;
    return call_then(start_out_ty_of(lx_1, part), [=](OutTy out_ty_of_323407) {
        return ({
            prism_rtl::is<OutTy::OutGen>(out_ty_of_323407) ? prism_rtl::finished(OutTy(OutTy::OutPod{}))
            : ({
            auto&& t = out_ty_of_323407;
            prism_rtl::finished(t);
        });
        });
    });
}


/// `Start AnswerTy, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<OutTy> start_answer_ty(Lx lx, check_env::TagInfo tg) {
    return std::make_shared<AnswerTy>(lx, tg);
}


/// TagPaths: fn Lx, TagInfo -> ((Text, Text))
std::tuple<Text, Text> tag_paths(const Lx& lx, const check_env::TagInfo& tg) {
    auto st = tag_struct(tg.name);
    auto struct_path = path_in(lx, tg.home, st);
    return std::tuple{prism_rtl::cat(kind_path(lx, tg.kind), "::", st), struct_path};
}


/// VariantOf: fn Lx, TagInfo -> Text
Text variant_of(const Lx& lx, const check_env::TagInfo& tg) {
    return prism_rtl::cat(kind_path(lx, tg.kind), "::", tag_struct(tg.name));
}


/// KindPath: fn Lx, Text -> Text
Text kind_path(const Lx& lx, const Text& kind) {
    return kind == Text("Element")
        ? Text("crate::Elem")
        : path_in(lx, or_(prelude::get(lx.g.types, kind), check_env::dummy_ty_info()).home, camel(check_types::bare_name(kind)));
}


/// CheckDefOf: unbounded fn Lx, CheckDecl -> CheckDef
CheckDef check_def_of(const Lx& lx, const ast::CheckDecl& c) {
    return CheckDef{.name = c.name.name, .lines = run_to_end(each_job(c.lines, ({
        auto lx_1 = lx;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(ast::CheckLine)>>(prism_rtl::rc([=](ast::CheckLine p0) {
        return ({
            auto lx_1_2 = lx_1;
            entered(once_job([=]() {
            return ({
                auto l = p0;
                call_then(start_value_of(lx_1_2, empty_env(), l.expr), [=](Vl value_of_324255) { return prism_rtl::finished(Ex(Ex::XCtor{Text("Ok"), Array(std::vector{Ex(Ex::XMethod{prism_rtl::rc(own(value_of_324255)), Text("to_pod"), Array<Ex>{}})})})); });
            });
        }));
        });
    })));
    })))};
}


prism_rtl::Turn<CheckDef> CheckDefOf::cycle() const {
    const auto& lx = this->lx;
    const auto& c = this->c;
    auto c_1 = c;
    auto lx_2 = lx;
    return call_value(each_job(c_1.lines, ({
        auto lx_2_3 = lx_2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(ast::CheckLine)>>(prism_rtl::rc([=](ast::CheckLine p0) {
        return ({
            auto lx_2_3_3 = lx_2_3;
            entered(once_job([=]() {
            return ({
                auto l = p0;
                call_then(start_value_of(lx_2_3_3, empty_env(), l.expr), [=](Vl value_of_324255) { return prism_rtl::finished(Ex(Ex::XCtor{Text("Ok"), Array(std::vector{Ex(Ex::XMethod{prism_rtl::rc(own(value_of_324255)), Text("to_pod"), Array<Ex>{}})})})); });
            });
        }));
        });
    })));
    })), [=](Array<Ex> each_324207) { return prism_rtl::finished(CheckDef{.name = c_1.name.name, .lines = each_324207}); });
}


/// `Start CheckDefOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<CheckDef> start_check_def_of(Lx lx, ast::CheckDecl c) {
    return std::make_shared<CheckDefOf>(lx, c);
}


/// ForLine: unbounded fn Wx, Env, Env, ?ForBinders, Expr, Block, Expr, ?Bn -> ((Wx, Wres))
std::tuple<Wx, Wres> for_line(const Wx& wx, const Env& benv, const Env& menv, const std::optional<ast::ForBinders>& binders_opt, const ast::Expr& source, const ast::Block& body, const ast::Expr& e, const std::optional<Bn>& bound_opt) {
    auto lx = wx.lx;
    auto pos = wx.pos;
    auto wx1 = ({
        Wx this_ = wx;
        this_.pos = next_pos(this_.pos);
        this_;
    });
    auto [src_ex, reads] = dynamic_expr(wx1, menv, source);
    auto src_ty = peel(type_at(lx, source.span));
    auto [kt, vt, keyed] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<OutTy, OutTy, bool>> _v;
        if (prism_rtl::is<check_types::Ty::TyMap>(src_ty)) {
            auto&& k = prism_rtl::as<check_types::Ty::TyMap>(src_ty).a0;
            auto&& v_ = prism_rtl::as<check_types::Ty::TyMap>(src_ty).a1;
            _v.set(std::tuple{out_ty_of(lx, k), out_ty_of(lx, v_), true});
            goto _done;
        }
        if (prism_rtl::is<check_types::Ty::TyArray>(src_ty)) {
            auto&& v_ = prism_rtl::as<check_types::Ty::TyArray>(src_ty).a0;
            _v.set(std::tuple{OutTy(OutTy::OutNat{}), out_ty_of(lx, v_), false});
            goto _done;
        }
        {
            _v.set(std::tuple{OutTy(OutTy::OutUnit{}), OutTy(OutTy::OutUnit{}), true});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto src = keyed
        ? src_ex
        : Ex(Ex::XCall{Text("indexed"), Array(std::vector{Ex(Ex::XRef{prism_rtl::rc(src_ex)})})});
    auto base_ = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        if (prism_rtl::is_some(bound_opt) && prism_rtl::is<Bn::BnEv>(prism_rtl::some_of(bound_opt))) {
            auto&& er = prism_rtl::as<Bn::BnEv>(prism_rtl::some_of(bound_opt)).a0;
            _v.set(gn_of(wx1, er.node_).name);
            goto _done;
        }
        {
            _v.set(Text("rows"));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto [name, wx2a] = fresh_name(wx1, base_);
    auto src_getter = prism_rtl::cat(name, "_source");
    auto wx2 = ({
        Wx this_ = wx2a;
        this_.taken = prelude::push(this_.taken, src_getter);
        this_.getters = prelude::push(this_.getters, MethDef{.name = src_getter, .recv = Recv(Recv::RecvRef{}), .params = Array<std::tuple<Text, OutTy>>{}, .cx_ = CxArg(CxArg::CxRef{}), .ret = OutTy(OutTy::OutMap{prism_rtl::rc(kt), prism_rtl::rc(vt)}), .body = Array<Do>{}, .tail = src, .doc = prism_rtl::cat("The source of the `for` at place ", place_text(pos), " by key, at the read point: what its builder and its rows' entries read.")});
        this_.dyn_reads = insert(this_.dyn_reads, src_getter, reads);
        this_;
    });
    auto row_name = prism_rtl::cat(wx.node_, row_suffix(wx), "Row");
    auto locals = row_locals(benv, menv, body);
    auto row_fields = append(Array(std::vector{std::tuple{Text("key"), kt, Text("the row's key")}, std::tuple{Text("left_entry"), OutTy(OutTy::OutCell{prism_rtl::rc(OutTy(OutTy::OutOpt{prism_rtl::rc(vt)}))}), Text("the entry as the tick its key left opened, kept from the row's leaving on (R8)")}, std::tuple{Text("parent"), OutTy(OutTy::OutWeak{wx.node_}), Text("the node of the `for`")}}), each(locals, [&](const RowLocal& l) { return std::tuple{l.field, l.ty, prism_rtl::cat("`", l.name, "`, the block's")}; }));
    auto row_moves = append(Array(std::vector{std::tuple{Text("key"), Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{Text("key")}))})}, std::tuple{Text("left_entry"), Ex(Ex::XCall{Text("RefCell::new"), Array(std::vector{Ex(Ex::XNone{})})})}, std::tuple{Text("parent"), Ex(Ex::XVar{Text("parent")})}}), each(locals, [&](const RowLocal& l) { return std::tuple{l.field, Ex(Ex::XVar{l.field})}; }));
    auto row_taken = append(append(node_hooks(), Array(std::vector{Text("key"), Text("value"), Text("parent"), Text("entry"), Text("left_entry")})), each(locals, [&](const RowLocal& l) { return l.field; }));
    auto row_wx0 = new_wx(lx, row_name, row_fields, Array<std::tuple<Text, Ex>>{}, row_moves, Array(std::vector{entry_getter(src_getter, vt)}), map_of(std::vector{std::tuple{Text("entry"), Array(std::vector{Read(Read::ParentRead{src_getter})})}}), row_taken, wx.depth, hosted_rows(wx));
    auto key_b = Bn(Bn::BnLocal{Ex(Ex::XVar{Text("key")}), Holding(Holding::Owned{}), kt});
    auto key_m = Bn(Bn::BnLocal{Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), Text("key")}), Holding(Holding::Owned{}), kt});
    auto benv_l = fold(locals, row_reads(benv, parent_arg()), [&](const Env& en, const RowLocal& l) { return bind(en, l.name, Bn(Bn::BnLocal{Ex(Ex::XVar{l.field}), Holding(Holding::Owned{}), l.ty})); });
    auto menv_l = fold(locals, row_reads(menv, parent_ref()), [&](const Env& en, const RowLocal& l) { return bind(en, l.name, Bn(Bn::BnLocal{Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), l.field}), Holding(Holding::Owned{}), l.ty})); });
    auto passed = append(hosted_passed(wx), each(locals, [&](const RowLocal& l) { return l.passed; }));
    auto row_params = append(append(Array(std::vector{std::tuple{Text("key"), kt}, std::tuple{Text("value"), vt}, std::tuple{Text("parent"), OutTy(OutTy::OutWeak{wx.node_})}}), hosted_params(wx)), each(locals, [&](const RowLocal& l) { return std::tuple{l.field, l.ty}; }));
    auto entry_m = Bn(Bn::BnDyn{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XSelf{})), Text("entry"), Array(std::vector{Ex(Ex::XCx{})})}), Array(std::vector{Read(Read::ParentRead{src_getter})}), vt});
    auto [rbe, rme] = for_envs(benv_l, menv_l, binders_opt, key_b, key_m, Bn(Bn::BnLocal{Ex(Ex::XVar{Text("value")}), Holding(Holding::Owned{}), vt}), entry_m, vt);
    auto row_wx = block_into(row_wx0, rbe, rme, body);
    auto wx3 = ({
        Wx this_ = wx2;
        this_.row_marks = prelude::push(this_.row_marks, RowMarks{.builder = name, .reads = row_place_reads(row_wx), .wrote = row_hears(row_wx), .kind = RowKind(RowKind::ForRow{})});
        this_;
    });
    auto full = type_at(lx, e.span);
    auto out_ty = out_ty_of(lx, peel(full));
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Wx, Wres>> _v;
        auto&& _m = row_wx->result;
        if (prism_rtl::is<Wres::WrEv>(_m)) {
            auto&& r = prism_rtl::as<Wres::WrEv>(_m).a0;
            _v.set(({
                auto [gid, wx4] = add_gn(wx3, prism_rtl::cat(name, "_all"), out_ty, GnKind(GnKind::GnGather{}), Nat(1u));
                auto wx5 = add_field_last(wx4, prism_rtl::cat(name, "_gathered"), OutTy(OutTy::OutStamped{prism_rtl::rc(out_ty)}), Text("the rows' firings this tick, by key"), Ex(Ex::XCall{Text("Stamped::new"), Array<Ex>{}}));
                auto wx6 = ({
                    Wx this_ = wx5;
                    this_.gns = each(this_.gns, [&](const Gn& n) {
                        return n.id == gid
                            ? with_inputs(n, Array(std::vector{prism_rtl::cat(name, "_gathered")}))
                            : n;
                    });
                    this_;
                });
                auto row_done = connect(row_wx, r, Sk(Sk::SkUp{prism_rtl::cat(name, "_all_in")}));
                auto wx7 = add_builder(wx6, name, pos, kt, vt, row_name, keyed, reads, PendingRow{.wx = row_done, .qk = row_name, .params = row_params, .gather = std::optional(gid)}, passed);
                std::tuple{wx7, Wres(Wres::WrEv{ev_ref_of(gid)})};
            }));
            goto _done;
        }
        if (prism_rtl::is<Wres::WrDyn>(_m)) {
            auto&& ex = prism_rtl::as<Wres::WrDyn>(_m).a0;
            auto&& result_reads = prism_rtl::as<Wres::WrDyn>(_m).a1;
            auto&& rt = prism_rtl::as<Wres::WrDyn>(_m).a2;
            _v.set(({
                auto gathered = prism_rtl::cat(name, "_all");
                auto gathered_ty = OutTy(OutTy::OutMap{prism_rtl::rc(kt), prism_rtl::rc(rt)});
                auto own_behind = filter(reads_closed(row_wx.dyn_reads, result_reads), [&](const Read& r) {
                    return ({
                        __label__ _done;
                        prism_rtl::Slot<bool> _v;
                        if (prism_rtl::is<Read::OwnRead>(r)) {
                            _v.set(true);
                            goto _done;
                        }
                        if (prism_rtl::is<Read::ParentRead>(r)) {
                            _v.set(false);
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                });
                auto row_done = ({
                    Wx this_ = row_wx;
                    this_.getters = prelude::push(this_.getters, MethDef{.name = Text("result"), .recv = Recv(Recv::RecvRef{}), .params = Array<std::tuple<Text, OutTy>>{}, .cx_ = CxArg(CxArg::CxRef{}), .ret = rt, .body = Array<Do>{}, .tail = ex, .doc = Text("The row's result, which the block gathers by key.")});
                    this_.result_moved = len(own_behind) > Nat(0u)
                        ? std::optional(std::tuple{prism_rtl::cat(gathered, "_moved"), own_behind})
                        : std::optional<std::tuple<Text, Array<Read>>>{};
                    this_;
                });
                auto wx4 = add_builder(wx3, name, pos, kt, vt, row_name, keyed, reads, PendingRow{.wx = row_done, .qk = row_name, .params = row_params, .gather = std::optional<Nat>{}}, passed);
                auto all = Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), name})), Text("borrow"), Array<Ex>{}})), Text("iter"), Array<Ex>{}})), Text("map"), Array(std::vector{Ex(Ex::XClosure{false, Array(std::vector{Pa(Pa::PaTuple{Array(std::vector{Pa(Pa::PaBind{Text("k")}), Pa(Pa::PaBind{Text("row")})})})}), prism_rtl::rc(Ex(Ex::XTuple{Array(std::vector{Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{Text("k")}))}), Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text("row")})), Text("result"), Array(std::vector{Ex(Ex::XCx{})})})})}))})})})), Text("collect"), Array<Ex>{}});
                auto what = prism_rtl::cat("the dynamic gathered by the `for` at place ", place_text(pos));
                auto wx5 = ({
                    Wx this_ = wx4;
                    this_.taken = append(this_.taken, Array(std::vector{gathered, prism_rtl::cat(gathered, "_now"), prism_rtl::cat(gathered, "_snap"), prism_rtl::cat(gathered, "_moved"), prism_rtl::cat(gathered, "_publish")}));
                    this_.getters = append(this_.getters, Array(std::vector{MethDef{.name = prism_rtl::cat(gathered, "_now"), .recv = Recv(Recv::RecvRef{}), .params = Array<std::tuple<Text, OutTy>>{}, .cx_ = CxArg(CxArg::CxRef{}), .ret = gathered_ty, .body = Array<Do>{}, .tail = all, .doc = Text("The rows' results by key, computed live: what the snapshot of the `for`'s dynamic is taken from (pick ST).")}, snap_getter(gathered, gathered_ty, Text("The `for`'s dynamic, the rows' results by key, a structural dynamic (pick ST): one tick behind the rows, the snapshot of the tick before the tick the read point is after."))}));
                    this_.fields = prelude::push(this_.fields, std::tuple{prism_rtl::cat(gathered, "_snap"), OutTy(OutTy::OutSnapshot{prism_rtl::rc(gathered_ty)}), prism_rtl::cat("the `for` at place ", place_text(pos), "'s gathered dynamic, structural: its snapshots, the rows' results and the lagged dynamic (pick ST)")});
                    this_.inits = prelude::push(this_.inits, std::tuple{prism_rtl::cat(gathered, "_snap"), Ex(Ex::XCall{Text("Snapshot::new"), Array(std::vector{Ex(Ex::XStr{what})})})});
                    this_.snaps = prelude::push(this_.snaps, SnapDef{.name = gathered, .live = prism_rtl::cat(gathered, "_now"), .ty = gathered_ty, .eq = ty_has_eq(lx, peel(full), Array<Text>{}), .builder = name, .before = false, .what = what});
                    this_.dyn_reads = insert(this_.dyn_reads, prism_rtl::cat(gathered, "_now"), union_reads(reads, block_reads(reads_closed(row_wx.dyn_reads, result_reads))));
                    this_;
                });
                std::tuple{wx5, Wres(Wres::WrDyn{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XSelf{})), gathered, Array(std::vector{Ex(Ex::XCx{})})}), Array(std::vector{Read(Read::OwnRead{gathered})}), gathered_ty})};
            }));
            goto _done;
        }
        {
            _v.set(({
                auto wx4 = add_builder(wx3, name, pos, kt, vt, row_name, keyed, reads, PendingRow{.wx = row_wx, .qk = row_name, .params = row_params, .gather = std::optional<Nat>{}}, passed);
                std::tuple{wx4, Wres(Wres::WrUnit{})};
            }));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::tuple<Wx, Wres>> ForLine::cycle() const {
    const auto& wx = this->wx;
    const auto& benv = this->benv;
    const auto& menv = this->menv;
    const auto& binders_opt = this->binders_opt;
    const auto& source = this->source;
    const auto& body = this->body;
    const auto& e = this->e;
    const auto& bound_opt = this->bound_opt;
    auto lx = wx.lx;
    auto pos = wx.pos;
    auto wx1 = ({
        Wx this_ = wx;
        this_.pos = next_pos(this_.pos);
        this_;
    });
    auto binders_opt_1 = binders_opt;
    auto bound_opt_2 = bound_opt;
    auto benv_3 = benv;
    auto body_4 = body;
    auto e_5 = e;
    auto menv_6 = menv;
    auto source_7 = source;
    auto wx_8 = wx;
    return call_then(start_dynamic_expr(wx1, menv_6, source_7), [=](std::tuple<Ex, Array<Read>> dynamic_expr_325143) {
        return ({
            auto [src_ex, reads] = dynamic_expr_325143;
            auto src_ty = peel(type_at(lx, source_7.span));
            auto [kt, vt, keyed] = ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<OutTy, OutTy, bool>> _v;
                if (prism_rtl::is<check_types::Ty::TyMap>(src_ty)) {
                    auto&& k = prism_rtl::as<check_types::Ty::TyMap>(src_ty).a0;
                    auto&& v_ = prism_rtl::as<check_types::Ty::TyMap>(src_ty).a1;
                    _v.set(std::tuple{out_ty_of(lx, k), out_ty_of(lx, v_), true});
                    goto _done;
                }
                if (prism_rtl::is<check_types::Ty::TyArray>(src_ty)) {
                    auto&& v_ = prism_rtl::as<check_types::Ty::TyArray>(src_ty).a0;
                    _v.set(std::tuple{OutTy(OutTy::OutNat{}), out_ty_of(lx, v_), false});
                    goto _done;
                }
                {
                    _v.set(std::tuple{OutTy(OutTy::OutUnit{}), OutTy(OutTy::OutUnit{}), true});
                    goto _done;
                }
            _done:
                _v.take();
            });
            auto src = keyed
                ? src_ex
                : Ex(Ex::XCall{Text("indexed"), Array(std::vector{Ex(Ex::XRef{prism_rtl::rc(src_ex)})})});
            auto base_ = ({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                if (prism_rtl::is_some(bound_opt) && prism_rtl::is<Bn::BnEv>(prism_rtl::some_of(bound_opt))) {
                    auto&& er = prism_rtl::as<Bn::BnEv>(prism_rtl::some_of(bound_opt)).a0;
                    _v.set(gn_of(wx1, er.node_).name);
                    goto _done;
                }
                {
                    _v.set(Text("rows"));
                    goto _done;
                }
            _done:
                _v.take();
            });
            auto [name, wx2a] = fresh_name(wx1, base_);
            auto src_getter = prism_rtl::cat(name, "_source");
            auto wx2 = ({
                Wx this_ = wx2a;
                this_.taken = prelude::push(this_.taken, src_getter);
                this_.getters = prelude::push(this_.getters, MethDef{.name = src_getter, .recv = Recv(Recv::RecvRef{}), .params = Array<std::tuple<Text, OutTy>>{}, .cx_ = CxArg(CxArg::CxRef{}), .ret = OutTy(OutTy::OutMap{prism_rtl::rc(kt), prism_rtl::rc(vt)}), .body = Array<Do>{}, .tail = src, .doc = prism_rtl::cat("The source of the `for` at place ", place_text(pos), " by key, at the read point: what its builder and its rows' entries read.")});
                this_.dyn_reads = insert(this_.dyn_reads, src_getter, reads);
                this_;
            });
            auto row_name = prism_rtl::cat(wx_8.node_, row_suffix(wx_8), "Row");
            auto locals = row_locals(benv_3, menv_6, body_4);
            auto row_fields = append(Array(std::vector{std::tuple{Text("key"), kt, Text("the row's key")}, std::tuple{Text("left_entry"), OutTy(OutTy::OutCell{prism_rtl::rc(OutTy(OutTy::OutOpt{prism_rtl::rc(vt)}))}), Text("the entry as the tick its key left opened, kept from the row's leaving on (R8)")}, std::tuple{Text("parent"), OutTy(OutTy::OutWeak{wx_8.node_}), Text("the node of the `for`")}}), each(locals, [&](const RowLocal& l) { return std::tuple{l.field, l.ty, prism_rtl::cat("`", l.name, "`, the block's")}; }));
            auto row_moves = append(Array(std::vector{std::tuple{Text("key"), Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{Text("key")}))})}, std::tuple{Text("left_entry"), Ex(Ex::XCall{Text("RefCell::new"), Array(std::vector{Ex(Ex::XNone{})})})}, std::tuple{Text("parent"), Ex(Ex::XVar{Text("parent")})}}), each(locals, [&](const RowLocal& l) { return std::tuple{l.field, Ex(Ex::XVar{l.field})}; }));
            auto row_taken = append(append(node_hooks(), Array(std::vector{Text("key"), Text("value"), Text("parent"), Text("entry"), Text("left_entry")})), each(locals, [&](const RowLocal& l) { return l.field; }));
            auto row_wx0 = new_wx(lx, row_name, row_fields, Array<std::tuple<Text, Ex>>{}, row_moves, Array(std::vector{entry_getter(src_getter, vt)}), map_of(std::vector{std::tuple{Text("entry"), Array(std::vector{Read(Read::ParentRead{src_getter})})}}), row_taken, wx_8.depth, hosted_rows(wx_8));
            auto key_b = Bn(Bn::BnLocal{Ex(Ex::XVar{Text("key")}), Holding(Holding::Owned{}), kt});
            auto key_m = Bn(Bn::BnLocal{Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), Text("key")}), Holding(Holding::Owned{}), kt});
            auto benv_l = fold(locals, row_reads(benv_3, parent_arg()), [&](const Env& en, const RowLocal& l) { return bind(en, l.name, Bn(Bn::BnLocal{Ex(Ex::XVar{l.field}), Holding(Holding::Owned{}), l.ty})); });
            auto menv_l = fold(locals, row_reads(menv_6, parent_ref()), [&](const Env& en, const RowLocal& l) { return bind(en, l.name, Bn(Bn::BnLocal{Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), l.field}), Holding(Holding::Owned{}), l.ty})); });
            auto passed = append(hosted_passed(wx_8), each(locals, [&](const RowLocal& l) { return l.passed; }));
            auto row_params = append(append(Array(std::vector{std::tuple{Text("key"), kt}, std::tuple{Text("value"), vt}, std::tuple{Text("parent"), OutTy(OutTy::OutWeak{wx_8.node_})}}), hosted_params(wx_8)), each(locals, [&](const RowLocal& l) { return std::tuple{l.field, l.ty}; }));
            auto entry_m = Bn(Bn::BnDyn{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XSelf{})), Text("entry"), Array(std::vector{Ex(Ex::XCx{})})}), Array(std::vector{Read(Read::ParentRead{src_getter})}), vt});
            auto [rbe, rme] = for_envs(benv_l, menv_l, binders_opt_1, key_b, key_m, Bn(Bn::BnLocal{Ex(Ex::XVar{Text("value")}), Holding(Holding::Owned{}), vt}), entry_m, vt);
            call_then(start_block_into(row_wx0, rbe, rme, body_4), [=](Wx block_into_328089) {
            return ({
                auto row_wx = block_into_328089;
                auto wx3 = ({
                    Wx this_ = wx2;
                    this_.row_marks = prelude::push(this_.row_marks, RowMarks{.builder = name, .reads = row_place_reads(row_wx), .wrote = row_hears(row_wx), .kind = RowKind(RowKind::ForRow{})});
                    this_;
                });
                auto full = type_at(lx, e_5.span);
                call_then(start_out_ty_of(lx, peel(full)), [=](OutTy out_ty_of_328327) {
                return ({
                    auto out_ty = out_ty_of_328327;
                    ({
                    auto&& _m = row_wx->result;
                    prism_rtl::is<Wres::WrEv>(_m) ? ({
                    auto&& r = prism_rtl::as<Wres::WrEv>(_m).a0;
                    ({
                    auto [gid, wx4] = add_gn(wx3, prism_rtl::cat(name, "_all"), out_ty, GnKind(GnKind::GnGather{}), Nat(1u));
                    auto wx5 = add_field_last(wx4, prism_rtl::cat(name, "_gathered"), OutTy(OutTy::OutStamped{prism_rtl::rc(out_ty)}), Text("the rows' firings this tick, by key"), Ex(Ex::XCall{Text("Stamped::new"), Array<Ex>{}}));
                    auto wx6 = ({
                        Wx this_ = wx5;
                        this_.gns = each(this_.gns, [&](const Gn& n) {
                            return n.id == gid
                                ? with_inputs(n, Array(std::vector{prism_rtl::cat(name, "_gathered")}))
                                : n;
                        });
                        this_;
                    });
                    auto row_done = connect(row_wx, r, Sk(Sk::SkUp{prism_rtl::cat(name, "_all_in")}));
                    auto wx7 = add_builder(wx6, name, pos, kt, vt, row_name, keyed, reads, PendingRow{.wx = row_done, .qk = row_name, .params = row_params, .gather = std::optional(gid)}, passed);
                    (prism_rtl::finished(std::tuple{wx7, Wres(Wres::WrEv{ev_ref_of(gid)})}));
                });
                })
                    : prism_rtl::is<Wres::WrDyn>(_m) ? ({
                    auto&& ex = prism_rtl::as<Wres::WrDyn>(_m).a0;
                    auto&& result_reads = prism_rtl::as<Wres::WrDyn>(_m).a1;
                    auto&& rt = prism_rtl::as<Wres::WrDyn>(_m).a2;
                    ({
                    auto gathered = prism_rtl::cat(name, "_all");
                    auto gathered_ty = OutTy(OutTy::OutMap{prism_rtl::rc(kt), prism_rtl::rc(rt)});
                    auto own_behind = filter(reads_closed(row_wx.dyn_reads, result_reads), [&](const Read& r) {
                        return ({
                            __label__ _done;
                            prism_rtl::Slot<bool> _v;
                            if (prism_rtl::is<Read::OwnRead>(r)) {
                                _v.set(true);
                                goto _done;
                            }
                            if (prism_rtl::is<Read::ParentRead>(r)) {
                                _v.set(false);
                                goto _done;
                            }
                            prism_rtl::unreachable("no arm matched");
                        _done:
                            _v.take();
                        });
                    });
                    auto row_done = ({
                        Wx this_ = row_wx;
                        this_.getters = prelude::push(this_.getters, MethDef{.name = Text("result"), .recv = Recv(Recv::RecvRef{}), .params = Array<std::tuple<Text, OutTy>>{}, .cx_ = CxArg(CxArg::CxRef{}), .ret = rt, .body = Array<Do>{}, .tail = ex, .doc = Text("The row's result, which the block gathers by key.")});
                        this_.result_moved = len(own_behind) > Nat(0u)
                            ? std::optional(std::tuple{prism_rtl::cat(gathered, "_moved"), own_behind})
                            : std::optional<std::tuple<Text, Array<Read>>>{};
                        this_;
                    });
                    auto wx4 = add_builder(wx3, name, pos, kt, vt, row_name, keyed, reads, PendingRow{.wx = row_done, .qk = row_name, .params = row_params, .gather = std::optional<Nat>{}}, passed);
                    auto all = Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), name})), Text("borrow"), Array<Ex>{}})), Text("iter"), Array<Ex>{}})), Text("map"), Array(std::vector{Ex(Ex::XClosure{false, Array(std::vector{Pa(Pa::PaTuple{Array(std::vector{Pa(Pa::PaBind{Text("k")}), Pa(Pa::PaBind{Text("row")})})})}), prism_rtl::rc(Ex(Ex::XTuple{Array(std::vector{Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{Text("k")}))}), Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text("row")})), Text("result"), Array(std::vector{Ex(Ex::XCx{})})})})}))})})})), Text("collect"), Array<Ex>{}});
                    auto what = prism_rtl::cat("the dynamic gathered by the `for` at place ", place_text(pos));
                    auto wx5 = ({
                        Wx this_ = wx4;
                        this_.taken = append(this_.taken, Array(std::vector{gathered, prism_rtl::cat(gathered, "_now"), prism_rtl::cat(gathered, "_snap"), prism_rtl::cat(gathered, "_moved"), prism_rtl::cat(gathered, "_publish")}));
                        this_.getters = append(this_.getters, Array(std::vector{MethDef{.name = prism_rtl::cat(gathered, "_now"), .recv = Recv(Recv::RecvRef{}), .params = Array<std::tuple<Text, OutTy>>{}, .cx_ = CxArg(CxArg::CxRef{}), .ret = gathered_ty, .body = Array<Do>{}, .tail = all, .doc = Text("The rows' results by key, computed live: what the snapshot of the `for`'s dynamic is taken from (pick ST).")}, snap_getter(gathered, gathered_ty, Text("The `for`'s dynamic, the rows' results by key, a structural dynamic (pick ST): one tick behind the rows, the snapshot of the tick before the tick the read point is after."))}));
                        this_.fields = prelude::push(this_.fields, std::tuple{prism_rtl::cat(gathered, "_snap"), OutTy(OutTy::OutSnapshot{prism_rtl::rc(gathered_ty)}), prism_rtl::cat("the `for` at place ", place_text(pos), "'s gathered dynamic, structural: its snapshots, the rows' results and the lagged dynamic (pick ST)")});
                        this_.inits = prelude::push(this_.inits, std::tuple{prism_rtl::cat(gathered, "_snap"), Ex(Ex::XCall{Text("Snapshot::new"), Array(std::vector{Ex(Ex::XStr{what})})})});
                        this_.snaps = prelude::push(this_.snaps, SnapDef{.name = gathered, .live = prism_rtl::cat(gathered, "_now"), .ty = gathered_ty, .eq = ty_has_eq(lx, peel(full), Array<Text>{}), .builder = name, .before = false, .what = what});
                        this_.dyn_reads = insert(this_.dyn_reads, prism_rtl::cat(gathered, "_now"), union_reads(reads, block_reads(reads_closed(row_wx.dyn_reads, result_reads))));
                        this_;
                    });
                    (prism_rtl::finished(std::tuple{wx5, Wres(Wres::WrDyn{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XSelf{})), gathered, Array(std::vector{Ex(Ex::XCx{})})}), Array(std::vector{Read(Read::OwnRead{gathered})}), gathered_ty})}));
                });
                })
                    : ({
                    auto wx4 = add_builder(wx3, name, pos, kt, vt, row_name, keyed, reads, PendingRow{.wx = row_wx, .qk = row_name, .params = row_params, .gather = std::optional<Nat>{}}, passed);
                    (prism_rtl::finished(std::tuple{wx4, Wres(Wres::WrUnit{})}));
                });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start ForLine, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Wx, Wres>> start_for_line(Wx wx, Env benv, Env menv, std::optional<ast::ForBinders> binders_opt, ast::Expr source, ast::Block body, ast::Expr e, std::optional<Bn> bound_opt) {
    return std::make_shared<ForLine>(wx, benv, menv, binders_opt, source, body, e, bound_opt);
}


/// EntryGetter: fn Text, OutTy -> MethDef
MethDef entry_getter(const Text& src_getter, const OutTy& vt) {
    auto found = Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text("parent")})), src_getter, Array(std::vector{Ex(Ex::XCx{})})})), Text("get"), Array(std::vector{Ex(Ex::XRef{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), Text("key")}))})})})), Text("cloned"), Array<Ex>{}});
    auto opened_1 = Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XCx{})), Text("before"), Array(std::vector{Ex(Ex::XClosure{false, Array(std::vector{Pa(Pa::PaBind{Text("cx")})}), prism_rtl::rc(found)})})})), Text("expect"), Array(std::vector{Ex(Ex::XStr{Text("a row's key is in its source as its tick opened")})})});
    auto body = Array(std::vector{Do(Do::DoIfLet{Pa(Pa::PaCtor{Text("Some"), Array(std::vector{Pa(Pa::PaBind{Text("v")})})}), Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), Text("left_entry")})), Text("borrow"), Array<Ex>{}})), Text("as_ref"), Array<Ex>{}}), Array(std::vector{Do(Do::DoReturn{Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{Text("v")}))})})}), Array<Do>{}}), Do(Do::DoLet{Pa(Pa::PaBind{Text("parent")}), parent_ref()})});
    auto tail_ = Ex(Ex::XMatch{prism_rtl::rc(found), Array(std::vector{XArm{.pat = Pa(Pa::PaCtor{Text("Some"), Array(std::vector{Pa(Pa::PaBind{Text("v")})})}), .conds = Array<Cc>{}, .body = Ex(Ex::XVar{Text("v")})}, XArm{.pat = Pa(Pa::PaUnit{Text("None")}), .conds = Array<Cc>{}, .body = opened_1}}), false, vt});
    return MethDef{.name = Text("entry"), .recv = Recv(Recv::RecvRef{}), .params = Array<std::tuple<Text, OutTy>>{}, .cx_ = CxArg(CxArg::CxRef{}), .ret = vt, .body = body, .tail = tail_, .doc = Text("The row's entry, `$_`: the block's source at this key, at the read point; from the row's leaving on, the value as the leaving tick opened.")};
}


/// AddBuilder: fn Wx, Text, Pos, OutTy, OutTy, Text, Bool, [Read], PendingRow, [Ex] -> Wx
Wx add_builder(const Wx& wx, const Text& name, const Pos_& pos, const OutTy& kt, const OutTy& vt, const Text& row_name, const bool& keyed, const Array<Read>& reads, const PendingRow& waiting, const Array<Ex>& passed) {
    auto wx0 = add_field_last(wx, name, OutTy(OutTy::OutCell{prism_rtl::rc(OutTy(OutTy::OutMap{prism_rtl::rc(kt), prism_rtl::rc(OutTy(OutTy::OutRc{prism_rtl::rc(OutTy(OutTy::OutNamed{row_name, Array<OutTy>{}}))}))}))}), prism_rtl::cat("the rows of the `for` at place ", place_text(pos)), Ex(Ex::XCall{Text("RefCell::new"), Array(std::vector{Ex(Ex::XCall{Text("Map::new"), Array<Ex>{}})})}));
    Wx this_ = wx0;
    this_.builders = prelude::push(this_.builders, ForDef{.name = name, .pos = pos, .at = place_at(wx, Text("self"), pos), .key_ty = kt, .value_ty = vt, .row_node = row_name, .keyed = keyed, .source = prism_rtl::cat(name, "_source"), .parent = Ex(Ex::XWeak{prism_rtl::rc(Ex(Ex::XSelf{}))}), .passed = passed});
    this_.build_holds = union_reads(this_.build_holds, reads);
    this_.pending = prelude::push(this_.pending, waiting);
    return this_;
}


/// RowPlaceReads: fn Wx -> [Read]
Array<Read> row_place_reads(const Wx& row_wx) {
    return fold(row_wx.places, Array<Read>{}, [&](const Array<Read>& acc, const Place& pl) { return union_reads(acc, block_reads(reads_closed(row_wx.dyn_reads, pl.reads))); });
}


/// HostedParams: fn Wx -> [((Text, OutTy))]
Array<std::tuple<Text, OutTy>> hosted_params(const Wx& wx) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Array<std::tuple<Text, OutTy>>> _v;
        auto&& _m = hosted_rows(wx);
        if (prism_rtl::is_some(_m)) {
            _v.set(Array(std::vector{std::tuple{Text("enclosing"), host_of_ty()}}));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Array<std::tuple<Text, OutTy>>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// HostedPassed: fn Wx -> [Ex]
Array<Ex> hosted_passed(const Wx& wx) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Array<Ex>> _v;
        auto&& _m = hosted_rows(wx);
        if (prism_rtl::is_some(_m)) {
            _v.set(Array(std::vector{Ex(Ex::XClone{prism_rtl::rc(host_field_ex(wx, wx.pos))})}));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Array<Ex>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// RowReads: fn Env, Ex -> Env
Env row_reads(const Env& env, const Ex& pref) {
    return fold(keys(env->names), env, [&](const Env& en, const Text& k) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Env> _v;
            auto&& _m = prelude::get(env->names, k);
            if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnHold>(prism_rtl::some_of(_m))) {
                auto&& f = prism_rtl::as<Bn::BnHold>(prism_rtl::some_of(_m)).a0;
                auto&& t = prism_rtl::as<Bn::BnHold>(prism_rtl::some_of(_m)).a1;
                _v.set(bind(en, k, Bn(Bn::BnDyn{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(pref), f})), Text("get"), Array(std::vector{Ex(Ex::XCx{})})}), Array(std::vector{Read(Read::ParentRead{f})}), t})));
                goto _done;
            }
            if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnDyn>(prism_rtl::some_of(_m)) && prism_rtl::is<Ex::XMethod>(prism_rtl::as<Bn::BnDyn>(prism_rtl::some_of(_m)).a0)) {
                auto&& m335599_1_0_0 = prism_rtl::as<Ex::XMethod>(prism_rtl::as<Bn::BnDyn>(prism_rtl::some_of(_m)).a0).a0;
                auto&& m = prism_rtl::as<Ex::XMethod>(prism_rtl::as<Bn::BnDyn>(prism_rtl::some_of(_m)).a0).a1;
                auto&& xs = prism_rtl::as<Ex::XMethod>(prism_rtl::as<Bn::BnDyn>(prism_rtl::some_of(_m)).a0).a2;
                auto&& t = prism_rtl::as<Bn::BnDyn>(prism_rtl::some_of(_m)).a2;
                if (prism_rtl::is<Ex::XSelf>(m335599_1_0_0)) {
                    _v.set(bind(en, k, Bn(Bn::BnDyn{Ex(Ex::XMethod{prism_rtl::rc(pref), m, xs}), Array(std::vector{Read(Read::ParentRead{m})}), t})));
                    goto _done;
                }
            }
            {
                _v.set(en);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


/// BlockReads: fn [Read] -> [Read]
Array<Read> block_reads(const Array<Read>& reads) {
    return fold(reads, Array<Read>{}, [&](const Array<Read>& acc, const Read& r) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Read>> _v;
            if (prism_rtl::is<Read::ParentRead>(r)) {
                auto&& f = prism_rtl::as<Read::ParentRead>(r).a0;
                _v.set(add_read(acc, Read(Read::OwnRead{f})));
                goto _done;
            }
            if (prism_rtl::is<Read::OwnRead>(r)) {
                _v.set(acc);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
}


/// RowLocals: unbounded fn Env, Env, Block -> [RowLocal]
Array<RowLocal> row_locals(const Env& benv, const Env& menv, const ast::Block& body) {
    return fold(read_names(typed::block_exprs(body)), Array<RowLocal>{}, [&](const Array<RowLocal>& acc, const Text& n) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<RowLocal>> _v;
            auto&& _m = prelude::get(menv->names, n);
            if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m))) {
                auto&& rs = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                auto&& mode = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a1;
                auto&& t = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                _v.set(({
                    auto field = snake(n);
                    (((field == Text("key")) || (field == Text("value"))) || (field == Text("parent"))) || (field == Text("path"))
                    ? acc
                    : prelude::push(acc, RowLocal{.name = n, .field = field, .ty = t, .passed = own(Vl(Vl::VlPlace{rs, mode, t}))});
                }));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


/// ForEnvs: unbounded fn Env, Env, ?ForBinders, Bn, Bn, Bn, Bn, OutTy -> ((Env, Env))
std::tuple<Env, Env> for_envs(const Env& benv, const Env& menv, const std::optional<ast::ForBinders>& binders_opt, const Bn& key_b, const Bn& key_m, const Bn& val_b, const Bn& val_m, const OutTy& vt) {
    auto be0 = bind(bind(benv, Text("key"), key_b), Text("$_"), val_b);
    auto me0 = bind(bind(menv, Text("key"), key_m), Text("$_"), val_m);
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Env, Env>> _v;
        if (prism_rtl::is_none(binders_opt)) {
            _v.set(std::tuple{be0, me0});
            goto _done;
        }
        if (prism_rtl::is_some(binders_opt)) {
            auto&& fb = prism_rtl::some_of(binders_opt);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::tuple<Env, Env>> _v;
                auto&& _m = fb.second;
                if (prism_rtl::is_some(_m)) {
                    auto&& second = prism_rtl::some_of(_m);
                    _v.set(({
                        auto be1 = bind_pat(be0, fb.first, key_b, Ex(Ex::XVar{Text("key")}), kt0());
                        auto me1 = bind_pat(me0, fb.first, key_m, Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), Text("key")}), kt0());
                        std::tuple{bind_pat(be1, second, val_b, Ex(Ex::XVar{Text("value")}), vt), bind_pat(me1, second, val_m, Ex(Ex::XUnit{}), vt)};
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(std::tuple{bind_pat(be0, fb.first, val_b, Ex(Ex::XVar{Text("value")}), vt), bind_pat(me0, fb.first, val_m, Ex(Ex::XUnit{}), vt)});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}

}  // namespace crate::lower
