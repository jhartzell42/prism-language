// The module `Lower`, from `target/bootstrap/cpp-src/prismc/lower.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (docs/backend.md). Edit the Prism source, not this file.
#include "lower.hpp"
#include "ast.hpp"
#include "check_env.hpp"
#include "check_errors.hpp"
#include "check_types.hpp"
#include "lexer.hpp"
#include "typed.hpp"
#include "lower.generic.hpp"
#include "check_env.generic.hpp"
#include "lexer.generic.hpp"

namespace crate::lower {

/// UpdatedEvent: unbounded fn Wx, Env, [Arg], OutTy -> ((EvRef, Wx))
std::tuple<EvRef, Wx> updated_event(const Wx& wx, const Env& menv, const Array<ast::Arg>& args, const OutTy& t) {
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<EvRef, Wx>> _v;
        auto&& _m = index(args, Nat(0u));
        if (prism_rtl::is_some(_m)) {
            auto&& a = prism_rtl::some_of(_m);
            _v.set(({
                auto [ex, reads] = dynamic_expr(wx, menv, a->value);
                auto [nm, w1] = fresh_name(wx, Text("updated"));
                auto [id, w2] = add_gn(w1, nm, t, GnKind(GnKind::GnUpdated{}), Nat(1u));
                auto w3 = add_field_last(w2, prism_rtl::cat(nm, "_moved"), OutTy(OutTy::OutNamed{Text("Cell"), Array(std::vector{OutTy(OutTy::OutBool{})})}), prism_rtl::cat("a hold `!", nm, "`'s dynamic reads was written this tick"), Ex(Ex::XCall{Text("Cell::new"), Array(std::vector{Ex(Ex::XBool{false})})}));
                auto w4 = ({
                    Wx this_ = w3;
                    this_.gns = each(this_.gns, [&](const Gn& n) { return n.id == id ? with_reads(n, reads) : n; });
                    this_.getters = prelude::push(this_.getters, MethDef{.name = prism_rtl::cat(nm, "_value"), .recv = Recv(Recv::RecvRef{}), .params = Array<std::tuple<Text, OutTy>>{}, .cx_ = CxArg(CxArg::CxRef{}), .ret = t, .body = Array<Do>{}, .tail = ex, .doc = prism_rtl::cat("The dynamic `!", nm, "` is the event half of, which the wake reads after the tick.")});
                    this_;
                });
                std::tuple{ev_ref_of(w4, id), w4};
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(never_event(wx, t));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// FilterEvent: unbounded fn Wx, Env, [Arg], Bool -> ((EvRef, Wx))
std::tuple<EvRef, Wx> filter_event(const Wx& wx, const Env& menv, const Array<ast::Arg>& args, const bool& is_unit) {
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<EvRef, Wx>> _v;
        auto&& _m = index(args, Nat(0u));
        if (prism_rtl::is_none(_m)) {
            _v.set(never_event(wx, OutTy(OutTy::OutUnit{})));
            goto _done;
        }
        if (prism_rtl::is_some(_m)) {
            auto&& a = prism_rtl::some_of(_m);
            _v.set(({
                auto [r, w1] = event_ref(wx, menv, a->value);
                auto bound = is_unit ? Pa(Pa::PaWild{}) : Pa(Pa::PaBind{Text("w")});
                auto pipe = ({
                    auto r_1 = r;
                    auto bound_2 = bound;
                    auto is_unit_3 = is_unit;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(std::tuple<Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(Ex)>>)>>(prism_rtl::rc([=](std::tuple<Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(Ex)>> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto r_1_4 = r_1;
                        auto bound_2_4 = bound_2;
                        auto is_unit_3_4 = is_unit_3;
                        entered(once_job([=]() {
                        return ({
                            auto x = p0;
                            auto k_fn = p1;
                            r_1_4.pipe(std::tuple{x, ({
                            auto bound_2_4_4 = bound_2_4;
                            auto k_fn_4 = k_fn;
                            auto is_unit_3_4_5 = is_unit_3_4;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(Ex)>>(prism_rtl::rc([=](Ex p0) {
                            return ({
                                auto bound_2_4_4_5 = bound_2_4_4;
                                auto k_fn_4_5 = k_fn_4;
                                auto is_unit_3_4_5_5 = is_unit_3_4_5;
                                entered(once_job([=]() {
                                return ({
                                    auto y = p0;
                                    call_value(k_fn_4_5(is_unit_3_4_5_5 ? Ex(Ex::XUnit{}) : Ex(Ex::XVar{Text("w")})), [=](Array<Do> k_260440) { return prism_rtl::finished(Array(std::vector{Do(Do::DoIfLet{Pa(Pa::PaCtor{Text("Some"), Array(std::vector{bound_2_4_4_5})}), y, k_260440, Array<Do>{}})})); });
                                });
                            }));
                            });
                        })));
                        })})->cycle();
                        });
                    }));
                    });
                })));
                });
                std::tuple{EvRef{.node_ = r.node_, .owner = r.owner, .pipe = pipe}, w1};
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// GateEvent: unbounded fn Wx, Env, [Arg] -> ((EvRef, Wx))
std::tuple<EvRef, Wx> gate_event(const Wx& wx, const Env& menv, const Array<ast::Arg>& args) {
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<EvRef, Wx>> _v;
        auto&& _m = index(args, Nat(1u));
        if (prism_rtl::is_none(_m)) {
            _v.set(never_event(wx, OutTy(OutTy::OutUnit{})));
            goto _done;
        }
        if (prism_rtl::is_some(_m)) {
            auto&& a = prism_rtl::some_of(_m);
            _v.set(({
                auto [r, w1] = event_ref(wx, menv, a->value);
                auto cond = ({
                    __label__ _done;
                    prism_rtl::Slot<Ex> _v;
                    auto&& _m = index(args, Nat(0u));
                    if (prism_rtl::is_some(_m)) {
                        auto&& b = prism_rtl::some_of(_m);
                        _v.set(as_bool(value_of(wx.lx, menv, b->value)));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(Ex(Ex::XBool{false}));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                auto pipe = ({
                    auto r_1 = r;
                    auto cond_2 = cond;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(std::tuple<Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(Ex)>>)>>(prism_rtl::rc([=](std::tuple<Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(Ex)>> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto r_1_3 = r_1;
                        auto cond_2_3 = cond_2;
                        entered(once_job([=]() {
                        return ({
                            auto x = p0;
                            auto k_fn = p1;
                            r_1_3.pipe(std::tuple{x, ({
                            auto cond_2_3_3 = cond_2_3;
                            auto k_fn_3 = k_fn;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(Ex)>>(prism_rtl::rc([=](Ex p0) {
                            return ({
                                auto cond_2_3_3_4 = cond_2_3_3;
                                auto k_fn_3_4 = k_fn_3;
                                entered(once_job([=]() {
                                return ({
                                    auto y = p0;
                                    call_value(k_fn_3_4(y), [=](Array<Do> k_260973) { return prism_rtl::finished(Array(std::vector{Do(Do::DoIf{cond_2_3_3_4, k_260973, Array<Do>{}})})); });
                                });
                            }));
                            });
                        })));
                        })})->cycle();
                        });
                    }));
                    });
                })));
                });
                std::tuple{EvRef{.node_ = r.node_, .owner = r.owner, .pipe = pipe}, w1};
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// EventMap: unbounded fn Wx, Env, Expr -> ((EvRef, Wx))
std::tuple<EvRef, Wx> event_map(const Wx& wx, const Env& menv, const ast::Expr& e) {
    auto lx = wx.lx;
    auto t = out_ty_of(lx, peel(type_at(lx, e.span)));
    auto evs = filter(operands(e), [&](const ast::Expr& x) { return layer_of(type_at(lx, x.span)) == Layer(Layer::LyEv{}); });
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<EvRef, Wx>> _v;
        {
            auto&& m261455_0 = evs;
            if (m261455_0.size() == 1u) {
                {
                    auto&& _c1 = index(m261455_0, Nat(0u));
                    if (prism_rtl::is_some(_c1)) {
                        auto&& one = prism_rtl::some_of(_c1);
                        _v.set(({
                            auto [r, w1] = event_ref(wx, menv, one);
                            auto et = out_ty_of(lx, peel(type_at(lx, one.span)));
                            auto k = place_key(lx, one.span);
                            auto pipe = ({
                                auto r_1 = r;
                                auto lx_2 = lx;
                                auto menv_3 = menv;
                                auto k_4 = k;
                                auto et_5 = et;
                                auto e_6 = e;
                                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(std::tuple<Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(Ex)>>)>>(prism_rtl::rc([=](std::tuple<Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(Ex)>> _p0) {
                                auto&& p0 = std::get<0>(_p0);
                                auto&& p1 = std::get<1>(_p0);
                                return ({
                                    auto r_1_7 = r_1;
                                    auto lx_2_7 = lx_2;
                                    auto menv_3_7 = menv_3;
                                    auto k_4_7 = k_4;
                                    auto et_5_7 = et_5;
                                    auto e_6_7 = e_6;
                                    entered(once_job([=]() {
                                    return ({
                                        auto x = p0;
                                        auto k_fn = p1;
                                        r_1_7.pipe(std::tuple{x, ({
                                        auto k_fn_7 = k_fn;
                                        auto lx_2_7_8 = lx_2_7;
                                        auto menv_3_7_8 = menv_3_7;
                                        auto k_4_7_8 = k_4_7;
                                        auto et_5_7_8 = et_5_7;
                                        auto e_6_7_8 = e_6_7;
                                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(Ex)>>(prism_rtl::rc([=](Ex p0) {
                                        return ({
                                            auto k_fn_7_8 = k_fn_7;
                                            auto lx_2_7_8_8 = lx_2_7_8;
                                            auto menv_3_7_8_8 = menv_3_7_8;
                                            auto k_4_7_8_8 = k_4_7_8;
                                            auto et_5_7_8_8 = et_5_7_8;
                                            auto e_6_7_8_8 = e_6_7_8;
                                            entered(once_job([=]() {
                                            return ({
                                                auto y = p0;
                                                call_then(start_value_of(lx_2_7_8_8, bind_span(menv_3_7_8_8, k_4_7_8_8, firing_value(y, et_5_7_8_8)), e_6_7_8_8), [=](Vl value_of_261692) { return k_fn_7_8(own(value_of_261692))->cycle(); });
                                            });
                                        }));
                                        });
                                    })));
                                    })})->cycle();
                                    });
                                }));
                                });
                            })));
                            });
                            std::tuple{EvRef{.node_ = r.node_, .owner = r.owner, .pipe = pipe}, w1};
                        }));
                        goto _done;
                    }
                }
            }
        }
        {
            _v.set(never_event(wx, t));
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// FiringValue: fn Ex, OutTy -> Vl
Vl firing_value(const Ex& ex0, const OutTy& t) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Vl> _v;
        if (prism_rtl::is<Ex::XVar>(ex0)) {
            auto&& n = prism_rtl::as<Ex::XVar>(ex0).a0;
            _v.set(Vl(Vl::VlPlace{Ex(Ex::XVar{n}), Holding(Holding::Owned{}), t}));
            goto _done;
        }
        if (prism_rtl::is<Ex::XUnit>(ex0)) {
            _v.set(Vl(Vl::VlPlace{Ex(Ex::XUnit{}), Holding(Holding::Owned{}), t}));
            goto _done;
        }
        {
            auto&& x = ex0;
            _v.set(Vl(Vl::VlOwned{x, t}));
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// Operands: fn Expr -> [Expr]
Array<ast::Expr> operands(const ast::Expr& e) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Array<ast::Expr>> _v;
        auto&& _m = e.kind;
        if (prism_rtl::is<ast::ExprKind::ECall>(_m)) {
            auto&& c = prism_rtl::as<ast::ExprKind::ECall>(_m).a0;
            auto&& args = prism_rtl::as<ast::ExprKind::ECall>(_m).a1;
            _v.set(append(Array(std::vector{c}), each(args, [&](const ast::Arg& a) { return a->value; })));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EMethod>(_m)) {
            auto&& r = prism_rtl::as<ast::ExprKind::EMethod>(_m).a0;
            auto&& args = prism_rtl::as<ast::ExprKind::EMethod>(_m).a2;
            _v.set(append(Array(std::vector{r}), each(args, [&](const ast::Arg& a) { return a->value; })));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EBinary>(_m)) {
            auto&& l = prism_rtl::as<ast::ExprKind::EBinary>(_m).a1;
            auto&& r = prism_rtl::as<ast::ExprKind::EBinary>(_m).a2;
            _v.set(Array(std::vector{l, r}));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EUnary>(_m)) {
            auto&& x = prism_rtl::as<ast::ExprKind::EUnary>(_m).a1;
            _v.set(Array(std::vector{x}));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EFreeSigil>(_m)) {
            auto&& x = prism_rtl::as<ast::ExprKind::EFreeSigil>(_m).a1;
            _v.set(Array(std::vector{x}));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EGroup>(_m)) {
            auto&& x = prism_rtl::as<ast::ExprKind::EGroup>(_m).a0;
            _v.set(Array(std::vector{x}));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EField>(_m)) {
            auto&& r = prism_rtl::as<ast::ExprKind::EField>(_m).a0;
            _v.set(Array(std::vector{r}));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EIndex>(_m)) {
            auto&& r = prism_rtl::as<ast::ExprKind::EIndex>(_m).a0;
            auto&& i = prism_rtl::as<ast::ExprKind::EIndex>(_m).a1;
            _v.set(Array(std::vector{r, i}));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::ETuple>(_m)) {
            auto&& es = prism_rtl::as<ast::ExprKind::ETuple>(_m).a0;
            _v.set(es);
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EArray>(_m)) {
            auto&& es = prism_rtl::as<ast::ExprKind::EArray>(_m).a0;
            _v.set(es);
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EMap>(_m)) {
            auto&& kvs = prism_rtl::as<ast::ExprKind::EMap>(_m).a0;
            _v.set(fold(kvs, Array<ast::Expr>{}, [&](const Array<ast::Expr>& acc, const std::tuple<ast::Expr, ast::Expr>& _p1) {
                auto&& k = std::get<0>(_p1);
                auto&& v_ = std::get<1>(_p1);
                return append(acc, Array(std::vector{k, v_}));
            }));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::ELit>(_m)) {
            auto&& l = prism_rtl::as<ast::ExprKind::ELit>(_m).a0;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<Array<ast::Expr>> _v;
                auto&& _m = l.kind;
                if (prism_rtl::is<ast::LitKind::LText>(_m)) {
                    auto&& segs = prism_rtl::as<ast::LitKind::LText>(_m).a0;
                    _v.set(fold(segs, Array<ast::Expr>{}, [&](const Array<ast::Expr>& acc, const ast::TextSeg& sg) {
                        return ({
                            __label__ _done;
                            prism_rtl::Slot<Array<ast::Expr>> _v;
                            if (prism_rtl::is<ast::TextSeg::SegPlaceholder>(sg)) {
                                auto&& x = prism_rtl::as<ast::TextSeg::SegPlaceholder>(sg).a0;
                                _v.set(prelude::push(acc, x));
                                goto _done;
                            }
                            {
                                _v.set(acc);
                                goto _done;
                            }
                        _done:
                            _v.take();
                        });
                    }));
                    goto _done;
                }
                {
                    _v.set(Array<ast::Expr>{});
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        {
            _v.set(Array<ast::Expr>{});
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// Merge: fn Wx, Text, OutTy, EvRef, EvRef -> ((Nat, Wx))
std::tuple<Nat, Wx> merge(const Wx& wx, const Text& name, const OutTy& t, const EvRef& l, const EvRef& r) {
    return combinator(wx, name, t, GnKind(GnKind::GnMerge{}), l, r, t, t);
}


/// Combinator: fn Wx, Text, OutTy, GnKind, EvRef, EvRef, OutTy, OutTy -> ((Nat, Wx))
std::tuple<Nat, Wx> combinator(const Wx& wx, const Text& name, const OutTy& t, const GnKind& kind, const EvRef& l, const EvRef& r, const OutTy& lt, const OutTy& rt) {
    auto [id, wx1] = add_gn(wx, name, t, kind, Nat(1u));
    auto wx2 = add_field_last(wx1, prism_rtl::cat(name, "_left"), OutTy(OutTy::OutStamped{prism_rtl::rc(lt)}), prism_rtl::cat("`", name, "`'s left input"), Ex(Ex::XCall{Text("Stamped::new"), Array<Ex>{}}));
    auto wx3 = add_field_last(wx2, prism_rtl::cat(name, "_right"), OutTy(OutTy::OutStamped{prism_rtl::rc(rt)}), Text("its right input"), Ex(Ex::XCall{Text("Stamped::new"), Array<Ex>{}}));
    auto wx4 = ({
        Wx this_ = wx3;
        this_.gns = each(this_.gns, [&](const Gn& n) {
            return n.id == id
                ? with_inputs(n, Array(std::vector{prism_rtl::cat(name, "_left"), prism_rtl::cat(name, "_right")}))
                : n;
        });
        this_;
    });
    return std::tuple{id, connect(connect(wx4, l, Sk(Sk::SkIn{id, Nat(0u)})), r, Sk(Sk::SkIn{id, Nat(1u)}))};
}


/// WithInputs: fn Gn, [Text] -> Gn
Gn with_inputs(const Gn& n, const Array<Text>& ins) {
    Gn this_ = n;
    this_.inputs = ins;
    return this_;
}


/// WithReads: fn Gn, [Read] -> Gn
Gn with_reads(const Gn& n, const Array<Read>& reads) {
    Gn this_ = n;
    this_.reads = reads;
    return this_;
}


/// Heights: fn [Gn] -> [Gn]
Array<Gn> heights(const Array<Gn>& gns) {
    return fold(gns, gns, [&](const Array<Gn>& cur, const Gn& _p1) { return each(cur, [&](const Gn& n) { return height_step(cur, n); }); });
}


/// HeightStep: fn [Gn], Gn -> Gn
Gn height_step(const Array<Gn>& gns, const Gn& n) {
    auto feeders = filter(gns, [&](const Gn& m) { return fold(m.outs, false, [&](const bool& f, const Out& o) { return f || feeds(o.sink, n); }); });
    auto top = fold(feeders, Nat(0u), [&](const Nat& hi, const Gn& m) { return prelude::max(hi, m.height); });
    auto h = ({
        __label__ _done;
        prism_rtl::Slot<Nat> _v;
        auto&& _m = n.kind;
        if (prism_rtl::is<GnKind::GnNamed>(_m)) {
            _v.set(top);
            goto _done;
        }
        {
            auto&& kind = _m;
            _v.set(is_comb(kind) ? prelude::max(top + Nat(1u), n.floor) : n.height);
            goto _done;
        }
    _done:
        _v.take();
    });
    Gn this_ = n;
    this_.height = h;
    return this_;
}


/// IsComb: fn GnKind -> Bool
bool is_comb(const GnKind& k) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        if (prism_rtl::is<GnKind::GnMerge>(k)) {
            _v.set(true);
            goto _done;
        }
        if (prism_rtl::is<GnKind::GnUnion>(k)) {
            _v.set(true);
            goto _done;
        }
        if (prism_rtl::is<GnKind::GnBoth>(k)) {
            _v.set(true);
            goto _done;
        }
        if (prism_rtl::is<GnKind::GnExcept>(k)) {
            _v.set(true);
            goto _done;
        }
        if (prism_rtl::is<GnKind::GnMergeAll>(k)) {
            _v.set(true);
            goto _done;
        }
        if (prism_rtl::is<GnKind::GnUpdated>(k)) {
            _v.set(true);
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// Feeds: fn Sk, Gn -> Bool
bool feeds(const Sk& sk0, const Gn& n) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        if (prism_rtl::is<Sk::SkNode>(sk0)) {
            auto&& m = prism_rtl::as<Sk::SkNode>(sk0).a0;
            _v.set(m == n.id);
            goto _done;
        }
        if (prism_rtl::is<Sk::SkIn>(sk0)) {
            auto&& m = prism_rtl::as<Sk::SkIn>(sk0).a0;
            _v.set(m == n.id);
            goto _done;
        }
        if (prism_rtl::is<Sk::SkCycle>(sk0)) {
            auto&& m = prism_rtl::as<Sk::SkCycle>(sk0).a2;
            _v.set(m == n.id);
            goto _done;
        }
        if (prism_rtl::is<Sk::SkMachine>(sk0)) {
            auto&& f = prism_rtl::as<Sk::SkMachine>(sk0).a0;
            auto&& m = prism_rtl::as<Sk::SkMachine>(sk0).a2;
            _v.set((m == n.id) || writes(f, n));
            goto _done;
        }
        if (prism_rtl::is<Sk::SkHold>(sk0)) {
            auto&& f = prism_rtl::as<Sk::SkHold>(sk0).a0;
            _v.set(writes(f, n));
            goto _done;
        }
        {
            auto&& other = sk0;
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// Writes: fn Text, Gn -> Bool
bool writes(const Text& f, const Gn& n) {
    return moves(Read(Read::OwnRead{f}), n);
}


/// Moves: fn Read, Gn -> Bool
bool moves(const Read& r, const Gn& n) {
    return (n.kind == GnKind(GnKind::GnUpdated{})) && has_read(n.reads, r);
}


/// ReadsClosed: fn (Text ==> [Read]), [Read] -> [Read]
Array<Read> reads_closed(const Map<Text, Array<Read>>& dyn_, const Array<Read>& reads) {
    return fold(check_errors::range0(Nat(4u)), reads, [&](const Array<Read>& acc, const Nat& _p1) { return fold(acc, acc, [&](const Array<Read>& a, const Read& r) { return union_reads(a, getter_reads(dyn_, r)); }); });
}


/// GetterReads: fn (Text ==> [Read]), Read -> [Read]
Array<Read> getter_reads(const Map<Text, Array<Read>>& dyn_, const Read& read1) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Array<Read>> _v;
        if (prism_rtl::is<Read::OwnRead>(read1)) {
            auto&& n = prism_rtl::as<Read::OwnRead>(read1).a0;
            _v.set(or_(prelude::get(dyn_, n), Array<Read>{}));
            goto _done;
        }
        if (prism_rtl::is<Read::ParentRead>(read1)) {
            _v.set(Array<Read>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// ReachesSnap: fn [Text], [Read] -> Bool
bool reaches_snap(const Array<Text>& roots, const Array<Read>& reads) {
    return fold(reads, false, [&](const bool& f, const Read& r) {
        return f || ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            if (prism_rtl::is<Read::OwnRead>(r)) {
                auto&& n = prism_rtl::as<Read::OwnRead>(r).a0;
                _v.set(check_types::has_text(roots, n));
                goto _done;
            }
            if (prism_rtl::is<Read::ParentRead>(r)) {
                _v.set(false);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
}


/// SnapNames: fn Wx -> [Text]
Array<Text> snap_names(const Wx& wx) {
    return each(wx.snaps, [&](const SnapDef& sn) { return sn.name; });
}


/// WakeConst: fn [Nat], Nat -> Text
Text wake_const(const Array<Nat>& heights_, const Nat& h) {
    return len(heights_) <= Nat(1u) ? Text("WAKE") : prism_rtl::cat("WAKE_", h);
}


/// SelfCall: fn Text, [Ex] -> Do
Do self_call(const Text& m, const Array<Ex>& args) {
    return Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XSelf{})), m, prelude::push(args, Ex(Ex::XCx{}))})});
}


/// SinkCode: fn Sinks, Sk, Ex -> [Do]
Array<Do> sink_code(const Sinks& sk, const Sk& target, const Ex& y) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Array<Do>> _v;
        if (prism_rtl::is<Sk::SkNode>(target)) {
            auto&& m = prism_rtl::as<Sk::SkNode>(target).a0;
            _v.set(Array(std::vector{self_call(gn_of(sk.wx, m).name, Array(std::vector{y}))}));
            goto _done;
        }
        if (prism_rtl::is<Sk::SkIn>(target)) {
            auto&& m = prism_rtl::as<Sk::SkIn>(target).a0;
            auto&& i = prism_rtl::as<Sk::SkIn>(target).a1;
            _v.set(({
                auto g = gn_of(sk.wx, m);
                append(Array(std::vector{Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(or_(index(g.inputs, i), Text("")))})), Text("set"), Array(std::vector{y, Ex(Ex::XCx{})})})})}), ask_wake(sk, g.height));
            }));
            goto _done;
        }
        if (prism_rtl::is<Sk::SkHold>(target)) {
            auto&& f = prism_rtl::as<Sk::SkHold>(target).a0;
            _v.set(append(Array(std::vector{Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(f)})), Text("set"), Array(std::vector{y, Ex(Ex::XCx{})})})})}), hold_written(sk, f)));
            goto _done;
        }
        if (prism_rtl::is<Sk::SkRequest>(target)) {
            auto&& pos = prism_rtl::as<Sk::SkRequest>(target).a0;
            auto&& field = prism_rtl::as<Sk::SkRequest>(target).a1;
            _v.set(({
                auto field_ex = field == Text("")
                    ? Ex(Ex::XNone{})
                    : Ex(Ex::XCtor{Text("Some"), Array(std::vector{Ex(Ex::XStr{field})})});
                emits(sk.wx, pos)
                ? Array(std::vector{Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XCx{})), Text("request"), Array(std::vector{place_at(sk.wx, Text("self"), pos), field_ex, Ex(Ex::XMethod{prism_rtl::rc(y), Text("to_pod"), Array<Ex>{}})})})})})
                : Array(std::vector{Do(Do::DoLet{Pa(Pa::PaBind{Text("requested")}), Ex(Ex::XMethod{prism_rtl::rc(host_field_ex(sk.wx, pos)), Text("request"), Array(std::vector{Ex(Ex::XRef{prism_rtl::rc(place_at(sk.wx, Text("self"), pos))}), field_ex, Ex(Ex::XMethod{prism_rtl::rc(y), Text("to_pod"), Array<Ex>{}}), Ex(Ex::XCx{})})})}), Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XCx{})), Text("keep"), Array(std::vector{Ex(Ex::XVar{Text("requested")})})})})});
            }));
            goto _done;
        }
        if (prism_rtl::is<Sk::SkResult>(target)) {
            _v.set(Array(std::vector{Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XCx{})), Text("result"), Array(std::vector{Ex(Ex::XCtor{Text("Outcome::Fired"), Array(std::vector{Ex(Ex::XMethod{prism_rtl::rc(y), Text("to_pod"), Array<Ex>{}})})})})})})}));
            goto _done;
        }
        if (prism_rtl::is<Sk::SkArm>(target)) {
            auto&& f = prism_rtl::as<Sk::SkArm>(target).a0;
            _v.set(Array(std::vector{Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(f)})), Text("arm"), Array(std::vector{y, Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XSelf{}))}), Ex(Ex::XCx{})})})})}));
            goto _done;
        }
        if (prism_rtl::is<Sk::SkMachine>(target)) {
            auto&& f = prism_rtl::as<Sk::SkMachine>(target).a0;
            auto&& step_ = prism_rtl::as<Sk::SkMachine>(target).a1;
            auto&& out = prism_rtl::as<Sk::SkMachine>(target).a2;
            _v.set(({
                auto stepped = Ex(Ex::XCall{step_, Array(std::vector{Ex(Ex::XRef{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), f})), Text("get"), Array(std::vector{Ex(Ex::XCx{})})}))}), Ex(Ex::XRef{prism_rtl::rc(y)})})});
                append(Array(std::vector{Do(Do::DoLet{Pa(Pa::PaTuple{Array(std::vector{Pa(Pa::PaBind{Text("machine_s")}), Pa(Pa::PaBind{Text("machine_b")})})}), stepped}), Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(f)})), Text("set"), Array(std::vector{Ex(Ex::XVar{Text("machine_s")}), Ex(Ex::XCx{})})})}), Do(Do::DoIfLet{Pa(Pa::PaCtor{Text("Some"), Array(std::vector{Pa(Pa::PaBind{Text("machine_b")})})}), Ex(Ex::XVar{Text("machine_b")}), Array(std::vector{self_call(gn_of(sk.wx, out).name, Array(std::vector{Ex(Ex::XVar{Text("machine_b")})}))}), Array<Do>{}})}), moved_marks(sk, f));
            }));
            goto _done;
        }
        if (prism_rtl::is<Sk::SkPort>(target)) {
            auto&& f = prism_rtl::as<Sk::SkPort>(target).a0;
            _v.set(Array(std::vector{Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(f, "_port")})), Text("fire"), Array(std::vector{y, Ex(Ex::XCx{})})})), Text("ok"), Array<Ex>{}})})}));
            goto _done;
        }
        if (prism_rtl::is<Sk::SkUp>(target)) {
            auto&& m = prism_rtl::as<Sk::SkUp>(target).a0;
            _v.set(({
                auto keyed = len(filter(sk.wx.fields, [&](const std::tuple<Text, OutTy, Text>& _p0) {
                    auto&& f = std::get<0>(_p0);
                    return f == Text("key");
                })) > Nat(0u);
                auto args = keyed
                    ? Array(std::vector{Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), Text("key")}))}), y, Ex(Ex::XCx{})})
                    : Array(std::vector{y, Ex(Ex::XCx{})});
                (Array(std::vector{Do(Do::DoIfLet{Pa(Pa::PaCtor{Text("Some"), Array(std::vector{Pa(Pa::PaBind{Text("parent")})})}), Ex(Ex::XUpgrade{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), Text("parent")}))}), Array(std::vector{Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text("parent")})), m, args})})}), Array<Do>{}})}));
            }));
            goto _done;
        }
        if (prism_rtl::is<Sk::SkCycle>(target)) {
            auto&& job = prism_rtl::as<Sk::SkCycle>(target).a0;
            auto&& again = prism_rtl::as<Sk::SkCycle>(target).a1;
            auto&& res = prism_rtl::as<Sk::SkCycle>(target).a2;
            _v.set(({
                auto more = Array(std::vector{Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(job)})), Text("set"), Array(std::vector{Ex(Ex::XVar{Text("next")}), Ex(Ex::XCx{})})})}), Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(again)})), Text("arm"), Array(std::vector{Ex(Ex::XUnit{}), Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XSelf{}))}), Ex(Ex::XCx{})})})})});
                auto fin = Array(std::vector{self_call(gn_of(sk.wx, res).name, Array(std::vector{Ex(Ex::XVar{Text("b")})}))});
                (Array(std::vector{Do(Do::DoMatch{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(job)})), Text("get"), Array(std::vector{Ex(Ex::XCx{})})})), Text("cycle"), Array<Ex>{}}), Array(std::vector{std::tuple{Pa(Pa::PaCtor{Text("prism_rtl::Turn::More"), Array(std::vector{Pa(Pa::PaBind{Text("next")})})}), more}, std::tuple{Pa(Pa::PaCtor{Text("prism_rtl::Turn::Finished"), Array(std::vector{Pa(Pa::PaBind{Text("b")})})}), fin}})})}));
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// HoldWritten: fn Sinks, Text -> [Do]
Array<Do> hold_written(const Sinks& sk, const Text& f) {
    auto r = Read(Read::OwnRead{f});
    auto read_by_place = has_read(sk.dirty, r);
    auto [dirty, told] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Array<Do>, Array<Do>>> _v;
        auto&& _m = sk.wx.hosted_by;
        if (prism_rtl::is_some(_m)) {
            _v.set(std::tuple{Array<Do>{}, read_by_place
                ? Array(std::vector{Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XSelf{})), Text("document_moved"), Array(std::vector{Ex(Ex::XCx{})})})})})
                : Array<Do>{}});
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(std::tuple{read_by_place
                ? Array(std::vector{Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XCx{})), Text("dirty"), Array(std::vector{Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XSelf{}))})})})})})
                : Array<Do>{}, Array<Do>{}});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto stales = fold(sk.wx.gen_holds, Array<Do>{}, [&](const Array<Do>& acc, const std::tuple<Text, Array<Read>>& _p1) {
        auto&& gname = std::get<0>(_p1);
        auto&& hs = std::get<1>(_p1);
        return has_read(reads_closed(sk.wx.dyn_reads, hs), r)
            ? prelude::push(acc, Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(gname, "_stale")})), Text("set"), Array(std::vector{Ex(Ex::XBool{true})})})}))
            : acc;
    });
    auto row_marks = fold(sk.wx.row_marks, Array<Do>{}, [&](const Array<Do>& acc, const RowMarks& rm) { return append(acc, row_written(sk.wx, rm, r)); });
    auto builds = has_read(sk.builds, r) || (len(stales) > Nat(0u));
    auto rebuild_it = builds && (!lists_build(sk, r))
        ? append(stales, Array(std::vector{Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XCx{})), Text("build_later"), Array(std::vector{Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XSelf{}))})})})})}))
        : stales;
    auto gathered = ({
        __label__ _done;
        prism_rtl::Slot<Array<Do>> _v;
        auto&& _m = sk.wx.result_moved;
        if (prism_rtl::is_some(_m)) {
            auto&& m = std::get<0>(prism_rtl::some_of(_m));
            auto&& rds = std::get<1>(prism_rtl::some_of(_m));
            _v.set(has_read(rds, r)
                ? Array(std::vector{Do(Do::DoIfLet{Pa(Pa::PaCtor{Text("Some"), Array(std::vector{Pa(Pa::PaBind{Text("parent")})})}), Ex(Ex::XUpgrade{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), Text("parent")}))}), Array(std::vector{Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text("parent")})), m, Array(std::vector{Ex(Ex::XCx{})})})})}), Array<Do>{}})})
                : Array<Do>{});
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Array<Do>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return append(append(append(append(append(dirty, told), rebuild_it), row_marks), gathered), moved_marks(sk, f));
}


/// HostFieldEx: fn Wx, Pos -> Ex
Ex host_field_ex(const Wx& wx, const Pos_& pos) {
    return Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), host_local(wx, pos)});
}


/// MovedMarks: fn Sinks, Text -> [Do]
Array<Do> moved_marks(const Sinks& sk, const Text& f) {
    return moved_by(sk, Read(Read::OwnRead{f}));
}


/// MovedBy: fn Sinks, Read -> [Do]
Array<Do> moved_by(const Sinks& sk, const Read& r) {
    auto moved = filter(sk.wx.gns, [&](const Gn& g) { return moves(r, g); });
    auto flags = each(moved, [&](const Gn& g) { return Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(g.name, "_moved")})), Text("set"), Array(std::vector{Ex(Ex::XBool{true})})})}); });
    auto heights_ = sort_nats(fold(moved, Array<Nat>{}, [&](const Array<Nat>& acc, const Gn& g) { return check_types::add_nat(acc, g.height); }));
    auto marks = each(snaps_behind(sk.wx, r), [&](const SnapDef& sn) { return Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(sn.name, "_snap")})), Text("mark"), Array(std::vector{Ex(Ex::XCx{})})})}); });
    auto listed = lists_build(sk, r)
        ? Array(std::vector{Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XCx{})), Text("build_later"), Array(std::vector{Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XSelf{}))})})})})})
        : Array<Do>{};
    auto answers = each(filter(sk.wx.dyn_answers, [&](const std::tuple<Text, Array<Read>>& _p0) {
        auto&& rds = std::get<1>(_p0);
        return has_read(reads_closed(sk.wx.dyn_reads, rds), r);
    }), [&](const std::tuple<Text, Array<Read>>& _p0) {
        auto&& name = std::get<0>(_p0);
        return Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(name, "_port")})), Text("fire"), Array(std::vector{Ex(Ex::XUnit{}), Ex(Ex::XCx{})})})), Text("ok"), Array<Ex>{}})});
    });
    auto adoptions = each(filter(sk.wx.flattens, [&](const FlatDef& fl) { return r == Read(Read::OwnRead{fl.outer}); }), [&](const FlatDef& fl) { return Do(Do::DoScope{adoption(fl)}); });
    return append(append(append(append(append(fold(heights_, flags, [&](const Array<Do>& acc, const Nat& h) { return append(acc, ask_wake(sk, h)); }), marks), listed), answers), adoptions), source_marks(sk.wx, r));
}


/// SourceMarks: fn Wx, Read -> [Do]
Array<Do> source_marks(const Wx& wx, const Read& r) {
    return fold(wx.builders, Array<Do>{}, [&](const Array<Do>& acc, const ForDef& b) {
        return has_read(reads_closed(wx.dyn_reads, or_(prelude::get(wx.dyn_reads, b->source), Array<Read>{})), r)
            ? prelude::push(acc, Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(b->source, "_cache")})), Text("mark"), Array(std::vector{Ex(Ex::XCx{})})})}))
            : acc;
    });
}


/// SnapsBehind: fn Wx, Read -> [SnapDef]
Array<SnapDef> snaps_behind(const Wx& wx, const Read& r) {
    return filter(wx.snaps, [&](const SnapDef& sn) { return (r == Read(Read::OwnRead{sn.live})) || has_read(reads_closed(wx.dyn_reads, Array(std::vector{Read(Read::OwnRead{sn.live})})), r); });
}


/// ListsBuild: fn Sinks, Read -> Bool
bool lists_build(const Sinks& sk, const Read& r) {
    return len(snaps_behind(sk.wx, r)) > Nat(0u);
}


/// FiringCode: unbounded fn Sinks, Gn, Ex -> [Do]
Array<Do> firing_code(const Sinks& sk, const Gn& g, const Ex& x) {
    auto many = (len(g.outs) > Nat(1u)) && (!is_copy(g.ty));
    auto xv = many ? Ex(Ex::XClone{prism_rtl::rc(x)}) : x;
    return run_to_end(fold_job(g.outs, Array<Do>{}, ({
        auto xv_1 = xv;
        auto sk_2 = sk;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(std::tuple<Array<Do>, Out>)>>(prism_rtl::rc([=](std::tuple<Array<Do>, Out> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto xv_1_3 = xv_1;
            auto sk_2_3 = sk_2;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto o = p1;
                call_value(o.pipe(std::tuple{xv_1_3, ({
                auto sk_2_3_3 = sk_2_3;
                auto o_3 = o;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(Ex)>>(prism_rtl::rc([=](Ex p0) {
                return ({
                    auto sk_2_3_3_4 = sk_2_3_3;
                    auto o_3_4 = o_3;
                    once_job([=]() {
                    return ({
                        auto y = p0;
                        (prism_rtl::finished(sink_code(sk_2_3_3_4, o_3_4.sink, y)));
                    });
                });
                });
            })));
            })}), [=](Array<Do> call_275064) { return prism_rtl::finished(append(acc, call_275064)); });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<Array<Do>> FiringCode::cycle() const {
    const auto& sk = this->sk;
    const auto& g = this->g;
    const auto& x = this->x;
    auto many = (len(g.outs) > Nat(1u)) && (!is_copy(g.ty));
    auto xv = many ? Ex(Ex::XClone{prism_rtl::rc(x)}) : x;
    return fold_job(g.outs, Array<Do>{}, ({
        auto xv_1 = xv;
        auto sk_2 = sk;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(std::tuple<Array<Do>, Out>)>>(prism_rtl::rc([=](std::tuple<Array<Do>, Out> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto xv_1_3 = xv_1;
            auto sk_2_3 = sk_2;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto o = p1;
                call_value(o.pipe(std::tuple{xv_1_3, ({
                auto sk_2_3_3 = sk_2_3;
                auto o_3 = o;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(Ex)>>(prism_rtl::rc([=](Ex p0) {
                return ({
                    auto sk_2_3_3_4 = sk_2_3_3;
                    auto o_3_4 = o_3;
                    once_job([=]() {
                    return ({
                        auto y = p0;
                        (prism_rtl::finished(sink_code(sk_2_3_3_4, o_3_4.sink, y)));
                    });
                });
                });
            })));
            })}), [=](Array<Do> call_275064) { return prism_rtl::finished(append(acc, call_275064)); });
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start FiringCode, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Do>> start_firing_code(Sinks sk, Gn g, Ex x) {
    return std::make_shared<FiringCode>(sk, g, x);
}


/// FinishNode: unbounded fn Wx, Text, [((Text, OutTy))], Bool -> NodeDef
NodeDef finish_node(const Wx& wx0, const Text& qk, const Array<std::tuple<Text, OutTy>>& params, const bool& is_row) {
    auto closed_gns = each(wx0.gns, [&](const Gn& g) {
        return g.kind == GnKind(GnKind::GnUpdated{})
            ? with_reads(g, reads_closed(wx0.dyn_reads, g.reads))
            : g;
    });
    auto [row_defs, gns2] = finish_pending(wx0, heights(closed_gns));
    auto is_gen = is_row && (len(filter(wx0.fields, [&](const std::tuple<Text, OutTy, Text>& _p0) {
        auto&& f = std::get<0>(_p0);
        return f == Text("key");
    })) == Nat(0u));
    auto wx = ({
        Wx this_ = wx0;
        this_.gns = heights(gns2);
        this_.build = append(this_.build, updated_gaps(wx0, closed_gns, is_gen));
        this_.rows = fold(row_defs, this_.rows, [&](const Array<NodeDef>& acc, const NodeDef& rd) { return append(prelude::push(acc, rd), rd.children); });
        this_;
    });
    auto combs = filter(wx.gns, [&](const Gn& g) { return is_comb(g.kind) || (g.kind == GnKind(GnKind::GnGather{})); });
    auto heights_ = sort_nats(fold(combs, Array<Nat>{}, [&](const Array<Nat>& acc, const Gn& g) { return check_types::add_nat(acc, g.height); }));
    auto many = len(heights_) > Nat(1u);
    auto consts = each(heights_, [&](const Nat& h) { return std::tuple{wake_const(heights_, h), h, Text("merges' height above the node's inputs")}; });
    auto live = filter(wx.places, [&](const Place& p_) { return p_.getter != Text(""); });
    auto root_reads = ({
        __label__ _done;
        prism_rtl::Slot<Array<Read>> _v;
        auto&& _m = wx.root_dyn;
        if (prism_rtl::is_some(_m)) {
            auto&& rds = std::get<1>(prism_rtl::some_of(_m));
            _v.set(reads_closed(wx.dyn_reads, rds));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Array<Read>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto dirty_holds = fold(live, root_reads, [&](const Array<Read>& acc, const Place& p_) { return union_reads(acc, reads_closed(wx.dyn_reads, p_.reads)); });
    auto build_holds = reads_closed(wx.dyn_reads, wx.build_holds);
    auto sinks = Sinks{.wx = wx, .dirty = dirty_holds, .builds = build_holds, .heights = heights_, .many = many};
    auto ev_methods = run_to_end(each_job(filter(wx.gns, [&](const Gn& g) { return g.kind != GnKind(GnKind::GnNever{}); }), ({
        auto sinks_1 = sinks;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<MethDef>(Gn)>>(prism_rtl::rc([=](Gn p0) {
        return ({
            auto sinks_1_2 = sinks_1;
            entered(once_job([=]() {
            return ({
                auto g = p0;
                call_then(start_firing_code(sinks_1_2, g, Ex(Ex::XVar{Text("v")})), [=](Array<Do> firing_code_276856) { return prism_rtl::finished(MethDef{.name = g.name, .recv = Recv(Recv::RecvRc{}), .params = Array(std::vector{std::tuple{Text("v"), g.ty}}), .cx_ = CxArg(CxArg::CxMut{}), .ret = OutTy(OutTy::OutUnit{}), .body = firing_code_276856, .tail = Ex(Ex::XUnit{}), .doc = gn_doc(g)}); });
            });
        }));
        });
    })));
    })));
    auto gather_ins = each(filter(wx.gns, [&](const Gn& g) { return g.kind == GnKind(GnKind::GnGather{}); }), [&](const Gn& g) { return gather_in(sinks, g); });
    auto place_getters = each(live, [&](const Place& p_) { return MethDef{.name = p_.getter, .recv = Recv(Recv::RecvRef{}), .params = Array<std::tuple<Text, OutTy>>{}, .cx_ = CxArg(CxArg::CxRef{}), .ret = elem_ty(), .body = Array<Do>{}, .tail = p_.level, .doc = prism_rtl::cat("Place ", place_text(p_.pos), "'s level, read at the read point.")}; });
    auto wake_body = many
        ? Array(std::vector{wake_by_height(combs, heights_)})
        : each(combs, [&](const Gn& g) { return decide(g); });
    auto started_body = each(wx->started, [&](const Nat& st) { return self_call(gn_of(wx, st).name, Array(std::vector{Ex(Ex::XUnit{})})); });
    auto deferred_body = each(wx.defers, [&](const std::tuple<Text, Nat>& _p0) {
        auto&& f = std::get<0>(_p0);
        auto&& id = std::get<1>(_p0);
        return Do(Do::DoIfLet{Pa(Pa::PaCtor{Text("Some"), Array(std::vector{Pa(Pa::PaBind{Text("v")})})}), Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(f)})), Text("fired"), Array(std::vector{Ex(Ex::XCx{})})}), Array(std::vector{self_call(gn_of(wx, id).name, Array(std::vector{Ex(Ex::XVar{Text("v")})}))}), Array<Do>{}});
    });
    auto patch_body0 = fold(filter(live, [&](const Place& p_) { return emits(wx, p_.pos); }), Array<Do>{}, [&](const Array<Do>& acc, const Place& p_) { return append(acc, patch_place(wx, p_)); });
    auto patch_body = append(patch_body0, root_dyn_patch(wx));
    auto build_body = build_steps(sinks, false);
    auto push_body = each(filter(wx.dyn_places, [&](const std::tuple<Pos_, Text, OutTy, Text>& _p0) {
        auto&& pos = std::get<0>(_p0);
        return emits(wx, pos);
    }), [&](const std::tuple<Pos_, Text, OutTy, Text>& _p0) {
        auto&& pos = std::get<0>(_p0);
        auto&& f = std::get<1>(_p0);
        auto&& t = std::get<2>(_p0);
        return Do(Do::DoIf{Ex(Ex::XBin{Text("=="), prism_rtl::rc(Ex(Ex::XVar{Text("element")})), prism_rtl::rc(Ex(Ex::XRef{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(f, "_element")}))}))}), dyn_place_write(sinks, f, Ex(Ex::XDecode{t, prism_rtl::rc(Ex(Ex::XVar{Text("v")}))})), Array<Do>{}});
    });
    auto hooks = filter(Array(std::vector{std::tuple{Text("wake"), wake_body}, std::tuple{Text("started"), started_body}, std::tuple{Text("deferred"), deferred_body}, std::tuple{Text("build"), build_body}, std::tuple{Text("push"), push_body}, std::tuple{Text("patch"), patch_body}}), [&](const std::tuple<Text, Array<Do>>& _p0) {
        auto&& b = std::get<1>(_p0);
        return len(b) > Nat(0u);
    });
    auto started_reg = len(wx->started) > Nat(0u)
        ? Array(std::vector{Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XCx{})), Text("on_started"), Array(std::vector{Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{Text("node")}))})})})})})
        : Array<Do>{};
    auto links = each(wx.hosts, [&](const HostDef& h) { return Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XVar{Text("node")})), prism_rtl::cat(h.name)})), Text("link"), Array(std::vector{Ex(Ex::XRef{prism_rtl::rc(Ex(Ex::XVar{Text("node")}))})})})}); });
    auto rows_built = append(links, build_steps(sinks, true));
    auto subscribed = each(wx.subs, [&](const std::tuple<Text, Text, OutTy>& _p0) {
        auto&& ev = std::get<0>(_p0);
        auto&& m = std::get<1>(_p0);
        auto&& t = std::get<2>(_p0);
        return Do(Do::DoExpr{Ex(Ex::XCall{Text("subscribe_row"), Array(std::vector{Ex(Ex::XRef{prism_rtl::rc(Ex(Ex::XVar{Text("node")}))}), Ex(Ex::XUpgrade{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XVar{Text("node")})), Text("parent")}))}), Ex(Ex::XClosure{false, Array(std::vector{Pa(Pa::PaBind{Text("p")})}), prism_rtl::rc(Ex(Ex::XRef{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XVar{Text("p")})), prism_rtl::cat(ev, "_port")}))}))}), Ex(Ex::XClosure{false, Array(std::vector{Pa(Pa::PaBind{Text("n")}), Pa(Pa::PaBind{Text("v")}), Pa(Pa::PaBind{Text("cx")})}), prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text("n")})), m, Array(std::vector{Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{Text("v")}))}), Ex(Ex::XCx{})})}))}), Ex(Ex::XRef{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XVar{Text("node")})), prism_rtl::cat(m, "_sub")}))})})})});
    });
    auto answers = append(each(filter(wx.answers, [&](const std::tuple<Pos_, Nat, OutTy, Text>& _p0) {
        auto&& pos = std::get<0>(_p0);
        return emits(wx, pos);
    }), [&](const std::tuple<Pos_, Nat, OutTy, Text>& _p0) {
        auto&& pos = std::get<0>(_p0);
        auto&& id = std::get<1>(_p0);
        auto&& t = std::get<2>(_p0);
        return answer_arm(wx, pos, id, t);
    }), each(filter(wx.dyn_places, [&](const std::tuple<Pos_, Text, OutTy, Text>& _p0) {
        auto&& pos = std::get<0>(_p0);
        return emits(wx, pos);
    }), [&](const std::tuple<Pos_, Text, OutTy, Text>& _p0) {
        auto&& pos = std::get<0>(_p0);
        auto&& f = std::get<1>(_p0);
        auto&& t = std::get<2>(_p0);
        return dyn_answer_arm(sinks, pos, f, t);
    }));
    auto forwards = append(each(filter(wx.builders, [&](const ForDef& b) { return emits(wx, b.pos); }), [&](const ForDef& b) { return std::tuple{pos_pat(b.pos, key_tail()), forward_answer(b)}; }), fold(filter(wx.gens, [&](const GenDef& gd) { return emits(wx, gd.pos); }), Array<std::tuple<Pa, Ex>>{}, [&](const Array<std::tuple<Pa, Ex>>& acc, const GenDef& gd) { return append(acc, gen_forwards(gd)); }));
    auto host_methods = fold(wx.hosts, Array<MethDef>{}, [&](const Array<MethDef>& acc, const HostDef& h) { return append(acc, Array(std::vector{typed_dispatch(sinks, prism_rtl::cat(h.name, "_answer"), h.scope), host_moved(sinks, h)})); });
    auto gathered = filter(wx.snaps, [&](const SnapDef& sn) { return !(sn.before || is_generation(wx, sn.builder)); });
    auto gathered_moved_ = append(append(each(gathered, [&](const SnapDef& sn) { return gathered_moved(sn); }), each(wx.snaps, [&](const SnapDef& sn) { return snap_publish(sinks, sn); })), flatten_methods(sinks));
    auto hosted_methods = ({
        __label__ _done;
        prism_rtl::Slot<Array<MethDef>> _v;
        auto&& _m = wx.hosted_by;
        if (prism_rtl::is_some(_m)) {
            _v.set(Array(std::vector{typed_dispatch(sinks, Text("deliver"), Nat(0u)), document_getter(wx)}));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Array<MethDef>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto moved_method = ({
        __label__ _done;
        prism_rtl::Slot<Array<MethDef>> _v;
        auto&& _m = wx.hosted_by;
        if (prism_rtl::is_some(_m)) {
            auto&& m = prism_rtl::some_of(_m);
            _v.set(Array(std::vector{lower::document_moved(m)}));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Array<MethDef>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto row_methods_ = is_row ? row_methods(wx) : Array<MethDef>{};
    auto heard = each(row_hears(wx), [&](const Text& m) { return MethDef{.name = prism_rtl::cat("parent_wrote_", m), .recv = Recv(Recv::RecvRc{}), .params = Array<std::tuple<Text, OutTy>>{}, .cx_ = CxArg(CxArg::CxMut{}), .ret = OutTy(OutTy::OutUnit{}), .body = append(moved_by(sinks, Read(Read::ParentRead{m})), fold(wx.row_marks, Array<Do>{}, [&](const Array<Do>& acc, const RowMarks& rm) { return append(acc, row_written(wx, rm, Read(Read::ParentRead{m}))); })), .tail = Ex(Ex::XUnit{}), .doc = prism_rtl::cat("The block wrote behind its `", m, "`, which this row reads through the parent: the `!Updated` nodes over it are told and the wake asked at their heights; the rows of this row's own `for`s that read it are marked.")}; });
    auto top = fold(wx.gns, Nat(0u), [&](const Nat& hi, const Gn& g) { return prelude::max(hi, g.height); });
    auto wakes_field = many
        ? Array(std::vector{std::tuple{Text("wakes"), OutTy(OutTy::OutWakes{}), Text("the heights asked for this tick, lowest first")}})
        : Array<std::tuple<Text, OutTy, Text>>{};
    auto wakes_init = many
        ? Array(std::vector{std::tuple{Text("wakes"), Ex(Ex::XCall{Text("Wakes::default"), Array<Ex>{}})}})
        : Array<std::tuple<Text, Ex>>{};
    auto gen_fields = fold(wx.gens, Array<std::tuple<Text, OutTy, Text>>{}, [&](const Array<std::tuple<Text, OutTy, Text>>& acc, const GenDef& gd) { return append(acc, Array(std::vector{std::tuple{gd.name, OutTy(OutTy::OutCell{prism_rtl::rc(OutTy(OutTy::OutOpt{prism_rtl::rc(OutTy(OutTy::OutObj{prism_rtl::rc(OutTy(OutTy::OutNamed{Text("Row"), Array<OutTy>{}}))}))}))}), prism_rtl::cat("the current generation of the `rebuild` at place ", place_text(gd.pos))}, std::tuple{prism_rtl::cat(gd.name, "_count"), OutTy(OutTy::OutNamed{Text("Cell"), Array(std::vector{OutTy(OutTy::OutCount{})})}), Text("how many generations it has built")}, std::tuple{prism_rtl::cat(gd.name, "_stale"), OutTy(OutTy::OutNamed{Text("Cell"), Array(std::vector{OutTy(OutTy::OutBool{})})}), Text("its source changed since it was built")}})); });
    auto gen_inits = fold(wx.gens, Array<std::tuple<Text, Ex>>{}, [&](const Array<std::tuple<Text, Ex>>& acc, const GenDef& gd) { return append(acc, Array(std::vector{std::tuple{gd.name, Ex(Ex::XCall{Text("RefCell::new"), Array(std::vector{Ex(Ex::XNone{})})})}, std::tuple{prism_rtl::cat(gd.name, "_count"), Ex(Ex::XCall{Text("Cell::new"), Array(std::vector{Ex(Ex::XIndex{Nat(0u)})})})}, std::tuple{prism_rtl::cat(gd.name, "_stale"), Ex(Ex::XCall{Text("Cell::new"), Array(std::vector{Ex(Ex::XBool{false})})})}})); });
    auto port_fields = each(wx.ports, [&](const Text& pn) { return std::tuple{prism_rtl::cat(pn, "_port"), OutTy(OutTy::OutPort{prism_rtl::rc(gn_ty_named(wx, pn))}), prism_rtl::cat("`!", pn, "`, which rows subscribe to")}; });
    auto port_inits = each(wx.ports, [&](const Text& pn) { return std::tuple{prism_rtl::cat(pn, "_port"), Ex(Ex::XCall{Text("Port::new"), Array<Ex>{}})}; });
    auto sub_fields = each(wx.subs, [&](const std::tuple<Text, Text, OutTy>& _p0) {
        auto&& ev = std::get<0>(_p0);
        auto&& m = std::get<1>(_p0);
        auto&& t = std::get<2>(_p0);
        return std::tuple{prism_rtl::cat(m, "_sub"), OutTy(OutTy::OutNamed{Text("Cell"), Array(std::vector{OutTy(OutTy::OutOpt{prism_rtl::rc(OutTy(OutTy::OutNamed{Text("Handle"), Array<OutTy>{}}))})})}), prism_rtl::cat("the subscription to the parent's `!", ev, "`")};
    });
    auto sub_inits = each(wx.subs, [&](const std::tuple<Text, Text, OutTy>& _p0) {
        auto&& ev = std::get<0>(_p0);
        auto&& m = std::get<1>(_p0);
        auto&& t = std::get<2>(_p0);
        return std::tuple{prism_rtl::cat(m, "_sub"), Ex(Ex::XCall{Text("Cell::new"), Array(std::vector{Ex(Ex::XNone{})})})};
    });
    auto fallible = ((wx.fallible || is_row) || (len(wx.builders) > Nat(0u))) || (len(wx.gens) > Nat(0u));
    return NodeDef{.name = wx.node_, .prism = check_types::bare_name(qk), .doc = definition_text(wx.lx, qk), .params = params, .fields = append(append(append(append(wx.fields, wakes_field), gen_fields), port_fields), sub_fields), .consts = consts, .lets = wx.lets, .inits = append(wx.inits, append(append(append(append(wx.moves, wakes_init), gen_inits), port_inits), sub_inits)), .build = append(append(append(rows_built, wx->build), subscribed), started_reg), .fallible = fallible, .methods = append(append(append(append(append(append(append(append(ev_methods, gather_ins), place_getters), wx.getters), row_methods_), heard), host_methods), gathered_moved_), moved_method), .answers = append(answers, forwards), .hooks = hooks, .builders = wx.builders, .wakes = many, .children = wx->rows, .gens = wx.gens, .subs = wx.subs, .top = top, .row_kind = is_row
        ? is_gen ? RowKind(RowKind::GenerationRow{}) : RowKind(RowKind::ForRow{})
        : RowKind(RowKind::NotARow{}), .hosted = hosted_methods};
}


prism_rtl::Turn<NodeDef> FinishNode::cycle() const {
    const auto& wx0 = this->wx0;
    const auto& qk = this->qk;
    const auto& params = this->params;
    const auto& is_row = this->is_row;
    auto closed_gns = each(wx0.gns, [&](const Gn& g) {
        return g.kind == GnKind(GnKind::GnUpdated{})
            ? with_reads(g, reads_closed(wx0.dyn_reads, g.reads))
            : g;
    });
    auto is_row_1 = is_row;
    auto params_2 = params;
    auto qk_3 = qk;
    auto wx0_4 = wx0;
    return call_then(start_finish_pending(wx0_4, heights(closed_gns)), [=](std::tuple<Array<NodeDef>, Array<Gn>> finish_pending_275621) {
        return ({
            auto [row_defs, gns2] = finish_pending_275621;
            auto is_gen = is_row_1 && (len(filter(wx0_4.fields, [&](const std::tuple<Text, OutTy, Text>& _p0) {
                auto&& f = std::get<0>(_p0);
                return f == Text("key");
            })) == Nat(0u));
            auto wx = ({
                Wx this_ = wx0_4;
                this_.gns = heights(gns2);
                this_.build = append(this_.build, updated_gaps(wx0_4, closed_gns, is_gen));
                this_.rows = fold(row_defs, this_.rows, [&](const Array<NodeDef>& acc, const NodeDef& rd) { return append(prelude::push(acc, rd), rd.children); });
                this_;
            });
            auto combs = filter(wx.gns, [&](const Gn& g) { return is_comb(g.kind) || (g.kind == GnKind(GnKind::GnGather{})); });
            auto heights_ = sort_nats(fold(combs, Array<Nat>{}, [&](const Array<Nat>& acc, const Gn& g) { return check_types::add_nat(acc, g.height); }));
            auto many = len(heights_) > Nat(1u);
            auto consts = each(heights_, [&](const Nat& h) { return std::tuple{wake_const(heights_, h), h, Text("merges' height above the node's inputs")}; });
            auto live = filter(wx.places, [&](const Place& p_) { return p_.getter != Text(""); });
            auto root_reads = ({
                __label__ _done;
                prism_rtl::Slot<Array<Read>> _v;
                auto&& _m = wx.root_dyn;
                if (prism_rtl::is_some(_m)) {
                    auto&& rds = std::get<1>(prism_rtl::some_of(_m));
                    _v.set(reads_closed(wx.dyn_reads, rds));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(Array<Read>{});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            auto dirty_holds = fold(live, root_reads, [&](const Array<Read>& acc, const Place& p_) { return union_reads(acc, reads_closed(wx.dyn_reads, p_.reads)); });
            auto build_holds = reads_closed(wx.dyn_reads, wx.build_holds);
            auto sinks = Sinks{.wx = wx, .dirty = dirty_holds, .builds = build_holds, .heights = heights_, .many = many};
            call_value(each_job(filter(wx.gns, [&](const Gn& g) { return g.kind != GnKind(GnKind::GnNever{}); }), ({
            auto sinks_5 = sinks;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<MethDef>(Gn)>>(prism_rtl::rc([=](Gn p0) {
            return ({
                auto sinks_5_6 = sinks_5;
                entered(once_job([=]() {
                return ({
                    auto g = p0;
                    call_then(start_firing_code(sinks_5_6, g, Ex(Ex::XVar{Text("v")})), [=](Array<Do> firing_code_276856) { return prism_rtl::finished(MethDef{.name = g.name, .recv = Recv(Recv::RecvRc{}), .params = Array(std::vector{std::tuple{Text("v"), g.ty}}), .cx_ = CxArg(CxArg::CxMut{}), .ret = OutTy(OutTy::OutUnit{}), .body = firing_code_276856, .tail = Ex(Ex::XUnit{}), .doc = gn_doc(g)}); });
                });
            }));
            });
        })));
        })), [=](Array<MethDef> each_276716) {
            return ({
                auto ev_methods = each_276716;
                auto gather_ins = each(filter(wx.gns, [&](const Gn& g) { return g.kind == GnKind(GnKind::GnGather{}); }), [&](const Gn& g) { return gather_in(sinks, g); });
                auto place_getters = each(live, [&](const Place& p_) { return MethDef{.name = p_.getter, .recv = Recv(Recv::RecvRef{}), .params = Array<std::tuple<Text, OutTy>>{}, .cx_ = CxArg(CxArg::CxRef{}), .ret = elem_ty(), .body = Array<Do>{}, .tail = p_.level, .doc = prism_rtl::cat("Place ", place_text(p_.pos), "'s level, read at the read point.")}; });
                auto wake_body = many
                    ? Array(std::vector{wake_by_height(combs, heights_)})
                    : each(combs, [&](const Gn& g) { return decide(g); });
                auto started_body = each(wx->started, [&](const Nat& st) { return self_call(gn_of(wx, st).name, Array(std::vector{Ex(Ex::XUnit{})})); });
                auto deferred_body = each(wx.defers, [&](const std::tuple<Text, Nat>& _p0) {
                    auto&& f = std::get<0>(_p0);
                    auto&& id = std::get<1>(_p0);
                    return Do(Do::DoIfLet{Pa(Pa::PaCtor{Text("Some"), Array(std::vector{Pa(Pa::PaBind{Text("v")})})}), Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(f)})), Text("fired"), Array(std::vector{Ex(Ex::XCx{})})}), Array(std::vector{self_call(gn_of(wx, id).name, Array(std::vector{Ex(Ex::XVar{Text("v")})}))}), Array<Do>{}});
                });
                auto patch_body0 = fold(filter(live, [&](const Place& p_) { return emits(wx, p_.pos); }), Array<Do>{}, [&](const Array<Do>& acc, const Place& p_) { return append(acc, patch_place(wx, p_)); });
                auto patch_body = append(patch_body0, root_dyn_patch(wx));
                auto build_body = build_steps(sinks, false);
                auto push_body = each(filter(wx.dyn_places, [&](const std::tuple<Pos_, Text, OutTy, Text>& _p0) {
                    auto&& pos = std::get<0>(_p0);
                    return emits(wx, pos);
                }), [&](const std::tuple<Pos_, Text, OutTy, Text>& _p0) {
                    auto&& pos = std::get<0>(_p0);
                    auto&& f = std::get<1>(_p0);
                    auto&& t = std::get<2>(_p0);
                    return Do(Do::DoIf{Ex(Ex::XBin{Text("=="), prism_rtl::rc(Ex(Ex::XVar{Text("element")})), prism_rtl::rc(Ex(Ex::XRef{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(f, "_element")}))}))}), dyn_place_write(sinks, f, Ex(Ex::XDecode{t, prism_rtl::rc(Ex(Ex::XVar{Text("v")}))})), Array<Do>{}});
                });
                auto hooks = filter(Array(std::vector{std::tuple{Text("wake"), wake_body}, std::tuple{Text("started"), started_body}, std::tuple{Text("deferred"), deferred_body}, std::tuple{Text("build"), build_body}, std::tuple{Text("push"), push_body}, std::tuple{Text("patch"), patch_body}}), [&](const std::tuple<Text, Array<Do>>& _p0) {
                    auto&& b = std::get<1>(_p0);
                    return len(b) > Nat(0u);
                });
                auto started_reg = len(wx->started) > Nat(0u)
                    ? Array(std::vector{Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XCx{})), Text("on_started"), Array(std::vector{Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{Text("node")}))})})})})})
                    : Array<Do>{};
                auto links = each(wx.hosts, [&](const HostDef& h) { return Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XVar{Text("node")})), prism_rtl::cat(h.name)})), Text("link"), Array(std::vector{Ex(Ex::XRef{prism_rtl::rc(Ex(Ex::XVar{Text("node")}))})})})}); });
                auto rows_built = append(links, build_steps(sinks, true));
                auto subscribed = each(wx.subs, [&](const std::tuple<Text, Text, OutTy>& _p0) {
                    auto&& ev = std::get<0>(_p0);
                    auto&& m = std::get<1>(_p0);
                    auto&& t = std::get<2>(_p0);
                    return Do(Do::DoExpr{Ex(Ex::XCall{Text("subscribe_row"), Array(std::vector{Ex(Ex::XRef{prism_rtl::rc(Ex(Ex::XVar{Text("node")}))}), Ex(Ex::XUpgrade{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XVar{Text("node")})), Text("parent")}))}), Ex(Ex::XClosure{false, Array(std::vector{Pa(Pa::PaBind{Text("p")})}), prism_rtl::rc(Ex(Ex::XRef{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XVar{Text("p")})), prism_rtl::cat(ev, "_port")}))}))}), Ex(Ex::XClosure{false, Array(std::vector{Pa(Pa::PaBind{Text("n")}), Pa(Pa::PaBind{Text("v")}), Pa(Pa::PaBind{Text("cx")})}), prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text("n")})), m, Array(std::vector{Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{Text("v")}))}), Ex(Ex::XCx{})})}))}), Ex(Ex::XRef{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XVar{Text("node")})), prism_rtl::cat(m, "_sub")}))})})})});
                });
                auto answers = append(each(filter(wx.answers, [&](const std::tuple<Pos_, Nat, OutTy, Text>& _p0) {
                    auto&& pos = std::get<0>(_p0);
                    return emits(wx, pos);
                }), [&](const std::tuple<Pos_, Nat, OutTy, Text>& _p0) {
                    auto&& pos = std::get<0>(_p0);
                    auto&& id = std::get<1>(_p0);
                    auto&& t = std::get<2>(_p0);
                    return answer_arm(wx, pos, id, t);
                }), each(filter(wx.dyn_places, [&](const std::tuple<Pos_, Text, OutTy, Text>& _p0) {
                    auto&& pos = std::get<0>(_p0);
                    return emits(wx, pos);
                }), [&](const std::tuple<Pos_, Text, OutTy, Text>& _p0) {
                    auto&& pos = std::get<0>(_p0);
                    auto&& f = std::get<1>(_p0);
                    auto&& t = std::get<2>(_p0);
                    return dyn_answer_arm(sinks, pos, f, t);
                }));
                auto forwards = append(each(filter(wx.builders, [&](const ForDef& b) { return emits(wx, b.pos); }), [&](const ForDef& b) { return std::tuple{pos_pat(b.pos, key_tail()), forward_answer(b)}; }), fold(filter(wx.gens, [&](const GenDef& gd) { return emits(wx, gd.pos); }), Array<std::tuple<Pa, Ex>>{}, [&](const Array<std::tuple<Pa, Ex>>& acc, const GenDef& gd) { return append(acc, gen_forwards(gd)); }));
                auto host_methods = fold(wx.hosts, Array<MethDef>{}, [&](const Array<MethDef>& acc, const HostDef& h) { return append(acc, Array(std::vector{typed_dispatch(sinks, prism_rtl::cat(h.name, "_answer"), h.scope), host_moved(sinks, h)})); });
                auto gathered = filter(wx.snaps, [&](const SnapDef& sn) { return !(sn.before || is_generation(wx, sn.builder)); });
                auto gathered_moved_ = append(append(each(gathered, [&](const SnapDef& sn) { return gathered_moved(sn); }), each(wx.snaps, [&](const SnapDef& sn) { return snap_publish(sinks, sn); })), flatten_methods(sinks));
                auto hosted_methods = ({
                    __label__ _done;
                    prism_rtl::Slot<Array<MethDef>> _v;
                    auto&& _m = wx.hosted_by;
                    if (prism_rtl::is_some(_m)) {
                        _v.set(Array(std::vector{typed_dispatch(sinks, Text("deliver"), Nat(0u)), document_getter(wx)}));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(Array<MethDef>{});
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                auto moved_method = ({
                    __label__ _done;
                    prism_rtl::Slot<Array<MethDef>> _v;
                    auto&& _m = wx.hosted_by;
                    if (prism_rtl::is_some(_m)) {
                        auto&& m = prism_rtl::some_of(_m);
                        _v.set(Array(std::vector{lower::document_moved(m)}));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(Array<MethDef>{});
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                auto row_methods_ = is_row_1 ? row_methods(wx) : Array<MethDef>{};
                auto heard = each(row_hears(wx), [&](const Text& m) { return MethDef{.name = prism_rtl::cat("parent_wrote_", m), .recv = Recv(Recv::RecvRc{}), .params = Array<std::tuple<Text, OutTy>>{}, .cx_ = CxArg(CxArg::CxMut{}), .ret = OutTy(OutTy::OutUnit{}), .body = append(moved_by(sinks, Read(Read::ParentRead{m})), fold(wx.row_marks, Array<Do>{}, [&](const Array<Do>& acc, const RowMarks& rm) { return append(acc, row_written(wx, rm, Read(Read::ParentRead{m}))); })), .tail = Ex(Ex::XUnit{}), .doc = prism_rtl::cat("The block wrote behind its `", m, "`, which this row reads through the parent: the `!Updated` nodes over it are told and the wake asked at their heights; the rows of this row's own `for`s that read it are marked.")}; });
                auto top = fold(wx.gns, Nat(0u), [&](const Nat& hi, const Gn& g) { return prelude::max(hi, g.height); });
                auto wakes_field = many
                    ? Array(std::vector{std::tuple{Text("wakes"), OutTy(OutTy::OutWakes{}), Text("the heights asked for this tick, lowest first")}})
                    : Array<std::tuple<Text, OutTy, Text>>{};
                auto wakes_init = many
                    ? Array(std::vector{std::tuple{Text("wakes"), Ex(Ex::XCall{Text("Wakes::default"), Array<Ex>{}})}})
                    : Array<std::tuple<Text, Ex>>{};
                auto gen_fields = fold(wx.gens, Array<std::tuple<Text, OutTy, Text>>{}, [&](const Array<std::tuple<Text, OutTy, Text>>& acc, const GenDef& gd) { return append(acc, Array(std::vector{std::tuple{gd.name, OutTy(OutTy::OutCell{prism_rtl::rc(OutTy(OutTy::OutOpt{prism_rtl::rc(OutTy(OutTy::OutObj{prism_rtl::rc(OutTy(OutTy::OutNamed{Text("Row"), Array<OutTy>{}}))}))}))}), prism_rtl::cat("the current generation of the `rebuild` at place ", place_text(gd.pos))}, std::tuple{prism_rtl::cat(gd.name, "_count"), OutTy(OutTy::OutNamed{Text("Cell"), Array(std::vector{OutTy(OutTy::OutCount{})})}), Text("how many generations it has built")}, std::tuple{prism_rtl::cat(gd.name, "_stale"), OutTy(OutTy::OutNamed{Text("Cell"), Array(std::vector{OutTy(OutTy::OutBool{})})}), Text("its source changed since it was built")}})); });
                auto gen_inits = fold(wx.gens, Array<std::tuple<Text, Ex>>{}, [&](const Array<std::tuple<Text, Ex>>& acc, const GenDef& gd) { return append(acc, Array(std::vector{std::tuple{gd.name, Ex(Ex::XCall{Text("RefCell::new"), Array(std::vector{Ex(Ex::XNone{})})})}, std::tuple{prism_rtl::cat(gd.name, "_count"), Ex(Ex::XCall{Text("Cell::new"), Array(std::vector{Ex(Ex::XIndex{Nat(0u)})})})}, std::tuple{prism_rtl::cat(gd.name, "_stale"), Ex(Ex::XCall{Text("Cell::new"), Array(std::vector{Ex(Ex::XBool{false})})})}})); });
                auto port_fields = each(wx.ports, [&](const Text& pn) { return std::tuple{prism_rtl::cat(pn, "_port"), OutTy(OutTy::OutPort{prism_rtl::rc(gn_ty_named(wx, pn))}), prism_rtl::cat("`!", pn, "`, which rows subscribe to")}; });
                auto port_inits = each(wx.ports, [&](const Text& pn) { return std::tuple{prism_rtl::cat(pn, "_port"), Ex(Ex::XCall{Text("Port::new"), Array<Ex>{}})}; });
                auto sub_fields = each(wx.subs, [&](const std::tuple<Text, Text, OutTy>& _p0) {
                    auto&& ev = std::get<0>(_p0);
                    auto&& m = std::get<1>(_p0);
                    auto&& t = std::get<2>(_p0);
                    return std::tuple{prism_rtl::cat(m, "_sub"), OutTy(OutTy::OutNamed{Text("Cell"), Array(std::vector{OutTy(OutTy::OutOpt{prism_rtl::rc(OutTy(OutTy::OutNamed{Text("Handle"), Array<OutTy>{}}))})})}), prism_rtl::cat("the subscription to the parent's `!", ev, "`")};
                });
                auto sub_inits = each(wx.subs, [&](const std::tuple<Text, Text, OutTy>& _p0) {
                    auto&& ev = std::get<0>(_p0);
                    auto&& m = std::get<1>(_p0);
                    auto&& t = std::get<2>(_p0);
                    return std::tuple{prism_rtl::cat(m, "_sub"), Ex(Ex::XCall{Text("Cell::new"), Array(std::vector{Ex(Ex::XNone{})})})};
                });
                auto fallible = ((wx.fallible || is_row_1) || (len(wx.builders) > Nat(0u))) || (len(wx.gens) > Nat(0u));
                (prism_rtl::finished(NodeDef{.name = wx.node_, .prism = check_types::bare_name(qk_3), .doc = definition_text(wx.lx, qk_3), .params = params_2, .fields = append(append(append(append(wx.fields, wakes_field), gen_fields), port_fields), sub_fields), .consts = consts, .lets = wx.lets, .inits = append(wx.inits, append(append(append(append(wx.moves, wakes_init), gen_inits), port_inits), sub_inits)), .build = append(append(append(rows_built, wx->build), subscribed), started_reg), .fallible = fallible, .methods = append(append(append(append(append(append(append(append(ev_methods, gather_ins), place_getters), wx.getters), row_methods_), heard), host_methods), gathered_moved_), moved_method), .answers = append(answers, forwards), .hooks = hooks, .builders = wx.builders, .wakes = many, .children = wx->rows, .gens = wx.gens, .subs = wx.subs, .top = top, .row_kind = is_row_1
                ? is_gen ? RowKind(RowKind::GenerationRow{}) : RowKind(RowKind::ForRow{})
                : RowKind(RowKind::NotARow{}), .hosted = hosted_methods}));
            });
        });
        });
    });
}


/// `Start FinishNode, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<NodeDef> start_finish_node(Wx wx0, Text qk, Array<std::tuple<Text, OutTy>> params, bool is_row) {
    return std::make_shared<FinishNode>(wx0, qk, params, is_row);
}


/// IsGeneration: fn Wx, Text -> Bool
bool is_generation(const Wx& wx, const Text& name) {
    return len(filter(wx.gens, [&](const GenDef& gd) { return gd.name == name; })) > Nat(0u);
}


/// FlattenMethods: fn Sinks -> [MethDef]
Array<MethDef> flatten_methods(const Sinks& sk) {
    auto wx = sk.wx;
    auto adopts_1 = each(wx.flattens, [&](const FlatDef& fl) {
        return ({
            auto set_1 = Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(fl.name, "_inner")})), Text("set"), Array(std::vector{Ex(Ex::XCtor{Text("Some"), Array(std::vector{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XSelf{})), fl.outer, Array(std::vector{Ex(Ex::XCx{})})})})}), Ex(Ex::XCx{})})})});
            MethDef{.name = prism_rtl::cat(fl.name, "_adopt"), .recv = Recv(Recv::RecvRc{}), .params = Array<std::tuple<Text, OutTy>>{}, .cx_ = CxArg(CxArg::CxMut{}), .ret = OutTy(OutTy::OutUnit{}), .body = append(Array(std::vector{set_1}), hold_written(sk, prism_rtl::cat(fl.name, "_inner"))), .tail = Ex(Ex::XUnit{}), .doc = Text("`@Flatten` adopts the inner its `rebuild`'s dynamic held after the tick before, among this tick's first firings: from here on it reads that inner (Semantics ch. 7).")};
        });
    });
    auto dyn_gens = filter(wx.gens, [&](const GenDef& gd) { return len(filter(wx.snaps, [&](const SnapDef& sn) { return sn.builder == gd.name; })) > Nat(0u); });
    auto moved_2 = each(dyn_gens, [&](const GenDef& gd) {
        return ({
            auto marks = fold(filter(wx.flattens, [&](const FlatDef& fl) { return fl->generation == gd.name; }), Array<Do>{}, [&](const Array<Do>& acc, const FlatDef& fl) { return append(acc, hold_written(sk, prism_rtl::cat(fl.name, "_inner"))); });
            MethDef{.name = prism_rtl::cat(gd.name, "_result_moved"), .recv = Recv(Recv::RecvRc{}), .params = Array<std::tuple<Text, OutTy>>{}, .cx_ = CxArg(CxArg::CxMut{}), .ret = OutTy(OutTy::OutUnit{}), .body = marks, .tail = Ex(Ex::XUnit{}), .doc = Text("The current generation's result moved: what reads a `@Flatten` over it reads it again.")};
        });
    });
    return append(adopts_1, moved_2);
}


/// HostMoved: fn Sinks, HostDef -> MethDef
MethDef host_moved(const Sinks& sk, const HostDef& h) {
    return MethDef{.name = prism_rtl::cat(h.name, "_moved"), .recv = Recv(Recv::RecvRc{}), .params = Array<std::tuple<Text, OutTy>>{}, .cx_ = CxArg(CxArg::CxMut{}), .ret = OutTy(OutTy::OutUnit{}), .body = hold_written(sk, prism_rtl::cat(h.name, "_doc_now")), .tail = Ex(Ex::XUnit{}), .doc = prism_rtl::cat("A node of the child hosted at place ", place_text(h.pos), " wrote behind its document: the structure is marked as for a write of a hold it reads (pick HO), the snapshot listed to be taken; the program's `$doc` moves when it is published, the tick after (pick ST).")};
}


/// BuildSteps: fn Sinks, Bool -> [Do]
Array<Do> build_steps(const Sinks& sk, const bool& at_build) {
    auto wx = sk.wx;
    auto recv = at_build ? Ex(Ex::XVar{Text("node")}) : Ex(Ex::XSelf{});
    auto take_fn = ({
        auto at_build_1 = at_build;
        auto sk_2 = sk;
        (prism_rtl::rc([=](const SnapDef& sn) { return at_build_1 ? snap_take_at_build(sn) : snap_take(sk_2, sn); }));
    });
    auto builder_fn = ({
        auto wx_1 = wx;
        auto take_fn_2 = take_fn;
        auto recv_3 = recv;
        (prism_rtl::rc([=](const ForDef& b) {
        return ({
            auto before_ = each(filter(wx_1.snaps, [&](const SnapDef& sn) { return sn.before && (sn.builder == b.name); }), take_fn_2);
            auto after_ = each(filter(wx_1.snaps, [&](const SnapDef& sn) { return (!sn.before) && (sn.builder == b.name); }), take_fn_2);
            append(prelude::push(before_, Do(Do::DoExpr{try_of(Ex(Ex::XMethod{prism_rtl::rc(recv_3), prism_rtl::cat(b.name, "_build"), Array(std::vector{Ex(Ex::XCx{})})}))})), after_);
        });
    }));
    });
    auto gen__fn = ({
        auto at_build_1 = at_build;
        auto recv_2 = recv;
        auto wx_3 = wx;
        auto take_fn_4 = take_fn;
        (prism_rtl::rc([=](const GenDef& gd) {
        return ({
            auto built = at_build_1
                ? Do(Do::DoExpr{try_of(Ex(Ex::XMethod{prism_rtl::rc(recv_2), prism_rtl::cat(gd.name, "_build"), Array(std::vector{Ex(Ex::XCx{})})}))})
                : Do(Do::DoIf{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(gd.name, "_stale")})), Text("replace"), Array(std::vector{Ex(Ex::XBool{false})})}), Array(std::vector{Do(Do::DoExpr{try_of(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(gd.name, "_build"), Array(std::vector{Ex(Ex::XCx{})})}))})}), Array<Do>{}});
            append(Array(std::vector{built}), each(filter(wx_3.snaps, [&](const SnapDef& sn) { return (!sn.before) && (sn.builder == gd.name); }), take_fn_4));
        });
    }));
    });
    return fold(check_errors::range0(len(wx.scopes) + Nat(1u)), Array<Do>{}, [&](const Array<Do>& acc, const Nat& i) {
        return ({
            auto k = or_(len(wx.scopes).checked_sub(i), Nat(0u));
            auto builders = fold(filter(wx.builders, [&](const ForDef& b) { return b.pos.scope == k; }), Array<Do>{}, [&](const Array<Do>& a, const ForDef& b) { return append(a, builder_fn(b)); });
            append(append(acc, builders), fold(filter(wx.gens, [&](const GenDef& gd) { return gd.pos.scope == k; }), Array<Do>{}, [&](const Array<Do>& a, const GenDef& gd) { return append(a, gen__fn(gd)); }));
        });
    });
}


/// SnapTakeAtBuild: fn SnapDef -> Do
Do snap_take_at_build(const SnapDef& sn) {
    return Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XVar{Text("node")})), prism_rtl::cat(sn.name, "_snap")})), Text("take"), Array(std::vector{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text("node")})), prism_rtl::cat(sn.name, "_now"), Array(std::vector{Ex(Ex::XCx{})})}), Ex(Ex::XCx{})})})});
}


/// SnapTake: fn Sinks, SnapDef -> Do
Do snap_take(const Sinks& sk, const SnapDef& sn) {
    auto now = Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(sn.name, "_now"), Array(std::vector{Ex(Ex::XCx{})})});
    auto take_ = Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(sn.name, "_snap")})), sn.eq ? Text("take_compared") : Text("take"), Array(std::vector{now, Ex(Ex::XCx{})})})});
    auto queue = Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XCx{})), Text("answer_later"), Array(std::vector{Ex(Ex::XLater{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text("node")})), prism_rtl::cat(sn.name, "_publish"), Array(std::vector{Ex(Ex::XCx{})})}))})})})});
    auto queued = Do(Do::DoIf{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(sn.name, "_snap")})), Text("queue"), Array(std::vector{Ex(Ex::XCx{})})}), Array(std::vector{Do(Do::DoLet{Pa(Pa::PaBind{Text("node")}), Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XSelf{}))})}), queue}), Array<Do>{}});
    return Do(Do::DoIf{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(sn.name, "_snap")})), Text("marked"), Array(std::vector{Ex(Ex::XCx{})})}), Array(std::vector{take_, queued}), Array<Do>{}});
}


/// SnapPublish: fn Sinks, SnapDef -> MethDef
MethDef snap_publish(const Sinks& sk, const SnapDef& sn) {
    return MethDef{.name = prism_rtl::cat(sn.name, "_publish"), .recv = Recv(Recv::RecvRc{}), .params = Array<std::tuple<Text, OutTy>>{}, .cx_ = CxArg(CxArg::CxMut{}), .ret = OutTy(OutTy::OutUnit{}), .body = Array(std::vector{Do(Do::DoIf{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(sn.name, "_snap")})), Text("published"), Array(std::vector{Ex(Ex::XCx{})})}), hold_written(sk, sn.name), Array<Do>{}})}), .tail = Ex(Ex::XUnit{}), .doc = prism_rtl::cat(sn.what, ", published: its snapshot of the tick before moved it, written as a hold is (pick ST).")};
}


/// GatheredMoved: fn SnapDef -> MethDef
MethDef gathered_moved(const SnapDef& sn) {
    return MethDef{.name = prism_rtl::cat(sn.name, "_moved"), .recv = Recv(Recv::RecvRc{}), .params = Array<std::tuple<Text, OutTy>>{}, .cx_ = CxArg(CxArg::CxMut{}), .ret = OutTy(OutTy::OutUnit{}), .body = Array(std::vector{Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(sn.name, "_snap")})), Text("mark"), Array(std::vector{Ex(Ex::XCx{})})})}), Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XCx{})), Text("build_later"), Array(std::vector{Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XSelf{}))})})})})}), .tail = Ex(Ex::XUnit{}), .doc = Text("A row's result moved: the `for`'s gathered dynamic is marked, and its snapshot taken after the builder (pick ST).")};
}


/// DocumentGetter: fn Wx -> MethDef
MethDef document_getter(const Wx& wx) {
    auto is_own_fn = prism_rtl::rc([=](const Pos_& p_) { return p_.scope == Nat(0u); });
    auto body = document_body(({
        auto f = prism_rtl::rc(vec_push);
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Do>(std::tuple<Ex, Ex>)>>(prism_rtl::rc([=](std::tuple<Ex, Ex> _p0) {
        auto&& a0 = std::get<0>(_p0);
        auto&& a1 = std::get<1>(_p0);
        return ({
            auto f_1 = f;
            once_job([=]() { return prism_rtl::finished(f_1(a0, a1)); });
        });
    })));
    }), filter(wx.places, [&](const Place& pl) { return is_own_fn(pl.pos); }), filter(wx.builders, [&](const ForDef& b) { return is_own_fn(b.pos); }), filter(wx.gens, [&](const GenDef& gd) { return is_own_fn(gd.pos); }));
    return MethDef{.name = Text("document"), .recv = Recv(Recv::RecvRef{}), .params = Array<std::tuple<Text, OutTy>>{}, .cx_ = CxArg(CxArg::CxRef{}), .ret = OutTy(OutTy::OutNamed{Text("Vec"), Array(std::vector{OutTy(OutTy::OutTuple{Array(std::vector{OutTy(OutTy::OutPath{}), elem_ty()})})})}), .body = append(Array(std::vector{Do(Do::DoLet{Pa(Pa::PaTyped{prism_rtl::rc(Pa(Pa::PaMut{Text("doc")})), OutTy(OutTy::OutNamed{Text("Vec"), Array(std::vector{OutTy(OutTy::OutTuple{Array(std::vector{OutTy(OutTy::OutPath{}), elem_ty()})})})})}), Ex(Ex::XCall{Text("Vec::new"), Array<Ex>{}})})}), body), .tail = Ex(Ex::XVar{Text("doc")}), .doc = Text("The row's own places, entries of its host's document, by their paths relative to the row (pick HO).")};
}


/// DocumentMoved: fn Text -> MethDef
MethDef document_moved(const Text& m) {
    return MethDef{.name = Text("document_moved"), .recv = Recv(Recv::RecvRc{}), .params = Array<std::tuple<Text, OutTy>>{}, .cx_ = CxArg(CxArg::CxMut{}), .ret = OutTy(OutTy::OutUnit{}), .body = Array(std::vector{Do(Do::DoIfLet{Pa(Pa::PaCtor{Text("Some"), Array(std::vector{Pa(Pa::PaBind{Text("parent")})})}), Ex(Ex::XUpgrade{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), Text("parent")}))}), Array(std::vector{Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text("parent")})), m, Array(std::vector{Ex(Ex::XCx{})})})})}), Array<Do>{}})}), .tail = Ex(Ex::XUnit{}), .doc = Text("A place of this row may have moved: its host's document moved, and the host's readers and rows are marked (pick HO).")};
}


/// DocumentBody: fn (fn Ex, Ex -> Do), [Place], [ForDef], [GenDef] -> [Do]
Array<Do> document_body(const prism_rtl::Fn<prism_rtl::JobRef<Do>(std::tuple<Ex, Ex>)>& add_fn, const Array<Place>& places, const Array<ForDef>& builders, const Array<GenDef>& gens) {
    auto statics = run_to_end(each_job(places, ({
        auto add_fn_1 = add_fn;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Do>(Place)>>(prism_rtl::rc([=](Place p0) {
        return ({
            auto add_fn_1_2 = add_fn_1;
            entered(once_job([=]() {
            return ({
                auto pl = p0;
                ({
                auto level = pl.getter == Text("")
                    ? pl.level
                    : Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XSelf{})), pl.getter, Array(std::vector{Ex(Ex::XCx{})})});
                add_fn_1_2(std::tuple{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XCall{Text("Path::root"), Array<Ex>{}})), Text("at"), Array(std::vector{Ex(Ex::XIndex{pl.pos.at})})}), level})->cycle();
            });
            });
        }));
        });
    })));
    })));
    auto rows = run_to_end(each_job(builders, ({
        auto add_fn_1 = add_fn;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Do>(ForDef)>>(prism_rtl::rc([=](ForDef p0) {
        return ({
            auto add_fn_1_2 = add_fn_1;
            entered(once_job([=]() {
            return ({
                auto b = p0;
                call_value(add_fn_1_2(std::tuple{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XCall{Text("Path::root"), Array<Ex>{}})), Text("at"), Array(std::vector{Ex(Ex::XIndex{b.pos.at})})})), Text("child"), Array(std::vector{Ex(Ex::XCtor{Text("Segment::Key"), Array(std::vector{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text("k")})), Text("to_pod"), Array<Ex>{}})})})})})), Text("join"), Array(std::vector{Ex(Ex::XRef{prism_rtl::rc(Ex(Ex::XVar{Text("p")}))})})}), Ex(Ex::XVar{Text("e")})}), [=](Do add_292229) { return prism_rtl::finished(Do(Do::DoFor{Pa(Pa::PaTuple{Array(std::vector{Pa(Pa::PaBind{Text("k")}), Pa(Pa::PaBind{Text("row")})})}), Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), b.name})), Text("borrow"), Array<Ex>{}})), Text("iter"), Array<Ex>{}}), Array(std::vector{Do(Do::DoFor{Pa(Pa::PaTuple{Array(std::vector{Pa(Pa::PaBind{Text("p")}), Pa(Pa::PaBind{Text("e")})})}), Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text("row")})), Text("document"), Array(std::vector{Ex(Ex::XCx{})})}), Array(std::vector{add_292229})})})})); });
            });
        }));
        });
    })));
    })));
    auto generations = run_to_end(each_job(gens, ({
        auto add_fn_1 = add_fn;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Do>(GenDef)>>(prism_rtl::rc([=](GenDef p0) {
        return ({
            auto add_fn_1_2 = add_fn_1;
            entered(once_job([=]() {
            return ({
                auto gd = p0;
                call_value(add_fn_1_2(std::tuple{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XCall{Text("Path::root"), Array<Ex>{}})), Text("at"), Array(std::vector{Ex(Ex::XIndex{gd.pos.at})})})), Text("child"), Array(std::vector{Ex(Ex::XCtor{Text("Segment::Gen"), Array(std::vector{Ex(Ex::XVar{Text("g")})})})})})), Text("join"), Array(std::vector{Ex(Ex::XRef{prism_rtl::rc(Ex(Ex::XVar{Text("p")}))})})}), Ex(Ex::XVar{Text("e")})}), [=](Do add_292801) { return prism_rtl::finished(Do(Do::DoIfLet{Pa(Pa::PaCtor{Text("Some"), Array(std::vector{Pa(Pa::PaBind{Text("row")})})}), Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), gd.name})), Text("borrow"), Array<Ex>{}})), Text("as_ref"), Array<Ex>{}}), Array(std::vector{Do(Do::DoLet{Pa(Pa::PaBind{Text("g")}), Ex(Ex::XBin{Text("-"), prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(gd.name, "_count")})), Text("get"), Array<Ex>{}})), prism_rtl::rc(Ex(Ex::XIndex{Nat(1u)}))})}), Do(Do::DoFor{Pa(Pa::PaTuple{Array(std::vector{Pa(Pa::PaBind{Text("p")}), Pa(Pa::PaBind{Text("e")})})}), Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text("row")})), Text("document"), Array(std::vector{Ex(Ex::XCx{})})}), Array(std::vector{add_292801})})}), Array<Do>{}})); });
            });
        }));
        });
    })));
    })));
    return append(append(statics, rows), generations);
}


/// MapInsert: fn Ex, Ex -> Do
Do map_insert(const Ex& path_, const Ex& e) {
    return Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text("doc")})), Text("insert"), Array(std::vector{path_, e})})});
}


/// VecPush: fn Ex, Ex -> Do
Do vec_push(const Ex& path_, const Ex& e) {
    return Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text("doc")})), Text("push"), Array(std::vector{Ex(Ex::XTuple{Array(std::vector{path_, e})})})})});
}


/// DynAnswerArm: fn Sinks, Pos, Text, OutTy -> ((Pa, Ex))
std::tuple<Pa, Ex> dyn_answer_arm(const Sinks& sk, const Pos_& pos, const Text& f, const OutTy& t) {
    return std::tuple{pos_pat(pos, Array<Pa>{}), Ex(Ex::XBlock{dyn_place_write(sk, f, Ex(Ex::XDecode{t, prism_rtl::rc(Ex(Ex::XVar{Text("v")}))})), prism_rtl::rc(Ex(Ex::XUnit{}))})};
}


/// DynPlaceWrite: fn Sinks, Text, Ex -> [Do]
Array<Do> dyn_place_write(const Sinks& sk, const Text& f, const Ex& value) {
    return append(Array(std::vector{Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(f)})), Text("set"), Array(std::vector{value, Ex(Ex::XCx{})})})})}), hold_written(sk, f));
}


/// UpdatedGaps: fn Wx, [Gn], Bool -> [Do]
Array<Do> updated_gaps(const Wx& wx, const Array<Gn>& gns, const bool& is_gen) {
    auto holds = fold(wx.fields, Array<Text>{}, [&](const Array<Text>& acc, const std::tuple<Text, OutTy, Text>& _p1) {
        auto&& f = std::get<0>(_p1);
        auto&& t = std::get<1>(_p1);
        return is_hold(t) ? prelude::push(acc, f) : acc;
    });
    auto derived = keys(wx.dyn_reads);
    auto roots = snap_names(wx);
    auto own_ = fold(filter(gns, [&](const Gn& g) { return g.kind == GnKind(GnKind::GnUpdated{}); }), Array<Do>{}, [&](const Array<Do>& acc, const Gn& g) {
        return fold(g.reads, acc, [&](const Array<Do>& a, const Read& r) {
            return ({
                __label__ _done;
                prism_rtl::Slot<Array<Do>> _v;
                if (prism_rtl::is<Read::ParentRead>(r)) {
                    auto&& f = prism_rtl::as<Read::ParentRead>(r).a0;
                    _v.set(is_gen
                        ? prelude::push(a, refusal_do(prism_rtl::cat("`!Updated` of a dynamic in a generation that reads its block's `", f, "`, which the block does not tell a generation of (gap DY)")))
                        : a);
                    goto _done;
                }
                if (prism_rtl::is<Read::OwnRead>(r)) {
                    auto&& f = prism_rtl::as<Read::OwnRead>(r).a0;
                    _v.set((check_types::has_text(holds, f) || check_types::has_text(derived, f)) || check_types::has_text(roots, f)
                        ? a
                        : prelude::push(a, refusal_do(prism_rtl::cat("`!Updated` of a dynamic that reads `", f, "`, which no sink of this node writes (no height for its event)"))));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
        });
    });
    return fold(wx.pending, own_, [&](const Array<Do>& acc, const PendingRow& p_) {
        return fold(row_hears(p_.wx), acc, [&](const Array<Do>& a, const Text& m) {
            return ({
                auto behind = reads_closed(wx.dyn_reads, Array(std::vector{Read(Read::OwnRead{m})}));
                auto written = fold(behind, false, [&](const bool& w, const Read& r) {
                    return w || ({
                        __label__ _done;
                        prism_rtl::Slot<bool> _v;
                        if (prism_rtl::is<Read::OwnRead>(r)) {
                            auto&& h = prism_rtl::as<Read::OwnRead>(r).a0;
                            _v.set(check_types::has_text(holds, h));
                            goto _done;
                        }
                        if (prism_rtl::is<Read::ParentRead>(r)) {
                            _v.set(true);
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                });
                (check_types::has_text(roots, m) || reaches_snap(roots, behind)
                ? prelude::push(a, refusal_do(prism_rtl::cat("`!Updated` of a dynamic in a row that reads its block's `", m, "`, a structural dynamic the block publishes at the start of a tick, not lowered for a row's `!Updated` (gap SU)")))
                : written || check_types::has_text(derived, m)
                ? a
                : prelude::push(a, refusal_do(prism_rtl::cat("`!Updated` of a dynamic in a row that reads its block's `", m, "`, which no sink of the block writes (no height for its event)"))));
            });
        });
    });
}


/// FinishPending: unbounded fn Wx, [Gn] -> (([NodeDef], [Gn]))
std::tuple<Array<NodeDef>, Array<Gn>> finish_pending(const Wx& wx, const Array<Gn>& gns) {
    return run_to_end(fold_job(wx.pending, std::tuple{Array<NodeDef>{}, gns}, ({
        auto wx_1 = wx;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<NodeDef>, Array<Gn>>>(std::tuple<std::tuple<Array<NodeDef>, Array<Gn>>, PendingRow>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<NodeDef>, Array<Gn>>, PendingRow> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto wx_1_2 = wx_1;
            entered(once_job([=]() {
            return ({
                auto [defs, cur] = p0;
                auto p_ = p1;
                ({
                auto floors = fold(row_hears(p_.wx), Map<Text, Nat>{}, [&](const Map<Text, Nat>& acc, const Text& m) { return insert(acc, m, parent_floor(wx_1_2, cur, Array(std::vector{Read(Read::ParentRead{m})}))); });
                auto floored = ({
                    Wx this_ = p_.wx;
                    this_.floors = floors;
                    this_.gns = each(this_.gns, [&](const Gn& g) {
                        return g.kind == GnKind(GnKind::GnUpdated{})
                            ? with_floor(g, parent_floor(wx_1_2, cur, reads_closed(p_.wx.dyn_reads, g.reads)))
                            : g;
                    });
                    this_;
                });
                call_then(start_finish_node(floored, p_.qk, p_.params, true), [=](NodeDef finish_node_297067) {
                return ({
                    auto def = finish_node_297067;
                    auto next = ({
                        __label__ _done;
                        prism_rtl::Slot<Array<Gn>> _v;
                        auto&& _m = p_.gather;
                        if (prism_rtl::is_some(_m)) {
                            auto&& gid = prism_rtl::some_of(_m);
                            _v.set(each(cur, [&](const Gn& g) { return g.id == gid ? with_height(g, def.top + Nat(1u)) : g; }));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(cur);
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                    (prism_rtl::finished(std::tuple{prelude::push(defs, def), next}));
                });
            });
            });
            });
        }));
        });
    }));
    })));
}


prism_rtl::Turn<std::tuple<Array<NodeDef>, Array<Gn>>> FinishPending::cycle() const {
    const auto& wx = this->wx;
    const auto& gns = this->gns;
    return fold_job(wx.pending, std::tuple{Array<NodeDef>{}, gns}, ({
        auto wx_1 = wx;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<NodeDef>, Array<Gn>>>(std::tuple<std::tuple<Array<NodeDef>, Array<Gn>>, PendingRow>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<NodeDef>, Array<Gn>>, PendingRow> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto wx_1_2 = wx_1;
            entered(once_job([=]() {
            return ({
                auto [defs, cur] = p0;
                auto p_ = p1;
                ({
                auto floors = fold(row_hears(p_.wx), Map<Text, Nat>{}, [&](const Map<Text, Nat>& acc, const Text& m) { return insert(acc, m, parent_floor(wx_1_2, cur, Array(std::vector{Read(Read::ParentRead{m})}))); });
                auto floored = ({
                    Wx this_ = p_.wx;
                    this_.floors = floors;
                    this_.gns = each(this_.gns, [&](const Gn& g) {
                        return g.kind == GnKind(GnKind::GnUpdated{})
                            ? with_floor(g, parent_floor(wx_1_2, cur, reads_closed(p_.wx.dyn_reads, g.reads)))
                            : g;
                    });
                    this_;
                });
                call_then(start_finish_node(floored, p_.qk, p_.params, true), [=](NodeDef finish_node_297067) {
                return ({
                    auto def = finish_node_297067;
                    auto next = ({
                        __label__ _done;
                        prism_rtl::Slot<Array<Gn>> _v;
                        auto&& _m = p_.gather;
                        if (prism_rtl::is_some(_m)) {
                            auto&& gid = prism_rtl::some_of(_m);
                            _v.set(each(cur, [&](const Gn& g) { return g.id == gid ? with_height(g, def.top + Nat(1u)) : g; }));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(cur);
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                    (prism_rtl::finished(std::tuple{prelude::push(defs, def), next}));
                });
            });
            });
            });
        }));
        });
    }));
    }))->cycle();
}


/// `Start FinishPending, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<NodeDef>, Array<Gn>>> start_finish_pending(Wx wx, Array<Gn> gns) {
    return std::make_shared<FinishPending>(wx, gns);
}


/// ParentFloor: fn Wx, [Gn], [Read] -> Nat
Nat parent_floor(const Wx& wx, const Array<Gn>& gns, const Array<Read>& reads) {
    return fold(reads, Nat(0u), [&](const Nat& hi, const Read& r) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Nat> _v;
            if (prism_rtl::is<Read::ParentRead>(r)) {
                auto&& m = prism_rtl::as<Read::ParentRead>(r).a0;
                _v.set(fold(reads_closed(wx.dyn_reads, Array(std::vector{Read(Read::OwnRead{m})})), hi, [&](const Nat& h2, const Read& hr) {
                    return ({
                        __label__ _done;
                        prism_rtl::Slot<Nat> _v;
                        if (prism_rtl::is<Read::OwnRead>(hr)) {
                            auto&& f = prism_rtl::as<Read::OwnRead>(hr).a0;
                            _v.set(fold(gns, h2, [&](const Nat& h3, const Gn& g) { return writes_hold(g, f) ? prelude::max(h3, g.height + Nat(1u)) : h3; }));
                            goto _done;
                        }
                        if (prism_rtl::is<Read::ParentRead>(hr)) {
                            auto&& up = prism_rtl::as<Read::ParentRead>(hr).a0;
                            _v.set(prelude::max(h2, or_(prelude::get(wx.floors, up), Nat(0u))));
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                }));
                goto _done;
            }
            if (prism_rtl::is<Read::OwnRead>(r)) {
                _v.set(hi);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
}


/// WritesHold: fn Gn, Text -> Bool
bool writes_hold(const Gn& g, const Text& f) {
    return fold(g.outs, false, [&](const bool& acc, const Out& o) { return acc || sink_writes_hold(o.sink, f); });
}


/// SinkWritesHold: fn Sk, Text -> Bool
bool sink_writes_hold(const Sk& sk0, const Text& f) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        if (prism_rtl::is<Sk::SkHold>(sk0)) {
            auto&& h = prism_rtl::as<Sk::SkHold>(sk0).a0;
            _v.set(h == f);
            goto _done;
        }
        if (prism_rtl::is<Sk::SkMachine>(sk0)) {
            auto&& h = prism_rtl::as<Sk::SkMachine>(sk0).a0;
            _v.set(h == f);
            goto _done;
        }
        {
            auto&& other = sk0;
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// WithFloor: fn Gn, Nat -> Gn
Gn with_floor(const Gn& g, const Nat& h) {
    Gn this_ = g;
    this_.floor = h;
    return this_;
}


/// WithHeight: fn Gn, Nat -> Gn
Gn with_height(const Gn& g, const Nat& h) {
    Gn this_ = g;
    this_.height = h;
    return this_;
}


/// RowHears: fn Wx -> [Text]
Array<Text> row_hears(const Wx& wx) {
    auto from_updated = fold(filter(wx.gns, [&](const Gn& g) { return g.kind == GnKind(GnKind::GnUpdated{}); }), Array<Read>{}, [&](const Array<Read>& acc, const Gn& g) { return union_reads(acc, reads_closed(wx.dyn_reads, g.reads)); });
    auto from_rows = fold(wx.row_marks, Array<Read>{}, [&](const Array<Read>& acc, const RowMarks& rm) { return union_reads(acc, reads_closed(wx.dyn_reads, append(rm.reads, each(rm.wrote, [&](const Text& m) { return Read(Read::OwnRead{m}); })))); });
    return fold(union_reads(from_updated, from_rows), Array<Text>{}, [&](const Array<Text>& acc, const Read& r) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            if (prism_rtl::is<Read::ParentRead>(r)) {
                auto&& m = prism_rtl::as<Read::ParentRead>(r).a0;
                _v.set(check_types::add_text(acc, m));
                goto _done;
            }
            if (prism_rtl::is<Read::OwnRead>(r)) {
                _v.set(acc);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
}


/// RowWritten: fn Wx, RowMarks, Read -> [Do]
Array<Do> row_written(const Wx& wx, const RowMarks& rm, const Read& r) {
    auto dirty_1 = has_read(reads_closed(wx.dyn_reads, rm.reads), r)
        ? Array(std::vector{Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XCx{})), Text("dirty"), Array(std::vector{Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{Text("row")}))})})})})})
        : Array<Do>{};
    auto told = fold(rm.wrote, Array<Do>{}, [&](const Array<Do>& acc, const Text& m) {
        return has_read(reads_closed(wx.dyn_reads, Array(std::vector{Read(Read::OwnRead{m})})), r)
            ? prelude::push(acc, Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text("row")})), prism_rtl::cat("parent_wrote_", m), Array(std::vector{Ex(Ex::XCx{})})})}))
            : acc;
    });
    auto body = append(dirty_1, told);
    return len(body) == Nat(0u)
        ? Array<Do>{}
        : ({
        __label__ _done;
        prism_rtl::Slot<Array<Do>> _v;
        auto&& _m = rm.kind;
        if (prism_rtl::is<RowKind::GenerationRow>(_m)) {
            _v.set(Array(std::vector{Do(Do::DoIfLet{Pa(Pa::PaCtor{Text("Some"), Array(std::vector{Pa(Pa::PaBind{Text("row")})})}), Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), rm.builder})), Text("borrow"), Array<Ex>{}})), Text("as_ref"), Array<Ex>{}}), body, Array<Do>{}})}));
            goto _done;
        }
        {
            _v.set(Array(std::vector{Do(Do::DoFor{Pa(Pa::PaBind{Text("row")}), Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), rm.builder})), Text("borrow"), Array<Ex>{}})), Text("values"), Array<Ex>{}}), body})}));
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// PatchPlace: fn Wx, Place -> [Do]
Array<Do> patch_place(const Wx& wx, const Place& p_) {
    auto pull = Do(Do::DoLet{Pa(Pa::PaBind{p_.getter}), Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XSelf{})), p_.getter, Array(std::vector{Ex(Ex::XCx{})})})});
    auto at_ = place_at(wx, Text("self"), p_.pos);
    return Array(std::vector{pull, Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XCx{})), Text("changed"), Array(std::vector{at_, Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{p_.getter})), Text("to_pod"), Array<Ex>{}})})})})});
}


/// Emits: fn Wx, Pos -> Bool
bool emits(const Wx& wx, const Pos_& pos) {
    return (pos.scope == Nat(0u)) && (wx.hosted_by == std::optional<Text>{});
}


/// ResultTold: fn Ex -> [Do]
Array<Do> result_told(const Ex& node_) {
    auto r_1 = Do(Do::DoLet{Pa(Pa::PaBind{Text("r")}), Ex(Ex::XMethod{prism_rtl::rc(node_), Text("result_value"), Array(std::vector{Ex(Ex::XCx{})})})});
    return Array(std::vector{r_1, result_kept(node_), result_tell()});
}


/// ResultMoved: fn Ex -> [Do]
Array<Do> result_moved(const Ex& node_) {
    auto r_1 = Do(Do::DoLet{Pa(Pa::PaBind{Text("r")}), Ex(Ex::XMethod{prism_rtl::rc(node_), Text("result_value"), Array(std::vector{Ex(Ex::XCx{})})})});
    auto last = Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(node_), Text("result_last")})), Text("borrow"), Array<Ex>{}})), Text("as_ref"), Array<Ex>{}});
    auto differs = Ex(Ex::XBin{Text("!="), prism_rtl::rc(last), prism_rtl::rc(Ex(Ex::XCtor{Text("Some"), Array(std::vector{Ex(Ex::XRef{prism_rtl::rc(Ex(Ex::XVar{Text("r")}))})})}))});
    return Array(std::vector{r_1, Do(Do::DoIf{differs, Array(std::vector{result_kept(node_), result_tell()}), Array<Do>{}})});
}


/// ResultKept: fn Ex -> Do
Do result_kept(const Ex& node_) {
    return Do(Do::DoAssign{Ex(Ex::XDeref{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(node_), Text("result_last")})), Text("borrow_mut"), Array<Ex>{}}))}), Ex(Ex::XCtor{Text("Some"), Array(std::vector{Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{Text("r")}))})})})});
}


/// let resultTell
Do result_tell() {
    return Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XCx{})), Text("result"), Array(std::vector{Ex(Ex::XCtor{Text("Outcome::Value"), Array(std::vector{Ex(Ex::XVar{Text("r")})})})})})});
}


/// Adoption: fn FlatDef -> [Do]
Array<Do> adoption(const FlatDef& fl) {
    auto adopt = Ex(Ex::XLater{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text("node")})), prism_rtl::cat(fl.name, "_adopt"), Array(std::vector{Ex(Ex::XCx{})})}))});
    return Array(std::vector{Do(Do::DoLet{Pa(Pa::PaBind{Text("node")}), Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XSelf{}))})}), Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XCx{})), Text("answer_later"), Array(std::vector{adopt})})})});
}


/// PlaceAt: fn Wx, Text, Pos -> Ex
Ex place_at(const Wx& wx, const Text& recv, const Pos_& pos) {
    auto at_ = Array(std::vector{Ex(Ex::XIndex{pos.at})});
    return emits(wx, pos)
        ? Ex(Ex::XMethod{prism_rtl::rc(recv == Text("")
        ? Ex(Ex::XVar{Text("path")})
        : recv == Text("self")
        ? Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), Text("path")})
        : Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XVar{recv})), Text("path")})), Text("at"), at_})
        : Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XCall{Text("Path::root"), Array<Ex>{}})), Text("at"), at_});
}


/// PosPat: fn Pos, [Pa] -> Pa
Pa pos_pat(const Pos_& pos, const Array<Pa>& tail_) {
    return Pa(Pa::PaSlice{append(Array(std::vector{Pa(Pa::PaCtor{Text("Segment::Pos"), Array(std::vector{Pa(Pa::PaIndex{pos.at})})})}), tail_)});
}


/// let keyTail
Array<Pa> key_tail() {
    return Array(std::vector{Pa(Pa::PaCtor{Text("Segment::Key"), Array(std::vector{Pa(Pa::PaBind{Text("k")})})}), Pa(Pa::PaRest{Text("rest")})});
}


/// let genTail
Array<Pa> gen_tail() {
    return Array(std::vector{Pa(Pa::PaCtor{Text("Segment::Gen"), Array(std::vector{Pa(Pa::PaBind{Text("g")})})}), Pa(Pa::PaRest{Text("rest")})});
}


/// ?HostedRows: fn Wx -> ?Text
std::optional<Text> hosted_rows(const Wx& wx) {
    return wx.pos.scope > Nat(0u)
        ? std::optional(prism_rtl::cat(or_(index(wx.scopes, lexer::dec(wx.pos.scope)), Text("")), "_moved"))
        : ({
        __label__ _done;
        prism_rtl::Slot<std::optional<Text>> _v;
        auto&& _m = wx.hosted_by;
        if (prism_rtl::is_some(_m)) {
            _v.set(std::optional(Text("document_moved")));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(std::optional<Text>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// RootDynPatch: fn Wx -> [Do]
Array<Do> root_dyn_patch(const Wx& wx) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Array<Do>> _v;
        auto&& _m = wx.root_dyn;
        if (prism_rtl::is_some(_m)) {
            _v.set(Array(std::vector{Do(Do::DoLine{result_moved(Ex(Ex::XSelf{}))})}));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Array<Do>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// AnswerArm: fn Wx, Pos, Nat, OutTy -> ((Pa, Ex))
std::tuple<Pa, Ex> answer_arm(const Wx& wx, const Pos_& pos, const Nat& id, const OutTy& t) {
    auto call = Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XSelf{})), gn_of(wx, id).name, Array(std::vector{Ex(Ex::XDecode{t, prism_rtl::rc(Ex(Ex::XVar{Text("v")}))}), Ex(Ex::XCx{})})});
    return std::tuple{pos_pat(pos, Array<Pa>{}), call};
}


/// TypedAnswerArm: fn Wx, Pos, Nat, Text -> ((Pa, [Do]))
std::tuple<Pa, Array<Do>> typed_answer_arm(const Wx& wx, const Pos_& pos, const Nat& id, const Text& acc) {
    return std::tuple{pos_pat(pos, Array<Pa>{}), Array(std::vector{self_call(gn_of(wx, id).name, Array(std::vector{try_of(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text("v")})), acc, Array<Ex>{}}))}))})};
}


/// TypedDynArm: fn Sinks, Pos, Text, Text -> ((Pa, [Do]))
std::tuple<Pa, Array<Do>> typed_dyn_arm(const Sinks& sk, const Pos_& pos, const Text& f, const Text& acc) {
    return std::tuple{pos_pat(pos, Array<Pa>{}), dyn_place_write(sk, f, try_of(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text("v")})), acc, Array<Ex>{}})))};
}


/// TypedForwardArm: fn ForDef, Ex -> ((Pa, [Do]))
std::tuple<Pa, Array<Do>> typed_forward_arm(const ForDef& b, const Ex& segs) {
    auto row_of = Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(b.name)})), Text("borrow"), Array<Ex>{}})), Text("get"), Array(std::vector{Ex(Ex::XRef{prism_rtl::rc(Ex(Ex::XDecode{b.key_ty, prism_rtl::rc(Ex(Ex::XVar{Text("k")}))}))})})})), Text("cloned"), Array<Ex>{}});
    return std::tuple{pos_pat(b.pos, key_tail()), Array(std::vector{Do(Do::DoLet{Pa(Pa::PaBind{Text("row")}), row_of}), Do(Do::DoMatch{Ex(Ex::XVar{Text("row")}), Array(std::vector{std::tuple{Pa(Pa::PaCtor{Text("Some"), Array(std::vector{Pa(Pa::PaBind{Text("row")})})}), Array(std::vector{Do(Do::DoExpr{try_of(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text("row")})), Text("deliver"), Array(std::vector{Ex(Ex::XVar{Text("rest")}), Ex(Ex::XVar{Text("v")}), Ex(Ex::XCx{})})}))})})}, std::tuple{Pa(Pa::PaUnit{Text("None")}), Array(std::vector{Do(Do::DoReturn{Ex(Ex::XCtor{Text("Err"), Array(std::vector{Ex(Ex::XCall{Text("Fault::answer"), Array(std::vector{Ex(Ex::XFormatStr{Array(std::vector{Ex(Ex::XText{Text("no row ")}), Ex(Ex::XVar{Text("k")}), Ex(Ex::XText{Text(" under the hosted place ")}), Ex(Ex::XCtor{Text("Path"), Array(std::vector{Ex(Ex::XMethod{prism_rtl::rc(segs), Text("to_vec"), Array<Ex>{}})})})})})})})})})})})}})})})};
}


/// TypedGenArm: fn GenDef -> ((Pa, [Do]))
std::tuple<Pa, Array<Do>> typed_gen_arm(const GenDef& gd) {
    auto current = Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(gd.name)})), Text("borrow"), Array<Ex>{}}))});
    auto is_current = Ex(Ex::XBin{Text("=="), prism_rtl::rc(Ex(Ex::XBin{Text("+"), prism_rtl::rc(Ex(Ex::XDeref{prism_rtl::rc(Ex(Ex::XVar{Text("g")}))})), prism_rtl::rc(Ex(Ex::XIndex{Nat(1u)}))})), prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(gd.name, "_count")})), Text("get"), Array<Ex>{}}))});
    return std::tuple{pos_pat(gd.pos, gen_tail()), Array(std::vector{Do(Do::DoLet{Pa(Pa::PaBind{Text("row")}), current}), Do(Do::DoIfLet{Pa(Pa::PaCtor{Text("Some"), Array(std::vector{Pa(Pa::PaBind{Text("row")})})}), Ex(Ex::XVar{Text("row")}), Array(std::vector{Do(Do::DoIf{is_current, Array(std::vector{Do(Do::DoExpr{try_of(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text("row")})), Text("deliver"), Array(std::vector{Ex(Ex::XVar{Text("rest")}), Ex(Ex::XVar{Text("v")}), Ex(Ex::XCx{})})}))})}), Array<Do>{}})}), Array<Do>{}})})};
}


/// TypedDispatch: fn Sinks, Text, Nat -> MethDef
MethDef typed_dispatch(const Sinks& sk, const Text& name, const Nat& scope) {
    auto wx = sk.wx;
    auto in_scope_fn = ({
        auto scope_1 = scope;
        (prism_rtl::rc([=](const Pos_& p_) { return p_.scope == scope_1; }));
    });
    auto [recv, param, segs, doc] = scope > Nat(0u)
        ? std::tuple{Recv(Recv::RecvRc{}), std::tuple{Text("place"), OutTy(OutTy::OutRef{prism_rtl::rc(OutTy(OutTy::OutPath{}))})}, Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text("place")})), Text("segments"), Array<Ex>{}}), prism_rtl::cat("The host at place ", place_text(or_(index(wx.hosts, lexer::dec(scope)), dummy_host()).pos), " answers its child's place `place` (pick HO): into the child's input method, a hold the place's element answers, or the row of a `for` or `rebuild` under it.")}
        : std::tuple{Recv(Recv::RecvOwned{}), std::tuple{Text("at"), OutTy(OutTy::OutRef{prism_rtl::rc(OutTy(OutTy::OutSlice{prism_rtl::rc(OutTy(OutTy::OutNamed{Text("Segment"), Array<OutTy>{}}))}))})}, Ex(Ex::XVar{Text("at")}), Text("A host's answer to a place of this row's own, `at` under the row (pick HO): into the input method, a hold, or a row under it.")};
    auto answers = each(filter(wx.answers, [&](const std::tuple<Pos_, Nat, OutTy, Text>& _p0) {
        auto&& pos = std::get<0>(_p0);
        return in_scope_fn(pos);
    }), [&](const std::tuple<Pos_, Nat, OutTy, Text>& _p0) {
        auto&& pos = std::get<0>(_p0);
        auto&& id = std::get<1>(_p0);
        auto&& acc = std::get<3>(_p0);
        return typed_answer_arm(wx, pos, id, acc);
    });
    auto dyns = each(filter(wx.dyn_places, [&](const std::tuple<Pos_, Text, OutTy, Text>& _p0) {
        auto&& pos = std::get<0>(_p0);
        return in_scope_fn(pos);
    }), [&](const std::tuple<Pos_, Text, OutTy, Text>& _p0) {
        auto&& pos = std::get<0>(_p0);
        auto&& f = std::get<1>(_p0);
        auto&& acc = std::get<3>(_p0);
        return typed_dyn_arm(sk, pos, f, acc);
    });
    auto rows = each(filter(wx.builders, [&](const ForDef& b) { return in_scope_fn(b.pos); }), [&](const ForDef& b) { return typed_forward_arm(b, segs); });
    auto gens = each(filter(wx.gens, [&](const GenDef& gd) { return in_scope_fn(gd.pos); }), [&](const GenDef& gd) { return typed_gen_arm(gd); });
    auto none = std::tuple{Pa(Pa::PaWild{}), Array(std::vector{Do(Do::DoReturn{Ex(Ex::XCtor{Text("Err"), Array(std::vector{Ex(Ex::XCall{Text("Fault::answer"), Array(std::vector{Ex(Ex::XFormatStr{Array(std::vector{Ex(Ex::XText{Text("no hosted place at ")}), Ex(Ex::XCtor{Text("Path"), Array(std::vector{Ex(Ex::XMethod{prism_rtl::rc(segs), Text("to_vec"), Array<Ex>{}})})}), Ex(Ex::XText{Text(" to answer")})})})})})})})})})};
    auto arms = prelude::push(append(append(append(answers, dyns), rows), gens), none);
    return MethDef{.name = name, .recv = recv, .params = Array(std::vector{param, std::tuple{Text("v"), OutTy(OutTy::OutRef{prism_rtl::rc(answer_ty_value())})}}), .cx_ = CxArg(CxArg::CxMut{}), .ret = OutTy(OutTy::OutNamed{Text("Done"), Array<OutTy>{}}), .body = Array(std::vector{Do(Do::DoMatch{segs, arms})}), .tail = Ex(Ex::XCtor{Text("Ok"), Array(std::vector{Ex(Ex::XUnit{})})}), .doc = doc};
}


/// let dummyHost
HostDef dummy_host() {
    return HostDef{.pos = pos0(), .name = Text(""), .scope = Nat(0u)};
}


/// SortNats: fn [Nat] -> [Nat]
Array<Nat> sort_nats(const Array<Nat>& xs) {
    return fold(xs, Array<Nat>{}, [&](const Array<Nat>& acc, const Nat& x) { return append(prelude::push(filter(acc, [&](const Nat& y) { return y < x; }), x), filter(acc, [&](const Nat& y) { return !(y < x); })); });
}


/// AskWake: fn Sinks, Nat -> [Do]
Array<Do> ask_wake(const Sinks& sk, const Nat& h) {
    auto c = Ex(Ex::XConst{wake_const(sk.heights, h)});
    auto ask_1 = Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), Text("wakes")})), Text("ask"), Array(std::vector{c})})});
    auto wake_2 = Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XCx{})), Text("wake"), Array(std::vector{c, Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XSelf{}))})})})});
    return sk.many ? Array(std::vector{ask_1, wake_2}) : Array(std::vector{wake_2});
}


/// GatherIn: fn Sinks, Gn -> MethDef
MethDef gather_in(const Sinks& sk, const Gn& g) {
    auto field = or_(index(g.inputs, Nat(0u)), Text(""));
    auto kt = ({
        __label__ _done;
        prism_rtl::Slot<OutTy> _v;
        auto&& _m = g.ty;
        if (prism_rtl::is<OutTy::OutMap>(_m)) {
            auto&& k = prism_rtl::as<OutTy::OutMap>(_m).a0;
            _v.set(k);
            goto _done;
        }
        {
            _v.set(OutTy(OutTy::OutUnit{}));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto vt = ({
        __label__ _done;
        prism_rtl::Slot<OutTy> _v;
        auto&& _m = g.ty;
        if (prism_rtl::is<OutTy::OutMap>(_m)) {
            auto&& v_ = prism_rtl::as<OutTy::OutMap>(_m).a1;
            _v.set(v_);
            goto _done;
        }
        {
            _v.set(OutTy(OutTy::OutUnit{}));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto current = Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(field)})), Text("get"), Array(std::vector{Ex(Ex::XCx{})})})), Text("unwrap_or_default"), Array<Ex>{}});
    auto collect = Array(std::vector{Do(Do::DoLet{Pa(Pa::PaMut{Text("all")}), current}), Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text("all")})), Text("insert"), Array(std::vector{Ex(Ex::XVar{Text("k")}), Ex(Ex::XVar{Text("v")})})})}), Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(field)})), Text("set"), Array(std::vector{Ex(Ex::XVar{Text("all")}), Ex(Ex::XCx{})})})})});
    auto body = append(collect, ask_wake(sk, g.height));
    return MethDef{.name = prism_rtl::cat(g.name, "_in"), .recv = Recv(Recv::RecvRc{}), .params = Array(std::vector{std::tuple{Text("k"), kt}, std::tuple{Text("v"), vt}}), .cx_ = CxArg(CxArg::CxMut{}), .ret = OutTy(OutTy::OutUnit{}), .body = body, .tail = Ex(Ex::XUnit{}), .doc = Text("A row's firing, gathered by its key.")};
}


/// Decide: fn Gn -> Do
Do decide(const Gn& g) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Do> _v;
        auto&& _m = g.kind;
        if (prism_rtl::is<GnKind::GnGather>(_m)) {
            _v.set(Do(Do::DoIfLet{Pa(Pa::PaCtor{Text("Some"), Array(std::vector{Pa(Pa::PaBind{Text("v")})})}), Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(or_(index(g.inputs, Nat(0u)), Text("")))})), Text("take"), Array(std::vector{Ex(Ex::XCx{})})}), Array(std::vector{self_call(g.name, Array(std::vector{Ex(Ex::XVar{Text("v")})}))}), Array<Do>{}}));
            goto _done;
        }
        if (prism_rtl::is<GnKind::GnMerge>(_m)) {
            _v.set(merge_decide(g));
            goto _done;
        }
        if (prism_rtl::is<GnKind::GnUpdated>(_m)) {
            _v.set(updated_decide(g));
            goto _done;
        }
        if (prism_rtl::is<GnKind::GnMergeAll>(_m)) {
            _v.set(({
                auto pushes = each(g.inputs, [&](const Text& f) { return Do(Do::DoIfLet{Pa(Pa::PaCtor{Text("Some"), Array(std::vector{Pa(Pa::PaBind{Text("x")})})}), Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(f)})), Text("take"), Array(std::vector{Ex(Ex::XCx{})})}), Array(std::vector{Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text("all")})), Text("push_back"), Array(std::vector{Ex(Ex::XVar{Text("x")})})})})}), Array<Do>{}}); });
                auto start = Do(Do::DoLet{Pa(Pa::PaTyped{prism_rtl::rc(Pa(Pa::PaMut{Text("all")})), g.ty}), Ex(Ex::XCall{Text("Array::new"), Array<Ex>{}})});
                auto fire = Do(Do::DoIf{Ex(Ex::XUnary{Text("!"), prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text("all")})), Text("is_empty"), Array<Ex>{}}))}), Array(std::vector{self_call(g.name, Array(std::vector{Ex(Ex::XVar{Text("all")})}))}), Array<Do>{}});
                (Do(Do::DoIf{Ex(Ex::XBool{true}), prelude::push(append(Array(std::vector{start}), pushes), fire), Array<Do>{}}));
            }));
            goto _done;
        }
        {
            auto&& kind = _m;
            _v.set(pair_decide(g, kind));
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// UpdatedDecide: fn Gn -> Do
Do updated_decide(const Gn& g) {
    return Do(Do::DoIf{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(g.name, "_moved")})), Text("replace"), Array(std::vector{Ex(Ex::XBool{false})})}), Array(std::vector{Do(Do::DoLet{Pa(Pa::PaBind{Text("after")}), Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XCx{})), Text("after"), Array(std::vector{Ex(Ex::XClosure{false, Array(std::vector{Pa(Pa::PaBind{Text("cx")})}), prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(g.name, "_value"), Array(std::vector{Ex(Ex::XCx{})})}))})})})}), self_call(g.name, Array(std::vector{Ex(Ex::XVar{Text("after")})}))}), Array<Do>{}});
}


/// PairDecide: fn Gn, GnKind -> Do
Do pair_decide(const Gn& g, const GnKind& kind) {
    auto get_l = Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(or_(index(g.inputs, Nat(0u)), Text("")))})), Text("take"), Array(std::vector{Ex(Ex::XCx{})})});
    auto get_r = Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(or_(index(g.inputs, Nat(1u)), Text("")))})), Text("take"), Array(std::vector{Ex(Ex::XCx{})})});
    auto both_ = Ex(Ex::XTuple{Array(std::vector{get_l, get_r})});
    auto fire_fn = ({
        auto g_1 = g;
        (prism_rtl::rc([=](const Ex& x) { return Array(std::vector{self_call(g_1.name, Array(std::vector{x}))}); }));
    });
    auto sa = Pa(Pa::PaCtor{Text("Some"), Array(std::vector{Pa(Pa::PaBind{Text("a")})})});
    auto sb = Pa(Pa::PaCtor{Text("Some"), Array(std::vector{Pa(Pa::PaBind{Text("b")})})});
    auto some2 = Pa(Pa::PaTuple{Array(std::vector{sa, sb})});
    auto left = Pa(Pa::PaTuple{Array(std::vector{sa, Pa(Pa::PaUnit{Text("None")})})});
    auto right = Pa(Pa::PaTuple{Array(std::vector{Pa(Pa::PaUnit{Text("None")}), sb})});
    auto cases = ({
        __label__ _done;
        prism_rtl::Slot<Array<std::tuple<Pa, Array<Do>>>> _v;
        if (prism_rtl::is<GnKind::GnUnion>(kind)) {
            _v.set(Array(std::vector{std::tuple{some2, fire_fn(Ex(Ex::XCall{Text("union"), Array(std::vector{Ex(Ex::XRef{prism_rtl::rc(Ex(Ex::XVar{Text("a")}))}), Ex(Ex::XRef{prism_rtl::rc(Ex(Ex::XVar{Text("b")}))})})}))}, std::tuple{left, fire_fn(Ex(Ex::XVar{Text("a")}))}, std::tuple{right, fire_fn(Ex(Ex::XVar{Text("b")}))}, std::tuple{Pa(Pa::PaWild{}), Array<Do>{}}}));
            goto _done;
        }
        if (prism_rtl::is<GnKind::GnBoth>(kind)) {
            _v.set(Array(std::vector{std::tuple{some2, fire_fn(Ex(Ex::XTuple{Array(std::vector{Ex(Ex::XVar{Text("a")}), Ex(Ex::XVar{Text("b")})})}))}, std::tuple{Pa(Pa::PaWild{}), Array<Do>{}}}));
            goto _done;
        }
        {
            _v.set(Array(std::vector{std::tuple{left, fire_fn(Ex(Ex::XVar{Text("a")}))}, std::tuple{Pa(Pa::PaWild{}), Array<Do>{}}}));
            goto _done;
        }
    _done:
        _v.take();
    });
    return Do(Do::DoMatch{both_, cases});
}


/// WakeByHeight: fn [Gn], [Nat] -> Do
Do wake_by_height(const Array<Gn>& combs, const Array<Nat>& heights_) {
    return Do(Do::DoMatch{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), Text("wakes")})), Text("next"), Array<Ex>{}}), prelude::push(each(heights_, [&](const Nat& h) { return std::tuple{Pa(Pa::PaConst{wake_const(heights_, h)}), each(filter(combs, [&](const Gn& g) { return g.height == h; }), [&](const Gn& g) { return decide(g); })}; }), std::tuple{Pa(Pa::PaWild{}), Array<Do>{}})});
}


/// ForwardAnswer: fn ForDef -> Ex
Ex forward_answer(const ForDef& b) {
    auto row_of = Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(b.name)})), Text("borrow"), Array<Ex>{}})), Text("get"), Array(std::vector{Ex(Ex::XRef{prism_rtl::rc(Ex(Ex::XDecode{b.key_ty, prism_rtl::rc(Ex(Ex::XVar{Text("k")}))}))})})})), Text("cloned"), Array<Ex>{}});
    return Ex(Ex::XBlock{Array(std::vector{Do(Do::DoLet{Pa(Pa::PaBind{Text("row")}), row_of}), Do(Do::DoIfLet{Pa(Pa::PaCtor{Text("Some"), Array(std::vector{Pa(Pa::PaBind{Text("row")})})}), Ex(Ex::XVar{Text("row")}), Array(std::vector{Do(Do::DoExpr{try_of(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text("row")})), Text("answer"), Array(std::vector{Ex(Ex::XVar{Text("rest")}), Ex(Ex::XVar{Text("v")}), Ex(Ex::XCx{})})}))})}), Array<Do>{}})}), prism_rtl::rc(Ex(Ex::XUnit{}))});
}


/// IsHold: fn OutTy -> Bool
bool is_hold(const OutTy& out_ty0) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        if (prism_rtl::is<OutTy::OutHold>(out_ty0)) {
            _v.set(true);
            goto _done;
        }
        {
            auto&& other = out_ty0;
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// RowMethods: fn Wx -> [MethDef]
Array<MethDef> row_methods(const Wx& wx) {
    auto removes = each(filter(wx.places, [&](const Place& p_) { return emits(wx, p_.pos); }), [&](const Place& p_) { return Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XCx{})), Text("removed"), Array(std::vector{place_at(wx, Text("self"), p_.pos)})})}); });
    auto nested = append(each(wx.builders, [&](const ForDef& b) { return Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), b.name})), Text("borrow"), Array<Ex>{}})), Text("values"), Array<Ex>{}})), Text("for_each"), Array(std::vector{Ex(Ex::XClosure{false, Array(std::vector{Pa(Pa::PaBind{Text("row")})}), prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text("row")})), Text("leave_row"), Array(std::vector{Ex(Ex::XCx{})})}))})})})}); }), each(wx.gens, [&](const GenDef& gd) { return Do(Do::DoIfLet{Pa(Pa::PaCtor{Text("Some"), Array(std::vector{Pa(Pa::PaBind{Text("row")})})}), Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), gd.name})), Text("borrow"), Array<Ex>{}})), Text("as_ref"), Array<Ex>{}}), Array(std::vector{Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text("row")})), Text("leave_row"), Array(std::vector{Ex(Ex::XCx{})})})})}), Array<Do>{}}); }));
    return Array(std::vector{MethDef{.name = Text("remove_places"), .recv = Recv(Recv::RecvRef{}), .params = Array<std::tuple<Text, OutTy>>{}, .cx_ = CxArg(CxArg::CxMut{}), .ret = OutTy(OutTy::OutUnit{}), .body = append(removes, nested), .tail = Ex(Ex::XUnit{}), .doc = Text("The row left: its places are torn down.")}});
}


/// GnDoc: fn Gn -> Text
Text gn_doc(const Gn& g) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = g.kind;
        if (prism_rtl::is<GnKind::GnAnswer>(_m)) {
            _v.set(prism_rtl::cat("`", g.name, "`: an answer at its place."));
            goto _done;
        }
        if (prism_rtl::is<GnKind::GnStarted>(_m)) {
            _v.set(Text("`@started`, the tick after the build."));
            goto _done;
        }
        if (prism_rtl::is<GnKind::GnDeferred>(_m)) {
            _v.set(Text("An `@Defer` firing, the tick after it was armed."));
            goto _done;
        }
        if (prism_rtl::is<GnKind::GnMerge>(_m)) {
            _v.set(prism_rtl::cat("The merge `", g.name, "`, decided in the wake."));
            goto _done;
        }
        if (prism_rtl::is<GnKind::GnUpdated>(_m)) {
            _v.set(Text("`!Updated`: the dynamic's value after the tick, fired in the wake when a hold it reads was written (or a structural dynamic it reads was published, pick ST)."));
            goto _done;
        }
        {
            _v.set(prism_rtl::cat("`!", g.name, "`."));
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// MergeDecide: fn Gn -> Do
Do merge_decide(const Gn& g) {
    auto call = Array(std::vector{self_call(g.name, Array(std::vector{Ex(Ex::XVar{Text("v")})}))});
    auto take_l = Do(Do::DoLet{Pa(Pa::PaBind{Text("left")}), Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(or_(index(g.inputs, Nat(0u)), Text("")))})), Text("take"), Array(std::vector{Ex(Ex::XCx{})})})});
    auto take_r = Do(Do::DoLet{Pa(Pa::PaBind{Text("right")}), Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(or_(index(g.inputs, Nat(1u)), Text("")))})), Text("take"), Array(std::vector{Ex(Ex::XCx{})})})});
    auto right_1 = Do(Do::DoIfLet{Pa(Pa::PaCtor{Text("Some"), Array(std::vector{Pa(Pa::PaBind{Text("v")})})}), Ex(Ex::XVar{Text("right")}), call, Array<Do>{}});
    return Do(Do::DoIf{Ex(Ex::XBool{true}), Array(std::vector{take_l, take_r, Do(Do::DoIfLet{Pa(Pa::PaCtor{Text("Some"), Array(std::vector{Pa(Pa::PaBind{Text("v")})})}), Ex(Ex::XVar{Text("left")}), call, Array(std::vector{right_1})})}), Array<Do>{}});
}


/// InModule: fn Lx, Nat, Text -> Lx
Lx in_module(const Lx& lx, const Nat& file, const Text& home) {
    Lx this_ = lx;
    this_.file = file;
    this_.home = home;
    this_.site = home;
    return this_;
}


/// InModuleAt: fn Lx, Nat, Text, Text -> Lx
Lx in_module_at(const Lx& lx, const Nat& file, const Text& home, const Text& site) {
    Lx this_ = lx;
    this_.file = file;
    this_.home = home;
    this_.site = site;
    return this_;
}


/// LowerProgram: unbounded fn [Src], [Module], Nat, TProgram, Text -> Model
Model lower_program(const Array<check_errors::Src>& srcs, const Array<ast::Module>& trees, const Nat& shown, const typed::TProgram& tp, const Text& name) {
    auto&& _g = check_env::build_g(srcs, trees);
    auto&& g = std::get<0>(_g);
    auto [tys, apps, bs, ims] = typed_tables(tp);
    auto gens = fold(tp.gens, Map<Text, typed::GenNote>{}, [&](const Map<Text, typed::GenNote>& m, const typed::GenNote& n) { return insert(m, typed::at_key(n.at), n); });
    auto insts = fold(tp.insts, Map<Text, Array<typed::InstNote>>{}, [&](const Map<Text, Array<typed::InstNote>>& m, const typed::InstNote& n) { return insert(m, inst_key(n), prelude::push(or_(prelude::get(m, inst_key(n)), Array<typed::InstNote>{}), n)); });
    auto quants = fold(tp.gens, Map<Text, Text>{}, [&](const Map<Text, Text>& m, const typed::GenNote& n) { return fold(append(n.tys, n.cols), m, [&](const Map<Text, Text>& m2, const Text& q) { return insert(m2, q, n.name); }); });
    auto gen_of_q = fold(tp.gens, Map<Text, typed::GenNote>{}, [&](const Map<Text, typed::GenNote>& m, const typed::GenNote& n) { return fold(append(n.tys, n.cols), m, [&](const Map<Text, typed::GenNote>& m2, const Text& q) { return insert(m2, q, n); }); });
    auto use_insts = fold(tp.insts, Map<Text, typed::InstNote>{}, [&](const Map<Text, typed::InstNote>& m, const typed::InstNote& n) { return insert(m, typed::at_key(n.at), n); });
    auto mods = needed_mods(g, shown);
    auto rs_mods = fold(mods, Map<Text, Text>{}, [&](const Map<Text, Text>& acc, const Text& m) { return insert(acc, m, rust_mod_name(m)); });
    auto lx0 = Lx{.g = g, .tys = tys, .apps = apps, .binders = bs, .impls = ims, .file = Nat(0u), .home = Text(""), .site = Text(""), .rs_mods = rs_mods, .rs_names = value_names(g), .layouts = layouts(g), .unbs = Array<Text>{}, .notes = Array<Text>{}, .globals = global_names(g), .in_node = false, .unshrunk = fold(tp.unshrunk, Map<Text, bool>{}, [&](const Map<Text, bool>& m, const typed::SrcAt& a) { return insert(m, typed::at_key(a), true); }), .gens = gens, .insts = insts, .quants = quants, .gen_of_q = gen_of_q, .use_insts = use_insts, .subst = Map<Text, check_types::Ty>{}, .csubst = Map<Text, check_types::Col>{}};
    auto lx = ({
        Lx this_ = lx0;
        this_.unbs = job_roots(lx0);
        this_;
    });
    auto roots = root_widgets(lx);
    auto mod_defs = run_to_end(each_job(mods, ({
        auto lx_1 = lx;
        auto roots_2 = roots;
        auto g_3 = g;
        auto mods_4 = mods;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<ModDef>(Text)>>(prism_rtl::rc([=](Text p0) {
        return ({
            auto lx_1_5 = lx_1;
            auto roots_2_5 = roots_2;
            auto g_3_5 = g_3;
            auto mods_4_5 = mods_4;
            entered(once_job([=]() {
            return ({
                auto m = p0;
                (prism_rtl::more(prism_rtl::rc(ModDefOf(lx_1_5, m, roots_2_5, or_(prelude::get(g_3_5.mods, m), check_env::dummy_mod()), mods_4_5))));
            });
        }));
        });
    })));
    })));
    auto programs = run_to_end(each_job(roots, ({
        auto lx_1 = lx;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<ProgDef>(std::tuple<Text, bool>)>>(prism_rtl::rc([=](std::tuple<Text, bool> p0) {
        return ({
            auto lx_1_2 = lx_1;
            entered(once_job([=]() {
            return ({
                auto&& _qk = p0;
                auto&& qk = std::get<0>(_qk);
                (prism_rtl::more(prism_rtl::rc(ProgDefOf(lx_1_2, qk))));
            });
        }));
        });
    })));
    })));
    auto main_qk = fold(g.defs, Text(""), [&](const Text& found, const check_env::Def& d) { return (found == Text("")) && is_main(d.qk) ? d.qk : found; });
    auto root_opt = main_qk == Text("")
        ? std::optional<ProgDef>{}
        : std::optional(prog_def_of(lx, main_qk));
    auto checks = run_to_end(fold_job(g.defs, Array<CheckDef>{}, ({
        auto lx_1 = lx;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<CheckDef>>(std::tuple<Array<CheckDef>, check_env::Def>)>>(prism_rtl::rc([=](std::tuple<Array<CheckDef>, check_env::Def> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_1_2 = lx_1;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto d = p1;
                ({
                auto&& _m = d.body;
                prism_rtl::is<check_env::DefBody::DbCheck>(_m) ? ({
                auto&& c = prism_rtl::as<check_env::DefBody::DbCheck>(_m).a0;
                ({
                auto c_2 = c;
                call_then(start_check_def_of(in_module_at(lx_1_2, d->file, d.home, Text("\000main"sv)), c_2), [=](CheckDef check_def_of_317736) { return prism_rtl::finished(prelude::push(acc, check_def_of_317736)); });
            });
            })
                : prism_rtl::finished(acc);
            });
            });
        }));
        });
    })));
    })));
    auto with_needs_ = with_groups(with_needs(g, srcs, tp, mod_defs));
    auto elem = elem_row(lx, mods);
    auto answer = answer_enum(in_module_at(lx, Nat(0u), Text(""), Text("\000main"sv)), mods);
    auto names = each(with_needs_, [&](const ModDef& d) { return d.name; });
    auto value_tys = value_types(with_needs_);
    auto elem_held = fold(elem.cases_, Array<Text>{}, [&](const Array<Text>& acc, const std::tuple<Text, Text>& _p1) {
        auto&& sp = std::get<1>(_p1);
        return check_types::union_texts(acc, held_in(names, value_tys, Text(""), OutTy(OutTy::OutNamed{sp, Array<OutTy>{}})));
    });
    auto answer_held = fold(answer.cases_, elem_held, [&](const Array<Text>& acc, const AnswerCase& k) { return check_types::union_texts(acc, held_in(names, value_tys, Text(""), k.ty)); });
    auto answer_named = fold(answer.cases_, Array<Text>{}, [&](const Array<Text>& acc, const AnswerCase& k) { return check_types::union_texts(acc, named_in(names, Text(""), k.ty)); });
    return Model{.name = name, .mods = with_needs_, .programs = programs, .root = root_opt, .checks = checks, .elem = elem, .answer = answer, .elem_complete = answer_held, .elem_declared = check_types::minus_texts(answer_named, answer_held), .scripts = Array<Text>{}, .notes = Array<Text>{}};
}


prism_rtl::Turn<Model> LowerProgram::cycle() const {
    const auto& srcs = this->srcs;
    const auto& trees = this->trees;
    const auto& shown = this->shown;
    const auto& tp = this->tp;
    const auto& name = this->name;
    auto name_1 = name;
    auto shown_2 = shown;
    auto srcs_3 = srcs;
    auto tp_4 = tp;
    auto trees_5 = trees;
    return call_then(check_env::start_build_g(srcs_3, trees_5), [=](std::tuple<check_env::G, check_types::St> build_g_316245) {
        return ({
            auto&& _g = build_g_316245;
            auto&& g = std::get<0>(_g);
            auto [tys, apps, bs, ims] = typed_tables(tp_4);
            auto gens = fold(tp_4.gens, Map<Text, typed::GenNote>{}, [&](const Map<Text, typed::GenNote>& m, const typed::GenNote& n) { return insert(m, typed::at_key(n.at), n); });
            auto insts = fold(tp_4.insts, Map<Text, Array<typed::InstNote>>{}, [&](const Map<Text, Array<typed::InstNote>>& m, const typed::InstNote& n) { return insert(m, inst_key(n), prelude::push(or_(prelude::get(m, inst_key(n)), Array<typed::InstNote>{}), n)); });
            auto quants = fold(tp_4.gens, Map<Text, Text>{}, [&](const Map<Text, Text>& m, const typed::GenNote& n) { return fold(append(n.tys, n.cols), m, [&](const Map<Text, Text>& m2, const Text& q) { return insert(m2, q, n.name); }); });
            auto gen_of_q = fold(tp_4.gens, Map<Text, typed::GenNote>{}, [&](const Map<Text, typed::GenNote>& m, const typed::GenNote& n) { return fold(append(n.tys, n.cols), m, [&](const Map<Text, typed::GenNote>& m2, const Text& q) { return insert(m2, q, n); }); });
            auto use_insts = fold(tp_4.insts, Map<Text, typed::InstNote>{}, [&](const Map<Text, typed::InstNote>& m, const typed::InstNote& n) { return insert(m, typed::at_key(n.at), n); });
            call_then(start_needed_mods(g, shown_2), [=](Array<Text> needed_mods_316771) {
            return ({
                auto mods = needed_mods_316771;
                auto rs_mods = fold(mods, Map<Text, Text>{}, [&](const Map<Text, Text>& acc, const Text& m) { return insert(acc, m, rust_mod_name(m)); });
                call_then(start_layouts(g), [=](Map<Text, Array<bool>> layouts_317003) {
                return ({
                    auto lx0 = Lx{.g = g, .tys = tys, .apps = apps, .binders = bs, .impls = ims, .file = Nat(0u), .home = Text(""), .site = Text(""), .rs_mods = rs_mods, .rs_names = value_names(g), .layouts = layouts_317003, .unbs = Array<Text>{}, .notes = Array<Text>{}, .globals = global_names(g), .in_node = false, .unshrunk = fold(tp_4.unshrunk, Map<Text, bool>{}, [&](const Map<Text, bool>& m, const typed::SrcAt& a) { return insert(m, typed::at_key(a), true); }), .gens = gens, .insts = insts, .quants = quants, .gen_of_q = gen_of_q, .use_insts = use_insts, .subst = Map<Text, check_types::Ty>{}, .csubst = Map<Text, check_types::Col>{}};
                    auto lx = ({
                        Lx this_ = lx0;
                        this_.unbs = job_roots(lx0);
                        this_;
                    });
                    auto roots = root_widgets(lx);
                    call_value(each_job(mods, ({
                    auto lx_6 = lx;
                    auto roots_7 = roots;
                    auto g_8 = g;
                    auto mods_9 = mods;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<ModDef>(Text)>>(prism_rtl::rc([=](Text p0) {
                    return ({
                        auto lx_6_10 = lx_6;
                        auto roots_7_10 = roots_7;
                        auto g_8_10 = g_8;
                        auto mods_9_10 = mods_9;
                        entered(once_job([=]() {
                        return ({
                            auto m = p0;
                            (prism_rtl::more(prism_rtl::rc(ModDefOf(lx_6_10, m, roots_7_10, or_(prelude::get(g_8_10.mods, m), check_env::dummy_mod()), mods_9_10))));
                        });
                    }));
                    });
                })));
                })), [=](Array<ModDef> each_317345) {
                    return ({
                        auto mod_defs = each_317345;
                        call_value(each_job(roots, ({
                        auto lx_6 = lx;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<ProgDef>(std::tuple<Text, bool>)>>(prism_rtl::rc([=](std::tuple<Text, bool> p0) {
                        return ({
                            auto lx_6_7 = lx_6;
                            entered(once_job([=]() {
                            return ({
                                auto&& _qk = p0;
                                auto&& qk = std::get<0>(_qk);
                                (prism_rtl::more(prism_rtl::rc(ProgDefOf(lx_6_7, qk))));
                            });
                        }));
                        });
                    })));
                    })), [=](Array<ProgDef> each_317434) {
                        return ({
                            auto programs = each_317434;
                            auto main_qk = fold(g.defs, Text(""), [&](const Text& found, const check_env::Def& d) { return (found == Text("")) && is_main(d.qk) ? d.qk : found; });
                            auto root_opt = main_qk == Text("")
                                ? std::optional<ProgDef>{}
                                : std::optional(prog_def_of(lx, main_qk));
                            call_value(fold_job(g.defs, Array<CheckDef>{}, ({
                            auto lx_6 = lx;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<CheckDef>>(std::tuple<Array<CheckDef>, check_env::Def>)>>(prism_rtl::rc([=](std::tuple<Array<CheckDef>, check_env::Def> _p0) {
                            auto&& p0 = std::get<0>(_p0);
                            auto&& p1 = std::get<1>(_p0);
                            return ({
                                auto lx_6_7 = lx_6;
                                entered(once_job([=]() {
                                return ({
                                    auto acc = p0;
                                    auto d = p1;
                                    ({
                                    auto&& _m = d.body;
                                    prism_rtl::is<check_env::DefBody::DbCheck>(_m) ? ({
                                    auto&& c = prism_rtl::as<check_env::DefBody::DbCheck>(_m).a0;
                                    ({
                                    auto c_7 = c;
                                    call_then(start_check_def_of(in_module_at(lx_6_7, d->file, d.home, Text("\000main"sv)), c_7), [=](CheckDef check_def_of_317736) { return prism_rtl::finished(prelude::push(acc, check_def_of_317736)); });
                                });
                                })
                                    : prism_rtl::finished(acc);
                                });
                                });
                            }));
                            });
                        })));
                        })), [=](Array<CheckDef> fold_317663) {
                            return ({
                                auto checks = fold_317663;
                                call_then(start_with_needs(g, srcs_3, tp_4, mod_defs), [=](Array<ModDef> with_needs_317851) {
                                return call_then(start_with_groups(with_needs_317851), [=](Array<ModDef> with_groups_317839) {
                                    return ({
                                        auto with_needs_ = with_groups_317839;
                                        call_then(start_elem_row(lx, mods), [=](RowDef elem_row_317898) {
                                        return ({
                                            auto elem = elem_row_317898;
                                            call_then(start_answer_enum(in_module_at(lx, Nat(0u), Text(""), Text("\000main"sv)), mods), [=](AnswerDef answer_enum_317932) {
                                            return ({
                                                auto answer = answer_enum_317932;
                                                auto names = each(with_needs_, [&](const ModDef& d) { return d.name; });
                                                auto value_tys = value_types(with_needs_);
                                                auto elem_held = fold(elem.cases_, Array<Text>{}, [&](const Array<Text>& acc, const std::tuple<Text, Text>& _p1) {
                                                    auto&& sp = std::get<1>(_p1);
                                                    return check_types::union_texts(acc, held_in(names, value_tys, Text(""), OutTy(OutTy::OutNamed{sp, Array<OutTy>{}})));
                                                });
                                                auto answer_held = fold(answer.cases_, elem_held, [&](const Array<Text>& acc, const AnswerCase& k) { return check_types::union_texts(acc, held_in(names, value_tys, Text(""), k.ty)); });
                                                auto answer_named = fold(answer.cases_, Array<Text>{}, [&](const Array<Text>& acc, const AnswerCase& k) { return check_types::union_texts(acc, named_in(names, Text(""), k.ty)); });
                                                (prism_rtl::finished(Model{.name = name_1, .mods = with_needs_, .programs = programs, .root = root_opt, .checks = checks, .elem = elem, .answer = answer, .elem_complete = answer_held, .elem_declared = check_types::minus_texts(answer_named, answer_held), .scripts = Array<Text>{}, .notes = Array<Text>{}}));
                                            });
                                        });
                                        });
                                    });
                                    });
                                });
                            });
                            });
                        });
                        });
                    });
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start LowerProgram, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Model> start_lower_program(Array<check_errors::Src> srcs, Array<ast::Module> trees, Nat shown, typed::TProgram tp, Text name) {
    return std::make_shared<LowerProgram>(srcs, trees, shown, tp, name);
}


/// WithNeeds: unbounded fn G, [Src], TProgram, [ModDef] -> [ModDef]
Array<ModDef> with_needs(const check_env::G& g, const Array<check_errors::Src>& srcs, const typed::TProgram& tp, const Array<ModDef>& defs) {
    auto names = each(defs, [&](const ModDef& d) { return d.name; });
    auto value_tys = value_types(defs);
    auto refs = named_mods(g, srcs, tp, each(defs, [&](const ModDef& d) { return d.prism; }));
    return run_to_end(each_job(defs, ({
        auto names_1 = names;
        auto value_tys_2 = value_tys;
        auto refs_3 = refs;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<ModDef>(ModDef)>>(prism_rtl::rc([=](ModDef p0) {
        return ({
            auto names_1_4 = names_1;
            auto value_tys_2_4 = value_tys_2;
            auto refs_3_4 = refs_3;
            entered(once_job([=]() {
            return ({
                auto d = p0;
                ({
                auto held = fold(d.items, Array<Text>{}, [&](const Array<Text>& acc, const Item& it) { return check_types::union_texts(acc, item_held(names_1_4, value_tys_2_4, d.name, it)); });
                auto complete = filter(held, [&](const Text& n) { return n != d.name; });
                call_then(start_reached_by(refs_3_4, Array(std::vector{d.prism}), Array<Text>{}), [=](Array<Text> reached_by_319146) {
                return ({
                    auto reached = each(reached_by_319146, [&](const Text& m) { return rust_mod_name(m); });
                    auto declared = filter(names_1_4, [&](const Text& n) { return ((n != d.name) && check_types::has_text(reached, n)) && (!check_types::has_text(complete, n)); });
                    (prism_rtl::finished(({
                    ModDef this_ = d;
                    this_.complete = complete;
                    this_.declared = declared;
                    this_;
                })));
                });
            });
            });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<Array<ModDef>> WithNeeds::cycle() const {
    const auto& g = this->g;
    const auto& srcs = this->srcs;
    const auto& tp = this->tp;
    const auto& defs = this->defs;
    auto names = each(defs, [&](const ModDef& d) { return d.name; });
    auto value_tys = value_types(defs);
    auto defs_1 = defs;
    auto g_2 = g;
    auto srcs_3 = srcs;
    auto tp_4 = tp;
    return call_then(start_named_mods(g_2, srcs_3, tp_4, each(defs_1, [&](const ModDef& d) { return d.prism; })), [=](Map<Text, Array<Text>> named_mods_318891) {
        return ({
            auto refs = named_mods_318891;
            each_job(defs_1, ({
            auto names_5 = names;
            auto value_tys_6 = value_tys;
            auto refs_7 = refs;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<ModDef>(ModDef)>>(prism_rtl::rc([=](ModDef p0) {
            return ({
                auto names_5_8 = names_5;
                auto value_tys_6_8 = value_tys_6;
                auto refs_7_8 = refs_7;
                entered(once_job([=]() {
                return ({
                    auto d = p0;
                    ({
                    auto held = fold(d.items, Array<Text>{}, [&](const Array<Text>& acc, const Item& it) { return check_types::union_texts(acc, item_held(names_5_8, value_tys_6_8, d.name, it)); });
                    auto complete = filter(held, [&](const Text& n) { return n != d.name; });
                    call_then(start_reached_by(refs_7_8, Array(std::vector{d.prism}), Array<Text>{}), [=](Array<Text> reached_by_319146) {
                    return ({
                        auto reached = each(reached_by_319146, [&](const Text& m) { return rust_mod_name(m); });
                        auto declared = filter(names_5_8, [&](const Text& n) { return ((n != d.name) && check_types::has_text(reached, n)) && (!check_types::has_text(complete, n)); });
                        (prism_rtl::finished(({
                        ModDef this_ = d;
                        this_.complete = complete;
                        this_.declared = declared;
                        this_;
                    })));
                    });
                });
                });
                });
            }));
            });
        })));
        }))->cycle();
        });
    });
}


/// `Start WithNeeds, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<ModDef>> start_with_needs(check_env::G g, Array<check_errors::Src> srcs, typed::TProgram tp, Array<ModDef> defs) {
    return std::make_shared<WithNeeds>(g, srcs, tp, defs);
}


/// NamedMods: unbounded fn G, [Src], TProgram, [Text] -> (Text ==> [Text])
Map<Text, Array<Text>> named_mods(const check_env::G& g, const Array<check_errors::Src>& srcs, const typed::TProgram& tp, const Array<Text>& ms) {
    auto by_path = fold(values(g.mods), Map<Text, Text>{}, [&](const Map<Text, Text>& acc, const check_env::ModInfo& info) { return insert(acc, or_(index(srcs, info->file), check_errors::mk_src(Text(""), Text("")))->path_, info.name); });
    auto by_file = fold(values(g.mods), Map<Nat, Text>{}, [&](const Map<Nat, Text>& acc, const check_env::ModInfo& info) { return insert(acc, info->file, info.name); });
    auto solved = fold(tp.impls, Map<Text, Array<Text>>{}, [&](const Map<Text, Array<Text>>& acc, const typed::ImplNote& n) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Map<Text, Array<Text>>> _v;
            auto&& _m = prelude::get(by_file, n.at->file);
            if (prism_rtl::is_some(_m)) {
                auto&& site = prism_rtl::some_of(_m);
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Map<Text, Array<Text>>> _v;
                    auto&& _m = prelude::get(by_path, impl_path(n.how));
                    if (prism_rtl::is_some(_m)) {
                        auto&& home = prism_rtl::some_of(_m);
                        _v.set((home == site) || check_types::has_text(or_(prelude::get(acc, site), Array<Text>{}), home)
                            ? acc
                            : insert(acc, site, prelude::push(or_(prelude::get(acc, site), Array<Text>{}), home)));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(acc);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(acc);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
    return run_to_end(fold_job(ms, Map<Text, Array<Text>>{}, ({
        auto g_1 = g;
        auto srcs_2 = srcs;
        auto ms_3 = ms;
        auto solved_4 = solved;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Array<Text>>>(std::tuple<Map<Text, Array<Text>>, Text>)>>(prism_rtl::rc([=](std::tuple<Map<Text, Array<Text>>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_1_5 = g_1;
            auto srcs_2_5 = srcs_2;
            auto ms_3_5 = ms_3;
            auto solved_4_5 = solved_4;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto m = p1;
                ({
                auto&& _m = prelude::get(g_1_5.mods, m);
                prism_rtl::is_some(_m) ? ({
                auto&& info = prism_rtl::some_of(_m);
                ({
                auto code = lexer::join(filter(split(or_(index(srcs_2_5, info->file), check_errors::mk_src(Text(""), Text("")))->text, Text("\n")), [&](const Text& l) { return !lexer::has_prefix(lexer::trim_start(l), Text("#")); }), Text("\n"));
                auto qualified = filter(ms_3_5, [&](const Text& o) { return ((o != m) && (o != Text(""))) && lexer::contains(code, prism_rtl::cat(o, ".")); });
                call_then(start_mod_refs(g_1_5, m), [=](Array<Text> mod_refs_320793) { return prism_rtl::finished(insert(acc, m, check_types::union_texts(check_types::union_texts(mod_refs_320793, qualified), or_(prelude::get(solved_4_5, m), Array<Text>{})))); });
            });
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(acc)
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    }));
    })));
}


prism_rtl::Turn<Map<Text, Array<Text>>> NamedMods::cycle() const {
    const auto& g = this->g;
    const auto& srcs = this->srcs;
    const auto& tp = this->tp;
    const auto& ms = this->ms;
    auto by_path = fold(values(g.mods), Map<Text, Text>{}, [&](const Map<Text, Text>& acc, const check_env::ModInfo& info) { return insert(acc, or_(index(srcs, info->file), check_errors::mk_src(Text(""), Text("")))->path_, info.name); });
    auto by_file = fold(values(g.mods), Map<Nat, Text>{}, [&](const Map<Nat, Text>& acc, const check_env::ModInfo& info) { return insert(acc, info->file, info.name); });
    auto solved = fold(tp.impls, Map<Text, Array<Text>>{}, [&](const Map<Text, Array<Text>>& acc, const typed::ImplNote& n) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Map<Text, Array<Text>>> _v;
            auto&& _m = prelude::get(by_file, n.at->file);
            if (prism_rtl::is_some(_m)) {
                auto&& site = prism_rtl::some_of(_m);
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Map<Text, Array<Text>>> _v;
                    auto&& _m = prelude::get(by_path, impl_path(n.how));
                    if (prism_rtl::is_some(_m)) {
                        auto&& home = prism_rtl::some_of(_m);
                        _v.set((home == site) || check_types::has_text(or_(prelude::get(acc, site), Array<Text>{}), home)
                            ? acc
                            : insert(acc, site, prelude::push(or_(prelude::get(acc, site), Array<Text>{}), home)));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(acc);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(acc);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
    return fold_job(ms, Map<Text, Array<Text>>{}, ({
        auto g_1 = g;
        auto srcs_2 = srcs;
        auto ms_3 = ms;
        auto solved_4 = solved;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Array<Text>>>(std::tuple<Map<Text, Array<Text>>, Text>)>>(prism_rtl::rc([=](std::tuple<Map<Text, Array<Text>>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_1_5 = g_1;
            auto srcs_2_5 = srcs_2;
            auto ms_3_5 = ms_3;
            auto solved_4_5 = solved_4;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto m = p1;
                ({
                auto&& _m = prelude::get(g_1_5.mods, m);
                prism_rtl::is_some(_m) ? ({
                auto&& info = prism_rtl::some_of(_m);
                ({
                auto code = lexer::join(filter(split(or_(index(srcs_2_5, info->file), check_errors::mk_src(Text(""), Text("")))->text, Text("\n")), [&](const Text& l) { return !lexer::has_prefix(lexer::trim_start(l), Text("#")); }), Text("\n"));
                auto qualified = filter(ms_3_5, [&](const Text& o) { return ((o != m) && (o != Text(""))) && lexer::contains(code, prism_rtl::cat(o, ".")); });
                call_then(start_mod_refs(g_1_5, m), [=](Array<Text> mod_refs_320793) { return prism_rtl::finished(insert(acc, m, check_types::union_texts(check_types::union_texts(mod_refs_320793, qualified), or_(prelude::get(solved_4_5, m), Array<Text>{})))); });
            });
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(acc)
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    }));
    }))->cycle();
}


/// `Start NamedMods, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, Array<Text>>> start_named_mods(check_env::G g, Array<check_errors::Src> srcs, typed::TProgram tp, Array<Text> ms) {
    return std::make_shared<NamedMods>(g, srcs, tp, ms);
}


/// ImplPath: fn Text -> Text
Text impl_path(const Text& how) {
    auto rest = or_(lexer::after_prefix(how, Text("impl ")), or_(lexer::after_prefix(how, Text("derived ")), Text("")));
    auto parts = split(rest, Text(":"));
    return lexer::join(take(parts, lexer::dec(len(parts))), Text(":"));
}


/// ValueTypes: fn [ModDef] -> (Text ==> Bool)
Map<Text, bool> value_types(const Array<ModDef>& defs) {
    return fold(defs, Map<Text, bool>{}, [&](const Map<Text, bool>& acc, const ModDef& d) {
        return fold(d.items, acc, [&](const Map<Text, bool>& a, const Item& it) {
            return ({
                __label__ _done;
                prism_rtl::Slot<Map<Text, bool>> _v;
                if (prism_rtl::is<Item::ItType>(it)) {
                    auto&& t = prism_rtl::as<Item::ItType>(it).a0;
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<Map<Text, bool>> _v;
                        auto&& _m = t.shape;
                        if (prism_rtl::is<TyShape::ShapeChoice>(_m)) {
                            _v.set(a);
                            goto _done;
                        }
                        {
                            _v.set(insert(a, prism_rtl::cat(d.name, "::", t.name), true));
                            goto _done;
                        }
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                if (prism_rtl::is<Item::ItTag>(it)) {
                    auto&& t = prism_rtl::as<Item::ItTag>(it).a0;
                    _v.set(insert(a, prism_rtl::cat(d.name, "::", t.name), true));
                    goto _done;
                }
                {
                    _v.set(a);
                    goto _done;
                }
            _done:
                _v.take();
            });
        });
    });
}


/// ItemHeld: fn [Text], (Text ==> Bool), Text, Item -> [Text]
Array<Text> item_held(const Array<Text>& names, const Map<Text, bool>& value_tys, const Text& home, const Item& it) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Array<Text>> _v;
        if (prism_rtl::is<Item::ItType>(it)) {
            auto&& t = prism_rtl::as<Item::ItType>(it).a0;
            _v.set(fold(t.cases_, Array<Text>{}, [&](const Array<Text>& acc, const CaseDef& c) {
                return fold(c.fields, acc, [&](const Array<Text>& a, const std::tuple<Text, OutTy>& _p1) {
                    auto&& ft = std::get<1>(_p1);
                    return check_types::union_texts(a, held_in(names, value_tys, home, ft));
                });
            }));
            goto _done;
        }
        if (prism_rtl::is<Item::ItTag>(it)) {
            auto&& t = prism_rtl::as<Item::ItTag>(it).a0;
            _v.set(fold(t.fields, Array<Text>{}, [&](const Array<Text>& acc, const std::tuple<Text, Text, OutTy>& _p1) {
                auto&& ft = std::get<2>(_p1);
                return check_types::union_texts(acc, held_in(names, value_tys, home, ft));
            }));
            goto _done;
        }
        if (prism_rtl::is<Item::ItRow>(it)) {
            auto&& r = prism_rtl::as<Item::ItRow>(it).a0;
            _v.set(fold(r.cases_, Array<Text>{}, [&](const Array<Text>& acc, const std::tuple<Text, Text>& _p1) {
                auto&& sp = std::get<1>(_p1);
                return check_types::union_texts(acc, held_in(names, value_tys, home, OutTy(OutTy::OutNamed{sp, Array<OutTy>{}})));
            }));
            goto _done;
        }
        {
            _v.set(Array<Text>{});
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// HeldIn: fn [Text], (Text ==> Bool), Text, OutTy -> [Text]
Array<Text> held_in(const Array<Text>& names, const Map<Text, bool>& value_tys, const Text& home, const OutTy& t) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Array<Text>> _v;
        if (prism_rtl::is<OutTy::OutNamed>(t)) {
            auto&& n = prism_rtl::as<OutTy::OutNamed>(t).a0;
            auto&& args = prism_rtl::as<OutTy::OutNamed>(t).a1;
            _v.set(({
                auto p_ = path_from(names, home, n);
                auto own_ = check_env::has_key(value_tys, p_)
                    ? Array(std::vector{parent_of(p_)})
                    : Array<Text>{};
                fold(args, own_, [&](const Array<Text>& acc, const OutTy& a) { return check_types::union_texts(acc, held_in(names, value_tys, home, a)); });
            }));
            goto _done;
        }
        if (prism_rtl::is<OutTy::OutOpt>(t)) {
            auto&& i = prism_rtl::as<OutTy::OutOpt>(t).a0;
            _v.set(held_in(names, value_tys, home, i));
            goto _done;
        }
        if (prism_rtl::is<OutTy::OutRes>(t)) {
            auto&& i = prism_rtl::as<OutTy::OutRes>(t).a0;
            _v.set(held_in(names, value_tys, home, i));
            goto _done;
        }
        if (prism_rtl::is<OutTy::OutCell>(t)) {
            auto&& i = prism_rtl::as<OutTy::OutCell>(t).a0;
            _v.set(held_in(names, value_tys, home, i));
            goto _done;
        }
        if (prism_rtl::is<OutTy::OutRc>(t)) {
            auto&& i = prism_rtl::as<OutTy::OutRc>(t).a0;
            _v.set(held_in(names, value_tys, home, i));
            goto _done;
        }
        if (prism_rtl::is<OutTy::OutTuple>(t)) {
            auto&& ts = prism_rtl::as<OutTy::OutTuple>(t).a0;
            _v.set(fold(ts, Array<Text>{}, [&](const Array<Text>& acc, const OutTy& a) { return check_types::union_texts(acc, held_in(names, value_tys, home, a)); }));
            goto _done;
        }
        {
            _v.set(Array<Text>{});
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// NamedIn: fn [Text], Text, OutTy -> [Text]
Array<Text> named_in(const Array<Text>& names, const Text& home, const OutTy& t) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Array<Text>> _v;
        if (prism_rtl::is<OutTy::OutNamed>(t)) {
            auto&& n = prism_rtl::as<OutTy::OutNamed>(t).a0;
            auto&& args = prism_rtl::as<OutTy::OutNamed>(t).a1;
            _v.set(({
                auto p_ = path_from(names, home, n);
                auto own_ = check_types::has_text(names, parent_of(p_))
                    ? Array(std::vector{parent_of(p_)})
                    : Array<Text>{};
                fold(args, own_, [&](const Array<Text>& acc, const OutTy& a) { return check_types::union_texts(acc, named_in(names, home, a)); });
            }));
            goto _done;
        }
        if (prism_rtl::is<OutTy::OutOpt>(t)) {
            auto&& i = prism_rtl::as<OutTy::OutOpt>(t).a0;
            _v.set(named_in(names, home, i));
            goto _done;
        }
        if (prism_rtl::is<OutTy::OutRes>(t)) {
            auto&& i = prism_rtl::as<OutTy::OutRes>(t).a0;
            _v.set(named_in(names, home, i));
            goto _done;
        }
        if (prism_rtl::is<OutTy::OutCell>(t)) {
            auto&& i = prism_rtl::as<OutTy::OutCell>(t).a0;
            _v.set(named_in(names, home, i));
            goto _done;
        }
        if (prism_rtl::is<OutTy::OutArray>(t)) {
            auto&& i = prism_rtl::as<OutTy::OutArray>(t).a0;
            _v.set(named_in(names, home, i));
            goto _done;
        }
        if (prism_rtl::is<OutTy::OutRc>(t)) {
            auto&& i = prism_rtl::as<OutTy::OutRc>(t).a0;
            _v.set(named_in(names, home, i));
            goto _done;
        }
        if (prism_rtl::is<OutTy::OutEvent>(t)) {
            auto&& i = prism_rtl::as<OutTy::OutEvent>(t).a0;
            _v.set(named_in(names, home, i));
            goto _done;
        }
        if (prism_rtl::is<OutTy::OutDyn>(t)) {
            auto&& i = prism_rtl::as<OutTy::OutDyn>(t).a0;
            _v.set(named_in(names, home, i));
            goto _done;
        }
        if (prism_rtl::is<OutTy::OutMap>(t)) {
            auto&& k = prism_rtl::as<OutTy::OutMap>(t).a0;
            auto&& v_ = prism_rtl::as<OutTy::OutMap>(t).a1;
            _v.set(check_types::union_texts(named_in(names, home, k), named_in(names, home, v_)));
            goto _done;
        }
        if (prism_rtl::is<OutTy::OutTuple>(t)) {
            auto&& ts = prism_rtl::as<OutTy::OutTuple>(t).a0;
            _v.set(fold(ts, Array<Text>{}, [&](const Array<Text>& acc, const OutTy& a) { return check_types::union_texts(acc, named_in(names, home, a)); }));
            goto _done;
        }
        if (prism_rtl::is<OutTy::OutFn>(t)) {
            auto&& ps = prism_rtl::as<OutTy::OutFn>(t).a0;
            auto&& r = prism_rtl::as<OutTy::OutFn>(t).a1;
            _v.set(fold(ps, named_in(names, home, r), [&](const Array<Text>& acc, const OutTy& a) { return check_types::union_texts(acc, named_in(names, home, a)); }));
            goto _done;
        }
        {
            _v.set(Array<Text>{});
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// PathFrom: fn [Text], Text, Text -> Text
Text path_from(const Array<Text>& names, const Text& home, const Text& n) {
    auto q = lexer::drop_prefix(n, Text("crate::"));
    return check_types::has_text(names, or_(index(split(q, Text("::")), Nat(0u)), Text("")))
        ? q
        : home == Text("") ? q : prism_rtl::cat(home, "::", q);
}


/// ParentOf: fn Text -> Text
Text parent_of(const Text& p_) {
    auto segs = split(p_, Text("::"));
    return lexer::join(take(segs, lexer::dec(len(segs))), Text("::"));
}


/// WithGroups: unbounded fn [ModDef] -> [ModDef]
Array<ModDef> with_groups(const Array<ModDef>& defs) {
    auto edges = fold(defs, Map<Text, Array<Text>>{}, [&](const Map<Text, Array<Text>>& m, const ModDef& d) { return insert(m, d.name, d.complete); });
    auto reach = run_to_end(fold_job(defs, Map<Text, Array<Text>>{}, ({
        auto edges_1 = edges;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Array<Text>>>(std::tuple<Map<Text, Array<Text>>, ModDef>)>>(prism_rtl::rc([=](std::tuple<Map<Text, Array<Text>>, ModDef> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto edges_1_2 = edges_1;
            entered(once_job([=]() {
            return ({
                auto m = p0;
                auto d = p1;
                call_then(start_reached_by(edges_1_2, Array(std::vector{d.name}), Array<Text>{}), [=](Array<Text> reached_by_324862) { return prism_rtl::finished(insert(m, d.name, reached_by_324862)); });
            });
        }));
        });
    }));
    })));
    return each(defs, [&](const ModDef& d) {
        return ({
            auto mine = or_(prelude::get(reach, d.name), Array<Text>{});
            ({
            ModDef this_ = d;
            this_.types_with = filter(each(defs, [&](const ModDef& o) { return o.name; }), [&](const Text& n) { return (n == d.name) || (check_types::has_text(mine, n) && check_types::has_text(or_(prelude::get(reach, n), Array<Text>{}), d.name)); });
            this_;
        });
        });
    });
}


prism_rtl::Turn<Array<ModDef>> WithGroups::cycle() const {
    const auto& defs = this->defs;
    auto edges = fold(defs, Map<Text, Array<Text>>{}, [&](const Map<Text, Array<Text>>& m, const ModDef& d) { return insert(m, d.name, d.complete); });
    auto defs_1 = defs;
    return call_value(fold_job(defs_1, Map<Text, Array<Text>>{}, ({
        auto edges_2 = edges;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Array<Text>>>(std::tuple<Map<Text, Array<Text>>, ModDef>)>>(prism_rtl::rc([=](std::tuple<Map<Text, Array<Text>>, ModDef> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto edges_2_3 = edges_2;
            entered(once_job([=]() {
            return ({
                auto m = p0;
                auto d = p1;
                call_then(start_reached_by(edges_2_3, Array(std::vector{d.name}), Array<Text>{}), [=](Array<Text> reached_by_324862) { return prism_rtl::finished(insert(m, d.name, reached_by_324862)); });
            });
        }));
        });
    }));
    })), [=](Map<Text, Array<Text>> fold_324820) {
        return ({
            auto reach = fold_324820;
            (prism_rtl::finished(each(defs_1, [&](const ModDef& d) {
            return ({
                auto mine = or_(prelude::get(reach, d.name), Array<Text>{});
                ({
                ModDef this_ = d;
                this_.types_with = filter(each(defs_1, [&](const ModDef& o) { return o.name; }), [&](const Text& n) { return (n == d.name) || (check_types::has_text(mine, n) && check_types::has_text(or_(prelude::get(reach, n), Array<Text>{}), d.name)); });
                this_;
            });
            });
        })));
        });
    });
}


/// `Start WithGroups, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<ModDef>> start_with_groups(Array<ModDef> defs) {
    return std::make_shared<WithGroups>(defs);
}


/// ReachedBy: unbounded fn (Text ==> [Text]), [Text], [Text] -> [Text]
Array<Text> reached_by(const Map<Text, Array<Text>>& edges, const Array<Text>& todo, const Array<Text>& seen) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Array<Text>> _v;
        auto&& _m = index(todo, Nat(0u));
        if (prism_rtl::is_none(_m)) {
            _v.set(seen);
            goto _done;
        }
        if (prism_rtl::is_some(_m)) {
            auto&& m = prism_rtl::some_of(_m);
            _v.set(check_types::has_text(seen, m)
                ? reached_by(edges, drop(todo, Nat(1u)), seen)
                : reached_by(edges, append(drop(todo, Nat(1u)), or_(prelude::get(edges, m), Array<Text>{})), prelude::push(seen, m)));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Array<Text>> ReachedBy::cycle() const {
    const auto& edges = this->edges;
    const auto& todo = this->todo;
    const auto& seen = this->seen;
    return ({
        auto&& _m = index(todo, Nat(0u));
        prism_rtl::is_none(_m) ? prism_rtl::finished(seen)
        : prism_rtl::is_some(_m) ? ({
        auto&& m = prism_rtl::some_of(_m);
        check_types::has_text(seen, m)
        ? prism_rtl::more(prism_rtl::rc(ReachedBy(edges, drop(todo, Nat(1u)), seen)))
        : prism_rtl::more(prism_rtl::rc(ReachedBy(edges, append(drop(todo, Nat(1u)), or_(prelude::get(edges, m), Array<Text>{})), prelude::push(seen, m))));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ReachedBy, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_reached_by(Map<Text, Array<Text>> edges, Array<Text> todo, Array<Text> seen) {
    return std::make_shared<ReachedBy>(edges, todo, seen);
}


/// NeededMods: unbounded fn G, Nat -> [Text]
Array<Text> needed_mods(const check_env::G& g, const Nat& shown) {
    auto own_ = filter(keys(g.mods), [&](const Text& m) { return (or_(prelude::get(g.mods, m), check_env::dummy_mod())->file < shown) && (m != Text("Prelude")); });
    auto grown = run_to_end(fold_job(check_errors::range0(Nat(6u)), own_, ({
        auto g_1 = g;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Nat>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_1_2 = g_1;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                static_cast<void>(p1);
                fold_job(acc, acc, ({
                auto g_1_2_2 = g_1_2;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Text>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, Text> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto g_1_2_2_2 = g_1_2_2;
                    entered(once_job([=]() {
                    return ({
                        auto a = p0;
                        auto m = p1;
                        call_then(start_mod_refs(g_1_2_2_2, m), [=](Array<Text> mod_refs_325885) { return prism_rtl::finished(check_types::union_texts(a, mod_refs_325885)); });
                    });
                }));
                });
            })));
            }))->cycle();
            });
        }));
        });
    })));
    })));
    return filter(keys(g.mods), [&](const Text& m) { return (m != Text("Prelude")) && check_types::has_text(grown, m); });
}


prism_rtl::Turn<Array<Text>> NeededMods::cycle() const {
    const auto& g = this->g;
    const auto& shown = this->shown;
    auto own_ = filter(keys(g.mods), [&](const Text& m) { return (or_(prelude::get(g.mods, m), check_env::dummy_mod())->file < shown) && (m != Text("Prelude")); });
    auto g_1 = g;
    return call_value(fold_job(check_errors::range0(Nat(6u)), own_, ({
        auto g_1_2 = g_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Nat>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_1_2_2 = g_1_2;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                static_cast<void>(p1);
                fold_job(acc, acc, ({
                auto g_1_2_2_2 = g_1_2_2;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Text>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, Text> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto g_1_2_2_2_2 = g_1_2_2_2;
                    entered(once_job([=]() {
                    return ({
                        auto a = p0;
                        auto m = p1;
                        call_then(start_mod_refs(g_1_2_2_2_2, m), [=](Array<Text> mod_refs_325885) { return prism_rtl::finished(check_types::union_texts(a, mod_refs_325885)); });
                    });
                }));
                });
            })));
            }))->cycle();
            });
        }));
        });
    })));
    })), [=](Array<Text> fold_325810) {
        return ({
            auto grown = fold_325810;
            (prism_rtl::finished(filter(keys(g_1.mods), [&](const Text& m) { return (m != Text("Prelude")) && check_types::has_text(grown, m); })));
        });
    });
}


/// `Start NeededMods, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_needed_mods(check_env::G g, Nat shown) {
    return std::make_shared<NeededMods>(g, shown);
}


/// ModRefs: unbounded fn G, Text -> [Text]
Array<Text> mod_refs(const check_env::G& g, const Text& m) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Array<Text>> _v;
        auto&& _m = prelude::get(g.mods, m);
        if (prism_rtl::is_some(_m)) {
            auto&& info = prism_rtl::some_of(_m);
            _v.set(({
                auto used = each(info.uses, [&](const std::tuple<Text, bool>& _p0) {
                    auto&& u = std::get<0>(_p0);
                    return u;
                });
                auto fams = ({
                    __label__ _done;
                    prism_rtl::Slot<Array<Text>> _v;
                    auto&& _m = info.tree.emit_row;
                    if (prism_rtl::is_some(_m)) {
                        auto&& rw = prism_rtl::some_of(_m);
                        _v.set(fold(rw.terms, Array<Text>{}, [&](const Array<Text>& acc, const ast::RowTerm& t) {
                            return ({
                                __label__ _done;
                                prism_rtl::Slot<Array<Text>> _v;
                                if (prism_rtl::is<ast::RowTerm::RFamily>(t)) {
                                    auto&& q = prism_rtl::as<ast::RowTerm::RFamily>(t).a0;
                                    _v.set(prelude::push(acc, or_(prelude::get(g.fam_owner, check_env::dotted(q->path_)), check_env::dotted(q->path_))));
                                    goto _done;
                                }
                                {
                                    _v.set(acc);
                                    goto _done;
                                }
                            _done:
                                _v.take();
                            });
                        }));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(Array<Text>{});
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                filter(append(used, fams), [&](const Text& x) { return check_env::has_key(g.mods, x); });
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Array<Text>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Array<Text>> ModRefs::cycle() const {
    const auto& g = this->g;
    const auto& m = this->m;
    return ({
        auto&& _m = prelude::get(g.mods, m);
        prism_rtl::is_some(_m) ? ({
        auto&& info = prism_rtl::some_of(_m);
        ({
        auto used = each(info.uses, [&](const std::tuple<Text, bool>& _p0) {
            auto&& u = std::get<0>(_p0);
            return u;
        });
        auto fams = ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = info.tree.emit_row;
            if (prism_rtl::is_some(_m)) {
                auto&& rw = prism_rtl::some_of(_m);
                _v.set(fold(rw.terms, Array<Text>{}, [&](const Array<Text>& acc, const ast::RowTerm& t) {
                    return ({
                        __label__ _done;
                        prism_rtl::Slot<Array<Text>> _v;
                        if (prism_rtl::is<ast::RowTerm::RFamily>(t)) {
                            auto&& q = prism_rtl::as<ast::RowTerm::RFamily>(t).a0;
                            _v.set(prelude::push(acc, or_(prelude::get(g.fam_owner, check_env::dotted(q->path_)), check_env::dotted(q->path_))));
                            goto _done;
                        }
                        {
                            _v.set(acc);
                            goto _done;
                        }
                    _done:
                        _v.take();
                    });
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(Array<Text>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        (prism_rtl::finished(filter(append(used, fams), [&](const Text& x) { return check_env::has_key(g.mods, x); })));
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(Array<Text>{})
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ModRefs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_mod_refs(check_env::G g, Text m) {
    return std::make_shared<ModRefs>(g, m);
}


/// RootWidgets: fn Lx -> [((Text, Bool))]
Array<std::tuple<Text, bool>> root_widgets(const Lx& lx) {
    auto tested = fold(lx.g.defs, Array<std::tuple<Text, bool>>{}, [&](const Array<std::tuple<Text, bool>>& acc, const check_env::Def& d) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<std::tuple<Text, bool>>> _v;
            auto&& _m = d.body;
            if (prism_rtl::is<check_env::DefBody::DbTest>(_m)) {
                auto&& t = prism_rtl::as<check_env::DefBody::DbTest>(_m).a0;
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Array<std::tuple<Text, bool>>> _v;
                    auto&& _m = blueprint_qk(in_module(lx, d->file, d.home), t.blueprint);
                    {
                        auto&& m326639_0 = _m;
                        if (m326639_0 == Text("")) {
                            _v.set(acc);
                            goto _done;
                        }
                    }
                    {
                        auto&& qk = _m;
                        _v.set(check_types::has_text(each(acc, [&](const std::tuple<Text, bool>& _p0) {
                            auto&& q = std::get<0>(_p0);
                            return q;
                        }), qk)
                            ? acc
                            : prelude::push(acc, std::tuple{qk, true}));
                        goto _done;
                    }
                _done:
                    _v.take();
                }));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto main = fold(lx.g.defs, Array<std::tuple<Text, bool>>{}, [&](const Array<std::tuple<Text, bool>>& acc, const check_env::Def& d) { return is_main(d.qk) ? prelude::push(acc, std::tuple{d.qk, false}) : acc; });
    return fold(main, tested, [&](const Array<std::tuple<Text, bool>>& acc, const std::tuple<Text, bool>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& b = std::get<1>(_p1);
        return check_types::has_text(each(acc, [&](const std::tuple<Text, bool>& _p0) {
            auto&& q = std::get<0>(_p0);
            return q;
        }), k)
            ? acc
            : prelude::push(acc, std::tuple{k, b});
    });
}


/// IsMain: fn Text -> Bool
bool is_main(const Text& qk) {
    return ((owner_of(qk) == Text("")) && (base(check_types::bare_name(qk)) == Text("main"))) && lexer::has_prefix(check_types::bare_name(qk), Text("@"));
}


/// BlueprintQk: fn Lx, Expr -> Text
Text blueprint_qk(const Lx& lx, const ast::Expr& e) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = e.kind;
        if (prism_rtl::is<ast::ExprKind::ECall>(_m)) {
            auto&& c = prism_rtl::as<ast::ExprKind::ECall>(_m).a0;
            _v.set(blueprint_qk(lx, c));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EGroup>(_m)) {
            auto&& x = prism_rtl::as<ast::ExprKind::EGroup>(_m).a0;
            _v.set(blueprint_qk(lx, x));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
            auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
            _v.set(({
                auto&& _q_opt = check_env::resolve_value(lx.g, lx.home, n);
                auto&& q_opt = std::get<0>(_q_opt);
                or_(q_opt, Text(""));
            }));
            goto _done;
        }
        {
            _v.set(Text(""));
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// ValOf: fn Lx, Text -> ValInfo
check_env::ValInfo val_of(const Lx& lx, const Text& qk) {
    return ({
        __label__ _done;
        prism_rtl::Slot<check_env::ValInfo> _v;
        auto&& _m = prelude::get(lx.g.vals, qk);
        if (prism_rtl::is_some(_m)) {
            auto&& v_ = prism_rtl::some_of(_m);
            _v.set(v_);
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(({
                auto d = fold(lx.g.defs, check_env::dummy_def(), [&](const check_env::Def& found, const check_env::Def& df) { return df.qk == qk ? df : found; });
                check_env::ValInfo{.qk = qk, .scheme = check_types::mono(check_types::Ty(check_types::Ty::TyErr{})), .sort = Text("fn"), .has_sig = false, .home = d.home, .file = d->file, .span = d.span};
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// ProgDefOf: unbounded fn Lx, Text -> ProgDef
ProgDef prog_def_of(const Lx& lx, const Text& qk) {
    auto v_ = val_of(lx, qk);
    auto ptys = ({
        __label__ _done;
        prism_rtl::Slot<Array<check_types::Ty>> _v;
        auto&& _m = v_.scheme.ty;
        if (prism_rtl::is<check_types::Ty::TyFn>(_m)) {
            auto&& ps = prism_rtl::as<check_types::Ty::TyFn>(_m).a1;
            _v.set(ps);
            goto _done;
        }
        {
            _v.set(Array<check_types::Ty>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto lxm = in_module_at(lx, v_->file, v_.home, Text("\000main"sv));
    auto params = run_to_end(each_job(check_errors::range0(len(ptys)), ({
        auto lxm_1 = lxm;
        auto ptys_2 = ptys;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, OutTy>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto lxm_1_3 = lxm_1;
            auto ptys_2_3 = ptys_2;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                call_then(start_out_ty_of(lxm_1_3, peel(or_(index(ptys_2_3, i), check_types::Ty(check_types::Ty::TyErr{})))), [=](OutTy out_ty_of_328214) { return prism_rtl::finished(std::tuple{prism_rtl::cat("arg", i), out_ty_of_328214}); });
            });
        }));
        });
    }));
    })));
    auto node_ = prism_rtl::cat(rust_mod_name(v_.home), "::", camel(check_types::bare_name(qk)));
    auto fams = or_(prelude::get(lx.g.mods, v_.home), check_env::dummy_mod()).emit_rw.fams;
    auto world = check_types::has_text(fams, Text("Gui"))
        ? Text("canvas")
        : check_types::has_text(fams, Text("Ui")) ? Text("none") : Text("cli");
    return ProgDef{.name = prism_rtl::cat(camel(check_types::bare_name(qk)), "Program"), .prism = lexer::after_first(check_types::bare_name(qk)), .node_ = node_, .params = params, .fallible = true, .world = world};
}


prism_rtl::Turn<ProgDef> ProgDefOf::cycle() const {
    const auto& lx = this->lx;
    const auto& qk = this->qk;
    auto v_ = val_of(lx, qk);
    auto ptys = ({
        __label__ _done;
        prism_rtl::Slot<Array<check_types::Ty>> _v;
        auto&& _m = v_.scheme.ty;
        if (prism_rtl::is<check_types::Ty::TyFn>(_m)) {
            auto&& ps = prism_rtl::as<check_types::Ty::TyFn>(_m).a1;
            _v.set(ps);
            goto _done;
        }
        {
            _v.set(Array<check_types::Ty>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto lxm = in_module_at(lx, v_->file, v_.home, Text("\000main"sv));
    auto lx_1 = lx;
    auto qk_2 = qk;
    return call_value(each_job(check_errors::range0(len(ptys)), ({
        auto lxm_3 = lxm;
        auto ptys_4 = ptys;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, OutTy>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto lxm_3_5 = lxm_3;
            auto ptys_4_5 = ptys_4;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                call_then(start_out_ty_of(lxm_3_5, peel(or_(index(ptys_4_5, i), check_types::Ty(check_types::Ty::TyErr{})))), [=](OutTy out_ty_of_328214) { return prism_rtl::finished(std::tuple{prism_rtl::cat("arg", i), out_ty_of_328214}); });
            });
        }));
        });
    }));
    })), [=](Array<std::tuple<Text, OutTy>> each_328170) {
        return ({
            auto params = each_328170;
            auto node_ = prism_rtl::cat(rust_mod_name(v_.home), "::", camel(check_types::bare_name(qk_2)));
            auto fams = or_(prelude::get(lx_1.g.mods, v_.home), check_env::dummy_mod()).emit_rw.fams;
            auto world = check_types::has_text(fams, Text("Gui"))
                ? Text("canvas")
                : check_types::has_text(fams, Text("Ui")) ? Text("none") : Text("cli");
            (prism_rtl::finished(ProgDef{.name = prism_rtl::cat(camel(check_types::bare_name(qk_2)), "Program"), .prism = lexer::after_first(check_types::bare_name(qk_2)), .node_ = node_, .params = params, .fallible = true, .world = world}));
        });
    });
}


/// `Start ProgDefOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<ProgDef> start_prog_def_of(Lx lx, Text qk) {
    return std::make_shared<ProgDefOf>(lx, qk);
}


/// JobRoots: unbounded fn Lx -> [Text]
Array<Text> job_roots(const Lx& lx) {
    auto direct = run_to_end(fold_job(lx.g.defs, Array<Text>{}, ({
        auto lx_1 = lx;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, check_env::Def>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, check_env::Def> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_1_2 = lx_1;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto d = p1;
                ({
                auto lxd = in_module(lx_1_2, d->file, d.home);
                call_then(start_run_targets(lxd, d), [=](Array<Text> run_targets_329049) { return call_then(start_unbounded_values(lxd, d), [=](Array<Text> unbounded_values_329071) { return prism_rtl::finished(check_types::union_texts(check_types::union_texts(acc, run_targets_329049), unbounded_values_329071)); }); });
            });
            });
        }));
        });
    })));
    })));
    return run_to_end(fold_job(check_errors::range0(Nat(8u)), direct, ({
        auto lx_1 = lx;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Nat>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_1_2 = lx_1;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                static_cast<void>(p1);
                fold_job(acc, acc, ({
                auto lx_1_2_2 = lx_1_2;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Text>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, Text> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto lx_1_2_2_2 = lx_1_2_2;
                    entered(once_job([=]() {
                    return ({
                        auto a = p0;
                        auto qk = p1;
                        call_then(start_tail_targets(lx_1_2_2_2, qk), [=](Array<Text> tail_targets_329178) { return prism_rtl::finished(check_types::union_texts(a, tail_targets_329178)); });
                    });
                }));
                });
            })));
            }))->cycle();
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<Array<Text>> JobRoots::cycle() const {
    const auto& lx = this->lx;
    auto lx_1 = lx;
    return call_value(fold_job(lx_1.g.defs, Array<Text>{}, ({
        auto lx_1_2 = lx_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, check_env::Def>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, check_env::Def> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_1_2_2 = lx_1_2;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto d = p1;
                ({
                auto lxd = in_module(lx_1_2_2, d->file, d.home);
                call_then(start_run_targets(lxd, d), [=](Array<Text> run_targets_329049) { return call_then(start_unbounded_values(lxd, d), [=](Array<Text> unbounded_values_329071) { return prism_rtl::finished(check_types::union_texts(check_types::union_texts(acc, run_targets_329049), unbounded_values_329071)); }); });
            });
            });
        }));
        });
    })));
    })), [=](Array<Text> fold_328934) {
        return ({
            auto direct = fold_328934;
            fold_job(check_errors::range0(Nat(8u)), direct, ({
            auto lx_1_2 = lx_1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Nat>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, Nat> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto lx_1_2_2 = lx_1_2;
                entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    static_cast<void>(p1);
                    fold_job(acc, acc, ({
                    auto lx_1_2_2_2 = lx_1_2_2;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Text>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, Text> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto lx_1_2_2_2_2 = lx_1_2_2_2;
                        entered(once_job([=]() {
                        return ({
                            auto a = p0;
                            auto qk = p1;
                            call_then(start_tail_targets(lx_1_2_2_2_2, qk), [=](Array<Text> tail_targets_329178) { return prism_rtl::finished(check_types::union_texts(a, tail_targets_329178)); });
                        });
                    }));
                    });
                })));
                }))->cycle();
                });
            }));
            });
        })));
        }))->cycle();
        });
    });
}


/// `Start JobRoots, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_job_roots(Lx lx) {
    return std::make_shared<JobRoots>(lx);
}


/// UnboundedValues: unbounded fn Lx, Def -> [Text]
Array<Text> unbounded_values(const Lx& lx, const check_env::Def& d) {
    auto es = ({
        __label__ _done;
        prism_rtl::Slot<Array<ast::Expr>> _v;
        auto&& _m = d.body;
        if (prism_rtl::is<check_env::DefBody::DbWidget>(_m)) {
            auto&& w = prism_rtl::as<check_env::DefBody::DbWidget>(_m).a0;
            _v.set(typed::block_exprs(w.body));
            goto _done;
        }
        if (prism_rtl::is<check_env::DefBody::DbFn>(_m)) {
            auto&& cs = prism_rtl::as<check_env::DefBody::DbFn>(_m).a0;
            _v.set(run_to_end(fold_job(cs, Array<ast::Expr>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<ast::Expr>>(std::tuple<Array<ast::Expr>, ast::FnClause>)>>(prism_rtl::rc([=](std::tuple<Array<ast::Expr>, ast::FnClause> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return entered(once_job([=]() {
                    return ({
                        auto acc = p0;
                        auto c = p1;
                        call_then(typed::start_body_exprs(c.body), [=](Array<ast::Expr> body_exprs_329527) { return prism_rtl::finished(append(acc, body_exprs_329527)); });
                    });
                }));
            })))));
            goto _done;
        }
        if (prism_rtl::is<check_env::DefBody::DbLet>(_m)) {
            auto&& l = prism_rtl::as<check_env::DefBody::DbLet>(_m).a0;
            _v.set(typed::exprs_in(l->value));
            goto _done;
        }
        {
            _v.set(Array<ast::Expr>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto callees = fold(es, Array<Text>{}, [&](const Array<Text>& acc, const ast::Expr& e) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = e.kind;
            if (prism_rtl::is<ast::ExprKind::ECall>(_m)) {
                auto&& c = prism_rtl::as<ast::ExprKind::ECall>(_m).a0;
                _v.set(prelude::push(acc, place_key(lx, c.span)));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    return fold(es, Array<Text>{}, [&](const Array<Text>& acc, const ast::Expr& e) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = e.kind;
            if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
                auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
                _v.set(check_types::has_text(callees, place_key(lx, e.span))
                    ? acc
                    : ({
                    auto&& _q_opt = check_env::resolve_value(lx.g, lx.home, n);
                    auto&& q_opt = std::get<0>(_q_opt);
                    ({
                    __label__ _done;
                    prism_rtl::Slot<Array<Text>> _v;
                    if (prism_rtl::is_some(q_opt)) {
                        auto&& q = prism_rtl::some_of(q_opt);
                        _v.set(is_unbounded(lx, q) ? check_types::add_text(acc, q) : acc);
                        goto _done;
                    }
                    if (prism_rtl::is_none(q_opt)) {
                        _v.set(acc);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                }));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


prism_rtl::Turn<Array<Text>> UnboundedValues::cycle() const {
    const auto& lx = this->lx;
    const auto& d = this->d;
    auto es = ({
        __label__ _done;
        prism_rtl::Slot<Array<ast::Expr>> _v;
        auto&& _m = d.body;
        if (prism_rtl::is<check_env::DefBody::DbWidget>(_m)) {
            auto&& w = prism_rtl::as<check_env::DefBody::DbWidget>(_m).a0;
            _v.set(typed::block_exprs(w.body));
            goto _done;
        }
        if (prism_rtl::is<check_env::DefBody::DbFn>(_m)) {
            auto&& cs = prism_rtl::as<check_env::DefBody::DbFn>(_m).a0;
            _v.set(run_to_end(fold_job(cs, Array<ast::Expr>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<ast::Expr>>(std::tuple<Array<ast::Expr>, ast::FnClause>)>>(prism_rtl::rc([=](std::tuple<Array<ast::Expr>, ast::FnClause> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return entered(once_job([=]() {
                    return ({
                        auto acc = p0;
                        auto c = p1;
                        call_then(typed::start_body_exprs(c.body), [=](Array<ast::Expr> body_exprs_329527) { return prism_rtl::finished(append(acc, body_exprs_329527)); });
                    });
                }));
            })))));
            goto _done;
        }
        if (prism_rtl::is<check_env::DefBody::DbLet>(_m)) {
            auto&& l = prism_rtl::as<check_env::DefBody::DbLet>(_m).a0;
            _v.set(typed::exprs_in(l->value));
            goto _done;
        }
        {
            _v.set(Array<ast::Expr>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto callees = fold(es, Array<Text>{}, [&](const Array<Text>& acc, const ast::Expr& e) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = e.kind;
            if (prism_rtl::is<ast::ExprKind::ECall>(_m)) {
                auto&& c = prism_rtl::as<ast::ExprKind::ECall>(_m).a0;
                _v.set(prelude::push(acc, place_key(lx, c.span)));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    return prism_rtl::finished(fold(es, Array<Text>{}, [&](const Array<Text>& acc, const ast::Expr& e) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = e.kind;
            if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
                auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
                _v.set(check_types::has_text(callees, place_key(lx, e.span))
                    ? acc
                    : ({
                    auto&& _q_opt = check_env::resolve_value(lx.g, lx.home, n);
                    auto&& q_opt = std::get<0>(_q_opt);
                    ({
                    __label__ _done;
                    prism_rtl::Slot<Array<Text>> _v;
                    if (prism_rtl::is_some(q_opt)) {
                        auto&& q = prism_rtl::some_of(q_opt);
                        _v.set(is_unbounded(lx, q) ? check_types::add_text(acc, q) : acc);
                        goto _done;
                    }
                    if (prism_rtl::is_none(q_opt)) {
                        _v.set(acc);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                }));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    }));
}


/// `Start UnboundedValues, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_unbounded_values(Lx lx, check_env::Def d) {
    return std::make_shared<UnboundedValues>(lx, d);
}


/// InPrelude: fn Lx, Text -> Bool
bool in_prelude(const Lx& lx, const Text& q) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = prelude::get(lx.g.vals, q);
        if (prism_rtl::is_some(_m)) {
            auto&& v_ = prism_rtl::some_of(_m);
            _v.set(v_.home == Text("Prelude"));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(false);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// IsColorPoly: fn Lx, Text -> Bool
bool is_color_poly(const Lx& lx, const Text& q) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = prelude::get(lx.g.vals, q);
        if (prism_rtl::is_some(_m)) {
            auto&& v_ = prism_rtl::some_of(_m);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<bool> _v;
                auto&& _m = v_.scheme.ty;
                if (prism_rtl::is<check_types::Ty::TyFn>(_m) && prism_rtl::is<check_types::Col::CQ>(prism_rtl::as<check_types::Ty::TyFn>(_m).a0)) {
                    _v.set(true);
                    goto _done;
                }
                if (prism_rtl::is<check_types::Ty::TyFn>(_m) && prism_rtl::is<check_types::Col::CRigid>(prism_rtl::as<check_types::Ty::TyFn>(_m).a0)) {
                    _v.set(true);
                    goto _done;
                }
                {
                    _v.set(false);
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(false);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// EntersAtOnce: fn Lx, Text, [Arg] -> Bool
bool enters_at_once(const Lx& lx, const Text& q, const Array<ast::Arg>& args) {
    return is_color_poly(lx, q) && (!fold(args, false, [&](const bool& seen, const ast::Arg& a) { return seen || is_unbounded_arg(lx, a); }));
}


/// IsUnboundedArg: fn Lx, Arg -> Bool
bool is_unbounded_arg(const Lx& lx, const ast::Arg& a) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = peel(type_at(lx, a->value.span));
        if (prism_rtl::is<check_types::Ty::TyFn>(_m) && prism_rtl::is<check_types::Col::CUnbound>(prism_rtl::as<check_types::Ty::TyFn>(_m).a0)) {
            _v.set(true);
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// IsUnbounded: fn Lx, Text -> Bool
bool is_unbounded(const Lx& lx, const Text& q) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = prelude::get(lx.g.vals, q);
        if (prism_rtl::is_some(_m)) {
            auto&& v_ = prism_rtl::some_of(_m);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<bool> _v;
                auto&& _m = v_.scheme.ty;
                if (prism_rtl::is<check_types::Ty::TyFn>(_m) && prism_rtl::is<check_types::Col::CBound>(prism_rtl::as<check_types::Ty::TyFn>(_m).a0)) {
                    _v.set(false);
                    goto _done;
                }
                if (prism_rtl::is<check_types::Ty::TyFn>(_m)) {
                    _v.set(true);
                    goto _done;
                }
                {
                    _v.set(false);
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(false);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// RunTargets: unbounded fn Lx, Def -> [Text]
Array<Text> run_targets(const Lx& lx, const check_env::Def& d) {
    auto es = ({
        __label__ _done;
        prism_rtl::Slot<Array<ast::Expr>> _v;
        auto&& _m = d.body;
        if (prism_rtl::is<check_env::DefBody::DbWidget>(_m)) {
            auto&& w = prism_rtl::as<check_env::DefBody::DbWidget>(_m).a0;
            _v.set(typed::block_exprs(w.body));
            goto _done;
        }
        if (prism_rtl::is<check_env::DefBody::DbFn>(_m)) {
            auto&& cs = prism_rtl::as<check_env::DefBody::DbFn>(_m).a0;
            _v.set(run_to_end(fold_job(cs, Array<ast::Expr>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<ast::Expr>>(std::tuple<Array<ast::Expr>, ast::FnClause>)>>(prism_rtl::rc([=](std::tuple<Array<ast::Expr>, ast::FnClause> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return entered(once_job([=]() {
                    return ({
                        auto acc = p0;
                        auto c = p1;
                        call_then(typed::start_body_exprs(c.body), [=](Array<ast::Expr> body_exprs_331756) { return prism_rtl::finished(append(acc, body_exprs_331756)); });
                    });
                }));
            })))));
            goto _done;
        }
        {
            _v.set(Array<ast::Expr>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    return fold(es, Array<Text>{}, [&](const Array<Text>& acc, const ast::Expr& e) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = e.kind;
            if (prism_rtl::is<ast::ExprKind::ECall>(_m)) {
                auto&& c = prism_rtl::as<ast::ExprKind::ECall>(_m).a0;
                auto&& args = prism_rtl::as<ast::ExprKind::ECall>(_m).a1;
                _v.set(blueprint_qk(lx, c) == Text("Prelude.@Run")
                    ? ({
                    __label__ _done;
                    prism_rtl::Slot<Array<Text>> _v;
                    auto&& _m = index(args, Nat(0u));
                    if (prism_rtl::is_some(_m)) {
                        auto&& a = prism_rtl::some_of(_m);
                        _v.set(({
                            __label__ _done;
                            prism_rtl::Slot<Array<Text>> _v;
                            auto&& _m = a->value.kind;
                            if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
                                auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
                                _v.set(({
                                    auto&& _q_opt = check_env::resolve_value(lx.g, lx.home, n);
                                    auto&& q_opt = std::get<0>(_q_opt);
                                    ({
                                    __label__ _done;
                                    prism_rtl::Slot<Array<Text>> _v;
                                    if (prism_rtl::is_some(q_opt)) {
                                        auto&& q = prism_rtl::some_of(q_opt);
                                        _v.set(check_types::add_text(acc, q));
                                        goto _done;
                                    }
                                    if (prism_rtl::is_none(q_opt)) {
                                        _v.set(acc);
                                        goto _done;
                                    }
                                    prism_rtl::unreachable("no arm matched");
                                _done:
                                    _v.take();
                                });
                                }));
                                goto _done;
                            }
                            {
                                _v.set(acc);
                                goto _done;
                            }
                        _done:
                            _v.take();
                        }));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(acc);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                })
                    : acc);
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


prism_rtl::Turn<Array<Text>> RunTargets::cycle() const {
    const auto& lx = this->lx;
    const auto& d = this->d;
    auto es = ({
        __label__ _done;
        prism_rtl::Slot<Array<ast::Expr>> _v;
        auto&& _m = d.body;
        if (prism_rtl::is<check_env::DefBody::DbWidget>(_m)) {
            auto&& w = prism_rtl::as<check_env::DefBody::DbWidget>(_m).a0;
            _v.set(typed::block_exprs(w.body));
            goto _done;
        }
        if (prism_rtl::is<check_env::DefBody::DbFn>(_m)) {
            auto&& cs = prism_rtl::as<check_env::DefBody::DbFn>(_m).a0;
            _v.set(run_to_end(fold_job(cs, Array<ast::Expr>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<ast::Expr>>(std::tuple<Array<ast::Expr>, ast::FnClause>)>>(prism_rtl::rc([=](std::tuple<Array<ast::Expr>, ast::FnClause> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return entered(once_job([=]() {
                    return ({
                        auto acc = p0;
                        auto c = p1;
                        call_then(typed::start_body_exprs(c.body), [=](Array<ast::Expr> body_exprs_331756) { return prism_rtl::finished(append(acc, body_exprs_331756)); });
                    });
                }));
            })))));
            goto _done;
        }
        {
            _v.set(Array<ast::Expr>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    return prism_rtl::finished(fold(es, Array<Text>{}, [&](const Array<Text>& acc, const ast::Expr& e) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = e.kind;
            if (prism_rtl::is<ast::ExprKind::ECall>(_m)) {
                auto&& c = prism_rtl::as<ast::ExprKind::ECall>(_m).a0;
                auto&& args = prism_rtl::as<ast::ExprKind::ECall>(_m).a1;
                _v.set(blueprint_qk(lx, c) == Text("Prelude.@Run")
                    ? ({
                    __label__ _done;
                    prism_rtl::Slot<Array<Text>> _v;
                    auto&& _m = index(args, Nat(0u));
                    if (prism_rtl::is_some(_m)) {
                        auto&& a = prism_rtl::some_of(_m);
                        _v.set(({
                            __label__ _done;
                            prism_rtl::Slot<Array<Text>> _v;
                            auto&& _m = a->value.kind;
                            if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
                                auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
                                _v.set(({
                                    auto&& _q_opt = check_env::resolve_value(lx.g, lx.home, n);
                                    auto&& q_opt = std::get<0>(_q_opt);
                                    ({
                                    __label__ _done;
                                    prism_rtl::Slot<Array<Text>> _v;
                                    if (prism_rtl::is_some(q_opt)) {
                                        auto&& q = prism_rtl::some_of(q_opt);
                                        _v.set(check_types::add_text(acc, q));
                                        goto _done;
                                    }
                                    if (prism_rtl::is_none(q_opt)) {
                                        _v.set(acc);
                                        goto _done;
                                    }
                                    prism_rtl::unreachable("no arm matched");
                                _done:
                                    _v.take();
                                });
                                }));
                                goto _done;
                            }
                            {
                                _v.set(acc);
                                goto _done;
                            }
                        _done:
                            _v.take();
                        }));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(acc);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                })
                    : acc);
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    }));
}


/// `Start RunTargets, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_run_targets(Lx lx, check_env::Def d) {
    return std::make_shared<RunTargets>(lx, d);
}


/// TailTargets: unbounded fn Lx, Text -> [Text]
Array<Text> tail_targets(const Lx& lx, const Text& qk) {
    auto v_ = or_(prelude::get(lx.g.vals, qk), check_env::builtin(qk, check_types::mono(check_types::Ty(check_types::Ty::TyErr{}))));
    auto lxm = in_module(lx, v_->file, v_.home);
    return run_to_end(fold_job(clauses_of(lx.g, qk), Array<Text>{}, ({
        auto lxm_1 = lxm;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, ast::FnClause>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, ast::FnClause> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lxm_1_2 = lxm_1;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto c = p1;
                call_then(start_tails_of_body(lxm_1_2, c.body), [=](Array<Text> tails_of_body_332635) { return prism_rtl::finished(check_types::union_texts(acc, tails_of_body_332635)); });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<Array<Text>> TailTargets::cycle() const {
    const auto& lx = this->lx;
    const auto& qk = this->qk;
    auto v_ = or_(prelude::get(lx.g.vals, qk), check_env::builtin(qk, check_types::mono(check_types::Ty(check_types::Ty::TyErr{}))));
    auto lxm = in_module(lx, v_->file, v_.home);
    return fold_job(clauses_of(lx.g, qk), Array<Text>{}, ({
        auto lxm_1 = lxm;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, ast::FnClause>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, ast::FnClause> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lxm_1_2 = lxm_1;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto c = p1;
                call_then(start_tails_of_body(lxm_1_2, c.body), [=](Array<Text> tails_of_body_332635) { return prism_rtl::finished(check_types::union_texts(acc, tails_of_body_332635)); });
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start TailTargets, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_tail_targets(Lx lx, Text qk) {
    return std::make_shared<TailTargets>(lx, qk);
}


/// TailsOfBody: unbounded fn Lx, FnBody -> [Text]
Array<Text> tails_of_body(const Lx& lx, const ast::FnBody& body) {
    return fold(typed::body_exprs(body), Array<Text>{}, [&](const Array<Text>& acc, const ast::Expr& e) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = e.kind;
            if (prism_rtl::is<ast::ExprKind::ECall>(_m)) {
                auto&& c = prism_rtl::as<ast::ExprKind::ECall>(_m).a0;
                _v.set(({
                    auto q = blueprint_qk(lx, c);
                    ({
                    __label__ _done;
                    prism_rtl::Slot<Array<Text>> _v;
                    auto&& _m = prelude::get(lx.g.vals, q);
                    if (prism_rtl::is_some(_m)) {
                        auto&& v_ = prism_rtl::some_of(_m);
                        _v.set(({
                            __label__ _done;
                            prism_rtl::Slot<Array<Text>> _v;
                            auto&& _m = v_.scheme.ty;
                            if (prism_rtl::is<check_types::Ty::TyFn>(_m) && prism_rtl::is<check_types::Col::CBound>(prism_rtl::as<check_types::Ty::TyFn>(_m).a0)) {
                                _v.set(acc);
                                goto _done;
                            }
                            if (prism_rtl::is<check_types::Ty::TyFn>(_m)) {
                                _v.set(check_types::add_text(acc, q));
                                goto _done;
                            }
                            {
                                _v.set(acc);
                                goto _done;
                            }
                        _done:
                            _v.take();
                        }));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(acc);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                }));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


prism_rtl::Turn<Array<Text>> TailsOfBody::cycle() const {
    const auto& lx = this->lx;
    const auto& body = this->body;
    auto body_1 = body;
    auto lx_2 = lx;
    return call_then(typed::start_body_exprs(body_1), [=](Array<ast::Expr> body_exprs_332740) {
        return prism_rtl::finished(fold(body_exprs_332740, Array<Text>{}, [&](const Array<Text>& acc, const ast::Expr& e) {
            return ({
                __label__ _done;
                prism_rtl::Slot<Array<Text>> _v;
                auto&& _m = e.kind;
                if (prism_rtl::is<ast::ExprKind::ECall>(_m)) {
                    auto&& c = prism_rtl::as<ast::ExprKind::ECall>(_m).a0;
                    _v.set(({
                        auto q = blueprint_qk(lx_2, c);
                        ({
                        __label__ _done;
                        prism_rtl::Slot<Array<Text>> _v;
                        auto&& _m = prelude::get(lx_2.g.vals, q);
                        if (prism_rtl::is_some(_m)) {
                            auto&& v_ = prism_rtl::some_of(_m);
                            _v.set(({
                                __label__ _done;
                                prism_rtl::Slot<Array<Text>> _v;
                                auto&& _m = v_.scheme.ty;
                                if (prism_rtl::is<check_types::Ty::TyFn>(_m) && prism_rtl::is<check_types::Col::CBound>(prism_rtl::as<check_types::Ty::TyFn>(_m).a0)) {
                                    _v.set(acc);
                                    goto _done;
                                }
                                if (prism_rtl::is<check_types::Ty::TyFn>(_m)) {
                                    _v.set(check_types::add_text(acc, q));
                                    goto _done;
                                }
                                {
                                    _v.set(acc);
                                    goto _done;
                                }
                            _done:
                                _v.take();
                            }));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(acc);
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                    }));
                    goto _done;
                }
                {
                    _v.set(acc);
                    goto _done;
                }
            _done:
                _v.take();
            });
        }));
    });
}


/// `Start TailsOfBody, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_tails_of_body(Lx lx, ast::FnBody body) {
    return std::make_shared<TailsOfBody>(lx, body);
}


/// ModDefOf: unbounded fn Lx, Text, [((Text, Bool))], ModInfo, [Text] -> ModDef
ModDef mod_def_of(const Lx& lx0, const Text& m, const Array<std::tuple<Text, bool>>& roots, const check_env::ModInfo& info, const Array<Text>& mods) {
    auto lx = in_module(lx0, info->file, m);
    auto path_ = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = index(lx.g.srcs, info->file);
        if (prism_rtl::is_some(_m)) {
            auto&& src = prism_rtl::some_of(_m);
            _v.set(src->path_);
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto types = run_to_end(fold_job(values(lx.g.types), Array<Item>{}, ({
        auto m_1 = m;
        auto lx_2 = lx;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Item>>(std::tuple<Array<Item>, check_env::TyInfo>)>>(prism_rtl::rc([=](std::tuple<Array<Item>, check_env::TyInfo> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto m_1_3 = m_1;
            auto lx_2_3 = lx_2;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto ti = p1;
                ti.home == m_1_3
                ? call_then(start_ty_defs(lx_2_3, ti), [=](Array<Item> ty_defs_333465) { return prism_rtl::finished(append(acc, ty_defs_333465)); })
                : prism_rtl::finished(acc);
            });
        }));
        });
    })));
    })));
    auto tags = run_to_end(fold_job(values(lx.g.tags), Array<Item>{}, ({
        auto m_1 = m;
        auto lx_2 = lx;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Item>>(std::tuple<Array<Item>, check_env::TagInfo>)>>(prism_rtl::rc([=](std::tuple<Array<Item>, check_env::TagInfo> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto m_1_3 = m_1;
            auto lx_2_3 = lx_2;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto tg = p1;
                (tg.home == m_1_3) && (tg.kind != Text("Prelude.Fault"))
                ? call_then(start_tag_def_of(lx_2_3, tg), [=](TagDef tag_def_of_333613) { return prism_rtl::finished(prelude::push(acc, Item(Item::ItTag{tag_def_of_333613}))); })
                : prism_rtl::finished(acc);
            });
        }));
        });
    })));
    })));
    auto defs = run_to_end(fold_job(lx.g.defs, Array<Item>{}, ({
        auto m_1 = m;
        auto lx_2 = lx;
        auto roots_3 = roots;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Item>>(std::tuple<Array<Item>, check_env::Def>)>>(prism_rtl::rc([=](std::tuple<Array<Item>, check_env::Def> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto m_1_4 = m_1;
            auto lx_2_4 = lx_2;
            auto roots_3_4 = roots_3;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto d = p1;
                d.home == m_1_4
                ? call_then(start_def_items(in_module(lx_2_4, d->file, m_1_4), d, roots_3_4), [=](Array<Item> def_items_333717) { return prism_rtl::finished(append(acc, def_items_333717)); })
                : prism_rtl::finished(acc);
            });
        }));
        });
    })));
    })));
    auto traits = run_to_end(fold_job(values(lx.g.traits), Array<Item>{}, ({
        auto m_1 = m;
        auto lx_2 = lx;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Item>>(std::tuple<Array<Item>, check_env::TraitInfo>)>>(prism_rtl::rc([=](std::tuple<Array<Item>, check_env::TraitInfo> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto m_1_3 = m_1;
            auto lx_2_3 = lx_2;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto tr = p1;
                tr.home == m_1_3
                ? call_then(start_trait_def_of(lx_2_3, tr), [=](TraitDef trait_def_of_333870) { return prism_rtl::finished(prelude::push(acc, Item(Item::ItTrait{trait_def_of_333870}))); })
                : prism_rtl::finished(acc);
            });
        }));
        });
    })));
    })));
    auto impls = run_to_end(fold_job(values(lx.g.impls), Array<Item>{}, ({
        auto m_1 = m;
        auto lx_2 = lx;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Item>>(std::tuple<Array<Item>, Array<check_env::ImplInfo>>)>>(prism_rtl::rc([=](std::tuple<Array<Item>, Array<check_env::ImplInfo>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto m_1_3 = m_1;
            auto lx_2_3 = lx_2;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto ims = p1;
                fold_job(ims, acc, ({
                auto m_1_3_3 = m_1_3;
                auto lx_2_3_3 = lx_2_3;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Item>>(std::tuple<Array<Item>, check_env::ImplInfo>)>>(prism_rtl::rc([=](std::tuple<Array<Item>, check_env::ImplInfo> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto m_1_3_3_3 = m_1_3_3;
                    auto lx_2_3_3_3 = lx_2_3_3;
                    entered(once_job([=]() {
                    return ({
                        auto a = p0;
                        auto im = p1;
                        (im.home == m_1_3_3_3) && (!im.derived)
                        ? call_then(start_impl_def_of(in_module(lx_2_3_3_3, im->file, m_1_3_3_3), im), [=](ImplDef impl_def_of_334037) { return prism_rtl::finished(prelude::push(a, Item(Item::ItImpl{impl_def_of_334037}))); })
                        : prism_rtl::finished(a);
                    });
                }));
                });
            })));
            }))->cycle();
            });
        }));
        });
    })));
    })));
    auto uses = filter(each(mods, [&](const Text& o) { return rust_mod_name(o); }), [&](const Text& o) { return o != rust_mod_name(m); });
    return ModDef{.name = rust_mod_name(m), .prism = m, .path_ = path_, .uses = uses, .complete = Array<Text>{}, .declared = Array<Text>{}, .types_with = Array<Text>{}, .items = append(append(append(append(types, tags), traits), impls), defs)};
}


prism_rtl::Turn<ModDef> ModDefOf::cycle() const {
    const auto& lx0 = this->lx0;
    const auto& m = this->m;
    const auto& roots = this->roots;
    const auto& info = this->info;
    const auto& mods = this->mods;
    auto lx = in_module(lx0, info->file, m);
    auto path_ = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = index(lx.g.srcs, info->file);
        if (prism_rtl::is_some(_m)) {
            auto&& src = prism_rtl::some_of(_m);
            _v.set(src->path_);
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto m_1 = m;
    auto mods_2 = mods;
    auto roots_3 = roots;
    return call_value(fold_job(values(lx.g.types), Array<Item>{}, ({
        auto m_1_4 = m_1;
        auto lx_4 = lx;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Item>>(std::tuple<Array<Item>, check_env::TyInfo>)>>(prism_rtl::rc([=](std::tuple<Array<Item>, check_env::TyInfo> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto m_1_4_5 = m_1_4;
            auto lx_4_5 = lx_4;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto ti = p1;
                ti.home == m_1_4_5
                ? call_then(start_ty_defs(lx_4_5, ti), [=](Array<Item> ty_defs_333465) { return prism_rtl::finished(append(acc, ty_defs_333465)); })
                : prism_rtl::finished(acc);
            });
        }));
        });
    })));
    })), [=](Array<Item> fold_333392) {
        return ({
            auto types = fold_333392;
            call_value(fold_job(values(lx.g.tags), Array<Item>{}, ({
            auto m_1_4 = m_1;
            auto lx_4 = lx;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Item>>(std::tuple<Array<Item>, check_env::TagInfo>)>>(prism_rtl::rc([=](std::tuple<Array<Item>, check_env::TagInfo> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto m_1_4_5 = m_1_4;
                auto lx_4_5 = lx_4;
                entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto tg = p1;
                    (tg.home == m_1_4_5) && (tg.kind != Text("Prelude.Fault"))
                    ? call_then(start_tag_def_of(lx_4_5, tg), [=](TagDef tag_def_of_333613) { return prism_rtl::finished(prelude::push(acc, Item(Item::ItTag{tag_def_of_333613}))); })
                    : prism_rtl::finished(acc);
                });
            }));
            });
        })));
        })), [=](Array<Item> fold_333505) {
            return ({
                auto tags = fold_333505;
                call_value(fold_job(lx.g.defs, Array<Item>{}, ({
                auto m_1_4 = m_1;
                auto lx_4 = lx;
                auto roots_3_5 = roots_3;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Item>>(std::tuple<Array<Item>, check_env::Def>)>>(prism_rtl::rc([=](std::tuple<Array<Item>, check_env::Def> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto m_1_4_5 = m_1_4;
                    auto lx_4_5 = lx_4;
                    auto roots_3_5_5 = roots_3_5;
                    entered(once_job([=]() {
                    return ({
                        auto acc = p0;
                        auto d = p1;
                        d.home == m_1_4_5
                        ? call_then(start_def_items(in_module(lx_4_5, d->file, m_1_4_5), d, roots_3_5_5), [=](Array<Item> def_items_333717) { return prism_rtl::finished(append(acc, def_items_333717)); })
                        : prism_rtl::finished(acc);
                    });
                }));
                });
            })));
            })), [=](Array<Item> fold_333656) {
                return ({
                    auto defs = fold_333656;
                    call_value(fold_job(values(lx.g.traits), Array<Item>{}, ({
                    auto m_1_4 = m_1;
                    auto lx_4 = lx;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Item>>(std::tuple<Array<Item>, check_env::TraitInfo>)>>(prism_rtl::rc([=](std::tuple<Array<Item>, check_env::TraitInfo> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto m_1_4_5 = m_1_4;
                        auto lx_4_5 = lx_4;
                        entered(once_job([=]() {
                        return ({
                            auto acc = p0;
                            auto tr = p1;
                            tr.home == m_1_4_5
                            ? call_then(start_trait_def_of(lx_4_5, tr), [=](TraitDef trait_def_of_333870) { return prism_rtl::finished(prelude::push(acc, Item(Item::ItTrait{trait_def_of_333870}))); })
                            : prism_rtl::finished(acc);
                        });
                    }));
                    });
                })));
                })), [=](Array<Item> fold_333789) {
                    return ({
                        auto traits = fold_333789;
                        call_value(fold_job(values(lx.g.impls), Array<Item>{}, ({
                        auto m_1_4 = m_1;
                        auto lx_4 = lx;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Item>>(std::tuple<Array<Item>, Array<check_env::ImplInfo>>)>>(prism_rtl::rc([=](std::tuple<Array<Item>, Array<check_env::ImplInfo>> _p0) {
                        auto&& p0 = std::get<0>(_p0);
                        auto&& p1 = std::get<1>(_p0);
                        return ({
                            auto m_1_4_5 = m_1_4;
                            auto lx_4_5 = lx_4;
                            entered(once_job([=]() {
                            return ({
                                auto acc = p0;
                                auto ims = p1;
                                fold_job(ims, acc, ({
                                auto m_1_4_5_5 = m_1_4_5;
                                auto lx_4_5_5 = lx_4_5;
                                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Item>>(std::tuple<Array<Item>, check_env::ImplInfo>)>>(prism_rtl::rc([=](std::tuple<Array<Item>, check_env::ImplInfo> _p0) {
                                auto&& p0 = std::get<0>(_p0);
                                auto&& p1 = std::get<1>(_p0);
                                return ({
                                    auto m_1_4_5_5_5 = m_1_4_5_5;
                                    auto lx_4_5_5_5 = lx_4_5_5;
                                    entered(once_job([=]() {
                                    return ({
                                        auto a = p0;
                                        auto im = p1;
                                        (im.home == m_1_4_5_5_5) && (!im.derived)
                                        ? call_then(start_impl_def_of(in_module(lx_4_5_5_5, im->file, m_1_4_5_5_5), im), [=](ImplDef impl_def_of_334037) { return prism_rtl::finished(prelude::push(a, Item(Item::ItImpl{impl_def_of_334037}))); })
                                        : prism_rtl::finished(a);
                                    });
                                }));
                                });
                            })));
                            }))->cycle();
                            });
                        }));
                        });
                    })));
                    })), [=](Array<Item> fold_333916) {
                        return ({
                            auto impls = fold_333916;
                            auto uses = filter(each(mods_2, [&](const Text& o) { return rust_mod_name(o); }), [&](const Text& o) { return o != rust_mod_name(m_1); });
                            (prism_rtl::finished(ModDef{.name = rust_mod_name(m_1), .prism = m_1, .path_ = path_, .uses = uses, .complete = Array<Text>{}, .declared = Array<Text>{}, .types_with = Array<Text>{}, .items = append(append(append(append(types, tags), traits), impls), defs)}));
                        });
                    });
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start ModDefOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<ModDef> start_mod_def_of(Lx lx0, Text m, Array<std::tuple<Text, bool>> roots, check_env::ModInfo info, Array<Text> mods) {
    return std::make_shared<ModDefOf>(lx0, m, roots, info, mods);
}


/// DefItems: unbounded fn Lx, Def, [((Text, Bool))] -> [Item]
Array<Item> def_items(const Lx& lx, const check_env::Def& d, const Array<std::tuple<Text, bool>>& roots) {
    auto is_root = check_types::has_text(each(roots, [&](const std::tuple<Text, bool>& _p0) {
        auto&& q = std::get<0>(_p0);
        return q;
    }), d.qk);
    return ({
        __label__ _done;
        prism_rtl::Slot<Array<Item>> _v;
        auto&& _m = d.body;
        if (prism_rtl::is<check_env::DefBody::DbWidget>(_m)) {
            auto&& w = prism_rtl::as<check_env::DefBody::DbWidget>(_m).a0;
            _v.set(is_root
                ? node_items(node_def_of(lx, d.qk, Array<ast::Pattern_>{}, w.body, or_(prelude::get(lx.g.vals, d.qk), check_env::builtin(d.qk, check_types::mono(check_types::Ty(check_types::Ty::TyErr{})))).scheme, true))
                : Array(std::vector{Item(Item::ItNote{prism_rtl::cat("`", d.name, "` is inlined where it is applied.")})}));
            goto _done;
        }
        if (prism_rtl::is<check_env::DefBody::DbFn>(_m)) {
            auto&& clauses = prism_rtl::as<check_env::DefBody::DbFn>(_m).a0;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<Array<Item>> _v;
                auto&& _m = prelude::get(lx.g.vals, d.qk);
                if (prism_rtl::is_none(_m)) {
                    _v.set(Array<Item>{});
                    goto _done;
                }
                if (prism_rtl::is_some(_m)) {
                    auto&& v_ = prism_rtl::some_of(_m);
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<Array<Item>> _v;
                        auto&& _m = v_.scheme.ty;
                        if (prism_rtl::is<check_types::Ty::TyFn>(_m)) {
                            auto&& m334955_0_2 = prism_rtl::as<check_types::Ty::TyFn>(_m).a2;
                            if (prism_rtl::is<check_types::Ty::TyAt>(m334955_0_2)) {
                                _v.set(!is_root
                                    ? Array(std::vector{Item(Item::ItNote{prism_rtl::cat("`", d.name, "` is inlined where it is applied.")})})
                                    : ({
                                    __label__ _done;
                                    prism_rtl::Slot<Array<Item>> _v;
                                    {
                                        auto&& m335151_0 = clauses;
                                        if (m335151_0.size() == 1u) {
                                            {
                                                auto&& _c1 = index(m335151_0, Nat(0u));
                                                if (prism_rtl::is_some(_c1)) {
                                                    auto&& c = prism_rtl::some_of(_c1);
                                                    _v.set(({
                                                        __label__ _done;
                                                        prism_rtl::Slot<Array<Item>> _v;
                                                        auto&& _m = c.body;
                                                        if (prism_rtl::is<ast::FnBody::BodyBlock>(_m)) {
                                                            auto&& b = prism_rtl::as<ast::FnBody::BodyBlock>(_m).a0;
                                                            _v.set(node_items(node_def_of(lx, d.qk, c.params, b, v_.scheme, true)));
                                                            goto _done;
                                                        }
                                                        {
                                                            _v.set(Array(std::vector{Item(Item::ItRefused{prism_rtl::cat("`", d.name, "`, a root widget whose body is one expression")})}));
                                                            goto _done;
                                                        }
                                                    _done:
                                                        _v.take();
                                                    }));
                                                    goto _done;
                                                }
                                            }
                                        }
                                    }
                                    {
                                        _v.set(Array(std::vector{Item(Item::ItRefused{prism_rtl::cat("`", d.name, "`, a root widget of several clauses")})}));
                                        goto _done;
                                    }
                                _done:
                                    _v.take();
                                }));
                                goto _done;
                            }
                        }
                        {
                            _v.set(({
                                auto f = Item(Item::ItFn{fn_def_of(lx, d.qk, clauses, v_.scheme)});
                                (check_types::has_text(lx.unbs, d.qk)
                                ? Array(std::vector{f, Item(Item::ItJob{job_def_of(lx, d.qk, clauses, v_.scheme)})})
                                : Array(std::vector{f}));
                            }));
                            goto _done;
                        }
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is<check_env::DefBody::DbLet>(_m)) {
            auto&& l = prism_rtl::as<check_env::DefBody::DbLet>(_m).a0;
            _v.set(Array(std::vector{Item(Item::ItFn{let_getter(lx, d.qk, l)})}));
            goto _done;
        }
        {
            _v.set(Array<Item>{});
            goto _done;
        }
    _done:
        _v.take();
    });
}

}  // namespace crate::lower
