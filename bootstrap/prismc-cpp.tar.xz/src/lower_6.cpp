// The module `Lower`, from `target/bootstrap/cpp-src/prismc/lower.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (docs/backend.md). Edit the Prism source, not this file.
#include "lower.hpp"
#include "ast.hpp"
#include "check_env.hpp"
#include "check_errors.hpp"
#include "check_types.hpp"
#include "lexer.hpp"
#include "typed.hpp"
#include "lower.generic.hpp"
#include "check_env.generic.hpp"
#include "lexer.generic.hpp"

namespace crate::lower {

/// FinishPending: unbounded fn Wx, [Gn] -> (([NodeDef], [Gn]))
std::tuple<Array<NodeDef>, Array<Gn>> finish_pending(const Wx& wx, const Array<Gn>& gns) {
    return run_to_end(fold_job(wx.pending, std::tuple{Array<NodeDef>{}, gns}, ({
        auto wx_1 = wx;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<NodeDef>, Array<Gn>>>(std::tuple<std::tuple<Array<NodeDef>, Array<Gn>>, PendingRow>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<NodeDef>, Array<Gn>>, PendingRow> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto wx_1_2 = wx_1;
            entered(once_job([=]() {
            return ({
                auto [defs, cur] = p0;
                auto p_ = p1;
                ({
                auto floors = fold(row_hears(p_.wx), Map<Text, Nat>{}, [&](const Map<Text, Nat>& acc, const Text& m) { return insert(acc, m, parent_floor(wx_1_2, cur, Array(std::vector{Read(Read::ParentRead{m})}))); });
                auto floored = ({
                    Wx this_ = p_.wx;
                    this_.floors = floors;
                    this_.gns = each(this_.gns, [&](const Gn& g) {
                        return g.kind == GnKind(GnKind::GnUpdated{})
                            ? with_floor(g, parent_floor(wx_1_2, cur, reads_closed(p_.wx.dyn_reads, g.reads)))
                            : g;
                    });
                    this_;
                });
                call_then(start_finish_node(floored, p_.qk, p_.params, true), [=](NodeDef finish_node_297879) {
                return ({
                    auto def = finish_node_297879;
                    auto next = ({
                        __label__ _done;
                        prism_rtl::Slot<Array<Gn>> _v;
                        auto&& _m = p_.gather;
                        if (prism_rtl::is_some(_m)) {
                            auto&& gid = prism_rtl::some_of(_m);
                            _v.set(each(cur, [&](const Gn& g) { return g.id == gid ? with_height(g, def.top + Nat(1u)) : g; }));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(cur);
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                    (prism_rtl::finished(std::tuple{prelude::push(defs, def), next}));
                });
            });
            });
            });
        }));
        });
    }));
    })));
}


prism_rtl::Turn<std::tuple<Array<NodeDef>, Array<Gn>>> FinishPending::cycle() const {
    const auto& wx = this->wx;
    const auto& gns = this->gns;
    return fold_job(wx.pending, std::tuple{Array<NodeDef>{}, gns}, ({
        auto wx_1 = wx;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<NodeDef>, Array<Gn>>>(std::tuple<std::tuple<Array<NodeDef>, Array<Gn>>, PendingRow>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<NodeDef>, Array<Gn>>, PendingRow> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto wx_1_2 = wx_1;
            entered(once_job([=]() {
            return ({
                auto [defs, cur] = p0;
                auto p_ = p1;
                ({
                auto floors = fold(row_hears(p_.wx), Map<Text, Nat>{}, [&](const Map<Text, Nat>& acc, const Text& m) { return insert(acc, m, parent_floor(wx_1_2, cur, Array(std::vector{Read(Read::ParentRead{m})}))); });
                auto floored = ({
                    Wx this_ = p_.wx;
                    this_.floors = floors;
                    this_.gns = each(this_.gns, [&](const Gn& g) {
                        return g.kind == GnKind(GnKind::GnUpdated{})
                            ? with_floor(g, parent_floor(wx_1_2, cur, reads_closed(p_.wx.dyn_reads, g.reads)))
                            : g;
                    });
                    this_;
                });
                call_then(start_finish_node(floored, p_.qk, p_.params, true), [=](NodeDef finish_node_297879) {
                return ({
                    auto def = finish_node_297879;
                    auto next = ({
                        __label__ _done;
                        prism_rtl::Slot<Array<Gn>> _v;
                        auto&& _m = p_.gather;
                        if (prism_rtl::is_some(_m)) {
                            auto&& gid = prism_rtl::some_of(_m);
                            _v.set(each(cur, [&](const Gn& g) { return g.id == gid ? with_height(g, def.top + Nat(1u)) : g; }));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(cur);
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                    (prism_rtl::finished(std::tuple{prelude::push(defs, def), next}));
                });
            });
            });
            });
        }));
        });
    }));
    }))->cycle();
}


/// `Start FinishPending, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<NodeDef>, Array<Gn>>> start_finish_pending(Wx wx, Array<Gn> gns) {
    return prism_rtl::make_rc<FinishPending>(wx, gns);
}


/// ParentFloor: fn Wx, [Gn], [Read] -> Nat
Nat parent_floor(const Wx& wx, const Array<Gn>& gns, const Array<Read>& reads) {
    return fold(reads, Nat(0u), [&](const Nat& hi, const Read& r) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Nat> _v;
            if (prism_rtl::is<Read::ParentRead>(r)) {
                auto&& m = prism_rtl::as<Read::ParentRead>(r).a0;
                _v.set(fold(reads_closed(wx.dyn_reads, Array(std::vector{Read(Read::OwnRead{m})})), hi, [&](const Nat& h2, const Read& hr) {
                    return ({
                        __label__ _done;
                        prism_rtl::Slot<Nat> _v;
                        if (prism_rtl::is<Read::OwnRead>(hr)) {
                            auto&& f = prism_rtl::as<Read::OwnRead>(hr).a0;
                            _v.set(fold(gns, h2, [&](const Nat& h3, const Gn& g) { return writes_hold(g, f) ? prelude::max(h3, g.height + Nat(1u)) : h3; }));
                            goto _done;
                        }
                        if (prism_rtl::is<Read::ParentRead>(hr)) {
                            auto&& up = prism_rtl::as<Read::ParentRead>(hr).a0;
                            _v.set(prelude::max(h2, or_(prelude::get(wx.floors, up), Nat(0u))));
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                }));
                goto _done;
            }
            if (prism_rtl::is<Read::OwnRead>(r)) {
                _v.set(hi);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
}


/// WritesHold: fn Gn, Text -> Bool
bool writes_hold(const Gn& g, const Text& f) {
    return fold(g.outs, false, [&](const bool& acc, const Out& o) { return acc || sink_writes_hold(o.sink, f); });
}


/// SinkWritesHold: fn Sk, Text -> Bool
bool sink_writes_hold(const Sk& sk0, const Text& f) {
    if (prism_rtl::is<Sk::SkHold>(sk0)) {
        auto&& h = prism_rtl::as<Sk::SkHold>(sk0).a0;
        return h == f;
    }
    if (prism_rtl::is<Sk::SkMachine>(sk0)) {
        auto&& h = prism_rtl::as<Sk::SkMachine>(sk0).a0;
        return h == f;
    }
    {
        auto&& other = sk0;
        return false;
    }
}


/// WithFloor: fn Gn, Nat -> Gn
Gn with_floor(const Gn& g, const Nat& h) {
    Gn this_ = g;
    this_.floor = h;
    return this_;
}


/// WithHeight: fn Gn, Nat -> Gn
Gn with_height(const Gn& g, const Nat& h) {
    Gn this_ = g;
    this_.height = h;
    return this_;
}


/// RowHears: fn Wx -> [Text]
Array<Text> row_hears(const Wx& wx) {
    auto from_updated = fold(filter(wx.gns, [&](const Gn& g) { return g.kind == GnKind(GnKind::GnUpdated{}); }), Array<Read>{}, [&](const Array<Read>& acc, const Gn& g) { return union_reads(acc, reads_closed(wx.dyn_reads, g.reads)); });
    auto from_rows = fold(wx.row_marks, Array<Read>{}, [&](const Array<Read>& acc, const RowMarks& rm) { return union_reads(acc, reads_closed(wx.dyn_reads, append(rm.reads, each(rm.wrote, [&](const Text& m) { return Read(Read::OwnRead{m}); })))); });
    return fold(union_reads(from_updated, from_rows), Array<Text>{}, [&](const Array<Text>& acc, const Read& r) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            if (prism_rtl::is<Read::ParentRead>(r)) {
                auto&& m = prism_rtl::as<Read::ParentRead>(r).a0;
                _v.set(check_types::add_text(acc, m));
                goto _done;
            }
            if (prism_rtl::is<Read::OwnRead>(r)) {
                _v.set(acc);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
}


/// RowWritten: fn Wx, RowMarks, Read -> [Do]
Array<Do> row_written(const Wx& wx, const RowMarks& rm, const Read& r) {
    auto dirty_1 = has_read(reads_closed(wx.dyn_reads, rm.reads), r)
        ? Array(std::vector{Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XCx{})), Text::lit("dirty"), Array(std::vector{Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{Text::lit("row")}))})})})})})
        : Array<Do>{};
    auto told = fold(rm.wrote, Array<Do>{}, [&](const Array<Do>& acc, const Text& m) {
        return has_read(reads_closed(wx.dyn_reads, Array(std::vector{Read(Read::OwnRead{m})})), r)
            ? prelude::push(acc, Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text::lit("row")})), prism_rtl::cat("parent_wrote_", m), Array(std::vector{Ex(Ex::XCx{})})})}))
            : acc;
    });
    auto body = append(dirty_1, told);
    return len(body) == Nat(0u)
        ? Array<Do>{}
        : ({
        __label__ _done;
        prism_rtl::Slot<Array<Do>> _v;
        auto&& _m = rm.kind;
        if (prism_rtl::is<RowKind::GenerationRow>(_m)) {
            _v.set(Array(std::vector{Do(Do::DoIfLet{Pa(Pa::PaCtor{Text::lit("Some"), Array(std::vector{Pa(Pa::PaBind{Text::lit("row")})})}), Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), rm.builder})), Text::lit("borrow"), Array<Ex>{}})), Text::lit("as_ref"), Array<Ex>{}}), body, Array<Do>{}})}));
            goto _done;
        }
        {
            _v.set(Array(std::vector{Do(Do::DoFor{Pa(Pa::PaBind{Text::lit("row")}), Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), rm.builder})), Text::lit("borrow"), Array<Ex>{}})), Text::lit("values"), Array<Ex>{}}), body})}));
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// PatchPlace: fn Wx, Place -> [Do]
Array<Do> patch_place(const Wx& wx, const Place& p_) {
    auto pull = Do(Do::DoLet{Pa(Pa::PaBind{p_.getter}), Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XSelf{})), p_.getter, Array(std::vector{Ex(Ex::XCx{})})})});
    auto at_ = place_at(wx, Text::lit("self"), p_.pos);
    return Array(std::vector{pull, Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XCx{})), Text::lit("changed"), Array(std::vector{at_, Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{p_.getter})), Text::lit("to_pod"), Array<Ex>{}})})})})});
}


/// Emits: fn Wx, Pos -> Bool
bool emits(const Wx& wx, const Pos_& pos) {
    return (pos.scope == Nat(0u)) && (wx.hosted_by == std::optional<Text>{});
}


/// ResultTold: fn Ex -> [Do]
Array<Do> result_told(const Ex& node_) {
    auto r_1 = Do(Do::DoLet{Pa(Pa::PaBind{Text::lit("r")}), Ex(Ex::XMethod{prism_rtl::rc(node_), Text::lit("result_value"), Array(std::vector{Ex(Ex::XCx{})})})});
    return Array(std::vector{r_1, result_kept(node_), result_tell()});
}


/// ResultMoved: fn Ex -> [Do]
Array<Do> result_moved(const Ex& node_) {
    auto r_1 = Do(Do::DoLet{Pa(Pa::PaBind{Text::lit("r")}), Ex(Ex::XMethod{prism_rtl::rc(node_), Text::lit("result_value"), Array(std::vector{Ex(Ex::XCx{})})})});
    auto last = Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(node_), Text::lit("result_last")})), Text::lit("borrow"), Array<Ex>{}})), Text::lit("as_ref"), Array<Ex>{}});
    auto differs = Ex(Ex::XBin{Text::lit("!="), prism_rtl::rc(last), prism_rtl::rc(Ex(Ex::XCtor{Text::lit("Some"), Array(std::vector{Ex(Ex::XRef{prism_rtl::rc(Ex(Ex::XVar{Text::lit("r")}))})})}))});
    return Array(std::vector{r_1, Do(Do::DoIf{differs, Array(std::vector{result_kept(node_), result_tell()}), Array<Do>{}})});
}


/// ResultKept: fn Ex -> Do
Do result_kept(const Ex& node_) {
    return Do(Do::DoAssign{Ex(Ex::XDeref{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(node_), Text::lit("result_last")})), Text::lit("borrow_mut"), Array<Ex>{}}))}), Ex(Ex::XCtor{Text::lit("Some"), Array(std::vector{Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{Text::lit("r")}))})})})});
}


/// let resultTell
Do result_tell() {
    return Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XCx{})), Text::lit("result"), Array(std::vector{Ex(Ex::XCtor{Text::lit("Outcome::Value"), Array(std::vector{Ex(Ex::XVar{Text::lit("r")})})})})})});
}


/// Adoption: fn FlatDef -> [Do]
Array<Do> adoption(const FlatDef& fl) {
    auto adopt = Ex(Ex::XLater{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text::lit("node")})), prism_rtl::cat(fl.name, "_adopt"), Array(std::vector{Ex(Ex::XCx{})})}))});
    return Array(std::vector{Do(Do::DoLet{Pa(Pa::PaBind{Text::lit("node")}), Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XSelf{}))})}), Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XCx{})), Text::lit("answer_later"), Array(std::vector{adopt})})})});
}


/// PlaceAt: fn Wx, Text, Pos -> Ex
Ex place_at(const Wx& wx, const Text& recv, const Pos_& pos) {
    auto at_ = Array(std::vector{Ex(Ex::XIndex{pos.at})});
    return emits(wx, pos)
        ? Ex(Ex::XMethod{prism_rtl::rc(recv == Text::lit("")
        ? Ex(Ex::XVar{Text::lit("path")})
        : recv == Text::lit("self")
        ? Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), Text::lit("path")})
        : Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XVar{recv})), Text::lit("path")})), Text::lit("at"), at_})
        : Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XCall{Text::lit("Path::root"), Array<Ex>{}})), Text::lit("at"), at_});
}


/// PosPat: fn Pos, [Pa] -> Pa
Pa pos_pat(const Pos_& pos, const Array<Pa>& tail_) {
    return Pa(Pa::PaSlice{append(Array(std::vector{Pa(Pa::PaCtor{Text::lit("Segment::Pos"), Array(std::vector{Pa(Pa::PaIndex{pos.at})})})}), tail_)});
}


/// let keyTail
Array<Pa> key_tail() {
    return Array(std::vector{Pa(Pa::PaCtor{Text::lit("Segment::Key"), Array(std::vector{Pa(Pa::PaBind{Text::lit("k")})})}), Pa(Pa::PaRest{Text::lit("rest")})});
}


/// let genTail
Array<Pa> gen_tail() {
    return Array(std::vector{Pa(Pa::PaCtor{Text::lit("Segment::Gen"), Array(std::vector{Pa(Pa::PaBind{Text::lit("g")})})}), Pa(Pa::PaRest{Text::lit("rest")})});
}


/// ?HostedRows: fn Wx -> ?Text
std::optional<Text> hosted_rows(const Wx& wx) {
    return wx.pos.scope > Nat(0u)
        ? std::optional(prism_rtl::cat(or_(index(wx.scopes, lexer::dec(wx.pos.scope)), Text::lit("")), "_moved"))
        : ({
        __label__ _done;
        prism_rtl::Slot<std::optional<Text>> _v;
        auto&& _m = wx.hosted_by;
        if (prism_rtl::is_some(_m)) {
            _v.set(std::optional(Text::lit("document_moved")));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(std::optional<Text>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// RootDynPatch: fn Wx -> [Do]
Array<Do> root_dyn_patch(const Wx& wx) {
    auto&& _m = wx.root_dyn;
    if (prism_rtl::is_some(_m)) {
        return Array(std::vector{Do(Do::DoLine{result_moved(Ex(Ex::XSelf{}))})});
    }
    if (prism_rtl::is_none(_m)) {
        return Array<Do>{};
    }
    prism_rtl::unreachable("no arm matched");
}


/// AnswerArm: fn Wx, Pos, Nat, OutTy -> ((Pa, Ex))
std::tuple<Pa, Ex> answer_arm(const Wx& wx, const Pos_& pos, const Nat& id, const OutTy& t) {
    auto call = Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XSelf{})), gn_of(wx, id).name, Array(std::vector{Ex(Ex::XDecode{t, prism_rtl::rc(Ex(Ex::XVar{Text::lit("v")}))}), Ex(Ex::XCx{})})});
    return std::tuple{pos_pat(pos, Array<Pa>{}), call};
}


/// TypedAnswerArm: fn Wx, Pos, Nat, Text -> ((Pa, [Do]))
std::tuple<Pa, Array<Do>> typed_answer_arm(const Wx& wx, const Pos_& pos, const Nat& id, const Text& acc) {
    return std::tuple{pos_pat(pos, Array<Pa>{}), Array(std::vector{self_call(gn_of(wx, id).name, Array(std::vector{try_of(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text::lit("v")})), acc, Array<Ex>{}}))}))})};
}


/// TypedDynArm: fn Sinks, Pos, Text, Text -> ((Pa, [Do]))
std::tuple<Pa, Array<Do>> typed_dyn_arm(const Sinks& sk, const Pos_& pos, const Text& f, const Text& acc) {
    return std::tuple{pos_pat(pos, Array<Pa>{}), dyn_place_write(sk, f, try_of(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text::lit("v")})), acc, Array<Ex>{}})))};
}


/// TypedForwardArm: fn ForDef, Ex -> ((Pa, [Do]))
std::tuple<Pa, Array<Do>> typed_forward_arm(const ForDef& b, const Ex& segs) {
    auto row_of = Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(b.name)})), Text::lit("borrow"), Array<Ex>{}})), Text::lit("get"), Array(std::vector{Ex(Ex::XRef{prism_rtl::rc(Ex(Ex::XDecode{b.key_ty, prism_rtl::rc(Ex(Ex::XVar{Text::lit("k")}))}))})})})), Text::lit("cloned"), Array<Ex>{}});
    return std::tuple{pos_pat(b.pos, key_tail()), Array(std::vector{Do(Do::DoLet{Pa(Pa::PaBind{Text::lit("row")}), row_of}), Do(Do::DoMatch{Ex(Ex::XVar{Text::lit("row")}), Array(std::vector{std::tuple{Pa(Pa::PaCtor{Text::lit("Some"), Array(std::vector{Pa(Pa::PaBind{Text::lit("row")})})}), Array(std::vector{Do(Do::DoExpr{try_of(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text::lit("row")})), Text::lit("deliver"), Array(std::vector{Ex(Ex::XVar{Text::lit("rest")}), Ex(Ex::XVar{Text::lit("v")}), Ex(Ex::XCx{})})}))})})}, std::tuple{Pa(Pa::PaUnit{Text::lit("None")}), Array(std::vector{Do(Do::DoReturn{Ex(Ex::XCtor{Text::lit("Err"), Array(std::vector{Ex(Ex::XCall{Text::lit("Fault::answer"), Array(std::vector{Ex(Ex::XFormatStr{Array(std::vector{Ex(Ex::XText{Text::lit("no row ")}), Ex(Ex::XVar{Text::lit("k")}), Ex(Ex::XText{Text::lit(" under the hosted place ")}), Ex(Ex::XCtor{Text::lit("Path"), Array(std::vector{Ex(Ex::XMethod{prism_rtl::rc(segs), Text::lit("to_vec"), Array<Ex>{}})})})})})})})})})})})}})})})};
}


/// TypedGenArm: fn GenDef -> ((Pa, [Do]))
std::tuple<Pa, Array<Do>> typed_gen_arm(const GenDef& gd) {
    auto current = Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(gd.name)})), Text::lit("borrow"), Array<Ex>{}}))});
    auto is_current = Ex(Ex::XBin{Text::lit("=="), prism_rtl::rc(Ex(Ex::XBin{Text::lit("+"), prism_rtl::rc(Ex(Ex::XDeref{prism_rtl::rc(Ex(Ex::XVar{Text::lit("g")}))})), prism_rtl::rc(Ex(Ex::XIndex{Nat(1u)}))})), prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(gd.name, "_count")})), Text::lit("get"), Array<Ex>{}}))});
    return std::tuple{pos_pat(gd.pos, gen_tail()), Array(std::vector{Do(Do::DoLet{Pa(Pa::PaBind{Text::lit("row")}), current}), Do(Do::DoIfLet{Pa(Pa::PaCtor{Text::lit("Some"), Array(std::vector{Pa(Pa::PaBind{Text::lit("row")})})}), Ex(Ex::XVar{Text::lit("row")}), Array(std::vector{Do(Do::DoIf{is_current, Array(std::vector{Do(Do::DoExpr{try_of(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text::lit("row")})), Text::lit("deliver"), Array(std::vector{Ex(Ex::XVar{Text::lit("rest")}), Ex(Ex::XVar{Text::lit("v")}), Ex(Ex::XCx{})})}))})}), Array<Do>{}})}), Array<Do>{}})})};
}


/// TypedDispatch: fn Sinks, Text, Nat -> MethDef
MethDef typed_dispatch(const Sinks& sk, const Text& name, const Nat& scope) {
    auto wx = sk.wx;
    auto in_scope_fn = ({
        auto scope_1 = scope;
        (prism_rtl::rc([=](const Pos_& p_) { return p_.scope == scope_1; }));
    });
    auto [recv, param, segs, doc] = scope > Nat(0u)
        ? std::tuple{Recv(Recv::RecvRc{}), std::tuple{Text::lit("place"), OutTy(OutTy::OutRef{prism_rtl::rc(OutTy(OutTy::OutPath{}))})}, Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text::lit("place")})), Text::lit("segments"), Array<Ex>{}}), prism_rtl::cat("The host at place ", place_text(or_(index(wx.hosts, lexer::dec(scope)), dummy_host()).pos), " answers its child's place `place` (pick HO): into the child's input method, a hold the place's element answers, or the row of a `for` or `rebuild` under it.")}
        : std::tuple{Recv(Recv::RecvOwned{}), std::tuple{Text::lit("at"), OutTy(OutTy::OutRef{prism_rtl::rc(OutTy(OutTy::OutSlice{prism_rtl::rc(OutTy(OutTy::OutNamed{Text::lit("Segment"), Array<OutTy>{}}))}))})}, Ex(Ex::XVar{Text::lit("at")}), Text::lit("A host's answer to a place of this row's own, `at` under the row (pick HO): into the input method, a hold, or a row under it.")};
    auto answers = each(filter(wx.answers, [&](const std::tuple<Pos_, Nat, OutTy, Text>& _p0) {
        auto&& pos = std::get<0>(_p0);
        return in_scope_fn(pos);
    }), [&](const std::tuple<Pos_, Nat, OutTy, Text>& _p0) {
        auto&& pos = std::get<0>(_p0);
        auto&& id = std::get<1>(_p0);
        auto&& acc = std::get<3>(_p0);
        return typed_answer_arm(wx, pos, id, acc);
    });
    auto dyns = each(filter(wx.dyn_places, [&](const std::tuple<Pos_, Text, OutTy, Text>& _p0) {
        auto&& pos = std::get<0>(_p0);
        return in_scope_fn(pos);
    }), [&](const std::tuple<Pos_, Text, OutTy, Text>& _p0) {
        auto&& pos = std::get<0>(_p0);
        auto&& f = std::get<1>(_p0);
        auto&& acc = std::get<3>(_p0);
        return typed_dyn_arm(sk, pos, f, acc);
    });
    auto rows = each(filter(wx.builders, [&](const ForDef& b) { return in_scope_fn(b.pos); }), [&](const ForDef& b) { return typed_forward_arm(b, segs); });
    auto gens = each(filter(wx.gens, [&](const GenDef& gd) { return in_scope_fn(gd.pos); }), [&](const GenDef& gd) { return typed_gen_arm(gd); });
    auto none = std::tuple{Pa(Pa::PaWild{}), Array(std::vector{Do(Do::DoReturn{Ex(Ex::XCtor{Text::lit("Err"), Array(std::vector{Ex(Ex::XCall{Text::lit("Fault::answer"), Array(std::vector{Ex(Ex::XFormatStr{Array(std::vector{Ex(Ex::XText{Text::lit("no hosted place at ")}), Ex(Ex::XCtor{Text::lit("Path"), Array(std::vector{Ex(Ex::XMethod{prism_rtl::rc(segs), Text::lit("to_vec"), Array<Ex>{}})})}), Ex(Ex::XText{Text::lit(" to answer")})})})})})})})})})};
    auto arms = prelude::push(append(append(append(answers, dyns), rows), gens), none);
    return MethDef{.name = name, .recv = recv, .params = Array(std::vector{param, std::tuple{Text::lit("v"), OutTy(OutTy::OutRef{prism_rtl::rc(answer_ty_value())})}}), .cx_ = CxArg(CxArg::CxMut{}), .ret = OutTy(OutTy::OutNamed{Text::lit("Done"), Array<OutTy>{}}), .body = Array(std::vector{Do(Do::DoMatch{segs, arms})}), .tail = Ex(Ex::XCtor{Text::lit("Ok"), Array(std::vector{Ex(Ex::XUnit{})})}), .doc = doc};
}


/// let dummyHost
HostDef dummy_host() {
    return HostDef{.pos = pos0(), .name = Text::lit(""), .scope = Nat(0u)};
}


/// SortNats: fn [Nat] -> [Nat]
Array<Nat> sort_nats(const Array<Nat>& xs) {
    return fold(xs, Array<Nat>{}, [&](const Array<Nat>& acc, const Nat& x) { return append(prelude::push(filter(acc, [&](const Nat& y) { return y < x; }), x), filter(acc, [&](const Nat& y) { return !(y < x); })); });
}


/// AskWake: fn Sinks, Nat -> [Do]
Array<Do> ask_wake(const Sinks& sk, const Nat& h) {
    auto c = Ex(Ex::XConst{wake_const(sk.heights, h)});
    auto ask_1 = Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), Text::lit("wakes")})), Text::lit("ask"), Array(std::vector{c})})});
    auto wake_2 = Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XCx{})), Text::lit("wake"), Array(std::vector{c, Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XSelf{}))})})})});
    return sk.many ? Array(std::vector{ask_1, wake_2}) : Array(std::vector{wake_2});
}


/// GatherIn: fn Sinks, Gn -> MethDef
MethDef gather_in(const Sinks& sk, const Gn& g) {
    auto field = or_(index(g.inputs, Nat(0u)), Text::lit(""));
    auto kt = ({
        __label__ _done;
        prism_rtl::Slot<OutTy> _v;
        auto&& _m = g.ty;
        if (prism_rtl::is<OutTy::OutMap>(_m)) {
            auto&& k = prism_rtl::as<OutTy::OutMap>(_m).a0;
            _v.set(k);
            goto _done;
        }
        {
            _v.set(OutTy(OutTy::OutUnit{}));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto vt = ({
        __label__ _done;
        prism_rtl::Slot<OutTy> _v;
        auto&& _m = g.ty;
        if (prism_rtl::is<OutTy::OutMap>(_m)) {
            auto&& v_ = prism_rtl::as<OutTy::OutMap>(_m).a1;
            _v.set(v_);
            goto _done;
        }
        {
            _v.set(OutTy(OutTy::OutUnit{}));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto current = Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(field)})), Text::lit("get"), Array(std::vector{Ex(Ex::XCx{})})})), Text::lit("unwrap_or_default"), Array<Ex>{}});
    auto collect = Array(std::vector{Do(Do::DoLet{Pa(Pa::PaMut{Text::lit("all")}), current}), Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text::lit("all")})), Text::lit("insert"), Array(std::vector{Ex(Ex::XVar{Text::lit("k")}), Ex(Ex::XVar{Text::lit("v")})})})}), Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(field)})), Text::lit("set"), Array(std::vector{Ex(Ex::XVar{Text::lit("all")}), Ex(Ex::XCx{})})})})});
    auto body = append(collect, ask_wake(sk, g.height));
    return MethDef{.name = prism_rtl::cat(g.name, "_in"), .recv = Recv(Recv::RecvRc{}), .params = Array(std::vector{std::tuple{Text::lit("k"), kt}, std::tuple{Text::lit("v"), vt}}), .cx_ = CxArg(CxArg::CxMut{}), .ret = OutTy(OutTy::OutUnit{}), .body = body, .tail = Ex(Ex::XUnit{}), .doc = Text::lit("A row's firing, gathered by its key.")};
}


/// Decide: fn Gn -> Do
Do decide(const Gn& g) {
    auto&& _m = g.kind;
    if (prism_rtl::is<GnKind::GnGather>(_m)) {
        return Do(Do::DoIfLet{Pa(Pa::PaCtor{Text::lit("Some"), Array(std::vector{Pa(Pa::PaBind{Text::lit("v")})})}), Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(or_(index(g.inputs, Nat(0u)), Text::lit("")))})), Text::lit("take"), Array(std::vector{Ex(Ex::XCx{})})}), Array(std::vector{self_call(g.name, Array(std::vector{Ex(Ex::XVar{Text::lit("v")})}))}), Array<Do>{}});
    }
    if (prism_rtl::is<GnKind::GnMerge>(_m)) {
        return merge_decide(g);
    }
    if (prism_rtl::is<GnKind::GnUpdated>(_m)) {
        return updated_decide(g);
    }
    if (prism_rtl::is<GnKind::GnMergeAll>(_m)) {
        auto pushes = each(g.inputs, [&](const Text& f) { return Do(Do::DoIfLet{Pa(Pa::PaCtor{Text::lit("Some"), Array(std::vector{Pa(Pa::PaBind{Text::lit("x")})})}), Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(f)})), Text::lit("take"), Array(std::vector{Ex(Ex::XCx{})})}), Array(std::vector{Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text::lit("all")})), Text::lit("push_back"), Array(std::vector{Ex(Ex::XVar{Text::lit("x")})})})})}), Array<Do>{}}); });
        auto start = Do(Do::DoLet{Pa(Pa::PaTyped{prism_rtl::rc(Pa(Pa::PaMut{Text::lit("all")})), g.ty}), Ex(Ex::XCall{Text::lit("Array::new"), Array<Ex>{}})});
        auto fire = Do(Do::DoIf{Ex(Ex::XUnary{Text::lit("!"), prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text::lit("all")})), Text::lit("is_empty"), Array<Ex>{}}))}), Array(std::vector{self_call(g.name, Array(std::vector{Ex(Ex::XVar{Text::lit("all")})}))}), Array<Do>{}});
        return Do(Do::DoBlock{prelude::push(append(Array(std::vector{start}), pushes), fire)});
    }
    {
        auto&& kind = _m;
        return pair_decide(g, kind);
    }
}


/// UpdatedDecide: fn Gn -> Do
Do updated_decide(const Gn& g) {
    return Do(Do::DoIf{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(g.name, "_moved")})), Text::lit("replace"), Array(std::vector{Ex(Ex::XBool{false})})}), Array(std::vector{Do(Do::DoLet{Pa(Pa::PaBind{Text::lit("after")}), Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XCx{})), Text::lit("after"), Array(std::vector{Ex(Ex::XClosure{false, Array(std::vector{Pa(Pa::PaBind{Text::lit("cx")})}), prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(g.name, "_value"), Array(std::vector{Ex(Ex::XCx{})})}))})})})}), self_call(g.name, Array(std::vector{Ex(Ex::XVar{Text::lit("after")})}))}), Array<Do>{}});
}


/// PairDecide: fn Gn, GnKind -> Do
Do pair_decide(const Gn& g, const GnKind& kind) {
    auto get_l = Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(or_(index(g.inputs, Nat(0u)), Text::lit("")))})), Text::lit("take"), Array(std::vector{Ex(Ex::XCx{})})});
    auto get_r = Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(or_(index(g.inputs, Nat(1u)), Text::lit("")))})), Text::lit("take"), Array(std::vector{Ex(Ex::XCx{})})});
    auto both_ = Ex(Ex::XTuple{Array(std::vector{get_l, get_r})});
    auto fire_fn = ({
        auto g_1 = g;
        (prism_rtl::rc([=](const Ex& x) { return Array(std::vector{self_call(g_1.name, Array(std::vector{x}))}); }));
    });
    auto sa = Pa(Pa::PaCtor{Text::lit("Some"), Array(std::vector{Pa(Pa::PaBind{Text::lit("a")})})});
    auto sb = Pa(Pa::PaCtor{Text::lit("Some"), Array(std::vector{Pa(Pa::PaBind{Text::lit("b")})})});
    auto some2 = Pa(Pa::PaTuple{Array(std::vector{sa, sb})});
    auto left = Pa(Pa::PaTuple{Array(std::vector{sa, Pa(Pa::PaUnit{Text::lit("None")})})});
    auto right = Pa(Pa::PaTuple{Array(std::vector{Pa(Pa::PaUnit{Text::lit("None")}), sb})});
    auto cases = ({
        __label__ _done;
        prism_rtl::Slot<Array<std::tuple<Pa, Array<Do>>>> _v;
        if (prism_rtl::is<GnKind::GnUnion>(kind)) {
            _v.set(Array(std::vector{std::tuple{some2, fire_fn(Ex(Ex::XCall{Text::lit("union"), Array(std::vector{Ex(Ex::XRef{prism_rtl::rc(Ex(Ex::XVar{Text::lit("a")}))}), Ex(Ex::XRef{prism_rtl::rc(Ex(Ex::XVar{Text::lit("b")}))})})}))}, std::tuple{left, fire_fn(Ex(Ex::XVar{Text::lit("a")}))}, std::tuple{right, fire_fn(Ex(Ex::XVar{Text::lit("b")}))}, std::tuple{Pa(Pa::PaWild{}), Array<Do>{}}}));
            goto _done;
        }
        if (prism_rtl::is<GnKind::GnBoth>(kind)) {
            _v.set(Array(std::vector{std::tuple{some2, fire_fn(Ex(Ex::XTuple{Array(std::vector{Ex(Ex::XVar{Text::lit("a")}), Ex(Ex::XVar{Text::lit("b")})})}))}, std::tuple{Pa(Pa::PaWild{}), Array<Do>{}}}));
            goto _done;
        }
        {
            _v.set(Array(std::vector{std::tuple{left, fire_fn(Ex(Ex::XVar{Text::lit("a")}))}, std::tuple{Pa(Pa::PaWild{}), Array<Do>{}}}));
            goto _done;
        }
    _done:
        _v.take();
    });
    return Do(Do::DoMatch{both_, cases});
}


/// WakeByHeight: fn [Gn], [Nat] -> Do
Do wake_by_height(const Array<Gn>& combs, const Array<Nat>& heights_) {
    return Do(Do::DoMatch{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), Text::lit("wakes")})), Text::lit("next"), Array<Ex>{}}), prelude::push(each(heights_, [&](const Nat& h) { return std::tuple{Pa(Pa::PaConst{wake_const(heights_, h)}), each(filter(combs, [&](const Gn& g) { return g.height == h; }), [&](const Gn& g) { return decide(g); })}; }), std::tuple{Pa(Pa::PaWild{}), Array<Do>{}})});
}


/// ForwardAnswer: fn ForDef -> Ex
Ex forward_answer(const ForDef& b) {
    auto row_of = Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(b.name)})), Text::lit("borrow"), Array<Ex>{}})), Text::lit("get"), Array(std::vector{Ex(Ex::XRef{prism_rtl::rc(Ex(Ex::XDecode{b.key_ty, prism_rtl::rc(Ex(Ex::XVar{Text::lit("k")}))}))})})})), Text::lit("cloned"), Array<Ex>{}});
    return Ex(Ex::XBlock{Array(std::vector{Do(Do::DoLet{Pa(Pa::PaBind{Text::lit("row")}), row_of}), Do(Do::DoIfLet{Pa(Pa::PaCtor{Text::lit("Some"), Array(std::vector{Pa(Pa::PaBind{Text::lit("row")})})}), Ex(Ex::XVar{Text::lit("row")}), Array(std::vector{Do(Do::DoExpr{try_of(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text::lit("row")})), Text::lit("answer"), Array(std::vector{Ex(Ex::XVar{Text::lit("rest")}), Ex(Ex::XVar{Text::lit("v")}), Ex(Ex::XCx{})})}))})}), Array<Do>{}})}), prism_rtl::rc(Ex(Ex::XUnit{}))});
}


/// IsHold: fn OutTy -> Bool
bool is_hold(const OutTy& out_ty0) {
    if (prism_rtl::is<OutTy::OutHold>(out_ty0)) {
        return true;
    }
    {
        auto&& other = out_ty0;
        return false;
    }
}


/// RowMethods: fn Wx -> [MethDef]
Array<MethDef> row_methods(const Wx& wx) {
    auto removes = each(filter(wx.places, [&](const Place& p_) { return emits(wx, p_.pos); }), [&](const Place& p_) { return Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XCx{})), Text::lit("removed"), Array(std::vector{place_at(wx, Text::lit("self"), p_.pos)})})}); });
    auto nested = append(each(wx.builders, [&](const ForDef& b) { return Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), b.name})), Text::lit("borrow"), Array<Ex>{}})), Text::lit("values"), Array<Ex>{}})), Text::lit("for_each"), Array(std::vector{Ex(Ex::XClosure{false, Array(std::vector{Pa(Pa::PaBind{Text::lit("row")})}), prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text::lit("row")})), Text::lit("leave_row"), Array(std::vector{Ex(Ex::XCx{})})}))})})})}); }), each(wx.gens, [&](const GenDef& gd) { return Do(Do::DoIfLet{Pa(Pa::PaCtor{Text::lit("Some"), Array(std::vector{Pa(Pa::PaBind{Text::lit("row")})})}), Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), gd.name})), Text::lit("borrow"), Array<Ex>{}})), Text::lit("as_ref"), Array<Ex>{}}), Array(std::vector{Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text::lit("row")})), Text::lit("leave_row"), Array(std::vector{Ex(Ex::XCx{})})})})}), Array<Do>{}}); }));
    return Array(std::vector{MethDef{.name = Text::lit("remove_places"), .recv = Recv(Recv::RecvRef{}), .params = Array<std::tuple<Text, OutTy>>{}, .cx_ = CxArg(CxArg::CxMut{}), .ret = OutTy(OutTy::OutUnit{}), .body = append(removes, nested), .tail = Ex(Ex::XUnit{}), .doc = Text::lit("The row left: its places are torn down.")}});
}


/// GnDoc: fn Gn -> Text
Text gn_doc(const Gn& g) {
    auto&& _m = g.kind;
    if (prism_rtl::is<GnKind::GnAnswer>(_m)) {
        return prism_rtl::cat("`", g.name, "`: an answer at its place.");
    }
    if (prism_rtl::is<GnKind::GnStarted>(_m)) {
        return Text::lit("`@started`, the tick after the build.");
    }
    if (prism_rtl::is<GnKind::GnDeferred>(_m)) {
        return Text::lit("An `@Defer` firing, the tick after it was armed.");
    }
    if (prism_rtl::is<GnKind::GnMerge>(_m)) {
        return prism_rtl::cat("The merge `", g.name, "`, decided in the wake.");
    }
    if (prism_rtl::is<GnKind::GnUpdated>(_m)) {
        return Text::lit("`!Updated`: the dynamic's value after the tick, fired in the wake when a hold it reads was written (or a structural dynamic it reads was published, pick ST).");
    }
    {
        return prism_rtl::cat("`!", g.name, "`.");
    }
}


/// MergeDecide: fn Gn -> Do
Do merge_decide(const Gn& g) {
    auto call = Array(std::vector{self_call(g.name, Array(std::vector{Ex(Ex::XVar{Text::lit("v")})}))});
    auto take_l = Do(Do::DoLet{Pa(Pa::PaBind{Text::lit("left")}), Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(or_(index(g.inputs, Nat(0u)), Text::lit("")))})), Text::lit("take"), Array(std::vector{Ex(Ex::XCx{})})})});
    auto take_r = Do(Do::DoLet{Pa(Pa::PaBind{Text::lit("right")}), Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(or_(index(g.inputs, Nat(1u)), Text::lit("")))})), Text::lit("take"), Array(std::vector{Ex(Ex::XCx{})})})});
    auto right_1 = Do(Do::DoIfLet{Pa(Pa::PaCtor{Text::lit("Some"), Array(std::vector{Pa(Pa::PaBind{Text::lit("v")})})}), Ex(Ex::XVar{Text::lit("right")}), call, Array<Do>{}});
    return Do(Do::DoBlock{Array(std::vector{take_l, take_r, Do(Do::DoIfLet{Pa(Pa::PaCtor{Text::lit("Some"), Array(std::vector{Pa(Pa::PaBind{Text::lit("v")})})}), Ex(Ex::XVar{Text::lit("left")}), call, Array(std::vector{right_1})})})});
}


/// InModule: fn Lx, Nat, Text -> Lx
Lx in_module(const Lx& lx, const Nat& file, const Text& home) {
    Lx this_ = lx;
    this_.file = file;
    this_.home = home;
    this_.site = home;
    return this_;
}


/// InModuleAt: fn Lx, Nat, Text, Text -> Lx
Lx in_module_at(const Lx& lx, const Nat& file, const Text& home, const Text& site) {
    Lx this_ = lx;
    this_.file = file;
    this_.home = home;
    this_.site = site;
    return this_;
}


/// LowerProgram: unbounded fn [Src], [Module], Nat, TProgram, Text -> Model
Model lower_program(const Array<check_errors::Src>& srcs, const Array<ast::Module>& trees, const Nat& shown, const typed::TProgram& tp, const Text& name) {
    auto&& _g = check_env::build_g(srcs, trees);
    auto&& g = std::get<0>(_g);
    auto [tys, apps, bs, ims] = typed_tables(tp);
    auto gens = fold(tp.gens, Map<Text, typed::GenNote>{}, [&](const Map<Text, typed::GenNote>& m, const typed::GenNote& n) { return insert(m, typed::at_key(n.at), n); });
    auto insts = fold(tp.insts, Map<Text, Array<typed::InstNote>>{}, [&](const Map<Text, Array<typed::InstNote>>& m, const typed::InstNote& n) { return insert(m, inst_key(n), prelude::push(or_(prelude::get(m, inst_key(n)), Array<typed::InstNote>{}), n)); });
    auto quants = fold(tp.gens, Map<Text, Text>{}, [&](const Map<Text, Text>& m, const typed::GenNote& n) { return fold(append(n.tys, n.cols), m, [&](const Map<Text, Text>& m2, const Text& q) { return insert(m2, q, n.name); }); });
    auto gen_of_q = fold(tp.gens, Map<Text, typed::GenNote>{}, [&](const Map<Text, typed::GenNote>& m, const typed::GenNote& n) { return fold(append(n.tys, n.cols), m, [&](const Map<Text, typed::GenNote>& m2, const Text& q) { return insert(m2, q, n); }); });
    auto use_insts = fold(tp.insts, Map<Text, typed::InstNote>{}, [&](const Map<Text, typed::InstNote>& m, const typed::InstNote& n) { return insert(m, typed::at_key(n.at), n); });
    auto mods = needed_mods(g, shown);
    auto rs_mods = fold(mods, Map<Text, Text>{}, [&](const Map<Text, Text>& acc, const Text& m) { return insert(acc, m, rust_mod_name(m)); });
    auto lx0 = Lx{.g = g, .tys = tys, .apps = apps, .binders = bs, .impls = ims, .file = Nat(0u), .home = Text::lit(""), .site = Text::lit(""), .rs_mods = rs_mods, .rs_names = value_names(g), .layouts = layouts(g), .unbs = Array<Text>{}, .notes = Array<Text>{}, .globals = global_names(g), .in_node = false, .unshrunk = fold(tp.unshrunk, Map<Text, bool>{}, [&](const Map<Text, bool>& m, const typed::SrcAt& a) { return insert(m, typed::at_key(a), true); }), .gens = gens, .insts = insts, .quants = quants, .gen_of_q = gen_of_q, .use_insts = use_insts, .subst = Map<Text, check_types::Ty>{}, .csubst = Map<Text, check_types::Col>{}};
    auto lx = ({
        Lx this_ = lx0;
        this_.unbs = job_roots(lx0);
        this_;
    });
    auto roots = root_widgets(lx);
    auto mod_defs = run_to_end(each_job(mods, ({
        auto lx_1 = lx;
        auto roots_2 = roots;
        auto g_3 = g;
        auto mods_4 = mods;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<ModDef>(Text)>>(prism_rtl::rc([=](Text p0) {
        return ({
            auto lx_1_5 = lx_1;
            auto roots_2_5 = roots_2;
            auto g_3_5 = g_3;
            auto mods_4_5 = mods_4;
            entered(once_job([=]() {
            return ({
                auto m = p0;
                (prism_rtl::more(prism_rtl::rc(ModDefOf(lx_1_5, m, roots_2_5, or_(prelude::get(g_3_5.mods, m), check_env::dummy_mod()), mods_4_5))));
            });
        }));
        });
    })));
    })));
    auto programs = run_to_end(each_job(roots, ({
        auto lx_1 = lx;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<ProgDef>(std::tuple<Text, bool>)>>(prism_rtl::rc([=](std::tuple<Text, bool> p0) {
        return ({
            auto lx_1_2 = lx_1;
            entered(once_job([=]() {
            return ({
                auto&& _qk = p0;
                auto&& qk = std::get<0>(_qk);
                (prism_rtl::more(prism_rtl::rc(ProgDefOf(lx_1_2, qk))));
            });
        }));
        });
    })));
    })));
    auto main_qk = fold(g.defs, Text::lit(""), [&](const Text& found, const check_env::Def& d) { return (found == Text::lit("")) && is_main(d.qk) ? d.qk : found; });
    auto root_opt = main_qk == Text::lit("")
        ? std::optional<ProgDef>{}
        : std::optional(prog_def_of(lx, main_qk));
    auto checks = run_to_end(fold_job(g.defs, Array<CheckDef>{}, ({
        auto lx_1 = lx;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<CheckDef>>(std::tuple<Array<CheckDef>, check_env::Def>)>>(prism_rtl::rc([=](std::tuple<Array<CheckDef>, check_env::Def> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_1_2 = lx_1;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto d = p1;
                ({
                auto&& _m = d.body;
                prism_rtl::is<check_env::DefBody::DbCheck>(_m) ? ({
                auto&& c = prism_rtl::as<check_env::DefBody::DbCheck>(_m).a0;
                ({
                auto c_2 = c;
                call_then(start_check_def_of(in_module_at(lx_1_2, d->file, d.home, Text::lit("\000main"sv)), c_2), [=](CheckDef check_def_of_318514) { return prism_rtl::finished(prelude::push(acc, check_def_of_318514)); });
            });
            })
                : prism_rtl::finished(acc);
            });
            });
        }));
        });
    })));
    })));
    auto with_needs_ = with_groups(with_needs(g, srcs, tp, mod_defs));
    auto elem = elem_row(lx, mods);
    auto answer = answer_enum(in_module_at(lx, Nat(0u), Text::lit(""), Text::lit("\000main"sv)), mods);
    auto names = each(with_needs_, [&](const ModDef& d) { return d.name; });
    auto value_tys = value_types(with_needs_);
    auto elem_held = fold(elem.cases_, Array<Text>{}, [&](const Array<Text>& acc, const std::tuple<Text, Text>& _p1) {
        auto&& sp = std::get<1>(_p1);
        return check_types::union_texts(acc, held_in(names, value_tys, Text::lit(""), OutTy(OutTy::OutNamed{sp, Array<OutTy>{}})));
    });
    auto answer_held = fold(answer.cases_, elem_held, [&](const Array<Text>& acc, const AnswerCase& k) { return check_types::union_texts(acc, held_in(names, value_tys, Text::lit(""), k.ty)); });
    auto answer_named = fold(answer.cases_, Array<Text>{}, [&](const Array<Text>& acc, const AnswerCase& k) { return check_types::union_texts(acc, named_in(names, Text::lit(""), k.ty)); });
    return Model{.name = name, .mods = with_needs_, .programs = programs, .root = root_opt, .checks = checks, .elem = elem, .answer = answer, .elem_complete = answer_held, .elem_declared = check_types::minus_texts(answer_named, answer_held), .scripts = Array<Text>{}, .notes = Array<Text>{}};
}


prism_rtl::Turn<Model> LowerProgram::cycle() const {
    const auto& srcs = this->srcs;
    const auto& trees = this->trees;
    const auto& shown = this->shown;
    const auto& tp = this->tp;
    const auto& name = this->name;
    auto name_1 = name;
    auto shown_2 = shown;
    auto srcs_3 = srcs;
    auto tp_4 = tp;
    auto trees_5 = trees;
    return call_then(check_env::start_build_g(srcs_3, trees_5), [=](std::tuple<check_env::G, check_types::St> build_g_317023) {
        return ({
            auto&& _g = build_g_317023;
            auto&& g = std::get<0>(_g);
            auto [tys, apps, bs, ims] = typed_tables(tp_4);
            auto gens = fold(tp_4.gens, Map<Text, typed::GenNote>{}, [&](const Map<Text, typed::GenNote>& m, const typed::GenNote& n) { return insert(m, typed::at_key(n.at), n); });
            auto insts = fold(tp_4.insts, Map<Text, Array<typed::InstNote>>{}, [&](const Map<Text, Array<typed::InstNote>>& m, const typed::InstNote& n) { return insert(m, inst_key(n), prelude::push(or_(prelude::get(m, inst_key(n)), Array<typed::InstNote>{}), n)); });
            auto quants = fold(tp_4.gens, Map<Text, Text>{}, [&](const Map<Text, Text>& m, const typed::GenNote& n) { return fold(append(n.tys, n.cols), m, [&](const Map<Text, Text>& m2, const Text& q) { return insert(m2, q, n.name); }); });
            auto gen_of_q = fold(tp_4.gens, Map<Text, typed::GenNote>{}, [&](const Map<Text, typed::GenNote>& m, const typed::GenNote& n) { return fold(append(n.tys, n.cols), m, [&](const Map<Text, typed::GenNote>& m2, const Text& q) { return insert(m2, q, n); }); });
            auto use_insts = fold(tp_4.insts, Map<Text, typed::InstNote>{}, [&](const Map<Text, typed::InstNote>& m, const typed::InstNote& n) { return insert(m, typed::at_key(n.at), n); });
            call_then(start_needed_mods(g, shown_2), [=](Array<Text> needed_mods_317549) {
            return ({
                auto mods = needed_mods_317549;
                auto rs_mods = fold(mods, Map<Text, Text>{}, [&](const Map<Text, Text>& acc, const Text& m) { return insert(acc, m, rust_mod_name(m)); });
                call_then(start_layouts(g), [=](Map<Text, Array<bool>> layouts_317781) {
                return ({
                    auto lx0 = Lx{.g = g, .tys = tys, .apps = apps, .binders = bs, .impls = ims, .file = Nat(0u), .home = Text::lit(""), .site = Text::lit(""), .rs_mods = rs_mods, .rs_names = value_names(g), .layouts = layouts_317781, .unbs = Array<Text>{}, .notes = Array<Text>{}, .globals = global_names(g), .in_node = false, .unshrunk = fold(tp_4.unshrunk, Map<Text, bool>{}, [&](const Map<Text, bool>& m, const typed::SrcAt& a) { return insert(m, typed::at_key(a), true); }), .gens = gens, .insts = insts, .quants = quants, .gen_of_q = gen_of_q, .use_insts = use_insts, .subst = Map<Text, check_types::Ty>{}, .csubst = Map<Text, check_types::Col>{}};
                    auto lx = ({
                        Lx this_ = lx0;
                        this_.unbs = job_roots(lx0);
                        this_;
                    });
                    auto roots = root_widgets(lx);
                    call_value(each_job(mods, ({
                    auto lx_6 = lx;
                    auto roots_7 = roots;
                    auto g_8 = g;
                    auto mods_9 = mods;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<ModDef>(Text)>>(prism_rtl::rc([=](Text p0) {
                    return ({
                        auto lx_6_10 = lx_6;
                        auto roots_7_10 = roots_7;
                        auto g_8_10 = g_8;
                        auto mods_9_10 = mods_9;
                        entered(once_job([=]() {
                        return ({
                            auto m = p0;
                            (prism_rtl::more(prism_rtl::rc(ModDefOf(lx_6_10, m, roots_7_10, or_(prelude::get(g_8_10.mods, m), check_env::dummy_mod()), mods_9_10))));
                        });
                    }));
                    });
                })));
                })), [=](Array<ModDef> each_318123) {
                    return ({
                        auto mod_defs = each_318123;
                        call_value(each_job(roots, ({
                        auto lx_6 = lx;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<ProgDef>(std::tuple<Text, bool>)>>(prism_rtl::rc([=](std::tuple<Text, bool> p0) {
                        return ({
                            auto lx_6_7 = lx_6;
                            entered(once_job([=]() {
                            return ({
                                auto&& _qk = p0;
                                auto&& qk = std::get<0>(_qk);
                                (prism_rtl::more(prism_rtl::rc(ProgDefOf(lx_6_7, qk))));
                            });
                        }));
                        });
                    })));
                    })), [=](Array<ProgDef> each_318212) {
                        return ({
                            auto programs = each_318212;
                            auto main_qk = fold(g.defs, Text::lit(""), [&](const Text& found, const check_env::Def& d) { return (found == Text::lit("")) && is_main(d.qk) ? d.qk : found; });
                            auto root_opt = main_qk == Text::lit("")
                                ? std::optional<ProgDef>{}
                                : std::optional(prog_def_of(lx, main_qk));
                            call_value(fold_job(g.defs, Array<CheckDef>{}, ({
                            auto lx_6 = lx;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<CheckDef>>(std::tuple<Array<CheckDef>, check_env::Def>)>>(prism_rtl::rc([=](std::tuple<Array<CheckDef>, check_env::Def> _p0) {
                            auto&& p0 = std::get<0>(_p0);
                            auto&& p1 = std::get<1>(_p0);
                            return ({
                                auto lx_6_7 = lx_6;
                                entered(once_job([=]() {
                                return ({
                                    auto acc = p0;
                                    auto d = p1;
                                    ({
                                    auto&& _m = d.body;
                                    prism_rtl::is<check_env::DefBody::DbCheck>(_m) ? ({
                                    auto&& c = prism_rtl::as<check_env::DefBody::DbCheck>(_m).a0;
                                    ({
                                    auto c_7 = c;
                                    call_then(start_check_def_of(in_module_at(lx_6_7, d->file, d.home, Text::lit("\000main"sv)), c_7), [=](CheckDef check_def_of_318514) { return prism_rtl::finished(prelude::push(acc, check_def_of_318514)); });
                                });
                                })
                                    : prism_rtl::finished(acc);
                                });
                                });
                            }));
                            });
                        })));
                        })), [=](Array<CheckDef> fold_318441) {
                            return ({
                                auto checks = fold_318441;
                                call_then(start_with_needs(g, srcs_3, tp_4, mod_defs), [=](Array<ModDef> with_needs_318629) {
                                return call_then(start_with_groups(with_needs_318629), [=](Array<ModDef> with_groups_318617) {
                                    return ({
                                        auto with_needs_ = with_groups_318617;
                                        call_then(start_elem_row(lx, mods), [=](RowDef elem_row_318676) {
                                        return ({
                                            auto elem = elem_row_318676;
                                            call_then(start_answer_enum(in_module_at(lx, Nat(0u), Text::lit(""), Text::lit("\000main"sv)), mods), [=](AnswerDef answer_enum_318710) {
                                            return ({
                                                auto answer = answer_enum_318710;
                                                auto names = each(with_needs_, [&](const ModDef& d) { return d.name; });
                                                auto value_tys = value_types(with_needs_);
                                                auto elem_held = fold(elem.cases_, Array<Text>{}, [&](const Array<Text>& acc, const std::tuple<Text, Text>& _p1) {
                                                    auto&& sp = std::get<1>(_p1);
                                                    return check_types::union_texts(acc, held_in(names, value_tys, Text::lit(""), OutTy(OutTy::OutNamed{sp, Array<OutTy>{}})));
                                                });
                                                auto answer_held = fold(answer.cases_, elem_held, [&](const Array<Text>& acc, const AnswerCase& k) { return check_types::union_texts(acc, held_in(names, value_tys, Text::lit(""), k.ty)); });
                                                auto answer_named = fold(answer.cases_, Array<Text>{}, [&](const Array<Text>& acc, const AnswerCase& k) { return check_types::union_texts(acc, named_in(names, Text::lit(""), k.ty)); });
                                                (prism_rtl::finished(Model{.name = name_1, .mods = with_needs_, .programs = programs, .root = root_opt, .checks = checks, .elem = elem, .answer = answer, .elem_complete = answer_held, .elem_declared = check_types::minus_texts(answer_named, answer_held), .scripts = Array<Text>{}, .notes = Array<Text>{}}));
                                            });
                                        });
                                        });
                                    });
                                    });
                                });
                            });
                            });
                        });
                        });
                    });
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start LowerProgram, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Model> start_lower_program(Array<check_errors::Src> srcs, Array<ast::Module> trees, Nat shown, typed::TProgram tp, Text name) {
    return prism_rtl::make_rc<LowerProgram>(srcs, trees, shown, tp, name);
}


/// WithNeeds: unbounded fn G, [Src], TProgram, [ModDef] -> [ModDef]
Array<ModDef> with_needs(const check_env::G& g, const Array<check_errors::Src>& srcs, const typed::TProgram& tp, const Array<ModDef>& defs) {
    auto names = each(defs, [&](const ModDef& d) { return d.name; });
    auto value_tys = value_types(defs);
    auto refs = named_mods(g, srcs, tp, each(defs, [&](const ModDef& d) { return d.prism; }));
    return run_to_end(each_job(defs, ({
        auto names_1 = names;
        auto value_tys_2 = value_tys;
        auto refs_3 = refs;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<ModDef>(ModDef)>>(prism_rtl::rc([=](ModDef p0) {
        return ({
            auto names_1_4 = names_1;
            auto value_tys_2_4 = value_tys_2;
            auto refs_3_4 = refs_3;
            entered(once_job([=]() {
            return ({
                auto d = p0;
                ({
                auto held = fold(d.items, Array<Text>{}, [&](const Array<Text>& acc, const Item& it) { return check_types::union_texts(acc, item_held(names_1_4, value_tys_2_4, d.name, it)); });
                auto complete = filter(held, [&](const Text& n) { return n != d.name; });
                call_then(start_reached_by(refs_3_4, Array(std::vector{d.prism}), Array<Text>{}), [=](Array<Text> reached_by_319924) {
                return ({
                    auto reached = each(reached_by_319924, [&](const Text& m) { return rust_mod_name(m); });
                    auto declared = filter(names_1_4, [&](const Text& n) { return ((n != d.name) && check_types::has_text(reached, n)) && (!check_types::has_text(complete, n)); });
                    (prism_rtl::finished(({
                    ModDef this_ = d;
                    this_.complete = complete;
                    this_.declared = declared;
                    this_;
                })));
                });
            });
            });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<Array<ModDef>> WithNeeds::cycle() const {
    const auto& g = this->g;
    const auto& srcs = this->srcs;
    const auto& tp = this->tp;
    const auto& defs = this->defs;
    auto names = each(defs, [&](const ModDef& d) { return d.name; });
    auto value_tys = value_types(defs);
    auto defs_1 = defs;
    auto g_2 = g;
    auto srcs_3 = srcs;
    auto tp_4 = tp;
    return call_then(start_named_mods(g_2, srcs_3, tp_4, each(defs_1, [&](const ModDef& d) { return d.prism; })), [=](Map<Text, Array<Text>> named_mods_319669) {
        return ({
            auto refs = named_mods_319669;
            each_job(defs_1, ({
            auto names_5 = names;
            auto value_tys_6 = value_tys;
            auto refs_7 = refs;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<ModDef>(ModDef)>>(prism_rtl::rc([=](ModDef p0) {
            return ({
                auto names_5_8 = names_5;
                auto value_tys_6_8 = value_tys_6;
                auto refs_7_8 = refs_7;
                entered(once_job([=]() {
                return ({
                    auto d = p0;
                    ({
                    auto held = fold(d.items, Array<Text>{}, [&](const Array<Text>& acc, const Item& it) { return check_types::union_texts(acc, item_held(names_5_8, value_tys_6_8, d.name, it)); });
                    auto complete = filter(held, [&](const Text& n) { return n != d.name; });
                    call_then(start_reached_by(refs_7_8, Array(std::vector{d.prism}), Array<Text>{}), [=](Array<Text> reached_by_319924) {
                    return ({
                        auto reached = each(reached_by_319924, [&](const Text& m) { return rust_mod_name(m); });
                        auto declared = filter(names_5_8, [&](const Text& n) { return ((n != d.name) && check_types::has_text(reached, n)) && (!check_types::has_text(complete, n)); });
                        (prism_rtl::finished(({
                        ModDef this_ = d;
                        this_.complete = complete;
                        this_.declared = declared;
                        this_;
                    })));
                    });
                });
                });
                });
            }));
            });
        })));
        }))->cycle();
        });
    });
}


/// `Start WithNeeds, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<ModDef>> start_with_needs(check_env::G g, Array<check_errors::Src> srcs, typed::TProgram tp, Array<ModDef> defs) {
    return prism_rtl::make_rc<WithNeeds>(g, srcs, tp, defs);
}


/// NamedMods: unbounded fn G, [Src], TProgram, [Text] -> (Text ==> [Text])
Map<Text, Array<Text>> named_mods(const check_env::G& g, const Array<check_errors::Src>& srcs, const typed::TProgram& tp, const Array<Text>& ms) {
    auto by_path = fold(values(g.mods), Map<Text, Text>{}, [&](const Map<Text, Text>& acc, const check_env::ModInfo& info) { return insert(acc, or_(index(srcs, info->file), check_errors::mk_src(Text::lit(""), Text::lit("")))->path_, info.name); });
    auto by_file = fold(values(g.mods), Map<Nat, Text>{}, [&](const Map<Nat, Text>& acc, const check_env::ModInfo& info) { return insert(acc, info->file, info.name); });
    auto solved = fold(tp.impls, Map<Text, Array<Text>>{}, [&](const Map<Text, Array<Text>>& acc, const typed::ImplNote& n) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Map<Text, Array<Text>>> _v;
            auto&& _m = prelude::get(by_file, n.at->file);
            if (prism_rtl::is_some(_m)) {
                auto&& site = prism_rtl::some_of(_m);
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Map<Text, Array<Text>>> _v;
                    auto&& _m = prelude::get(by_path, impl_path(n.how));
                    if (prism_rtl::is_some(_m)) {
                        auto&& home = prism_rtl::some_of(_m);
                        _v.set((home == site) || check_types::has_text(or_(prelude::get(acc, site), Array<Text>{}), home)
                            ? acc
                            : insert(acc, site, prelude::push(or_(prelude::get(acc, site), Array<Text>{}), home)));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(acc);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(acc);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
    return run_to_end(fold_job(ms, Map<Text, Array<Text>>{}, ({
        auto g_1 = g;
        auto srcs_2 = srcs;
        auto ms_3 = ms;
        auto solved_4 = solved;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Array<Text>>>(std::tuple<Map<Text, Array<Text>>, Text>)>>(prism_rtl::rc([=](std::tuple<Map<Text, Array<Text>>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_1_5 = g_1;
            auto srcs_2_5 = srcs_2;
            auto ms_3_5 = ms_3;
            auto solved_4_5 = solved_4;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto m = p1;
                ({
                auto&& _m = prelude::get(g_1_5.mods, m);
                prism_rtl::is_some(_m) ? ({
                auto&& info = prism_rtl::some_of(_m);
                ({
                auto code = lexer::join(filter(split(or_(index(srcs_2_5, info->file), check_errors::mk_src(Text::lit(""), Text::lit("")))->text, Text::lit("\n")), [&](const Text& l) { return !lexer::has_prefix(lexer::trim_start(l), Text::lit("#")); }), Text::lit("\n"));
                auto qualified = filter(ms_3_5, [&](const Text& o) { return ((o != m) && (o != Text::lit(""))) && lexer::contains(code, prism_rtl::cat(o, ".")); });
                call_then(start_mod_refs(g_1_5, m), [=](Array<Text> mod_refs_321571) { return prism_rtl::finished(insert(acc, m, check_types::union_texts(check_types::union_texts(mod_refs_321571, qualified), or_(prelude::get(solved_4_5, m), Array<Text>{})))); });
            });
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(acc)
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    }));
    })));
}


prism_rtl::Turn<Map<Text, Array<Text>>> NamedMods::cycle() const {
    const auto& g = this->g;
    const auto& srcs = this->srcs;
    const auto& tp = this->tp;
    const auto& ms = this->ms;
    auto by_path = fold(values(g.mods), Map<Text, Text>{}, [&](const Map<Text, Text>& acc, const check_env::ModInfo& info) { return insert(acc, or_(index(srcs, info->file), check_errors::mk_src(Text::lit(""), Text::lit("")))->path_, info.name); });
    auto by_file = fold(values(g.mods), Map<Nat, Text>{}, [&](const Map<Nat, Text>& acc, const check_env::ModInfo& info) { return insert(acc, info->file, info.name); });
    auto solved = fold(tp.impls, Map<Text, Array<Text>>{}, [&](const Map<Text, Array<Text>>& acc, const typed::ImplNote& n) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Map<Text, Array<Text>>> _v;
            auto&& _m = prelude::get(by_file, n.at->file);
            if (prism_rtl::is_some(_m)) {
                auto&& site = prism_rtl::some_of(_m);
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Map<Text, Array<Text>>> _v;
                    auto&& _m = prelude::get(by_path, impl_path(n.how));
                    if (prism_rtl::is_some(_m)) {
                        auto&& home = prism_rtl::some_of(_m);
                        _v.set((home == site) || check_types::has_text(or_(prelude::get(acc, site), Array<Text>{}), home)
                            ? acc
                            : insert(acc, site, prelude::push(or_(prelude::get(acc, site), Array<Text>{}), home)));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(acc);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(acc);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
    return fold_job(ms, Map<Text, Array<Text>>{}, ({
        auto g_1 = g;
        auto srcs_2 = srcs;
        auto ms_3 = ms;
        auto solved_4 = solved;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Array<Text>>>(std::tuple<Map<Text, Array<Text>>, Text>)>>(prism_rtl::rc([=](std::tuple<Map<Text, Array<Text>>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_1_5 = g_1;
            auto srcs_2_5 = srcs_2;
            auto ms_3_5 = ms_3;
            auto solved_4_5 = solved_4;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto m = p1;
                ({
                auto&& _m = prelude::get(g_1_5.mods, m);
                prism_rtl::is_some(_m) ? ({
                auto&& info = prism_rtl::some_of(_m);
                ({
                auto code = lexer::join(filter(split(or_(index(srcs_2_5, info->file), check_errors::mk_src(Text::lit(""), Text::lit("")))->text, Text::lit("\n")), [&](const Text& l) { return !lexer::has_prefix(lexer::trim_start(l), Text::lit("#")); }), Text::lit("\n"));
                auto qualified = filter(ms_3_5, [&](const Text& o) { return ((o != m) && (o != Text::lit(""))) && lexer::contains(code, prism_rtl::cat(o, ".")); });
                call_then(start_mod_refs(g_1_5, m), [=](Array<Text> mod_refs_321571) { return prism_rtl::finished(insert(acc, m, check_types::union_texts(check_types::union_texts(mod_refs_321571, qualified), or_(prelude::get(solved_4_5, m), Array<Text>{})))); });
            });
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(acc)
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    }));
    }))->cycle();
}


/// `Start NamedMods, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, Array<Text>>> start_named_mods(check_env::G g, Array<check_errors::Src> srcs, typed::TProgram tp, Array<Text> ms) {
    return prism_rtl::make_rc<NamedMods>(g, srcs, tp, ms);
}


/// ImplPath: fn Text -> Text
Text impl_path(const Text& how) {
    auto rest = or_(lexer::after_prefix(how, Text::lit("impl ")), or_(lexer::after_prefix(how, Text::lit("derived ")), Text::lit("")));
    auto parts = split(rest, Text::lit(":"));
    return lexer::join(take(parts, lexer::dec(len(parts))), Text::lit(":"));
}


/// ValueTypes: fn [ModDef] -> (Text ==> Bool)
Map<Text, bool> value_types(const Array<ModDef>& defs) {
    return fold(defs, Map<Text, bool>{}, [&](const Map<Text, bool>& acc, const ModDef& d) {
        return fold(d.items, acc, [&](const Map<Text, bool>& a, const Item& it) {
            return ({
                __label__ _done;
                prism_rtl::Slot<Map<Text, bool>> _v;
                if (prism_rtl::is<Item::ItType>(it)) {
                    auto&& t = prism_rtl::as<Item::ItType>(it).a0;
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<Map<Text, bool>> _v;
                        auto&& _m = t.shape;
                        if (prism_rtl::is<TyShape::ShapeChoice>(_m)) {
                            _v.set(a);
                            goto _done;
                        }
                        {
                            _v.set(insert(a, prism_rtl::cat(d.name, "::", t.name), true));
                            goto _done;
                        }
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                if (prism_rtl::is<Item::ItTag>(it)) {
                    auto&& t = prism_rtl::as<Item::ItTag>(it).a0;
                    _v.set(insert(a, prism_rtl::cat(d.name, "::", t.name), true));
                    goto _done;
                }
                {
                    _v.set(a);
                    goto _done;
                }
            _done:
                _v.take();
            });
        });
    });
}


/// ItemHeld: fn [Text], (Text ==> Bool), Text, Item -> [Text]
Array<Text> item_held(const Array<Text>& names, const Map<Text, bool>& value_tys, const Text& home, const Item& it) {
    if (prism_rtl::is<Item::ItType>(it)) {
        auto&& t = prism_rtl::as<Item::ItType>(it).a0;
        return fold(t.cases_, Array<Text>{}, [&](const Array<Text>& acc, const CaseDef& c) {
            return fold(c.fields, acc, [&](const Array<Text>& a, const std::tuple<Text, OutTy>& _p1) {
                auto&& ft = std::get<1>(_p1);
                return check_types::union_texts(a, held_in(names, value_tys, home, ft));
            });
        });
    }
    if (prism_rtl::is<Item::ItTag>(it)) {
        auto&& t = prism_rtl::as<Item::ItTag>(it).a0;
        return fold(t.fields, Array<Text>{}, [&](const Array<Text>& acc, const std::tuple<Text, Text, OutTy>& _p1) {
            auto&& ft = std::get<2>(_p1);
            return check_types::union_texts(acc, held_in(names, value_tys, home, ft));
        });
    }
    if (prism_rtl::is<Item::ItRow>(it)) {
        auto&& r = prism_rtl::as<Item::ItRow>(it).a0;
        return fold(r.cases_, Array<Text>{}, [&](const Array<Text>& acc, const std::tuple<Text, Text>& _p1) {
            auto&& sp = std::get<1>(_p1);
            return check_types::union_texts(acc, held_in(names, value_tys, home, OutTy(OutTy::OutNamed{sp, Array<OutTy>{}})));
        });
    }
    {
        return Array<Text>{};
    }
}


/// HeldIn: fn [Text], (Text ==> Bool), Text, OutTy -> [Text]
Array<Text> held_in(const Array<Text>& names, const Map<Text, bool>& value_tys, const Text& home, const OutTy& t) {
    if (prism_rtl::is<OutTy::OutNamed>(t)) {
        auto&& n = prism_rtl::as<OutTy::OutNamed>(t).a0;
        auto&& args = prism_rtl::as<OutTy::OutNamed>(t).a1;
        auto p_ = path_from(names, home, n);
        auto own_ = check_env::has_key(value_tys, p_)
            ? Array(std::vector{parent_of(p_)})
            : Array<Text>{};
        return fold(args, own_, [&](const Array<Text>& acc, const OutTy& a) { return check_types::union_texts(acc, held_in(names, value_tys, home, a)); });
    }
    if (prism_rtl::is<OutTy::OutOpt>(t)) {
        auto&& i = prism_rtl::as<OutTy::OutOpt>(t).a0;
        return held_in(names, value_tys, home, i);
    }
    if (prism_rtl::is<OutTy::OutRes>(t)) {
        auto&& i = prism_rtl::as<OutTy::OutRes>(t).a0;
        return held_in(names, value_tys, home, i);
    }
    if (prism_rtl::is<OutTy::OutCell>(t)) {
        auto&& i = prism_rtl::as<OutTy::OutCell>(t).a0;
        return held_in(names, value_tys, home, i);
    }
    if (prism_rtl::is<OutTy::OutRc>(t)) {
        auto&& i = prism_rtl::as<OutTy::OutRc>(t).a0;
        return held_in(names, value_tys, home, i);
    }
    if (prism_rtl::is<OutTy::OutTuple>(t)) {
        auto&& ts = prism_rtl::as<OutTy::OutTuple>(t).a0;
        return fold(ts, Array<Text>{}, [&](const Array<Text>& acc, const OutTy& a) { return check_types::union_texts(acc, held_in(names, value_tys, home, a)); });
    }
    {
        return Array<Text>{};
    }
}


/// NamedIn: fn [Text], Text, OutTy -> [Text]
Array<Text> named_in(const Array<Text>& names, const Text& home, const OutTy& t) {
    if (prism_rtl::is<OutTy::OutNamed>(t)) {
        auto&& n = prism_rtl::as<OutTy::OutNamed>(t).a0;
        auto&& args = prism_rtl::as<OutTy::OutNamed>(t).a1;
        auto p_ = path_from(names, home, n);
        auto own_ = check_types::has_text(names, parent_of(p_))
            ? Array(std::vector{parent_of(p_)})
            : Array<Text>{};
        return fold(args, own_, [&](const Array<Text>& acc, const OutTy& a) { return check_types::union_texts(acc, named_in(names, home, a)); });
    }
    if (prism_rtl::is<OutTy::OutOpt>(t)) {
        auto&& i = prism_rtl::as<OutTy::OutOpt>(t).a0;
        return named_in(names, home, i);
    }
    if (prism_rtl::is<OutTy::OutRes>(t)) {
        auto&& i = prism_rtl::as<OutTy::OutRes>(t).a0;
        return named_in(names, home, i);
    }
    if (prism_rtl::is<OutTy::OutCell>(t)) {
        auto&& i = prism_rtl::as<OutTy::OutCell>(t).a0;
        return named_in(names, home, i);
    }
    if (prism_rtl::is<OutTy::OutArray>(t)) {
        auto&& i = prism_rtl::as<OutTy::OutArray>(t).a0;
        return named_in(names, home, i);
    }
    if (prism_rtl::is<OutTy::OutRc>(t)) {
        auto&& i = prism_rtl::as<OutTy::OutRc>(t).a0;
        return named_in(names, home, i);
    }
    if (prism_rtl::is<OutTy::OutEvent>(t)) {
        auto&& i = prism_rtl::as<OutTy::OutEvent>(t).a0;
        return named_in(names, home, i);
    }
    if (prism_rtl::is<OutTy::OutDyn>(t)) {
        auto&& i = prism_rtl::as<OutTy::OutDyn>(t).a0;
        return named_in(names, home, i);
    }
    if (prism_rtl::is<OutTy::OutMap>(t)) {
        auto&& k = prism_rtl::as<OutTy::OutMap>(t).a0;
        auto&& v_ = prism_rtl::as<OutTy::OutMap>(t).a1;
        return check_types::union_texts(named_in(names, home, k), named_in(names, home, v_));
    }
    if (prism_rtl::is<OutTy::OutTuple>(t)) {
        auto&& ts = prism_rtl::as<OutTy::OutTuple>(t).a0;
        return fold(ts, Array<Text>{}, [&](const Array<Text>& acc, const OutTy& a) { return check_types::union_texts(acc, named_in(names, home, a)); });
    }
    if (prism_rtl::is<OutTy::OutFn>(t)) {
        auto&& ps = prism_rtl::as<OutTy::OutFn>(t).a0;
        auto&& r = prism_rtl::as<OutTy::OutFn>(t).a1;
        return fold(ps, named_in(names, home, r), [&](const Array<Text>& acc, const OutTy& a) { return check_types::union_texts(acc, named_in(names, home, a)); });
    }
    {
        return Array<Text>{};
    }
}


/// PathFrom: fn [Text], Text, Text -> Text
Text path_from(const Array<Text>& names, const Text& home, const Text& n) {
    auto q = lexer::drop_prefix(n, Text::lit("crate::"));
    return check_types::has_text(names, or_(index(split(q, Text::lit("::")), Nat(0u)), Text::lit("")))
        ? q
        : home == Text::lit("") ? q : prism_rtl::cat(home, "::", q);
}


/// ParentOf: fn Text -> Text
Text parent_of(const Text& p_) {
    auto segs = split(p_, Text::lit("::"));
    return lexer::join(take(segs, lexer::dec(len(segs))), Text::lit("::"));
}


/// WithGroups: unbounded fn [ModDef] -> [ModDef]
Array<ModDef> with_groups(const Array<ModDef>& defs) {
    auto edges = fold(defs, Map<Text, Array<Text>>{}, [&](const Map<Text, Array<Text>>& m, const ModDef& d) { return insert(m, d.name, d.complete); });
    auto reach = run_to_end(fold_job(defs, Map<Text, Array<Text>>{}, ({
        auto edges_1 = edges;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Array<Text>>>(std::tuple<Map<Text, Array<Text>>, ModDef>)>>(prism_rtl::rc([=](std::tuple<Map<Text, Array<Text>>, ModDef> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto edges_1_2 = edges_1;
            entered(once_job([=]() {
            return ({
                auto m = p0;
                auto d = p1;
                call_then(start_reached_by(edges_1_2, Array(std::vector{d.name}), Array<Text>{}), [=](Array<Text> reached_by_325640) { return prism_rtl::finished(insert(m, d.name, reached_by_325640)); });
            });
        }));
        });
    }));
    })));
    return each(defs, [&](const ModDef& d) {
        return ({
            auto mine = or_(prelude::get(reach, d.name), Array<Text>{});
            ({
            ModDef this_ = d;
            this_.types_with = filter(each(defs, [&](const ModDef& o) { return o.name; }), [&](const Text& n) { return (n == d.name) || (check_types::has_text(mine, n) && check_types::has_text(or_(prelude::get(reach, n), Array<Text>{}), d.name)); });
            this_;
        });
        });
    });
}


prism_rtl::Turn<Array<ModDef>> WithGroups::cycle() const {
    const auto& defs = this->defs;
    auto edges = fold(defs, Map<Text, Array<Text>>{}, [&](const Map<Text, Array<Text>>& m, const ModDef& d) { return insert(m, d.name, d.complete); });
    auto defs_1 = defs;
    return call_value(fold_job(defs_1, Map<Text, Array<Text>>{}, ({
        auto edges_2 = edges;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Array<Text>>>(std::tuple<Map<Text, Array<Text>>, ModDef>)>>(prism_rtl::rc([=](std::tuple<Map<Text, Array<Text>>, ModDef> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto edges_2_3 = edges_2;
            entered(once_job([=]() {
            return ({
                auto m = p0;
                auto d = p1;
                call_then(start_reached_by(edges_2_3, Array(std::vector{d.name}), Array<Text>{}), [=](Array<Text> reached_by_325640) { return prism_rtl::finished(insert(m, d.name, reached_by_325640)); });
            });
        }));
        });
    }));
    })), [=](Map<Text, Array<Text>> fold_325598) {
        return ({
            auto reach = fold_325598;
            (prism_rtl::finished(each(defs_1, [&](const ModDef& d) {
            return ({
                auto mine = or_(prelude::get(reach, d.name), Array<Text>{});
                ({
                ModDef this_ = d;
                this_.types_with = filter(each(defs_1, [&](const ModDef& o) { return o.name; }), [&](const Text& n) { return (n == d.name) || (check_types::has_text(mine, n) && check_types::has_text(or_(prelude::get(reach, n), Array<Text>{}), d.name)); });
                this_;
            });
            });
        })));
        });
    });
}


/// `Start WithGroups, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<ModDef>> start_with_groups(Array<ModDef> defs) {
    return prism_rtl::make_rc<WithGroups>(defs);
}


/// ReachedBy: unbounded fn (Text ==> [Text]), [Text], [Text] -> [Text]
Array<Text> reached_by(const Map<Text, Array<Text>>& edges, const Array<Text>& todo, const Array<Text>& seen) {
    auto&& _m = index(todo, Nat(0u));
    if (prism_rtl::is_none(_m)) {
        return seen;
    }
    if (prism_rtl::is_some(_m)) {
        auto&& m = prism_rtl::some_of(_m);
        return check_types::has_text(seen, m)
            ? reached_by(edges, drop(todo, Nat(1u)), seen)
            : reached_by(edges, append(drop(todo, Nat(1u)), or_(prelude::get(edges, m), Array<Text>{})), prelude::push(seen, m));
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Text>> ReachedBy::cycle() const {
    const auto& edges = this->edges;
    const auto& todo = this->todo;
    const auto& seen = this->seen;
    return ({
        auto&& _m = index(todo, Nat(0u));
        prism_rtl::is_none(_m) ? prism_rtl::finished(seen)
        : prism_rtl::is_some(_m) ? ({
        auto&& m = prism_rtl::some_of(_m);
        check_types::has_text(seen, m)
        ? prism_rtl::more(prism_rtl::rc(ReachedBy(edges, drop(todo, Nat(1u)), seen)))
        : prism_rtl::more(prism_rtl::rc(ReachedBy(edges, append(drop(todo, Nat(1u)), or_(prelude::get(edges, m), Array<Text>{})), prelude::push(seen, m))));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ReachedBy, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_reached_by(Map<Text, Array<Text>> edges, Array<Text> todo, Array<Text> seen) {
    return prism_rtl::make_rc<ReachedBy>(edges, todo, seen);
}


/// NeededMods: unbounded fn G, Nat -> [Text]
Array<Text> needed_mods(const check_env::G& g, const Nat& shown) {
    auto own_ = filter(keys(g.mods), [&](const Text& m) { return (or_(prelude::get(g.mods, m), check_env::dummy_mod())->file < shown) && (m != Text::lit("Prelude")); });
    auto grown = run_to_end(fold_job(check_errors::range0(Nat(6u)), own_, ({
        auto g_1 = g;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Nat>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_1_2 = g_1;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                static_cast<void>(p1);
                fold_job(acc, acc, ({
                auto g_1_2_2 = g_1_2;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Text>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, Text> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto g_1_2_2_2 = g_1_2_2;
                    entered(once_job([=]() {
                    return ({
                        auto a = p0;
                        auto m = p1;
                        call_then(start_mod_refs(g_1_2_2_2, m), [=](Array<Text> mod_refs_326663) { return prism_rtl::finished(check_types::union_texts(a, mod_refs_326663)); });
                    });
                }));
                });
            })));
            }))->cycle();
            });
        }));
        });
    })));
    })));
    return filter(keys(g.mods), [&](const Text& m) { return (m != Text::lit("Prelude")) && check_types::has_text(grown, m); });
}


prism_rtl::Turn<Array<Text>> NeededMods::cycle() const {
    const auto& g = this->g;
    const auto& shown = this->shown;
    auto own_ = filter(keys(g.mods), [&](const Text& m) { return (or_(prelude::get(g.mods, m), check_env::dummy_mod())->file < shown) && (m != Text::lit("Prelude")); });
    auto g_1 = g;
    return call_value(fold_job(check_errors::range0(Nat(6u)), own_, ({
        auto g_1_2 = g_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Nat>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_1_2_2 = g_1_2;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                static_cast<void>(p1);
                fold_job(acc, acc, ({
                auto g_1_2_2_2 = g_1_2_2;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Text>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, Text> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto g_1_2_2_2_2 = g_1_2_2_2;
                    entered(once_job([=]() {
                    return ({
                        auto a = p0;
                        auto m = p1;
                        call_then(start_mod_refs(g_1_2_2_2_2, m), [=](Array<Text> mod_refs_326663) { return prism_rtl::finished(check_types::union_texts(a, mod_refs_326663)); });
                    });
                }));
                });
            })));
            }))->cycle();
            });
        }));
        });
    })));
    })), [=](Array<Text> fold_326588) {
        return ({
            auto grown = fold_326588;
            (prism_rtl::finished(filter(keys(g_1.mods), [&](const Text& m) { return (m != Text::lit("Prelude")) && check_types::has_text(grown, m); })));
        });
    });
}


/// `Start NeededMods, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_needed_mods(check_env::G g, Nat shown) {
    return prism_rtl::make_rc<NeededMods>(g, shown);
}


/// ModRefs: unbounded fn G, Text -> [Text]
Array<Text> mod_refs(const check_env::G& g, const Text& m) {
    auto&& _m = prelude::get(g.mods, m);
    if (prism_rtl::is_some(_m)) {
        auto&& info = prism_rtl::some_of(_m);
        auto used = each(info.uses, [&](const std::tuple<Text, bool>& _p0) {
            auto&& u = std::get<0>(_p0);
            return u;
        });
        auto fams = ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = info.tree.emit_row;
            if (prism_rtl::is_some(_m)) {
                auto&& rw = prism_rtl::some_of(_m);
                _v.set(fold(rw.terms, Array<Text>{}, [&](const Array<Text>& acc, const ast::RowTerm& t) {
                    return ({
                        __label__ _done;
                        prism_rtl::Slot<Array<Text>> _v;
                        if (prism_rtl::is<ast::RowTerm::RFamily>(t)) {
                            auto&& q = prism_rtl::as<ast::RowTerm::RFamily>(t).a0;
                            _v.set(prelude::push(acc, or_(prelude::get(g.fam_owner, check_env::dotted(q->path_)), check_env::dotted(q->path_))));
                            goto _done;
                        }
                        {
                            _v.set(acc);
                            goto _done;
                        }
                    _done:
                        _v.take();
                    });
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(Array<Text>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        return filter(append(used, fams), [&](const Text& x) { return check_env::has_key(g.mods, x); });
    }
    if (prism_rtl::is_none(_m)) {
        return Array<Text>{};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Text>> ModRefs::cycle() const {
    const auto& g = this->g;
    const auto& m = this->m;
    return ({
        auto&& _m = prelude::get(g.mods, m);
        prism_rtl::is_some(_m) ? ({
        auto&& info = prism_rtl::some_of(_m);
        ({
        auto used = each(info.uses, [&](const std::tuple<Text, bool>& _p0) {
            auto&& u = std::get<0>(_p0);
            return u;
        });
        auto fams = ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = info.tree.emit_row;
            if (prism_rtl::is_some(_m)) {
                auto&& rw = prism_rtl::some_of(_m);
                _v.set(fold(rw.terms, Array<Text>{}, [&](const Array<Text>& acc, const ast::RowTerm& t) {
                    return ({
                        __label__ _done;
                        prism_rtl::Slot<Array<Text>> _v;
                        if (prism_rtl::is<ast::RowTerm::RFamily>(t)) {
                            auto&& q = prism_rtl::as<ast::RowTerm::RFamily>(t).a0;
                            _v.set(prelude::push(acc, or_(prelude::get(g.fam_owner, check_env::dotted(q->path_)), check_env::dotted(q->path_))));
                            goto _done;
                        }
                        {
                            _v.set(acc);
                            goto _done;
                        }
                    _done:
                        _v.take();
                    });
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(Array<Text>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        (prism_rtl::finished(filter(append(used, fams), [&](const Text& x) { return check_env::has_key(g.mods, x); })));
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(Array<Text>{})
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ModRefs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_mod_refs(check_env::G g, Text m) {
    return prism_rtl::make_rc<ModRefs>(g, m);
}


/// RootWidgets: fn Lx -> [((Text, Bool))]
Array<std::tuple<Text, bool>> root_widgets(const Lx& lx) {
    auto tested = fold(lx.g.defs, Array<std::tuple<Text, bool>>{}, [&](const Array<std::tuple<Text, bool>>& acc, const check_env::Def& d) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<std::tuple<Text, bool>>> _v;
            auto&& _m = d.body;
            if (prism_rtl::is<check_env::DefBody::DbTest>(_m)) {
                auto&& t = prism_rtl::as<check_env::DefBody::DbTest>(_m).a0;
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Array<std::tuple<Text, bool>>> _v;
                    auto&& _m = blueprint_qk(in_module(lx, d->file, d.home), t.blueprint);
                    {
                        auto&& m327417_0 = _m;
                        if (m327417_0 == Text::lit("")) {
                            _v.set(acc);
                            goto _done;
                        }
                    }
                    {
                        auto&& qk = _m;
                        _v.set(check_types::has_text(each(acc, [&](const std::tuple<Text, bool>& _p0) {
                            auto&& q = std::get<0>(_p0);
                            return q;
                        }), qk)
                            ? acc
                            : prelude::push(acc, std::tuple{qk, true}));
                        goto _done;
                    }
                _done:
                    _v.take();
                }));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto main = fold(lx.g.defs, Array<std::tuple<Text, bool>>{}, [&](const Array<std::tuple<Text, bool>>& acc, const check_env::Def& d) { return is_main(d.qk) ? prelude::push(acc, std::tuple{d.qk, false}) : acc; });
    return fold(main, tested, [&](const Array<std::tuple<Text, bool>>& acc, const std::tuple<Text, bool>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& b = std::get<1>(_p1);
        return check_types::has_text(each(acc, [&](const std::tuple<Text, bool>& _p0) {
            auto&& q = std::get<0>(_p0);
            return q;
        }), k)
            ? acc
            : prelude::push(acc, std::tuple{k, b});
    });
}


/// IsMain: fn Text -> Bool
bool is_main(const Text& qk) {
    return ((owner_of(qk) == Text::lit("")) && (base(check_types::bare_name(qk)) == Text::lit("main"))) && lexer::has_prefix(check_types::bare_name(qk), Text::lit("@"));
}


/// BlueprintQk: fn Lx, Expr -> Text
Text blueprint_qk(const Lx& lx, const ast::Expr& e) {
    auto&& _m = e.kind;
    if (prism_rtl::is<ast::ExprKind::ECall>(_m)) {
        auto&& c = prism_rtl::as<ast::ExprKind::ECall>(_m).a0;
        return blueprint_qk(lx, c);
    }
    if (prism_rtl::is<ast::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<ast::ExprKind::EGroup>(_m).a0;
        return blueprint_qk(lx, x);
    }
    if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
        auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
        auto&& _q_opt = check_env::resolve_value(lx.g, lx.home, n);
        auto&& q_opt = std::get<0>(_q_opt);
        return or_(q_opt, Text::lit(""));
    }
    {
        return Text::lit("");
    }
}


/// ValOf: fn Lx, Text -> ValInfo
check_env::ValInfo val_of(const Lx& lx, const Text& qk) {
    auto&& _m = prelude::get(lx.g.vals, qk);
    if (prism_rtl::is_some(_m)) {
        auto&& v_ = prism_rtl::some_of(_m);
        return v_;
    }
    if (prism_rtl::is_none(_m)) {
        auto d = fold(lx.g.defs, check_env::dummy_def(), [&](const check_env::Def& found, const check_env::Def& df) { return df.qk == qk ? df : found; });
        return check_env::ValInfo{.qk = qk, .scheme = check_types::mono(check_types::Ty(check_types::Ty::TyErr{})), .sort = Text::lit("fn"), .has_sig = false, .home = d.home, .file = d->file, .span = d.span};
    }
    prism_rtl::unreachable("no arm matched");
}


/// ProgDefOf: unbounded fn Lx, Text -> ProgDef
ProgDef prog_def_of(const Lx& lx, const Text& qk) {
    auto v_ = val_of(lx, qk);
    auto ptys = ({
        __label__ _done;
        prism_rtl::Slot<Array<check_types::Ty>> _v;
        auto&& _m = v_.scheme.ty;
        if (prism_rtl::is<check_types::Ty::TyFn>(_m)) {
            auto&& ps = prism_rtl::as<check_types::Ty::TyFn>(_m).a1;
            _v.set(ps);
            goto _done;
        }
        {
            _v.set(Array<check_types::Ty>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto lxm = in_module_at(lx, v_->file, v_.home, Text::lit("\000main"sv));
    auto params = run_to_end(each_job(check_errors::range0(len(ptys)), ({
        auto lxm_1 = lxm;
        auto ptys_2 = ptys;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, OutTy>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto lxm_1_3 = lxm_1;
            auto ptys_2_3 = ptys_2;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                call_then(start_out_ty_of(lxm_1_3, peel(or_(index(ptys_2_3, i), check_types::Ty(check_types::Ty::TyErr{})))), [=](OutTy out_ty_of_328992) { return prism_rtl::finished(std::tuple{prism_rtl::cat("arg", i), out_ty_of_328992}); });
            });
        }));
        });
    }));
    })));
    auto node_ = prism_rtl::cat(rust_mod_name(v_.home), "::", camel(check_types::bare_name(qk)));
    auto fams = or_(prelude::get(lx.g.mods, v_.home), check_env::dummy_mod()).emit_rw.fams;
    auto world = check_types::has_text(fams, Text::lit("Gui"))
        ? Text::lit("canvas")
        : check_types::has_text(fams, Text::lit("Ui"))
        ? Text::lit("none")
        : Text::lit("cli");
    return ProgDef{.name = prism_rtl::cat(camel(check_types::bare_name(qk)), "Program"), .prism = lexer::after_first(check_types::bare_name(qk)), .node_ = node_, .params = params, .fallible = true, .world = world};
}


prism_rtl::Turn<ProgDef> ProgDefOf::cycle() const {
    const auto& lx = this->lx;
    const auto& qk = this->qk;
    auto v_ = val_of(lx, qk);
    auto ptys = ({
        __label__ _done;
        prism_rtl::Slot<Array<check_types::Ty>> _v;
        auto&& _m = v_.scheme.ty;
        if (prism_rtl::is<check_types::Ty::TyFn>(_m)) {
            auto&& ps = prism_rtl::as<check_types::Ty::TyFn>(_m).a1;
            _v.set(ps);
            goto _done;
        }
        {
            _v.set(Array<check_types::Ty>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto lxm = in_module_at(lx, v_->file, v_.home, Text::lit("\000main"sv));
    auto lx_1 = lx;
    auto qk_2 = qk;
    return call_value(each_job(check_errors::range0(len(ptys)), ({
        auto lxm_3 = lxm;
        auto ptys_4 = ptys;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, OutTy>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto lxm_3_5 = lxm_3;
            auto ptys_4_5 = ptys_4;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                call_then(start_out_ty_of(lxm_3_5, peel(or_(index(ptys_4_5, i), check_types::Ty(check_types::Ty::TyErr{})))), [=](OutTy out_ty_of_328992) { return prism_rtl::finished(std::tuple{prism_rtl::cat("arg", i), out_ty_of_328992}); });
            });
        }));
        });
    }));
    })), [=](Array<std::tuple<Text, OutTy>> each_328948) {
        return ({
            auto params = each_328948;
            auto node_ = prism_rtl::cat(rust_mod_name(v_.home), "::", camel(check_types::bare_name(qk_2)));
            auto fams = or_(prelude::get(lx_1.g.mods, v_.home), check_env::dummy_mod()).emit_rw.fams;
            auto world = check_types::has_text(fams, Text::lit("Gui"))
                ? Text::lit("canvas")
                : check_types::has_text(fams, Text::lit("Ui"))
                ? Text::lit("none")
                : Text::lit("cli");
            (prism_rtl::finished(ProgDef{.name = prism_rtl::cat(camel(check_types::bare_name(qk_2)), "Program"), .prism = lexer::after_first(check_types::bare_name(qk_2)), .node_ = node_, .params = params, .fallible = true, .world = world}));
        });
    });
}


/// `Start ProgDefOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<ProgDef> start_prog_def_of(Lx lx, Text qk) {
    return prism_rtl::make_rc<ProgDefOf>(lx, qk);
}


/// JobRoots: unbounded fn Lx -> [Text]
Array<Text> job_roots(const Lx& lx) {
    auto direct = run_to_end(fold_job(lx.g.defs, Array<Text>{}, ({
        auto lx_1 = lx;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, check_env::Def>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, check_env::Def> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_1_2 = lx_1;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto d = p1;
                ({
                auto lxd = in_module(lx_1_2, d->file, d.home);
                call_then(start_run_targets(lxd, d), [=](Array<Text> run_targets_329827) { return call_then(start_unbounded_values(lxd, d), [=](Array<Text> unbounded_values_329849) { return prism_rtl::finished(check_types::union_texts(check_types::union_texts(acc, run_targets_329827), unbounded_values_329849)); }); });
            });
            });
        }));
        });
    })));
    })));
    return run_to_end(fold_job(check_errors::range0(Nat(8u)), direct, ({
        auto lx_1 = lx;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Nat>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_1_2 = lx_1;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                static_cast<void>(p1);
                fold_job(acc, acc, ({
                auto lx_1_2_2 = lx_1_2;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Text>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, Text> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto lx_1_2_2_2 = lx_1_2_2;
                    entered(once_job([=]() {
                    return ({
                        auto a = p0;
                        auto qk = p1;
                        call_then(start_tail_targets(lx_1_2_2_2, qk), [=](Array<Text> tail_targets_329956) { return prism_rtl::finished(check_types::union_texts(a, tail_targets_329956)); });
                    });
                }));
                });
            })));
            }))->cycle();
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<Array<Text>> JobRoots::cycle() const {
    const auto& lx = this->lx;
    auto lx_1 = lx;
    return call_value(fold_job(lx_1.g.defs, Array<Text>{}, ({
        auto lx_1_2 = lx_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, check_env::Def>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, check_env::Def> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_1_2_2 = lx_1_2;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto d = p1;
                ({
                auto lxd = in_module(lx_1_2_2, d->file, d.home);
                call_then(start_run_targets(lxd, d), [=](Array<Text> run_targets_329827) { return call_then(start_unbounded_values(lxd, d), [=](Array<Text> unbounded_values_329849) { return prism_rtl::finished(check_types::union_texts(check_types::union_texts(acc, run_targets_329827), unbounded_values_329849)); }); });
            });
            });
        }));
        });
    })));
    })), [=](Array<Text> fold_329712) {
        return ({
            auto direct = fold_329712;
            fold_job(check_errors::range0(Nat(8u)), direct, ({
            auto lx_1_2 = lx_1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Nat>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, Nat> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto lx_1_2_2 = lx_1_2;
                entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    static_cast<void>(p1);
                    fold_job(acc, acc, ({
                    auto lx_1_2_2_2 = lx_1_2_2;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Text>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, Text> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto lx_1_2_2_2_2 = lx_1_2_2_2;
                        entered(once_job([=]() {
                        return ({
                            auto a = p0;
                            auto qk = p1;
                            call_then(start_tail_targets(lx_1_2_2_2_2, qk), [=](Array<Text> tail_targets_329956) { return prism_rtl::finished(check_types::union_texts(a, tail_targets_329956)); });
                        });
                    }));
                    });
                })));
                }))->cycle();
                });
            }));
            });
        })));
        }))->cycle();
        });
    });
}


/// `Start JobRoots, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_job_roots(Lx lx) {
    return prism_rtl::make_rc<JobRoots>(lx);
}


/// UnboundedValues: unbounded fn Lx, Def -> [Text]
Array<Text> unbounded_values(const Lx& lx, const check_env::Def& d) {
    auto es = ({
        __label__ _done;
        prism_rtl::Slot<Array<ast::Expr>> _v;
        auto&& _m = d.body;
        if (prism_rtl::is<check_env::DefBody::DbWidget>(_m)) {
            auto&& w = prism_rtl::as<check_env::DefBody::DbWidget>(_m).a0;
            _v.set(typed::block_exprs(w.body));
            goto _done;
        }
        if (prism_rtl::is<check_env::DefBody::DbFn>(_m)) {
            auto&& cs = prism_rtl::as<check_env::DefBody::DbFn>(_m).a0;
            _v.set(run_to_end(fold_job(cs, Array<ast::Expr>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<ast::Expr>>(std::tuple<Array<ast::Expr>, ast::FnClause>)>>(prism_rtl::rc([=](std::tuple<Array<ast::Expr>, ast::FnClause> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return entered(once_job([=]() {
                    return ({
                        auto acc = p0;
                        auto c = p1;
                        call_then(typed::start_body_exprs(c.body), [=](Array<ast::Expr> body_exprs_330305) { return prism_rtl::finished(append(acc, body_exprs_330305)); });
                    });
                }));
            })))));
            goto _done;
        }
        if (prism_rtl::is<check_env::DefBody::DbLet>(_m)) {
            auto&& l = prism_rtl::as<check_env::DefBody::DbLet>(_m).a0;
            _v.set(typed::exprs_in(l->value));
            goto _done;
        }
        {
            _v.set(Array<ast::Expr>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto callees = fold(es, Array<Text>{}, [&](const Array<Text>& acc, const ast::Expr& e) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = e.kind;
            if (prism_rtl::is<ast::ExprKind::ECall>(_m)) {
                auto&& c = prism_rtl::as<ast::ExprKind::ECall>(_m).a0;
                _v.set(prelude::push(acc, place_key(lx, c.span)));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    return fold(es, Array<Text>{}, [&](const Array<Text>& acc, const ast::Expr& e) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = e.kind;
            if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
                auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
                _v.set(check_types::has_text(callees, place_key(lx, e.span))
                    ? acc
                    : ({
                    auto&& _q_opt = check_env::resolve_value(lx.g, lx.home, n);
                    auto&& q_opt = std::get<0>(_q_opt);
                    ({
                    __label__ _done;
                    prism_rtl::Slot<Array<Text>> _v;
                    if (prism_rtl::is_some(q_opt)) {
                        auto&& q = prism_rtl::some_of(q_opt);
                        _v.set(is_unbounded(lx, q) ? check_types::add_text(acc, q) : acc);
                        goto _done;
                    }
                    if (prism_rtl::is_none(q_opt)) {
                        _v.set(acc);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                }));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


prism_rtl::Turn<Array<Text>> UnboundedValues::cycle() const {
    const auto& lx = this->lx;
    const auto& d = this->d;
    auto es = ({
        __label__ _done;
        prism_rtl::Slot<Array<ast::Expr>> _v;
        auto&& _m = d.body;
        if (prism_rtl::is<check_env::DefBody::DbWidget>(_m)) {
            auto&& w = prism_rtl::as<check_env::DefBody::DbWidget>(_m).a0;
            _v.set(typed::block_exprs(w.body));
            goto _done;
        }
        if (prism_rtl::is<check_env::DefBody::DbFn>(_m)) {
            auto&& cs = prism_rtl::as<check_env::DefBody::DbFn>(_m).a0;
            _v.set(run_to_end(fold_job(cs, Array<ast::Expr>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<ast::Expr>>(std::tuple<Array<ast::Expr>, ast::FnClause>)>>(prism_rtl::rc([=](std::tuple<Array<ast::Expr>, ast::FnClause> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return entered(once_job([=]() {
                    return ({
                        auto acc = p0;
                        auto c = p1;
                        call_then(typed::start_body_exprs(c.body), [=](Array<ast::Expr> body_exprs_330305) { return prism_rtl::finished(append(acc, body_exprs_330305)); });
                    });
                }));
            })))));
            goto _done;
        }
        if (prism_rtl::is<check_env::DefBody::DbLet>(_m)) {
            auto&& l = prism_rtl::as<check_env::DefBody::DbLet>(_m).a0;
            _v.set(typed::exprs_in(l->value));
            goto _done;
        }
        {
            _v.set(Array<ast::Expr>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto callees = fold(es, Array<Text>{}, [&](const Array<Text>& acc, const ast::Expr& e) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = e.kind;
            if (prism_rtl::is<ast::ExprKind::ECall>(_m)) {
                auto&& c = prism_rtl::as<ast::ExprKind::ECall>(_m).a0;
                _v.set(prelude::push(acc, place_key(lx, c.span)));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    return prism_rtl::finished(fold(es, Array<Text>{}, [&](const Array<Text>& acc, const ast::Expr& e) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = e.kind;
            if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
                auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
                _v.set(check_types::has_text(callees, place_key(lx, e.span))
                    ? acc
                    : ({
                    auto&& _q_opt = check_env::resolve_value(lx.g, lx.home, n);
                    auto&& q_opt = std::get<0>(_q_opt);
                    ({
                    __label__ _done;
                    prism_rtl::Slot<Array<Text>> _v;
                    if (prism_rtl::is_some(q_opt)) {
                        auto&& q = prism_rtl::some_of(q_opt);
                        _v.set(is_unbounded(lx, q) ? check_types::add_text(acc, q) : acc);
                        goto _done;
                    }
                    if (prism_rtl::is_none(q_opt)) {
                        _v.set(acc);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                }));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    }));
}


/// `Start UnboundedValues, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_unbounded_values(Lx lx, check_env::Def d) {
    return prism_rtl::make_rc<UnboundedValues>(lx, d);
}


/// InPrelude: fn Lx, Text -> Bool
bool in_prelude(const Lx& lx, const Text& q) {
    auto&& _m = prelude::get(lx.g.vals, q);
    if (prism_rtl::is_some(_m)) {
        auto&& v_ = prism_rtl::some_of(_m);
        return v_.home == Text::lit("Prelude");
    }
    if (prism_rtl::is_none(_m)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// IsColorPoly: fn Lx, Text -> Bool
bool is_color_poly(const Lx& lx, const Text& q) {
    auto&& _m = prelude::get(lx.g.vals, q);
    if (prism_rtl::is_some(_m)) {
        auto&& v_ = prism_rtl::some_of(_m);
        auto&& _m = v_.scheme.ty;
        if (prism_rtl::is<check_types::Ty::TyFn>(_m) && prism_rtl::is<check_types::Col::CQ>(prism_rtl::as<check_types::Ty::TyFn>(_m).a0)) {
            return true;
        }
        if (prism_rtl::is<check_types::Ty::TyFn>(_m) && prism_rtl::is<check_types::Col::CRigid>(prism_rtl::as<check_types::Ty::TyFn>(_m).a0)) {
            return true;
        }
        {
            return false;
        }
    }
    if (prism_rtl::is_none(_m)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// EntersAtOnce: fn Lx, Text, [Arg] -> Bool
bool enters_at_once(const Lx& lx, const Text& q, const Array<ast::Arg>& args) {
    return is_color_poly(lx, q) && (!fold(args, false, [&](const bool& seen, const ast::Arg& a) { return seen || is_unbounded_arg(lx, a); }));
}


/// IsUnboundedArg: fn Lx, Arg -> Bool
bool is_unbounded_arg(const Lx& lx, const ast::Arg& a) {
    auto&& _m = peel(type_at(lx, a->value.span));
    if (prism_rtl::is<check_types::Ty::TyFn>(_m) && prism_rtl::is<check_types::Col::CUnbound>(prism_rtl::as<check_types::Ty::TyFn>(_m).a0)) {
        return true;
    }
    {
        return false;
    }
}


/// IsUnbounded: fn Lx, Text -> Bool
bool is_unbounded(const Lx& lx, const Text& q) {
    auto&& _m = prelude::get(lx.g.vals, q);
    if (prism_rtl::is_some(_m)) {
        auto&& v_ = prism_rtl::some_of(_m);
        auto&& _m = v_.scheme.ty;
        if (prism_rtl::is<check_types::Ty::TyFn>(_m) && prism_rtl::is<check_types::Col::CBound>(prism_rtl::as<check_types::Ty::TyFn>(_m).a0)) {
            return false;
        }
        if (prism_rtl::is<check_types::Ty::TyFn>(_m)) {
            return true;
        }
        {
            return false;
        }
    }
    if (prism_rtl::is_none(_m)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// RunTargets: unbounded fn Lx, Def -> [Text]
Array<Text> run_targets(const Lx& lx, const check_env::Def& d) {
    auto es = ({
        __label__ _done;
        prism_rtl::Slot<Array<ast::Expr>> _v;
        auto&& _m = d.body;
        if (prism_rtl::is<check_env::DefBody::DbWidget>(_m)) {
            auto&& w = prism_rtl::as<check_env::DefBody::DbWidget>(_m).a0;
            _v.set(typed::block_exprs(w.body));
            goto _done;
        }
        if (prism_rtl::is<check_env::DefBody::DbFn>(_m)) {
            auto&& cs = prism_rtl::as<check_env::DefBody::DbFn>(_m).a0;
            _v.set(run_to_end(fold_job(cs, Array<ast::Expr>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<ast::Expr>>(std::tuple<Array<ast::Expr>, ast::FnClause>)>>(prism_rtl::rc([=](std::tuple<Array<ast::Expr>, ast::FnClause> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return entered(once_job([=]() {
                    return ({
                        auto acc = p0;
                        auto c = p1;
                        call_then(typed::start_body_exprs(c.body), [=](Array<ast::Expr> body_exprs_332534) { return prism_rtl::finished(append(acc, body_exprs_332534)); });
                    });
                }));
            })))));
            goto _done;
        }
        {
            _v.set(Array<ast::Expr>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    return fold(es, Array<Text>{}, [&](const Array<Text>& acc, const ast::Expr& e) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = e.kind;
            if (prism_rtl::is<ast::ExprKind::ECall>(_m)) {
                auto&& c = prism_rtl::as<ast::ExprKind::ECall>(_m).a0;
                auto&& args = prism_rtl::as<ast::ExprKind::ECall>(_m).a1;
                _v.set(blueprint_qk(lx, c) == Text::lit("Prelude.@Run")
                    ? ({
                    __label__ _done;
                    prism_rtl::Slot<Array<Text>> _v;
                    auto&& _m = index(args, Nat(0u));
                    if (prism_rtl::is_some(_m)) {
                        auto&& a = prism_rtl::some_of(_m);
                        _v.set(({
                            __label__ _done;
                            prism_rtl::Slot<Array<Text>> _v;
                            auto&& _m = a->value.kind;
                            if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
                                auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
                                _v.set(({
                                    auto&& _q_opt = check_env::resolve_value(lx.g, lx.home, n);
                                    auto&& q_opt = std::get<0>(_q_opt);
                                    ({
                                    __label__ _done;
                                    prism_rtl::Slot<Array<Text>> _v;
                                    if (prism_rtl::is_some(q_opt)) {
                                        auto&& q = prism_rtl::some_of(q_opt);
                                        _v.set(check_types::add_text(acc, q));
                                        goto _done;
                                    }
                                    if (prism_rtl::is_none(q_opt)) {
                                        _v.set(acc);
                                        goto _done;
                                    }
                                    prism_rtl::unreachable("no arm matched");
                                _done:
                                    _v.take();
                                });
                                }));
                                goto _done;
                            }
                            {
                                _v.set(acc);
                                goto _done;
                            }
                        _done:
                            _v.take();
                        }));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(acc);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                })
                    : acc);
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


prism_rtl::Turn<Array<Text>> RunTargets::cycle() const {
    const auto& lx = this->lx;
    const auto& d = this->d;
    auto es = ({
        __label__ _done;
        prism_rtl::Slot<Array<ast::Expr>> _v;
        auto&& _m = d.body;
        if (prism_rtl::is<check_env::DefBody::DbWidget>(_m)) {
            auto&& w = prism_rtl::as<check_env::DefBody::DbWidget>(_m).a0;
            _v.set(typed::block_exprs(w.body));
            goto _done;
        }
        if (prism_rtl::is<check_env::DefBody::DbFn>(_m)) {
            auto&& cs = prism_rtl::as<check_env::DefBody::DbFn>(_m).a0;
            _v.set(run_to_end(fold_job(cs, Array<ast::Expr>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<ast::Expr>>(std::tuple<Array<ast::Expr>, ast::FnClause>)>>(prism_rtl::rc([=](std::tuple<Array<ast::Expr>, ast::FnClause> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return entered(once_job([=]() {
                    return ({
                        auto acc = p0;
                        auto c = p1;
                        call_then(typed::start_body_exprs(c.body), [=](Array<ast::Expr> body_exprs_332534) { return prism_rtl::finished(append(acc, body_exprs_332534)); });
                    });
                }));
            })))));
            goto _done;
        }
        {
            _v.set(Array<ast::Expr>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    return prism_rtl::finished(fold(es, Array<Text>{}, [&](const Array<Text>& acc, const ast::Expr& e) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = e.kind;
            if (prism_rtl::is<ast::ExprKind::ECall>(_m)) {
                auto&& c = prism_rtl::as<ast::ExprKind::ECall>(_m).a0;
                auto&& args = prism_rtl::as<ast::ExprKind::ECall>(_m).a1;
                _v.set(blueprint_qk(lx, c) == Text::lit("Prelude.@Run")
                    ? ({
                    __label__ _done;
                    prism_rtl::Slot<Array<Text>> _v;
                    auto&& _m = index(args, Nat(0u));
                    if (prism_rtl::is_some(_m)) {
                        auto&& a = prism_rtl::some_of(_m);
                        _v.set(({
                            __label__ _done;
                            prism_rtl::Slot<Array<Text>> _v;
                            auto&& _m = a->value.kind;
                            if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
                                auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
                                _v.set(({
                                    auto&& _q_opt = check_env::resolve_value(lx.g, lx.home, n);
                                    auto&& q_opt = std::get<0>(_q_opt);
                                    ({
                                    __label__ _done;
                                    prism_rtl::Slot<Array<Text>> _v;
                                    if (prism_rtl::is_some(q_opt)) {
                                        auto&& q = prism_rtl::some_of(q_opt);
                                        _v.set(check_types::add_text(acc, q));
                                        goto _done;
                                    }
                                    if (prism_rtl::is_none(q_opt)) {
                                        _v.set(acc);
                                        goto _done;
                                    }
                                    prism_rtl::unreachable("no arm matched");
                                _done:
                                    _v.take();
                                });
                                }));
                                goto _done;
                            }
                            {
                                _v.set(acc);
                                goto _done;
                            }
                        _done:
                            _v.take();
                        }));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(acc);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                })
                    : acc);
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    }));
}


/// `Start RunTargets, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_run_targets(Lx lx, check_env::Def d) {
    return prism_rtl::make_rc<RunTargets>(lx, d);
}


/// TailTargets: unbounded fn Lx, Text -> [Text]
Array<Text> tail_targets(const Lx& lx, const Text& qk) {
    auto v_ = or_(prelude::get(lx.g.vals, qk), check_env::builtin(qk, check_types::mono(check_types::Ty(check_types::Ty::TyErr{}))));
    auto lxm = in_module(lx, v_->file, v_.home);
    return run_to_end(fold_job(clauses_of(lx.g, qk), Array<Text>{}, ({
        auto lxm_1 = lxm;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, ast::FnClause>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, ast::FnClause> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lxm_1_2 = lxm_1;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto c = p1;
                call_then(start_tails_of_body(lxm_1_2, c.body), [=](Array<Text> tails_of_body_333413) { return prism_rtl::finished(check_types::union_texts(acc, tails_of_body_333413)); });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<Array<Text>> TailTargets::cycle() const {
    const auto& lx = this->lx;
    const auto& qk = this->qk;
    auto v_ = or_(prelude::get(lx.g.vals, qk), check_env::builtin(qk, check_types::mono(check_types::Ty(check_types::Ty::TyErr{}))));
    auto lxm = in_module(lx, v_->file, v_.home);
    return fold_job(clauses_of(lx.g, qk), Array<Text>{}, ({
        auto lxm_1 = lxm;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, ast::FnClause>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, ast::FnClause> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lxm_1_2 = lxm_1;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto c = p1;
                call_then(start_tails_of_body(lxm_1_2, c.body), [=](Array<Text> tails_of_body_333413) { return prism_rtl::finished(check_types::union_texts(acc, tails_of_body_333413)); });
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start TailTargets, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_tail_targets(Lx lx, Text qk) {
    return prism_rtl::make_rc<TailTargets>(lx, qk);
}


/// TailsOfBody: unbounded fn Lx, FnBody -> [Text]
Array<Text> tails_of_body(const Lx& lx, const ast::FnBody& body) {
    return fold(typed::body_exprs(body), Array<Text>{}, [&](const Array<Text>& acc, const ast::Expr& e) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = e.kind;
            if (prism_rtl::is<ast::ExprKind::ECall>(_m)) {
                auto&& c = prism_rtl::as<ast::ExprKind::ECall>(_m).a0;
                _v.set(({
                    auto q = blueprint_qk(lx, c);
                    ({
                    __label__ _done;
                    prism_rtl::Slot<Array<Text>> _v;
                    auto&& _m = prelude::get(lx.g.vals, q);
                    if (prism_rtl::is_some(_m)) {
                        auto&& v_ = prism_rtl::some_of(_m);
                        _v.set(({
                            __label__ _done;
                            prism_rtl::Slot<Array<Text>> _v;
                            auto&& _m = v_.scheme.ty;
                            if (prism_rtl::is<check_types::Ty::TyFn>(_m) && prism_rtl::is<check_types::Col::CBound>(prism_rtl::as<check_types::Ty::TyFn>(_m).a0)) {
                                _v.set(acc);
                                goto _done;
                            }
                            if (prism_rtl::is<check_types::Ty::TyFn>(_m)) {
                                _v.set(check_types::add_text(acc, q));
                                goto _done;
                            }
                            {
                                _v.set(acc);
                                goto _done;
                            }
                        _done:
                            _v.take();
                        }));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(acc);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                }));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


prism_rtl::Turn<Array<Text>> TailsOfBody::cycle() const {
    const auto& lx = this->lx;
    const auto& body = this->body;
    auto body_1 = body;
    auto lx_2 = lx;
    return call_then(typed::start_body_exprs(body_1), [=](Array<ast::Expr> body_exprs_333518) {
        return prism_rtl::finished(fold(body_exprs_333518, Array<Text>{}, [&](const Array<Text>& acc, const ast::Expr& e) {
            return ({
                __label__ _done;
                prism_rtl::Slot<Array<Text>> _v;
                auto&& _m = e.kind;
                if (prism_rtl::is<ast::ExprKind::ECall>(_m)) {
                    auto&& c = prism_rtl::as<ast::ExprKind::ECall>(_m).a0;
                    _v.set(({
                        auto q = blueprint_qk(lx_2, c);
                        ({
                        __label__ _done;
                        prism_rtl::Slot<Array<Text>> _v;
                        auto&& _m = prelude::get(lx_2.g.vals, q);
                        if (prism_rtl::is_some(_m)) {
                            auto&& v_ = prism_rtl::some_of(_m);
                            _v.set(({
                                __label__ _done;
                                prism_rtl::Slot<Array<Text>> _v;
                                auto&& _m = v_.scheme.ty;
                                if (prism_rtl::is<check_types::Ty::TyFn>(_m) && prism_rtl::is<check_types::Col::CBound>(prism_rtl::as<check_types::Ty::TyFn>(_m).a0)) {
                                    _v.set(acc);
                                    goto _done;
                                }
                                if (prism_rtl::is<check_types::Ty::TyFn>(_m)) {
                                    _v.set(check_types::add_text(acc, q));
                                    goto _done;
                                }
                                {
                                    _v.set(acc);
                                    goto _done;
                                }
                            _done:
                                _v.take();
                            }));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(acc);
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                    }));
                    goto _done;
                }
                {
                    _v.set(acc);
                    goto _done;
                }
            _done:
                _v.take();
            });
        }));
    });
}


/// `Start TailsOfBody, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_tails_of_body(Lx lx, ast::FnBody body) {
    return prism_rtl::make_rc<TailsOfBody>(lx, body);
}


/// ModDefOf: unbounded fn Lx, Text, [((Text, Bool))], ModInfo, [Text] -> ModDef
ModDef mod_def_of(const Lx& lx0, const Text& m, const Array<std::tuple<Text, bool>>& roots, const check_env::ModInfo& info, const Array<Text>& mods) {
    auto lx = in_module(lx0, info->file, m);
    auto path_ = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = index(lx.g.srcs, info->file);
        if (prism_rtl::is_some(_m)) {
            auto&& src = prism_rtl::some_of(_m);
            _v.set(src->path_);
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto types = run_to_end(fold_job(values(lx.g.types), Array<Item>{}, ({
        auto m_1 = m;
        auto lx_2 = lx;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Item>>(std::tuple<Array<Item>, check_env::TyInfo>)>>(prism_rtl::rc([=](std::tuple<Array<Item>, check_env::TyInfo> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto m_1_3 = m_1;
            auto lx_2_3 = lx_2;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto ti = p1;
                ti.home == m_1_3
                ? call_then(start_ty_defs(lx_2_3, ti), [=](Array<Item> ty_defs_334243) { return prism_rtl::finished(append(acc, ty_defs_334243)); })
                : prism_rtl::finished(acc);
            });
        }));
        });
    })));
    })));
    auto tags = run_to_end(fold_job(values(lx.g.tags), Array<Item>{}, ({
        auto m_1 = m;
        auto lx_2 = lx;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Item>>(std::tuple<Array<Item>, check_env::TagInfo>)>>(prism_rtl::rc([=](std::tuple<Array<Item>, check_env::TagInfo> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto m_1_3 = m_1;
            auto lx_2_3 = lx_2;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto tg = p1;
                (tg.home == m_1_3) && (tg.kind != Text::lit("Prelude.Fault"))
                ? call_then(start_tag_def_of(lx_2_3, tg), [=](TagDef tag_def_of_334391) { return prism_rtl::finished(prelude::push(acc, Item(Item::ItTag{tag_def_of_334391}))); })
                : prism_rtl::finished(acc);
            });
        }));
        });
    })));
    })));
    auto defs = run_to_end(fold_job(lx.g.defs, Array<Item>{}, ({
        auto m_1 = m;
        auto lx_2 = lx;
        auto roots_3 = roots;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Item>>(std::tuple<Array<Item>, check_env::Def>)>>(prism_rtl::rc([=](std::tuple<Array<Item>, check_env::Def> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto m_1_4 = m_1;
            auto lx_2_4 = lx_2;
            auto roots_3_4 = roots_3;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto d = p1;
                d.home == m_1_4
                ? call_then(start_def_items(in_module(lx_2_4, d->file, m_1_4), d, roots_3_4), [=](Array<Item> def_items_334495) { return prism_rtl::finished(append(acc, def_items_334495)); })
                : prism_rtl::finished(acc);
            });
        }));
        });
    })));
    })));
    auto traits = run_to_end(fold_job(values(lx.g.traits), Array<Item>{}, ({
        auto m_1 = m;
        auto lx_2 = lx;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Item>>(std::tuple<Array<Item>, check_env::TraitInfo>)>>(prism_rtl::rc([=](std::tuple<Array<Item>, check_env::TraitInfo> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto m_1_3 = m_1;
            auto lx_2_3 = lx_2;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto tr = p1;
                tr.home == m_1_3
                ? call_then(start_trait_def_of(lx_2_3, tr), [=](TraitDef trait_def_of_334648) { return prism_rtl::finished(prelude::push(acc, Item(Item::ItTrait{trait_def_of_334648}))); })
                : prism_rtl::finished(acc);
            });
        }));
        });
    })));
    })));
    auto impls = run_to_end(fold_job(values(lx.g.impls), Array<Item>{}, ({
        auto m_1 = m;
        auto lx_2 = lx;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Item>>(std::tuple<Array<Item>, Array<check_env::ImplInfo>>)>>(prism_rtl::rc([=](std::tuple<Array<Item>, Array<check_env::ImplInfo>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto m_1_3 = m_1;
            auto lx_2_3 = lx_2;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto ims = p1;
                fold_job(ims, acc, ({
                auto m_1_3_3 = m_1_3;
                auto lx_2_3_3 = lx_2_3;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Item>>(std::tuple<Array<Item>, check_env::ImplInfo>)>>(prism_rtl::rc([=](std::tuple<Array<Item>, check_env::ImplInfo> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto m_1_3_3_3 = m_1_3_3;
                    auto lx_2_3_3_3 = lx_2_3_3;
                    entered(once_job([=]() {
                    return ({
                        auto a = p0;
                        auto im = p1;
                        (im.home == m_1_3_3_3) && (!im.derived)
                        ? call_then(start_impl_def_of(in_module(lx_2_3_3_3, im->file, m_1_3_3_3), im), [=](ImplDef impl_def_of_334815) { return prism_rtl::finished(prelude::push(a, Item(Item::ItImpl{impl_def_of_334815}))); })
                        : prism_rtl::finished(a);
                    });
                }));
                });
            })));
            }))->cycle();
            });
        }));
        });
    })));
    })));
    auto uses = filter(each(mods, [&](const Text& o) { return rust_mod_name(o); }), [&](const Text& o) { return o != rust_mod_name(m); });
    return ModDef{.name = rust_mod_name(m), .prism = m, .path_ = path_, .uses = uses, .complete = Array<Text>{}, .declared = Array<Text>{}, .types_with = Array<Text>{}, .items = append(append(append(append(types, tags), traits), impls), defs)};
}


prism_rtl::Turn<ModDef> ModDefOf::cycle() const {
    const auto& lx0 = this->lx0;
    const auto& m = this->m;
    const auto& roots = this->roots;
    const auto& info = this->info;
    const auto& mods = this->mods;
    auto lx = in_module(lx0, info->file, m);
    auto path_ = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = index(lx.g.srcs, info->file);
        if (prism_rtl::is_some(_m)) {
            auto&& src = prism_rtl::some_of(_m);
            _v.set(src->path_);
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto m_1 = m;
    auto mods_2 = mods;
    auto roots_3 = roots;
    return call_value(fold_job(values(lx.g.types), Array<Item>{}, ({
        auto m_1_4 = m_1;
        auto lx_4 = lx;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Item>>(std::tuple<Array<Item>, check_env::TyInfo>)>>(prism_rtl::rc([=](std::tuple<Array<Item>, check_env::TyInfo> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto m_1_4_5 = m_1_4;
            auto lx_4_5 = lx_4;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto ti = p1;
                ti.home == m_1_4_5
                ? call_then(start_ty_defs(lx_4_5, ti), [=](Array<Item> ty_defs_334243) { return prism_rtl::finished(append(acc, ty_defs_334243)); })
                : prism_rtl::finished(acc);
            });
        }));
        });
    })));
    })), [=](Array<Item> fold_334170) {
        return ({
            auto types = fold_334170;
            call_value(fold_job(values(lx.g.tags), Array<Item>{}, ({
            auto m_1_4 = m_1;
            auto lx_4 = lx;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Item>>(std::tuple<Array<Item>, check_env::TagInfo>)>>(prism_rtl::rc([=](std::tuple<Array<Item>, check_env::TagInfo> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto m_1_4_5 = m_1_4;
                auto lx_4_5 = lx_4;
                entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto tg = p1;
                    (tg.home == m_1_4_5) && (tg.kind != Text::lit("Prelude.Fault"))
                    ? call_then(start_tag_def_of(lx_4_5, tg), [=](TagDef tag_def_of_334391) { return prism_rtl::finished(prelude::push(acc, Item(Item::ItTag{tag_def_of_334391}))); })
                    : prism_rtl::finished(acc);
                });
            }));
            });
        })));
        })), [=](Array<Item> fold_334283) {
            return ({
                auto tags = fold_334283;
                call_value(fold_job(lx.g.defs, Array<Item>{}, ({
                auto m_1_4 = m_1;
                auto lx_4 = lx;
                auto roots_3_5 = roots_3;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Item>>(std::tuple<Array<Item>, check_env::Def>)>>(prism_rtl::rc([=](std::tuple<Array<Item>, check_env::Def> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto m_1_4_5 = m_1_4;
                    auto lx_4_5 = lx_4;
                    auto roots_3_5_5 = roots_3_5;
                    entered(once_job([=]() {
                    return ({
                        auto acc = p0;
                        auto d = p1;
                        d.home == m_1_4_5
                        ? call_then(start_def_items(in_module(lx_4_5, d->file, m_1_4_5), d, roots_3_5_5), [=](Array<Item> def_items_334495) { return prism_rtl::finished(append(acc, def_items_334495)); })
                        : prism_rtl::finished(acc);
                    });
                }));
                });
            })));
            })), [=](Array<Item> fold_334434) {
                return ({
                    auto defs = fold_334434;
                    call_value(fold_job(values(lx.g.traits), Array<Item>{}, ({
                    auto m_1_4 = m_1;
                    auto lx_4 = lx;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Item>>(std::tuple<Array<Item>, check_env::TraitInfo>)>>(prism_rtl::rc([=](std::tuple<Array<Item>, check_env::TraitInfo> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto m_1_4_5 = m_1_4;
                        auto lx_4_5 = lx_4;
                        entered(once_job([=]() {
                        return ({
                            auto acc = p0;
                            auto tr = p1;
                            tr.home == m_1_4_5
                            ? call_then(start_trait_def_of(lx_4_5, tr), [=](TraitDef trait_def_of_334648) { return prism_rtl::finished(prelude::push(acc, Item(Item::ItTrait{trait_def_of_334648}))); })
                            : prism_rtl::finished(acc);
                        });
                    }));
                    });
                })));
                })), [=](Array<Item> fold_334567) {
                    return ({
                        auto traits = fold_334567;
                        call_value(fold_job(values(lx.g.impls), Array<Item>{}, ({
                        auto m_1_4 = m_1;
                        auto lx_4 = lx;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Item>>(std::tuple<Array<Item>, Array<check_env::ImplInfo>>)>>(prism_rtl::rc([=](std::tuple<Array<Item>, Array<check_env::ImplInfo>> _p0) {
                        auto&& p0 = std::get<0>(_p0);
                        auto&& p1 = std::get<1>(_p0);
                        return ({
                            auto m_1_4_5 = m_1_4;
                            auto lx_4_5 = lx_4;
                            entered(once_job([=]() {
                            return ({
                                auto acc = p0;
                                auto ims = p1;
                                fold_job(ims, acc, ({
                                auto m_1_4_5_5 = m_1_4_5;
                                auto lx_4_5_5 = lx_4_5;
                                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Item>>(std::tuple<Array<Item>, check_env::ImplInfo>)>>(prism_rtl::rc([=](std::tuple<Array<Item>, check_env::ImplInfo> _p0) {
                                auto&& p0 = std::get<0>(_p0);
                                auto&& p1 = std::get<1>(_p0);
                                return ({
                                    auto m_1_4_5_5_5 = m_1_4_5_5;
                                    auto lx_4_5_5_5 = lx_4_5_5;
                                    entered(once_job([=]() {
                                    return ({
                                        auto a = p0;
                                        auto im = p1;
                                        (im.home == m_1_4_5_5_5) && (!im.derived)
                                        ? call_then(start_impl_def_of(in_module(lx_4_5_5_5, im->file, m_1_4_5_5_5), im), [=](ImplDef impl_def_of_334815) { return prism_rtl::finished(prelude::push(a, Item(Item::ItImpl{impl_def_of_334815}))); })
                                        : prism_rtl::finished(a);
                                    });
                                }));
                                });
                            })));
                            }))->cycle();
                            });
                        }));
                        });
                    })));
                    })), [=](Array<Item> fold_334694) {
                        return ({
                            auto impls = fold_334694;
                            auto uses = filter(each(mods_2, [&](const Text& o) { return rust_mod_name(o); }), [&](const Text& o) { return o != rust_mod_name(m_1); });
                            (prism_rtl::finished(ModDef{.name = rust_mod_name(m_1), .prism = m_1, .path_ = path_, .uses = uses, .complete = Array<Text>{}, .declared = Array<Text>{}, .types_with = Array<Text>{}, .items = append(append(append(append(types, tags), traits), impls), defs)}));
                        });
                    });
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start ModDefOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<ModDef> start_mod_def_of(Lx lx0, Text m, Array<std::tuple<Text, bool>> roots, check_env::ModInfo info, Array<Text> mods) {
    return prism_rtl::make_rc<ModDefOf>(lx0, m, roots, info, mods);
}


/// DefItems: unbounded fn Lx, Def, [((Text, Bool))] -> [Item]
Array<Item> def_items(const Lx& lx, const check_env::Def& d, const Array<std::tuple<Text, bool>>& roots) {
    auto is_root = check_types::has_text(each(roots, [&](const std::tuple<Text, bool>& _p0) {
        auto&& q = std::get<0>(_p0);
        return q;
    }), d.qk);
    auto&& _m = d.body;
    if (prism_rtl::is<check_env::DefBody::DbWidget>(_m)) {
        auto&& w = prism_rtl::as<check_env::DefBody::DbWidget>(_m).a0;
        return is_root
            ? node_items(node_def_of(lx, d.qk, Array<ast::Pattern_>{}, w.body, or_(prelude::get(lx.g.vals, d.qk), check_env::builtin(d.qk, check_types::mono(check_types::Ty(check_types::Ty::TyErr{})))).scheme, true))
            : Array(std::vector{Item(Item::ItNote{prism_rtl::cat("`", d.name, "` is inlined where it is applied.")})});
    }
    if (prism_rtl::is<check_env::DefBody::DbFn>(_m)) {
        auto&& clauses = prism_rtl::as<check_env::DefBody::DbFn>(_m).a0;
        auto&& _m = prelude::get(lx.g.vals, d.qk);
        if (prism_rtl::is_none(_m)) {
            return Array<Item>{};
        }
        if (prism_rtl::is_some(_m)) {
            auto&& v_ = prism_rtl::some_of(_m);
            auto&& _m = v_.scheme.ty;
            if (prism_rtl::is<check_types::Ty::TyFn>(_m)) {
                auto&& m335733_0_2 = prism_rtl::as<check_types::Ty::TyFn>(_m).a2;
                if (prism_rtl::is<check_types::Ty::TyAt>(m335733_0_2)) {
                    return !is_root
                        ? Array(std::vector{Item(Item::ItNote{prism_rtl::cat("`", d.name, "` is inlined where it is applied.")})})
                        : ({
                        __label__ _done;
                        prism_rtl::Slot<Array<Item>> _v;
                        {
                            auto&& m335929_0 = clauses;
                            if (m335929_0.size() == 1u) {
                                {
                                    auto&& _c1 = index(m335929_0, Nat(0u));
                                    if (prism_rtl::is_some(_c1)) {
                                        auto&& c = prism_rtl::some_of(_c1);
                                        _v.set(({
                                            __label__ _done;
                                            prism_rtl::Slot<Array<Item>> _v;
                                            auto&& _m = c.body;
                                            if (prism_rtl::is<ast::FnBody::BodyBlock>(_m)) {
                                                auto&& b = prism_rtl::as<ast::FnBody::BodyBlock>(_m).a0;
                                                _v.set(node_items(node_def_of(lx, d.qk, c.params, b, v_.scheme, true)));
                                                goto _done;
                                            }
                                            {
                                                _v.set(Array(std::vector{Item(Item::ItRefused{prism_rtl::cat("`", d.name, "`, a root widget whose body is one expression")})}));
                                                goto _done;
                                            }
                                        _done:
                                            _v.take();
                                        }));
                                        goto _done;
                                    }
                                }
                            }
                        }
                        {
                            _v.set(Array(std::vector{Item(Item::ItRefused{prism_rtl::cat("`", d.name, "`, a root widget of several clauses")})}));
                            goto _done;
                        }
                    _done:
                        _v.take();
                    });
                }
            }
            {
                auto f = Item(Item::ItFn{fn_def_of(lx, d.qk, clauses, v_.scheme)});
                return check_types::has_text(lx.unbs, d.qk)
                    ? Array(std::vector{f, Item(Item::ItJob{job_def_of(lx, d.qk, clauses, v_.scheme)})})
                    : Array(std::vector{f});
            }
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<check_env::DefBody::DbLet>(_m)) {
        auto&& l = prism_rtl::as<check_env::DefBody::DbLet>(_m).a0;
        return Array(std::vector{Item(Item::ItFn{let_getter(lx, d.qk, l)})});
    }
    {
        return Array<Item>{};
    }
}


prism_rtl::Turn<Array<Item>> DefItems::cycle() const {
    const auto& lx = this->lx;
    const auto& d = this->d;
    const auto& roots = this->roots;
    auto is_root = check_types::has_text(each(roots, [&](const std::tuple<Text, bool>& _p0) {
        auto&& q = std::get<0>(_p0);
        return q;
    }), d.qk);
    return ({
        auto&& _m = d.body;
        prism_rtl::is<check_env::DefBody::DbWidget>(_m) ? ({
        auto&& w = prism_rtl::as<check_env::DefBody::DbWidget>(_m).a0;
        is_root
        ? ({
        auto d_1 = d;
        auto lx_2 = lx;
        auto w_3 = w;
        call_then(start_node_def_of(lx_2, d_1.qk, Array<ast::Pattern_>{}, w_3.body, or_(prelude::get(lx_2.g.vals, d_1.qk), check_env::builtin(d_1.qk, check_types::mono(check_types::Ty(check_types::Ty::TyErr{})))).scheme, true), [=](NodeDef node_def_of_335476) { return prism_rtl::finished(node_items(node_def_of_335476)); });
    })
        : prism_rtl::finished(Array(std::vector{Item(Item::ItNote{prism_rtl::cat("`", d.name, "` is inlined where it is applied.")})}));
    })
        : prism_rtl::is<check_env::DefBody::DbFn>(_m) ? ({
        auto&& clauses = prism_rtl::as<check_env::DefBody::DbFn>(_m).a0;
        ({
        auto&& _m = prelude::get(lx.g.vals, d.qk);
        prism_rtl::is_none(_m) ? prism_rtl::finished(Array<Item>{})
        : prism_rtl::is_some(_m) ? ({
        auto&& v_ = prism_rtl::some_of(_m);
        ({
        auto&& _m = v_.scheme.ty;
        prism_rtl::is<check_types::Ty::TyFn>(_m) && ({
        auto&& m335733_0_2 = prism_rtl::as<check_types::Ty::TyFn>(_m).a2;
        prism_rtl::is<check_types::Ty::TyAt>(m335733_0_2);
    }) ? ({
        auto&& m335733_0_2 = prism_rtl::as<check_types::Ty::TyFn>(_m).a2;
        !is_root
        ? prism_rtl::finished(Array(std::vector{Item(Item::ItNote{prism_rtl::cat("`", d.name, "` is inlined where it is applied.")})}))
        : ({
        ({
        auto&& m335929_0 = clauses;
        (m335929_0.size() == 1u) && ({
        auto&& _c1 = index(m335929_0, Nat(0u));
        prism_rtl::is_some(_c1);
    });
    }) ? ({
        auto&& m335929_0 = clauses;
        auto&& _c1 = index(m335929_0, Nat(0u));
        auto&& c = prism_rtl::some_of(_c1);
        ({
        auto&& _m = c.body;
        prism_rtl::is<ast::FnBody::BodyBlock>(_m) ? ({
        auto&& b = prism_rtl::as<ast::FnBody::BodyBlock>(_m).a0;
        ({
        auto b_1 = b;
        auto d_2 = d;
        auto lx_3 = lx;
        call_then(start_node_def_of(lx_3, d_2.qk, c.params, b_1, v_.scheme, true), [=](NodeDef node_def_of_336041) { return prism_rtl::finished(node_items(node_def_of_336041)); });
    });
    })
        : prism_rtl::finished(Array(std::vector{Item(Item::ItRefused{prism_rtl::cat("`", d.name, "`, a root widget whose body is one expression")})}));
    });
    })
        : prism_rtl::finished(Array(std::vector{Item(Item::ItRefused{prism_rtl::cat("`", d.name, "`, a root widget of several clauses")})}));
    });
    })
        : ({
        auto clauses_1 = clauses;
        auto d_2 = d;
        auto lx_3 = lx;
        call_then(start_fn_def_of(lx_3, d_2.qk, clauses_1, v_.scheme), [=](FnDef fn_def_of_336357) {
        return ({
            auto f = Item(Item::ItFn{fn_def_of_336357});
            (check_types::has_text(lx_3.unbs, d_2.qk)
            ? call_then(start_job_def_of(lx_3, d_2.qk, clauses_1, v_.scheme), [=](JobDef job_def_of_336452) { return prism_rtl::finished(Array(std::vector{f, Item(Item::ItJob{job_def_of_336452})})); })
            : prism_rtl::finished(Array(std::vector{f})));
        });
    });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : prism_rtl::is<check_env::DefBody::DbLet>(_m) ? ({
        auto&& l = prism_rtl::as<check_env::DefBody::DbLet>(_m).a0;
        ({
        auto d_1 = d;
        auto l_2 = l;
        auto lx_3 = lx;
        call_then(start_let_getter(lx_3, d_1.qk, l_2), [=](FnDef let_getter_336529) { return prism_rtl::finished(Array(std::vector{Item(Item::ItFn{let_getter_336529})})); });
    });
    })
        : prism_rtl::finished(Array<Item>{});
    });
}


/// `Start DefItems, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Item>> start_def_items(Lx lx, check_env::Def d, Array<std::tuple<Text, bool>> roots) {
    return prism_rtl::make_rc<DefItems>(lx, d, roots);
}


/// NodeItems: fn NodeDef -> [Item]
Array<Item> node_items(const NodeDef& n) {
    return append(Array(std::vector{Item(Item::ItNode{n})}), each(n.children, [&](const NodeDef& c) { return Item(Item::ItNode{c}); }));
}


/// TyDefs: unbounded fn Lx, TyInfo -> [Item]
Array<Item> ty_defs(const Lx& lx, const check_env::TyInfo& ti) {
    auto derives = each(ti.derives, [&](const Text& dn) { return check_types::bare_name(dn); });
    auto params = each(ti.params, [&](const Text& p_) { return camel(p_); });
    auto floaty_ = floaty(lx.g, check_types::Ty(check_types::Ty::TyCon{ti.name, Array<check_types::Ty>{}}), Array<Text>{});
    auto bare = check_types::bare_name(ti.name);
    auto mk_fn = ({
        auto bare_1 = bare;
        auto params_2 = params;
        auto derives_3 = derives;
        auto floaty__4 = floaty_;
        auto lx_5 = lx;
        auto ti_6 = ti;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<TyDef>(std::tuple<TyShape, Array<CaseDef>>)>>(prism_rtl::rc([=](std::tuple<TyShape, Array<CaseDef>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto bare_1_7 = bare_1;
            auto params_2_7 = params_2;
            auto derives_3_7 = derives_3;
            auto floaty__4_7 = floaty__4;
            auto lx_5_7 = lx_5;
            auto ti_6_7 = ti_6;
            entered(once_job([=]() {
            return ({
                auto shape = p0;
                auto cases = p1;
                call_then(start_ty_podable(lx_5_7, check_types::Ty(check_types::Ty::TyCon{ti_6_7.name, Array<check_types::Ty>{}}), Array<Text>{}), [=](bool ty_podable_337319) {
                return prism_rtl::finished(TyDef{.name = camel(bare_1_7), .prism = bare_1_7, .params = params_2_7, .shape = shape, .cases_ = cases, .eq = check_types::has_text(derives_3_7, Text::lit("Eq")), .ord = check_types::has_text(derives_3_7, Text::lit("Ord")), .floaty = floaty__4_7, .show_ = has_own_show(lx_5_7, ti_6_7.name)
                    ? Shown(Shown::ShownOwn{})
                    : check_types::has_text(derives_3_7, Text::lit("Show"))
                    ? Shown(Shown::ShownDerived{})
                    : Shown(Shown::NotShown{}), .pod = ty_podable_337319 && run_to_end(fold_job(cases, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, CaseDef>)>>(prism_rtl::rc([=](std::tuple<bool, CaseDef> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return entered(once_job([=]() {
                        return ({
                            auto ok = p0;
                            auto c = p1;
                            (prism_rtl::finished(ok && run_to_end(fold_job(c.fields, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, OutTy>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<Text, OutTy>> _p0) {
                            auto&& p0 = std::get<0>(_p0);
                            auto&& p1 = std::get<1>(_p0);
                            return entered(once_job([=]() {
                                return ({
                                    auto ok2 = p0;
                                    auto&& _ft = p1;
                                    auto&& ft = std::get<1>(_ft);
                                    (prism_rtl::finished(ok2 && podable(ft)));
                                });
                            }));
                        }))))));
                        });
                    }));
                })))), .doc = type_doc(lx_5_7, ti_6_7)});
            });
            });
        }));
        });
    })));
    });
    auto&& _m = ti.body;
    if (prism_rtl::is<check_env::TyBody::BRecord>(_m)) {
        auto&& fs = prism_rtl::as<check_env::TyBody::BRecord>(_m).a0;
        auto fields = run_to_end(each_job(check_errors::range0(len(fs)), ({
            auto fs_1 = fs;
            auto lx_2 = lx;
            auto ti_3 = ti;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, OutTy>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
            return ({
                auto fs_1_4 = fs_1;
                auto lx_2_4 = lx_2;
                auto ti_3_4 = ti_3;
                entered(once_job([=]() {
                return ({
                    auto i = p0;
                    ({
                    auto [fname, ft] = or_(index(fs_1_4, i), std::tuple{Text::lit(""), check_types::Ty(check_types::Ty::TyErr{})});
                    call_then(start_out_ty_of(lx_2_4, ft), [=](OutTy out_ty_of_337665) {
                    return ({
                        auto rt = out_ty_of_337665;
                        (prism_rtl::finished(std::tuple{snake(fname), rc_field(lx_2_4, ti_3_4.name, i)
                        ? OutTy(OutTy::OutRc{prism_rtl::rc(rt)})
                        : rt}));
                    });
                });
                });
                });
            }));
            });
        }));
        })));
        return Array(std::vector{Item(Item::ItType{run_to_end(mk_fn(std::tuple{TyShape(TyShape::ShapeRecord{}), Array(std::vector{CaseDef{.name = camel(bare), .prism = bare, .fields = fields}})}))})});
    }
    if (prism_rtl::is<check_env::TyBody::BChoice>(_m)) {
        auto&& cases = prism_rtl::as<check_env::TyBody::BChoice>(_m).a0;
        auto defs = run_to_end(each_job(cases, ({
            auto ti_1 = ti;
            auto lx_2 = lx;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<CaseDef>(std::tuple<Text, Array<check_types::Ty>>)>>(prism_rtl::rc([=](std::tuple<Text, Array<check_types::Ty>> p0) {
            return ({
                auto ti_1_3 = ti_1;
                auto lx_2_3 = lx_2;
                entered(once_job([=]() {
                return ({
                    auto [cn, ats] = p0;
                    ({
                    auto ck = check_env::qual_key(ti_1_3.home, cn);
                    call_value(each_job(check_errors::range0(len(ats)), ({
                    auto lx_2_3_3 = lx_2_3;
                    auto ck_3 = ck;
                    auto ats_4 = ats;
                    static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, OutTy>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
                    return ({
                        auto lx_2_3_3_5 = lx_2_3_3;
                        auto ck_3_5 = ck_3;
                        auto ats_4_5 = ats_4;
                        entered(once_job([=]() {
                        return ({
                            auto i = p0;
                            call_then(start_case_field(lx_2_3_3_5, ck_3_5, i, or_(index(ats_4_5, i), check_types::Ty(check_types::Ty::TyErr{}))), [=](OutTy case_field_338073) { return prism_rtl::finished(std::tuple{Text::lit(""), case_field_338073}); });
                        });
                    }));
                    });
                }));
                })), [=](Array<std::tuple<Text, OutTy>> each_338036) { return prism_rtl::finished(CaseDef{.name = camel(cn), .prism = cn, .fields = each_338036}); });
                });
                });
            }));
            });
        })));
        })));
        auto shape = ({
            __label__ _done;
            prism_rtl::Slot<TyShape> _v;
            {
                auto&& m338142_0 = cases;
                if (m338142_0.size() == 1u) {
                    {
                        auto&& _c2 = index(m338142_0, Nat(0u));
                        if (prism_rtl::is_some(_c2)) {
                            auto&& cn = std::get<0>(prism_rtl::some_of(_c2));
                            auto&& m338142_0_0_1 = std::get<1>(prism_rtl::some_of(_c2));
                            if (m338142_0_0_1.size() == 0u) {
                                _v.set(check_env::is_lower_text(cn)
                                    ? TyShape(TyShape::ShapeUnit{})
                                    : TyShape(TyShape::ShapeChoice{}));
                                goto _done;
                            }
                        }
                    }
                }
            }
            {
                auto&& m338142_1 = cases;
                if (m338142_1.size() == 1u) {
                    {
                        auto&& _c1 = index(m338142_1, Nat(0u));
                        if (prism_rtl::is_some(_c1)) {
                            auto&& cn = std::get<0>(prism_rtl::some_of(_c1));
                            _v.set(cn == bare
                                ? TyShape(TyShape::ShapeNewtype{})
                                : TyShape(TyShape::ShapeChoice{}));
                            goto _done;
                        }
                    }
                }
            }
            {
                _v.set(TyShape(TyShape::ShapeChoice{}));
                goto _done;
            }
        _done:
            _v.take();
        });
        return Array(std::vector{Item(Item::ItType{run_to_end(mk_fn(std::tuple{shape, defs}))})});
    }
    if (prism_rtl::is<check_env::TyBody::BRowKind>(_m)) {
        return ti.name == Text::lit("Prelude.Fault")
            ? Array<Item>{}
            : Array(std::vector{Item(Item::ItRow{row_def_of(lx, ti)})});
    }
    {
        return Array<Item>{};
    }
}


prism_rtl::Turn<Array<Item>> TyDefs::cycle() const {
    const auto& lx = this->lx;
    const auto& ti = this->ti;
    auto derives = each(ti.derives, [&](const Text& dn) { return check_types::bare_name(dn); });
    auto params = each(ti.params, [&](const Text& p_) { return camel(p_); });
    auto lx_1 = lx;
    auto ti_2 = ti;
    return call_then(start_floaty(lx_1.g, check_types::Ty(check_types::Ty::TyCon{ti_2.name, Array<check_types::Ty>{}}), Array<Text>{}), [=](bool floaty_336954) {
        return ({
            auto floaty_ = floaty_336954;
            auto bare = check_types::bare_name(ti_2.name);
            auto mk_fn = ({
                auto bare_3 = bare;
                auto params_4 = params;
                auto derives_5 = derives;
                auto floaty__6 = floaty_;
                auto lx_1_7 = lx_1;
                auto ti_2_7 = ti_2;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<TyDef>(std::tuple<TyShape, Array<CaseDef>>)>>(prism_rtl::rc([=](std::tuple<TyShape, Array<CaseDef>> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto bare_3_7 = bare_3;
                    auto params_4_7 = params_4;
                    auto derives_5_7 = derives_5;
                    auto floaty__6_7 = floaty__6;
                    auto lx_1_7_7 = lx_1_7;
                    auto ti_2_7_7 = ti_2_7;
                    entered(once_job([=]() {
                    return ({
                        auto shape = p0;
                        auto cases = p1;
                        call_then(start_ty_podable(lx_1_7_7, check_types::Ty(check_types::Ty::TyCon{ti_2_7_7.name, Array<check_types::Ty>{}}), Array<Text>{}), [=](bool ty_podable_337319) {
                        return prism_rtl::finished(TyDef{.name = camel(bare_3_7), .prism = bare_3_7, .params = params_4_7, .shape = shape, .cases_ = cases, .eq = check_types::has_text(derives_5_7, Text::lit("Eq")), .ord = check_types::has_text(derives_5_7, Text::lit("Ord")), .floaty = floaty__6_7, .show_ = has_own_show(lx_1_7_7, ti_2_7_7.name)
                            ? Shown(Shown::ShownOwn{})
                            : check_types::has_text(derives_5_7, Text::lit("Show"))
                            ? Shown(Shown::ShownDerived{})
                            : Shown(Shown::NotShown{}), .pod = ty_podable_337319 && run_to_end(fold_job(cases, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, CaseDef>)>>(prism_rtl::rc([=](std::tuple<bool, CaseDef> _p0) {
                            auto&& p0 = std::get<0>(_p0);
                            auto&& p1 = std::get<1>(_p0);
                            return entered(once_job([=]() {
                                return ({
                                    auto ok = p0;
                                    auto c = p1;
                                    (prism_rtl::finished(ok && run_to_end(fold_job(c.fields, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, OutTy>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<Text, OutTy>> _p0) {
                                    auto&& p0 = std::get<0>(_p0);
                                    auto&& p1 = std::get<1>(_p0);
                                    return entered(once_job([=]() {
                                        return ({
                                            auto ok2 = p0;
                                            auto&& _ft = p1;
                                            auto&& ft = std::get<1>(_ft);
                                            (prism_rtl::finished(ok2 && podable(ft)));
                                        });
                                    }));
                                }))))));
                                });
                            }));
                        })))), .doc = type_doc(lx_1_7_7, ti_2_7_7)});
                    });
                    });
                }));
                });
            })));
            });
            ({
            auto&& _m = ti_2.body;
            prism_rtl::is<check_env::TyBody::BRecord>(_m) ? ({
            auto&& fs = prism_rtl::as<check_env::TyBody::BRecord>(_m).a0;
            ({
            auto fs_3 = fs;
            call_value(each_job(check_errors::range0(len(fs_3)), ({
            auto fs_3_4 = fs_3;
            auto lx_1_4 = lx_1;
            auto ti_2_4 = ti_2;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, OutTy>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
            return ({
                auto fs_3_4_4 = fs_3_4;
                auto lx_1_4_4 = lx_1_4;
                auto ti_2_4_4 = ti_2_4;
                entered(once_job([=]() {
                return ({
                    auto i = p0;
                    ({
                    auto [fname, ft] = or_(index(fs_3_4_4, i), std::tuple{Text::lit(""), check_types::Ty(check_types::Ty::TyErr{})});
                    call_then(start_out_ty_of(lx_1_4_4, ft), [=](OutTy out_ty_of_337665) {
                    return ({
                        auto rt = out_ty_of_337665;
                        (prism_rtl::finished(std::tuple{snake(fname), rc_field(lx_1_4_4, ti_2_4_4.name, i)
                        ? OutTy(OutTy::OutRc{prism_rtl::rc(rt)})
                        : rt}));
                    });
                });
                });
                });
            }));
            });
        }));
        })), [=](Array<std::tuple<Text, OutTy>> each_337551) {
            return ({
                auto fields = each_337551;
                call_value(mk_fn(std::tuple{TyShape(TyShape::ShapeRecord{}), Array(std::vector{CaseDef{.name = camel(bare), .prism = bare, .fields = fields}})}), [=](TyDef mk_337782) { return prism_rtl::finished(Array(std::vector{Item(Item::ItType{mk_337782})})); });
            });
        });
        });
        })
            : prism_rtl::is<check_env::TyBody::BChoice>(_m) ? ({
            auto&& cases = prism_rtl::as<check_env::TyBody::BChoice>(_m).a0;
            ({
            auto cases_3 = cases;
            call_value(each_job(cases_3, ({
            auto ti_2_4 = ti_2;
            auto lx_1_4 = lx_1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<CaseDef>(std::tuple<Text, Array<check_types::Ty>>)>>(prism_rtl::rc([=](std::tuple<Text, Array<check_types::Ty>> p0) {
            return ({
                auto ti_2_4_4 = ti_2_4;
                auto lx_1_4_4 = lx_1_4;
                entered(once_job([=]() {
                return ({
                    auto [cn, ats] = p0;
                    ({
                    auto ck = check_env::qual_key(ti_2_4_4.home, cn);
                    call_value(each_job(check_errors::range0(len(ats)), ({
                    auto lx_1_4_4_4 = lx_1_4_4;
                    auto ck_4 = ck;
                    auto ats_5 = ats;
                    static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, OutTy>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
                    return ({
                        auto lx_1_4_4_4_6 = lx_1_4_4_4;
                        auto ck_4_6 = ck_4;
                        auto ats_5_6 = ats_5;
                        entered(once_job([=]() {
                        return ({
                            auto i = p0;
                            call_then(start_case_field(lx_1_4_4_4_6, ck_4_6, i, or_(index(ats_5_6, i), check_types::Ty(check_types::Ty::TyErr{}))), [=](OutTy case_field_338073) { return prism_rtl::finished(std::tuple{Text::lit(""), case_field_338073}); });
                        });
                    }));
                    });
                }));
                })), [=](Array<std::tuple<Text, OutTy>> each_338036) { return prism_rtl::finished(CaseDef{.name = camel(cn), .prism = cn, .fields = each_338036}); });
                });
                });
            }));
            });
        })));
        })), [=](Array<CaseDef> each_337905) {
            return ({
                auto defs = each_337905;
                auto shape = ({
                    __label__ _done;
                    prism_rtl::Slot<TyShape> _v;
                    {
                        auto&& m338142_0 = cases;
                        if (m338142_0.size() == 1u) {
                            {
                                auto&& _c2 = index(m338142_0, Nat(0u));
                                if (prism_rtl::is_some(_c2)) {
                                    auto&& cn = std::get<0>(prism_rtl::some_of(_c2));
                                    auto&& m338142_0_0_1 = std::get<1>(prism_rtl::some_of(_c2));
                                    if (m338142_0_0_1.size() == 0u) {
                                        _v.set(check_env::is_lower_text(cn)
                                            ? TyShape(TyShape::ShapeUnit{})
                                            : TyShape(TyShape::ShapeChoice{}));
                                        goto _done;
                                    }
                                }
                            }
                        }
                    }
                    {
                        auto&& m338142_1 = cases;
                        if (m338142_1.size() == 1u) {
                            {
                                auto&& _c1 = index(m338142_1, Nat(0u));
                                if (prism_rtl::is_some(_c1)) {
                                    auto&& cn = std::get<0>(prism_rtl::some_of(_c1));
                                    _v.set(cn == bare
                                        ? TyShape(TyShape::ShapeNewtype{})
                                        : TyShape(TyShape::ShapeChoice{}));
                                    goto _done;
                                }
                            }
                        }
                    }
                    {
                        _v.set(TyShape(TyShape::ShapeChoice{}));
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                call_value(mk_fn(std::tuple{shape, defs}), [=](TyDef mk_338379) { return prism_rtl::finished(Array(std::vector{Item(Item::ItType{mk_338379})})); });
            });
        });
        });
        })
            : prism_rtl::is<check_env::TyBody::BRowKind>(_m) ? ti_2.name == Text::lit("Prelude.Fault")
            ? prism_rtl::finished(Array<Item>{})
            : call_then(start_row_def_of(lx_1, ti_2), [=](RowDef row_def_of_338466) { return prism_rtl::finished(Array(std::vector{Item(Item::ItRow{row_def_of_338466})})); })
            : prism_rtl::finished(Array<Item>{});
        });
        });
    });
}


/// `Start TyDefs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Item>> start_ty_defs(Lx lx, check_env::TyInfo ti) {
    return prism_rtl::make_rc<TyDefs>(lx, ti);
}


/// TyPodable: unbounded fn Lx, Ty, [Text] -> Bool
bool ty_podable(const Lx& lx, const check_types::Ty& t, const Array<Text>& seen) {
    if (prism_rtl::is<check_types::Ty::TyFn>(t)) {
        return false;
    }
    if (prism_rtl::is<check_types::Ty::TyAt>(t)) {
        return false;
    }
    if (prism_rtl::is<check_types::Ty::TySig>(t)) {
        auto&& m338787_2_0 = prism_rtl::as<check_types::Ty::TySig>(t).a0;
        if (m338787_2_0 == Text::lit("!")) {
            return false;
        }
    }
    if (prism_rtl::is<check_types::Ty::TySig>(t)) {
        auto&& m338787_3_0 = prism_rtl::as<check_types::Ty::TySig>(t).a0;
        if (m338787_3_0 == Text::lit("$")) {
            return false;
        }
    }
    if (prism_rtl::is<check_types::Ty::TySig>(t)) {
        auto&& i = prism_rtl::as<check_types::Ty::TySig>(t).a1;
        return ty_podable(lx, i, seen);
    }
    if (prism_rtl::is<check_types::Ty::TyTuple>(t)) {
        auto&& ts = prism_rtl::as<check_types::Ty::TyTuple>(t).a0;
        return run_to_end(fold_job(ts, true, ({
            auto lx_1 = lx;
            auto seen_2 = seen;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, check_types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, check_types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto lx_1_3 = lx_1;
                auto seen_2_3 = seen_2;
                entered(once_job([=]() {
                return ({
                    auto ok = p0;
                    auto x = p1;
                    (prism_rtl::finished(ok && ty_podable(lx_1_3, x, seen_2_3)));
                });
            }));
            });
        })));
        })));
    }
    if (prism_rtl::is<check_types::Ty::TyArray>(t)) {
        auto&& e = prism_rtl::as<check_types::Ty::TyArray>(t).a0;
        return ty_podable(lx, e, seen);
    }
    if (prism_rtl::is<check_types::Ty::TyMap>(t)) {
        auto&& k = prism_rtl::as<check_types::Ty::TyMap>(t).a0;
        auto&& v_ = prism_rtl::as<check_types::Ty::TyMap>(t).a1;
        return ty_podable(lx, k, seen) && ty_podable(lx, v_, seen);
    }
    if (prism_rtl::is<check_types::Ty::TyCon>(t)) {
        auto&& n = prism_rtl::as<check_types::Ty::TyCon>(t).a0;
        auto&& args = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
        return check_types::has_text(seen, n)
            ? true
            : ({
            auto more = prelude::push(seen, n);
            auto args_ok = run_to_end(fold_job(args, true, ({
                auto lx_1 = lx;
                auto more_2 = more;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, check_types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, check_types::Ty> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto lx_1_3 = lx_1;
                    auto more_2_3 = more_2;
                    entered(once_job([=]() {
                    return ({
                        auto ok = p0;
                        auto x = p1;
                        (prism_rtl::finished(ok && ty_podable(lx_1_3, x, more_2_3)));
                    });
                }));
                });
            })));
            })));
            args_ok && ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            auto&& _m = prelude::get(lx.g.types, n);
            if (prism_rtl::is_some(_m)) {
                auto&& ti = prism_rtl::some_of(_m);
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<bool> _v;
                    auto&& _m = ti.body;
                    if (prism_rtl::is<check_env::TyBody::BRecord>(_m)) {
                        auto&& fs = prism_rtl::as<check_env::TyBody::BRecord>(_m).a0;
                        _v.set(run_to_end(fold_job(fs, true, ({
                            auto lx_1 = lx;
                            auto more_2 = more;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, check_types::Ty>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<Text, check_types::Ty>> _p0) {
                            auto&& p0 = std::get<0>(_p0);
                            auto&& p1 = std::get<1>(_p0);
                            return ({
                                auto lx_1_3 = lx_1;
                                auto more_2_3 = more_2;
                                entered(once_job([=]() {
                                return ({
                                    auto ok = p0;
                                    auto&& _ft = p1;
                                    auto&& ft = std::get<1>(_ft);
                                    (prism_rtl::finished(ok && ty_podable(lx_1_3, ft, more_2_3)));
                                });
                            }));
                            });
                        })));
                        }))));
                        goto _done;
                    }
                    if (prism_rtl::is<check_env::TyBody::BChoice>(_m)) {
                        auto&& cs = prism_rtl::as<check_env::TyBody::BChoice>(_m).a0;
                        _v.set(run_to_end(fold_job(cs, true, ({
                            auto lx_1 = lx;
                            auto more_2 = more;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, Array<check_types::Ty>>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<Text, Array<check_types::Ty>>> _p0) {
                            auto&& p0 = std::get<0>(_p0);
                            auto&& p1 = std::get<1>(_p0);
                            return ({
                                auto lx_1_3 = lx_1;
                                auto more_2_3 = more_2;
                                entered(once_job([=]() {
                                return ({
                                    auto ok = p0;
                                    auto&& _ats = p1;
                                    auto&& ats = std::get<1>(_ats);
                                    (prism_rtl::finished(ok && run_to_end(fold_job(ats, true, ({
                                    auto lx_1_3_3 = lx_1_3;
                                    auto more_2_3_3 = more_2_3;
                                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, check_types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, check_types::Ty> _p0) {
                                    auto&& p0 = std::get<0>(_p0);
                                    auto&& p1 = std::get<1>(_p0);
                                    return ({
                                        auto lx_1_3_3_3 = lx_1_3_3;
                                        auto more_2_3_3_3 = more_2_3_3;
                                        entered(once_job([=]() {
                                        return ({
                                            auto ok2 = p0;
                                            auto x = p1;
                                            (prism_rtl::finished(ok2 && ty_podable(lx_1_3_3_3, x, more_2_3_3_3)));
                                        });
                                    }));
                                    });
                                })));
                                })))));
                                });
                            }));
                            });
                        })));
                        }))));
                        goto _done;
                    }
                    if (prism_rtl::is<check_env::TyBody::BAlias>(_m)) {
                        auto&& a = prism_rtl::as<check_env::TyBody::BAlias>(_m).a0;
                        _v.set(ty_podable(lx, a, more));
                        goto _done;
                    }
                    {
                        _v.set(true);
                        goto _done;
                    }
                _done:
                    _v.take();
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(true);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        });
    }
    {
        return true;
    }
}


prism_rtl::Turn<bool> TyPodable::cycle() const {
    const auto& lx = this->lx;
    const auto& t = this->t;
    const auto& seen = this->seen;
    return ({
        prism_rtl::is<check_types::Ty::TyFn>(t) ? prism_rtl::finished(false)
        : prism_rtl::is<check_types::Ty::TyAt>(t) ? prism_rtl::finished(false)
        : prism_rtl::is<check_types::Ty::TySig>(t) && ({
        auto&& m338787_2_0 = prism_rtl::as<check_types::Ty::TySig>(t).a0;
        (m338787_2_0 == Text::lit("!"));
    }) ? ({
        auto&& m338787_2_0 = prism_rtl::as<check_types::Ty::TySig>(t).a0;
        prism_rtl::finished(false);
    })
        : prism_rtl::is<check_types::Ty::TySig>(t) && ({
        auto&& m338787_3_0 = prism_rtl::as<check_types::Ty::TySig>(t).a0;
        (m338787_3_0 == Text::lit("$"));
    }) ? ({
        auto&& m338787_3_0 = prism_rtl::as<check_types::Ty::TySig>(t).a0;
        prism_rtl::finished(false);
    })
        : prism_rtl::is<check_types::Ty::TySig>(t) ? ({
        auto&& i = prism_rtl::as<check_types::Ty::TySig>(t).a1;
        prism_rtl::more(prism_rtl::rc(TyPodable(lx, i, seen)));
    })
        : prism_rtl::is<check_types::Ty::TyTuple>(t) ? ({
        auto&& ts = prism_rtl::as<check_types::Ty::TyTuple>(t).a0;
        fold_job(ts, true, ({
        auto lx_1 = lx;
        auto seen_2 = seen;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, check_types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, check_types::Ty> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_1_3 = lx_1;
            auto seen_2_3 = seen_2;
            entered(once_job([=]() {
            return ({
                auto ok = p0;
                auto x = p1;
                (prism_rtl::finished(ok && ty_podable(lx_1_3, x, seen_2_3)));
            });
        }));
        });
    })));
    }))->cycle();
    })
        : prism_rtl::is<check_types::Ty::TyArray>(t) ? ({
        auto&& e = prism_rtl::as<check_types::Ty::TyArray>(t).a0;
        prism_rtl::more(prism_rtl::rc(TyPodable(lx, e, seen)));
    })
        : prism_rtl::is<check_types::Ty::TyMap>(t) ? ({
        auto&& k = prism_rtl::as<check_types::Ty::TyMap>(t).a0;
        auto&& v_ = prism_rtl::as<check_types::Ty::TyMap>(t).a1;
        ({
        auto k_1 = k;
        auto lx_2 = lx;
        auto seen_3 = seen;
        auto v__4 = v_;
        call_then(start_ty_podable(lx_2, k_1, seen_3), [=](bool ty_podable_339090) { return prism_rtl::finished(ty_podable_339090 && ty_podable(lx_2, v__4, seen_3)); });
    });
    })
        : prism_rtl::is<check_types::Ty::TyCon>(t) ? ({
        auto&& n = prism_rtl::as<check_types::Ty::TyCon>(t).a0;
        auto&& args = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
        check_types::has_text(seen, n)
        ? prism_rtl::finished(true)
        : ({
        auto more = prelude::push(seen, n);
        auto args_1 = args;
        auto lx_2 = lx;
        auto n_3 = n;
        call_value(fold_job(args_1, true, ({
        auto lx_2_4 = lx_2;
        auto more_4 = more;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, check_types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, check_types::Ty> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_2_4_5 = lx_2_4;
            auto more_4_5 = more_4;
            entered(once_job([=]() {
            return ({
                auto ok = p0;
                auto x = p1;
                (prism_rtl::finished(ok && ty_podable(lx_2_4_5, x, more_4_5)));
            });
        }));
        });
    })));
    })), [=](bool fold_339266) {
        return ({
            auto args_ok = fold_339266;
            (prism_rtl::finished(args_ok && ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            auto&& _m = prelude::get(lx_2.g.types, n_3);
            if (prism_rtl::is_some(_m)) {
                auto&& ti = prism_rtl::some_of(_m);
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<bool> _v;
                    auto&& _m = ti.body;
                    if (prism_rtl::is<check_env::TyBody::BRecord>(_m)) {
                        auto&& fs = prism_rtl::as<check_env::TyBody::BRecord>(_m).a0;
                        _v.set(run_to_end(fold_job(fs, true, ({
                            auto lx_2_4 = lx_2;
                            auto more_4 = more;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, check_types::Ty>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<Text, check_types::Ty>> _p0) {
                            auto&& p0 = std::get<0>(_p0);
                            auto&& p1 = std::get<1>(_p0);
                            return ({
                                auto lx_2_4_5 = lx_2_4;
                                auto more_4_5 = more_4;
                                entered(once_job([=]() {
                                return ({
                                    auto ok = p0;
                                    auto&& _ft = p1;
                                    auto&& ft = std::get<1>(_ft);
                                    (prism_rtl::finished(ok && ty_podable(lx_2_4_5, ft, more_4_5)));
                                });
                            }));
                            });
                        })));
                        }))));
                        goto _done;
                    }
                    if (prism_rtl::is<check_env::TyBody::BChoice>(_m)) {
                        auto&& cs = prism_rtl::as<check_env::TyBody::BChoice>(_m).a0;
                        _v.set(run_to_end(fold_job(cs, true, ({
                            auto lx_2_4 = lx_2;
                            auto more_4 = more;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, Array<check_types::Ty>>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<Text, Array<check_types::Ty>>> _p0) {
                            auto&& p0 = std::get<0>(_p0);
                            auto&& p1 = std::get<1>(_p0);
                            return ({
                                auto lx_2_4_5 = lx_2_4;
                                auto more_4_5 = more_4;
                                entered(once_job([=]() {
                                return ({
                                    auto ok = p0;
                                    auto&& _ats = p1;
                                    auto&& ats = std::get<1>(_ats);
                                    (prism_rtl::finished(ok && run_to_end(fold_job(ats, true, ({
                                    auto lx_2_4_5_5 = lx_2_4_5;
                                    auto more_4_5_5 = more_4_5;
                                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, check_types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, check_types::Ty> _p0) {
                                    auto&& p0 = std::get<0>(_p0);
                                    auto&& p1 = std::get<1>(_p0);
                                    return ({
                                        auto lx_2_4_5_5_5 = lx_2_4_5_5;
                                        auto more_4_5_5_5 = more_4_5_5;
                                        entered(once_job([=]() {
                                        return ({
                                            auto ok2 = p0;
                                            auto x = p1;
                                            (prism_rtl::finished(ok2 && ty_podable(lx_2_4_5_5_5, x, more_4_5_5_5)));
                                        });
                                    }));
                                    });
                                })));
                                })))));
                                });
                            }));
                            });
                        })));
                        }))));
                        goto _done;
                    }
                    if (prism_rtl::is<check_env::TyBody::BAlias>(_m)) {
                        auto&& a = prism_rtl::as<check_env::TyBody::BAlias>(_m).a0;
                        _v.set(ty_podable(lx_2, a, more));
                        goto _done;
                    }
                    {
                        _v.set(true);
                        goto _done;
                    }
                _done:
                    _v.take();
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(true);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        })));
        });
    });
    });
    })
        : prism_rtl::finished(true);
    });
}


/// `Start TyPodable, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_ty_podable(Lx lx, check_types::Ty t, Array<Text> seen) {
    return prism_rtl::make_rc<TyPodable>(lx, t, seen);
}


/// TyHasEq: unbounded fn Lx, Ty, [Text] -> Bool
bool ty_has_eq(const Lx& lx, const check_types::Ty& t, const Array<Text>& seen) {
    if (prism_rtl::is<check_types::Ty::TyFn>(t)) {
        return false;
    }
    if (prism_rtl::is<check_types::Ty::TyAt>(t)) {
        return false;
    }
    if (prism_rtl::is<check_types::Ty::TySig>(t)) {
        auto&& m340220_2_0 = prism_rtl::as<check_types::Ty::TySig>(t).a0;
        if (m340220_2_0 == Text::lit("!")) {
            return false;
        }
    }
    if (prism_rtl::is<check_types::Ty::TySig>(t)) {
        auto&& m340220_3_0 = prism_rtl::as<check_types::Ty::TySig>(t).a0;
        if (m340220_3_0 == Text::lit("$")) {
            return false;
        }
    }
    if (prism_rtl::is<check_types::Ty::TySig>(t)) {
        auto&& i = prism_rtl::as<check_types::Ty::TySig>(t).a1;
        return ty_has_eq(lx, i, seen);
    }
    if (prism_rtl::is<check_types::Ty::TyTuple>(t)) {
        auto&& ts = prism_rtl::as<check_types::Ty::TyTuple>(t).a0;
        return run_to_end(fold_job(ts, true, ({
            auto lx_1 = lx;
            auto seen_2 = seen;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, check_types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, check_types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto lx_1_3 = lx_1;
                auto seen_2_3 = seen_2;
                entered(once_job([=]() {
                return ({
                    auto ok = p0;
                    auto x = p1;
                    (prism_rtl::finished(ok && ty_has_eq(lx_1_3, x, seen_2_3)));
                });
            }));
            });
        })));
        })));
    }
    if (prism_rtl::is<check_types::Ty::TyArray>(t)) {
        auto&& e = prism_rtl::as<check_types::Ty::TyArray>(t).a0;
        return ty_has_eq(lx, e, seen);
    }
    if (prism_rtl::is<check_types::Ty::TyMap>(t)) {
        auto&& k = prism_rtl::as<check_types::Ty::TyMap>(t).a0;
        auto&& v_ = prism_rtl::as<check_types::Ty::TyMap>(t).a1;
        return ty_has_eq(lx, k, seen) && ty_has_eq(lx, v_, seen);
    }
    if (prism_rtl::is<check_types::Ty::TyElem>(t)) {
        return true;
    }
    if (prism_rtl::is<check_types::Ty::TyElemAny>(t)) {
        return true;
    }
    if (prism_rtl::is<check_types::Ty::TyCon>(t)) {
        auto&& n = prism_rtl::as<check_types::Ty::TyCon>(t).a0;
        auto&& args = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
        return check_types::has_text(seen, n)
            ? true
            : ({
            auto args_ok = run_to_end(fold_job(args, true, ({
                auto lx_1 = lx;
                auto seen_2 = seen;
                auto n_3 = n;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, check_types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, check_types::Ty> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto lx_1_4 = lx_1;
                    auto seen_2_4 = seen_2;
                    auto n_3_4 = n_3;
                    entered(once_job([=]() {
                    return ({
                        auto ok = p0;
                        auto x = p1;
                        (prism_rtl::finished(ok && ty_has_eq(lx_1_4, x, prelude::push(seen_2_4, n_3_4))));
                    });
                }));
                });
            })));
            })));
            args_ok && ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            auto&& _m = prelude::get(lx.g.types, n);
            if (prism_rtl::is_some(_m)) {
                auto&& ti = prism_rtl::some_of(_m);
                _v.set(fold(ti.derives, false, [&](const bool& f, const Text& d) { return f || (check_types::bare_name(d) == Text::lit("Eq")); }) || has_own_eq(lx, n));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(true);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        });
    }
    {
        return false;
    }
}


/// HasOwnEq: fn Lx, Text -> Bool
bool has_own_eq(const Lx& lx, const Text& tn) {
    return fold(or_(prelude::get(lx.g.impls, Text::lit("Prelude.Eq")), Array<check_env::ImplInfo>{}), false, [&](const bool& f, const check_env::ImplInfo& im) { return f || (head_name(im.head) == tn); });
}


/// CaseField: unbounded fn Lx, Text, Nat, Ty -> OutTy
OutTy case_field(const Lx& lx, const Text& ck, const Nat& i, const check_types::Ty& t) {
    auto rt = out_ty_of(lx, t);
    return rc_field(lx, ck, i) ? OutTy(OutTy::OutRc{prism_rtl::rc(rt)}) : rt;
}


prism_rtl::Turn<OutTy> CaseField::cycle() const {
    const auto& lx = this->lx;
    const auto& ck = this->ck;
    const auto& i = this->i;
    const auto& t = this->t;
    auto ck_1 = ck;
    auto i_2 = i;
    auto lx_3 = lx;
    auto t_4 = t;
    return call_then(start_out_ty_of(lx_3, t_4), [=](OutTy out_ty_of_341198) {
        return ({
            auto rt = out_ty_of_341198;
            rc_field(lx_3, ck_1, i_2)
            ? prism_rtl::finished(OutTy(OutTy::OutRc{prism_rtl::rc(rt)}))
            : prism_rtl::finished(rt);
        });
    });
}


/// `Start CaseField, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<OutTy> start_case_field(Lx lx, Text ck, Nat i, check_types::Ty t) {
    return prism_rtl::make_rc<CaseField>(lx, ck, i, t);
}


/// TypeDoc: fn Lx, TyInfo -> Text
Text type_doc(const Lx& lx, const check_env::TyInfo& ti) {
    auto&& _m = index(lx.g.srcs, ti->file);
    if (prism_rtl::is_some(_m)) {
        auto&& src = prism_rtl::some_of(_m);
        return lexer::trim(check_errors::line_text(src, check_errors::cline_of(src.starts, ti.span.start)));
    }
    if (prism_rtl::is_none(_m)) {
        return ti.name;
    }
    prism_rtl::unreachable("no arm matched");
}


/// TagDefOf: unbounded fn Lx, TagInfo -> TagDef
TagDef tag_def_of(const Lx& lx, const check_env::TagInfo& tg) {
    auto fields = run_to_end(each_job(level_fields(tg), ({
        auto lx_1 = lx;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, Text, OutTy>>(std::tuple<Text, check_types::Ty>)>>(prism_rtl::rc([=](std::tuple<Text, check_types::Ty> p0) {
        return ({
            auto lx_1_2 = lx_1;
            entered(once_job([=]() {
            return ({
                auto [fname, ft] = p0;
                call_then(start_out_ty_of(lx_1_2, peel(ft)), [=](OutTy out_ty_of_341708) { return prism_rtl::finished(std::tuple{fname, snake(fname), out_ty_of_341708}); });
            });
        }));
        });
    }));
    })));
    return TagDef{.name = tag_struct(tg.name), .tag_name = tg.name, .fields = fields, .doc = type_doc(lx, check_env::TyInfo{.name = tg.name, .home = tg.home, .params = Array<Text>{}, .body = check_env::TyBody(check_env::TyBody::BOpaque{}), .derives = Array<Text>{}, .file = tg->file, .span = tg.span}), .pod = run_to_end(fold_job(fields, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, Text, OutTy>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<Text, Text, OutTy>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto ok = p0;
                auto&& _t = p1;
                auto&& t = std::get<2>(_t);
                (prism_rtl::finished(ok && podable(t)));
            });
        }));
    }))))};
}


prism_rtl::Turn<TagDef> TagDefOf::cycle() const {
    const auto& lx = this->lx;
    const auto& tg = this->tg;
    auto lx_1 = lx;
    auto tg_2 = tg;
    return call_value(each_job(level_fields(tg_2), ({
        auto lx_1_3 = lx_1;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, Text, OutTy>>(std::tuple<Text, check_types::Ty>)>>(prism_rtl::rc([=](std::tuple<Text, check_types::Ty> p0) {
        return ({
            auto lx_1_3_3 = lx_1_3;
            entered(once_job([=]() {
            return ({
                auto [fname, ft] = p0;
                call_then(start_out_ty_of(lx_1_3_3, peel(ft)), [=](OutTy out_ty_of_341708) { return prism_rtl::finished(std::tuple{fname, snake(fname), out_ty_of_341708}); });
            });
        }));
        });
    }));
    })), [=](Array<std::tuple<Text, Text, OutTy>> each_341643) {
        return ({
            auto fields = each_341643;
            call_value(fold_job(fields, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, Text, OutTy>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<Text, Text, OutTy>> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto ok = p0;
                    auto&& _t = p1;
                    auto&& t = std::get<2>(_t);
                    (prism_rtl::finished(ok && podable(t)));
                });
            }));
        }))), [=](bool fold_341932) { return prism_rtl::finished(TagDef{.name = tag_struct(tg_2.name), .tag_name = tg_2.name, .fields = fields, .doc = type_doc(lx_1, check_env::TyInfo{.name = tg_2.name, .home = tg_2.home, .params = Array<Text>{}, .body = check_env::TyBody(check_env::TyBody::BOpaque{}), .derives = Array<Text>{}, .file = tg_2->file, .span = tg_2.span}), .pod = fold_341932}); });
        });
    });
}


/// `Start TagDefOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<TagDef> start_tag_def_of(Lx lx, check_env::TagInfo tg) {
    return prism_rtl::make_rc<TagDefOf>(lx, tg);
}


/// LevelFields: fn TagInfo -> [((Text, Ty))]
Array<std::tuple<Text, check_types::Ty>> level_fields(const check_env::TagInfo& tg) {
    return filter(tg.fields, [&](const std::tuple<Text, check_types::Ty>& _p0) {
        auto&& ft = std::get<1>(_p0);
        return layer_of(ft) != Layer(Layer::LyEv{});
    });
}


/// KindTags: fn Lx, Text, [Text] -> [TagInfo]
Array<check_env::TagInfo> kind_tags(const Lx& lx, const Text& kind, const Array<Text>& mods) {
    return filter(values(lx.g.tags), [&](const check_env::TagInfo& tg) { return (tg.kind == kind) && check_types::has_text(mods, tg.home); });
}


/// RowDefOf: unbounded fn Lx, TyInfo -> RowDef
RowDef row_def_of(const Lx& lx, const check_env::TyInfo& ti) {
    auto tags = kind_tags(lx, ti.name, keys(lx.rs_mods));
    auto cases = each(tags, [&](const check_env::TagInfo& tg) { return std::tuple{tag_struct(tg.name), path_in(lx, tg.home, tag_struct(tg.name))}; });
    auto pod = run_to_end(fold_job(tags, true, ({
        auto lx_1 = lx;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, check_env::TagInfo>)>>(prism_rtl::rc([=](std::tuple<bool, check_env::TagInfo> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_1_2 = lx_1;
            entered(once_job([=]() {
            return ({
                auto ok = p0;
                auto tg = p1;
                (prism_rtl::finished(ok && tag_def_of(lx_1_2, tg).pod));
            });
        }));
        });
    })));
    })));
    return RowDef{.name = camel(check_types::bare_name(ti.name)), .prism = ti.name, .cases_ = cases, .pod = pod, .doc = type_doc(lx, ti)};
}


prism_rtl::Turn<RowDef> RowDefOf::cycle() const {
    const auto& lx = this->lx;
    const auto& ti = this->ti;
    auto tags = kind_tags(lx, ti.name, keys(lx.rs_mods));
    auto cases = each(tags, [&](const check_env::TagInfo& tg) { return std::tuple{tag_struct(tg.name), path_in(lx, tg.home, tag_struct(tg.name))}; });
    auto lx_1 = lx;
    auto ti_2 = ti;
    return call_value(fold_job(tags, true, ({
        auto lx_1_3 = lx_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, check_env::TagInfo>)>>(prism_rtl::rc([=](std::tuple<bool, check_env::TagInfo> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_1_3_3 = lx_1_3;
            entered(once_job([=]() {
            return ({
                auto ok = p0;
                auto tg = p1;
                (prism_rtl::finished(ok && tag_def_of(lx_1_3_3, tg).pod));
            });
        }));
        });
    })));
    })), [=](bool fold_342646) {
        return ({
            auto pod = fold_342646;
            (prism_rtl::finished(RowDef{.name = camel(check_types::bare_name(ti_2.name)), .prism = ti_2.name, .cases_ = cases, .pod = pod, .doc = type_doc(lx_1, ti_2)}));
        });
    });
}


/// `Start RowDefOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<RowDef> start_row_def_of(Lx lx, check_env::TyInfo ti) {
    return prism_rtl::make_rc<RowDefOf>(lx, ti);
}


/// ElemRow: unbounded fn Lx, [Text] -> RowDef
RowDef elem_row(const Lx& lx, const Array<Text>& mods) {
    auto tags = kind_tags(lx, Text::lit("Element"), prelude::push(mods, Text::lit("Prelude")));
    auto cases = each(tags, [&](const check_env::TagInfo& tg) { return std::tuple{tag_struct(tg.name), prism_rtl::cat(rust_mod_name(tg.home), "::", tag_struct(tg.name))}; });
    auto pod = run_to_end(fold_job(tags, true, ({
        auto lx_1 = lx;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, check_env::TagInfo>)>>(prism_rtl::rc([=](std::tuple<bool, check_env::TagInfo> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_1_2 = lx_1;
            entered(once_job([=]() {
            return ({
                auto ok = p0;
                auto tg = p1;
                (prism_rtl::finished(ok && tag_def_of(lx_1_2, tg).pod));
            });
        }));
        });
    })));
    })));
    return RowDef{.name = Text::lit("Elem"), .prism = Text::lit("Elem"), .cases_ = cases, .pod = pod, .doc = Text::lit("`Elem r`: an element as a document holds it, its `Level` in a tick.")};
}


prism_rtl::Turn<RowDef> ElemRow::cycle() const {
    const auto& lx = this->lx;
    const auto& mods = this->mods;
    auto tags = kind_tags(lx, Text::lit("Element"), prelude::push(mods, Text::lit("Prelude")));
    auto cases = each(tags, [&](const check_env::TagInfo& tg) { return std::tuple{tag_struct(tg.name), prism_rtl::cat(rust_mod_name(tg.home), "::", tag_struct(tg.name))}; });
    auto lx_1 = lx;
    return call_value(fold_job(tags, true, ({
        auto lx_1_2 = lx_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, check_env::TagInfo>)>>(prism_rtl::rc([=](std::tuple<bool, check_env::TagInfo> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_1_2_2 = lx_1_2;
            entered(once_job([=]() {
            return ({
                auto ok = p0;
                auto tg = p1;
                (prism_rtl::finished(ok && tag_def_of(lx_1_2_2, tg).pod));
            });
        }));
        });
    })));
    })), [=](bool fold_343248) {
        return ({
            auto pod = fold_343248;
            (prism_rtl::finished(RowDef{.name = Text::lit("Elem"), .prism = Text::lit("Elem"), .cases_ = cases, .pod = pod, .doc = Text::lit("`Elem r`: an element as a document holds it, its `Level` in a tick.")}));
        });
    });
}


/// `Start ElemRow, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<RowDef> start_elem_row(Lx lx, Array<Text> mods) {
    return prism_rtl::make_rc<ElemRow>(lx, mods);
}


/// AnswerEnum: unbounded fn Lx, [Text] -> AnswerDef
AnswerDef answer_enum(const Lx& lx, const Array<Text>& mods) {
    auto tags = kind_tags(lx, Text::lit("Element"), prelude::push(mods, Text::lit("Prelude")));
    return AnswerDef{.cases_ = run_to_end(each_job(tags, ({
        auto lx_1 = lx;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<AnswerCase>(check_env::TagInfo)>>(prism_rtl::rc([=](check_env::TagInfo p0) {
        return ({
            auto lx_1_2 = lx_1;
            entered(once_job([=]() {
            return ({
                auto tg = p0;
                call_then(start_answer_ty(lx_1_2, tg), [=](OutTy answer_ty_343839) { return prism_rtl::finished(AnswerCase{.variant = tag_struct(tg.name), .accessor = answer_accessor(tg), .struct_path = prism_rtl::cat(rust_mod_name(tg.home), "::", tag_struct(tg.name)), .tag_name = tg.name, .ty = answer_ty_343839}); });
            });
        }));
        });
    })));
    })))};
}


prism_rtl::Turn<AnswerDef> AnswerEnum::cycle() const {
    const auto& lx = this->lx;
    const auto& mods = this->mods;
    auto tags = kind_tags(lx, Text::lit("Element"), prelude::push(mods, Text::lit("Prelude")));
    auto lx_1 = lx;
    return call_value(each_job(tags, ({
        auto lx_1_2 = lx_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<AnswerCase>(check_env::TagInfo)>>(prism_rtl::rc([=](check_env::TagInfo p0) {
        return ({
            auto lx_1_2_2 = lx_1_2;
            entered(once_job([=]() {
            return ({
                auto tg = p0;
                call_then(start_answer_ty(lx_1_2_2, tg), [=](OutTy answer_ty_343839) { return prism_rtl::finished(AnswerCase{.variant = tag_struct(tg.name), .accessor = answer_accessor(tg), .struct_path = prism_rtl::cat(rust_mod_name(tg.home), "::", tag_struct(tg.name)), .tag_name = tg.name, .ty = answer_ty_343839}); });
            });
        }));
        });
    })));
    })), [=](Array<AnswerCase> each_343674) { return prism_rtl::finished(AnswerDef{.cases_ = each_343674}); });
}


/// `Start AnswerEnum, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<AnswerDef> start_answer_enum(Lx lx, Array<Text> mods) {
    return prism_rtl::make_rc<AnswerEnum>(lx, mods);
}


/// AnswerTy: unbounded fn Lx, TagInfo -> OutTy
OutTy answer_ty(const Lx& lx, const check_env::TagInfo& tg) {
    auto out = peel(tg->out);
    auto part = ({
        __label__ _done;
        prism_rtl::Slot<check_types::Ty> _v;
        if (prism_rtl::is<check_types::Ty::TyTuple>(out)) {
            auto&& cs = prism_rtl::as<check_types::Ty::TyTuple>(out).a0;
            _v.set(fold(cs, out, [&](const check_types::Ty& found, const check_types::Ty& c) { return layer_of(c) == Layer(Layer::LyEv{}) ? peel(c) : found; }));
            goto _done;
        }
        {
            _v.set(out);
            goto _done;
        }
    _done:
        _v.take();
    });
    auto&& _m = out_ty_of(lx, part);
    if (prism_rtl::is<OutTy::OutGen>(_m)) {
        return OutTy(OutTy::OutPod{});
    }
    {
        auto&& t = _m;
        return t;
    }
}


prism_rtl::Turn<OutTy> AnswerTy::cycle() const {
    const auto& lx = this->lx;
    const auto& tg = this->tg;
    auto out = peel(tg->out);
    auto part = ({
        __label__ _done;
        prism_rtl::Slot<check_types::Ty> _v;
        if (prism_rtl::is<check_types::Ty::TyTuple>(out)) {
            auto&& cs = prism_rtl::as<check_types::Ty::TyTuple>(out).a0;
            _v.set(fold(cs, out, [&](const check_types::Ty& found, const check_types::Ty& c) { return layer_of(c) == Layer(Layer::LyEv{}) ? peel(c) : found; }));
            goto _done;
        }
        {
            _v.set(out);
            goto _done;
        }
    _done:
        _v.take();
    });
    auto lx_1 = lx;
    return call_then(start_out_ty_of(lx_1, part), [=](OutTy out_ty_of_344366) {
        return ({
            prism_rtl::is<OutTy::OutGen>(out_ty_of_344366) ? prism_rtl::finished(OutTy(OutTy::OutPod{}))
            : ({
            auto&& t = out_ty_of_344366;
            prism_rtl::finished(t);
        });
        });
    });
}


/// `Start AnswerTy, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<OutTy> start_answer_ty(Lx lx, check_env::TagInfo tg) {
    return prism_rtl::make_rc<AnswerTy>(lx, tg);
}


/// TagPaths: fn Lx, TagInfo -> ((Text, Text))
std::tuple<Text, Text> tag_paths(const Lx& lx, const check_env::TagInfo& tg) {
    auto st = tag_struct(tg.name);
    auto struct_path = path_in(lx, tg.home, st);
    return std::tuple{prism_rtl::cat(kind_path(lx, tg.kind), "::", st), struct_path};
}


/// VariantOf: fn Lx, TagInfo -> Text
Text variant_of(const Lx& lx, const check_env::TagInfo& tg) {
    return prism_rtl::cat(kind_path(lx, tg.kind), "::", tag_struct(tg.name));
}


/// KindPath: fn Lx, Text -> Text
Text kind_path(const Lx& lx, const Text& kind) {
    return kind == Text::lit("Element")
        ? Text::lit("crate::Elem")
        : path_in(lx, or_(prelude::get(lx.g.types, kind), check_env::dummy_ty_info()).home, camel(check_types::bare_name(kind)));
}


/// CheckDefOf: unbounded fn Lx, CheckDecl -> CheckDef
CheckDef check_def_of(const Lx& lx, const ast::CheckDecl& c) {
    return CheckDef{.name = c.name.name, .lines = run_to_end(each_job(c.lines, ({
        auto lx_1 = lx;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(ast::CheckLine)>>(prism_rtl::rc([=](ast::CheckLine p0) {
        return ({
            auto lx_1_2 = lx_1;
            entered(once_job([=]() {
            return ({
                auto l = p0;
                call_then(start_value_of(lx_1_2, empty_env(), l.expr), [=](Vl value_of_345214) { return prism_rtl::finished(Ex(Ex::XCtor{Text::lit("Ok"), Array(std::vector{Ex(Ex::XMethod{prism_rtl::rc(own(value_of_345214)), Text::lit("to_pod"), Array<Ex>{}})})})); });
            });
        }));
        });
    })));
    })))};
}


prism_rtl::Turn<CheckDef> CheckDefOf::cycle() const {
    const auto& lx = this->lx;
    const auto& c = this->c;
    auto c_1 = c;
    auto lx_2 = lx;
    return call_value(each_job(c_1.lines, ({
        auto lx_2_3 = lx_2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(ast::CheckLine)>>(prism_rtl::rc([=](ast::CheckLine p0) {
        return ({
            auto lx_2_3_3 = lx_2_3;
            entered(once_job([=]() {
            return ({
                auto l = p0;
                call_then(start_value_of(lx_2_3_3, empty_env(), l.expr), [=](Vl value_of_345214) { return prism_rtl::finished(Ex(Ex::XCtor{Text::lit("Ok"), Array(std::vector{Ex(Ex::XMethod{prism_rtl::rc(own(value_of_345214)), Text::lit("to_pod"), Array<Ex>{}})})})); });
            });
        }));
        });
    })));
    })), [=](Array<Ex> each_345166) { return prism_rtl::finished(CheckDef{.name = c_1.name.name, .lines = each_345166}); });
}


/// `Start CheckDefOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<CheckDef> start_check_def_of(Lx lx, ast::CheckDecl c) {
    return prism_rtl::make_rc<CheckDefOf>(lx, c);
}


/// ForLine: unbounded fn Wx, Env, Env, ?ForBinders, Expr, Block, Expr, ?Bn -> ((Wx, Wres))
std::tuple<Wx, Wres> for_line(const Wx& wx, const Env& benv, const Env& menv, const std::optional<ast::ForBinders>& binders_opt, const ast::Expr& source, const ast::Block& body, const ast::Expr& e, const std::optional<Bn>& bound_opt) {
    auto lx = wx.lx;
    auto pos = wx.pos;
    auto wx1 = ({
        Wx this_ = wx;
        this_.pos = next_pos(this_.pos);
        this_;
    });
    auto [src_ex, reads] = dynamic_expr(wx1, menv, source);
    auto src_ty = peel(type_at(lx, source.span));
    auto [kt, vt, keyed] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<OutTy, OutTy, bool>> _v;
        if (prism_rtl::is<check_types::Ty::TyMap>(src_ty)) {
            auto&& k = prism_rtl::as<check_types::Ty::TyMap>(src_ty).a0;
            auto&& v_ = prism_rtl::as<check_types::Ty::TyMap>(src_ty).a1;
            _v.set(std::tuple{out_ty_of(lx, k), out_ty_of(lx, v_), true});
            goto _done;
        }
        if (prism_rtl::is<check_types::Ty::TyArray>(src_ty)) {
            auto&& v_ = prism_rtl::as<check_types::Ty::TyArray>(src_ty).a0;
            _v.set(std::tuple{OutTy(OutTy::OutNat{}), out_ty_of(lx, v_), false});
            goto _done;
        }
        {
            _v.set(std::tuple{OutTy(OutTy::OutUnit{}), OutTy(OutTy::OutUnit{}), true});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto src = keyed
        ? src_ex
        : Ex(Ex::XCall{Text::lit("indexed"), Array(std::vector{Ex(Ex::XRef{prism_rtl::rc(src_ex)})})});
    auto base_ = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        if (prism_rtl::is_some(bound_opt) && prism_rtl::is<Bn::BnEv>(prism_rtl::some_of(bound_opt))) {
            auto&& er = prism_rtl::as<Bn::BnEv>(prism_rtl::some_of(bound_opt)).a0;
            _v.set(gn_of(wx1, er.node_).name);
            goto _done;
        }
        {
            _v.set(Text::lit("rows"));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto [name, wx2a] = fresh_name(wx1, base_);
    auto src_getter = prism_rtl::cat(name, "_source");
    auto src_cached = Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(src_getter, "_cache")})), Text::lit("get"), Array(std::vector{Ex(Ex::XCx{}), Ex(Ex::XClosure{false, Array<Pa>{}, prism_rtl::rc(src)})})});
    auto src_def = MethDef{.name = src_getter, .recv = Recv(Recv::RecvRef{}), .params = Array<std::tuple<Text, OutTy>>{}, .cx_ = CxArg(CxArg::CxRef{}), .ret = OutTy(OutTy::OutMap{prism_rtl::rc(kt), prism_rtl::rc(vt)}), .body = Array<Do>{}, .tail = src_cached, .doc = prism_rtl::cat("The source of the `for` at place ", place_text(pos), " by key, at the read point: what its builder and its rows' entries read, computed once per write behind it.")};
    auto row_name = prism_rtl::cat(wx.node_, row_suffix(wx), "Row");
    auto locals = row_locals(benv, menv, body);
    auto row_fields = append(Array(std::vector{std::tuple{Text::lit("key"), kt, Text::lit("the row's key")}, std::tuple{Text::lit("left_entry"), OutTy(OutTy::OutCell{prism_rtl::rc(OutTy(OutTy::OutOpt{prism_rtl::rc(vt)}))}), Text::lit("the entry as the tick its key left opened, kept from the row's leaving on (R8)")}, std::tuple{Text::lit("parent"), OutTy(OutTy::OutWeak{wx.node_}), Text::lit("the node of the `for`")}}), each(locals, [&](const RowLocal& l) { return std::tuple{l.field, l.ty, prism_rtl::cat("`", l.name, "`, the block's")}; }));
    auto row_moves = append(Array(std::vector{std::tuple{Text::lit("key"), Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{Text::lit("key")}))})}, std::tuple{Text::lit("left_entry"), Ex(Ex::XCall{Text::lit("RefCell::new"), Array(std::vector{Ex(Ex::XNone{})})})}, std::tuple{Text::lit("parent"), Ex(Ex::XVar{Text::lit("parent")})}}), each(locals, [&](const RowLocal& l) { return std::tuple{l.field, Ex(Ex::XVar{l.field})}; }));
    auto row_taken = append(append(node_hooks(), Array(std::vector{Text::lit("key"), Text::lit("value"), Text::lit("parent"), Text::lit("entry"), Text::lit("left_entry")})), each(locals, [&](const RowLocal& l) { return l.field; }));
    auto row_wx0 = new_wx(lx, row_name, row_fields, Array<std::tuple<Text, Ex>>{}, row_moves, Array(std::vector{entry_getter(src_getter, vt)}), map_of(std::vector{std::tuple{Text::lit("entry"), Array(std::vector{Read(Read::ParentRead{src_getter})})}}), row_taken, wx.depth, hosted_rows(wx));
    auto [wx2p, row_wx0p, ports] = row_env(wx2a, row_wx0, menv, body);
    auto wx2 = ({
        Wx this_ = add_field(wx2p, prism_rtl::cat(src_getter, "_cache"), OutTy(OutTy::OutNamed{Text::lit("Cache"), Array(std::vector{OutTy(OutTy::OutMap{prism_rtl::rc(kt), prism_rtl::rc(vt)})})}), prism_rtl::cat("the source of the `for` at place ", place_text(pos), ", cached (gap SR)"), Ex(Ex::XCall{Text::lit("Cache::new"), Array<Ex>{}}));
        this_.taken = append(this_.taken, Array(std::vector{src_getter, prism_rtl::cat(src_getter, "_cache")}));
        this_.getters = prelude::push(this_.getters, src_def);
        this_.dyn_reads = insert(this_.dyn_reads, src_getter, reads);
        this_;
    });
    auto key_b = Bn(Bn::BnLocal{Ex(Ex::XVar{Text::lit("key")}), Holding(Holding::Owned{}), kt});
    auto key_m = Bn(Bn::BnLocal{Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), Text::lit("key")}), Holding(Holding::Owned{}), kt});
    auto benv_l = events_of(ports, fold(locals, row_reads(benv, parent_arg()), [&](const Env& en, const RowLocal& l) { return bind(en, l.name, Bn(Bn::BnLocal{Ex(Ex::XVar{l.field}), Holding(Holding::Owned{}), l.ty})); }));
    auto menv_l = events_of(ports, fold(locals, row_reads(menv, parent_ref()), [&](const Env& en, const RowLocal& l) { return bind(en, l.name, Bn(Bn::BnLocal{Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), l.field}), Holding(Holding::Owned{}), l.ty})); }));
    auto passed = append(hosted_passed(wx), each(locals, [&](const RowLocal& l) { return l.passed; }));
    auto row_params = append(append(Array(std::vector{std::tuple{Text::lit("key"), kt}, std::tuple{Text::lit("value"), vt}, std::tuple{Text::lit("parent"), OutTy(OutTy::OutWeak{wx.node_})}}), hosted_params(wx)), each(locals, [&](const RowLocal& l) { return std::tuple{l.field, l.ty}; }));
    auto entry_m = Bn(Bn::BnDyn{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XSelf{})), Text::lit("entry"), Array(std::vector{Ex(Ex::XCx{})})}), Array(std::vector{Read(Read::ParentRead{src_getter})}), vt});
    auto [rbe, rme] = for_envs(benv_l, menv_l, binders_opt, key_b, key_m, Bn(Bn::BnLocal{Ex(Ex::XVar{Text::lit("value")}), Holding(Holding::Owned{}), vt}), entry_m, vt);
    auto row_wx = block_into(row_wx0p, rbe, rme, body);
    auto wx3 = ({
        Wx this_ = wx2;
        this_.row_marks = prelude::push(this_.row_marks, RowMarks{.builder = name, .reads = row_place_reads(row_wx), .wrote = row_hears(row_wx), .kind = RowKind(RowKind::ForRow{})});
        this_;
    });
    auto full = type_at(lx, e.span);
    auto out_ty = out_ty_of(lx, peel(full));
    auto&& _m = row_wx->result;
    if (prism_rtl::is<Wres::WrEv>(_m)) {
        auto&& r = prism_rtl::as<Wres::WrEv>(_m).a0;
        auto [gid, wx4] = add_gn(wx3, prism_rtl::cat(name, "_all"), out_ty, GnKind(GnKind::GnGather{}), Nat(1u));
        auto wx5 = add_field_last(wx4, prism_rtl::cat(name, "_gathered"), OutTy(OutTy::OutStamped{prism_rtl::rc(out_ty)}), Text::lit("the rows' firings this tick, by key"), Ex(Ex::XCall{Text::lit("Stamped::new"), Array<Ex>{}}));
        auto wx6 = ({
            Wx this_ = wx5;
            this_.gns = each(this_.gns, [&](const Gn& n) {
                return n.id == gid
                    ? with_inputs(n, Array(std::vector{prism_rtl::cat(name, "_gathered")}))
                    : n;
            });
            this_;
        });
        auto row_done = connect(row_wx, r, Sk(Sk::SkUp{prism_rtl::cat(name, "_all_in")}));
        auto wx7 = add_builder(wx6, name, pos, kt, vt, row_name, keyed, reads, PendingRow{.wx = row_done, .qk = row_name, .params = row_params, .gather = std::optional(gid)}, passed);
        return std::tuple{wx7, Wres(Wres::WrEv{ev_ref_of(wx7, gid)})};
    }
    if (prism_rtl::is<Wres::WrDyn>(_m)) {
        auto&& ex = prism_rtl::as<Wres::WrDyn>(_m).a0;
        auto&& result_reads = prism_rtl::as<Wres::WrDyn>(_m).a1;
        auto&& rt = prism_rtl::as<Wres::WrDyn>(_m).a2;
        auto gathered = prism_rtl::cat(name, "_all");
        auto gathered_ty = OutTy(OutTy::OutMap{prism_rtl::rc(kt), prism_rtl::rc(rt)});
        auto own_behind = filter(reads_closed(row_wx.dyn_reads, result_reads), [&](const Read& r) {
            return ({
                __label__ _done;
                prism_rtl::Slot<bool> _v;
                if (prism_rtl::is<Read::OwnRead>(r)) {
                    _v.set(true);
                    goto _done;
                }
                if (prism_rtl::is<Read::ParentRead>(r)) {
                    _v.set(false);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
        });
        auto row_done = ({
            Wx this_ = row_wx;
            this_.getters = prelude::push(this_.getters, MethDef{.name = Text::lit("result"), .recv = Recv(Recv::RecvRef{}), .params = Array<std::tuple<Text, OutTy>>{}, .cx_ = CxArg(CxArg::CxRef{}), .ret = rt, .body = Array<Do>{}, .tail = ex, .doc = Text::lit("The row's result, which the block gathers by key.")});
            this_.result_moved = len(own_behind) > Nat(0u)
                ? std::optional(std::tuple{prism_rtl::cat(gathered, "_moved"), own_behind})
                : std::optional<std::tuple<Text, Array<Read>>>{};
            this_;
        });
        auto wx4 = add_builder(wx3, name, pos, kt, vt, row_name, keyed, reads, PendingRow{.wx = row_done, .qk = row_name, .params = row_params, .gather = std::optional<Nat>{}}, passed);
        auto all = Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), name})), Text::lit("borrow"), Array<Ex>{}})), Text::lit("iter"), Array<Ex>{}})), Text::lit("map"), Array(std::vector{Ex(Ex::XClosure{false, Array(std::vector{Pa(Pa::PaTuple{Array(std::vector{Pa(Pa::PaBind{Text::lit("k")}), Pa(Pa::PaBind{Text::lit("row")})})})}), prism_rtl::rc(Ex(Ex::XTuple{Array(std::vector{Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{Text::lit("k")}))}), Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text::lit("row")})), Text::lit("result"), Array(std::vector{Ex(Ex::XCx{})})})})}))})})})), Text::lit("collect"), Array<Ex>{}});
        auto what = prism_rtl::cat("the dynamic gathered by the `for` at place ", place_text(pos));
        auto wx5 = ({
            Wx this_ = wx4;
            this_.taken = append(this_.taken, Array(std::vector{gathered, prism_rtl::cat(gathered, "_now"), prism_rtl::cat(gathered, "_snap"), prism_rtl::cat(gathered, "_moved"), prism_rtl::cat(gathered, "_publish")}));
            this_.getters = append(this_.getters, Array(std::vector{MethDef{.name = prism_rtl::cat(gathered, "_now"), .recv = Recv(Recv::RecvRef{}), .params = Array<std::tuple<Text, OutTy>>{}, .cx_ = CxArg(CxArg::CxRef{}), .ret = gathered_ty, .body = Array<Do>{}, .tail = all, .doc = Text::lit("The rows' results by key, computed live: what the snapshot of the `for`'s dynamic is taken from (pick ST).")}, snap_getter(gathered, gathered_ty, Text::lit("The `for`'s dynamic, the rows' results by key, a structural dynamic (pick ST): one tick behind the rows, the snapshot of the tick before the tick the read point is after."))}));
            this_.fields = prelude::push(this_.fields, std::tuple{prism_rtl::cat(gathered, "_snap"), OutTy(OutTy::OutSnapshot{prism_rtl::rc(gathered_ty)}), prism_rtl::cat("the `for` at place ", place_text(pos), "'s gathered dynamic, structural: its snapshots, the rows' results and the lagged dynamic (pick ST)")});
            this_.inits = prelude::push(this_.inits, std::tuple{prism_rtl::cat(gathered, "_snap"), Ex(Ex::XCall{Text::lit("Snapshot::new"), Array(std::vector{Ex(Ex::XStr{what})})})});
            this_.snaps = prelude::push(this_.snaps, SnapDef{.name = gathered, .live = prism_rtl::cat(gathered, "_now"), .ty = gathered_ty, .eq = ty_has_eq(lx, peel(full), Array<Text>{}), .builder = name, .before = false, .what = what});
            this_.dyn_reads = insert(this_.dyn_reads, prism_rtl::cat(gathered, "_now"), union_reads(reads, block_reads(reads_closed(row_wx.dyn_reads, result_reads))));
            this_;
        });
        return std::tuple{wx5, Wres(Wres::WrDyn{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XSelf{})), gathered, Array(std::vector{Ex(Ex::XCx{})})}), Array(std::vector{Read(Read::OwnRead{gathered})}), gathered_ty})};
    }
    {
        auto wx4 = add_builder(wx3, name, pos, kt, vt, row_name, keyed, reads, PendingRow{.wx = row_wx, .qk = row_name, .params = row_params, .gather = std::optional<Nat>{}}, passed);
        return std::tuple{wx4, Wres(Wres::WrUnit{})};
    }
}


prism_rtl::Turn<std::tuple<Wx, Wres>> ForLine::cycle() const {
    const auto& wx = this->wx;
    const auto& benv = this->benv;
    const auto& menv = this->menv;
    const auto& binders_opt = this->binders_opt;
    const auto& source = this->source;
    const auto& body = this->body;
    const auto& e = this->e;
    const auto& bound_opt = this->bound_opt;
    auto lx = wx.lx;
    auto pos = wx.pos;
    auto wx1 = ({
        Wx this_ = wx;
        this_.pos = next_pos(this_.pos);
        this_;
    });
    auto binders_opt_1 = binders_opt;
    auto bound_opt_2 = bound_opt;
    auto benv_3 = benv;
    auto body_4 = body;
    auto e_5 = e;
    auto menv_6 = menv;
    auto source_7 = source;
    auto wx_8 = wx;
    return call_then(start_dynamic_expr(wx1, menv_6, source_7), [=](std::tuple<Ex, Array<Read>> dynamic_expr_346102) {
        return ({
            auto [src_ex, reads] = dynamic_expr_346102;
            auto src_ty = peel(type_at(lx, source_7.span));
            auto [kt, vt, keyed] = ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<OutTy, OutTy, bool>> _v;
                if (prism_rtl::is<check_types::Ty::TyMap>(src_ty)) {
                    auto&& k = prism_rtl::as<check_types::Ty::TyMap>(src_ty).a0;
                    auto&& v_ = prism_rtl::as<check_types::Ty::TyMap>(src_ty).a1;
                    _v.set(std::tuple{out_ty_of(lx, k), out_ty_of(lx, v_), true});
                    goto _done;
                }
                if (prism_rtl::is<check_types::Ty::TyArray>(src_ty)) {
                    auto&& v_ = prism_rtl::as<check_types::Ty::TyArray>(src_ty).a0;
                    _v.set(std::tuple{OutTy(OutTy::OutNat{}), out_ty_of(lx, v_), false});
                    goto _done;
                }
                {
                    _v.set(std::tuple{OutTy(OutTy::OutUnit{}), OutTy(OutTy::OutUnit{}), true});
                    goto _done;
                }
            _done:
                _v.take();
            });
            auto src = keyed
                ? src_ex
                : Ex(Ex::XCall{Text::lit("indexed"), Array(std::vector{Ex(Ex::XRef{prism_rtl::rc(src_ex)})})});
            auto base_ = ({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                if (prism_rtl::is_some(bound_opt) && prism_rtl::is<Bn::BnEv>(prism_rtl::some_of(bound_opt))) {
                    auto&& er = prism_rtl::as<Bn::BnEv>(prism_rtl::some_of(bound_opt)).a0;
                    _v.set(gn_of(wx1, er.node_).name);
                    goto _done;
                }
                {
                    _v.set(Text::lit("rows"));
                    goto _done;
                }
            _done:
                _v.take();
            });
            auto [name, wx2a] = fresh_name(wx1, base_);
            auto src_getter = prism_rtl::cat(name, "_source");
            auto src_cached = Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(src_getter, "_cache")})), Text::lit("get"), Array(std::vector{Ex(Ex::XCx{}), Ex(Ex::XClosure{false, Array<Pa>{}, prism_rtl::rc(src)})})});
            auto src_def = MethDef{.name = src_getter, .recv = Recv(Recv::RecvRef{}), .params = Array<std::tuple<Text, OutTy>>{}, .cx_ = CxArg(CxArg::CxRef{}), .ret = OutTy(OutTy::OutMap{prism_rtl::rc(kt), prism_rtl::rc(vt)}), .body = Array<Do>{}, .tail = src_cached, .doc = prism_rtl::cat("The source of the `for` at place ", place_text(pos), " by key, at the read point: what its builder and its rows' entries read, computed once per write behind it.")};
            auto row_name = prism_rtl::cat(wx_8.node_, row_suffix(wx_8), "Row");
            auto locals = row_locals(benv_3, menv_6, body_4);
            auto row_fields = append(Array(std::vector{std::tuple{Text::lit("key"), kt, Text::lit("the row's key")}, std::tuple{Text::lit("left_entry"), OutTy(OutTy::OutCell{prism_rtl::rc(OutTy(OutTy::OutOpt{prism_rtl::rc(vt)}))}), Text::lit("the entry as the tick its key left opened, kept from the row's leaving on (R8)")}, std::tuple{Text::lit("parent"), OutTy(OutTy::OutWeak{wx_8.node_}), Text::lit("the node of the `for`")}}), each(locals, [&](const RowLocal& l) { return std::tuple{l.field, l.ty, prism_rtl::cat("`", l.name, "`, the block's")}; }));
            auto row_moves = append(Array(std::vector{std::tuple{Text::lit("key"), Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{Text::lit("key")}))})}, std::tuple{Text::lit("left_entry"), Ex(Ex::XCall{Text::lit("RefCell::new"), Array(std::vector{Ex(Ex::XNone{})})})}, std::tuple{Text::lit("parent"), Ex(Ex::XVar{Text::lit("parent")})}}), each(locals, [&](const RowLocal& l) { return std::tuple{l.field, Ex(Ex::XVar{l.field})}; }));
            auto row_taken = append(append(node_hooks(), Array(std::vector{Text::lit("key"), Text::lit("value"), Text::lit("parent"), Text::lit("entry"), Text::lit("left_entry")})), each(locals, [&](const RowLocal& l) { return l.field; }));
            auto row_wx0 = new_wx(lx, row_name, row_fields, Array<std::tuple<Text, Ex>>{}, row_moves, Array(std::vector{entry_getter(src_getter, vt)}), map_of(std::vector{std::tuple{Text::lit("entry"), Array(std::vector{Read(Read::ParentRead{src_getter})})}}), row_taken, wx_8.depth, hosted_rows(wx_8));
            auto [wx2p, row_wx0p, ports] = row_env(wx2a, row_wx0, menv_6, body_4);
            auto wx2 = ({
                Wx this_ = add_field(wx2p, prism_rtl::cat(src_getter, "_cache"), OutTy(OutTy::OutNamed{Text::lit("Cache"), Array(std::vector{OutTy(OutTy::OutMap{prism_rtl::rc(kt), prism_rtl::rc(vt)})})}), prism_rtl::cat("the source of the `for` at place ", place_text(pos), ", cached (gap SR)"), Ex(Ex::XCall{Text::lit("Cache::new"), Array<Ex>{}}));
                this_.taken = append(this_.taken, Array(std::vector{src_getter, prism_rtl::cat(src_getter, "_cache")}));
                this_.getters = prelude::push(this_.getters, src_def);
                this_.dyn_reads = insert(this_.dyn_reads, src_getter, reads);
                this_;
            });
            auto key_b = Bn(Bn::BnLocal{Ex(Ex::XVar{Text::lit("key")}), Holding(Holding::Owned{}), kt});
            auto key_m = Bn(Bn::BnLocal{Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), Text::lit("key")}), Holding(Holding::Owned{}), kt});
            auto benv_l = events_of(ports, fold(locals, row_reads(benv_3, parent_arg()), [&](const Env& en, const RowLocal& l) { return bind(en, l.name, Bn(Bn::BnLocal{Ex(Ex::XVar{l.field}), Holding(Holding::Owned{}), l.ty})); }));
            auto menv_l = events_of(ports, fold(locals, row_reads(menv_6, parent_ref()), [&](const Env& en, const RowLocal& l) { return bind(en, l.name, Bn(Bn::BnLocal{Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), l.field}), Holding(Holding::Owned{}), l.ty})); }));
            auto passed = append(hosted_passed(wx_8), each(locals, [&](const RowLocal& l) { return l.passed; }));
            auto row_params = append(append(Array(std::vector{std::tuple{Text::lit("key"), kt}, std::tuple{Text::lit("value"), vt}, std::tuple{Text::lit("parent"), OutTy(OutTy::OutWeak{wx_8.node_})}}), hosted_params(wx_8)), each(locals, [&](const RowLocal& l) { return std::tuple{l.field, l.ty}; }));
            auto entry_m = Bn(Bn::BnDyn{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XSelf{})), Text::lit("entry"), Array(std::vector{Ex(Ex::XCx{})})}), Array(std::vector{Read(Read::ParentRead{src_getter})}), vt});
            auto [rbe, rme] = for_envs(benv_l, menv_l, binders_opt_1, key_b, key_m, Bn(Bn::BnLocal{Ex(Ex::XVar{Text::lit("value")}), Holding(Holding::Owned{}), vt}), entry_m, vt);
            call_then(start_block_into(row_wx0p, rbe, rme, body_4), [=](Wx block_into_349911) {
            return ({
                auto row_wx = block_into_349911;
                auto wx3 = ({
                    Wx this_ = wx2;
                    this_.row_marks = prelude::push(this_.row_marks, RowMarks{.builder = name, .reads = row_place_reads(row_wx), .wrote = row_hears(row_wx), .kind = RowKind(RowKind::ForRow{})});
                    this_;
                });
                auto full = type_at(lx, e_5.span);
                call_then(start_out_ty_of(lx, peel(full)), [=](OutTy out_ty_of_350150) {
                return ({
                    auto out_ty = out_ty_of_350150;
                    ({
                    auto&& _m = row_wx->result;
                    prism_rtl::is<Wres::WrEv>(_m) ? ({
                    auto&& r = prism_rtl::as<Wres::WrEv>(_m).a0;
                    ({
                    auto [gid, wx4] = add_gn(wx3, prism_rtl::cat(name, "_all"), out_ty, GnKind(GnKind::GnGather{}), Nat(1u));
                    auto wx5 = add_field_last(wx4, prism_rtl::cat(name, "_gathered"), OutTy(OutTy::OutStamped{prism_rtl::rc(out_ty)}), Text::lit("the rows' firings this tick, by key"), Ex(Ex::XCall{Text::lit("Stamped::new"), Array<Ex>{}}));
                    auto wx6 = ({
                        Wx this_ = wx5;
                        this_.gns = each(this_.gns, [&](const Gn& n) {
                            return n.id == gid
                                ? with_inputs(n, Array(std::vector{prism_rtl::cat(name, "_gathered")}))
                                : n;
                        });
                        this_;
                    });
                    auto row_done = connect(row_wx, r, Sk(Sk::SkUp{prism_rtl::cat(name, "_all_in")}));
                    auto wx7 = add_builder(wx6, name, pos, kt, vt, row_name, keyed, reads, PendingRow{.wx = row_done, .qk = row_name, .params = row_params, .gather = std::optional(gid)}, passed);
                    (prism_rtl::finished(std::tuple{wx7, Wres(Wres::WrEv{ev_ref_of(wx7, gid)})}));
                });
                })
                    : prism_rtl::is<Wres::WrDyn>(_m) ? ({
                    auto&& ex = prism_rtl::as<Wres::WrDyn>(_m).a0;
                    auto&& result_reads = prism_rtl::as<Wres::WrDyn>(_m).a1;
                    auto&& rt = prism_rtl::as<Wres::WrDyn>(_m).a2;
                    ({
                    auto gathered = prism_rtl::cat(name, "_all");
                    auto gathered_ty = OutTy(OutTy::OutMap{prism_rtl::rc(kt), prism_rtl::rc(rt)});
                    auto own_behind = filter(reads_closed(row_wx.dyn_reads, result_reads), [&](const Read& r) {
                        return ({
                            __label__ _done;
                            prism_rtl::Slot<bool> _v;
                            if (prism_rtl::is<Read::OwnRead>(r)) {
                                _v.set(true);
                                goto _done;
                            }
                            if (prism_rtl::is<Read::ParentRead>(r)) {
                                _v.set(false);
                                goto _done;
                            }
                            prism_rtl::unreachable("no arm matched");
                        _done:
                            _v.take();
                        });
                    });
                    auto row_done = ({
                        Wx this_ = row_wx;
                        this_.getters = prelude::push(this_.getters, MethDef{.name = Text::lit("result"), .recv = Recv(Recv::RecvRef{}), .params = Array<std::tuple<Text, OutTy>>{}, .cx_ = CxArg(CxArg::CxRef{}), .ret = rt, .body = Array<Do>{}, .tail = ex, .doc = Text::lit("The row's result, which the block gathers by key.")});
                        this_.result_moved = len(own_behind) > Nat(0u)
                            ? std::optional(std::tuple{prism_rtl::cat(gathered, "_moved"), own_behind})
                            : std::optional<std::tuple<Text, Array<Read>>>{};
                        this_;
                    });
                    auto wx4 = add_builder(wx3, name, pos, kt, vt, row_name, keyed, reads, PendingRow{.wx = row_done, .qk = row_name, .params = row_params, .gather = std::optional<Nat>{}}, passed);
                    auto all = Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), name})), Text::lit("borrow"), Array<Ex>{}})), Text::lit("iter"), Array<Ex>{}})), Text::lit("map"), Array(std::vector{Ex(Ex::XClosure{false, Array(std::vector{Pa(Pa::PaTuple{Array(std::vector{Pa(Pa::PaBind{Text::lit("k")}), Pa(Pa::PaBind{Text::lit("row")})})})}), prism_rtl::rc(Ex(Ex::XTuple{Array(std::vector{Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{Text::lit("k")}))}), Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text::lit("row")})), Text::lit("result"), Array(std::vector{Ex(Ex::XCx{})})})})}))})})})), Text::lit("collect"), Array<Ex>{}});
                    auto what = prism_rtl::cat("the dynamic gathered by the `for` at place ", place_text(pos));
                    auto wx5 = ({
                        Wx this_ = wx4;
                        this_.taken = append(this_.taken, Array(std::vector{gathered, prism_rtl::cat(gathered, "_now"), prism_rtl::cat(gathered, "_snap"), prism_rtl::cat(gathered, "_moved"), prism_rtl::cat(gathered, "_publish")}));
                        this_.getters = append(this_.getters, Array(std::vector{MethDef{.name = prism_rtl::cat(gathered, "_now"), .recv = Recv(Recv::RecvRef{}), .params = Array<std::tuple<Text, OutTy>>{}, .cx_ = CxArg(CxArg::CxRef{}), .ret = gathered_ty, .body = Array<Do>{}, .tail = all, .doc = Text::lit("The rows' results by key, computed live: what the snapshot of the `for`'s dynamic is taken from (pick ST).")}, snap_getter(gathered, gathered_ty, Text::lit("The `for`'s dynamic, the rows' results by key, a structural dynamic (pick ST): one tick behind the rows, the snapshot of the tick before the tick the read point is after."))}));
                        this_.fields = prelude::push(this_.fields, std::tuple{prism_rtl::cat(gathered, "_snap"), OutTy(OutTy::OutSnapshot{prism_rtl::rc(gathered_ty)}), prism_rtl::cat("the `for` at place ", place_text(pos), "'s gathered dynamic, structural: its snapshots, the rows' results and the lagged dynamic (pick ST)")});
                        this_.inits = prelude::push(this_.inits, std::tuple{prism_rtl::cat(gathered, "_snap"), Ex(Ex::XCall{Text::lit("Snapshot::new"), Array(std::vector{Ex(Ex::XStr{what})})})});
                        this_.snaps = prelude::push(this_.snaps, SnapDef{.name = gathered, .live = prism_rtl::cat(gathered, "_now"), .ty = gathered_ty, .eq = ty_has_eq(lx, peel(full), Array<Text>{}), .builder = name, .before = false, .what = what});
                        this_.dyn_reads = insert(this_.dyn_reads, prism_rtl::cat(gathered, "_now"), union_reads(reads, block_reads(reads_closed(row_wx.dyn_reads, result_reads))));
                        this_;
                    });
                    (prism_rtl::finished(std::tuple{wx5, Wres(Wres::WrDyn{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XSelf{})), gathered, Array(std::vector{Ex(Ex::XCx{})})}), Array(std::vector{Read(Read::OwnRead{gathered})}), gathered_ty})}));
                });
                })
                    : ({
                    auto wx4 = add_builder(wx3, name, pos, kt, vt, row_name, keyed, reads, PendingRow{.wx = row_wx, .qk = row_name, .params = row_params, .gather = std::optional<Nat>{}}, passed);
                    (prism_rtl::finished(std::tuple{wx4, Wres(Wres::WrUnit{})}));
                });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start ForLine, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Wx, Wres>> start_for_line(Wx wx, Env benv, Env menv, std::optional<ast::ForBinders> binders_opt, ast::Expr source, ast::Block body, ast::Expr e, std::optional<Bn> bound_opt) {
    return prism_rtl::make_rc<ForLine>(wx, benv, menv, binders_opt, source, body, e, bound_opt);
}


/// EntryGetter: fn Text, OutTy -> MethDef
MethDef entry_getter(const Text& src_getter, const OutTy& vt) {
    auto found = Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text::lit("parent")})), src_getter, Array(std::vector{Ex(Ex::XCx{})})})), Text::lit("get"), Array(std::vector{Ex(Ex::XRef{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), Text::lit("key")}))})})})), Text::lit("cloned"), Array<Ex>{}});
    auto opened_1 = Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XCx{})), Text::lit("before"), Array(std::vector{Ex(Ex::XClosure{false, Array(std::vector{Pa(Pa::PaBind{Text::lit("cx")})}), prism_rtl::rc(found)})})})), Text::lit("expect"), Array(std::vector{Ex(Ex::XStr{Text::lit("a row's key is in its source as its tick opened")})})});
    auto body = Array(std::vector{Do(Do::DoIfLet{Pa(Pa::PaCtor{Text::lit("Some"), Array(std::vector{Pa(Pa::PaBind{Text::lit("v")})})}), Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), Text::lit("left_entry")})), Text::lit("borrow"), Array<Ex>{}})), Text::lit("as_ref"), Array<Ex>{}}), Array(std::vector{Do(Do::DoReturn{Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{Text::lit("v")}))})})}), Array<Do>{}}), Do(Do::DoLet{Pa(Pa::PaBind{Text::lit("parent")}), parent_ref()})});
    auto tail_ = Ex(Ex::XMatch{prism_rtl::rc(found), Array(std::vector{XArm{.pat = Pa(Pa::PaCtor{Text::lit("Some"), Array(std::vector{Pa(Pa::PaBind{Text::lit("v")})})}), .conds = Array<Cc>{}, .body = Ex(Ex::XVar{Text::lit("v")})}, XArm{.pat = Pa(Pa::PaUnit{Text::lit("None")}), .conds = Array<Cc>{}, .body = opened_1}}), false, vt});
    return MethDef{.name = Text::lit("entry"), .recv = Recv(Recv::RecvRef{}), .params = Array<std::tuple<Text, OutTy>>{}, .cx_ = CxArg(CxArg::CxRef{}), .ret = vt, .body = body, .tail = tail_, .doc = Text::lit("The row's entry, `$_`: the block's source at this key, at the read point; from the row's leaving on, the value as the leaving tick opened.")};
}


/// AddBuilder: fn Wx, Text, Pos, OutTy, OutTy, Text, Bool, [Read], PendingRow, [Ex] -> Wx
Wx add_builder(const Wx& wx, const Text& name, const Pos_& pos, const OutTy& kt, const OutTy& vt, const Text& row_name, const bool& keyed, const Array<Read>& reads, const PendingRow& waiting, const Array<Ex>& passed) {
    auto wx0 = add_field_last(wx, name, OutTy(OutTy::OutCell{prism_rtl::rc(OutTy(OutTy::OutMap{prism_rtl::rc(kt), prism_rtl::rc(OutTy(OutTy::OutRc{prism_rtl::rc(OutTy(OutTy::OutNamed{row_name, Array<OutTy>{}}))}))}))}), prism_rtl::cat("the rows of the `for` at place ", place_text(pos)), Ex(Ex::XCall{Text::lit("RefCell::new"), Array(std::vector{Ex(Ex::XCall{Text::lit("Map::new"), Array<Ex>{}})})}));
    Wx this_ = wx0;
    this_.builders = prelude::push(this_.builders, ForDef{.name = name, .pos = pos, .at = place_at(wx, Text::lit("self"), pos), .key_ty = kt, .value_ty = vt, .row_node = row_name, .keyed = keyed, .source = prism_rtl::cat(name, "_source"), .parent = Ex(Ex::XWeak{prism_rtl::rc(Ex(Ex::XSelf{}))}), .passed = passed});
    this_.build_holds = union_reads(this_.build_holds, reads);
    this_.pending = prelude::push(this_.pending, waiting);
    return this_;
}


/// RowPlaceReads: fn Wx -> [Read]
Array<Read> row_place_reads(const Wx& row_wx) {
    return fold(row_wx.places, Array<Read>{}, [&](const Array<Read>& acc, const Place& pl) { return union_reads(acc, block_reads(reads_closed(row_wx.dyn_reads, pl.reads))); });
}


/// HostedParams: fn Wx -> [((Text, OutTy))]
Array<std::tuple<Text, OutTy>> hosted_params(const Wx& wx) {
    auto&& _m = hosted_rows(wx);
    if (prism_rtl::is_some(_m)) {
        return Array(std::vector{std::tuple{Text::lit("enclosing"), host_of_ty()}});
    }
    if (prism_rtl::is_none(_m)) {
        return Array<std::tuple<Text, OutTy>>{};
    }
    prism_rtl::unreachable("no arm matched");
}


/// HostedPassed: fn Wx -> [Ex]
Array<Ex> hosted_passed(const Wx& wx) {
    auto&& _m = hosted_rows(wx);
    if (prism_rtl::is_some(_m)) {
        return Array(std::vector{Ex(Ex::XClone{prism_rtl::rc(host_field_ex(wx, wx.pos))})});
    }
    if (prism_rtl::is_none(_m)) {
        return Array<Ex>{};
    }
    prism_rtl::unreachable("no arm matched");
}


/// RowReads: fn Env, Ex -> Env
Env row_reads(const Env& env, const Ex& pref) {
    return fold(keys(env->names), env, [&](const Env& en, const Text& k) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Env> _v;
            auto&& _m = prelude::get(env->names, k);
            if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnHold>(prism_rtl::some_of(_m))) {
                auto&& f = prism_rtl::as<Bn::BnHold>(prism_rtl::some_of(_m)).a0;
                auto&& t = prism_rtl::as<Bn::BnHold>(prism_rtl::some_of(_m)).a1;
                _v.set(bind(en, k, Bn(Bn::BnDyn{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(pref), f})), Text::lit("get"), Array(std::vector{Ex(Ex::XCx{})})}), Array(std::vector{Read(Read::ParentRead{f})}), t})));
                goto _done;
            }
            if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnDyn>(prism_rtl::some_of(_m)) && prism_rtl::is<Ex::XMethod>(prism_rtl::as<Bn::BnDyn>(prism_rtl::some_of(_m)).a0)) {
                auto&& m357427_1_0_0 = prism_rtl::as<Ex::XMethod>(prism_rtl::as<Bn::BnDyn>(prism_rtl::some_of(_m)).a0).a0;
                auto&& m = prism_rtl::as<Ex::XMethod>(prism_rtl::as<Bn::BnDyn>(prism_rtl::some_of(_m)).a0).a1;
                auto&& xs = prism_rtl::as<Ex::XMethod>(prism_rtl::as<Bn::BnDyn>(prism_rtl::some_of(_m)).a0).a2;
                auto&& t = prism_rtl::as<Bn::BnDyn>(prism_rtl::some_of(_m)).a2;
                if (prism_rtl::is<Ex::XSelf>(m357427_1_0_0)) {
                    _v.set(bind(en, k, Bn(Bn::BnDyn{Ex(Ex::XMethod{prism_rtl::rc(pref), m, xs}), Array(std::vector{Read(Read::ParentRead{m})}), t})));
                    goto _done;
                }
            }
            {
                _v.set(en);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


/// EventsOf: fn Env, Env -> Env
Env events_of(const Env& ports, const Env& env) {
    return fold(keys(ports->names), env, [&](const Env& en, const Text& k) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Env> _v;
            auto&& _m = prelude::get(ports->names, k);
            if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnEv>(prism_rtl::some_of(_m))) {
                auto&& er = prism_rtl::as<Bn::BnEv>(prism_rtl::some_of(_m)).a0;
                auto&& t = prism_rtl::as<Bn::BnEv>(prism_rtl::some_of(_m)).a1;
                _v.set(bind(en, k, Bn(Bn::BnEv{er, t})));
                goto _done;
            }
            {
                _v.set(en);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}

}  // namespace crate::lower
