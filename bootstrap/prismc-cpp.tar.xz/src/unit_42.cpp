// The modules `Lower.Model`, `Lower.Node`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <lower/model/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Lower.Model`, from `target/bootstrap/cpp-src/prismc/lower/model.prism`.
namespace crate::lower::model {

void AnswerCase::show(Printer& p) const {
    p.record("AnswerCase", {{"variant", variant}, {"accessor", accessor}, {"struct_path", struct_path}, {"tag_name", tag_name}, {"ty", ty}});
}

Pod AnswerCase::to_pod() const {
    return Pod::record("AnswerCase", {{"variant", prism_rtl::to_pod(variant)}, {"accessor", prism_rtl::to_pod(accessor)}, {"struct_path", prism_rtl::to_pod(struct_path)}, {"tag_name", prism_rtl::to_pod(tag_name)}, {"ty", prism_rtl::to_pod(ty)}});
}

Result<AnswerCase> AnswerCase::from_pod(const Pod& whole) {
    return AnswerCase{.variant = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "variant")))), .accessor = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "accessor")))), .struct_path = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "struct_path")))), .tag_name = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "tag_name")))), .ty = TRY(prism_rtl::from_pod<OutTy>(TRY(crate::prelude::field(whole, "ty"))))};
}


void AnswerDef::show(Printer& p) const {
    p.record("AnswerDef", {{"cases", cases_}});
}

Pod AnswerDef::to_pod() const {
    return Pod::record("AnswerDef", {{"cases", prism_rtl::to_pod(cases_)}});
}

Result<AnswerDef> AnswerDef::from_pod(const Pod& whole) {
    return AnswerDef{.cases_ = TRY(prism_rtl::from_pod<Array<AnswerCase>>(TRY(crate::prelude::field(whole, "cases"))))};
}


void CaseDef::show(Printer& p) const {
    p.record("CaseDef", {{"name", name}, {"prism", prism}, {"fields", fields}});
}

Pod CaseDef::to_pod() const {
    return Pod::record("CaseDef", {{"name", prism_rtl::to_pod(name)}, {"prism", prism_rtl::to_pod(prism)}, {"fields", prism_rtl::to_pod(fields)}});
}

Result<CaseDef> CaseDef::from_pod(const Pod& whole) {
    return CaseDef{.name = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .prism = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "prism")))), .fields = TRY(prism_rtl::from_pod<Array<std::tuple<Text, OutTy>>>(TRY(crate::prelude::field(whole, "fields"))))};
}


void Cc::show(Printer& p) const {
    if (auto c = std::get_if<CcIf>(&cases())) p.choice("CcIf", {c->a0});
    else if (auto c = std::get_if<CcLet>(&cases())) p.choice("CcLet", {c->a0, c->a1});
}

Pod Cc::to_pod() const {
    return std::holds_alternative<CcIf>(cases()) ? Pod::choice("CcIf", {prism_rtl::to_pod(std::get<CcIf>(cases()).a0)})
        : std::holds_alternative<CcLet>(cases()) ? Pod::choice("CcLet", {prism_rtl::to_pod(std::get<CcLet>(cases()).a0), prism_rtl::to_pod(std::get<CcLet>(cases()).a1)})
        : Pod();
}

Result<Cc> Cc::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "CcIf" && c->args.size() == 1) return Cc(CcIf{TRY(prism_rtl::from_pod<Ex>(c->args[0]))});
        if (c->ctor == "CcLet" && c->args.size() == 2) return Cc(CcLet{TRY(prism_rtl::from_pod<Pa>(c->args[0])), TRY(prism_rtl::from_pod<Ex>(c->args[1]))});
    }
    return mismatch<Cc>("a Cc", p);
}


void CheckDef::show(Printer& p) const {
    p.record("CheckDef", {{"name", name}, {"lines", lines}});
}

Pod CheckDef::to_pod() const {
    return Pod::record("CheckDef", {{"name", prism_rtl::to_pod(name)}, {"lines", prism_rtl::to_pod(lines)}});
}

Result<CheckDef> CheckDef::from_pod(const Pod& whole) {
    return CheckDef{.name = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .lines = TRY(prism_rtl::from_pod<Array<Ex>>(TRY(crate::prelude::field(whole, "lines"))))};
}


void CxArg::show(Printer& p) const {
    if (auto c = std::get_if<CxMut>(&cases())) p.choice("CxMut", {});
    else if (auto c = std::get_if<CxRef>(&cases())) p.choice("CxRef", {});
    else if (auto c = std::get_if<CxNone>(&cases())) p.choice("CxNone", {});
}

Pod CxArg::to_pod() const {
    return std::holds_alternative<CxMut>(cases()) ? Pod::choice("CxMut", {})
        : std::holds_alternative<CxRef>(cases()) ? Pod::choice("CxRef", {})
        : std::holds_alternative<CxNone>(cases()) ? Pod::choice("CxNone", {})
        : Pod();
}

Result<CxArg> CxArg::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "CxMut" && c->args.size() == 0) return CxArg(CxMut{});
        if (c->ctor == "CxRef" && c->args.size() == 0) return CxArg(CxRef{});
        if (c->ctor == "CxNone" && c->args.size() == 0) return CxArg(CxNone{});
    }
    return mismatch<CxArg>("a CxArg", p);
}


void Do::show(Printer& p) const {
    if (auto c = std::get_if<DoLet>(&cases())) p.choice("DoLet", {c->a0, c->a1});
    else if (auto c = std::get_if<DoLetElse>(&cases())) p.choice("DoLetElse", {c->a0, c->a1, c->a2});
    else if (auto c = std::get_if<DoAssign>(&cases())) p.choice("DoAssign", {c->a0, c->a1});
    else if (auto c = std::get_if<DoWhile>(&cases())) p.choice("DoWhile", {c->a0, c->a1});
    else if (auto c = std::get_if<DoWhileLet>(&cases())) p.choice("DoWhileLet", {c->a0, c->a1, c->a2});
    else if (auto c = std::get_if<DoFor>(&cases())) p.choice("DoFor", {c->a0, c->a1, c->a2});
    else if (auto c = std::get_if<DoExpr>(&cases())) p.choice("DoExpr", {c->a0});
    else if (auto c = std::get_if<DoIf>(&cases())) p.choice("DoIf", {c->a0, c->a1, c->a2});
    else if (auto c = std::get_if<DoIfLet>(&cases())) p.choice("DoIfLet", {c->a0, c->a1, c->a2, c->a3});
    else if (auto c = std::get_if<DoMatch>(&cases())) p.choice("DoMatch", {c->a0, c->a1});
    else if (auto c = std::get_if<DoReturn>(&cases())) p.choice("DoReturn", {c->a0});
    else if (auto c = std::get_if<DoBlock>(&cases())) p.choice("DoBlock", {c->a0});
    else if (auto c = std::get_if<DoScope>(&cases())) p.choice("DoScope", {c->a0});
    else if (auto c = std::get_if<DoLine>(&cases())) p.choice("DoLine", {c->a0});
    else if (auto c = std::get_if<DoNote>(&cases())) p.choice("DoNote", {c->a0});
}

Pod Do::to_pod() const {
    return std::holds_alternative<DoLet>(cases()) ? Pod::choice("DoLet", {prism_rtl::to_pod(std::get<DoLet>(cases()).a0), prism_rtl::to_pod(std::get<DoLet>(cases()).a1)})
        : std::holds_alternative<DoLetElse>(cases()) ? Pod::choice("DoLetElse", {prism_rtl::to_pod(std::get<DoLetElse>(cases()).a0), prism_rtl::to_pod(std::get<DoLetElse>(cases()).a1), prism_rtl::to_pod(std::get<DoLetElse>(cases()).a2)})
        : std::holds_alternative<DoAssign>(cases()) ? Pod::choice("DoAssign", {prism_rtl::to_pod(std::get<DoAssign>(cases()).a0), prism_rtl::to_pod(std::get<DoAssign>(cases()).a1)})
        : std::holds_alternative<DoWhile>(cases()) ? Pod::choice("DoWhile", {prism_rtl::to_pod(std::get<DoWhile>(cases()).a0), prism_rtl::to_pod(std::get<DoWhile>(cases()).a1)})
        : std::holds_alternative<DoWhileLet>(cases()) ? Pod::choice("DoWhileLet", {prism_rtl::to_pod(std::get<DoWhileLet>(cases()).a0), prism_rtl::to_pod(std::get<DoWhileLet>(cases()).a1), prism_rtl::to_pod(std::get<DoWhileLet>(cases()).a2)})
        : std::holds_alternative<DoFor>(cases()) ? Pod::choice("DoFor", {prism_rtl::to_pod(std::get<DoFor>(cases()).a0), prism_rtl::to_pod(std::get<DoFor>(cases()).a1), prism_rtl::to_pod(std::get<DoFor>(cases()).a2)})
        : std::holds_alternative<DoExpr>(cases()) ? Pod::choice("DoExpr", {prism_rtl::to_pod(std::get<DoExpr>(cases()).a0)})
        : std::holds_alternative<DoIf>(cases()) ? Pod::choice("DoIf", {prism_rtl::to_pod(std::get<DoIf>(cases()).a0), prism_rtl::to_pod(std::get<DoIf>(cases()).a1), prism_rtl::to_pod(std::get<DoIf>(cases()).a2)})
        : std::holds_alternative<DoIfLet>(cases()) ? Pod::choice("DoIfLet", {prism_rtl::to_pod(std::get<DoIfLet>(cases()).a0), prism_rtl::to_pod(std::get<DoIfLet>(cases()).a1), prism_rtl::to_pod(std::get<DoIfLet>(cases()).a2), prism_rtl::to_pod(std::get<DoIfLet>(cases()).a3)})
        : std::holds_alternative<DoMatch>(cases()) ? Pod::choice("DoMatch", {prism_rtl::to_pod(std::get<DoMatch>(cases()).a0), prism_rtl::to_pod(std::get<DoMatch>(cases()).a1)})
        : std::holds_alternative<DoReturn>(cases()) ? Pod::choice("DoReturn", {prism_rtl::to_pod(std::get<DoReturn>(cases()).a0)})
        : std::holds_alternative<DoBlock>(cases()) ? Pod::choice("DoBlock", {prism_rtl::to_pod(std::get<DoBlock>(cases()).a0)})
        : std::holds_alternative<DoScope>(cases()) ? Pod::choice("DoScope", {prism_rtl::to_pod(std::get<DoScope>(cases()).a0)})
        : std::holds_alternative<DoLine>(cases()) ? Pod::choice("DoLine", {prism_rtl::to_pod(std::get<DoLine>(cases()).a0)})
        : std::holds_alternative<DoNote>(cases()) ? Pod::choice("DoNote", {prism_rtl::to_pod(std::get<DoNote>(cases()).a0)})
        : Pod();
}

Result<Do> Do::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "DoLet" && c->args.size() == 2) return Do(DoLet{TRY(prism_rtl::from_pod<Pa>(c->args[0])), TRY(prism_rtl::from_pod<Ex>(c->args[1]))});
        if (c->ctor == "DoLetElse" && c->args.size() == 3) return Do(DoLetElse{TRY(prism_rtl::from_pod<Pa>(c->args[0])), TRY(prism_rtl::from_pod<Ex>(c->args[1])), TRY(prism_rtl::from_pod<Ex>(c->args[2]))});
        if (c->ctor == "DoAssign" && c->args.size() == 2) return Do(DoAssign{TRY(prism_rtl::from_pod<Ex>(c->args[0])), TRY(prism_rtl::from_pod<Ex>(c->args[1]))});
        if (c->ctor == "DoWhile" && c->args.size() == 2) return Do(DoWhile{TRY(prism_rtl::from_pod<Ex>(c->args[0])), TRY(prism_rtl::from_pod<Array<Do>>(c->args[1]))});
        if (c->ctor == "DoWhileLet" && c->args.size() == 3) return Do(DoWhileLet{TRY(prism_rtl::from_pod<Pa>(c->args[0])), TRY(prism_rtl::from_pod<Ex>(c->args[1])), TRY(prism_rtl::from_pod<Array<Do>>(c->args[2]))});
        if (c->ctor == "DoFor" && c->args.size() == 3) return Do(DoFor{TRY(prism_rtl::from_pod<Pa>(c->args[0])), TRY(prism_rtl::from_pod<Ex>(c->args[1])), TRY(prism_rtl::from_pod<Array<Do>>(c->args[2]))});
        if (c->ctor == "DoExpr" && c->args.size() == 1) return Do(DoExpr{TRY(prism_rtl::from_pod<Ex>(c->args[0]))});
        if (c->ctor == "DoIf" && c->args.size() == 3) return Do(DoIf{TRY(prism_rtl::from_pod<Ex>(c->args[0])), TRY(prism_rtl::from_pod<Array<Do>>(c->args[1])), TRY(prism_rtl::from_pod<Array<Do>>(c->args[2]))});
        if (c->ctor == "DoIfLet" && c->args.size() == 4) return Do(DoIfLet{TRY(prism_rtl::from_pod<Pa>(c->args[0])), TRY(prism_rtl::from_pod<Ex>(c->args[1])), TRY(prism_rtl::from_pod<Array<Do>>(c->args[2])), TRY(prism_rtl::from_pod<Array<Do>>(c->args[3]))});
        if (c->ctor == "DoMatch" && c->args.size() == 2) return Do(DoMatch{TRY(prism_rtl::from_pod<Ex>(c->args[0])), TRY(prism_rtl::from_pod<Array<std::tuple<Pa, Array<Do>>>>(c->args[1]))});
        if (c->ctor == "DoReturn" && c->args.size() == 1) return Do(DoReturn{TRY(prism_rtl::from_pod<Ex>(c->args[0]))});
        if (c->ctor == "DoBlock" && c->args.size() == 1) return Do(DoBlock{TRY(prism_rtl::from_pod<Array<Do>>(c->args[0]))});
        if (c->ctor == "DoScope" && c->args.size() == 1) return Do(DoScope{TRY(prism_rtl::from_pod<Array<Do>>(c->args[0]))});
        if (c->ctor == "DoLine" && c->args.size() == 1) return Do(DoLine{TRY(prism_rtl::from_pod<Array<Do>>(c->args[0]))});
        if (c->ctor == "DoNote" && c->args.size() == 1) return Do(DoNote{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
    }
    return mismatch<Do>("a Do", p);
}


void Ex::show(Printer& p) const {
    if (auto c = std::get_if<XVar>(&cases())) p.choice("XVar", {c->a0});
    else if (auto c = std::get_if<XPath>(&cases())) p.choice("XPath", {c->a0});
    else if (auto c = std::get_if<XSelf>(&cases())) p.choice("XSelf", {});
    else if (auto c = std::get_if<XCx>(&cases())) p.choice("XCx", {});
    else if (auto c = std::get_if<XConst>(&cases())) p.choice("XConst", {c->a0});
    else if (auto c = std::get_if<XUnit>(&cases())) p.choice("XUnit", {});
    else if (auto c = std::get_if<XNone>(&cases())) p.choice("XNone", {});
    else if (auto c = std::get_if<XBool>(&cases())) p.choice("XBool", {c->a0});
    else if (auto c = std::get_if<XNat>(&cases())) p.choice("XNat", {c->a0});
    else if (auto c = std::get_if<XInt>(&cases())) p.choice("XInt", {c->a0});
    else if (auto c = std::get_if<XByte>(&cases())) p.choice("XByte", {c->a0});
    else if (auto c = std::get_if<XFloat>(&cases())) p.choice("XFloat", {c->a0});
    else if (auto c = std::get_if<XIndex>(&cases())) p.choice("XIndex", {c->a0});
    else if (auto c = std::get_if<XChar>(&cases())) p.choice("XChar", {c->a0});
    else if (auto c = std::get_if<XStr>(&cases())) p.choice("XStr", {c->a0});
    else if (auto c = std::get_if<XRegex>(&cases())) p.choice("XRegex", {c->a0, c->a1});
    else if (auto c = std::get_if<XReplacement>(&cases())) p.choice("XReplacement", {c->a0, c->a1, c->a2});
    else if (auto c = std::get_if<XRef>(&cases())) p.choice("XRef", {c->a0});
    else if (auto c = std::get_if<XRefMut>(&cases())) p.choice("XRefMut", {c->a0});
    else if (auto c = std::get_if<XDeref>(&cases())) p.choice("XDeref", {c->a0});
    else if (auto c = std::get_if<XTarget>(&cases())) p.choice("XTarget", {c->a0});
    else if (auto c = std::get_if<XClone>(&cases())) p.choice("XClone", {c->a0});
    else if (auto c = std::get_if<XWeak>(&cases())) p.choice("XWeak", {c->a0});
    else if (auto c = std::get_if<XUpgrade>(&cases())) p.choice("XUpgrade", {c->a0});
    else if (auto c = std::get_if<XBreak>(&cases())) p.choice("XBreak", {c->a0, c->a1});
    else if (auto c = std::get_if<XBreakLoop>(&cases())) p.choice("XBreakLoop", {});
    else if (auto c = std::get_if<XLater>(&cases())) p.choice("XLater", {c->a0});
    else if (auto c = std::get_if<XFormatStr>(&cases())) p.choice("XFormatStr", {c->a0});
    else if (auto c = std::get_if<XIsCase>(&cases())) p.choice("XIsCase", {c->a0, c->a1});
    else if (auto c = std::get_if<XRefusal>(&cases())) p.choice("XRefusal", {c->a0});
    else if (auto c = std::get_if<XUnreachable>(&cases())) p.choice("XUnreachable", {});
    else if (auto c = std::get_if<XCall>(&cases())) p.choice("XCall", {c->a0, c->a1});
    else if (auto c = std::get_if<XApply>(&cases())) p.choice("XApply", {c->a0, c->a1});
    else if (auto c = std::get_if<XMethod>(&cases())) p.choice("XMethod", {c->a0, c->a1, c->a2});
    else if (auto c = std::get_if<XBin>(&cases())) p.choice("XBin", {c->a0, c->a1, c->a2});
    else if (auto c = std::get_if<XUnary>(&cases())) p.choice("XUnary", {c->a0, c->a1});
    else if (auto c = std::get_if<XCtor>(&cases())) p.choice("XCtor", {c->a0, c->a1});
    else if (auto c = std::get_if<XRecord>(&cases())) p.choice("XRecord", {c->a0, c->a1});
    else if (auto c = std::get_if<XTuple>(&cases())) p.choice("XTuple", {c->a0});
    else if (auto c = std::get_if<XVec>(&cases())) p.choice("XVec", {c->a0});
    else if (auto c = std::get_if<XText>(&cases())) p.choice("XText", {c->a0});
    else if (auto c = std::get_if<XFormat>(&cases())) p.choice("XFormat", {c->a0});
    else if (auto c = std::get_if<XMatch>(&cases())) p.choice("XMatch", {c->a0, c->a1, c->a2, c->a3});
    else if (auto c = std::get_if<XChain>(&cases())) p.choice("XChain", {c->a0, c->a1, c->a2, c->a3});
    else if (auto c = std::get_if<XIf>(&cases())) p.choice("XIf", {c->a0, c->a1, c->a2});
    else if (auto c = std::get_if<XBlock>(&cases())) p.choice("XBlock", {c->a0, c->a1});
    else if (auto c = std::get_if<XLabeled>(&cases())) p.choice("XLabeled", {c->a0, c->a1, c->a2, c->a3});
    else if (auto c = std::get_if<XClosure>(&cases())) p.choice("XClosure", {c->a0, c->a1, c->a2});
    else if (auto c = std::get_if<XTry>(&cases())) p.choice("XTry", {c->a0});
    else if (auto c = std::get_if<XField>(&cases())) p.choice("XField", {c->a0, c->a1});
    else if (auto c = std::get_if<XPart>(&cases())) p.choice("XPart", {c->a0, c->a1});
    else if (auto c = std::get_if<XDecode>(&cases())) p.choice("XDecode", {c->a0, c->a1});
    else if (auto c = std::get_if<XCast>(&cases())) p.choice("XCast", {c->a0, c->a1});
    else if (auto c = std::get_if<XTyped>(&cases())) p.choice("XTyped", {c->a0, c->a1});
}

Pod Ex::to_pod() const {
    return std::holds_alternative<XVar>(cases()) ? Pod::choice("XVar", {prism_rtl::to_pod(std::get<XVar>(cases()).a0)})
        : std::holds_alternative<XPath>(cases()) ? Pod::choice("XPath", {prism_rtl::to_pod(std::get<XPath>(cases()).a0)})
        : std::holds_alternative<XSelf>(cases()) ? Pod::choice("XSelf", {})
        : std::holds_alternative<XCx>(cases()) ? Pod::choice("XCx", {})
        : std::holds_alternative<XConst>(cases()) ? Pod::choice("XConst", {prism_rtl::to_pod(std::get<XConst>(cases()).a0)})
        : std::holds_alternative<XUnit>(cases()) ? Pod::choice("XUnit", {})
        : std::holds_alternative<XNone>(cases()) ? Pod::choice("XNone", {})
        : std::holds_alternative<XBool>(cases()) ? Pod::choice("XBool", {prism_rtl::to_pod(std::get<XBool>(cases()).a0)})
        : std::holds_alternative<XNat>(cases()) ? Pod::choice("XNat", {prism_rtl::to_pod(std::get<XNat>(cases()).a0)})
        : std::holds_alternative<XInt>(cases()) ? Pod::choice("XInt", {prism_rtl::to_pod(std::get<XInt>(cases()).a0)})
        : std::holds_alternative<XByte>(cases()) ? Pod::choice("XByte", {prism_rtl::to_pod(std::get<XByte>(cases()).a0)})
        : std::holds_alternative<XFloat>(cases()) ? Pod::choice("XFloat", {prism_rtl::to_pod(std::get<XFloat>(cases()).a0)})
        : std::holds_alternative<XIndex>(cases()) ? Pod::choice("XIndex", {prism_rtl::to_pod(std::get<XIndex>(cases()).a0)})
        : std::holds_alternative<XChar>(cases()) ? Pod::choice("XChar", {prism_rtl::to_pod(std::get<XChar>(cases()).a0)})
        : std::holds_alternative<XStr>(cases()) ? Pod::choice("XStr", {prism_rtl::to_pod(std::get<XStr>(cases()).a0)})
        : std::holds_alternative<XRegex>(cases()) ? Pod::choice("XRegex", {prism_rtl::to_pod(std::get<XRegex>(cases()).a0), prism_rtl::to_pod(std::get<XRegex>(cases()).a1)})
        : std::holds_alternative<XReplacement>(cases()) ? Pod::choice("XReplacement", {prism_rtl::to_pod(std::get<XReplacement>(cases()).a0), prism_rtl::to_pod(std::get<XReplacement>(cases()).a1), prism_rtl::to_pod(std::get<XReplacement>(cases()).a2)})
        : std::holds_alternative<XRef>(cases()) ? Pod::choice("XRef", {prism_rtl::to_pod(std::get<XRef>(cases()).a0)})
        : std::holds_alternative<XRefMut>(cases()) ? Pod::choice("XRefMut", {prism_rtl::to_pod(std::get<XRefMut>(cases()).a0)})
        : std::holds_alternative<XDeref>(cases()) ? Pod::choice("XDeref", {prism_rtl::to_pod(std::get<XDeref>(cases()).a0)})
        : std::holds_alternative<XTarget>(cases()) ? Pod::choice("XTarget", {prism_rtl::to_pod(std::get<XTarget>(cases()).a0)})
        : std::holds_alternative<XClone>(cases()) ? Pod::choice("XClone", {prism_rtl::to_pod(std::get<XClone>(cases()).a0)})
        : std::holds_alternative<XWeak>(cases()) ? Pod::choice("XWeak", {prism_rtl::to_pod(std::get<XWeak>(cases()).a0)})
        : std::holds_alternative<XUpgrade>(cases()) ? Pod::choice("XUpgrade", {prism_rtl::to_pod(std::get<XUpgrade>(cases()).a0)})
        : std::holds_alternative<XBreak>(cases()) ? Pod::choice("XBreak", {prism_rtl::to_pod(std::get<XBreak>(cases()).a0), prism_rtl::to_pod(std::get<XBreak>(cases()).a1)})
        : std::holds_alternative<XBreakLoop>(cases()) ? Pod::choice("XBreakLoop", {})
        : std::holds_alternative<XLater>(cases()) ? Pod::choice("XLater", {prism_rtl::to_pod(std::get<XLater>(cases()).a0)})
        : std::holds_alternative<XFormatStr>(cases()) ? Pod::choice("XFormatStr", {prism_rtl::to_pod(std::get<XFormatStr>(cases()).a0)})
        : std::holds_alternative<XIsCase>(cases()) ? Pod::choice("XIsCase", {prism_rtl::to_pod(std::get<XIsCase>(cases()).a0), prism_rtl::to_pod(std::get<XIsCase>(cases()).a1)})
        : std::holds_alternative<XRefusal>(cases()) ? Pod::choice("XRefusal", {prism_rtl::to_pod(std::get<XRefusal>(cases()).a0)})
        : std::holds_alternative<XUnreachable>(cases()) ? Pod::choice("XUnreachable", {})
        : std::holds_alternative<XCall>(cases()) ? Pod::choice("XCall", {prism_rtl::to_pod(std::get<XCall>(cases()).a0), prism_rtl::to_pod(std::get<XCall>(cases()).a1)})
        : std::holds_alternative<XApply>(cases()) ? Pod::choice("XApply", {prism_rtl::to_pod(std::get<XApply>(cases()).a0), prism_rtl::to_pod(std::get<XApply>(cases()).a1)})
        : std::holds_alternative<XMethod>(cases()) ? Pod::choice("XMethod", {prism_rtl::to_pod(std::get<XMethod>(cases()).a0), prism_rtl::to_pod(std::get<XMethod>(cases()).a1), prism_rtl::to_pod(std::get<XMethod>(cases()).a2)})
        : std::holds_alternative<XBin>(cases()) ? Pod::choice("XBin", {prism_rtl::to_pod(std::get<XBin>(cases()).a0), prism_rtl::to_pod(std::get<XBin>(cases()).a1), prism_rtl::to_pod(std::get<XBin>(cases()).a2)})
        : std::holds_alternative<XUnary>(cases()) ? Pod::choice("XUnary", {prism_rtl::to_pod(std::get<XUnary>(cases()).a0), prism_rtl::to_pod(std::get<XUnary>(cases()).a1)})
        : std::holds_alternative<XCtor>(cases()) ? Pod::choice("XCtor", {prism_rtl::to_pod(std::get<XCtor>(cases()).a0), prism_rtl::to_pod(std::get<XCtor>(cases()).a1)})
        : std::holds_alternative<XRecord>(cases()) ? Pod::choice("XRecord", {prism_rtl::to_pod(std::get<XRecord>(cases()).a0), prism_rtl::to_pod(std::get<XRecord>(cases()).a1)})
        : std::holds_alternative<XTuple>(cases()) ? Pod::choice("XTuple", {prism_rtl::to_pod(std::get<XTuple>(cases()).a0)})
        : std::holds_alternative<XVec>(cases()) ? Pod::choice("XVec", {prism_rtl::to_pod(std::get<XVec>(cases()).a0)})
        : std::holds_alternative<XText>(cases()) ? Pod::choice("XText", {prism_rtl::to_pod(std::get<XText>(cases()).a0)})
        : std::holds_alternative<XFormat>(cases()) ? Pod::choice("XFormat", {prism_rtl::to_pod(std::get<XFormat>(cases()).a0)})
        : std::holds_alternative<XMatch>(cases()) ? Pod::choice("XMatch", {prism_rtl::to_pod(std::get<XMatch>(cases()).a0), prism_rtl::to_pod(std::get<XMatch>(cases()).a1), prism_rtl::to_pod(std::get<XMatch>(cases()).a2), prism_rtl::to_pod(std::get<XMatch>(cases()).a3)})
        : std::holds_alternative<XChain>(cases()) ? Pod::choice("XChain", {prism_rtl::to_pod(std::get<XChain>(cases()).a0), prism_rtl::to_pod(std::get<XChain>(cases()).a1), prism_rtl::to_pod(std::get<XChain>(cases()).a2), prism_rtl::to_pod(std::get<XChain>(cases()).a3)})
        : std::holds_alternative<XIf>(cases()) ? Pod::choice("XIf", {prism_rtl::to_pod(std::get<XIf>(cases()).a0), prism_rtl::to_pod(std::get<XIf>(cases()).a1), prism_rtl::to_pod(std::get<XIf>(cases()).a2)})
        : std::holds_alternative<XBlock>(cases()) ? Pod::choice("XBlock", {prism_rtl::to_pod(std::get<XBlock>(cases()).a0), prism_rtl::to_pod(std::get<XBlock>(cases()).a1)})
        : std::holds_alternative<XLabeled>(cases()) ? Pod::choice("XLabeled", {prism_rtl::to_pod(std::get<XLabeled>(cases()).a0), prism_rtl::to_pod(std::get<XLabeled>(cases()).a1), prism_rtl::to_pod(std::get<XLabeled>(cases()).a2), prism_rtl::to_pod(std::get<XLabeled>(cases()).a3)})
        : std::holds_alternative<XClosure>(cases()) ? Pod::choice("XClosure", {prism_rtl::to_pod(std::get<XClosure>(cases()).a0), prism_rtl::to_pod(std::get<XClosure>(cases()).a1), prism_rtl::to_pod(std::get<XClosure>(cases()).a2)})
        : std::holds_alternative<XTry>(cases()) ? Pod::choice("XTry", {prism_rtl::to_pod(std::get<XTry>(cases()).a0)})
        : std::holds_alternative<XField>(cases()) ? Pod::choice("XField", {prism_rtl::to_pod(std::get<XField>(cases()).a0), prism_rtl::to_pod(std::get<XField>(cases()).a1)})
        : std::holds_alternative<XPart>(cases()) ? Pod::choice("XPart", {prism_rtl::to_pod(std::get<XPart>(cases()).a0), prism_rtl::to_pod(std::get<XPart>(cases()).a1)})
        : std::holds_alternative<XDecode>(cases()) ? Pod::choice("XDecode", {prism_rtl::to_pod(std::get<XDecode>(cases()).a0), prism_rtl::to_pod(std::get<XDecode>(cases()).a1)})
        : std::holds_alternative<XCast>(cases()) ? Pod::choice("XCast", {prism_rtl::to_pod(std::get<XCast>(cases()).a0), prism_rtl::to_pod(std::get<XCast>(cases()).a1)})
        : std::holds_alternative<XTyped>(cases()) ? Pod::choice("XTyped", {prism_rtl::to_pod(std::get<XTyped>(cases()).a0), prism_rtl::to_pod(std::get<XTyped>(cases()).a1)})
        : Pod();
}

Result<Ex> Ex::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "XVar" && c->args.size() == 1) return Ex(XVar{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "XPath" && c->args.size() == 1) return Ex(XPath{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "XSelf" && c->args.size() == 0) return Ex(XSelf{});
        if (c->ctor == "XCx" && c->args.size() == 0) return Ex(XCx{});
        if (c->ctor == "XConst" && c->args.size() == 1) return Ex(XConst{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "XUnit" && c->args.size() == 0) return Ex(XUnit{});
        if (c->ctor == "XNone" && c->args.size() == 0) return Ex(XNone{});
        if (c->ctor == "XBool" && c->args.size() == 1) return Ex(XBool{TRY(prism_rtl::from_pod<bool>(c->args[0]))});
        if (c->ctor == "XNat" && c->args.size() == 1) return Ex(XNat{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "XInt" && c->args.size() == 1) return Ex(XInt{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "XByte" && c->args.size() == 1) return Ex(XByte{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "XFloat" && c->args.size() == 1) return Ex(XFloat{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "XIndex" && c->args.size() == 1) return Ex(XIndex{TRY(prism_rtl::from_pod<Nat>(c->args[0]))});
        if (c->ctor == "XChar" && c->args.size() == 1) return Ex(XChar{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "XStr" && c->args.size() == 1) return Ex(XStr{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "XRegex" && c->args.size() == 2) return Ex(XRegex{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Text>(c->args[1]))});
        if (c->ctor == "XReplacement" && c->args.size() == 3) return Ex(XReplacement{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Text>(c->args[1])), TRY(prism_rtl::from_pod<Text>(c->args[2]))});
        if (c->ctor == "XRef" && c->args.size() == 1) return Ex(XRef{TRY(prism_rtl::from_pod<Ex>(c->args[0]))});
        if (c->ctor == "XRefMut" && c->args.size() == 1) return Ex(XRefMut{TRY(prism_rtl::from_pod<Ex>(c->args[0]))});
        if (c->ctor == "XDeref" && c->args.size() == 1) return Ex(XDeref{TRY(prism_rtl::from_pod<Ex>(c->args[0]))});
        if (c->ctor == "XTarget" && c->args.size() == 1) return Ex(XTarget{TRY(prism_rtl::from_pod<Ex>(c->args[0]))});
        if (c->ctor == "XClone" && c->args.size() == 1) return Ex(XClone{TRY(prism_rtl::from_pod<Ex>(c->args[0]))});
        if (c->ctor == "XWeak" && c->args.size() == 1) return Ex(XWeak{TRY(prism_rtl::from_pod<Ex>(c->args[0]))});
        if (c->ctor == "XUpgrade" && c->args.size() == 1) return Ex(XUpgrade{TRY(prism_rtl::from_pod<Ex>(c->args[0]))});
        if (c->ctor == "XBreak" && c->args.size() == 2) return Ex(XBreak{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Ex>(c->args[1]))});
        if (c->ctor == "XBreakLoop" && c->args.size() == 0) return Ex(XBreakLoop{});
        if (c->ctor == "XLater" && c->args.size() == 1) return Ex(XLater{TRY(prism_rtl::from_pod<Ex>(c->args[0]))});
        if (c->ctor == "XFormatStr" && c->args.size() == 1) return Ex(XFormatStr{TRY(prism_rtl::from_pod<Array<Ex>>(c->args[0]))});
        if (c->ctor == "XIsCase" && c->args.size() == 2) return Ex(XIsCase{TRY(prism_rtl::from_pod<Ex>(c->args[0])), TRY(prism_rtl::from_pod<Array<Text>>(c->args[1]))});
        if (c->ctor == "XRefusal" && c->args.size() == 1) return Ex(XRefusal{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "XUnreachable" && c->args.size() == 0) return Ex(XUnreachable{});
        if (c->ctor == "XCall" && c->args.size() == 2) return Ex(XCall{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Array<Ex>>(c->args[1]))});
        if (c->ctor == "XApply" && c->args.size() == 2) return Ex(XApply{TRY(prism_rtl::from_pod<Ex>(c->args[0])), TRY(prism_rtl::from_pod<Array<Ex>>(c->args[1]))});
        if (c->ctor == "XMethod" && c->args.size() == 3) return Ex(XMethod{TRY(prism_rtl::from_pod<Ex>(c->args[0])), TRY(prism_rtl::from_pod<Text>(c->args[1])), TRY(prism_rtl::from_pod<Array<Ex>>(c->args[2]))});
        if (c->ctor == "XBin" && c->args.size() == 3) return Ex(XBin{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Ex>(c->args[1])), TRY(prism_rtl::from_pod<Ex>(c->args[2]))});
        if (c->ctor == "XUnary" && c->args.size() == 2) return Ex(XUnary{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Ex>(c->args[1]))});
        if (c->ctor == "XCtor" && c->args.size() == 2) return Ex(XCtor{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Array<Ex>>(c->args[1]))});
        if (c->ctor == "XRecord" && c->args.size() == 2) return Ex(XRecord{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Array<std::tuple<Text, Ex>>>(c->args[1]))});
        if (c->ctor == "XTuple" && c->args.size() == 1) return Ex(XTuple{TRY(prism_rtl::from_pod<Array<Ex>>(c->args[0]))});
        if (c->ctor == "XVec" && c->args.size() == 1) return Ex(XVec{TRY(prism_rtl::from_pod<Array<Ex>>(c->args[0]))});
        if (c->ctor == "XText" && c->args.size() == 1) return Ex(XText{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "XFormat" && c->args.size() == 1) return Ex(XFormat{TRY(prism_rtl::from_pod<Array<Ex>>(c->args[0]))});
        if (c->ctor == "XMatch" && c->args.size() == 4) return Ex(XMatch{TRY(prism_rtl::from_pod<Ex>(c->args[0])), TRY(prism_rtl::from_pod<Array<XArm>>(c->args[1])), TRY(prism_rtl::from_pod<bool>(c->args[2])), TRY(prism_rtl::from_pod<OutTy>(c->args[3]))});
        if (c->ctor == "XChain" && c->args.size() == 4) return Ex(XChain{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Ex>(c->args[1])), TRY(prism_rtl::from_pod<Array<XArm>>(c->args[2])), TRY(prism_rtl::from_pod<OutTy>(c->args[3]))});
        if (c->ctor == "XIf" && c->args.size() == 3) return Ex(XIf{TRY(prism_rtl::from_pod<Ex>(c->args[0])), TRY(prism_rtl::from_pod<Ex>(c->args[1])), TRY(prism_rtl::from_pod<Ex>(c->args[2]))});
        if (c->ctor == "XBlock" && c->args.size() == 2) return Ex(XBlock{TRY(prism_rtl::from_pod<Array<Do>>(c->args[0])), TRY(prism_rtl::from_pod<Ex>(c->args[1]))});
        if (c->ctor == "XLabeled" && c->args.size() == 4) return Ex(XLabeled{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Array<Do>>(c->args[1])), TRY(prism_rtl::from_pod<Ex>(c->args[2])), TRY(prism_rtl::from_pod<OutTy>(c->args[3]))});
        if (c->ctor == "XClosure" && c->args.size() == 3) return Ex(XClosure{TRY(prism_rtl::from_pod<bool>(c->args[0])), TRY(prism_rtl::from_pod<Array<Pa>>(c->args[1])), TRY(prism_rtl::from_pod<Ex>(c->args[2]))});
        if (c->ctor == "XTry" && c->args.size() == 1) return Ex(XTry{TRY(prism_rtl::from_pod<Ex>(c->args[0]))});
        if (c->ctor == "XField" && c->args.size() == 2) return Ex(XField{TRY(prism_rtl::from_pod<Ex>(c->args[0])), TRY(prism_rtl::from_pod<Text>(c->args[1]))});
        if (c->ctor == "XPart" && c->args.size() == 2) return Ex(XPart{TRY(prism_rtl::from_pod<Ex>(c->args[0])), TRY(prism_rtl::from_pod<Nat>(c->args[1]))});
        if (c->ctor == "XDecode" && c->args.size() == 2) return Ex(XDecode{TRY(prism_rtl::from_pod<OutTy>(c->args[0])), TRY(prism_rtl::from_pod<Ex>(c->args[1]))});
        if (c->ctor == "XCast" && c->args.size() == 2) return Ex(XCast{TRY(prism_rtl::from_pod<Ex>(c->args[0])), TRY(prism_rtl::from_pod<OutTy>(c->args[1]))});
        if (c->ctor == "XTyped" && c->args.size() == 2) return Ex(XTyped{TRY(prism_rtl::from_pod<Ex>(c->args[0])), TRY(prism_rtl::from_pod<OutTy>(c->args[1]))});
    }
    return mismatch<Ex>("a Ex", p);
}


void FnDef::show(Printer& p) const {
    p.record("FnDef", {{"name", name}, {"generics", generics}, {"params", params}, {"ret", ret}, {"body", body}, {"doc", doc}, {"public", public_}});
}

Pod FnDef::to_pod() const {
    return Pod::record("FnDef", {{"name", prism_rtl::to_pod(name)}, {"generics", prism_rtl::to_pod(generics)}, {"params", prism_rtl::to_pod(params)}, {"ret", prism_rtl::to_pod(ret)}, {"body", prism_rtl::to_pod(body)}, {"doc", prism_rtl::to_pod(doc)}, {"public", prism_rtl::to_pod(public_)}});
}

Result<FnDef> FnDef::from_pod(const Pod& whole) {
    return FnDef{.name = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .generics = TRY(prism_rtl::from_pod<Array<std::tuple<Text, Array<Text>>>>(TRY(crate::prelude::field(whole, "generics")))), .params = TRY(prism_rtl::from_pod<Array<std::tuple<Text, OutTy>>>(TRY(crate::prelude::field(whole, "params")))), .ret = TRY(prism_rtl::from_pod<OutTy>(TRY(crate::prelude::field(whole, "ret")))), .body = TRY(prism_rtl::from_pod<Ex>(TRY(crate::prelude::field(whole, "body")))), .doc = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "doc")))), .public_ = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "public"))))};
}


void ForDef::show(Printer& p) const {
    p.record("ForDef", {{"name", name}, {"pos", pos}, {"at", at}, {"key_ty", key_ty}, {"value_ty", value_ty}, {"row_node", row_node}, {"keyed", keyed}, {"source", source}, {"parent", parent}, {"passed", passed}, {"moved", moved}});
}

Pod ForDef::to_pod() const {
    return Pod::record("ForDef", {{"name", prism_rtl::to_pod(name)}, {"pos", prism_rtl::to_pod(pos)}, {"at", prism_rtl::to_pod(at)}, {"key_ty", prism_rtl::to_pod(key_ty)}, {"value_ty", prism_rtl::to_pod(value_ty)}, {"row_node", prism_rtl::to_pod(row_node)}, {"keyed", prism_rtl::to_pod(keyed)}, {"source", prism_rtl::to_pod(source)}, {"parent", prism_rtl::to_pod(parent)}, {"passed", prism_rtl::to_pod(passed)}, {"moved", prism_rtl::to_pod(moved)}});
}

Result<ForDef> ForDef::from_pod(const Pod& whole) {
    return ForDef{.name = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .pos = TRY(prism_rtl::from_pod<Pos_>(TRY(crate::prelude::field(whole, "pos")))), .at = TRY(prism_rtl::from_pod<Ex>(TRY(crate::prelude::field(whole, "at")))), .key_ty = TRY(prism_rtl::from_pod<OutTy>(TRY(crate::prelude::field(whole, "key_ty")))), .value_ty = TRY(prism_rtl::from_pod<OutTy>(TRY(crate::prelude::field(whole, "value_ty")))), .row_node = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "row_node")))), .keyed = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "keyed")))), .source = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "source")))), .parent = TRY(prism_rtl::from_pod<Ex>(TRY(crate::prelude::field(whole, "parent")))), .passed = TRY(prism_rtl::from_pod<Array<Ex>>(TRY(crate::prelude::field(whole, "passed")))), .moved = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "moved"))))};
}


void GenDef::show(Printer& p) const {
    p.record("GenDef", {{"name", name}, {"pos", pos}, {"at", at}, {"source", source}, {"value_ty", value_ty}, {"select", select}, {"transparent", transparent}, {"width", width}, {"moved", moved}});
}

Pod GenDef::to_pod() const {
    return Pod::record("GenDef", {{"name", prism_rtl::to_pod(name)}, {"pos", prism_rtl::to_pod(pos)}, {"at", prism_rtl::to_pod(at)}, {"source", prism_rtl::to_pod(source)}, {"value_ty", prism_rtl::to_pod(value_ty)}, {"select", prism_rtl::to_pod(select)}, {"transparent", prism_rtl::to_pod(transparent)}, {"width", prism_rtl::to_pod(width)}, {"moved", prism_rtl::to_pod(moved)}});
}

Result<GenDef> GenDef::from_pod(const Pod& whole) {
    return GenDef{.name = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .pos = TRY(prism_rtl::from_pod<Pos_>(TRY(crate::prelude::field(whole, "pos")))), .at = TRY(prism_rtl::from_pod<Ex>(TRY(crate::prelude::field(whole, "at")))), .source = TRY(prism_rtl::from_pod<Ex>(TRY(crate::prelude::field(whole, "source")))), .value_ty = TRY(prism_rtl::from_pod<OutTy>(TRY(crate::prelude::field(whole, "value_ty")))), .select = TRY(prism_rtl::from_pod<Ex>(TRY(crate::prelude::field(whole, "select")))), .transparent = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "transparent")))), .width = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "width")))), .moved = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "moved"))))};
}


void ImplDef::show(Printer& p) const {
    p.record("ImplDef", {{"cls", cls}, {"tr", tr}, {"head", head}, {"generics", generics}, {"methods", methods}, {"doc", doc}});
}

Pod ImplDef::to_pod() const {
    return Pod::record("ImplDef", {{"cls", prism_rtl::to_pod(cls)}, {"tr", prism_rtl::to_pod(tr)}, {"head", prism_rtl::to_pod(head)}, {"generics", prism_rtl::to_pod(generics)}, {"methods", prism_rtl::to_pod(methods)}, {"doc", prism_rtl::to_pod(doc)}});
}

Result<ImplDef> ImplDef::from_pod(const Pod& whole) {
    return ImplDef{.cls = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "cls")))), .tr = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "tr")))), .head = TRY(prism_rtl::from_pod<OutTy>(TRY(crate::prelude::field(whole, "head")))), .generics = TRY(prism_rtl::from_pod<Array<std::tuple<Text, Array<Text>>>>(TRY(crate::prelude::field(whole, "generics")))), .methods = TRY(prism_rtl::from_pod<Array<FnDef>>(TRY(crate::prelude::field(whole, "methods")))), .doc = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "doc"))))};
}


void Item::show(Printer& p) const {
    if (auto c = std::get_if<ItTrait>(&cases())) p.choice("ItTrait", {c->a0});
    else if (auto c = std::get_if<ItImpl>(&cases())) p.choice("ItImpl", {c->a0});
    else if (auto c = std::get_if<ItType>(&cases())) p.choice("ItType", {c->a0});
    else if (auto c = std::get_if<ItTag>(&cases())) p.choice("ItTag", {c->a0});
    else if (auto c = std::get_if<ItRow>(&cases())) p.choice("ItRow", {c->a0});
    else if (auto c = std::get_if<ItFn>(&cases())) p.choice("ItFn", {c->a0});
    else if (auto c = std::get_if<ItJob>(&cases())) p.choice("ItJob", {c->a0});
    else if (auto c = std::get_if<ItNode>(&cases())) p.choice("ItNode", {c->a0});
    else if (auto c = std::get_if<ItNote>(&cases())) p.choice("ItNote", {c->a0});
    else if (auto c = std::get_if<ItRefused>(&cases())) p.choice("ItRefused", {c->a0});
}

Pod Item::to_pod() const {
    return std::holds_alternative<ItTrait>(cases()) ? Pod::choice("ItTrait", {prism_rtl::to_pod(std::get<ItTrait>(cases()).a0)})
        : std::holds_alternative<ItImpl>(cases()) ? Pod::choice("ItImpl", {prism_rtl::to_pod(std::get<ItImpl>(cases()).a0)})
        : std::holds_alternative<ItType>(cases()) ? Pod::choice("ItType", {prism_rtl::to_pod(std::get<ItType>(cases()).a0)})
        : std::holds_alternative<ItTag>(cases()) ? Pod::choice("ItTag", {prism_rtl::to_pod(std::get<ItTag>(cases()).a0)})
        : std::holds_alternative<ItRow>(cases()) ? Pod::choice("ItRow", {prism_rtl::to_pod(std::get<ItRow>(cases()).a0)})
        : std::holds_alternative<ItFn>(cases()) ? Pod::choice("ItFn", {prism_rtl::to_pod(std::get<ItFn>(cases()).a0)})
        : std::holds_alternative<ItJob>(cases()) ? Pod::choice("ItJob", {prism_rtl::to_pod(std::get<ItJob>(cases()).a0)})
        : std::holds_alternative<ItNode>(cases()) ? Pod::choice("ItNode", {prism_rtl::to_pod(std::get<ItNode>(cases()).a0)})
        : std::holds_alternative<ItNote>(cases()) ? Pod::choice("ItNote", {prism_rtl::to_pod(std::get<ItNote>(cases()).a0)})
        : std::holds_alternative<ItRefused>(cases()) ? Pod::choice("ItRefused", {prism_rtl::to_pod(std::get<ItRefused>(cases()).a0)})
        : Pod();
}

Result<Item> Item::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "ItTrait" && c->args.size() == 1) return Item(ItTrait{TRY(prism_rtl::from_pod<TraitDef>(c->args[0]))});
        if (c->ctor == "ItImpl" && c->args.size() == 1) return Item(ItImpl{TRY(prism_rtl::from_pod<ImplDef>(c->args[0]))});
        if (c->ctor == "ItType" && c->args.size() == 1) return Item(ItType{TRY(prism_rtl::from_pod<TyDef>(c->args[0]))});
        if (c->ctor == "ItTag" && c->args.size() == 1) return Item(ItTag{TRY(prism_rtl::from_pod<TagDef>(c->args[0]))});
        if (c->ctor == "ItRow" && c->args.size() == 1) return Item(ItRow{TRY(prism_rtl::from_pod<RowDef>(c->args[0]))});
        if (c->ctor == "ItFn" && c->args.size() == 1) return Item(ItFn{TRY(prism_rtl::from_pod<FnDef>(c->args[0]))});
        if (c->ctor == "ItJob" && c->args.size() == 1) return Item(ItJob{TRY(prism_rtl::from_pod<JobDef>(c->args[0]))});
        if (c->ctor == "ItNode" && c->args.size() == 1) return Item(ItNode{TRY(prism_rtl::from_pod<NodeDef>(c->args[0]))});
        if (c->ctor == "ItNote" && c->args.size() == 1) return Item(ItNote{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "ItRefused" && c->args.size() == 1) return Item(ItRefused{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
    }
    return mismatch<Item>("a Item", p);
}


void JobDef::show(Printer& p) const {
    p.record("JobDef", {{"name", name}, {"start", start}, {"generics", generics}, {"fields", fields}, {"ret", ret}, {"body", body}, {"doc", doc}});
}

Pod JobDef::to_pod() const {
    return Pod::record("JobDef", {{"name", prism_rtl::to_pod(name)}, {"start", prism_rtl::to_pod(start)}, {"generics", prism_rtl::to_pod(generics)}, {"fields", prism_rtl::to_pod(fields)}, {"ret", prism_rtl::to_pod(ret)}, {"body", prism_rtl::to_pod(body)}, {"doc", prism_rtl::to_pod(doc)}});
}

Result<JobDef> JobDef::from_pod(const Pod& whole) {
    return JobDef{.name = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .start = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "start")))), .generics = TRY(prism_rtl::from_pod<Array<std::tuple<Text, Array<Text>>>>(TRY(crate::prelude::field(whole, "generics")))), .fields = TRY(prism_rtl::from_pod<Array<std::tuple<Text, OutTy>>>(TRY(crate::prelude::field(whole, "fields")))), .ret = TRY(prism_rtl::from_pod<OutTy>(TRY(crate::prelude::field(whole, "ret")))), .body = TRY(prism_rtl::from_pod<Ex>(TRY(crate::prelude::field(whole, "body")))), .doc = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "doc"))))};
}


void MethDef::show(Printer& p) const {
    p.record("MethDef", {{"name", name}, {"recv", recv}, {"params", params}, {"cx", cx_}, {"ret", ret}, {"body", body}, {"tail", tail}, {"doc", doc}});
}

Pod MethDef::to_pod() const {
    return Pod::record("MethDef", {{"name", prism_rtl::to_pod(name)}, {"recv", prism_rtl::to_pod(recv)}, {"params", prism_rtl::to_pod(params)}, {"cx", prism_rtl::to_pod(cx_)}, {"ret", prism_rtl::to_pod(ret)}, {"body", prism_rtl::to_pod(body)}, {"tail", prism_rtl::to_pod(tail)}, {"doc", prism_rtl::to_pod(doc)}});
}

Result<MethDef> MethDef::from_pod(const Pod& whole) {
    return MethDef{.name = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .recv = TRY(prism_rtl::from_pod<Recv>(TRY(crate::prelude::field(whole, "recv")))), .params = TRY(prism_rtl::from_pod<Array<std::tuple<Text, OutTy>>>(TRY(crate::prelude::field(whole, "params")))), .cx_ = TRY(prism_rtl::from_pod<CxArg>(TRY(crate::prelude::field(whole, "cx")))), .ret = TRY(prism_rtl::from_pod<OutTy>(TRY(crate::prelude::field(whole, "ret")))), .body = TRY(prism_rtl::from_pod<Array<Do>>(TRY(crate::prelude::field(whole, "body")))), .tail = TRY(prism_rtl::from_pod<Ex>(TRY(crate::prelude::field(whole, "tail")))), .doc = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "doc"))))};
}


void ModDef::show(Printer& p) const {
    p.record("ModDef", {{"name", name}, {"prism", prism}, {"path", path_}, {"uses", uses}, {"complete", complete}, {"declared", declared}, {"types_with", types_with}, {"items", items}});
}

Pod ModDef::to_pod() const {
    return Pod::record("ModDef", {{"name", prism_rtl::to_pod(name)}, {"prism", prism_rtl::to_pod(prism)}, {"path", prism_rtl::to_pod(path_)}, {"uses", prism_rtl::to_pod(uses)}, {"complete", prism_rtl::to_pod(complete)}, {"declared", prism_rtl::to_pod(declared)}, {"types_with", prism_rtl::to_pod(types_with)}, {"items", prism_rtl::to_pod(items)}});
}

Result<ModDef> ModDef::from_pod(const Pod& whole) {
    return ModDef{.name = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .prism = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "prism")))), .path_ = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "path")))), .uses = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "uses")))), .complete = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "complete")))), .declared = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "declared")))), .types_with = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "types_with")))), .items = TRY(prism_rtl::from_pod<Array<Item>>(TRY(crate::prelude::field(whole, "items"))))};
}


void Model::show(Printer& p) const {
    p.record("Model", {{"name", name}, {"mods", mods}, {"programs", programs}, {"root", root}, {"checks", checks}, {"elem", elem}, {"answer", answer}, {"elem_complete", elem_complete}, {"elem_declared", elem_declared}, {"scripts", scripts}, {"notes", notes}});
}

Pod Model::to_pod() const {
    return Pod::record("Model", {{"name", prism_rtl::to_pod(name)}, {"mods", prism_rtl::to_pod(mods)}, {"programs", prism_rtl::to_pod(programs)}, {"root", prism_rtl::to_pod(root)}, {"checks", prism_rtl::to_pod(checks)}, {"elem", prism_rtl::to_pod(elem)}, {"answer", prism_rtl::to_pod(answer)}, {"elem_complete", prism_rtl::to_pod(elem_complete)}, {"elem_declared", prism_rtl::to_pod(elem_declared)}, {"scripts", prism_rtl::to_pod(scripts)}, {"notes", prism_rtl::to_pod(notes)}});
}

Result<Model> Model::from_pod(const Pod& whole) {
    return Model{.name = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .mods = TRY(prism_rtl::from_pod<Array<ModDef>>(TRY(crate::prelude::field(whole, "mods")))), .programs = TRY(prism_rtl::from_pod<Array<ProgDef>>(TRY(crate::prelude::field(whole, "programs")))), .root = TRY(prism_rtl::from_pod<std::optional<ProgDef>>(TRY(crate::prelude::field(whole, "root")))), .checks = TRY(prism_rtl::from_pod<Array<CheckDef>>(TRY(crate::prelude::field(whole, "checks")))), .elem = TRY(prism_rtl::from_pod<RowDef>(TRY(crate::prelude::field(whole, "elem")))), .answer = TRY(prism_rtl::from_pod<AnswerDef>(TRY(crate::prelude::field(whole, "answer")))), .elem_complete = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "elem_complete")))), .elem_declared = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "elem_declared")))), .scripts = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "scripts")))), .notes = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "notes"))))};
}


void NodeDef::show(Printer& p) const {
    p.record("NodeDef", {{"name", name}, {"prism", prism}, {"doc", doc}, {"params", params}, {"fields", fields}, {"consts", consts}, {"lets", lets}, {"inits", inits}, {"build", build}, {"fallible", fallible}, {"methods", methods}, {"answers", answers}, {"hooks", hooks}, {"builders", builders}, {"wakes", wakes}, {"children", children}, {"gens", gens}, {"subs", subs}, {"top", top}, {"row_kind", row_kind}, {"hosted", hosted}});
}

Pod NodeDef::to_pod() const {
    return Pod::record("NodeDef", {{"name", prism_rtl::to_pod(name)}, {"prism", prism_rtl::to_pod(prism)}, {"doc", prism_rtl::to_pod(doc)}, {"params", prism_rtl::to_pod(params)}, {"fields", prism_rtl::to_pod(fields)}, {"consts", prism_rtl::to_pod(consts)}, {"lets", prism_rtl::to_pod(lets)}, {"inits", prism_rtl::to_pod(inits)}, {"build", prism_rtl::to_pod(build)}, {"fallible", prism_rtl::to_pod(fallible)}, {"methods", prism_rtl::to_pod(methods)}, {"answers", prism_rtl::to_pod(answers)}, {"hooks", prism_rtl::to_pod(hooks)}, {"builders", prism_rtl::to_pod(builders)}, {"wakes", prism_rtl::to_pod(wakes)}, {"children", prism_rtl::to_pod(children)}, {"gens", prism_rtl::to_pod(gens)}, {"subs", prism_rtl::to_pod(subs)}, {"top", prism_rtl::to_pod(top)}, {"row_kind", prism_rtl::to_pod(row_kind)}, {"hosted", prism_rtl::to_pod(hosted)}});
}

Result<NodeDef> NodeDef::from_pod(const Pod& whole) {
    return NodeDef{.name = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .prism = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "prism")))), .doc = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "doc")))), .params = TRY(prism_rtl::from_pod<Array<std::tuple<Text, OutTy>>>(TRY(crate::prelude::field(whole, "params")))), .fields = TRY(prism_rtl::from_pod<Array<std::tuple<Text, OutTy, Text>>>(TRY(crate::prelude::field(whole, "fields")))), .consts = TRY(prism_rtl::from_pod<Array<std::tuple<Text, Nat, Text>>>(TRY(crate::prelude::field(whole, "consts")))), .lets = TRY(prism_rtl::from_pod<Array<Do>>(TRY(crate::prelude::field(whole, "lets")))), .inits = TRY(prism_rtl::from_pod<Array<std::tuple<Text, Ex>>>(TRY(crate::prelude::field(whole, "inits")))), .build = TRY(prism_rtl::from_pod<Array<Do>>(TRY(crate::prelude::field(whole, "build")))), .fallible = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "fallible")))), .methods = TRY(prism_rtl::from_pod<Array<MethDef>>(TRY(crate::prelude::field(whole, "methods")))), .answers = TRY(prism_rtl::from_pod<Array<std::tuple<Pa, Ex>>>(TRY(crate::prelude::field(whole, "answers")))), .hooks = TRY(prism_rtl::from_pod<Array<std::tuple<Text, Array<Do>>>>(TRY(crate::prelude::field(whole, "hooks")))), .builders = TRY(prism_rtl::from_pod<Array<ForDef>>(TRY(crate::prelude::field(whole, "builders")))), .wakes = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "wakes")))), .children = TRY(prism_rtl::from_pod<Array<NodeDef>>(TRY(crate::prelude::field(whole, "children")))), .gens = TRY(prism_rtl::from_pod<Array<GenDef>>(TRY(crate::prelude::field(whole, "gens")))), .subs = TRY(prism_rtl::from_pod<Array<std::tuple<Text, Text, OutTy>>>(TRY(crate::prelude::field(whole, "subs")))), .top = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "top")))), .row_kind = TRY(prism_rtl::from_pod<RowKind>(TRY(crate::prelude::field(whole, "row_kind")))), .hosted = TRY(prism_rtl::from_pod<Array<MethDef>>(TRY(crate::prelude::field(whole, "hosted"))))};
}


void OutTy::show(Printer& p) const {
    if (auto c = std::get_if<OutNat>(&cases())) p.choice("OutNat", {});
    else if (auto c = std::get_if<OutInt>(&cases())) p.choice("OutInt", {});
    else if (auto c = std::get_if<OutU8>(&cases())) p.choice("OutU8", {});
    else if (auto c = std::get_if<OutFloat>(&cases())) p.choice("OutFloat", {});
    else if (auto c = std::get_if<OutBool>(&cases())) p.choice("OutBool", {});
    else if (auto c = std::get_if<OutChar>(&cases())) p.choice("OutChar", {});
    else if (auto c = std::get_if<OutText>(&cases())) p.choice("OutText", {});
    else if (auto c = std::get_if<OutCursor>(&cases())) p.choice("OutCursor", {});
    else if (auto c = std::get_if<OutRegex>(&cases())) p.choice("OutRegex", {});
    else if (auto c = std::get_if<OutReplacement>(&cases())) p.choice("OutReplacement", {});
    else if (auto c = std::get_if<OutUnit>(&cases())) p.choice("OutUnit", {});
    else if (auto c = std::get_if<OutPath>(&cases())) p.choice("OutPath", {});
    else if (auto c = std::get_if<OutDuration>(&cases())) p.choice("OutDuration", {});
    else if (auto c = std::get_if<OutError>(&cases())) p.choice("OutError", {});
    else if (auto c = std::get_if<OutNamed>(&cases())) p.choice("OutNamed", {c->a0, c->a1});
    else if (auto c = std::get_if<OutOpt>(&cases())) p.choice("OutOpt", {c->a0});
    else if (auto c = std::get_if<OutRes>(&cases())) p.choice("OutRes", {c->a0});
    else if (auto c = std::get_if<OutTuple>(&cases())) p.choice("OutTuple", {c->a0});
    else if (auto c = std::get_if<OutArray>(&cases())) p.choice("OutArray", {c->a0});
    else if (auto c = std::get_if<OutMap>(&cases())) p.choice("OutMap", {c->a0, c->a1});
    else if (auto c = std::get_if<OutFn>(&cases())) p.choice("OutFn", {c->a0, c->a1});
    else if (auto c = std::get_if<OutJobFn>(&cases())) p.choice("OutJobFn", {c->a0, c->a1});
    else if (auto c = std::get_if<OutJob>(&cases())) p.choice("OutJob", {c->a0});
    else if (auto c = std::get_if<OutEvent>(&cases())) p.choice("OutEvent", {c->a0});
    else if (auto c = std::get_if<OutDyn>(&cases())) p.choice("OutDyn", {c->a0});
    else if (auto c = std::get_if<OutGen>(&cases())) p.choice("OutGen", {c->a0});
    else if (auto c = std::get_if<OutRc>(&cases())) p.choice("OutRc", {c->a0});
    else if (auto c = std::get_if<OutRef>(&cases())) p.choice("OutRef", {c->a0});
    else if (auto c = std::get_if<OutPod>(&cases())) p.choice("OutPod", {});
    else if (auto c = std::get_if<OutShowAny>(&cases())) p.choice("OutShowAny", {});
    else if (auto c = std::get_if<OutHold>(&cases())) p.choice("OutHold", {c->a0});
    else if (auto c = std::get_if<OutStamped>(&cases())) p.choice("OutStamped", {c->a0});
    else if (auto c = std::get_if<OutSnapshot>(&cases())) p.choice("OutSnapshot", {c->a0});
    else if (auto c = std::get_if<OutDefer>(&cases())) p.choice("OutDefer", {c->a0});
    else if (auto c = std::get_if<OutWeak>(&cases())) p.choice("OutWeak", {c->a0});
    else if (auto c = std::get_if<OutCell>(&cases())) p.choice("OutCell", {c->a0});
    else if (auto c = std::get_if<OutWakes>(&cases())) p.choice("OutWakes", {});
    else if (auto c = std::get_if<OutCount>(&cases())) p.choice("OutCount", {});
    else if (auto c = std::get_if<OutObj>(&cases())) p.choice("OutObj", {c->a0});
    else if (auto c = std::get_if<OutSlice>(&cases())) p.choice("OutSlice", {c->a0});
    else if (auto c = std::get_if<OutPort>(&cases())) p.choice("OutPort", {c->a0});
    else if (auto c = std::get_if<OutLive>(&cases())) p.choice("OutLive", {c->a0});
    else if (auto c = std::get_if<OutQuantified>(&cases())) p.choice("OutQuantified", {c->a0});
    else if (auto c = std::get_if<OutUnknown>(&cases())) p.choice("OutUnknown", {c->a0});
}

Pod OutTy::to_pod() const {
    return std::holds_alternative<OutNat>(cases()) ? Pod::choice("OutNat", {})
        : std::holds_alternative<OutInt>(cases()) ? Pod::choice("OutInt", {})
        : std::holds_alternative<OutU8>(cases()) ? Pod::choice("OutU8", {})
        : std::holds_alternative<OutFloat>(cases()) ? Pod::choice("OutFloat", {})
        : std::holds_alternative<OutBool>(cases()) ? Pod::choice("OutBool", {})
        : std::holds_alternative<OutChar>(cases()) ? Pod::choice("OutChar", {})
        : std::holds_alternative<OutText>(cases()) ? Pod::choice("OutText", {})
        : std::holds_alternative<OutCursor>(cases()) ? Pod::choice("OutCursor", {})
        : std::holds_alternative<OutRegex>(cases()) ? Pod::choice("OutRegex", {})
        : std::holds_alternative<OutReplacement>(cases()) ? Pod::choice("OutReplacement", {})
        : std::holds_alternative<OutUnit>(cases()) ? Pod::choice("OutUnit", {})
        : std::holds_alternative<OutPath>(cases()) ? Pod::choice("OutPath", {})
        : std::holds_alternative<OutDuration>(cases()) ? Pod::choice("OutDuration", {})
        : std::holds_alternative<OutError>(cases()) ? Pod::choice("OutError", {})
        : std::holds_alternative<OutNamed>(cases()) ? Pod::choice("OutNamed", {prism_rtl::to_pod(std::get<OutNamed>(cases()).a0), prism_rtl::to_pod(std::get<OutNamed>(cases()).a1)})
        : std::holds_alternative<OutOpt>(cases()) ? Pod::choice("OutOpt", {prism_rtl::to_pod(std::get<OutOpt>(cases()).a0)})
        : std::holds_alternative<OutRes>(cases()) ? Pod::choice("OutRes", {prism_rtl::to_pod(std::get<OutRes>(cases()).a0)})
        : std::holds_alternative<OutTuple>(cases()) ? Pod::choice("OutTuple", {prism_rtl::to_pod(std::get<OutTuple>(cases()).a0)})
        : std::holds_alternative<OutArray>(cases()) ? Pod::choice("OutArray", {prism_rtl::to_pod(std::get<OutArray>(cases()).a0)})
        : std::holds_alternative<OutMap>(cases()) ? Pod::choice("OutMap", {prism_rtl::to_pod(std::get<OutMap>(cases()).a0), prism_rtl::to_pod(std::get<OutMap>(cases()).a1)})
        : std::holds_alternative<OutFn>(cases()) ? Pod::choice("OutFn", {prism_rtl::to_pod(std::get<OutFn>(cases()).a0), prism_rtl::to_pod(std::get<OutFn>(cases()).a1)})
        : std::holds_alternative<OutJobFn>(cases()) ? Pod::choice("OutJobFn", {prism_rtl::to_pod(std::get<OutJobFn>(cases()).a0), prism_rtl::to_pod(std::get<OutJobFn>(cases()).a1)})
        : std::holds_alternative<OutJob>(cases()) ? Pod::choice("OutJob", {prism_rtl::to_pod(std::get<OutJob>(cases()).a0)})
        : std::holds_alternative<OutEvent>(cases()) ? Pod::choice("OutEvent", {prism_rtl::to_pod(std::get<OutEvent>(cases()).a0)})
        : std::holds_alternative<OutDyn>(cases()) ? Pod::choice("OutDyn", {prism_rtl::to_pod(std::get<OutDyn>(cases()).a0)})
        : std::holds_alternative<OutGen>(cases()) ? Pod::choice("OutGen", {prism_rtl::to_pod(std::get<OutGen>(cases()).a0)})
        : std::holds_alternative<OutRc>(cases()) ? Pod::choice("OutRc", {prism_rtl::to_pod(std::get<OutRc>(cases()).a0)})
        : std::holds_alternative<OutRef>(cases()) ? Pod::choice("OutRef", {prism_rtl::to_pod(std::get<OutRef>(cases()).a0)})
        : std::holds_alternative<OutPod>(cases()) ? Pod::choice("OutPod", {})
        : std::holds_alternative<OutShowAny>(cases()) ? Pod::choice("OutShowAny", {})
        : std::holds_alternative<OutHold>(cases()) ? Pod::choice("OutHold", {prism_rtl::to_pod(std::get<OutHold>(cases()).a0)})
        : std::holds_alternative<OutStamped>(cases()) ? Pod::choice("OutStamped", {prism_rtl::to_pod(std::get<OutStamped>(cases()).a0)})
        : std::holds_alternative<OutSnapshot>(cases()) ? Pod::choice("OutSnapshot", {prism_rtl::to_pod(std::get<OutSnapshot>(cases()).a0)})
        : std::holds_alternative<OutDefer>(cases()) ? Pod::choice("OutDefer", {prism_rtl::to_pod(std::get<OutDefer>(cases()).a0)})
        : std::holds_alternative<OutWeak>(cases()) ? Pod::choice("OutWeak", {prism_rtl::to_pod(std::get<OutWeak>(cases()).a0)})
        : std::holds_alternative<OutCell>(cases()) ? Pod::choice("OutCell", {prism_rtl::to_pod(std::get<OutCell>(cases()).a0)})
        : std::holds_alternative<OutWakes>(cases()) ? Pod::choice("OutWakes", {})
        : std::holds_alternative<OutCount>(cases()) ? Pod::choice("OutCount", {})
        : std::holds_alternative<OutObj>(cases()) ? Pod::choice("OutObj", {prism_rtl::to_pod(std::get<OutObj>(cases()).a0)})
        : std::holds_alternative<OutSlice>(cases()) ? Pod::choice("OutSlice", {prism_rtl::to_pod(std::get<OutSlice>(cases()).a0)})
        : std::holds_alternative<OutPort>(cases()) ? Pod::choice("OutPort", {prism_rtl::to_pod(std::get<OutPort>(cases()).a0)})
        : std::holds_alternative<OutLive>(cases()) ? Pod::choice("OutLive", {prism_rtl::to_pod(std::get<OutLive>(cases()).a0)})
        : std::holds_alternative<OutQuantified>(cases()) ? Pod::choice("OutQuantified", {prism_rtl::to_pod(std::get<OutQuantified>(cases()).a0)})
        : std::holds_alternative<OutUnknown>(cases()) ? Pod::choice("OutUnknown", {prism_rtl::to_pod(std::get<OutUnknown>(cases()).a0)})
        : Pod();
}

Result<OutTy> OutTy::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "OutNat" && c->args.size() == 0) return OutTy(OutNat{});
        if (c->ctor == "OutInt" && c->args.size() == 0) return OutTy(OutInt{});
        if (c->ctor == "OutU8" && c->args.size() == 0) return OutTy(OutU8{});
        if (c->ctor == "OutFloat" && c->args.size() == 0) return OutTy(OutFloat{});
        if (c->ctor == "OutBool" && c->args.size() == 0) return OutTy(OutBool{});
        if (c->ctor == "OutChar" && c->args.size() == 0) return OutTy(OutChar{});
        if (c->ctor == "OutText" && c->args.size() == 0) return OutTy(OutText{});
        if (c->ctor == "OutCursor" && c->args.size() == 0) return OutTy(OutCursor{});
        if (c->ctor == "OutRegex" && c->args.size() == 0) return OutTy(OutRegex{});
        if (c->ctor == "OutReplacement" && c->args.size() == 0) return OutTy(OutReplacement{});
        if (c->ctor == "OutUnit" && c->args.size() == 0) return OutTy(OutUnit{});
        if (c->ctor == "OutPath" && c->args.size() == 0) return OutTy(OutPath{});
        if (c->ctor == "OutDuration" && c->args.size() == 0) return OutTy(OutDuration{});
        if (c->ctor == "OutError" && c->args.size() == 0) return OutTy(OutError{});
        if (c->ctor == "OutNamed" && c->args.size() == 2) return OutTy(OutNamed{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Array<OutTy>>(c->args[1]))});
        if (c->ctor == "OutOpt" && c->args.size() == 1) return OutTy(OutOpt{TRY(prism_rtl::from_pod<OutTy>(c->args[0]))});
        if (c->ctor == "OutRes" && c->args.size() == 1) return OutTy(OutRes{TRY(prism_rtl::from_pod<OutTy>(c->args[0]))});
        if (c->ctor == "OutTuple" && c->args.size() == 1) return OutTy(OutTuple{TRY(prism_rtl::from_pod<Array<OutTy>>(c->args[0]))});
        if (c->ctor == "OutArray" && c->args.size() == 1) return OutTy(OutArray{TRY(prism_rtl::from_pod<OutTy>(c->args[0]))});
        if (c->ctor == "OutMap" && c->args.size() == 2) return OutTy(OutMap{TRY(prism_rtl::from_pod<OutTy>(c->args[0])), TRY(prism_rtl::from_pod<OutTy>(c->args[1]))});
        if (c->ctor == "OutFn" && c->args.size() == 2) return OutTy(OutFn{TRY(prism_rtl::from_pod<Array<OutTy>>(c->args[0])), TRY(prism_rtl::from_pod<OutTy>(c->args[1]))});
        if (c->ctor == "OutJobFn" && c->args.size() == 2) return OutTy(OutJobFn{TRY(prism_rtl::from_pod<OutTy>(c->args[0])), TRY(prism_rtl::from_pod<OutTy>(c->args[1]))});
        if (c->ctor == "OutJob" && c->args.size() == 1) return OutTy(OutJob{TRY(prism_rtl::from_pod<OutTy>(c->args[0]))});
        if (c->ctor == "OutEvent" && c->args.size() == 1) return OutTy(OutEvent{TRY(prism_rtl::from_pod<OutTy>(c->args[0]))});
        if (c->ctor == "OutDyn" && c->args.size() == 1) return OutTy(OutDyn{TRY(prism_rtl::from_pod<OutTy>(c->args[0]))});
        if (c->ctor == "OutGen" && c->args.size() == 1) return OutTy(OutGen{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "OutRc" && c->args.size() == 1) return OutTy(OutRc{TRY(prism_rtl::from_pod<OutTy>(c->args[0]))});
        if (c->ctor == "OutRef" && c->args.size() == 1) return OutTy(OutRef{TRY(prism_rtl::from_pod<OutTy>(c->args[0]))});
        if (c->ctor == "OutPod" && c->args.size() == 0) return OutTy(OutPod{});
        if (c->ctor == "OutShowAny" && c->args.size() == 0) return OutTy(OutShowAny{});
        if (c->ctor == "OutHold" && c->args.size() == 1) return OutTy(OutHold{TRY(prism_rtl::from_pod<OutTy>(c->args[0]))});
        if (c->ctor == "OutStamped" && c->args.size() == 1) return OutTy(OutStamped{TRY(prism_rtl::from_pod<OutTy>(c->args[0]))});
        if (c->ctor == "OutSnapshot" && c->args.size() == 1) return OutTy(OutSnapshot{TRY(prism_rtl::from_pod<OutTy>(c->args[0]))});
        if (c->ctor == "OutDefer" && c->args.size() == 1) return OutTy(OutDefer{TRY(prism_rtl::from_pod<OutTy>(c->args[0]))});
        if (c->ctor == "OutWeak" && c->args.size() == 1) return OutTy(OutWeak{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "OutCell" && c->args.size() == 1) return OutTy(OutCell{TRY(prism_rtl::from_pod<OutTy>(c->args[0]))});
        if (c->ctor == "OutWakes" && c->args.size() == 0) return OutTy(OutWakes{});
        if (c->ctor == "OutCount" && c->args.size() == 0) return OutTy(OutCount{});
        if (c->ctor == "OutObj" && c->args.size() == 1) return OutTy(OutObj{TRY(prism_rtl::from_pod<OutTy>(c->args[0]))});
        if (c->ctor == "OutSlice" && c->args.size() == 1) return OutTy(OutSlice{TRY(prism_rtl::from_pod<OutTy>(c->args[0]))});
        if (c->ctor == "OutPort" && c->args.size() == 1) return OutTy(OutPort{TRY(prism_rtl::from_pod<OutTy>(c->args[0]))});
        if (c->ctor == "OutLive" && c->args.size() == 1) return OutTy(OutLive{TRY(prism_rtl::from_pod<OutTy>(c->args[0]))});
        if (c->ctor == "OutQuantified" && c->args.size() == 1) return OutTy(OutQuantified{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "OutUnknown" && c->args.size() == 1) return OutTy(OutUnknown{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
    }
    return mismatch<OutTy>("a OutTy", p);
}


void Pa::show(Printer& p) const {
    if (auto c = std::get_if<PaWild>(&cases())) p.choice("PaWild", {});
    else if (auto c = std::get_if<PaBind>(&cases())) p.choice("PaBind", {c->a0});
    else if (auto c = std::get_if<PaMut>(&cases())) p.choice("PaMut", {c->a0});
    else if (auto c = std::get_if<PaCtor>(&cases())) p.choice("PaCtor", {c->a0, c->a1});
    else if (auto c = std::get_if<PaUnit>(&cases())) p.choice("PaUnit", {c->a0});
    else if (auto c = std::get_if<PaRecord>(&cases())) p.choice("PaRecord", {c->a0, c->a1, c->a2});
    else if (auto c = std::get_if<PaTuple>(&cases())) p.choice("PaTuple", {c->a0});
    else if (auto c = std::get_if<PaChar>(&cases())) p.choice("PaChar", {c->a0});
    else if (auto c = std::get_if<PaBool>(&cases())) p.choice("PaBool", {c->a0});
    else if (auto c = std::get_if<PaIndex>(&cases())) p.choice("PaIndex", {c->a0});
    else if (auto c = std::get_if<PaConst>(&cases())) p.choice("PaConst", {c->a0});
    else if (auto c = std::get_if<PaSlice>(&cases())) p.choice("PaSlice", {c->a0});
    else if (auto c = std::get_if<PaRest>(&cases())) p.choice("PaRest", {c->a0});
    else if (auto c = std::get_if<PaTyped>(&cases())) p.choice("PaTyped", {c->a0, c->a1});
}

Pod Pa::to_pod() const {
    return std::holds_alternative<PaWild>(cases()) ? Pod::choice("PaWild", {})
        : std::holds_alternative<PaBind>(cases()) ? Pod::choice("PaBind", {prism_rtl::to_pod(std::get<PaBind>(cases()).a0)})
        : std::holds_alternative<PaMut>(cases()) ? Pod::choice("PaMut", {prism_rtl::to_pod(std::get<PaMut>(cases()).a0)})
        : std::holds_alternative<PaCtor>(cases()) ? Pod::choice("PaCtor", {prism_rtl::to_pod(std::get<PaCtor>(cases()).a0), prism_rtl::to_pod(std::get<PaCtor>(cases()).a1)})
        : std::holds_alternative<PaUnit>(cases()) ? Pod::choice("PaUnit", {prism_rtl::to_pod(std::get<PaUnit>(cases()).a0)})
        : std::holds_alternative<PaRecord>(cases()) ? Pod::choice("PaRecord", {prism_rtl::to_pod(std::get<PaRecord>(cases()).a0), prism_rtl::to_pod(std::get<PaRecord>(cases()).a1), prism_rtl::to_pod(std::get<PaRecord>(cases()).a2)})
        : std::holds_alternative<PaTuple>(cases()) ? Pod::choice("PaTuple", {prism_rtl::to_pod(std::get<PaTuple>(cases()).a0)})
        : std::holds_alternative<PaChar>(cases()) ? Pod::choice("PaChar", {prism_rtl::to_pod(std::get<PaChar>(cases()).a0)})
        : std::holds_alternative<PaBool>(cases()) ? Pod::choice("PaBool", {prism_rtl::to_pod(std::get<PaBool>(cases()).a0)})
        : std::holds_alternative<PaIndex>(cases()) ? Pod::choice("PaIndex", {prism_rtl::to_pod(std::get<PaIndex>(cases()).a0)})
        : std::holds_alternative<PaConst>(cases()) ? Pod::choice("PaConst", {prism_rtl::to_pod(std::get<PaConst>(cases()).a0)})
        : std::holds_alternative<PaSlice>(cases()) ? Pod::choice("PaSlice", {prism_rtl::to_pod(std::get<PaSlice>(cases()).a0)})
        : std::holds_alternative<PaRest>(cases()) ? Pod::choice("PaRest", {prism_rtl::to_pod(std::get<PaRest>(cases()).a0)})
        : std::holds_alternative<PaTyped>(cases()) ? Pod::choice("PaTyped", {prism_rtl::to_pod(std::get<PaTyped>(cases()).a0), prism_rtl::to_pod(std::get<PaTyped>(cases()).a1)})
        : Pod();
}

Result<Pa> Pa::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "PaWild" && c->args.size() == 0) return Pa(PaWild{});
        if (c->ctor == "PaBind" && c->args.size() == 1) return Pa(PaBind{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "PaMut" && c->args.size() == 1) return Pa(PaMut{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "PaCtor" && c->args.size() == 2) return Pa(PaCtor{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Array<Pa>>(c->args[1]))});
        if (c->ctor == "PaUnit" && c->args.size() == 1) return Pa(PaUnit{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "PaRecord" && c->args.size() == 3) return Pa(PaRecord{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Array<std::tuple<Text, Pa>>>(c->args[1])), TRY(prism_rtl::from_pod<bool>(c->args[2]))});
        if (c->ctor == "PaTuple" && c->args.size() == 1) return Pa(PaTuple{TRY(prism_rtl::from_pod<Array<Pa>>(c->args[0]))});
        if (c->ctor == "PaChar" && c->args.size() == 1) return Pa(PaChar{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "PaBool" && c->args.size() == 1) return Pa(PaBool{TRY(prism_rtl::from_pod<bool>(c->args[0]))});
        if (c->ctor == "PaIndex" && c->args.size() == 1) return Pa(PaIndex{TRY(prism_rtl::from_pod<Nat>(c->args[0]))});
        if (c->ctor == "PaConst" && c->args.size() == 1) return Pa(PaConst{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "PaSlice" && c->args.size() == 1) return Pa(PaSlice{TRY(prism_rtl::from_pod<Array<Pa>>(c->args[0]))});
        if (c->ctor == "PaRest" && c->args.size() == 1) return Pa(PaRest{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "PaTyped" && c->args.size() == 2) return Pa(PaTyped{TRY(prism_rtl::from_pod<Pa>(c->args[0])), TRY(prism_rtl::from_pod<OutTy>(c->args[1]))});
    }
    return mismatch<Pa>("a Pa", p);
}


void Pos_::show(Printer& p) const {
    p.record("Pos", {{"scope", scope}, {"at", at}});
}

Pod Pos_::to_pod() const {
    return Pod::record("Pos", {{"scope", prism_rtl::to_pod(scope)}, {"at", prism_rtl::to_pod(at)}});
}

Result<Pos_> Pos_::from_pod(const Pod& whole) {
    return Pos_{.scope = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "scope")))), .at = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "at"))))};
}


void ProgDef::show(Printer& p) const {
    p.record("ProgDef", {{"name", name}, {"prism", prism}, {"node", node_}, {"params", params}, {"fallible", fallible}, {"world", world}});
}

Pod ProgDef::to_pod() const {
    return Pod::record("ProgDef", {{"name", prism_rtl::to_pod(name)}, {"prism", prism_rtl::to_pod(prism)}, {"node", prism_rtl::to_pod(node_)}, {"params", prism_rtl::to_pod(params)}, {"fallible", prism_rtl::to_pod(fallible)}, {"world", prism_rtl::to_pod(world)}});
}

Result<ProgDef> ProgDef::from_pod(const Pod& whole) {
    return ProgDef{.name = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .prism = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "prism")))), .node_ = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "node")))), .params = TRY(prism_rtl::from_pod<Array<std::tuple<Text, OutTy>>>(TRY(crate::prelude::field(whole, "params")))), .fallible = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "fallible")))), .world = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "world"))))};
}


void Recv::show(Printer& p) const {
    if (auto c = std::get_if<RecvRc>(&cases())) p.choice("RecvRc", {});
    else if (auto c = std::get_if<RecvRef>(&cases())) p.choice("RecvRef", {});
    else if (auto c = std::get_if<RecvOwned>(&cases())) p.choice("RecvOwned", {});
}

Pod Recv::to_pod() const {
    return std::holds_alternative<RecvRc>(cases()) ? Pod::choice("RecvRc", {})
        : std::holds_alternative<RecvRef>(cases()) ? Pod::choice("RecvRef", {})
        : std::holds_alternative<RecvOwned>(cases()) ? Pod::choice("RecvOwned", {})
        : Pod();
}

Result<Recv> Recv::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "RecvRc" && c->args.size() == 0) return Recv(RecvRc{});
        if (c->ctor == "RecvRef" && c->args.size() == 0) return Recv(RecvRef{});
        if (c->ctor == "RecvOwned" && c->args.size() == 0) return Recv(RecvOwned{});
    }
    return mismatch<Recv>("a Recv", p);
}


void RowDef::show(Printer& p) const {
    p.record("RowDef", {{"name", name}, {"prism", prism}, {"cases", cases_}, {"pod", pod}, {"doc", doc}, {"eq", eq}, {"level", level}, {"deep", deep}});
}

Pod RowDef::to_pod() const {
    return Pod::record("RowDef", {{"name", prism_rtl::to_pod(name)}, {"prism", prism_rtl::to_pod(prism)}, {"cases", prism_rtl::to_pod(cases_)}, {"pod", prism_rtl::to_pod(pod)}, {"doc", prism_rtl::to_pod(doc)}, {"eq", prism_rtl::to_pod(eq)}, {"level", prism_rtl::to_pod(level)}, {"deep", prism_rtl::to_pod(deep)}});
}

Result<RowDef> RowDef::from_pod(const Pod& whole) {
    return RowDef{.name = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .prism = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "prism")))), .cases_ = TRY(prism_rtl::from_pod<Array<std::tuple<Text, Text>>>(TRY(crate::prelude::field(whole, "cases")))), .pod = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "pod")))), .doc = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "doc")))), .eq = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "eq")))), .level = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "level")))), .deep = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "deep"))))};
}


void RowKind::show(Printer& p) const {
    if (auto c = std::get_if<ForRow>(&cases())) p.choice("ForRow", {});
    else if (auto c = std::get_if<GenerationRow>(&cases())) p.choice("GenerationRow", {});
    else if (auto c = std::get_if<NotARow>(&cases())) p.choice("NotARow", {});
}

Pod RowKind::to_pod() const {
    return std::holds_alternative<ForRow>(cases()) ? Pod::choice("ForRow", {})
        : std::holds_alternative<GenerationRow>(cases()) ? Pod::choice("GenerationRow", {})
        : std::holds_alternative<NotARow>(cases()) ? Pod::choice("NotARow", {})
        : Pod();
}

Result<RowKind> RowKind::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "ForRow" && c->args.size() == 0) return RowKind(ForRow{});
        if (c->ctor == "GenerationRow" && c->args.size() == 0) return RowKind(GenerationRow{});
        if (c->ctor == "NotARow" && c->args.size() == 0) return RowKind(NotARow{});
    }
    return mismatch<RowKind>("a RowKind", p);
}


void Shown::show(Printer& p) const {
    if (auto c = std::get_if<ShownOwn>(&cases())) p.choice("ShownOwn", {});
    else if (auto c = std::get_if<ShownDerived>(&cases())) p.choice("ShownDerived", {});
    else if (auto c = std::get_if<NotShown>(&cases())) p.choice("NotShown", {});
}

Pod Shown::to_pod() const {
    return std::holds_alternative<ShownOwn>(cases()) ? Pod::choice("ShownOwn", {})
        : std::holds_alternative<ShownDerived>(cases()) ? Pod::choice("ShownDerived", {})
        : std::holds_alternative<NotShown>(cases()) ? Pod::choice("NotShown", {})
        : Pod();
}

Result<Shown> Shown::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "ShownOwn" && c->args.size() == 0) return Shown(ShownOwn{});
        if (c->ctor == "ShownDerived" && c->args.size() == 0) return Shown(ShownDerived{});
        if (c->ctor == "NotShown" && c->args.size() == 0) return Shown(NotShown{});
    }
    return mismatch<Shown>("a Shown", p);
}


void TagDef::show(Printer& p) const {
    p.record("TagDef", {{"name", name}, {"tag_name", tag_name}, {"fields", fields}, {"doc", doc}, {"pod", pod}, {"eq", eq}});
}

Pod TagDef::to_pod() const {
    return Pod::record("TagDef", {{"name", prism_rtl::to_pod(name)}, {"tag_name", prism_rtl::to_pod(tag_name)}, {"fields", prism_rtl::to_pod(fields)}, {"doc", prism_rtl::to_pod(doc)}, {"pod", prism_rtl::to_pod(pod)}, {"eq", prism_rtl::to_pod(eq)}});
}

Result<TagDef> TagDef::from_pod(const Pod& whole) {
    return TagDef{.name = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .tag_name = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "tag_name")))), .fields = TRY(prism_rtl::from_pod<Array<std::tuple<Text, Text, OutTy>>>(TRY(crate::prelude::field(whole, "fields")))), .doc = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "doc")))), .pod = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "pod")))), .eq = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "eq"))))};
}


void TraitDef::show(Printer& p) const {
    p.record("TraitDef", {{"name", name}, {"methods", methods}, {"defaults", defaults}, {"doc", doc}});
}

Pod TraitDef::to_pod() const {
    return Pod::record("TraitDef", {{"name", prism_rtl::to_pod(name)}, {"methods", prism_rtl::to_pod(methods)}, {"defaults", prism_rtl::to_pod(defaults)}, {"doc", prism_rtl::to_pod(doc)}});
}

Result<TraitDef> TraitDef::from_pod(const Pod& whole) {
    return TraitDef{.name = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .methods = TRY(prism_rtl::from_pod<Array<FnDef>>(TRY(crate::prelude::field(whole, "methods")))), .defaults = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "defaults")))), .doc = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "doc"))))};
}


void TyDef::show(Printer& p) const {
    p.record("TyDef", {{"name", name}, {"prism", prism}, {"params", params}, {"shape", shape}, {"cases", cases_}, {"eq", eq}, {"ord", ord}, {"floaty", floaty}, {"show", show_}, {"pod", pod}, {"doc", doc}});
}

Pod TyDef::to_pod() const {
    return Pod::record("TyDef", {{"name", prism_rtl::to_pod(name)}, {"prism", prism_rtl::to_pod(prism)}, {"params", prism_rtl::to_pod(params)}, {"shape", prism_rtl::to_pod(shape)}, {"cases", prism_rtl::to_pod(cases_)}, {"eq", prism_rtl::to_pod(eq)}, {"ord", prism_rtl::to_pod(ord)}, {"floaty", prism_rtl::to_pod(floaty)}, {"show", prism_rtl::to_pod(show_)}, {"pod", prism_rtl::to_pod(pod)}, {"doc", prism_rtl::to_pod(doc)}});
}

Result<TyDef> TyDef::from_pod(const Pod& whole) {
    return TyDef{.name = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .prism = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "prism")))), .params = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "params")))), .shape = TRY(prism_rtl::from_pod<TyShape>(TRY(crate::prelude::field(whole, "shape")))), .cases_ = TRY(prism_rtl::from_pod<Array<CaseDef>>(TRY(crate::prelude::field(whole, "cases")))), .eq = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "eq")))), .ord = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "ord")))), .floaty = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "floaty")))), .show_ = TRY(prism_rtl::from_pod<Shown>(TRY(crate::prelude::field(whole, "show")))), .pod = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "pod")))), .doc = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "doc"))))};
}


void TyShape::show(Printer& p) const {
    if (auto c = std::get_if<ShapeRecord>(&cases())) p.choice("ShapeRecord", {});
    else if (auto c = std::get_if<ShapeChoice>(&cases())) p.choice("ShapeChoice", {});
    else if (auto c = std::get_if<ShapeNewtype>(&cases())) p.choice("ShapeNewtype", {});
    else if (auto c = std::get_if<ShapeUnit>(&cases())) p.choice("ShapeUnit", {});
}

Pod TyShape::to_pod() const {
    return std::holds_alternative<ShapeRecord>(cases()) ? Pod::choice("ShapeRecord", {})
        : std::holds_alternative<ShapeChoice>(cases()) ? Pod::choice("ShapeChoice", {})
        : std::holds_alternative<ShapeNewtype>(cases()) ? Pod::choice("ShapeNewtype", {})
        : std::holds_alternative<ShapeUnit>(cases()) ? Pod::choice("ShapeUnit", {})
        : Pod();
}

Result<TyShape> TyShape::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "ShapeRecord" && c->args.size() == 0) return TyShape(ShapeRecord{});
        if (c->ctor == "ShapeChoice" && c->args.size() == 0) return TyShape(ShapeChoice{});
        if (c->ctor == "ShapeNewtype" && c->args.size() == 0) return TyShape(ShapeNewtype{});
        if (c->ctor == "ShapeUnit" && c->args.size() == 0) return TyShape(ShapeUnit{});
    }
    return mismatch<TyShape>("a TyShape", p);
}


void XArm::show(Printer& p) const {
    p.record("XArm", {{"pat", pat}, {"conds", conds}, {"body", body}});
}

Pod XArm::to_pod() const {
    return Pod::record("XArm", {{"pat", prism_rtl::to_pod(pat)}, {"conds", prism_rtl::to_pod(conds)}, {"body", prism_rtl::to_pod(body)}});
}

Result<XArm> XArm::from_pod(const Pod& whole) {
    return XArm{.pat = TRY(prism_rtl::from_pod<Pa>(TRY(crate::prelude::field(whole, "pat")))), .conds = TRY(prism_rtl::from_pod<Array<Cc>>(TRY(crate::prelude::field(whole, "conds")))), .body = TRY(prism_rtl::from_pod<Ex>(TRY(crate::prelude::field(whole, "body"))))};
}


/// let pos0
Pos_ pos0() {
    return Pos_{.scope = Nat(0u), .at = Nat(0u)};
}


/// NextPos: fn Pos -> Pos
Pos_ next_pos(const Pos_& p_) {
    Pos_ this_ = p_;
    this_.at = this_.at + Nat(1u);
    return this_;
}


/// ScopePos: fn Nat -> Pos
Pos_ scope_pos(const Nat& k) {
    return Pos_{.scope = k, .at = Nat(0u)};
}


/// PlaceText: fn Pos -> Text
Text place_text(const Pos_& p_) {
    return p_.scope == Nat(0u)
        ? prism_rtl::cat(p_.at)
        : prism_rtl::cat("h", p_.scope, "_", p_.at);
}

}  // namespace crate::lower::model


// The module `Lower.Node`, from `target/bootstrap/cpp-src/prismc/lower/node/mod.prism`.
namespace crate::lower::node_ {



Pod FlatDef::to_pod() const {
    return Pod::record("FlatDef", {{"name", prism_rtl::to_pod(name)}, {"outer", prism_rtl::to_pod(outer)}, {"generation", prism_rtl::to_pod(generation)}, {"ty", prism_rtl::to_pod(ty)}});
}

Result<FlatDef> FlatDef::from_pod(const Pod& whole) {
    return FlatDef{.name = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .outer = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "outer")))), .generation = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "generation")))), .ty = TRY(prism_rtl::from_pod<crate::lower::model::OutTy>(TRY(crate::prelude::field(whole, "ty"))))};
}




void GnKind::show(Printer& p) const {
    if (auto c = std::get_if<GnNamed>(&cases())) p.choice("GnNamed", {});
    else if (auto c = std::get_if<GnAnswer>(&cases())) p.choice("GnAnswer", {});
    else if (auto c = std::get_if<GnStarted>(&cases())) p.choice("GnStarted", {});
    else if (auto c = std::get_if<GnDeferred>(&cases())) p.choice("GnDeferred", {});
    else if (auto c = std::get_if<GnPort>(&cases())) p.choice("GnPort", {});
    else if (auto c = std::get_if<GnMerge>(&cases())) p.choice("GnMerge", {});
    else if (auto c = std::get_if<GnUnion>(&cases())) p.choice("GnUnion", {});
    else if (auto c = std::get_if<GnBoth>(&cases())) p.choice("GnBoth", {});
    else if (auto c = std::get_if<GnExcept>(&cases())) p.choice("GnExcept", {});
    else if (auto c = std::get_if<GnMergeAll>(&cases())) p.choice("GnMergeAll", {});
    else if (auto c = std::get_if<GnGather>(&cases())) p.choice("GnGather", {});
    else if (auto c = std::get_if<GnUpdated>(&cases())) p.choice("GnUpdated", {});
    else if (auto c = std::get_if<GnNever>(&cases())) p.choice("GnNever", {});
}

Pod GnKind::to_pod() const {
    return std::holds_alternative<GnNamed>(cases()) ? Pod::choice("GnNamed", {})
        : std::holds_alternative<GnAnswer>(cases()) ? Pod::choice("GnAnswer", {})
        : std::holds_alternative<GnStarted>(cases()) ? Pod::choice("GnStarted", {})
        : std::holds_alternative<GnDeferred>(cases()) ? Pod::choice("GnDeferred", {})
        : std::holds_alternative<GnPort>(cases()) ? Pod::choice("GnPort", {})
        : std::holds_alternative<GnMerge>(cases()) ? Pod::choice("GnMerge", {})
        : std::holds_alternative<GnUnion>(cases()) ? Pod::choice("GnUnion", {})
        : std::holds_alternative<GnBoth>(cases()) ? Pod::choice("GnBoth", {})
        : std::holds_alternative<GnExcept>(cases()) ? Pod::choice("GnExcept", {})
        : std::holds_alternative<GnMergeAll>(cases()) ? Pod::choice("GnMergeAll", {})
        : std::holds_alternative<GnGather>(cases()) ? Pod::choice("GnGather", {})
        : std::holds_alternative<GnUpdated>(cases()) ? Pod::choice("GnUpdated", {})
        : std::holds_alternative<GnNever>(cases()) ? Pod::choice("GnNever", {})
        : Pod();
}

Result<GnKind> GnKind::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "GnNamed" && c->args.size() == 0) return GnKind(GnNamed{});
        if (c->ctor == "GnAnswer" && c->args.size() == 0) return GnKind(GnAnswer{});
        if (c->ctor == "GnStarted" && c->args.size() == 0) return GnKind(GnStarted{});
        if (c->ctor == "GnDeferred" && c->args.size() == 0) return GnKind(GnDeferred{});
        if (c->ctor == "GnPort" && c->args.size() == 0) return GnKind(GnPort{});
        if (c->ctor == "GnMerge" && c->args.size() == 0) return GnKind(GnMerge{});
        if (c->ctor == "GnUnion" && c->args.size() == 0) return GnKind(GnUnion{});
        if (c->ctor == "GnBoth" && c->args.size() == 0) return GnKind(GnBoth{});
        if (c->ctor == "GnExcept" && c->args.size() == 0) return GnKind(GnExcept{});
        if (c->ctor == "GnMergeAll" && c->args.size() == 0) return GnKind(GnMergeAll{});
        if (c->ctor == "GnGather" && c->args.size() == 0) return GnKind(GnGather{});
        if (c->ctor == "GnUpdated" && c->args.size() == 0) return GnKind(GnUpdated{});
        if (c->ctor == "GnNever" && c->args.size() == 0) return GnKind(GnNever{});
    }
    return mismatch<GnKind>("a GnKind", p);
}


Pod HostDef::to_pod() const {
    return Pod::record("HostDef", {{"pos", prism_rtl::to_pod(pos)}, {"name", prism_rtl::to_pod(name)}, {"scope", prism_rtl::to_pod(scope)}});
}

Result<HostDef> HostDef::from_pod(const Pod& whole) {
    return HostDef{.pos = TRY(prism_rtl::from_pod<crate::lower::model::Pos_>(TRY(crate::prelude::field(whole, "pos")))), .name = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .scope = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "scope"))))};
}






Pod Place::to_pod() const {
    return Pod::record("Place", {{"pos", prism_rtl::to_pod(pos)}, {"level", prism_rtl::to_pod(level)}, {"getter", prism_rtl::to_pod(getter)}, {"reads", prism_rtl::to_pod(reads)}, {"entry", prism_rtl::to_pod(entry)}, {"watch", prism_rtl::to_pod(watch)}});
}

Result<Place> Place::from_pod(const Pod& whole) {
    return Place{.pos = TRY(prism_rtl::from_pod<crate::lower::model::Pos_>(TRY(crate::prelude::field(whole, "pos")))), .level = TRY(prism_rtl::from_pod<crate::lower::model::Ex>(TRY(crate::prelude::field(whole, "level")))), .getter = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "getter")))), .reads = TRY(prism_rtl::from_pod<Array<Read>>(TRY(crate::prelude::field(whole, "reads")))), .entry = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "entry")))), .watch = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "watch"))))};
}


void Read::show(Printer& p) const {
    if (auto c = std::get_if<OwnRead>(&cases())) p.choice("OwnRead", {c->a0});
    else if (auto c = std::get_if<ParentRead>(&cases())) p.choice("ParentRead", {c->a0});
}

Pod Read::to_pod() const {
    return std::holds_alternative<OwnRead>(cases()) ? Pod::choice("OwnRead", {prism_rtl::to_pod(std::get<OwnRead>(cases()).a0)})
        : std::holds_alternative<ParentRead>(cases()) ? Pod::choice("ParentRead", {prism_rtl::to_pod(std::get<ParentRead>(cases()).a0)})
        : Pod();
}

Result<Read> Read::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "OwnRead" && c->args.size() == 1) return Read(OwnRead{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "ParentRead" && c->args.size() == 1) return Read(ParentRead{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
    }
    return mismatch<Read>("a Read", p);
}


Pod RowMarks::to_pod() const {
    return Pod::record("RowMarks", {{"builder", prism_rtl::to_pod(builder)}, {"reads", prism_rtl::to_pod(reads)}, {"wrote", prism_rtl::to_pod(wrote)}, {"kind", prism_rtl::to_pod(kind)}});
}

Result<RowMarks> RowMarks::from_pod(const Pod& whole) {
    return RowMarks{.builder = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "builder")))), .reads = TRY(prism_rtl::from_pod<Array<Read>>(TRY(crate::prelude::field(whole, "reads")))), .wrote = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "wrote")))), .kind = TRY(prism_rtl::from_pod<crate::lower::model::RowKind>(TRY(crate::prelude::field(whole, "kind"))))};
}


Pod Sk::to_pod() const {
    return std::holds_alternative<SkNode>(cases()) ? Pod::choice("SkNode", {prism_rtl::to_pod(std::get<SkNode>(cases()).a0)})
        : std::holds_alternative<SkIn>(cases()) ? Pod::choice("SkIn", {prism_rtl::to_pod(std::get<SkIn>(cases()).a0), prism_rtl::to_pod(std::get<SkIn>(cases()).a1)})
        : std::holds_alternative<SkHold>(cases()) ? Pod::choice("SkHold", {prism_rtl::to_pod(std::get<SkHold>(cases()).a0)})
        : std::holds_alternative<SkRequest>(cases()) ? Pod::choice("SkRequest", {prism_rtl::to_pod(std::get<SkRequest>(cases()).a0), prism_rtl::to_pod(std::get<SkRequest>(cases()).a1)})
        : std::holds_alternative<SkResult>(cases()) ? Pod::choice("SkResult", {})
        : std::holds_alternative<SkArm>(cases()) ? Pod::choice("SkArm", {prism_rtl::to_pod(std::get<SkArm>(cases()).a0)})
        : std::holds_alternative<SkCycle>(cases()) ? Pod::choice("SkCycle", {prism_rtl::to_pod(std::get<SkCycle>(cases()).a0), prism_rtl::to_pod(std::get<SkCycle>(cases()).a1), prism_rtl::to_pod(std::get<SkCycle>(cases()).a2)})
        : std::holds_alternative<SkUp>(cases()) ? Pod::choice("SkUp", {prism_rtl::to_pod(std::get<SkUp>(cases()).a0)})
        : std::holds_alternative<SkPort>(cases()) ? Pod::choice("SkPort", {prism_rtl::to_pod(std::get<SkPort>(cases()).a0)})
        : std::holds_alternative<SkMachine>(cases()) ? Pod::choice("SkMachine", {prism_rtl::to_pod(std::get<SkMachine>(cases()).a0), prism_rtl::to_pod(std::get<SkMachine>(cases()).a1), prism_rtl::to_pod(std::get<SkMachine>(cases()).a2)})
        : std::holds_alternative<SkDistinct>(cases()) ? Pod::choice("SkDistinct", {prism_rtl::to_pod(std::get<SkDistinct>(cases()).a0)})
        : Pod();
}

Result<Sk> Sk::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "SkNode" && c->args.size() == 1) return Sk(SkNode{TRY(prism_rtl::from_pod<Nat>(c->args[0]))});
        if (c->ctor == "SkIn" && c->args.size() == 2) return Sk(SkIn{TRY(prism_rtl::from_pod<Nat>(c->args[0])), TRY(prism_rtl::from_pod<Nat>(c->args[1]))});
        if (c->ctor == "SkHold" && c->args.size() == 1) return Sk(SkHold{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "SkRequest" && c->args.size() == 2) return Sk(SkRequest{TRY(prism_rtl::from_pod<crate::lower::model::Pos_>(c->args[0])), TRY(prism_rtl::from_pod<Text>(c->args[1]))});
        if (c->ctor == "SkResult" && c->args.size() == 0) return Sk(SkResult{});
        if (c->ctor == "SkArm" && c->args.size() == 1) return Sk(SkArm{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "SkCycle" && c->args.size() == 3) return Sk(SkCycle{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Text>(c->args[1])), TRY(prism_rtl::from_pod<Nat>(c->args[2]))});
        if (c->ctor == "SkUp" && c->args.size() == 1) return Sk(SkUp{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "SkPort" && c->args.size() == 1) return Sk(SkPort{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "SkMachine" && c->args.size() == 3) return Sk(SkMachine{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Text>(c->args[1])), TRY(prism_rtl::from_pod<Nat>(c->args[2]))});
        if (c->ctor == "SkDistinct" && c->args.size() == 1) return Sk(SkDistinct{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
    }
    return mismatch<Sk>("a Sk", p);
}


Pod SnapDef::to_pod() const {
    return Pod::record("SnapDef", {{"name", prism_rtl::to_pod(name)}, {"live", prism_rtl::to_pod(live)}, {"ty", prism_rtl::to_pod(ty)}, {"eq", prism_rtl::to_pod(eq)}, {"builder", prism_rtl::to_pod(builder)}, {"before", prism_rtl::to_pod(before)}, {"what", prism_rtl::to_pod(what)}});
}

Result<SnapDef> SnapDef::from_pod(const Pod& whole) {
    return SnapDef{.name = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .live = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "live")))), .ty = TRY(prism_rtl::from_pod<crate::lower::model::OutTy>(TRY(crate::prelude::field(whole, "ty")))), .eq = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "eq")))), .builder = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "builder")))), .before = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "before")))), .what = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "what"))))};
}






/// IdPipe: unbounded fn Ex, (unbounded fn Ex -> [Do]) -> [Do]
Array<crate::lower::model::Do> id_pipe(const crate::lower::model::Ex& x, const prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>& k_fn) {
    return run_to_end(k_fn(x));
}


prism_rtl::Turn<Array<crate::lower::model::Do>> IdPipe::cycle() const {
    const auto& x = this->x;
    const auto& k_fn = this->k_fn;
    return k_fn(x)->cycle();
}


/// `Start IdPipe, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::lower::model::Do>> start_id_pipe(crate::lower::model::Ex x, prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)> k_fn) {
    return prism_rtl::make_rc<IdPipe>(x, k_fn);
}


/// EvRefOf: fn Wx, Nat -> EvRef
EvRef ev_ref_of(const Wx& wx, const Nat& n) {
    return EvRef{.node_ = n, .owner = wx.node_, .pipe = static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(std::tuple<crate::lower::model::Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>>)>>(prism_rtl::rc([&](std::tuple<crate::lower::model::Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>> _p0) {
        auto&& a0 = std::get<0>(_p0);
        auto&& a1 = std::get<1>(_p0);
        return entered(start_id_pipe(a0, a1));
    }))};
}


/// KindWord: fn GnKind -> Text
Text kind_word(const GnKind& k) {
    if (prism_rtl::is<GnKind::GnNamed>(k)) {
        return Text::lit("named");
    }
    if (prism_rtl::is<GnKind::GnAnswer>(k)) {
        return Text::lit("answer");
    }
    if (prism_rtl::is<GnKind::GnStarted>(k)) {
        return Text::lit("started");
    }
    if (prism_rtl::is<GnKind::GnDeferred>(k)) {
        return Text::lit("deferred");
    }
    if (prism_rtl::is<GnKind::GnPort>(k)) {
        return Text::lit("port");
    }
    if (prism_rtl::is<GnKind::GnMerge>(k)) {
        return Text::lit("merge");
    }
    if (prism_rtl::is<GnKind::GnUnion>(k)) {
        return Text::lit("union");
    }
    if (prism_rtl::is<GnKind::GnBoth>(k)) {
        return Text::lit("both");
    }
    if (prism_rtl::is<GnKind::GnExcept>(k)) {
        return Text::lit("except");
    }
    if (prism_rtl::is<GnKind::GnMergeAll>(k)) {
        return Text::lit("mergeall");
    }
    if (prism_rtl::is<GnKind::GnGather>(k)) {
        return Text::lit("gather");
    }
    if (prism_rtl::is<GnKind::GnUpdated>(k)) {
        return Text::lit("updated");
    }
    if (prism_rtl::is<GnKind::GnNever>(k)) {
        return Text::lit("never");
    }
    prism_rtl::unreachable("no arm matched");
}


/// HasRead: fn [Read], Read -> Bool
bool has_read(const Array<Read>& rs, const Read& r) {
    return fold(rs, false, [&](const bool& seen, const Read& x) { return seen || (x == r); });
}


/// AddRead: fn [Read], Read -> [Read]
Array<Read> add_read(const Array<Read>& rs, const Read& r) {
    return has_read(rs, r) ? rs : crate::prelude::push(rs, r);
}


/// UnionReads: fn [Read], [Read] -> [Read]
Array<Read> union_reads(const Array<Read>& xs, const Array<Read>& ys) {
    return fold(ys, xs, [&](const Array<Read>& acc, const Read& y) { return add_read(acc, y); });
}


/// let nodeHooks
Array<Text> node_hooks() {
    return Array(std::vector{Text::lit("path"), Text::lit("build"), Text::lit("wake"), Text::lit("started"), Text::lit("deferred"), Text::lit("answer"), Text::lit("push"), Text::lit("swap"), Text::lit("leave"), Text::lit("patch"), Text::lit("clean_up"), Text::lit("edges"), Text::lit("release"), Text::lit("leave_row"), Text::lit("remove_places")});
}


/// NewWx: fn Lx, Text, [((Text, OutTy, Text))], [((Text, Ex))], [((Text, Ex))], [MethDef], (Text ==> [Read]), [Text], Nat, ?Text -> Wx
Wx new_wx(const crate::lower::Lx& lx, const Text& name, const Array<std::tuple<Text, crate::lower::model::OutTy, Text>>& fields, const Array<std::tuple<Text, crate::lower::model::Ex>>& inits, const Array<std::tuple<Text, crate::lower::model::Ex>>& moves, const Array<crate::lower::model::MethDef>& getters, const Map<Text, Array<Read>>& dyn_reads, const Array<Text>& taken, const Nat& depth, const std::optional<Text>& hosted_by_opt) {
    auto hosted_fields = ({
        __label__ _done;
        prism_rtl::Slot<Array<std::tuple<Text, crate::lower::model::OutTy, Text>>> _v;
        if (prism_rtl::is_some(hosted_by_opt)) {
            _v.set(Array(std::vector{std::tuple{Text::lit("enclosing"), crate::lower::types::host_of_ty(), Text::lit("the host whose document this row\'s places are entries of (pick HO)")}}));
            goto _done;
        }
        if (prism_rtl::is_none(hosted_by_opt)) {
            _v.set(Array<std::tuple<Text, crate::lower::model::OutTy, Text>>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto hosted_inits = ({
        __label__ _done;
        prism_rtl::Slot<Array<std::tuple<Text, crate::lower::model::Ex>>> _v;
        if (prism_rtl::is_some(hosted_by_opt)) {
            _v.set(Array(std::vector{std::tuple{Text::lit("enclosing"), crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("enclosing")})}}));
            goto _done;
        }
        if (prism_rtl::is_none(hosted_by_opt)) {
            _v.set(Array<std::tuple<Text, crate::lower::model::Ex>>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return Wx{.lx = lx, .node_ = name, .pos = crate::lower::model::pos0(), .gns = Array<Gn>{}, .fields = append(fields, hosted_fields), .inits = inits, .moves = append(moves, hosted_inits), .lets = Array<crate::lower::model::Do>{}, .build = Array<crate::lower::model::Do>{}, .places = Array<Place>{}, .answers = Array<std::tuple<crate::lower::model::Pos_, Nat, crate::lower::model::OutTy, Text>>{}, .started = Array<Nat>{}, .defers = Array<std::tuple<Text, Nat>>{}, .getters = getters, .dyn_reads = dyn_reads, .taken = crate::prelude::push(taken, Text::lit("enclosing")), .fallible = false, .depth = depth, .result = Wres(Wres::WrUnit{}), .rows = Array<crate::lower::model::NodeDef>{}, .builders = Array<crate::lower::model::ForDef>{}, .let_caches = Array<Text>{}, .build_holds = Array<Read>{}, .up_sink = Text::lit(""), .gens = Array<crate::lower::model::GenDef>{}, .gen_holds = Array<std::tuple<Text, Array<Read>>>{}, .ports = Array<Text>{}, .subs = Array<std::tuple<Text, Text, crate::lower::model::OutTy>>{}, .parent_env = crate::lower::types::empty_env(), .hosts = Array<HostDef>{}, .dyn_places = Array<std::tuple<crate::lower::model::Pos_, Text, crate::lower::model::OutTy, Text>>{}, .scopes = Array<Text>{}, .hosted_by = hosted_by_opt, .root_dyn = std::optional<std::tuple<crate::lower::model::Ex, Array<Read>, crate::lower::model::OutTy>>{}, .row_marks = Array<RowMarks>{}, .pending = Array<PendingRow>{}, .floors = Map<Text, Nat>{}, .snaps = Array<SnapDef>{}, .result_moved = std::optional<std::tuple<Text, Array<Read>>>{}, .dyn_answers = Array<std::tuple<Text, Array<Read>>>{}, .inited = Array<Text>{}, .flattens = Array<FlatDef>{}};
}


/// FreshName: fn Wx, Text -> ((Text, Wx))
std::tuple<Text, Wx> fresh_name(const Wx& wx, const Text& base) {
    auto pick = !crate::check::types::has_text(wx.taken, base)
        ? base
        : prism_rtl::cat(base, "_", first_free(wx.taken, base, Nat(2u)));
    auto wx2 = ({
        Wx this_ = wx;
        this_.taken = crate::prelude::push(this_.taken, pick);
        this_;
    });
    return std::tuple{pick, wx2};
}


/// FirstFree: fn [Text], Text, Nat -> Nat
Nat first_free(const Array<Text>& taken, const Text& base, const Nat& from) {
    return fold(crate::check::errors::range0(len(taken)), from, [&](const Nat& n, const Nat& _p1) {
        return crate::check::types::has_text(taken, prism_rtl::cat(base, "_", n))
            ? n + Nat(1u)
            : n;
    });
}


/// AddGn: fn Wx, Text, OutTy, GnKind, Nat -> ((Nat, Wx))
std::tuple<Nat, Wx> add_gn(const Wx& wx, const Text& name, const crate::lower::model::OutTy& ty, const GnKind& kind, const Nat& height) {
    auto id = len(wx.gns);
    auto wx2 = ({
        Wx this_ = wx;
        this_.gns = crate::prelude::push(this_.gns, Gn{.id = id, .name = name, .ty = ty, .kind = kind, .height = height, .inputs = Array<Text>{}, .reads = Array<Read>{}, .floor = Nat(0u), .outs = Array<Out>{}});
        this_;
    });
    return std::tuple{id, wx2};
}


/// Connect: fn Wx, EvRef, Sk -> Wx
Wx connect(const Wx& wx, const EvRef& r, const Sk& sink) {
    return r.owner != wx.node_
        ? crossed(wx, prism_rtl::cat("an event of node `", r.owner, "` (its graph node ", r.node_, ")"))
        : ({
        Wx this_ = wx;
        this_.gns = each(this_.gns, [&](const Gn& n) { return n.id == r.node_ ? add_out(n, Out{.pipe = r.pipe, .sink = sink}) : n; });
        this_;
    });
}


/// Crossed: fn Wx, Text -> Wx
Wx crossed(const Wx& wx, const Text& what) {
    Wx this_ = wx;
    this_.build = crate::prelude::push(this_.build, crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::expr::refusal(prism_rtl::cat(what, " read in node `", wx.node_, "` without a port (a lowering bug)"))}));
    return this_;
}


/// AddOut: fn Gn, Out -> Gn
Gn add_out(const Gn& n, const Out& o) {
    Gn this_ = n;
    this_.outs = crate::prelude::push(this_.outs, o);
    return this_;
}


/// AddField: fn Wx, Text, OutTy, Text, Ex -> Wx
Wx add_field(const Wx& wx, const Text& name, const crate::lower::model::OutTy& t, const Text& doc, const crate::lower::model::Ex& init) {
    Wx this_ = wx;
    this_.fields = crate::prelude::push(this_.fields, std::tuple{name, t, doc});
    this_.inits = crate::prelude::push(this_.inits, std::tuple{name, init});
    return this_;
}


/// AddFieldLast: fn Wx, Text, OutTy, Text, Ex -> Wx
Wx add_field_last(const Wx& wx, const Text& name, const crate::lower::model::OutTy& t, const Text& doc, const crate::lower::model::Ex& init) {
    Wx this_ = wx;
    this_.fields = crate::prelude::push(this_.fields, std::tuple{name, t, doc});
    this_.moves = crate::prelude::push(this_.moves, std::tuple{name, init});
    return this_;
}


/// GnOf: fn Wx, Nat -> Gn
Gn gn_of(const Wx& wx, const Nat& n) {
    return or_(index(wx.gns, n), Gn{.id = n, .name = Text::lit("never"), .ty = crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), .kind = GnKind(GnKind::GnNever{}), .height = Nat(0u), .inputs = Array<Text>{}, .reads = Array<Read>{}, .floor = Nat(0u), .outs = Array<Out>{}});
}


/// BindPlain: fn Env, Env, Text, Text, OutTy -> ((Env, Env))
std::tuple<crate::lower::types::Env, crate::lower::types::Env> bind_plain(const crate::lower::types::Env& benv, const crate::lower::types::Env& menv, const Text& nkey, const Text& rs, const crate::lower::model::OutTy& t) {
    return std::tuple{crate::lower::types::bind(benv, nkey, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{rs}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), t})), crate::lower::types::bind(menv, nkey, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), rs}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), t}))};
}

}  // namespace crate::lower::node_
