// The modules `Emit.Rust.Prelude`, `Emit.Rust.Templates`, `Emit.Rust.Templates.Items`, `Fs`, `Lower`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Emit.Rust.Prelude`, from `target/bootstrap/cpp-src/prismc/emit/rust/prelude.prism`.
namespace crate::emit::rust::prelude {

/// PreludeSource: fn Text -> Text
Text prelude_source(const Text& unused_p0) {
    auto out = std::string();
    out.append("//! The prelude (Semantics Appendix B), emitted by prismc beside every program: the\n//! builtins and the prelude\'s own functions as Rust over `prism_rtl`.\n\nuse std::rc::Rc;\n\nuse prism_rtl::*;\n\n// ---- Types ------------------------------------------------------------------------------\n\n/// `type Ordering = choice: Less | Equal | Greater; derive ^Eq, ^Ord, ^Show`.\n#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug)]\npub enum Ordering {\n    Less,\n    Equal,\n    Greater,\n}\n\nimpl Show for Ordering {\n    fn show(&self, p: &mut Printer) {\n        p.choice(match self { Ordering::Less => \"Less\", Ordering::Equal => \"Equal\", Ordering::Greater => \"Greater\" }, &[]);\n    }\n}\n\nimpl ToPod for Ordering {\n    fn to_pod(&self) -> Pod {\n        Pod::name(match self { Ordering::Less => \"Less\", Ordering::Equal => \"Equal\", Ordering::Greater => \"Greater\" })\n    }\n}\n\n/// `type Span = record: file, line, column, binding`.\n#[derive(Clone, PartialEq, Eq, PartialOrd, Ord)]\npub struct Span {\n    pub file: Text,\n    pub line: Nat,\n    pub column: Nat,\n    pub binding: Text,\n}\n\nimpl ToPod for Span {\n    fn to_pod(&self) -> Pod {\n        Pod::record(\"Span\", vec![(\"file\", self.file.to_pod()), (\"line\", self.line.to_pod()), (\"column\", self.column.to_pod()), (\"binding\", self.binding.to_pod())])\n    }\n}\n\nimpl FromPod for Span {\n    fn from_pod(p: &Pod) -> Result<Self, Fault> {\n        Ok(Span { file: FromPod::from_pod(field(p, \"file\")?)?, line: FromPod::from_pod(field(p, \"line\")?)?, column: FromPod::from_pod(field(p, \"column\")?)?, binding: FromPod::from_pod(field(p, \"binding\")?)? })\n    }\n}\n\n/// `type Exception = record: kind, message, spans, path`.\n#[derive(Clone, PartialEq, Eq)]\npub struct Exception {\n    pub kind: Text,\n    pub message: Text,\n    pub spans: Array<Span>,\n    pub path_: Option<Path>,\n}\n\nimpl ToPod for Exception {\n    fn to_pod(&self) -> Pod {\n        Pod::record(\"Exception\", vec![(\"kind\", self.kind.to_pod()), (\"message\", self.message.to_pod()), (\"spans\", self.spans.to_pod()), (\"path\", self.path_.to_pod())])\n    }\n}\n\nimpl FromPod for Exception {\n    fn from_pod(p: &Pod) -> Result<Self, Fault> {\n        Ok(Exception { kind: FromPod::from_pod(field(p, \"kind\")?)?, message: FromPod::from_pod(field(p, \"message\")?)?, spans: FromPod::from_pod(field(p, \"spans\")?)?, path_: FromPod::from_pod(field(p, \"path\")?)? })\n    }\n}\n\n/// `type Turn b = choice: More | Done b` (the prelude\'s; `prism_rtl::Turn` is the job\'s).\n#[derive(Clone, PartialEq, Eq)]\npub enum PreludeTurn<B> {\n    More,\n    Done(B),\n}\n\n/// `tag Prelude.Unwrap of Element !a: value: !~a`. The prelude\'s element tags are variants\n/// of `crate::Elem` and `crate::Answer` like any program\'s (a hosted child may emit them).\n#[derive(Clone, PartialEq, Eq)]\npub struct PreludeUnwrap {}\n\nimpl PreludeUnwrap {\n    pub const TAG: &\'static str = \"Prelude.Unwrap\";\n}\n\nimpl ToPod for PreludeUnwrap {\n    fn to_pod(&self) -> Pod {\n        Pod::element(\"Prelude.Unwrap\", vec![])\n    }\n}\n\nimpl FromPod for PreludeUnwrap {\n    fn from_pod(p: &Pod) -> Result<Self, Fault> {\n        match p.tag() {\n            Some(\"Prelude.Unwrap\") => Ok(PreludeUnwrap {}),\n            _ => prism_rtl::pod::mismatch(\"a Prelude.Unwrap\", p),\n        }\n    }\n}\n\n/// `tag Prelude.Exceptions of Element !Exception`.\n#[derive(Clone, PartialEq, Eq)]\npub struct PreludeExceptions {}\n\nimpl PreludeExceptions {\n    pub const TAG: &\'static str = \"Prelude.Exceptions\";\n}\n\nimpl ToPod for PreludeExceptions {\n    fn to_pod(&self) -> Pod {\n        Pod::element(\"Prelude.Exceptions\", vec![])\n    }\n}\n\nimpl FromPod for PreludeExceptions {\n    fn from_pod(p: &Pod) -> Result<Self, Fault> {\n        match p.tag() {\n            Some(\"Prelude.Exceptions\") => Ok(PreludeExceptions {}),\n            _ => prism_rtl::pod::mismatch(\"a Prelude.Exceptions\", p),\n        }\n    }\n}\n\n/// `Duration`: nanoseconds (D14 keeps its arithmetic out).\n#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord)]\npub struct Duration(pub i128);\n\nimpl Show for Duration {\n    fn show(&self, p: &mut Printer) {\n        p.duration(self.0);\n    }\n}\n\nimpl ToPod for Duration {\n    fn to_pod(&self) -> Pod {\n        Pod::Duration(self.0)\n    }\n}\n\nimpl FromPod for Duration {\n    fn from_pod(p: &Pod) -> Result<Duration, Fault> {\n        match p.structure() {\n            Pod::Duration(ns) => Ok(Duration(*ns)),\n            other => prism_rtl::pod::mismatch(\"a Duration\", other),\n        }\n    }\n}\n\n// ---- Numbers ----------------------------------------------------------------------------\n\n/// `^Num` (Type System ch. 3) over a type variable: the operators by name.\npub trait Num: Clone {\n    fn zero() -> Self;\n    fn add(a: &Self, b: &Self) -> Self;\n    fn sub(a: &Self, b: &Self) -> Self;\n    fn mul(a: &Self, b: &Self) -> Self;\n    fn div_opt(a: &Self, b: &Self) -> Option<Self>;\n    fn add_opt(a: &Self, b: &Self) -> Option<Self> {\n        Some(Self::add(a, b))\n    }\n    fn sub_opt(a: &Self, b: &Self) -> Option<Self> {\n        Some(Self::sub(a, b))\n    }\n    fn mul_opt(a: &Self, b: &Self) -> Option<Self> {\n        Some(Self::mul(a, b))\n    }\n}\n\nimpl Num for Nat {\n    fn zero() -> Nat {\n        Nat::from(0u32)\n    }\n    fn add(a: &Nat, b: &Nat) -> Nat {\n        a + b\n    }\n    fn sub(a: &Nat, b: &Nat) -> Nat {\n        a.checked_sub(b).unwrap_or_else(|| Nat::from(0u32))\n    }\n    fn mul(a: &Nat, b: &Nat) -> Nat {\n        a * b\n    }\n    fn div_opt(a: &Nat, b: &Nat) -> Option<Nat> {\n        a.div(b)\n    }\n    fn sub_opt(a: &Nat, b: &Nat) -> Option<Nat> {\n        a.checked_sub(b)\n    }\n}\n\nimpl Num for Int {\n    fn zero() -> Int {\n        Int::from(0)\n    }\n    fn add(a: &Int, b: &Int) -> Int {\n        a + b\n    }\n    fn sub(a: &Int, b: &Int) -> Int {\n        a - b\n    }\n    fn mul(a: &Int, b: &Int) -> Int {\n        a * b\n    }\n    fn div_opt(a: &Int, b: &Int) -> Option<Int> {\n        a.div(b)\n    }\n}\n\nimpl Num for Float {\n    fn zero() -> Float {\n        Float(0.0)\n    }\n    fn add(a: &Float, b: &Float) -> Float {\n        a + b\n    }\n    fn sub(a: &Float, b: &Float) -> Float {\n        a - b\n    }\n    fn mul(a: &Float, b: &Float) -> Float {\n        a * b\n    }\n    fn div_opt(a: &Float, b: &Float) -> Option<Float> {\n        Some(a / b)\n    }\n}\n\nimpl Num for u8 {\n    fn zero() -> u8 {\n        0\n    }\n    fn add(a: &u8, b: &u8) -> u8 {\n        a.wrapping_add(*b)\n    }\n    fn sub(a: &u8, b: &u8) -> u8 {\n        a.wrapping_sub(*b)\n    }\n    fn mul(a: &u8, b: &u8) -> u8 {\n        a.wrapping_mul(*b)\n    }\n    fn div_opt(a: &u8, b: &u8) -> Option<u8> {\n        a.checked_div(*b)\n    }\n    fn add_opt(a: &u8, b: &u8) -> Option<u8> {\n        a.checked_add(*b)\n    }\n    fn sub_opt(a: &u8, b: &u8) -> Option<u8> {\n        a.checked_sub(*b)\n    }\n    fn mul_opt(a: &u8, b: &u8) -> Option<u8> {\n        a.checked_mul(*b)\n    }\n}\n\n/// A `Nat` as an index; one too large for memory indexes nothing.\npub fn ix(n: &Nat) -> usize {\n    n.as_int().to_i64().map_or(usize::MAX, |i| i as usize)\n}\n\npub fn nat_of(n: usize) -> Nat {\n    Nat::from_int(Int::from(n as i64)).unwrap_or_else(|| Nat::from(0u32))\n}\n\n/// `Int: fn Nat -> Int`.\npub fn int(n: &Nat) -> Int {\n    n.as_int().clone()\n}\n\n/// `?Nat: fn Int -> ?Nat`.\npub fn nat(i: &Int) -> Option<Nat> {\n    Nat::from_int(i.clone())\n}\n\n/// `?U8: fn Int -> ?U8`.\npub fn u8_(i: &Int) -> Option<u8> {\n    i.to_i64().and_then(|n| u8::try_from(n).ok())\n}\n\n/// `?Div`, `?Mod`.\npub fn div<A: Num>(a: &A, b: &A) -> Option<A> {\n    A::div_opt(a, b)\n}\n\npub fn mod_<A: Modulo>(a: &A, b: &A) -> Option<A> {\n    A::mod_opt(a, b)\n}\n\n/// `?Mod` over each numeric type that has a remainder.\npub trait Modulo: Sized {\n    fn mod_opt(a: &Self, b: &Self) -> Option<Self>;\n}\n\nimpl Modulo for Int {\n    fn mod_opt(a: &Int, b: &Int) -> Option<Int> {\n        (b != &Int::from(0)).then(|| a.modulo(b))\n    }\n}\n\nimpl Modulo for Nat {\n    fn mod_opt(a: &Nat, b: &Nat) -> Option<Nat> {\n        (b != &Nat::from(0u32)).then(|| a.modulo(b))\n    }\n}\n\nimpl Modulo for u8 {\n    fn mod_opt(a: &u8, b: &u8) -> Option<u8> {\n        a.checked_rem(*b)\n    }\n}\n\n/// `Float`, `ToFloat`: an `Int` as a double.\npub fn float(i: &Int) -> Float {\n    Float(i.to_i64().map_or_else(|| i.to_string().parse().unwrap_or(f64::NAN), |n| n as f64))\n}\n\npub fn to_float(i: &Int) -> Float {\n    float(i)\n}\n\npub fn cos(x: &Float) -> Float {\n    Float(x.0.cos())\n}\n\npub fn sin(x: &Float) -> Float {\n    Float(x.0.sin())\n}\n\npub fn abs<A: Num + Ord>(a: &A) -> A {\n    if *a < A::zero() { A::sub(&A::zero(), a) } else { a.clone() }\n}\n\npub fn sign<A: Num + Ord + From<i8>>(a: &A) -> A {\n    if *a < A::zero() { A::from(-1) } else if *a > A::zero() { A::from(1) } else { A::zero() }\n}\n\npub fn sum<A: Num>(xs: &Array<A>) -> A {\n    xs.iter().fold(A::zero(), |s, x| A::add(&s, x))\n}\n\npub fn max<A: Ord + Clone>(a: &A, b: &A) -> A {\n    if a < b { b.clone() } else { a.clone() }\n}\n\npub fn min<A: Ord + Clone>(a: &A, b: &A) -> A {\n    if b < a { b.clone() } else { a.clone() }\n}\n\n/// `Compare` of `^Ord`.\npub fn compare<A: Ord>(a: &A, b: &A) -> Ordering {\n    match a.cmp(b) {\n        std::cmp::Ordering::Less => Ordering::Less,\n        std::cmp::Ordering::Greater => Ordering::Greater,\n        std::cmp::Ordering::Equal => Ordering::Equal,\n    }\n}\n\n// ---- Optionals --------------------------------------------------------------------------\n\n/// `Or: fn ?a, a -> a`.\npub fn or<A: Clone>(o: &Option<A>, d: &A) -> A {\n    o.clone().unwrap_or_else(|| d.clone())\n}\n\n// ---- Arrays -----------------------------------------------------------------------------\n\npub fn len<A: Clone>(xs: &Array<A>) -> Nat {\n    nat_of(xs.len())\n}\n\npub fn len_text(t: &Text) -> Nat {\n    nat_of(t.len())\n}\n\npub fn len_map<K: Ord + Clone, V: Clone>(m: &Map<K, V>) -> Nat {\n    nat_of(m.len())\n}\n\npub fn append<A: Clone>(a: &Array<A>, b: &Array<A>) -> Array<A> {\n    let mut out = a.clone();\n    out.append(b.clone());\n    out\n}\n\npub fn push<A: Clone>(xs: &Array<A>, x: &A) -> Array<A> {\n    let mut out = xs.clone();\n    out.push_back(x.clone());\n    out\n}\n\npub fn fold<A: Clone, B: Clone>(xs: &Array<A>, init: &B, f: &dyn Fn(&B, &A) -> B) -> B {\n    xs.iter().fold(init.clone(), |acc, x| f(&acc, x))\n}\n\npub fn fold_map<K: Ord + Clone, V: Clone, B: Clone>(m: &Map<K, V>, init: &B, f: &dyn Fn(&B, &K, &V) -> B) -> B {\n    m.iter().fold(init.clone(), |acc, (k, v)| f(&acc, k, v))\n}\n\npub fn each<A: Clone, B: Clone>(xs: &Array<A>, f: &dyn Fn(&A) -> B) -> Array<B> {\n    xs.iter().map(f).collect()\n}\n\npub fn filter<A: Clone>(xs: &Array<A>, keep: &dyn Fn(&A) -> bool) -> Array<A> {\n    xs.iter().filter(|x| keep(x)).cloned().collect()\n}\n\npub fn concat(xs: &Array<Text>) -> Text {\n    let mut s = String::with_capacity(xs.iter().map(Text::len).sum());\n    xs.iter().for_each(|t| s.push_str(t.as_str()));\n    Text::from(s)\n}\n\n/// `xs[i]`.\npub fn index<A: Clone>(xs: &Array<A>, i: &Nat) -> Option<A> {\n    xs.get(ix(i)).cloned()\n}\n\n/// `&xs[i]` in an `&` block.\npub fn at_mut<\'a, A: Clone>(xs: &\'a mut Array<A>, i: &Nat) -> &\'a mut A {\n    &mut xs[ix(i)]\n}\n\npub fn at_mut_map<\'a, K: Ord + Clone, V: Clone>(m: &\'a mut Map<K, V>, k: &K) -> &\'a mut V {\n    m.get_mut(k).expect(\"an `&` path to a key the map does not hold\")\n}\n\n/// `&xs[i] <= v` in an `&` block: the part is optional (Semantics ch. 5), `? x` writes the\n/// entry; an array has no entry to remove.\npub fn set_index<A: Clone>(xs: &mut Array<A>, i: &Nat, v: Option<A>) {\n    match v {\n        Some(x) => xs[ix(i)] = x,\n        None => panic!(\"`&xs[{i}] <= nil`: an array\'s entry cannot be removed\"),\n    }\n}\n\n/// `&m[k] <= v` in an `&` block: `? x` writes the key, `nil` removes it.\npub fn set_key<K: Ord + Clone, V: Clone>(m: &mut Map<K, V>, k: &K, v: Option<V>) {\n    match v {\n        Some(x) => {\n            m.insert(k.clone(), x);\n        }\n        None => {\n            m.remove(k);\n        }\n    }\n}\n\npub fn take<A: Clone>(xs: &Array<A>, n: &Nat) -> Array<A> {\n    xs.take(ix(n).min(xs.len()))\n}\n\npub fn drop<A: Clone>(xs: &Array<A>, n: &Nat) -> Array<A> {\n    xs.skip(ix(n).min(xs.len()))\n}\n\n// ---- Maps -------------------------------------------------------------------------------\n\npub fn map_of<K: Ord + Clone, V: Clone>(entries: Vec<(K, V)>) -> Map<K, V> {\n    entries.into_iter().collect()\n}\n\npub fn insert<K: Ord + Clone, V: Clone>(m: &Map<K, V>, k: &K, v: &V) -> Map<K, V> {\n    m.update(k.clone(), v.clone())\n}\n\npub fn remove<K: Ord + Clone, V: Clone>(m: &Map<K, V>, k: &K) -> Map<K, V> {\n    m.without(k)\n}\n\n/// `?Get`, and `m[k]`.\npub fn get<K: Ord + Clone, V: Clone>(m: &Map<K, V>, k: &K) -> Option<V> {\n    m.get(k).cloned()\n}\n\n/// `?First`.\npub fn first<K: Ord + Clone, V: Clone>(m: &Map<K, V>) -> Option<(K, V)> {\n    m.get_min().cloned()\n}\n\npub fn keys<K: Ord + Clone, V: Clone>(m: &Map<K, V>) -> Array<K> {\n    m.keys().cloned().collect()\n}\n\npub fn values<K: Ord + Clone, V: Clone>(m: &Map<K, V>) -> Array<V> {\n    m.values().cloned().collect()\n}\n\npub fn size<K: Ord + Clone, V: Clone>(m: &Map<K, V>) -> Nat {\n    nat_of(m.len())\n}\n\npub fn map<K: Ord + Clone, V: Clone>(entries: &Array<(K, V)>) -> Map<K, V> {\n    entries.iter().cloned().collect()\n}\n\npub fn union<K: Ord + Clone, V: Clone>(a: &Map<K, V>, b: &Map<K, V>) -> Map<K, V> {\n    b.clone().union(a.clone())\n}\n\npub fn each_map<K: Ord + Clone, V: Clone, B: Clone>(m: &Map<K, V>, f: &dyn Fn(&K, &V) -> B) -> Array<B> {\n    m.iter().map(|(k, v)| f(k, v)).collect()\n}\n\npub fn filter_map<K: Ord + Clone, V: Clone>(m: &Map<K, V>, keep: &dyn Fn(&K, &V) -> bool) -> Map<K, V> {\n    m.iter().filter(|(k, v)| keep(k, v)).map(|(k, v)| (k.clone(), v.clone())).collect()\n}\n\n// ---- Text -------------------------------------------------------------------------------\n\n/// `Text: fn Char -> Text`: the character as a one-character text.\npub fn text(c: &char) -> Text {\n    Text::from(c.to_string())\n}\n\n/// `?CharOf: fn Nat -> ?Char`: the character of a code point, none past `10FFFF` or for a\n/// surrogate.\npub fn char_of(n: &Nat) -> Option<char> {\n    n.as_int().to_i64().and_then(|v| u32::try_from(v).ok()).and_then(char::from_u32)\n}\n\npub fn upper(t: &Text) -> Text {\n    Text::from(t.as_str().to_uppercase())\n}\n\npub fn lower(t: &Text) -> Text {\n    Text::from(t.as_str().to_lowercase())\n}\n\n/// `SplitOn t, sep`: the pieces between the separators (not in Appendix B, whose `Split`\n/// is a regular expression\'s). An empty separator is refused.\npub fn split_on(t: &Text, sep: &Text) -> Array<Text> {\n    if sep.is_empty() {\n        panic!(\"`SplitOn` with an empty separator: walk the text\'s characters with a cursor (`Front`, `?Step`)\");\n    }\n    t.split(sep.as_str()).collect()\n}\n\n/// `Front: fn Text -> Cursor`.\npub fn front(t: &Text) -> Cursor {\n    Cursor::front(t)\n}\n\n/// `Back: fn Text -> Cursor`.\npub fn back(t: &Text) -> Cursor {\n    Cursor::back(t)\n}\n\n/// `?Step: fn Cursor -> ?((Char, Cursor))`.\npub fn step(c: &Cursor) -> Option<(char, Cursor)> {\n    c.step()\n}\n\n/// `?StepBack: fn Cursor -> ?((Char, Cursor))`.\npub fn step_back(c: &Cursor) -> Option<(char, Cursor)> {\n    c.step_back()\n}\n\n/// `Before: fn Cursor -> Text`.\npub fn before(c: &Cursor) -> Text {\n    c.before()\n}\n\n/// `After: fn Cursor -> Text`.\npub fn after(c: &Cursor) -> Text {\n    c.after()\n}\n\n/// `At: fn Cursor -> Nat`.\npub fn at(c: &Cursor) -> Nat {\n    nat_of(c.at())\n}\n\n/// `?CursorAt: fn Text, Nat -> ?Cursor`.\npub fn cursor_at(t: &Text, n: &Nat) -> Option<Cursor> {\n    Cursor::at_byte(t, ix(n))\n}\n\n// ---- Regular expressions (Appendix B; claude/regex-dialect.md) --------------------------\n// A literal is built where it stands (`Regex::lit`, once per literal); these are the\n// prelude\'s functions over `prism_rtl::regex`, each the runtime\'s search.\n\n/// `type Group = record: text, front, back` and `type Match = record: text, front, back,\n/// groups, named`: the runtime\'s own records, with their `==` and `Show`.\npub use prism_rtl::{Group, Match};\n\n/// `?Regex: fn Text -> ?Regex`: the text as a pattern with no flags, `None` outside the\n/// dialect; linear in the text.\npub fn regex(t: &Text) -> Option<Regex> {\n    Regex::parse(t)\n}\n\n/// `?Match: fn Regex, Cursor -> ?Match`: the match that starts at the cursor, seeing the\n/// whole text before it.\npub fn match_(r: &Regex, c: &Cursor) -> Option<Match> {\n    r.match_at(c)\n}\n\n/// `?Find: fn Regex, Text -> ?Match`: the leftmost-first match.\npub fn find(r: &Regex, t: &Text) -> Option<Match> {\n    r.find(t)\n}\n\n/// `Matches: fn Regex, Text -> [Match]`: every match, by the iteration rule.\npub fn matches(r: &Regex, t: &Text) -> Array<Match> {\n    r.matches(t)\n}\n\n/// `Replace: fn RegexReplacement, Text -> Text`: every match replaced.\npub fn replace(r: &RegexReplacement, t: &Text) -> Text {\n    r.replace(t)\n}\n\n/// `Split: fn Regex, Text -> [Text]`: the `k + 1` views between the `k` matches.\npub fn split(r: &Regex, t: &Text) -> Array<Text> {\n    r.split(t)\n}\n\n/// `?ParseNat`.\npub fn parse_nat_opt(t: &Text) -> Option<Nat> {\n    let s = t.as_str();\n    if s.is_empty() || !s.bytes().all(|c| c.is_ascii_digit()) {\n        return None;\n    }\n    Int::parse(s).and_then(Nat::from_int)\n}\n\n/// `~ParseNat`.\npub fn parse_nat_try(t: &Text) -> Result<Nat, Error> {\n    parse_nat_opt(t).ok_or_else(|| Error::new(\"Prelude.NotANumber\", format!(\"not a number: {t}\")))\n}\n\n/// `Buffer.Numbered n`: `0` to `n - 1`, linear.\npub fn numbered(n: &Nat) -> Array<Nat> {\n    (0..ix(n)).map(nat_of).collect()\n}\n\n/// `Freeze`: a `Buffer` is an array already.\npub fn freeze<A: Clone>(a: &A) -> A {\n    a.clone()\n}\n\n/// A code template\'s placeholder (Templates ch. 2): alone on its line, its text\'s lines\n/// indented to its column, a final newline dropped, an empty text no line; sharing a line,\n/// the text as it is.\npub fn place(out: &mut String, text: &Text, column: Option<usize>) {\n    let text = text.as_str();\n    match column {\n        Some(c) => {\n            let text = text.strip_suffix(\'\\n\').unwrap_or(text);\n            if text.is_empty() {\n                return;\n            }\n            for l in text.split(\'\\n\') {\n                if !l.is_empty() {\n                    out.extend(std::iter::repeat_n(\' \', c));\n                }\n                out.push_str(l);\n                out.push(\'\\n\');\n            }\n        }\n        None => out.push_str(text),\n    }\n}\n\n/// A derived `FromPod`\'s field.\npub fn field<\'a>(p: &\'a Pod, name: &str) -> Result<&\'a Pod, Fault> {\n    p.field(name).ok_or_else(|| Fault::answer(format!(\"no field {name} in {p}\")))\n}\n\n/// An array as the map from each index to its entry, for a `for` over an array.\npub fn indexed<A: Clone>(xs: &Array<A>) -> Map<Nat, A> {\n    xs.iter().enumerate().map(|(i, x)| (nat_of(i), x.clone())).collect()\n}\n\n/// The heights a node with combinators at several heights asked for this tick: its wake\n/// runs the lowest one asked (`Node::wake` is not told its height, prismc/README.md WH).\n#[derive(Default)]\npub struct Wakes(std::cell::RefCell<std::collections::BTreeSet<u32>>);\n\nimpl Wakes {\n    pub fn ask(&self, h: u32) {\n        self.0.borrow_mut().insert(h);\n    }\n    pub fn next(&self) -> u32 {\n        self.0.borrow_mut().pop_first().unwrap_or(u32::MAX)\n    }\n}\n\n/// A row of a `for` or a generation of a `rebuild`: a node its builder tears down. A row\n/// of a hosted child\'s (prismc/README.md, pick HO) is an entry of its host\'s document: its\n/// own places\' entries, by their paths relative to the row, and a host\'s typed answer to one\n/// of them.\npub trait Row: Node {\n    fn leave_row(&self, cx: &mut Cx);\n    fn document(&self, cx: &Cx) -> Vec<(Path, Rc<prism_rtl::Entry<crate::Elem>>)> {\n        let _ = cx;\n        Vec::new()\n    }\n    fn deliver(self: Rc<Self>, at: &[Segment], v: &crate::Answer, cx: &mut Cx) -> Done {\n        let _ = (v, cx);\n        Err(Fault::answer(format!(\"no hosted place at {} to answer: the row is not hosted\", Path(at.to_vec()))))\n    }\n}\n\n/// A host\'s own rows (prism_rtl\'s), which its `for` builds and tears down like any row.\nimpl Row for prism_rtl::HostRow<crate::Elem, crate::Answer> {\n    fn leave_row(&self, cx: &mut Cx) {\n        prism_rtl::HostRow::leave_row(self, cx)\n    }\n    fn document(&self, cx: &Cx) -> Vec<(Path, Rc<prism_rtl::Entry<crate::Elem>>)> {\n        let _ = cx;\n        prism_rtl::HostRow::entries(self)\n    }\n    fn deliver(self: Rc<Self>, at: &[Segment], v: &crate::Answer, cx: &mut Cx) -> Done {\n        prism_rtl::HostRow::deliver(&self, at, v, cx)\n    }\n}\n\n/// A row subscribing to its block\'s port for one event: the row heard weakly, the handle\n/// kept for its leaving (claude/backend.md: `Port::subscribe`).\npub fn subscribe_row<N: Node, P, T: Clone + \'static>(node: &Rc<N>, parent: Option<Rc<P>>, port: impl Fn(&P) -> &Port<T>, call: impl Fn(&Rc<N>, &T, &mut Cx) + \'static, slot: &std::cell::Cell<Option<Handle>>) {\n    let Some(parent) = parent else { return };\n    let me = Rc::downgrade(node);\n    let h = port(&parent).subscribe(Rc::new(move |v: &T, cx: &mut Cx| {\n        if let Some(n) = me.upgrade() {\n            call(&n, v, cx);\n        }\n        Ok(())\n    }));\n    slot.set(Some(h));\n}\n\n// ---- Jobs -------------------------------------------------------------------------------\n\n/// A frame of a job\'s stack (D6; claude/backend.md, \"Unbounded functions and `@Run`\"): the\n/// caller of `callee`, a call of an unbounded function that was not in tail position,\n/// waiting for its result. Entering the call is a cycle point; the result resumes `then`\n/// in the cycle the callee finishes. Frames nest, the innermost call deepest, so a job\'s\n/// state is its stack of pending callers. A continuation runs once, so it may move what\n/// it owns: a cycled frame hands it on to the next.\npub struct Frame<A, B> {\n    callee: Rc<dyn Job<A>>,\n    then: std::cell::RefCell<Option<Box<dyn FnOnce(A) -> Turn<B>>>>,\n}\n\nimpl<A: \'static, B: \'static> Job<B> for Frame<A, B> {\n    fn cycle(&self) -> Turn<B> {\n        let then = self.then.borrow_mut().take().expect(\"a job\'s frame is cycled once\");\n        match self.callee.cycle() {\n            Turn::More(next) => Turn::More(Rc::new(Frame { callee: next, then: std::cell::RefCell::new(Some(then)) })),\n            Turn::Finished(a) => then(a),\n        }\n    }\n}\n\n/// A call that is not in tail position: a cycle point, with `then` the continuation.\npub fn call_then<A: \'static, B: \'static>(callee: Rc<dyn Job<A>>, then: impl FnOnce(A) -> Turn<B> + \'static) -> Turn<B> {\n    Turn::More(Rc::new(Frame { callee, then: std::cell::RefCell::new(Some(Box::new(then))) }))\n}\n\n/// A call through an unbounded function value that is not in tail position: the value\'s\n/// job runs its first cycle now. A named function\'s value is `entered`, so entering it\n/// is still a cycle point (D6); a lambda\'s body is not a named function and runs on.\npub fn call_value<A: \'static, B: \'static>(callee: Rc<dyn Job<A>>, then: impl FnOnce(A) -> Turn<B> + \'static) -> Turn<B> {\n    Frame { callee, then: std::cell::RefCell::new(Some(Box::new(then))) }.cycle()\n}\n\n/// A named unbounded function\'s job as its value gives it: entering it is a cycle point.\npub struct Entered<B>(Rc<dyn Job<B>>);\n\nimpl<B> Job<B> for Entered<B> {\n    fn cycle(&self) -> Turn<B> {\n        Turn::More(self.0.clone())\n    }\n}\n\npub fn entered<B: \'static>(job: Rc<dyn Job<B>>) -> Rc<dyn Job<B>> {\n    Rc::new(Entered(job))\n}\n\n/// A `while` in an `update` block of an unbounded function as a job (D6: every turn of a\n/// `while` in an unbounded `&` block is a cycle point): `step` takes the block\'s state\n/// (`this` and its `&` locals) one turn, `Ok` to turn again, `Err` when the condition\n/// fails; each turn is a cycle.\npub struct Looping<S> {\n    state: std::cell::RefCell<Option<S>>,\n    step: Rc<dyn Fn(S) -> Result<S, S>>,\n}\n\nimpl<S: \'static> Job<S> for Looping<S> {\n    fn cycle(&self) -> Turn<S> {\n        let s = self.state.borrow_mut().take().expect(\"a loop\'s turn is cycled once\");\n        match (self.step)(s) {\n            Ok(next) => Turn::More(Rc::new(Looping { state: std::cell::RefCell::new(Some(next)), step: self.step.clone() })),\n            Err(done) => Turn::Finished(done),\n        }\n    }\n}\n\npub fn loop_job<S: \'static>(state: S, step: impl Fn(S) -> Result<S, S> + \'static) -> Rc<dyn Job<S>> {\n    Rc::new(Looping { state: std::cell::RefCell::new(Some(state)), step: Rc::new(step) })\n}\n\n/// A `while` whose body holds a cycle-point loop of its own (D6): a turn is a job, `Ok` to\n/// turn again in the next cycle, `Err` when the condition fails; each turn starts a cycle.\npub struct LoopingTurns<S> {\n    state: std::cell::RefCell<Option<S>>,\n    step: Rc<dyn Fn(S) -> Turn<Result<S, S>>>,\n}\n\nimpl<S: \'static> Job<S> for LoopingTurns<S> {\n    fn cycle(&self) -> Turn<S> {\n        let state = self.state.borrow_mut().take().expect(\"a loop\'s turn is cycled once\");\n        let step = self.step.clone();\n        let again = move |r: Result<S, S>| match r {\n            Ok(next) => Turn::More(Rc::new(LoopingTurns { state: std::cell::RefCell::new(Some(next)), step }) as Rc<dyn Job<S>>),\n            Err(done) => Turn::Finished(done),\n        };\n        match (self.step)(state) {\n            Turn::Finished(r) => again(r),\n            Turn::More(turn) => Turn::More(Rc::new(Frame { callee: turn, then: std::cell::RefCell::new(Some(Box::new(again))) })),\n        }\n    }\n}\n\npub fn loop_turns<S: \'static>(state: S, step: impl Fn(S) -> Turn<Result<S, S>> + \'static) -> Rc<dyn Job<S>> {\n    Rc::new(LoopingTurns { state: std::cell::RefCell::new(Some(state)), step: Rc::new(step) })\n}\n\n/// A `for` of an `update` block whose body holds a cycle-point loop (D6, gap LP): a loop\n/// over its entries as `loop_turns` is over its condition, taking the next entry its\n/// test; `step` takes the block\'s state and an entry, a turn a job.\nfn for_turns<E: Clone + \'static, S: \'static>(entries: Vec<E>, state: S, step: impl Fn(S, E) -> Turn<S> + \'static) -> Rc<dyn Job<S>> {\n    let entries = Rc::new(entries);\n    let job = loop_turns((state, 0usize), move |(s, i): (S, usize)| match entries.get(i).cloned() {\n        Some(e) => match step(s, e) {\n            Turn::Finished(s2) => Turn::Finished(Ok((s2, i + 1))),\n            Turn::More(j) => call_then(j, move |s2| Turn::Finished(Ok((s2, i + 1)))),\n        },\n        None => Turn::Finished(Err((s, i))),\n    });\n    map_job(job, |(s, _)| s)\n}\n\n/// `for` over a map in a job (`for_turns`): the key and the entry, in key order.\npub fn for_turns_keyed<K: Clone + \'static, V: Clone + \'static, S: \'static>(entries: impl IntoIterator<Item = (K, V)>, state: S, step: impl Fn(S, K, V) -> Turn<S> + \'static) -> Rc<dyn Job<S>> {\n    for_turns(entries.into_iter().collect(), state, move |s, (k, v)| step(s, k, v))\n}\n\n/// `for` over an array in a job (`for_turns`): the index and the entry.\npub fn for_turns_indexed<V: Clone + \'static, S: \'static>(entries: impl IntoIterator<Item = V>, state: S, step: impl Fn(S, Nat, V) -> Turn<S> + \'static) -> Rc<dyn Job<S>> {\n    for_turns(entries.into_iter().enumerate().collect(), state, move |s, (i, v)| step(s, nat_of(i), v))\n}\n\n/// The job of a lambda of unbounded type: its body, run as a job body from its first\n/// cycle (prismc/README.md, pick JB).\npub struct Once<B>(std::cell::RefCell<Option<Box<dyn FnOnce() -> Turn<B>>>>);\n\nimpl<B> Job<B> for Once<B> {\n    fn cycle(&self) -> Turn<B> {\n        (self.0.borrow_mut().take().expect(\"a lambda\'s job is cycled once\"))()\n    }\n}\n\npub fn once_job<B: \'static>(body: impl FnOnce() -> Turn<B> + \'static) -> Rc<dyn Job<B>> {\n    Rc::new(Once(std::cell::RefCell::new(Some(Box::new(body)))))\n}\n\n/// A job\'s result, mapped: `g` runs in the cycle the job finishes (entering is free).\npub fn map_job<B: \'static, C: \'static>(job: Rc<dyn Job<B>>, g: impl FnOnce(B) -> C + \'static) -> Rc<dyn Job<C>> {\n    Rc::new(Frame { callee: job, then: std::cell::RefCell::new(Some(Box::new(move |b| Turn::Finished(g(b))))) })\n}\n\n// ---- The higher-order functions as jobs (D8): given an unbounded closure, `Fold`, `Each`\n// and `Filter` call it as a job, each call a cycle point when it enters a named function\n// (D6), so that a closure\'s calls cost the cycles the books count.\n\nfn fold_from<A: Clone + \'static, B: Clone + \'static>(xs: Array<A>, i: usize, acc: B, f: Rc<dyn Fn((B, A)) -> Rc<dyn Job<B>>>) -> Turn<B> {\n    match xs.get(i).cloned() {\n        None => Turn::Finished(acc),\n        Some(x) => {\n            let g = f.clone();\n            call_value(f((acc, x)), move |b| fold_from(xs, i + 1, b, g))\n        }\n    }\n}\n\npub fn fold_job<A: Clone + \'static, B: Clone + \'static>(xs: Array<A>, init: B, f: Rc<dyn Fn((B, A)) -> Rc<dyn Job<B>>>) -> Rc<dyn Job<B>> {\n    once_job(move || fold_from(xs, 0, init, f))\n}\n\npub fn fold_map_job<K: Ord + Clone + \'static, V: Clone + \'static, B: Clone + \'static>(m: Map<K, V>, init: B, f: Rc<dyn Fn((B, K, V)) -> Rc<dyn Job<B>>>) -> Rc<dyn Job<B>> {\n    let pairs: Array<(K, V)> = m.iter().map(|(k, v)| (k.clone(), v.clone())).collect();\n    fold_job(pairs, init, Rc::new(move |(acc, (k, v)): (B, (K, V))| f((acc, k, v))))\n}\n\npub fn each_job<A: Clone + \'static, B: Clone + \'static>(xs: Array<A>, f: Rc<dyn Fn(A) -> Rc<dyn Job<B>>>) -> Rc<dyn Job<Array<B>>> {\n    fold_job(xs, Array::new(), Rc::new(move |(acc, x): (Array<B>, A)| {\n        map_job(f(x), move |b| {\n            let mut acc = acc;\n            acc.push_back(b);\n            acc\n        })\n    }))\n}\n\npub fn each_map_job<K: Ord + Clone + \'static, V: Clone + \'static, B: Clone + \'static>(m: Map<K, V>, f: Rc<dyn Fn((K, V)) -> Rc<dyn Job<B>>>) -> Rc<dyn Job<Array<B>>> {\n    let pairs: Array<(K, V)> = m.iter().map(|(k, v)| (k.clone(), v.clone())).collect();\n    each_job(pairs, f)\n}\n\npub fn filter_job<A: Clone + \'static>(xs: Array<A>, keep: Rc<dyn Fn(A) -> Rc<dyn Job<bool>>>) -> Rc<dyn Job<Array<A>>> {\n    fold_job(xs, Array::new(), Rc::new(move |(acc, x): (Array<A>, A)| {\n        map_job(keep(x.clone()), move |k| {\n            let mut acc = acc;\n            if k {\n                acc.push_back(x);\n            }\n            acc\n        })\n    }))\n}\n\npub fn filter_map_job<K: Ord + Clone + \'static, V: Clone + \'static>(m: Map<K, V>, keep: Rc<dyn Fn((K, V)) -> Rc<dyn Job<bool>>>) -> Rc<dyn Job<Map<K, V>>> {\n    let pairs: Array<(K, V)> = m.iter().map(|(k, v)| (k.clone(), v.clone())).collect();\n    fold_job(pairs, Map::new(), Rc::new(move |(acc, (k, v)): (Map<K, V>, (K, V))| {\n        map_job(keep((k.clone(), v.clone())), move |keep| {\n            let mut acc = acc;\n            if keep {\n                acc.insert(k, v);\n            }\n            acc\n        })\n    }))\n}\n\n/// A job run to its result inside the cycle: a call of an unbounded function value from\n/// direct-style code (gap DS of prismc/README.md).\npub fn run_to_end<B>(job: Rc<dyn Job<B>>) -> B {\n    let mut job = job;\n    loop {\n        match job.cycle() {\n            Turn::More(next) => job = next,\n            Turn::Finished(b) => return b,\n        }\n    }\n}\n\n// ---- Running ----------------------------------------------------------------------------\n\n/// `--world NAME` as the first argument: the World, and the arguments without the\n/// option. Only the first: a `--world` later on is the program\'s own (prismc\'s `--check\n/// --world Ui` names the World the checker checks against).\npub fn world_option(args: &[String], default: &str) -> (String, Vec<String>) {\n    match args.first().map(String::as_str) {\n        Some(\"--world\") if args.len() > 1 => (args[1].clone(), args[2..].to_vec()),\n        Some(a) if a.starts_with(\"--world=\") => (a[\"--world=\".len()..].to_string(), args[1..].to_vec()),\n        _ => (default.to_string(), args.to_vec()),\n    }\n}\n\n/// Run on a thread with a large stack: unbounded code runs direct-style within a cycle\n/// (doubt DS of prismc/README.md), and Rust\'s default stack is 8 MB.\npub fn on_big_stack(f: impl FnOnce() -> u8 + Send + \'static) -> u8 {\n    std::thread::Builder::new().stack_size(1 << 30).spawn(f).map_or(1, |h| h.join().unwrap_or(1))\n}\n\n/// `test`: each script under the Test World. With `--print` the transcripts go to\n/// standard output as they are; otherwise each is compared byte for byte with the\n/// `.expected` beside it (`tests.expected` for the test module `tests.prism`), and `ok`\n/// or the difference is printed.\npub fn run_scripts(world: &TestWorld, given: &[String], compiled: &[&str]) -> u8 {\n    let print = given.iter().any(|a| a == \"--print\");\n    let mut paths: Vec<String> = given.iter().filter(|a| *a != \"--print\").cloned().collect();\n    if paths.is_empty() {\n        paths = compiled.iter().map(|s| s.to_string()).collect();\n    }\n    let mut code = 0;\n    for path in paths {\n        let script = match std::fs::read_to_string(&path) {\n            Ok(s) => s,\n            Err(e) => {\n                eprintln!(\"{path}: {e}\");\n                code = 2;\n                continue;\n            }\n        };\n        if print {\n            let report = world.run(&script);\n            print!(\"{}\", report.transcript);\n            report.failures.iter().for_each(|f| eprintln!(\"{path}: {f}\"));\n            code = code.max(report.exit_code);\n            continue;\n        }\n        let stem = path.strip_suffix(\".prism\").unwrap_or(&path);\n        let expected_path = format!(\"{stem}.expected\");\n        match std::fs::read_to_string(&expected_path) {\n            Ok(expected) => match world.verify(&script, &expected) {\n                Ok(_) => println!(\"ok {path}\"),\n                Err(e) => {\n                    println!(\"FAILED {path}: {e}\");\n                    code = 1;\n                }\n            },\n            Err(_) => {\n                let report = world.run(&script);\n                print!(\"{}\", report.transcript);\n                report.failures.iter().for_each(|f| eprintln!(\"{path}: {f}\"));\n                code = code.max(report.exit_code);\n            }\n        }\n    }\n    code\n}\n\n/// The canvas World, when the crate is built with it.\n#[cfg(feature = \"canvas\")]\npub fn run_canvas<P: Program>() -> u8 {\n    prism_world_canvas_rtl::run::<P>()\n}\n\n#[cfg(not(feature = \"canvas\"))]\npub fn run_canvas<P: Program>() -> u8 {\n    eprintln!(\"this program was built without the canvas World: cargo build --features canvas\");\n    1\n}\n");
    return Text(std::move(out));
}

}  // namespace crate::emit::rust::prelude


// The module `Emit.Rust.Templates`, from `target/bootstrap/cpp-src/prismc/emit/rust/templates/mod.prism`.
namespace crate::emit::rust::templates {

/// Doc: fn Text -> Text
Text doc(const Text& text_p0) {
    return text_p0 == Text::lit("")
        ? Text::lit("")
        : concat(each(split_on(text_p0, Text::lit("\n")), [&](const Text& l_p1) {
        return l_p1 == Text::lit("")
            ? Text::lit("///\n")
            : prism_rtl::cat("/// ", l_p1, "\n");
    }));
}


/// SourceDoc: fn Text, Text -> Text
Text source_doc(const Text& lead_p0, const Text& source_p1) {
    return lead_p0 == Text::lit("")
        ? source_only(source_p1)
        : source_led(lead_p0, source_p1);
}


/// SourceOnly: fn Text -> Text
Text source_only(const Text& source_p0) {
    auto out = std::string();
    out.append("/// ```prism\n");
    place(out, quoted(source_p0), std::nullopt);
    out.append("\n/// ```\n");
    return Text(std::move(out));
}


/// SourceLed: fn Text, Text -> Text
Text source_led(const Text& lead_p0, const Text& source_p1) {
    auto out = std::string();
    out.append("/// ");
    place(out, lead_p0, std::nullopt);
    out.append("\n///\n/// ```prism\n");
    place(out, quoted(source_p1), std::nullopt);
    out.append("\n/// ```\n");
    return Text(std::move(out));
}


/// Quoted: fn Text -> Text
Text quoted(const Text& text_p0) {
    return joined(each(split_on(text_p0, Text::lit("\n")), [&](const Text& l_p1) { return l_p1 == Text::lit("") ? Text::lit("///") : prism_rtl::cat("/// ", l_p1); }), Text::lit("\n"));
}


/// Joined: fn [Text], Text -> Text
Text joined(const Array<Text>& xs_p0, const Text& sep_p1) {
    auto&& _m = index(xs_p0, Nat(0u));
    if (prism_rtl::is_some(_m)) {
        auto&& first_p2 = prism_rtl::some_of(_m);
        return concat(fold(drop(xs_p0, Nat(1u)), Array(std::vector{first_p2}), [&](const Array<Text>& acc_p3, const Text& x_p4) { return crate::prelude::push(crate::prelude::push(acc_p3, sep_p1), x_p4); }));
    }
    if (prism_rtl::is_none(_m)) {
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}


/// Module: fn Text, Text, Text, Text -> Text
Text module(const Text& prism_p0, const Text& path_p1, const Text& uses_p2, const Text& items_p3) {
    auto out = std::string();
    out.append("//! ");
    place(out, prism_p0, std::nullopt);
    out.append(", from `");
    place(out, path_p1, std::nullopt);
    out.append("`, emitted by prismc: one Rust type per Prism type, a node\n//! per root widget (claude/backend.md). Edit the Prism source, not this file.\n\nuse std::cell::{Cell, RefCell};\nuse std::rc::{Rc, Weak};\n\nuse prism_rtl::*;\nuse prism_rtl::pod::mismatch;\n\nuse crate::prelude::*;\n");
    place(out, uses_p2, std::optional(0u));
    out.append("\n");
    place(out, items_p3, std::optional(0u));
    return Text(std::move(out));
}


/// Cargo: fn Text, Text, Text -> Text
Text cargo(const Text& name_p0, const Text& runtime_p1, const Text& defaults_p2) {
    auto out = std::string();
    out.append("# Emitted by prismc. Edit the Prism sources, not this file.\n[package]\nname = \"");
    place(out, name_p0, std::nullopt);
    out.append("\"\nversion = \"0.1.0\"\nedition = \"2024\"\n\n[workspace]\n\n[[bin]]\nname = \"");
    place(out, name_p0, std::nullopt);
    out.append("\"\npath = \"src/main.rs\"\n\n[dependencies]\nprism_rtl = { path = \"");
    place(out, runtime_p1, std::nullopt);
    out.append("/runtime/rust\" }\nprism_world_cli = { path = \"");
    place(out, runtime_p1, std::nullopt);
    out.append("/worlds/cli/rust\" }\nprism_world_canvas_rtl = { path = \"");
    place(out, runtime_p1, std::nullopt);
    out.append("/worlds/canvas/rust\", optional = true }\n\n[features]\ndefault = [");
    place(out, defaults_p2, std::nullopt);
    out.append("]\ncanvas = [\"prism_world_canvas_rtl\"]\n");
    return Text(std::move(out));
}


/// Main: fn Text, Text, Text, Text, Text, Text, Text -> Text
Text main(const Text& name_p0, const Text& mods_p1, const Text& programs_p2, const Text& registrations_p3, const Text& scripts_p4, const Text& run_root_p5, const Text& world_p6) {
    auto out = std::string();
    out.append("//! The program `");
    place(out, name_p0, std::nullopt);
    out.append("`, emitted by prismc from Prism (claude/backend.md): a crate over\n//! `prism_rtl`, run under the CLI World, the canvas World or the Test World. Edit the\n//! Prism sources, not these files.\n#![allow(dead_code, unused_variables, unused_imports, unused_mut, unused_parens, unused_braces)]\n#![allow(unreachable_patterns, unreachable_code, unused_labels, non_snake_case, non_camel_case_types)]\n#![allow(clippy::all)]\n// A recursive widget\'s rows nest a node type per level, sixteen levels (gap ID): deeper than\n// rustc\'s default limit of 128 for checking what a type\'s drop reaches.\n#![recursion_limit = \"512\"]\n\n");
    place(out, mods_p1, std::optional(0u));
    out.append("\nuse std::rc::Rc;\n\nuse prism_rtl::*;\n\nuse crate::prelude::*;\n\n");
    place(out, programs_p2, std::optional(0u));
    out.append("\n/// The Test World with every root a test names, and the compiled `check` blocks.\nfn test_world() -> TestWorld {\n    TestWorld::new()\n");
    place(out, registrations_p3, std::optional(8u));
    out.append("}\n\n/// The test scripts compiled with the program: `test` runs these when given none.\nconst SCRIPTS: &[&str] = &[\n");
    place(out, scripts_p4, std::optional(4u));
    out.append("];\n\n/// The World the root\'s row asks for: `canvas`, `cli`, or `none` (a row with `Ui` and no\n/// `Gui`, which no World answers).\nconst WORLD: &str = \"");
    place(out, world_p6, std::nullopt);
    out.append("\";\n\nfn main() {\n    let args: Vec<String> = std::env::args().skip(1).collect();\n    let (world, rest) = prelude::world_option(&args, WORLD);\n    let code = if args.first().map(String::as_str) == Some(\"test\") || world == \"test\" {\n        let scripts: Vec<String> = rest.into_iter().filter(|a| a != \"test\").collect();\n        prelude::on_big_stack(move || prelude::run_scripts(&test_world(), &scripts, SCRIPTS))\n    } else {\n        run_root(&world, rest)\n    };\n    std::process::exit(code as i32);\n}\n\n/// The root under the World `world`.\nfn run_root(world: &str, args: Vec<String>) -> u8 {\n");
    place(out, run_root_p5, std::optional(4u));
    out.append("}\n");
    return Text(std::move(out));
}


/// NoRoot: fn Text -> Text
Text no_root(const Text& name_p0) {
    auto out = std::string();
    out.append("let _ = (world, args);\neprintln!(\"");
    place(out, name_p0, std::nullopt);
    out.append(": the program has no `@main`; `");
    place(out, name_p0, std::nullopt);
    out.append(" test` runs its tests\");\n2\n");
    return Text(std::move(out));
}


/// RunRoot: fn Text -> Text
Text run_root(const Text& program_p0) {
    auto out = std::string();
    out.append("match world {\n    \"canvas\" => prelude::run_canvas::<");
    place(out, program_p0, std::nullopt);
    out.append(">(),\n    \"cli\" => prelude::on_big_stack(move || prism_world_cli::run::<");
    place(out, program_p0, std::nullopt);
    out.append(">(args)),\n    \"none\" => {\n        eprintln!(\"the root\'s row has Ui.* without Gui.*: no World answers Ui elements alone; emit Gui.* for the canvas World, or pass --world\");\n        2\n    }\n    other => {\n        eprintln!(\"no World {other} (cli, canvas, test)\");\n        2\n    }\n}\n");
    return Text(std::move(out));
}

}  // namespace crate::emit::rust::templates


// The module `Emit.Rust.Templates.Items`, from `target/bootstrap/cpp-src/prismc/emit/rust/templates/items.prism`.
namespace crate::emit::rust::templates::items {

/// Struct: fn Text, Text, Text, Text -> Text
Text struct_(const Text& doc_p0, const Text& derives_p1, const Text& head_p2, const Text& fields_p3) {
    auto out = std::string();
    place(out, doc_p0, std::optional(0u));
    out.append("#[derive(");
    place(out, derives_p1, std::nullopt);
    out.append(")]\npub struct ");
    place(out, head_p2, std::nullopt);
    out.append(" {\n");
    place(out, fields_p3, std::optional(4u));
    out.append("}\n");
    return Text(std::move(out));
}


/// Enum: fn Text, Text, Text, Text -> Text
Text enum_(const Text& doc_p0, const Text& derives_p1, const Text& head_p2, const Text& cases_p3) {
    auto out = std::string();
    place(out, doc_p0, std::optional(0u));
    out.append("#[derive(");
    place(out, derives_p1, std::nullopt);
    out.append(")]\npub enum ");
    place(out, head_p2, std::nullopt);
    out.append(" {\n");
    place(out, cases_p3, std::optional(4u));
    out.append("}\n");
    return Text(std::move(out));
}


/// TupleStruct: fn Text, Text, Text, Text -> Text
Text tuple_struct(const Text& doc_p0, const Text& derives_p1, const Text& head_p2, const Text& fields_p3) {
    auto out = std::string();
    place(out, doc_p0, std::optional(0u));
    out.append("#[derive(");
    place(out, derives_p1, std::nullopt);
    out.append(")]\npub struct ");
    place(out, head_p2, std::nullopt);
    place(out, fields_p3, std::nullopt);
    out.append(";\n");
    return Text(std::move(out));
}


/// Impl: fn Text, Text, Text, Text, Text -> Text
Text impl_(const Text& generics_p0, const Text& tr_p1, const Text& ty_p2, const Text& signature_p3, const Text& body_p4) {
    auto out = std::string();
    out.append("impl");
    place(out, generics_p0, std::nullopt);
    out.append(" ");
    place(out, tr_p1, std::nullopt);
    out.append(" for ");
    place(out, ty_p2, std::nullopt);
    out.append(" {\n    ");
    place(out, signature_p3, std::nullopt);
    out.append(" {\n");
    place(out, body_p4, std::optional(8u));
    out.append("    }\n}\n");
    return Text(std::move(out));
}


/// MatchSelf: fn Text -> Text
Text match_self(const Text& arms_p0) {
    auto out = std::string();
    out.append("match self {\n");
    place(out, arms_p0, std::optional(4u));
    out.append("}\n");
    return Text(std::move(out));
}


/// ShownPod: fn Text -> Text
Text shown_pod(const Text& structure_p0) {
    auto out = std::string();
    out.append("let structure = {\n");
    place(out, structure_p0, std::optional(4u));
    out.append("};\nPod::Shown(show(self).as_str().into(), Box::new(structure))\n");
    return Text(std::move(out));
}


/// FromPodBody: fn Text, Text -> Text
Text from_pod_body(const Text& arms_p0, const Text& want_p1) {
    auto out = std::string();
    out.append("match p.structure() {\n");
    place(out, arms_p0, std::optional(4u));
    out.append("    other => mismatch(\"");
    place(out, want_p1, std::nullopt);
    out.append("\", other),\n}\n");
    return Text(std::move(out));
}


/// Tag: fn Text, Text, Text, Text, Text, Text -> Text
Text tag(const Text& doc_p0, const Text& derives_p1, const Text& name_p2, const Text& fields_p3, const Text& tag_name_p4, const Text& pods_p5) {
    auto out = std::string();
    place(out, doc_p0, std::optional(0u));
    out.append("#[derive(");
    place(out, derives_p1, std::nullopt);
    out.append(")]\npub struct ");
    place(out, name_p2, std::nullopt);
    out.append(" {\n");
    place(out, fields_p3, std::optional(4u));
    out.append("}\n\nimpl ");
    place(out, name_p2, std::nullopt);
    out.append(" {\n    /// The tag\'s qualified name, as its `Pod` carries it.\n    pub const TAG: &\'static str = \"");
    place(out, tag_name_p4, std::nullopt);
    out.append("\";\n}\n\nimpl ToPod for ");
    place(out, name_p2, std::nullopt);
    out.append(" {\n    fn to_pod(&self) -> Pod {\n        Pod::element(\"");
    place(out, tag_name_p4, std::nullopt);
    out.append("\", vec![");
    place(out, pods_p5, std::nullopt);
    out.append("])\n    }\n}\n\nimpl Show for ");
    place(out, name_p2, std::nullopt);
    out.append(" {\n    fn show(&self, p: &mut Printer) {\n        self.to_pod().show(p);\n    }\n}\n");
    return Text(std::move(out));
}


/// TagLevel: fn Text, Text, Text, Text -> Text
Text tag_level(const Text& name_p0, const Text& tag_name_p1, const Text& pods_p2, const Text& ports_p3) {
    auto out = std::string();
    out.append("impl ");
    place(out, name_p0, std::nullopt);
    out.append(" {\n    /// The level as a World reads it: each dynamic it holds sampled at the read point.\n    pub fn level_pod(&self, cx: &Cx) -> Pod {\n        Pod::element(\"");
    place(out, tag_name_p1, std::nullopt);
    out.append("\", vec![");
    place(out, pods_p2, std::nullopt);
    out.append("])\n    }\n    /// The update events of the dynamics it holds, and of theirs.\n    pub fn level_ports(&self, cx: &Cx, out: &mut Vec<Rc<Port<()>>>) {\n        let _ = (cx, &out);");
    place(out, ports_p3, std::nullopt);
    out.append("\n    }\n}\n");
    return Text(std::move(out));
}


/// RowLevel: fn Text, Text, Text -> Text
Text row_level(const Text& name_p0, const Text& pods_p1, const Text& ports_p2) {
    auto out = std::string();
    out.append("impl prism_rtl::Level for ");
    place(out, name_p0, std::nullopt);
    out.append(" {\n    fn level_pod(&self, cx: &Cx) -> Pod {\n        let _ = cx;\n        match self {\n            ");
    place(out, pods_p1, std::nullopt);
    out.append("_ => self.to_pod(),\n        }\n    }\n    fn level_ports(&self, cx: &Cx, out: &mut Vec<Rc<Port<()>>>) {\n        let _ = (cx, &out);\n        match self {\n            ");
    place(out, ports_p2, std::nullopt);
    out.append("_ => {}\n        }\n    }\n}\n");
    return Text(std::move(out));
}


/// TagFromPod: fn Text, Text, Text -> Text
Text tag_from_pod(const Text& name_p0, const Text& tag_name_p1, const Text& reads_p2) {
    auto out = std::string();
    out.append("impl FromPod for ");
    place(out, name_p0, std::nullopt);
    out.append(" {\n    fn from_pod(p: &Pod) -> Result<Self, Fault> {\n        match p.tag() {\n            Some(\"");
    place(out, tag_name_p1, std::nullopt);
    out.append("\") => Ok(");
    place(out, name_p0, std::nullopt);
    out.append(" { ");
    place(out, reads_p2, std::nullopt);
    out.append(" }),\n            _ => prism_rtl::pod::mismatch(\"a ");
    place(out, tag_name_p1, std::nullopt);
    out.append("\", p),\n        }\n    }\n}\n");
    return Text(std::move(out));
}


/// Row: fn Text, Text, Text, Text, Text -> Text
Text row(const Text& doc_p0, const Text& derives_p1, const Text& name_p2, const Text& cases_p3, const Text& pods_p4) {
    auto out = std::string();
    place(out, doc_p0, std::optional(0u));
    out.append("#[derive(");
    place(out, derives_p1, std::nullopt);
    out.append(")]\npub enum ");
    place(out, name_p2, std::nullopt);
    out.append(" {\n");
    place(out, cases_p3, std::optional(4u));
    out.append("}\n\nimpl ToPod for ");
    place(out, name_p2, std::nullopt);
    out.append(" {\n    fn to_pod(&self) -> Pod {\n        match self {\n");
    place(out, pods_p4, std::optional(12u));
    out.append("        }\n    }\n}\n\nimpl Show for ");
    place(out, name_p2, std::nullopt);
    out.append(" {\n    fn show(&self, p: &mut Printer) {\n        self.to_pod().show(p);\n    }\n}\n");
    return Text(std::move(out));
}


/// RowFromPod: fn Text, Text -> Text
Text row_from_pod(const Text& name_p0, const Text& reads_p1) {
    auto out = std::string();
    out.append("impl FromPod for ");
    place(out, name_p0, std::nullopt);
    out.append(" {\n    fn from_pod(p: &Pod) -> Result<Self, Fault> {\n        match p.tag() {\n");
    place(out, reads_p1, std::optional(12u));
    out.append("            _ => prism_rtl::pod::mismatch(\"a ");
    place(out, name_p0, std::nullopt);
    out.append("\", p),\n        }\n    }\n}\n");
    return Text(std::move(out));
}


/// Fn: fn Text, Text, Text -> Text
Text fn_(const Text& doc_p0, const Text& signature_p1, const Text& body_p2) {
    auto out = std::string();
    place(out, doc_p0, std::optional(0u));
    place(out, signature_p1, std::nullopt);
    out.append(" {\n");
    place(out, body_p2, std::optional(4u));
    out.append("}\n");
    return Text(std::move(out));
}


/// Job: fn Text, Text, Text, Text, Text, Text, Text, Text, Text -> Text
Text job(const Text& doc_p0, const Text& head_p1, const Text& generics_p2, const Text& bounded_p3, const Text& fields_p4, const Text& ret_p5, const Text& body_p6, const Text& start_p7, const Text& start_body_p8) {
    auto out = std::string();
    out.append("/// The step machine of `");
    place(out, head_p1, std::nullopt);
    out.append("`, stopped at a cycle point: the call about to be\n/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the\n/// callee\'s job, so the job\'s stack is its frames.\n///\n");
    place(out, doc_p0, std::optional(0u));
    out.append("pub struct ");
    place(out, head_p1, std::nullopt);
    place(out, generics_p2, std::nullopt);
    out.append(" {\n");
    place(out, fields_p4, std::optional(4u));
    out.append("}\n\nimpl");
    place(out, bounded_p3, std::nullopt);
    out.append(" prism_rtl::Job<");
    place(out, ret_p5, std::nullopt);
    out.append("> for ");
    place(out, head_p1, std::nullopt);
    place(out, generics_p2, std::nullopt);
    out.append(" {\n    fn cycle(&self) -> prism_rtl::Turn<");
    place(out, ret_p5, std::nullopt);
    out.append("> {\n");
    place(out, body_p6, std::optional(8u));
    out.append("    }\n}\n\n/// `Start ");
    place(out, head_p1, std::nullopt);
    out.append(", x`: what the function value is when passed to `@Run`.\n");
    place(out, start_p7, std::nullopt);
    out.append(" {\n");
    place(out, start_body_p8, std::optional(4u));
    out.append("}\n");
    return Text(std::move(out));
}


/// Node: fn Text, Text, Text, Text, Text, Text, Text, Text -> Text
Text node_(const Text& doc_p0, const Text& name_p1, const Text& fields_p2, const Text& consts_p3, const Text& build_p4, const Text& methods_p5, const Text& hooks_p6, const Text& answer_p7) {
    auto out = std::string();
    place(out, doc_p0, std::optional(0u));
    out.append("pub struct ");
    place(out, name_p1, std::nullopt);
    out.append(" {\n    path: Path,\n");
    place(out, fields_p2, std::optional(4u));
    out.append("}\n\nimpl ");
    place(out, name_p1, std::nullopt);
    out.append(" {\n");
    place(out, consts_p3, std::optional(4u));
    place(out, build_p4, std::optional(4u));
    place(out, methods_p5, std::optional(4u));
    out.append("}\n\nimpl Node for ");
    place(out, name_p1, std::nullopt);
    out.append(" {\n");
    place(out, answer_p7, std::optional(4u));
    place(out, hooks_p6, std::optional(4u));
    out.append("}\n");
    return Text(std::move(out));
}


/// Build: fn Text, Text, Text, Text, Text, Text -> Text
Text build(const Text& name_p0, const Text& params_p1, const Text& ret_p2, const Text& lets_p3, const Text& inits_p4, const Text& rest_p5) {
    auto out = std::string();
    out.append("/// Built after propagation: holds take their initial values, places go out with\n/// `cx.added`, and nothing fires.\npub fn build(path: Path, ");
    place(out, params_p1, std::nullopt);
    out.append("cx: &mut Cx) -> ");
    place(out, ret_p2, std::nullopt);
    out.append(" {\n");
    place(out, lets_p3, std::optional(4u));
    out.append("    let node = Rc::new(");
    place(out, name_p0, std::nullopt);
    out.append(" { ");
    place(out, inits_p4, std::nullopt);
    out.append(" });\n");
    place(out, rest_p5, std::optional(4u));
    out.append("}\n");
    return Text(std::move(out));
}


/// Method: fn Text, Text, Text -> Text
Text method(const Text& doc_p0, const Text& signature_p1, const Text& body_p2) {
    auto out = std::string();
    place(out, doc_p0, std::optional(0u));
    place(out, signature_p1, std::nullopt);
    out.append(" {\n");
    place(out, body_p2, std::optional(4u));
    out.append("}\n");
    return Text(std::move(out));
}


/// ForBuild: fn Text, Text, Text, Text, Text, Text, Text, Text, Text, Text, Text -> Text
Text for_build(const Text& name_p0, const Text& at_p1, const Text& key_ty_p2, const Text& value_ty_p3, const Text& row_node_p4, const Text& source_p5, const Text& parent_p6, const Text& passed_p7, const Text& moved_p8, const Text& from_p9, const Text& replaced_pa) {
    auto out = std::string();
    out.append("/// The rows of the `for` at `");
    place(out, at_p1, std::nullopt);
    out.append("`: rows whose key left are torn down, new keys are\n/// built under it at `[k]` from the values after the tick; kept rows keep reading their\n/// entry out of the source. Nothing to do when the source is the map last built from.\nfn ");
    place(out, name_p0, std::nullopt);
    out.append("_build(self: &Rc<Self>, cx: &mut Cx) -> Done {\n    let items: Map<");
    place(out, key_ty_p2, std::nullopt);
    out.append(", ");
    place(out, value_ty_p3, std::nullopt);
    out.append("> = self.");
    place(out, source_p5, std::nullopt);
    out.append("(cx);\n    if self.");
    place(out, name_p0, std::nullopt);
    out.append("_from.borrow().same(&items) {\n        return Ok(());\n    }\n");
    place(out, from_p9, std::optional(4u));
    out.append("    let old = self.");
    place(out, name_p0, std::nullopt);
    out.append(".borrow().clone();\n    // the kept rows stay where they are: only the keys that left or came are touched\n    let mut next = old.clone();\n    for (k, row) in old.iter() {\n        if !items.contains_key(k) {\n            row.leave_row(cx);\n            cx.leave_later(row.clone());\n            next.remove(k);\n        }");
    place(out, replaced_pa, std::nullopt);
    out.append("\n    }\n    for (k, v) in items.iter() {\n        if !old.contains_key(k) {\n            let row = ");
    place(out, row_node_p4, std::nullopt);
    out.append("::build(");
    place(out, at_p1, std::nullopt);
    out.append(".child(Segment::Key(k.to_pod())), k.clone(), v.clone(), ");
    place(out, parent_p6, std::nullopt);
    place(out, passed_p7, std::nullopt);
    out.append(", cx)?;\n            next.insert(k.clone(), row);\n        }\n    }\n    *self.");
    place(out, name_p0, std::nullopt);
    out.append(".borrow_mut() = next;\n    // What the block reads of its rows (a `for` that gives a dynamic) moved.\n    cx.dirty(self.clone());");
    place(out, moved_p8, std::nullopt);
    out.append("\n    Ok(())\n}\n");
    return Text(std::move(out));
}


/// GenBuild: fn Text, Text, Text, Text, Text, Text, Text -> Text
Text gen_build(const Text& name_p0, const Text& at_p1, const Text& path_p2, const Text& source_p3, const Text& value_ty_p4, const Text& select_p5, const Text& moved_p6) {
    auto out = std::string();
    out.append("/// The `rebuild` at `");
    place(out, at_p1, std::nullopt);
    out.append("`: the old generation torn down (it ran to the end of the\n/// tick), the next built at `");
    place(out, path_p2, std::nullopt);
    out.append("` from the source after the tick.\nfn ");
    place(out, name_p0, std::nullopt);
    out.append("_build(self: &Rc<Self>, cx: &mut Cx) -> Done {\n    if let Some(old) = self.");
    place(out, name_p0, std::nullopt);
    out.append(".borrow_mut().take() {\n        old.leave_row(cx);\n        cx.leave_later(old);\n    }\n    let g = self.");
    place(out, name_p0, std::nullopt);
    out.append("_count.get();\n    self.");
    place(out, name_p0, std::nullopt);
    out.append("_count.set(g + 1);\n    let path = ");
    place(out, path_p2, std::nullopt);
    out.append(";\n    let value: ");
    place(out, value_ty_p4, std::nullopt);
    out.append(" = ");
    place(out, source_p3, std::nullopt);
    out.append(";\n    let row: Rc<dyn Row> = ");
    place(out, select_p5, std::nullopt);
    out.append(";\n    *self.");
    place(out, name_p0, std::nullopt);
    out.append(".borrow_mut() = Some(row);");
    place(out, moved_p6, std::nullopt);
    out.append("\n    Ok(())\n}\n");
    return Text(std::move(out));
}


/// RowImpl: fn Text, Text, Text -> Text
Text row_impl(const Text& name_p0, const Text& leaving_p1, const Text& hosted_p2) {
    auto out = std::string();
    out.append("impl Row for ");
    place(out, name_p0, std::nullopt);
    out.append(" {\n    fn leave_row(&self, cx: &mut Cx) {\n");
    place(out, leaving_p1, std::optional(8u));
    out.append("    }\n");
    place(out, hosted_p2, std::optional(4u));
    out.append("}\n");
    return Text(std::move(out));
}


/// AnswerType: fn Text, Text, Text, Text -> Text
Text answer_type(const Text& cases_p0, const Text& tags_p1, const Text& accessors_p2, const Text& decodes_p3) {
    auto out = std::string();
    out.append("/// `Answer c`: an answer to an element, typed by its tag (Semantics ch. 9): what a host\'s\n/// supplier answers a child place with, and what a World\'s answer to a forwarded element\n/// decodes to, carrying the tag\'s output.\n#[derive(Clone)]\npub enum Answer {\n");
    place(out, cases_p0, std::optional(4u));
    out.append("}\n\nimpl Answer {\n    /// The tag the answer is for.\n    pub fn tag(&self) -> &\'static str {\n        match self {\n");
    place(out, tags_p1, std::optional(12u));
    out.append("        }\n    }\n");
    place(out, accessors_p2, std::optional(4u));
    out.append("}\n\nimpl prism_rtl::AnswerOf<Elem> for Answer {\n    /// A World\'s answer to the element `e`, decoded by its tag.\n    fn decode(e: &Elem, v: &Pod) -> Result<Answer, Fault> {\n        match e {\n");
    place(out, decodes_p3, std::optional(12u));
    out.append("        }\n    }\n}\n");
    return Text(std::move(out));
}


/// AnswerGetter: fn Text, Text, Text, Text -> Text
Text answer_getter(const Text& accessor_p0, const Text& variant_p1, const Text& tag_name_p2, const Text& ty_p3) {
    auto out = std::string();
    out.append("/// A `");
    place(out, tag_name_p2, std::nullopt);
    out.append("`\'s answer.\npub fn ");
    place(out, accessor_p0, std::nullopt);
    out.append("(&self) -> Result<");
    place(out, ty_p3, std::nullopt);
    out.append(", Fault> {\n    match self {\n        Answer::");
    place(out, variant_p1, std::nullopt);
    out.append("(v) => Ok(v.clone()),\n        other => Err(Fault::answer(format!(\"an answer for {}, where ");
    place(out, tag_name_p2, std::nullopt);
    out.append("\'s was expected\", other.tag()))),\n    }\n}\n");
    return Text(std::move(out));
}


/// Answer: fn Text -> Text
Text answer(const Text& arms_p0) {
    auto out = std::string();
    out.append("fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {\n    match at {\n");
    place(out, arms_p0, std::optional(8u));
    out.append("        _ => return Err(Fault::answer(format!(\"no answering place at {}\", Path(at.to_vec())))),\n    }\n    Ok(())\n}\n");
    return Text(std::move(out));
}


/// Hook: fn Text, Text -> Text
Text hook(const Text& name_p0, const Text& body_p1) {
    auto out = std::string();
    out.append("fn ");
    place(out, name_p0, std::nullopt);
    out.append("(self: Rc<Self>, cx: &mut Cx) -> Done {\n");
    place(out, body_p1, std::optional(4u));
    out.append("    Ok(())\n}\n");
    return Text(std::move(out));
}


/// PushHook: fn Text -> Text
Text push_hook(const Text& body_p0) {
    auto out = std::string();
    out.append("fn push(self: Rc<Self>, element: &Pod, v: &Pod, cx: &mut Cx) -> Done {\n");
    place(out, body_p0, std::optional(4u));
    out.append("    Ok(())\n}\n");
    return Text(std::move(out));
}


/// Program: fn Text, Text, Text, Text, Text -> Text
Text program(const Text& name_p0, const Text& prism_p1, const Text& node_p2, const Text& decode_p3, const Text& call_p4) {
    auto out = std::string();
    out.append("/// The program of `@");
    place(out, prism_p1, std::nullopt);
    out.append("`: the root node and the runtime.\npub struct ");
    place(out, name_p0, std::nullopt);
    out.append(" {\n    rt: Runtime,\n    root: Rc<");
    place(out, node_p2, std::nullopt);
    out.append(">,\n}\n\nimpl Program for ");
    place(out, name_p0, std::nullopt);
    out.append(" {\n    fn build(args: &[Pod], ready: &dyn ReadyState) -> Result<(Self, TickOut), Fault> {\n");
    place(out, decode_p3, std::optional(8u));
    out.append("        let mut rt = Runtime::new();\n        let mut cx = rt.build(ready);\n        let root = ");
    place(out, call_p4, std::nullopt);
    out.append(";\n        let out = rt.close(cx)?;\n        Ok((");
    place(out, name_p0, std::nullopt);
    out.append(" { rt, root }, out))\n    }\n    fn tick(&mut self, input: &TickIn, ready: &dyn ReadyState) -> Result<TickOut, Fault> {\n        let root: Rc<dyn Node> = self.root.clone();\n        self.rt.tick(&root, input, ready)\n    }\n    fn compact(&mut self) {\n        self.rt.compact();\n    }\n}\n");
    return Text(std::move(out));
}


/// MatchBlock: fn Text, Text -> Text
Text match_block(const Text& scrut_p0, const Text& arms_p1) {
    auto out = std::string();
    out.append("match ");
    place(out, scrut_p0, std::nullopt);
    out.append(" {\n");
    place(out, arms_p1, std::optional(4u));
    out.append("}");
    return Text(std::move(out));
}


/// Block: fn Text, Text -> Text
Text block(const Text& stmts_p0, const Text& tail_p1) {
    auto out = std::string();
    out.append("{\n");
    place(out, stmts_p0, std::optional(4u));
    place(out, tail_p1, std::optional(4u));
    out.append("}");
    return Text(std::move(out));
}


/// Labeled: fn Text, Text, Text -> Text
Text labeled(const Text& label_p0, const Text& stmts_p1, const Text& tail_p2) {
    auto out = std::string();
    place(out, label_p0, std::nullopt);
    out.append(": {\n");
    place(out, stmts_p1, std::optional(4u));
    place(out, tail_p2, std::optional(4u));
    out.append("}");
    return Text(std::move(out));
}


/// If: fn Text, Text, Text -> Text
Text if_(const Text& cond_p0, const Text& then_x_p1, const Text& else_x_p2) {
    auto out = std::string();
    out.append("if ");
    place(out, cond_p0, std::nullopt);
    out.append(" {\n");
    place(out, then_x_p1, std::optional(4u));
    out.append("} else {\n");
    place(out, else_x_p2, std::optional(4u));
    out.append("}");
    return Text(std::move(out));
}


/// IfStmt: fn Text, Text -> Text
Text if_stmt(const Text& head_p0, const Text& body_p1) {
    auto out = std::string();
    place(out, head_p0, std::nullopt);
    out.append(" {\n");
    place(out, body_p1, std::optional(4u));
    out.append("}");
    return Text(std::move(out));
}


/// Scope: fn Text -> Text
Text scope(const Text& body_p0) {
    auto out = std::string();
    out.append("{\n");
    place(out, body_p0, std::optional(4u));
    out.append("}");
    return Text(std::move(out));
}


/// Else: fn Text -> Text
Text else_(const Text& body_p0) {
    auto out = std::string();
    out.append(" else {\n");
    place(out, body_p0, std::optional(4u));
    out.append("}");
    return Text(std::move(out));
}


/// ArmBlock: fn Text, Text -> Text
Text arm_block(const Text& pat_p0, const Text& body_p1) {
    auto out = std::string();
    place(out, pat_p0, std::nullopt);
    out.append(" => {\n");
    place(out, body_p1, std::optional(4u));
    out.append("}");
    return Text(std::move(out));
}


/// ChainArm: fn Text, Text, Text -> Text
Text chain_arm(const Text& head_p0, const Text& label_p1, const Text& body_p2) {
    auto out = std::string();
    out.append("if ");
    place(out, head_p0, std::nullopt);
    out.append(" {\n    break ");
    place(out, label_p1, std::nullopt);
    out.append(" ");
    place(out, body_p2, std::nullopt);
    out.append(";\n}");
    return Text(std::move(out));
}

}  // namespace crate::emit::rust::templates::items


// The module `Fs`, from `target/bootstrap/cpp-src/prismc/fs.prism`.
namespace crate::fs {

void Contents::show(Printer& p) const {
    p.record("Contents", {{"text", text}});
}

Pod Contents::to_pod() const {
    return Pod::record("Contents", {{"text", prism_rtl::to_pod(text)}});
}

Result<Contents> Contents::from_pod(const Pod& whole) {
    return Contents{.text = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "text"))))};
}


void FileRequest::show(Printer& p) const {
    if (auto c = std::get_if<Read>(&cases())) p.choice("Read", {});
    else if (auto c = std::get_if<Write>(&cases())) p.choice("Write", {c->a0});
}

Pod FileRequest::to_pod() const {
    return std::holds_alternative<Read>(cases()) ? Pod::choice("Read", {})
        : std::holds_alternative<Write>(cases()) ? Pod::choice("Write", {prism_rtl::to_pod(std::get<Write>(cases()).a0)})
        : Pod();
}

Result<FileRequest> FileRequest::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "Read" && c->args.size() == 0) return FileRequest(Read{});
        if (c->ctor == "Write" && c->args.size() == 1) return FileRequest(Write{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
    }
    return mismatch<FileRequest>("a FileRequest", p);
}


void WriteState::show(Printer& p) const {
    if (auto c = std::get_if<Writing>(&cases())) p.choice("Writing", {});
    else if (auto c = std::get_if<Written>(&cases())) p.choice("Written", {});
    else if (auto c = std::get_if<WriteFailed>(&cases())) p.choice("WriteFailed", {c->a0});
}

Pod WriteState::to_pod() const {
    return std::holds_alternative<Writing>(cases()) ? Pod::choice("Writing", {})
        : std::holds_alternative<Written>(cases()) ? Pod::choice("Written", {})
        : std::holds_alternative<WriteFailed>(cases()) ? Pod::choice("WriteFailed", {prism_rtl::to_pod(std::get<WriteFailed>(cases()).a0)})
        : Pod();
}

Result<WriteState> WriteState::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "Writing" && c->args.size() == 0) return WriteState(Writing{});
        if (c->ctor == "Written" && c->args.size() == 0) return WriteState(Written{});
        if (c->ctor == "WriteFailed" && c->args.size() == 1) return WriteState(WriteFailed{TRY(prism_rtl::from_pod<Error>(c->args[0]))});
    }
    return mismatch<WriteState>("a WriteState", p);
}


Pod FsContents::to_pod() const {
    return Pod::element(TAG, {{"path", prism_rtl::to_pod(path_)}});
}


void FsContents::show(Printer& p) const {
    prism_rtl::to_pod(*this).structure();
    Show<Pod>::show(prism_rtl::to_pod(*this), p);
}


Result<FsContents> FsContents::from_pod(const Pod& p) {
    if (auto t = p.tag(); t && *t == TAG) return FsContents{.path_ = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(p, "path"))))};
    return mismatch<FsContents>("a Fs.Contents", p);
}


Pod FsFile::to_pod() const {
    return Pod::element(TAG, {{"path", prism_rtl::to_pod(path_)}});
}


void FsFile::show(Printer& p) const {
    prism_rtl::to_pod(*this).structure();
    Show<Pod>::show(prism_rtl::to_pod(*this), p);
}


Result<FsFile> FsFile::from_pod(const Pod& p) {
    if (auto t = p.tag(); t && *t == TAG) return FsFile{.path_ = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(p, "path"))))};
    return mismatch<FsFile>("a Fs.File", p);
}


Pod FsList_::to_pod() const {
    return Pod::element(TAG, {{"dir", prism_rtl::to_pod(dir)}});
}


void FsList_::show(Printer& p) const {
    prism_rtl::to_pod(*this).structure();
    Show<Pod>::show(prism_rtl::to_pod(*this), p);
}


Result<FsList_> FsList_::from_pod(const Pod& p) {
    if (auto t = p.tag(); t && *t == TAG) return FsList_{.dir = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(p, "dir"))))};
    return mismatch<FsList_>("a Fs.List", p);
}


Pod FsOutput::to_pod() const {
    return Pod::element(TAG, {{"path", prism_rtl::to_pod(path_)}, {"text", prism_rtl::to_pod(text)}});
}


void FsOutput::show(Printer& p) const {
    prism_rtl::to_pod(*this).structure();
    Show<Pod>::show(prism_rtl::to_pod(*this), p);
}


Result<FsOutput> FsOutput::from_pod(const Pod& p) {
    if (auto t = p.tag(); t && *t == TAG) return FsOutput{.path_ = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(p, "path")))), .text = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(p, "text"))))};
    return mismatch<FsOutput>("a Fs.Output", p);
}

}  // namespace crate::fs


// The module `Lower`, from `target/bootstrap/cpp-src/prismc/lower/mod.prism`.
namespace crate::lower {

bool Lx::operator==(const Lx& o) const { return g == o.g && tys == o.tys && apps == o.apps && lifts == o.lifts && binders == o.binders && impls == o.impls && file == o.file && home == o.home && site == o.site && rs_mods == o.rs_mods && mod_segments == o.mod_segments && rs_names == o.rs_names && layouts == o.layouts && unbs == o.unbs && notes == o.notes && globals == o.globals && in_node == o.in_node && unshrunk == o.unshrunk && gens == o.gens && insts == o.insts && quants == o.quants && gen_of_q == o.gen_of_q && use_insts == o.use_insts && local_ids == o.local_ids && use_ids == o.use_ids && subst == o.subst && csubst == o.csubst; }

void Lx::show(Printer& p) const {
    p.record("Lx", {{"g", g}, {"tys", tys}, {"apps", apps}, {"lifts", lifts}, {"binders", binders}, {"impls", impls}, {"file", file}, {"home", home}, {"site", site}, {"rs_mods", rs_mods}, {"mod_segments", mod_segments}, {"rs_names", rs_names}, {"layouts", layouts}, {"unbs", unbs}, {"notes", notes}, {"globals", globals}, {"in_node", in_node}, {"unshrunk", unshrunk}, {"gens", gens}, {"insts", insts}, {"quants", quants}, {"gen_of_q", gen_of_q}, {"use_insts", use_insts}, {"local_ids", local_ids}, {"use_ids", use_ids}, {"subst", subst}, {"csubst", csubst}});
}

Pod Lx::to_pod() const {
    return Pod::record("Lx", {{"g", prism_rtl::to_pod(g)}, {"tys", prism_rtl::to_pod(tys)}, {"apps", prism_rtl::to_pod(apps)}, {"lifts", prism_rtl::to_pod(lifts)}, {"binders", prism_rtl::to_pod(binders)}, {"impls", prism_rtl::to_pod(impls)}, {"file", prism_rtl::to_pod(file)}, {"home", prism_rtl::to_pod(home)}, {"site", prism_rtl::to_pod(site)}, {"rs_mods", prism_rtl::to_pod(rs_mods)}, {"mod_segments", prism_rtl::to_pod(mod_segments)}, {"rs_names", prism_rtl::to_pod(rs_names)}, {"layouts", prism_rtl::to_pod(layouts)}, {"unbs", prism_rtl::to_pod(unbs)}, {"notes", prism_rtl::to_pod(notes)}, {"globals", prism_rtl::to_pod(globals)}, {"in_node", prism_rtl::to_pod(in_node)}, {"unshrunk", prism_rtl::to_pod(unshrunk)}, {"gens", prism_rtl::to_pod(gens)}, {"insts", prism_rtl::to_pod(insts)}, {"quants", prism_rtl::to_pod(quants)}, {"gen_of_q", prism_rtl::to_pod(gen_of_q)}, {"use_insts", prism_rtl::to_pod(use_insts)}, {"local_ids", prism_rtl::to_pod(local_ids)}, {"use_ids", prism_rtl::to_pod(use_ids)}, {"subst", prism_rtl::to_pod(subst)}, {"csubst", prism_rtl::to_pod(csubst)}});
}

Result<Lx> Lx::from_pod(const Pod& whole) {
    return Lx{.g = TRY(prism_rtl::from_pod<crate::check::env::G>(TRY(crate::prelude::field(whole, "g")))), .tys = TRY(prism_rtl::from_pod<Map<Text, crate::check::types::Ty>>(TRY(crate::prelude::field(whole, "tys")))), .apps = TRY(prism_rtl::from_pod<Map<Text, crate::check::typed::AppNote>>(TRY(crate::prelude::field(whole, "apps")))), .lifts = TRY(prism_rtl::from_pod<Map<Text, crate::check::typed::LiftNote>>(TRY(crate::prelude::field(whole, "lifts")))), .binders = TRY(prism_rtl::from_pod<Map<Text, crate::check::types::Ty>>(TRY(crate::prelude::field(whole, "binders")))), .impls = TRY(prism_rtl::from_pod<Map<Text, Array<crate::check::typed::ImplNote>>>(TRY(crate::prelude::field(whole, "impls")))), .file = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "file")))), .home = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "home")))), .site = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "site")))), .rs_mods = TRY(prism_rtl::from_pod<Map<Text, Text>>(TRY(crate::prelude::field(whole, "rs_mods")))), .mod_segments = TRY(prism_rtl::from_pod<Map<Text, bool>>(TRY(crate::prelude::field(whole, "mod_segments")))), .rs_names = TRY(prism_rtl::from_pod<Map<Text, Text>>(TRY(crate::prelude::field(whole, "rs_names")))), .layouts = TRY(prism_rtl::from_pod<Map<Text, Array<bool>>>(TRY(crate::prelude::field(whole, "layouts")))), .unbs = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "unbs")))), .notes = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "notes")))), .globals = TRY(prism_rtl::from_pod<Map<Text, bool>>(TRY(crate::prelude::field(whole, "globals")))), .in_node = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "in_node")))), .unshrunk = TRY(prism_rtl::from_pod<Map<Text, bool>>(TRY(crate::prelude::field(whole, "unshrunk")))), .gens = TRY(prism_rtl::from_pod<Map<Text, crate::check::typed::GenNote>>(TRY(crate::prelude::field(whole, "gens")))), .insts = TRY(prism_rtl::from_pod<Map<Text, Array<crate::check::typed::InstNote>>>(TRY(crate::prelude::field(whole, "insts")))), .quants = TRY(prism_rtl::from_pod<Map<Text, Text>>(TRY(crate::prelude::field(whole, "quants")))), .gen_of_q = TRY(prism_rtl::from_pod<Map<Text, crate::check::typed::GenNote>>(TRY(crate::prelude::field(whole, "gen_of_q")))), .use_insts = TRY(prism_rtl::from_pod<Map<Text, crate::check::typed::InstNote>>(TRY(crate::prelude::field(whole, "use_insts")))), .local_ids = TRY(prism_rtl::from_pod<Map<Text, Nat>>(TRY(crate::prelude::field(whole, "local_ids")))), .use_ids = TRY(prism_rtl::from_pod<Map<Text, Nat>>(TRY(crate::prelude::field(whole, "use_ids")))), .subst = TRY(prism_rtl::from_pod<Map<Text, crate::check::types::Ty>>(TRY(crate::prelude::field(whole, "subst")))), .csubst = TRY(prism_rtl::from_pod<Map<Text, crate::check::types::Col>>(TRY(crate::prelude::field(whole, "csubst"))))};
}


/// PlaceKey: fn Lx, Range -> Text
Text place_key(const Lx& lx_p0, const crate::syntax::Range& r_p1) {
    return prism_rtl::cat(lx_p0.file, ":", r_p1.start, ":", r_p1.end);
}


/// TypeAt: fn Lx, Range -> Ty
crate::check::types::Ty type_at(const Lx& lx_p0, const crate::syntax::Range& r_p1) {
    return subst_ty(lx_p0, or_(crate::prelude::get(lx_p0.tys, place_key(lx_p0, r_p1)), crate::check::types::Ty(crate::check::types::Ty::TyErr{})));
}


/// BinderTy: fn Lx, Range -> Ty
crate::check::types::Ty binder_ty(const Lx& lx_p0, const crate::syntax::Range& r_p1) {
    auto&& _m = crate::prelude::get(lx_p0.binders, place_key(lx_p0, r_p1));
    if (prism_rtl::is_some(_m)) {
        auto&& t_p2 = prism_rtl::some_of(_m);
        return subst_ty(lx_p0, t_p2);
    }
    if (prism_rtl::is_none(_m)) {
        return type_at(lx_p0, r_p1);
    }
    prism_rtl::unreachable("no arm matched");
}


/// SubstTy: fn Lx, Ty -> Ty
crate::check::types::Ty subst_ty(const Lx& lx_p0, const crate::check::types::Ty& t_p1) {
    return (len(keys(lx_p0.subst)) == Nat(0u)) && (len(keys(lx_p0.csubst)) == Nat(0u))
        ? t_p1
        : subst_ty_in(lx_p0, t_p1);
}


/// SubstTyIn: fn Lx, Ty -> Ty
crate::check::types::Ty subst_ty_in(const Lx& lx_p0, const crate::check::types::Ty& t_p1) {
    if (prism_rtl::is<crate::check::types::Ty::TyFlex>(t_p1)) {
        auto&& n_p2 = prism_rtl::as<crate::check::types::Ty::TyFlex>(t_p1).a0;
        return or_(crate::prelude::get(lx_p0.subst, prism_rtl::cat("\'", n_p2)), t_p1);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t_p1)) {
        auto&& n_p3 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a0;
        auto&& args_p4 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyCon{n_p3, each(args_p4, [&](const crate::check::types::Ty& a_p5) { return subst_ty_in(lx_p0, a_p5); })});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(t_p1)) {
        auto&& c_p6 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p1).a0;
        auto&& ps_p7 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p1).a1;
        auto&& res_p8 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p1).a2;
        return crate::check::types::Ty(crate::check::types::Ty::TyFn{inst_col(lx_p0, c_p6), each(ps_p7, [&](const crate::check::types::Ty& p_p9) { return subst_ty_in(lx_p0, p_p9); }), prism_rtl::rc(subst_ty_in(lx_p0, prism_rtl::deref(prism_rtl::deref(res_p8))))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t_p1)) {
        auto&& ts_pa = prism_rtl::as<crate::check::types::Ty::TyTuple>(t_p1).a0;
        return crate::check::types::Ty(crate::check::types::Ty::TyTuple{each(ts_pa, [&](const crate::check::types::Ty& a_pb) { return subst_ty_in(lx_p0, a_pb); })});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(t_p1)) {
        auto&& e_pc = prism_rtl::as<crate::check::types::Ty::TyArray>(t_p1).a0;
        return crate::check::types::Ty(crate::check::types::Ty::TyArray{prism_rtl::rc(subst_ty_in(lx_p0, prism_rtl::deref(prism_rtl::deref(e_pc))))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(t_p1)) {
        auto&& k_pd = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p1).a0;
        auto&& v_pe = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p1).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyMap{prism_rtl::rc(subst_ty_in(lx_p0, prism_rtl::deref(prism_rtl::deref(k_pd)))), prism_rtl::rc(subst_ty_in(lx_p0, prism_rtl::deref(prism_rtl::deref(v_pe))))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t_p1)) {
        auto&& s_pf = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a0;
        auto&& i_pg = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TySig{s_pf, prism_rtl::rc(subst_ty_in(lx_p0, prism_rtl::deref(prism_rtl::deref(i_pg))))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(t_p1)) {
        auto&& i_ph = prism_rtl::as<crate::check::types::Ty::TyAt>(t_p1).a0;
        auto&& rw_pi = prism_rtl::as<crate::check::types::Ty::TyAt>(t_p1).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyAt{prism_rtl::rc(subst_ty_in(lx_p0, prism_rtl::deref(prism_rtl::deref(i_ph)))), rw_pi});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(t_p1)) {
        auto&& rw_pj = prism_rtl::as<crate::check::types::Ty::TyElem>(t_p1).a0;
        auto&& o_pk = prism_rtl::as<crate::check::types::Ty::TyElem>(t_p1).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyElem{rw_pj, prism_rtl::rc(subst_ty_in(lx_p0, prism_rtl::deref(prism_rtl::deref(o_pk))))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAssoc>(t_p1)) {
        auto&& n_pl = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t_p1).a0;
        auto&& a_pm = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t_p1).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyAssoc{n_pl, prism_rtl::rc(subst_ty_in(lx_p0, prism_rtl::deref(prism_rtl::deref(a_pm))))});
    }
    {
        auto&& other_pn = t_p1;
        return other_pn;
    }
}


/// InstCol: fn Lx, Col -> Col
crate::check::types::Col inst_col(const Lx& lx_p0, const crate::check::types::Col& col1) {
    if (prism_rtl::is<crate::check::types::Col::CQ>(col1)) {
        auto&& q_p1 = prism_rtl::as<crate::check::types::Col::CQ>(col1).a0;
        return or_(crate::prelude::get(lx_p0.csubst, q_p1), crate::check::types::Col(crate::check::types::Col::CQ{q_p1}));
    }
    {
        auto&& c_p3 = col1;
        return c_p3;
    }
}


/// IsQuantCol: fn Lx, Col -> Bool
bool is_quant_col(const Lx& lx_p0, const crate::check::types::Col& col1) {
    if (prism_rtl::is<crate::check::types::Col::CQ>(col1)) {
        auto&& q_p1 = prism_rtl::as<crate::check::types::Col::CQ>(col1).a0;
        return crate::check::env::has_key(lx_p0.quants, q_p1);
    }
    {
        auto&& c_p3 = col1;
        return false;
    }
}


/// TypedTables: fn TProgram -> (((Text ==> Ty), (Text ==> AppNote), (Text ==> Ty), (Text ==> [ImplNote])))
std::tuple<Map<Text, crate::check::types::Ty>, Map<Text, crate::check::typed::AppNote>, Map<Text, crate::check::types::Ty>, Map<Text, Array<crate::check::typed::ImplNote>>> typed_tables(const crate::check::typed::TProgram& tp_p0) {
    auto tys_p1 = fold(tp_p0.exprs, Map<Text, crate::check::types::Ty>{}, [&](const Map<Text, crate::check::types::Ty>& m_p5, const crate::check::typed::TyNote& n_p6) { return insert(m_p5, crate::check::typed::at_key(prism_rtl::deref(n_p6).at), prism_rtl::deref(n_p6).ty); });
    auto apps_p2 = fold(tp_p0.apps, Map<Text, crate::check::typed::AppNote>{}, [&](const Map<Text, crate::check::typed::AppNote>& m_p7, const crate::check::typed::AppNote& n_p8) { return insert(m_p7, crate::check::typed::at_key(prism_rtl::deref(n_p8).at), n_p8); });
    auto bs_p3 = fold(tp_p0.binders, Map<Text, crate::check::types::Ty>{}, [&](const Map<Text, crate::check::types::Ty>& m_p9, const crate::check::typed::BinderNote& n_pa) { return insert(m_p9, crate::check::typed::at_key(prism_rtl::deref(n_pa).at), prism_rtl::deref(n_pa).ty); });
    auto ims_p4 = fold(tp_p0.impls, Map<Text, Array<crate::check::typed::ImplNote>>{}, [&](const Map<Text, Array<crate::check::typed::ImplNote>>& m_pb, const crate::check::typed::ImplNote& n_pc) { return insert(m_pb, crate::check::typed::at_key(prism_rtl::deref(n_pc).at), crate::prelude::push(or_(crate::prelude::get(m_pb, crate::check::typed::at_key(prism_rtl::deref(n_pc).at)), Array<crate::check::typed::ImplNote>{}), n_pc)); });
    return std::tuple{tys_p1, apps_p2, bs_p3, ims_p4};
}


/// let rustKeywords
Array<Text> rust_keywords() {
    return Array(std::vector{Text::lit("as"), Text::lit("async"), Text::lit("await"), Text::lit("box"), Text::lit("break"), Text::lit("const"), Text::lit("continue"), Text::lit("crate"), Text::lit("do"), Text::lit("dyn"), Text::lit("else"), Text::lit("enum"), Text::lit("extern"), Text::lit("false"), Text::lit("final"), Text::lit("fn"), Text::lit("for"), Text::lit("gen"), Text::lit("if"), Text::lit("impl"), Text::lit("in"), Text::lit("let"), Text::lit("loop"), Text::lit("macro"), Text::lit("match"), Text::lit("mod"), Text::lit("move"), Text::lit("mut"), Text::lit("override"), Text::lit("priv"), Text::lit("pub"), Text::lit("ref"), Text::lit("return"), Text::lit("self"), Text::lit("static"), Text::lit("struct"), Text::lit("super"), Text::lit("trait"), Text::lit("true"), Text::lit("try"), Text::lit("type"), Text::lit("typeof"), Text::lit("unsafe"), Text::lit("unsized"), Text::lit("use"), Text::lit("virtual"), Text::lit("where"), Text::lit("while"), Text::lit("yield"), Text::lit("u8"), Text::lit("u16"), Text::lit("u32"), Text::lit("u64"), Text::lit("i8"), Text::lit("i16"), Text::lit("i32"), Text::lit("i64"), Text::lit("f32"), Text::lit("f64"), Text::lit("bool"), Text::lit("char"), Text::lit("str"), Text::lit("usize"), Text::lit("isize"), Text::lit("cx"), Text::lit("node"), Text::lit("path"), Text::lit("v"), Text::lit("p")});
}


/// Base: fn Text -> Text
Text base(const Text& name_p0) {
    return crate::syntax::lexer::chars::drop_prefix(name_p0, crate::check::types::unify::marks_of(name_p0));
}


/// Snake: fn Text -> Text
Text snake(const Text& name_p0) {
    auto&& _out_p6 = crate::syntax::lexer::chars::fold_chars(base(name_p0), std::tuple{Text::lit(""), Text::lit("")}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, Text>>(std::tuple<std::tuple<Text, Text>, Text>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Text, Text>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return once_job([=]() {
            return ({
                auto [acc_p2, prev_p3] = p0;
                auto c_p4 = p1;
                ({
                auto sep_p5 = crate::syntax::lexer::chars::is_upper(c_p4) && (crate::syntax::lexer::chars::is_lower(prev_p3) || crate::syntax::lexer::chars::is_digit(prev_p3))
                    ? Text::lit("_")
                    : Text::lit("");
                (prism_rtl::finished(std::tuple{prism_rtl::cat(acc_p2, sep_p5, lower_char(c_p4)), c_p4}));
            });
            });
        });
    })));
    auto&& out_p6 = std::get<0>(_out_p6);
    auto plain_p1 = out_p6 == Text::lit("") ? Text::lit("x") : out_p6;
    return crate::check::types::has_text(rust_keywords(), plain_p1)
        ? prism_rtl::cat(plain_p1, "_")
        : plain_p1;
}


/// LowerChar: fn Text -> Text
Text lower_char(const Text& c_p0) {
    return crate::syntax::lexer::chars::is_upper(c_p0)
        ? crate::prelude::lower(c_p0)
        : c_p0;
}


/// Camel: fn Text -> Text
Text camel(const Text& name_p0) {
    auto b_p1 = base(name_p0);
    auto first_p2 = crate::syntax::lexer::chars::head(b_p1);
    auto fixed_p3 = crate::syntax::lexer::chars::is_lower(first_p2)
        ? prism_rtl::cat(upper(first_p2), crate::syntax::lexer::chars::after_first(b_p1))
        : b_p1;
    return (fixed_p3 == Text::lit("Self")) || crate::check::types::has_text(runtime_names(), fixed_p3)
        ? prism_rtl::cat(fixed_p3, "_")
        : fixed_p3;
}


/// let runtimeNames
Array<Text> runtime_names() {
    return Array(std::vector{Text::lit("AnswerOf"), Text::lit("BigInt"), Text::lit("Blueprint"), Text::lit("Box"), Text::lit("Built"), Text::lit("Cache"), Text::lit("Case"), Text::lit("Cell"), Text::lit("Clickable"), Text::lit("Collector"), Text::lit("Cursor"), Text::lit("Cx"), Text::lit("Defer"), Text::lit("Demand"), Text::lit("Document"), Text::lit("Done"), Text::lit("DynShow"), Text::lit("Dynamic"), Text::lit("Edit"), Text::lit("Err"), Text::lit("Event"), Text::lit("F64"), Text::lit("Fallible"), Text::lit("Fields"), Text::lit("Finishing"), Text::lit("Fn"), Text::lit("Forward"), Text::lit("FromPod"), Text::lit("Gathered"), Text::lit("Gen"), Text::lit("Handle"), Text::lit("Hold"), Text::lit("Host"), Text::lit("HostOf"), Text::lit("HostRow"), Text::lit("Inert"), Text::lit("IsShared"), Text::lit("IsValue"), Text::lit("Job"), Text::lit("JobRef"), Text::lit("Later"), Text::lit("Link"), Text::lit("List"), Text::lit("Live"), Text::lit("MakeNew"), Text::lit("MutElements"), Text::lit("Nanos"), Text::lit("NeverEvent"), Text::lit("NewSnapshot"), Text::lit("Node"), Text::lit("NodeRef"), Text::lit("None"), Text::lit("Ok"), Text::lit("OkUnit"), Text::lit("Option"), Text::lit("Outcome"), Text::lit("Panic"), Text::lit("Patch"), Text::lit("Path"), Text::lit("Pattern"), Text::lit("Pod"), Text::lit("Port"), Text::lit("Pos"), Text::lit("Printer"), Text::lit("Program"), Text::lit("Rc"), Text::lit("ReadyMap"), Text::lit("ReadyState"), Text::lit("RefCell"), Text::lit("Report"), Text::lit("Request"), Text::lit("Result"), Text::lit("Row"), Text::lit("Rows"), Text::lit("Runtime"), Text::lit("Scope"), Text::lit("Segment"), Text::lit("ShowRef"), Text::lit("ShownText"), Text::lit("Sink"), Text::lit("Slot"), Text::lit("Snapshot"), Text::lit("Some"), Text::lit("Stamped"), Text::lit("String"), Text::lit("Subscribed"), Text::lit("Subscriber"), Text::lit("Supplied"), Text::lit("Supplier"), Text::lit("TestWorld"), Text::lit("Tick"), Text::lit("TickIn"), Text::lit("TickOut"), Text::lit("ToPod"), Text::lit("Unexpected"), Text::lit("Unit"), Text::lit("Vec"), Text::lit("Weak"), Text::lit("World"), Text::lit("XorShift")});
}


/// let runtimeFns
Map<Text, bool> runtime_fns() {
    return fold(Array(std::vector{Text::lit("abs"), Text::lit("after"), Text::lit("append"), Text::lit("as"), Text::lit("ask"), Text::lit("at"), Text::lit("at_mut"), Text::lit("at_mut_map"), Text::lit("back"), Text::lit("before"), Text::lit("call_then"), Text::lit("call_value"), Text::lit("case_unicode_version"), Text::lit("cat"), Text::lit("char_is_alphabetic"), Text::lit("char_is_alphanumeric"), Text::lit("char_is_uppercase"), Text::lit("char_is_whitespace"), Text::lit("char_of"), Text::lit("cloned"), Text::lit("compare"), Text::lit("concat"), Text::lit("cos"), Text::lit("cursor_at"), Text::lit("deref"), Text::lit("diff"), Text::lit("display"), Text::lit("div"), Text::lit("drive"), Text::lit("drop"), Text::lit("dynamic_blueprint"), Text::lit("dynamic_of"), Text::lit("each"), Text::lit("each_job"), Text::lit("each_map"), Text::lit("each_map_job"), Text::lit("element_blueprint"), Text::lit("entered"), Text::lit("enumerate"), Text::lit("event_blueprint"), Text::lit("event_of"), Text::lit("expect"), Text::lit("field"), Text::lit("filter"), Text::lit("filter_job"), Text::lit("filter_map"), Text::lit("filter_map_job"), Text::lit("filter_some"), Text::lit("find"), Text::lit("find_clickables"), Text::lit("finished"), Text::lit("first"), Text::lit("float"), Text::lit("float_"), Text::lit("float_digits"), Text::lit("fmap"), Text::lit("fold"), Text::lit("fold_from"), Text::lit("fold_job"), Text::lit("fold_map"), Text::lit("fold_map_job"), Text::lit("for_each"), Text::lit("for_turns"), Text::lit("for_turns_indexed"), Text::lit("for_turns_keyed"), Text::lit("forward_on_none"), Text::lit("freeze"), Text::lit("from_pod"), Text::lit("front"), Text::lit("get"), Text::lit("host_new"), Text::lit("ignore"), Text::lit("index"), Text::lit("indexed"), Text::lit("insert"), Text::lit("int"), Text::lit("int_"), Text::lit("is"), Text::lit("is_err"), Text::lit("is_none"), Text::lit("is_ok"), Text::lit("is_some"), Text::lit("iter_mut"), Text::lit("ix"), Text::lit("keys"), Text::lit("len"), Text::lit("len_map"), Text::lit("len_text"), Text::lit("loop_job"), Text::lit("loop_turns"), Text::lit("lower"), Text::lit("make_new"), Text::lit("make_rc"), Text::lit("map"), Text::lit("map_job"), Text::lit("map_of"), Text::lit("match_"), Text::lit("matches"), Text::lit("max"), Text::lit("min"), Text::lit("mismatch"), Text::lit("mismatch_fault"), Text::lit("mod_"), Text::lit("more"), Text::lit("named"), Text::lit("nat"), Text::lit("nat_of"), Text::lit("never_blueprint"), Text::lit("never_event"), Text::lit("new_rows"), Text::lit("next"), Text::lit("numbered"), Text::lit("ok"), Text::lit("ok_or"), Text::lit("on_big_stack"), Text::lit("once_job"), Text::lit("or"), Text::lit("or_"), Text::lit("pairs_of"), Text::lit("panic"), Text::lit("parse_nat_opt"), Text::lit("parse_nat_try"), Text::lit("path_of"), Text::lit("place"), Text::lit("plain_blueprint"), Text::lit("print_path"), Text::lit("print_tick"), Text::lit("push"), Text::lit("rc"), Text::lit("rc_placed"), Text::lit("rc_static_cast"), Text::lit("read_file"), Text::lit("regex"), Text::lit("remove"), Text::lit("replace"), Text::lit("run_canvas"), Text::lit("run_cli"), Text::lit("run_scripts"), Text::lit("run_to_end"), Text::lit("set_index"), Text::lit("set_key"), Text::lit("share"), Text::lit("show"), Text::lit("show_ref"), Text::lit("show_text"), Text::lit("sign"), Text::lit("sin"), Text::lit("size"), Text::lit("snapshot"), Text::lit("some_of"), Text::lit("split"), Text::lit("split_on"), Text::lit("step"), Text::lit("step_back"), Text::lit("str"), Text::lit("strip_comment_header"), Text::lit("subscribe_row"), Text::lit("sum"), Text::lit("take"), Text::lit("text"), Text::lit("text_lower"), Text::lit("text_upper"), Text::lit("to_float"), Text::lit("to_pod"), Text::lit("to_string"), Text::lit("u8_"), Text::lit("unexpected"), Text::lit("union"), Text::lit("union_"), Text::lit("unreachable"), Text::lit("unwrap_or_default"), Text::lit("upgrade"), Text::lit("upper"), Text::lit("utf8_decode"), Text::lit("utf8_encode"), Text::lit("utf8_error_at"), Text::lit("utf8_push"), Text::lit("values"), Text::lit("weaken"), Text::lit("world_option")}), Map<Text, bool>{}, [&](const Map<Text, bool>& m_p0, const Text& n_p1) { return insert(m_p0, n_p1, true); });
}


/// Unclash: fn Text -> Text
Text unclash(const Text& n_p0) {
    auto n1_p1 = crate::check::env::has_key(runtime_fns(), n_p0)
        ? prism_rtl::cat(n_p0, "_")
        : n_p0;
    return crate::check::env::has_key(runtime_fns(), n1_p1)
        ? prism_rtl::cat(n1_p1, "_")
        : n1_p1;
}


/// RustModName: fn Text -> Text
Text rust_mod_name(const Text& m_p0) {
    return m_p0 == Text::lit("")
        ? Text::lit("program")
        : crate::syntax::lexer::chars::join(each(split_on(m_p0, Text::lit(".")), [&](const Text& s_p1) { return mod_segment(s_p1); }), Text::lit("::"));
}


/// ModSegment: fn Text -> Text
Text mod_segment(const Text& s_p0) {
    auto n_p1 = snake(s_p0);
    return crate::check::types::has_text(cpp_keywords(), n_p1)
        ? prism_rtl::cat(n_p1, "_")
        : n_p1;
}


/// let cppKeywords
Array<Text> cpp_keywords() {
    return Array(std::vector{Text::lit("explicit"), Text::lit("and"), Text::lit("and_eq"), Text::lit("asm"), Text::lit("auto"), Text::lit("bitand"), Text::lit("bitor"), Text::lit("bool"), Text::lit("case"), Text::lit("catch"), Text::lit("char"), Text::lit("char8_t"), Text::lit("char16_t"), Text::lit("char32_t"), Text::lit("class"), Text::lit("compl"), Text::lit("concept"), Text::lit("const_cast"), Text::lit("consteval"), Text::lit("constexpr"), Text::lit("constinit"), Text::lit("co_await"), Text::lit("co_return"), Text::lit("co_yield"), Text::lit("decltype"), Text::lit("default"), Text::lit("delete"), Text::lit("double"), Text::lit("dynamic_cast"), Text::lit("explicit"), Text::lit("export"), Text::lit("extern"), Text::lit("float"), Text::lit("friend"), Text::lit("goto"), Text::lit("inline"), Text::lit("int"), Text::lit("long"), Text::lit("mutable"), Text::lit("namespace"), Text::lit("new"), Text::lit("noexcept"), Text::lit("not"), Text::lit("not_eq"), Text::lit("nullptr"), Text::lit("operator"), Text::lit("or"), Text::lit("or_eq"), Text::lit("private"), Text::lit("protected"), Text::lit("public"), Text::lit("register"), Text::lit("reinterpret_cast"), Text::lit("requires"), Text::lit("short"), Text::lit("signed"), Text::lit("sizeof"), Text::lit("static_assert"), Text::lit("static_cast"), Text::lit("switch"), Text::lit("template"), Text::lit("this"), Text::lit("thread_local"), Text::lit("throw"), Text::lit("try"), Text::lit("typedef"), Text::lit("typeid"), Text::lit("typename"), Text::lit("union"), Text::lit("unsigned"), Text::lit("using"), Text::lit("virtual"), Text::lit("void"), Text::lit("volatile"), Text::lit("wchar_t"), Text::lit("xor"), Text::lit("xor_eq"), Text::lit("errno"), Text::lit("assert"), Text::lit("NULL"), Text::lit("EOF"), Text::lit("stdin"), Text::lit("stdout"), Text::lit("stderr"), Text::lit("major"), Text::lit("minor")});
}


/// PathIn: fn Lx, Text, Text -> Text
Text path_in(const Lx& lx_p0, const Text& owner_p1, const Text& name_p2) {
    return owner_p1 == lx_p0.site
        ? name_p2
        : owner_p1 == Text::lit("Prelude")
        ? prelude_path(lx_p0, name_p2)
        : prism_rtl::cat("crate::", or_(crate::prelude::get(lx_p0.rs_mods, owner_p1), rust_mod_name(owner_p1)), "::", name_p2);
}


/// PreludePath: fn Lx, Text -> Text
Text prelude_path(const Lx& lx_p0, const Text& name_p1) {
    return crate::check::env::has_key(lx_p0.globals, prism_rtl::cat(lx_p0.site, ".", name_p1)) || crate::check::env::has_key(lx_p0.mod_segments, name_p1)
        ? prism_rtl::cat("crate::prelude::", name_p1)
        : name_p1;
}


/// ValueNames: fn G -> (Text ==> Text)
Map<Text, Text> value_names(const crate::check::env::G& g_p0) {
    auto lets_p1 = fold(g_p0.defs, Array<Text>{}, [&](const Array<Text>& acc_p4, const crate::check::env::Def& d_p5) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = prism_rtl::deref(d_p5).body;
            if (prism_rtl::is<crate::check::env::DefBody::DbLet>(_m)) {
                _v.set(crate::check::types::add_text(acc_p4, prism_rtl::deref(d_p5).qk));
                goto _done;
            }
            {
                _v.set(acc_p4);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto keys_p2 = crate::check::types::union_texts(keys(g_p0.vals), lets_p1);
    auto bases_p3 = fold(keys_p2, Map<Text, Array<Text>>{}, [&](const Map<Text, Array<Text>>& m_p6, const Text& k_p7) { return insert(m_p6, base_key(k_p7), crate::prelude::push(or_(crate::prelude::get(m_p6, base_key(k_p7)), Array<Text>{}), k_p7)); });
    return fold(keys_p2, Map<Text, Text>{}, [&](const Map<Text, Text>& m_p8, const Text& k_p9) {
        return ({
            auto name_pa = value_name(k_p9, len(or_(crate::prelude::get(bases_p3, base_key(k_p9)), Array<Text>{})));
            auto runtimes_pb = (owner_of(k_p9) == Text::lit("Prelude")) || ({
                __label__ _done;
                prism_rtl::Slot<bool> _v;
                auto&& _m = crate::prelude::get(g_p0.vals, k_p9);
                if (prism_rtl::is_some(_m)) {
                    auto&& v_pc = prism_rtl::some_of(_m);
                    _v.set((prism_rtl::deref(v_pc).sort == Text::lit("builtin")) || (prism_rtl::deref(v_pc).home == Text::lit("Prelude")));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(false);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            insert(m_p8, k_p9, std::move(runtimes_pb) ? name_pa : unclash(name_pa));
        });
    });
}


/// GlobalNames: fn G -> (Text ==> Bool)
Map<Text, bool> global_names(const crate::check::env::G& g_p0) {
    auto names_p1 = value_names(g_p0);
    return fold(keys(names_p1), Map<Text, bool>{}, [&](const Map<Text, bool>& m_p2, const Text& k_p3) { return insert(m_p2, prism_rtl::cat(owner_of(k_p3), ".", or_(crate::prelude::get(names_p1, k_p3), Text::lit(""))), true); });
}


/// LocalName: fn Lx, Text -> Text
Text local_name(const Lx& lx_p0, const Text& nkey_p1) {
    auto marks_p2 = crate::check::types::unify::marks_of(nkey_p1);
    auto base_p3 = snake(nkey_p1);
    auto bare_p4 = crate::syntax::lexer::chars::drop_prefix(nkey_p1, marks_p2);
    auto s0_p5 = crate::syntax::lexer::chars::contains(marks_p2, Text::lit("?"))
        ? prism_rtl::cat(base_p3, "_opt")
        : crate::syntax::lexer::chars::contains(marks_p2, Text::lit("~"))
        ? prism_rtl::cat(base_p3, "_try")
        : base_p3;
    auto s1_p6 = crate::check::env::is_upper_text(crate::syntax::lexer::chars::head(bare_p4))
        ? prism_rtl::cat(s0_p5, "_fn")
        : s0_p5;
    return unclash(crate::check::env::has_key(lx_p0.globals, prism_rtl::cat(lx_p0.site, ".", s1_p6)) || crate::check::env::has_key(lx_p0.globals, prism_rtl::cat("Prelude.", s1_p6))
        ? prism_rtl::cat(s1_p6, "_")
        : s1_p6);
}


/// LocalNameAt: unbounded fn Lx, Text, Range -> Text
Text local_name_at(const Lx& lx_p0, const Text& nkey_p1, const crate::syntax::Range& span_p2) {
    auto&& _m = crate::prelude::get(lx_p0.local_ids, place_key(lx_p0, span_p2));
    if (prism_rtl::is_some(_m)) {
        auto&& id_p3 = prism_rtl::some_of(_m);
        return prism_rtl::cat(local_base(nkey_p1), "_", kind_letter(binder_ty(lx_p0, span_p2)), base32(id_p3));
    }
    if (prism_rtl::is_none(_m)) {
        return local_name(lx_p0, nkey_p1);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Text> LocalNameAt::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& nkey_p1 = this->nkey_p1;
    const auto& span_p2 = this->span_p2;
    return ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(lx_p0).local_ids, place_key(lx_p0, span_p2));
        prism_rtl::is_some(_m) ? ({
        auto&& id_p3 = prism_rtl::some_of(_m);
        ({
        auto lx_p0_1 = lx_p0;
        auto nkey_p1_2 = nkey_p1;
        auto span_p2_3 = span_p2;
        call_then(start_local_base(nkey_p1_2), [=, lx_p0_1 = std::move(lx_p0_1), span_p2_3 = std::move(span_p2_3)](Text local_base_17647) { return call_then(start_base32(id_p3), [=](Text base32_17696) { return prism_rtl::finished(prism_rtl::cat(local_base_17647, "_", kind_letter(binder_ty(lx_p0_1, span_p2_3)), base32_17696)); }); });
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(local_name(lx_p0, nkey_p1))
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start LocalNameAt, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_local_name_at(Lx lx_p0, Text nkey_p1, crate::syntax::Range span_p2) {
    return prism_rtl::make_rc<LocalNameAt>(lx_p0, nkey_p1, span_p2);
}


/// LocalBase: unbounded fn Text -> Text
Text local_base(const Text& nkey_p0) {
    auto bare_p1 = crate::syntax::lexer::chars::drop_prefix(nkey_p0, crate::check::types::unify::marks_of(nkey_p0));
    auto base_p2 = snake(bare_p1);
    auto trimmed_p3 = trim_underscores(base_p2);
    return trimmed_p3 == Text::lit("") ? Text::lit("topic") : trimmed_p3;
}


prism_rtl::Turn<Text> LocalBase::cycle() const {
    const auto& nkey_p0 = this->nkey_p0;
    auto bare_p1 = crate::syntax::lexer::chars::drop_prefix(nkey_p0, crate::check::types::unify::marks_of(nkey_p0));
    auto base_p2 = snake(bare_p1);
    return call_then(start_trim_underscores(base_p2), [=](Text trim_underscores_18021) {
        return ({
            auto trimmed_p3 = trim_underscores_18021;
            trimmed_p3 == Text::lit("")
            ? prism_rtl::finished(Text::lit("topic"))
            : prism_rtl::finished(trimmed_p3);
        });
    });
}


/// `Start LocalBase, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_local_base(Text nkey_p0) {
    return prism_rtl::make_rc<LocalBase>(nkey_p0);
}


/// TrimUnderscores: unbounded fn Text -> Text
Text trim_underscores(const Text& t_p0) {
    auto&& _m = crate::syntax::lexer::chars::before_suffix(t_p0, Text::lit("_"));
    if (prism_rtl::is_some(_m)) {
        auto&& s_p1 = prism_rtl::some_of(_m);
        return trim_underscores(s_p1);
    }
    if (prism_rtl::is_none(_m)) {
        return t_p0;
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Text> TrimUnderscores::cycle() const {
    const auto& t_p0 = this->t_p0;
    return ({
        auto&& _m = crate::syntax::lexer::chars::before_suffix(t_p0, Text::lit("_"));
        prism_rtl::is_some(_m) ? ({
        auto&& s_p1 = prism_rtl::some_of(_m);
        prism_rtl::more(prism_rtl::rc(TrimUnderscores(s_p1)));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(t_p0)
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start TrimUnderscores, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_trim_underscores(Text t_p0) {
    return prism_rtl::make_rc<TrimUnderscores>(t_p0);
}


/// KindLetter: fn Ty -> Text
Text kind_letter(const crate::check::types::Ty& t_p0) {
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t_p0)) {
        auto&& m18427_0_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t_p0).a0;
        if (m18427_0_0 == Text::lit("!")) {
            return Text::lit("e");
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t_p0)) {
        auto&& m18427_1_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t_p0).a0;
        if (m18427_1_0 == Text::lit("$")) {
            return Text::lit("d");
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t_p0)) {
        auto&& m18427_2_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t_p0).a0;
        if (m18427_2_0 == Text::lit("?")) {
            return Text::lit("o");
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t_p0)) {
        auto&& m18427_3_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t_p0).a0;
        if (m18427_3_0 == Text::lit("~")) {
            return Text::lit("r");
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t_p0)) {
        auto&& m18427_4_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t_p0).a0;
        auto&& i_p1 = prism_rtl::as<crate::check::types::Ty::TySig>(t_p0).a1;
        if (m18427_4_0 == Text::lit("&")) {
            return kind_letter(prism_rtl::deref(prism_rtl::deref(i_p1)));
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(t_p0)) {
        return Text::lit("b");
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(t_p0)) {
        return Text::lit("f");
    }
    {
        return Text::lit("p");
    }
}


/// Base32: unbounded fn Nat -> Text
Text base32(const Nat& n_p0) {
    auto digit_p1 = crate::syntax::lexer::chars::char_at_byte(Text::lit("0123456789abcdefghijklmnopqrstuv"), or_(mod_(n_p0, Nat(32u)), Nat(0u)));
    auto&& _m = div(n_p0, Nat(32u));
    if (prism_rtl::is_some(_m)) {
        auto&& q_p2 = prism_rtl::some_of(_m);
        if (q_p2 > Nat(0u)) {
            return prism_rtl::cat(base32(q_p2), digit_p1);
        }
    }
    {
        return digit_p1;
    }
}


prism_rtl::Turn<Text> Base32::cycle() const {
    const auto& n_p0 = this->n_p0;
    auto digit_p1 = crate::syntax::lexer::chars::char_at_byte(Text::lit("0123456789abcdefghijklmnopqrstuv"), or_(mod_(n_p0, Nat(32u)), Nat(0u)));
    return ({
        auto&& _m = div(n_p0, Nat(32u));
        prism_rtl::is_some(_m) && ({
        auto&& q_p2 = prism_rtl::some_of(_m);
        (q_p2 > Nat(0u));
    }) ? ({
        auto&& q_p2 = prism_rtl::some_of(_m);
        call_then(start_base32(q_p2), [=](Text base32_18893) { return prism_rtl::finished(prism_rtl::cat(base32_18893, digit_p1)); });
    })
        : prism_rtl::finished(digit_p1);
    });
}


/// `Start Base32, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_base32(Nat n_p0) {
    return prism_rtl::make_rc<Base32>(n_p0);
}


/// BaseKey: fn Text -> Text
Text base_key(const Text& k_p0) {
    auto parts_p1 = split_on(k_p0, Text::lit("."));
    auto last_p2 = or_(crate::syntax::lexer::chars::last(parts_p1), k_p0);
    return prism_rtl::cat(crate::syntax::lexer::chars::join(take(parts_p1, crate::syntax::lexer::chars::dec(len(parts_p1))), Text::lit(".")), ".", snake(last_p2));
}


/// ValueName: fn Text, Nat -> Text
Text value_name(const Text& k_p0, const Nat& count_p1) {
    auto last_p2 = crate::check::types::bare_name(k_p0);
    auto marks_p3 = crate::check::types::unify::marks_of(last_p2);
    auto base_p4 = snake(last_p2);
    return (count_p1 > Nat(1u)) && (marks_p3 != Text::lit(""))
        ? prism_rtl::cat(base_p4, "_", sigil_word(crate::syntax::lexer::chars::head(marks_p3)))
        : (count_p1 > Nat(1u)) && (!crate::check::env::is_upper_text(crate::syntax::lexer::chars::head(last_p2)))
        ? prism_rtl::cat(base_p4, "_value")
        : base_p4;
}


/// SigilWord: fn Text -> Text
Text sigil_word(const Text& text0) {
    {
        auto&& c0_0 = text0;
        if (c0_0 == Text::lit("?")) {
            return Text::lit("opt");
        }
    }
    {
        auto&& c1_0 = text0;
        if (c1_0 == Text::lit("~")) {
            return Text::lit("try");
        }
    }
    {
        auto&& c2_0 = text0;
        if (c2_0 == Text::lit("!")) {
            return Text::lit("ev");
        }
    }
    {
        auto&& c3_0 = text0;
        if (c3_0 == Text::lit("$")) {
            return Text::lit("dyn");
        }
    }
    {
        auto&& c4_0 = text0;
        if (c4_0 == Text::lit("@")) {
            return Text::lit("widget");
        }
    }
    {
        auto&& c5_0 = text0;
        if (c5_0 == Text::lit("&")) {
            return Text::lit("ref");
        }
    }
    {
        auto&& other_p0 = text0;
        return Text::lit("x");
    }
}


/// ValuePath: fn Lx, Text -> Text
Text value_path(const Lx& lx_p0, const Text& qk_p1) {
    auto owner_p2 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = crate::prelude::get(prism_rtl::deref(lx_p0.g).vals, qk_p1);
        if (prism_rtl::is_some(_m)) {
            auto&& v_p3 = prism_rtl::some_of(_m);
            _v.set(prism_rtl::deref(v_p3).home);
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(owner_of(qk_p1));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return path_in(lx_p0, owner_p2, or_(crate::prelude::get(lx_p0.rs_names, qk_p1), snake(crate::check::types::bare_name(qk_p1))));
}


/// OwnerOf: fn Text -> Text
Text owner_of(const Text& qk_p0) {
    auto parts_p1 = split_on(qk_p0, Text::lit("."));
    return crate::syntax::lexer::chars::join(take(parts_p1, crate::syntax::lexer::chars::dec(len(parts_p1))), Text::lit("."));
}


/// TagStruct: fn Text -> Text
Text tag_struct(const Text& tn_p0) {
    return concat(each(split_on(tn_p0, Text::lit(".")), [&](const Text& p_p1) { return camel(p_p1); }));
}

}  // namespace crate::lower
