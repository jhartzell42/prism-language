// The module `Compile`: its types, nodes and jobs declared, and its choices' handles, emitted by
// prismc (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace compile {

struct CompileJob;

struct Compiled;

struct CompileProgram;

}  // namespace compile


}  // namespace crate
