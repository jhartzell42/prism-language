// The module `Compile`, from `target/bootstrap/cpp-src/prismc/compile.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (claude/backend.md). Edit the Prism source, not this file.
#include <compile/module.hpp>
#include <reading/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

namespace crate::compile {

void CompileJob::show(Printer& p) const {
    p.record("CompileJob", {{"read", read}, {"name", name}, {"runtime", runtime}, {"target", target}});
}

Pod CompileJob::to_pod() const {
    return Pod::record("CompileJob", {{"read", prism_rtl::to_pod(read)}, {"name", prism_rtl::to_pod(name)}, {"runtime", prism_rtl::to_pod(runtime)}, {"target", prism_rtl::to_pod(target)}});
}

Result<CompileJob> CompileJob::from_pod(const Pod& whole) {
    return CompileJob{.read = TRY(prism_rtl::from_pod<crate::reading::ReadInput>(TRY(crate::prelude::field(whole, "read")))), .name = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .runtime = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "runtime")))), .target = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "target"))))};
}


void Compiled::show(Printer& p) const {
    p.record("Compiled", {{"files", files}, {"failed", failed}, {"report", report}});
}

Pod Compiled::to_pod() const {
    return Pod::record("Compiled", {{"files", prism_rtl::to_pod(files)}, {"failed", prism_rtl::to_pod(failed)}, {"report", prism_rtl::to_pod(report)}});
}

Result<Compiled> Compiled::from_pod(const Pod& whole) {
    return Compiled{.files = TRY(prism_rtl::from_pod<Array<std::tuple<Text, Text>>>(TRY(crate::prelude::field(whole, "files")))), .failed = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "failed")))), .report = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "report"))))};
}


// `@CompileMain` is inlined where it is applied.

/// let compileValued
Array<Text> compile_valued() {
    return Array(std::vector{Text::lit("-o"), Text::lit("--prelude"), Text::lit("--name"), Text::lit("--runtime"), Text::lit("--target")});
}


/// ?RuntimeOf: fn ?Text, ?Text, Text -> ?Text
std::optional<Text> runtime_of(const std::optional<Text>& named_opt, const std::optional<Text>& root_opt, const Text& out) {
    if (prism_rtl::is_some(named_opt)) {
        auto&& r = prism_rtl::some_of(named_opt);
        return std::optional(r);
    }
    if (prism_rtl::is_none(named_opt)) {
        return !crate::syntax::lexer::chars::has_prefix(out, Text::lit("/"))
            ? std::optional(runtime_for(out))
            : root_opt;
    }
    prism_rtl::unreachable("no arm matched");
}


/// RuntimeFor: fn Text -> Text
Text runtime_for(const Text& out) {
    auto parts = filter(split_on(out, Text::lit("/")), [&](const Text& p_) { return (p_ != Text::lit("")) && (p_ != Text::lit(".")); });
    return len(parts) == Nat(0u)
        ? Text::lit(".")
        : crate::syntax::lexer::chars::join(each(parts, [&](const Text& _p0) { return Text::lit(".."); }), Text::lit("/"));
}


/// CompileProgram: unbounded fn CompileJob -> Compiled
Compiled compile_program(const CompileJob& job) {
    auto read = crate::reading::assemble(job.read);
    return len(read.errors) > Nat(0u)
        ? Compiled{.files = Array<std::tuple<Text, Text>>{}, .failed = true, .report = crate::reading::tree_report(job.read, read.errors)}
        : ({
        auto pp = crate::reading::parse_program(read);
        pp.errors != Text::lit("")
        ? Compiled{.files = Array<std::tuple<Text, Text>>{}, .failed = true, .report = prism_rtl::cat(pp.errors, "parse errors")}
        : ({
        auto pre = crate::reading::tree_decl_diags(pp);
        auto report = crate::check::check_program(pp.srcs, each(pp.trees, [&](const crate::syntax::Module& t) { return without_tests(t); }), Array<Text>{}, pp.shown, true, false, pre);
        report.errors > Nat(0u)
        ? Compiled{.files = Array<std::tuple<Text, Text>>{}, .failed = true, .report = prism_rtl::cat(report->text, report.errors, " error", report.errors == Nat(1u) ? Text::lit("") : Text::lit("s"))}
        : ({
        auto model = crate::lower::program::lower_program(pp.srcs, pp.trees, pp.shown, report.typed, job.name);
        auto files = job->target == Text::lit("cpp")
            ? crate::emit::cpp::program::emit_cpp(model, job->runtime, read.scripts)
            : crate::emit::rust::items::emit_crate(model, job->runtime, read.scripts);
        auto refused = fold(files, Array<Text>{}, [&](const Array<Text>& acc, const std::tuple<Text, Text>& _p1) {
            auto&& path_ = std::get<0>(_p1);
            auto&& text_ = std::get<1>(_p1);
            return fold(refusals(text_), acc, [&](const Array<Text>& a, const Text& r) { return crate::check::types::add_text(a, prism_rtl::cat(path_, ": ", r)); });
        });
        len(refused) == Nat(0u)
        ? Compiled{.files = files, .failed = false, .report = Text::lit("")}
        : Compiled{.files = files, .failed = true, .report = prism_rtl::cat(concat(each(refused, [&](const Text& r) { return prism_rtl::cat("error[not-lowered]: ", r, "\n"); })), len(refused), " construct", len(refused) == Nat(1u) ? Text::lit("") : Text::lit("s"), " the back end does not lower (the crate is written, with a `compile_error!` at each)")};
    });
    });
    });
}


prism_rtl::Turn<Compiled> CompileProgram::cycle() const {
    const auto& job = this->job;
    auto job_1 = job;
    return call_then(crate::reading::start_assemble(job_1.read), [=](crate::reading::Assembled assemble_4670) {
        return ({
            auto read = assemble_4670;
            len(read.errors) > Nat(0u)
            ? prism_rtl::finished(Compiled{.files = Array<std::tuple<Text, Text>>{}, .failed = true, .report = crate::reading::tree_report(job_1.read, read.errors)})
            : call_then(crate::reading::start_parse_program(read), [=](crate::reading::ParsedProgram parse_program_4822) {
            return ({
                auto pp = parse_program_4822;
                pp.errors != Text::lit("")
                ? prism_rtl::finished(Compiled{.files = Array<std::tuple<Text, Text>>{}, .failed = true, .report = prism_rtl::cat(pp.errors, "parse errors")})
                : ({
                auto pre = crate::reading::tree_decl_diags(pp);
                call_then(crate::check::start_check_program(pp.srcs, each(pp.trees, [&](const crate::syntax::Module& t) { return without_tests(t); }), Array<Text>{}, pp.shown, true, false, pre), [=](crate::check::Report_ check_program_5014) {
                return ({
                    auto report = check_program_5014;
                    report.errors > Nat(0u)
                    ? prism_rtl::finished(Compiled{.files = Array<std::tuple<Text, Text>>{}, .failed = true, .report = prism_rtl::cat(report->text, report.errors, " error", report.errors == Nat(1u) ? Text::lit("") : Text::lit("s"))})
                    : call_then(crate::lower::program::start_lower_program(pp.srcs, pp.trees, pp.shown, report.typed, job_1.name), [=](crate::lower::model::Model lower_program_5303) {
                    return ({
                        auto model = lower_program_5303;
                        auto files = job_1->target == Text::lit("cpp")
                            ? crate::emit::cpp::program::emit_cpp(model, job_1->runtime, read.scripts)
                            : crate::emit::rust::items::emit_crate(model, job_1->runtime, read.scripts);
                        auto refused = fold(files, Array<Text>{}, [&](const Array<Text>& acc, const std::tuple<Text, Text>& _p1) {
                            auto&& path_ = std::get<0>(_p1);
                            auto&& text_ = std::get<1>(_p1);
                            return fold(refusals(text_), acc, [&](const Array<Text>& a, const Text& r) { return crate::check::types::add_text(a, prism_rtl::cat(path_, ": ", r)); });
                        });
                        len(refused) == Nat(0u)
                        ? prism_rtl::finished(Compiled{.files = files, .failed = false, .report = Text::lit("")})
                        : prism_rtl::finished(Compiled{.files = files, .failed = true, .report = prism_rtl::cat(concat(each(refused, [&](const Text& r) { return prism_rtl::cat("error[not-lowered]: ", r, "\n"); })), len(refused), " construct", len(refused) == Nat(1u) ? Text::lit("") : Text::lit("s"), " the back end does not lower (the crate is written, with a `compile_error!` at each)")});
                    });
                });
                });
            });
            });
            });
        });
        });
    });
}


/// `Start CompileProgram, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Compiled> start_compile_program(CompileJob job) {
    return prism_rtl::make_rc<CompileProgram>(job);
}


/// Refusals: fn Text -> [Text]
Array<Text> refusals(const Text& text_) {
    auto marker = Text::lit("compile_error!(\"prismc does not lower ");
    auto parts = split_on(text_, marker);
    return fold(drop(parts, Nat(1u)), Array<Text>{}, [&](const Array<Text>& acc, const Text& part) { return crate::check::types::add_text(acc, or_(index(split_on(part, Text::lit("\")")), Nat(0u)), part)); });
}


/// WithoutTests: fn Module -> Module
crate::syntax::Module without_tests(const crate::syntax::Module& m) {
    crate::syntax::Module this_ = m;
    this_.decls = each(filter(this_.decls, [&](const crate::syntax::decls::Decl& d) { return !is_test_decl(d); }), [&](const crate::syntax::decls::Decl& d) { return without_patterns(d); });
    return this_;
}


/// WithoutPatterns: fn Decl -> Decl
crate::syntax::decls::Decl without_patterns(const crate::syntax::decls::Decl& d) {
    auto&& _m = d.kind;
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DCheck>(_m)) {
        auto&& c = prism_rtl::as<crate::syntax::decls::DeclKind::DCheck>(_m).a0;
        crate::syntax::decls::Decl this_ = d;
        this_.kind = crate::syntax::decls::DeclKind(crate::syntax::decls::DeclKind::DCheck{check_without_patterns(c)});
        return this_;
    }
    {
        return d;
    }
}


/// CheckWithoutPatterns: fn CheckDecl -> CheckDecl
crate::syntax::decls::CheckDecl check_without_patterns(const crate::syntax::decls::CheckDecl& c) {
    crate::syntax::decls::CheckDecl this_ = c;
    this_.lines = each(this_.lines, [&](const crate::syntax::decls::CheckLine& l) { return line_without_pattern(l); });
    return this_;
}


/// LineWithoutPattern: fn CheckLine -> CheckLine
crate::syntax::decls::CheckLine line_without_pattern(const crate::syntax::decls::CheckLine& l) {
    crate::syntax::decls::CheckLine this_ = l;
    this_.pattern = std::optional<crate::syntax::Pattern_>{};
    return this_;
}


/// IsTestDecl: fn Decl -> Bool
bool is_test_decl(const crate::syntax::decls::Decl& d) {
    auto&& _m = d.kind;
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DTest>(_m)) {
        return true;
    }
    {
        return false;
    }
}


// `@FinishCompile` is inlined where it is applied.

}  // namespace crate::compile
