// The module `Parser`, from `target/bootstrap/cpp-src/prismc/parser.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (docs/backend.md). Edit the Prism source, not this file.
#include <parser/module.hpp>
#include <ast/module.hpp>
#include <lexer/module.hpp>
#include <parser/generic.hpp>
#include <lexer/generic.hpp>

namespace crate::parser {

void ArgsRead::show(Printer& p) const {
    p.record("ArgsRead", {{"args", args}, {"rest", rest}, {"p", p_}, {"going", going}});
}

Pod ArgsRead::to_pod() const {
    return Pod::record("ArgsRead", {{"args", prism_rtl::to_pod(args)}, {"rest", prism_rtl::to_pod(rest)}, {"p", prism_rtl::to_pod(p_)}, {"going", prism_rtl::to_pod(going)}});
}

Result<ArgsRead> ArgsRead::from_pod(const Pod& whole) {
    return ArgsRead{.args = TRY(prism_rtl::from_pod<Array<crate::ast::Arg>>(TRY(prelude::field(whole, "args")))), .rest = TRY(prism_rtl::from_pod<bool>(TRY(prelude::field(whole, "rest")))), .p_ = TRY(prism_rtl::from_pod<Ps>(TRY(prelude::field(whole, "p")))), .going = TRY(prism_rtl::from_pod<bool>(TRY(prelude::field(whole, "going"))))};
}


void Climb::show(Printer& p) const {
    p.record("Climb", {{"lhs", lhs}, {"p", p_}, {"going", going}});
}

Pod Climb::to_pod() const {
    return Pod::record("Climb", {{"lhs", prism_rtl::to_pod(lhs)}, {"p", prism_rtl::to_pod(p_)}, {"going", prism_rtl::to_pod(going)}});
}

Result<Climb> Climb::from_pod(const Pod& whole) {
    return Climb{.lhs = TRY(prism_rtl::from_pod<crate::ast::Expr>(TRY(prelude::field(whole, "lhs")))), .p_ = TRY(prism_rtl::from_pod<Ps>(TRY(prelude::field(whole, "p")))), .going = TRY(prism_rtl::from_pod<bool>(TRY(prelude::field(whole, "going"))))};
}


void FieldsRead::show(Printer& p) const {
    p.record("FieldsRead", {{"fields", fields}, {"rest", rest}, {"p", p_}, {"going", going}});
}

Pod FieldsRead::to_pod() const {
    return Pod::record("FieldsRead", {{"fields", prism_rtl::to_pod(fields)}, {"rest", prism_rtl::to_pod(rest)}, {"p", prism_rtl::to_pod(p_)}, {"going", prism_rtl::to_pod(going)}});
}

Result<FieldsRead> FieldsRead::from_pod(const Pod& whole) {
    return FieldsRead{.fields = TRY(prism_rtl::from_pod<Array<crate::ast::FieldPat>>(TRY(prelude::field(whole, "fields")))), .rest = TRY(prism_rtl::from_pod<bool>(TRY(prelude::field(whole, "rest")))), .p_ = TRY(prism_rtl::from_pod<Ps>(TRY(prelude::field(whole, "p")))), .going = TRY(prism_rtl::from_pod<bool>(TRY(prelude::field(whole, "going"))))};
}


void ModRead::show(Printer& p) const {
    p.record("ModRead", {{"p", p_}, {"m", m}, {"stage", stage}});
}

Pod ModRead::to_pod() const {
    return Pod::record("ModRead", {{"p", prism_rtl::to_pod(p_)}, {"m", prism_rtl::to_pod(m)}, {"stage", prism_rtl::to_pod(stage)}});
}

Result<ModRead> ModRead::from_pod(const Pod& whole) {
    return ModRead{.p_ = TRY(prism_rtl::from_pod<Ps>(TRY(prelude::field(whole, "p")))), .m = TRY(prism_rtl::from_pod<crate::ast::Module>(TRY(prelude::field(whole, "m")))), .stage = TRY(prism_rtl::from_pod<Nat>(TRY(prelude::field(whole, "stage"))))};
}


void Pair::show(Printer& p) const {
    p.record("Pair", {{"partner", partner}, {"outer", outer}, {"inner", inner}});
}

Pod Pair::to_pod() const {
    return Pod::record("Pair", {{"partner", prism_rtl::to_pod(partner)}, {"outer", prism_rtl::to_pod(outer)}, {"inner", prism_rtl::to_pod(inner)}});
}

Result<Pair> Pair::from_pod(const Pod& whole) {
    return Pair{.partner = TRY(prism_rtl::from_pod<std::optional<Nat>>(TRY(prelude::field(whole, "partner")))), .outer = TRY(prism_rtl::from_pod<bool>(TRY(prelude::field(whole, "outer")))), .inner = TRY(prism_rtl::from_pod<bool>(TRY(prelude::field(whole, "inner"))))};
}


void Parsed::show(Printer& p) const {
    p.record("Parsed", {{"tree", tree}, {"diags", diags}});
}

Pod Parsed::to_pod() const {
    return Pod::record("Parsed", {{"tree", prism_rtl::to_pod(tree)}, {"diags", prism_rtl::to_pod(diags)}});
}

Result<Parsed> Parsed::from_pod(const Pod& whole) {
    return Parsed{.tree = TRY(prism_rtl::from_pod<crate::ast::Module>(TRY(prelude::field(whole, "tree")))), .diags = TRY(prism_rtl::from_pod<Array<crate::ast::Diag>>(TRY(prelude::field(whole, "diags"))))};
}


void Ps::show(Printer& p) const {
    p.record("Ps", {{"toks", toks}, {"pairs", pairs}, {"pos", pos}, {"diags", diags}, {"out", out}, {"step_mode", step_mode}, {"in_trait", in_trait}, {"bad", bad}});
}

Pod Ps::to_pod() const {
    return Pod::record("Ps", {{"toks", prism_rtl::to_pod(toks)}, {"pairs", prism_rtl::to_pod(pairs)}, {"pos", prism_rtl::to_pod(pos)}, {"diags", prism_rtl::to_pod(diags)}, {"out", prism_rtl::to_pod(out)}, {"step_mode", prism_rtl::to_pod(step_mode)}, {"in_trait", prism_rtl::to_pod(in_trait)}, {"bad", prism_rtl::to_pod(bad)}});
}

Result<Ps> Ps::from_pod(const Pod& whole) {
    return Ps{.toks = TRY(prism_rtl::from_pod<Array<crate::lexer::Tok>>(TRY(prelude::field(whole, "toks")))), .pairs = TRY(prism_rtl::from_pod<Array<Pair>>(TRY(prelude::field(whole, "pairs")))), .pos = TRY(prism_rtl::from_pod<Nat>(TRY(prelude::field(whole, "pos")))), .diags = TRY(prism_rtl::from_pod<Array<crate::ast::Diag>>(TRY(prelude::field(whole, "diags")))), .out = TRY(prism_rtl::from_pod<Array<crate::ast::Diag>>(TRY(prelude::field(whole, "out")))), .step_mode = TRY(prism_rtl::from_pod<bool>(TRY(prelude::field(whole, "step_mode")))), .in_trait = TRY(prism_rtl::from_pod<bool>(TRY(prelude::field(whole, "in_trait")))), .bad = TRY(prism_rtl::from_pod<bool>(TRY(prelude::field(whole, "bad"))))};
}


/// let noRange
crate::ast::Range no_range() {
    return crate::ast::Range{.start = Nat(0u), .end = Nat(0u)};
}


/// let eofTok
crate::lexer::Tok eof_tok() {
    return crate::lexer::Tok{.kind = crate::lexer::TokKind(crate::lexer::TokKind::KEof{}), .span = no_range(), .touches = false, .line_start = false};
}


/// let noPair
Pair no_pair() {
    return Pair{.partner = std::optional<Nat>{}, .outer = false, .inner = false};
}


/// ParseFile: unbounded fn Text -> Parsed
Parsed parse_file(const Text& src) {
    auto lexed = crate::lexer::lex_file(src);
    auto [m, p_] = parse_module(new_ps(lexed->tokens), false);
    return Parsed{.tree = m, .diags = finish_diags(append(append(lexed.diags, p_.diags), p_->out))};
}


prism_rtl::Turn<Parsed> ParseFile::cycle() const {
    const auto& src = this->src;
    auto src_1 = src;
    return call_then(crate::lexer::start_lex_file(src_1), [=](crate::lexer::Lexed lex_file_2986) {
        return ({
            auto lexed = lex_file_2986;
            call_then(start_new_ps(lexed->tokens), [=](Ps new_ps_3030) {
            return call_then(start_parse_module(new_ps_3030, false), [=](std::tuple<crate::ast::Module, Ps> parse_module_3017) {
                return ({
                    auto [m, p_] = parse_module_3017;
                    (prism_rtl::finished(Parsed{.tree = m, .diags = finish_diags(append(append(lexed.diags, p_.diags), p_->out))}));
                });
            });
        });
        });
    });
}


/// `Start ParseFile, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Parsed> start_parse_file(Text src) {
    return prism_rtl::make_rc<ParseFile>(src);
}


/// ParseFragment: unbounded fn Text -> Parsed
Parsed parse_fragment(const Text& src) {
    auto lexed = crate::lexer::lex_file(src);
    auto [m, p_] = parse_module(new_ps(lexed->tokens), true);
    return Parsed{.tree = m, .diags = finish_diags(append(append(lexed.diags, p_.diags), p_->out))};
}


prism_rtl::Turn<Parsed> ParseFragment::cycle() const {
    const auto& src = this->src;
    auto src_1 = src;
    return call_then(crate::lexer::start_lex_file(src_1), [=](crate::lexer::Lexed lex_file_3379) {
        return ({
            auto lexed = lex_file_3379;
            call_then(start_new_ps(lexed->tokens), [=](Ps new_ps_3423) {
            return call_then(start_parse_module(new_ps_3423, true), [=](std::tuple<crate::ast::Module, Ps> parse_module_3410) {
                return ({
                    auto [m, p_] = parse_module_3410;
                    (prism_rtl::finished(Parsed{.tree = m, .diags = finish_diags(append(append(lexed.diags, p_.diags), p_->out))}));
                });
            });
        });
        });
    });
}


/// `Start ParseFragment, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Parsed> start_parse_fragment(Text src) {
    return prism_rtl::make_rc<ParseFragment>(src);
}


/// NewPs: unbounded fn [Tok] -> Ps
Ps new_ps(const Array<crate::lexer::Tok>& toks0) {
    auto ends = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = crate::lexer::last(toks0);
        if (prism_rtl::is_some(_m)) {
            auto&& t = prism_rtl::some_of(_m);
            _v.set(t.kind == crate::lexer::TokKind(crate::lexer::TokKind::KEof{}));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(false);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto end = ({
        __label__ _done;
        prism_rtl::Slot<crate::ast::Range> _v;
        auto&& _m = crate::lexer::last(toks0);
        if (prism_rtl::is_some(_m)) {
            auto&& t = prism_rtl::some_of(_m);
            _v.set(crate::ast::Range{.start = t.span.end, .end = t.span.end});
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(no_range());
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto toks = ends
        ? toks0
        : prelude::push(toks0, crate::lexer::Tok{.kind = crate::lexer::TokKind(crate::lexer::TokKind::KEof{}), .span = end, .touches = false, .line_start = false});
    return Ps{.toks = toks, .pairs = pair_brackets(toks), .pos = Nat(0u), .diags = Array<crate::ast::Diag>{}, .out = Array<crate::ast::Diag>{}, .step_mode = false, .in_trait = false, .bad = false};
}


prism_rtl::Turn<Ps> NewPs::cycle() const {
    const auto& toks0 = this->toks0;
    auto ends = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = crate::lexer::last(toks0);
        if (prism_rtl::is_some(_m)) {
            auto&& t = prism_rtl::some_of(_m);
            _v.set(t.kind == crate::lexer::TokKind(crate::lexer::TokKind::KEof{}));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(false);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto end = ({
        __label__ _done;
        prism_rtl::Slot<crate::ast::Range> _v;
        auto&& _m = crate::lexer::last(toks0);
        if (prism_rtl::is_some(_m)) {
            auto&& t = prism_rtl::some_of(_m);
            _v.set(crate::ast::Range{.start = t.span.end, .end = t.span.end});
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(no_range());
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto toks = ends
        ? toks0
        : prelude::push(toks0, crate::lexer::Tok{.kind = crate::lexer::TokKind(crate::lexer::TokKind::KEof{}), .span = end, .touches = false, .line_start = false});
    return call_then(start_pair_brackets(toks), [=](Array<Pair> pair_brackets_3902) { return prism_rtl::finished(Ps{.toks = toks, .pairs = pair_brackets_3902, .pos = Nat(0u), .diags = Array<crate::ast::Diag>{}, .out = Array<crate::ast::Diag>{}, .step_mode = false, .in_trait = false, .bad = false}); });
}


/// `Start NewPs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Ps> start_new_ps(Array<crate::lexer::Tok> toks0) {
    return prism_rtl::make_rc<NewPs>(toks0);
}


/// Sub: unbounded fn Ps, [Tok], Range -> Ps
Ps sub(const Ps& p_, const Array<crate::lexer::Tok>& toks, const crate::ast::Range& end) {
    auto q = new_ps(prelude::push(toks, crate::lexer::Tok{.kind = crate::lexer::TokKind(crate::lexer::TokKind::KEof{}), .span = end, .touches = false, .line_start = false}));
    Ps this_ = q;
    this_.step_mode = p_.step_mode;
    return this_;
}


prism_rtl::Turn<Ps> Sub::cycle() const {
    const auto& p_ = this->p_;
    const auto& toks = this->toks;
    const auto& end = this->end;
    auto end_1 = end;
    auto p__2 = p_;
    auto toks_3 = toks;
    return call_then(start_new_ps(prelude::push(toks_3, crate::lexer::Tok{.kind = crate::lexer::TokKind(crate::lexer::TokKind::KEof{}), .span = end_1, .touches = false, .line_start = false})), [=](Ps new_ps_4211) {
        return ({
            auto q = new_ps_4211;
            (prism_rtl::finished(({
            Ps this_ = q;
            this_.step_mode = p__2.step_mode;
            this_;
        })));
        });
    });
}


/// `Start Sub, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Ps> start_sub(Ps p_, Array<crate::lexer::Tok> toks, crate::ast::Range end) {
    return prism_rtl::make_rc<Sub>(p_, toks, end);
}


/// Absorb: fn Ps, Ps -> Ps
Ps absorb(const Ps& p_, const Ps& sub_) {
    Ps this_ = p_;
    this_.diags = append(this_.diags, sub_.diags);
    this_.out = append(this_.out, sub_->out);
    return this_;
}


/// FinishDiags: fn [Diag] -> [Diag]
Array<crate::ast::Diag> finish_diags(const Array<crate::ast::Diag>& ds) {
    auto sorted = fold(ds, Array<crate::ast::Diag>{}, insert_diag);
    return fold(sorted, Array<crate::ast::Diag>{}, [&](const Array<crate::ast::Diag>& acc, const crate::ast::Diag& d) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::ast::Diag>> _v;
            auto&& _m = crate::lexer::last(acc);
            if (prism_rtl::is_some(_m)) {
                auto&& e = prism_rtl::some_of(_m);
                if ((e.span == d.span) && (e.message == d.message)) {
                    _v.set(acc);
                    goto _done;
                }
            }
            {
                _v.set(prelude::push(acc, d));
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


/// StageRank: fn Text -> Nat
Nat stage_rank(const Text& text0) {
    {
        auto&& c0_0 = text0;
        if (c0_0 == Text::lit("lex")) {
            return Nat(0u);
        }
    }
    {
        auto&& c1_0 = text0;
        if (c1_0 == Text::lit("parse")) {
            return Nat(1u);
        }
    }
    {
        return Nat(2u);
    }
}


/// DiagBefore: fn Diag, Diag -> Bool
bool diag_before(const crate::ast::Diag& a, const crate::ast::Diag& b) {
    return (a.span.start < b.span.start) || ((a.span.start == b.span.start) && (stage_rank(a.stage) < stage_rank(b.stage)));
}


/// InsertDiag: fn [Diag], Diag -> [Diag]
Array<crate::ast::Diag> insert_diag(const Array<crate::ast::Diag>& sorted, const crate::ast::Diag& d) {
    auto before_ = fold(sorted, Array<crate::ast::Diag>{}, [&](const Array<crate::ast::Diag>& acc, const crate::ast::Diag& e) { return diag_before(d, e) ? acc : prelude::push(acc, e); });
    auto after_ = fold(sorted, Array<crate::ast::Diag>{}, [&](const Array<crate::ast::Diag>& acc, const crate::ast::Diag& e) { return diag_before(d, e) ? prelude::push(acc, e) : acc; });
    return append(prelude::push(before_, d), after_);
}


/// PairBrackets: unbounded fn [Tok] -> [Pair]
Array<Pair> pair_brackets(const Array<crate::lexer::Tok>& toks) {
    Array<Pair> this_ = each(toks, [&](const crate::lexer::Tok& t) { return no_pair(); });
    Array<std::tuple<Nat, Text>> stack = Array<std::tuple<Nat, Text>>{};
    for (auto&& [i5963, v5963] : prism_rtl::enumerate(toks)) {
        auto k5963 = nat_of(i5963);
        auto t = v5963;
        if (auto&& _m = open_kind_of(t.kind); prism_rtl::is_some(_m)) {
            auto&& k = prism_rtl::some_of(_m);
            stack = prelude::push(stack, std::tuple{k5963, k});
        }
        if (auto&& _m = close_kind_of(t.kind); prism_rtl::is_some(_m)) {
            auto&& k = prism_rtl::some_of(_m);
            if (auto&& _m = crate::lexer::last(stack); prism_rtl::is_some(_m)) {
                auto&& j = std::get<0>(prism_rtl::some_of(_m));
                auto&& k2 = std::get<1>(prism_rtl::some_of(_m));
                if (k2 == k) {
                    stack = crate::lexer::pop(stack);
                    at_mut(this_, k5963).partner = std::optional(j);
                    at_mut(this_, j).partner = std::optional(k5963);
                }
            }
        }
    }
    for (auto&& [i6424, v6424] : prism_rtl::enumerate(toks)) {
        auto k6424 = nat_of(i6424);
        auto t = v6424;
        auto i = k6424;
        if (auto&& _m = open_kind_of(t.kind); prism_rtl::is_some(_m)) {
            auto&& kind_ = prism_rtl::some_of(_m);
            if ((kind_ != Text::lit("{")) && (!or_(index(this_, i), no_pair()).inner)) {
                if (auto&& _m = or_(index(this_, i), no_pair()).partner; prism_rtl::is_some(_m)) {
                    auto&& j = prism_rtl::some_of(_m);
                    if (double_at(this_, toks, i, j, kind_)) {
                        at_mut(this_, i).outer = true;
                        at_mut(this_, j).outer = true;
                        at_mut(this_, i + Nat(1u)).inner = true;
                        at_mut(this_, crate::lexer::dec(j)).inner = true;
                    }
                }
            }
        }
    }
    return this_;
}


prism_rtl::Turn<Array<Pair>> PairBrackets::cycle() const {
    const auto& toks = this->toks;
    return prism_rtl::finished(({
        Array<Pair> this_ = each(toks, [&](const crate::lexer::Tok& t) { return no_pair(); });
        Array<std::tuple<Nat, Text>> stack = Array<std::tuple<Nat, Text>>{};
        for (auto&& [i5963, v5963] : prism_rtl::enumerate(toks)) {
            auto k5963 = nat_of(i5963);
            auto t = v5963;
            if (auto&& _m = open_kind_of(t.kind); prism_rtl::is_some(_m)) {
                auto&& k = prism_rtl::some_of(_m);
                stack = prelude::push(stack, std::tuple{k5963, k});
            }
            if (auto&& _m = close_kind_of(t.kind); prism_rtl::is_some(_m)) {
                auto&& k = prism_rtl::some_of(_m);
                if (auto&& _m = crate::lexer::last(stack); prism_rtl::is_some(_m)) {
                    auto&& j = std::get<0>(prism_rtl::some_of(_m));
                    auto&& k2 = std::get<1>(prism_rtl::some_of(_m));
                    if (k2 == k) {
                        stack = crate::lexer::pop(stack);
                        at_mut(this_, k5963).partner = std::optional(j);
                        at_mut(this_, j).partner = std::optional(k5963);
                    }
                }
            }
        }
        for (auto&& [i6424, v6424] : prism_rtl::enumerate(toks)) {
            auto k6424 = nat_of(i6424);
            auto t = v6424;
            auto i = k6424;
            if (auto&& _m = open_kind_of(t.kind); prism_rtl::is_some(_m)) {
                auto&& kind_ = prism_rtl::some_of(_m);
                if ((kind_ != Text::lit("{")) && (!or_(index(this_, i), no_pair()).inner)) {
                    if (auto&& _m = or_(index(this_, i), no_pair()).partner; prism_rtl::is_some(_m)) {
                        auto&& j = prism_rtl::some_of(_m);
                        if (double_at(this_, toks, i, j, kind_)) {
                            at_mut(this_, i).outer = true;
                            at_mut(this_, j).outer = true;
                            at_mut(this_, i + Nat(1u)).inner = true;
                            at_mut(this_, crate::lexer::dec(j)).inner = true;
                        }
                    }
                }
            }
        }
        this_;
    }));
}


/// `Start PairBrackets, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Pair>> start_pair_brackets(Array<crate::lexer::Tok> toks) {
    return prism_rtl::make_rc<PairBrackets>(toks);
}


/// DoubleAt: fn [Pair], [Tok], Nat, Nat, Text -> Bool
bool double_at(const Array<Pair>& pairs, const Array<crate::lexer::Tok>& toks, const Nat& i, const Nat& j, const Text& kind_) {
    auto next = or_(index(toks, i + Nat(1u)), eof_tok());
    auto inner_close_opt = or_(index(pairs, i + Nat(1u)), no_pair()).partner;
    return ((is_open_of(next.kind, kind_) && next.touches) && (inner_close_opt == std::optional(crate::lexer::dec(j)))) && or_(index(toks, j), eof_tok()).touches;
}


/// ?OpenKindOf: fn TokKind -> ?Text
std::optional<Text> open_kind_of(const crate::lexer::TokKind& tok_kind0) {
    if (prism_rtl::is<crate::lexer::TokKind::KOpen>(tok_kind0)) {
        auto&& k = prism_rtl::as<crate::lexer::TokKind::KOpen>(tok_kind0).a0;
        return std::optional(k);
    }
    {
        return std::optional<Text>{};
    }
}


/// ?CloseKindOf: fn TokKind -> ?Text
std::optional<Text> close_kind_of(const crate::lexer::TokKind& tok_kind0) {
    if (prism_rtl::is<crate::lexer::TokKind::KClose>(tok_kind0)) {
        auto&& k = prism_rtl::as<crate::lexer::TokKind::KClose>(tok_kind0).a0;
        return std::optional(k);
    }
    {
        return std::optional<Text>{};
    }
}


/// IsOpenOf: fn TokKind, Text -> Bool
bool is_open_of(const crate::lexer::TokKind& tok_kind0, const Text& text1) {
    auto&& _m = std::tuple{tok_kind0, text1};
    if (prism_rtl::is<crate::lexer::TokKind::KOpen>(std::get<0>(_m))) {
        auto&& k = prism_rtl::as<crate::lexer::TokKind::KOpen>(std::get<0>(_m)).a0;
        auto&& kind_ = std::get<1>(_m);
        return k == kind_;
    }
    {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// Tk: fn Ps -> Tok
crate::lexer::Tok tk(const Ps& p_) {
    return p_->bad
        ? eof_tok()
        : or_(index(p_.toks, prelude::min(p_.pos, crate::lexer::dec(len(p_.toks)))), eof_tok());
}


/// TkAt: fn Ps, Nat -> Tok
crate::lexer::Tok tk_at(const Ps& p_, const Nat& n) {
    return p_->bad
        ? eof_tok()
        : or_(index(p_.toks, prelude::min(p_.pos + n, crate::lexer::dec(len(p_.toks)))), eof_tok());
}


/// Kind: fn Ps -> TokKind
crate::lexer::TokKind kind(const Ps& p_) {
    return tk(p_).kind;
}


/// KindAt: fn Ps, Nat -> TokKind
crate::lexer::TokKind kind_at(const Ps& p_, const Nat& n) {
    return tk_at(p_, n).kind;
}


/// Here: fn Ps -> Range
crate::ast::Range here(const Ps& p_) {
    return tk(p_).span;
}


/// Prev: fn Ps -> Range
crate::ast::Range prev(const Ps& p_) {
    return or_(index(p_.toks, crate::lexer::dec(p_.pos)), eof_tok()).span;
}


/// To: fn Range, Range -> Range
crate::ast::Range to(const crate::ast::Range& a, const crate::ast::Range& b) {
    return crate::ast::Range{.start = prelude::min(a.start, b.start), .end = prelude::max(a.end, b.end)};
}


/// AtEnd: fn Range -> Range
crate::ast::Range at_end(const crate::ast::Range& r) {
    return crate::ast::Range{.start = r.end, .end = r.end};
}


/// Adv: fn Ps -> Ps
Ps adv(const Ps& p_) {
    return p_->bad || ((p_.pos + Nat(1u)) >= len(p_.toks))
        ? p_
        : ({
        Ps this_ = p_;
        this_.pos = this_.pos + Nat(1u);
        this_;
    });
}


/// PairAt: fn Ps -> Pair
Pair pair_at(const Ps& p_) {
    return or_(index(p_.pairs, prelude::min(p_.pos, crate::lexer::dec(len(p_.pairs)))), no_pair());
}


/// AtEof: fn Ps -> Bool
bool at_eof(const Ps& p_) {
    return kind(p_) == crate::lexer::TokKind(crate::lexer::TokKind::KEof{});
}


/// AtKw: fn Ps, Text -> Bool
bool at_kw(const Ps& p_, const Text& w) {
    return kind(p_) == crate::lexer::TokKind(crate::lexer::TokKind::KKw{w, Text::lit("")});
}


/// AtOp: fn Ps, Text -> Bool
bool at_op(const Ps& p_, const Text& op) {
    auto&& _m = kind(p_);
    if (prism_rtl::is<crate::lexer::TokKind::KOp>(_m)) {
        auto&& o = prism_rtl::as<crate::lexer::TokKind::KOp>(_m).a0;
        return o == op;
    }
    {
        return false;
    }
}


/// AtSep: fn Ps -> Bool
bool at_sep(const Ps& p_) {
    return kind(p_) == crate::lexer::TokKind(crate::lexer::TokKind::KLaySep{});
}


/// AtOpenL: fn Ps -> Bool
bool at_open_l(const Ps& p_) {
    return kind(p_) == crate::lexer::TokKind(crate::lexer::TokKind::KLayOpen{});
}


/// AtCloseL: fn Ps -> Bool
bool at_close_l(const Ps& p_) {
    return kind(p_) == crate::lexer::TokKind(crate::lexer::TokKind::KLayClose{});
}


/// AtComma: fn Ps -> Bool
bool at_comma(const Ps& p_) {
    return kind(p_) == crate::lexer::TokKind(crate::lexer::TokKind::KComma{});
}


/// AtColon: fn Ps -> Bool
bool at_colon(const Ps& p_) {
    return kind(p_) == crate::lexer::TokKind(crate::lexer::TokKind::KColon{});
}


/// IsOpenKind: fn TokKind, Text -> Bool
bool is_open_kind(const crate::lexer::TokKind& tok_kind0, const Text& text1) {
    auto&& _m = std::tuple{tok_kind0, text1};
    if (prism_rtl::is<crate::lexer::TokKind::KOpen>(std::get<0>(_m))) {
        auto&& k = prism_rtl::as<crate::lexer::TokKind::KOpen>(std::get<0>(_m)).a0;
        auto&& kind_ = std::get<1>(_m);
        return k == kind_;
    }
    {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// AtDoubleOpen: fn Ps, Text -> Bool
bool at_double_open(const Ps& p_, const Text& kind_) {
    return is_open_kind(kind(p_), kind_) && pair_at(p_).outer;
}


/// AtSingleOpen: fn Ps, Text -> Bool
bool at_single_open(const Ps& p_, const Text& kind_) {
    return is_open_kind(kind(p_), kind_) && (!pair_at(p_).outer);
}


/// AtClose: fn Ps, Text -> Bool
bool at_close(const Ps& p_, const Text& kind_) {
    return kind(p_) == crate::lexer::TokKind(crate::lexer::TokKind::KClose{kind_});
}


/// OpenDouble: fn Ps -> Ps
Ps open_double(const Ps& p_) {
    return adv(adv(p_));
}


/// CloseDouble: fn Ps, Text -> Ps
Ps close_double(const Ps& p_, const Text& kind_) {
    auto c = crate::lexer::close_char(kind_);
    auto p1 = adv(p_);
    return ((at_close(p_, kind_) && pair_at(p_).inner) && at_close(p1, kind_)) && pair_at(p1).outer
        ? adv(p1)
        : at_close(p_, kind_) && pair_at(p_).inner
        ? error_here(p1, prism_rtl::cat("expected `", c, c, "` to close the double bracket"))
        : error_here(p_, prism_rtl::cat("expected `", c, c, "` to close the double bracket"));
}


/// ExpectClose: fn Ps, Text -> Ps
Ps expect_close(const Ps& p_, const Text& kind_) {
    return at_close(p_, kind_)
        ? adv(p_)
        : error_here(p_, prism_rtl::cat("expected `", crate::lexer::close_char(kind_), "`"));
}


/// ParseDiag: fn Range, Text -> Diag
crate::ast::Diag parse_diag(const crate::ast::Range& span, const Text& message) {
    return crate::ast::Diag{.stage = Text::lit("parse"), .span = span, .message = message, .feature = std::optional<Text>{}};
}


/// ErrorAt: fn Ps, Range, Text -> Ps
Ps error_at(const Ps& p_, const crate::ast::Range& span, const Text& message) {
    return p_->bad
        ? p_
        : ({
        Ps this_ = p_;
        this_.diags = prelude::push(this_.diags, parse_diag(span, message));
        this_.bad = true;
        this_;
    });
}


/// ErrorHere: fn Ps, Text -> Ps
Ps error_here(const Ps& p_, const Text& message) {
    return error_at(p_, here(p_), prism_rtl::cat(message, ", found ", describe(kind(p_))));
}


/// Fail: fn Ps -> Ps
Ps fail(const Ps& p_) {
    Ps this_ = p_;
    this_.bad = true;
    return this_;
}


/// Unbad: fn Ps -> Ps
Ps unbad(const Ps& p_) {
    Ps this_ = p_;
    this_.bad = false;
    return this_;
}


/// NoteError: fn Ps, Range, Text -> Ps
Ps note_error(const Ps& p_, const crate::ast::Range& span, const Text& message) {
    return p_->bad
        ? p_
        : ({
        Ps this_ = p_;
        this_.diags = prelude::push(this_.diags, parse_diag(span, message));
        this_;
    });
}


/// Complain: fn Ps, Text -> Ps
Ps complain(const Ps& p_, const Text& message) {
    return unbad(error_here(p_, message));
}


/// OutOfScope: fn Ps, Range, Text, Text -> Ps
Ps out_of_scope(const Ps& p_, const crate::ast::Range& span, const Text& feature, const Text& message) {
    return p_->bad
        ? p_
        : ({
        Ps this_ = p_;
        this_.out = prelude::push(this_.out, crate::ast::Diag{.stage = Text::lit("out"), .span = span, .message = message, .feature = std::optional(feature)});
        this_;
    });
}


/// ExpectColon: fn Ps -> Ps
Ps expect_colon(const Ps& p_) {
    return at_colon(p_) ? adv(p_) : error_here(p_, Text::lit("expected `:`"));
}


/// ExpectOp: fn Ps, Text -> Ps
Ps expect_op(const Ps& p_, const Text& op) {
    return at_op(p_, op)
        ? adv(p_)
        : error_here(p_, prism_rtl::cat("expected `", op, "`"));
}


/// ExpectKw: fn Ps, Text -> Ps
Ps expect_kw(const Ps& p_, const Text& w) {
    return at_kw(p_, w)
        ? adv(p_)
        : error_here(p_, prism_rtl::cat("expected `", w, "`"));
}


/// Recover: unbounded fn Ps -> Ps
Ps recover(const Ps& p0) {
    Ps this_ = unbad(p0);
    Nat depth = Nat(0u);
    bool going = true;
    while (going) {
        ({
            __label__ _done;
            prism_rtl::Slot<Unit> _v;
            auto&& _m = kind(this_);
            if (prism_rtl::is<crate::lexer::TokKind::KEof>(_m)) {
                _v.set(({
                    going = false;
                    Unit{};
                }));
                goto _done;
            }
            if (prism_rtl::is<crate::lexer::TokKind::KLayOpen>(_m)) {
                _v.set(({
                    depth = depth + Nat(1u);
                    this_ = adv(this_);
                    Unit{};
                }));
                goto _done;
            }
            if (prism_rtl::is<crate::lexer::TokKind::KLayClose>(_m)) {
                _v.set(({
                    if (depth == Nat(0u)) {
                        going = false;
                    } else  {
                        depth = crate::lexer::dec(depth);
                        this_ = adv(this_);
                    }
                    Unit{};
                }));
                goto _done;
            }
            if (prism_rtl::is<crate::lexer::TokKind::KLaySep>(_m)) {
                if (depth == Nat(0u)) {
                    _v.set(({
                        going = false;
                        Unit{};
                    }));
                    goto _done;
                }
            }
            {
                _v.set(({
                    this_ = adv(this_);
                    Unit{};
                }));
                goto _done;
            }
        _done:
            _v.take();
        });
    }
    return this_;
}


prism_rtl::Turn<Ps> Recover::cycle() const {
    const auto& p0 = this->p0;
    Ps this_ = unbad(p0);
    Nat depth = Nat(0u);
    bool going = true;
    return call_then(loop_job(std::tuple{this_, depth, going}, [=](std::tuple<Ps, Nat, bool> _p0) {
        auto this_ = std::get<0>(_p0);
        auto depth = std::get<1>(_p0);
        auto going = std::get<2>(_p0);
        return going
            ? ({
            ({
                __label__ _done;
                prism_rtl::Slot<Unit> _v;
                auto&& _m = kind(this_);
                if (prism_rtl::is<crate::lexer::TokKind::KEof>(_m)) {
                    _v.set(({
                        going = false;
                        Unit{};
                    }));
                    goto _done;
                }
                if (prism_rtl::is<crate::lexer::TokKind::KLayOpen>(_m)) {
                    _v.set(({
                        depth = depth + Nat(1u);
                        this_ = adv(this_);
                        Unit{};
                    }));
                    goto _done;
                }
                if (prism_rtl::is<crate::lexer::TokKind::KLayClose>(_m)) {
                    _v.set(({
                        if (depth == Nat(0u)) {
                            going = false;
                        } else  {
                            depth = crate::lexer::dec(depth);
                            this_ = adv(this_);
                        }
                        Unit{};
                    }));
                    goto _done;
                }
                if (prism_rtl::is<crate::lexer::TokKind::KLaySep>(_m)) {
                    if (depth == Nat(0u)) {
                        _v.set(({
                            going = false;
                            Unit{};
                        }));
                        goto _done;
                    }
                }
                {
                    _v.set(({
                        this_ = adv(this_);
                        Unit{};
                    }));
                    goto _done;
                }
            _done:
                _v.take();
            });
            Expected<std::tuple<Ps, Nat, bool>, std::tuple<Ps, Nat, bool>>(std::tuple{this_, depth, going});
        })
            : Expected<std::tuple<Ps, Nat, bool>, std::tuple<Ps, Nat, bool>>(unexpected(std::tuple{this_, depth, going}));
    }), [=](std::tuple<Ps, Nat, bool> _p0) {
        auto this_ = std::get<0>(_p0);
        auto depth = std::get<1>(_p0);
        auto going = std::get<2>(_p0);
        return prism_rtl::finished(this_);
    });
}


/// `Start Recover, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Ps> start_recover(Ps p0) {
    return prism_rtl::make_rc<Recover>(p0);
}


/// Recovered: unbounded fn Ps -> Ps
Ps recovered(const Ps& p_) {
    return p_->bad ? recover(p_) : p_;
}


prism_rtl::Turn<Ps> Recovered::cycle() const {
    const auto& p_ = this->p_;
    return p_->bad
        ? prism_rtl::more(prism_rtl::rc(Recover(p_)))
        : prism_rtl::finished(p_);
}


/// `Start Recovered, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Ps> start_recovered(Ps p_) {
    return prism_rtl::make_rc<Recovered>(p_);
}


/// AtStmtBoundary: fn Ps -> Bool
bool at_stmt_boundary(const Ps& p_) {
    auto&& _m = kind(p_);
    if (prism_rtl::is<crate::lexer::TokKind::KLaySep>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::lexer::TokKind::KLayClose>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::lexer::TokKind::KEof>(_m)) {
        return true;
    }
    {
        return false;
    }
}


/// ExpectStmtEnd: unbounded fn Ps, Text -> Ps
Ps expect_stmt_end(const Ps& p_, const Text& what) {
    return at_stmt_boundary(p_)
        ? p_
        : recover(note_error(p_, here(p_), prism_rtl::cat("expected the end of the ", what, ", found ", describe(kind(p_)))));
}


prism_rtl::Turn<Ps> ExpectStmtEnd::cycle() const {
    const auto& p_ = this->p_;
    const auto& what = this->what;
    return at_stmt_boundary(p_)
        ? prism_rtl::finished(p_)
        : prism_rtl::more(prism_rtl::rc(Recover(note_error(p_, here(p_), prism_rtl::cat("expected the end of the ", what, ", found ", describe(kind(p_)))))));
}


/// `Start ExpectStmtEnd, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Ps> start_expect_stmt_end(Ps p_, Text what) {
    return prism_rtl::make_rc<ExpectStmtEnd>(p_, what);
}


/// Describe: fn TokKind -> Text
Text describe(const crate::lexer::TokKind& tok_kind0) {
    if (prism_rtl::is<crate::lexer::TokKind::KLayOpen>(tok_kind0)) {
        return Text::lit("an indented block");
    }
    if (prism_rtl::is<crate::lexer::TokKind::KLaySep>(tok_kind0)) {
        return Text::lit("the end of the line");
    }
    if (prism_rtl::is<crate::lexer::TokKind::KLayClose>(tok_kind0)) {
        return Text::lit("the end of the block");
    }
    if (prism_rtl::is<crate::lexer::TokKind::KEof>(tok_kind0)) {
        return Text::lit("the end of the input");
    }
    if (prism_rtl::is<crate::lexer::TokKind::KText>(tok_kind0)) {
        return Text::lit("a text literal");
    }
    if (prism_rtl::is<crate::lexer::TokKind::KTemplate>(tok_kind0)) {
        return Text::lit("a template");
    }
    {
        auto&& k = tok_kind0;
        return prism_rtl::cat("`", crate::lexer::token_text(k), "`");
    }
}


/// WithStepMode: fn Ps, Bool -> Ps
Ps with_step_mode(const Ps& p_, const bool& flag) {
    Ps this_ = p_;
    this_.step_mode = flag;
    return this_;
}


/// let noSName
crate::ast::SName no_sname() {
    return crate::ast::SName{.sigils = Text::lit(""), .path_ = Array<Text>{}, .span = no_range()};
}


/// let noIdent
crate::ast::Ident no_ident() {
    return crate::ast::Ident{.name = Text::lit(""), .span = no_range()};
}


/// IsUpperName: fn SName -> Bool
bool is_upper_name(const crate::ast::SName& n) {
    return crate::lexer::is_upper(crate::lexer::head(or_(crate::lexer::last(n->path_), Text::lit(""))));
}


/// IsCallee: fn SName -> Bool
bool is_callee(const crate::ast::SName& n) {
    return is_upper_name(n) || crate::lexer::is_reserved_ctor(or_(crate::lexer::last(n->path_), Text::lit("")));
}


/// IsTopic: fn SName -> Bool
bool is_topic(const crate::ast::SName& n) {
    return n->path_ == Array(std::vector{Text::lit("_")});
}


/// NameText: fn SName -> Text
Text name_text(const crate::ast::SName& n) {
    return prism_rtl::cat(n.sigils, crate::lexer::join(n->path_, Text::lit(".")));
}


/// ParseSName: fn Ps -> ((SName, Ps))
std::tuple<crate::ast::SName, Ps> parse_sname(const Ps& p_) {
    auto&& _m = kind(p_);
    if (prism_rtl::is<crate::lexer::TokKind::KName>(_m)) {
        auto&& n = prism_rtl::as<crate::lexer::TokKind::KName>(_m).a0;
        return std::tuple{crate::ast::SName{.sigils = n.sigils, .path_ = n->path_, .span = here(p_)}, adv(p_)};
    }
    {
        return std::tuple{no_sname(), error_here(p_, Text::lit("expected a name"))};
    }
}


/// ParseIdent: fn Ps -> ((Ident, Ps))
std::tuple<crate::ast::Ident, Ps> parse_ident(const Ps& p_) {
    auto&& _m = kind(p_);
    if (prism_rtl::is<crate::lexer::TokKind::KName>(_m)) {
        auto&& n = prism_rtl::as<crate::lexer::TokKind::KName>(_m).a0;
        if (((n.sigils == Text::lit("")) && (len(n->path_) == Nat(1u))) && (n.case_ == crate::lexer::NameCase(crate::lexer::NameCase::CaseLower{}))) {
            return std::tuple{crate::ast::Ident{.name = or_(index(n->path_, Nat(0u)), Text::lit("")), .span = here(p_)}, adv(p_)};
        }
    }
    if (prism_rtl::is<crate::lexer::TokKind::KKw>(_m)) {
        auto&& m15981_1_0 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a0;
        auto&& m15981_1_1 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a1;
        if (m15981_1_0 == Text::lit("key")) {
            if (m15981_1_1 == Text::lit("")) {
                return std::tuple{crate::ast::Ident{.name = Text::lit("key"), .span = here(p_)}, adv(p_)};
            }
        }
    }
    {
        return std::tuple{no_ident(), error_here(p_, Text::lit("expected a lowercase name"))};
    }
}


/// ParseQualName: fn Ps -> ((QualName, Ps))
std::tuple<crate::ast::QualName, Ps> parse_qual_name(const Ps& p_) {
    auto&& _m = kind(p_);
    if (prism_rtl::is<crate::lexer::TokKind::KName>(_m)) {
        auto&& n = prism_rtl::as<crate::lexer::TokKind::KName>(_m).a0;
        if ((n.sigils == Text::lit("")) && (n.case_ == crate::lexer::NameCase(crate::lexer::NameCase::CaseUpper{}))) {
            return std::tuple{crate::ast::QualName{.path_ = n->path_, .span = here(p_)}, adv(p_)};
        }
    }
    {
        return std::tuple{crate::ast::QualName{.path_ = Array<Text>{}, .span = no_range()}, error_here(p_, Text::lit("expected an uppercase name"))};
    }
}


/// ParseTraitRef: fn Ps -> ((TraitRef, Ps))
std::tuple<crate::ast::TraitRef, Ps> parse_trait_ref(const Ps& p_) {
    auto&& _m = kind(p_);
    if (prism_rtl::is<crate::lexer::TokKind::KTrait>(_m)) {
        auto&& path_ = prism_rtl::as<crate::lexer::TokKind::KTrait>(_m).a0;
        auto span = here(p_);
        auto q = path_ == Array(std::vector{Text::lit("Monad")})
            ? out_of_scope(p_, span, Text::lit("`T monad:` blocks and `^Monad`"), Text::lit("`^Monad` is out of this compiler"))
            : p_;
        return std::tuple{crate::ast::TraitRef{.path_ = path_, .span = span}, adv(q)};
    }
    {
        return std::tuple{crate::ast::TraitRef{.path_ = Array<Text>{}, .span = no_range()}, error_here(p_, Text::lit("expected a trait, `^Name`"))};
    }
}


/// CheckNameScope: fn Ps, SName -> Ps
Ps check_name_scope(const Ps& p_, const crate::ast::SName& name) {
    auto text = name_text(name);
    auto feature = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        {
            auto&& m17144_0 = text;
            if (m17144_0 == Text::lit("!Align")) {
                _v.set(Text::lit("`!Align`"));
                goto _done;
            }
        }
        {
            auto&& m17144_1 = text;
            if (m17144_1 == Text::lit("@Collect")) {
                _v.set(Text::lit("POD hosting (`@Collect`, `@View`, `@Edit`, `@Translate`)"));
                goto _done;
            }
        }
        {
            auto&& m17144_2 = text;
            if (m17144_2 == Text::lit("@View")) {
                _v.set(Text::lit("POD hosting (`@Collect`, `@View`, `@Edit`, `@Translate`)"));
                goto _done;
            }
        }
        {
            auto&& m17144_3 = text;
            if (m17144_3 == Text::lit("@Edit")) {
                _v.set(Text::lit("POD hosting (`@Collect`, `@View`, `@Edit`, `@Translate`)"));
                goto _done;
            }
        }
        {
            auto&& m17144_4 = text;
            if (m17144_4 == Text::lit("@Translate")) {
                _v.set(Text::lit("POD hosting (`@Collect`, `@View`, `@Edit`, `@Translate`)"));
                goto _done;
            }
        }
        {
            auto&& m17144_5 = text;
            if (m17144_5 == Text::lit("Over")) {
                _v.set(Text::lit("named lenses `&Home` and `Over`"));
                goto _done;
            }
        }
        {
            _v.set(Text::lit(""));
            goto _done;
        }
    _done:
        _v.take();
    });
    return feature == Text::lit("")
        ? p_
        : out_of_scope(p_, name.span, feature, prism_rtl::cat("`", text, "` is out of this compiler"));
}


/// CheckTypeNameScope: fn Ps, SName -> Ps
Ps check_type_name_scope(const Ps& p_, const crate::ast::SName& name) {
    auto b = or_(crate::lexer::last(name->path_), Text::lit(""));
    auto sized = fold(Array(std::vector{Text::lit("U16"), Text::lit("U32"), Text::lit("U64"), Text::lit("U128"), Text::lit("I8"), Text::lit("I16"), Text::lit("I32"), Text::lit("I64"), Text::lit("I128")}), false, [&](const bool& seen, const Text& s) { return seen || (s == b); });
    return len(name->path_) != Nat(1u)
        ? p_
        : sized
        ? out_of_scope(p_, name.span, Text::lit("sized ints other than `U8`"), prism_rtl::cat("`", b, "` is out of this compiler: the sized integer it has is `U8`"))
        : b == Text::lit("Instant")
        ? out_of_scope(p_, name.span, Text::lit("`Instant`"), Text::lit("`Instant` is out of this compiler"))
        : p_;
}


/// ParseModule: unbounded fn Ps, Bool -> ((Module, Ps))
std::tuple<crate::ast::Module, Ps> parse_module(const Ps& p0, const bool& fragment) {
    auto start = here(p0);
    auto [template_opt, p1] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<std::optional<crate::ast::Template>, Ps>> _v;
        auto&& _m = kind(p0);
        if (prism_rtl::is<crate::lexer::TokKind::KTemplate>(_m)) {
            auto&& t = prism_rtl::as<crate::lexer::TokKind::KTemplate>(_m).a0;
            _v.set(({
                auto [tpl, q] = parse_template(adv(p0), t, here(p0));
                std::tuple{std::optional(tpl), q};
            }));
            goto _done;
        }
        {
            _v.set(std::tuple{std::optional<crate::ast::Template>{}, p0});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto m0 = crate::ast::Module{.name = std::optional<crate::ast::QualName>{}, .emit_row = std::optional<crate::ast::Row_>{}, .mods = Array<crate::ast::ModLine>{}, .uses = Array<crate::ast::Use>{}, .decls = Array<crate::ast::Decl>{}, .template_ = template_opt, .span = start};
    auto r = ({
        ModRead this_ = ModRead{.p_ = p1, .m = m0, .stage = Nat(0u)};
        while (!at_eof(this_.p_)) {
            this_ = module_item(this_, fragment);
        }
        this_;
    });
    auto m = ({
        crate::ast::Module this_ = r->m;
        this_.span = to(start, parser::prev(r.p_));
        this_;
    });
    return std::tuple{m, r.p_};
}


prism_rtl::Turn<std::tuple<crate::ast::Module, Ps>> ParseModule::cycle() const {
    const auto& p0 = this->p0;
    const auto& fragment = this->fragment;
    auto start = here(p0);
    auto [template_opt, p1] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<std::optional<crate::ast::Template>, Ps>> _v;
        auto&& _m = kind(p0);
        if (prism_rtl::is<crate::lexer::TokKind::KTemplate>(_m)) {
            auto&& t = prism_rtl::as<crate::lexer::TokKind::KTemplate>(_m).a0;
            _v.set(({
                auto [tpl, q] = parse_template(adv(p0), t, here(p0));
                std::tuple{std::optional(tpl), q};
            }));
            goto _done;
        }
        {
            _v.set(std::tuple{std::optional<crate::ast::Template>{}, p0});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto m0 = crate::ast::Module{.name = std::optional<crate::ast::QualName>{}, .emit_row = std::optional<crate::ast::Row_>{}, .mods = Array<crate::ast::ModLine>{}, .uses = Array<crate::ast::Use>{}, .decls = Array<crate::ast::Decl>{}, .template_ = template_opt, .span = start};
    ModRead this_ = ModRead{.p_ = p1, .m = m0, .stage = Nat(0u)};
    auto start_1 = start;
    return call_then(loop_job(std::tuple{this_}, ({
        auto fragment_2 = fragment;
        [=](std::tuple<ModRead> _p0) {
        auto this_ = std::get<0>(_p0);
        return !at_eof(this_.p_)
            ? ({
            this_ = module_item(this_, fragment_2);
            Expected<std::tuple<ModRead>, std::tuple<ModRead>>(std::tuple{this_});
        })
            : Expected<std::tuple<ModRead>, std::tuple<ModRead>>(unexpected(std::tuple{this_}));
    };
    })), [=](std::tuple<ModRead> _p0) {
        auto this_ = std::get<0>(_p0);
        return ({
            auto r = this_;
            auto m = ({
                crate::ast::Module this_ = r->m;
                this_.span = to(start_1, parser::prev(r.p_));
                this_;
            });
            (prism_rtl::finished(std::tuple{m, r.p_}));
        });
    });
}


/// `Start ParseModule, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::ast::Module, Ps>> start_parse_module(Ps p0, bool fragment) {
    return prism_rtl::make_rc<ParseModule>(p0, fragment);
}


/// ModuleItem: unbounded fn ModRead, Bool -> ModRead
ModRead module_item(const ModRead& s, const bool& fragment) {
    return at_sep(s.p_)
        ? ({
        ModRead this_ = s;
        this_.p_ = adv(this_.p_);
        this_;
    })
        : ({
        auto s1 = header_or_decl(s, fragment, here(s.p_));
        auto p2 = recovered(s1.p_);
        auto p3 = at_close_l(p2)
            ? adv(p2)
            : at_eof(p2) ? p2 : expect_stmt_end(p2, Text::lit("declaration"));
        ({
        ModRead this_ = s1;
        this_.p_ = p3;
        this_;
    });
    });
}


prism_rtl::Turn<ModRead> ModuleItem::cycle() const {
    const auto& s = this->s;
    const auto& fragment = this->fragment;
    return at_sep(s.p_)
        ? prism_rtl::finished(({
        ModRead this_ = s;
        this_.p_ = adv(this_.p_);
        this_;
    }))
        : ({
        auto fragment_1 = fragment;
        auto s_2 = s;
        call_then(start_header_or_decl(s_2, fragment_1, here(s_2.p_)), [=](ModRead header_or_decl_19729) {
        return ({
            auto s1 = header_or_decl_19729;
            call_then(start_recovered(s1.p_), [=](Ps recovered_19783) {
            return ({
                auto p2 = recovered_19783;
                auto p3 = at_close_l(p2)
                    ? adv(p2)
                    : at_eof(p2) ? p2 : expect_stmt_end(p2, Text::lit("declaration"));
                (prism_rtl::finished(({
                ModRead this_ = s1;
                this_.p_ = p3;
                this_;
            })));
            });
        });
        });
    });
    });
}


/// `Start ModuleItem, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<ModRead> start_module_item(ModRead s, bool fragment) {
    return prism_rtl::make_rc<ModuleItem>(s, fragment);
}


/// HeaderOrDecl: unbounded fn ModRead, Bool, Range -> ModRead
ModRead header_or_decl(const ModRead& s, const bool& fragment, const crate::ast::Range& item_start) {
    auto&& _m = kind(s.p_);
    if (prism_rtl::is<crate::lexer::TokKind::KKw>(_m)) {
        auto&& m20105_0_0 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a0;
        auto&& m20105_0_1 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a1;
        if (m20105_0_0 == Text::lit("module")) {
            if (m20105_0_1 == Text::lit("")) {
                auto [name, p_] = parse_qual_name(adv(s.p_));
                return p_->bad
                    ? ({
                    ModRead this_ = s;
                    this_.p_ = p_;
                    this_;
                })
                    : ({
                    auto late = (s.stage > Nat(0u)) || (s->m.name != std::optional<crate::ast::QualName>{});
                    ({
                    ModRead this_ = s;
                    this_.p_ = late
                        ? note_error(p_, item_start, Text::lit("the `module` line comes first in a file"))
                        : p_;
                    this_.m.name = std::optional(name);
                    this_.stage = Nat(1u);
                    this_;
                });
                });
            }
        }
    }
    if (prism_rtl::is<crate::lexer::TokKind::KKw>(_m)) {
        auto&& m20105_1_0 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a0;
        auto&& m20105_1_1 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a1;
        if (m20105_1_0 == Text::lit("emit")) {
            if (m20105_1_1 == Text::lit("")) {
                auto [emit_row, p_] = parse_row(adv(s.p_));
                return p_->bad
                    ? ({
                    ModRead this_ = s;
                    this_.p_ = p_;
                    this_;
                })
                    : ({
                    auto late = (s.stage > Nat(1u)) || (s->m.emit_row != std::optional<crate::ast::Row_>{});
                    ({
                    ModRead this_ = s;
                    this_.p_ = late
                        ? note_error(p_, item_start, Text::lit("`emit` comes after `module` and above `use`, once (Semantics ch. 6)"))
                        : p_;
                    this_.m.emit_row = std::optional(emit_row);
                    this_.stage = Nat(2u);
                    this_;
                });
                });
            }
        }
    }
    if (prism_rtl::is<crate::lexer::TokKind::KKw>(_m)) {
        auto&& m20105_2_0 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a0;
        auto&& m20105_2_1 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a1;
        if (m20105_2_0 == Text::lit("use")) {
            if (m20105_2_1 == Text::lit("")) {
                auto [u, p_] = parse_use(adv(s.p_), item_start);
                return p_->bad
                    ? ({
                    ModRead this_ = s;
                    this_.p_ = p_;
                    this_;
                })
                    : ({
                    ModRead this_ = s;
                    this_.p_ = s.stage > Nat(4u)
                        ? note_error(p_, item_start, Text::lit("`use` lines belong to the header, above the declarations"))
                        : p_;
                    this_.m.uses = prelude::push(this_.m.uses, u);
                    this_.stage = Nat(4u);
                    this_;
                });
            }
        }
    }
    if (prism_rtl::is<crate::lexer::TokKind::KKw>(_m)) {
        auto&& m20105_3_0 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a0;
        auto&& m20105_3_1 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a1;
        if (m20105_3_0 == Text::lit("mod")) {
            if (m20105_3_1 == Text::lit("")) {
                return mod_header(s, adv(s.p_), false, item_start);
            }
        }
    }
    if (prism_rtl::is<crate::lexer::TokKind::KKw>(_m)) {
        auto&& m20105_4_0 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a0;
        auto&& m20105_4_1 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a1;
        if (m20105_4_0 == Text::lit("test")) {
            if (m20105_4_1 == Text::lit("")) {
                if (is_kw_kind(kind(adv(s.p_)), Text::lit("mod"))) {
                    return mod_header(s, adv(adv(s.p_)), true, item_start);
                }
            }
        }
    }
    {
        auto [d, p_] = parse_decl(s.p_, fragment);
        ModRead this_ = s;
        this_.p_ = p_;
        this_.stage = Nat(5u);
        if (!p_->bad) {
            this_.m.decls = prelude::push(this_.m.decls, d);
        }
        return this_;
    }
}


prism_rtl::Turn<ModRead> HeaderOrDecl::cycle() const {
    const auto& s = this->s;
    const auto& fragment = this->fragment;
    const auto& item_start = this->item_start;
    return ({
        auto&& _m = kind(s.p_);
        prism_rtl::is<crate::lexer::TokKind::KKw>(_m) && ({
        auto&& m20105_0_0 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a0;
        auto&& m20105_0_1 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a1;
        (m20105_0_0 == Text::lit("module")) && (m20105_0_1 == Text::lit(""));
    }) ? ({
        auto&& m20105_0_0 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a0;
        auto&& m20105_0_1 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a1;
        ({
        auto [name, p_] = parse_qual_name(adv(s.p_));
        p_->bad
        ? prism_rtl::finished(({
        ModRead this_ = s;
        this_.p_ = p_;
        this_;
    }))
        : ({
        auto late = (s.stage > Nat(0u)) || (s->m.name != std::optional<crate::ast::QualName>{});
        (prism_rtl::finished(({
        ModRead this_ = s;
        this_.p_ = late
            ? note_error(p_, item_start, Text::lit("the `module` line comes first in a file"))
            : p_;
        this_.m.name = std::optional(name);
        this_.stage = Nat(1u);
        this_;
    })));
    });
    });
    })
        : prism_rtl::is<crate::lexer::TokKind::KKw>(_m) && ({
        auto&& m20105_1_0 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a0;
        auto&& m20105_1_1 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a1;
        (m20105_1_0 == Text::lit("emit")) && (m20105_1_1 == Text::lit(""));
    }) ? ({
        auto&& m20105_1_0 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a0;
        auto&& m20105_1_1 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a1;
        ({
        auto item_start_1 = item_start;
        auto s_2 = s;
        call_then(start_parse_row(adv(s_2.p_)), [=](std::tuple<crate::ast::Row_, Ps> parse_row_20556) {
        return ({
            auto [emit_row, p_] = parse_row_20556;
            p_->bad
            ? prism_rtl::finished(({
            ModRead this_ = s_2;
            this_.p_ = p_;
            this_;
        }))
            : ({
            auto late = (s_2.stage > Nat(1u)) || (s_2->m.emit_row != std::optional<crate::ast::Row_>{});
            (prism_rtl::finished(({
            ModRead this_ = s_2;
            this_.p_ = late
                ? note_error(p_, item_start_1, Text::lit("`emit` comes after `module` and above `use`, once (Semantics ch. 6)"))
                : p_;
            this_.m.emit_row = std::optional(emit_row);
            this_.stage = Nat(2u);
            this_;
        })));
        });
        });
    });
    });
    })
        : prism_rtl::is<crate::lexer::TokKind::KKw>(_m) && ({
        auto&& m20105_2_0 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a0;
        auto&& m20105_2_1 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a1;
        (m20105_2_0 == Text::lit("use")) && (m20105_2_1 == Text::lit(""));
    }) ? ({
        auto&& m20105_2_0 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a0;
        auto&& m20105_2_1 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a1;
        ({
        auto [u, p_] = parse_use(adv(s.p_), item_start);
        p_->bad
        ? prism_rtl::finished(({
        ModRead this_ = s;
        this_.p_ = p_;
        this_;
    }))
        : prism_rtl::finished(({
        ModRead this_ = s;
        this_.p_ = s.stage > Nat(4u)
            ? note_error(p_, item_start, Text::lit("`use` lines belong to the header, above the declarations"))
            : p_;
        this_.m.uses = prelude::push(this_.m.uses, u);
        this_.stage = Nat(4u);
        this_;
    }));
    });
    })
        : prism_rtl::is<crate::lexer::TokKind::KKw>(_m) && ({
        auto&& m20105_3_0 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a0;
        auto&& m20105_3_1 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a1;
        (m20105_3_0 == Text::lit("mod")) && (m20105_3_1 == Text::lit(""));
    }) ? ({
        auto&& m20105_3_0 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a0;
        auto&& m20105_3_1 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a1;
        prism_rtl::finished(mod_header(s, adv(s.p_), false, item_start));
    })
        : prism_rtl::is<crate::lexer::TokKind::KKw>(_m) && ({
        auto&& m20105_4_0 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a0;
        auto&& m20105_4_1 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a1;
        (m20105_4_0 == Text::lit("test")) && (m20105_4_1 == Text::lit("")) && is_kw_kind(kind(adv(s.p_)), Text::lit("mod"));
    }) ? ({
        auto&& m20105_4_0 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a0;
        auto&& m20105_4_1 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a1;
        prism_rtl::finished(mod_header(s, adv(adv(s.p_)), true, item_start));
    })
        : ({
        auto fragment_1 = fragment;
        auto s_2 = s;
        call_then(start_parse_decl(s_2.p_, fragment_1), [=](std::tuple<crate::ast::Decl, Ps> parse_decl_21492) {
        return ({
            auto [d, p_] = parse_decl_21492;
            (prism_rtl::finished(({
            ModRead this_ = s_2;
            this_.p_ = p_;
            this_.stage = Nat(5u);
            if (!p_->bad) {
                this_.m.decls = prelude::push(this_.m.decls, d);
            }
            this_;
        })));
        });
    });
    });
    });
}


/// `Start HeaderOrDecl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<ModRead> start_header_or_decl(ModRead s, bool fragment, crate::ast::Range item_start) {
    return prism_rtl::make_rc<HeaderOrDecl>(s, fragment, item_start);
}


/// ModHeader: fn ModRead, Ps, Bool, Range -> ModRead
ModRead mod_header(const ModRead& s, const Ps& p_, const bool& is_test, const crate::ast::Range& item_start) {
    auto&& _m = kind(p_);
    if (prism_rtl::is<crate::lexer::TokKind::KName>(_m)) {
        auto&& n = prism_rtl::as<crate::lexer::TokKind::KName>(_m).a0;
        if (((n.sigils == Text::lit("")) && (len(n->path_) == Nat(1u))) && (!(is_test && (n.case_ == crate::lexer::NameCase(crate::lexer::NameCase::CaseUpper{}))))) {
            auto line = crate::ast::ModLine{.name = crate::ast::Ident{.name = or_(index(n->path_, Nat(0u)), Text::lit("")), .span = here(p_)}, .is_test = is_test, .span = to(item_start, here(p_))};
            ModRead this_ = s;
            this_.p_ = s.stage > Nat(3u)
                ? note_error(adv(p_), item_start, Text::lit("`mod` lines come after `emit` and above `use` (docs/modules-style-pass.md)"))
                : adv(p_);
            this_.m.mods = prelude::push(this_.m.mods, line);
            this_.stage = Nat(3u);
            return this_;
        }
    }
    {
        ModRead this_ = s;
        this_.p_ = error_here(p_, is_test
            ? Text::lit("expected a test module's lowercase name after `test mod`")
            : Text::lit("expected a section's or a submodule's name after `mod`"));
        return this_;
    }
}


/// IsKwKind: fn TokKind, Text -> Bool
bool is_kw_kind(const crate::lexer::TokKind& k, const Text& w) {
    if (prism_rtl::is<crate::lexer::TokKind::KKw>(k)) {
        auto&& x = prism_rtl::as<crate::lexer::TokKind::KKw>(k).a0;
        return x == w;
    }
    {
        return false;
    }
}


/// let noQual
crate::ast::QualName no_qual() {
    return crate::ast::QualName{.path_ = Array<Text>{}, .span = no_range()};
}


/// ParseUse: fn Ps, Range -> ((Use, Ps))
std::tuple<crate::ast::Use, Ps> parse_use(const Ps& p_, const crate::ast::Range& start) {
    auto&& _m = kind(p_);
    if (prism_rtl::is<crate::lexer::TokKind::KFamily>(_m)) {
        auto&& path_ = prism_rtl::as<crate::lexer::TokKind::KFamily>(_m).a0;
        return std::tuple{crate::ast::Use{.target = crate::ast::QualName{.path_ = path_, .span = here(p_)}, .star = true, .span = to(start, here(p_))}, adv(p_)};
    }
    if (prism_rtl::is<crate::lexer::TokKind::KName>(_m)) {
        auto&& n = prism_rtl::as<crate::lexer::TokKind::KName>(_m).a0;
        if ((n.sigils == Text::lit("")) && (n.case_ == crate::lexer::NameCase(crate::lexer::NameCase::CaseUpper{}))) {
            return std::tuple{crate::ast::Use{.target = crate::ast::QualName{.path_ = n->path_, .span = here(p_)}, .star = false, .span = to(start, here(p_))}, adv(p_)};
        }
    }
    {
        return std::tuple{crate::ast::Use{.target = no_qual(), .star = false, .span = no_range()}, error_here(p_, Text::lit("expected a module name after `use`"))};
    }
}


/// let noExpr
crate::ast::Expr no_expr() {
    return crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::EError{})), .span = no_range()};
}


/// let noType
crate::ast::Type no_type() {
    return crate::ast::Type{.kind = prism_rtl::rc(crate::ast::TypeKind(crate::ast::TypeKind::TAbsent{})), .span = no_range()};
}


/// let noPattern
crate::ast::Pattern_ no_pattern() {
    return crate::ast::Pattern_{.kind = prism_rtl::rc(crate::ast::PatternKind(crate::ast::PatternKind::PIgnore{})), .span = no_range()};
}


/// let noBlock
crate::ast::Block no_block() {
    return crate::ast::Block{.stmts = Array<crate::ast::Stmt>{}, .inline_ = true, .span = no_range()};
}


/// ParseDecl: unbounded fn Ps, Bool -> ((Decl, Ps))
std::tuple<crate::ast::Decl, Ps> parse_decl(const Ps& p_, const bool& fragment) {
    auto start = here(p_);
    auto [kind_, q] = decl_kind_of(p_, fragment, start);
    return std::tuple{crate::ast::Decl{.kind = kind_, .span = to(start, parser::prev(q))}, q};
}


prism_rtl::Turn<std::tuple<crate::ast::Decl, Ps>> ParseDecl::cycle() const {
    const auto& p_ = this->p_;
    const auto& fragment = this->fragment;
    auto start = here(p_);
    auto fragment_1 = fragment;
    auto p__2 = p_;
    return call_then(start_decl_kind_of(p__2, fragment_1, start), [=](std::tuple<crate::ast::DeclKind, Ps> decl_kind_of_23436) {
        return ({
            auto [kind_, q] = decl_kind_of_23436;
            (prism_rtl::finished(std::tuple{crate::ast::Decl{.kind = kind_, .span = to(start, parser::prev(q))}, q}));
        });
    });
}


/// `Start ParseDecl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::ast::Decl, Ps>> start_parse_decl(Ps p_, bool fragment) {
    return prism_rtl::make_rc<ParseDecl>(p_, fragment);
}


/// DeclKindOf: unbounded fn Ps, Bool, Range -> ((DeclKind, Ps))
std::tuple<crate::ast::DeclKind, Ps> decl_kind_of(const Ps& p_, const bool& fragment, const crate::ast::Range& start) {
    auto&& _m = kind(p_);
    if (prism_rtl::is<crate::lexer::TokKind::KKw>(_m)) {
        auto&& m23617_0_0 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a0;
        if (m23617_0_0 == Text::lit("type")) {
            auto [d, q] = parse_type_decl(p_);
            return std::tuple{crate::ast::DeclKind(crate::ast::DeclKind::DType{d}), q};
        }
    }
    if (prism_rtl::is<crate::lexer::TokKind::KKw>(_m)) {
        auto&& m23617_1_0 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a0;
        if (m23617_1_0 == Text::lit("tag")) {
            auto [d, q] = parse_tag_decl(p_);
            return std::tuple{crate::ast::DeclKind(crate::ast::DeclKind::DTag{d}), q};
        }
    }
    if (prism_rtl::is<crate::lexer::TokKind::KKw>(_m)) {
        auto&& m23617_2_0 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a0;
        if (m23617_2_0 == Text::lit("derive")) {
            auto [traits, q] = commas(adv(p_), ({
                auto f = prism_rtl::rc(parse_trait_ref);
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::ast::TraitRef, Ps>>(Ps)>>(prism_rtl::rc([=](Ps a0) {
                return ({
                    auto f_1 = f;
                    once_job([=]() { return prism_rtl::finished(f_1(a0)); });
                });
            }));
            }));
            return std::tuple{crate::ast::DeclKind(crate::ast::DeclKind::DDerive{traits}), q};
        }
    }
    if (prism_rtl::is<crate::lexer::TokKind::KKw>(_m)) {
        auto&& m23617_3_0 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a0;
        if (m23617_3_0 == Text::lit("trait")) {
            auto [d, q] = parse_trait_decl(p_);
            return std::tuple{crate::ast::DeclKind(crate::ast::DeclKind::DTrait{d}), q};
        }
    }
    if (prism_rtl::is<crate::lexer::TokKind::KKw>(_m)) {
        auto&& m23617_4_0 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a0;
        if (m23617_4_0 == Text::lit("impl")) {
            auto [d, q] = parse_impl_decl(p_);
            return std::tuple{crate::ast::DeclKind(crate::ast::DeclKind::DImpl{d}), q};
        }
    }
    if (prism_rtl::is<crate::lexer::TokKind::KKw>(_m)) {
        auto&& m23617_5_0 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a0;
        if (m23617_5_0 == Text::lit("check")) {
            auto [d, q] = parse_check_decl(p_);
            return std::tuple{crate::ast::DeclKind(crate::ast::DeclKind::DCheck{d}), q};
        }
    }
    if (prism_rtl::is<crate::lexer::TokKind::KKw>(_m)) {
        auto&& m23617_6_0 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a0;
        if (m23617_6_0 == Text::lit("test")) {
            auto [d, q] = parse_test_decl(p_);
            return std::tuple{crate::ast::DeclKind(crate::ast::DeclKind::DTest{d}), q};
        }
    }
    if (prism_rtl::is<crate::lexer::TokKind::KKw>(_m)) {
        auto&& m23617_7_0 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a0;
        if (m23617_7_0 == Text::lit("fn")) {
            auto [d, q] = parse_fn_clause(p_);
            return std::tuple{crate::ast::DeclKind(crate::ast::DeclKind::DFn{d}), q};
        }
    }
    if (prism_rtl::is<crate::lexer::TokKind::KKw>(_m)) {
        auto&& m23617_8_0 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a0;
        if (m23617_8_0 == Text::lit("let")) {
            auto [pattern, p1] = parse_pattern(adv(p_), false);
            auto [ty_opt, p2] = optional_annotation(p1);
            auto [value, p3] = parse_rhs_expr(expect_op(p2, Text::lit("=")));
            return std::tuple{crate::ast::DeclKind(crate::ast::DeclKind::DLet{crate::ast::LetDecl{.pattern = pattern, .ty = ty_opt, .value = value, .span = to(start, parser::prev(p3))}}), p3};
        }
    }
    if (prism_rtl::is<crate::lexer::TokKind::KName>(_m)) {
        if (kind_at(p_, Nat(1u)) == crate::lexer::TokKind(crate::lexer::TokKind::KColon{})) {
            return kind_at(p_, Nat(2u)) == crate::lexer::TokKind(crate::lexer::TokKind::KLayOpen{})
                ? ({
                auto [name, p1] = parse_sname(p_);
                auto [body, p2] = parse_block_after_colon(p1);
                std::tuple{crate::ast::DeclKind(crate::ast::DeclKind::DWidget{crate::ast::WidgetDecl{.name = name, .body = body, .span = to(start, body.span)}}), p2};
            })
                : ({
                auto [sig, q] = parse_signature(p_);
                std::tuple{crate::ast::DeclKind(crate::ast::DeclKind::DSignature{sig}), q};
            });
        }
    }
    {
        return fragment
            ? ({
            auto [st, q] = parse_stmt(p_);
            std::tuple{crate::ast::DeclKind(crate::ast::DeclKind::DStmt{st}), q};
        })
            : ({
            auto [st, q] = parse_stmt(p_);
            ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<crate::ast::DeclKind, Ps>> _v;
            auto&& _m = st.kind;
            if (prism_rtl::is<crate::ast::StmtKind::SBind>(_m)) {
                if (!q->bad) {
                    _v.set(std::tuple{crate::ast::DeclKind(crate::ast::DeclKind::DStmt{st}), error_at(q, start, Text::lit("a bind or hold is a statement of a widget block: nothing at top level is built (Semantics ch. 6)"))});
                    goto _done;
                }
            }
            {
                _v.set(({
                    auto at_ = q->bad ? p_ : q;
                    std::tuple{crate::ast::DeclKind(crate::ast::DeclKind::DStmt{st}), error_here(at_, Text::lit("expected a declaration (`fn`, `let`, `type`, `tag`, `derive`, `trait`, `impl`, `test`, `check`, or a signature `Name: type`)"))};
                }));
                goto _done;
            }
        _done:
            _v.take();
        });
        });
    }
}


prism_rtl::Turn<std::tuple<crate::ast::DeclKind, Ps>> DeclKindOf::cycle() const {
    const auto& p_ = this->p_;
    const auto& fragment = this->fragment;
    const auto& start = this->start;
    return ({
        auto&& _m = kind(p_);
        prism_rtl::is<crate::lexer::TokKind::KKw>(_m) && ({
        auto&& m23617_0_0 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a0;
        (m23617_0_0 == Text::lit("type"));
    }) ? ({
        auto&& m23617_0_0 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a0;
        ({
        auto p__1 = p_;
        call_then(start_parse_type_decl(p__1), [=](std::tuple<crate::ast::TypeDecl, Ps> parse_type_decl_23678) {
        return ({
            auto [d, q] = parse_type_decl_23678;
            (prism_rtl::finished(std::tuple{crate::ast::DeclKind(crate::ast::DeclKind::DType{d}), q}));
        });
    });
    });
    })
        : prism_rtl::is<crate::lexer::TokKind::KKw>(_m) && ({
        auto&& m23617_1_0 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a0;
        (m23617_1_0 == Text::lit("tag"));
    }) ? ({
        auto&& m23617_1_0 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a0;
        ({
        auto p__1 = p_;
        call_then(start_parse_tag_decl(p__1), [=](std::tuple<crate::ast::TagDecl, Ps> parse_tag_decl_23763) {
        return ({
            auto [d, q] = parse_tag_decl_23763;
            (prism_rtl::finished(std::tuple{crate::ast::DeclKind(crate::ast::DeclKind::DTag{d}), q}));
        });
    });
    });
    })
        : prism_rtl::is<crate::lexer::TokKind::KKw>(_m) && ({
        auto&& m23617_2_0 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a0;
        (m23617_2_0 == Text::lit("derive"));
    }) ? ({
        auto&& m23617_2_0 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a0;
        ({
        auto p__1 = p_;
        call_then(start_commas(adv(p__1), ({
        auto f = prism_rtl::rc(parse_trait_ref);
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::ast::TraitRef, Ps>>(Ps)>>(prism_rtl::rc([=](Ps a0) {
        return ({
            auto f_2 = f;
            once_job([=]() { return prism_rtl::finished(f_2(a0)); });
        });
    }));
    })), [=](std::tuple<Array<crate::ast::TraitRef>, Ps> commas_23854) {
        return ({
            auto [traits, q] = commas_23854;
            (prism_rtl::finished(std::tuple{crate::ast::DeclKind(crate::ast::DeclKind::DDerive{traits}), q}));
        });
    });
    });
    })
        : prism_rtl::is<crate::lexer::TokKind::KKw>(_m) && ({
        auto&& m23617_3_0 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a0;
        (m23617_3_0 == Text::lit("trait"));
    }) ? ({
        auto&& m23617_3_0 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a0;
        ({
        auto p__1 = p_;
        call_then(start_parse_trait_decl(p__1), [=](std::tuple<crate::ast::TraitDecl, Ps> parse_trait_decl_23962) {
        return ({
            auto [d, q] = parse_trait_decl_23962;
            (prism_rtl::finished(std::tuple{crate::ast::DeclKind(crate::ast::DeclKind::DTrait{d}), q}));
        });
    });
    });
    })
        : prism_rtl::is<crate::lexer::TokKind::KKw>(_m) && ({
        auto&& m23617_4_0 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a0;
        (m23617_4_0 == Text::lit("impl"));
    }) ? ({
        auto&& m23617_4_0 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a0;
        ({
        auto p__1 = p_;
        call_then(start_parse_impl_decl(p__1), [=](std::tuple<crate::ast::ImplDecl, Ps> parse_impl_decl_24050) {
        return ({
            auto [d, q] = parse_impl_decl_24050;
            (prism_rtl::finished(std::tuple{crate::ast::DeclKind(crate::ast::DeclKind::DImpl{d}), q}));
        });
    });
    });
    })
        : prism_rtl::is<crate::lexer::TokKind::KKw>(_m) && ({
        auto&& m23617_5_0 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a0;
        (m23617_5_0 == Text::lit("check"));
    }) ? ({
        auto&& m23617_5_0 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a0;
        ({
        auto p__1 = p_;
        call_then(start_parse_check_decl(p__1), [=](std::tuple<crate::ast::CheckDecl, Ps> parse_check_decl_24137) {
        return ({
            auto [d, q] = parse_check_decl_24137;
            (prism_rtl::finished(std::tuple{crate::ast::DeclKind(crate::ast::DeclKind::DCheck{d}), q}));
        });
    });
    });
    })
        : prism_rtl::is<crate::lexer::TokKind::KKw>(_m) && ({
        auto&& m23617_6_0 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a0;
        (m23617_6_0 == Text::lit("test"));
    }) ? ({
        auto&& m23617_6_0 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a0;
        ({
        auto p__1 = p_;
        call_then(start_parse_test_decl(p__1), [=](std::tuple<crate::ast::TestDecl, Ps> parse_test_decl_24225) {
        return ({
            auto [d, q] = parse_test_decl_24225;
            (prism_rtl::finished(std::tuple{crate::ast::DeclKind(crate::ast::DeclKind::DTest{d}), q}));
        });
    });
    });
    })
        : prism_rtl::is<crate::lexer::TokKind::KKw>(_m) && ({
        auto&& m23617_7_0 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a0;
        (m23617_7_0 == Text::lit("fn"));
    }) ? ({
        auto&& m23617_7_0 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a0;
        ({
        auto p__1 = p_;
        call_then(start_parse_fn_clause(p__1), [=](std::tuple<crate::ast::FnClause, Ps> parse_fn_clause_24309) {
        return ({
            auto [d, q] = parse_fn_clause_24309;
            (prism_rtl::finished(std::tuple{crate::ast::DeclKind(crate::ast::DeclKind::DFn{d}), q}));
        });
    });
    });
    })
        : prism_rtl::is<crate::lexer::TokKind::KKw>(_m) && ({
        auto&& m23617_8_0 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a0;
        (m23617_8_0 == Text::lit("let"));
    }) ? ({
        auto&& m23617_8_0 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a0;
        ({
        auto p__1 = p_;
        auto start_2 = start;
        call_then(start_parse_pattern(adv(p__1), false), [=](std::tuple<crate::ast::Pattern_, Ps> parse_pattern_24399) {
        return ({
            auto [pattern, p1] = parse_pattern_24399;
            call_then(start_optional_annotation(p1), [=](std::tuple<std::optional<crate::ast::Type>, Ps> optional_annotation_24453) {
            return ({
                auto [ty_opt, p2] = optional_annotation_24453;
                call_then(start_parse_rhs_expr(expect_op(p2, Text::lit("="))), [=](std::tuple<crate::ast::Expr, Ps> parse_rhs_expr_24503) {
                return ({
                    auto [value, p3] = parse_rhs_expr_24503;
                    (prism_rtl::finished(std::tuple{crate::ast::DeclKind(crate::ast::DeclKind::DLet{crate::ast::LetDecl{.pattern = pattern, .ty = ty_opt, .value = value, .span = to(start_2, parser::prev(p3))}}), p3}));
                });
            });
            });
        });
        });
    });
    });
    })
        : prism_rtl::is<crate::lexer::TokKind::KName>(_m) && ({
        (kind_at(p_, Nat(1u)) == crate::lexer::TokKind(crate::lexer::TokKind::KColon{}));
    }) ? kind_at(p_, Nat(2u)) == crate::lexer::TokKind(crate::lexer::TokKind::KLayOpen{})
        ? ({
        auto [name, p1] = parse_sname(p_);
        auto start_1 = start;
        call_then(start_parse_block_after_colon(p1), [=](std::tuple<crate::ast::Block, Ps> parse_block_after_colon_24788) {
        return ({
            auto [body, p2] = parse_block_after_colon_24788;
            (prism_rtl::finished(std::tuple{crate::ast::DeclKind(crate::ast::DeclKind::DWidget{crate::ast::WidgetDecl{.name = name, .body = body, .span = to(start_1, body.span)}}), p2}));
        });
    });
    })
        : ({
        auto p__1 = p_;
        call_then(start_parse_signature(p__1), [=](std::tuple<crate::ast::Signature, Ps> parse_signature_24944) {
        return ({
            auto [sig, q] = parse_signature_24944;
            (prism_rtl::finished(std::tuple{crate::ast::DeclKind(crate::ast::DeclKind::DSignature{sig}), q}));
        });
    });
    })
        : fragment
        ? ({
        auto p__1 = p_;
        call_then(start_parse_stmt(p__1), [=](std::tuple<crate::ast::Stmt, Ps> parse_stmt_25059) {
        return ({
            auto [st, q] = parse_stmt_25059;
            (prism_rtl::finished(std::tuple{crate::ast::DeclKind(crate::ast::DeclKind::DStmt{st}), q}));
        });
    });
    })
        : ({
        auto p__1 = p_;
        auto start_2 = start;
        call_then(start_parse_stmt(p__1), [=](std::tuple<crate::ast::Stmt, Ps> parse_stmt_25267) {
        return ({
            auto [st, q] = parse_stmt_25267;
            ({
            auto&& _m = st.kind;
            prism_rtl::is<crate::ast::StmtKind::SBind>(_m) && ({
            (!q->bad);
        }) ? prism_rtl::finished(std::tuple{crate::ast::DeclKind(crate::ast::DeclKind::DStmt{st}), error_at(q, start_2, Text::lit("a bind or hold is a statement of a widget block: nothing at top level is built (Semantics ch. 6)"))})
            : ({
            auto at_ = q->bad ? p__1 : q;
            (prism_rtl::finished(std::tuple{crate::ast::DeclKind(crate::ast::DeclKind::DStmt{st}), error_here(at_, Text::lit("expected a declaration (`fn`, `let`, `type`, `tag`, `derive`, `trait`, `impl`, `test`, `check`, or a signature `Name: type`)"))}));
        });
        });
        });
    });
    });
    });
}


/// `Start DeclKindOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::ast::DeclKind, Ps>> start_decl_kind_of(Ps p_, bool fragment, crate::ast::Range start) {
    return prism_rtl::make_rc<DeclKindOf>(p_, fragment, start);
}


/// OptionalAnnotation: unbounded fn Ps -> ((?Type, Ps))
std::tuple<std::optional<crate::ast::Type>, Ps> optional_annotation(const Ps& p_) {
    return at_colon(p_)
        ? ({
        auto [ty, q] = parse_type(adv(p_));
        std::tuple{std::optional(ty), q};
    })
        : std::tuple{std::optional<crate::ast::Type>{}, p_};
}


prism_rtl::Turn<std::tuple<std::optional<crate::ast::Type>, Ps>> OptionalAnnotation::cycle() const {
    const auto& p_ = this->p_;
    return at_colon(p_)
        ? ({
        auto p__1 = p_;
        call_then(start_parse_type(adv(p__1)), [=](std::tuple<crate::ast::Type, Ps> parse_type_25957) {
        return ({
            auto [ty, q] = parse_type_25957;
            (prism_rtl::finished(std::tuple{std::optional(ty), q}));
        });
    });
    })
        : prism_rtl::finished(std::tuple{std::optional<crate::ast::Type>{}, p_});
}


/// `Start OptionalAnnotation, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<std::optional<crate::ast::Type>, Ps>> start_optional_annotation(Ps p_) {
    return prism_rtl::make_rc<OptionalAnnotation>(p_);
}


/// ParseSignature: unbounded fn Ps -> ((Signature, Ps))
std::tuple<crate::ast::Signature, Ps> parse_signature(const Ps& p_) {
    auto start = here(p_);
    auto [name, p1] = parse_def_name(p_);
    auto [ty, p2] = parse_type(expect_colon(p1));
    auto [bounds, p3] = optional_bounds(p2);
    return std::tuple{crate::ast::Signature{.name = name, .ty = ty, .bounds = bounds, .span = to(start, parser::prev(p3))}, p3};
}


prism_rtl::Turn<std::tuple<crate::ast::Signature, Ps>> ParseSignature::cycle() const {
    const auto& p_ = this->p_;
    auto start = here(p_);
    auto [name, p1] = parse_def_name(p_);
    return call_then(start_parse_type(expect_colon(p1)), [=](std::tuple<crate::ast::Type, Ps> parse_type_26239) {
        return ({
            auto [ty, p2] = parse_type_26239;
            call_then(start_optional_bounds(p2), [=](std::tuple<Array<crate::ast::Bound>, Ps> optional_bounds_26291) {
            return ({
                auto [bounds, p3] = optional_bounds_26291;
                (prism_rtl::finished(std::tuple{crate::ast::Signature{.name = name, .ty = ty, .bounds = bounds, .span = to(start, parser::prev(p3))}, p3}));
            });
        });
        });
    });
}


/// `Start ParseSignature, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::ast::Signature, Ps>> start_parse_signature(Ps p_) {
    return prism_rtl::make_rc<ParseSignature>(p_);
}


/// OptionalBounds: unbounded fn Ps -> (([Bound], Ps))
std::tuple<Array<crate::ast::Bound>, Ps> optional_bounds(const Ps& p_) {
    return at_kw(p_, Text::lit("where"))
        ? parse_bounds(adv(p_))
        : std::tuple{Array<crate::ast::Bound>{}, p_};
}


prism_rtl::Turn<std::tuple<Array<crate::ast::Bound>, Ps>> OptionalBounds::cycle() const {
    const auto& p_ = this->p_;
    return at_kw(p_, Text::lit("where"))
        ? prism_rtl::more(prism_rtl::rc(ParseBounds(adv(p_))))
        : prism_rtl::finished(std::tuple{Array<crate::ast::Bound>{}, p_});
}


/// `Start OptionalBounds, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::ast::Bound>, Ps>> start_optional_bounds(Ps p_) {
    return prism_rtl::make_rc<OptionalBounds>(p_);
}


/// ParseDefName: fn Ps -> ((DefName, Ps))
std::tuple<crate::ast::DefName, Ps> parse_def_name(const Ps& p_) {
    auto&& _m = kind(p_);
    if (prism_rtl::is<crate::lexer::TokKind::KName>(_m)) {
        auto&& n = prism_rtl::as<crate::lexer::TokKind::KName>(_m).a0;
        auto [name, q] = parse_sname(p_);
        auto lens = crate::lexer::has_prefix(n.sigils, Text::lit("&")) && is_upper_name(name);
        auto q2 = lens
            ? out_of_scope(q, name.span, Text::lit("named lenses `&Home` and `Over`"), prism_rtl::cat("the named lens `", name_text(name), "` is out of this compiler"))
            : q;
        return std::tuple{crate::ast::DefName(crate::ast::DefName::DefSName{name}), q2};
    }
    if (prism_rtl::is<crate::lexer::TokKind::KOp>(_m)) {
        auto&& op = prism_rtl::as<crate::lexer::TokKind::KOp>(_m).a0;
        if (p_.in_trait) {
            auto name = crate::ast::DefName(crate::ast::DefName::DefOp{op, here(p_)});
            return std::tuple{name, adv(p_)};
        }
    }
    {
        return std::tuple{crate::ast::DefName(crate::ast::DefName::DefSName{no_sname()}), error_here(p_, Text::lit("expected a name"))};
    }
}


/// ParseFnClause: unbounded fn Ps -> ((FnClause, Ps))
std::tuple<crate::ast::FnClause, Ps> parse_fn_clause(const Ps& p0) {
    auto start = here(p0);
    auto [name, p1] = parse_def_name(expect_kw(p0, Text::lit("fn")));
    auto [params, p2] = at_op(p1, Text::lit("=")) || at_colon(p1)
        ? std::tuple{Array<crate::ast::Pattern_>{}, p1}
        : commas(p1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::ast::Pattern_, Ps>>(Ps)>>(prism_rtl::rc([=](Ps p0) {
        return entered(once_job([=]() {
            return ({
                auto q = p0;
                (prism_rtl::more(prism_rtl::rc(ParsePattern(q, false))));
            });
        }));
    })));
    auto [body, p3] = parse_fn_body(p2);
    return std::tuple{crate::ast::FnClause{.name = name, .params = params, .body = body, .span = to(start, parser::prev(p3))}, p3};
}


prism_rtl::Turn<std::tuple<crate::ast::FnClause, Ps>> ParseFnClause::cycle() const {
    const auto& p0 = this->p0;
    auto start = here(p0);
    auto [name, p1] = parse_def_name(expect_kw(p0, Text::lit("fn")));
    auto [params, p2] = at_op(p1, Text::lit("=")) || at_colon(p1)
        ? std::tuple{Array<crate::ast::Pattern_>{}, p1}
        : commas(p1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::ast::Pattern_, Ps>>(Ps)>>(prism_rtl::rc([=](Ps p0) {
        return entered(once_job([=]() {
            return ({
                auto q = p0;
                (prism_rtl::more(prism_rtl::rc(ParsePattern(q, false))));
            });
        }));
    })));
    return call_then(start_parse_fn_body(p2), [=](std::tuple<crate::ast::FnBody, Ps> parse_fn_body_27414) {
        return ({
            auto [body, p3] = parse_fn_body_27414;
            (prism_rtl::finished(std::tuple{crate::ast::FnClause{.name = name, .params = params, .body = body, .span = to(start, parser::prev(p3))}, p3}));
        });
    });
}


/// `Start ParseFnClause, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::ast::FnClause, Ps>> start_parse_fn_clause(Ps p0) {
    return prism_rtl::make_rc<ParseFnClause>(p0);
}


/// ParseFnBody: unbounded fn Ps -> ((FnBody, Ps))
std::tuple<crate::ast::FnBody, Ps> parse_fn_body(const Ps& p_) {
    return at_op(p_, Text::lit("="))
        ? ({
        auto [e, q] = parse_rhs_expr(adv(p_));
        std::tuple{crate::ast::FnBody(crate::ast::FnBody::BodyExpr{e}), q};
    })
        : at_colon(p_)
        ? ({
        auto [b, q] = parse_block_after_colon(p_);
        std::tuple{crate::ast::FnBody(crate::ast::FnBody::BodyBlock{b}), q};
    })
        : std::tuple{crate::ast::FnBody(crate::ast::FnBody::BodyExpr{no_expr()}), error_here(p_, Text::lit("expected `=` and an expression, or `:` and a block, after the parameters"))};
}


prism_rtl::Turn<std::tuple<crate::ast::FnBody, Ps>> ParseFnBody::cycle() const {
    const auto& p_ = this->p_;
    return at_op(p_, Text::lit("="))
        ? ({
        auto p__1 = p_;
        call_then(start_parse_rhs_expr(adv(p__1)), [=](std::tuple<crate::ast::Expr, Ps> parse_rhs_expr_27624) {
        return ({
            auto [e, q] = parse_rhs_expr_27624;
            (prism_rtl::finished(std::tuple{crate::ast::FnBody(crate::ast::FnBody::BodyExpr{e}), q}));
        });
    });
    })
        : at_colon(p_)
        ? ({
        auto p__1 = p_;
        call_then(start_parse_block_after_colon(p__1), [=](std::tuple<crate::ast::Block, Ps> parse_block_after_colon_27718) {
        return ({
            auto [b, q] = parse_block_after_colon_27718;
            (prism_rtl::finished(std::tuple{crate::ast::FnBody(crate::ast::FnBody::BodyBlock{b}), q}));
        });
    });
    })
        : prism_rtl::finished(std::tuple{crate::ast::FnBody(crate::ast::FnBody::BodyExpr{no_expr()}), error_here(p_, Text::lit("expected `=` and an expression, or `:` and a block, after the parameters"))});
}


/// `Start ParseFnBody, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::ast::FnBody, Ps>> start_parse_fn_body(Ps p_) {
    return prism_rtl::make_rc<ParseFnBody>(p_);
}


/// LowerParams: fn Ps -> (([Ident], Ps))
std::tuple<Array<crate::ast::Ident>, Ps> lower_params(const Ps& p0) {
    std::tuple<Array<crate::ast::Ident>, Ps> this_ = std::tuple{Array<crate::ast::Ident>{}, p0};
    Array<crate::ast::Ident> ps = Array<crate::ast::Ident>{};
    Ps p_ = p0;
    Nat fuel = len(p0.toks);
    while (true) {
        auto&& _m = fuel.checked_sub(Nat(1u));
        if (!(prism_rtl::is_some(_m))) break;
        auto&& left = prism_rtl::some_of(_m);
        if (!is_plain_lower(kind(p_))) {
            break;
        }
        fuel = left;
        auto [i, q] = parse_ident(p_);
        ps = prelude::push(ps, i);
        p_ = q;
    }
    this_ = std::tuple{ps, p_};
    return this_;
}


/// IsPlainLower: fn TokKind -> Bool
bool is_plain_lower(const crate::lexer::TokKind& tok_kind0) {
    if (prism_rtl::is<crate::lexer::TokKind::KName>(tok_kind0)) {
        auto&& n = prism_rtl::as<crate::lexer::TokKind::KName>(tok_kind0).a0;
        return (n.case_ == crate::lexer::NameCase(crate::lexer::NameCase::CaseLower{})) && (n.sigils == Text::lit(""));
    }
    {
        return false;
    }
}


/// ParseTypeDecl: unbounded fn Ps -> ((TypeDecl, Ps))
std::tuple<crate::ast::TypeDecl, Ps> parse_type_decl(const Ps& p0) {
    auto start = here(p0);
    auto [name, p1] = parse_qual_name(adv(p0));
    auto [params, p2] = lower_params(p1);
    auto [body_opt, p3] = at_op(p2, Text::lit("="))
        ? parse_type_body(adv(p2), name, params)
        : std::tuple{std::optional<crate::ast::TypeBody>{}, p2};
    return std::tuple{crate::ast::TypeDecl{.name = name, .params = params, .body = body_opt, .span = to(start, parser::prev(p3))}, p3};
}


prism_rtl::Turn<std::tuple<crate::ast::TypeDecl, Ps>> ParseTypeDecl::cycle() const {
    const auto& p0 = this->p0;
    auto start = here(p0);
    auto [name, p1] = parse_qual_name(adv(p0));
    auto [params, p2] = lower_params(p1);
    auto [body_opt, p3] = at_op(p2, Text::lit("="))
        ? parse_type_body(adv(p2), name, params)
        : std::tuple{std::optional<crate::ast::TypeBody>{}, p2};
    return prism_rtl::finished(std::tuple{crate::ast::TypeDecl{.name = name, .params = params, .body = body_opt, .span = to(start, parser::prev(p3))}, p3});
}


/// `Start ParseTypeDecl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::ast::TypeDecl, Ps>> start_parse_type_decl(Ps p0) {
    return prism_rtl::make_rc<ParseTypeDecl>(p0);
}


/// ParseTypeBody: unbounded fn Ps, QualName, [Ident] -> ((?TypeBody, Ps))
std::tuple<std::optional<crate::ast::TypeBody>, Ps> parse_type_body(const Ps& p_, const crate::ast::QualName& name, const Array<crate::ast::Ident>& params) {
    auto&& _m = kind(p_);
    if (prism_rtl::is<crate::lexer::TokKind::KKw>(_m)) {
        auto&& m28931_0_0 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a0;
        auto&& m28931_0_1 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a1;
        if (m28931_0_0 == Text::lit("record")) {
            if (m28931_0_1 == Text::lit("")) {
                auto [fields, q] = parse_field_block(adv(p_));
                return std::tuple{std::optional(crate::ast::TypeBody(crate::ast::TypeBody::TbRecord{fields})), q};
            }
        }
    }
    if (prism_rtl::is<crate::lexer::TokKind::KKw>(_m)) {
        auto&& m28931_1_0 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a0;
        auto&& m28931_1_1 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a1;
        if (m28931_1_0 == Text::lit("choice")) {
            if (m28931_1_1 == Text::lit("")) {
                auto p1 = expect_colon(adv(p_));
                return at_open_l(p1)
                    ? ({
                    auto [cases, q] = layout_items(adv(p1), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::ast::Case_, Ps>>(Ps)>>(prism_rtl::rc([&](Ps a0) { return entered(start_parse_case(a0)); })));
                    std::tuple{std::optional(crate::ast::TypeBody(crate::ast::TypeBody::TbChoice{cases})), q};
                })
                    : std::tuple{std::optional<crate::ast::TypeBody>{}, error_here(p1, Text::lit("a choice's cases stand in an indented block after `choice:`"))};
            }
        }
    }
    if (prism_rtl::is<crate::lexer::TokKind::KKw>(_m)) {
        auto&& m28931_2_0 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a0;
        auto&& m28931_2_1 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a1;
        if (m28931_2_0 == Text::lit("row")) {
            if (m28931_2_1 == Text::lit("")) {
                return std::tuple{std::optional(crate::ast::TypeBody(crate::ast::TypeBody::TbRow{})), adv(p_)};
            }
        }
    }
    if (prism_rtl::is<crate::lexer::TokKind::KName>(_m)) {
        auto&& n = prism_rtl::as<crate::lexer::TokKind::KName>(_m).a0;
        if (((n.sigils == Text::lit("")) && (len(n->path_) == Nat(1u))) && (crate::lexer::last(n->path_) == crate::lexer::last(name->path_))) {
            auto [c, q] = parse_case(p_);
            return std::tuple{std::optional(crate::ast::TypeBody(crate::ast::TypeBody::TbNewtype{c})), q};
        }
    }
    if (prism_rtl::is<crate::lexer::TokKind::KName>(_m)) {
        auto&& n = prism_rtl::as<crate::lexer::TokKind::KName>(_m).a0;
        if (is_unit_body(p_, n, params)) {
            auto [i, q] = parse_ident(p_);
            return std::tuple{std::optional(crate::ast::TypeBody(crate::ast::TypeBody::TbUnit{i})), q};
        }
    }
    {
        auto [ty, q] = parse_type(p_);
        return std::tuple{std::optional(crate::ast::TypeBody(crate::ast::TypeBody::TbAlias{ty})), q};
    }
}


prism_rtl::Turn<std::tuple<std::optional<crate::ast::TypeBody>, Ps>> ParseTypeBody::cycle() const {
    const auto& p_ = this->p_;
    const auto& name = this->name;
    const auto& params = this->params;
    return ({
        auto&& _m = kind(p_);
        prism_rtl::is<crate::lexer::TokKind::KKw>(_m) && ({
        auto&& m28931_0_0 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a0;
        auto&& m28931_0_1 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a1;
        (m28931_0_0 == Text::lit("record")) && (m28931_0_1 == Text::lit(""));
    }) ? ({
        auto&& m28931_0_0 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a0;
        auto&& m28931_0_1 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a1;
        ({
        auto p__1 = p_;
        call_then(start_parse_field_block(adv(p__1)), [=](std::tuple<Array<crate::ast::Field>, Ps> parse_field_block_28995) {
        return ({
            auto [fields, q] = parse_field_block_28995;
            (prism_rtl::finished(std::tuple{std::optional(crate::ast::TypeBody(crate::ast::TypeBody::TbRecord{fields})), q}));
        });
    });
    });
    })
        : prism_rtl::is<crate::lexer::TokKind::KKw>(_m) && ({
        auto&& m28931_1_0 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a0;
        auto&& m28931_1_1 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a1;
        (m28931_1_0 == Text::lit("choice")) && (m28931_1_1 == Text::lit(""));
    }) ? ({
        auto&& m28931_1_0 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a0;
        auto&& m28931_1_1 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a1;
        ({
        auto p1 = expect_colon(adv(p_));
        at_open_l(p1)
        ? call_then(start_layout_items(adv(p1), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::ast::Case_, Ps>>(Ps)>>(prism_rtl::rc([&](Ps a0) { return entered(start_parse_case(a0)); }))), [=](std::tuple<Array<crate::ast::Case_>, Ps> layout_items_29167) {
        return ({
            auto [cases, q] = layout_items_29167;
            (prism_rtl::finished(std::tuple{std::optional(crate::ast::TypeBody(crate::ast::TypeBody::TbChoice{cases})), q}));
        });
    })
        : prism_rtl::finished(std::tuple{std::optional<crate::ast::TypeBody>{}, error_here(p1, Text::lit("a choice's cases stand in an indented block after `choice:`"))});
    });
    })
        : prism_rtl::is<crate::lexer::TokKind::KKw>(_m) && ({
        auto&& m28931_2_0 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a0;
        auto&& m28931_2_1 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a1;
        (m28931_2_0 == Text::lit("row")) && (m28931_2_1 == Text::lit(""));
    }) ? ({
        auto&& m28931_2_0 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a0;
        auto&& m28931_2_1 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a1;
        prism_rtl::finished(std::tuple{std::optional(crate::ast::TypeBody(crate::ast::TypeBody::TbRow{})), adv(p_)});
    })
        : prism_rtl::is<crate::lexer::TokKind::KName>(_m) && ({
        auto&& n = prism_rtl::as<crate::lexer::TokKind::KName>(_m).a0;
        (((n.sigils == Text::lit("")) && (len(n->path_) == Nat(1u))) && (crate::lexer::last(n->path_) == crate::lexer::last(name->path_)));
    }) ? ({
        auto&& n = prism_rtl::as<crate::lexer::TokKind::KName>(_m).a0;
        ({
        auto p__1 = p_;
        call_then(start_parse_case(p__1), [=](std::tuple<crate::ast::Case_, Ps> parse_case_29586) {
        return ({
            auto [c, q] = parse_case_29586;
            (prism_rtl::finished(std::tuple{std::optional(crate::ast::TypeBody(crate::ast::TypeBody::TbNewtype{c})), q}));
        });
    });
    });
    })
        : prism_rtl::is<crate::lexer::TokKind::KName>(_m) && ({
        auto&& n = prism_rtl::as<crate::lexer::TokKind::KName>(_m).a0;
        is_unit_body(p_, n, params);
    }) ? ({
        auto&& n = prism_rtl::as<crate::lexer::TokKind::KName>(_m).a0;
        ({
        auto [i, q] = parse_ident(p_);
        (prism_rtl::finished(std::tuple{std::optional(crate::ast::TypeBody(crate::ast::TypeBody::TbUnit{i})), q}));
    });
    })
        : ({
        auto p__1 = p_;
        call_then(start_parse_type(p__1), [=](std::tuple<crate::ast::Type, Ps> parse_type_29842) {
        return ({
            auto [ty, q] = parse_type_29842;
            (prism_rtl::finished(std::tuple{std::optional(crate::ast::TypeBody(crate::ast::TypeBody::TbAlias{ty})), q}));
        });
    });
    });
    });
}


/// `Start ParseTypeBody, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<std::optional<crate::ast::TypeBody>, Ps>> start_parse_type_body(Ps p_, crate::ast::QualName name, Array<crate::ast::Ident> params) {
    return prism_rtl::make_rc<ParseTypeBody>(p_, name, params);
}


/// IsUnitBody: fn Ps, NameTok, [Ident] -> Bool
bool is_unit_body(const Ps& p_, const crate::lexer::NameTok& n, const Array<crate::ast::Ident>& params) {
    auto w = or_(index(n->path_, Nat(0u)), Text::lit(""));
    auto param = fold(params, false, [&](const bool& seen, const crate::ast::Ident& i) { return seen || (i.name == w); });
    auto ends = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = kind_at(p_, Nat(1u));
        if (prism_rtl::is<crate::lexer::TokKind::KLaySep>(_m)) {
            _v.set(true);
            goto _done;
        }
        if (prism_rtl::is<crate::lexer::TokKind::KLayOpen>(_m)) {
            _v.set(true);
            goto _done;
        }
        if (prism_rtl::is<crate::lexer::TokKind::KLayClose>(_m)) {
            _v.set(true);
            goto _done;
        }
        if (prism_rtl::is<crate::lexer::TokKind::KEof>(_m)) {
            _v.set(true);
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
    return ((((n.sigils == Text::lit("")) && (n.case_ == crate::lexer::NameCase(crate::lexer::NameCase::CaseLower{}))) && (len(n->path_) == Nat(1u))) && (!param)) && ends;
}


/// ParseFieldBlock: unbounded fn Ps -> (([Field], Ps))
std::tuple<Array<crate::ast::Field>, Ps> parse_field_block(const Ps& p0) {
    auto p_ = expect_colon(p0);
    return at_open_l(p_)
        ? layout_items(adv(p_), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::ast::Field, Ps>>(Ps)>>(prism_rtl::rc([&](Ps a0) { return entered(start_parse_field(a0)); })))
        : std::tuple{Array<crate::ast::Field>{}, error_here(p_, Text::lit("fields stand in an indented block, one `name: Type` per line"))};
}


prism_rtl::Turn<std::tuple<Array<crate::ast::Field>, Ps>> ParseFieldBlock::cycle() const {
    const auto& p0 = this->p0;
    auto p_ = expect_colon(p0);
    return at_open_l(p_)
        ? prism_rtl::more(prism_rtl::rc(LayoutItems(adv(p_), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::ast::Field, Ps>>(Ps)>>(prism_rtl::rc([&](Ps a0) { return entered(start_parse_field(a0)); })))))
        : prism_rtl::finished(std::tuple{Array<crate::ast::Field>{}, error_here(p_, Text::lit("fields stand in an indented block, one `name: Type` per line"))});
}


/// `Start ParseFieldBlock, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::ast::Field>, Ps>> start_parse_field_block(Ps p0) {
    return prism_rtl::make_rc<ParseFieldBlock>(p0);
}


/// ParseField: unbounded fn Ps -> ((Field, Ps))
std::tuple<crate::ast::Field, Ps> parse_field(const Ps& p_) {
    auto start = here(p_);
    auto [name, p1] = parse_ident(p_);
    auto [ty, p2] = parse_type(expect_colon(p1));
    return std::tuple{crate::ast::Field{.name = name, .ty = ty, .span = to(start, parser::prev(p2))}, p2};
}


prism_rtl::Turn<std::tuple<crate::ast::Field, Ps>> ParseField::cycle() const {
    const auto& p_ = this->p_;
    auto start = here(p_);
    auto [name, p1] = parse_ident(p_);
    return call_then(start_parse_type(expect_colon(p1)), [=](std::tuple<crate::ast::Type, Ps> parse_type_30719) {
        return ({
            auto [ty, p2] = parse_type_30719;
            (prism_rtl::finished(std::tuple{crate::ast::Field{.name = name, .ty = ty, .span = to(start, parser::prev(p2))}, p2}));
        });
    });
}


/// `Start ParseField, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::ast::Field, Ps>> start_parse_field(Ps p_) {
    return prism_rtl::make_rc<ParseField>(p_);
}


/// ParseCase: unbounded fn Ps -> ((Case, Ps))
std::tuple<crate::ast::Case_, Ps> parse_case(const Ps& p0) {
    auto start = here(p0);
    auto [name, p1] = parse_sname(p0);
    auto p2 = name.sigils != Text::lit("")
        ? note_error(p1, name.span, Text::lit("a constructor takes no sigil"))
        : p1;
    return at_colon(p2)
        ? ({
        auto p3 = adv(p2);
        auto [args, p4] = at_op(p3, Text::lit("->"))
            ? std::tuple{Array<crate::ast::Type>{}, p3}
            : commas(p3, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::ast::Type, Ps>>(Ps)>>(prism_rtl::rc([&](Ps a0) { return entered(start_parse_emit_type(a0)); })));
        auto [result, p5] = parse_type(expect_op(p4, Text::lit("->")));
        auto p6 = out_of_scope(p5, start, Text::lit("indexed choices/GADTs for user types"), prism_rtl::cat("`", name_text(name), "` is an indexed alternative: indexed choices for user types are out of this compiler"));
        std::tuple{crate::ast::Case_{.name = name, .args = args, .indexed = std::optional(result), .span = to(start, parser::prev(p6))}, p6};
    })
        : ({
        auto [args, p3] = at_stmt_boundary(p2)
            ? std::tuple{Array<crate::ast::Type>{}, p2}
            : commas(p2, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::ast::Type, Ps>>(Ps)>>(prism_rtl::rc([&](Ps a0) { return entered(start_parse_type(a0)); })));
        std::tuple{crate::ast::Case_{.name = name, .args = args, .indexed = std::optional<crate::ast::Type>{}, .span = to(start, parser::prev(p3))}, p3};
    });
}


prism_rtl::Turn<std::tuple<crate::ast::Case_, Ps>> ParseCase::cycle() const {
    const auto& p0 = this->p0;
    auto start = here(p0);
    auto [name, p1] = parse_sname(p0);
    auto p2 = name.sigils != Text::lit("")
        ? note_error(p1, name.span, Text::lit("a constructor takes no sigil"))
        : p1;
    return at_colon(p2)
        ? ({
        auto p3 = adv(p2);
        auto [args, p4] = at_op(p3, Text::lit("->"))
            ? std::tuple{Array<crate::ast::Type>{}, p3}
            : commas(p3, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::ast::Type, Ps>>(Ps)>>(prism_rtl::rc([&](Ps a0) { return entered(start_parse_emit_type(a0)); })));
        call_then(start_parse_type(expect_op(p4, Text::lit("->"))), [=](std::tuple<crate::ast::Type, Ps> parse_type_31333) {
        return ({
            auto [result, p5] = parse_type_31333;
            auto p6 = out_of_scope(p5, start, Text::lit("indexed choices/GADTs for user types"), prism_rtl::cat("`", name_text(name), "` is an indexed alternative: indexed choices for user types are out of this compiler"));
            (prism_rtl::finished(std::tuple{crate::ast::Case_{.name = name, .args = args, .indexed = std::optional(result), .span = to(start, parser::prev(p6))}, p6}));
        });
    });
    })
        : ({
        auto [args, p3] = at_stmt_boundary(p2)
            ? std::tuple{Array<crate::ast::Type>{}, p2}
            : commas(p2, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::ast::Type, Ps>>(Ps)>>(prism_rtl::rc([&](Ps a0) { return entered(start_parse_type(a0)); })));
        (prism_rtl::finished(std::tuple{crate::ast::Case_{.name = name, .args = args, .indexed = std::optional<crate::ast::Type>{}, .span = to(start, parser::prev(p3))}, p3}));
    });
}


/// `Start ParseCase, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::ast::Case_, Ps>> start_parse_case(Ps p0) {
    return prism_rtl::make_rc<ParseCase>(p0);
}


/// ParseTagDecl: unbounded fn Ps -> ((TagDecl, Ps))
std::tuple<crate::ast::TagDecl, Ps> parse_tag_decl(const Ps& p0) {
    auto start = here(p0);
    auto [name, p1] = parse_qual_name(adv(p0));
    auto [of_type, p2] = parse_type(expect_kw(p1, Text::lit("of")));
    auto [bounds, p3] = optional_bounds(p2);
    auto [fields, p4] = at_colon(p3)
        ? parse_field_block(p3)
        : std::tuple{Array<crate::ast::Field>{}, p3};
    return std::tuple{crate::ast::TagDecl{.name = name, .of_type = of_type, .bounds = bounds, .fields = fields, .span = to(start, parser::prev(p4))}, p4};
}


prism_rtl::Turn<std::tuple<crate::ast::TagDecl, Ps>> ParseTagDecl::cycle() const {
    const auto& p0 = this->p0;
    auto start = here(p0);
    auto [name, p1] = parse_qual_name(adv(p0));
    return call_then(start_parse_type(expect_kw(p1, Text::lit("of"))), [=](std::tuple<crate::ast::Type, Ps> parse_type_32037) {
        return ({
            auto [of_type, p2] = parse_type_32037;
            call_then(start_optional_bounds(p2), [=](std::tuple<Array<crate::ast::Bound>, Ps> optional_bounds_32092) {
            return ({
                auto [bounds, p3] = optional_bounds_32092;
                auto [fields, p4] = at_colon(p3)
                    ? parse_field_block(p3)
                    : std::tuple{Array<crate::ast::Field>{}, p3};
                (prism_rtl::finished(std::tuple{crate::ast::TagDecl{.name = name, .of_type = of_type, .bounds = bounds, .fields = fields, .span = to(start, parser::prev(p4))}, p4}));
            });
        });
        });
    });
}


/// `Start ParseTagDecl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::ast::TagDecl, Ps>> start_parse_tag_decl(Ps p0) {
    return prism_rtl::make_rc<ParseTagDecl>(p0);
}


/// ParseTraitDecl: unbounded fn Ps -> ((TraitDecl, Ps))
std::tuple<crate::ast::TraitDecl, Ps> parse_trait_decl(const Ps& p0) {
    auto start = here(p0);
    auto [name, p1] = parse_trait_ref(adv(p0));
    auto [params, p2] = lower_params(p1);
    auto [bounds, p3] = optional_bounds(p2);
    auto [items, p4] = parse_trait_items(p3);
    auto decl = crate::ast::TraitDecl{.name = name, .params = params, .bounds = bounds, .items = items, .span = to(start, parser::prev(p4))};
    return std::tuple{decl, check_higher_kinded(p4, decl)};
}


prism_rtl::Turn<std::tuple<crate::ast::TraitDecl, Ps>> ParseTraitDecl::cycle() const {
    const auto& p0 = this->p0;
    auto start = here(p0);
    auto [name, p1] = parse_trait_ref(adv(p0));
    auto [params, p2] = lower_params(p1);
    return call_then(start_optional_bounds(p2), [=](std::tuple<Array<crate::ast::Bound>, Ps> optional_bounds_32550) {
        return ({
            auto [bounds, p3] = optional_bounds_32550;
            call_then(start_parse_trait_items(p3), [=](std::tuple<Array<crate::ast::TraitItem>, Ps> parse_trait_items_32592) {
            return ({
                auto [items, p4] = parse_trait_items_32592;
                auto decl = crate::ast::TraitDecl{.name = name, .params = params, .bounds = bounds, .items = items, .span = to(start, parser::prev(p4))};
                (prism_rtl::finished(std::tuple{decl, check_higher_kinded(p4, decl)}));
            });
        });
        });
    });
}


/// `Start ParseTraitDecl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::ast::TraitDecl, Ps>> start_parse_trait_decl(Ps p0) {
    return prism_rtl::make_rc<ParseTraitDecl>(p0);
}


/// ParseImplDecl: unbounded fn Ps -> ((ImplDecl, Ps))
std::tuple<crate::ast::ImplDecl, Ps> parse_impl_decl(const Ps& p0) {
    auto start = here(p0);
    auto [trait_ref, p1] = parse_trait_ref(adv(p0));
    auto [ty, p2] = parse_type(p1);
    auto [bounds, p3] = optional_bounds(p2);
    auto [items, p4] = parse_trait_items(p3);
    return std::tuple{crate::ast::ImplDecl{.trait_ref = trait_ref, .ty = ty, .bounds = bounds, .items = items, .span = to(start, parser::prev(p4))}, p4};
}


prism_rtl::Turn<std::tuple<crate::ast::ImplDecl, Ps>> ParseImplDecl::cycle() const {
    const auto& p0 = this->p0;
    auto start = here(p0);
    auto [trait_ref, p1] = parse_trait_ref(adv(p0));
    return call_then(start_parse_type(p1), [=](std::tuple<crate::ast::Type, Ps> parse_type_32978) {
        return ({
            auto [ty, p2] = parse_type_32978;
            call_then(start_optional_bounds(p2), [=](std::tuple<Array<crate::ast::Bound>, Ps> optional_bounds_33016) {
            return ({
                auto [bounds, p3] = optional_bounds_33016;
                call_then(start_parse_trait_items(p3), [=](std::tuple<Array<crate::ast::TraitItem>, Ps> parse_trait_items_33058) {
                return ({
                    auto [items, p4] = parse_trait_items_33058;
                    (prism_rtl::finished(std::tuple{crate::ast::ImplDecl{.trait_ref = trait_ref, .ty = ty, .bounds = bounds, .items = items, .span = to(start, parser::prev(p4))}, p4}));
                });
            });
            });
        });
        });
    });
}


/// `Start ParseImplDecl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::ast::ImplDecl, Ps>> start_parse_impl_decl(Ps p0) {
    return prism_rtl::make_rc<ParseImplDecl>(p0);
}


/// ParseTraitItems: unbounded fn Ps -> (([TraitItem], Ps))
std::tuple<Array<crate::ast::TraitItem>, Ps> parse_trait_items(const Ps& p0) {
    auto p_ = expect_colon(p0);
    return at_open_l(p_)
        ? ({
        auto inside = ({
            Ps this_ = adv(p_);
            this_.in_trait = true;
            this_;
        });
        auto [items, q] = layout_items(inside, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::ast::TraitItem, Ps>>(Ps)>>(prism_rtl::rc([&](Ps a0) { return entered(start_parse_trait_item(a0)); })));
        std::tuple{items, ({
        Ps this_ = q;
        this_.in_trait = p_.in_trait;
        this_;
    })};
    })
        : std::tuple{Array<crate::ast::TraitItem>{}, error_here(p_, Text::lit("a trait's or impl's items stand in an indented block"))};
}


prism_rtl::Turn<std::tuple<Array<crate::ast::TraitItem>, Ps>> ParseTraitItems::cycle() const {
    const auto& p0 = this->p0;
    auto p_ = expect_colon(p0);
    return at_open_l(p_)
        ? ({
        auto inside = ({
            Ps this_ = adv(p_);
            this_.in_trait = true;
            this_;
        });
        call_then(start_layout_items(inside, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::ast::TraitItem, Ps>>(Ps)>>(prism_rtl::rc([&](Ps a0) { return entered(start_parse_trait_item(a0)); }))), [=](std::tuple<Array<crate::ast::TraitItem>, Ps> layout_items_33400) {
        return ({
            auto [items, q] = layout_items_33400;
            (prism_rtl::finished(std::tuple{items, ({
            Ps this_ = q;
            this_.in_trait = p_.in_trait;
            this_;
        })}));
        });
    });
    })
        : prism_rtl::finished(std::tuple{Array<crate::ast::TraitItem>{}, error_here(p_, Text::lit("a trait's or impl's items stand in an indented block"))});
}


/// `Start ParseTraitItems, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::ast::TraitItem>, Ps>> start_parse_trait_items(Ps p0) {
    return prism_rtl::make_rc<ParseTraitItems>(p0);
}


/// ParseTraitItem: unbounded fn Ps -> ((TraitItem, Ps))
std::tuple<crate::ast::TraitItem, Ps> parse_trait_item(const Ps& p_) {
    auto&& _m = kind(p_);
    if (prism_rtl::is<crate::lexer::TokKind::KKw>(_m)) {
        auto&& m33668_0_0 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a0;
        if (m33668_0_0 == Text::lit("fn")) {
            auto [f, q] = parse_fn_clause(p_);
            return std::tuple{crate::ast::TraitItem(crate::ast::TraitItem::TiFn{f}), q};
        }
    }
    if (prism_rtl::is<crate::lexer::TokKind::KKw>(_m)) {
        auto&& m33668_1_0 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a0;
        if (m33668_1_0 == Text::lit("type")) {
            auto start = here(p_);
            auto p1 = adv(p_);
            auto&& _m = kind(p1);
            if (prism_rtl::is<crate::lexer::TokKind::KName>(_m)) {
                auto&& n = prism_rtl::as<crate::lexer::TokKind::KName>(_m).a0;
                if (((n.case_ == crate::lexer::NameCase(crate::lexer::NameCase::CaseUpper{})) && (n.sigils == Text::lit(""))) && (len(n->path_) == Nat(1u))) {
                    auto name = crate::ast::Ident{.name = or_(index(n->path_, Nat(0u)), Text::lit("")), .span = here(p1)};
                    auto [params, p2] = lower_params(adv(p1));
                    auto [value_opt, p3] = at_op(p2, Text::lit("="))
                        ? optional_type(adv(p2))
                        : std::tuple{std::optional<crate::ast::Type>{}, p2};
                    auto item = crate::ast::TraitItem(crate::ast::TraitItem::TiAssocType{name, params, value_opt, to(start, parser::prev(p3))});
                    return std::tuple{item, p3};
                }
            }
            {
                auto item = crate::ast::TraitItem(crate::ast::TraitItem::TiAssocType{no_ident(), Array<crate::ast::Ident>{}, std::optional<crate::ast::Type>{}, no_range()});
                return std::tuple{item, error_here(p1, Text::lit("expected the associated type's name"))};
            }
        }
    }
    if (prism_rtl::is<crate::lexer::TokKind::KKw>(_m)) {
        auto&& m33668_2_0 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a0;
        if (m33668_2_0 == Text::lit("row")) {
            auto start = here(p_);
            auto [name, q] = parse_sname(adv(p_));
            auto item = crate::ast::TraitItem(crate::ast::TraitItem::TiAssocRow{name, to(start, parser::prev(q))});
            return std::tuple{item, q};
        }
    }
    {
        auto [sig, q] = parse_signature(p_);
        return std::tuple{crate::ast::TraitItem(crate::ast::TraitItem::TiSignature{sig}), q};
    }
}


prism_rtl::Turn<std::tuple<crate::ast::TraitItem, Ps>> ParseTraitItem::cycle() const {
    const auto& p_ = this->p_;
    return ({
        auto&& _m = kind(p_);
        prism_rtl::is<crate::lexer::TokKind::KKw>(_m) && ({
        auto&& m33668_0_0 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a0;
        (m33668_0_0 == Text::lit("fn"));
    }) ? ({
        auto&& m33668_0_0 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a0;
        ({
        auto p__1 = p_;
        call_then(start_parse_fn_clause(p__1), [=](std::tuple<crate::ast::FnClause, Ps> parse_fn_clause_33727) {
        return ({
            auto [f, q] = parse_fn_clause_33727;
            (prism_rtl::finished(std::tuple{crate::ast::TraitItem(crate::ast::TraitItem::TiFn{f}), q}));
        });
    });
    });
    })
        : prism_rtl::is<crate::lexer::TokKind::KKw>(_m) && ({
        auto&& m33668_1_0 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a0;
        (m33668_1_0 == Text::lit("type"));
    }) ? ({
        auto&& m33668_1_0 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a0;
        ({
        auto start = here(p_);
        auto p1 = adv(p_);
        ({
        auto&& _m = kind(p1);
        prism_rtl::is<crate::lexer::TokKind::KName>(_m) && ({
        auto&& n = prism_rtl::as<crate::lexer::TokKind::KName>(_m).a0;
        (((n.case_ == crate::lexer::NameCase(crate::lexer::NameCase::CaseUpper{})) && (n.sigils == Text::lit(""))) && (len(n->path_) == Nat(1u)));
    }) ? ({
        auto&& n = prism_rtl::as<crate::lexer::TokKind::KName>(_m).a0;
        ({
        auto name = crate::ast::Ident{.name = or_(index(n->path_, Nat(0u)), Text::lit("")), .span = here(p1)};
        auto [params, p2] = lower_params(adv(p1));
        auto [value_opt, p3] = at_op(p2, Text::lit("="))
            ? optional_type(adv(p2))
            : std::tuple{std::optional<crate::ast::Type>{}, p2};
        auto item = crate::ast::TraitItem(crate::ast::TraitItem::TiAssocType{name, params, value_opt, to(start, parser::prev(p3))});
        (prism_rtl::finished(std::tuple{item, p3}));
    });
    })
        : ({
        auto item = crate::ast::TraitItem(crate::ast::TraitItem::TiAssocType{no_ident(), Array<crate::ast::Ident>{}, std::optional<crate::ast::Type>{}, no_range()});
        (prism_rtl::finished(std::tuple{item, error_here(p1, Text::lit("expected the associated type's name"))}));
    });
    });
    });
    })
        : prism_rtl::is<crate::lexer::TokKind::KKw>(_m) && ({
        auto&& m33668_2_0 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a0;
        (m33668_2_0 == Text::lit("row"));
    }) ? ({
        auto&& m33668_2_0 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a0;
        ({
        auto start = here(p_);
        auto [name, q] = parse_sname(adv(p_));
        auto item = crate::ast::TraitItem(crate::ast::TraitItem::TiAssocRow{name, to(start, parser::prev(q))});
        (prism_rtl::finished(std::tuple{item, q}));
    });
    })
        : ({
        auto p__1 = p_;
        call_then(start_parse_signature(p__1), [=](std::tuple<crate::ast::Signature, Ps> parse_signature_34667) {
        return ({
            auto [sig, q] = parse_signature_34667;
            (prism_rtl::finished(std::tuple{crate::ast::TraitItem(crate::ast::TraitItem::TiSignature{sig}), q}));
        });
    });
    });
    });
}


/// `Start ParseTraitItem, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::ast::TraitItem, Ps>> start_parse_trait_item(Ps p_) {
    return prism_rtl::make_rc<ParseTraitItem>(p_);
}


/// OptionalType: unbounded fn Ps -> ((?Type, Ps))
std::tuple<std::optional<crate::ast::Type>, Ps> optional_type(const Ps& p_) {
    auto [ty, q] = parse_type(p_);
    return std::tuple{std::optional(ty), q};
}


prism_rtl::Turn<std::tuple<std::optional<crate::ast::Type>, Ps>> OptionalType::cycle() const {
    const auto& p_ = this->p_;
    auto p__1 = p_;
    return call_then(start_parse_type(p__1), [=](std::tuple<crate::ast::Type, Ps> parse_type_34802) {
        return ({
            auto [ty, q] = parse_type_34802;
            (prism_rtl::finished(std::tuple{std::optional(ty), q}));
        });
    });
}


/// `Start OptionalType, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<std::optional<crate::ast::Type>, Ps>> start_optional_type(Ps p_) {
    return prism_rtl::make_rc<OptionalType>(p_);
}


/// CheckHigherKinded: fn Ps, TraitDecl -> Ps
Ps check_higher_kinded(const Ps& p_, const crate::ast::TraitDecl& t) {
    auto hk = fold(t.items, false, [&](const bool& seen, const crate::ast::TraitItem& item) { return seen || item_applies(item, t.params); });
    return hk && (t.name->path_ != Array(std::vector{Text::lit("Monad")}))
        ? out_of_scope(p_, t.name.span, Text::lit("higher-kinded traits"), prism_rtl::cat("`^", crate::lexer::join(t.name->path_, Text::lit(".")), "` applies its parameter to arguments: higher-kinded traits are out of this compiler"))
        : p_;
}


/// ItemApplies: fn TraitItem, [Ident] -> Bool
bool item_applies(const crate::ast::TraitItem& trait_item0, const Array<crate::ast::Ident>& xs1) {
    auto&& _m = std::tuple{trait_item0, xs1};
    if (prism_rtl::is<crate::ast::TraitItem::TiSignature>(std::get<0>(_m))) {
        auto&& s = prism_rtl::as<crate::ast::TraitItem::TiSignature>(std::get<0>(_m)).a0;
        auto&& params = std::get<1>(_m);
        return applies(s.ty, params);
    }
    {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// AnyApplies: fn [Type], [Ident] -> Bool
bool any_applies(const Array<crate::ast::Type>& ts, const Array<crate::ast::Ident>& params) {
    return fold(ts, false, [&](const bool& seen, const crate::ast::Type& t) { return seen || applies(t, params); });
}


/// Applies: fn Type, [Ident] -> Bool
bool applies(const crate::ast::Type& ty, const Array<crate::ast::Ident>& params) {
    auto&& _m = ty.kind;
    if (prism_rtl::is<crate::ast::TypeKind::TName>(_m)) {
        auto&& name = prism_rtl::as<crate::ast::TypeKind::TName>(_m).a0;
        auto&& args = prism_rtl::as<crate::ast::TypeKind::TName>(_m).a1;
        auto head = ((len(args) > Nat(0u)) && (len(name->path_) == Nat(1u))) && fold(params, false, [&](const bool& seen, const crate::ast::Ident& i) { return seen || (i.name == or_(index(name->path_, Nat(0u)), Text::lit(""))); });
        return head || any_applies(args, params);
    }
    if (prism_rtl::is<crate::ast::TypeKind::TSigiled>(_m)) {
        auto&& inner = prism_rtl::as<crate::ast::TypeKind::TSigiled>(_m).a1;
        return applies(inner, params);
    }
    if (prism_rtl::is<crate::ast::TypeKind::TGroup>(_m)) {
        auto&& inner = prism_rtl::as<crate::ast::TypeKind::TGroup>(_m).a0;
        return applies(inner, params);
    }
    if (prism_rtl::is<crate::ast::TypeKind::TNonEmpty>(_m)) {
        auto&& inner = prism_rtl::as<crate::ast::TypeKind::TNonEmpty>(_m).a0;
        return applies(inner, params);
    }
    if (prism_rtl::is<crate::ast::TypeKind::TArray>(_m)) {
        auto&& elem = prism_rtl::as<crate::ast::TypeKind::TArray>(_m).a0;
        return applies(elem, params);
    }
    if (prism_rtl::is<crate::ast::TypeKind::TTuple>(_m)) {
        auto&& ts = prism_rtl::as<crate::ast::TypeKind::TTuple>(_m).a0;
        return any_applies(ts, params);
    }
    if (prism_rtl::is<crate::ast::TypeKind::TRowUnion>(_m)) {
        auto&& ts = prism_rtl::as<crate::ast::TypeKind::TRowUnion>(_m).a0;
        return any_applies(ts, params);
    }
    if (prism_rtl::is<crate::ast::TypeKind::TMap>(_m)) {
        auto&& k = prism_rtl::as<crate::ast::TypeKind::TMap>(_m).a0;
        auto&& v_ = prism_rtl::as<crate::ast::TypeKind::TMap>(_m).a1;
        return applies(k, params) || applies(v_, params);
    }
    if (prism_rtl::is<crate::ast::TypeKind::TFn>(_m)) {
        auto&& ps = prism_rtl::as<crate::ast::TypeKind::TFn>(_m).a1;
        auto&& result = prism_rtl::as<crate::ast::TypeKind::TFn>(_m).a2;
        return any_applies(ps, params) || applies(result, params);
    }
    if (prism_rtl::is<crate::ast::TypeKind::TEmit>(_m)) {
        auto&& t = prism_rtl::as<crate::ast::TypeKind::TEmit>(_m).a0;
        auto&& r = prism_rtl::as<crate::ast::TypeKind::TEmit>(_m).a1;
        return applies(t, params) || applies(r, params);
    }
    {
        return false;
    }
}


/// ParseExpr: unbounded fn Ps -> ((Expr, Ps))
std::tuple<crate::ast::Expr, Ps> parse_expr(const Ps& p_) {
    return parse_expr_ctx(p_, true);
}


prism_rtl::Turn<std::tuple<crate::ast::Expr, Ps>> ParseExpr::cycle() const {
    const auto& p_ = this->p_;
    return prism_rtl::more(prism_rtl::rc(ParseExprCtx(p_, true)));
}


/// `Start ParseExpr, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::ast::Expr, Ps>> start_parse_expr(Ps p_) {
    return prism_rtl::make_rc<ParseExpr>(p_);
}


/// ParseArgExpr: unbounded fn Ps -> ((Expr, Ps))
std::tuple<crate::ast::Expr, Ps> parse_arg_expr(const Ps& p_) {
    return parse_expr_ctx(p_, false);
}


prism_rtl::Turn<std::tuple<crate::ast::Expr, Ps>> ParseArgExpr::cycle() const {
    const auto& p_ = this->p_;
    return prism_rtl::more(prism_rtl::rc(ParseExprCtx(p_, false)));
}


/// `Start ParseArgExpr, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::ast::Expr, Ps>> start_parse_arg_expr(Ps p_) {
    return prism_rtl::make_rc<ParseArgExpr>(p_);
}


/// ParseExprCtx: unbounded fn Ps, Bool -> ((Expr, Ps))
std::tuple<crate::ast::Expr, Ps> parse_expr_ctx(const Ps& p_, const bool& commas_) {
    return parse_binary(p_, Nat(4u), commas_ && (!p_.step_mode));
}


prism_rtl::Turn<std::tuple<crate::ast::Expr, Ps>> ParseExprCtx::cycle() const {
    const auto& p_ = this->p_;
    const auto& commas_ = this->commas_;
    return prism_rtl::more(prism_rtl::rc(ParseBinary(p_, Nat(4u), commas_ && (!p_.step_mode))));
}


/// `Start ParseExprCtx, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::ast::Expr, Ps>> start_parse_expr_ctx(Ps p_, bool commas_) {
    return prism_rtl::make_rc<ParseExprCtx>(p_, commas_);
}


/// ParseRhsExpr: unbounded fn Ps -> ((Expr, Ps))
std::tuple<crate::ast::Expr, Ps> parse_rhs_expr(const Ps& p0) {
    std::tuple<crate::ast::Expr, Ps> this_ = parse_expr(p0);
    auto [e0, p1] = this_;
    crate::ast::Expr e = e0;
    Ps p_ = p1;
    while (at_line_method(p_)) {
        auto [method, p2] = parse_sname(adv(p_));
        auto [args, p3] = arg_starts_here(p2)
            ? parse_call_args(p2, true)
            : std::tuple{Array<crate::ast::Arg>{}, p2};
        e = crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::EMethod{prism_rtl::rc(e), method, args})), .span = to(e.span, parser::prev(p3))};
        p_ = p3;
    }
    this_ = std::tuple{e, p_};
    return this_;
}


prism_rtl::Turn<std::tuple<crate::ast::Expr, Ps>> ParseRhsExpr::cycle() const {
    const auto& p0 = this->p0;
    std::tuple<crate::ast::Expr, Ps> this_ = parse_expr(p0);
    auto [e0, p1] = this_;
    crate::ast::Expr e = e0;
    Ps p_ = p1;
    return call_then(loop_job(std::tuple{this_, e, p_}, [=](std::tuple<std::tuple<crate::ast::Expr, Ps>, crate::ast::Expr, Ps> _p0) {
        auto this_ = std::get<0>(_p0);
        auto e = std::get<1>(_p0);
        auto p_ = std::get<2>(_p0);
        return at_line_method(p_)
            ? ({
            auto [method, p2] = parse_sname(adv(p_));
            auto [args, p3] = arg_starts_here(p2)
                ? parse_call_args(p2, true)
                : std::tuple{Array<crate::ast::Arg>{}, p2};
            e = crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::EMethod{prism_rtl::rc(e), method, args})), .span = to(e.span, parser::prev(p3))};
            p_ = p3;
            Expected<std::tuple<std::tuple<crate::ast::Expr, Ps>, crate::ast::Expr, Ps>, std::tuple<std::tuple<crate::ast::Expr, Ps>, crate::ast::Expr, Ps>>(std::tuple{this_, e, p_});
        })
            : Expected<std::tuple<std::tuple<crate::ast::Expr, Ps>, crate::ast::Expr, Ps>, std::tuple<std::tuple<crate::ast::Expr, Ps>, crate::ast::Expr, Ps>>(unexpected(std::tuple{this_, e, p_}));
    }), [=](std::tuple<std::tuple<crate::ast::Expr, Ps>, crate::ast::Expr, Ps> _p0) {
        auto this_ = std::get<0>(_p0);
        auto e = std::get<1>(_p0);
        auto p_ = std::get<2>(_p0);
        return ({
            this_ = std::tuple{e, p_};
            (prism_rtl::finished(this_));
        });
    });
}


/// `Start ParseRhsExpr, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::ast::Expr, Ps>> start_parse_rhs_expr(Ps p0) {
    return prism_rtl::make_rc<ParseRhsExpr>(p0);
}


/// AtLineMethod: fn Ps -> Bool
bool at_line_method(const Ps& p_) {
    return ((kind(p_) == crate::lexer::TokKind(crate::lexer::TokKind::KDot{true})) && tk(p_).line_start) && is_plain_upper(kind_at(p_, Nat(1u)));
}


/// IsPlainUpper: fn TokKind -> Bool
bool is_plain_upper(const crate::lexer::TokKind& tok_kind0) {
    if (prism_rtl::is<crate::lexer::TokKind::KName>(tok_kind0)) {
        auto&& n = prism_rtl::as<crate::lexer::TokKind::KName>(tok_kind0).a0;
        return (n.case_ == crate::lexer::NameCase(crate::lexer::NameCase::CaseUpper{})) && (n.sigils == Text::lit(""));
    }
    {
        return false;
    }
}


/// IsUpperTok: fn TokKind -> Bool
bool is_upper_tok(const crate::lexer::TokKind& tok_kind0) {
    if (prism_rtl::is<crate::lexer::TokKind::KName>(tok_kind0)) {
        auto&& n = prism_rtl::as<crate::lexer::TokKind::KName>(tok_kind0).a0;
        return n.case_ == crate::lexer::NameCase(crate::lexer::NameCase::CaseUpper{});
    }
    {
        return false;
    }
}


/// ?PeekBinop: fn Ps -> ?((Text, ?[Text]))
std::optional<std::tuple<Text, std::optional<Array<Text>>>> peek_binop(const Ps& p_) {
    auto&& _m = kind(p_);
    if (prism_rtl::is<crate::lexer::TokKind::KOp>(_m)) {
        auto&& op = prism_rtl::as<crate::lexer::TokKind::KOp>(_m).a0;
        auto&& prefix = prism_rtl::as<crate::lexer::TokKind::KOp>(_m).a1;
        if ((!prefix) || (op == Text::lit("-?"))) {
            return is_binop(op)
                ? std::optional(std::tuple{op, std::optional<Array<Text>>{}})
                : std::optional<std::tuple<Text, std::optional<Array<Text>>>>{};
        }
    }
    if (prism_rtl::is<crate::lexer::TokKind::KSuffixed>(_m)) {
        auto&& op = prism_rtl::as<crate::lexer::TokKind::KSuffixed>(_m).a0;
        auto&& ty = prism_rtl::as<crate::lexer::TokKind::KSuffixed>(_m).a1;
        return is_binop(op)
            ? std::optional(std::tuple{op, std::optional(ty)})
            : std::optional<std::tuple<Text, std::optional<Array<Text>>>>{};
    }
    if (prism_rtl::is<crate::lexer::TokKind::KKw>(_m)) {
        auto&& m38658_2_0 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a0;
        auto&& m38658_2_1 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a1;
        if (m38658_2_0 == Text::lit("on")) {
            if (m38658_2_1 == Text::lit("")) {
                return std::optional(std::tuple{Text::lit("on"), std::optional<Array<Text>>{}});
            }
        }
    }
    if (prism_rtl::is<crate::lexer::TokKind::KKw>(_m)) {
        auto&& m38658_3_0 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a0;
        auto&& m38658_3_1 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a1;
        if (m38658_3_0 == Text::lit("or")) {
            if (m38658_3_1 == Text::lit("")) {
                return std::optional(std::tuple{Text::lit("or"), std::optional<Array<Text>>{}});
            }
        }
    }
    if (prism_rtl::is<crate::lexer::TokKind::KKw>(_m)) {
        auto&& m38658_4_0 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a0;
        auto&& m38658_4_1 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a1;
        if (m38658_4_0 == Text::lit("and")) {
            if (m38658_4_1 == Text::lit("")) {
                return std::optional(std::tuple{Text::lit("and"), std::optional<Array<Text>>{}});
            }
        }
    }
    if (prism_rtl::is<crate::lexer::TokKind::KKw>(_m)) {
        auto&& m38658_5_0 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a0;
        auto&& m38658_5_1 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a1;
        if (m38658_5_0 == Text::lit("mod")) {
            if (m38658_5_1 == Text::lit("")) {
                return std::optional(std::tuple{Text::lit("mod"), std::optional<Array<Text>>{}});
            }
        }
    }
    {
        return std::optional<std::tuple<Text, std::optional<Array<Text>>>>{};
    }
}


/// IsBinop: fn Text -> Bool
bool is_binop(const Text& op) {
    return fold(Array(std::vector{Text::lit("<|"), Text::lit("=="), Text::lit("!="), Text::lit("<"), Text::lit("<="), Text::lit(">"), Text::lit(">="), Text::lit("+"), Text::lit("-"), Text::lit("+?"), Text::lit("-?"), Text::lit("*"), Text::lit("/"), Text::lit("*?")}), false, [&](const bool& seen, const Text& o) { return seen || (o == op); });
}


/// Level: fn Text -> Nat
Nat level(const Text& text0) {
    {
        auto&& c0_0 = text0;
        if (c0_0 == Text::lit("<|")) {
            return Nat(4u);
        }
    }
    {
        auto&& c1_0 = text0;
        if (c1_0 == Text::lit("on")) {
            return Nat(5u);
        }
    }
    {
        auto&& c2_0 = text0;
        if (c2_0 == Text::lit("or")) {
            return Nat(6u);
        }
    }
    {
        auto&& c3_0 = text0;
        if (c3_0 == Text::lit("and")) {
            return Nat(7u);
        }
    }
    {
        auto&& c4_0 = text0;
        if (c4_0 == Text::lit("+")) {
            return Nat(10u);
        }
    }
    {
        auto&& c5_0 = text0;
        if (c5_0 == Text::lit("-")) {
            return Nat(10u);
        }
    }
    {
        auto&& c6_0 = text0;
        if (c6_0 == Text::lit("+?")) {
            return Nat(10u);
        }
    }
    {
        auto&& c7_0 = text0;
        if (c7_0 == Text::lit("-?")) {
            return Nat(10u);
        }
    }
    {
        auto&& c8_0 = text0;
        if (c8_0 == Text::lit("*")) {
            return Nat(11u);
        }
    }
    {
        auto&& c9_0 = text0;
        if (c9_0 == Text::lit("/")) {
            return Nat(11u);
        }
    }
    {
        auto&& c10_0 = text0;
        if (c10_0 == Text::lit("*?")) {
            return Nat(11u);
        }
    }
    {
        auto&& c11_0 = text0;
        if (c11_0 == Text::lit("mod")) {
            return Nat(11u);
        }
    }
    {
        return Nat(9u);
    }
}


/// ParseBinary: unbounded fn Ps, Nat, Bool -> ((Expr, Ps))
std::tuple<crate::ast::Expr, Ps> parse_binary(const Ps& p0, const Nat& min_, const bool& commas_) {
    auto [lhs, p1] = parse_prefix(p0, min_, commas_);
    auto r = ({
        Climb this_ = Climb{.lhs = lhs, .p_ = p1, .going = true};
        while (this_.going && (!this_.p_->bad)) {
            this_ = climb_step(this_, min_, commas_);
        }
        this_;
    });
    return std::tuple{r.lhs, r.p_};
}


prism_rtl::Turn<std::tuple<crate::ast::Expr, Ps>> ParseBinary::cycle() const {
    const auto& p0 = this->p0;
    const auto& min_ = this->min_;
    const auto& commas_ = this->commas_;
    auto commas__1 = commas_;
    auto min__2 = min_;
    auto p0_3 = p0;
    return call_then(start_parse_prefix(p0_3, min__2, commas__1), [=](std::tuple<crate::ast::Expr, Ps> parse_prefix_39926) {
        return ({
            auto [lhs, p1] = parse_prefix_39926;
            Climb this_ = Climb{.lhs = lhs, .p_ = p1, .going = true};
            auto lhs_4 = lhs;
            call_then(loop_job(std::tuple{this_}, ({
            auto commas__1_5 = commas__1;
            auto min__2_5 = min__2;
            [=](std::tuple<Climb> _p0) {
            auto this_ = std::get<0>(_p0);
            return this_.going && (!this_.p_->bad)
                ? ({
                this_ = climb_step(this_, min__2_5, commas__1_5);
                Expected<std::tuple<Climb>, std::tuple<Climb>>(std::tuple{this_});
            })
                : Expected<std::tuple<Climb>, std::tuple<Climb>>(unexpected(std::tuple{this_}));
        };
        })), [=](std::tuple<Climb> _p0) {
            auto this_ = std::get<0>(_p0);
            return ({
                auto r = this_;
                (prism_rtl::finished(std::tuple{r.lhs, r.p_}));
            });
        });
        });
    });
}


/// `Start ParseBinary, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::ast::Expr, Ps>> start_parse_binary(Ps p0, Nat min_, bool commas_) {
    return prism_rtl::make_rc<ParseBinary>(p0, min_, commas_);
}


/// ClimbStep: unbounded fn Climb, Nat, Bool -> Climb
Climb climb_step(const Climb& c, const Nat& min_, const bool& commas_) {
    auto p_ = c.p_;
    return at_kw(p_, Text::lit("as")) && (min_ <= Nat(12u))
        ? ({
        auto [ty, p2] = parse_type(adv(p_));
        auto checked = (kind(p2) == crate::lexer::TokKind(crate::lexer::TokKind::KFree{Text::lit("?")})) && tk(p2).touches;
        auto p3 = checked ? adv(p2) : p2;
        ({
        Climb this_ = c;
        this_.lhs = crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::ECast{prism_rtl::rc(this_.lhs), ty, checked})), .span = to(this_.lhs.span, parser::prev(p3))};
        this_.p_ = p3;
        this_;
    });
    })
        : ({
        __label__ _done;
        prism_rtl::Slot<Climb> _v;
        auto&& _m = peek_binop(p_);
        if (prism_rtl::is_none(_m)) {
            _v.set(({
                Climb this_ = c;
                this_.going = false;
                this_.p_ = no_operator(p_);
                this_;
            }));
            goto _done;
        }
        if (prism_rtl::is_some(_m)) {
            auto&& op = std::get<0>(prism_rtl::some_of(_m));
            auto&& suffix_opt = std::get<1>(prism_rtl::some_of(_m));
            _v.set(level(op) < min_
                ? ({
                Climb this_ = c;
                this_.going = false;
                this_;
            })
                : ({
                auto p1 = kind(p_) == crate::lexer::TokKind(crate::lexer::TokKind::KOp{Text::lit("-?"), true})
                    ? note_error(p_, here(p_), Text::lit("`-?` is the checked subtraction by longest match; to subtract or negate an optional, write `-(?x)`"))
                    : p_;
                auto op_tok = tk(p1);
                auto [rhs, p2] = parse_binary(adv(p1), level(op) + Nat(1u), commas_);
                auto span = to(c.lhs.span, rhs.span);
                auto kind_ = ({
                    __label__ _done;
                    prism_rtl::Slot<crate::ast::ExprKind> _v;
                    if (prism_rtl::is_none(suffix_opt)) {
                        _v.set(crate::ast::ExprKind(crate::ast::ExprKind::EBinary{op, prism_rtl::rc(c.lhs), prism_rtl::rc(rhs)}));
                        goto _done;
                    }
                    if (prism_rtl::is_some(suffix_opt)) {
                        auto&& ty = prism_rtl::some_of(suffix_opt);
                        _v.set(crate::ast::ExprKind(crate::ast::ExprKind::ESuffixed{op, crate::ast::QualName{.path_ = ty, .span = op_tok.span}, prism_rtl::rc(c.lhs), prism_rtl::rc(rhs)}));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                auto p3 = suffix_opt == std::optional<Array<Text>>{}
                    ? p2
                    : out_of_scope(p2, op_tok.span, Text::lit("suffixed operators"), prism_rtl::cat("the suffixed operator `", crate::lexer::token_text(op_tok.kind), "` is out of this compiler"));
                ({
                Climb this_ = c;
                this_.lhs = crate::ast::Expr{.kind = prism_rtl::rc(kind_), .span = span};
                this_.p_ = p3;
                this_;
            });
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Climb> ClimbStep::cycle() const {
    const auto& c = this->c;
    const auto& min_ = this->min_;
    const auto& commas_ = this->commas_;
    auto p_ = c.p_;
    return at_kw(p_, Text::lit("as")) && (min_ <= Nat(12u))
        ? ({
        auto c_1 = c;
        call_then(start_parse_type(adv(p_)), [=](std::tuple<crate::ast::Type, Ps> parse_type_40322) {
        return ({
            auto [ty, p2] = parse_type_40322;
            auto checked = (kind(p2) == crate::lexer::TokKind(crate::lexer::TokKind::KFree{Text::lit("?")})) && tk(p2).touches;
            auto p3 = checked ? adv(p2) : p2;
            (prism_rtl::finished(({
            Climb this_ = c_1;
            this_.lhs = crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::ECast{prism_rtl::rc(this_.lhs), ty, checked})), .span = to(this_.lhs.span, parser::prev(p3))};
            this_.p_ = p3;
            this_;
        })));
        });
    });
    })
        : ({
        auto&& _m = peek_binop(p_);
        prism_rtl::is_none(_m) ? prism_rtl::finished(({
        Climb this_ = c;
        this_.going = false;
        this_.p_ = no_operator(p_);
        this_;
    }))
        : prism_rtl::is_some(_m) ? ({
        auto&& op = std::get<0>(prism_rtl::some_of(_m));
        auto&& suffix_opt = std::get<1>(prism_rtl::some_of(_m));
        level(op) < min_
        ? prism_rtl::finished(({
        Climb this_ = c;
        this_.going = false;
        this_;
    }))
        : ({
        auto p1 = kind(p_) == crate::lexer::TokKind(crate::lexer::TokKind::KOp{Text::lit("-?"), true})
            ? note_error(p_, here(p_), Text::lit("`-?` is the checked subtraction by longest match; to subtract or negate an optional, write `-(?x)`"))
            : p_;
        auto op_tok = tk(p1);
        auto c_1 = c;
        auto commas__2 = commas_;
        call_then(start_parse_binary(adv(p1), level(op) + Nat(1u), commas__2), [=](std::tuple<crate::ast::Expr, Ps> parse_binary_41234) {
        return ({
            auto [rhs, p2] = parse_binary_41234;
            auto span = to(c_1.lhs.span, rhs.span);
            auto kind_ = ({
                __label__ _done;
                prism_rtl::Slot<crate::ast::ExprKind> _v;
                if (prism_rtl::is_none(suffix_opt)) {
                    _v.set(crate::ast::ExprKind(crate::ast::ExprKind::EBinary{op, prism_rtl::rc(c_1.lhs), prism_rtl::rc(rhs)}));
                    goto _done;
                }
                if (prism_rtl::is_some(suffix_opt)) {
                    auto&& ty = prism_rtl::some_of(suffix_opt);
                    _v.set(crate::ast::ExprKind(crate::ast::ExprKind::ESuffixed{op, crate::ast::QualName{.path_ = ty, .span = op_tok.span}, prism_rtl::rc(c_1.lhs), prism_rtl::rc(rhs)}));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            auto p3 = suffix_opt == std::optional<Array<Text>>{}
                ? p2
                : out_of_scope(p2, op_tok.span, Text::lit("suffixed operators"), prism_rtl::cat("the suffixed operator `", crate::lexer::token_text(op_tok.kind), "` is out of this compiler"));
            (prism_rtl::finished(({
            Climb this_ = c_1;
            this_.lhs = crate::ast::Expr{.kind = prism_rtl::rc(kind_), .span = span};
            this_.p_ = p3;
            this_;
        })));
        });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ClimbStep, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Climb> start_climb_step(Climb c, Nat min_, bool commas_) {
    return prism_rtl::make_rc<ClimbStep>(c, min_, commas_);
}


/// NoOperator: fn Ps -> Ps
Ps no_operator(const Ps& p_) {
    auto&& _m = kind(p_);
    if (prism_rtl::is<crate::lexer::TokKind::KOp>(_m) && prism_rtl::as<crate::lexer::TokKind::KOp>(_m).a1) {
        auto&& o = prism_rtl::as<crate::lexer::TokKind::KOp>(_m).a0;
        if (((o == Text::lit("-")) || (o == Text::lit("+"))) && (!tk(p_).line_start)) {
            return error_at(p_, here(p_), prism_rtl::cat("`", o, "` here is a prefix sign by the spacing rule (a space before it and none after); did you mean `a ", o, " 1`, with spaces on both sides?"));
        }
    }
    if (prism_rtl::is<crate::lexer::TokKind::KBar>(_m)) {
        return error_at(p_, here(p_), Text::lit("a bare `|` is not an operator: the merge is `<|`, and `|` separates the families of a row"));
    }
    if (prism_rtl::is<crate::lexer::TokKind::KDot>(_m) && prism_rtl::as<crate::lexer::TokKind::KDot>(_m).a0) {
        if ((!at_line_method(p_)) && is_upper_tok(kind_at(p_, Nat(1u)))) {
            return error_at(p_, here(p_), Text::lit("a spaced `.Method` begins its own line, below the call it takes as its receiver (layout rule 9)"));
        }
    }
    {
        return p_;
    }
}


/// ParsePrefix: unbounded fn Ps, Nat, Bool -> ((Expr, Ps))
std::tuple<crate::ast::Expr, Ps> parse_prefix(const Ps& p_, const Nat& min_, const bool& commas_) {
    auto start = here(p_);
    return at_kw(p_, Text::lit("not"))
        ? ({
        auto [operand, q] = parse_binary(adv(p_), prelude::max(Nat(9u), min_), commas_);
        std::tuple{crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::EUnary{Text::lit("not"), prism_rtl::rc(operand)})), .span = to(start, operand.span)}, q};
    })
        : ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::ast::Expr, Ps>> _v;
        auto&& _m = kind(p_);
        if (prism_rtl::is<crate::lexer::TokKind::KOp>(_m) && prism_rtl::as<crate::lexer::TokKind::KOp>(_m).a1) {
            auto&& op = prism_rtl::as<crate::lexer::TokKind::KOp>(_m).a0;
            if ((op == Text::lit("-")) || (op == Text::lit("+"))) {
                _v.set(({
                    auto [operand, q] = parse_postfix_expr(adv(p_), commas_);
                    auto name = op == Text::lit("-") ? Text::lit("neg") : Text::lit("pos");
                    std::tuple{crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::EUnary{name, prism_rtl::rc(operand)})), .span = to(start, operand.span)}, q};
                }));
                goto _done;
            }
        }
        if (prism_rtl::is<crate::lexer::TokKind::KOp>(_m)) {
            auto&& m43027_1_0 = prism_rtl::as<crate::lexer::TokKind::KOp>(_m).a0;
            if (m43027_1_0 == Text::lit("-?")) {
                _v.set(std::tuple{no_expr(), error_at(p_, here(p_), Text::lit("`-?` is the checked subtraction and needs a left operand; to negate an optional write `-(?x)`"))});
                goto _done;
            }
        }
        {
            _v.set(parse_postfix_expr(p_, commas_));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::tuple<crate::ast::Expr, Ps>> ParsePrefix::cycle() const {
    const auto& p_ = this->p_;
    const auto& min_ = this->min_;
    const auto& commas_ = this->commas_;
    auto start = here(p_);
    return at_kw(p_, Text::lit("not"))
        ? ({
        auto commas__1 = commas_;
        auto min__2 = min_;
        auto p__3 = p_;
        call_then(start_parse_binary(adv(p__3), prelude::max(Nat(9u), min__2), commas__1), [=](std::tuple<crate::ast::Expr, Ps> parse_binary_42894) {
        return ({
            auto [operand, q] = parse_binary_42894;
            (prism_rtl::finished(std::tuple{crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::EUnary{Text::lit("not"), prism_rtl::rc(operand)})), .span = to(start, operand.span)}, q}));
        });
    });
    })
        : ({
        auto&& _m = kind(p_);
        prism_rtl::is<crate::lexer::TokKind::KOp>(_m) && prism_rtl::as<crate::lexer::TokKind::KOp>(_m).a1 && ({
        auto&& op = prism_rtl::as<crate::lexer::TokKind::KOp>(_m).a0;
        ((op == Text::lit("-")) || (op == Text::lit("+")));
    }) ? ({
        auto&& op = prism_rtl::as<crate::lexer::TokKind::KOp>(_m).a0;
        ({
        auto commas__1 = commas_;
        auto p__2 = p_;
        call_then(start_parse_postfix_expr(adv(p__2), commas__1), [=](std::tuple<crate::ast::Expr, Ps> parse_postfix_expr_43122) {
        return ({
            auto [operand, q] = parse_postfix_expr_43122;
            auto name = op == Text::lit("-") ? Text::lit("neg") : Text::lit("pos");
            (prism_rtl::finished(std::tuple{crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::EUnary{name, prism_rtl::rc(operand)})), .span = to(start, operand.span)}, q}));
        });
    });
    });
    })
        : prism_rtl::is<crate::lexer::TokKind::KOp>(_m) && ({
        auto&& m43027_1_0 = prism_rtl::as<crate::lexer::TokKind::KOp>(_m).a0;
        (m43027_1_0 == Text::lit("-?"));
    }) ? ({
        auto&& m43027_1_0 = prism_rtl::as<crate::lexer::TokKind::KOp>(_m).a0;
        prism_rtl::finished(std::tuple{no_expr(), error_at(p_, here(p_), Text::lit("`-?` is the checked subtraction and needs a left operand; to negate an optional write `-(?x)`"))});
    })
        : prism_rtl::more(prism_rtl::rc(ParsePostfixExpr(p_, commas_)));
    });
}


/// `Start ParsePrefix, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::ast::Expr, Ps>> start_parse_prefix(Ps p_, Nat min_, bool commas_) {
    return prism_rtl::make_rc<ParsePrefix>(p_, min_, commas_);
}


/// ParsePostfixExpr: unbounded fn Ps, Bool -> ((Expr, Ps))
std::tuple<crate::ast::Expr, Ps> parse_postfix_expr(const Ps& p_, const bool& commas_) {
    auto [e, took_rest, q] = parse_primary(p_, commas_);
    return took_rest ? std::tuple{e, q} : parse_postfix(e, q, commas_);
}


prism_rtl::Turn<std::tuple<crate::ast::Expr, Ps>> ParsePostfixExpr::cycle() const {
    const auto& p_ = this->p_;
    const auto& commas_ = this->commas_;
    auto commas__1 = commas_;
    auto p__2 = p_;
    return call_then(start_parse_primary(p__2, commas__1), [=](std::tuple<crate::ast::Expr, bool, Ps> parse_primary_43729) {
        return ({
            auto [e, took_rest, q] = parse_primary_43729;
            took_rest
            ? prism_rtl::finished(std::tuple{e, q})
            : prism_rtl::more(prism_rtl::rc(ParsePostfix(e, q, commas__1)));
        });
    });
}


/// `Start ParsePostfixExpr, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::ast::Expr, Ps>> start_parse_postfix_expr(Ps p_, bool commas_) {
    return prism_rtl::make_rc<ParsePostfixExpr>(p_, commas_);
}


/// ParsePostfix: unbounded fn Expr, Ps, Bool -> ((Expr, Ps))
std::tuple<crate::ast::Expr, Ps> parse_postfix(const crate::ast::Expr& e0, const Ps& p0, const bool& commas_) {
    std::tuple<crate::ast::Expr, Ps> this_ = std::tuple{e0, p0};
    crate::ast::Expr e = e0;
    Ps p_ = p0;
    bool going = true;
    while (going && (!p_.bad)) {
        auto [e2, p2, more] = postfix_step(e, p_, commas_);
        e = e2;
        p_ = p2;
        going = more;
    }
    this_ = std::tuple{e, p_};
    return this_;
}


prism_rtl::Turn<std::tuple<crate::ast::Expr, Ps>> ParsePostfix::cycle() const {
    const auto& e0 = this->e0;
    const auto& p0 = this->p0;
    const auto& commas_ = this->commas_;
    std::tuple<crate::ast::Expr, Ps> this_ = std::tuple{e0, p0};
    crate::ast::Expr e = e0;
    Ps p_ = p0;
    bool going = true;
    return call_then(loop_job(std::tuple{this_, e, going, p_}, ({
        auto commas__1 = commas_;
        [=](std::tuple<std::tuple<crate::ast::Expr, Ps>, crate::ast::Expr, bool, Ps> _p0) {
        auto this_ = std::get<0>(_p0);
        auto e = std::get<1>(_p0);
        auto going = std::get<2>(_p0);
        auto p_ = std::get<3>(_p0);
        return going && (!p_->bad)
            ? ({
            auto [e2, p2, more] = postfix_step(e, p_, commas__1);
            e = e2;
            p_ = p2;
            going = more;
            Expected<std::tuple<std::tuple<crate::ast::Expr, Ps>, crate::ast::Expr, bool, Ps>, std::tuple<std::tuple<crate::ast::Expr, Ps>, crate::ast::Expr, bool, Ps>>(std::tuple{this_, e, going, p_});
        })
            : Expected<std::tuple<std::tuple<crate::ast::Expr, Ps>, crate::ast::Expr, bool, Ps>, std::tuple<std::tuple<crate::ast::Expr, Ps>, crate::ast::Expr, bool, Ps>>(unexpected(std::tuple{this_, e, going, p_}));
    };
    })), [=](std::tuple<std::tuple<crate::ast::Expr, Ps>, crate::ast::Expr, bool, Ps> _p0) {
        auto this_ = std::get<0>(_p0);
        auto e = std::get<1>(_p0);
        auto going = std::get<2>(_p0);
        auto p_ = std::get<3>(_p0);
        return ({
            this_ = std::tuple{e, p_};
            (prism_rtl::finished(this_));
        });
    });
}


/// `Start ParsePostfix, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::ast::Expr, Ps>> start_parse_postfix(crate::ast::Expr e0, Ps p0, bool commas_) {
    return prism_rtl::make_rc<ParsePostfix>(e0, p0, commas_);
}


/// PostfixStep: unbounded fn Expr, Ps, Bool -> ((Expr, Ps, Bool))
std::tuple<crate::ast::Expr, Ps, bool> postfix_step(const crate::ast::Expr& e, const Ps& p_, const bool& commas_) {
    auto&& _m = kind(p_);
    if (prism_rtl::is<crate::lexer::TokKind::KDot>(_m) && !prism_rtl::as<crate::lexer::TokKind::KDot>(_m).a0) {
        return field_or_method(e, p_, commas_);
    }
    if (prism_rtl::is<crate::lexer::TokKind::KOpen>(_m) && !prism_rtl::as<crate::lexer::TokKind::KOpen>(_m).a1) {
        auto&& m44359_1_0 = prism_rtl::as<crate::lexer::TokKind::KOpen>(_m).a0;
        if (m44359_1_0 == Text::lit("[")) {
            if (tk(p_).touches && (!at_double_open(p_, Text::lit("[")))) {
                auto [index, p1] = bracketed(adv(p_), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::ast::Expr, Ps>>(Ps)>>(prism_rtl::rc([&](Ps a0) { return entered(start_parse_expr(a0)); })));
                auto p2 = expect_close(p1, Text::lit("["));
                return std::tuple{crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::EIndex{prism_rtl::rc(e), prism_rtl::rc(index)})), .span = to(e.span, parser::prev(p2))}, p2, true};
            }
        }
    }
    if (prism_rtl::is<crate::lexer::TokKind::KLtLt>(_m)) {
        auto [types, q] = parse_type_args(p_);
        return std::tuple{crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::ETypeArgs{prism_rtl::rc(e), types})), .span = to(e.span, parser::prev(q))}, q, true};
    }
    if (prism_rtl::is<crate::lexer::TokKind::KNonEmpty>(_m)) {
        auto span = here(p_);
        auto q = out_of_scope(adv(p_), span, Text::lit("non-empty arrays"), Text::lit("the non-empty mark `+` is out of this compiler"));
        return std::tuple{crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::ENonEmpty{prism_rtl::rc(e)})), .span = to(e.span, span)}, q, true};
    }
    {
        return std::tuple{e, p_, false};
    }
}


prism_rtl::Turn<std::tuple<crate::ast::Expr, Ps, bool>> PostfixStep::cycle() const {
    const auto& e = this->e;
    const auto& p_ = this->p_;
    const auto& commas_ = this->commas_;
    return ({
        auto&& _m = kind(p_);
        prism_rtl::is<crate::lexer::TokKind::KDot>(_m) && !prism_rtl::as<crate::lexer::TokKind::KDot>(_m).a0 ? prism_rtl::more(prism_rtl::rc(FieldOrMethod(e, p_, commas_)))
        : prism_rtl::is<crate::lexer::TokKind::KOpen>(_m) && !prism_rtl::as<crate::lexer::TokKind::KOpen>(_m).a1 && ({
        auto&& m44359_1_0 = prism_rtl::as<crate::lexer::TokKind::KOpen>(_m).a0;
        (m44359_1_0 == Text::lit("[")) && (tk(p_).touches && (!at_double_open(p_, Text::lit("["))));
    }) ? ({
        auto&& m44359_1_0 = prism_rtl::as<crate::lexer::TokKind::KOpen>(_m).a0;
        ({
        auto e_1 = e;
        auto p__2 = p_;
        call_then(start_bracketed(adv(p__2), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::ast::Expr, Ps>>(Ps)>>(prism_rtl::rc([&](Ps a0) { return entered(start_parse_expr(a0)); }))), [=](std::tuple<crate::ast::Expr, Ps> bracketed_44514) {
        return ({
            auto [index, p1] = bracketed_44514;
            auto p2 = expect_close(p1, Text::lit("["));
            (prism_rtl::finished(std::tuple{crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::EIndex{prism_rtl::rc(e_1), prism_rtl::rc(index)})), .span = to(e_1.span, parser::prev(p2))}, p2, true}));
        });
    });
    });
    })
        : prism_rtl::is<crate::lexer::TokKind::KLtLt>(_m) ? ({
        auto e_1 = e;
        auto p__2 = p_;
        call_then(start_parse_type_args(p__2), [=](std::tuple<Array<crate::ast::Type>, Ps> parse_type_args_44698) {
        return ({
            auto [types, q] = parse_type_args_44698;
            (prism_rtl::finished(std::tuple{crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::ETypeArgs{prism_rtl::rc(e_1), types})), .span = to(e_1.span, parser::prev(q))}, q, true}));
        });
    });
    })
        : prism_rtl::is<crate::lexer::TokKind::KNonEmpty>(_m) ? ({
        auto span = here(p_);
        auto q = out_of_scope(adv(p_), span, Text::lit("non-empty arrays"), Text::lit("the non-empty mark `+` is out of this compiler"));
        (prism_rtl::finished(std::tuple{crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::ENonEmpty{prism_rtl::rc(e)})), .span = to(e.span, span)}, q, true}));
    })
        : prism_rtl::finished(std::tuple{e, p_, false});
    });
}


/// `Start PostfixStep, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::ast::Expr, Ps, bool>> start_postfix_step(crate::ast::Expr e, Ps p_, bool commas_) {
    return prism_rtl::make_rc<PostfixStep>(e, p_, commas_);
}


/// FieldOrMethod: unbounded fn Expr, Ps, Bool -> ((Expr, Ps, Bool))
std::tuple<crate::ast::Expr, Ps, bool> field_or_method(const crate::ast::Expr& e, const Ps& p0, const bool& commas_) {
    auto dot = here(p0);
    auto p_ = adv(p0);
    auto&& _m = kind(p_);
    if (prism_rtl::is<crate::lexer::TokKind::KName>(_m)) {
        auto&& n = prism_rtl::as<crate::lexer::TokKind::KName>(_m).a0;
        if ((len(n->path_) == Nat(1u)) && ((n.case_ == crate::lexer::NameCase(crate::lexer::NameCase::CaseLower{})) || (n.case_ == crate::lexer::NameCase(crate::lexer::NameCase::CaseTopic{})))) {
            auto t = here(p_);
            auto field = crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::EField{prism_rtl::rc(e), n.sigils, crate::ast::Ident{.name = or_(index(n->path_, Nat(0u)), Text::lit("")), .span = t}})), .span = to(e.span, t)};
            auto p1 = adv(p_);
            return arg_starts_here(p1) && (!tk(p1).line_start)
                ? ({
                auto [args, p2] = parse_call_args(p1, commas_);
                std::tuple{crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::ECall{prism_rtl::rc(field), args, false, false})), .span = to(field.span, parser::prev(p2))}, p2, false};
            })
                : std::tuple{field, p1, true};
        }
    }
    if (prism_rtl::is<crate::lexer::TokKind::KKw>(_m)) {
        auto&& w = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a0;
        auto&& m45191_1_1 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a1;
        if (m45191_1_1 == Text::lit("")) {
            if (crate::lexer::is_bound_word(w)) {
                auto t = here(p_);
                return std::tuple{crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::EField{prism_rtl::rc(e), Text::lit(""), crate::ast::Ident{.name = w, .span = t}})), .span = to(e.span, t)}, adv(p_), true};
            }
        }
    }
    if (prism_rtl::is<crate::lexer::TokKind::KName>(_m)) {
        auto&& n = prism_rtl::as<crate::lexer::TokKind::KName>(_m).a0;
        if ((n.case_ == crate::lexer::NameCase(crate::lexer::NameCase::CaseUpper{})) || (n.case_ == crate::lexer::NameCase(crate::lexer::NameCase::CaseReserved{}))) {
            auto [method, p1] = parse_sname(p_);
            auto [args, p2] = arg_starts_here(p1)
                ? parse_call_args(p1, commas_)
                : std::tuple{Array<crate::ast::Arg>{}, p1};
            return std::tuple{crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::EMethod{prism_rtl::rc(e), method, args})), .span = to(e.span, parser::prev(p2))}, p2, false};
        }
    }
    {
        return std::tuple{e, error_at(p_, dot, Text::lit("expected a field name or a `.Method` after `.`")), false};
    }
}


prism_rtl::Turn<std::tuple<crate::ast::Expr, Ps, bool>> FieldOrMethod::cycle() const {
    const auto& e = this->e;
    const auto& p0 = this->p0;
    const auto& commas_ = this->commas_;
    auto dot = here(p0);
    auto p_ = adv(p0);
    return ({
        auto&& _m = kind(p_);
        prism_rtl::is<crate::lexer::TokKind::KName>(_m) && ({
        auto&& n = prism_rtl::as<crate::lexer::TokKind::KName>(_m).a0;
        ((len(n->path_) == Nat(1u)) && ((n.case_ == crate::lexer::NameCase(crate::lexer::NameCase::CaseLower{})) || (n.case_ == crate::lexer::NameCase(crate::lexer::NameCase::CaseTopic{}))));
    }) ? ({
        auto&& n = prism_rtl::as<crate::lexer::TokKind::KName>(_m).a0;
        ({
        auto t = here(p_);
        auto field = crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::EField{prism_rtl::rc(e), n.sigils, crate::ast::Ident{.name = or_(index(n->path_, Nat(0u)), Text::lit("")), .span = t}})), .span = to(e.span, t)};
        auto p1 = adv(p_);
        arg_starts_here(p1) && (!tk(p1).line_start)
        ? ({
        auto commas__1 = commas_;
        call_then(start_parse_call_args(p1, commas__1), [=](std::tuple<Array<crate::ast::Arg>, Ps> parse_call_args_45810) {
        return ({
            auto [args, p2] = parse_call_args_45810;
            (prism_rtl::finished(std::tuple{crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::ECall{prism_rtl::rc(field), args, false, false})), .span = to(field.span, parser::prev(p2))}, p2, false}));
        });
    });
    })
        : prism_rtl::finished(std::tuple{field, p1, true});
    });
    })
        : prism_rtl::is<crate::lexer::TokKind::KKw>(_m) && ({
        auto&& w = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a0;
        auto&& m45191_1_1 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a1;
        (m45191_1_1 == Text::lit("")) && crate::lexer::is_bound_word(w);
    }) ? ({
        auto&& w = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a0;
        auto&& m45191_1_1 = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a1;
        ({
        auto t = here(p_);
        (prism_rtl::finished(std::tuple{crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::EField{prism_rtl::rc(e), Text::lit(""), crate::ast::Ident{.name = w, .span = t}})), .span = to(e.span, t)}, adv(p_), true}));
    });
    })
        : prism_rtl::is<crate::lexer::TokKind::KName>(_m) && ({
        auto&& n = prism_rtl::as<crate::lexer::TokKind::KName>(_m).a0;
        ((n.case_ == crate::lexer::NameCase(crate::lexer::NameCase::CaseUpper{})) || (n.case_ == crate::lexer::NameCase(crate::lexer::NameCase::CaseReserved{})));
    }) ? ({
        auto&& n = prism_rtl::as<crate::lexer::TokKind::KName>(_m).a0;
        ({
        auto [method, p1] = parse_sname(p_);
        auto [args, p2] = arg_starts_here(p1)
            ? parse_call_args(p1, commas_)
            : std::tuple{Array<crate::ast::Arg>{}, p1};
        (prism_rtl::finished(std::tuple{crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::EMethod{prism_rtl::rc(e), method, args})), .span = to(e.span, parser::prev(p2))}, p2, false}));
    });
    })
        : prism_rtl::finished(std::tuple{e, error_at(p_, dot, Text::lit("expected a field name or a `.Method` after `.`")), false});
    });
}


/// `Start FieldOrMethod, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::ast::Expr, Ps, bool>> start_field_or_method(crate::ast::Expr e, Ps p0, bool commas_) {
    return prism_rtl::make_rc<FieldOrMethod>(e, p0, commas_);
}


/// ParseTypeArgs: unbounded fn Ps -> (([Type], Ps))
std::tuple<Array<crate::ast::Type>, Ps> parse_type_args(const Ps& p_) {
    auto [types, q] = commas(adv(p_), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::ast::Type, Ps>>(Ps)>>(prism_rtl::rc([&](Ps a0) { return entered(start_parse_type(a0)); })));
    return kind(q) == crate::lexer::TokKind(crate::lexer::TokKind::KGtGt{})
        ? std::tuple{types, adv(q)}
        : std::tuple{types, error_here(q, Text::lit("expected `>>` to close the type arguments"))};
}


prism_rtl::Turn<std::tuple<Array<crate::ast::Type>, Ps>> ParseTypeArgs::cycle() const {
    const auto& p_ = this->p_;
    auto p__1 = p_;
    return call_then(start_commas(adv(p__1), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::ast::Type, Ps>>(Ps)>>(prism_rtl::rc([&](Ps a0) { return entered(start_parse_type(a0)); }))), [=](std::tuple<Array<crate::ast::Type>, Ps> commas_46800) {
        return ({
            auto [types, q] = commas_46800;
            kind(q) == crate::lexer::TokKind(crate::lexer::TokKind::KGtGt{})
            ? prism_rtl::finished(std::tuple{types, adv(q)})
            : prism_rtl::finished(std::tuple{types, error_here(q, Text::lit("expected `>>` to close the type arguments"))});
        });
    });
}


/// `Start ParseTypeArgs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::ast::Type>, Ps>> start_parse_type_args(Ps p_) {
    return prism_rtl::make_rc<ParseTypeArgs>(p_);
}


/// ArgStartsHere: fn Ps -> Bool
bool arg_starts_here(const Ps& p_) {
    auto t = tk(p_);
    auto&& _m = t.kind;
    if (prism_rtl::is<crate::lexer::TokKind::KName>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::lexer::TokKind::KInt>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::lexer::TokKind::KFloat>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::lexer::TokKind::KDuration>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::lexer::TokKind::KChar>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::lexer::TokKind::KText>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::lexer::TokKind::KTemplate>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::lexer::TokKind::KFree>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::lexer::TokKind::KLensDot>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::lexer::TokKind::KBackslash>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::lexer::TokKind::KAbsent>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::lexer::TokKind::KOpen>(_m)) {
        auto&& m47117_11_0 = prism_rtl::as<crate::lexer::TokKind::KOpen>(_m).a0;
        auto&& prefix = prism_rtl::as<crate::lexer::TokKind::KOpen>(_m).a1;
        if (m47117_11_0 == Text::lit("[")) {
            return (prefix || (!t.touches)) || at_double_open(p_, Text::lit("["));
        }
    }
    if (prism_rtl::is<crate::lexer::TokKind::KOpen>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::lexer::TokKind::KOp>(_m) && prism_rtl::as<crate::lexer::TokKind::KOp>(_m).a1) {
        auto&& op = prism_rtl::as<crate::lexer::TokKind::KOp>(_m).a0;
        return (op == Text::lit("+")) || (op == Text::lit("-"));
    }
    if (prism_rtl::is<crate::lexer::TokKind::KDot>(_m) && prism_rtl::as<crate::lexer::TokKind::KDot>(_m).a0) {
        return !at_line_method(p_);
    }
    if (prism_rtl::is<crate::lexer::TokKind::KKw>(_m)) {
        auto&& w = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a0;
        return fold(arg_words(), false, [&](const bool& seen, const Text& x) { return seen || (x == w); });
    }
    {
        return false;
    }
}


/// let argWords
Array<Text> arg_words() {
    return Array(std::vector{Text::lit("unit"), Text::lit("nil"), Text::lit("key"), Text::lit("ix"), Text::lit("jx"), Text::lit("kx"), Text::lit("not"), Text::lit("any"), Text::lit("given"), Text::lit("update"), Text::lit("match"), Text::lit("rebuild"), Text::lit("widget"), Text::lit("output"), Text::lit("inline_text"), Text::lit("raw")});
}


/// ParseCallArgs: unbounded fn Ps, Bool -> (([Arg], Ps))
std::tuple<Array<crate::ast::Arg>, Ps> parse_call_args(const Ps& p_, const bool& commas_) {
    return commas_ && (!p_.step_mode)
        ? commas(p_, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::ast::Arg, Ps>>(Ps)>>(prism_rtl::rc([&](Ps a0) { return entered(start_parse_arg(a0)); })))
        : parse_one_arg(p_);
}


prism_rtl::Turn<std::tuple<Array<crate::ast::Arg>, Ps>> ParseCallArgs::cycle() const {
    const auto& p_ = this->p_;
    const auto& commas_ = this->commas_;
    return commas_ && (!p_.step_mode)
        ? prism_rtl::more(prism_rtl::rc(Commas(p_, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::ast::Arg, Ps>>(Ps)>>(prism_rtl::rc([&](Ps a0) { return entered(start_parse_arg(a0)); })))))
        : prism_rtl::more(prism_rtl::rc(ParseOneArg(p_)));
}


/// `Start ParseCallArgs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::ast::Arg>, Ps>> start_parse_call_args(Ps p_, bool commas_) {
    return prism_rtl::make_rc<ParseCallArgs>(p_, commas_);
}


/// ParseOneArg: unbounded fn Ps -> (([Arg], Ps))
std::tuple<Array<crate::ast::Arg>, Ps> parse_one_arg(const Ps& p_) {
    auto [a, q] = parse_arg(p_);
    return std::tuple{Array(std::vector{a}), q};
}


prism_rtl::Turn<std::tuple<Array<crate::ast::Arg>, Ps>> ParseOneArg::cycle() const {
    const auto& p_ = this->p_;
    auto p__1 = p_;
    return call_then(start_parse_arg(p__1), [=](std::tuple<crate::ast::Arg, Ps> parse_arg_48333) {
        return ({
            auto [a, q] = parse_arg_48333;
            (prism_rtl::finished(std::tuple{Array(std::vector{a}), q}));
        });
    });
}


/// `Start ParseOneArg, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::ast::Arg>, Ps>> start_parse_one_arg(Ps p_) {
    return prism_rtl::make_rc<ParseOneArg>(p_);
}


/// ParseArg: unbounded fn Ps -> ((Arg, Ps))
std::tuple<crate::ast::Arg, Ps> parse_arg(const Ps& p_) {
    auto [value, q] = parse_arg_expr(p_);
    return std::tuple{crate::ast::Arg{.name = std::optional<crate::ast::Ident>{}, .value = value, .span = value.span}, q};
}


prism_rtl::Turn<std::tuple<crate::ast::Arg, Ps>> ParseArg::cycle() const {
    const auto& p_ = this->p_;
    auto p__1 = p_;
    return call_then(start_parse_arg_expr(p__1), [=](std::tuple<crate::ast::Expr, Ps> parse_arg_expr_48441) {
        return ({
            auto [value, q] = parse_arg_expr_48441;
            (prism_rtl::finished(std::tuple{crate::ast::Arg{.name = std::optional<crate::ast::Ident>{}, .value = value, .span = value.span}, q}));
        });
    });
}


/// `Start ParseArg, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::ast::Arg, Ps>> start_parse_arg(Ps p_) {
    return prism_rtl::make_rc<ParseArg>(p_);
}


/// ParseParenArgs: unbounded fn Ps -> (([Arg], Bool, Ps))
std::tuple<Array<crate::ast::Arg>, bool, Ps> parse_paren_args(const Ps& p0) {
    auto p_ = adv(p0);
    return at_close(p_, Text::lit("("))
        ? std::tuple{Array<crate::ast::Arg>{}, false, adv(p_)}
        : ({
        auto r = ({
            ArgsRead this_ = ArgsRead{.args = Array<crate::ast::Arg>{}, .rest = false, .p_ = p_, .going = true};
            while (this_.going && (!this_.p_->bad)) {
                if (kind(this_.p_) == crate::lexer::TokKind(crate::lexer::TokKind::KDotDot{})) {
                    this_.p_ = adv(this_.p_);
                    this_.rest = true;
                } else  {
                    auto start = here(this_.p_);
                    auto [name_opt, p1] = parse_arg_name(this_.p_);
                    auto [value, p2] = parse_arg_expr(p1);
                    this_.args = prelude::push(this_.args, crate::ast::Arg{.name = name_opt, .value = value, .span = to(start, value.span)});
                    this_.p_ = p2;
                }
                if (at_comma(this_.p_)) {
                    this_.p_ = adv(this_.p_);
                } else  {
                    this_.p_ = expect_close(this_.p_, Text::lit("("));
                    this_.going = false;
                }
            }
            this_;
        });
        std::tuple{r->args, r.rest, r.p_};
    });
}


prism_rtl::Turn<std::tuple<Array<crate::ast::Arg>, bool, Ps>> ParseParenArgs::cycle() const {
    const auto& p0 = this->p0;
    auto p_ = adv(p0);
    return at_close(p_, Text::lit("("))
        ? prism_rtl::finished(std::tuple{Array<crate::ast::Arg>{}, false, adv(p_)})
        : ({
        ArgsRead this_ = ArgsRead{.args = Array<crate::ast::Arg>{}, .rest = false, .p_ = p_, .going = true};
        auto p__1 = p_;
        call_then(loop_job(std::tuple{this_}, ({
        auto p__1_2 = p__1;
        [=](std::tuple<ArgsRead> _p0) {
        auto this_ = std::get<0>(_p0);
        return this_.going && (!this_.p_->bad)
            ? ({
            if (kind(this_.p_) == crate::lexer::TokKind(crate::lexer::TokKind::KDotDot{})) {
                this_.p_ = adv(this_.p_);
                this_.rest = true;
            } else  {
                auto start = here(this_.p_);
                auto [name_opt, p1] = parse_arg_name(this_.p_);
                auto [value, p2] = parse_arg_expr(p1);
                this_->args = prelude::push(this_->args, crate::ast::Arg{.name = name_opt, .value = value, .span = to(start, value.span)});
                this_.p_ = p2;
            }
            if (at_comma(this_.p_)) {
                this_.p_ = adv(this_.p_);
            } else  {
                this_.p_ = expect_close(this_.p_, Text::lit("("));
                this_.going = false;
            }
            Expected<std::tuple<ArgsRead>, std::tuple<ArgsRead>>(std::tuple{this_});
        })
            : Expected<std::tuple<ArgsRead>, std::tuple<ArgsRead>>(unexpected(std::tuple{this_}));
    };
    })), [=](std::tuple<ArgsRead> _p0) {
        auto this_ = std::get<0>(_p0);
        return ({
            auto r = this_;
            (prism_rtl::finished(std::tuple{r->args, r.rest, r.p_}));
        });
    });
    });
}


/// `Start ParseParenArgs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::ast::Arg>, bool, Ps>> start_parse_paren_args(Ps p0) {
    return prism_rtl::make_rc<ParseParenArgs>(p0);
}


/// ParseArgName: fn Ps -> ((?Ident, Ps))
std::tuple<std::optional<crate::ast::Ident>, Ps> parse_arg_name(const Ps& p_) {
    auto&& _m = kind(p_);
    if (prism_rtl::is<crate::lexer::TokKind::KName>(_m)) {
        auto&& n = prism_rtl::as<crate::lexer::TokKind::KName>(_m).a0;
        if ((((n.sigils == Text::lit("")) && (len(n->path_) == Nat(1u))) && (n.case_ == crate::lexer::NameCase(crate::lexer::NameCase::CaseLower{}))) && at_op(adv(p_), Text::lit("="))) {
            return std::tuple{std::optional(crate::ast::Ident{.name = or_(index(n->path_, Nat(0u)), Text::lit("")), .span = here(p_)}), adv(adv(p_))};
        }
    }
    {
        return std::tuple{std::optional<crate::ast::Ident>{}, p_};
    }
}


/// ParsePrimary: unbounded fn Ps, Bool -> ((Expr, Bool, Ps))
std::tuple<crate::ast::Expr, bool, Ps> parse_primary(const Ps& p_, const bool& commas_) {
    auto start = here(p_);
    auto tok = tk(p_);
    auto&& _m = tok.kind;
    if (prism_rtl::is<crate::lexer::TokKind::KName>(_m)) {
        auto&& n = prism_rtl::as<crate::lexer::TokKind::KName>(_m).a0;
        return name_primary(p_, n, commas_);
    }
    if (prism_rtl::is<crate::lexer::TokKind::KKw>(_m)) {
        auto&& w = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a0;
        auto&& sigils = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a1;
        return keyword_primary(p_, w, sigils, commas_);
    }
    if (prism_rtl::is<crate::lexer::TokKind::KInt>(_m)) {
        return literal_primary(p_);
    }
    if (prism_rtl::is<crate::lexer::TokKind::KFloat>(_m)) {
        return literal_primary(p_);
    }
    if (prism_rtl::is<crate::lexer::TokKind::KDuration>(_m)) {
        return literal_primary(p_);
    }
    if (prism_rtl::is<crate::lexer::TokKind::KChar>(_m)) {
        return literal_primary(p_);
    }
    if (prism_rtl::is<crate::lexer::TokKind::KText>(_m)) {
        return literal_primary(p_);
    }
    if (prism_rtl::is<crate::lexer::TokKind::KTemplate>(_m)) {
        auto&& t = prism_rtl::as<crate::lexer::TokKind::KTemplate>(_m).a0;
        auto [tpl, q] = parse_template(adv(p_), t, tok.span);
        return std::tuple{crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::ETemplate{tpl})), .span = tok.span}, false, q};
    }
    if (prism_rtl::is<crate::lexer::TokKind::KOpen>(_m)) {
        auto&& m50292_8_0 = prism_rtl::as<crate::lexer::TokKind::KOpen>(_m).a0;
        if (m50292_8_0 == Text::lit("(")) {
            return paren_primary(p_);
        }
    }
    if (prism_rtl::is<crate::lexer::TokKind::KOpen>(_m)) {
        auto&& m50292_9_0 = prism_rtl::as<crate::lexer::TokKind::KOpen>(_m).a0;
        if (m50292_9_0 == Text::lit("[")) {
            return square_primary(p_);
        }
    }
    if (prism_rtl::is<crate::lexer::TokKind::KOpen>(_m)) {
        return map_primary(p_);
    }
    if (prism_rtl::is<crate::lexer::TokKind::KDot>(_m) && prism_rtl::as<crate::lexer::TokKind::KDot>(_m).a0) {
        auto p1 = adv(p_);
        auto&& _m = kind(p1);
        if (prism_rtl::is<crate::lexer::TokKind::KName>(_m)) {
            auto&& n = prism_rtl::as<crate::lexer::TokKind::KName>(_m).a0;
            if (((n.sigils == Text::lit("")) && (len(n->path_) == Nat(1u))) && (n.case_ == crate::lexer::NameCase(crate::lexer::NameCase::CaseLower{}))) {
                auto t = here(p1);
                return std::tuple{crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::ETopicField{crate::ast::Ident{.name = or_(index(n->path_, Nat(0u)), Text::lit("")), .span = t}})), .span = to(start, t)}, false, adv(p1)};
            }
        }
        if (prism_rtl::is<crate::lexer::TokKind::KName>(_m)) {
            auto&& n = prism_rtl::as<crate::lexer::TokKind::KName>(_m).a0;
            if (n.case_ == crate::lexer::NameCase(crate::lexer::NameCase::CaseUpper{})) {
                return std::tuple{no_expr(), false, error_at(p1, start, prism_rtl::cat("a spaced `.", crate::lexer::join(n->path_, Text::lit(".")), "` begins its own line, below the call it takes as its receiver (layout rule 9)"))};
            }
        }
        {
            return std::tuple{no_expr(), false, error_at(p1, start, Text::lit("a prefix `.` takes a field name, applied to the topic `_`"))};
        }
    }
    if (prism_rtl::is<crate::lexer::TokKind::KLensDot>(_m)) {
        return lens_primary(p_);
    }
    if (prism_rtl::is<crate::lexer::TokKind::KFree>(_m)) {
        auto&& s = prism_rtl::as<crate::lexer::TokKind::KFree>(_m).a0;
        return s == Text::lit("!")
            ? std::tuple{no_expr(), true, error_at(adv(p_), tok.span, Text::lit("`!` is never free: no event fires a constant"))}
            : s == Text::lit("&")
            ? std::tuple{no_expr(), true, error_at(adv(p_), tok.span, Text::lit("`&` is never free: no reference exists outside the value an `update` block names"))}
            : ({
            auto [operand, q] = parse_expr_ctx(adv(p_), commas_);
            std::tuple{crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::EFreeSigil{s, prism_rtl::rc(operand)})), .span = to(start, operand.span)}, true, q};
        });
    }
    if (prism_rtl::is<crate::lexer::TokKind::KBackslash>(_m)) {
        auto [e, q] = parse_lambda(p_);
        return std::tuple{e, true, q};
    }
    if (prism_rtl::is<crate::lexer::TokKind::KAbsent>(_m)) {
        auto q = out_of_scope(adv(p_), tok.span, Text::lit("sparse tuples"), Text::lit("an absent component `-` makes a sparse tuple, which is out of this compiler"));
        return std::tuple{crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::EAbsent{})), .span = tok.span}, false, q};
    }
    if (prism_rtl::is<crate::lexer::TokKind::KDotDot>(_m)) {
        return std::tuple{crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::ERest{})), .span = tok.span}, false, adv(p_)};
    }
    if (prism_rtl::is<crate::lexer::TokKind::KTrait>(_m)) {
        return std::tuple{no_expr(), false, error_at(p_, tok.span, Text::lit("no trait is a value: a `^Trait` stands in a type, a bound, `derive`, `trait` or `impl`"))};
    }
    if (prism_rtl::is<crate::lexer::TokKind::KFamily>(_m)) {
        auto&& path_ = prism_rtl::as<crate::lexer::TokKind::KFamily>(_m).a0;
        return std::tuple{no_expr(), false, error_at(p_, tok.span, prism_rtl::cat("`", crate::lexer::join(path_, Text::lit(".")), ".*` names every tag of a family: it stands in a pattern, an `emit` row or a `use`, not in an expression"))};
    }
    if (prism_rtl::is<crate::lexer::TokKind::KBar>(_m)) {
        return std::tuple{no_expr(), false, error_at(p_, tok.span, Text::lit("a bare `|` is not an operator: the merge is `<|`, and `|` separates the families of a row"))};
    }
    {
        return std::tuple{no_expr(), false, error_here(p_, Text::lit("expected an expression"))};
    }
}


prism_rtl::Turn<std::tuple<crate::ast::Expr, bool, Ps>> ParsePrimary::cycle() const {
    const auto& p_ = this->p_;
    const auto& commas_ = this->commas_;
    auto start = here(p_);
    auto tok = tk(p_);
    return ({
        auto&& _m = tok.kind;
        prism_rtl::is<crate::lexer::TokKind::KName>(_m) ? ({
        auto&& n = prism_rtl::as<crate::lexer::TokKind::KName>(_m).a0;
        prism_rtl::more(prism_rtl::rc(NamePrimary(p_, n, commas_)));
    })
        : prism_rtl::is<crate::lexer::TokKind::KKw>(_m) ? ({
        auto&& w = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a0;
        auto&& sigils = prism_rtl::as<crate::lexer::TokKind::KKw>(_m).a1;
        prism_rtl::more(prism_rtl::rc(KeywordPrimary(p_, w, sigils, commas_)));
    })
        : prism_rtl::is<crate::lexer::TokKind::KInt>(_m) ? prism_rtl::more(prism_rtl::rc(LiteralPrimary(p_)))
        : prism_rtl::is<crate::lexer::TokKind::KFloat>(_m) ? prism_rtl::more(prism_rtl::rc(LiteralPrimary(p_)))
        : prism_rtl::is<crate::lexer::TokKind::KDuration>(_m) ? prism_rtl::more(prism_rtl::rc(LiteralPrimary(p_)))
        : prism_rtl::is<crate::lexer::TokKind::KChar>(_m) ? prism_rtl::more(prism_rtl::rc(LiteralPrimary(p_)))
        : prism_rtl::is<crate::lexer::TokKind::KText>(_m) ? prism_rtl::more(prism_rtl::rc(LiteralPrimary(p_)))
        : prism_rtl::is<crate::lexer::TokKind::KTemplate>(_m) ? ({
        auto&& t = prism_rtl::as<crate::lexer::TokKind::KTemplate>(_m).a0;
        ({
        auto p__1 = p_;
        auto t_2 = t;
        call_then(start_parse_template(adv(p__1), t_2, tok.span), [=](std::tuple<crate::ast::Template, Ps> parse_template_50706) {
        return ({
            auto [tpl, q] = parse_template_50706;
            (prism_rtl::finished(std::tuple{crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::ETemplate{tpl})), .span = tok.span}, false, q}));
        });
    });
    });
    })
        : prism_rtl::is<crate::lexer::TokKind::KOpen>(_m) && ({
        auto&& m50292_8_0 = prism_rtl::as<crate::lexer::TokKind::KOpen>(_m).a0;
        (m50292_8_0 == Text::lit("("));
    }) ? ({
        auto&& m50292_8_0 = prism_rtl::as<crate::lexer::TokKind::KOpen>(_m).a0;
        prism_rtl::more(prism_rtl::rc(ParenPrimary(p_)));
    })
        : prism_rtl::is<crate::lexer::TokKind::KOpen>(_m) && ({
        auto&& m50292_9_0 = prism_rtl::as<crate::lexer::TokKind::KOpen>(_m).a0;
        (m50292_9_0 == Text::lit("["));
    }) ? ({
        auto&& m50292_9_0 = prism_rtl::as<crate::lexer::TokKind::KOpen>(_m).a0;
        prism_rtl::more(prism_rtl::rc(SquarePrimary(p_)));
    })
        : prism_rtl::is<crate::lexer::TokKind::KOpen>(_m) ? prism_rtl::more(prism_rtl::rc(MapPrimary(p_)))
        : prism_rtl::is<crate::lexer::TokKind::KDot>(_m) && prism_rtl::as<crate::lexer::TokKind::KDot>(_m).a0 ? ({
        auto p1 = adv(p_);
        ({
        auto&& _m = kind(p1);
        prism_rtl::is<crate::lexer::TokKind::KName>(_m) && ({
        auto&& n = prism_rtl::as<crate::lexer::TokKind::KName>(_m).a0;
        (((n.sigils == Text::lit("")) && (len(n->path_) == Nat(1u))) && (n.case_ == crate::lexer::NameCase(crate::lexer::NameCase::CaseLower{})));
    }) ? ({
        auto&& n = prism_rtl::as<crate::lexer::TokKind::KName>(_m).a0;
        ({
        auto t = here(p1);
        (prism_rtl::finished(std::tuple{crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::ETopicField{crate::ast::Ident{.name = or_(index(n->path_, Nat(0u)), Text::lit("")), .span = t}})), .span = to(start, t)}, false, adv(p1)}));
    });
    })
        : prism_rtl::is<crate::lexer::TokKind::KName>(_m) && ({
        auto&& n = prism_rtl::as<crate::lexer::TokKind::KName>(_m).a0;
        (n.case_ == crate::lexer::NameCase(crate::lexer::NameCase::CaseUpper{}));
    }) ? ({
        auto&& n = prism_rtl::as<crate::lexer::TokKind::KName>(_m).a0;
        prism_rtl::finished(std::tuple{no_expr(), false, error_at(p1, start, prism_rtl::cat("a spaced `.", crate::lexer::join(n->path_, Text::lit(".")), "` begins its own line, below the call it takes as its receiver (layout rule 9)"))});
    })
        : prism_rtl::finished(std::tuple{no_expr(), false, error_at(p1, start, Text::lit("a prefix `.` takes a field name, applied to the topic `_`"))});
    });
    })
        : prism_rtl::is<crate::lexer::TokKind::KLensDot>(_m) ? prism_rtl::more(prism_rtl::rc(LensPrimary(p_)))
        : prism_rtl::is<crate::lexer::TokKind::KFree>(_m) ? ({
        auto&& s = prism_rtl::as<crate::lexer::TokKind::KFree>(_m).a0;
        s == Text::lit("!")
        ? prism_rtl::finished(std::tuple{no_expr(), true, error_at(adv(p_), tok.span, Text::lit("`!` is never free: no event fires a constant"))})
        : s == Text::lit("&")
        ? prism_rtl::finished(std::tuple{no_expr(), true, error_at(adv(p_), tok.span, Text::lit("`&` is never free: no reference exists outside the value an `update` block names"))})
        : ({
        auto commas__1 = commas_;
        auto p__2 = p_;
        auto s_3 = s;
        call_then(start_parse_expr_ctx(adv(p__2), commas__1), [=](std::tuple<crate::ast::Expr, Ps> parse_expr_ctx_52222) {
        return ({
            auto [operand, q] = parse_expr_ctx_52222;
            (prism_rtl::finished(std::tuple{crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::EFreeSigil{s_3, prism_rtl::rc(operand)})), .span = to(start, operand.span)}, true, q}));
        });
    });
    });
    })
        : prism_rtl::is<crate::lexer::TokKind::KBackslash>(_m) ? ({
        auto p__1 = p_;
        call_then(start_parse_lambda(p__1), [=](std::tuple<crate::ast::Expr, Ps> parse_lambda_52393) {
        return ({
            auto [e, q] = parse_lambda_52393;
            (prism_rtl::finished(std::tuple{e, true, q}));
        });
    });
    })
        : prism_rtl::is<crate::lexer::TokKind::KAbsent>(_m) ? ({
        auto q = out_of_scope(adv(p_), tok.span, Text::lit("sparse tuples"), Text::lit("an absent component `-` makes a sparse tuple, which is out of this compiler"));
        (prism_rtl::finished(std::tuple{crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::EAbsent{})), .span = tok.span}, false, q}));
    })
        : prism_rtl::is<crate::lexer::TokKind::KDotDot>(_m) ? prism_rtl::finished(std::tuple{crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::ERest{})), .span = tok.span}, false, adv(p_)})
        : prism_rtl::is<crate::lexer::TokKind::KTrait>(_m) ? prism_rtl::finished(std::tuple{no_expr(), false, error_at(p_, tok.span, Text::lit("no trait is a value: a `^Trait` stands in a type, a bound, `derive`, `trait` or `impl`"))})
        : prism_rtl::is<crate::lexer::TokKind::KFamily>(_m) ? ({
        auto&& path_ = prism_rtl::as<crate::lexer::TokKind::KFamily>(_m).a0;
        prism_rtl::finished(std::tuple{no_expr(), false, error_at(p_, tok.span, prism_rtl::cat("`", crate::lexer::join(path_, Text::lit(".")), ".*` names every tag of a family: it stands in a pattern, an `emit` row or a `use`, not in an expression"))});
    })
        : prism_rtl::is<crate::lexer::TokKind::KBar>(_m) ? prism_rtl::finished(std::tuple{no_expr(), false, error_at(p_, tok.span, Text::lit("a bare `|` is not an operator: the merge is `<|`, and `|` separates the families of a row"))})
        : prism_rtl::finished(std::tuple{no_expr(), false, error_here(p_, Text::lit("expected an expression"))});
    });
}


/// `Start ParsePrimary, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::ast::Expr, bool, Ps>> start_parse_primary(Ps p_, bool commas_) {
    return prism_rtl::make_rc<ParsePrimary>(p_, commas_);
}


/// LiteralPrimary: unbounded fn Ps -> ((Expr, Bool, Ps))
std::tuple<crate::ast::Expr, bool, Ps> literal_primary(const Ps& p_) {
    auto [lit, q] = parse_literal(p_);
    return std::tuple{crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::ELit{lit})), .span = lit.span}, false, q};
}


prism_rtl::Turn<std::tuple<crate::ast::Expr, bool, Ps>> LiteralPrimary::cycle() const {
    const auto& p_ = this->p_;
    auto p__1 = p_;
    return call_then(start_parse_literal(p__1), [=](std::tuple<crate::ast::Literal, Ps> parse_literal_53389) {
        return ({
            auto [lit, q] = parse_literal_53389;
            (prism_rtl::finished(std::tuple{crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::ELit{lit})), .span = lit.span}, false, q}));
        });
    });
}


/// `Start LiteralPrimary, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::ast::Expr, bool, Ps>> start_literal_primary(Ps p_) {
    return prism_rtl::make_rc<LiteralPrimary>(p_);
}


/// NamePrimary: unbounded fn Ps, NameTok, Bool -> ((Expr, Bool, Ps))
std::tuple<crate::ast::Expr, bool, Ps> name_primary(const Ps& p0, const crate::lexer::NameTok& n, const bool& commas_) {
    auto start = here(p0);
    auto name = crate::ast::SName{.sigils = n.sigils, .path_ = n->path_, .span = start};
    auto p1 = check_name_scope(adv(p0), name);
    auto plain = crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::EName{name})), .span = start};
    auto [e, p_] = kind(p1) == crate::lexer::TokKind(crate::lexer::TokKind::KLtLt{})
        ? type_args_on(plain, p1, start)
        : std::tuple{plain, p1};
    return is_callee(name)
        ? at_single_open(p_, Text::lit("(")) && tk(p_).touches
        ? ({
        auto [args, rest, q] = parse_paren_args(p_);
        std::tuple{crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::ECall{prism_rtl::rc(e), args, true, rest})), .span = to(start, parser::prev(q))}, false, q};
    })
        : at_kw(p_, Text::lit("monad"))
        ? ({
        auto kw = here(p_);
        auto [body, q] = parse_block_after_colon(out_of_scope(adv(p_), kw, Text::lit("`T monad:` blocks and `^Monad`"), Text::lit("monad blocks are out of this compiler")));
        std::tuple{crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::EMonad{prism_rtl::rc(e), body})), .span = to(start, body.span)}, true, q};
    })
        : arg_starts_here(p_)
        ? ({
        auto [args, q] = parse_call_args(p_, commas_);
        std::tuple{crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::ECall{prism_rtl::rc(e), args, false, false})), .span = to(start, parser::prev(q))}, true, q};
    })
        : std::tuple{e, false, p_}
        : (at_single_open(p_, Text::lit("(")) && tk(p_).touches) && (!is_topic(name))
        ? std::tuple{e, false, error_at(p_, here(p_), prism_rtl::cat("`", name_text(name), "` is a value and is not applied: a function's name is uppercase (case is a mark)"))}
        : std::tuple{e, false, p_};
}


prism_rtl::Turn<std::tuple<crate::ast::Expr, bool, Ps>> NamePrimary::cycle() const {
    const auto& p0 = this->p0;
    const auto& n = this->n;
    const auto& commas_ = this->commas_;
    auto start = here(p0);
    auto name = crate::ast::SName{.sigils = n.sigils, .path_ = n->path_, .span = start};
    auto p1 = check_name_scope(adv(p0), name);
    auto plain = crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::EName{name})), .span = start};
    auto [e, p_] = kind(p1) == crate::lexer::TokKind(crate::lexer::TokKind::KLtLt{})
        ? type_args_on(plain, p1, start)
        : std::tuple{plain, p1};
    return is_callee(name)
        ? at_single_open(p_, Text::lit("(")) && tk(p_).touches
        ? call_then(start_parse_paren_args(p_), [=](std::tuple<Array<crate::ast::Arg>, bool, Ps> parse_paren_args_54012) {
        return ({
            auto [args, rest, q] = parse_paren_args_54012;
            (prism_rtl::finished(std::tuple{crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::ECall{prism_rtl::rc(e), args, true, rest})), .span = to(start, parser::prev(q))}, false, q}));
        });
    })
        : at_kw(p_, Text::lit("monad"))
        ? ({
        auto kw = here(p_);
        call_then(start_parse_block_after_colon(out_of_scope(adv(p_), kw, Text::lit("`T monad:` blocks and `^Monad`"), Text::lit("monad blocks are out of this compiler"))), [=](std::tuple<crate::ast::Block, Ps> parse_block_after_colon_54263) {
        return ({
            auto [body, q] = parse_block_after_colon_54263;
            (prism_rtl::finished(std::tuple{crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::EMonad{prism_rtl::rc(e), body})), .span = to(start, body.span)}, true, q}));
        });
    });
    })
        : arg_starts_here(p_)
        ? ({
        auto commas__1 = commas_;
        call_then(start_parse_call_args(p_, commas__1), [=](std::tuple<Array<crate::ast::Arg>, Ps> parse_call_args_54529) {
        return ({
            auto [args, q] = parse_call_args_54529;
            (prism_rtl::finished(std::tuple{crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::ECall{prism_rtl::rc(e), args, false, false})), .span = to(start, parser::prev(q))}, true, q}));
        });
    });
    })
        : prism_rtl::finished(std::tuple{e, false, p_})
        : (at_single_open(p_, Text::lit("(")) && tk(p_).touches) && (!is_topic(name))
        ? prism_rtl::finished(std::tuple{e, false, error_at(p_, here(p_), prism_rtl::cat("`", name_text(name), "` is a value and is not applied: a function's name is uppercase (case is a mark)"))})
        : prism_rtl::finished(std::tuple{e, false, p_});
}


/// `Start NamePrimary, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::ast::Expr, bool, Ps>> start_name_primary(Ps p0, crate::lexer::NameTok n, bool commas_) {
    return prism_rtl::make_rc<NamePrimary>(p0, n, commas_);
}


/// TypeArgsOn: unbounded fn Expr, Ps, Range -> ((Expr, Ps))
std::tuple<crate::ast::Expr, Ps> type_args_on(const crate::ast::Expr& e, const Ps& p_, const crate::ast::Range& start) {
    auto [types, q] = parse_type_args(p_);
    return std::tuple{crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::ETypeArgs{prism_rtl::rc(e), types})), .span = to(start, parser::prev(q))}, q};
}


prism_rtl::Turn<std::tuple<crate::ast::Expr, Ps>> TypeArgsOn::cycle() const {
    const auto& e = this->e;
    const auto& p_ = this->p_;
    const auto& start = this->start;
    auto e_1 = e;
    auto p__2 = p_;
    auto start_3 = start;
    return call_then(start_parse_type_args(p__2), [=](std::tuple<Array<crate::ast::Type>, Ps> parse_type_args_55032) {
        return ({
            auto [types, q] = parse_type_args_55032;
            (prism_rtl::finished(std::tuple{crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::ETypeArgs{prism_rtl::rc(e_1), types})), .span = to(start_3, parser::prev(q))}, q}));
        });
    });
}


/// `Start TypeArgsOn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::ast::Expr, Ps>> start_type_args_on(crate::ast::Expr e, Ps p_, crate::ast::Range start) {
    return prism_rtl::make_rc<TypeArgsOn>(e, p_, start);
}


/// ParenPrimary: unbounded fn Ps -> ((Expr, Bool, Ps))
std::tuple<crate::ast::Expr, bool, Ps> paren_primary(const Ps& p_) {
    auto start = here(p_);
    return at_double_open(p_, Text::lit("("))
        ? ({
        auto [elems, p1] = commas(open_double(p_), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::ast::Expr, Ps>>(Ps)>>(prism_rtl::rc([&](Ps a0) { return entered(start_parse_arg_expr(a0)); })));
        auto p2 = close_double(p1, Text::lit("("));
        std::tuple{crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::ETuple{elems})), .span = to(start, parser::prev(p2))}, false, p2};
    })
        : ({
        auto [inner, p1] = bracketed(adv(p_), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::ast::Expr, Ps>>(Ps)>>(prism_rtl::rc([&](Ps a0) { return entered(start_parse_rhs_expr(a0)); })));
        at_comma(p1)
        ? std::tuple{no_expr(), false, error_at(p1, here(p1), Text::lit("a group holds one expression: a comma here needs a call at the group's head, or `((` `))` for a tuple"))}
        : ({
        auto p2 = expect_close(p1, Text::lit("("));
        std::tuple{crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::EGroup{prism_rtl::rc(inner)})), .span = to(start, parser::prev(p2))}, false, p2};
    });
    });
}


prism_rtl::Turn<std::tuple<crate::ast::Expr, bool, Ps>> ParenPrimary::cycle() const {
    const auto& p_ = this->p_;
    auto start = here(p_);
    return at_double_open(p_, Text::lit("("))
        ? ({
        auto p__1 = p_;
        call_then(start_commas(open_double(p__1), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::ast::Expr, Ps>>(Ps)>>(prism_rtl::rc([&](Ps a0) { return entered(start_parse_arg_expr(a0)); }))), [=](std::tuple<Array<crate::ast::Expr>, Ps> commas_55362) {
        return ({
            auto [elems, p1] = commas_55362;
            auto p2 = close_double(p1, Text::lit("("));
            (prism_rtl::finished(std::tuple{crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::ETuple{elems})), .span = to(start, parser::prev(p2))}, false, p2}));
        });
    });
    })
        : ({
        auto p__1 = p_;
        call_then(start_bracketed(adv(p__1), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::ast::Expr, Ps>>(Ps)>>(prism_rtl::rc([&](Ps a0) { return entered(start_parse_rhs_expr(a0)); }))), [=](std::tuple<crate::ast::Expr, Ps> bracketed_55626) {
        return ({
            auto [inner, p1] = bracketed_55626;
            at_comma(p1)
            ? prism_rtl::finished(std::tuple{no_expr(), false, error_at(p1, here(p1), Text::lit("a group holds one expression: a comma here needs a call at the group's head, or `((` `))` for a tuple"))})
            : ({
            auto p2 = expect_close(p1, Text::lit("("));
            (prism_rtl::finished(std::tuple{crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::EGroup{prism_rtl::rc(inner)})), .span = to(start, parser::prev(p2))}, false, p2}));
        });
        });
    });
    });
}


/// `Start ParenPrimary, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::ast::Expr, bool, Ps>> start_paren_primary(Ps p_) {
    return prism_rtl::make_rc<ParenPrimary>(p_);
}


/// SquarePrimary: unbounded fn Ps -> ((Expr, Bool, Ps))
std::tuple<crate::ast::Expr, bool, Ps> square_primary(const Ps& p_) {
    auto start = here(p_);
    return at_double_open(p_, Text::lit("["))
        ? ({
        auto p1 = open_double(p_);
        auto [elems, p2] = at_close(p1, Text::lit("["))
            ? std::tuple{Array<crate::ast::Expr>{}, p1}
            : commas(p1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::ast::Expr, Ps>>(Ps)>>(prism_rtl::rc([&](Ps a0) { return entered(start_parse_arg_expr(a0)); })));
        auto p3 = close_double(p2, Text::lit("["));
        std::tuple{crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::EArray{elems})), .span = to(start, parser::prev(p3))}, false, p3};
    })
        : ({
        auto [index, p1] = bracketed(adv(p_), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::ast::Expr, Ps>>(Ps)>>(prism_rtl::rc([&](Ps a0) { return entered(start_parse_expr(a0)); })));
        auto p2 = expect_close(p1, Text::lit("["));
        std::tuple{crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::ETopicIndex{prism_rtl::rc(index)})), .span = to(start, parser::prev(p2))}, false, p2};
    });
}


prism_rtl::Turn<std::tuple<crate::ast::Expr, bool, Ps>> SquarePrimary::cycle() const {
    const auto& p_ = this->p_;
    auto start = here(p_);
    return at_double_open(p_, Text::lit("["))
        ? ({
        auto p1 = open_double(p_);
        auto [elems, p2] = at_close(p1, Text::lit("["))
            ? std::tuple{Array<crate::ast::Expr>{}, p1}
            : commas(p1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::ast::Expr, Ps>>(Ps)>>(prism_rtl::rc([&](Ps a0) { return entered(start_parse_arg_expr(a0)); })));
        auto p3 = close_double(p2, Text::lit("["));
        (prism_rtl::finished(std::tuple{crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::EArray{elems})), .span = to(start, parser::prev(p3))}, false, p3}));
    })
        : ({
        auto p__1 = p_;
        call_then(start_bracketed(adv(p__1), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::ast::Expr, Ps>>(Ps)>>(prism_rtl::rc([&](Ps a0) { return entered(start_parse_expr(a0)); }))), [=](std::tuple<crate::ast::Expr, Ps> bracketed_56450) {
        return ({
            auto [index, p1] = bracketed_56450;
            auto p2 = expect_close(p1, Text::lit("["));
            (prism_rtl::finished(std::tuple{crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::ETopicIndex{prism_rtl::rc(index)})), .span = to(start, parser::prev(p2))}, false, p2}));
        });
    });
    });
}


/// `Start SquarePrimary, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::ast::Expr, bool, Ps>> start_square_primary(Ps p_) {
    return prism_rtl::make_rc<SquarePrimary>(p_);
}


/// MapPrimary: unbounded fn Ps -> ((Expr, Bool, Ps))
std::tuple<crate::ast::Expr, bool, Ps> map_primary(const Ps& p_) {
    auto start = here(p_);
    auto p1 = adv(p_);
    auto [entries, p2] = at_close(p1, Text::lit("{"))
        ? std::tuple{Array<std::tuple<crate::ast::Expr, crate::ast::Expr>>{}, p1}
        : commas(p1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<std::tuple<crate::ast::Expr, crate::ast::Expr>, Ps>>(Ps)>>(prism_rtl::rc([&](Ps a0) { return entered(start_parse_map_entry(a0)); })));
    auto p3 = expect_close(p2, Text::lit("{"));
    return std::tuple{crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::EMap{entries})), .span = to(start, parser::prev(p3))}, false, p3};
}


prism_rtl::Turn<std::tuple<crate::ast::Expr, bool, Ps>> MapPrimary::cycle() const {
    const auto& p_ = this->p_;
    auto start = here(p_);
    auto p1 = adv(p_);
    auto [entries, p2] = at_close(p1, Text::lit("{"))
        ? std::tuple{Array<std::tuple<crate::ast::Expr, crate::ast::Expr>>{}, p1}
        : commas(p1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<std::tuple<crate::ast::Expr, crate::ast::Expr>, Ps>>(Ps)>>(prism_rtl::rc([&](Ps a0) { return entered(start_parse_map_entry(a0)); })));
    auto p3 = expect_close(p2, Text::lit("{"));
    return prism_rtl::finished(std::tuple{crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::EMap{entries})), .span = to(start, parser::prev(p3))}, false, p3});
}


/// `Start MapPrimary, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::ast::Expr, bool, Ps>> start_map_primary(Ps p_) {
    return prism_rtl::make_rc<MapPrimary>(p_);
}


/// ParseMapEntry: unbounded fn Ps -> ((((Expr, Expr)), Ps))
std::tuple<std::tuple<crate::ast::Expr, crate::ast::Expr>, Ps> parse_map_entry(const Ps& p_) {
    auto [k, p1] = parse_arg_expr(p_);
    auto [v_, p2] = parse_arg_expr(expect_colon(p1));
    return std::tuple{std::tuple{k, v_}, p2};
}


prism_rtl::Turn<std::tuple<std::tuple<crate::ast::Expr, crate::ast::Expr>, Ps>> ParseMapEntry::cycle() const {
    const auto& p_ = this->p_;
    auto p__1 = p_;
    return call_then(start_parse_arg_expr(p__1), [=](std::tuple<crate::ast::Expr, Ps> parse_arg_expr_57033) {
        return ({
            auto [k, p1] = parse_arg_expr_57033;
            call_then(start_parse_arg_expr(expect_colon(p1)), [=](std::tuple<crate::ast::Expr, Ps> parse_arg_expr_57068) {
            return ({
                auto [v_, p2] = parse_arg_expr_57068;
                (prism_rtl::finished(std::tuple{std::tuple{k, v_}, p2}));
            });
        });
        });
    });
}


/// `Start ParseMapEntry, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<std::tuple<crate::ast::Expr, crate::ast::Expr>, Ps>> start_parse_map_entry(Ps p_) {
    return prism_rtl::make_rc<ParseMapEntry>(p_);
}


/// LensPrimary: unbounded fn Ps -> ((Expr, Bool, Ps))
std::tuple<crate::ast::Expr, bool, Ps> lens_primary(const Ps& p0) {
    auto start = here(p0);
    auto r = ({
        std::tuple<Array<crate::ast::Ident>, Ps> this_ = std::tuple{Array<crate::ast::Ident>{}, adv(p0)};
        Array<crate::ast::Ident> path_ = Array<crate::ast::Ident>{};
        Ps p_ = adv(p0);
        bool going = true;
        while (going && (!p_.bad)) {
            ({
                __label__ _done;
                prism_rtl::Slot<Unit> _v;
                auto&& _m = kind(p_);
                if (prism_rtl::is<crate::lexer::TokKind::KName>(_m)) {
                    auto&& n = prism_rtl::as<crate::lexer::TokKind::KName>(_m).a0;
                    if (((n.sigils == Text::lit("")) && (n.case_ == crate::lexer::NameCase(crate::lexer::NameCase::CaseLower{}))) && (len(n->path_) == Nat(1u))) {
                        _v.set(({
                            path_ = prelude::push(path_, crate::ast::Ident{.name = or_(index(n->path_, Nat(0u)), Text::lit("")), .span = here(p_)});
                            p_ = adv(p_);
                            if (kind(p_) == crate::lexer::TokKind(crate::lexer::TokKind::KDot{false})) {
                                p_ = adv(p_);
                            } else  {
                                going = false;
                            }
                            Unit{};
                        }));
                        goto _done;
                    }
                }
                {
                    _v.set(({
                        p_ = error_here(p_, Text::lit("expected a field name in a lens path"));
                        Unit{};
                    }));
                    goto _done;
                }
            _done:
                _v.take();
            });
        }
        this_ = std::tuple{path_, p_};
        this_;
    });
    auto [path_, q] = r;
    return std::tuple{crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::ELens{path_})), .span = to(start, parser::prev(q))}, false, q};
}


prism_rtl::Turn<std::tuple<crate::ast::Expr, bool, Ps>> LensPrimary::cycle() const {
    const auto& p0 = this->p0;
    auto start = here(p0);
    std::tuple<Array<crate::ast::Ident>, Ps> this_ = std::tuple{Array<crate::ast::Ident>{}, adv(p0)};
    Array<crate::ast::Ident> path_ = Array<crate::ast::Ident>{};
    Ps p_ = adv(p0);
    bool going = true;
    auto start_1 = start;
    return call_then(loop_job(std::tuple{this_, going, p_, path_}, [=](std::tuple<std::tuple<Array<crate::ast::Ident>, Ps>, bool, Ps, Array<crate::ast::Ident>> _p0) {
        auto this_ = std::get<0>(_p0);
        auto going = std::get<1>(_p0);
        auto p_ = std::get<2>(_p0);
        auto path_ = std::get<3>(_p0);
        return going && (!p_->bad)
            ? ({
            ({
                __label__ _done;
                prism_rtl::Slot<Unit> _v;
                auto&& _m = kind(p_);
                if (prism_rtl::is<crate::lexer::TokKind::KName>(_m)) {
                    auto&& n = prism_rtl::as<crate::lexer::TokKind::KName>(_m).a0;
                    if (((n.sigils == Text::lit("")) && (n.case_ == crate::lexer::NameCase(crate::lexer::NameCase::CaseLower{}))) && (len(n->path_) == Nat(1u))) {
                        _v.set(({
                            path_ = prelude::push(path_, crate::ast::Ident{.name = or_(index(n->path_, Nat(0u)), Text::lit("")), .span = here(p_)});
                            p_ = adv(p_);
                            if (kind(p_) == crate::lexer::TokKind(crate::lexer::TokKind::KDot{false})) {
                                p_ = adv(p_);
                            } else  {
                                going = false;
                            }
                            Unit{};
                        }));
                        goto _done;
                    }
                }
                {
                    _v.set(({
                        p_ = error_here(p_, Text::lit("expected a field name in a lens path"));
                        Unit{};
                    }));
                    goto _done;
                }
            _done:
                _v.take();
            });
            Expected<std::tuple<std::tuple<Array<crate::ast::Ident>, Ps>, bool, Ps, Array<crate::ast::Ident>>, std::tuple<std::tuple<Array<crate::ast::Ident>, Ps>, bool, Ps, Array<crate::ast::Ident>>>(std::tuple{this_, going, p_, path_});
        })
            : Expected<std::tuple<std::tuple<Array<crate::ast::Ident>, Ps>, bool, Ps, Array<crate::ast::Ident>>, std::tuple<std::tuple<Array<crate::ast::Ident>, Ps>, bool, Ps, Array<crate::ast::Ident>>>(unexpected(std::tuple{this_, going, p_, path_}));
    }), [=](std::tuple<std::tuple<Array<crate::ast::Ident>, Ps>, bool, Ps, Array<crate::ast::Ident>> _p0) {
        auto this_ = std::get<0>(_p0);
        auto going = std::get<1>(_p0);
        auto p_ = std::get<2>(_p0);
        auto path_ = std::get<3>(_p0);
        return ({
            this_ = std::tuple{path_, p_};
            auto r = this_;
            auto [path_, q] = r;
            (prism_rtl::finished(std::tuple{crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::ELens{path_})), .span = to(start_1, parser::prev(q))}, false, q}));
        });
    });
}


/// `Start LensPrimary, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::ast::Expr, bool, Ps>> start_lens_primary(Ps p0) {
    return prism_rtl::make_rc<LensPrimary>(p0);
}


/// KeywordPrimary: unbounded fn Ps, Text, Text, Bool -> ((Expr, Bool, Ps))
std::tuple<crate::ast::Expr, bool, Ps> keyword_primary(const Ps& p_, const Text& w, const Text& sigils, const bool& commas_) {
    auto start = here(p_);
    {
        auto&& m58193_0 = w;
        if (m58193_0 == Text::lit("unit")) {
            return std::tuple{crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::EUnit{sigils})), .span = start}, false, adv(p_)};
        }
    }
    {
        auto&& m58193_1 = w;
        if (m58193_1 == Text::lit("nil")) {
            return std::tuple{crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::ENil{sigils})), .span = start}, false, adv(p_)};
        }
    }
    {
        if (crate::lexer::is_bound_word(w)) {
            return std::tuple{crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::EBound{w})), .span = start}, false, adv(p_)};
        }
    }
    {
        auto&& m58193_3 = w;
        if (m58193_3 == Text::lit("if")) {
            return took(parse_if(p_));
        }
    }
    {
        auto&& m58193_4 = w;
        if (m58193_4 == Text::lit("match")) {
            return took(parse_match(p_));
        }
    }
    {
        auto&& m58193_5 = w;
        if (m58193_5 == Text::lit("rebuild")) {
            auto [scrutinee, p1] = parse_expr(adv(p_));
            auto [body, p2] = parse_block_after_colon(p1);
            return std::tuple{crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::ERebuild{prism_rtl::rc(scrutinee), body})), .span = to(start, body.span)}, true, p2};
        }
    }
    {
        auto&& m58193_6 = w;
        if (m58193_6 == Text::lit("for")) {
            return took(parse_for(p_));
        }
    }
    {
        auto&& m58193_7 = w;
        if (m58193_7 == Text::lit("given")) {
            auto [body, q] = parse_block_after_colon(adv(p_));
            return std::tuple{crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::EGiven{body})), .span = to(start, body.span)}, true, q};
        }
    }
    {
        auto&& m58193_8 = w;
        if (m58193_8 == Text::lit("update")) {
            auto [target, p1] = parse_expr(adv(p_));
            auto [body, p2] = parse_block_after_colon(p1);
            return std::tuple{crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::EUpdate{prism_rtl::rc(target), body})), .span = to(start, body.span)}, true, p2};
        }
    }
    {
        auto&& m58193_9 = w;
        if (m58193_9 == Text::lit("widget")) {
            auto [body, q] = parse_block_after_colon(adv(p_));
            return std::tuple{crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::EWidgetBlock{body})), .span = to(start, body.span)}, true, q};
        }
    }
    {
        auto&& m58193_10 = w;
        if (m58193_10 == Text::lit("any")) {
            auto [operand, q] = parse_expr_ctx(adv(p_), commas_);
            return std::tuple{crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::EAny{prism_rtl::rc(operand)})), .span = to(start, operand.span)}, true, q};
        }
    }
    {
        auto&& m58193_11 = w;
        if (m58193_11 == Text::lit("not")) {
            auto [e, q] = parse_binary(p_, Nat(8u), commas_);
            return std::tuple{e, true, q};
        }
    }
    {
        if (((w == Text::lit("output")) || (w == Text::lit("inline_text"))) || (w == Text::lit("raw"))) {
            auto p1 = adv(p_);
            auto&& _m = kind(p1);
            if (prism_rtl::is<crate::lexer::TokKind::KTemplate>(_m)) {
                auto&& t = prism_rtl::as<crate::lexer::TokKind::KTemplate>(_m).a0;
                auto tspan = here(p1);
                auto [tpl, q] = parse_template(adv(p1), t, tspan);
                return std::tuple{crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::ETemplate{tpl})), .span = to(start, tspan)}, false, q};
            }
            {
                return std::tuple{no_expr(), false, fail(p1)};
            }
        }
    }
    {
        auto&& m58193_13 = w;
        if (m58193_13 == Text::lit("then")) {
            return std::tuple{no_expr(), false, error_at(p_, start, Text::lit("`then` belongs to a hold: `$x <- start then step`"))};
        }
    }
    {
        auto&& m58193_14 = w;
        if (m58193_14 == Text::lit("else")) {
            return std::tuple{no_expr(), false, error_at(p_, start, Text::lit("`else` without its `if`"))};
        }
    }
    {
        auto&& m58193_15 = w;
        if (m58193_15 == Text::lit("ignore")) {
            return std::tuple{no_expr(), false, error_at(p_, start, Text::lit("`ignore` stands only inside a pattern or as the left side of a bind"))};
        }
    }
    {
        auto&& m58193_16 = w;
        if (m58193_16 == Text::lit("return")) {
            return std::tuple{no_expr(), false, error_at(p_, start, Text::lit("`return` ends a monad block, as its last statement"))};
        }
    }
    {
        return std::tuple{no_expr(), false, error_here(p_, Text::lit("expected an expression"))};
    }
}


prism_rtl::Turn<std::tuple<crate::ast::Expr, bool, Ps>> KeywordPrimary::cycle() const {
    const auto& p_ = this->p_;
    const auto& w = this->w;
    const auto& sigils = this->sigils;
    const auto& commas_ = this->commas_;
    auto start = here(p_);
    return ({
        ({
        auto&& m58193_0 = w;
        (m58193_0 == Text::lit("unit"));
    }) ? ({
        auto&& m58193_0 = w;
        prism_rtl::finished(std::tuple{crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::EUnit{sigils})), .span = start}, false, adv(p_)});
    })
        : ({
        auto&& m58193_1 = w;
        (m58193_1 == Text::lit("nil"));
    }) ? ({
        auto&& m58193_1 = w;
        prism_rtl::finished(std::tuple{crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::ENil{sigils})), .span = start}, false, adv(p_)});
    })
        : ({
        crate::lexer::is_bound_word(w);
    }) ? prism_rtl::finished(std::tuple{crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::EBound{w})), .span = start}, false, adv(p_)})
        : ({
        auto&& m58193_3 = w;
        (m58193_3 == Text::lit("if"));
    }) ? ({
        auto&& m58193_3 = w;
        ({
        auto p__1 = p_;
        call_then(start_parse_if(p__1), [=](std::tuple<crate::ast::Expr, Ps> parse_if_58455) { return prism_rtl::finished(took(parse_if_58455)); });
    });
    })
        : ({
        auto&& m58193_4 = w;
        (m58193_4 == Text::lit("match"));
    }) ? ({
        auto&& m58193_4 = w;
        ({
        auto p__1 = p_;
        call_then(start_parse_match(p__1), [=](std::tuple<crate::ast::Expr, Ps> parse_match_58489) { return prism_rtl::finished(took(parse_match_58489)); });
    });
    })
        : ({
        auto&& m58193_5 = w;
        (m58193_5 == Text::lit("rebuild"));
    }) ? ({
        auto&& m58193_5 = w;
        ({
        auto p__1 = p_;
        call_then(start_parse_expr(adv(p__1)), [=](std::tuple<crate::ast::Expr, Ps> parse_expr_58558) {
        return ({
            auto [scrutinee, p1] = parse_expr_58558;
            call_then(start_parse_block_after_colon(p1), [=](std::tuple<crate::ast::Block, Ps> parse_block_after_colon_58607) {
            return ({
                auto [body, p2] = parse_block_after_colon_58607;
                (prism_rtl::finished(std::tuple{crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::ERebuild{prism_rtl::rc(scrutinee), body})), .span = to(start, body.span)}, true, p2}));
            });
        });
        });
    });
    });
    })
        : ({
        auto&& m58193_6 = w;
        (m58193_6 == Text::lit("for"));
    }) ? ({
        auto&& m58193_6 = w;
        ({
        auto p__1 = p_;
        call_then(start_parse_for(p__1), [=](std::tuple<crate::ast::Expr, Ps> parse_for_58744) { return prism_rtl::finished(took(parse_for_58744)); });
    });
    })
        : ({
        auto&& m58193_7 = w;
        (m58193_7 == Text::lit("given"));
    }) ? ({
        auto&& m58193_7 = w;
        ({
        auto p__1 = p_;
        call_then(start_parse_block_after_colon(adv(p__1)), [=](std::tuple<crate::ast::Block, Ps> parse_block_after_colon_58803) {
        return ({
            auto [body, q] = parse_block_after_colon_58803;
            (prism_rtl::finished(std::tuple{crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::EGiven{body})), .span = to(start, body.span)}, true, q}));
        });
    });
    });
    })
        : ({
        auto&& m58193_8 = w;
        (m58193_8 == Text::lit("update"));
    }) ? ({
        auto&& m58193_8 = w;
        ({
        auto p__1 = p_;
        call_then(start_parse_expr(adv(p__1)), [=](std::tuple<crate::ast::Expr, Ps> parse_expr_58961) {
        return ({
            auto [target, p1] = parse_expr_58961;
            call_then(start_parse_block_after_colon(p1), [=](std::tuple<crate::ast::Block, Ps> parse_block_after_colon_59010) {
            return ({
                auto [body, p2] = parse_block_after_colon_59010;
                (prism_rtl::finished(std::tuple{crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::EUpdate{prism_rtl::rc(target), body})), .span = to(start, body.span)}, true, p2}));
            });
        });
        });
    });
    });
    })
        : ({
        auto&& m58193_9 = w;
        (m58193_9 == Text::lit("widget"));
    }) ? ({
        auto&& m58193_9 = w;
        ({
        auto p__1 = p_;
        call_then(start_parse_block_after_colon(adv(p__1)), [=](std::tuple<crate::ast::Block, Ps> parse_block_after_colon_59223) {
        return ({
            auto [body, q] = parse_block_after_colon_59223;
            (prism_rtl::finished(std::tuple{crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::EWidgetBlock{body})), .span = to(start, body.span)}, true, q}));
        });
    });
    });
    })
        : ({
        auto&& m58193_10 = w;
        (m58193_10 == Text::lit("any"));
    }) ? ({
        auto&& m58193_10 = w;
        ({
        auto commas__1 = commas_;
        auto p__2 = p_;
        call_then(start_parse_expr_ctx(adv(p__2), commas__1), [=](std::tuple<crate::ast::Expr, Ps> parse_expr_ctx_59384) {
        return ({
            auto [operand, q] = parse_expr_ctx_59384;
            (prism_rtl::finished(std::tuple{crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::EAny{prism_rtl::rc(operand)})), .span = to(start, operand.span)}, true, q}));
        });
    });
    });
    })
        : ({
        auto&& m58193_11 = w;
        (m58193_11 == Text::lit("not"));
    }) ? ({
        auto&& m58193_11 = w;
        ({
        auto commas__1 = commas_;
        auto p__2 = p_;
        call_then(start_parse_binary(p__2, Nat(8u), commas__1), [=](std::tuple<crate::ast::Expr, Ps> parse_binary_59537) {
        return ({
            auto [e, q] = parse_binary_59537;
            (prism_rtl::finished(std::tuple{e, true, q}));
        });
    });
    });
    })
        : ({
        (((w == Text::lit("output")) || (w == Text::lit("inline_text"))) || (w == Text::lit("raw")));
    }) ? ({
        auto p1 = adv(p_);
        ({
        auto&& _m = kind(p1);
        prism_rtl::is<crate::lexer::TokKind::KTemplate>(_m) ? ({
        auto&& t = prism_rtl::as<crate::lexer::TokKind::KTemplate>(_m).a0;
        ({
        auto tspan = here(p1);
        call_then(start_parse_template(adv(p1), t, tspan), [=](std::tuple<crate::ast::Template, Ps> parse_template_59897) {
        return ({
            auto [tpl, q] = parse_template_59897;
            (prism_rtl::finished(std::tuple{crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::ETemplate{tpl})), .span = to(start, tspan)}, false, q}));
        });
    });
    });
    })
        : prism_rtl::finished(std::tuple{no_expr(), false, fail(p1)});
    });
    })
        : ({
        auto&& m58193_13 = w;
        (m58193_13 == Text::lit("then"));
    }) ? ({
        auto&& m58193_13 = w;
        prism_rtl::finished(std::tuple{no_expr(), false, error_at(p_, start, Text::lit("`then` belongs to a hold: `$x <- start then step`"))});
    })
        : ({
        auto&& m58193_14 = w;
        (m58193_14 == Text::lit("else"));
    }) ? ({
        auto&& m58193_14 = w;
        prism_rtl::finished(std::tuple{no_expr(), false, error_at(p_, start, Text::lit("`else` without its `if`"))});
    })
        : ({
        auto&& m58193_15 = w;
        (m58193_15 == Text::lit("ignore"));
    }) ? ({
        auto&& m58193_15 = w;
        prism_rtl::finished(std::tuple{no_expr(), false, error_at(p_, start, Text::lit("`ignore` stands only inside a pattern or as the left side of a bind"))});
    })
        : ({
        auto&& m58193_16 = w;
        (m58193_16 == Text::lit("return"));
    }) ? ({
        auto&& m58193_16 = w;
        prism_rtl::finished(std::tuple{no_expr(), false, error_at(p_, start, Text::lit("`return` ends a monad block, as its last statement"))});
    })
        : prism_rtl::finished(std::tuple{no_expr(), false, error_here(p_, Text::lit("expected an expression"))});
    });
}


/// `Start KeywordPrimary, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::ast::Expr, bool, Ps>> start_keyword_primary(Ps p_, Text w, Text sigils, bool commas_) {
    return prism_rtl::make_rc<KeywordPrimary>(p_, w, sigils, commas_);
}


/// Took: fn ((Expr, Ps)) -> ((Expr, Bool, Ps))
std::tuple<crate::ast::Expr, bool, Ps> took(const std::tuple<crate::ast::Expr, Ps>& arg0) {
    {
        auto&& e = std::get<0>(arg0);
        auto&& p_ = std::get<1>(arg0);
        return std::tuple{e, true, p_};
    }
    prism_rtl::unreachable("no arm matched");
}


/// ParseLiteral: unbounded fn Ps -> ((Literal, Ps))
std::tuple<crate::ast::Literal, Ps> parse_literal(const Ps& p_) {
    auto span = here(p_);
    auto p1 = adv(p_);
    auto&& _m = kind(p_);
    if (prism_rtl::is<crate::lexer::TokKind::KInt>(_m)) {
        auto&& s = prism_rtl::as<crate::lexer::TokKind::KInt>(_m).a0;
        auto&& t = prism_rtl::as<crate::lexer::TokKind::KInt>(_m).a1;
        return std::tuple{crate::ast::Literal{.marks = s, .kind = crate::ast::LitKind(crate::ast::LitKind::LInt{t}), .span = span}, p1};
    }
    if (prism_rtl::is<crate::lexer::TokKind::KFloat>(_m)) {
        auto&& s = prism_rtl::as<crate::lexer::TokKind::KFloat>(_m).a0;
        auto&& t = prism_rtl::as<crate::lexer::TokKind::KFloat>(_m).a1;
        return std::tuple{crate::ast::Literal{.marks = s, .kind = crate::ast::LitKind(crate::ast::LitKind::LFloat{t}), .span = span}, p1};
    }
    if (prism_rtl::is<crate::lexer::TokKind::KDuration>(_m)) {
        auto&& s = prism_rtl::as<crate::lexer::TokKind::KDuration>(_m).a0;
        auto&& n = prism_rtl::as<crate::lexer::TokKind::KDuration>(_m).a1;
        auto&& u = prism_rtl::as<crate::lexer::TokKind::KDuration>(_m).a2;
        return std::tuple{crate::ast::Literal{.marks = s, .kind = crate::ast::LitKind(crate::ast::LitKind::LDuration{n, u}), .span = span}, p1};
    }
    if (prism_rtl::is<crate::lexer::TokKind::KChar>(_m)) {
        auto&& s = prism_rtl::as<crate::lexer::TokKind::KChar>(_m).a0;
        auto&& c = prism_rtl::as<crate::lexer::TokKind::KChar>(_m).a1;
        return std::tuple{crate::ast::Literal{.marks = s, .kind = crate::ast::LitKind(crate::ast::LitKind::LChar{c}), .span = span}, p1};
    }
    if (prism_rtl::is<crate::lexer::TokKind::KText>(_m)) {
        auto&& s = prism_rtl::as<crate::lexer::TokKind::KText>(_m).a0;
        auto&& segs = prism_rtl::as<crate::lexer::TokKind::KText>(_m).a1;
        auto [out, q] = run_to_end(fold_job(segs, std::tuple{Array<crate::ast::TextSeg>{}, p1}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::ast::TextSeg>, Ps>>(std::tuple<std::tuple<Array<crate::ast::TextSeg>, Ps>, crate::lexer::TextSegTok>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<crate::ast::TextSeg>, Ps>, crate::lexer::TextSegTok> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto [acc, pp] = p0;
                    auto seg = p1;
                    (prism_rtl::more(prism_rtl::rc(TextSegment(acc, pp, seg))));
                });
            }));
        }))));
        return std::tuple{crate::ast::Literal{.marks = s, .kind = crate::ast::LitKind(crate::ast::LitKind::LText{out}), .span = span}, q};
    }
    {
        return std::tuple{crate::ast::Literal{.marks = Text::lit(""), .kind = crate::ast::LitKind(crate::ast::LitKind::LInt{Text::lit("")}), .span = span}, error_at(p1, span, Text::lit("expected a literal"))};
    }
}


prism_rtl::Turn<std::tuple<crate::ast::Literal, Ps>> ParseLiteral::cycle() const {
    const auto& p_ = this->p_;
    auto span = here(p_);
    auto p1 = adv(p_);
    return ({
        auto&& _m = kind(p_);
        prism_rtl::is<crate::lexer::TokKind::KInt>(_m) ? ({
        auto&& s = prism_rtl::as<crate::lexer::TokKind::KInt>(_m).a0;
        auto&& t = prism_rtl::as<crate::lexer::TokKind::KInt>(_m).a1;
        prism_rtl::finished(std::tuple{crate::ast::Literal{.marks = s, .kind = crate::ast::LitKind(crate::ast::LitKind::LInt{t}), .span = span}, p1});
    })
        : prism_rtl::is<crate::lexer::TokKind::KFloat>(_m) ? ({
        auto&& s = prism_rtl::as<crate::lexer::TokKind::KFloat>(_m).a0;
        auto&& t = prism_rtl::as<crate::lexer::TokKind::KFloat>(_m).a1;
        prism_rtl::finished(std::tuple{crate::ast::Literal{.marks = s, .kind = crate::ast::LitKind(crate::ast::LitKind::LFloat{t}), .span = span}, p1});
    })
        : prism_rtl::is<crate::lexer::TokKind::KDuration>(_m) ? ({
        auto&& s = prism_rtl::as<crate::lexer::TokKind::KDuration>(_m).a0;
        auto&& n = prism_rtl::as<crate::lexer::TokKind::KDuration>(_m).a1;
        auto&& u = prism_rtl::as<crate::lexer::TokKind::KDuration>(_m).a2;
        prism_rtl::finished(std::tuple{crate::ast::Literal{.marks = s, .kind = crate::ast::LitKind(crate::ast::LitKind::LDuration{n, u}), .span = span}, p1});
    })
        : prism_rtl::is<crate::lexer::TokKind::KChar>(_m) ? ({
        auto&& s = prism_rtl::as<crate::lexer::TokKind::KChar>(_m).a0;
        auto&& c = prism_rtl::as<crate::lexer::TokKind::KChar>(_m).a1;
        prism_rtl::finished(std::tuple{crate::ast::Literal{.marks = s, .kind = crate::ast::LitKind(crate::ast::LitKind::LChar{c}), .span = span}, p1});
    })
        : prism_rtl::is<crate::lexer::TokKind::KText>(_m) ? ({
        auto&& s = prism_rtl::as<crate::lexer::TokKind::KText>(_m).a0;
        auto&& segs = prism_rtl::as<crate::lexer::TokKind::KText>(_m).a1;
        call_value(fold_job(segs, std::tuple{Array<crate::ast::TextSeg>{}, p1}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::ast::TextSeg>, Ps>>(std::tuple<std::tuple<Array<crate::ast::TextSeg>, Ps>, crate::lexer::TextSegTok>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<crate::ast::TextSeg>, Ps>, crate::lexer::TextSegTok> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto [acc, pp] = p0;
                auto seg = p1;
                (prism_rtl::more(prism_rtl::rc(TextSegment(acc, pp, seg))));
            });
        }));
    }))), [=](std::tuple<Array<crate::ast::TextSeg>, Ps> fold_61211) {
        return ({
            auto [out, q] = fold_61211;
            (prism_rtl::finished(std::tuple{crate::ast::Literal{.marks = s, .kind = crate::ast::LitKind(crate::ast::LitKind::LText{out}), .span = span}, q}));
        });
    });
    })
        : prism_rtl::finished(std::tuple{crate::ast::Literal{.marks = Text::lit(""), .kind = crate::ast::LitKind(crate::ast::LitKind::LInt{Text::lit("")}), .span = span}, error_at(p1, span, Text::lit("expected a literal"))});
    });
}


/// `Start ParseLiteral, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::ast::Literal, Ps>> start_parse_literal(Ps p_) {
    return prism_rtl::make_rc<ParseLiteral>(p_);
}


/// TextSegment: unbounded fn [TextSeg], Ps, TextSegTok -> (([TextSeg], Ps))
std::tuple<Array<crate::ast::TextSeg>, Ps> text_segment(const Array<crate::ast::TextSeg>& acc, const Ps& p_, const crate::lexer::TextSegTok& text_seg_tok2) {
    if (prism_rtl::is<crate::lexer::TextSegTok::TsPlain>(text_seg_tok2)) {
        auto&& s = prism_rtl::as<crate::lexer::TextSegTok::TsPlain>(text_seg_tok2).a0;
        return std::tuple{prelude::push(acc, crate::ast::TextSeg(crate::ast::TextSeg::SegPlain{s})), p_};
    }
    if (prism_rtl::is<crate::lexer::TextSegTok::TsPlaceholder>(text_seg_tok2)) {
        auto&& toks = prism_rtl::as<crate::lexer::TextSegTok::TsPlaceholder>(text_seg_tok2).a0;
        auto&& span = prism_rtl::as<crate::lexer::TextSegTok::TsPlaceholder>(text_seg_tok2).a1;
        auto [e, q] = parse_nested(p_, toks, span);
        return std::tuple{prelude::push(acc, crate::ast::TextSeg(crate::ast::TextSeg::SegPlaceholder{e})), q};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<Array<crate::ast::TextSeg>, Ps>> TextSegment::cycle() const {
    const auto& acc = this->acc;
    const auto& p_ = this->p_;
    const auto& text_seg_tok2 = this->text_seg_tok2;
    return ({
        prism_rtl::is<crate::lexer::TextSegTok::TsPlain>(text_seg_tok2) ? ({
        auto&& s = prism_rtl::as<crate::lexer::TextSegTok::TsPlain>(text_seg_tok2).a0;
        prism_rtl::finished(std::tuple{prelude::push(acc, crate::ast::TextSeg(crate::ast::TextSeg::SegPlain{s})), p_});
    })
        : prism_rtl::is<crate::lexer::TextSegTok::TsPlaceholder>(text_seg_tok2) ? ({
        auto&& toks = prism_rtl::as<crate::lexer::TextSegTok::TsPlaceholder>(text_seg_tok2).a0;
        auto&& span = prism_rtl::as<crate::lexer::TextSegTok::TsPlaceholder>(text_seg_tok2).a1;
        ({
        auto acc_1 = acc;
        auto p__2 = p_;
        auto span_3 = span;
        auto toks_4 = toks;
        call_then(start_parse_nested(p__2, toks_4, span_3), [=](std::tuple<crate::ast::Expr, Ps> parse_nested_61669) {
        return ({
            auto [e, q] = parse_nested_61669;
            (prism_rtl::finished(std::tuple{prelude::push(acc_1, crate::ast::TextSeg(crate::ast::TextSeg::SegPlaceholder{e})), q}));
        });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start TextSegment, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::ast::TextSeg>, Ps>> start_text_segment(Array<crate::ast::TextSeg> acc, Ps p_, crate::lexer::TextSegTok text_seg_tok2) {
    return prism_rtl::make_rc<TextSegment>(acc, p_, text_seg_tok2);
}


/// ParseNested: unbounded fn Ps, [Tok], Range -> ((Expr, Ps))
std::tuple<crate::ast::Expr, Ps> parse_nested(const Ps& p_, const Array<crate::lexer::Tok>& toks, const crate::ast::Range& span) {
    auto sub_ = with_step_mode(sub(p_, toks, at_end(span)), false);
    auto [e, s1] = parse_rhs_expr(sub_);
    auto s2 = (!s1->bad) && (!at_eof(s1))
        ? note_error(s1, here(s1), prism_rtl::cat("expected the end of the placeholder, found ", describe(kind(s1))))
        : s1;
    auto s3 = s2->bad && (len(s2.diags) == Nat(0u))
        ? note_error(unbad(s2), span, Text::lit("expected an expression in the placeholder"))
        : s2;
    auto q = absorb(p_, s3);
    return s1->bad
        ? std::tuple{crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::EError{})), .span = span}, q}
        : std::tuple{e, q};
}


prism_rtl::Turn<std::tuple<crate::ast::Expr, Ps>> ParseNested::cycle() const {
    const auto& p_ = this->p_;
    const auto& toks = this->toks;
    const auto& span = this->span;
    auto p__1 = p_;
    auto span_2 = span;
    auto toks_3 = toks;
    return call_then(start_sub(p__1, toks_3, at_end(span_2)), [=](Ps sub_61992) {
        return ({
            auto sub_ = with_step_mode(sub_61992, false);
            call_then(start_parse_rhs_expr(sub_), [=](std::tuple<crate::ast::Expr, Ps> parse_rhs_expr_62046) {
            return ({
                auto [e, s1] = parse_rhs_expr_62046;
                auto s2 = (!s1->bad) && (!at_eof(s1))
                    ? note_error(s1, here(s1), prism_rtl::cat("expected the end of the placeholder, found ", describe(kind(s1))))
                    : s1;
                auto s3 = s2->bad && (len(s2.diags) == Nat(0u))
                    ? note_error(unbad(s2), span_2, Text::lit("expected an expression in the placeholder"))
                    : s2;
                auto q = absorb(p__1, s3);
                s1->bad
                ? prism_rtl::finished(std::tuple{crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::EError{})), .span = span_2}, q})
                : prism_rtl::finished(std::tuple{e, q});
            });
        });
        });
    });
}


/// `Start ParseNested, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::ast::Expr, Ps>> start_parse_nested(Ps p_, Array<crate::lexer::Tok> toks, crate::ast::Range span) {
    return prism_rtl::make_rc<ParseNested>(p_, toks, span);
}


/// ParseTemplate: unbounded fn Ps, TemplateTok, Range -> ((Template, Ps))
std::tuple<crate::ast::Template, Ps> parse_template(const Ps& p0, const crate::lexer::TemplateTok& t, const crate::ast::Range& span) {
    auto p1 = (t.delims == Text::lit("single")) && (t.keyword != Text::lit("Raw"))
        ? out_of_scope(p0, span, Text::lit("the template notation"), prism_rtl::cat("a `<", t.lang, ">` template is the template notation for an element language, out of this compiler (code templates only)"))
        : p0;
    auto p2 = t.keyword == Text::lit("File")
        ? out_of_scope(p1, span, Text::lit("the template notation"), Text::lit("a file whose first token is a language tag is a template file, out of this compiler (code templates only)"))
        : p1;
    auto [parts, p3] = template_parts(p2, t.parts);
    return std::tuple{crate::ast::Template{.keyword = t.keyword, .lang = t.lang, .delims = t.delims, .parts = parts, .span = span}, p3};
}


prism_rtl::Turn<std::tuple<crate::ast::Template, Ps>> ParseTemplate::cycle() const {
    const auto& p0 = this->p0;
    const auto& t = this->t;
    const auto& span = this->span;
    auto p1 = (t.delims == Text::lit("single")) && (t.keyword != Text::lit("Raw"))
        ? out_of_scope(p0, span, Text::lit("the template notation"), prism_rtl::cat("a `<", t.lang, ">` template is the template notation for an element language, out of this compiler (code templates only)"))
        : p0;
    auto p2 = t.keyword == Text::lit("File")
        ? out_of_scope(p1, span, Text::lit("the template notation"), Text::lit("a file whose first token is a language tag is a template file, out of this compiler (code templates only)"))
        : p1;
    auto span_1 = span;
    auto t_2 = t;
    return call_then(start_template_parts(p2, t_2.parts), [=](std::tuple<Array<crate::ast::TemplatePart>, Ps> template_parts_63041) {
        return ({
            auto [parts, p3] = template_parts_63041;
            (prism_rtl::finished(std::tuple{crate::ast::Template{.keyword = t_2.keyword, .lang = t_2.lang, .delims = t_2.delims, .parts = parts, .span = span_1}, p3}));
        });
    });
}


/// `Start ParseTemplate, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::ast::Template, Ps>> start_parse_template(Ps p0, crate::lexer::TemplateTok t, crate::ast::Range span) {
    return prism_rtl::make_rc<ParseTemplate>(p0, t, span);
}


/// TemplateParts: unbounded fn Ps, [TPartTok] -> (([TemplatePart], Ps))
std::tuple<Array<crate::ast::TemplatePart>, Ps> template_parts(const Ps& p_, const Array<crate::lexer::TPartTok>& parts) {
    return run_to_end(fold_job(parts, std::tuple{Array<crate::ast::TemplatePart>{}, p_}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::ast::TemplatePart>, Ps>>(std::tuple<std::tuple<Array<crate::ast::TemplatePart>, Ps>, crate::lexer::TPartTok>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<crate::ast::TemplatePart>, Ps>, crate::lexer::TPartTok> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto [acc, q] = p0;
                auto part = p1;
                (prism_rtl::more(prism_rtl::rc(TemplatePartOf(acc, q, part))));
            });
        }));
    }))));
}


prism_rtl::Turn<std::tuple<Array<crate::ast::TemplatePart>, Ps>> TemplateParts::cycle() const {
    const auto& p_ = this->p_;
    const auto& parts = this->parts;
    return fold_job(parts, std::tuple{Array<crate::ast::TemplatePart>{}, p_}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::ast::TemplatePart>, Ps>>(std::tuple<std::tuple<Array<crate::ast::TemplatePart>, Ps>, crate::lexer::TPartTok>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<crate::ast::TemplatePart>, Ps>, crate::lexer::TPartTok> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto [acc, q] = p0;
                auto part = p1;
                (prism_rtl::more(prism_rtl::rc(TemplatePartOf(acc, q, part))));
            });
        }));
    })))->cycle();
}


/// `Start TemplateParts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::ast::TemplatePart>, Ps>> start_template_parts(Ps p_, Array<crate::lexer::TPartTok> parts) {
    return prism_rtl::make_rc<TemplateParts>(p_, parts);
}


/// TemplatePartOf: unbounded fn [TemplatePart], Ps, TPartTok -> (([TemplatePart], Ps))
std::tuple<Array<crate::ast::TemplatePart>, Ps> template_part_of(const Array<crate::ast::TemplatePart>& acc, const Ps& p_, const crate::lexer::TPartTok& tpart_tok2) {
    if (prism_rtl::is<crate::lexer::TPartTok::TptText>(tpart_tok2)) {
        auto&& s = prism_rtl::as<crate::lexer::TPartTok::TptText>(tpart_tok2).a0;
        return std::tuple{prelude::push(acc, crate::ast::TemplatePart(crate::ast::TemplatePart::TpText{s})), p_};
    }
    if (prism_rtl::is<crate::lexer::TPartTok::TptPlaceholder>(tpart_tok2)) {
        auto&& toks = prism_rtl::as<crate::lexer::TPartTok::TptPlaceholder>(tpart_tok2).a0;
        auto&& col_opt = prism_rtl::as<crate::lexer::TPartTok::TptPlaceholder>(tpart_tok2).a1;
        auto&& span = prism_rtl::as<crate::lexer::TPartTok::TptPlaceholder>(tpart_tok2).a2;
        auto [e, q] = parse_nested(p_, toks, span);
        return std::tuple{prelude::push(acc, crate::ast::TemplatePart(crate::ast::TemplatePart::TpPlaceholder{e, col_opt})), q};
    }
    if (prism_rtl::is<crate::lexer::TPartTok::TptBlock>(tpart_tok2)) {
        auto&& toks = prism_rtl::as<crate::lexer::TPartTok::TptBlock>(tpart_tok2).a0;
        auto&& span = prism_rtl::as<crate::lexer::TPartTok::TptBlock>(tpart_tok2).a1;
        auto sub_ = sub(p_, toks, at_end(span));
        auto [block, s1] = parse_block_until_eof(sub_, span);
        return std::tuple{prelude::push(acc, crate::ast::TemplatePart(crate::ast::TemplatePart::TpBlock{block})), absorb(p_, s1)};
    }
    if (prism_rtl::is<crate::lexer::TPartTok::TptCall>(tpart_tok2)) {
        auto&& name = prism_rtl::as<crate::lexer::TPartTok::TptCall>(tpart_tok2).a0;
        auto&& attrs = prism_rtl::as<crate::lexer::TPartTok::TptCall>(tpart_tok2).a1;
        auto&& body_opt = prism_rtl::as<crate::lexer::TPartTok::TptCall>(tpart_tok2).a2;
        auto&& span = prism_rtl::as<crate::lexer::TPartTok::TptCall>(tpart_tok2).a3;
        auto sname = crate::ast::SName{.sigils = name.sigils, .path_ = name->path_, .span = span};
        auto [args, p1] = run_to_end(fold_job(attrs, std::tuple{Array<crate::ast::Arg>{}, p_}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::ast::Arg>, Ps>>(std::tuple<std::tuple<Array<crate::ast::Arg>, Ps>, crate::lexer::AttrTok>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<crate::ast::Arg>, Ps>, crate::lexer::AttrTok> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto [done, q] = p0;
                    auto a = p1;
                    (prism_rtl::more(prism_rtl::rc(AttrArg(done, q, a))));
                });
            }));
        }))));
        auto [inner_opt, p2] = ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<std::optional<Array<crate::ast::TemplatePart>>, Ps>> _v;
            if (prism_rtl::is_some(body_opt)) {
                auto&& b = prism_rtl::some_of(body_opt);
                _v.set(({
                    auto [ps, q] = template_parts(p1, b);
                    std::tuple{std::optional(ps), q};
                }));
                goto _done;
            }
            if (prism_rtl::is_none(body_opt)) {
                _v.set(std::tuple{std::optional<Array<crate::ast::TemplatePart>>{}, p1});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        return std::tuple{prelude::push(acc, crate::ast::TemplatePart(crate::ast::TemplatePart::TpCall{sname, args, inner_opt, span})), p2};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<Array<crate::ast::TemplatePart>, Ps>> TemplatePartOf::cycle() const {
    const auto& acc = this->acc;
    const auto& p_ = this->p_;
    const auto& tpart_tok2 = this->tpart_tok2;
    return ({
        prism_rtl::is<crate::lexer::TPartTok::TptText>(tpart_tok2) ? ({
        auto&& s = prism_rtl::as<crate::lexer::TPartTok::TptText>(tpart_tok2).a0;
        prism_rtl::finished(std::tuple{prelude::push(acc, crate::ast::TemplatePart(crate::ast::TemplatePart::TpText{s})), p_});
    })
        : prism_rtl::is<crate::lexer::TPartTok::TptPlaceholder>(tpart_tok2) ? ({
        auto&& toks = prism_rtl::as<crate::lexer::TPartTok::TptPlaceholder>(tpart_tok2).a0;
        auto&& col_opt = prism_rtl::as<crate::lexer::TPartTok::TptPlaceholder>(tpart_tok2).a1;
        auto&& span = prism_rtl::as<crate::lexer::TPartTok::TptPlaceholder>(tpart_tok2).a2;
        ({
        auto col_opt_1 = col_opt;
        auto acc_2 = acc;
        auto p__3 = p_;
        auto span_4 = span;
        auto toks_5 = toks;
        call_then(start_parse_nested(p__3, toks_5, span_4), [=](std::tuple<crate::ast::Expr, Ps> parse_nested_63567) {
        return ({
            auto [e, q] = parse_nested_63567;
            (prism_rtl::finished(std::tuple{prelude::push(acc_2, crate::ast::TemplatePart(crate::ast::TemplatePart::TpPlaceholder{e, col_opt_1})), q}));
        });
    });
    });
    })
        : prism_rtl::is<crate::lexer::TPartTok::TptBlock>(tpart_tok2) ? ({
        auto&& toks = prism_rtl::as<crate::lexer::TPartTok::TptBlock>(tpart_tok2).a0;
        auto&& span = prism_rtl::as<crate::lexer::TPartTok::TptBlock>(tpart_tok2).a1;
        ({
        auto acc_1 = acc;
        auto p__2 = p_;
        auto span_3 = span;
        auto toks_4 = toks;
        call_then(start_sub(p__2, toks_4, at_end(span_3)), [=](Ps sub_63703) {
        return ({
            auto sub_ = sub_63703;
            call_then(start_parse_block_until_eof(sub_, span_3), [=](std::tuple<crate::ast::Block, Ps> parse_block_until_eof_63753) {
            return ({
                auto [block, s1] = parse_block_until_eof_63753;
                (prism_rtl::finished(std::tuple{prelude::push(acc_1, crate::ast::TemplatePart(crate::ast::TemplatePart::TpBlock{block})), absorb(p__2, s1)}));
            });
        });
        });
    });
    });
    })
        : prism_rtl::is<crate::lexer::TPartTok::TptCall>(tpart_tok2) ? ({
        auto&& name = prism_rtl::as<crate::lexer::TPartTok::TptCall>(tpart_tok2).a0;
        auto&& attrs = prism_rtl::as<crate::lexer::TPartTok::TptCall>(tpart_tok2).a1;
        auto&& body_opt = prism_rtl::as<crate::lexer::TPartTok::TptCall>(tpart_tok2).a2;
        auto&& span = prism_rtl::as<crate::lexer::TPartTok::TptCall>(tpart_tok2).a3;
        ({
        auto sname = crate::ast::SName{.sigils = name.sigils, .path_ = name->path_, .span = span};
        auto body_opt_1 = body_opt;
        auto acc_2 = acc;
        auto attrs_3 = attrs;
        auto p__4 = p_;
        auto span_5 = span;
        call_value(fold_job(attrs_3, std::tuple{Array<crate::ast::Arg>{}, p__4}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::ast::Arg>, Ps>>(std::tuple<std::tuple<Array<crate::ast::Arg>, Ps>, crate::lexer::AttrTok>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<crate::ast::Arg>, Ps>, crate::lexer::AttrTok> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto [done, q] = p0;
                auto a = p1;
                (prism_rtl::more(prism_rtl::rc(AttrArg(done, q, a))));
            });
        }));
    }))), [=](std::tuple<Array<crate::ast::Arg>, Ps> fold_63988) {
        return ({
            auto [args, p1] = fold_63988;
            auto [inner_opt, p2] = ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<std::optional<Array<crate::ast::TemplatePart>>, Ps>> _v;
                if (prism_rtl::is_some(body_opt)) {
                    auto&& b = prism_rtl::some_of(body_opt);
                    _v.set(({
                        auto [ps, q] = template_parts(p1, b);
                        std::tuple{std::optional(ps), q};
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(body_opt)) {
                    _v.set(std::tuple{std::optional<Array<crate::ast::TemplatePart>>{}, p1});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            (prism_rtl::finished(std::tuple{prelude::push(acc_2, crate::ast::TemplatePart(crate::ast::TemplatePart::TpCall{sname, args, inner_opt, span_5})), p2}));
        });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start TemplatePartOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::ast::TemplatePart>, Ps>> start_template_part_of(Array<crate::ast::TemplatePart> acc, Ps p_, crate::lexer::TPartTok tpart_tok2) {
    return prism_rtl::make_rc<TemplatePartOf>(acc, p_, tpart_tok2);
}


/// AttrArg: unbounded fn [Arg], Ps, AttrTok -> (([Arg], Ps))
std::tuple<Array<crate::ast::Arg>, Ps> attr_arg(const Array<crate::ast::Arg>& done, const Ps& p_, const crate::lexer::AttrTok& a) {
    auto [value, q] = parse_nested(p_, a->tokens, a.span);
    return std::tuple{prelude::push(done, crate::ast::Arg{.name = std::optional(crate::ast::Ident{.name = a.name, .span = a.span}), .value = value, .span = a.span}), q};
}


prism_rtl::Turn<std::tuple<Array<crate::ast::Arg>, Ps>> AttrArg::cycle() const {
    const auto& done = this->done;
    const auto& p_ = this->p_;
    const auto& a = this->a;
    auto a_1 = a;
    auto done_2 = done;
    auto p__3 = p_;
    return call_then(start_parse_nested(p__3, a_1->tokens, a_1.span), [=](std::tuple<crate::ast::Expr, Ps> parse_nested_64362) {
        return ({
            auto [value, q] = parse_nested_64362;
            (prism_rtl::finished(std::tuple{prelude::push(done_2, crate::ast::Arg{.name = std::optional(crate::ast::Ident{.name = a_1.name, .span = a_1.span}), .value = value, .span = a_1.span}), q}));
        });
    });
}


/// `Start AttrArg, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::ast::Arg>, Ps>> start_attr_arg(Array<crate::ast::Arg> done, Ps p_, crate::lexer::AttrTok a) {
    return prism_rtl::make_rc<AttrArg>(done, p_, a);
}


/// ParseLambda: unbounded fn Ps -> ((Expr, Ps))
std::tuple<crate::ast::Expr, Ps> parse_lambda(const Ps& p0) {
    auto start = here(p0);
    auto p_ = adv(p0);
    auto [params_opt, p1] = kind(p_) == crate::lexer::TokKind(crate::lexer::TokKind::KLambdaBar{true})
        ? lambda_params(adv(p_))
        : std::tuple{std::optional<Array<crate::ast::Pattern_>>{}, p_};
    return at_open_l(p1)
        ? ({
        auto [block, q] = parse_indented_block(p1);
        std::tuple{crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::ELambda{params_opt, prism_rtl::rc(crate::ast::LambdaBody(crate::ast::LambdaBody::LbBlock{block}))})), .span = to(start, block.span)}, q};
    })
        : ({
        auto [body, q] = parse_expr(p1);
        std::tuple{crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::ELambda{params_opt, prism_rtl::rc(crate::ast::LambdaBody(crate::ast::LambdaBody::LbExpr{prism_rtl::rc(body)}))})), .span = to(start, body.span)}, q};
    });
}


prism_rtl::Turn<std::tuple<crate::ast::Expr, Ps>> ParseLambda::cycle() const {
    const auto& p0 = this->p0;
    auto start = here(p0);
    auto p_ = adv(p0);
    auto [params_opt, p1] = kind(p_) == crate::lexer::TokKind(crate::lexer::TokKind::KLambdaBar{true})
        ? lambda_params(adv(p_))
        : std::tuple{std::optional<Array<crate::ast::Pattern_>>{}, p_};
    return at_open_l(p1)
        ? call_then(start_parse_indented_block(p1), [=](std::tuple<crate::ast::Block, Ps> parse_indented_block_64991) {
        return ({
            auto [block, q] = parse_indented_block_64991;
            (prism_rtl::finished(std::tuple{crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::ELambda{params_opt, prism_rtl::rc(crate::ast::LambdaBody(crate::ast::LambdaBody::LbBlock{block}))})), .span = to(start, block.span)}, q}));
        });
    })
        : call_then(start_parse_expr(p1), [=](std::tuple<crate::ast::Expr, Ps> parse_expr_65139) {
        return ({
            auto [body, q] = parse_expr_65139;
            (prism_rtl::finished(std::tuple{crate::ast::Expr{.kind = prism_rtl::rc(crate::ast::ExprKind(crate::ast::ExprKind::ELambda{params_opt, prism_rtl::rc(crate::ast::LambdaBody(crate::ast::LambdaBody::LbExpr{prism_rtl::rc(body)}))})), .span = to(start, body.span)}, q}));
        });
    });
}

}  // namespace crate::parser
