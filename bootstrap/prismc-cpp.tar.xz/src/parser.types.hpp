// The module `Parser`: its records, tags and newtypes (each after the types it holds) and its
// choices' cases, emitted by prismc (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include "parser.decl.hpp"
#include "elem.decl.hpp"
#include "lexer.decl.hpp"
#include "ast.types.hpp"

namespace crate {

using namespace prelude;

namespace parser {

/// `Pair`:
///
/// ```prism
/// type Pair = record:
/// ```
struct Pair {
    using prism_value = void;
    std::optional<Nat> partner;
    bool outer;
    bool inner;
    const Pair* operator->() const { return this; }
    Pair* operator->() { return this; }
    bool operator==(const Pair&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Pair> from_pod(const Pod& whole);
};


}  // namespace parser

namespace parser {

/// `Parsed`:
///
/// ```prism
/// type Parsed = record:
/// ```
struct Parsed {
    using prism_value = void;
    ast::Module tree;
    Array<ast::Diag> diags;
    const Parsed* operator->() const { return this; }
    Parsed* operator->() { return this; }
    bool operator==(const Parsed&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Parsed> from_pod(const Pod& whole);
};


}  // namespace parser

namespace parser {

/// `Ps`:
///
/// ```prism
/// type Ps = record:
/// ```
struct Ps {
    using prism_value = void;
    Array<lexer::Tok> toks;
    Array<Pair> pairs;
    Nat pos;
    Array<ast::Diag> diags;
    Array<ast::Diag> out;
    bool step_mode;
    bool in_trait;
    bool bad;
    const Ps* operator->() const { return this; }
    Ps* operator->() { return this; }
    bool operator==(const Ps&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Ps> from_pod(const Pod& whole);
};


}  // namespace parser

namespace parser {

/// `ArgsRead`:
///
/// ```prism
/// type ArgsRead = record:
/// ```
struct ArgsRead {
    using prism_value = void;
    Array<ast::Arg> args;
    bool rest;
    Ps p_;
    bool going;
    const ArgsRead* operator->() const { return this; }
    ArgsRead* operator->() { return this; }
    bool operator==(const ArgsRead&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<ArgsRead> from_pod(const Pod& whole);
};


}  // namespace parser

namespace parser {

/// `Climb`:
///
/// ```prism
/// type Climb = record:
/// ```
struct Climb {
    using prism_value = void;
    ast::Expr lhs;
    Ps p_;
    bool going;
    const Climb* operator->() const { return this; }
    Climb* operator->() { return this; }
    bool operator==(const Climb&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Climb> from_pod(const Pod& whole);
};


}  // namespace parser

namespace parser {

/// `FieldsRead`:
///
/// ```prism
/// type FieldsRead = record:
/// ```
struct FieldsRead {
    using prism_value = void;
    Array<ast::FieldPat> fields;
    bool rest;
    Ps p_;
    bool going;
    const FieldsRead* operator->() const { return this; }
    FieldsRead* operator->() { return this; }
    bool operator==(const FieldsRead&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<FieldsRead> from_pod(const Pod& whole);
};


}  // namespace parser

namespace parser {

/// `ModRead`:
///
/// ```prism
/// type ModRead = record:
/// ```
struct ModRead {
    using prism_value = void;
    Ps p_;
    ast::Module m;
    Nat stage;
    const ModRead* operator->() const { return this; }
    ModRead* operator->() { return this; }
    bool operator==(const ModRead&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<ModRead> from_pod(const Pod& whole);
};


}  // namespace parser


}  // namespace crate
