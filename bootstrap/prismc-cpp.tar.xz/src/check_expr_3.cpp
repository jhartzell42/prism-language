// The module `CheckExpr`, from `target/bootstrap/cpp-src/prismc/check-expr.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (docs/backend.md). Edit the Prism source, not this file.
#include "crate.hpp"

namespace crate::check_expr {

/// TemplateMissing: unbounded fn [Arg], St, [FnClause], Nat, Text, Range, Bool -> (([Arg], St))
std::tuple<Array<ast::Arg>, check_types::St> template_missing(const Array<ast::Arg>& acc, const check_types::St& st, const Array<ast::FnClause>& clauses, const Nat& j, const Text& cname, const ast::Range& span, const bool& quiet) {
    auto pname = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = index(clauses, Nat(0u));
        if (prism_rtl::is_some(_m)) {
            auto&& c = prism_rtl::some_of(_m);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                auto&& _m = index(c.params, j);
                if (prism_rtl::is_some(_m)) {
                    auto&& p_ = prism_rtl::some_of(_m);
                    _v.set(check_passes::param_name_of(p_));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(Text(""));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto st2 = quiet
        ? st
        : check_types::err(st, Text("mismatch"), span, prism_rtl::cat("`<@", cname, ">` needs `", pname, "=`"));
    return std::tuple{prelude::push(acc, ast::Arg{.name = std::optional<ast::Ident>{}, .value = ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EError{})), .span = span}, .span = span}), st2};
}


prism_rtl::Turn<std::tuple<Array<ast::Arg>, check_types::St>> TemplateMissing::cycle() const {
    const auto& acc = this->acc;
    const auto& st = this->st;
    const auto& clauses = this->clauses;
    const auto& j = this->j;
    const auto& cname = this->cname;
    const auto& span = this->span;
    const auto& quiet = this->quiet;
    auto pname = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = index(clauses, Nat(0u));
        if (prism_rtl::is_some(_m)) {
            auto&& c = prism_rtl::some_of(_m);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                auto&& _m = index(c.params, j);
                if (prism_rtl::is_some(_m)) {
                    auto&& p_ = prism_rtl::some_of(_m);
                    _v.set(check_passes::param_name_of(p_));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(Text(""));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto st2 = quiet
        ? st
        : check_types::err(st, Text("mismatch"), span, prism_rtl::cat("`<@", cname, ">` needs `", pname, "=`"));
    return prism_rtl::finished(std::tuple{prelude::push(acc, ast::Arg{.name = std::optional<ast::Ident>{}, .value = ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EError{})), .span = span}, .span = span}), st2});
}


/// `Start TemplateMissing, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<ast::Arg>, check_types::St>> start_template_missing(Array<ast::Arg> acc, check_types::St st, Array<ast::FnClause> clauses, Nat j, Text cname, ast::Range span, bool quiet) {
    return std::make_shared<TemplateMissing>(acc, st, clauses, j, cname, span, quiet);
}


/// ?TemplateSlot: unbounded fn [FnClause], Text -> ?Nat
std::optional<Nat> template_slot(const Array<ast::FnClause>& clauses, const Text& name) {
    auto found = run_to_end(fold_job(clauses, Array<Nat>{}, ({
        auto name_1 = name;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, ast::FnClause>)>>(prism_rtl::rc([=](std::tuple<Array<Nat>, ast::FnClause> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto name_1_2 = name_1;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto c = p1;
                fold_job(check_errors::range0(len(c.params)), acc, ({
                auto c_2 = c;
                auto name_1_2_3 = name_1_2;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, Nat>)>>(prism_rtl::rc([=](std::tuple<Array<Nat>, Nat> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto c_2_3 = c_2;
                    auto name_1_2_3_3 = name_1_2_3;
                    entered(once_job([=]() {
                    return ({
                        auto a2 = p0;
                        auto i = p1;
                        ({
                        auto&& _m = index(c_2_3.params, i);
                        prism_rtl::is_some(_m) ? ({
                        auto&& p_ = prism_rtl::some_of(_m);
                        check_passes::param_name_of(p_) == name_1_2_3_3
                        ? prism_rtl::finished(check_types::add_nat(a2, i))
                        : prism_rtl::finished(a2);
                    })
                        : prism_rtl::is_none(_m) ? prism_rtl::finished(a2)
                        : throw prism_rtl::Panic("no arm matched");
                    });
                    });
                }));
                });
            })));
            }))->cycle();
            });
        }));
        });
    })));
    })));
    return len(found) == Nat(1u) ? index(found, Nat(0u)) : std::optional<Nat>{};
}


prism_rtl::Turn<std::optional<Nat>> TemplateSlot::cycle() const {
    const auto& clauses = this->clauses;
    const auto& name = this->name;
    auto clauses_1 = clauses;
    auto name_2 = name;
    return call_value(fold_job(clauses_1, Array<Nat>{}, ({
        auto name_2_3 = name_2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, ast::FnClause>)>>(prism_rtl::rc([=](std::tuple<Array<Nat>, ast::FnClause> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto name_2_3_3 = name_2_3;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto c = p1;
                fold_job(check_errors::range0(len(c.params)), acc, ({
                auto c_3 = c;
                auto name_2_3_3_4 = name_2_3_3;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, Nat>)>>(prism_rtl::rc([=](std::tuple<Array<Nat>, Nat> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto c_3_4 = c_3;
                    auto name_2_3_3_4_4 = name_2_3_3_4;
                    entered(once_job([=]() {
                    return ({
                        auto a2 = p0;
                        auto i = p1;
                        ({
                        auto&& _m = index(c_3_4.params, i);
                        prism_rtl::is_some(_m) ? ({
                        auto&& p_ = prism_rtl::some_of(_m);
                        check_passes::param_name_of(p_) == name_2_3_3_4_4
                        ? prism_rtl::finished(check_types::add_nat(a2, i))
                        : prism_rtl::finished(a2);
                    })
                        : prism_rtl::is_none(_m) ? prism_rtl::finished(a2)
                        : throw prism_rtl::Panic("no arm matched");
                    });
                    });
                }));
                });
            })));
            }))->cycle();
            });
        }));
        });
    })));
    })), [=](Array<Nat> fold_90377) {
        return ({
            auto found = fold_90377;
            len(found) == Nat(1u)
            ? prism_rtl::finished(index(found, Nat(0u)))
            : prism_rtl::finished(std::optional<Nat>{});
        });
    });
}


/// `Start TemplateSlot, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<Nat>> start_template_slot(Array<ast::FnClause> clauses, Text name) {
    return std::make_shared<TemplateSlot>(clauses, name);
}

}  // namespace crate::check_expr
