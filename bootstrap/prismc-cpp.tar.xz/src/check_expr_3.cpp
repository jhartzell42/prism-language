// The module `CheckExpr`, from `target/bootstrap/cpp-src/prismc/check-expr.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (docs/backend.md). Edit the Prism source, not this file.
#include "check_expr.hpp"
#include "check_env.hpp"
#include "check_errors.hpp"
#include "check_types.hpp"
#include "ast.hpp"
#include "check_blocks.hpp"
#include "check_passes.hpp"
#include "lexer.hpp"
#include "typed.hpp"
#include "check_env.generic.hpp"
#include "lexer.generic.hpp"

namespace crate::check_expr {

prism_rtl::Turn<check_types::St> TemplateCallCheck::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& n = this->n;
    const auto& args = this->args;
    const auto& parts_opt = this->parts_opt;
    const auto& span = this->span;
    auto plain = ast::SName{.sigils = lexer::after_first(n.sigils), .path_ = n->path_, .span = n.span};
    auto&& _qk1_opt = check_env::resolve_value(env.g, env.home, n);
    auto&& qk1_opt = std::get<0>(_qk1_opt);
    auto callee = qk1_opt != std::optional<Text>{} ? n : plain;
    auto [qk_opt, ignore2] = check_env::resolve_value(env.g, env.home, callee);
    auto cname = check_env::sname_key(plain);
    return ({
        prism_rtl::is_none(qk_opt) ? ({
        auto env_1 = env;
        auto span_2 = span;
        auto st_3 = st;
        call_then(start_call_global(env_1, st_3, callee, Array<ast::Arg>{}, span_2, Array<check_types::Ty>{}, callee.span), [=](std::tuple<check_types::Ty, check_types::St> call_global_91675) {
        return ({
            auto [ignore3, st2] = call_global_91675;
            (prism_rtl::finished(st2));
        });
    });
    })
        : prism_rtl::is_some(qk_opt) ? ({
        auto&& qk = prism_rtl::some_of(qk_opt);
        ({
        auto clauses = ({
            __label__ _done;
            prism_rtl::Slot<Array<ast::FnClause>> _v;
            auto&& _m = prelude::get(env.g.fn_at, qk);
            if (prism_rtl::is_some(_m)) {
                auto&& i = prism_rtl::some_of(_m);
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Array<ast::FnClause>> _v;
                    auto&& _m = index(env.g.defs, i);
                    if (prism_rtl::is_some(_m)) {
                        auto&& d = prism_rtl::some_of(_m);
                        _v.set(({
                            __label__ _done;
                            prism_rtl::Slot<Array<ast::FnClause>> _v;
                            auto&& _m = d.body;
                            if (prism_rtl::is<check_env::DefBody::DbFn>(_m)) {
                                auto&& cs = prism_rtl::as<check_env::DefBody::DbFn>(_m).a0;
                                _v.set(cs);
                                goto _done;
                            }
                            {
                                _v.set(Array<ast::FnClause>{});
                                goto _done;
                            }
                        _done:
                            _v.take();
                        }));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(Array<ast::FnClause>{});
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(Array<ast::FnClause>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto arity = ({
            __label__ _done;
            prism_rtl::Slot<Nat> _v;
            auto&& _m = index(clauses, Nat(0u));
            if (prism_rtl::is_some(_m)) {
                auto&& c = prism_rtl::some_of(_m);
                _v.set(len(c.params));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(Nat(0u));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        len(clauses) == Nat(0u)
        ? prism_rtl::finished(check_types::err(st, Text("mismatch"), span, prism_rtl::cat("`<@", cname, ">` calls a function without clauses, which name no parameters for its attributes")))
        : ({
        auto parts_opt_1 = parts_opt;
        auto args_2 = args;
        auto env_3 = env;
        auto span_4 = span;
        auto st_5 = st;
        call_value(fold_job(args_2, std::tuple{Map<Text, ast::Expr>{}, st_5}, ({
        auto clauses_6 = clauses;
        auto cname_7 = cname;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Map<Text, ast::Expr>, check_types::St>>(std::tuple<std::tuple<Map<Text, ast::Expr>, check_types::St>, ast::Arg>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Map<Text, ast::Expr>, check_types::St>, ast::Arg> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto clauses_6_8 = clauses_6;
            auto cname_7_8 = cname_7;
            entered(once_job([=]() {
            return ({
                auto [m, s] = p0;
                auto a = p1;
                ({
                auto&& _m = a.name;
                prism_rtl::is_some(_m) ? ({
                auto&& id = prism_rtl::some_of(_m);
                ({
                auto id_8 = id;
                call_then(start_template_slot(clauses_6_8, id_8.name), [=](std::optional<Nat> template_slot_92417) {
                return ({
                    prism_rtl::is_some(template_slot_92417) ? ({
                    auto&& j = prism_rtl::some_of(template_slot_92417);
                    check_env::has_key(m, prism_rtl::cat(j))
                    ? prism_rtl::finished(std::tuple{m, check_types::err(s, Text("mismatch"), a.span, prism_rtl::cat("`", id_8.name, "` is given twice"))})
                    : prism_rtl::finished(std::tuple{insert(m, prism_rtl::cat(j), a->value), s});
                })
                    : prism_rtl::is_none(template_slot_92417) ? prism_rtl::finished(std::tuple{m, check_types::err(s, Text("mismatch"), a.span, prism_rtl::cat("`", cname_7_8, "` has no parameter `", id_8.name, "`"))})
                    : throw prism_rtl::Panic("no arm matched");
                });
            });
            });
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{m, check_types::err(s, Text("mismatch"), a.span, Text("a template call names each argument: `name={{value}}`"))})
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    }));
    })), [=](std::tuple<Map<Text, ast::Expr>, check_types::St> fold_92332) {
        return ({
            auto [slots, st1] = fold_92332;
            auto body_opt = ({
                __label__ _done;
                prism_rtl::Slot<std::optional<ast::Expr>> _v;
                if (prism_rtl::is_some(parts_opt)) {
                    auto&& ps = prism_rtl::some_of(parts_opt);
                    _v.set(std::optional(ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::ETemplate{ast::Template{.keyword = Text("InlineText"), .lang = Text(""), .delims = Text("double"), .parts = ps, .span = span_4}})), .span = span_4}));
                    goto _done;
                }
                if (prism_rtl::is_none(parts_opt)) {
                    _v.set(std::optional<ast::Expr>{});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            auto last = lexer::dec(arity);
            auto st2 = ({
                __label__ _done;
                prism_rtl::Slot<check_types::St> _v;
                if (prism_rtl::is_some(body_opt)) {
                    auto&& ignore4 = prism_rtl::some_of(body_opt);
                    _v.set((arity == Nat(0u)) || check_env::has_key(slots, prism_rtl::cat(last))
                        ? check_types::err(st1, Text("mismatch"), span_4, prism_rtl::cat("`", cname, "` has no parameter left for the call's body"))
                        : st1);
                    goto _done;
                }
                if (prism_rtl::is_none(body_opt)) {
                    _v.set(st1);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            auto quiet = len(st1.diags) > len(st_5.diags);
            call_value(fold_job(check_errors::range0(arity), std::tuple{Array<ast::Arg>{}, st2}, ({
            auto slots_6 = slots;
            auto body_opt_7 = body_opt;
            auto last_8 = last;
            auto span_4_9 = span_4;
            auto clauses_9 = clauses;
            auto cname_10 = cname;
            auto quiet_11 = quiet;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<ast::Arg>, check_types::St>>(std::tuple<std::tuple<Array<ast::Arg>, check_types::St>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<ast::Arg>, check_types::St>, Nat> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto slots_6_12 = slots_6;
                auto body_opt_7_12 = body_opt_7;
                auto last_8_12 = last_8;
                auto span_4_9_12 = span_4_9;
                auto clauses_9_12 = clauses_9;
                auto cname_10_12 = cname_10;
                auto quiet_11_12 = quiet_11;
                entered(once_job([=]() {
                return ({
                    auto [acc, s] = p0;
                    auto j = p1;
                    ({
                    auto&& _m = prelude::get(slots_6_12, prism_rtl::cat(j));
                    prism_rtl::is_some(_m) ? ({
                    auto&& v_ = prism_rtl::some_of(_m);
                    prism_rtl::finished(std::tuple{prelude::push(acc, ast::Arg{.name = std::optional<ast::Ident>{}, .value = v_, .span = v_.span}), s});
                })
                    : prism_rtl::is_none(_m) ? ({
                    prism_rtl::is_some(body_opt_7_12) ? ({
                    auto&& b = prism_rtl::some_of(body_opt_7_12);
                    j == last_8_12
                    ? prism_rtl::finished(std::tuple{prelude::push(acc, ast::Arg{.name = std::optional<ast::Ident>{}, .value = b, .span = span_4_9_12}), s})
                    : prism_rtl::more(prism_rtl::rc(TemplateMissing(acc, s, clauses_9_12, j, cname_10_12, span_4_9_12, quiet_11_12)));
                })
                    : prism_rtl::is_none(body_opt_7_12) ? prism_rtl::more(prism_rtl::rc(TemplateMissing(acc, s, clauses_9_12, j, cname_10_12, span_4_9_12, quiet_11_12)))
                    : throw prism_rtl::Panic("no arm matched");
                })
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            }));
            });
        }));
        })), [=](std::tuple<Array<ast::Arg>, check_types::St> fold_93416) {
            return ({
                auto [positional_, st3] = fold_93416;
                call_then(start_call_global(env_3, st3, callee, positional_, span_4, Array<check_types::Ty>{}, callee.span), [=](std::tuple<check_types::Ty, check_types::St> call_global_93881) {
                return ({
                    auto [t, st4] = call_global_93881;
                    (prism_rtl::more(prism_rtl::rc(check_types::Unify(st4, check_types::t_text(), t, span_4))));
                });
            });
            });
        });
        });
    });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start TemplateCallCheck, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<check_types::St> start_template_call_check(Env env, check_types::St st, ast::SName n, Array<ast::Arg> args, std::optional<Array<ast::TemplatePart>> parts_opt, ast::Range span) {
    return std::make_shared<TemplateCallCheck>(env, st, n, args, parts_opt, span);
}


/// TemplateMissing: unbounded fn [Arg], St, [FnClause], Nat, Text, Range, Bool -> (([Arg], St))
std::tuple<Array<ast::Arg>, check_types::St> template_missing(const Array<ast::Arg>& acc, const check_types::St& st, const Array<ast::FnClause>& clauses, const Nat& j, const Text& cname, const ast::Range& span, const bool& quiet) {
    auto pname = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = index(clauses, Nat(0u));
        if (prism_rtl::is_some(_m)) {
            auto&& c = prism_rtl::some_of(_m);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                auto&& _m = index(c.params, j);
                if (prism_rtl::is_some(_m)) {
                    auto&& p_ = prism_rtl::some_of(_m);
                    _v.set(check_passes::param_name_of(p_));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(Text(""));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto st2 = quiet
        ? st
        : check_types::err(st, Text("mismatch"), span, prism_rtl::cat("`<@", cname, ">` needs `", pname, "=`"));
    return std::tuple{prelude::push(acc, ast::Arg{.name = std::optional<ast::Ident>{}, .value = ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EError{})), .span = span}, .span = span}), st2};
}


prism_rtl::Turn<std::tuple<Array<ast::Arg>, check_types::St>> TemplateMissing::cycle() const {
    const auto& acc = this->acc;
    const auto& st = this->st;
    const auto& clauses = this->clauses;
    const auto& j = this->j;
    const auto& cname = this->cname;
    const auto& span = this->span;
    const auto& quiet = this->quiet;
    auto pname = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = index(clauses, Nat(0u));
        if (prism_rtl::is_some(_m)) {
            auto&& c = prism_rtl::some_of(_m);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                auto&& _m = index(c.params, j);
                if (prism_rtl::is_some(_m)) {
                    auto&& p_ = prism_rtl::some_of(_m);
                    _v.set(check_passes::param_name_of(p_));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(Text(""));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto st2 = quiet
        ? st
        : check_types::err(st, Text("mismatch"), span, prism_rtl::cat("`<@", cname, ">` needs `", pname, "=`"));
    return prism_rtl::finished(std::tuple{prelude::push(acc, ast::Arg{.name = std::optional<ast::Ident>{}, .value = ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EError{})), .span = span}, .span = span}), st2});
}


/// `Start TemplateMissing, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<ast::Arg>, check_types::St>> start_template_missing(Array<ast::Arg> acc, check_types::St st, Array<ast::FnClause> clauses, Nat j, Text cname, ast::Range span, bool quiet) {
    return std::make_shared<TemplateMissing>(acc, st, clauses, j, cname, span, quiet);
}


/// ?TemplateSlot: unbounded fn [FnClause], Text -> ?Nat
std::optional<Nat> template_slot(const Array<ast::FnClause>& clauses, const Text& name) {
    auto found = run_to_end(fold_job(clauses, Array<Nat>{}, ({
        auto name_1 = name;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, ast::FnClause>)>>(prism_rtl::rc([=](std::tuple<Array<Nat>, ast::FnClause> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto name_1_2 = name_1;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto c = p1;
                fold_job(check_errors::range0(len(c.params)), acc, ({
                auto c_2 = c;
                auto name_1_2_3 = name_1_2;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, Nat>)>>(prism_rtl::rc([=](std::tuple<Array<Nat>, Nat> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto c_2_3 = c_2;
                    auto name_1_2_3_3 = name_1_2_3;
                    entered(once_job([=]() {
                    return ({
                        auto a2 = p0;
                        auto i = p1;
                        ({
                        auto&& _m = index(c_2_3.params, i);
                        prism_rtl::is_some(_m) ? ({
                        auto&& p_ = prism_rtl::some_of(_m);
                        check_passes::param_name_of(p_) == name_1_2_3_3
                        ? prism_rtl::finished(check_types::add_nat(a2, i))
                        : prism_rtl::finished(a2);
                    })
                        : prism_rtl::is_none(_m) ? prism_rtl::finished(a2)
                        : throw prism_rtl::Panic("no arm matched");
                    });
                    });
                }));
                });
            })));
            }))->cycle();
            });
        }));
        });
    })));
    })));
    return len(found) == Nat(1u) ? index(found, Nat(0u)) : std::optional<Nat>{};
}


prism_rtl::Turn<std::optional<Nat>> TemplateSlot::cycle() const {
    const auto& clauses = this->clauses;
    const auto& name = this->name;
    auto clauses_1 = clauses;
    auto name_2 = name;
    return call_value(fold_job(clauses_1, Array<Nat>{}, ({
        auto name_2_3 = name_2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, ast::FnClause>)>>(prism_rtl::rc([=](std::tuple<Array<Nat>, ast::FnClause> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto name_2_3_3 = name_2_3;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto c = p1;
                fold_job(check_errors::range0(len(c.params)), acc, ({
                auto c_3 = c;
                auto name_2_3_3_4 = name_2_3_3;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, Nat>)>>(prism_rtl::rc([=](std::tuple<Array<Nat>, Nat> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto c_3_4 = c_3;
                    auto name_2_3_3_4_4 = name_2_3_3_4;
                    entered(once_job([=]() {
                    return ({
                        auto a2 = p0;
                        auto i = p1;
                        ({
                        auto&& _m = index(c_3_4.params, i);
                        prism_rtl::is_some(_m) ? ({
                        auto&& p_ = prism_rtl::some_of(_m);
                        check_passes::param_name_of(p_) == name_2_3_3_4_4
                        ? prism_rtl::finished(check_types::add_nat(a2, i))
                        : prism_rtl::finished(a2);
                    })
                        : prism_rtl::is_none(_m) ? prism_rtl::finished(a2)
                        : throw prism_rtl::Panic("no arm matched");
                    });
                    });
                }));
                });
            })));
            }))->cycle();
            });
        }));
        });
    })));
    })), [=](Array<Nat> fold_94775) {
        return ({
            auto found = fold_94775;
            len(found) == Nat(1u)
            ? prism_rtl::finished(index(found, Nat(0u)))
            : prism_rtl::finished(std::optional<Nat>{});
        });
    });
}


/// `Start TemplateSlot, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<Nat>> start_template_slot(Array<ast::FnClause> clauses, Text name) {
    return std::make_shared<TemplateSlot>(clauses, name);
}

}  // namespace crate::check_expr
