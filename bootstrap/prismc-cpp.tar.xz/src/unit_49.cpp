// The module `Lower.Model`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <lower/model/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>

// The module `Lower.Model`, from `target/bootstrap/cpp-src/prismc/lower/model.prism`.
namespace crate::lower::model {

void AnswerCase::show(Printer& p) const {
    p.record("AnswerCase", {{"variant", variant_p}, {"accessor", accessor_p}, {"structPath", struct_path_p}, {"tagName", tag_name_p}, {"ty", ty_p}});
}

Pod AnswerCase::to_pod() const {
    return Pod::record("AnswerCase", {{"variant", prism_rtl::to_pod(variant_p)}, {"accessor", prism_rtl::to_pod(accessor_p)}, {"structPath", prism_rtl::to_pod(struct_path_p)}, {"tagName", prism_rtl::to_pod(tag_name_p)}, {"ty", prism_rtl::to_pod(ty_p)}});
}

Result<AnswerCase> AnswerCase::from_pod(const Pod& whole) {
    return AnswerCase{.variant_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "variant")))), .accessor_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "accessor")))), .struct_path_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "structPath")))), .tag_name_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "tagName")))), .ty_p = TRY(prism_rtl::from_pod<OutTy>(TRY(crate::prelude::field(whole, "ty"))))};
}


bool AnswerDef::operator==(const AnswerDef& o) const { return cases_p == o.cases_p; }

void AnswerDef::show(Printer& p) const {
    p.record("AnswerDef", {{"cases", cases_p}});
}

Pod AnswerDef::to_pod() const {
    return Pod::record("AnswerDef", {{"cases", prism_rtl::to_pod(cases_p)}});
}

Result<AnswerDef> AnswerDef::from_pod(const Pod& whole) {
    return AnswerDef{.cases_p = TRY(prism_rtl::from_pod<Array<AnswerCase>>(TRY(crate::prelude::field(whole, "cases"))))};
}


void BinOp::show(Printer& p) const {
    if (auto c = std::get_if<OpAdd>(&cases())) p.choice("OpAdd", {});
    else if (auto c = std::get_if<OpSub>(&cases())) p.choice("OpSub", {});
    else if (auto c = std::get_if<OpMul>(&cases())) p.choice("OpMul", {});
    else if (auto c = std::get_if<OpDiv>(&cases())) p.choice("OpDiv", {});
    else if (auto c = std::get_if<OpEq>(&cases())) p.choice("OpEq", {});
    else if (auto c = std::get_if<OpNe>(&cases())) p.choice("OpNe", {});
    else if (auto c = std::get_if<OpLt>(&cases())) p.choice("OpLt", {});
    else if (auto c = std::get_if<OpLe>(&cases())) p.choice("OpLe", {});
    else if (auto c = std::get_if<OpGt>(&cases())) p.choice("OpGt", {});
    else if (auto c = std::get_if<OpGe>(&cases())) p.choice("OpGe", {});
    else if (auto c = std::get_if<OpAnd>(&cases())) p.choice("OpAnd", {});
    else if (auto c = std::get_if<OpOr>(&cases())) p.choice("OpOr", {});
}

Pod BinOp::to_pod() const {
    return std::holds_alternative<OpAdd>(cases()) ? Pod::choice("OpAdd", {})
        : std::holds_alternative<OpSub>(cases()) ? Pod::choice("OpSub", {})
        : std::holds_alternative<OpMul>(cases()) ? Pod::choice("OpMul", {})
        : std::holds_alternative<OpDiv>(cases()) ? Pod::choice("OpDiv", {})
        : std::holds_alternative<OpEq>(cases()) ? Pod::choice("OpEq", {})
        : std::holds_alternative<OpNe>(cases()) ? Pod::choice("OpNe", {})
        : std::holds_alternative<OpLt>(cases()) ? Pod::choice("OpLt", {})
        : std::holds_alternative<OpLe>(cases()) ? Pod::choice("OpLe", {})
        : std::holds_alternative<OpGt>(cases()) ? Pod::choice("OpGt", {})
        : std::holds_alternative<OpGe>(cases()) ? Pod::choice("OpGe", {})
        : std::holds_alternative<OpAnd>(cases()) ? Pod::choice("OpAnd", {})
        : std::holds_alternative<OpOr>(cases()) ? Pod::choice("OpOr", {})
        : Pod();
}

Result<BinOp> BinOp::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "OpAdd" && c->args.size() == 0) return BinOp(OpAdd{});
        if (c->ctor == "OpSub" && c->args.size() == 0) return BinOp(OpSub{});
        if (c->ctor == "OpMul" && c->args.size() == 0) return BinOp(OpMul{});
        if (c->ctor == "OpDiv" && c->args.size() == 0) return BinOp(OpDiv{});
        if (c->ctor == "OpEq" && c->args.size() == 0) return BinOp(OpEq{});
        if (c->ctor == "OpNe" && c->args.size() == 0) return BinOp(OpNe{});
        if (c->ctor == "OpLt" && c->args.size() == 0) return BinOp(OpLt{});
        if (c->ctor == "OpLe" && c->args.size() == 0) return BinOp(OpLe{});
        if (c->ctor == "OpGt" && c->args.size() == 0) return BinOp(OpGt{});
        if (c->ctor == "OpGe" && c->args.size() == 0) return BinOp(OpGe{});
        if (c->ctor == "OpAnd" && c->args.size() == 0) return BinOp(OpAnd{});
        if (c->ctor == "OpOr" && c->args.size() == 0) return BinOp(OpOr{});
    }
    return mismatch<BinOp>("a BinOp", p);
}


bool CaseDef::operator==(const CaseDef& o) const { return name_p == o.name_p && prism_p == o.prism_p && fields_p == o.fields_p && labels_p == o.labels_p; }

void CaseDef::show(Printer& p) const {
    p.record("CaseDef", {{"name", name_p}, {"prism", prism_p}, {"fields", fields_p}, {"labels", labels_p}});
}

Pod CaseDef::to_pod() const {
    return Pod::record("CaseDef", {{"name", prism_rtl::to_pod(name_p)}, {"prism", prism_rtl::to_pod(prism_p)}, {"fields", prism_rtl::to_pod(fields_p)}, {"labels", prism_rtl::to_pod(labels_p)}});
}

Result<CaseDef> CaseDef::from_pod(const Pod& whole) {
    return CaseDef{.name_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .prism_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "prism")))), .fields_p = TRY(prism_rtl::from_pod<Array<std::tuple<Text, OutTy>>>(TRY(crate::prelude::field(whole, "fields")))), .labels_p = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "labels"))))};
}


void Cc::show(Printer& p) const {
    if (auto c = std::get_if<CcIf>(&cases())) p.choice("CcIf", {c->a0});
    else if (auto c = std::get_if<CcLet>(&cases())) p.choice("CcLet", {c->a0, c->a1});
}

Pod Cc::to_pod() const {
    return std::holds_alternative<CcIf>(cases()) ? Pod::choice("CcIf", {prism_rtl::to_pod(std::get<CcIf>(cases()).a0)})
        : std::holds_alternative<CcLet>(cases()) ? Pod::choice("CcLet", {prism_rtl::to_pod(std::get<CcLet>(cases()).a0), prism_rtl::to_pod(std::get<CcLet>(cases()).a1)})
        : Pod();
}

Result<Cc> Cc::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "CcIf" && c->args.size() == 1) return Cc(CcIf{TRY(prism_rtl::from_pod<Ex>(c->args[0]))});
        if (c->ctor == "CcLet" && c->args.size() == 2) return Cc(CcLet{TRY(prism_rtl::from_pod<Pa>(c->args[0])), TRY(prism_rtl::from_pod<Ex>(c->args[1]))});
    }
    return mismatch<Cc>("a Cc", p);
}


bool CheckDef::operator==(const CheckDef& o) const { return name_p == o.name_p && lines_p == o.lines_p; }

void CheckDef::show(Printer& p) const {
    p.record("CheckDef", {{"name", name_p}, {"lines", lines_p}});
}

Pod CheckDef::to_pod() const {
    return Pod::record("CheckDef", {{"name", prism_rtl::to_pod(name_p)}, {"lines", prism_rtl::to_pod(lines_p)}});
}

Result<CheckDef> CheckDef::from_pod(const Pod& whole) {
    return CheckDef{.name_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .lines_p = TRY(prism_rtl::from_pod<Array<Ex>>(TRY(crate::prelude::field(whole, "lines"))))};
}


void CxArg::show(Printer& p) const {
    if (auto c = std::get_if<CxMut>(&cases())) p.choice("CxMut", {});
    else if (auto c = std::get_if<CxRef>(&cases())) p.choice("CxRef", {});
    else if (auto c = std::get_if<CxNone>(&cases())) p.choice("CxNone", {});
}

Pod CxArg::to_pod() const {
    return std::holds_alternative<CxMut>(cases()) ? Pod::choice("CxMut", {})
        : std::holds_alternative<CxRef>(cases()) ? Pod::choice("CxRef", {})
        : std::holds_alternative<CxNone>(cases()) ? Pod::choice("CxNone", {})
        : Pod();
}

Result<CxArg> CxArg::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "CxMut" && c->args.size() == 0) return CxArg(CxMut{});
        if (c->ctor == "CxRef" && c->args.size() == 0) return CxArg(CxRef{});
        if (c->ctor == "CxNone" && c->args.size() == 0) return CxArg(CxNone{});
    }
    return mismatch<CxArg>("a CxArg", p);
}


bool Do::DoWhile::operator==(const DoWhile& o) const { return a0 == o.a0 && a1 == o.a1; }

bool Do::DoWhileLet::operator==(const DoWhileLet& o) const { return a0 == o.a0 && a1 == o.a1 && a2 == o.a2; }

bool Do::DoFor::operator==(const DoFor& o) const { return a0 == o.a0 && a1 == o.a1 && a2 == o.a2; }

bool Do::DoIf::operator==(const DoIf& o) const { return a0 == o.a0 && a1 == o.a1 && a2 == o.a2; }

bool Do::DoIfLet::operator==(const DoIfLet& o) const { return a0 == o.a0 && a1 == o.a1 && a2 == o.a2 && a3 == o.a3; }

bool Do::DoMatch::operator==(const DoMatch& o) const { return a0 == o.a0 && a1 == o.a1; }

bool Do::DoBlock::operator==(const DoBlock& o) const { return a0 == o.a0; }

bool Do::DoScope::operator==(const DoScope& o) const { return a0 == o.a0; }

bool Do::DoLine::operator==(const DoLine& o) const { return a0 == o.a0; }

void Do::show(Printer& p) const {
    if (auto c = std::get_if<DoLet>(&cases())) p.choice("DoLet", {c->a0, c->a1});
    else if (auto c = std::get_if<DoLetElse>(&cases())) p.choice("DoLetElse", {c->a0, c->a1, c->a2});
    else if (auto c = std::get_if<DoAssign>(&cases())) p.choice("DoAssign", {c->a0, c->a1});
    else if (auto c = std::get_if<DoWhile>(&cases())) p.choice("DoWhile", {c->a0, c->a1});
    else if (auto c = std::get_if<DoWhileLet>(&cases())) p.choice("DoWhileLet", {c->a0, c->a1, c->a2});
    else if (auto c = std::get_if<DoFor>(&cases())) p.choice("DoFor", {c->a0, c->a1, c->a2});
    else if (auto c = std::get_if<DoExpr>(&cases())) p.choice("DoExpr", {c->a0});
    else if (auto c = std::get_if<DoIf>(&cases())) p.choice("DoIf", {c->a0, c->a1, c->a2});
    else if (auto c = std::get_if<DoIfLet>(&cases())) p.choice("DoIfLet", {c->a0, c->a1, c->a2, c->a3});
    else if (auto c = std::get_if<DoMatch>(&cases())) p.choice("DoMatch", {c->a0, c->a1});
    else if (auto c = std::get_if<DoReturn>(&cases())) p.choice("DoReturn", {c->a0});
    else if (auto c = std::get_if<DoBlock>(&cases())) p.choice("DoBlock", {c->a0});
    else if (auto c = std::get_if<DoScope>(&cases())) p.choice("DoScope", {c->a0});
    else if (auto c = std::get_if<DoLine>(&cases())) p.choice("DoLine", {c->a0});
    else if (auto c = std::get_if<DoNote>(&cases())) p.choice("DoNote", {c->a0});
}

Pod Do::to_pod() const {
    return std::holds_alternative<DoLet>(cases()) ? Pod::choice("DoLet", {prism_rtl::to_pod(std::get<DoLet>(cases()).a0), prism_rtl::to_pod(std::get<DoLet>(cases()).a1)})
        : std::holds_alternative<DoLetElse>(cases()) ? Pod::choice("DoLetElse", {prism_rtl::to_pod(std::get<DoLetElse>(cases()).a0), prism_rtl::to_pod(std::get<DoLetElse>(cases()).a1), prism_rtl::to_pod(std::get<DoLetElse>(cases()).a2)})
        : std::holds_alternative<DoAssign>(cases()) ? Pod::choice("DoAssign", {prism_rtl::to_pod(std::get<DoAssign>(cases()).a0), prism_rtl::to_pod(std::get<DoAssign>(cases()).a1)})
        : std::holds_alternative<DoWhile>(cases()) ? Pod::choice("DoWhile", {prism_rtl::to_pod(std::get<DoWhile>(cases()).a0), prism_rtl::to_pod(std::get<DoWhile>(cases()).a1)})
        : std::holds_alternative<DoWhileLet>(cases()) ? Pod::choice("DoWhileLet", {prism_rtl::to_pod(std::get<DoWhileLet>(cases()).a0), prism_rtl::to_pod(std::get<DoWhileLet>(cases()).a1), prism_rtl::to_pod(std::get<DoWhileLet>(cases()).a2)})
        : std::holds_alternative<DoFor>(cases()) ? Pod::choice("DoFor", {prism_rtl::to_pod(std::get<DoFor>(cases()).a0), prism_rtl::to_pod(std::get<DoFor>(cases()).a1), prism_rtl::to_pod(std::get<DoFor>(cases()).a2)})
        : std::holds_alternative<DoExpr>(cases()) ? Pod::choice("DoExpr", {prism_rtl::to_pod(std::get<DoExpr>(cases()).a0)})
        : std::holds_alternative<DoIf>(cases()) ? Pod::choice("DoIf", {prism_rtl::to_pod(std::get<DoIf>(cases()).a0), prism_rtl::to_pod(std::get<DoIf>(cases()).a1), prism_rtl::to_pod(std::get<DoIf>(cases()).a2)})
        : std::holds_alternative<DoIfLet>(cases()) ? Pod::choice("DoIfLet", {prism_rtl::to_pod(std::get<DoIfLet>(cases()).a0), prism_rtl::to_pod(std::get<DoIfLet>(cases()).a1), prism_rtl::to_pod(std::get<DoIfLet>(cases()).a2), prism_rtl::to_pod(std::get<DoIfLet>(cases()).a3)})
        : std::holds_alternative<DoMatch>(cases()) ? Pod::choice("DoMatch", {prism_rtl::to_pod(std::get<DoMatch>(cases()).a0), prism_rtl::to_pod(std::get<DoMatch>(cases()).a1)})
        : std::holds_alternative<DoReturn>(cases()) ? Pod::choice("DoReturn", {prism_rtl::to_pod(std::get<DoReturn>(cases()).a0)})
        : std::holds_alternative<DoBlock>(cases()) ? Pod::choice("DoBlock", {prism_rtl::to_pod(std::get<DoBlock>(cases()).a0)})
        : std::holds_alternative<DoScope>(cases()) ? Pod::choice("DoScope", {prism_rtl::to_pod(std::get<DoScope>(cases()).a0)})
        : std::holds_alternative<DoLine>(cases()) ? Pod::choice("DoLine", {prism_rtl::to_pod(std::get<DoLine>(cases()).a0)})
        : std::holds_alternative<DoNote>(cases()) ? Pod::choice("DoNote", {prism_rtl::to_pod(std::get<DoNote>(cases()).a0)})
        : Pod();
}

Result<Do> Do::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "DoLet" && c->args.size() == 2) return Do(DoLet{TRY(prism_rtl::from_pod<Pa>(c->args[0])), TRY(prism_rtl::from_pod<Ex>(c->args[1]))});
        if (c->ctor == "DoLetElse" && c->args.size() == 3) return Do(DoLetElse{TRY(prism_rtl::from_pod<Pa>(c->args[0])), TRY(prism_rtl::from_pod<Ex>(c->args[1])), TRY(prism_rtl::from_pod<Ex>(c->args[2]))});
        if (c->ctor == "DoAssign" && c->args.size() == 2) return Do(DoAssign{TRY(prism_rtl::from_pod<Ex>(c->args[0])), TRY(prism_rtl::from_pod<Ex>(c->args[1]))});
        if (c->ctor == "DoWhile" && c->args.size() == 2) return Do(DoWhile{TRY(prism_rtl::from_pod<Ex>(c->args[0])), TRY(prism_rtl::from_pod<Array<Do>>(c->args[1]))});
        if (c->ctor == "DoWhileLet" && c->args.size() == 3) return Do(DoWhileLet{TRY(prism_rtl::from_pod<Pa>(c->args[0])), TRY(prism_rtl::from_pod<Ex>(c->args[1])), TRY(prism_rtl::from_pod<Array<Do>>(c->args[2]))});
        if (c->ctor == "DoFor" && c->args.size() == 3) return Do(DoFor{TRY(prism_rtl::from_pod<Pa>(c->args[0])), TRY(prism_rtl::from_pod<Ex>(c->args[1])), TRY(prism_rtl::from_pod<Array<Do>>(c->args[2]))});
        if (c->ctor == "DoExpr" && c->args.size() == 1) return Do(DoExpr{TRY(prism_rtl::from_pod<Ex>(c->args[0]))});
        if (c->ctor == "DoIf" && c->args.size() == 3) return Do(DoIf{TRY(prism_rtl::from_pod<Ex>(c->args[0])), TRY(prism_rtl::from_pod<Array<Do>>(c->args[1])), TRY(prism_rtl::from_pod<Array<Do>>(c->args[2]))});
        if (c->ctor == "DoIfLet" && c->args.size() == 4) return Do(DoIfLet{TRY(prism_rtl::from_pod<Pa>(c->args[0])), TRY(prism_rtl::from_pod<Ex>(c->args[1])), TRY(prism_rtl::from_pod<Array<Do>>(c->args[2])), TRY(prism_rtl::from_pod<Array<Do>>(c->args[3]))});
        if (c->ctor == "DoMatch" && c->args.size() == 2) return Do(DoMatch{TRY(prism_rtl::from_pod<Ex>(c->args[0])), TRY(prism_rtl::from_pod<Array<std::tuple<Pa, Array<Do>>>>(c->args[1]))});
        if (c->ctor == "DoReturn" && c->args.size() == 1) return Do(DoReturn{TRY(prism_rtl::from_pod<Ex>(c->args[0]))});
        if (c->ctor == "DoBlock" && c->args.size() == 1) return Do(DoBlock{TRY(prism_rtl::from_pod<Array<Do>>(c->args[0]))});
        if (c->ctor == "DoScope" && c->args.size() == 1) return Do(DoScope{TRY(prism_rtl::from_pod<Array<Do>>(c->args[0]))});
        if (c->ctor == "DoLine" && c->args.size() == 1) return Do(DoLine{TRY(prism_rtl::from_pod<Array<Do>>(c->args[0]))});
        if (c->ctor == "DoNote" && c->args.size() == 1) return Do(DoNote{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
    }
    return mismatch<Do>("a Do", p);
}


bool Ex::XRef::operator==(const XRef& o) const { return a0 == o.a0; }

bool Ex::XRefMut::operator==(const XRefMut& o) const { return a0 == o.a0; }

bool Ex::XDeref::operator==(const XDeref& o) const { return a0 == o.a0; }

bool Ex::XTarget::operator==(const XTarget& o) const { return a0 == o.a0; }

bool Ex::XClone::operator==(const XClone& o) const { return a0 == o.a0; }

bool Ex::XWeak::operator==(const XWeak& o) const { return a0 == o.a0; }

bool Ex::XUpgrade::operator==(const XUpgrade& o) const { return a0 == o.a0; }

bool Ex::XBreak::operator==(const XBreak& o) const { return a0 == o.a0 && a1 == o.a1; }

bool Ex::XLater::operator==(const XLater& o) const { return a0 == o.a0; }

bool Ex::XFormatStr::operator==(const XFormatStr& o) const { return a0 == o.a0; }

bool Ex::XIsCase::operator==(const XIsCase& o) const { return a0 == o.a0 && a1 == o.a1; }

bool Ex::XCall::operator==(const XCall& o) const { return a0 == o.a0 && a1 == o.a1; }

bool Ex::XApply::operator==(const XApply& o) const { return a0 == o.a0 && a1 == o.a1; }

bool Ex::XMethod::operator==(const XMethod& o) const { return a0 == o.a0 && a1 == o.a1 && a2 == o.a2; }

bool Ex::XBin::operator==(const XBin& o) const { return a0 == o.a0 && a1 == o.a1 && a2 == o.a2; }

bool Ex::XUnary::operator==(const XUnary& o) const { return a0 == o.a0 && a1 == o.a1; }

bool Ex::XCtor::operator==(const XCtor& o) const { return a0 == o.a0 && a1 == o.a1; }

bool Ex::XRecord::operator==(const XRecord& o) const { return a0 == o.a0 && a1 == o.a1; }

bool Ex::XTuple::operator==(const XTuple& o) const { return a0 == o.a0; }

bool Ex::XVec::operator==(const XVec& o) const { return a0 == o.a0; }

bool Ex::XFormat::operator==(const XFormat& o) const { return a0 == o.a0; }

bool Ex::XMatch::operator==(const XMatch& o) const { return a0 == o.a0 && a1 == o.a1 && a2 == o.a2 && a3 == o.a3; }

bool Ex::XChain::operator==(const XChain& o) const { return a0 == o.a0 && a1 == o.a1 && a2 == o.a2 && a3 == o.a3; }

bool Ex::XIf::operator==(const XIf& o) const { return a0 == o.a0 && a1 == o.a1 && a2 == o.a2; }

bool Ex::XBlock::operator==(const XBlock& o) const { return a0 == o.a0 && a1 == o.a1; }

bool Ex::XLabeled::operator==(const XLabeled& o) const { return a0 == o.a0 && a1 == o.a1 && a2 == o.a2 && a3 == o.a3; }

bool Ex::XClosure::operator==(const XClosure& o) const { return a0 == o.a0 && a1 == o.a1 && a2 == o.a2; }

bool Ex::XTry::operator==(const XTry& o) const { return a0 == o.a0; }

bool Ex::XField::operator==(const XField& o) const { return a0 == o.a0 && a1 == o.a1; }

bool Ex::XPart::operator==(const XPart& o) const { return a0 == o.a0 && a1 == o.a1; }

bool Ex::XDecode::operator==(const XDecode& o) const { return a0 == o.a0 && a1 == o.a1; }

bool Ex::XCast::operator==(const XCast& o) const { return a0 == o.a0 && a1 == o.a1; }

bool Ex::XTyped::operator==(const XTyped& o) const { return a0 == o.a0 && a1 == o.a1; }

void Ex::show(Printer& p) const {
    if (auto c = std::get_if<XVar>(&cases())) p.choice("XVar", {c->a0});
    else if (auto c = std::get_if<XPath>(&cases())) p.choice("XPath", {c->a0});
    else if (auto c = std::get_if<XSelf>(&cases())) p.choice("XSelf", {});
    else if (auto c = std::get_if<XCx>(&cases())) p.choice("XCx", {});
    else if (auto c = std::get_if<XConst>(&cases())) p.choice("XConst", {c->a0});
    else if (auto c = std::get_if<XUnit>(&cases())) p.choice("XUnit", {});
    else if (auto c = std::get_if<XNone>(&cases())) p.choice("XNone", {});
    else if (auto c = std::get_if<XBool>(&cases())) p.choice("XBool", {c->a0});
    else if (auto c = std::get_if<XNat>(&cases())) p.choice("XNat", {c->a0});
    else if (auto c = std::get_if<XInt>(&cases())) p.choice("XInt", {c->a0});
    else if (auto c = std::get_if<XByte>(&cases())) p.choice("XByte", {c->a0});
    else if (auto c = std::get_if<XFloat>(&cases())) p.choice("XFloat", {c->a0});
    else if (auto c = std::get_if<XIndex>(&cases())) p.choice("XIndex", {c->a0});
    else if (auto c = std::get_if<XChar>(&cases())) p.choice("XChar", {c->a0});
    else if (auto c = std::get_if<XStr>(&cases())) p.choice("XStr", {c->a0});
    else if (auto c = std::get_if<XRegex>(&cases())) p.choice("XRegex", {c->a0, c->a1});
    else if (auto c = std::get_if<XReplacement>(&cases())) p.choice("XReplacement", {c->a0, c->a1, c->a2});
    else if (auto c = std::get_if<XRef>(&cases())) p.choice("XRef", {c->a0});
    else if (auto c = std::get_if<XRefMut>(&cases())) p.choice("XRefMut", {c->a0});
    else if (auto c = std::get_if<XDeref>(&cases())) p.choice("XDeref", {c->a0});
    else if (auto c = std::get_if<XTarget>(&cases())) p.choice("XTarget", {c->a0});
    else if (auto c = std::get_if<XClone>(&cases())) p.choice("XClone", {c->a0});
    else if (auto c = std::get_if<XWeak>(&cases())) p.choice("XWeak", {c->a0});
    else if (auto c = std::get_if<XUpgrade>(&cases())) p.choice("XUpgrade", {c->a0});
    else if (auto c = std::get_if<XBreak>(&cases())) p.choice("XBreak", {c->a0, c->a1});
    else if (auto c = std::get_if<XBreakLoop>(&cases())) p.choice("XBreakLoop", {});
    else if (auto c = std::get_if<XLater>(&cases())) p.choice("XLater", {c->a0});
    else if (auto c = std::get_if<XFormatStr>(&cases())) p.choice("XFormatStr", {c->a0});
    else if (auto c = std::get_if<XIsCase>(&cases())) p.choice("XIsCase", {c->a0, c->a1});
    else if (auto c = std::get_if<XRefusal>(&cases())) p.choice("XRefusal", {c->a0});
    else if (auto c = std::get_if<XUnreachable>(&cases())) p.choice("XUnreachable", {});
    else if (auto c = std::get_if<XCall>(&cases())) p.choice("XCall", {c->a0, c->a1});
    else if (auto c = std::get_if<XApply>(&cases())) p.choice("XApply", {c->a0, c->a1});
    else if (auto c = std::get_if<XMethod>(&cases())) p.choice("XMethod", {c->a0, c->a1, c->a2});
    else if (auto c = std::get_if<XBin>(&cases())) p.choice("XBin", {c->a0, c->a1, c->a2});
    else if (auto c = std::get_if<XUnary>(&cases())) p.choice("XUnary", {c->a0, c->a1});
    else if (auto c = std::get_if<XCtor>(&cases())) p.choice("XCtor", {c->a0, c->a1});
    else if (auto c = std::get_if<XRecord>(&cases())) p.choice("XRecord", {c->a0, c->a1});
    else if (auto c = std::get_if<XTuple>(&cases())) p.choice("XTuple", {c->a0});
    else if (auto c = std::get_if<XVec>(&cases())) p.choice("XVec", {c->a0});
    else if (auto c = std::get_if<XText>(&cases())) p.choice("XText", {c->a0});
    else if (auto c = std::get_if<XFormat>(&cases())) p.choice("XFormat", {c->a0});
    else if (auto c = std::get_if<XMatch>(&cases())) p.choice("XMatch", {c->a0, c->a1, c->a2, c->a3});
    else if (auto c = std::get_if<XChain>(&cases())) p.choice("XChain", {c->a0, c->a1, c->a2, c->a3});
    else if (auto c = std::get_if<XIf>(&cases())) p.choice("XIf", {c->a0, c->a1, c->a2});
    else if (auto c = std::get_if<XBlock>(&cases())) p.choice("XBlock", {c->a0, c->a1});
    else if (auto c = std::get_if<XLabeled>(&cases())) p.choice("XLabeled", {c->a0, c->a1, c->a2, c->a3});
    else if (auto c = std::get_if<XClosure>(&cases())) p.choice("XClosure", {c->a0, c->a1, c->a2});
    else if (auto c = std::get_if<XTry>(&cases())) p.choice("XTry", {c->a0});
    else if (auto c = std::get_if<XField>(&cases())) p.choice("XField", {c->a0, c->a1});
    else if (auto c = std::get_if<XPart>(&cases())) p.choice("XPart", {c->a0, c->a1});
    else if (auto c = std::get_if<XDecode>(&cases())) p.choice("XDecode", {c->a0, c->a1});
    else if (auto c = std::get_if<XCast>(&cases())) p.choice("XCast", {c->a0, c->a1});
    else if (auto c = std::get_if<XTyped>(&cases())) p.choice("XTyped", {c->a0, c->a1});
}

Pod Ex::to_pod() const {
    return std::holds_alternative<XVar>(cases()) ? Pod::choice("XVar", {prism_rtl::to_pod(std::get<XVar>(cases()).a0)})
        : std::holds_alternative<XPath>(cases()) ? Pod::choice("XPath", {prism_rtl::to_pod(std::get<XPath>(cases()).a0)})
        : std::holds_alternative<XSelf>(cases()) ? Pod::choice("XSelf", {})
        : std::holds_alternative<XCx>(cases()) ? Pod::choice("XCx", {})
        : std::holds_alternative<XConst>(cases()) ? Pod::choice("XConst", {prism_rtl::to_pod(std::get<XConst>(cases()).a0)})
        : std::holds_alternative<XUnit>(cases()) ? Pod::choice("XUnit", {})
        : std::holds_alternative<XNone>(cases()) ? Pod::choice("XNone", {})
        : std::holds_alternative<XBool>(cases()) ? Pod::choice("XBool", {prism_rtl::to_pod(std::get<XBool>(cases()).a0)})
        : std::holds_alternative<XNat>(cases()) ? Pod::choice("XNat", {prism_rtl::to_pod(std::get<XNat>(cases()).a0)})
        : std::holds_alternative<XInt>(cases()) ? Pod::choice("XInt", {prism_rtl::to_pod(std::get<XInt>(cases()).a0)})
        : std::holds_alternative<XByte>(cases()) ? Pod::choice("XByte", {prism_rtl::to_pod(std::get<XByte>(cases()).a0)})
        : std::holds_alternative<XFloat>(cases()) ? Pod::choice("XFloat", {prism_rtl::to_pod(std::get<XFloat>(cases()).a0)})
        : std::holds_alternative<XIndex>(cases()) ? Pod::choice("XIndex", {prism_rtl::to_pod(std::get<XIndex>(cases()).a0)})
        : std::holds_alternative<XChar>(cases()) ? Pod::choice("XChar", {prism_rtl::to_pod(std::get<XChar>(cases()).a0)})
        : std::holds_alternative<XStr>(cases()) ? Pod::choice("XStr", {prism_rtl::to_pod(std::get<XStr>(cases()).a0)})
        : std::holds_alternative<XRegex>(cases()) ? Pod::choice("XRegex", {prism_rtl::to_pod(std::get<XRegex>(cases()).a0), prism_rtl::to_pod(std::get<XRegex>(cases()).a1)})
        : std::holds_alternative<XReplacement>(cases()) ? Pod::choice("XReplacement", {prism_rtl::to_pod(std::get<XReplacement>(cases()).a0), prism_rtl::to_pod(std::get<XReplacement>(cases()).a1), prism_rtl::to_pod(std::get<XReplacement>(cases()).a2)})
        : std::holds_alternative<XRef>(cases()) ? Pod::choice("XRef", {prism_rtl::to_pod(std::get<XRef>(cases()).a0)})
        : std::holds_alternative<XRefMut>(cases()) ? Pod::choice("XRefMut", {prism_rtl::to_pod(std::get<XRefMut>(cases()).a0)})
        : std::holds_alternative<XDeref>(cases()) ? Pod::choice("XDeref", {prism_rtl::to_pod(std::get<XDeref>(cases()).a0)})
        : std::holds_alternative<XTarget>(cases()) ? Pod::choice("XTarget", {prism_rtl::to_pod(std::get<XTarget>(cases()).a0)})
        : std::holds_alternative<XClone>(cases()) ? Pod::choice("XClone", {prism_rtl::to_pod(std::get<XClone>(cases()).a0)})
        : std::holds_alternative<XWeak>(cases()) ? Pod::choice("XWeak", {prism_rtl::to_pod(std::get<XWeak>(cases()).a0)})
        : std::holds_alternative<XUpgrade>(cases()) ? Pod::choice("XUpgrade", {prism_rtl::to_pod(std::get<XUpgrade>(cases()).a0)})
        : std::holds_alternative<XBreak>(cases()) ? Pod::choice("XBreak", {prism_rtl::to_pod(std::get<XBreak>(cases()).a0), prism_rtl::to_pod(std::get<XBreak>(cases()).a1)})
        : std::holds_alternative<XBreakLoop>(cases()) ? Pod::choice("XBreakLoop", {})
        : std::holds_alternative<XLater>(cases()) ? Pod::choice("XLater", {prism_rtl::to_pod(std::get<XLater>(cases()).a0)})
        : std::holds_alternative<XFormatStr>(cases()) ? Pod::choice("XFormatStr", {prism_rtl::to_pod(std::get<XFormatStr>(cases()).a0)})
        : std::holds_alternative<XIsCase>(cases()) ? Pod::choice("XIsCase", {prism_rtl::to_pod(std::get<XIsCase>(cases()).a0), prism_rtl::to_pod(std::get<XIsCase>(cases()).a1)})
        : std::holds_alternative<XRefusal>(cases()) ? Pod::choice("XRefusal", {prism_rtl::to_pod(std::get<XRefusal>(cases()).a0)})
        : std::holds_alternative<XUnreachable>(cases()) ? Pod::choice("XUnreachable", {})
        : std::holds_alternative<XCall>(cases()) ? Pod::choice("XCall", {prism_rtl::to_pod(std::get<XCall>(cases()).a0), prism_rtl::to_pod(std::get<XCall>(cases()).a1)})
        : std::holds_alternative<XApply>(cases()) ? Pod::choice("XApply", {prism_rtl::to_pod(std::get<XApply>(cases()).a0), prism_rtl::to_pod(std::get<XApply>(cases()).a1)})
        : std::holds_alternative<XMethod>(cases()) ? Pod::choice("XMethod", {prism_rtl::to_pod(std::get<XMethod>(cases()).a0), prism_rtl::to_pod(std::get<XMethod>(cases()).a1), prism_rtl::to_pod(std::get<XMethod>(cases()).a2)})
        : std::holds_alternative<XBin>(cases()) ? Pod::choice("XBin", {prism_rtl::to_pod(std::get<XBin>(cases()).a0), prism_rtl::to_pod(std::get<XBin>(cases()).a1), prism_rtl::to_pod(std::get<XBin>(cases()).a2)})
        : std::holds_alternative<XUnary>(cases()) ? Pod::choice("XUnary", {prism_rtl::to_pod(std::get<XUnary>(cases()).a0), prism_rtl::to_pod(std::get<XUnary>(cases()).a1)})
        : std::holds_alternative<XCtor>(cases()) ? Pod::choice("XCtor", {prism_rtl::to_pod(std::get<XCtor>(cases()).a0), prism_rtl::to_pod(std::get<XCtor>(cases()).a1)})
        : std::holds_alternative<XRecord>(cases()) ? Pod::choice("XRecord", {prism_rtl::to_pod(std::get<XRecord>(cases()).a0), prism_rtl::to_pod(std::get<XRecord>(cases()).a1)})
        : std::holds_alternative<XTuple>(cases()) ? Pod::choice("XTuple", {prism_rtl::to_pod(std::get<XTuple>(cases()).a0)})
        : std::holds_alternative<XVec>(cases()) ? Pod::choice("XVec", {prism_rtl::to_pod(std::get<XVec>(cases()).a0)})
        : std::holds_alternative<XText>(cases()) ? Pod::choice("XText", {prism_rtl::to_pod(std::get<XText>(cases()).a0)})
        : std::holds_alternative<XFormat>(cases()) ? Pod::choice("XFormat", {prism_rtl::to_pod(std::get<XFormat>(cases()).a0)})
        : std::holds_alternative<XMatch>(cases()) ? Pod::choice("XMatch", {prism_rtl::to_pod(std::get<XMatch>(cases()).a0), prism_rtl::to_pod(std::get<XMatch>(cases()).a1), prism_rtl::to_pod(std::get<XMatch>(cases()).a2), prism_rtl::to_pod(std::get<XMatch>(cases()).a3)})
        : std::holds_alternative<XChain>(cases()) ? Pod::choice("XChain", {prism_rtl::to_pod(std::get<XChain>(cases()).a0), prism_rtl::to_pod(std::get<XChain>(cases()).a1), prism_rtl::to_pod(std::get<XChain>(cases()).a2), prism_rtl::to_pod(std::get<XChain>(cases()).a3)})
        : std::holds_alternative<XIf>(cases()) ? Pod::choice("XIf", {prism_rtl::to_pod(std::get<XIf>(cases()).a0), prism_rtl::to_pod(std::get<XIf>(cases()).a1), prism_rtl::to_pod(std::get<XIf>(cases()).a2)})
        : std::holds_alternative<XBlock>(cases()) ? Pod::choice("XBlock", {prism_rtl::to_pod(std::get<XBlock>(cases()).a0), prism_rtl::to_pod(std::get<XBlock>(cases()).a1)})
        : std::holds_alternative<XLabeled>(cases()) ? Pod::choice("XLabeled", {prism_rtl::to_pod(std::get<XLabeled>(cases()).a0), prism_rtl::to_pod(std::get<XLabeled>(cases()).a1), prism_rtl::to_pod(std::get<XLabeled>(cases()).a2), prism_rtl::to_pod(std::get<XLabeled>(cases()).a3)})
        : std::holds_alternative<XClosure>(cases()) ? Pod::choice("XClosure", {prism_rtl::to_pod(std::get<XClosure>(cases()).a0), prism_rtl::to_pod(std::get<XClosure>(cases()).a1), prism_rtl::to_pod(std::get<XClosure>(cases()).a2)})
        : std::holds_alternative<XTry>(cases()) ? Pod::choice("XTry", {prism_rtl::to_pod(std::get<XTry>(cases()).a0)})
        : std::holds_alternative<XField>(cases()) ? Pod::choice("XField", {prism_rtl::to_pod(std::get<XField>(cases()).a0), prism_rtl::to_pod(std::get<XField>(cases()).a1)})
        : std::holds_alternative<XPart>(cases()) ? Pod::choice("XPart", {prism_rtl::to_pod(std::get<XPart>(cases()).a0), prism_rtl::to_pod(std::get<XPart>(cases()).a1)})
        : std::holds_alternative<XDecode>(cases()) ? Pod::choice("XDecode", {prism_rtl::to_pod(std::get<XDecode>(cases()).a0), prism_rtl::to_pod(std::get<XDecode>(cases()).a1)})
        : std::holds_alternative<XCast>(cases()) ? Pod::choice("XCast", {prism_rtl::to_pod(std::get<XCast>(cases()).a0), prism_rtl::to_pod(std::get<XCast>(cases()).a1)})
        : std::holds_alternative<XTyped>(cases()) ? Pod::choice("XTyped", {prism_rtl::to_pod(std::get<XTyped>(cases()).a0), prism_rtl::to_pod(std::get<XTyped>(cases()).a1)})
        : Pod();
}

Result<Ex> Ex::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "XVar" && c->args.size() == 1) return Ex(XVar{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "XPath" && c->args.size() == 1) return Ex(XPath{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "XSelf" && c->args.size() == 0) return Ex(XSelf{});
        if (c->ctor == "XCx" && c->args.size() == 0) return Ex(XCx{});
        if (c->ctor == "XConst" && c->args.size() == 1) return Ex(XConst{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "XUnit" && c->args.size() == 0) return Ex(XUnit{});
        if (c->ctor == "XNone" && c->args.size() == 0) return Ex(XNone{});
        if (c->ctor == "XBool" && c->args.size() == 1) return Ex(XBool{TRY(prism_rtl::from_pod<bool>(c->args[0]))});
        if (c->ctor == "XNat" && c->args.size() == 1) return Ex(XNat{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "XInt" && c->args.size() == 1) return Ex(XInt{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "XByte" && c->args.size() == 1) return Ex(XByte{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "XFloat" && c->args.size() == 1) return Ex(XFloat{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "XIndex" && c->args.size() == 1) return Ex(XIndex{TRY(prism_rtl::from_pod<Nat>(c->args[0]))});
        if (c->ctor == "XChar" && c->args.size() == 1) return Ex(XChar{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "XStr" && c->args.size() == 1) return Ex(XStr{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "XRegex" && c->args.size() == 2) return Ex(XRegex{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Text>(c->args[1]))});
        if (c->ctor == "XReplacement" && c->args.size() == 3) return Ex(XReplacement{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Text>(c->args[1])), TRY(prism_rtl::from_pod<Text>(c->args[2]))});
        if (c->ctor == "XRef" && c->args.size() == 1) return Ex(XRef{TRY(prism_rtl::from_pod<prism_rtl::Rc<const Ex>>(c->args[0]))});
        if (c->ctor == "XRefMut" && c->args.size() == 1) return Ex(XRefMut{TRY(prism_rtl::from_pod<prism_rtl::Rc<const Ex>>(c->args[0]))});
        if (c->ctor == "XDeref" && c->args.size() == 1) return Ex(XDeref{TRY(prism_rtl::from_pod<prism_rtl::Rc<const Ex>>(c->args[0]))});
        if (c->ctor == "XTarget" && c->args.size() == 1) return Ex(XTarget{TRY(prism_rtl::from_pod<prism_rtl::Rc<const Ex>>(c->args[0]))});
        if (c->ctor == "XClone" && c->args.size() == 1) return Ex(XClone{TRY(prism_rtl::from_pod<prism_rtl::Rc<const Ex>>(c->args[0]))});
        if (c->ctor == "XWeak" && c->args.size() == 1) return Ex(XWeak{TRY(prism_rtl::from_pod<prism_rtl::Rc<const Ex>>(c->args[0]))});
        if (c->ctor == "XUpgrade" && c->args.size() == 1) return Ex(XUpgrade{TRY(prism_rtl::from_pod<prism_rtl::Rc<const Ex>>(c->args[0]))});
        if (c->ctor == "XBreak" && c->args.size() == 2) return Ex(XBreak{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<prism_rtl::Rc<const Ex>>(c->args[1]))});
        if (c->ctor == "XBreakLoop" && c->args.size() == 0) return Ex(XBreakLoop{});
        if (c->ctor == "XLater" && c->args.size() == 1) return Ex(XLater{TRY(prism_rtl::from_pod<prism_rtl::Rc<const Ex>>(c->args[0]))});
        if (c->ctor == "XFormatStr" && c->args.size() == 1) return Ex(XFormatStr{TRY(prism_rtl::from_pod<Array<Ex>>(c->args[0]))});
        if (c->ctor == "XIsCase" && c->args.size() == 2) return Ex(XIsCase{TRY(prism_rtl::from_pod<prism_rtl::Rc<const Ex>>(c->args[0])), TRY(prism_rtl::from_pod<Array<Text>>(c->args[1]))});
        if (c->ctor == "XRefusal" && c->args.size() == 1) return Ex(XRefusal{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "XUnreachable" && c->args.size() == 0) return Ex(XUnreachable{});
        if (c->ctor == "XCall" && c->args.size() == 2) return Ex(XCall{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Array<Ex>>(c->args[1]))});
        if (c->ctor == "XApply" && c->args.size() == 2) return Ex(XApply{TRY(prism_rtl::from_pod<prism_rtl::Rc<const Ex>>(c->args[0])), TRY(prism_rtl::from_pod<Array<Ex>>(c->args[1]))});
        if (c->ctor == "XMethod" && c->args.size() == 3) return Ex(XMethod{TRY(prism_rtl::from_pod<prism_rtl::Rc<const Ex>>(c->args[0])), TRY(prism_rtl::from_pod<Text>(c->args[1])), TRY(prism_rtl::from_pod<Array<Ex>>(c->args[2]))});
        if (c->ctor == "XBin" && c->args.size() == 3) return Ex(XBin{TRY(prism_rtl::from_pod<BinOp>(c->args[0])), TRY(prism_rtl::from_pod<prism_rtl::Rc<const Ex>>(c->args[1])), TRY(prism_rtl::from_pod<prism_rtl::Rc<const Ex>>(c->args[2]))});
        if (c->ctor == "XUnary" && c->args.size() == 2) return Ex(XUnary{TRY(prism_rtl::from_pod<UnOp>(c->args[0])), TRY(prism_rtl::from_pod<prism_rtl::Rc<const Ex>>(c->args[1]))});
        if (c->ctor == "XCtor" && c->args.size() == 2) return Ex(XCtor{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Array<Ex>>(c->args[1]))});
        if (c->ctor == "XRecord" && c->args.size() == 2) return Ex(XRecord{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Array<std::tuple<Text, Ex>>>(c->args[1]))});
        if (c->ctor == "XTuple" && c->args.size() == 1) return Ex(XTuple{TRY(prism_rtl::from_pod<Array<Ex>>(c->args[0]))});
        if (c->ctor == "XVec" && c->args.size() == 1) return Ex(XVec{TRY(prism_rtl::from_pod<Array<Ex>>(c->args[0]))});
        if (c->ctor == "XText" && c->args.size() == 1) return Ex(XText{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "XFormat" && c->args.size() == 1) return Ex(XFormat{TRY(prism_rtl::from_pod<Array<Ex>>(c->args[0]))});
        if (c->ctor == "XMatch" && c->args.size() == 4) return Ex(XMatch{TRY(prism_rtl::from_pod<prism_rtl::Rc<const Ex>>(c->args[0])), TRY(prism_rtl::from_pod<Array<XArm>>(c->args[1])), TRY(prism_rtl::from_pod<bool>(c->args[2])), TRY(prism_rtl::from_pod<OutTy>(c->args[3]))});
        if (c->ctor == "XChain" && c->args.size() == 4) return Ex(XChain{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<prism_rtl::Rc<const Ex>>(c->args[1])), TRY(prism_rtl::from_pod<Array<XArm>>(c->args[2])), TRY(prism_rtl::from_pod<OutTy>(c->args[3]))});
        if (c->ctor == "XIf" && c->args.size() == 3) return Ex(XIf{TRY(prism_rtl::from_pod<prism_rtl::Rc<const Ex>>(c->args[0])), TRY(prism_rtl::from_pod<prism_rtl::Rc<const Ex>>(c->args[1])), TRY(prism_rtl::from_pod<prism_rtl::Rc<const Ex>>(c->args[2]))});
        if (c->ctor == "XBlock" && c->args.size() == 2) return Ex(XBlock{TRY(prism_rtl::from_pod<Array<Do>>(c->args[0])), TRY(prism_rtl::from_pod<prism_rtl::Rc<const Ex>>(c->args[1]))});
        if (c->ctor == "XLabeled" && c->args.size() == 4) return Ex(XLabeled{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Array<Do>>(c->args[1])), TRY(prism_rtl::from_pod<prism_rtl::Rc<const Ex>>(c->args[2])), TRY(prism_rtl::from_pod<OutTy>(c->args[3]))});
        if (c->ctor == "XClosure" && c->args.size() == 3) return Ex(XClosure{TRY(prism_rtl::from_pod<bool>(c->args[0])), TRY(prism_rtl::from_pod<Array<Pa>>(c->args[1])), TRY(prism_rtl::from_pod<prism_rtl::Rc<const Ex>>(c->args[2]))});
        if (c->ctor == "XTry" && c->args.size() == 1) return Ex(XTry{TRY(prism_rtl::from_pod<prism_rtl::Rc<const Ex>>(c->args[0]))});
        if (c->ctor == "XField" && c->args.size() == 2) return Ex(XField{TRY(prism_rtl::from_pod<prism_rtl::Rc<const Ex>>(c->args[0])), TRY(prism_rtl::from_pod<Text>(c->args[1]))});
        if (c->ctor == "XPart" && c->args.size() == 2) return Ex(XPart{TRY(prism_rtl::from_pod<prism_rtl::Rc<const Ex>>(c->args[0])), TRY(prism_rtl::from_pod<Nat>(c->args[1]))});
        if (c->ctor == "XDecode" && c->args.size() == 2) return Ex(XDecode{TRY(prism_rtl::from_pod<OutTy>(c->args[0])), TRY(prism_rtl::from_pod<prism_rtl::Rc<const Ex>>(c->args[1]))});
        if (c->ctor == "XCast" && c->args.size() == 2) return Ex(XCast{TRY(prism_rtl::from_pod<prism_rtl::Rc<const Ex>>(c->args[0])), TRY(prism_rtl::from_pod<OutTy>(c->args[1]))});
        if (c->ctor == "XTyped" && c->args.size() == 2) return Ex(XTyped{TRY(prism_rtl::from_pod<prism_rtl::Rc<const Ex>>(c->args[0])), TRY(prism_rtl::from_pod<OutTy>(c->args[1]))});
    }
    return mismatch<Ex>("a Ex", p);
}


bool FnDef::operator==(const FnDef& o) const { return name_p == o.name_p && generics_p == o.generics_p && params_p == o.params_p && ret_p == o.ret_p && body_p == o.body_p && doc_p == o.doc_p && public_p == o.public_p; }

void FnDef::show(Printer& p) const {
    p.record("FnDef", {{"name", name_p}, {"generics", generics_p}, {"params", params_p}, {"ret", ret_p}, {"body", body_p}, {"doc", doc_p}, {"public", public_p}});
}

Pod FnDef::to_pod() const {
    return Pod::record("FnDef", {{"name", prism_rtl::to_pod(name_p)}, {"generics", prism_rtl::to_pod(generics_p)}, {"params", prism_rtl::to_pod(params_p)}, {"ret", prism_rtl::to_pod(ret_p)}, {"body", prism_rtl::to_pod(body_p)}, {"doc", prism_rtl::to_pod(doc_p)}, {"public", prism_rtl::to_pod(public_p)}});
}

Result<FnDef> FnDef::from_pod(const Pod& whole) {
    return FnDef{.name_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .generics_p = TRY(prism_rtl::from_pod<Array<std::tuple<Text, Array<Text>>>>(TRY(crate::prelude::field(whole, "generics")))), .params_p = TRY(prism_rtl::from_pod<Array<std::tuple<Text, OutTy>>>(TRY(crate::prelude::field(whole, "params")))), .ret_p = TRY(prism_rtl::from_pod<OutTy>(TRY(crate::prelude::field(whole, "ret")))), .body_p = TRY(prism_rtl::from_pod<Ex>(TRY(crate::prelude::field(whole, "body")))), .doc_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "doc")))), .public_p = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "public"))))};
}


bool ForDef::operator==(const ForDef& o) const { return name_p == o.name_p && pos_p == o.pos_p && at_p == o.at_p && key_ty_p == o.key_ty_p && value_ty_p == o.value_ty_p && row_node_p == o.row_node_p && keyed_p == o.keyed_p && source_p == o.source_p && parent_p == o.parent_p && passed_p == o.passed_p && moved_p == o.moved_p && replaced_p == o.replaced_p; }

void ForDef::show(Printer& p) const {
    p.record("ForDef", {{"name", name_p}, {"pos", pos_p}, {"at", at_p}, {"keyTy", key_ty_p}, {"valueTy", value_ty_p}, {"rowNode", row_node_p}, {"keyed", keyed_p}, {"source", source_p}, {"parent", parent_p}, {"passed", passed_p}, {"moved", moved_p}, {"replaced", replaced_p}});
}

Pod ForDef::to_pod() const {
    return Pod::record("ForDef", {{"name", prism_rtl::to_pod(name_p)}, {"pos", prism_rtl::to_pod(pos_p)}, {"at", prism_rtl::to_pod(at_p)}, {"keyTy", prism_rtl::to_pod(key_ty_p)}, {"valueTy", prism_rtl::to_pod(value_ty_p)}, {"rowNode", prism_rtl::to_pod(row_node_p)}, {"keyed", prism_rtl::to_pod(keyed_p)}, {"source", prism_rtl::to_pod(source_p)}, {"parent", prism_rtl::to_pod(parent_p)}, {"passed", prism_rtl::to_pod(passed_p)}, {"moved", prism_rtl::to_pod(moved_p)}, {"replaced", prism_rtl::to_pod(replaced_p)}});
}

Result<ForDef> ForDef::from_pod(const Pod& whole) {
    return ForDef{.name_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .pos_p = TRY(prism_rtl::from_pod<Pos_>(TRY(crate::prelude::field(whole, "pos")))), .at_p = TRY(prism_rtl::from_pod<Ex>(TRY(crate::prelude::field(whole, "at")))), .key_ty_p = TRY(prism_rtl::from_pod<OutTy>(TRY(crate::prelude::field(whole, "keyTy")))), .value_ty_p = TRY(prism_rtl::from_pod<OutTy>(TRY(crate::prelude::field(whole, "valueTy")))), .row_node_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "rowNode")))), .keyed_p = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "keyed")))), .source_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "source")))), .parent_p = TRY(prism_rtl::from_pod<Ex>(TRY(crate::prelude::field(whole, "parent")))), .passed_p = TRY(prism_rtl::from_pod<Array<Ex>>(TRY(crate::prelude::field(whole, "passed")))), .moved_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "moved")))), .replaced_p = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "replaced"))))};
}


void GenDef::show(Printer& p) const {
    p.record("GenDef", {{"name", name_p}, {"pos", pos_p}, {"at", at_p}, {"source", source_p}, {"valueTy", value_ty_p}, {"select", select_p}, {"transparent", transparent_p}, {"width", width_p}, {"moved", moved_p}});
}

Pod GenDef::to_pod() const {
    return Pod::record("GenDef", {{"name", prism_rtl::to_pod(name_p)}, {"pos", prism_rtl::to_pod(pos_p)}, {"at", prism_rtl::to_pod(at_p)}, {"source", prism_rtl::to_pod(source_p)}, {"valueTy", prism_rtl::to_pod(value_ty_p)}, {"select", prism_rtl::to_pod(select_p)}, {"transparent", prism_rtl::to_pod(transparent_p)}, {"width", prism_rtl::to_pod(width_p)}, {"moved", prism_rtl::to_pod(moved_p)}});
}

Result<GenDef> GenDef::from_pod(const Pod& whole) {
    return GenDef{.name_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .pos_p = TRY(prism_rtl::from_pod<Pos_>(TRY(crate::prelude::field(whole, "pos")))), .at_p = TRY(prism_rtl::from_pod<Ex>(TRY(crate::prelude::field(whole, "at")))), .source_p = TRY(prism_rtl::from_pod<Ex>(TRY(crate::prelude::field(whole, "source")))), .value_ty_p = TRY(prism_rtl::from_pod<OutTy>(TRY(crate::prelude::field(whole, "valueTy")))), .select_p = TRY(prism_rtl::from_pod<Ex>(TRY(crate::prelude::field(whole, "select")))), .transparent_p = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "transparent")))), .width_p = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "width")))), .moved_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "moved"))))};
}


bool ImplDef::operator==(const ImplDef& o) const { return cls_p == o.cls_p && tr_p == o.tr_p && head_p == o.head_p && generics_p == o.generics_p && methods_p == o.methods_p && doc_p == o.doc_p; }

void ImplDef::show(Printer& p) const {
    p.record("ImplDef", {{"cls", cls_p}, {"tr", tr_p}, {"head", head_p}, {"generics", generics_p}, {"methods", methods_p}, {"doc", doc_p}});
}

Pod ImplDef::to_pod() const {
    return Pod::record("ImplDef", {{"cls", prism_rtl::to_pod(cls_p)}, {"tr", prism_rtl::to_pod(tr_p)}, {"head", prism_rtl::to_pod(head_p)}, {"generics", prism_rtl::to_pod(generics_p)}, {"methods", prism_rtl::to_pod(methods_p)}, {"doc", prism_rtl::to_pod(doc_p)}});
}

Result<ImplDef> ImplDef::from_pod(const Pod& whole) {
    return ImplDef{.cls_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "cls")))), .tr_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "tr")))), .head_p = TRY(prism_rtl::from_pod<OutTy>(TRY(crate::prelude::field(whole, "head")))), .generics_p = TRY(prism_rtl::from_pod<Array<std::tuple<Text, Array<Text>>>>(TRY(crate::prelude::field(whole, "generics")))), .methods_p = TRY(prism_rtl::from_pod<Array<FnDef>>(TRY(crate::prelude::field(whole, "methods")))), .doc_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "doc"))))};
}


void Item::show(Printer& p) const {
    if (auto c = std::get_if<ItTrait>(&cases())) p.choice("ItTrait", {c->a0});
    else if (auto c = std::get_if<ItImpl>(&cases())) p.choice("ItImpl", {c->a0});
    else if (auto c = std::get_if<ItType>(&cases())) p.choice("ItType", {c->a0});
    else if (auto c = std::get_if<ItTag>(&cases())) p.choice("ItTag", {c->a0});
    else if (auto c = std::get_if<ItRow>(&cases())) p.choice("ItRow", {c->a0});
    else if (auto c = std::get_if<ItFn>(&cases())) p.choice("ItFn", {c->a0});
    else if (auto c = std::get_if<ItJob>(&cases())) p.choice("ItJob", {c->a0});
    else if (auto c = std::get_if<ItNode>(&cases())) p.choice("ItNode", {c->a0});
    else if (auto c = std::get_if<ItNote>(&cases())) p.choice("ItNote", {c->a0});
    else if (auto c = std::get_if<ItRefused>(&cases())) p.choice("ItRefused", {c->a0});
}

Pod Item::to_pod() const {
    return std::holds_alternative<ItTrait>(cases()) ? Pod::choice("ItTrait", {prism_rtl::to_pod(std::get<ItTrait>(cases()).a0)})
        : std::holds_alternative<ItImpl>(cases()) ? Pod::choice("ItImpl", {prism_rtl::to_pod(std::get<ItImpl>(cases()).a0)})
        : std::holds_alternative<ItType>(cases()) ? Pod::choice("ItType", {prism_rtl::to_pod(std::get<ItType>(cases()).a0)})
        : std::holds_alternative<ItTag>(cases()) ? Pod::choice("ItTag", {prism_rtl::to_pod(std::get<ItTag>(cases()).a0)})
        : std::holds_alternative<ItRow>(cases()) ? Pod::choice("ItRow", {prism_rtl::to_pod(std::get<ItRow>(cases()).a0)})
        : std::holds_alternative<ItFn>(cases()) ? Pod::choice("ItFn", {prism_rtl::to_pod(std::get<ItFn>(cases()).a0)})
        : std::holds_alternative<ItJob>(cases()) ? Pod::choice("ItJob", {prism_rtl::to_pod(std::get<ItJob>(cases()).a0)})
        : std::holds_alternative<ItNode>(cases()) ? Pod::choice("ItNode", {prism_rtl::to_pod(std::get<ItNode>(cases()).a0)})
        : std::holds_alternative<ItNote>(cases()) ? Pod::choice("ItNote", {prism_rtl::to_pod(std::get<ItNote>(cases()).a0)})
        : std::holds_alternative<ItRefused>(cases()) ? Pod::choice("ItRefused", {prism_rtl::to_pod(std::get<ItRefused>(cases()).a0)})
        : Pod();
}

Result<Item> Item::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "ItTrait" && c->args.size() == 1) return Item(ItTrait{TRY(prism_rtl::from_pod<TraitDef>(c->args[0]))});
        if (c->ctor == "ItImpl" && c->args.size() == 1) return Item(ItImpl{TRY(prism_rtl::from_pod<ImplDef>(c->args[0]))});
        if (c->ctor == "ItType" && c->args.size() == 1) return Item(ItType{TRY(prism_rtl::from_pod<TyDef>(c->args[0]))});
        if (c->ctor == "ItTag" && c->args.size() == 1) return Item(ItTag{TRY(prism_rtl::from_pod<TagDef>(c->args[0]))});
        if (c->ctor == "ItRow" && c->args.size() == 1) return Item(ItRow{TRY(prism_rtl::from_pod<RowDef>(c->args[0]))});
        if (c->ctor == "ItFn" && c->args.size() == 1) return Item(ItFn{TRY(prism_rtl::from_pod<FnDef>(c->args[0]))});
        if (c->ctor == "ItJob" && c->args.size() == 1) return Item(ItJob{TRY(prism_rtl::from_pod<JobDef>(c->args[0]))});
        if (c->ctor == "ItNode" && c->args.size() == 1) return Item(ItNode{TRY(prism_rtl::from_pod<NodeDef>(c->args[0]))});
        if (c->ctor == "ItNote" && c->args.size() == 1) return Item(ItNote{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "ItRefused" && c->args.size() == 1) return Item(ItRefused{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
    }
    return mismatch<Item>("a Item", p);
}


bool JobDef::operator==(const JobDef& o) const { return name_p == o.name_p && start_p == o.start_p && generics_p == o.generics_p && fields_p == o.fields_p && ret_p == o.ret_p && body_p == o.body_p && doc_p == o.doc_p; }

void JobDef::show(Printer& p) const {
    p.record("JobDef", {{"name", name_p}, {"start", start_p}, {"generics", generics_p}, {"fields", fields_p}, {"ret", ret_p}, {"body", body_p}, {"doc", doc_p}});
}

Pod JobDef::to_pod() const {
    return Pod::record("JobDef", {{"name", prism_rtl::to_pod(name_p)}, {"start", prism_rtl::to_pod(start_p)}, {"generics", prism_rtl::to_pod(generics_p)}, {"fields", prism_rtl::to_pod(fields_p)}, {"ret", prism_rtl::to_pod(ret_p)}, {"body", prism_rtl::to_pod(body_p)}, {"doc", prism_rtl::to_pod(doc_p)}});
}

Result<JobDef> JobDef::from_pod(const Pod& whole) {
    return JobDef{.name_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .start_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "start")))), .generics_p = TRY(prism_rtl::from_pod<Array<std::tuple<Text, Array<Text>>>>(TRY(crate::prelude::field(whole, "generics")))), .fields_p = TRY(prism_rtl::from_pod<Array<std::tuple<Text, OutTy>>>(TRY(crate::prelude::field(whole, "fields")))), .ret_p = TRY(prism_rtl::from_pod<OutTy>(TRY(crate::prelude::field(whole, "ret")))), .body_p = TRY(prism_rtl::from_pod<Ex>(TRY(crate::prelude::field(whole, "body")))), .doc_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "doc"))))};
}


bool MethDef::operator==(const MethDef& o) const { return name_p == o.name_p && recv_p == o.recv_p && params_p == o.params_p && cx_p == o.cx_p && ret_p == o.ret_p && body_p == o.body_p && tail_p == o.tail_p && doc_p == o.doc_p; }

void MethDef::show(Printer& p) const {
    p.record("MethDef", {{"name", name_p}, {"recv", recv_p}, {"params", params_p}, {"cx", cx_p}, {"ret", ret_p}, {"body", body_p}, {"tail", tail_p}, {"doc", doc_p}});
}

Pod MethDef::to_pod() const {
    return Pod::record("MethDef", {{"name", prism_rtl::to_pod(name_p)}, {"recv", prism_rtl::to_pod(recv_p)}, {"params", prism_rtl::to_pod(params_p)}, {"cx", prism_rtl::to_pod(cx_p)}, {"ret", prism_rtl::to_pod(ret_p)}, {"body", prism_rtl::to_pod(body_p)}, {"tail", prism_rtl::to_pod(tail_p)}, {"doc", prism_rtl::to_pod(doc_p)}});
}

Result<MethDef> MethDef::from_pod(const Pod& whole) {
    return MethDef{.name_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .recv_p = TRY(prism_rtl::from_pod<Recv>(TRY(crate::prelude::field(whole, "recv")))), .params_p = TRY(prism_rtl::from_pod<Array<std::tuple<Text, OutTy>>>(TRY(crate::prelude::field(whole, "params")))), .cx_p = TRY(prism_rtl::from_pod<CxArg>(TRY(crate::prelude::field(whole, "cx")))), .ret_p = TRY(prism_rtl::from_pod<OutTy>(TRY(crate::prelude::field(whole, "ret")))), .body_p = TRY(prism_rtl::from_pod<Array<Do>>(TRY(crate::prelude::field(whole, "body")))), .tail_p = TRY(prism_rtl::from_pod<Ex>(TRY(crate::prelude::field(whole, "tail")))), .doc_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "doc"))))};
}


bool ModDef::operator==(const ModDef& o) const { return name_p == o.name_p && prism_p == o.prism_p && path_p == o.path_p && uses_p == o.uses_p && complete_p == o.complete_p && declared_p == o.declared_p && types_with_p == o.types_with_p && items_p == o.items_p; }

void ModDef::show(Printer& p) const {
    p.record("ModDef", {{"name", name_p}, {"prism", prism_p}, {"path", path_p}, {"uses", uses_p}, {"complete", complete_p}, {"declared", declared_p}, {"typesWith", types_with_p}, {"items", items_p}});
}

Pod ModDef::to_pod() const {
    return Pod::record("ModDef", {{"name", prism_rtl::to_pod(name_p)}, {"prism", prism_rtl::to_pod(prism_p)}, {"path", prism_rtl::to_pod(path_p)}, {"uses", prism_rtl::to_pod(uses_p)}, {"complete", prism_rtl::to_pod(complete_p)}, {"declared", prism_rtl::to_pod(declared_p)}, {"typesWith", prism_rtl::to_pod(types_with_p)}, {"items", prism_rtl::to_pod(items_p)}});
}

Result<ModDef> ModDef::from_pod(const Pod& whole) {
    return ModDef{.name_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .prism_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "prism")))), .path_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "path")))), .uses_p = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "uses")))), .complete_p = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "complete")))), .declared_p = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "declared")))), .types_with_p = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "typesWith")))), .items_p = TRY(prism_rtl::from_pod<Array<Item>>(TRY(crate::prelude::field(whole, "items"))))};
}


bool Model::operator==(const Model& o) const { return name_p == o.name_p && mods_p == o.mods_p && programs_p == o.programs_p && root_o == o.root_o && checks_p == o.checks_p && elem_p == o.elem_p && answer_p == o.answer_p && elem_complete_p == o.elem_complete_p && elem_declared_p == o.elem_declared_p && scripts_p == o.scripts_p && notes_p == o.notes_p; }

void Model::show(Printer& p) const {
    p.record("Model", {{"name", name_p}, {"mods", mods_p}, {"programs", programs_p}, {"root", root_o}, {"checks", checks_p}, {"elem", elem_p}, {"answer", answer_p}, {"elemComplete", elem_complete_p}, {"elemDeclared", elem_declared_p}, {"scripts", scripts_p}, {"notes", notes_p}});
}

Pod Model::to_pod() const {
    return Pod::record("Model", {{"name", prism_rtl::to_pod(name_p)}, {"mods", prism_rtl::to_pod(mods_p)}, {"programs", prism_rtl::to_pod(programs_p)}, {"root", prism_rtl::to_pod(root_o)}, {"checks", prism_rtl::to_pod(checks_p)}, {"elem", prism_rtl::to_pod(elem_p)}, {"answer", prism_rtl::to_pod(answer_p)}, {"elemComplete", prism_rtl::to_pod(elem_complete_p)}, {"elemDeclared", prism_rtl::to_pod(elem_declared_p)}, {"scripts", prism_rtl::to_pod(scripts_p)}, {"notes", prism_rtl::to_pod(notes_p)}});
}

Result<Model> Model::from_pod(const Pod& whole) {
    return Model{.name_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .mods_p = TRY(prism_rtl::from_pod<Array<ModDef>>(TRY(crate::prelude::field(whole, "mods")))), .programs_p = TRY(prism_rtl::from_pod<Array<ProgDef>>(TRY(crate::prelude::field(whole, "programs")))), .root_o = TRY(prism_rtl::from_pod<std::optional<ProgDef>>(TRY(crate::prelude::field(whole, "root")))), .checks_p = TRY(prism_rtl::from_pod<Array<CheckDef>>(TRY(crate::prelude::field(whole, "checks")))), .elem_p = TRY(prism_rtl::from_pod<RowDef>(TRY(crate::prelude::field(whole, "elem")))), .answer_p = TRY(prism_rtl::from_pod<AnswerDef>(TRY(crate::prelude::field(whole, "answer")))), .elem_complete_p = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "elemComplete")))), .elem_declared_p = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "elemDeclared")))), .scripts_p = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "scripts")))), .notes_p = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "notes"))))};
}


bool NodeDef::operator==(const NodeDef& o) const { return name_p == o.name_p && prism_p == o.prism_p && doc_p == o.doc_p && params_p == o.params_p && fields_p == o.fields_p && consts_p == o.consts_p && lets_p == o.lets_p && inits_p == o.inits_p && build_p == o.build_p && fallible_p == o.fallible_p && methods_p == o.methods_p && answers_p == o.answers_p && hooks_p == o.hooks_p && builders_p == o.builders_p && wakes_p == o.wakes_p && children_p == o.children_p && gens_p == o.gens_p && subs_p == o.subs_p && top_p == o.top_p && row_kind_p == o.row_kind_p && hosted_p == o.hosted_p; }

void NodeDef::show(Printer& p) const {
    p.record("NodeDef", {{"name", name_p}, {"prism", prism_p}, {"doc", doc_p}, {"params", params_p}, {"fields", fields_p}, {"consts", consts_p}, {"lets", lets_p}, {"inits", inits_p}, {"build", build_p}, {"fallible", fallible_p}, {"methods", methods_p}, {"answers", answers_p}, {"hooks", hooks_p}, {"builders", builders_p}, {"wakes", wakes_p}, {"children", children_p}, {"gens", gens_p}, {"subs", subs_p}, {"top", top_p}, {"rowKind", row_kind_p}, {"hosted", hosted_p}});
}

Pod NodeDef::to_pod() const {
    return Pod::record("NodeDef", {{"name", prism_rtl::to_pod(name_p)}, {"prism", prism_rtl::to_pod(prism_p)}, {"doc", prism_rtl::to_pod(doc_p)}, {"params", prism_rtl::to_pod(params_p)}, {"fields", prism_rtl::to_pod(fields_p)}, {"consts", prism_rtl::to_pod(consts_p)}, {"lets", prism_rtl::to_pod(lets_p)}, {"inits", prism_rtl::to_pod(inits_p)}, {"build", prism_rtl::to_pod(build_p)}, {"fallible", prism_rtl::to_pod(fallible_p)}, {"methods", prism_rtl::to_pod(methods_p)}, {"answers", prism_rtl::to_pod(answers_p)}, {"hooks", prism_rtl::to_pod(hooks_p)}, {"builders", prism_rtl::to_pod(builders_p)}, {"wakes", prism_rtl::to_pod(wakes_p)}, {"children", prism_rtl::to_pod(children_p)}, {"gens", prism_rtl::to_pod(gens_p)}, {"subs", prism_rtl::to_pod(subs_p)}, {"top", prism_rtl::to_pod(top_p)}, {"rowKind", prism_rtl::to_pod(row_kind_p)}, {"hosted", prism_rtl::to_pod(hosted_p)}});
}

Result<NodeDef> NodeDef::from_pod(const Pod& whole) {
    return NodeDef{.name_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .prism_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "prism")))), .doc_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "doc")))), .params_p = TRY(prism_rtl::from_pod<Array<std::tuple<Text, OutTy>>>(TRY(crate::prelude::field(whole, "params")))), .fields_p = TRY(prism_rtl::from_pod<Array<std::tuple<Text, OutTy, Text>>>(TRY(crate::prelude::field(whole, "fields")))), .consts_p = TRY(prism_rtl::from_pod<Array<std::tuple<Text, Nat, Text>>>(TRY(crate::prelude::field(whole, "consts")))), .lets_p = TRY(prism_rtl::from_pod<Array<Do>>(TRY(crate::prelude::field(whole, "lets")))), .inits_p = TRY(prism_rtl::from_pod<Array<std::tuple<Text, Ex>>>(TRY(crate::prelude::field(whole, "inits")))), .build_p = TRY(prism_rtl::from_pod<Array<Do>>(TRY(crate::prelude::field(whole, "build")))), .fallible_p = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "fallible")))), .methods_p = TRY(prism_rtl::from_pod<Array<MethDef>>(TRY(crate::prelude::field(whole, "methods")))), .answers_p = TRY(prism_rtl::from_pod<Array<std::tuple<Pa, Ex>>>(TRY(crate::prelude::field(whole, "answers")))), .hooks_p = TRY(prism_rtl::from_pod<Array<std::tuple<Text, Array<Do>>>>(TRY(crate::prelude::field(whole, "hooks")))), .builders_p = TRY(prism_rtl::from_pod<Array<ForDef>>(TRY(crate::prelude::field(whole, "builders")))), .wakes_p = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "wakes")))), .children_p = TRY(prism_rtl::from_pod<Array<NodeDef>>(TRY(crate::prelude::field(whole, "children")))), .gens_p = TRY(prism_rtl::from_pod<Array<GenDef>>(TRY(crate::prelude::field(whole, "gens")))), .subs_p = TRY(prism_rtl::from_pod<Array<std::tuple<Text, Text, OutTy>>>(TRY(crate::prelude::field(whole, "subs")))), .top_p = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "top")))), .row_kind_p = TRY(prism_rtl::from_pod<RowKind>(TRY(crate::prelude::field(whole, "rowKind")))), .hosted_p = TRY(prism_rtl::from_pod<Array<MethDef>>(TRY(crate::prelude::field(whole, "hosted"))))};
}


bool OutTy::OutNamed::operator==(const OutNamed& o) const { return a0 == o.a0 && a1 == o.a1; }

bool OutTy::OutOpt::operator==(const OutOpt& o) const { return a0 == o.a0; }

bool OutTy::OutRes::operator==(const OutRes& o) const { return a0 == o.a0; }

bool OutTy::OutTuple::operator==(const OutTuple& o) const { return a0 == o.a0; }

bool OutTy::OutArray::operator==(const OutArray& o) const { return a0 == o.a0; }

bool OutTy::OutMap::operator==(const OutMap& o) const { return a0 == o.a0 && a1 == o.a1; }

bool OutTy::OutFn::operator==(const OutFn& o) const { return a0 == o.a0 && a1 == o.a1; }

bool OutTy::OutJobFn::operator==(const OutJobFn& o) const { return a0 == o.a0 && a1 == o.a1; }

bool OutTy::OutJob::operator==(const OutJob& o) const { return a0 == o.a0; }

bool OutTy::OutEvent::operator==(const OutEvent& o) const { return a0 == o.a0; }

bool OutTy::OutDyn::operator==(const OutDyn& o) const { return a0 == o.a0; }

bool OutTy::OutRc::operator==(const OutRc& o) const { return a0 == o.a0; }

bool OutTy::OutRef::operator==(const OutRef& o) const { return a0 == o.a0; }

bool OutTy::OutHold::operator==(const OutHold& o) const { return a0 == o.a0; }

bool OutTy::OutStamped::operator==(const OutStamped& o) const { return a0 == o.a0; }

bool OutTy::OutSnapshot::operator==(const OutSnapshot& o) const { return a0 == o.a0; }

bool OutTy::OutDefer::operator==(const OutDefer& o) const { return a0 == o.a0; }

bool OutTy::OutCell::operator==(const OutCell& o) const { return a0 == o.a0; }

bool OutTy::OutObj::operator==(const OutObj& o) const { return a0 == o.a0; }

bool OutTy::OutSlice::operator==(const OutSlice& o) const { return a0 == o.a0; }

bool OutTy::OutPort::operator==(const OutPort& o) const { return a0 == o.a0; }

bool OutTy::OutLive::operator==(const OutLive& o) const { return a0 == o.a0; }

void OutTy::show(Printer& p) const {
    if (auto c = std::get_if<OutNat>(&cases())) p.choice("OutNat", {});
    else if (auto c = std::get_if<OutInt>(&cases())) p.choice("OutInt", {});
    else if (auto c = std::get_if<OutU8>(&cases())) p.choice("OutU8", {});
    else if (auto c = std::get_if<OutFloat>(&cases())) p.choice("OutFloat", {});
    else if (auto c = std::get_if<OutBool>(&cases())) p.choice("OutBool", {});
    else if (auto c = std::get_if<OutChar>(&cases())) p.choice("OutChar", {});
    else if (auto c = std::get_if<OutText>(&cases())) p.choice("OutText", {});
    else if (auto c = std::get_if<OutCursor>(&cases())) p.choice("OutCursor", {});
    else if (auto c = std::get_if<OutRegex>(&cases())) p.choice("OutRegex", {});
    else if (auto c = std::get_if<OutReplacement>(&cases())) p.choice("OutReplacement", {});
    else if (auto c = std::get_if<OutUnit>(&cases())) p.choice("OutUnit", {});
    else if (auto c = std::get_if<OutPath>(&cases())) p.choice("OutPath", {});
    else if (auto c = std::get_if<OutDuration>(&cases())) p.choice("OutDuration", {});
    else if (auto c = std::get_if<OutError>(&cases())) p.choice("OutError", {});
    else if (auto c = std::get_if<OutNamed>(&cases())) p.choice("OutNamed", {c->a0, c->a1});
    else if (auto c = std::get_if<OutOpt>(&cases())) p.choice("OutOpt", {c->a0});
    else if (auto c = std::get_if<OutRes>(&cases())) p.choice("OutRes", {c->a0});
    else if (auto c = std::get_if<OutTuple>(&cases())) p.choice("OutTuple", {c->a0});
    else if (auto c = std::get_if<OutArray>(&cases())) p.choice("OutArray", {c->a0});
    else if (auto c = std::get_if<OutMap>(&cases())) p.choice("OutMap", {c->a0, c->a1});
    else if (auto c = std::get_if<OutFn>(&cases())) p.choice("OutFn", {c->a0, c->a1});
    else if (auto c = std::get_if<OutJobFn>(&cases())) p.choice("OutJobFn", {c->a0, c->a1});
    else if (auto c = std::get_if<OutJob>(&cases())) p.choice("OutJob", {c->a0});
    else if (auto c = std::get_if<OutEvent>(&cases())) p.choice("OutEvent", {c->a0});
    else if (auto c = std::get_if<OutDyn>(&cases())) p.choice("OutDyn", {c->a0});
    else if (auto c = std::get_if<OutGen>(&cases())) p.choice("OutGen", {c->a0});
    else if (auto c = std::get_if<OutRc>(&cases())) p.choice("OutRc", {c->a0});
    else if (auto c = std::get_if<OutRef>(&cases())) p.choice("OutRef", {c->a0});
    else if (auto c = std::get_if<OutPod>(&cases())) p.choice("OutPod", {});
    else if (auto c = std::get_if<OutShowAny>(&cases())) p.choice("OutShowAny", {});
    else if (auto c = std::get_if<OutHold>(&cases())) p.choice("OutHold", {c->a0});
    else if (auto c = std::get_if<OutStamped>(&cases())) p.choice("OutStamped", {c->a0});
    else if (auto c = std::get_if<OutSnapshot>(&cases())) p.choice("OutSnapshot", {c->a0});
    else if (auto c = std::get_if<OutDefer>(&cases())) p.choice("OutDefer", {c->a0});
    else if (auto c = std::get_if<OutWeak>(&cases())) p.choice("OutWeak", {c->a0});
    else if (auto c = std::get_if<OutCell>(&cases())) p.choice("OutCell", {c->a0});
    else if (auto c = std::get_if<OutWakes>(&cases())) p.choice("OutWakes", {});
    else if (auto c = std::get_if<OutCount>(&cases())) p.choice("OutCount", {});
    else if (auto c = std::get_if<OutObj>(&cases())) p.choice("OutObj", {c->a0});
    else if (auto c = std::get_if<OutSlice>(&cases())) p.choice("OutSlice", {c->a0});
    else if (auto c = std::get_if<OutPort>(&cases())) p.choice("OutPort", {c->a0});
    else if (auto c = std::get_if<OutLive>(&cases())) p.choice("OutLive", {c->a0});
    else if (auto c = std::get_if<OutQuantified>(&cases())) p.choice("OutQuantified", {c->a0});
    else if (auto c = std::get_if<OutTurn>(&cases())) p.choice("OutTurn", {});
    else if (auto c = std::get_if<OutRefused>(&cases())) p.choice("OutRefused", {c->a0});
}

Pod OutTy::to_pod() const {
    return std::holds_alternative<OutNat>(cases()) ? Pod::choice("OutNat", {})
        : std::holds_alternative<OutInt>(cases()) ? Pod::choice("OutInt", {})
        : std::holds_alternative<OutU8>(cases()) ? Pod::choice("OutU8", {})
        : std::holds_alternative<OutFloat>(cases()) ? Pod::choice("OutFloat", {})
        : std::holds_alternative<OutBool>(cases()) ? Pod::choice("OutBool", {})
        : std::holds_alternative<OutChar>(cases()) ? Pod::choice("OutChar", {})
        : std::holds_alternative<OutText>(cases()) ? Pod::choice("OutText", {})
        : std::holds_alternative<OutCursor>(cases()) ? Pod::choice("OutCursor", {})
        : std::holds_alternative<OutRegex>(cases()) ? Pod::choice("OutRegex", {})
        : std::holds_alternative<OutReplacement>(cases()) ? Pod::choice("OutReplacement", {})
        : std::holds_alternative<OutUnit>(cases()) ? Pod::choice("OutUnit", {})
        : std::holds_alternative<OutPath>(cases()) ? Pod::choice("OutPath", {})
        : std::holds_alternative<OutDuration>(cases()) ? Pod::choice("OutDuration", {})
        : std::holds_alternative<OutError>(cases()) ? Pod::choice("OutError", {})
        : std::holds_alternative<OutNamed>(cases()) ? Pod::choice("OutNamed", {prism_rtl::to_pod(std::get<OutNamed>(cases()).a0), prism_rtl::to_pod(std::get<OutNamed>(cases()).a1)})
        : std::holds_alternative<OutOpt>(cases()) ? Pod::choice("OutOpt", {prism_rtl::to_pod(std::get<OutOpt>(cases()).a0)})
        : std::holds_alternative<OutRes>(cases()) ? Pod::choice("OutRes", {prism_rtl::to_pod(std::get<OutRes>(cases()).a0)})
        : std::holds_alternative<OutTuple>(cases()) ? Pod::choice("OutTuple", {prism_rtl::to_pod(std::get<OutTuple>(cases()).a0)})
        : std::holds_alternative<OutArray>(cases()) ? Pod::choice("OutArray", {prism_rtl::to_pod(std::get<OutArray>(cases()).a0)})
        : std::holds_alternative<OutMap>(cases()) ? Pod::choice("OutMap", {prism_rtl::to_pod(std::get<OutMap>(cases()).a0), prism_rtl::to_pod(std::get<OutMap>(cases()).a1)})
        : std::holds_alternative<OutFn>(cases()) ? Pod::choice("OutFn", {prism_rtl::to_pod(std::get<OutFn>(cases()).a0), prism_rtl::to_pod(std::get<OutFn>(cases()).a1)})
        : std::holds_alternative<OutJobFn>(cases()) ? Pod::choice("OutJobFn", {prism_rtl::to_pod(std::get<OutJobFn>(cases()).a0), prism_rtl::to_pod(std::get<OutJobFn>(cases()).a1)})
        : std::holds_alternative<OutJob>(cases()) ? Pod::choice("OutJob", {prism_rtl::to_pod(std::get<OutJob>(cases()).a0)})
        : std::holds_alternative<OutEvent>(cases()) ? Pod::choice("OutEvent", {prism_rtl::to_pod(std::get<OutEvent>(cases()).a0)})
        : std::holds_alternative<OutDyn>(cases()) ? Pod::choice("OutDyn", {prism_rtl::to_pod(std::get<OutDyn>(cases()).a0)})
        : std::holds_alternative<OutGen>(cases()) ? Pod::choice("OutGen", {prism_rtl::to_pod(std::get<OutGen>(cases()).a0)})
        : std::holds_alternative<OutRc>(cases()) ? Pod::choice("OutRc", {prism_rtl::to_pod(std::get<OutRc>(cases()).a0)})
        : std::holds_alternative<OutRef>(cases()) ? Pod::choice("OutRef", {prism_rtl::to_pod(std::get<OutRef>(cases()).a0)})
        : std::holds_alternative<OutPod>(cases()) ? Pod::choice("OutPod", {})
        : std::holds_alternative<OutShowAny>(cases()) ? Pod::choice("OutShowAny", {})
        : std::holds_alternative<OutHold>(cases()) ? Pod::choice("OutHold", {prism_rtl::to_pod(std::get<OutHold>(cases()).a0)})
        : std::holds_alternative<OutStamped>(cases()) ? Pod::choice("OutStamped", {prism_rtl::to_pod(std::get<OutStamped>(cases()).a0)})
        : std::holds_alternative<OutSnapshot>(cases()) ? Pod::choice("OutSnapshot", {prism_rtl::to_pod(std::get<OutSnapshot>(cases()).a0)})
        : std::holds_alternative<OutDefer>(cases()) ? Pod::choice("OutDefer", {prism_rtl::to_pod(std::get<OutDefer>(cases()).a0)})
        : std::holds_alternative<OutWeak>(cases()) ? Pod::choice("OutWeak", {prism_rtl::to_pod(std::get<OutWeak>(cases()).a0)})
        : std::holds_alternative<OutCell>(cases()) ? Pod::choice("OutCell", {prism_rtl::to_pod(std::get<OutCell>(cases()).a0)})
        : std::holds_alternative<OutWakes>(cases()) ? Pod::choice("OutWakes", {})
        : std::holds_alternative<OutCount>(cases()) ? Pod::choice("OutCount", {})
        : std::holds_alternative<OutObj>(cases()) ? Pod::choice("OutObj", {prism_rtl::to_pod(std::get<OutObj>(cases()).a0)})
        : std::holds_alternative<OutSlice>(cases()) ? Pod::choice("OutSlice", {prism_rtl::to_pod(std::get<OutSlice>(cases()).a0)})
        : std::holds_alternative<OutPort>(cases()) ? Pod::choice("OutPort", {prism_rtl::to_pod(std::get<OutPort>(cases()).a0)})
        : std::holds_alternative<OutLive>(cases()) ? Pod::choice("OutLive", {prism_rtl::to_pod(std::get<OutLive>(cases()).a0)})
        : std::holds_alternative<OutQuantified>(cases()) ? Pod::choice("OutQuantified", {prism_rtl::to_pod(std::get<OutQuantified>(cases()).a0)})
        : std::holds_alternative<OutTurn>(cases()) ? Pod::choice("OutTurn", {})
        : std::holds_alternative<OutRefused>(cases()) ? Pod::choice("OutRefused", {prism_rtl::to_pod(std::get<OutRefused>(cases()).a0)})
        : Pod();
}

Result<OutTy> OutTy::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "OutNat" && c->args.size() == 0) return OutTy(OutNat{});
        if (c->ctor == "OutInt" && c->args.size() == 0) return OutTy(OutInt{});
        if (c->ctor == "OutU8" && c->args.size() == 0) return OutTy(OutU8{});
        if (c->ctor == "OutFloat" && c->args.size() == 0) return OutTy(OutFloat{});
        if (c->ctor == "OutBool" && c->args.size() == 0) return OutTy(OutBool{});
        if (c->ctor == "OutChar" && c->args.size() == 0) return OutTy(OutChar{});
        if (c->ctor == "OutText" && c->args.size() == 0) return OutTy(OutText{});
        if (c->ctor == "OutCursor" && c->args.size() == 0) return OutTy(OutCursor{});
        if (c->ctor == "OutRegex" && c->args.size() == 0) return OutTy(OutRegex{});
        if (c->ctor == "OutReplacement" && c->args.size() == 0) return OutTy(OutReplacement{});
        if (c->ctor == "OutUnit" && c->args.size() == 0) return OutTy(OutUnit{});
        if (c->ctor == "OutPath" && c->args.size() == 0) return OutTy(OutPath{});
        if (c->ctor == "OutDuration" && c->args.size() == 0) return OutTy(OutDuration{});
        if (c->ctor == "OutError" && c->args.size() == 0) return OutTy(OutError{});
        if (c->ctor == "OutNamed" && c->args.size() == 2) return OutTy(OutNamed{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Array<OutTy>>(c->args[1]))});
        if (c->ctor == "OutOpt" && c->args.size() == 1) return OutTy(OutOpt{TRY(prism_rtl::from_pod<prism_rtl::Rc<const OutTy>>(c->args[0]))});
        if (c->ctor == "OutRes" && c->args.size() == 1) return OutTy(OutRes{TRY(prism_rtl::from_pod<prism_rtl::Rc<const OutTy>>(c->args[0]))});
        if (c->ctor == "OutTuple" && c->args.size() == 1) return OutTy(OutTuple{TRY(prism_rtl::from_pod<Array<OutTy>>(c->args[0]))});
        if (c->ctor == "OutArray" && c->args.size() == 1) return OutTy(OutArray{TRY(prism_rtl::from_pod<prism_rtl::Rc<const OutTy>>(c->args[0]))});
        if (c->ctor == "OutMap" && c->args.size() == 2) return OutTy(OutMap{TRY(prism_rtl::from_pod<prism_rtl::Rc<const OutTy>>(c->args[0])), TRY(prism_rtl::from_pod<prism_rtl::Rc<const OutTy>>(c->args[1]))});
        if (c->ctor == "OutFn" && c->args.size() == 2) return OutTy(OutFn{TRY(prism_rtl::from_pod<Array<OutTy>>(c->args[0])), TRY(prism_rtl::from_pod<prism_rtl::Rc<const OutTy>>(c->args[1]))});
        if (c->ctor == "OutJobFn" && c->args.size() == 2) return OutTy(OutJobFn{TRY(prism_rtl::from_pod<prism_rtl::Rc<const OutTy>>(c->args[0])), TRY(prism_rtl::from_pod<prism_rtl::Rc<const OutTy>>(c->args[1]))});
        if (c->ctor == "OutJob" && c->args.size() == 1) return OutTy(OutJob{TRY(prism_rtl::from_pod<prism_rtl::Rc<const OutTy>>(c->args[0]))});
        if (c->ctor == "OutEvent" && c->args.size() == 1) return OutTy(OutEvent{TRY(prism_rtl::from_pod<prism_rtl::Rc<const OutTy>>(c->args[0]))});
        if (c->ctor == "OutDyn" && c->args.size() == 1) return OutTy(OutDyn{TRY(prism_rtl::from_pod<prism_rtl::Rc<const OutTy>>(c->args[0]))});
        if (c->ctor == "OutGen" && c->args.size() == 1) return OutTy(OutGen{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "OutRc" && c->args.size() == 1) return OutTy(OutRc{TRY(prism_rtl::from_pod<prism_rtl::Rc<const OutTy>>(c->args[0]))});
        if (c->ctor == "OutRef" && c->args.size() == 1) return OutTy(OutRef{TRY(prism_rtl::from_pod<prism_rtl::Rc<const OutTy>>(c->args[0]))});
        if (c->ctor == "OutPod" && c->args.size() == 0) return OutTy(OutPod{});
        if (c->ctor == "OutShowAny" && c->args.size() == 0) return OutTy(OutShowAny{});
        if (c->ctor == "OutHold" && c->args.size() == 1) return OutTy(OutHold{TRY(prism_rtl::from_pod<prism_rtl::Rc<const OutTy>>(c->args[0]))});
        if (c->ctor == "OutStamped" && c->args.size() == 1) return OutTy(OutStamped{TRY(prism_rtl::from_pod<prism_rtl::Rc<const OutTy>>(c->args[0]))});
        if (c->ctor == "OutSnapshot" && c->args.size() == 1) return OutTy(OutSnapshot{TRY(prism_rtl::from_pod<prism_rtl::Rc<const OutTy>>(c->args[0]))});
        if (c->ctor == "OutDefer" && c->args.size() == 1) return OutTy(OutDefer{TRY(prism_rtl::from_pod<prism_rtl::Rc<const OutTy>>(c->args[0]))});
        if (c->ctor == "OutWeak" && c->args.size() == 1) return OutTy(OutWeak{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "OutCell" && c->args.size() == 1) return OutTy(OutCell{TRY(prism_rtl::from_pod<prism_rtl::Rc<const OutTy>>(c->args[0]))});
        if (c->ctor == "OutWakes" && c->args.size() == 0) return OutTy(OutWakes{});
        if (c->ctor == "OutCount" && c->args.size() == 0) return OutTy(OutCount{});
        if (c->ctor == "OutObj" && c->args.size() == 1) return OutTy(OutObj{TRY(prism_rtl::from_pod<prism_rtl::Rc<const OutTy>>(c->args[0]))});
        if (c->ctor == "OutSlice" && c->args.size() == 1) return OutTy(OutSlice{TRY(prism_rtl::from_pod<prism_rtl::Rc<const OutTy>>(c->args[0]))});
        if (c->ctor == "OutPort" && c->args.size() == 1) return OutTy(OutPort{TRY(prism_rtl::from_pod<prism_rtl::Rc<const OutTy>>(c->args[0]))});
        if (c->ctor == "OutLive" && c->args.size() == 1) return OutTy(OutLive{TRY(prism_rtl::from_pod<prism_rtl::Rc<const OutTy>>(c->args[0]))});
        if (c->ctor == "OutQuantified" && c->args.size() == 1) return OutTy(OutQuantified{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "OutTurn" && c->args.size() == 0) return OutTy(OutTurn{});
        if (c->ctor == "OutRefused" && c->args.size() == 1) return OutTy(OutRefused{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
    }
    return mismatch<OutTy>("a OutTy", p);
}


bool Pa::PaCtor::operator==(const PaCtor& o) const { return a0 == o.a0 && a1 == o.a1; }

bool Pa::PaRecord::operator==(const PaRecord& o) const { return a0 == o.a0 && a1 == o.a1 && a2 == o.a2; }

bool Pa::PaTuple::operator==(const PaTuple& o) const { return a0 == o.a0; }

bool Pa::PaSlice::operator==(const PaSlice& o) const { return a0 == o.a0; }

bool Pa::PaTyped::operator==(const PaTyped& o) const { return a0 == o.a0 && a1 == o.a1; }

void Pa::show(Printer& p) const {
    if (auto c = std::get_if<PaWild>(&cases())) p.choice("PaWild", {});
    else if (auto c = std::get_if<PaBind>(&cases())) p.choice("PaBind", {c->a0});
    else if (auto c = std::get_if<PaMut>(&cases())) p.choice("PaMut", {c->a0});
    else if (auto c = std::get_if<PaCtor>(&cases())) p.choice("PaCtor", {c->a0, c->a1});
    else if (auto c = std::get_if<PaUnit>(&cases())) p.choice("PaUnit", {c->a0});
    else if (auto c = std::get_if<PaRecord>(&cases())) p.choice("PaRecord", {c->a0, c->a1, c->a2});
    else if (auto c = std::get_if<PaTuple>(&cases())) p.choice("PaTuple", {c->a0});
    else if (auto c = std::get_if<PaChar>(&cases())) p.choice("PaChar", {c->a0});
    else if (auto c = std::get_if<PaBool>(&cases())) p.choice("PaBool", {c->a0});
    else if (auto c = std::get_if<PaIndex>(&cases())) p.choice("PaIndex", {c->a0});
    else if (auto c = std::get_if<PaConst>(&cases())) p.choice("PaConst", {c->a0});
    else if (auto c = std::get_if<PaSlice>(&cases())) p.choice("PaSlice", {c->a0});
    else if (auto c = std::get_if<PaRest>(&cases())) p.choice("PaRest", {c->a0});
    else if (auto c = std::get_if<PaTyped>(&cases())) p.choice("PaTyped", {c->a0, c->a1});
}

Pod Pa::to_pod() const {
    return std::holds_alternative<PaWild>(cases()) ? Pod::choice("PaWild", {})
        : std::holds_alternative<PaBind>(cases()) ? Pod::choice("PaBind", {prism_rtl::to_pod(std::get<PaBind>(cases()).a0)})
        : std::holds_alternative<PaMut>(cases()) ? Pod::choice("PaMut", {prism_rtl::to_pod(std::get<PaMut>(cases()).a0)})
        : std::holds_alternative<PaCtor>(cases()) ? Pod::choice("PaCtor", {prism_rtl::to_pod(std::get<PaCtor>(cases()).a0), prism_rtl::to_pod(std::get<PaCtor>(cases()).a1)})
        : std::holds_alternative<PaUnit>(cases()) ? Pod::choice("PaUnit", {prism_rtl::to_pod(std::get<PaUnit>(cases()).a0)})
        : std::holds_alternative<PaRecord>(cases()) ? Pod::choice("PaRecord", {prism_rtl::to_pod(std::get<PaRecord>(cases()).a0), prism_rtl::to_pod(std::get<PaRecord>(cases()).a1), prism_rtl::to_pod(std::get<PaRecord>(cases()).a2)})
        : std::holds_alternative<PaTuple>(cases()) ? Pod::choice("PaTuple", {prism_rtl::to_pod(std::get<PaTuple>(cases()).a0)})
        : std::holds_alternative<PaChar>(cases()) ? Pod::choice("PaChar", {prism_rtl::to_pod(std::get<PaChar>(cases()).a0)})
        : std::holds_alternative<PaBool>(cases()) ? Pod::choice("PaBool", {prism_rtl::to_pod(std::get<PaBool>(cases()).a0)})
        : std::holds_alternative<PaIndex>(cases()) ? Pod::choice("PaIndex", {prism_rtl::to_pod(std::get<PaIndex>(cases()).a0)})
        : std::holds_alternative<PaConst>(cases()) ? Pod::choice("PaConst", {prism_rtl::to_pod(std::get<PaConst>(cases()).a0)})
        : std::holds_alternative<PaSlice>(cases()) ? Pod::choice("PaSlice", {prism_rtl::to_pod(std::get<PaSlice>(cases()).a0)})
        : std::holds_alternative<PaRest>(cases()) ? Pod::choice("PaRest", {prism_rtl::to_pod(std::get<PaRest>(cases()).a0)})
        : std::holds_alternative<PaTyped>(cases()) ? Pod::choice("PaTyped", {prism_rtl::to_pod(std::get<PaTyped>(cases()).a0), prism_rtl::to_pod(std::get<PaTyped>(cases()).a1)})
        : Pod();
}

Result<Pa> Pa::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "PaWild" && c->args.size() == 0) return Pa(PaWild{});
        if (c->ctor == "PaBind" && c->args.size() == 1) return Pa(PaBind{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "PaMut" && c->args.size() == 1) return Pa(PaMut{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "PaCtor" && c->args.size() == 2) return Pa(PaCtor{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Array<Pa>>(c->args[1]))});
        if (c->ctor == "PaUnit" && c->args.size() == 1) return Pa(PaUnit{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "PaRecord" && c->args.size() == 3) return Pa(PaRecord{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Array<std::tuple<Text, Pa>>>(c->args[1])), TRY(prism_rtl::from_pod<bool>(c->args[2]))});
        if (c->ctor == "PaTuple" && c->args.size() == 1) return Pa(PaTuple{TRY(prism_rtl::from_pod<Array<Pa>>(c->args[0]))});
        if (c->ctor == "PaChar" && c->args.size() == 1) return Pa(PaChar{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "PaBool" && c->args.size() == 1) return Pa(PaBool{TRY(prism_rtl::from_pod<bool>(c->args[0]))});
        if (c->ctor == "PaIndex" && c->args.size() == 1) return Pa(PaIndex{TRY(prism_rtl::from_pod<Nat>(c->args[0]))});
        if (c->ctor == "PaConst" && c->args.size() == 1) return Pa(PaConst{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "PaSlice" && c->args.size() == 1) return Pa(PaSlice{TRY(prism_rtl::from_pod<Array<Pa>>(c->args[0]))});
        if (c->ctor == "PaRest" && c->args.size() == 1) return Pa(PaRest{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "PaTyped" && c->args.size() == 2) return Pa(PaTyped{TRY(prism_rtl::from_pod<prism_rtl::Rc<const Pa>>(c->args[0])), TRY(prism_rtl::from_pod<OutTy>(c->args[1]))});
    }
    return mismatch<Pa>("a Pa", p);
}


void Pos_::show(Printer& p) const {
    p.record("Pos", {{"scope", scope_p}, {"at", at_p}});
}

Pod Pos_::to_pod() const {
    return Pod::record("Pos", {{"scope", prism_rtl::to_pod(scope_p)}, {"at", prism_rtl::to_pod(at_p)}});
}

Result<Pos_> Pos_::from_pod(const Pod& whole) {
    return Pos_{.scope_p = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "scope")))), .at_p = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "at"))))};
}


bool ProgDef::operator==(const ProgDef& o) const { return name_p == o.name_p && prism_p == o.prism_p && node_p == o.node_p && params_p == o.params_p && fallible_p == o.fallible_p && world_p == o.world_p; }

void ProgDef::show(Printer& p) const {
    p.record("ProgDef", {{"name", name_p}, {"prism", prism_p}, {"node", node_p}, {"params", params_p}, {"fallible", fallible_p}, {"world", world_p}});
}

Pod ProgDef::to_pod() const {
    return Pod::record("ProgDef", {{"name", prism_rtl::to_pod(name_p)}, {"prism", prism_rtl::to_pod(prism_p)}, {"node", prism_rtl::to_pod(node_p)}, {"params", prism_rtl::to_pod(params_p)}, {"fallible", prism_rtl::to_pod(fallible_p)}, {"world", prism_rtl::to_pod(world_p)}});
}

Result<ProgDef> ProgDef::from_pod(const Pod& whole) {
    return ProgDef{.name_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .prism_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "prism")))), .node_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "node")))), .params_p = TRY(prism_rtl::from_pod<Array<std::tuple<Text, OutTy>>>(TRY(crate::prelude::field(whole, "params")))), .fallible_p = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "fallible")))), .world_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "world"))))};
}


void Recv::show(Printer& p) const {
    if (auto c = std::get_if<RecvRc>(&cases())) p.choice("RecvRc", {});
    else if (auto c = std::get_if<RecvRef>(&cases())) p.choice("RecvRef", {});
    else if (auto c = std::get_if<RecvOwned>(&cases())) p.choice("RecvOwned", {});
}

Pod Recv::to_pod() const {
    return std::holds_alternative<RecvRc>(cases()) ? Pod::choice("RecvRc", {})
        : std::holds_alternative<RecvRef>(cases()) ? Pod::choice("RecvRef", {})
        : std::holds_alternative<RecvOwned>(cases()) ? Pod::choice("RecvOwned", {})
        : Pod();
}

Result<Recv> Recv::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "RecvRc" && c->args.size() == 0) return Recv(RecvRc{});
        if (c->ctor == "RecvRef" && c->args.size() == 0) return Recv(RecvRef{});
        if (c->ctor == "RecvOwned" && c->args.size() == 0) return Recv(RecvOwned{});
    }
    return mismatch<Recv>("a Recv", p);
}


void RowDef::show(Printer& p) const {
    p.record("RowDef", {{"name", name_p}, {"prism", prism_p}, {"cases", cases_p}, {"pod", pod_p}, {"doc", doc_p}, {"eq", eq_p}, {"level", level_p}, {"deep", deep_p}});
}

Pod RowDef::to_pod() const {
    return Pod::record("RowDef", {{"name", prism_rtl::to_pod(name_p)}, {"prism", prism_rtl::to_pod(prism_p)}, {"cases", prism_rtl::to_pod(cases_p)}, {"pod", prism_rtl::to_pod(pod_p)}, {"doc", prism_rtl::to_pod(doc_p)}, {"eq", prism_rtl::to_pod(eq_p)}, {"level", prism_rtl::to_pod(level_p)}, {"deep", prism_rtl::to_pod(deep_p)}});
}

Result<RowDef> RowDef::from_pod(const Pod& whole) {
    return RowDef{.name_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .prism_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "prism")))), .cases_p = TRY(prism_rtl::from_pod<Array<std::tuple<Text, Text>>>(TRY(crate::prelude::field(whole, "cases")))), .pod_p = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "pod")))), .doc_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "doc")))), .eq_p = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "eq")))), .level_p = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "level")))), .deep_p = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "deep"))))};
}


void RowKind::show(Printer& p) const {
    if (auto c = std::get_if<ForRow>(&cases())) p.choice("ForRow", {});
    else if (auto c = std::get_if<GenerationRow>(&cases())) p.choice("GenerationRow", {});
    else if (auto c = std::get_if<NotARow>(&cases())) p.choice("NotARow", {});
}

Pod RowKind::to_pod() const {
    return std::holds_alternative<ForRow>(cases()) ? Pod::choice("ForRow", {})
        : std::holds_alternative<GenerationRow>(cases()) ? Pod::choice("GenerationRow", {})
        : std::holds_alternative<NotARow>(cases()) ? Pod::choice("NotARow", {})
        : Pod();
}

Result<RowKind> RowKind::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "ForRow" && c->args.size() == 0) return RowKind(ForRow{});
        if (c->ctor == "GenerationRow" && c->args.size() == 0) return RowKind(GenerationRow{});
        if (c->ctor == "NotARow" && c->args.size() == 0) return RowKind(NotARow{});
    }
    return mismatch<RowKind>("a RowKind", p);
}


void Shown::show(Printer& p) const {
    if (auto c = std::get_if<ShownOwn>(&cases())) p.choice("ShownOwn", {});
    else if (auto c = std::get_if<ShownDerived>(&cases())) p.choice("ShownDerived", {});
    else if (auto c = std::get_if<NotShown>(&cases())) p.choice("NotShown", {});
}

Pod Shown::to_pod() const {
    return std::holds_alternative<ShownOwn>(cases()) ? Pod::choice("ShownOwn", {})
        : std::holds_alternative<ShownDerived>(cases()) ? Pod::choice("ShownDerived", {})
        : std::holds_alternative<NotShown>(cases()) ? Pod::choice("NotShown", {})
        : Pod();
}

Result<Shown> Shown::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "ShownOwn" && c->args.size() == 0) return Shown(ShownOwn{});
        if (c->ctor == "ShownDerived" && c->args.size() == 0) return Shown(ShownDerived{});
        if (c->ctor == "NotShown" && c->args.size() == 0) return Shown(NotShown{});
    }
    return mismatch<Shown>("a Shown", p);
}


bool TagDef::operator==(const TagDef& o) const { return name_p == o.name_p && tag_name_p == o.tag_name_p && fields_p == o.fields_p && doc_p == o.doc_p && pod_p == o.pod_p && eq_p == o.eq_p; }

void TagDef::show(Printer& p) const {
    p.record("TagDef", {{"name", name_p}, {"tagName", tag_name_p}, {"fields", fields_p}, {"doc", doc_p}, {"pod", pod_p}, {"eq", eq_p}});
}

Pod TagDef::to_pod() const {
    return Pod::record("TagDef", {{"name", prism_rtl::to_pod(name_p)}, {"tagName", prism_rtl::to_pod(tag_name_p)}, {"fields", prism_rtl::to_pod(fields_p)}, {"doc", prism_rtl::to_pod(doc_p)}, {"pod", prism_rtl::to_pod(pod_p)}, {"eq", prism_rtl::to_pod(eq_p)}});
}

Result<TagDef> TagDef::from_pod(const Pod& whole) {
    return TagDef{.name_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .tag_name_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "tagName")))), .fields_p = TRY(prism_rtl::from_pod<Array<std::tuple<Text, Text, OutTy>>>(TRY(crate::prelude::field(whole, "fields")))), .doc_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "doc")))), .pod_p = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "pod")))), .eq_p = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "eq"))))};
}


bool TraitDef::operator==(const TraitDef& o) const { return name_p == o.name_p && methods_p == o.methods_p && defaults_p == o.defaults_p && doc_p == o.doc_p; }

void TraitDef::show(Printer& p) const {
    p.record("TraitDef", {{"name", name_p}, {"methods", methods_p}, {"defaults", defaults_p}, {"doc", doc_p}});
}

Pod TraitDef::to_pod() const {
    return Pod::record("TraitDef", {{"name", prism_rtl::to_pod(name_p)}, {"methods", prism_rtl::to_pod(methods_p)}, {"defaults", prism_rtl::to_pod(defaults_p)}, {"doc", prism_rtl::to_pod(doc_p)}});
}

Result<TraitDef> TraitDef::from_pod(const Pod& whole) {
    return TraitDef{.name_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .methods_p = TRY(prism_rtl::from_pod<Array<FnDef>>(TRY(crate::prelude::field(whole, "methods")))), .defaults_p = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "defaults")))), .doc_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "doc"))))};
}


bool TyDef::operator==(const TyDef& o) const { return name_p == o.name_p && prism_p == o.prism_p && params_p == o.params_p && shape_p == o.shape_p && cases_p == o.cases_p && eq_p == o.eq_p && ord_p == o.ord_p && show_p == o.show_p && pod_p == o.pod_p && doc_p == o.doc_p; }

void TyDef::show(Printer& p) const {
    p.record("TyDef", {{"name", name_p}, {"prism", prism_p}, {"params", params_p}, {"shape", shape_p}, {"cases", cases_p}, {"eq", eq_p}, {"ord", ord_p}, {"show", show_p}, {"pod", pod_p}, {"doc", doc_p}});
}

Pod TyDef::to_pod() const {
    return Pod::record("TyDef", {{"name", prism_rtl::to_pod(name_p)}, {"prism", prism_rtl::to_pod(prism_p)}, {"params", prism_rtl::to_pod(params_p)}, {"shape", prism_rtl::to_pod(shape_p)}, {"cases", prism_rtl::to_pod(cases_p)}, {"eq", prism_rtl::to_pod(eq_p)}, {"ord", prism_rtl::to_pod(ord_p)}, {"show", prism_rtl::to_pod(show_p)}, {"pod", prism_rtl::to_pod(pod_p)}, {"doc", prism_rtl::to_pod(doc_p)}});
}

Result<TyDef> TyDef::from_pod(const Pod& whole) {
    return TyDef{.name_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .prism_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "prism")))), .params_p = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "params")))), .shape_p = TRY(prism_rtl::from_pod<TyShape>(TRY(crate::prelude::field(whole, "shape")))), .cases_p = TRY(prism_rtl::from_pod<Array<CaseDef>>(TRY(crate::prelude::field(whole, "cases")))), .eq_p = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "eq")))), .ord_p = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "ord")))), .show_p = TRY(prism_rtl::from_pod<Shown>(TRY(crate::prelude::field(whole, "show")))), .pod_p = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "pod")))), .doc_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "doc"))))};
}


void TyShape::show(Printer& p) const {
    if (auto c = std::get_if<ShapeRecord>(&cases())) p.choice("ShapeRecord", {});
    else if (auto c = std::get_if<ShapeChoice>(&cases())) p.choice("ShapeChoice", {});
    else if (auto c = std::get_if<ShapeNewtype>(&cases())) p.choice("ShapeNewtype", {});
    else if (auto c = std::get_if<ShapeUnit>(&cases())) p.choice("ShapeUnit", {});
}

Pod TyShape::to_pod() const {
    return std::holds_alternative<ShapeRecord>(cases()) ? Pod::choice("ShapeRecord", {})
        : std::holds_alternative<ShapeChoice>(cases()) ? Pod::choice("ShapeChoice", {})
        : std::holds_alternative<ShapeNewtype>(cases()) ? Pod::choice("ShapeNewtype", {})
        : std::holds_alternative<ShapeUnit>(cases()) ? Pod::choice("ShapeUnit", {})
        : Pod();
}

Result<TyShape> TyShape::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "ShapeRecord" && c->args.size() == 0) return TyShape(ShapeRecord{});
        if (c->ctor == "ShapeChoice" && c->args.size() == 0) return TyShape(ShapeChoice{});
        if (c->ctor == "ShapeNewtype" && c->args.size() == 0) return TyShape(ShapeNewtype{});
        if (c->ctor == "ShapeUnit" && c->args.size() == 0) return TyShape(ShapeUnit{});
    }
    return mismatch<TyShape>("a TyShape", p);
}


void UnOp::show(Printer& p) const {
    if (auto c = std::get_if<OpNot>(&cases())) p.choice("OpNot", {});
    else if (auto c = std::get_if<OpNeg>(&cases())) p.choice("OpNeg", {});
}

Pod UnOp::to_pod() const {
    return std::holds_alternative<OpNot>(cases()) ? Pod::choice("OpNot", {})
        : std::holds_alternative<OpNeg>(cases()) ? Pod::choice("OpNeg", {})
        : Pod();
}

Result<UnOp> UnOp::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "OpNot" && c->args.size() == 0) return UnOp(OpNot{});
        if (c->ctor == "OpNeg" && c->args.size() == 0) return UnOp(OpNeg{});
    }
    return mismatch<UnOp>("a UnOp", p);
}


bool XArm::operator==(const XArm& o) const { return pat_p == o.pat_p && conds_p == o.conds_p && body_p == o.body_p; }

void XArm::show(Printer& p) const {
    p.record("XArm", {{"pat", pat_p}, {"conds", conds_p}, {"body", body_p}});
}

Pod XArm::to_pod() const {
    return Pod::record("XArm", {{"pat", prism_rtl::to_pod(pat_p)}, {"conds", prism_rtl::to_pod(conds_p)}, {"body", prism_rtl::to_pod(body_p)}});
}

Result<XArm> XArm::from_pod(const Pod& whole) {
    return XArm{.pat_p = TRY(prism_rtl::from_pod<Pa>(TRY(crate::prelude::field(whole, "pat")))), .conds_p = TRY(prism_rtl::from_pod<Array<Cc>>(TRY(crate::prelude::field(whole, "conds")))), .body_p = TRY(prism_rtl::from_pod<Ex>(TRY(crate::prelude::field(whole, "body"))))};
}


/// BinOpText: fn BinOp -> Text
Text bin_op_text_f(const BinOp& bin_op0) {
    if (prism_rtl::is<BinOp::OpAdd>(bin_op0)) {
        return Text::lit("+");
    }
    if (prism_rtl::is<BinOp::OpSub>(bin_op0)) {
        return Text::lit("-");
    }
    if (prism_rtl::is<BinOp::OpMul>(bin_op0)) {
        return Text::lit("*");
    }
    if (prism_rtl::is<BinOp::OpDiv>(bin_op0)) {
        return Text::lit("/");
    }
    if (prism_rtl::is<BinOp::OpEq>(bin_op0)) {
        return Text::lit("==");
    }
    if (prism_rtl::is<BinOp::OpNe>(bin_op0)) {
        return Text::lit("!=");
    }
    if (prism_rtl::is<BinOp::OpLt>(bin_op0)) {
        return Text::lit("<");
    }
    if (prism_rtl::is<BinOp::OpLe>(bin_op0)) {
        return Text::lit("<=");
    }
    if (prism_rtl::is<BinOp::OpGt>(bin_op0)) {
        return Text::lit(">");
    }
    if (prism_rtl::is<BinOp::OpGe>(bin_op0)) {
        return Text::lit(">=");
    }
    if (prism_rtl::is<BinOp::OpAnd>(bin_op0)) {
        return Text::lit("&&");
    }
    if (prism_rtl::is<BinOp::OpOr>(bin_op0)) {
        return Text::lit("||");
    }
    prism_rtl::unreachable("no arm matched");
}


/// UnOpText: fn UnOp -> Text
Text un_op_text_f(const UnOp& un_op0) {
    if (prism_rtl::is<UnOp::OpNot>(un_op0)) {
        return Text::lit("!");
    }
    if (prism_rtl::is<UnOp::OpNeg>(un_op0)) {
        return Text::lit("-");
    }
    prism_rtl::unreachable("no arm matched");
}


/// ?BinOpOf: fn Text -> ?BinOp
std::optional<BinOp> bin_op_of_o(const Text& text0) {
    {
        auto&& c0_0 = text0;
        if (c0_0 == Text::lit("+")) {
            return std::optional(BinOp(BinOp::OpAdd{}));
        }
    }
    {
        auto&& c1_0 = text0;
        if (c1_0 == Text::lit("-")) {
            return std::optional(BinOp(BinOp::OpSub{}));
        }
    }
    {
        auto&& c2_0 = text0;
        if (c2_0 == Text::lit("*")) {
            return std::optional(BinOp(BinOp::OpMul{}));
        }
    }
    {
        auto&& c3_0 = text0;
        if (c3_0 == Text::lit("/")) {
            return std::optional(BinOp(BinOp::OpDiv{}));
        }
    }
    {
        auto&& c4_0 = text0;
        if (c4_0 == Text::lit("==")) {
            return std::optional(BinOp(BinOp::OpEq{}));
        }
    }
    {
        auto&& c5_0 = text0;
        if (c5_0 == Text::lit("!=")) {
            return std::optional(BinOp(BinOp::OpNe{}));
        }
    }
    {
        auto&& c6_0 = text0;
        if (c6_0 == Text::lit("<")) {
            return std::optional(BinOp(BinOp::OpLt{}));
        }
    }
    {
        auto&& c7_0 = text0;
        if (c7_0 == Text::lit("<=")) {
            return std::optional(BinOp(BinOp::OpLe{}));
        }
    }
    {
        auto&& c8_0 = text0;
        if (c8_0 == Text::lit(">")) {
            return std::optional(BinOp(BinOp::OpGt{}));
        }
    }
    {
        auto&& c9_0 = text0;
        if (c9_0 == Text::lit(">=")) {
            return std::optional(BinOp(BinOp::OpGe{}));
        }
    }
    {
        return std::optional<BinOp>{};
    }
}


/// let pos0
Pos_ pos0_p() {
    return Pos_{.scope_p = Nat(0u), .at_p = Nat(0u)};
}


/// NextPos: fn Pos -> Pos
Pos_ next_pos_f(const Pos_& p_p0) {
    Pos_ this_ = p_p0;
    this_.at_p = this_.at_p + Nat(1u);
    return this_;
}


/// ScopePos: fn Nat -> Pos
Pos_ scope_pos_f(const Nat& k_p0) {
    return Pos_{.scope_p = k_p0, .at_p = Nat(0u)};
}


/// PlaceText: fn Pos -> Text
Text place_text_f(const Pos_& p_p0) {
    return p_p0.scope_p == Nat(0u)
        ? prism_rtl::cat(p_p0.at_p)
        : prism_rtl::cat("h", p_p0.scope_p, "_", p_p0.at_p);
}


/// ExReads: unbounded fn Ex, Text -> Bool
bool ex_reads_f(const Ex& x_p0, const Text& n_p1) {
    if (prism_rtl::is<Ex::XVar>(x_p0)) {
        auto&& m_p2 = prism_rtl::as<Ex::XVar>(x_p0).a0;
        return m_p2 == n_p1;
    }
    if (prism_rtl::is<Ex::XRef>(x_p0)) {
        auto&& y_p3 = prism_rtl::as<Ex::XRef>(x_p0).a0;
        return ex_reads_f(prism_rtl::deref(prism_rtl::deref(y_p3)), n_p1);
    }
    if (prism_rtl::is<Ex::XRefMut>(x_p0)) {
        auto&& y_p4 = prism_rtl::as<Ex::XRefMut>(x_p0).a0;
        return ex_reads_f(prism_rtl::deref(prism_rtl::deref(y_p4)), n_p1);
    }
    if (prism_rtl::is<Ex::XDeref>(x_p0)) {
        auto&& y_p5 = prism_rtl::as<Ex::XDeref>(x_p0).a0;
        return ex_reads_f(prism_rtl::deref(prism_rtl::deref(y_p5)), n_p1);
    }
    if (prism_rtl::is<Ex::XTarget>(x_p0)) {
        auto&& y_p6 = prism_rtl::as<Ex::XTarget>(x_p0).a0;
        return ex_reads_f(prism_rtl::deref(prism_rtl::deref(y_p6)), n_p1);
    }
    if (prism_rtl::is<Ex::XClone>(x_p0)) {
        auto&& y_p7 = prism_rtl::as<Ex::XClone>(x_p0).a0;
        return ex_reads_f(prism_rtl::deref(prism_rtl::deref(y_p7)), n_p1);
    }
    if (prism_rtl::is<Ex::XWeak>(x_p0)) {
        auto&& y_p8 = prism_rtl::as<Ex::XWeak>(x_p0).a0;
        return ex_reads_f(prism_rtl::deref(prism_rtl::deref(y_p8)), n_p1);
    }
    if (prism_rtl::is<Ex::XUpgrade>(x_p0)) {
        auto&& y_p9 = prism_rtl::as<Ex::XUpgrade>(x_p0).a0;
        return ex_reads_f(prism_rtl::deref(prism_rtl::deref(y_p9)), n_p1);
    }
    if (prism_rtl::is<Ex::XBreak>(x_p0)) {
        auto&& y_pa = prism_rtl::as<Ex::XBreak>(x_p0).a1;
        return ex_reads_f(prism_rtl::deref(prism_rtl::deref(y_pa)), n_p1);
    }
    if (prism_rtl::is<Ex::XLater>(x_p0)) {
        auto&& y_pb = prism_rtl::as<Ex::XLater>(x_p0).a0;
        return ex_reads_f(prism_rtl::deref(prism_rtl::deref(y_pb)), n_p1);
    }
    if (prism_rtl::is<Ex::XFormatStr>(x_p0)) {
        auto&& ys_pc = prism_rtl::as<Ex::XFormatStr>(x_p0).a0;
        return any_reads_f(ys_pc, n_p1);
    }
    if (prism_rtl::is<Ex::XIsCase>(x_p0)) {
        auto&& y_pd = prism_rtl::as<Ex::XIsCase>(x_p0).a0;
        return ex_reads_f(prism_rtl::deref(prism_rtl::deref(y_pd)), n_p1);
    }
    if (prism_rtl::is<Ex::XCall>(x_p0)) {
        auto&& ys_pe = prism_rtl::as<Ex::XCall>(x_p0).a1;
        return any_reads_f(ys_pe, n_p1);
    }
    if (prism_rtl::is<Ex::XApply>(x_p0)) {
        auto&& f_pf = prism_rtl::as<Ex::XApply>(x_p0).a0;
        auto&& ys_pg = prism_rtl::as<Ex::XApply>(x_p0).a1;
        return ex_reads_f(prism_rtl::deref(prism_rtl::deref(f_pf)), n_p1) || any_reads_f(ys_pg, n_p1);
    }
    if (prism_rtl::is<Ex::XMethod>(x_p0)) {
        auto&& y_ph = prism_rtl::as<Ex::XMethod>(x_p0).a0;
        auto&& ys_pi = prism_rtl::as<Ex::XMethod>(x_p0).a2;
        return ex_reads_f(prism_rtl::deref(prism_rtl::deref(y_ph)), n_p1) || any_reads_f(ys_pi, n_p1);
    }
    if (prism_rtl::is<Ex::XBin>(x_p0)) {
        auto&& a_pj = prism_rtl::as<Ex::XBin>(x_p0).a1;
        auto&& b_pk = prism_rtl::as<Ex::XBin>(x_p0).a2;
        return ex_reads_f(prism_rtl::deref(prism_rtl::deref(a_pj)), n_p1) || ex_reads_f(prism_rtl::deref(prism_rtl::deref(b_pk)), n_p1);
    }
    if (prism_rtl::is<Ex::XUnary>(x_p0)) {
        auto&& y_pl = prism_rtl::as<Ex::XUnary>(x_p0).a1;
        return ex_reads_f(prism_rtl::deref(prism_rtl::deref(y_pl)), n_p1);
    }
    if (prism_rtl::is<Ex::XCtor>(x_p0)) {
        auto&& ys_pm = prism_rtl::as<Ex::XCtor>(x_p0).a1;
        return any_reads_f(ys_pm, n_p1);
    }
    if (prism_rtl::is<Ex::XRecord>(x_p0)) {
        auto&& fs_pn = prism_rtl::as<Ex::XRecord>(x_p0).a1;
        return crate::prelude::run_to_end(crate::prelude::fold_job(fs_pn, false, ({
            auto n_p1x = n_p1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, Ex>>)>>(prism_rtl::rc([=, n_p1x = std::move(n_p1x)](std::tuple<bool, std::tuple<Text, Ex>> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto n_p1xy = n_p1x;
                (crate::prelude::entered(crate::prelude::once_job([=, n_p1xy = std::move(n_p1xy)]() {
                return ({
                    auto f_po = p0;
                    auto&& _y_pp = p1;
                    auto&& y_pp = std::get<1>(_y_pp);
                    (prism_rtl::finished(std::move(f_po) || ex_reads_f(y_pp, n_p1xy)));
                });
            })));
            });
        })));
        })));
    }
    if (prism_rtl::is<Ex::XTuple>(x_p0)) {
        auto&& ys_pq = prism_rtl::as<Ex::XTuple>(x_p0).a0;
        return any_reads_f(ys_pq, n_p1);
    }
    if (prism_rtl::is<Ex::XVec>(x_p0)) {
        auto&& ys_pr = prism_rtl::as<Ex::XVec>(x_p0).a0;
        return any_reads_f(ys_pr, n_p1);
    }
    if (prism_rtl::is<Ex::XFormat>(x_p0)) {
        auto&& ys_ps = prism_rtl::as<Ex::XFormat>(x_p0).a0;
        return any_reads_f(ys_ps, n_p1);
    }
    if (prism_rtl::is<Ex::XMatch>(x_p0)) {
        auto&& y_pt = prism_rtl::as<Ex::XMatch>(x_p0).a0;
        auto&& arms_pu = prism_rtl::as<Ex::XMatch>(x_p0).a1;
        return ex_reads_f(prism_rtl::deref(prism_rtl::deref(y_pt)), n_p1) || arms_read_f(arms_pu, n_p1);
    }
    if (prism_rtl::is<Ex::XChain>(x_p0)) {
        auto&& y_pv = prism_rtl::as<Ex::XChain>(x_p0).a1;
        auto&& arms_p10 = prism_rtl::as<Ex::XChain>(x_p0).a2;
        return ex_reads_f(prism_rtl::deref(prism_rtl::deref(y_pv)), n_p1) || arms_read_f(arms_p10, n_p1);
    }
    if (prism_rtl::is<Ex::XIf>(x_p0)) {
        auto&& c_p11 = prism_rtl::as<Ex::XIf>(x_p0).a0;
        auto&& a_p12 = prism_rtl::as<Ex::XIf>(x_p0).a1;
        auto&& b_p13 = prism_rtl::as<Ex::XIf>(x_p0).a2;
        return (ex_reads_f(prism_rtl::deref(prism_rtl::deref(c_p11)), n_p1) || ex_reads_f(prism_rtl::deref(prism_rtl::deref(a_p12)), n_p1)) || ex_reads_f(prism_rtl::deref(prism_rtl::deref(b_p13)), n_p1);
    }
    if (prism_rtl::is<Ex::XBlock>(x_p0)) {
        auto&& ds_p14 = prism_rtl::as<Ex::XBlock>(x_p0).a0;
        auto&& y_p15 = prism_rtl::as<Ex::XBlock>(x_p0).a1;
        return dos_read_f(ds_p14, n_p1) || ex_reads_f(prism_rtl::deref(prism_rtl::deref(y_p15)), n_p1);
    }
    if (prism_rtl::is<Ex::XLabeled>(x_p0)) {
        auto&& ds_p16 = prism_rtl::as<Ex::XLabeled>(x_p0).a1;
        auto&& y_p17 = prism_rtl::as<Ex::XLabeled>(x_p0).a2;
        return dos_read_f(ds_p16, n_p1) || ex_reads_f(prism_rtl::deref(prism_rtl::deref(y_p17)), n_p1);
    }
    if (prism_rtl::is<Ex::XClosure>(x_p0)) {
        auto&& y_p18 = prism_rtl::as<Ex::XClosure>(x_p0).a2;
        return ex_reads_f(prism_rtl::deref(prism_rtl::deref(y_p18)), n_p1);
    }
    if (prism_rtl::is<Ex::XTry>(x_p0)) {
        auto&& y_p19 = prism_rtl::as<Ex::XTry>(x_p0).a0;
        return ex_reads_f(prism_rtl::deref(prism_rtl::deref(y_p19)), n_p1);
    }
    if (prism_rtl::is<Ex::XField>(x_p0)) {
        auto&& y_p1a = prism_rtl::as<Ex::XField>(x_p0).a0;
        return ex_reads_f(prism_rtl::deref(prism_rtl::deref(y_p1a)), n_p1);
    }
    if (prism_rtl::is<Ex::XPart>(x_p0)) {
        auto&& y_p1b = prism_rtl::as<Ex::XPart>(x_p0).a0;
        return ex_reads_f(prism_rtl::deref(prism_rtl::deref(y_p1b)), n_p1);
    }
    if (prism_rtl::is<Ex::XDecode>(x_p0)) {
        auto&& y_p1c = prism_rtl::as<Ex::XDecode>(x_p0).a1;
        return ex_reads_f(prism_rtl::deref(prism_rtl::deref(y_p1c)), n_p1);
    }
    if (prism_rtl::is<Ex::XCast>(x_p0)) {
        auto&& y_p1d = prism_rtl::as<Ex::XCast>(x_p0).a0;
        return ex_reads_f(prism_rtl::deref(prism_rtl::deref(y_p1d)), n_p1);
    }
    if (prism_rtl::is<Ex::XTyped>(x_p0)) {
        auto&& y_p1e = prism_rtl::as<Ex::XTyped>(x_p0).a0;
        return ex_reads_f(prism_rtl::deref(prism_rtl::deref(y_p1e)), n_p1);
    }
    {
        return false;
    }
}


prism_rtl::Turn<bool> ExReads::cycle() const {
    const auto& x_p0 = this->x_p0;
    const auto& n_p1 = this->n_p1;
    return ({
        prism_rtl::is<Ex::XVar>(x_p0) ? ({
        auto&& m_p2 = prism_rtl::as<Ex::XVar>(x_p0).a0;
        prism_rtl::finished(m_p2 == n_p1);
    })
        : prism_rtl::is<Ex::XRef>(x_p0) ? ({
        auto&& y_p3 = prism_rtl::as<Ex::XRef>(x_p0).a0;
        prism_rtl::more(prism_rtl::rc(ExReads(prism_rtl::deref(prism_rtl::deref(y_p3)), n_p1)));
    })
        : prism_rtl::is<Ex::XRefMut>(x_p0) ? ({
        auto&& y_p4 = prism_rtl::as<Ex::XRefMut>(x_p0).a0;
        prism_rtl::more(prism_rtl::rc(ExReads(prism_rtl::deref(prism_rtl::deref(y_p4)), n_p1)));
    })
        : prism_rtl::is<Ex::XDeref>(x_p0) ? ({
        auto&& y_p5 = prism_rtl::as<Ex::XDeref>(x_p0).a0;
        prism_rtl::more(prism_rtl::rc(ExReads(prism_rtl::deref(prism_rtl::deref(y_p5)), n_p1)));
    })
        : prism_rtl::is<Ex::XTarget>(x_p0) ? ({
        auto&& y_p6 = prism_rtl::as<Ex::XTarget>(x_p0).a0;
        prism_rtl::more(prism_rtl::rc(ExReads(prism_rtl::deref(prism_rtl::deref(y_p6)), n_p1)));
    })
        : prism_rtl::is<Ex::XClone>(x_p0) ? ({
        auto&& y_p7 = prism_rtl::as<Ex::XClone>(x_p0).a0;
        prism_rtl::more(prism_rtl::rc(ExReads(prism_rtl::deref(prism_rtl::deref(y_p7)), n_p1)));
    })
        : prism_rtl::is<Ex::XWeak>(x_p0) ? ({
        auto&& y_p8 = prism_rtl::as<Ex::XWeak>(x_p0).a0;
        prism_rtl::more(prism_rtl::rc(ExReads(prism_rtl::deref(prism_rtl::deref(y_p8)), n_p1)));
    })
        : prism_rtl::is<Ex::XUpgrade>(x_p0) ? ({
        auto&& y_p9 = prism_rtl::as<Ex::XUpgrade>(x_p0).a0;
        prism_rtl::more(prism_rtl::rc(ExReads(prism_rtl::deref(prism_rtl::deref(y_p9)), n_p1)));
    })
        : prism_rtl::is<Ex::XBreak>(x_p0) ? ({
        auto&& y_pa = prism_rtl::as<Ex::XBreak>(x_p0).a1;
        prism_rtl::more(prism_rtl::rc(ExReads(prism_rtl::deref(prism_rtl::deref(y_pa)), n_p1)));
    })
        : prism_rtl::is<Ex::XLater>(x_p0) ? ({
        auto&& y_pb = prism_rtl::as<Ex::XLater>(x_p0).a0;
        prism_rtl::more(prism_rtl::rc(ExReads(prism_rtl::deref(prism_rtl::deref(y_pb)), n_p1)));
    })
        : prism_rtl::is<Ex::XFormatStr>(x_p0) ? ({
        auto&& ys_pc = prism_rtl::as<Ex::XFormatStr>(x_p0).a0;
        prism_rtl::more(prism_rtl::rc(AnyReads(ys_pc, n_p1)));
    })
        : prism_rtl::is<Ex::XIsCase>(x_p0) ? ({
        auto&& y_pd = prism_rtl::as<Ex::XIsCase>(x_p0).a0;
        prism_rtl::more(prism_rtl::rc(ExReads(prism_rtl::deref(prism_rtl::deref(y_pd)), n_p1)));
    })
        : prism_rtl::is<Ex::XCall>(x_p0) ? ({
        auto&& ys_pe = prism_rtl::as<Ex::XCall>(x_p0).a1;
        prism_rtl::more(prism_rtl::rc(AnyReads(ys_pe, n_p1)));
    })
        : prism_rtl::is<Ex::XApply>(x_p0) ? ({
        auto&& f_pf = prism_rtl::as<Ex::XApply>(x_p0).a0;
        auto&& ys_pg = prism_rtl::as<Ex::XApply>(x_p0).a1;
        ({
        auto f_pfx = prism_rtl::deref(prism_rtl::deref(f_pf));
        auto n_p1x = n_p1;
        auto ys_pgx = ys_pg;
        (crate::prelude::call_then(start_ex_reads_f(f_pfx, n_p1x), [=, ys_pgx = std::move(ys_pgx)](bool ex_reads_f_20115) { return prism_rtl::finished(ex_reads_f_20115 || any_reads_f(ys_pgx, n_p1x)); }));
    });
    })
        : prism_rtl::is<Ex::XMethod>(x_p0) ? ({
        auto&& y_ph = prism_rtl::as<Ex::XMethod>(x_p0).a0;
        auto&& ys_pi = prism_rtl::as<Ex::XMethod>(x_p0).a2;
        ({
        auto n_p1x = n_p1;
        auto y_phx = prism_rtl::deref(prism_rtl::deref(y_ph));
        auto ys_pix = ys_pi;
        (crate::prelude::call_then(start_ex_reads_f(y_phx, n_p1x), [=, ys_pix = std::move(ys_pix)](bool ex_reads_f_20175) { return prism_rtl::finished(ex_reads_f_20175 || any_reads_f(ys_pix, n_p1x)); }));
    });
    })
        : prism_rtl::is<Ex::XBin>(x_p0) ? ({
        auto&& a_pj = prism_rtl::as<Ex::XBin>(x_p0).a1;
        auto&& b_pk = prism_rtl::as<Ex::XBin>(x_p0).a2;
        ({
        auto a_pjx = prism_rtl::deref(prism_rtl::deref(a_pj));
        auto b_pkx = prism_rtl::deref(prism_rtl::deref(b_pk));
        auto n_p1x = n_p1;
        (crate::prelude::call_then(start_ex_reads_f(a_pjx, n_p1x), [=, b_pkx = std::move(b_pkx)](bool ex_reads_f_20231) { return prism_rtl::finished(ex_reads_f_20231 || ex_reads_f(b_pkx, n_p1x)); }));
    });
    })
        : prism_rtl::is<Ex::XUnary>(x_p0) ? ({
        auto&& y_pl = prism_rtl::as<Ex::XUnary>(x_p0).a1;
        prism_rtl::more(prism_rtl::rc(ExReads(prism_rtl::deref(prism_rtl::deref(y_pl)), n_p1)));
    })
        : prism_rtl::is<Ex::XCtor>(x_p0) ? ({
        auto&& ys_pm = prism_rtl::as<Ex::XCtor>(x_p0).a1;
        prism_rtl::more(prism_rtl::rc(AnyReads(ys_pm, n_p1)));
    })
        : prism_rtl::is<Ex::XRecord>(x_p0) ? ({
        auto&& fs_pn = prism_rtl::as<Ex::XRecord>(x_p0).a1;
        crate::prelude::fold_job(fs_pn, false, ({
        auto n_p1x = n_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, Ex>>)>>(prism_rtl::rc([=, n_p1x = std::move(n_p1x)](std::tuple<bool, std::tuple<Text, Ex>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto n_p1xy = n_p1x;
            (crate::prelude::entered(crate::prelude::once_job([=, n_p1xy = std::move(n_p1xy)]() {
            return ({
                auto f_po = p0;
                auto&& _y_pp = p1;
                auto&& y_pp = std::get<1>(_y_pp);
                (prism_rtl::finished(std::move(f_po) || ex_reads_f(y_pp, n_p1xy)));
            });
        })));
        });
    })));
    }))->cycle();
    })
        : prism_rtl::is<Ex::XTuple>(x_p0) ? ({
        auto&& ys_pq = prism_rtl::as<Ex::XTuple>(x_p0).a0;
        prism_rtl::more(prism_rtl::rc(AnyReads(ys_pq, n_p1)));
    })
        : prism_rtl::is<Ex::XVec>(x_p0) ? ({
        auto&& ys_pr = prism_rtl::as<Ex::XVec>(x_p0).a0;
        prism_rtl::more(prism_rtl::rc(AnyReads(ys_pr, n_p1)));
    })
        : prism_rtl::is<Ex::XFormat>(x_p0) ? ({
        auto&& ys_ps = prism_rtl::as<Ex::XFormat>(x_p0).a0;
        prism_rtl::more(prism_rtl::rc(AnyReads(ys_ps, n_p1)));
    })
        : prism_rtl::is<Ex::XMatch>(x_p0) ? ({
        auto&& y_pt = prism_rtl::as<Ex::XMatch>(x_p0).a0;
        auto&& arms_pu = prism_rtl::as<Ex::XMatch>(x_p0).a1;
        ({
        auto arms_pux = arms_pu;
        auto n_p1x = n_p1;
        auto y_ptx = prism_rtl::deref(prism_rtl::deref(y_pt));
        (crate::prelude::call_then(start_ex_reads_f(y_ptx, n_p1x), [=, arms_pux = std::move(arms_pux)](bool ex_reads_f_20537) { return prism_rtl::finished(ex_reads_f_20537 || arms_read_f(arms_pux, n_p1x)); }));
    });
    })
        : prism_rtl::is<Ex::XChain>(x_p0) ? ({
        auto&& y_pv = prism_rtl::as<Ex::XChain>(x_p0).a1;
        auto&& arms_p10 = prism_rtl::as<Ex::XChain>(x_p0).a2;
        ({
        auto arms_p10x = arms_p10;
        auto n_p1x = n_p1;
        auto y_pvx = prism_rtl::deref(prism_rtl::deref(y_pv));
        (crate::prelude::call_then(start_ex_reads_f(y_pvx, n_p1x), [=, arms_p10x = std::move(arms_p10x)](bool ex_reads_f_20608) { return prism_rtl::finished(ex_reads_f_20608 || arms_read_f(arms_p10x, n_p1x)); }));
    });
    })
        : prism_rtl::is<Ex::XIf>(x_p0) ? ({
        auto&& c_p11 = prism_rtl::as<Ex::XIf>(x_p0).a0;
        auto&& a_p12 = prism_rtl::as<Ex::XIf>(x_p0).a1;
        auto&& b_p13 = prism_rtl::as<Ex::XIf>(x_p0).a2;
        ({
        auto a_p12x = prism_rtl::deref(prism_rtl::deref(a_p12));
        auto b_p13x = prism_rtl::deref(prism_rtl::deref(b_p13));
        auto c_p11x = prism_rtl::deref(prism_rtl::deref(c_p11));
        auto n_p1x = n_p1;
        (crate::prelude::call_then(start_ex_reads_f(c_p11x, n_p1x), [=, a_p12x = std::move(a_p12x), b_p13x = std::move(b_p13x)](bool ex_reads_f_20660) { return prism_rtl::finished((ex_reads_f_20660 || ex_reads_f(a_p12x, n_p1x)) || ex_reads_f(b_p13x, n_p1x)); }));
    });
    })
        : prism_rtl::is<Ex::XBlock>(x_p0) ? ({
        auto&& ds_p14 = prism_rtl::as<Ex::XBlock>(x_p0).a0;
        auto&& y_p15 = prism_rtl::as<Ex::XBlock>(x_p0).a1;
        ({
        auto ds_p14x = ds_p14;
        auto n_p1x = n_p1;
        auto y_p15x = prism_rtl::deref(prism_rtl::deref(y_p15));
        (crate::prelude::call_then(start_dos_read_f(ds_p14x, n_p1x), [=, y_p15x = std::move(y_p15x)](bool dos_read_f_20727) { return prism_rtl::finished(dos_read_f_20727 || ex_reads_f(y_p15x, n_p1x)); }));
    });
    })
        : prism_rtl::is<Ex::XLabeled>(x_p0) ? ({
        auto&& ds_p16 = prism_rtl::as<Ex::XLabeled>(x_p0).a1;
        auto&& y_p17 = prism_rtl::as<Ex::XLabeled>(x_p0).a2;
        ({
        auto ds_p16x = ds_p16;
        auto n_p1x = n_p1;
        auto y_p17x = prism_rtl::deref(prism_rtl::deref(y_p17));
        (crate::prelude::call_then(start_dos_read_f(ds_p16x, n_p1x), [=, y_p17x = std::move(y_p17x)](bool dos_read_f_20795) { return prism_rtl::finished(dos_read_f_20795 || ex_reads_f(y_p17x, n_p1x)); }));
    });
    })
        : prism_rtl::is<Ex::XClosure>(x_p0) ? ({
        auto&& y_p18 = prism_rtl::as<Ex::XClosure>(x_p0).a2;
        prism_rtl::more(prism_rtl::rc(ExReads(prism_rtl::deref(prism_rtl::deref(y_p18)), n_p1)));
    })
        : prism_rtl::is<Ex::XTry>(x_p0) ? ({
        auto&& y_p19 = prism_rtl::as<Ex::XTry>(x_p0).a0;
        prism_rtl::more(prism_rtl::rc(ExReads(prism_rtl::deref(prism_rtl::deref(y_p19)), n_p1)));
    })
        : prism_rtl::is<Ex::XField>(x_p0) ? ({
        auto&& y_p1a = prism_rtl::as<Ex::XField>(x_p0).a0;
        prism_rtl::more(prism_rtl::rc(ExReads(prism_rtl::deref(prism_rtl::deref(y_p1a)), n_p1)));
    })
        : prism_rtl::is<Ex::XPart>(x_p0) ? ({
        auto&& y_p1b = prism_rtl::as<Ex::XPart>(x_p0).a0;
        prism_rtl::more(prism_rtl::rc(ExReads(prism_rtl::deref(prism_rtl::deref(y_p1b)), n_p1)));
    })
        : prism_rtl::is<Ex::XDecode>(x_p0) ? ({
        auto&& y_p1c = prism_rtl::as<Ex::XDecode>(x_p0).a1;
        prism_rtl::more(prism_rtl::rc(ExReads(prism_rtl::deref(prism_rtl::deref(y_p1c)), n_p1)));
    })
        : prism_rtl::is<Ex::XCast>(x_p0) ? ({
        auto&& y_p1d = prism_rtl::as<Ex::XCast>(x_p0).a0;
        prism_rtl::more(prism_rtl::rc(ExReads(prism_rtl::deref(prism_rtl::deref(y_p1d)), n_p1)));
    })
        : prism_rtl::is<Ex::XTyped>(x_p0) ? ({
        auto&& y_p1e = prism_rtl::as<Ex::XTyped>(x_p0).a0;
        prism_rtl::more(prism_rtl::rc(ExReads(prism_rtl::deref(prism_rtl::deref(y_p1e)), n_p1)));
    })
        : prism_rtl::finished(false);
    });
}


/// `Start ExReads, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_ex_reads_f(Ex x_p0, Text n_p1) {
    return prism_rtl::make_rc<ExReads>(x_p0, n_p1);
}


/// AnyReads: unbounded fn [Ex], Text -> Bool
bool any_reads_f(const Array<Ex>& xs_p0, const Text& n_p1) {
    return crate::prelude::run_to_end(crate::prelude::fold_job(xs_p0, false, ({
        auto n_p1x = n_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, Ex>)>>(prism_rtl::rc([=, n_p1x = std::move(n_p1x)](std::tuple<bool, Ex> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto n_p1xy = n_p1x;
            (crate::prelude::entered(crate::prelude::once_job([=, n_p1xy = std::move(n_p1xy)]() {
            return ({
                auto f_p2 = p0;
                auto y_p3 = p1;
                (prism_rtl::finished(std::move(f_p2) || ex_reads_f(y_p3, n_p1xy)));
            });
        })));
        });
    })));
    })));
}


prism_rtl::Turn<bool> AnyReads::cycle() const {
    const auto& xs_p0 = this->xs_p0;
    const auto& n_p1 = this->n_p1;
    return crate::prelude::fold_job(xs_p0, false, ({
        auto n_p1x = n_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, Ex>)>>(prism_rtl::rc([=, n_p1x = std::move(n_p1x)](std::tuple<bool, Ex> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto n_p1xy = n_p1x;
            (crate::prelude::entered(crate::prelude::once_job([=, n_p1xy = std::move(n_p1xy)]() {
            return ({
                auto f_p2 = p0;
                auto y_p3 = p1;
                (prism_rtl::finished(std::move(f_p2) || ex_reads_f(y_p3, n_p1xy)));
            });
        })));
        });
    })));
    }))->cycle();
}


/// `Start AnyReads, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_any_reads_f(Array<Ex> xs_p0, Text n_p1) {
    return prism_rtl::make_rc<AnyReads>(xs_p0, n_p1);
}


/// ArmsRead: unbounded fn [XArm], Text -> Bool
bool arms_read_f(const Array<XArm>& arms_p0, const Text& n_p1) {
    return crate::prelude::run_to_end(crate::prelude::fold_job(arms_p0, false, ({
        auto n_p1x = n_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, XArm>)>>(prism_rtl::rc([=, n_p1x = std::move(n_p1x)](std::tuple<bool, XArm> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto n_p1xy = n_p1x;
            (crate::prelude::entered(crate::prelude::once_job([=, n_p1xy = std::move(n_p1xy)]() {
            return ({
                auto f_p2 = p0;
                auto a_p3 = p1;
                (prism_rtl::finished((std::move(f_p2) || ex_reads_f(prism_rtl::deref(a_p3).body_p, n_p1xy)) || crate::prelude::run_to_end(crate::prelude::fold_job(prism_rtl::deref(a_p3).conds_p, false, ({
                auto n_p1xyx = n_p1xy;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, Cc>)>>(prism_rtl::rc([=, n_p1xyx = std::move(n_p1xyx)](std::tuple<bool, Cc> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto n_p1xyxy = n_p1xyx;
                    (crate::prelude::entered(crate::prelude::once_job([=, n_p1xyxy = std::move(n_p1xyxy)]() {
                    return ({
                        auto g_p4 = p0;
                        auto c_p5 = p1;
                        (prism_rtl::finished(std::move(g_p4) || ({
                        __label__ _done;
                        prism_rtl::Slot<bool> _v;
                        if (prism_rtl::is<Cc::CcIf>(c_p5)) {
                            auto&& y_p6 = prism_rtl::as<Cc::CcIf>(c_p5).a0;
                            _v.set(ex_reads_f(y_p6, n_p1xyxy));
                            goto _done;
                        }
                        if (prism_rtl::is<Cc::CcLet>(c_p5)) {
                            auto&& y_p7 = prism_rtl::as<Cc::CcLet>(c_p5).a1;
                            _v.set(ex_reads_f(y_p7, n_p1xyxy));
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    })));
                    });
                })));
                });
            })));
            })))));
            });
        })));
        });
    })));
    })));
}


prism_rtl::Turn<bool> ArmsRead::cycle() const {
    const auto& arms_p0 = this->arms_p0;
    const auto& n_p1 = this->n_p1;
    return crate::prelude::fold_job(arms_p0, false, ({
        auto n_p1x = n_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, XArm>)>>(prism_rtl::rc([=, n_p1x = std::move(n_p1x)](std::tuple<bool, XArm> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto n_p1xy = n_p1x;
            (crate::prelude::entered(crate::prelude::once_job([=, n_p1xy = std::move(n_p1xy)]() {
            return ({
                auto f_p2 = p0;
                auto a_p3 = p1;
                (prism_rtl::finished((std::move(f_p2) || ex_reads_f(prism_rtl::deref(a_p3).body_p, n_p1xy)) || crate::prelude::run_to_end(crate::prelude::fold_job(prism_rtl::deref(a_p3).conds_p, false, ({
                auto n_p1xyx = n_p1xy;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, Cc>)>>(prism_rtl::rc([=, n_p1xyx = std::move(n_p1xyx)](std::tuple<bool, Cc> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto n_p1xyxy = n_p1xyx;
                    (crate::prelude::entered(crate::prelude::once_job([=, n_p1xyxy = std::move(n_p1xyxy)]() {
                    return ({
                        auto g_p4 = p0;
                        auto c_p5 = p1;
                        (prism_rtl::finished(std::move(g_p4) || ({
                        __label__ _done;
                        prism_rtl::Slot<bool> _v;
                        if (prism_rtl::is<Cc::CcIf>(c_p5)) {
                            auto&& y_p6 = prism_rtl::as<Cc::CcIf>(c_p5).a0;
                            _v.set(ex_reads_f(y_p6, n_p1xyxy));
                            goto _done;
                        }
                        if (prism_rtl::is<Cc::CcLet>(c_p5)) {
                            auto&& y_p7 = prism_rtl::as<Cc::CcLet>(c_p5).a1;
                            _v.set(ex_reads_f(y_p7, n_p1xyxy));
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    })));
                    });
                })));
                });
            })));
            })))));
            });
        })));
        });
    })));
    }))->cycle();
}


/// `Start ArmsRead, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_arms_read_f(Array<XArm> arms_p0, Text n_p1) {
    return prism_rtl::make_rc<ArmsRead>(arms_p0, n_p1);
}


/// DosRead: unbounded fn [Do], Text -> Bool
bool dos_read_f(const Array<Do>& ds_p0, const Text& n_p1) {
    return crate::prelude::run_to_end(crate::prelude::fold_job(ds_p0, false, ({
        auto n_p1x = n_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, Do>)>>(prism_rtl::rc([=, n_p1x = std::move(n_p1x)](std::tuple<bool, Do> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto n_p1xy = n_p1x;
            (crate::prelude::entered(crate::prelude::once_job([=, n_p1xy = std::move(n_p1xy)]() {
            return ({
                auto f_p2 = p0;
                auto d_p3 = p1;
                (prism_rtl::finished(std::move(f_p2) || do_reads_f(d_p3, n_p1xy)));
            });
        })));
        });
    })));
    })));
}


prism_rtl::Turn<bool> DosRead::cycle() const {
    const auto& ds_p0 = this->ds_p0;
    const auto& n_p1 = this->n_p1;
    return crate::prelude::fold_job(ds_p0, false, ({
        auto n_p1x = n_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, Do>)>>(prism_rtl::rc([=, n_p1x = std::move(n_p1x)](std::tuple<bool, Do> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto n_p1xy = n_p1x;
            (crate::prelude::entered(crate::prelude::once_job([=, n_p1xy = std::move(n_p1xy)]() {
            return ({
                auto f_p2 = p0;
                auto d_p3 = p1;
                (prism_rtl::finished(std::move(f_p2) || do_reads_f(d_p3, n_p1xy)));
            });
        })));
        });
    })));
    }))->cycle();
}


/// `Start DosRead, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_dos_read_f(Array<Do> ds_p0, Text n_p1) {
    return prism_rtl::make_rc<DosRead>(ds_p0, n_p1);
}


/// DoReads: unbounded fn Do, Text -> Bool
bool do_reads_f(const Do& d_p0, const Text& n_p1) {
    if (prism_rtl::is<Do::DoLet>(d_p0)) {
        auto&& y_p2 = prism_rtl::as<Do::DoLet>(d_p0).a1;
        return ex_reads_f(y_p2, n_p1);
    }
    if (prism_rtl::is<Do::DoLetElse>(d_p0)) {
        auto&& y_p3 = prism_rtl::as<Do::DoLetElse>(d_p0).a1;
        auto&& z_p4 = prism_rtl::as<Do::DoLetElse>(d_p0).a2;
        return ex_reads_f(y_p3, n_p1) || ex_reads_f(z_p4, n_p1);
    }
    if (prism_rtl::is<Do::DoAssign>(d_p0)) {
        auto&& a_p5 = prism_rtl::as<Do::DoAssign>(d_p0).a0;
        auto&& b_p6 = prism_rtl::as<Do::DoAssign>(d_p0).a1;
        return ex_reads_f(a_p5, n_p1) || ex_reads_f(b_p6, n_p1);
    }
    if (prism_rtl::is<Do::DoWhile>(d_p0)) {
        auto&& c_p7 = prism_rtl::as<Do::DoWhile>(d_p0).a0;
        auto&& ds_p8 = prism_rtl::as<Do::DoWhile>(d_p0).a1;
        return ex_reads_f(c_p7, n_p1) || dos_read_f(ds_p8, n_p1);
    }
    if (prism_rtl::is<Do::DoWhileLet>(d_p0)) {
        auto&& y_p9 = prism_rtl::as<Do::DoWhileLet>(d_p0).a1;
        auto&& ds_pa = prism_rtl::as<Do::DoWhileLet>(d_p0).a2;
        return ex_reads_f(y_p9, n_p1) || dos_read_f(ds_pa, n_p1);
    }
    if (prism_rtl::is<Do::DoFor>(d_p0)) {
        auto&& y_pb = prism_rtl::as<Do::DoFor>(d_p0).a1;
        auto&& ds_pc = prism_rtl::as<Do::DoFor>(d_p0).a2;
        return ex_reads_f(y_pb, n_p1) || dos_read_f(ds_pc, n_p1);
    }
    if (prism_rtl::is<Do::DoExpr>(d_p0)) {
        auto&& y_pd = prism_rtl::as<Do::DoExpr>(d_p0).a0;
        return ex_reads_f(y_pd, n_p1);
    }
    if (prism_rtl::is<Do::DoIf>(d_p0)) {
        auto&& c_pe = prism_rtl::as<Do::DoIf>(d_p0).a0;
        auto&& a_pf = prism_rtl::as<Do::DoIf>(d_p0).a1;
        auto&& b_pg = prism_rtl::as<Do::DoIf>(d_p0).a2;
        return (ex_reads_f(c_pe, n_p1) || dos_read_f(a_pf, n_p1)) || dos_read_f(b_pg, n_p1);
    }
    if (prism_rtl::is<Do::DoIfLet>(d_p0)) {
        auto&& y_ph = prism_rtl::as<Do::DoIfLet>(d_p0).a1;
        auto&& a_pi = prism_rtl::as<Do::DoIfLet>(d_p0).a2;
        auto&& b_pj = prism_rtl::as<Do::DoIfLet>(d_p0).a3;
        return (ex_reads_f(y_ph, n_p1) || dos_read_f(a_pi, n_p1)) || dos_read_f(b_pj, n_p1);
    }
    if (prism_rtl::is<Do::DoMatch>(d_p0)) {
        auto&& y_pk = prism_rtl::as<Do::DoMatch>(d_p0).a0;
        auto&& arms_pl = prism_rtl::as<Do::DoMatch>(d_p0).a1;
        return ex_reads_f(y_pk, n_p1) || crate::prelude::run_to_end(crate::prelude::fold_job(arms_pl, false, ({
            auto n_p1x = n_p1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Pa, Array<Do>>>)>>(prism_rtl::rc([=, n_p1x = std::move(n_p1x)](std::tuple<bool, std::tuple<Pa, Array<Do>>> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto n_p1xy = n_p1x;
                (crate::prelude::entered(crate::prelude::once_job([=, n_p1xy = std::move(n_p1xy)]() {
                return ({
                    auto f_pm = p0;
                    auto&& _ds_pn = p1;
                    auto&& ds_pn = std::get<1>(_ds_pn);
                    (prism_rtl::finished(std::move(f_pm) || dos_read_f(ds_pn, n_p1xy)));
                });
            })));
            });
        })));
        })));
    }
    if (prism_rtl::is<Do::DoReturn>(d_p0)) {
        auto&& y_po = prism_rtl::as<Do::DoReturn>(d_p0).a0;
        return ex_reads_f(y_po, n_p1);
    }
    if (prism_rtl::is<Do::DoBlock>(d_p0)) {
        auto&& ds_pp = prism_rtl::as<Do::DoBlock>(d_p0).a0;
        return dos_read_f(ds_pp, n_p1);
    }
    if (prism_rtl::is<Do::DoScope>(d_p0)) {
        auto&& ds_pq = prism_rtl::as<Do::DoScope>(d_p0).a0;
        return dos_read_f(ds_pq, n_p1);
    }
    if (prism_rtl::is<Do::DoLine>(d_p0)) {
        auto&& ds_pr = prism_rtl::as<Do::DoLine>(d_p0).a0;
        return dos_read_f(ds_pr, n_p1);
    }
    if (prism_rtl::is<Do::DoNote>(d_p0)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<bool> DoReads::cycle() const {
    const auto& d_p0 = this->d_p0;
    const auto& n_p1 = this->n_p1;
    return ({
        prism_rtl::is<Do::DoLet>(d_p0) ? ({
        auto&& y_p2 = prism_rtl::as<Do::DoLet>(d_p0).a1;
        prism_rtl::more(prism_rtl::rc(ExReads(y_p2, n_p1)));
    })
        : prism_rtl::is<Do::DoLetElse>(d_p0) ? ({
        auto&& y_p3 = prism_rtl::as<Do::DoLetElse>(d_p0).a1;
        auto&& z_p4 = prism_rtl::as<Do::DoLetElse>(d_p0).a2;
        ({
        auto n_p1x = n_p1;
        auto y_p3x = y_p3;
        auto z_p4x = z_p4;
        (crate::prelude::call_then(start_ex_reads_f(y_p3x, n_p1x), [=, z_p4x = std::move(z_p4x)](bool ex_reads_f_21652) { return prism_rtl::finished(ex_reads_f_21652 || ex_reads_f(z_p4x, n_p1x)); }));
    });
    })
        : prism_rtl::is<Do::DoAssign>(d_p0) ? ({
        auto&& a_p5 = prism_rtl::as<Do::DoAssign>(d_p0).a0;
        auto&& b_p6 = prism_rtl::as<Do::DoAssign>(d_p0).a1;
        ({
        auto a_p5x = a_p5;
        auto b_p6x = b_p6;
        auto n_p1x = n_p1;
        (crate::prelude::call_then(start_ex_reads_f(a_p5x, n_p1x), [=, b_p6x = std::move(b_p6x)](bool ex_reads_f_21702) { return prism_rtl::finished(ex_reads_f_21702 || ex_reads_f(b_p6x, n_p1x)); }));
    });
    })
        : prism_rtl::is<Do::DoWhile>(d_p0) ? ({
        auto&& c_p7 = prism_rtl::as<Do::DoWhile>(d_p0).a0;
        auto&& ds_p8 = prism_rtl::as<Do::DoWhile>(d_p0).a1;
        ({
        auto c_p7x = c_p7;
        auto ds_p8x = ds_p8;
        auto n_p1x = n_p1;
        (crate::prelude::call_then(start_ex_reads_f(c_p7x, n_p1x), [=, ds_p8x = std::move(ds_p8x)](bool ex_reads_f_21752) { return prism_rtl::finished(ex_reads_f_21752 || dos_read_f(ds_p8x, n_p1x)); }));
    });
    })
        : prism_rtl::is<Do::DoWhileLet>(d_p0) ? ({
        auto&& y_p9 = prism_rtl::as<Do::DoWhileLet>(d_p0).a1;
        auto&& ds_pa = prism_rtl::as<Do::DoWhileLet>(d_p0).a2;
        ({
        auto ds_pax = ds_pa;
        auto n_p1x = n_p1;
        auto y_p9x = y_p9;
        (crate::prelude::call_then(start_ex_reads_f(y_p9x, n_p1x), [=, ds_pax = std::move(ds_pax)](bool ex_reads_f_21814) { return prism_rtl::finished(ex_reads_f_21814 || dos_read_f(ds_pax, n_p1x)); }));
    });
    })
        : prism_rtl::is<Do::DoFor>(d_p0) ? ({
        auto&& y_pb = prism_rtl::as<Do::DoFor>(d_p0).a1;
        auto&& ds_pc = prism_rtl::as<Do::DoFor>(d_p0).a2;
        ({
        auto ds_pcx = ds_pc;
        auto n_p1x = n_p1;
        auto y_pbx = y_pb;
        (crate::prelude::call_then(start_ex_reads_f(y_pbx, n_p1x), [=, ds_pcx = std::move(ds_pcx)](bool ex_reads_f_21871) { return prism_rtl::finished(ex_reads_f_21871 || dos_read_f(ds_pcx, n_p1x)); }));
    });
    })
        : prism_rtl::is<Do::DoExpr>(d_p0) ? ({
        auto&& y_pd = prism_rtl::as<Do::DoExpr>(d_p0).a0;
        prism_rtl::more(prism_rtl::rc(ExReads(y_pd, n_p1)));
    })
        : prism_rtl::is<Do::DoIf>(d_p0) ? ({
        auto&& c_pe = prism_rtl::as<Do::DoIf>(d_p0).a0;
        auto&& a_pf = prism_rtl::as<Do::DoIf>(d_p0).a1;
        auto&& b_pg = prism_rtl::as<Do::DoIf>(d_p0).a2;
        ({
        auto a_pfx = a_pf;
        auto b_pgx = b_pg;
        auto c_pex = c_pe;
        auto n_p1x = n_p1;
        (crate::prelude::call_then(start_ex_reads_f(c_pex, n_p1x), [=, a_pfx = std::move(a_pfx), b_pgx = std::move(b_pgx)](bool ex_reads_f_21948) { return prism_rtl::finished((ex_reads_f_21948 || dos_read_f(a_pfx, n_p1x)) || dos_read_f(b_pgx, n_p1x)); }));
    });
    })
        : prism_rtl::is<Do::DoIfLet>(d_p0) ? ({
        auto&& y_ph = prism_rtl::as<Do::DoIfLet>(d_p0).a1;
        auto&& a_pi = prism_rtl::as<Do::DoIfLet>(d_p0).a2;
        auto&& b_pj = prism_rtl::as<Do::DoIfLet>(d_p0).a3;
        ({
        auto a_pix = a_pi;
        auto b_pjx = b_pj;
        auto n_p1x = n_p1;
        auto y_phx = y_ph;
        (crate::prelude::call_then(start_ex_reads_f(y_phx, n_p1x), [=, a_pix = std::move(a_pix), b_pjx = std::move(b_pjx)](bool ex_reads_f_22026) { return prism_rtl::finished((ex_reads_f_22026 || dos_read_f(a_pix, n_p1x)) || dos_read_f(b_pjx, n_p1x)); }));
    });
    })
        : prism_rtl::is<Do::DoMatch>(d_p0) ? ({
        auto&& y_pk = prism_rtl::as<Do::DoMatch>(d_p0).a0;
        auto&& arms_pl = prism_rtl::as<Do::DoMatch>(d_p0).a1;
        ({
        auto arms_plx = arms_pl;
        auto n_p1x = n_p1;
        auto y_pkx = y_pk;
        (crate::prelude::call_then(start_ex_reads_f(y_pkx, n_p1x), [=, arms_plx = std::move(arms_plx)](bool ex_reads_f_22096) {
        return prism_rtl::finished(ex_reads_f_22096 || crate::prelude::run_to_end(crate::prelude::fold_job(arms_plx, false, ({
            auto n_p1xx = n_p1x;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Pa, Array<Do>>>)>>(prism_rtl::rc([=, n_p1xx = std::move(n_p1xx)](std::tuple<bool, std::tuple<Pa, Array<Do>>> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto n_p1xxy = n_p1xx;
                (crate::prelude::entered(crate::prelude::once_job([=, n_p1xxy = std::move(n_p1xxy)]() {
                return ({
                    auto f_pm = p0;
                    auto&& _ds_pn = p1;
                    auto&& ds_pn = std::get<1>(_ds_pn);
                    (prism_rtl::finished(std::move(f_pm) || dos_read_f(ds_pn, n_p1xxy)));
                });
            })));
            });
        })));
        }))));
    }));
    });
    })
        : prism_rtl::is<Do::DoReturn>(d_p0) ? ({
        auto&& y_po = prism_rtl::as<Do::DoReturn>(d_p0).a0;
        prism_rtl::more(prism_rtl::rc(ExReads(y_po, n_p1)));
    })
        : prism_rtl::is<Do::DoBlock>(d_p0) ? ({
        auto&& ds_pp = prism_rtl::as<Do::DoBlock>(d_p0).a0;
        prism_rtl::more(prism_rtl::rc(DosRead(ds_pp, n_p1)));
    })
        : prism_rtl::is<Do::DoScope>(d_p0) ? ({
        auto&& ds_pq = prism_rtl::as<Do::DoScope>(d_p0).a0;
        prism_rtl::more(prism_rtl::rc(DosRead(ds_pq, n_p1)));
    })
        : prism_rtl::is<Do::DoLine>(d_p0) ? ({
        auto&& ds_pr = prism_rtl::as<Do::DoLine>(d_p0).a0;
        prism_rtl::more(prism_rtl::rc(DosRead(ds_pr, n_p1)));
    })
        : prism_rtl::is<Do::DoNote>(d_p0) ? prism_rtl::finished(false)
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start DoReads, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_do_reads_f(Do d_p0, Text n_p1) {
    return prism_rtl::make_rc<DoReads>(d_p0, n_p1);
}

}  // namespace crate::lower::model
