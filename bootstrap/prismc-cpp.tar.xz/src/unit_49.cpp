// The module `Lower.Node.Def`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <lower/node_/def/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Lower.Node.Def`, from `target/bootstrap/cpp-src/prismc/lower/node/def.prism`.
namespace crate::lower::node_::def {

void HowBound::show(Printer& p) const {
    if (auto c = std::get_if<AsHold>(&cases())) p.choice("AsHold", {});
    else if (auto c = std::get_if<AsBind>(&cases())) p.choice("AsBind", {});
    else if (auto c = std::get_if<AsLet>(&cases())) p.choice("AsLet", {});
    else if (auto c = std::get_if<AsResult>(&cases())) p.choice("AsResult", {});
}

Pod HowBound::to_pod() const {
    return std::holds_alternative<AsHold>(cases()) ? Pod::choice("AsHold", {})
        : std::holds_alternative<AsBind>(cases()) ? Pod::choice("AsBind", {})
        : std::holds_alternative<AsLet>(cases()) ? Pod::choice("AsLet", {})
        : std::holds_alternative<AsResult>(cases()) ? Pod::choice("AsResult", {})
        : Pod();
}

Result<HowBound> HowBound::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "AsHold" && c->args.size() == 0) return HowBound(AsHold{});
        if (c->ctor == "AsBind" && c->args.size() == 0) return HowBound(AsBind{});
        if (c->ctor == "AsLet" && c->args.size() == 0) return HowBound(AsLet{});
        if (c->ctor == "AsResult" && c->args.size() == 0) return HowBound(AsResult{});
    }
    return mismatch<HowBound>("a HowBound", p);
}


/// NodeDefOf: unbounded fn Lx, Text, [Pattern], Block, Scheme, Bool -> NodeDef
crate::lower::model::NodeDef node_def_of(const crate::lower::Lx& lx_p0, const Text& qk_p1, const Array<crate::syntax::Pattern_>& params_p2, const crate::syntax::Block& body_p3, const crate::check::types::Scheme& sc_p4, const bool& is_root_p5) {
    auto name_p6 = crate::lower::camel(crate::check::types::bare_name(qk_p1));
    auto ptys_p7 = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::check::types::Ty>> _v;
        auto&& _m = sc_p4.ty;
        if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
            auto&& ps_pb = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a1;
            _v.set(ps_pb);
            goto _done;
        }
        {
            _v.set(Array<crate::check::types::Ty>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto wx0_p8 = crate::lower::node_::new_wx(lx_p0, name_p6, Array<std::tuple<Text, crate::lower::model::OutTy, Text>>{}, Array<std::tuple<Text, crate::lower::model::Ex>>{}, Array<std::tuple<Text, crate::lower::model::Ex>>{}, Array<crate::lower::model::MethDef>{}, Map<Text, Array<crate::lower::node_::Read>>{}, crate::lower::node_::node_hooks(), Array<Text>{}, std::optional<Text>{});
    auto [ps_pq, wx1_pr, benv_ps, menv_pt] = run_to_end(fold_job(crate::check::errors::range0(len(params_p2)), std::tuple{Array<std::tuple<Text, crate::lower::model::OutTy>>{}, wx0_p8, crate::lower::types::empty_env(), crate::lower::types::empty_env()}, ({
        auto params_p2_1 = params_p2;
        auto lx_p0_2 = lx_p0;
        auto ptys_p7_3 = ptys_p7;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, crate::lower::model::OutTy>>, crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>>(std::tuple<std::tuple<Array<std::tuple<Text, crate::lower::model::OutTy>>, crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>, Nat>)>>(prism_rtl::rc([=, params_p2_1 = std::move(params_p2_1), lx_p0_2 = std::move(lx_p0_2), ptys_p7_3 = std::move(ptys_p7_3)](std::tuple<std::tuple<Array<std::tuple<Text, crate::lower::model::OutTy>>, crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto params_p2_1_4 = params_p2_1;
            auto lx_p0_2_4 = lx_p0_2;
            auto ptys_p7_3_4 = ptys_p7_3;
            entered(once_job([=, params_p2_1_4 = std::move(params_p2_1_4), lx_p0_2_4 = std::move(lx_p0_2_4), ptys_p7_3_4 = std::move(ptys_p7_3_4)]() {
            return ({
                auto [acc_pc, w_pd, be_pe, me_pf] = p0;
                auto i_pg = p1;
                ({
                auto p_ph = or_(index(params_p2_1_4, i_pg), crate::lower::patterns::dummy_pat());
                auto nkey_pi = crate::lower::functions::plain_binder(lx_p0_2_4, p_ph);
                auto base_pj = nkey_pi == Text::lit("")
                    ? prism_rtl::cat("arg", i_pg)
                    : crate::lower::snake(nkey_pi);
                auto [rs_pm, w2_pn] = crate::lower::node_::fresh_name(w_pd, base_pj);
                call_then(crate::lower::types::start_out_ty_of(lx_p0_2_4, crate::lower::types::peel(or_(index(ptys_p7_3_4, i_pg), crate::check::types::Ty(crate::check::types::Ty::TyErr{})))), [=, nkey_pi = std::move(nkey_pi)](crate::lower::model::OutTy out_ty_of_1975) {
                return ({
                    auto t_pk = out_ty_of_1975;
                    auto w3_pl = ({
                        crate::lower::node_::Wx this_ = w2_pn;
                        this_.fields = crate::prelude::push(this_.fields, std::tuple{rs_pm, t_pk, Text::lit("a parameter")});
                        this_.inits = crate::prelude::push(this_.inits, std::tuple{rs_pm, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{rs_pm}))})});
                        (std::move(this_));
                    });
                    auto [be2_po, me2_pp] = crate::lower::node_::bind_plain(be_pe, me_pf, nkey_pi, rs_pm, t_pk);
                    (prism_rtl::finished(std::tuple{crate::prelude::push(acc_pc, std::tuple{rs_pm, t_pk}), w3_pl, be2_po, me2_pp}));
                });
            });
            });
            });
        }));
        });
    }));
    })));
    auto wx2_p9 = block_into(wx1_pr, benv_ps, menv_pt, body_p3);
    auto wx3_pa = is_root_p5 ? root_result(wx2_p9) : wx2_p9;
    return crate::lower::node_::finish::finish_node(wx3_pa, qk_p1, ps_pq, false);
}


prism_rtl::Turn<crate::lower::model::NodeDef> NodeDefOf::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& qk_p1 = this->qk_p1;
    const auto& params_p2 = this->params_p2;
    const auto& body_p3 = this->body_p3;
    const auto& sc_p4 = this->sc_p4;
    const auto& is_root_p5 = this->is_root_p5;
    auto name_p6 = crate::lower::camel(crate::check::types::bare_name(qk_p1));
    auto ptys_p7 = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::check::types::Ty>> _v;
        auto&& _m = prism_rtl::deref(sc_p4).ty;
        if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
            auto&& ps_pb = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a1;
            _v.set(ps_pb);
            goto _done;
        }
        {
            _v.set(Array<crate::check::types::Ty>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto wx0_p8 = crate::lower::node_::new_wx(lx_p0, name_p6, Array<std::tuple<Text, crate::lower::model::OutTy, Text>>{}, Array<std::tuple<Text, crate::lower::model::Ex>>{}, Array<std::tuple<Text, crate::lower::model::Ex>>{}, Array<crate::lower::model::MethDef>{}, Map<Text, Array<crate::lower::node_::Read>>{}, crate::lower::node_::node_hooks(), Array<Text>{}, std::optional<Text>{});
    auto body_p3_1 = body_p3;
    auto is_root_p5_2 = prism_rtl::deref(is_root_p5);
    auto lx_p0_3 = lx_p0;
    auto params_p2_4 = params_p2;
    auto qk_p1_5 = qk_p1;
    return call_value(fold_job(crate::check::errors::range0(len(params_p2_4)), std::tuple{Array<std::tuple<Text, crate::lower::model::OutTy>>{}, wx0_p8, crate::lower::types::empty_env(), crate::lower::types::empty_env()}, ({
        auto params_p2_4_6 = params_p2_4;
        auto lx_p0_3_6 = lx_p0_3;
        auto ptys_p7_6 = ptys_p7;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, crate::lower::model::OutTy>>, crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>>(std::tuple<std::tuple<Array<std::tuple<Text, crate::lower::model::OutTy>>, crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>, Nat>)>>(prism_rtl::rc([=, params_p2_4_6 = std::move(params_p2_4_6), lx_p0_3_6 = std::move(lx_p0_3_6), ptys_p7_6 = std::move(ptys_p7_6)](std::tuple<std::tuple<Array<std::tuple<Text, crate::lower::model::OutTy>>, crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto params_p2_4_6_7 = params_p2_4_6;
            auto lx_p0_3_6_7 = lx_p0_3_6;
            auto ptys_p7_6_7 = ptys_p7_6;
            entered(once_job([=, params_p2_4_6_7 = std::move(params_p2_4_6_7), lx_p0_3_6_7 = std::move(lx_p0_3_6_7), ptys_p7_6_7 = std::move(ptys_p7_6_7)]() {
            return ({
                auto [acc_pc, w_pd, be_pe, me_pf] = p0;
                auto i_pg = p1;
                ({
                auto p_ph = or_(index(params_p2_4_6_7, i_pg), crate::lower::patterns::dummy_pat());
                auto nkey_pi = crate::lower::functions::plain_binder(lx_p0_3_6_7, p_ph);
                auto base_pj = nkey_pi == Text::lit("")
                    ? prism_rtl::cat("arg", i_pg)
                    : crate::lower::snake(nkey_pi);
                auto [rs_pm, w2_pn] = crate::lower::node_::fresh_name(w_pd, base_pj);
                call_then(crate::lower::types::start_out_ty_of(lx_p0_3_6_7, crate::lower::types::peel(or_(index(ptys_p7_6_7, i_pg), crate::check::types::Ty(crate::check::types::Ty::TyErr{})))), [=, nkey_pi = std::move(nkey_pi)](crate::lower::model::OutTy out_ty_of_1975) {
                return ({
                    auto t_pk = out_ty_of_1975;
                    auto w3_pl = ({
                        crate::lower::node_::Wx this_ = w2_pn;
                        this_.fields = crate::prelude::push(this_.fields, std::tuple{rs_pm, t_pk, Text::lit("a parameter")});
                        this_.inits = crate::prelude::push(this_.inits, std::tuple{rs_pm, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{rs_pm}))})});
                        (std::move(this_));
                    });
                    auto [be2_po, me2_pp] = crate::lower::node_::bind_plain(be_pe, me_pf, nkey_pi, rs_pm, t_pk);
                    (prism_rtl::finished(std::tuple{crate::prelude::push(acc_pc, std::tuple{rs_pm, t_pk}), w3_pl, be2_po, me2_pp}));
                });
            });
            });
            });
        }));
        });
    }));
    })), [=](std::tuple<Array<std::tuple<Text, crate::lower::model::OutTy>>, crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env> fold_1692) {
        return ({
            auto [ps_pq, wx1_pr, benv_ps, menv_pt] = fold_1692;
            call_then(start_block_into(wx1_pr, benv_ps, menv_pt, body_p3_1), [=](crate::lower::node_::Wx block_into_2293) {
            return ({
                auto wx2_p9 = block_into_2293;
                auto wx3_pa = is_root_p5_2 ? root_result(wx2_p9) : wx2_p9;
                (prism_rtl::more(prism_rtl::rc(crate::lower::node_::finish::FinishNode(wx3_pa, qk_p1_5, ps_pq, false))));
            });
        });
        });
    });
}


/// `Start NodeDefOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::NodeDef> start_node_def_of(crate::lower::Lx lx_p0, Text qk_p1, Array<crate::syntax::Pattern_> params_p2, crate::syntax::Block body_p3, crate::check::types::Scheme sc_p4, bool is_root_p5) {
    return prism_rtl::make_rc<NodeDefOf>(lx_p0, qk_p1, params_p2, body_p3, sc_p4, is_root_p5);
}


/// RootResult: fn Wx -> Wx
crate::lower::node_::Wx root_result(const crate::lower::node_::Wx& wx_p0) {
    auto&& _m = wx_p0.result;
    if (prism_rtl::is<crate::lower::node_::Wres::WrEv>(_m)) {
        auto&& r_p1 = prism_rtl::as<crate::lower::node_::Wres::WrEv>(_m).a0;
        return crate::lower::node_::connect(wx_p0, r_p1, crate::lower::node_::Sk(crate::lower::node_::Sk::SkResult{}));
    }
    if (prism_rtl::is<crate::lower::node_::Wres::WrDyn>(_m)) {
        auto&& x_p2 = prism_rtl::as<crate::lower::node_::Wres::WrDyn>(_m).a0;
        auto&& rds_p3 = prism_rtl::as<crate::lower::node_::Wres::WrDyn>(_m).a1;
        auto&& t_p4 = prism_rtl::as<crate::lower::node_::Wres::WrDyn>(_m).a2;
        crate::lower::node_::Wx this_ = wx_p0;
        this_.root_dyn = std::optional(std::tuple{x_p2, rds_p3, t_p4});
        this_.getters = crate::prelude::push(this_.getters, crate::lower::model::MethDef{.name = Text::lit("result_value"), .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxRef{}), .ret = crate::lower::model::OutTy(crate::lower::model::OutTy::OutPod{}), .body = Array<crate::lower::model::Do>{}, .tail = crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(x_p2), Text::lit("to_pod"), Array<crate::lower::model::Ex>{}}), .doc = Text::lit("The root\'s dynamic result, pulled after the tick.")});
        this_.fields = crate::prelude::push(this_.fields, std::tuple{Text::lit("result_last"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutCell{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutOpt{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutPod{}))}))}), Text::lit("the result the World last heard")});
        this_.moves = crate::prelude::push(this_.moves, std::tuple{Text::lit("result_last"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("RefCell::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XNone{})})})});
        this_.build = crate::prelude::push(this_.build, crate::lower::model::Do(crate::lower::model::Do::DoScope{crate::lower::node_::finish::result_told(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")}))}));
        return this_;
    }
    if (prism_rtl::is<crate::lower::node_::Wres::WrPlain>(_m)) {
        auto&& x_p5 = prism_rtl::as<crate::lower::node_::Wres::WrPlain>(_m).a0;
        crate::lower::node_::Wx this_ = wx_p0;
        this_.build = crate::prelude::push(this_.build, crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCx{})), Text::lit("result"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Outcome::Value"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(x_p5), Text::lit("to_pod"), Array<crate::lower::model::Ex>{}})})})})})}));
        return this_;
    }
    if (prism_rtl::is<crate::lower::node_::Wres::WrParts>(_m)) {
        crate::lower::node_::Wx this_ = wx_p0;
        this_.build = crate::prelude::push(this_.build, crate::lower::expr::refusal_do(Text::lit("a bundle as the root\'s result: a World hears a plain value, a dynamic or an event")));
        return this_;
    }
    {
        return wx_p0;
    }
}


/// BlockInto: unbounded fn Wx, Env, Env, Block -> Wx
crate::lower::node_::Wx block_into(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& benv_p1, const crate::lower::types::Env& menv_p2, const crate::syntax::Block& b_p3) {
    auto [wx1_pb, be1_pc, me1_pd] = run_to_end(fold_job(b_p3.stmts, std::tuple{wx_p0, benv_p1, menv_p2}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>>(std::tuple<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>, crate::syntax::Stmt>)>>(prism_rtl::rc([=](std::tuple<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>, crate::syntax::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto [w_p7, be_p8, me_p9] = p0;
                auto s_pa = p1;
                (prism_rtl::more(prism_rtl::rc(PreBind(w_p7, be_p8, me_p9, s_pa))));
            });
        }));
    }))));
    auto order_p4 = build_order(b_p3.stmts);
    auto [wx2_pk, be2_pl] = run_to_end(fold_job(order_p4, std::tuple{wx1_pb, be1_pc}, ({
        auto me1_pd_1 = me1_pd;
        auto b_p3_2 = b_p3;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env>>(std::tuple<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env>, Array<Nat>>)>>(prism_rtl::rc([=, me1_pd_1 = std::move(me1_pd_1), b_p3_2 = std::move(b_p3_2)](std::tuple<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env>, Array<Nat>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto me1_pd_1_3 = me1_pd_1;
            auto b_p3_2_3 = b_p3_2;
            entered(once_job([=, me1_pd_1_3 = std::move(me1_pd_1_3), b_p3_2_3 = std::move(b_p3_2_3)]() {
            return ({
                auto [w_pe, be_pf] = p0;
                auto comp_pg = p1;
                fold_job(comp_pg, std::tuple{w_pe, be_pf}, ({
                auto me1_pd_1_3_3 = me1_pd_1_3;
                auto b_p3_2_3_3 = b_p3_2_3;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env>>(std::tuple<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env>, Nat>)>>(prism_rtl::rc([=, me1_pd_1_3_3 = std::move(me1_pd_1_3_3), b_p3_2_3_3 = std::move(b_p3_2_3_3)](std::tuple<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env>, Nat> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto me1_pd_1_3_3_3 = me1_pd_1_3_3;
                    auto b_p3_2_3_3_3 = b_p3_2_3_3;
                    entered(once_job([=, me1_pd_1_3_3_3 = std::move(me1_pd_1_3_3_3), b_p3_2_3_3_3 = std::move(b_p3_2_3_3_3)]() {
                    return ({
                        auto [w2_ph, be3_pi] = p0;
                        auto i_pj = p1;
                        (prism_rtl::more(prism_rtl::rc(PreInit(w2_ph, be3_pi, me1_pd_1_3_3_3, or_(index(b_p3_2_3_3_3.stmts, i_pj), crate::lower::expr::dummy_stmt_l())))));
                    });
                }));
                });
            }));
            }))->cycle();
            });
        }));
        });
    }));
    })));
    auto n_p5 = len(b_p3.stmts);
    auto start_p6 = len(prism_rtl::deref(wx2_pk).lets);
    auto&& _wx3_pu = run_to_end(fold_job(crate::check::errors::range0(n_p5), std::tuple{wx2_pk, be2_pl, me1_pd, Array<Nat>{}}, ({
        auto b_p3_1 = b_p3;
        auto n_p5_2 = n_p5;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, Array<Nat>>>(std::tuple<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, Array<Nat>>, Nat>)>>(prism_rtl::rc([=, b_p3_1 = std::move(b_p3_1), n_p5_2 = std::move(n_p5_2)](std::tuple<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, Array<Nat>>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto b_p3_1_3 = b_p3_1;
            auto n_p5_2_3 = n_p5_2;
            entered(once_job([=, b_p3_1_3 = std::move(b_p3_1_3), n_p5_2_3 = std::move(n_p5_2_3)]() {
            return ({
                auto [w_pm, be_pn, me_po, acc_pp] = p0;
                auto i_pq = p1;
                call_then(start_widget_stmt(w_pm, be_pn, me_po, or_(index(b_p3_1_3.stmts, i_pq), crate::lower::expr::dummy_stmt_l()), (i_pq + Nat(1u)) == n_p5_2_3), [=](std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env> widget_stmt_4499) {
                return ({
                    auto [w2_pr, be3_ps, me3_pt] = widget_stmt_4499;
                    (prism_rtl::finished(std::tuple{w2_pr, be3_ps, me3_pt, crate::prelude::push(acc_pp, len(prism_rtl::deref(w2_pr).lets))}));
                });
            });
            });
        }));
        });
    }));
    })));
    auto&& wx3_pu = std::get<0>(_wx3_pu);
    auto&& ends_pv = std::get<3>(_wx3_pu);
    return build_in_order(wx3_pu, b_p3.stmts, order_p4, start_p6, ends_pv);
}


prism_rtl::Turn<crate::lower::node_::Wx> BlockInto::cycle() const {
    const auto& wx_p0 = this->wx_p0;
    const auto& benv_p1 = this->benv_p1;
    const auto& menv_p2 = this->menv_p2;
    const auto& b_p3 = this->b_p3;
    auto b_p3_1 = b_p3;
    auto benv_p1_2 = benv_p1;
    auto menv_p2_3 = menv_p2;
    auto wx_p0_4 = wx_p0;
    return call_value(fold_job(prism_rtl::deref(b_p3_1).stmts, std::tuple{wx_p0_4, benv_p1_2, menv_p2_3}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>>(std::tuple<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>, crate::syntax::Stmt>)>>(prism_rtl::rc([=](std::tuple<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>, crate::syntax::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto [w_p7, be_p8, me_p9] = p0;
                auto s_pa = p1;
                (prism_rtl::more(prism_rtl::rc(PreBind(w_p7, be_p8, me_p9, s_pa))));
            });
        }));
    }))), [=](std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env> fold_4040) {
        return ({
            auto [wx1_pb, be1_pc, me1_pd] = fold_4040;
            call_then(start_build_order(prism_rtl::deref(b_p3_1).stmts), [=](Array<Array<Nat>> build_order_4131) {
            return ({
                auto order_p4 = build_order_4131;
                call_value(fold_job(order_p4, std::tuple{wx1_pb, be1_pc}, ({
                auto me1_pd_5 = me1_pd;
                auto b_p3_1_6 = b_p3_1;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env>>(std::tuple<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env>, Array<Nat>>)>>(prism_rtl::rc([=, me1_pd_5 = std::move(me1_pd_5), b_p3_1_6 = std::move(b_p3_1_6)](std::tuple<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env>, Array<Nat>> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto me1_pd_5_6 = me1_pd_5;
                    auto b_p3_1_6_6 = b_p3_1_6;
                    entered(once_job([=, me1_pd_5_6 = std::move(me1_pd_5_6), b_p3_1_6_6 = std::move(b_p3_1_6_6)]() {
                    return ({
                        auto [w_pe, be_pf] = p0;
                        auto comp_pg = p1;
                        fold_job(comp_pg, std::tuple{w_pe, be_pf}, ({
                        auto me1_pd_5_6_6 = me1_pd_5_6;
                        auto b_p3_1_6_6_6 = b_p3_1_6_6;
                        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env>>(std::tuple<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env>, Nat>)>>(prism_rtl::rc([=, me1_pd_5_6_6 = std::move(me1_pd_5_6_6), b_p3_1_6_6_6 = std::move(b_p3_1_6_6_6)](std::tuple<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env>, Nat> _p0) {
                        auto&& p0 = std::get<0>(_p0);
                        auto&& p1 = std::get<1>(_p0);
                        return ({
                            auto me1_pd_5_6_6_6 = me1_pd_5_6_6;
                            auto b_p3_1_6_6_6_6 = b_p3_1_6_6_6;
                            entered(once_job([=, me1_pd_5_6_6_6 = std::move(me1_pd_5_6_6_6), b_p3_1_6_6_6_6 = std::move(b_p3_1_6_6_6_6)]() {
                            return ({
                                auto [w2_ph, be3_pi] = p0;
                                auto i_pj = p1;
                                (prism_rtl::more(prism_rtl::rc(PreInit(w2_ph, be3_pi, me1_pd_5_6_6_6, or_(index(prism_rtl::deref(b_p3_1_6_6_6_6).stmts, i_pj), crate::lower::expr::dummy_stmt_l())))));
                            });
                        }));
                        });
                    }));
                    }))->cycle();
                    });
                }));
                });
            }));
            })), [=](std::tuple<crate::lower::node_::Wx, crate::lower::types::Env> fold_4173) {
                return ({
                    auto [wx2_pk, be2_pl] = fold_4173;
                    auto n_p5 = len(prism_rtl::deref(b_p3_1).stmts);
                    auto start_p6 = len(prism_rtl::deref(wx2_pk).lets);
                    call_value(fold_job(crate::check::errors::range0(n_p5), std::tuple{wx2_pk, be2_pl, me1_pd, Array<Nat>{}}, ({
                    auto b_p3_1_5 = b_p3_1;
                    auto n_p5_5 = n_p5;
                    static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, Array<Nat>>>(std::tuple<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, Array<Nat>>, Nat>)>>(prism_rtl::rc([=, b_p3_1_5 = std::move(b_p3_1_5), n_p5_5 = std::move(n_p5_5)](std::tuple<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, Array<Nat>>, Nat> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto b_p3_1_5_6 = b_p3_1_5;
                        auto n_p5_5_6 = n_p5_5;
                        entered(once_job([=, b_p3_1_5_6 = std::move(b_p3_1_5_6), n_p5_5_6 = std::move(n_p5_5_6)]() {
                        return ({
                            auto [w_pm, be_pn, me_po, acc_pp] = p0;
                            auto i_pq = p1;
                            call_then(start_widget_stmt(w_pm, be_pn, me_po, or_(index(prism_rtl::deref(b_p3_1_5_6).stmts, i_pq), crate::lower::expr::dummy_stmt_l()), (i_pq + Nat(1u)) == n_p5_5_6), [=](std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env> widget_stmt_4499) {
                            return ({
                                auto [w2_pr, be3_ps, me3_pt] = widget_stmt_4499;
                                (prism_rtl::finished(std::tuple{w2_pr, be3_ps, me3_pt, crate::prelude::push(acc_pp, len(prism_rtl::deref(w2_pr).lets))}));
                            });
                        });
                        });
                    }));
                    });
                }));
                })), [=, start_p6 = std::move(start_p6)](std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env, Array<Nat>> fold_4401) {
                    return ({
                        auto&& _wx3_pu = fold_4401;
                        auto&& wx3_pu = std::get<0>(_wx3_pu);
                        auto&& ends_pv = std::get<3>(_wx3_pu);
                        (prism_rtl::more(prism_rtl::rc(BuildInOrder(wx3_pu, prism_rtl::deref(b_p3_1).stmts, order_p4, start_p6, ends_pv))));
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start BlockInto, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::node_::Wx> start_block_into(crate::lower::node_::Wx wx_p0, crate::lower::types::Env benv_p1, crate::lower::types::Env menv_p2, crate::syntax::Block b_p3) {
    return prism_rtl::make_rc<BlockInto>(wx_p0, benv_p1, menv_p2, b_p3);
}


/// PreInit: unbounded fn Wx, Env, Env, Stmt -> ((Wx, Env))
std::tuple<crate::lower::node_::Wx, crate::lower::types::Env> pre_init(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& benv_p1, const crate::lower::types::Env& menv_p2, const crate::syntax::Stmt& s_p3) {
    auto&& _m = s_p3.kind;
    if (prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) && prism_rtl::is_some(prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2)) {
        auto&& p_p4 = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a0;
        auto&& _m = binding_of(menv_p2, p_p4);
        if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnHold>(prism_rtl::some_of(_m))) {
            auto&& f_p5 = prism_rtl::as<crate::lower::types::Bn::BnHold>(prism_rtl::some_of(_m)).a0;
            auto&& t_p6 = prism_rtl::as<crate::lower::types::Bn::BnHold>(prism_rtl::some_of(_m)).a1;
            auto wx2_p7 = ({
                crate::lower::node_::Wx this_ = wx_p0;
                this_.inited = crate::check::types::add_text(this_.inited, f_p5);
                (std::move(this_));
            });
            return std::tuple{wx2_p7, crate::lower::types::bind(benv_p1, prism_rtl::cat(pat_text(p_p4), "#init"), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat(f_p5, "_init")}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), t_p6}))};
        }
        {
            return std::tuple{wx_p0, benv_p1};
        }
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SLet>(_m)) {
        auto&& p_p8 = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
        auto&& e_p9 = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
        auto&& _m = binding_of(menv_p2, p_p8);
        if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m))) {
            auto&& t_pa = prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)).a2;
            auto rs_pb = crate::lower::snake(pat_text(p_p8));
            auto&& _reads_pd = crate::lower::node_::dynamics::dynamic_expr(wx_p0, menv_p2, e_p9);
            auto&& reads_pd = std::get<1>(_reads_pd);
            auto wx2_pc = ({
                crate::lower::node_::Wx this_ = wx_p0;
                this_.dyn_reads = insert(this_.dyn_reads, rs_pb, reads_pd);
                (std::move(this_));
            });
            return all_inited(wx2_pc, reads_pd) && names_inited(benv_p1, e_p9)
                ? ({
                auto wx3_pe = ({
                    crate::lower::node_::Wx this_ = wx2_pc;
                    this_.inited = crate::check::types::add_text(this_.inited, rs_pb);
                    (std::move(this_));
                });
                std::tuple{wx3_pe, crate::lower::types::bind(benv_p1, prism_rtl::cat(pat_text(p_p8), "#init"), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat(rs_pb, "_init")}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), t_pa}))};
            })
                : std::tuple{wx2_pc, benv_p1};
        }
        {
            return std::tuple{wx_p0, benv_p1};
        }
    }
    {
        return std::tuple{wx_p0, benv_p1};
    }
}


prism_rtl::Turn<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env>> PreInit::cycle() const {
    const auto& wx_p0 = this->wx_p0;
    const auto& benv_p1 = this->benv_p1;
    const auto& menv_p2 = this->menv_p2;
    const auto& s_p3 = this->s_p3;
    return ({
        auto&& _m = prism_rtl::deref(s_p3).kind;
        prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) && prism_rtl::is_some(prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2) ? ({
        auto&& p_p4 = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a0;
        ({
        auto&& _m = binding_of(menv_p2, p_p4);
        prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnHold>(prism_rtl::some_of(_m)) ? ({
        auto&& f_p5 = prism_rtl::as<crate::lower::types::Bn::BnHold>(prism_rtl::some_of(_m)).a0;
        auto&& t_p6 = prism_rtl::as<crate::lower::types::Bn::BnHold>(prism_rtl::some_of(_m)).a1;
        ({
        auto wx2_p7 = ({
            crate::lower::node_::Wx this_ = wx_p0;
            this_.inited = crate::check::types::add_text(this_.inited, f_p5);
            (std::move(this_));
        });
        (prism_rtl::finished(std::tuple{wx2_p7, crate::lower::types::bind(benv_p1, prism_rtl::cat(pat_text(p_p4), "#init"), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat(f_p5, "_init")}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), t_p6}))}));
    });
    })
        : prism_rtl::finished(std::tuple{wx_p0, benv_p1});
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SLet>(_m) ? ({
        auto&& p_p8 = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
        auto&& e_p9 = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
        ({
        auto&& _m = binding_of(menv_p2, p_p8);
        prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)) ? ({
        auto&& t_pa = prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)).a2;
        ({
        auto rs_pb = crate::lower::snake(pat_text(p_p8));
        auto benv_p1_1 = benv_p1;
        auto e_p9_2 = e_p9;
        auto menv_p2_3 = menv_p2;
        auto p_p8_4 = p_p8;
        auto wx_p0_5 = wx_p0;
        call_then(crate::lower::node_::dynamics::start_dynamic_expr(wx_p0_5, menv_p2_3, e_p9_2), [=, rs_pb = std::move(rs_pb), benv_p1_1 = std::move(benv_p1_1), p_p8_4 = std::move(p_p8_4)](std::tuple<crate::lower::model::Ex, Array<crate::lower::node_::Read>> dynamic_expr_5593) {
        return ({
            auto&& _reads_pd = dynamic_expr_5593;
            auto&& reads_pd = std::get<1>(_reads_pd);
            auto wx2_pc = ({
                crate::lower::node_::Wx this_ = wx_p0_5;
                this_.dyn_reads = insert(this_.dyn_reads, rs_pb, reads_pd);
                (std::move(this_));
            });
            all_inited(wx2_pc, reads_pd) && names_inited(benv_p1_1, e_p9_2)
            ? ({
            auto wx3_pe = ({
                crate::lower::node_::Wx this_ = wx2_pc;
                this_.inited = crate::check::types::add_text(this_.inited, rs_pb);
                (std::move(this_));
            });
            (prism_rtl::finished(std::tuple{wx3_pe, crate::lower::types::bind(benv_p1_1, prism_rtl::cat(pat_text(p_p8_4), "#init"), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat(rs_pb, "_init")}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), t_pa}))}));
        })
            : prism_rtl::finished(std::tuple{wx2_pc, benv_p1_1});
        });
    });
    });
    })
        : prism_rtl::finished(std::tuple{wx_p0, benv_p1});
    });
    })
        : prism_rtl::finished(std::tuple{wx_p0, benv_p1});
    });
}


/// `Start PreInit, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env>> start_pre_init(crate::lower::node_::Wx wx_p0, crate::lower::types::Env benv_p1, crate::lower::types::Env menv_p2, crate::syntax::Stmt s_p3) {
    return prism_rtl::make_rc<PreInit>(wx_p0, benv_p1, menv_p2, s_p3);
}


/// BuildInOrder: unbounded fn Wx, [Stmt], [ [Nat] ], Nat, [Nat] -> Wx
crate::lower::node_::Wx build_in_order(const crate::lower::node_::Wx& wx_p0, const Array<crate::syntax::Stmt>& stmts_p1, const Array<Array<Nat>>& order_p2, const Nat& start_p3, const Array<Nat>& ends_p4) {
    auto n_p5 = len(stmts_p1);
    auto last_p6 = or_(index(ends_p4, crate::syntax::lexer::chars::dec(n_p5)), start_p3);
    auto runs_p7 = each(crate::check::errors::range0(n_p5), [&](const Nat& i_pb) {
        return ({
            auto from_pc = i_pb == Nat(0u)
                ? start_p3
                : or_(index(ends_p4, crate::syntax::lexer::chars::dec(i_pb)), start_p3);
            take(drop(wx_p0.lets, from_pc), or_(or_(index(ends_p4, i_pb), from_pc).checked_sub(from_pc), Nat(0u)));
        });
    });
    auto lets_p8 = fold(order_p2, take(wx_p0.lets, start_p3), [&](const Array<crate::lower::model::Do>& acc_pd, const Array<Nat>& comp_pe) { return fold(comp_pe, acc_pd, [&](const Array<crate::lower::model::Do>& acc2_pf, const Nat& i_pg) { return append(acc2_pf, or_(index(runs_p7, i_pg), Array<crate::lower::model::Do>{})); }); });
    auto cyclic_p9 = filter(order_p2, [&](const Array<Nat>& comp_ph) { return (len(comp_ph) > Nat(1u)) && fold(comp_ph, false, [&](const bool& seen_pi, const Nat& i_pj) { return prism_rtl::deref(seen_pi) || (len(or_(index(runs_p7, i_pj), Array<crate::lower::model::Do>{})) > Nat(0u)); }); });
    auto wx2_pa = ({
        crate::lower::node_::Wx this_ = wx_p0;
        this_.lets = append(lets_p8, drop(wx_p0.lets, last_p6));
        (std::move(this_));
    });
    return run_to_end(fold_job(cyclic_p9, wx2_pa, ({
        auto stmts_p1_1 = stmts_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::node_::Wx>(std::tuple<crate::lower::node_::Wx, Array<Nat>>)>>(prism_rtl::rc([=, stmts_p1_1 = std::move(stmts_p1_1)](std::tuple<crate::lower::node_::Wx, Array<Nat>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto stmts_p1_1_2 = stmts_p1_1;
            entered(once_job([=, stmts_p1_1_2 = std::move(stmts_p1_1_2)]() {
            return ({
                auto w_pk = p0;
                auto comp_pl = p1;
                (prism_rtl::finished(({
                crate::lower::node_::Wx this_ = w_pk;
                this_.build = crate::prelude::push(this_.build, crate::lower::expr::refusal_do(prism_rtl::cat("lines that read each other at the build (", crate::syntax::lexer::chars::join(run_to_end(fold_job(comp_pl, Array<Text>{}, ({
                    auto stmts_p1_1_2_2 = stmts_p1_1_2;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Nat>)>>(prism_rtl::rc([=, stmts_p1_1_2_2 = std::move(stmts_p1_1_2_2)](std::tuple<Array<Text>, Nat> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto stmts_p1_1_2_2_2 = stmts_p1_1_2_2;
                        entered(once_job([=, stmts_p1_1_2_2_2 = std::move(stmts_p1_1_2_2_2)]() {
                        return ({
                            auto acc_pm = p0;
                            auto i_pn = p1;
                            call_then(crate::check::blocks::start_group_defs(or_(index(stmts_p1_1_2_2_2, i_pn), crate::lower::expr::dummy_stmt_l())), [=, acc_pm = std::move(acc_pm)](Array<Text> group_defs_7245) { return prism_rtl::finished(append(acc_pm, group_defs_7245)); });
                        });
                    }));
                    });
                })));
                }))), Text::lit(", ")), "): a cycle among values")));
                (std::move(this_));
            })));
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<crate::lower::node_::Wx> BuildInOrder::cycle() const {
    const auto& wx_p0 = this->wx_p0;
    const auto& stmts_p1 = this->stmts_p1;
    const auto& order_p2 = this->order_p2;
    const auto& start_p3 = this->start_p3;
    const auto& ends_p4 = this->ends_p4;
    auto n_p5 = len(stmts_p1);
    auto last_p6 = or_(index(ends_p4, crate::syntax::lexer::chars::dec(n_p5)), start_p3);
    auto runs_p7 = each(crate::check::errors::range0(n_p5), [&](const Nat& i_pb) {
        return ({
            auto from_pc = i_pb == Nat(0u)
                ? start_p3
                : or_(index(ends_p4, crate::syntax::lexer::chars::dec(i_pb)), start_p3);
            take(drop(prism_rtl::deref(wx_p0).lets, from_pc), or_(or_(index(ends_p4, i_pb), from_pc).checked_sub(from_pc), Nat(0u)));
        });
    });
    auto lets_p8 = fold(order_p2, take(prism_rtl::deref(wx_p0).lets, start_p3), [&](const Array<crate::lower::model::Do>& acc_pd, const Array<Nat>& comp_pe) { return fold(comp_pe, acc_pd, [&](const Array<crate::lower::model::Do>& acc2_pf, const Nat& i_pg) { return append(acc2_pf, or_(index(runs_p7, i_pg), Array<crate::lower::model::Do>{})); }); });
    auto cyclic_p9 = filter(order_p2, [&](const Array<Nat>& comp_ph) { return (len(comp_ph) > Nat(1u)) && fold(comp_ph, false, [&](const bool& seen_pi, const Nat& i_pj) { return prism_rtl::deref(seen_pi) || (len(or_(index(runs_p7, i_pj), Array<crate::lower::model::Do>{})) > Nat(0u)); }); });
    auto wx2_pa = ({
        crate::lower::node_::Wx this_ = wx_p0;
        this_.lets = append(lets_p8, drop(prism_rtl::deref(wx_p0).lets, last_p6));
        (std::move(this_));
    });
    return fold_job(cyclic_p9, wx2_pa, ({
        auto stmts_p1_1 = stmts_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::node_::Wx>(std::tuple<crate::lower::node_::Wx, Array<Nat>>)>>(prism_rtl::rc([=, stmts_p1_1 = std::move(stmts_p1_1)](std::tuple<crate::lower::node_::Wx, Array<Nat>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto stmts_p1_1_2 = stmts_p1_1;
            entered(once_job([=, stmts_p1_1_2 = std::move(stmts_p1_1_2)]() {
            return ({
                auto w_pk = p0;
                auto comp_pl = p1;
                (prism_rtl::finished(({
                crate::lower::node_::Wx this_ = w_pk;
                this_.build = crate::prelude::push(this_.build, crate::lower::expr::refusal_do(prism_rtl::cat("lines that read each other at the build (", crate::syntax::lexer::chars::join(run_to_end(fold_job(comp_pl, Array<Text>{}, ({
                    auto stmts_p1_1_2_2 = stmts_p1_1_2;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Nat>)>>(prism_rtl::rc([=, stmts_p1_1_2_2 = std::move(stmts_p1_1_2_2)](std::tuple<Array<Text>, Nat> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto stmts_p1_1_2_2_2 = stmts_p1_1_2_2;
                        entered(once_job([=, stmts_p1_1_2_2_2 = std::move(stmts_p1_1_2_2_2)]() {
                        return ({
                            auto acc_pm = p0;
                            auto i_pn = p1;
                            call_then(crate::check::blocks::start_group_defs(or_(index(stmts_p1_1_2_2_2, i_pn), crate::lower::expr::dummy_stmt_l())), [=, acc_pm = std::move(acc_pm)](Array<Text> group_defs_7245) { return prism_rtl::finished(append(acc_pm, group_defs_7245)); });
                        });
                    }));
                    });
                })));
                }))), Text::lit(", ")), "): a cycle among values")));
                (std::move(this_));
            })));
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start BuildInOrder, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::node_::Wx> start_build_in_order(crate::lower::node_::Wx wx_p0, Array<crate::syntax::Stmt> stmts_p1, Array<Array<Nat>> order_p2, Nat start_p3, Array<Nat> ends_p4) {
    return prism_rtl::make_rc<BuildInOrder>(wx_p0, stmts_p1, order_p2, start_p3, ends_p4);
}


/// BuildOrder: unbounded fn [Stmt] -> [ [Nat] ]
Array<Array<Nat>> build_order(const Array<crate::syntax::Stmt>& stmts_p0) {
    auto n_p1 = len(stmts_p0);
    auto defs_p2 = run_to_end(each_job(stmts_p0, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(crate::syntax::Stmt)>>(prism_rtl::rc([=](crate::syntax::Stmt p0) {
        return entered(once_job([=]() {
            return ({
                auto s_p7 = p0;
                call_then(crate::check::blocks::start_group_defs(s_p7), [=](Array<Text> group_defs_7730) { return prism_rtl::finished(filter(group_defs_7730, [&](const Text& d_p8) { return !crate::syntax::lexer::chars::has_prefix(d_p8, Text::lit("!")); })); });
            });
        }));
    }))));
    auto reads_p3 = run_to_end(each_job(stmts_p0, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(crate::syntax::Stmt)>>(prism_rtl::rc([=](crate::syntax::Stmt p0) {
        return entered(once_job([=]() {
            return ({
                auto s_p9 = p0;
                (prism_rtl::more(prism_rtl::rc(ReadsAtBuild(s_p9))));
            });
        }));
    }))));
    auto deps_p4 = each(crate::check::errors::range0(n_p1), [&](const Nat& i_pa) { return filter(crate::check::errors::range0(n_p1), [&](const Nat& j_pb) { return (j_pb != i_pa) && fold(or_(index(defs_p2, j_pb), Array<Text>{}), false, [&](const bool& seen_pc, const Text& d_pd) { return prism_rtl::deref(seen_pc) || crate::check::types::has_text(or_(index(reads_p3, i_pa), Array<Text>{}), d_pd); }); }); });
    auto reach_p5 = run_to_end(each_job(crate::check::errors::range0(n_p1), ({
        auto deps_p4_1 = deps_p4;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(Nat)>>(prism_rtl::rc([=, deps_p4_1 = std::move(deps_p4_1)](Nat p0) {
        return ({
            auto deps_p4_1_2 = deps_p4_1;
            entered(once_job([=, deps_p4_1_2 = std::move(deps_p4_1_2)]() {
            return ({
                auto i_pe = p0;
                (prism_rtl::more(prism_rtl::rc(crate::check::blocks::ReachIdx(deps_p4_1_2, or_(index(deps_p4_1_2, i_pe), Array<Nat>{}), Array<Nat>{}))));
            });
        }));
        });
    })));
    })));
    auto comps_p6 = each(crate::check::errors::range0(n_p1), [&](const Nat& i_pf) { return filter(crate::check::errors::range0(n_p1), [&](const Nat& j_pg) { return (j_pg == i_pf) || (crate::check::types::has_nat(or_(index(reach_p5, i_pf), Array<Nat>{}), j_pg) && crate::check::types::has_nat(or_(index(reach_p5, j_pg), Array<Nat>{}), i_pf)); }); });
    return crate::check::blocks::emit_groups(comps_p6, deps_p4, Array<Nat>{}, Array<Array<Nat>>{});
}


prism_rtl::Turn<Array<Array<Nat>>> BuildOrder::cycle() const {
    const auto& stmts_p0 = this->stmts_p0;
    auto n_p1 = len(stmts_p0);
    auto stmts_p0_1 = stmts_p0;
    return call_value(each_job(stmts_p0_1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(crate::syntax::Stmt)>>(prism_rtl::rc([=](crate::syntax::Stmt p0) {
        return entered(once_job([=]() {
            return ({
                auto s_p7 = p0;
                call_then(crate::check::blocks::start_group_defs(s_p7), [=](Array<Text> group_defs_7730) { return prism_rtl::finished(filter(group_defs_7730, [&](const Text& d_p8) { return !crate::syntax::lexer::chars::has_prefix(d_p8, Text::lit("!")); })); });
            });
        }));
    }))), [=](Array<Array<Text>> each_7705) {
        return ({
            auto defs_p2 = each_7705;
            call_value(each_job(stmts_p0_1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(crate::syntax::Stmt)>>(prism_rtl::rc([=](crate::syntax::Stmt p0) {
            return entered(once_job([=]() {
                return ({
                    auto s_p9 = p0;
                    (prism_rtl::more(prism_rtl::rc(ReadsAtBuild(s_p9))));
                });
            }));
        }))), [=, defs_p2 = std::move(defs_p2)](Array<Array<Text>> each_7801) {
            return ({
                auto reads_p3 = each_7801;
                auto deps_p4 = each(crate::check::errors::range0(n_p1), [&](const Nat& i_pa) { return filter(crate::check::errors::range0(n_p1), [&](const Nat& j_pb) { return (j_pb != i_pa) && fold(or_(index(defs_p2, j_pb), Array<Text>{}), false, [&](const bool& seen_pc, const Text& d_pd) { return prism_rtl::deref(seen_pc) || crate::check::types::has_text(or_(index(reads_p3, i_pa), Array<Text>{}), d_pd); }); }); });
                call_value(each_job(crate::check::errors::range0(n_p1), ({
                auto deps_p4_2 = deps_p4;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(Nat)>>(prism_rtl::rc([=, deps_p4_2 = std::move(deps_p4_2)](Nat p0) {
                return ({
                    auto deps_p4_2_3 = deps_p4_2;
                    entered(once_job([=, deps_p4_2_3 = std::move(deps_p4_2_3)]() {
                    return ({
                        auto i_pe = p0;
                        (prism_rtl::more(prism_rtl::rc(crate::check::blocks::ReachIdx(deps_p4_2_3, or_(index(deps_p4_2_3, i_pe), Array<Nat>{}), Array<Nat>{}))));
                    });
                }));
                });
            })));
            })), [=](Array<Array<Nat>> each_8003) {
                return ({
                    auto reach_p5 = each_8003;
                    auto comps_p6 = each(crate::check::errors::range0(n_p1), [&](const Nat& i_pf) { return filter(crate::check::errors::range0(n_p1), [&](const Nat& j_pg) { return (j_pg == i_pf) || (crate::check::types::has_nat(or_(index(reach_p5, i_pf), Array<Nat>{}), j_pg) && crate::check::types::has_nat(or_(index(reach_p5, j_pg), Array<Nat>{}), i_pf)); }); });
                    (prism_rtl::more(prism_rtl::rc(crate::check::blocks::EmitGroups(comps_p6, deps_p4, Array<Nat>{}, Array<Array<Nat>>{}))));
                });
            });
            });
        });
        });
    });
}


/// `Start BuildOrder, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Array<Nat>>> start_build_order(Array<crate::syntax::Stmt> stmts_p0) {
    return prism_rtl::make_rc<BuildOrder>(stmts_p0);
}


/// ReadsAtBuild: unbounded fn Stmt -> [Text]
Array<Text> reads_at_build(const crate::syntax::Stmt& s_p0) {
    auto&& _m = s_p0.kind;
    if (prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) && prism_rtl::is_some(prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2)) {
        auto&& init_p1 = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a1;
        return crate::lower::expr::free_reads(crate::check::typed::print::exprs_in(init_p1), Array<std::tuple<Array<Text>, crate::syntax::Range>>{});
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SFn>(_m)) {
        auto&& f_p2 = prism_rtl::as<crate::syntax::StmtKind::SFn>(_m).a0;
        return crate::lower::expr::free_reads(crate::check::typed::print::stmt_exprs(s_p0), Array(std::vector{std::tuple{run_to_end(fold_job(prism_rtl::deref(f_p2).params, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Pattern_> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc_p3 = p0;
                    auto q_p4 = p1;
                    call_then(crate::check::env::names::start_pattern_names(q_p4), [=, acc_p3 = std::move(acc_p3)](Array<Text> pattern_names_8794) { return prism_rtl::finished(append(acc_p3, pattern_names_8794)); });
                });
            }));
        })))), prism_rtl::deref(f_p2).span}}));
    }
    {
        return crate::lower::expr::free_reads(crate::check::typed::print::stmt_exprs(s_p0), Array<std::tuple<Array<Text>, crate::syntax::Range>>{});
    }
}


prism_rtl::Turn<Array<Text>> ReadsAtBuild::cycle() const {
    const auto& s_p0 = this->s_p0;
    return ({
        auto&& _m = prism_rtl::deref(s_p0).kind;
        prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) && prism_rtl::is_some(prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2) ? ({
        auto&& init_p1 = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a1;
        ({
        auto init_p1_1 = init_p1;
        call_then(crate::check::typed::print::start_exprs_in(init_p1_1), [=](Array<crate::syntax::Expr> exprs_in_8689) { return prism_rtl::more(prism_rtl::rc(crate::lower::expr::FreeReads(exprs_in_8689, Array<std::tuple<Array<Text>, crate::syntax::Range>>{}))); });
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SFn>(_m) ? ({
        auto&& f_p2 = prism_rtl::as<crate::syntax::StmtKind::SFn>(_m).a0;
        ({
        auto f_p2_1 = f_p2;
        auto s_p0_2 = s_p0;
        call_then(crate::check::typed::print::start_stmt_exprs(s_p0_2), [=, f_p2_1 = std::move(f_p2_1)](Array<crate::syntax::Expr> stmt_exprs_8731) {
        return call_value(fold_job(prism_rtl::deref(f_p2_1).params, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Pattern_> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc_p3 = p0;
                    auto q_p4 = p1;
                    call_then(crate::check::env::names::start_pattern_names(q_p4), [=, acc_p3 = std::move(acc_p3)](Array<Text> pattern_names_8794) { return prism_rtl::finished(append(acc_p3, pattern_names_8794)); });
                });
            }));
        }))), [=](Array<Text> fold_8750) { return prism_rtl::more(prism_rtl::rc(crate::lower::expr::FreeReads(stmt_exprs_8731, Array(std::vector{std::tuple{fold_8750, prism_rtl::deref(f_p2_1).span}})))); });
    });
    });
    })
        : ({
        auto s_p0_1 = s_p0;
        call_then(crate::check::typed::print::start_stmt_exprs(s_p0_1), [=](Array<crate::syntax::Expr> stmt_exprs_8849) { return prism_rtl::more(prism_rtl::rc(crate::lower::expr::FreeReads(stmt_exprs_8849, Array<std::tuple<Array<Text>, crate::syntax::Range>>{}))); });
    });
    });
}


/// `Start ReadsAtBuild, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_reads_at_build(crate::syntax::Stmt s_p0) {
    return prism_rtl::make_rc<ReadsAtBuild>(s_p0);
}


/// PreBind: unbounded fn Wx, Env, Env, Stmt -> ((Wx, Env, Env))
std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env> pre_bind(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& benv_p1, const crate::lower::types::Env& menv_p2, const crate::syntax::Stmt& s_p3) {
    auto&& _m = s_p3.kind;
    if (prism_rtl::is<crate::syntax::StmtKind::SBind>(_m)) {
        auto&& p_p4 = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a0;
        auto&& init_p5 = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a1;
        auto&& step_o6 = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2;
        auto how_p7 = (step_o6 == std::optional<crate::syntax::Expr>{}) && gives_result(wx_p0.lx, menv_p2, init_p5)
            ? HowBound(HowBound::AsResult{})
            : how_bound(step_o6);
        auto&& _m = prism_rtl::deref(prism_rtl::deref(p_p4).kind);
        if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
            auto&& n_p8 = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
            return pre_bind_name(wx_p0, benv_p1, menv_p2, n_p8, how_p7);
        }
        if (prism_rtl::is<crate::syntax::PatternKind::PTuple>(_m)) {
            auto&& ps_p9 = prism_rtl::as<crate::syntax::PatternKind::PTuple>(_m).a0;
            return run_to_end(fold_job(ps_p9, std::tuple{wx_p0, benv_p1, menv_p2}, ({
                auto how_p7_1 = how_p7;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>>(std::tuple<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>, crate::syntax::Pattern_>)>>(prism_rtl::rc([=, how_p7_1 = std::move(how_p7_1)](std::tuple<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>, crate::syntax::Pattern_> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto how_p7_1_2 = how_p7_1;
                    entered(once_job([=, how_p7_1_2 = std::move(how_p7_1_2)]() {
                    return ({
                        auto [w_pa, be_pb, me_pc] = p0;
                        auto q_pd = p1;
                        ({
                        auto&& _m = prism_rtl::deref(prism_rtl::deref(q_pd).kind);
                        prism_rtl::is<crate::syntax::PatternKind::PName>(_m) ? ({
                        auto&& n_pe = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
                        prism_rtl::more(prism_rtl::rc(PreBindName(w_pa, be_pb, me_pc, n_pe, how_p7_1_2)));
                    })
                        : prism_rtl::finished(std::tuple{w_pa, be_pb, me_pc});
                    });
                    });
                }));
                });
            }));
            })));
        }
        {
            return std::tuple{wx_p0, benv_p1, menv_p2};
        }
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SLet>(_m)) {
        auto&& p_pf = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
        auto&& _m = prism_rtl::deref(prism_rtl::deref(p_pf).kind);
        if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
            auto&& n_pg = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
            return pre_bind_name(wx_p0, benv_p1, menv_p2, n_pg, HowBound(HowBound::AsLet{}));
        }
        {
            return std::tuple{wx_p0, benv_p1, menv_p2};
        }
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SFn>(_m)) {
        auto&& c_ph = prism_rtl::as<crate::syntax::StmtKind::SFn>(_m).a0;
        auto fname_pi = crate::check::env::def_name_text(prism_rtl::deref(c_ph).name);
        return std::tuple{wx_p0, crate::lower::types::bind(benv_p1, fname_pi, crate::lower::types::Bn(crate::lower::types::Bn::BnLocalFn{c_ph})), crate::lower::types::bind(menv_p2, fname_pi, crate::lower::types::Bn(crate::lower::types::Bn::BnLocalFn{c_ph}))};
    }
    {
        return std::tuple{wx_p0, benv_p1, menv_p2};
    }
}


prism_rtl::Turn<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>> PreBind::cycle() const {
    const auto& wx_p0 = this->wx_p0;
    const auto& benv_p1 = this->benv_p1;
    const auto& menv_p2 = this->menv_p2;
    const auto& s_p3 = this->s_p3;
    return ({
        auto&& _m = prism_rtl::deref(s_p3).kind;
        prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) ? ({
        auto&& p_p4 = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a0;
        auto&& init_p5 = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a1;
        auto&& step_o6 = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2;
        ({
        auto how_p7 = (step_o6 == std::optional<crate::syntax::Expr>{}) && gives_result(prism_rtl::deref(wx_p0).lx, menv_p2, init_p5)
            ? HowBound(HowBound::AsResult{})
            : how_bound(step_o6);
        ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(p_p4).kind);
        prism_rtl::is<crate::syntax::PatternKind::PName>(_m) ? ({
        auto&& n_p8 = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        prism_rtl::more(prism_rtl::rc(PreBindName(wx_p0, benv_p1, menv_p2, n_p8, how_p7)));
    })
        : prism_rtl::is<crate::syntax::PatternKind::PTuple>(_m) ? ({
        auto&& ps_p9 = prism_rtl::as<crate::syntax::PatternKind::PTuple>(_m).a0;
        fold_job(ps_p9, std::tuple{wx_p0, benv_p1, menv_p2}, ({
        auto how_p7_1 = how_p7;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>>(std::tuple<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>, crate::syntax::Pattern_>)>>(prism_rtl::rc([=, how_p7_1 = std::move(how_p7_1)](std::tuple<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>, crate::syntax::Pattern_> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto how_p7_1_2 = how_p7_1;
            entered(once_job([=, how_p7_1_2 = std::move(how_p7_1_2)]() {
            return ({
                auto [w_pa, be_pb, me_pc] = p0;
                auto q_pd = p1;
                ({
                auto&& _m = prism_rtl::deref(prism_rtl::deref(q_pd).kind);
                prism_rtl::is<crate::syntax::PatternKind::PName>(_m) ? ({
                auto&& n_pe = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
                prism_rtl::more(prism_rtl::rc(PreBindName(w_pa, be_pb, me_pc, n_pe, how_p7_1_2)));
            })
                : prism_rtl::finished(std::tuple{w_pa, be_pb, me_pc});
            });
            });
        }));
        });
    }));
    }))->cycle();
    })
        : prism_rtl::finished(std::tuple{wx_p0, benv_p1, menv_p2});
    });
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SLet>(_m) ? ({
        auto&& p_pf = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
        ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(p_pf).kind);
        prism_rtl::is<crate::syntax::PatternKind::PName>(_m) ? ({
        auto&& n_pg = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        prism_rtl::more(prism_rtl::rc(PreBindName(wx_p0, benv_p1, menv_p2, n_pg, HowBound(HowBound::AsLet{}))));
    })
        : prism_rtl::finished(std::tuple{wx_p0, benv_p1, menv_p2});
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SFn>(_m) ? ({
        auto&& c_ph = prism_rtl::as<crate::syntax::StmtKind::SFn>(_m).a0;
        ({
        auto fname_pi = crate::check::env::def_name_text(prism_rtl::deref(c_ph).name);
        (prism_rtl::finished(std::tuple{wx_p0, crate::lower::types::bind(benv_p1, fname_pi, crate::lower::types::Bn(crate::lower::types::Bn::BnLocalFn{c_ph})), crate::lower::types::bind(menv_p2, fname_pi, crate::lower::types::Bn(crate::lower::types::Bn::BnLocalFn{c_ph}))}));
    });
    })
        : prism_rtl::finished(std::tuple{wx_p0, benv_p1, menv_p2});
    });
}


/// `Start PreBind, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>> start_pre_bind(crate::lower::node_::Wx wx_p0, crate::lower::types::Env benv_p1, crate::lower::types::Env menv_p2, crate::syntax::Stmt s_p3) {
    return prism_rtl::make_rc<PreBind>(wx_p0, benv_p1, menv_p2, s_p3);
}


/// GivesResult: unbounded fn Lx, Env, Expr -> Bool
bool gives_result(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& menv_p1, const crate::syntax::Expr& e_p2) {
    auto&& _m = prism_rtl::deref(e_p2.kind);
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x_p3 = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return gives_result(lx_p0, menv_p1, prism_rtl::deref(prism_rtl::deref(x_p3)));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EWidgetBlock>(_m)) {
        return true;
    }
    {
        auto callee_p4 = ({
            __label__ _done;
            prism_rtl::Slot<crate::syntax::Expr> _v;
            auto&& _m = prism_rtl::deref(e_p2.kind);
            if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
                auto&& c_p5 = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
                _v.set(prism_rtl::deref(prism_rtl::deref(c_p5)));
                goto _done;
            }
            {
                _v.set(e_p2);
                goto _done;
            }
        _done:
            _v.take();
        });
        auto&& _m = prism_rtl::deref(prism_rtl::deref(callee_p4).kind);
        if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
            auto&& n_p6 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
            auto&& _m = crate::prelude::get(menv_p1.names, crate::check::env::sname_key(n_p6));
            if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnWidget>(prism_rtl::some_of(_m))) {
                return true;
            }
            {
                auto&& _q_o7 = crate::check::env::names::resolve_value(lx_p0.g, lx_p0.home, n_p6);
                auto&& q_o7 = std::get<0>(_q_o7);
                if (prism_rtl::is_some(q_o7)) {
                    auto&& q_p8 = prism_rtl::some_of(q_o7);
                    return is_getter_builtin(q_p8) || (((!is_prelude_name(q_p8)) && (crate::prelude::get(prism_rtl::deref(lx_p0.g).vals, q_p8) != std::optional<crate::check::env::ValInfo>{})) && is_widget_ty(crate::lower::types::peel(crate::lower::type_at(lx_p0, e_p2.span))));
                }
                if (prism_rtl::is_none(q_o7)) {
                    return false;
                }
                prism_rtl::unreachable("no arm matched");
            }
        }
        {
            return false;
        }
    }
}


prism_rtl::Turn<bool> GivesResult::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& menv_p1 = this->menv_p1;
    const auto& e_p2 = this->e_p2;
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p2).kind);
        prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
        auto&& x_p3 = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(GivesResult(lx_p0, menv_p1, prism_rtl::deref(prism_rtl::deref(x_p3)))));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EWidgetBlock>(_m) ? prism_rtl::finished(true)
        : ({
        auto callee_p4 = ({
            __label__ _done;
            prism_rtl::Slot<crate::syntax::Expr> _v;
            auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p2).kind);
            if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
                auto&& c_p5 = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
                _v.set(prism_rtl::deref(prism_rtl::deref(c_p5)));
                goto _done;
            }
            {
                _v.set(e_p2);
                goto _done;
            }
        _done:
            _v.take();
        });
        ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(callee_p4).kind);
        prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? ({
        auto&& n_p6 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        ({
        auto&& _m = crate::prelude::get(menv_p1->names, crate::check::env::sname_key(n_p6));
        prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnWidget>(prism_rtl::some_of(_m)) ? prism_rtl::finished(true)
        : ({
        auto&& _q_o7 = crate::check::env::names::resolve_value(prism_rtl::deref(lx_p0).g, prism_rtl::deref(lx_p0).home, n_p6);
        auto&& q_o7 = std::get<0>(_q_o7);
        ({
        prism_rtl::is_some(q_o7) ? ({
        auto&& q_p8 = prism_rtl::some_of(q_o7);
        prism_rtl::finished(is_getter_builtin(q_p8) || (((!is_prelude_name(q_p8)) && (crate::prelude::get(prism_rtl::deref(prism_rtl::deref(lx_p0).g).vals, q_p8) != std::optional<crate::check::env::ValInfo>{})) && is_widget_ty(crate::lower::types::peel(crate::lower::type_at(lx_p0, prism_rtl::deref(e_p2).span)))));
    })
        : prism_rtl::is_none(q_o7) ? prism_rtl::finished(false)
        : throw prism_rtl::Panic("no arm matched");
    });
    });
    });
    })
        : prism_rtl::finished(false);
    });
    });
    });
}


/// `Start GivesResult, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_gives_result(crate::lower::Lx lx_p0, crate::lower::types::Env menv_p1, crate::syntax::Expr e_p2) {
    return prism_rtl::make_rc<GivesResult>(lx_p0, menv_p1, e_p2);
}


/// IsPreludeName: fn Text -> Bool
bool is_prelude_name(const Text& q_p0) {
    return crate::prelude::find(([]() -> const Regex& { static const Regex r = Regex::lit("^Prelude\\.", ""); return r; }()), q_p0) != std::optional<Match>{};
}


/// IsGetterBuiltin: fn Text -> Bool
bool is_getter_builtin(const Text& q_p0) {
    return ((q_p0 == Text::lit("Prelude.@Distinct")) || (q_p0 == Text::lit("Prelude.@PerKey"))) || (q_p0 == Text::lit("Prelude.@Flatten"));
}


/// IsWidgetTy: fn Ty -> Bool
bool is_widget_ty(const crate::check::types::Ty& t_p0) {
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(t_p0)) {
        return true;
    }
    {
        return false;
    }
}


/// HowBound: fn ?Expr -> HowBound
HowBound how_bound(const std::optional<crate::syntax::Expr>& opt0) {
    if (prism_rtl::is_some(opt0)) {
        return HowBound(HowBound::AsHold{});
    }
    if (prism_rtl::is_none(opt0)) {
        return HowBound(HowBound::AsBind{});
    }
    prism_rtl::unreachable("no arm matched");
}


/// PreBindName: unbounded fn Wx, Env, Env, SName, HowBound -> ((Wx, Env, Env))
std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env> pre_bind_name(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& benv_p1, const crate::lower::types::Env& menv_p2, const crate::syntax::SName& n_p3, const HowBound& how_p4) {
    auto lx_p5 = crate::lower::expr::widget_let_lx(wx_p0.lx, n_p3.span);
    auto nkey_p6 = crate::check::env::sname_key(n_p3);
    auto full_p7 = crate::lower::binder_ty(lx_p5, n_p3.span);
    auto layer_p8 = crate::lower::types::layer_of(full_p7);
    auto t_p9 = crate::lower::types::out_ty_of(lx_p5, crate::lower::types::peel(full_p7));
    auto [rs_pa, wx1_pb] = crate::lower::node_::fresh_name(wx_p0, crate::lower::snake(nkey_p6));
    return ((how_p4 == HowBound(HowBound::AsBind{})) || (how_p4 == HowBound(HowBound::AsResult{}))) && crate::lower::types::is_bundle(full_p7)
        ? std::tuple{wx_p0, benv_p1, menv_p2}
        : (layer_p8 == crate::lower::types::Layer(crate::lower::types::Layer::LyEv{})) || is_switched(full_p7)
        ? ({
        auto et_pc = crate::lower::types::out_ty_of(lx_p5, crate::lower::types::peel(crate::lower::types::peel(full_p7)));
        auto [id_pj, wx2_pk] = crate::lower::node_::add_gn(wx1_pb, rs_pa, et_pc, crate::lower::node_::GnKind(crate::lower::node_::GnKind::GnNamed{}), Nat(0u));
        auto b_pd = crate::lower::types::Bn(crate::lower::types::Bn::BnEv{crate::lower::node_::ev_ref_of(wx2_pk, id_pj), t_p9});
        auto pf_pe = prism_rtl::cat(rs_pa, "_v_port");
        auto pt_pf = crate::lower::model::OutTy(crate::lower::model::OutTy::OutRc{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutPort{prism_rtl::rc(et_pc)}))});
        auto wx3_pg = ({
            crate::lower::node_::Wx this_ = crate::lower::node_::connect(wx2_pk, crate::lower::node_::ev_ref_of(wx2_pk, id_pj), crate::lower::node_::Sk(crate::lower::node_::Sk::SkPort{prism_rtl::cat(rs_pa, "_v")}));
            this_.lets = crate::prelude::push(this_.lets, crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{pf_pe})), pt_pf}), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Port::new"), Array<crate::lower::model::Ex>{}})})})}));
            this_.fields = crate::prelude::push(this_.fields, std::tuple{pf_pe, pt_pf, prism_rtl::cat("`", nkey_p6, "` as a value: the port it fires")});
            this_.moves = crate::prelude::push(this_.moves, std::tuple{pf_pe, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{pf_pe}))})});
            (std::move(this_));
        });
        auto be_ph = crate::lower::types::bind(crate::lower::types::bind(benv_p1, nkey_p6, b_pd), prism_rtl::cat(nkey_p6, "#port"), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{pf_pe}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), pt_pf}));
        auto me_pi = crate::lower::types::bind(crate::lower::types::bind(menv_p2, nkey_p6, b_pd), prism_rtl::cat(nkey_p6, "#port"), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), pf_pe}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), pt_pf}));
        std::tuple{wx3_pg, be_ph, me_pi};
    })
        : ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>> _v;
        auto&& _m = std::tuple{layer_p8, how_p4};
        if (prism_rtl::is<crate::lower::types::Layer::LyDyn>(std::get<0>(_m)) && prism_rtl::is<HowBound::AsLet>(std::get<1>(_m))) {
            _v.set(({
                auto b_pl = crate::lower::types::Bn(crate::lower::types::Bn::BnDyn{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), rs_pa, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), Array(std::vector{crate::lower::node_::Read(crate::lower::node_::Read::OwnRead{rs_pa})}), t_p9});
                std::tuple{wx1_pb, crate::lower::types::bind(benv_p1, nkey_p6, b_pl), crate::lower::types::bind(menv_p2, nkey_p6, b_pl)};
            }));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::types::Layer::LyDyn>(std::get<0>(_m)) && prism_rtl::is<HowBound::AsResult>(std::get<1>(_m))) {
            _v.set(({
                auto b_pm = crate::lower::types::Bn(crate::lower::types::Bn::BnDyn{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), rs_pa, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), Array(std::vector{crate::lower::node_::Read(crate::lower::node_::Read::OwnRead{rs_pa})}), t_p9});
                std::tuple{wx1_pb, crate::lower::types::bind(benv_p1, nkey_p6, b_pm), crate::lower::types::bind(menv_p2, nkey_p6, b_pm)};
            }));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::types::Layer::LyDyn>(std::get<0>(_m))) {
            _v.set(({
                auto b_pn = crate::lower::types::Bn(crate::lower::types::Bn::BnHold{rs_pa, t_p9});
                std::tuple{wx1_pb, crate::lower::types::bind(benv_p1, nkey_p6, b_pn), crate::lower::types::bind(menv_p2, nkey_p6, b_pn)};
            }));
            goto _done;
        }
        {
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>> _v;
                auto&& _m = many_instances(wx_p0.lx, n_p3.span);
                if (prism_rtl::is_some(_m)) {
                    auto&& insts_po = prism_rtl::some_of(_m);
                    _v.set(run_to_end(fold_job(crate::check::errors::range0(len(insts_po)), std::tuple{wx1_pb, benv_p1, menv_p2}, ({
                        auto insts_po_1 = insts_po;
                        auto wx_p0_2 = wx_p0;
                        auto n_p3_3 = n_p3;
                        auto rs_pa_4 = rs_pa;
                        auto nkey_p6_5 = nkey_p6;
                        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>>(std::tuple<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>, Nat>)>>(prism_rtl::rc([=, insts_po_1 = std::move(insts_po_1), wx_p0_2 = std::move(wx_p0_2), n_p3_3 = std::move(n_p3_3), rs_pa_4 = std::move(rs_pa_4), nkey_p6_5 = std::move(nkey_p6_5)](std::tuple<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>, Nat> _p0) {
                        auto&& p0 = std::get<0>(_p0);
                        auto&& p1 = std::get<1>(_p0);
                        return ({
                            auto insts_po_1_6 = insts_po_1;
                            auto wx_p0_2_6 = wx_p0_2;
                            auto n_p3_3_6 = n_p3_3;
                            auto rs_pa_4_6 = rs_pa_4;
                            auto nkey_p6_5_6 = nkey_p6_5;
                            entered(once_job([=, insts_po_1_6 = std::move(insts_po_1_6), wx_p0_2_6 = std::move(wx_p0_2_6), n_p3_3_6 = std::move(n_p3_3_6), rs_pa_4_6 = std::move(rs_pa_4_6), nkey_p6_5_6 = std::move(nkey_p6_5_6)]() {
                            return ({
                                auto [w_pp, be_pq, me_pr] = p0;
                                auto k_ps = p1;
                                ({
                                auto inst_pt = or_(index(insts_po_1_6, k_ps), std::tuple{Array<std::tuple<Text, crate::check::types::Ty>>{}, Array<std::tuple<Text, crate::check::types::Col>>{}});
                                auto lxk_pu = crate::lower::expr::at_instance(wx_p0_2_6.lx, inst_pt);
                                call_then(crate::lower::types::start_out_ty_of(lxk_pu, crate::lower::types::peel(crate::lower::binder_ty(lxk_pu, n_p3_3_6.span))), [=, inst_pt = std::move(inst_pt)](crate::lower::model::OutTy out_ty_of_14418) {
                                return ({
                                    auto tk_pv = out_ty_of_14418;
                                    auto [rk_p12, w2_p13] = k_ps == Nat(0u)
                                        ? std::tuple{rs_pa_4_6, w_pp}
                                        : crate::lower::node_::fresh_name(w_pp, prism_rtl::cat(rs_pa_4_6, "_", k_ps));
                                    auto bkey_p10 = k_ps == Nat(0u) ? nkey_p6_5_6 : prism_rtl::cat(nkey_p6_5_6, "#inst", k_ps);
                                    auto [be2_p14, me2_p15] = crate::lower::node_::bind_plain(be_pq, me_pr, bkey_p10, rk_p12, tk_pv);
                                    auto ukey_p11 = prism_rtl::cat(nkey_p6_5_6, "#", show_text(inst_pt));
                                    (prism_rtl::finished(std::tuple{w2_p13, with_use(be2_p14, ukey_p11, bkey_p10), with_use(me2_p15, ukey_p11, bkey_p10)}));
                                });
                            });
                            });
                            });
                        }));
                        });
                    }));
                    }))));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(({
                        auto [be_p16, me_p17] = crate::lower::node_::bind_plain(benv_p1, menv_p2, nkey_p6, rs_pa, t_p9);
                        std::tuple{wx1_pb, be_p16, me_p17};
                    }));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>> PreBindName::cycle() const {
    const auto& wx_p0 = this->wx_p0;
    const auto& benv_p1 = this->benv_p1;
    const auto& menv_p2 = this->menv_p2;
    const auto& n_p3 = this->n_p3;
    const auto& how_p4 = this->how_p4;
    auto benv_p1_1 = benv_p1;
    auto how_p4_2 = how_p4;
    auto menv_p2_3 = menv_p2;
    auto n_p3_4 = n_p3;
    auto wx_p0_5 = wx_p0;
    return call_then(crate::lower::expr::start_widget_let_lx(prism_rtl::deref(wx_p0_5).lx, prism_rtl::deref(n_p3_4).span), [=](crate::lower::Lx widget_let_lx_12007) {
        return ({
            auto lx_p5 = widget_let_lx_12007;
            auto nkey_p6 = crate::check::env::sname_key(n_p3_4);
            auto full_p7 = crate::lower::binder_ty(lx_p5, prism_rtl::deref(n_p3_4).span);
            auto layer_p8 = crate::lower::types::layer_of(full_p7);
            call_then(crate::lower::types::start_out_ty_of(lx_p5, crate::lower::types::peel(full_p7)), [=, nkey_p6 = std::move(nkey_p6), layer_p8 = std::move(layer_p8)](crate::lower::model::OutTy out_ty_of_12135) {
            return ({
                auto t_p9 = out_ty_of_12135;
                auto [rs_pa, wx1_pb] = crate::lower::node_::fresh_name(wx_p0_5, crate::lower::snake(nkey_p6));
                ((how_p4_2 == HowBound(HowBound::AsBind{})) || (how_p4_2 == HowBound(HowBound::AsResult{}))) && crate::lower::types::is_bundle(full_p7)
                ? prism_rtl::finished(std::tuple{wx_p0_5, benv_p1_1, menv_p2_3})
                : (layer_p8 == crate::lower::types::Layer(crate::lower::types::Layer::LyEv{})) || is_switched(full_p7)
                ? call_then(crate::lower::types::start_out_ty_of(lx_p5, crate::lower::types::peel(crate::lower::types::peel(full_p7))), [=](crate::lower::model::OutTy out_ty_of_12493) {
                return ({
                    auto et_pc = out_ty_of_12493;
                    auto [id_pj, wx2_pk] = crate::lower::node_::add_gn(wx1_pb, rs_pa, et_pc, crate::lower::node_::GnKind(crate::lower::node_::GnKind::GnNamed{}), Nat(0u));
                    auto b_pd = crate::lower::types::Bn(crate::lower::types::Bn::BnEv{crate::lower::node_::ev_ref_of(wx2_pk, id_pj), t_p9});
                    auto pf_pe = prism_rtl::cat(rs_pa, "_v_port");
                    auto pt_pf = crate::lower::model::OutTy(crate::lower::model::OutTy::OutRc{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutPort{prism_rtl::rc(et_pc)}))});
                    auto wx3_pg = ({
                        crate::lower::node_::Wx this_ = crate::lower::node_::connect(wx2_pk, crate::lower::node_::ev_ref_of(wx2_pk, id_pj), crate::lower::node_::Sk(crate::lower::node_::Sk::SkPort{prism_rtl::cat(rs_pa, "_v")}));
                        this_.lets = crate::prelude::push(this_.lets, crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{pf_pe})), pt_pf}), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Port::new"), Array<crate::lower::model::Ex>{}})})})}));
                        this_.fields = crate::prelude::push(this_.fields, std::tuple{pf_pe, pt_pf, prism_rtl::cat("`", nkey_p6, "` as a value: the port it fires")});
                        this_.moves = crate::prelude::push(this_.moves, std::tuple{pf_pe, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{pf_pe}))})});
                        (std::move(this_));
                    });
                    auto be_ph = crate::lower::types::bind(crate::lower::types::bind(benv_p1_1, nkey_p6, b_pd), prism_rtl::cat(nkey_p6, "#port"), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{pf_pe}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), pt_pf}));
                    auto me_pi = crate::lower::types::bind(crate::lower::types::bind(menv_p2_3, nkey_p6, b_pd), prism_rtl::cat(nkey_p6, "#port"), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), pf_pe}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), pt_pf}));
                    (prism_rtl::finished(std::tuple{wx3_pg, be_ph, me_pi}));
                });
            })
                : ({
                auto&& _m = std::tuple{layer_p8, how_p4_2};
                prism_rtl::is<crate::lower::types::Layer::LyDyn>(std::get<0>(_m)) && prism_rtl::is<HowBound::AsLet>(std::get<1>(_m)) ? ({
                auto b_pl = crate::lower::types::Bn(crate::lower::types::Bn::BnDyn{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), rs_pa, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), Array(std::vector{crate::lower::node_::Read(crate::lower::node_::Read::OwnRead{rs_pa})}), t_p9});
                (prism_rtl::finished(std::tuple{wx1_pb, crate::lower::types::bind(benv_p1_1, nkey_p6, b_pl), crate::lower::types::bind(menv_p2_3, nkey_p6, b_pl)}));
            })
                : prism_rtl::is<crate::lower::types::Layer::LyDyn>(std::get<0>(_m)) && prism_rtl::is<HowBound::AsResult>(std::get<1>(_m)) ? ({
                auto b_pm = crate::lower::types::Bn(crate::lower::types::Bn::BnDyn{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), rs_pa, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), Array(std::vector{crate::lower::node_::Read(crate::lower::node_::Read::OwnRead{rs_pa})}), t_p9});
                (prism_rtl::finished(std::tuple{wx1_pb, crate::lower::types::bind(benv_p1_1, nkey_p6, b_pm), crate::lower::types::bind(menv_p2_3, nkey_p6, b_pm)}));
            })
                : prism_rtl::is<crate::lower::types::Layer::LyDyn>(std::get<0>(_m)) ? ({
                auto b_pn = crate::lower::types::Bn(crate::lower::types::Bn::BnHold{rs_pa, t_p9});
                (prism_rtl::finished(std::tuple{wx1_pb, crate::lower::types::bind(benv_p1_1, nkey_p6, b_pn), crate::lower::types::bind(menv_p2_3, nkey_p6, b_pn)}));
            })
                : call_then(start_many_instances(prism_rtl::deref(wx_p0_5).lx, prism_rtl::deref(n_p3_4).span), [=](std::optional<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>> many_instances_13950) {
                return ({
                    prism_rtl::is_some(many_instances_13950) ? ({
                    auto&& insts_po = prism_rtl::some_of(many_instances_13950);
                    fold_job(crate::check::errors::range0(len(insts_po)), std::tuple{wx1_pb, benv_p1_1, menv_p2_3}, ({
                    auto insts_po_6 = insts_po;
                    auto wx_p0_5_7 = wx_p0_5;
                    auto n_p3_4_7 = n_p3_4;
                    auto rs_pa_7 = rs_pa;
                    auto nkey_p6_8 = nkey_p6;
                    static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>>(std::tuple<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>, Nat>)>>(prism_rtl::rc([=, insts_po_6 = std::move(insts_po_6), wx_p0_5_7 = std::move(wx_p0_5_7), n_p3_4_7 = std::move(n_p3_4_7), rs_pa_7 = std::move(rs_pa_7), nkey_p6_8 = std::move(nkey_p6_8)](std::tuple<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>, Nat> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto insts_po_6_9 = insts_po_6;
                        auto wx_p0_5_7_9 = wx_p0_5_7;
                        auto n_p3_4_7_9 = n_p3_4_7;
                        auto rs_pa_7_9 = rs_pa_7;
                        auto nkey_p6_8_9 = nkey_p6_8;
                        entered(once_job([=, insts_po_6_9 = std::move(insts_po_6_9), wx_p0_5_7_9 = std::move(wx_p0_5_7_9), n_p3_4_7_9 = std::move(n_p3_4_7_9), rs_pa_7_9 = std::move(rs_pa_7_9), nkey_p6_8_9 = std::move(nkey_p6_8_9)]() {
                        return ({
                            auto [w_pp, be_pq, me_pr] = p0;
                            auto k_ps = p1;
                            ({
                            auto inst_pt = or_(index(insts_po_6_9, k_ps), std::tuple{Array<std::tuple<Text, crate::check::types::Ty>>{}, Array<std::tuple<Text, crate::check::types::Col>>{}});
                            auto lxk_pu = crate::lower::expr::at_instance(prism_rtl::deref(wx_p0_5_7_9).lx, inst_pt);
                            call_then(crate::lower::types::start_out_ty_of(lxk_pu, crate::lower::types::peel(crate::lower::binder_ty(lxk_pu, prism_rtl::deref(n_p3_4_7_9).span))), [=, inst_pt = std::move(inst_pt)](crate::lower::model::OutTy out_ty_of_14418) {
                            return ({
                                auto tk_pv = out_ty_of_14418;
                                auto [rk_p12, w2_p13] = k_ps == Nat(0u)
                                    ? std::tuple{rs_pa_7_9, w_pp}
                                    : crate::lower::node_::fresh_name(w_pp, prism_rtl::cat(rs_pa_7_9, "_", k_ps));
                                auto bkey_p10 = k_ps == Nat(0u) ? nkey_p6_8_9 : prism_rtl::cat(nkey_p6_8_9, "#inst", k_ps);
                                auto [be2_p14, me2_p15] = crate::lower::node_::bind_plain(be_pq, me_pr, bkey_p10, rk_p12, tk_pv);
                                auto ukey_p11 = prism_rtl::cat(nkey_p6_8_9, "#", show_text(inst_pt));
                                (prism_rtl::finished(std::tuple{w2_p13, with_use(be2_p14, ukey_p11, bkey_p10), with_use(me2_p15, ukey_p11, bkey_p10)}));
                            });
                        });
                        });
                        });
                    }));
                    });
                }));
                }))->cycle();
                })
                    : prism_rtl::is_none(many_instances_13950) ? ({
                    auto [be_p16, me_p17] = crate::lower::node_::bind_plain(benv_p1_1, menv_p2_3, nkey_p6, rs_pa, t_p9);
                    (prism_rtl::finished(std::tuple{wx1_pb, be_p16, me_p17}));
                })
                    : throw prism_rtl::Panic("no arm matched");
                });
            });
            });
            });
        });
        });
    });
}


/// `Start PreBindName, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>> start_pre_bind_name(crate::lower::node_::Wx wx_p0, crate::lower::types::Env benv_p1, crate::lower::types::Env menv_p2, crate::syntax::SName n_p3, HowBound how_p4) {
    return prism_rtl::make_rc<PreBindName>(wx_p0, benv_p1, menv_p2, n_p3, how_p4);
}


/// WithUse: fn Env, Text, Text -> Env
crate::lower::types::Env with_use(const crate::lower::types::Env& env_p0, const Text& ukey_p1, const Text& bkey_p2) {
    crate::lower::types::Env this_ = env_p0;
    this_.uses = insert(this_.uses, ukey_p1, bkey_p2);
    return this_;
}


/// ?ManyInstances: unbounded fn Lx, Range -> ?[(([((Text, Ty))], [((Text, Col))]))]
std::optional<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>> many_instances(const crate::lower::Lx& lx_p0, const crate::syntax::Range& span_p1) {
    auto&& _m = crate::prelude::get(lx_p0.gens, crate::lower::place_key(lx_p0, span_p1));
    if (prism_rtl::is_some(_m)) {
        auto&& gn_p2 = prism_rtl::some_of(_m);
        auto insts_p3 = crate::lower::expr::instantiations(lx_p0, gn_p2);
        return len(insts_p3) > Nat(1u)
            ? std::optional(insts_p3)
            : std::optional<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>>{};
    }
    if (prism_rtl::is_none(_m)) {
        return std::optional<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>>{};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::optional<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>>> ManyInstances::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& span_p1 = this->span_p1;
    return ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(lx_p0).gens, crate::lower::place_key(lx_p0, span_p1));
        prism_rtl::is_some(_m) ? ({
        auto&& gn_p2 = prism_rtl::some_of(_m);
        ({
        auto lx_p0_1 = lx_p0;
        call_then(crate::lower::expr::start_instantiations(lx_p0_1, gn_p2), [=](Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>> instantiations_15295) {
        return ({
            auto insts_p3 = instantiations_15295;
            len(insts_p3) > Nat(1u)
            ? prism_rtl::finished(std::optional(insts_p3))
            : prism_rtl::finished(std::optional<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>>{});
        });
    });
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(std::optional<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>>{})
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ManyInstances, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>>> start_many_instances(crate::lower::Lx lx_p0, crate::syntax::Range span_p1) {
    return prism_rtl::make_rc<ManyInstances>(lx_p0, span_p1);
}


/// IsSwitched: fn Ty -> Bool
bool is_switched(const crate::check::types::Ty& t_p0) {
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t_p0)) {
        auto&& m15612_0_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t_p0).a0;
        auto&& m15612_0_1 = prism_rtl::as<crate::check::types::Ty::TySig>(t_p0).a1;
        if (m15612_0_0 == Text::lit("$")) {
            if (prism_rtl::is<crate::check::types::Ty::TySig>(prism_rtl::deref(prism_rtl::deref(m15612_0_1)))) {
                auto&& m15612_0_1_r_0 = prism_rtl::as<crate::check::types::Ty::TySig>(prism_rtl::deref(prism_rtl::deref(m15612_0_1))).a0;
                if (m15612_0_1_r_0 == Text::lit("!")) {
                    return true;
                }
            }
        }
    }
    {
        return false;
    }
}


/// ?BindingOf: fn Env, Pattern -> ?Bn
std::optional<crate::lower::types::Bn> binding_of(const crate::lower::types::Env& env_p0, const crate::syntax::Pattern_& p_p1) {
    auto&& _m = prism_rtl::deref(p_p1.kind);
    if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
        auto&& n_p2 = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        return crate::prelude::get(env_p0.names, crate::check::env::sname_key(n_p2));
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PTuple>(_m)) {
        auto&& ps_p3 = prism_rtl::as<crate::syntax::PatternKind::PTuple>(_m).a0;
        return std::optional(crate::lower::types::Bn(crate::lower::types::Bn::BnParts{each(ps_p3, [&](const crate::syntax::Pattern_& q_p4) { return binding_of_name(env_p0, q_p4); })}));
    }
    {
        return std::optional<crate::lower::types::Bn>{};
    }
}


/// ?BindingOfName: fn Env, Pattern -> ?Bn
std::optional<crate::lower::types::Bn> binding_of_name(const crate::lower::types::Env& env_p0, const crate::syntax::Pattern_& p_p1) {
    auto&& _m = prism_rtl::deref(p_p1.kind);
    if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
        auto&& n_p2 = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        return crate::prelude::get(env_p0.names, crate::check::env::sname_key(n_p2));
    }
    {
        return std::optional<crate::lower::types::Bn>{};
    }
}


/// WidgetStmt: unbounded fn Wx, Env, Env, Stmt, Bool -> ((Wx, Env, Env))
std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env> widget_stmt(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& benv_p1, const crate::lower::types::Env& menv_p2, const crate::syntax::Stmt& s_p3, const bool& last_p4) {
    auto lx_p5 = wx_p0.lx;
    auto&& _m = s_p3.kind;
    if (prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) && prism_rtl::is_none(prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2)) {
        auto&& p_p6 = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a0;
        auto&& e_p7 = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a1;
        auto [wx2_p9, res_pa] = build_line(wx_p0, benv_p1, menv_p2, e_p7, binding_of(menv_p2, p_p6));
        auto wx3_p8 = bind_res(wx2_p9, menv_p2, p_p6, res_pa);
        auto&& _m = std::tuple{res_pa, prism_rtl::deref(prism_rtl::deref(p_p6).kind)};
        if (prism_rtl::is<crate::lower::node_::Wres::WrDyn>(std::get<0>(_m)) && prism_rtl::is<crate::syntax::PatternKind::PName>(std::get<1>(_m))) {
            auto&& ex_pb = prism_rtl::as<crate::lower::node_::Wres::WrDyn>(std::get<0>(_m)).a0;
            auto&& rds_pc = prism_rtl::as<crate::lower::node_::Wres::WrDyn>(std::get<0>(_m)).a1;
            auto&& t_pd = prism_rtl::as<crate::lower::node_::Wres::WrDyn>(std::get<0>(_m)).a2;
            auto&& n_pe = prism_rtl::as<crate::syntax::PatternKind::PName>(std::get<1>(_m)).a0;
            auto b_pf = crate::lower::types::Bn(crate::lower::types::Bn::BnDyn{ex_pb, rds_pc, t_pd});
            return result_getter(wx3_p8, menv_p2, n_pe, ex_pb, rds_pc, t_pd, crate::lower::types::bind(benv_p1, crate::check::env::sname_key(n_pe), b_pf), crate::lower::types::bind(menv_p2, crate::check::env::sname_key(n_pe), b_pf));
        }
        if (prism_rtl::is<crate::lower::node_::Wres::WrHosted>(std::get<0>(_m)) && prism_rtl::is<crate::syntax::PatternKind::PTuple>(std::get<1>(_m))) {
            auto&& inner_pg = prism_rtl::as<crate::lower::node_::Wres::WrHosted>(std::get<0>(_m)).a0;
            auto&& doc_ph = prism_rtl::as<crate::lower::node_::Wres::WrHosted>(std::get<0>(_m)).a1;
            auto&& ps_pi = prism_rtl::as<crate::syntax::PatternKind::PTuple>(std::get<1>(_m)).a0;
            return bind_hosted(wx3_p8, benv_p1, menv_p2, prism_rtl::deref(inner_pg), doc_ph, ps_pi);
        }
        if (prism_rtl::is<crate::lower::node_::Wres::WrParts>(std::get<0>(_m)) && prism_rtl::is<crate::syntax::PatternKind::PTuple>(std::get<1>(_m))) {
            auto&& parts_pj = prism_rtl::as<crate::lower::node_::Wres::WrParts>(std::get<0>(_m)).a0;
            auto&& ps_pk = prism_rtl::as<crate::syntax::PatternKind::PTuple>(std::get<1>(_m)).a0;
            return bind_parts(wx2_p9, benv_p1, menv_p2, parts_pj, ps_pk);
        }
        if (prism_rtl::is<crate::lower::node_::Wres::WrParts>(std::get<0>(_m)) && prism_rtl::is<crate::syntax::PatternKind::PName>(std::get<1>(_m))) {
            auto&& parts_pl = prism_rtl::as<crate::lower::node_::Wres::WrParts>(std::get<0>(_m)).a0;
            auto&& n_pm = prism_rtl::as<crate::syntax::PatternKind::PName>(std::get<1>(_m)).a0;
            auto b_pn = bundle_bn(res_pa);
            return std::tuple{wx3_p8, crate::lower::types::bind(benv_p1, crate::check::env::sname_key(n_pm), b_pn), crate::lower::types::bind(menv_p2, crate::check::env::sname_key(n_pm), b_pn)};
        }
        if (prism_rtl::is<crate::lower::node_::Wres::WrPlain>(std::get<0>(_m))) {
            auto&& ex_po = prism_rtl::as<crate::lower::node_::Wres::WrPlain>(std::get<0>(_m)).a0;
            auto&& t_pp = prism_rtl::as<crate::lower::node_::Wres::WrPlain>(std::get<0>(_m)).a1;
            return std::tuple{bind_plain_result(wx3_p8, menv_p2, p_p6, ex_po, t_pp), benv_p1, menv_p2};
        }
        {
            return std::tuple{wx3_p8, benv_p1, menv_p2};
        }
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) && prism_rtl::is_some(prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2)) {
        auto&& p_pq = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a0;
        auto&& init_pr = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a1;
        auto&& step_ps = prism_rtl::some_of(prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2);
        auto [wx2_pt, be2_pu] = hold_line(wx_p0, benv_p1, menv_p2, p_pq, init_pr, step_ps);
        return std::tuple{wx2_pt, be2_pu, menv_p2};
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SIgnore>(_m)) {
        auto&& e_pv = prism_rtl::as<crate::syntax::StmtKind::SIgnore>(_m).a0;
        auto&& _wx2_p10 = build_line(wx_p0, benv_p1, menv_p2, e_pv, std::optional<crate::lower::types::Bn>{});
        auto&& wx2_p10 = std::get<0>(_wx2_p10);
        return std::tuple{wx2_p10, benv_p1, menv_p2};
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SLet>(_m)) {
        auto&& p_p11 = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
        auto&& e_p12 = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
        auto [wx2_p13, be2_p14] = let_line(wx_p0, benv_p1, menv_p2, p_p11, e_p12);
        return std::tuple{wx2_p13, be2_p14, menv_p2};
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m)) {
        auto&& e_p15 = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
        auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p15).kind);
        if (prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m)) {
            auto&& m17518_0_0 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
            auto&& x_p16 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
            if (m17518_0_0 == Text::lit("@")) {
                auto [res_p18, wx2_p19] = result_of(wx_p0, benv_p1, menv_p2, prism_rtl::deref(prism_rtl::deref(x_p16)));
                auto wx3_p17 = ({
                    crate::lower::node_::Wx this_ = wx2_p19;
                    this_.result = res_p18;
                    (std::move(this_));
                });
                return std::tuple{wx3_p17, benv_p1, menv_p2};
            }
        }
        {
            auto [wx2_p1b, res_p1c] = build_line(wx_p0, benv_p1, menv_p2, e_p15, std::optional<crate::lower::types::Bn>{});
            auto wx3_p1a = last_p4 ? set_result(wx2_p1b, res_p1c) : wx2_p1b;
            return std::tuple{wx3_p1a, benv_p1, menv_p2};
        }
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SEmit>(_m)) {
        return std::tuple{wx_p0, benv_p1, menv_p2};
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SSignature>(_m)) {
        return std::tuple{wx_p0, benv_p1, menv_p2};
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SFn>(_m)) {
        auto&& c_p1d = prism_rtl::as<crate::syntax::StmtKind::SFn>(_m).a0;
        return std::tuple{wx_p0, benv_p1, menv_p2};
    }
    {
        auto wx2_p1e = ({
            crate::lower::node_::Wx this_ = wx_p0;
            this_.build = crate::prelude::push(this_.build, crate::lower::expr::refusal_do(Text::lit("a statement this back end does not lower yet")));
            (std::move(this_));
        });
        return std::tuple{wx2_p1e, benv_p1, menv_p2};
    }
}


prism_rtl::Turn<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>> WidgetStmt::cycle() const {
    const auto& wx_p0 = this->wx_p0;
    const auto& benv_p1 = this->benv_p1;
    const auto& menv_p2 = this->menv_p2;
    const auto& s_p3 = this->s_p3;
    const auto& last_p4 = this->last_p4;
    auto lx_p5 = prism_rtl::deref(wx_p0).lx;
    return ({
        auto&& _m = prism_rtl::deref(s_p3).kind;
        prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) && prism_rtl::is_none(prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2) ? ({
        auto&& p_p6 = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a0;
        auto&& e_p7 = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a1;
        ({
        auto benv_p1_1 = benv_p1;
        auto e_p7_2 = e_p7;
        auto menv_p2_3 = menv_p2;
        auto p_p6_4 = p_p6;
        auto wx_p0_5 = wx_p0;
        call_then(start_build_line(wx_p0_5, benv_p1_1, menv_p2_3, e_p7_2, binding_of(menv_p2_3, p_p6_4)), [=](std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> build_line_16283) {
        return ({
            auto [wx2_p9, res_pa] = build_line_16283;
            auto wx3_p8 = bind_res(wx2_p9, menv_p2_3, p_p6_4, res_pa);
            ({
            auto&& _m = std::tuple{res_pa, prism_rtl::deref(prism_rtl::deref(p_p6_4).kind)};
            prism_rtl::is<crate::lower::node_::Wres::WrDyn>(std::get<0>(_m)) && prism_rtl::is<crate::syntax::PatternKind::PName>(std::get<1>(_m)) ? ({
            auto&& ex_pb = prism_rtl::as<crate::lower::node_::Wres::WrDyn>(std::get<0>(_m)).a0;
            auto&& rds_pc = prism_rtl::as<crate::lower::node_::Wres::WrDyn>(std::get<0>(_m)).a1;
            auto&& t_pd = prism_rtl::as<crate::lower::node_::Wres::WrDyn>(std::get<0>(_m)).a2;
            auto&& n_pe = prism_rtl::as<crate::syntax::PatternKind::PName>(std::get<1>(_m)).a0;
            ({
            auto b_pf = crate::lower::types::Bn(crate::lower::types::Bn::BnDyn{ex_pb, rds_pc, t_pd});
            (prism_rtl::finished(result_getter(wx3_p8, menv_p2_3, n_pe, ex_pb, rds_pc, t_pd, crate::lower::types::bind(benv_p1_1, crate::check::env::sname_key(n_pe), b_pf), crate::lower::types::bind(menv_p2_3, crate::check::env::sname_key(n_pe), b_pf))));
        });
        })
            : prism_rtl::is<crate::lower::node_::Wres::WrHosted>(std::get<0>(_m)) && prism_rtl::is<crate::syntax::PatternKind::PTuple>(std::get<1>(_m)) ? ({
            auto&& inner_pg = prism_rtl::as<crate::lower::node_::Wres::WrHosted>(std::get<0>(_m)).a0;
            auto&& doc_ph = prism_rtl::as<crate::lower::node_::Wres::WrHosted>(std::get<0>(_m)).a1;
            auto&& ps_pi = prism_rtl::as<crate::syntax::PatternKind::PTuple>(std::get<1>(_m)).a0;
            prism_rtl::finished(bind_hosted(wx3_p8, benv_p1_1, menv_p2_3, prism_rtl::deref(inner_pg), doc_ph, ps_pi));
        })
            : prism_rtl::is<crate::lower::node_::Wres::WrParts>(std::get<0>(_m)) && prism_rtl::is<crate::syntax::PatternKind::PTuple>(std::get<1>(_m)) ? ({
            auto&& parts_pj = prism_rtl::as<crate::lower::node_::Wres::WrParts>(std::get<0>(_m)).a0;
            auto&& ps_pk = prism_rtl::as<crate::syntax::PatternKind::PTuple>(std::get<1>(_m)).a0;
            prism_rtl::more(prism_rtl::rc(BindParts(wx2_p9, benv_p1_1, menv_p2_3, parts_pj, ps_pk)));
        })
            : prism_rtl::is<crate::lower::node_::Wres::WrParts>(std::get<0>(_m)) && prism_rtl::is<crate::syntax::PatternKind::PName>(std::get<1>(_m)) ? ({
            auto&& parts_pl = prism_rtl::as<crate::lower::node_::Wres::WrParts>(std::get<0>(_m)).a0;
            auto&& n_pm = prism_rtl::as<crate::syntax::PatternKind::PName>(std::get<1>(_m)).a0;
            ({
            auto b_pn = bundle_bn(res_pa);
            (prism_rtl::finished(std::tuple{wx3_p8, crate::lower::types::bind(benv_p1_1, crate::check::env::sname_key(n_pm), b_pn), crate::lower::types::bind(menv_p2_3, crate::check::env::sname_key(n_pm), b_pn)}));
        });
        })
            : prism_rtl::is<crate::lower::node_::Wres::WrPlain>(std::get<0>(_m)) ? ({
            auto&& ex_po = prism_rtl::as<crate::lower::node_::Wres::WrPlain>(std::get<0>(_m)).a0;
            auto&& t_pp = prism_rtl::as<crate::lower::node_::Wres::WrPlain>(std::get<0>(_m)).a1;
            call_then(start_bind_plain_result(wx3_p8, menv_p2_3, p_p6_4, ex_po, t_pp), [=](crate::lower::node_::Wx bind_plain_result_17033) { return prism_rtl::finished(std::tuple{bind_plain_result_17033, benv_p1_1, menv_p2_3}); });
        })
            : prism_rtl::finished(std::tuple{wx3_p8, benv_p1_1, menv_p2_3});
        });
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) && prism_rtl::is_some(prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2) ? ({
        auto&& p_pq = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a0;
        auto&& init_pr = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a1;
        auto&& step_ps = prism_rtl::some_of(prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2);
        ({
        auto benv_p1_1 = benv_p1;
        auto init_pr_2 = init_pr;
        auto menv_p2_3 = menv_p2;
        auto p_pq_4 = p_pq;
        auto step_ps_5 = step_ps;
        auto wx_p0_6 = wx_p0;
        call_then(start_hold_line(wx_p0_6, benv_p1_1, menv_p2_3, p_pq_4, init_pr_2, step_ps_5), [=](std::tuple<crate::lower::node_::Wx, crate::lower::types::Env> hold_line_17195) {
        return ({
            auto [wx2_pt, be2_pu] = hold_line_17195;
            (prism_rtl::finished(std::tuple{wx2_pt, be2_pu, menv_p2_3}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SIgnore>(_m) ? ({
        auto&& e_pv = prism_rtl::as<crate::syntax::StmtKind::SIgnore>(_m).a0;
        ({
        auto benv_p1_1 = benv_p1;
        auto e_pv_2 = e_pv;
        auto menv_p2_3 = menv_p2;
        auto wx_p0_4 = wx_p0;
        call_then(start_build_line(wx_p0_4, benv_p1_1, menv_p2_3, e_pv_2, std::optional<crate::lower::types::Bn>{}), [=](std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> build_line_17318) {
        return ({
            auto&& _wx2_p10 = build_line_17318;
            auto&& wx2_p10 = std::get<0>(_wx2_p10);
            (prism_rtl::finished(std::tuple{wx2_p10, benv_p1_1, menv_p2_3}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SLet>(_m) ? ({
        auto&& p_p11 = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
        auto&& e_p12 = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
        ({
        auto benv_p1_1 = benv_p1;
        auto e_p12_2 = e_p12;
        auto menv_p2_3 = menv_p2;
        auto p_p11_4 = p_p11;
        auto wx_p0_5 = wx_p0;
        call_then(start_let_line(wx_p0_5, benv_p1_1, menv_p2_3, p_p11_4, e_p12_2), [=](std::tuple<crate::lower::node_::Wx, crate::lower::types::Env> let_line_17441) {
        return ({
            auto [wx2_p13, be2_p14] = let_line_17441;
            (prism_rtl::finished(std::tuple{wx2_p13, be2_p14, menv_p2_3}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m) ? ({
        auto&& e_p15 = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
        ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p15).kind);
        prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m) && ({
        auto&& m17518_0_0 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
        auto&& x_p16 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
        (m17518_0_0 == Text::lit("@"));
    }) ? ({
        auto&& m17518_0_0 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
        auto&& x_p16 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
        ({
        auto benv_p1_1 = benv_p1;
        auto menv_p2_2 = menv_p2;
        auto wx_p0_3 = wx_p0;
        auto x_p16_4 = prism_rtl::deref(prism_rtl::deref(x_p16));
        call_then(start_result_of(wx_p0_3, benv_p1_1, menv_p2_2, x_p16_4), [=](std::tuple<crate::lower::node_::Wres, crate::lower::node_::Wx> result_of_17598) {
        return ({
            auto [res_p18, wx2_p19] = result_of_17598;
            auto wx3_p17 = ({
                crate::lower::node_::Wx this_ = wx2_p19;
                this_.result = res_p18;
                (std::move(this_));
            });
            (prism_rtl::finished(std::tuple{wx3_p17, benv_p1_1, menv_p2_2}));
        });
    });
    });
    })
        : ({
        auto benv_p1_1 = benv_p1;
        auto e_p15_2 = e_p15;
        auto last_p4_3 = prism_rtl::deref(last_p4);
        auto menv_p2_4 = menv_p2;
        auto wx_p0_5 = wx_p0;
        call_then(start_build_line(wx_p0_5, benv_p1_1, menv_p2_4, e_p15_2, std::optional<crate::lower::types::Bn>{}), [=, last_p4_3 = std::move(last_p4_3)](std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> build_line_17794) {
        return ({
            auto [wx2_p1b, res_p1c] = build_line_17794;
            auto wx3_p1a = last_p4_3 ? set_result(wx2_p1b, res_p1c) : wx2_p1b;
            (prism_rtl::finished(std::tuple{wx3_p1a, benv_p1_1, menv_p2_4}));
        });
    });
    });
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SEmit>(_m) ? prism_rtl::finished(std::tuple{wx_p0, benv_p1, menv_p2})
        : prism_rtl::is<crate::syntax::StmtKind::SSignature>(_m) ? prism_rtl::finished(std::tuple{wx_p0, benv_p1, menv_p2})
        : prism_rtl::is<crate::syntax::StmtKind::SFn>(_m) ? ({
        auto&& c_p1d = prism_rtl::as<crate::syntax::StmtKind::SFn>(_m).a0;
        prism_rtl::finished(std::tuple{wx_p0, benv_p1, menv_p2});
    })
        : ({
        auto wx2_p1e = ({
            crate::lower::node_::Wx this_ = wx_p0;
            this_.build = crate::prelude::push(this_.build, crate::lower::expr::refusal_do(Text::lit("a statement this back end does not lower yet")));
            (std::move(this_));
        });
        (prism_rtl::finished(std::tuple{wx2_p1e, benv_p1, menv_p2}));
    });
    });
}


/// `Start WidgetStmt, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>> start_widget_stmt(crate::lower::node_::Wx wx_p0, crate::lower::types::Env benv_p1, crate::lower::types::Env menv_p2, crate::syntax::Stmt s_p3, bool last_p4) {
    return prism_rtl::make_rc<WidgetStmt>(wx_p0, benv_p1, menv_p2, s_p3, last_p4);
}


/// BindHosted: fn Wx, Env, Env, Wres, Bn, [Pattern] -> ((Wx, Env, Env))
std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env> bind_hosted(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& benv_p1, const crate::lower::types::Env& menv_p2, const crate::lower::node_::Wres& res_p3, const crate::lower::types::Bn& doc_p4, const Array<crate::syntax::Pattern_>& ps_p5) {
    auto r_o6 = ({
        __label__ _done;
        prism_rtl::Slot<std::optional<crate::lower::types::Bn>> _v;
        if (prism_rtl::is<crate::lower::node_::Wres::WrEv>(res_p3)) {
            auto&& r_p7 = prism_rtl::as<crate::lower::node_::Wres::WrEv>(res_p3).a0;
            _v.set(std::optional(crate::lower::types::Bn(crate::lower::types::Bn::BnEv{r_p7, crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})})));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::node_::Wres::WrDyn>(res_p3)) {
            auto&& ex_p8 = prism_rtl::as<crate::lower::node_::Wres::WrDyn>(res_p3).a0;
            auto&& rds_p9 = prism_rtl::as<crate::lower::node_::Wres::WrDyn>(res_p3).a1;
            auto&& t_pa = prism_rtl::as<crate::lower::node_::Wres::WrDyn>(res_p3).a2;
            _v.set(std::optional(crate::lower::types::Bn(crate::lower::types::Bn::BnDyn{ex_p8, rds_p9, t_pa})));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::node_::Wres::WrParts>(res_p3)) {
            _v.set(std::optional(bundle_bn(res_p3)));
            goto _done;
        }
        {
            _v.set(std::optional<crate::lower::types::Bn>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto [be1_pb, me1_pc] = bind_part(benv_p1, menv_p2, index(ps_p5, Nat(0u)), r_o6);
    return bind_part2(wx_p0, be1_pb, me1_pc, index(ps_p5, Nat(1u)), std::optional(doc_p4));
}


/// BindPart: fn Env, Env, ?Pattern, ?Bn -> ((Env, Env))
std::tuple<crate::lower::types::Env, crate::lower::types::Env> bind_part(const crate::lower::types::Env& benv_p0, const crate::lower::types::Env& menv_p1, const std::optional<crate::syntax::Pattern_>& p_o2, const std::optional<crate::lower::types::Bn>& b_o3) {
    auto&& _m = std::tuple{p_o2, b_o3};
    if (prism_rtl::is_some(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m))) {
        auto&& p_p4 = prism_rtl::some_of(std::get<0>(_m));
        auto&& b_p5 = prism_rtl::some_of(std::get<1>(_m));
        auto&& _m = prism_rtl::deref(prism_rtl::deref(p_p4).kind);
        if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
            auto&& n_p6 = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
            return std::tuple{crate::lower::types::bind(benv_p0, crate::check::env::sname_key(n_p6), b_p5), crate::lower::types::bind(menv_p1, crate::check::env::sname_key(n_p6), b_p5)};
        }
        {
            return std::tuple{benv_p0, menv_p1};
        }
    }
    {
        return std::tuple{benv_p0, menv_p1};
    }
}


/// BindPart2: fn Wx, Env, Env, ?Pattern, ?Bn -> ((Wx, Env, Env))
std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env> bind_part2(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& benv_p1, const crate::lower::types::Env& menv_p2, const std::optional<crate::syntax::Pattern_>& p_o3, const std::optional<crate::lower::types::Bn>& b_o4) {
    auto [be_p5, me_p6] = bind_part(benv_p1, menv_p2, p_o3, b_o4);
    return std::tuple{wx_p0, be_p5, me_p6};
}


/// BindParts: unbounded fn Wx, Env, Env, [Wres], [Pattern] -> ((Wx, Env, Env))
std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env> bind_parts(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& benv_p1, const crate::lower::types::Env& menv_p2, const Array<crate::lower::node_::Wres>& parts_p3, const Array<crate::syntax::Pattern_>& ps_p4) {
    return run_to_end(fold_job(crate::check::errors::range0(len(ps_p4)), std::tuple{wx_p0, benv_p1, menv_p2}, ({
        auto ps_p4_1 = ps_p4;
        auto parts_p3_2 = parts_p3;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>>(std::tuple<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>, Nat>)>>(prism_rtl::rc([=, ps_p4_1 = std::move(ps_p4_1), parts_p3_2 = std::move(parts_p3_2)](std::tuple<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto ps_p4_1_3 = ps_p4_1;
            auto parts_p3_2_3 = parts_p3_2;
            entered(once_job([=, ps_p4_1_3 = std::move(ps_p4_1_3), parts_p3_2_3 = std::move(parts_p3_2_3)]() {
            return ({
                auto [w_p5, be_p6, me_p7] = p0;
                auto i_p8 = p1;
                ({
                auto&& _m = std::tuple{index(ps_p4_1_3, i_p8), index(parts_p3_2_3, i_p8)};
                prism_rtl::is_some(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m)) ? ({
                auto&& p_p9 = prism_rtl::some_of(std::get<0>(_m));
                auto&& part_pa = prism_rtl::some_of(std::get<1>(_m));
                ({
                auto&& _m = std::tuple{part_pa, prism_rtl::deref(prism_rtl::deref(p_p9).kind)};
                prism_rtl::is<crate::lower::node_::Wres::WrEv>(std::get<0>(_m)) && prism_rtl::is<crate::syntax::PatternKind::PName>(std::get<1>(_m)) ? ({
                auto&& r_pb = prism_rtl::as<crate::lower::node_::Wres::WrEv>(std::get<0>(_m)).a0;
                prism_rtl::finished(std::tuple{bind_res(w_p5, me_p7, p_p9, part_pa), be_p6, me_p7});
            })
                : prism_rtl::is<crate::lower::node_::Wres::WrParts>(std::get<0>(_m)) && prism_rtl::is<crate::syntax::PatternKind::PTuple>(std::get<1>(_m)) ? ({
                auto&& inner_pc = prism_rtl::as<crate::lower::node_::Wres::WrParts>(std::get<0>(_m)).a0;
                auto&& qs_pd = prism_rtl::as<crate::syntax::PatternKind::PTuple>(std::get<1>(_m)).a0;
                prism_rtl::more(prism_rtl::rc(BindParts(w_p5, be_p6, me_p7, inner_pc, qs_pd)));
            })
                : prism_rtl::is<crate::syntax::PatternKind::PName>(std::get<1>(_m)) ? ({
                auto&& n_pe = prism_rtl::as<crate::syntax::PatternKind::PName>(std::get<1>(_m)).a0;
                ({
                prism_rtl::is<crate::lower::node_::Wres::WrUnit>(part_pa) ? prism_rtl::finished(std::tuple{w_p5, be_p6, me_p7})
                : prism_rtl::is<crate::lower::node_::Wres::WrDyn>(part_pa) ? ({
                auto&& ex_pf = prism_rtl::as<crate::lower::node_::Wres::WrDyn>(part_pa).a0;
                auto&& rds_pg = prism_rtl::as<crate::lower::node_::Wres::WrDyn>(part_pa).a1;
                auto&& t_ph = prism_rtl::as<crate::lower::node_::Wres::WrDyn>(part_pa).a2;
                ({
                auto b_pi = crate::lower::types::Bn(crate::lower::types::Bn::BnDyn{ex_pf, rds_pg, t_ph});
                (prism_rtl::finished(result_getter(w_p5, me_p7, n_pe, ex_pf, rds_pg, t_ph, crate::lower::types::bind(be_p6, crate::check::env::sname_key(n_pe), b_pi), crate::lower::types::bind(me_p7, crate::check::env::sname_key(n_pe), b_pi))));
            });
            })
                : ({
                auto b_pj = bundle_bn(part_pa);
                (prism_rtl::finished(std::tuple{w_p5, crate::lower::types::bind(be_p6, crate::check::env::sname_key(n_pe), b_pj), crate::lower::types::bind(me_p7, crate::check::env::sname_key(n_pe), b_pj)}));
            });
            });
            })
                : prism_rtl::finished(std::tuple{w_p5, be_p6, me_p7});
            });
            })
                : prism_rtl::finished(std::tuple{w_p5, be_p6, me_p7});
            });
            });
        }));
        });
    }));
    })));
}


prism_rtl::Turn<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>> BindParts::cycle() const {
    const auto& wx_p0 = this->wx_p0;
    const auto& benv_p1 = this->benv_p1;
    const auto& menv_p2 = this->menv_p2;
    const auto& parts_p3 = this->parts_p3;
    const auto& ps_p4 = this->ps_p4;
    return fold_job(crate::check::errors::range0(len(ps_p4)), std::tuple{wx_p0, benv_p1, menv_p2}, ({
        auto ps_p4_1 = ps_p4;
        auto parts_p3_2 = parts_p3;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>>(std::tuple<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>, Nat>)>>(prism_rtl::rc([=, ps_p4_1 = std::move(ps_p4_1), parts_p3_2 = std::move(parts_p3_2)](std::tuple<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto ps_p4_1_3 = ps_p4_1;
            auto parts_p3_2_3 = parts_p3_2;
            entered(once_job([=, ps_p4_1_3 = std::move(ps_p4_1_3), parts_p3_2_3 = std::move(parts_p3_2_3)]() {
            return ({
                auto [w_p5, be_p6, me_p7] = p0;
                auto i_p8 = p1;
                ({
                auto&& _m = std::tuple{index(ps_p4_1_3, i_p8), index(parts_p3_2_3, i_p8)};
                prism_rtl::is_some(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m)) ? ({
                auto&& p_p9 = prism_rtl::some_of(std::get<0>(_m));
                auto&& part_pa = prism_rtl::some_of(std::get<1>(_m));
                ({
                auto&& _m = std::tuple{part_pa, prism_rtl::deref(prism_rtl::deref(p_p9).kind)};
                prism_rtl::is<crate::lower::node_::Wres::WrEv>(std::get<0>(_m)) && prism_rtl::is<crate::syntax::PatternKind::PName>(std::get<1>(_m)) ? ({
                auto&& r_pb = prism_rtl::as<crate::lower::node_::Wres::WrEv>(std::get<0>(_m)).a0;
                prism_rtl::finished(std::tuple{bind_res(w_p5, me_p7, p_p9, part_pa), be_p6, me_p7});
            })
                : prism_rtl::is<crate::lower::node_::Wres::WrParts>(std::get<0>(_m)) && prism_rtl::is<crate::syntax::PatternKind::PTuple>(std::get<1>(_m)) ? ({
                auto&& inner_pc = prism_rtl::as<crate::lower::node_::Wres::WrParts>(std::get<0>(_m)).a0;
                auto&& qs_pd = prism_rtl::as<crate::syntax::PatternKind::PTuple>(std::get<1>(_m)).a0;
                prism_rtl::more(prism_rtl::rc(BindParts(w_p5, be_p6, me_p7, inner_pc, qs_pd)));
            })
                : prism_rtl::is<crate::syntax::PatternKind::PName>(std::get<1>(_m)) ? ({
                auto&& n_pe = prism_rtl::as<crate::syntax::PatternKind::PName>(std::get<1>(_m)).a0;
                ({
                prism_rtl::is<crate::lower::node_::Wres::WrUnit>(part_pa) ? prism_rtl::finished(std::tuple{w_p5, be_p6, me_p7})
                : prism_rtl::is<crate::lower::node_::Wres::WrDyn>(part_pa) ? ({
                auto&& ex_pf = prism_rtl::as<crate::lower::node_::Wres::WrDyn>(part_pa).a0;
                auto&& rds_pg = prism_rtl::as<crate::lower::node_::Wres::WrDyn>(part_pa).a1;
                auto&& t_ph = prism_rtl::as<crate::lower::node_::Wres::WrDyn>(part_pa).a2;
                ({
                auto b_pi = crate::lower::types::Bn(crate::lower::types::Bn::BnDyn{ex_pf, rds_pg, t_ph});
                (prism_rtl::finished(result_getter(w_p5, me_p7, n_pe, ex_pf, rds_pg, t_ph, crate::lower::types::bind(be_p6, crate::check::env::sname_key(n_pe), b_pi), crate::lower::types::bind(me_p7, crate::check::env::sname_key(n_pe), b_pi))));
            });
            })
                : ({
                auto b_pj = bundle_bn(part_pa);
                (prism_rtl::finished(std::tuple{w_p5, crate::lower::types::bind(be_p6, crate::check::env::sname_key(n_pe), b_pj), crate::lower::types::bind(me_p7, crate::check::env::sname_key(n_pe), b_pj)}));
            });
            });
            })
                : prism_rtl::finished(std::tuple{w_p5, be_p6, me_p7});
            });
            })
                : prism_rtl::finished(std::tuple{w_p5, be_p6, me_p7});
            });
            });
        }));
        });
    }));
    }))->cycle();
}


/// `Start BindParts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>> start_bind_parts(crate::lower::node_::Wx wx_p0, crate::lower::types::Env benv_p1, crate::lower::types::Env menv_p2, Array<crate::lower::node_::Wres> parts_p3, Array<crate::syntax::Pattern_> ps_p4) {
    return prism_rtl::make_rc<BindParts>(wx_p0, benv_p1, menv_p2, parts_p3, ps_p4);
}


/// ResultGetter: fn Wx, Env, SName, Ex, [Read], OutTy, Env, Env -> ((Wx, Env, Env))
std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env> result_getter(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& menv_p1, const crate::syntax::SName& n_p2, const crate::lower::model::Ex& ex_p3, const Array<crate::lower::node_::Read>& rds_p4, const crate::lower::model::OutTy& t_p5, const crate::lower::types::Env& benv2_p6, const crate::lower::types::Env& menv2_p7) {
    auto&& _m = crate::prelude::get(menv_p1.names, crate::check::env::sname_key(n_p2));
    if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)) && prism_rtl::is<crate::lower::model::Ex::XMethod>(prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)).a0)) {
        auto&& m20830_0_0_0 = prism_rtl::as<crate::lower::model::Ex::XMethod>(prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)).a0).a0;
        auto&& rs_p8 = prism_rtl::as<crate::lower::model::Ex::XMethod>(prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)).a0).a1;
        auto&& m20830_0_1 = prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)).a1;
        if (prism_rtl::is<crate::lower::model::Ex::XSelf>(prism_rtl::deref(prism_rtl::deref(m20830_0_0_0)))) {
            if (m20830_0_1.size() == 1u) {
                {
                    auto&& _c2 = index(m20830_0_1, Nat(0u));
                    if (prism_rtl::is_some(_c2) && prism_rtl::is<crate::lower::node_::Read::OwnRead>(prism_rtl::some_of(_c2))) {
                        auto&& r0_p9 = prism_rtl::as<crate::lower::node_::Read::OwnRead>(prism_rtl::some_of(_c2)).a0;
                        if ((r0_p9 == rs_p8) && (!crate::check::types::has_text(keys(wx_p0.dyn_reads), rs_p8))) {
                            auto getter_pa = crate::lower::model::MethDef{.name = rs_p8, .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxRef{}), .ret = t_p5, .body = Array<crate::lower::model::Do>{}, .tail = ex_p3, .doc = prism_rtl::cat("`", crate::check::env::sname_key(n_p2), "`, a widget\'s result")};
                            auto wx2_pb = ({
                                crate::lower::node_::Wx this_ = wx_p0;
                                this_.getters = crate::prelude::push(this_.getters, getter_pa);
                                this_.dyn_reads = insert(this_.dyn_reads, rs_p8, rds_p4);
                                (std::move(this_));
                            });
                            return std::tuple{wx2_pb, benv2_p6, menv2_p7};
                        }
                    }
                }
            }
        }
    }
    {
        return std::tuple{wx_p0, benv2_p6, menv2_p7};
    }
}


/// BindPlainResult: unbounded fn Wx, Env, Pattern, Ex, OutTy -> Wx
crate::lower::node_::Wx bind_plain_result(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& menv_p1, const crate::syntax::Pattern_& p_p2, const crate::lower::model::Ex& ex_p3, const crate::lower::model::OutTy& t_p4) {
    auto&& _m = prism_rtl::deref(p_p2.kind);
    if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
        auto&& n_p5 = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        auto&& _m = crate::prelude::get(menv_p1.names, crate::check::env::sname_key(n_p5));
        if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m))) {
            auto&& rx_p6 = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
            auto&& bt_p7 = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
            auto f_p8 = crate::lower::types::place_stem(rx_p6);
            crate::lower::node_::Wx this_ = wx_p0;
            this_.lets = crate::prelude::push(this_.lets, crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{f_p8})), bt_p7}), ex_p3}));
            this_.fields = crate::prelude::push(this_.fields, std::tuple{f_p8, bt_p7, prism_rtl::cat("`", crate::check::env::sname_key(n_p5), "`, a widget\'s result")});
            this_.inits = crate::prelude::push(this_.inits, std::tuple{f_p8, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{f_p8}))})});
            return this_;
        }
        {
            return refuse_plain_result(wx_p0, p_p2);
        }
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PIgnore>(_m)) {
        return wx_p0;
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PGroup>(_m)) {
        auto&& q_p9 = prism_rtl::as<crate::syntax::PatternKind::PGroup>(_m).a0;
        return bind_plain_result(wx_p0, menv_p1, prism_rtl::deref(prism_rtl::deref(q_p9)), ex_p3, t_p4);
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PTuple>(_m)) {
        auto&& ps_pa = prism_rtl::as<crate::syntax::PatternKind::PTuple>(_m).a0;
        auto [tmp_pd, wx1_pe] = crate::lower::node_::fresh_name(wx_p0, Text::lit("result"));
        auto wx2_pb = ({
            crate::lower::node_::Wx this_ = wx1_pe;
            this_.lets = crate::prelude::push(this_.lets, crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{tmp_pd})), t_p4}), ex_p3}));
            (std::move(this_));
        });
        auto parts_pc = ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::lower::model::OutTy>> _v;
            if (prism_rtl::is<crate::lower::model::OutTy::OutTuple>(t_p4)) {
                auto&& ts_pf = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(t_p4).a0;
                _v.set(ts_pf);
                goto _done;
            }
            {
                _v.set(Array<crate::lower::model::OutTy>{});
                goto _done;
            }
        _done:
            _v.take();
        });
        return run_to_end(fold_job(crate::check::errors::range0(len(ps_pa)), wx2_pb, ({
            auto ps_pa_1 = ps_pa;
            auto menv_p1_2 = menv_p1;
            auto tmp_pd_3 = tmp_pd;
            auto parts_pc_4 = parts_pc;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::node_::Wx>(std::tuple<crate::lower::node_::Wx, Nat>)>>(prism_rtl::rc([=, ps_pa_1 = std::move(ps_pa_1), menv_p1_2 = std::move(menv_p1_2), tmp_pd_3 = std::move(tmp_pd_3), parts_pc_4 = std::move(parts_pc_4)](std::tuple<crate::lower::node_::Wx, Nat> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto ps_pa_1_5 = ps_pa_1;
                auto menv_p1_2_5 = menv_p1_2;
                auto tmp_pd_3_5 = tmp_pd_3;
                auto parts_pc_4_5 = parts_pc_4;
                entered(once_job([=, ps_pa_1_5 = std::move(ps_pa_1_5), menv_p1_2_5 = std::move(menv_p1_2_5), tmp_pd_3_5 = std::move(tmp_pd_3_5), parts_pc_4_5 = std::move(parts_pc_4_5)]() {
                return ({
                    auto w_pg = p0;
                    auto i_ph = p1;
                    ({
                    auto&& _m = index(ps_pa_1_5, i_ph);
                    prism_rtl::is_some(_m) ? ({
                    auto&& q_pi = prism_rtl::some_of(_m);
                    ({
                    auto&& _m = prism_rtl::deref(prism_rtl::deref(q_pi).kind);
                    prism_rtl::is<crate::syntax::PatternKind::PName>(_m) ? prism_rtl::more(prism_rtl::rc(BindPlainResult(w_pg, menv_p1_2_5, q_pi, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XPart{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{tmp_pd_3_5})), i_ph}))}), or_(index(parts_pc_4_5, i_ph), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})))))
                    : prism_rtl::is<crate::syntax::PatternKind::PIgnore>(_m) ? prism_rtl::finished(w_pg)
                    : prism_rtl::finished(refuse_plain_result(w_pg, q_pi));
                });
                })
                    : prism_rtl::is_none(_m) ? prism_rtl::finished(w_pg)
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            }));
            });
        })));
        })));
    }
    {
        return refuse_plain_result(wx_p0, p_p2);
    }
}


prism_rtl::Turn<crate::lower::node_::Wx> BindPlainResult::cycle() const {
    const auto& wx_p0 = this->wx_p0;
    const auto& menv_p1 = this->menv_p1;
    const auto& p_p2 = this->p_p2;
    const auto& ex_p3 = this->ex_p3;
    const auto& t_p4 = this->t_p4;
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(p_p2).kind);
        prism_rtl::is<crate::syntax::PatternKind::PName>(_m) ? ({
        auto&& n_p5 = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        ({
        auto&& _m = crate::prelude::get(menv_p1->names, crate::check::env::sname_key(n_p5));
        prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)) ? ({
        auto&& rx_p6 = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
        auto&& bt_p7 = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
        ({
        auto f_p8 = crate::lower::types::place_stem(rx_p6);
        (prism_rtl::finished(({
        crate::lower::node_::Wx this_ = wx_p0;
        this_.lets = crate::prelude::push(this_.lets, crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{f_p8})), bt_p7}), ex_p3}));
        this_.fields = crate::prelude::push(this_.fields, std::tuple{f_p8, bt_p7, prism_rtl::cat("`", crate::check::env::sname_key(n_p5), "`, a widget\'s result")});
        this_.inits = crate::prelude::push(this_.inits, std::tuple{f_p8, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{f_p8}))})});
        (std::move(this_));
    })));
    });
    })
        : prism_rtl::finished(refuse_plain_result(wx_p0, p_p2));
    });
    })
        : prism_rtl::is<crate::syntax::PatternKind::PIgnore>(_m) ? prism_rtl::finished(wx_p0)
        : prism_rtl::is<crate::syntax::PatternKind::PGroup>(_m) ? ({
        auto&& q_p9 = prism_rtl::as<crate::syntax::PatternKind::PGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(BindPlainResult(wx_p0, menv_p1, prism_rtl::deref(prism_rtl::deref(q_p9)), ex_p3, t_p4)));
    })
        : prism_rtl::is<crate::syntax::PatternKind::PTuple>(_m) ? ({
        auto&& ps_pa = prism_rtl::as<crate::syntax::PatternKind::PTuple>(_m).a0;
        ({
        auto [tmp_pd, wx1_pe] = crate::lower::node_::fresh_name(wx_p0, Text::lit("result"));
        auto wx2_pb = ({
            crate::lower::node_::Wx this_ = wx1_pe;
            this_.lets = crate::prelude::push(this_.lets, crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{tmp_pd})), t_p4}), ex_p3}));
            (std::move(this_));
        });
        auto parts_pc = ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::lower::model::OutTy>> _v;
            if (prism_rtl::is<crate::lower::model::OutTy::OutTuple>(t_p4)) {
                auto&& ts_pf = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(t_p4).a0;
                _v.set(ts_pf);
                goto _done;
            }
            {
                _v.set(Array<crate::lower::model::OutTy>{});
                goto _done;
            }
        _done:
            _v.take();
        });
        fold_job(crate::check::errors::range0(len(ps_pa)), wx2_pb, ({
        auto ps_pa_1 = ps_pa;
        auto menv_p1_2 = menv_p1;
        auto tmp_pd_3 = tmp_pd;
        auto parts_pc_4 = parts_pc;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::node_::Wx>(std::tuple<crate::lower::node_::Wx, Nat>)>>(prism_rtl::rc([=, ps_pa_1 = std::move(ps_pa_1), menv_p1_2 = std::move(menv_p1_2), tmp_pd_3 = std::move(tmp_pd_3), parts_pc_4 = std::move(parts_pc_4)](std::tuple<crate::lower::node_::Wx, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto ps_pa_1_5 = ps_pa_1;
            auto menv_p1_2_5 = menv_p1_2;
            auto tmp_pd_3_5 = tmp_pd_3;
            auto parts_pc_4_5 = parts_pc_4;
            entered(once_job([=, ps_pa_1_5 = std::move(ps_pa_1_5), menv_p1_2_5 = std::move(menv_p1_2_5), tmp_pd_3_5 = std::move(tmp_pd_3_5), parts_pc_4_5 = std::move(parts_pc_4_5)]() {
            return ({
                auto w_pg = p0;
                auto i_ph = p1;
                ({
                auto&& _m = index(ps_pa_1_5, i_ph);
                prism_rtl::is_some(_m) ? ({
                auto&& q_pi = prism_rtl::some_of(_m);
                ({
                auto&& _m = prism_rtl::deref(prism_rtl::deref(q_pi).kind);
                prism_rtl::is<crate::syntax::PatternKind::PName>(_m) ? prism_rtl::more(prism_rtl::rc(BindPlainResult(w_pg, menv_p1_2_5, q_pi, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XPart{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{tmp_pd_3_5})), i_ph}))}), or_(index(parts_pc_4_5, i_ph), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})))))
                : prism_rtl::is<crate::syntax::PatternKind::PIgnore>(_m) ? prism_rtl::finished(w_pg)
                : prism_rtl::finished(refuse_plain_result(w_pg, q_pi));
            });
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(w_pg)
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    })));
    }))->cycle();
    });
    })
        : prism_rtl::finished(refuse_plain_result(wx_p0, p_p2));
    });
}


/// `Start BindPlainResult, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::node_::Wx> start_bind_plain_result(crate::lower::node_::Wx wx_p0, crate::lower::types::Env menv_p1, crate::syntax::Pattern_ p_p2, crate::lower::model::Ex ex_p3, crate::lower::model::OutTy t_p4) {
    return prism_rtl::make_rc<BindPlainResult>(wx_p0, menv_p1, p_p2, ex_p3, t_p4);
}


/// RefusePlainResult: fn Wx, Pattern -> Wx
crate::lower::node_::Wx refuse_plain_result(const crate::lower::node_::Wx& wx_p0, const crate::syntax::Pattern_& p_p1) {
    crate::lower::node_::Wx this_ = wx_p0;
    this_.build = crate::prelude::push(this_.build, crate::lower::expr::refusal_do(Text::lit("a widget\'s plain result bound by this pattern: a name, or a tuple of names, binds one")));
    return this_;
}


/// BundleBn: fn Wres -> Bn
crate::lower::types::Bn bundle_bn(const crate::lower::node_::Wres& res_p0) {
    if (prism_rtl::is<crate::lower::node_::Wres::WrEv>(res_p0)) {
        auto&& r_p1 = prism_rtl::as<crate::lower::node_::Wres::WrEv>(res_p0).a0;
        return crate::lower::types::Bn(crate::lower::types::Bn::BnEv{r_p1, crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})});
    }
    if (prism_rtl::is<crate::lower::node_::Wres::WrDyn>(res_p0)) {
        auto&& ex_p2 = prism_rtl::as<crate::lower::node_::Wres::WrDyn>(res_p0).a0;
        auto&& rds_p3 = prism_rtl::as<crate::lower::node_::Wres::WrDyn>(res_p0).a1;
        auto&& t_p4 = prism_rtl::as<crate::lower::node_::Wres::WrDyn>(res_p0).a2;
        return crate::lower::types::Bn(crate::lower::types::Bn::BnDyn{ex_p2, rds_p3, t_p4});
    }
    if (prism_rtl::is<crate::lower::node_::Wres::WrPlain>(res_p0)) {
        auto&& ex_p5 = prism_rtl::as<crate::lower::node_::Wres::WrPlain>(res_p0).a0;
        auto&& t_p6 = prism_rtl::as<crate::lower::node_::Wres::WrPlain>(res_p0).a1;
        return crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{ex_p5, crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), t_p6});
    }
    if (prism_rtl::is<crate::lower::node_::Wres::WrParts>(res_p0)) {
        auto&& parts_p7 = prism_rtl::as<crate::lower::node_::Wres::WrParts>(res_p0).a0;
        return crate::lower::types::Bn(crate::lower::types::Bn::BnParts{each(parts_p7, [&](const crate::lower::node_::Wres& q_p8) { return std::optional(bundle_bn(q_p8)); })});
    }
    if (prism_rtl::is<crate::lower::node_::Wres::WrHosted>(res_p0)) {
        auto&& inner_p9 = prism_rtl::as<crate::lower::node_::Wres::WrHosted>(res_p0).a0;
        return bundle_bn(prism_rtl::deref(prism_rtl::deref(inner_p9)));
    }
    if (prism_rtl::is<crate::lower::node_::Wres::WrUnit>(res_p0)) {
        return crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})});
    }
    prism_rtl::unreachable("no arm matched");
}


/// BnRes: fn Bn -> Wres
crate::lower::node_::Wres bn_res(const crate::lower::types::Bn& b_p0) {
    if (prism_rtl::is<crate::lower::types::Bn::BnEv>(b_p0)) {
        auto&& r_p1 = prism_rtl::as<crate::lower::types::Bn::BnEv>(b_p0).a0;
        return crate::lower::node_::Wres(crate::lower::node_::Wres::WrEv{r_p1});
    }
    if (prism_rtl::is<crate::lower::types::Bn::BnDyn>(b_p0)) {
        auto&& ex_p2 = prism_rtl::as<crate::lower::types::Bn::BnDyn>(b_p0).a0;
        auto&& rds_p3 = prism_rtl::as<crate::lower::types::Bn::BnDyn>(b_p0).a1;
        auto&& t_p4 = prism_rtl::as<crate::lower::types::Bn::BnDyn>(b_p0).a2;
        return crate::lower::node_::Wres(crate::lower::node_::Wres::WrDyn{ex_p2, rds_p3, t_p4});
    }
    if (prism_rtl::is<crate::lower::types::Bn::BnLocal>(b_p0)) {
        auto&& ex_p5 = prism_rtl::as<crate::lower::types::Bn::BnLocal>(b_p0).a0;
        auto&& t_p6 = prism_rtl::as<crate::lower::types::Bn::BnLocal>(b_p0).a2;
        return t_p6 == crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})
            ? crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{})
            : crate::lower::node_::Wres(crate::lower::node_::Wres::WrPlain{ex_p5, t_p6});
    }
    if (prism_rtl::is<crate::lower::types::Bn::BnParts>(b_p0)) {
        auto&& bs_p7 = prism_rtl::as<crate::lower::types::Bn::BnParts>(b_p0).a0;
        return crate::lower::node_::Wres(crate::lower::node_::Wres::WrParts{each(bs_p7, part_res)});
    }
    {
        return crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{});
    }
}


/// PartRes: fn ?Bn -> Wres
crate::lower::node_::Wres part_res(const std::optional<crate::lower::types::Bn>& b_o0) {
    if (prism_rtl::is_some(b_o0)) {
        auto&& b_p1 = prism_rtl::some_of(b_o0);
        return bn_res(b_p1);
    }
    if (prism_rtl::is_none(b_o0)) {
        return crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{});
    }
    prism_rtl::unreachable("no arm matched");
}


/// SetResult: fn Wx, Wres -> Wx
crate::lower::node_::Wx set_result(const crate::lower::node_::Wx& wx_p0, const crate::lower::node_::Wres& res_p1) {
    crate::lower::node_::Wx this_ = wx_p0;
    this_.result = res_p1;
    return this_;
}


/// ResultOf: unbounded fn Wx, Env, Env, Expr -> ((Wres, Wx))
std::tuple<crate::lower::node_::Wres, crate::lower::node_::Wx> result_of(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& benv_p1, const crate::lower::types::Env& menv_p2, const crate::syntax::Expr& x_p3) {
    auto lx_p4 = wx_p0.lx;
    auto full_p5 = crate::lower::type_at(lx_p4, x_p3.span);
    auto t_p6 = crate::lower::types::out_ty_of(lx_p4, crate::lower::types::peel(full_p5));
    auto bound_o7 = ({
        __label__ _done;
        prism_rtl::Slot<std::optional<crate::lower::types::Bn>> _v;
        auto&& _m = prism_rtl::deref(x_p3.kind);
        if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
            auto&& n_p8 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
            _v.set(len(n_p8->path_) == Nat(1u)
                ? crate::prelude::get(menv_p2.names, crate::check::env::sname_key(n_p8))
                : std::optional<crate::lower::types::Bn>{});
            goto _done;
        }
        {
            _v.set(std::optional<crate::lower::types::Bn>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    if (prism_rtl::is_some(bound_o7) && prism_rtl::is<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(bound_o7))) {
        auto&& r_p9 = prism_rtl::as<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(bound_o7)).a0;
        return std::tuple{crate::lower::node_::Wres(crate::lower::node_::Wres::WrEv{r_p9}), wx_p0};
    }
    if (prism_rtl::is_some(bound_o7) && prism_rtl::is<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(bound_o7))) {
        auto&& ex_pa = prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(bound_o7)).a0;
        auto&& rds_pb = prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(bound_o7)).a1;
        auto&& bt_pc = prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(bound_o7)).a2;
        return std::tuple{crate::lower::node_::Wres(crate::lower::node_::Wres::WrDyn{ex_pa, rds_pb, bt_pc}), wx_p0};
    }
    if (prism_rtl::is_some(bound_o7) && prism_rtl::is<crate::lower::types::Bn::BnParts>(prism_rtl::some_of(bound_o7))) {
        auto&& bs_pd = prism_rtl::as<crate::lower::types::Bn::BnParts>(prism_rtl::some_of(bound_o7)).a0;
        return std::tuple{bn_res(crate::lower::types::Bn(crate::lower::types::Bn::BnParts{bs_pd})), wx_p0};
    }
    {
        auto&& _m = prism_rtl::deref(x_p3.kind);
        if (prism_rtl::is<crate::syntax::ExprKind::ETuple>(_m)) {
            auto&& xs_pe = prism_rtl::as<crate::syntax::ExprKind::ETuple>(_m).a0;
            if (crate::lower::types::is_bundle(full_p5)) {
                auto [parts_pk, wx2_pl] = run_to_end(fold_job(xs_pe, std::tuple{Array<crate::lower::node_::Wres>{}, wx_p0}, ({
                    auto benv_p1_1 = benv_p1;
                    auto menv_p2_2 = menv_p2;
                    static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::lower::node_::Wres>, crate::lower::node_::Wx>>(std::tuple<std::tuple<Array<crate::lower::node_::Wres>, crate::lower::node_::Wx>, crate::syntax::Expr>)>>(prism_rtl::rc([=, benv_p1_1 = std::move(benv_p1_1), menv_p2_2 = std::move(menv_p2_2)](std::tuple<std::tuple<Array<crate::lower::node_::Wres>, crate::lower::node_::Wx>, crate::syntax::Expr> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto benv_p1_1_3 = benv_p1_1;
                        auto menv_p2_2_3 = menv_p2_2;
                        entered(once_job([=, benv_p1_1_3 = std::move(benv_p1_1_3), menv_p2_2_3 = std::move(menv_p2_2_3)]() {
                        return ({
                            auto [acc_pf, w_pg] = p0;
                            auto y_ph = p1;
                            call_then(start_result_of(w_pg, benv_p1_1_3, menv_p2_2_3, y_ph), [=](std::tuple<crate::lower::node_::Wres, crate::lower::node_::Wx> result_of_24875) {
                            return ({
                                auto [r_pi, w2_pj] = result_of_24875;
                                (prism_rtl::finished(std::tuple{crate::prelude::push(acc_pf, r_pi), w2_pj}));
                            });
                        });
                        });
                    }));
                    });
                }));
                })));
                return std::tuple{crate::lower::node_::Wres(crate::lower::node_::Wres::WrParts{parts_pk}), wx2_pl};
            }
        }
        {
            return result_of_typed(wx_p0, benv_p1, menv_p2, x_p3, full_p5, t_p6);
        }
    }
}


prism_rtl::Turn<std::tuple<crate::lower::node_::Wres, crate::lower::node_::Wx>> ResultOf::cycle() const {
    const auto& wx_p0 = this->wx_p0;
    const auto& benv_p1 = this->benv_p1;
    const auto& menv_p2 = this->menv_p2;
    const auto& x_p3 = this->x_p3;
    auto lx_p4 = prism_rtl::deref(wx_p0).lx;
    auto full_p5 = crate::lower::type_at(lx_p4, prism_rtl::deref(x_p3).span);
    auto benv_p1_1 = benv_p1;
    auto menv_p2_2 = menv_p2;
    auto wx_p0_3 = wx_p0;
    auto x_p3_4 = x_p3;
    return call_then(crate::lower::types::start_out_ty_of(lx_p4, crate::lower::types::peel(full_p5)), [=](crate::lower::model::OutTy out_ty_of_24284) {
        return ({
            auto t_p6 = out_ty_of_24284;
            auto bound_o7 = ({
                __label__ _done;
                prism_rtl::Slot<std::optional<crate::lower::types::Bn>> _v;
                auto&& _m = prism_rtl::deref(prism_rtl::deref(x_p3_4).kind);
                if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
                    auto&& n_p8 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
                    _v.set(len(n_p8->path_) == Nat(1u)
                        ? crate::prelude::get(menv_p2_2->names, crate::check::env::sname_key(n_p8))
                        : std::optional<crate::lower::types::Bn>{});
                    goto _done;
                }
                {
                    _v.set(std::optional<crate::lower::types::Bn>{});
                    goto _done;
                }
            _done:
                _v.take();
            });
            ({
            prism_rtl::is_some(bound_o7) && prism_rtl::is<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(bound_o7)) ? ({
            auto&& r_p9 = prism_rtl::as<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(bound_o7)).a0;
            prism_rtl::finished(std::tuple{crate::lower::node_::Wres(crate::lower::node_::Wres::WrEv{r_p9}), wx_p0_3});
        })
            : prism_rtl::is_some(bound_o7) && prism_rtl::is<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(bound_o7)) ? ({
            auto&& ex_pa = prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(bound_o7)).a0;
            auto&& rds_pb = prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(bound_o7)).a1;
            auto&& bt_pc = prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(bound_o7)).a2;
            prism_rtl::finished(std::tuple{crate::lower::node_::Wres(crate::lower::node_::Wres::WrDyn{ex_pa, rds_pb, bt_pc}), wx_p0_3});
        })
            : prism_rtl::is_some(bound_o7) && prism_rtl::is<crate::lower::types::Bn::BnParts>(prism_rtl::some_of(bound_o7)) ? ({
            auto&& bs_pd = prism_rtl::as<crate::lower::types::Bn::BnParts>(prism_rtl::some_of(bound_o7)).a0;
            prism_rtl::finished(std::tuple{bn_res(crate::lower::types::Bn(crate::lower::types::Bn::BnParts{bs_pd})), wx_p0_3});
        })
            : ({
            auto&& _m = prism_rtl::deref(prism_rtl::deref(x_p3_4).kind);
            prism_rtl::is<crate::syntax::ExprKind::ETuple>(_m) && ({
            auto&& xs_pe = prism_rtl::as<crate::syntax::ExprKind::ETuple>(_m).a0;
            crate::lower::types::is_bundle(full_p5);
        }) ? ({
            auto&& xs_pe = prism_rtl::as<crate::syntax::ExprKind::ETuple>(_m).a0;
            ({
            auto xs_pe_5 = xs_pe;
            call_value(fold_job(xs_pe_5, std::tuple{Array<crate::lower::node_::Wres>{}, wx_p0_3}, ({
            auto benv_p1_1_6 = benv_p1_1;
            auto menv_p2_2_6 = menv_p2_2;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::lower::node_::Wres>, crate::lower::node_::Wx>>(std::tuple<std::tuple<Array<crate::lower::node_::Wres>, crate::lower::node_::Wx>, crate::syntax::Expr>)>>(prism_rtl::rc([=, benv_p1_1_6 = std::move(benv_p1_1_6), menv_p2_2_6 = std::move(menv_p2_2_6)](std::tuple<std::tuple<Array<crate::lower::node_::Wres>, crate::lower::node_::Wx>, crate::syntax::Expr> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto benv_p1_1_6_6 = benv_p1_1_6;
                auto menv_p2_2_6_6 = menv_p2_2_6;
                entered(once_job([=, benv_p1_1_6_6 = std::move(benv_p1_1_6_6), menv_p2_2_6_6 = std::move(menv_p2_2_6_6)]() {
                return ({
                    auto [acc_pf, w_pg] = p0;
                    auto y_ph = p1;
                    call_then(start_result_of(w_pg, benv_p1_1_6_6, menv_p2_2_6_6, y_ph), [=](std::tuple<crate::lower::node_::Wres, crate::lower::node_::Wx> result_of_24875) {
                    return ({
                        auto [r_pi, w2_pj] = result_of_24875;
                        (prism_rtl::finished(std::tuple{crate::prelude::push(acc_pf, r_pi), w2_pj}));
                    });
                });
                });
            }));
            });
        }));
        })), [=](std::tuple<Array<crate::lower::node_::Wres>, crate::lower::node_::Wx> fold_24799) {
            return ({
                auto [parts_pk, wx2_pl] = fold_24799;
                (prism_rtl::finished(std::tuple{crate::lower::node_::Wres(crate::lower::node_::Wres::WrParts{parts_pk}), wx2_pl}));
            });
        });
        });
        })
            : prism_rtl::more(prism_rtl::rc(ResultOfTyped(wx_p0_3, benv_p1_1, menv_p2_2, x_p3_4, full_p5, t_p6)));
        });
        });
        });
    });
}


/// `Start ResultOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::lower::node_::Wres, crate::lower::node_::Wx>> start_result_of(crate::lower::node_::Wx wx_p0, crate::lower::types::Env benv_p1, crate::lower::types::Env menv_p2, crate::syntax::Expr x_p3) {
    return prism_rtl::make_rc<ResultOf>(wx_p0, benv_p1, menv_p2, x_p3);
}


/// ResultOfTyped: unbounded fn Wx, Env, Env, Expr, Ty, OutTy -> ((Wres, Wx))
std::tuple<crate::lower::node_::Wres, crate::lower::node_::Wx> result_of_typed(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& benv_p1, const crate::lower::types::Env& menv_p2, const crate::syntax::Expr& x_p3, const crate::check::types::Ty& full_p4, const crate::lower::model::OutTy& t_p5) {
    auto lx_p6 = wx_p0.lx;
    auto&& _m = crate::lower::types::layer_of(full_p4);
    if (prism_rtl::is<crate::lower::types::Layer::LyEv>(_m)) {
        auto [r_p7, wx2_p8] = crate::lower::node_::dynamics::event_ref(wx_p0, menv_p2, x_p3);
        return std::tuple{crate::lower::node_::Wres(crate::lower::node_::Wres::WrEv{r_p7}), wx2_p8};
    }
    if (prism_rtl::is<crate::lower::types::Layer::LyDyn>(_m)) {
        auto [ex_p9, reads_pa] = crate::lower::node_::dynamics::dynamic_expr(wx_p0, menv_p2, x_p3);
        return std::tuple{crate::lower::node_::Wres(crate::lower::node_::Wres::WrDyn{ex_p9, reads_pa, t_p5}), wx_p0};
    }
    {
        return t_p5 == crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})
            ? std::tuple{crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{}), wx_p0}
            : std::tuple{crate::lower::node_::Wres(crate::lower::node_::Wres::WrPlain{crate::lower::types::own(crate::lower::expr::value_of(lx_p6, benv_p1, x_p3)), t_p5}), wx_p0};
    }
}


prism_rtl::Turn<std::tuple<crate::lower::node_::Wres, crate::lower::node_::Wx>> ResultOfTyped::cycle() const {
    const auto& wx_p0 = this->wx_p0;
    const auto& benv_p1 = this->benv_p1;
    const auto& menv_p2 = this->menv_p2;
    const auto& x_p3 = this->x_p3;
    const auto& full_p4 = this->full_p4;
    const auto& t_p5 = this->t_p5;
    auto lx_p6 = prism_rtl::deref(wx_p0).lx;
    return ({
        auto&& _m = crate::lower::types::layer_of(full_p4);
        prism_rtl::is<crate::lower::types::Layer::LyEv>(_m) ? ({
        auto menv_p2_1 = menv_p2;
        auto wx_p0_2 = wx_p0;
        auto x_p3_3 = x_p3;
        call_then(crate::lower::node_::dynamics::start_event_ref(wx_p0_2, menv_p2_1, x_p3_3), [=](std::tuple<crate::lower::node_::EvRef, crate::lower::node_::Wx> event_ref_25252) {
        return ({
            auto [r_p7, wx2_p8] = event_ref_25252;
            (prism_rtl::finished(std::tuple{crate::lower::node_::Wres(crate::lower::node_::Wres::WrEv{r_p7}), wx2_p8}));
        });
    });
    })
        : prism_rtl::is<crate::lower::types::Layer::LyDyn>(_m) ? ({
        auto menv_p2_1 = menv_p2;
        auto t_p5_2 = t_p5;
        auto wx_p0_3 = wx_p0;
        auto x_p3_4 = x_p3;
        call_then(crate::lower::node_::dynamics::start_dynamic_expr(wx_p0_3, menv_p2_1, x_p3_4), [=, t_p5_2 = std::move(t_p5_2)](std::tuple<crate::lower::model::Ex, Array<crate::lower::node_::Read>> dynamic_expr_25348) {
        return ({
            auto [ex_p9, reads_pa] = dynamic_expr_25348;
            (prism_rtl::finished(std::tuple{crate::lower::node_::Wres(crate::lower::node_::Wres::WrDyn{ex_p9, reads_pa, t_p5_2}), wx_p0_3}));
        });
    });
    })
        : t_p5 == crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})
        ? prism_rtl::finished(std::tuple{crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{}), wx_p0})
        : ({
        auto benv_p1_1 = benv_p1;
        auto t_p5_2 = t_p5;
        auto wx_p0_3 = wx_p0;
        auto x_p3_4 = x_p3;
        call_then(crate::lower::expr::start_value_of(lx_p6, benv_p1_1, x_p3_4), [=, t_p5_2 = std::move(t_p5_2), wx_p0_3 = std::move(wx_p0_3)](crate::lower::types::Vl value_of_25511) { return prism_rtl::finished(std::tuple{crate::lower::node_::Wres(crate::lower::node_::Wres::WrPlain{crate::lower::types::own(value_of_25511), t_p5_2}), wx_p0_3}); });
    });
    });
}


/// `Start ResultOfTyped, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::lower::node_::Wres, crate::lower::node_::Wx>> start_result_of_typed(crate::lower::node_::Wx wx_p0, crate::lower::types::Env benv_p1, crate::lower::types::Env menv_p2, crate::syntax::Expr x_p3, crate::check::types::Ty full_p4, crate::lower::model::OutTy t_p5) {
    return prism_rtl::make_rc<ResultOfTyped>(wx_p0, benv_p1, menv_p2, x_p3, full_p4, t_p5);
}


/// HoldLine: unbounded fn Wx, Env, Env, Pattern, Expr, Expr -> ((Wx, Env))
std::tuple<crate::lower::node_::Wx, crate::lower::types::Env> hold_line(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& benv_p1, const crate::lower::types::Env& menv_p2, const crate::syntax::Pattern_& p_p3, const crate::syntax::Expr& init_p4, const crate::syntax::Expr& step_p5) {
    auto lx_p6 = wx_p0.lx;
    auto&& _m = binding_of(menv_p2, p_p3);
    if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnHold>(prism_rtl::some_of(_m))) {
        auto&& f_p7 = prism_rtl::as<crate::lower::types::Bn::BnHold>(prism_rtl::some_of(_m)).a0;
        auto&& t_p8 = prism_rtl::as<crate::lower::types::Bn::BnHold>(prism_rtl::some_of(_m)).a1;
        auto iv_p9 = crate::lower::types::own(crate::lower::expr::value_of(lx_p6, benv_p1, init_p4));
        auto wx1_pa = crate::lower::node_::add_field(wx_p0, f_p7, crate::lower::model::OutTy(crate::lower::model::OutTy::OutHold{prism_rtl::rc(t_p8)}), prism_rtl::cat("`", pat_text(p_p3), "`"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Hold::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat(f_p7, "_init")}))}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}));
        auto [r_pc, wx2_pd] = crate::lower::node_::dynamics::event_ref(wx1_pa, menv_p2, step_p5);
        auto wx3_pb = ({
            crate::lower::node_::Wx this_ = crate::lower::node_::connect(wx2_pd, r_pc, crate::lower::node_::Sk(crate::lower::node_::Sk::SkHold{f_p7}));
            this_.lets = crate::prelude::push(this_.lets, crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{prism_rtl::cat(f_p7, "_init")})), t_p8}), iv_p9}));
            this_.inited = crate::prelude::push(this_.inited, f_p7);
            (std::move(this_));
        });
        return std::tuple{wx3_pb, crate::lower::types::bind(benv_p1, prism_rtl::cat(pat_text(p_p3), "#init"), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat(f_p7, "_init")}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), t_p8}))};
    }
    {
        return std::tuple{wx_p0, benv_p1};
    }
}


prism_rtl::Turn<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env>> HoldLine::cycle() const {
    const auto& wx_p0 = this->wx_p0;
    const auto& benv_p1 = this->benv_p1;
    const auto& menv_p2 = this->menv_p2;
    const auto& p_p3 = this->p_p3;
    const auto& init_p4 = this->init_p4;
    const auto& step_p5 = this->step_p5;
    auto lx_p6 = prism_rtl::deref(wx_p0).lx;
    return ({
        auto&& _m = binding_of(menv_p2, p_p3);
        prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnHold>(prism_rtl::some_of(_m)) ? ({
        auto&& f_p7 = prism_rtl::as<crate::lower::types::Bn::BnHold>(prism_rtl::some_of(_m)).a0;
        auto&& t_p8 = prism_rtl::as<crate::lower::types::Bn::BnHold>(prism_rtl::some_of(_m)).a1;
        ({
        auto benv_p1_1 = benv_p1;
        auto init_p4_2 = init_p4;
        auto menv_p2_3 = menv_p2;
        auto p_p3_4 = p_p3;
        auto step_p5_5 = step_p5;
        auto wx_p0_6 = wx_p0;
        call_then(crate::lower::expr::start_value_of(lx_p6, benv_p1_1, init_p4_2), [=, menv_p2_3 = std::move(menv_p2_3), p_p3_4 = std::move(p_p3_4), step_p5_5 = std::move(step_p5_5), wx_p0_6 = std::move(wx_p0_6)](crate::lower::types::Vl value_of_26066) {
        return ({
            auto iv_p9 = crate::lower::types::own(value_of_26066);
            auto wx1_pa = crate::lower::node_::add_field(wx_p0_6, f_p7, crate::lower::model::OutTy(crate::lower::model::OutTy::OutHold{prism_rtl::rc(t_p8)}), prism_rtl::cat("`", pat_text(p_p3_4), "`"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Hold::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat(f_p7, "_init")}))}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}));
            call_then(crate::lower::node_::dynamics::start_event_ref(wx1_pa, menv_p2_3, step_p5_5), [=, iv_p9 = std::move(iv_p9)](std::tuple<crate::lower::node_::EvRef, crate::lower::node_::Wx> event_ref_26244) {
            return ({
                auto [r_pc, wx2_pd] = event_ref_26244;
                auto wx3_pb = ({
                    crate::lower::node_::Wx this_ = crate::lower::node_::connect(wx2_pd, r_pc, crate::lower::node_::Sk(crate::lower::node_::Sk::SkHold{f_p7}));
                    this_.lets = crate::prelude::push(this_.lets, crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{prism_rtl::cat(f_p7, "_init")})), t_p8}), iv_p9}));
                    this_.inited = crate::prelude::push(this_.inited, f_p7);
                    (std::move(this_));
                });
                (prism_rtl::finished(std::tuple{wx3_pb, crate::lower::types::bind(benv_p1_1, prism_rtl::cat(pat_text(p_p3_4), "#init"), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat(f_p7, "_init")}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), t_p8}))}));
            });
        });
        });
    });
    });
    })
        : prism_rtl::finished(std::tuple{wx_p0, benv_p1});
    });
}


/// `Start HoldLine, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env>> start_hold_line(crate::lower::node_::Wx wx_p0, crate::lower::types::Env benv_p1, crate::lower::types::Env menv_p2, crate::syntax::Pattern_ p_p3, crate::syntax::Expr init_p4, crate::syntax::Expr step_p5) {
    return prism_rtl::make_rc<HoldLine>(wx_p0, benv_p1, menv_p2, p_p3, init_p4, step_p5);
}


/// InitEnv: fn Env -> Env
crate::lower::types::Env init_env(const crate::lower::types::Env& env_p0) {
    return fold(keys(env_p0.names), env_p0, [&](const crate::lower::types::Env& en_p1, const Text& k_p2) {
        return ({
            __label__ _done;
            prism_rtl::Slot<crate::lower::types::Env> _v;
            auto&& _m = std::tuple{crate::syntax::lexer::chars::before_suffix(k_p2, Text::lit("#init")), crate::prelude::get(env_p0.names, k_p2)};
            if (prism_rtl::is_some(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m))) {
                auto&& name_p3 = prism_rtl::some_of(std::get<0>(_m));
                auto&& b_p4 = prism_rtl::some_of(std::get<1>(_m));
                _v.set(crate::lower::types::bind(en_p1, name_p3, b_p4));
                goto _done;
            }
            {
                _v.set(en_p1);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


/// AllInited: fn Wx, [Read] -> Bool
bool all_inited(const crate::lower::node_::Wx& wx_p0, const Array<crate::lower::node_::Read>& reads_p1) {
    return fold(crate::lower::node_::finish::reads_closed(wx_p0.dyn_reads, reads_p1), true, [&](const bool& ok_p2, const crate::lower::node_::Read& r_p3) {
        return prism_rtl::deref(ok_p2) && ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            if (prism_rtl::is<crate::lower::node_::Read::OwnRead>(r_p3)) {
                auto&& f_p4 = prism_rtl::as<crate::lower::node_::Read::OwnRead>(r_p3).a0;
                _v.set(crate::check::types::has_text(wx_p0.inited, f_p4));
                goto _done;
            }
            if (prism_rtl::is<crate::lower::node_::Read::ParentRead>(r_p3)) {
                _v.set(false);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
}


/// NamesInited: unbounded fn Env, Expr -> Bool
bool names_inited(const crate::lower::types::Env& env_p0, const crate::syntax::Expr& e_p1) {
    return fold(crate::lower::expr::read_names(crate::check::typed::print::exprs_in(e_p1)), true, [&](const bool& ok_p2, const Text& n_p3) {
        return prism_rtl::deref(ok_p2) && ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            auto&& _m = crate::prelude::get(env_p0.names, n_p3);
            if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m))) {
                _v.set(crate::check::env::has_key(env_p0.names, prism_rtl::cat(n_p3, "#init")));
                goto _done;
            }
            if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnHold>(prism_rtl::some_of(_m))) {
                _v.set(crate::check::env::has_key(env_p0.names, prism_rtl::cat(n_p3, "#init")));
                goto _done;
            }
            {
                _v.set(true);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


prism_rtl::Turn<bool> NamesInited::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& e_p1 = this->e_p1;
    auto e_p1_1 = e_p1;
    auto env_p0_2 = env_p0;
    return call_then(crate::check::typed::print::start_exprs_in(e_p1_1), [=](Array<crate::syntax::Expr> exprs_in_27763) {
        return call_then(crate::lower::expr::start_read_names(exprs_in_27763), [=](Array<Text> read_names_27752) {
            return prism_rtl::finished(fold(read_names_27752, true, [&](const bool& ok_p2, const Text& n_p3) {
                return prism_rtl::deref(ok_p2) && ({
                    __label__ _done;
                    prism_rtl::Slot<bool> _v;
                    auto&& _m = crate::prelude::get(env_p0_2->names, n_p3);
                    if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m))) {
                        _v.set(crate::check::env::has_key(env_p0_2->names, prism_rtl::cat(n_p3, "#init")));
                        goto _done;
                    }
                    if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnHold>(prism_rtl::some_of(_m))) {
                        _v.set(crate::check::env::has_key(env_p0_2->names, prism_rtl::cat(n_p3, "#init")));
                        goto _done;
                    }
                    {
                        _v.set(true);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
            }));
        });
    });
}


/// `Start NamesInited, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_names_inited(crate::lower::types::Env env_p0, crate::syntax::Expr e_p1) {
    return prism_rtl::make_rc<NamesInited>(env_p0, e_p1);
}


/// PatText: fn Pattern -> Text
Text pat_text(const crate::syntax::Pattern_& p_p0) {
    auto&& _m = prism_rtl::deref(p_p0.kind);
    if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
        auto&& n_p1 = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        return crate::check::env::sname_key(n_p1);
    }
    {
        return Text::lit("_");
    }
}


/// LetLine: unbounded fn Wx, Env, Env, Pattern, Expr -> ((Wx, Env))
std::tuple<crate::lower::node_::Wx, crate::lower::types::Env> let_line(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& benv_p1, const crate::lower::types::Env& menv_p2, const crate::syntax::Pattern_& p_p3, const crate::syntax::Expr& e_p4) {
    auto lx_p5 = wx_p0.lx;
    auto&& _m = binding_of(menv_p2, p_p3);
    if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(_m))) {
        auto&& er_p6 = prism_rtl::as<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(_m)).a0;
        auto&& t_p7 = prism_rtl::as<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(_m)).a1;
        auto [r_pa, wx2_pb] = crate::lower::node_::dynamics::event_ref(wx_p0, menv_p2, e_p4);
        auto fed_p8 = crate::lower::types::out_ty_of(lx_p5, crate::lower::types::peel(crate::lower::types::peel(crate::lower::type_at(lx_p5, e_p4.span))));
        auto r2_p9 = ({
            __label__ _done;
            prism_rtl::Slot<crate::lower::node_::EvRef> _v;
            if (prism_rtl::is<crate::lower::model::OutTy::OutEvent>(t_p7)) {
                auto&& m28639_0_0 = prism_rtl::as<crate::lower::model::OutTy::OutEvent>(t_p7).a0;
                if (prism_rtl::is<crate::lower::model::OutTy::OutRes>(prism_rtl::deref(prism_rtl::deref(m28639_0_0)))) {
                    _v.set(fed_p8 == crate::lower::model::OutTy(crate::lower::model::OutTy::OutError{})
                        ? err_pipe(r_pa)
                        : r_pa);
                    goto _done;
                }
            }
            if (prism_rtl::is<crate::lower::model::OutTy::OutRes>(t_p7)) {
                _v.set(fed_p8 == crate::lower::model::OutTy(crate::lower::model::OutTy::OutError{})
                    ? err_pipe(r_pa)
                    : r_pa);
                goto _done;
            }
            {
                _v.set(r_pa);
                goto _done;
            }
        _done:
            _v.take();
        });
        return std::tuple{crate::lower::node_::connect(wx2_pb, r2_p9, crate::lower::node_::Sk(crate::lower::node_::Sk::SkNode{prism_rtl::deref(er_p6).node_})), benv_p1};
    }
    if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m))) {
        auto&& t_pc = prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)).a2;
        auto rs_pd = crate::lower::snake(pat_text(p_p3));
        auto [ex_pj, reads_pk] = crate::lower::node_::dynamics::dynamic_expr(wx_p0, menv_p2, e_p4);
        auto cached_pe = (len(reads_pk) > Nat(0u)) && fold(crate::lower::node_::finish::reads_all(wx_p0.dyn_reads, reads_pk), true, [&](const bool& ok_pl, const crate::lower::node_::Read& r_pm) { return prism_rtl::deref(ok_pl) && crate::lower::node_::finish::is_own_read(r_pm); });
        auto tail_pf = std::move(cached_pe)
            ? crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(rs_pd, "_cache")})), Text::lit("get"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{}), crate::lower::model::Ex(crate::lower::model::Ex::XClosure{false, Array<crate::lower::model::Pa>{}, prism_rtl::rc(ex_pj)})})})
            : ex_pj;
        auto getter_pg = crate::lower::model::MethDef{.name = rs_pd, .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxRef{}), .ret = t_pc, .body = Array<crate::lower::model::Do>{}, .tail = tail_pf, .doc = prism_rtl::cat("`", pat_text(p_p3), "`")};
        auto wx1_ph = std::move(cached_pe)
            ? ({
            crate::lower::node_::Wx this_ = crate::lower::node_::add_field(wx_p0, prism_rtl::cat(rs_pd, "_cache"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Cache"), Array(std::vector{t_pc})}), prism_rtl::cat("`", pat_text(p_p3), "`, cached"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Cache::new"), Array<crate::lower::model::Ex>{}}));
            this_.let_caches = crate::prelude::push(this_.let_caches, rs_pd);
            this_.taken = crate::prelude::push(this_.taken, prism_rtl::cat(rs_pd, "_cache"));
            (std::move(this_));
        })
            : wx_p0;
        auto wx2_pi = ({
            crate::lower::node_::Wx this_ = wx1_ph;
            this_.getters = crate::prelude::push(this_.getters, getter_pg);
            this_.dyn_reads = insert(this_.dyn_reads, rs_pd, reads_pk);
            (std::move(this_));
        });
        return all_inited(wx2_pi, reads_pk) && names_inited(benv_p1, e_p4)
            ? ({
            auto wx3_pn = ({
                crate::lower::node_::Wx this_ = wx2_pi;
                this_.lets = crate::prelude::push(this_.lets, crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{prism_rtl::cat(rs_pd, "_init")})), t_pc}), crate::lower::types::own(crate::lower::expr::value_of(lx_p5, init_env(benv_p1), e_p4))}));
                this_.inited = crate::prelude::push(this_.inited, rs_pd);
                (std::move(this_));
            });
            std::tuple{wx3_pn, crate::lower::types::bind(benv_p1, prism_rtl::cat(pat_text(p_p3), "#init"), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat(rs_pd, "_init")}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), t_pc}))};
        })
            : std::tuple{wx2_pi, benv_p1};
    }
    if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m))) {
        auto&& rs_po = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
        auto&& t_pp = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
        auto insts_oq = ({
            __label__ _done;
            prism_rtl::Slot<std::optional<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>>> _v;
            auto&& _m = prism_rtl::deref(p_p3.kind);
            if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
                auto&& n_pr = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
                _v.set(many_instances(lx_p5, prism_rtl::deref(n_pr).span));
                goto _done;
            }
            {
                _v.set(std::optional<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>>{});
                goto _done;
            }
        _done:
            _v.take();
        });
        if (prism_rtl::is_some(insts_oq)) {
            auto&& insts_ps = prism_rtl::some_of(insts_oq);
            auto&& _m = prism_rtl::deref(p_p3.kind);
            if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
                auto&& n_pt = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
                auto nkey_pu = crate::check::env::sname_key(n_pt);
                auto wxn_pv = run_to_end(fold_job(crate::check::errors::range0(len(insts_ps)), wx_p0, ({
                    auto lx_p5_1 = lx_p5;
                    auto insts_ps_2 = insts_ps;
                    auto nkey_pu_3 = nkey_pu;
                    auto menv_p2_4 = menv_p2;
                    auto benv_p1_5 = benv_p1;
                    auto e_p4_6 = e_p4;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::node_::Wx>(std::tuple<crate::lower::node_::Wx, Nat>)>>(prism_rtl::rc([=, lx_p5_1 = std::move(lx_p5_1), insts_ps_2 = std::move(insts_ps_2), nkey_pu_3 = std::move(nkey_pu_3), menv_p2_4 = std::move(menv_p2_4), benv_p1_5 = std::move(benv_p1_5), e_p4_6 = std::move(e_p4_6)](std::tuple<crate::lower::node_::Wx, Nat> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto lx_p5_1_7 = lx_p5_1;
                        auto insts_ps_2_7 = insts_ps_2;
                        auto nkey_pu_3_7 = nkey_pu_3;
                        auto menv_p2_4_7 = menv_p2_4;
                        auto benv_p1_5_7 = benv_p1_5;
                        auto e_p4_6_7 = e_p4_6;
                        entered(once_job([=, lx_p5_1_7 = std::move(lx_p5_1_7), insts_ps_2_7 = std::move(insts_ps_2_7), nkey_pu_3_7 = std::move(nkey_pu_3_7), menv_p2_4_7 = std::move(menv_p2_4_7), benv_p1_5_7 = std::move(benv_p1_5_7), e_p4_6_7 = std::move(e_p4_6_7)]() {
                        return ({
                            auto w_p10 = p0;
                            auto k_p11 = p1;
                            ({
                            auto lxk_p12 = crate::lower::expr::at_instance(lx_p5_1_7, or_(index(insts_ps_2_7, k_p11), std::tuple{Array<std::tuple<Text, crate::check::types::Ty>>{}, Array<std::tuple<Text, crate::check::types::Col>>{}}));
                            auto bkey_p13 = k_p11 == Nat(0u)
                                ? nkey_pu_3_7
                                : prism_rtl::cat(nkey_pu_3_7, "#inst", k_p11);
                            ({
                            auto&& _m = crate::prelude::get(menv_p2_4_7.names, bkey_p13);
                            prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)) ? ({
                            auto&& rk_p14 = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                            auto&& tk_p15 = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                            call_then(crate::lower::expr::start_value_of(lxk_p12, benv_p1_5_7, e_p4_6_7), [=](crate::lower::types::Vl value_of_31300) { return prism_rtl::finished(widget_let_field(w_p10, crate::lower::types::place_stem(rk_p14), tk_p15, crate::lower::types::own(value_of_31300), prism_rtl::cat("`", nkey_pu_3_7, "` at its instantiation ", k_p11))); });
                        })
                            : prism_rtl::finished(({
                            crate::lower::node_::Wx this_ = w_p10;
                            this_.build = crate::prelude::push(this_.build, crate::lower::expr::refusal_do(prism_rtl::cat("`", nkey_pu_3_7, "` at its instantiation ", k_p11, ", which has no binding")));
                            (std::move(this_));
                        }));
                        });
                        });
                        });
                    }));
                    });
                })));
                })));
                return std::tuple{wxn_pv, benv_p1};
            }
            {
                return std::tuple{wx_p0, benv_p1};
            }
        }
        if (prism_rtl::is_none(insts_oq)) {
            auto lxw_p16 = ({
                __label__ _done;
                prism_rtl::Slot<crate::lower::Lx> _v;
                auto&& _m = prism_rtl::deref(p_p3.kind);
                if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
                    auto&& n_p18 = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
                    _v.set(crate::lower::expr::widget_let_lx(lx_p5, prism_rtl::deref(n_p18).span));
                    goto _done;
                }
                {
                    _v.set(lx_p5);
                    goto _done;
                }
            _done:
                _v.take();
            });
            auto v_p17 = crate::lower::types::own(crate::lower::expr::value_of(lxw_p16, benv_p1, e_p4));
            return std::tuple{widget_let_field(wx_p0, crate::lower::types::place_stem(rs_po), t_pp, v_p17, prism_rtl::cat("`", pat_text(p_p3), "`")), benv_p1};
        }
        prism_rtl::unreachable("no arm matched");
    }
    {
        return std::tuple{wx_p0, benv_p1};
    }
}


prism_rtl::Turn<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env>> LetLine::cycle() const {
    const auto& wx_p0 = this->wx_p0;
    const auto& benv_p1 = this->benv_p1;
    const auto& menv_p2 = this->menv_p2;
    const auto& p_p3 = this->p_p3;
    const auto& e_p4 = this->e_p4;
    auto lx_p5 = prism_rtl::deref(wx_p0).lx;
    return ({
        auto&& _m = binding_of(menv_p2, p_p3);
        prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(_m)) ? ({
        auto&& er_p6 = prism_rtl::as<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(_m)).a0;
        auto&& t_p7 = prism_rtl::as<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(_m)).a1;
        ({
        auto benv_p1_1 = benv_p1;
        auto e_p4_2 = e_p4;
        auto menv_p2_3 = menv_p2;
        auto wx_p0_4 = wx_p0;
        call_then(crate::lower::node_::dynamics::start_event_ref(wx_p0_4, menv_p2_3, e_p4_2), [=, benv_p1_1 = std::move(benv_p1_1)](std::tuple<crate::lower::node_::EvRef, crate::lower::node_::Wx> event_ref_28529) {
        return ({
            auto [r_pa, wx2_pb] = event_ref_28529;
            call_then(crate::lower::types::start_out_ty_of(lx_p5, crate::lower::types::peel(crate::lower::types::peel(crate::lower::type_at(lx_p5, prism_rtl::deref(e_p4_2).span)))), [=](crate::lower::model::OutTy out_ty_of_28572) {
            return ({
                auto fed_p8 = out_ty_of_28572;
                auto r2_p9 = ({
                    __label__ _done;
                    prism_rtl::Slot<crate::lower::node_::EvRef> _v;
                    if (prism_rtl::is<crate::lower::model::OutTy::OutEvent>(t_p7)) {
                        auto&& m28639_0_0 = prism_rtl::as<crate::lower::model::OutTy::OutEvent>(t_p7).a0;
                        if (prism_rtl::is<crate::lower::model::OutTy::OutRes>(prism_rtl::deref(prism_rtl::deref(m28639_0_0)))) {
                            _v.set(fed_p8 == crate::lower::model::OutTy(crate::lower::model::OutTy::OutError{})
                                ? err_pipe(r_pa)
                                : r_pa);
                            goto _done;
                        }
                    }
                    if (prism_rtl::is<crate::lower::model::OutTy::OutRes>(t_p7)) {
                        _v.set(fed_p8 == crate::lower::model::OutTy(crate::lower::model::OutTy::OutError{})
                            ? err_pipe(r_pa)
                            : r_pa);
                        goto _done;
                    }
                    {
                        _v.set(r_pa);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                (prism_rtl::finished(std::tuple{crate::lower::node_::connect(wx2_pb, r2_p9, crate::lower::node_::Sk(crate::lower::node_::Sk::SkNode{prism_rtl::deref(er_p6).node_})), benv_p1_1}));
            });
        });
        });
    });
    });
    })
        : prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)) ? ({
        auto&& t_pc = prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)).a2;
        ({
        auto rs_pd = crate::lower::snake(pat_text(p_p3));
        auto benv_p1_1 = benv_p1;
        auto e_p4_2 = e_p4;
        auto menv_p2_3 = menv_p2;
        auto p_p3_4 = p_p3;
        auto wx_p0_5 = wx_p0;
        call_then(crate::lower::node_::dynamics::start_dynamic_expr(wx_p0_5, menv_p2_3, e_p4_2), [=, rs_pd = std::move(rs_pd), benv_p1_1 = std::move(benv_p1_1), p_p3_4 = std::move(p_p3_4)](std::tuple<crate::lower::model::Ex, Array<crate::lower::node_::Read>> dynamic_expr_28992) {
        return ({
            auto [ex_pj, reads_pk] = dynamic_expr_28992;
            auto cached_pe = (len(reads_pk) > Nat(0u)) && fold(crate::lower::node_::finish::reads_all(prism_rtl::deref(wx_p0_5).dyn_reads, reads_pk), true, [&](const bool& ok_pl, const crate::lower::node_::Read& r_pm) { return prism_rtl::deref(ok_pl) && crate::lower::node_::finish::is_own_read(r_pm); });
            auto tail_pf = std::move(cached_pe)
                ? crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(rs_pd, "_cache")})), Text::lit("get"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{}), crate::lower::model::Ex(crate::lower::model::Ex::XClosure{false, Array<crate::lower::model::Pa>{}, prism_rtl::rc(ex_pj)})})})
                : ex_pj;
            auto getter_pg = crate::lower::model::MethDef{.name = rs_pd, .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxRef{}), .ret = t_pc, .body = Array<crate::lower::model::Do>{}, .tail = tail_pf, .doc = prism_rtl::cat("`", pat_text(p_p3_4), "`")};
            auto wx1_ph = std::move(cached_pe)
                ? ({
                crate::lower::node_::Wx this_ = crate::lower::node_::add_field(wx_p0_5, prism_rtl::cat(rs_pd, "_cache"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Cache"), Array(std::vector{t_pc})}), prism_rtl::cat("`", pat_text(p_p3_4), "`, cached"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Cache::new"), Array<crate::lower::model::Ex>{}}));
                this_.let_caches = crate::prelude::push(this_.let_caches, rs_pd);
                this_.taken = crate::prelude::push(this_.taken, prism_rtl::cat(rs_pd, "_cache"));
                (std::move(this_));
            })
                : wx_p0_5;
            auto wx2_pi = ({
                crate::lower::node_::Wx this_ = wx1_ph;
                this_.getters = crate::prelude::push(this_.getters, getter_pg);
                this_.dyn_reads = insert(this_.dyn_reads, rs_pd, reads_pk);
                (std::move(this_));
            });
            all_inited(wx2_pi, reads_pk) && names_inited(benv_p1_1, e_p4_2)
            ? ({
            auto wx3_pn = ({
                crate::lower::node_::Wx this_ = wx2_pi;
                this_.lets = crate::prelude::push(this_.lets, crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{prism_rtl::cat(rs_pd, "_init")})), t_pc}), crate::lower::types::own(crate::lower::expr::value_of(lx_p5, init_env(benv_p1_1), e_p4_2))}));
                this_.inited = crate::prelude::push(this_.inited, rs_pd);
                (std::move(this_));
            });
            (prism_rtl::finished(std::tuple{wx3_pn, crate::lower::types::bind(benv_p1_1, prism_rtl::cat(pat_text(p_p3_4), "#init"), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat(rs_pd, "_init")}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), t_pc}))}));
        })
            : prism_rtl::finished(std::tuple{wx2_pi, benv_p1_1});
        });
    });
    });
    })
        : prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)) ? ({
        auto&& rs_po = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
        auto&& t_pp = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
        ({
        auto insts_oq = ({
            __label__ _done;
            prism_rtl::Slot<std::optional<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>>> _v;
            auto&& _m = prism_rtl::deref(prism_rtl::deref(p_p3).kind);
            if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
                auto&& n_pr = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
                _v.set(many_instances(lx_p5, prism_rtl::deref(n_pr).span));
                goto _done;
            }
            {
                _v.set(std::optional<Array<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, Array<std::tuple<Text, crate::check::types::Col>>>>>{});
                goto _done;
            }
        _done:
            _v.take();
        });
        ({
        prism_rtl::is_some(insts_oq) ? ({
        auto&& insts_ps = prism_rtl::some_of(insts_oq);
        ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(p_p3).kind);
        prism_rtl::is<crate::syntax::PatternKind::PName>(_m) ? ({
        auto&& n_pt = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        ({
        auto nkey_pu = crate::check::env::sname_key(n_pt);
        auto benv_p1_1 = benv_p1;
        auto e_p4_2 = e_p4;
        auto insts_ps_3 = insts_ps;
        auto menv_p2_4 = menv_p2;
        auto wx_p0_5 = wx_p0;
        call_value(fold_job(crate::check::errors::range0(len(insts_ps_3)), wx_p0_5, ({
        auto lx_p5_6 = lx_p5;
        auto insts_ps_3_7 = insts_ps_3;
        auto nkey_pu_7 = nkey_pu;
        auto menv_p2_4_8 = menv_p2_4;
        auto benv_p1_1_8 = benv_p1_1;
        auto e_p4_2_8 = e_p4_2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::node_::Wx>(std::tuple<crate::lower::node_::Wx, Nat>)>>(prism_rtl::rc([=, lx_p5_6 = std::move(lx_p5_6), insts_ps_3_7 = std::move(insts_ps_3_7), nkey_pu_7 = std::move(nkey_pu_7), menv_p2_4_8 = std::move(menv_p2_4_8), benv_p1_1_8 = std::move(benv_p1_1_8), e_p4_2_8 = std::move(e_p4_2_8)](std::tuple<crate::lower::node_::Wx, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_p5_6_8 = lx_p5_6;
            auto insts_ps_3_7_8 = insts_ps_3_7;
            auto nkey_pu_7_8 = nkey_pu_7;
            auto menv_p2_4_8_8 = menv_p2_4_8;
            auto benv_p1_1_8_8 = benv_p1_1_8;
            auto e_p4_2_8_8 = e_p4_2_8;
            entered(once_job([=, lx_p5_6_8 = std::move(lx_p5_6_8), insts_ps_3_7_8 = std::move(insts_ps_3_7_8), nkey_pu_7_8 = std::move(nkey_pu_7_8), menv_p2_4_8_8 = std::move(menv_p2_4_8_8), benv_p1_1_8_8 = std::move(benv_p1_1_8_8), e_p4_2_8_8 = std::move(e_p4_2_8_8)]() {
            return ({
                auto w_p10 = p0;
                auto k_p11 = p1;
                ({
                auto lxk_p12 = crate::lower::expr::at_instance(lx_p5_6_8, or_(index(insts_ps_3_7_8, k_p11), std::tuple{Array<std::tuple<Text, crate::check::types::Ty>>{}, Array<std::tuple<Text, crate::check::types::Col>>{}}));
                auto bkey_p13 = k_p11 == Nat(0u)
                    ? nkey_pu_7_8
                    : prism_rtl::cat(nkey_pu_7_8, "#inst", k_p11);
                ({
                auto&& _m = crate::prelude::get(menv_p2_4_8_8->names, bkey_p13);
                prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)) ? ({
                auto&& rk_p14 = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                auto&& tk_p15 = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                call_then(crate::lower::expr::start_value_of(lxk_p12, benv_p1_1_8_8, e_p4_2_8_8), [=](crate::lower::types::Vl value_of_31300) { return prism_rtl::finished(widget_let_field(w_p10, crate::lower::types::place_stem(rk_p14), tk_p15, crate::lower::types::own(value_of_31300), prism_rtl::cat("`", nkey_pu_7_8, "` at its instantiation ", k_p11))); });
            })
                : prism_rtl::finished(({
                crate::lower::node_::Wx this_ = w_p10;
                this_.build = crate::prelude::push(this_.build, crate::lower::expr::refusal_do(prism_rtl::cat("`", nkey_pu_7_8, "` at its instantiation ", k_p11, ", which has no binding")));
                (std::move(this_));
            }));
            });
            });
            });
        }));
        });
    })));
    })), [=](crate::lower::node_::Wx fold_30944) {
        return ({
            auto wxn_pv = fold_30944;
            (prism_rtl::finished(std::tuple{wxn_pv, benv_p1_1}));
        });
    });
    });
    })
        : prism_rtl::finished(std::tuple{wx_p0, benv_p1});
    });
    })
        : prism_rtl::is_none(insts_oq) ? ({
        auto lxw_p16 = ({
            __label__ _done;
            prism_rtl::Slot<crate::lower::Lx> _v;
            auto&& _m = prism_rtl::deref(prism_rtl::deref(p_p3).kind);
            if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
                auto&& n_p18 = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
                _v.set(crate::lower::expr::widget_let_lx(lx_p5, prism_rtl::deref(n_p18).span));
                goto _done;
            }
            {
                _v.set(lx_p5);
                goto _done;
            }
        _done:
            _v.take();
        });
        auto benv_p1_1 = benv_p1;
        auto e_p4_2 = e_p4;
        auto p_p3_3 = p_p3;
        auto wx_p0_4 = wx_p0;
        call_then(crate::lower::expr::start_value_of(lxw_p16, benv_p1_1, e_p4_2), [=, p_p3_3 = std::move(p_p3_3), wx_p0_4 = std::move(wx_p0_4)](crate::lower::types::Vl value_of_31820) {
        return ({
            auto v_p17 = crate::lower::types::own(value_of_31820);
            (prism_rtl::finished(std::tuple{widget_let_field(wx_p0_4, crate::lower::types::place_stem(rs_po), t_pp, v_p17, prism_rtl::cat("`", pat_text(p_p3_3), "`")), benv_p1_1}));
        });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    });
    })
        : prism_rtl::finished(std::tuple{wx_p0, benv_p1});
    });
}


/// `Start LetLine, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env>> start_let_line(crate::lower::node_::Wx wx_p0, crate::lower::types::Env benv_p1, crate::lower::types::Env menv_p2, crate::syntax::Pattern_ p_p3, crate::syntax::Expr e_p4) {
    return prism_rtl::make_rc<LetLine>(wx_p0, benv_p1, menv_p2, p_p3, e_p4);
}


/// WidgetLetField: fn Wx, Text, OutTy, Ex, Text -> Wx
crate::lower::node_::Wx widget_let_field(const crate::lower::node_::Wx& wx_p0, const Text& f_p1, const crate::lower::model::OutTy& t_p2, const crate::lower::model::Ex& v_p3, const Text& doc_p4) {
    crate::lower::node_::Wx this_ = wx_p0;
    this_.lets = crate::prelude::push(this_.lets, crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{f_p1}), v_p3}));
    this_.fields = crate::prelude::push(this_.fields, std::tuple{f_p1, t_p2, doc_p4});
    this_.inits = crate::prelude::push(this_.inits, std::tuple{f_p1, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{f_p1}))})});
    return this_;
}


/// ErrPipe: fn EvRef -> EvRef
crate::lower::node_::EvRef err_pipe(const crate::lower::node_::EvRef& r_p0) {
    return crate::lower::node_::EvRef{.node_ = r_p0.node_, .owner = r_p0.owner, .pipe = ({
        auto r_p0_1 = r_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(std::tuple<crate::lower::model::Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>>)>>(prism_rtl::rc([=, r_p0_1 = std::move(r_p0_1)](std::tuple<crate::lower::model::Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto r_p0_1_2 = r_p0_1;
            entered(once_job([=, r_p0_1_2 = std::move(r_p0_1_2)]() {
            return ({
                auto x_p1 = p0;
                auto k_f2 = p1;
                r_p0_1_2.pipe(std::tuple{x_p1, ({
                auto k_f2_2 = k_f2;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>>(prism_rtl::rc([=, k_f2_2 = std::move(k_f2_2)](crate::lower::model::Ex p0) {
                return ({
                    auto k_f2_2_3 = k_f2_2;
                    entered(once_job([=, k_f2_2_3 = std::move(k_f2_2_3)]() {
                    return ({
                        auto y_p3 = p0;
                        k_f2_2_3(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Err"), Array(std::vector{y_p3})}))->cycle();
                    });
                }));
                });
            })));
            })})->cycle();
            });
        }));
        });
    })));
    })};
}


/// OwnAs: fn OutTy, Vl -> Ex
crate::lower::model::Ex own_as(const crate::lower::model::OutTy& t_p0, const crate::lower::types::Vl& v_p1) {
    if (prism_rtl::is<crate::lower::model::OutTy::OutRes>(t_p0)) {
        return crate::lower::types::value_ty(v_p1) == crate::lower::model::OutTy(crate::lower::model::OutTy::OutError{})
            ? crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Err"), Array(std::vector{crate::lower::types::own(v_p1)})})
            : crate::lower::types::own(v_p1);
    }
    {
        return crate::lower::types::own(v_p1);
    }
}


/// BindRes: fn Wx, Env, Pattern, Wres -> Wx
crate::lower::node_::Wx bind_res(const crate::lower::node_::Wx& wx2_p0, const crate::lower::types::Env& menv_p1, const crate::syntax::Pattern_& p_p2, const crate::lower::node_::Wres& res_p3) {
    auto&& _m = binding_of(menv_p1, p_p2);
    if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(_m))) {
        auto&& er_p4 = prism_rtl::as<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(_m)).a0;
        if (prism_rtl::is<crate::lower::node_::Wres::WrEv>(res_p3)) {
            auto&& r_p5 = prism_rtl::as<crate::lower::node_::Wres::WrEv>(res_p3).a0;
            return prism_rtl::deref(er_p4).owner != wx2_p0.node_
                ? crate::lower::node_::crossed(wx2_p0, prism_rtl::cat("the bound event of node `", prism_rtl::deref(er_p4).owner, "` (its graph node ", prism_rtl::deref(er_p4).node_, ")"))
                : prism_rtl::deref(r_p5).node_ == prism_rtl::deref(er_p4).node_
                ? wx2_p0
                : crate::lower::node_::connect(wx2_p0, r_p5, crate::lower::node_::Sk(crate::lower::node_::Sk::SkNode{prism_rtl::deref(er_p4).node_}));
        }
        {
            return wx2_p0;
        }
    }
    {
        return wx2_p0;
    }
}


/// BuildLine: unbounded fn Wx, Env, Env, Expr, ?Bn -> ((Wx, Wres))
std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> build_line(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& benv_p1, const crate::lower::types::Env& menv_p2, const crate::syntax::Expr& e_p3, const std::optional<crate::lower::types::Bn>& bound_o4) {
    auto lx_p5 = wx_p0.lx;
    auto full_p6 = crate::lower::type_at(lx_p5, e_p3.span);
    auto&& _m = prism_rtl::deref(e_p3.kind);
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x_p7 = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return build_line(wx_p0, benv_p1, menv_p2, prism_rtl::deref(prism_rtl::deref(x_p7)), bound_o4);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EWidgetBlock>(_m)) {
        auto&& b_p8 = prism_rtl::as<crate::syntax::ExprKind::EWidgetBlock>(_m).a0;
        return crate::lower::node_::static_::inline_block(wx_p0, benv_p1, menv_p2, b_p8, lx_p5);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EFor>(_m)) {
        auto&& binders_o9 = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a0;
        auto&& source_pa = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a1;
        auto&& body_pb = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a2;
        return crate::lower::node_::keyed::for_line(wx_p0, benv_p1, menv_p2, binders_o9, prism_rtl::deref(prism_rtl::deref(source_pa)), body_pb, e_p3, bound_o4);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ERebuild>(_m)) {
        auto&& scrut_pc = prism_rtl::as<crate::syntax::ExprKind::ERebuild>(_m).a0;
        auto&& body_pd = prism_rtl::as<crate::syntax::ExprKind::ERebuild>(_m).a1;
        return crate::lower::node_::switch_::rebuild_line(wx_p0, benv_p1, menv_p2, prism_rtl::deref(prism_rtl::deref(scrut_pc)), body_pd, e_p3, bound_o4);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) && prism_rtl::is_some(prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2)) {
        auto&& m33597_4_0 = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
        auto&& then_b_pf = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
        auto&& else_b_pg = prism_rtl::some_of(prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2);
        if (prism_rtl::is<crate::syntax::Cond::CondExpr>(prism_rtl::deref(prism_rtl::deref(m33597_4_0)))) {
            auto&& c_pe = prism_rtl::as<crate::syntax::Cond::CondExpr>(prism_rtl::deref(prism_rtl::deref(m33597_4_0))).a0;
            return crate::lower::functions::if_gen_line(wx_p0, menv_p2, prism_rtl::deref(prism_rtl::deref(c_pe)), then_b_pf, else_b_pg, e_p3);
        }
    }
    {
        auto&& _m = crate::lower::types::peel(full_p6);
        if (prism_rtl::is<crate::check::types::Ty::TyElem>(_m)) {
            return crate::lower::node_::elements::element_line(wx_p0, benv_p1, menv_p2, e_p3, bound_o4);
        }
        if (prism_rtl::is<crate::check::types::Ty::TyAt>(_m)) {
            return crate::lower::node_::static_::widget_line(wx_p0, benv_p1, menv_p2, e_p3, bound_o4);
        }
        {
            auto wx2_ph = ({
                crate::lower::node_::Wx this_ = wx_p0;
                this_.build = crate::prelude::push(this_.build, crate::lower::expr::refusal_do(Text::lit("a building line this back end does not lower yet")));
                (std::move(this_));
            });
            return std::tuple{wx2_ph, crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{})};
        }
    }
}


prism_rtl::Turn<std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres>> BuildLine::cycle() const {
    const auto& wx_p0 = this->wx_p0;
    const auto& benv_p1 = this->benv_p1;
    const auto& menv_p2 = this->menv_p2;
    const auto& e_p3 = this->e_p3;
    const auto& bound_o4 = this->bound_o4;
    auto lx_p5 = prism_rtl::deref(wx_p0).lx;
    auto full_p6 = crate::lower::type_at(lx_p5, prism_rtl::deref(e_p3).span);
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p3).kind);
        prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
        auto&& x_p7 = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(BuildLine(wx_p0, benv_p1, menv_p2, prism_rtl::deref(prism_rtl::deref(x_p7)), bound_o4)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EWidgetBlock>(_m) ? ({
        auto&& b_p8 = prism_rtl::as<crate::syntax::ExprKind::EWidgetBlock>(_m).a0;
        prism_rtl::more(prism_rtl::rc(crate::lower::node_::static_::InlineBlock(wx_p0, benv_p1, menv_p2, b_p8, lx_p5)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EFor>(_m) ? ({
        auto&& binders_o9 = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a0;
        auto&& source_pa = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a1;
        auto&& body_pb = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a2;
        prism_rtl::more(prism_rtl::rc(crate::lower::node_::keyed::ForLine(wx_p0, benv_p1, menv_p2, binders_o9, prism_rtl::deref(prism_rtl::deref(source_pa)), body_pb, e_p3, bound_o4)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::ERebuild>(_m) ? ({
        auto&& scrut_pc = prism_rtl::as<crate::syntax::ExprKind::ERebuild>(_m).a0;
        auto&& body_pd = prism_rtl::as<crate::syntax::ExprKind::ERebuild>(_m).a1;
        prism_rtl::more(prism_rtl::rc(crate::lower::node_::switch_::RebuildLine(wx_p0, benv_p1, menv_p2, prism_rtl::deref(prism_rtl::deref(scrut_pc)), body_pd, e_p3, bound_o4)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) && prism_rtl::is_some(prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2) && ({
        auto&& m33597_4_0 = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
        auto&& then_b_pf = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
        auto&& else_b_pg = prism_rtl::some_of(prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2);
        prism_rtl::is<crate::syntax::Cond::CondExpr>(prism_rtl::deref(prism_rtl::deref(m33597_4_0)));
    }) ? ({
        auto&& m33597_4_0 = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
        auto&& then_b_pf = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
        auto&& else_b_pg = prism_rtl::some_of(prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2);
        auto&& c_pe = prism_rtl::as<crate::syntax::Cond::CondExpr>(prism_rtl::deref(prism_rtl::deref(m33597_4_0))).a0;
        prism_rtl::more(prism_rtl::rc(crate::lower::functions::IfGenLine(wx_p0, menv_p2, prism_rtl::deref(prism_rtl::deref(c_pe)), then_b_pf, else_b_pg, e_p3)));
    })
        : ({
        auto&& _m = crate::lower::types::peel(full_p6);
        prism_rtl::is<crate::check::types::Ty::TyElem>(_m) ? prism_rtl::more(prism_rtl::rc(crate::lower::node_::elements::ElementLine(wx_p0, benv_p1, menv_p2, e_p3, bound_o4)))
        : prism_rtl::is<crate::check::types::Ty::TyAt>(_m) ? prism_rtl::more(prism_rtl::rc(crate::lower::node_::static_::WidgetLine(wx_p0, benv_p1, menv_p2, e_p3, bound_o4)))
        : ({
        auto wx2_ph = ({
            crate::lower::node_::Wx this_ = wx_p0;
            this_.build = crate::prelude::push(this_.build, crate::lower::expr::refusal_do(Text::lit("a building line this back end does not lower yet")));
            (std::move(this_));
        });
        (prism_rtl::finished(std::tuple{wx2_ph, crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{})}));
    });
    });
    });
}


/// `Start BuildLine, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres>> start_build_line(crate::lower::node_::Wx wx_p0, crate::lower::types::Env benv_p1, crate::lower::types::Env menv_p2, crate::syntax::Expr e_p3, std::optional<crate::lower::types::Bn> bound_o4) {
    return prism_rtl::make_rc<BuildLine>(wx_p0, benv_p1, menv_p2, e_p3, bound_o4);
}

}  // namespace crate::lower::node_::def
