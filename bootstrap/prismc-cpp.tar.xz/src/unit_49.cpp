// The module `Lower.Patterns`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <lower/patterns/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Lower.Patterns`, from `target/bootstrap/cpp-src/prismc/lower/patterns.prism`.
namespace crate::lower::patterns {



/// PatOnly: fn Pa -> PatOut
PatOut pat_only(const crate::lower::model::Pa& pa) {
    return PatOut{.pa = pa, .conds = Array<crate::lower::model::Cc>{}, .binds = Array<std::tuple<Text, crate::lower::types::Bn>>{}};
}


/// RustPat: unbounded fn Lx, Pattern, Ty, Holding, Text -> PatOut
PatOut rust_pat(const crate::lower::Lx& lx, const crate::syntax::Pattern_& p_, const crate::check::types::Ty& ty, const crate::lower::types::Holding& mode, const Text& fresh) {
    auto&& _m = p_.kind;
    if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        auto nkey = crate::check::env::sname_key(n);
        auto [qk_opt, why] = crate::check::env::names::resolve_value(lx.g, lx.home, n);
        auto is_ctor = ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            if (prism_rtl::is_some(qk_opt)) {
                auto&& qk = prism_rtl::some_of(qk_opt);
                _v.set(crate::check::env::has_key(lx.g.ctors, qk) && ((crate::check::env::is_upper_text(crate::lower::base(nkey)) || (len(n->path_) > Nat(1u))) || is_unit_ctor(lx, qk)));
                goto _done;
            }
            if (prism_rtl::is_none(qk_opt)) {
                _v.set(false);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto tagged_opt = ({
            __label__ _done;
            prism_rtl::Slot<std::optional<crate::check::env::TagInfo>> _v;
            if (prism_rtl::is_some(qk_opt)) {
                auto&& qk = prism_rtl::some_of(qk_opt);
                _v.set(crate::prelude::get(lx.g.tags, qk));
                goto _done;
            }
            if (prism_rtl::is_none(qk_opt)) {
                _v.set(std::optional<crate::check::env::TagInfo>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        return is_ctor
            ? ctor_pat(lx, n, Array<crate::syntax::Pattern_>{}, ty, mode, fresh)
            : (why == Text::lit("tag")) && (tagged_opt != std::optional<crate::check::env::TagInfo>{})
            ? tag_pat(lx, or_(tagged_opt, dummy_tag_info()), Array<crate::syntax::FieldPat>{}, true, ty, mode, fresh)
            : ({
            auto rs = crate::lower::local_name(lx, nkey);
            auto bt = crate::lower::types::out_ty_of(lx, crate::lower::types::peel(crate::lower::binder_ty(lx, n.span)));
            PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaBind{rs}), .conds = Array<crate::lower::model::Cc>{}, .binds = Array(std::vector{std::tuple{nkey, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{rs}), mode, bt})}})};
        });
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PIgnore>(_m)) {
        return pat_only(crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}));
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PUnit>(_m)) {
        return pat_only(crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}));
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PNil>(_m)) {
        return pat_only(crate::lower::model::Pa(crate::lower::model::Pa::PaUnit{Text::lit("None")}));
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PLit>(_m)) {
        auto&& l = prism_rtl::as<crate::syntax::PatternKind::PLit>(_m).a0;
        return lit_pat(lx, l, ty, mode, fresh, false);
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PNeg>(_m)) {
        auto&& l = prism_rtl::as<crate::syntax::PatternKind::PNeg>(_m).a0;
        return lit_pat(lx, l, ty, mode, fresh, true);
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PSigil>(_m)) {
        auto&& m1652_6_0 = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a0;
        auto&& q = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a1;
        if (m1652_6_0 == Text::lit("?")) {
            return wrap_pat(lx, Text::lit("Some"), q, inner_ty(ty), mode, fresh);
        }
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PSigil>(_m)) {
        auto&& m1652_7_0 = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a0;
        auto&& q = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a1;
        if (m1652_7_0 == Text::lit("~")) {
            return wrap_pat(lx, Text::lit("Ok"), q, inner_ty(ty), mode, fresh);
        }
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PSigil>(_m)) {
        auto&& q = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a1;
        return rust_pat(lx, q, ty, mode, fresh);
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PGroup>(_m)) {
        auto&& q = prism_rtl::as<crate::syntax::PatternKind::PGroup>(_m).a0;
        return rust_pat(lx, q, ty, mode, fresh);
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PCtor>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::PatternKind::PCtor>(_m).a0;
        auto&& ps = prism_rtl::as<crate::syntax::PatternKind::PCtor>(_m).a1;
        return ctor_pat(lx, n, ps, ty, mode, fresh);
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PRecord>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::PatternKind::PRecord>(_m).a0;
        auto&& fps = prism_rtl::as<crate::syntax::PatternKind::PRecord>(_m).a1;
        auto&& rest = prism_rtl::as<crate::syntax::PatternKind::PRecord>(_m).a2;
        return record_pat(lx, n, fps, rest, ty, mode, fresh);
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PTuple>(_m)) {
        auto&& ps = prism_rtl::as<crate::syntax::PatternKind::PTuple>(_m).a0;
        auto ts = ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::check::types::Ty>> _v;
            auto&& _m = crate::lower::types::peel(ty);
            if (prism_rtl::is<crate::check::types::Ty::TyTuple>(_m)) {
                auto&& xs = prism_rtl::as<crate::check::types::Ty::TyTuple>(_m).a0;
                _v.set(xs);
                goto _done;
            }
            {
                _v.set(Array<crate::check::types::Ty>{});
                goto _done;
            }
        _done:
            _v.take();
        });
        auto subs = run_to_end(each_job(crate::check::errors::range0(len(ps)), ({
            auto lx_1 = lx;
            auto ps_2 = ps;
            auto ts_3 = ts;
            auto mode_4 = mode;
            auto fresh_5 = fresh;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<PatOut>(Nat)>>(prism_rtl::rc([=](Nat p0) {
            return ({
                auto lx_1_6 = lx_1;
                auto ps_2_6 = ps_2;
                auto ts_3_6 = ts_3;
                auto mode_4_6 = mode_4;
                auto fresh_5_6 = fresh_5;
                entered(once_job([=]() {
                return ({
                    auto i = p0;
                    (prism_rtl::more(prism_rtl::rc(RustPat(lx_1_6, or_(index(ps_2_6, i), dummy_pat()), or_(index(ts_3_6, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), mode_4_6, prism_rtl::cat(fresh_5_6, "_", i)))));
                });
            }));
            });
        })));
        })));
        return PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{each(subs, [&](const PatOut& o) { return o.pa; })}), .conds = fold(subs, Array<crate::lower::model::Cc>{}, [&](const Array<crate::lower::model::Cc>& acc, const PatOut& o) { return append(acc, o.conds); }), .binds = fold(subs, Array<std::tuple<Text, crate::lower::types::Bn>>{}, [&](const Array<std::tuple<Text, crate::lower::types::Bn>>& acc, const PatOut& o) { return append(acc, o.binds); })};
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PArray>(_m)) {
        auto&& ps = prism_rtl::as<crate::syntax::PatternKind::PArray>(_m).a0;
        return array_pat(lx, ps, ty, mode, fresh);
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PFamily>(_m)) {
        auto&& q = prism_rtl::as<crate::syntax::PatternKind::PFamily>(_m).a0;
        return family_pat(lx, q, ty, fresh);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<PatOut> RustPat::cycle() const {
    const auto& lx = this->lx;
    const auto& p_ = this->p_;
    const auto& ty = this->ty;
    const auto& mode = this->mode;
    const auto& fresh = this->fresh;
    return ({
        auto&& _m = p_.kind;
        prism_rtl::is<crate::syntax::PatternKind::PName>(_m) ? ({
        auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        ({
        auto nkey = crate::check::env::sname_key(n);
        auto [qk_opt, why] = crate::check::env::names::resolve_value(lx.g, lx.home, n);
        auto is_ctor = ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            if (prism_rtl::is_some(qk_opt)) {
                auto&& qk = prism_rtl::some_of(qk_opt);
                _v.set(crate::check::env::has_key(lx.g.ctors, qk) && ((crate::check::env::is_upper_text(crate::lower::base(nkey)) || (len(n->path_) > Nat(1u))) || is_unit_ctor(lx, qk)));
                goto _done;
            }
            if (prism_rtl::is_none(qk_opt)) {
                _v.set(false);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto tagged_opt = ({
            __label__ _done;
            prism_rtl::Slot<std::optional<crate::check::env::TagInfo>> _v;
            if (prism_rtl::is_some(qk_opt)) {
                auto&& qk = prism_rtl::some_of(qk_opt);
                _v.set(crate::prelude::get(lx.g.tags, qk));
                goto _done;
            }
            if (prism_rtl::is_none(qk_opt)) {
                _v.set(std::optional<crate::check::env::TagInfo>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        is_ctor
        ? prism_rtl::more(prism_rtl::rc(CtorPat(lx, n, Array<crate::syntax::Pattern_>{}, ty, mode, fresh)))
        : (why == Text::lit("tag")) && (tagged_opt != std::optional<crate::check::env::TagInfo>{})
        ? prism_rtl::more(prism_rtl::rc(TagPat(lx, or_(tagged_opt, dummy_tag_info()), Array<crate::syntax::FieldPat>{}, true, ty, mode, fresh)))
        : ({
        auto rs = crate::lower::local_name(lx, nkey);
        auto lx_1 = lx;
        auto mode_2 = mode;
        auto n_3 = n;
        call_then(crate::lower::types::start_out_ty_of(lx_1, crate::lower::types::peel(crate::lower::binder_ty(lx_1, n_3.span))), [=](crate::lower::model::OutTy out_ty_of_2270) {
        return ({
            auto bt = out_ty_of_2270;
            (prism_rtl::finished(PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaBind{rs}), .conds = Array<crate::lower::model::Cc>{}, .binds = Array(std::vector{std::tuple{nkey, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{rs}), mode_2, bt})}})}));
        });
    });
    });
    });
    })
        : prism_rtl::is<crate::syntax::PatternKind::PIgnore>(_m) ? prism_rtl::finished(pat_only(crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})))
        : prism_rtl::is<crate::syntax::PatternKind::PUnit>(_m) ? prism_rtl::finished(pat_only(crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})))
        : prism_rtl::is<crate::syntax::PatternKind::PNil>(_m) ? prism_rtl::finished(pat_only(crate::lower::model::Pa(crate::lower::model::Pa::PaUnit{Text::lit("None")})))
        : prism_rtl::is<crate::syntax::PatternKind::PLit>(_m) ? ({
        auto&& l = prism_rtl::as<crate::syntax::PatternKind::PLit>(_m).a0;
        prism_rtl::more(prism_rtl::rc(LitPat(lx, l, ty, mode, fresh, false)));
    })
        : prism_rtl::is<crate::syntax::PatternKind::PNeg>(_m) ? ({
        auto&& l = prism_rtl::as<crate::syntax::PatternKind::PNeg>(_m).a0;
        prism_rtl::more(prism_rtl::rc(LitPat(lx, l, ty, mode, fresh, true)));
    })
        : prism_rtl::is<crate::syntax::PatternKind::PSigil>(_m) && ({
        auto&& m1652_6_0 = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a0;
        auto&& q = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a1;
        (m1652_6_0 == Text::lit("?"));
    }) ? ({
        auto&& m1652_6_0 = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a0;
        auto&& q = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a1;
        prism_rtl::more(prism_rtl::rc(WrapPat(lx, Text::lit("Some"), q, inner_ty(ty), mode, fresh)));
    })
        : prism_rtl::is<crate::syntax::PatternKind::PSigil>(_m) && ({
        auto&& m1652_7_0 = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a0;
        auto&& q = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a1;
        (m1652_7_0 == Text::lit("~"));
    }) ? ({
        auto&& m1652_7_0 = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a0;
        auto&& q = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a1;
        prism_rtl::more(prism_rtl::rc(WrapPat(lx, Text::lit("Ok"), q, inner_ty(ty), mode, fresh)));
    })
        : prism_rtl::is<crate::syntax::PatternKind::PSigil>(_m) ? ({
        auto&& q = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a1;
        prism_rtl::more(prism_rtl::rc(RustPat(lx, q, ty, mode, fresh)));
    })
        : prism_rtl::is<crate::syntax::PatternKind::PGroup>(_m) ? ({
        auto&& q = prism_rtl::as<crate::syntax::PatternKind::PGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(RustPat(lx, q, ty, mode, fresh)));
    })
        : prism_rtl::is<crate::syntax::PatternKind::PCtor>(_m) ? ({
        auto&& n = prism_rtl::as<crate::syntax::PatternKind::PCtor>(_m).a0;
        auto&& ps = prism_rtl::as<crate::syntax::PatternKind::PCtor>(_m).a1;
        prism_rtl::more(prism_rtl::rc(CtorPat(lx, n, ps, ty, mode, fresh)));
    })
        : prism_rtl::is<crate::syntax::PatternKind::PRecord>(_m) ? ({
        auto&& n = prism_rtl::as<crate::syntax::PatternKind::PRecord>(_m).a0;
        auto&& fps = prism_rtl::as<crate::syntax::PatternKind::PRecord>(_m).a1;
        auto&& rest = prism_rtl::as<crate::syntax::PatternKind::PRecord>(_m).a2;
        prism_rtl::more(prism_rtl::rc(RecordPat(lx, n, fps, rest, ty, mode, fresh)));
    })
        : prism_rtl::is<crate::syntax::PatternKind::PTuple>(_m) ? ({
        auto&& ps = prism_rtl::as<crate::syntax::PatternKind::PTuple>(_m).a0;
        ({
        auto ts = ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::check::types::Ty>> _v;
            auto&& _m = crate::lower::types::peel(ty);
            if (prism_rtl::is<crate::check::types::Ty::TyTuple>(_m)) {
                auto&& xs = prism_rtl::as<crate::check::types::Ty::TyTuple>(_m).a0;
                _v.set(xs);
                goto _done;
            }
            {
                _v.set(Array<crate::check::types::Ty>{});
                goto _done;
            }
        _done:
            _v.take();
        });
        auto fresh_1 = fresh;
        auto lx_2 = lx;
        auto mode_3 = mode;
        auto ps_4 = ps;
        call_value(each_job(crate::check::errors::range0(len(ps_4)), ({
        auto lx_2_5 = lx_2;
        auto ps_4_5 = ps_4;
        auto ts_5 = ts;
        auto mode_3_6 = mode_3;
        auto fresh_1_6 = fresh_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<PatOut>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto lx_2_5_6 = lx_2_5;
            auto ps_4_5_6 = ps_4_5;
            auto ts_5_6 = ts_5;
            auto mode_3_6_6 = mode_3_6;
            auto fresh_1_6_6 = fresh_1_6;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                (prism_rtl::more(prism_rtl::rc(RustPat(lx_2_5_6, or_(index(ps_4_5_6, i), dummy_pat()), or_(index(ts_5_6, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), mode_3_6_6, prism_rtl::cat(fresh_1_6_6, "_", i)))));
            });
        }));
        });
    })));
    })), [=](Array<PatOut> each_3069) {
        return ({
            auto subs = each_3069;
            (prism_rtl::finished(PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{each(subs, [&](const PatOut& o) { return o.pa; })}), .conds = fold(subs, Array<crate::lower::model::Cc>{}, [&](const Array<crate::lower::model::Cc>& acc, const PatOut& o) { return append(acc, o.conds); }), .binds = fold(subs, Array<std::tuple<Text, crate::lower::types::Bn>>{}, [&](const Array<std::tuple<Text, crate::lower::types::Bn>>& acc, const PatOut& o) { return append(acc, o.binds); })}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::PatternKind::PArray>(_m) ? ({
        auto&& ps = prism_rtl::as<crate::syntax::PatternKind::PArray>(_m).a0;
        prism_rtl::more(prism_rtl::rc(ArrayPat(lx, ps, ty, mode, fresh)));
    })
        : prism_rtl::is<crate::syntax::PatternKind::PFamily>(_m) ? ({
        auto&& q = prism_rtl::as<crate::syntax::PatternKind::PFamily>(_m).a0;
        prism_rtl::more(prism_rtl::rc(FamilyPat(lx, q, ty, fresh)));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start RustPat, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<PatOut> start_rust_pat(crate::lower::Lx lx, crate::syntax::Pattern_ p_, crate::check::types::Ty ty, crate::lower::types::Holding mode, Text fresh) {
    return prism_rtl::make_rc<RustPat>(lx, p_, ty, mode, fresh);
}


/// let dummyPat
crate::syntax::Pattern_ dummy_pat() {
    return crate::syntax::Pattern_{.kind = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PIgnore{})), .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}};
}


/// InnerTy: fn Ty -> Ty
crate::check::types::Ty inner_ty(const crate::check::types::Ty& t) {
    auto&& _m = crate::lower::types::peel(t);
    if (prism_rtl::is<crate::check::types::Ty::TySig>(_m)) {
        auto&& m3528_0_0 = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a0;
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a1;
        if (m3528_0_0 == Text::lit("?")) {
            return i;
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(_m)) {
        auto&& m3528_1_0 = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a0;
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a1;
        if (m3528_1_0 == Text::lit("~")) {
            return i;
        }
    }
    {
        return crate::check::types::Ty(crate::check::types::Ty::TyErr{});
    }
}


/// IsUnitCtor: fn Lx, Text -> Bool
bool is_unit_ctor(const crate::lower::Lx& lx, const Text& qk) {
    auto&& _m = crate::prelude::get(lx.g.ctors, qk);
    if (prism_rtl::is_some(_m)) {
        auto&& c = prism_rtl::some_of(_m);
        auto&& _m = or_(crate::prelude::get(lx.g.types, c.owner), crate::check::env::names::dummy_ty_info()).body;
        if (prism_rtl::is<crate::check::env::TyBody::BChoice>(_m)) {
            auto&& m3781_0_0 = prism_rtl::as<crate::check::env::TyBody::BChoice>(_m).a0;
            if (m3781_0_0.size() == 1u) {
                {
                    auto&& _c2 = index(m3781_0_0, Nat(0u));
                    if (prism_rtl::is_some(_c2)) {
                        auto&& m3781_0_0_0_1 = std::get<1>(prism_rtl::some_of(_c2));
                        if (m3781_0_0_0_1.size() == 0u) {
                            return crate::check::env::is_lower_text(crate::check::types::bare_name(qk));
                        }
                    }
                }
            }
        }
        {
            return false;
        }
    }
    if (prism_rtl::is_none(_m)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// WrapPat: unbounded fn Lx, Text, Pattern, Ty, Holding, Text -> PatOut
PatOut wrap_pat(const crate::lower::Lx& lx, const Text& ctor, const crate::syntax::Pattern_& q, const crate::check::types::Ty& inner, const crate::lower::types::Holding& mode, const Text& fresh) {
    auto o = rust_pat(lx, q, inner, mode, fresh);
    PatOut this_ = o;
    this_.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{ctor, Array(std::vector{this_.pa})});
    return this_;
}


prism_rtl::Turn<PatOut> WrapPat::cycle() const {
    const auto& lx = this->lx;
    const auto& ctor = this->ctor;
    const auto& q = this->q;
    const auto& inner = this->inner;
    const auto& mode = this->mode;
    const auto& fresh = this->fresh;
    auto ctor_1 = ctor;
    auto fresh_2 = fresh;
    auto inner_3 = inner;
    auto lx_4 = lx;
    auto mode_5 = mode;
    auto q_6 = q;
    return call_then(start_rust_pat(lx_4, q_6, inner_3, mode_5, fresh_2), [=](PatOut rust_pat_4061) {
        return ({
            auto o = rust_pat_4061;
            (prism_rtl::finished(({
            PatOut this_ = o;
            this_.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{ctor_1, Array(std::vector{this_.pa})});
            this_;
        })));
        });
    });
}


/// `Start WrapPat, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<PatOut> start_wrap_pat(crate::lower::Lx lx, Text ctor, crate::syntax::Pattern_ q, crate::check::types::Ty inner, crate::lower::types::Holding mode, Text fresh) {
    return prism_rtl::make_rc<WrapPat>(lx, ctor, q, inner, mode, fresh);
}


/// LitPat: unbounded fn Lx, Literal, Ty, Holding, Text, Bool -> PatOut
PatOut lit_pat(const crate::lower::Lx& lx, const crate::syntax::Literal& l, const crate::check::types::Ty& ty, const crate::lower::types::Holding& mode, const Text& fresh, const bool& neg) {
    auto t = crate::lower::types::out_ty_of(lx, crate::lower::types::peel(ty));
    auto&& _m = l.kind;
    if (prism_rtl::is<crate::syntax::LitKind::LChar>(_m)) {
        auto&& c = prism_rtl::as<crate::syntax::LitKind::LChar>(_m).a0;
        return pat_only(crate::lower::model::Pa(crate::lower::model::Pa::PaChar{c}));
    }
    {
        auto lit = ({
            __label__ _done;
            prism_rtl::Slot<crate::lower::types::Vl> _v;
            auto&& _m = l.kind;
            if (prism_rtl::is<crate::syntax::LitKind::LInt>(_m)) {
                auto&& d = prism_rtl::as<crate::syntax::LitKind::LInt>(_m).a0;
                _v.set((((t == crate::lower::model::OutTy(crate::lower::model::OutTy::OutNat{})) || (t == crate::lower::model::OutTy(crate::lower::model::OutTy::OutInt{}))) || (t == crate::lower::model::OutTy(crate::lower::model::OutTy::OutU8{}))) || (t == crate::lower::model::OutTy(crate::lower::model::OutTy::OutFloat{}))
                    ? crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::expr::number(t, d, neg), t})
                    : crate::lower::expr::literal_value(lx, crate::lower::types::empty_env(), l, l.span, neg));
                goto _done;
            }
            {
                _v.set(crate::lower::expr::literal_value(lx, crate::lower::types::empty_env(), l, l.span, neg));
                goto _done;
            }
        _done:
            _v.take();
        });
        auto lv = crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::types::own(lit), t});
        auto b = crate::lower::types::local_place(crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh}), mode, t);
        return PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaBind{fresh}), .conds = Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::model::Ex(crate::lower::model::Ex::XBin{Text::lit("=="), prism_rtl::rc(crate::lower::types::ref_(b)), prism_rtl::rc(crate::lower::types::ref_(lv))})})}), .binds = Array<std::tuple<Text, crate::lower::types::Bn>>{}};
    }
}


prism_rtl::Turn<PatOut> LitPat::cycle() const {
    const auto& lx = this->lx;
    const auto& l = this->l;
    const auto& ty = this->ty;
    const auto& mode = this->mode;
    const auto& fresh = this->fresh;
    const auto& neg = this->neg;
    auto fresh_1 = fresh;
    auto l_2 = l;
    auto lx_3 = lx;
    auto mode_4 = mode;
    auto neg_5 = neg;
    auto ty_6 = ty;
    return call_then(crate::lower::types::start_out_ty_of(lx_3, crate::lower::types::peel(ty_6)), [=](crate::lower::model::OutTy out_ty_of_4373) {
        return ({
            auto t = out_ty_of_4373;
            ({
            auto&& _m = l_2.kind;
            prism_rtl::is<crate::syntax::LitKind::LChar>(_m) ? ({
            auto&& c = prism_rtl::as<crate::syntax::LitKind::LChar>(_m).a0;
            prism_rtl::finished(pat_only(crate::lower::model::Pa(crate::lower::model::Pa::PaChar{c})));
        })
            : ({
            auto lit = ({
                __label__ _done;
                prism_rtl::Slot<crate::lower::types::Vl> _v;
                auto&& _m = l_2.kind;
                if (prism_rtl::is<crate::syntax::LitKind::LInt>(_m)) {
                    auto&& d = prism_rtl::as<crate::syntax::LitKind::LInt>(_m).a0;
                    _v.set((((t == crate::lower::model::OutTy(crate::lower::model::OutTy::OutNat{})) || (t == crate::lower::model::OutTy(crate::lower::model::OutTy::OutInt{}))) || (t == crate::lower::model::OutTy(crate::lower::model::OutTy::OutU8{}))) || (t == crate::lower::model::OutTy(crate::lower::model::OutTy::OutFloat{}))
                        ? crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::expr::number(t, d, neg_5), t})
                        : crate::lower::expr::literal_value(lx_3, crate::lower::types::empty_env(), l_2, l_2.span, neg_5));
                    goto _done;
                }
                {
                    _v.set(crate::lower::expr::literal_value(lx_3, crate::lower::types::empty_env(), l_2, l_2.span, neg_5));
                    goto _done;
                }
            _done:
                _v.take();
            });
            auto lv = crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::types::own(lit), t});
            auto b = crate::lower::types::local_place(crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh_1}), mode_4, t);
            (prism_rtl::finished(PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaBind{fresh_1}), .conds = Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::model::Ex(crate::lower::model::Ex::XBin{Text::lit("=="), prism_rtl::rc(crate::lower::types::ref_(b)), prism_rtl::rc(crate::lower::types::ref_(lv))})})}), .binds = Array<std::tuple<Text, crate::lower::types::Bn>>{}}));
        });
        });
        });
    });
}


/// `Start LitPat, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<PatOut> start_lit_pat(crate::lower::Lx lx, crate::syntax::Literal l, crate::check::types::Ty ty, crate::lower::types::Holding mode, Text fresh, bool neg) {
    return prism_rtl::make_rc<LitPat>(lx, l, ty, mode, fresh, neg);
}


/// CtorPat: unbounded fn Lx, SName, [Pattern], Ty, Holding, Text -> PatOut
PatOut ctor_pat(const crate::lower::Lx& lx, const crate::syntax::SName& n, const Array<crate::syntax::Pattern_>& ps, const crate::check::types::Ty& ty, const crate::lower::types::Holding& mode, const Text& fresh) {
    auto&& _qk_opt = crate::check::env::names::resolve_value(lx.g, lx.home, n);
    auto&& qk_opt = std::get<0>(_qk_opt);
    if (prism_rtl::is_some(qk_opt)) {
        auto&& m5416_0 = prism_rtl::some_of(qk_opt);
        if (m5416_0 == Text::lit("True")) {
            return pat_only(crate::lower::model::Pa(crate::lower::model::Pa::PaBool{true}));
        }
    }
    if (prism_rtl::is_some(qk_opt)) {
        auto&& m5416_1 = prism_rtl::some_of(qk_opt);
        if (m5416_1 == Text::lit("False")) {
            return pat_only(crate::lower::model::Pa(crate::lower::model::Pa::PaBool{false}));
        }
    }
    if (prism_rtl::is_some(qk_opt)) {
        auto&& qk = prism_rtl::some_of(qk_opt);
        auto&& _m = crate::prelude::get(lx.g.ctors, qk);
        if (prism_rtl::is_some(_m)) {
            auto&& c = prism_rtl::some_of(_m);
            auto owner = or_(crate::prelude::get(lx.g.types, c.owner), crate::check::env::names::dummy_ty_info());
            auto ty_path = crate::lower::path_in(lx, owner.home, crate::lower::camel(crate::check::types::bare_name(c.owner)));
            auto args = ({
                __label__ _done;
                prism_rtl::Slot<Array<crate::check::types::Ty>> _v;
                auto&& _m = crate::lower::types::peel(ty);
                if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
                    auto&& xs = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a1;
                    _v.set(xs);
                    goto _done;
                }
                {
                    _v.set(Array<crate::check::types::Ty>{});
                    goto _done;
                }
            _done:
                _v.take();
            });
            auto subs = run_to_end(each_job(crate::check::errors::range0(len(ps)), ({
                auto lx_1 = lx;
                auto c_2 = c;
                auto ps_3 = ps;
                auto args_4 = args;
                auto mode_5 = mode;
                auto fresh_6 = fresh;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<PatOut>(Nat)>>(prism_rtl::rc([=](Nat p0) {
                return ({
                    auto lx_1_7 = lx_1;
                    auto c_2_7 = c_2;
                    auto ps_3_7 = ps_3;
                    auto args_4_7 = args_4;
                    auto mode_5_7 = mode_5;
                    auto fresh_6_7 = fresh_6;
                    entered(once_job([=]() {
                    return ({
                        auto i = p0;
                        call_then(crate::lower::expr::start_instantiated(or_(index(c_2_7->args, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), c_2_7.params, args_4_7), [=](crate::check::types::Ty instantiated_5920) { return prism_rtl::more(prism_rtl::rc(SubPat(lx_1_7, c_2_7, i, or_(index(ps_3_7, i), dummy_pat()), instantiated_5920, mode_5_7, prism_rtl::cat(fresh_6_7, "_", i)))); });
                    });
                }));
                });
            })));
            })));
            auto conds = fold(subs, Array<crate::lower::model::Cc>{}, [&](const Array<crate::lower::model::Cc>& acc, const PatOut& o) { return append(acc, o.conds); });
            auto binds = fold(subs, Array<std::tuple<Text, crate::lower::types::Bn>>{}, [&](const Array<std::tuple<Text, crate::lower::types::Bn>>& acc, const PatOut& o) { return append(acc, o.binds); });
            auto pas = each(subs, [&](const PatOut& o) { return o.pa; });
            auto&& _m = owner.body;
            if (prism_rtl::is<crate::check::env::TyBody::BRecord>(_m)) {
                auto&& fs = prism_rtl::as<crate::check::env::TyBody::BRecord>(_m).a0;
                return PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaRecord{ty_path, each(crate::check::errors::range0(len(pas)), [&](const Nat& i) { return std::tuple{crate::lower::snake(or_(index(c.fields, i), Text::lit(""))), or_(index(pas, i), crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}))}; }), len(pas) < len(c.fields)}), .conds = conds, .binds = binds};
            }
            {
                auto is_unit_type = (len(c->args) == Nat(0u)) && is_unit_ctor(lx, qk);
                auto is_newtype = (crate::check::types::bare_name(c.name) == crate::check::types::bare_name(c.owner)) && ({
                    __label__ _done;
                    prism_rtl::Slot<bool> _v;
                    auto&& _m = owner.body;
                    if (prism_rtl::is<crate::check::env::TyBody::BChoice>(_m)) {
                        auto&& cases = prism_rtl::as<crate::check::env::TyBody::BChoice>(_m).a0;
                        _v.set(len(cases) == Nat(1u));
                        goto _done;
                    }
                    {
                        _v.set(false);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                auto path_ = is_unit_type || is_newtype
                    ? ty_path
                    : prism_rtl::cat(ty_path, "::", crate::lower::camel(crate::check::types::bare_name(c.name)));
                return len(c->args) == Nat(0u)
                    ? PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaUnit{path_}), .conds = Array<crate::lower::model::Cc>{}, .binds = Array<std::tuple<Text, crate::lower::types::Bn>>{}}
                    : PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{path_, pas}), .conds = conds, .binds = binds};
            }
        }
        if (prism_rtl::is_none(_m)) {
            return PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds = Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::expr::refusal(prism_rtl::cat("a pattern of ", qk))})}), .binds = Array<std::tuple<Text, crate::lower::types::Bn>>{}};
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is_none(qk_opt)) {
        return PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds = Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::expr::refusal(Text::lit("a pattern of an unknown constructor"))})}), .binds = Array<std::tuple<Text, crate::lower::types::Bn>>{}};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<PatOut> CtorPat::cycle() const {
    const auto& lx = this->lx;
    const auto& n = this->n;
    const auto& ps = this->ps;
    const auto& ty = this->ty;
    const auto& mode = this->mode;
    const auto& fresh = this->fresh;
    auto&& _qk_opt = crate::check::env::names::resolve_value(lx.g, lx.home, n);
    auto&& qk_opt = std::get<0>(_qk_opt);
    return ({
        prism_rtl::is_some(qk_opt) && ({
        auto&& m5416_0 = prism_rtl::some_of(qk_opt);
        (m5416_0 == Text::lit("True"));
    }) ? ({
        auto&& m5416_0 = prism_rtl::some_of(qk_opt);
        prism_rtl::finished(pat_only(crate::lower::model::Pa(crate::lower::model::Pa::PaBool{true})));
    })
        : prism_rtl::is_some(qk_opt) && ({
        auto&& m5416_1 = prism_rtl::some_of(qk_opt);
        (m5416_1 == Text::lit("False"));
    }) ? ({
        auto&& m5416_1 = prism_rtl::some_of(qk_opt);
        prism_rtl::finished(pat_only(crate::lower::model::Pa(crate::lower::model::Pa::PaBool{false})));
    })
        : prism_rtl::is_some(qk_opt) ? ({
        auto&& qk = prism_rtl::some_of(qk_opt);
        ({
        auto&& _m = crate::prelude::get(lx.g.ctors, qk);
        prism_rtl::is_some(_m) ? ({
        auto&& c = prism_rtl::some_of(_m);
        ({
        auto owner = or_(crate::prelude::get(lx.g.types, c.owner), crate::check::env::names::dummy_ty_info());
        auto ty_path = crate::lower::path_in(lx, owner.home, crate::lower::camel(crate::check::types::bare_name(c.owner)));
        auto args = ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::check::types::Ty>> _v;
            auto&& _m = crate::lower::types::peel(ty);
            if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
                auto&& xs = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a1;
                _v.set(xs);
                goto _done;
            }
            {
                _v.set(Array<crate::check::types::Ty>{});
                goto _done;
            }
        _done:
            _v.take();
        });
        auto fresh_1 = fresh;
        auto lx_2 = lx;
        auto mode_3 = mode;
        auto ps_4 = ps;
        auto qk_5 = qk;
        call_value(each_job(crate::check::errors::range0(len(ps_4)), ({
        auto lx_2_6 = lx_2;
        auto c_6 = c;
        auto ps_4_7 = ps_4;
        auto args_7 = args;
        auto mode_3_8 = mode_3;
        auto fresh_1_8 = fresh_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<PatOut>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto lx_2_6_8 = lx_2_6;
            auto c_6_8 = c_6;
            auto ps_4_7_8 = ps_4_7;
            auto args_7_8 = args_7;
            auto mode_3_8_8 = mode_3_8;
            auto fresh_1_8_8 = fresh_1_8;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                call_then(crate::lower::expr::start_instantiated(or_(index(c_6_8->args, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), c_6_8.params, args_7_8), [=](crate::check::types::Ty instantiated_5920) { return prism_rtl::more(prism_rtl::rc(SubPat(lx_2_6_8, c_6_8, i, or_(index(ps_4_7_8, i), dummy_pat()), instantiated_5920, mode_3_8_8, prism_rtl::cat(fresh_1_8_8, "_", i)))); });
            });
        }));
        });
    })));
    })), [=](Array<PatOut> each_5851) {
        return ({
            auto subs = each_5851;
            auto conds = fold(subs, Array<crate::lower::model::Cc>{}, [&](const Array<crate::lower::model::Cc>& acc, const PatOut& o) { return append(acc, o.conds); });
            auto binds = fold(subs, Array<std::tuple<Text, crate::lower::types::Bn>>{}, [&](const Array<std::tuple<Text, crate::lower::types::Bn>>& acc, const PatOut& o) { return append(acc, o.binds); });
            auto pas = each(subs, [&](const PatOut& o) { return o.pa; });
            ({
            auto&& _m = owner.body;
            prism_rtl::is<crate::check::env::TyBody::BRecord>(_m) ? ({
            auto&& fs = prism_rtl::as<crate::check::env::TyBody::BRecord>(_m).a0;
            prism_rtl::finished(PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaRecord{ty_path, each(crate::check::errors::range0(len(pas)), [&](const Nat& i) { return std::tuple{crate::lower::snake(or_(index(c.fields, i), Text::lit(""))), or_(index(pas, i), crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}))}; }), len(pas) < len(c.fields)}), .conds = conds, .binds = binds});
        })
            : ({
            auto is_unit_type = (len(c->args) == Nat(0u)) && is_unit_ctor(lx_2, qk_5);
            auto is_newtype = (crate::check::types::bare_name(c.name) == crate::check::types::bare_name(c.owner)) && ({
                __label__ _done;
                prism_rtl::Slot<bool> _v;
                auto&& _m = owner.body;
                if (prism_rtl::is<crate::check::env::TyBody::BChoice>(_m)) {
                    auto&& cases = prism_rtl::as<crate::check::env::TyBody::BChoice>(_m).a0;
                    _v.set(len(cases) == Nat(1u));
                    goto _done;
                }
                {
                    _v.set(false);
                    goto _done;
                }
            _done:
                _v.take();
            });
            auto path_ = is_unit_type || is_newtype
                ? ty_path
                : prism_rtl::cat(ty_path, "::", crate::lower::camel(crate::check::types::bare_name(c.name)));
            len(c->args) == Nat(0u)
            ? prism_rtl::finished(PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaUnit{path_}), .conds = Array<crate::lower::model::Cc>{}, .binds = Array<std::tuple<Text, crate::lower::types::Bn>>{}})
            : prism_rtl::finished(PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{path_, pas}), .conds = conds, .binds = binds});
        });
        });
        });
    });
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds = Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::expr::refusal(prism_rtl::cat("a pattern of ", qk))})}), .binds = Array<std::tuple<Text, crate::lower::types::Bn>>{}})
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : prism_rtl::is_none(qk_opt) ? prism_rtl::finished(PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds = Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::expr::refusal(Text::lit("a pattern of an unknown constructor"))})}), .binds = Array<std::tuple<Text, crate::lower::types::Bn>>{}})
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CtorPat, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<PatOut> start_ctor_pat(crate::lower::Lx lx, crate::syntax::SName n, Array<crate::syntax::Pattern_> ps, crate::check::types::Ty ty, crate::lower::types::Holding mode, Text fresh) {
    return prism_rtl::make_rc<CtorPat>(lx, n, ps, ty, mode, fresh);
}


/// SubPat: unbounded fn Lx, CtorInfo, Nat, Pattern, Ty, Holding, Text -> PatOut
PatOut sub_pat(const crate::lower::Lx& lx, const crate::check::env::CtorInfo& c, const Nat& i, const crate::syntax::Pattern_& p_, const crate::check::types::Ty& ty, const crate::lower::types::Holding& mode, const Text& fresh) {
    return !crate::lower::types::rc_field(lx, c.name, i)
        ? rust_pat(lx, p_, ty, mode, fresh)
        : ({
        auto rc_mode = mode == crate::lower::types::Holding(crate::lower::types::Holding::Owned{})
            ? crate::lower::types::Holding(crate::lower::types::Holding::RcOwned{})
            : crate::lower::types::Holding(crate::lower::types::Holding::RcRef{});
        ({
        __label__ _done;
        prism_rtl::Slot<PatOut> _v;
        auto&& _m = p_.kind;
        if (prism_rtl::is<crate::syntax::PatternKind::PIgnore>(_m)) {
            _v.set(pat_only(crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
            auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
            _v.set(({
                auto o = rust_pat(lx, p_, ty, rc_mode, fresh);
                ({
                __label__ _done;
                prism_rtl::Slot<PatOut> _v;
                auto&& _m = o.pa;
                if (prism_rtl::is<crate::lower::model::Pa::PaBind>(_m)) {
                    _v.set(o);
                    goto _done;
                }
                {
                    _v.set(behind_rc(lx, p_, ty, rc_mode, fresh));
                    goto _done;
                }
            _done:
                _v.take();
            });
            }));
            goto _done;
        }
        {
            _v.set(behind_rc(lx, p_, ty, rc_mode, fresh));
            goto _done;
        }
    _done:
        _v.take();
    });
    });
}


prism_rtl::Turn<PatOut> SubPat::cycle() const {
    const auto& lx = this->lx;
    const auto& c = this->c;
    const auto& i = this->i;
    const auto& p_ = this->p_;
    const auto& ty = this->ty;
    const auto& mode = this->mode;
    const auto& fresh = this->fresh;
    return !crate::lower::types::rc_field(lx, c.name, i)
        ? prism_rtl::more(prism_rtl::rc(RustPat(lx, p_, ty, mode, fresh)))
        : ({
        auto rc_mode = mode == crate::lower::types::Holding(crate::lower::types::Holding::Owned{})
            ? crate::lower::types::Holding(crate::lower::types::Holding::RcOwned{})
            : crate::lower::types::Holding(crate::lower::types::Holding::RcRef{});
        ({
        auto&& _m = p_.kind;
        prism_rtl::is<crate::syntax::PatternKind::PIgnore>(_m) ? prism_rtl::finished(pat_only(crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})))
        : prism_rtl::is<crate::syntax::PatternKind::PName>(_m) ? ({
        auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        ({
        auto fresh_1 = fresh;
        auto lx_2 = lx;
        auto p__3 = p_;
        auto ty_4 = ty;
        call_then(start_rust_pat(lx_2, p__3, ty_4, rc_mode, fresh_1), [=](PatOut rust_pat_7814) {
        return ({
            auto o = rust_pat_7814;
            ({
            auto&& _m = o.pa;
            prism_rtl::is<crate::lower::model::Pa::PaBind>(_m) ? prism_rtl::finished(o)
            : prism_rtl::more(prism_rtl::rc(BehindRc(lx_2, p__3, ty_4, rc_mode, fresh_1)));
        });
        });
    });
    });
    })
        : prism_rtl::more(prism_rtl::rc(BehindRc(lx, p_, ty, rc_mode, fresh)));
    });
    });
}


/// `Start SubPat, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<PatOut> start_sub_pat(crate::lower::Lx lx, crate::check::env::CtorInfo c, Nat i, crate::syntax::Pattern_ p_, crate::check::types::Ty ty, crate::lower::types::Holding mode, Text fresh) {
    return prism_rtl::make_rc<SubPat>(lx, c, i, p_, ty, mode, fresh);
}


/// BehindRc: unbounded fn Lx, Pattern, Ty, Holding, Text -> PatOut
PatOut behind_rc(const crate::lower::Lx& lx, const crate::syntax::Pattern_& p_, const crate::check::types::Ty& ty, const crate::lower::types::Holding& rc_mode, const Text& fresh) {
    auto inner = rust_pat(lx, p_, ty, crate::lower::types::Holding(crate::lower::types::Holding::ByRef{}), prism_rtl::cat(fresh, "_r"));
    auto place_ = crate::lower::types::ref_(crate::lower::types::local_place(crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh}), rc_mode, crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnknown{Text::lit("a payload")})));
    return PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaBind{fresh}), .conds = append(Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcLet{inner.pa, place_})}), inner.conds), .binds = inner.binds};
}


prism_rtl::Turn<PatOut> BehindRc::cycle() const {
    const auto& lx = this->lx;
    const auto& p_ = this->p_;
    const auto& ty = this->ty;
    const auto& rc_mode = this->rc_mode;
    const auto& fresh = this->fresh;
    auto fresh_1 = fresh;
    auto lx_2 = lx;
    auto p__3 = p_;
    auto rc_mode_4 = rc_mode;
    auto ty_5 = ty;
    return call_then(start_rust_pat(lx_2, p__3, ty_5, crate::lower::types::Holding(crate::lower::types::Holding::ByRef{}), prism_rtl::cat(fresh_1, "_r")), [=](PatOut rust_pat_8153) {
        return ({
            auto inner = rust_pat_8153;
            auto place_ = crate::lower::types::ref_(crate::lower::types::local_place(crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh_1}), rc_mode_4, crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnknown{Text::lit("a payload")})));
            (prism_rtl::finished(PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaBind{fresh_1}), .conds = append(Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcLet{inner.pa, place_})}), inner.conds), .binds = inner.binds}));
        });
    });
}


/// `Start BehindRc, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<PatOut> start_behind_rc(crate::lower::Lx lx, crate::syntax::Pattern_ p_, crate::check::types::Ty ty, crate::lower::types::Holding rc_mode, Text fresh) {
    return prism_rtl::make_rc<BehindRc>(lx, p_, ty, rc_mode, fresh);
}


/// RecordPat: unbounded fn Lx, SName, [FieldPat], Bool, Ty, Holding, Text -> PatOut
PatOut record_pat(const crate::lower::Lx& lx, const crate::syntax::SName& n, const Array<crate::syntax::FieldPat>& fps, const bool& rest, const crate::check::types::Ty& ty, const crate::lower::types::Holding& mode, const Text& fresh) {
    auto [qk_opt, why] = crate::check::env::names::resolve_value(lx.g, lx.home, n);
    auto qk = or_(qk_opt, Text::lit(""));
    return qk == Text::lit("Prelude.Error")
        ? error_pat(lx, fps, ty, mode, fresh)
        : (why == Text::lit("tag")) && crate::check::env::has_key(lx.g.tags, qk)
        ? tag_pat(lx, or_(crate::prelude::get(lx.g.tags, qk), dummy_tag_info()), fps, rest, ty, mode, fresh)
        : ({
        __label__ _done;
        prism_rtl::Slot<PatOut> _v;
        auto&& _m = crate::prelude::get(lx.g.ctors, qk);
        if (prism_rtl::is_some(_m)) {
            auto&& c = prism_rtl::some_of(_m);
            _v.set(({
                auto owner = or_(crate::prelude::get(lx.g.types, c.owner), crate::check::env::names::dummy_ty_info());
                auto ty_path = crate::lower::path_in(lx, owner.home, crate::lower::camel(crate::check::types::bare_name(c.owner)));
                ({
                __label__ _done;
                prism_rtl::Slot<PatOut> _v;
                auto&& _m = owner.body;
                if (prism_rtl::is<crate::check::env::TyBody::BChoice>(_m)) {
                    auto&& cases = prism_rtl::as<crate::check::env::TyBody::BChoice>(_m).a0;
                    if (len(fps) == Nat(0u)) {
                        _v.set(rest_case_pat(c, cases, ty_path));
                        goto _done;
                    }
                }
                {
                    _v.set(fields_pat(lx, c, fps, rest, ty, mode, fresh, ty_path));
                    goto _done;
                }
            _done:
                _v.take();
            });
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<PatOut> _v;
                auto&& _m = crate::prelude::get(lx.g.tags, qk);
                if (prism_rtl::is_some(_m)) {
                    auto&& tg = prism_rtl::some_of(_m);
                    _v.set(tag_pat(lx, tg, fps, rest, ty, mode, fresh));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds = Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::expr::refusal(prism_rtl::cat("a pattern of ", qk))})}), .binds = Array<std::tuple<Text, crate::lower::types::Bn>>{}});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<PatOut> RecordPat::cycle() const {
    const auto& lx = this->lx;
    const auto& n = this->n;
    const auto& fps = this->fps;
    const auto& rest = this->rest;
    const auto& ty = this->ty;
    const auto& mode = this->mode;
    const auto& fresh = this->fresh;
    auto [qk_opt, why] = crate::check::env::names::resolve_value(lx.g, lx.home, n);
    auto qk = or_(qk_opt, Text::lit(""));
    return qk == Text::lit("Prelude.Error")
        ? prism_rtl::more(prism_rtl::rc(ErrorPat(lx, fps, ty, mode, fresh)))
        : (why == Text::lit("tag")) && crate::check::env::has_key(lx.g.tags, qk)
        ? prism_rtl::more(prism_rtl::rc(TagPat(lx, or_(crate::prelude::get(lx.g.tags, qk), dummy_tag_info()), fps, rest, ty, mode, fresh)))
        : ({
        auto&& _m = crate::prelude::get(lx.g.ctors, qk);
        prism_rtl::is_some(_m) ? ({
        auto&& c = prism_rtl::some_of(_m);
        ({
        auto owner = or_(crate::prelude::get(lx.g.types, c.owner), crate::check::env::names::dummy_ty_info());
        auto ty_path = crate::lower::path_in(lx, owner.home, crate::lower::camel(crate::check::types::bare_name(c.owner)));
        ({
        auto&& _m = owner.body;
        prism_rtl::is<crate::check::env::TyBody::BChoice>(_m) && ({
        auto&& cases = prism_rtl::as<crate::check::env::TyBody::BChoice>(_m).a0;
        (len(fps) == Nat(0u));
    }) ? ({
        auto&& cases = prism_rtl::as<crate::check::env::TyBody::BChoice>(_m).a0;
        prism_rtl::finished(rest_case_pat(c, cases, ty_path));
    })
        : prism_rtl::more(prism_rtl::rc(FieldsPat(lx, c, fps, rest, ty, mode, fresh, ty_path)));
    });
    });
    })
        : prism_rtl::is_none(_m) ? ({
        auto&& _m = crate::prelude::get(lx.g.tags, qk);
        prism_rtl::is_some(_m) ? ({
        auto&& tg = prism_rtl::some_of(_m);
        prism_rtl::more(prism_rtl::rc(TagPat(lx, tg, fps, rest, ty, mode, fresh)));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds = Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::expr::refusal(prism_rtl::cat("a pattern of ", qk))})}), .binds = Array<std::tuple<Text, crate::lower::types::Bn>>{}})
        : throw prism_rtl::Panic("no arm matched");
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start RecordPat, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<PatOut> start_record_pat(crate::lower::Lx lx, crate::syntax::SName n, Array<crate::syntax::FieldPat> fps, bool rest, crate::check::types::Ty ty, crate::lower::types::Holding mode, Text fresh) {
    return prism_rtl::make_rc<RecordPat>(lx, n, fps, rest, ty, mode, fresh);
}


/// RestCasePat: fn CtorInfo, [((Text, [Ty]))], Text -> PatOut
PatOut rest_case_pat(const crate::check::env::CtorInfo& c, const Array<std::tuple<Text, Array<crate::check::types::Ty>>>& cases, const Text& ty_path) {
    auto is_newtype = (len(cases) == Nat(1u)) && (crate::check::types::bare_name(c.name) == crate::check::types::bare_name(c.owner));
    auto path_ = is_newtype
        ? ty_path
        : prism_rtl::cat(ty_path, "::", crate::lower::camel(crate::check::types::bare_name(c.name)));
    return len(c->args) == Nat(0u)
        ? PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaUnit{path_}), .conds = Array<crate::lower::model::Cc>{}, .binds = Array<std::tuple<Text, crate::lower::types::Bn>>{}}
        : PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{path_, each(c->args, [&](const crate::check::types::Ty& _p0) { return crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}); })}), .conds = Array<crate::lower::model::Cc>{}, .binds = Array<std::tuple<Text, crate::lower::types::Bn>>{}};
}


/// FieldsPat: unbounded fn Lx, CtorInfo, [FieldPat], Bool, Ty, Holding, Text, Text -> PatOut
PatOut fields_pat(const crate::lower::Lx& lx, const crate::check::env::CtorInfo& c, const Array<crate::syntax::FieldPat>& fps, const bool& rest, const crate::check::types::Ty& ty, const crate::lower::types::Holding& mode, const Text& fresh, const Text& ty_path) {
    auto args = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::check::types::Ty>> _v;
        auto&& _m = crate::lower::types::peel(ty);
        if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
            auto&& xs = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a1;
            _v.set(xs);
            goto _done;
        }
        {
            _v.set(Array<crate::check::types::Ty>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto subs = run_to_end(each_job(crate::check::errors::range0(len(fps)), ({
        auto fps_1 = fps;
        auto c_2 = c;
        auto lx_3 = lx;
        auto args_4 = args;
        auto mode_5 = mode;
        auto fresh_6 = fresh;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, PatOut>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto fps_1_7 = fps_1;
            auto c_2_7 = c_2;
            auto lx_3_7 = lx_3;
            auto args_4_7 = args_4;
            auto mode_5_7 = mode_5;
            auto fresh_6_7 = fresh_6;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                ({
                auto fp = or_(index(fps_1_7, i), dummy_field_pat());
                auto fname = ({
                    __label__ _done;
                    prism_rtl::Slot<Text> _v;
                    auto&& _m = fp.name;
                    if (prism_rtl::is_some(_m)) {
                        auto&& id = prism_rtl::some_of(_m);
                        _v.set(id.name);
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(or_(index(c_2_7.fields, i), Text::lit("")));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                auto fix = fold(crate::check::errors::range0(len(c_2_7.fields)), i, [&](const Nat& found, const Nat& j) { return or_(index(c_2_7.fields, j), Text::lit("")) == fname ? j : found; });
                call_then(crate::lower::expr::start_instantiated(or_(index(c_2_7->args, fix), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), c_2_7.params, args_4_7), [=](crate::check::types::Ty instantiated_10660) { return call_then(start_sub_pat(lx_3_7, c_2_7, fix, fp.pattern, instantiated_10660, mode_5_7, prism_rtl::cat(fresh_6_7, "_", i)), [=](PatOut sub_pat_10628) { return prism_rtl::finished(std::tuple{crate::lower::snake(fname), sub_pat_10628}); }); });
            });
            });
        }));
        });
    }));
    })));
    auto conds = fold(subs, Array<crate::lower::model::Cc>{}, [&](const Array<crate::lower::model::Cc>& acc, const std::tuple<Text, PatOut>& _p1) {
        auto&& o = std::get<1>(_p1);
        return append(acc, o.conds);
    });
    auto binds = fold(subs, Array<std::tuple<Text, crate::lower::types::Bn>>{}, [&](const Array<std::tuple<Text, crate::lower::types::Bn>>& acc, const std::tuple<Text, PatOut>& _p1) {
        auto&& o = std::get<1>(_p1);
        return append(acc, o.binds);
    });
    return PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaRecord{ty_path, each(subs, [&](const std::tuple<Text, PatOut>& _p0) {
        auto&& f = std::get<0>(_p0);
        auto&& o = std::get<1>(_p0);
        return std::tuple{f, o.pa};
    }), rest || (len(subs) < len(c.fields))}), .conds = conds, .binds = binds};
}


prism_rtl::Turn<PatOut> FieldsPat::cycle() const {
    const auto& lx = this->lx;
    const auto& c = this->c;
    const auto& fps = this->fps;
    const auto& rest = this->rest;
    const auto& ty = this->ty;
    const auto& mode = this->mode;
    const auto& fresh = this->fresh;
    const auto& ty_path = this->ty_path;
    auto args = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::check::types::Ty>> _v;
        auto&& _m = crate::lower::types::peel(ty);
        if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
            auto&& xs = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a1;
            _v.set(xs);
            goto _done;
        }
        {
            _v.set(Array<crate::check::types::Ty>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto c_1 = c;
    auto fps_2 = fps;
    auto fresh_3 = fresh;
    auto lx_4 = lx;
    auto mode_5 = mode;
    auto rest_6 = rest;
    auto ty_path_7 = ty_path;
    return call_value(each_job(crate::check::errors::range0(len(fps_2)), ({
        auto fps_2_8 = fps_2;
        auto c_1_8 = c_1;
        auto lx_4_8 = lx_4;
        auto args_8 = args;
        auto mode_5_9 = mode_5;
        auto fresh_3_9 = fresh_3;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, PatOut>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto fps_2_8_9 = fps_2_8;
            auto c_1_8_9 = c_1_8;
            auto lx_4_8_9 = lx_4_8;
            auto args_8_9 = args_8;
            auto mode_5_9_9 = mode_5_9;
            auto fresh_3_9_9 = fresh_3_9;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                ({
                auto fp = or_(index(fps_2_8_9, i), dummy_field_pat());
                auto fname = ({
                    __label__ _done;
                    prism_rtl::Slot<Text> _v;
                    auto&& _m = fp.name;
                    if (prism_rtl::is_some(_m)) {
                        auto&& id = prism_rtl::some_of(_m);
                        _v.set(id.name);
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(or_(index(c_1_8_9.fields, i), Text::lit("")));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                auto fix = fold(crate::check::errors::range0(len(c_1_8_9.fields)), i, [&](const Nat& found, const Nat& j) { return or_(index(c_1_8_9.fields, j), Text::lit("")) == fname ? j : found; });
                call_then(crate::lower::expr::start_instantiated(or_(index(c_1_8_9->args, fix), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), c_1_8_9.params, args_8_9), [=](crate::check::types::Ty instantiated_10660) { return call_then(start_sub_pat(lx_4_8_9, c_1_8_9, fix, fp.pattern, instantiated_10660, mode_5_9_9, prism_rtl::cat(fresh_3_9_9, "_", i)), [=](PatOut sub_pat_10628) { return prism_rtl::finished(std::tuple{crate::lower::snake(fname), sub_pat_10628}); }); });
            });
            });
        }));
        });
    }));
    })), [=](Array<std::tuple<Text, PatOut>> each_10275) {
        return ({
            auto subs = each_10275;
            auto conds = fold(subs, Array<crate::lower::model::Cc>{}, [&](const Array<crate::lower::model::Cc>& acc, const std::tuple<Text, PatOut>& _p1) {
                auto&& o = std::get<1>(_p1);
                return append(acc, o.conds);
            });
            auto binds = fold(subs, Array<std::tuple<Text, crate::lower::types::Bn>>{}, [&](const Array<std::tuple<Text, crate::lower::types::Bn>>& acc, const std::tuple<Text, PatOut>& _p1) {
                auto&& o = std::get<1>(_p1);
                return append(acc, o.binds);
            });
            (prism_rtl::finished(PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaRecord{ty_path_7, each(subs, [&](const std::tuple<Text, PatOut>& _p0) {
            auto&& f = std::get<0>(_p0);
            auto&& o = std::get<1>(_p0);
            return std::tuple{f, o.pa};
        }), rest_6 || (len(subs) < len(c_1.fields))}), .conds = conds, .binds = binds}));
        });
    });
}


/// `Start FieldsPat, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<PatOut> start_fields_pat(crate::lower::Lx lx, crate::check::env::CtorInfo c, Array<crate::syntax::FieldPat> fps, bool rest, crate::check::types::Ty ty, crate::lower::types::Holding mode, Text fresh, Text ty_path) {
    return prism_rtl::make_rc<FieldsPat>(lx, c, fps, rest, ty, mode, fresh, ty_path);
}


/// let dummyFieldPat
crate::syntax::FieldPat dummy_field_pat() {
    return crate::syntax::FieldPat{.name = std::optional<crate::syntax::Ident>{}, .pattern = dummy_pat(), .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}};
}


/// let dummyTagInfo
crate::check::env::TagInfo dummy_tag_info() {
    return crate::check::env::TagInfo{.name = Text::lit(""), .family = Text::lit(""), .kind = Text::lit(""), .out = crate::check::types::Ty(crate::check::types::Ty::TyErr{}), .qs = Array<Text>{}, .rqs = Array<Text>{}, .bounds = Array<std::tuple<Text, Text>>{}, .fields = Array<std::tuple<Text, crate::check::types::Ty>>{}, .home = Text::lit(""), .file = Nat(0u), .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}};
}


/// IsLive: fn Ty -> Bool
bool is_live(const crate::check::types::Ty& t) {
    auto&& _m = crate::lower::types::peel(t);
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(_m)) {
        return true;
    }
    {
        return false;
    }
}


/// TagFieldName: fn FieldPat, [Text], Nat -> Text
Text tag_field_name(const crate::syntax::FieldPat& fp, const Array<Text>& names, const Nat& i) {
    auto&& _m = fp.name;
    if (prism_rtl::is_some(_m)) {
        auto&& id = prism_rtl::some_of(_m);
        return id.name;
    }
    if (prism_rtl::is_none(_m)) {
        auto&& _m = fp.pattern.kind;
        if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
            auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
            return crate::check::types::has_text(names, crate::check::env::sname_key(n))
                ? crate::check::env::sname_key(n)
                : or_(index(names, i), Text::lit(""));
        }
        {
            return or_(index(names, i), Text::lit(""));
        }
    }
    prism_rtl::unreachable("no arm matched");
}


/// TagPat: unbounded fn Lx, TagInfo, [FieldPat], Bool, Ty, Holding, Text -> PatOut
PatOut tag_pat(const crate::lower::Lx& lx, const crate::check::env::TagInfo& tg, const Array<crate::syntax::FieldPat>& fps, const bool& rest, const crate::check::types::Ty& ty, const crate::lower::types::Holding& mode, const Text& fresh) {
    auto [variant, struct_path] = crate::lower::program::tag_paths(lx, tg);
    auto live = is_live(ty);
    auto names = each(tg.fields, [&](const std::tuple<Text, crate::check::types::Ty>& _p0) {
        auto&& f = std::get<0>(_p0);
        return f;
    });
    auto sub_mode = live
        ? crate::lower::types::Holding(crate::lower::types::Holding::ByRef{})
        : mode;
    auto parts = run_to_end(each_job(crate::check::errors::range0(len(fps)), ({
        auto fps_1 = fps;
        auto names_2 = names;
        auto tg_3 = tg;
        auto live_4 = live;
        auto lx_5 = lx;
        auto variant_6 = variant;
        auto fresh_7 = fresh;
        auto sub_mode_8 = sub_mode;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<std::optional<Text>, PatOut>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto fps_1_9 = fps_1;
            auto names_2_9 = names_2;
            auto tg_3_9 = tg_3;
            auto live_4_9 = live_4;
            auto lx_5_9 = lx_5;
            auto variant_6_9 = variant_6;
            auto fresh_7_9 = fresh_7;
            auto sub_mode_8_9 = sub_mode_8;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                ({
                auto fp = or_(index(fps_1_9, i), dummy_field_pat());
                auto fname = tag_field_name(fp, names_2_9, i);
                auto ft = fold(tg_3_9.fields, crate::check::types::Ty(crate::check::types::Ty::TyErr{}), [&](const crate::check::types::Ty& found, const std::tuple<Text, crate::check::types::Ty>& _p1) {
                    auto&& f = std::get<0>(_p1);
                    auto&& t = std::get<1>(_p1);
                    return f == fname ? t : found;
                });
                ({
                auto&& _m = crate::lower::types::layer_of(ft);
                prism_rtl::is<crate::lower::types::Layer::LyEv>(_m) ? prism_rtl::finished(std::tuple{std::optional<Text>{}, PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds = Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::expr::refusal(prism_rtl::cat("an event field in an element pattern (", tg_3_9.name, ".", fname, ")"))})}), .binds = Array<std::tuple<Text, crate::lower::types::Bn>>{}}})
                : prism_rtl::is<crate::lower::types::Layer::LyDyn>(_m) && ({
                live_4_9;
            }) ? call_then(start_live_field_pat(lx_5_9, fp.pattern, variant_6_9, fname, ft, fresh_7_9), [=](PatOut live_field_pat_13035) { return prism_rtl::finished(std::tuple{std::optional<Text>{}, live_field_pat_13035}); })
                : call_then(start_rust_pat(lx_5_9, fp.pattern, crate::lower::types::peel(ft), sub_mode_8_9, prism_rtl::cat(fresh_7_9, "_", i)), [=](PatOut rust_pat_13140) {
                return ({
                    auto o = rust_pat_13140;
                    (prism_rtl::finished(std::tuple{std::optional(crate::lower::snake(fname)), o}));
                });
            });
            });
            });
            });
        }));
        });
    }));
    })));
    auto field_pas = fold(parts, Array<std::tuple<Text, crate::lower::model::Pa>>{}, [&](const Array<std::tuple<Text, crate::lower::model::Pa>>& acc, const std::tuple<std::optional<Text>, PatOut>& _p1) {
        auto&& f_opt = std::get<0>(_p1);
        auto&& o = std::get<1>(_p1);
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<std::tuple<Text, crate::lower::model::Pa>>> _v;
            if (prism_rtl::is_some(f_opt)) {
                auto&& f = prism_rtl::some_of(f_opt);
                _v.set(crate::prelude::push(acc, std::tuple{f, o.pa}));
                goto _done;
            }
            if (prism_rtl::is_none(f_opt)) {
                _v.set(acc);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
    auto conds = fold(parts, Array<crate::lower::model::Cc>{}, [&](const Array<crate::lower::model::Cc>& acc, const std::tuple<std::optional<Text>, PatOut>& _p1) {
        auto&& o = std::get<1>(_p1);
        return append(acc, o.conds);
    });
    auto binds = fold(parts, Array<std::tuple<Text, crate::lower::types::Bn>>{}, [&](const Array<std::tuple<Text, crate::lower::types::Bn>>& acc, const std::tuple<std::optional<Text>, PatOut>& _p1) {
        auto&& o = std::get<1>(_p1);
        return append(acc, o.binds);
    });
    auto level = crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{variant, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaRecord{struct_path, field_pas, true})})});
    auto tagged = crate::prelude::push(binds, std::tuple{Text::lit("#tag"), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XPath{crate::lower::node_::elements::answer_variant(tg)}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})})});
    return live
        ? PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaBind{fresh}), .conds = append(Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcLet{level, crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh})), Text::lit("identity")}))})})}), conds), .binds = tagged}
        : PatOut{.pa = level, .conds = conds, .binds = binds};
}


prism_rtl::Turn<PatOut> TagPat::cycle() const {
    const auto& lx = this->lx;
    const auto& tg = this->tg;
    const auto& fps = this->fps;
    const auto& rest = this->rest;
    const auto& ty = this->ty;
    const auto& mode = this->mode;
    const auto& fresh = this->fresh;
    auto [variant, struct_path] = crate::lower::program::tag_paths(lx, tg);
    auto live = is_live(ty);
    auto names = each(tg.fields, [&](const std::tuple<Text, crate::check::types::Ty>& _p0) {
        auto&& f = std::get<0>(_p0);
        return f;
    });
    auto sub_mode = live
        ? crate::lower::types::Holding(crate::lower::types::Holding::ByRef{})
        : mode;
    auto fps_1 = fps;
    auto fresh_2 = fresh;
    auto lx_3 = lx;
    auto tg_4 = tg;
    return call_value(each_job(crate::check::errors::range0(len(fps_1)), ({
        auto fps_1_5 = fps_1;
        auto names_5 = names;
        auto tg_4_6 = tg_4;
        auto live_6 = live;
        auto lx_3_7 = lx_3;
        auto variant_7 = variant;
        auto fresh_2_8 = fresh_2;
        auto sub_mode_8 = sub_mode;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<std::optional<Text>, PatOut>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto fps_1_5_9 = fps_1_5;
            auto names_5_9 = names_5;
            auto tg_4_6_9 = tg_4_6;
            auto live_6_9 = live_6;
            auto lx_3_7_9 = lx_3_7;
            auto variant_7_9 = variant_7;
            auto fresh_2_8_9 = fresh_2_8;
            auto sub_mode_8_9 = sub_mode_8;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                ({
                auto fp = or_(index(fps_1_5_9, i), dummy_field_pat());
                auto fname = tag_field_name(fp, names_5_9, i);
                auto ft = fold(tg_4_6_9.fields, crate::check::types::Ty(crate::check::types::Ty::TyErr{}), [&](const crate::check::types::Ty& found, const std::tuple<Text, crate::check::types::Ty>& _p1) {
                    auto&& f = std::get<0>(_p1);
                    auto&& t = std::get<1>(_p1);
                    return f == fname ? t : found;
                });
                ({
                auto&& _m = crate::lower::types::layer_of(ft);
                prism_rtl::is<crate::lower::types::Layer::LyEv>(_m) ? prism_rtl::finished(std::tuple{std::optional<Text>{}, PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds = Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::expr::refusal(prism_rtl::cat("an event field in an element pattern (", tg_4_6_9.name, ".", fname, ")"))})}), .binds = Array<std::tuple<Text, crate::lower::types::Bn>>{}}})
                : prism_rtl::is<crate::lower::types::Layer::LyDyn>(_m) && ({
                live_6_9;
            }) ? call_then(start_live_field_pat(lx_3_7_9, fp.pattern, variant_7_9, fname, ft, fresh_2_8_9), [=](PatOut live_field_pat_13035) { return prism_rtl::finished(std::tuple{std::optional<Text>{}, live_field_pat_13035}); })
                : call_then(start_rust_pat(lx_3_7_9, fp.pattern, crate::lower::types::peel(ft), sub_mode_8_9, prism_rtl::cat(fresh_2_8_9, "_", i)), [=](PatOut rust_pat_13140) {
                return ({
                    auto o = rust_pat_13140;
                    (prism_rtl::finished(std::tuple{std::optional(crate::lower::snake(fname)), o}));
                });
            });
            });
            });
            });
        }));
        });
    }));
    })), [=](Array<std::tuple<std::optional<Text>, PatOut>> each_12624) {
        return ({
            auto parts = each_12624;
            auto field_pas = fold(parts, Array<std::tuple<Text, crate::lower::model::Pa>>{}, [&](const Array<std::tuple<Text, crate::lower::model::Pa>>& acc, const std::tuple<std::optional<Text>, PatOut>& _p1) {
                auto&& f_opt = std::get<0>(_p1);
                auto&& o = std::get<1>(_p1);
                return ({
                    __label__ _done;
                    prism_rtl::Slot<Array<std::tuple<Text, crate::lower::model::Pa>>> _v;
                    if (prism_rtl::is_some(f_opt)) {
                        auto&& f = prism_rtl::some_of(f_opt);
                        _v.set(crate::prelude::push(acc, std::tuple{f, o.pa}));
                        goto _done;
                    }
                    if (prism_rtl::is_none(f_opt)) {
                        _v.set(acc);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
            });
            auto conds = fold(parts, Array<crate::lower::model::Cc>{}, [&](const Array<crate::lower::model::Cc>& acc, const std::tuple<std::optional<Text>, PatOut>& _p1) {
                auto&& o = std::get<1>(_p1);
                return append(acc, o.conds);
            });
            auto binds = fold(parts, Array<std::tuple<Text, crate::lower::types::Bn>>{}, [&](const Array<std::tuple<Text, crate::lower::types::Bn>>& acc, const std::tuple<std::optional<Text>, PatOut>& _p1) {
                auto&& o = std::get<1>(_p1);
                return append(acc, o.binds);
            });
            auto level = crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{variant, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaRecord{struct_path, field_pas, true})})});
            auto tagged = crate::prelude::push(binds, std::tuple{Text::lit("#tag"), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XPath{crate::lower::node_::elements::answer_variant(tg_4)}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})})});
            live
            ? prism_rtl::finished(PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaBind{fresh_2}), .conds = append(Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcLet{level, crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh_2})), Text::lit("identity")}))})})}), conds), .binds = tagged})
            : prism_rtl::finished(PatOut{.pa = level, .conds = conds, .binds = binds});
        });
    });
}


/// `Start TagPat, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<PatOut> start_tag_pat(crate::lower::Lx lx, crate::check::env::TagInfo tg, Array<crate::syntax::FieldPat> fps, bool rest, crate::check::types::Ty ty, crate::lower::types::Holding mode, Text fresh) {
    return prism_rtl::make_rc<TagPat>(lx, tg, fps, rest, ty, mode, fresh);
}


/// LiveFieldPat: unbounded fn Lx, Pattern, Text, Text, Ty, Text -> PatOut
PatOut live_field_pat(const crate::lower::Lx& lx, const crate::syntax::Pattern_& p_, const Text& variant, const Text& fname, const crate::check::types::Ty& ft, const Text& fresh) {
    auto&& _m = p_.kind;
    if (prism_rtl::is<crate::syntax::PatternKind::PIgnore>(_m)) {
        return pat_only(crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}));
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        auto rs = lx.in_node
            ? live_projection(fresh, variant, fname, crate::lower::types::out_ty_of(lx, crate::lower::types::peel(ft)))
            : crate::lower::expr::refusal(prism_rtl::cat("a live element\'s `$` field (", fname, ") in a plain function, which has no read point (gap LE)"));
        return PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds = Array<crate::lower::model::Cc>{}, .binds = Array(std::vector{std::tuple{crate::check::env::sname_key(n), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{rs, crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutDyn{prism_rtl::rc(crate::lower::types::out_ty_of(lx, crate::lower::types::peel(ft)))})})}})};
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PGroup>(_m)) {
        auto&& q = prism_rtl::as<crate::syntax::PatternKind::PGroup>(_m).a0;
        return live_field_pat(lx, q, variant, fname, ft, fresh);
    }
    {
        return PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds = Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::expr::refusal(prism_rtl::cat("a pattern inside a live element\'s `$` field (", fname, ")"))})}), .binds = Array<std::tuple<Text, crate::lower::types::Bn>>{}};
    }
}


prism_rtl::Turn<PatOut> LiveFieldPat::cycle() const {
    const auto& lx = this->lx;
    const auto& p_ = this->p_;
    const auto& variant = this->variant;
    const auto& fname = this->fname;
    const auto& ft = this->ft;
    const auto& fresh = this->fresh;
    return ({
        auto&& _m = p_.kind;
        prism_rtl::is<crate::syntax::PatternKind::PIgnore>(_m) ? prism_rtl::finished(pat_only(crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})))
        : prism_rtl::is<crate::syntax::PatternKind::PName>(_m) ? ({
        auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        ({
        auto rs = lx.in_node
            ? live_projection(fresh, variant, fname, crate::lower::types::out_ty_of(lx, crate::lower::types::peel(ft)))
            : crate::lower::expr::refusal(prism_rtl::cat("a live element\'s `$` field (", fname, ") in a plain function, which has no read point (gap LE)"));
        auto ft_1 = ft;
        auto lx_2 = lx;
        auto n_3 = n;
        call_then(crate::lower::types::start_out_ty_of(lx_2, crate::lower::types::peel(ft_1)), [=](crate::lower::model::OutTy out_ty_of_14752) { return prism_rtl::finished(PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds = Array<crate::lower::model::Cc>{}, .binds = Array(std::vector{std::tuple{crate::check::env::sname_key(n_3), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{rs, crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutDyn{prism_rtl::rc(out_ty_of_14752)})})}})}); });
    });
    })
        : prism_rtl::is<crate::syntax::PatternKind::PGroup>(_m) ? ({
        auto&& q = prism_rtl::as<crate::syntax::PatternKind::PGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(LiveFieldPat(lx, q, variant, fname, ft, fresh)));
    })
        : prism_rtl::finished(PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds = Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::expr::refusal(prism_rtl::cat("a pattern inside a live element\'s `$` field (", fname, ")"))})}), .binds = Array<std::tuple<Text, crate::lower::types::Bn>>{}});
    });
}


/// `Start LiveFieldPat, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<PatOut> start_live_field_pat(crate::lower::Lx lx, crate::syntax::Pattern_ p_, Text variant, Text fname, crate::check::types::Ty ft, Text fresh) {
    return prism_rtl::make_rc<LiveFieldPat>(lx, p_, variant, fname, ft, fresh);
}


/// LiveProjection: fn Text, Text, Text, OutTy -> Ex
crate::lower::model::Ex live_projection(const Text& fresh, const Text& variant, const Text& fname, const crate::lower::model::OutTy& ft) {
    auto arm = crate::lower::model::XArm{.pat = crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{variant, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("x")})})}), .conds = Array<crate::lower::model::Cc>{}, .body = crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("x")})), crate::lower::snake(fname)}))})};
    auto other = crate::lower::model::XArm{.pat = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds = Array<crate::lower::model::Cc>{}, .body = crate::lower::model::Ex(crate::lower::model::Ex::XUnreachable{})};
    return crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh})), Text::lit("level")})), Text::lit("map"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("l")})}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMatch{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("l")})), Array(std::vector{arm, other}), false, ft}))})})});
}


/// FamilyPat: unbounded fn Lx, QualName, Ty, Text -> PatOut
PatOut family_pat(const crate::lower::Lx& lx, const crate::syntax::QualName& q, const crate::check::types::Ty& ty, const Text& fresh) {
    auto fam = crate::check::env::dotted(filter(q->path_, [&](const Text& x) { return x != Text::lit("*"); }));
    auto kind = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = crate::lower::types::peel(ty);
        if (prism_rtl::is<crate::check::types::Ty::TyElem>(_m)) {
            _v.set(Text::lit("Element"));
            goto _done;
        }
        if (prism_rtl::is<crate::check::types::Ty::TyElemAny>(_m)) {
            _v.set(Text::lit("Element"));
            goto _done;
        }
        if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
            auto&& k = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
            _v.set(k);
            goto _done;
        }
        {
            _v.set(Text::lit(""));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto tags = filter(crate::lower::program::kind_tags(lx, kind, keys(lx.rs_mods)), [&](const crate::check::env::TagInfo& tg) { return tg.family == fam; });
    auto place_ = is_live(ty)
        ? crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh})), Text::lit("identity")})
        : crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh});
    return PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaBind{fresh}), .conds = Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::model::Ex(crate::lower::model::Ex::XIsCase{prism_rtl::rc(place_), each(tags, [&](const crate::check::env::TagInfo& tg) { return crate::lower::program::variant_of(lx, tg); })})})}), .binds = Array<std::tuple<Text, crate::lower::types::Bn>>{}};
}


prism_rtl::Turn<PatOut> FamilyPat::cycle() const {
    const auto& lx = this->lx;
    const auto& q = this->q;
    const auto& ty = this->ty;
    const auto& fresh = this->fresh;
    auto fam = crate::check::env::dotted(filter(q->path_, [&](const Text& x) { return x != Text::lit("*"); }));
    auto kind = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = crate::lower::types::peel(ty);
        if (prism_rtl::is<crate::check::types::Ty::TyElem>(_m)) {
            _v.set(Text::lit("Element"));
            goto _done;
        }
        if (prism_rtl::is<crate::check::types::Ty::TyElemAny>(_m)) {
            _v.set(Text::lit("Element"));
            goto _done;
        }
        if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
            auto&& k = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
            _v.set(k);
            goto _done;
        }
        {
            _v.set(Text::lit(""));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto tags = filter(crate::lower::program::kind_tags(lx, kind, keys(lx.rs_mods)), [&](const crate::check::env::TagInfo& tg) { return tg.family == fam; });
    auto place_ = is_live(ty)
        ? crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh})), Text::lit("identity")})
        : crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh});
    return prism_rtl::finished(PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaBind{fresh}), .conds = Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::model::Ex(crate::lower::model::Ex::XIsCase{prism_rtl::rc(place_), each(tags, [&](const crate::check::env::TagInfo& tg) { return crate::lower::program::variant_of(lx, tg); })})})}), .binds = Array<std::tuple<Text, crate::lower::types::Bn>>{}});
}


/// `Start FamilyPat, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<PatOut> start_family_pat(crate::lower::Lx lx, crate::syntax::QualName q, crate::check::types::Ty ty, Text fresh) {
    return prism_rtl::make_rc<FamilyPat>(lx, q, ty, fresh);
}


/// ErrorPat: unbounded fn Lx, [FieldPat], Ty, Holding, Text -> PatOut
PatOut error_pat(const crate::lower::Lx& lx, const Array<crate::syntax::FieldPat>& fps, const crate::check::types::Ty& ty, const crate::lower::types::Holding& mode, const Text& fresh) {
    auto e = crate::lower::types::local_place(crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh}), mode, crate::lower::model::OutTy(crate::lower::model::OutTy::OutError{}));
    auto parts = each(fps, [&](const crate::syntax::FieldPat& fp) {
        return ({
            auto fname = ({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                auto&& _m = fp.name;
                if (prism_rtl::is_some(_m)) {
                    auto&& id = prism_rtl::some_of(_m);
                    _v.set(id.name);
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(Text::lit(""));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<Array<crate::lower::model::Cc>, Array<std::tuple<Text, crate::lower::types::Bn>>>> _v;
            {
                auto&& m16367_0 = fname;
                if (m16367_0 == Text::lit("kind")) {
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<std::tuple<Array<crate::lower::model::Cc>, Array<std::tuple<Text, crate::lower::types::Bn>>>> _v;
                        auto&& _m = fp.pattern.kind;
                        if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
                            auto&& k = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
                            _v.set(({
                                auto&& _kq_opt = crate::check::env::names::resolve_value(lx.g, lx.home, k);
                                auto&& kq_opt = std::get<0>(_kq_opt);
                                ({
                                __label__ _done;
                                prism_rtl::Slot<std::tuple<Array<crate::lower::model::Cc>, Array<std::tuple<Text, crate::lower::types::Bn>>>> _v;
                                if (prism_rtl::is_some(kq_opt)) {
                                    auto&& kq = prism_rtl::some_of(kq_opt);
                                    _v.set(crate::check::env::has_key(lx.g.tags, kq)
                                        ? std::tuple{Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::model::Ex(crate::lower::model::Ex::XBin{Text::lit("=="), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XDeref{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh})), Text::lit("kind")}))}))})), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XStr{kq}))})})}), Array<std::tuple<Text, crate::lower::types::Bn>>{}}
                                        : std::tuple{Array<crate::lower::model::Cc>{}, Array(std::vector{std::tuple{crate::check::env::sname_key(k), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh})), Text::lit("kind")}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutText{})})}})});
                                    goto _done;
                                }
                                if (prism_rtl::is_none(kq_opt)) {
                                    _v.set(std::tuple{Array<crate::lower::model::Cc>{}, Array(std::vector{std::tuple{crate::check::env::sname_key(k), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh})), Text::lit("kind")}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutText{})})}})});
                                    goto _done;
                                }
                                prism_rtl::unreachable("no arm matched");
                            _done:
                                _v.take();
                            });
                            }));
                            goto _done;
                        }
                        {
                            _v.set(std::tuple{Array<crate::lower::model::Cc>{}, Array<std::tuple<Text, crate::lower::types::Bn>>{}});
                            goto _done;
                        }
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
            }
            {
                auto&& m16367_1 = fname;
                if (m16367_1 == Text::lit("message")) {
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<std::tuple<Array<crate::lower::model::Cc>, Array<std::tuple<Text, crate::lower::types::Bn>>>> _v;
                        auto&& _m = fp.pattern.kind;
                        if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
                            auto&& m = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
                            _v.set(std::tuple{Array<crate::lower::model::Cc>{}, Array(std::vector{std::tuple{crate::check::env::sname_key(m), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh})), Text::lit("message")}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutText{})})}})});
                            goto _done;
                        }
                        {
                            _v.set(std::tuple{Array<crate::lower::model::Cc>{}, Array<std::tuple<Text, crate::lower::types::Bn>>{}});
                            goto _done;
                        }
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
            }
            {
                _v.set(std::tuple{Array<crate::lower::model::Cc>{}, Array<std::tuple<Text, crate::lower::types::Bn>>{}});
                goto _done;
            }
        _done:
            _v.take();
        });
        });
    });
    auto wrapped = ({
        __label__ _done;
        prism_rtl::Slot<crate::lower::model::Pa> _v;
        auto&& _m = crate::lower::types::peel(ty);
        if (prism_rtl::is<crate::check::types::Ty::TySig>(_m)) {
            auto&& m17204_0_0 = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a0;
            if (m17204_0_0 == Text::lit("~")) {
                _v.set(crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Err"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{fresh})})}));
                goto _done;
            }
        }
        {
            _v.set(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{fresh}));
            goto _done;
        }
    _done:
        _v.take();
    });
    return PatOut{.pa = wrapped, .conds = fold(parts, Array<crate::lower::model::Cc>{}, [&](const Array<crate::lower::model::Cc>& acc, const std::tuple<Array<crate::lower::model::Cc>, Array<std::tuple<Text, crate::lower::types::Bn>>>& _p1) {
        auto&& cs = std::get<0>(_p1);
        return append(acc, cs);
    }), .binds = fold(parts, Array<std::tuple<Text, crate::lower::types::Bn>>{}, [&](const Array<std::tuple<Text, crate::lower::types::Bn>>& acc, const std::tuple<Array<crate::lower::model::Cc>, Array<std::tuple<Text, crate::lower::types::Bn>>>& _p1) {
        auto&& bs = std::get<1>(_p1);
        return append(acc, bs);
    })};
}


prism_rtl::Turn<PatOut> ErrorPat::cycle() const {
    const auto& lx = this->lx;
    const auto& fps = this->fps;
    const auto& ty = this->ty;
    const auto& mode = this->mode;
    const auto& fresh = this->fresh;
    auto e = crate::lower::types::local_place(crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh}), mode, crate::lower::model::OutTy(crate::lower::model::OutTy::OutError{}));
    auto parts = each(fps, [&](const crate::syntax::FieldPat& fp) {
        return ({
            auto fname = ({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                auto&& _m = fp.name;
                if (prism_rtl::is_some(_m)) {
                    auto&& id = prism_rtl::some_of(_m);
                    _v.set(id.name);
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(Text::lit(""));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<Array<crate::lower::model::Cc>, Array<std::tuple<Text, crate::lower::types::Bn>>>> _v;
            {
                auto&& m16367_0 = fname;
                if (m16367_0 == Text::lit("kind")) {
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<std::tuple<Array<crate::lower::model::Cc>, Array<std::tuple<Text, crate::lower::types::Bn>>>> _v;
                        auto&& _m = fp.pattern.kind;
                        if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
                            auto&& k = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
                            _v.set(({
                                auto&& _kq_opt = crate::check::env::names::resolve_value(lx.g, lx.home, k);
                                auto&& kq_opt = std::get<0>(_kq_opt);
                                ({
                                __label__ _done;
                                prism_rtl::Slot<std::tuple<Array<crate::lower::model::Cc>, Array<std::tuple<Text, crate::lower::types::Bn>>>> _v;
                                if (prism_rtl::is_some(kq_opt)) {
                                    auto&& kq = prism_rtl::some_of(kq_opt);
                                    _v.set(crate::check::env::has_key(lx.g.tags, kq)
                                        ? std::tuple{Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::model::Ex(crate::lower::model::Ex::XBin{Text::lit("=="), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XDeref{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh})), Text::lit("kind")}))}))})), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XStr{kq}))})})}), Array<std::tuple<Text, crate::lower::types::Bn>>{}}
                                        : std::tuple{Array<crate::lower::model::Cc>{}, Array(std::vector{std::tuple{crate::check::env::sname_key(k), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh})), Text::lit("kind")}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutText{})})}})});
                                    goto _done;
                                }
                                if (prism_rtl::is_none(kq_opt)) {
                                    _v.set(std::tuple{Array<crate::lower::model::Cc>{}, Array(std::vector{std::tuple{crate::check::env::sname_key(k), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh})), Text::lit("kind")}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutText{})})}})});
                                    goto _done;
                                }
                                prism_rtl::unreachable("no arm matched");
                            _done:
                                _v.take();
                            });
                            }));
                            goto _done;
                        }
                        {
                            _v.set(std::tuple{Array<crate::lower::model::Cc>{}, Array<std::tuple<Text, crate::lower::types::Bn>>{}});
                            goto _done;
                        }
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
            }
            {
                auto&& m16367_1 = fname;
                if (m16367_1 == Text::lit("message")) {
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<std::tuple<Array<crate::lower::model::Cc>, Array<std::tuple<Text, crate::lower::types::Bn>>>> _v;
                        auto&& _m = fp.pattern.kind;
                        if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
                            auto&& m = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
                            _v.set(std::tuple{Array<crate::lower::model::Cc>{}, Array(std::vector{std::tuple{crate::check::env::sname_key(m), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh})), Text::lit("message")}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutText{})})}})});
                            goto _done;
                        }
                        {
                            _v.set(std::tuple{Array<crate::lower::model::Cc>{}, Array<std::tuple<Text, crate::lower::types::Bn>>{}});
                            goto _done;
                        }
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
            }
            {
                _v.set(std::tuple{Array<crate::lower::model::Cc>{}, Array<std::tuple<Text, crate::lower::types::Bn>>{}});
                goto _done;
            }
        _done:
            _v.take();
        });
        });
    });
    auto wrapped = ({
        __label__ _done;
        prism_rtl::Slot<crate::lower::model::Pa> _v;
        auto&& _m = crate::lower::types::peel(ty);
        if (prism_rtl::is<crate::check::types::Ty::TySig>(_m)) {
            auto&& m17204_0_0 = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a0;
            if (m17204_0_0 == Text::lit("~")) {
                _v.set(crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Err"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{fresh})})}));
                goto _done;
            }
        }
        {
            _v.set(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{fresh}));
            goto _done;
        }
    _done:
        _v.take();
    });
    return prism_rtl::finished(PatOut{.pa = wrapped, .conds = fold(parts, Array<crate::lower::model::Cc>{}, [&](const Array<crate::lower::model::Cc>& acc, const std::tuple<Array<crate::lower::model::Cc>, Array<std::tuple<Text, crate::lower::types::Bn>>>& _p1) {
        auto&& cs = std::get<0>(_p1);
        return append(acc, cs);
    }), .binds = fold(parts, Array<std::tuple<Text, crate::lower::types::Bn>>{}, [&](const Array<std::tuple<Text, crate::lower::types::Bn>>& acc, const std::tuple<Array<crate::lower::model::Cc>, Array<std::tuple<Text, crate::lower::types::Bn>>>& _p1) {
        auto&& bs = std::get<1>(_p1);
        return append(acc, bs);
    })});
}


/// `Start ErrorPat, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<PatOut> start_error_pat(crate::lower::Lx lx, Array<crate::syntax::FieldPat> fps, crate::check::types::Ty ty, crate::lower::types::Holding mode, Text fresh) {
    return prism_rtl::make_rc<ErrorPat>(lx, fps, ty, mode, fresh);
}


/// ArrayPat: unbounded fn Lx, [Pattern], Ty, Holding, Text -> PatOut
PatOut array_pat(const crate::lower::Lx& lx, const Array<crate::syntax::Pattern_>& ps, const crate::check::types::Ty& ty, const crate::lower::types::Holding& mode, const Text& fresh) {
    auto et = ({
        __label__ _done;
        prism_rtl::Slot<crate::check::types::Ty> _v;
        auto&& _m = crate::lower::types::peel(ty);
        if (prism_rtl::is<crate::check::types::Ty::TyArray>(_m)) {
            auto&& x = prism_rtl::as<crate::check::types::Ty::TyArray>(_m).a0;
            _v.set(x);
            goto _done;
        }
        {
            _v.set(crate::check::types::Ty(crate::check::types::Ty::TyErr{}));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto arr = crate::lower::types::local_place(crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh}), mode, crate::lower::types::out_ty_of(lx, crate::lower::types::peel(ty)));
    auto len_cond = crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::model::Ex(crate::lower::model::Ex::XBin{Text::lit("=="), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::types::ref_(arr)), Text::lit("len"), Array<crate::lower::model::Ex>{}})), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XIndex{len(ps)}))})});
    auto subs = run_to_end(each_job(crate::check::errors::range0(len(ps)), ({
        auto lx_1 = lx;
        auto ps_2 = ps;
        auto et_3 = et;
        auto fresh_4 = fresh;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Nat, PatOut>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto lx_1_5 = lx_1;
            auto ps_2_5 = ps_2;
            auto et_3_5 = et_3;
            auto fresh_4_5 = fresh_4;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                call_then(start_rust_pat(lx_1_5, or_(index(ps_2_5, i), dummy_pat()), et_3_5, crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat(fresh_4_5, "_", i)), [=](PatOut rust_pat_17901) { return prism_rtl::finished(std::tuple{i, rust_pat_17901}); });
            });
        }));
        });
    }));
    })));
    auto conds = fold(subs, Array(std::vector{len_cond}), [&](const Array<crate::lower::model::Cc>& acc, const std::tuple<Nat, PatOut>& _p1) {
        auto&& i = std::get<0>(_p1);
        auto&& o = std::get<1>(_p1);
        return append(crate::prelude::push(acc, crate::lower::model::Cc(crate::lower::model::Cc::CcLet{crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{o.pa})}), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("index"), Array(std::vector{crate::lower::types::ref_(arr), crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XNat{prism_rtl::cat(i)}))})})})})), o.conds);
    });
    auto binds = fold(subs, Array<std::tuple<Text, crate::lower::types::Bn>>{}, [&](const Array<std::tuple<Text, crate::lower::types::Bn>>& acc, const std::tuple<Nat, PatOut>& _p1) {
        auto&& o = std::get<1>(_p1);
        return append(acc, o.binds);
    });
    return PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaBind{fresh}), .conds = conds, .binds = binds};
}


prism_rtl::Turn<PatOut> ArrayPat::cycle() const {
    const auto& lx = this->lx;
    const auto& ps = this->ps;
    const auto& ty = this->ty;
    const auto& mode = this->mode;
    const auto& fresh = this->fresh;
    auto et = ({
        __label__ _done;
        prism_rtl::Slot<crate::check::types::Ty> _v;
        auto&& _m = crate::lower::types::peel(ty);
        if (prism_rtl::is<crate::check::types::Ty::TyArray>(_m)) {
            auto&& x = prism_rtl::as<crate::check::types::Ty::TyArray>(_m).a0;
            _v.set(x);
            goto _done;
        }
        {
            _v.set(crate::check::types::Ty(crate::check::types::Ty::TyErr{}));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto fresh_1 = fresh;
    auto lx_2 = lx;
    auto mode_3 = mode;
    auto ps_4 = ps;
    auto ty_5 = ty;
    return call_then(crate::lower::types::start_out_ty_of(lx_2, crate::lower::types::peel(ty_5)), [=](crate::lower::model::OutTy out_ty_of_17740) {
        return ({
            auto arr = crate::lower::types::local_place(crate::lower::model::Ex(crate::lower::model::Ex::XVar{fresh_1}), mode_3, out_ty_of_17740);
            auto len_cond = crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::model::Ex(crate::lower::model::Ex::XBin{Text::lit("=="), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::types::ref_(arr)), Text::lit("len"), Array<crate::lower::model::Ex>{}})), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XIndex{len(ps_4)}))})});
            call_value(each_job(crate::check::errors::range0(len(ps_4)), ({
            auto lx_2_6 = lx_2;
            auto ps_4_6 = ps_4;
            auto et_6 = et;
            auto fresh_1_7 = fresh_1;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Nat, PatOut>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
            return ({
                auto lx_2_6_7 = lx_2_6;
                auto ps_4_6_7 = ps_4_6;
                auto et_6_7 = et_6;
                auto fresh_1_7_7 = fresh_1_7;
                entered(once_job([=]() {
                return ({
                    auto i = p0;
                    call_then(start_rust_pat(lx_2_6_7, or_(index(ps_4_6_7, i), dummy_pat()), et_6_7, crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat(fresh_1_7_7, "_", i)), [=](PatOut rust_pat_17901) { return prism_rtl::finished(std::tuple{i, rust_pat_17901}); });
                });
            }));
            });
        }));
        })), [=](Array<std::tuple<Nat, PatOut>> each_17866) {
            return ({
                auto subs = each_17866;
                auto conds = fold(subs, Array(std::vector{len_cond}), [&](const Array<crate::lower::model::Cc>& acc, const std::tuple<Nat, PatOut>& _p1) {
                    auto&& i = std::get<0>(_p1);
                    auto&& o = std::get<1>(_p1);
                    return append(crate::prelude::push(acc, crate::lower::model::Cc(crate::lower::model::Cc::CcLet{crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{o.pa})}), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("index"), Array(std::vector{crate::lower::types::ref_(arr), crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XNat{prism_rtl::cat(i)}))})})})})), o.conds);
                });
                auto binds = fold(subs, Array<std::tuple<Text, crate::lower::types::Bn>>{}, [&](const Array<std::tuple<Text, crate::lower::types::Bn>>& acc, const std::tuple<Nat, PatOut>& _p1) {
                    auto&& o = std::get<1>(_p1);
                    return append(acc, o.binds);
                });
                (prism_rtl::finished(PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaBind{fresh_1}), .conds = conds, .binds = binds}));
            });
        });
        });
    });
}


/// `Start ArrayPat, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<PatOut> start_array_pat(crate::lower::Lx lx, Array<crate::syntax::Pattern_> ps, crate::check::types::Ty ty, crate::lower::types::Holding mode, Text fresh) {
    return prism_rtl::make_rc<ArrayPat>(lx, ps, ty, mode, fresh);
}

}  // namespace crate::lower::patterns
