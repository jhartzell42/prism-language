// The root module, from `target/bootstrap/cpp-src/prismc/front.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (docs/backend.md). Edit the Prism source, not this file.
#include "program.hpp"
#include "ast.hpp"
#include "check_blocks.hpp"
#include "check_env.hpp"
#include "check_errors.hpp"
#include "check_expr.hpp"
#include "check_passes.hpp"
#include "check_types.hpp"
#include "cpp_prelude_template.hpp"
#include "cpp_templates.hpp"
#include "emit.hpp"
#include "emit_cpp.hpp"
#include "fs.hpp"
#include "lexer.hpp"
#include "lower.hpp"
#include "parser.hpp"
#include "prelude_template.hpp"
#include "process.hpp"
#include "rust_templates.hpp"
#include "sexp.hpp"
#include "typed.hpp"
#include "check_env.generic.hpp"
#include "lexer.generic.hpp"
#include "lower.generic.hpp"
#include "parser.generic.hpp"
#include "sexp.generic.hpp"

namespace crate::program {

void CheckJob::show(Printer& p) const {
    p.record("CheckJob", {{"files", files}, {"prelude", prelude}, {"world", world}, {"typed", typed}, {"unused", unused}});
}

Pod CheckJob::to_pod() const {
    return Pod::record("CheckJob", {{"files", prism_rtl::to_pod(files)}, {"prelude", prism_rtl::to_pod(prelude)}, {"world", prism_rtl::to_pod(world)}, {"typed", prism_rtl::to_pod(typed)}, {"unused", prism_rtl::to_pod(unused)}});
}

Result<CheckJob> CheckJob::from_pod(const Pod& whole) {
    return CheckJob{.files = TRY(prism_rtl::from_pod<Array<std::tuple<Text, Text>>>(TRY(prelude::field(whole, "files")))), .prelude = TRY(prism_rtl::from_pod<Array<std::tuple<Text, Text>>>(TRY(prelude::field(whole, "prelude")))), .world = TRY(prism_rtl::from_pod<Array<Text>>(TRY(prelude::field(whole, "world")))), .typed = TRY(prism_rtl::from_pod<bool>(TRY(prelude::field(whole, "typed")))), .unused = TRY(prism_rtl::from_pod<bool>(TRY(prelude::field(whole, "unused"))))};
}


void CompileJob::show(Printer& p) const {
    p.record("CompileJob", {{"files", files}, {"prelude", prelude}, {"name", name}, {"runtime", runtime}, {"target", target}});
}

Pod CompileJob::to_pod() const {
    return Pod::record("CompileJob", {{"files", prism_rtl::to_pod(files)}, {"prelude", prism_rtl::to_pod(prelude)}, {"name", prism_rtl::to_pod(name)}, {"runtime", prism_rtl::to_pod(runtime)}, {"target", prism_rtl::to_pod(target)}});
}

Result<CompileJob> CompileJob::from_pod(const Pod& whole) {
    return CompileJob{.files = TRY(prism_rtl::from_pod<Array<std::tuple<Text, Text>>>(TRY(prelude::field(whole, "files")))), .prelude = TRY(prism_rtl::from_pod<Array<std::tuple<Text, Text>>>(TRY(prelude::field(whole, "prelude")))), .name = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "name")))), .runtime = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "runtime")))), .target = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "target"))))};
}


void CompileSettings::show(Printer& p) const {
    p.record("CompileSettings", {{"out", out}, {"prelude", prelude}, {"name", name}, {"runtime", runtime}, {"target", target}});
}

Pod CompileSettings::to_pod() const {
    return Pod::record("CompileSettings", {{"out", prism_rtl::to_pod(out)}, {"prelude", prism_rtl::to_pod(prelude)}, {"name", prism_rtl::to_pod(name)}, {"runtime", prism_rtl::to_pod(runtime)}, {"target", prism_rtl::to_pod(target)}});
}

Result<CompileSettings> CompileSettings::from_pod(const Pod& whole) {
    return CompileSettings{.out = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "out")))), .prelude = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "prelude")))), .name = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "name")))), .runtime = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "runtime")))), .target = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "target"))))};
}


void Compiled::show(Printer& p) const {
    p.record("Compiled", {{"files", files}, {"failed", failed}, {"report", report}});
}

Pod Compiled::to_pod() const {
    return Pod::record("Compiled", {{"files", prism_rtl::to_pod(files)}, {"failed", prism_rtl::to_pod(failed)}, {"report", prism_rtl::to_pod(report)}});
}

Result<Compiled> Compiled::from_pod(const Pod& whole) {
    return Compiled{.files = TRY(prism_rtl::from_pod<Array<std::tuple<Text, Text>>>(TRY(prelude::field(whole, "files")))), .failed = TRY(prism_rtl::from_pod<bool>(TRY(prelude::field(whole, "failed")))), .report = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "report"))))};
}


void Job_::show(Printer& p) const {
    p.record("Job", {{"tokens", tokens}, {"fragment", fragment}, {"text", text}});
}

Pod Job_::to_pod() const {
    return Pod::record("Job", {{"tokens", prism_rtl::to_pod(tokens)}, {"fragment", prism_rtl::to_pod(fragment)}, {"text", prism_rtl::to_pod(text)}});
}

Result<Job_> Job_::from_pod(const Pod& whole) {
    return Job_{.tokens = TRY(prism_rtl::from_pod<bool>(TRY(prelude::field(whole, "tokens")))), .fragment = TRY(prism_rtl::from_pod<bool>(TRY(prelude::field(whole, "fragment")))), .text = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "text"))))};
}


void Outcome_::show(Printer& p) const {
    p.record("Outcome", {{"text", text}, {"failed", failed}, {"report", report}});
}

Pod Outcome_::to_pod() const {
    return Pod::record("Outcome", {{"text", prism_rtl::to_pod(text)}, {"failed", prism_rtl::to_pod(failed)}, {"report", prism_rtl::to_pod(report)}});
}

Result<Outcome_> Outcome_::from_pod(const Pod& whole) {
    return Outcome_{.text = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "text")))), .failed = TRY(prism_rtl::from_pod<bool>(TRY(prelude::field(whole, "failed")))), .report = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "report"))))};
}


/// FrontEnd: unbounded fn Job -> Outcome
Outcome_ front_end(const Job_& job) {
    return job->tokens
        ? ({
        auto lexed = lexer::lex_file(job->text);
        auto report = render_diags(job->text, lexed.diags);
        Outcome_{.text = prism_rtl::cat(lexer::render_tokens(lexed->tokens), report, "\n"), .failed = any_errors(lexed.diags), .report = report};
    })
        : ({
        auto parsed = job->fragment
            ? parser::parse_fragment(job->text)
            : parser::parse_file(job->text);
        auto report = render_diags(job->text, parsed.diags);
        Outcome_{.text = prism_rtl::cat(sexp::sexp_module(parsed.tree), report, "\n"), .failed = any_errors(parsed.diags), .report = report};
    });
}


prism_rtl::Turn<Outcome_> FrontEnd::cycle() const {
    const auto& job = this->job;
    return job->tokens
        ? ({
        auto job_1 = job;
        call_then(lexer::start_lex_file(job_1->text), [=](lexer::Lexed lex_file_2183) {
        return ({
            auto lexed = lex_file_2183;
            auto report = render_diags(job_1->text, lexed.diags);
            (prism_rtl::finished(Outcome_{.text = prism_rtl::cat(lexer::render_tokens(lexed->tokens), report, "\n"), .failed = any_errors(lexed.diags), .report = report}));
        });
    });
    })
        : ({
        auto parsed = job->fragment
            ? parser::parse_fragment(job->text)
            : parser::parse_file(job->text);
        auto report = render_diags(job->text, parsed.diags);
        (prism_rtl::finished(Outcome_{.text = prism_rtl::cat(sexp::sexp_module(parsed.tree), report, "\n"), .failed = any_errors(parsed.diags), .report = report}));
    });
}


/// `Start FrontEnd, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Outcome_> start_front_end(Job_ job) {
    return std::make_shared<FrontEnd>(job);
}


/// AnyErrors: fn [Diag] -> Bool
bool any_errors(const Array<ast::Diag>& ds) {
    return fold(ds, false, [&](const bool& seen, const ast::Diag& d) { return seen || (d.stage != Text("out")); });
}


/// RenderDiags: fn Text, [Diag] -> Text
Text render_diags(const Text& text, const Array<ast::Diag>& ds) {
    auto starts = line_starts(text);
    return lexer::join(each(ds, [&](const ast::Diag& d) { return render_diag(text, starts, d); }), Text("\n"));
}


/// RenderDiag: fn Text, [Nat], Diag -> Text
Text render_diag(const Text& text, const Array<Nat>& starts, const ast::Diag& d) {
    auto line = line_of(starts, d.span.start);
    auto col = lexer::column_of(text, or_(index(starts, line), Nat(0u)), d.span.start) + Nat(1u);
    auto at_ = prism_rtl::cat(line + Nat(1u), ":", col);
    return ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = d.feature;
        if (prism_rtl::is_some(_m)) {
            auto&& f = prism_rtl::some_of(_m);
            _v.set(prism_rtl::cat(at_, ": out of scope (", f, "): ", d.message));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(prism_rtl::cat(at_, ": ", d.message));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// LineStarts: fn Text -> [Nat]
Array<Nat> line_starts(const Text& text) {
    auto&& _starts = fold(split(text, Text("\n")), std::tuple{Array<Nat>{}, Nat(0u)}, [&](const std::tuple<Array<Nat>, Nat>& _p0, const Text& line) {
        auto&& acc = std::get<0>(_p0);
        auto&& at_ = std::get<1>(_p0);
        return std::tuple{prelude::push(acc, at_), (at_ + len_text(line)) + Nat(1u)};
    });
    auto&& starts = std::get<0>(_starts);
    return starts;
}


/// LineOf: fn [Nat], Nat -> Nat
Nat line_of(const Array<Nat>& starts, const Nat& offset) {
    return lexer::dec(fold(starts, Nat(0u), [&](const Nat& n, const Nat& s) { return s <= offset ? n + Nat(1u) : n; }));
}


/// let preludeFiles
Array<Text> prelude_files() {
    return Array(std::vector{Text("prelude.prism"), Text("ui.prism"), Text("fs.prism"), Text("process.prism"), Text("time.prism"), Text("test.prism"), Text("gui.prism")});
}


/// ?OptionValue: fn [Text], Text -> ?Text
std::optional<Text> option_value(const Array<Text>& args, const Text& name) {
    return fold(check_errors::range0(len(args)), std::optional<Text>{}, [&](const std::optional<Text>& found_opt, const Nat& i) {
        return index(args, i) == std::optional(name)
            ? index(args, i + Nat(1u))
            : found_opt;
    });
}


/// BadOptions: fn [Text], [Text], [Text] -> [Text]
Array<Text> bad_options(const Array<Text>& args, const Array<Text>& flags, const Array<Text>& valued) {
    auto [bad, owed] = fold(args, std::tuple{Array<Text>{}, Text("")}, [&](const std::tuple<Array<Text>, Text>& _p0, const Text& a) {
        auto&& acc = std::get<0>(_p0);
        auto&& owed = std::get<1>(_p0);
        return owed != Text("")
            ? std::tuple{acc, Text("")}
            : check_types::has_text(valued, a)
            ? std::tuple{acc, a}
            : lexer::has_prefix(a, Text("-")) && (!check_types::has_text(flags, a))
            ? std::tuple{check_types::add_text(acc, prism_rtl::cat("unknown option ", a)), Text("")}
            : std::tuple{acc, Text("")};
    });
    return owed == Text("")
        ? bad
        : check_types::add_text(bad, prism_rtl::cat(owed, " takes a value"));
}


// `@Refuse` is inlined where it is applied.

/// PlainArgs: fn [Text] -> [Text]
Array<Text> plain_args(const Array<Text>& args) {
    auto takes_value = Array(std::vector{Text("--prelude"), Text("--out"), Text("--world")});
    auto&& _kept = fold(args, std::tuple{Array<Text>{}, false}, [&](const std::tuple<Array<Text>, bool>& _p0, const Text& a) {
        auto&& acc = std::get<0>(_p0);
        auto&& skip = std::get<1>(_p0);
        return skip
            ? std::tuple{acc, false}
            : check_types::has_text(takes_value, a)
            ? std::tuple{acc, true}
            : lexer::has_prefix(a, Text("--"))
            ? std::tuple{acc, false}
            : std::tuple{prelude::push(acc, a), false};
    });
    auto&& kept = std::get<0>(_kept);
    return kept;
}


/// CheckFiles: unbounded fn CheckJob -> Outcome
Outcome_ check_files(const CheckJob& job) {
    auto parsed = run_to_end(each_job(job->files, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, Text, parser::Parsed>>(std::tuple<Text, Text>)>>(prism_rtl::rc([=](std::tuple<Text, Text> p0) {
        return entered(once_job([=]() {
            return ({
                auto [path_, text] = p0;
                call_then(parser::start_parse_file(text), [=](parser::Parsed parse_file_6213) { return prism_rtl::finished(std::tuple{path_, text, parse_file_6213}); });
            });
        }));
    }))));
    auto user_mods = fold(parsed, Array<Text>{}, [&](const Array<Text>& acc, const std::tuple<Text, Text, parser::Parsed>& _p1) {
        auto&& p_ = std::get<2>(_p1);
        return prelude::push(acc, check_env::mod_name(p_.tree));
    });
    auto user_fams = fold(parsed, Array<Text>{}, [&](const Array<Text>& acc, const std::tuple<Text, Text, parser::Parsed>& _p1) {
        auto&& p_ = std::get<2>(_p1);
        return append(acc, tag_families(p_.tree));
    });
    auto pre_parsed = run_to_end(each_job(job->prelude, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, Text, parser::Parsed>>(std::tuple<Text, Text>)>>(prism_rtl::rc([=](std::tuple<Text, Text> p0) {
        return entered(once_job([=]() {
            return ({
                auto [path_, text] = p0;
                call_then(parser::start_parse_file(text), [=](parser::Parsed parse_file_6498) { return prism_rtl::finished(std::tuple{path_, text, parse_file_6498}); });
            });
        }));
    }))));
    auto kept = filter(pre_parsed, [&](const std::tuple<Text, Text, parser::Parsed>& _p0) {
        auto&& p_ = std::get<2>(_p0);
        return (!check_types::has_text(user_mods, check_env::mod_name(p_.tree))) && (!any_in(tag_families(p_.tree), user_fams));
    });
    auto all = append(parsed, kept);
    auto parse_diags = fold(all, Text(""), [&](const Text& acc, const std::tuple<Text, Text, parser::Parsed>& _p1) {
        auto&& path_ = std::get<0>(_p1);
        auto&& text = std::get<1>(_p1);
        auto&& p_ = std::get<2>(_p1);
        return any_errors(p_.diags)
            ? prism_rtl::cat(acc, render_parse(path_, text, p_.diags))
            : acc;
    });
    return parse_diags != Text("")
        ? Outcome_{.text = prism_rtl::cat(parse_diags, "parse errors\n"), .failed = true, .report = prism_rtl::cat(parse_diags, "parse errors")}
        : ({
        auto srcs = each(all, [&](const std::tuple<Text, Text, parser::Parsed>& _p0) {
            auto&& path_ = std::get<0>(_p0);
            auto&& text = std::get<1>(_p0);
            return check_errors::mk_src(path_, text);
        });
        auto trees = each(all, [&](const std::tuple<Text, Text, parser::Parsed>& _p0) {
            auto&& p_ = std::get<2>(_p0);
            return p_.tree;
        });
        auto report = check_passes::check_program(srcs, trees, job->world, len(parsed), job->typed, job->unused);
        auto summary = report.errors == Nat(0u)
            ? Text("no errors\n")
            : prism_rtl::cat(report.errors, " error", report.errors == Nat(1u) ? Text("") : Text("s"), "\n");
        auto shown = job->typed
            ? prism_rtl::cat(typed::typed_sexp(srcs, trees, len(parsed), report->typed), commented(prism_rtl::cat(report->text, summary)))
            : prism_rtl::cat(report->text, summary);
        Outcome_{.text = shown, .failed = report.errors > Nat(0u), .report = prism_rtl::cat(report->text, summary)};
    });
}


prism_rtl::Turn<Outcome_> CheckFiles::cycle() const {
    const auto& job = this->job;
    auto job_1 = job;
    return call_value(each_job(job_1->files, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, Text, parser::Parsed>>(std::tuple<Text, Text>)>>(prism_rtl::rc([=](std::tuple<Text, Text> p0) {
        return entered(once_job([=]() {
            return ({
                auto [path_, text] = p0;
                call_then(parser::start_parse_file(text), [=](parser::Parsed parse_file_6213) { return prism_rtl::finished(std::tuple{path_, text, parse_file_6213}); });
            });
        }));
    }))), [=](Array<std::tuple<Text, Text, parser::Parsed>> each_6164) {
        return ({
            auto parsed = each_6164;
            auto user_mods = fold(parsed, Array<Text>{}, [&](const Array<Text>& acc, const std::tuple<Text, Text, parser::Parsed>& _p1) {
                auto&& p_ = std::get<2>(_p1);
                return prelude::push(acc, check_env::mod_name(p_.tree));
            });
            auto user_fams = fold(parsed, Array<Text>{}, [&](const Array<Text>& acc, const std::tuple<Text, Text, parser::Parsed>& _p1) {
                auto&& p_ = std::get<2>(_p1);
                return append(acc, tag_families(p_.tree));
            });
            call_value(each_job(job_1->prelude, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, Text, parser::Parsed>>(std::tuple<Text, Text>)>>(prism_rtl::rc([=](std::tuple<Text, Text> p0) {
            return entered(once_job([=]() {
                return ({
                    auto [path_, text] = p0;
                    call_then(parser::start_parse_file(text), [=](parser::Parsed parse_file_6498) { return prism_rtl::finished(std::tuple{path_, text, parse_file_6498}); });
                });
            }));
        }))), [=](Array<std::tuple<Text, Text, parser::Parsed>> each_6447) {
            return ({
                auto pre_parsed = each_6447;
                auto kept = filter(pre_parsed, [&](const std::tuple<Text, Text, parser::Parsed>& _p0) {
                    auto&& p_ = std::get<2>(_p0);
                    return (!check_types::has_text(user_mods, check_env::mod_name(p_.tree))) && (!any_in(tag_families(p_.tree), user_fams));
                });
                auto all = append(parsed, kept);
                auto parse_diags = fold(all, Text(""), [&](const Text& acc, const std::tuple<Text, Text, parser::Parsed>& _p1) {
                    auto&& path_ = std::get<0>(_p1);
                    auto&& text = std::get<1>(_p1);
                    auto&& p_ = std::get<2>(_p1);
                    return any_errors(p_.diags)
                        ? prism_rtl::cat(acc, render_parse(path_, text, p_.diags))
                        : acc;
                });
                parse_diags != Text("")
                ? prism_rtl::finished(Outcome_{.text = prism_rtl::cat(parse_diags, "parse errors\n"), .failed = true, .report = prism_rtl::cat(parse_diags, "parse errors")})
                : ({
                auto srcs = each(all, [&](const std::tuple<Text, Text, parser::Parsed>& _p0) {
                    auto&& path_ = std::get<0>(_p0);
                    auto&& text = std::get<1>(_p0);
                    return check_errors::mk_src(path_, text);
                });
                auto trees = each(all, [&](const std::tuple<Text, Text, parser::Parsed>& _p0) {
                    auto&& p_ = std::get<2>(_p0);
                    return p_.tree;
                });
                call_then(check_passes::start_check_program(srcs, trees, job_1->world, len(parsed), job_1->typed, job_1->unused), [=](check_passes::Report_ check_program_7111) {
                return ({
                    auto report = check_program_7111;
                    auto summary = report.errors == Nat(0u)
                        ? Text("no errors\n")
                        : prism_rtl::cat(report.errors, " error", report.errors == Nat(1u) ? Text("") : Text("s"), "\n");
                    auto shown = job_1->typed
                        ? prism_rtl::cat(typed::typed_sexp(srcs, trees, len(parsed), report->typed), commented(prism_rtl::cat(report->text, summary)))
                        : prism_rtl::cat(report->text, summary);
                    (prism_rtl::finished(Outcome_{.text = shown, .failed = report.errors > Nat(0u), .report = prism_rtl::cat(report->text, summary)}));
                });
            });
            });
            });
        });
        });
    });
}


/// `Start CheckFiles, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Outcome_> start_check_files(CheckJob job) {
    return std::make_shared<CheckFiles>(job);
}


/// Commented: fn Text -> Text
Text commented(const Text& t) {
    return concat(each(filter(split(t, Text("\n")), [&](const Text& l) { return l != Text(""); }), [&](const Text& l) { return prism_rtl::cat("; ", l, "\n"); }));
}


/// TagFamilies: fn Module -> [Text]
Array<Text> tag_families(const ast::Module& m) {
    return fold(m.decls, Array<Text>{}, [&](const Array<Text>& acc, const ast::Decl& d) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = d.kind;
            if (prism_rtl::is<ast::DeclKind::DTag>(_m)) {
                auto&& t = prism_rtl::as<ast::DeclKind::DTag>(_m).a0;
                _v.set(prelude::push(acc, lexer::join(take(t.name->path_, lexer::dec(len(t.name->path_))), Text("."))));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


/// AnyIn: fn [Text], [Text] -> Bool
bool any_in(const Array<Text>& xs, const Array<Text>& ys) {
    return fold(xs, false, [&](const bool& seen, const Text& x) { return seen || check_types::has_text(ys, x); });
}


/// RenderParse: fn Text, Text, [Diag] -> Text
Text render_parse(const Text& path_, const Text& text, const Array<ast::Diag>& ds) {
    return concat(each(filter(ds, [&](const ast::Diag& d) { return d.stage != Text("out"); }), [&](const ast::Diag& d) { return prism_rtl::cat(path_, ":", render_diag(text, line_starts(text), d), "\n"); }));
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<std::shared_ptr<Main>> Main::make(Path path, Cx& cx) {
    auto first_0 = TRY(ok_or(cx.first_value(prism_rtl::to_pod(crate::Elem(crate::Elem::ProcessArgs{process::ProcessArgs{}}))), Fault::answer("no first value for Process.Args")));
    auto args = TRY(prism_rtl::from_pod<Array<Text>>(first_0));
    auto checking = fold(args, false, [&](const bool& seen, const Text& a) { return (seen || (a == Text("--check"))) || (a == Text("--typed")); });
    auto compiling = or_(index(args, Nat(0u)), Text("")) == Text("compile");
    auto node = std::shared_ptr<Main>(new Main(path, args, checking, compiling, std::nullopt, 0u, false));
    TRY(node->arm_build(cx));
    cx.added(node->path.at(0u), prism_rtl::to_pod(crate::Elem(crate::Elem::ProcessArgs{process::ProcessArgs{}})));
    return node;
}


/// An arm's result, which a building `if` of widgets drops.
Unit Main::arm_up(Unit v, Cx& cx) {

    return Unit{};
}


/// The `rebuild` at `this->path.at(1u)`: the old generation torn down (it ran to the end of the
/// tick), the next built at `this->path.at(1u).child(Segment::gen(g))` from the source after the tick.
Done Main::arm_build(Cx& cx) {
    if (auto old = std::exchange(this->arm, std::nullopt)) {
        (*old)->leave_row(cx);
        cx.leave_later(*old);
    }
    std::uint32_t g = this->arm_count;
    this->arm_count = g + 1;
    Path path = this->path.at(1u).child(Segment::gen(g));
    Unit value = Unit{};
    std::shared_ptr<Row> row = this->compiling
    ? static_cast<std::shared_ptr<Row>>(TRY(MainArmThen::make(path, value, prism_rtl::weaken(prism_rtl::share(this)), cx)))
    : static_cast<std::shared_ptr<Row>>(TRY(MainArmElse::make(path, value, prism_rtl::weaken(prism_rtl::share(this)), cx)));
    this->arm = row;
    return {};
}


Done Main::build(Cx& cx) {
    if (std::exchange(this->arm_stale, false)) {
        TRY(this->arm_build(cx));
    }
    return {};
}


Done Main::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() >= 2 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 1u && prism_rtl::is<pat::Gen>(at[1])) {
        auto&& g = prism_rtl::as<pat::Gen>(at[1]).a0;
        auto rest = at.subspan(2);
        ({
            auto row = this->arm;
            if (auto&& _m = row; prism_rtl::is_some(_m)) {
                auto&& row = prism_rtl::some_of(_m);
                if ((g + 1u) == this->arm_count) {
                    TRY(row->answer(rest, v, cx));
                }
            }
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<std::shared_ptr<MainArmThen>> MainArmThen::make(Path path, Unit value, std::weak_ptr<Main> parent, Cx& cx) {
    auto opts = drop(expect(prism_rtl::upgrade(parent), "the block outlives its rows")->args, Nat(1u));
    auto bad = bad_options(opts, Array<Text>{}, compile_valued());
    auto target_1 = or_(option_value(opts, Text("--target")), Text("rust"));
    auto node = std::shared_ptr<MainArmThen>(new MainArmThen(path, value, parent, opts, bad, target_1, std::nullopt, 0u, false));
    TRY(node->arm_build(cx));
    return node;
}


/// An arm's result, which a building `if` of widgets drops.
Unit MainArmThen::arm_up(Unit v, Cx& cx) {

    return Unit{};
}


/// The row left: its places are torn down.
Unit MainArmThen::remove_places(Cx& cx) const {
    if (auto&& _m = this->arm; prism_rtl::is_some(_m)) {
        auto&& row = prism_rtl::some_of(_m);
        row->leave_row(cx);
    }
    return Unit{};
}


/// The `rebuild` at `this->path.at(0u)`: the old generation torn down (it ran to the end of the
/// tick), the next built at `this->path.at(0u).child(Segment::gen(g))` from the source after the tick.
Done MainArmThen::arm_build(Cx& cx) {
    if (auto old = std::exchange(this->arm, std::nullopt)) {
        (*old)->leave_row(cx);
        cx.leave_later(*old);
    }
    std::uint32_t g = this->arm_count;
    this->arm_count = g + 1;
    Path path = this->path.at(0u).child(Segment::gen(g));
    Unit value = Unit{};
    std::shared_ptr<Row> row = len(this->bad) > Nat(0u)
    ? static_cast<std::shared_ptr<Row>>(TRY(MainArmThenArmThen::make(path, value, prism_rtl::weaken(prism_rtl::share(this)), cx)))
    : static_cast<std::shared_ptr<Row>>(TRY(MainArmThenArmElse::make(path, value, prism_rtl::weaken(prism_rtl::share(this)), cx)));
    this->arm = row;
    return {};
}


Done MainArmThen::build(Cx& cx) {
    if (std::exchange(this->arm_stale, false)) {
        TRY(this->arm_build(cx));
    }
    return {};
}


Done MainArmThen::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() >= 2 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 0u && prism_rtl::is<pat::Gen>(at[1])) {
        auto&& g = prism_rtl::as<pat::Gen>(at[1]).a0;
        auto rest = at.subspan(2);
        ({
            auto row = this->arm;
            if (auto&& _m = row; prism_rtl::is_some(_m)) {
                auto&& row = prism_rtl::some_of(_m);
                if ((g + 1u) == this->arm_count) {
                    TRY(row->answer(rest, v, cx));
                }
            }
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmThen::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<std::shared_ptr<MainArmThenArmThen>> MainArmThenArmThen::make(Path path, Unit value, std::weak_ptr<MainArmThen> parent, Cx& cx) {
    auto why = prism_rtl::cat(lexer::join(expect(prism_rtl::upgrade(parent), "the block outlives its rows")->bad, Text("; ")), " (compile takes -o OUT, --name NAME, --prelude DIR, --runtime PATH, --target rust|cpp)");
    std::shared_ptr<Port<Unit>> started_2_v_port = prism_rtl::make_new();
    std::shared_ptr<Port<Fallible<Unit>>> gave_up_v_port = prism_rtl::make_new();
    auto node = std::shared_ptr<MainArmThenArmThen>(new MainArmThenArmThen(path, value, parent, why, started_2_v_port, gave_up_v_port));
    cx.added(node->path.at(1u), prism_rtl::to_pod(crate::Elem(crate::Elem::PreludeUnwrap{PreludeUnwrap{}})));
    cx.on_started(node);
    return node;
}


/// `!started_2`.
Unit MainArmThenArmThen::started_2(Unit v, Cx& cx) {
    prism_rtl::ignore(this->started_2_v_port->fire(v, cx));
    this->gave_up(unexpected(Error("Prismc.Refused", this->why)), cx);
    return Unit{};
}


/// `!gave_up`.
Unit MainArmThenArmThen::gave_up(Fallible<Unit> v, Cx& cx) {
    prism_rtl::ignore(this->gave_up_v_port->fire(v, cx));
    cx.request(this->path.at(1u), std::nullopt, prism_rtl::to_pod(v));
    return Unit{};
}


/// `place_1`: an answer at its place.
Unit MainArmThenArmThen::place_1(Unit v, Cx& cx) {

    return Unit{};
}


/// The row left: its places are torn down.
Unit MainArmThenArmThen::remove_places(Cx& cx) const {
    cx.removed(this->path.at(1u));
    return Unit{};
}


Done MainArmThenArmThen::started(Cx& cx) {
    this->started_2(Unit{}, cx);
    return {};
}


Done MainArmThenArmThen::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() == 1 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 1u) {
        this->place_1(TRY(prism_rtl::from_pod<Unit>(v)), cx);
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmThenArmThen::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<std::shared_ptr<MainArmThenArmElse>> MainArmThenArmElse::make(Path path, Unit value, std::weak_ptr<MainArmThen> parent, Cx& cx) {
    auto node = std::shared_ptr<MainArmThenArmElse>(new MainArmThenArmElse(path, value, parent, std::nullopt, 0u, false));
    TRY(node->arm_build(cx));
    return node;
}


/// An arm's result, which a building `if` of widgets drops.
Unit MainArmThenArmElse::arm_up(Unit v, Cx& cx) {

    return Unit{};
}


/// The row left: its places are torn down.
Unit MainArmThenArmElse::remove_places(Cx& cx) const {
    if (auto&& _m = this->arm; prism_rtl::is_some(_m)) {
        auto&& row = prism_rtl::some_of(_m);
        row->leave_row(cx);
    }
    return Unit{};
}


/// The `rebuild` at `this->path.at(0u)`: the old generation torn down (it ran to the end of the
/// tick), the next built at `this->path.at(0u).child(Segment::gen(g))` from the source after the tick.
Done MainArmThenArmElse::arm_build(Cx& cx) {
    if (auto old = std::exchange(this->arm, std::nullopt)) {
        (*old)->leave_row(cx);
        cx.leave_later(*old);
    }
    std::uint32_t g = this->arm_count;
    this->arm_count = g + 1;
    Path path = this->path.at(0u).child(Segment::gen(g));
    Unit value = Unit{};
    std::shared_ptr<Row> row = (expect(prism_rtl::upgrade(this->parent), "the block outlives its rows")->target != Text("rust")) && (expect(prism_rtl::upgrade(this->parent), "the block outlives its rows")->target != Text("cpp"))
    ? static_cast<std::shared_ptr<Row>>(TRY(MainArmThenArmElseArmThen::make(path, value, prism_rtl::weaken(prism_rtl::share(this)), cx)))
    : static_cast<std::shared_ptr<Row>>(TRY(MainArmThenArmElseArmElse::make(path, value, prism_rtl::weaken(prism_rtl::share(this)), cx)));
    this->arm = row;
    return {};
}


Done MainArmThenArmElse::build(Cx& cx) {
    if (std::exchange(this->arm_stale, false)) {
        TRY(this->arm_build(cx));
    }
    return {};
}


Done MainArmThenArmElse::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() >= 2 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 0u && prism_rtl::is<pat::Gen>(at[1])) {
        auto&& g = prism_rtl::as<pat::Gen>(at[1]).a0;
        auto rest = at.subspan(2);
        ({
            auto row = this->arm;
            if (auto&& _m = row; prism_rtl::is_some(_m)) {
                auto&& row = prism_rtl::some_of(_m);
                if ((g + 1u) == this->arm_count) {
                    TRY(row->answer(rest, v, cx));
                }
            }
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmThenArmElse::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<std::shared_ptr<MainArmThenArmElseArmThen>> MainArmThenArmElseArmThen::make(Path path, Unit value, std::weak_ptr<MainArmThenArmElse> parent, Cx& cx) {
    auto why = prism_rtl::cat("unknown target ", expect(prism_rtl::upgrade(expect(prism_rtl::upgrade(parent), "the block outlives its rows")->parent), "the block outlives its rows")->target, " (rust, cpp)");
    std::shared_ptr<Port<Unit>> started_2_v_port = prism_rtl::make_new();
    std::shared_ptr<Port<Fallible<Unit>>> gave_up_v_port = prism_rtl::make_new();
    auto node = std::shared_ptr<MainArmThenArmElseArmThen>(new MainArmThenArmElseArmThen(path, value, parent, why, started_2_v_port, gave_up_v_port));
    cx.added(node->path.at(1u), prism_rtl::to_pod(crate::Elem(crate::Elem::PreludeUnwrap{PreludeUnwrap{}})));
    cx.on_started(node);
    return node;
}


/// `!started_2`.
Unit MainArmThenArmElseArmThen::started_2(Unit v, Cx& cx) {
    prism_rtl::ignore(this->started_2_v_port->fire(v, cx));
    this->gave_up(unexpected(Error("Prismc.Refused", this->why)), cx);
    return Unit{};
}


/// `!gave_up`.
Unit MainArmThenArmElseArmThen::gave_up(Fallible<Unit> v, Cx& cx) {
    prism_rtl::ignore(this->gave_up_v_port->fire(v, cx));
    cx.request(this->path.at(1u), std::nullopt, prism_rtl::to_pod(v));
    return Unit{};
}


/// `place_1`: an answer at its place.
Unit MainArmThenArmElseArmThen::place_1(Unit v, Cx& cx) {

    return Unit{};
}


/// The row left: its places are torn down.
Unit MainArmThenArmElseArmThen::remove_places(Cx& cx) const {
    cx.removed(this->path.at(1u));
    return Unit{};
}


Done MainArmThenArmElseArmThen::started(Cx& cx) {
    this->started_2(Unit{}, cx);
    return {};
}


Done MainArmThenArmElseArmThen::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() == 1 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 1u) {
        this->place_1(TRY(prism_rtl::from_pod<Unit>(v)), cx);
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmThenArmElseArmThen::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<std::shared_ptr<MainArmThenArmElseArmElse>> MainArmThenArmElseArmElse::make(Path path, Unit value, std::weak_ptr<MainArmThenArmElse> parent, Cx& cx) {
    auto opts = expect(prism_rtl::upgrade(expect(prism_rtl::upgrade(parent), "the block outlives its rows")->parent), "the block outlives its rows")->opts;
    auto named = compile_files(opts);
    auto dirs = filter(named, [&](const Text& f) { return !is_source_path(f); });
    auto files = filter(named, [&](const Text& f) { return is_source_path(f); });
    auto out_1 = or_(option_value(opts, Text("-o")), Text("prismc-out"));
    auto settings = CompileSettings{.out = out_1, .prelude = or_(option_value(opts, Text("--prelude")), Text("prelude")), .name = or_(option_value(opts, Text("--name")), Text("program")), .runtime = or_(option_value(opts, Text("--runtime")), runtime_for(out_1)), .target = or_(option_value(opts, Text("--target")), Text("rust"))};
    auto node = std::shared_ptr<MainArmThenArmElseArmElse>(new MainArmThenArmElseArmElse(path, value, parent, opts, named, dirs, files, out_1, settings, {}, {}, snapshot("the dynamic gathered by the `for` at place 0"), std::nullopt, 0u, false));
    TRY(node->rows_build(cx));
    node->rows_all_snap.take(node->rows_all_now(cx), cx);
    TRY(node->generation_build(cx));
    return node;
}


/// `!generation_fired`.
Unit MainArmThenArmElseArmElse::generation_fired(Unit v, Cx& cx) {

    return Unit{};
}


/// The source of the `for` at place 0 by key, at the read point: what its builder and its rows' entries read, computed once per write behind it.
Map<Nat, Text> MainArmThenArmElseArmElse::rows_source(const Cx& cx) const {
    return this->rows_source_cache.get(cx, [&]() { return indexed(this->dirs); });
}


/// The rows' results by key, computed live: what the snapshot of the `for`'s dynamic is taken from (pick ST).
Map<Nat, Array<Text>> MainArmThenArmElseArmElse::rows_all_now(const Cx& cx) const {
    return prism_rtl::fmap(this->rows, [&](const auto& _p0) {
        auto&& k = std::get<0>(_p0);
        auto&& row = std::get<1>(_p0);
        return std::tuple{k, row->result(cx)};
    });
}


/// The `for`'s dynamic, the rows' results by key, a structural dynamic (pick ST): one tick behind the rows, the snapshot of the tick before the tick the read point is after.
Map<Nat, Array<Text>> MainArmThenArmElseArmElse::rows_all(const Cx& cx) const {
    return this->rows_all_snap.get(cx);
}


/// The current generation's result fires the `rebuild`'s.
Unit MainArmThenArmElseArmElse::generation_up(Unit v, Cx& cx) {
    this->generation_fired(v, cx);
    return Unit{};
}


/// The row left: its places are torn down.
Unit MainArmThenArmElseArmElse::remove_places(Cx& cx) const {
    prism_rtl::for_each(prelude::values(this->rows), [&](auto&& row) { return row->leave_row(cx); });
    if (auto&& _m = this->generation; prism_rtl::is_some(_m)) {
        auto&& row = prism_rtl::some_of(_m);
        row->leave_row(cx);
    }
    return Unit{};
}


/// A row's result moved: the `for`'s gathered dynamic is marked, and its snapshot taken after the builder (pick ST).
Unit MainArmThenArmElseArmElse::rows_all_moved(Cx& cx) {
    this->rows_all_snap.mark(cx);
    cx.build_later(prism_rtl::share(this));
    return Unit{};
}


/// the dynamic gathered by the `for` at place 0, published: its snapshot of the tick before moved it, written as a hold is (pick ST).
Unit MainArmThenArmElseArmElse::rows_all_publish(Cx& cx) {
    if (this->rows_all_snap.published(cx)) {
        this->generation_stale = true;
        cx.build_later(prism_rtl::share(this));
    }
    return Unit{};
}


/// The rows of the `for` at `this->path.at(0u)`: rows whose key left are torn down, new keys are
/// built under it at `[k]` from the values after the tick; kept rows keep reading their
/// entry out of the source.
Done MainArmThenArmElseArmElse::rows_build(Cx& cx) {
    Map<Nat, Text> items = rows_source(cx);
    auto old = deref(this->rows);
    for (auto&& [k, row] : old) {
        if (!items.contains(k)) {
            row->leave_row(cx);
            cx.leave_later(row);
        }
    }
    decltype(old) next;
    for (auto&& [k, v] : items) {
        if (auto row = old.get(k)) next.insert(k, *row);
        else next.insert(k, TRY(MainArmThenArmElseArmElseRow::make(this->path.at(0u).child(Segment::key(prism_rtl::to_pod(k))), k, v, prism_rtl::weaken(prism_rtl::share(this)), cx)));
    }
    deref(this->rows) = next;
    // What the block reads of its rows (a `for` that gives a dynamic) moved.
    cx.dirty(prism_rtl::share(this));
    return {};
}


/// The `rebuild` at `this->path.at(1u)`: the old generation torn down (it ran to the end of the
/// tick), the next built at `this->path.at(1u).child(Segment::gen(g))` from the source after the tick.
Done MainArmThenArmElseArmElse::generation_build(Cx& cx) {
    if (auto old = std::exchange(this->generation, std::nullopt)) {
        (*old)->leave_row(cx);
        cx.leave_later(*old);
    }
    std::uint32_t g = this->generation_count;
    this->generation_count = g + 1;
    Path path = this->path.at(1u).child(Segment::gen(g));
    Map<Nat, Array<Text>> value = this->rows_all(cx);
    std::shared_ptr<Row> row = TRY(MainArmThenArmElseArmElseGen1::make(path, value, prism_rtl::weaken(prism_rtl::share(this)), cx));
    this->generation = row;
    return {};
}


Done MainArmThenArmElseArmElse::build(Cx& cx) {
    TRY(this->rows_build(cx));
    if (this->rows_all_snap.marked(cx)) {
        this->rows_all_snap.take_compared(this->rows_all_now(cx), cx);
        if (this->rows_all_snap.queue(cx)) {
            auto node = prism_rtl::share(this);
            cx.answer_later([=](Cx& cx) -> Done { node->rows_all_publish(cx); return {}; });
        }
    }
    if (std::exchange(this->generation_stale, false)) {
        TRY(this->generation_build(cx));
    }
    return {};
}


Done MainArmThenArmElseArmElse::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() >= 2 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 0u && prism_rtl::is<pat::Key>(at[1])) {
        auto&& k = prism_rtl::as<pat::Key>(at[1]).a0;
        auto rest = at.subspan(2);
        ({
            auto row = cloned(this->rows.get(TRY(prism_rtl::from_pod<Nat>(k))));
            if (auto&& _m = row; prism_rtl::is_some(_m)) {
                auto&& row = prism_rtl::some_of(_m);
                TRY(row->answer(rest, v, cx));
            }
            Unit{};
        });
    } else if (at.size() >= 2 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 1u && prism_rtl::is<pat::Gen>(at[1])) {
        auto&& g = prism_rtl::as<pat::Gen>(at[1]).a0;
        auto rest = at.subspan(2);
        ({
            auto row = this->generation;
            if (auto&& _m = row; prism_rtl::is_some(_m)) {
                auto&& row = prism_rtl::some_of(_m);
                if ((g + 1u) == this->generation_count) {
                    TRY(row->answer(rest, v, cx));
                }
            }
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmThenArmElseArmElse::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<std::shared_ptr<MainArmThenArmElseArmElseGen1>> MainArmThenArmElseArmElseGen1::make(Path path, Map<Nat, Array<Text>> value, std::weak_ptr<MainArmThenArmElseArmElse> parent, Cx& cx) {
    auto settings = expect(prism_rtl::upgrade(parent), "the block outlives its rows")->settings;
    auto files = append(expect(prism_rtl::upgrade(parent), "the block outlives its rows")->files, fold(values(value), Array<Text>{}, [&](const Array<Text>& acc, const Array<Text>& l) { return append(acc, l); }));
    auto prelude = each(prelude_files(), [&](const Text& f) { return prism_rtl::cat(settings->prelude, "/", f); });
    auto node = std::shared_ptr<MainArmThenArmElseArmElseGen1>(new MainArmThenArmElseArmElseGen1(path, value, parent, settings, files, prelude, {}, {}, snapshot("the dynamic gathered by the `for` at place 0"), std::nullopt, 0u, false));
    TRY(node->rows_build(cx));
    node->rows_all_snap.take(node->rows_all_now(cx), cx);
    TRY(node->generation_build(cx));
    return node;
}


/// `!generation_fired`.
Unit MainArmThenArmElseArmElseGen1::generation_fired(Unit v, Cx& cx) {

    return Unit{};
}


/// The source of the `for` at place 0 by key, at the read point: what its builder and its rows' entries read, computed once per write behind it.
Map<Nat, Text> MainArmThenArmElseArmElseGen1::rows_source(const Cx& cx) const {
    return this->rows_source_cache.get(cx, [&]() { return indexed(append(this->files, this->prelude)); });
}


/// The rows' results by key, computed live: what the snapshot of the `for`'s dynamic is taken from (pick ST).
Map<Nat, Fallible<fs::Contents>> MainArmThenArmElseArmElseGen1::rows_all_now(const Cx& cx) const {
    return prism_rtl::fmap(this->rows, [&](const auto& _p0) {
        auto&& k = std::get<0>(_p0);
        auto&& row = std::get<1>(_p0);
        return std::tuple{k, row->result(cx)};
    });
}


/// The `for`'s dynamic, the rows' results by key, a structural dynamic (pick ST): one tick behind the rows, the snapshot of the tick before the tick the read point is after.
Map<Nat, Fallible<fs::Contents>> MainArmThenArmElseArmElseGen1::rows_all(const Cx& cx) const {
    return this->rows_all_snap.get(cx);
}


/// The current generation's result fires the `rebuild`'s.
Unit MainArmThenArmElseArmElseGen1::generation_up(Unit v, Cx& cx) {
    this->generation_fired(v, cx);
    return Unit{};
}


/// The row left: its places are torn down.
Unit MainArmThenArmElseArmElseGen1::remove_places(Cx& cx) const {
    prism_rtl::for_each(prelude::values(this->rows), [&](auto&& row) { return row->leave_row(cx); });
    if (auto&& _m = this->generation; prism_rtl::is_some(_m)) {
        auto&& row = prism_rtl::some_of(_m);
        row->leave_row(cx);
    }
    return Unit{};
}


/// A row's result moved: the `for`'s gathered dynamic is marked, and its snapshot taken after the builder (pick ST).
Unit MainArmThenArmElseArmElseGen1::rows_all_moved(Cx& cx) {
    this->rows_all_snap.mark(cx);
    cx.build_later(prism_rtl::share(this));
    return Unit{};
}


/// the dynamic gathered by the `for` at place 0, published: its snapshot of the tick before moved it, written as a hold is (pick ST).
Unit MainArmThenArmElseArmElseGen1::rows_all_publish(Cx& cx) {
    if (this->rows_all_snap.published(cx)) {
        this->generation_stale = true;
        cx.build_later(prism_rtl::share(this));
    }
    return Unit{};
}


/// The rows of the `for` at `this->path.at(0u)`: rows whose key left are torn down, new keys are
/// built under it at `[k]` from the values after the tick; kept rows keep reading their
/// entry out of the source.
Done MainArmThenArmElseArmElseGen1::rows_build(Cx& cx) {
    Map<Nat, Text> items = rows_source(cx);
    auto old = deref(this->rows);
    for (auto&& [k, row] : old) {
        if (!items.contains(k)) {
            row->leave_row(cx);
            cx.leave_later(row);
        }
    }
    decltype(old) next;
    for (auto&& [k, v] : items) {
        if (auto row = old.get(k)) next.insert(k, *row);
        else next.insert(k, TRY(MainArmThenArmElseArmElseGen1Row::make(this->path.at(0u).child(Segment::key(prism_rtl::to_pod(k))), k, v, prism_rtl::weaken(prism_rtl::share(this)), cx)));
    }
    deref(this->rows) = next;
    // What the block reads of its rows (a `for` that gives a dynamic) moved.
    cx.dirty(prism_rtl::share(this));
    return {};
}


/// The `rebuild` at `this->path.at(1u)`: the old generation torn down (it ran to the end of the
/// tick), the next built at `this->path.at(1u).child(Segment::gen(g))` from the source after the tick.
Done MainArmThenArmElseArmElseGen1::generation_build(Cx& cx) {
    if (auto old = std::exchange(this->generation, std::nullopt)) {
        (*old)->leave_row(cx);
        cx.leave_later(*old);
    }
    std::uint32_t g = this->generation_count;
    this->generation_count = g + 1;
    Path path = this->path.at(1u).child(Segment::gen(g));
    Map<Nat, Fallible<fs::Contents>> value = this->rows_all(cx);
    std::shared_ptr<Row> row = TRY(MainArmThenArmElseArmElseGen1Gen1::make(path, value, prism_rtl::weaken(prism_rtl::share(this)), cx));
    this->generation = row;
    return {};
}


Done MainArmThenArmElseArmElseGen1::build(Cx& cx) {
    TRY(this->rows_build(cx));
    if (this->rows_all_snap.marked(cx)) {
        this->rows_all_snap.take_compared(this->rows_all_now(cx), cx);
        if (this->rows_all_snap.queue(cx)) {
            auto node = prism_rtl::share(this);
            cx.answer_later([=](Cx& cx) -> Done { node->rows_all_publish(cx); return {}; });
        }
    }
    if (std::exchange(this->generation_stale, false)) {
        TRY(this->generation_build(cx));
    }
    return {};
}


Done MainArmThenArmElseArmElseGen1::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() >= 2 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 0u && prism_rtl::is<pat::Key>(at[1])) {
        auto&& k = prism_rtl::as<pat::Key>(at[1]).a0;
        auto rest = at.subspan(2);
        ({
            auto row = cloned(this->rows.get(TRY(prism_rtl::from_pod<Nat>(k))));
            if (auto&& _m = row; prism_rtl::is_some(_m)) {
                auto&& row = prism_rtl::some_of(_m);
                TRY(row->answer(rest, v, cx));
            }
            Unit{};
        });
    } else if (at.size() >= 2 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 1u && prism_rtl::is<pat::Gen>(at[1])) {
        auto&& g = prism_rtl::as<pat::Gen>(at[1]).a0;
        auto rest = at.subspan(2);
        ({
            auto row = this->generation;
            if (auto&& _m = row; prism_rtl::is_some(_m)) {
                auto&& row = prism_rtl::some_of(_m);
                if ((g + 1u) == this->generation_count) {
                    TRY(row->answer(rest, v, cx));
                }
            }
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmThenArmElseArmElseGen1::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<std::shared_ptr<MainArmThenArmElseArmElseGen1Gen1>> MainArmThenArmElseArmElseGen1Gen1::make(Path path, Map<Nat, Fallible<fs::Contents>> value, std::weak_ptr<MainArmThenArmElseArmElseGen1> parent, Cx& cx) {
    auto settings = expect(prism_rtl::upgrade(parent), "the block outlives its rows")->settings;
    auto files = expect(prism_rtl::upgrade(parent), "the block outlives its rows")->files;
    auto prelude = expect(prism_rtl::upgrade(parent), "the block outlives its rows")->prelude;
    auto contents = value;
    std::shared_ptr<Port<Compiled>> done_v_port = prism_rtl::make_new();
    auto n = len(files);
    auto texts = each(check_errors::range0(len(append(files, prelude))), [&](const Nat& i) { return contents_text(or_(prelude::get(contents, i), fs::Contents{.text = Text("")})); });
    auto mine = each(check_errors::range0(n), [&](const Nat& i) { return std::tuple{or_(index(files, i), Text("")), or_(index(texts, i), Text(""))}; });
    auto theirs = each(check_errors::range0(len(prelude)), [&](const Nat& i) { return std::tuple{or_(index(prelude, i), Text("")), or_(index(texts, n + i), Text(""))}; });
    auto present = filter(theirs, [&](const std::tuple<Text, Text>& _p0) {
        auto&& t = std::get<1>(_p0);
        return t != Text("");
    });
    std::optional<Compiled> outcome_init = std::optional<Compiled>{};
    auto node = std::shared_ptr<MainArmThenArmElseArmElseGen1Gen1>(new MainArmThenArmElseArmElseGen1Gen1(path, value, parent, settings, files, prelude, contents, done_v_port, n, texts, mine, theirs, present, {start_compile_program(CompileJob{.files = mine, .prelude = present, .name = settings.name, .runtime = settings.runtime, .target = settings->target}), cx}, {}, {}, {}, {outcome_init, cx}, std::nullopt, 0u, false));
    TRY(node->generation_build(cx));
    cx.on_started(node);
    return node;
}


/// `!done`.
Unit MainArmThenArmElseArmElseGen1Gen1::done(Compiled v, Cx& cx) {
    prism_rtl::ignore(this->done_v_port->fire(v, cx));
    this->outcome.set(std::optional(v), cx);
    this->generation_stale = true;
    cx.build_later(prism_rtl::share(this));
    return Unit{};
}


/// `@started`, the tick after the build.
Unit MainArmThenArmElseArmElseGen1Gen1::run_started(Unit v, Cx& cx) {
    this->run_turn_left.set(v, cx);
    cx.wake(WAKE, prism_rtl::share(this));
    return Unit{};
}


/// An `@Defer` firing, the tick after it was armed.
Unit MainArmThenArmElseArmElseGen1Gen1::run_again_(Unit v, Cx& cx) {
    this->run_turn_right.set(v, cx);
    cx.wake(WAKE, prism_rtl::share(this));
    return Unit{};
}


/// The merge `run_turn`, decided in the wake.
Unit MainArmThenArmElseArmElseGen1Gen1::run_turn(Unit v, Cx& cx) {
    {
        auto&& _m = this->run_job.get(cx)->cycle();
        if (_m.if_more()) {
            auto&& next = _m.if_more()->next;
            this->run_job.set(next, cx);
            this->run_again.arm(Unit{}, prism_rtl::share(this), cx);
        } else if (_m.if_finished()) {
            auto&& b = _m.if_finished()->value;
            this->done(b, cx);
        }
    }
    return Unit{};
}


/// `!generation_fired`.
Unit MainArmThenArmElseArmElseGen1Gen1::generation_fired(Unit v, Cx& cx) {

    return Unit{};
}


/// The current generation's result fires the `rebuild`'s.
Unit MainArmThenArmElseArmElseGen1Gen1::generation_up(Unit v, Cx& cx) {
    this->generation_fired(v, cx);
    return Unit{};
}


/// The row left: its places are torn down.
Unit MainArmThenArmElseArmElseGen1Gen1::remove_places(Cx& cx) const {
    if (auto&& _m = this->generation; prism_rtl::is_some(_m)) {
        auto&& row = prism_rtl::some_of(_m);
        row->leave_row(cx);
    }
    return Unit{};
}


/// The `rebuild` at `this->path.at(1u)`: the old generation torn down (it ran to the end of the
/// tick), the next built at `this->path.at(1u).child(Segment::gen(g))` from the source after the tick.
Done MainArmThenArmElseArmElseGen1Gen1::generation_build(Cx& cx) {
    if (auto old = std::exchange(this->generation, std::nullopt)) {
        (*old)->leave_row(cx);
        cx.leave_later(*old);
    }
    std::uint32_t g = this->generation_count;
    this->generation_count = g + 1;
    Path path = this->path.at(1u).child(Segment::gen(g));
    std::optional<Compiled> value = this->outcome.get(cx);
    std::shared_ptr<Row> row = ({
    __label__ _done;
    prism_rtl::Slot<std::shared_ptr<Row>> _v;
    auto&& _m = std::tuple{this->settings.out, value};
    if (prism_rtl::is_none(std::get<1>(_m))) {
        auto&& out = std::get<0>(_m);
        _v.set(static_cast<std::shared_ptr<Row>>(TRY(MainArmThenArmElseArmElseGen1Gen1Gen0::make(path, out, prism_rtl::weaken(prism_rtl::share(this)), cx))));
        goto _done;
    }
    if (prism_rtl::is_some(std::get<1>(_m))) {
        auto&& out = std::get<0>(_m);
        auto&& o = prism_rtl::some_of(std::get<1>(_m));
        _v.set(static_cast<std::shared_ptr<Row>>(TRY(MainArmThenArmElseArmElseGen1Gen1Gen1::make(path, out, o, prism_rtl::weaken(prism_rtl::share(this)), cx))));
        goto _done;
    }
    prism_rtl::unreachable("no arm matched");
_done:
    _v.take();
});
    this->generation = row;
    return {};
}


Done MainArmThenArmElseArmElseGen1Gen1::wake(Cx& cx) {
    if (true) {
        auto left = this->run_turn_left.take(cx);
        auto right = this->run_turn_right.take(cx);
        if (auto&& _m = left; prism_rtl::is_some(_m)) {
            auto&& v = prism_rtl::some_of(_m);
            this->run_turn(v, cx);
        } else if (auto&& _m = right; prism_rtl::is_some(_m)) {
            auto&& v = prism_rtl::some_of(_m);
            this->run_turn(v, cx);
        }
    }
    return {};
}


Done MainArmThenArmElseArmElseGen1Gen1::started(Cx& cx) {
    this->run_started(Unit{}, cx);
    return {};
}


Done MainArmThenArmElseArmElseGen1Gen1::deferred(Cx& cx) {
    if (auto&& _m = this->run_again.fired(cx); prism_rtl::is_some(_m)) {
        auto&& v = prism_rtl::some_of(_m);
        this->run_again_(v, cx);
    }
    return {};
}


Done MainArmThenArmElseArmElseGen1Gen1::build(Cx& cx) {
    if (std::exchange(this->generation_stale, false)) {
        TRY(this->generation_build(cx));
    }
    return {};
}


Done MainArmThenArmElseArmElseGen1Gen1::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() >= 2 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 1u && prism_rtl::is<pat::Gen>(at[1])) {
        auto&& g = prism_rtl::as<pat::Gen>(at[1]).a0;
        auto rest = at.subspan(2);
        ({
            auto row = this->generation;
            if (auto&& _m = row; prism_rtl::is_some(_m)) {
                auto&& row = prism_rtl::some_of(_m);
                if ((g + 1u) == this->generation_count) {
                    TRY(row->answer(rest, v, cx));
                }
            }
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmThenArmElseArmElseGen1Gen1::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<std::shared_ptr<MainArmThenArmElseArmElseGen1Gen1Gen0>> MainArmThenArmElseArmElseGen1Gen1Gen0::make(Path path, Text out, std::weak_ptr<MainArmThenArmElseArmElseGen1Gen1> parent, Cx& cx) {
    auto node = std::shared_ptr<MainArmThenArmElseArmElseGen1Gen1Gen0>(new MainArmThenArmElseArmElseGen1Gen1Gen0(path, out, parent));
    return node;
}


/// The row left: its places are torn down.
Unit MainArmThenArmElseArmElseGen1Gen1Gen0::remove_places(Cx& cx) const {

    return Unit{};
}


void MainArmThenArmElseArmElseGen1Gen1Gen0::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<std::shared_ptr<MainArmThenArmElseArmElseGen1Gen1Gen1>> MainArmThenArmElseArmElseGen1Gen1Gen1::make(Path path, Text out, Compiled o, std::weak_ptr<MainArmThenArmElseArmElseGen1Gen1> parent, Cx& cx) {
    std::shared_ptr<Port<Unit>> started_2_v_port = prism_rtl::make_new();
    std::shared_ptr<Port<Fallible<Unit>>> verdict_v_port = prism_rtl::make_new();
    auto node = std::shared_ptr<MainArmThenArmElseArmElseGen1Gen1Gen1>(new MainArmThenArmElseArmElseGen1Gen1Gen1(path, out, o, parent, started_2_v_port, verdict_v_port, {}, {}, snapshot("the dynamic gathered by the `for` at place 0")));
    TRY(node->rows_build(cx));
    node->rows_all_snap.take(node->rows_all_now(cx), cx);
    cx.added(node->path.at(2u), prism_rtl::to_pod(crate::Elem(crate::Elem::PreludeUnwrap{PreludeUnwrap{}})));
    cx.on_started(node);
    return node;
}


/// `!started_2`.
Unit MainArmThenArmElseArmElseGen1Gen1Gen1::started_2(Unit v, Cx& cx) {
    prism_rtl::ignore(this->started_2_v_port->fire(v, cx));
    this->verdict(this->o.failed
        ? unexpected(Error("Prismc.Refused", this->o.report))
        : Expected<std::decay_t<decltype(Unit{})>, std::decay_t<decltype(Error("Prismc.Refused", this->o.report))>>(Unit{}), cx);
    return Unit{};
}


/// `!verdict`.
Unit MainArmThenArmElseArmElseGen1Gen1Gen1::verdict(Fallible<Unit> v, Cx& cx) {
    prism_rtl::ignore(this->verdict_v_port->fire(v, cx));
    cx.request(this->path.at(2u), std::nullopt, prism_rtl::to_pod(v));
    return Unit{};
}


/// `place_2`: an answer at its place.
Unit MainArmThenArmElseArmElseGen1Gen1Gen1::place_2(Unit v, Cx& cx) {

    return Unit{};
}


/// The source of the `for` at place 0 by key, at the read point: what its builder and its rows' entries read, computed once per write behind it.
Map<Nat, std::tuple<Text, Text>> MainArmThenArmElseArmElseGen1Gen1Gen1::rows_source(const Cx& cx) const {
    return this->rows_source_cache.get(cx, [&]() { return indexed(this->o.files); });
}


/// The rows' results by key, computed live: what the snapshot of the `for`'s dynamic is taken from (pick ST).
Map<Nat, fs::WriteState> MainArmThenArmElseArmElseGen1Gen1Gen1::rows_all_now(const Cx& cx) const {
    return prism_rtl::fmap(this->rows, [&](const auto& _p0) {
        auto&& k = std::get<0>(_p0);
        auto&& row = std::get<1>(_p0);
        return std::tuple{k, row->result(cx)};
    });
}


/// The `for`'s dynamic, the rows' results by key, a structural dynamic (pick ST): one tick behind the rows, the snapshot of the tick before the tick the read point is after.
Map<Nat, fs::WriteState> MainArmThenArmElseArmElseGen1Gen1Gen1::rows_all(const Cx& cx) const {
    return this->rows_all_snap.get(cx);
}


/// The row left: its places are torn down.
Unit MainArmThenArmElseArmElseGen1Gen1Gen1::remove_places(Cx& cx) const {
    cx.removed(this->path.at(2u));
    prism_rtl::for_each(prelude::values(this->rows), [&](auto&& row) { return row->leave_row(cx); });
    return Unit{};
}


/// A row's result moved: the `for`'s gathered dynamic is marked, and its snapshot taken after the builder (pick ST).
Unit MainArmThenArmElseArmElseGen1Gen1Gen1::rows_all_moved(Cx& cx) {
    this->rows_all_snap.mark(cx);
    cx.build_later(prism_rtl::share(this));
    return Unit{};
}


/// the dynamic gathered by the `for` at place 0, published: its snapshot of the tick before moved it, written as a hold is (pick ST).
Unit MainArmThenArmElseArmElseGen1Gen1Gen1::rows_all_publish(Cx& cx) {
    if (this->rows_all_snap.published(cx)) {
    }
    return Unit{};
}


/// The rows of the `for` at `this->path.at(0u)`: rows whose key left are torn down, new keys are
/// built under it at `[k]` from the values after the tick; kept rows keep reading their
/// entry out of the source.
Done MainArmThenArmElseArmElseGen1Gen1Gen1::rows_build(Cx& cx) {
    Map<Nat, std::tuple<Text, Text>> items = rows_source(cx);
    auto old = deref(this->rows);
    for (auto&& [k, row] : old) {
        if (!items.contains(k)) {
            row->leave_row(cx);
            cx.leave_later(row);
        }
    }
    decltype(old) next;
    for (auto&& [k, v] : items) {
        if (auto row = old.get(k)) next.insert(k, *row);
        else next.insert(k, TRY(MainArmThenArmElseArmElseGen1Gen1Gen1Row::make(this->path.at(0u).child(Segment::key(prism_rtl::to_pod(k))), k, v, prism_rtl::weaken(prism_rtl::share(this)), this->out, cx)));
    }
    deref(this->rows) = next;
    // What the block reads of its rows (a `for` that gives a dynamic) moved.
    cx.dirty(prism_rtl::share(this));
    return {};
}


Done MainArmThenArmElseArmElseGen1Gen1Gen1::started(Cx& cx) {
    this->started_2(Unit{}, cx);
    return {};
}


Done MainArmThenArmElseArmElseGen1Gen1Gen1::build(Cx& cx) {
    TRY(this->rows_build(cx));
    if (this->rows_all_snap.marked(cx)) {
        this->rows_all_snap.take_compared(this->rows_all_now(cx), cx);
        if (this->rows_all_snap.queue(cx)) {
            auto node = prism_rtl::share(this);
            cx.answer_later([=](Cx& cx) -> Done { node->rows_all_publish(cx); return {}; });
        }
    }
    return {};
}


Done MainArmThenArmElseArmElseGen1Gen1Gen1::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() == 1 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 2u) {
        this->place_2(TRY(prism_rtl::from_pod<Unit>(v)), cx);
    } else if (at.size() >= 2 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 0u && prism_rtl::is<pat::Key>(at[1])) {
        auto&& k = prism_rtl::as<pat::Key>(at[1]).a0;
        auto rest = at.subspan(2);
        ({
            auto row = cloned(this->rows.get(TRY(prism_rtl::from_pod<Nat>(k))));
            if (auto&& _m = row; prism_rtl::is_some(_m)) {
                auto&& row = prism_rtl::some_of(_m);
                TRY(row->answer(rest, v, cx));
            }
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmThenArmElseArmElseGen1Gen1Gen1::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<std::shared_ptr<MainArmThenArmElseArmElseGen1Gen1Gen1Row>> MainArmThenArmElseArmElseGen1Gen1Gen1Row::make(Path path, Nat key, std::tuple<Text, Text> value, std::weak_ptr<MainArmThenArmElseArmElseGen1Gen1Gen1> parent, Text out, Cx& cx) {
    auto first_0 = TRY(ok_or(cx.first_value(prism_rtl::to_pod(crate::Elem(crate::Elem::FsOutput{fs::FsOutput{.path_ = prism_rtl::cat(out, "/", std::get<0>(value)), .text = std::get<1>(value)}}))), Fault::answer("no first value for Fs.Output")));
    auto place_0_element = prism_rtl::to_pod(crate::Elem(crate::Elem::FsOutput{fs::FsOutput{.path_ = prism_rtl::cat(out, "/", std::get<0>(value)), .text = std::get<1>(value)}}));
    auto node = std::shared_ptr<MainArmThenArmElseArmElseGen1Gen1Gen1Row>(new MainArmThenArmElseArmElseGen1Gen1Gen1Row(path, key, std::nullopt, parent, out, {TRY(prism_rtl::from_pod<fs::WriteState>(first_0)), cx}, place_0_element));
    cx.added(node->path.at(0u), prism_rtl::to_pod(node->output(cx)));
    cx.listen(node->place_0_element, static_cast<std::shared_ptr<Node>>(node));
    return node;
}


/// Place 0's level, read at the read point.
crate::Elem MainArmThenArmElseArmElseGen1Gen1Gen1Row::output(const Cx& cx) const {
    return crate::Elem(crate::Elem::FsOutput{fs::FsOutput{.path_ = prism_rtl::cat(this->out, "/", std::get<0>(this->entry(cx))), .text = std::get<1>(this->entry(cx))}});
}


/// The row's entry, `$_`: the block's source at this key, at the read point; from the row's leaving on, the value as the leaving tick opened.
std::tuple<Text, Text> MainArmThenArmElseArmElseGen1Gen1Gen1Row::entry(const Cx& cx) const {
    if (auto&& _m = this->left_entry; prism_rtl::is_some(_m)) {
        auto&& v = prism_rtl::some_of(_m);
        return v;
    }
    auto parent = expect(prism_rtl::upgrade(this->parent), "the block outlives its rows");
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Text, Text>> _v;
        auto&& _m = cloned(parent->rows_source(cx).get(this->key));
        if (prism_rtl::is_some(_m)) {
            auto&& v = prism_rtl::some_of(_m);
            _v.set(v);
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(expect(cx.before([&](auto&& cx) { return cloned(parent->rows_source(cx).get(this->key)); }), "a row's key is in its source as its tick opened"));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// The row's result, which the block gathers by key.
fs::WriteState MainArmThenArmElseArmElseGen1Gen1Gen1Row::result(const Cx& cx) const {
    return this->place_0.get(cx);
}


/// The row left: its places are torn down.
Unit MainArmThenArmElseArmElseGen1Gen1Gen1Row::remove_places(Cx& cx) const {
    cx.removed(this->path.at(0u));
    return Unit{};
}


Done MainArmThenArmElseArmElseGen1Gen1Gen1Row::push(const Pod& element, const Pod& v, Cx& cx) {
    if (element == this->place_0_element) {
        this->place_0.set(TRY(prism_rtl::from_pod<fs::WriteState>(v)), cx);
        if (auto&& _m = prism_rtl::upgrade(this->parent); prism_rtl::is_some(_m)) {
            auto&& parent = prism_rtl::some_of(_m);
            parent->rows_all_moved(cx);
        }
    }
    return {};
}


Done MainArmThenArmElseArmElseGen1Gen1Gen1Row::patch(Cx& cx) {
    auto output = this->output(cx);
    cx.changed(this->path.at(0u), prism_rtl::to_pod(output));
    return {};
}


Done MainArmThenArmElseArmElseGen1Gen1Gen1Row::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() == 1 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 0u) {
        ({
            this->place_0.set(TRY(prism_rtl::from_pod<fs::WriteState>(v)), cx);
            if (auto&& _m = prism_rtl::upgrade(this->parent); prism_rtl::is_some(_m)) {
                auto&& parent = prism_rtl::some_of(_m);
                parent->rows_all_moved(cx);
            }
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmThenArmElseArmElseGen1Gen1Gen1Row::leave_row(Cx& cx) {
    this->left_entry = entry(cx);
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<std::shared_ptr<MainArmThenArmElseArmElseGen1Row>> MainArmThenArmElseArmElseGen1Row::make(Path path, Nat key, Text value, std::weak_ptr<MainArmThenArmElseArmElseGen1> parent, Cx& cx) {
    auto first_0 = TRY(ok_or(cx.first_value(prism_rtl::to_pod(crate::Elem(crate::Elem::FsContents{fs::FsContents{.path_ = value}}))), Fault::answer("no first value for Fs.Contents")));
    auto place_0_element = prism_rtl::to_pod(crate::Elem(crate::Elem::FsContents{fs::FsContents{.path_ = value}}));
    auto node = std::shared_ptr<MainArmThenArmElseArmElseGen1Row>(new MainArmThenArmElseArmElseGen1Row(path, key, std::nullopt, parent, {TRY(prism_rtl::from_pod<Fallible<fs::Contents>>(first_0)), cx}, place_0_element));
    cx.added(node->path.at(0u), prism_rtl::to_pod(node->contents_(cx)));
    cx.listen(node->place_0_element, static_cast<std::shared_ptr<Node>>(node));
    return node;
}


/// Place 0's level, read at the read point.
crate::Elem MainArmThenArmElseArmElseGen1Row::contents_(const Cx& cx) const {
    return crate::Elem(crate::Elem::FsContents{fs::FsContents{.path_ = this->entry(cx)}});
}


/// The row's entry, `$_`: the block's source at this key, at the read point; from the row's leaving on, the value as the leaving tick opened.
Text MainArmThenArmElseArmElseGen1Row::entry(const Cx& cx) const {
    if (auto&& _m = this->left_entry; prism_rtl::is_some(_m)) {
        auto&& v = prism_rtl::some_of(_m);
        return v;
    }
    auto parent = expect(prism_rtl::upgrade(this->parent), "the block outlives its rows");
    return ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = cloned(parent->rows_source(cx).get(this->key));
        if (prism_rtl::is_some(_m)) {
            auto&& v = prism_rtl::some_of(_m);
            _v.set(v);
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(expect(cx.before([&](auto&& cx) { return cloned(parent->rows_source(cx).get(this->key)); }), "a row's key is in its source as its tick opened"));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// The row's result, which the block gathers by key.
Fallible<fs::Contents> MainArmThenArmElseArmElseGen1Row::result(const Cx& cx) const {
    return this->place_0.get(cx);
}


/// The row left: its places are torn down.
Unit MainArmThenArmElseArmElseGen1Row::remove_places(Cx& cx) const {
    cx.removed(this->path.at(0u));
    return Unit{};
}


Done MainArmThenArmElseArmElseGen1Row::push(const Pod& element, const Pod& v, Cx& cx) {
    if (element == this->place_0_element) {
        this->place_0.set(TRY(prism_rtl::from_pod<Fallible<fs::Contents>>(v)), cx);
        if (auto&& _m = prism_rtl::upgrade(this->parent); prism_rtl::is_some(_m)) {
            auto&& parent = prism_rtl::some_of(_m);
            parent->rows_all_moved(cx);
        }
    }
    return {};
}


Done MainArmThenArmElseArmElseGen1Row::patch(Cx& cx) {
    auto contents = this->contents_(cx);
    cx.changed(this->path.at(0u), prism_rtl::to_pod(contents));
    return {};
}


Done MainArmThenArmElseArmElseGen1Row::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() == 1 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 0u) {
        ({
            this->place_0.set(TRY(prism_rtl::from_pod<Fallible<fs::Contents>>(v)), cx);
            if (auto&& _m = prism_rtl::upgrade(this->parent); prism_rtl::is_some(_m)) {
                auto&& parent = prism_rtl::some_of(_m);
                parent->rows_all_moved(cx);
            }
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmThenArmElseArmElseGen1Row::leave_row(Cx& cx) {
    this->left_entry = entry(cx);
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<std::shared_ptr<MainArmThenArmElseArmElseRow>> MainArmThenArmElseArmElseRow::make(Path path, Nat key, Text value, std::weak_ptr<MainArmThenArmElseArmElse> parent, Cx& cx) {
    auto first_0 = TRY(ok_or(cx.first_value(prism_rtl::to_pod(crate::Elem(crate::Elem::FsList_{fs::FsList_{.dir = value}}))), Fault::answer("no first value for Fs.List")));
    auto place_0_element = prism_rtl::to_pod(crate::Elem(crate::Elem::FsList_{fs::FsList_{.dir = value}}));
    auto node = std::shared_ptr<MainArmThenArmElseArmElseRow>(new MainArmThenArmElseArmElseRow(path, key, std::nullopt, parent, {TRY(prism_rtl::from_pod<Array<Text>>(first_0)), cx}, place_0_element));
    cx.added(node->path.at(0u), prism_rtl::to_pod(node->list(cx)));
    cx.listen(node->place_0_element, static_cast<std::shared_ptr<Node>>(node));
    return node;
}


/// Place 0's level, read at the read point.
crate::Elem MainArmThenArmElseArmElseRow::list(const Cx& cx) const {
    return crate::Elem(crate::Elem::FsList_{fs::FsList_{.dir = this->entry(cx)}});
}


/// The row's entry, `$_`: the block's source at this key, at the read point; from the row's leaving on, the value as the leaving tick opened.
Text MainArmThenArmElseArmElseRow::entry(const Cx& cx) const {
    if (auto&& _m = this->left_entry; prism_rtl::is_some(_m)) {
        auto&& v = prism_rtl::some_of(_m);
        return v;
    }
    auto parent = expect(prism_rtl::upgrade(this->parent), "the block outlives its rows");
    return ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = cloned(parent->rows_source(cx).get(this->key));
        if (prism_rtl::is_some(_m)) {
            auto&& v = prism_rtl::some_of(_m);
            _v.set(v);
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(expect(cx.before([&](auto&& cx) { return cloned(parent->rows_source(cx).get(this->key)); }), "a row's key is in its source as its tick opened"));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// The row's result, which the block gathers by key.
Array<Text> MainArmThenArmElseArmElseRow::result(const Cx& cx) const {
    return this->place_0.get(cx);
}


/// The row left: its places are torn down.
Unit MainArmThenArmElseArmElseRow::remove_places(Cx& cx) const {
    cx.removed(this->path.at(0u));
    return Unit{};
}


Done MainArmThenArmElseArmElseRow::push(const Pod& element, const Pod& v, Cx& cx) {
    if (element == this->place_0_element) {
        this->place_0.set(TRY(prism_rtl::from_pod<Array<Text>>(v)), cx);
        if (auto&& _m = prism_rtl::upgrade(this->parent); prism_rtl::is_some(_m)) {
            auto&& parent = prism_rtl::some_of(_m);
            parent->rows_all_moved(cx);
        }
    }
    return {};
}


Done MainArmThenArmElseArmElseRow::patch(Cx& cx) {
    auto list = this->list(cx);
    cx.changed(this->path.at(0u), prism_rtl::to_pod(list));
    return {};
}


Done MainArmThenArmElseArmElseRow::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() == 1 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 0u) {
        ({
            this->place_0.set(TRY(prism_rtl::from_pod<Array<Text>>(v)), cx);
            if (auto&& _m = prism_rtl::upgrade(this->parent); prism_rtl::is_some(_m)) {
                auto&& parent = prism_rtl::some_of(_m);
                parent->rows_all_moved(cx);
            }
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmThenArmElseArmElseRow::leave_row(Cx& cx) {
    this->left_entry = entry(cx);
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<std::shared_ptr<MainArmElse>> MainArmElse::make(Path path, Unit value, std::weak_ptr<Main> parent, Cx& cx) {
    auto node = std::shared_ptr<MainArmElse>(new MainArmElse(path, value, parent, std::nullopt, 0u, false));
    TRY(node->arm_build(cx));
    return node;
}


/// An arm's result, which a building `if` of widgets drops.
Unit MainArmElse::arm_up(Unit v, Cx& cx) {

    return Unit{};
}


/// The row left: its places are torn down.
Unit MainArmElse::remove_places(Cx& cx) const {
    if (auto&& _m = this->arm; prism_rtl::is_some(_m)) {
        auto&& row = prism_rtl::some_of(_m);
        row->leave_row(cx);
    }
    return Unit{};
}


/// The `rebuild` at `this->path.at(0u)`: the old generation torn down (it ran to the end of the
/// tick), the next built at `this->path.at(0u).child(Segment::gen(g))` from the source after the tick.
Done MainArmElse::arm_build(Cx& cx) {
    if (auto old = std::exchange(this->arm, std::nullopt)) {
        (*old)->leave_row(cx);
        cx.leave_later(*old);
    }
    std::uint32_t g = this->arm_count;
    this->arm_count = g + 1;
    Path path = this->path.at(0u).child(Segment::gen(g));
    Unit value = Unit{};
    std::shared_ptr<Row> row = expect(prism_rtl::upgrade(this->parent), "the block outlives its rows")->checking
    ? static_cast<std::shared_ptr<Row>>(TRY(MainArmElseArmThen::make(path, value, prism_rtl::weaken(prism_rtl::share(this)), cx)))
    : static_cast<std::shared_ptr<Row>>(TRY(MainArmElseArmElse::make(path, value, prism_rtl::weaken(prism_rtl::share(this)), cx)));
    this->arm = row;
    return {};
}


Done MainArmElse::build(Cx& cx) {
    if (std::exchange(this->arm_stale, false)) {
        TRY(this->arm_build(cx));
    }
    return {};
}


Done MainArmElse::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() >= 2 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 0u && prism_rtl::is<pat::Gen>(at[1])) {
        auto&& g = prism_rtl::as<pat::Gen>(at[1]).a0;
        auto rest = at.subspan(2);
        ({
            auto row = this->arm;
            if (auto&& _m = row; prism_rtl::is_some(_m)) {
                auto&& row = prism_rtl::some_of(_m);
                if ((g + 1u) == this->arm_count) {
                    TRY(row->answer(rest, v, cx));
                }
            }
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmElse::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<std::shared_ptr<MainArmElseArmThen>> MainArmElseArmThen::make(Path path, Unit value, std::weak_ptr<MainArmElse> parent, Cx& cx) {
    auto args = expect(prism_rtl::upgrade(expect(prism_rtl::upgrade(parent), "the block outlives its rows")->parent), "the block outlives its rows")->args;
    auto bad = bad_options(args, Array(std::vector{Text("--check"), Text("--typed"), Text("--unused")}), Array(std::vector{Text("--prelude"), Text("--out"), Text("--world")}));
    auto node = std::shared_ptr<MainArmElseArmThen>(new MainArmElseArmThen(path, value, parent, args, bad, std::nullopt, 0u, false));
    TRY(node->arm_build(cx));
    return node;
}


/// An arm's result, which a building `if` of widgets drops.
Unit MainArmElseArmThen::arm_up(Unit v, Cx& cx) {

    return Unit{};
}


/// The row left: its places are torn down.
Unit MainArmElseArmThen::remove_places(Cx& cx) const {
    if (auto&& _m = this->arm; prism_rtl::is_some(_m)) {
        auto&& row = prism_rtl::some_of(_m);
        row->leave_row(cx);
    }
    return Unit{};
}


/// The `rebuild` at `this->path.at(0u)`: the old generation torn down (it ran to the end of the
/// tick), the next built at `this->path.at(0u).child(Segment::gen(g))` from the source after the tick.
Done MainArmElseArmThen::arm_build(Cx& cx) {
    if (auto old = std::exchange(this->arm, std::nullopt)) {
        (*old)->leave_row(cx);
        cx.leave_later(*old);
    }
    std::uint32_t g = this->arm_count;
    this->arm_count = g + 1;
    Path path = this->path.at(0u).child(Segment::gen(g));
    Unit value = Unit{};
    std::shared_ptr<Row> row = len(this->bad) > Nat(0u)
    ? static_cast<std::shared_ptr<Row>>(TRY(MainArmElseArmThenArmThen::make(path, value, prism_rtl::weaken(prism_rtl::share(this)), cx)))
    : static_cast<std::shared_ptr<Row>>(TRY(MainArmElseArmThenArmElse::make(path, value, prism_rtl::weaken(prism_rtl::share(this)), cx)));
    this->arm = row;
    return {};
}


Done MainArmElseArmThen::build(Cx& cx) {
    if (std::exchange(this->arm_stale, false)) {
        TRY(this->arm_build(cx));
    }
    return {};
}


Done MainArmElseArmThen::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() >= 2 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 0u && prism_rtl::is<pat::Gen>(at[1])) {
        auto&& g = prism_rtl::as<pat::Gen>(at[1]).a0;
        auto rest = at.subspan(2);
        ({
            auto row = this->arm;
            if (auto&& _m = row; prism_rtl::is_some(_m)) {
                auto&& row = prism_rtl::some_of(_m);
                if ((g + 1u) == this->arm_count) {
                    TRY(row->answer(rest, v, cx));
                }
            }
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmElseArmThen::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<std::shared_ptr<MainArmElseArmThenArmThen>> MainArmElseArmThenArmThen::make(Path path, Unit value, std::weak_ptr<MainArmElseArmThen> parent, Cx& cx) {
    auto why = prism_rtl::cat(lexer::join(expect(prism_rtl::upgrade(parent), "the block outlives its rows")->bad, Text("; ")), " (--check takes --typed, --unused, --prelude DIR, --out FILE, --world W,...)");
    std::shared_ptr<Port<Unit>> started_2_v_port = prism_rtl::make_new();
    std::shared_ptr<Port<Fallible<Unit>>> gave_up_v_port = prism_rtl::make_new();
    auto node = std::shared_ptr<MainArmElseArmThenArmThen>(new MainArmElseArmThenArmThen(path, value, parent, why, started_2_v_port, gave_up_v_port));
    cx.added(node->path.at(1u), prism_rtl::to_pod(crate::Elem(crate::Elem::PreludeUnwrap{PreludeUnwrap{}})));
    cx.on_started(node);
    return node;
}


/// `!started_2`.
Unit MainArmElseArmThenArmThen::started_2(Unit v, Cx& cx) {
    prism_rtl::ignore(this->started_2_v_port->fire(v, cx));
    this->gave_up(unexpected(Error("Prismc.Refused", this->why)), cx);
    return Unit{};
}


/// `!gave_up`.
Unit MainArmElseArmThenArmThen::gave_up(Fallible<Unit> v, Cx& cx) {
    prism_rtl::ignore(this->gave_up_v_port->fire(v, cx));
    cx.request(this->path.at(1u), std::nullopt, prism_rtl::to_pod(v));
    return Unit{};
}


/// `place_1`: an answer at its place.
Unit MainArmElseArmThenArmThen::place_1(Unit v, Cx& cx) {

    return Unit{};
}


/// The row left: its places are torn down.
Unit MainArmElseArmThenArmThen::remove_places(Cx& cx) const {
    cx.removed(this->path.at(1u));
    return Unit{};
}


Done MainArmElseArmThenArmThen::started(Cx& cx) {
    this->started_2(Unit{}, cx);
    return {};
}


Done MainArmElseArmThenArmThen::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() == 1 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 1u) {
        this->place_1(TRY(prism_rtl::from_pod<Unit>(v)), cx);
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmElseArmThenArmThen::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<std::shared_ptr<MainArmElseArmThenArmElse>> MainArmElseArmThenArmElse::make(Path path, Unit value, std::weak_ptr<MainArmElseArmThen> parent, Cx& cx) {
    auto args = expect(prism_rtl::upgrade(parent), "the block outlives its rows")->args;
    auto files = plain_args(args);
    auto dir = or_(option_value(args, Text("--prelude")), Text("prelude"));
    auto out_1 = option_value(args, Text("--out"));
    auto world_2 = ({
        __label__ _done;
        prism_rtl::Slot<Array<Text>> _v;
        auto&& _m = option_value(args, Text("--world"));
        if (prism_rtl::is_some(_m)) {
            auto&& w = prism_rtl::some_of(_m);
            _v.set(split(w, Text(",")));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Array<Text>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto prelude = each(prelude_files(), [&](const Text& f) { return prism_rtl::cat(dir, "/", f); });
    auto paths = append(files, prelude);
    auto node = std::shared_ptr<MainArmElseArmThenArmElse>(new MainArmElseArmThenArmElse(path, value, parent, args, files, dir, out_1, world_2, prelude, paths, {}, {}, snapshot("the dynamic gathered by the `for` at place 0"), std::nullopt, 0u, false));
    TRY(node->rows_build(cx));
    node->rows_all_snap.take(node->rows_all_now(cx), cx);
    TRY(node->generation_build(cx));
    return node;
}


/// `!generation_fired`.
Unit MainArmElseArmThenArmElse::generation_fired(Unit v, Cx& cx) {

    return Unit{};
}


/// The source of the `for` at place 0 by key, at the read point: what its builder and its rows' entries read, computed once per write behind it.
Map<Nat, Text> MainArmElseArmThenArmElse::rows_source(const Cx& cx) const {
    return this->rows_source_cache.get(cx, [&]() { return indexed(this->paths); });
}


/// The rows' results by key, computed live: what the snapshot of the `for`'s dynamic is taken from (pick ST).
Map<Nat, Fallible<fs::Contents>> MainArmElseArmThenArmElse::rows_all_now(const Cx& cx) const {
    return prism_rtl::fmap(this->rows, [&](const auto& _p0) {
        auto&& k = std::get<0>(_p0);
        auto&& row = std::get<1>(_p0);
        return std::tuple{k, row->result(cx)};
    });
}


/// The `for`'s dynamic, the rows' results by key, a structural dynamic (pick ST): one tick behind the rows, the snapshot of the tick before the tick the read point is after.
Map<Nat, Fallible<fs::Contents>> MainArmElseArmThenArmElse::rows_all(const Cx& cx) const {
    return this->rows_all_snap.get(cx);
}


/// The current generation's result fires the `rebuild`'s.
Unit MainArmElseArmThenArmElse::generation_up(Unit v, Cx& cx) {
    this->generation_fired(v, cx);
    return Unit{};
}


/// The row left: its places are torn down.
Unit MainArmElseArmThenArmElse::remove_places(Cx& cx) const {
    prism_rtl::for_each(prelude::values(this->rows), [&](auto&& row) { return row->leave_row(cx); });
    if (auto&& _m = this->generation; prism_rtl::is_some(_m)) {
        auto&& row = prism_rtl::some_of(_m);
        row->leave_row(cx);
    }
    return Unit{};
}


/// A row's result moved: the `for`'s gathered dynamic is marked, and its snapshot taken after the builder (pick ST).
Unit MainArmElseArmThenArmElse::rows_all_moved(Cx& cx) {
    this->rows_all_snap.mark(cx);
    cx.build_later(prism_rtl::share(this));
    return Unit{};
}


/// the dynamic gathered by the `for` at place 0, published: its snapshot of the tick before moved it, written as a hold is (pick ST).
Unit MainArmElseArmThenArmElse::rows_all_publish(Cx& cx) {
    if (this->rows_all_snap.published(cx)) {
        this->generation_stale = true;
        cx.build_later(prism_rtl::share(this));
    }
    return Unit{};
}


/// The rows of the `for` at `this->path.at(0u)`: rows whose key left are torn down, new keys are
/// built under it at `[k]` from the values after the tick; kept rows keep reading their
/// entry out of the source.
Done MainArmElseArmThenArmElse::rows_build(Cx& cx) {
    Map<Nat, Text> items = rows_source(cx);
    auto old = deref(this->rows);
    for (auto&& [k, row] : old) {
        if (!items.contains(k)) {
            row->leave_row(cx);
            cx.leave_later(row);
        }
    }
    decltype(old) next;
    for (auto&& [k, v] : items) {
        if (auto row = old.get(k)) next.insert(k, *row);
        else next.insert(k, TRY(MainArmElseArmThenArmElseRow::make(this->path.at(0u).child(Segment::key(prism_rtl::to_pod(k))), k, v, prism_rtl::weaken(prism_rtl::share(this)), cx)));
    }
    deref(this->rows) = next;
    // What the block reads of its rows (a `for` that gives a dynamic) moved.
    cx.dirty(prism_rtl::share(this));
    return {};
}


/// The `rebuild` at `this->path.at(1u)`: the old generation torn down (it ran to the end of the
/// tick), the next built at `this->path.at(1u).child(Segment::gen(g))` from the source after the tick.
Done MainArmElseArmThenArmElse::generation_build(Cx& cx) {
    if (auto old = std::exchange(this->generation, std::nullopt)) {
        (*old)->leave_row(cx);
        cx.leave_later(*old);
    }
    std::uint32_t g = this->generation_count;
    this->generation_count = g + 1;
    Path path = this->path.at(1u).child(Segment::gen(g));
    Map<Nat, Fallible<fs::Contents>> value = this->rows_all(cx);
    std::shared_ptr<Row> row = TRY(MainArmElseArmThenArmElseGen1::make(path, value, prism_rtl::weaken(prism_rtl::share(this)), cx));
    this->generation = row;
    return {};
}


Done MainArmElseArmThenArmElse::build(Cx& cx) {
    TRY(this->rows_build(cx));
    if (this->rows_all_snap.marked(cx)) {
        this->rows_all_snap.take_compared(this->rows_all_now(cx), cx);
        if (this->rows_all_snap.queue(cx)) {
            auto node = prism_rtl::share(this);
            cx.answer_later([=](Cx& cx) -> Done { node->rows_all_publish(cx); return {}; });
        }
    }
    if (std::exchange(this->generation_stale, false)) {
        TRY(this->generation_build(cx));
    }
    return {};
}


Done MainArmElseArmThenArmElse::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() >= 2 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 0u && prism_rtl::is<pat::Key>(at[1])) {
        auto&& k = prism_rtl::as<pat::Key>(at[1]).a0;
        auto rest = at.subspan(2);
        ({
            auto row = cloned(this->rows.get(TRY(prism_rtl::from_pod<Nat>(k))));
            if (auto&& _m = row; prism_rtl::is_some(_m)) {
                auto&& row = prism_rtl::some_of(_m);
                TRY(row->answer(rest, v, cx));
            }
            Unit{};
        });
    } else if (at.size() >= 2 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 1u && prism_rtl::is<pat::Gen>(at[1])) {
        auto&& g = prism_rtl::as<pat::Gen>(at[1]).a0;
        auto rest = at.subspan(2);
        ({
            auto row = this->generation;
            if (auto&& _m = row; prism_rtl::is_some(_m)) {
                auto&& row = prism_rtl::some_of(_m);
                if ((g + 1u) == this->generation_count) {
                    TRY(row->answer(rest, v, cx));
                }
            }
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmElseArmThenArmElse::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<std::shared_ptr<MainArmElseArmThenArmElseGen1>> MainArmElseArmThenArmElseGen1::make(Path path, Map<Nat, Fallible<fs::Contents>> value, std::weak_ptr<MainArmElseArmThenArmElse> parent, Cx& cx) {
    auto files = expect(prism_rtl::upgrade(parent), "the block outlives its rows")->files;
    auto prelude = expect(prism_rtl::upgrade(parent), "the block outlives its rows")->prelude;
    auto world = expect(prism_rtl::upgrade(parent), "the block outlives its rows")->world;
    auto out = expect(prism_rtl::upgrade(parent), "the block outlives its rows")->out;
    auto typed_1 = check_types::has_text(expect(prism_rtl::upgrade(parent), "the block outlives its rows")->args, Text("--typed"));
    auto unused_2 = check_types::has_text(expect(prism_rtl::upgrade(parent), "the block outlives its rows")->args, Text("--unused"));
    auto contents = value;
    std::shared_ptr<Port<Outcome_>> done_v_port = prism_rtl::make_new();
    auto n = len(files);
    auto texts = each(check_errors::range0(len(append(files, prelude))), [&](const Nat& i) { return contents_text(or_(prelude::get(contents, i), fs::Contents{.text = Text("")})); });
    auto mine = each(check_errors::range0(n), [&](const Nat& i) { return std::tuple{or_(index(files, i), Text("")), or_(index(texts, i), Text(""))}; });
    auto theirs = each(check_errors::range0(len(prelude)), [&](const Nat& i) { return std::tuple{or_(index(prelude, i), Text("")), or_(index(texts, n + i), Text(""))}; });
    auto present = filter(theirs, [&](const std::tuple<Text, Text>& _p0) {
        auto&& t = std::get<1>(_p0);
        return t != Text("");
    });
    auto job = CheckJob{.files = mine, .prelude = present, .world = world, .typed = typed_1, .unused = unused_2};
    std::optional<Outcome_> outcome_init = std::optional<Outcome_>{};
    auto node = std::shared_ptr<MainArmElseArmThenArmElseGen1>(new MainArmElseArmThenArmElseGen1(path, value, parent, files, prelude, world, out, typed_1, unused_2, contents, done_v_port, n, texts, mine, theirs, present, job, {start_check_files(job), cx}, {}, {}, {}, {outcome_init, cx}, std::nullopt, 0u, false));
    TRY(node->generation_build(cx));
    cx.on_started(node);
    return node;
}


/// `!done`.
Unit MainArmElseArmThenArmElseGen1::done(Outcome_ v, Cx& cx) {
    prism_rtl::ignore(this->done_v_port->fire(v, cx));
    this->outcome.set(std::optional(v), cx);
    this->generation_stale = true;
    cx.build_later(prism_rtl::share(this));
    return Unit{};
}


/// `@started`, the tick after the build.
Unit MainArmElseArmThenArmElseGen1::run_started(Unit v, Cx& cx) {
    this->run_turn_left.set(v, cx);
    cx.wake(WAKE, prism_rtl::share(this));
    return Unit{};
}


/// An `@Defer` firing, the tick after it was armed.
Unit MainArmElseArmThenArmElseGen1::run_again_(Unit v, Cx& cx) {
    this->run_turn_right.set(v, cx);
    cx.wake(WAKE, prism_rtl::share(this));
    return Unit{};
}


/// The merge `run_turn`, decided in the wake.
Unit MainArmElseArmThenArmElseGen1::run_turn(Unit v, Cx& cx) {
    {
        auto&& _m = this->run_job.get(cx)->cycle();
        if (_m.if_more()) {
            auto&& next = _m.if_more()->next;
            this->run_job.set(next, cx);
            this->run_again.arm(Unit{}, prism_rtl::share(this), cx);
        } else if (_m.if_finished()) {
            auto&& b = _m.if_finished()->value;
            this->done(b, cx);
        }
    }
    return Unit{};
}


/// `!generation_fired`.
Unit MainArmElseArmThenArmElseGen1::generation_fired(Unit v, Cx& cx) {

    return Unit{};
}


/// The current generation's result fires the `rebuild`'s.
Unit MainArmElseArmThenArmElseGen1::generation_up(Unit v, Cx& cx) {
    this->generation_fired(v, cx);
    return Unit{};
}


/// The row left: its places are torn down.
Unit MainArmElseArmThenArmElseGen1::remove_places(Cx& cx) const {
    if (auto&& _m = this->generation; prism_rtl::is_some(_m)) {
        auto&& row = prism_rtl::some_of(_m);
        row->leave_row(cx);
    }
    return Unit{};
}


/// The `rebuild` at `this->path.at(1u)`: the old generation torn down (it ran to the end of the
/// tick), the next built at `this->path.at(1u).child(Segment::gen(g))` from the source after the tick.
Done MainArmElseArmThenArmElseGen1::generation_build(Cx& cx) {
    if (auto old = std::exchange(this->generation, std::nullopt)) {
        (*old)->leave_row(cx);
        cx.leave_later(*old);
    }
    std::uint32_t g = this->generation_count;
    this->generation_count = g + 1;
    Path path = this->path.at(1u).child(Segment::gen(g));
    std::optional<Outcome_> value = this->outcome.get(cx);
    std::shared_ptr<Row> row = ({
    __label__ _done;
    prism_rtl::Slot<std::shared_ptr<Row>> _v;
    auto&& _m = std::tuple{this->out, value};
    if (prism_rtl::is_none(std::get<1>(_m))) {
        auto&& out_opt = std::get<0>(_m);
        _v.set(static_cast<std::shared_ptr<Row>>(TRY(MainArmElseArmThenArmElseGen1Gen0::make(path, out_opt, prism_rtl::weaken(prism_rtl::share(this)), cx))));
        goto _done;
    }
    if (prism_rtl::is_some(std::get<1>(_m))) {
        auto&& out_opt = std::get<0>(_m);
        auto&& o = prism_rtl::some_of(std::get<1>(_m));
        _v.set(static_cast<std::shared_ptr<Row>>(TRY(MainArmElseArmThenArmElseGen1Gen1::make(path, out_opt, o, prism_rtl::weaken(prism_rtl::share(this)), cx))));
        goto _done;
    }
    prism_rtl::unreachable("no arm matched");
_done:
    _v.take();
});
    this->generation = row;
    return {};
}


Done MainArmElseArmThenArmElseGen1::wake(Cx& cx) {
    if (true) {
        auto left = this->run_turn_left.take(cx);
        auto right = this->run_turn_right.take(cx);
        if (auto&& _m = left; prism_rtl::is_some(_m)) {
            auto&& v = prism_rtl::some_of(_m);
            this->run_turn(v, cx);
        } else if (auto&& _m = right; prism_rtl::is_some(_m)) {
            auto&& v = prism_rtl::some_of(_m);
            this->run_turn(v, cx);
        }
    }
    return {};
}


Done MainArmElseArmThenArmElseGen1::started(Cx& cx) {
    this->run_started(Unit{}, cx);
    return {};
}


Done MainArmElseArmThenArmElseGen1::deferred(Cx& cx) {
    if (auto&& _m = this->run_again.fired(cx); prism_rtl::is_some(_m)) {
        auto&& v = prism_rtl::some_of(_m);
        this->run_again_(v, cx);
    }
    return {};
}


Done MainArmElseArmThenArmElseGen1::build(Cx& cx) {
    if (std::exchange(this->generation_stale, false)) {
        TRY(this->generation_build(cx));
    }
    return {};
}


Done MainArmElseArmThenArmElseGen1::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() >= 2 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 1u && prism_rtl::is<pat::Gen>(at[1])) {
        auto&& g = prism_rtl::as<pat::Gen>(at[1]).a0;
        auto rest = at.subspan(2);
        ({
            auto row = this->generation;
            if (auto&& _m = row; prism_rtl::is_some(_m)) {
                auto&& row = prism_rtl::some_of(_m);
                if ((g + 1u) == this->generation_count) {
                    TRY(row->answer(rest, v, cx));
                }
            }
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmElseArmThenArmElseGen1::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<std::shared_ptr<MainArmElseArmThenArmElseGen1Gen0>> MainArmElseArmThenArmElseGen1Gen0::make(Path path, std::optional<Text> out, std::weak_ptr<MainArmElseArmThenArmElseGen1> parent, Cx& cx) {
    auto node = std::shared_ptr<MainArmElseArmThenArmElseGen1Gen0>(new MainArmElseArmThenArmElseGen1Gen0(path, out, parent));
    return node;
}


/// The row left: its places are torn down.
Unit MainArmElseArmThenArmElseGen1Gen0::remove_places(Cx& cx) const {

    return Unit{};
}


void MainArmElseArmThenArmElseGen1Gen0::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<std::shared_ptr<MainArmElseArmThenArmElseGen1Gen1>> MainArmElseArmThenArmElseGen1Gen1::make(Path path, std::optional<Text> out, Outcome_ o, std::weak_ptr<MainArmElseArmThenArmElseGen1> parent, Cx& cx) {
    std::shared_ptr<Port<Unit>> started_2_v_port = prism_rtl::make_new();
    std::shared_ptr<Port<Fallible<Unit>>> verdict_v_port = prism_rtl::make_new();
    auto node = std::shared_ptr<MainArmElseArmThenArmElseGen1Gen1>(new MainArmElseArmThenArmElseGen1Gen1(path, out, o, parent, started_2_v_port, verdict_v_port, std::nullopt, 0u, false));
    TRY(node->generation_build(cx));
    cx.added(node->path.at(2u), prism_rtl::to_pod(crate::Elem(crate::Elem::PreludeUnwrap{PreludeUnwrap{}})));
    cx.on_started(node);
    return node;
}


/// `!started_2`.
Unit MainArmElseArmThenArmElseGen1Gen1::started_2(Unit v, Cx& cx) {
    prism_rtl::ignore(this->started_2_v_port->fire(v, cx));
    this->verdict(this->o.failed
        ? unexpected(Error("Prismc.Refused", this->o.report))
        : Expected<std::decay_t<decltype(Unit{})>, std::decay_t<decltype(Error("Prismc.Refused", this->o.report))>>(Unit{}), cx);
    return Unit{};
}


/// `!verdict`.
Unit MainArmElseArmThenArmElseGen1Gen1::verdict(Fallible<Unit> v, Cx& cx) {
    prism_rtl::ignore(this->verdict_v_port->fire(v, cx));
    cx.request(this->path.at(2u), std::nullopt, prism_rtl::to_pod(v));
    return Unit{};
}


/// `!generation_fired`.
Unit MainArmElseArmThenArmElseGen1Gen1::generation_fired(prism_rtl::Blueprint<crate::Elem, crate::Answer> v, Cx& cx) {

    return Unit{};
}


/// `place_2`: an answer at its place.
Unit MainArmElseArmThenArmElseGen1Gen1::place_2(Unit v, Cx& cx) {

    return Unit{};
}


/// The current generation's result fires the `rebuild`'s.
Unit MainArmElseArmThenArmElseGen1Gen1::generation_up(prism_rtl::Blueprint<crate::Elem, crate::Answer> v, Cx& cx) {
    this->generation_fired(v, cx);
    return Unit{};
}


/// The row left: its places are torn down.
Unit MainArmElseArmThenArmElseGen1Gen1::remove_places(Cx& cx) const {
    cx.removed(this->path.at(2u));
    if (auto&& _m = this->generation; prism_rtl::is_some(_m)) {
        auto&& row = prism_rtl::some_of(_m);
        row->leave_row(cx);
    }
    return Unit{};
}


/// The `rebuild` at `this->path.at(0u)`: the old generation torn down (it ran to the end of the
/// tick), the next built at `this->path` from the source after the tick.
Done MainArmElseArmThenArmElseGen1Gen1::generation_build(Cx& cx) {
    if (auto old = std::exchange(this->generation, std::nullopt)) {
        (*old)->leave_row(cx);
        cx.leave_later(*old);
    }
    std::uint32_t g = this->generation_count;
    this->generation_count = g + 1;
    Path path = this->path;
    std::optional<Text> value = this->out;
    std::shared_ptr<Row> row = ({
    __label__ _done;
    prism_rtl::Slot<std::shared_ptr<Row>> _v;
    auto&& _m = std::tuple{this->out, this->o.text};
    if (prism_rtl::is_none(std::get<0>(_m))) {
        _v.set(static_cast<std::shared_ptr<Row>>(TRY(MainArmElseArmThenArmElseGen1Gen1Gen0::make(path, prism_rtl::weaken(prism_rtl::share(this)), cx))));
        goto _done;
    }
    if (prism_rtl::is_some(std::get<0>(_m))) {
        auto&& path_ = prism_rtl::some_of(std::get<0>(_m));
        auto&& text = std::get<1>(_m);
        _v.set(static_cast<std::shared_ptr<Row>>(TRY(MainArmElseArmThenArmElseGen1Gen1Gen1::make(path, path_, text, prism_rtl::weaken(prism_rtl::share(this)), cx))));
        goto _done;
    }
    prism_rtl::unreachable("no arm matched");
_done:
    _v.take();
});
    this->generation = row;
    return {};
}


Done MainArmElseArmThenArmElseGen1Gen1::started(Cx& cx) {
    this->started_2(Unit{}, cx);
    return {};
}


Done MainArmElseArmThenArmElseGen1Gen1::build(Cx& cx) {
    if (std::exchange(this->generation_stale, false)) {
        TRY(this->generation_build(cx));
    }
    return {};
}


Done MainArmElseArmThenArmElseGen1Gen1::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() == 1 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 2u) {
        this->place_2(TRY(prism_rtl::from_pod<Unit>(v)), cx);
    } else if (at.size() >= 1 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 0u) {
        ({
            auto row = this->generation;
            if (auto&& _m = row; prism_rtl::is_some(_m)) {
                auto&& row = prism_rtl::some_of(_m);
                TRY(row->answer(at, v, cx));
            }
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmElseArmThenArmElseGen1Gen1::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<std::shared_ptr<MainArmElseArmThenArmElseGen1Gen1Gen0>> MainArmElseArmThenArmElseGen1Gen1Gen0::make(Path path, std::weak_ptr<MainArmElseArmThenArmElseGen1Gen1> parent, Cx& cx) {
    auto node = std::shared_ptr<MainArmElseArmThenArmElseGen1Gen1Gen0>(new MainArmElseArmThenArmElseGen1Gen1Gen0(path, parent));
    return node;
}


/// The row left: its places are torn down.
Unit MainArmElseArmThenArmElseGen1Gen1Gen0::remove_places(Cx& cx) const {

    return Unit{};
}


void MainArmElseArmThenArmElseGen1Gen1Gen0::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<std::shared_ptr<MainArmElseArmThenArmElseGen1Gen1Gen1>> MainArmElseArmThenArmElseGen1Gen1Gen1::make(Path path, Text path_, Text text, std::weak_ptr<MainArmElseArmThenArmElseGen1Gen1> parent, Cx& cx) {
    auto first_0 = TRY(ok_or(cx.first_value(prism_rtl::to_pod(crate::Elem(crate::Elem::FsOutput{fs::FsOutput{.path_ = path_, .text = text}}))), Fault::answer("no first value for Fs.Output")));
    auto place_0_element = prism_rtl::to_pod(crate::Elem(crate::Elem::FsOutput{fs::FsOutput{.path_ = path_, .text = text}}));
    auto node = std::shared_ptr<MainArmElseArmThenArmElseGen1Gen1Gen1>(new MainArmElseArmThenArmElseGen1Gen1Gen1(path, path_, text, parent, {TRY(prism_rtl::from_pod<fs::WriteState>(first_0)), cx}, place_0_element));
    cx.added(node->path.at(0u), prism_rtl::to_pod(crate::Elem(crate::Elem::FsOutput{fs::FsOutput{.path_ = path_, .text = text}})));
    cx.listen(node->place_0_element, static_cast<std::shared_ptr<Node>>(node));
    return node;
}


/// The row left: its places are torn down.
Unit MainArmElseArmThenArmElseGen1Gen1Gen1::remove_places(Cx& cx) const {
    cx.removed(this->path.at(0u));
    return Unit{};
}


Done MainArmElseArmThenArmElseGen1Gen1Gen1::push(const Pod& element, const Pod& v, Cx& cx) {
    if (element == this->place_0_element) {
        this->place_0.set(TRY(prism_rtl::from_pod<fs::WriteState>(v)), cx);
    }
    return {};
}


Done MainArmElseArmThenArmElseGen1Gen1Gen1::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() == 1 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 0u) {
        ({
            this->place_0.set(TRY(prism_rtl::from_pod<fs::WriteState>(v)), cx);
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmElseArmThenArmElseGen1Gen1Gen1::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<std::shared_ptr<MainArmElseArmThenArmElseRow>> MainArmElseArmThenArmElseRow::make(Path path, Nat key, Text value, std::weak_ptr<MainArmElseArmThenArmElse> parent, Cx& cx) {
    auto first_0 = TRY(ok_or(cx.first_value(prism_rtl::to_pod(crate::Elem(crate::Elem::FsContents{fs::FsContents{.path_ = value}}))), Fault::answer("no first value for Fs.Contents")));
    auto place_0_element = prism_rtl::to_pod(crate::Elem(crate::Elem::FsContents{fs::FsContents{.path_ = value}}));
    auto node = std::shared_ptr<MainArmElseArmThenArmElseRow>(new MainArmElseArmThenArmElseRow(path, key, std::nullopt, parent, {TRY(prism_rtl::from_pod<Fallible<fs::Contents>>(first_0)), cx}, place_0_element));
    cx.added(node->path.at(0u), prism_rtl::to_pod(node->contents_(cx)));
    cx.listen(node->place_0_element, static_cast<std::shared_ptr<Node>>(node));
    return node;
}


/// Place 0's level, read at the read point.
crate::Elem MainArmElseArmThenArmElseRow::contents_(const Cx& cx) const {
    return crate::Elem(crate::Elem::FsContents{fs::FsContents{.path_ = this->entry(cx)}});
}


/// The row's entry, `$_`: the block's source at this key, at the read point; from the row's leaving on, the value as the leaving tick opened.
Text MainArmElseArmThenArmElseRow::entry(const Cx& cx) const {
    if (auto&& _m = this->left_entry; prism_rtl::is_some(_m)) {
        auto&& v = prism_rtl::some_of(_m);
        return v;
    }
    auto parent = expect(prism_rtl::upgrade(this->parent), "the block outlives its rows");
    return ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = cloned(parent->rows_source(cx).get(this->key));
        if (prism_rtl::is_some(_m)) {
            auto&& v = prism_rtl::some_of(_m);
            _v.set(v);
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(expect(cx.before([&](auto&& cx) { return cloned(parent->rows_source(cx).get(this->key)); }), "a row's key is in its source as its tick opened"));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// The row's result, which the block gathers by key.
Fallible<fs::Contents> MainArmElseArmThenArmElseRow::result(const Cx& cx) const {
    return this->place_0.get(cx);
}


/// The row left: its places are torn down.
Unit MainArmElseArmThenArmElseRow::remove_places(Cx& cx) const {
    cx.removed(this->path.at(0u));
    return Unit{};
}


Done MainArmElseArmThenArmElseRow::push(const Pod& element, const Pod& v, Cx& cx) {
    if (element == this->place_0_element) {
        this->place_0.set(TRY(prism_rtl::from_pod<Fallible<fs::Contents>>(v)), cx);
        if (auto&& _m = prism_rtl::upgrade(this->parent); prism_rtl::is_some(_m)) {
            auto&& parent = prism_rtl::some_of(_m);
            parent->rows_all_moved(cx);
        }
    }
    return {};
}


Done MainArmElseArmThenArmElseRow::patch(Cx& cx) {
    auto contents = this->contents_(cx);
    cx.changed(this->path.at(0u), prism_rtl::to_pod(contents));
    return {};
}


Done MainArmElseArmThenArmElseRow::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() == 1 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 0u) {
        ({
            this->place_0.set(TRY(prism_rtl::from_pod<Fallible<fs::Contents>>(v)), cx);
            if (auto&& _m = prism_rtl::upgrade(this->parent); prism_rtl::is_some(_m)) {
                auto&& parent = prism_rtl::some_of(_m);
                parent->rows_all_moved(cx);
            }
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmElseArmThenArmElseRow::leave_row(Cx& cx) {
    this->left_entry = entry(cx);
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<std::shared_ptr<MainArmElseArmElse>> MainArmElseArmElse::make(Path path, Unit value, std::weak_ptr<MainArmElse> parent, Cx& cx) {
    auto args = expect(prism_rtl::upgrade(expect(prism_rtl::upgrade(parent), "the block outlives its rows")->parent), "the block outlives its rows")->args;
    auto tokens_1 = fold(args, false, [&](const bool& seen, const Text& a) { return seen || (a == Text("--tokens")); });
    auto fragment_2 = fold(args, false, [&](const bool& seen, const Text& a) { return seen || (a == Text("--fragment")); });
    auto names = fold(args, Array<Text>{}, [&](const Array<Text>& acc, const Text& a) { return lexer::has_prefix(a, Text("--")) ? acc : prelude::push(acc, a); });
    auto file = or_(index(names, Nat(0u)), Text(""));
    auto out = or_(index(names, Nat(1u)), prism_rtl::cat(file, ".sexp"));
    auto first_0 = TRY(ok_or(cx.first_value(prism_rtl::to_pod(crate::Elem(crate::Elem::FsContents{fs::FsContents{.path_ = file}}))), Fault::answer("no first value for Fs.Contents")));
    auto source_element = prism_rtl::to_pod(crate::Elem(crate::Elem::FsContents{fs::FsContents{.path_ = file}}));
    auto node = std::shared_ptr<MainArmElseArmElse>(new MainArmElseArmElse(path, value, parent, args, tokens_1, fragment_2, names, file, out, {TRY(prism_rtl::from_pod<Fallible<fs::Contents>>(first_0)), cx}, source_element, std::nullopt, 0u, false));
    TRY(node->generation_build(cx));
    cx.added(node->path.at(0u), prism_rtl::to_pod(crate::Elem(crate::Elem::FsContents{fs::FsContents{.path_ = file}})));
    cx.listen(node->source_element, static_cast<std::shared_ptr<Node>>(node));
    return node;
}


/// `!generation_fired`.
Unit MainArmElseArmElse::generation_fired(Unit v, Cx& cx) {

    return Unit{};
}


/// The current generation's result fires the `rebuild`'s.
Unit MainArmElseArmElse::generation_up(Unit v, Cx& cx) {
    this->generation_fired(v, cx);
    return Unit{};
}


/// The row left: its places are torn down.
Unit MainArmElseArmElse::remove_places(Cx& cx) const {
    cx.removed(this->path.at(0u));
    if (auto&& _m = this->generation; prism_rtl::is_some(_m)) {
        auto&& row = prism_rtl::some_of(_m);
        row->leave_row(cx);
    }
    return Unit{};
}


/// The `rebuild` at `this->path.at(1u)`: the old generation torn down (it ran to the end of the
/// tick), the next built at `this->path.at(1u).child(Segment::gen(g))` from the source after the tick.
Done MainArmElseArmElse::generation_build(Cx& cx) {
    if (auto old = std::exchange(this->generation, std::nullopt)) {
        (*old)->leave_row(cx);
        cx.leave_later(*old);
    }
    std::uint32_t g = this->generation_count;
    this->generation_count = g + 1;
    Path path = this->path.at(1u).child(Segment::gen(g));
    Fallible<fs::Contents> value = this->source.get(cx);
    std::shared_ptr<Row> row = ({
    __label__ _done;
    prism_rtl::Slot<std::shared_ptr<Row>> _v;
    auto&& _m = std::tuple{Job_{.tokens = this->tokens, .fragment = this->fragment, .text = Text("")}, this->file, this->out, value};
    if (prism_rtl::is_ok(std::get<3>(_m))) {
        auto&& job = std::get<0>(_m);
        auto&& file = std::get<1>(_m);
        auto&& out = std::get<2>(_m);
        auto&& c = *std::get<3>(_m);
        _v.set(static_cast<std::shared_ptr<Row>>(TRY(MainArmElseArmElseGen0::make(path, job, file, out, c, prism_rtl::weaken(prism_rtl::share(this)), cx))));
        goto _done;
    }
    if (prism_rtl::is_err(std::get<3>(_m))) {
        auto&& job = std::get<0>(_m);
        auto&& file = std::get<1>(_m);
        auto&& out = std::get<2>(_m);
        auto&& c3 = std::get<3>(_m).error();
        _v.set(static_cast<std::shared_ptr<Row>>(TRY(MainArmElseArmElseGen1::make(path, job, file, out, c3.message, prism_rtl::weaken(prism_rtl::share(this)), cx))));
        goto _done;
    }
    prism_rtl::unreachable("no arm matched");
_done:
    _v.take();
});
    this->generation = row;
    return {};
}


Done MainArmElseArmElse::build(Cx& cx) {
    if (std::exchange(this->generation_stale, false)) {
        TRY(this->generation_build(cx));
    }
    return {};
}


Done MainArmElseArmElse::push(const Pod& element, const Pod& v, Cx& cx) {
    if (element == this->source_element) {
        this->source.set(TRY(prism_rtl::from_pod<Fallible<fs::Contents>>(v)), cx);
        this->generation_stale = true;
        cx.build_later(prism_rtl::share(this));
    }
    return {};
}


Done MainArmElseArmElse::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() == 1 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 0u) {
        ({
            this->source.set(TRY(prism_rtl::from_pod<Fallible<fs::Contents>>(v)), cx);
            this->generation_stale = true;
            cx.build_later(prism_rtl::share(this));
            Unit{};
        });
    } else if (at.size() >= 2 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 1u && prism_rtl::is<pat::Gen>(at[1])) {
        auto&& g = prism_rtl::as<pat::Gen>(at[1]).a0;
        auto rest = at.subspan(2);
        ({
            auto row = this->generation;
            if (auto&& _m = row; prism_rtl::is_some(_m)) {
                auto&& row = prism_rtl::some_of(_m);
                if ((g + 1u) == this->generation_count) {
                    TRY(row->answer(rest, v, cx));
                }
            }
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmElseArmElse::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<std::shared_ptr<MainArmElseArmElseGen0>> MainArmElseArmElseGen0::make(Path path, Job_ job, Text file, Text out, fs::Contents c, std::weak_ptr<MainArmElseArmElse> parent, Cx& cx) {
    std::shared_ptr<Port<Outcome_>> done_v_port = prism_rtl::make_new();
    auto full = ({
        Job_ this_ = job;
        this_.text = c->text;
        this_;
    });
    std::optional<Outcome_> outcome_init = std::optional<Outcome_>{};
    auto node = std::shared_ptr<MainArmElseArmElseGen0>(new MainArmElseArmElseGen0(path, job, file, out, c, parent, done_v_port, full, {start_front_end(full), cx}, {}, {}, {}, {outcome_init, cx}, std::nullopt, 0u, false));
    TRY(node->generation_build(cx));
    cx.on_started(node);
    return node;
}


/// `!done`.
Unit MainArmElseArmElseGen0::done(Outcome_ v, Cx& cx) {
    prism_rtl::ignore(this->done_v_port->fire(v, cx));
    this->outcome.set(std::optional(v), cx);
    this->generation_stale = true;
    cx.build_later(prism_rtl::share(this));
    return Unit{};
}


/// `@started`, the tick after the build.
Unit MainArmElseArmElseGen0::run_started(Unit v, Cx& cx) {
    this->run_turn_left.set(v, cx);
    cx.wake(WAKE, prism_rtl::share(this));
    return Unit{};
}


/// An `@Defer` firing, the tick after it was armed.
Unit MainArmElseArmElseGen0::run_again_(Unit v, Cx& cx) {
    this->run_turn_right.set(v, cx);
    cx.wake(WAKE, prism_rtl::share(this));
    return Unit{};
}


/// The merge `run_turn`, decided in the wake.
Unit MainArmElseArmElseGen0::run_turn(Unit v, Cx& cx) {
    {
        auto&& _m = this->run_job.get(cx)->cycle();
        if (_m.if_more()) {
            auto&& next = _m.if_more()->next;
            this->run_job.set(next, cx);
            this->run_again.arm(Unit{}, prism_rtl::share(this), cx);
        } else if (_m.if_finished()) {
            auto&& b = _m.if_finished()->value;
            this->done(b, cx);
        }
    }
    return Unit{};
}


/// `!generation_fired`.
Unit MainArmElseArmElseGen0::generation_fired(Unit v, Cx& cx) {

    return Unit{};
}


/// The current generation's result fires the `rebuild`'s.
Unit MainArmElseArmElseGen0::generation_up(Unit v, Cx& cx) {
    this->generation_fired(v, cx);
    return Unit{};
}


/// The row left: its places are torn down.
Unit MainArmElseArmElseGen0::remove_places(Cx& cx) const {
    if (auto&& _m = this->generation; prism_rtl::is_some(_m)) {
        auto&& row = prism_rtl::some_of(_m);
        row->leave_row(cx);
    }
    return Unit{};
}


/// The `rebuild` at `this->path.at(1u)`: the old generation torn down (it ran to the end of the
/// tick), the next built at `this->path.at(1u).child(Segment::gen(g))` from the source after the tick.
Done MainArmElseArmElseGen0::generation_build(Cx& cx) {
    if (auto old = std::exchange(this->generation, std::nullopt)) {
        (*old)->leave_row(cx);
        cx.leave_later(*old);
    }
    std::uint32_t g = this->generation_count;
    this->generation_count = g + 1;
    Path path = this->path.at(1u).child(Segment::gen(g));
    std::optional<Outcome_> value = this->outcome.get(cx);
    std::shared_ptr<Row> row = ({
    __label__ _done;
    prism_rtl::Slot<std::shared_ptr<Row>> _v;
    auto&& _m = std::tuple{this->out, value};
    if (prism_rtl::is_none(std::get<1>(_m))) {
        auto&& out = std::get<0>(_m);
        _v.set(static_cast<std::shared_ptr<Row>>(TRY(MainArmElseArmElseGen0Gen0::make(path, out, prism_rtl::weaken(prism_rtl::share(this)), cx))));
        goto _done;
    }
    if (prism_rtl::is_some(std::get<1>(_m))) {
        auto&& out = std::get<0>(_m);
        auto&& o = prism_rtl::some_of(std::get<1>(_m));
        _v.set(static_cast<std::shared_ptr<Row>>(TRY(MainArmElseArmElseGen0Gen1::make(path, out, o, prism_rtl::weaken(prism_rtl::share(this)), cx))));
        goto _done;
    }
    prism_rtl::unreachable("no arm matched");
_done:
    _v.take();
});
    this->generation = row;
    return {};
}


Done MainArmElseArmElseGen0::wake(Cx& cx) {
    if (true) {
        auto left = this->run_turn_left.take(cx);
        auto right = this->run_turn_right.take(cx);
        if (auto&& _m = left; prism_rtl::is_some(_m)) {
            auto&& v = prism_rtl::some_of(_m);
            this->run_turn(v, cx);
        } else if (auto&& _m = right; prism_rtl::is_some(_m)) {
            auto&& v = prism_rtl::some_of(_m);
            this->run_turn(v, cx);
        }
    }
    return {};
}


Done MainArmElseArmElseGen0::started(Cx& cx) {
    this->run_started(Unit{}, cx);
    return {};
}


Done MainArmElseArmElseGen0::deferred(Cx& cx) {
    if (auto&& _m = this->run_again.fired(cx); prism_rtl::is_some(_m)) {
        auto&& v = prism_rtl::some_of(_m);
        this->run_again_(v, cx);
    }
    return {};
}


Done MainArmElseArmElseGen0::build(Cx& cx) {
    if (std::exchange(this->generation_stale, false)) {
        TRY(this->generation_build(cx));
    }
    return {};
}


Done MainArmElseArmElseGen0::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() >= 2 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 1u && prism_rtl::is<pat::Gen>(at[1])) {
        auto&& g = prism_rtl::as<pat::Gen>(at[1]).a0;
        auto rest = at.subspan(2);
        ({
            auto row = this->generation;
            if (auto&& _m = row; prism_rtl::is_some(_m)) {
                auto&& row = prism_rtl::some_of(_m);
                if ((g + 1u) == this->generation_count) {
                    TRY(row->answer(rest, v, cx));
                }
            }
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmElseArmElseGen0::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<std::shared_ptr<MainArmElseArmElseGen0Gen0>> MainArmElseArmElseGen0Gen0::make(Path path, Text out, std::weak_ptr<MainArmElseArmElseGen0> parent, Cx& cx) {
    auto node = std::shared_ptr<MainArmElseArmElseGen0Gen0>(new MainArmElseArmElseGen0Gen0(path, out, parent));
    return node;
}


/// The row left: its places are torn down.
Unit MainArmElseArmElseGen0Gen0::remove_places(Cx& cx) const {

    return Unit{};
}


void MainArmElseArmElseGen0Gen0::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<std::shared_ptr<MainArmElseArmElseGen0Gen1>> MainArmElseArmElseGen0Gen1::make(Path path, Text out, Outcome_ o, std::weak_ptr<MainArmElseArmElseGen0> parent, Cx& cx) {
    std::shared_ptr<Port<Unit>> started_2_v_port = prism_rtl::make_new();
    std::shared_ptr<Port<Fallible<Unit>>> verdict_v_port = prism_rtl::make_new();
    auto first_0 = TRY(ok_or(cx.first_value(prism_rtl::to_pod(crate::Elem(crate::Elem::FsOutput{fs::FsOutput{.path_ = out, .text = o->text}}))), Fault::answer("no first value for Fs.Output")));
    auto place_0_element = prism_rtl::to_pod(crate::Elem(crate::Elem::FsOutput{fs::FsOutput{.path_ = out, .text = o->text}}));
    auto node = std::shared_ptr<MainArmElseArmElseGen0Gen1>(new MainArmElseArmElseGen0Gen1(path, out, o, parent, started_2_v_port, verdict_v_port, {TRY(prism_rtl::from_pod<fs::WriteState>(first_0)), cx}, place_0_element));
    cx.added(node->path.at(0u), prism_rtl::to_pod(crate::Elem(crate::Elem::FsOutput{fs::FsOutput{.path_ = out, .text = o->text}})));
    cx.listen(node->place_0_element, static_cast<std::shared_ptr<Node>>(node));
    cx.added(node->path.at(2u), prism_rtl::to_pod(crate::Elem(crate::Elem::PreludeUnwrap{PreludeUnwrap{}})));
    cx.on_started(node);
    return node;
}


/// `!started_2`.
Unit MainArmElseArmElseGen0Gen1::started_2(Unit v, Cx& cx) {
    prism_rtl::ignore(this->started_2_v_port->fire(v, cx));
    this->verdict(this->o.failed
        ? unexpected(Error("Prismc.Refused", this->o.report))
        : Expected<std::decay_t<decltype(Unit{})>, std::decay_t<decltype(Error("Prismc.Refused", this->o.report))>>(Unit{}), cx);
    return Unit{};
}


/// `!verdict`.
Unit MainArmElseArmElseGen0Gen1::verdict(Fallible<Unit> v, Cx& cx) {
    prism_rtl::ignore(this->verdict_v_port->fire(v, cx));
    cx.request(this->path.at(2u), std::nullopt, prism_rtl::to_pod(v));
    return Unit{};
}


/// `place_2`: an answer at its place.
Unit MainArmElseArmElseGen0Gen1::place_2(Unit v, Cx& cx) {

    return Unit{};
}


/// The row left: its places are torn down.
Unit MainArmElseArmElseGen0Gen1::remove_places(Cx& cx) const {
    cx.removed(this->path.at(0u));
    cx.removed(this->path.at(2u));
    return Unit{};
}


Done MainArmElseArmElseGen0Gen1::started(Cx& cx) {
    this->started_2(Unit{}, cx);
    return {};
}


Done MainArmElseArmElseGen0Gen1::push(const Pod& element, const Pod& v, Cx& cx) {
    if (element == this->place_0_element) {
        this->place_0.set(TRY(prism_rtl::from_pod<fs::WriteState>(v)), cx);
    }
    return {};
}


Done MainArmElseArmElseGen0Gen1::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() == 1 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 2u) {
        this->place_2(TRY(prism_rtl::from_pod<Unit>(v)), cx);
    } else if (at.size() == 1 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 0u) {
        ({
            this->place_0.set(TRY(prism_rtl::from_pod<fs::WriteState>(v)), cx);
            Unit{};
        });
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmElseArmElseGen0Gen1::leave_row(Cx& cx) {
    remove_places(cx);
}


/// Built after propagation: holds take their initial values, places go out with
/// `cx.added`, and nothing fires.
Result<std::shared_ptr<MainArmElseArmElseGen1>> MainArmElseArmElseGen1::make(Path path, Job_ job, Text file, Text out, Text m, std::weak_ptr<MainArmElseArmElse> parent, Cx& cx) {
    std::shared_ptr<Port<Unit>> started_2_v_port = prism_rtl::make_new();
    std::shared_ptr<Port<Fallible<Unit>>> gave_up_v_port = prism_rtl::make_new();
    auto node = std::shared_ptr<MainArmElseArmElseGen1>(new MainArmElseArmElseGen1(path, job, file, out, m, parent, started_2_v_port, gave_up_v_port));
    cx.added(node->path.at(1u), prism_rtl::to_pod(crate::Elem(crate::Elem::PreludeUnwrap{PreludeUnwrap{}})));
    cx.on_started(node);
    return node;
}


/// `!started_2`.
Unit MainArmElseArmElseGen1::started_2(Unit v, Cx& cx) {
    prism_rtl::ignore(this->started_2_v_port->fire(v, cx));
    this->gave_up(unexpected(Error("Prismc.Refused", prism_rtl::cat("cannot read ", this->file, ": ", this->m))), cx);
    return Unit{};
}


/// `!gave_up`.
Unit MainArmElseArmElseGen1::gave_up(Fallible<Unit> v, Cx& cx) {
    prism_rtl::ignore(this->gave_up_v_port->fire(v, cx));
    cx.request(this->path.at(1u), std::nullopt, prism_rtl::to_pod(v));
    return Unit{};
}


/// `place_1`: an answer at its place.
Unit MainArmElseArmElseGen1::place_1(Unit v, Cx& cx) {

    return Unit{};
}


/// The row left: its places are torn down.
Unit MainArmElseArmElseGen1::remove_places(Cx& cx) const {
    cx.removed(this->path.at(1u));
    return Unit{};
}


Done MainArmElseArmElseGen1::started(Cx& cx) {
    this->started_2(Unit{}, cx);
    return {};
}


Done MainArmElseArmElseGen1::answer(std::span<const Segment> at, const Pod& v, Cx& cx) {
    if (at.size() == 1 && prism_rtl::is<pat::Pos>(at[0]) && prism_rtl::as<pat::Pos>(at[0]).a0 == 1u) {
        this->place_1(TRY(prism_rtl::from_pod<Unit>(v)), cx);
    } else {
        return unexpected(Fault::answer(str("no answering place at ", path_of(at))));
    }
    return {};
}


void MainArmElseArmElseGen1::leave_row(Cx& cx) {
    remove_places(cx);
}


// `@CheckMain` is inlined where it is applied.

// `@CheckChecked` is inlined where it is applied.

// `@Check` is inlined where it is applied.

/// ContentsText: fn ~Contents -> Text
Text contents_text(const Fallible<fs::Contents>& arg0) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        if (prism_rtl::is_ok(arg0)) {
            auto&& c = *arg0;
            _v.set(c->text);
            goto _done;
        }
        if (prism_rtl::is_err(arg0)) {
            auto&& c1_0 = arg0.error();
            _v.set(Text(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


// `@FinishCheck` is inlined where it is applied.

// `@WriteOut` is inlined where it is applied.

// `@FrontMain` is inlined where it is applied.

// `@Compile` is inlined where it is applied.

// `@Finish` is inlined where it is applied.

// `@CompileMain` is inlined where it is applied.

/// let compileValued
Array<Text> compile_valued() {
    return Array(std::vector{Text("-o"), Text("--prelude"), Text("--name"), Text("--runtime"), Text("--target")});
}


// `@CompileChecked` is inlined where it is applied.

/// IsSourcePath: fn Text -> Bool
bool is_source_path(const Text& f) {
    return ends_with_text(f, Text(".prism")) || ends_with_text(f, Text(".prismtest"));
}


/// EndsWithText: fn Text, Text -> Bool
bool ends_with_text(const Text& t, const Text& suffix) {
    return lexer::has_suffix(t, suffix);
}


/// RuntimeFor: fn Text -> Text
Text runtime_for(const Text& out) {
    auto parts = filter(split(out, Text("/")), [&](const Text& p_) { return (p_ != Text("")) && (p_ != Text(".")); });
    return len(parts) == Nat(0u)
        ? Text(".")
        : lexer::join(each(parts, [&](const Text& _p0) { return Text(".."); }), Text("/"));
}


/// CompileFiles: fn [Text] -> [Text]
Array<Text> compile_files(const Array<Text>& args) {
    auto&& _kept = fold(args, std::tuple{Array<Text>{}, false}, [&](const std::tuple<Array<Text>, bool>& _p0, const Text& a) {
        auto&& acc = std::get<0>(_p0);
        auto&& skip = std::get<1>(_p0);
        return skip
            ? std::tuple{acc, false}
            : check_types::has_text(compile_valued(), a)
            ? std::tuple{acc, true}
            : lexer::has_prefix(a, Text("-"))
            ? std::tuple{acc, false}
            : std::tuple{prelude::push(acc, a), false};
    });
    auto&& kept = std::get<0>(_kept);
    return kept;
}


// `@CompileRead` is inlined where it is applied.

// `@CompileAll` is inlined where it is applied.

/// CompileProgram: unbounded fn CompileJob -> Compiled
Compiled compile_program(const CompileJob& job) {
    auto tests = filter(job->files, [&](const std::tuple<Text, Text>& _p0) {
        auto&& p_ = std::get<0>(_p0);
        return ends_with_text(p_, Text(".prismtest"));
    });
    auto progs = filter(job->files, [&](const std::tuple<Text, Text>& _p0) {
        auto&& p_ = std::get<0>(_p0);
        return !ends_with_text(p_, Text(".prismtest"));
    });
    auto joined = each(progs, [&](const std::tuple<Text, Text>& _p0) {
        auto&& p_ = std::get<0>(_p0);
        auto&& t = std::get<1>(_p0);
        return std::tuple{p_, with_tests(p_, t, tests)};
    });
    auto parsed = run_to_end(each_job(joined, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, Text, parser::Parsed>>(std::tuple<Text, Text>)>>(prism_rtl::rc([=](std::tuple<Text, Text> p0) {
        return entered(once_job([=]() {
            return ({
                auto [path_, text] = p0;
                call_then(parser::start_parse_file(text), [=](parser::Parsed parse_file_17816) { return prism_rtl::finished(std::tuple{path_, text, parse_file_17816}); });
            });
        }));
    }))));
    auto user_mods = fold(parsed, Array<Text>{}, [&](const Array<Text>& acc, const std::tuple<Text, Text, parser::Parsed>& _p1) {
        auto&& pr = std::get<2>(_p1);
        return prelude::push(acc, check_env::mod_name(pr.tree));
    });
    auto user_fams = fold(parsed, Array<Text>{}, [&](const Array<Text>& acc, const std::tuple<Text, Text, parser::Parsed>& _p1) {
        auto&& pr = std::get<2>(_p1);
        return append(acc, tag_families(pr.tree));
    });
    auto pre_parsed = run_to_end(each_job(job->prelude, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, Text, parser::Parsed>>(std::tuple<Text, Text>)>>(prism_rtl::rc([=](std::tuple<Text, Text> p0) {
        return entered(once_job([=]() {
            return ({
                auto [path_, text] = p0;
                call_then(parser::start_parse_file(text), [=](parser::Parsed parse_file_18105) { return prism_rtl::finished(std::tuple{path_, text, parse_file_18105}); });
            });
        }));
    }))));
    auto kept = filter(pre_parsed, [&](const std::tuple<Text, Text, parser::Parsed>& _p0) {
        auto&& pr = std::get<2>(_p0);
        return (!check_types::has_text(user_mods, check_env::mod_name(pr.tree))) && (!any_in(tag_families(pr.tree), user_fams));
    });
    auto all = append(parsed, kept);
    auto parse_diags = fold(all, Text(""), [&](const Text& acc, const std::tuple<Text, Text, parser::Parsed>& _p1) {
        auto&& path_ = std::get<0>(_p1);
        auto&& text = std::get<1>(_p1);
        auto&& pr = std::get<2>(_p1);
        return any_errors(pr.diags)
            ? prism_rtl::cat(acc, render_parse(path_, text, pr.diags))
            : acc;
    });
    return parse_diags != Text("")
        ? Compiled{.files = Array<std::tuple<Text, Text>>{}, .failed = true, .report = prism_rtl::cat(parse_diags, "parse errors")}
        : ({
        auto srcs = each(all, [&](const std::tuple<Text, Text, parser::Parsed>& _p0) {
            auto&& path_ = std::get<0>(_p0);
            auto&& text = std::get<1>(_p0);
            return check_errors::mk_src(path_, text);
        });
        auto trees = each(all, [&](const std::tuple<Text, Text, parser::Parsed>& _p0) {
            auto&& pr = std::get<2>(_p0);
            return pr.tree;
        });
        auto report = check_passes::check_program(srcs, each(trees, [&](const ast::Module& t) { return without_tests(t); }), Array<Text>{}, len(parsed), true, false);
        report.errors > Nat(0u)
        ? Compiled{.files = Array<std::tuple<Text, Text>>{}, .failed = true, .report = prism_rtl::cat(report->text, report.errors, " error", report.errors == Nat(1u) ? Text("") : Text("s"))}
        : ({
        auto model = lower::lower_program(srcs, trees, len(parsed), report->typed, job.name);
        auto scripts = each(tests, [&](const std::tuple<Text, Text>& _p0) {
            auto&& p_ = std::get<0>(_p0);
            return p_;
        });
        auto files = job->target == Text("cpp")
            ? emit_cpp::emit_cpp(model, job.runtime, scripts)
            : emit::emit_crate(model, job.runtime, scripts);
        auto refused = fold(files, Array<Text>{}, [&](const Array<Text>& acc, const std::tuple<Text, Text>& _p1) {
            auto&& path_ = std::get<0>(_p1);
            auto&& text = std::get<1>(_p1);
            return fold(refusals(text), acc, [&](const Array<Text>& a, const Text& r) { return check_types::add_text(a, prism_rtl::cat(path_, ": ", r)); });
        });
        len(refused) == Nat(0u)
        ? Compiled{.files = files, .failed = false, .report = Text("")}
        : Compiled{.files = files, .failed = true, .report = prism_rtl::cat(concat(each(refused, [&](const Text& r) { return prism_rtl::cat("error[not-lowered]: ", r, "\n"); })), len(refused), " construct", len(refused) == Nat(1u) ? Text("") : Text("s"), " the back end does not lower (the crate is written, with a `compile_error!` at each)")};
    });
    });
}


prism_rtl::Turn<Compiled> CompileProgram::cycle() const {
    const auto& job = this->job;
    auto tests = filter(job->files, [&](const std::tuple<Text, Text>& _p0) {
        auto&& p_ = std::get<0>(_p0);
        return ends_with_text(p_, Text(".prismtest"));
    });
    auto progs = filter(job->files, [&](const std::tuple<Text, Text>& _p0) {
        auto&& p_ = std::get<0>(_p0);
        return !ends_with_text(p_, Text(".prismtest"));
    });
    auto joined = each(progs, [&](const std::tuple<Text, Text>& _p0) {
        auto&& p_ = std::get<0>(_p0);
        auto&& t = std::get<1>(_p0);
        return std::tuple{p_, with_tests(p_, t, tests)};
    });
    auto job_1 = job;
    return call_value(each_job(joined, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, Text, parser::Parsed>>(std::tuple<Text, Text>)>>(prism_rtl::rc([=](std::tuple<Text, Text> p0) {
        return entered(once_job([=]() {
            return ({
                auto [path_, text] = p0;
                call_then(parser::start_parse_file(text), [=](parser::Parsed parse_file_17816) { return prism_rtl::finished(std::tuple{path_, text, parse_file_17816}); });
            });
        }));
    }))), [=](Array<std::tuple<Text, Text, parser::Parsed>> each_17770) {
        return ({
            auto parsed = each_17770;
            auto user_mods = fold(parsed, Array<Text>{}, [&](const Array<Text>& acc, const std::tuple<Text, Text, parser::Parsed>& _p1) {
                auto&& pr = std::get<2>(_p1);
                return prelude::push(acc, check_env::mod_name(pr.tree));
            });
            auto user_fams = fold(parsed, Array<Text>{}, [&](const Array<Text>& acc, const std::tuple<Text, Text, parser::Parsed>& _p1) {
                auto&& pr = std::get<2>(_p1);
                return append(acc, tag_families(pr.tree));
            });
            call_value(each_job(job_1->prelude, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, Text, parser::Parsed>>(std::tuple<Text, Text>)>>(prism_rtl::rc([=](std::tuple<Text, Text> p0) {
            return entered(once_job([=]() {
                return ({
                    auto [path_, text] = p0;
                    call_then(parser::start_parse_file(text), [=](parser::Parsed parse_file_18105) { return prism_rtl::finished(std::tuple{path_, text, parse_file_18105}); });
                });
            }));
        }))), [=](Array<std::tuple<Text, Text, parser::Parsed>> each_18054) {
            return ({
                auto pre_parsed = each_18054;
                auto kept = filter(pre_parsed, [&](const std::tuple<Text, Text, parser::Parsed>& _p0) {
                    auto&& pr = std::get<2>(_p0);
                    return (!check_types::has_text(user_mods, check_env::mod_name(pr.tree))) && (!any_in(tag_families(pr.tree), user_fams));
                });
                auto all = append(parsed, kept);
                auto parse_diags = fold(all, Text(""), [&](const Text& acc, const std::tuple<Text, Text, parser::Parsed>& _p1) {
                    auto&& path_ = std::get<0>(_p1);
                    auto&& text = std::get<1>(_p1);
                    auto&& pr = std::get<2>(_p1);
                    return any_errors(pr.diags)
                        ? prism_rtl::cat(acc, render_parse(path_, text, pr.diags))
                        : acc;
                });
                parse_diags != Text("")
                ? prism_rtl::finished(Compiled{.files = Array<std::tuple<Text, Text>>{}, .failed = true, .report = prism_rtl::cat(parse_diags, "parse errors")})
                : ({
                auto srcs = each(all, [&](const std::tuple<Text, Text, parser::Parsed>& _p0) {
                    auto&& path_ = std::get<0>(_p0);
                    auto&& text = std::get<1>(_p0);
                    return check_errors::mk_src(path_, text);
                });
                auto trees = each(all, [&](const std::tuple<Text, Text, parser::Parsed>& _p0) {
                    auto&& pr = std::get<2>(_p0);
                    return pr.tree;
                });
                call_then(check_passes::start_check_program(srcs, each(trees, [&](const ast::Module& t) { return without_tests(t); }), Array<Text>{}, len(parsed), true, false), [=](check_passes::Report_ check_program_18704) {
                return ({
                    auto report = check_program_18704;
                    report.errors > Nat(0u)
                    ? prism_rtl::finished(Compiled{.files = Array<std::tuple<Text, Text>>{}, .failed = true, .report = prism_rtl::cat(report->text, report.errors, " error", report.errors == Nat(1u) ? Text("") : Text("s"))})
                    : call_then(lower::start_lower_program(srcs, trees, len(parsed), report->typed, job_1.name), [=](lower::Model lower_program_18974) {
                    return ({
                        auto model = lower_program_18974;
                        auto scripts = each(tests, [&](const std::tuple<Text, Text>& _p0) {
                            auto&& p_ = std::get<0>(_p0);
                            return p_;
                        });
                        auto files = job_1->target == Text("cpp")
                            ? emit_cpp::emit_cpp(model, job_1.runtime, scripts)
                            : emit::emit_crate(model, job_1.runtime, scripts);
                        auto refused = fold(files, Array<Text>{}, [&](const Array<Text>& acc, const std::tuple<Text, Text>& _p1) {
                            auto&& path_ = std::get<0>(_p1);
                            auto&& text = std::get<1>(_p1);
                            return fold(refusals(text), acc, [&](const Array<Text>& a, const Text& r) { return check_types::add_text(a, prism_rtl::cat(path_, ": ", r)); });
                        });
                        len(refused) == Nat(0u)
                        ? prism_rtl::finished(Compiled{.files = files, .failed = false, .report = Text("")})
                        : prism_rtl::finished(Compiled{.files = files, .failed = true, .report = prism_rtl::cat(concat(each(refused, [&](const Text& r) { return prism_rtl::cat("error[not-lowered]: ", r, "\n"); })), len(refused), " construct", len(refused) == Nat(1u) ? Text("") : Text("s"), " the back end does not lower (the crate is written, with a `compile_error!` at each)")});
                    });
                });
                });
            });
            });
            });
        });
        });
    });
}


/// `Start CompileProgram, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Compiled> start_compile_program(CompileJob job) {
    return std::make_shared<CompileProgram>(job);
}


/// Refusals: fn Text -> [Text]
Array<Text> refusals(const Text& text) {
    auto marker = Text("compile_error!(\"prismc does not lower ");
    auto parts = split(text, marker);
    return fold(drop(parts, Nat(1u)), Array<Text>{}, [&](const Array<Text>& acc, const Text& part) { return check_types::add_text(acc, or_(index(split(part, Text("\")")), Nat(0u)), part)); });
}


/// WithoutTests: fn Module -> Module
ast::Module without_tests(const ast::Module& m) {
    ast::Module this_ = m;
    this_.decls = each(filter(this_.decls, [&](const ast::Decl& d) { return !is_test_decl(d); }), [&](const ast::Decl& d) { return without_patterns(d); });
    return this_;
}


/// WithoutPatterns: fn Decl -> Decl
ast::Decl without_patterns(const ast::Decl& d) {
    return ({
        __label__ _done;
        prism_rtl::Slot<ast::Decl> _v;
        auto&& _m = d.kind;
        if (prism_rtl::is<ast::DeclKind::DCheck>(_m)) {
            auto&& c = prism_rtl::as<ast::DeclKind::DCheck>(_m).a0;
            _v.set(({
                ast::Decl this_ = d;
                this_.kind = ast::DeclKind(ast::DeclKind::DCheck{check_without_patterns(c)});
                this_;
            }));
            goto _done;
        }
        {
            _v.set(d);
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// CheckWithoutPatterns: fn CheckDecl -> CheckDecl
ast::CheckDecl check_without_patterns(const ast::CheckDecl& c) {
    ast::CheckDecl this_ = c;
    this_.lines = each(this_.lines, [&](const ast::CheckLine& l) { return line_without_pattern(l); });
    return this_;
}


/// LineWithoutPattern: fn CheckLine -> CheckLine
ast::CheckLine line_without_pattern(const ast::CheckLine& l) {
    ast::CheckLine this_ = l;
    this_.pattern = std::optional<ast::Pattern_>{};
    return this_;
}


/// IsTestDecl: fn Decl -> Bool
bool is_test_decl(const ast::Decl& d) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = d.kind;
        if (prism_rtl::is<ast::DeclKind::DTest>(_m)) {
            _v.set(true);
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// WithTests: fn Text, Text, [((Text, Text))] -> Text
Text with_tests(const Text& path_, const Text& text, const Array<std::tuple<Text, Text>>& tests) {
    auto stem = or_(lexer::before_suffix(path_, Text(".prism")), path_);
    return fold(tests, text, [&](const Text& acc, const std::tuple<Text, Text>& _p1) {
        auto&& tp = std::get<0>(_p1);
        auto&& tt = std::get<1>(_p1);
        return tp == prism_rtl::cat(stem, ".prismtest")
            ? prism_rtl::cat(acc, "\n", tt)
            : acc;
    });
}


// `@FinishCompile` is inlined where it is applied.

}  // namespace crate::program
