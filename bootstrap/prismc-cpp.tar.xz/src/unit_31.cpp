// The module `Emit.Cpp.Items`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <emit/cpp/items/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Emit.Cpp.Items`, from `target/bootstrap/cpp-src/prismc/emit/cpp/items.prism`.
namespace crate::emit::cpp::items {

bool Parts::operator==(const Parts& o) const { return forward == o.forward && values == o.values && protos == o.protos && classes == o.classes && outer == o.outer && generic == o.generic && defs == o.defs; }

void Parts::show(Printer& p) const {
    p.record("Parts", {{"forward", forward}, {"values", values}, {"protos", protos}, {"classes", classes}, {"outer", outer}, {"generic", generic}, {"defs", defs}});
}

Pod Parts::to_pod() const {
    return Pod::record("Parts", {{"forward", prism_rtl::to_pod(forward)}, {"values", prism_rtl::to_pod(values)}, {"protos", prism_rtl::to_pod(protos)}, {"classes", prism_rtl::to_pod(classes)}, {"outer", prism_rtl::to_pod(outer)}, {"generic", prism_rtl::to_pod(generic)}, {"defs", prism_rtl::to_pod(defs)}});
}

Result<Parts> Parts::from_pod(const Pod& whole) {
    return Parts{.forward = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "forward")))), .values = TRY(prism_rtl::from_pod<Array<ValueDecl>>(TRY(crate::prelude::field(whole, "values")))), .protos = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "protos")))), .classes = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "classes")))), .outer = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "outer")))), .generic = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "generic")))), .defs = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "defs"))))};
}


void ValueDecl::show(Printer& p) const {
    p.record("ValueDecl", {{"path", path_}, {"deps", deps}, {"text", text}});
}

Pod ValueDecl::to_pod() const {
    return Pod::record("ValueDecl", {{"path", prism_rtl::to_pod(path_)}, {"deps", prism_rtl::to_pod(deps)}, {"text", prism_rtl::to_pod(text)}});
}

Result<ValueDecl> ValueDecl::from_pod(const Pod& whole) {
    return ValueDecl{.path_ = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "path")))), .deps = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "deps")))), .text = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "text"))))};
}


/// CppTemplateHead: fn [Text] -> Text
Text cpp_template_head(const Array<Text>& xs0) {
    {
        auto&& c0_0 = xs0;
        if (c0_0.size() == 0u) {
            return Text::lit("");
        }
    }
    {
        auto&& ps = xs0;
        return prism_rtl::cat("template <", crate::syntax::lexer::chars::join(each(ps, [&](const Text& p_) { return prism_rtl::cat("class ", p_); }), Text::lit(", ")), ">\n");
    }
}


/// GenericNamesOf: fn [((Text, [Text]))] -> [Text]
Array<Text> generic_names_of(const Array<std::tuple<Text, Array<Text>>>& gs) {
    return each(gs, [&](const std::tuple<Text, Array<Text>>& _p0) {
        auto&& g = std::get<0>(_p0);
        return g;
    });
}


/// HeadOf: fn Text, [Text] -> Text
Text head_of(const Text& name, const Array<Text>& xs1) {
    {
        auto&& c0_1 = xs1;
        if (c0_1.size() == 0u) {
            return name;
        }
    }
    {
        auto&& ps = xs1;
        return prism_rtl::cat(name, "<", crate::syntax::lexer::chars::join(ps, Text::lit(", ")), ">");
    }
}


/// CppParams: unbounded fn Cp, [((Text, OutTy))] -> Text
Text cpp_params(const crate::emit::cpp::Cp& cp, const Array<std::tuple<Text, crate::lower::model::OutTy>>& ps) {
    return crate::syntax::lexer::chars::join(run_to_end(each_job(ps, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=]() {
            return ({
                auto [n, t] = p0;
                call_then(crate::emit::cpp::expr::start_param_type(cp_1_2, t), [=](Text param_type_1510) { return prism_rtl::finished(prism_rtl::cat(param_type_1510, " ", crate::emit::cpp::cpp_id(n))); });
            });
        }));
        });
    })));
    }))), Text::lit(", "));
}


prism_rtl::Turn<Text> CppParams::cycle() const {
    const auto& cp = this->cp;
    const auto& ps = this->ps;
    auto cp_1 = cp;
    auto ps_2 = ps;
    return call_value(each_job(ps_2, ({
        auto cp_1_3 = cp_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
        return ({
            auto cp_1_3_3 = cp_1_3;
            entered(once_job([=]() {
            return ({
                auto [n, t] = p0;
                call_then(crate::emit::cpp::expr::start_param_type(cp_1_3_3, t), [=](Text param_type_1510) { return prism_rtl::finished(prism_rtl::cat(param_type_1510, " ", crate::emit::cpp::cpp_id(n))); });
            });
        }));
        });
    })));
    })), [=](Array<Text> each_1487) { return prism_rtl::finished(crate::syntax::lexer::chars::join(each_1487, Text::lit(", "))); });
}


/// `Start CppParams, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_params(crate::emit::cpp::Cp cp, Array<std::tuple<Text, crate::lower::model::OutTy>> ps) {
    return prism_rtl::make_rc<CppParams>(cp, ps);
}


/// FnSignature: unbounded fn Cp, FnDef -> Text
Text fn_signature(const crate::emit::cpp::Cp& cp, const crate::lower::model::FnDef& f) {
    return prism_rtl::cat(cpp_template_head(generic_names_of(f.generics)), crate::emit::cpp::cpp_type(cp, f.ret), " ", crate::emit::cpp::cpp_id(f.name), "(", cpp_params(cp, f.params), ")");
}


prism_rtl::Turn<Text> FnSignature::cycle() const {
    const auto& cp = this->cp;
    const auto& f = this->f;
    auto cp_1 = cp;
    auto f_2 = f;
    return call_then(crate::emit::cpp::start_cpp_type(cp_1, prism_rtl::val(f_2).ret), [=](Text cpp_type_1741) { return call_then(start_cpp_params(cp_1, prism_rtl::val(f_2).params), [=](Text cpp_params_1776) { return prism_rtl::finished(prism_rtl::cat(cpp_template_head(generic_names_of(prism_rtl::val(f_2).generics)), cpp_type_1741, " ", crate::emit::cpp::cpp_id(prism_rtl::val(f_2).name), "(", cpp_params_1776, ")")); }); });
}


/// `Start FnSignature, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_fn_signature(crate::emit::cpp::Cp cp, crate::lower::model::FnDef f) {
    return prism_rtl::make_rc<FnSignature>(cp, f);
}


/// FnDefinition: unbounded fn Cp, FnDef -> Text
Text fn_definition(const crate::emit::cpp::Cp& cp, const crate::lower::model::FnDef& f) {
    return crate::emit::cpp::templates::items::cpp_function(cpp_doc(f.doc), fn_signature(cp, f), crate::emit::cpp::stmts::cpp_body(with_params(cp, f.params), f.body));
}


prism_rtl::Turn<Text> FnDefinition::cycle() const {
    const auto& cp = this->cp;
    const auto& f = this->f;
    auto cp_1 = cp;
    auto f_2 = f;
    return call_then(start_fn_signature(cp_1, f_2), [=](Text fn_signature_1901) { return call_then(crate::emit::cpp::stmts::start_cpp_body(with_params(cp_1, prism_rtl::val(f_2).params), prism_rtl::val(f_2).body), [=](Text cpp_body_1922) { return prism_rtl::finished(crate::emit::cpp::templates::items::cpp_function(cpp_doc(prism_rtl::val(f_2).doc), fn_signature_1901, cpp_body_1922)); }); });
}


/// `Start FnDefinition, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_fn_definition(crate::emit::cpp::Cp cp, crate::lower::model::FnDef f) {
    return prism_rtl::make_rc<FnDefinition>(cp, f);
}


/// WithParams: fn Cp, [((Text, OutTy))] -> Cp
crate::emit::cpp::Cp with_params(const crate::emit::cpp::Cp& cp, const Array<std::tuple<Text, crate::lower::model::OutTy>>& ps) {
    return fold(ps, cp, [&](const crate::emit::cpp::Cp& c, const std::tuple<Text, crate::lower::model::OutTy>& _p1) {
        auto&& n = std::get<0>(_p1);
        auto&& t = std::get<1>(_p1);
        return ({
            crate::emit::cpp::Cp this_ = c;
            this_.pointers = insert(this_.pointers, n, crate::emit::cpp::expr::is_pointer_ty(c, crate::emit::cpp::expr::unref(t)));
            this_;
        });
    });
}


/// ValueDeps: unbounded fn Cp, OutTy -> [Text]
Array<Text> value_deps(const crate::emit::cpp::Cp& cp, const crate::lower::model::OutTy& t) {
    if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t)) {
        auto&& n = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t).a0;
        auto&& args = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t).a1;
        auto own = ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = crate::emit::cpp::type_of(cp, n);
            if (prism_rtl::is_some(_m)) {
                auto&& info = prism_rtl::some_of(_m);
                _v.set(((((prism_rtl::val(info).kind == Text::lit("record")) || (prism_rtl::val(info).kind == Text::lit("newtype"))) || (prism_rtl::val(info).kind == Text::lit("unit"))) || (prism_rtl::val(info).kind == Text::lit("tag"))) || (prism_rtl::val(info).kind == Text::lit("choice"))
                    ? Array(std::vector{dep_path(cp, n)})
                    : Array<Text>{});
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(Array<Text>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        return append(own, crate::emit::cpp::patterns::concat2(run_to_end(each_job(args, ({
            auto cp_1 = cp;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(crate::lower::model::OutTy)>>(prism_rtl::rc([=](crate::lower::model::OutTy p0) {
            return ({
                auto cp_1_2 = cp_1;
                entered(once_job([=]() {
                return ({
                    auto a = p0;
                    (prism_rtl::more(prism_rtl::rc(ValueDeps(cp_1_2, a))));
                });
            }));
            });
        })));
        })))));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutOpt>(t)) {
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutOpt>(t).a0;
        return value_deps(cp, prism_rtl::val(prism_rtl::val(i)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutRes>(t)) {
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutRes>(t).a0;
        return value_deps(cp, prism_rtl::val(prism_rtl::val(i)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutCell>(t)) {
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutCell>(t).a0;
        return value_deps(cp, prism_rtl::val(prism_rtl::val(i)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutTuple>(t)) {
        auto&& ts = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(t).a0;
        return crate::emit::cpp::patterns::concat2(run_to_end(each_job(ts, ({
            auto cp_1 = cp;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(crate::lower::model::OutTy)>>(prism_rtl::rc([=](crate::lower::model::OutTy p0) {
            return ({
                auto cp_1_2 = cp_1;
                entered(once_job([=]() {
                return ({
                    auto a = p0;
                    (prism_rtl::more(prism_rtl::rc(ValueDeps(cp_1_2, a))));
                });
            }));
            });
        })));
        }))));
    }
    {
        return Array<Text>{};
    }
}


prism_rtl::Turn<Array<Text>> ValueDeps::cycle() const {
    const auto& cp = this->cp;
    const auto& t = this->t;
    return ({
        prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t) ? ({
        auto&& n = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t).a0;
        auto&& args = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t).a1;
        ({
        auto own = ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = crate::emit::cpp::type_of(cp, n);
            if (prism_rtl::is_some(_m)) {
                auto&& info = prism_rtl::some_of(_m);
                _v.set(((((prism_rtl::val(info).kind == Text::lit("record")) || (prism_rtl::val(info).kind == Text::lit("newtype"))) || (prism_rtl::val(info).kind == Text::lit("unit"))) || (prism_rtl::val(info).kind == Text::lit("tag"))) || (prism_rtl::val(info).kind == Text::lit("choice"))
                    ? Array(std::vector{dep_path(cp, n)})
                    : Array<Text>{});
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(Array<Text>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto args_1 = args;
        auto cp_2 = cp;
        call_value(each_job(args_1, ({
        auto cp_2_3 = cp_2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(crate::lower::model::OutTy)>>(prism_rtl::rc([=](crate::lower::model::OutTy p0) {
        return ({
            auto cp_2_3_3 = cp_2_3;
            entered(once_job([=]() {
            return ({
                auto a = p0;
                (prism_rtl::more(prism_rtl::rc(ValueDeps(cp_2_3_3, a))));
            });
        }));
        });
    })));
    })), [=](Array<Array<Text>> each_3836) { return prism_rtl::finished(append(own, crate::emit::cpp::patterns::concat2(each_3836))); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutOpt>(t) ? ({
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutOpt>(t).a0;
        prism_rtl::more(prism_rtl::rc(ValueDeps(cp, prism_rtl::val(prism_rtl::val(i)))));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutRes>(t) ? ({
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutRes>(t).a0;
        prism_rtl::more(prism_rtl::rc(ValueDeps(cp, prism_rtl::val(prism_rtl::val(i)))));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutCell>(t) ? ({
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutCell>(t).a0;
        prism_rtl::more(prism_rtl::rc(ValueDeps(cp, prism_rtl::val(prism_rtl::val(i)))));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutTuple>(t) ? ({
        auto&& ts = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(t).a0;
        ({
        auto cp_1 = cp;
        auto ts_2 = ts;
        call_value(each_job(ts_2, ({
        auto cp_1_3 = cp_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(crate::lower::model::OutTy)>>(prism_rtl::rc([=](crate::lower::model::OutTy p0) {
        return ({
            auto cp_1_3_3 = cp_1_3;
            entered(once_job([=]() {
            return ({
                auto a = p0;
                (prism_rtl::more(prism_rtl::rc(ValueDeps(cp_1_3_3, a))));
            });
        }));
        });
    })));
    })), [=](Array<Array<Text>> each_3987) { return prism_rtl::finished(crate::emit::cpp::patterns::concat2(each_3987)); });
    });
    })
        : prism_rtl::finished(Array<Text>{});
    });
}


/// `Start ValueDeps, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_value_deps(crate::emit::cpp::Cp cp, crate::lower::model::OutTy t) {
    return prism_rtl::make_rc<ValueDeps>(cp, t);
}


/// DepPath: fn Cp, Text -> Text
Text dep_path(const crate::emit::cpp::Cp& cp, const Text& n) {
    auto abs_ = crate::emit::cpp::absolute(cp, n);
    auto q = crate::syntax::lexer::chars::drop_prefix(n, Text::lit("crate::"));
    auto&& _m = crate::prelude::get(cp.types, abs_);
    if (prism_rtl::is_some(_m)) {
        return abs_;
    }
    if (prism_rtl::is_none(_m)) {
        return q;
    }
    prism_rtl::unreachable("no arm matched");
}


/// Behind: unbounded fn Cp, OutTy -> Bool
bool behind(const crate::emit::cpp::Cp& cp, const crate::lower::model::OutTy& t) {
    if (prism_rtl::is<crate::lower::model::OutTy::OutRc>(t)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutOpt>(t)) {
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutOpt>(t).a0;
        return behind(cp, prism_rtl::val(prism_rtl::val(i)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutRes>(t)) {
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutRes>(t).a0;
        return behind(cp, prism_rtl::val(prism_rtl::val(i)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutCell>(t)) {
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutCell>(t).a0;
        return behind(cp, prism_rtl::val(prism_rtl::val(i)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutTuple>(t)) {
        auto&& ts = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(t).a0;
        return run_to_end(fold_job(ts, false, ({
            auto cp_1 = cp;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<bool, crate::lower::model::OutTy> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto cp_1_2 = cp_1;
                entered(once_job([=]() {
                return ({
                    auto f = p0;
                    auto x = p1;
                    (prism_rtl::finished(f || behind(cp_1_2, x)));
                });
            }));
            });
        })));
        })));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutArray>(t)) {
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutArray>(t).a0;
        return names_program_type(cp, prism_rtl::val(prism_rtl::val(i)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutMap>(t)) {
        auto&& k = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t).a0;
        auto&& v_ = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t).a1;
        return names_program_type(cp, prism_rtl::val(prism_rtl::val(k))) || names_program_type(cp, prism_rtl::val(prism_rtl::val(v_)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutFn>(t)) {
        auto&& ps = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t).a0;
        auto&& r = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t).a1;
        return run_to_end(fold_job(ps, names_program_type(cp, prism_rtl::val(prism_rtl::val(r))), ({
            auto cp_1 = cp;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<bool, crate::lower::model::OutTy> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto cp_1_2 = cp_1;
                entered(once_job([=]() {
                return ({
                    auto f = p0;
                    auto x = p1;
                    (prism_rtl::finished(f || names_program_type(cp_1_2, x)));
                });
            }));
            });
        })));
        })));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutDyn>(t)) {
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(t).a0;
        return names_program_type(cp, prism_rtl::val(prism_rtl::val(i)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutEvent>(t)) {
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutEvent>(t).a0;
        return names_program_type(cp, prism_rtl::val(prism_rtl::val(i)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t)) {
        auto&& args = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t).a1;
        return run_to_end(fold_job(args, false, ({
            auto cp_1 = cp;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<bool, crate::lower::model::OutTy> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto cp_1_2 = cp_1;
                entered(once_job([=]() {
                return ({
                    auto f = p0;
                    auto x = p1;
                    (prism_rtl::finished(f || behind(cp_1_2, x)));
                });
            }));
            });
        })));
        })));
    }
    {
        return false;
    }
}


prism_rtl::Turn<bool> Behind::cycle() const {
    const auto& cp = this->cp;
    const auto& t = this->t;
    return ({
        prism_rtl::is<crate::lower::model::OutTy::OutRc>(t) ? prism_rtl::finished(true)
        : prism_rtl::is<crate::lower::model::OutTy::OutOpt>(t) ? ({
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutOpt>(t).a0;
        prism_rtl::more(prism_rtl::rc(Behind(cp, prism_rtl::val(prism_rtl::val(i)))));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutRes>(t) ? ({
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutRes>(t).a0;
        prism_rtl::more(prism_rtl::rc(Behind(cp, prism_rtl::val(prism_rtl::val(i)))));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutCell>(t) ? ({
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutCell>(t).a0;
        prism_rtl::more(prism_rtl::rc(Behind(cp, prism_rtl::val(prism_rtl::val(i)))));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutTuple>(t) ? ({
        auto&& ts = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(t).a0;
        fold_job(ts, false, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<bool, crate::lower::model::OutTy> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=]() {
            return ({
                auto f = p0;
                auto x = p1;
                (prism_rtl::finished(f || behind(cp_1_2, x)));
            });
        }));
        });
    })));
    }))->cycle();
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutArray>(t) ? ({
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutArray>(t).a0;
        prism_rtl::more(prism_rtl::rc(NamesProgramType(cp, prism_rtl::val(prism_rtl::val(i)))));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutMap>(t) ? ({
        auto&& k = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t).a0;
        auto&& v_ = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t).a1;
        ({
        auto cp_1 = cp;
        auto k_2 = prism_rtl::val(prism_rtl::val(k));
        auto v__3 = prism_rtl::val(prism_rtl::val(v_));
        call_then(start_names_program_type(cp_1, k_2), [=](bool names_program_type_5321) { return prism_rtl::finished(names_program_type_5321 || names_program_type(cp_1, v__3)); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutFn>(t) ? ({
        auto&& ps = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t).a0;
        auto&& r = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t).a1;
        ({
        auto cp_1 = cp;
        auto ps_2 = ps;
        auto r_3 = prism_rtl::val(prism_rtl::val(r));
        call_then(start_names_program_type(cp_1, r_3), [=](bool names_program_type_5398) {
        return fold_job(ps_2, names_program_type_5398, ({
            auto cp_1_4 = cp_1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<bool, crate::lower::model::OutTy> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto cp_1_4_4 = cp_1_4;
                entered(once_job([=]() {
                return ({
                    auto f = p0;
                    auto x = p1;
                    (prism_rtl::finished(f || names_program_type(cp_1_4_4, x)));
                });
            }));
            });
        })));
        }))->cycle();
    });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutDyn>(t) ? ({
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(t).a0;
        prism_rtl::more(prism_rtl::rc(NamesProgramType(cp, prism_rtl::val(prism_rtl::val(i)))));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutEvent>(t) ? ({
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutEvent>(t).a0;
        prism_rtl::more(prism_rtl::rc(NamesProgramType(cp, prism_rtl::val(prism_rtl::val(i)))));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t) ? ({
        auto&& args = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t).a1;
        fold_job(args, false, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<bool, crate::lower::model::OutTy> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=]() {
            return ({
                auto f = p0;
                auto x = p1;
                (prism_rtl::finished(f || behind(cp_1_2, x)));
            });
        }));
        });
    })));
    }))->cycle();
    })
        : prism_rtl::finished(false);
    });
}


/// `Start Behind, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_behind(crate::emit::cpp::Cp cp, crate::lower::model::OutTy t) {
    return prism_rtl::make_rc<Behind>(cp, t);
}


/// NamesProgramType: unbounded fn Cp, OutTy -> Bool
bool names_program_type(const crate::emit::cpp::Cp& cp, const crate::lower::model::OutTy& t) {
    if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t)) {
        auto&& n = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t).a0;
        auto&& args = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t).a1;
        auto own = ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            auto&& _m = crate::emit::cpp::type_of(cp, n);
            if (prism_rtl::is_some(_m)) {
                auto&& info = prism_rtl::some_of(_m);
                _v.set((prism_rtl::val(info).kind != Text::lit("node")) && (prism_rtl::val(info).kind != Text::lit("job")));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(false);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        return own || run_to_end(fold_job(args, false, ({
            auto cp_1 = cp;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<bool, crate::lower::model::OutTy> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto cp_1_2 = cp_1;
                entered(once_job([=]() {
                return ({
                    auto f = p0;
                    auto x = p1;
                    (prism_rtl::finished(f || names_program_type(cp_1_2, x)));
                });
            }));
            });
        })));
        })));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutOpt>(t)) {
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutOpt>(t).a0;
        return names_program_type(cp, prism_rtl::val(prism_rtl::val(i)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutRes>(t)) {
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutRes>(t).a0;
        return names_program_type(cp, prism_rtl::val(prism_rtl::val(i)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutRc>(t)) {
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutRc>(t).a0;
        return names_program_type(cp, prism_rtl::val(prism_rtl::val(i)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutCell>(t)) {
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutCell>(t).a0;
        return names_program_type(cp, prism_rtl::val(prism_rtl::val(i)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutArray>(t)) {
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutArray>(t).a0;
        return names_program_type(cp, prism_rtl::val(prism_rtl::val(i)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutMap>(t)) {
        auto&& k = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t).a0;
        auto&& v_ = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t).a1;
        return names_program_type(cp, prism_rtl::val(prism_rtl::val(k))) || names_program_type(cp, prism_rtl::val(prism_rtl::val(v_)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutTuple>(t)) {
        auto&& ts = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(t).a0;
        return run_to_end(fold_job(ts, false, ({
            auto cp_1 = cp;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<bool, crate::lower::model::OutTy> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto cp_1_2 = cp_1;
                entered(once_job([=]() {
                return ({
                    auto f = p0;
                    auto x = p1;
                    (prism_rtl::finished(f || names_program_type(cp_1_2, x)));
                });
            }));
            });
        })));
        })));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutFn>(t)) {
        auto&& ps = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t).a0;
        auto&& r = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t).a1;
        return run_to_end(fold_job(ps, names_program_type(cp, prism_rtl::val(prism_rtl::val(r))), ({
            auto cp_1 = cp;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<bool, crate::lower::model::OutTy> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto cp_1_2 = cp_1;
                entered(once_job([=]() {
                return ({
                    auto f = p0;
                    auto x = p1;
                    (prism_rtl::finished(f || names_program_type(cp_1_2, x)));
                });
            }));
            });
        })));
        })));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutDyn>(t)) {
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(t).a0;
        return names_program_type(cp, prism_rtl::val(prism_rtl::val(i)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutEvent>(t)) {
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutEvent>(t).a0;
        return names_program_type(cp, prism_rtl::val(prism_rtl::val(i)));
    }
    {
        return false;
    }
}


prism_rtl::Turn<bool> NamesProgramType::cycle() const {
    const auto& cp = this->cp;
    const auto& t = this->t;
    return ({
        prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t) ? ({
        auto&& n = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t).a0;
        auto&& args = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t).a1;
        ({
        auto own = ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            auto&& _m = crate::emit::cpp::type_of(cp, n);
            if (prism_rtl::is_some(_m)) {
                auto&& info = prism_rtl::some_of(_m);
                _v.set((prism_rtl::val(info).kind != Text::lit("node")) && (prism_rtl::val(info).kind != Text::lit("job")));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(false);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        (prism_rtl::finished(own || run_to_end(fold_job(args, false, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<bool, crate::lower::model::OutTy> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=]() {
            return ({
                auto f = p0;
                auto x = p1;
                (prism_rtl::finished(f || names_program_type(cp_1_2, x)));
            });
        }));
        });
    })));
    })))));
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutOpt>(t) ? ({
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutOpt>(t).a0;
        prism_rtl::more(prism_rtl::rc(NamesProgramType(cp, prism_rtl::val(prism_rtl::val(i)))));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutRes>(t) ? ({
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutRes>(t).a0;
        prism_rtl::more(prism_rtl::rc(NamesProgramType(cp, prism_rtl::val(prism_rtl::val(i)))));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutRc>(t) ? ({
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutRc>(t).a0;
        prism_rtl::more(prism_rtl::rc(NamesProgramType(cp, prism_rtl::val(prism_rtl::val(i)))));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutCell>(t) ? ({
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutCell>(t).a0;
        prism_rtl::more(prism_rtl::rc(NamesProgramType(cp, prism_rtl::val(prism_rtl::val(i)))));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutArray>(t) ? ({
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutArray>(t).a0;
        prism_rtl::more(prism_rtl::rc(NamesProgramType(cp, prism_rtl::val(prism_rtl::val(i)))));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutMap>(t) ? ({
        auto&& k = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t).a0;
        auto&& v_ = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t).a1;
        ({
        auto cp_1 = cp;
        auto k_2 = prism_rtl::val(prism_rtl::val(k));
        auto v__3 = prism_rtl::val(prism_rtl::val(v_));
        call_then(start_names_program_type(cp_1, k_2), [=](bool names_program_type_6201) { return prism_rtl::finished(names_program_type_6201 || names_program_type(cp_1, v__3)); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutTuple>(t) ? ({
        auto&& ts = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(t).a0;
        fold_job(ts, false, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<bool, crate::lower::model::OutTy> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=]() {
            return ({
                auto f = p0;
                auto x = p1;
                (prism_rtl::finished(f || names_program_type(cp_1_2, x)));
            });
        }));
        });
    })));
    }))->cycle();
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutFn>(t) ? ({
        auto&& ps = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t).a0;
        auto&& r = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t).a1;
        ({
        auto cp_1 = cp;
        auto ps_2 = ps;
        auto r_3 = prism_rtl::val(prism_rtl::val(r));
        call_then(start_names_program_type(cp_1, r_3), [=](bool names_program_type_6347) {
        return fold_job(ps_2, names_program_type_6347, ({
            auto cp_1_4 = cp_1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<bool, crate::lower::model::OutTy> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto cp_1_4_4 = cp_1_4;
                entered(once_job([=]() {
                return ({
                    auto f = p0;
                    auto x = p1;
                    (prism_rtl::finished(f || names_program_type(cp_1_4_4, x)));
                });
            }));
            });
        })));
        }))->cycle();
    });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutDyn>(t) ? ({
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(t).a0;
        prism_rtl::more(prism_rtl::rc(NamesProgramType(cp, prism_rtl::val(prism_rtl::val(i)))));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutEvent>(t) ? ({
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutEvent>(t).a0;
        prism_rtl::more(prism_rtl::rc(NamesProgramType(cp, prism_rtl::val(prism_rtl::val(i)))));
    })
        : prism_rtl::finished(false);
    });
}


/// `Start NamesProgramType, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_names_program_type(crate::emit::cpp::Cp cp, crate::lower::model::OutTy t) {
    return prism_rtl::make_rc<NamesProgramType>(cp, t);
}


/// let noParts
Parts no_parts() {
    return Parts{.forward = Array<Text>{}, .values = Array<ValueDecl>{}, .protos = Array<Text>{}, .classes = Array<Text>{}, .outer = Array<Text>{}, .generic = Array<Text>{}, .defs = Array<Text>{}};
}


/// JoinParts: fn Parts, Parts -> Parts
Parts join_parts(const Parts& a, const Parts& b) {
    return Parts{.forward = append(a.forward, b.forward), .values = append(a.values, b.values), .protos = append(a.protos, b.protos), .classes = append(a.classes, b.classes), .outer = append(a.outer, b.outer), .generic = append(a.generic, b.generic), .defs = append(a.defs, b.defs)};
}


/// ItemParts: unbounded fn Cp, Item -> Parts
Parts item_parts(const crate::emit::cpp::Cp& cp, const crate::lower::model::Item& it) {
    if (prism_rtl::is<crate::lower::model::Item::ItType>(it)) {
        auto&& t = prism_rtl::as<crate::lower::model::Item::ItType>(it).a0;
        return type_parts(cp, t);
    }
    if (prism_rtl::is<crate::lower::model::Item::ItTag>(it)) {
        auto&& t = prism_rtl::as<crate::lower::model::Item::ItTag>(it).a0;
        return tag_parts(cp, t);
    }
    if (prism_rtl::is<crate::lower::model::Item::ItRow>(it)) {
        auto&& r = prism_rtl::as<crate::lower::model::Item::ItRow>(it).a0;
        return row_parts(cp, cp.home, r);
    }
    if (prism_rtl::is<crate::lower::model::Item::ItFn>(it)) {
        auto&& f = prism_rtl::as<crate::lower::model::Item::ItFn>(it).a0;
        return fn_parts(cp, f);
    }
    if (prism_rtl::is<crate::lower::model::Item::ItJob>(it)) {
        auto&& j = prism_rtl::as<crate::lower::model::Item::ItJob>(it).a0;
        return job_parts(cp, j);
    }
    if (prism_rtl::is<crate::lower::model::Item::ItNode>(it)) {
        auto&& n = prism_rtl::as<crate::lower::model::Item::ItNode>(it).a0;
        return crate::emit::cpp::program::node_parts(cp, n);
    }
    if (prism_rtl::is<crate::lower::model::Item::ItTrait>(it)) {
        auto&& t = prism_rtl::as<crate::lower::model::Item::ItTrait>(it).a0;
        return trait_parts(cp, t);
    }
    if (prism_rtl::is<crate::lower::model::Item::ItImpl>(it)) {
        auto&& i = prism_rtl::as<crate::lower::model::Item::ItImpl>(it).a0;
        return impl_parts(cp, i);
    }
    if (prism_rtl::is<crate::lower::model::Item::ItNote>(it)) {
        auto&& t = prism_rtl::as<crate::lower::model::Item::ItNote>(it).a0;
        return protos_defs(Array<Text>{}, Array(std::vector{prism_rtl::cat("// ", t)}));
    }
    if (prism_rtl::is<crate::lower::model::Item::ItRefused>(it)) {
        auto&& t = prism_rtl::as<crate::lower::model::Item::ItRefused>(it).a0;
        return protos_defs(Array<Text>{}, Array(std::vector{prism_rtl::cat("compile_error!(\"", crate::lower::expr::lowering_refusal(), crate::lower::expr::escape(t), "\");")}));
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Parts> ItemParts::cycle() const {
    const auto& cp = this->cp;
    const auto& it = this->it;
    return ({
        prism_rtl::is<crate::lower::model::Item::ItType>(it) ? ({
        auto&& t = prism_rtl::as<crate::lower::model::Item::ItType>(it).a0;
        prism_rtl::more(prism_rtl::rc(TypeParts(cp, t)));
    })
        : prism_rtl::is<crate::lower::model::Item::ItTag>(it) ? ({
        auto&& t = prism_rtl::as<crate::lower::model::Item::ItTag>(it).a0;
        prism_rtl::more(prism_rtl::rc(TagParts(cp, t)));
    })
        : prism_rtl::is<crate::lower::model::Item::ItRow>(it) ? ({
        auto&& r = prism_rtl::as<crate::lower::model::Item::ItRow>(it).a0;
        prism_rtl::more(prism_rtl::rc(RowParts(cp, prism_rtl::val(cp).home, r)));
    })
        : prism_rtl::is<crate::lower::model::Item::ItFn>(it) ? ({
        auto&& f = prism_rtl::as<crate::lower::model::Item::ItFn>(it).a0;
        prism_rtl::more(prism_rtl::rc(FnParts(cp, f)));
    })
        : prism_rtl::is<crate::lower::model::Item::ItJob>(it) ? ({
        auto&& j = prism_rtl::as<crate::lower::model::Item::ItJob>(it).a0;
        prism_rtl::more(prism_rtl::rc(JobParts(cp, j)));
    })
        : prism_rtl::is<crate::lower::model::Item::ItNode>(it) ? ({
        auto&& n = prism_rtl::as<crate::lower::model::Item::ItNode>(it).a0;
        prism_rtl::more(prism_rtl::rc(crate::emit::cpp::program::NodeParts(cp, n)));
    })
        : prism_rtl::is<crate::lower::model::Item::ItTrait>(it) ? ({
        auto&& t = prism_rtl::as<crate::lower::model::Item::ItTrait>(it).a0;
        prism_rtl::more(prism_rtl::rc(TraitParts(cp, t)));
    })
        : prism_rtl::is<crate::lower::model::Item::ItImpl>(it) ? ({
        auto&& i = prism_rtl::as<crate::lower::model::Item::ItImpl>(it).a0;
        prism_rtl::more(prism_rtl::rc(ImplParts(cp, i)));
    })
        : prism_rtl::is<crate::lower::model::Item::ItNote>(it) ? ({
        auto&& t = prism_rtl::as<crate::lower::model::Item::ItNote>(it).a0;
        prism_rtl::finished(protos_defs(Array<Text>{}, Array(std::vector{prism_rtl::cat("// ", t)})));
    })
        : prism_rtl::is<crate::lower::model::Item::ItRefused>(it) ? ({
        auto&& t = prism_rtl::as<crate::lower::model::Item::ItRefused>(it).a0;
        prism_rtl::finished(protos_defs(Array<Text>{}, Array(std::vector{prism_rtl::cat("compile_error!(\"", crate::lower::expr::lowering_refusal(), crate::lower::expr::escape(t), "\");")})));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ItemParts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Parts> start_item_parts(crate::emit::cpp::Cp cp, crate::lower::model::Item it) {
    return prism_rtl::make_rc<ItemParts>(cp, it);
}


/// FnParts: unbounded fn Cp, FnDef -> Parts
Parts fn_parts(const crate::emit::cpp::Cp& cp, const crate::lower::model::FnDef& f) {
    return len(f.generics) > Nat(0u)
        ? ({
        Parts this_ = generic_only(Array(std::vector{fn_definition(cp, f)}));
        this_.protos = Array(std::vector{prism_rtl::cat(fn_signature(cp, f), ";")});
        this_;
    })
        : protos_defs(Array(std::vector{prism_rtl::cat(fn_signature(cp, f), ";")}), Array(std::vector{fn_definition(cp, f)}));
}


prism_rtl::Turn<Parts> FnParts::cycle() const {
    const auto& cp = this->cp;
    const auto& f = this->f;
    return len(prism_rtl::val(f).generics) > Nat(0u)
        ? prism_rtl::finished(({
        Parts this_ = generic_only(Array(std::vector{fn_definition(cp, f)}));
        this_.protos = Array(std::vector{prism_rtl::cat(fn_signature(cp, f), ";")});
        this_;
    }))
        : ({
        auto cp_1 = cp;
        auto f_2 = f;
        call_then(start_fn_signature(cp_1, f_2), [=](Text fn_signature_7590) { return call_then(start_fn_definition(cp_1, f_2), [=](Text fn_definition_7617) { return prism_rtl::finished(protos_defs(Array(std::vector{prism_rtl::cat(fn_signature_7590, ";")}), Array(std::vector{fn_definition_7617}))); }); });
    });
}


/// `Start FnParts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Parts> start_fn_parts(crate::emit::cpp::Cp cp, crate::lower::model::FnDef f) {
    return prism_rtl::make_rc<FnParts>(cp, f);
}


/// CppDoc: fn Text -> Text
Text cpp_doc(const Text& text_) {
    return text_ == Text::lit("")
        ? Text::lit("")
        : concat(each(split_on(text_, Text::lit("\n")), [&](const Text& l) { return l == Text::lit("") ? Text::lit("///\n") : prism_rtl::cat("/// ", l, "\n"); }));
}


/// CppSourceDoc: fn Text, Text -> Text
Text cpp_source_doc(const Text& lead, const Text& source) {
    auto quoted = concat(each(split_on(source, Text::lit("\n")), [&](const Text& l) { return l == Text::lit("") ? Text::lit("///\n") : prism_rtl::cat("/// ", l, "\n"); }));
    return source == Text::lit("")
        ? cpp_doc(lead)
        : lead == Text::lit("")
        ? prism_rtl::cat("/// ```prism\n", quoted, "/// ```\n")
        : prism_rtl::cat("/// ", lead, "\n///\n/// ```prism\n", quoted, "/// ```\n");
}


/// TypeParts: unbounded fn Cp, TyDef -> Parts
Parts type_parts(const crate::emit::cpp::Cp& cp, const crate::lower::model::TyDef& t) {
    auto eq = t.eq;
    auto ord = t.ord && (!t.floaty);
    auto gens = cpp_template_head(t.params);
    auto head = head_of(t.name, t.params);
    auto doc = cpp_source_doc(prism_rtl::cat("`", t.prism, "`:"), t.doc);
    auto members_ = members(t.show_ != crate::lower::model::Shown(crate::lower::model::Shown::NotShown{}), t.pod, head);
    auto generic = len(t.params) > Nat(0u);
    auto fwd = prism_rtl::cat(gens, t.shape == crate::lower::model::TyShape(crate::lower::model::TyShape::ShapeChoice{})
        ? Text::lit("class")
        : Text::lit("struct"), " ", t.name, ";");
    auto deps = crate::emit::cpp::patterns::concat2(run_to_end(each_job(t.cases_, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(crate::lower::model::CaseDef)>>(prism_rtl::rc([=](crate::lower::model::CaseDef p0) {
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=]() {
            return ({
                auto c = p0;
                call_value(each_job(prism_rtl::val(c).fields, ({
                auto cp_1_2_2 = cp_1_2;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
                return ({
                    auto cp_1_2_2_2 = cp_1_2_2;
                    entered(once_job([=]() {
                    return ({
                        auto&& _ft = p0;
                        auto&& ft = std::get<1>(_ft);
                        (prism_rtl::more(prism_rtl::rc(ValueDeps(cp_1_2_2_2, ft))));
                    });
                }));
                });
            })));
            })), [=](Array<Array<Text>> each_8988) { return prism_rtl::finished(crate::emit::cpp::patterns::concat2(each_8988)); });
            });
        }));
        });
    })));
    }))));
    auto [text_, cmp_defs] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Text, Array<Text>>> _v;
        auto&& _m = t.shape;
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeChoice>(_m)) {
            _v.set(({
                auto names = each(t.cases_, [&](const crate::lower::model::CaseDef& c) { return prism_rtl::val(c).name; });
                auto cases = crate::syntax::lexer::chars::join(run_to_end(each_job(t.cases_, ({
                    auto cp_1 = cp;
                    auto eq_2 = eq;
                    auto ord_3 = ord;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::CaseDef)>>(prism_rtl::rc([=](crate::lower::model::CaseDef p0) {
                    return ({
                        auto cp_1_4 = cp_1;
                        auto eq_2_4 = eq_2;
                        auto ord_3_4 = ord_3;
                        entered(once_job([=]() {
                        return ({
                            auto c = p0;
                            (prism_rtl::more(prism_rtl::rc(CaseStruct(cp_1_4, c, eq_2_4, ord_3_4))));
                        });
                    }));
                    });
                })));
                }))), Text::lit("\n"));
                auto cls = crate::emit::cpp::templates::items::choice_class(doc, gens, t.name, cases, crate::syntax::lexer::chars::join(names, Text::lit(", ")), members_);
                auto cmp = crate::syntax::lexer::chars::join(filter(Array(std::vector{eq
                    ? prism_rtl::cat(gens, "inline bool operator==(const ", head, "& a, const ", head, "& b) { return a.cases() == b.cases(); }")
                    : Text::lit(""), ord
                    ? prism_rtl::cat(gens, "inline std::strong_ordering operator<=>(const ", head, "& a, const ", head, "& b) { return prism_rtl::as_strong(a.cases() <=> b.cases()); }")
                    : Text::lit("")}), [&](const Text& s) { return s != Text::lit(""); }), Text::lit("\n"));
                auto case_defs = filter(run_to_end(each_job(t.cases_, ({
                    auto cp_1 = cp;
                    auto gens_2 = gens;
                    auto head_3 = head;
                    auto eq_4 = eq;
                    auto ord_5 = ord;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::CaseDef)>>(prism_rtl::rc([=](crate::lower::model::CaseDef p0) {
                    return ({
                        auto cp_1_6 = cp_1;
                        auto gens_2_6 = gens_2;
                        auto head_3_6 = head_3;
                        auto eq_4_6 = eq_4;
                        auto ord_5_6 = ord_5;
                        entered(once_job([=]() {
                        return ({
                            auto c = p0;
                            (prism_rtl::more(prism_rtl::rc(CaseCmpDefs(cp_1_6, gens_2_6, head_3_6, c, eq_4_6, ord_5_6))));
                        });
                    }));
                    });
                })));
                }))), [&](const Text& s) { return s != Text::lit(""); });
                std::tuple{crate::syntax::lexer::chars::join(filter(Array(std::vector{cls, cmp}), [&](const Text& s) { return s != Text::lit(""); }), Text::lit("\n")), case_defs};
            }));
            goto _done;
        }
        {
            _v.set(({
                auto first_ = or_(index(t.cases_, Nat(0u)), crate::lower::model::CaseDef{.name = Text::lit(""), .prism = Text::lit(""), .fields = Array<std::tuple<Text, crate::lower::model::OutTy>>{}});
                auto fields = ({
                    __label__ _done;
                    prism_rtl::Slot<Text> _v;
                    auto&& _m = t.shape;
                    if (prism_rtl::is<crate::lower::model::TyShape::ShapeRecord>(_m)) {
                        _v.set(crate::syntax::lexer::chars::join(run_to_end(each_job(prism_rtl::val(first_).fields, ({
                            auto cp_1 = cp;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
                            return ({
                                auto cp_1_2 = cp_1;
                                entered(once_job([=]() {
                                return ({
                                    auto [f, ft] = p0;
                                    call_then(crate::emit::cpp::start_cpp_type(cp_1_2, ft), [=](Text cpp_type_10220) { return prism_rtl::finished(prism_rtl::cat(cpp_type_10220, " ", crate::emit::cpp::field_id(f), ";")); });
                                });
                            }));
                            });
                        })));
                        }))), Text::lit("\n")));
                        goto _done;
                    }
                    if (prism_rtl::is<crate::lower::model::TyShape::ShapeNewtype>(_m)) {
                        _v.set(positional_fields(cp, prism_rtl::val(first_).fields));
                        goto _done;
                    }
                    {
                        _v.set(Text::lit(""));
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                auto names = ({
                    __label__ _done;
                    prism_rtl::Slot<Array<Text>> _v;
                    auto&& _m = t.shape;
                    if (prism_rtl::is<crate::lower::model::TyShape::ShapeRecord>(_m)) {
                        _v.set(each(prism_rtl::val(first_).fields, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
                            auto&& f = std::get<0>(_p0);
                            return crate::emit::cpp::field_id(f);
                        }));
                        goto _done;
                    }
                    if (prism_rtl::is<crate::lower::model::TyShape::ShapeNewtype>(_m)) {
                        _v.set(each(crate::check::errors::range0(len(prism_rtl::val(first_).fields)), [&](const Nat& i) { return prism_rtl::cat("a", i); }));
                        goto _done;
                    }
                    {
                        _v.set(Array<Text>{});
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                auto behind_ = run_to_end(fold_job(prism_rtl::val(first_).fields, false, ({
                    auto cp_1 = cp;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, crate::lower::model::OutTy>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<Text, crate::lower::model::OutTy>> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto cp_1_2 = cp_1;
                        entered(once_job([=]() {
                        return ({
                            auto f = p0;
                            auto&& _ft = p1;
                            auto&& ft = std::get<1>(_ft);
                            (prism_rtl::finished(f || behind(cp_1_2, ft)));
                        });
                    }));
                    });
                })));
                })));
                auto [cmps, cmp_defs] = comparisons(gens, head, t.name, names, eq, ord, behind_);
                auto decl = crate::emit::cpp::templates::items::value_struct(doc, gens, t.name, fields, crate::syntax::lexer::chars::join(filter(Array(std::vector{cmps, members_}), [&](const Text& s) { return s != Text::lit(""); }), Text::lit("\n")));
                std::tuple{decl, cmp_defs == Text::lit("") ? Array<Text>{} : Array(std::vector{cmp_defs})};
            }));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto defs = append(cmp_defs, Array(std::vector{type_defs(cp, t, head)}));
    return Parts{.forward = Array(std::vector{fwd}), .values = Array(std::vector{ValueDecl{.path_ = decl_path(cp, t.name), .deps = deps, .text = text_}}), .protos = Array<Text>{}, .classes = Array<Text>{}, .outer = Array<Text>{}, .generic = generic ? defs : Array<Text>{}, .defs = generic ? Array<Text>{} : defs};
}


prism_rtl::Turn<Parts> TypeParts::cycle() const {
    const auto& cp = this->cp;
    const auto& t = this->t;
    auto eq = prism_rtl::val(t).eq;
    auto ord = prism_rtl::val(t).ord && (!prism_rtl::val(t).floaty);
    auto gens = cpp_template_head(prism_rtl::val(t).params);
    auto head = head_of(prism_rtl::val(t).name, prism_rtl::val(t).params);
    auto doc = cpp_source_doc(prism_rtl::cat("`", prism_rtl::val(t).prism, "`:"), prism_rtl::val(t).doc);
    auto members_ = members(prism_rtl::val(t).show_ != crate::lower::model::Shown(crate::lower::model::Shown::NotShown{}), prism_rtl::val(t).pod, head);
    auto generic = len(prism_rtl::val(t).params) > Nat(0u);
    auto fwd = prism_rtl::cat(gens, prism_rtl::val(t).shape == crate::lower::model::TyShape(crate::lower::model::TyShape::ShapeChoice{})
        ? Text::lit("class")
        : Text::lit("struct"), " ", prism_rtl::val(t).name, ";");
    auto cp_1 = cp;
    auto t_2 = t;
    return call_value(each_job(prism_rtl::val(t_2).cases_, ({
        auto cp_1_3 = cp_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(crate::lower::model::CaseDef)>>(prism_rtl::rc([=](crate::lower::model::CaseDef p0) {
        return ({
            auto cp_1_3_3 = cp_1_3;
            entered(once_job([=]() {
            return ({
                auto c = p0;
                call_value(each_job(prism_rtl::val(c).fields, ({
                auto cp_1_3_3_3 = cp_1_3_3;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
                return ({
                    auto cp_1_3_3_3_3 = cp_1_3_3_3;
                    entered(once_job([=]() {
                    return ({
                        auto&& _ft = p0;
                        auto&& ft = std::get<1>(_ft);
                        (prism_rtl::more(prism_rtl::rc(ValueDeps(cp_1_3_3_3_3, ft))));
                    });
                }));
                });
            })));
            })), [=](Array<Array<Text>> each_8988) { return prism_rtl::finished(crate::emit::cpp::patterns::concat2(each_8988)); });
            });
        }));
        });
    })));
    })), [=](Array<Array<Text>> each_8960) {
        return ({
            auto deps = crate::emit::cpp::patterns::concat2(each_8960);
            auto [text_, cmp_defs] = ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<Text, Array<Text>>> _v;
                auto&& _m = prism_rtl::val(t_2).shape;
                if (prism_rtl::is<crate::lower::model::TyShape::ShapeChoice>(_m)) {
                    _v.set(({
                        auto names = each(prism_rtl::val(t_2).cases_, [&](const crate::lower::model::CaseDef& c) { return prism_rtl::val(c).name; });
                        auto cases = crate::syntax::lexer::chars::join(run_to_end(each_job(prism_rtl::val(t_2).cases_, ({
                            auto cp_1_3 = cp_1;
                            auto eq_3 = eq;
                            auto ord_4 = ord;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::CaseDef)>>(prism_rtl::rc([=](crate::lower::model::CaseDef p0) {
                            return ({
                                auto cp_1_3_5 = cp_1_3;
                                auto eq_3_5 = eq_3;
                                auto ord_4_5 = ord_4;
                                entered(once_job([=]() {
                                return ({
                                    auto c = p0;
                                    (prism_rtl::more(prism_rtl::rc(CaseStruct(cp_1_3_5, c, eq_3_5, ord_4_5))));
                                });
                            }));
                            });
                        })));
                        }))), Text::lit("\n"));
                        auto cls = crate::emit::cpp::templates::items::choice_class(doc, gens, prism_rtl::val(t_2).name, cases, crate::syntax::lexer::chars::join(names, Text::lit(", ")), members_);
                        auto cmp = crate::syntax::lexer::chars::join(filter(Array(std::vector{eq
                            ? prism_rtl::cat(gens, "inline bool operator==(const ", head, "& a, const ", head, "& b) { return a.cases() == b.cases(); }")
                            : Text::lit(""), ord
                            ? prism_rtl::cat(gens, "inline std::strong_ordering operator<=>(const ", head, "& a, const ", head, "& b) { return prism_rtl::as_strong(a.cases() <=> b.cases()); }")
                            : Text::lit("")}), [&](const Text& s) { return s != Text::lit(""); }), Text::lit("\n"));
                        auto case_defs = filter(run_to_end(each_job(prism_rtl::val(t_2).cases_, ({
                            auto cp_1_3 = cp_1;
                            auto gens_3 = gens;
                            auto head_4 = head;
                            auto eq_5 = eq;
                            auto ord_6 = ord;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::CaseDef)>>(prism_rtl::rc([=](crate::lower::model::CaseDef p0) {
                            return ({
                                auto cp_1_3_7 = cp_1_3;
                                auto gens_3_7 = gens_3;
                                auto head_4_7 = head_4;
                                auto eq_5_7 = eq_5;
                                auto ord_6_7 = ord_6;
                                entered(once_job([=]() {
                                return ({
                                    auto c = p0;
                                    (prism_rtl::more(prism_rtl::rc(CaseCmpDefs(cp_1_3_7, gens_3_7, head_4_7, c, eq_5_7, ord_6_7))));
                                });
                            }));
                            });
                        })));
                        }))), [&](const Text& s) { return s != Text::lit(""); });
                        std::tuple{crate::syntax::lexer::chars::join(filter(Array(std::vector{cls, cmp}), [&](const Text& s) { return s != Text::lit(""); }), Text::lit("\n")), case_defs};
                    }));
                    goto _done;
                }
                {
                    _v.set(({
                        auto first_ = or_(index(prism_rtl::val(t_2).cases_, Nat(0u)), crate::lower::model::CaseDef{.name = Text::lit(""), .prism = Text::lit(""), .fields = Array<std::tuple<Text, crate::lower::model::OutTy>>{}});
                        auto fields = ({
                            __label__ _done;
                            prism_rtl::Slot<Text> _v;
                            auto&& _m = prism_rtl::val(t_2).shape;
                            if (prism_rtl::is<crate::lower::model::TyShape::ShapeRecord>(_m)) {
                                _v.set(crate::syntax::lexer::chars::join(run_to_end(each_job(prism_rtl::val(first_).fields, ({
                                    auto cp_1_3 = cp_1;
                                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
                                    return ({
                                        auto cp_1_3_3 = cp_1_3;
                                        entered(once_job([=]() {
                                        return ({
                                            auto [f, ft] = p0;
                                            call_then(crate::emit::cpp::start_cpp_type(cp_1_3_3, ft), [=](Text cpp_type_10220) { return prism_rtl::finished(prism_rtl::cat(cpp_type_10220, " ", crate::emit::cpp::field_id(f), ";")); });
                                        });
                                    }));
                                    });
                                })));
                                }))), Text::lit("\n")));
                                goto _done;
                            }
                            if (prism_rtl::is<crate::lower::model::TyShape::ShapeNewtype>(_m)) {
                                _v.set(positional_fields(cp_1, prism_rtl::val(first_).fields));
                                goto _done;
                            }
                            {
                                _v.set(Text::lit(""));
                                goto _done;
                            }
                        _done:
                            _v.take();
                        });
                        auto names = ({
                            __label__ _done;
                            prism_rtl::Slot<Array<Text>> _v;
                            auto&& _m = prism_rtl::val(t_2).shape;
                            if (prism_rtl::is<crate::lower::model::TyShape::ShapeRecord>(_m)) {
                                _v.set(each(prism_rtl::val(first_).fields, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
                                    auto&& f = std::get<0>(_p0);
                                    return crate::emit::cpp::field_id(f);
                                }));
                                goto _done;
                            }
                            if (prism_rtl::is<crate::lower::model::TyShape::ShapeNewtype>(_m)) {
                                _v.set(each(crate::check::errors::range0(len(prism_rtl::val(first_).fields)), [&](const Nat& i) { return prism_rtl::cat("a", i); }));
                                goto _done;
                            }
                            {
                                _v.set(Array<Text>{});
                                goto _done;
                            }
                        _done:
                            _v.take();
                        });
                        auto behind_ = run_to_end(fold_job(prism_rtl::val(first_).fields, false, ({
                            auto cp_1_3 = cp_1;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, crate::lower::model::OutTy>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<Text, crate::lower::model::OutTy>> _p0) {
                            auto&& p0 = std::get<0>(_p0);
                            auto&& p1 = std::get<1>(_p0);
                            return ({
                                auto cp_1_3_3 = cp_1_3;
                                entered(once_job([=]() {
                                return ({
                                    auto f = p0;
                                    auto&& _ft = p1;
                                    auto&& ft = std::get<1>(_ft);
                                    (prism_rtl::finished(f || behind(cp_1_3_3, ft)));
                                });
                            }));
                            });
                        })));
                        })));
                        auto [cmps, cmp_defs] = comparisons(gens, head, prism_rtl::val(t_2).name, names, eq, ord, behind_);
                        auto decl = crate::emit::cpp::templates::items::value_struct(doc, gens, prism_rtl::val(t_2).name, fields, crate::syntax::lexer::chars::join(filter(Array(std::vector{cmps, members_}), [&](const Text& s) { return s != Text::lit(""); }), Text::lit("\n")));
                        std::tuple{decl, cmp_defs == Text::lit("") ? Array<Text>{} : Array(std::vector{cmp_defs})};
                    }));
                    goto _done;
                }
            _done:
                _v.take();
            });
            call_then(start_type_defs(cp_1, t_2, head), [=](Text type_defs_10970) {
            return ({
                auto defs = append(cmp_defs, Array(std::vector{type_defs_10970}));
                (prism_rtl::finished(Parts{.forward = Array(std::vector{fwd}), .values = Array(std::vector{ValueDecl{.path_ = decl_path(cp_1, prism_rtl::val(t_2).name), .deps = deps, .text = text_}}), .protos = Array<Text>{}, .classes = Array<Text>{}, .outer = Array<Text>{}, .generic = generic ? defs : Array<Text>{}, .defs = generic ? Array<Text>{} : defs}));
            });
        });
        });
    });
}


/// `Start TypeParts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Parts> start_type_parts(crate::emit::cpp::Cp cp, crate::lower::model::TyDef t) {
    return prism_rtl::make_rc<TypeParts>(cp, t);
}


/// DeclPath: fn Cp, Text -> Text
Text decl_path(const crate::emit::cpp::Cp& cp, const Text& name) {
    return cp.home == Text::lit("") ? name : prism_rtl::cat(cp.home, "::", name);
}


/// Comparisons: fn Text, Text, Text, [Text], Bool, Bool, Bool -> ((Text, Text))
std::tuple<Text, Text> comparisons(const Text& gens, const Text& owner, const Text& self_, const Array<Text>& names, const bool& eq, const bool& ord, const bool& behind_) {
    return !prism_rtl::val(behind_)
        ? std::tuple{crate::syntax::lexer::chars::join(filter(Array(std::vector{prism_rtl::val(eq)
        ? prism_rtl::cat("bool operator==(const ", self_, "&) const = default;")
        : Text::lit(""), prism_rtl::val(ord)
        ? prism_rtl::cat("auto operator<=>(const ", self_, "&) const = default;")
        : Text::lit("")}), [&](const Text& s) { return s != Text::lit(""); }), Text::lit("\n")), Text::lit("")}
        : ({
        auto decls = crate::syntax::lexer::chars::join(filter(Array(std::vector{prism_rtl::val(eq)
            ? prism_rtl::cat("bool operator==(const ", self_, "&) const;")
            : Text::lit(""), prism_rtl::val(ord)
            ? prism_rtl::cat("std::strong_ordering operator<=>(const ", self_, "&) const;")
            : Text::lit("")}), [&](const Text& s) { return s != Text::lit(""); }), Text::lit("\n"));
        auto eq_body = len(names) == Nat(0u)
            ? Text::lit("true")
            : crate::syntax::lexer::chars::join(each(names, [&](const Text& n) { return prism_rtl::cat(n, " == o.", n); }), Text::lit(" && "));
        auto ord_body = len(names) == Nat(0u)
            ? Text::lit("std::strong_ordering::equal")
            : prism_rtl::cat("prism_rtl::as_strong(std::tie(", crate::syntax::lexer::chars::join(names, Text::lit(", ")), ") <=> std::tie(", crate::syntax::lexer::chars::join(each(names, [&](const Text& n) { return prism_rtl::cat("o.", n); }), Text::lit(", ")), "))");
        auto defs = crate::syntax::lexer::chars::join(filter(Array(std::vector{prism_rtl::val(eq)
            ? prism_rtl::cat(gens, "bool ", owner, "::operator==(const ", self_, "& o) const { return ", eq_body, "; }")
            : Text::lit(""), prism_rtl::val(ord)
            ? prism_rtl::cat(gens, "std::strong_ordering ", owner, "::operator<=>(const ", self_, "& o) const { return ", ord_body, "; }")
            : Text::lit("")}), [&](const Text& s) { return s != Text::lit(""); }), Text::lit("\n"));
        std::tuple{decls, defs};
    });
}


/// Members: fn Bool, Bool, Text -> Text
Text members(const bool& shown, const bool& pod, const Text& head) {
    auto s = prism_rtl::val(shown)
        ? Array(std::vector{Text::lit("void show(Printer& p) const;")})
        : Array<Text>{};
    auto d = prism_rtl::val(pod)
        ? Array(std::vector{Text::lit("Pod to_pod() const;"), prism_rtl::cat("static Result<", head, "> from_pod(const Pod& whole);")})
        : Array<Text>{};
    return crate::syntax::lexer::chars::join(append(s, d), Text::lit("\n"));
}


/// CaseStruct: unbounded fn Cp, CaseDef, Bool, Bool -> Text
Text case_struct(const crate::emit::cpp::Cp& cp, const crate::lower::model::CaseDef& c, const bool& eq, const bool& ord) {
    auto fields = positional_fields(cp, c.fields);
    auto&& _cmps = comparisons(Text::lit(""), Text::lit(""), c.name, case_names(c), eq, ord, case_behind(cp, c));
    auto&& cmps = std::get<0>(_cmps);
    return crate::emit::cpp::templates::items::case_decl(c.name, crate::syntax::lexer::chars::join(filter(Array(std::vector{fields, cmps}), [&](const Text& s) { return s != Text::lit(""); }), Text::lit("\n")));
}


prism_rtl::Turn<Text> CaseStruct::cycle() const {
    const auto& cp = this->cp;
    const auto& c = this->c;
    const auto& eq = this->eq;
    const auto& ord = this->ord;
    auto c_1 = c;
    auto cp_2 = cp;
    auto eq_3 = prism_rtl::val(eq);
    auto ord_4 = prism_rtl::val(ord);
    return call_then(start_positional_fields(cp_2, prism_rtl::val(c_1).fields), [=](Text positional_fields_13273) {
        return ({
            auto fields = positional_fields_13273;
            call_then(start_case_behind(cp_2, c_1), [=](bool case_behind_13383) {
            return ({
                auto&& _cmps = comparisons(Text::lit(""), Text::lit(""), prism_rtl::val(c_1).name, case_names(c_1), eq_3, ord_4, case_behind_13383);
                auto&& cmps = std::get<0>(_cmps);
                (prism_rtl::finished(crate::emit::cpp::templates::items::case_decl(prism_rtl::val(c_1).name, crate::syntax::lexer::chars::join(filter(Array(std::vector{fields, cmps}), [&](const Text& s) { return s != Text::lit(""); }), Text::lit("\n")))));
            });
        });
        });
    });
}


/// `Start CaseStruct, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_case_struct(crate::emit::cpp::Cp cp, crate::lower::model::CaseDef c, bool eq, bool ord) {
    return prism_rtl::make_rc<CaseStruct>(cp, c, eq, ord);
}


/// CaseCmpDefs: unbounded fn Cp, Text, Text, CaseDef, Bool, Bool -> Text
Text case_cmp_defs(const crate::emit::cpp::Cp& cp, const Text& gens, const Text& head, const crate::lower::model::CaseDef& c, const bool& eq, const bool& ord) {
    auto&& _defs = comparisons(gens, prism_rtl::cat(head, "::", c.name), c.name, case_names(c), eq, ord, case_behind(cp, c));
    auto&& defs = std::get<1>(_defs);
    return defs;
}


prism_rtl::Turn<Text> CaseCmpDefs::cycle() const {
    const auto& cp = this->cp;
    const auto& gens = this->gens;
    const auto& head = this->head;
    const auto& c = this->c;
    const auto& eq = this->eq;
    const auto& ord = this->ord;
    auto c_1 = c;
    auto cp_2 = cp;
    auto eq_3 = prism_rtl::val(eq);
    auto gens_4 = gens;
    auto head_5 = head;
    auto ord_6 = prism_rtl::val(ord);
    return call_then(start_case_behind(cp_2, c_1), [=](bool case_behind_13776) {
        return ({
            auto&& _defs = comparisons(gens_4, prism_rtl::cat(head_5, "::", prism_rtl::val(c_1).name), prism_rtl::val(c_1).name, case_names(c_1), eq_3, ord_6, case_behind_13776);
            auto&& defs = std::get<1>(_defs);
            (prism_rtl::finished(defs));
        });
    });
}


/// `Start CaseCmpDefs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_case_cmp_defs(crate::emit::cpp::Cp cp, Text gens, Text head, crate::lower::model::CaseDef c, bool eq, bool ord) {
    return prism_rtl::make_rc<CaseCmpDefs>(cp, gens, head, c, eq, ord);
}


/// CaseNames: fn CaseDef -> [Text]
Array<Text> case_names(const crate::lower::model::CaseDef& c) {
    return each(crate::check::errors::range0(len(c.fields)), [&](const Nat& i) { return prism_rtl::cat("a", i); });
}


/// CaseBehind: unbounded fn Cp, CaseDef -> Bool
bool case_behind(const crate::emit::cpp::Cp& cp, const crate::lower::model::CaseDef& c) {
    return run_to_end(fold_job(c.fields, false, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, crate::lower::model::OutTy>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<Text, crate::lower::model::OutTy>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=]() {
            return ({
                auto f = p0;
                auto&& _ft = p1;
                auto&& ft = std::get<1>(_ft);
                (prism_rtl::finished(f || behind(cp_1_2, ft)));
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<bool> CaseBehind::cycle() const {
    const auto& cp = this->cp;
    const auto& c = this->c;
    return fold_job(prism_rtl::val(c).fields, false, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, crate::lower::model::OutTy>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<Text, crate::lower::model::OutTy>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=]() {
            return ({
                auto f = p0;
                auto&& _ft = p1;
                auto&& ft = std::get<1>(_ft);
                (prism_rtl::finished(f || behind(cp_1_2, ft)));
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start CaseBehind, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_case_behind(crate::emit::cpp::Cp cp, crate::lower::model::CaseDef c) {
    return prism_rtl::make_rc<CaseBehind>(cp, c);
}


/// TypeDefs: unbounded fn Cp, TyDef, Text -> Text
Text type_defs(const crate::emit::cpp::Cp& cp, const crate::lower::model::TyDef& t, const Text& head) {
    auto gens = cpp_template_head(t.params);
    auto show_ = t.show_ == crate::lower::model::Shown(crate::lower::model::Shown::ShownDerived{})
        ? Array(std::vector{show_def(cp, t, head, gens)})
        : Array<Text>{};
    auto pod = t.pod
        ? Array(std::vector{to_pod_def(cp, t, head, gens), from_pod_def(cp, t, head, gens)})
        : Array<Text>{};
    return crate::syntax::lexer::chars::join(append(show_, pod), Text::lit("\n"));
}


prism_rtl::Turn<Text> TypeDefs::cycle() const {
    const auto& cp = this->cp;
    const auto& t = this->t;
    const auto& head = this->head;
    auto gens = cpp_template_head(prism_rtl::val(t).params);
    auto show_ = prism_rtl::val(t).show_ == crate::lower::model::Shown(crate::lower::model::Shown::ShownDerived{})
        ? Array(std::vector{show_def(cp, t, head, gens)})
        : Array<Text>{};
    auto pod = prism_rtl::val(t).pod
        ? Array(std::vector{to_pod_def(cp, t, head, gens), from_pod_def(cp, t, head, gens)})
        : Array<Text>{};
    return prism_rtl::finished(crate::syntax::lexer::chars::join(append(show_, pod), Text::lit("\n")));
}


/// `Start TypeDefs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_type_defs(crate::emit::cpp::Cp cp, crate::lower::model::TyDef t, Text head) {
    return prism_rtl::make_rc<TypeDefs>(cp, t, head);
}


/// ShowDef: unbounded fn Cp, TyDef, Text, Text -> Text
Text show_def(const crate::emit::cpp::Cp& cp, const crate::lower::model::TyDef& t, const Text& head, const Text& gens) {
    auto body = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = t.shape;
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeRecord>(_m)) {
            _v.set(({
                auto c = or_(index(t.cases_, Nat(0u)), crate::lower::model::CaseDef{.name = Text::lit(""), .prism = Text::lit(""), .fields = Array<std::tuple<Text, crate::lower::model::OutTy>>{}});
                (prism_rtl::cat("p.record(\"", t.prism, "\", {", crate::syntax::lexer::chars::join(each(prism_rtl::val(c).fields, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
                auto&& f = std::get<0>(_p0);
                return prism_rtl::cat("{\"", prism_field(f), "\", ", crate::emit::cpp::field_id(f), "}");
            }), Text::lit(", ")), "});"));
            }));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeChoice>(_m)) {
            _v.set(crate::syntax::lexer::chars::join(each(crate::check::errors::range0(len(t.cases_)), [&](const Nat& i) { return show_case(t, i); }), Text::lit("\n")));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeNewtype>(_m)) {
            _v.set(prism_rtl::cat("p.choice(\"", first_case(t), "\", {", crate::syntax::lexer::chars::join(each(crate::check::errors::range0(first_arity(t)), [&](const Nat& k) { return prism_rtl::cat("a", k); }), Text::lit(", ")), "});"));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeUnit>(_m)) {
            _v.set(prism_rtl::cat("p.choice(\"", first_case(t), "\", {});"));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat(gens, "void ", head, "::show(Printer& p) const"), body);
}


prism_rtl::Turn<Text> ShowDef::cycle() const {
    const auto& cp = this->cp;
    const auto& t = this->t;
    const auto& head = this->head;
    const auto& gens = this->gens;
    auto body = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = prism_rtl::val(t).shape;
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeRecord>(_m)) {
            _v.set(({
                auto c = or_(index(prism_rtl::val(t).cases_, Nat(0u)), crate::lower::model::CaseDef{.name = Text::lit(""), .prism = Text::lit(""), .fields = Array<std::tuple<Text, crate::lower::model::OutTy>>{}});
                (prism_rtl::cat("p.record(\"", prism_rtl::val(t).prism, "\", {", crate::syntax::lexer::chars::join(each(prism_rtl::val(c).fields, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
                auto&& f = std::get<0>(_p0);
                return prism_rtl::cat("{\"", prism_field(f), "\", ", crate::emit::cpp::field_id(f), "}");
            }), Text::lit(", ")), "});"));
            }));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeChoice>(_m)) {
            _v.set(crate::syntax::lexer::chars::join(each(crate::check::errors::range0(len(prism_rtl::val(t).cases_)), [&](const Nat& i) { return show_case(t, i); }), Text::lit("\n")));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeNewtype>(_m)) {
            _v.set(prism_rtl::cat("p.choice(\"", first_case(t), "\", {", crate::syntax::lexer::chars::join(each(crate::check::errors::range0(first_arity(t)), [&](const Nat& k) { return prism_rtl::cat("a", k); }), Text::lit(", ")), "});"));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeUnit>(_m)) {
            _v.set(prism_rtl::cat("p.choice(\"", first_case(t), "\", {});"));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return prism_rtl::finished(crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat(gens, "void ", head, "::show(Printer& p) const"), body));
}


/// `Start ShowDef, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_show_def(crate::emit::cpp::Cp cp, crate::lower::model::TyDef t, Text head, Text gens) {
    return prism_rtl::make_rc<ShowDef>(cp, t, head, gens);
}


/// ShowCase: fn TyDef, Nat -> Text
Text show_case(const crate::lower::model::TyDef& t, const Nat& i) {
    auto c = or_(index(t.cases_, i), crate::lower::model::CaseDef{.name = Text::lit(""), .prism = Text::lit(""), .fields = Array<std::tuple<Text, crate::lower::model::OutTy>>{}});
    auto head = prism_rtl::cat(i == Nat(0u) ? Text::lit("if") : Text::lit("else if"), " (auto c = std::get_if<", prism_rtl::val(c).name, ">(&cases()))");
    return prism_rtl::cat(head, " p.choice(\"", prism_rtl::val(c).prism, "\", {", crate::syntax::lexer::chars::join(each(crate::check::errors::range0(len(prism_rtl::val(c).fields)), [&](const Nat& k) { return prism_rtl::cat("c->a", k); }), Text::lit(", ")), "});");
}


/// FirstCase: fn TyDef -> Text
Text first_case(const crate::lower::model::TyDef& t) {
    return prism_rtl::val(or_(index(t.cases_, Nat(0u)), crate::lower::model::CaseDef{.name = Text::lit(""), .prism = t.prism, .fields = Array<std::tuple<Text, crate::lower::model::OutTy>>{}})).prism;
}


/// FirstArity: fn TyDef -> Nat
Nat first_arity(const crate::lower::model::TyDef& t) {
    return len(prism_rtl::val(or_(index(t.cases_, Nat(0u)), crate::lower::model::CaseDef{.name = Text::lit(""), .prism = Text::lit(""), .fields = Array<std::tuple<Text, crate::lower::model::OutTy>>{}})).fields);
}


/// FieldTypes: fn [((Text, OutTy))] -> [OutTy]
Array<crate::lower::model::OutTy> field_types(const Array<std::tuple<Text, crate::lower::model::OutTy>>& fs) {
    return each(fs, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
        auto&& t = std::get<1>(_p0);
        return t;
    });
}


/// PositionalFields: unbounded fn Cp, [((Text, OutTy))] -> Text
Text positional_fields(const crate::emit::cpp::Cp& cp, const Array<std::tuple<Text, crate::lower::model::OutTy>>& fs) {
    auto tys = field_types(fs);
    return crate::syntax::lexer::chars::join(run_to_end(each_job(crate::check::errors::range0(len(tys)), ({
        auto cp_1 = cp;
        auto tys_2 = tys;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto cp_1_3 = cp_1;
            auto tys_2_3 = tys_2;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                call_then(crate::emit::cpp::start_cpp_type(cp_1_3, or_(index(tys_2_3, i), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}))), [=](Text cpp_type_15967) { return prism_rtl::finished(prism_rtl::cat(cpp_type_15967, " a", i, ";")); });
            });
        }));
        });
    })));
    }))), Text::lit("\n"));
}


prism_rtl::Turn<Text> PositionalFields::cycle() const {
    const auto& cp = this->cp;
    const auto& fs = this->fs;
    auto tys = field_types(fs);
    auto cp_1 = cp;
    return call_value(each_job(crate::check::errors::range0(len(tys)), ({
        auto cp_1_2 = cp_1;
        auto tys_2 = tys;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto cp_1_2_3 = cp_1_2;
            auto tys_2_3 = tys_2;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                call_then(crate::emit::cpp::start_cpp_type(cp_1_2_3, or_(index(tys_2_3, i), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}))), [=](Text cpp_type_15967) { return prism_rtl::finished(prism_rtl::cat(cpp_type_15967, " a", i, ";")); });
            });
        }));
        });
    })));
    })), [=](Array<Text> each_15935) { return prism_rtl::finished(crate::syntax::lexer::chars::join(each_15935, Text::lit("\n"))); });
}


/// `Start PositionalFields, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_positional_fields(crate::emit::cpp::Cp cp, Array<std::tuple<Text, crate::lower::model::OutTy>> fs) {
    return prism_rtl::make_rc<PositionalFields>(cp, fs);
}


/// ToPodDef: unbounded fn Cp, TyDef, Text, Text -> Text
Text to_pod_def(const crate::emit::cpp::Cp& cp, const crate::lower::model::TyDef& t, const Text& head, const Text& gens) {
    auto structure = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = t.shape;
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeRecord>(_m)) {
            _v.set(({
                auto c = or_(index(t.cases_, Nat(0u)), crate::lower::model::CaseDef{.name = Text::lit(""), .prism = Text::lit(""), .fields = Array<std::tuple<Text, crate::lower::model::OutTy>>{}});
                (prism_rtl::cat("Pod::record(\"", t.prism, "\", {", crate::syntax::lexer::chars::join(each(prism_rtl::val(c).fields, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
                auto&& f = std::get<0>(_p0);
                return prism_rtl::cat("{\"", prism_field(f), "\", prism_rtl::to_pod(", crate::emit::cpp::field_id(f), ")}");
            }), Text::lit(", ")), "})"));
            }));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeChoice>(_m)) {
            _v.set(choice_pod(t));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeNewtype>(_m)) {
            _v.set(prism_rtl::cat("Pod::choice(\"", first_case(t), "\", {", crate::syntax::lexer::chars::join(each(crate::check::errors::range0(first_arity(t)), [&](const Nat& k) { return prism_rtl::cat("prism_rtl::to_pod(a", k, ")"); }), Text::lit(", ")), "})"));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeUnit>(_m)) {
            _v.set(prism_rtl::cat("Pod::choice(\"", first_case(t), "\", {})"));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto body = t.show_ == crate::lower::model::Shown(crate::lower::model::Shown::ShownOwn{})
        ? prism_rtl::cat("Pod structure = ", structure, ";\nreturn Pod::shown(prism_rtl::show(*this), structure);")
        : prism_rtl::cat("return ", structure, ";");
    return crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat(gens, "Pod ", head, "::to_pod() const"), body);
}


prism_rtl::Turn<Text> ToPodDef::cycle() const {
    const auto& cp = this->cp;
    const auto& t = this->t;
    const auto& head = this->head;
    const auto& gens = this->gens;
    auto structure = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = prism_rtl::val(t).shape;
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeRecord>(_m)) {
            _v.set(({
                auto c = or_(index(prism_rtl::val(t).cases_, Nat(0u)), crate::lower::model::CaseDef{.name = Text::lit(""), .prism = Text::lit(""), .fields = Array<std::tuple<Text, crate::lower::model::OutTy>>{}});
                (prism_rtl::cat("Pod::record(\"", prism_rtl::val(t).prism, "\", {", crate::syntax::lexer::chars::join(each(prism_rtl::val(c).fields, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
                auto&& f = std::get<0>(_p0);
                return prism_rtl::cat("{\"", prism_field(f), "\", prism_rtl::to_pod(", crate::emit::cpp::field_id(f), ")}");
            }), Text::lit(", ")), "})"));
            }));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeChoice>(_m)) {
            _v.set(choice_pod(t));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeNewtype>(_m)) {
            _v.set(prism_rtl::cat("Pod::choice(\"", first_case(t), "\", {", crate::syntax::lexer::chars::join(each(crate::check::errors::range0(first_arity(t)), [&](const Nat& k) { return prism_rtl::cat("prism_rtl::to_pod(a", k, ")"); }), Text::lit(", ")), "})"));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeUnit>(_m)) {
            _v.set(prism_rtl::cat("Pod::choice(\"", first_case(t), "\", {})"));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto body = prism_rtl::val(t).show_ == crate::lower::model::Shown(crate::lower::model::Shown::ShownOwn{})
        ? prism_rtl::cat("Pod structure = ", structure, ";\nreturn Pod::shown(prism_rtl::show(*this), structure);")
        : prism_rtl::cat("return ", structure, ";");
    return prism_rtl::finished(crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat(gens, "Pod ", head, "::to_pod() const"), body));
}


/// `Start ToPodDef, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_to_pod_def(crate::emit::cpp::Cp cp, crate::lower::model::TyDef t, Text head, Text gens) {
    return prism_rtl::make_rc<ToPodDef>(cp, t, head, gens);
}


/// ChoicePod: fn TyDef -> Text
Text choice_pod(const crate::lower::model::TyDef& t) {
    auto arms = each(crate::check::errors::range0(len(t.cases_)), [&](const Nat& i) {
        return ({
            auto c = or_(index(t.cases_, i), crate::lower::model::CaseDef{.name = Text::lit(""), .prism = Text::lit(""), .fields = Array<std::tuple<Text, crate::lower::model::OutTy>>{}});
            (prism_rtl::cat("std::holds_alternative<", prism_rtl::val(c).name, ">(cases()) ? Pod::choice(\"", prism_rtl::val(c).prism, "\", {", crate::syntax::lexer::chars::join(each(crate::check::errors::range0(len(prism_rtl::val(c).fields)), [&](const Nat& k) { return prism_rtl::cat("prism_rtl::to_pod(std::get<", prism_rtl::val(c).name, ">(cases()).a", k, ")"); }), Text::lit(", ")), "})"));
        });
    });
    return prism_rtl::cat(crate::syntax::lexer::chars::join(arms, Text::lit("\n    : ")), "\n    : Pod()");
}


/// FromPodDef: unbounded fn Cp, TyDef, Text, Text -> Text
Text from_pod_def(const crate::emit::cpp::Cp& cp, const crate::lower::model::TyDef& t, const Text& head, const Text& gens) {
    auto body = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = t.shape;
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeRecord>(_m)) {
            _v.set(({
                auto c = or_(index(t.cases_, Nat(0u)), crate::lower::model::CaseDef{.name = Text::lit(""), .prism = Text::lit(""), .fields = Array<std::tuple<Text, crate::lower::model::OutTy>>{}});
                auto reads = crate::syntax::lexer::chars::join(run_to_end(each_job(prism_rtl::val(c).fields, ({
                    auto cp_1 = cp;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
                    return ({
                        auto cp_1_2 = cp_1;
                        entered(once_job([=]() {
                        return ({
                            auto [f, ft] = p0;
                            call_then(crate::emit::cpp::start_cpp_type(cp_1_2, ft), [=](Text cpp_type_17539) { return prism_rtl::finished(prism_rtl::cat(".", crate::emit::cpp::field_id(f), " = TRY(prism_rtl::from_pod<", cpp_type_17539, ">(TRY(crate::prelude::field(whole, \"", prism_field(f), "\"))))")); });
                        });
                    }));
                    });
                })));
                }))), Text::lit(", "));
                (prism_rtl::cat("return ", head, "{", reads, "};"));
            }));
            goto _done;
        }
        {
            _v.set(({
                auto arms = run_to_end(each_job(t.cases_, ({
                    auto cp_1 = cp;
                    auto t_2 = t;
                    auto head_3 = head;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::CaseDef)>>(prism_rtl::rc([=](crate::lower::model::CaseDef p0) {
                    return ({
                        auto cp_1_4 = cp_1;
                        auto t_2_4 = t_2;
                        auto head_3_4 = head_3;
                        entered(once_job([=]() {
                        return ({
                            auto c = p0;
                            ({
                            auto n = len(prism_rtl::val(c).fields);
                            auto tys = field_types(prism_rtl::val(c).fields);
                            call_value(each_job(crate::check::errors::range0(n), ({
                            auto cp_1_4_4 = cp_1_4;
                            auto tys_4 = tys;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Nat)>>(prism_rtl::rc([=](Nat p0) {
                            return ({
                                auto cp_1_4_4_5 = cp_1_4_4;
                                auto tys_4_5 = tys_4;
                                entered(once_job([=]() {
                                return ({
                                    auto i = p0;
                                    call_then(crate::emit::cpp::start_cpp_type(cp_1_4_4_5, or_(index(tys_4_5, i), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}))), [=](Text cpp_type_17885) { return prism_rtl::finished(prism_rtl::cat("TRY(prism_rtl::from_pod<", cpp_type_17885, ">(c->args[", i, "]))")); });
                                });
                            }));
                            });
                        })));
                        })), [=](Array<Text> each_17837) {
                            return ({
                                auto args = crate::syntax::lexer::chars::join(each_17837, Text::lit(", "));
                                auto made = ({
                                    __label__ _done;
                                    prism_rtl::Slot<Text> _v;
                                    auto&& _m = t_2_4.shape;
                                    if (prism_rtl::is<crate::lower::model::TyShape::ShapeChoice>(_m)) {
                                        _v.set(prism_rtl::cat(head_3_4, "(", prism_rtl::val(c).name, "{", args, "})"));
                                        goto _done;
                                    }
                                    {
                                        _v.set(prism_rtl::cat(head_3_4, "{", args, "}"));
                                        goto _done;
                                    }
                                _done:
                                    _v.take();
                                });
                                (prism_rtl::finished(prism_rtl::cat("if (c->ctor == \"", prism_rtl::val(c).prism, "\" && c->args.size() == ", n, ") return ", made, ";")));
                            });
                        });
                        });
                        });
                    }));
                    });
                })));
                })));
                (prism_rtl::cat("const Pod& p = whole.structure();\nif (auto c = p.if_choice()) {\n", indent_cpp(crate::syntax::lexer::chars::join(arms, Text::lit("\n"))), "\n}\nreturn mismatch<", head, ">(\"a ", t.prism, "\", p);"));
            }));
            goto _done;
        }
    _done:
        _v.take();
    });
    return crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat(gens, "Result<", head, "> ", head, "::from_pod(const Pod& whole)"), body);
}


prism_rtl::Turn<Text> FromPodDef::cycle() const {
    const auto& cp = this->cp;
    const auto& t = this->t;
    const auto& head = this->head;
    const auto& gens = this->gens;
    auto body = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = prism_rtl::val(t).shape;
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeRecord>(_m)) {
            _v.set(({
                auto c = or_(index(prism_rtl::val(t).cases_, Nat(0u)), crate::lower::model::CaseDef{.name = Text::lit(""), .prism = Text::lit(""), .fields = Array<std::tuple<Text, crate::lower::model::OutTy>>{}});
                auto reads = crate::syntax::lexer::chars::join(run_to_end(each_job(prism_rtl::val(c).fields, ({
                    auto cp_1 = cp;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
                    return ({
                        auto cp_1_2 = cp_1;
                        entered(once_job([=]() {
                        return ({
                            auto [f, ft] = p0;
                            call_then(crate::emit::cpp::start_cpp_type(cp_1_2, ft), [=](Text cpp_type_17539) { return prism_rtl::finished(prism_rtl::cat(".", crate::emit::cpp::field_id(f), " = TRY(prism_rtl::from_pod<", cpp_type_17539, ">(TRY(crate::prelude::field(whole, \"", prism_field(f), "\"))))")); });
                        });
                    }));
                    });
                })));
                }))), Text::lit(", "));
                (prism_rtl::cat("return ", head, "{", reads, "};"));
            }));
            goto _done;
        }
        {
            _v.set(({
                auto arms = run_to_end(each_job(prism_rtl::val(t).cases_, ({
                    auto cp_1 = cp;
                    auto t_2 = t;
                    auto head_3 = head;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::CaseDef)>>(prism_rtl::rc([=](crate::lower::model::CaseDef p0) {
                    return ({
                        auto cp_1_4 = cp_1;
                        auto t_2_4 = t_2;
                        auto head_3_4 = head_3;
                        entered(once_job([=]() {
                        return ({
                            auto c = p0;
                            ({
                            auto n = len(prism_rtl::val(c).fields);
                            auto tys = field_types(prism_rtl::val(c).fields);
                            call_value(each_job(crate::check::errors::range0(n), ({
                            auto cp_1_4_4 = cp_1_4;
                            auto tys_4 = tys;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Nat)>>(prism_rtl::rc([=](Nat p0) {
                            return ({
                                auto cp_1_4_4_5 = cp_1_4_4;
                                auto tys_4_5 = tys_4;
                                entered(once_job([=]() {
                                return ({
                                    auto i = p0;
                                    call_then(crate::emit::cpp::start_cpp_type(cp_1_4_4_5, or_(index(tys_4_5, i), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}))), [=](Text cpp_type_17885) { return prism_rtl::finished(prism_rtl::cat("TRY(prism_rtl::from_pod<", cpp_type_17885, ">(c->args[", i, "]))")); });
                                });
                            }));
                            });
                        })));
                        })), [=](Array<Text> each_17837) {
                            return ({
                                auto args = crate::syntax::lexer::chars::join(each_17837, Text::lit(", "));
                                auto made = ({
                                    __label__ _done;
                                    prism_rtl::Slot<Text> _v;
                                    auto&& _m = prism_rtl::val(t_2_4).shape;
                                    if (prism_rtl::is<crate::lower::model::TyShape::ShapeChoice>(_m)) {
                                        _v.set(prism_rtl::cat(head_3_4, "(", prism_rtl::val(c).name, "{", args, "})"));
                                        goto _done;
                                    }
                                    {
                                        _v.set(prism_rtl::cat(head_3_4, "{", args, "}"));
                                        goto _done;
                                    }
                                _done:
                                    _v.take();
                                });
                                (prism_rtl::finished(prism_rtl::cat("if (c->ctor == \"", prism_rtl::val(c).prism, "\" && c->args.size() == ", n, ") return ", made, ";")));
                            });
                        });
                        });
                        });
                    }));
                    });
                })));
                })));
                (prism_rtl::cat("const Pod& p = whole.structure();\nif (auto c = p.if_choice()) {\n", indent_cpp(crate::syntax::lexer::chars::join(arms, Text::lit("\n"))), "\n}\nreturn mismatch<", head, ">(\"a ", prism_rtl::val(t).prism, "\", p);"));
            }));
            goto _done;
        }
    _done:
        _v.take();
    });
    return prism_rtl::finished(crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat(gens, "Result<", head, "> ", head, "::from_pod(const Pod& whole)"), body));
}


/// `Start FromPodDef, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_from_pod_def(crate::emit::cpp::Cp cp, crate::lower::model::TyDef t, Text head, Text gens) {
    return prism_rtl::make_rc<FromPodDef>(cp, t, head, gens);
}


/// PrismField: fn Text -> Text
Text prism_field(const Text& f) {
    return crate::syntax::lexer::chars::last_char(f) == Text::lit("_")
        ? crate::syntax::lexer::chars::before_last(f)
        : f;
}


/// IndentCpp: fn Text -> Text
Text indent_cpp(const Text& t) {
    return crate::syntax::lexer::chars::join(each(split_on(t, Text::lit("\n")), [&](const Text& l) { return l == Text::lit("") ? Text::lit("") : prism_rtl::cat("    ", l); }), Text::lit("\n"));
}


/// TagParts: unbounded fn Cp, TagDef -> Parts
Parts tag_parts(const crate::emit::cpp::Cp& cp, const crate::lower::model::TagDef& t) {
    auto fields = crate::syntax::lexer::chars::join(run_to_end(each_job(t.fields, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, Text, crate::lower::model::OutTy> p0) {
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=]() {
            return ({
                auto&& _f = p0;
                auto&& f = std::get<1>(_f);
                auto&& ft = std::get<2>(_f);
                call_then(crate::emit::cpp::start_cpp_type(cp_1_2, ft), [=](Text cpp_type_18913) { return prism_rtl::finished(prism_rtl::cat(cpp_type_18913, " ", crate::emit::cpp::field_id(f), ";")); });
            });
        }));
        });
    })));
    }))), Text::lit("\n"));
    auto pods = crate::syntax::lexer::chars::join(each(t.fields, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
        auto&& p_ = std::get<0>(_p0);
        auto&& f = std::get<1>(_p0);
        return prism_rtl::cat("{\"", p_, "\", prism_rtl::to_pod(", crate::emit::cpp::field_id(f), ")}");
    }), Text::lit(", "));
    auto reads = crate::syntax::lexer::chars::join(run_to_end(each_job(t.fields, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, Text, crate::lower::model::OutTy> p0) {
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=]() {
            return ({
                auto [p_, f, ft] = p0;
                call_then(crate::emit::cpp::start_cpp_type(cp_1_2, ft), [=](Text cpp_type_19153) { return prism_rtl::finished(prism_rtl::cat(".", crate::emit::cpp::field_id(f), " = TRY(prism_rtl::from_pod<", cpp_type_19153, ">(TRY(crate::prelude::field(p, \"", p_, "\"))))")); });
            });
        }));
        });
    })));
    }))), Text::lit(", "));
    auto eq = t.eq
        ? prism_rtl::cat("bool operator==(const ", t.name, "&) const = default;")
        : Text::lit("");
    auto back_ = t.pod
        ? prism_rtl::cat("static Result<", t.name, "> from_pod(const Pod& p);")
        : Text::lit("");
    auto deep = run_to_end(fold_job(t.fields, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, Text, crate::lower::model::OutTy>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<Text, Text, crate::lower::model::OutTy>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto d = p0;
                auto&& _ft = p1;
                auto&& ft = std::get<2>(_ft);
                (prism_rtl::finished(d || crate::lower::types::holds_dyn(ft)));
            });
        }));
    }))));
    auto level_decl = deep
        ? Text::lit("/// The level as a World reads it: each dynamic it holds sampled at the read point.\nPod level_pod(const Cx& cx) const;\n/// The update events of the dynamics it holds, and of theirs.\nvoid level_ports(const Cx& cx, std::vector<prism_rtl::Rc<prism_rtl::Port<Unit>>>& out) const;")
        : Text::lit("");
    auto decl = crate::emit::cpp::templates::items::cpp_tag_struct(cpp_source_doc(prism_rtl::cat("The `Level` of `", t.tag_name, "`:"), t.doc), t.name, fields, t.tag_name, crate::syntax::lexer::chars::join(filter(Array(std::vector{eq, back_, level_decl}), [&](const Text& s) { return s != Text::lit(""); }), Text::lit("\n")));
    auto deep_pods = crate::syntax::lexer::chars::join(run_to_end(each_job(t.fields, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, Text, crate::lower::model::OutTy> p0) {
        return entered(once_job([=]() {
            return ({
                auto [p_, f, ft] = p0;
                (prism_rtl::more(prism_rtl::rc(CppDeepField(p_, f, ft))));
            });
        }));
    })))), Text::lit(", "));
    auto deep_ports = crate::syntax::lexer::chars::join(filter(run_to_end(each_job(t.fields, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, Text, crate::lower::model::OutTy> p0) {
        return entered(once_job([=]() {
            return ({
                auto&& _f = p0;
                auto&& f = std::get<1>(_f);
                auto&& ft = std::get<2>(_f);
                (prism_rtl::more(prism_rtl::rc(CppDeepPorts(f, ft))));
            });
        }));
    })))), [&](const Text& s) { return s != Text::lit(""); }), Text::lit("\n"));
    auto level_defs = deep
        ? Array(std::vector{crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat("Pod ", t.name, "::level_pod(const Cx& cx) const"), prism_rtl::cat("static_cast<void>(cx);\nreturn Pod::element(TAG, {", deep_pods, "});")), crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat("void ", t.name, "::level_ports(const Cx& cx, std::vector<prism_rtl::Rc<prism_rtl::Port<Unit>>>& out) const"), prism_rtl::cat("static_cast<void>(cx);\nstatic_cast<void>(out);", deep_ports == Text::lit("")
        ? Text::lit("")
        : prism_rtl::cat("\n", deep_ports)))})
        : Array<Text>{};
    auto to_pod_ = crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat("Pod ", t.name, "::to_pod() const"), prism_rtl::cat("return Pod::element(TAG, {", pods, "});"));
    auto show_ = crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat("void ", t.name, "::show(Printer& p) const"), Text::lit("prism_rtl::to_pod(*this).structure();\nShow<Pod>::show(prism_rtl::to_pod(*this), p);"));
    auto from_pod_ = t.pod
        ? Array(std::vector{crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat("Result<", t.name, "> ", t.name, "::from_pod(const Pod& p)"), prism_rtl::cat("if (auto t = p.tag(); t && *t == TAG) return ", t.name, "{", reads, "};\nreturn mismatch<", t.name, ">(\"a ", t.tag_name, "\", p);"))})
        : Array<Text>{};
    auto deps = crate::emit::cpp::patterns::concat2(run_to_end(each_job(t.fields, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Text, Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, Text, crate::lower::model::OutTy> p0) {
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=]() {
            return ({
                auto&& _ft = p0;
                auto&& ft = std::get<2>(_ft);
                (prism_rtl::more(prism_rtl::rc(ValueDeps(cp_1_2, ft))));
            });
        }));
        });
    })));
    }))));
    return Parts{.forward = Array(std::vector{prism_rtl::cat("struct ", t.name, ";")}), .values = Array(std::vector{ValueDecl{.path_ = decl_path(cp, t.name), .deps = deps, .text = decl}}), .protos = Array<Text>{}, .classes = Array<Text>{}, .outer = Array<Text>{}, .generic = Array<Text>{}, .defs = append(append(Array(std::vector{to_pod_, show_}), from_pod_), level_defs)};
}


prism_rtl::Turn<Parts> TagParts::cycle() const {
    const auto& cp = this->cp;
    const auto& t = this->t;
    auto cp_1 = cp;
    auto t_2 = t;
    return call_value(each_job(prism_rtl::val(t_2).fields, ({
        auto cp_1_3 = cp_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, Text, crate::lower::model::OutTy> p0) {
        return ({
            auto cp_1_3_3 = cp_1_3;
            entered(once_job([=]() {
            return ({
                auto&& _f = p0;
                auto&& f = std::get<1>(_f);
                auto&& ft = std::get<2>(_f);
                call_then(crate::emit::cpp::start_cpp_type(cp_1_3_3, ft), [=](Text cpp_type_18913) { return prism_rtl::finished(prism_rtl::cat(cpp_type_18913, " ", crate::emit::cpp::field_id(f), ";")); });
            });
        }));
        });
    })));
    })), [=](Array<Text> each_18875) {
        return ({
            auto fields = crate::syntax::lexer::chars::join(each_18875, Text::lit("\n"));
            auto pods = crate::syntax::lexer::chars::join(each(prism_rtl::val(t_2).fields, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
                auto&& p_ = std::get<0>(_p0);
                auto&& f = std::get<1>(_p0);
                return prism_rtl::cat("{\"", p_, "\", prism_rtl::to_pod(", crate::emit::cpp::field_id(f), ")}");
            }), Text::lit(", "));
            call_value(each_job(prism_rtl::val(t_2).fields, ({
            auto cp_1_3 = cp_1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, Text, crate::lower::model::OutTy> p0) {
            return ({
                auto cp_1_3_3 = cp_1_3;
                entered(once_job([=]() {
                return ({
                    auto [p_, f, ft] = p0;
                    call_then(crate::emit::cpp::start_cpp_type(cp_1_3_3, ft), [=](Text cpp_type_19153) { return prism_rtl::finished(prism_rtl::cat(".", crate::emit::cpp::field_id(f), " = TRY(prism_rtl::from_pod<", cpp_type_19153, ">(TRY(crate::prelude::field(p, \"", p_, "\"))))")); });
                });
            }));
            });
        })));
        })), [=](Array<Text> each_19081) {
            return ({
                auto reads = crate::syntax::lexer::chars::join(each_19081, Text::lit(", "));
                auto eq = prism_rtl::val(t_2).eq
                    ? prism_rtl::cat("bool operator==(const ", prism_rtl::val(t_2).name, "&) const = default;")
                    : Text::lit("");
                auto back_ = prism_rtl::val(t_2).pod
                    ? prism_rtl::cat("static Result<", prism_rtl::val(t_2).name, "> from_pod(const Pod& p);")
                    : Text::lit("");
                call_value(fold_job(prism_rtl::val(t_2).fields, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, Text, crate::lower::model::OutTy>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<Text, Text, crate::lower::model::OutTy>> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return entered(once_job([=]() {
                    return ({
                        auto d = p0;
                        auto&& _ft = p1;
                        auto&& ft = std::get<2>(_ft);
                        (prism_rtl::finished(d || crate::lower::types::holds_dyn(ft)));
                    });
                }));
            }))), [=](bool fold_19472) {
                return ({
                    auto deep = fold_19472;
                    auto level_decl = deep
                        ? Text::lit("/// The level as a World reads it: each dynamic it holds sampled at the read point.\nPod level_pod(const Cx& cx) const;\n/// The update events of the dynamics it holds, and of theirs.\nvoid level_ports(const Cx& cx, std::vector<prism_rtl::Rc<prism_rtl::Port<Unit>>>& out) const;")
                        : Text::lit("");
                    auto decl = crate::emit::cpp::templates::items::cpp_tag_struct(cpp_source_doc(prism_rtl::cat("The `Level` of `", prism_rtl::val(t_2).tag_name, "`:"), prism_rtl::val(t_2).doc), prism_rtl::val(t_2).name, fields, prism_rtl::val(t_2).tag_name, crate::syntax::lexer::chars::join(filter(Array(std::vector{eq, back_, level_decl}), [&](const Text& s) { return s != Text::lit(""); }), Text::lit("\n")));
                    call_value(each_job(prism_rtl::val(t_2).fields, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, Text, crate::lower::model::OutTy> p0) {
                    return entered(once_job([=]() {
                        return ({
                            auto [p_, f, ft] = p0;
                            (prism_rtl::more(prism_rtl::rc(CppDeepField(p_, f, ft))));
                        });
                    }));
                }))), [=](Array<Text> each_20054) {
                    return ({
                        auto deep_pods = crate::syntax::lexer::chars::join(each_20054, Text::lit(", "));
                        call_value(each_job(prism_rtl::val(t_2).fields, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, Text, crate::lower::model::OutTy> p0) {
                        return entered(once_job([=]() {
                            return ({
                                auto&& _f = p0;
                                auto&& f = std::get<1>(_f);
                                auto&& ft = std::get<2>(_f);
                                (prism_rtl::more(prism_rtl::rc(CppDeepPorts(f, ft))));
                            });
                        }));
                    }))), [=](Array<Text> each_20148) {
                        return ({
                            auto deep_ports = crate::syntax::lexer::chars::join(filter(each_20148, [&](const Text& s) { return s != Text::lit(""); }), Text::lit("\n"));
                            auto level_defs = deep
                                ? Array(std::vector{crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat("Pod ", prism_rtl::val(t_2).name, "::level_pod(const Cx& cx) const"), prism_rtl::cat("static_cast<void>(cx);\nreturn Pod::element(TAG, {", deep_pods, "});")), crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat("void ", prism_rtl::val(t_2).name, "::level_ports(const Cx& cx, std::vector<prism_rtl::Rc<prism_rtl::Port<Unit>>>& out) const"), prism_rtl::cat("static_cast<void>(cx);\nstatic_cast<void>(out);", deep_ports == Text::lit("")
                                ? Text::lit("")
                                : prism_rtl::cat("\n", deep_ports)))})
                                : Array<Text>{};
                            auto to_pod_ = crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat("Pod ", prism_rtl::val(t_2).name, "::to_pod() const"), prism_rtl::cat("return Pod::element(TAG, {", pods, "});"));
                            auto show_ = crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat("void ", prism_rtl::val(t_2).name, "::show(Printer& p) const"), Text::lit("prism_rtl::to_pod(*this).structure();\nShow<Pod>::show(prism_rtl::to_pod(*this), p);"));
                            auto from_pod_ = prism_rtl::val(t_2).pod
                                ? Array(std::vector{crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat("Result<", prism_rtl::val(t_2).name, "> ", prism_rtl::val(t_2).name, "::from_pod(const Pod& p)"), prism_rtl::cat("if (auto t = p.tag(); t && *t == TAG) return ", prism_rtl::val(t_2).name, "{", reads, "};\nreturn mismatch<", prism_rtl::val(t_2).name, ">(\"a ", prism_rtl::val(t_2).tag_name, "\", p);"))})
                                : Array<Text>{};
                            call_value(each_job(prism_rtl::val(t_2).fields, ({
                            auto cp_1_3 = cp_1;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Text, Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, Text, crate::lower::model::OutTy> p0) {
                            return ({
                                auto cp_1_3_3 = cp_1_3;
                                entered(once_job([=]() {
                                return ({
                                    auto&& _ft = p0;
                                    auto&& ft = std::get<2>(_ft);
                                    (prism_rtl::more(prism_rtl::rc(ValueDeps(cp_1_3_3, ft))));
                                });
                            }));
                            });
                        })));
                        })), [=](Array<Array<Text>> each_21142) {
                            return ({
                                auto deps = crate::emit::cpp::patterns::concat2(each_21142);
                                (prism_rtl::finished(Parts{.forward = Array(std::vector{prism_rtl::cat("struct ", prism_rtl::val(t_2).name, ";")}), .values = Array(std::vector{ValueDecl{.path_ = decl_path(cp_1, prism_rtl::val(t_2).name), .deps = deps, .text = decl}}), .protos = Array<Text>{}, .classes = Array<Text>{}, .outer = Array<Text>{}, .generic = Array<Text>{}, .defs = append(append(Array(std::vector{to_pod_, show_}), from_pod_), level_defs)}));
                            });
                        });
                        });
                    });
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start TagParts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Parts> start_tag_parts(crate::emit::cpp::Cp cp, crate::lower::model::TagDef t) {
    return prism_rtl::make_rc<TagParts>(cp, t);
}


/// CppDeepField: unbounded fn Text, Text, OutTy -> Text
Text cpp_deep_field(const Text& p_, const Text& f, const crate::lower::model::OutTy& ft) {
    return prism_rtl::cat("{\"", p_, "\", ", cpp_deep_pod(f, ft), "}");
}


prism_rtl::Turn<Text> CppDeepField::cycle() const {
    const auto& p_ = this->p_;
    const auto& f = this->f;
    const auto& ft = this->ft;
    auto f_1 = f;
    auto ft_2 = ft;
    auto p__3 = p_;
    return call_then(start_cpp_deep_pod(f_1, ft_2), [=](Text cpp_deep_pod_21697) { return prism_rtl::finished(prism_rtl::cat("{\"", p__3, "\", ", cpp_deep_pod_21697, "}")); });
}


/// `Start CppDeepField, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_deep_field(Text p_, Text f, crate::lower::model::OutTy ft) {
    return prism_rtl::make_rc<CppDeepField>(p_, f, ft);
}


/// CppDeepPod: unbounded fn Text, OutTy -> Text
Text cpp_deep_pod(const Text& f, const crate::lower::model::OutTy& ft) {
    if (prism_rtl::is<crate::lower::model::OutTy::OutMap>(ft)) {
        auto&& m21786_0_1 = prism_rtl::as<crate::lower::model::OutTy::OutMap>(ft).a1;
        if (prism_rtl::is<crate::lower::model::OutTy::OutDyn>(prism_rtl::val(prism_rtl::val(m21786_0_1)))) {
            auto&& m21786_0_1_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(prism_rtl::val(prism_rtl::val(m21786_0_1))).a0;
            if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(prism_rtl::val(prism_rtl::val(m21786_0_1_r_0)))) {
                auto&& m21786_0_1_r_0_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(prism_rtl::val(prism_rtl::val(m21786_0_1_r_0))).a0;
                if (m21786_0_1_r_0_r_0 == Text::lit("crate::Elem")) {
                    return prism_rtl::cat("prism_rtl::dynamics_pod(", crate::emit::cpp::field_id(f), ", cx)");
                }
            }
        }
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutDyn>(ft)) {
        auto&& m21786_1_0 = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(ft).a0;
        if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(prism_rtl::val(prism_rtl::val(m21786_1_0)))) {
            auto&& m21786_1_0_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(prism_rtl::val(prism_rtl::val(m21786_1_0))).a0;
            if (m21786_1_0_r_0 == Text::lit("crate::Elem")) {
                return prism_rtl::cat("prism_rtl::level_pod(", crate::emit::cpp::field_id(f), ".sample(cx), cx)");
            }
        }
    }
    {
        auto&& other = ft;
        return crate::lower::types::holds_dyn(other)
            ? Text::lit("[] { static_assert(false, \"prismc: a tag field holding a dynamic other than `$Elem` or a map of them is not read deep (claude/incremental-host-document.md, doubt WD)\"); return Pod(); }()")
            : prism_rtl::cat("prism_rtl::to_pod(", crate::emit::cpp::field_id(f), ")");
    }
}


prism_rtl::Turn<Text> CppDeepPod::cycle() const {
    const auto& f = this->f;
    const auto& ft = this->ft;
    return ({
        prism_rtl::is<crate::lower::model::OutTy::OutMap>(ft) && ({
        auto&& m21786_0_1 = prism_rtl::as<crate::lower::model::OutTy::OutMap>(ft).a1;
        prism_rtl::is<crate::lower::model::OutTy::OutDyn>(prism_rtl::val(prism_rtl::val(m21786_0_1))) && ({
        auto&& m21786_0_1_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(prism_rtl::val(prism_rtl::val(m21786_0_1))).a0;
        prism_rtl::is<crate::lower::model::OutTy::OutNamed>(prism_rtl::val(prism_rtl::val(m21786_0_1_r_0))) && ({
        auto&& m21786_0_1_r_0_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(prism_rtl::val(prism_rtl::val(m21786_0_1_r_0))).a0;
        (m21786_0_1_r_0_r_0 == Text::lit("crate::Elem"));
    });
    });
    }) ? ({
        auto&& m21786_0_1 = prism_rtl::as<crate::lower::model::OutTy::OutMap>(ft).a1;
        auto&& m21786_0_1_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(prism_rtl::val(prism_rtl::val(m21786_0_1))).a0;
        auto&& m21786_0_1_r_0_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(prism_rtl::val(prism_rtl::val(m21786_0_1_r_0))).a0;
        prism_rtl::finished(prism_rtl::cat("prism_rtl::dynamics_pod(", crate::emit::cpp::field_id(f), ", cx)"));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutDyn>(ft) && ({
        auto&& m21786_1_0 = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(ft).a0;
        prism_rtl::is<crate::lower::model::OutTy::OutNamed>(prism_rtl::val(prism_rtl::val(m21786_1_0))) && ({
        auto&& m21786_1_0_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(prism_rtl::val(prism_rtl::val(m21786_1_0))).a0;
        (m21786_1_0_r_0 == Text::lit("crate::Elem"));
    });
    }) ? ({
        auto&& m21786_1_0 = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(ft).a0;
        auto&& m21786_1_0_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(prism_rtl::val(prism_rtl::val(m21786_1_0))).a0;
        prism_rtl::finished(prism_rtl::cat("prism_rtl::level_pod(", crate::emit::cpp::field_id(f), ".sample(cx), cx)"));
    })
        : ({
        auto&& other = ft;
        ({
        auto f_1 = f;
        auto other_2 = other;
        call_then(crate::lower::types::start_holds_dyn(other_2), [=](bool holds_dyn_22011) {
        return holds_dyn_22011
            ? prism_rtl::finished(Text::lit("[] { static_assert(false, \"prismc: a tag field holding a dynamic other than `$Elem` or a map of them is not read deep (claude/incremental-host-document.md, doubt WD)\"); return Pod(); }()"))
            : prism_rtl::finished(prism_rtl::cat("prism_rtl::to_pod(", crate::emit::cpp::field_id(f_1), ")"));
    });
    });
    });
    });
}


/// `Start CppDeepPod, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_deep_pod(Text f, crate::lower::model::OutTy ft) {
    return prism_rtl::make_rc<CppDeepPod>(f, ft);
}


/// CppDeepPorts: unbounded fn Text, OutTy -> Text
Text cpp_deep_ports(const Text& f, const crate::lower::model::OutTy& ft) {
    if (prism_rtl::is<crate::lower::model::OutTy::OutMap>(ft)) {
        auto&& m22331_0_1 = prism_rtl::as<crate::lower::model::OutTy::OutMap>(ft).a1;
        if (prism_rtl::is<crate::lower::model::OutTy::OutDyn>(prism_rtl::val(prism_rtl::val(m22331_0_1)))) {
            auto&& m22331_0_1_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(prism_rtl::val(prism_rtl::val(m22331_0_1))).a0;
            if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(prism_rtl::val(prism_rtl::val(m22331_0_1_r_0)))) {
                auto&& m22331_0_1_r_0_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(prism_rtl::val(prism_rtl::val(m22331_0_1_r_0))).a0;
                if (m22331_0_1_r_0_r_0 == Text::lit("crate::Elem")) {
                    return prism_rtl::cat("prism_rtl::dynamics_ports(", crate::emit::cpp::field_id(f), ", cx, out);");
                }
            }
        }
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutDyn>(ft)) {
        auto&& m22331_1_0 = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(ft).a0;
        if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(prism_rtl::val(prism_rtl::val(m22331_1_0)))) {
            auto&& m22331_1_0_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(prism_rtl::val(prism_rtl::val(m22331_1_0))).a0;
            if (m22331_1_0_r_0 == Text::lit("crate::Elem")) {
                return prism_rtl::cat("out.push_back(", crate::emit::cpp::field_id(f), ".updates);\nprism_rtl::level_ports(", crate::emit::cpp::field_id(f), ".sample(cx), cx, out);");
            }
        }
    }
    {
        return Text::lit("");
    }
}


prism_rtl::Turn<Text> CppDeepPorts::cycle() const {
    const auto& f = this->f;
    const auto& ft = this->ft;
    return ({
        prism_rtl::is<crate::lower::model::OutTy::OutMap>(ft) && ({
        auto&& m22331_0_1 = prism_rtl::as<crate::lower::model::OutTy::OutMap>(ft).a1;
        prism_rtl::is<crate::lower::model::OutTy::OutDyn>(prism_rtl::val(prism_rtl::val(m22331_0_1))) && ({
        auto&& m22331_0_1_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(prism_rtl::val(prism_rtl::val(m22331_0_1))).a0;
        prism_rtl::is<crate::lower::model::OutTy::OutNamed>(prism_rtl::val(prism_rtl::val(m22331_0_1_r_0))) && ({
        auto&& m22331_0_1_r_0_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(prism_rtl::val(prism_rtl::val(m22331_0_1_r_0))).a0;
        (m22331_0_1_r_0_r_0 == Text::lit("crate::Elem"));
    });
    });
    }) ? ({
        auto&& m22331_0_1 = prism_rtl::as<crate::lower::model::OutTy::OutMap>(ft).a1;
        auto&& m22331_0_1_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(prism_rtl::val(prism_rtl::val(m22331_0_1))).a0;
        auto&& m22331_0_1_r_0_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(prism_rtl::val(prism_rtl::val(m22331_0_1_r_0))).a0;
        prism_rtl::finished(prism_rtl::cat("prism_rtl::dynamics_ports(", crate::emit::cpp::field_id(f), ", cx, out);"));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutDyn>(ft) && ({
        auto&& m22331_1_0 = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(ft).a0;
        prism_rtl::is<crate::lower::model::OutTy::OutNamed>(prism_rtl::val(prism_rtl::val(m22331_1_0))) && ({
        auto&& m22331_1_0_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(prism_rtl::val(prism_rtl::val(m22331_1_0))).a0;
        (m22331_1_0_r_0 == Text::lit("crate::Elem"));
    });
    }) ? ({
        auto&& m22331_1_0 = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(ft).a0;
        auto&& m22331_1_0_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(prism_rtl::val(prism_rtl::val(m22331_1_0))).a0;
        prism_rtl::finished(prism_rtl::cat("out.push_back(", crate::emit::cpp::field_id(f), ".updates);\nprism_rtl::level_ports(", crate::emit::cpp::field_id(f), ".sample(cx), cx, out);"));
    })
        : prism_rtl::finished(Text::lit(""));
    });
}


/// `Start CppDeepPorts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_deep_ports(Text f, crate::lower::model::OutTy ft) {
    return prism_rtl::make_rc<CppDeepPorts>(f, ft);
}


/// RowParts: unbounded fn Cp, Text, RowDef -> Parts
Parts row_parts(const crate::emit::cpp::Cp& cp, const Text& m, const crate::lower::model::RowDef& r) {
    auto names = each(r.cases_, [&](const std::tuple<Text, Text>& _p0) {
        auto&& v_ = std::get<0>(_p0);
        return v_;
    });
    auto levels = r.level
        ? Text::lit("\nPod level_pod(const Cx& cx) const;\nvoid level_ports(const Cx& cx, std::vector<prism_rtl::Rc<prism_rtl::Port<Unit>>>& out) const;")
        : Text::lit("");
    auto pod = prism_rtl::cat("Pod to_pod() const;\nvoid show(Printer& p) const;", r.pod
        ? prism_rtl::cat("\nstatic Result<", r.name, "> from_pod(const Pod& p);")
        : Text::lit(""), levels);
    auto cases = crate::syntax::lexer::chars::join(each(r.cases_, [&](const std::tuple<Text, Text>& _p0) {
        auto&& v_ = std::get<0>(_p0);
        auto&& st = std::get<1>(_p0);
        return crate::emit::cpp::templates::items::case_decl(v_, prism_rtl::cat(row_struct(m, st), " a0;", r.eq
            ? prism_rtl::cat("\nbool operator==(const ", v_, "&) const = default;")
            : Text::lit("")));
    }), Text::lit("\n"));
    auto cls = crate::emit::cpp::templates::items::choice_class(cpp_source_doc(prism_rtl::cat("`", r.prism, "`, a row kind\'s values:"), r.doc), Text::lit(""), r.name, cases, crate::syntax::lexer::chars::join(names, Text::lit(", ")), pod);
    auto eq = r.eq
        ? prism_rtl::cat("\ninline bool operator==(const ", r.name, "& a, const ", r.name, "& b) { return a.cases() == b.cases(); }")
        : Text::lit("");
    auto level_defs = r.level
        ? Array(std::vector{crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat("Pod ", r.name, "::level_pod(const Cx& cx) const"), Text::lit("return std::visit([&](const auto& c) { return prism_rtl::level_pod(c.a0, cx); }, cases());")), crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat("void ", r.name, "::level_ports(const Cx& cx, std::vector<prism_rtl::Rc<prism_rtl::Port<Unit>>>& out) const"), Text::lit("std::visit([&](const auto& c) { prism_rtl::level_ports(c.a0, cx, out); }, cases());"))})
        : Array<Text>{};
    auto to_pod_ = crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat("Pod ", r.name, "::to_pod() const"), Text::lit("return std::visit([](const auto& c) { return prism_rtl::to_pod(c.a0); }, cases());"));
    auto show_ = crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat("void ", r.name, "::show(Printer& p) const"), Text::lit("Show<Pod>::show(to_pod(), p);"));
    auto reads = crate::syntax::lexer::chars::join(each(r.cases_, [&](const std::tuple<Text, Text>& _p0) {
        auto&& v_ = std::get<0>(_p0);
        auto&& st = std::get<1>(_p0);
        return prism_rtl::cat("if (*t == ", row_struct(m, st), "::TAG) return ", r.name, "(", v_, "{TRY(prism_rtl::from_pod<", row_struct(m, st), ">(p))});");
    }), Text::lit("\n"));
    auto from_pod_ = r.pod
        ? Array(std::vector{crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat("Result<", r.name, "> ", r.name, "::from_pod(const Pod& p)"), prism_rtl::cat("if (auto t = p.tag()) {\n", indent_cpp(reads), "\n}\nreturn mismatch<", r.name, ">(\"a ", r.name, "\", p);"))})
        : Array<Text>{};
    auto deps = crate::emit::cpp::patterns::concat2(run_to_end(each_job(r.cases_, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Text, Text>)>>(prism_rtl::rc([=](std::tuple<Text, Text> p0) {
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=]() {
            return ({
                auto&& _st = p0;
                auto&& st = std::get<1>(_st);
                (prism_rtl::more(prism_rtl::rc(ValueDeps(cp_1_2, crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{st, Array<crate::lower::model::OutTy>{}})))));
            });
        }));
        });
    })));
    }))));
    return Parts{.forward = Array(std::vector{prism_rtl::cat("class ", r.name, ";")}), .values = Array(std::vector{ValueDecl{.path_ = decl_path(cp, r.name), .deps = deps, .text = prism_rtl::cat(cls, eq)}}), .protos = Array<Text>{}, .classes = Array<Text>{}, .outer = Array<Text>{}, .generic = Array<Text>{}, .defs = append(append(Array(std::vector{to_pod_, show_}), from_pod_), level_defs)};
}


prism_rtl::Turn<Parts> RowParts::cycle() const {
    const auto& cp = this->cp;
    const auto& m = this->m;
    const auto& r = this->r;
    auto names = each(prism_rtl::val(r).cases_, [&](const std::tuple<Text, Text>& _p0) {
        auto&& v_ = std::get<0>(_p0);
        return v_;
    });
    auto levels = prism_rtl::val(r).level
        ? Text::lit("\nPod level_pod(const Cx& cx) const;\nvoid level_ports(const Cx& cx, std::vector<prism_rtl::Rc<prism_rtl::Port<Unit>>>& out) const;")
        : Text::lit("");
    auto pod = prism_rtl::cat("Pod to_pod() const;\nvoid show(Printer& p) const;", prism_rtl::val(r).pod
        ? prism_rtl::cat("\nstatic Result<", prism_rtl::val(r).name, "> from_pod(const Pod& p);")
        : Text::lit(""), levels);
    auto cases = crate::syntax::lexer::chars::join(each(prism_rtl::val(r).cases_, [&](const std::tuple<Text, Text>& _p0) {
        auto&& v_ = std::get<0>(_p0);
        auto&& st = std::get<1>(_p0);
        return crate::emit::cpp::templates::items::case_decl(v_, prism_rtl::cat(row_struct(m, st), " a0;", prism_rtl::val(r).eq
            ? prism_rtl::cat("\nbool operator==(const ", v_, "&) const = default;")
            : Text::lit("")));
    }), Text::lit("\n"));
    auto cls = crate::emit::cpp::templates::items::choice_class(cpp_source_doc(prism_rtl::cat("`", prism_rtl::val(r).prism, "`, a row kind\'s values:"), prism_rtl::val(r).doc), Text::lit(""), prism_rtl::val(r).name, cases, crate::syntax::lexer::chars::join(names, Text::lit(", ")), pod);
    auto eq = prism_rtl::val(r).eq
        ? prism_rtl::cat("\ninline bool operator==(const ", prism_rtl::val(r).name, "& a, const ", prism_rtl::val(r).name, "& b) { return a.cases() == b.cases(); }")
        : Text::lit("");
    auto level_defs = prism_rtl::val(r).level
        ? Array(std::vector{crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat("Pod ", prism_rtl::val(r).name, "::level_pod(const Cx& cx) const"), Text::lit("return std::visit([&](const auto& c) { return prism_rtl::level_pod(c.a0, cx); }, cases());")), crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat("void ", prism_rtl::val(r).name, "::level_ports(const Cx& cx, std::vector<prism_rtl::Rc<prism_rtl::Port<Unit>>>& out) const"), Text::lit("std::visit([&](const auto& c) { prism_rtl::level_ports(c.a0, cx, out); }, cases());"))})
        : Array<Text>{};
    auto to_pod_ = crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat("Pod ", prism_rtl::val(r).name, "::to_pod() const"), Text::lit("return std::visit([](const auto& c) { return prism_rtl::to_pod(c.a0); }, cases());"));
    auto show_ = crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat("void ", prism_rtl::val(r).name, "::show(Printer& p) const"), Text::lit("Show<Pod>::show(to_pod(), p);"));
    auto reads = crate::syntax::lexer::chars::join(each(prism_rtl::val(r).cases_, [&](const std::tuple<Text, Text>& _p0) {
        auto&& v_ = std::get<0>(_p0);
        auto&& st = std::get<1>(_p0);
        return prism_rtl::cat("if (*t == ", row_struct(m, st), "::TAG) return ", prism_rtl::val(r).name, "(", v_, "{TRY(prism_rtl::from_pod<", row_struct(m, st), ">(p))});");
    }), Text::lit("\n"));
    auto from_pod_ = prism_rtl::val(r).pod
        ? Array(std::vector{crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat("Result<", prism_rtl::val(r).name, "> ", prism_rtl::val(r).name, "::from_pod(const Pod& p)"), prism_rtl::cat("if (auto t = p.tag()) {\n", indent_cpp(reads), "\n}\nreturn mismatch<", prism_rtl::val(r).name, ">(\"a ", prism_rtl::val(r).name, "\", p);"))})
        : Array<Text>{};
    auto cp_1 = cp;
    auto r_2 = r;
    return call_value(each_job(prism_rtl::val(r_2).cases_, ({
        auto cp_1_3 = cp_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Text, Text>)>>(prism_rtl::rc([=](std::tuple<Text, Text> p0) {
        return ({
            auto cp_1_3_3 = cp_1_3;
            entered(once_job([=]() {
            return ({
                auto&& _st = p0;
                auto&& st = std::get<1>(_st);
                (prism_rtl::more(prism_rtl::rc(ValueDeps(cp_1_3_3, crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{st, Array<crate::lower::model::OutTy>{}})))));
            });
        }));
        });
    })));
    })), [=](Array<Array<Text>> each_24769) {
        return ({
            auto deps = crate::emit::cpp::patterns::concat2(each_24769);
            (prism_rtl::finished(Parts{.forward = Array(std::vector{prism_rtl::cat("class ", prism_rtl::val(r_2).name, ";")}), .values = Array(std::vector{ValueDecl{.path_ = decl_path(cp_1, prism_rtl::val(r_2).name), .deps = deps, .text = prism_rtl::cat(cls, eq)}}), .protos = Array<Text>{}, .classes = Array<Text>{}, .outer = Array<Text>{}, .generic = Array<Text>{}, .defs = append(append(Array(std::vector{to_pod_, show_}), from_pod_), level_defs)}));
        });
    });
}


/// `Start RowParts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Parts> start_row_parts(crate::emit::cpp::Cp cp, Text m, crate::lower::model::RowDef r) {
    return prism_rtl::make_rc<RowParts>(cp, m, r);
}


/// RowStruct: fn Text, Text -> Text
Text row_struct(const Text& m, const Text& st) {
    return crate::syntax::lexer::chars::contains(st, Text::lit(":")) || (m == Text::lit(""))
        ? crate::emit::cpp::type_path(st)
        : prism_rtl::cat("crate::", m, "::", st);
}


/// AnswerParts: unbounded fn Cp, AnswerDef -> Parts
Parts answer_parts(const crate::emit::cpp::Cp& cp, const crate::lower::model::AnswerDef& a) {
    auto names = each(a.cases_, [&](const crate::lower::model::AnswerCase& c) { return prism_rtl::val(c).variant; });
    auto accessors = crate::syntax::lexer::chars::join(run_to_end(each_job(a.cases_, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::AnswerCase)>>(prism_rtl::rc([=](crate::lower::model::AnswerCase p0) {
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=]() {
            return ({
                auto c = p0;
                call_then(crate::emit::cpp::start_cpp_type(cp_1_2, prism_rtl::val(c).ty), [=](Text cpp_type_25628) { return prism_rtl::finished(prism_rtl::cat("Result<", cpp_type_25628, "> ", prism_rtl::val(c).accessor, "() const;")); });
            });
        }));
        });
    })));
    }))), Text::lit("\n"));
    auto members_ = prism_rtl::cat("const char* tag() const;\n", accessors, "\nstatic Result<Answer> decode(const Elem& e, const Pod& v);");
    auto cases = crate::syntax::lexer::chars::join(run_to_end(each_job(a.cases_, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::AnswerCase)>>(prism_rtl::rc([=](crate::lower::model::AnswerCase p0) {
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=]() {
            return ({
                auto c = p0;
                call_then(crate::emit::cpp::start_cpp_type(cp_1_2, prism_rtl::val(c).ty), [=](Text cpp_type_25858) { return prism_rtl::finished(crate::emit::cpp::templates::items::case_decl(prism_rtl::val(c).variant, prism_rtl::cat(cpp_type_25858, " a0;"))); });
            });
        }));
        });
    })));
    }))), Text::lit("\n"));
    auto cls = crate::emit::cpp::templates::items::choice_class(cpp_doc(Text::lit("`Answer c`: an answer to an element, typed by its tag (Semantics ch. 9): what a host\'s\nsupplier answers a child place with, and what a World\'s answer to a forwarded element\ndecodes to, carrying the tag\'s output.")), Text::lit(""), Text::lit("Answer"), cases, crate::syntax::lexer::chars::join(names, Text::lit(", ")), members_);
    auto tags = crate::syntax::lexer::chars::join(each(a.cases_, [&](const crate::lower::model::AnswerCase& c) { return prism_rtl::cat("if (std::holds_alternative<", prism_rtl::val(c).variant, ">(cases())) return ", crate::emit::cpp::type_path(prism_rtl::val(c).struct_path), "::TAG;"); }), Text::lit("\n"));
    auto tag_fn = crate::emit::cpp::templates::items::cpp_function(Text::lit(""), Text::lit("const char* Answer::tag() const"), prism_rtl::cat(tags, "\nprism_rtl::unreachable();"));
    auto getters = run_to_end(each_job(a.cases_, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::AnswerCase)>>(prism_rtl::rc([=](crate::lower::model::AnswerCase p0) {
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=]() {
            return ({
                auto c = p0;
                call_then(crate::emit::cpp::start_cpp_type(cp_1_2, prism_rtl::val(c).ty), [=](Text cpp_type_26524) { return prism_rtl::finished(crate::emit::cpp::templates::items::cpp_function(cpp_doc(prism_rtl::cat("A `", prism_rtl::val(c).tag_name, "`\'s answer.")), prism_rtl::cat("Result<", cpp_type_26524, "> Answer::", prism_rtl::val(c).accessor, "() const"), prism_rtl::cat("if (auto c = std::get_if<", prism_rtl::val(c).variant, ">(&cases())) return c->a0;\nreturn unexpected(Fault::answer(str(\"an answer for \", tag(), \", where ", prism_rtl::val(c).tag_name, "\'s was expected\")));"))); });
            });
        }));
        });
    })));
    })));
    auto decodes = crate::syntax::lexer::chars::join(run_to_end(each_job(a.cases_, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::AnswerCase)>>(prism_rtl::rc([=](crate::lower::model::AnswerCase p0) {
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=]() {
            return ({
                auto c = p0;
                call_then(crate::emit::cpp::start_cpp_type(cp_1_2, prism_rtl::val(c).ty), [=](Text cpp_type_26872) { return prism_rtl::finished(prism_rtl::cat("if (is<Elem::", prism_rtl::val(c).variant, ">(e)) return Answer(", prism_rtl::val(c).variant, "{TRY(prism_rtl::from_pod<", cpp_type_26872, ">(v))});")); });
            });
        }));
        });
    })));
    }))), Text::lit("\n"));
    auto decode_1 = crate::emit::cpp::templates::items::cpp_function(cpp_doc(Text::lit("A World\'s answer to the element `e`, decoded by its tag.")), Text::lit("Result<Answer> Answer::decode(const Elem& e, const Pod& v)"), prism_rtl::cat(decodes, "\nprism_rtl::unreachable();"));
    return Parts{.forward = Array(std::vector{Text::lit("class Answer;")}), .values = Array(std::vector{ValueDecl{.path_ = Text::lit("Answer"), .deps = Array<Text>{}, .text = cls}}), .protos = Array<Text>{}, .classes = Array<Text>{}, .outer = Array<Text>{}, .generic = Array<Text>{}, .defs = append(Array(std::vector{tag_fn}), crate::prelude::push(getters, decode_1))};
}


prism_rtl::Turn<Parts> AnswerParts::cycle() const {
    const auto& cp = this->cp;
    const auto& a = this->a;
    auto names = each(prism_rtl::val(a).cases_, [&](const crate::lower::model::AnswerCase& c) { return prism_rtl::val(c).variant; });
    auto a_1 = a;
    auto cp_2 = cp;
    return call_value(each_job(prism_rtl::val(a_1).cases_, ({
        auto cp_2_3 = cp_2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::AnswerCase)>>(prism_rtl::rc([=](crate::lower::model::AnswerCase p0) {
        return ({
            auto cp_2_3_3 = cp_2_3;
            entered(once_job([=]() {
            return ({
                auto c = p0;
                call_then(crate::emit::cpp::start_cpp_type(cp_2_3_3, prism_rtl::val(c).ty), [=](Text cpp_type_25628) { return prism_rtl::finished(prism_rtl::cat("Result<", cpp_type_25628, "> ", prism_rtl::val(c).accessor, "() const;")); });
            });
        }));
        });
    })));
    })), [=](Array<Text> each_25600) {
        return ({
            auto accessors = crate::syntax::lexer::chars::join(each_25600, Text::lit("\n"));
            auto members_ = prism_rtl::cat("const char* tag() const;\n", accessors, "\nstatic Result<Answer> decode(const Elem& e, const Pod& v);");
            call_value(each_job(prism_rtl::val(a_1).cases_, ({
            auto cp_2_3 = cp_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::AnswerCase)>>(prism_rtl::rc([=](crate::lower::model::AnswerCase p0) {
            return ({
                auto cp_2_3_3 = cp_2_3;
                entered(once_job([=]() {
                return ({
                    auto c = p0;
                    call_then(crate::emit::cpp::start_cpp_type(cp_2_3_3, prism_rtl::val(c).ty), [=](Text cpp_type_25858) { return prism_rtl::finished(crate::emit::cpp::templates::items::case_decl(prism_rtl::val(c).variant, prism_rtl::cat(cpp_type_25858, " a0;"))); });
                });
            }));
            });
        })));
        })), [=](Array<Text> each_25817) {
            return ({
                auto cases = crate::syntax::lexer::chars::join(each_25817, Text::lit("\n"));
                auto cls = crate::emit::cpp::templates::items::choice_class(cpp_doc(Text::lit("`Answer c`: an answer to an element, typed by its tag (Semantics ch. 9): what a host\'s\nsupplier answers a child place with, and what a World\'s answer to a forwarded element\ndecodes to, carrying the tag\'s output.")), Text::lit(""), Text::lit("Answer"), cases, crate::syntax::lexer::chars::join(names, Text::lit(", ")), members_);
                auto tags = crate::syntax::lexer::chars::join(each(prism_rtl::val(a_1).cases_, [&](const crate::lower::model::AnswerCase& c) { return prism_rtl::cat("if (std::holds_alternative<", prism_rtl::val(c).variant, ">(cases())) return ", crate::emit::cpp::type_path(prism_rtl::val(c).struct_path), "::TAG;"); }), Text::lit("\n"));
                auto tag_fn = crate::emit::cpp::templates::items::cpp_function(Text::lit(""), Text::lit("const char* Answer::tag() const"), prism_rtl::cat(tags, "\nprism_rtl::unreachable();"));
                call_value(each_job(prism_rtl::val(a_1).cases_, ({
                auto cp_2_3 = cp_2;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::AnswerCase)>>(prism_rtl::rc([=](crate::lower::model::AnswerCase p0) {
                return ({
                    auto cp_2_3_3 = cp_2_3;
                    entered(once_job([=]() {
                    return ({
                        auto c = p0;
                        call_then(crate::emit::cpp::start_cpp_type(cp_2_3_3, prism_rtl::val(c).ty), [=](Text cpp_type_26524) { return prism_rtl::finished(crate::emit::cpp::templates::items::cpp_function(cpp_doc(prism_rtl::cat("A `", prism_rtl::val(c).tag_name, "`\'s answer.")), prism_rtl::cat("Result<", cpp_type_26524, "> Answer::", prism_rtl::val(c).accessor, "() const"), prism_rtl::cat("if (auto c = std::get_if<", prism_rtl::val(c).variant, ">(&cases())) return c->a0;\nreturn unexpected(Fault::answer(str(\"an answer for \", tag(), \", where ", prism_rtl::val(c).tag_name, "\'s was expected\")));"))); });
                    });
                }));
                });
            })));
            })), [=](Array<Text> each_26446) {
                return ({
                    auto getters = each_26446;
                    call_value(each_job(prism_rtl::val(a_1).cases_, ({
                    auto cp_2_3 = cp_2;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::AnswerCase)>>(prism_rtl::rc([=](crate::lower::model::AnswerCase p0) {
                    return ({
                        auto cp_2_3_3 = cp_2_3;
                        entered(once_job([=]() {
                        return ({
                            auto c = p0;
                            call_then(crate::emit::cpp::start_cpp_type(cp_2_3_3, prism_rtl::val(c).ty), [=](Text cpp_type_26872) { return prism_rtl::finished(prism_rtl::cat("if (is<Elem::", prism_rtl::val(c).variant, ">(e)) return Answer(", prism_rtl::val(c).variant, "{TRY(prism_rtl::from_pod<", cpp_type_26872, ">(v))});")); });
                        });
                    }));
                    });
                })));
                })), [=](Array<Text> each_26770) {
                    return ({
                        auto decodes = crate::syntax::lexer::chars::join(each_26770, Text::lit("\n"));
                        auto decode_3 = crate::emit::cpp::templates::items::cpp_function(cpp_doc(Text::lit("A World\'s answer to the element `e`, decoded by its tag.")), Text::lit("Result<Answer> Answer::decode(const Elem& e, const Pod& v)"), prism_rtl::cat(decodes, "\nprism_rtl::unreachable();"));
                        (prism_rtl::finished(Parts{.forward = Array(std::vector{Text::lit("class Answer;")}), .values = Array(std::vector{ValueDecl{.path_ = Text::lit("Answer"), .deps = Array<Text>{}, .text = cls}}), .protos = Array<Text>{}, .classes = Array<Text>{}, .outer = Array<Text>{}, .generic = Array<Text>{}, .defs = append(Array(std::vector{tag_fn}), crate::prelude::push(getters, decode_3))}));
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start AnswerParts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Parts> start_answer_parts(crate::emit::cpp::Cp cp, crate::lower::model::AnswerDef a) {
    return prism_rtl::make_rc<AnswerParts>(cp, a);
}


/// JobParts: unbounded fn Cp, JobDef -> Parts
Parts job_parts(const crate::emit::cpp::Cp& cp, const crate::lower::model::JobDef& j) {
    auto gens = cpp_template_head(generic_names_of(j.generics));
    auto head = head_of(j.name, generic_names_of(j.generics));
    auto jcp = crate::emit::cpp::with_fields(cp, j.fields);
    auto fields = crate::syntax::lexer::chars::join(run_to_end(each_job(j.fields, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=]() {
            return ({
                auto [n, t] = p0;
                call_then(crate::emit::cpp::start_cpp_type(cp_1_2, t), [=](Text cpp_type_27638) { return prism_rtl::finished(prism_rtl::cat(cpp_type_27638, " ", crate::emit::cpp::field_id(n), ";")); });
            });
        }));
        });
    })));
    }))), Text::lit("\n"));
    auto params = crate::syntax::lexer::chars::join(run_to_end(each_job(j.fields, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=]() {
            return ({
                auto [n, t] = p0;
                call_then(crate::emit::cpp::start_cpp_type(cp_1_2, t), [=](Text cpp_type_27726) { return prism_rtl::finished(prism_rtl::cat(cpp_type_27726, " ", crate::emit::cpp::field_id(n))); });
            });
        }));
        });
    })));
    }))), Text::lit(", "));
    auto inits = crate::syntax::lexer::chars::join(each(j.fields, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
        auto&& n = std::get<0>(_p0);
        return prism_rtl::cat(crate::emit::cpp::field_id(n), "(std::move(", crate::emit::cpp::field_id(n), "))");
    }), Text::lit(", "));
    auto ctor = len(j.fields) == Nat(0u)
        ? Text::lit("")
        : prism_rtl::cat(j.name, "(", params, ") : ", inits, " {}");
    auto ret = crate::emit::cpp::cpp_type(cp, j.ret);
    auto decl = crate::emit::cpp::templates::items::job_struct(cpp_doc(j.doc), gens, j.name, ret, fields, ctor);
    auto cycle_1 = crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat(gens, "prism_rtl::Turn<", ret, "> ", head, "::cycle() const"), crate::emit::cpp::stmts::cpp_body(jcp, j.body));
    auto start = crate::emit::cpp::templates::items::cpp_function(cpp_doc(prism_rtl::cat("`Start ", j.name, ", x`: what the function value is when passed to `@Run`.")), prism_rtl::cat(gens, "prism_rtl::JobRef<", ret, "> ", j.start, "(", params, ")"), prism_rtl::cat("return prism_rtl::make_rc<", head, ">(", crate::syntax::lexer::chars::join(each(j.fields, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
        auto&& n = std::get<0>(_p0);
        return crate::emit::cpp::field_id(n);
    }), Text::lit(", ")), ");"));
    auto generic = len(j.generics) > Nat(0u);
    return Parts{.forward = Array(std::vector{prism_rtl::cat(gens, "struct ", j.name, ";")}), .values = Array<ValueDecl>{}, .protos = Array(std::vector{prism_rtl::cat(gens, "prism_rtl::JobRef<", ret, "> ", j.start, "(", params, ");")}), .classes = Array(std::vector{decl}), .outer = Array<Text>{}, .generic = generic ? Array(std::vector{cycle_1, start}) : Array<Text>{}, .defs = generic ? Array<Text>{} : Array(std::vector{cycle_1, start})};
}


prism_rtl::Turn<Parts> JobParts::cycle() const {
    const auto& cp = this->cp;
    const auto& j = this->j;
    auto gens = cpp_template_head(generic_names_of(prism_rtl::val(j).generics));
    auto head = head_of(prism_rtl::val(j).name, generic_names_of(prism_rtl::val(j).generics));
    auto jcp = crate::emit::cpp::with_fields(cp, prism_rtl::val(j).fields);
    auto cp_1 = cp;
    auto j_2 = j;
    return call_value(each_job(prism_rtl::val(j_2).fields, ({
        auto cp_1_3 = cp_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
        return ({
            auto cp_1_3_3 = cp_1_3;
            entered(once_job([=]() {
            return ({
                auto [n, t] = p0;
                call_then(crate::emit::cpp::start_cpp_type(cp_1_3_3, t), [=](Text cpp_type_27638) { return prism_rtl::finished(prism_rtl::cat(cpp_type_27638, " ", crate::emit::cpp::field_id(n), ";")); });
            });
        }));
        });
    })));
    })), [=](Array<Text> each_27609) {
        return ({
            auto fields = crate::syntax::lexer::chars::join(each_27609, Text::lit("\n"));
            call_value(each_job(prism_rtl::val(j_2).fields, ({
            auto cp_1_3 = cp_1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
            return ({
                auto cp_1_3_3 = cp_1_3;
                entered(once_job([=]() {
                return ({
                    auto [n, t] = p0;
                    call_then(crate::emit::cpp::start_cpp_type(cp_1_3_3, t), [=](Text cpp_type_27726) { return prism_rtl::finished(prism_rtl::cat(cpp_type_27726, " ", crate::emit::cpp::field_id(n))); });
                });
            }));
            });
        })));
        })), [=](Array<Text> each_27697) {
            return ({
                auto params = crate::syntax::lexer::chars::join(each_27697, Text::lit(", "));
                auto inits = crate::syntax::lexer::chars::join(each(prism_rtl::val(j_2).fields, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
                    auto&& n = std::get<0>(_p0);
                    return prism_rtl::cat(crate::emit::cpp::field_id(n), "(std::move(", crate::emit::cpp::field_id(n), "))");
                }), Text::lit(", "));
                auto ctor = len(prism_rtl::val(j_2).fields) == Nat(0u)
                    ? Text::lit("")
                    : prism_rtl::cat(prism_rtl::val(j_2).name, "(", params, ") : ", inits, " {}");
                call_then(crate::emit::cpp::start_cpp_type(cp_1, prism_rtl::val(j_2).ret), [=](Text cpp_type_27958) {
                return ({
                    auto ret = cpp_type_27958;
                    auto decl = crate::emit::cpp::templates::items::job_struct(cpp_doc(prism_rtl::val(j_2).doc), gens, prism_rtl::val(j_2).name, ret, fields, ctor);
                    call_then(crate::emit::cpp::stmts::start_cpp_body(jcp, prism_rtl::val(j_2).body), [=](Text cpp_body_28136) {
                    return ({
                        auto cycle_3 = crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat(gens, "prism_rtl::Turn<", ret, "> ", head, "::cycle() const"), cpp_body_28136);
                        auto start = crate::emit::cpp::templates::items::cpp_function(cpp_doc(prism_rtl::cat("`Start ", prism_rtl::val(j_2).name, ", x`: what the function value is when passed to `@Run`.")), prism_rtl::cat(gens, "prism_rtl::JobRef<", ret, "> ", prism_rtl::val(j_2).start, "(", params, ")"), prism_rtl::cat("return prism_rtl::make_rc<", head, ">(", crate::syntax::lexer::chars::join(each(prism_rtl::val(j_2).fields, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
                            auto&& n = std::get<0>(_p0);
                            return crate::emit::cpp::field_id(n);
                        }), Text::lit(", ")), ");"));
                        auto generic = len(prism_rtl::val(j_2).generics) > Nat(0u);
                        (prism_rtl::finished(Parts{.forward = Array(std::vector{prism_rtl::cat(gens, "struct ", prism_rtl::val(j_2).name, ";")}), .values = Array<ValueDecl>{}, .protos = Array(std::vector{prism_rtl::cat(gens, "prism_rtl::JobRef<", ret, "> ", prism_rtl::val(j_2).start, "(", params, ");")}), .classes = Array(std::vector{decl}), .outer = Array<Text>{}, .generic = generic ? Array(std::vector{cycle_3, start}) : Array<Text>{}, .defs = generic ? Array<Text>{} : Array(std::vector{cycle_3, start})}));
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start JobParts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Parts> start_job_parts(crate::emit::cpp::Cp cp, crate::lower::model::JobDef j) {
    return prism_rtl::make_rc<JobParts>(cp, j);
}


/// TraitParts: unbounded fn Cp, TraitDef -> Parts
Parts trait_parts(const crate::emit::cpp::Cp& cp, const crate::lower::model::TraitDef& t) {
    auto defaults = filter(t.methods, [&](const crate::lower::model::FnDef& f) { return prism_rtl::val(f).public_; });
    auto defs = run_to_end(each_job(defaults, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::FnDef)>>(prism_rtl::rc([=](crate::lower::model::FnDef p0) {
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=]() {
            return ({
                auto f = p0;
                (prism_rtl::more(prism_rtl::rc(FnDefinition(cp_1_2, with_generics(f, Array(std::vector{std::tuple{Text::lit("Self"), Array<Text>{}}}))))));
            });
        }));
        });
    })));
    })));
    auto protos = run_to_end(each_job(t.methods, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::FnDef)>>(prism_rtl::rc([=](crate::lower::model::FnDef p0) {
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=]() {
            return ({
                auto f = p0;
                call_then(start_fn_signature(cp_1_2, with_generics(f, Array(std::vector{std::tuple{Text::lit("Self"), Array<Text>{}}}))), [=](Text fn_signature_29376) { return prism_rtl::finished(prism_rtl::cat(fn_signature_29376, prism_rtl::val(f).public_ ? Text::lit("") : Text::lit(" = delete"), ";")); });
            });
        }));
        });
    })));
    })));
    auto generic = len(defaults) == Nat(0u)
        ? Array<Text>{}
        : Array(std::vector{crate::emit::cpp::templates::items::trait_namespace(t.name, crate::syntax::lexer::chars::join(defs, Text::lit("\n")))});
    Parts this_ = generic_only(generic);
    this_.protos = Array(std::vector{crate::emit::cpp::templates::items::trait_namespace(t.name, crate::syntax::lexer::chars::join(protos, Text::lit("\n")))});
    return this_;
}


prism_rtl::Turn<Parts> TraitParts::cycle() const {
    const auto& cp = this->cp;
    const auto& t = this->t;
    auto defaults = filter(prism_rtl::val(t).methods, [&](const crate::lower::model::FnDef& f) { return prism_rtl::val(f).public_; });
    auto cp_1 = cp;
    auto t_2 = t;
    return call_value(each_job(defaults, ({
        auto cp_1_3 = cp_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::FnDef)>>(prism_rtl::rc([=](crate::lower::model::FnDef p0) {
        return ({
            auto cp_1_3_3 = cp_1_3;
            entered(once_job([=]() {
            return ({
                auto f = p0;
                (prism_rtl::more(prism_rtl::rc(FnDefinition(cp_1_3_3, with_generics(f, Array(std::vector{std::tuple{Text::lit("Self"), Array<Text>{}}}))))));
            });
        }));
        });
    })));
    })), [=](Array<Text> each_29260) {
        return ({
            auto defs = each_29260;
            call_value(each_job(prism_rtl::val(t_2).methods, ({
            auto cp_1_3 = cp_1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::FnDef)>>(prism_rtl::rc([=](crate::lower::model::FnDef p0) {
            return ({
                auto cp_1_3_3 = cp_1_3;
                entered(once_job([=]() {
                return ({
                    auto f = p0;
                    call_then(start_fn_signature(cp_1_3_3, with_generics(f, Array(std::vector{std::tuple{Text::lit("Self"), Array<Text>{}}}))), [=](Text fn_signature_29376) { return prism_rtl::finished(prism_rtl::cat(fn_signature_29376, prism_rtl::val(f).public_ ? Text::lit("") : Text::lit(" = delete"), ";")); });
                });
            }));
            });
        })));
        })), [=](Array<Text> each_29353) {
            return ({
                auto protos = each_29353;
                auto generic = len(defaults) == Nat(0u)
                    ? Array<Text>{}
                    : Array(std::vector{crate::emit::cpp::templates::items::trait_namespace(prism_rtl::val(t_2).name, crate::syntax::lexer::chars::join(defs, Text::lit("\n")))});
                (prism_rtl::finished(({
                Parts this_ = generic_only(generic);
                this_.protos = Array(std::vector{crate::emit::cpp::templates::items::trait_namespace(prism_rtl::val(t_2).name, crate::syntax::lexer::chars::join(protos, Text::lit("\n")))});
                this_;
            })));
            });
        });
        });
    });
}


/// `Start TraitParts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Parts> start_trait_parts(crate::emit::cpp::Cp cp, crate::lower::model::TraitDef t) {
    return prism_rtl::make_rc<TraitParts>(cp, t);
}


/// ImplParts: unbounded fn Cp, ImplDef -> Parts
Parts impl_parts(const crate::emit::cpp::Cp& cp, const crate::lower::model::ImplDef& i) {
    auto head = crate::emit::cpp::cpp_type(cp, i.head);
    auto gens = cpp_template_head(generic_names_of(i.generics));
    auto fns = run_to_end(each_job(i.methods, ({
        auto cp_1 = cp;
        auto i_2 = i;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Parts>(crate::lower::model::FnDef)>>(prism_rtl::rc([=](crate::lower::model::FnDef p0) {
        return ({
            auto cp_1_3 = cp_1;
            auto i_2_3 = i_2;
            entered(once_job([=]() {
            return ({
                auto f = p0;
                (prism_rtl::more(prism_rtl::rc(FnParts(cp_1_3, with_generics(f, i_2_3.generics)))));
            });
        }));
        });
    })));
    })));
    auto own = fold(fns, no_parts(), [&](const Parts& acc, const Parts& p_) { return join_parts(acc, p_); });
    auto&& _m = i.cls;
    {
        auto&& m30363_0 = _m;
        if (m30363_0 == Text::lit("Prelude.Show")) {
            auto shown = or_(index(each(i.methods, [&](const crate::lower::model::FnDef& f) { return prism_rtl::val(f).name; }), Nat(0u)), Text::lit("show"));
            return join_parts(own, protos_defs(Array<Text>{}, Array(std::vector{crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat(gens, "void ", head, "::show(Printer& p) const"), prism_rtl::cat("p.raw(", shown, "(*this).to_string());"))})));
        }
    }
    {
        auto&& m30363_1 = _m;
        if (m30363_1 == Text::lit("Prelude.Eq")) {
            auto eq = fold(i.methods, Text::lit(""), [&](const Text& acc, const crate::lower::model::FnDef& f) {
                return (!crate::syntax::lexer::chars::has_prefix(prism_rtl::val(f).name, Text::lit("ne"))) && (acc == Text::lit(""))
                    ? prism_rtl::val(f).name
                    : acc;
            });
            return join_parts(own, protos_defs(Array(std::vector{prism_rtl::cat(gens, "bool operator==(const ", head, "& a, const ", head, "& b);")}), Array(std::vector{crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat(gens, "bool operator==(const ", head, "& a, const ", head, "& b)"), prism_rtl::cat("return ", eq, "(a, b);"))})));
        }
    }
    {
        auto tr = crate::syntax::lexer::chars::drop_prefix(crate::emit::cpp::type_path(i.tr), Text::lit("crate::"));
        auto own = !crate::syntax::lexer::chars::contains(tr, Text::lit("::"));
        auto ns = own
            ? tr
            : prism_rtl::cat("impl_", crate::syntax::lexer::chars::join(split_on(tr, Text::lit("::")), Text::lit("_")));
        auto in_trait = run_to_end(each_job(i.methods, ({
            auto ns_1 = ns;
            auto cp_2 = cp;
            auto i_3 = i;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::FnDef)>>(prism_rtl::rc([=](crate::lower::model::FnDef p0) {
            return ({
                auto ns_1_4 = ns_1;
                auto cp_2_4 = cp_2;
                auto i_3_4 = i_3;
                entered(once_job([=]() {
                return ({
                    auto f = p0;
                    call_then(start_fn_definition(cp_2_4, with_generics(f, i_3_4.generics)), [=](Text fn_definition_31230) { return prism_rtl::finished(crate::emit::cpp::templates::items::trait_namespace(ns_1_4, fn_definition_31230)); });
                });
            }));
            });
        })));
        })));
        auto protos = run_to_end(each_job(i.methods, ({
            auto ns_1 = ns;
            auto cp_2 = cp;
            auto i_3 = i;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::FnDef)>>(prism_rtl::rc([=](crate::lower::model::FnDef p0) {
            return ({
                auto ns_1_4 = ns_1;
                auto cp_2_4 = cp_2;
                auto i_3_4 = i_3;
                entered(once_job([=]() {
                return ({
                    auto f = p0;
                    call_then(start_fn_signature(cp_2_4, with_generics(f, i_3_4.generics)), [=](Text fn_signature_31344) { return prism_rtl::finished(crate::emit::cpp::templates::items::trait_namespace(ns_1_4, prism_rtl::cat(fn_signature_31344, ";"))); });
                });
            }));
            });
        })));
        })));
        auto outer = own
            ? Array<Text>{}
            : Array(std::vector{crate::emit::cpp::templates::items::trait_namespace(tr, crate::syntax::lexer::chars::join(each(i.methods, [&](const crate::lower::model::FnDef& f) { return prism_rtl::cat("using ::crate::", cp.home, "::", ns, "::", crate::emit::cpp::cpp_id(prism_rtl::val(f).name), ";"); }), Text::lit("\n")))});
        Parts this_ = protos_defs(protos, in_trait);
        this_.outer = outer;
        return this_;
    }
}


prism_rtl::Turn<Parts> ImplParts::cycle() const {
    const auto& cp = this->cp;
    const auto& i = this->i;
    auto cp_1 = cp;
    auto i_2 = i;
    return call_then(crate::emit::cpp::start_cpp_type(cp_1, prism_rtl::val(i_2).head), [=](Text cpp_type_30145) {
        return ({
            auto head = cpp_type_30145;
            auto gens = cpp_template_head(generic_names_of(prism_rtl::val(i_2).generics));
            call_value(each_job(prism_rtl::val(i_2).methods, ({
            auto cp_1_3 = cp_1;
            auto i_2_3 = i_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Parts>(crate::lower::model::FnDef)>>(prism_rtl::rc([=](crate::lower::model::FnDef p0) {
            return ({
                auto cp_1_3_3 = cp_1_3;
                auto i_2_3_3 = i_2_3;
                entered(once_job([=]() {
                return ({
                    auto f = p0;
                    (prism_rtl::more(prism_rtl::rc(FnParts(cp_1_3_3, with_generics(f, prism_rtl::val(i_2_3_3).generics)))));
                });
            }));
            });
        })));
        })), [=](Array<Parts> each_30237) {
            return ({
                auto fns = each_30237;
                auto own = fold(fns, no_parts(), [&](const Parts& acc, const Parts& p_) { return join_parts(acc, p_); });
                ({
                auto&& _m = prism_rtl::val(i_2).cls;
                ({
                auto&& m30363_0 = _m;
                (m30363_0 == Text::lit("Prelude.Show"));
            }) ? ({
                auto&& m30363_0 = _m;
                ({
                auto shown = or_(index(each(prism_rtl::val(i_2).methods, [&](const crate::lower::model::FnDef& f) { return prism_rtl::val(f).name; }), Nat(0u)), Text::lit("show"));
                (prism_rtl::finished(join_parts(own, protos_defs(Array<Text>{}, Array(std::vector{crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat(gens, "void ", head, "::show(Printer& p) const"), prism_rtl::cat("p.raw(", shown, "(*this).to_string());"))})))));
            });
            })
                : ({
                auto&& m30363_1 = _m;
                (m30363_1 == Text::lit("Prelude.Eq"));
            }) ? ({
                auto&& m30363_1 = _m;
                ({
                auto eq = fold(prism_rtl::val(i_2).methods, Text::lit(""), [&](const Text& acc, const crate::lower::model::FnDef& f) {
                    return (!crate::syntax::lexer::chars::has_prefix(prism_rtl::val(f).name, Text::lit("ne"))) && (acc == Text::lit(""))
                        ? prism_rtl::val(f).name
                        : acc;
                });
                (prism_rtl::finished(join_parts(own, protos_defs(Array(std::vector{prism_rtl::cat(gens, "bool operator==(const ", head, "& a, const ", head, "& b);")}), Array(std::vector{crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat(gens, "bool operator==(const ", head, "& a, const ", head, "& b)"), prism_rtl::cat("return ", eq, "(a, b);"))})))));
            });
            })
                : ({
                auto tr = crate::syntax::lexer::chars::drop_prefix(crate::emit::cpp::type_path(prism_rtl::val(i_2).tr), Text::lit("crate::"));
                auto own = !crate::syntax::lexer::chars::contains(tr, Text::lit("::"));
                auto ns = own
                    ? tr
                    : prism_rtl::cat("impl_", crate::syntax::lexer::chars::join(split_on(tr, Text::lit("::")), Text::lit("_")));
                call_value(each_job(prism_rtl::val(i_2).methods, ({
                auto ns_3 = ns;
                auto cp_1_4 = cp_1;
                auto i_2_4 = i_2;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::FnDef)>>(prism_rtl::rc([=](crate::lower::model::FnDef p0) {
                return ({
                    auto ns_3_4 = ns_3;
                    auto cp_1_4_4 = cp_1_4;
                    auto i_2_4_4 = i_2_4;
                    entered(once_job([=]() {
                    return ({
                        auto f = p0;
                        call_then(start_fn_definition(cp_1_4_4, with_generics(f, prism_rtl::val(i_2_4_4).generics)), [=](Text fn_definition_31230) { return prism_rtl::finished(crate::emit::cpp::templates::items::trait_namespace(ns_3_4, fn_definition_31230)); });
                    });
                }));
                });
            })));
            })), [=](Array<Text> each_31189) {
                return ({
                    auto in_trait = each_31189;
                    call_value(each_job(prism_rtl::val(i_2).methods, ({
                    auto ns_3 = ns;
                    auto cp_1_4 = cp_1;
                    auto i_2_4 = i_2;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::FnDef)>>(prism_rtl::rc([=](crate::lower::model::FnDef p0) {
                    return ({
                        auto ns_3_4 = ns_3;
                        auto cp_1_4_4 = cp_1_4;
                        auto i_2_4_4 = i_2_4;
                        entered(once_job([=]() {
                        return ({
                            auto f = p0;
                            call_then(start_fn_signature(cp_1_4_4, with_generics(f, prism_rtl::val(i_2_4_4).generics)), [=](Text fn_signature_31344) { return prism_rtl::finished(crate::emit::cpp::templates::items::trait_namespace(ns_3_4, prism_rtl::cat(fn_signature_31344, ";"))); });
                        });
                    }));
                    });
                })));
                })), [=](Array<Text> each_31302) {
                    return ({
                        auto protos = each_31302;
                        auto outer = own
                            ? Array<Text>{}
                            : Array(std::vector{crate::emit::cpp::templates::items::trait_namespace(tr, crate::syntax::lexer::chars::join(each(prism_rtl::val(i_2).methods, [&](const crate::lower::model::FnDef& f) { return prism_rtl::cat("using ::crate::", prism_rtl::val(cp_1).home, "::", ns, "::", crate::emit::cpp::cpp_id(prism_rtl::val(f).name), ";"); }), Text::lit("\n")))});
                        (prism_rtl::finished(({
                        Parts this_ = protos_defs(protos, in_trait);
                        this_.outer = outer;
                        this_;
                    })));
                    });
                });
                });
            });
            });
            });
            });
        });
        });
    });
}


/// `Start ImplParts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Parts> start_impl_parts(crate::emit::cpp::Cp cp, crate::lower::model::ImplDef i) {
    return prism_rtl::make_rc<ImplParts>(cp, i);
}


/// WithGenerics: fn FnDef, [((Text, [Text]))] -> FnDef
crate::lower::model::FnDef with_generics(const crate::lower::model::FnDef& f, const Array<std::tuple<Text, Array<Text>>>& gs) {
    crate::lower::model::FnDef this_ = f;
    this_.generics = append(gs, this_.generics);
    return this_;
}


/// GenericOnly: fn [Text] -> Parts
Parts generic_only(const Array<Text>& xs) {
    Parts this_ = no_parts();
    this_.generic = xs;
    return this_;
}


/// ProtosDefs: fn [Text], [Text] -> Parts
Parts protos_defs(const Array<Text>& ps, const Array<Text>& ds) {
    Parts this_ = no_parts();
    this_.protos = ps;
    this_.defs = ds;
    return this_;
}

}  // namespace crate::emit::cpp::items
