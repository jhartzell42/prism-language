// The modules `Check.Types.Unify`, `Checking`, `Compile`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <check/types/unify/module.hpp>
#include <check/types/module.hpp>
#include <syntax/module.hpp>
#include <check/errors/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <checking/module.hpp>
#include <reading/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <compile/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Check.Types.Unify`, from `target/bootstrap/cpp-src/prismc/check/types/unify.prism`.
namespace crate::check::types::unify {

void FieldQ::show(Printer& p) const {
    p.record("FieldQ", {{"recv", recv_p}, {"field", field_p}, {"result", result_p}, {"span", span_p}, {"file", file_p}, {"owners", owners_p}, {"marks", marks_o}});
}

Pod FieldQ::to_pod() const {
    return Pod::record("FieldQ", {{"recv", prism_rtl::to_pod(recv_p)}, {"field", prism_rtl::to_pod(field_p)}, {"result", prism_rtl::to_pod(result_p)}, {"span", prism_rtl::to_pod(span_p)}, {"file", prism_rtl::to_pod(file_p)}, {"owners", prism_rtl::to_pod(owners_p)}, {"marks", prism_rtl::to_pod(marks_o)}});
}

Result<FieldQ> FieldQ::from_pod(const Pod& whole) {
    return FieldQ{.recv_p = TRY(prism_rtl::from_pod<crate::check::types::Ty>(TRY(crate::prelude::field(whole, "recv")))), .field_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "field")))), .result_p = TRY(prism_rtl::from_pod<crate::check::types::Ty>(TRY(crate::prelude::field(whole, "result")))), .span_p = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span")))), .file_p = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "file")))), .owners_p = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "owners")))), .marks_o = TRY(prism_rtl::from_pod<std::optional<std::tuple<Text, crate::syntax::Range>>>(TRY(crate::prelude::field(whole, "marks"))))};
}


/// Unify: unbounded fn St, Ty, Ty, Range -> St
crate::check::types::St unify_f(const crate::check::types::St& st_p0, const crate::check::types::Ty& expected_p1, const crate::check::types::Ty& found_p2, const crate::syntax::Range& span_p3) {
    auto [verdict_p4, st2_p5] = unify_in_f(st_p0, expected_p1, found_p2, span_p3);
    return verdict_p4 == Text::lit("mismatch")
        ? ({
        auto e_p6 = crate::check::types::show_ty_f(st2_p5, expected_p1);
        auto f_p7 = crate::check::types::show_ty_f(st2_p5, found_p2);
        e_p6 == f_p7
        ? crate::check::types::recording::err_f(st2_p5, Text::lit("mismatch"), span_p3, prism_rtl::cat("expected `", show_ty_q_f(st2_p5, expected_p1), "`, found `", show_ty_q_f(st2_p5, found_p2), "`"))
        : crate::check::types::recording::err_f(st2_p5, Text::lit("mismatch"), span_p3, prism_rtl::cat("expected `", e_p6, "`, found `", f_p7, "`"));
    })
        : st2_p5;
}


prism_rtl::Turn<crate::check::types::St> Unify::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& expected_p1 = this->expected_p1;
    const auto& found_p2 = this->found_p2;
    const auto& span_p3 = this->span_p3;
    auto expected_p1x = expected_p1;
    auto found_p2x = found_p2;
    auto span_p3x = span_p3;
    auto st_p0x = st_p0;
    return crate::prelude::call_then(start_unify_in_f(st_p0x, expected_p1x, found_p2x, span_p3x), [=](std::tuple<Text, crate::check::types::St> unify_in_f_1030) {
        return ({
            auto [verdict_p4, st2_p5] = unify_in_f_1030;
            verdict_p4 == Text::lit("mismatch")
            ? crate::prelude::call_then(crate::check::types::start_show_ty_f(st2_p5, expected_p1x), [=](Text show_ty_f_1110) {
            return ({
                auto e_p6 = show_ty_f_1110;
                (crate::prelude::call_then(crate::check::types::start_show_ty_f(st2_p5, found_p2x), [=, e_p6 = std::move(e_p6)](Text show_ty_f_1147) {
                return ({
                    auto f_p7 = show_ty_f_1147;
                    e_p6 == f_p7
                    ? crate::prelude::call_then(start_show_ty_q_f(st2_p5, expected_p1x), [=](Text show_ty_q_f_1223) { return crate::prelude::call_then(start_show_ty_q_f(st2_p5, found_p2x), [=](Text show_ty_q_f_1256) { return prism_rtl::finished(crate::check::types::recording::err_f(st2_p5, Text::lit("mismatch"), span_p3x, prism_rtl::cat("expected `", show_ty_q_f_1223, "`, found `", show_ty_q_f_1256, "`"))); }); })
                    : prism_rtl::finished(crate::check::types::recording::err_f(st2_p5, Text::lit("mismatch"), span_p3x, prism_rtl::cat("expected `", e_p6, "`, found `", f_p7, "`")));
                });
            }));
            });
        })
            : prism_rtl::finished(st2_p5);
        });
    });
}


/// `Start Unify, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_unify_f(crate::check::types::St st_p0, crate::check::types::Ty expected_p1, crate::check::types::Ty found_p2, crate::syntax::Range span_p3) {
    return prism_rtl::make_rc<Unify>(st_p0, expected_p1, found_p2, span_p3);
}


/// ShowTyQ: unbounded fn St, Ty -> Text
Text show_ty_q_f(const crate::check::types::St& st_p0, const crate::check::types::Ty& t_p1) {
    auto&& _m = crate::check::types::recording::zonk_f(st_p0, t_p1);
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
        auto&& n_p2 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
        auto&& m1487_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a1;
        if (m1487_0_1.size() == 0u) {
            return n_p2;
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
        auto&& n_p3 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
        auto&& args_p4 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a1;
        return prism_rtl::cat("(", n_p3, crate::prelude::concat(crate::prelude::run_to_end(crate::prelude::each_job(args_p4, ({
            auto st_p0x = st_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::check::types::Ty)>>(prism_rtl::rc([=, st_p0x = std::move(st_p0x)](crate::check::types::Ty p0) {
            return ({
                auto st_p0xy = st_p0x;
                (crate::prelude::entered(crate::prelude::once_job([=, st_p0xy = std::move(st_p0xy)]() {
                return ({
                    auto a_p5 = p0;
                    (crate::prelude::call_then(start_show_ty_q_f(st_p0xy, a_p5), [=](Text show_ty_q_f_1578) { return prism_rtl::finished(prism_rtl::cat(" ", show_ty_q_f_1578)); }));
                });
            })));
            });
        })));
        })))), ")");
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(_m)) {
        auto&& s_p6 = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a0;
        auto&& i_p7 = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a1;
        return prism_rtl::cat(s_p6, show_ty_q_f(st_p0, prism_rtl::deref(i_p7)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(_m)) {
        auto&& e_p8 = prism_rtl::as<crate::check::types::Ty::TyArray>(_m).a0;
        auto inner_p9 = show_ty_q_f(st_p0, prism_rtl::deref(e_p8));
        return crate::syntax::lexer::chars::has_prefix_f(inner_p9, Text::lit("["))
            ? prism_rtl::cat("[ ", inner_p9, " ]")
            : prism_rtl::cat("[", inner_p9, "]");
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(_m)) {
        auto&& k_pa = prism_rtl::as<crate::check::types::Ty::TyMap>(_m).a0;
        auto&& v_pb = prism_rtl::as<crate::check::types::Ty::TyMap>(_m).a1;
        return prism_rtl::cat("(", show_ty_q_f(st_p0, prism_rtl::deref(k_pa)), " ==> ", show_ty_q_f(st_p0, prism_rtl::deref(v_pb)), ")");
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(_m)) {
        auto&& i_pc = prism_rtl::as<crate::check::types::Ty::TyAt>(_m).a0;
        auto&& rw_pd = prism_rtl::as<crate::check::types::Ty::TyAt>(_m).a1;
        return prism_rtl::cat("@", show_ty_q_f(st_p0, prism_rtl::deref(i_pc)), " emit ", crate::check::types::show_row_in_f(rw_pd, true));
    }
    {
        auto&& other_pe = _m;
        return crate::check::types::show_ty_f(st_p0, other_pe);
    }
}


prism_rtl::Turn<Text> ShowTyQ::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& t_p1 = this->t_p1;
    auto st_p0x = st_p0;
    auto t_p1x = t_p1;
    return crate::prelude::call_then(crate::check::types::recording::start_zonk_f(st_p0x, t_p1x), [=](crate::check::types::Ty zonk_f_1493) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TyCon>(zonk_f_1493) && ({
            auto&& n_p2 = prism_rtl::as<crate::check::types::Ty::TyCon>(zonk_f_1493).a0;
            auto&& m1487_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(zonk_f_1493).a1;
            (m1487_0_1.size() == 0u);
        }) ? ({
            auto&& n_p2 = prism_rtl::as<crate::check::types::Ty::TyCon>(zonk_f_1493).a0;
            auto&& m1487_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(zonk_f_1493).a1;
            prism_rtl::finished(n_p2);
        })
            : prism_rtl::is<crate::check::types::Ty::TyCon>(zonk_f_1493) ? ({
            auto&& n_p3 = prism_rtl::as<crate::check::types::Ty::TyCon>(zonk_f_1493).a0;
            auto&& args_p4 = prism_rtl::as<crate::check::types::Ty::TyCon>(zonk_f_1493).a1;
            crate::prelude::call_value(crate::prelude::each_job(args_p4, ({
            auto st_p0xx = st_p0x;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::check::types::Ty)>>(prism_rtl::rc([=, st_p0xx = std::move(st_p0xx)](crate::check::types::Ty p0) {
            return ({
                auto st_p0xxy = st_p0xx;
                (crate::prelude::entered(crate::prelude::once_job([=, st_p0xxy = std::move(st_p0xxy)]() {
                return ({
                    auto a_p5 = p0;
                    (crate::prelude::call_then(start_show_ty_q_f(st_p0xxy, a_p5), [=](Text show_ty_q_f_1578) { return prism_rtl::finished(prism_rtl::cat(" ", show_ty_q_f_1578)); }));
                });
            })));
            });
        })));
        })), [=](Array<Text> each_1559) { return prism_rtl::finished(prism_rtl::cat("(", n_p3, crate::prelude::concat(each_1559), ")")); });
        })
            : prism_rtl::is<crate::check::types::Ty::TySig>(zonk_f_1493) ? ({
            auto&& s_p6 = prism_rtl::as<crate::check::types::Ty::TySig>(zonk_f_1493).a0;
            auto&& i_p7 = prism_rtl::as<crate::check::types::Ty::TySig>(zonk_f_1493).a1;
            crate::prelude::call_then(start_show_ty_q_f(st_p0x, prism_rtl::deref(i_p7)), [=](Text show_ty_q_f_1619) { return prism_rtl::finished(prism_rtl::cat(s_p6, show_ty_q_f_1619)); });
        })
            : prism_rtl::is<crate::check::types::Ty::TyArray>(zonk_f_1493) ? ({
            auto&& e_p8 = prism_rtl::as<crate::check::types::Ty::TyArray>(zonk_f_1493).a0;
            crate::prelude::call_then(start_show_ty_q_f(st_p0x, prism_rtl::deref(e_p8)), [=](Text show_ty_q_f_1670) {
            return ({
                auto inner_p9 = show_ty_q_f_1670;
                (crate::syntax::lexer::chars::has_prefix_f(inner_p9, Text::lit("["))
                ? prism_rtl::finished(prism_rtl::cat("[ ", inner_p9, " ]"))
                : prism_rtl::finished(prism_rtl::cat("[", inner_p9, "]")));
            });
        });
        })
            : prism_rtl::is<crate::check::types::Ty::TyMap>(zonk_f_1493) ? ({
            auto&& k_pa = prism_rtl::as<crate::check::types::Ty::TyMap>(zonk_f_1493).a0;
            auto&& v_pb = prism_rtl::as<crate::check::types::Ty::TyMap>(zonk_f_1493).a1;
            crate::prelude::call_then(start_show_ty_q_f(st_p0x, prism_rtl::deref(k_pa)), [=](Text show_ty_q_f_1770) { return crate::prelude::call_then(start_show_ty_q_f(st_p0x, prism_rtl::deref(v_pb)), [=](Text show_ty_q_f_1790) { return prism_rtl::finished(prism_rtl::cat("(", show_ty_q_f_1770, " ==> ", show_ty_q_f_1790, ")")); }); });
        })
            : prism_rtl::is<crate::check::types::Ty::TyAt>(zonk_f_1493) ? ({
            auto&& i_pc = prism_rtl::as<crate::check::types::Ty::TyAt>(zonk_f_1493).a0;
            auto&& rw_pd = prism_rtl::as<crate::check::types::Ty::TyAt>(zonk_f_1493).a1;
            crate::prelude::call_then(start_show_ty_q_f(st_p0x, prism_rtl::deref(i_pc)), [=](Text show_ty_q_f_1826) { return prism_rtl::finished(prism_rtl::cat("@", show_ty_q_f_1826, " emit ", crate::check::types::show_row_in_f(rw_pd, true))); });
        })
            : ({
            auto&& other_pe = zonk_f_1493;
            prism_rtl::more(prism_rtl::rc(crate::check::types::ShowTy(st_p0x, other_pe)));
        });
        });
    });
}


/// `Start ShowTyQ, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_show_ty_q_f(crate::check::types::St st_p0, crate::check::types::Ty t_p1) {
    return prism_rtl::make_rc<ShowTyQ>(st_p0, t_p1);
}


/// TryUnify: unbounded fn St, Ty, Ty, Range -> ((Bool, St))
std::tuple<bool, crate::check::types::St> try_unify_f(const crate::check::types::St& st_p0, const crate::check::types::Ty& expected_p1, const crate::check::types::Ty& found_p2, const crate::syntax::Range& span_p3) {
    auto [verdict_p4, st2_p5] = unify_in_f(st_p0, expected_p1, found_p2, span_p3);
    return std::tuple{verdict_p4 == Text::lit(""), st2_p5};
}


prism_rtl::Turn<std::tuple<bool, crate::check::types::St>> TryUnify::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& expected_p1 = this->expected_p1;
    const auto& found_p2 = this->found_p2;
    const auto& span_p3 = this->span_p3;
    auto expected_p1x = expected_p1;
    auto found_p2x = found_p2;
    auto span_p3x = span_p3;
    auto st_p0x = st_p0;
    return crate::prelude::call_then(start_unify_in_f(st_p0x, expected_p1x, found_p2x, span_p3x), [=](std::tuple<Text, crate::check::types::St> unify_in_f_2156) {
        return ({
            auto [verdict_p4, st2_p5] = unify_in_f_2156;
            (prism_rtl::finished(std::tuple{verdict_p4 == Text::lit(""), st2_p5}));
        });
    });
}


/// `Start TryUnify, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<bool, crate::check::types::St>> start_try_unify_f(crate::check::types::St st_p0, crate::check::types::Ty expected_p1, crate::check::types::Ty found_p2, crate::syntax::Range span_p3) {
    return prism_rtl::make_rc<TryUnify>(st_p0, expected_p1, found_p2, span_p3);
}


/// UnifyIn: unbounded fn St, Ty, Ty, Range -> ((Text, St))
std::tuple<Text, crate::check::types::St> unify_in_f(const crate::check::types::St& st_p0, const crate::check::types::Ty& expected_p1, const crate::check::types::Ty& found_p2, const crate::syntax::Range& span_p3) {
    auto e_p4 = norm_assoc_f(st_p0, crate::check::types::recording::walk_f(st_p0, expected_p1));
    auto f_p5 = norm_assoc_f(st_p0, crate::check::types::recording::walk_f(st_p0, found_p2));
    return is_waiting_assoc_f(st_p0, e_p4) || is_waiting_assoc_f(st_p0, f_p5)
        ? e_p4 == f_p5
        ? std::tuple{Text::lit(""), st_p0}
        : std::tuple{Text::lit(""), defer_f(st_p0, e_p4, f_p5, span_p3)}
        : unify_heads_f(st_p0, e_p4, f_p5, span_p3);
}


prism_rtl::Turn<std::tuple<Text, crate::check::types::St>> UnifyIn::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& expected_p1 = this->expected_p1;
    const auto& found_p2 = this->found_p2;
    const auto& span_p3 = this->span_p3;
    auto expected_p1x = expected_p1;
    auto found_p2x = found_p2;
    auto span_p3x = span_p3;
    auto st_p0x = st_p0;
    return crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p0x, expected_p1x), [=](crate::check::types::Ty walk_f_2446) {
        return crate::prelude::call_then(start_norm_assoc_f(st_p0x, walk_f_2446), [=](crate::check::types::Ty norm_assoc_f_2431) {
            return ({
                auto e_p4 = norm_assoc_f_2431;
                (crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p0x, found_p2x), [=, e_p4 = std::move(e_p4)](crate::check::types::Ty walk_f_2492) {
                return crate::prelude::call_then(start_norm_assoc_f(st_p0x, walk_f_2492), [=](crate::check::types::Ty norm_assoc_f_2477) {
                    return ({
                        auto f_p5 = norm_assoc_f_2477;
                        (crate::prelude::call_then(start_is_waiting_assoc_f(st_p0x, e_p4), [=, f_p5 = std::move(f_p5)](bool is_waiting_assoc_f_2516) {
                        return is_waiting_assoc_f_2516 || is_waiting_assoc_f(st_p0x, f_p5)
                            ? e_p4 == f_p5
                            ? prism_rtl::finished(std::tuple{Text::lit(""), st_p0x})
                            : prism_rtl::finished(std::tuple{Text::lit(""), defer_f(st_p0x, e_p4, f_p5, span_p3x)})
                            : prism_rtl::more(prism_rtl::rc(UnifyHeads(st_p0x, e_p4, f_p5, span_p3x)));
                    }));
                    });
                });
            }));
            });
        });
    });
}


/// `Start UnifyIn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Text, crate::check::types::St>> start_unify_in_f(crate::check::types::St st_p0, crate::check::types::Ty expected_p1, crate::check::types::Ty found_p2, crate::syntax::Range span_p3) {
    return prism_rtl::make_rc<UnifyIn>(st_p0, expected_p1, found_p2, span_p3);
}


/// NormAssoc: unbounded fn St, Ty -> Ty
crate::check::types::Ty norm_assoc_f(const crate::check::types::St& st_p0, const crate::check::types::Ty& t_p1) {
    if (prism_rtl::is<crate::check::types::Ty::TyAssoc>(t_p1)) {
        auto&& m2934_0_0 = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t_p1).a0;
        auto&& a_p2 = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t_p1).a1;
        if (m2934_0_0 == Text::lit("Quotient")) {
            auto&& _m = crate::check::types::recording::walk_f(st_p0, prism_rtl::deref(prism_rtl::deref(a_p2)));
            if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
                auto&& m2970_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
                auto&& m2970_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a1;
                if (m2970_0_0 == Text::lit("Float")) {
                    if (m2970_0_1.size() == 0u) {
                        return crate::check::types::t_float_p();
                    }
                }
            }
            if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
                auto&& n_p3 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
                auto&& m2970_1_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a1;
                if (m2970_1_1.size() == 0u) {
                    return ((n_p3 == Text::lit("Nat")) || (n_p3 == Text::lit("Int"))) || (n_p3 == Text::lit("U8"))
                        ? crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("?"), prism_rtl::rc(crate::check::types::Ty(crate::check::types::Ty::TyCon{n_p3, Array<crate::check::types::Ty>{}}))})
                        : t_p1;
                }
            }
            {
                return t_p1;
            }
        }
    }
    {
        auto&& other_p4 = t_p1;
        return other_p4;
    }
}


prism_rtl::Turn<crate::check::types::Ty> NormAssoc::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& t_p1 = this->t_p1;
    return ({
        prism_rtl::is<crate::check::types::Ty::TyAssoc>(t_p1) && ({
        auto&& m2934_0_0 = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t_p1).a0;
        auto&& a_p2 = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t_p1).a1;
        (m2934_0_0 == Text::lit("Quotient"));
    }) ? ({
        auto&& m2934_0_0 = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t_p1).a0;
        auto&& a_p2 = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t_p1).a1;
        ({
        auto a_p2x = prism_rtl::deref(prism_rtl::deref(a_p2));
        auto st_p0x = st_p0;
        auto t_p1x = t_p1;
        (crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p0x, a_p2x), [=, t_p1x = std::move(t_p1x)](crate::check::types::Ty walk_f_2976) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TyCon>(walk_f_2976) && ({
            auto&& m2970_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_f_2976).a0;
            auto&& m2970_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_f_2976).a1;
            (m2970_0_0 == Text::lit("Float")) && (m2970_0_1.size() == 0u);
        }) ? ({
            auto&& m2970_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_f_2976).a0;
            auto&& m2970_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_f_2976).a1;
            prism_rtl::finished(crate::check::types::t_float_p());
        })
            : prism_rtl::is<crate::check::types::Ty::TyCon>(walk_f_2976) && ({
            auto&& n_p3 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_f_2976).a0;
            auto&& m2970_1_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_f_2976).a1;
            (m2970_1_1.size() == 0u);
        }) ? ({
            auto&& n_p3 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_f_2976).a0;
            auto&& m2970_1_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_f_2976).a1;
            ((n_p3 == Text::lit("Nat")) || (n_p3 == Text::lit("Int"))) || (n_p3 == Text::lit("U8"))
            ? prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("?"), prism_rtl::rc(crate::check::types::Ty(crate::check::types::Ty::TyCon{n_p3, Array<crate::check::types::Ty>{}}))}))
            : prism_rtl::finished(t_p1x);
        })
            : prism_rtl::finished(t_p1x);
        });
    }));
    });
    })
        : ({
        auto&& other_p4 = t_p1;
        prism_rtl::finished(other_p4);
    });
    });
}


/// `Start NormAssoc, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::Ty> start_norm_assoc_f(crate::check::types::St st_p0, crate::check::types::Ty t_p1) {
    return prism_rtl::make_rc<NormAssoc>(st_p0, t_p1);
}


/// IsWaitingAssoc: unbounded fn St, Ty -> Bool
bool is_waiting_assoc_f(const crate::check::types::St& st_p0, const crate::check::types::Ty& t_p1) {
    if (prism_rtl::is<crate::check::types::Ty::TyAssoc>(t_p1)) {
        auto&& a_p2 = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t_p1).a1;
        return crate::check::types::is_flex_var_f(st_p0, prism_rtl::deref(prism_rtl::deref(a_p2)));
    }
    {
        return false;
    }
}


prism_rtl::Turn<bool> IsWaitingAssoc::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& t_p1 = this->t_p1;
    return ({
        prism_rtl::is<crate::check::types::Ty::TyAssoc>(t_p1) ? ({
        auto&& a_p2 = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t_p1).a1;
        prism_rtl::more(prism_rtl::rc(crate::check::types::IsFlexVar(st_p0, prism_rtl::deref(prism_rtl::deref(a_p2)))));
    })
        : prism_rtl::finished(false);
    });
}


/// `Start IsWaitingAssoc, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_is_waiting_assoc_f(crate::check::types::St st_p0, crate::check::types::Ty t_p1) {
    return prism_rtl::make_rc<IsWaitingAssoc>(st_p0, t_p1);
}


/// Defer: fn St, Ty, Ty, Range -> St
crate::check::types::St defer_f(const crate::check::types::St& st_p0, const crate::check::types::Ty& e_p1, const crate::check::types::Ty& f_p2, const crate::syntax::Range& span_p3) {
    crate::check::types::St this_ = st_p0;
    this_.deferred_p = crate::prelude::push(this_.deferred_p, std::tuple{e_p1, f_p2, span_p3});
    return this_;
}


/// RetryDeferred: unbounded fn St -> St
crate::check::types::St retry_deferred_f(const crate::check::types::St& st_p0) {
    auto waiting_p1 = st_p0.deferred_p;
    auto cleared_p2 = ({
        crate::check::types::St this_ = st_p0;
        this_.deferred_p = Array<std::tuple<crate::check::types::Ty, crate::check::types::Ty, crate::syntax::Range>>{};
        (std::move(this_));
    });
    return crate::prelude::run_to_end(crate::prelude::fold_job(waiting_p1, cleared_p2, static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, std::tuple<crate::check::types::Ty, crate::check::types::Ty, crate::syntax::Range>>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, std::tuple<crate::check::types::Ty, crate::check::types::Ty, crate::syntax::Range>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto s_p3 = p0;
                auto [e_p4, f_p5, span_p6] = p1;
                (prism_rtl::more(prism_rtl::rc(Unify(s_p3, e_p4, f_p5, span_p6))));
            });
        }));
    }))));
}


prism_rtl::Turn<crate::check::types::St> RetryDeferred::cycle() const {
    const auto& st_p0 = this->st_p0;
    auto waiting_p1 = prism_rtl::deref(st_p0).deferred_p;
    auto cleared_p2 = ({
        crate::check::types::St this_ = st_p0;
        this_.deferred_p = Array<std::tuple<crate::check::types::Ty, crate::check::types::Ty, crate::syntax::Range>>{};
        (std::move(this_));
    });
    return crate::prelude::fold_job(waiting_p1, cleared_p2, static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, std::tuple<crate::check::types::Ty, crate::check::types::Ty, crate::syntax::Range>>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, std::tuple<crate::check::types::Ty, crate::check::types::Ty, crate::syntax::Range>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto s_p3 = p0;
                auto [e_p4, f_p5, span_p6] = p1;
                (prism_rtl::more(prism_rtl::rc(Unify(s_p3, e_p4, f_p5, span_p6))));
            });
        }));
    })))->cycle();
}


/// `Start RetryDeferred, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_retry_deferred_f(crate::check::types::St st_p0) {
    return prism_rtl::make_rc<RetryDeferred>(st_p0);
}


/// UnifyHeads: unbounded fn St, Ty, Ty, Range -> ((Text, St))
std::tuple<Text, crate::check::types::St> unify_heads_f(const crate::check::types::St& st_p0, const crate::check::types::Ty& e_p1, const crate::check::types::Ty& f_p2, const crate::syntax::Range& span_p3) {
    auto&& _m = std::tuple{e_p1, f_p2};
    if (prism_rtl::is<crate::check::types::Ty::TyErr>(std::get<0>(_m))) {
        return std::tuple{Text::lit(""), st_p0};
    }
    if (prism_rtl::is<crate::check::types::Ty::TyErr>(std::get<1>(_m))) {
        return std::tuple{Text::lit(""), st_p0};
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyCon>(std::get<1>(_m))) {
        auto&& m3799_2_0_0 = prism_rtl::as<crate::check::types::Ty::TySig>(std::get<0>(_m)).a0;
        auto&& m3799_2_1_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(std::get<1>(_m)).a0;
        auto&& m3799_2_1_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(std::get<1>(_m)).a1;
        if (m3799_2_0_0 == Text::lit("~")) {
            if (m3799_2_1_0 == Text::lit("Prelude.Error")) {
                if (m3799_2_1_1.size() == 0u) {
                    return std::tuple{Text::lit(""), st_p0};
                }
            }
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TySig>(std::get<1>(_m))) {
        auto&& m3799_3_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(std::get<0>(_m)).a0;
        auto&& m3799_3_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(std::get<0>(_m)).a1;
        auto&& m3799_3_1_0 = prism_rtl::as<crate::check::types::Ty::TySig>(std::get<1>(_m)).a0;
        if (m3799_3_0_0 == Text::lit("Prelude.Error")) {
            if (m3799_3_0_1.size() == 0u) {
                if (m3799_3_1_0 == Text::lit("~")) {
                    return std::tuple{Text::lit(""), st_p0};
                }
            }
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFlex>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyFlex>(std::get<1>(_m))) {
        auto&& a_p4 = prism_rtl::as<crate::check::types::Ty::TyFlex>(std::get<0>(_m)).a0;
        auto&& b_p5 = prism_rtl::as<crate::check::types::Ty::TyFlex>(std::get<1>(_m)).a0;
        return a_p4 == b_p5
            ? std::tuple{Text::lit(""), st_p0}
            : std::tuple{Text::lit(""), merge_vars_f(st_p0, a_p4, b_p5)};
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFlex>(std::get<0>(_m))) {
        auto&& a_p6 = prism_rtl::as<crate::check::types::Ty::TyFlex>(std::get<0>(_m)).a0;
        auto&& t_p7 = std::get<1>(_m);
        return bind_var_f(st_p0, a_p6, t_p7, span_p3);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFlex>(std::get<1>(_m))) {
        auto&& t_p8 = std::get<0>(_m);
        auto&& b_p9 = prism_rtl::as<crate::check::types::Ty::TyFlex>(std::get<1>(_m)).a0;
        return bind_var_f(st_p0, b_p9, t_p8, span_p3);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyRigid>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyRigid>(std::get<1>(_m))) {
        auto&& a_pa = prism_rtl::as<crate::check::types::Ty::TyRigid>(std::get<0>(_m)).a0;
        auto&& b_pb = prism_rtl::as<crate::check::types::Ty::TyRigid>(std::get<1>(_m)).a0;
        return a_pa == b_pb
            ? std::tuple{Text::lit(""), st_p0}
            : std::tuple{Text::lit("mismatch"), st_p0};
    }
    if (prism_rtl::is<crate::check::types::Ty::TyQ>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyQ>(std::get<1>(_m))) {
        auto&& a_pc = prism_rtl::as<crate::check::types::Ty::TyQ>(std::get<0>(_m)).a0;
        auto&& b_pd = prism_rtl::as<crate::check::types::Ty::TyQ>(std::get<1>(_m)).a0;
        return a_pc == b_pd
            ? std::tuple{Text::lit(""), st_p0}
            : std::tuple{Text::lit("mismatch"), st_p0};
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyCon>(std::get<1>(_m))) {
        auto&& a_pe = prism_rtl::as<crate::check::types::Ty::TyCon>(std::get<0>(_m)).a0;
        auto&& xs_pf = prism_rtl::as<crate::check::types::Ty::TyCon>(std::get<0>(_m)).a1;
        auto&& b_pg = prism_rtl::as<crate::check::types::Ty::TyCon>(std::get<1>(_m)).a0;
        auto&& ys_ph = prism_rtl::as<crate::check::types::Ty::TyCon>(std::get<1>(_m)).a1;
        return (a_pe == b_pg) && (crate::prelude::len(xs_pf) == crate::prelude::len(ys_ph))
            ? unify_all_f(st_p0, xs_pf, ys_ph, span_p3)
            : std::tuple{Text::lit("mismatch"), st_p0};
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyFn>(std::get<1>(_m))) {
        auto&& c1_pi = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<0>(_m)).a0;
        auto&& ps_pj = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<0>(_m)).a1;
        auto&& r1_pk = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<0>(_m)).a2;
        auto&& c2_pl = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<1>(_m)).a0;
        auto&& qs_pm = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<1>(_m)).a1;
        auto&& r2_pn = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<1>(_m)).a2;
        return crate::prelude::len(ps_pj) == crate::prelude::len(qs_pm)
            ? ({
            auto [v_po, st2_pp] = crate::check::types::colors::unify_col_f(st_p0, c1_pi, c2_pl);
            v_po != Text::lit("")
            ? std::tuple{v_po, st2_pp}
            : unify_all_f(st2_pp, crate::prelude::push(ps_pj, prism_rtl::deref(r1_pk)), crate::prelude::push(qs_pm, prism_rtl::deref(r2_pn)), span_p3);
        })
            : std::tuple{Text::lit("mismatch"), st_p0};
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyTuple>(std::get<1>(_m))) {
        auto&& xs_pq = prism_rtl::as<crate::check::types::Ty::TyTuple>(std::get<0>(_m)).a0;
        auto&& ys_pr = prism_rtl::as<crate::check::types::Ty::TyTuple>(std::get<1>(_m)).a0;
        return crate::prelude::len(xs_pq) == crate::prelude::len(ys_pr)
            ? unify_all_f(st_p0, xs_pq, ys_pr, span_p3)
            : std::tuple{Text::lit("mismatch"), st_p0};
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyArray>(std::get<1>(_m))) {
        auto&& x_ps = prism_rtl::as<crate::check::types::Ty::TyArray>(std::get<0>(_m)).a0;
        auto&& y_pt = prism_rtl::as<crate::check::types::Ty::TyArray>(std::get<1>(_m)).a0;
        return unify_in_f(st_p0, prism_rtl::deref(x_ps), prism_rtl::deref(y_pt), span_p3);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyMap>(std::get<1>(_m))) {
        auto&& k1_pu = prism_rtl::as<crate::check::types::Ty::TyMap>(std::get<0>(_m)).a0;
        auto&& v1_pv = prism_rtl::as<crate::check::types::Ty::TyMap>(std::get<0>(_m)).a1;
        auto&& k2_p10 = prism_rtl::as<crate::check::types::Ty::TyMap>(std::get<1>(_m)).a0;
        auto&& v2_p11 = prism_rtl::as<crate::check::types::Ty::TyMap>(std::get<1>(_m)).a1;
        return unify_all_f(st_p0, Array(std::vector{prism_rtl::deref(k1_pu), prism_rtl::deref(v1_pv)}), Array(std::vector{prism_rtl::deref(k2_p10), prism_rtl::deref(v2_p11)}), span_p3);
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TySig>(std::get<1>(_m))) {
        auto&& s1_p12 = prism_rtl::as<crate::check::types::Ty::TySig>(std::get<0>(_m)).a0;
        auto&& i1_p13 = prism_rtl::as<crate::check::types::Ty::TySig>(std::get<0>(_m)).a1;
        auto&& s2_p14 = prism_rtl::as<crate::check::types::Ty::TySig>(std::get<1>(_m)).a0;
        auto&& i2_p15 = prism_rtl::as<crate::check::types::Ty::TySig>(std::get<1>(_m)).a1;
        return s1_p12 == s2_p14
            ? unify_in_f(st_p0, prism_rtl::deref(i1_p13), prism_rtl::deref(i2_p15), span_p3)
            : std::tuple{Text::lit("mismatch"), st_p0};
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyAt>(std::get<1>(_m))) {
        auto&& i1_p16 = prism_rtl::as<crate::check::types::Ty::TyAt>(std::get<0>(_m)).a0;
        auto&& r1_p17 = prism_rtl::as<crate::check::types::Ty::TyAt>(std::get<0>(_m)).a1;
        auto&& i2_p18 = prism_rtl::as<crate::check::types::Ty::TyAt>(std::get<1>(_m)).a0;
        auto&& r2_p19 = prism_rtl::as<crate::check::types::Ty::TyAt>(std::get<1>(_m)).a1;
        auto [v_p1a, st2_p1b] = unify_in_f(st_p0, prism_rtl::deref(i1_p16), prism_rtl::deref(i2_p18), span_p3);
        return v_p1a != Text::lit("")
            ? std::tuple{v_p1a, st2_p1b}
            : unify_row_f(st2_p1b, r1_p17, r2_p19, span_p3);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyElem>(std::get<1>(_m))) {
        auto&& r1_p1c = prism_rtl::as<crate::check::types::Ty::TyElem>(std::get<0>(_m)).a0;
        auto&& o1_p1d = prism_rtl::as<crate::check::types::Ty::TyElem>(std::get<0>(_m)).a1;
        auto&& r2_p1e = prism_rtl::as<crate::check::types::Ty::TyElem>(std::get<1>(_m)).a0;
        auto&& o2_p1f = prism_rtl::as<crate::check::types::Ty::TyElem>(std::get<1>(_m)).a1;
        auto [v_p1g, st2_p1h] = unify_row_f(st_p0, r1_p1c, r2_p1e, span_p3);
        return v_p1g != Text::lit("")
            ? std::tuple{v_p1g, st2_p1h}
            : unify_in_f(st2_p1h, prism_rtl::deref(o1_p1d), prism_rtl::deref(o2_p1f), span_p3);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElemAny>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyElemAny>(std::get<1>(_m))) {
        auto&& r1_p1i = prism_rtl::as<crate::check::types::Ty::TyElemAny>(std::get<0>(_m)).a0;
        auto&& r2_p1j = prism_rtl::as<crate::check::types::Ty::TyElemAny>(std::get<1>(_m)).a0;
        return unify_row_f(st_p0, r1_p1i, r2_p1j, span_p3);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAssoc>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyAssoc>(std::get<1>(_m))) {
        auto&& n1_p1k = prism_rtl::as<crate::check::types::Ty::TyAssoc>(std::get<0>(_m)).a0;
        auto&& a1_p1l = prism_rtl::as<crate::check::types::Ty::TyAssoc>(std::get<0>(_m)).a1;
        auto&& n2_p1m = prism_rtl::as<crate::check::types::Ty::TyAssoc>(std::get<1>(_m)).a0;
        auto&& a2_p1n = prism_rtl::as<crate::check::types::Ty::TyAssoc>(std::get<1>(_m)).a1;
        return n1_p1k == n2_p1m
            ? unify_in_f(st_p0, prism_rtl::deref(a1_p1l), prism_rtl::deref(a2_p1n), span_p3)
            : std::tuple{Text::lit("mismatch"), st_p0};
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAny>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyAny>(std::get<1>(_m))) {
        auto&& xs_p1o = prism_rtl::as<crate::check::types::Ty::TyAny>(std::get<0>(_m)).a0;
        auto&& ys_p1p = prism_rtl::as<crate::check::types::Ty::TyAny>(std::get<1>(_m)).a0;
        return crate::check::types::sort_texts_f(xs_p1o) == crate::check::types::sort_texts_f(ys_p1p)
            ? std::tuple{Text::lit(""), st_p0}
            : std::tuple{Text::lit("mismatch"), st_p0};
    }
    {
        return std::tuple{Text::lit("mismatch"), st_p0};
    }
}


prism_rtl::Turn<std::tuple<Text, crate::check::types::St>> UnifyHeads::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& e_p1 = this->e_p1;
    const auto& f_p2 = this->f_p2;
    const auto& span_p3 = this->span_p3;
    return ({
        auto&& _m = std::tuple{e_p1, f_p2};
        prism_rtl::is<crate::check::types::Ty::TyErr>(std::get<0>(_m)) ? prism_rtl::finished(std::tuple{Text::lit(""), st_p0})
        : prism_rtl::is<crate::check::types::Ty::TyErr>(std::get<1>(_m)) ? prism_rtl::finished(std::tuple{Text::lit(""), st_p0})
        : prism_rtl::is<crate::check::types::Ty::TySig>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyCon>(std::get<1>(_m)) && ({
        auto&& m3799_2_0_0 = prism_rtl::as<crate::check::types::Ty::TySig>(std::get<0>(_m)).a0;
        auto&& m3799_2_1_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(std::get<1>(_m)).a0;
        auto&& m3799_2_1_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(std::get<1>(_m)).a1;
        (m3799_2_0_0 == Text::lit("~")) && (m3799_2_1_0 == Text::lit("Prelude.Error")) && (m3799_2_1_1.size() == 0u);
    }) ? ({
        auto&& m3799_2_0_0 = prism_rtl::as<crate::check::types::Ty::TySig>(std::get<0>(_m)).a0;
        auto&& m3799_2_1_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(std::get<1>(_m)).a0;
        auto&& m3799_2_1_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(std::get<1>(_m)).a1;
        prism_rtl::finished(std::tuple{Text::lit(""), st_p0});
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TySig>(std::get<1>(_m)) && ({
        auto&& m3799_3_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(std::get<0>(_m)).a0;
        auto&& m3799_3_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(std::get<0>(_m)).a1;
        auto&& m3799_3_1_0 = prism_rtl::as<crate::check::types::Ty::TySig>(std::get<1>(_m)).a0;
        (m3799_3_0_0 == Text::lit("Prelude.Error")) && (m3799_3_0_1.size() == 0u) && (m3799_3_1_0 == Text::lit("~"));
    }) ? ({
        auto&& m3799_3_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(std::get<0>(_m)).a0;
        auto&& m3799_3_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(std::get<0>(_m)).a1;
        auto&& m3799_3_1_0 = prism_rtl::as<crate::check::types::Ty::TySig>(std::get<1>(_m)).a0;
        prism_rtl::finished(std::tuple{Text::lit(""), st_p0});
    })
        : prism_rtl::is<crate::check::types::Ty::TyFlex>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyFlex>(std::get<1>(_m)) ? ({
        auto&& a_p4 = prism_rtl::as<crate::check::types::Ty::TyFlex>(std::get<0>(_m)).a0;
        auto&& b_p5 = prism_rtl::as<crate::check::types::Ty::TyFlex>(std::get<1>(_m)).a0;
        a_p4 == b_p5
        ? prism_rtl::finished(std::tuple{Text::lit(""), st_p0})
        : prism_rtl::finished(std::tuple{Text::lit(""), merge_vars_f(st_p0, a_p4, b_p5)});
    })
        : prism_rtl::is<crate::check::types::Ty::TyFlex>(std::get<0>(_m)) ? ({
        auto&& a_p6 = prism_rtl::as<crate::check::types::Ty::TyFlex>(std::get<0>(_m)).a0;
        auto&& t_p7 = std::get<1>(_m);
        prism_rtl::more(prism_rtl::rc(BindVar(st_p0, a_p6, t_p7, span_p3)));
    })
        : prism_rtl::is<crate::check::types::Ty::TyFlex>(std::get<1>(_m)) ? ({
        auto&& t_p8 = std::get<0>(_m);
        auto&& b_p9 = prism_rtl::as<crate::check::types::Ty::TyFlex>(std::get<1>(_m)).a0;
        prism_rtl::more(prism_rtl::rc(BindVar(st_p0, b_p9, t_p8, span_p3)));
    })
        : prism_rtl::is<crate::check::types::Ty::TyRigid>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyRigid>(std::get<1>(_m)) ? ({
        auto&& a_pa = prism_rtl::as<crate::check::types::Ty::TyRigid>(std::get<0>(_m)).a0;
        auto&& b_pb = prism_rtl::as<crate::check::types::Ty::TyRigid>(std::get<1>(_m)).a0;
        a_pa == b_pb
        ? prism_rtl::finished(std::tuple{Text::lit(""), st_p0})
        : prism_rtl::finished(std::tuple{Text::lit("mismatch"), st_p0});
    })
        : prism_rtl::is<crate::check::types::Ty::TyQ>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyQ>(std::get<1>(_m)) ? ({
        auto&& a_pc = prism_rtl::as<crate::check::types::Ty::TyQ>(std::get<0>(_m)).a0;
        auto&& b_pd = prism_rtl::as<crate::check::types::Ty::TyQ>(std::get<1>(_m)).a0;
        a_pc == b_pd
        ? prism_rtl::finished(std::tuple{Text::lit(""), st_p0})
        : prism_rtl::finished(std::tuple{Text::lit("mismatch"), st_p0});
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyCon>(std::get<1>(_m)) ? ({
        auto&& a_pe = prism_rtl::as<crate::check::types::Ty::TyCon>(std::get<0>(_m)).a0;
        auto&& xs_pf = prism_rtl::as<crate::check::types::Ty::TyCon>(std::get<0>(_m)).a1;
        auto&& b_pg = prism_rtl::as<crate::check::types::Ty::TyCon>(std::get<1>(_m)).a0;
        auto&& ys_ph = prism_rtl::as<crate::check::types::Ty::TyCon>(std::get<1>(_m)).a1;
        (a_pe == b_pg) && (crate::prelude::len(xs_pf) == crate::prelude::len(ys_ph))
        ? prism_rtl::more(prism_rtl::rc(UnifyAll(st_p0, xs_pf, ys_ph, span_p3)))
        : prism_rtl::finished(std::tuple{Text::lit("mismatch"), st_p0});
    })
        : prism_rtl::is<crate::check::types::Ty::TyFn>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyFn>(std::get<1>(_m)) ? ({
        auto&& c1_pi = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<0>(_m)).a0;
        auto&& ps_pj = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<0>(_m)).a1;
        auto&& r1_pk = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<0>(_m)).a2;
        auto&& c2_pl = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<1>(_m)).a0;
        auto&& qs_pm = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<1>(_m)).a1;
        auto&& r2_pn = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<1>(_m)).a2;
        crate::prelude::len(ps_pj) == crate::prelude::len(qs_pm)
        ? ({
        auto span_p3x = span_p3;
        auto st_p0x = st_p0;
        (crate::prelude::call_then(crate::check::types::colors::start_unify_col_f(st_p0x, c1_pi, c2_pl), [=, span_p3x = std::move(span_p3x)](std::tuple<Text, crate::check::types::St> unify_col_f_4653) {
        return ({
            auto [v_po, st2_pp] = unify_col_f_4653;
            v_po != Text::lit("")
            ? prism_rtl::finished(std::tuple{v_po, st2_pp})
            : prism_rtl::more(prism_rtl::rc(UnifyAll(st2_pp, crate::prelude::push(ps_pj, prism_rtl::deref(r1_pk)), crate::prelude::push(qs_pm, prism_rtl::deref(r2_pn)), span_p3x)));
        });
    }));
    })
        : prism_rtl::finished(std::tuple{Text::lit("mismatch"), st_p0});
    })
        : prism_rtl::is<crate::check::types::Ty::TyTuple>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyTuple>(std::get<1>(_m)) ? ({
        auto&& xs_pq = prism_rtl::as<crate::check::types::Ty::TyTuple>(std::get<0>(_m)).a0;
        auto&& ys_pr = prism_rtl::as<crate::check::types::Ty::TyTuple>(std::get<1>(_m)).a0;
        crate::prelude::len(xs_pq) == crate::prelude::len(ys_pr)
        ? prism_rtl::more(prism_rtl::rc(UnifyAll(st_p0, xs_pq, ys_pr, span_p3)))
        : prism_rtl::finished(std::tuple{Text::lit("mismatch"), st_p0});
    })
        : prism_rtl::is<crate::check::types::Ty::TyArray>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyArray>(std::get<1>(_m)) ? ({
        auto&& x_ps = prism_rtl::as<crate::check::types::Ty::TyArray>(std::get<0>(_m)).a0;
        auto&& y_pt = prism_rtl::as<crate::check::types::Ty::TyArray>(std::get<1>(_m)).a0;
        prism_rtl::more(prism_rtl::rc(UnifyIn(st_p0, prism_rtl::deref(x_ps), prism_rtl::deref(y_pt), span_p3)));
    })
        : prism_rtl::is<crate::check::types::Ty::TyMap>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyMap>(std::get<1>(_m)) ? ({
        auto&& k1_pu = prism_rtl::as<crate::check::types::Ty::TyMap>(std::get<0>(_m)).a0;
        auto&& v1_pv = prism_rtl::as<crate::check::types::Ty::TyMap>(std::get<0>(_m)).a1;
        auto&& k2_p10 = prism_rtl::as<crate::check::types::Ty::TyMap>(std::get<1>(_m)).a0;
        auto&& v2_p11 = prism_rtl::as<crate::check::types::Ty::TyMap>(std::get<1>(_m)).a1;
        prism_rtl::more(prism_rtl::rc(UnifyAll(st_p0, Array(std::vector{prism_rtl::deref(k1_pu), prism_rtl::deref(v1_pv)}), Array(std::vector{prism_rtl::deref(k2_p10), prism_rtl::deref(v2_p11)}), span_p3)));
    })
        : prism_rtl::is<crate::check::types::Ty::TySig>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TySig>(std::get<1>(_m)) ? ({
        auto&& s1_p12 = prism_rtl::as<crate::check::types::Ty::TySig>(std::get<0>(_m)).a0;
        auto&& i1_p13 = prism_rtl::as<crate::check::types::Ty::TySig>(std::get<0>(_m)).a1;
        auto&& s2_p14 = prism_rtl::as<crate::check::types::Ty::TySig>(std::get<1>(_m)).a0;
        auto&& i2_p15 = prism_rtl::as<crate::check::types::Ty::TySig>(std::get<1>(_m)).a1;
        s1_p12 == s2_p14
        ? prism_rtl::more(prism_rtl::rc(UnifyIn(st_p0, prism_rtl::deref(i1_p13), prism_rtl::deref(i2_p15), span_p3)))
        : prism_rtl::finished(std::tuple{Text::lit("mismatch"), st_p0});
    })
        : prism_rtl::is<crate::check::types::Ty::TyAt>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyAt>(std::get<1>(_m)) ? ({
        auto&& i1_p16 = prism_rtl::as<crate::check::types::Ty::TyAt>(std::get<0>(_m)).a0;
        auto&& r1_p17 = prism_rtl::as<crate::check::types::Ty::TyAt>(std::get<0>(_m)).a1;
        auto&& i2_p18 = prism_rtl::as<crate::check::types::Ty::TyAt>(std::get<1>(_m)).a0;
        auto&& r2_p19 = prism_rtl::as<crate::check::types::Ty::TyAt>(std::get<1>(_m)).a1;
        ({
        auto span_p3x = span_p3;
        auto st_p0x = st_p0;
        (crate::prelude::call_then(start_unify_in_f(st_p0x, prism_rtl::deref(i1_p16), prism_rtl::deref(i2_p18), span_p3x), [=](std::tuple<Text, crate::check::types::St> unify_in_f_5237) {
        return ({
            auto [v_p1a, st2_p1b] = unify_in_f_5237;
            v_p1a != Text::lit("")
            ? prism_rtl::finished(std::tuple{v_p1a, st2_p1b})
            : prism_rtl::more(prism_rtl::rc(UnifyRow(st2_p1b, r1_p17, r2_p19, span_p3x)));
        });
    }));
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyElem>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyElem>(std::get<1>(_m)) ? ({
        auto&& r1_p1c = prism_rtl::as<crate::check::types::Ty::TyElem>(std::get<0>(_m)).a0;
        auto&& o1_p1d = prism_rtl::as<crate::check::types::Ty::TyElem>(std::get<0>(_m)).a1;
        auto&& r2_p1e = prism_rtl::as<crate::check::types::Ty::TyElem>(std::get<1>(_m)).a0;
        auto&& o2_p1f = prism_rtl::as<crate::check::types::Ty::TyElem>(std::get<1>(_m)).a1;
        ({
        auto span_p3x = span_p3;
        auto st_p0x = st_p0;
        (crate::prelude::call_then(start_unify_row_f(st_p0x, r1_p1c, r2_p1e, span_p3x), [=](std::tuple<Text, crate::check::types::St> unify_row_f_5405) {
        return ({
            auto [v_p1g, st2_p1h] = unify_row_f_5405;
            v_p1g != Text::lit("")
            ? prism_rtl::finished(std::tuple{v_p1g, st2_p1h})
            : prism_rtl::more(prism_rtl::rc(UnifyIn(st2_p1h, prism_rtl::deref(o1_p1d), prism_rtl::deref(o2_p1f), span_p3x)));
        });
    }));
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyElemAny>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyElemAny>(std::get<1>(_m)) ? ({
        auto&& r1_p1i = prism_rtl::as<crate::check::types::Ty::TyElemAny>(std::get<0>(_m)).a0;
        auto&& r2_p1j = prism_rtl::as<crate::check::types::Ty::TyElemAny>(std::get<1>(_m)).a0;
        prism_rtl::more(prism_rtl::rc(UnifyRow(st_p0, r1_p1i, r2_p1j, span_p3)));
    })
        : prism_rtl::is<crate::check::types::Ty::TyAssoc>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyAssoc>(std::get<1>(_m)) ? ({
        auto&& n1_p1k = prism_rtl::as<crate::check::types::Ty::TyAssoc>(std::get<0>(_m)).a0;
        auto&& a1_p1l = prism_rtl::as<crate::check::types::Ty::TyAssoc>(std::get<0>(_m)).a1;
        auto&& n2_p1m = prism_rtl::as<crate::check::types::Ty::TyAssoc>(std::get<1>(_m)).a0;
        auto&& a2_p1n = prism_rtl::as<crate::check::types::Ty::TyAssoc>(std::get<1>(_m)).a1;
        n1_p1k == n2_p1m
        ? prism_rtl::more(prism_rtl::rc(UnifyIn(st_p0, prism_rtl::deref(a1_p1l), prism_rtl::deref(a2_p1n), span_p3)))
        : prism_rtl::finished(std::tuple{Text::lit("mismatch"), st_p0});
    })
        : prism_rtl::is<crate::check::types::Ty::TyAny>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyAny>(std::get<1>(_m)) ? ({
        auto&& xs_p1o = prism_rtl::as<crate::check::types::Ty::TyAny>(std::get<0>(_m)).a0;
        auto&& ys_p1p = prism_rtl::as<crate::check::types::Ty::TyAny>(std::get<1>(_m)).a0;
        crate::check::types::sort_texts_f(xs_p1o) == crate::check::types::sort_texts_f(ys_p1p)
        ? prism_rtl::finished(std::tuple{Text::lit(""), st_p0})
        : prism_rtl::finished(std::tuple{Text::lit("mismatch"), st_p0});
    })
        : prism_rtl::finished(std::tuple{Text::lit("mismatch"), st_p0});
    });
}


/// `Start UnifyHeads, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Text, crate::check::types::St>> start_unify_heads_f(crate::check::types::St st_p0, crate::check::types::Ty e_p1, crate::check::types::Ty f_p2, crate::syntax::Range span_p3) {
    return prism_rtl::make_rc<UnifyHeads>(st_p0, e_p1, f_p2, span_p3);
}


/// UnifyAll: unbounded fn St, [Ty], [Ty], Range -> ((Text, St))
std::tuple<Text, crate::check::types::St> unify_all_f(const crate::check::types::St& st_p0, const Array<crate::check::types::Ty>& xs_p1, const Array<crate::check::types::Ty>& ys_p2, const crate::syntax::Range& span_p3) {
    return crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(crate::prelude::len(xs_p1)), std::tuple{Text::lit(""), st_p0}, ({
        auto xs_p1x = xs_p1;
        auto ys_p2x = ys_p2;
        auto span_p3x = span_p3;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, crate::check::types::St>>(std::tuple<std::tuple<Text, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=, xs_p1x = std::move(xs_p1x), ys_p2x = std::move(ys_p2x), span_p3x = std::move(span_p3x)](std::tuple<std::tuple<Text, crate::check::types::St>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto xs_p1xy = xs_p1x;
            auto ys_p2xy = ys_p2x;
            auto span_p3xy = span_p3x;
            (crate::prelude::entered(crate::prelude::once_job([=, xs_p1xy = std::move(xs_p1xy), ys_p2xy = std::move(ys_p2xy), span_p3xy = std::move(span_p3xy)]() {
            return ({
                auto [v_p4, s_p5] = p0;
                auto i_p6 = p1;
                v_p4 != Text::lit("")
                ? prism_rtl::finished(std::tuple{v_p4, s_p5})
                : prism_rtl::more(prism_rtl::rc(UnifyIn(s_p5, crate::prelude::or_(crate::prelude::index(xs_p1xy, i_p6), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), crate::prelude::or_(crate::prelude::index(ys_p2xy, i_p6), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), span_p3xy)));
            });
        })));
        });
    }));
    })));
}


prism_rtl::Turn<std::tuple<Text, crate::check::types::St>> UnifyAll::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& xs_p1 = this->xs_p1;
    const auto& ys_p2 = this->ys_p2;
    const auto& span_p3 = this->span_p3;
    return crate::prelude::fold_job(crate::check::errors::range0_f(crate::prelude::len(xs_p1)), std::tuple{Text::lit(""), st_p0}, ({
        auto xs_p1x = xs_p1;
        auto ys_p2x = ys_p2;
        auto span_p3x = span_p3;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, crate::check::types::St>>(std::tuple<std::tuple<Text, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=, xs_p1x = std::move(xs_p1x), ys_p2x = std::move(ys_p2x), span_p3x = std::move(span_p3x)](std::tuple<std::tuple<Text, crate::check::types::St>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto xs_p1xy = xs_p1x;
            auto ys_p2xy = ys_p2x;
            auto span_p3xy = span_p3x;
            (crate::prelude::entered(crate::prelude::once_job([=, xs_p1xy = std::move(xs_p1xy), ys_p2xy = std::move(ys_p2xy), span_p3xy = std::move(span_p3xy)]() {
            return ({
                auto [v_p4, s_p5] = p0;
                auto i_p6 = p1;
                v_p4 != Text::lit("")
                ? prism_rtl::finished(std::tuple{v_p4, s_p5})
                : prism_rtl::more(prism_rtl::rc(UnifyIn(s_p5, crate::prelude::or_(crate::prelude::index(xs_p1xy, i_p6), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), crate::prelude::or_(crate::prelude::index(ys_p2xy, i_p6), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), span_p3xy)));
            });
        })));
        });
    }));
    }))->cycle();
}


/// `Start UnifyAll, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Text, crate::check::types::St>> start_unify_all_f(crate::check::types::St st_p0, Array<crate::check::types::Ty> xs_p1, Array<crate::check::types::Ty> ys_p2, crate::syntax::Range span_p3) {
    return prism_rtl::make_rc<UnifyAll>(st_p0, xs_p1, ys_p2, span_p3);
}


/// MergeVars: fn St, Nat, Nat -> St
crate::check::types::St merge_vars_f(const crate::check::types::St& st_p0, const Nat& a_p1, const Nat& b_p2) {
    auto ia_p3 = crate::check::types::recording::info_of_f(st_p0, a_p1);
    auto ib_p4 = crate::check::types::recording::info_of_f(st_p0, b_p2);
    auto merged_p5 = crate::check::types::VInfo{.plain_p = prism_rtl::deref(ia_p3).plain_p || prism_rtl::deref(ib_p4).plain_p, .level_p = crate::prelude::min(prism_rtl::deref(ia_p3).level_p, prism_rtl::deref(ib_p4).level_p), .name_p = prism_rtl::deref(ib_p4).name_p == Text::lit("")
        ? prism_rtl::deref(ia_p3).name_p
        : prism_rtl::deref(ib_p4).name_p};
    crate::check::types::St this_ = st_p0;
    this_.tys_p = crate::prelude::insert(this_.tys_p, a_p1, crate::check::types::Ty(crate::check::types::Ty::TyFlex{b_p2}));
    this_.infos_p = crate::prelude::insert(this_.infos_p, b_p2, merged_p5);
    return this_;
}


/// BindVar: unbounded fn St, Nat, Ty, Range -> ((Text, St))
std::tuple<Text, crate::check::types::St> bind_var_f(const crate::check::types::St& st_p0, const Nat& n_p1, const crate::check::types::Ty& t_p2, const crate::syntax::Range& span_p3) {
    auto info_p4 = crate::check::types::recording::info_of_f(st_p0, n_p1);
    auto stack_p5 = crate::check::types::stack_of_f(st_p0, t_p2);
    return crate::check::types::has_nat_f(crate::check::types::recording::free_vars_f(st_p0, t_p2), n_p1)
        ? std::tuple{Text::lit("reported"), crate::check::types::recording::err_f(st_p0, Text::lit("occurs"), span_p3, prism_rtl::cat("`t", n_p1, "` would contain itself: `t", n_p1, " = ", crate::check::types::show_ty_f(st_p0, t_p2), "`"))}
        : prism_rtl::deref(info_p4).plain_p && (stack_p5 != Text::lit(""))
        ? prism_rtl::deref(info_p4).name_p != Text::lit("")
        ? ({
        auto marks_p6 = marks_of_f(prism_rtl::deref(info_p4).name_p);
        auto whole_p7 = prism_rtl::cat(marks_p6, crate::check::types::show_ty_in_f(st_p0, crate::check::types::recording::zonk_f(st_p0, t_p2), true));
        auto at_p8 = crate::prelude::or_(crate::prelude::get(st_p0.binder_at_p, n_p1), span_p3);
        auto st2_p9 = crate::check::types::recording::err_fix_f(st_p0, Text::lit("mark-stack"), at_p8, prism_rtl::cat("`", prism_rtl::deref(info_p4).name_p, "` has type `", whole_p7, "`, whose stack is `", marks_p6, stack_p5, "`; the name shows `", marks_p6, "`"), prism_rtl::cat("rename to `", marks_p6, stack_p5, crate::syntax::lexer::chars::drop_prefix_f(prism_rtl::deref(info_p4).name_p, marks_p6), "`"));
        std::tuple{Text::lit(""), ({
        crate::check::types::St this_ = lower_levels_f(st2_p9, crate::prelude::append(crate::check::types::recording::free_vars_f(st2_p9, t_p2), crate::check::types::colors::free_col_vars_f(st2_p9, t_p2)), prism_rtl::deref(info_p4).level_p);
        this_.tys_p = crate::prelude::insert(this_.tys_p, n_p1, t_p2);
        (std::move(this_));
    })};
    })
        : std::tuple{Text::lit("mismatch"), st_p0}
        : ({
        auto lowered_pa = lower_levels_f(st_p0, crate::prelude::append(crate::check::types::recording::free_vars_f(st_p0, t_p2), crate::check::types::colors::free_col_vars_f(st_p0, t_p2)), prism_rtl::deref(info_p4).level_p);
        std::tuple{Text::lit(""), ({
        crate::check::types::St this_ = lowered_pa;
        this_.tys_p = crate::prelude::insert(this_.tys_p, n_p1, t_p2);
        (std::move(this_));
    })};
    });
}


prism_rtl::Turn<std::tuple<Text, crate::check::types::St>> BindVar::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& n_p1 = this->n_p1;
    const auto& t_p2 = this->t_p2;
    const auto& span_p3 = this->span_p3;
    auto info_p4 = crate::check::types::recording::info_of_f(st_p0, n_p1);
    auto n_p1x = n_p1;
    auto span_p3x = span_p3;
    auto st_p0x = st_p0;
    auto t_p2x = t_p2;
    return crate::prelude::call_then(crate::check::types::start_stack_of_f(st_p0x, t_p2x), [=](Text stack_of_f_6651) {
        return ({
            auto stack_p5 = stack_of_f_6651;
            (crate::prelude::call_then(crate::check::types::recording::start_free_vars_f(st_p0x, t_p2x), [=, stack_p5 = std::move(stack_p5)](Array<Nat> free_vars_f_6680) {
            return crate::check::types::has_nat_f(free_vars_f_6680, n_p1x)
                ? crate::prelude::call_then(crate::check::types::start_show_ty_f(st_p0x, t_p2x), [=](Text show_ty_f_6786) { return prism_rtl::finished(std::tuple{Text::lit("reported"), crate::check::types::recording::err_f(st_p0x, Text::lit("occurs"), span_p3x, prism_rtl::cat("`t", n_p1x, "` would contain itself: `t", n_p1x, " = ", show_ty_f_6786, "`"))}); })
                : prism_rtl::deref(info_p4).plain_p && (stack_p5 != Text::lit(""))
                ? prism_rtl::deref(info_p4).name_p != Text::lit("")
                ? ({
                auto marks_p6 = marks_of_f(prism_rtl::deref(info_p4).name_p);
                (crate::prelude::call_then(crate::check::types::recording::start_zonk_f(st_p0x, t_p2x), [=, marks_p6 = std::move(marks_p6)](crate::check::types::Ty zonk_f_6963) {
                return crate::prelude::call_then(crate::check::types::start_show_ty_in_f(st_p0x, zonk_f_6963, true), [=](Text show_ty_in_f_6949) {
                    return ({
                        auto whole_p7 = prism_rtl::cat(marks_p6, show_ty_in_f_6949);
                        auto at_p8 = crate::prelude::or_(crate::prelude::get(prism_rtl::deref(st_p0x).binder_at_p, n_p1x), span_p3x);
                        auto st2_p9 = crate::check::types::recording::err_fix_f(st_p0x, Text::lit("mark-stack"), at_p8, prism_rtl::cat("`", prism_rtl::deref(info_p4).name_p, "` has type `", whole_p7, "`, whose stack is `", marks_p6, stack_p5, "`; the name shows `", marks_p6, "`"), prism_rtl::cat("rename to `", marks_p6, stack_p5, crate::syntax::lexer::chars::drop_prefix_f(prism_rtl::deref(info_p4).name_p, marks_p6), "`"));
                        (prism_rtl::finished(std::tuple{Text::lit(""), ({
                        crate::check::types::St this_ = lower_levels_f(st2_p9, crate::prelude::append(crate::check::types::recording::free_vars_f(st2_p9, t_p2x), crate::check::types::colors::free_col_vars_f(st2_p9, t_p2x)), prism_rtl::deref(info_p4).level_p);
                        this_.tys_p = crate::prelude::insert(this_.tys_p, n_p1x, t_p2x);
                        (std::move(this_));
                    })}));
                    });
                });
            }));
            })
                : prism_rtl::finished(std::tuple{Text::lit("mismatch"), st_p0x})
                : crate::prelude::call_then(crate::check::types::recording::start_free_vars_f(st_p0x, t_p2x), [=](Array<Nat> free_vars_f_7628) {
                return crate::prelude::call_then(crate::check::types::colors::start_free_col_vars_f(st_p0x, t_p2x), [=](Array<Nat> free_col_vars_f_7646) {
                    return ({
                        auto lowered_pa = lower_levels_f(st_p0x, crate::prelude::append(free_vars_f_7628, free_col_vars_f_7646), prism_rtl::deref(info_p4).level_p);
                        (prism_rtl::finished(std::tuple{Text::lit(""), ({
                        crate::check::types::St this_ = lowered_pa;
                        this_.tys_p = crate::prelude::insert(this_.tys_p, n_p1x, t_p2x);
                        (std::move(this_));
                    })}));
                    });
                });
            });
        }));
        });
    });
}


/// `Start BindVar, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Text, crate::check::types::St>> start_bind_var_f(crate::check::types::St st_p0, Nat n_p1, crate::check::types::Ty t_p2, crate::syntax::Range span_p3) {
    return prism_rtl::make_rc<BindVar>(st_p0, n_p1, t_p2, span_p3);
}


/// MarksOf: fn Text -> Text
Text marks_of_f(const Text& name_p0) {
    auto c_p1 = ({
        Cursor this_ = crate::prelude::front(name_p0);
        while (true) {
            auto&& _m = crate::prelude::step(this_);
            if (!(prism_rtl::is_some(_m))) break;
            auto&& next_p2 = std::get<1>(prism_rtl::some_of(_m));
            if (!is_mark_char_f(crate::syntax::lexer::chars::char_at_f(this_))) {
                break;
            }
            this_ = next_p2;
        }
        (std::move(this_));
    });
    return crate::prelude::before(c_p1);
}


/// IsMarkChar: fn Text -> Bool
bool is_mark_char_f(const Text& c_p0) {
    return (((((c_p0 == Text::lit("$")) || (c_p0 == Text::lit("!"))) || (c_p0 == Text::lit("@"))) || (c_p0 == Text::lit("?"))) || (c_p0 == Text::lit("~"))) || (c_p0 == Text::lit("&"));
}


/// LowerLevels: fn St, [Nat], Nat -> St
crate::check::types::St lower_levels_f(const crate::check::types::St& st_p0, const Array<Nat>& vs_p1, const Nat& level_p2) {
    return crate::prelude::fold(vs_p1, st_p0, [&](const crate::check::types::St& s_p3, const Nat& v_p4) { return lower_one_f(s_p3, v_p4, level_p2); });
}


/// LowerOne: fn St, Nat, Nat -> St
crate::check::types::St lower_one_f(const crate::check::types::St& s_p0, const Nat& v_p1, const Nat& level_p2) {
    auto i_p3 = crate::check::types::recording::info_of_f(s_p0, v_p1);
    return prism_rtl::deref(i_p3).level_p <= level_p2
        ? s_p0
        : ({
        crate::check::types::St this_ = s_p0;
        this_.infos_p = crate::prelude::insert(this_.infos_p, v_p1, crate::check::types::VInfo{.plain_p = prism_rtl::deref(i_p3).plain_p, .level_p = level_p2, .name_p = prism_rtl::deref(i_p3).name_p});
        (std::move(this_));
    });
}


/// UnifyRow: unbounded fn St, Rw, Rw, Range -> ((Text, St))
std::tuple<Text, crate::check::types::St> unify_row_f(const crate::check::types::St& st_p0, const crate::check::types::Rw& a0_p1, const crate::check::types::Rw& b0_p2, const crate::syntax::Range& span_p3) {
    auto a_p4 = crate::check::types::recording::walk_row_f(st_p0, a0_p1);
    auto b_p5 = crate::check::types::recording::walk_row_f(st_p0, b0_p2);
    auto only_a_p6 = crate::check::types::minus_texts_f(prism_rtl::deref(a_p4).fams_p, prism_rtl::deref(b_p5).fams_p);
    auto only_b_p7 = crate::check::types::minus_texts_f(prism_rtl::deref(b_p5).fams_p, prism_rtl::deref(a_p4).fams_p);
    auto&& _m = std::tuple{prism_rtl::deref(a_p4).tail_p, prism_rtl::deref(b_p5).tail_p};
    if (prism_rtl::is<crate::check::types::Tail::TlClosed>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Tail::TlClosed>(std::get<1>(_m))) {
        return (crate::prelude::len(only_a_p6) == Nat(0u)) && (crate::prelude::len(only_b_p7) == Nat(0u))
            ? std::tuple{Text::lit(""), st_p0}
            : std::tuple{Text::lit("mismatch"), st_p0};
    }
    if (prism_rtl::is<crate::check::types::Tail::TlFlex>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Tail::TlFlex>(std::get<1>(_m))) {
        auto&& x_p8 = prism_rtl::as<crate::check::types::Tail::TlFlex>(std::get<0>(_m)).a0;
        auto&& y_p9 = prism_rtl::as<crate::check::types::Tail::TlFlex>(std::get<1>(_m)).a0;
        return x_p8 == y_p9
            ? (crate::prelude::len(only_a_p6) == Nat(0u)) && (crate::prelude::len(only_b_p7) == Nat(0u))
            ? std::tuple{Text::lit(""), st_p0}
            : std::tuple{Text::lit("mismatch"), st_p0}
            : ({
            auto lacking_pa = crate::check::types::union_texts_f(crate::check::types::union_texts_f(lacks_of_f(st_p0, x_p8), lacks_of_f(st_p0, y_p9)), crate::check::types::union_texts_f(prism_rtl::deref(a_p4).fams_p, prism_rtl::deref(b_p5).fams_p));
            auto [fresh_pb, st2_pc] = crate::check::types::recording::fresh_row_f(st_p0, lacking_pa);
            auto [v1_pd, st3_pe] = bind_row_f(st2_pc, x_p8, crate::check::types::Rw{.fams_p = only_b_p7, .minus_p = Array<Text>{}, .tail_p = prism_rtl::deref(fresh_pb).tail_p}, span_p3);
            v1_pd != Text::lit("")
            ? std::tuple{v1_pd, st3_pe}
            : bind_row_f(st3_pe, y_p9, crate::check::types::Rw{.fams_p = only_a_p6, .minus_p = Array<Text>{}, .tail_p = prism_rtl::deref(fresh_pb).tail_p}, span_p3);
        });
    }
    if (prism_rtl::is<crate::check::types::Tail::TlFlex>(std::get<0>(_m))) {
        auto&& x_pf = prism_rtl::as<crate::check::types::Tail::TlFlex>(std::get<0>(_m)).a0;
        auto&& other_pg = std::get<1>(_m);
        return crate::prelude::len(only_a_p6) == Nat(0u)
            ? bind_row_f(st_p0, x_pf, crate::check::types::Rw{.fams_p = only_b_p7, .minus_p = prism_rtl::deref(b_p5).minus_p, .tail_p = other_pg}, span_p3)
            : std::tuple{Text::lit("mismatch"), st_p0};
    }
    if (prism_rtl::is<crate::check::types::Tail::TlFlex>(std::get<1>(_m))) {
        auto&& other_ph = std::get<0>(_m);
        auto&& y_pi = prism_rtl::as<crate::check::types::Tail::TlFlex>(std::get<1>(_m)).a0;
        return crate::prelude::len(only_b_p7) == Nat(0u)
            ? bind_row_f(st_p0, y_pi, crate::check::types::Rw{.fams_p = only_a_p6, .minus_p = prism_rtl::deref(a_p4).minus_p, .tail_p = other_ph}, span_p3)
            : std::tuple{Text::lit("mismatch"), st_p0};
    }
    if (prism_rtl::is<crate::check::types::Tail::TlRigid>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Tail::TlRigid>(std::get<1>(_m))) {
        auto&& x_pj = prism_rtl::as<crate::check::types::Tail::TlRigid>(std::get<0>(_m)).a0;
        auto&& y_pk = prism_rtl::as<crate::check::types::Tail::TlRigid>(std::get<1>(_m)).a0;
        return ((x_pj == y_pk) && (crate::prelude::len(only_a_p6) == Nat(0u))) && (crate::prelude::len(only_b_p7) == Nat(0u))
            ? std::tuple{Text::lit(""), st_p0}
            : std::tuple{Text::lit("mismatch"), st_p0};
    }
    if (prism_rtl::is<crate::check::types::Tail::TlQ>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Tail::TlQ>(std::get<1>(_m))) {
        auto&& x_pl = prism_rtl::as<crate::check::types::Tail::TlQ>(std::get<0>(_m)).a0;
        auto&& y_pm = prism_rtl::as<crate::check::types::Tail::TlQ>(std::get<1>(_m)).a0;
        return ((x_pl == y_pm) && (crate::prelude::len(only_a_p6) == Nat(0u))) && (crate::prelude::len(only_b_p7) == Nat(0u))
            ? std::tuple{Text::lit(""), st_p0}
            : std::tuple{Text::lit("mismatch"), st_p0};
    }
    {
        return std::tuple{Text::lit("mismatch"), st_p0};
    }
}


prism_rtl::Turn<std::tuple<Text, crate::check::types::St>> UnifyRow::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& a0_p1 = this->a0_p1;
    const auto& b0_p2 = this->b0_p2;
    const auto& span_p3 = this->span_p3;
    auto a0_p1x = a0_p1;
    auto b0_p2x = b0_p2;
    auto span_p3x = span_p3;
    auto st_p0x = st_p0;
    return crate::prelude::call_then(crate::check::types::recording::start_walk_row_f(st_p0x, a0_p1x), [=](crate::check::types::Rw walk_row_f_8688) {
        return ({
            auto a_p4 = walk_row_f_8688;
            (crate::prelude::call_then(crate::check::types::recording::start_walk_row_f(st_p0x, b0_p2x), [=, a_p4 = std::move(a_p4)](crate::check::types::Rw walk_row_f_8715) {
            return ({
                auto b_p5 = walk_row_f_8715;
                auto only_a_p6 = crate::check::types::minus_texts_f(prism_rtl::deref(a_p4).fams_p, prism_rtl::deref(b_p5).fams_p);
                auto only_b_p7 = crate::check::types::minus_texts_f(prism_rtl::deref(b_p5).fams_p, prism_rtl::deref(a_p4).fams_p);
                ({
                auto&& _m = std::tuple{prism_rtl::deref(a_p4).tail_p, prism_rtl::deref(b_p5).tail_p};
                prism_rtl::is<crate::check::types::Tail::TlClosed>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Tail::TlClosed>(std::get<1>(_m)) ? (crate::prelude::len(only_a_p6) == Nat(0u)) && (crate::prelude::len(only_b_p7) == Nat(0u))
                ? prism_rtl::finished(std::tuple{Text::lit(""), st_p0x})
                : prism_rtl::finished(std::tuple{Text::lit("mismatch"), st_p0x})
                : prism_rtl::is<crate::check::types::Tail::TlFlex>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Tail::TlFlex>(std::get<1>(_m)) ? ({
                auto&& x_p8 = prism_rtl::as<crate::check::types::Tail::TlFlex>(std::get<0>(_m)).a0;
                auto&& y_p9 = prism_rtl::as<crate::check::types::Tail::TlFlex>(std::get<1>(_m)).a0;
                x_p8 == y_p9
                ? (crate::prelude::len(only_a_p6) == Nat(0u)) && (crate::prelude::len(only_b_p7) == Nat(0u))
                ? prism_rtl::finished(std::tuple{Text::lit(""), st_p0x})
                : prism_rtl::finished(std::tuple{Text::lit("mismatch"), st_p0x})
                : ({
                auto lacking_pa = crate::check::types::union_texts_f(crate::check::types::union_texts_f(lacks_of_f(st_p0x, x_p8), lacks_of_f(st_p0x, y_p9)), crate::check::types::union_texts_f(prism_rtl::deref(a_p4).fams_p, prism_rtl::deref(b_p5).fams_p));
                auto [fresh_pb, st2_pc] = crate::check::types::recording::fresh_row_f(st_p0x, lacking_pa);
                (crate::prelude::call_then(start_bind_row_f(st2_pc, x_p8, crate::check::types::Rw{.fams_p = only_b_p7, .minus_p = Array<Text>{}, .tail_p = prism_rtl::deref(fresh_pb).tail_p}, span_p3x), [=](std::tuple<Text, crate::check::types::St> bind_row_f_9329) {
                return ({
                    auto [v1_pd, st3_pe] = bind_row_f_9329;
                    v1_pd != Text::lit("")
                    ? prism_rtl::finished(std::tuple{v1_pd, st3_pe})
                    : prism_rtl::more(prism_rtl::rc(BindRow(st3_pe, y_p9, crate::check::types::Rw{.fams_p = only_a_p6, .minus_p = Array<Text>{}, .tail_p = prism_rtl::deref(fresh_pb).tail_p}, span_p3x)));
                });
            }));
            });
            })
                : prism_rtl::is<crate::check::types::Tail::TlFlex>(std::get<0>(_m)) ? ({
                auto&& x_pf = prism_rtl::as<crate::check::types::Tail::TlFlex>(std::get<0>(_m)).a0;
                auto&& other_pg = std::get<1>(_m);
                crate::prelude::len(only_a_p6) == Nat(0u)
                ? prism_rtl::more(prism_rtl::rc(BindRow(st_p0x, x_pf, crate::check::types::Rw{.fams_p = only_b_p7, .minus_p = prism_rtl::deref(b_p5).minus_p, .tail_p = other_pg}, span_p3x)))
                : prism_rtl::finished(std::tuple{Text::lit("mismatch"), st_p0x});
            })
                : prism_rtl::is<crate::check::types::Tail::TlFlex>(std::get<1>(_m)) ? ({
                auto&& other_ph = std::get<0>(_m);
                auto&& y_pi = prism_rtl::as<crate::check::types::Tail::TlFlex>(std::get<1>(_m)).a0;
                crate::prelude::len(only_b_p7) == Nat(0u)
                ? prism_rtl::more(prism_rtl::rc(BindRow(st_p0x, y_pi, crate::check::types::Rw{.fams_p = only_a_p6, .minus_p = prism_rtl::deref(a_p4).minus_p, .tail_p = other_ph}, span_p3x)))
                : prism_rtl::finished(std::tuple{Text::lit("mismatch"), st_p0x});
            })
                : prism_rtl::is<crate::check::types::Tail::TlRigid>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Tail::TlRigid>(std::get<1>(_m)) ? ({
                auto&& x_pj = prism_rtl::as<crate::check::types::Tail::TlRigid>(std::get<0>(_m)).a0;
                auto&& y_pk = prism_rtl::as<crate::check::types::Tail::TlRigid>(std::get<1>(_m)).a0;
                ((x_pj == y_pk) && (crate::prelude::len(only_a_p6) == Nat(0u))) && (crate::prelude::len(only_b_p7) == Nat(0u))
                ? prism_rtl::finished(std::tuple{Text::lit(""), st_p0x})
                : prism_rtl::finished(std::tuple{Text::lit("mismatch"), st_p0x});
            })
                : prism_rtl::is<crate::check::types::Tail::TlQ>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Tail::TlQ>(std::get<1>(_m)) ? ({
                auto&& x_pl = prism_rtl::as<crate::check::types::Tail::TlQ>(std::get<0>(_m)).a0;
                auto&& y_pm = prism_rtl::as<crate::check::types::Tail::TlQ>(std::get<1>(_m)).a0;
                ((x_pl == y_pm) && (crate::prelude::len(only_a_p6) == Nat(0u))) && (crate::prelude::len(only_b_p7) == Nat(0u))
                ? prism_rtl::finished(std::tuple{Text::lit(""), st_p0x})
                : prism_rtl::finished(std::tuple{Text::lit("mismatch"), st_p0x});
            })
                : prism_rtl::finished(std::tuple{Text::lit("mismatch"), st_p0x});
            });
            });
        }));
        });
    });
}


/// `Start UnifyRow, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Text, crate::check::types::St>> start_unify_row_f(crate::check::types::St st_p0, crate::check::types::Rw a0_p1, crate::check::types::Rw b0_p2, crate::syntax::Range span_p3) {
    return prism_rtl::make_rc<UnifyRow>(st_p0, a0_p1, b0_p2, span_p3);
}


/// AskField: fn St, Ty, Text, Ty, Range, [Text] -> St
crate::check::types::St ask_field_f(const crate::check::types::St& st_p0, const crate::check::types::Ty& recv_p1, const Text& field_p2, const crate::check::types::Ty& result_p3, const crate::syntax::Range& span_p4, const Array<Text>& owners_p5) {
    crate::check::types::St this_ = st_p0;
    this_.field_qs_p = crate::prelude::push(this_.field_qs_p, FieldQ{.recv_p = recv_p1, .field_p = field_p2, .result_p = result_p3, .span_p = span_p4, .file_p = this_.file_p, .owners_p = owners_p5, .marks_o = std::optional<std::tuple<Text, crate::syntax::Range>>{}});
    return this_;
}


/// MarkLastField: fn St, Ty, Text, Range -> St
crate::check::types::St mark_last_field_f(const crate::check::types::St& st_p0, const crate::check::types::Ty& result_p1, const Text& marks_p2, const crate::syntax::Range& at_p3) {
    crate::check::types::St this_ = st_p0;
    this_.field_qs_p = crate::prelude::each(this_.field_qs_p, [&](const FieldQ& q_p4) {
        return (prism_rtl::deref(q_p4).result_p == result_p1) && (prism_rtl::deref(q_p4).marks_o == std::optional<std::tuple<Text, crate::syntax::Range>>{})
            ? ({
            FieldQ this_ = q_p4;
            this_.marks_o = std::optional(std::tuple{marks_p2, at_p3});
            (std::move(this_));
        })
            : q_p4;
    });
    return this_;
}


/// AskLayer: fn St, Ty, Range, Text -> St
crate::check::types::St ask_layer_f(const crate::check::types::St& st_p0, const crate::check::types::Ty& t_p1, const crate::syntax::Range& span_p2, const Text& fname_p3) {
    crate::check::types::St this_ = st_p0;
    this_.layer_qs_p = crate::prelude::push(this_.layer_qs_p, std::tuple{t_p1, span_p2, fname_p3});
    return this_;
}


/// LayerQuestions: unbounded fn St -> St
crate::check::types::St layer_questions_f(const crate::check::types::St& st_p0) {
    auto qs_p1 = st_p0.layer_qs_p;
    auto cleared_p2 = ({
        crate::check::types::St this_ = st_p0;
        this_.layer_qs_p = Array<std::tuple<crate::check::types::Ty, crate::syntax::Range, Text>>{};
        (std::move(this_));
    });
    return crate::prelude::run_to_end(crate::prelude::fold_job(qs_p1, cleared_p2, static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, std::tuple<crate::check::types::Ty, crate::syntax::Range, Text>>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, std::tuple<crate::check::types::Ty, crate::syntax::Range, Text>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto s_p3 = p0;
                auto [t_p4, span_p5, fname_p6] = p1;
                (crate::prelude::call_then(crate::check::types::start_head_sigil_f(s_p3, t_p4), [=](Text head_sigil_f_11857) {
                return ({
                    auto h_p7 = head_sigil_f_11857;
                    (crate::prelude::call_then(crate::check::types::start_is_free_headed_f(s_p3, t_p4), [=, h_p7 = std::move(h_p7)](bool is_free_headed_f_11884) {
                    return (is_free_headed_f_11884 || (h_p7 == Text::lit("$"))) || (h_p7 == Text::lit("!"))
                        ? prism_rtl::finished(crate::check::types::recording::err_fix_f(s_p3, Text::lit("layer-unknown"), span_p5, prism_rtl::cat("the layer of this argument to `", fname_p6, "` is not known here"), Text::lit("say it where the value is made: a name whose marks declare the layer (`let $x = ...`), `<<T>>` at the application that made it, or a signature on the enclosing `let`")))
                        : prism_rtl::finished(s_p3);
                }));
                });
            }));
            });
        }));
    }))));
}


prism_rtl::Turn<crate::check::types::St> LayerQuestions::cycle() const {
    const auto& st_p0 = this->st_p0;
    auto qs_p1 = prism_rtl::deref(st_p0).layer_qs_p;
    auto cleared_p2 = ({
        crate::check::types::St this_ = st_p0;
        this_.layer_qs_p = Array<std::tuple<crate::check::types::Ty, crate::syntax::Range, Text>>{};
        (std::move(this_));
    });
    return crate::prelude::fold_job(qs_p1, cleared_p2, static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, std::tuple<crate::check::types::Ty, crate::syntax::Range, Text>>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, std::tuple<crate::check::types::Ty, crate::syntax::Range, Text>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto s_p3 = p0;
                auto [t_p4, span_p5, fname_p6] = p1;
                (crate::prelude::call_then(crate::check::types::start_head_sigil_f(s_p3, t_p4), [=](Text head_sigil_f_11857) {
                return ({
                    auto h_p7 = head_sigil_f_11857;
                    (crate::prelude::call_then(crate::check::types::start_is_free_headed_f(s_p3, t_p4), [=, h_p7 = std::move(h_p7)](bool is_free_headed_f_11884) {
                    return (is_free_headed_f_11884 || (h_p7 == Text::lit("$"))) || (h_p7 == Text::lit("!"))
                        ? prism_rtl::finished(crate::check::types::recording::err_fix_f(s_p3, Text::lit("layer-unknown"), span_p5, prism_rtl::cat("the layer of this argument to `", fname_p6, "` is not known here"), Text::lit("say it where the value is made: a name whose marks declare the layer (`let $x = ...`), `<<T>>` at the application that made it, or a signature on the enclosing `let`")))
                        : prism_rtl::finished(s_p3);
                }));
                });
            }));
            });
        }));
    })))->cycle();
}


/// `Start LayerQuestions, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_layer_questions_f(crate::check::types::St st_p0) {
    return prism_rtl::make_rc<LayerQuestions>(st_p0);
}


/// NameRow: fn St, Tail, Text -> St
crate::check::types::St name_row_f(const crate::check::types::St& st_p0, const crate::check::types::Tail& tail1, const Text& text2) {
    auto&& _m = std::tuple{tail1, text2};
    if (prism_rtl::is<crate::check::types::Tail::TlFlex>(std::get<0>(_m))) {
        auto&& n_p1 = prism_rtl::as<crate::check::types::Tail::TlFlex>(std::get<0>(_m)).a0;
        auto&& q_p2 = std::get<1>(_m);
        crate::check::types::St this_ = st_p0;
        this_.row_names_p = crate::prelude::insert(this_.row_names_p, n_p1, q_p2);
        return this_;
    }
    {
        return st_p0;
    }
    prism_rtl::unreachable("no arm matched");
}


/// RowName: fn St, Nat -> Text
Text row_name_f(const crate::check::types::St& st_p0, const Nat& n_p1) {
    return crate::prelude::or_(crate::prelude::get(st_p0.row_names_p, n_p1), prism_rtl::cat("r", n_p1));
}


/// LacksOf: fn St, Nat -> [Text]
Array<Text> lacks_of_f(const crate::check::types::St& st_p0, const Nat& n_p1) {
    return crate::prelude::or_(crate::prelude::get(st_p0.lacks_p, n_p1), Array<Text>{});
}


/// BindRow: unbounded fn St, Nat, Rw, Range -> ((Text, St))
std::tuple<Text, crate::check::types::St> bind_row_f(const crate::check::types::St& st_p0, const Nat& n_p1, const crate::check::types::Rw& rw_p2, const crate::syntax::Range& span_p3) {
    auto bad_p4 = crate::check::types::inter_texts_f(lacks_of_f(st_p0, n_p1), rw_p2.fams_p);
    return crate::prelude::len(bad_p4) > Nat(0u)
        ? ({
        auto fam_p5 = crate::prelude::or_(crate::prelude::index(bad_p4, Nat(0u)), Text::lit(""));
        std::tuple{Text::lit("reported"), crate::check::types::recording::err_fix_f(st_p0, Text::lit("row-lacks"), span_p3, prism_rtl::cat("`", row_name_f(st_p0, n_p1), " | ", fam_p5, ".*` promises `", row_name_f(st_p0, n_p1), "` has no `", fam_p5, "` tags"), prism_rtl::cat("answer the `", fam_p5, "` tags before this point, or widen the row"))};
    })
        : ({
        auto st2_p6 = ({
            __label__ _done;
            prism_rtl::Slot<crate::check::types::St> _v;
            auto&& _m = rw_p2.tail_p;
            if (prism_rtl::is<crate::check::types::Tail::TlFlex>(_m)) {
                auto&& m_p7 = prism_rtl::as<crate::check::types::Tail::TlFlex>(_m).a0;
                _v.set(({
                    crate::check::types::St this_ = st_p0;
                    this_.lacks_p = crate::prelude::insert(this_.lacks_p, m_p7, crate::check::types::union_texts_f(lacks_of_f(st_p0, m_p7), lacks_of_f(st_p0, n_p1)));
                    (std::move(this_));
                }));
                goto _done;
            }
            {
                _v.set(st_p0);
                goto _done;
            }
        _done:
            _v.take();
        });
        std::tuple{Text::lit(""), ({
        crate::check::types::St this_ = st2_p6;
        this_.rows_p = crate::prelude::insert(this_.rows_p, n_p1, rw_p2);
        (std::move(this_));
    })};
    });
}


prism_rtl::Turn<std::tuple<Text, crate::check::types::St>> BindRow::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& n_p1 = this->n_p1;
    const auto& rw_p2 = this->rw_p2;
    const auto& span_p3 = this->span_p3;
    auto bad_p4 = crate::check::types::inter_texts_f(lacks_of_f(st_p0, n_p1), prism_rtl::deref(rw_p2).fams_p);
    return crate::prelude::len(bad_p4) > Nat(0u)
        ? ({
        auto fam_p5 = crate::prelude::or_(crate::prelude::index(bad_p4, Nat(0u)), Text::lit(""));
        (prism_rtl::finished(std::tuple{Text::lit("reported"), crate::check::types::recording::err_fix_f(st_p0, Text::lit("row-lacks"), span_p3, prism_rtl::cat("`", row_name_f(st_p0, n_p1), " | ", fam_p5, ".*` promises `", row_name_f(st_p0, n_p1), "` has no `", fam_p5, "` tags"), prism_rtl::cat("answer the `", fam_p5, "` tags before this point, or widen the row"))}));
    })
        : ({
        auto st2_p6 = ({
            __label__ _done;
            prism_rtl::Slot<crate::check::types::St> _v;
            auto&& _m = prism_rtl::deref(rw_p2).tail_p;
            if (prism_rtl::is<crate::check::types::Tail::TlFlex>(_m)) {
                auto&& m_p7 = prism_rtl::as<crate::check::types::Tail::TlFlex>(_m).a0;
                _v.set(({
                    crate::check::types::St this_ = st_p0;
                    this_.lacks_p = crate::prelude::insert(this_.lacks_p, m_p7, crate::check::types::union_texts_f(lacks_of_f(st_p0, m_p7), lacks_of_f(st_p0, n_p1)));
                    (std::move(this_));
                }));
                goto _done;
            }
            {
                _v.set(st_p0);
                goto _done;
            }
        _done:
            _v.take();
        });
        (prism_rtl::finished(std::tuple{Text::lit(""), ({
        crate::check::types::St this_ = st2_p6;
        this_.rows_p = crate::prelude::insert(this_.rows_p, n_p1, rw_p2);
        (std::move(this_));
    })}));
    });
}


/// `Start BindRow, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Text, crate::check::types::St>> start_bind_row_f(crate::check::types::St st_p0, Nat n_p1, crate::check::types::Rw rw_p2, crate::syntax::Range span_p3) {
    return prism_rtl::make_rc<BindRow>(st_p0, n_p1, rw_p2, span_p3);
}

}  // namespace crate::check::types::unify


// The module `Checking`, from `target/bootstrap/cpp-src/prismc/checking.prism`.
namespace crate::checking {

void CheckJob::show(Printer& p) const {
    p.record("CheckJob", {{"read", read_p}, {"world", world_p}, {"typed", typed_p}, {"unused", unused_p}});
}

Pod CheckJob::to_pod() const {
    return Pod::record("CheckJob", {{"read", prism_rtl::to_pod(read_p)}, {"world", prism_rtl::to_pod(world_p)}, {"typed", prism_rtl::to_pod(typed_p)}, {"unused", prism_rtl::to_pod(unused_p)}});
}

Result<CheckJob> CheckJob::from_pod(const Pod& whole) {
    return CheckJob{.read_p = TRY(prism_rtl::from_pod<crate::reading::ReadInput>(TRY(crate::prelude::field(whole, "read")))), .world_p = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "world")))), .typed_p = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "typed")))), .unused_p = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "unused"))))};
}


/// CheckFiles: unbounded fn CheckJob -> Outcome
crate::program::Outcome_ check_files_f(const CheckJob& job_p0) {
    auto read_p1 = crate::reading::assemble_f(job_p0.read_p);
    return crate::prelude::len(prism_rtl::deref(read_p1).errors_p) > Nat(0u)
        ? ({
        auto report_p2 = crate::reading::tree_report_f(job_p0.read_p, prism_rtl::deref(read_p1).errors_p);
        crate::program::Outcome_{.text_p = prism_rtl::cat(report_p2, "\n"), .failed_p = true, .report_p = report_p2};
    })
        : ({
        auto pp_p3 = crate::reading::parse_program_f(read_p1);
        (prism_rtl::deref(pp_p3).errors_p != Text::lit("")
        ? crate::program::Outcome_{.text_p = prism_rtl::cat(prism_rtl::deref(pp_p3).errors_p, "parse errors\n"), .failed_p = true, .report_p = prism_rtl::cat(prism_rtl::deref(pp_p3).errors_p, "parse errors")}
        : ({
        auto pre_p4 = crate::reading::tree_decl_diags_f(pp_p3);
        auto checked_p5 = crate::prelude::each(prism_rtl::deref(pp_p3).trees_p, [&](const crate::syntax::Module& t_p9) { return crate::compile::without_tests_f(t_p9); });
        auto report_p6 = crate::check::check_program_f(prism_rtl::deref(pp_p3).srcs_p, checked_p5, job_p0.world_p, prism_rtl::deref(pp_p3).shown_p, job_p0.typed_p, job_p0.unused_p, pre_p4);
        auto summary_p7 = prism_rtl::deref(report_p6).errors_p == Nat(0u)
            ? Text::lit("no errors\n")
            : prism_rtl::cat(prism_rtl::deref(report_p6).errors_p, " error", prism_rtl::deref(report_p6).errors_p == Nat(1u)
            ? Text::lit("")
            : Text::lit("s"), "\n");
        auto shown_p8 = job_p0.typed_p
            ? prism_rtl::cat(crate::check::typed::print::typed_sexp_f(prism_rtl::deref(pp_p3).srcs_p, checked_p5, prism_rtl::deref(pp_p3).shown_p, prism_rtl::deref(report_p6).typed_p), commented_f(prism_rtl::cat(prism_rtl::deref(report_p6).text_p, summary_p7)))
            : prism_rtl::cat(prism_rtl::deref(report_p6).text_p, summary_p7);
        crate::program::Outcome_{.text_p = shown_p8, .failed_p = prism_rtl::deref(report_p6).errors_p > Nat(0u), .report_p = prism_rtl::cat(prism_rtl::deref(report_p6).text_p, summary_p7)};
    }));
    });
}


prism_rtl::Turn<crate::program::Outcome_> CheckFiles::cycle() const {
    const auto& job_p0 = this->job_p0;
    auto job_p0x = job_p0;
    return crate::prelude::call_then(crate::reading::start_assemble_f(prism_rtl::deref(job_p0x).read_p), [=](crate::reading::Assembled assemble_f_1698) {
        return ({
            auto read_p1 = assemble_f_1698;
            (crate::prelude::len(prism_rtl::deref(read_p1).errors_p) > Nat(0u)
            ? ({
            auto report_p2 = crate::reading::tree_report_f(prism_rtl::deref(job_p0x).read_p, prism_rtl::deref(read_p1).errors_p);
            (prism_rtl::finished(crate::program::Outcome_{.text_p = prism_rtl::cat(report_p2, "\n"), .failed_p = true, .report_p = report_p2}));
        })
            : crate::prelude::call_then(crate::reading::start_parse_program_f(read_p1), [=](crate::reading::ParsedProgram parse_program_f_1890) {
            return ({
                auto pp_p3 = parse_program_f_1890;
                (prism_rtl::deref(pp_p3).errors_p != Text::lit("")
                ? prism_rtl::finished(crate::program::Outcome_{.text_p = prism_rtl::cat(prism_rtl::deref(pp_p3).errors_p, "parse errors\n"), .failed_p = true, .report_p = prism_rtl::cat(prism_rtl::deref(pp_p3).errors_p, "parse errors")})
                : ({
                auto pre_p4 = crate::reading::tree_decl_diags_f(pp_p3);
                auto checked_p5 = crate::prelude::each(prism_rtl::deref(pp_p3).trees_p, [&](const crate::syntax::Module& t_p9) { return crate::compile::without_tests_f(t_p9); });
                (crate::prelude::call_then(crate::check::start_check_program_f(prism_rtl::deref(pp_p3).srcs_p, checked_p5, prism_rtl::deref(job_p0x).world_p, prism_rtl::deref(pp_p3).shown_p, prism_rtl::deref(job_p0x).typed_p, prism_rtl::deref(job_p0x).unused_p, pre_p4), [=](crate::check::Report_ check_program_f_2313) {
                return ({
                    auto report_p6 = check_program_f_2313;
                    auto summary_p7 = prism_rtl::deref(report_p6).errors_p == Nat(0u)
                        ? Text::lit("no errors\n")
                        : prism_rtl::cat(prism_rtl::deref(report_p6).errors_p, " error", prism_rtl::deref(report_p6).errors_p == Nat(1u)
                        ? Text::lit("")
                        : Text::lit("s"), "\n");
                    auto shown_p8 = prism_rtl::deref(job_p0x).typed_p
                        ? prism_rtl::cat(crate::check::typed::print::typed_sexp_f(prism_rtl::deref(pp_p3).srcs_p, checked_p5, prism_rtl::deref(pp_p3).shown_p, prism_rtl::deref(report_p6).typed_p), commented_f(prism_rtl::cat(prism_rtl::deref(report_p6).text_p, summary_p7)))
                        : prism_rtl::cat(prism_rtl::deref(report_p6).text_p, summary_p7);
                    (prism_rtl::finished(crate::program::Outcome_{.text_p = shown_p8, .failed_p = prism_rtl::deref(report_p6).errors_p > Nat(0u), .report_p = prism_rtl::cat(prism_rtl::deref(report_p6).text_p, summary_p7)}));
                });
            }));
            }));
            });
        }));
        });
    });
}


/// `Start CheckFiles, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::program::Outcome_> start_check_files_f(CheckJob job_p0) {
    return prism_rtl::make_rc<CheckFiles>(job_p0);
}


/// Commented: fn Text -> Text
Text commented_f(const Text& t_p0) {
    return crate::prelude::concat(crate::prelude::each(crate::prelude::filter(crate::prelude::split_on(t_p0, Text::lit("\n")), [&](const Text& l_p1) { return l_p1 != Text::lit(""); }), [&](const Text& l_p2) { return prism_rtl::cat("; ", l_p2, "\n"); }));
}


// `@CheckMain` is inlined where it is applied.

/// let checkValued
Array<Text> check_valued_p() {
    return Array(std::vector{Text::lit("--prelude"), Text::lit("--out"), Text::lit("--world")});
}


// `@FinishCheck` is inlined where it is applied.

// `@WriteOut` is inlined where it is applied.

}  // namespace crate::checking


// The module `Compile`, from `target/bootstrap/cpp-src/prismc/compile.prism`.
namespace crate::compile {

void CompileJob::show(Printer& p) const {
    p.record("CompileJob", {{"read", read_p}, {"name", name_p}, {"runtime", runtime_p}, {"target", target_p}});
}

Pod CompileJob::to_pod() const {
    return Pod::record("CompileJob", {{"read", prism_rtl::to_pod(read_p)}, {"name", prism_rtl::to_pod(name_p)}, {"runtime", prism_rtl::to_pod(runtime_p)}, {"target", prism_rtl::to_pod(target_p)}});
}

Result<CompileJob> CompileJob::from_pod(const Pod& whole) {
    return CompileJob{.read_p = TRY(prism_rtl::from_pod<crate::reading::ReadInput>(TRY(crate::prelude::field(whole, "read")))), .name_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .runtime_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "runtime")))), .target_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "target"))))};
}


void Compiled::show(Printer& p) const {
    p.record("Compiled", {{"files", files_p}, {"failed", failed_p}, {"report", report_p}});
}

Pod Compiled::to_pod() const {
    return Pod::record("Compiled", {{"files", prism_rtl::to_pod(files_p)}, {"failed", prism_rtl::to_pod(failed_p)}, {"report", prism_rtl::to_pod(report_p)}});
}

Result<Compiled> Compiled::from_pod(const Pod& whole) {
    return Compiled{.files_p = TRY(prism_rtl::from_pod<Array<std::tuple<Text, Text>>>(TRY(crate::prelude::field(whole, "files")))), .failed_p = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "failed")))), .report_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "report"))))};
}


// `@CompileMain` is inlined where it is applied.

/// let compileValued
Array<Text> compile_valued_p() {
    return Array(std::vector{Text::lit("-o"), Text::lit("--prelude"), Text::lit("--name"), Text::lit("--runtime"), Text::lit("--target")});
}


/// ?RuntimeOf: fn ?Text, ?Text, Text -> ?Text
std::optional<Text> runtime_of_o(const std::optional<Text>& named_o0, const std::optional<Text>& root_o1, const Text& out_p2) {
    if (prism_rtl::is_some(named_o0)) {
        auto&& r_p3 = prism_rtl::some_of(named_o0);
        return std::optional(r_p3);
    }
    if (prism_rtl::is_none(named_o0)) {
        return !crate::syntax::lexer::chars::has_prefix_f(out_p2, Text::lit("/"))
            ? std::optional(runtime_for_f(out_p2))
            : root_o1;
    }
    prism_rtl::unreachable("no arm matched");
}


/// RuntimeFor: fn Text -> Text
Text runtime_for_f(const Text& out_p0) {
    auto parts_p1 = crate::prelude::filter(crate::prelude::split_on(out_p0, Text::lit("/")), [&](const Text& p_p2) { return (p_p2 != Text::lit("")) && (p_p2 != Text::lit(".")); });
    return crate::prelude::len(parts_p1) == Nat(0u)
        ? Text::lit(".")
        : crate::syntax::lexer::chars::join_f(crate::prelude::each(parts_p1, [&](const Text& _p0) { return Text::lit(".."); }), Text::lit("/"));
}


/// CompileProgram: unbounded fn CompileJob -> Compiled
Compiled compile_program_f(const CompileJob& job_p0) {
    auto read_p1 = crate::reading::assemble_f(job_p0.read_p);
    return crate::prelude::len(prism_rtl::deref(read_p1).errors_p) > Nat(0u)
        ? Compiled{.files_p = Array<std::tuple<Text, Text>>{}, .failed_p = true, .report_p = crate::reading::tree_report_f(job_p0.read_p, prism_rtl::deref(read_p1).errors_p)}
        : ({
        auto pp_p2 = crate::reading::parse_program_f(read_p1);
        (prism_rtl::deref(pp_p2).errors_p != Text::lit("")
        ? Compiled{.files_p = Array<std::tuple<Text, Text>>{}, .failed_p = true, .report_p = prism_rtl::cat(prism_rtl::deref(pp_p2).errors_p, "parse errors")}
        : ({
        auto pre_p3 = crate::reading::tree_decl_diags_f(pp_p2);
        auto report_p4 = crate::check::check_program_f(prism_rtl::deref(pp_p2).srcs_p, crate::prelude::each(prism_rtl::deref(pp_p2).trees_p, [&](const crate::syntax::Module& t_p5) { return without_tests_f(t_p5); }), Array<Text>{}, prism_rtl::deref(pp_p2).shown_p, true, false, pre_p3);
        (prism_rtl::deref(report_p4).errors_p > Nat(0u)
        ? Compiled{.files_p = Array<std::tuple<Text, Text>>{}, .failed_p = true, .report_p = prism_rtl::cat(prism_rtl::deref(report_p4).text_p, prism_rtl::deref(report_p4).errors_p, " error", prism_rtl::deref(report_p4).errors_p == Nat(1u)
        ? Text::lit("")
        : Text::lit("s"))}
        : ({
        auto model_p6 = crate::lower::program::lower_program_f(prism_rtl::deref(pp_p2).srcs_p, prism_rtl::deref(pp_p2).trees_p, prism_rtl::deref(pp_p2).shown_p, prism_rtl::deref(report_p4).typed_p, job_p0.name_p);
        auto files_p7 = job_p0.target_p == Text::lit("cpp")
            ? crate::emit::cpp::program::emit_cpp_f(model_p6, job_p0.runtime_p, prism_rtl::deref(read_p1).scripts_p)
            : crate::emit::rust::items::emit_crate_f(model_p6, job_p0.runtime_p, prism_rtl::deref(read_p1).scripts_p);
        auto refused_p8 = crate::prelude::fold(files_p7, Array<Text>{}, [&](const Array<Text>& acc_p9, const std::tuple<Text, Text>& _p1) {
            auto&& path_pa = std::get<0>(_p1);
            auto&& text_pb = std::get<1>(_p1);
            return crate::prelude::fold(refusals_f(text_pb), acc_p9, [&](const Array<Text>& a_pc, const Text& r_pd) { return crate::check::types::add_text_f(a_pc, prism_rtl::cat(path_pa, ": ", r_pd)); });
        });
        crate::prelude::len(refused_p8) == Nat(0u)
        ? Compiled{.files_p = files_p7, .failed_p = false, .report_p = Text::lit("")}
        : Compiled{.files_p = files_p7, .failed_p = true, .report_p = prism_rtl::cat(crate::prelude::concat(crate::prelude::each(refused_p8, [&](const Text& r_pe) { return prism_rtl::cat("error[not-lowered]: ", r_pe, "\n"); })), crate::prelude::len(refused_p8), " construct", crate::prelude::len(refused_p8) == Nat(1u) ? Text::lit("") : Text::lit("s"), " the back end does not lower (the crate is written, with a `compile_error!` at each)")};
    }));
    }));
    });
}


prism_rtl::Turn<Compiled> CompileProgram::cycle() const {
    const auto& job_p0 = this->job_p0;
    auto job_p0x = job_p0;
    return crate::prelude::call_then(crate::reading::start_assemble_f(prism_rtl::deref(job_p0x).read_p), [=](crate::reading::Assembled assemble_f_4670) {
        return ({
            auto read_p1 = assemble_f_4670;
            (crate::prelude::len(prism_rtl::deref(read_p1).errors_p) > Nat(0u)
            ? prism_rtl::finished(Compiled{.files_p = Array<std::tuple<Text, Text>>{}, .failed_p = true, .report_p = crate::reading::tree_report_f(prism_rtl::deref(job_p0x).read_p, prism_rtl::deref(read_p1).errors_p)})
            : crate::prelude::call_then(crate::reading::start_parse_program_f(read_p1), [=](crate::reading::ParsedProgram parse_program_f_4822) {
            return ({
                auto pp_p2 = parse_program_f_4822;
                (prism_rtl::deref(pp_p2).errors_p != Text::lit("")
                ? prism_rtl::finished(Compiled{.files_p = Array<std::tuple<Text, Text>>{}, .failed_p = true, .report_p = prism_rtl::cat(prism_rtl::deref(pp_p2).errors_p, "parse errors")})
                : ({
                auto pre_p3 = crate::reading::tree_decl_diags_f(pp_p2);
                (crate::prelude::call_then(crate::check::start_check_program_f(prism_rtl::deref(pp_p2).srcs_p, crate::prelude::each(prism_rtl::deref(pp_p2).trees_p, [&](const crate::syntax::Module& t_p5) { return without_tests_f(t_p5); }), Array<Text>{}, prism_rtl::deref(pp_p2).shown_p, true, false, pre_p3), [=](crate::check::Report_ check_program_f_5014) {
                return ({
                    auto report_p4 = check_program_f_5014;
                    (prism_rtl::deref(report_p4).errors_p > Nat(0u)
                    ? prism_rtl::finished(Compiled{.files_p = Array<std::tuple<Text, Text>>{}, .failed_p = true, .report_p = prism_rtl::cat(prism_rtl::deref(report_p4).text_p, prism_rtl::deref(report_p4).errors_p, " error", prism_rtl::deref(report_p4).errors_p == Nat(1u)
                    ? Text::lit("")
                    : Text::lit("s"))})
                    : crate::prelude::call_then(crate::lower::program::start_lower_program_f(prism_rtl::deref(pp_p2).srcs_p, prism_rtl::deref(pp_p2).trees_p, prism_rtl::deref(pp_p2).shown_p, prism_rtl::deref(report_p4).typed_p, prism_rtl::deref(job_p0x).name_p), [=](crate::lower::model::Model lower_program_f_5303) {
                    return ({
                        auto model_p6 = lower_program_f_5303;
                        auto files_p7 = prism_rtl::deref(job_p0x).target_p == Text::lit("cpp")
                            ? crate::emit::cpp::program::emit_cpp_f(model_p6, prism_rtl::deref(job_p0x).runtime_p, prism_rtl::deref(read_p1).scripts_p)
                            : crate::emit::rust::items::emit_crate_f(model_p6, prism_rtl::deref(job_p0x).runtime_p, prism_rtl::deref(read_p1).scripts_p);
                        auto refused_p8 = crate::prelude::fold(files_p7, Array<Text>{}, [&](const Array<Text>& acc_p9, const std::tuple<Text, Text>& _p1) {
                            auto&& path_pa = std::get<0>(_p1);
                            auto&& text_pb = std::get<1>(_p1);
                            return crate::prelude::fold(refusals_f(text_pb), acc_p9, [&](const Array<Text>& a_pc, const Text& r_pd) { return crate::check::types::add_text_f(a_pc, prism_rtl::cat(path_pa, ": ", r_pd)); });
                        });
                        (crate::prelude::len(refused_p8) == Nat(0u)
                        ? prism_rtl::finished(Compiled{.files_p = files_p7, .failed_p = false, .report_p = Text::lit("")})
                        : prism_rtl::finished(Compiled{.files_p = files_p7, .failed_p = true, .report_p = prism_rtl::cat(crate::prelude::concat(crate::prelude::each(refused_p8, [&](const Text& r_pe) { return prism_rtl::cat("error[not-lowered]: ", r_pe, "\n"); })), crate::prelude::len(refused_p8), " construct", crate::prelude::len(refused_p8) == Nat(1u) ? Text::lit("") : Text::lit("s"), " the back end does not lower (the crate is written, with a `compile_error!` at each)")}));
                    });
                }));
                });
            }));
            }));
            });
        }));
        });
    });
}


/// `Start CompileProgram, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Compiled> start_compile_program_f(CompileJob job_p0) {
    return prism_rtl::make_rc<CompileProgram>(job_p0);
}


/// Refusals: fn Text -> [Text]
Array<Text> refusals_f(const Text& text_p0) {
    auto marker_p1 = Text::lit("compile_error!(\"prismc does not lower ");
    auto parts_p2 = crate::prelude::split_on(text_p0, marker_p1);
    return crate::prelude::fold(crate::prelude::drop(parts_p2, Nat(1u)), Array<Text>{}, [&](const Array<Text>& acc_p3, const Text& part_p4) { return crate::check::types::add_text_f(acc_p3, crate::prelude::or_(crate::prelude::index(crate::prelude::split_on(part_p4, Text::lit("\")")), Nat(0u)), part_p4)); });
}


/// WithoutTests: fn Module -> Module
crate::syntax::Module without_tests_f(const crate::syntax::Module& m_p0) {
    crate::syntax::Module this_ = m_p0;
    this_.decls_p = crate::prelude::filter(this_.decls_p, [&](const crate::syntax::decls::Decl& d_p1) { return !is_test_decl_f(d_p1); });
    return this_;
}


/// IsTestDecl: fn Decl -> Bool
bool is_test_decl_f(const crate::syntax::decls::Decl& d_p0) {
    auto&& _m = d_p0.kind_p;
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DTest>(_m)) {
        return true;
    }
    {
        return false;
    }
}


// `@FinishCompile` is inlined where it is applied.

}  // namespace crate::compile
