// The modules `Check.Types.Unify`, `Checking`, `Compile`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <check/types/unify/module.hpp>
#include <check/types/module.hpp>
#include <syntax/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Check.Types.Unify`, from `target/bootstrap/cpp-src/prismc/check/types/unify.prism`.
namespace crate::check::types::unify {

void FieldQ::show(Printer& p) const {
    p.record("FieldQ", {{"recv", recv}, {"field", field}, {"result", result}, {"span", span}, {"file", file}, {"owners", owners}});
}

Pod FieldQ::to_pod() const {
    return Pod::record("FieldQ", {{"recv", prism_rtl::to_pod(recv)}, {"field", prism_rtl::to_pod(field)}, {"result", prism_rtl::to_pod(result)}, {"span", prism_rtl::to_pod(span)}, {"file", prism_rtl::to_pod(file)}, {"owners", prism_rtl::to_pod(owners)}});
}

Result<FieldQ> FieldQ::from_pod(const Pod& whole) {
    return FieldQ{.recv = TRY(prism_rtl::from_pod<crate::check::types::Ty>(TRY(crate::prelude::field(whole, "recv")))), .field = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "field")))), .result = TRY(prism_rtl::from_pod<crate::check::types::Ty>(TRY(crate::prelude::field(whole, "result")))), .span = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span")))), .file = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "file")))), .owners = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "owners"))))};
}


/// Unify: unbounded fn St, Ty, Ty, Range -> St
crate::check::types::St unify(const crate::check::types::St& st_p0, const crate::check::types::Ty& expected_p1, const crate::check::types::Ty& found_p2, const crate::syntax::Range& span_p3) {
    auto [verdict_p4, st2_p5] = unify_in(st_p0, expected_p1, found_p2, span_p3);
    return verdict_p4 == Text::lit("mismatch")
        ? ({
        auto e_p6 = crate::check::types::show_ty(st2_p5, expected_p1);
        auto f_p7 = crate::check::types::show_ty(st2_p5, found_p2);
        e_p6 == f_p7
        ? crate::check::types::recording::err(st2_p5, Text::lit("mismatch"), span_p3, prism_rtl::cat("expected `", show_ty_q(st2_p5, expected_p1), "`, found `", show_ty_q(st2_p5, found_p2), "`"))
        : crate::check::types::recording::err(st2_p5, Text::lit("mismatch"), span_p3, prism_rtl::cat("expected `", e_p6, "`, found `", f_p7, "`"));
    })
        : st2_p5;
}


prism_rtl::Turn<crate::check::types::St> Unify::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& expected_p1 = this->expected_p1;
    const auto& found_p2 = this->found_p2;
    const auto& span_p3 = this->span_p3;
    auto expected_p1_1 = expected_p1;
    auto found_p2_2 = found_p2;
    auto span_p3_3 = span_p3;
    auto st_p0_4 = st_p0;
    return call_then(start_unify_in(st_p0_4, expected_p1_1, found_p2_2, span_p3_3), [=](std::tuple<Text, crate::check::types::St> unify_in_1030) {
        return ({
            auto [verdict_p4, st2_p5] = unify_in_1030;
            verdict_p4 == Text::lit("mismatch")
            ? call_then(crate::check::types::start_show_ty(st2_p5, expected_p1_1), [=](Text show_ty_1110) {
            return ({
                auto e_p6 = show_ty_1110;
                call_then(crate::check::types::start_show_ty(st2_p5, found_p2_2), [=, e_p6 = std::move(e_p6)](Text show_ty_1147) {
                return ({
                    auto f_p7 = show_ty_1147;
                    e_p6 == f_p7
                    ? call_then(start_show_ty_q(st2_p5, expected_p1_1), [=](Text show_ty_q_1223) { return call_then(start_show_ty_q(st2_p5, found_p2_2), [=](Text show_ty_q_1256) { return prism_rtl::finished(crate::check::types::recording::err(st2_p5, Text::lit("mismatch"), span_p3_3, prism_rtl::cat("expected `", show_ty_q_1223, "`, found `", show_ty_q_1256, "`"))); }); })
                    : prism_rtl::finished(crate::check::types::recording::err(st2_p5, Text::lit("mismatch"), span_p3_3, prism_rtl::cat("expected `", e_p6, "`, found `", f_p7, "`")));
                });
            });
            });
        })
            : prism_rtl::finished(st2_p5);
        });
    });
}


/// `Start Unify, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_unify(crate::check::types::St st_p0, crate::check::types::Ty expected_p1, crate::check::types::Ty found_p2, crate::syntax::Range span_p3) {
    return prism_rtl::make_rc<Unify>(st_p0, expected_p1, found_p2, span_p3);
}


/// ShowTyQ: unbounded fn St, Ty -> Text
Text show_ty_q(const crate::check::types::St& st_p0, const crate::check::types::Ty& t_p1) {
    auto&& _m = crate::check::types::recording::zonk(st_p0, t_p1);
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
        auto&& n_p2 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
        auto&& m1487_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a1;
        if (m1487_0_1.size() == 0u) {
            return n_p2;
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
        auto&& n_p3 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
        auto&& args_p4 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a1;
        return prism_rtl::cat("(", n_p3, concat(run_to_end(each_job(args_p4, ({
            auto st_p0_1 = st_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::check::types::Ty)>>(prism_rtl::rc([=, st_p0_1 = std::move(st_p0_1)](crate::check::types::Ty p0) {
            return ({
                auto st_p0_1_2 = st_p0_1;
                entered(once_job([=, st_p0_1_2 = std::move(st_p0_1_2)]() {
                return ({
                    auto a_p5 = p0;
                    call_then(start_show_ty_q(st_p0_1_2, a_p5), [=](Text show_ty_q_1578) { return prism_rtl::finished(prism_rtl::cat(" ", show_ty_q_1578)); });
                });
            }));
            });
        })));
        })))), ")");
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(_m)) {
        auto&& s_p6 = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a0;
        auto&& i_p7 = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a1;
        return prism_rtl::cat(s_p6, show_ty_q(st_p0, prism_rtl::deref(i_p7)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(_m)) {
        auto&& e_p8 = prism_rtl::as<crate::check::types::Ty::TyArray>(_m).a0;
        auto inner_p9 = show_ty_q(st_p0, prism_rtl::deref(e_p8));
        return crate::syntax::lexer::chars::has_prefix(inner_p9, Text::lit("["))
            ? prism_rtl::cat("[ ", inner_p9, " ]")
            : prism_rtl::cat("[", inner_p9, "]");
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(_m)) {
        auto&& k_pa = prism_rtl::as<crate::check::types::Ty::TyMap>(_m).a0;
        auto&& v_pb = prism_rtl::as<crate::check::types::Ty::TyMap>(_m).a1;
        return prism_rtl::cat("(", show_ty_q(st_p0, prism_rtl::deref(k_pa)), " ==> ", show_ty_q(st_p0, prism_rtl::deref(v_pb)), ")");
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(_m)) {
        auto&& i_pc = prism_rtl::as<crate::check::types::Ty::TyAt>(_m).a0;
        auto&& rw_pd = prism_rtl::as<crate::check::types::Ty::TyAt>(_m).a1;
        return prism_rtl::cat("@", show_ty_q(st_p0, prism_rtl::deref(i_pc)), " emit ", crate::check::types::show_row_in(rw_pd, true));
    }
    {
        auto&& other_pe = _m;
        return crate::check::types::show_ty(st_p0, other_pe);
    }
}


prism_rtl::Turn<Text> ShowTyQ::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& t_p1 = this->t_p1;
    auto st_p0_1 = st_p0;
    auto t_p1_2 = t_p1;
    return call_then(crate::check::types::recording::start_zonk(st_p0_1, t_p1_2), [=](crate::check::types::Ty zonk_1493) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TyCon>(zonk_1493) && ({
            auto&& n_p2 = prism_rtl::as<crate::check::types::Ty::TyCon>(zonk_1493).a0;
            auto&& m1487_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(zonk_1493).a1;
            (m1487_0_1.size() == 0u);
        }) ? ({
            auto&& n_p2 = prism_rtl::as<crate::check::types::Ty::TyCon>(zonk_1493).a0;
            auto&& m1487_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(zonk_1493).a1;
            prism_rtl::finished(n_p2);
        })
            : prism_rtl::is<crate::check::types::Ty::TyCon>(zonk_1493) ? ({
            auto&& n_p3 = prism_rtl::as<crate::check::types::Ty::TyCon>(zonk_1493).a0;
            auto&& args_p4 = prism_rtl::as<crate::check::types::Ty::TyCon>(zonk_1493).a1;
            call_value(each_job(args_p4, ({
            auto st_p0_1_3 = st_p0_1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::check::types::Ty)>>(prism_rtl::rc([=, st_p0_1_3 = std::move(st_p0_1_3)](crate::check::types::Ty p0) {
            return ({
                auto st_p0_1_3_3 = st_p0_1_3;
                entered(once_job([=, st_p0_1_3_3 = std::move(st_p0_1_3_3)]() {
                return ({
                    auto a_p5 = p0;
                    call_then(start_show_ty_q(st_p0_1_3_3, a_p5), [=](Text show_ty_q_1578) { return prism_rtl::finished(prism_rtl::cat(" ", show_ty_q_1578)); });
                });
            }));
            });
        })));
        })), [=](Array<Text> each_1559) { return prism_rtl::finished(prism_rtl::cat("(", n_p3, concat(each_1559), ")")); });
        })
            : prism_rtl::is<crate::check::types::Ty::TySig>(zonk_1493) ? ({
            auto&& s_p6 = prism_rtl::as<crate::check::types::Ty::TySig>(zonk_1493).a0;
            auto&& i_p7 = prism_rtl::as<crate::check::types::Ty::TySig>(zonk_1493).a1;
            call_then(start_show_ty_q(st_p0_1, prism_rtl::deref(i_p7)), [=](Text show_ty_q_1619) { return prism_rtl::finished(prism_rtl::cat(s_p6, show_ty_q_1619)); });
        })
            : prism_rtl::is<crate::check::types::Ty::TyArray>(zonk_1493) ? ({
            auto&& e_p8 = prism_rtl::as<crate::check::types::Ty::TyArray>(zonk_1493).a0;
            call_then(start_show_ty_q(st_p0_1, prism_rtl::deref(e_p8)), [=](Text show_ty_q_1670) {
            return ({
                auto inner_p9 = show_ty_q_1670;
                (crate::syntax::lexer::chars::has_prefix(inner_p9, Text::lit("["))
                ? prism_rtl::finished(prism_rtl::cat("[ ", inner_p9, " ]"))
                : prism_rtl::finished(prism_rtl::cat("[", inner_p9, "]")));
            });
        });
        })
            : prism_rtl::is<crate::check::types::Ty::TyMap>(zonk_1493) ? ({
            auto&& k_pa = prism_rtl::as<crate::check::types::Ty::TyMap>(zonk_1493).a0;
            auto&& v_pb = prism_rtl::as<crate::check::types::Ty::TyMap>(zonk_1493).a1;
            call_then(start_show_ty_q(st_p0_1, prism_rtl::deref(k_pa)), [=](Text show_ty_q_1770) { return call_then(start_show_ty_q(st_p0_1, prism_rtl::deref(v_pb)), [=](Text show_ty_q_1790) { return prism_rtl::finished(prism_rtl::cat("(", show_ty_q_1770, " ==> ", show_ty_q_1790, ")")); }); });
        })
            : prism_rtl::is<crate::check::types::Ty::TyAt>(zonk_1493) ? ({
            auto&& i_pc = prism_rtl::as<crate::check::types::Ty::TyAt>(zonk_1493).a0;
            auto&& rw_pd = prism_rtl::as<crate::check::types::Ty::TyAt>(zonk_1493).a1;
            call_then(start_show_ty_q(st_p0_1, prism_rtl::deref(i_pc)), [=](Text show_ty_q_1826) { return prism_rtl::finished(prism_rtl::cat("@", show_ty_q_1826, " emit ", crate::check::types::show_row_in(rw_pd, true))); });
        })
            : ({
            auto&& other_pe = zonk_1493;
            prism_rtl::more(prism_rtl::rc(crate::check::types::ShowTy(st_p0_1, other_pe)));
        });
        });
    });
}


/// `Start ShowTyQ, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_show_ty_q(crate::check::types::St st_p0, crate::check::types::Ty t_p1) {
    return prism_rtl::make_rc<ShowTyQ>(st_p0, t_p1);
}


/// TryUnify: unbounded fn St, Ty, Ty, Range -> ((Bool, St))
std::tuple<bool, crate::check::types::St> try_unify(const crate::check::types::St& st_p0, const crate::check::types::Ty& expected_p1, const crate::check::types::Ty& found_p2, const crate::syntax::Range& span_p3) {
    auto [verdict_p4, st2_p5] = unify_in(st_p0, expected_p1, found_p2, span_p3);
    return std::tuple{verdict_p4 == Text::lit(""), st2_p5};
}


prism_rtl::Turn<std::tuple<bool, crate::check::types::St>> TryUnify::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& expected_p1 = this->expected_p1;
    const auto& found_p2 = this->found_p2;
    const auto& span_p3 = this->span_p3;
    auto expected_p1_1 = expected_p1;
    auto found_p2_2 = found_p2;
    auto span_p3_3 = span_p3;
    auto st_p0_4 = st_p0;
    return call_then(start_unify_in(st_p0_4, expected_p1_1, found_p2_2, span_p3_3), [=](std::tuple<Text, crate::check::types::St> unify_in_2156) {
        return ({
            auto [verdict_p4, st2_p5] = unify_in_2156;
            (prism_rtl::finished(std::tuple{verdict_p4 == Text::lit(""), st2_p5}));
        });
    });
}


/// `Start TryUnify, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<bool, crate::check::types::St>> start_try_unify(crate::check::types::St st_p0, crate::check::types::Ty expected_p1, crate::check::types::Ty found_p2, crate::syntax::Range span_p3) {
    return prism_rtl::make_rc<TryUnify>(st_p0, expected_p1, found_p2, span_p3);
}


/// UnifyIn: unbounded fn St, Ty, Ty, Range -> ((Text, St))
std::tuple<Text, crate::check::types::St> unify_in(const crate::check::types::St& st_p0, const crate::check::types::Ty& expected_p1, const crate::check::types::Ty& found_p2, const crate::syntax::Range& span_p3) {
    auto e_p4 = norm_assoc(st_p0, crate::check::types::recording::walk(st_p0, expected_p1));
    auto f_p5 = norm_assoc(st_p0, crate::check::types::recording::walk(st_p0, found_p2));
    return is_waiting_assoc(st_p0, e_p4) || is_waiting_assoc(st_p0, f_p5)
        ? e_p4 == f_p5
        ? std::tuple{Text::lit(""), st_p0}
        : std::tuple{Text::lit(""), defer(st_p0, e_p4, f_p5, span_p3)}
        : unify_heads(st_p0, e_p4, f_p5, span_p3);
}


prism_rtl::Turn<std::tuple<Text, crate::check::types::St>> UnifyIn::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& expected_p1 = this->expected_p1;
    const auto& found_p2 = this->found_p2;
    const auto& span_p3 = this->span_p3;
    auto expected_p1_1 = expected_p1;
    auto found_p2_2 = found_p2;
    auto span_p3_3 = span_p3;
    auto st_p0_4 = st_p0;
    return call_then(crate::check::types::recording::start_walk(st_p0_4, expected_p1_1), [=](crate::check::types::Ty walk_2446) {
        return call_then(start_norm_assoc(st_p0_4, walk_2446), [=](crate::check::types::Ty norm_assoc_2431) {
            return ({
                auto e_p4 = norm_assoc_2431;
                call_then(crate::check::types::recording::start_walk(st_p0_4, found_p2_2), [=, e_p4 = std::move(e_p4)](crate::check::types::Ty walk_2492) {
                return call_then(start_norm_assoc(st_p0_4, walk_2492), [=](crate::check::types::Ty norm_assoc_2477) {
                    return ({
                        auto f_p5 = norm_assoc_2477;
                        call_then(start_is_waiting_assoc(st_p0_4, e_p4), [=, f_p5 = std::move(f_p5)](bool is_waiting_assoc_2516) {
                        return is_waiting_assoc_2516 || is_waiting_assoc(st_p0_4, f_p5)
                            ? e_p4 == f_p5
                            ? prism_rtl::finished(std::tuple{Text::lit(""), st_p0_4})
                            : prism_rtl::finished(std::tuple{Text::lit(""), defer(st_p0_4, e_p4, f_p5, span_p3_3)})
                            : prism_rtl::more(prism_rtl::rc(UnifyHeads(st_p0_4, e_p4, f_p5, span_p3_3)));
                    });
                    });
                });
            });
            });
        });
    });
}


/// `Start UnifyIn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Text, crate::check::types::St>> start_unify_in(crate::check::types::St st_p0, crate::check::types::Ty expected_p1, crate::check::types::Ty found_p2, crate::syntax::Range span_p3) {
    return prism_rtl::make_rc<UnifyIn>(st_p0, expected_p1, found_p2, span_p3);
}


/// NormAssoc: unbounded fn St, Ty -> Ty
crate::check::types::Ty norm_assoc(const crate::check::types::St& st_p0, const crate::check::types::Ty& t_p1) {
    if (prism_rtl::is<crate::check::types::Ty::TyAssoc>(t_p1)) {
        auto&& m2934_0_0 = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t_p1).a0;
        auto&& a_p2 = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t_p1).a1;
        if (m2934_0_0 == Text::lit("Quotient")) {
            auto&& _m = crate::check::types::recording::walk(st_p0, prism_rtl::deref(prism_rtl::deref(a_p2)));
            if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
                auto&& m2970_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
                auto&& m2970_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a1;
                if (m2970_0_0 == Text::lit("Float")) {
                    if (m2970_0_1.size() == 0u) {
                        return crate::check::types::t_float();
                    }
                }
            }
            if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
                auto&& n_p3 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
                auto&& m2970_1_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a1;
                if (m2970_1_1.size() == 0u) {
                    return ((n_p3 == Text::lit("Nat")) || (n_p3 == Text::lit("Int"))) || (n_p3 == Text::lit("U8"))
                        ? crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("?"), prism_rtl::rc(crate::check::types::Ty(crate::check::types::Ty::TyCon{n_p3, Array<crate::check::types::Ty>{}}))})
                        : t_p1;
                }
            }
            {
                return t_p1;
            }
        }
    }
    {
        auto&& other_p4 = t_p1;
        return other_p4;
    }
}


prism_rtl::Turn<crate::check::types::Ty> NormAssoc::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& t_p1 = this->t_p1;
    return ({
        prism_rtl::is<crate::check::types::Ty::TyAssoc>(t_p1) && ({
        auto&& m2934_0_0 = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t_p1).a0;
        auto&& a_p2 = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t_p1).a1;
        (m2934_0_0 == Text::lit("Quotient"));
    }) ? ({
        auto&& m2934_0_0 = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t_p1).a0;
        auto&& a_p2 = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t_p1).a1;
        ({
        auto a_p2_1 = prism_rtl::deref(prism_rtl::deref(a_p2));
        auto st_p0_2 = st_p0;
        auto t_p1_3 = t_p1;
        call_then(crate::check::types::recording::start_walk(st_p0_2, a_p2_1), [=, t_p1_3 = std::move(t_p1_3)](crate::check::types::Ty walk_2976) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TyCon>(walk_2976) && ({
            auto&& m2970_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_2976).a0;
            auto&& m2970_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_2976).a1;
            (m2970_0_0 == Text::lit("Float")) && (m2970_0_1.size() == 0u);
        }) ? ({
            auto&& m2970_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_2976).a0;
            auto&& m2970_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_2976).a1;
            prism_rtl::finished(crate::check::types::t_float());
        })
            : prism_rtl::is<crate::check::types::Ty::TyCon>(walk_2976) && ({
            auto&& n_p3 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_2976).a0;
            auto&& m2970_1_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_2976).a1;
            (m2970_1_1.size() == 0u);
        }) ? ({
            auto&& n_p3 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_2976).a0;
            auto&& m2970_1_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_2976).a1;
            ((n_p3 == Text::lit("Nat")) || (n_p3 == Text::lit("Int"))) || (n_p3 == Text::lit("U8"))
            ? prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("?"), prism_rtl::rc(crate::check::types::Ty(crate::check::types::Ty::TyCon{n_p3, Array<crate::check::types::Ty>{}}))}))
            : prism_rtl::finished(t_p1_3);
        })
            : prism_rtl::finished(t_p1_3);
        });
    });
    });
    })
        : ({
        auto&& other_p4 = t_p1;
        prism_rtl::finished(other_p4);
    });
    });
}


/// `Start NormAssoc, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::Ty> start_norm_assoc(crate::check::types::St st_p0, crate::check::types::Ty t_p1) {
    return prism_rtl::make_rc<NormAssoc>(st_p0, t_p1);
}


/// IsWaitingAssoc: unbounded fn St, Ty -> Bool
bool is_waiting_assoc(const crate::check::types::St& st_p0, const crate::check::types::Ty& t_p1) {
    if (prism_rtl::is<crate::check::types::Ty::TyAssoc>(t_p1)) {
        auto&& a_p2 = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t_p1).a1;
        return crate::check::types::is_flex_var(st_p0, prism_rtl::deref(prism_rtl::deref(a_p2)));
    }
    {
        return false;
    }
}


prism_rtl::Turn<bool> IsWaitingAssoc::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& t_p1 = this->t_p1;
    return ({
        prism_rtl::is<crate::check::types::Ty::TyAssoc>(t_p1) ? ({
        auto&& a_p2 = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t_p1).a1;
        prism_rtl::more(prism_rtl::rc(crate::check::types::IsFlexVar(st_p0, prism_rtl::deref(prism_rtl::deref(a_p2)))));
    })
        : prism_rtl::finished(false);
    });
}


/// `Start IsWaitingAssoc, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_is_waiting_assoc(crate::check::types::St st_p0, crate::check::types::Ty t_p1) {
    return prism_rtl::make_rc<IsWaitingAssoc>(st_p0, t_p1);
}


/// Defer: fn St, Ty, Ty, Range -> St
crate::check::types::St defer(const crate::check::types::St& st_p0, const crate::check::types::Ty& e_p1, const crate::check::types::Ty& f_p2, const crate::syntax::Range& span_p3) {
    crate::check::types::St this_ = st_p0;
    this_.deferred = crate::prelude::push(this_.deferred, std::tuple{e_p1, f_p2, span_p3});
    return this_;
}


/// RetryDeferred: unbounded fn St -> St
crate::check::types::St retry_deferred(const crate::check::types::St& st_p0) {
    auto waiting_p1 = st_p0.deferred;
    auto cleared_p2 = ({
        crate::check::types::St this_ = st_p0;
        this_.deferred = Array<std::tuple<crate::check::types::Ty, crate::check::types::Ty, crate::syntax::Range>>{};
        (std::move(this_));
    });
    return run_to_end(fold_job(waiting_p1, cleared_p2, static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, std::tuple<crate::check::types::Ty, crate::check::types::Ty, crate::syntax::Range>>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, std::tuple<crate::check::types::Ty, crate::check::types::Ty, crate::syntax::Range>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto s_p3 = p0;
                auto [e_p4, f_p5, span_p6] = p1;
                (prism_rtl::more(prism_rtl::rc(Unify(s_p3, e_p4, f_p5, span_p6))));
            });
        }));
    }))));
}


prism_rtl::Turn<crate::check::types::St> RetryDeferred::cycle() const {
    const auto& st_p0 = this->st_p0;
    auto waiting_p1 = st_p0->deferred;
    auto cleared_p2 = ({
        crate::check::types::St this_ = st_p0;
        this_.deferred = Array<std::tuple<crate::check::types::Ty, crate::check::types::Ty, crate::syntax::Range>>{};
        (std::move(this_));
    });
    return fold_job(waiting_p1, cleared_p2, static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, std::tuple<crate::check::types::Ty, crate::check::types::Ty, crate::syntax::Range>>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, std::tuple<crate::check::types::Ty, crate::check::types::Ty, crate::syntax::Range>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto s_p3 = p0;
                auto [e_p4, f_p5, span_p6] = p1;
                (prism_rtl::more(prism_rtl::rc(Unify(s_p3, e_p4, f_p5, span_p6))));
            });
        }));
    })))->cycle();
}


/// `Start RetryDeferred, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_retry_deferred(crate::check::types::St st_p0) {
    return prism_rtl::make_rc<RetryDeferred>(st_p0);
}


/// UnifyHeads: unbounded fn St, Ty, Ty, Range -> ((Text, St))
std::tuple<Text, crate::check::types::St> unify_heads(const crate::check::types::St& st_p0, const crate::check::types::Ty& e_p1, const crate::check::types::Ty& f_p2, const crate::syntax::Range& span_p3) {
    auto&& _m = std::tuple{e_p1, f_p2};
    if (prism_rtl::is<crate::check::types::Ty::TyErr>(std::get<0>(_m))) {
        return std::tuple{Text::lit(""), st_p0};
    }
    if (prism_rtl::is<crate::check::types::Ty::TyErr>(std::get<1>(_m))) {
        return std::tuple{Text::lit(""), st_p0};
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyCon>(std::get<1>(_m))) {
        auto&& m3799_2_0_0 = prism_rtl::as<crate::check::types::Ty::TySig>(std::get<0>(_m)).a0;
        auto&& m3799_2_1_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(std::get<1>(_m)).a0;
        auto&& m3799_2_1_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(std::get<1>(_m)).a1;
        if (m3799_2_0_0 == Text::lit("~")) {
            if (m3799_2_1_0 == Text::lit("Prelude.Error")) {
                if (m3799_2_1_1.size() == 0u) {
                    return std::tuple{Text::lit(""), st_p0};
                }
            }
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TySig>(std::get<1>(_m))) {
        auto&& m3799_3_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(std::get<0>(_m)).a0;
        auto&& m3799_3_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(std::get<0>(_m)).a1;
        auto&& m3799_3_1_0 = prism_rtl::as<crate::check::types::Ty::TySig>(std::get<1>(_m)).a0;
        if (m3799_3_0_0 == Text::lit("Prelude.Error")) {
            if (m3799_3_0_1.size() == 0u) {
                if (m3799_3_1_0 == Text::lit("~")) {
                    return std::tuple{Text::lit(""), st_p0};
                }
            }
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFlex>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyFlex>(std::get<1>(_m))) {
        auto&& a_p4 = prism_rtl::as<crate::check::types::Ty::TyFlex>(std::get<0>(_m)).a0;
        auto&& b_p5 = prism_rtl::as<crate::check::types::Ty::TyFlex>(std::get<1>(_m)).a0;
        return a_p4 == b_p5
            ? std::tuple{Text::lit(""), st_p0}
            : std::tuple{Text::lit(""), merge_vars(st_p0, a_p4, b_p5)};
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFlex>(std::get<0>(_m))) {
        auto&& a_p6 = prism_rtl::as<crate::check::types::Ty::TyFlex>(std::get<0>(_m)).a0;
        auto&& t_p7 = std::get<1>(_m);
        return bind_var(st_p0, a_p6, t_p7, span_p3);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFlex>(std::get<1>(_m))) {
        auto&& t_p8 = std::get<0>(_m);
        auto&& b_p9 = prism_rtl::as<crate::check::types::Ty::TyFlex>(std::get<1>(_m)).a0;
        return bind_var(st_p0, b_p9, t_p8, span_p3);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyRigid>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyRigid>(std::get<1>(_m))) {
        auto&& a_pa = prism_rtl::as<crate::check::types::Ty::TyRigid>(std::get<0>(_m)).a0;
        auto&& b_pb = prism_rtl::as<crate::check::types::Ty::TyRigid>(std::get<1>(_m)).a0;
        return a_pa == b_pb
            ? std::tuple{Text::lit(""), st_p0}
            : std::tuple{Text::lit("mismatch"), st_p0};
    }
    if (prism_rtl::is<crate::check::types::Ty::TyQ>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyQ>(std::get<1>(_m))) {
        auto&& a_pc = prism_rtl::as<crate::check::types::Ty::TyQ>(std::get<0>(_m)).a0;
        auto&& b_pd = prism_rtl::as<crate::check::types::Ty::TyQ>(std::get<1>(_m)).a0;
        return a_pc == b_pd
            ? std::tuple{Text::lit(""), st_p0}
            : std::tuple{Text::lit("mismatch"), st_p0};
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyCon>(std::get<1>(_m))) {
        auto&& a_pe = prism_rtl::as<crate::check::types::Ty::TyCon>(std::get<0>(_m)).a0;
        auto&& xs_pf = prism_rtl::as<crate::check::types::Ty::TyCon>(std::get<0>(_m)).a1;
        auto&& b_pg = prism_rtl::as<crate::check::types::Ty::TyCon>(std::get<1>(_m)).a0;
        auto&& ys_ph = prism_rtl::as<crate::check::types::Ty::TyCon>(std::get<1>(_m)).a1;
        return (a_pe == b_pg) && (len(xs_pf) == len(ys_ph))
            ? unify_all(st_p0, xs_pf, ys_ph, span_p3)
            : std::tuple{Text::lit("mismatch"), st_p0};
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyFn>(std::get<1>(_m))) {
        auto&& c1_pi = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<0>(_m)).a0;
        auto&& ps_pj = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<0>(_m)).a1;
        auto&& r1_pk = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<0>(_m)).a2;
        auto&& c2_pl = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<1>(_m)).a0;
        auto&& qs_pm = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<1>(_m)).a1;
        auto&& r2_pn = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<1>(_m)).a2;
        return len(ps_pj) == len(qs_pm)
            ? ({
            auto [v_po, st2_pp] = crate::check::types::colors::unify_col(st_p0, c1_pi, c2_pl);
            v_po != Text::lit("")
            ? std::tuple{v_po, st2_pp}
            : unify_all(st2_pp, crate::prelude::push(ps_pj, prism_rtl::deref(r1_pk)), crate::prelude::push(qs_pm, prism_rtl::deref(r2_pn)), span_p3);
        })
            : std::tuple{Text::lit("mismatch"), st_p0};
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyTuple>(std::get<1>(_m))) {
        auto&& xs_pq = prism_rtl::as<crate::check::types::Ty::TyTuple>(std::get<0>(_m)).a0;
        auto&& ys_pr = prism_rtl::as<crate::check::types::Ty::TyTuple>(std::get<1>(_m)).a0;
        return len(xs_pq) == len(ys_pr)
            ? unify_all(st_p0, xs_pq, ys_pr, span_p3)
            : std::tuple{Text::lit("mismatch"), st_p0};
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyArray>(std::get<1>(_m))) {
        auto&& x_ps = prism_rtl::as<crate::check::types::Ty::TyArray>(std::get<0>(_m)).a0;
        auto&& y_pt = prism_rtl::as<crate::check::types::Ty::TyArray>(std::get<1>(_m)).a0;
        return unify_in(st_p0, prism_rtl::deref(x_ps), prism_rtl::deref(y_pt), span_p3);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyMap>(std::get<1>(_m))) {
        auto&& k1_pu = prism_rtl::as<crate::check::types::Ty::TyMap>(std::get<0>(_m)).a0;
        auto&& v1_pv = prism_rtl::as<crate::check::types::Ty::TyMap>(std::get<0>(_m)).a1;
        auto&& k2_p10 = prism_rtl::as<crate::check::types::Ty::TyMap>(std::get<1>(_m)).a0;
        auto&& v2_p11 = prism_rtl::as<crate::check::types::Ty::TyMap>(std::get<1>(_m)).a1;
        return unify_all(st_p0, Array(std::vector{prism_rtl::deref(k1_pu), prism_rtl::deref(v1_pv)}), Array(std::vector{prism_rtl::deref(k2_p10), prism_rtl::deref(v2_p11)}), span_p3);
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TySig>(std::get<1>(_m))) {
        auto&& s1_p12 = prism_rtl::as<crate::check::types::Ty::TySig>(std::get<0>(_m)).a0;
        auto&& i1_p13 = prism_rtl::as<crate::check::types::Ty::TySig>(std::get<0>(_m)).a1;
        auto&& s2_p14 = prism_rtl::as<crate::check::types::Ty::TySig>(std::get<1>(_m)).a0;
        auto&& i2_p15 = prism_rtl::as<crate::check::types::Ty::TySig>(std::get<1>(_m)).a1;
        return s1_p12 == s2_p14
            ? unify_in(st_p0, prism_rtl::deref(i1_p13), prism_rtl::deref(i2_p15), span_p3)
            : std::tuple{Text::lit("mismatch"), st_p0};
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyAt>(std::get<1>(_m))) {
        auto&& i1_p16 = prism_rtl::as<crate::check::types::Ty::TyAt>(std::get<0>(_m)).a0;
        auto&& r1_p17 = prism_rtl::as<crate::check::types::Ty::TyAt>(std::get<0>(_m)).a1;
        auto&& i2_p18 = prism_rtl::as<crate::check::types::Ty::TyAt>(std::get<1>(_m)).a0;
        auto&& r2_p19 = prism_rtl::as<crate::check::types::Ty::TyAt>(std::get<1>(_m)).a1;
        auto [v_p1a, st2_p1b] = unify_in(st_p0, prism_rtl::deref(i1_p16), prism_rtl::deref(i2_p18), span_p3);
        return v_p1a != Text::lit("")
            ? std::tuple{v_p1a, st2_p1b}
            : unify_row(st2_p1b, r1_p17, r2_p19, span_p3);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyElem>(std::get<1>(_m))) {
        auto&& r1_p1c = prism_rtl::as<crate::check::types::Ty::TyElem>(std::get<0>(_m)).a0;
        auto&& o1_p1d = prism_rtl::as<crate::check::types::Ty::TyElem>(std::get<0>(_m)).a1;
        auto&& r2_p1e = prism_rtl::as<crate::check::types::Ty::TyElem>(std::get<1>(_m)).a0;
        auto&& o2_p1f = prism_rtl::as<crate::check::types::Ty::TyElem>(std::get<1>(_m)).a1;
        auto [v_p1g, st2_p1h] = unify_row(st_p0, r1_p1c, r2_p1e, span_p3);
        return v_p1g != Text::lit("")
            ? std::tuple{v_p1g, st2_p1h}
            : unify_in(st2_p1h, prism_rtl::deref(o1_p1d), prism_rtl::deref(o2_p1f), span_p3);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElemAny>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyElemAny>(std::get<1>(_m))) {
        auto&& r1_p1i = prism_rtl::as<crate::check::types::Ty::TyElemAny>(std::get<0>(_m)).a0;
        auto&& r2_p1j = prism_rtl::as<crate::check::types::Ty::TyElemAny>(std::get<1>(_m)).a0;
        return unify_row(st_p0, r1_p1i, r2_p1j, span_p3);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAssoc>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyAssoc>(std::get<1>(_m))) {
        auto&& n1_p1k = prism_rtl::as<crate::check::types::Ty::TyAssoc>(std::get<0>(_m)).a0;
        auto&& a1_p1l = prism_rtl::as<crate::check::types::Ty::TyAssoc>(std::get<0>(_m)).a1;
        auto&& n2_p1m = prism_rtl::as<crate::check::types::Ty::TyAssoc>(std::get<1>(_m)).a0;
        auto&& a2_p1n = prism_rtl::as<crate::check::types::Ty::TyAssoc>(std::get<1>(_m)).a1;
        return n1_p1k == n2_p1m
            ? unify_in(st_p0, prism_rtl::deref(a1_p1l), prism_rtl::deref(a2_p1n), span_p3)
            : std::tuple{Text::lit("mismatch"), st_p0};
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAny>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyAny>(std::get<1>(_m))) {
        auto&& xs_p1o = prism_rtl::as<crate::check::types::Ty::TyAny>(std::get<0>(_m)).a0;
        auto&& ys_p1p = prism_rtl::as<crate::check::types::Ty::TyAny>(std::get<1>(_m)).a0;
        return crate::check::types::sort_texts(xs_p1o) == crate::check::types::sort_texts(ys_p1p)
            ? std::tuple{Text::lit(""), st_p0}
            : std::tuple{Text::lit("mismatch"), st_p0};
    }
    {
        return std::tuple{Text::lit("mismatch"), st_p0};
    }
}


prism_rtl::Turn<std::tuple<Text, crate::check::types::St>> UnifyHeads::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& e_p1 = this->e_p1;
    const auto& f_p2 = this->f_p2;
    const auto& span_p3 = this->span_p3;
    return ({
        auto&& _m = std::tuple{e_p1, f_p2};
        prism_rtl::is<crate::check::types::Ty::TyErr>(std::get<0>(_m)) ? prism_rtl::finished(std::tuple{Text::lit(""), st_p0})
        : prism_rtl::is<crate::check::types::Ty::TyErr>(std::get<1>(_m)) ? prism_rtl::finished(std::tuple{Text::lit(""), st_p0})
        : prism_rtl::is<crate::check::types::Ty::TySig>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyCon>(std::get<1>(_m)) && ({
        auto&& m3799_2_0_0 = prism_rtl::as<crate::check::types::Ty::TySig>(std::get<0>(_m)).a0;
        auto&& m3799_2_1_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(std::get<1>(_m)).a0;
        auto&& m3799_2_1_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(std::get<1>(_m)).a1;
        (m3799_2_0_0 == Text::lit("~")) && (m3799_2_1_0 == Text::lit("Prelude.Error")) && (m3799_2_1_1.size() == 0u);
    }) ? ({
        auto&& m3799_2_0_0 = prism_rtl::as<crate::check::types::Ty::TySig>(std::get<0>(_m)).a0;
        auto&& m3799_2_1_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(std::get<1>(_m)).a0;
        auto&& m3799_2_1_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(std::get<1>(_m)).a1;
        prism_rtl::finished(std::tuple{Text::lit(""), st_p0});
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TySig>(std::get<1>(_m)) && ({
        auto&& m3799_3_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(std::get<0>(_m)).a0;
        auto&& m3799_3_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(std::get<0>(_m)).a1;
        auto&& m3799_3_1_0 = prism_rtl::as<crate::check::types::Ty::TySig>(std::get<1>(_m)).a0;
        (m3799_3_0_0 == Text::lit("Prelude.Error")) && (m3799_3_0_1.size() == 0u) && (m3799_3_1_0 == Text::lit("~"));
    }) ? ({
        auto&& m3799_3_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(std::get<0>(_m)).a0;
        auto&& m3799_3_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(std::get<0>(_m)).a1;
        auto&& m3799_3_1_0 = prism_rtl::as<crate::check::types::Ty::TySig>(std::get<1>(_m)).a0;
        prism_rtl::finished(std::tuple{Text::lit(""), st_p0});
    })
        : prism_rtl::is<crate::check::types::Ty::TyFlex>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyFlex>(std::get<1>(_m)) ? ({
        auto&& a_p4 = prism_rtl::as<crate::check::types::Ty::TyFlex>(std::get<0>(_m)).a0;
        auto&& b_p5 = prism_rtl::as<crate::check::types::Ty::TyFlex>(std::get<1>(_m)).a0;
        a_p4 == b_p5
        ? prism_rtl::finished(std::tuple{Text::lit(""), st_p0})
        : prism_rtl::finished(std::tuple{Text::lit(""), merge_vars(st_p0, a_p4, b_p5)});
    })
        : prism_rtl::is<crate::check::types::Ty::TyFlex>(std::get<0>(_m)) ? ({
        auto&& a_p6 = prism_rtl::as<crate::check::types::Ty::TyFlex>(std::get<0>(_m)).a0;
        auto&& t_p7 = std::get<1>(_m);
        prism_rtl::more(prism_rtl::rc(BindVar(st_p0, a_p6, t_p7, span_p3)));
    })
        : prism_rtl::is<crate::check::types::Ty::TyFlex>(std::get<1>(_m)) ? ({
        auto&& t_p8 = std::get<0>(_m);
        auto&& b_p9 = prism_rtl::as<crate::check::types::Ty::TyFlex>(std::get<1>(_m)).a0;
        prism_rtl::more(prism_rtl::rc(BindVar(st_p0, b_p9, t_p8, span_p3)));
    })
        : prism_rtl::is<crate::check::types::Ty::TyRigid>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyRigid>(std::get<1>(_m)) ? ({
        auto&& a_pa = prism_rtl::as<crate::check::types::Ty::TyRigid>(std::get<0>(_m)).a0;
        auto&& b_pb = prism_rtl::as<crate::check::types::Ty::TyRigid>(std::get<1>(_m)).a0;
        a_pa == b_pb
        ? prism_rtl::finished(std::tuple{Text::lit(""), st_p0})
        : prism_rtl::finished(std::tuple{Text::lit("mismatch"), st_p0});
    })
        : prism_rtl::is<crate::check::types::Ty::TyQ>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyQ>(std::get<1>(_m)) ? ({
        auto&& a_pc = prism_rtl::as<crate::check::types::Ty::TyQ>(std::get<0>(_m)).a0;
        auto&& b_pd = prism_rtl::as<crate::check::types::Ty::TyQ>(std::get<1>(_m)).a0;
        a_pc == b_pd
        ? prism_rtl::finished(std::tuple{Text::lit(""), st_p0})
        : prism_rtl::finished(std::tuple{Text::lit("mismatch"), st_p0});
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyCon>(std::get<1>(_m)) ? ({
        auto&& a_pe = prism_rtl::as<crate::check::types::Ty::TyCon>(std::get<0>(_m)).a0;
        auto&& xs_pf = prism_rtl::as<crate::check::types::Ty::TyCon>(std::get<0>(_m)).a1;
        auto&& b_pg = prism_rtl::as<crate::check::types::Ty::TyCon>(std::get<1>(_m)).a0;
        auto&& ys_ph = prism_rtl::as<crate::check::types::Ty::TyCon>(std::get<1>(_m)).a1;
        (a_pe == b_pg) && (len(xs_pf) == len(ys_ph))
        ? prism_rtl::more(prism_rtl::rc(UnifyAll(st_p0, xs_pf, ys_ph, span_p3)))
        : prism_rtl::finished(std::tuple{Text::lit("mismatch"), st_p0});
    })
        : prism_rtl::is<crate::check::types::Ty::TyFn>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyFn>(std::get<1>(_m)) ? ({
        auto&& c1_pi = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<0>(_m)).a0;
        auto&& ps_pj = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<0>(_m)).a1;
        auto&& r1_pk = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<0>(_m)).a2;
        auto&& c2_pl = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<1>(_m)).a0;
        auto&& qs_pm = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<1>(_m)).a1;
        auto&& r2_pn = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<1>(_m)).a2;
        len(ps_pj) == len(qs_pm)
        ? ({
        auto span_p3_1 = span_p3;
        auto st_p0_2 = st_p0;
        call_then(crate::check::types::colors::start_unify_col(st_p0_2, c1_pi, c2_pl), [=, span_p3_1 = std::move(span_p3_1)](std::tuple<Text, crate::check::types::St> unify_col_4653) {
        return ({
            auto [v_po, st2_pp] = unify_col_4653;
            v_po != Text::lit("")
            ? prism_rtl::finished(std::tuple{v_po, st2_pp})
            : prism_rtl::more(prism_rtl::rc(UnifyAll(st2_pp, crate::prelude::push(ps_pj, prism_rtl::deref(r1_pk)), crate::prelude::push(qs_pm, prism_rtl::deref(r2_pn)), span_p3_1)));
        });
    });
    })
        : prism_rtl::finished(std::tuple{Text::lit("mismatch"), st_p0});
    })
        : prism_rtl::is<crate::check::types::Ty::TyTuple>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyTuple>(std::get<1>(_m)) ? ({
        auto&& xs_pq = prism_rtl::as<crate::check::types::Ty::TyTuple>(std::get<0>(_m)).a0;
        auto&& ys_pr = prism_rtl::as<crate::check::types::Ty::TyTuple>(std::get<1>(_m)).a0;
        len(xs_pq) == len(ys_pr)
        ? prism_rtl::more(prism_rtl::rc(UnifyAll(st_p0, xs_pq, ys_pr, span_p3)))
        : prism_rtl::finished(std::tuple{Text::lit("mismatch"), st_p0});
    })
        : prism_rtl::is<crate::check::types::Ty::TyArray>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyArray>(std::get<1>(_m)) ? ({
        auto&& x_ps = prism_rtl::as<crate::check::types::Ty::TyArray>(std::get<0>(_m)).a0;
        auto&& y_pt = prism_rtl::as<crate::check::types::Ty::TyArray>(std::get<1>(_m)).a0;
        prism_rtl::more(prism_rtl::rc(UnifyIn(st_p0, prism_rtl::deref(x_ps), prism_rtl::deref(y_pt), span_p3)));
    })
        : prism_rtl::is<crate::check::types::Ty::TyMap>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyMap>(std::get<1>(_m)) ? ({
        auto&& k1_pu = prism_rtl::as<crate::check::types::Ty::TyMap>(std::get<0>(_m)).a0;
        auto&& v1_pv = prism_rtl::as<crate::check::types::Ty::TyMap>(std::get<0>(_m)).a1;
        auto&& k2_p10 = prism_rtl::as<crate::check::types::Ty::TyMap>(std::get<1>(_m)).a0;
        auto&& v2_p11 = prism_rtl::as<crate::check::types::Ty::TyMap>(std::get<1>(_m)).a1;
        prism_rtl::more(prism_rtl::rc(UnifyAll(st_p0, Array(std::vector{prism_rtl::deref(k1_pu), prism_rtl::deref(v1_pv)}), Array(std::vector{prism_rtl::deref(k2_p10), prism_rtl::deref(v2_p11)}), span_p3)));
    })
        : prism_rtl::is<crate::check::types::Ty::TySig>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TySig>(std::get<1>(_m)) ? ({
        auto&& s1_p12 = prism_rtl::as<crate::check::types::Ty::TySig>(std::get<0>(_m)).a0;
        auto&& i1_p13 = prism_rtl::as<crate::check::types::Ty::TySig>(std::get<0>(_m)).a1;
        auto&& s2_p14 = prism_rtl::as<crate::check::types::Ty::TySig>(std::get<1>(_m)).a0;
        auto&& i2_p15 = prism_rtl::as<crate::check::types::Ty::TySig>(std::get<1>(_m)).a1;
        s1_p12 == s2_p14
        ? prism_rtl::more(prism_rtl::rc(UnifyIn(st_p0, prism_rtl::deref(i1_p13), prism_rtl::deref(i2_p15), span_p3)))
        : prism_rtl::finished(std::tuple{Text::lit("mismatch"), st_p0});
    })
        : prism_rtl::is<crate::check::types::Ty::TyAt>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyAt>(std::get<1>(_m)) ? ({
        auto&& i1_p16 = prism_rtl::as<crate::check::types::Ty::TyAt>(std::get<0>(_m)).a0;
        auto&& r1_p17 = prism_rtl::as<crate::check::types::Ty::TyAt>(std::get<0>(_m)).a1;
        auto&& i2_p18 = prism_rtl::as<crate::check::types::Ty::TyAt>(std::get<1>(_m)).a0;
        auto&& r2_p19 = prism_rtl::as<crate::check::types::Ty::TyAt>(std::get<1>(_m)).a1;
        ({
        auto span_p3_1 = span_p3;
        auto st_p0_2 = st_p0;
        call_then(start_unify_in(st_p0_2, prism_rtl::deref(i1_p16), prism_rtl::deref(i2_p18), span_p3_1), [=](std::tuple<Text, crate::check::types::St> unify_in_5237) {
        return ({
            auto [v_p1a, st2_p1b] = unify_in_5237;
            v_p1a != Text::lit("")
            ? prism_rtl::finished(std::tuple{v_p1a, st2_p1b})
            : prism_rtl::more(prism_rtl::rc(UnifyRow(st2_p1b, r1_p17, r2_p19, span_p3_1)));
        });
    });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyElem>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyElem>(std::get<1>(_m)) ? ({
        auto&& r1_p1c = prism_rtl::as<crate::check::types::Ty::TyElem>(std::get<0>(_m)).a0;
        auto&& o1_p1d = prism_rtl::as<crate::check::types::Ty::TyElem>(std::get<0>(_m)).a1;
        auto&& r2_p1e = prism_rtl::as<crate::check::types::Ty::TyElem>(std::get<1>(_m)).a0;
        auto&& o2_p1f = prism_rtl::as<crate::check::types::Ty::TyElem>(std::get<1>(_m)).a1;
        ({
        auto span_p3_1 = span_p3;
        auto st_p0_2 = st_p0;
        call_then(start_unify_row(st_p0_2, r1_p1c, r2_p1e, span_p3_1), [=](std::tuple<Text, crate::check::types::St> unify_row_5405) {
        return ({
            auto [v_p1g, st2_p1h] = unify_row_5405;
            v_p1g != Text::lit("")
            ? prism_rtl::finished(std::tuple{v_p1g, st2_p1h})
            : prism_rtl::more(prism_rtl::rc(UnifyIn(st2_p1h, prism_rtl::deref(o1_p1d), prism_rtl::deref(o2_p1f), span_p3_1)));
        });
    });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyElemAny>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyElemAny>(std::get<1>(_m)) ? ({
        auto&& r1_p1i = prism_rtl::as<crate::check::types::Ty::TyElemAny>(std::get<0>(_m)).a0;
        auto&& r2_p1j = prism_rtl::as<crate::check::types::Ty::TyElemAny>(std::get<1>(_m)).a0;
        prism_rtl::more(prism_rtl::rc(UnifyRow(st_p0, r1_p1i, r2_p1j, span_p3)));
    })
        : prism_rtl::is<crate::check::types::Ty::TyAssoc>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyAssoc>(std::get<1>(_m)) ? ({
        auto&& n1_p1k = prism_rtl::as<crate::check::types::Ty::TyAssoc>(std::get<0>(_m)).a0;
        auto&& a1_p1l = prism_rtl::as<crate::check::types::Ty::TyAssoc>(std::get<0>(_m)).a1;
        auto&& n2_p1m = prism_rtl::as<crate::check::types::Ty::TyAssoc>(std::get<1>(_m)).a0;
        auto&& a2_p1n = prism_rtl::as<crate::check::types::Ty::TyAssoc>(std::get<1>(_m)).a1;
        n1_p1k == n2_p1m
        ? prism_rtl::more(prism_rtl::rc(UnifyIn(st_p0, prism_rtl::deref(a1_p1l), prism_rtl::deref(a2_p1n), span_p3)))
        : prism_rtl::finished(std::tuple{Text::lit("mismatch"), st_p0});
    })
        : prism_rtl::is<crate::check::types::Ty::TyAny>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyAny>(std::get<1>(_m)) ? ({
        auto&& xs_p1o = prism_rtl::as<crate::check::types::Ty::TyAny>(std::get<0>(_m)).a0;
        auto&& ys_p1p = prism_rtl::as<crate::check::types::Ty::TyAny>(std::get<1>(_m)).a0;
        crate::check::types::sort_texts(xs_p1o) == crate::check::types::sort_texts(ys_p1p)
        ? prism_rtl::finished(std::tuple{Text::lit(""), st_p0})
        : prism_rtl::finished(std::tuple{Text::lit("mismatch"), st_p0});
    })
        : prism_rtl::finished(std::tuple{Text::lit("mismatch"), st_p0});
    });
}


/// `Start UnifyHeads, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Text, crate::check::types::St>> start_unify_heads(crate::check::types::St st_p0, crate::check::types::Ty e_p1, crate::check::types::Ty f_p2, crate::syntax::Range span_p3) {
    return prism_rtl::make_rc<UnifyHeads>(st_p0, e_p1, f_p2, span_p3);
}


/// UnifyAll: unbounded fn St, [Ty], [Ty], Range -> ((Text, St))
std::tuple<Text, crate::check::types::St> unify_all(const crate::check::types::St& st_p0, const Array<crate::check::types::Ty>& xs_p1, const Array<crate::check::types::Ty>& ys_p2, const crate::syntax::Range& span_p3) {
    return run_to_end(fold_job(crate::check::errors::range0(len(xs_p1)), std::tuple{Text::lit(""), st_p0}, ({
        auto xs_p1_1 = xs_p1;
        auto ys_p2_2 = ys_p2;
        auto span_p3_3 = span_p3;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, crate::check::types::St>>(std::tuple<std::tuple<Text, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=, xs_p1_1 = std::move(xs_p1_1), ys_p2_2 = std::move(ys_p2_2), span_p3_3 = std::move(span_p3_3)](std::tuple<std::tuple<Text, crate::check::types::St>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto xs_p1_1_4 = xs_p1_1;
            auto ys_p2_2_4 = ys_p2_2;
            auto span_p3_3_4 = span_p3_3;
            entered(once_job([=, xs_p1_1_4 = std::move(xs_p1_1_4), ys_p2_2_4 = std::move(ys_p2_2_4), span_p3_3_4 = std::move(span_p3_3_4)]() {
            return ({
                auto [v_p4, s_p5] = p0;
                auto i_p6 = p1;
                v_p4 != Text::lit("")
                ? prism_rtl::finished(std::tuple{v_p4, s_p5})
                : prism_rtl::more(prism_rtl::rc(UnifyIn(s_p5, or_(index(xs_p1_1_4, i_p6), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), or_(index(ys_p2_2_4, i_p6), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), span_p3_3_4)));
            });
        }));
        });
    }));
    })));
}


prism_rtl::Turn<std::tuple<Text, crate::check::types::St>> UnifyAll::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& xs_p1 = this->xs_p1;
    const auto& ys_p2 = this->ys_p2;
    const auto& span_p3 = this->span_p3;
    return fold_job(crate::check::errors::range0(len(xs_p1)), std::tuple{Text::lit(""), st_p0}, ({
        auto xs_p1_1 = xs_p1;
        auto ys_p2_2 = ys_p2;
        auto span_p3_3 = span_p3;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, crate::check::types::St>>(std::tuple<std::tuple<Text, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=, xs_p1_1 = std::move(xs_p1_1), ys_p2_2 = std::move(ys_p2_2), span_p3_3 = std::move(span_p3_3)](std::tuple<std::tuple<Text, crate::check::types::St>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto xs_p1_1_4 = xs_p1_1;
            auto ys_p2_2_4 = ys_p2_2;
            auto span_p3_3_4 = span_p3_3;
            entered(once_job([=, xs_p1_1_4 = std::move(xs_p1_1_4), ys_p2_2_4 = std::move(ys_p2_2_4), span_p3_3_4 = std::move(span_p3_3_4)]() {
            return ({
                auto [v_p4, s_p5] = p0;
                auto i_p6 = p1;
                v_p4 != Text::lit("")
                ? prism_rtl::finished(std::tuple{v_p4, s_p5})
                : prism_rtl::more(prism_rtl::rc(UnifyIn(s_p5, or_(index(xs_p1_1_4, i_p6), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), or_(index(ys_p2_2_4, i_p6), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), span_p3_3_4)));
            });
        }));
        });
    }));
    }))->cycle();
}


/// `Start UnifyAll, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Text, crate::check::types::St>> start_unify_all(crate::check::types::St st_p0, Array<crate::check::types::Ty> xs_p1, Array<crate::check::types::Ty> ys_p2, crate::syntax::Range span_p3) {
    return prism_rtl::make_rc<UnifyAll>(st_p0, xs_p1, ys_p2, span_p3);
}


/// MergeVars: fn St, Nat, Nat -> St
crate::check::types::St merge_vars(const crate::check::types::St& st_p0, const Nat& a_p1, const Nat& b_p2) {
    auto ia_p3 = crate::check::types::recording::info_of(st_p0, a_p1);
    auto ib_p4 = crate::check::types::recording::info_of(st_p0, b_p2);
    auto merged_p5 = crate::check::types::VInfo{.plain = prism_rtl::deref(ia_p3).plain || prism_rtl::deref(ib_p4).plain, .level = crate::prelude::min(prism_rtl::deref(ia_p3).level, prism_rtl::deref(ib_p4).level), .name = prism_rtl::deref(ib_p4).name == Text::lit("")
        ? prism_rtl::deref(ia_p3).name
        : prism_rtl::deref(ib_p4).name};
    crate::check::types::St this_ = st_p0;
    this_.tys = insert(this_.tys, a_p1, crate::check::types::Ty(crate::check::types::Ty::TyFlex{b_p2}));
    this_.infos = insert(this_.infos, b_p2, merged_p5);
    return this_;
}


/// BindVar: unbounded fn St, Nat, Ty, Range -> ((Text, St))
std::tuple<Text, crate::check::types::St> bind_var(const crate::check::types::St& st_p0, const Nat& n_p1, const crate::check::types::Ty& t_p2, const crate::syntax::Range& span_p3) {
    auto info_p4 = crate::check::types::recording::info_of(st_p0, n_p1);
    auto stack_p5 = crate::check::types::stack_of(st_p0, t_p2);
    return crate::check::types::has_nat(crate::check::types::recording::free_vars(st_p0, t_p2), n_p1)
        ? std::tuple{Text::lit("reported"), crate::check::types::recording::err(st_p0, Text::lit("occurs"), span_p3, prism_rtl::cat("`t", n_p1, "` would contain itself: `t", n_p1, " = ", crate::check::types::show_ty(st_p0, t_p2), "`"))}
        : prism_rtl::deref(info_p4).plain && (stack_p5 != Text::lit(""))
        ? prism_rtl::deref(info_p4).name != Text::lit("")
        ? ({
        auto marks_p6 = marks_of(prism_rtl::deref(info_p4).name);
        auto whole_p7 = prism_rtl::cat(marks_p6, crate::check::types::show_ty_in(st_p0, crate::check::types::recording::zonk(st_p0, t_p2), true));
        auto at_p8 = or_(crate::prelude::get(st_p0.binder_at, n_p1), span_p3);
        auto st2_p9 = crate::check::types::recording::err_fix(st_p0, Text::lit("mark-stack"), at_p8, prism_rtl::cat("`", prism_rtl::deref(info_p4).name, "` has type `", whole_p7, "`, whose stack is `", marks_p6, stack_p5, "`; the name shows `", marks_p6, "`"), prism_rtl::cat("rename to `", marks_p6, stack_p5, crate::syntax::lexer::chars::drop_prefix(prism_rtl::deref(info_p4).name, marks_p6), "`"));
        std::tuple{Text::lit(""), ({
        crate::check::types::St this_ = lower_levels(st2_p9, append(crate::check::types::recording::free_vars(st2_p9, t_p2), crate::check::types::colors::free_col_vars(st2_p9, t_p2)), prism_rtl::deref(info_p4).level);
        this_.tys = insert(this_.tys, n_p1, t_p2);
        (std::move(this_));
    })};
    })
        : std::tuple{Text::lit("mismatch"), st_p0}
        : ({
        auto lowered_pa = lower_levels(st_p0, append(crate::check::types::recording::free_vars(st_p0, t_p2), crate::check::types::colors::free_col_vars(st_p0, t_p2)), prism_rtl::deref(info_p4).level);
        std::tuple{Text::lit(""), ({
        crate::check::types::St this_ = lowered_pa;
        this_.tys = insert(this_.tys, n_p1, t_p2);
        (std::move(this_));
    })};
    });
}


prism_rtl::Turn<std::tuple<Text, crate::check::types::St>> BindVar::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& n_p1 = this->n_p1;
    const auto& t_p2 = this->t_p2;
    const auto& span_p3 = this->span_p3;
    auto info_p4 = crate::check::types::recording::info_of(st_p0, n_p1);
    auto n_p1_1 = n_p1;
    auto span_p3_2 = span_p3;
    auto st_p0_3 = st_p0;
    auto t_p2_4 = t_p2;
    return call_then(crate::check::types::start_stack_of(st_p0_3, t_p2_4), [=](Text stack_of_6651) {
        return ({
            auto stack_p5 = stack_of_6651;
            call_then(crate::check::types::recording::start_free_vars(st_p0_3, t_p2_4), [=, stack_p5 = std::move(stack_p5)](Array<Nat> free_vars_6680) {
            return crate::check::types::has_nat(free_vars_6680, n_p1_1)
                ? call_then(crate::check::types::start_show_ty(st_p0_3, t_p2_4), [=](Text show_ty_6786) { return prism_rtl::finished(std::tuple{Text::lit("reported"), crate::check::types::recording::err(st_p0_3, Text::lit("occurs"), span_p3_2, prism_rtl::cat("`t", n_p1_1, "` would contain itself: `t", n_p1_1, " = ", show_ty_6786, "`"))}); })
                : prism_rtl::deref(info_p4).plain && (stack_p5 != Text::lit(""))
                ? prism_rtl::deref(info_p4).name != Text::lit("")
                ? ({
                auto marks_p6 = marks_of(prism_rtl::deref(info_p4).name);
                call_then(crate::check::types::recording::start_zonk(st_p0_3, t_p2_4), [=, marks_p6 = std::move(marks_p6)](crate::check::types::Ty zonk_6963) {
                return call_then(crate::check::types::start_show_ty_in(st_p0_3, zonk_6963, true), [=](Text show_ty_in_6949) {
                    return ({
                        auto whole_p7 = prism_rtl::cat(marks_p6, show_ty_in_6949);
                        auto at_p8 = or_(crate::prelude::get(prism_rtl::deref(st_p0_3).binder_at, n_p1_1), span_p3_2);
                        auto st2_p9 = crate::check::types::recording::err_fix(st_p0_3, Text::lit("mark-stack"), at_p8, prism_rtl::cat("`", prism_rtl::deref(info_p4).name, "` has type `", whole_p7, "`, whose stack is `", marks_p6, stack_p5, "`; the name shows `", marks_p6, "`"), prism_rtl::cat("rename to `", marks_p6, stack_p5, crate::syntax::lexer::chars::drop_prefix(prism_rtl::deref(info_p4).name, marks_p6), "`"));
                        (prism_rtl::finished(std::tuple{Text::lit(""), ({
                        crate::check::types::St this_ = lower_levels(st2_p9, append(crate::check::types::recording::free_vars(st2_p9, t_p2_4), crate::check::types::colors::free_col_vars(st2_p9, t_p2_4)), prism_rtl::deref(info_p4).level);
                        this_.tys = insert(this_.tys, n_p1_1, t_p2_4);
                        (std::move(this_));
                    })}));
                    });
                });
            });
            })
                : prism_rtl::finished(std::tuple{Text::lit("mismatch"), st_p0_3})
                : call_then(crate::check::types::recording::start_free_vars(st_p0_3, t_p2_4), [=](Array<Nat> free_vars_7628) {
                return call_then(crate::check::types::colors::start_free_col_vars(st_p0_3, t_p2_4), [=](Array<Nat> free_col_vars_7646) {
                    return ({
                        auto lowered_pa = lower_levels(st_p0_3, append(free_vars_7628, free_col_vars_7646), prism_rtl::deref(info_p4).level);
                        (prism_rtl::finished(std::tuple{Text::lit(""), ({
                        crate::check::types::St this_ = lowered_pa;
                        this_.tys = insert(this_.tys, n_p1_1, t_p2_4);
                        (std::move(this_));
                    })}));
                    });
                });
            });
        });
        });
    });
}


/// `Start BindVar, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Text, crate::check::types::St>> start_bind_var(crate::check::types::St st_p0, Nat n_p1, crate::check::types::Ty t_p2, crate::syntax::Range span_p3) {
    return prism_rtl::make_rc<BindVar>(st_p0, n_p1, t_p2, span_p3);
}


/// MarksOf: fn Text -> Text
Text marks_of(const Text& name_p0) {
    auto c_p1 = ({
        Cursor this_ = front(name_p0);
        while (true) {
            auto&& _m = step(this_);
            if (!(prism_rtl::is_some(_m))) break;
            auto&& next_p2 = std::get<1>(prism_rtl::some_of(_m));
            if (!is_mark_char(crate::syntax::lexer::chars::char_at(this_))) {
                break;
            }
            this_ = next_p2;
        }
        (std::move(this_));
    });
    return before(c_p1);
}


/// IsMarkChar: fn Text -> Bool
bool is_mark_char(const Text& c_p0) {
    return (((((c_p0 == Text::lit("$")) || (c_p0 == Text::lit("!"))) || (c_p0 == Text::lit("@"))) || (c_p0 == Text::lit("?"))) || (c_p0 == Text::lit("~"))) || (c_p0 == Text::lit("&"));
}


/// LowerLevels: fn St, [Nat], Nat -> St
crate::check::types::St lower_levels(const crate::check::types::St& st_p0, const Array<Nat>& vs_p1, const Nat& level_p2) {
    return fold(vs_p1, st_p0, [&](const crate::check::types::St& s_p3, const Nat& v_p4) { return lower_one(s_p3, v_p4, level_p2); });
}


/// LowerOne: fn St, Nat, Nat -> St
crate::check::types::St lower_one(const crate::check::types::St& s_p0, const Nat& v_p1, const Nat& level_p2) {
    auto i_p3 = crate::check::types::recording::info_of(s_p0, v_p1);
    return prism_rtl::deref(i_p3).level <= level_p2
        ? s_p0
        : ({
        crate::check::types::St this_ = s_p0;
        this_.infos = insert(this_.infos, v_p1, crate::check::types::VInfo{.plain = prism_rtl::deref(i_p3).plain, .level = level_p2, .name = prism_rtl::deref(i_p3).name});
        (std::move(this_));
    });
}


/// UnifyRow: unbounded fn St, Rw, Rw, Range -> ((Text, St))
std::tuple<Text, crate::check::types::St> unify_row(const crate::check::types::St& st_p0, const crate::check::types::Rw& a0_p1, const crate::check::types::Rw& b0_p2, const crate::syntax::Range& span_p3) {
    auto a_p4 = crate::check::types::recording::walk_row(st_p0, a0_p1);
    auto b_p5 = crate::check::types::recording::walk_row(st_p0, b0_p2);
    auto only_a_p6 = crate::check::types::minus_texts(prism_rtl::deref(a_p4).fams, prism_rtl::deref(b_p5).fams);
    auto only_b_p7 = crate::check::types::minus_texts(prism_rtl::deref(b_p5).fams, prism_rtl::deref(a_p4).fams);
    auto&& _m = std::tuple{prism_rtl::deref(a_p4).tail, prism_rtl::deref(b_p5).tail};
    if (prism_rtl::is<crate::check::types::Tail::TlClosed>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Tail::TlClosed>(std::get<1>(_m))) {
        return (len(only_a_p6) == Nat(0u)) && (len(only_b_p7) == Nat(0u))
            ? std::tuple{Text::lit(""), st_p0}
            : std::tuple{Text::lit("mismatch"), st_p0};
    }
    if (prism_rtl::is<crate::check::types::Tail::TlFlex>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Tail::TlFlex>(std::get<1>(_m))) {
        auto&& x_p8 = prism_rtl::as<crate::check::types::Tail::TlFlex>(std::get<0>(_m)).a0;
        auto&& y_p9 = prism_rtl::as<crate::check::types::Tail::TlFlex>(std::get<1>(_m)).a0;
        return x_p8 == y_p9
            ? (len(only_a_p6) == Nat(0u)) && (len(only_b_p7) == Nat(0u))
            ? std::tuple{Text::lit(""), st_p0}
            : std::tuple{Text::lit("mismatch"), st_p0}
            : ({
            auto lacking_pa = crate::check::types::union_texts(crate::check::types::union_texts(lacks_of(st_p0, x_p8), lacks_of(st_p0, y_p9)), crate::check::types::union_texts(prism_rtl::deref(a_p4).fams, prism_rtl::deref(b_p5).fams));
            auto [fresh_pb, st2_pc] = crate::check::types::recording::fresh_row(st_p0, lacking_pa);
            auto [v1_pd, st3_pe] = bind_row(st2_pc, x_p8, crate::check::types::Rw{.fams = only_b_p7, .minus = Array<Text>{}, .tail = prism_rtl::deref(fresh_pb).tail}, span_p3);
            v1_pd != Text::lit("")
            ? std::tuple{v1_pd, st3_pe}
            : bind_row(st3_pe, y_p9, crate::check::types::Rw{.fams = only_a_p6, .minus = Array<Text>{}, .tail = prism_rtl::deref(fresh_pb).tail}, span_p3);
        });
    }
    if (prism_rtl::is<crate::check::types::Tail::TlFlex>(std::get<0>(_m))) {
        auto&& x_pf = prism_rtl::as<crate::check::types::Tail::TlFlex>(std::get<0>(_m)).a0;
        auto&& other_pg = std::get<1>(_m);
        return len(only_a_p6) == Nat(0u)
            ? bind_row(st_p0, x_pf, crate::check::types::Rw{.fams = only_b_p7, .minus = prism_rtl::deref(b_p5).minus, .tail = other_pg}, span_p3)
            : std::tuple{Text::lit("mismatch"), st_p0};
    }
    if (prism_rtl::is<crate::check::types::Tail::TlFlex>(std::get<1>(_m))) {
        auto&& other_ph = std::get<0>(_m);
        auto&& y_pi = prism_rtl::as<crate::check::types::Tail::TlFlex>(std::get<1>(_m)).a0;
        return len(only_b_p7) == Nat(0u)
            ? bind_row(st_p0, y_pi, crate::check::types::Rw{.fams = only_a_p6, .minus = prism_rtl::deref(a_p4).minus, .tail = other_ph}, span_p3)
            : std::tuple{Text::lit("mismatch"), st_p0};
    }
    if (prism_rtl::is<crate::check::types::Tail::TlRigid>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Tail::TlRigid>(std::get<1>(_m))) {
        auto&& x_pj = prism_rtl::as<crate::check::types::Tail::TlRigid>(std::get<0>(_m)).a0;
        auto&& y_pk = prism_rtl::as<crate::check::types::Tail::TlRigid>(std::get<1>(_m)).a0;
        return ((x_pj == y_pk) && (len(only_a_p6) == Nat(0u))) && (len(only_b_p7) == Nat(0u))
            ? std::tuple{Text::lit(""), st_p0}
            : std::tuple{Text::lit("mismatch"), st_p0};
    }
    if (prism_rtl::is<crate::check::types::Tail::TlQ>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Tail::TlQ>(std::get<1>(_m))) {
        auto&& x_pl = prism_rtl::as<crate::check::types::Tail::TlQ>(std::get<0>(_m)).a0;
        auto&& y_pm = prism_rtl::as<crate::check::types::Tail::TlQ>(std::get<1>(_m)).a0;
        return ((x_pl == y_pm) && (len(only_a_p6) == Nat(0u))) && (len(only_b_p7) == Nat(0u))
            ? std::tuple{Text::lit(""), st_p0}
            : std::tuple{Text::lit("mismatch"), st_p0};
    }
    {
        return std::tuple{Text::lit("mismatch"), st_p0};
    }
}


prism_rtl::Turn<std::tuple<Text, crate::check::types::St>> UnifyRow::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& a0_p1 = this->a0_p1;
    const auto& b0_p2 = this->b0_p2;
    const auto& span_p3 = this->span_p3;
    auto a0_p1_1 = a0_p1;
    auto b0_p2_2 = b0_p2;
    auto span_p3_3 = span_p3;
    auto st_p0_4 = st_p0;
    return call_then(crate::check::types::recording::start_walk_row(st_p0_4, a0_p1_1), [=](crate::check::types::Rw walk_row_8688) {
        return ({
            auto a_p4 = walk_row_8688;
            call_then(crate::check::types::recording::start_walk_row(st_p0_4, b0_p2_2), [=, a_p4 = std::move(a_p4)](crate::check::types::Rw walk_row_8715) {
            return ({
                auto b_p5 = walk_row_8715;
                auto only_a_p6 = crate::check::types::minus_texts(prism_rtl::deref(a_p4).fams, prism_rtl::deref(b_p5).fams);
                auto only_b_p7 = crate::check::types::minus_texts(prism_rtl::deref(b_p5).fams, prism_rtl::deref(a_p4).fams);
                ({
                auto&& _m = std::tuple{prism_rtl::deref(a_p4).tail, prism_rtl::deref(b_p5).tail};
                prism_rtl::is<crate::check::types::Tail::TlClosed>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Tail::TlClosed>(std::get<1>(_m)) ? (len(only_a_p6) == Nat(0u)) && (len(only_b_p7) == Nat(0u))
                ? prism_rtl::finished(std::tuple{Text::lit(""), st_p0_4})
                : prism_rtl::finished(std::tuple{Text::lit("mismatch"), st_p0_4})
                : prism_rtl::is<crate::check::types::Tail::TlFlex>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Tail::TlFlex>(std::get<1>(_m)) ? ({
                auto&& x_p8 = prism_rtl::as<crate::check::types::Tail::TlFlex>(std::get<0>(_m)).a0;
                auto&& y_p9 = prism_rtl::as<crate::check::types::Tail::TlFlex>(std::get<1>(_m)).a0;
                x_p8 == y_p9
                ? (len(only_a_p6) == Nat(0u)) && (len(only_b_p7) == Nat(0u))
                ? prism_rtl::finished(std::tuple{Text::lit(""), st_p0_4})
                : prism_rtl::finished(std::tuple{Text::lit("mismatch"), st_p0_4})
                : ({
                auto lacking_pa = crate::check::types::union_texts(crate::check::types::union_texts(lacks_of(st_p0_4, x_p8), lacks_of(st_p0_4, y_p9)), crate::check::types::union_texts(prism_rtl::deref(a_p4).fams, prism_rtl::deref(b_p5).fams));
                auto [fresh_pb, st2_pc] = crate::check::types::recording::fresh_row(st_p0_4, lacking_pa);
                call_then(start_bind_row(st2_pc, x_p8, crate::check::types::Rw{.fams = only_b_p7, .minus = Array<Text>{}, .tail = prism_rtl::deref(fresh_pb).tail}, span_p3_3), [=](std::tuple<Text, crate::check::types::St> bind_row_9329) {
                return ({
                    auto [v1_pd, st3_pe] = bind_row_9329;
                    v1_pd != Text::lit("")
                    ? prism_rtl::finished(std::tuple{v1_pd, st3_pe})
                    : prism_rtl::more(prism_rtl::rc(BindRow(st3_pe, y_p9, crate::check::types::Rw{.fams = only_a_p6, .minus = Array<Text>{}, .tail = prism_rtl::deref(fresh_pb).tail}, span_p3_3)));
                });
            });
            });
            })
                : prism_rtl::is<crate::check::types::Tail::TlFlex>(std::get<0>(_m)) ? ({
                auto&& x_pf = prism_rtl::as<crate::check::types::Tail::TlFlex>(std::get<0>(_m)).a0;
                auto&& other_pg = std::get<1>(_m);
                len(only_a_p6) == Nat(0u)
                ? prism_rtl::more(prism_rtl::rc(BindRow(st_p0_4, x_pf, crate::check::types::Rw{.fams = only_b_p7, .minus = prism_rtl::deref(b_p5).minus, .tail = other_pg}, span_p3_3)))
                : prism_rtl::finished(std::tuple{Text::lit("mismatch"), st_p0_4});
            })
                : prism_rtl::is<crate::check::types::Tail::TlFlex>(std::get<1>(_m)) ? ({
                auto&& other_ph = std::get<0>(_m);
                auto&& y_pi = prism_rtl::as<crate::check::types::Tail::TlFlex>(std::get<1>(_m)).a0;
                len(only_b_p7) == Nat(0u)
                ? prism_rtl::more(prism_rtl::rc(BindRow(st_p0_4, y_pi, crate::check::types::Rw{.fams = only_a_p6, .minus = prism_rtl::deref(a_p4).minus, .tail = other_ph}, span_p3_3)))
                : prism_rtl::finished(std::tuple{Text::lit("mismatch"), st_p0_4});
            })
                : prism_rtl::is<crate::check::types::Tail::TlRigid>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Tail::TlRigid>(std::get<1>(_m)) ? ({
                auto&& x_pj = prism_rtl::as<crate::check::types::Tail::TlRigid>(std::get<0>(_m)).a0;
                auto&& y_pk = prism_rtl::as<crate::check::types::Tail::TlRigid>(std::get<1>(_m)).a0;
                ((x_pj == y_pk) && (len(only_a_p6) == Nat(0u))) && (len(only_b_p7) == Nat(0u))
                ? prism_rtl::finished(std::tuple{Text::lit(""), st_p0_4})
                : prism_rtl::finished(std::tuple{Text::lit("mismatch"), st_p0_4});
            })
                : prism_rtl::is<crate::check::types::Tail::TlQ>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Tail::TlQ>(std::get<1>(_m)) ? ({
                auto&& x_pl = prism_rtl::as<crate::check::types::Tail::TlQ>(std::get<0>(_m)).a0;
                auto&& y_pm = prism_rtl::as<crate::check::types::Tail::TlQ>(std::get<1>(_m)).a0;
                ((x_pl == y_pm) && (len(only_a_p6) == Nat(0u))) && (len(only_b_p7) == Nat(0u))
                ? prism_rtl::finished(std::tuple{Text::lit(""), st_p0_4})
                : prism_rtl::finished(std::tuple{Text::lit("mismatch"), st_p0_4});
            })
                : prism_rtl::finished(std::tuple{Text::lit("mismatch"), st_p0_4});
            });
            });
        });
        });
    });
}


/// `Start UnifyRow, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Text, crate::check::types::St>> start_unify_row(crate::check::types::St st_p0, crate::check::types::Rw a0_p1, crate::check::types::Rw b0_p2, crate::syntax::Range span_p3) {
    return prism_rtl::make_rc<UnifyRow>(st_p0, a0_p1, b0_p2, span_p3);
}


/// AskField: fn St, Ty, Text, Ty, Range, [Text] -> St
crate::check::types::St ask_field(const crate::check::types::St& st_p0, const crate::check::types::Ty& recv_p1, const Text& field_p2, const crate::check::types::Ty& result_p3, const crate::syntax::Range& span_p4, const Array<Text>& owners_p5) {
    crate::check::types::St this_ = st_p0;
    this_.field_qs = crate::prelude::push(this_.field_qs, FieldQ{.recv = recv_p1, .field = field_p2, .result = result_p3, .span = span_p4, .file = this_.file, .owners = owners_p5});
    return this_;
}


/// AskLayer: fn St, Ty, Range, Text -> St
crate::check::types::St ask_layer(const crate::check::types::St& st_p0, const crate::check::types::Ty& t_p1, const crate::syntax::Range& span_p2, const Text& fname_p3) {
    crate::check::types::St this_ = st_p0;
    this_.layer_qs = crate::prelude::push(this_.layer_qs, std::tuple{t_p1, span_p2, fname_p3});
    return this_;
}


/// LayerQuestions: unbounded fn St -> St
crate::check::types::St layer_questions(const crate::check::types::St& st_p0) {
    auto qs_p1 = st_p0.layer_qs;
    auto cleared_p2 = ({
        crate::check::types::St this_ = st_p0;
        this_.layer_qs = Array<std::tuple<crate::check::types::Ty, crate::syntax::Range, Text>>{};
        (std::move(this_));
    });
    return run_to_end(fold_job(qs_p1, cleared_p2, static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, std::tuple<crate::check::types::Ty, crate::syntax::Range, Text>>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, std::tuple<crate::check::types::Ty, crate::syntax::Range, Text>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto s_p3 = p0;
                auto [t_p4, span_p5, fname_p6] = p1;
                call_then(crate::check::types::start_head_sigil(s_p3, t_p4), [=](Text head_sigil_11312) {
                return ({
                    auto h_p7 = head_sigil_11312;
                    call_then(crate::check::types::start_is_free_headed(s_p3, t_p4), [=, h_p7 = std::move(h_p7)](bool is_free_headed_11339) {
                    return (is_free_headed_11339 || (h_p7 == Text::lit("$"))) || (h_p7 == Text::lit("!"))
                        ? prism_rtl::finished(crate::check::types::recording::err_fix(s_p3, Text::lit("layer-unknown"), span_p5, prism_rtl::cat("the layer of this argument to `", fname_p6, "` is not known here"), Text::lit("say it where the value is made: a name whose marks declare the layer (`let $x = ...`), `<<T>>` at the application that made it, or a signature on the enclosing `let`")))
                        : prism_rtl::finished(s_p3);
                });
                });
            });
            });
        }));
    }))));
}


prism_rtl::Turn<crate::check::types::St> LayerQuestions::cycle() const {
    const auto& st_p0 = this->st_p0;
    auto qs_p1 = prism_rtl::deref(st_p0).layer_qs;
    auto cleared_p2 = ({
        crate::check::types::St this_ = st_p0;
        this_.layer_qs = Array<std::tuple<crate::check::types::Ty, crate::syntax::Range, Text>>{};
        (std::move(this_));
    });
    return fold_job(qs_p1, cleared_p2, static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, std::tuple<crate::check::types::Ty, crate::syntax::Range, Text>>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, std::tuple<crate::check::types::Ty, crate::syntax::Range, Text>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto s_p3 = p0;
                auto [t_p4, span_p5, fname_p6] = p1;
                call_then(crate::check::types::start_head_sigil(s_p3, t_p4), [=](Text head_sigil_11312) {
                return ({
                    auto h_p7 = head_sigil_11312;
                    call_then(crate::check::types::start_is_free_headed(s_p3, t_p4), [=, h_p7 = std::move(h_p7)](bool is_free_headed_11339) {
                    return (is_free_headed_11339 || (h_p7 == Text::lit("$"))) || (h_p7 == Text::lit("!"))
                        ? prism_rtl::finished(crate::check::types::recording::err_fix(s_p3, Text::lit("layer-unknown"), span_p5, prism_rtl::cat("the layer of this argument to `", fname_p6, "` is not known here"), Text::lit("say it where the value is made: a name whose marks declare the layer (`let $x = ...`), `<<T>>` at the application that made it, or a signature on the enclosing `let`")))
                        : prism_rtl::finished(s_p3);
                });
                });
            });
            });
        }));
    })))->cycle();
}


/// `Start LayerQuestions, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_layer_questions(crate::check::types::St st_p0) {
    return prism_rtl::make_rc<LayerQuestions>(st_p0);
}


/// NameRow: fn St, Tail, Text -> St
crate::check::types::St name_row(const crate::check::types::St& st_p0, const crate::check::types::Tail& tail1, const Text& text2) {
    auto&& _m = std::tuple{tail1, text2};
    if (prism_rtl::is<crate::check::types::Tail::TlFlex>(std::get<0>(_m))) {
        auto&& n_p1 = prism_rtl::as<crate::check::types::Tail::TlFlex>(std::get<0>(_m)).a0;
        auto&& q_p2 = std::get<1>(_m);
        crate::check::types::St this_ = st_p0;
        this_.row_names = insert(this_.row_names, n_p1, q_p2);
        return this_;
    }
    {
        return st_p0;
    }
    prism_rtl::unreachable("no arm matched");
}


/// RowName: fn St, Nat -> Text
Text row_name(const crate::check::types::St& st_p0, const Nat& n_p1) {
    return or_(crate::prelude::get(st_p0.row_names, n_p1), prism_rtl::cat("r", n_p1));
}


/// LacksOf: fn St, Nat -> [Text]
Array<Text> lacks_of(const crate::check::types::St& st_p0, const Nat& n_p1) {
    return or_(crate::prelude::get(st_p0.lacks, n_p1), Array<Text>{});
}


/// BindRow: unbounded fn St, Nat, Rw, Range -> ((Text, St))
std::tuple<Text, crate::check::types::St> bind_row(const crate::check::types::St& st_p0, const Nat& n_p1, const crate::check::types::Rw& rw_p2, const crate::syntax::Range& span_p3) {
    auto bad_p4 = crate::check::types::inter_texts(lacks_of(st_p0, n_p1), rw_p2.fams);
    return len(bad_p4) > Nat(0u)
        ? ({
        auto fam_p5 = or_(index(bad_p4, Nat(0u)), Text::lit(""));
        std::tuple{Text::lit("reported"), crate::check::types::recording::err_fix(st_p0, Text::lit("row-lacks"), span_p3, prism_rtl::cat("`", row_name(st_p0, n_p1), " | ", fam_p5, ".*` promises `", row_name(st_p0, n_p1), "` has no `", fam_p5, "` tags"), prism_rtl::cat("answer the `", fam_p5, "` tags before this point, or widen the row"))};
    })
        : ({
        auto st2_p6 = ({
            __label__ _done;
            prism_rtl::Slot<crate::check::types::St> _v;
            auto&& _m = rw_p2.tail;
            if (prism_rtl::is<crate::check::types::Tail::TlFlex>(_m)) {
                auto&& m_p7 = prism_rtl::as<crate::check::types::Tail::TlFlex>(_m).a0;
                _v.set(({
                    crate::check::types::St this_ = st_p0;
                    this_.lacks = insert(this_.lacks, m_p7, crate::check::types::union_texts(lacks_of(st_p0, m_p7), lacks_of(st_p0, n_p1)));
                    (std::move(this_));
                }));
                goto _done;
            }
            {
                _v.set(st_p0);
                goto _done;
            }
        _done:
            _v.take();
        });
        std::tuple{Text::lit(""), ({
        crate::check::types::St this_ = st2_p6;
        this_.rows = insert(this_.rows, n_p1, rw_p2);
        (std::move(this_));
    })};
    });
}


prism_rtl::Turn<std::tuple<Text, crate::check::types::St>> BindRow::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& n_p1 = this->n_p1;
    const auto& rw_p2 = this->rw_p2;
    const auto& span_p3 = this->span_p3;
    auto bad_p4 = crate::check::types::inter_texts(lacks_of(st_p0, n_p1), prism_rtl::deref(rw_p2).fams);
    return len(bad_p4) > Nat(0u)
        ? ({
        auto fam_p5 = or_(index(bad_p4, Nat(0u)), Text::lit(""));
        (prism_rtl::finished(std::tuple{Text::lit("reported"), crate::check::types::recording::err_fix(st_p0, Text::lit("row-lacks"), span_p3, prism_rtl::cat("`", row_name(st_p0, n_p1), " | ", fam_p5, ".*` promises `", row_name(st_p0, n_p1), "` has no `", fam_p5, "` tags"), prism_rtl::cat("answer the `", fam_p5, "` tags before this point, or widen the row"))}));
    })
        : ({
        auto st2_p6 = ({
            __label__ _done;
            prism_rtl::Slot<crate::check::types::St> _v;
            auto&& _m = prism_rtl::deref(rw_p2).tail;
            if (prism_rtl::is<crate::check::types::Tail::TlFlex>(_m)) {
                auto&& m_p7 = prism_rtl::as<crate::check::types::Tail::TlFlex>(_m).a0;
                _v.set(({
                    crate::check::types::St this_ = st_p0;
                    this_.lacks = insert(this_.lacks, m_p7, crate::check::types::union_texts(lacks_of(st_p0, m_p7), lacks_of(st_p0, n_p1)));
                    (std::move(this_));
                }));
                goto _done;
            }
            {
                _v.set(st_p0);
                goto _done;
            }
        _done:
            _v.take();
        });
        (prism_rtl::finished(std::tuple{Text::lit(""), ({
        crate::check::types::St this_ = st2_p6;
        this_.rows = insert(this_.rows, n_p1, rw_p2);
        (std::move(this_));
    })}));
    });
}


/// `Start BindRow, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Text, crate::check::types::St>> start_bind_row(crate::check::types::St st_p0, Nat n_p1, crate::check::types::Rw rw_p2, crate::syntax::Range span_p3) {
    return prism_rtl::make_rc<BindRow>(st_p0, n_p1, rw_p2, span_p3);
}

}  // namespace crate::check::types::unify


// The module `Checking`, from `target/bootstrap/cpp-src/prismc/checking.prism`.
namespace crate::checking {

void CheckJob::show(Printer& p) const {
    p.record("CheckJob", {{"read", read}, {"world", world}, {"typed", typed}, {"unused", unused}});
}

Pod CheckJob::to_pod() const {
    return Pod::record("CheckJob", {{"read", prism_rtl::to_pod(read)}, {"world", prism_rtl::to_pod(world)}, {"typed", prism_rtl::to_pod(typed)}, {"unused", prism_rtl::to_pod(unused)}});
}

Result<CheckJob> CheckJob::from_pod(const Pod& whole) {
    return CheckJob{.read = TRY(prism_rtl::from_pod<crate::reading::ReadInput>(TRY(crate::prelude::field(whole, "read")))), .world = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "world")))), .typed = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "typed")))), .unused = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "unused"))))};
}


/// CheckFiles: unbounded fn CheckJob -> Outcome
crate::program::Outcome_ check_files(const CheckJob& job_p0) {
    auto read_p1 = crate::reading::assemble(job_p0.read);
    return len(prism_rtl::deref(read_p1).errors) > Nat(0u)
        ? ({
        auto report_p2 = crate::reading::tree_report(job_p0.read, prism_rtl::deref(read_p1).errors);
        crate::program::Outcome_{.text = prism_rtl::cat(report_p2, "\n"), .failed = true, .report = report_p2};
    })
        : ({
        auto pp_p3 = crate::reading::parse_program(read_p1);
        (prism_rtl::deref(pp_p3).errors != Text::lit("")
        ? crate::program::Outcome_{.text = prism_rtl::cat(prism_rtl::deref(pp_p3).errors, "parse errors\n"), .failed = true, .report = prism_rtl::cat(prism_rtl::deref(pp_p3).errors, "parse errors")}
        : ({
        auto pre_p4 = crate::reading::tree_decl_diags(pp_p3);
        auto checked_p5 = each(prism_rtl::deref(pp_p3).trees, [&](const crate::syntax::Module& t_p9) { return crate::compile::without_tests(t_p9); });
        auto report_p6 = crate::check::check_program(prism_rtl::deref(pp_p3).srcs, checked_p5, job_p0.world, prism_rtl::deref(pp_p3).shown, job_p0.typed, job_p0.unused, pre_p4);
        auto summary_p7 = prism_rtl::deref(report_p6).errors == Nat(0u)
            ? Text::lit("no errors\n")
            : prism_rtl::cat(prism_rtl::deref(report_p6).errors, " error", prism_rtl::deref(report_p6).errors == Nat(1u)
            ? Text::lit("")
            : Text::lit("s"), "\n");
        auto shown_p8 = job_p0.typed
            ? prism_rtl::cat(crate::check::typed::print::typed_sexp(prism_rtl::deref(pp_p3).srcs, checked_p5, prism_rtl::deref(pp_p3).shown, prism_rtl::deref(report_p6).typed), commented(prism_rtl::cat(report_p6->text, summary_p7)))
            : prism_rtl::cat(report_p6->text, summary_p7);
        crate::program::Outcome_{.text = shown_p8, .failed = prism_rtl::deref(report_p6).errors > Nat(0u), .report = prism_rtl::cat(report_p6->text, summary_p7)};
    }));
    });
}


prism_rtl::Turn<crate::program::Outcome_> CheckFiles::cycle() const {
    const auto& job_p0 = this->job_p0;
    auto job_p0_1 = job_p0;
    return call_then(crate::reading::start_assemble(prism_rtl::deref(job_p0_1).read), [=](crate::reading::Assembled assemble_1698) {
        return ({
            auto read_p1 = assemble_1698;
            len(prism_rtl::deref(read_p1).errors) > Nat(0u)
            ? ({
            auto report_p2 = crate::reading::tree_report(prism_rtl::deref(job_p0_1).read, prism_rtl::deref(read_p1).errors);
            (prism_rtl::finished(crate::program::Outcome_{.text = prism_rtl::cat(report_p2, "\n"), .failed = true, .report = report_p2}));
        })
            : call_then(crate::reading::start_parse_program(read_p1), [=](crate::reading::ParsedProgram parse_program_1890) {
            return ({
                auto pp_p3 = parse_program_1890;
                (prism_rtl::deref(pp_p3).errors != Text::lit("")
                ? prism_rtl::finished(crate::program::Outcome_{.text = prism_rtl::cat(prism_rtl::deref(pp_p3).errors, "parse errors\n"), .failed = true, .report = prism_rtl::cat(prism_rtl::deref(pp_p3).errors, "parse errors")})
                : ({
                auto pre_p4 = crate::reading::tree_decl_diags(pp_p3);
                auto checked_p5 = each(prism_rtl::deref(pp_p3).trees, [&](const crate::syntax::Module& t_p9) { return crate::compile::without_tests(t_p9); });
                call_then(crate::check::start_check_program(prism_rtl::deref(pp_p3).srcs, checked_p5, job_p0_1->world, prism_rtl::deref(pp_p3).shown, prism_rtl::deref(job_p0_1).typed, prism_rtl::deref(job_p0_1).unused, pre_p4), [=](crate::check::Report_ check_program_2313) {
                return ({
                    auto report_p6 = check_program_2313;
                    auto summary_p7 = prism_rtl::deref(report_p6).errors == Nat(0u)
                        ? Text::lit("no errors\n")
                        : prism_rtl::cat(prism_rtl::deref(report_p6).errors, " error", prism_rtl::deref(report_p6).errors == Nat(1u)
                        ? Text::lit("")
                        : Text::lit("s"), "\n");
                    auto shown_p8 = prism_rtl::deref(job_p0_1).typed
                        ? prism_rtl::cat(crate::check::typed::print::typed_sexp(prism_rtl::deref(pp_p3).srcs, checked_p5, prism_rtl::deref(pp_p3).shown, prism_rtl::deref(report_p6).typed), commented(prism_rtl::cat(report_p6->text, summary_p7)))
                        : prism_rtl::cat(report_p6->text, summary_p7);
                    (prism_rtl::finished(crate::program::Outcome_{.text = shown_p8, .failed = prism_rtl::deref(report_p6).errors > Nat(0u), .report = prism_rtl::cat(report_p6->text, summary_p7)}));
                });
            });
            }));
            });
        });
        });
    });
}


/// `Start CheckFiles, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::program::Outcome_> start_check_files(CheckJob job_p0) {
    return prism_rtl::make_rc<CheckFiles>(job_p0);
}


/// Commented: fn Text -> Text
Text commented(const Text& t_p0) {
    return concat(each(filter(split_on(t_p0, Text::lit("\n")), [&](const Text& l_p1) { return l_p1 != Text::lit(""); }), [&](const Text& l_p2) { return prism_rtl::cat("; ", l_p2, "\n"); }));
}


// `@CheckMain` is inlined where it is applied.

/// let checkValued
Array<Text> check_valued() {
    return Array(std::vector{Text::lit("--prelude"), Text::lit("--out"), Text::lit("--world")});
}


// `@FinishCheck` is inlined where it is applied.

// `@WriteOut` is inlined where it is applied.

}  // namespace crate::checking


// The module `Compile`, from `target/bootstrap/cpp-src/prismc/compile.prism`.
namespace crate::compile {

void CompileJob::show(Printer& p) const {
    p.record("CompileJob", {{"read", read}, {"name", name}, {"runtime", runtime}, {"target", target}});
}

Pod CompileJob::to_pod() const {
    return Pod::record("CompileJob", {{"read", prism_rtl::to_pod(read)}, {"name", prism_rtl::to_pod(name)}, {"runtime", prism_rtl::to_pod(runtime)}, {"target", prism_rtl::to_pod(target)}});
}

Result<CompileJob> CompileJob::from_pod(const Pod& whole) {
    return CompileJob{.read = TRY(prism_rtl::from_pod<crate::reading::ReadInput>(TRY(crate::prelude::field(whole, "read")))), .name = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .runtime = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "runtime")))), .target = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "target"))))};
}


void Compiled::show(Printer& p) const {
    p.record("Compiled", {{"files", files}, {"failed", failed}, {"report", report}});
}

Pod Compiled::to_pod() const {
    return Pod::record("Compiled", {{"files", prism_rtl::to_pod(files)}, {"failed", prism_rtl::to_pod(failed)}, {"report", prism_rtl::to_pod(report)}});
}

Result<Compiled> Compiled::from_pod(const Pod& whole) {
    return Compiled{.files = TRY(prism_rtl::from_pod<Array<std::tuple<Text, Text>>>(TRY(crate::prelude::field(whole, "files")))), .failed = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "failed")))), .report = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "report"))))};
}


// `@CompileMain` is inlined where it is applied.

/// let compileValued
Array<Text> compile_valued() {
    return Array(std::vector{Text::lit("-o"), Text::lit("--prelude"), Text::lit("--name"), Text::lit("--runtime"), Text::lit("--target")});
}


/// ?RuntimeOf: fn ?Text, ?Text, Text -> ?Text
std::optional<Text> runtime_of(const std::optional<Text>& named_o0, const std::optional<Text>& root_o1, const Text& out_p2) {
    if (prism_rtl::is_some(named_o0)) {
        auto&& r_p3 = prism_rtl::some_of(named_o0);
        return std::optional(r_p3);
    }
    if (prism_rtl::is_none(named_o0)) {
        return !crate::syntax::lexer::chars::has_prefix(out_p2, Text::lit("/"))
            ? std::optional(runtime_for(out_p2))
            : root_o1;
    }
    prism_rtl::unreachable("no arm matched");
}


/// RuntimeFor: fn Text -> Text
Text runtime_for(const Text& out_p0) {
    auto parts_p1 = filter(split_on(out_p0, Text::lit("/")), [&](const Text& p_p2) { return (p_p2 != Text::lit("")) && (p_p2 != Text::lit(".")); });
    return len(parts_p1) == Nat(0u)
        ? Text::lit(".")
        : crate::syntax::lexer::chars::join(each(parts_p1, [&](const Text& _p0) { return Text::lit(".."); }), Text::lit("/"));
}


/// CompileProgram: unbounded fn CompileJob -> Compiled
Compiled compile_program(const CompileJob& job_p0) {
    auto read_p1 = crate::reading::assemble(job_p0.read);
    return len(prism_rtl::deref(read_p1).errors) > Nat(0u)
        ? Compiled{.files = Array<std::tuple<Text, Text>>{}, .failed = true, .report = crate::reading::tree_report(job_p0.read, prism_rtl::deref(read_p1).errors)}
        : ({
        auto pp_p2 = crate::reading::parse_program(read_p1);
        (prism_rtl::deref(pp_p2).errors != Text::lit("")
        ? Compiled{.files = Array<std::tuple<Text, Text>>{}, .failed = true, .report = prism_rtl::cat(prism_rtl::deref(pp_p2).errors, "parse errors")}
        : ({
        auto pre_p3 = crate::reading::tree_decl_diags(pp_p2);
        auto report_p4 = crate::check::check_program(prism_rtl::deref(pp_p2).srcs, each(prism_rtl::deref(pp_p2).trees, [&](const crate::syntax::Module& t_p5) { return without_tests(t_p5); }), Array<Text>{}, prism_rtl::deref(pp_p2).shown, true, false, pre_p3);
        (prism_rtl::deref(report_p4).errors > Nat(0u)
        ? Compiled{.files = Array<std::tuple<Text, Text>>{}, .failed = true, .report = prism_rtl::cat(report_p4->text, prism_rtl::deref(report_p4).errors, " error", prism_rtl::deref(report_p4).errors == Nat(1u)
        ? Text::lit("")
        : Text::lit("s"))}
        : ({
        auto model_p6 = crate::lower::program::lower_program(prism_rtl::deref(pp_p2).srcs, prism_rtl::deref(pp_p2).trees, prism_rtl::deref(pp_p2).shown, prism_rtl::deref(report_p4).typed, job_p0.name);
        auto files_p7 = job_p0.target == Text::lit("cpp")
            ? crate::emit::cpp::program::emit_cpp(model_p6, job_p0.runtime, prism_rtl::deref(read_p1).scripts)
            : crate::emit::rust::items::emit_crate(model_p6, job_p0.runtime, prism_rtl::deref(read_p1).scripts);
        auto refused_p8 = fold(files_p7, Array<Text>{}, [&](const Array<Text>& acc_p9, const std::tuple<Text, Text>& _p1) {
            auto&& path_pa = std::get<0>(_p1);
            auto&& text_pb = std::get<1>(_p1);
            return fold(refusals(text_pb), acc_p9, [&](const Array<Text>& a_pc, const Text& r_pd) { return crate::check::types::add_text(a_pc, prism_rtl::cat(path_pa, ": ", r_pd)); });
        });
        len(refused_p8) == Nat(0u)
        ? Compiled{.files = files_p7, .failed = false, .report = Text::lit("")}
        : Compiled{.files = files_p7, .failed = true, .report = prism_rtl::cat(concat(each(refused_p8, [&](const Text& r_pe) { return prism_rtl::cat("error[not-lowered]: ", r_pe, "\n"); })), len(refused_p8), " construct", len(refused_p8) == Nat(1u) ? Text::lit("") : Text::lit("s"), " the back end does not lower (the crate is written, with a `compile_error!` at each)")};
    }));
    }));
    });
}


prism_rtl::Turn<Compiled> CompileProgram::cycle() const {
    const auto& job_p0 = this->job_p0;
    auto job_p0_1 = job_p0;
    return call_then(crate::reading::start_assemble(prism_rtl::deref(job_p0_1).read), [=](crate::reading::Assembled assemble_4670) {
        return ({
            auto read_p1 = assemble_4670;
            len(prism_rtl::deref(read_p1).errors) > Nat(0u)
            ? prism_rtl::finished(Compiled{.files = Array<std::tuple<Text, Text>>{}, .failed = true, .report = crate::reading::tree_report(prism_rtl::deref(job_p0_1).read, prism_rtl::deref(read_p1).errors)})
            : call_then(crate::reading::start_parse_program(read_p1), [=](crate::reading::ParsedProgram parse_program_4822) {
            return ({
                auto pp_p2 = parse_program_4822;
                (prism_rtl::deref(pp_p2).errors != Text::lit("")
                ? prism_rtl::finished(Compiled{.files = Array<std::tuple<Text, Text>>{}, .failed = true, .report = prism_rtl::cat(prism_rtl::deref(pp_p2).errors, "parse errors")})
                : ({
                auto pre_p3 = crate::reading::tree_decl_diags(pp_p2);
                call_then(crate::check::start_check_program(prism_rtl::deref(pp_p2).srcs, each(prism_rtl::deref(pp_p2).trees, [&](const crate::syntax::Module& t_p5) { return without_tests(t_p5); }), Array<Text>{}, prism_rtl::deref(pp_p2).shown, true, false, pre_p3), [=](crate::check::Report_ check_program_5014) {
                return ({
                    auto report_p4 = check_program_5014;
                    (prism_rtl::deref(report_p4).errors > Nat(0u)
                    ? prism_rtl::finished(Compiled{.files = Array<std::tuple<Text, Text>>{}, .failed = true, .report = prism_rtl::cat(report_p4->text, prism_rtl::deref(report_p4).errors, " error", prism_rtl::deref(report_p4).errors == Nat(1u)
                    ? Text::lit("")
                    : Text::lit("s"))})
                    : call_then(crate::lower::program::start_lower_program(prism_rtl::deref(pp_p2).srcs, prism_rtl::deref(pp_p2).trees, prism_rtl::deref(pp_p2).shown, prism_rtl::deref(report_p4).typed, prism_rtl::deref(job_p0_1).name), [=](crate::lower::model::Model lower_program_5303) {
                    return ({
                        auto model_p6 = lower_program_5303;
                        auto files_p7 = job_p0_1->target == Text::lit("cpp")
                            ? crate::emit::cpp::program::emit_cpp(model_p6, job_p0_1->runtime, prism_rtl::deref(read_p1).scripts)
                            : crate::emit::rust::items::emit_crate(model_p6, job_p0_1->runtime, prism_rtl::deref(read_p1).scripts);
                        auto refused_p8 = fold(files_p7, Array<Text>{}, [&](const Array<Text>& acc_p9, const std::tuple<Text, Text>& _p1) {
                            auto&& path_pa = std::get<0>(_p1);
                            auto&& text_pb = std::get<1>(_p1);
                            return fold(refusals(text_pb), acc_p9, [&](const Array<Text>& a_pc, const Text& r_pd) { return crate::check::types::add_text(a_pc, prism_rtl::cat(path_pa, ": ", r_pd)); });
                        });
                        len(refused_p8) == Nat(0u)
                        ? prism_rtl::finished(Compiled{.files = files_p7, .failed = false, .report = Text::lit("")})
                        : prism_rtl::finished(Compiled{.files = files_p7, .failed = true, .report = prism_rtl::cat(concat(each(refused_p8, [&](const Text& r_pe) { return prism_rtl::cat("error[not-lowered]: ", r_pe, "\n"); })), len(refused_p8), " construct", len(refused_p8) == Nat(1u) ? Text::lit("") : Text::lit("s"), " the back end does not lower (the crate is written, with a `compile_error!` at each)")});
                    });
                }));
                });
            });
            }));
            });
        });
        });
    });
}


/// `Start CompileProgram, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Compiled> start_compile_program(CompileJob job_p0) {
    return prism_rtl::make_rc<CompileProgram>(job_p0);
}


/// Refusals: fn Text -> [Text]
Array<Text> refusals(const Text& text_p0) {
    auto marker_p1 = Text::lit("compile_error!(\"prismc does not lower ");
    auto parts_p2 = split_on(text_p0, marker_p1);
    return fold(drop(parts_p2, Nat(1u)), Array<Text>{}, [&](const Array<Text>& acc_p3, const Text& part_p4) { return crate::check::types::add_text(acc_p3, or_(index(split_on(part_p4, Text::lit("\")")), Nat(0u)), part_p4)); });
}


/// WithoutTests: fn Module -> Module
crate::syntax::Module without_tests(const crate::syntax::Module& m_p0) {
    crate::syntax::Module this_ = m_p0;
    this_.decls = filter(this_.decls, [&](const crate::syntax::decls::Decl& d_p1) { return !is_test_decl(d_p1); });
    return this_;
}


/// IsTestDecl: fn Decl -> Bool
bool is_test_decl(const crate::syntax::decls::Decl& d_p0) {
    auto&& _m = d_p0.kind;
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DTest>(_m)) {
        return true;
    }
    {
        return false;
    }
}


// `@FinishCompile` is inlined where it is applied.

}  // namespace crate::compile
