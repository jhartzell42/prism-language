// The modules `check::typed`, `check::types`: its value types (records, tags, newtypes and choices with their cases), each
// after the types it holds by value, emitted by prismc (claude/backend.md). Edit the Prism
// source, not this file.
#pragma once

#include <check/typed/decl.hpp>
#include <check/types/decl.hpp>
#include "elem.decl.hpp"
#include <check/errors/decl.hpp>
#include <check/typed/print/decl.hpp>
#include <check/types/colors/decl.hpp>
#include <check/types/recording/decl.hpp>
#include <check/types/schemes/decl.hpp>
#include <check/types/unify/decl.hpp>
#include <syntax/decls/decl.hpp>
#include <syntax/lexer/decl.hpp>
#include <syntax/lexer/chars/decl.hpp>
#include <syntax/lexer/corpus/decl.hpp>
#include <syntax/lexer/layout/decl.hpp>
#include <syntax/lexer/literals/decl.hpp>
#include <syntax/lexer/regexes/decl.hpp>
#include <syntax/lexer/templates/decl.hpp>
#include <syntax/lexer/words/decl.hpp>
#include <syntax/types.hpp>

namespace crate {

using namespace prelude;

namespace check::typed {

/// `SrcAt`:
///
/// ```prism
/// type SrcAt = record:
/// ```
struct SrcAt {
    using prism_value = void;
    Nat file_p;
    crate::syntax::Range span_p;
    const SrcAt* operator->() const { return this; }
    SrcAt* operator->() { return this; }
    bool operator==(const SrcAt&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<SrcAt> from_pod(const Pod& whole);
};


}  // namespace check::typed

namespace check::typed {

/// `TProgram`:
///
/// ```prism
/// type TProgram = record:
/// ```
struct TProgram {
    using prism_value = void;
    Array<TyNote> exprs_p;
    Array<AppNote> apps_p;
    Array<LiftNote> lifts_p;
    Array<FnNote> fns_p;
    Array<ImplNote> impls_p;
    Array<MethodNote> methods_p;
    Array<GroupNote> groups_p;
    Array<BinderNote> binders_p;
    Array<LocalNote> locals_p;
    Array<LocalNote> uses_p;
    Array<LocalNote> calls_p;
    Array<GlobalNote> globals_p;
    Array<GenNote> gens_p;
    Array<InstNote> insts_p;
    Array<DefNote> defs_p;
    Array<SrcAt> unshrunk_p;
    const TProgram* operator->() const { return this; }
    TProgram* operator->() { return this; }
    bool operator==(const TProgram&) const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<TProgram> from_pod(const Pod& whole);
};


}  // namespace check::typed

namespace check::types {

/// `Col`:
///
/// ```prism
/// type Col = choice:
/// ```
class Col {
public:
    using prism_value = void;
    struct CBound {
        bool operator==(const CBound&) const = default;
    };

    struct CUnbound {
        bool operator==(const CUnbound&) const = default;
    };

    struct CRigid {
        Text a0;
        bool operator==(const CRigid&) const = default;
    };

    struct CQ {
        Text a0;
        bool operator==(const CQ&) const = default;
    };

    struct CFlex {
        Nat a0;
        bool operator==(const CFlex&) const = default;
    };
    using Cases = std::variant<CBound, CUnbound, CRigid, CQ, CFlex>;
    template <class C>
        requires prism_rtl::one_of<C, CBound, CUnbound, CRigid, CQ, CFlex>
    Col(C c) : cases_(std::move(c)) {}
    const Cases& cases() const { return cases_; }
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Col> from_pod(const Pod& whole);

private:
    Cases cases_;
};

inline bool operator==(const Col& a, const Col& b) { return a.cases() == b.cases(); }

}  // namespace check::types

namespace check::types {

/// `Tail`:
///
/// ```prism
/// type Tail = choice:
/// ```
class Tail {
public:
    using prism_value = void;
    struct TlClosed {
        bool operator==(const TlClosed&) const = default;
    };

    struct TlFlex {
        Nat a0;
        bool operator==(const TlFlex&) const = default;
    };

    struct TlRigid {
        Text a0;
        bool operator==(const TlRigid&) const = default;
    };

    struct TlQ {
        Text a0;
        bool operator==(const TlQ&) const = default;
    };
    using Cases = std::variant<TlClosed, TlFlex, TlRigid, TlQ>;
    template <class C>
        requires prism_rtl::one_of<C, TlClosed, TlFlex, TlRigid, TlQ>
    Tail(C c) : cases_(std::move(c)) {}
    const Cases& cases() const { return cases_; }
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Tail> from_pod(const Pod& whole);

private:
    Cases cases_;
};

inline bool operator==(const Tail& a, const Tail& b) { return a.cases() == b.cases(); }

}  // namespace check::types

namespace check::types {

/// `VInfo`:
///
/// ```prism
/// type VInfo = record:
/// ```
struct VInfo {
    using prism_value = void;
    bool plain_p;
    Nat level_p;
    Text name_p;
    const VInfo* operator->() const { return this; }
    VInfo* operator->() { return this; }
    bool operator==(const VInfo&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<VInfo> from_pod(const Pod& whole);
};


}  // namespace check::types

namespace check::typed {

/// `AppNote`:
///
/// ```prism
/// type AppNote = record:
/// ```
struct AppNote {
    using prism_value = void;
    SrcAt at_p;
    Text callee_p;
    Text kind_p;
    Text layer_p;
    Array<Nat> lifted_p;
    Text inner_p;
    crate::check::types::Col color_p;
    const AppNote* operator->() const { return this; }
    AppNote* operator->() { return this; }
    bool operator==(const AppNote&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<AppNote> from_pod(const Pod& whole);
};


}  // namespace check::typed

namespace check::typed {

/// `FnNote`:
///
/// ```prism
/// type FnNote = record:
/// ```
struct FnNote {
    using prism_value = void;
    SrcAt at_p;
    Text name_p;
    crate::check::types::Col declared_p;
    crate::check::types::Col body_p;
    const FnNote* operator->() const { return this; }
    FnNote* operator->() { return this; }
    bool operator==(const FnNote&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<FnNote> from_pod(const Pod& whole);
};


}  // namespace check::typed

namespace check::typed {

/// `GenNote`:
///
/// ```prism
/// type GenNote = record:
/// ```
struct GenNote {
    using prism_value = void;
    SrcAt at_p;
    Text name_p;
    Array<Text> tys_p;
    Array<Text> cols_p;
    const GenNote* operator->() const { return this; }
    GenNote* operator->() { return this; }
    bool operator==(const GenNote&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<GenNote> from_pod(const Pod& whole);
};


}  // namespace check::typed

namespace check::typed {

/// `GlobalNote`:
///
/// ```prism
/// type GlobalNote = record:
/// ```
struct GlobalNote {
    using prism_value = void;
    SrcAt at_p;
    Text target_p;
    const GlobalNote* operator->() const { return this; }
    GlobalNote* operator->() { return this; }
    bool operator==(const GlobalNote&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<GlobalNote> from_pod(const Pod& whole);
};


}  // namespace check::typed

namespace check::typed {

/// `GroupNote`:
///
/// ```prism
/// type GroupNote = record:
/// ```
struct GroupNote {
    using prism_value = void;
    SrcAt at_p;
    Text kind_p;
    Array<Array<Nat>> order_p;
    const GroupNote* operator->() const { return this; }
    GroupNote* operator->() { return this; }
    bool operator==(const GroupNote&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<GroupNote> from_pod(const Pod& whole);
};


}  // namespace check::typed

namespace check::typed {

/// `InstNote`:
///
/// ```prism
/// type InstNote = record:
/// ```
struct InstNote {
    using prism_value = void;
    SrcAt at_p;
    Text name_p;
    Array<std::tuple<Text, crate::check::types::Ty>> tys_p;
    Array<std::tuple<Text, crate::check::types::Col>> cols_p;
    const InstNote* operator->() const { return this; }
    InstNote* operator->() { return this; }
    bool operator==(const InstNote&) const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<InstNote> from_pod(const Pod& whole);
};


}  // namespace check::typed

namespace check::typed {

/// `LiftNote`:
///
/// ```prism
/// type LiftNote = record:
/// ```
struct LiftNote {
    using prism_value = void;
    SrcAt at_p;
    Text sigil_p;
    Array<crate::syntax::Range> operands_p;
    const LiftNote* operator->() const { return this; }
    LiftNote* operator->() { return this; }
    bool operator==(const LiftNote&) const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<LiftNote> from_pod(const Pod& whole);
};


}  // namespace check::typed

namespace check::typed {

/// `LocalNote`:
///
/// ```prism
/// type LocalNote = record:
/// ```
struct LocalNote {
    using prism_value = void;
    SrcAt at_p;
    Nat id_p;
    const LocalNote* operator->() const { return this; }
    LocalNote* operator->() { return this; }
    bool operator==(const LocalNote&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<LocalNote> from_pod(const Pod& whole);
};


}  // namespace check::typed

namespace check::typed {

/// `MethodNote`:
///
/// ```prism
/// type MethodNote = record:
/// ```
struct MethodNote {
    using prism_value = void;
    SrcAt at_p;
    Text method_p;
    Text cls_p;
    const MethodNote* operator->() const { return this; }
    MethodNote* operator->() { return this; }
    bool operator==(const MethodNote&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<MethodNote> from_pod(const Pod& whole);
};


}  // namespace check::typed

namespace check::types {

/// `CLeq`:
///
/// ```prism
/// type CLeq = record:
/// ```
struct CLeq {
    using prism_value = void;
    Col lo_p;
    Col hi_p;
    Nat file_p;
    crate::syntax::Range span_p;
    Text kind_p;
    Text name_p;
    Text why_p;
    const CLeq* operator->() const { return this; }
    CLeq* operator->() { return this; }
    bool operator==(const CLeq&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<CLeq> from_pod(const Pod& whole);
};


}  // namespace check::types

namespace check::types {

/// `Rw`:
///
/// ```prism
/// type Rw = record:
/// ```
struct Rw {
    using prism_value = void;
    Array<Text> fams_p;
    Array<Text> minus_p;
    Tail tail_p;
    const Rw* operator->() const { return this; }
    Rw* operator->() { return this; }
    bool operator==(const Rw&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Rw> from_pod(const Pod& whole);
};


}  // namespace check::types

namespace check::types {

/// `St`:
///
/// ```prism
/// type St = record:
/// ```
struct St {
    using prism_value = void;
    Nat next_p;
    Map<Nat, Ty> tys_p;
    Map<Nat, VInfo> infos_p;
    Map<Nat, Rw> rows_p;
    Map<Nat, Array<Text>> lacks_p;
    Array<Want> wants_p;
    Array<Incl> incls_p;
    Array<crate::check::errors::CDiag> diags_p;
    Nat level_p;
    Nat file_p;
    Col color_p;
    Text color_why_p;
    Array<std::tuple<Col, Text, crate::syntax::Range>> color_flex_p;
    Map<Nat, Col> cols_p;
    Array<CLeq> cleqs_p;
    Map<Nat, Text> col_q_p;
    Map<Text, Text> col_up_p;
    Array<std::tuple<Ty, Ty, crate::syntax::Range>> deferred_p;
    Map<Nat, crate::syntax::Range> binder_at_p;
    Map<Nat, Text> row_names_p;
    Array<std::tuple<Ty, crate::syntax::Range, Text>> layer_qs_p;
    Array<crate::check::types::unify::FieldQ> field_qs_p;
    bool recording_p;
    crate::check::typed::TProgram typed_p;
    Map<Text, Array<Text>> choices_p;
    Map<Text, Ty> size_tys_p;
    Nat local_next_p;
    Map<Text, Nat> local_ids_p;
    Array<std::tuple<Text, Text>> any_givens_p;
    const St* operator->() const { return this; }
    St* operator->() { return this; }
    bool operator==(const St&) const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<St> from_pod(const Pod& whole);
};


}  // namespace check::types

namespace check::types {

/// `Incl`:
///
/// ```prism
/// type Incl = record:
/// ```
struct Incl {
    using prism_value = void;
    Rw sub_p;
    Rw sup_p;
    Nat file_p;
    crate::syntax::Range span_p;
    Text what_p;
    bool forward_p;
    const Incl* operator->() const { return this; }
    Incl* operator->() { return this; }
    bool operator==(const Incl&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Incl> from_pod(const Pod& whole);
};


}  // namespace check::types

namespace check::types {

/// `Ty`:
///
/// ```prism
/// type Ty = choice:
/// ```
class Ty {
public:
    using prism_value = void;
    struct TyFlex {
        Nat a0;
        bool operator==(const TyFlex&) const = default;
    };

    struct TyRigid {
        Text a0;
        bool operator==(const TyRigid&) const = default;
    };

    struct TyQ {
        Text a0;
        bool operator==(const TyQ&) const = default;
    };

    struct TyCon {
        Text a0;
        Array<Ty> a1;
        bool operator==(const TyCon&) const;
    };

    struct TyFn {
        Col a0;
        Array<Ty> a1;
        prism_rtl::Rc<const Ty> a2;
        bool operator==(const TyFn&) const;
    };

    struct TyTuple {
        Array<Ty> a0;
        bool operator==(const TyTuple&) const;
    };

    struct TyArray {
        prism_rtl::Rc<const Ty> a0;
        bool operator==(const TyArray&) const;
    };

    struct TyMap {
        prism_rtl::Rc<const Ty> a0;
        prism_rtl::Rc<const Ty> a1;
        bool operator==(const TyMap&) const;
    };

    struct TySig {
        Text a0;
        prism_rtl::Rc<const Ty> a1;
        bool operator==(const TySig&) const;
    };

    struct TyAt {
        prism_rtl::Rc<const Ty> a0;
        Rw a1;
        bool operator==(const TyAt&) const;
    };

    struct TyElem {
        Rw a0;
        prism_rtl::Rc<const Ty> a1;
        bool operator==(const TyElem&) const;
    };

    struct TyElemAny {
        Rw a0;
        bool operator==(const TyElemAny&) const = default;
    };

    struct TyAssoc {
        Text a0;
        prism_rtl::Rc<const Ty> a1;
        bool operator==(const TyAssoc&) const;
    };

    struct TyAny {
        Array<Text> a0;
        bool operator==(const TyAny&) const = default;
    };

    struct TyErr {
        bool operator==(const TyErr&) const = default;
    };
    using Cases = std::variant<TyFlex, TyRigid, TyQ, TyCon, TyFn, TyTuple, TyArray, TyMap, TySig, TyAt, TyElem, TyElemAny, TyAssoc, TyAny, TyErr>;
    template <class C>
        requires prism_rtl::one_of<C, TyFlex, TyRigid, TyQ, TyCon, TyFn, TyTuple, TyArray, TyMap, TySig, TyAt, TyElem, TyElemAny, TyAssoc, TyAny, TyErr>
    Ty(C c) : cases_(std::move(c)) {}
    const Cases& cases() const { return cases_; }
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Ty> from_pod(const Pod& whole);

private:
    Cases cases_;
};

inline bool operator==(const Ty& a, const Ty& b) { return a.cases() == b.cases(); }

}  // namespace check::types

namespace check::typed {

/// `BinderNote`:
///
/// ```prism
/// type BinderNote = record:
/// ```
struct BinderNote {
    using prism_value = void;
    SrcAt at_p;
    Text name_p;
    crate::check::types::Ty ty_p;
    const BinderNote* operator->() const { return this; }
    BinderNote* operator->() { return this; }
    bool operator==(const BinderNote&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<BinderNote> from_pod(const Pod& whole);
};


}  // namespace check::typed

namespace check::typed {

/// `ImplNote`:
///
/// ```prism
/// type ImplNote = record:
/// ```
struct ImplNote {
    using prism_value = void;
    SrcAt at_p;
    Text cls_p;
    crate::check::types::Ty ty_p;
    Text how_p;
    const ImplNote* operator->() const { return this; }
    ImplNote* operator->() { return this; }
    bool operator==(const ImplNote&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<ImplNote> from_pod(const Pod& whole);
};


}  // namespace check::typed

namespace check::typed {

/// `TyNote`:
///
/// ```prism
/// type TyNote = record:
/// ```
struct TyNote {
    using prism_value = void;
    SrcAt at_p;
    crate::check::types::Ty ty_p;
    const TyNote* operator->() const { return this; }
    TyNote* operator->() { return this; }
    bool operator==(const TyNote&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<TyNote> from_pod(const Pod& whole);
};


}  // namespace check::typed

namespace check::types {

/// `Scheme`:
///
/// ```prism
/// type Scheme = record:
/// ```
struct Scheme {
    using prism_value = void;
    Array<Text> qs_p;
    Array<Text> plain_qs_p;
    Array<Text> rqs_p;
    Array<Text> cqs_p;
    Array<std::tuple<Text, Text>> cjoins_p;
    Array<std::tuple<Text, Text>> bounds_p;
    Ty ty_p;
    const Scheme* operator->() const { return this; }
    Scheme* operator->() { return this; }
    bool operator==(const Scheme&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Scheme> from_pod(const Pod& whole);
};


}  // namespace check::types

namespace check::types {

/// `Want`:
///
/// ```prism
/// type Want = record:
/// ```
struct Want {
    using prism_value = void;
    Text cls_p;
    Ty ty_p;
    Nat file_p;
    crate::syntax::Range span_p;
    Nat level_p;
    const Want* operator->() const { return this; }
    Want* operator->() { return this; }
    bool operator==(const Want&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Want> from_pod(const Pod& whole);
};


}  // namespace check::types

namespace check::typed {

/// `DefNote`:
///
/// ```prism
/// type DefNote = record:
/// ```
struct DefNote {
    using prism_value = void;
    SrcAt at_p;
    Text name_p;
    crate::check::types::Scheme scheme_p;
    const DefNote* operator->() const { return this; }
    DefNote* operator->() { return this; }
    bool operator==(const DefNote&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<DefNote> from_pod(const Pod& whole);
};


}  // namespace check::typed

}  // namespace crate
