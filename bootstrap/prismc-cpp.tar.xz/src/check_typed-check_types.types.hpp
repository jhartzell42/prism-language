// The modules `check::typed`, `check::types`: its records, tags and newtypes (each after the types it holds) and its
// choices' cases, emitted by prismc (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <check/typed/decl.hpp>
#include <check/types/decl.hpp>
#include "elem.decl.hpp"
#include <program/decl.hpp>
#include <check/decl.hpp>
#include <check/blocks/decl.hpp>
#include <check/blocks/borrows/decl.hpp>
#include <check/blocks/structure/decl.hpp>
#include <check/env/decl.hpp>
#include <check/env/decls/decl.hpp>
#include <check/env/names/decl.hpp>
#include <check/env/reading/decl.hpp>
#include <check/env/traits/decl.hpp>
#include <check/errors/decl.hpp>
#include <check/expr/decl.hpp>
#include <check/expr/calls/decl.hpp>
#include <check/expr/lets/decl.hpp>
#include <check/expr/lifting/decl.hpp>
#include <check/expr/operators/decl.hpp>
#include <check/expr/patterns/decl.hpp>
#include <check/passes/decl.hpp>
#include <check/passes/borrows/decl.hpp>
#include <check/passes/cycles/decl.hpp>
#include <check/shrink/decl.hpp>
#include <check/shrink/calls/decl.hpp>
#include <check/shrink/locals/decl.hpp>
#include <check/shrink/relations/decl.hpp>
#include <check/shrink/summaries/decl.hpp>
#include <check/shrink/types/decl.hpp>
#include <check/shrink/walk/decl.hpp>
#include <check/typed/print/decl.hpp>
#include <check/types/colors/decl.hpp>
#include <check/types/recording/decl.hpp>
#include <check/types/schemes/decl.hpp>
#include <check/types/unify/decl.hpp>
#include <checking/decl.hpp>
#include <compile/decl.hpp>
#include <emit/decl.hpp>
#include <emit/cpp/decl.hpp>
#include <emit/cpp/expr/decl.hpp>
#include <emit/cpp/items/decl.hpp>
#include <emit/cpp/patterns/decl.hpp>
#include <emit/cpp/prelude/decl.hpp>
#include <emit/cpp/program/decl.hpp>
#include <emit/cpp/stmts/decl.hpp>
#include <emit/cpp/templates/decl.hpp>
#include <emit/cpp/templates/items/decl.hpp>
#include <emit/rust/decl.hpp>
#include <emit/rust/items/decl.hpp>
#include <emit/rust/prelude/decl.hpp>
#include <emit/rust/templates/decl.hpp>
#include <emit/rust/templates/items/decl.hpp>
#include <fs/decl.hpp>
#include <lower/decl.hpp>
#include <lower/expr/decl.hpp>
#include <lower/functions/decl.hpp>
#include <lower/jobs/decl.hpp>
#include <lower/model/decl.hpp>
#include <lower/node_/decl.hpp>
#include <lower/node_/def/decl.hpp>
#include <lower/node_/dynamics/decl.hpp>
#include <lower/node_/elements/decl.hpp>
#include <lower/node_/finish/decl.hpp>
#include <lower/node_/keyed/decl.hpp>
#include <lower/node_/static_/decl.hpp>
#include <lower/node_/switch_/decl.hpp>
#include <lower/patterns/decl.hpp>
#include <lower/program/decl.hpp>
#include <lower/templates/decl.hpp>
#include <lower/types/decl.hpp>
#include <process/decl.hpp>
#include <reading/decl.hpp>
#include <syntax/decls/decl.hpp>
#include <syntax/lexer/decl.hpp>
#include <syntax/lexer/chars/decl.hpp>
#include <syntax/lexer/corpus/decl.hpp>
#include <syntax/lexer/layout/decl.hpp>
#include <syntax/lexer/literals/decl.hpp>
#include <syntax/lexer/templates/decl.hpp>
#include <syntax/lexer/words/decl.hpp>
#include <syntax/parser/decl.hpp>
#include <syntax/parser/blocks/decl.hpp>
#include <syntax/parser/decls/decl.hpp>
#include <syntax/parser/expr/decl.hpp>
#include <syntax/parser/test_language/decl.hpp>
#include <syntax/parser/types/decl.hpp>
#include <syntax/sexp/decl.hpp>
#include <syntax/types.hpp>

namespace crate {

using namespace prelude;

namespace check::typed {

/// `SrcAt`:
///
/// ```prism
/// type SrcAt = record:
/// ```
struct SrcAt {
    using prism_value = void;
    Nat file;
    crate::syntax::Range span;
    const SrcAt* operator->() const { return this; }
    SrcAt* operator->() { return this; }
    bool operator==(const SrcAt&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<SrcAt> from_pod(const Pod& whole);
};


}  // namespace check::typed

namespace check::typed {

/// `TProgram`:
///
/// ```prism
/// type TProgram = record:
/// ```
struct TProgram {
    using prism_value = void;
    Array<TyNote> exprs;
    Array<AppNote> apps;
    Array<FnNote> fns;
    Array<ImplNote> impls;
    Array<MethodNote> methods;
    Array<GroupNote> groups;
    Array<BinderNote> binders;
    Array<GenNote> gens;
    Array<InstNote> insts;
    Array<DefNote> defs;
    Array<SrcAt> unshrunk;
    const TProgram* operator->() const { return this; }
    TProgram* operator->() { return this; }
    bool operator==(const TProgram&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<TProgram> from_pod(const Pod& whole);
};


}  // namespace check::typed

namespace check::types {

/// `CLeq`:
///
/// ```prism
/// type CLeq = record:
/// ```
struct CLeq {
    using prism_value = void;
    Col lo;
    Col hi;
    Nat file;
    crate::syntax::Range span;
    Text kind;
    Text name;
    Text why;
    const CLeq* operator->() const { return this; }
    CLeq* operator->() { return this; }
    bool operator==(const CLeq&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<CLeq> from_pod(const Pod& whole);
};


}  // namespace check::types

namespace check::types {

/// `Rw`:
///
/// ```prism
/// type Rw = record:
/// ```
struct Rw {
    using prism_value = void;
    Array<Text> fams;
    Array<Text> minus;
    Tail tail;
    const Rw* operator->() const { return this; }
    Rw* operator->() { return this; }
    bool operator==(const Rw&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Rw> from_pod(const Pod& whole);
};


}  // namespace check::types

namespace check::types {

/// `Scheme`:
///
/// ```prism
/// type Scheme = record:
/// ```
struct Scheme {
    using prism_value = void;
    Array<Text> qs;
    Array<Text> plain_qs;
    Array<Text> rqs;
    Array<Text> cqs;
    Array<std::tuple<Text, Text>> cjoins;
    Array<std::tuple<Text, Text>> bounds;
    Ty ty;
    const Scheme* operator->() const { return this; }
    Scheme* operator->() { return this; }
    bool operator==(const Scheme&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Scheme> from_pod(const Pod& whole);
};


}  // namespace check::types

namespace check::types {

/// `VInfo`:
///
/// ```prism
/// type VInfo = record:
/// ```
struct VInfo {
    using prism_value = void;
    bool plain;
    Nat level;
    Text name;
    const VInfo* operator->() const { return this; }
    VInfo* operator->() { return this; }
    bool operator==(const VInfo&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<VInfo> from_pod(const Pod& whole);
};


}  // namespace check::types

namespace check::types {

/// `Want`:
///
/// ```prism
/// type Want = record:
/// ```
struct Want {
    using prism_value = void;
    Text cls;
    Ty ty;
    Nat file;
    crate::syntax::Range span;
    Nat level;
    const Want* operator->() const { return this; }
    Want* operator->() { return this; }
    bool operator==(const Want&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Want> from_pod(const Pod& whole);
};


}  // namespace check::types

namespace check::typed {

/// `AppNote`:
///
/// ```prism
/// type AppNote = record:
/// ```
struct AppNote {
    using prism_value = void;
    SrcAt at;
    Text callee;
    Text kind;
    Text layer;
    Array<Nat> lifted;
    Text inner;
    crate::check::types::Col color;
    const AppNote* operator->() const { return this; }
    AppNote* operator->() { return this; }
    bool operator==(const AppNote&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<AppNote> from_pod(const Pod& whole);
};


}  // namespace check::typed

namespace check::typed {

/// `BinderNote`:
///
/// ```prism
/// type BinderNote = record:
/// ```
struct BinderNote {
    using prism_value = void;
    SrcAt at;
    Text name;
    crate::check::types::Ty ty;
    const BinderNote* operator->() const { return this; }
    BinderNote* operator->() { return this; }
    bool operator==(const BinderNote&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<BinderNote> from_pod(const Pod& whole);
};


}  // namespace check::typed

namespace check::typed {

/// `DefNote`:
///
/// ```prism
/// type DefNote = record:
/// ```
struct DefNote {
    using prism_value = void;
    SrcAt at;
    Text name;
    crate::check::types::Scheme scheme;
    const DefNote* operator->() const { return this; }
    DefNote* operator->() { return this; }
    bool operator==(const DefNote&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<DefNote> from_pod(const Pod& whole);
};


}  // namespace check::typed

namespace check::typed {

/// `FnNote`:
///
/// ```prism
/// type FnNote = record:
/// ```
struct FnNote {
    using prism_value = void;
    SrcAt at;
    Text name;
    crate::check::types::Col declared;
    crate::check::types::Col body;
    const FnNote* operator->() const { return this; }
    FnNote* operator->() { return this; }
    bool operator==(const FnNote&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<FnNote> from_pod(const Pod& whole);
};


}  // namespace check::typed

namespace check::typed {

/// `GenNote`:
///
/// ```prism
/// type GenNote = record:
/// ```
struct GenNote {
    using prism_value = void;
    SrcAt at;
    Text name;
    Array<Text> tys;
    Array<Text> cols;
    const GenNote* operator->() const { return this; }
    GenNote* operator->() { return this; }
    bool operator==(const GenNote&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<GenNote> from_pod(const Pod& whole);
};


}  // namespace check::typed

namespace check::typed {

/// `GroupNote`:
///
/// ```prism
/// type GroupNote = record:
/// ```
struct GroupNote {
    using prism_value = void;
    SrcAt at;
    Text kind;
    Array<Array<Nat>> order;
    const GroupNote* operator->() const { return this; }
    GroupNote* operator->() { return this; }
    bool operator==(const GroupNote&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<GroupNote> from_pod(const Pod& whole);
};


}  // namespace check::typed

namespace check::typed {

/// `ImplNote`:
///
/// ```prism
/// type ImplNote = record:
/// ```
struct ImplNote {
    using prism_value = void;
    SrcAt at;
    Text cls;
    crate::check::types::Ty ty;
    Text how;
    const ImplNote* operator->() const { return this; }
    ImplNote* operator->() { return this; }
    bool operator==(const ImplNote&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<ImplNote> from_pod(const Pod& whole);
};


}  // namespace check::typed

namespace check::typed {

/// `InstNote`:
///
/// ```prism
/// type InstNote = record:
/// ```
struct InstNote {
    using prism_value = void;
    SrcAt at;
    Text name;
    Array<std::tuple<Text, crate::check::types::Ty>> tys;
    Array<std::tuple<Text, crate::check::types::Col>> cols;
    const InstNote* operator->() const { return this; }
    InstNote* operator->() { return this; }
    bool operator==(const InstNote&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<InstNote> from_pod(const Pod& whole);
};


}  // namespace check::typed

namespace check::typed {

/// `MethodNote`:
///
/// ```prism
/// type MethodNote = record:
/// ```
struct MethodNote {
    using prism_value = void;
    SrcAt at;
    Text method;
    Text cls;
    const MethodNote* operator->() const { return this; }
    MethodNote* operator->() { return this; }
    bool operator==(const MethodNote&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<MethodNote> from_pod(const Pod& whole);
};


}  // namespace check::typed

namespace check::typed {

/// `TyNote`:
///
/// ```prism
/// type TyNote = record:
/// ```
struct TyNote {
    using prism_value = void;
    SrcAt at;
    crate::check::types::Ty ty;
    const TyNote* operator->() const { return this; }
    TyNote* operator->() { return this; }
    bool operator==(const TyNote&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<TyNote> from_pod(const Pod& whole);
};


}  // namespace check::typed

namespace check::types {

/// `Incl`:
///
/// ```prism
/// type Incl = record:
/// ```
struct Incl {
    using prism_value = void;
    Rw sub;
    Rw sup;
    Nat file;
    crate::syntax::Range span;
    Text what;
    bool forward;
    const Incl* operator->() const { return this; }
    Incl* operator->() { return this; }
    bool operator==(const Incl&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Incl> from_pod(const Pod& whole);
};


}  // namespace check::types

namespace check::types {

/// `St`:
///
/// ```prism
/// type St = record:
/// ```
struct St {
    using prism_value = void;
    Nat next;
    Map<Nat, Ty> tys;
    Map<Nat, VInfo> infos;
    Map<Nat, Rw> rows;
    Map<Nat, Array<Text>> lacks;
    Array<Want> wants;
    Array<Incl> incls;
    Array<crate::check::errors::CDiag> diags;
    Nat level;
    Nat file;
    Col color;
    Text color_why;
    Array<std::tuple<Col, Text, crate::syntax::Range>> color_flex;
    Map<Nat, Col> cols;
    Array<CLeq> cleqs;
    Map<Nat, Text> col_q;
    Map<Text, Text> col_up;
    Array<std::tuple<Ty, Ty, crate::syntax::Range>> deferred;
    Map<Nat, crate::syntax::Range> binder_at;
    Map<Nat, Text> row_names;
    Array<std::tuple<Ty, crate::syntax::Range, Text>> layer_qs;
    Array<crate::check::types::unify::FieldQ> field_qs;
    bool recording;
    crate::check::typed::TProgram typed;
    Map<Text, Array<Text>> choices;
    Map<Text, Ty> size_tys;
    const St* operator->() const { return this; }
    St* operator->() { return this; }
    bool operator==(const St&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<St> from_pod(const Pod& whole);
};


}  // namespace check::types

namespace check::types {

struct Col::CBound {
    bool operator==(const CBound&) const = default;
};


struct Col::CUnbound {
    bool operator==(const CUnbound&) const = default;
};


struct Col::CRigid {
    Text a0;
    bool operator==(const CRigid&) const = default;
};


struct Col::CQ {
    Text a0;
    bool operator==(const CQ&) const = default;
};


struct Col::CFlex {
    Nat a0;
    bool operator==(const CFlex&) const = default;
};


inline const Col::Cases& Col::cases() const { return *cases_; }

inline bool operator==(const Col& a, const Col& b) { return a.cases() == b.cases(); }

struct Tail::TlClosed {
    bool operator==(const TlClosed&) const = default;
};


struct Tail::TlFlex {
    Nat a0;
    bool operator==(const TlFlex&) const = default;
};


struct Tail::TlRigid {
    Text a0;
    bool operator==(const TlRigid&) const = default;
};


struct Tail::TlQ {
    Text a0;
    bool operator==(const TlQ&) const = default;
};


inline const Tail::Cases& Tail::cases() const { return *cases_; }

inline bool operator==(const Tail& a, const Tail& b) { return a.cases() == b.cases(); }

struct Ty::TyFlex {
    Nat a0;
    bool operator==(const TyFlex&) const = default;
};


struct Ty::TyRigid {
    Text a0;
    bool operator==(const TyRigid&) const = default;
};


struct Ty::TyQ {
    Text a0;
    bool operator==(const TyQ&) const = default;
};


struct Ty::TyCon {
    Text a0;
    Array<Ty> a1;
    bool operator==(const TyCon&) const = default;
};


struct Ty::TyFn {
    Col a0;
    Array<Ty> a1;
    Ty a2;
    bool operator==(const TyFn&) const = default;
};


struct Ty::TyTuple {
    Array<Ty> a0;
    bool operator==(const TyTuple&) const = default;
};


struct Ty::TyArray {
    Ty a0;
    bool operator==(const TyArray&) const = default;
};


struct Ty::TyMap {
    Ty a0;
    Ty a1;
    bool operator==(const TyMap&) const = default;
};


struct Ty::TySig {
    Text a0;
    Ty a1;
    bool operator==(const TySig&) const = default;
};


struct Ty::TyAt {
    Ty a0;
    Rw a1;
    bool operator==(const TyAt&) const = default;
};


struct Ty::TyElem {
    Rw a0;
    Ty a1;
    bool operator==(const TyElem&) const = default;
};


struct Ty::TyElemAny {
    Rw a0;
    bool operator==(const TyElemAny&) const = default;
};


struct Ty::TyAssoc {
    Text a0;
    Ty a1;
    bool operator==(const TyAssoc&) const = default;
};


struct Ty::TyAny {
    Array<Text> a0;
    bool operator==(const TyAny&) const = default;
};


struct Ty::TyErr {
    bool operator==(const TyErr&) const = default;
};


inline const Ty::Cases& Ty::cases() const { return *cases_; }

inline bool operator==(const Ty& a, const Ty& b) { return a.cases() == b.cases(); }

}  // namespace check::types

}  // namespace crate
