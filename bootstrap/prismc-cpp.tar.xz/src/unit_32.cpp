// The modules `Emit.Cpp.Patterns`, `Emit.Cpp.Prelude`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <emit/cpp/patterns/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Emit.Cpp.Patterns`, from `target/bootstrap/cpp-src/prismc/emit/cpp/patterns.prism`.
namespace crate::emit::cpp::patterns {

/// PatConds: unbounded fn Cp, Pa, Text -> [Text]
Array<Text> pat_conds(const crate::emit::cpp::Cp& cp, const crate::lower::model::Pa& p_, const Text& v_) {
    if (prism_rtl::is<crate::lower::model::Pa::PaWild>(p_)) {
        return Array<Text>{};
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaBind>(p_)) {
        return Array<Text>{};
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaMut>(p_)) {
        return Array<Text>{};
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaTyped>(p_)) {
        auto&& q = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_).a0;
        return pat_conds(cp, q, v_);
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaUnit>(p_)) {
        auto&& c = prism_rtl::as<crate::lower::model::Pa::PaUnit>(p_).a0;
        return Array(std::vector{crate::emit::cpp::expr::case_test(cp, c, v_)});
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaCtor>(p_)) {
        auto&& c = prism_rtl::as<crate::lower::model::Pa::PaCtor>(p_).a0;
        auto&& ps = prism_rtl::as<crate::lower::model::Pa::PaCtor>(p_).a1;
        auto own = crate::emit::cpp::expr::case_test(cp, c, v_);
        auto inner = concat2(run_to_end(each_job(crate::check::errors::range0(len(ps)), ({
            auto cp_1 = cp;
            auto ps_2 = ps;
            auto c_3 = c;
            auto v__4 = v_;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
            return ({
                auto cp_1_5 = cp_1;
                auto ps_2_5 = ps_2;
                auto c_3_5 = c_3;
                auto v__4_5 = v__4;
                entered(once_job([=]() {
                return ({
                    auto i = p0;
                    (prism_rtl::more(prism_rtl::rc(PatConds(cp_1_5, or_(index(ps_2_5, i), crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})), crate::emit::cpp::expr::payload(cp_1_5, c_3_5, v__4_5, i)))));
                });
            }));
            });
        })));
        }))));
        return filter(append(Array(std::vector{own}), inner), [&](const Text& t) { return t != Text::lit("true"); });
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaRecord>(p_)) {
        auto&& c = prism_rtl::as<crate::lower::model::Pa::PaRecord>(p_).a0;
        auto&& fs = prism_rtl::as<crate::lower::model::Pa::PaRecord>(p_).a1;
        return concat2(run_to_end(each_job(fs, ({
            auto cp_1 = cp;
            auto v__2 = v_;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Text, crate::lower::model::Pa>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::Pa> p0) {
            return ({
                auto cp_1_3 = cp_1;
                auto v__2_3 = v__2;
                entered(once_job([=]() {
                return ({
                    auto [f, q] = p0;
                    (prism_rtl::more(prism_rtl::rc(PatConds(cp_1_3, q, prism_rtl::cat(v__2_3, ".", crate::emit::cpp::field_id(f))))));
                });
            }));
            });
        })));
        }))));
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaTuple>(p_)) {
        auto&& ps = prism_rtl::as<crate::lower::model::Pa::PaTuple>(p_).a0;
        return concat2(run_to_end(each_job(crate::check::errors::range0(len(ps)), ({
            auto cp_1 = cp;
            auto ps_2 = ps;
            auto v__3 = v_;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
            return ({
                auto cp_1_4 = cp_1;
                auto ps_2_4 = ps_2;
                auto v__3_4 = v__3;
                entered(once_job([=]() {
                return ({
                    auto i = p0;
                    (prism_rtl::more(prism_rtl::rc(PatConds(cp_1_4, or_(index(ps_2_4, i), crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})), prism_rtl::cat("std::get<", i, ">(", v__3_4, ")")))));
                });
            }));
            });
        })));
        }))));
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaChar>(p_)) {
        auto&& c = prism_rtl::as<crate::lower::model::Pa::PaChar>(p_).a0;
        return Array(std::vector{prism_rtl::cat(v_, " == U\'", crate::emit::cpp::expr::cpp_char_escape(c), "\'")});
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaBool>(p_)) {
        auto&& b = prism_rtl::as<crate::lower::model::Pa::PaBool>(p_).a0;
        return Array(std::vector{b ? v_ : prism_rtl::cat("!", v_)});
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaIndex>(p_)) {
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaIndex>(p_).a0;
        return Array(std::vector{prism_rtl::cat(v_, " == ", n, "u")});
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaConst>(p_)) {
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaConst>(p_).a0;
        return Array(std::vector{prism_rtl::cat(v_, " == ", n)});
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaSlice>(p_)) {
        auto&& ps = prism_rtl::as<crate::lower::model::Pa::PaSlice>(p_).a0;
        auto rest = fold(ps, false, [&](const bool& f, const crate::lower::model::Pa& q) { return f || is_rest(q); });
        auto fixed = len(filter(ps, [&](const crate::lower::model::Pa& q) { return !is_rest(q); }));
        auto size_ = rest
            ? prism_rtl::cat(v_, ".size() >= ", fixed)
            : prism_rtl::cat(v_, ".size() == ", fixed);
        return append(Array(std::vector{size_}), concat2(run_to_end(each_job(crate::check::errors::range0(len(ps)), ({
            auto cp_1 = cp;
            auto ps_2 = ps;
            auto v__3 = v_;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
            return ({
                auto cp_1_4 = cp_1;
                auto ps_2_4 = ps_2;
                auto v__3_4 = v__3;
                entered(once_job([=]() {
                return ({
                    auto i = p0;
                    (prism_rtl::more(prism_rtl::rc(PatConds(cp_1_4, or_(index(ps_2_4, i), crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})), prism_rtl::cat(v__3_4, "[", i, "]")))));
                });
            }));
            });
        })));
        })))));
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaRest>(p_)) {
        return Array<Text>{};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Text>> PatConds::cycle() const {
    const auto& cp = this->cp;
    const auto& p_ = this->p_;
    const auto& v_ = this->v_;
    return ({
        prism_rtl::is<crate::lower::model::Pa::PaWild>(p_) ? prism_rtl::finished(Array<Text>{})
        : prism_rtl::is<crate::lower::model::Pa::PaBind>(p_) ? prism_rtl::finished(Array<Text>{})
        : prism_rtl::is<crate::lower::model::Pa::PaMut>(p_) ? prism_rtl::finished(Array<Text>{})
        : prism_rtl::is<crate::lower::model::Pa::PaTyped>(p_) ? ({
        auto&& q = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_).a0;
        prism_rtl::more(prism_rtl::rc(PatConds(cp, q, v_)));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaUnit>(p_) ? ({
        auto&& c = prism_rtl::as<crate::lower::model::Pa::PaUnit>(p_).a0;
        prism_rtl::finished(Array(std::vector{crate::emit::cpp::expr::case_test(cp, c, v_)}));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaCtor>(p_) ? ({
        auto&& c = prism_rtl::as<crate::lower::model::Pa::PaCtor>(p_).a0;
        auto&& ps = prism_rtl::as<crate::lower::model::Pa::PaCtor>(p_).a1;
        ({
        auto own = crate::emit::cpp::expr::case_test(cp, c, v_);
        auto c_1 = c;
        auto cp_2 = cp;
        auto ps_3 = ps;
        auto v__4 = v_;
        call_value(each_job(crate::check::errors::range0(len(ps_3)), ({
        auto cp_2_5 = cp_2;
        auto ps_3_5 = ps_3;
        auto c_1_5 = c_1;
        auto v__4_5 = v__4;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto cp_2_5_5 = cp_2_5;
            auto ps_3_5_5 = ps_3_5;
            auto c_1_5_5 = c_1_5;
            auto v__4_5_5 = v__4_5;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                (prism_rtl::more(prism_rtl::rc(PatConds(cp_2_5_5, or_(index(ps_3_5_5, i), crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})), crate::emit::cpp::expr::payload(cp_2_5_5, c_1_5_5, v__4_5_5, i)))));
            });
        }));
        });
    })));
    })), [=](Array<Array<Text>> each_1488) {
        return ({
            auto inner = concat2(each_1488);
            (prism_rtl::finished(filter(append(Array(std::vector{own}), inner), [&](const Text& t) { return t != Text::lit("true"); })));
        });
    });
    });
    })
        : prism_rtl::is<crate::lower::model::Pa::PaRecord>(p_) ? ({
        auto&& c = prism_rtl::as<crate::lower::model::Pa::PaRecord>(p_).a0;
        auto&& fs = prism_rtl::as<crate::lower::model::Pa::PaRecord>(p_).a1;
        ({
        auto cp_1 = cp;
        auto fs_2 = fs;
        auto v__3 = v_;
        call_value(each_job(fs_2, ({
        auto cp_1_4 = cp_1;
        auto v__3_4 = v__3;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Text, crate::lower::model::Pa>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::Pa> p0) {
        return ({
            auto cp_1_4_4 = cp_1_4;
            auto v__3_4_4 = v__3_4;
            entered(once_job([=]() {
            return ({
                auto [f, q] = p0;
                (prism_rtl::more(prism_rtl::rc(PatConds(cp_1_4_4, q, prism_rtl::cat(v__3_4_4, ".", crate::emit::cpp::field_id(f))))));
            });
        }));
        });
    })));
    })), [=](Array<Array<Text>> each_1667) { return prism_rtl::finished(concat2(each_1667)); });
    });
    })
        : prism_rtl::is<crate::lower::model::Pa::PaTuple>(p_) ? ({
        auto&& ps = prism_rtl::as<crate::lower::model::Pa::PaTuple>(p_).a0;
        ({
        auto cp_1 = cp;
        auto ps_2 = ps;
        auto v__3 = v_;
        call_value(each_job(crate::check::errors::range0(len(ps_2)), ({
        auto cp_1_4 = cp_1;
        auto ps_2_4 = ps_2;
        auto v__3_4 = v__3;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto cp_1_4_4 = cp_1_4;
            auto ps_2_4_4 = ps_2_4;
            auto v__3_4_4 = v__3_4;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                (prism_rtl::more(prism_rtl::rc(PatConds(cp_1_4_4, or_(index(ps_2_4_4, i), crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})), prism_rtl::cat("std::get<", i, ">(", v__3_4_4, ")")))));
            });
        }));
        });
    })));
    })), [=](Array<Array<Text>> each_1748) { return prism_rtl::finished(concat2(each_1748)); });
    });
    })
        : prism_rtl::is<crate::lower::model::Pa::PaChar>(p_) ? ({
        auto&& c = prism_rtl::as<crate::lower::model::Pa::PaChar>(p_).a0;
        prism_rtl::finished(Array(std::vector{prism_rtl::cat(v_, " == U\'", crate::emit::cpp::expr::cpp_char_escape(c), "\'")}));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaBool>(p_) ? ({
        auto&& b = prism_rtl::as<crate::lower::model::Pa::PaBool>(p_).a0;
        prism_rtl::finished(Array(std::vector{b ? v_ : prism_rtl::cat("!", v_)}));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaIndex>(p_) ? ({
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaIndex>(p_).a0;
        prism_rtl::finished(Array(std::vector{prism_rtl::cat(v_, " == ", n, "u")}));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaConst>(p_) ? ({
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaConst>(p_).a0;
        prism_rtl::finished(Array(std::vector{prism_rtl::cat(v_, " == ", n)}));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaSlice>(p_) ? ({
        auto&& ps = prism_rtl::as<crate::lower::model::Pa::PaSlice>(p_).a0;
        ({
        auto rest = fold(ps, false, [&](const bool& f, const crate::lower::model::Pa& q) { return f || is_rest(q); });
        auto fixed = len(filter(ps, [&](const crate::lower::model::Pa& q) { return !is_rest(q); }));
        auto size_ = rest
            ? prism_rtl::cat(v_, ".size() >= ", fixed)
            : prism_rtl::cat(v_, ".size() == ", fixed);
        auto cp_1 = cp;
        auto ps_2 = ps;
        auto v__3 = v_;
        call_value(each_job(crate::check::errors::range0(len(ps_2)), ({
        auto cp_1_4 = cp_1;
        auto ps_2_4 = ps_2;
        auto v__3_4 = v__3;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto cp_1_4_4 = cp_1_4;
            auto ps_2_4_4 = ps_2_4;
            auto v__3_4_4 = v__3_4;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                (prism_rtl::more(prism_rtl::rc(PatConds(cp_1_4_4, or_(index(ps_2_4_4, i), crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})), prism_rtl::cat(v__3_4_4, "[", i, "]")))));
            });
        }));
        });
    })));
    })), [=](Array<Array<Text>> each_2231) { return prism_rtl::finished(append(Array(std::vector{size_}), concat2(each_2231))); });
    });
    })
        : prism_rtl::is<crate::lower::model::Pa::PaRest>(p_) ? prism_rtl::finished(Array<Text>{})
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start PatConds, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_pat_conds(crate::emit::cpp::Cp cp, crate::lower::model::Pa p_, Text v_) {
    return prism_rtl::make_rc<PatConds>(cp, p_, v_);
}


/// PatBinds: unbounded fn Cp, Pa, Text -> [Text]
Array<Text> pat_binds(const crate::emit::cpp::Cp& cp, const crate::lower::model::Pa& p_, const Text& v_) {
    if (prism_rtl::is<crate::lower::model::Pa::PaWild>(p_)) {
        return Array<Text>{};
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaBind>(p_)) {
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaBind>(p_).a0;
        return Array(std::vector{prism_rtl::cat("auto&& ", crate::emit::cpp::cpp_id(n), " = ", v_, ";")});
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaMut>(p_)) {
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaMut>(p_).a0;
        return Array(std::vector{prism_rtl::cat("auto ", crate::emit::cpp::cpp_id(n), " = ", v_, ";")});
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaTyped>(p_)) {
        auto&& m2400_3_0 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_).a0;
        auto&& t = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_).a1;
        if (prism_rtl::is<crate::lower::model::Pa::PaBind>(m2400_3_0)) {
            auto&& n = prism_rtl::as<crate::lower::model::Pa::PaBind>(m2400_3_0).a0;
            return Array(std::vector{prism_rtl::cat(crate::emit::cpp::cpp_type(cp, crate::emit::cpp::expr::unref(t)), " ", crate::emit::cpp::cpp_id(n), " = ", v_, ";")});
        }
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaTyped>(p_)) {
        auto&& q = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_).a0;
        return pat_binds(cp, q, v_);
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaUnit>(p_)) {
        return Array<Text>{};
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaCtor>(p_)) {
        auto&& c = prism_rtl::as<crate::lower::model::Pa::PaCtor>(p_).a0;
        auto&& ps = prism_rtl::as<crate::lower::model::Pa::PaCtor>(p_).a1;
        return concat2(run_to_end(each_job(crate::check::errors::range0(len(ps)), ({
            auto cp_1 = cp;
            auto ps_2 = ps;
            auto c_3 = c;
            auto v__4 = v_;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
            return ({
                auto cp_1_5 = cp_1;
                auto ps_2_5 = ps_2;
                auto c_3_5 = c_3;
                auto v__4_5 = v__4;
                entered(once_job([=]() {
                return ({
                    auto i = p0;
                    (prism_rtl::more(prism_rtl::rc(PatBinds(cp_1_5, or_(index(ps_2_5, i), crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})), crate::emit::cpp::expr::payload(cp_1_5, c_3_5, v__4_5, i)))));
                });
            }));
            });
        })));
        }))));
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaRecord>(p_)) {
        auto&& c = prism_rtl::as<crate::lower::model::Pa::PaRecord>(p_).a0;
        auto&& fs = prism_rtl::as<crate::lower::model::Pa::PaRecord>(p_).a1;
        return concat2(run_to_end(each_job(fs, ({
            auto cp_1 = cp;
            auto v__2 = v_;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Text, crate::lower::model::Pa>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::Pa> p0) {
            return ({
                auto cp_1_3 = cp_1;
                auto v__2_3 = v__2;
                entered(once_job([=]() {
                return ({
                    auto [f, q] = p0;
                    (prism_rtl::more(prism_rtl::rc(PatBinds(cp_1_3, q, prism_rtl::cat(v__2_3, ".", crate::emit::cpp::field_id(f))))));
                });
            }));
            });
        })));
        }))));
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaTuple>(p_)) {
        auto&& ps = prism_rtl::as<crate::lower::model::Pa::PaTuple>(p_).a0;
        return concat2(run_to_end(each_job(crate::check::errors::range0(len(ps)), ({
            auto cp_1 = cp;
            auto ps_2 = ps;
            auto v__3 = v_;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
            return ({
                auto cp_1_4 = cp_1;
                auto ps_2_4 = ps_2;
                auto v__3_4 = v__3;
                entered(once_job([=]() {
                return ({
                    auto i = p0;
                    (prism_rtl::more(prism_rtl::rc(PatBinds(cp_1_4, or_(index(ps_2_4, i), crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})), prism_rtl::cat("std::get<", i, ">(", v__3_4, ")")))));
                });
            }));
            });
        })));
        }))));
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaSlice>(p_)) {
        auto&& ps = prism_rtl::as<crate::lower::model::Pa::PaSlice>(p_).a0;
        return concat2(run_to_end(each_job(crate::check::errors::range0(len(ps)), ({
            auto cp_1 = cp;
            auto ps_2 = ps;
            auto v__3 = v_;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
            return ({
                auto cp_1_4 = cp_1;
                auto ps_2_4 = ps_2;
                auto v__3_4 = v__3;
                entered(once_job([=]() {
                return ({
                    auto i = p0;
                    (prism_rtl::more(prism_rtl::rc(SliceBinds(cp_1_4, or_(index(ps_2_4, i), crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})), v__3_4, i))));
                });
            }));
            });
        })));
        }))));
    }
    {
        return Array<Text>{};
    }
}


prism_rtl::Turn<Array<Text>> PatBinds::cycle() const {
    const auto& cp = this->cp;
    const auto& p_ = this->p_;
    const auto& v_ = this->v_;
    return ({
        prism_rtl::is<crate::lower::model::Pa::PaWild>(p_) ? prism_rtl::finished(Array<Text>{})
        : prism_rtl::is<crate::lower::model::Pa::PaBind>(p_) ? ({
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaBind>(p_).a0;
        prism_rtl::finished(Array(std::vector{prism_rtl::cat("auto&& ", crate::emit::cpp::cpp_id(n), " = ", v_, ";")}));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaMut>(p_) ? ({
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaMut>(p_).a0;
        prism_rtl::finished(Array(std::vector{prism_rtl::cat("auto ", crate::emit::cpp::cpp_id(n), " = ", v_, ";")}));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaTyped>(p_) && ({
        auto&& m2400_3_0 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_).a0;
        auto&& t = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_).a1;
        prism_rtl::is<crate::lower::model::Pa::PaBind>(m2400_3_0);
    }) ? ({
        auto&& m2400_3_0 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_).a0;
        auto&& t = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_).a1;
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaBind>(m2400_3_0).a0;
        ({
        auto cp_1 = cp;
        auto n_2 = n;
        auto t_3 = t;
        auto v__4 = v_;
        call_then(crate::emit::cpp::start_cpp_type(cp_1, crate::emit::cpp::expr::unref(t_3)), [=](Text cpp_type_2542) { return prism_rtl::finished(Array(std::vector{prism_rtl::cat(cpp_type_2542, " ", crate::emit::cpp::cpp_id(n_2), " = ", v__4, ";")})); });
    });
    })
        : prism_rtl::is<crate::lower::model::Pa::PaTyped>(p_) ? ({
        auto&& q = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_).a0;
        prism_rtl::more(prism_rtl::rc(PatBinds(cp, q, v_)));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaUnit>(p_) ? prism_rtl::finished(Array<Text>{})
        : prism_rtl::is<crate::lower::model::Pa::PaCtor>(p_) ? ({
        auto&& c = prism_rtl::as<crate::lower::model::Pa::PaCtor>(p_).a0;
        auto&& ps = prism_rtl::as<crate::lower::model::Pa::PaCtor>(p_).a1;
        ({
        auto c_1 = c;
        auto cp_2 = cp;
        auto ps_3 = ps;
        auto v__4 = v_;
        call_value(each_job(crate::check::errors::range0(len(ps_3)), ({
        auto cp_2_5 = cp_2;
        auto ps_3_5 = ps_3;
        auto c_1_5 = c_1;
        auto v__4_5 = v__4;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto cp_2_5_5 = cp_2_5;
            auto ps_3_5_5 = ps_3_5;
            auto c_1_5_5 = c_1_5;
            auto v__4_5_5 = v__4_5;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                (prism_rtl::more(prism_rtl::rc(PatBinds(cp_2_5_5, or_(index(ps_3_5_5, i), crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})), crate::emit::cpp::expr::payload(cp_2_5_5, c_1_5_5, v__4_5_5, i)))));
            });
        }));
        });
    })));
    })), [=](Array<Array<Text>> each_2677) { return prism_rtl::finished(concat2(each_2677)); });
    });
    })
        : prism_rtl::is<crate::lower::model::Pa::PaRecord>(p_) ? ({
        auto&& c = prism_rtl::as<crate::lower::model::Pa::PaRecord>(p_).a0;
        auto&& fs = prism_rtl::as<crate::lower::model::Pa::PaRecord>(p_).a1;
        ({
        auto cp_1 = cp;
        auto fs_2 = fs;
        auto v__3 = v_;
        call_value(each_job(fs_2, ({
        auto cp_1_4 = cp_1;
        auto v__3_4 = v__3;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Text, crate::lower::model::Pa>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::Pa> p0) {
        return ({
            auto cp_1_4_4 = cp_1_4;
            auto v__3_4_4 = v__3_4;
            entered(once_job([=]() {
            return ({
                auto [f, q] = p0;
                (prism_rtl::more(prism_rtl::rc(PatBinds(cp_1_4_4, q, prism_rtl::cat(v__3_4_4, ".", crate::emit::cpp::field_id(f))))));
            });
        }));
        });
    })));
    })), [=](Array<Array<Text>> each_2799) { return prism_rtl::finished(concat2(each_2799)); });
    });
    })
        : prism_rtl::is<crate::lower::model::Pa::PaTuple>(p_) ? ({
        auto&& ps = prism_rtl::as<crate::lower::model::Pa::PaTuple>(p_).a0;
        ({
        auto cp_1 = cp;
        auto ps_2 = ps;
        auto v__3 = v_;
        call_value(each_job(crate::check::errors::range0(len(ps_2)), ({
        auto cp_1_4 = cp_1;
        auto ps_2_4 = ps_2;
        auto v__3_4 = v__3;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto cp_1_4_4 = cp_1_4;
            auto ps_2_4_4 = ps_2_4;
            auto v__3_4_4 = v__3_4;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                (prism_rtl::more(prism_rtl::rc(PatBinds(cp_1_4_4, or_(index(ps_2_4_4, i), crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})), prism_rtl::cat("std::get<", i, ">(", v__3_4_4, ")")))));
            });
        }));
        });
    })));
    })), [=](Array<Array<Text>> each_2880) { return prism_rtl::finished(concat2(each_2880)); });
    });
    })
        : prism_rtl::is<crate::lower::model::Pa::PaSlice>(p_) ? ({
        auto&& ps = prism_rtl::as<crate::lower::model::Pa::PaSlice>(p_).a0;
        ({
        auto cp_1 = cp;
        auto ps_2 = ps;
        auto v__3 = v_;
        call_value(each_job(crate::check::errors::range0(len(ps_2)), ({
        auto cp_1_4 = cp_1;
        auto ps_2_4 = ps_2;
        auto v__3_4 = v__3;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto cp_1_4_4 = cp_1_4;
            auto ps_2_4_4 = ps_2_4;
            auto v__3_4_4 = v__3_4;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                (prism_rtl::more(prism_rtl::rc(SliceBinds(cp_1_4_4, or_(index(ps_2_4_4, i), crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})), v__3_4_4, i))));
            });
        }));
        });
    })));
    })), [=](Array<Array<Text>> each_2989) { return prism_rtl::finished(concat2(each_2989)); });
    });
    })
        : prism_rtl::finished(Array<Text>{});
    });
}


/// `Start PatBinds, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_pat_binds(crate::emit::cpp::Cp cp, crate::lower::model::Pa p_, Text v_) {
    return prism_rtl::make_rc<PatBinds>(cp, p_, v_);
}


/// SliceBinds: unbounded fn Cp, Pa, Text, Nat -> [Text]
Array<Text> slice_binds(const crate::emit::cpp::Cp& cp, const crate::lower::model::Pa& pa1, const Text& v_, const Nat& i) {
    if (prism_rtl::is<crate::lower::model::Pa::PaRest>(pa1)) {
        auto&& c0_1_0 = prism_rtl::as<crate::lower::model::Pa::PaRest>(pa1).a0;
        if (c0_1_0 == Text::lit("")) {
            return Array<Text>{};
        }
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaRest>(pa1)) {
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaRest>(pa1).a0;
        return Array(std::vector{prism_rtl::cat("auto ", crate::emit::cpp::cpp_id(n), " = ", v_, ".subspan(", i, ");")});
    }
    {
        auto&& p_ = pa1;
        return pat_binds(cp, p_, prism_rtl::cat(v_, "[", i, "]"));
    }
}


prism_rtl::Turn<Array<Text>> SliceBinds::cycle() const {
    const auto& cp = this->cp;
    const auto& pa1 = this->pa1;
    const auto& v_ = this->v_;
    const auto& i = this->i;
    return ({
        prism_rtl::is<crate::lower::model::Pa::PaRest>(pa1) && ({
        auto&& j0_1_0 = prism_rtl::as<crate::lower::model::Pa::PaRest>(pa1).a0;
        (j0_1_0 == Text::lit(""));
    }) ? ({
        auto&& j0_1_0 = prism_rtl::as<crate::lower::model::Pa::PaRest>(pa1).a0;
        prism_rtl::finished(Array<Text>{});
    })
        : prism_rtl::is<crate::lower::model::Pa::PaRest>(pa1) ? ({
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaRest>(pa1).a0;
        prism_rtl::finished(Array(std::vector{prism_rtl::cat("auto ", crate::emit::cpp::cpp_id(n), " = ", v_, ".subspan(", i, ");")}));
    })
        : ({
        auto&& p_ = pa1;
        prism_rtl::more(prism_rtl::rc(PatBinds(cp, p_, prism_rtl::cat(v_, "[", i, "]"))));
    });
    });
}


/// `Start SliceBinds, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_slice_binds(crate::emit::cpp::Cp cp, crate::lower::model::Pa pa1, Text v_, Nat i) {
    return prism_rtl::make_rc<SliceBinds>(cp, pa1, v_, i);
}


/// IsRest: fn Pa -> Bool
bool is_rest(const crate::lower::model::Pa& pa0) {
    if (prism_rtl::is<crate::lower::model::Pa::PaRest>(pa0)) {
        return true;
    }
    {
        auto&& other = pa0;
        return false;
    }
}


/// Concat2: fn [ [Text] ] -> [Text]
Array<Text> concat2(const Array<Array<Text>>& xss) {
    return fold(xss, Array<Text>{}, [&](const Array<Text>& acc, const Array<Text>& xs) { return append(acc, xs); });
}


/// Conds: fn [Text] -> Text
Text conds(const Array<Text>& xs0) {
    {
        auto&& c0_0 = xs0;
        if (c0_0.size() == 0u) {
            return Text::lit("true");
        }
    }
    {
        auto&& cs = xs0;
        return crate::syntax::lexer::chars::join(cs, Text::lit(" && "));
    }
}


/// IsCatchAll: fn Pa -> Bool
bool is_catch_all(const crate::lower::model::Pa& p_) {
    if (prism_rtl::is<crate::lower::model::Pa::PaWild>(p_)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaBind>(p_)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaMut>(p_)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaTyped>(p_)) {
        auto&& q = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_).a0;
        return is_catch_all(q);
    }
    {
        return false;
    }
}


/// Leaves: fn Ex -> Bool
bool leaves(const crate::lower::model::Ex& x) {
    if (prism_rtl::is<crate::lower::model::Ex::XBreak>(x)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XBreakLoop>(x)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XUnreachable>(x)) {
        return true;
    }
    {
        return false;
    }
}


/// CppMatch: unbounded fn Cp, Ex, [XArm], OutTy -> Text
Text cpp_match(const crate::emit::cpp::Cp& cp, const crate::lower::model::Ex& s, const Array<crate::lower::model::XArm>& arms, const crate::lower::model::OutTy& out_ty3) {
    if (prism_rtl::is<crate::lower::model::OutTy::OutUnknown>(out_ty3)) {
        auto&& what = prism_rtl::as<crate::lower::model::OutTy::OutUnknown>(out_ty3).a0;
        return ternary_match(cp, s, arms);
    }
    {
        auto&& t = out_ty3;
        auto bound_opt = ({
            __label__ _done;
            prism_rtl::Slot<std::optional<Text>> _v;
            if (prism_rtl::is<crate::lower::model::Ex::XVar>(s)) {
                auto&& n = prism_rtl::as<crate::lower::model::Ex::XVar>(s).a0;
                _v.set(std::optional(crate::emit::cpp::cpp_id(n)));
                goto _done;
            }
            if (prism_rtl::is<crate::lower::model::Ex::XRef>(s)) {
                auto&& m4487_1_0 = prism_rtl::as<crate::lower::model::Ex::XRef>(s).a0;
                if (prism_rtl::is<crate::lower::model::Ex::XVar>(m4487_1_0)) {
                    auto&& n = prism_rtl::as<crate::lower::model::Ex::XVar>(m4487_1_0).a0;
                    _v.set(std::optional(crate::emit::cpp::cpp_id(n)));
                    goto _done;
                }
            }
            {
                _v.set(std::optional<Text>{});
                goto _done;
            }
        _done:
            _v.take();
        });
        auto subject = or_(bound_opt, Text::lit("_m"));
        auto bind = ({
            __label__ _done;
            prism_rtl::Slot<Text> _v;
            if (prism_rtl::is_some(bound_opt)) {
                _v.set(Text::lit(""));
                goto _done;
            }
            if (prism_rtl::is_none(bound_opt)) {
                _v.set(prism_rtl::cat("auto&& _m = ", crate::emit::cpp::expr::cpp_expr(cp, s), ";\n"));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto lines = run_to_end(each_job(arms, ({
            auto cp_1 = cp;
            auto subject_2 = subject;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::XArm)>>(prism_rtl::rc([=](crate::lower::model::XArm p0) {
            return ({
                auto cp_1_3 = cp_1;
                auto subject_2_3 = subject_2;
                entered(once_job([=]() {
                return ({
                    auto a = p0;
                    (prism_rtl::more(prism_rtl::rc(MatchArm(cp_1_3, subject_2_3, a, false))));
                });
            }));
            });
        })));
        })));
        return crate::emit::cpp::templates::items::match_expr(crate::emit::cpp::cpp_type(cp, t), prism_rtl::cat(bind, crate::syntax::lexer::chars::join(lines, Text::lit("\n")), "\n", match_tail(arms)));
    }
}


prism_rtl::Turn<Text> CppMatch::cycle() const {
    const auto& cp = this->cp;
    const auto& s = this->s;
    const auto& arms = this->arms;
    const auto& out_ty3 = this->out_ty3;
    return ({
        prism_rtl::is<crate::lower::model::OutTy::OutUnknown>(out_ty3) ? ({
        auto&& what = prism_rtl::as<crate::lower::model::OutTy::OutUnknown>(out_ty3).a0;
        prism_rtl::more(prism_rtl::rc(TernaryMatch(cp, s, arms)));
    })
        : ({
        auto&& t = out_ty3;
        ({
        auto bound_opt = ({
            __label__ _done;
            prism_rtl::Slot<std::optional<Text>> _v;
            if (prism_rtl::is<crate::lower::model::Ex::XVar>(s)) {
                auto&& n = prism_rtl::as<crate::lower::model::Ex::XVar>(s).a0;
                _v.set(std::optional(crate::emit::cpp::cpp_id(n)));
                goto _done;
            }
            if (prism_rtl::is<crate::lower::model::Ex::XRef>(s)) {
                auto&& m4487_1_0 = prism_rtl::as<crate::lower::model::Ex::XRef>(s).a0;
                if (prism_rtl::is<crate::lower::model::Ex::XVar>(m4487_1_0)) {
                    auto&& n = prism_rtl::as<crate::lower::model::Ex::XVar>(m4487_1_0).a0;
                    _v.set(std::optional(crate::emit::cpp::cpp_id(n)));
                    goto _done;
                }
            }
            {
                _v.set(std::optional<Text>{});
                goto _done;
            }
        _done:
            _v.take();
        });
        auto subject = or_(bound_opt, Text::lit("_m"));
        auto bind = ({
            __label__ _done;
            prism_rtl::Slot<Text> _v;
            if (prism_rtl::is_some(bound_opt)) {
                _v.set(Text::lit(""));
                goto _done;
            }
            if (prism_rtl::is_none(bound_opt)) {
                _v.set(prism_rtl::cat("auto&& _m = ", crate::emit::cpp::expr::cpp_expr(cp, s), ";\n"));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto arms_1 = arms;
        auto cp_2 = cp;
        auto s_3 = s;
        auto t_4 = t;
        call_value(each_job(arms_1, ({
        auto cp_2_5 = cp_2;
        auto subject_5 = subject;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::XArm)>>(prism_rtl::rc([=](crate::lower::model::XArm p0) {
        return ({
            auto cp_2_5_6 = cp_2_5;
            auto subject_5_6 = subject_5;
            entered(once_job([=]() {
            return ({
                auto a = p0;
                (prism_rtl::more(prism_rtl::rc(MatchArm(cp_2_5_6, subject_5_6, a, false))));
            });
        }));
        });
    })));
    })), [=](Array<Text> each_4728) {
        return ({
            auto lines = each_4728;
            call_then(crate::emit::cpp::start_cpp_type(cp_2, t_4), [=](Text cpp_type_4790) { return prism_rtl::finished(crate::emit::cpp::templates::items::match_expr(cpp_type_4790, prism_rtl::cat(bind, crate::syntax::lexer::chars::join(lines, Text::lit("\n")), "\n", match_tail(arms_1)))); });
        });
    });
    });
    });
    });
}


/// `Start CppMatch, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_match(crate::emit::cpp::Cp cp, crate::lower::model::Ex s, Array<crate::lower::model::XArm> arms, crate::lower::model::OutTy out_ty3) {
    return prism_rtl::make_rc<CppMatch>(cp, s, arms, out_ty3);
}


/// ReturnMatch: unbounded fn Cp, Ex, [XArm], OutTy -> Text
Text return_match(const crate::emit::cpp::Cp& cp, const crate::lower::model::Ex& s, const Array<crate::lower::model::XArm>& arms, const crate::lower::model::OutTy& out_ty3) {
    if (prism_rtl::is<crate::lower::model::OutTy::OutUnknown>(out_ty3)) {
        auto&& what = prism_rtl::as<crate::lower::model::OutTy::OutUnknown>(out_ty3).a0;
        return prism_rtl::cat("return ", ternary_match(cp, s, arms), ";");
    }
    {
        auto&& t = out_ty3;
        auto bound_opt = ({
            __label__ _done;
            prism_rtl::Slot<std::optional<Text>> _v;
            if (prism_rtl::is<crate::lower::model::Ex::XVar>(s)) {
                auto&& n = prism_rtl::as<crate::lower::model::Ex::XVar>(s).a0;
                _v.set(std::optional(crate::emit::cpp::cpp_id(n)));
                goto _done;
            }
            if (prism_rtl::is<crate::lower::model::Ex::XRef>(s)) {
                auto&& m5261_1_0 = prism_rtl::as<crate::lower::model::Ex::XRef>(s).a0;
                if (prism_rtl::is<crate::lower::model::Ex::XVar>(m5261_1_0)) {
                    auto&& n = prism_rtl::as<crate::lower::model::Ex::XVar>(m5261_1_0).a0;
                    _v.set(std::optional(crate::emit::cpp::cpp_id(n)));
                    goto _done;
                }
            }
            {
                _v.set(std::optional<Text>{});
                goto _done;
            }
        _done:
            _v.take();
        });
        auto subject = or_(bound_opt, Text::lit("_m"));
        auto bind = ({
            __label__ _done;
            prism_rtl::Slot<Text> _v;
            if (prism_rtl::is_some(bound_opt)) {
                _v.set(Text::lit(""));
                goto _done;
            }
            if (prism_rtl::is_none(bound_opt)) {
                _v.set(prism_rtl::cat("auto&& _m = ", crate::emit::cpp::expr::cpp_expr(cp, s), ";\n"));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto lines = run_to_end(each_job(arms, ({
            auto cp_1 = cp;
            auto subject_2 = subject;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::XArm)>>(prism_rtl::rc([=](crate::lower::model::XArm p0) {
            return ({
                auto cp_1_3 = cp_1;
                auto subject_2_3 = subject_2;
                entered(once_job([=]() {
                return ({
                    auto a = p0;
                    (prism_rtl::more(prism_rtl::rc(MatchArm(cp_1_3, subject_2_3, a, true))));
                });
            }));
            });
        })));
        })));
        return prism_rtl::cat(bind, crate::syntax::lexer::chars::join(lines, Text::lit("\n")), "\n", match_tail(arms));
    }
}


prism_rtl::Turn<Text> ReturnMatch::cycle() const {
    const auto& cp = this->cp;
    const auto& s = this->s;
    const auto& arms = this->arms;
    const auto& out_ty3 = this->out_ty3;
    return ({
        prism_rtl::is<crate::lower::model::OutTy::OutUnknown>(out_ty3) ? ({
        auto&& what = prism_rtl::as<crate::lower::model::OutTy::OutUnknown>(out_ty3).a0;
        ({
        auto arms_1 = arms;
        auto cp_2 = cp;
        auto s_3 = s;
        call_then(start_ternary_match(cp_2, s_3, arms_1), [=](Text ternary_match_5185) { return prism_rtl::finished(prism_rtl::cat("return ", ternary_match_5185, ";")); });
    });
    })
        : ({
        auto&& t = out_ty3;
        ({
        auto bound_opt = ({
            __label__ _done;
            prism_rtl::Slot<std::optional<Text>> _v;
            if (prism_rtl::is<crate::lower::model::Ex::XVar>(s)) {
                auto&& n = prism_rtl::as<crate::lower::model::Ex::XVar>(s).a0;
                _v.set(std::optional(crate::emit::cpp::cpp_id(n)));
                goto _done;
            }
            if (prism_rtl::is<crate::lower::model::Ex::XRef>(s)) {
                auto&& m5261_1_0 = prism_rtl::as<crate::lower::model::Ex::XRef>(s).a0;
                if (prism_rtl::is<crate::lower::model::Ex::XVar>(m5261_1_0)) {
                    auto&& n = prism_rtl::as<crate::lower::model::Ex::XVar>(m5261_1_0).a0;
                    _v.set(std::optional(crate::emit::cpp::cpp_id(n)));
                    goto _done;
                }
            }
            {
                _v.set(std::optional<Text>{});
                goto _done;
            }
        _done:
            _v.take();
        });
        auto subject = or_(bound_opt, Text::lit("_m"));
        auto bind = ({
            __label__ _done;
            prism_rtl::Slot<Text> _v;
            if (prism_rtl::is_some(bound_opt)) {
                _v.set(Text::lit(""));
                goto _done;
            }
            if (prism_rtl::is_none(bound_opt)) {
                _v.set(prism_rtl::cat("auto&& _m = ", crate::emit::cpp::expr::cpp_expr(cp, s), ";\n"));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto arms_1 = arms;
        auto cp_2 = cp;
        auto s_3 = s;
        call_value(each_job(arms_1, ({
        auto cp_2_4 = cp_2;
        auto subject_4 = subject;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::XArm)>>(prism_rtl::rc([=](crate::lower::model::XArm p0) {
        return ({
            auto cp_2_4_5 = cp_2_4;
            auto subject_4_5 = subject_4;
            entered(once_job([=]() {
            return ({
                auto a = p0;
                (prism_rtl::more(prism_rtl::rc(MatchArm(cp_2_4_5, subject_4_5, a, true))));
            });
        }));
        });
    })));
    })), [=](Array<Text> each_5502) {
        return ({
            auto lines = each_5502;
            (prism_rtl::finished(prism_rtl::cat(bind, crate::syntax::lexer::chars::join(lines, Text::lit("\n")), "\n", match_tail(arms_1))));
        });
    });
    });
    });
    });
}


/// `Start ReturnMatch, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_return_match(crate::emit::cpp::Cp cp, crate::lower::model::Ex s, Array<crate::lower::model::XArm> arms, crate::lower::model::OutTy out_ty3) {
    return prism_rtl::make_rc<ReturnMatch>(cp, s, arms, out_ty3);
}


/// MatchTail: fn [XArm] -> Text
Text match_tail(const Array<crate::lower::model::XArm>& arms) {
    auto ends = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = crate::syntax::lexer::chars::last(arms);
        if (prism_rtl::is_some(_m)) {
            auto&& a = prism_rtl::some_of(_m);
            _v.set(is_catch_all(a.pat) && (len(a.conds) == Nat(0u)));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(false);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return ends
        ? Text::lit("")
        : Text::lit("prism_rtl::unreachable(\"no arm matched\");\n");
}


/// TernaryMatch: unbounded fn Cp, Ex, [XArm] -> Text
Text ternary_match(const crate::emit::cpp::Cp& cp, const crate::lower::model::Ex& s, const Array<crate::lower::model::XArm>& arms) {
    auto bound_opt = ({
        __label__ _done;
        prism_rtl::Slot<std::optional<Text>> _v;
        if (prism_rtl::is<crate::lower::model::Ex::XVar>(s)) {
            auto&& n = prism_rtl::as<crate::lower::model::Ex::XVar>(s).a0;
            _v.set(std::optional(crate::emit::cpp::stmts::var_name(cp, n)));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::Ex::XRef>(s)) {
            auto&& m6234_1_0 = prism_rtl::as<crate::lower::model::Ex::XRef>(s).a0;
            if (prism_rtl::is<crate::lower::model::Ex::XVar>(m6234_1_0)) {
                auto&& n = prism_rtl::as<crate::lower::model::Ex::XVar>(m6234_1_0).a0;
                _v.set(std::optional(crate::emit::cpp::stmts::var_name(cp, n)));
                goto _done;
            }
        }
        {
            _v.set(std::optional<Text>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto subject = or_(bound_opt, Text::lit("_m"));
    auto bind = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        if (prism_rtl::is_some(bound_opt)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        if (prism_rtl::is_none(bound_opt)) {
            _v.set(prism_rtl::cat("auto&& _m = ", crate::emit::cpp::expr::cpp_expr(cp, s), ";\n"));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto reached = run_to_end(fold_job(arms, std::tuple{Array<crate::lower::model::XArm>{}, false}, ({
        auto cp_1 = cp;
        auto subject_2 = subject;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::lower::model::XArm>, bool>>(std::tuple<std::tuple<Array<crate::lower::model::XArm>, bool>, crate::lower::model::XArm>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<crate::lower::model::XArm>, bool>, crate::lower::model::XArm> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto cp_1_3 = cp_1;
            auto subject_2_3 = subject_2;
            entered(once_job([=]() {
            return ({
                auto [acc, done] = p0;
                auto a = p1;
                done
                ? prism_rtl::finished(std::tuple{acc, done})
                : call_then(start_pat_conds(cp_1_3, a.pat, subject_2_3), [=](Array<Text> pat_conds_6673) { return prism_rtl::finished(std::tuple{crate::prelude::push(acc, a), (len(pat_conds_6673) == Nat(0u)) && (len(a.conds) == Nat(0u))}); });
            });
        }));
        });
    }));
    })));
    auto [kept, ends] = reached;
    auto parts = run_to_end(each_job(kept, ({
        auto cp_1 = cp;
        auto subject_2 = subject;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::XArm)>>(prism_rtl::rc([=](crate::lower::model::XArm p0) {
        return ({
            auto cp_1_3 = cp_1;
            auto subject_2_3 = subject_2;
            entered(once_job([=]() {
            return ({
                auto a = p0;
                (prism_rtl::more(prism_rtl::rc(TernaryArm(cp_1_3, subject_2_3, a))));
            });
        }));
        });
    })));
    })));
    auto last_text = ends
        ? Text::lit("")
        : Text::lit("\n    : throw prism_rtl::Panic(\"no arm matched\")");
    return crate::emit::cpp::templates::items::stmt_expr(prism_rtl::cat(bind), prism_rtl::cat(crate::syntax::lexer::chars::join(parts, Text::lit("\n    : ")), last_text));
}


prism_rtl::Turn<Text> TernaryMatch::cycle() const {
    const auto& cp = this->cp;
    const auto& s = this->s;
    const auto& arms = this->arms;
    auto bound_opt = ({
        __label__ _done;
        prism_rtl::Slot<std::optional<Text>> _v;
        if (prism_rtl::is<crate::lower::model::Ex::XVar>(s)) {
            auto&& n = prism_rtl::as<crate::lower::model::Ex::XVar>(s).a0;
            _v.set(std::optional(crate::emit::cpp::stmts::var_name(cp, n)));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::Ex::XRef>(s)) {
            auto&& m6234_1_0 = prism_rtl::as<crate::lower::model::Ex::XRef>(s).a0;
            if (prism_rtl::is<crate::lower::model::Ex::XVar>(m6234_1_0)) {
                auto&& n = prism_rtl::as<crate::lower::model::Ex::XVar>(m6234_1_0).a0;
                _v.set(std::optional(crate::emit::cpp::stmts::var_name(cp, n)));
                goto _done;
            }
        }
        {
            _v.set(std::optional<Text>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto subject = or_(bound_opt, Text::lit("_m"));
    auto bind = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        if (prism_rtl::is_some(bound_opt)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        if (prism_rtl::is_none(bound_opt)) {
            _v.set(prism_rtl::cat("auto&& _m = ", crate::emit::cpp::expr::cpp_expr(cp, s), ";\n"));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto arms_1 = arms;
    auto cp_2 = cp;
    return call_value(fold_job(arms_1, std::tuple{Array<crate::lower::model::XArm>{}, false}, ({
        auto cp_2_3 = cp_2;
        auto subject_3 = subject;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::lower::model::XArm>, bool>>(std::tuple<std::tuple<Array<crate::lower::model::XArm>, bool>, crate::lower::model::XArm>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<crate::lower::model::XArm>, bool>, crate::lower::model::XArm> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto cp_2_3_4 = cp_2_3;
            auto subject_3_4 = subject_3;
            entered(once_job([=]() {
            return ({
                auto [acc, done] = p0;
                auto a = p1;
                done
                ? prism_rtl::finished(std::tuple{acc, done})
                : call_then(start_pat_conds(cp_2_3_4, a.pat, subject_3_4), [=](Array<Text> pat_conds_6673) { return prism_rtl::finished(std::tuple{crate::prelude::push(acc, a), (len(pat_conds_6673) == Nat(0u)) && (len(a.conds) == Nat(0u))}); });
            });
        }));
        });
    }));
    })), [=](std::tuple<Array<crate::lower::model::XArm>, bool> fold_6573) {
        return ({
            auto reached = fold_6573;
            auto [kept, ends] = reached;
            call_value(each_job(kept, ({
            auto cp_2_3 = cp_2;
            auto subject_3 = subject;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::XArm)>>(prism_rtl::rc([=](crate::lower::model::XArm p0) {
            return ({
                auto cp_2_3_4 = cp_2_3;
                auto subject_3_4 = subject_3;
                entered(once_job([=]() {
                return ({
                    auto a = p0;
                    (prism_rtl::more(prism_rtl::rc(TernaryArm(cp_2_3_4, subject_3_4, a))));
                });
            }));
            });
        })));
        })), [=](Array<Text> each_6782) {
            return ({
                auto parts = each_6782;
                auto last_text = ends
                    ? Text::lit("")
                    : Text::lit("\n    : throw prism_rtl::Panic(\"no arm matched\")");
                (prism_rtl::finished(crate::emit::cpp::templates::items::stmt_expr(prism_rtl::cat(bind), prism_rtl::cat(crate::syntax::lexer::chars::join(parts, Text::lit("\n    : ")), last_text))));
            });
        });
        });
    });
}


/// `Start TernaryMatch, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_ternary_match(crate::emit::cpp::Cp cp, crate::lower::model::Ex s, Array<crate::lower::model::XArm> arms) {
    return prism_rtl::make_rc<TernaryMatch>(cp, s, arms);
}


/// TernaryArm: unbounded fn Cp, Text, XArm -> Text
Text ternary_arm(const crate::emit::cpp::Cp& cp0, const Text& subject, const crate::lower::model::XArm& a) {
    auto cp = crate::emit::cpp::stmts::unbind(cp0, crate::emit::cpp::stmts::arm_names(a));
    auto tests = pat_conds(cp, a.pat, subject);
    auto binds = pat_binds(cp, a.pat, subject);
    auto n = len(a.conds);
    auto lets = concat2(run_to_end(each_job(crate::check::errors::range0(n), ({
        auto cp_1 = cp;
        auto a_2 = a;
        auto n_3 = n;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto cp_1_4 = cp_1;
            auto a_2_4 = a_2;
            auto n_3_4 = n_3;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                (prism_rtl::more(prism_rtl::rc(CondBinds(cp_1_4, or_(index(a_2_4.conds, i), crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{})})), or_(n_3_4.checked_sub(i), Nat(0u))))));
            });
        }));
        });
    })));
    }))));
    auto value = (len(binds) + len(lets)) == Nat(0u)
        ? crate::emit::cpp::expr::cpp_expr(cp, a.body)
        : crate::emit::cpp::templates::items::stmt_expr(crate::syntax::lexer::chars::join(append(binds, lets), Text::lit("\n")), crate::emit::cpp::expr::cpp_expr(cp, a.body));
    auto guard = len(a.conds) == Nat(0u)
        ? Array<Text>{}
        : Array(std::vector{crate::emit::cpp::templates::items::stmt_expr(crate::syntax::lexer::chars::join(binds, Text::lit("\n")), guard_test(cp, a.conds))});
    auto all = append(tests, guard);
    return len(all) == Nat(0u) ? value : prism_rtl::cat(conds(all), " ? ", value);
}


prism_rtl::Turn<Text> TernaryArm::cycle() const {
    const auto& cp0 = this->cp0;
    const auto& subject = this->subject;
    const auto& a = this->a;
    auto a_1 = a;
    auto cp0_2 = cp0;
    auto subject_3 = subject;
    return call_then(crate::emit::cpp::stmts::start_arm_names(a_1), [=](Array<Text> arm_names_7080) {
        return ({
            auto cp = crate::emit::cpp::stmts::unbind(cp0_2, arm_names_7080);
            call_then(start_pat_conds(cp, a_1.pat, subject_3), [=](Array<Text> pat_conds_7108) {
            return ({
                auto tests = pat_conds_7108;
                call_then(start_pat_binds(cp, a_1.pat, subject_3), [=](Array<Text> pat_binds_7152) {
                return ({
                    auto binds = pat_binds_7152;
                    auto n = len(a_1.conds);
                    call_value(each_job(crate::check::errors::range0(n), ({
                    auto cp_4 = cp;
                    auto a_1_5 = a_1;
                    auto n_5 = n;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
                    return ({
                        auto cp_4_6 = cp_4;
                        auto a_1_5_6 = a_1_5;
                        auto n_5_6 = n_5;
                        entered(once_job([=]() {
                        return ({
                            auto i = p0;
                            (prism_rtl::more(prism_rtl::rc(CondBinds(cp_4_6, or_(index(a_1_5_6.conds, i), crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{})})), or_(n_5_6.checked_sub(i), Nat(0u))))));
                        });
                    }));
                    });
                })));
                })), [=](Array<Array<Text>> each_7228) {
                    return ({
                        auto lets = concat2(each_7228);
                        auto value = (len(binds) + len(lets)) == Nat(0u)
                            ? crate::emit::cpp::expr::cpp_expr(cp, a_1.body)
                            : crate::emit::cpp::templates::items::stmt_expr(crate::syntax::lexer::chars::join(append(binds, lets), Text::lit("\n")), crate::emit::cpp::expr::cpp_expr(cp, a_1.body));
                        auto guard = len(a_1.conds) == Nat(0u)
                            ? Array<Text>{}
                            : Array(std::vector{crate::emit::cpp::templates::items::stmt_expr(crate::syntax::lexer::chars::join(binds, Text::lit("\n")), guard_test(cp, a_1.conds))});
                        auto all = append(tests, guard);
                        len(all) == Nat(0u)
                        ? prism_rtl::finished(value)
                        : prism_rtl::finished(prism_rtl::cat(conds(all), " ? ", value));
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start TernaryArm, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_ternary_arm(crate::emit::cpp::Cp cp0, Text subject, crate::lower::model::XArm a) {
    return prism_rtl::make_rc<TernaryArm>(cp0, subject, a);
}


/// CondBinds: unbounded fn Cp, Cc, Nat -> [Text]
Array<Text> cond_binds(const crate::emit::cpp::Cp& cp, const crate::lower::model::Cc& cc1, const Nat& k) {
    if (prism_rtl::is<crate::lower::model::Cc::CcLet>(cc1)) {
        auto&& p_ = prism_rtl::as<crate::lower::model::Cc::CcLet>(cc1).a0;
        auto&& x = prism_rtl::as<crate::lower::model::Cc::CcLet>(cc1).a1;
        auto [v_, pre] = cond_subject(cp, x, k);
        return append(pre, pat_binds(cp, p_, v_));
    }
    if (prism_rtl::is<crate::lower::model::Cc::CcIf>(cc1)) {
        auto&& x = prism_rtl::as<crate::lower::model::Cc::CcIf>(cc1).a0;
        return Array<Text>{};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Text>> CondBinds::cycle() const {
    const auto& cp = this->cp;
    const auto& cc1 = this->cc1;
    const auto& k = this->k;
    return ({
        prism_rtl::is<crate::lower::model::Cc::CcLet>(cc1) ? ({
        auto&& p_ = prism_rtl::as<crate::lower::model::Cc::CcLet>(cc1).a0;
        auto&& x = prism_rtl::as<crate::lower::model::Cc::CcLet>(cc1).a1;
        ({
        auto cp_1 = cp;
        auto k_2 = k;
        auto p__3 = p_;
        auto x_4 = x;
        call_then(start_cond_subject(cp_1, x_4, k_2), [=](std::tuple<Text, Array<Text>> cond_subject_7757) {
        return ({
            auto [v_, pre] = cond_subject_7757;
            call_then(start_pat_binds(cp_1, p__3, v_), [=](Array<Text> pat_binds_7795) { return prism_rtl::finished(append(pre, pat_binds_7795)); });
        });
    });
    });
    })
        : prism_rtl::is<crate::lower::model::Cc::CcIf>(cc1) ? ({
        auto&& x = prism_rtl::as<crate::lower::model::Cc::CcIf>(cc1).a0;
        prism_rtl::finished(Array<Text>{});
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CondBinds, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_cond_binds(crate::emit::cpp::Cp cp, crate::lower::model::Cc cc1, Nat k) {
    return prism_rtl::make_rc<CondBinds>(cp, cc1, k);
}


/// CondSubject: unbounded fn Cp, Ex, Nat -> ((Text, [Text]))
std::tuple<Text, Array<Text>> cond_subject(const crate::emit::cpp::Cp& cp, const crate::lower::model::Ex& x, const Nat& k) {
    return is_place_ex(x)
        ? std::tuple{crate::emit::cpp::expr::cpp_tight(cp, x), Array<Text>{}}
        : std::tuple{prism_rtl::cat("_c", k), Array(std::vector{prism_rtl::cat("auto&& _c", k, " = ", crate::emit::cpp::expr::cpp_expr(cp, x), ";")})};
}


prism_rtl::Turn<std::tuple<Text, Array<Text>>> CondSubject::cycle() const {
    const auto& cp = this->cp;
    const auto& x = this->x;
    const auto& k = this->k;
    return is_place_ex(x)
        ? ({
        auto cp_1 = cp;
        auto x_2 = x;
        call_then(crate::emit::cpp::expr::start_cpp_tight(cp_1, x_2), [=](Text cpp_tight_8212) { return prism_rtl::finished(std::tuple{cpp_tight_8212, Array<Text>{}}); });
    })
        : ({
        auto cp_1 = cp;
        auto k_2 = k;
        auto x_3 = x;
        call_then(crate::emit::cpp::expr::start_cpp_expr(cp_1, x_3), [=](Text cpp_expr_8272) { return prism_rtl::finished(std::tuple{prism_rtl::cat("_c", k_2), Array(std::vector{prism_rtl::cat("auto&& _c", k_2, " = ", cpp_expr_8272, ";")})}); });
    });
}


/// `Start CondSubject, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Text, Array<Text>>> start_cond_subject(crate::emit::cpp::Cp cp, crate::lower::model::Ex x, Nat k) {
    return prism_rtl::make_rc<CondSubject>(cp, x, k);
}


/// IsPlaceEx: fn Ex -> Bool
bool is_place_ex(const crate::lower::model::Ex& x) {
    if (prism_rtl::is<crate::lower::model::Ex::XVar>(x)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XField>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XField>(x).a0;
        return is_place_ex(y);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XPart>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XPart>(x).a0;
        return is_place_ex(y);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XTarget>(x)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XSelf>(x)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XRef>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XRef>(x).a0;
        return is_place_ex(y);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XDeref>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XDeref>(x).a0;
        return is_place_ex(y);
    }
    {
        return false;
    }
}


/// GuardTest: unbounded fn Cp, [Cc] -> Text
Text guard_test(const crate::emit::cpp::Cp& cp, const Array<crate::lower::model::Cc>& xs1) {
    {
        auto&& c0_1 = xs1;
        if (c0_1.size() == 0u) {
            return Text::lit("true");
        }
    }
    {
        auto&& cs = xs1;
        auto first_ = or_(index(cs, Nat(0u)), crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{})}));
        auto rest = guard_test(cp, drop(cs, Nat(1u)));
        if (prism_rtl::is<crate::lower::model::Cc::CcIf>(first_)) {
            auto&& x = prism_rtl::as<crate::lower::model::Cc::CcIf>(first_).a0;
            return len(cs) == Nat(1u)
                ? crate::emit::cpp::expr::cpp_tight(cp, x)
                : prism_rtl::cat(crate::emit::cpp::expr::cpp_tight(cp, x), " && ", rest);
        }
        if (prism_rtl::is<crate::lower::model::Cc::CcLet>(first_)) {
            auto&& p_ = prism_rtl::as<crate::lower::model::Cc::CcLet>(first_).a0;
            auto&& x = prism_rtl::as<crate::lower::model::Cc::CcLet>(first_).a1;
            auto [v_, pre] = cond_subject(cp, x, len(cs));
            auto tests = conds(pat_conds(cp, p_, v_));
            auto whole = len(cs) == Nat(1u)
                ? tests
                : prism_rtl::cat(tests, " && ", crate::emit::cpp::templates::items::stmt_expr(crate::syntax::lexer::chars::join(pat_binds(cp, p_, v_), Text::lit("\n")), rest));
            return len(pre) == Nat(0u)
                ? whole
                : crate::emit::cpp::templates::items::stmt_expr(crate::syntax::lexer::chars::join(pre, Text::lit("\n")), whole);
        }
        prism_rtl::unreachable("no arm matched");
    }
}


prism_rtl::Turn<Text> GuardTest::cycle() const {
    const auto& cp = this->cp;
    const auto& xs1 = this->xs1;
    return ({
        ({
        auto&& j0_1 = xs1;
        (j0_1.size() == 0u);
    }) ? ({
        auto&& j0_1 = xs1;
        prism_rtl::finished(Text::lit("true"));
    })
        : ({
        auto&& cs = xs1;
        ({
        auto first_ = or_(index(cs, Nat(0u)), crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{})}));
        auto cp_1 = cp;
        auto cs_2 = cs;
        call_then(start_guard_test(cp_1, drop(cs_2, Nat(1u))), [=](Text guard_test_8776) {
        return ({
            auto rest = guard_test_8776;
            ({
            prism_rtl::is<crate::lower::model::Cc::CcIf>(first_) ? ({
            auto&& x = prism_rtl::as<crate::lower::model::Cc::CcIf>(first_).a0;
            len(cs_2) == Nat(1u)
            ? prism_rtl::more(prism_rtl::rc(crate::emit::cpp::expr::CppTight(cp_1, x)))
            : ({
            auto x_3 = x;
            call_then(crate::emit::cpp::expr::start_cpp_tight(cp_1, x_3), [=](Text cpp_tight_8877) { return prism_rtl::finished(prism_rtl::cat(cpp_tight_8877, " && ", rest)); });
        });
        })
            : prism_rtl::is<crate::lower::model::Cc::CcLet>(first_) ? ({
            auto&& p_ = prism_rtl::as<crate::lower::model::Cc::CcLet>(first_).a0;
            auto&& x = prism_rtl::as<crate::lower::model::Cc::CcLet>(first_).a1;
            ({
            auto p__3 = p_;
            auto x_4 = x;
            call_then(start_cond_subject(cp_1, x_4, len(cs_2)), [=](std::tuple<Text, Array<Text>> cond_subject_8953) {
            return ({
                auto [v_, pre] = cond_subject_8953;
                call_then(start_pat_conds(cp_1, p__3, v_), [=](Array<Text> pat_conds_9012) {
                return ({
                    auto tests = conds(pat_conds_9012);
                    auto whole = len(cs_2) == Nat(1u)
                        ? tests
                        : prism_rtl::cat(tests, " && ", crate::emit::cpp::templates::items::stmt_expr(crate::syntax::lexer::chars::join(pat_binds(cp_1, p__3, v_), Text::lit("\n")), rest));
                    len(pre) == Nat(0u)
                    ? prism_rtl::finished(whole)
                    : prism_rtl::finished(crate::emit::cpp::templates::items::stmt_expr(crate::syntax::lexer::chars::join(pre, Text::lit("\n")), whole));
                });
            });
            });
        });
        });
        })
            : throw prism_rtl::Panic("no arm matched");
        });
        });
    });
    });
    });
    });
}


/// `Start GuardTest, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_guard_test(crate::emit::cpp::Cp cp, Array<crate::lower::model::Cc> xs1) {
    return prism_rtl::make_rc<GuardTest>(cp, xs1);
}


/// MatchArm: unbounded fn Cp, Text, XArm, Bool -> Text
Text match_arm(const crate::emit::cpp::Cp& cp0, const Text& subject, const crate::lower::model::XArm& a, const bool& returns) {
    auto cp = crate::emit::cpp::stmts::unbind(cp0, crate::emit::cpp::stmts::arm_names(a));
    auto tests = pat_conds(cp, a.pat, subject);
    auto binds = pat_binds(cp, a.pat, subject);
    auto body = returns
        ? crate::emit::cpp::stmts::cpp_body(cp, a.body)
        : leaves(a.body)
        ? prism_rtl::cat(crate::emit::cpp::expr::cpp_expr(cp, a.body), ";")
        : prism_rtl::cat("_v.set(", crate::emit::cpp::expr::cpp_expr(cp, a.body), ");\ngoto _done;");
    auto guarded = len(a.conds) == Nat(0u) ? body : guarded_arm(cp, a.conds, body);
    auto inner = crate::syntax::lexer::chars::join(append(binds, Array(std::vector{guarded})), Text::lit("\n"));
    return len(tests) == Nat(0u)
        ? crate::emit::cpp::templates::items::braced(inner)
        : crate::emit::cpp::templates::items::if_block(conds(tests), inner);
}


prism_rtl::Turn<Text> MatchArm::cycle() const {
    const auto& cp0 = this->cp0;
    const auto& subject = this->subject;
    const auto& a = this->a;
    const auto& returns = this->returns;
    auto a_1 = a;
    auto cp0_2 = cp0;
    auto returns_3 = returns;
    auto subject_4 = subject;
    return call_then(crate::emit::cpp::stmts::start_arm_names(a_1), [=](Array<Text> arm_names_9470) {
        return ({
            auto cp = crate::emit::cpp::stmts::unbind(cp0_2, arm_names_9470);
            call_then(start_pat_conds(cp, a_1.pat, subject_4), [=](Array<Text> pat_conds_9498) {
            return ({
                auto tests = pat_conds_9498;
                call_then(start_pat_binds(cp, a_1.pat, subject_4), [=](Array<Text> pat_binds_9542) {
                return ({
                    auto binds = pat_binds_9542;
                    auto body = returns_3
                        ? crate::emit::cpp::stmts::cpp_body(cp, a_1.body)
                        : leaves(a_1.body)
                        ? prism_rtl::cat(crate::emit::cpp::expr::cpp_expr(cp, a_1.body), ";")
                        : prism_rtl::cat("_v.set(", crate::emit::cpp::expr::cpp_expr(cp, a_1.body), ");\ngoto _done;");
                    auto guarded = len(a_1.conds) == Nat(0u) ? body : guarded_arm(cp, a_1.conds, body);
                    auto inner = crate::syntax::lexer::chars::join(append(binds, Array(std::vector{guarded})), Text::lit("\n"));
                    len(tests) == Nat(0u)
                    ? prism_rtl::finished(crate::emit::cpp::templates::items::braced(inner))
                    : prism_rtl::finished(crate::emit::cpp::templates::items::if_block(conds(tests), inner));
                });
            });
            });
        });
        });
    });
}


/// `Start MatchArm, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_match_arm(crate::emit::cpp::Cp cp0, Text subject, crate::lower::model::XArm a, bool returns) {
    return prism_rtl::make_rc<MatchArm>(cp0, subject, a, returns);
}


/// GuardedArm: unbounded fn Cp, [Cc], Text -> Text
Text guarded_arm(const crate::emit::cpp::Cp& cp, const Array<crate::lower::model::Cc>& xs1, const Text& body) {
    {
        auto&& c0_1 = xs1;
        if (c0_1.size() == 0u) {
            return body;
        }
    }
    {
        auto&& cs = xs1;
        auto first_ = or_(index(cs, Nat(0u)), crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{})}));
        auto rest = guarded_arm(cp, drop(cs, Nat(1u)), body);
        if (prism_rtl::is<crate::lower::model::Cc::CcIf>(first_)) {
            auto&& x = prism_rtl::as<crate::lower::model::Cc::CcIf>(first_).a0;
            return crate::emit::cpp::templates::items::if_block(crate::emit::cpp::expr::cpp_expr(cp, x), rest);
        }
        if (prism_rtl::is<crate::lower::model::Cc::CcLet>(first_)) {
            auto&& p_ = prism_rtl::as<crate::lower::model::Cc::CcLet>(first_).a0;
            auto&& x = prism_rtl::as<crate::lower::model::Cc::CcLet>(first_).a1;
            auto [v_, pre] = cond_subject(cp, x, len(cs));
            auto inner = crate::emit::cpp::templates::items::if_block(conds(pat_conds(cp, p_, v_)), crate::syntax::lexer::chars::join(append(pat_binds(cp, p_, v_), Array(std::vector{rest})), Text::lit("\n")));
            return len(pre) == Nat(0u)
                ? inner
                : crate::emit::cpp::templates::items::braced(crate::syntax::lexer::chars::join(crate::prelude::push(pre, inner), Text::lit("\n")));
        }
        prism_rtl::unreachable("no arm matched");
    }
}


prism_rtl::Turn<Text> GuardedArm::cycle() const {
    const auto& cp = this->cp;
    const auto& xs1 = this->xs1;
    const auto& body = this->body;
    return ({
        ({
        auto&& j0_1 = xs1;
        (j0_1.size() == 0u);
    }) ? ({
        auto&& j0_1 = xs1;
        prism_rtl::finished(body);
    })
        : ({
        auto&& cs = xs1;
        ({
        auto first_ = or_(index(cs, Nat(0u)), crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{})}));
        auto body_1 = body;
        auto cp_2 = cp;
        auto cs_3 = cs;
        call_then(start_guarded_arm(cp_2, drop(cs_3, Nat(1u)), body_1), [=](Text guarded_arm_10179) {
        return ({
            auto rest = guarded_arm_10179;
            ({
            prism_rtl::is<crate::lower::model::Cc::CcIf>(first_) ? ({
            auto&& x = prism_rtl::as<crate::lower::model::Cc::CcIf>(first_).a0;
            ({
            auto x_4 = x;
            call_then(crate::emit::cpp::expr::start_cpp_expr(cp_2, x_4), [=](Text cpp_expr_10255) { return prism_rtl::finished(crate::emit::cpp::templates::items::if_block(cpp_expr_10255, rest)); });
        });
        })
            : prism_rtl::is<crate::lower::model::Cc::CcLet>(first_) ? ({
            auto&& p_ = prism_rtl::as<crate::lower::model::Cc::CcLet>(first_).a0;
            auto&& x = prism_rtl::as<crate::lower::model::Cc::CcLet>(first_).a1;
            ({
            auto p__4 = p_;
            auto x_5 = x;
            call_then(start_cond_subject(cp_2, x_5, len(cs_3)), [=](std::tuple<Text, Array<Text>> cond_subject_10325) {
            return ({
                auto [v_, pre] = cond_subject_10325;
                call_then(start_pat_conds(cp_2, p__4, v_), [=](Array<Text> pat_conds_10393) {
                return call_then(start_pat_binds(cp_2, p__4, v_), [=](Array<Text> pat_binds_10429) {
                    return ({
                        auto inner = crate::emit::cpp::templates::items::if_block(conds(pat_conds_10393), crate::syntax::lexer::chars::join(append(pat_binds_10429, Array(std::vector{rest})), Text::lit("\n")));
                        len(pre) == Nat(0u)
                        ? prism_rtl::finished(inner)
                        : prism_rtl::finished(crate::emit::cpp::templates::items::braced(crate::syntax::lexer::chars::join(crate::prelude::push(pre, inner), Text::lit("\n"))));
                    });
                });
            });
            });
        });
        });
        })
            : throw prism_rtl::Panic("no arm matched");
        });
        });
    });
    });
    });
    });
}


/// `Start GuardedArm, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_guarded_arm(crate::emit::cpp::Cp cp, Array<crate::lower::model::Cc> xs1, Text body) {
    return prism_rtl::make_rc<GuardedArm>(cp, xs1, body);
}


/// CppLabeled: unbounded fn Cp, Text, [Do], Ex, OutTy -> Text
Text cpp_labeled(const crate::emit::cpp::Cp& cp, const Text& label, const Array<crate::lower::model::Do>& dos, const crate::lower::model::Ex& e, const crate::lower::model::OutTy& t) {
    auto l = cpp_label(label);
    auto last = leaves(e)
        ? prism_rtl::cat(crate::emit::cpp::expr::cpp_expr(cp, e), ";")
        : prism_rtl::cat(l, "_v.set(", crate::emit::cpp::expr::cpp_expr(cp, e), ");");
    return crate::emit::cpp::templates::items::labeled_expr(l, crate::emit::cpp::cpp_type(cp, t), crate::syntax::lexer::chars::join(crate::prelude::push(run_to_end(each_job(dos, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Do)>>(prism_rtl::rc([=](crate::lower::model::Do p0) {
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=]() {
            return ({
                auto d = p0;
                (prism_rtl::more(prism_rtl::rc(crate::emit::cpp::stmts::CppStatement(cp_1_2, d))));
            });
        }));
        });
    })));
    }))), last), Text::lit("\n")));
}


prism_rtl::Turn<Text> CppLabeled::cycle() const {
    const auto& cp = this->cp;
    const auto& label = this->label;
    const auto& dos = this->dos;
    const auto& e = this->e;
    const auto& t = this->t;
    auto l = cpp_label(label);
    auto last = leaves(e)
        ? prism_rtl::cat(crate::emit::cpp::expr::cpp_expr(cp, e), ";")
        : prism_rtl::cat(l, "_v.set(", crate::emit::cpp::expr::cpp_expr(cp, e), ");");
    auto cp_1 = cp;
    auto dos_2 = dos;
    auto t_3 = t;
    return call_then(crate::emit::cpp::start_cpp_type(cp_1, t_3), [=](Text cpp_type_10855) {
        return call_value(each_job(dos_2, ({
            auto cp_1_4 = cp_1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Do)>>(prism_rtl::rc([=](crate::lower::model::Do p0) {
            return ({
                auto cp_1_4_4 = cp_1_4;
                entered(once_job([=]() {
                return ({
                    auto d = p0;
                    (prism_rtl::more(prism_rtl::rc(crate::emit::cpp::stmts::CppStatement(cp_1_4_4, d))));
                });
            }));
            });
        })));
        })), [=](Array<Text> each_10884) { return prism_rtl::finished(crate::emit::cpp::templates::items::labeled_expr(l, cpp_type_10855, crate::syntax::lexer::chars::join(crate::prelude::push(each_10884, last), Text::lit("\n")))); });
    });
}


/// `Start CppLabeled, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_labeled(crate::emit::cpp::Cp cp, Text label, Array<crate::lower::model::Do> dos, crate::lower::model::Ex e, crate::lower::model::OutTy t) {
    return prism_rtl::make_rc<CppLabeled>(cp, label, dos, e, t);
}


/// CppLabel: fn Text -> Text
Text cpp_label(const Text& l) {
    return crate::syntax::lexer::chars::has_prefix(l, Text::lit("\'"))
        ? crate::syntax::lexer::chars::after_first(l)
        : l;
}


/// CppBreak: unbounded fn Cp, Text, Ex -> Text
Text cpp_break(const crate::emit::cpp::Cp& cp, const Text& l, const crate::lower::model::Ex& y) {
    auto n = cpp_label(l);
    return prism_rtl::cat("{ ", n, "_v.set(", crate::emit::cpp::expr::cpp_expr(cp, y), "); goto ", n, "; }");
}


prism_rtl::Turn<Text> CppBreak::cycle() const {
    const auto& cp = this->cp;
    const auto& l = this->l;
    const auto& y = this->y;
    auto n = cpp_label(l);
    auto cp_1 = cp;
    auto y_2 = y;
    return call_then(crate::emit::cpp::expr::start_cpp_expr(cp_1, y_2), [=](Text cpp_expr_11129) { return prism_rtl::finished(prism_rtl::cat("{ ", n, "_v.set(", cpp_expr_11129, "); goto ", n, "; }")); });
}


/// `Start CppBreak, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_break(crate::emit::cpp::Cp cp, Text l, crate::lower::model::Ex y) {
    return prism_rtl::make_rc<CppBreak>(cp, l, y);
}

}  // namespace crate::emit::cpp::patterns


// The module `Emit.Cpp.Prelude`, from `target/bootstrap/cpp-src/prismc/emit/cpp/prelude.prism`.
namespace crate::emit::cpp::prelude {

/// CppPreludeSource: fn Text -> Text
Text cpp_prelude_source(const Text& unused) {
    auto out = std::string();
    out.append("// The prelude (Semantics Appendix B), emitted by prismc beside every program compiled to\n// C++: the builtins and the prelude\'s own functions over `prism_rtl`.\n#pragma once\n\n#include <algorithm>\n#include <cmath>\n#include <cstdio>\n#include <fstream>\n#include <iostream>\n#include <pthread.h>\n#include <set>\n#include <sstream>\n\n#include \"prism_rtl/lang.hpp\"\n#include \"prism_world_cli/cli.hpp\"\n\nnamespace crate {\n\nusing namespace prism_rtl;\nusing namespace std::literals;\n\nnamespace prelude {\n\n// ---- Types ------------------------------------------------------------------------------\n\n/// `type Ordering = choice: Less | Equal | Greater; derive ^Eq, ^Ord, ^Show`.\nclass Ordering {\npublic:\n    using prism_value = void;\n    struct Less {\n        auto operator<=>(const Less&) const = default;\n    };\n    struct Equal {\n        auto operator<=>(const Equal&) const = default;\n    };\n    struct Greater {\n        auto operator<=>(const Greater&) const = default;\n    };\n    using Cases = std::variant<Less, Equal, Greater>;\n    template <class C>\n        requires prism_rtl::one_of<C, Less, Equal, Greater>\n    Ordering(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}\n    const Cases& cases() const { return *cases_; }\n    const char* name() const {\n        return std::holds_alternative<Less>(cases()) ? \"Less\" : std::holds_alternative<Equal>(cases()) ? \"Equal\" : \"Greater\";\n    }\n    void show(Printer& p) const { p.choice(name(), {}); }\n    Pod to_pod() const { return Pod::name(name()); }\n    friend bool operator==(const Ordering& a, const Ordering& b) { return a.cases() == b.cases(); }\n    friend auto operator<=>(const Ordering& a, const Ordering& b) { return a.cases() <=> b.cases(); }\n\nprivate:\n    prism_rtl::Rc<const Cases> cases_;\n};\n\n/// A derived `FromPod`\'s field.\ninline Result<Pod> field(const Pod& p, const char* name) {\n    if (auto f = p.field(name)) return *f;\n    return unexpected(Fault::answer(str(\"no field \", name, \" in \", p)));\n}\n\n/// `type Span = record: file, line, column, binding`.\nstruct Span {\n    using prism_value = void;\n    Text file;\n    Nat line;\n    Nat column;\n    Text binding;\n    const Span* operator->() const { return this; }\n    auto operator<=>(const Span&) const = default;\n    Pod to_pod() const {\n        return Pod::record(\"Span\", { {\"file\", prism_rtl::to_pod(file)}, {\"line\", prism_rtl::to_pod(line)}, {\"column\", prism_rtl::to_pod(column)}, {\"binding\", prism_rtl::to_pod(binding)} });\n    }\n    static Result<Span> from_pod(const Pod& p) {\n        return Span{.file = TRY(prism_rtl::from_pod<Text>(TRY(field(p, \"file\")))), .line = TRY(prism_rtl::from_pod<Nat>(TRY(field(p, \"line\")))), .column = TRY(prism_rtl::from_pod<Nat>(TRY(field(p, \"column\")))), .binding = TRY(prism_rtl::from_pod<Text>(TRY(field(p, \"binding\"))))};\n    }\n};\n\n/// `type Exception = record: kind, message, spans, path`.\nstruct Exception {\n    using prism_value = void;\n    Text kind;\n    Text message;\n    Array<Span> spans;\n    std::optional<Path> path_;\n    const Exception* operator->() const { return this; }\n    bool operator==(const Exception&) const = default;\n    Pod to_pod() const {\n        return Pod::record(\"Exception\", { {\"kind\", prism_rtl::to_pod(kind)}, {\"message\", prism_rtl::to_pod(message)}, {\"spans\", prism_rtl::to_pod(spans)}, {\"path\", prism_rtl::to_pod(path_)} });\n    }\n    static Result<Exception> from_pod(const Pod& p) {\n        return Exception{.kind = TRY(prism_rtl::from_pod<Text>(TRY(field(p, \"kind\")))), .message = TRY(prism_rtl::from_pod<Text>(TRY(field(p, \"message\")))), .spans = TRY(prism_rtl::from_pod<Array<Span>>(TRY(field(p, \"spans\")))), .path_ = TRY(prism_rtl::from_pod<std::optional<Path>>(TRY(field(p, \"path\"))))};\n    }\n};\n\n/// `tag Prelude.Unwrap of Element !a: value: !~a`.\nstruct PreludeUnwrap {\n    using prism_value = void;\n    static constexpr const char* TAG = \"Prelude.Unwrap\";\n    bool operator==(const PreludeUnwrap&) const = default;\n    Pod to_pod() const { return Pod::element(TAG, {}); }\n    void show(Printer& p) const { Show<Pod>::show(to_pod(), p); }\n    static Result<PreludeUnwrap> from_pod(const Pod& p) {\n        if (auto t = p.tag(); t && *t == TAG) return PreludeUnwrap{};\n        return mismatch<PreludeUnwrap>(\"a Prelude.Unwrap\", p);\n    }\n};\n\n/// `tag Prelude.Exceptions of Element !Exception`.\nstruct PreludeExceptions {\n    using prism_value = void;\n    static constexpr const char* TAG = \"Prelude.Exceptions\";\n    bool operator==(const PreludeExceptions&) const = default;\n    Pod to_pod() const { return Pod::element(TAG, {}); }\n    void show(Printer& p) const { Show<Pod>::show(to_pod(), p); }\n    static Result<PreludeExceptions> from_pod(const Pod& p) {\n        if (auto t = p.tag(); t && *t == TAG) return PreludeExceptions{};\n        return mismatch<PreludeExceptions>(\"a Prelude.Exceptions\", p);\n    }\n};\n\n/// `Duration`: nanoseconds (D14 keeps its arithmetic out).\nstruct Duration {\n    using prism_value = void;\n    Nanos a0;\n    auto operator<=>(const Duration&) const = default;\n    void show(Printer& p) const { p.duration(a0); }\n    Pod to_pod() const { return Pod::duration(a0); }\n    static Result<Duration> from_pod(const Pod& whole) {\n        if (auto ns = whole.structure().if_duration()) return Duration{*ns};\n        return mismatch<Duration>(\"a Duration\", whole.structure());\n    }\n};\n\n// ---- Numbers ----------------------------------------------------------------------------\n\n/// `^Num` (Type System ch. 3) over a type variable: the operators by name.\nnamespace Num {\ninline Nat add(const Nat& a, const Nat& b) { return a + b; }\ninline Nat sub(const Nat& a, const Nat& b) { return a.checked_sub(b).value_or(Nat(0u)); }\ninline Nat mul(const Nat& a, const Nat& b) { return a * b; }\ninline std::optional<Nat> div_opt(const Nat& a, const Nat& b) { return a.div(b); }\ninline std::optional<Nat> sub_opt(const Nat& a, const Nat& b) { return a.checked_sub(b); }\ninline Int add(const Int& a, const Int& b) { return a + b; }\ninline Int sub(const Int& a, const Int& b) { return a - b; }\ninline Int mul(const Int& a, const Int& b) { return a * b; }\ninline std::optional<Int> div_opt(const Int& a, const Int& b) { return a.div(b); }\ninline double add(double a, double b) { return a + b; }\ninline double sub(double a, double b) { return a - b; }\ninline double mul(double a, double b) { return a * b; }\ninline std::optional<double> div_opt(double a, double b) { return a / b; }\ninline std::uint8_t add(std::uint8_t a, std::uint8_t b) { return std::uint8_t(a + b); }\ninline std::uint8_t sub(std::uint8_t a, std::uint8_t b) { return std::uint8_t(a - b); }\ninline std::uint8_t mul(std::uint8_t a, std::uint8_t b) { return std::uint8_t(a * b); }\ninline std::optional<std::uint8_t> div_opt(std::uint8_t a, std::uint8_t b) {\n    if (b == 0) return std::nullopt;\n    return std::uint8_t(a / b);\n}\ninline std::optional<std::uint8_t> add_opt(std::uint8_t a, std::uint8_t b) {\n    if (a + b > 255) return std::nullopt;\n    return std::uint8_t(a + b);\n}\ninline std::optional<std::uint8_t> sub_opt(std::uint8_t a, std::uint8_t b) {\n    if (b > a) return std::nullopt;\n    return std::uint8_t(a - b);\n}\ninline std::optional<std::uint8_t> mul_opt(std::uint8_t a, std::uint8_t b) {\n    if (a * b > 255) return std::nullopt;\n    return std::uint8_t(a * b);\n}\ntemplate <class A>\nstd::optional<A> add_opt(const A& a, const A& b) { return add(a, b); }\ntemplate <class A>\nstd::optional<A> sub_opt(const A& a, const A& b) { return sub(a, b); }\ntemplate <class A>\nstd::optional<A> mul_opt(const A& a, const A& b) { return mul(a, b); }\ntemplate <class A>\nA zero();\ntemplate <> inline Nat zero<Nat>() { return Nat(0u); }\ntemplate <> inline Int zero<Int>() { return Int(0); }\ntemplate <> inline double zero<double>() { return 0.0; }\ntemplate <> inline std::uint8_t zero<std::uint8_t>() { return 0; }\n}  // namespace Num\n\n/// A `Nat` as an index; one too large for memory indexes nothing.\ninline std::size_t ix(const Nat& n) {\n    auto i = n.as_int().to_i64();\n    return i ? std::size_t(*i) : std::size_t(-1);\n}\n\ninline Nat nat_of(std::size_t n) { return Nat::from_int(Int(std::int64_t(n))).value_or(Nat(0u)); }\n\n/// `Int: fn Nat -> Int`.\ninline Int int_(const Nat& n) { return n.as_int(); }\n\n/// `?Nat: fn Int -> ?Nat`.\ninline std::optional<Nat> nat(const Int& i) { return Nat::from_int(i); }\n\n/// `?U8: fn Int -> ?U8`.\ninline std::optional<std::uint8_t> u8_(const Int& i) {\n    auto n = i.to_i64();\n    if (!n || *n < 0 || *n > 255) return std::nullopt;\n    return std::uint8_t(*n);\n}\n\ntemplate <class A>\nstd::optional<A> div(const A& a, const A& b) { return Num::div_opt(a, b); }\n\ninline std::optional<Int> mod_(const Int& a, const Int& b) {\n    if (b == Int(0)) return std::nullopt;\n    return a.modulo(b);\n}\ninline std::optional<Nat> mod_(const Nat& a, const Nat& b) {\n    if (b == Nat(0u)) return std::nullopt;\n    return a.modulo(b);\n}\ninline std::optional<std::uint8_t> mod_(std::uint8_t a, std::uint8_t b) {\n    if (b == 0) return std::nullopt;\n    return std::uint8_t(a % b);\n}\n\ninline double float_(const Int& i) {\n    auto n = i.to_i64();\n    return n ? double(*n) : std::stod(i.to_string());\n}\ninline double to_float(const Int& i) { return float_(i); }\ninline double cos(double x) { return std::cos(x); }\ninline double sin(double x) { return std::sin(x); }\n\ntemplate <class A>\nA abs(const A& a) { return a < Num::zero<A>() ? Num::sub(Num::zero<A>(), a) : a; }\n\ntemplate <class A>\nA sum(const Array<A>& xs) {\n    A acc = Num::zero<A>();\n    for (const A& x : xs) acc = Num::add(acc, x);\n    return acc;\n}\n\ntemplate <class A>\nA max(const A& a, const A& b) { return a < b ? b : a; }\ntemplate <class A>\nA min(const A& a, const A& b) { return b < a ? b : a; }\n\n/// `Compare` of `^Ord`.\ntemplate <class A>\nOrdering compare(const A& a, const A& b) {\n    if (a < b) return Ordering::Less{};\n    if (b < a) return Ordering::Greater{};\n    return Ordering::Equal{};\n}\n\n// ---- Optionals --------------------------------------------------------------------------\n\n/// `Or: fn ?a, a -> a`.\ntemplate <class A, class D>\nA or_(const std::optional<A>& o, const D& d) { return o ? *o : A(d); }\n\n// ---- Arrays -----------------------------------------------------------------------------\n\ntemplate <class A>\nNat len(const Array<A>& xs) { return nat_of(xs.size()); }\ninline Nat len_text(const Text& t) { return nat_of(t.len()); }\ntemplate <class K, class V>\nNat len_map(const Map<K, V>& m) { return nat_of(m.size()); }\n\ntemplate <class A>\nArray<A> append(const Array<A>& a, const Array<A>& b) { return a.concat(b); }\ntemplate <class A>\nArray<A> push(const Array<A>& xs, const A& x) { return xs.pushed(x); }\n\ntemplate <class A, class B, class F>\nB fold(const Array<A>& xs, const B& init, const F& f) {\n    B acc = init;\n    for (const A& x : xs) acc = f(acc, x);\n    return acc;\n}\ntemplate <class K, class V, class B, class F>\nB fold_map(const Map<K, V>& m, const B& init, const F& f) {\n    B acc = init;\n    for (const auto& [k, v] : m) acc = f(acc, k, v);\n    return acc;\n}\ntemplate <class A, class F>\nauto each(const Array<A>& xs, const F& f) {\n    using B = std::decay_t<std::invoke_result_t<const F&, const A&>>;\n    std::vector<B> out;\n    out.reserve(xs.size());\n    for (const A& x : xs) out.push_back(f(x));\n    return Array<B>(std::move(out));\n}\ntemplate <class A, class F>\nArray<A> filter(const Array<A>& xs, const F& keep) {\n    std::vector<A> out;\n    for (const A& x : xs)\n        if (keep(x)) out.push_back(x);\n    return Array<A>(std::move(out));\n}\ninline Text concat(const Array<Text>& xs) {\n    std::size_t n = 0;\n    for (const Text& t : xs) n += t.len();\n    std::string s;\n    s.reserve(n);\n    for (const Text& t : xs) s += t.view();\n    return Text::of_utf8(std::move(s));\n}\n\n/// `xs[i]`.\ntemplate <class A>\nstd::optional<A> index(const Array<A>& xs, const Nat& i) {\n    if (auto x = xs.get(ix(i))) return *x;\n    return std::nullopt;\n}\n\n/// `&xs[i]` in an `&` block.\ntemplate <class A>\nA& at_mut(Array<A>& xs, const Nat& i) { return xs.mut_at(ix(i)); }\ntemplate <class K, class V>\nV& at_mut_map(Map<K, V>& m, const K& k) {\n    V* v = m.mut_get(k);\n    if (!v) panic(\"an `&` path to a key the map does not hold\");\n    return *v;\n}\n\n/// `&xs[i] <= v` in an `&` block: an array has no entry to remove.\ntemplate <class A>\nvoid set_index(Array<A>& xs, const Nat& i, std::optional<A> v) {\n    if (!v) panic(str(\"`&xs[\", i, \"] <= nil`: an array\'s entry cannot be removed\"));\n    xs.set(ix(i), std::move(*v));\n}\n/// `&m[k] <= v` in an `&` block: `? x` writes the key, `nil` removes it.\ntemplate <class K, class V>\nvoid set_key(Map<K, V>& m, const K& k, std::optional<V> v) {\n    if (v) m.insert(k, std::move(*v));\n    else m.remove(k);\n}\n\ntemplate <class A>\nArray<A> take(const Array<A>& xs, const Nat& n) { return xs.take(std::min(ix(n), xs.size())); }\ntemplate <class A>\nArray<A> drop(const Array<A>& xs, const Nat& n) { return xs.drop_front(std::min(ix(n), xs.size())); }\n\n// ---- Maps -------------------------------------------------------------------------------\n\ntemplate <class K, class V>\nMap<K, V> map_of(std::vector<std::tuple<K, V>> entries) {\n    Map<K, V> m;\n    for (auto& [k, v] : entries) m.insert(std::move(k), std::move(v));\n    return m;\n}\ntemplate <class K, class V>\nMap<K, V> insert(const Map<K, V>& m, const K& k, const V& v) { return m.inserted(k, v); }\ntemplate <class K, class V>\nMap<K, V> remove(const Map<K, V>& m, const K& k) { return m.removed(k); }\n/// `?Get`, and `m[k]`.\ntemplate <class K, class V>\nstd::optional<V> get(const Map<K, V>& m, const K& k) {\n    if (auto v = m.get(k)) return *v;\n    return std::nullopt;\n}\n/// `?First`.\ntemplate <class K, class V>\nstd::optional<std::tuple<K, V>> first(const Map<K, V>& m) {\n    if (m.empty()) return std::nullopt;\n    auto it = m.begin();\n    return std::tuple<K, V>(it->first, it->second);\n}\ntemplate <class K, class V>\nArray<K> keys(const Map<K, V>& m) {\n    std::vector<K> out;\n    for (const auto& [k, v] : m) out.push_back(k);\n    return Array<K>(std::move(out));\n}\ntemplate <class K, class V>\nArray<V> values(const Map<K, V>& m) {\n    std::vector<V> out;\n    for (const auto& [k, v] : m) out.push_back(v);\n    return Array<V>(std::move(out));\n}\ntemplate <class K, class V>\nNat size(const Map<K, V>& m) { return nat_of(m.size()); }\n/// A host\'s rows (`prism_rtl::Rows`, shared), as `Map::values` reads them.\ntemplate <class K, class V>\nArray<V> values(const prism_rtl::Rc<Map<K, V>>& m) { return values(*m); }\ntemplate <class K, class V>\nMap<K, V> map(const Array<std::tuple<K, V>>& entries) {\n    Map<K, V> m;\n    for (const auto& [k, v] : entries) m.insert(k, v);\n    return m;\n}\n/// `Union a, b`: `a`\'s entries over `b`\'s.\ntemplate <class K, class V>\nMap<K, V> union_(const Map<K, V>& a, const Map<K, V>& b) {\n    return a.united(b);\n}\ntemplate <class K, class V, class F>\nauto each_map(const Map<K, V>& m, const F& f) {\n    using B = std::decay_t<std::invoke_result_t<const F&, const K&, const V&>>;\n    std::vector<B> out;\n    for (const auto& [k, v] : m) out.push_back(f(k, v));\n    return Array<B>(std::move(out));\n}\ntemplate <class K, class V, class F>\nMap<K, V> filter_map(const Map<K, V>& m, const F& keep) {\n    Map<K, V> out;\n    for (const auto& [k, v] : m)\n        if (keep(k, v)) out.insert(k, v);\n    return out;\n}\n\n// ---- Text -------------------------------------------------------------------------------\n\n/// `Text: fn Char -> Text`: the character as a one-character text, its UTF-8.\ninline Text text(char32_t c) {\n    std::string s;\n    prism_rtl::utf8_push(s, c);\n    return Text::of_utf8(std::move(s));\n}\n/// `Upper`, `Lower`: Unicode\'s default full case mapping, as Rust\'s `str::to_uppercase`\n/// and `to_lowercase` (runtime/cpp/README.md, \"Upper and Lower\").\ninline Text upper(const Text& t) { return text_upper(t); }\ninline Text lower(const Text& t) { return text_lower(t); }\n\n/// `SplitOn t, sep`: the pieces between the separators (not in Appendix B, whose `Split`\n/// is a regular expression\'s). An empty separator is refused.\ninline Array<Text> split_on(const Text& t, const Text& sep) {\n    if (sep.is_empty()) panic(\"`SplitOn` with an empty separator: walk the text\'s characters with a cursor (`Front`, `?Step`)\");\n    return Array<Text>(t.split(sep.view()));\n}\n\n/// `Front: fn Text -> Cursor`.\ninline Cursor front(const Text& t) { return Cursor::front(t); }\n/// `Back: fn Text -> Cursor`.\ninline Cursor back(const Text& t) { return Cursor::back(t); }\n/// `?Step: fn Cursor -> ?((Char, Cursor))`.\ninline std::optional<std::tuple<char32_t, Cursor>> step(const Cursor& c) {\n    auto s = c.step();\n    if (!s) return std::nullopt;\n    return std::tuple<char32_t, Cursor>(s->first, std::move(s->second));\n}\n/// `?StepBack: fn Cursor -> ?((Char, Cursor))`.\ninline std::optional<std::tuple<char32_t, Cursor>> step_back(const Cursor& c) {\n    auto s = c.step_back();\n    if (!s) return std::nullopt;\n    return std::tuple<char32_t, Cursor>(s->first, std::move(s->second));\n}\n/// `Before: fn Cursor -> Text`.\ninline Text before(const Cursor& c) { return c.before(); }\n/// `After: fn Cursor -> Text`.\ninline Text after(const Cursor& c) { return c.after(); }\n/// `At: fn Cursor -> Nat`.\ninline Nat at(const Cursor& c) { return nat_of(c.at()); }\n/// `?CursorAt: fn Text, Nat -> ?Cursor`.\ninline std::optional<Cursor> cursor_at(const Text& t, const Nat& n) { return Cursor::at_byte(t, ix(n)); }\n\n// ---- Regular expressions (Appendix B; claude/regex-dialect.md) --------------------------\n// A literal is built where it stands (`Regex::lit`, a function-local static per literal);\n// these are the prelude\'s functions over prism_rtl\'s regex.hpp, each the runtime\'s search.\n// `Group` and `Match` are the runtime\'s records, seen through `using namespace prism_rtl`.\n\n/// `?Regex: fn Text -> ?Regex`: the text as a pattern with no flags, none outside the\n/// dialect; linear in the text.\ninline std::optional<Regex> regex(const Text& t) { return Regex::parse(t); }\n/// `?Match: fn Regex, Cursor -> ?Match`: the match that starts at the cursor, seeing the\n/// whole text before it.\ninline std::optional<Match> match_(const Regex& r, const Cursor& c) { return r.match_at(c); }\n/// `?Find: fn Regex, Text -> ?Match`: the leftmost-first match.\ninline std::optional<Match> find(const Regex& r, const Text& t) { return r.find(t); }\n/// `Matches: fn Regex, Text -> [Match]`: every match, by the iteration rule.\ninline Array<Match> matches(const Regex& r, const Text& t) { return r.matches(t); }\n/// `Replace: fn RegexReplacement, Text -> Text`: every match replaced.\ninline Text replace(const RegexReplacement& r, const Text& t) { return r.replace(t); }\n/// `Split: fn Regex, Text -> [Text]`: the `k + 1` views between the `k` matches.\ninline Array<Text> split(const Regex& r, const Text& t) { return r.split(t); }\n\n/// `?ParseNat`.\ninline std::optional<Nat> parse_nat_opt(const Text& t) {\n    std::string_view s = t.view();\n    if (s.empty() || !std::all_of(s.begin(), s.end(), [](char c) { return c >= \'0\' && c <= \'9\'; })) return std::nullopt;\n    return Nat::from_int(*Int::parse(s));\n}\n\n/// `~ParseNat`.\ninline Fallible<Nat> parse_nat_try(const Text& t) {\n    if (auto n = parse_nat_opt(t)) return *n;\n    return unexpected(Error(\"Prelude.NotANumber\", Text(str(\"not a number: \", t))));\n}\n\n/// `Buffer.Numbered n`: `0` to `n - 1`, linear.\ninline Array<Nat> numbered(const Nat& n) {\n    std::vector<Nat> out;\n    for (std::size_t i = 0; i < ix(n); ++i) out.push_back(nat_of(i));\n    return Array<Nat>(std::move(out));\n}\n\n/// `Freeze`: a `Buffer` is an array already.\ntemplate <class A>\nA freeze(const A& a) { return a; }\n\n/// A code template\'s placeholder (Templates ch. 2): alone on its line, its text\'s lines\n/// indented to its column, a final newline dropped, an empty text no line; sharing a line,\n/// the text as it is.\ninline void place(std::string& out, const Text& text, std::optional<std::size_t> column) {\n    std::string_view t = text.view();\n    if (!column) {\n        out += t;\n        return;\n    }\n    if (!t.empty() && t.back() == \'\\n\') t.remove_suffix(1);\n    if (t.empty()) return;\n    std::size_t from = 0;\n    while (true) {\n        std::size_t at = t.find(\'\\n\', from);\n        std::string_view l = t.substr(from, at == std::string_view::npos ? std::string_view::npos : at - from);\n        if (!l.empty()) out.append(*column, \' \');\n        out += l;\n        out += \'\\n\';\n        if (at == std::string_view::npos) break;\n        from = at + 1;\n    }\n}\n\n/// An array as the map from each index to its entry, for a `for` over an array.\ntemplate <class A>\nMap<Nat, A> indexed(const Array<A>& xs) {\n    Map<Nat, A> m;\n    std::size_t i = 0;\n    for (const A& x : xs) m.insert(nat_of(i++), x);\n    return m;\n}\n\n/// The heights a node with combinators at several heights asked for this tick: its wake\n/// runs the lowest one asked (`Node::wake` is not told its height, prismc/README.md WH).\nclass Wakes {\npublic:\n    void ask(std::uint32_t h) { asked_.insert(h); }\n    std::uint32_t next() {\n        if (asked_.empty()) return std::uint32_t(-1);\n        std::uint32_t h = *asked_.begin();\n        asked_.erase(asked_.begin());\n        return h;\n    }\n\nprivate:\n    std::set<std::uint32_t> asked_;\n};\n\n// ---- Jobs -------------------------------------------------------------------------------\n\n/// A frame of a job\'s stack (D6; claude/backend.md, \"Unbounded functions and `@Run`\"): the\n/// caller of `callee`, a call of an unbounded function that was not in tail position,\n/// waiting for its result. A continuation runs once.\ntemplate <class A, class B>\nstruct Frame : Job<B> {\n    JobRef<A> callee;\n    std::function<Turn<B>(A)> then;\n    Frame(JobRef<A> callee, std::function<Turn<B>(A)> then) : callee(std::move(callee)), then(std::move(then)) {}\n    Turn<B> cycle() const override {\n        Turn<A> t = callee->cycle();\n        if (auto m = t.if_more()) return Turn<B>::more(prism_rtl::make_rc<Frame<A, B>>(m->next, then));\n        return then(std::move(std::get<typename Turn<A>::Finished>(t.v).value));\n    }\n};\n\n/// A call that is not in tail position: a cycle point, with `then` the continuation.\ntemplate <class A, class F>\nauto call_then(JobRef<A> callee, F then) {\n    using T = std::invoke_result_t<F, A>;\n    using B = typename T::Value;\n    return Turn<B>::more(prism_rtl::make_rc<Frame<A, B>>(std::move(callee), std::move(then)));\n}\n\n/// A call through an unbounded function value that is not in tail position: the value\'s\n/// job runs its first cycle now.\ntemplate <class A, class F>\nauto call_value(JobRef<A> callee, F then) {\n    using T = std::invoke_result_t<F, A>;\n    using B = typename T::Value;\n    return Frame<A, B>(std::move(callee), std::move(then)).cycle();\n}\n\n/// A named unbounded function\'s job as its value gives it: entering it is a cycle point.\ntemplate <class B>\nstruct Entered : Job<B> {\n    JobRef<B> job;\n    explicit Entered(JobRef<B> job) : job(std::move(job)) {}\n    Turn<B> cycle() const override { return Turn<B>::more(job); }\n};\ntemplate <class B>\nJobRef<B> entered(JobRef<B> job) { return prism_rtl::make_rc<Entered<B>>(std::move(job)); }\n\n/// A `while` in an `update` block of an unbounded function as a job (D6): each turn is a\n/// cycle; `step` answers the next state, or a failure when the condition fails.\ntemplate <class S>\nstruct Looping : Job<S> {\n    S state;\n    prism_rtl::Rc<const std::function<Expected<S, S>(S)>> step;\n    Looping(S state, prism_rtl::Rc<const std::function<Expected<S, S>(S)>> step) : state(std::move(state)), step(std::move(step)) {}\n    Turn<S> cycle() const override {\n        Expected<S, S> r = (*step)(state);\n        if (r) return Turn<S>::more(prism_rtl::make_rc<Looping<S>>(std::move(r).value(), step));\n        return Turn<S>::finished(r.error());\n    }\n};\ntemplate <class S, class F>\nJobRef<S> loop_job(S state, F step) {\n    return prism_rtl::make_rc<Looping<S>>(std::move(state), prism_rtl::make_rc<const std::function<Expected<S, S>(S)>>(std::move(step)));\n}\n\n/// A `while` whose body holds a cycle-point loop of its own (D6): a turn is a job.\ntemplate <class S>\nstruct LoopingTurns : Job<S> {\n    S state;\n    prism_rtl::Rc<const std::function<Turn<Expected<S, S>>(S)>> step;\n    LoopingTurns(S state, prism_rtl::Rc<const std::function<Turn<Expected<S, S>>(S)>> step) : state(std::move(state)), step(std::move(step)) {}\n    Turn<S> cycle() const override {\n        auto st = step;\n        std::function<Turn<S>(Expected<S, S>)> again = [st](Expected<S, S> r) -> Turn<S> {\n            if (r) return Turn<S>::more(prism_rtl::make_rc<LoopingTurns<S>>(std::move(r).value(), st));\n            return Turn<S>::finished(r.error());\n        };\n        Turn<Expected<S, S>> t = (*step)(state);\n        if (auto m = t.if_more()) return Turn<S>::more(prism_rtl::make_rc<Frame<Expected<S, S>, S>>(m->next, again));\n        return again(t.if_finished()->value);\n    }\n};\ntemplate <class S, class F>\nJobRef<S> loop_turns(S state, F step) {\n    return prism_rtl::make_rc<LoopingTurns<S>>(std::move(state), prism_rtl::make_rc<const std::function<Turn<Expected<S, S>>(S)>>(std::move(step)));\n}\n\n\n/// The job of a lambda of unbounded type: its body, run as a job body from its first\n/// cycle (prismc/README.md, pick JB).\ntemplate <class B>\nstruct Once : Job<B> {\n    std::function<Turn<B>()> body;\n    explicit Once(std::function<Turn<B>()> body) : body(std::move(body)) {}\n    Turn<B> cycle() const override { return body(); }\n};\ntemplate <class F>\nauto once_job(F body) {\n    using B = typename std::invoke_result_t<F>::Value;\n    return JobRef<B>(prism_rtl::make_rc<Once<B>>(std::move(body)));\n}\n\n/// A job\'s result, mapped: `g` runs in the cycle the job finishes.\ntemplate <class B, class G>\nauto map_job(JobRef<B> job, G g) {\n    using C = std::decay_t<std::invoke_result_t<G, B>>;\n    return JobRef<C>(prism_rtl::make_rc<Frame<B, C>>(std::move(job), [g](B b) { return Turn<C>::finished(g(std::move(b))); }));\n}\n\n/// A `for` of an `update` block whose body holds a cycle-point loop (D6, gap LP): a loop\n/// over its entries as `loop_turns` is over its condition, taking the next entry its\n/// test; `step` takes the block\'s state and an entry\'s parts, a turn a job.\ntemplate <class S, class E, class F>\nJobRef<S> for_turns(std::vector<E> entries, S state, F step) {\n    using P = std::pair<S, std::size_t>;\n    auto all = prism_rtl::make_rc<const std::vector<E>>(std::move(entries));\n    auto st = prism_rtl::make_rc<const F>(std::move(step));\n    JobRef<P> job = loop_turns(P(std::move(state), 0), [all, st](P p) -> Turn<Expected<P, P>> {\n        std::size_t i = p.second;\n        if (i >= all->size()) return Turn<Expected<P, P>>::finished(Expected<P, P>(unexpected(std::move(p))));\n        Turn<S> t = std::apply([&](const auto&... parts) { return (*st)(std::move(p.first), parts...); }, (*all)[i]);\n        if (auto m = t.if_more()) return call_then(m->next, [i](S s2) { return Turn<Expected<P, P>>::finished(Expected<P, P>(P(std::move(s2), i + 1))); });\n        return Turn<Expected<P, P>>::finished(Expected<P, P>(P(std::move(t.if_finished()->value), i + 1)));\n    });\n    return map_job(job, [](P p) { return std::move(p.first); });\n}\n\n/// `for` over a map in a job (`for_turns`): the key and the entry, in key order.\ntemplate <class K, class V, class S, class F>\nJobRef<S> for_turns_keyed(Map<K, V> m, S state, F step) {\n    std::vector<std::pair<K, V>> entries;\n    for (auto&& [k, v] : m) entries.emplace_back(k, v);\n    return for_turns(std::move(entries), std::move(state), std::move(step));\n}\n\n/// `for` over an array in a job (`for_turns`): the index and the entry.\ntemplate <class V, class S, class F>\nJobRef<S> for_turns_indexed(Array<V> xs, S state, F step) {\n    std::vector<std::pair<Nat, V>> entries;\n    for (auto&& [i, v] : prism_rtl::enumerate(xs)) entries.emplace_back(nat_of(i), v);\n    return for_turns(std::move(entries), std::move(state), std::move(step));\n}\n\n// ---- The higher-order functions as jobs (D8) ---------------------------------------------\n\ntemplate <class A, class B, class F>\nTurn<B> fold_from(Array<A> xs, std::size_t i, B acc, F f) {\n    auto x = xs.get(i);\n    if (!x) return Turn<B>::finished(std::move(acc));\n    A item = *x;\n    return call_value(f(std::tuple<B, A>(std::move(acc), std::move(item))), [xs, i, f](B b) { return fold_from(xs, i + 1, std::move(b), f); });\n}\ntemplate <class A, class B, class F>\nJobRef<B> fold_job(Array<A> xs, B init, F f) {\n    return once_job([xs, init, f]() { return fold_from(xs, 0, init, f); });\n}\ntemplate <class K, class V>\nArray<std::tuple<K, V>> pairs_of(const Map<K, V>& m) {\n    std::vector<std::tuple<K, V>> out;\n    for (const auto& [k, v] : m) out.emplace_back(k, v);\n    return Array<std::tuple<K, V>>(std::move(out));\n}\ntemplate <class K, class V, class B, class F>\nJobRef<B> fold_map_job(Map<K, V> m, B init, F f) {\n    return fold_job(pairs_of(m), std::move(init), [f](std::tuple<B, std::tuple<K, V>> p) {\n        auto& [acc, kv] = p;\n        return f(std::tuple<B, K, V>(acc, std::get<0>(kv), std::get<1>(kv)));\n    });\n}\ntemplate <class A, class F>\nauto each_job(Array<A> xs, F f) {\n    using B = typename std::invoke_result_t<F, A>::element_type::Value;\n    return fold_job(std::move(xs), Array<B>(), [f](std::tuple<Array<B>, A> p) {\n        auto acc = std::get<0>(p);\n        return map_job(f(std::get<1>(p)), [acc](B b) { return acc.pushed(std::move(b)); });\n    });\n}\ntemplate <class K, class V, class F>\nauto each_map_job(Map<K, V> m, F f) {\n    return each_job(pairs_of(m), std::move(f));\n}\ntemplate <class A, class F>\nJobRef<Array<A>> filter_job(Array<A> xs, F keep) {\n    return fold_job(std::move(xs), Array<A>(), [keep](std::tuple<Array<A>, A> p) {\n        auto acc = std::get<0>(p);\n        auto x = std::get<1>(p);\n        return map_job(keep(x), [acc, x](bool k) { return k ? acc.pushed(x) : acc; });\n    });\n}\ntemplate <class K, class V, class F>\nJobRef<Map<K, V>> filter_map_job(Map<K, V> m, F keep) {\n    return fold_job(pairs_of(m), Map<K, V>(), [keep](std::tuple<Map<K, V>, std::tuple<K, V>> p) {\n        auto acc = std::get<0>(p);\n        auto kv = std::get<1>(p);\n        return map_job(keep(kv), [acc, kv](bool k) { return k ? acc.inserted(std::get<0>(kv), std::get<1>(kv)) : acc; });\n    });\n}\n\n/// A job run to its result inside the cycle: a call of an unbounded function value from\n/// direct-style code (gap DS of prismc/README.md).\ntemplate <class B>\nB run_to_end(JobRef<B> job) {\n    while (true) {\n        Turn<B> t = job->cycle();\n        if (auto m = t.if_more()) job = m->next;\n        else return std::move(std::get<typename Turn<B>::Finished>(t.v).value);\n    }\n}\n\n// ---- Running ----------------------------------------------------------------------------\n\n/// `--world NAME` as the first argument: the World, and the arguments without the option.\ninline std::pair<std::string, std::vector<std::string>> world_option(const std::vector<std::string>& args, const std::string& fallback) {\n    if (args.size() > 1 && args[0] == \"--world\") return {args[1], std::vector<std::string>(args.begin() + 2, args.end())};\n    if (!args.empty() && args[0].rfind(\"--world=\", 0) == 0) return {args[0].substr(8), std::vector<std::string>(args.begin() + 1, args.end())};\n    return {fallback, args};\n}\n\ninline std::optional<std::string> read_file(const std::string& path) {\n    std::ifstream f(path, std::ios::binary);\n    if (!f) return std::nullopt;\n    std::stringstream s;\n    s << f.rdbuf();\n    return s.str();\n}\n\n/// `test`: each script under the Test World. With `--print` the transcripts go to standard\n/// output as they are; otherwise each is compared byte for byte with the `.expected` beside\n/// it (`tests.expected` for the test module `tests.prism`), and `ok` or the\n/// difference is printed.\ninline int run_scripts(const TestWorld& world, const std::vector<std::string>& given, const std::vector<std::string>& compiled) {\n    bool print = std::find(given.begin(), given.end(), \"--print\") != given.end();\n    std::vector<std::string> paths;\n    for (const auto& a : given)\n        if (a != \"--print\") paths.push_back(a);\n    if (paths.empty()) paths = compiled;\n    int code = 0;\n    for (const auto& path : paths) {\n        auto script = read_file(path);\n        if (!script) {\n            std::fprintf(stderr, \"%s: cannot read the script\\n\", path.c_str());\n            code = 2;\n            continue;\n        }\n        // a test module\'s transcript is beside it, its `.prism` dropped\n        std::string stem = path.size() > 6 && path.substr(path.size() - 6) == \".prism\" ? path.substr(0, path.size() - 6) : path;\n        auto expected = print ? std::nullopt : read_file(stem + \".expected\");\n        if (!expected) {\n            Report report = world.run(*script);\n            std::fwrite(report.transcript.data(), 1, report.transcript.size(), stdout);\n            for (const auto& f : report.failures) std::fprintf(stderr, \"%s: %s\\n\", path.c_str(), f.c_str());\n            code = std::max(code, int(report.exit_code));\n            continue;\n        }\n        auto verdict = world.verify(*script, *expected);\n        if (verdict) std::printf(\"ok %s\\n\", path.c_str());\n        else {\n            std::printf(\"FAILED %s: %s\\n\", path.c_str(), verdict.error().c_str());\n            code = 1;\n        }\n    }\n    std::fflush(stdout);\n    return code;\n}\n\n/// Run on a thread with a large stack (4 GB, committed as it is used): unbounded code runs\n/// direct-style within a cycle (doubt DS of prismc/README.md), and a C++ frame of the\n/// emitted code is larger than Rust\'s, whose runner takes 1 GB.\ninline int on_big_stack(std::function<int()> f) {\n    struct Job {\n        std::function<int()> f;\n        int code = 1;\n    } job{std::move(f)};\n    pthread_attr_t attr;\n    pthread_attr_init(&attr);\n    pthread_attr_setstacksize(&attr, std::size_t(4) << 30);\n    pthread_t t;\n    auto run = [](void* p) -> void* {\n        auto* j = static_cast<Job*>(p);\n        j->code = j->f();\n        return nullptr;\n    };\n    if (pthread_create(&t, &attr, run, &job) != 0) {\n        std::fprintf(stderr, \"prism: no thread with a 4 GB stack: running on the main thread\'s\\n\");\n        return job.f();\n    }\n    pthread_join(t, nullptr);\n    pthread_attr_destroy(&attr);\n    return job.code;\n}\n\n/// The root under the CLI World (`worlds/cli/cpp`).\ntemplate <class P>\nint run_cli(const std::vector<std::string>& args) { return prism_world_cli::run<P>(args); }\n\n}  // namespace prelude\n}  // namespace crate\n");
    return Text(out);
}


/// CppPreludeRows: fn Text -> Text
Text cpp_prelude_rows(const Text& unused) {
    auto out = std::string();
    out.append("/// A row of a `for` or a generation of a `rebuild`: a node its builder tears down. A row\n/// of a hosted child\'s (prismc/README.md, pick HO) is an entry of its host\'s document: its\n/// own places\' entries, by their paths relative to the row, and a host\'s typed answer to\n/// one of them.\nclass Row : public Node {\npublic:\n    virtual void leave_row(Cx& cx) = 0;\n    virtual std::vector<std::tuple<Path, prism_rtl::Rc<prism_rtl::Entry<Elem>>>> document(const Cx& cx) const {\n        static_cast<void>(cx);\n        return {};\n    }\n    virtual Done deliver(std::span<const Segment> at, const Answer& v, Cx& cx) {\n        static_cast<void>(v);\n        static_cast<void>(cx);\n        return unexpected(Fault::answer(str(\"no hosted place at \", path_of(at), \" to answer: the row is not hosted\")));\n    }\n};\n\n/// A row subscribing to its block\'s port for one event: the row heard weakly, the handle\n/// kept for its leaving (claude/backend.md: `Port::subscribe`).\ntemplate <class N, class P, class Port, class Call>\nvoid subscribe_row(const prism_rtl::Rc<N>& node, std::optional<prism_rtl::Rc<P>> parent, Port port, Call call, std::optional<Handle>& slot) {\n    if (!parent) return;\n    prism_rtl::Weak<N> me = node;\n    using T = typename std::remove_cvref_t<decltype(deref(port(*parent)))>::Value;\n    Handle h = deref(port(*parent)).subscribe([me, call](const T& v, Cx& cx) -> Done {\n        if (auto n = me.lock()) call(n, v, cx);\n        return {};\n    });\n    slot = h;\n}\n");
    return Text(out);
}

}  // namespace crate::emit::cpp::prelude
