// The module `Emit.Cpp`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <emit/cpp/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>

// The module `Emit.Cpp`, from `target/bootstrap/cpp-src/prismc/emit/cpp/mod.prism`.
namespace crate::emit::cpp {

Pod Cp::to_pod() const {
    return Pod::record("Cp", {{"home", prism_rtl::to_pod(home_p)}, {"mods", prism_rtl::to_pod(mods_p)}, {"types", prism_rtl::to_pod(types_p)}, {"ctors", prism_rtl::to_pod(ctors_p)}, {"members", prism_rtl::to_pod(members_p)}, {"methods", prism_rtl::to_pod(methods_p)}, {"fieldNames", prism_rtl::to_pod(field_names_p)}, {"fns", prism_rtl::to_pod(fns_p)}, {"fields", prism_rtl::to_pod(fields_p)}, {"pointers", prism_rtl::to_pod(pointers_p)}, {"owned", prism_rtl::to_pod(owned_p)}, {"moveCaptures", prism_rtl::to_pod(move_captures_p)}, {"localTypes", prism_rtl::to_pod(local_types_p)}});
}

Result<Cp> Cp::from_pod(const Pod& whole) {
    return Cp{.home_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "home")))), .mods_p = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "mods")))), .types_p = TRY(prism_rtl::from_pod<Map<Text, TyInfo>>(TRY(crate::prelude::field(whole, "types")))), .ctors_p = TRY(prism_rtl::from_pod<Map<Text, Text>>(TRY(crate::prelude::field(whole, "ctors")))), .members_p = TRY(prism_rtl::from_pod<Map<Text, bool>>(TRY(crate::prelude::field(whole, "members")))), .methods_p = TRY(prism_rtl::from_pod<Map<Text, bool>>(TRY(crate::prelude::field(whole, "methods")))), .field_names_p = TRY(prism_rtl::from_pod<Map<Text, bool>>(TRY(crate::prelude::field(whole, "fieldNames")))), .fns_p = TRY(prism_rtl::from_pod<Map<Text, bool>>(TRY(crate::prelude::field(whole, "fns")))), .fields_p = TRY(prism_rtl::from_pod<Map<Text, crate::lower::model::OutTy>>(TRY(crate::prelude::field(whole, "fields")))), .pointers_p = TRY(prism_rtl::from_pod<Map<Text, bool>>(TRY(crate::prelude::field(whole, "pointers")))), .owned_p = TRY(prism_rtl::from_pod<Map<Text, bool>>(TRY(crate::prelude::field(whole, "owned")))), .move_captures_p = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "moveCaptures")))), .local_types_p = TRY(prism_rtl::from_pod<Map<Text, crate::lower::model::OutTy>>(TRY(crate::prelude::field(whole, "localTypes"))))};
}


void TyInfo::show(Printer& p) const {
    p.record("TyInfo", {{"kind", kind_p}, {"fields", fields_p}, {"params", params_p}});
}

Pod TyInfo::to_pod() const {
    return Pod::record("TyInfo", {{"kind", prism_rtl::to_pod(kind_p)}, {"fields", prism_rtl::to_pod(fields_p)}, {"params", prism_rtl::to_pod(params_p)}});
}

Result<TyInfo> TyInfo::from_pod(const Pod& whole) {
    return TyInfo{.kind_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "kind")))), .fields_p = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "fields")))), .params_p = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "params"))))};
}


/// CppId: fn Text -> Text
Text cpp_id_f(const Text& n_p0) {
    return in_list_f(crate::lower::cpp_keywords_p(), n_p0)
        ? prism_rtl::cat(n_p0, "_")
        : n_p0;
}


/// FieldId: fn Text -> Text
Text field_id_f(const Text& f_p0) {
    return cpp_id_f(f_p0);
}


/// CppPathId: fn Text -> Text
Text cpp_path_id_f(const Text& p_p0) {
    return crate::syntax::lexer::chars::join_f(crate::prelude::each(crate::prelude::split_on(p_p0, Text::lit("::")), [&](const Text& s_p1) { return cpp_id_f(s_p1); }), Text::lit("::"));
}


/// InList: fn [Text], Text -> Bool
bool in_list_f(const Array<Text>& xs_p0, const Text& x_p1) {
    return crate::prelude::fold(xs_p0, false, [&](const bool& seen_p2, const Text& y_p3) { return prism_rtl::deref(seen_p2) || (y_p3 == x_p1); });
}


/// Absolute: fn Cp, Text -> Text
Text absolute_f(const Cp& cp_p0, const Text& p_p1) {
    auto q_p2 = crate::syntax::lexer::chars::drop_prefix_f(p_p1, Text::lit("crate::"));
    return crate::prelude::fold(cp_p0.mods_p, false, [&](const bool& f_p3, const Text& m_p4) { return prism_rtl::deref(f_p3) || crate::syntax::lexer::chars::has_prefix_f(q_p2, prism_rtl::cat(m_p4, "::")); })
        ? q_p2
        : prism_rtl::cat(cp_p0.home_p, "::", q_p2);
}


/// ?TypeOf: fn Cp, Text -> ?TyInfo
std::optional<TyInfo> type_of_o(const Cp& cp_p0, const Text& p_p1) {
    auto q_p2 = crate::syntax::lexer::chars::drop_prefix_f(p_p1, Text::lit("crate::"));
    auto&& _m = crate::prelude::get(cp_p0.types_p, absolute_f(cp_p0, q_p2));
    if (prism_rtl::is_some(_m)) {
        auto&& t_p3 = prism_rtl::some_of(_m);
        return std::optional(t_p3);
    }
    if (prism_rtl::is_none(_m)) {
        auto&& _m = crate::prelude::get(cp_p0.types_p, prism_rtl::cat("prelude::", q_p2));
        if (prism_rtl::is_some(_m)) {
            auto&& t_p4 = prism_rtl::some_of(_m);
            return std::optional(t_p4);
        }
        if (prism_rtl::is_none(_m)) {
            return crate::prelude::get(cp_p0.types_p, q_p2);
        }
        prism_rtl::unreachable("no arm matched");
    }
    prism_rtl::unreachable("no arm matched");
}


/// ?CaseOf: fn Cp, Text -> ?Text
std::optional<Text> case_of_o(const Cp& cp_p0, const Text& p_p1) {
    auto q_p2 = crate::syntax::lexer::chars::drop_prefix_f(p_p1, Text::lit("crate::"));
    auto&& _m = crate::prelude::get(cp_p0.ctors_p, absolute_f(cp_p0, q_p2));
    if (prism_rtl::is_some(_m)) {
        return std::optional(parent_path_f(p_p1));
    }
    if (prism_rtl::is_none(_m)) {
        auto&& _m = crate::prelude::get(cp_p0.ctors_p, prism_rtl::cat("prelude::", q_p2));
        if (prism_rtl::is_some(_m)) {
            return std::optional(parent_path_f(p_p1));
        }
        if (prism_rtl::is_none(_m)) {
            auto&& _m = crate::prelude::get(cp_p0.ctors_p, q_p2);
            if (prism_rtl::is_some(_m)) {
                return std::optional(parent_path_f(p_p1));
            }
            if (prism_rtl::is_none(_m)) {
                return std::optional<Text>{};
            }
            prism_rtl::unreachable("no arm matched");
        }
        prism_rtl::unreachable("no arm matched");
    }
    prism_rtl::unreachable("no arm matched");
}


/// ParentPath: fn Text -> Text
Text parent_path_f(const Text& p_p0) {
    auto segs_p1 = crate::prelude::split_on(p_p0, Text::lit("::"));
    return crate::syntax::lexer::chars::join_f(crate::prelude::take(segs_p1, crate::syntax::lexer::chars::dec_f(crate::prelude::len(segs_p1))), Text::lit("::"));
}


/// LastSegment: fn Text -> Text
Text last_segment_f(const Text& p_p0) {
    return crate::prelude::or_(crate::syntax::lexer::chars::last_o(crate::prelude::split_on(p_p0, Text::lit("::"))), p_p0);
}


/// Context: fn Model -> Cp
Cp context_f(const crate::lower::model::Model& model_p0) {
    auto names_p1 = crate::prelude::each(model_p0.mods_p, [&](const crate::lower::model::ModDef& m_p6) { return prism_rtl::deref(m_p6).name_p; });
    auto tops_p2 = crate::prelude::fold(names_p1, Array<Text>{}, [&](const Array<Text>& acc_p7, const Text& n_p8) {
        return ({
            auto top_p9 = crate::prelude::or_(crate::prelude::index(crate::prelude::split_on(n_p8, Text::lit("::")), Nat(0u)), n_p8);
            in_list_f(names_p1, top_p9) || in_list_f(acc_p7, top_p9)
            ? acc_p7
            : crate::prelude::push(acc_p7, top_p9);
        });
    });
    auto mods_p3 = crate::prelude::push(crate::prelude::append(names_p1, tops_p2), Text::lit("prelude"));
    auto base_p4 = Cp{.home_p = Text::lit(""), .mods_p = mods_p3, .types_p = prelude_types_p(), .ctors_p = prelude_ctors_p(), .members_p = node_base_p(), .methods_p = Map<Text, bool>{}, .field_names_p = Map<Text, bool>{}, .fns_p = Map<Text, bool>{}, .fields_p = Map<Text, crate::lower::model::OutTy>{}, .pointers_p = Map<Text, bool>{}, .owned_p = Map<Text, bool>{}, .move_captures_p = Array<Text>{}, .local_types_p = Map<Text, crate::lower::model::OutTy>{}};
    auto with_elem_p5 = add_row_f(add_answer_f(base_p4, model_p0.answer_p), Text::lit(""), model_p0.elem_p);
    return crate::prelude::fold(model_p0.mods_p, with_elem_p5, [&](const Cp& cp_pa, const crate::lower::model::ModDef& m_pb) { return crate::prelude::fold(prism_rtl::deref(m_pb).items_p, cp_pa, [&](const Cp& c_pc, const crate::lower::model::Item& it_pd) { return add_model_item_f(c_pc, prism_rtl::deref(m_pb).name_p, it_pd); }); });
}


/// let preludeTypes
Map<Text, TyInfo> prelude_types_p() {
    return crate::prelude::map_of(std::vector{std::tuple{Text::lit("prelude::Ordering"), TyInfo{.kind_p = Text::lit("choice"), .fields_p = Array<Text>{}, .params_p = Array<Text>{}}}, std::tuple{Text::lit("prelude::Span"), TyInfo{.kind_p = Text::lit("record"), .fields_p = Array(std::vector{Text::lit("file_p"), Text::lit("line_p"), Text::lit("column_p"), Text::lit("binding_p")}), .params_p = Array<Text>{}}}, std::tuple{Text::lit("prelude::Exception"), TyInfo{.kind_p = Text::lit("record"), .fields_p = Array(std::vector{Text::lit("kind_p"), Text::lit("message_p"), Text::lit("spans_p"), Text::lit("path_o")}), .params_p = Array<Text>{}}}, std::tuple{Text::lit("prelude::Duration"), TyInfo{.kind_p = Text::lit("newtype"), .fields_p = Array<Text>{}, .params_p = Array<Text>{}}}, std::tuple{Text::lit("prelude::PreludeUnwrap"), TyInfo{.kind_p = Text::lit("tag"), .fields_p = Array<Text>{}, .params_p = Array<Text>{}}}, std::tuple{Text::lit("prelude::PreludeExceptions"), TyInfo{.kind_p = Text::lit("tag"), .fields_p = Array<Text>{}, .params_p = Array<Text>{}}}});
}


/// let preludeCtors
Map<Text, Text> prelude_ctors_p() {
    return crate::prelude::map_of(std::vector{std::tuple{Text::lit("prelude::Ordering::Less"), Text::lit("choice")}, std::tuple{Text::lit("prelude::Ordering::Equal"), Text::lit("choice")}, std::tuple{Text::lit("prelude::Ordering::Greater"), Text::lit("choice")}});
}


/// let nodeBase
Map<Text, bool> node_base_p() {
    return crate::prelude::map_of(std::vector{std::tuple{Text::lit("make"), true}, std::tuple{Text::lit("push"), true}, std::tuple{Text::lit("wake"), true}, std::tuple{Text::lit("started"), true}, std::tuple{Text::lit("deferred"), true}, std::tuple{Text::lit("build"), true}, std::tuple{Text::lit("swap"), true}, std::tuple{Text::lit("leave"), true}, std::tuple{Text::lit("patch"), true}, std::tuple{Text::lit("edges"), true}, std::tuple{Text::lit("release"), true}, std::tuple{Text::lit("clean_up"), true}, std::tuple{Text::lit("path"), true}, std::tuple{Text::lit("leave_row"), true}, std::tuple{Text::lit("answer"), true}, std::tuple{Text::lit("document"), true}, std::tuple{Text::lit("entries"), true}, std::tuple{Text::lit("deliver"), true}, std::tuple{Text::lit("document_moved"), true}, std::tuple{Text::lit("me"), true}, std::tuple{Text::lit("result_dynamic"), true}});
}


/// AddModelItem: fn Cp, Text, Item -> Cp
Cp add_model_item_f(const Cp& cp_p0, const Text& m_p1, const crate::lower::model::Item& it_p2) {
    if (prism_rtl::is<crate::lower::model::Item::ItType>(it_p2)) {
        auto&& t_p3 = prism_rtl::as<crate::lower::model::Item::ItType>(it_p2).a0;
        return add_type_f(cp_p0, m_p1, t_p3);
    }
    if (prism_rtl::is<crate::lower::model::Item::ItTag>(it_p2)) {
        auto&& t_p4 = prism_rtl::as<crate::lower::model::Item::ItTag>(it_p2).a0;
        return add_ty_f(cp_p0, prism_rtl::cat(m_p1, "::", prism_rtl::deref(t_p4).name_p), TyInfo{.kind_p = Text::lit("tag"), .fields_p = crate::prelude::each(prism_rtl::deref(t_p4).fields_p, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
            auto&& f_p5 = std::get<1>(_p0);
            return f_p5;
        }), .params_p = Array<Text>{}});
    }
    if (prism_rtl::is<crate::lower::model::Item::ItRow>(it_p2)) {
        auto&& r_p6 = prism_rtl::as<crate::lower::model::Item::ItRow>(it_p2).a0;
        return add_row_f(cp_p0, m_p1, r_p6);
    }
    if (prism_rtl::is<crate::lower::model::Item::ItJob>(it_p2)) {
        auto&& j_p7 = prism_rtl::as<crate::lower::model::Item::ItJob>(it_p2).a0;
        return add_ty_f(cp_p0, prism_rtl::cat(m_p1, "::", prism_rtl::deref(j_p7).name_p), TyInfo{.kind_p = Text::lit("job"), .fields_p = crate::prelude::each(prism_rtl::deref(j_p7).fields_p, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
            auto&& f_p8 = std::get<0>(_p0);
            return f_p8;
        }), .params_p = crate::prelude::each(prism_rtl::deref(j_p7).generics_p, [&](const std::tuple<Text, Array<Text>>& _p0) {
            auto&& g_p9 = std::get<0>(_p0);
            return g_p9;
        })});
    }
    if (prism_rtl::is<crate::lower::model::Item::ItNode>(it_p2)) {
        auto&& n_pa = prism_rtl::as<crate::lower::model::Item::ItNode>(it_p2).a0;
        return add_node_f(cp_p0, m_p1, n_pa);
    }
    if (prism_rtl::is<crate::lower::model::Item::ItFn>(it_p2)) {
        auto&& f_pb = prism_rtl::as<crate::lower::model::Item::ItFn>(it_p2).a0;
        Cp this_ = cp_p0;
        this_.fns_p = crate::prelude::insert(this_.fns_p, prism_rtl::cat(m_p1, "::", prism_rtl::deref(f_pb).name_p), true);
        return this_;
    }
    {
        return cp_p0;
    }
}


/// AddTy: fn Cp, Text, TyInfo -> Cp
Cp add_ty_f(const Cp& cp_p0, const Text& path_p1, const TyInfo& info_p2) {
    Cp this_ = cp_p0;
    this_.types_p = crate::prelude::insert(this_.types_p, path_p1, info_p2);
    return this_;
}


/// AddCtor: fn Cp, Text, Text -> Cp
Cp add_ctor_f(const Cp& cp_p0, const Text& path_p1, const Text& kind_p2) {
    Cp this_ = cp_p0;
    this_.ctors_p = crate::prelude::insert(this_.ctors_p, path_p1, kind_p2);
    return this_;
}


/// AddMember: fn Cp, Text -> Cp
Cp add_member_f(const Cp& cp_p0, const Text& name_p1) {
    Cp this_ = cp_p0;
    this_.members_p = crate::prelude::insert(this_.members_p, name_p1, true);
    return this_;
}


/// AddType: fn Cp, Text, TyDef -> Cp
Cp add_type_f(const Cp& cp_p0, const Text& m_p1, const crate::lower::model::TyDef& t_p2) {
    auto path_p3 = prism_rtl::cat(m_p1, "::", t_p2.name_p);
    auto first_p4 = crate::prelude::or_(crate::prelude::index(t_p2.cases_p, Nat(0u)), crate::lower::model::CaseDef{.name_p = Text::lit(""), .prism_p = Text::lit(""), .fields_p = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .labels_p = Array<Text>{}});
    auto&& _m = t_p2.shape_p;
    if (prism_rtl::is<crate::lower::model::TyShape::ShapeRecord>(_m)) {
        return add_ty_f(cp_p0, path_p3, TyInfo{.kind_p = Text::lit("record"), .fields_p = crate::prelude::each(prism_rtl::deref(first_p4).fields_p, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
            auto&& f_p5 = std::get<0>(_p0);
            return f_p5;
        }), .params_p = t_p2.params_p});
    }
    if (prism_rtl::is<crate::lower::model::TyShape::ShapeNewtype>(_m)) {
        return add_ty_f(cp_p0, path_p3, TyInfo{.kind_p = Text::lit("newtype"), .fields_p = Array<Text>{}, .params_p = t_p2.params_p});
    }
    if (prism_rtl::is<crate::lower::model::TyShape::ShapeUnit>(_m)) {
        return add_ty_f(cp_p0, path_p3, TyInfo{.kind_p = Text::lit("unit"), .fields_p = Array<Text>{}, .params_p = t_p2.params_p});
    }
    if (prism_rtl::is<crate::lower::model::TyShape::ShapeChoice>(_m)) {
        return crate::prelude::fold(t_p2.cases_p, add_ty_f(cp_p0, path_p3, TyInfo{.kind_p = Text::lit("choice"), .fields_p = Array<Text>{}, .params_p = t_p2.params_p}), [&](const Cp& c_p6, const crate::lower::model::CaseDef& k_p7) { return add_ctor_f(c_p6, prism_rtl::cat(path_p3, "::", prism_rtl::deref(k_p7).name_p), Text::lit("choice")); });
    }
    prism_rtl::unreachable("no arm matched");
}


/// AddRow: fn Cp, Text, RowDef -> Cp
Cp add_row_f(const Cp& cp_p0, const Text& m_p1, const crate::lower::model::RowDef& r_p2) {
    auto path_p3 = m_p1 == Text::lit("")
        ? r_p2.name_p
        : prism_rtl::cat(m_p1, "::", r_p2.name_p);
    return crate::prelude::fold(r_p2.cases_p, add_ty_f(cp_p0, path_p3, TyInfo{.kind_p = Text::lit("choice"), .fields_p = Array<Text>{}, .params_p = Array<Text>{}}), [&](const Cp& c_p4, const std::tuple<Text, Text>& _p1) {
        auto&& v_p5 = std::get<0>(_p1);
        return add_ctor_f(c_p4, prism_rtl::cat(path_p3, "::", v_p5), Text::lit("choice"));
    });
}


/// AddAnswer: fn Cp, AnswerDef -> Cp
Cp add_answer_f(const Cp& cp_p0, const crate::lower::model::AnswerDef& a_p1) {
    return crate::prelude::fold(a_p1.cases_p, add_ty_f(cp_p0, Text::lit("Answer"), TyInfo{.kind_p = Text::lit("choice"), .fields_p = Array<Text>{}, .params_p = Array<Text>{}}), [&](const Cp& c_p2, const crate::lower::model::AnswerCase& k_p3) { return add_ctor_f(c_p2, prism_rtl::cat("Answer::", prism_rtl::deref(k_p3).variant_p), Text::lit("choice")); });
}


/// AddNode: fn Cp, Text, NodeDef -> Cp
Cp add_node_f(const Cp& cp_p0, const Text& m_p1, const crate::lower::model::NodeDef& n_p2) {
    auto with_fields_p3 = crate::prelude::fold(n_p2.fields_p, cp_p0, [&](const Cp& c_p7, const std::tuple<Text, crate::lower::model::OutTy, Text>& _p1) {
        auto&& f_p8 = std::get<0>(_p1);
        return ({
            Cp this_ = add_member_f(c_p7, f_p8);
            this_.field_names_p = crate::prelude::insert(this_.field_names_p, f_p8, true);
            (std::move(this_));
        });
    });
    auto with_methods_p4 = crate::prelude::fold(crate::prelude::append(n_p2.methods_p, n_p2.hosted_p), with_fields_p3, [&](const Cp& c_p9, const crate::lower::model::MethDef& md_pa) {
        return ({
            Cp this_ = add_member_f(c_p9, prism_rtl::deref(md_pa).name_p);
            this_.methods_p = crate::prelude::insert(this_.methods_p, prism_rtl::deref(md_pa).name_p, true);
            (std::move(this_));
        });
    });
    auto with_builders_p5 = crate::prelude::fold(n_p2.builders_p, with_methods_p4, [&](const Cp& c_pb, const crate::lower::model::ForDef& b_pc) { return add_member_f(c_pb, prism_rtl::cat(prism_rtl::deref(b_pc).name_p, "_build")); });
    auto with_gens_p6 = crate::prelude::fold(n_p2.gens_p, with_builders_p5, [&](const Cp& c_pd, const crate::lower::model::GenDef& g_pe) { return add_member_f(c_pd, prism_rtl::cat(prism_rtl::deref(g_pe).name_p, "_build")); });
    return add_ty_f(with_gens_p6, prism_rtl::cat(m_p1, "::", n_p2.name_p), TyInfo{.kind_p = Text::lit("node"), .fields_p = crate::prelude::each(n_p2.fields_p, [&](const std::tuple<Text, crate::lower::model::OutTy, Text>& _p0) {
        auto&& f_pf = std::get<0>(_p0);
        return f_pf;
    }), .params_p = Array<Text>{}});
}


/// InHome: fn Cp, Text -> Cp
Cp in_home_f(const Cp& cp_p0, const Text& m_p1) {
    Cp this_ = cp_p0;
    this_.home_p = m_p1;
    return this_;
}


/// WithFields: fn Cp, [((Text, OutTy))] -> Cp
Cp with_fields_f(const Cp& cp_p0, const Array<std::tuple<Text, crate::lower::model::OutTy>>& fs_p1) {
    Cp this_ = cp_p0;
    this_.fields_p = crate::prelude::fold(fs_p1, Map<Text, crate::lower::model::OutTy>{}, [&](const Map<Text, crate::lower::model::OutTy>& acc_p2, const std::tuple<Text, crate::lower::model::OutTy>& _p1) {
        auto&& f_p3 = std::get<0>(_p1);
        auto&& t_p4 = std::get<1>(_p1);
        return crate::prelude::insert(acc_p2, f_p3, t_p4);
    });
    return this_;
}


/// CppType: unbounded fn Cp, OutTy -> Text
Text cpp_type_f(const Cp& cp_p0, const crate::lower::model::OutTy& t_p1) {
    if (prism_rtl::is<crate::lower::model::OutTy::OutNat>(t_p1)) {
        return Text::lit("Nat");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutInt>(t_p1)) {
        return Text::lit("Int");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutU8>(t_p1)) {
        return Text::lit("std::uint8_t");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutFloat>(t_p1)) {
        return Text::lit("Float");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutBool>(t_p1)) {
        return Text::lit("bool");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutChar>(t_p1)) {
        return Text::lit("char32_t");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutText>(t_p1)) {
        return Text::lit("Text");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutCursor>(t_p1)) {
        return Text::lit("Cursor");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutRegex>(t_p1)) {
        return Text::lit("Regex");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutReplacement>(t_p1)) {
        return Text::lit("RegexReplacement");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutUnit>(t_p1)) {
        return Text::lit("Unit");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutPath>(t_p1)) {
        return Text::lit("Path");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutDuration>(t_p1)) {
        return Text::lit("Duration");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutError>(t_p1)) {
        return Text::lit("Error");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t_p1)) {
        auto&& m11530_14_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p1).a0;
        auto&& m11530_14_1 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p1).a1;
        if (m11530_14_0 == Text::lit("Cell")) {
            if (m11530_14_1.size() == 1u) {
                {
                    auto&& _c1 = crate::prelude::index(m11530_14_1, Nat(0u));
                    if (prism_rtl::is_some(_c1)) {
                        auto&& i_p2 = prism_rtl::some_of(_c1);
                        return cpp_type_f(cp_p0, i_p2);
                    }
                }
            }
        }
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t_p1)) {
        auto&& m11530_15_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p1).a0;
        auto&& m11530_15_1 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p1).a1;
        if (m11530_15_0 == Text::lit("RefCell")) {
            if (m11530_15_1.size() == 1u) {
                {
                    auto&& _c1 = crate::prelude::index(m11530_15_1, Nat(0u));
                    if (prism_rtl::is_some(_c1)) {
                        auto&& i_p3 = prism_rtl::some_of(_c1);
                        return cpp_type_f(cp_p0, i_p3);
                    }
                }
            }
        }
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t_p1)) {
        auto&& m11530_16_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p1).a0;
        auto&& m11530_16_1 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p1).a1;
        if (m11530_16_0 == Text::lit("Vec")) {
            if (m11530_16_1.size() == 1u) {
                {
                    auto&& _c1 = crate::prelude::index(m11530_16_1, Nat(0u));
                    if (prism_rtl::is_some(_c1)) {
                        auto&& i_p4 = prism_rtl::some_of(_c1);
                        return prism_rtl::cat("std::vector<", cpp_type_f(cp_p0, i_p4), ">");
                    }
                }
            }
        }
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t_p1)) {
        auto&& m11530_17_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p1).a0;
        auto&& m11530_17_1 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p1).a1;
        if (m11530_17_0 == Text::lit("Result")) {
            if (m11530_17_1.size() == 2u) {
                {
                    auto&& _c2 = crate::prelude::index(m11530_17_1, Nat(0u));
                    if (prism_rtl::is_some(_c2)) {
                        auto&& a_p5 = prism_rtl::some_of(_c2);
                        {
                            auto&& _c1 = crate::prelude::index(m11530_17_1, Nat(1u));
                            if (prism_rtl::is_some(_c1)) {
                                auto&& b_p6 = prism_rtl::some_of(_c1);
                                return prism_rtl::cat("Expected<", cpp_type_f(cp_p0, a_p5), ", ", cpp_type_f(cp_p0, b_p6), ">");
                            }
                        }
                    }
                }
            }
        }
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t_p1)) {
        auto&& n_p7 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p1).a0;
        auto&& m11530_18_1 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p1).a1;
        if (m11530_18_1.size() == 0u) {
            return own_type_path_f(cp_p0, n_p7);
        }
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t_p1)) {
        auto&& n_p8 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p1).a0;
        auto&& args_p9 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p1).a1;
        return prism_rtl::cat(own_type_path_f(cp_p0, n_p8), "<", cpp_types_f(cp_p0, args_p9), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutOpt>(t_p1)) {
        auto&& i_pa = prism_rtl::as<crate::lower::model::OutTy::OutOpt>(t_p1).a0;
        return prism_rtl::cat("std::optional<", cpp_type_f(cp_p0, prism_rtl::deref(prism_rtl::deref(i_pa))), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutRes>(t_p1)) {
        auto&& i_pb = prism_rtl::as<crate::lower::model::OutTy::OutRes>(t_p1).a0;
        return prism_rtl::cat("Fallible<", cpp_type_f(cp_p0, prism_rtl::deref(prism_rtl::deref(i_pb))), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutTuple>(t_p1)) {
        auto&& ts_pc = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(t_p1).a0;
        return prism_rtl::cat("std::tuple<", cpp_types_f(cp_p0, ts_pc), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutArray>(t_p1)) {
        auto&& e_pd = prism_rtl::as<crate::lower::model::OutTy::OutArray>(t_p1).a0;
        return prism_rtl::cat("Array<", cpp_type_f(cp_p0, prism_rtl::deref(prism_rtl::deref(e_pd))), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutMap>(t_p1)) {
        auto&& k_pe = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t_p1).a0;
        auto&& v_pf = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t_p1).a1;
        return prism_rtl::cat("Map<", cpp_type_f(cp_p0, prism_rtl::deref(prism_rtl::deref(k_pe))), ", ", cpp_type_f(cp_p0, prism_rtl::deref(prism_rtl::deref(v_pf))), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutFn>(t_p1)) {
        auto&& ps_pg = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t_p1).a0;
        auto&& r_ph = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t_p1).a1;
        return prism_rtl::cat("Fn<", cpp_type_f(cp_p0, prism_rtl::deref(prism_rtl::deref(r_ph))), "(", param_types_f(cp_p0, ps_pg), ")>");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutRef>(t_p1)) {
        auto&& m11530_26_0 = prism_rtl::as<crate::lower::model::OutTy::OutRef>(t_p1).a0;
        if (prism_rtl::is<crate::lower::model::OutTy::OutFn>(prism_rtl::deref(prism_rtl::deref(m11530_26_0)))) {
            auto&& ps_pi = prism_rtl::as<crate::lower::model::OutTy::OutFn>(prism_rtl::deref(prism_rtl::deref(m11530_26_0))).a0;
            auto&& r_pj = prism_rtl::as<crate::lower::model::OutTy::OutFn>(prism_rtl::deref(prism_rtl::deref(m11530_26_0))).a1;
            return prism_rtl::cat("const std::function<", cpp_type_f(cp_p0, prism_rtl::deref(prism_rtl::deref(r_pj))), "(", param_types_f(cp_p0, ps_pi), ")>&");
        }
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutRef>(t_p1)) {
        auto&& m11530_27_0 = prism_rtl::as<crate::lower::model::OutTy::OutRef>(t_p1).a0;
        if (prism_rtl::is<crate::lower::model::OutTy::OutSlice>(prism_rtl::deref(prism_rtl::deref(m11530_27_0)))) {
            auto&& i_pk = prism_rtl::as<crate::lower::model::OutTy::OutSlice>(prism_rtl::deref(prism_rtl::deref(m11530_27_0))).a0;
            return prism_rtl::cat("std::span<const ", cpp_type_f(cp_p0, prism_rtl::deref(prism_rtl::deref(i_pk))), ">");
        }
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutRef>(t_p1)) {
        auto&& i_pl = prism_rtl::as<crate::lower::model::OutTy::OutRef>(t_p1).a0;
        return prism_rtl::cat("const ", cpp_type_f(cp_p0, prism_rtl::deref(prism_rtl::deref(i_pl))), "&");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(t_p1)) {
        auto&& a_pm = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(t_p1).a0;
        auto&& b_pn = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(t_p1).a1;
        return prism_rtl::cat("prism_rtl::Fn<prism_rtl::JobRef<", cpp_type_f(cp_p0, prism_rtl::deref(prism_rtl::deref(b_pn))), ">(", cpp_type_f(cp_p0, prism_rtl::deref(prism_rtl::deref(a_pm))), ")>");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutJob>(t_p1)) {
        auto&& b_po = prism_rtl::as<crate::lower::model::OutTy::OutJob>(t_p1).a0;
        return prism_rtl::cat("prism_rtl::JobRef<", cpp_type_f(cp_p0, prism_rtl::deref(prism_rtl::deref(b_po))), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutEvent>(t_p1)) {
        auto&& i_pp = prism_rtl::as<crate::lower::model::OutTy::OutEvent>(t_p1).a0;
        return prism_rtl::cat("Event<", cpp_type_f(cp_p0, prism_rtl::deref(prism_rtl::deref(i_pp))), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutDyn>(t_p1)) {
        auto&& i_pq = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(t_p1).a0;
        return prism_rtl::cat("Dynamic<", cpp_type_f(cp_p0, prism_rtl::deref(prism_rtl::deref(i_pq))), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutGen>(t_p1)) {
        auto&& n_pr = prism_rtl::as<crate::lower::model::OutTy::OutGen>(t_p1).a0;
        return n_pr;
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutRc>(t_p1)) {
        auto&& i_ps = prism_rtl::as<crate::lower::model::OutTy::OutRc>(t_p1).a0;
        return is_value_ty_f(cp_p0, prism_rtl::deref(prism_rtl::deref(i_ps)))
            ? prism_rtl::cat("prism_rtl::Rc<const ", cpp_type_f(cp_p0, prism_rtl::deref(prism_rtl::deref(i_ps))), ">")
            : prism_rtl::cat("prism_rtl::Rc<", cpp_type_f(cp_p0, prism_rtl::deref(prism_rtl::deref(i_ps))), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutPod>(t_p1)) {
        return Text::lit("Pod");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutShowAny>(t_p1)) {
        return Text::lit("prism_rtl::Rc<const DynShow>");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutHold>(t_p1)) {
        auto&& i_pt = prism_rtl::as<crate::lower::model::OutTy::OutHold>(t_p1).a0;
        return prism_rtl::cat("Hold<", cpp_type_f(cp_p0, prism_rtl::deref(prism_rtl::deref(i_pt))), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutStamped>(t_p1)) {
        auto&& i_pu = prism_rtl::as<crate::lower::model::OutTy::OutStamped>(t_p1).a0;
        return prism_rtl::cat("Stamped<", cpp_type_f(cp_p0, prism_rtl::deref(prism_rtl::deref(i_pu))), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutSnapshot>(t_p1)) {
        auto&& i_pv = prism_rtl::as<crate::lower::model::OutTy::OutSnapshot>(t_p1).a0;
        return prism_rtl::cat("Snapshot<", cpp_type_f(cp_p0, prism_rtl::deref(prism_rtl::deref(i_pv))), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutDefer>(t_p1)) {
        auto&& i_p10 = prism_rtl::as<crate::lower::model::OutTy::OutDefer>(t_p1).a0;
        return prism_rtl::cat("Defer<", cpp_type_f(cp_p0, prism_rtl::deref(prism_rtl::deref(i_p10))), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutWeak>(t_p1)) {
        auto&& n_p11 = prism_rtl::as<crate::lower::model::OutTy::OutWeak>(t_p1).a0;
        return prism_rtl::cat("prism_rtl::Weak<", type_path_f(n_p11), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutCell>(t_p1)) {
        auto&& i_p12 = prism_rtl::as<crate::lower::model::OutTy::OutCell>(t_p1).a0;
        return cpp_type_f(cp_p0, prism_rtl::deref(prism_rtl::deref(i_p12)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutWakes>(t_p1)) {
        return Text::lit("Wakes");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutCount>(t_p1)) {
        return Text::lit("std::uint32_t");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutObj>(t_p1)) {
        auto&& i_p13 = prism_rtl::as<crate::lower::model::OutTy::OutObj>(t_p1).a0;
        return prism_rtl::cat("prism_rtl::Rc<", cpp_type_f(cp_p0, prism_rtl::deref(prism_rtl::deref(i_p13))), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutSlice>(t_p1)) {
        auto&& i_p14 = prism_rtl::as<crate::lower::model::OutTy::OutSlice>(t_p1).a0;
        return prism_rtl::cat("std::span<const ", cpp_type_f(cp_p0, prism_rtl::deref(prism_rtl::deref(i_p14))), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutPort>(t_p1)) {
        auto&& i_p15 = prism_rtl::as<crate::lower::model::OutTy::OutPort>(t_p1).a0;
        return prism_rtl::cat("Port<", cpp_type_f(cp_p0, prism_rtl::deref(prism_rtl::deref(i_p15))), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutLive>(t_p1)) {
        auto&& i_p16 = prism_rtl::as<crate::lower::model::OutTy::OutLive>(t_p1).a0;
        return prism_rtl::cat("Live<", cpp_type_f(cp_p0, prism_rtl::deref(prism_rtl::deref(i_p16))), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutTurn>(t_p1)) {
        return Text::lit("decltype(this->cycle())");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutRefused>(t_p1)) {
        auto&& what_p17 = prism_rtl::as<crate::lower::model::OutTy::OutRefused>(t_p1).a0;
        return prism_rtl::cat("compile_error!(\"", crate::lower::expr::lowering_refusal_p(), what_p17, "\")");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutQuantified>(t_p1)) {
        auto&& b_p18 = prism_rtl::as<crate::lower::model::OutTy::OutQuantified>(t_p1).a0;
        return prism_rtl::cat("compile_error!(\"", crate::lower::expr::lowering_refusal_p(), "a quantified type variable of `", b_p18, "`: no instantiation gives it a type\")");
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Text> CppType::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& t_p1 = this->t_p1;
    return ({
        prism_rtl::is<crate::lower::model::OutTy::OutNat>(t_p1) ? prism_rtl::finished(Text::lit("Nat"))
        : prism_rtl::is<crate::lower::model::OutTy::OutInt>(t_p1) ? prism_rtl::finished(Text::lit("Int"))
        : prism_rtl::is<crate::lower::model::OutTy::OutU8>(t_p1) ? prism_rtl::finished(Text::lit("std::uint8_t"))
        : prism_rtl::is<crate::lower::model::OutTy::OutFloat>(t_p1) ? prism_rtl::finished(Text::lit("Float"))
        : prism_rtl::is<crate::lower::model::OutTy::OutBool>(t_p1) ? prism_rtl::finished(Text::lit("bool"))
        : prism_rtl::is<crate::lower::model::OutTy::OutChar>(t_p1) ? prism_rtl::finished(Text::lit("char32_t"))
        : prism_rtl::is<crate::lower::model::OutTy::OutText>(t_p1) ? prism_rtl::finished(Text::lit("Text"))
        : prism_rtl::is<crate::lower::model::OutTy::OutCursor>(t_p1) ? prism_rtl::finished(Text::lit("Cursor"))
        : prism_rtl::is<crate::lower::model::OutTy::OutRegex>(t_p1) ? prism_rtl::finished(Text::lit("Regex"))
        : prism_rtl::is<crate::lower::model::OutTy::OutReplacement>(t_p1) ? prism_rtl::finished(Text::lit("RegexReplacement"))
        : prism_rtl::is<crate::lower::model::OutTy::OutUnit>(t_p1) ? prism_rtl::finished(Text::lit("Unit"))
        : prism_rtl::is<crate::lower::model::OutTy::OutPath>(t_p1) ? prism_rtl::finished(Text::lit("Path"))
        : prism_rtl::is<crate::lower::model::OutTy::OutDuration>(t_p1) ? prism_rtl::finished(Text::lit("Duration"))
        : prism_rtl::is<crate::lower::model::OutTy::OutError>(t_p1) ? prism_rtl::finished(Text::lit("Error"))
        : prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t_p1) && ({
        auto&& m11530_14_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p1).a0;
        auto&& m11530_14_1 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p1).a1;
        (m11530_14_0 == Text::lit("Cell")) && (m11530_14_1.size() == 1u) && ({
        auto&& _c1 = crate::prelude::index(m11530_14_1, Nat(0u));
        prism_rtl::is_some(_c1);
    });
    }) ? ({
        auto&& m11530_14_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p1).a0;
        auto&& m11530_14_1 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p1).a1;
        auto&& _c1 = crate::prelude::index(m11530_14_1, Nat(0u));
        auto&& i_p2 = prism_rtl::some_of(_c1);
        prism_rtl::more(prism_rtl::rc(CppType(cp_p0, i_p2)));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t_p1) && ({
        auto&& m11530_15_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p1).a0;
        auto&& m11530_15_1 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p1).a1;
        (m11530_15_0 == Text::lit("RefCell")) && (m11530_15_1.size() == 1u) && ({
        auto&& _c1 = crate::prelude::index(m11530_15_1, Nat(0u));
        prism_rtl::is_some(_c1);
    });
    }) ? ({
        auto&& m11530_15_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p1).a0;
        auto&& m11530_15_1 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p1).a1;
        auto&& _c1 = crate::prelude::index(m11530_15_1, Nat(0u));
        auto&& i_p3 = prism_rtl::some_of(_c1);
        prism_rtl::more(prism_rtl::rc(CppType(cp_p0, i_p3)));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t_p1) && ({
        auto&& m11530_16_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p1).a0;
        auto&& m11530_16_1 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p1).a1;
        (m11530_16_0 == Text::lit("Vec")) && (m11530_16_1.size() == 1u) && ({
        auto&& _c1 = crate::prelude::index(m11530_16_1, Nat(0u));
        prism_rtl::is_some(_c1);
    });
    }) ? ({
        auto&& m11530_16_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p1).a0;
        auto&& m11530_16_1 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p1).a1;
        auto&& _c1 = crate::prelude::index(m11530_16_1, Nat(0u));
        auto&& i_p4 = prism_rtl::some_of(_c1);
        ({
        auto cp_p0x = cp_p0;
        (crate::prelude::call_then(start_cpp_type_f(cp_p0x, i_p4), [=](Text cpp_type_f_11990) { return prism_rtl::finished(prism_rtl::cat("std::vector<", cpp_type_f_11990, ">")); }));
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t_p1) && ({
        auto&& m11530_17_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p1).a0;
        auto&& m11530_17_1 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p1).a1;
        (m11530_17_0 == Text::lit("Result")) && (m11530_17_1.size() == 2u) && ({
        auto&& _c2 = crate::prelude::index(m11530_17_1, Nat(0u));
        prism_rtl::is_some(_c2) && ({
        auto&& a_p5 = prism_rtl::some_of(_c2);
        ({
        auto&& _c1 = crate::prelude::index(m11530_17_1, Nat(1u));
        prism_rtl::is_some(_c1);
    });
    });
    });
    }) ? ({
        auto&& m11530_17_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p1).a0;
        auto&& m11530_17_1 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p1).a1;
        auto&& _c2 = crate::prelude::index(m11530_17_1, Nat(0u));
        auto&& a_p5 = prism_rtl::some_of(_c2);
        auto&& _c1 = crate::prelude::index(m11530_17_1, Nat(1u));
        auto&& b_p6 = prism_rtl::some_of(_c1);
        ({
        auto cp_p0x = cp_p0;
        (crate::prelude::call_then(start_cpp_type_f(cp_p0x, a_p5), [=](Text cpp_type_f_12051) { return crate::prelude::call_then(start_cpp_type_f(cp_p0x, b_p6), [=](Text cpp_type_f_12068) { return prism_rtl::finished(prism_rtl::cat("Expected<", cpp_type_f_12051, ", ", cpp_type_f_12068, ">")); }); }));
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t_p1) && ({
        auto&& n_p7 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p1).a0;
        auto&& m11530_18_1 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p1).a1;
        (m11530_18_1.size() == 0u);
    }) ? ({
        auto&& n_p7 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p1).a0;
        auto&& m11530_18_1 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p1).a1;
        prism_rtl::finished(own_type_path_f(cp_p0, n_p7));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t_p1) ? ({
        auto&& n_p8 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p1).a0;
        auto&& args_p9 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p1).a1;
        ({
        auto args_p9x = args_p9;
        auto cp_p0x = cp_p0;
        auto n_p8x = n_p8;
        (crate::prelude::call_then(start_cpp_types_f(cp_p0x, args_p9x), [=, n_p8x = std::move(n_p8x)](Text cpp_types_f_12169) { return prism_rtl::finished(prism_rtl::cat(own_type_path_f(cp_p0x, n_p8x), "<", cpp_types_f_12169, ">")); }));
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutOpt>(t_p1) ? ({
        auto&& i_pa = prism_rtl::as<crate::lower::model::OutTy::OutOpt>(t_p1).a0;
        ({
        auto cp_p0x = cp_p0;
        auto i_pax = prism_rtl::deref(prism_rtl::deref(i_pa));
        (crate::prelude::call_then(start_cpp_type_f(cp_p0x, i_pax), [=](Text cpp_type_f_12220) { return prism_rtl::finished(prism_rtl::cat("std::optional<", cpp_type_f_12220, ">")); }));
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutRes>(t_p1) ? ({
        auto&& i_pb = prism_rtl::as<crate::lower::model::OutTy::OutRes>(t_p1).a0;
        ({
        auto cp_p0x = cp_p0;
        auto i_pbx = prism_rtl::deref(prism_rtl::deref(i_pb));
        (crate::prelude::call_then(start_cpp_type_f(cp_p0x, i_pbx), [=](Text cpp_type_f_12262) { return prism_rtl::finished(prism_rtl::cat("Fallible<", cpp_type_f_12262, ">")); }));
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutTuple>(t_p1) ? ({
        auto&& ts_pc = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(t_p1).a0;
        ({
        auto cp_p0x = cp_p0;
        auto ts_pcx = ts_pc;
        (crate::prelude::call_then(start_cpp_types_f(cp_p0x, ts_pcx), [=](Text cpp_types_f_12309) { return prism_rtl::finished(prism_rtl::cat("std::tuple<", cpp_types_f_12309, ">")); }));
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutArray>(t_p1) ? ({
        auto&& e_pd = prism_rtl::as<crate::lower::model::OutTy::OutArray>(t_p1).a0;
        ({
        auto cp_p0x = cp_p0;
        auto e_pdx = prism_rtl::deref(prism_rtl::deref(e_pd));
        (crate::prelude::call_then(start_cpp_type_f(cp_p0x, e_pdx), [=](Text cpp_type_f_12352) { return prism_rtl::finished(prism_rtl::cat("Array<", cpp_type_f_12352, ">")); }));
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutMap>(t_p1) ? ({
        auto&& k_pe = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t_p1).a0;
        auto&& v_pf = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t_p1).a1;
        ({
        auto cp_p0x = cp_p0;
        auto k_pex = prism_rtl::deref(prism_rtl::deref(k_pe));
        auto v_pfx = prism_rtl::deref(prism_rtl::deref(v_pf));
        (crate::prelude::call_then(start_cpp_type_f(cp_p0x, k_pex), [=, v_pfx = std::move(v_pfx)](Text cpp_type_f_12392) { return crate::prelude::call_then(start_cpp_type_f(cp_p0x, v_pfx), [=](Text cpp_type_f_12409) { return prism_rtl::finished(prism_rtl::cat("Map<", cpp_type_f_12392, ", ", cpp_type_f_12409, ">")); }); }));
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutFn>(t_p1) ? ({
        auto&& ps_pg = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t_p1).a0;
        auto&& r_ph = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t_p1).a1;
        ({
        auto cp_p0x = cp_p0;
        auto ps_pgx = ps_pg;
        auto r_phx = prism_rtl::deref(prism_rtl::deref(r_ph));
        (crate::prelude::call_then(start_cpp_type_f(cp_p0x, r_phx), [=, ps_pgx = std::move(ps_pgx)](Text cpp_type_f_12448) { return crate::prelude::call_then(start_param_types_f(cp_p0x, ps_pgx), [=](Text param_types_f_12464) { return prism_rtl::finished(prism_rtl::cat("Fn<", cpp_type_f_12448, "(", param_types_f_12464, ")>")); }); }));
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutRef>(t_p1) && ({
        auto&& m11530_26_0 = prism_rtl::as<crate::lower::model::OutTy::OutRef>(t_p1).a0;
        prism_rtl::is<crate::lower::model::OutTy::OutFn>(prism_rtl::deref(prism_rtl::deref(m11530_26_0)));
    }) ? ({
        auto&& m11530_26_0 = prism_rtl::as<crate::lower::model::OutTy::OutRef>(t_p1).a0;
        auto&& ps_pi = prism_rtl::as<crate::lower::model::OutTy::OutFn>(prism_rtl::deref(prism_rtl::deref(m11530_26_0))).a0;
        auto&& r_pj = prism_rtl::as<crate::lower::model::OutTy::OutFn>(prism_rtl::deref(prism_rtl::deref(m11530_26_0))).a1;
        ({
        auto cp_p0x = cp_p0;
        auto ps_pix = ps_pi;
        auto r_pjx = prism_rtl::deref(prism_rtl::deref(r_pj));
        (crate::prelude::call_then(start_cpp_type_f(cp_p0x, r_pjx), [=, ps_pix = std::move(ps_pix)](Text cpp_type_f_12534) { return crate::prelude::call_then(start_param_types_f(cp_p0x, ps_pix), [=](Text param_types_f_12550) { return prism_rtl::finished(prism_rtl::cat("const std::function<", cpp_type_f_12534, "(", param_types_f_12550, ")>&")); }); }));
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutRef>(t_p1) && ({
        auto&& m11530_27_0 = prism_rtl::as<crate::lower::model::OutTy::OutRef>(t_p1).a0;
        prism_rtl::is<crate::lower::model::OutTy::OutSlice>(prism_rtl::deref(prism_rtl::deref(m11530_27_0)));
    }) ? ({
        auto&& m11530_27_0 = prism_rtl::as<crate::lower::model::OutTy::OutRef>(t_p1).a0;
        auto&& i_pk = prism_rtl::as<crate::lower::model::OutTy::OutSlice>(prism_rtl::deref(prism_rtl::deref(m11530_27_0))).a0;
        ({
        auto cp_p0x = cp_p0;
        auto i_pkx = prism_rtl::deref(prism_rtl::deref(i_pk));
        (crate::prelude::call_then(start_cpp_type_f(cp_p0x, i_pkx), [=](Text cpp_type_f_12616) { return prism_rtl::finished(prism_rtl::cat("std::span<const ", cpp_type_f_12616, ">")); }));
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutRef>(t_p1) ? ({
        auto&& i_pl = prism_rtl::as<crate::lower::model::OutTy::OutRef>(t_p1).a0;
        ({
        auto cp_p0x = cp_p0;
        auto i_plx = prism_rtl::deref(prism_rtl::deref(i_pl));
        (crate::prelude::call_then(start_cpp_type_f(cp_p0x, i_plx), [=](Text cpp_type_f_12655) { return prism_rtl::finished(prism_rtl::cat("const ", cpp_type_f_12655, "&")); }));
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(t_p1) ? ({
        auto&& a_pm = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(t_p1).a0;
        auto&& b_pn = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(t_p1).a1;
        ({
        auto a_pmx = prism_rtl::deref(prism_rtl::deref(a_pm));
        auto b_pnx = prism_rtl::deref(prism_rtl::deref(b_pn));
        auto cp_p0x = cp_p0;
        (crate::prelude::call_then(start_cpp_type_f(cp_p0x, b_pnx), [=, a_pmx = std::move(a_pmx)](Text cpp_type_f_12725) { return crate::prelude::call_then(start_cpp_type_f(cp_p0x, a_pmx), [=](Text cpp_type_f_12742) { return prism_rtl::finished(prism_rtl::cat("prism_rtl::Fn<prism_rtl::JobRef<", cpp_type_f_12725, ">(", cpp_type_f_12742, ")>")); }); }));
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutJob>(t_p1) ? ({
        auto&& b_po = prism_rtl::as<crate::lower::model::OutTy::OutJob>(t_p1).a0;
        ({
        auto b_pox = prism_rtl::deref(prism_rtl::deref(b_po));
        auto cp_p0x = cp_p0;
        (crate::prelude::call_then(start_cpp_type_f(cp_p0x, b_pox), [=](Text cpp_type_f_12794) { return prism_rtl::finished(prism_rtl::cat("prism_rtl::JobRef<", cpp_type_f_12794, ">")); }));
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutEvent>(t_p1) ? ({
        auto&& i_pp = prism_rtl::as<crate::lower::model::OutTy::OutEvent>(t_p1).a0;
        ({
        auto cp_p0x = cp_p0;
        auto i_ppx = prism_rtl::deref(prism_rtl::deref(i_pp));
        (crate::prelude::call_then(start_cpp_type_f(cp_p0x, i_ppx), [=](Text cpp_type_f_12835) { return prism_rtl::finished(prism_rtl::cat("Event<", cpp_type_f_12835, ">")); }));
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutDyn>(t_p1) ? ({
        auto&& i_pq = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(t_p1).a0;
        ({
        auto cp_p0x = cp_p0;
        auto i_pqx = prism_rtl::deref(prism_rtl::deref(i_pq));
        (crate::prelude::call_then(start_cpp_type_f(cp_p0x, i_pqx), [=](Text cpp_type_f_12876) { return prism_rtl::finished(prism_rtl::cat("Dynamic<", cpp_type_f_12876, ">")); }));
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutGen>(t_p1) ? ({
        auto&& n_pr = prism_rtl::as<crate::lower::model::OutTy::OutGen>(t_p1).a0;
        prism_rtl::finished(n_pr);
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutRc>(t_p1) ? ({
        auto&& i_ps = prism_rtl::as<crate::lower::model::OutTy::OutRc>(t_p1).a0;
        is_value_ty_f(cp_p0, prism_rtl::deref(prism_rtl::deref(i_ps)))
        ? ({
        auto cp_p0x = cp_p0;
        auto i_psx = prism_rtl::deref(prism_rtl::deref(i_ps));
        (crate::prelude::call_then(start_cpp_type_f(cp_p0x, i_psx), [=](Text cpp_type_f_12964) { return prism_rtl::finished(prism_rtl::cat("prism_rtl::Rc<const ", cpp_type_f_12964, ">")); }));
    })
        : ({
        auto cp_p0x = cp_p0;
        auto i_psx = prism_rtl::deref(prism_rtl::deref(i_ps));
        (crate::prelude::call_then(start_cpp_type_f(cp_p0x, i_psx), [=](Text cpp_type_f_13003) { return prism_rtl::finished(prism_rtl::cat("prism_rtl::Rc<", cpp_type_f_13003, ">")); }));
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutPod>(t_p1) ? prism_rtl::finished(Text::lit("Pod"))
        : prism_rtl::is<crate::lower::model::OutTy::OutShowAny>(t_p1) ? prism_rtl::finished(Text::lit("prism_rtl::Rc<const DynShow>"))
        : prism_rtl::is<crate::lower::model::OutTy::OutHold>(t_p1) ? ({
        auto&& i_pt = prism_rtl::as<crate::lower::model::OutTy::OutHold>(t_p1).a0;
        ({
        auto cp_p0x = cp_p0;
        auto i_ptx = prism_rtl::deref(prism_rtl::deref(i_pt));
        (crate::prelude::call_then(start_cpp_type_f(cp_p0x, i_ptx), [=](Text cpp_type_f_13107) { return prism_rtl::finished(prism_rtl::cat("Hold<", cpp_type_f_13107, ">")); }));
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutStamped>(t_p1) ? ({
        auto&& i_pu = prism_rtl::as<crate::lower::model::OutTy::OutStamped>(t_p1).a0;
        ({
        auto cp_p0x = cp_p0;
        auto i_pux = prism_rtl::deref(prism_rtl::deref(i_pu));
        (crate::prelude::call_then(start_cpp_type_f(cp_p0x, i_pux), [=](Text cpp_type_f_13152) { return prism_rtl::finished(prism_rtl::cat("Stamped<", cpp_type_f_13152, ">")); }));
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutSnapshot>(t_p1) ? ({
        auto&& i_pv = prism_rtl::as<crate::lower::model::OutTy::OutSnapshot>(t_p1).a0;
        ({
        auto cp_p0x = cp_p0;
        auto i_pvx = prism_rtl::deref(prism_rtl::deref(i_pv));
        (crate::prelude::call_then(start_cpp_type_f(cp_p0x, i_pvx), [=](Text cpp_type_f_13199) { return prism_rtl::finished(prism_rtl::cat("Snapshot<", cpp_type_f_13199, ">")); }));
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutDefer>(t_p1) ? ({
        auto&& i_p10 = prism_rtl::as<crate::lower::model::OutTy::OutDefer>(t_p1).a0;
        ({
        auto cp_p0x = cp_p0;
        auto i_p10x = prism_rtl::deref(prism_rtl::deref(i_p10));
        (crate::prelude::call_then(start_cpp_type_f(cp_p0x, i_p10x), [=](Text cpp_type_f_13240) { return prism_rtl::finished(prism_rtl::cat("Defer<", cpp_type_f_13240, ">")); }));
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutWeak>(t_p1) ? ({
        auto&& n_p11 = prism_rtl::as<crate::lower::model::OutTy::OutWeak>(t_p1).a0;
        prism_rtl::finished(prism_rtl::cat("prism_rtl::Weak<", type_path_f(n_p11), ">"));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutCell>(t_p1) ? ({
        auto&& i_p12 = prism_rtl::as<crate::lower::model::OutTy::OutCell>(t_p1).a0;
        prism_rtl::more(prism_rtl::rc(CppType(cp_p0, prism_rtl::deref(prism_rtl::deref(i_p12)))));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutWakes>(t_p1) ? prism_rtl::finished(Text::lit("Wakes"))
        : prism_rtl::is<crate::lower::model::OutTy::OutCount>(t_p1) ? prism_rtl::finished(Text::lit("std::uint32_t"))
        : prism_rtl::is<crate::lower::model::OutTy::OutObj>(t_p1) ? ({
        auto&& i_p13 = prism_rtl::as<crate::lower::model::OutTy::OutObj>(t_p1).a0;
        ({
        auto cp_p0x = cp_p0;
        auto i_p13x = prism_rtl::deref(prism_rtl::deref(i_p13));
        (crate::prelude::call_then(start_cpp_type_f(cp_p0x, i_p13x), [=](Text cpp_type_f_13415) { return prism_rtl::finished(prism_rtl::cat("prism_rtl::Rc<", cpp_type_f_13415, ">")); }));
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutSlice>(t_p1) ? ({
        auto&& i_p14 = prism_rtl::as<crate::lower::model::OutTy::OutSlice>(t_p1).a0;
        ({
        auto cp_p0x = cp_p0;
        auto i_p14x = prism_rtl::deref(prism_rtl::deref(i_p14));
        (crate::prelude::call_then(start_cpp_type_f(cp_p0x, i_p14x), [=](Text cpp_type_f_13466) { return prism_rtl::finished(prism_rtl::cat("std::span<const ", cpp_type_f_13466, ">")); }));
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutPort>(t_p1) ? ({
        auto&& i_p15 = prism_rtl::as<crate::lower::model::OutTy::OutPort>(t_p1).a0;
        ({
        auto cp_p0x = cp_p0;
        auto i_p15x = prism_rtl::deref(prism_rtl::deref(i_p15));
        (crate::prelude::call_then(start_cpp_type_f(cp_p0x, i_p15x), [=](Text cpp_type_f_13505) { return prism_rtl::finished(prism_rtl::cat("Port<", cpp_type_f_13505, ">")); }));
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutLive>(t_p1) ? ({
        auto&& i_p16 = prism_rtl::as<crate::lower::model::OutTy::OutLive>(t_p1).a0;
        ({
        auto cp_p0x = cp_p0;
        auto i_p16x = prism_rtl::deref(prism_rtl::deref(i_p16));
        (crate::prelude::call_then(start_cpp_type_f(cp_p0x, i_p16x), [=](Text cpp_type_f_13544) { return prism_rtl::finished(prism_rtl::cat("Live<", cpp_type_f_13544, ">")); }));
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutTurn>(t_p1) ? prism_rtl::finished(Text::lit("decltype(this->cycle())"))
        : prism_rtl::is<crate::lower::model::OutTy::OutRefused>(t_p1) ? ({
        auto&& what_p17 = prism_rtl::as<crate::lower::model::OutTy::OutRefused>(t_p1).a0;
        prism_rtl::finished(prism_rtl::cat("compile_error!(\"", crate::lower::expr::lowering_refusal_p(), what_p17, "\")"));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutQuantified>(t_p1) ? ({
        auto&& b_p18 = prism_rtl::as<crate::lower::model::OutTy::OutQuantified>(t_p1).a0;
        prism_rtl::finished(prism_rtl::cat("compile_error!(\"", crate::lower::expr::lowering_refusal_p(), "a quantified type variable of `", b_p18, "`: no instantiation gives it a type\")"));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CppType, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_type_f(Cp cp_p0, crate::lower::model::OutTy t_p1) {
    return prism_rtl::make_rc<CppType>(cp_p0, t_p1);
}


/// CppTypes: unbounded fn Cp, [OutTy] -> Text
Text cpp_types_f(const Cp& cp_p0, const Array<crate::lower::model::OutTy>& ts_p1) {
    return crate::syntax::lexer::chars::join_f(crate::prelude::run_to_end(crate::prelude::each_job(ts_p1, ({
        auto cp_p0x = cp_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::OutTy)>>(prism_rtl::rc([=, cp_p0x = std::move(cp_p0x)](crate::lower::model::OutTy p0) {
        return ({
            auto cp_p0xy = cp_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xy = std::move(cp_p0xy)]() {
            return ({
                auto t_p2 = p0;
                (prism_rtl::more(prism_rtl::rc(CppType(cp_p0xy, t_p2))));
            });
        })));
        });
    })));
    }))), Text::lit(", "));
}


prism_rtl::Turn<Text> CppTypes::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& ts_p1 = this->ts_p1;
    auto cp_p0x = cp_p0;
    auto ts_p1x = ts_p1;
    return crate::prelude::call_value(crate::prelude::each_job(ts_p1x, ({
        auto cp_p0xx = cp_p0x;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::OutTy)>>(prism_rtl::rc([=, cp_p0xx = std::move(cp_p0xx)](crate::lower::model::OutTy p0) {
        return ({
            auto cp_p0xxy = cp_p0xx;
            (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xxy = std::move(cp_p0xxy)]() {
            return ({
                auto t_p2 = p0;
                (prism_rtl::more(prism_rtl::rc(CppType(cp_p0xxy, t_p2))));
            });
        })));
        });
    })));
    })), [=](Array<Text> each_13868) { return prism_rtl::finished(crate::syntax::lexer::chars::join_f(each_13868, Text::lit(", "))); });
}


/// `Start CppTypes, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_types_f(Cp cp_p0, Array<crate::lower::model::OutTy> ts_p1) {
    return prism_rtl::make_rc<CppTypes>(cp_p0, ts_p1);
}


/// ParamTypes: unbounded fn Cp, [OutTy] -> Text
Text param_types_f(const Cp& cp_p0, const Array<crate::lower::model::OutTy>& ts_p1) {
    return crate::syntax::lexer::chars::join_f(crate::prelude::run_to_end(crate::prelude::each_job(ts_p1, ({
        auto cp_p0x = cp_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::OutTy)>>(prism_rtl::rc([=, cp_p0x = std::move(cp_p0x)](crate::lower::model::OutTy p0) {
        return ({
            auto cp_p0xy = cp_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xy = std::move(cp_p0xy)]() {
            return ({
                auto t_p2 = p0;
                (crate::prelude::call_then(start_cpp_type_f(cp_p0xy, t_p2), [=](Text cpp_type_f_14083) { return prism_rtl::finished(prism_rtl::cat("const ", cpp_type_f_14083, "&")); }));
            });
        })));
        });
    })));
    }))), Text::lit(", "));
}


prism_rtl::Turn<Text> ParamTypes::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& ts_p1 = this->ts_p1;
    auto cp_p0x = cp_p0;
    auto ts_p1x = ts_p1;
    return crate::prelude::call_value(crate::prelude::each_job(ts_p1x, ({
        auto cp_p0xx = cp_p0x;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::OutTy)>>(prism_rtl::rc([=, cp_p0xx = std::move(cp_p0xx)](crate::lower::model::OutTy p0) {
        return ({
            auto cp_p0xxy = cp_p0xx;
            (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xxy = std::move(cp_p0xxy)]() {
            return ({
                auto t_p2 = p0;
                (crate::prelude::call_then(start_cpp_type_f(cp_p0xxy, t_p2), [=](Text cpp_type_f_14083) { return prism_rtl::finished(prism_rtl::cat("const ", cpp_type_f_14083, "&")); }));
            });
        })));
        });
    })));
    })), [=](Array<Text> each_14061) { return prism_rtl::finished(crate::syntax::lexer::chars::join_f(each_14061, Text::lit(", "))); });
}


/// `Start ParamTypes, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_param_types_f(Cp cp_p0, Array<crate::lower::model::OutTy> ts_p1) {
    return prism_rtl::make_rc<ParamTypes>(cp_p0, ts_p1);
}


/// OwnTypePath: fn Cp, Text -> Text
Text own_type_path_f(const Cp& cp_p0, const Text& n_p1) {
    auto shadowed_p2 = (!crate::syntax::lexer::chars::contains_f(n_p1, Text::lit(":"))) && in_list_f(Array(std::vector{Text::lit("Job"), Text::lit("Node"), Text::lit("Row"), Text::lit("Turn"), Text::lit("Program")}), n_p1);
    auto&& _m = type_of_o(cp_p0, n_p1);
    if (prism_rtl::is_some(_m)) {
        return std::move(shadowed_p2)
            ? prism_rtl::cat("crate::", cp_p0.home_p, "::", n_p1)
            : type_path_f(n_p1);
    }
    if (prism_rtl::is_none(_m)) {
        return type_path_f(n_p1);
    }
    prism_rtl::unreachable("no arm matched");
}


/// TypePath: fn Text -> Text
Text type_path_f(const Text& p_p0) {
    auto no_fish_p1 = crate::syntax::lexer::chars::join_f(crate::prelude::split_on(p_p0, Text::lit("::<")), Text::lit("<"));
    auto no_holes_p2 = crate::syntax::lexer::chars::join_f(crate::prelude::split_on(no_fish_p1, Text::lit(", _>")), Text::lit(">"));
    return crate::syntax::lexer::chars::join_f(crate::prelude::split_on(no_holes_p2, Text::lit("<_>")), Text::lit(""));
}


/// IsValueTy: fn Cp, OutTy -> Bool
bool is_value_ty_f(const Cp& cp_p0, const crate::lower::model::OutTy& t_p1) {
    if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t_p1)) {
        auto&& n_p2 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p1).a0;
        auto&& _m = type_of_o(cp_p0, n_p2);
        if (prism_rtl::is_some(_m)) {
            auto&& info_p3 = prism_rtl::some_of(_m);
            return (prism_rtl::deref(info_p3).kind_p != Text::lit("node")) && (prism_rtl::deref(info_p3).kind_p != Text::lit("job"));
        }
        if (prism_rtl::is_none(_m)) {
            return false;
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutCell>(t_p1)) {
        return false;
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutPort>(t_p1)) {
        return false;
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutHold>(t_p1)) {
        return false;
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutStamped>(t_p1)) {
        return false;
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutSnapshot>(t_p1)) {
        return false;
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutDefer>(t_p1)) {
        return false;
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutObj>(t_p1)) {
        return false;
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutWakes>(t_p1)) {
        return false;
    }
    {
        return true;
    }
}

}  // namespace crate::emit::cpp
