// The module `Emit.Cpp`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <emit/cpp/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Emit.Cpp`, from `target/bootstrap/cpp-src/prismc/emit/cpp/mod.prism`.
namespace crate::emit::cpp {

Pod Cp::to_pod() const {
    return Pod::record("Cp", {{"home", prism_rtl::to_pod(home)}, {"mods", prism_rtl::to_pod(mods)}, {"types", prism_rtl::to_pod(types)}, {"ctors", prism_rtl::to_pod(ctors)}, {"members", prism_rtl::to_pod(members)}, {"methods", prism_rtl::to_pod(methods)}, {"field_names", prism_rtl::to_pod(field_names)}, {"fns", prism_rtl::to_pod(fns)}, {"fields", prism_rtl::to_pod(fields)}, {"renames", prism_rtl::to_pod(renames)}, {"pointers", prism_rtl::to_pod(pointers)}, {"owned", prism_rtl::to_pod(owned)}, {"move_captures", prism_rtl::to_pod(move_captures)}, {"local_types", prism_rtl::to_pod(local_types)}});
}

Result<Cp> Cp::from_pod(const Pod& whole) {
    return Cp{.home = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "home")))), .mods = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "mods")))), .types = TRY(prism_rtl::from_pod<Map<Text, TyInfo>>(TRY(crate::prelude::field(whole, "types")))), .ctors = TRY(prism_rtl::from_pod<Map<Text, Text>>(TRY(crate::prelude::field(whole, "ctors")))), .members = TRY(prism_rtl::from_pod<Map<Text, bool>>(TRY(crate::prelude::field(whole, "members")))), .methods = TRY(prism_rtl::from_pod<Map<Text, bool>>(TRY(crate::prelude::field(whole, "methods")))), .field_names = TRY(prism_rtl::from_pod<Map<Text, bool>>(TRY(crate::prelude::field(whole, "field_names")))), .fns = TRY(prism_rtl::from_pod<Map<Text, bool>>(TRY(crate::prelude::field(whole, "fns")))), .fields = TRY(prism_rtl::from_pod<Map<Text, crate::lower::model::OutTy>>(TRY(crate::prelude::field(whole, "fields")))), .renames = TRY(prism_rtl::from_pod<Map<Text, Text>>(TRY(crate::prelude::field(whole, "renames")))), .pointers = TRY(prism_rtl::from_pod<Map<Text, bool>>(TRY(crate::prelude::field(whole, "pointers")))), .owned = TRY(prism_rtl::from_pod<Map<Text, bool>>(TRY(crate::prelude::field(whole, "owned")))), .move_captures = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "move_captures")))), .local_types = TRY(prism_rtl::from_pod<Map<Text, crate::lower::model::OutTy>>(TRY(crate::prelude::field(whole, "local_types"))))};
}


void TyInfo::show(Printer& p) const {
    p.record("TyInfo", {{"kind", kind}, {"fields", fields}, {"params", params}});
}

Pod TyInfo::to_pod() const {
    return Pod::record("TyInfo", {{"kind", prism_rtl::to_pod(kind)}, {"fields", prism_rtl::to_pod(fields)}, {"params", prism_rtl::to_pod(params)}});
}

Result<TyInfo> TyInfo::from_pod(const Pod& whole) {
    return TyInfo{.kind = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "kind")))), .fields = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "fields")))), .params = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "params"))))};
}


/// CppId: fn Text -> Text
Text cpp_id(const Text& n_p0) {
    return in_list(crate::lower::cpp_keywords(), n_p0)
        ? prism_rtl::cat(n_p0, "_")
        : n_p0;
}


/// FieldId: fn Text -> Text
Text field_id(const Text& f_p0) {
    return in_list(Array(std::vector{Text::lit("show"), Text::lit("to_pod"), Text::lit("from_pod"), Text::lit("cases")}), f_p0)
        ? prism_rtl::cat(f_p0, "_")
        : cpp_id(f_p0);
}


/// CppPathId: fn Text -> Text
Text cpp_path_id(const Text& p_p0) {
    return crate::syntax::lexer::chars::join(each(split_on(p_p0, Text::lit("::")), [&](const Text& s_p1) { return cpp_id(s_p1); }), Text::lit("::"));
}


/// InList: fn [Text], Text -> Bool
bool in_list(const Array<Text>& xs_p0, const Text& x_p1) {
    return fold(xs_p0, false, [&](const bool& seen_p2, const Text& y_p3) { return prism_rtl::deref(seen_p2) || (y_p3 == x_p1); });
}


/// Absolute: fn Cp, Text -> Text
Text absolute(const Cp& cp_p0, const Text& p_p1) {
    auto q_p2 = crate::syntax::lexer::chars::drop_prefix(p_p1, Text::lit("crate::"));
    return fold(cp_p0.mods, false, [&](const bool& f_p3, const Text& m_p4) { return prism_rtl::deref(f_p3) || crate::syntax::lexer::chars::has_prefix(q_p2, prism_rtl::cat(m_p4, "::")); })
        ? q_p2
        : prism_rtl::cat(cp_p0.home, "::", q_p2);
}


/// ?TypeOf: fn Cp, Text -> ?TyInfo
std::optional<TyInfo> type_of(const Cp& cp_p0, const Text& p_p1) {
    auto q_p2 = crate::syntax::lexer::chars::drop_prefix(p_p1, Text::lit("crate::"));
    auto&& _m = crate::prelude::get(cp_p0.types, absolute(cp_p0, q_p2));
    if (prism_rtl::is_some(_m)) {
        auto&& t_p3 = prism_rtl::some_of(_m);
        return std::optional(t_p3);
    }
    if (prism_rtl::is_none(_m)) {
        auto&& _m = crate::prelude::get(cp_p0.types, prism_rtl::cat("prelude::", q_p2));
        if (prism_rtl::is_some(_m)) {
            auto&& t_p4 = prism_rtl::some_of(_m);
            return std::optional(t_p4);
        }
        if (prism_rtl::is_none(_m)) {
            return crate::prelude::get(cp_p0.types, q_p2);
        }
        prism_rtl::unreachable("no arm matched");
    }
    prism_rtl::unreachable("no arm matched");
}


/// ?CaseOf: fn Cp, Text -> ?Text
std::optional<Text> case_of(const Cp& cp_p0, const Text& p_p1) {
    auto q_p2 = crate::syntax::lexer::chars::drop_prefix(p_p1, Text::lit("crate::"));
    auto&& _m = crate::prelude::get(cp_p0.ctors, absolute(cp_p0, q_p2));
    if (prism_rtl::is_some(_m)) {
        return std::optional(parent_path(p_p1));
    }
    if (prism_rtl::is_none(_m)) {
        auto&& _m = crate::prelude::get(cp_p0.ctors, prism_rtl::cat("prelude::", q_p2));
        if (prism_rtl::is_some(_m)) {
            return std::optional(parent_path(p_p1));
        }
        if (prism_rtl::is_none(_m)) {
            auto&& _m = crate::prelude::get(cp_p0.ctors, q_p2);
            if (prism_rtl::is_some(_m)) {
                return std::optional(parent_path(p_p1));
            }
            if (prism_rtl::is_none(_m)) {
                return std::optional<Text>{};
            }
            prism_rtl::unreachable("no arm matched");
        }
        prism_rtl::unreachable("no arm matched");
    }
    prism_rtl::unreachable("no arm matched");
}


/// ParentPath: fn Text -> Text
Text parent_path(const Text& p_p0) {
    auto segs_p1 = split_on(p_p0, Text::lit("::"));
    return crate::syntax::lexer::chars::join(take(segs_p1, crate::syntax::lexer::chars::dec(len(segs_p1))), Text::lit("::"));
}


/// LastSegment: fn Text -> Text
Text last_segment(const Text& p_p0) {
    return or_(crate::syntax::lexer::chars::last(split_on(p_p0, Text::lit("::"))), p_p0);
}


/// Context: fn Model -> Cp
Cp context(const crate::lower::model::Model& model_p0) {
    auto names_p1 = each(model_p0.mods, [&](const crate::lower::model::ModDef& m_p6) { return prism_rtl::deref(m_p6).name; });
    auto tops_p2 = fold(names_p1, Array<Text>{}, [&](const Array<Text>& acc_p7, const Text& n_p8) {
        return ({
            auto top_p9 = or_(index(split_on(n_p8, Text::lit("::")), Nat(0u)), n_p8);
            in_list(names_p1, top_p9) || in_list(acc_p7, top_p9)
            ? acc_p7
            : crate::prelude::push(acc_p7, top_p9);
        });
    });
    auto mods_p3 = crate::prelude::push(append(names_p1, tops_p2), Text::lit("prelude"));
    auto base_p4 = Cp{.home = Text::lit(""), .mods = mods_p3, .types = prelude_types(), .ctors = prelude_ctors(), .members = node_base(), .methods = Map<Text, bool>{}, .field_names = Map<Text, bool>{}, .fns = Map<Text, bool>{}, .fields = Map<Text, crate::lower::model::OutTy>{}, .renames = Map<Text, Text>{}, .pointers = Map<Text, bool>{}, .owned = Map<Text, bool>{}, .move_captures = Array<Text>{}, .local_types = Map<Text, crate::lower::model::OutTy>{}};
    auto with_elem_p5 = add_row(add_answer(base_p4, model_p0.answer), Text::lit(""), model_p0.elem);
    return fold(model_p0.mods, with_elem_p5, [&](const Cp& cp_pa, const crate::lower::model::ModDef& m_pb) { return fold(prism_rtl::deref(m_pb).items, cp_pa, [&](const Cp& c_pc, const crate::lower::model::Item& it_pd) { return add_model_item(c_pc, prism_rtl::deref(m_pb).name, it_pd); }); });
}


/// let preludeTypes
Map<Text, TyInfo> prelude_types() {
    return map_of(std::vector{std::tuple{Text::lit("prelude::Ordering"), TyInfo{.kind = Text::lit("choice"), .fields = Array<Text>{}, .params = Array<Text>{}}}, std::tuple{Text::lit("prelude::Span"), TyInfo{.kind = Text::lit("record"), .fields = Array(std::vector{Text::lit("file"), Text::lit("line"), Text::lit("column"), Text::lit("binding")}), .params = Array<Text>{}}}, std::tuple{Text::lit("prelude::Exception"), TyInfo{.kind = Text::lit("record"), .fields = Array(std::vector{Text::lit("kind"), Text::lit("message"), Text::lit("spans"), Text::lit("path_")}), .params = Array<Text>{}}}, std::tuple{Text::lit("prelude::Duration"), TyInfo{.kind = Text::lit("newtype"), .fields = Array<Text>{}, .params = Array<Text>{}}}, std::tuple{Text::lit("prelude::PreludeUnwrap"), TyInfo{.kind = Text::lit("tag"), .fields = Array<Text>{}, .params = Array<Text>{}}}, std::tuple{Text::lit("prelude::PreludeExceptions"), TyInfo{.kind = Text::lit("tag"), .fields = Array<Text>{}, .params = Array<Text>{}}}});
}


/// let preludeCtors
Map<Text, Text> prelude_ctors() {
    return map_of(std::vector{std::tuple{Text::lit("prelude::Ordering::Less"), Text::lit("choice")}, std::tuple{Text::lit("prelude::Ordering::Equal"), Text::lit("choice")}, std::tuple{Text::lit("prelude::Ordering::Greater"), Text::lit("choice")}});
}


/// let nodeBase
Map<Text, bool> node_base() {
    return map_of(std::vector{std::tuple{Text::lit("make"), true}, std::tuple{Text::lit("push"), true}, std::tuple{Text::lit("wake"), true}, std::tuple{Text::lit("started"), true}, std::tuple{Text::lit("deferred"), true}, std::tuple{Text::lit("build"), true}, std::tuple{Text::lit("swap"), true}, std::tuple{Text::lit("leave"), true}, std::tuple{Text::lit("patch"), true}, std::tuple{Text::lit("edges"), true}, std::tuple{Text::lit("release"), true}, std::tuple{Text::lit("clean_up"), true}, std::tuple{Text::lit("path"), true}, std::tuple{Text::lit("leave_row"), true}, std::tuple{Text::lit("answer"), true}, std::tuple{Text::lit("document"), true}, std::tuple{Text::lit("entries"), true}, std::tuple{Text::lit("deliver"), true}, std::tuple{Text::lit("document_moved"), true}, std::tuple{Text::lit("me"), true}, std::tuple{Text::lit("result_dynamic"), true}});
}


/// AddModelItem: fn Cp, Text, Item -> Cp
Cp add_model_item(const Cp& cp_p0, const Text& m_p1, const crate::lower::model::Item& it_p2) {
    if (prism_rtl::is<crate::lower::model::Item::ItType>(it_p2)) {
        auto&& t_p3 = prism_rtl::as<crate::lower::model::Item::ItType>(it_p2).a0;
        return add_type(cp_p0, m_p1, t_p3);
    }
    if (prism_rtl::is<crate::lower::model::Item::ItTag>(it_p2)) {
        auto&& t_p4 = prism_rtl::as<crate::lower::model::Item::ItTag>(it_p2).a0;
        return add_ty(cp_p0, prism_rtl::cat(m_p1, "::", prism_rtl::deref(t_p4).name), TyInfo{.kind = Text::lit("tag"), .fields = each(prism_rtl::deref(t_p4).fields, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
            auto&& f_p5 = std::get<1>(_p0);
            return f_p5;
        }), .params = Array<Text>{}});
    }
    if (prism_rtl::is<crate::lower::model::Item::ItRow>(it_p2)) {
        auto&& r_p6 = prism_rtl::as<crate::lower::model::Item::ItRow>(it_p2).a0;
        return add_row(cp_p0, m_p1, r_p6);
    }
    if (prism_rtl::is<crate::lower::model::Item::ItJob>(it_p2)) {
        auto&& j_p7 = prism_rtl::as<crate::lower::model::Item::ItJob>(it_p2).a0;
        return add_ty(cp_p0, prism_rtl::cat(m_p1, "::", prism_rtl::deref(j_p7).name), TyInfo{.kind = Text::lit("job"), .fields = each(prism_rtl::deref(j_p7).fields, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
            auto&& f_p8 = std::get<0>(_p0);
            return f_p8;
        }), .params = each(prism_rtl::deref(j_p7).generics, [&](const std::tuple<Text, Array<Text>>& _p0) {
            auto&& g_p9 = std::get<0>(_p0);
            return g_p9;
        })});
    }
    if (prism_rtl::is<crate::lower::model::Item::ItNode>(it_p2)) {
        auto&& n_pa = prism_rtl::as<crate::lower::model::Item::ItNode>(it_p2).a0;
        return add_node(cp_p0, m_p1, n_pa);
    }
    if (prism_rtl::is<crate::lower::model::Item::ItFn>(it_p2)) {
        auto&& f_pb = prism_rtl::as<crate::lower::model::Item::ItFn>(it_p2).a0;
        Cp this_ = cp_p0;
        this_.fns = insert(this_.fns, prism_rtl::cat(m_p1, "::", prism_rtl::deref(f_pb).name), true);
        return this_;
    }
    {
        return cp_p0;
    }
}


/// AddTy: fn Cp, Text, TyInfo -> Cp
Cp add_ty(const Cp& cp_p0, const Text& path_p1, const TyInfo& info_p2) {
    Cp this_ = cp_p0;
    this_.types = insert(this_.types, path_p1, info_p2);
    return this_;
}


/// AddCtor: fn Cp, Text, Text -> Cp
Cp add_ctor(const Cp& cp_p0, const Text& path_p1, const Text& kind_p2) {
    Cp this_ = cp_p0;
    this_.ctors = insert(this_.ctors, path_p1, kind_p2);
    return this_;
}


/// AddMember: fn Cp, Text -> Cp
Cp add_member(const Cp& cp_p0, const Text& name_p1) {
    Cp this_ = cp_p0;
    this_.members = insert(this_.members, name_p1, true);
    return this_;
}


/// AddType: fn Cp, Text, TyDef -> Cp
Cp add_type(const Cp& cp_p0, const Text& m_p1, const crate::lower::model::TyDef& t_p2) {
    auto path_p3 = prism_rtl::cat(m_p1, "::", t_p2.name);
    auto first_p4 = or_(index(t_p2.cases_, Nat(0u)), crate::lower::model::CaseDef{.name = Text::lit(""), .prism = Text::lit(""), .fields = Array<std::tuple<Text, crate::lower::model::OutTy>>{}});
    auto&& _m = t_p2.shape;
    if (prism_rtl::is<crate::lower::model::TyShape::ShapeRecord>(_m)) {
        return add_ty(cp_p0, path_p3, TyInfo{.kind = Text::lit("record"), .fields = each(prism_rtl::deref(first_p4).fields, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
            auto&& f_p5 = std::get<0>(_p0);
            return f_p5;
        }), .params = t_p2.params});
    }
    if (prism_rtl::is<crate::lower::model::TyShape::ShapeNewtype>(_m)) {
        return add_ty(cp_p0, path_p3, TyInfo{.kind = Text::lit("newtype"), .fields = Array<Text>{}, .params = t_p2.params});
    }
    if (prism_rtl::is<crate::lower::model::TyShape::ShapeUnit>(_m)) {
        return add_ty(cp_p0, path_p3, TyInfo{.kind = Text::lit("unit"), .fields = Array<Text>{}, .params = t_p2.params});
    }
    if (prism_rtl::is<crate::lower::model::TyShape::ShapeChoice>(_m)) {
        return fold(t_p2.cases_, add_ty(cp_p0, path_p3, TyInfo{.kind = Text::lit("choice"), .fields = Array<Text>{}, .params = t_p2.params}), [&](const Cp& c_p6, const crate::lower::model::CaseDef& k_p7) { return add_ctor(c_p6, prism_rtl::cat(path_p3, "::", prism_rtl::deref(k_p7).name), Text::lit("choice")); });
    }
    prism_rtl::unreachable("no arm matched");
}


/// AddRow: fn Cp, Text, RowDef -> Cp
Cp add_row(const Cp& cp_p0, const Text& m_p1, const crate::lower::model::RowDef& r_p2) {
    auto path_p3 = m_p1 == Text::lit("") ? r_p2.name : prism_rtl::cat(m_p1, "::", r_p2.name);
    return fold(r_p2.cases_, add_ty(cp_p0, path_p3, TyInfo{.kind = Text::lit("choice"), .fields = Array<Text>{}, .params = Array<Text>{}}), [&](const Cp& c_p4, const std::tuple<Text, Text>& _p1) {
        auto&& v_p5 = std::get<0>(_p1);
        return add_ctor(c_p4, prism_rtl::cat(path_p3, "::", v_p5), Text::lit("choice"));
    });
}


/// AddAnswer: fn Cp, AnswerDef -> Cp
Cp add_answer(const Cp& cp_p0, const crate::lower::model::AnswerDef& a_p1) {
    return fold(a_p1.cases_, add_ty(cp_p0, Text::lit("Answer"), TyInfo{.kind = Text::lit("choice"), .fields = Array<Text>{}, .params = Array<Text>{}}), [&](const Cp& c_p2, const crate::lower::model::AnswerCase& k_p3) { return add_ctor(c_p2, prism_rtl::cat("Answer::", prism_rtl::deref(k_p3).variant), Text::lit("choice")); });
}


/// AddNode: fn Cp, Text, NodeDef -> Cp
Cp add_node(const Cp& cp_p0, const Text& m_p1, const crate::lower::model::NodeDef& n_p2) {
    auto with_fields_p3 = fold(n_p2.fields, cp_p0, [&](const Cp& c_p7, const std::tuple<Text, crate::lower::model::OutTy, Text>& _p1) {
        auto&& f_p8 = std::get<0>(_p1);
        return ({
            Cp this_ = add_member(c_p7, f_p8);
            this_.field_names = insert(this_.field_names, f_p8, true);
            (std::move(this_));
        });
    });
    auto with_methods_p4 = fold(append(n_p2.methods, n_p2.hosted), with_fields_p3, [&](const Cp& c_p9, const crate::lower::model::MethDef& md_pa) {
        return ({
            Cp this_ = add_member(c_p9, prism_rtl::deref(md_pa).name);
            this_.methods = insert(this_.methods, prism_rtl::deref(md_pa).name, true);
            (std::move(this_));
        });
    });
    auto with_builders_p5 = fold(n_p2.builders, with_methods_p4, [&](const Cp& c_pb, const crate::lower::model::ForDef& b_pc) { return add_member(c_pb, prism_rtl::cat(prism_rtl::deref(b_pc).name, "_build")); });
    auto with_gens_p6 = fold(n_p2.gens, with_builders_p5, [&](const Cp& c_pd, const crate::lower::model::GenDef& g_pe) { return add_member(c_pd, prism_rtl::cat(prism_rtl::deref(g_pe).name, "_build")); });
    return add_ty(with_gens_p6, prism_rtl::cat(m_p1, "::", n_p2.name), TyInfo{.kind = Text::lit("node"), .fields = each(n_p2.fields, [&](const std::tuple<Text, crate::lower::model::OutTy, Text>& _p0) {
        auto&& f_pf = std::get<0>(_p0);
        return f_pf;
    }), .params = Array<Text>{}});
}


/// InHome: fn Cp, Text -> Cp
Cp in_home(const Cp& cp_p0, const Text& m_p1) {
    Cp this_ = cp_p0;
    this_.home = m_p1;
    return this_;
}


/// WithFields: fn Cp, [((Text, OutTy))] -> Cp
Cp with_fields(const Cp& cp_p0, const Array<std::tuple<Text, crate::lower::model::OutTy>>& fs_p1) {
    Cp this_ = cp_p0;
    this_.fields = fold(fs_p1, Map<Text, crate::lower::model::OutTy>{}, [&](const Map<Text, crate::lower::model::OutTy>& acc_p2, const std::tuple<Text, crate::lower::model::OutTy>& _p1) {
        auto&& f_p3 = std::get<0>(_p1);
        auto&& t_p4 = std::get<1>(_p1);
        return insert(acc_p2, f_p3, t_p4);
    });
    return this_;
}


/// CppType: unbounded fn Cp, OutTy -> Text
Text cpp_type(const Cp& cp_p0, const crate::lower::model::OutTy& t_p1) {
    if (prism_rtl::is<crate::lower::model::OutTy::OutNat>(t_p1)) {
        return Text::lit("Nat");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutInt>(t_p1)) {
        return Text::lit("Int");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutU8>(t_p1)) {
        return Text::lit("std::uint8_t");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutFloat>(t_p1)) {
        return Text::lit("Float");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutBool>(t_p1)) {
        return Text::lit("bool");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutChar>(t_p1)) {
        return Text::lit("char32_t");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutText>(t_p1)) {
        return Text::lit("Text");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutCursor>(t_p1)) {
        return Text::lit("Cursor");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutRegex>(t_p1)) {
        return Text::lit("Regex");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutReplacement>(t_p1)) {
        return Text::lit("RegexReplacement");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutUnit>(t_p1)) {
        return Text::lit("Unit");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutPath>(t_p1)) {
        return Text::lit("Path");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutDuration>(t_p1)) {
        return Text::lit("Duration");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutError>(t_p1)) {
        return Text::lit("Error");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t_p1)) {
        auto&& m11561_14_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p1).a0;
        auto&& m11561_14_1 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p1).a1;
        if (m11561_14_0 == Text::lit("Cell")) {
            if (m11561_14_1.size() == 1u) {
                {
                    auto&& _c1 = index(m11561_14_1, Nat(0u));
                    if (prism_rtl::is_some(_c1)) {
                        auto&& i_p2 = prism_rtl::some_of(_c1);
                        return cpp_type(cp_p0, i_p2);
                    }
                }
            }
        }
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t_p1)) {
        auto&& m11561_15_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p1).a0;
        auto&& m11561_15_1 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p1).a1;
        if (m11561_15_0 == Text::lit("RefCell")) {
            if (m11561_15_1.size() == 1u) {
                {
                    auto&& _c1 = index(m11561_15_1, Nat(0u));
                    if (prism_rtl::is_some(_c1)) {
                        auto&& i_p3 = prism_rtl::some_of(_c1);
                        return cpp_type(cp_p0, i_p3);
                    }
                }
            }
        }
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t_p1)) {
        auto&& m11561_16_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p1).a0;
        auto&& m11561_16_1 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p1).a1;
        if (m11561_16_0 == Text::lit("Vec")) {
            if (m11561_16_1.size() == 1u) {
                {
                    auto&& _c1 = index(m11561_16_1, Nat(0u));
                    if (prism_rtl::is_some(_c1)) {
                        auto&& i_p4 = prism_rtl::some_of(_c1);
                        return prism_rtl::cat("std::vector<", cpp_type(cp_p0, i_p4), ">");
                    }
                }
            }
        }
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t_p1)) {
        auto&& m11561_17_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p1).a0;
        auto&& m11561_17_1 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p1).a1;
        if (m11561_17_0 == Text::lit("Result")) {
            if (m11561_17_1.size() == 2u) {
                {
                    auto&& _c2 = index(m11561_17_1, Nat(0u));
                    if (prism_rtl::is_some(_c2)) {
                        auto&& a_p5 = prism_rtl::some_of(_c2);
                        {
                            auto&& _c1 = index(m11561_17_1, Nat(1u));
                            if (prism_rtl::is_some(_c1)) {
                                auto&& b_p6 = prism_rtl::some_of(_c1);
                                return prism_rtl::cat("Expected<", cpp_type(cp_p0, a_p5), ", ", cpp_type(cp_p0, b_p6), ">");
                            }
                        }
                    }
                }
            }
        }
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t_p1)) {
        auto&& n_p7 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p1).a0;
        auto&& m11561_18_1 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p1).a1;
        if (m11561_18_1.size() == 0u) {
            return own_type_path(cp_p0, n_p7);
        }
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t_p1)) {
        auto&& n_p8 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p1).a0;
        auto&& args_p9 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p1).a1;
        return prism_rtl::cat(own_type_path(cp_p0, n_p8), "<", cpp_types(cp_p0, args_p9), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutOpt>(t_p1)) {
        auto&& i_pa = prism_rtl::as<crate::lower::model::OutTy::OutOpt>(t_p1).a0;
        return prism_rtl::cat("std::optional<", cpp_type(cp_p0, prism_rtl::deref(prism_rtl::deref(i_pa))), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutRes>(t_p1)) {
        auto&& i_pb = prism_rtl::as<crate::lower::model::OutTy::OutRes>(t_p1).a0;
        return prism_rtl::cat("Fallible<", cpp_type(cp_p0, prism_rtl::deref(prism_rtl::deref(i_pb))), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutTuple>(t_p1)) {
        auto&& ts_pc = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(t_p1).a0;
        return prism_rtl::cat("std::tuple<", cpp_types(cp_p0, ts_pc), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutArray>(t_p1)) {
        auto&& e_pd = prism_rtl::as<crate::lower::model::OutTy::OutArray>(t_p1).a0;
        return prism_rtl::cat("Array<", cpp_type(cp_p0, prism_rtl::deref(prism_rtl::deref(e_pd))), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutMap>(t_p1)) {
        auto&& k_pe = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t_p1).a0;
        auto&& v_pf = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t_p1).a1;
        return prism_rtl::cat("Map<", cpp_type(cp_p0, prism_rtl::deref(prism_rtl::deref(k_pe))), ", ", cpp_type(cp_p0, prism_rtl::deref(prism_rtl::deref(v_pf))), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutFn>(t_p1)) {
        auto&& ps_pg = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t_p1).a0;
        auto&& r_ph = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t_p1).a1;
        return prism_rtl::cat("Fn<", cpp_type(cp_p0, prism_rtl::deref(prism_rtl::deref(r_ph))), "(", param_types(cp_p0, ps_pg), ")>");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutRef>(t_p1)) {
        auto&& m11561_26_0 = prism_rtl::as<crate::lower::model::OutTy::OutRef>(t_p1).a0;
        if (prism_rtl::is<crate::lower::model::OutTy::OutFn>(prism_rtl::deref(prism_rtl::deref(m11561_26_0)))) {
            auto&& ps_pi = prism_rtl::as<crate::lower::model::OutTy::OutFn>(prism_rtl::deref(prism_rtl::deref(m11561_26_0))).a0;
            auto&& r_pj = prism_rtl::as<crate::lower::model::OutTy::OutFn>(prism_rtl::deref(prism_rtl::deref(m11561_26_0))).a1;
            return prism_rtl::cat("const std::function<", cpp_type(cp_p0, prism_rtl::deref(prism_rtl::deref(r_pj))), "(", param_types(cp_p0, ps_pi), ")>&");
        }
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutRef>(t_p1)) {
        auto&& m11561_27_0 = prism_rtl::as<crate::lower::model::OutTy::OutRef>(t_p1).a0;
        if (prism_rtl::is<crate::lower::model::OutTy::OutSlice>(prism_rtl::deref(prism_rtl::deref(m11561_27_0)))) {
            auto&& i_pk = prism_rtl::as<crate::lower::model::OutTy::OutSlice>(prism_rtl::deref(prism_rtl::deref(m11561_27_0))).a0;
            return prism_rtl::cat("std::span<const ", cpp_type(cp_p0, prism_rtl::deref(prism_rtl::deref(i_pk))), ">");
        }
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutRef>(t_p1)) {
        auto&& i_pl = prism_rtl::as<crate::lower::model::OutTy::OutRef>(t_p1).a0;
        return prism_rtl::cat("const ", cpp_type(cp_p0, prism_rtl::deref(prism_rtl::deref(i_pl))), "&");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(t_p1)) {
        auto&& a_pm = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(t_p1).a0;
        auto&& b_pn = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(t_p1).a1;
        return prism_rtl::cat("prism_rtl::Fn<prism_rtl::JobRef<", cpp_type(cp_p0, prism_rtl::deref(prism_rtl::deref(b_pn))), ">(", cpp_type(cp_p0, prism_rtl::deref(prism_rtl::deref(a_pm))), ")>");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutJob>(t_p1)) {
        auto&& b_po = prism_rtl::as<crate::lower::model::OutTy::OutJob>(t_p1).a0;
        return prism_rtl::cat("prism_rtl::JobRef<", cpp_type(cp_p0, prism_rtl::deref(prism_rtl::deref(b_po))), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutEvent>(t_p1)) {
        auto&& i_pp = prism_rtl::as<crate::lower::model::OutTy::OutEvent>(t_p1).a0;
        return prism_rtl::cat("Event<", cpp_type(cp_p0, prism_rtl::deref(prism_rtl::deref(i_pp))), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutDyn>(t_p1)) {
        auto&& i_pq = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(t_p1).a0;
        return prism_rtl::cat("Dynamic<", cpp_type(cp_p0, prism_rtl::deref(prism_rtl::deref(i_pq))), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutGen>(t_p1)) {
        auto&& n_pr = prism_rtl::as<crate::lower::model::OutTy::OutGen>(t_p1).a0;
        return n_pr;
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutRc>(t_p1)) {
        auto&& i_ps = prism_rtl::as<crate::lower::model::OutTy::OutRc>(t_p1).a0;
        return is_value_ty(cp_p0, prism_rtl::deref(prism_rtl::deref(i_ps)))
            ? prism_rtl::cat("prism_rtl::Rc<const ", cpp_type(cp_p0, prism_rtl::deref(prism_rtl::deref(i_ps))), ">")
            : prism_rtl::cat("prism_rtl::Rc<", cpp_type(cp_p0, prism_rtl::deref(prism_rtl::deref(i_ps))), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutPod>(t_p1)) {
        return Text::lit("Pod");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutShowAny>(t_p1)) {
        return Text::lit("prism_rtl::Rc<const DynShow>");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutHold>(t_p1)) {
        auto&& i_pt = prism_rtl::as<crate::lower::model::OutTy::OutHold>(t_p1).a0;
        return prism_rtl::cat("Hold<", cpp_type(cp_p0, prism_rtl::deref(prism_rtl::deref(i_pt))), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutStamped>(t_p1)) {
        auto&& i_pu = prism_rtl::as<crate::lower::model::OutTy::OutStamped>(t_p1).a0;
        return prism_rtl::cat("Stamped<", cpp_type(cp_p0, prism_rtl::deref(prism_rtl::deref(i_pu))), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutSnapshot>(t_p1)) {
        auto&& i_pv = prism_rtl::as<crate::lower::model::OutTy::OutSnapshot>(t_p1).a0;
        return prism_rtl::cat("Snapshot<", cpp_type(cp_p0, prism_rtl::deref(prism_rtl::deref(i_pv))), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutDefer>(t_p1)) {
        auto&& i_p10 = prism_rtl::as<crate::lower::model::OutTy::OutDefer>(t_p1).a0;
        return prism_rtl::cat("Defer<", cpp_type(cp_p0, prism_rtl::deref(prism_rtl::deref(i_p10))), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutWeak>(t_p1)) {
        auto&& n_p11 = prism_rtl::as<crate::lower::model::OutTy::OutWeak>(t_p1).a0;
        return prism_rtl::cat("prism_rtl::Weak<", type_path(n_p11), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutCell>(t_p1)) {
        auto&& i_p12 = prism_rtl::as<crate::lower::model::OutTy::OutCell>(t_p1).a0;
        return cpp_type(cp_p0, prism_rtl::deref(prism_rtl::deref(i_p12)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutWakes>(t_p1)) {
        return Text::lit("Wakes");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutCount>(t_p1)) {
        return Text::lit("std::uint32_t");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutObj>(t_p1)) {
        auto&& i_p13 = prism_rtl::as<crate::lower::model::OutTy::OutObj>(t_p1).a0;
        return prism_rtl::cat("prism_rtl::Rc<", cpp_type(cp_p0, prism_rtl::deref(prism_rtl::deref(i_p13))), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutSlice>(t_p1)) {
        auto&& i_p14 = prism_rtl::as<crate::lower::model::OutTy::OutSlice>(t_p1).a0;
        return prism_rtl::cat("std::span<const ", cpp_type(cp_p0, prism_rtl::deref(prism_rtl::deref(i_p14))), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutPort>(t_p1)) {
        auto&& i_p15 = prism_rtl::as<crate::lower::model::OutTy::OutPort>(t_p1).a0;
        return prism_rtl::cat("Port<", cpp_type(cp_p0, prism_rtl::deref(prism_rtl::deref(i_p15))), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutLive>(t_p1)) {
        auto&& i_p16 = prism_rtl::as<crate::lower::model::OutTy::OutLive>(t_p1).a0;
        return prism_rtl::cat("Live<", cpp_type(cp_p0, prism_rtl::deref(prism_rtl::deref(i_p16))), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutUnknown>(t_p1)) {
        auto&& m11561_49_0 = prism_rtl::as<crate::lower::model::OutTy::OutUnknown>(t_p1).a0;
        if (m11561_49_0 == Text::lit("the job\'s turn")) {
            return Text::lit("decltype(this->cycle())");
        }
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutUnknown>(t_p1)) {
        auto&& what_p17 = prism_rtl::as<crate::lower::model::OutTy::OutUnknown>(t_p1).a0;
        return prism_rtl::cat("Unit /* ", what_p17, " */");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutQuantified>(t_p1)) {
        auto&& b_p18 = prism_rtl::as<crate::lower::model::OutTy::OutQuantified>(t_p1).a0;
        return prism_rtl::cat("compile_error!(\"", crate::lower::expr::lowering_refusal(), "a quantified type variable of `", b_p18, "`: no instantiation gives it a type\")");
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Text> CppType::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& t_p1 = this->t_p1;
    return ({
        prism_rtl::is<crate::lower::model::OutTy::OutNat>(t_p1) ? prism_rtl::finished(Text::lit("Nat"))
        : prism_rtl::is<crate::lower::model::OutTy::OutInt>(t_p1) ? prism_rtl::finished(Text::lit("Int"))
        : prism_rtl::is<crate::lower::model::OutTy::OutU8>(t_p1) ? prism_rtl::finished(Text::lit("std::uint8_t"))
        : prism_rtl::is<crate::lower::model::OutTy::OutFloat>(t_p1) ? prism_rtl::finished(Text::lit("Float"))
        : prism_rtl::is<crate::lower::model::OutTy::OutBool>(t_p1) ? prism_rtl::finished(Text::lit("bool"))
        : prism_rtl::is<crate::lower::model::OutTy::OutChar>(t_p1) ? prism_rtl::finished(Text::lit("char32_t"))
        : prism_rtl::is<crate::lower::model::OutTy::OutText>(t_p1) ? prism_rtl::finished(Text::lit("Text"))
        : prism_rtl::is<crate::lower::model::OutTy::OutCursor>(t_p1) ? prism_rtl::finished(Text::lit("Cursor"))
        : prism_rtl::is<crate::lower::model::OutTy::OutRegex>(t_p1) ? prism_rtl::finished(Text::lit("Regex"))
        : prism_rtl::is<crate::lower::model::OutTy::OutReplacement>(t_p1) ? prism_rtl::finished(Text::lit("RegexReplacement"))
        : prism_rtl::is<crate::lower::model::OutTy::OutUnit>(t_p1) ? prism_rtl::finished(Text::lit("Unit"))
        : prism_rtl::is<crate::lower::model::OutTy::OutPath>(t_p1) ? prism_rtl::finished(Text::lit("Path"))
        : prism_rtl::is<crate::lower::model::OutTy::OutDuration>(t_p1) ? prism_rtl::finished(Text::lit("Duration"))
        : prism_rtl::is<crate::lower::model::OutTy::OutError>(t_p1) ? prism_rtl::finished(Text::lit("Error"))
        : prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t_p1) && ({
        auto&& m11561_14_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p1).a0;
        auto&& m11561_14_1 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p1).a1;
        (m11561_14_0 == Text::lit("Cell")) && (m11561_14_1.size() == 1u) && ({
        auto&& _c1 = index(m11561_14_1, Nat(0u));
        prism_rtl::is_some(_c1);
    });
    }) ? ({
        auto&& m11561_14_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p1).a0;
        auto&& m11561_14_1 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p1).a1;
        auto&& _c1 = index(m11561_14_1, Nat(0u));
        auto&& i_p2 = prism_rtl::some_of(_c1);
        prism_rtl::more(prism_rtl::rc(CppType(cp_p0, i_p2)));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t_p1) && ({
        auto&& m11561_15_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p1).a0;
        auto&& m11561_15_1 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p1).a1;
        (m11561_15_0 == Text::lit("RefCell")) && (m11561_15_1.size() == 1u) && ({
        auto&& _c1 = index(m11561_15_1, Nat(0u));
        prism_rtl::is_some(_c1);
    });
    }) ? ({
        auto&& m11561_15_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p1).a0;
        auto&& m11561_15_1 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p1).a1;
        auto&& _c1 = index(m11561_15_1, Nat(0u));
        auto&& i_p3 = prism_rtl::some_of(_c1);
        prism_rtl::more(prism_rtl::rc(CppType(cp_p0, i_p3)));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t_p1) && ({
        auto&& m11561_16_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p1).a0;
        auto&& m11561_16_1 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p1).a1;
        (m11561_16_0 == Text::lit("Vec")) && (m11561_16_1.size() == 1u) && ({
        auto&& _c1 = index(m11561_16_1, Nat(0u));
        prism_rtl::is_some(_c1);
    });
    }) ? ({
        auto&& m11561_16_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p1).a0;
        auto&& m11561_16_1 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p1).a1;
        auto&& _c1 = index(m11561_16_1, Nat(0u));
        auto&& i_p4 = prism_rtl::some_of(_c1);
        ({
        auto cp_p0_1 = cp_p0;
        call_then(start_cpp_type(cp_p0_1, i_p4), [=](Text cpp_type_12021) { return prism_rtl::finished(prism_rtl::cat("std::vector<", cpp_type_12021, ">")); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t_p1) && ({
        auto&& m11561_17_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p1).a0;
        auto&& m11561_17_1 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p1).a1;
        (m11561_17_0 == Text::lit("Result")) && (m11561_17_1.size() == 2u) && ({
        auto&& _c2 = index(m11561_17_1, Nat(0u));
        prism_rtl::is_some(_c2) && ({
        auto&& a_p5 = prism_rtl::some_of(_c2);
        ({
        auto&& _c1 = index(m11561_17_1, Nat(1u));
        prism_rtl::is_some(_c1);
    });
    });
    });
    }) ? ({
        auto&& m11561_17_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p1).a0;
        auto&& m11561_17_1 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p1).a1;
        auto&& _c2 = index(m11561_17_1, Nat(0u));
        auto&& a_p5 = prism_rtl::some_of(_c2);
        auto&& _c1 = index(m11561_17_1, Nat(1u));
        auto&& b_p6 = prism_rtl::some_of(_c1);
        ({
        auto cp_p0_1 = cp_p0;
        call_then(start_cpp_type(cp_p0_1, a_p5), [=](Text cpp_type_12082) { return call_then(start_cpp_type(cp_p0_1, b_p6), [=](Text cpp_type_12099) { return prism_rtl::finished(prism_rtl::cat("Expected<", cpp_type_12082, ", ", cpp_type_12099, ">")); }); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t_p1) && ({
        auto&& n_p7 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p1).a0;
        auto&& m11561_18_1 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p1).a1;
        (m11561_18_1.size() == 0u);
    }) ? ({
        auto&& n_p7 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p1).a0;
        auto&& m11561_18_1 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p1).a1;
        prism_rtl::finished(own_type_path(cp_p0, n_p7));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t_p1) ? ({
        auto&& n_p8 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p1).a0;
        auto&& args_p9 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p1).a1;
        ({
        auto args_p9_1 = args_p9;
        auto cp_p0_2 = cp_p0;
        auto n_p8_3 = n_p8;
        call_then(start_cpp_types(cp_p0_2, args_p9_1), [=, n_p8_3 = std::move(n_p8_3)](Text cpp_types_12200) { return prism_rtl::finished(prism_rtl::cat(own_type_path(cp_p0_2, n_p8_3), "<", cpp_types_12200, ">")); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutOpt>(t_p1) ? ({
        auto&& i_pa = prism_rtl::as<crate::lower::model::OutTy::OutOpt>(t_p1).a0;
        ({
        auto cp_p0_1 = cp_p0;
        auto i_pa_2 = prism_rtl::deref(prism_rtl::deref(i_pa));
        call_then(start_cpp_type(cp_p0_1, i_pa_2), [=](Text cpp_type_12251) { return prism_rtl::finished(prism_rtl::cat("std::optional<", cpp_type_12251, ">")); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutRes>(t_p1) ? ({
        auto&& i_pb = prism_rtl::as<crate::lower::model::OutTy::OutRes>(t_p1).a0;
        ({
        auto cp_p0_1 = cp_p0;
        auto i_pb_2 = prism_rtl::deref(prism_rtl::deref(i_pb));
        call_then(start_cpp_type(cp_p0_1, i_pb_2), [=](Text cpp_type_12293) { return prism_rtl::finished(prism_rtl::cat("Fallible<", cpp_type_12293, ">")); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutTuple>(t_p1) ? ({
        auto&& ts_pc = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(t_p1).a0;
        ({
        auto cp_p0_1 = cp_p0;
        auto ts_pc_2 = ts_pc;
        call_then(start_cpp_types(cp_p0_1, ts_pc_2), [=](Text cpp_types_12340) { return prism_rtl::finished(prism_rtl::cat("std::tuple<", cpp_types_12340, ">")); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutArray>(t_p1) ? ({
        auto&& e_pd = prism_rtl::as<crate::lower::model::OutTy::OutArray>(t_p1).a0;
        ({
        auto cp_p0_1 = cp_p0;
        auto e_pd_2 = prism_rtl::deref(prism_rtl::deref(e_pd));
        call_then(start_cpp_type(cp_p0_1, e_pd_2), [=](Text cpp_type_12383) { return prism_rtl::finished(prism_rtl::cat("Array<", cpp_type_12383, ">")); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutMap>(t_p1) ? ({
        auto&& k_pe = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t_p1).a0;
        auto&& v_pf = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t_p1).a1;
        ({
        auto cp_p0_1 = cp_p0;
        auto k_pe_2 = prism_rtl::deref(prism_rtl::deref(k_pe));
        auto v_pf_3 = prism_rtl::deref(prism_rtl::deref(v_pf));
        call_then(start_cpp_type(cp_p0_1, k_pe_2), [=, v_pf_3 = std::move(v_pf_3)](Text cpp_type_12423) { return call_then(start_cpp_type(cp_p0_1, v_pf_3), [=](Text cpp_type_12440) { return prism_rtl::finished(prism_rtl::cat("Map<", cpp_type_12423, ", ", cpp_type_12440, ">")); }); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutFn>(t_p1) ? ({
        auto&& ps_pg = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t_p1).a0;
        auto&& r_ph = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t_p1).a1;
        ({
        auto cp_p0_1 = cp_p0;
        auto ps_pg_2 = ps_pg;
        auto r_ph_3 = prism_rtl::deref(prism_rtl::deref(r_ph));
        call_then(start_cpp_type(cp_p0_1, r_ph_3), [=, ps_pg_2 = std::move(ps_pg_2)](Text cpp_type_12479) { return call_then(start_param_types(cp_p0_1, ps_pg_2), [=](Text param_types_12495) { return prism_rtl::finished(prism_rtl::cat("Fn<", cpp_type_12479, "(", param_types_12495, ")>")); }); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutRef>(t_p1) && ({
        auto&& m11561_26_0 = prism_rtl::as<crate::lower::model::OutTy::OutRef>(t_p1).a0;
        prism_rtl::is<crate::lower::model::OutTy::OutFn>(prism_rtl::deref(prism_rtl::deref(m11561_26_0)));
    }) ? ({
        auto&& m11561_26_0 = prism_rtl::as<crate::lower::model::OutTy::OutRef>(t_p1).a0;
        auto&& ps_pi = prism_rtl::as<crate::lower::model::OutTy::OutFn>(prism_rtl::deref(prism_rtl::deref(m11561_26_0))).a0;
        auto&& r_pj = prism_rtl::as<crate::lower::model::OutTy::OutFn>(prism_rtl::deref(prism_rtl::deref(m11561_26_0))).a1;
        ({
        auto cp_p0_1 = cp_p0;
        auto ps_pi_2 = ps_pi;
        auto r_pj_3 = prism_rtl::deref(prism_rtl::deref(r_pj));
        call_then(start_cpp_type(cp_p0_1, r_pj_3), [=, ps_pi_2 = std::move(ps_pi_2)](Text cpp_type_12565) { return call_then(start_param_types(cp_p0_1, ps_pi_2), [=](Text param_types_12581) { return prism_rtl::finished(prism_rtl::cat("const std::function<", cpp_type_12565, "(", param_types_12581, ")>&")); }); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutRef>(t_p1) && ({
        auto&& m11561_27_0 = prism_rtl::as<crate::lower::model::OutTy::OutRef>(t_p1).a0;
        prism_rtl::is<crate::lower::model::OutTy::OutSlice>(prism_rtl::deref(prism_rtl::deref(m11561_27_0)));
    }) ? ({
        auto&& m11561_27_0 = prism_rtl::as<crate::lower::model::OutTy::OutRef>(t_p1).a0;
        auto&& i_pk = prism_rtl::as<crate::lower::model::OutTy::OutSlice>(prism_rtl::deref(prism_rtl::deref(m11561_27_0))).a0;
        ({
        auto cp_p0_1 = cp_p0;
        auto i_pk_2 = prism_rtl::deref(prism_rtl::deref(i_pk));
        call_then(start_cpp_type(cp_p0_1, i_pk_2), [=](Text cpp_type_12647) { return prism_rtl::finished(prism_rtl::cat("std::span<const ", cpp_type_12647, ">")); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutRef>(t_p1) ? ({
        auto&& i_pl = prism_rtl::as<crate::lower::model::OutTy::OutRef>(t_p1).a0;
        ({
        auto cp_p0_1 = cp_p0;
        auto i_pl_2 = prism_rtl::deref(prism_rtl::deref(i_pl));
        call_then(start_cpp_type(cp_p0_1, i_pl_2), [=](Text cpp_type_12686) { return prism_rtl::finished(prism_rtl::cat("const ", cpp_type_12686, "&")); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(t_p1) ? ({
        auto&& a_pm = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(t_p1).a0;
        auto&& b_pn = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(t_p1).a1;
        ({
        auto a_pm_1 = prism_rtl::deref(prism_rtl::deref(a_pm));
        auto b_pn_2 = prism_rtl::deref(prism_rtl::deref(b_pn));
        auto cp_p0_3 = cp_p0;
        call_then(start_cpp_type(cp_p0_3, b_pn_2), [=, a_pm_1 = std::move(a_pm_1)](Text cpp_type_12756) { return call_then(start_cpp_type(cp_p0_3, a_pm_1), [=](Text cpp_type_12773) { return prism_rtl::finished(prism_rtl::cat("prism_rtl::Fn<prism_rtl::JobRef<", cpp_type_12756, ">(", cpp_type_12773, ")>")); }); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutJob>(t_p1) ? ({
        auto&& b_po = prism_rtl::as<crate::lower::model::OutTy::OutJob>(t_p1).a0;
        ({
        auto b_po_1 = prism_rtl::deref(prism_rtl::deref(b_po));
        auto cp_p0_2 = cp_p0;
        call_then(start_cpp_type(cp_p0_2, b_po_1), [=](Text cpp_type_12825) { return prism_rtl::finished(prism_rtl::cat("prism_rtl::JobRef<", cpp_type_12825, ">")); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutEvent>(t_p1) ? ({
        auto&& i_pp = prism_rtl::as<crate::lower::model::OutTy::OutEvent>(t_p1).a0;
        ({
        auto cp_p0_1 = cp_p0;
        auto i_pp_2 = prism_rtl::deref(prism_rtl::deref(i_pp));
        call_then(start_cpp_type(cp_p0_1, i_pp_2), [=](Text cpp_type_12866) { return prism_rtl::finished(prism_rtl::cat("Event<", cpp_type_12866, ">")); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutDyn>(t_p1) ? ({
        auto&& i_pq = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(t_p1).a0;
        ({
        auto cp_p0_1 = cp_p0;
        auto i_pq_2 = prism_rtl::deref(prism_rtl::deref(i_pq));
        call_then(start_cpp_type(cp_p0_1, i_pq_2), [=](Text cpp_type_12907) { return prism_rtl::finished(prism_rtl::cat("Dynamic<", cpp_type_12907, ">")); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutGen>(t_p1) ? ({
        auto&& n_pr = prism_rtl::as<crate::lower::model::OutTy::OutGen>(t_p1).a0;
        prism_rtl::finished(n_pr);
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutRc>(t_p1) ? ({
        auto&& i_ps = prism_rtl::as<crate::lower::model::OutTy::OutRc>(t_p1).a0;
        is_value_ty(cp_p0, prism_rtl::deref(prism_rtl::deref(i_ps)))
        ? ({
        auto cp_p0_1 = cp_p0;
        auto i_ps_2 = prism_rtl::deref(prism_rtl::deref(i_ps));
        call_then(start_cpp_type(cp_p0_1, i_ps_2), [=](Text cpp_type_12995) { return prism_rtl::finished(prism_rtl::cat("prism_rtl::Rc<const ", cpp_type_12995, ">")); });
    })
        : ({
        auto cp_p0_1 = cp_p0;
        auto i_ps_2 = prism_rtl::deref(prism_rtl::deref(i_ps));
        call_then(start_cpp_type(cp_p0_1, i_ps_2), [=](Text cpp_type_13034) { return prism_rtl::finished(prism_rtl::cat("prism_rtl::Rc<", cpp_type_13034, ">")); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutPod>(t_p1) ? prism_rtl::finished(Text::lit("Pod"))
        : prism_rtl::is<crate::lower::model::OutTy::OutShowAny>(t_p1) ? prism_rtl::finished(Text::lit("prism_rtl::Rc<const DynShow>"))
        : prism_rtl::is<crate::lower::model::OutTy::OutHold>(t_p1) ? ({
        auto&& i_pt = prism_rtl::as<crate::lower::model::OutTy::OutHold>(t_p1).a0;
        ({
        auto cp_p0_1 = cp_p0;
        auto i_pt_2 = prism_rtl::deref(prism_rtl::deref(i_pt));
        call_then(start_cpp_type(cp_p0_1, i_pt_2), [=](Text cpp_type_13138) { return prism_rtl::finished(prism_rtl::cat("Hold<", cpp_type_13138, ">")); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutStamped>(t_p1) ? ({
        auto&& i_pu = prism_rtl::as<crate::lower::model::OutTy::OutStamped>(t_p1).a0;
        ({
        auto cp_p0_1 = cp_p0;
        auto i_pu_2 = prism_rtl::deref(prism_rtl::deref(i_pu));
        call_then(start_cpp_type(cp_p0_1, i_pu_2), [=](Text cpp_type_13183) { return prism_rtl::finished(prism_rtl::cat("Stamped<", cpp_type_13183, ">")); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutSnapshot>(t_p1) ? ({
        auto&& i_pv = prism_rtl::as<crate::lower::model::OutTy::OutSnapshot>(t_p1).a0;
        ({
        auto cp_p0_1 = cp_p0;
        auto i_pv_2 = prism_rtl::deref(prism_rtl::deref(i_pv));
        call_then(start_cpp_type(cp_p0_1, i_pv_2), [=](Text cpp_type_13230) { return prism_rtl::finished(prism_rtl::cat("Snapshot<", cpp_type_13230, ">")); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutDefer>(t_p1) ? ({
        auto&& i_p10 = prism_rtl::as<crate::lower::model::OutTy::OutDefer>(t_p1).a0;
        ({
        auto cp_p0_1 = cp_p0;
        auto i_p10_2 = prism_rtl::deref(prism_rtl::deref(i_p10));
        call_then(start_cpp_type(cp_p0_1, i_p10_2), [=](Text cpp_type_13271) { return prism_rtl::finished(prism_rtl::cat("Defer<", cpp_type_13271, ">")); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutWeak>(t_p1) ? ({
        auto&& n_p11 = prism_rtl::as<crate::lower::model::OutTy::OutWeak>(t_p1).a0;
        prism_rtl::finished(prism_rtl::cat("prism_rtl::Weak<", type_path(n_p11), ">"));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutCell>(t_p1) ? ({
        auto&& i_p12 = prism_rtl::as<crate::lower::model::OutTy::OutCell>(t_p1).a0;
        prism_rtl::more(prism_rtl::rc(CppType(cp_p0, prism_rtl::deref(prism_rtl::deref(i_p12)))));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutWakes>(t_p1) ? prism_rtl::finished(Text::lit("Wakes"))
        : prism_rtl::is<crate::lower::model::OutTy::OutCount>(t_p1) ? prism_rtl::finished(Text::lit("std::uint32_t"))
        : prism_rtl::is<crate::lower::model::OutTy::OutObj>(t_p1) ? ({
        auto&& i_p13 = prism_rtl::as<crate::lower::model::OutTy::OutObj>(t_p1).a0;
        ({
        auto cp_p0_1 = cp_p0;
        auto i_p13_2 = prism_rtl::deref(prism_rtl::deref(i_p13));
        call_then(start_cpp_type(cp_p0_1, i_p13_2), [=](Text cpp_type_13446) { return prism_rtl::finished(prism_rtl::cat("prism_rtl::Rc<", cpp_type_13446, ">")); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutSlice>(t_p1) ? ({
        auto&& i_p14 = prism_rtl::as<crate::lower::model::OutTy::OutSlice>(t_p1).a0;
        ({
        auto cp_p0_1 = cp_p0;
        auto i_p14_2 = prism_rtl::deref(prism_rtl::deref(i_p14));
        call_then(start_cpp_type(cp_p0_1, i_p14_2), [=](Text cpp_type_13497) { return prism_rtl::finished(prism_rtl::cat("std::span<const ", cpp_type_13497, ">")); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutPort>(t_p1) ? ({
        auto&& i_p15 = prism_rtl::as<crate::lower::model::OutTy::OutPort>(t_p1).a0;
        ({
        auto cp_p0_1 = cp_p0;
        auto i_p15_2 = prism_rtl::deref(prism_rtl::deref(i_p15));
        call_then(start_cpp_type(cp_p0_1, i_p15_2), [=](Text cpp_type_13536) { return prism_rtl::finished(prism_rtl::cat("Port<", cpp_type_13536, ">")); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutLive>(t_p1) ? ({
        auto&& i_p16 = prism_rtl::as<crate::lower::model::OutTy::OutLive>(t_p1).a0;
        ({
        auto cp_p0_1 = cp_p0;
        auto i_p16_2 = prism_rtl::deref(prism_rtl::deref(i_p16));
        call_then(start_cpp_type(cp_p0_1, i_p16_2), [=](Text cpp_type_13575) { return prism_rtl::finished(prism_rtl::cat("Live<", cpp_type_13575, ">")); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutUnknown>(t_p1) && ({
        auto&& m11561_49_0 = prism_rtl::as<crate::lower::model::OutTy::OutUnknown>(t_p1).a0;
        (m11561_49_0 == Text::lit("the job\'s turn"));
    }) ? ({
        auto&& m11561_49_0 = prism_rtl::as<crate::lower::model::OutTy::OutUnknown>(t_p1).a0;
        prism_rtl::finished(Text::lit("decltype(this->cycle())"));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutUnknown>(t_p1) ? ({
        auto&& what_p17 = prism_rtl::as<crate::lower::model::OutTy::OutUnknown>(t_p1).a0;
        prism_rtl::finished(prism_rtl::cat("Unit /* ", what_p17, " */"));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutQuantified>(t_p1) ? ({
        auto&& b_p18 = prism_rtl::as<crate::lower::model::OutTy::OutQuantified>(t_p1).a0;
        prism_rtl::finished(prism_rtl::cat("compile_error!(\"", crate::lower::expr::lowering_refusal(), "a quantified type variable of `", b_p18, "`: no instantiation gives it a type\")"));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CppType, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_type(Cp cp_p0, crate::lower::model::OutTy t_p1) {
    return prism_rtl::make_rc<CppType>(cp_p0, t_p1);
}


/// CppTypes: unbounded fn Cp, [OutTy] -> Text
Text cpp_types(const Cp& cp_p0, const Array<crate::lower::model::OutTy>& ts_p1) {
    return crate::syntax::lexer::chars::join(run_to_end(each_job(ts_p1, ({
        auto cp_p0_1 = cp_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::OutTy)>>(prism_rtl::rc([=, cp_p0_1 = std::move(cp_p0_1)](crate::lower::model::OutTy p0) {
        return ({
            auto cp_p0_1_2 = cp_p0_1;
            entered(once_job([=, cp_p0_1_2 = std::move(cp_p0_1_2)]() {
            return ({
                auto t_p2 = p0;
                (prism_rtl::more(prism_rtl::rc(CppType(cp_p0_1_2, t_p2))));
            });
        }));
        });
    })));
    }))), Text::lit(", "));
}


prism_rtl::Turn<Text> CppTypes::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& ts_p1 = this->ts_p1;
    auto cp_p0_1 = cp_p0;
    auto ts_p1_2 = ts_p1;
    return call_value(each_job(ts_p1_2, ({
        auto cp_p0_1_3 = cp_p0_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::OutTy)>>(prism_rtl::rc([=, cp_p0_1_3 = std::move(cp_p0_1_3)](crate::lower::model::OutTy p0) {
        return ({
            auto cp_p0_1_3_3 = cp_p0_1_3;
            entered(once_job([=, cp_p0_1_3_3 = std::move(cp_p0_1_3_3)]() {
            return ({
                auto t_p2 = p0;
                (prism_rtl::more(prism_rtl::rc(CppType(cp_p0_1_3_3, t_p2))));
            });
        }));
        });
    })));
    })), [=](Array<Text> each_13893) { return prism_rtl::finished(crate::syntax::lexer::chars::join(each_13893, Text::lit(", "))); });
}


/// `Start CppTypes, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_types(Cp cp_p0, Array<crate::lower::model::OutTy> ts_p1) {
    return prism_rtl::make_rc<CppTypes>(cp_p0, ts_p1);
}


/// ParamTypes: unbounded fn Cp, [OutTy] -> Text
Text param_types(const Cp& cp_p0, const Array<crate::lower::model::OutTy>& ts_p1) {
    return crate::syntax::lexer::chars::join(run_to_end(each_job(ts_p1, ({
        auto cp_p0_1 = cp_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::OutTy)>>(prism_rtl::rc([=, cp_p0_1 = std::move(cp_p0_1)](crate::lower::model::OutTy p0) {
        return ({
            auto cp_p0_1_2 = cp_p0_1;
            entered(once_job([=, cp_p0_1_2 = std::move(cp_p0_1_2)]() {
            return ({
                auto t_p2 = p0;
                call_then(start_cpp_type(cp_p0_1_2, t_p2), [=](Text cpp_type_14108) { return prism_rtl::finished(prism_rtl::cat("const ", cpp_type_14108, "&")); });
            });
        }));
        });
    })));
    }))), Text::lit(", "));
}


prism_rtl::Turn<Text> ParamTypes::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& ts_p1 = this->ts_p1;
    auto cp_p0_1 = cp_p0;
    auto ts_p1_2 = ts_p1;
    return call_value(each_job(ts_p1_2, ({
        auto cp_p0_1_3 = cp_p0_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::OutTy)>>(prism_rtl::rc([=, cp_p0_1_3 = std::move(cp_p0_1_3)](crate::lower::model::OutTy p0) {
        return ({
            auto cp_p0_1_3_3 = cp_p0_1_3;
            entered(once_job([=, cp_p0_1_3_3 = std::move(cp_p0_1_3_3)]() {
            return ({
                auto t_p2 = p0;
                call_then(start_cpp_type(cp_p0_1_3_3, t_p2), [=](Text cpp_type_14108) { return prism_rtl::finished(prism_rtl::cat("const ", cpp_type_14108, "&")); });
            });
        }));
        });
    })));
    })), [=](Array<Text> each_14086) { return prism_rtl::finished(crate::syntax::lexer::chars::join(each_14086, Text::lit(", "))); });
}


/// `Start ParamTypes, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_param_types(Cp cp_p0, Array<crate::lower::model::OutTy> ts_p1) {
    return prism_rtl::make_rc<ParamTypes>(cp_p0, ts_p1);
}


/// OwnTypePath: fn Cp, Text -> Text
Text own_type_path(const Cp& cp_p0, const Text& n_p1) {
    auto shadowed_p2 = (!crate::syntax::lexer::chars::contains(n_p1, Text::lit(":"))) && in_list(Array(std::vector{Text::lit("Job"), Text::lit("Node"), Text::lit("Row"), Text::lit("Turn"), Text::lit("Program")}), n_p1);
    auto&& _m = type_of(cp_p0, n_p1);
    if (prism_rtl::is_some(_m)) {
        return std::move(shadowed_p2)
            ? prism_rtl::cat("crate::", cp_p0.home, "::", n_p1)
            : type_path(n_p1);
    }
    if (prism_rtl::is_none(_m)) {
        return type_path(n_p1);
    }
    prism_rtl::unreachable("no arm matched");
}


/// TypePath: fn Text -> Text
Text type_path(const Text& p_p0) {
    auto no_fish_p1 = crate::syntax::lexer::chars::join(split_on(p_p0, Text::lit("::<")), Text::lit("<"));
    auto no_holes_p2 = crate::syntax::lexer::chars::join(split_on(no_fish_p1, Text::lit(", _>")), Text::lit(">"));
    return crate::syntax::lexer::chars::join(split_on(no_holes_p2, Text::lit("<_>")), Text::lit(""));
}


/// IsValueTy: fn Cp, OutTy -> Bool
bool is_value_ty(const Cp& cp_p0, const crate::lower::model::OutTy& t_p1) {
    if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t_p1)) {
        auto&& n_p2 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p1).a0;
        auto&& _m = type_of(cp_p0, n_p2);
        if (prism_rtl::is_some(_m)) {
            auto&& info_p3 = prism_rtl::some_of(_m);
            return (prism_rtl::deref(info_p3).kind != Text::lit("node")) && (prism_rtl::deref(info_p3).kind != Text::lit("job"));
        }
        if (prism_rtl::is_none(_m)) {
            return false;
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutCell>(t_p1)) {
        return false;
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutPort>(t_p1)) {
        return false;
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutHold>(t_p1)) {
        return false;
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutStamped>(t_p1)) {
        return false;
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutSnapshot>(t_p1)) {
        return false;
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutDefer>(t_p1)) {
        return false;
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutObj>(t_p1)) {
        return false;
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutWakes>(t_p1)) {
        return false;
    }
    {
        return true;
    }
}

}  // namespace crate::emit::cpp
