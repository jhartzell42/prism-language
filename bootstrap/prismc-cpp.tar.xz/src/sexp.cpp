// The module `Sexp`, from `target/bootstrap/cpp-src/prismc/sexp.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (claude/backend.md). Edit the Prism source, not this file.
#include "sexp.hpp"
#include "ast.hpp"
#include "lexer.hpp"
#include "sexp.generic.hpp"
#include "lexer.generic.hpp"

namespace crate::sexp {

/// Nl: fn Nat -> Text
Text nl(const Nat& d) {
    return prism_rtl::cat("\n", indent(d));
}


/// Indent: fn Nat -> Text
Text indent(const Nat& d) {
    auto&& _m = d.checked_sub(Nat(1u));
    if (prism_rtl::is_some(_m)) {
        auto&& m = prism_rtl::some_of(_m);
        return prism_rtl::cat("  ", indent(m));
    }
    if (prism_rtl::is_none(_m)) {
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}


/// Path: fn [Text] -> Text
Text path_(const Array<Text>& p_) {
    return lexer::join(p_, Text::lit("."));
}


/// SNameText: fn SName -> Text
Text sname_text(const ast::SName& n) {
    return prism_rtl::cat(n.sigils, sexp::path_(n->path_));
}


/// SexpModule: fn Module -> Text
Text sexp_module(const ast::Module& m) {
    auto name_1 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = m.name;
        if (prism_rtl::is_some(_m)) {
            auto&& n = prism_rtl::some_of(_m);
            _v.set(prism_rtl::cat(nl(Nat(1u)), "(name ", sexp::path_(n->path_), ")"));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto emits = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = m.emit_row;
        if (prism_rtl::is_some(_m)) {
            auto&& r = prism_rtl::some_of(_m);
            _v.set(prism_rtl::cat(nl(Nat(1u)), "(emit ", sexp_row(r), ")"));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto uses = concat(each(m.uses, [&](const ast::Use& u) { return prism_rtl::cat(nl(Nat(1u)), "(use ", sexp::path_(u->target->path_), u.star ? Text::lit(".*") : Text::lit(""), ")"); }));
    auto template_ = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = m.template_;
        if (prism_rtl::is_some(_m)) {
            auto&& t = prism_rtl::some_of(_m);
            _v.set(prism_rtl::cat(nl(Nat(1u)), sexp_template(t, Nat(1u))));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto decls = concat(each(m.decls, [&](const ast::Decl& d) { return prism_rtl::cat(nl(Nat(1u)), sexp_decl(d, Nat(1u))); }));
    return prism_rtl::cat("(module", name_1, emits, uses, template_, decls, ")\n");
}


/// SexpRow: fn Row -> Text
Text sexp_row(const ast::Row_& r) {
    return prism_rtl::cat("(row", spaced(r.terms, ({
        auto f = prism_rtl::rc(sexp_row_term);
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(ast::RowTerm)>>(prism_rtl::rc([=](ast::RowTerm a0) {
        return ({
            auto f_1 = f;
            once_job([=]() { return prism_rtl::finished(f_1(a0)); });
        });
    })));
    })), ")");
}


/// SexpRowTerm: fn RowTerm -> Text
Text sexp_row_term(const ast::RowTerm& row_term0) {
    if (prism_rtl::is<ast::RowTerm::RFamily>(row_term0)) {
        auto&& q = prism_rtl::as<ast::RowTerm::RFamily>(row_term0).a0;
        return prism_rtl::cat(sexp::path_(q->path_), ".*");
    }
    if (prism_rtl::is<ast::RowTerm::RVar>(row_term0)) {
        auto&& v_ = prism_rtl::as<ast::RowTerm::RVar>(row_term0).a0;
        return prism_rtl::cat("(var ", v_.name, ")");
    }
    if (prism_rtl::is<ast::RowTerm::RType>(row_term0)) {
        auto&& t = prism_rtl::as<ast::RowTerm::RType>(row_term0).a0;
        return sexp_type(t);
    }
    prism_rtl::unreachable("no arm matched");
}


/// SexpDecl: fn Decl, Nat -> Text
Text sexp_decl(const ast::Decl& d, const Nat& depth) {
    auto&& _m = d.kind;
    if (prism_rtl::is<ast::DeclKind::DSignature>(_m)) {
        auto&& s = prism_rtl::as<ast::DeclKind::DSignature>(_m).a0;
        return sexp_signature(s);
    }
    if (prism_rtl::is<ast::DeclKind::DFn>(_m)) {
        auto&& f = prism_rtl::as<ast::DeclKind::DFn>(_m).a0;
        return sexp_fn(f, depth);
    }
    if (prism_rtl::is<ast::DeclKind::DLet>(_m)) {
        auto&& l = prism_rtl::as<ast::DeclKind::DLet>(_m).a0;
        return prism_rtl::cat("(let ", sexp_pattern(l.pattern, depth), opt_type(l.ty), " ", sexp_expr(l->value, depth), ")");
    }
    if (prism_rtl::is<ast::DeclKind::DWidget>(_m)) {
        auto&& w = prism_rtl::as<ast::DeclKind::DWidget>(_m).a0;
        return prism_rtl::cat("(widget ", sname_text(w.name), sexp_block(w.body, depth), ")");
    }
    if (prism_rtl::is<ast::DeclKind::DType>(_m)) {
        auto&& t = prism_rtl::as<ast::DeclKind::DType>(_m).a0;
        return prism_rtl::cat("(type ", sexp::path_(t.name->path_), concat(each(t.params, [&](const ast::Ident& p_) { return prism_rtl::cat(" ", p_.name); })), sexp_type_body(t.body, depth), ")");
    }
    if (prism_rtl::is<ast::DeclKind::DTag>(_m)) {
        auto&& t = prism_rtl::as<ast::DeclKind::DTag>(_m).a0;
        return prism_rtl::cat("(tag ", sexp::path_(t.name->path_), " ", sexp_type(t.of_type), sexp_bounds(t.bounds), sexp_fields(t.fields, depth), ")");
    }
    if (prism_rtl::is<ast::DeclKind::DDerive>(_m)) {
        auto&& ts = prism_rtl::as<ast::DeclKind::DDerive>(_m).a0;
        return prism_rtl::cat("(derive", concat(each(ts, [&](const ast::TraitRef& t) { return prism_rtl::cat(" ^", sexp::path_(t->path_)); })), ")");
    }
    if (prism_rtl::is<ast::DeclKind::DTrait>(_m)) {
        auto&& t = prism_rtl::as<ast::DeclKind::DTrait>(_m).a0;
        return prism_rtl::cat("(trait ^", sexp::path_(t.name->path_), concat(each(t.params, [&](const ast::Ident& p_) { return prism_rtl::cat(" ", p_.name); })), sexp_bounds(t.bounds), sexp_items(t.items, depth), ")");
    }
    if (prism_rtl::is<ast::DeclKind::DImpl>(_m)) {
        auto&& i = prism_rtl::as<ast::DeclKind::DImpl>(_m).a0;
        return prism_rtl::cat("(impl ^", sexp::path_(i.trait_ref->path_), " ", sexp_type(i.ty), sexp_bounds(i.bounds), sexp_items(i.items, depth), ")");
    }
    if (prism_rtl::is<ast::DeclKind::DCheck>(_m)) {
        auto&& c = prism_rtl::as<ast::DeclKind::DCheck>(_m).a0;
        return prism_rtl::cat("(check ", c.name.name, concat(each(c.lines, [&](const ast::CheckLine& l) { return prism_rtl::cat(nl(depth + Nat(1u)), "(line ", sexp_expr(l.expr, depth + Nat(1u)), check_pattern(l.pattern, depth + Nat(1u)), ")"); })), ")");
    }
    if (prism_rtl::is<ast::DeclKind::DTest>(_m)) {
        auto&& t = prism_rtl::as<ast::DeclKind::DTest>(_m).a0;
        return sexp_test(t, depth);
    }
    if (prism_rtl::is<ast::DeclKind::DStmt>(_m)) {
        auto&& s = prism_rtl::as<ast::DeclKind::DStmt>(_m).a0;
        return sexp_stmt(s, depth);
    }
    prism_rtl::unreachable("no arm matched");
}


/// OptType: fn ?Type -> Text
Text opt_type(const std::optional<ast::Type>& opt0) {
    if (prism_rtl::is_none(opt0)) {
        return Text::lit("");
    }
    if (prism_rtl::is_some(opt0)) {
        auto&& t = prism_rtl::some_of(opt0);
        return prism_rtl::cat(" ", sexp_type(t));
    }
    prism_rtl::unreachable("no arm matched");
}


/// CheckPattern: fn ?Pattern, Nat -> Text
Text check_pattern(const std::optional<ast::Pattern_>& opt0, const Nat& n1) {
    auto&& _m = std::tuple{opt0, n1};
    if (prism_rtl::is_none(std::get<0>(_m))) {
        return Text::lit("");
    }
    if (prism_rtl::is_some(std::get<0>(_m))) {
        auto&& p_ = prism_rtl::some_of(std::get<0>(_m));
        auto&& d = std::get<1>(_m);
        return prism_rtl::cat(" => ", sexp_pattern(p_, d));
    }
    prism_rtl::unreachable("no arm matched");
}


/// SexpTypeBody: fn ?TypeBody, Nat -> Text
Text sexp_type_body(const std::optional<ast::TypeBody>& opt0, const Nat& n1) {
    auto&& _m = std::tuple{opt0, n1};
    if (prism_rtl::is_none(std::get<0>(_m))) {
        return Text::lit(" opaque");
    }
    if (prism_rtl::is_some(std::get<0>(_m))) {
        auto&& b = prism_rtl::some_of(std::get<0>(_m));
        auto&& depth = std::get<1>(_m);
        if (prism_rtl::is<ast::TypeBody::TbRecord>(b)) {
            auto&& fs = prism_rtl::as<ast::TypeBody::TbRecord>(b).a0;
            return prism_rtl::cat(" record", sexp_fields(fs, depth));
        }
        if (prism_rtl::is<ast::TypeBody::TbChoice>(b)) {
            auto&& cs = prism_rtl::as<ast::TypeBody::TbChoice>(b).a0;
            return prism_rtl::cat(" choice", concat(each(cs, [&](const ast::Case_& c) { return prism_rtl::cat(nl(depth + Nat(1u)), sexp_case(c)); })));
        }
        if (prism_rtl::is<ast::TypeBody::TbRow>(b)) {
            return Text::lit(" row");
        }
        if (prism_rtl::is<ast::TypeBody::TbNewtype>(b)) {
            auto&& c = prism_rtl::as<ast::TypeBody::TbNewtype>(b).a0;
            return prism_rtl::cat(" newtype ", sexp_case(c));
        }
        if (prism_rtl::is<ast::TypeBody::TbUnit>(b)) {
            auto&& i = prism_rtl::as<ast::TypeBody::TbUnit>(b).a0;
            return prism_rtl::cat(" unit ", i.name);
        }
        if (prism_rtl::is<ast::TypeBody::TbAlias>(b)) {
            auto&& t = prism_rtl::as<ast::TypeBody::TbAlias>(b).a0;
            return prism_rtl::cat(" alias ", sexp_type(t));
        }
        prism_rtl::unreachable("no arm matched");
    }
    prism_rtl::unreachable("no arm matched");
}


/// SexpSignature: fn Signature -> Text
Text sexp_signature(const ast::Signature& s) {
    return prism_rtl::cat("(sig ", sexp_def_name(s.name), " ", sexp_type(s.ty), sexp_bounds(s.bounds), ")");
}


/// SexpDefName: fn DefName -> Text
Text sexp_def_name(const ast::DefName& def_name0) {
    if (prism_rtl::is<ast::DefName::DefSName>(def_name0)) {
        auto&& n = prism_rtl::as<ast::DefName::DefSName>(def_name0).a0;
        return sname_text(n);
    }
    if (prism_rtl::is<ast::DefName::DefOp>(def_name0)) {
        auto&& o = prism_rtl::as<ast::DefName::DefOp>(def_name0).a0;
        return prism_rtl::cat("(op ", o, ")");
    }
    prism_rtl::unreachable("no arm matched");
}


/// SexpBounds: fn [Bound] -> Text
Text sexp_bounds(const Array<ast::Bound>& bs) {
    return concat(each(bs, [&](const ast::Bound& b) { return prism_rtl::cat(" (where ", b.var.name, concat(each(b.traits, [&](const ast::TraitRef& t) { return prism_rtl::cat(" ^", sexp::path_(t->path_)); })), ")"); }));
}


/// SexpFn: fn FnClause, Nat -> Text
Text sexp_fn(const ast::FnClause& f, const Nat& depth) {
    auto body = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = f.body;
        if (prism_rtl::is<ast::FnBody::BodyExpr>(_m)) {
            auto&& e = prism_rtl::as<ast::FnBody::BodyExpr>(_m).a0;
            _v.set(prism_rtl::cat(nl(depth + Nat(1u)), sexp_expr(e, depth + Nat(1u))));
            goto _done;
        }
        if (prism_rtl::is<ast::FnBody::BodyBlock>(_m)) {
            auto&& b = prism_rtl::as<ast::FnBody::BodyBlock>(_m).a0;
            _v.set(sexp_block(b, depth));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return prism_rtl::cat("(fn ", sexp_def_name(f.name), " (params", concat(each(f.params, [&](const ast::Pattern_& p_) { return prism_rtl::cat(" ", sexp_pattern(p_, depth)); })), ")", body, ")");
}


/// SexpFields: fn [Field], Nat -> Text
Text sexp_fields(const Array<ast::Field>& fs, const Nat& depth) {
    return concat(each(fs, [&](const ast::Field& f) { return prism_rtl::cat(nl(depth + Nat(1u)), "(field ", f.name.name, " ", sexp_type(f.ty), ")"); }));
}


/// SexpCase: fn Case -> Text
Text sexp_case(const ast::Case_& c) {
    auto indexed = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = c.indexed;
        if (prism_rtl::is_some(_m)) {
            auto&& r = prism_rtl::some_of(_m);
            _v.set(prism_rtl::cat(" -> ", sexp_type(r)));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return prism_rtl::cat("(case ", sname_text(c.name), spaced(c->args, ({
        auto f = prism_rtl::rc(sexp_type);
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(ast::Type)>>(prism_rtl::rc([=](ast::Type a0) {
        return ({
            auto f_1 = f;
            once_job([=]() { return prism_rtl::finished(f_1(a0)); });
        });
    })));
    })), indexed, ")");
}


/// SexpItems: fn [TraitItem], Nat -> Text
Text sexp_items(const Array<ast::TraitItem>& items, const Nat& depth) {
    return concat(each(items, [&](const ast::TraitItem& it) { return prism_rtl::cat(nl(depth + Nat(1u)), sexp_item(it, depth + Nat(1u))); }));
}


/// SexpItem: fn TraitItem, Nat -> Text
Text sexp_item(const ast::TraitItem& trait_item0, const Nat& n1) {
    auto&& _m = std::tuple{trait_item0, n1};
    if (prism_rtl::is<ast::TraitItem::TiSignature>(std::get<0>(_m))) {
        auto&& s = prism_rtl::as<ast::TraitItem::TiSignature>(std::get<0>(_m)).a0;
        return sexp_signature(s);
    }
    if (prism_rtl::is<ast::TraitItem::TiFn>(std::get<0>(_m))) {
        auto&& f = prism_rtl::as<ast::TraitItem::TiFn>(std::get<0>(_m)).a0;
        auto&& d = std::get<1>(_m);
        return sexp_fn(f, d);
    }
    if (prism_rtl::is<ast::TraitItem::TiAssocType>(std::get<0>(_m))) {
        auto&& name = prism_rtl::as<ast::TraitItem::TiAssocType>(std::get<0>(_m)).a0;
        auto&& params = prism_rtl::as<ast::TraitItem::TiAssocType>(std::get<0>(_m)).a1;
        auto&& value_opt = prism_rtl::as<ast::TraitItem::TiAssocType>(std::get<0>(_m)).a2;
        return prism_rtl::cat("(assoc-type ", name.name, concat(each(params, [&](const ast::Ident& p_) { return prism_rtl::cat(" ", p_.name); })), opt_type(value_opt), ")");
    }
    if (prism_rtl::is<ast::TraitItem::TiAssocRow>(std::get<0>(_m))) {
        auto&& name = prism_rtl::as<ast::TraitItem::TiAssocRow>(std::get<0>(_m)).a0;
        return prism_rtl::cat("(assoc-row ", sname_text(name), ")");
    }
    prism_rtl::unreachable("no arm matched");
}


/// SexpTest: fn TestDecl, Nat -> Text
Text sexp_test(const ast::TestDecl& t, const Nat& depth) {
    auto seed_1 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = t.seed;
        if (prism_rtl::is_some(_m)) {
            auto&& s = prism_rtl::some_of(_m);
            _v.set(prism_rtl::cat(" (seed ", s, ")"));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return prism_rtl::cat("(test ", t.name.name, " ", sexp_expr(t.blueprint, depth), seed_1, concat(each(t.steps, [&](const ast::TestStep& s) { return prism_rtl::cat(nl(depth + Nat(1u)), sexp_step(s, depth + Nat(1u))); })), ")");
}


/// SexpStep: fn TestStep, Nat -> Text
Text sexp_step(const ast::TestStep& s, const Nat& d) {
    auto withs = concat(each(s.withs, [&](const ast::Entry& w) { return prism_rtl::cat(" (with ", sexp_expr(w.element, d), " ", sexp_expr(w->value, d), ")"); }));
    auto checks = concat(each(s.checks, [&](const ast::TestCheck& c) { return prism_rtl::cat(nl(d + Nat(1u)), sexp_check(c, d + Nat(1u))); }));
    return prism_rtl::cat("(step", withs, " ", sexp_action(s.action, d), checks, ")");
}


/// SexpAction: fn StepAction, Nat -> Text
Text sexp_action(const ast::StepAction& step_action0, const Nat& n1) {
    auto&& _m = std::tuple{step_action0, n1};
    if (prism_rtl::is<ast::StepAction::SaBuild>(std::get<0>(_m))) {
        return Text::lit("build");
    }
    if (prism_rtl::is<ast::StepAction::SaTick>(std::get<0>(_m))) {
        return Text::lit("tick");
    }
    if (prism_rtl::is<ast::StepAction::SaCompute>(std::get<0>(_m)) && prism_rtl::as<ast::StepAction::SaCompute>(std::get<0>(_m)).a0) {
        return Text::lit("compute-until-idle");
    }
    if (prism_rtl::is<ast::StepAction::SaCompute>(std::get<0>(_m)) && !prism_rtl::as<ast::StepAction::SaCompute>(std::get<0>(_m)).a0) {
        return Text::lit("compute");
    }
    if (prism_rtl::is<ast::StepAction::SaWithOnly>(std::get<0>(_m))) {
        return Text::lit("with-only");
    }
    if (prism_rtl::is<ast::StepAction::SaPush>(std::get<0>(_m))) {
        auto&& e = prism_rtl::as<ast::StepAction::SaPush>(std::get<0>(_m)).a0;
        auto&& d = std::get<1>(_m);
        return prism_rtl::cat("(push ", sexp_expr(e.element, d), " ", sexp_expr(e->value, d), ")");
    }
    if (prism_rtl::is<ast::StepAction::SaDeliver>(std::get<0>(_m))) {
        auto&& ds = prism_rtl::as<ast::StepAction::SaDeliver>(std::get<0>(_m)).a0;
        auto&& d = std::get<1>(_m);
        return lexer::join(each(ds, [&](const ast::Delivery& x) { return sexp_delivery(x, d); }), Text::lit(" "));
    }
    prism_rtl::unreachable("no arm matched");
}


/// SexpDelivery: fn Delivery, Nat -> Text
Text sexp_delivery(const ast::Delivery& x, const Nat& d) {
    auto word = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = x.kind;
        if (prism_rtl::is<ast::DeliveryKind::DkSend>(_m)) {
            _v.set(Text::lit("send"));
            goto _done;
        }
        if (prism_rtl::is<ast::DeliveryKind::DkClick>(_m)) {
            _v.set(Text::lit("click"));
            goto _done;
        }
        if (prism_rtl::is<ast::DeliveryKind::DkAnswer>(_m)) {
            _v.set(Text::lit("answer"));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto value = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = x.kind;
        if (prism_rtl::is<ast::DeliveryKind::DkSend>(_m)) {
            auto&& v_ = prism_rtl::as<ast::DeliveryKind::DkSend>(_m).a0;
            _v.set(prism_rtl::cat(" ", sexp_expr(v_, d)));
            goto _done;
        }
        {
            _v.set(Text::lit(""));
            goto _done;
        }
    _done:
        _v.take();
    });
    return prism_rtl::cat("(", word, " ", sexp_target(x->target, d), value, ")");
}


/// SexpTarget: fn Target, Nat -> Text
Text sexp_target(const ast::Target& target0, const Nat& d) {
    if (prism_rtl::is<ast::Target::TgPattern>(target0)) {
        auto&& p_ = prism_rtl::as<ast::Target::TgPattern>(target0).a0;
        return sexp_pattern(p_, d);
    }
    if (prism_rtl::is<ast::Target::TgPath>(target0)) {
        auto&& p_ = prism_rtl::as<ast::Target::TgPath>(target0).a0;
        return sexp_path(Text::lit("at"), p_, d);
    }
    if (prism_rtl::is<ast::Target::TgElement>(target0)) {
        auto&& p_ = prism_rtl::as<ast::Target::TgElement>(target0).a0;
        return sexp_path(Text::lit("element"), p_, d);
    }
    prism_rtl::unreachable("no arm matched");
}


/// SexpPath: fn Text, TestPath, Nat -> Text
Text sexp_path(const Text& word, const ast::TestPath& p_, const Nat& d) {
    return prism_rtl::cat("(", word, concat(each(p_.segments, [&](const ast::PathSeg& s) { return sexp_path_seg(s, d); })), ")");
}


/// SexpPathSeg: fn PathSeg, Nat -> Text
Text sexp_path_seg(const ast::PathSeg& path_seg0, const Nat& n1) {
    auto&& _m = std::tuple{path_seg0, n1};
    if (prism_rtl::is<ast::PathSeg::PsNum>(std::get<0>(_m))) {
        auto&& n = prism_rtl::as<ast::PathSeg::PsNum>(std::get<0>(_m)).a0;
        return prism_rtl::cat(" ", n);
    }
    if (prism_rtl::is<ast::PathSeg::PsGen>(std::get<0>(_m))) {
        auto&& n = prism_rtl::as<ast::PathSeg::PsGen>(std::get<0>(_m)).a0;
        return prism_rtl::cat(" #", n);
    }
    if (prism_rtl::is<ast::PathSeg::PsKey>(std::get<0>(_m))) {
        auto&& e = prism_rtl::as<ast::PathSeg::PsKey>(std::get<0>(_m)).a0;
        auto&& d = std::get<1>(_m);
        return prism_rtl::cat(" [", sexp_expr(e, d), "]");
    }
    prism_rtl::unreachable("no arm matched");
}


/// SexpCheck: fn TestCheck, Nat -> Text
Text sexp_check(const ast::TestCheck& c, const Nat& d) {
    auto&& _m = c.kind;
    if (prism_rtl::is<ast::TestCheckKind::CkExpect>(_m)) {
        auto&& p_ = prism_rtl::as<ast::TestCheckKind::CkExpect>(_m).a0;
        return prism_rtl::cat("(=> expect ", sexp_pattern(p_, d), ")");
    }
    if (prism_rtl::is<ast::TestCheckKind::CkExpectNone>(_m)) {
        auto&& p_ = prism_rtl::as<ast::TestCheckKind::CkExpectNone>(_m).a0;
        return prism_rtl::cat("(=> expect_none ", sexp_pattern(p_, d), ")");
    }
    if (prism_rtl::is<ast::TestCheckKind::CkExpectCount>(_m)) {
        auto&& p_ = prism_rtl::as<ast::TestCheckKind::CkExpectCount>(_m).a0;
        auto&& n = prism_rtl::as<ast::TestCheckKind::CkExpectCount>(_m).a1;
        return prism_rtl::cat("(=> expect_count ", sexp_pattern(p_, d), " ", n, ")");
    }
    if (prism_rtl::is<ast::TestCheckKind::CkExpectTop>(_m)) {
        auto&& p_ = prism_rtl::as<ast::TestCheckKind::CkExpectTop>(_m).a0;
        return prism_rtl::cat("(=> expect_top ", sexp_pattern(p_, d), ")");
    }
    if (prism_rtl::is<ast::TestCheckKind::CkExpectTopNone>(_m)) {
        auto&& p_ = prism_rtl::as<ast::TestCheckKind::CkExpectTopNone>(_m).a0;
        return prism_rtl::cat("(=> expect_top_none ", sexp_pattern(p_, d), ")");
    }
    if (prism_rtl::is<ast::TestCheckKind::CkRequested>(_m)) {
        auto&& p_ = prism_rtl::as<ast::TestCheckKind::CkRequested>(_m).a0;
        auto&& v_ = prism_rtl::as<ast::TestCheckKind::CkRequested>(_m).a1;
        return prism_rtl::cat("(=> requested ", sexp_pattern(p_, d), " ", sexp_pattern(v_, d), ")");
    }
    if (prism_rtl::is<ast::TestCheckKind::CkUnrequested>(_m)) {
        auto&& p_ = prism_rtl::as<ast::TestCheckKind::CkUnrequested>(_m).a0;
        return prism_rtl::cat("(=> unrequested ", sexp_pattern(p_, d), ")");
    }
    if (prism_rtl::is<ast::TestCheckKind::CkReturns>(_m)) {
        auto&& p_ = prism_rtl::as<ast::TestCheckKind::CkReturns>(_m).a0;
        return prism_rtl::cat("(=> returns ", sexp_pattern(p_, d), ")");
    }
    if (prism_rtl::is<ast::TestCheckKind::CkFired>(_m)) {
        auto&& p_ = prism_rtl::as<ast::TestCheckKind::CkFired>(_m).a0;
        return prism_rtl::cat("(=> fired ", sexp_pattern(p_, d), ")");
    }
    if (prism_rtl::is<ast::TestCheckKind::CkQuiet>(_m)) {
        return Text::lit("(=> quiet)");
    }
    if (prism_rtl::is<ast::TestCheckKind::CkSettles>(_m)) {
        return Text::lit("(=> settles)");
    }
    if (prism_rtl::is<ast::TestCheckKind::CkAborted>(_m)) {
        return Text::lit("(=> aborted)");
    }
    if (prism_rtl::is<ast::TestCheckKind::CkSnapshot>(_m)) {
        auto&& s = prism_rtl::as<ast::TestCheckKind::CkSnapshot>(_m).a0;
        return prism_rtl::cat("(=> snapshot ", lexer::debug_text(s), ")");
    }
    prism_rtl::unreachable("no arm matched");
}


/// SexpBlock: fn Block, Nat -> Text
Text sexp_block(const ast::Block& b, const Nat& d) {
    return b.inline_
        ? prism_rtl::cat(" (inline", concat(each(b.stmts, [&](const ast::Stmt& s) { return prism_rtl::cat(" ", sexp_stmt(s, d)); })), ")")
        : concat(each(b.stmts, [&](const ast::Stmt& s) { return prism_rtl::cat(nl(d + Nat(1u)), sexp_stmt(s, d + Nat(1u))); }));
}


/// SexpStmt: fn Stmt, Nat -> Text
Text sexp_stmt(const ast::Stmt& s, const Nat& d) {
    auto&& _m = s.kind;
    if (prism_rtl::is<ast::StmtKind::SEmit>(_m)) {
        auto&& r = prism_rtl::as<ast::StmtKind::SEmit>(_m).a0;
        return prism_rtl::cat("(emit ", sexp_row(r), ")");
    }
    if (prism_rtl::is<ast::StmtKind::SBind>(_m) && prism_rtl::is_none(prism_rtl::as<ast::StmtKind::SBind>(_m).a2)) {
        auto&& p_ = prism_rtl::as<ast::StmtKind::SBind>(_m).a0;
        auto&& v_ = prism_rtl::as<ast::StmtKind::SBind>(_m).a1;
        return prism_rtl::cat("(bind ", sexp_pattern(p_, d), " ", sexp_expr(v_, d), ")");
    }
    if (prism_rtl::is<ast::StmtKind::SBind>(_m) && prism_rtl::is_some(prism_rtl::as<ast::StmtKind::SBind>(_m).a2)) {
        auto&& p_ = prism_rtl::as<ast::StmtKind::SBind>(_m).a0;
        auto&& v_ = prism_rtl::as<ast::StmtKind::SBind>(_m).a1;
        auto&& t = prism_rtl::some_of(prism_rtl::as<ast::StmtKind::SBind>(_m).a2);
        return prism_rtl::cat("(hold ", sexp_pattern(p_, d), " ", sexp_expr(v_, d), " then ", sexp_expr(t, d), ")");
    }
    if (prism_rtl::is<ast::StmtKind::SIgnore>(_m)) {
        auto&& e = prism_rtl::as<ast::StmtKind::SIgnore>(_m).a0;
        return prism_rtl::cat("(ignore ", sexp_expr(e, d), ")");
    }
    if (prism_rtl::is<ast::StmtKind::SLet>(_m)) {
        auto&& p_ = prism_rtl::as<ast::StmtKind::SLet>(_m).a0;
        auto&& ty_opt = prism_rtl::as<ast::StmtKind::SLet>(_m).a1;
        auto&& v_ = prism_rtl::as<ast::StmtKind::SLet>(_m).a2;
        return prism_rtl::cat("(let ", sexp_pattern(p_, d), opt_type(ty_opt), " ", sexp_expr(v_, d), ")");
    }
    if (prism_rtl::is<ast::StmtKind::SSignature>(_m)) {
        auto&& sg = prism_rtl::as<ast::StmtKind::SSignature>(_m).a0;
        return sexp_signature(sg);
    }
    if (prism_rtl::is<ast::StmtKind::SFn>(_m)) {
        auto&& f = prism_rtl::as<ast::StmtKind::SFn>(_m).a0;
        return sexp_fn(f, d);
    }
    if (prism_rtl::is<ast::StmtKind::SWidget>(_m)) {
        auto&& w = prism_rtl::as<ast::StmtKind::SWidget>(_m).a0;
        return prism_rtl::cat("(widget ", sname_text(w.name), sexp_block(w.body, d), ")");
    }
    if (prism_rtl::is<ast::StmtKind::SSet>(_m)) {
        auto&& t = prism_rtl::as<ast::StmtKind::SSet>(_m).a0;
        auto&& v_ = prism_rtl::as<ast::StmtKind::SSet>(_m).a1;
        return prism_rtl::cat("(set ", sexp_expr(t, d), " ", sexp_expr(v_, d), ")");
    }
    if (prism_rtl::is<ast::StmtKind::SAccum>(_m)) {
        auto&& t = prism_rtl::as<ast::StmtKind::SAccum>(_m).a0;
        auto&& op = prism_rtl::as<ast::StmtKind::SAccum>(_m).a1;
        auto&& v_ = prism_rtl::as<ast::StmtKind::SAccum>(_m).a2;
        return prism_rtl::cat("(", op, " ", sexp_expr(t, d), " ", sexp_expr(v_, d), ")");
    }
    if (prism_rtl::is<ast::StmtKind::SRequire>(_m)) {
        auto&& c = prism_rtl::as<ast::StmtKind::SRequire>(_m).a0;
        return prism_rtl::cat("(require ", sexp_expr(c, d), ")");
    }
    if (prism_rtl::is<ast::StmtKind::SForbid>(_m)) {
        auto&& c = prism_rtl::as<ast::StmtKind::SForbid>(_m).a0;
        return prism_rtl::cat("(forbid ", sexp_expr(c, d), ")");
    }
    if (prism_rtl::is<ast::StmtKind::SWhile>(_m)) {
        auto&& c = prism_rtl::as<ast::StmtKind::SWhile>(_m).a0;
        auto&& body = prism_rtl::as<ast::StmtKind::SWhile>(_m).a1;
        return prism_rtl::cat("(while ", sexp_cond(c, d), sexp_block(body, d), ")");
    }
    if (prism_rtl::is<ast::StmtKind::SReturn>(_m)) {
        auto&& e = prism_rtl::as<ast::StmtKind::SReturn>(_m).a0;
        return prism_rtl::cat("(return ", sexp_expr(e, d), ")");
    }
    if (prism_rtl::is<ast::StmtKind::SExpr>(_m)) {
        auto&& e = prism_rtl::as<ast::StmtKind::SExpr>(_m).a0;
        return sexp_expr(e, d);
    }
    prism_rtl::unreachable("no arm matched");
}


/// SexpCond: fn Cond, Nat -> Text
Text sexp_cond(const ast::Cond& cond0, const Nat& d) {
    if (prism_rtl::is<ast::Cond::CondExpr>(cond0)) {
        auto&& e = prism_rtl::as<ast::Cond::CondExpr>(cond0).a0;
        return sexp_expr(e, d);
    }
    if (prism_rtl::is<ast::Cond::CondBind>(cond0)) {
        auto&& p_ = prism_rtl::as<ast::Cond::CondBind>(cond0).a0;
        auto&& v_ = prism_rtl::as<ast::Cond::CondBind>(cond0).a1;
        auto&& g_opt = prism_rtl::as<ast::Cond::CondBind>(cond0).a2;
        return prism_rtl::cat("(<- ", sexp_pattern(p_, d), " ", sexp_expr(v_, d), sexp_guard(g_opt, d), ")");
    }
    prism_rtl::unreachable("no arm matched");
}


/// SexpGuard: fn ?Expr, Nat -> Text
Text sexp_guard(const std::optional<ast::Expr>& opt0, const Nat& n1) {
    auto&& _m = std::tuple{opt0, n1};
    if (prism_rtl::is_none(std::get<0>(_m))) {
        return Text::lit("");
    }
    if (prism_rtl::is_some(std::get<0>(_m))) {
        auto&& g = prism_rtl::some_of(std::get<0>(_m));
        auto&& d = std::get<1>(_m);
        return prism_rtl::cat(" (if ", sexp_expr(g, d), ")");
    }
    prism_rtl::unreachable("no arm matched");
}


/// SexpLiteral: fn Literal, Nat -> Text
Text sexp_literal(const ast::Literal& l, const Nat& d) {
    auto&& _m = l.kind;
    if (prism_rtl::is<ast::LitKind::LInt>(_m)) {
        auto&& s = prism_rtl::as<ast::LitKind::LInt>(_m).a0;
        return prism_rtl::cat(l.marks, s);
    }
    if (prism_rtl::is<ast::LitKind::LFloat>(_m)) {
        auto&& s = prism_rtl::as<ast::LitKind::LFloat>(_m).a0;
        return prism_rtl::cat(l.marks, s);
    }
    if (prism_rtl::is<ast::LitKind::LDuration>(_m)) {
        auto&& digits = prism_rtl::as<ast::LitKind::LDuration>(_m).a0;
        auto&& u = prism_rtl::as<ast::LitKind::LDuration>(_m).a1;
        return prism_rtl::cat(l.marks, digits, u);
    }
    if (prism_rtl::is<ast::LitKind::LChar>(_m)) {
        auto&& c = prism_rtl::as<ast::LitKind::LChar>(_m).a0;
        return prism_rtl::cat(l.marks, lexer::debug_char(c));
    }
    if (prism_rtl::is<ast::LitKind::LText>(_m)) {
        auto&& segs = prism_rtl::as<ast::LitKind::LText>(_m).a0;
        return all_plain_segs(segs)
            ? prism_rtl::cat(l.marks, lexer::debug_text(concat(each(segs, plain_seg_text))))
            : prism_rtl::cat("(", l.marks, "text", concat(each(segs, [&](const ast::TextSeg& s) { return prism_rtl::cat(" ", sexp_seg(s, d)); })), ")");
    }
    prism_rtl::unreachable("no arm matched");
}


/// AllPlainSegs: fn [TextSeg] -> Bool
bool all_plain_segs(const Array<ast::TextSeg>& segs) {
    return fold(segs, true, [&](const bool& ok, const ast::TextSeg& s) { return ok && is_plain_text_seg(s); });
}


/// IsPlainTextSeg: fn TextSeg -> Bool
bool is_plain_text_seg(const ast::TextSeg& text_seg0) {
    if (prism_rtl::is<ast::TextSeg::SegPlain>(text_seg0)) {
        return true;
    }
    {
        return false;
    }
}


/// PlainSegText: fn TextSeg -> Text
Text plain_seg_text(const ast::TextSeg& text_seg0) {
    if (prism_rtl::is<ast::TextSeg::SegPlain>(text_seg0)) {
        auto&& s = prism_rtl::as<ast::TextSeg::SegPlain>(text_seg0).a0;
        return s;
    }
    {
        return Text::lit("");
    }
}


/// SexpSeg: fn TextSeg, Nat -> Text
Text sexp_seg(const ast::TextSeg& text_seg0, const Nat& n1) {
    auto&& _m = std::tuple{text_seg0, n1};
    if (prism_rtl::is<ast::TextSeg::SegPlain>(std::get<0>(_m))) {
        auto&& p_ = prism_rtl::as<ast::TextSeg::SegPlain>(std::get<0>(_m)).a0;
        return lexer::debug_text(p_);
    }
    if (prism_rtl::is<ast::TextSeg::SegPlaceholder>(std::get<0>(_m))) {
        auto&& e = prism_rtl::as<ast::TextSeg::SegPlaceholder>(std::get<0>(_m)).a0;
        auto&& d = std::get<1>(_m);
        return prism_rtl::cat("{", sexp_expr(e, d), "}");
    }
    prism_rtl::unreachable("no arm matched");
}


/// SexpArgs: fn [Arg], Nat -> Text
Text sexp_args(const Array<ast::Arg>& args, const Nat& d) {
    return concat(each(args, [&](const ast::Arg& a) { return prism_rtl::cat(" ", arg_name(a.name), sexp_expr(a->value, d)); }));
}


/// ArgName: fn ?Ident -> Text
Text arg_name(const std::optional<ast::Ident>& opt0) {
    if (prism_rtl::is_none(opt0)) {
        return Text::lit("");
    }
    if (prism_rtl::is_some(opt0)) {
        auto&& n = prism_rtl::some_of(opt0);
        return prism_rtl::cat(n.name, "=");
    }
    prism_rtl::unreachable("no arm matched");
}


/// SexpExprs: fn [Expr], Nat -> Text
Text sexp_exprs(const Array<ast::Expr>& es, const Nat& d) {
    return concat(each(es, [&](const ast::Expr& x) { return prism_rtl::cat(" ", sexp_expr(x, d)); }));
}


/// SexpExpr: fn Expr, Nat -> Text
Text sexp_expr(const ast::Expr& e, const Nat& d) {
    auto&& _m = e.kind;
    if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
        auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
        return sname_text(n);
    }
    if (prism_rtl::is<ast::ExprKind::ELit>(_m)) {
        auto&& l = prism_rtl::as<ast::ExprKind::ELit>(_m).a0;
        return sexp_literal(l, d);
    }
    if (prism_rtl::is<ast::ExprKind::EUnit>(_m)) {
        auto&& s = prism_rtl::as<ast::ExprKind::EUnit>(_m).a0;
        return prism_rtl::cat(s, "unit");
    }
    if (prism_rtl::is<ast::ExprKind::ENil>(_m)) {
        auto&& s = prism_rtl::as<ast::ExprKind::ENil>(_m).a0;
        return prism_rtl::cat(s, "nil");
    }
    if (prism_rtl::is<ast::ExprKind::EBound>(_m)) {
        auto&& b = prism_rtl::as<ast::ExprKind::EBound>(_m).a0;
        return b;
    }
    if (prism_rtl::is<ast::ExprKind::ETuple>(_m)) {
        auto&& es = prism_rtl::as<ast::ExprKind::ETuple>(_m).a0;
        return prism_rtl::cat("(tuple", sexp_exprs(es, d), ")");
    }
    if (prism_rtl::is<ast::ExprKind::EArray>(_m)) {
        auto&& es = prism_rtl::as<ast::ExprKind::EArray>(_m).a0;
        return prism_rtl::cat("(array", sexp_exprs(es, d), ")");
    }
    if (prism_rtl::is<ast::ExprKind::EMap>(_m)) {
        auto&& es = prism_rtl::as<ast::ExprKind::EMap>(_m).a0;
        return prism_rtl::cat("(map", concat(each(es, [&](const std::tuple<ast::Expr, ast::Expr>& _p0) {
            auto&& k = std::get<0>(_p0);
            auto&& v_ = std::get<1>(_p0);
            return prism_rtl::cat(" (", sexp_expr(k, d), ": ", sexp_expr(v_, d), ")");
        })), ")");
    }
    if (prism_rtl::is<ast::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<ast::ExprKind::EGroup>(_m).a0;
        return prism_rtl::cat("(group ", sexp_expr(x, d), ")");
    }
    if (prism_rtl::is<ast::ExprKind::ECall>(_m)) {
        auto&& callee = prism_rtl::as<ast::ExprKind::ECall>(_m).a0;
        auto&& args = prism_rtl::as<ast::ExprKind::ECall>(_m).a1;
        auto&& parens = prism_rtl::as<ast::ExprKind::ECall>(_m).a2;
        auto&& rest = prism_rtl::as<ast::ExprKind::ECall>(_m).a3;
        return prism_rtl::cat("(", parens ? Text::lit("call()") : Text::lit("call"), " ", sexp_expr(callee, d), sexp_args(args, d), rest ? Text::lit(" ..") : Text::lit(""), ")");
    }
    if (prism_rtl::is<ast::ExprKind::EBinary>(_m)) {
        auto&& op = prism_rtl::as<ast::ExprKind::EBinary>(_m).a0;
        auto&& lhs = prism_rtl::as<ast::ExprKind::EBinary>(_m).a1;
        auto&& rhs = prism_rtl::as<ast::ExprKind::EBinary>(_m).a2;
        return prism_rtl::cat("(", op, " ", sexp_expr(lhs, d), " ", sexp_expr(rhs, d), ")");
    }
    if (prism_rtl::is<ast::ExprKind::ESuffixed>(_m)) {
        auto&& op = prism_rtl::as<ast::ExprKind::ESuffixed>(_m).a0;
        auto&& ty = prism_rtl::as<ast::ExprKind::ESuffixed>(_m).a1;
        auto&& lhs = prism_rtl::as<ast::ExprKind::ESuffixed>(_m).a2;
        auto&& rhs = prism_rtl::as<ast::ExprKind::ESuffixed>(_m).a3;
        return prism_rtl::cat("(", op, sexp::path_(ty->path_), " ", sexp_expr(lhs, d), " ", sexp_expr(rhs, d), ")");
    }
    if (prism_rtl::is<ast::ExprKind::EUnary>(_m)) {
        auto&& op = prism_rtl::as<ast::ExprKind::EUnary>(_m).a0;
        auto&& operand = prism_rtl::as<ast::ExprKind::EUnary>(_m).a1;
        return prism_rtl::cat("(", op, " ", sexp_expr(operand, d), ")");
    }
    if (prism_rtl::is<ast::ExprKind::EFreeSigil>(_m)) {
        auto&& s = prism_rtl::as<ast::ExprKind::EFreeSigil>(_m).a0;
        auto&& operand = prism_rtl::as<ast::ExprKind::EFreeSigil>(_m).a1;
        return prism_rtl::cat("(free", s, " ", sexp_expr(operand, d), ")");
    }
    if (prism_rtl::is<ast::ExprKind::EField>(_m)) {
        auto&& recv = prism_rtl::as<ast::ExprKind::EField>(_m).a0;
        auto&& sigils = prism_rtl::as<ast::ExprKind::EField>(_m).a1;
        auto&& name = prism_rtl::as<ast::ExprKind::EField>(_m).a2;
        return prism_rtl::cat("(. ", sexp_expr(recv, d), " ", sigils, name.name, ")");
    }
    if (prism_rtl::is<ast::ExprKind::EIndex>(_m)) {
        auto&& recv = prism_rtl::as<ast::ExprKind::EIndex>(_m).a0;
        auto&& index = prism_rtl::as<ast::ExprKind::EIndex>(_m).a1;
        return prism_rtl::cat("(index ", sexp_expr(recv, d), " ", sexp_expr(index, d), ")");
    }
    if (prism_rtl::is<ast::ExprKind::ETopicField>(_m)) {
        auto&& n = prism_rtl::as<ast::ExprKind::ETopicField>(_m).a0;
        return prism_rtl::cat("(. _ ", n.name, ")");
    }
    if (prism_rtl::is<ast::ExprKind::ETopicIndex>(_m)) {
        auto&& i = prism_rtl::as<ast::ExprKind::ETopicIndex>(_m).a0;
        return prism_rtl::cat("(index _ ", sexp_expr(i, d), ")");
    }
    if (prism_rtl::is<ast::ExprKind::EMethod>(_m)) {
        auto&& recv = prism_rtl::as<ast::ExprKind::EMethod>(_m).a0;
        auto&& method = prism_rtl::as<ast::ExprKind::EMethod>(_m).a1;
        auto&& args = prism_rtl::as<ast::ExprKind::EMethod>(_m).a2;
        return prism_rtl::cat("(.", sname_text(method), " ", sexp_expr(recv, d), sexp_args(args, d), ")");
    }
    if (prism_rtl::is<ast::ExprKind::ETypeArgs>(_m)) {
        auto&& target = prism_rtl::as<ast::ExprKind::ETypeArgs>(_m).a0;
        auto&& types = prism_rtl::as<ast::ExprKind::ETypeArgs>(_m).a1;
        return prism_rtl::cat("(<<>> ", sexp_expr(target, d), spaced(types, ({
            auto f = prism_rtl::rc(sexp_type);
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(ast::Type)>>(prism_rtl::rc([=](ast::Type a0) {
            return ({
                auto f_1 = f;
                once_job([=]() { return prism_rtl::finished(f_1(a0)); });
            });
        })));
        })), ")");
    }
    if (prism_rtl::is<ast::ExprKind::ECast>(_m)) {
        auto&& x = prism_rtl::as<ast::ExprKind::ECast>(_m).a0;
        auto&& ty = prism_rtl::as<ast::ExprKind::ECast>(_m).a1;
        auto&& checked = prism_rtl::as<ast::ExprKind::ECast>(_m).a2;
        return prism_rtl::cat("(", checked ? Text::lit("as?") : Text::lit("as"), " ", sexp_expr(x, d), " ", sexp_type(ty), ")");
    }
    if (prism_rtl::is<ast::ExprKind::ENonEmpty>(_m)) {
        auto&& x = prism_rtl::as<ast::ExprKind::ENonEmpty>(_m).a0;
        return prism_rtl::cat("(nonempty ", sexp_expr(x, d), ")");
    }
    if (prism_rtl::is<ast::ExprKind::EAbsent>(_m)) {
        return Text::lit("absent");
    }
    if (prism_rtl::is<ast::ExprKind::ERest>(_m)) {
        return Text::lit("..");
    }
    if (prism_rtl::is<ast::ExprKind::ELambda>(_m)) {
        auto&& params_opt = prism_rtl::as<ast::ExprKind::ELambda>(_m).a0;
        auto&& body = prism_rtl::as<ast::ExprKind::ELambda>(_m).a1;
        return prism_rtl::cat("(lambda", sexp_lambda_params(params_opt, d), sexp_lambda_body(body, d), ")");
    }
    if (prism_rtl::is<ast::ExprKind::EIf>(_m)) {
        auto&& c = prism_rtl::as<ast::ExprKind::EIf>(_m).a0;
        auto&& then_block = prism_rtl::as<ast::ExprKind::EIf>(_m).a1;
        auto&& else_block_opt = prism_rtl::as<ast::ExprKind::EIf>(_m).a2;
        return prism_rtl::cat("(if ", sexp_cond(c, d), sexp_block(then_block, d), sexp_else(else_block_opt, d), ")");
    }
    if (prism_rtl::is<ast::ExprKind::EMatch>(_m)) {
        auto&& scrutinee = prism_rtl::as<ast::ExprKind::EMatch>(_m).a0;
        auto&& arms = prism_rtl::as<ast::ExprKind::EMatch>(_m).a1;
        return prism_rtl::cat("(match ", sexp_expr(scrutinee, d), concat(each(arms, [&](const ast::Arm& a) { return prism_rtl::cat(nl(d + Nat(1u)), sexp_arm(a, d + Nat(1u))); })), ")");
    }
    if (prism_rtl::is<ast::ExprKind::ERebuild>(_m)) {
        auto&& scrutinee = prism_rtl::as<ast::ExprKind::ERebuild>(_m).a0;
        auto&& body = prism_rtl::as<ast::ExprKind::ERebuild>(_m).a1;
        return prism_rtl::cat("(rebuild ", sexp_expr(scrutinee, d), sexp_block(body, d), ")");
    }
    if (prism_rtl::is<ast::ExprKind::EFor>(_m)) {
        auto&& binders_opt = prism_rtl::as<ast::ExprKind::EFor>(_m).a0;
        auto&& source = prism_rtl::as<ast::ExprKind::EFor>(_m).a1;
        auto&& body = prism_rtl::as<ast::ExprKind::EFor>(_m).a2;
        return prism_rtl::cat("(for", sexp_binders(binders_opt, d), " ", sexp_expr(source, d), sexp_block(body, d), ")");
    }
    if (prism_rtl::is<ast::ExprKind::EGiven>(_m)) {
        auto&& b = prism_rtl::as<ast::ExprKind::EGiven>(_m).a0;
        return prism_rtl::cat("(given", sexp_block(b, d), ")");
    }
    if (prism_rtl::is<ast::ExprKind::EUpdate>(_m)) {
        auto&& target = prism_rtl::as<ast::ExprKind::EUpdate>(_m).a0;
        auto&& body = prism_rtl::as<ast::ExprKind::EUpdate>(_m).a1;
        return prism_rtl::cat("(update ", sexp_expr(target, d), sexp_block(body, d), ")");
    }
    if (prism_rtl::is<ast::ExprKind::EWidgetBlock>(_m)) {
        auto&& b = prism_rtl::as<ast::ExprKind::EWidgetBlock>(_m).a0;
        return prism_rtl::cat("(@widget", sexp_block(b, d), ")");
    }
    if (prism_rtl::is<ast::ExprKind::EMonad>(_m)) {
        auto&& m = prism_rtl::as<ast::ExprKind::EMonad>(_m).a0;
        auto&& body = prism_rtl::as<ast::ExprKind::EMonad>(_m).a1;
        return prism_rtl::cat("(monad ", sexp_expr(m, d), sexp_block(body, d), ")");
    }
    if (prism_rtl::is<ast::ExprKind::ETemplate>(_m)) {
        auto&& t = prism_rtl::as<ast::ExprKind::ETemplate>(_m).a0;
        return sexp_template(t, d);
    }
    if (prism_rtl::is<ast::ExprKind::EAny>(_m)) {
        auto&& x = prism_rtl::as<ast::ExprKind::EAny>(_m).a0;
        return prism_rtl::cat("(any ", sexp_expr(x, d), ")");
    }
    if (prism_rtl::is<ast::ExprKind::ELens>(_m)) {
        auto&& path__ = prism_rtl::as<ast::ExprKind::ELens>(_m).a0;
        return prism_rtl::cat("(lens ", lexer::join(each(path__, [&](const ast::Ident& i) { return i.name; }), Text::lit(".")), ")");
    }
    if (prism_rtl::is<ast::ExprKind::EError>(_m)) {
        return Text::lit("<error>");
    }
    prism_rtl::unreachable("no arm matched");
}


/// SexpLambdaParams: fn ?[Pattern], Nat -> Text
Text sexp_lambda_params(const std::optional<Array<ast::Pattern_>>& opt0, const Nat& n1) {
    auto&& _m = std::tuple{opt0, n1};
    if (prism_rtl::is_none(std::get<0>(_m))) {
        return Text::lit(" topic");
    }
    if (prism_rtl::is_some(std::get<0>(_m))) {
        auto&& ps = prism_rtl::some_of(std::get<0>(_m));
        auto&& d = std::get<1>(_m);
        return prism_rtl::cat(" (params", concat(each(ps, [&](const ast::Pattern_& p_) { return prism_rtl::cat(" ", sexp_pattern(p_, d)); })), ")");
    }
    prism_rtl::unreachable("no arm matched");
}


/// SexpLambdaBody: fn LambdaBody, Nat -> Text
Text sexp_lambda_body(const ast::LambdaBody& lambda_body0, const Nat& d) {
    if (prism_rtl::is<ast::LambdaBody::LbExpr>(lambda_body0)) {
        auto&& e = prism_rtl::as<ast::LambdaBody::LbExpr>(lambda_body0).a0;
        return prism_rtl::cat(" ", sexp_expr(e, d));
    }
    if (prism_rtl::is<ast::LambdaBody::LbBlock>(lambda_body0)) {
        auto&& b = prism_rtl::as<ast::LambdaBody::LbBlock>(lambda_body0).a0;
        return sexp_block(b, d);
    }
    prism_rtl::unreachable("no arm matched");
}


/// SexpElse: fn ?Block, Nat -> Text
Text sexp_else(const std::optional<ast::Block>& opt0, const Nat& n1) {
    auto&& _m = std::tuple{opt0, n1};
    if (prism_rtl::is_none(std::get<0>(_m))) {
        return Text::lit("");
    }
    if (prism_rtl::is_some(std::get<0>(_m))) {
        auto&& b = prism_rtl::some_of(std::get<0>(_m));
        auto&& d = std::get<1>(_m);
        return prism_rtl::cat(b.inline_ ? Text::lit("") : nl(d), " else", sexp_block(b, d));
    }
    prism_rtl::unreachable("no arm matched");
}


/// SexpArm: fn Arm, Nat -> Text
Text sexp_arm(const ast::Arm& a, const Nat& d) {
    auto pattern = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = a.pattern;
        if (prism_rtl::is_some(_m)) {
            auto&& p_ = prism_rtl::some_of(_m);
            _v.set(sexp_pattern(p_, d));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text::lit("otherwise"));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return prism_rtl::cat("(arm ", pattern, sexp_guard(a.guard, d), sexp_block(a.body, d), ")");
}


/// SexpBinders: fn ?ForBinders, Nat -> Text
Text sexp_binders(const std::optional<ast::ForBinders>& opt0, const Nat& n1) {
    auto&& _m = std::tuple{opt0, n1};
    if (prism_rtl::is_none(std::get<0>(_m))) {
        return Text::lit("");
    }
    if (prism_rtl::is_some(std::get<0>(_m))) {
        auto&& b = prism_rtl::some_of(std::get<0>(_m));
        auto&& d = std::get<1>(_m);
        auto second = ({
            __label__ _done;
            prism_rtl::Slot<Text> _v;
            auto&& _m = b.second;
            if (prism_rtl::is_some(_m)) {
                auto&& s = prism_rtl::some_of(_m);
                _v.set(prism_rtl::cat(", ", sexp_pattern(s, d)));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(Text::lit(""));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        return prism_rtl::cat(" ", sexp_pattern(b.first, d), second, " <-");
    }
    prism_rtl::unreachable("no arm matched");
}


/// SexpTemplate: fn Template, Nat -> Text
Text sexp_template(const ast::Template& t, const Nat& d) {
    return prism_rtl::cat("(template ", t.keyword, " <", t.lang, ">", sexp_parts(t.parts, d + Nat(1u)), ")");
}


/// SexpParts: fn [TemplatePart], Nat -> Text
Text sexp_parts(const Array<ast::TemplatePart>& parts, const Nat& d) {
    return concat(each(parts, [&](const ast::TemplatePart& p_) { return prism_rtl::cat(nl(d), sexp_part(p_, d)); }));
}


/// SexpPart: fn TemplatePart, Nat -> Text
Text sexp_part(const ast::TemplatePart& template_part0, const Nat& n1) {
    auto&& _m = std::tuple{template_part0, n1};
    if (prism_rtl::is<ast::TemplatePart::TpText>(std::get<0>(_m))) {
        auto&& s = prism_rtl::as<ast::TemplatePart::TpText>(std::get<0>(_m)).a0;
        return lexer::debug_text(s);
    }
    if (prism_rtl::is<ast::TemplatePart::TpPlaceholder>(std::get<0>(_m))) {
        auto&& e = prism_rtl::as<ast::TemplatePart::TpPlaceholder>(std::get<0>(_m)).a0;
        auto&& col_opt = prism_rtl::as<ast::TemplatePart::TpPlaceholder>(std::get<0>(_m)).a1;
        auto&& d = std::get<1>(_m);
        return prism_rtl::cat("{{", sexp_expr(e, d), "}}", column_text(col_opt));
    }
    if (prism_rtl::is<ast::TemplatePart::TpBlock>(std::get<0>(_m))) {
        auto&& b = prism_rtl::as<ast::TemplatePart::TpBlock>(std::get<0>(_m)).a0;
        auto&& d = std::get<1>(_m);
        return prism_rtl::cat("(brace-block", sexp_block(b, d), ")");
    }
    if (prism_rtl::is<ast::TemplatePart::TpCall>(std::get<0>(_m))) {
        auto&& name = prism_rtl::as<ast::TemplatePart::TpCall>(std::get<0>(_m)).a0;
        auto&& attrs = prism_rtl::as<ast::TemplatePart::TpCall>(std::get<0>(_m)).a1;
        auto&& body_opt = prism_rtl::as<ast::TemplatePart::TpCall>(std::get<0>(_m)).a2;
        auto&& d = std::get<1>(_m);
        return prism_rtl::cat("(call ", sname_text(name), sexp_args(attrs, d), call_parts(body_opt, d), ")");
    }
    prism_rtl::unreachable("no arm matched");
}


/// ColumnText: fn ?Nat -> Text
Text column_text(const std::optional<Nat>& opt0) {
    if (prism_rtl::is_none(opt0)) {
        return Text::lit("");
    }
    if (prism_rtl::is_some(opt0)) {
        auto&& c = prism_rtl::some_of(opt0);
        return prism_rtl::cat(" @col ", c);
    }
    prism_rtl::unreachable("no arm matched");
}


/// CallParts: fn ?[TemplatePart], Nat -> Text
Text call_parts(const std::optional<Array<ast::TemplatePart>>& opt0, const Nat& n1) {
    auto&& _m = std::tuple{opt0, n1};
    if (prism_rtl::is_none(std::get<0>(_m))) {
        return Text::lit("");
    }
    if (prism_rtl::is_some(std::get<0>(_m))) {
        auto&& parts = prism_rtl::some_of(std::get<0>(_m));
        auto&& d = std::get<1>(_m);
        return sexp_parts(parts, d + Nat(1u));
    }
    prism_rtl::unreachable("no arm matched");
}


/// SexpPattern: fn Pattern, Nat -> Text
Text sexp_pattern(const ast::Pattern_& p_, const Nat& d) {
    auto&& _m = p_.kind;
    if (prism_rtl::is<ast::PatternKind::PName>(_m)) {
        auto&& n = prism_rtl::as<ast::PatternKind::PName>(_m).a0;
        return sname_text(n);
    }
    if (prism_rtl::is<ast::PatternKind::PIgnore>(_m)) {
        return Text::lit("ignore");
    }
    if (prism_rtl::is<ast::PatternKind::PLit>(_m)) {
        auto&& l = prism_rtl::as<ast::PatternKind::PLit>(_m).a0;
        return sexp_literal(l, d);
    }
    if (prism_rtl::is<ast::PatternKind::PNeg>(_m)) {
        auto&& l = prism_rtl::as<ast::PatternKind::PNeg>(_m).a0;
        return prism_rtl::cat("-", sexp_literal(l, d));
    }
    if (prism_rtl::is<ast::PatternKind::PUnit>(_m)) {
        return Text::lit("unit");
    }
    if (prism_rtl::is<ast::PatternKind::PNil>(_m)) {
        return Text::lit("nil");
    }
    if (prism_rtl::is<ast::PatternKind::PCtor>(_m)) {
        auto&& name = prism_rtl::as<ast::PatternKind::PCtor>(_m).a0;
        auto&& args = prism_rtl::as<ast::PatternKind::PCtor>(_m).a1;
        return prism_rtl::cat("(ctor ", sname_text(name), concat(each(args, [&](const ast::Pattern_& a) { return prism_rtl::cat(" ", sexp_pattern(a, d)); })), ")");
    }
    if (prism_rtl::is<ast::PatternKind::PRecord>(_m)) {
        auto&& name = prism_rtl::as<ast::PatternKind::PRecord>(_m).a0;
        auto&& fields = prism_rtl::as<ast::PatternKind::PRecord>(_m).a1;
        auto&& rest = prism_rtl::as<ast::PatternKind::PRecord>(_m).a2;
        return prism_rtl::cat("(record ", sname_text(name), concat(each(fields, [&](const ast::FieldPat& f) { return prism_rtl::cat(" ", arg_name(f.name), sexp_pattern(f.pattern, d)); })), rest ? Text::lit(" ..") : Text::lit(""), ")");
    }
    if (prism_rtl::is<ast::PatternKind::PSigil>(_m)) {
        auto&& s = prism_rtl::as<ast::PatternKind::PSigil>(_m).a0;
        auto&& inner = prism_rtl::as<ast::PatternKind::PSigil>(_m).a1;
        return prism_rtl::cat("(free", s, " ", sexp_pattern(inner, d), ")");
    }
    if (prism_rtl::is<ast::PatternKind::PTuple>(_m)) {
        auto&& ps = prism_rtl::as<ast::PatternKind::PTuple>(_m).a0;
        return prism_rtl::cat("(tuple", concat(each(ps, [&](const ast::Pattern_& x) { return prism_rtl::cat(" ", sexp_pattern(x, d)); })), ")");
    }
    if (prism_rtl::is<ast::PatternKind::PArray>(_m)) {
        auto&& ps = prism_rtl::as<ast::PatternKind::PArray>(_m).a0;
        return prism_rtl::cat("(array", concat(each(ps, [&](const ast::Pattern_& x) { return prism_rtl::cat(" ", sexp_pattern(x, d)); })), ")");
    }
    if (prism_rtl::is<ast::PatternKind::PGroup>(_m)) {
        auto&& x = prism_rtl::as<ast::PatternKind::PGroup>(_m).a0;
        return prism_rtl::cat("(group ", sexp_pattern(x, d), ")");
    }
    if (prism_rtl::is<ast::PatternKind::PFamily>(_m)) {
        auto&& q = prism_rtl::as<ast::PatternKind::PFamily>(_m).a0;
        return prism_rtl::cat(sexp::path_(q->path_), ".*");
    }
    prism_rtl::unreachable("no arm matched");
}


/// SexpType: fn Type -> Text
Text sexp_type(const ast::Type& t) {
    auto&& _m = t.kind;
    if (prism_rtl::is<ast::TypeKind::TName>(_m)) {
        auto&& name = prism_rtl::as<ast::TypeKind::TName>(_m).a0;
        auto&& m16095_0_1 = prism_rtl::as<ast::TypeKind::TName>(_m).a1;
        if (m16095_0_1.size() == 0u) {
            return sname_text(name);
        }
    }
    if (prism_rtl::is<ast::TypeKind::TName>(_m)) {
        auto&& name = prism_rtl::as<ast::TypeKind::TName>(_m).a0;
        auto&& args = prism_rtl::as<ast::TypeKind::TName>(_m).a1;
        return prism_rtl::cat("(", sname_text(name), concat(each(args, [&](const ast::Type& a) { return prism_rtl::cat(" ", sexp_type(a)); })), ")");
    }
    if (prism_rtl::is<ast::TypeKind::TSigiled>(_m)) {
        auto&& sigils = prism_rtl::as<ast::TypeKind::TSigiled>(_m).a0;
        auto&& inner = prism_rtl::as<ast::TypeKind::TSigiled>(_m).a1;
        return prism_rtl::cat("(free", sigils, " ", sexp_type(inner), ")");
    }
    if (prism_rtl::is<ast::TypeKind::TArray>(_m) && prism_rtl::as<ast::TypeKind::TArray>(_m).a1) {
        auto&& elem = prism_rtl::as<ast::TypeKind::TArray>(_m).a0;
        return prism_rtl::cat("[[", sexp_type(elem), "]]");
    }
    if (prism_rtl::is<ast::TypeKind::TArray>(_m) && !prism_rtl::as<ast::TypeKind::TArray>(_m).a1) {
        auto&& elem = prism_rtl::as<ast::TypeKind::TArray>(_m).a0;
        return prism_rtl::cat("[", sexp_type(elem), "]");
    }
    if (prism_rtl::is<ast::TypeKind::TTuple>(_m)) {
        auto&& ts = prism_rtl::as<ast::TypeKind::TTuple>(_m).a0;
        return prism_rtl::cat("(tuple", concat(each(ts, [&](const ast::Type& x) { return prism_rtl::cat(" ", sexp_type(x)); })), ")");
    }
    if (prism_rtl::is<ast::TypeKind::TGroup>(_m)) {
        auto&& x = prism_rtl::as<ast::TypeKind::TGroup>(_m).a0;
        return prism_rtl::cat("(group ", sexp_type(x), ")");
    }
    if (prism_rtl::is<ast::TypeKind::TMap>(_m)) {
        auto&& k = prism_rtl::as<ast::TypeKind::TMap>(_m).a0;
        auto&& v_ = prism_rtl::as<ast::TypeKind::TMap>(_m).a1;
        return prism_rtl::cat("(==> ", sexp_type(k), " ", sexp_type(v_), ")");
    }
    if (prism_rtl::is<ast::TypeKind::TFn>(_m)) {
        auto&& color = prism_rtl::as<ast::TypeKind::TFn>(_m).a0;
        auto&& params = prism_rtl::as<ast::TypeKind::TFn>(_m).a1;
        auto&& result = prism_rtl::as<ast::TypeKind::TFn>(_m).a2;
        return prism_rtl::cat("(", color_text(color), "fn", concat(each(params, [&](const ast::Type& x) { return prism_rtl::cat(" ", sexp_type(x)); })), " -> ", sexp_type(result), ")");
    }
    if (prism_rtl::is<ast::TypeKind::TEmit>(_m)) {
        auto&& ty = prism_rtl::as<ast::TypeKind::TEmit>(_m).a0;
        auto&& r = prism_rtl::as<ast::TypeKind::TEmit>(_m).a1;
        return prism_rtl::cat("(emit ", sexp_type(ty), " ", sexp_type(r), ")");
    }
    if (prism_rtl::is<ast::TypeKind::TRowUnion>(_m)) {
        auto&& ts = prism_rtl::as<ast::TypeKind::TRowUnion>(_m).a0;
        return prism_rtl::cat("(|", concat(each(ts, [&](const ast::Type& x) { return prism_rtl::cat(" ", sexp_type(x)); })), ")");
    }
    if (prism_rtl::is<ast::TypeKind::TFamily>(_m)) {
        auto&& q = prism_rtl::as<ast::TypeKind::TFamily>(_m).a0;
        return prism_rtl::cat(sexp::path_(q->path_), ".*");
    }
    if (prism_rtl::is<ast::TypeKind::TAny>(_m)) {
        auto&& tr = prism_rtl::as<ast::TypeKind::TAny>(_m).a0;
        return prism_rtl::cat("(any ^", sexp::path_(tr->path_), ")");
    }
    if (prism_rtl::is<ast::TypeKind::TUnit>(_m)) {
        auto&& s = prism_rtl::as<ast::TypeKind::TUnit>(_m).a0;
        return prism_rtl::cat(s, "unit");
    }
    if (prism_rtl::is<ast::TypeKind::THole>(_m)) {
        auto&& n = prism_rtl::as<ast::TypeKind::THole>(_m).a0;
        return sname_text(n);
    }
    if (prism_rtl::is<ast::TypeKind::TAbsent>(_m)) {
        return Text::lit("absent");
    }
    if (prism_rtl::is<ast::TypeKind::TNonEmpty>(_m)) {
        auto&& x = prism_rtl::as<ast::TypeKind::TNonEmpty>(_m).a0;
        return prism_rtl::cat("(nonempty ", sexp_type(x), ")");
    }
    prism_rtl::unreachable("no arm matched");
}


/// ColorText: fn Color -> Text
Text color_text(const ast::Color& color0) {
    if (prism_rtl::is<ast::Color::Bounded>(color0)) {
        return Text::lit("");
    }
    if (prism_rtl::is<ast::Color::Unbounded>(color0)) {
        return Text::lit("unbounded ");
    }
    if (prism_rtl::is<ast::Color::ColorVar>(color0)) {
        auto&& v_ = prism_rtl::as<ast::Color::ColorVar>(color0).a0;
        return prism_rtl::cat(v_.name, " ");
    }
    prism_rtl::unreachable("no arm matched");
}

}  // namespace crate::sexp
