// The module `Emit.Cpp.Program`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <emit/cpp/program/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Emit.Cpp.Program`, from `target/bootstrap/cpp-src/prismc/emit/cpp/program.prism`.
namespace crate::emit::cpp::program {

void Piece::show(Printer& p) const {
    p.record("Piece", {{"title", title}, {"prism", prism}, {"path", path_}, {"ns", ns}, {"needs", needs}, {"defs", defs}});
}

Pod Piece::to_pod() const {
    return Pod::record("Piece", {{"title", prism_rtl::to_pod(title)}, {"prism", prism_rtl::to_pod(prism)}, {"path", prism_rtl::to_pod(path_)}, {"ns", prism_rtl::to_pod(ns)}, {"needs", prism_rtl::to_pod(needs)}, {"defs", prism_rtl::to_pod(defs)}});
}

Result<Piece> Piece::from_pod(const Pod& whole) {
    return Piece{.title = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "title")))), .prism = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "prism")))), .path_ = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "path")))), .ns = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "ns")))), .needs = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "needs")))), .defs = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "defs"))))};
}


/// NodeParts: unbounded fn Cp, NodeDef -> Parts
crate::emit::cpp::items::Parts node_parts(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::NodeDef& n_p1) {
    auto ncp_p2 = crate::emit::cpp::with_fields(cp_p0, each(n_p1.fields, [&](const std::tuple<Text, crate::lower::model::OutTy, Text>& _p0) {
        auto&& f_pu = std::get<0>(_p0);
        auto&& t_pv = std::get<1>(_p0);
        return std::tuple{f_pu, t_pv};
    }));
    auto base_p3 = (n_p1.row_kind == crate::lower::model::RowKind(crate::lower::model::RowKind::NotARow{})) && (len(n_p1.hosted) == Nat(0u))
        ? Text::lit("Node")
        : Text::lit("Row");
    auto fields_p4 = crate::syntax::lexer::chars::join(run_to_end(each_job(n_p1.fields, ({
        auto cp_p0_1 = cp_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy, Text>)>>(prism_rtl::rc([=, cp_p0_1 = std::move(cp_p0_1)](std::tuple<Text, crate::lower::model::OutTy, Text> p0) {
        return ({
            auto cp_p0_1_2 = cp_p0_1;
            entered(once_job([=, cp_p0_1_2 = std::move(cp_p0_1_2)]() {
            return ({
                auto [f_p10, t_p11, doc_p12] = p0;
                call_then(crate::emit::cpp::start_cpp_type(cp_p0_1_2, t_p11), [=](Text cpp_type_1357) { return prism_rtl::finished(prism_rtl::cat(crate::emit::cpp::items::cpp_doc(doc_p12), cpp_type_1357, " ", crate::emit::cpp::field_id(f_p10), ";")); });
            });
        }));
        });
    })));
    }))), Text::lit("\n"));
    auto consts_p5 = crate::syntax::lexer::chars::join(each(n_p1.consts, [&](const std::tuple<Text, Nat, Text>& _p0) {
        auto&& c_p13 = std::get<0>(_p0);
        auto&& h_p14 = std::get<1>(_p0);
        auto&& doc_p15 = std::get<2>(_p0);
        return prism_rtl::cat(crate::emit::cpp::items::cpp_doc(prism_rtl::cat("The ", doc_p15, ".")), "static constexpr std::uint32_t ", c_p13, " = ", h_p14, ";");
    }), Text::lit("\n"));
    auto ctor_params_p6 = crate::syntax::lexer::chars::join(append(Array(std::vector{Text::lit("Path path")}), run_to_end(each_job(n_p1.fields, ({
        auto cp_p0_1 = cp_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy, Text>)>>(prism_rtl::rc([=, cp_p0_1 = std::move(cp_p0_1)](std::tuple<Text, crate::lower::model::OutTy, Text> p0) {
        return ({
            auto cp_p0_1_2 = cp_p0_1;
            entered(once_job([=, cp_p0_1_2 = std::move(cp_p0_1_2)]() {
            return ({
                auto&& _f_p16 = p0;
                auto&& f_p16 = std::get<0>(_f_p16);
                auto&& t_p17 = std::get<1>(_f_p16);
                call_then(crate::emit::cpp::start_cpp_type(cp_p0_1_2, t_p17), [=](Text cpp_type_1609) { return prism_rtl::finished(prism_rtl::cat(cpp_type_1609, " ", crate::emit::cpp::field_id(f_p16))); });
            });
        }));
        });
    })));
    })))), Text::lit(", "));
    auto ctor_inits_p7 = crate::syntax::lexer::chars::join(append(Array(std::vector{Text::lit("path(std::move(path))")}), each(n_p1.fields, [&](const std::tuple<Text, crate::lower::model::OutTy, Text>& _p0) {
        auto&& f_p18 = std::get<0>(_p0);
        return prism_rtl::cat(crate::emit::cpp::field_id(f_p18), "(std::move(", crate::emit::cpp::field_id(f_p18), "))");
    })), Text::lit(", "));
    auto params_p8 = concat(run_to_end(each_job(n_p1.params, ({
        auto cp_p0_1 = cp_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=, cp_p0_1 = std::move(cp_p0_1)](std::tuple<Text, crate::lower::model::OutTy> p0) {
        return ({
            auto cp_p0_1_2 = cp_p0_1;
            entered(once_job([=, cp_p0_1_2 = std::move(cp_p0_1_2)]() {
            return ({
                auto [p_p19, t_p1a] = p0;
                call_then(crate::emit::cpp::expr::start_param_type(cp_p0_1_2, t_p1a), [=](Text param_type_1848) { return prism_rtl::finished(prism_rtl::cat(param_type_1848, " ", p_p19, ", ")); });
            });
        }));
        });
    })));
    }))));
    auto ret_p9 = n_p1.fallible
        ? prism_rtl::cat("Result<prism_rtl::Rc<", n_p1.name, ">>")
        : prism_rtl::cat("prism_rtl::Rc<", n_p1.name, ">");
    auto make_decl_pa = prism_rtl::cat("static ", ret_p9, " make(Path path, ", params_p8, "Cx& cx);");
    auto method_decls_pb = run_to_end(each_job(append(n_p1.methods, n_p1.hosted), ({
        auto ncp_p2_1 = ncp_p2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::MethDef)>>(prism_rtl::rc([=, ncp_p2_1 = std::move(ncp_p2_1)](crate::lower::model::MethDef p0) {
        return ({
            auto ncp_p2_1_2 = ncp_p2_1;
            entered(once_job([=, ncp_p2_1_2 = std::move(ncp_p2_1_2)]() {
            return ({
                auto m_p1b = p0;
                call_then(start_method_sig(ncp_p2_1_2, m_p1b, Text::lit("")), [=](Text method_sig_2099) { return prism_rtl::finished(prism_rtl::cat(method_sig_2099, ";")); });
            });
        }));
        });
    })));
    })));
    auto builder_decls_pc = append(each(n_p1.builders, [&](const crate::lower::model::ForDef& b_p1c) { return prism_rtl::cat("Done ", prism_rtl::deref(b_p1c).name, "_build(Cx& cx);"); }), each(n_p1.gens, [&](const crate::lower::model::GenDef& g_p1d) { return prism_rtl::cat("Done ", prism_rtl::deref(g_p1d).name, "_build(Cx& cx);"); }));
    auto hook_decls_pd = each(n_p1.hooks, [&](const std::tuple<Text, Array<crate::lower::model::Do>>& _p0) {
        auto&& h_p1e = std::get<0>(_p0);
        return prism_rtl::cat(hook_sig(h_p1e, Text::lit("")), " override;");
    });
    auto answer_decl_pe = len(n_p1.answers) == Nat(0u)
        ? Array<Text>{}
        : Array(std::vector{Text::lit("Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;")});
    auto row_decl_pf = n_p1.row_kind == crate::lower::model::RowKind(crate::lower::model::RowKind::NotARow{})
        ? Array<Text>{}
        : Array(std::vector{Text::lit("void leave_row(Cx& cx) override;")});
    auto decls_pg = crate::syntax::lexer::chars::join(append(append(append(append(append(Array(std::vector{make_decl_pa}), method_decls_pb), builder_decls_pc), hook_decls_pd), answer_decl_pe), row_decl_pf), Text::lit("\n"));
    auto doc_ph = crate::emit::cpp::items::cpp_source_doc(prism_rtl::cat("`", n_p1.prism, "`: a node of its own (claude/backend.md, \"A widget block\")."), n_p1.doc);
    auto decl_pi = crate::emit::cpp::templates::items::node_class(doc_ph, n_p1.name, base_p3, fields_p4, consts_p5, prism_rtl::cat(n_p1.name, "(", ctor_params_p6, ") : ", ctor_inits_p7, " {}"), decls_pg);
    auto by_field_pj = each(n_p1.fields, [&](const std::tuple<Text, crate::lower::model::OutTy, Text>& _p0) {
        auto&& f_p1f = std::get<0>(_p0);
        return or_(fold(n_p1.inits, std::optional<crate::lower::model::Ex>{}, [&](const std::optional<crate::lower::model::Ex>& found_o1g, const std::tuple<Text, crate::lower::model::Ex>& _p1) {
            auto&& g_p1h = std::get<0>(_p1);
            auto&& v_p1i = std::get<1>(_p1);
            return g_p1h == f_p1f ? std::optional(v_p1i) : found_o1g;
        }), crate::lower::model::Ex(crate::lower::model::Ex::XVar{f_p1f}));
    });
    auto [lets_text_p1j, lcp_p1k] = crate::emit::cpp::stmts::cpp_statements_cp(ncp_p2, n_p1.lets);
    auto args_pk = crate::syntax::lexer::chars::join(append(Array(std::vector{Text::lit("path")}), run_to_end(each_job(by_field_pj, ({
        auto lcp_p1k_1 = lcp_p1k;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Ex)>>(prism_rtl::rc([=, lcp_p1k_1 = std::move(lcp_p1k_1)](crate::lower::model::Ex p0) {
        return ({
            auto lcp_p1k_1_2 = lcp_p1k_1;
            entered(once_job([=, lcp_p1k_1_2 = std::move(lcp_p1k_1_2)]() {
            return ({
                auto v_p1l = p0;
                (prism_rtl::more(prism_rtl::rc(crate::emit::cpp::expr::CppExpr(lcp_p1k_1_2, v_p1l))));
            });
        }));
        });
    })));
    })))), Text::lit(", "));
    auto tail_pl = n_p1.fallible ? Text::lit("return node;") : Text::lit("return node;");
    auto make_pm = crate::emit::cpp::templates::items::node_make(n_p1.name, prism_rtl::cat(ret_p9, " ", n_p1.name, "::make(Path path, ", params_p8, "Cx& cx)"), lets_text_p1j, args_pk, crate::syntax::lexer::chars::join(filter(Array(std::vector{crate::emit::cpp::stmts::cpp_statements(crate::emit::cpp::stmts::pointing(lcp_p1k, Text::lit("node")), n_p1.build), tail_pl}), [&](const Text& s_p1m) { return s_p1m != Text::lit(""); }), Text::lit("\n")));
    auto methods_pn = run_to_end(each_job(append(n_p1.methods, n_p1.hosted), ({
        auto ncp_p2_1 = ncp_p2;
        auto n_p1_2 = n_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::MethDef)>>(prism_rtl::rc([=, ncp_p2_1 = std::move(ncp_p2_1), n_p1_2 = std::move(n_p1_2)](crate::lower::model::MethDef p0) {
        return ({
            auto ncp_p2_1_3 = ncp_p2_1;
            auto n_p1_2_3 = n_p1_2;
            entered(once_job([=, ncp_p2_1_3 = std::move(ncp_p2_1_3), n_p1_2_3 = std::move(n_p1_2_3)]() {
            return ({
                auto m_p1n = p0;
                (prism_rtl::more(prism_rtl::rc(MethodDef(ncp_p2_1_3, n_p1_2_3.name, m_p1n))));
            });
        }));
        });
    })));
    })));
    auto builders_po = append(run_to_end(each_job(n_p1.builders, ({
        auto ncp_p2_1 = ncp_p2;
        auto n_p1_2 = n_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::ForDef)>>(prism_rtl::rc([=, ncp_p2_1 = std::move(ncp_p2_1), n_p1_2 = std::move(n_p1_2)](crate::lower::model::ForDef p0) {
        return ({
            auto ncp_p2_1_3 = ncp_p2_1;
            auto n_p1_2_3 = n_p1_2;
            entered(once_job([=, ncp_p2_1_3 = std::move(ncp_p2_1_3), n_p1_2_3 = std::move(n_p1_2_3)]() {
            return ({
                auto b_p1o = p0;
                (prism_rtl::more(prism_rtl::rc(ForBuildCpp(ncp_p2_1_3, n_p1_2_3.name, b_p1o))));
            });
        }));
        });
    })));
    }))), run_to_end(each_job(n_p1.gens, ({
        auto ncp_p2_1 = ncp_p2;
        auto n_p1_2 = n_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::GenDef)>>(prism_rtl::rc([=, ncp_p2_1 = std::move(ncp_p2_1), n_p1_2 = std::move(n_p1_2)](crate::lower::model::GenDef p0) {
        return ({
            auto ncp_p2_1_3 = ncp_p2_1;
            auto n_p1_2_3 = n_p1_2;
            entered(once_job([=, ncp_p2_1_3 = std::move(ncp_p2_1_3), n_p1_2_3 = std::move(n_p1_2_3)]() {
            return ({
                auto g_p1p = p0;
                (prism_rtl::more(prism_rtl::rc(GenBuildCpp(ncp_p2_1_3, n_p1_2_3.name, g_p1p))));
            });
        }));
        });
    })));
    }))));
    auto hooks_pp = run_to_end(each_job(n_p1.hooks, ({
        auto n_p1_1 = n_p1;
        auto ncp_p2_2 = ncp_p2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Array<crate::lower::model::Do>>)>>(prism_rtl::rc([=, n_p1_1 = std::move(n_p1_1), ncp_p2_2 = std::move(ncp_p2_2)](std::tuple<Text, Array<crate::lower::model::Do>> p0) {
        return ({
            auto n_p1_1_3 = n_p1_1;
            auto ncp_p2_2_3 = ncp_p2_2;
            entered(once_job([=, n_p1_1_3 = std::move(n_p1_1_3), ncp_p2_2_3 = std::move(ncp_p2_2_3)]() {
            return ({
                auto [h_p1q, body_p1r] = p0;
                call_then(crate::emit::cpp::stmts::start_cpp_statements(ncp_p2_2_3, body_p1r), [=](Text cpp_statements_3838) { return prism_rtl::finished(crate::emit::cpp::templates::items::cpp_function(Text::lit(""), hook_sig(h_p1q, prism_rtl::cat(n_p1_1_3.name, "::")), prism_rtl::cat(cpp_statements_3838, "\nreturn {};"))); });
            });
        }));
        });
    })));
    })));
    auto answer_pq = len(n_p1.answers) == Nat(0u)
        ? Array<Text>{}
        : Array(std::vector{answer_def_cpp(ncp_p2, n_p1)});
    auto leaving_pr = n_p1.row_kind == crate::lower::model::RowKind(crate::lower::model::RowKind::NotARow{})
        ? Array<Text>{}
        : Array(std::vector{row_leaving(ncp_p2, n_p1)});
    auto defs_ps = append(append(append(append(append(Array(std::vector{make_pm}), methods_pn), builders_po), hooks_pp), answer_pq), leaving_pr);
    auto own_pt = crate::emit::cpp::items::Parts{.forward = Array(std::vector{prism_rtl::cat("class ", n_p1.name, ";")}), .values = Array<crate::emit::cpp::items::ValueDecl>{}, .protos = Array<Text>{}, .classes = Array(std::vector{decl_pi}), .outer = Array<Text>{}, .generic = Array<Text>{}, .defs = defs_ps};
    return own_pt;
}


prism_rtl::Turn<crate::emit::cpp::items::Parts> NodeParts::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& n_p1 = this->n_p1;
    auto ncp_p2 = crate::emit::cpp::with_fields(cp_p0, each(prism_rtl::deref(n_p1).fields, [&](const std::tuple<Text, crate::lower::model::OutTy, Text>& _p0) {
        auto&& f_pu = std::get<0>(_p0);
        auto&& t_pv = std::get<1>(_p0);
        return std::tuple{f_pu, t_pv};
    }));
    auto base_p3 = (prism_rtl::deref(n_p1).row_kind == crate::lower::model::RowKind(crate::lower::model::RowKind::NotARow{})) && (len(prism_rtl::deref(n_p1).hosted) == Nat(0u))
        ? Text::lit("Node")
        : Text::lit("Row");
    auto cp_p0_1 = cp_p0;
    auto n_p1_2 = n_p1;
    return call_value(each_job(prism_rtl::deref(n_p1_2).fields, ({
        auto cp_p0_1_3 = cp_p0_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy, Text>)>>(prism_rtl::rc([=, cp_p0_1_3 = std::move(cp_p0_1_3)](std::tuple<Text, crate::lower::model::OutTy, Text> p0) {
        return ({
            auto cp_p0_1_3_3 = cp_p0_1_3;
            entered(once_job([=, cp_p0_1_3_3 = std::move(cp_p0_1_3_3)]() {
            return ({
                auto [f_p10, t_p11, doc_p12] = p0;
                call_then(crate::emit::cpp::start_cpp_type(cp_p0_1_3_3, t_p11), [=](Text cpp_type_1357) { return prism_rtl::finished(prism_rtl::cat(crate::emit::cpp::items::cpp_doc(doc_p12), cpp_type_1357, " ", crate::emit::cpp::field_id(f_p10), ";")); });
            });
        }));
        });
    })));
    })), [=](Array<Text> each_1311) {
        return ({
            auto fields_p4 = crate::syntax::lexer::chars::join(each_1311, Text::lit("\n"));
            auto consts_p5 = crate::syntax::lexer::chars::join(each(prism_rtl::deref(n_p1_2).consts, [&](const std::tuple<Text, Nat, Text>& _p0) {
                auto&& c_p13 = std::get<0>(_p0);
                auto&& h_p14 = std::get<1>(_p0);
                auto&& doc_p15 = std::get<2>(_p0);
                return prism_rtl::cat(crate::emit::cpp::items::cpp_doc(prism_rtl::cat("The ", doc_p15, ".")), "static constexpr std::uint32_t ", c_p13, " = ", h_p14, ";");
            }), Text::lit("\n"));
            call_value(each_job(prism_rtl::deref(n_p1_2).fields, ({
            auto cp_p0_1_3 = cp_p0_1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy, Text>)>>(prism_rtl::rc([=, cp_p0_1_3 = std::move(cp_p0_1_3)](std::tuple<Text, crate::lower::model::OutTy, Text> p0) {
            return ({
                auto cp_p0_1_3_3 = cp_p0_1_3;
                entered(once_job([=, cp_p0_1_3_3 = std::move(cp_p0_1_3_3)]() {
                return ({
                    auto&& _f_p16 = p0;
                    auto&& f_p16 = std::get<0>(_f_p16);
                    auto&& t_p17 = std::get<1>(_f_p16);
                    call_then(crate::emit::cpp::start_cpp_type(cp_p0_1_3_3, t_p17), [=](Text cpp_type_1609) { return prism_rtl::finished(prism_rtl::cat(cpp_type_1609, " ", crate::emit::cpp::field_id(f_p16))); });
                });
            }));
            });
        })));
        })), [=, fields_p4 = std::move(fields_p4), consts_p5 = std::move(consts_p5)](Array<Text> each_1572) {
            return ({
                auto ctor_params_p6 = crate::syntax::lexer::chars::join(append(Array(std::vector{Text::lit("Path path")}), each_1572), Text::lit(", "));
                auto ctor_inits_p7 = crate::syntax::lexer::chars::join(append(Array(std::vector{Text::lit("path(std::move(path))")}), each(prism_rtl::deref(n_p1_2).fields, [&](const std::tuple<Text, crate::lower::model::OutTy, Text>& _p0) {
                    auto&& f_p18 = std::get<0>(_p0);
                    return prism_rtl::cat(crate::emit::cpp::field_id(f_p18), "(std::move(", crate::emit::cpp::field_id(f_p18), "))");
                })), Text::lit(", "));
                call_value(each_job(prism_rtl::deref(n_p1_2).params, ({
                auto cp_p0_1_3 = cp_p0_1;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=, cp_p0_1_3 = std::move(cp_p0_1_3)](std::tuple<Text, crate::lower::model::OutTy> p0) {
                return ({
                    auto cp_p0_1_3_3 = cp_p0_1_3;
                    entered(once_job([=, cp_p0_1_3_3 = std::move(cp_p0_1_3_3)]() {
                    return ({
                        auto [p_p19, t_p1a] = p0;
                        call_then(crate::emit::cpp::expr::start_param_type(cp_p0_1_3_3, t_p1a), [=](Text param_type_1848) { return prism_rtl::finished(prism_rtl::cat(param_type_1848, " ", p_p19, ", ")); });
                    });
                }));
                });
            })));
            })), [=, ctor_params_p6 = std::move(ctor_params_p6), ctor_inits_p7 = std::move(ctor_inits_p7)](Array<Text> each_1819) {
                return ({
                    auto params_p8 = concat(each_1819);
                    auto ret_p9 = prism_rtl::deref(n_p1_2).fallible
                        ? prism_rtl::cat("Result<prism_rtl::Rc<", prism_rtl::deref(n_p1_2).name, ">>")
                        : prism_rtl::cat("prism_rtl::Rc<", prism_rtl::deref(n_p1_2).name, ">");
                    auto make_decl_pa = prism_rtl::cat("static ", ret_p9, " make(Path path, ", params_p8, "Cx& cx);");
                    call_value(each_job(append(prism_rtl::deref(n_p1_2).methods, prism_rtl::deref(n_p1_2).hosted), ({
                    auto ncp_p2_3 = ncp_p2;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::MethDef)>>(prism_rtl::rc([=, ncp_p2_3 = std::move(ncp_p2_3)](crate::lower::model::MethDef p0) {
                    return ({
                        auto ncp_p2_3_4 = ncp_p2_3;
                        entered(once_job([=, ncp_p2_3_4 = std::move(ncp_p2_3_4)]() {
                        return ({
                            auto m_p1b = p0;
                            call_then(start_method_sig(ncp_p2_3_4, m_p1b, Text::lit("")), [=](Text method_sig_2099) { return prism_rtl::finished(prism_rtl::cat(method_sig_2099, ";")); });
                        });
                    }));
                    });
                })));
                })), [=, params_p8 = std::move(params_p8), ret_p9 = std::move(ret_p9), make_decl_pa = std::move(make_decl_pa)](Array<Text> each_2057) {
                    return ({
                        auto method_decls_pb = each_2057;
                        auto builder_decls_pc = append(each(prism_rtl::deref(n_p1_2).builders, [&](const crate::lower::model::ForDef& b_p1c) { return prism_rtl::cat("Done ", prism_rtl::deref(b_p1c).name, "_build(Cx& cx);"); }), each(prism_rtl::deref(n_p1_2).gens, [&](const crate::lower::model::GenDef& g_p1d) { return prism_rtl::cat("Done ", prism_rtl::deref(g_p1d).name, "_build(Cx& cx);"); }));
                        auto hook_decls_pd = each(prism_rtl::deref(n_p1_2).hooks, [&](const std::tuple<Text, Array<crate::lower::model::Do>>& _p0) {
                            auto&& h_p1e = std::get<0>(_p0);
                            return prism_rtl::cat(hook_sig(h_p1e, Text::lit("")), " override;");
                        });
                        auto answer_decl_pe = len(prism_rtl::deref(n_p1_2).answers) == Nat(0u)
                            ? Array<Text>{}
                            : Array(std::vector{Text::lit("Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;")});
                        auto row_decl_pf = prism_rtl::deref(n_p1_2).row_kind == crate::lower::model::RowKind(crate::lower::model::RowKind::NotARow{})
                            ? Array<Text>{}
                            : Array(std::vector{Text::lit("void leave_row(Cx& cx) override;")});
                        auto decls_pg = crate::syntax::lexer::chars::join(append(append(append(append(append(Array(std::vector{make_decl_pa}), method_decls_pb), builder_decls_pc), hook_decls_pd), answer_decl_pe), row_decl_pf), Text::lit("\n"));
                        auto doc_ph = crate::emit::cpp::items::cpp_source_doc(prism_rtl::cat("`", prism_rtl::deref(n_p1_2).prism, "`: a node of its own (claude/backend.md, \"A widget block\")."), prism_rtl::deref(n_p1_2).doc);
                        auto decl_pi = crate::emit::cpp::templates::items::node_class(doc_ph, prism_rtl::deref(n_p1_2).name, base_p3, fields_p4, consts_p5, prism_rtl::cat(prism_rtl::deref(n_p1_2).name, "(", ctor_params_p6, ") : ", ctor_inits_p7, " {}"), decls_pg);
                        auto by_field_pj = each(prism_rtl::deref(n_p1_2).fields, [&](const std::tuple<Text, crate::lower::model::OutTy, Text>& _p0) {
                            auto&& f_p1f = std::get<0>(_p0);
                            return or_(fold(prism_rtl::deref(n_p1_2).inits, std::optional<crate::lower::model::Ex>{}, [&](const std::optional<crate::lower::model::Ex>& found_o1g, const std::tuple<Text, crate::lower::model::Ex>& _p1) {
                                auto&& g_p1h = std::get<0>(_p1);
                                auto&& v_p1i = std::get<1>(_p1);
                                return g_p1h == f_p1f ? std::optional(v_p1i) : found_o1g;
                            }), crate::lower::model::Ex(crate::lower::model::Ex::XVar{f_p1f}));
                        });
                        call_then(crate::emit::cpp::stmts::start_cpp_statements_cp(ncp_p2, prism_rtl::deref(n_p1_2).lets), [=, decl_pi = std::move(decl_pi), by_field_pj = std::move(by_field_pj)](std::tuple<Text, crate::emit::cpp::Cp> cpp_statements_cp_3170) {
                        return ({
                            auto [lets_text_p1j, lcp_p1k] = cpp_statements_cp_3170;
                            call_value(each_job(by_field_pj, ({
                            auto lcp_p1k_3 = lcp_p1k;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Ex)>>(prism_rtl::rc([=, lcp_p1k_3 = std::move(lcp_p1k_3)](crate::lower::model::Ex p0) {
                            return ({
                                auto lcp_p1k_3_4 = lcp_p1k_3;
                                entered(once_job([=, lcp_p1k_3_4 = std::move(lcp_p1k_3_4)]() {
                                return ({
                                    auto v_p1l = p0;
                                    (prism_rtl::more(prism_rtl::rc(crate::emit::cpp::expr::CppExpr(lcp_p1k_3_4, v_p1l))));
                                });
                            }));
                            });
                        })));
                        })), [=](Array<Text> each_3239) {
                            return ({
                                auto args_pk = crate::syntax::lexer::chars::join(append(Array(std::vector{Text::lit("path")}), each_3239), Text::lit(", "));
                                auto tail_pl = prism_rtl::deref(n_p1_2).fallible
                                    ? Text::lit("return node;")
                                    : Text::lit("return node;");
                                call_then(crate::emit::cpp::stmts::start_cpp_statements(crate::emit::cpp::stmts::pointing(lcp_p1k, Text::lit("node")), n_p1_2->build), [=, args_pk = std::move(args_pk), tail_pl = std::move(tail_pl)](Text cpp_statements_3463) {
                                return ({
                                    auto make_pm = crate::emit::cpp::templates::items::node_make(prism_rtl::deref(n_p1_2).name, prism_rtl::cat(ret_p9, " ", prism_rtl::deref(n_p1_2).name, "::make(Path path, ", params_p8, "Cx& cx)"), lets_text_p1j, args_pk, crate::syntax::lexer::chars::join(filter(Array(std::vector{cpp_statements_3463, tail_pl}), [&](const Text& s_p1m) { return s_p1m != Text::lit(""); }), Text::lit("\n")));
                                    call_value(each_job(append(prism_rtl::deref(n_p1_2).methods, prism_rtl::deref(n_p1_2).hosted), ({
                                    auto ncp_p2_3 = ncp_p2;
                                    auto n_p1_2_4 = n_p1_2;
                                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::MethDef)>>(prism_rtl::rc([=, ncp_p2_3 = std::move(ncp_p2_3), n_p1_2_4 = std::move(n_p1_2_4)](crate::lower::model::MethDef p0) {
                                    return ({
                                        auto ncp_p2_3_4 = ncp_p2_3;
                                        auto n_p1_2_4_4 = n_p1_2_4;
                                        entered(once_job([=, ncp_p2_3_4 = std::move(ncp_p2_3_4), n_p1_2_4_4 = std::move(n_p1_2_4_4)]() {
                                        return ({
                                            auto m_p1n = p0;
                                            (prism_rtl::more(prism_rtl::rc(MethodDef(ncp_p2_3_4, prism_rtl::deref(n_p1_2_4_4).name, m_p1n))));
                                        });
                                    }));
                                    });
                                })));
                                })), [=, make_pm = std::move(make_pm)](Array<Text> each_3558) {
                                    return ({
                                        auto methods_pn = each_3558;
                                        call_value(each_job(prism_rtl::deref(n_p1_2).builders, ({
                                        auto ncp_p2_3 = ncp_p2;
                                        auto n_p1_2_4 = n_p1_2;
                                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::ForDef)>>(prism_rtl::rc([=, ncp_p2_3 = std::move(ncp_p2_3), n_p1_2_4 = std::move(n_p1_2_4)](crate::lower::model::ForDef p0) {
                                        return ({
                                            auto ncp_p2_3_4 = ncp_p2_3;
                                            auto n_p1_2_4_4 = n_p1_2_4;
                                            entered(once_job([=, ncp_p2_3_4 = std::move(ncp_p2_3_4), n_p1_2_4_4 = std::move(n_p1_2_4_4)]() {
                                            return ({
                                                auto b_p1o = p0;
                                                (prism_rtl::more(prism_rtl::rc(ForBuildCpp(ncp_p2_3_4, prism_rtl::deref(n_p1_2_4_4).name, b_p1o))));
                                            });
                                        }));
                                        });
                                    })));
                                    })), [=, methods_pn = std::move(methods_pn)](Array<Text> each_3650) {
                                        return call_value(each_job(prism_rtl::deref(n_p1_2).gens, ({
                                            auto ncp_p2_3 = ncp_p2;
                                            auto n_p1_2_4 = n_p1_2;
                                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::GenDef)>>(prism_rtl::rc([=, ncp_p2_3 = std::move(ncp_p2_3), n_p1_2_4 = std::move(n_p1_2_4)](crate::lower::model::GenDef p0) {
                                            return ({
                                                auto ncp_p2_3_4 = ncp_p2_3;
                                                auto n_p1_2_4_4 = n_p1_2_4;
                                                entered(once_job([=, ncp_p2_3_4 = std::move(ncp_p2_3_4), n_p1_2_4_4 = std::move(n_p1_2_4_4)]() {
                                                return ({
                                                    auto g_p1p = p0;
                                                    (prism_rtl::more(prism_rtl::rc(GenBuildCpp(ncp_p2_3_4, prism_rtl::deref(n_p1_2_4_4).name, g_p1p))));
                                                });
                                            }));
                                            });
                                        })));
                                        })), [=](Array<Text> each_3702) {
                                            return ({
                                                auto builders_po = append(each_3650, each_3702);
                                                call_value(each_job(prism_rtl::deref(n_p1_2).hooks, ({
                                                auto n_p1_2_3 = n_p1_2;
                                                auto ncp_p2_3 = ncp_p2;
                                                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Array<crate::lower::model::Do>>)>>(prism_rtl::rc([=, n_p1_2_3 = std::move(n_p1_2_3), ncp_p2_3 = std::move(ncp_p2_3)](std::tuple<Text, Array<crate::lower::model::Do>> p0) {
                                                return ({
                                                    auto n_p1_2_3_4 = n_p1_2_3;
                                                    auto ncp_p2_3_4 = ncp_p2_3;
                                                    entered(once_job([=, n_p1_2_3_4 = std::move(n_p1_2_3_4), ncp_p2_3_4 = std::move(ncp_p2_3_4)]() {
                                                    return ({
                                                        auto [h_p1q, body_p1r] = p0;
                                                        call_then(crate::emit::cpp::stmts::start_cpp_statements(ncp_p2_3_4, body_p1r), [=](Text cpp_statements_3838) { return prism_rtl::finished(crate::emit::cpp::templates::items::cpp_function(Text::lit(""), hook_sig(h_p1q, prism_rtl::cat(prism_rtl::deref(n_p1_2_3_4).name, "::")), prism_rtl::cat(cpp_statements_3838, "\nreturn {};"))); });
                                                    });
                                                }));
                                                });
                                            })));
                                            })), [=, builders_po = std::move(builders_po)](Array<Text> each_3764) {
                                                return ({
                                                    auto hooks_pp = each_3764;
                                                    auto answer_pq = len(prism_rtl::deref(n_p1_2).answers) == Nat(0u)
                                                        ? Array<Text>{}
                                                        : Array(std::vector{answer_def_cpp(ncp_p2, n_p1_2)});
                                                    auto leaving_pr = prism_rtl::deref(n_p1_2).row_kind == crate::lower::model::RowKind(crate::lower::model::RowKind::NotARow{})
                                                        ? Array<Text>{}
                                                        : Array(std::vector{row_leaving(ncp_p2, n_p1_2)});
                                                    auto defs_ps = append(append(append(append(append(Array(std::vector{make_pm}), methods_pn), builders_po), hooks_pp), answer_pq), leaving_pr);
                                                    auto own_pt = crate::emit::cpp::items::Parts{.forward = Array(std::vector{prism_rtl::cat("class ", prism_rtl::deref(n_p1_2).name, ";")}), .values = Array<crate::emit::cpp::items::ValueDecl>{}, .protos = Array<Text>{}, .classes = Array(std::vector{decl_pi}), .outer = Array<Text>{}, .generic = Array<Text>{}, .defs = defs_ps};
                                                    (prism_rtl::finished(own_pt));
                                                });
                                            });
                                            });
                                        });
                                    });
                                    });
                                });
                                });
                            });
                            });
                        });
                        });
                    });
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start NodeParts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::emit::cpp::items::Parts> start_node_parts(crate::emit::cpp::Cp cp_p0, crate::lower::model::NodeDef n_p1) {
    return prism_rtl::make_rc<NodeParts>(cp_p0, n_p1);
}


/// MethodSig: unbounded fn Cp, MethDef, Text -> Text
Text method_sig(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::MethDef& m_p1, const Text& owner_p2) {
    auto cx_p3 = ({
        __label__ _done;
        prism_rtl::Slot<Array<Text>> _v;
        auto&& _m = m_p1.cx_;
        if (prism_rtl::is<crate::lower::model::CxArg::CxMut>(_m)) {
            _v.set(Array(std::vector{Text::lit("Cx& cx")}));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::CxArg::CxRef>(_m)) {
            _v.set(Array(std::vector{Text::lit("const Cx& cx")}));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::CxArg::CxNone>(_m)) {
            _v.set(Array<Text>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto params_p4 = crate::syntax::lexer::chars::join(append(run_to_end(each_job(m_p1.params, ({
        auto cp_p0_1 = cp_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=, cp_p0_1 = std::move(cp_p0_1)](std::tuple<Text, crate::lower::model::OutTy> p0) {
        return ({
            auto cp_p0_1_2 = cp_p0_1;
            entered(once_job([=, cp_p0_1_2 = std::move(cp_p0_1_2)]() {
            return ({
                auto [p_p6, t_p7] = p0;
                call_then(crate::emit::cpp::expr::start_param_type(cp_p0_1_2, t_p7), [=](Text param_type_4531) { return prism_rtl::finished(prism_rtl::cat(param_type_4531, " ", p_p6)); });
            });
        }));
        });
    })));
    }))), cx_p3), Text::lit(", "));
    auto constness_p5 = m_p1.recv == crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{})
        ? Text::lit(" const")
        : Text::lit("");
    return prism_rtl::cat(crate::emit::cpp::cpp_type(cp_p0, m_p1.ret), " ", owner_p2, crate::emit::cpp::expr::node_method_name(cp_p0, m_p1.name), "(", params_p4, ")", constness_p5);
}


prism_rtl::Turn<Text> MethodSig::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& m_p1 = this->m_p1;
    const auto& owner_p2 = this->owner_p2;
    auto cx_p3 = ({
        __label__ _done;
        prism_rtl::Slot<Array<Text>> _v;
        auto&& _m = prism_rtl::deref(m_p1).cx_;
        if (prism_rtl::is<crate::lower::model::CxArg::CxMut>(_m)) {
            _v.set(Array(std::vector{Text::lit("Cx& cx")}));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::CxArg::CxRef>(_m)) {
            _v.set(Array(std::vector{Text::lit("const Cx& cx")}));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::CxArg::CxNone>(_m)) {
            _v.set(Array<Text>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto cp_p0_1 = cp_p0;
    auto m_p1_2 = m_p1;
    auto owner_p2_3 = owner_p2;
    return call_value(each_job(prism_rtl::deref(m_p1_2).params, ({
        auto cp_p0_1_4 = cp_p0_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=, cp_p0_1_4 = std::move(cp_p0_1_4)](std::tuple<Text, crate::lower::model::OutTy> p0) {
        return ({
            auto cp_p0_1_4_4 = cp_p0_1_4;
            entered(once_job([=, cp_p0_1_4_4 = std::move(cp_p0_1_4_4)]() {
            return ({
                auto [p_p6, t_p7] = p0;
                call_then(crate::emit::cpp::expr::start_param_type(cp_p0_1_4_4, t_p7), [=](Text param_type_4531) { return prism_rtl::finished(prism_rtl::cat(param_type_4531, " ", p_p6)); });
            });
        }));
        });
    })));
    })), [=](Array<Text> each_4502) {
        return ({
            auto params_p4 = crate::syntax::lexer::chars::join(append(each_4502, cx_p3), Text::lit(", "));
            auto constness_p5 = prism_rtl::deref(m_p1_2).recv == crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{})
                ? Text::lit(" const")
                : Text::lit("");
            call_then(crate::emit::cpp::start_cpp_type(cp_p0_1, prism_rtl::deref(m_p1_2).ret), [=, params_p4 = std::move(params_p4), constness_p5 = std::move(constness_p5)](Text cpp_type_4631) { return prism_rtl::finished(prism_rtl::cat(cpp_type_4631, " ", owner_p2_3, crate::emit::cpp::expr::node_method_name(cp_p0_1, prism_rtl::deref(m_p1_2).name), "(", params_p4, ")", constness_p5)); });
        });
    });
}


/// `Start MethodSig, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_method_sig(crate::emit::cpp::Cp cp_p0, crate::lower::model::MethDef m_p1, Text owner_p2) {
    return prism_rtl::make_rc<MethodSig>(cp_p0, m_p1, owner_p2);
}


/// MethodDef: unbounded fn Cp, Text, MethDef -> Text
Text method_def(const crate::emit::cpp::Cp& cp_p0, const Text& owner_p1, const crate::lower::model::MethDef& m_p2) {
    auto [st_p4, cp2_p5] = crate::emit::cpp::stmts::cpp_statements_cp(cp_p0, m_p2.body);
    auto body_p3 = m_p2.ret == crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})
        ? prism_rtl::cat(st_p4, "\nreturn Unit{};")
        : len(m_p2.body) == Nat(0u)
        ? crate::emit::cpp::stmts::cpp_body(cp_p0, m_p2.tail)
        : prism_rtl::cat(st_p4, "\n", crate::emit::cpp::stmts::cpp_body(cp2_p5, m_p2.tail));
    return crate::emit::cpp::templates::items::cpp_function(crate::emit::cpp::items::cpp_doc(m_p2.doc), method_sig(cp_p0, m_p2, prism_rtl::cat(owner_p1, "::")), body_p3);
}


prism_rtl::Turn<Text> MethodDef::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& owner_p1 = this->owner_p1;
    const auto& m_p2 = this->m_p2;
    auto cp_p0_1 = cp_p0;
    auto m_p2_2 = m_p2;
    auto owner_p1_3 = owner_p1;
    return call_then(crate::emit::cpp::stmts::start_cpp_statements_cp(cp_p0_1, prism_rtl::deref(m_p2_2).body), [=](std::tuple<Text, crate::emit::cpp::Cp> cpp_statements_cp_4807) {
        return ({
            auto [st_p4, cp2_p5] = cpp_statements_cp_4807;
            auto body_p3 = prism_rtl::deref(m_p2_2).ret == crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})
                ? prism_rtl::cat(st_p4, "\nreturn Unit{};")
                : len(prism_rtl::deref(m_p2_2).body) == Nat(0u)
                ? crate::emit::cpp::stmts::cpp_body(cp_p0_1, prism_rtl::deref(m_p2_2).tail)
                : prism_rtl::cat(st_p4, "\n", crate::emit::cpp::stmts::cpp_body(cp2_p5, prism_rtl::deref(m_p2_2).tail));
            call_then(start_method_sig(cp_p0_1, m_p2_2, prism_rtl::cat(owner_p1_3, "::")), [=, body_p3 = std::move(body_p3)](Text method_sig_5011) { return prism_rtl::finished(crate::emit::cpp::templates::items::cpp_function(crate::emit::cpp::items::cpp_doc(prism_rtl::deref(m_p2_2).doc), method_sig_5011, body_p3)); });
        });
    });
}


/// `Start MethodDef, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_method_def(crate::emit::cpp::Cp cp_p0, Text owner_p1, crate::lower::model::MethDef m_p2) {
    return prism_rtl::make_rc<MethodDef>(cp_p0, owner_p1, m_p2);
}


/// HookSig: fn Text, Text -> Text
Text hook_sig(const Text& text0, const Text& owner_p0) {
    {
        auto&& c0_0 = text0;
        if (c0_0 == Text::lit("push")) {
            return prism_rtl::cat("Done ", owner_p0, "push(const Pod& element, const Pod& v, Cx& cx)");
        }
    }
    {
        auto&& h_p1 = text0;
        return prism_rtl::cat("Done ", owner_p0, h_p1, "(Cx& cx)");
    }
}


/// AnswerDefCpp: unbounded fn Cp, NodeDef -> Text
Text answer_def_cpp(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::NodeDef& n_p1) {
    auto arms_p2 = run_to_end(each_job(n_p1.answers, ({
        auto cp_p0_1 = cp_p0;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, Text>>(std::tuple<crate::lower::model::Pa, crate::lower::model::Ex>)>>(prism_rtl::rc([=, cp_p0_1 = std::move(cp_p0_1)](std::tuple<crate::lower::model::Pa, crate::lower::model::Ex> p0) {
        return ({
            auto cp_p0_1_2 = cp_p0_1;
            entered(once_job([=, cp_p0_1_2 = std::move(cp_p0_1_2)]() {
            return ({
                auto [pat_p4, call_p5] = p0;
                call_then(crate::emit::cpp::patterns::start_pat_conds(cp_p0_1_2, pat_p4, Text::lit("at")), [=](Array<Text> pat_conds_5354) {
                return ({
                    auto tests_p6 = pat_conds_5354;
                    call_then(crate::emit::cpp::patterns::start_pat_binds(cp_p0_1_2, pat_p4, Text::lit("at")), [=, tests_p6 = std::move(tests_p6)](Array<Text> pat_binds_5397) {
                    return ({
                        auto binds_p7 = pat_binds_5397;
                        call_then(crate::emit::cpp::expr::start_cpp_expr(cp_p0_1_2, call_p5), [=, binds_p7 = std::move(binds_p7)](Text cpp_expr_5458) { return prism_rtl::finished(std::tuple{tests_p6, crate::syntax::lexer::chars::join(crate::prelude::push(binds_p7, prism_rtl::cat(cpp_expr_5458, ";")), Text::lit("\n"))}); });
                    });
                });
                });
            });
            });
        }));
        });
    }));
    })));
    auto blocks_p3 = each(crate::check::errors::range0(len(arms_p2)), [&](const Nat& i_p8) {
        return ({
            auto [tests_p9, inner_pa] = or_(index(arms_p2, i_p8), std::tuple{Array<Text>{}, Text::lit("")});
            (crate::emit::cpp::templates::items::block(prism_rtl::cat(i_p8 == Nat(0u) ? Text::lit("if") : Text::lit("else if"), " (", crate::emit::cpp::patterns::conds(tests_p9), ")"), inner_pa));
        });
    });
    return crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat("Done ", n_p1.name, "::answer(std::span<const Segment> at, const Pod& v, Cx& cx)"), prism_rtl::cat(crate::syntax::lexer::chars::join(blocks_p3, Text::lit(" ")), " else {\n    return unexpected(Fault::answer(str(\"no answering place at \", path_of(at))));\n}\nreturn {};"));
}


prism_rtl::Turn<Text> AnswerDefCpp::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& n_p1 = this->n_p1;
    auto cp_p0_1 = cp_p0;
    auto n_p1_2 = n_p1;
    return call_value(each_job(prism_rtl::deref(n_p1_2).answers, ({
        auto cp_p0_1_3 = cp_p0_1;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, Text>>(std::tuple<crate::lower::model::Pa, crate::lower::model::Ex>)>>(prism_rtl::rc([=, cp_p0_1_3 = std::move(cp_p0_1_3)](std::tuple<crate::lower::model::Pa, crate::lower::model::Ex> p0) {
        return ({
            auto cp_p0_1_3_3 = cp_p0_1_3;
            entered(once_job([=, cp_p0_1_3_3 = std::move(cp_p0_1_3_3)]() {
            return ({
                auto [pat_p4, call_p5] = p0;
                call_then(crate::emit::cpp::patterns::start_pat_conds(cp_p0_1_3_3, pat_p4, Text::lit("at")), [=](Array<Text> pat_conds_5354) {
                return ({
                    auto tests_p6 = pat_conds_5354;
                    call_then(crate::emit::cpp::patterns::start_pat_binds(cp_p0_1_3_3, pat_p4, Text::lit("at")), [=, tests_p6 = std::move(tests_p6)](Array<Text> pat_binds_5397) {
                    return ({
                        auto binds_p7 = pat_binds_5397;
                        call_then(crate::emit::cpp::expr::start_cpp_expr(cp_p0_1_3_3, call_p5), [=, binds_p7 = std::move(binds_p7)](Text cpp_expr_5458) { return prism_rtl::finished(std::tuple{tests_p6, crate::syntax::lexer::chars::join(crate::prelude::push(binds_p7, prism_rtl::cat(cpp_expr_5458, ";")), Text::lit("\n"))}); });
                    });
                });
                });
            });
            });
        }));
        });
    }));
    })), [=](Array<std::tuple<Array<Text>, Text>> each_5301) {
        return ({
            auto arms_p2 = each_5301;
            auto blocks_p3 = each(crate::check::errors::range0(len(arms_p2)), [&](const Nat& i_p8) {
                return ({
                    auto [tests_p9, inner_pa] = or_(index(arms_p2, i_p8), std::tuple{Array<Text>{}, Text::lit("")});
                    (crate::emit::cpp::templates::items::block(prism_rtl::cat(i_p8 == Nat(0u) ? Text::lit("if") : Text::lit("else if"), " (", crate::emit::cpp::patterns::conds(tests_p9), ")"), inner_pa));
                });
            });
            (prism_rtl::finished(crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat("Done ", prism_rtl::deref(n_p1_2).name, "::answer(std::span<const Segment> at, const Pod& v, Cx& cx)"), prism_rtl::cat(crate::syntax::lexer::chars::join(blocks_p3, Text::lit(" ")), " else {\n    return unexpected(Fault::answer(str(\"no answering place at \", path_of(at))));\n}\nreturn {};"))));
        });
    });
}


/// `Start AnswerDefCpp, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_answer_def_cpp(crate::emit::cpp::Cp cp_p0, crate::lower::model::NodeDef n_p1) {
    return prism_rtl::make_rc<AnswerDefCpp>(cp_p0, n_p1);
}


/// RowLeaving: unbounded fn Cp, NodeDef -> Text
Text row_leaving(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::NodeDef& n_p1) {
    auto kept_p2 = n_p1.row_kind == crate::lower::model::RowKind(crate::lower::model::RowKind::ForRow{})
        ? Array(std::vector{Text::lit("this->left_entry = entry(cx);")})
        : Array<Text>{};
    auto unsubscribe_p3 = each(n_p1.subs, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
        auto&& ev_p4 = std::get<0>(_p0);
        auto&& m_p5 = std::get<1>(_p0);
        return prism_rtl::cat("if (auto p = parent.lock(); p && ", m_p5, "_sub) deref(p->", ev_p4, "_port).unsubscribe(*std::exchange(", m_p5, "_sub, std::nullopt));");
    });
    return crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat("void ", n_p1.name, "::leave_row(Cx& cx)"), crate::syntax::lexer::chars::join(append(crate::prelude::push(kept_p2, Text::lit("remove_places(cx);")), unsubscribe_p3), Text::lit("\n")));
}


prism_rtl::Turn<Text> RowLeaving::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& n_p1 = this->n_p1;
    auto kept_p2 = prism_rtl::deref(n_p1).row_kind == crate::lower::model::RowKind(crate::lower::model::RowKind::ForRow{})
        ? Array(std::vector{Text::lit("this->left_entry = entry(cx);")})
        : Array<Text>{};
    auto unsubscribe_p3 = each(prism_rtl::deref(n_p1).subs, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
        auto&& ev_p4 = std::get<0>(_p0);
        auto&& m_p5 = std::get<1>(_p0);
        return prism_rtl::cat("if (auto p = parent.lock(); p && ", m_p5, "_sub) deref(p->", ev_p4, "_port).unsubscribe(*std::exchange(", m_p5, "_sub, std::nullopt));");
    });
    return prism_rtl::finished(crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat("void ", prism_rtl::deref(n_p1).name, "::leave_row(Cx& cx)"), crate::syntax::lexer::chars::join(append(crate::prelude::push(kept_p2, Text::lit("remove_places(cx);")), unsubscribe_p3), Text::lit("\n"))));
}


/// `Start RowLeaving, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_row_leaving(crate::emit::cpp::Cp cp_p0, crate::lower::model::NodeDef n_p1) {
    return prism_rtl::make_rc<RowLeaving>(cp_p0, n_p1);
}


/// ForBuildCpp: unbounded fn Cp, Text, ForDef -> Text
Text for_build_cpp(const crate::emit::cpp::Cp& cp_p0, const Text& owner_p1, const crate::lower::model::ForDef& b_p2) {
    return crate::emit::cpp::templates::items::for_build_template(owner_p1, b_p2.name, crate::emit::cpp::expr::cpp_expr(cp_p0, b_p2.at), crate::emit::cpp::cpp_type(cp_p0, b_p2.key_ty), crate::emit::cpp::cpp_type(cp_p0, b_p2.value_ty), crate::emit::cpp::expr::call_path(prism_rtl::cat(b_p2.row_node, "::build")), b_p2.source, crate::emit::cpp::expr::cpp_expr(cp_p0, b_p2.parent), concat(run_to_end(each_job(b_p2.passed, ({
        auto cp_p0_1 = cp_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Ex)>>(prism_rtl::rc([=, cp_p0_1 = std::move(cp_p0_1)](crate::lower::model::Ex p0) {
        return ({
            auto cp_p0_1_2 = cp_p0_1;
            entered(once_job([=, cp_p0_1_2 = std::move(cp_p0_1_2)]() {
            return ({
                auto x_p3 = p0;
                call_then(crate::emit::cpp::expr::start_cpp_expr(cp_p0_1_2, x_p3), [=](Text cpp_expr_6762) { return prism_rtl::finished(prism_rtl::cat(", ", cpp_expr_6762)); });
            });
        }));
        });
    })));
    })))), moved_call_cpp(b_p2.moved), from_kept_cpp(b_p2.name, b_p2.replaced), replaced_call_cpp(b_p2.replaced));
}


prism_rtl::Turn<Text> ForBuildCpp::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& owner_p1 = this->owner_p1;
    const auto& b_p2 = this->b_p2;
    auto b_p2_1 = b_p2;
    auto cp_p0_2 = cp_p0;
    auto owner_p1_3 = owner_p1;
    return call_then(crate::emit::cpp::expr::start_cpp_expr(cp_p0_2, prism_rtl::deref(b_p2_1).at), [=](Text cpp_expr_6595) {
        return call_then(crate::emit::cpp::start_cpp_type(cp_p0_2, prism_rtl::deref(b_p2_1).key_ty), [=](Text cpp_type_6615) {
            return call_then(crate::emit::cpp::start_cpp_type(cp_p0_2, prism_rtl::deref(b_p2_1).value_ty), [=](Text cpp_type_6638) {
                return call_then(crate::emit::cpp::expr::start_cpp_expr(cp_p0_2, b_p2_1->parent), [=](Text cpp_expr_6706) {
                    return call_value(each_job(prism_rtl::deref(b_p2_1).passed, ({
                        auto cp_p0_2_4 = cp_p0_2;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Ex)>>(prism_rtl::rc([=, cp_p0_2_4 = std::move(cp_p0_2_4)](crate::lower::model::Ex p0) {
                        return ({
                            auto cp_p0_2_4_4 = cp_p0_2_4;
                            entered(once_job([=, cp_p0_2_4_4 = std::move(cp_p0_2_4_4)]() {
                            return ({
                                auto x_p3 = p0;
                                call_then(crate::emit::cpp::expr::start_cpp_expr(cp_p0_2_4_4, x_p3), [=](Text cpp_expr_6762) { return prism_rtl::finished(prism_rtl::cat(", ", cpp_expr_6762)); });
                            });
                        }));
                        });
                    })));
                    })), [=](Array<Text> each_6738) { return prism_rtl::finished(crate::emit::cpp::templates::items::for_build_template(owner_p1_3, prism_rtl::deref(b_p2_1).name, cpp_expr_6595, cpp_type_6615, cpp_type_6638, crate::emit::cpp::expr::call_path(prism_rtl::cat(prism_rtl::deref(b_p2_1).row_node, "::build")), b_p2_1->source, cpp_expr_6706, concat(each_6738), moved_call_cpp(prism_rtl::deref(b_p2_1).moved), from_kept_cpp(prism_rtl::deref(b_p2_1).name, prism_rtl::deref(b_p2_1).replaced), replaced_call_cpp(prism_rtl::deref(b_p2_1).replaced))); });
                });
            });
        });
    });
}


/// `Start ForBuildCpp, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_for_build_cpp(crate::emit::cpp::Cp cp_p0, Text owner_p1, crate::lower::model::ForDef b_p2) {
    return prism_rtl::make_rc<ForBuildCpp>(cp_p0, owner_p1, b_p2);
}


/// FromKeptCpp: fn Text, [Text] -> Text
Text from_kept_cpp(const Text& name_p0, const Array<Text>& replaced_p1) {
    return len(replaced_p1) == Nat(0u)
        ? prism_rtl::cat("this->", name_p0, "_from = items;")
        : prism_rtl::cat("auto from = std::exchange(this->", name_p0, "_from, items);");
}


/// ReplacedCallCpp: fn [Text] -> Text
Text replaced_call_cpp(const Array<Text>& replaced_p0) {
    return len(replaced_p0) == Nat(0u)
        ? Text::lit("")
        : prism_rtl::cat(" else if (auto was = from.get(k), is = items.get(k); !was || !is || !(*was == *is)) {\n            // the dynamic under a kept key was replaced: that row follows it from the next tick\n", concat(each(replaced_p0, [&](const Text& m_p1) { return prism_rtl::cat("            row->", m_p1, "(cx);\n"); })), "        }");
}


/// MovedCallCpp: fn Text -> Text
Text moved_call_cpp(const Text& m_p0) {
    return m_p0 == Text::lit("")
        ? Text::lit("")
        : prism_rtl::cat("\n    // the places of the host\'s child came or went: its document\'s outer moves\n    if (!prism_rtl::same_keys(next, old)) this->", m_p0, "(cx);");
}


/// GenMovedCallCpp: fn Text -> Text
Text gen_moved_call_cpp(const Text& m_p0) {
    return m_p0 == Text::lit("")
        ? Text::lit("")
        : prism_rtl::cat("\n    // the places of the host\'s child came or went: its document\'s outer moves\n    this->", m_p0, "(cx);");
}


/// GenBuildCpp: unbounded fn Cp, Text, GenDef -> Text
Text gen_build_cpp(const crate::emit::cpp::Cp& cp_p0, const Text& owner_p1, const crate::lower::model::GenDef& gd_p2) {
    auto path_p3 = gd_p2.transparent
        ? Text::lit("this->path")
        : prism_rtl::cat(crate::emit::cpp::expr::cpp_expr(cp_p0, gd_p2.at), ".child(Segment::gen(g))");
    return crate::emit::cpp::templates::items::gen_build_template(owner_p1, gd_p2.name, crate::emit::cpp::expr::cpp_expr(cp_p0, gd_p2.at), path_p3, crate::emit::cpp::expr::cpp_expr(cp_p0, gd_p2.source), crate::emit::cpp::cpp_type(cp_p0, gd_p2.value_ty), crate::emit::cpp::expr::cpp_expr(cp_p0, gd_p2.select), gen_moved_call_cpp(gd_p2.moved));
}


prism_rtl::Turn<Text> GenBuildCpp::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& owner_p1 = this->owner_p1;
    const auto& gd_p2 = this->gd_p2;
    auto path_p3 = prism_rtl::deref(gd_p2).transparent
        ? Text::lit("this->path")
        : prism_rtl::cat(crate::emit::cpp::expr::cpp_expr(cp_p0, prism_rtl::deref(gd_p2).at), ".child(Segment::gen(g))");
    auto cp_p0_1 = cp_p0;
    auto gd_p2_2 = gd_p2;
    auto owner_p1_3 = owner_p1;
    return call_then(crate::emit::cpp::expr::start_cpp_expr(cp_p0_1, prism_rtl::deref(gd_p2_2).at), [=](Text cpp_expr_8647) { return call_then(crate::emit::cpp::expr::start_cpp_expr(cp_p0_1, gd_p2_2->source), [=](Text cpp_expr_8674) { return call_then(crate::emit::cpp::start_cpp_type(cp_p0_1, prism_rtl::deref(gd_p2_2).value_ty), [=](Text cpp_type_8699) { return call_then(crate::emit::cpp::expr::start_cpp_expr(cp_p0_1, prism_rtl::deref(gd_p2_2).select), [=](Text cpp_expr_8725) { return prism_rtl::finished(crate::emit::cpp::templates::items::gen_build_template(owner_p1_3, prism_rtl::deref(gd_p2_2).name, cpp_expr_8647, path_p3, cpp_expr_8674, cpp_type_8699, cpp_expr_8725, gen_moved_call_cpp(prism_rtl::deref(gd_p2_2).moved))); }); }); }); });
}


/// `Start GenBuildCpp, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_gen_build_cpp(crate::emit::cpp::Cp cp_p0, Text owner_p1, crate::lower::model::GenDef gd_p2) {
    return prism_rtl::make_rc<GenBuildCpp>(cp_p0, owner_p1, gd_p2);
}


/// ProgramCpp: unbounded fn Cp, ProgDef, Bool -> Text
Text program_cpp(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::ProgDef& p_p1, const bool& fallible_p2) {
    auto n_p3 = len(p_p1.params);
    auto names_p4 = each(p_p1.params, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
        auto&& a_p9 = std::get<0>(_p0);
        return a_p9;
    });
    auto plural_p5 = n_p3 == Nat(1u) ? Text::lit("") : Text::lit("s");
    auto decode_p6 = n_p3 == Nat(0u)
        ? Text::lit("static_cast<void>(args);")
        : crate::syntax::lexer::chars::join(append(Array(std::vector{prism_rtl::cat("if (args.size() != ", n_p3, ") return unexpected(Fault::answer(\"@", p_p1.prism, " takes ", n_p3, " argument", plural_p5, "\"));")}), run_to_end(each_job(crate::check::errors::range0(n_p3), ({
        auto cp_p0_1 = cp_p0;
        auto p_p1_2 = p_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Nat)>>(prism_rtl::rc([=, cp_p0_1 = std::move(cp_p0_1), p_p1_2 = std::move(p_p1_2)](Nat p0) {
        return ({
            auto cp_p0_1_3 = cp_p0_1;
            auto p_p1_2_3 = p_p1_2;
            entered(once_job([=, cp_p0_1_3 = std::move(cp_p0_1_3), p_p1_2_3 = std::move(p_p1_2_3)]() {
            return ({
                auto i_pa = p0;
                (prism_rtl::more(prism_rtl::rc(DecodeArg(cp_p0_1_3, p_p1_2_3.params, i_pa))));
            });
        }));
        });
    })));
    })))), Text::lit("\n"));
    auto call_p7 = prism_rtl::cat(crate::emit::cpp::expr::call_path(prism_rtl::cat(p_p1.node_, "::build")), "(Path::root(), ", concat(each(names_p4, [&](const Text& a_pb) { return prism_rtl::cat(a_pb, ", "); })), "cx)");
    auto root_p8 = fallible_p2 ? prism_rtl::cat("TRY(", call_p7, ")") : call_p7;
    return crate::emit::cpp::templates::items::program_class(p_p1.name, p_p1.prism, crate::emit::cpp::type_path(p_p1.node_), decode_p6, root_p8);
}


prism_rtl::Turn<Text> ProgramCpp::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& p_p1 = this->p_p1;
    const auto& fallible_p2 = this->fallible_p2;
    auto n_p3 = len(prism_rtl::deref(p_p1).params);
    auto names_p4 = each(prism_rtl::deref(p_p1).params, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
        auto&& a_p9 = std::get<0>(_p0);
        return a_p9;
    });
    auto plural_p5 = n_p3 == Nat(1u) ? Text::lit("") : Text::lit("s");
    auto decode_p6 = n_p3 == Nat(0u)
        ? Text::lit("static_cast<void>(args);")
        : crate::syntax::lexer::chars::join(append(Array(std::vector{prism_rtl::cat("if (args.size() != ", n_p3, ") return unexpected(Fault::answer(\"@", prism_rtl::deref(p_p1).prism, " takes ", n_p3, " argument", plural_p5, "\"));")}), run_to_end(each_job(crate::check::errors::range0(n_p3), ({
        auto cp_p0_1 = cp_p0;
        auto p_p1_2 = p_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Nat)>>(prism_rtl::rc([=, cp_p0_1 = std::move(cp_p0_1), p_p1_2 = std::move(p_p1_2)](Nat p0) {
        return ({
            auto cp_p0_1_3 = cp_p0_1;
            auto p_p1_2_3 = p_p1_2;
            entered(once_job([=, cp_p0_1_3 = std::move(cp_p0_1_3), p_p1_2_3 = std::move(p_p1_2_3)]() {
            return ({
                auto i_pa = p0;
                (prism_rtl::more(prism_rtl::rc(DecodeArg(cp_p0_1_3, prism_rtl::deref(p_p1_2_3).params, i_pa))));
            });
        }));
        });
    })));
    })))), Text::lit("\n"));
    auto call_p7 = prism_rtl::cat(crate::emit::cpp::expr::call_path(prism_rtl::cat(prism_rtl::deref(p_p1).node_, "::build")), "(Path::root(), ", concat(each(names_p4, [&](const Text& a_pb) { return prism_rtl::cat(a_pb, ", "); })), "cx)");
    auto root_p8 = prism_rtl::deref(fallible_p2)
        ? prism_rtl::cat("TRY(", call_p7, ")")
        : call_p7;
    return prism_rtl::finished(crate::emit::cpp::templates::items::program_class(prism_rtl::deref(p_p1).name, prism_rtl::deref(p_p1).prism, crate::emit::cpp::type_path(prism_rtl::deref(p_p1).node_), decode_p6, root_p8));
}


/// `Start ProgramCpp, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_program_cpp(crate::emit::cpp::Cp cp_p0, crate::lower::model::ProgDef p_p1, bool fallible_p2) {
    return prism_rtl::make_rc<ProgramCpp>(cp_p0, p_p1, fallible_p2);
}


/// DecodeArg: unbounded fn Cp, [((Text, OutTy))], Nat -> Text
Text decode_arg(const crate::emit::cpp::Cp& cp_p0, const Array<std::tuple<Text, crate::lower::model::OutTy>>& ps_p1, const Nat& i_p2) {
    auto&& _m = index(ps_p1, i_p2);
    if (prism_rtl::is_some(_m)) {
        auto&& a_p3 = std::get<0>(prism_rtl::some_of(_m));
        auto&& t_p4 = std::get<1>(prism_rtl::some_of(_m));
        return prism_rtl::cat("auto ", a_p3, " = TRY(prism_rtl::from_pod<", crate::emit::cpp::cpp_type(cp_p0, t_p4), ">(args[", i_p2, "]));");
    }
    if (prism_rtl::is_none(_m)) {
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Text> DecodeArg::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& ps_p1 = this->ps_p1;
    const auto& i_p2 = this->i_p2;
    return ({
        auto&& _m = index(ps_p1, i_p2);
        prism_rtl::is_some(_m) ? ({
        auto&& a_p3 = std::get<0>(prism_rtl::some_of(_m));
        auto&& t_p4 = std::get<1>(prism_rtl::some_of(_m));
        ({
        auto cp_p0_1 = cp_p0;
        auto i_p2_2 = i_p2;
        call_then(crate::emit::cpp::start_cpp_type(cp_p0_1, t_p4), [=, i_p2_2 = std::move(i_p2_2)](Text cpp_type_9583) { return prism_rtl::finished(prism_rtl::cat("auto ", a_p3, " = TRY(prism_rtl::from_pod<", cpp_type_9583, ">(args[", i_p2_2, "]));")); });
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(Text::lit(""))
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start DecodeArg, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_decode_arg(crate::emit::cpp::Cp cp_p0, Array<std::tuple<Text, crate::lower::model::OutTy>> ps_p1, Nat i_p2) {
    return prism_rtl::make_rc<DecodeArg>(cp_p0, ps_p1, i_p2);
}


/// ModuleParts: unbounded fn Cp, ModDef -> Parts
crate::emit::cpp::items::Parts module_parts(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::ModDef& m_p1) {
    auto mcp_p2 = crate::emit::cpp::in_home(cp_p0, m_p1.name);
    auto all_p3 = run_to_end(fold_job(m_p1.items, crate::emit::cpp::items::no_parts(), ({
        auto mcp_p2_1 = mcp_p2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::emit::cpp::items::Parts>(std::tuple<crate::emit::cpp::items::Parts, crate::lower::model::Item>)>>(prism_rtl::rc([=, mcp_p2_1 = std::move(mcp_p2_1)](std::tuple<crate::emit::cpp::items::Parts, crate::lower::model::Item> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto mcp_p2_1_2 = mcp_p2_1;
            entered(once_job([=, mcp_p2_1_2 = std::move(mcp_p2_1_2)]() {
            return ({
                auto acc_p4 = p0;
                auto it_p5 = p1;
                call_then(crate::emit::cpp::items::start_item_parts(mcp_p2_1_2, it_p5), [=, acc_p4 = std::move(acc_p4)](crate::emit::cpp::items::Parts item_parts_10032) { return prism_rtl::finished(crate::emit::cpp::items::join_parts(acc_p4, item_parts_10032)); });
            });
        }));
        });
    })));
    })));
    return crate::emit::cpp::items::Parts{.forward = in_ns(m_p1.name, prism_rtl::deref(all_p3).forward), .values = each(prism_rtl::deref(all_p3).values, [&](const crate::emit::cpp::items::ValueDecl& v_p6) { return in_ns_value(m_p1.name, v_p6); }), .protos = in_ns(m_p1.name, prism_rtl::deref(all_p3).protos), .classes = in_ns(m_p1.name, prism_rtl::deref(all_p3).classes), .outer = prism_rtl::deref(all_p3).outer, .generic = in_ns(m_p1.name, prism_rtl::deref(all_p3).generic), .defs = prism_rtl::deref(all_p3).defs};
}


prism_rtl::Turn<crate::emit::cpp::items::Parts> ModuleParts::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& m_p1 = this->m_p1;
    auto mcp_p2 = crate::emit::cpp::in_home(cp_p0, prism_rtl::deref(m_p1).name);
    auto m_p1_1 = m_p1;
    return call_value(fold_job(prism_rtl::deref(m_p1_1).items, crate::emit::cpp::items::no_parts(), ({
        auto mcp_p2_2 = mcp_p2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::emit::cpp::items::Parts>(std::tuple<crate::emit::cpp::items::Parts, crate::lower::model::Item>)>>(prism_rtl::rc([=, mcp_p2_2 = std::move(mcp_p2_2)](std::tuple<crate::emit::cpp::items::Parts, crate::lower::model::Item> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto mcp_p2_2_3 = mcp_p2_2;
            entered(once_job([=, mcp_p2_2_3 = std::move(mcp_p2_2_3)]() {
            return ({
                auto acc_p4 = p0;
                auto it_p5 = p1;
                call_then(crate::emit::cpp::items::start_item_parts(mcp_p2_2_3, it_p5), [=, acc_p4 = std::move(acc_p4)](crate::emit::cpp::items::Parts item_parts_10032) { return prism_rtl::finished(crate::emit::cpp::items::join_parts(acc_p4, item_parts_10032)); });
            });
        }));
        });
    })));
    })), [=](crate::emit::cpp::items::Parts fold_9982) {
        return ({
            auto all_p3 = fold_9982;
            (prism_rtl::finished(crate::emit::cpp::items::Parts{.forward = in_ns(prism_rtl::deref(m_p1_1).name, prism_rtl::deref(all_p3).forward), .values = each(prism_rtl::deref(all_p3).values, [&](const crate::emit::cpp::items::ValueDecl& v_p6) { return in_ns_value(prism_rtl::deref(m_p1_1).name, v_p6); }), .protos = in_ns(prism_rtl::deref(m_p1_1).name, prism_rtl::deref(all_p3).protos), .classes = in_ns(prism_rtl::deref(m_p1_1).name, prism_rtl::deref(all_p3).classes), .outer = prism_rtl::deref(all_p3).outer, .generic = in_ns(prism_rtl::deref(m_p1_1).name, prism_rtl::deref(all_p3).generic), .defs = prism_rtl::deref(all_p3).defs}));
        });
    });
}


/// `Start ModuleParts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::emit::cpp::items::Parts> start_module_parts(crate::emit::cpp::Cp cp_p0, crate::lower::model::ModDef m_p1) {
    return prism_rtl::make_rc<ModuleParts>(cp_p0, m_p1);
}


/// InNsValue: fn Text, ValueDecl -> ValueDecl
crate::emit::cpp::items::ValueDecl in_ns_value(const Text& ns_p0, const crate::emit::cpp::items::ValueDecl& v_p1) {
    crate::emit::cpp::items::ValueDecl this_ = v_p1;
    this_.text = prism_rtl::cat("namespace ", ns_p0, " {\n\n", this_.text, "\n\n}  // namespace ", ns_p0);
    return this_;
}


/// InNs: fn Text, [Text] -> [Text]
Array<Text> in_ns(const Text& ns_p0, const Array<Text>& xs1) {
    {
        auto&& c0_1 = xs1;
        if (c0_1.size() == 0u) {
            return Array<Text>{};
        }
    }
    {
        auto&& xs_p2 = xs1;
        return Array(std::vector{prism_rtl::cat("namespace ", ns_p0, " {\n\n", crate::syntax::lexer::chars::join(xs_p2, Text::lit("\n\n")), "\n\n}  // namespace ", ns_p0)});
    }
}


/// NodeFallibleCpp: fn Model, Text -> Bool
bool node_fallible_cpp(const crate::lower::model::Model& model_p0, const Text& path_p1) {
    return fold(model_p0.mods, false, [&](const bool& f_p2, const crate::lower::model::ModDef& m_p3) {
        return fold(prism_rtl::deref(m_p3).items, f_p2, [&](const bool& f2_p4, const crate::lower::model::Item& it_p5) {
            return ({
                __label__ _done;
                prism_rtl::Slot<bool> _v;
                if (prism_rtl::is<crate::lower::model::Item::ItNode>(it_p5)) {
                    auto&& n_p6 = prism_rtl::as<crate::lower::model::Item::ItNode>(it_p5).a0;
                    _v.set(prism_rtl::deref(f2_p4) || ((prism_rtl::cat(prism_rtl::deref(m_p3).name, "::", prism_rtl::deref(n_p6).name) == path_p1) && prism_rtl::deref(n_p6).fallible));
                    goto _done;
                }
                {
                    _v.set(prism_rtl::deref(f2_p4));
                    goto _done;
                }
            _done:
                _v.take();
            });
        });
    });
}


/// EmitCpp: unbounded fn Model, Text, [Text] -> [((Text, Text))]
Array<std::tuple<Text, Text>> emit_cpp(const crate::lower::model::Model& model_p0, const Text& runtime_p1, const Array<Text>& scripts_p2) {
    auto cp_p3 = crate::emit::cpp::context(model_p0);
    auto crate_p4 = crate::emit::cpp::in_home(cp_p3, Text::lit(""));
    auto elem_p5 = crate::emit::cpp::items::row_parts(crate_p4, Text::lit(""), model_p0.elem);
    auto answer_p6 = crate::emit::cpp::items::answer_parts(crate_p4, model_p0.answer);
    auto mods_p7 = run_to_end(each_job(model_p0.mods, ({
        auto cp_p3_1 = cp_p3;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::emit::cpp::items::Parts>(crate::lower::model::ModDef)>>(prism_rtl::rc([=, cp_p3_1 = std::move(cp_p3_1)](crate::lower::model::ModDef p0) {
        return ({
            auto cp_p3_1_2 = cp_p3_1;
            entered(once_job([=, cp_p3_1_2 = std::move(cp_p3_1_2)]() {
            return ({
                auto m_pu = p0;
                (prism_rtl::more(prism_rtl::rc(ModuleParts(cp_p3_1_2, m_pu))));
            });
        }));
        });
    })));
    })));
    auto programs_p8 = crate::syntax::lexer::chars::join(run_to_end(each_job(all_programs_cpp(model_p0), ({
        auto crate_p4_1 = crate_p4;
        auto model_p0_2 = model_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::ProgDef)>>(prism_rtl::rc([=, crate_p4_1 = std::move(crate_p4_1), model_p0_2 = std::move(model_p0_2)](crate::lower::model::ProgDef p0) {
        return ({
            auto crate_p4_1_3 = crate_p4_1;
            auto model_p0_2_3 = model_p0_2;
            entered(once_job([=, crate_p4_1_3 = std::move(crate_p4_1_3), model_p0_2_3 = std::move(model_p0_2_3)]() {
            return ({
                auto p_pv = p0;
                (prism_rtl::more(prism_rtl::rc(ProgramCpp(crate_p4_1_3, p_pv, node_fallible_cpp(model_p0_2_3, prism_rtl::deref(p_pv).node_)))));
            });
        }));
        });
    })));
    }))), Text::lit("\n\n"));
    auto regs_p9 = concat(each(model_p0.programs, [&](const crate::lower::model::ProgDef& p_p10) { return prism_rtl::cat("\n.program<", prism_rtl::deref(p_p10).name, ">(\"", prism_rtl::deref(p_p10).prism, "\")"); }));
    auto checks_pa = concat(run_to_end(each_job(model_p0.checks, ({
        auto crate_p4_1 = crate_p4;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::CheckDef)>>(prism_rtl::rc([=, crate_p4_1 = std::move(crate_p4_1)](crate::lower::model::CheckDef p0) {
        return ({
            auto crate_p4_1_2 = crate_p4_1;
            entered(once_job([=, crate_p4_1_2 = std::move(crate_p4_1_2)]() {
            return ({
                auto c_p11 = p0;
                call_value(each_job(prism_rtl::deref(c_p11).lines, ({
                auto crate_p4_1_2_2 = crate_p4_1_2;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Ex)>>(prism_rtl::rc([=, crate_p4_1_2_2 = std::move(crate_p4_1_2_2)](crate::lower::model::Ex p0) {
                return ({
                    auto crate_p4_1_2_2_2 = crate_p4_1_2_2;
                    entered(once_job([=, crate_p4_1_2_2_2 = std::move(crate_p4_1_2_2_2)]() {
                    return ({
                        auto l_p12 = p0;
                        (prism_rtl::more(prism_rtl::rc(crate::emit::cpp::expr::CppExpr(crate_p4_1_2_2_2, l_p12))));
                    });
                }));
                });
            })));
            })), [=](Array<Text> each_11535) { return prism_rtl::finished(prism_rtl::cat("\n.check(\"", prism_rtl::deref(c_p11).name, "\", [] { return std::vector<Result<Pod>>{", crate::syntax::lexer::chars::join(each_11535, Text::lit(", ")), "}; })")); });
            });
        }));
        });
    })));
    }))));
    auto script_list_pb = crate::syntax::lexer::chars::join(each(scripts_p2, [&](const Text& s_p13) { return prism_rtl::cat("\"", crate::lower::expr::escape(s_p13), "\","); }), Text::lit("\n"));
    auto world_pc = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = model_p0.root;
        if (prism_rtl::is_some(_m)) {
            auto&& r_p14 = prism_rtl::some_of(_m);
            _v.set(r_p14->world);
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text::lit("test"));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto canvas_pd = world_pc == Text::lit("canvas");
    auto run_root_pe = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = model_p0.root;
        if (prism_rtl::is_some(_m)) {
            auto&& r_p15 = prism_rtl::some_of(_m);
            _v.set(crate::emit::cpp::templates::cpp_run_root(prism_rtl::deref(r_p15).name, std::move(canvas_pd)
                ? crate::emit::cpp::templates::cpp_canvas_run(prism_rtl::deref(r_p15).name)
                : crate::emit::cpp::templates::cpp_no_canvas(prism_rtl::deref(r_p15).name)));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(crate::emit::cpp::templates::cpp_no_root(model_p0.name));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto both_pf = crate::emit::cpp::items::join_parts(elem_p5, answer_p6);
    auto elem_decl_pg = crate::emit::cpp::templates::cpp_elem_decl(includes(Text::lit("decl"), append(model_p0.elem_complete, model_p0.elem_declared)), crate::syntax::lexer::chars::join(prism_rtl::deref(both_pf).forward, Text::lit("\n\n")), crate::emit::cpp::prelude::cpp_prelude_rows(Text::lit("")));
    auto elem_types_ph = crate::emit::cpp::templates::cpp_elem_types(crate::syntax::lexer::chars::join(filter(Array(std::vector{includes(Text::lit("types"), model_p0.elem_complete), includes(Text::lit("decl"), model_p0.elem_declared)}), [&](const Text& t_p16) { return t_p16 != Text::lit(""); }), Text::lit("\n")), crate::syntax::lexer::chars::join(each(prism_rtl::deref(both_pf).values, [&](const crate::emit::cpp::items::ValueDecl& v_p17) { return v_p17->text; }), Text::lit("\n\n")));
    auto pairs_pi = each(crate::check::errors::range0(len(model_p0.mods)), [&](const Nat& i_p18) { return std::tuple{or_(index(model_p0.mods, i_p18), no_mod()), or_(index(mods_p7, i_p18), crate::emit::cpp::items::no_parts())}; });
    auto generics_pj = fold(pairs_pi, Array<Text>{}, [&](const Array<Text>& acc_p19, const std::tuple<crate::lower::model::ModDef, crate::emit::cpp::items::Parts>& _p1) {
        auto&& m_p1a = std::get<0>(_p1);
        auto&& p_p1b = std::get<1>(_p1);
        return len(prism_rtl::deref(p_p1b).generic) > Nat(0u)
            ? crate::prelude::push(acc_p19, prism_rtl::deref(m_p1a).name)
            : acc_p19;
    });
    auto per_module_pk = run_to_end(each_job(pairs_pi, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, Text>>, Array<Piece>>>(std::tuple<crate::lower::model::ModDef, crate::emit::cpp::items::Parts>)>>(prism_rtl::rc([=](std::tuple<crate::lower::model::ModDef, crate::emit::cpp::items::Parts> p0) {
        return entered(once_job([=]() {
            return ({
                auto [m_p1c, p_p1d] = p0;
                (prism_rtl::more(prism_rtl::rc(ModuleFiles(m_p1c, p_p1d))));
            });
        }));
    }))));
    auto pieces_pl = fold(per_module_pk, Array<Piece>{}, [&](const Array<Piece>& acc_p1e, const std::tuple<Array<std::tuple<Text, Text>>, Array<Piece>>& _p1) {
        auto&& ps_p1f = std::get<1>(_p1);
        return append(acc_p1e, ps_p1f);
    });
    auto units_pm = units(pieces_pl);
    auto unit_files_pn = each(crate::check::errors::range0(len(units_pm)), [&](const Nat& k_p1g) { return unit_file(k_p1g, or_(index(units_pm, k_p1g), Array<Piece>{}), generics_pj); });
    auto main_includes_po = crate::syntax::lexer::chars::join(append(append(Array(std::vector{Text::lit("#include \"elem.types.hpp\"")}), Array(std::vector{includes(Text::lit(""), each(model_p0.mods, [&](const crate::lower::model::ModDef& m_p1h) { return prism_rtl::deref(m_p1h).name; }))})), Array(std::vector{includes(Text::lit("generic"), generics_pj)})), Text::lit("\n"));
    auto canvas_include_pp = std::move(canvas_pd)
        ? crate::emit::cpp::templates::cpp_canvas_include(Text::lit(""))
        : Text::lit("");
    auto main_pq = crate::emit::cpp::templates::cpp_main(model_p0.name, prism_rtl::cat("#include \"programs.hpp\"\n", canvas_include_pp), regs_p9, checks_pa, script_list_pb, world_pc, run_root_pe, crate::syntax::lexer::chars::join(crate::emit::cpp::patterns::concat2(each(Array(std::vector{elem_p5, answer_p6}), [&](const crate::emit::cpp::items::Parts& p_p1i) { return prism_rtl::deref(p_p1i).defs; })), Text::lit("\n\n")));
    auto groups_pr = run_to_end(each_job(filter(model_p0.mods, [&](const crate::lower::model::ModDef& m_p1j) { return (len(prism_rtl::deref(m_p1j).types_with) > Nat(1u)) && (or_(index(prism_rtl::deref(m_p1j).types_with, Nat(0u)), Text::lit("")) == prism_rtl::deref(m_p1j).name); }), ({
        auto pairs_pi_1 = pairs_pi;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, Text>>(crate::lower::model::ModDef)>>(prism_rtl::rc([=, pairs_pi_1 = std::move(pairs_pi_1)](crate::lower::model::ModDef p0) {
        return ({
            auto pairs_pi_1_2 = pairs_pi_1;
            entered(once_job([=, pairs_pi_1_2 = std::move(pairs_pi_1_2)]() {
            return ({
                auto m_p1k = p0;
                (prism_rtl::more(prism_rtl::rc(GroupTypesFile(pairs_pi_1_2, prism_rtl::deref(m_p1k).types_with))));
            });
        }));
        });
    }));
    })));
    auto files_ps = append(fold(per_module_pk, Array<std::tuple<Text, Text>>{}, [&](const Array<std::tuple<Text, Text>>& acc_p1l, const std::tuple<Array<std::tuple<Text, Text>>, Array<Piece>>& _p1) {
        auto&& fs_p1m = std::get<0>(_p1);
        return append(acc_p1l, fs_p1m);
    }), unit_files_pn);
    auto sources_pt = crate::syntax::lexer::chars::join(filter(each(files_ps, [&](const std::tuple<Text, Text>& _p0) {
        auto&& f_p1n = std::get<0>(_p0);
        return f_p1n;
    }), [&](const Text& f_p1o) { return crate::syntax::lexer::chars::contains(f_p1o, Text::lit(".cpp")); }), Text::lit(" "));
    return append(Array(std::vector{std::tuple{Text::lit("Makefile"), crate::emit::cpp::templates::cpp_makefile(model_p0.name, runtime_p1, sources_pt, std::move(canvas_pd)
        ? crate::emit::cpp::templates::cpp_makefile_canvas(runtime_p1)
        : Text::lit(""))}, std::tuple{Text::lit("src/elem.decl.hpp"), elem_decl_pg}, std::tuple{Text::lit("src/elem.types.hpp"), elem_types_ph}, std::tuple{Text::lit("src/programs.hpp"), crate::emit::cpp::templates::cpp_programs_header(model_p0.name, main_includes_po, programs_p8)}, std::tuple{Text::lit("src/main.cpp"), main_pq}, std::tuple{Text::lit("src/prelude.hpp"), crate::emit::cpp::prelude::cpp_prelude_source(Text::lit(""))}}), append(groups_pr, files_ps));
}


prism_rtl::Turn<Array<std::tuple<Text, Text>>> EmitCpp::cycle() const {
    const auto& model_p0 = this->model_p0;
    const auto& runtime_p1 = this->runtime_p1;
    const auto& scripts_p2 = this->scripts_p2;
    auto cp_p3 = crate::emit::cpp::context(model_p0);
    auto crate_p4 = crate::emit::cpp::in_home(cp_p3, Text::lit(""));
    auto model_p0_1 = model_p0;
    auto runtime_p1_2 = runtime_p1;
    auto scripts_p2_3 = scripts_p2;
    return call_then(crate::emit::cpp::items::start_row_parts(crate_p4, Text::lit(""), prism_rtl::deref(model_p0_1).elem), [=](crate::emit::cpp::items::Parts row_parts_11072) {
        return ({
            auto elem_p5 = row_parts_11072;
            call_then(crate::emit::cpp::items::start_answer_parts(crate_p4, model_p0_1->answer), [=, elem_p5 = std::move(elem_p5)](crate::emit::cpp::items::Parts answer_parts_11120) {
            return ({
                auto answer_p6 = answer_parts_11120;
                call_value(each_job(prism_rtl::deref(model_p0_1).mods, ({
                auto cp_p3_4 = cp_p3;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::emit::cpp::items::Parts>(crate::lower::model::ModDef)>>(prism_rtl::rc([=, cp_p3_4 = std::move(cp_p3_4)](crate::lower::model::ModDef p0) {
                return ({
                    auto cp_p3_4_5 = cp_p3_4;
                    entered(once_job([=, cp_p3_4_5 = std::move(cp_p3_4_5)]() {
                    return ({
                        auto m_pu = p0;
                        (prism_rtl::more(prism_rtl::rc(ModuleParts(cp_p3_4_5, m_pu))));
                    });
                }));
                });
            })));
            })), [=, answer_p6 = std::move(answer_p6)](Array<crate::emit::cpp::items::Parts> each_11167) {
                return ({
                    auto mods_p7 = each_11167;
                    call_value(each_job(all_programs_cpp(model_p0_1), ({
                    auto crate_p4_4 = crate_p4;
                    auto model_p0_1_5 = model_p0_1;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::ProgDef)>>(prism_rtl::rc([=, crate_p4_4 = std::move(crate_p4_4), model_p0_1_5 = std::move(model_p0_1_5)](crate::lower::model::ProgDef p0) {
                    return ({
                        auto crate_p4_4_5 = crate_p4_4;
                        auto model_p0_1_5_5 = model_p0_1_5;
                        entered(once_job([=, crate_p4_4_5 = std::move(crate_p4_4_5), model_p0_1_5_5 = std::move(model_p0_1_5_5)]() {
                        return ({
                            auto p_pv = p0;
                            (prism_rtl::more(prism_rtl::rc(ProgramCpp(crate_p4_4_5, p_pv, node_fallible_cpp(model_p0_1_5_5, prism_rtl::deref(p_pv).node_)))));
                        });
                    }));
                    });
                })));
                })), [=, mods_p7 = std::move(mods_p7)](Array<Text> each_11232) {
                    return ({
                        auto programs_p8 = crate::syntax::lexer::chars::join(each_11232, Text::lit("\n\n"));
                        auto regs_p9 = concat(each(prism_rtl::deref(model_p0_1).programs, [&](const crate::lower::model::ProgDef& p_p10) { return prism_rtl::cat("\n.program<", prism_rtl::deref(p_p10).name, ">(\"", prism_rtl::deref(p_p10).prism, "\")"); }));
                        call_value(each_job(prism_rtl::deref(model_p0_1).checks, ({
                        auto crate_p4_4 = crate_p4;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::CheckDef)>>(prism_rtl::rc([=, crate_p4_4 = std::move(crate_p4_4)](crate::lower::model::CheckDef p0) {
                        return ({
                            auto crate_p4_4_5 = crate_p4_4;
                            entered(once_job([=, crate_p4_4_5 = std::move(crate_p4_4_5)]() {
                            return ({
                                auto c_p11 = p0;
                                call_value(each_job(prism_rtl::deref(c_p11).lines, ({
                                auto crate_p4_4_5_5 = crate_p4_4_5;
                                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Ex)>>(prism_rtl::rc([=, crate_p4_4_5_5 = std::move(crate_p4_4_5_5)](crate::lower::model::Ex p0) {
                                return ({
                                    auto crate_p4_4_5_5_5 = crate_p4_4_5_5;
                                    entered(once_job([=, crate_p4_4_5_5_5 = std::move(crate_p4_4_5_5_5)]() {
                                    return ({
                                        auto l_p12 = p0;
                                        (prism_rtl::more(prism_rtl::rc(crate::emit::cpp::expr::CppExpr(crate_p4_4_5_5_5, l_p12))));
                                    });
                                }));
                                });
                            })));
                            })), [=](Array<Text> each_11535) { return prism_rtl::finished(prism_rtl::cat("\n.check(\"", prism_rtl::deref(c_p11).name, "\", [] { return std::vector<Result<Pod>>{", crate::syntax::lexer::chars::join(each_11535, Text::lit(", ")), "}; })")); });
                            });
                        }));
                        });
                    })));
                    })), [=, programs_p8 = std::move(programs_p8), regs_p9 = std::move(regs_p9)](Array<Text> each_11441) {
                        return ({
                            auto checks_pa = concat(each_11441);
                            auto script_list_pb = crate::syntax::lexer::chars::join(each(scripts_p2_3, [&](const Text& s_p13) { return prism_rtl::cat("\"", crate::lower::expr::escape(s_p13), "\","); }), Text::lit("\n"));
                            auto world_pc = ({
                                __label__ _done;
                                prism_rtl::Slot<Text> _v;
                                auto&& _m = model_p0_1->root;
                                if (prism_rtl::is_some(_m)) {
                                    auto&& r_p14 = prism_rtl::some_of(_m);
                                    _v.set(r_p14->world);
                                    goto _done;
                                }
                                if (prism_rtl::is_none(_m)) {
                                    _v.set(Text::lit("test"));
                                    goto _done;
                                }
                                prism_rtl::unreachable("no arm matched");
                            _done:
                                _v.take();
                            });
                            auto canvas_pd = world_pc == Text::lit("canvas");
                            auto run_root_pe = ({
                                __label__ _done;
                                prism_rtl::Slot<Text> _v;
                                auto&& _m = model_p0_1->root;
                                if (prism_rtl::is_some(_m)) {
                                    auto&& r_p15 = prism_rtl::some_of(_m);
                                    _v.set(crate::emit::cpp::templates::cpp_run_root(prism_rtl::deref(r_p15).name, std::move(canvas_pd)
                                        ? crate::emit::cpp::templates::cpp_canvas_run(prism_rtl::deref(r_p15).name)
                                        : crate::emit::cpp::templates::cpp_no_canvas(prism_rtl::deref(r_p15).name)));
                                    goto _done;
                                }
                                if (prism_rtl::is_none(_m)) {
                                    _v.set(crate::emit::cpp::templates::cpp_no_root(prism_rtl::deref(model_p0_1).name));
                                    goto _done;
                                }
                                prism_rtl::unreachable("no arm matched");
                            _done:
                                _v.take();
                            });
                            auto both_pf = crate::emit::cpp::items::join_parts(elem_p5, answer_p6);
                            auto elem_decl_pg = crate::emit::cpp::templates::cpp_elem_decl(includes(Text::lit("decl"), append(prism_rtl::deref(model_p0_1).elem_complete, prism_rtl::deref(model_p0_1).elem_declared)), crate::syntax::lexer::chars::join(prism_rtl::deref(both_pf).forward, Text::lit("\n\n")), crate::emit::cpp::prelude::cpp_prelude_rows(Text::lit("")));
                            auto elem_types_ph = crate::emit::cpp::templates::cpp_elem_types(crate::syntax::lexer::chars::join(filter(Array(std::vector{includes(Text::lit("types"), prism_rtl::deref(model_p0_1).elem_complete), includes(Text::lit("decl"), prism_rtl::deref(model_p0_1).elem_declared)}), [&](const Text& t_p16) { return t_p16 != Text::lit(""); }), Text::lit("\n")), crate::syntax::lexer::chars::join(each(prism_rtl::deref(both_pf).values, [&](const crate::emit::cpp::items::ValueDecl& v_p17) { return v_p17->text; }), Text::lit("\n\n")));
                            auto pairs_pi = each(crate::check::errors::range0(len(prism_rtl::deref(model_p0_1).mods)), [&](const Nat& i_p18) { return std::tuple{or_(index(prism_rtl::deref(model_p0_1).mods, i_p18), no_mod()), or_(index(mods_p7, i_p18), crate::emit::cpp::items::no_parts())}; });
                            auto generics_pj = fold(pairs_pi, Array<Text>{}, [&](const Array<Text>& acc_p19, const std::tuple<crate::lower::model::ModDef, crate::emit::cpp::items::Parts>& _p1) {
                                auto&& m_p1a = std::get<0>(_p1);
                                auto&& p_p1b = std::get<1>(_p1);
                                return len(prism_rtl::deref(p_p1b).generic) > Nat(0u)
                                    ? crate::prelude::push(acc_p19, prism_rtl::deref(m_p1a).name)
                                    : acc_p19;
                            });
                            call_value(each_job(pairs_pi, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, Text>>, Array<Piece>>>(std::tuple<crate::lower::model::ModDef, crate::emit::cpp::items::Parts>)>>(prism_rtl::rc([=](std::tuple<crate::lower::model::ModDef, crate::emit::cpp::items::Parts> p0) {
                            return entered(once_job([=]() {
                                return ({
                                    auto [m_p1c, p_p1d] = p0;
                                    (prism_rtl::more(prism_rtl::rc(ModuleFiles(m_p1c, p_p1d))));
                                });
                            }));
                        }))), [=, checks_pa = std::move(checks_pa), script_list_pb = std::move(script_list_pb), world_pc = std::move(world_pc), canvas_pd = std::move(canvas_pd), run_root_pe = std::move(run_root_pe), elem_decl_pg = std::move(elem_decl_pg), elem_types_ph = std::move(elem_types_ph), generics_pj = std::move(generics_pj)](Array<std::tuple<Array<std::tuple<Text, Text>>, Array<Piece>>> each_12547) {
                            return ({
                                auto per_module_pk = each_12547;
                                auto pieces_pl = fold(per_module_pk, Array<Piece>{}, [&](const Array<Piece>& acc_p1e, const std::tuple<Array<std::tuple<Text, Text>>, Array<Piece>>& _p1) {
                                    auto&& ps_p1f = std::get<1>(_p1);
                                    return append(acc_p1e, ps_p1f);
                                });
                                auto units_pm = units(pieces_pl);
                                auto unit_files_pn = each(crate::check::errors::range0(len(units_pm)), [&](const Nat& k_p1g) { return unit_file(k_p1g, or_(index(units_pm, k_p1g), Array<Piece>{}), generics_pj); });
                                auto main_includes_po = crate::syntax::lexer::chars::join(append(append(Array(std::vector{Text::lit("#include \"elem.types.hpp\"")}), Array(std::vector{includes(Text::lit(""), each(prism_rtl::deref(model_p0_1).mods, [&](const crate::lower::model::ModDef& m_p1h) { return prism_rtl::deref(m_p1h).name; }))})), Array(std::vector{includes(Text::lit("generic"), generics_pj)})), Text::lit("\n"));
                                auto canvas_include_pp = canvas_pd
                                    ? crate::emit::cpp::templates::cpp_canvas_include(Text::lit(""))
                                    : Text::lit("");
                                auto main_pq = crate::emit::cpp::templates::cpp_main(prism_rtl::deref(model_p0_1).name, prism_rtl::cat("#include \"programs.hpp\"\n", canvas_include_pp), regs_p9, checks_pa, script_list_pb, world_pc, run_root_pe, crate::syntax::lexer::chars::join(crate::emit::cpp::patterns::concat2(each(Array(std::vector{elem_p5, answer_p6}), [&](const crate::emit::cpp::items::Parts& p_p1i) { return prism_rtl::deref(p_p1i).defs; })), Text::lit("\n\n")));
                                call_value(each_job(filter(prism_rtl::deref(model_p0_1).mods, [&](const crate::lower::model::ModDef& m_p1j) { return (len(prism_rtl::deref(m_p1j).types_with) > Nat(1u)) && (or_(index(prism_rtl::deref(m_p1j).types_with, Nat(0u)), Text::lit("")) == prism_rtl::deref(m_p1j).name); }), ({
                                auto pairs_pi_4 = pairs_pi;
                                static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, Text>>(crate::lower::model::ModDef)>>(prism_rtl::rc([=, pairs_pi_4 = std::move(pairs_pi_4)](crate::lower::model::ModDef p0) {
                                return ({
                                    auto pairs_pi_4_5 = pairs_pi_4;
                                    entered(once_job([=, pairs_pi_4_5 = std::move(pairs_pi_4_5)]() {
                                    return ({
                                        auto m_p1k = p0;
                                        (prism_rtl::more(prism_rtl::rc(GroupTypesFile(pairs_pi_4_5, prism_rtl::deref(m_p1k).types_with))));
                                    });
                                }));
                                });
                            }));
                            })), [=, per_module_pk = std::move(per_module_pk), unit_files_pn = std::move(unit_files_pn), main_includes_po = std::move(main_includes_po), main_pq = std::move(main_pq)](Array<std::tuple<Text, Text>> each_13227) {
                                return ({
                                    auto groups_pr = each_13227;
                                    auto files_ps = append(fold(per_module_pk, Array<std::tuple<Text, Text>>{}, [&](const Array<std::tuple<Text, Text>>& acc_p1l, const std::tuple<Array<std::tuple<Text, Text>>, Array<Piece>>& _p1) {
                                        auto&& fs_p1m = std::get<0>(_p1);
                                        return append(acc_p1l, fs_p1m);
                                    }), unit_files_pn);
                                    auto sources_pt = crate::syntax::lexer::chars::join(filter(each(files_ps, [&](const std::tuple<Text, Text>& _p0) {
                                        auto&& f_p1n = std::get<0>(_p0);
                                        return f_p1n;
                                    }), [&](const Text& f_p1o) { return crate::syntax::lexer::chars::contains(f_p1o, Text::lit(".cpp")); }), Text::lit(" "));
                                    (prism_rtl::finished(append(Array(std::vector{std::tuple{Text::lit("Makefile"), crate::emit::cpp::templates::cpp_makefile(prism_rtl::deref(model_p0_1).name, runtime_p1_2, sources_pt, canvas_pd
                                    ? crate::emit::cpp::templates::cpp_makefile_canvas(runtime_p1_2)
                                    : Text::lit(""))}, std::tuple{Text::lit("src/elem.decl.hpp"), elem_decl_pg}, std::tuple{Text::lit("src/elem.types.hpp"), elem_types_ph}, std::tuple{Text::lit("src/programs.hpp"), crate::emit::cpp::templates::cpp_programs_header(prism_rtl::deref(model_p0_1).name, main_includes_po, programs_p8)}, std::tuple{Text::lit("src/main.cpp"), main_pq}, std::tuple{Text::lit("src/prelude.hpp"), crate::emit::cpp::prelude::cpp_prelude_source(Text::lit(""))}}), append(groups_pr, files_ps))));
                                });
                            });
                            });
                        });
                        });
                    });
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start EmitCpp, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<std::tuple<Text, Text>>> start_emit_cpp(crate::lower::model::Model model_p0, Text runtime_p1, Array<Text> scripts_p2) {
    return prism_rtl::make_rc<EmitCpp>(model_p0, runtime_p1, scripts_p2);
}


/// let noMod
crate::lower::model::ModDef no_mod() {
    return crate::lower::model::ModDef{.name = Text::lit(""), .prism = Text::lit(""), .path_ = Text::lit(""), .uses = Array<Text>{}, .complete = Array<Text>{}, .declared = Array<Text>{}, .types_with = Array<Text>{}, .items = Array<crate::lower::model::Item>{}};
}


/// GroupTypesFile: unbounded fn [((ModDef, Parts))], [Text] -> ((Text, Text))
std::tuple<Text, Text> group_types_file(const Array<std::tuple<crate::lower::model::ModDef, crate::emit::cpp::items::Parts>>& pairs_p0, const Array<Text>& group_p1) {
    auto members_p2 = filter(pairs_p0, [&](const std::tuple<crate::lower::model::ModDef, crate::emit::cpp::items::Parts>& _p0) {
        auto&& m_p7 = std::get<0>(_p0);
        return among(group_p1, prism_rtl::deref(m_p7).name);
    });
    auto p_p3 = fold(members_p2, crate::emit::cpp::items::no_parts(), [&](const crate::emit::cpp::items::Parts& acc_p8, const std::tuple<crate::lower::model::ModDef, crate::emit::cpp::items::Parts>& _p1) {
        auto&& q_p9 = std::get<1>(_p1);
        return crate::emit::cpp::items::join_parts(acc_p8, q_p9);
    });
    auto complete_p4 = fold(members_p2, Array<Text>{}, [&](const Array<Text>& acc_pa, const std::tuple<crate::lower::model::ModDef, crate::emit::cpp::items::Parts>& _p1) {
        auto&& m_pb = std::get<0>(_p1);
        return fold(prism_rtl::deref(m_pb).complete, acc_pa, [&](const Array<Text>& a_pc, const Text& n_pd) {
            return among(a_pc, n_pd) || among(group_p1, n_pd)
                ? a_pc
                : crate::prelude::push(a_pc, n_pd);
        });
    });
    auto declared_p5 = fold(members_p2, Array<Text>{}, [&](const Array<Text>& acc_pe, const std::tuple<crate::lower::model::ModDef, crate::emit::cpp::items::Parts>& _p1) {
        auto&& m_pf = std::get<0>(_p1);
        return fold(prism_rtl::deref(m_pf).declared, acc_pe, [&](const Array<Text>& a_pg, const Text& n_ph) {
            return (among(a_pg, n_ph) || among(group_p1, n_ph)) || among(complete_p4, n_ph)
                ? a_pg
                : crate::prelude::push(a_pg, n_ph);
        });
    });
    auto title_p6 = prism_rtl::cat("The modules ", crate::syntax::lexer::chars::join(each(group_p1, [&](const Text& n_pi) { return prism_rtl::cat("`", n_pi, "`"); }), Text::lit(", ")));
    return std::tuple{prism_rtl::cat("src/", group_name(group_p1), ".types.hpp"), types_header(title_p6, group_p1, declared_p5, complete_p4, p_p3)};
}


prism_rtl::Turn<std::tuple<Text, Text>> GroupTypesFile::cycle() const {
    const auto& pairs_p0 = this->pairs_p0;
    const auto& group_p1 = this->group_p1;
    auto members_p2 = filter(pairs_p0, [&](const std::tuple<crate::lower::model::ModDef, crate::emit::cpp::items::Parts>& _p0) {
        auto&& m_p7 = std::get<0>(_p0);
        return among(group_p1, prism_rtl::deref(m_p7).name);
    });
    auto p_p3 = fold(members_p2, crate::emit::cpp::items::no_parts(), [&](const crate::emit::cpp::items::Parts& acc_p8, const std::tuple<crate::lower::model::ModDef, crate::emit::cpp::items::Parts>& _p1) {
        auto&& q_p9 = std::get<1>(_p1);
        return crate::emit::cpp::items::join_parts(acc_p8, q_p9);
    });
    auto complete_p4 = fold(members_p2, Array<Text>{}, [&](const Array<Text>& acc_pa, const std::tuple<crate::lower::model::ModDef, crate::emit::cpp::items::Parts>& _p1) {
        auto&& m_pb = std::get<0>(_p1);
        return fold(prism_rtl::deref(m_pb).complete, acc_pa, [&](const Array<Text>& a_pc, const Text& n_pd) {
            return among(a_pc, n_pd) || among(group_p1, n_pd)
                ? a_pc
                : crate::prelude::push(a_pc, n_pd);
        });
    });
    auto declared_p5 = fold(members_p2, Array<Text>{}, [&](const Array<Text>& acc_pe, const std::tuple<crate::lower::model::ModDef, crate::emit::cpp::items::Parts>& _p1) {
        auto&& m_pf = std::get<0>(_p1);
        return fold(prism_rtl::deref(m_pf).declared, acc_pe, [&](const Array<Text>& a_pg, const Text& n_ph) {
            return (among(a_pg, n_ph) || among(group_p1, n_ph)) || among(complete_p4, n_ph)
                ? a_pg
                : crate::prelude::push(a_pg, n_ph);
        });
    });
    auto title_p6 = prism_rtl::cat("The modules ", crate::syntax::lexer::chars::join(each(group_p1, [&](const Text& n_pi) { return prism_rtl::cat("`", n_pi, "`"); }), Text::lit(", ")));
    auto group_p1_1 = group_p1;
    return call_then(start_types_header(title_p6, group_p1_1, declared_p5, complete_p4, p_p3), [=](Text types_header_14897) { return prism_rtl::finished(std::tuple{prism_rtl::cat("src/", group_name(group_p1_1), ".types.hpp"), types_header_14897}); });
}


/// `Start GroupTypesFile, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Text, Text>> start_group_types_file(Array<std::tuple<crate::lower::model::ModDef, crate::emit::cpp::items::Parts>> pairs_p0, Array<Text> group_p1) {
    return prism_rtl::make_rc<GroupTypesFile>(pairs_p0, group_p1);
}


/// GroupName: fn [Text] -> Text
Text group_name(const Array<Text>& group_p0) {
    return crate::syntax::lexer::chars::join(each(group_p0, [&](const Text& n_p1) { return crate::syntax::lexer::chars::join(split_on(n_p1, Text::lit("::")), Text::lit("_")); }), Text::lit("-"));
}


/// ModDir: fn Text -> Text
Text mod_dir(const Text& m_p0) {
    return crate::syntax::lexer::chars::join(split_on(m_p0, Text::lit("::")), Text::lit("/"));
}


/// Among: fn [Text], Text -> Bool
bool among(const Array<Text>& xs_p0, const Text& x_p1) {
    return fold(xs_p0, false, [&](const bool& f_p2, const Text& y_p3) { return prism_rtl::deref(f_p2) || (y_p3 == x_p1); });
}


/// TypesHeader: unbounded fn Text, [Text], [Text], [Text], Parts -> Text
Text types_header(const Text& title_p0, const Array<Text>& members_p1, const Array<Text>& declared_p2, const Array<Text>& complete_p3, const crate::emit::cpp::items::Parts& p_p4) {
    auto holds_elem_p5 = fold(p_p4.values, false, [&](const bool& f_p9, const crate::emit::cpp::items::ValueDecl& v_pa) { return prism_rtl::deref(f_p9) || fold(prism_rtl::deref(v_pa).deps, false, [&](const bool& g_pb, const Text& d_pc) { return (prism_rtl::deref(g_pb) || (d_pc == Text::lit("Elem"))) || (d_pc == Text::lit("Answer")); }); });
    auto elem_p6 = std::move(holds_elem_p5)
        ? Text::lit("#include \"elem.types.hpp\"")
        : Text::lit("#include \"elem.decl.hpp\"");
    auto includes_p7 = crate::syntax::lexer::chars::join(filter(Array(std::vector{includes(Text::lit("decl"), members_p1), elem_p6, includes(Text::lit("decl"), declared_p2), includes(Text::lit("types"), complete_p3)}), [&](const Text& t_pd) { return t_pd != Text::lit(""); }), Text::lit("\n"));
    auto values_p8 = crate::syntax::lexer::chars::join(order_values(p_p4.values, fold(p_p4.values, Map<Text, bool>{}, [&](const Map<Text, bool>& acc_pe, const crate::emit::cpp::items::ValueDecl& v_pf) { return insert(acc_pe, v_pf->path_, false); }), Array<Text>{}), Text::lit("\n\n"));
    return crate::emit::cpp::templates::cpp_types_header(title_p0, includes_p7, values_p8);
}


prism_rtl::Turn<Text> TypesHeader::cycle() const {
    const auto& title_p0 = this->title_p0;
    const auto& members_p1 = this->members_p1;
    const auto& declared_p2 = this->declared_p2;
    const auto& complete_p3 = this->complete_p3;
    const auto& p_p4 = this->p_p4;
    auto holds_elem_p5 = fold(prism_rtl::deref(p_p4).values, false, [&](const bool& f_p9, const crate::emit::cpp::items::ValueDecl& v_pa) { return prism_rtl::deref(f_p9) || fold(prism_rtl::deref(v_pa).deps, false, [&](const bool& g_pb, const Text& d_pc) { return (prism_rtl::deref(g_pb) || (d_pc == Text::lit("Elem"))) || (d_pc == Text::lit("Answer")); }); });
    auto elem_p6 = std::move(holds_elem_p5)
        ? Text::lit("#include \"elem.types.hpp\"")
        : Text::lit("#include \"elem.decl.hpp\"");
    auto includes_p7 = crate::syntax::lexer::chars::join(filter(Array(std::vector{includes(Text::lit("decl"), members_p1), elem_p6, includes(Text::lit("decl"), declared_p2), includes(Text::lit("types"), complete_p3)}), [&](const Text& t_pd) { return t_pd != Text::lit(""); }), Text::lit("\n"));
    auto p_p4_1 = p_p4;
    auto title_p0_2 = title_p0;
    return call_then(start_order_values(prism_rtl::deref(p_p4_1).values, fold(prism_rtl::deref(p_p4_1).values, Map<Text, bool>{}, [&](const Map<Text, bool>& acc_pe, const crate::emit::cpp::items::ValueDecl& v_pf) { return insert(acc_pe, v_pf->path_, false); }), Array<Text>{}), [=](Array<Text> order_values_16279) {
        return ({
            auto values_p8 = crate::syntax::lexer::chars::join(order_values_16279, Text::lit("\n\n"));
            (prism_rtl::finished(crate::emit::cpp::templates::cpp_types_header(title_p0_2, includes_p7, values_p8)));
        });
    });
}


/// `Start TypesHeader, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_types_header(Text title_p0, Array<Text> members_p1, Array<Text> declared_p2, Array<Text> complete_p3, crate::emit::cpp::items::Parts p_p4) {
    return prism_rtl::make_rc<TypesHeader>(title_p0, members_p1, declared_p2, complete_p3, p_p4);
}


/// Includes: fn Text, [Text] -> Text
Text includes(const Text& layer_p0, const Array<Text>& ms_p1) {
    return crate::syntax::lexer::chars::join(each(ms_p1, [&](const Text& m_p2) { return prism_rtl::cat("#include <", mod_dir(m_p2), "/", layer_p0 == Text::lit("") ? Text::lit("module") : layer_p0, ".hpp>"); }), Text::lit("\n"));
}


/// Chunks: fn [Text] -> [ [Text] ]
Array<Array<Text>> chunks(const Array<Text>& defs_p0) {
    auto [done_p5, current_p6, size_p7] = fold(defs_p0, std::tuple{Array<Array<Text>>{}, Array<Text>{}, Nat(0u)}, [&](const std::tuple<Array<Array<Text>>, Array<Text>, Nat>& _p0, const Text& d_p4) {
        auto&& acc_p1 = std::get<0>(_p0);
        auto&& cur_p2 = std::get<1>(_p0);
        auto&& n_p3 = std::get<2>(_p0);
        return (n_p3 > chunk_size()) && (len(cur_p2) > Nat(0u))
            ? std::tuple{crate::prelude::push(acc_p1, cur_p2), Array(std::vector{d_p4}), len_text(d_p4)}
            : std::tuple{acc_p1, crate::prelude::push(cur_p2, d_p4), n_p3 + len_text(d_p4)};
    });
    return (len(current_p6) == Nat(0u)) && (len(done_p5) > Nat(0u))
        ? done_p5
        : crate::prelude::push(done_p5, current_p6);
}


/// let chunkSize
Nat chunk_size() {
    return Nat(250000u);
}


/// ModuleFiles: unbounded fn ModDef, Parts -> (([((Text, Text))], [Piece]))
std::tuple<Array<std::tuple<Text, Text>>, Array<Piece>> module_files(const crate::lower::model::ModDef& m_p0, const crate::emit::cpp::items::Parts& p_p1) {
    auto title_p2 = m_p0.prism == Text::lit("")
        ? Text::lit("The root module")
        : prism_rtl::cat("The module `", m_p0.prism, "`");
    auto needed_p3 = append(m_p0.complete, m_p0.declared);
    auto decl_p4 = crate::emit::cpp::templates::cpp_decl_header(title_p2, Text::lit(""), crate::syntax::lexer::chars::join(p_p1.forward, Text::lit("\n\n")));
    auto types_p5 = len(m_p0.types_with) > Nat(1u)
        ? crate::emit::cpp::templates::cpp_types_in_group(title_p2, group_name(m_p0.types_with))
        : types_header(title_p2, Array(std::vector{m_p0.name}), m_p0.declared, m_p0.complete, p_p1);
    auto head_includes_p6 = crate::syntax::lexer::chars::join(filter(Array(std::vector{prism_rtl::cat(includes(Text::lit("types"), Array(std::vector{m_p0.name})), "\n#include \"elem.types.hpp\""), includes(Text::lit("types"), needed_p3)}), [&](const Text& t_pd) { return t_pd != Text::lit(""); }), Text::lit("\n"));
    auto head_p7 = crate::emit::cpp::templates::cpp_mod_header(title_p2, head_includes_p6, crate::syntax::lexer::chars::join(p_p1.protos, Text::lit("\n")), crate::syntax::lexer::chars::join(p_p1.outer, Text::lit("\n\n")), crate::syntax::lexer::chars::join(p_p1.classes, Text::lit("\n\n")));
    auto with_mine_p8 = append(Array(std::vector{m_p0.name}), needed_p3);
    auto generic_p9 = len(p_p1.generic) == Nat(0u)
        ? Array<std::tuple<Text, Text>>{}
        : Array(std::vector{std::tuple{prism_rtl::cat("src/", mod_dir(m_p0.name), "/generic.hpp"), crate::emit::cpp::templates::cpp_generic_header(title_p2, includes(Text::lit(""), with_mine_p8), crate::syntax::lexer::chars::join(p_p1.generic, Text::lit("\n\n")))}});
    auto chunks_pa = len(p_p1.defs) == Nat(0u) ? Array<Array<Text>>{} : chunks(p_p1.defs);
    auto pieces_pb = each(chunks_pa, [&](const Array<Text>& c_pe) { return Piece{.title = title_p2, .prism = m_p0.prism, .path_ = m_p0.path_, .ns = m_p0.name, .needs = with_mine_p8, .defs = crate::syntax::lexer::chars::join(c_pe, Text::lit("\n\n"))}; });
    auto dir_pc = mod_dir(m_p0.name);
    return std::tuple{append(Array(std::vector{std::tuple{prism_rtl::cat("src/", dir_pc, "/decl.hpp"), decl_p4}, std::tuple{prism_rtl::cat("src/", dir_pc, "/types.hpp"), types_p5}, std::tuple{prism_rtl::cat("src/", dir_pc, "/module.hpp"), head_p7}}), generic_p9), pieces_pb};
}


prism_rtl::Turn<std::tuple<Array<std::tuple<Text, Text>>, Array<Piece>>> ModuleFiles::cycle() const {
    const auto& m_p0 = this->m_p0;
    const auto& p_p1 = this->p_p1;
    auto title_p2 = prism_rtl::deref(m_p0).prism == Text::lit("")
        ? Text::lit("The root module")
        : prism_rtl::cat("The module `", prism_rtl::deref(m_p0).prism, "`");
    auto needed_p3 = append(prism_rtl::deref(m_p0).complete, prism_rtl::deref(m_p0).declared);
    auto decl_p4 = crate::emit::cpp::templates::cpp_decl_header(title_p2, Text::lit(""), crate::syntax::lexer::chars::join(prism_rtl::deref(p_p1).forward, Text::lit("\n\n")));
    auto types_p5 = len(prism_rtl::deref(m_p0).types_with) > Nat(1u)
        ? crate::emit::cpp::templates::cpp_types_in_group(title_p2, group_name(prism_rtl::deref(m_p0).types_with))
        : types_header(title_p2, Array(std::vector{prism_rtl::deref(m_p0).name}), prism_rtl::deref(m_p0).declared, prism_rtl::deref(m_p0).complete, p_p1);
    auto head_includes_p6 = crate::syntax::lexer::chars::join(filter(Array(std::vector{prism_rtl::cat(includes(Text::lit("types"), Array(std::vector{prism_rtl::deref(m_p0).name})), "\n#include \"elem.types.hpp\""), includes(Text::lit("types"), needed_p3)}), [&](const Text& t_pd) { return t_pd != Text::lit(""); }), Text::lit("\n"));
    auto head_p7 = crate::emit::cpp::templates::cpp_mod_header(title_p2, head_includes_p6, crate::syntax::lexer::chars::join(prism_rtl::deref(p_p1).protos, Text::lit("\n")), crate::syntax::lexer::chars::join(prism_rtl::deref(p_p1).outer, Text::lit("\n\n")), crate::syntax::lexer::chars::join(prism_rtl::deref(p_p1).classes, Text::lit("\n\n")));
    auto with_mine_p8 = append(Array(std::vector{prism_rtl::deref(m_p0).name}), needed_p3);
    auto generic_p9 = len(prism_rtl::deref(p_p1).generic) == Nat(0u)
        ? Array<std::tuple<Text, Text>>{}
        : Array(std::vector{std::tuple{prism_rtl::cat("src/", mod_dir(prism_rtl::deref(m_p0).name), "/generic.hpp"), crate::emit::cpp::templates::cpp_generic_header(title_p2, includes(Text::lit(""), with_mine_p8), crate::syntax::lexer::chars::join(prism_rtl::deref(p_p1).generic, Text::lit("\n\n")))}});
    auto chunks_pa = len(prism_rtl::deref(p_p1).defs) == Nat(0u)
        ? Array<Array<Text>>{}
        : chunks(prism_rtl::deref(p_p1).defs);
    auto pieces_pb = each(chunks_pa, [&](const Array<Text>& c_pe) { return Piece{.title = title_p2, .prism = prism_rtl::deref(m_p0).prism, .path_ = m_p0->path_, .ns = prism_rtl::deref(m_p0).name, .needs = with_mine_p8, .defs = crate::syntax::lexer::chars::join(c_pe, Text::lit("\n\n"))}; });
    auto dir_pc = mod_dir(prism_rtl::deref(m_p0).name);
    return prism_rtl::finished(std::tuple{append(Array(std::vector{std::tuple{prism_rtl::cat("src/", dir_pc, "/decl.hpp"), decl_p4}, std::tuple{prism_rtl::cat("src/", dir_pc, "/types.hpp"), types_p5}, std::tuple{prism_rtl::cat("src/", dir_pc, "/module.hpp"), head_p7}}), generic_p9), pieces_pb});
}


/// `Start ModuleFiles, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, Text>>, Array<Piece>>> start_module_files(crate::lower::model::ModDef m_p0, crate::emit::cpp::items::Parts p_p1) {
    return prism_rtl::make_rc<ModuleFiles>(m_p0, p_p1);
}


/// Units: fn [Piece] -> [ [Piece] ]
Array<Array<Piece>> units(const Array<Piece>& pieces_p0) {
    auto [done_p5, current_p6, size_p7] = fold(pieces_p0, std::tuple{Array<Array<Piece>>{}, Array<Piece>{}, Nat(0u)}, [&](const std::tuple<Array<Array<Piece>>, Array<Piece>, Nat>& _p0, const Piece& pc_p4) {
        auto&& acc_p1 = std::get<0>(_p0);
        auto&& cur_p2 = std::get<1>(_p0);
        auto&& n_p3 = std::get<2>(_p0);
        return (len(cur_p2) > Nat(0u)) && ((n_p3 + len_text(prism_rtl::deref(pc_p4).defs)) > unit_size())
            ? std::tuple{crate::prelude::push(acc_p1, cur_p2), Array(std::vector{pc_p4}), len_text(prism_rtl::deref(pc_p4).defs)}
            : std::tuple{acc_p1, crate::prelude::push(cur_p2, pc_p4), n_p3 + len_text(prism_rtl::deref(pc_p4).defs)};
    });
    return len(current_p6) == Nat(0u)
        ? done_p5
        : crate::prelude::push(done_p5, current_p6);
}


/// let unitSize
Nat unit_size() {
    return Nat(125000u);
}


/// UnitFile: fn Nat, [Piece], [Text] -> ((Text, Text))
std::tuple<Text, Text> unit_file(const Nat& k_p0, const Array<Piece>& pieces_p1, const Array<Text>& generics_p2) {
    auto needs_p3 = fold(pieces_p1, Array<Text>{}, [&](const Array<Text>& acc_p8, const Piece& pc_p9) { return fold(prism_rtl::deref(pc_p9).needs, acc_p8, [&](const Array<Text>& a_pa, const Text& n_pb) { return among(a_pa, n_pb) ? a_pa : crate::prelude::push(a_pa, n_pb); }); });
    auto includes_p4 = crate::syntax::lexer::chars::join(filter(Array(std::vector{includes(Text::lit(""), needs_p3), includes(Text::lit("generic"), filter(needs_p3, [&](const Text& n_pc) { return among(generics_p2, n_pc); }))}), [&](const Text& t_pd) { return t_pd != Text::lit(""); }), Text::lit("\n"));
    auto names_p5 = fold(pieces_p1, Array<Text>{}, [&](const Array<Text>& acc_pe, const Piece& pc_pf) {
        return among(acc_pe, prism_rtl::deref(pc_pf).prism)
            ? acc_pe
            : crate::prelude::push(acc_pe, prism_rtl::deref(pc_pf).prism);
    });
    auto title_p6 = len(names_p5) == Nat(1u)
        ? prism_rtl::deref(or_(index(pieces_p1, Nat(0u)), dummy_piece())).title
        : prism_rtl::cat("The modules ", crate::syntax::lexer::chars::join(each(names_p5, [&](const Text& n_pg) {
        return n_pg == Text::lit("")
            ? Text::lit("the root")
            : prism_rtl::cat("`", n_pg, "`");
    }), Text::lit(", ")));
    auto parts_p7 = crate::syntax::lexer::chars::join(each(pieces_p1, [&](const Piece& pc_ph) { return crate::emit::cpp::templates::cpp_unit_part(prism_rtl::deref(pc_ph).title, pc_ph->path_, prism_rtl::deref(pc_ph).ns, prism_rtl::deref(pc_ph).defs); }), Text::lit("\n\n"));
    return std::tuple{prism_rtl::cat("src/unit_", k_p0 + Nat(1u), ".cpp"), crate::emit::cpp::templates::cpp_unit(title_p6, includes_p4, parts_p7)};
}


/// let dummyPiece
Piece dummy_piece() {
    return Piece{.title = Text::lit(""), .prism = Text::lit(""), .path_ = Text::lit(""), .ns = Text::lit(""), .needs = Array<Text>{}, .defs = Text::lit("")};
}


/// AllProgramsCpp: fn Model -> [ProgDef]
Array<crate::lower::model::ProgDef> all_programs_cpp(const crate::lower::model::Model& model_p0) {
    auto&& _m = model_p0.root;
    if (prism_rtl::is_some(_m)) {
        auto&& r_p1 = prism_rtl::some_of(_m);
        return fold(model_p0.programs, false, [&](const bool& f_p2, const crate::lower::model::ProgDef& p_p3) { return prism_rtl::deref(f_p2) || (prism_rtl::deref(p_p3).name == prism_rtl::deref(r_p1).name); })
            ? model_p0.programs
            : crate::prelude::push(model_p0.programs, r_p1);
    }
    if (prism_rtl::is_none(_m)) {
        return model_p0.programs;
    }
    prism_rtl::unreachable("no arm matched");
}


/// OrderValues: unbounded fn [ValueDecl], (Text ==> Bool), [Text] -> [Text]
Array<Text> order_values(const Array<crate::emit::cpp::items::ValueDecl>& left_p0, const Map<Text, bool>& done_p1, const Array<Text>& acc_p2) {
    auto ready_p3 = filter(left_p0, [&](const crate::emit::cpp::items::ValueDecl& v_p4) { return fold(prism_rtl::deref(v_p4).deps, true, [&](const bool& ok_p5, const Text& d_p6) { return prism_rtl::deref(ok_p5) && ((d_p6 == v_p4->path_) || declared(done_p1, d_p6)); }); });
    return len(left_p0) == Nat(0u)
        ? acc_p2
        : len(ready_p3) == Nat(0u)
        ? append(acc_p2, each(left_p0, [&](const crate::emit::cpp::items::ValueDecl& v_p7) { return v_p7->text; }))
        : ({
        auto later_p8 = filter(left_p0, [&](const crate::emit::cpp::items::ValueDecl& v_pa) { return !fold(prism_rtl::deref(v_pa).deps, true, [&](const bool& ok_pb, const Text& d_pc) { return prism_rtl::deref(ok_pb) && ((d_pc == v_pa->path_) || declared(done_p1, d_pc)); }); });
        auto done2_p9 = fold(ready_p3, done_p1, [&](const Map<Text, bool>& m_pd, const crate::emit::cpp::items::ValueDecl& v_pe) { return insert(m_pd, v_pe->path_, true); });
        order_values(later_p8, done2_p9, append(acc_p2, each(ready_p3, [&](const crate::emit::cpp::items::ValueDecl& v_pf) { return v_pf->text; })));
    });
}


prism_rtl::Turn<Array<Text>> OrderValues::cycle() const {
    const auto& left_p0 = this->left_p0;
    const auto& done_p1 = this->done_p1;
    const auto& acc_p2 = this->acc_p2;
    auto ready_p3 = filter(left_p0, [&](const crate::emit::cpp::items::ValueDecl& v_p4) { return fold(prism_rtl::deref(v_p4).deps, true, [&](const bool& ok_p5, const Text& d_p6) { return prism_rtl::deref(ok_p5) && ((d_p6 == v_p4->path_) || declared(done_p1, d_p6)); }); });
    return len(left_p0) == Nat(0u)
        ? prism_rtl::finished(acc_p2)
        : len(ready_p3) == Nat(0u)
        ? prism_rtl::finished(append(acc_p2, each(left_p0, [&](const crate::emit::cpp::items::ValueDecl& v_p7) { return v_p7->text; })))
        : ({
        auto later_p8 = filter(left_p0, [&](const crate::emit::cpp::items::ValueDecl& v_pa) { return !fold(prism_rtl::deref(v_pa).deps, true, [&](const bool& ok_pb, const Text& d_pc) { return prism_rtl::deref(ok_pb) && ((d_pc == v_pa->path_) || declared(done_p1, d_pc)); }); });
        auto done2_p9 = fold(ready_p3, done_p1, [&](const Map<Text, bool>& m_pd, const crate::emit::cpp::items::ValueDecl& v_pe) { return insert(m_pd, v_pe->path_, true); });
        (prism_rtl::more(prism_rtl::rc(OrderValues(later_p8, done2_p9, append(acc_p2, each(ready_p3, [&](const crate::emit::cpp::items::ValueDecl& v_pf) { return v_pf->text; }))))));
    });
}


/// `Start OrderValues, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_order_values(Array<crate::emit::cpp::items::ValueDecl> left_p0, Map<Text, bool> done_p1, Array<Text> acc_p2) {
    return prism_rtl::make_rc<OrderValues>(left_p0, done_p1, acc_p2);
}


/// Declared: fn (Text ==> Bool), Text -> Bool
bool declared(const Map<Text, bool>& done_p0, const Text& d_p1) {
    auto&& _m = crate::prelude::get(done_p0, d_p1);
    if (prism_rtl::is_some(_m)) {
        auto&& b_p2 = prism_rtl::some_of(_m);
        return b_p2;
    }
    if (prism_rtl::is_none(_m)) {
        return true;
    }
    prism_rtl::unreachable("no arm matched");
}

}  // namespace crate::emit::cpp::program
