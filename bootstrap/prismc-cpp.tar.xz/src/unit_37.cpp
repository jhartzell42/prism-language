// The module `Emit.Cpp.Program`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <emit/cpp/program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>

// The module `Emit.Cpp.Program`, from `target/bootstrap/cpp-src/prismc/emit/cpp/program.prism`.
namespace crate::emit::cpp::program {

void Piece::show(Printer& p) const {
    p.record("Piece", {{"title", title_p}, {"prism", prism_p}, {"path", path_p}, {"ns", ns_p}, {"needs", needs_p}, {"defs", defs_p}});
}

Pod Piece::to_pod() const {
    return Pod::record("Piece", {{"title", prism_rtl::to_pod(title_p)}, {"prism", prism_rtl::to_pod(prism_p)}, {"path", prism_rtl::to_pod(path_p)}, {"ns", prism_rtl::to_pod(ns_p)}, {"needs", prism_rtl::to_pod(needs_p)}, {"defs", prism_rtl::to_pod(defs_p)}});
}

Result<Piece> Piece::from_pod(const Pod& whole) {
    return Piece{.title_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "title")))), .prism_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "prism")))), .path_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "path")))), .ns_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "ns")))), .needs_p = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "needs")))), .defs_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "defs"))))};
}


/// NodeParts: unbounded fn Cp, NodeDef -> Parts
crate::emit::cpp::items::Parts node_parts_f(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::NodeDef& n_p1) {
    auto ncp_p2 = crate::emit::cpp::with_fields_f(cp_p0, crate::prelude::each(n_p1.fields_p, [&](const std::tuple<Text, crate::lower::model::OutTy, Text>& _p0) {
        auto&& f_pu = std::get<0>(_p0);
        auto&& t_pv = std::get<1>(_p0);
        return std::tuple{f_pu, t_pv};
    }));
    auto base_p3 = (n_p1.row_kind_p == crate::lower::model::RowKind(crate::lower::model::RowKind::NotARow{})) && (crate::prelude::len(n_p1.hosted_p) == Nat(0u))
        ? Text::lit("Node")
        : Text::lit("Row");
    auto fields_p4 = crate::syntax::lexer::chars::join_f(crate::prelude::run_to_end(crate::prelude::each_job(n_p1.fields_p, ({
        auto cp_p0x = cp_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy, Text>)>>(prism_rtl::rc([=, cp_p0x = std::move(cp_p0x)](std::tuple<Text, crate::lower::model::OutTy, Text> p0) {
        return ({
            auto cp_p0xy = cp_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xy = std::move(cp_p0xy)]() {
            return ({
                auto [f_p10, t_p11, doc_p12] = p0;
                (crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xy, t_p11), [=](Text cpp_type_f_1357) { return prism_rtl::finished(prism_rtl::cat(crate::emit::cpp::items::cpp_doc_f(doc_p12), cpp_type_f_1357, " ", crate::emit::cpp::field_id_f(f_p10), ";")); }));
            });
        })));
        });
    })));
    }))), Text::lit("\n"));
    auto consts_p5 = crate::syntax::lexer::chars::join_f(crate::prelude::each(n_p1.consts_p, [&](const std::tuple<Text, Nat, Text>& _p0) {
        auto&& c_p13 = std::get<0>(_p0);
        auto&& h_p14 = std::get<1>(_p0);
        auto&& doc_p15 = std::get<2>(_p0);
        return prism_rtl::cat(crate::emit::cpp::items::cpp_doc_f(prism_rtl::cat("The ", doc_p15, ".")), "static constexpr std::uint32_t ", c_p13, " = ", h_p14, ";");
    }), Text::lit("\n"));
    auto ctor_params_p6 = crate::syntax::lexer::chars::join_f(crate::prelude::append(Array(std::vector{Text::lit("Path path")}), crate::prelude::run_to_end(crate::prelude::each_job(n_p1.fields_p, ({
        auto cp_p0x = cp_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy, Text>)>>(prism_rtl::rc([=, cp_p0x = std::move(cp_p0x)](std::tuple<Text, crate::lower::model::OutTy, Text> p0) {
        return ({
            auto cp_p0xy = cp_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xy = std::move(cp_p0xy)]() {
            return ({
                auto&& _f_p16 = p0;
                auto&& f_p16 = std::get<0>(_f_p16);
                auto&& t_p17 = std::get<1>(_f_p16);
                (crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xy, t_p17), [=](Text cpp_type_f_1609) { return prism_rtl::finished(prism_rtl::cat(cpp_type_f_1609, " ", crate::emit::cpp::field_id_f(f_p16))); }));
            });
        })));
        });
    })));
    })))), Text::lit(", "));
    auto ctor_inits_p7 = crate::syntax::lexer::chars::join_f(crate::prelude::append(Array(std::vector{Text::lit("path(std::move(path))")}), crate::prelude::each(n_p1.fields_p, [&](const std::tuple<Text, crate::lower::model::OutTy, Text>& _p0) {
        auto&& f_p18 = std::get<0>(_p0);
        return prism_rtl::cat(crate::emit::cpp::field_id_f(f_p18), "(std::move(", crate::emit::cpp::field_id_f(f_p18), "))");
    })), Text::lit(", "));
    auto params_p8 = crate::prelude::concat(crate::prelude::run_to_end(crate::prelude::each_job(n_p1.params_p, ({
        auto cp_p0x = cp_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=, cp_p0x = std::move(cp_p0x)](std::tuple<Text, crate::lower::model::OutTy> p0) {
        return ({
            auto cp_p0xy = cp_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xy = std::move(cp_p0xy)]() {
            return ({
                auto [p_p19, t_p1a] = p0;
                (crate::prelude::call_then(crate::emit::cpp::expr::start_param_type_f(cp_p0xy, t_p1a), [=](Text param_type_f_1848) { return prism_rtl::finished(prism_rtl::cat(param_type_f_1848, " ", p_p19, ", ")); }));
            });
        })));
        });
    })));
    }))));
    auto ret_p9 = n_p1.fallible_p
        ? prism_rtl::cat("Result<prism_rtl::Rc<", n_p1.name_p, ">>")
        : prism_rtl::cat("prism_rtl::Rc<", n_p1.name_p, ">");
    auto make_decl_pa = prism_rtl::cat("static ", ret_p9, " make(Path path, ", params_p8, "Cx& cx);");
    auto method_decls_pb = crate::prelude::run_to_end(crate::prelude::each_job(crate::prelude::append(n_p1.methods_p, n_p1.hosted_p), ({
        auto ncp_p2x = ncp_p2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::MethDef)>>(prism_rtl::rc([=, ncp_p2x = std::move(ncp_p2x)](crate::lower::model::MethDef p0) {
        return ({
            auto ncp_p2xy = ncp_p2x;
            (crate::prelude::entered(crate::prelude::once_job([=, ncp_p2xy = std::move(ncp_p2xy)]() {
            return ({
                auto m_p1b = p0;
                (crate::prelude::call_then(start_method_sig_f(ncp_p2xy, m_p1b, Text::lit("")), [=](Text method_sig_f_2099) { return prism_rtl::finished(prism_rtl::cat(method_sig_f_2099, ";")); }));
            });
        })));
        });
    })));
    })));
    auto builder_decls_pc = crate::prelude::append(crate::prelude::each(n_p1.builders_p, [&](const crate::lower::model::ForDef& b_p1c) { return prism_rtl::cat("Done ", prism_rtl::deref(b_p1c).name_p, "_build(Cx& cx);"); }), crate::prelude::each(n_p1.gens_p, [&](const crate::lower::model::GenDef& g_p1d) { return prism_rtl::cat("Done ", prism_rtl::deref(g_p1d).name_p, "_build(Cx& cx);"); }));
    auto hook_decls_pd = crate::prelude::each(n_p1.hooks_p, [&](const std::tuple<Text, Array<crate::lower::model::Do>>& _p0) {
        auto&& h_p1e = std::get<0>(_p0);
        return prism_rtl::cat(hook_sig_f(h_p1e, Text::lit("")), " override;");
    });
    auto answer_decl_pe = crate::prelude::len(n_p1.answers_p) == Nat(0u)
        ? Array<Text>{}
        : Array(std::vector{Text::lit("Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;")});
    auto row_decl_pf = n_p1.row_kind_p == crate::lower::model::RowKind(crate::lower::model::RowKind::NotARow{})
        ? Array<Text>{}
        : Array(std::vector{Text::lit("void leave_row(Cx& cx) override;")});
    auto decls_pg = crate::syntax::lexer::chars::join_f(crate::prelude::append(crate::prelude::append(crate::prelude::append(crate::prelude::append(crate::prelude::append(Array(std::vector{make_decl_pa}), method_decls_pb), builder_decls_pc), hook_decls_pd), answer_decl_pe), row_decl_pf), Text::lit("\n"));
    auto doc_ph = crate::emit::cpp::items::cpp_source_doc_f(prism_rtl::cat("`", n_p1.prism_p, "`: a node of its own (claude/backend.md, \"A widget block\")."), n_p1.doc_p);
    auto decl_pi = crate::emit::cpp::templates::items::node_class_f(doc_ph, n_p1.name_p, base_p3, fields_p4, consts_p5, prism_rtl::cat(n_p1.name_p, "(", ctor_params_p6, ") : ", ctor_inits_p7, " {}"), decls_pg);
    auto by_field_pj = crate::prelude::each(n_p1.fields_p, [&](const std::tuple<Text, crate::lower::model::OutTy, Text>& _p0) {
        auto&& f_p1f = std::get<0>(_p0);
        return crate::prelude::or_(crate::prelude::fold(n_p1.inits_p, std::optional<crate::lower::model::Ex>{}, [&](const std::optional<crate::lower::model::Ex>& found_o1g, const std::tuple<Text, crate::lower::model::Ex>& _p1) {
            auto&& g_p1h = std::get<0>(_p1);
            auto&& v_p1i = std::get<1>(_p1);
            return g_p1h == f_p1f ? std::optional(v_p1i) : found_o1g;
        }), crate::lower::model::Ex(crate::lower::model::Ex::XVar{f_p1f}));
    });
    auto [lets_text_p1j, lcp_p1k] = crate::emit::cpp::stmts::cpp_statements_cp_f(ncp_p2, n_p1.lets_p);
    auto args_pk = crate::syntax::lexer::chars::join_f(crate::prelude::append(Array(std::vector{Text::lit("path")}), crate::prelude::run_to_end(crate::prelude::each_job(by_field_pj, ({
        auto lcp_p1kx = lcp_p1k;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Ex)>>(prism_rtl::rc([=, lcp_p1kx = std::move(lcp_p1kx)](crate::lower::model::Ex p0) {
        return ({
            auto lcp_p1kxy = lcp_p1kx;
            (crate::prelude::entered(crate::prelude::once_job([=, lcp_p1kxy = std::move(lcp_p1kxy)]() {
            return ({
                auto v_p1l = p0;
                (prism_rtl::more(prism_rtl::rc(crate::emit::cpp::expr::CppExpr(lcp_p1kxy, v_p1l))));
            });
        })));
        });
    })));
    })))), Text::lit(", "));
    auto tail_pl = n_p1.fallible_p ? Text::lit("return node;") : Text::lit("return node;");
    auto make_pm = crate::emit::cpp::templates::items::node_make_f(n_p1.name_p, prism_rtl::cat(ret_p9, " ", n_p1.name_p, "::make(Path path, ", params_p8, "Cx& cx)"), lets_text_p1j, args_pk, crate::syntax::lexer::chars::join_f(crate::prelude::filter(Array(std::vector{crate::emit::cpp::stmts::cpp_statements_f(crate::emit::cpp::stmts::pointing_f(lcp_p1k, Text::lit("node")), n_p1.build_p), tail_pl}), [&](const Text& s_p1m) { return s_p1m != Text::lit(""); }), Text::lit("\n")));
    auto methods_pn = crate::prelude::run_to_end(crate::prelude::each_job(crate::prelude::append(n_p1.methods_p, n_p1.hosted_p), ({
        auto ncp_p2x = ncp_p2;
        auto n_p1x = n_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::MethDef)>>(prism_rtl::rc([=, ncp_p2x = std::move(ncp_p2x), n_p1x = std::move(n_p1x)](crate::lower::model::MethDef p0) {
        return ({
            auto ncp_p2xy = ncp_p2x;
            auto n_p1xy = n_p1x;
            (crate::prelude::entered(crate::prelude::once_job([=, ncp_p2xy = std::move(ncp_p2xy), n_p1xy = std::move(n_p1xy)]() {
            return ({
                auto m_p1n = p0;
                (prism_rtl::more(prism_rtl::rc(MethodDef(ncp_p2xy, prism_rtl::deref(n_p1xy).name_p, m_p1n))));
            });
        })));
        });
    })));
    })));
    auto builders_po = crate::prelude::append(crate::prelude::run_to_end(crate::prelude::each_job(n_p1.builders_p, ({
        auto ncp_p2x = ncp_p2;
        auto n_p1x = n_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::ForDef)>>(prism_rtl::rc([=, ncp_p2x = std::move(ncp_p2x), n_p1x = std::move(n_p1x)](crate::lower::model::ForDef p0) {
        return ({
            auto ncp_p2xy = ncp_p2x;
            auto n_p1xy = n_p1x;
            (crate::prelude::entered(crate::prelude::once_job([=, ncp_p2xy = std::move(ncp_p2xy), n_p1xy = std::move(n_p1xy)]() {
            return ({
                auto b_p1o = p0;
                (prism_rtl::more(prism_rtl::rc(ForBuildCpp(ncp_p2xy, prism_rtl::deref(n_p1xy).name_p, b_p1o))));
            });
        })));
        });
    })));
    }))), crate::prelude::run_to_end(crate::prelude::each_job(n_p1.gens_p, ({
        auto ncp_p2x = ncp_p2;
        auto n_p1x = n_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::GenDef)>>(prism_rtl::rc([=, ncp_p2x = std::move(ncp_p2x), n_p1x = std::move(n_p1x)](crate::lower::model::GenDef p0) {
        return ({
            auto ncp_p2xy = ncp_p2x;
            auto n_p1xy = n_p1x;
            (crate::prelude::entered(crate::prelude::once_job([=, ncp_p2xy = std::move(ncp_p2xy), n_p1xy = std::move(n_p1xy)]() {
            return ({
                auto g_p1p = p0;
                (prism_rtl::more(prism_rtl::rc(GenBuildCpp(ncp_p2xy, prism_rtl::deref(n_p1xy).name_p, g_p1p))));
            });
        })));
        });
    })));
    }))));
    auto hooks_pp = crate::prelude::run_to_end(crate::prelude::each_job(n_p1.hooks_p, ({
        auto n_p1x = n_p1;
        auto ncp_p2x = ncp_p2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Array<crate::lower::model::Do>>)>>(prism_rtl::rc([=, n_p1x = std::move(n_p1x), ncp_p2x = std::move(ncp_p2x)](std::tuple<Text, Array<crate::lower::model::Do>> p0) {
        return ({
            auto n_p1xy = n_p1x;
            auto ncp_p2xy = ncp_p2x;
            (crate::prelude::entered(crate::prelude::once_job([=, n_p1xy = std::move(n_p1xy), ncp_p2xy = std::move(ncp_p2xy)]() {
            return ({
                auto [h_p1q, body_p1r] = p0;
                (crate::prelude::call_then(crate::emit::cpp::stmts::start_cpp_statements_f(ncp_p2xy, body_p1r), [=](Text cpp_statements_f_3838) { return prism_rtl::finished(crate::emit::cpp::templates::items::cpp_function_f(Text::lit(""), hook_sig_f(h_p1q, prism_rtl::cat(prism_rtl::deref(n_p1xy).name_p, "::")), prism_rtl::cat(cpp_statements_f_3838, "\nreturn {};"))); }));
            });
        })));
        });
    })));
    })));
    auto answer_pq = crate::prelude::len(n_p1.answers_p) == Nat(0u)
        ? Array<Text>{}
        : Array(std::vector{answer_def_cpp_f(ncp_p2, n_p1)});
    auto leaving_pr = n_p1.row_kind_p == crate::lower::model::RowKind(crate::lower::model::RowKind::NotARow{})
        ? Array<Text>{}
        : Array(std::vector{row_leaving_f(ncp_p2, n_p1)});
    auto defs_ps = crate::prelude::append(crate::prelude::append(crate::prelude::append(crate::prelude::append(crate::prelude::append(Array(std::vector{make_pm}), methods_pn), builders_po), hooks_pp), answer_pq), leaving_pr);
    auto own_pt = crate::emit::cpp::items::Parts{.forward_p = Array(std::vector{prism_rtl::cat("class ", n_p1.name_p, ";")}), .values_p = Array<crate::emit::cpp::items::ValueDecl>{}, .protos_p = Array<Text>{}, .classes_p = Array(std::vector{decl_pi}), .outer_p = Array<Text>{}, .generic_p = Array<Text>{}, .defs_p = defs_ps};
    return own_pt;
}


prism_rtl::Turn<crate::emit::cpp::items::Parts> NodeParts::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& n_p1 = this->n_p1;
    auto ncp_p2 = crate::emit::cpp::with_fields_f(cp_p0, crate::prelude::each(prism_rtl::deref(n_p1).fields_p, [&](const std::tuple<Text, crate::lower::model::OutTy, Text>& _p0) {
        auto&& f_pu = std::get<0>(_p0);
        auto&& t_pv = std::get<1>(_p0);
        return std::tuple{f_pu, t_pv};
    }));
    auto base_p3 = (prism_rtl::deref(n_p1).row_kind_p == crate::lower::model::RowKind(crate::lower::model::RowKind::NotARow{})) && (crate::prelude::len(prism_rtl::deref(n_p1).hosted_p) == Nat(0u))
        ? Text::lit("Node")
        : Text::lit("Row");
    auto cp_p0x = cp_p0;
    auto n_p1x = n_p1;
    return crate::prelude::call_value(crate::prelude::each_job(prism_rtl::deref(n_p1x).fields_p, ({
        auto cp_p0xx = cp_p0x;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy, Text>)>>(prism_rtl::rc([=, cp_p0xx = std::move(cp_p0xx)](std::tuple<Text, crate::lower::model::OutTy, Text> p0) {
        return ({
            auto cp_p0xxy = cp_p0xx;
            (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xxy = std::move(cp_p0xxy)]() {
            return ({
                auto [f_p10, t_p11, doc_p12] = p0;
                (crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xxy, t_p11), [=](Text cpp_type_f_1357) { return prism_rtl::finished(prism_rtl::cat(crate::emit::cpp::items::cpp_doc_f(doc_p12), cpp_type_f_1357, " ", crate::emit::cpp::field_id_f(f_p10), ";")); }));
            });
        })));
        });
    })));
    })), [=](Array<Text> each_1311) {
        return ({
            auto fields_p4 = crate::syntax::lexer::chars::join_f(each_1311, Text::lit("\n"));
            auto consts_p5 = crate::syntax::lexer::chars::join_f(crate::prelude::each(prism_rtl::deref(n_p1x).consts_p, [&](const std::tuple<Text, Nat, Text>& _p0) {
                auto&& c_p13 = std::get<0>(_p0);
                auto&& h_p14 = std::get<1>(_p0);
                auto&& doc_p15 = std::get<2>(_p0);
                return prism_rtl::cat(crate::emit::cpp::items::cpp_doc_f(prism_rtl::cat("The ", doc_p15, ".")), "static constexpr std::uint32_t ", c_p13, " = ", h_p14, ";");
            }), Text::lit("\n"));
            (crate::prelude::call_value(crate::prelude::each_job(prism_rtl::deref(n_p1x).fields_p, ({
            auto cp_p0xx = cp_p0x;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy, Text>)>>(prism_rtl::rc([=, cp_p0xx = std::move(cp_p0xx)](std::tuple<Text, crate::lower::model::OutTy, Text> p0) {
            return ({
                auto cp_p0xxy = cp_p0xx;
                (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xxy = std::move(cp_p0xxy)]() {
                return ({
                    auto&& _f_p16 = p0;
                    auto&& f_p16 = std::get<0>(_f_p16);
                    auto&& t_p17 = std::get<1>(_f_p16);
                    (crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xxy, t_p17), [=](Text cpp_type_f_1609) { return prism_rtl::finished(prism_rtl::cat(cpp_type_f_1609, " ", crate::emit::cpp::field_id_f(f_p16))); }));
                });
            })));
            });
        })));
        })), [=, fields_p4 = std::move(fields_p4), consts_p5 = std::move(consts_p5)](Array<Text> each_1572) {
            return ({
                auto ctor_params_p6 = crate::syntax::lexer::chars::join_f(crate::prelude::append(Array(std::vector{Text::lit("Path path")}), each_1572), Text::lit(", "));
                auto ctor_inits_p7 = crate::syntax::lexer::chars::join_f(crate::prelude::append(Array(std::vector{Text::lit("path(std::move(path))")}), crate::prelude::each(prism_rtl::deref(n_p1x).fields_p, [&](const std::tuple<Text, crate::lower::model::OutTy, Text>& _p0) {
                    auto&& f_p18 = std::get<0>(_p0);
                    return prism_rtl::cat(crate::emit::cpp::field_id_f(f_p18), "(std::move(", crate::emit::cpp::field_id_f(f_p18), "))");
                })), Text::lit(", "));
                (crate::prelude::call_value(crate::prelude::each_job(prism_rtl::deref(n_p1x).params_p, ({
                auto cp_p0xx = cp_p0x;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=, cp_p0xx = std::move(cp_p0xx)](std::tuple<Text, crate::lower::model::OutTy> p0) {
                return ({
                    auto cp_p0xxy = cp_p0xx;
                    (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xxy = std::move(cp_p0xxy)]() {
                    return ({
                        auto [p_p19, t_p1a] = p0;
                        (crate::prelude::call_then(crate::emit::cpp::expr::start_param_type_f(cp_p0xxy, t_p1a), [=](Text param_type_f_1848) { return prism_rtl::finished(prism_rtl::cat(param_type_f_1848, " ", p_p19, ", ")); }));
                    });
                })));
                });
            })));
            })), [=, ctor_params_p6 = std::move(ctor_params_p6), ctor_inits_p7 = std::move(ctor_inits_p7)](Array<Text> each_1819) {
                return ({
                    auto params_p8 = crate::prelude::concat(each_1819);
                    auto ret_p9 = prism_rtl::deref(n_p1x).fallible_p
                        ? prism_rtl::cat("Result<prism_rtl::Rc<", prism_rtl::deref(n_p1x).name_p, ">>")
                        : prism_rtl::cat("prism_rtl::Rc<", prism_rtl::deref(n_p1x).name_p, ">");
                    auto make_decl_pa = prism_rtl::cat("static ", ret_p9, " make(Path path, ", params_p8, "Cx& cx);");
                    (crate::prelude::call_value(crate::prelude::each_job(crate::prelude::append(prism_rtl::deref(n_p1x).methods_p, prism_rtl::deref(n_p1x).hosted_p), ({
                    auto ncp_p2x = ncp_p2;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::MethDef)>>(prism_rtl::rc([=, ncp_p2x = std::move(ncp_p2x)](crate::lower::model::MethDef p0) {
                    return ({
                        auto ncp_p2xy = ncp_p2x;
                        (crate::prelude::entered(crate::prelude::once_job([=, ncp_p2xy = std::move(ncp_p2xy)]() {
                        return ({
                            auto m_p1b = p0;
                            (crate::prelude::call_then(start_method_sig_f(ncp_p2xy, m_p1b, Text::lit("")), [=](Text method_sig_f_2099) { return prism_rtl::finished(prism_rtl::cat(method_sig_f_2099, ";")); }));
                        });
                    })));
                    });
                })));
                })), [=, params_p8 = std::move(params_p8), ret_p9 = std::move(ret_p9), make_decl_pa = std::move(make_decl_pa)](Array<Text> each_2057) {
                    return ({
                        auto method_decls_pb = each_2057;
                        auto builder_decls_pc = crate::prelude::append(crate::prelude::each(prism_rtl::deref(n_p1x).builders_p, [&](const crate::lower::model::ForDef& b_p1c) { return prism_rtl::cat("Done ", prism_rtl::deref(b_p1c).name_p, "_build(Cx& cx);"); }), crate::prelude::each(prism_rtl::deref(n_p1x).gens_p, [&](const crate::lower::model::GenDef& g_p1d) { return prism_rtl::cat("Done ", prism_rtl::deref(g_p1d).name_p, "_build(Cx& cx);"); }));
                        auto hook_decls_pd = crate::prelude::each(prism_rtl::deref(n_p1x).hooks_p, [&](const std::tuple<Text, Array<crate::lower::model::Do>>& _p0) {
                            auto&& h_p1e = std::get<0>(_p0);
                            return prism_rtl::cat(hook_sig_f(h_p1e, Text::lit("")), " override;");
                        });
                        auto answer_decl_pe = crate::prelude::len(prism_rtl::deref(n_p1x).answers_p) == Nat(0u)
                            ? Array<Text>{}
                            : Array(std::vector{Text::lit("Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;")});
                        auto row_decl_pf = prism_rtl::deref(n_p1x).row_kind_p == crate::lower::model::RowKind(crate::lower::model::RowKind::NotARow{})
                            ? Array<Text>{}
                            : Array(std::vector{Text::lit("void leave_row(Cx& cx) override;")});
                        auto decls_pg = crate::syntax::lexer::chars::join_f(crate::prelude::append(crate::prelude::append(crate::prelude::append(crate::prelude::append(crate::prelude::append(Array(std::vector{make_decl_pa}), method_decls_pb), builder_decls_pc), hook_decls_pd), answer_decl_pe), row_decl_pf), Text::lit("\n"));
                        auto doc_ph = crate::emit::cpp::items::cpp_source_doc_f(prism_rtl::cat("`", prism_rtl::deref(n_p1x).prism_p, "`: a node of its own (claude/backend.md, \"A widget block\")."), prism_rtl::deref(n_p1x).doc_p);
                        auto decl_pi = crate::emit::cpp::templates::items::node_class_f(doc_ph, prism_rtl::deref(n_p1x).name_p, base_p3, fields_p4, consts_p5, prism_rtl::cat(prism_rtl::deref(n_p1x).name_p, "(", ctor_params_p6, ") : ", ctor_inits_p7, " {}"), decls_pg);
                        auto by_field_pj = crate::prelude::each(prism_rtl::deref(n_p1x).fields_p, [&](const std::tuple<Text, crate::lower::model::OutTy, Text>& _p0) {
                            auto&& f_p1f = std::get<0>(_p0);
                            return crate::prelude::or_(crate::prelude::fold(prism_rtl::deref(n_p1x).inits_p, std::optional<crate::lower::model::Ex>{}, [&](const std::optional<crate::lower::model::Ex>& found_o1g, const std::tuple<Text, crate::lower::model::Ex>& _p1) {
                                auto&& g_p1h = std::get<0>(_p1);
                                auto&& v_p1i = std::get<1>(_p1);
                                return g_p1h == f_p1f ? std::optional(v_p1i) : found_o1g;
                            }), crate::lower::model::Ex(crate::lower::model::Ex::XVar{f_p1f}));
                        });
                        (crate::prelude::call_then(crate::emit::cpp::stmts::start_cpp_statements_cp_f(ncp_p2, prism_rtl::deref(n_p1x).lets_p), [=, decl_pi = std::move(decl_pi), by_field_pj = std::move(by_field_pj)](std::tuple<Text, crate::emit::cpp::Cp> cpp_statements_cp_f_3170) {
                        return ({
                            auto [lets_text_p1j, lcp_p1k] = cpp_statements_cp_f_3170;
                            (crate::prelude::call_value(crate::prelude::each_job(by_field_pj, ({
                            auto lcp_p1kx = lcp_p1k;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Ex)>>(prism_rtl::rc([=, lcp_p1kx = std::move(lcp_p1kx)](crate::lower::model::Ex p0) {
                            return ({
                                auto lcp_p1kxy = lcp_p1kx;
                                (crate::prelude::entered(crate::prelude::once_job([=, lcp_p1kxy = std::move(lcp_p1kxy)]() {
                                return ({
                                    auto v_p1l = p0;
                                    (prism_rtl::more(prism_rtl::rc(crate::emit::cpp::expr::CppExpr(lcp_p1kxy, v_p1l))));
                                });
                            })));
                            });
                        })));
                        })), [=](Array<Text> each_3239) {
                            return ({
                                auto args_pk = crate::syntax::lexer::chars::join_f(crate::prelude::append(Array(std::vector{Text::lit("path")}), each_3239), Text::lit(", "));
                                auto tail_pl = prism_rtl::deref(n_p1x).fallible_p
                                    ? Text::lit("return node;")
                                    : Text::lit("return node;");
                                (crate::prelude::call_then(crate::emit::cpp::stmts::start_cpp_statements_f(crate::emit::cpp::stmts::pointing_f(lcp_p1k, Text::lit("node")), prism_rtl::deref(n_p1x).build_p), [=, args_pk = std::move(args_pk), tail_pl = std::move(tail_pl)](Text cpp_statements_f_3463) {
                                return ({
                                    auto make_pm = crate::emit::cpp::templates::items::node_make_f(prism_rtl::deref(n_p1x).name_p, prism_rtl::cat(ret_p9, " ", prism_rtl::deref(n_p1x).name_p, "::make(Path path, ", params_p8, "Cx& cx)"), lets_text_p1j, args_pk, crate::syntax::lexer::chars::join_f(crate::prelude::filter(Array(std::vector{cpp_statements_f_3463, tail_pl}), [&](const Text& s_p1m) { return s_p1m != Text::lit(""); }), Text::lit("\n")));
                                    (crate::prelude::call_value(crate::prelude::each_job(crate::prelude::append(prism_rtl::deref(n_p1x).methods_p, prism_rtl::deref(n_p1x).hosted_p), ({
                                    auto ncp_p2x = ncp_p2;
                                    auto n_p1xx = n_p1x;
                                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::MethDef)>>(prism_rtl::rc([=, ncp_p2x = std::move(ncp_p2x), n_p1xx = std::move(n_p1xx)](crate::lower::model::MethDef p0) {
                                    return ({
                                        auto ncp_p2xy = ncp_p2x;
                                        auto n_p1xxy = n_p1xx;
                                        (crate::prelude::entered(crate::prelude::once_job([=, ncp_p2xy = std::move(ncp_p2xy), n_p1xxy = std::move(n_p1xxy)]() {
                                        return ({
                                            auto m_p1n = p0;
                                            (prism_rtl::more(prism_rtl::rc(MethodDef(ncp_p2xy, prism_rtl::deref(n_p1xxy).name_p, m_p1n))));
                                        });
                                    })));
                                    });
                                })));
                                })), [=, make_pm = std::move(make_pm)](Array<Text> each_3558) {
                                    return ({
                                        auto methods_pn = each_3558;
                                        (crate::prelude::call_value(crate::prelude::each_job(prism_rtl::deref(n_p1x).builders_p, ({
                                        auto ncp_p2x = ncp_p2;
                                        auto n_p1xx = n_p1x;
                                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::ForDef)>>(prism_rtl::rc([=, ncp_p2x = std::move(ncp_p2x), n_p1xx = std::move(n_p1xx)](crate::lower::model::ForDef p0) {
                                        return ({
                                            auto ncp_p2xy = ncp_p2x;
                                            auto n_p1xxy = n_p1xx;
                                            (crate::prelude::entered(crate::prelude::once_job([=, ncp_p2xy = std::move(ncp_p2xy), n_p1xxy = std::move(n_p1xxy)]() {
                                            return ({
                                                auto b_p1o = p0;
                                                (prism_rtl::more(prism_rtl::rc(ForBuildCpp(ncp_p2xy, prism_rtl::deref(n_p1xxy).name_p, b_p1o))));
                                            });
                                        })));
                                        });
                                    })));
                                    })), [=, methods_pn = std::move(methods_pn)](Array<Text> each_3650) {
                                        return crate::prelude::call_value(crate::prelude::each_job(prism_rtl::deref(n_p1x).gens_p, ({
                                            auto ncp_p2x = ncp_p2;
                                            auto n_p1xx = n_p1x;
                                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::GenDef)>>(prism_rtl::rc([=, ncp_p2x = std::move(ncp_p2x), n_p1xx = std::move(n_p1xx)](crate::lower::model::GenDef p0) {
                                            return ({
                                                auto ncp_p2xy = ncp_p2x;
                                                auto n_p1xxy = n_p1xx;
                                                (crate::prelude::entered(crate::prelude::once_job([=, ncp_p2xy = std::move(ncp_p2xy), n_p1xxy = std::move(n_p1xxy)]() {
                                                return ({
                                                    auto g_p1p = p0;
                                                    (prism_rtl::more(prism_rtl::rc(GenBuildCpp(ncp_p2xy, prism_rtl::deref(n_p1xxy).name_p, g_p1p))));
                                                });
                                            })));
                                            });
                                        })));
                                        })), [=](Array<Text> each_3702) {
                                            return ({
                                                auto builders_po = crate::prelude::append(each_3650, each_3702);
                                                (crate::prelude::call_value(crate::prelude::each_job(prism_rtl::deref(n_p1x).hooks_p, ({
                                                auto n_p1xx = n_p1x;
                                                auto ncp_p2x = ncp_p2;
                                                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Array<crate::lower::model::Do>>)>>(prism_rtl::rc([=, n_p1xx = std::move(n_p1xx), ncp_p2x = std::move(ncp_p2x)](std::tuple<Text, Array<crate::lower::model::Do>> p0) {
                                                return ({
                                                    auto n_p1xxy = n_p1xx;
                                                    auto ncp_p2xy = ncp_p2x;
                                                    (crate::prelude::entered(crate::prelude::once_job([=, n_p1xxy = std::move(n_p1xxy), ncp_p2xy = std::move(ncp_p2xy)]() {
                                                    return ({
                                                        auto [h_p1q, body_p1r] = p0;
                                                        (crate::prelude::call_then(crate::emit::cpp::stmts::start_cpp_statements_f(ncp_p2xy, body_p1r), [=](Text cpp_statements_f_3838) { return prism_rtl::finished(crate::emit::cpp::templates::items::cpp_function_f(Text::lit(""), hook_sig_f(h_p1q, prism_rtl::cat(prism_rtl::deref(n_p1xxy).name_p, "::")), prism_rtl::cat(cpp_statements_f_3838, "\nreturn {};"))); }));
                                                    });
                                                })));
                                                });
                                            })));
                                            })), [=, builders_po = std::move(builders_po)](Array<Text> each_3764) {
                                                return ({
                                                    auto hooks_pp = each_3764;
                                                    auto answer_pq = crate::prelude::len(prism_rtl::deref(n_p1x).answers_p) == Nat(0u)
                                                        ? Array<Text>{}
                                                        : Array(std::vector{answer_def_cpp_f(ncp_p2, n_p1x)});
                                                    auto leaving_pr = prism_rtl::deref(n_p1x).row_kind_p == crate::lower::model::RowKind(crate::lower::model::RowKind::NotARow{})
                                                        ? Array<Text>{}
                                                        : Array(std::vector{row_leaving_f(ncp_p2, n_p1x)});
                                                    auto defs_ps = crate::prelude::append(crate::prelude::append(crate::prelude::append(crate::prelude::append(crate::prelude::append(Array(std::vector{make_pm}), methods_pn), builders_po), hooks_pp), answer_pq), leaving_pr);
                                                    auto own_pt = crate::emit::cpp::items::Parts{.forward_p = Array(std::vector{prism_rtl::cat("class ", prism_rtl::deref(n_p1x).name_p, ";")}), .values_p = Array<crate::emit::cpp::items::ValueDecl>{}, .protos_p = Array<Text>{}, .classes_p = Array(std::vector{decl_pi}), .outer_p = Array<Text>{}, .generic_p = Array<Text>{}, .defs_p = defs_ps};
                                                    (prism_rtl::finished(own_pt));
                                                });
                                            }));
                                            });
                                        });
                                    }));
                                    });
                                }));
                                });
                            }));
                            });
                        }));
                        });
                    }));
                    });
                }));
                });
            }));
            });
        }));
        });
    });
}


/// `Start NodeParts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::emit::cpp::items::Parts> start_node_parts_f(crate::emit::cpp::Cp cp_p0, crate::lower::model::NodeDef n_p1) {
    return prism_rtl::make_rc<NodeParts>(cp_p0, n_p1);
}


/// MethodSig: unbounded fn Cp, MethDef, Text -> Text
Text method_sig_f(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::MethDef& m_p1, const Text& owner_p2) {
    auto cx_p3 = ({
        __label__ _done;
        prism_rtl::Slot<Array<Text>> _v;
        auto&& _m = m_p1.cx_p;
        if (prism_rtl::is<crate::lower::model::CxArg::CxMut>(_m)) {
            _v.set(Array(std::vector{Text::lit("Cx& cx")}));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::CxArg::CxRef>(_m)) {
            _v.set(Array(std::vector{Text::lit("const Cx& cx")}));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::CxArg::CxNone>(_m)) {
            _v.set(Array<Text>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto params_p4 = crate::syntax::lexer::chars::join_f(crate::prelude::append(crate::prelude::run_to_end(crate::prelude::each_job(m_p1.params_p, ({
        auto cp_p0x = cp_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=, cp_p0x = std::move(cp_p0x)](std::tuple<Text, crate::lower::model::OutTy> p0) {
        return ({
            auto cp_p0xy = cp_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xy = std::move(cp_p0xy)]() {
            return ({
                auto [p_p6, t_p7] = p0;
                (crate::prelude::call_then(crate::emit::cpp::expr::start_param_type_f(cp_p0xy, t_p7), [=](Text param_type_f_4531) { return prism_rtl::finished(prism_rtl::cat(param_type_f_4531, " ", p_p6)); }));
            });
        })));
        });
    })));
    }))), cx_p3), Text::lit(", "));
    auto constness_p5 = m_p1.recv_p == crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{})
        ? Text::lit(" const")
        : Text::lit("");
    return prism_rtl::cat(crate::emit::cpp::cpp_type_f(cp_p0, m_p1.ret_p), " ", owner_p2, crate::emit::cpp::expr::node_method_name_f(cp_p0, m_p1.name_p), "(", params_p4, ")", constness_p5);
}


prism_rtl::Turn<Text> MethodSig::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& m_p1 = this->m_p1;
    const auto& owner_p2 = this->owner_p2;
    auto cx_p3 = ({
        __label__ _done;
        prism_rtl::Slot<Array<Text>> _v;
        auto&& _m = prism_rtl::deref(m_p1).cx_p;
        if (prism_rtl::is<crate::lower::model::CxArg::CxMut>(_m)) {
            _v.set(Array(std::vector{Text::lit("Cx& cx")}));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::CxArg::CxRef>(_m)) {
            _v.set(Array(std::vector{Text::lit("const Cx& cx")}));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::CxArg::CxNone>(_m)) {
            _v.set(Array<Text>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto cp_p0x = cp_p0;
    auto m_p1x = m_p1;
    auto owner_p2x = owner_p2;
    return crate::prelude::call_value(crate::prelude::each_job(prism_rtl::deref(m_p1x).params_p, ({
        auto cp_p0xx = cp_p0x;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=, cp_p0xx = std::move(cp_p0xx)](std::tuple<Text, crate::lower::model::OutTy> p0) {
        return ({
            auto cp_p0xxy = cp_p0xx;
            (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xxy = std::move(cp_p0xxy)]() {
            return ({
                auto [p_p6, t_p7] = p0;
                (crate::prelude::call_then(crate::emit::cpp::expr::start_param_type_f(cp_p0xxy, t_p7), [=](Text param_type_f_4531) { return prism_rtl::finished(prism_rtl::cat(param_type_f_4531, " ", p_p6)); }));
            });
        })));
        });
    })));
    })), [=](Array<Text> each_4502) {
        return ({
            auto params_p4 = crate::syntax::lexer::chars::join_f(crate::prelude::append(each_4502, cx_p3), Text::lit(", "));
            auto constness_p5 = prism_rtl::deref(m_p1x).recv_p == crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{})
                ? Text::lit(" const")
                : Text::lit("");
            (crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0x, prism_rtl::deref(m_p1x).ret_p), [=, params_p4 = std::move(params_p4), constness_p5 = std::move(constness_p5)](Text cpp_type_f_4631) { return prism_rtl::finished(prism_rtl::cat(cpp_type_f_4631, " ", owner_p2x, crate::emit::cpp::expr::node_method_name_f(cp_p0x, prism_rtl::deref(m_p1x).name_p), "(", params_p4, ")", constness_p5)); }));
        });
    });
}


/// `Start MethodSig, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_method_sig_f(crate::emit::cpp::Cp cp_p0, crate::lower::model::MethDef m_p1, Text owner_p2) {
    return prism_rtl::make_rc<MethodSig>(cp_p0, m_p1, owner_p2);
}


/// MethodDef: unbounded fn Cp, Text, MethDef -> Text
Text method_def_f(const crate::emit::cpp::Cp& cp_p0, const Text& owner_p1, const crate::lower::model::MethDef& m_p2) {
    auto [st_p4, cp2_p5] = crate::emit::cpp::stmts::cpp_statements_cp_f(cp_p0, m_p2.body_p);
    auto body_p3 = m_p2.ret_p == crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})
        ? prism_rtl::cat(st_p4, "\nreturn Unit{};")
        : crate::prelude::len(m_p2.body_p) == Nat(0u)
        ? crate::emit::cpp::stmts::cpp_body_f(cp_p0, m_p2.tail_p)
        : prism_rtl::cat(st_p4, "\n", crate::emit::cpp::stmts::cpp_body_f(cp2_p5, m_p2.tail_p));
    return crate::emit::cpp::templates::items::cpp_function_f(crate::emit::cpp::items::cpp_doc_f(m_p2.doc_p), method_sig_f(cp_p0, m_p2, prism_rtl::cat(owner_p1, "::")), body_p3);
}


prism_rtl::Turn<Text> MethodDef::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& owner_p1 = this->owner_p1;
    const auto& m_p2 = this->m_p2;
    auto cp_p0x = cp_p0;
    auto m_p2x = m_p2;
    auto owner_p1x = owner_p1;
    return crate::prelude::call_then(crate::emit::cpp::stmts::start_cpp_statements_cp_f(cp_p0x, prism_rtl::deref(m_p2x).body_p), [=](std::tuple<Text, crate::emit::cpp::Cp> cpp_statements_cp_f_4807) {
        return ({
            auto [st_p4, cp2_p5] = cpp_statements_cp_f_4807;
            auto body_p3 = prism_rtl::deref(m_p2x).ret_p == crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})
                ? prism_rtl::cat(st_p4, "\nreturn Unit{};")
                : crate::prelude::len(prism_rtl::deref(m_p2x).body_p) == Nat(0u)
                ? crate::emit::cpp::stmts::cpp_body_f(cp_p0x, prism_rtl::deref(m_p2x).tail_p)
                : prism_rtl::cat(st_p4, "\n", crate::emit::cpp::stmts::cpp_body_f(cp2_p5, prism_rtl::deref(m_p2x).tail_p));
            (crate::prelude::call_then(start_method_sig_f(cp_p0x, m_p2x, prism_rtl::cat(owner_p1x, "::")), [=, body_p3 = std::move(body_p3)](Text method_sig_f_5011) { return prism_rtl::finished(crate::emit::cpp::templates::items::cpp_function_f(crate::emit::cpp::items::cpp_doc_f(prism_rtl::deref(m_p2x).doc_p), method_sig_f_5011, body_p3)); }));
        });
    });
}


/// `Start MethodDef, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_method_def_f(crate::emit::cpp::Cp cp_p0, Text owner_p1, crate::lower::model::MethDef m_p2) {
    return prism_rtl::make_rc<MethodDef>(cp_p0, owner_p1, m_p2);
}


/// HookSig: fn Text, Text -> Text
Text hook_sig_f(const Text& text0, const Text& owner_p0) {
    {
        auto&& c0_0 = text0;
        if (c0_0 == Text::lit("push")) {
            return prism_rtl::cat("Done ", owner_p0, "push(const Pod& element, const Pod& v, Cx& cx)");
        }
    }
    {
        auto&& h_p1 = text0;
        return prism_rtl::cat("Done ", owner_p0, h_p1, "(Cx& cx)");
    }
}


/// AnswerDefCpp: unbounded fn Cp, NodeDef -> Text
Text answer_def_cpp_f(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::NodeDef& n_p1) {
    auto arms_p2 = crate::prelude::run_to_end(crate::prelude::each_job(n_p1.answers_p, ({
        auto cp_p0x = cp_p0;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, Text>>(std::tuple<crate::lower::model::Pa, crate::lower::model::Ex>)>>(prism_rtl::rc([=, cp_p0x = std::move(cp_p0x)](std::tuple<crate::lower::model::Pa, crate::lower::model::Ex> p0) {
        return ({
            auto cp_p0xy = cp_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xy = std::move(cp_p0xy)]() {
            return ({
                auto [pat_p4, call_p5] = p0;
                (crate::prelude::call_then(crate::emit::cpp::patterns::start_pat_conds_f(cp_p0xy, pat_p4, Text::lit("at")), [=](Array<Text> pat_conds_f_5354) {
                return ({
                    auto tests_p6 = pat_conds_f_5354;
                    (crate::prelude::call_then(crate::emit::cpp::patterns::start_pat_binds_f(cp_p0xy, pat_p4, Text::lit("at")), [=, tests_p6 = std::move(tests_p6)](Array<Text> pat_binds_f_5397) {
                    return ({
                        auto binds_p7 = pat_binds_f_5397;
                        (crate::prelude::call_then(crate::emit::cpp::expr::start_cpp_expr_f(cp_p0xy, call_p5), [=, binds_p7 = std::move(binds_p7)](Text cpp_expr_f_5458) { return prism_rtl::finished(std::tuple{tests_p6, crate::syntax::lexer::chars::join_f(crate::prelude::push(binds_p7, prism_rtl::cat(cpp_expr_f_5458, ";")), Text::lit("\n"))}); }));
                    });
                }));
                });
            }));
            });
        })));
        });
    }));
    })));
    auto blocks_p3 = crate::prelude::each(crate::check::errors::range0_f(crate::prelude::len(arms_p2)), [&](const Nat& i_p8) {
        return ({
            auto [tests_p9, inner_pa] = crate::prelude::or_(crate::prelude::index(arms_p2, i_p8), std::tuple{Array<Text>{}, Text::lit("")});
            (crate::emit::cpp::templates::items::block_f(prism_rtl::cat(i_p8 == Nat(0u) ? Text::lit("if") : Text::lit("else if"), " (", crate::emit::cpp::patterns::conds_f(tests_p9), ")"), inner_pa));
        });
    });
    return crate::emit::cpp::templates::items::cpp_function_f(Text::lit(""), prism_rtl::cat("Done ", n_p1.name_p, "::answer(std::span<const Segment> at, const Pod& v, Cx& cx)"), prism_rtl::cat(crate::syntax::lexer::chars::join_f(blocks_p3, Text::lit(" ")), " else {\n    return unexpected(Fault::answer(str(\"no answering place at \", path_of(at))));\n}\nreturn {};"));
}


prism_rtl::Turn<Text> AnswerDefCpp::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& n_p1 = this->n_p1;
    auto cp_p0x = cp_p0;
    auto n_p1x = n_p1;
    return crate::prelude::call_value(crate::prelude::each_job(prism_rtl::deref(n_p1x).answers_p, ({
        auto cp_p0xx = cp_p0x;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, Text>>(std::tuple<crate::lower::model::Pa, crate::lower::model::Ex>)>>(prism_rtl::rc([=, cp_p0xx = std::move(cp_p0xx)](std::tuple<crate::lower::model::Pa, crate::lower::model::Ex> p0) {
        return ({
            auto cp_p0xxy = cp_p0xx;
            (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xxy = std::move(cp_p0xxy)]() {
            return ({
                auto [pat_p4, call_p5] = p0;
                (crate::prelude::call_then(crate::emit::cpp::patterns::start_pat_conds_f(cp_p0xxy, pat_p4, Text::lit("at")), [=](Array<Text> pat_conds_f_5354) {
                return ({
                    auto tests_p6 = pat_conds_f_5354;
                    (crate::prelude::call_then(crate::emit::cpp::patterns::start_pat_binds_f(cp_p0xxy, pat_p4, Text::lit("at")), [=, tests_p6 = std::move(tests_p6)](Array<Text> pat_binds_f_5397) {
                    return ({
                        auto binds_p7 = pat_binds_f_5397;
                        (crate::prelude::call_then(crate::emit::cpp::expr::start_cpp_expr_f(cp_p0xxy, call_p5), [=, binds_p7 = std::move(binds_p7)](Text cpp_expr_f_5458) { return prism_rtl::finished(std::tuple{tests_p6, crate::syntax::lexer::chars::join_f(crate::prelude::push(binds_p7, prism_rtl::cat(cpp_expr_f_5458, ";")), Text::lit("\n"))}); }));
                    });
                }));
                });
            }));
            });
        })));
        });
    }));
    })), [=](Array<std::tuple<Array<Text>, Text>> each_5301) {
        return ({
            auto arms_p2 = each_5301;
            auto blocks_p3 = crate::prelude::each(crate::check::errors::range0_f(crate::prelude::len(arms_p2)), [&](const Nat& i_p8) {
                return ({
                    auto [tests_p9, inner_pa] = crate::prelude::or_(crate::prelude::index(arms_p2, i_p8), std::tuple{Array<Text>{}, Text::lit("")});
                    (crate::emit::cpp::templates::items::block_f(prism_rtl::cat(i_p8 == Nat(0u) ? Text::lit("if") : Text::lit("else if"), " (", crate::emit::cpp::patterns::conds_f(tests_p9), ")"), inner_pa));
                });
            });
            (prism_rtl::finished(crate::emit::cpp::templates::items::cpp_function_f(Text::lit(""), prism_rtl::cat("Done ", prism_rtl::deref(n_p1x).name_p, "::answer(std::span<const Segment> at, const Pod& v, Cx& cx)"), prism_rtl::cat(crate::syntax::lexer::chars::join_f(blocks_p3, Text::lit(" ")), " else {\n    return unexpected(Fault::answer(str(\"no answering place at \", path_of(at))));\n}\nreturn {};"))));
        });
    });
}


/// `Start AnswerDefCpp, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_answer_def_cpp_f(crate::emit::cpp::Cp cp_p0, crate::lower::model::NodeDef n_p1) {
    return prism_rtl::make_rc<AnswerDefCpp>(cp_p0, n_p1);
}


/// RowLeaving: unbounded fn Cp, NodeDef -> Text
Text row_leaving_f(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::NodeDef& n_p1) {
    auto kept_p2 = n_p1.row_kind_p == crate::lower::model::RowKind(crate::lower::model::RowKind::ForRow{})
        ? Array(std::vector{Text::lit("this->left_entry = entry(cx);")})
        : Array<Text>{};
    auto unsubscribe_p3 = crate::prelude::each(n_p1.subs_p, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
        auto&& ev_p4 = std::get<0>(_p0);
        auto&& m_p5 = std::get<1>(_p0);
        return prism_rtl::cat("if (auto p = parent.lock(); p && ", m_p5, "_sub) deref(p->", ev_p4, "_port).unsubscribe(*std::exchange(", m_p5, "_sub, std::nullopt));");
    });
    return crate::emit::cpp::templates::items::cpp_function_f(Text::lit(""), prism_rtl::cat("void ", n_p1.name_p, "::leave_row(Cx& cx)"), crate::syntax::lexer::chars::join_f(crate::prelude::append(crate::prelude::push(kept_p2, Text::lit("remove_places(cx);")), unsubscribe_p3), Text::lit("\n")));
}


prism_rtl::Turn<Text> RowLeaving::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& n_p1 = this->n_p1;
    auto kept_p2 = prism_rtl::deref(n_p1).row_kind_p == crate::lower::model::RowKind(crate::lower::model::RowKind::ForRow{})
        ? Array(std::vector{Text::lit("this->left_entry = entry(cx);")})
        : Array<Text>{};
    auto unsubscribe_p3 = crate::prelude::each(prism_rtl::deref(n_p1).subs_p, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
        auto&& ev_p4 = std::get<0>(_p0);
        auto&& m_p5 = std::get<1>(_p0);
        return prism_rtl::cat("if (auto p = parent.lock(); p && ", m_p5, "_sub) deref(p->", ev_p4, "_port).unsubscribe(*std::exchange(", m_p5, "_sub, std::nullopt));");
    });
    return prism_rtl::finished(crate::emit::cpp::templates::items::cpp_function_f(Text::lit(""), prism_rtl::cat("void ", prism_rtl::deref(n_p1).name_p, "::leave_row(Cx& cx)"), crate::syntax::lexer::chars::join_f(crate::prelude::append(crate::prelude::push(kept_p2, Text::lit("remove_places(cx);")), unsubscribe_p3), Text::lit("\n"))));
}


/// `Start RowLeaving, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_row_leaving_f(crate::emit::cpp::Cp cp_p0, crate::lower::model::NodeDef n_p1) {
    return prism_rtl::make_rc<RowLeaving>(cp_p0, n_p1);
}


/// ForBuildCpp: unbounded fn Cp, Text, ForDef -> Text
Text for_build_cpp_f(const crate::emit::cpp::Cp& cp_p0, const Text& owner_p1, const crate::lower::model::ForDef& b_p2) {
    return crate::emit::cpp::templates::items::for_build_template_f(owner_p1, b_p2.name_p, crate::emit::cpp::expr::cpp_expr_f(cp_p0, b_p2.at_p), crate::emit::cpp::cpp_type_f(cp_p0, b_p2.key_ty_p), crate::emit::cpp::cpp_type_f(cp_p0, b_p2.value_ty_p), crate::emit::cpp::expr::call_path_f(prism_rtl::cat(b_p2.row_node_p, "::build")), b_p2.source_p, crate::emit::cpp::expr::cpp_expr_f(cp_p0, b_p2.parent_p), crate::prelude::concat(crate::prelude::run_to_end(crate::prelude::each_job(b_p2.passed_p, ({
        auto cp_p0x = cp_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Ex)>>(prism_rtl::rc([=, cp_p0x = std::move(cp_p0x)](crate::lower::model::Ex p0) {
        return ({
            auto cp_p0xy = cp_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xy = std::move(cp_p0xy)]() {
            return ({
                auto x_p3 = p0;
                (crate::prelude::call_then(crate::emit::cpp::expr::start_cpp_expr_f(cp_p0xy, x_p3), [=](Text cpp_expr_f_6762) { return prism_rtl::finished(prism_rtl::cat(", ", cpp_expr_f_6762)); }));
            });
        })));
        });
    })));
    })))), moved_call_cpp_f(b_p2.moved_p), from_kept_cpp_f(b_p2.name_p, b_p2.replaced_p), replaced_call_cpp_f(b_p2.replaced_p));
}


prism_rtl::Turn<Text> ForBuildCpp::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& owner_p1 = this->owner_p1;
    const auto& b_p2 = this->b_p2;
    auto b_p2x = b_p2;
    auto cp_p0x = cp_p0;
    auto owner_p1x = owner_p1;
    return crate::prelude::call_then(crate::emit::cpp::expr::start_cpp_expr_f(cp_p0x, prism_rtl::deref(b_p2x).at_p), [=](Text cpp_expr_f_6595) {
        return crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0x, prism_rtl::deref(b_p2x).key_ty_p), [=](Text cpp_type_f_6615) {
            return crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0x, prism_rtl::deref(b_p2x).value_ty_p), [=](Text cpp_type_f_6638) {
                return crate::prelude::call_then(crate::emit::cpp::expr::start_cpp_expr_f(cp_p0x, prism_rtl::deref(b_p2x).parent_p), [=](Text cpp_expr_f_6706) {
                    return crate::prelude::call_value(crate::prelude::each_job(prism_rtl::deref(b_p2x).passed_p, ({
                        auto cp_p0xx = cp_p0x;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Ex)>>(prism_rtl::rc([=, cp_p0xx = std::move(cp_p0xx)](crate::lower::model::Ex p0) {
                        return ({
                            auto cp_p0xxy = cp_p0xx;
                            (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xxy = std::move(cp_p0xxy)]() {
                            return ({
                                auto x_p3 = p0;
                                (crate::prelude::call_then(crate::emit::cpp::expr::start_cpp_expr_f(cp_p0xxy, x_p3), [=](Text cpp_expr_f_6762) { return prism_rtl::finished(prism_rtl::cat(", ", cpp_expr_f_6762)); }));
                            });
                        })));
                        });
                    })));
                    })), [=](Array<Text> each_6738) { return prism_rtl::finished(crate::emit::cpp::templates::items::for_build_template_f(owner_p1x, prism_rtl::deref(b_p2x).name_p, cpp_expr_f_6595, cpp_type_f_6615, cpp_type_f_6638, crate::emit::cpp::expr::call_path_f(prism_rtl::cat(prism_rtl::deref(b_p2x).row_node_p, "::build")), prism_rtl::deref(b_p2x).source_p, cpp_expr_f_6706, crate::prelude::concat(each_6738), moved_call_cpp_f(prism_rtl::deref(b_p2x).moved_p), from_kept_cpp_f(prism_rtl::deref(b_p2x).name_p, prism_rtl::deref(b_p2x).replaced_p), replaced_call_cpp_f(prism_rtl::deref(b_p2x).replaced_p))); });
                });
            });
        });
    });
}


/// `Start ForBuildCpp, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_for_build_cpp_f(crate::emit::cpp::Cp cp_p0, Text owner_p1, crate::lower::model::ForDef b_p2) {
    return prism_rtl::make_rc<ForBuildCpp>(cp_p0, owner_p1, b_p2);
}


/// FromKeptCpp: fn Text, [Text] -> Text
Text from_kept_cpp_f(const Text& name_p0, const Array<Text>& replaced_p1) {
    return crate::prelude::len(replaced_p1) == Nat(0u)
        ? prism_rtl::cat("this->", name_p0, "_from = items;")
        : prism_rtl::cat("auto from = std::exchange(this->", name_p0, "_from, items);");
}


/// ReplacedCallCpp: fn [Text] -> Text
Text replaced_call_cpp_f(const Array<Text>& replaced_p0) {
    return crate::prelude::len(replaced_p0) == Nat(0u)
        ? Text::lit("")
        : prism_rtl::cat(" else if (auto was = from.get(k), is = items.get(k); !was || !is || !(*was == *is)) {\n            // the dynamic under a kept key was replaced: that row follows it from the next tick\n", crate::prelude::concat(crate::prelude::each(replaced_p0, [&](const Text& m_p1) { return prism_rtl::cat("            row->", m_p1, "(cx);\n"); })), "        }");
}


/// MovedCallCpp: fn Text -> Text
Text moved_call_cpp_f(const Text& m_p0) {
    return m_p0 == Text::lit("")
        ? Text::lit("")
        : prism_rtl::cat("\n    // the places of the host\'s child came or went: its document\'s outer moves\n    if (!prism_rtl::same_keys(next, old)) this->", m_p0, "(cx);");
}


/// GenMovedCallCpp: fn Text -> Text
Text gen_moved_call_cpp_f(const Text& m_p0) {
    return m_p0 == Text::lit("")
        ? Text::lit("")
        : prism_rtl::cat("\n    // the places of the host\'s child came or went: its document\'s outer moves\n    this->", m_p0, "(cx);");
}


/// GenBuildCpp: unbounded fn Cp, Text, GenDef -> Text
Text gen_build_cpp_f(const crate::emit::cpp::Cp& cp_p0, const Text& owner_p1, const crate::lower::model::GenDef& gd_p2) {
    auto path_p3 = gd_p2.transparent_p
        ? Text::lit("this->path")
        : prism_rtl::cat(crate::emit::cpp::expr::cpp_expr_f(cp_p0, gd_p2.at_p), ".child(Segment::gen(g))");
    return crate::emit::cpp::templates::items::gen_build_template_f(owner_p1, gd_p2.name_p, crate::emit::cpp::expr::cpp_expr_f(cp_p0, gd_p2.at_p), path_p3, crate::emit::cpp::expr::cpp_expr_f(cp_p0, gd_p2.source_p), crate::emit::cpp::cpp_type_f(cp_p0, gd_p2.value_ty_p), crate::emit::cpp::expr::cpp_expr_f(cp_p0, gd_p2.select_p), gen_moved_call_cpp_f(gd_p2.moved_p));
}


prism_rtl::Turn<Text> GenBuildCpp::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& owner_p1 = this->owner_p1;
    const auto& gd_p2 = this->gd_p2;
    auto path_p3 = prism_rtl::deref(gd_p2).transparent_p
        ? Text::lit("this->path")
        : prism_rtl::cat(crate::emit::cpp::expr::cpp_expr_f(cp_p0, prism_rtl::deref(gd_p2).at_p), ".child(Segment::gen(g))");
    auto cp_p0x = cp_p0;
    auto gd_p2x = gd_p2;
    auto owner_p1x = owner_p1;
    return crate::prelude::call_then(crate::emit::cpp::expr::start_cpp_expr_f(cp_p0x, prism_rtl::deref(gd_p2x).at_p), [=](Text cpp_expr_f_8647) { return crate::prelude::call_then(crate::emit::cpp::expr::start_cpp_expr_f(cp_p0x, prism_rtl::deref(gd_p2x).source_p), [=](Text cpp_expr_f_8674) { return crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0x, prism_rtl::deref(gd_p2x).value_ty_p), [=](Text cpp_type_f_8699) { return crate::prelude::call_then(crate::emit::cpp::expr::start_cpp_expr_f(cp_p0x, prism_rtl::deref(gd_p2x).select_p), [=](Text cpp_expr_f_8725) { return prism_rtl::finished(crate::emit::cpp::templates::items::gen_build_template_f(owner_p1x, prism_rtl::deref(gd_p2x).name_p, cpp_expr_f_8647, path_p3, cpp_expr_f_8674, cpp_type_f_8699, cpp_expr_f_8725, gen_moved_call_cpp_f(prism_rtl::deref(gd_p2x).moved_p))); }); }); }); });
}


/// `Start GenBuildCpp, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_gen_build_cpp_f(crate::emit::cpp::Cp cp_p0, Text owner_p1, crate::lower::model::GenDef gd_p2) {
    return prism_rtl::make_rc<GenBuildCpp>(cp_p0, owner_p1, gd_p2);
}


/// ProgramCpp: unbounded fn Cp, ProgDef, Bool -> Text
Text program_cpp_f(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::ProgDef& p_p1, const bool& fallible_p2) {
    auto n_p3 = crate::prelude::len(p_p1.params_p);
    auto names_p4 = crate::prelude::each(p_p1.params_p, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
        auto&& a_p9 = std::get<0>(_p0);
        return a_p9;
    });
    auto plural_p5 = n_p3 == Nat(1u) ? Text::lit("") : Text::lit("s");
    auto decode_p6 = n_p3 == Nat(0u)
        ? Text::lit("static_cast<void>(args);")
        : crate::syntax::lexer::chars::join_f(crate::prelude::append(Array(std::vector{prism_rtl::cat("if (args.size() != ", n_p3, ") return unexpected(Fault::answer(\"@", p_p1.prism_p, " takes ", n_p3, " argument", plural_p5, "\"));")}), crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(n_p3), ({
        auto cp_p0x = cp_p0;
        auto p_p1x = p_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Nat)>>(prism_rtl::rc([=, cp_p0x = std::move(cp_p0x), p_p1x = std::move(p_p1x)](Nat p0) {
        return ({
            auto cp_p0xy = cp_p0x;
            auto p_p1xy = p_p1x;
            (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xy = std::move(cp_p0xy), p_p1xy = std::move(p_p1xy)]() {
            return ({
                auto i_pa = p0;
                (prism_rtl::more(prism_rtl::rc(DecodeArg(cp_p0xy, prism_rtl::deref(p_p1xy).params_p, i_pa))));
            });
        })));
        });
    })));
    })))), Text::lit("\n"));
    auto call_p7 = prism_rtl::cat(crate::emit::cpp::expr::call_path_f(prism_rtl::cat(p_p1.node_p, "::build")), "(Path::root(), ", crate::prelude::concat(crate::prelude::each(names_p4, [&](const Text& a_pb) { return prism_rtl::cat(a_pb, ", "); })), "cx)");
    auto root_p8 = fallible_p2 ? prism_rtl::cat("TRY(", call_p7, ")") : call_p7;
    return crate::emit::cpp::templates::items::program_class_f(p_p1.name_p, p_p1.prism_p, crate::emit::cpp::type_path_f(p_p1.node_p), decode_p6, root_p8);
}


prism_rtl::Turn<Text> ProgramCpp::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& p_p1 = this->p_p1;
    const auto& fallible_p2 = this->fallible_p2;
    auto n_p3 = crate::prelude::len(prism_rtl::deref(p_p1).params_p);
    auto names_p4 = crate::prelude::each(prism_rtl::deref(p_p1).params_p, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
        auto&& a_p9 = std::get<0>(_p0);
        return a_p9;
    });
    auto plural_p5 = n_p3 == Nat(1u) ? Text::lit("") : Text::lit("s");
    auto decode_p6 = n_p3 == Nat(0u)
        ? Text::lit("static_cast<void>(args);")
        : crate::syntax::lexer::chars::join_f(crate::prelude::append(Array(std::vector{prism_rtl::cat("if (args.size() != ", n_p3, ") return unexpected(Fault::answer(\"@", prism_rtl::deref(p_p1).prism_p, " takes ", n_p3, " argument", plural_p5, "\"));")}), crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(n_p3), ({
        auto cp_p0x = cp_p0;
        auto p_p1x = p_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Nat)>>(prism_rtl::rc([=, cp_p0x = std::move(cp_p0x), p_p1x = std::move(p_p1x)](Nat p0) {
        return ({
            auto cp_p0xy = cp_p0x;
            auto p_p1xy = p_p1x;
            (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xy = std::move(cp_p0xy), p_p1xy = std::move(p_p1xy)]() {
            return ({
                auto i_pa = p0;
                (prism_rtl::more(prism_rtl::rc(DecodeArg(cp_p0xy, prism_rtl::deref(p_p1xy).params_p, i_pa))));
            });
        })));
        });
    })));
    })))), Text::lit("\n"));
    auto call_p7 = prism_rtl::cat(crate::emit::cpp::expr::call_path_f(prism_rtl::cat(prism_rtl::deref(p_p1).node_p, "::build")), "(Path::root(), ", crate::prelude::concat(crate::prelude::each(names_p4, [&](const Text& a_pb) { return prism_rtl::cat(a_pb, ", "); })), "cx)");
    auto root_p8 = prism_rtl::deref(fallible_p2)
        ? prism_rtl::cat("TRY(", call_p7, ")")
        : call_p7;
    return prism_rtl::finished(crate::emit::cpp::templates::items::program_class_f(prism_rtl::deref(p_p1).name_p, prism_rtl::deref(p_p1).prism_p, crate::emit::cpp::type_path_f(prism_rtl::deref(p_p1).node_p), decode_p6, root_p8));
}


/// `Start ProgramCpp, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_program_cpp_f(crate::emit::cpp::Cp cp_p0, crate::lower::model::ProgDef p_p1, bool fallible_p2) {
    return prism_rtl::make_rc<ProgramCpp>(cp_p0, p_p1, fallible_p2);
}


/// DecodeArg: unbounded fn Cp, [((Text, OutTy))], Nat -> Text
Text decode_arg_f(const crate::emit::cpp::Cp& cp_p0, const Array<std::tuple<Text, crate::lower::model::OutTy>>& ps_p1, const Nat& i_p2) {
    auto&& _m = crate::prelude::index(ps_p1, i_p2);
    if (prism_rtl::is_some(_m)) {
        auto&& a_p3 = std::get<0>(prism_rtl::some_of(_m));
        auto&& t_p4 = std::get<1>(prism_rtl::some_of(_m));
        return prism_rtl::cat("auto ", a_p3, " = TRY(prism_rtl::from_pod<", crate::emit::cpp::cpp_type_f(cp_p0, t_p4), ">(args[", i_p2, "]));");
    }
    if (prism_rtl::is_none(_m)) {
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Text> DecodeArg::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& ps_p1 = this->ps_p1;
    const auto& i_p2 = this->i_p2;
    return ({
        auto&& _m = crate::prelude::index(ps_p1, i_p2);
        prism_rtl::is_some(_m) ? ({
        auto&& a_p3 = std::get<0>(prism_rtl::some_of(_m));
        auto&& t_p4 = std::get<1>(prism_rtl::some_of(_m));
        ({
        auto cp_p0x = cp_p0;
        auto i_p2x = i_p2;
        (crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0x, t_p4), [=, i_p2x = std::move(i_p2x)](Text cpp_type_f_9583) { return prism_rtl::finished(prism_rtl::cat("auto ", a_p3, " = TRY(prism_rtl::from_pod<", cpp_type_f_9583, ">(args[", i_p2x, "]));")); }));
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(Text::lit(""))
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start DecodeArg, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_decode_arg_f(crate::emit::cpp::Cp cp_p0, Array<std::tuple<Text, crate::lower::model::OutTy>> ps_p1, Nat i_p2) {
    return prism_rtl::make_rc<DecodeArg>(cp_p0, ps_p1, i_p2);
}


/// ModuleParts: unbounded fn Cp, ModDef -> Parts
crate::emit::cpp::items::Parts module_parts_f(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::ModDef& m_p1) {
    auto mcp_p2 = crate::emit::cpp::in_home_f(cp_p0, m_p1.name_p);
    auto all_p3 = crate::prelude::run_to_end(crate::prelude::fold_job(m_p1.items_p, crate::emit::cpp::items::no_parts_p(), ({
        auto mcp_p2x = mcp_p2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::emit::cpp::items::Parts>(std::tuple<crate::emit::cpp::items::Parts, crate::lower::model::Item>)>>(prism_rtl::rc([=, mcp_p2x = std::move(mcp_p2x)](std::tuple<crate::emit::cpp::items::Parts, crate::lower::model::Item> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto mcp_p2xy = mcp_p2x;
            (crate::prelude::entered(crate::prelude::once_job([=, mcp_p2xy = std::move(mcp_p2xy)]() {
            return ({
                auto acc_p4 = p0;
                auto it_p5 = p1;
                (crate::prelude::call_then(crate::emit::cpp::items::start_item_parts_f(mcp_p2xy, it_p5), [=, acc_p4 = std::move(acc_p4)](crate::emit::cpp::items::Parts item_parts_f_10032) { return prism_rtl::finished(crate::emit::cpp::items::join_parts_f(acc_p4, item_parts_f_10032)); }));
            });
        })));
        });
    })));
    })));
    return crate::emit::cpp::items::Parts{.forward_p = in_ns_f(m_p1.name_p, prism_rtl::deref(all_p3).forward_p), .values_p = crate::prelude::each(prism_rtl::deref(all_p3).values_p, [&](const crate::emit::cpp::items::ValueDecl& v_p6) { return in_ns_value_f(m_p1.name_p, v_p6); }), .protos_p = in_ns_f(m_p1.name_p, prism_rtl::deref(all_p3).protos_p), .classes_p = in_ns_f(m_p1.name_p, prism_rtl::deref(all_p3).classes_p), .outer_p = prism_rtl::deref(all_p3).outer_p, .generic_p = in_ns_f(m_p1.name_p, prism_rtl::deref(all_p3).generic_p), .defs_p = prism_rtl::deref(all_p3).defs_p};
}


prism_rtl::Turn<crate::emit::cpp::items::Parts> ModuleParts::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& m_p1 = this->m_p1;
    auto mcp_p2 = crate::emit::cpp::in_home_f(cp_p0, prism_rtl::deref(m_p1).name_p);
    auto m_p1x = m_p1;
    return crate::prelude::call_value(crate::prelude::fold_job(prism_rtl::deref(m_p1x).items_p, crate::emit::cpp::items::no_parts_p(), ({
        auto mcp_p2x = mcp_p2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::emit::cpp::items::Parts>(std::tuple<crate::emit::cpp::items::Parts, crate::lower::model::Item>)>>(prism_rtl::rc([=, mcp_p2x = std::move(mcp_p2x)](std::tuple<crate::emit::cpp::items::Parts, crate::lower::model::Item> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto mcp_p2xy = mcp_p2x;
            (crate::prelude::entered(crate::prelude::once_job([=, mcp_p2xy = std::move(mcp_p2xy)]() {
            return ({
                auto acc_p4 = p0;
                auto it_p5 = p1;
                (crate::prelude::call_then(crate::emit::cpp::items::start_item_parts_f(mcp_p2xy, it_p5), [=, acc_p4 = std::move(acc_p4)](crate::emit::cpp::items::Parts item_parts_f_10032) { return prism_rtl::finished(crate::emit::cpp::items::join_parts_f(acc_p4, item_parts_f_10032)); }));
            });
        })));
        });
    })));
    })), [=](crate::emit::cpp::items::Parts fold_9982) {
        return ({
            auto all_p3 = fold_9982;
            (prism_rtl::finished(crate::emit::cpp::items::Parts{.forward_p = in_ns_f(prism_rtl::deref(m_p1x).name_p, prism_rtl::deref(all_p3).forward_p), .values_p = crate::prelude::each(prism_rtl::deref(all_p3).values_p, [&](const crate::emit::cpp::items::ValueDecl& v_p6) { return in_ns_value_f(prism_rtl::deref(m_p1x).name_p, v_p6); }), .protos_p = in_ns_f(prism_rtl::deref(m_p1x).name_p, prism_rtl::deref(all_p3).protos_p), .classes_p = in_ns_f(prism_rtl::deref(m_p1x).name_p, prism_rtl::deref(all_p3).classes_p), .outer_p = prism_rtl::deref(all_p3).outer_p, .generic_p = in_ns_f(prism_rtl::deref(m_p1x).name_p, prism_rtl::deref(all_p3).generic_p), .defs_p = prism_rtl::deref(all_p3).defs_p}));
        });
    });
}


/// `Start ModuleParts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::emit::cpp::items::Parts> start_module_parts_f(crate::emit::cpp::Cp cp_p0, crate::lower::model::ModDef m_p1) {
    return prism_rtl::make_rc<ModuleParts>(cp_p0, m_p1);
}


/// InNsValue: fn Text, ValueDecl -> ValueDecl
crate::emit::cpp::items::ValueDecl in_ns_value_f(const Text& ns_p0, const crate::emit::cpp::items::ValueDecl& v_p1) {
    crate::emit::cpp::items::ValueDecl this_ = v_p1;
    this_.text_p = prism_rtl::cat("namespace ", ns_p0, " {\n\n", this_.text_p, "\n\n}  // namespace ", ns_p0);
    return this_;
}


/// InNs: fn Text, [Text] -> [Text]
Array<Text> in_ns_f(const Text& ns_p0, const Array<Text>& xs1) {
    {
        auto&& c0_1 = xs1;
        if (c0_1.size() == 0u) {
            return Array<Text>{};
        }
    }
    {
        auto&& xs_p2 = xs1;
        return Array(std::vector{prism_rtl::cat("namespace ", ns_p0, " {\n\n", crate::syntax::lexer::chars::join_f(xs_p2, Text::lit("\n\n")), "\n\n}  // namespace ", ns_p0)});
    }
}


/// NodeFallibleCpp: fn Model, Text -> Bool
bool node_fallible_cpp_f(const crate::lower::model::Model& model_p0, const Text& path_p1) {
    return crate::prelude::fold(model_p0.mods_p, false, [&](const bool& f_p2, const crate::lower::model::ModDef& m_p3) {
        return crate::prelude::fold(prism_rtl::deref(m_p3).items_p, f_p2, [&](const bool& f2_p4, const crate::lower::model::Item& it_p5) {
            return ({
                __label__ _done;
                prism_rtl::Slot<bool> _v;
                if (prism_rtl::is<crate::lower::model::Item::ItNode>(it_p5)) {
                    auto&& n_p6 = prism_rtl::as<crate::lower::model::Item::ItNode>(it_p5).a0;
                    _v.set(prism_rtl::deref(f2_p4) || ((prism_rtl::cat(prism_rtl::deref(m_p3).name_p, "::", prism_rtl::deref(n_p6).name_p) == path_p1) && prism_rtl::deref(n_p6).fallible_p));
                    goto _done;
                }
                {
                    _v.set(prism_rtl::deref(f2_p4));
                    goto _done;
                }
            _done:
                _v.take();
            });
        });
    });
}


/// EmitCpp: unbounded fn Model, Text, [Text] -> [((Text, Text))]
Array<std::tuple<Text, Text>> emit_cpp_f(const crate::lower::model::Model& model_p0, const Text& runtime_p1, const Array<Text>& scripts_p2) {
    auto cp_p3 = crate::emit::cpp::context_f(model_p0);
    auto crate_p4 = crate::emit::cpp::in_home_f(cp_p3, Text::lit(""));
    auto elem_p5 = crate::emit::cpp::items::row_parts_f(crate_p4, Text::lit(""), model_p0.elem_p);
    auto answer_p6 = crate::emit::cpp::items::answer_parts_f(crate_p4, model_p0.answer_p);
    auto mods_p7 = crate::prelude::run_to_end(crate::prelude::each_job(model_p0.mods_p, ({
        auto cp_p3x = cp_p3;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::emit::cpp::items::Parts>(crate::lower::model::ModDef)>>(prism_rtl::rc([=, cp_p3x = std::move(cp_p3x)](crate::lower::model::ModDef p0) {
        return ({
            auto cp_p3xy = cp_p3x;
            (crate::prelude::entered(crate::prelude::once_job([=, cp_p3xy = std::move(cp_p3xy)]() {
            return ({
                auto m_pu = p0;
                (prism_rtl::more(prism_rtl::rc(ModuleParts(cp_p3xy, m_pu))));
            });
        })));
        });
    })));
    })));
    auto programs_p8 = crate::syntax::lexer::chars::join_f(crate::prelude::run_to_end(crate::prelude::each_job(all_programs_cpp_f(model_p0), ({
        auto crate_p4x = crate_p4;
        auto model_p0x = model_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::ProgDef)>>(prism_rtl::rc([=, crate_p4x = std::move(crate_p4x), model_p0x = std::move(model_p0x)](crate::lower::model::ProgDef p0) {
        return ({
            auto crate_p4xy = crate_p4x;
            auto model_p0xy = model_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, crate_p4xy = std::move(crate_p4xy), model_p0xy = std::move(model_p0xy)]() {
            return ({
                auto p_pv = p0;
                (prism_rtl::more(prism_rtl::rc(ProgramCpp(crate_p4xy, p_pv, node_fallible_cpp_f(model_p0xy, prism_rtl::deref(p_pv).node_p)))));
            });
        })));
        });
    })));
    }))), Text::lit("\n\n"));
    auto regs_p9 = crate::prelude::concat(crate::prelude::each(model_p0.programs_p, [&](const crate::lower::model::ProgDef& p_p10) { return prism_rtl::cat("\n.program<", prism_rtl::deref(p_p10).name_p, ">(\"", prism_rtl::deref(p_p10).prism_p, "\")"); }));
    auto checks_pa = crate::prelude::concat(crate::prelude::run_to_end(crate::prelude::each_job(model_p0.checks_p, ({
        auto crate_p4x = crate_p4;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::CheckDef)>>(prism_rtl::rc([=, crate_p4x = std::move(crate_p4x)](crate::lower::model::CheckDef p0) {
        return ({
            auto crate_p4xy = crate_p4x;
            (crate::prelude::entered(crate::prelude::once_job([=, crate_p4xy = std::move(crate_p4xy)]() {
            return ({
                auto c_p11 = p0;
                (crate::prelude::call_value(crate::prelude::each_job(prism_rtl::deref(c_p11).lines_p, ({
                auto crate_p4xyx = crate_p4xy;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Ex)>>(prism_rtl::rc([=, crate_p4xyx = std::move(crate_p4xyx)](crate::lower::model::Ex p0) {
                return ({
                    auto crate_p4xyxy = crate_p4xyx;
                    (crate::prelude::entered(crate::prelude::once_job([=, crate_p4xyxy = std::move(crate_p4xyxy)]() {
                    return ({
                        auto l_p12 = p0;
                        (prism_rtl::more(prism_rtl::rc(crate::emit::cpp::expr::CppExpr(crate_p4xyxy, l_p12))));
                    });
                })));
                });
            })));
            })), [=](Array<Text> each_11535) { return prism_rtl::finished(prism_rtl::cat("\n.check(\"", prism_rtl::deref(c_p11).name_p, "\", [] { return std::vector<Result<Pod>>{", crate::syntax::lexer::chars::join_f(each_11535, Text::lit(", ")), "}; })")); }));
            });
        })));
        });
    })));
    }))));
    auto script_list_pb = crate::syntax::lexer::chars::join_f(crate::prelude::each(scripts_p2, [&](const Text& s_p13) { return prism_rtl::cat("\"", crate::lower::expr::escape_f(s_p13), "\","); }), Text::lit("\n"));
    auto world_pc = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = model_p0.root_o;
        if (prism_rtl::is_some(_m)) {
            auto&& r_p14 = prism_rtl::some_of(_m);
            _v.set(prism_rtl::deref(r_p14).world_p);
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text::lit("test"));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto canvas_pd = world_pc == Text::lit("canvas");
    auto run_root_pe = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = model_p0.root_o;
        if (prism_rtl::is_some(_m)) {
            auto&& r_p15 = prism_rtl::some_of(_m);
            _v.set(crate::emit::cpp::templates::cpp_run_root_f(prism_rtl::deref(r_p15).name_p, std::move(canvas_pd)
                ? crate::emit::cpp::templates::cpp_canvas_run_f(prism_rtl::deref(r_p15).name_p)
                : crate::emit::cpp::templates::cpp_no_canvas_f(prism_rtl::deref(r_p15).name_p)));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(crate::emit::cpp::templates::cpp_no_root_f(model_p0.name_p));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto both_pf = crate::emit::cpp::items::join_parts_f(elem_p5, answer_p6);
    auto elem_decl_pg = crate::emit::cpp::templates::cpp_elem_decl_f(includes_f(Text::lit("decl"), crate::prelude::append(model_p0.elem_complete_p, model_p0.elem_declared_p)), crate::syntax::lexer::chars::join_f(prism_rtl::deref(both_pf).forward_p, Text::lit("\n\n")), crate::emit::cpp::prelude::cpp_prelude_rows_f(Text::lit("")));
    auto elem_types_ph = crate::emit::cpp::templates::cpp_elem_types_f(crate::syntax::lexer::chars::join_f(crate::prelude::filter(Array(std::vector{includes_f(Text::lit("types"), model_p0.elem_complete_p), includes_f(Text::lit("decl"), model_p0.elem_declared_p)}), [&](const Text& t_p16) { return t_p16 != Text::lit(""); }), Text::lit("\n")), crate::syntax::lexer::chars::join_f(crate::prelude::each(prism_rtl::deref(both_pf).values_p, [&](const crate::emit::cpp::items::ValueDecl& v_p17) { return prism_rtl::deref(v_p17).text_p; }), Text::lit("\n\n")));
    auto pairs_pi = crate::prelude::each(crate::check::errors::range0_f(crate::prelude::len(model_p0.mods_p)), [&](const Nat& i_p18) { return std::tuple{crate::prelude::or_(crate::prelude::index(model_p0.mods_p, i_p18), no_mod_p()), crate::prelude::or_(crate::prelude::index(mods_p7, i_p18), crate::emit::cpp::items::no_parts_p())}; });
    auto generics_pj = crate::prelude::fold(pairs_pi, Array<Text>{}, [&](const Array<Text>& acc_p19, const std::tuple<crate::lower::model::ModDef, crate::emit::cpp::items::Parts>& _p1) {
        auto&& m_p1a = std::get<0>(_p1);
        auto&& p_p1b = std::get<1>(_p1);
        return crate::prelude::len(prism_rtl::deref(p_p1b).generic_p) > Nat(0u)
            ? crate::prelude::push(acc_p19, prism_rtl::deref(m_p1a).name_p)
            : acc_p19;
    });
    auto per_module_pk = crate::prelude::run_to_end(crate::prelude::each_job(pairs_pi, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, Text>>, Array<Piece>>>(std::tuple<crate::lower::model::ModDef, crate::emit::cpp::items::Parts>)>>(prism_rtl::rc([=](std::tuple<crate::lower::model::ModDef, crate::emit::cpp::items::Parts> p0) {
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto [m_p1c, p_p1d] = p0;
                (prism_rtl::more(prism_rtl::rc(ModuleFiles(m_p1c, p_p1d))));
            });
        }));
    }))));
    auto pieces_pl = crate::prelude::fold(per_module_pk, Array<Piece>{}, [&](const Array<Piece>& acc_p1e, const std::tuple<Array<std::tuple<Text, Text>>, Array<Piece>>& _p1) {
        auto&& ps_p1f = std::get<1>(_p1);
        return crate::prelude::append(acc_p1e, ps_p1f);
    });
    auto units_pm = units_f(pieces_pl);
    auto unit_files_pn = crate::prelude::each(crate::check::errors::range0_f(crate::prelude::len(units_pm)), [&](const Nat& k_p1g) { return unit_file_f(k_p1g, crate::prelude::or_(crate::prelude::index(units_pm, k_p1g), Array<Piece>{}), generics_pj); });
    auto main_includes_po = crate::syntax::lexer::chars::join_f(crate::prelude::append(crate::prelude::append(Array(std::vector{Text::lit("#include \"elem.types.hpp\"")}), Array(std::vector{includes_f(Text::lit(""), crate::prelude::each(model_p0.mods_p, [&](const crate::lower::model::ModDef& m_p1h) { return prism_rtl::deref(m_p1h).name_p; }))})), Array(std::vector{includes_f(Text::lit("generic"), generics_pj)})), Text::lit("\n"));
    auto canvas_include_pp = std::move(canvas_pd)
        ? crate::emit::cpp::templates::cpp_canvas_include_f(Text::lit(""))
        : Text::lit("");
    auto main_pq = crate::emit::cpp::templates::cpp_main_f(model_p0.name_p, prism_rtl::cat("#include \"programs.hpp\"\n", canvas_include_pp), regs_p9, checks_pa, script_list_pb, world_pc, run_root_pe, crate::syntax::lexer::chars::join_f(crate::emit::cpp::patterns::concat2_f(crate::prelude::each(Array(std::vector{elem_p5, answer_p6}), [&](const crate::emit::cpp::items::Parts& p_p1i) { return prism_rtl::deref(p_p1i).defs_p; })), Text::lit("\n\n")));
    auto groups_pr = crate::prelude::run_to_end(crate::prelude::each_job(crate::prelude::filter(model_p0.mods_p, [&](const crate::lower::model::ModDef& m_p1j) { return (crate::prelude::len(prism_rtl::deref(m_p1j).types_with_p) > Nat(1u)) && (crate::prelude::or_(crate::prelude::index(prism_rtl::deref(m_p1j).types_with_p, Nat(0u)), Text::lit("")) == prism_rtl::deref(m_p1j).name_p); }), ({
        auto pairs_pix = pairs_pi;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, Text>>(crate::lower::model::ModDef)>>(prism_rtl::rc([=, pairs_pix = std::move(pairs_pix)](crate::lower::model::ModDef p0) {
        return ({
            auto pairs_pixy = pairs_pix;
            (crate::prelude::entered(crate::prelude::once_job([=, pairs_pixy = std::move(pairs_pixy)]() {
            return ({
                auto m_p1k = p0;
                (prism_rtl::more(prism_rtl::rc(GroupTypesFile(pairs_pixy, prism_rtl::deref(m_p1k).types_with_p))));
            });
        })));
        });
    }));
    })));
    auto files_ps = crate::prelude::append(crate::prelude::fold(per_module_pk, Array<std::tuple<Text, Text>>{}, [&](const Array<std::tuple<Text, Text>>& acc_p1l, const std::tuple<Array<std::tuple<Text, Text>>, Array<Piece>>& _p1) {
        auto&& fs_p1m = std::get<0>(_p1);
        return crate::prelude::append(acc_p1l, fs_p1m);
    }), unit_files_pn);
    auto sources_pt = crate::syntax::lexer::chars::join_f(crate::prelude::filter(crate::prelude::each(files_ps, [&](const std::tuple<Text, Text>& _p0) {
        auto&& f_p1n = std::get<0>(_p0);
        return f_p1n;
    }), [&](const Text& f_p1o) { return crate::syntax::lexer::chars::contains_f(f_p1o, Text::lit(".cpp")); }), Text::lit(" "));
    return crate::prelude::append(Array(std::vector{std::tuple{Text::lit("Makefile"), crate::emit::cpp::templates::cpp_makefile_f(model_p0.name_p, runtime_p1, sources_pt, std::move(canvas_pd)
        ? crate::emit::cpp::templates::cpp_makefile_canvas_f(runtime_p1)
        : Text::lit(""))}, std::tuple{Text::lit("src/elem.decl.hpp"), elem_decl_pg}, std::tuple{Text::lit("src/elem.types.hpp"), elem_types_ph}, std::tuple{Text::lit("src/programs.hpp"), crate::emit::cpp::templates::cpp_programs_header_f(model_p0.name_p, main_includes_po, programs_p8)}, std::tuple{Text::lit("src/main.cpp"), main_pq}, std::tuple{Text::lit("src/prelude.hpp"), crate::emit::cpp::prelude::cpp_prelude_source_f(Text::lit(""))}}), crate::prelude::append(groups_pr, files_ps));
}


prism_rtl::Turn<Array<std::tuple<Text, Text>>> EmitCpp::cycle() const {
    const auto& model_p0 = this->model_p0;
    const auto& runtime_p1 = this->runtime_p1;
    const auto& scripts_p2 = this->scripts_p2;
    auto cp_p3 = crate::emit::cpp::context_f(model_p0);
    auto crate_p4 = crate::emit::cpp::in_home_f(cp_p3, Text::lit(""));
    auto model_p0x = model_p0;
    auto runtime_p1x = runtime_p1;
    auto scripts_p2x = scripts_p2;
    return crate::prelude::call_then(crate::emit::cpp::items::start_row_parts_f(crate_p4, Text::lit(""), prism_rtl::deref(model_p0x).elem_p), [=](crate::emit::cpp::items::Parts row_parts_f_11072) {
        return ({
            auto elem_p5 = row_parts_f_11072;
            (crate::prelude::call_then(crate::emit::cpp::items::start_answer_parts_f(crate_p4, prism_rtl::deref(model_p0x).answer_p), [=, elem_p5 = std::move(elem_p5)](crate::emit::cpp::items::Parts answer_parts_f_11120) {
            return ({
                auto answer_p6 = answer_parts_f_11120;
                (crate::prelude::call_value(crate::prelude::each_job(prism_rtl::deref(model_p0x).mods_p, ({
                auto cp_p3x = cp_p3;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::emit::cpp::items::Parts>(crate::lower::model::ModDef)>>(prism_rtl::rc([=, cp_p3x = std::move(cp_p3x)](crate::lower::model::ModDef p0) {
                return ({
                    auto cp_p3xy = cp_p3x;
                    (crate::prelude::entered(crate::prelude::once_job([=, cp_p3xy = std::move(cp_p3xy)]() {
                    return ({
                        auto m_pu = p0;
                        (prism_rtl::more(prism_rtl::rc(ModuleParts(cp_p3xy, m_pu))));
                    });
                })));
                });
            })));
            })), [=, answer_p6 = std::move(answer_p6)](Array<crate::emit::cpp::items::Parts> each_11167) {
                return ({
                    auto mods_p7 = each_11167;
                    (crate::prelude::call_value(crate::prelude::each_job(all_programs_cpp_f(model_p0x), ({
                    auto crate_p4x = crate_p4;
                    auto model_p0xx = model_p0x;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::ProgDef)>>(prism_rtl::rc([=, crate_p4x = std::move(crate_p4x), model_p0xx = std::move(model_p0xx)](crate::lower::model::ProgDef p0) {
                    return ({
                        auto crate_p4xy = crate_p4x;
                        auto model_p0xxy = model_p0xx;
                        (crate::prelude::entered(crate::prelude::once_job([=, crate_p4xy = std::move(crate_p4xy), model_p0xxy = std::move(model_p0xxy)]() {
                        return ({
                            auto p_pv = p0;
                            (prism_rtl::more(prism_rtl::rc(ProgramCpp(crate_p4xy, p_pv, node_fallible_cpp_f(model_p0xxy, prism_rtl::deref(p_pv).node_p)))));
                        });
                    })));
                    });
                })));
                })), [=, mods_p7 = std::move(mods_p7)](Array<Text> each_11232) {
                    return ({
                        auto programs_p8 = crate::syntax::lexer::chars::join_f(each_11232, Text::lit("\n\n"));
                        auto regs_p9 = crate::prelude::concat(crate::prelude::each(prism_rtl::deref(model_p0x).programs_p, [&](const crate::lower::model::ProgDef& p_p10) { return prism_rtl::cat("\n.program<", prism_rtl::deref(p_p10).name_p, ">(\"", prism_rtl::deref(p_p10).prism_p, "\")"); }));
                        (crate::prelude::call_value(crate::prelude::each_job(prism_rtl::deref(model_p0x).checks_p, ({
                        auto crate_p4x = crate_p4;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::CheckDef)>>(prism_rtl::rc([=, crate_p4x = std::move(crate_p4x)](crate::lower::model::CheckDef p0) {
                        return ({
                            auto crate_p4xy = crate_p4x;
                            (crate::prelude::entered(crate::prelude::once_job([=, crate_p4xy = std::move(crate_p4xy)]() {
                            return ({
                                auto c_p11 = p0;
                                (crate::prelude::call_value(crate::prelude::each_job(prism_rtl::deref(c_p11).lines_p, ({
                                auto crate_p4xyx = crate_p4xy;
                                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Ex)>>(prism_rtl::rc([=, crate_p4xyx = std::move(crate_p4xyx)](crate::lower::model::Ex p0) {
                                return ({
                                    auto crate_p4xyxy = crate_p4xyx;
                                    (crate::prelude::entered(crate::prelude::once_job([=, crate_p4xyxy = std::move(crate_p4xyxy)]() {
                                    return ({
                                        auto l_p12 = p0;
                                        (prism_rtl::more(prism_rtl::rc(crate::emit::cpp::expr::CppExpr(crate_p4xyxy, l_p12))));
                                    });
                                })));
                                });
                            })));
                            })), [=](Array<Text> each_11535) { return prism_rtl::finished(prism_rtl::cat("\n.check(\"", prism_rtl::deref(c_p11).name_p, "\", [] { return std::vector<Result<Pod>>{", crate::syntax::lexer::chars::join_f(each_11535, Text::lit(", ")), "}; })")); }));
                            });
                        })));
                        });
                    })));
                    })), [=, programs_p8 = std::move(programs_p8), regs_p9 = std::move(regs_p9)](Array<Text> each_11441) {
                        return ({
                            auto checks_pa = crate::prelude::concat(each_11441);
                            auto script_list_pb = crate::syntax::lexer::chars::join_f(crate::prelude::each(scripts_p2x, [&](const Text& s_p13) { return prism_rtl::cat("\"", crate::lower::expr::escape_f(s_p13), "\","); }), Text::lit("\n"));
                            auto world_pc = ({
                                __label__ _done;
                                prism_rtl::Slot<Text> _v;
                                auto&& _m = prism_rtl::deref(model_p0x).root_o;
                                if (prism_rtl::is_some(_m)) {
                                    auto&& r_p14 = prism_rtl::some_of(_m);
                                    _v.set(prism_rtl::deref(r_p14).world_p);
                                    goto _done;
                                }
                                if (prism_rtl::is_none(_m)) {
                                    _v.set(Text::lit("test"));
                                    goto _done;
                                }
                                prism_rtl::unreachable("no arm matched");
                            _done:
                                _v.take();
                            });
                            auto canvas_pd = world_pc == Text::lit("canvas");
                            auto run_root_pe = ({
                                __label__ _done;
                                prism_rtl::Slot<Text> _v;
                                auto&& _m = prism_rtl::deref(model_p0x).root_o;
                                if (prism_rtl::is_some(_m)) {
                                    auto&& r_p15 = prism_rtl::some_of(_m);
                                    _v.set(crate::emit::cpp::templates::cpp_run_root_f(prism_rtl::deref(r_p15).name_p, std::move(canvas_pd)
                                        ? crate::emit::cpp::templates::cpp_canvas_run_f(prism_rtl::deref(r_p15).name_p)
                                        : crate::emit::cpp::templates::cpp_no_canvas_f(prism_rtl::deref(r_p15).name_p)));
                                    goto _done;
                                }
                                if (prism_rtl::is_none(_m)) {
                                    _v.set(crate::emit::cpp::templates::cpp_no_root_f(prism_rtl::deref(model_p0x).name_p));
                                    goto _done;
                                }
                                prism_rtl::unreachable("no arm matched");
                            _done:
                                _v.take();
                            });
                            auto both_pf = crate::emit::cpp::items::join_parts_f(elem_p5, answer_p6);
                            auto elem_decl_pg = crate::emit::cpp::templates::cpp_elem_decl_f(includes_f(Text::lit("decl"), crate::prelude::append(prism_rtl::deref(model_p0x).elem_complete_p, prism_rtl::deref(model_p0x).elem_declared_p)), crate::syntax::lexer::chars::join_f(prism_rtl::deref(both_pf).forward_p, Text::lit("\n\n")), crate::emit::cpp::prelude::cpp_prelude_rows_f(Text::lit("")));
                            auto elem_types_ph = crate::emit::cpp::templates::cpp_elem_types_f(crate::syntax::lexer::chars::join_f(crate::prelude::filter(Array(std::vector{includes_f(Text::lit("types"), prism_rtl::deref(model_p0x).elem_complete_p), includes_f(Text::lit("decl"), prism_rtl::deref(model_p0x).elem_declared_p)}), [&](const Text& t_p16) { return t_p16 != Text::lit(""); }), Text::lit("\n")), crate::syntax::lexer::chars::join_f(crate::prelude::each(prism_rtl::deref(both_pf).values_p, [&](const crate::emit::cpp::items::ValueDecl& v_p17) { return prism_rtl::deref(v_p17).text_p; }), Text::lit("\n\n")));
                            auto pairs_pi = crate::prelude::each(crate::check::errors::range0_f(crate::prelude::len(prism_rtl::deref(model_p0x).mods_p)), [&](const Nat& i_p18) { return std::tuple{crate::prelude::or_(crate::prelude::index(prism_rtl::deref(model_p0x).mods_p, i_p18), no_mod_p()), crate::prelude::or_(crate::prelude::index(mods_p7, i_p18), crate::emit::cpp::items::no_parts_p())}; });
                            auto generics_pj = crate::prelude::fold(pairs_pi, Array<Text>{}, [&](const Array<Text>& acc_p19, const std::tuple<crate::lower::model::ModDef, crate::emit::cpp::items::Parts>& _p1) {
                                auto&& m_p1a = std::get<0>(_p1);
                                auto&& p_p1b = std::get<1>(_p1);
                                return crate::prelude::len(prism_rtl::deref(p_p1b).generic_p) > Nat(0u)
                                    ? crate::prelude::push(acc_p19, prism_rtl::deref(m_p1a).name_p)
                                    : acc_p19;
                            });
                            (crate::prelude::call_value(crate::prelude::each_job(pairs_pi, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, Text>>, Array<Piece>>>(std::tuple<crate::lower::model::ModDef, crate::emit::cpp::items::Parts>)>>(prism_rtl::rc([=](std::tuple<crate::lower::model::ModDef, crate::emit::cpp::items::Parts> p0) {
                            return crate::prelude::entered(crate::prelude::once_job([=]() {
                                return ({
                                    auto [m_p1c, p_p1d] = p0;
                                    (prism_rtl::more(prism_rtl::rc(ModuleFiles(m_p1c, p_p1d))));
                                });
                            }));
                        }))), [=, checks_pa = std::move(checks_pa), script_list_pb = std::move(script_list_pb), world_pc = std::move(world_pc), canvas_pd = std::move(canvas_pd), run_root_pe = std::move(run_root_pe), elem_decl_pg = std::move(elem_decl_pg), elem_types_ph = std::move(elem_types_ph), generics_pj = std::move(generics_pj)](Array<std::tuple<Array<std::tuple<Text, Text>>, Array<Piece>>> each_12547) {
                            return ({
                                auto per_module_pk = each_12547;
                                auto pieces_pl = crate::prelude::fold(per_module_pk, Array<Piece>{}, [&](const Array<Piece>& acc_p1e, const std::tuple<Array<std::tuple<Text, Text>>, Array<Piece>>& _p1) {
                                    auto&& ps_p1f = std::get<1>(_p1);
                                    return crate::prelude::append(acc_p1e, ps_p1f);
                                });
                                auto units_pm = units_f(pieces_pl);
                                auto unit_files_pn = crate::prelude::each(crate::check::errors::range0_f(crate::prelude::len(units_pm)), [&](const Nat& k_p1g) { return unit_file_f(k_p1g, crate::prelude::or_(crate::prelude::index(units_pm, k_p1g), Array<Piece>{}), generics_pj); });
                                auto main_includes_po = crate::syntax::lexer::chars::join_f(crate::prelude::append(crate::prelude::append(Array(std::vector{Text::lit("#include \"elem.types.hpp\"")}), Array(std::vector{includes_f(Text::lit(""), crate::prelude::each(prism_rtl::deref(model_p0x).mods_p, [&](const crate::lower::model::ModDef& m_p1h) { return prism_rtl::deref(m_p1h).name_p; }))})), Array(std::vector{includes_f(Text::lit("generic"), generics_pj)})), Text::lit("\n"));
                                auto canvas_include_pp = canvas_pd
                                    ? crate::emit::cpp::templates::cpp_canvas_include_f(Text::lit(""))
                                    : Text::lit("");
                                auto main_pq = crate::emit::cpp::templates::cpp_main_f(prism_rtl::deref(model_p0x).name_p, prism_rtl::cat("#include \"programs.hpp\"\n", canvas_include_pp), regs_p9, checks_pa, script_list_pb, world_pc, run_root_pe, crate::syntax::lexer::chars::join_f(crate::emit::cpp::patterns::concat2_f(crate::prelude::each(Array(std::vector{elem_p5, answer_p6}), [&](const crate::emit::cpp::items::Parts& p_p1i) { return prism_rtl::deref(p_p1i).defs_p; })), Text::lit("\n\n")));
                                (crate::prelude::call_value(crate::prelude::each_job(crate::prelude::filter(prism_rtl::deref(model_p0x).mods_p, [&](const crate::lower::model::ModDef& m_p1j) { return (crate::prelude::len(prism_rtl::deref(m_p1j).types_with_p) > Nat(1u)) && (crate::prelude::or_(crate::prelude::index(prism_rtl::deref(m_p1j).types_with_p, Nat(0u)), Text::lit("")) == prism_rtl::deref(m_p1j).name_p); }), ({
                                auto pairs_pix = pairs_pi;
                                static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, Text>>(crate::lower::model::ModDef)>>(prism_rtl::rc([=, pairs_pix = std::move(pairs_pix)](crate::lower::model::ModDef p0) {
                                return ({
                                    auto pairs_pixy = pairs_pix;
                                    (crate::prelude::entered(crate::prelude::once_job([=, pairs_pixy = std::move(pairs_pixy)]() {
                                    return ({
                                        auto m_p1k = p0;
                                        (prism_rtl::more(prism_rtl::rc(GroupTypesFile(pairs_pixy, prism_rtl::deref(m_p1k).types_with_p))));
                                    });
                                })));
                                });
                            }));
                            })), [=, per_module_pk = std::move(per_module_pk), unit_files_pn = std::move(unit_files_pn), main_includes_po = std::move(main_includes_po), main_pq = std::move(main_pq)](Array<std::tuple<Text, Text>> each_13227) {
                                return ({
                                    auto groups_pr = each_13227;
                                    auto files_ps = crate::prelude::append(crate::prelude::fold(per_module_pk, Array<std::tuple<Text, Text>>{}, [&](const Array<std::tuple<Text, Text>>& acc_p1l, const std::tuple<Array<std::tuple<Text, Text>>, Array<Piece>>& _p1) {
                                        auto&& fs_p1m = std::get<0>(_p1);
                                        return crate::prelude::append(acc_p1l, fs_p1m);
                                    }), unit_files_pn);
                                    auto sources_pt = crate::syntax::lexer::chars::join_f(crate::prelude::filter(crate::prelude::each(files_ps, [&](const std::tuple<Text, Text>& _p0) {
                                        auto&& f_p1n = std::get<0>(_p0);
                                        return f_p1n;
                                    }), [&](const Text& f_p1o) { return crate::syntax::lexer::chars::contains_f(f_p1o, Text::lit(".cpp")); }), Text::lit(" "));
                                    (prism_rtl::finished(crate::prelude::append(Array(std::vector{std::tuple{Text::lit("Makefile"), crate::emit::cpp::templates::cpp_makefile_f(prism_rtl::deref(model_p0x).name_p, runtime_p1x, sources_pt, canvas_pd
                                    ? crate::emit::cpp::templates::cpp_makefile_canvas_f(runtime_p1x)
                                    : Text::lit(""))}, std::tuple{Text::lit("src/elem.decl.hpp"), elem_decl_pg}, std::tuple{Text::lit("src/elem.types.hpp"), elem_types_ph}, std::tuple{Text::lit("src/programs.hpp"), crate::emit::cpp::templates::cpp_programs_header_f(prism_rtl::deref(model_p0x).name_p, main_includes_po, programs_p8)}, std::tuple{Text::lit("src/main.cpp"), main_pq}, std::tuple{Text::lit("src/prelude.hpp"), crate::emit::cpp::prelude::cpp_prelude_source_f(Text::lit(""))}}), crate::prelude::append(groups_pr, files_ps))));
                                });
                            }));
                            });
                        }));
                        });
                    }));
                    });
                }));
                });
            }));
            });
        }));
        });
    });
}


/// `Start EmitCpp, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<std::tuple<Text, Text>>> start_emit_cpp_f(crate::lower::model::Model model_p0, Text runtime_p1, Array<Text> scripts_p2) {
    return prism_rtl::make_rc<EmitCpp>(model_p0, runtime_p1, scripts_p2);
}


/// let noMod
crate::lower::model::ModDef no_mod_p() {
    return crate::lower::model::ModDef{.name_p = Text::lit(""), .prism_p = Text::lit(""), .path_p = Text::lit(""), .uses_p = Array<Text>{}, .complete_p = Array<Text>{}, .declared_p = Array<Text>{}, .types_with_p = Array<Text>{}, .items_p = Array<crate::lower::model::Item>{}};
}


/// GroupTypesFile: unbounded fn [((ModDef, Parts))], [Text] -> ((Text, Text))
std::tuple<Text, Text> group_types_file_f(const Array<std::tuple<crate::lower::model::ModDef, crate::emit::cpp::items::Parts>>& pairs_p0, const Array<Text>& group_p1) {
    auto members_p2 = crate::prelude::filter(pairs_p0, [&](const std::tuple<crate::lower::model::ModDef, crate::emit::cpp::items::Parts>& _p0) {
        auto&& m_p7 = std::get<0>(_p0);
        return among_f(group_p1, prism_rtl::deref(m_p7).name_p);
    });
    auto p_p3 = crate::prelude::fold(members_p2, crate::emit::cpp::items::no_parts_p(), [&](const crate::emit::cpp::items::Parts& acc_p8, const std::tuple<crate::lower::model::ModDef, crate::emit::cpp::items::Parts>& _p1) {
        auto&& q_p9 = std::get<1>(_p1);
        return crate::emit::cpp::items::join_parts_f(acc_p8, q_p9);
    });
    auto complete_p4 = crate::prelude::fold(members_p2, Array<Text>{}, [&](const Array<Text>& acc_pa, const std::tuple<crate::lower::model::ModDef, crate::emit::cpp::items::Parts>& _p1) {
        auto&& m_pb = std::get<0>(_p1);
        return crate::prelude::fold(prism_rtl::deref(m_pb).complete_p, acc_pa, [&](const Array<Text>& a_pc, const Text& n_pd) {
            return among_f(a_pc, n_pd) || among_f(group_p1, n_pd)
                ? a_pc
                : crate::prelude::push(a_pc, n_pd);
        });
    });
    auto declared_p5 = crate::prelude::fold(members_p2, Array<Text>{}, [&](const Array<Text>& acc_pe, const std::tuple<crate::lower::model::ModDef, crate::emit::cpp::items::Parts>& _p1) {
        auto&& m_pf = std::get<0>(_p1);
        return crate::prelude::fold(prism_rtl::deref(m_pf).declared_p, acc_pe, [&](const Array<Text>& a_pg, const Text& n_ph) {
            return (among_f(a_pg, n_ph) || among_f(group_p1, n_ph)) || among_f(complete_p4, n_ph)
                ? a_pg
                : crate::prelude::push(a_pg, n_ph);
        });
    });
    auto title_p6 = prism_rtl::cat("The modules ", crate::syntax::lexer::chars::join_f(crate::prelude::each(group_p1, [&](const Text& n_pi) { return prism_rtl::cat("`", n_pi, "`"); }), Text::lit(", ")));
    return std::tuple{prism_rtl::cat("src/", group_name_f(group_p1), ".types.hpp"), types_header_f(title_p6, group_p1, declared_p5, complete_p4, p_p3)};
}


prism_rtl::Turn<std::tuple<Text, Text>> GroupTypesFile::cycle() const {
    const auto& pairs_p0 = this->pairs_p0;
    const auto& group_p1 = this->group_p1;
    auto members_p2 = crate::prelude::filter(pairs_p0, [&](const std::tuple<crate::lower::model::ModDef, crate::emit::cpp::items::Parts>& _p0) {
        auto&& m_p7 = std::get<0>(_p0);
        return among_f(group_p1, prism_rtl::deref(m_p7).name_p);
    });
    auto p_p3 = crate::prelude::fold(members_p2, crate::emit::cpp::items::no_parts_p(), [&](const crate::emit::cpp::items::Parts& acc_p8, const std::tuple<crate::lower::model::ModDef, crate::emit::cpp::items::Parts>& _p1) {
        auto&& q_p9 = std::get<1>(_p1);
        return crate::emit::cpp::items::join_parts_f(acc_p8, q_p9);
    });
    auto complete_p4 = crate::prelude::fold(members_p2, Array<Text>{}, [&](const Array<Text>& acc_pa, const std::tuple<crate::lower::model::ModDef, crate::emit::cpp::items::Parts>& _p1) {
        auto&& m_pb = std::get<0>(_p1);
        return crate::prelude::fold(prism_rtl::deref(m_pb).complete_p, acc_pa, [&](const Array<Text>& a_pc, const Text& n_pd) {
            return among_f(a_pc, n_pd) || among_f(group_p1, n_pd)
                ? a_pc
                : crate::prelude::push(a_pc, n_pd);
        });
    });
    auto declared_p5 = crate::prelude::fold(members_p2, Array<Text>{}, [&](const Array<Text>& acc_pe, const std::tuple<crate::lower::model::ModDef, crate::emit::cpp::items::Parts>& _p1) {
        auto&& m_pf = std::get<0>(_p1);
        return crate::prelude::fold(prism_rtl::deref(m_pf).declared_p, acc_pe, [&](const Array<Text>& a_pg, const Text& n_ph) {
            return (among_f(a_pg, n_ph) || among_f(group_p1, n_ph)) || among_f(complete_p4, n_ph)
                ? a_pg
                : crate::prelude::push(a_pg, n_ph);
        });
    });
    auto title_p6 = prism_rtl::cat("The modules ", crate::syntax::lexer::chars::join_f(crate::prelude::each(group_p1, [&](const Text& n_pi) { return prism_rtl::cat("`", n_pi, "`"); }), Text::lit(", ")));
    auto group_p1x = group_p1;
    return crate::prelude::call_then(start_types_header_f(title_p6, group_p1x, declared_p5, complete_p4, p_p3), [=](Text types_header_f_14897) { return prism_rtl::finished(std::tuple{prism_rtl::cat("src/", group_name_f(group_p1x), ".types.hpp"), types_header_f_14897}); });
}


/// `Start GroupTypesFile, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Text, Text>> start_group_types_file_f(Array<std::tuple<crate::lower::model::ModDef, crate::emit::cpp::items::Parts>> pairs_p0, Array<Text> group_p1) {
    return prism_rtl::make_rc<GroupTypesFile>(pairs_p0, group_p1);
}


/// GroupName: fn [Text] -> Text
Text group_name_f(const Array<Text>& group_p0) {
    return crate::syntax::lexer::chars::join_f(crate::prelude::each(group_p0, [&](const Text& n_p1) { return crate::syntax::lexer::chars::join_f(crate::prelude::split_on(n_p1, Text::lit("::")), Text::lit("_")); }), Text::lit("-"));
}


/// ModDir: fn Text -> Text
Text mod_dir_f(const Text& m_p0) {
    return crate::syntax::lexer::chars::join_f(crate::prelude::split_on(m_p0, Text::lit("::")), Text::lit("/"));
}


/// Among: fn [Text], Text -> Bool
bool among_f(const Array<Text>& xs_p0, const Text& x_p1) {
    return crate::prelude::fold(xs_p0, false, [&](const bool& f_p2, const Text& y_p3) { return prism_rtl::deref(f_p2) || (y_p3 == x_p1); });
}


/// TypesHeader: unbounded fn Text, [Text], [Text], [Text], Parts -> Text
Text types_header_f(const Text& title_p0, const Array<Text>& members_p1, const Array<Text>& declared_p2, const Array<Text>& complete_p3, const crate::emit::cpp::items::Parts& p_p4) {
    auto holds_elem_p5 = crate::prelude::fold(p_p4.values_p, false, [&](const bool& f_p9, const crate::emit::cpp::items::ValueDecl& v_pa) { return prism_rtl::deref(f_p9) || crate::prelude::fold(prism_rtl::deref(v_pa).deps_p, false, [&](const bool& g_pb, const Text& d_pc) { return (prism_rtl::deref(g_pb) || (d_pc == Text::lit("Elem"))) || (d_pc == Text::lit("Answer")); }); });
    auto elem_p6 = std::move(holds_elem_p5)
        ? Text::lit("#include \"elem.types.hpp\"")
        : Text::lit("#include \"elem.decl.hpp\"");
    auto includes_p7 = crate::syntax::lexer::chars::join_f(crate::prelude::filter(Array(std::vector{includes_f(Text::lit("decl"), members_p1), elem_p6, includes_f(Text::lit("decl"), declared_p2), includes_f(Text::lit("types"), complete_p3)}), [&](const Text& t_pd) { return t_pd != Text::lit(""); }), Text::lit("\n"));
    auto values_p8 = crate::syntax::lexer::chars::join_f(order_values_f(p_p4.values_p, crate::prelude::fold(p_p4.values_p, Map<Text, bool>{}, [&](const Map<Text, bool>& acc_pe, const crate::emit::cpp::items::ValueDecl& v_pf) { return crate::prelude::insert(acc_pe, prism_rtl::deref(v_pf).path_p, false); }), Array<Text>{}), Text::lit("\n\n"));
    return crate::emit::cpp::templates::cpp_types_header_f(title_p0, includes_p7, values_p8);
}


prism_rtl::Turn<Text> TypesHeader::cycle() const {
    const auto& title_p0 = this->title_p0;
    const auto& members_p1 = this->members_p1;
    const auto& declared_p2 = this->declared_p2;
    const auto& complete_p3 = this->complete_p3;
    const auto& p_p4 = this->p_p4;
    auto holds_elem_p5 = crate::prelude::fold(prism_rtl::deref(p_p4).values_p, false, [&](const bool& f_p9, const crate::emit::cpp::items::ValueDecl& v_pa) { return prism_rtl::deref(f_p9) || crate::prelude::fold(prism_rtl::deref(v_pa).deps_p, false, [&](const bool& g_pb, const Text& d_pc) { return (prism_rtl::deref(g_pb) || (d_pc == Text::lit("Elem"))) || (d_pc == Text::lit("Answer")); }); });
    auto elem_p6 = std::move(holds_elem_p5)
        ? Text::lit("#include \"elem.types.hpp\"")
        : Text::lit("#include \"elem.decl.hpp\"");
    auto includes_p7 = crate::syntax::lexer::chars::join_f(crate::prelude::filter(Array(std::vector{includes_f(Text::lit("decl"), members_p1), elem_p6, includes_f(Text::lit("decl"), declared_p2), includes_f(Text::lit("types"), complete_p3)}), [&](const Text& t_pd) { return t_pd != Text::lit(""); }), Text::lit("\n"));
    auto p_p4x = p_p4;
    auto title_p0x = title_p0;
    return crate::prelude::call_then(start_order_values_f(prism_rtl::deref(p_p4x).values_p, crate::prelude::fold(prism_rtl::deref(p_p4x).values_p, Map<Text, bool>{}, [&](const Map<Text, bool>& acc_pe, const crate::emit::cpp::items::ValueDecl& v_pf) { return crate::prelude::insert(acc_pe, prism_rtl::deref(v_pf).path_p, false); }), Array<Text>{}), [=](Array<Text> order_values_f_16279) {
        return ({
            auto values_p8 = crate::syntax::lexer::chars::join_f(order_values_f_16279, Text::lit("\n\n"));
            (prism_rtl::finished(crate::emit::cpp::templates::cpp_types_header_f(title_p0x, includes_p7, values_p8)));
        });
    });
}


/// `Start TypesHeader, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_types_header_f(Text title_p0, Array<Text> members_p1, Array<Text> declared_p2, Array<Text> complete_p3, crate::emit::cpp::items::Parts p_p4) {
    return prism_rtl::make_rc<TypesHeader>(title_p0, members_p1, declared_p2, complete_p3, p_p4);
}


/// Includes: fn Text, [Text] -> Text
Text includes_f(const Text& layer_p0, const Array<Text>& ms_p1) {
    return crate::syntax::lexer::chars::join_f(crate::prelude::each(ms_p1, [&](const Text& m_p2) { return prism_rtl::cat("#include <", mod_dir_f(m_p2), "/", layer_p0 == Text::lit("") ? Text::lit("module") : layer_p0, ".hpp>"); }), Text::lit("\n"));
}


/// Chunks: fn [Text] -> [ [Text] ]
Array<Array<Text>> chunks_f(const Array<Text>& defs_p0) {
    auto [done_p5, current_p6, size_p7] = crate::prelude::fold(defs_p0, std::tuple{Array<Array<Text>>{}, Array<Text>{}, Nat(0u)}, [&](const std::tuple<Array<Array<Text>>, Array<Text>, Nat>& _p0, const Text& d_p4) {
        auto&& acc_p1 = std::get<0>(_p0);
        auto&& cur_p2 = std::get<1>(_p0);
        auto&& n_p3 = std::get<2>(_p0);
        return (n_p3 > chunk_size_p()) && (crate::prelude::len(cur_p2) > Nat(0u))
            ? std::tuple{crate::prelude::push(acc_p1, cur_p2), Array(std::vector{d_p4}), crate::prelude::len_text(d_p4)}
            : std::tuple{acc_p1, crate::prelude::push(cur_p2, d_p4), n_p3 + crate::prelude::len_text(d_p4)};
    });
    return (crate::prelude::len(current_p6) == Nat(0u)) && (crate::prelude::len(done_p5) > Nat(0u))
        ? done_p5
        : crate::prelude::push(done_p5, current_p6);
}


/// let chunkSize
Nat chunk_size_p() {
    return Nat(250000u);
}


/// ModuleFiles: unbounded fn ModDef, Parts -> (([((Text, Text))], [Piece]))
std::tuple<Array<std::tuple<Text, Text>>, Array<Piece>> module_files_f(const crate::lower::model::ModDef& m_p0, const crate::emit::cpp::items::Parts& p_p1) {
    auto title_p2 = m_p0.prism_p == Text::lit("")
        ? Text::lit("The root module")
        : prism_rtl::cat("The module `", m_p0.prism_p, "`");
    auto needed_p3 = crate::prelude::append(m_p0.complete_p, m_p0.declared_p);
    auto decl_p4 = crate::emit::cpp::templates::cpp_decl_header_f(title_p2, Text::lit(""), crate::syntax::lexer::chars::join_f(p_p1.forward_p, Text::lit("\n\n")));
    auto types_p5 = crate::prelude::len(m_p0.types_with_p) > Nat(1u)
        ? crate::emit::cpp::templates::cpp_types_in_group_f(title_p2, group_name_f(m_p0.types_with_p))
        : types_header_f(title_p2, Array(std::vector{m_p0.name_p}), m_p0.declared_p, m_p0.complete_p, p_p1);
    auto head_includes_p6 = crate::syntax::lexer::chars::join_f(crate::prelude::filter(Array(std::vector{prism_rtl::cat(includes_f(Text::lit("types"), Array(std::vector{m_p0.name_p})), "\n#include \"elem.types.hpp\""), includes_f(Text::lit("types"), needed_p3)}), [&](const Text& t_pd) { return t_pd != Text::lit(""); }), Text::lit("\n"));
    auto head_p7 = crate::emit::cpp::templates::cpp_mod_header_f(title_p2, head_includes_p6, crate::syntax::lexer::chars::join_f(p_p1.protos_p, Text::lit("\n")), crate::syntax::lexer::chars::join_f(p_p1.outer_p, Text::lit("\n\n")), crate::syntax::lexer::chars::join_f(p_p1.classes_p, Text::lit("\n\n")));
    auto with_mine_p8 = crate::prelude::append(Array(std::vector{m_p0.name_p}), needed_p3);
    auto generic_p9 = crate::prelude::len(p_p1.generic_p) == Nat(0u)
        ? Array<std::tuple<Text, Text>>{}
        : Array(std::vector{std::tuple{prism_rtl::cat("src/", mod_dir_f(m_p0.name_p), "/generic.hpp"), crate::emit::cpp::templates::cpp_generic_header_f(title_p2, includes_f(Text::lit(""), with_mine_p8), crate::syntax::lexer::chars::join_f(p_p1.generic_p, Text::lit("\n\n")))}});
    auto chunks_pa = crate::prelude::len(p_p1.defs_p) == Nat(0u)
        ? Array<Array<Text>>{}
        : chunks_f(p_p1.defs_p);
    auto pieces_pb = crate::prelude::each(chunks_pa, [&](const Array<Text>& c_pe) { return Piece{.title_p = title_p2, .prism_p = m_p0.prism_p, .path_p = m_p0.path_p, .ns_p = m_p0.name_p, .needs_p = with_mine_p8, .defs_p = crate::syntax::lexer::chars::join_f(c_pe, Text::lit("\n\n"))}; });
    auto dir_pc = mod_dir_f(m_p0.name_p);
    return std::tuple{crate::prelude::append(Array(std::vector{std::tuple{prism_rtl::cat("src/", dir_pc, "/decl.hpp"), decl_p4}, std::tuple{prism_rtl::cat("src/", dir_pc, "/types.hpp"), types_p5}, std::tuple{prism_rtl::cat("src/", dir_pc, "/module.hpp"), head_p7}}), generic_p9), pieces_pb};
}


prism_rtl::Turn<std::tuple<Array<std::tuple<Text, Text>>, Array<Piece>>> ModuleFiles::cycle() const {
    const auto& m_p0 = this->m_p0;
    const auto& p_p1 = this->p_p1;
    auto title_p2 = prism_rtl::deref(m_p0).prism_p == Text::lit("")
        ? Text::lit("The root module")
        : prism_rtl::cat("The module `", prism_rtl::deref(m_p0).prism_p, "`");
    auto needed_p3 = crate::prelude::append(prism_rtl::deref(m_p0).complete_p, prism_rtl::deref(m_p0).declared_p);
    auto decl_p4 = crate::emit::cpp::templates::cpp_decl_header_f(title_p2, Text::lit(""), crate::syntax::lexer::chars::join_f(prism_rtl::deref(p_p1).forward_p, Text::lit("\n\n")));
    auto types_p5 = crate::prelude::len(prism_rtl::deref(m_p0).types_with_p) > Nat(1u)
        ? crate::emit::cpp::templates::cpp_types_in_group_f(title_p2, group_name_f(prism_rtl::deref(m_p0).types_with_p))
        : types_header_f(title_p2, Array(std::vector{prism_rtl::deref(m_p0).name_p}), prism_rtl::deref(m_p0).declared_p, prism_rtl::deref(m_p0).complete_p, p_p1);
    auto head_includes_p6 = crate::syntax::lexer::chars::join_f(crate::prelude::filter(Array(std::vector{prism_rtl::cat(includes_f(Text::lit("types"), Array(std::vector{prism_rtl::deref(m_p0).name_p})), "\n#include \"elem.types.hpp\""), includes_f(Text::lit("types"), needed_p3)}), [&](const Text& t_pd) { return t_pd != Text::lit(""); }), Text::lit("\n"));
    auto head_p7 = crate::emit::cpp::templates::cpp_mod_header_f(title_p2, head_includes_p6, crate::syntax::lexer::chars::join_f(prism_rtl::deref(p_p1).protos_p, Text::lit("\n")), crate::syntax::lexer::chars::join_f(prism_rtl::deref(p_p1).outer_p, Text::lit("\n\n")), crate::syntax::lexer::chars::join_f(prism_rtl::deref(p_p1).classes_p, Text::lit("\n\n")));
    auto with_mine_p8 = crate::prelude::append(Array(std::vector{prism_rtl::deref(m_p0).name_p}), needed_p3);
    auto generic_p9 = crate::prelude::len(prism_rtl::deref(p_p1).generic_p) == Nat(0u)
        ? Array<std::tuple<Text, Text>>{}
        : Array(std::vector{std::tuple{prism_rtl::cat("src/", mod_dir_f(prism_rtl::deref(m_p0).name_p), "/generic.hpp"), crate::emit::cpp::templates::cpp_generic_header_f(title_p2, includes_f(Text::lit(""), with_mine_p8), crate::syntax::lexer::chars::join_f(prism_rtl::deref(p_p1).generic_p, Text::lit("\n\n")))}});
    auto chunks_pa = crate::prelude::len(prism_rtl::deref(p_p1).defs_p) == Nat(0u)
        ? Array<Array<Text>>{}
        : chunks_f(prism_rtl::deref(p_p1).defs_p);
    auto pieces_pb = crate::prelude::each(chunks_pa, [&](const Array<Text>& c_pe) { return Piece{.title_p = title_p2, .prism_p = prism_rtl::deref(m_p0).prism_p, .path_p = prism_rtl::deref(m_p0).path_p, .ns_p = prism_rtl::deref(m_p0).name_p, .needs_p = with_mine_p8, .defs_p = crate::syntax::lexer::chars::join_f(c_pe, Text::lit("\n\n"))}; });
    auto dir_pc = mod_dir_f(prism_rtl::deref(m_p0).name_p);
    return prism_rtl::finished(std::tuple{crate::prelude::append(Array(std::vector{std::tuple{prism_rtl::cat("src/", dir_pc, "/decl.hpp"), decl_p4}, std::tuple{prism_rtl::cat("src/", dir_pc, "/types.hpp"), types_p5}, std::tuple{prism_rtl::cat("src/", dir_pc, "/module.hpp"), head_p7}}), generic_p9), pieces_pb});
}


/// `Start ModuleFiles, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, Text>>, Array<Piece>>> start_module_files_f(crate::lower::model::ModDef m_p0, crate::emit::cpp::items::Parts p_p1) {
    return prism_rtl::make_rc<ModuleFiles>(m_p0, p_p1);
}


/// Units: fn [Piece] -> [ [Piece] ]
Array<Array<Piece>> units_f(const Array<Piece>& pieces_p0) {
    auto [done_p5, current_p6, size_p7] = crate::prelude::fold(pieces_p0, std::tuple{Array<Array<Piece>>{}, Array<Piece>{}, Nat(0u)}, [&](const std::tuple<Array<Array<Piece>>, Array<Piece>, Nat>& _p0, const Piece& pc_p4) {
        auto&& acc_p1 = std::get<0>(_p0);
        auto&& cur_p2 = std::get<1>(_p0);
        auto&& n_p3 = std::get<2>(_p0);
        return (crate::prelude::len(cur_p2) > Nat(0u)) && ((n_p3 + crate::prelude::len_text(prism_rtl::deref(pc_p4).defs_p)) > unit_size_p())
            ? std::tuple{crate::prelude::push(acc_p1, cur_p2), Array(std::vector{pc_p4}), crate::prelude::len_text(prism_rtl::deref(pc_p4).defs_p)}
            : std::tuple{acc_p1, crate::prelude::push(cur_p2, pc_p4), n_p3 + crate::prelude::len_text(prism_rtl::deref(pc_p4).defs_p)};
    });
    return crate::prelude::len(current_p6) == Nat(0u)
        ? done_p5
        : crate::prelude::push(done_p5, current_p6);
}


/// let unitSize
Nat unit_size_p() {
    return Nat(125000u);
}


/// UnitFile: fn Nat, [Piece], [Text] -> ((Text, Text))
std::tuple<Text, Text> unit_file_f(const Nat& k_p0, const Array<Piece>& pieces_p1, const Array<Text>& generics_p2) {
    auto needs_p3 = crate::prelude::fold(pieces_p1, Array<Text>{}, [&](const Array<Text>& acc_p8, const Piece& pc_p9) { return crate::prelude::fold(prism_rtl::deref(pc_p9).needs_p, acc_p8, [&](const Array<Text>& a_pa, const Text& n_pb) { return among_f(a_pa, n_pb) ? a_pa : crate::prelude::push(a_pa, n_pb); }); });
    auto includes_p4 = crate::syntax::lexer::chars::join_f(crate::prelude::filter(Array(std::vector{includes_f(Text::lit(""), needs_p3), includes_f(Text::lit("generic"), crate::prelude::filter(needs_p3, [&](const Text& n_pc) { return among_f(generics_p2, n_pc); }))}), [&](const Text& t_pd) { return t_pd != Text::lit(""); }), Text::lit("\n"));
    auto names_p5 = crate::prelude::fold(pieces_p1, Array<Text>{}, [&](const Array<Text>& acc_pe, const Piece& pc_pf) {
        return among_f(acc_pe, prism_rtl::deref(pc_pf).prism_p)
            ? acc_pe
            : crate::prelude::push(acc_pe, prism_rtl::deref(pc_pf).prism_p);
    });
    auto title_p6 = crate::prelude::len(names_p5) == Nat(1u)
        ? prism_rtl::deref(crate::prelude::or_(crate::prelude::index(pieces_p1, Nat(0u)), dummy_piece_p())).title_p
        : prism_rtl::cat("The modules ", crate::syntax::lexer::chars::join_f(crate::prelude::each(names_p5, [&](const Text& n_pg) {
        return n_pg == Text::lit("")
            ? Text::lit("the root")
            : prism_rtl::cat("`", n_pg, "`");
    }), Text::lit(", ")));
    auto parts_p7 = crate::syntax::lexer::chars::join_f(crate::prelude::each(pieces_p1, [&](const Piece& pc_ph) { return crate::emit::cpp::templates::cpp_unit_part_f(prism_rtl::deref(pc_ph).title_p, prism_rtl::deref(pc_ph).path_p, prism_rtl::deref(pc_ph).ns_p, prism_rtl::deref(pc_ph).defs_p); }), Text::lit("\n\n"));
    return std::tuple{prism_rtl::cat("src/unit_", k_p0 + Nat(1u), ".cpp"), crate::emit::cpp::templates::cpp_unit_f(title_p6, includes_p4, parts_p7)};
}


/// let dummyPiece
Piece dummy_piece_p() {
    return Piece{.title_p = Text::lit(""), .prism_p = Text::lit(""), .path_p = Text::lit(""), .ns_p = Text::lit(""), .needs_p = Array<Text>{}, .defs_p = Text::lit("")};
}


/// AllProgramsCpp: fn Model -> [ProgDef]
Array<crate::lower::model::ProgDef> all_programs_cpp_f(const crate::lower::model::Model& model_p0) {
    auto&& _m = model_p0.root_o;
    if (prism_rtl::is_some(_m)) {
        auto&& r_p1 = prism_rtl::some_of(_m);
        return crate::prelude::fold(model_p0.programs_p, false, [&](const bool& f_p2, const crate::lower::model::ProgDef& p_p3) { return prism_rtl::deref(f_p2) || (prism_rtl::deref(p_p3).name_p == prism_rtl::deref(r_p1).name_p); })
            ? model_p0.programs_p
            : crate::prelude::push(model_p0.programs_p, r_p1);
    }
    if (prism_rtl::is_none(_m)) {
        return model_p0.programs_p;
    }
    prism_rtl::unreachable("no arm matched");
}


/// OrderValues: unbounded fn [ValueDecl], (Text ==> Bool), [Text] -> [Text]
Array<Text> order_values_f(const Array<crate::emit::cpp::items::ValueDecl>& left_p0, const Map<Text, bool>& done_p1, const Array<Text>& acc_p2) {
    auto ready_p3 = crate::prelude::filter(left_p0, [&](const crate::emit::cpp::items::ValueDecl& v_p4) { return crate::prelude::fold(prism_rtl::deref(v_p4).deps_p, true, [&](const bool& ok_p5, const Text& d_p6) { return prism_rtl::deref(ok_p5) && ((d_p6 == prism_rtl::deref(v_p4).path_p) || declared_f(done_p1, d_p6)); }); });
    return crate::prelude::len(left_p0) == Nat(0u)
        ? acc_p2
        : crate::prelude::len(ready_p3) == Nat(0u)
        ? crate::prelude::append(acc_p2, crate::prelude::each(left_p0, [&](const crate::emit::cpp::items::ValueDecl& v_p7) { return prism_rtl::deref(v_p7).text_p; }))
        : ({
        auto later_p8 = crate::prelude::filter(left_p0, [&](const crate::emit::cpp::items::ValueDecl& v_pa) { return !crate::prelude::fold(prism_rtl::deref(v_pa).deps_p, true, [&](const bool& ok_pb, const Text& d_pc) { return prism_rtl::deref(ok_pb) && ((d_pc == prism_rtl::deref(v_pa).path_p) || declared_f(done_p1, d_pc)); }); });
        auto done2_p9 = crate::prelude::fold(ready_p3, done_p1, [&](const Map<Text, bool>& m_pd, const crate::emit::cpp::items::ValueDecl& v_pe) { return crate::prelude::insert(m_pd, prism_rtl::deref(v_pe).path_p, true); });
        order_values_f(later_p8, done2_p9, crate::prelude::append(acc_p2, crate::prelude::each(ready_p3, [&](const crate::emit::cpp::items::ValueDecl& v_pf) { return prism_rtl::deref(v_pf).text_p; })));
    });
}


prism_rtl::Turn<Array<Text>> OrderValues::cycle() const {
    const auto& left_p0 = this->left_p0;
    const auto& done_p1 = this->done_p1;
    const auto& acc_p2 = this->acc_p2;
    auto ready_p3 = crate::prelude::filter(left_p0, [&](const crate::emit::cpp::items::ValueDecl& v_p4) { return crate::prelude::fold(prism_rtl::deref(v_p4).deps_p, true, [&](const bool& ok_p5, const Text& d_p6) { return prism_rtl::deref(ok_p5) && ((d_p6 == prism_rtl::deref(v_p4).path_p) || declared_f(done_p1, d_p6)); }); });
    return crate::prelude::len(left_p0) == Nat(0u)
        ? prism_rtl::finished(acc_p2)
        : crate::prelude::len(ready_p3) == Nat(0u)
        ? prism_rtl::finished(crate::prelude::append(acc_p2, crate::prelude::each(left_p0, [&](const crate::emit::cpp::items::ValueDecl& v_p7) { return prism_rtl::deref(v_p7).text_p; })))
        : ({
        auto later_p8 = crate::prelude::filter(left_p0, [&](const crate::emit::cpp::items::ValueDecl& v_pa) { return !crate::prelude::fold(prism_rtl::deref(v_pa).deps_p, true, [&](const bool& ok_pb, const Text& d_pc) { return prism_rtl::deref(ok_pb) && ((d_pc == prism_rtl::deref(v_pa).path_p) || declared_f(done_p1, d_pc)); }); });
        auto done2_p9 = crate::prelude::fold(ready_p3, done_p1, [&](const Map<Text, bool>& m_pd, const crate::emit::cpp::items::ValueDecl& v_pe) { return crate::prelude::insert(m_pd, prism_rtl::deref(v_pe).path_p, true); });
        (prism_rtl::more(prism_rtl::rc(OrderValues(later_p8, done2_p9, crate::prelude::append(acc_p2, crate::prelude::each(ready_p3, [&](const crate::emit::cpp::items::ValueDecl& v_pf) { return prism_rtl::deref(v_pf).text_p; }))))));
    });
}


/// `Start OrderValues, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_order_values_f(Array<crate::emit::cpp::items::ValueDecl> left_p0, Map<Text, bool> done_p1, Array<Text> acc_p2) {
    return prism_rtl::make_rc<OrderValues>(left_p0, done_p1, acc_p2);
}


/// Declared: fn (Text ==> Bool), Text -> Bool
bool declared_f(const Map<Text, bool>& done_p0, const Text& d_p1) {
    auto&& _m = crate::prelude::get(done_p0, d_p1);
    if (prism_rtl::is_some(_m)) {
        auto&& b_p2 = prism_rtl::some_of(_m);
        return b_p2;
    }
    if (prism_rtl::is_none(_m)) {
        return true;
    }
    prism_rtl::unreachable("no arm matched");
}

}  // namespace crate::emit::cpp::program
