// The module `Syntax.Parser.Expr`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Syntax.Parser.Expr`, from `target/bootstrap/cpp-src/prismc/syntax/parser/expr.prism`.
namespace crate::syntax::parser::expr {

void ArgsRead::show(Printer& p) const {
    p.record("ArgsRead", {{"args", args}, {"rest", rest}, {"p", p_}, {"going", going}});
}

Pod ArgsRead::to_pod() const {
    return Pod::record("ArgsRead", {{"args", prism_rtl::to_pod(args)}, {"rest", prism_rtl::to_pod(rest)}, {"p", prism_rtl::to_pod(p_)}, {"going", prism_rtl::to_pod(going)}});
}

Result<ArgsRead> ArgsRead::from_pod(const Pod& whole) {
    return ArgsRead{.args = TRY(prism_rtl::from_pod<Array<crate::syntax::Arg>>(TRY(crate::prelude::field(whole, "args")))), .rest = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "rest")))), .p_ = TRY(prism_rtl::from_pod<crate::syntax::parser::Ps>(TRY(crate::prelude::field(whole, "p")))), .going = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "going"))))};
}


void Climb::show(Printer& p) const {
    p.record("Climb", {{"lhs", lhs}, {"p", p_}, {"going", going}});
}

Pod Climb::to_pod() const {
    return Pod::record("Climb", {{"lhs", prism_rtl::to_pod(lhs)}, {"p", prism_rtl::to_pod(p_)}, {"going", prism_rtl::to_pod(going)}});
}

Result<Climb> Climb::from_pod(const Pod& whole) {
    return Climb{.lhs = TRY(prism_rtl::from_pod<crate::syntax::Expr>(TRY(crate::prelude::field(whole, "lhs")))), .p_ = TRY(prism_rtl::from_pod<crate::syntax::parser::Ps>(TRY(crate::prelude::field(whole, "p")))), .going = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "going"))))};
}


/// ParseExpr: unbounded fn Ps -> ((Expr, Ps))
std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_expr(const crate::syntax::parser::Ps& p_) {
    return parse_expr_ctx(p_, true);
}


prism_rtl::Turn<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> ParseExpr::cycle() const {
    const auto& p_ = this->p_;
    return prism_rtl::more(prism_rtl::rc(ParseExprCtx(p_, true)));
}


/// `Start ParseExpr, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> start_parse_expr(crate::syntax::parser::Ps p_) {
    return prism_rtl::make_rc<ParseExpr>(p_);
}


/// ParseArgExpr: unbounded fn Ps -> ((Expr, Ps))
std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_arg_expr(const crate::syntax::parser::Ps& p_) {
    return parse_expr_ctx(p_, false);
}


prism_rtl::Turn<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> ParseArgExpr::cycle() const {
    const auto& p_ = this->p_;
    return prism_rtl::more(prism_rtl::rc(ParseExprCtx(p_, false)));
}


/// `Start ParseArgExpr, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> start_parse_arg_expr(crate::syntax::parser::Ps p_) {
    return prism_rtl::make_rc<ParseArgExpr>(p_);
}


/// ParseExprCtx: unbounded fn Ps, Bool -> ((Expr, Ps))
std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_expr_ctx(const crate::syntax::parser::Ps& p_, const bool& commas) {
    return parse_binary(p_, Nat(4u), commas && (!p_.step_mode));
}


prism_rtl::Turn<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> ParseExprCtx::cycle() const {
    const auto& p_ = this->p_;
    const auto& commas = this->commas;
    return prism_rtl::more(prism_rtl::rc(ParseBinary(p_, Nat(4u), commas && (!p_.step_mode))));
}


/// `Start ParseExprCtx, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> start_parse_expr_ctx(crate::syntax::parser::Ps p_, bool commas) {
    return prism_rtl::make_rc<ParseExprCtx>(p_, commas);
}


/// ParseRhsExpr: unbounded fn Ps -> ((Expr, Ps))
std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_rhs_expr(const crate::syntax::parser::Ps& p0) {
    std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> this_ = parse_expr(p0);
    auto [e0, p1] = this_;
    crate::syntax::Expr e = e0;
    crate::syntax::parser::Ps p_ = p1;
    while (at_line_method(p_)) {
        auto [method, p2] = crate::syntax::parser::parse_sname(crate::syntax::parser::adv(p_));
        auto [args, p3] = arg_starts_here(p2)
            ? parse_call_args(p2, true)
            : std::tuple{Array<crate::syntax::Arg>{}, p2};
        e = crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EMethod{prism_rtl::rc(e), method, args})), .span = crate::syntax::parser::to(e.span, crate::syntax::parser::prev(p3))};
        p_ = p3;
    }
    this_ = std::tuple{e, p_};
    return this_;
}


prism_rtl::Turn<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> ParseRhsExpr::cycle() const {
    const auto& p0 = this->p0;
    std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> this_ = parse_expr(p0);
    auto [e0, p1] = this_;
    crate::syntax::Expr e = e0;
    crate::syntax::parser::Ps p_ = p1;
    return call_then(loop_job(std::tuple{this_, e, p_}, [=](std::tuple<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>, crate::syntax::Expr, crate::syntax::parser::Ps> _p0) {
        auto this_ = std::get<0>(_p0);
        auto e = std::get<1>(_p0);
        auto p_ = std::get<2>(_p0);
        return at_line_method(p_)
            ? ({
            auto [method, p2] = crate::syntax::parser::parse_sname(crate::syntax::parser::adv(p_));
            auto [args, p3] = arg_starts_here(p2)
                ? parse_call_args(p2, true)
                : std::tuple{Array<crate::syntax::Arg>{}, p2};
            e = crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EMethod{prism_rtl::rc(e), method, args})), .span = crate::syntax::parser::to(e.span, crate::syntax::parser::prev(p3))};
            p_ = p3;
            Expected<std::tuple<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>, crate::syntax::Expr, crate::syntax::parser::Ps>, std::tuple<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>, crate::syntax::Expr, crate::syntax::parser::Ps>>(std::tuple{this_, e, p_});
        })
            : Expected<std::tuple<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>, crate::syntax::Expr, crate::syntax::parser::Ps>, std::tuple<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>, crate::syntax::Expr, crate::syntax::parser::Ps>>(unexpected(std::tuple{this_, e, p_}));
    }), [=](std::tuple<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>, crate::syntax::Expr, crate::syntax::parser::Ps> _p0) {
        auto this_ = std::get<0>(_p0);
        auto e = std::get<1>(_p0);
        auto p_ = std::get<2>(_p0);
        return ({
            this_ = std::tuple{e, p_};
            (prism_rtl::finished(this_));
        });
    });
}


/// `Start ParseRhsExpr, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> start_parse_rhs_expr(crate::syntax::parser::Ps p0) {
    return prism_rtl::make_rc<ParseRhsExpr>(p0);
}


/// AtLineMethod: fn Ps -> Bool
bool at_line_method(const crate::syntax::parser::Ps& p_) {
    return ((crate::syntax::parser::kind(p_) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KDot{true})) && crate::syntax::parser::tk(p_).line_start) && is_plain_upper(crate::syntax::parser::kind_at(p_, Nat(1u)));
}


/// IsPlainUpper: fn TokKind -> Bool
bool is_plain_upper(const crate::syntax::lexer::TokKind& tok_kind0) {
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(tok_kind0)) {
        auto&& n = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(tok_kind0).a0;
        return (n.case_ == crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseUpper{})) && (n.sigils == Text::lit(""));
    }
    {
        return false;
    }
}


/// IsUpperTok: fn TokKind -> Bool
bool is_upper_tok(const crate::syntax::lexer::TokKind& tok_kind0) {
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(tok_kind0)) {
        auto&& n = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(tok_kind0).a0;
        return n.case_ == crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseUpper{});
    }
    {
        return false;
    }
}


/// ?PeekBinop: fn Ps -> ?((Text, ?[Text]))
std::optional<std::tuple<Text, std::optional<Array<Text>>>> peek_binop(const crate::syntax::parser::Ps& p_) {
    auto&& _m = crate::syntax::parser::kind(p_);
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KOp>(_m)) {
        auto&& op = prism_rtl::as<crate::syntax::lexer::TokKind::KOp>(_m).a0;
        auto&& prefix = prism_rtl::as<crate::syntax::lexer::TokKind::KOp>(_m).a1;
        if ((!prefix) || (op == Text::lit("-?"))) {
            return is_binop(op)
                ? std::optional(std::tuple{op, std::optional<Array<Text>>{}})
                : std::optional<std::tuple<Text, std::optional<Array<Text>>>>{};
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KSuffixed>(_m)) {
        auto&& op = prism_rtl::as<crate::syntax::lexer::TokKind::KSuffixed>(_m).a0;
        auto&& ty = prism_rtl::as<crate::syntax::lexer::TokKind::KSuffixed>(_m).a1;
        return is_binop(op)
            ? std::optional(std::tuple{op, std::optional(ty)})
            : std::optional<std::tuple<Text, std::optional<Array<Text>>>>{};
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m2766_2_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m2766_2_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        if (m2766_2_0 == Text::lit("on")) {
            if (m2766_2_1 == Text::lit("")) {
                return std::optional(std::tuple{Text::lit("on"), std::optional<Array<Text>>{}});
            }
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m2766_3_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m2766_3_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        if (m2766_3_0 == Text::lit("or")) {
            if (m2766_3_1 == Text::lit("")) {
                return std::optional(std::tuple{Text::lit("or"), std::optional<Array<Text>>{}});
            }
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m2766_4_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m2766_4_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        if (m2766_4_0 == Text::lit("and")) {
            if (m2766_4_1 == Text::lit("")) {
                return std::optional(std::tuple{Text::lit("and"), std::optional<Array<Text>>{}});
            }
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m2766_5_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m2766_5_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        if (m2766_5_0 == Text::lit("mod")) {
            if (m2766_5_1 == Text::lit("")) {
                return std::optional(std::tuple{Text::lit("mod"), std::optional<Array<Text>>{}});
            }
        }
    }
    {
        return std::optional<std::tuple<Text, std::optional<Array<Text>>>>{};
    }
}


/// IsBinop: fn Text -> Bool
bool is_binop(const Text& op) {
    return fold(Array(std::vector{Text::lit("<|"), Text::lit("=="), Text::lit("!="), Text::lit("<"), Text::lit("<="), Text::lit(">"), Text::lit(">="), Text::lit("+"), Text::lit("-"), Text::lit("+?"), Text::lit("-?"), Text::lit("*"), Text::lit("/"), Text::lit("*?")}), false, [&](const bool& seen, const Text& o) { return seen || (o == op); });
}


/// Level: fn Text -> Nat
Nat level(const Text& text0) {
    {
        auto&& c0_0 = text0;
        if (c0_0 == Text::lit("<|")) {
            return Nat(4u);
        }
    }
    {
        auto&& c1_0 = text0;
        if (c1_0 == Text::lit("on")) {
            return Nat(5u);
        }
    }
    {
        auto&& c2_0 = text0;
        if (c2_0 == Text::lit("or")) {
            return Nat(6u);
        }
    }
    {
        auto&& c3_0 = text0;
        if (c3_0 == Text::lit("and")) {
            return Nat(7u);
        }
    }
    {
        auto&& c4_0 = text0;
        if (c4_0 == Text::lit("+")) {
            return Nat(10u);
        }
    }
    {
        auto&& c5_0 = text0;
        if (c5_0 == Text::lit("-")) {
            return Nat(10u);
        }
    }
    {
        auto&& c6_0 = text0;
        if (c6_0 == Text::lit("+?")) {
            return Nat(10u);
        }
    }
    {
        auto&& c7_0 = text0;
        if (c7_0 == Text::lit("-?")) {
            return Nat(10u);
        }
    }
    {
        auto&& c8_0 = text0;
        if (c8_0 == Text::lit("*")) {
            return Nat(11u);
        }
    }
    {
        auto&& c9_0 = text0;
        if (c9_0 == Text::lit("/")) {
            return Nat(11u);
        }
    }
    {
        auto&& c10_0 = text0;
        if (c10_0 == Text::lit("*?")) {
            return Nat(11u);
        }
    }
    {
        auto&& c11_0 = text0;
        if (c11_0 == Text::lit("mod")) {
            return Nat(11u);
        }
    }
    {
        return Nat(9u);
    }
}


/// ParseBinary: unbounded fn Ps, Nat, Bool -> ((Expr, Ps))
std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_binary(const crate::syntax::parser::Ps& p0, const Nat& min_, const bool& commas) {
    auto [lhs, p1] = parse_prefix(p0, min_, commas);
    auto r = ({
        Climb this_ = Climb{.lhs = lhs, .p_ = p1, .going = true};
        while (this_.going && (!this_.p_->bad)) {
            this_ = climb_step(this_, min_, commas);
        }
        this_;
    });
    return std::tuple{r.lhs, r.p_};
}


prism_rtl::Turn<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> ParseBinary::cycle() const {
    const auto& p0 = this->p0;
    const auto& min_ = this->min_;
    const auto& commas = this->commas;
    auto commas_1 = commas;
    auto min__2 = min_;
    auto p0_3 = p0;
    return call_then(start_parse_prefix(p0_3, min__2, commas_1), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_prefix_4034) {
        return ({
            auto [lhs, p1] = parse_prefix_4034;
            Climb this_ = Climb{.lhs = lhs, .p_ = p1, .going = true};
            auto lhs_4 = lhs;
            call_then(loop_job(std::tuple{this_}, ({
            auto commas_1_5 = commas_1;
            auto min__2_5 = min__2;
            [=](std::tuple<Climb> _p0) {
            auto this_ = std::get<0>(_p0);
            return this_.going && (!this_.p_->bad)
                ? ({
                this_ = climb_step(this_, min__2_5, commas_1_5);
                Expected<std::tuple<Climb>, std::tuple<Climb>>(std::tuple{this_});
            })
                : Expected<std::tuple<Climb>, std::tuple<Climb>>(unexpected(std::tuple{this_}));
        };
        })), [=](std::tuple<Climb> _p0) {
            auto this_ = std::get<0>(_p0);
            return ({
                auto r = this_;
                (prism_rtl::finished(std::tuple{r.lhs, r.p_}));
            });
        });
        });
    });
}


/// `Start ParseBinary, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> start_parse_binary(crate::syntax::parser::Ps p0, Nat min_, bool commas) {
    return prism_rtl::make_rc<ParseBinary>(p0, min_, commas);
}


/// ClimbStep: unbounded fn Climb, Nat, Bool -> Climb
Climb climb_step(const Climb& c, const Nat& min_, const bool& commas) {
    auto p_ = c.p_;
    return crate::syntax::parser::at_kw(p_, Text::lit("as")) && (min_ <= Nat(12u))
        ? ({
        auto [ty, p2] = crate::syntax::parser::types::parse_type(crate::syntax::parser::adv(p_));
        auto checked = (crate::syntax::parser::kind(p2) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KFree{Text::lit("?")})) && crate::syntax::parser::tk(p2).touches;
        auto p3 = checked ? crate::syntax::parser::adv(p2) : p2;
        ({
        Climb this_ = c;
        this_.lhs = crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ECast{prism_rtl::rc(this_.lhs), ty, checked})), .span = crate::syntax::parser::to(this_.lhs.span, crate::syntax::parser::prev(p3))};
        this_.p_ = p3;
        this_;
    });
    })
        : ({
        __label__ _done;
        prism_rtl::Slot<Climb> _v;
        auto&& _m = peek_binop(p_);
        if (prism_rtl::is_none(_m)) {
            _v.set(({
                Climb this_ = c;
                this_.going = false;
                this_.p_ = no_operator(p_);
                this_;
            }));
            goto _done;
        }
        if (prism_rtl::is_some(_m)) {
            auto&& op = std::get<0>(prism_rtl::some_of(_m));
            auto&& suffix_opt = std::get<1>(prism_rtl::some_of(_m));
            _v.set(level(op) < min_
                ? ({
                Climb this_ = c;
                this_.going = false;
                this_;
            })
                : ({
                auto p1 = crate::syntax::parser::kind(p_) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KOp{Text::lit("-?"), true})
                    ? crate::syntax::parser::note_error(p_, crate::syntax::parser::here(p_), Text::lit("`-?` is the checked subtraction by longest match; to subtract or negate an optional, write `-(?x)`"))
                    : p_;
                auto op_tok = crate::syntax::parser::tk(p1);
                auto [rhs, p2] = parse_binary(crate::syntax::parser::adv(p1), level(op) + Nat(1u), commas);
                auto span = crate::syntax::parser::to(c.lhs.span, rhs.span);
                auto kind = ({
                    __label__ _done;
                    prism_rtl::Slot<crate::syntax::ExprKind> _v;
                    if (prism_rtl::is_none(suffix_opt)) {
                        _v.set(crate::syntax::ExprKind(crate::syntax::ExprKind::EBinary{op, prism_rtl::rc(c.lhs), prism_rtl::rc(rhs)}));
                        goto _done;
                    }
                    if (prism_rtl::is_some(suffix_opt)) {
                        auto&& ty = prism_rtl::some_of(suffix_opt);
                        _v.set(crate::syntax::ExprKind(crate::syntax::ExprKind::ESuffixed{op, crate::syntax::QualName{.path_ = ty, .span = op_tok.span}, prism_rtl::rc(c.lhs), prism_rtl::rc(rhs)}));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                auto p3 = suffix_opt == std::optional<Array<Text>>{}
                    ? p2
                    : crate::syntax::parser::out_of_scope(p2, op_tok.span, Text::lit("suffixed operators"), prism_rtl::cat("the suffixed operator `", crate::syntax::lexer::corpus::token_text(op_tok.kind), "` is out of this compiler"));
                ({
                Climb this_ = c;
                this_.lhs = crate::syntax::Expr{.kind = prism_rtl::rc(kind), .span = span};
                this_.p_ = p3;
                this_;
            });
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Climb> ClimbStep::cycle() const {
    const auto& c = this->c;
    const auto& min_ = this->min_;
    const auto& commas = this->commas;
    auto p_ = c.p_;
    return crate::syntax::parser::at_kw(p_, Text::lit("as")) && (min_ <= Nat(12u))
        ? ({
        auto c_1 = c;
        call_then(crate::syntax::parser::types::start_parse_type(crate::syntax::parser::adv(p_)), [=](std::tuple<crate::syntax::Type, crate::syntax::parser::Ps> parse_type_4430) {
        return ({
            auto [ty, p2] = parse_type_4430;
            auto checked = (crate::syntax::parser::kind(p2) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KFree{Text::lit("?")})) && crate::syntax::parser::tk(p2).touches;
            auto p3 = checked ? crate::syntax::parser::adv(p2) : p2;
            (prism_rtl::finished(({
            Climb this_ = c_1;
            this_.lhs = crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ECast{prism_rtl::rc(this_.lhs), ty, checked})), .span = crate::syntax::parser::to(this_.lhs.span, crate::syntax::parser::prev(p3))};
            this_.p_ = p3;
            this_;
        })));
        });
    });
    })
        : ({
        auto&& _m = peek_binop(p_);
        prism_rtl::is_none(_m) ? prism_rtl::finished(({
        Climb this_ = c;
        this_.going = false;
        this_.p_ = no_operator(p_);
        this_;
    }))
        : prism_rtl::is_some(_m) ? ({
        auto&& op = std::get<0>(prism_rtl::some_of(_m));
        auto&& suffix_opt = std::get<1>(prism_rtl::some_of(_m));
        level(op) < min_
        ? prism_rtl::finished(({
        Climb this_ = c;
        this_.going = false;
        this_;
    }))
        : ({
        auto p1 = crate::syntax::parser::kind(p_) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KOp{Text::lit("-?"), true})
            ? crate::syntax::parser::note_error(p_, crate::syntax::parser::here(p_), Text::lit("`-?` is the checked subtraction by longest match; to subtract or negate an optional, write `-(?x)`"))
            : p_;
        auto op_tok = crate::syntax::parser::tk(p1);
        auto c_1 = c;
        auto commas_2 = commas;
        call_then(start_parse_binary(crate::syntax::parser::adv(p1), level(op) + Nat(1u), commas_2), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_binary_5342) {
        return ({
            auto [rhs, p2] = parse_binary_5342;
            auto span = crate::syntax::parser::to(c_1.lhs.span, rhs.span);
            auto kind = ({
                __label__ _done;
                prism_rtl::Slot<crate::syntax::ExprKind> _v;
                if (prism_rtl::is_none(suffix_opt)) {
                    _v.set(crate::syntax::ExprKind(crate::syntax::ExprKind::EBinary{op, prism_rtl::rc(c_1.lhs), prism_rtl::rc(rhs)}));
                    goto _done;
                }
                if (prism_rtl::is_some(suffix_opt)) {
                    auto&& ty = prism_rtl::some_of(suffix_opt);
                    _v.set(crate::syntax::ExprKind(crate::syntax::ExprKind::ESuffixed{op, crate::syntax::QualName{.path_ = ty, .span = op_tok.span}, prism_rtl::rc(c_1.lhs), prism_rtl::rc(rhs)}));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            auto p3 = suffix_opt == std::optional<Array<Text>>{}
                ? p2
                : crate::syntax::parser::out_of_scope(p2, op_tok.span, Text::lit("suffixed operators"), prism_rtl::cat("the suffixed operator `", crate::syntax::lexer::corpus::token_text(op_tok.kind), "` is out of this compiler"));
            (prism_rtl::finished(({
            Climb this_ = c_1;
            this_.lhs = crate::syntax::Expr{.kind = prism_rtl::rc(kind), .span = span};
            this_.p_ = p3;
            this_;
        })));
        });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ClimbStep, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Climb> start_climb_step(Climb c, Nat min_, bool commas) {
    return prism_rtl::make_rc<ClimbStep>(c, min_, commas);
}


/// NoOperator: fn Ps -> Ps
crate::syntax::parser::Ps no_operator(const crate::syntax::parser::Ps& p_) {
    auto&& _m = crate::syntax::parser::kind(p_);
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KOp>(_m) && prism_rtl::as<crate::syntax::lexer::TokKind::KOp>(_m).a1) {
        auto&& o = prism_rtl::as<crate::syntax::lexer::TokKind::KOp>(_m).a0;
        if (((o == Text::lit("-")) || (o == Text::lit("+"))) && (!crate::syntax::parser::tk(p_).line_start)) {
            return crate::syntax::parser::error_at(p_, crate::syntax::parser::here(p_), prism_rtl::cat("`", o, "` here is a prefix sign by the spacing rule (a space before it and none after); did you mean `a ", o, " 1`, with spaces on both sides?"));
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KBar>(_m)) {
        return crate::syntax::parser::error_at(p_, crate::syntax::parser::here(p_), Text::lit("a bare `|` is not an operator: the merge is `<|`, and `|` separates the families of a row"));
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KDot>(_m) && prism_rtl::as<crate::syntax::lexer::TokKind::KDot>(_m).a0) {
        if ((!at_line_method(p_)) && is_upper_tok(crate::syntax::parser::kind_at(p_, Nat(1u)))) {
            return crate::syntax::parser::error_at(p_, crate::syntax::parser::here(p_), Text::lit("a spaced `.Method` begins its own line, below the call it takes as its receiver (layout rule 9)"));
        }
    }
    {
        return p_;
    }
}


/// ParsePrefix: unbounded fn Ps, Nat, Bool -> ((Expr, Ps))
std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_prefix(const crate::syntax::parser::Ps& p_, const Nat& min_, const bool& commas) {
    auto start = crate::syntax::parser::here(p_);
    return crate::syntax::parser::at_kw(p_, Text::lit("not"))
        ? ({
        auto [operand, q] = parse_binary(crate::syntax::parser::adv(p_), crate::prelude::max(Nat(9u), min_), commas);
        std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EUnary{Text::lit("not"), prism_rtl::rc(operand)})), .span = crate::syntax::parser::to(start, operand.span)}, q};
    })
        : ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> _v;
        auto&& _m = crate::syntax::parser::kind(p_);
        if (prism_rtl::is<crate::syntax::lexer::TokKind::KOp>(_m) && prism_rtl::as<crate::syntax::lexer::TokKind::KOp>(_m).a1) {
            auto&& op = prism_rtl::as<crate::syntax::lexer::TokKind::KOp>(_m).a0;
            if ((op == Text::lit("-")) || (op == Text::lit("+"))) {
                _v.set(({
                    auto [operand, q] = parse_postfix_expr(crate::syntax::parser::adv(p_), commas);
                    auto name = op == Text::lit("-") ? Text::lit("neg") : Text::lit("pos");
                    std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EUnary{name, prism_rtl::rc(operand)})), .span = crate::syntax::parser::to(start, operand.span)}, q};
                }));
                goto _done;
            }
        }
        if (prism_rtl::is<crate::syntax::lexer::TokKind::KOp>(_m)) {
            auto&& m7135_1_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KOp>(_m).a0;
            if (m7135_1_0 == Text::lit("-?")) {
                _v.set(std::tuple{crate::syntax::parser::decls::no_expr(), crate::syntax::parser::error_at(p_, crate::syntax::parser::here(p_), Text::lit("`-?` is the checked subtraction and needs a left operand; to negate an optional write `-(?x)`"))});
                goto _done;
            }
        }
        {
            _v.set(parse_postfix_expr(p_, commas));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> ParsePrefix::cycle() const {
    const auto& p_ = this->p_;
    const auto& min_ = this->min_;
    const auto& commas = this->commas;
    auto start = crate::syntax::parser::here(p_);
    return crate::syntax::parser::at_kw(p_, Text::lit("not"))
        ? ({
        auto commas_1 = commas;
        auto min__2 = min_;
        auto p__3 = p_;
        call_then(start_parse_binary(crate::syntax::parser::adv(p__3), crate::prelude::max(Nat(9u), min__2), commas_1), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_binary_7002) {
        return ({
            auto [operand, q] = parse_binary_7002;
            (prism_rtl::finished(std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EUnary{Text::lit("not"), prism_rtl::rc(operand)})), .span = crate::syntax::parser::to(start, operand.span)}, q}));
        });
    });
    })
        : ({
        auto&& _m = crate::syntax::parser::kind(p_);
        prism_rtl::is<crate::syntax::lexer::TokKind::KOp>(_m) && prism_rtl::as<crate::syntax::lexer::TokKind::KOp>(_m).a1 && ({
        auto&& op = prism_rtl::as<crate::syntax::lexer::TokKind::KOp>(_m).a0;
        ((op == Text::lit("-")) || (op == Text::lit("+")));
    }) ? ({
        auto&& op = prism_rtl::as<crate::syntax::lexer::TokKind::KOp>(_m).a0;
        ({
        auto commas_1 = commas;
        auto p__2 = p_;
        call_then(start_parse_postfix_expr(crate::syntax::parser::adv(p__2), commas_1), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_postfix_expr_7230) {
        return ({
            auto [operand, q] = parse_postfix_expr_7230;
            auto name = op == Text::lit("-") ? Text::lit("neg") : Text::lit("pos");
            (prism_rtl::finished(std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EUnary{name, prism_rtl::rc(operand)})), .span = crate::syntax::parser::to(start, operand.span)}, q}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KOp>(_m) && ({
        auto&& m7135_1_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KOp>(_m).a0;
        (m7135_1_0 == Text::lit("-?"));
    }) ? ({
        auto&& m7135_1_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KOp>(_m).a0;
        prism_rtl::finished(std::tuple{crate::syntax::parser::decls::no_expr(), crate::syntax::parser::error_at(p_, crate::syntax::parser::here(p_), Text::lit("`-?` is the checked subtraction and needs a left operand; to negate an optional write `-(?x)`"))});
    })
        : prism_rtl::more(prism_rtl::rc(ParsePostfixExpr(p_, commas)));
    });
}


/// `Start ParsePrefix, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> start_parse_prefix(crate::syntax::parser::Ps p_, Nat min_, bool commas) {
    return prism_rtl::make_rc<ParsePrefix>(p_, min_, commas);
}


/// ParsePostfixExpr: unbounded fn Ps, Bool -> ((Expr, Ps))
std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_postfix_expr(const crate::syntax::parser::Ps& p_, const bool& commas) {
    auto [e, took_rest, q] = parse_primary(p_, commas);
    return took_rest ? std::tuple{e, q} : parse_postfix(e, q, commas);
}


prism_rtl::Turn<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> ParsePostfixExpr::cycle() const {
    const auto& p_ = this->p_;
    const auto& commas = this->commas;
    auto commas_1 = commas;
    auto p__2 = p_;
    return call_then(start_parse_primary(p__2, commas_1), [=](std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps> parse_primary_7837) {
        return ({
            auto [e, took_rest, q] = parse_primary_7837;
            took_rest
            ? prism_rtl::finished(std::tuple{e, q})
            : prism_rtl::more(prism_rtl::rc(ParsePostfix(e, q, commas_1)));
        });
    });
}


/// `Start ParsePostfixExpr, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> start_parse_postfix_expr(crate::syntax::parser::Ps p_, bool commas) {
    return prism_rtl::make_rc<ParsePostfixExpr>(p_, commas);
}


/// ParsePostfix: unbounded fn Expr, Ps, Bool -> ((Expr, Ps))
std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_postfix(const crate::syntax::Expr& e0, const crate::syntax::parser::Ps& p0, const bool& commas) {
    std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> this_ = std::tuple{e0, p0};
    crate::syntax::Expr e = e0;
    crate::syntax::parser::Ps p_ = p0;
    bool going = true;
    while (going && (!p_.bad)) {
        auto [e2, p2, more_] = postfix_step(e, p_, commas);
        e = e2;
        p_ = p2;
        going = more_;
    }
    this_ = std::tuple{e, p_};
    return this_;
}


prism_rtl::Turn<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> ParsePostfix::cycle() const {
    const auto& e0 = this->e0;
    const auto& p0 = this->p0;
    const auto& commas = this->commas;
    std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> this_ = std::tuple{e0, p0};
    crate::syntax::Expr e = e0;
    crate::syntax::parser::Ps p_ = p0;
    bool going = true;
    return call_then(loop_job(std::tuple{this_, e, going, p_}, ({
        auto commas_1 = commas;
        [=](std::tuple<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>, crate::syntax::Expr, bool, crate::syntax::parser::Ps> _p0) {
        auto this_ = std::get<0>(_p0);
        auto e = std::get<1>(_p0);
        auto going = std::get<2>(_p0);
        auto p_ = std::get<3>(_p0);
        return going && (!p_->bad)
            ? ({
            auto [e2, p2, more_] = postfix_step(e, p_, commas_1);
            e = e2;
            p_ = p2;
            going = more_;
            Expected<std::tuple<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>, crate::syntax::Expr, bool, crate::syntax::parser::Ps>, std::tuple<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>, crate::syntax::Expr, bool, crate::syntax::parser::Ps>>(std::tuple{this_, e, going, p_});
        })
            : Expected<std::tuple<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>, crate::syntax::Expr, bool, crate::syntax::parser::Ps>, std::tuple<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>, crate::syntax::Expr, bool, crate::syntax::parser::Ps>>(unexpected(std::tuple{this_, e, going, p_}));
    };
    })), [=](std::tuple<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>, crate::syntax::Expr, bool, crate::syntax::parser::Ps> _p0) {
        auto this_ = std::get<0>(_p0);
        auto e = std::get<1>(_p0);
        auto going = std::get<2>(_p0);
        auto p_ = std::get<3>(_p0);
        return ({
            this_ = std::tuple{e, p_};
            (prism_rtl::finished(this_));
        });
    });
}


/// `Start ParsePostfix, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> start_parse_postfix(crate::syntax::Expr e0, crate::syntax::parser::Ps p0, bool commas) {
    return prism_rtl::make_rc<ParsePostfix>(e0, p0, commas);
}


/// PostfixStep: unbounded fn Expr, Ps, Bool -> ((Expr, Ps, Bool))
std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps, bool> postfix_step(const crate::syntax::Expr& e, const crate::syntax::parser::Ps& p_, const bool& commas) {
    auto&& _m = crate::syntax::parser::kind(p_);
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KDot>(_m) && !prism_rtl::as<crate::syntax::lexer::TokKind::KDot>(_m).a0) {
        return field_or_method(e, p_, commas);
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KOpen>(_m) && !prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(_m).a1) {
        auto&& m8467_1_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(_m).a0;
        if (m8467_1_0 == Text::lit("[")) {
            if (crate::syntax::parser::tk(p_).touches && (!crate::syntax::parser::at_double_open(p_, Text::lit("[")))) {
                auto [index_, p1] = crate::syntax::parser::bracketed(crate::syntax::parser::adv(p_), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([&](crate::syntax::parser::Ps a0) { return entered(start_parse_expr(a0)); })));
                auto p2 = crate::syntax::parser::expect_close(p1, Text::lit("["));
                return std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EIndex{prism_rtl::rc(e), prism_rtl::rc(index_)})), .span = crate::syntax::parser::to(e.span, crate::syntax::parser::prev(p2))}, p2, true};
            }
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KLtLt>(_m)) {
        auto [types, q] = parse_type_args(p_);
        return std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ETypeArgs{prism_rtl::rc(e), types})), .span = crate::syntax::parser::to(e.span, crate::syntax::parser::prev(q))}, q, true};
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KNonEmpty>(_m)) {
        auto span = crate::syntax::parser::here(p_);
        auto q = crate::syntax::parser::out_of_scope(crate::syntax::parser::adv(p_), span, Text::lit("non-empty arrays"), Text::lit("the non-empty mark `+` is out of this compiler"));
        return std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ENonEmpty{prism_rtl::rc(e)})), .span = crate::syntax::parser::to(e.span, span)}, q, true};
    }
    {
        return std::tuple{e, p_, false};
    }
}


prism_rtl::Turn<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps, bool>> PostfixStep::cycle() const {
    const auto& e = this->e;
    const auto& p_ = this->p_;
    const auto& commas = this->commas;
    return ({
        auto&& _m = crate::syntax::parser::kind(p_);
        prism_rtl::is<crate::syntax::lexer::TokKind::KDot>(_m) && !prism_rtl::as<crate::syntax::lexer::TokKind::KDot>(_m).a0 ? prism_rtl::more(prism_rtl::rc(FieldOrMethod(e, p_, commas)))
        : prism_rtl::is<crate::syntax::lexer::TokKind::KOpen>(_m) && !prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(_m).a1 && ({
        auto&& m8467_1_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(_m).a0;
        (m8467_1_0 == Text::lit("[")) && (crate::syntax::parser::tk(p_).touches && (!crate::syntax::parser::at_double_open(p_, Text::lit("["))));
    }) ? ({
        auto&& m8467_1_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(_m).a0;
        ({
        auto e_1 = e;
        auto p__2 = p_;
        call_then(crate::syntax::parser::start_bracketed(crate::syntax::parser::adv(p__2), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([&](crate::syntax::parser::Ps a0) { return entered(start_parse_expr(a0)); }))), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> bracketed_8622) {
        return ({
            auto [index_, p1] = bracketed_8622;
            auto p2 = crate::syntax::parser::expect_close(p1, Text::lit("["));
            (prism_rtl::finished(std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EIndex{prism_rtl::rc(e_1), prism_rtl::rc(index_)})), .span = crate::syntax::parser::to(e_1.span, crate::syntax::parser::prev(p2))}, p2, true}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KLtLt>(_m) ? ({
        auto e_1 = e;
        auto p__2 = p_;
        call_then(start_parse_type_args(p__2), [=](std::tuple<Array<crate::syntax::Type>, crate::syntax::parser::Ps> parse_type_args_8806) {
        return ({
            auto [types, q] = parse_type_args_8806;
            (prism_rtl::finished(std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ETypeArgs{prism_rtl::rc(e_1), types})), .span = crate::syntax::parser::to(e_1.span, crate::syntax::parser::prev(q))}, q, true}));
        });
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KNonEmpty>(_m) ? ({
        auto span = crate::syntax::parser::here(p_);
        auto q = crate::syntax::parser::out_of_scope(crate::syntax::parser::adv(p_), span, Text::lit("non-empty arrays"), Text::lit("the non-empty mark `+` is out of this compiler"));
        (prism_rtl::finished(std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ENonEmpty{prism_rtl::rc(e)})), .span = crate::syntax::parser::to(e.span, span)}, q, true}));
    })
        : prism_rtl::finished(std::tuple{e, p_, false});
    });
}


/// `Start PostfixStep, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps, bool>> start_postfix_step(crate::syntax::Expr e, crate::syntax::parser::Ps p_, bool commas) {
    return prism_rtl::make_rc<PostfixStep>(e, p_, commas);
}


/// FieldOrMethod: unbounded fn Expr, Ps, Bool -> ((Expr, Ps, Bool))
std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps, bool> field_or_method(const crate::syntax::Expr& e, const crate::syntax::parser::Ps& p0, const bool& commas) {
    auto dot = crate::syntax::parser::here(p0);
    auto p_ = crate::syntax::parser::adv(p0);
    auto&& _m = crate::syntax::parser::kind(p_);
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        if ((len(n->path_) == Nat(1u)) && ((n.case_ == crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseLower{})) || (n.case_ == crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseTopic{})))) {
            auto t = crate::syntax::parser::here(p_);
            auto field_ = crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EField{prism_rtl::rc(e), n.sigils, crate::syntax::Ident{.name = or_(index(n->path_, Nat(0u)), Text::lit("")), .span = t}})), .span = crate::syntax::parser::to(e.span, t)};
            auto p1 = crate::syntax::parser::adv(p_);
            return arg_starts_here(p1) && (!crate::syntax::parser::tk(p1).line_start)
                ? ({
                auto [args, p2] = parse_call_args(p1, commas);
                std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ECall{prism_rtl::rc(field_), args, false, false})), .span = crate::syntax::parser::to(field_.span, crate::syntax::parser::prev(p2))}, p2, false};
            })
                : std::tuple{field_, p1, true};
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& w = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m9299_1_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        if (m9299_1_1 == Text::lit("")) {
            if (crate::syntax::lexer::is_bound_word(w)) {
                auto t = crate::syntax::parser::here(p_);
                return std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EField{prism_rtl::rc(e), Text::lit(""), crate::syntax::Ident{.name = w, .span = t}})), .span = crate::syntax::parser::to(e.span, t)}, crate::syntax::parser::adv(p_), true};
            }
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        if ((n.case_ == crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseUpper{})) || (n.case_ == crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseReserved{}))) {
            auto [method, p1] = crate::syntax::parser::parse_sname(p_);
            auto [args, p2] = arg_starts_here(p1)
                ? parse_call_args(p1, commas)
                : std::tuple{Array<crate::syntax::Arg>{}, p1};
            return std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EMethod{prism_rtl::rc(e), method, args})), .span = crate::syntax::parser::to(e.span, crate::syntax::parser::prev(p2))}, p2, false};
        }
    }
    {
        return std::tuple{e, crate::syntax::parser::error_at(p_, dot, Text::lit("expected a field name or a `.Method` after `.`")), false};
    }
}


prism_rtl::Turn<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps, bool>> FieldOrMethod::cycle() const {
    const auto& e = this->e;
    const auto& p0 = this->p0;
    const auto& commas = this->commas;
    auto dot = crate::syntax::parser::here(p0);
    auto p_ = crate::syntax::parser::adv(p0);
    return ({
        auto&& _m = crate::syntax::parser::kind(p_);
        prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m) && ({
        auto&& n = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        ((len(n->path_) == Nat(1u)) && ((n.case_ == crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseLower{})) || (n.case_ == crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseTopic{}))));
    }) ? ({
        auto&& n = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        ({
        auto t = crate::syntax::parser::here(p_);
        auto field_ = crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EField{prism_rtl::rc(e), n.sigils, crate::syntax::Ident{.name = or_(index(n->path_, Nat(0u)), Text::lit("")), .span = t}})), .span = crate::syntax::parser::to(e.span, t)};
        auto p1 = crate::syntax::parser::adv(p_);
        arg_starts_here(p1) && (!crate::syntax::parser::tk(p1).line_start)
        ? ({
        auto commas_1 = commas;
        call_then(start_parse_call_args(p1, commas_1), [=](std::tuple<Array<crate::syntax::Arg>, crate::syntax::parser::Ps> parse_call_args_9918) {
        return ({
            auto [args, p2] = parse_call_args_9918;
            (prism_rtl::finished(std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ECall{prism_rtl::rc(field_), args, false, false})), .span = crate::syntax::parser::to(field_.span, crate::syntax::parser::prev(p2))}, p2, false}));
        });
    });
    })
        : prism_rtl::finished(std::tuple{field_, p1, true});
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& w = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m9299_1_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        (m9299_1_1 == Text::lit("")) && crate::syntax::lexer::is_bound_word(w);
    }) ? ({
        auto&& w = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m9299_1_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        ({
        auto t = crate::syntax::parser::here(p_);
        (prism_rtl::finished(std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EField{prism_rtl::rc(e), Text::lit(""), crate::syntax::Ident{.name = w, .span = t}})), .span = crate::syntax::parser::to(e.span, t)}, crate::syntax::parser::adv(p_), true}));
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m) && ({
        auto&& n = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        ((n.case_ == crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseUpper{})) || (n.case_ == crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseReserved{})));
    }) ? ({
        auto&& n = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        ({
        auto [method, p1] = crate::syntax::parser::parse_sname(p_);
        auto [args, p2] = arg_starts_here(p1)
            ? parse_call_args(p1, commas)
            : std::tuple{Array<crate::syntax::Arg>{}, p1};
        (prism_rtl::finished(std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EMethod{prism_rtl::rc(e), method, args})), .span = crate::syntax::parser::to(e.span, crate::syntax::parser::prev(p2))}, p2, false}));
    });
    })
        : prism_rtl::finished(std::tuple{e, crate::syntax::parser::error_at(p_, dot, Text::lit("expected a field name or a `.Method` after `.`")), false});
    });
}


/// `Start FieldOrMethod, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps, bool>> start_field_or_method(crate::syntax::Expr e, crate::syntax::parser::Ps p0, bool commas) {
    return prism_rtl::make_rc<FieldOrMethod>(e, p0, commas);
}


/// ParseTypeArgs: unbounded fn Ps -> (([Type], Ps))
std::tuple<Array<crate::syntax::Type>, crate::syntax::parser::Ps> parse_type_args(const crate::syntax::parser::Ps& p_) {
    auto [types, q] = crate::syntax::parser::commas(crate::syntax::parser::adv(p_), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::Type, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([&](crate::syntax::parser::Ps a0) { return entered(crate::syntax::parser::types::start_parse_type(a0)); })));
    return crate::syntax::parser::kind(q) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KGtGt{})
        ? std::tuple{types, crate::syntax::parser::adv(q)}
        : std::tuple{types, crate::syntax::parser::error_here(q, Text::lit("expected `>>` to close the type arguments"))};
}


prism_rtl::Turn<std::tuple<Array<crate::syntax::Type>, crate::syntax::parser::Ps>> ParseTypeArgs::cycle() const {
    const auto& p_ = this->p_;
    auto p__1 = p_;
    return call_then(crate::syntax::parser::start_commas(crate::syntax::parser::adv(p__1), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::Type, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([&](crate::syntax::parser::Ps a0) { return entered(crate::syntax::parser::types::start_parse_type(a0)); }))), [=](std::tuple<Array<crate::syntax::Type>, crate::syntax::parser::Ps> commas_10908) {
        return ({
            auto [types, q] = commas_10908;
            (crate::syntax::parser::kind(q) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KGtGt{})
            ? prism_rtl::finished(std::tuple{types, crate::syntax::parser::adv(q)})
            : prism_rtl::finished(std::tuple{types, crate::syntax::parser::error_here(q, Text::lit("expected `>>` to close the type arguments"))}));
        });
    });
}


/// `Start ParseTypeArgs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::syntax::Type>, crate::syntax::parser::Ps>> start_parse_type_args(crate::syntax::parser::Ps p_) {
    return prism_rtl::make_rc<ParseTypeArgs>(p_);
}


/// ArgStartsHere: fn Ps -> Bool
bool arg_starts_here(const crate::syntax::parser::Ps& p_) {
    auto t = crate::syntax::parser::tk(p_);
    auto&& _m = t.kind;
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KInt>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KFloat>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KDuration>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KChar>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KText>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KRegex>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KTemplate>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KFree>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KLensDot>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KBackslash>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KAbsent>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KOpen>(_m)) {
        auto&& m11225_12_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(_m).a0;
        auto&& prefix = prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(_m).a1;
        if (m11225_12_0 == Text::lit("[")) {
            return (prefix || (!t.touches)) || crate::syntax::parser::at_double_open(p_, Text::lit("["));
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KOpen>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KOp>(_m) && prism_rtl::as<crate::syntax::lexer::TokKind::KOp>(_m).a1) {
        auto&& op = prism_rtl::as<crate::syntax::lexer::TokKind::KOp>(_m).a0;
        return (op == Text::lit("+")) || (op == Text::lit("-"));
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KDot>(_m) && prism_rtl::as<crate::syntax::lexer::TokKind::KDot>(_m).a0) {
        return !at_line_method(p_);
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& w = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        return fold(arg_words(), false, [&](const bool& seen, const Text& x) { return seen || (x == w); });
    }
    {
        return false;
    }
}


/// let argWords
Array<Text> arg_words() {
    return Array(std::vector{Text::lit("unit"), Text::lit("nil"), Text::lit("key"), Text::lit("ix"), Text::lit("jx"), Text::lit("kx"), Text::lit("not"), Text::lit("any"), Text::lit("given"), Text::lit("update"), Text::lit("match"), Text::lit("rebuild"), Text::lit("widget"), Text::lit("output"), Text::lit("inline_text"), Text::lit("raw")});
}


/// ParseCallArgs: unbounded fn Ps, Bool -> (([Arg], Ps))
std::tuple<Array<crate::syntax::Arg>, crate::syntax::parser::Ps> parse_call_args(const crate::syntax::parser::Ps& p_, const bool& commas) {
    return commas && (!p_.step_mode)
        ? crate::syntax::parser::commas(p_, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::Arg, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([&](crate::syntax::parser::Ps a0) { return entered(start_parse_arg(a0)); })))
        : parse_one_arg(p_);
}


prism_rtl::Turn<std::tuple<Array<crate::syntax::Arg>, crate::syntax::parser::Ps>> ParseCallArgs::cycle() const {
    const auto& p_ = this->p_;
    const auto& commas = this->commas;
    return commas && (!p_.step_mode)
        ? prism_rtl::more(prism_rtl::rc(crate::syntax::parser::Commas(p_, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::Arg, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([&](crate::syntax::parser::Ps a0) { return entered(start_parse_arg(a0)); })))))
        : prism_rtl::more(prism_rtl::rc(ParseOneArg(p_)));
}


/// `Start ParseCallArgs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::syntax::Arg>, crate::syntax::parser::Ps>> start_parse_call_args(crate::syntax::parser::Ps p_, bool commas) {
    return prism_rtl::make_rc<ParseCallArgs>(p_, commas);
}


/// ParseOneArg: unbounded fn Ps -> (([Arg], Ps))
std::tuple<Array<crate::syntax::Arg>, crate::syntax::parser::Ps> parse_one_arg(const crate::syntax::parser::Ps& p_) {
    auto [a, q] = parse_arg(p_);
    return std::tuple{Array(std::vector{a}), q};
}


prism_rtl::Turn<std::tuple<Array<crate::syntax::Arg>, crate::syntax::parser::Ps>> ParseOneArg::cycle() const {
    const auto& p_ = this->p_;
    auto p__1 = p_;
    return call_then(start_parse_arg(p__1), [=](std::tuple<crate::syntax::Arg, crate::syntax::parser::Ps> parse_arg_12477) {
        return ({
            auto [a, q] = parse_arg_12477;
            (prism_rtl::finished(std::tuple{Array(std::vector{a}), q}));
        });
    });
}


/// `Start ParseOneArg, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::syntax::Arg>, crate::syntax::parser::Ps>> start_parse_one_arg(crate::syntax::parser::Ps p_) {
    return prism_rtl::make_rc<ParseOneArg>(p_);
}


/// ParseArg: unbounded fn Ps -> ((Arg, Ps))
std::tuple<crate::syntax::Arg, crate::syntax::parser::Ps> parse_arg(const crate::syntax::parser::Ps& p_) {
    auto [value, q] = parse_arg_expr(p_);
    return std::tuple{crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = value, .span = value.span}, q};
}


prism_rtl::Turn<std::tuple<crate::syntax::Arg, crate::syntax::parser::Ps>> ParseArg::cycle() const {
    const auto& p_ = this->p_;
    auto p__1 = p_;
    return call_then(start_parse_arg_expr(p__1), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_arg_expr_12585) {
        return ({
            auto [value, q] = parse_arg_expr_12585;
            (prism_rtl::finished(std::tuple{crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = value, .span = value.span}, q}));
        });
    });
}


/// `Start ParseArg, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Arg, crate::syntax::parser::Ps>> start_parse_arg(crate::syntax::parser::Ps p_) {
    return prism_rtl::make_rc<ParseArg>(p_);
}


/// ParseParenArgs: unbounded fn Ps -> (([Arg], Bool, Ps))
std::tuple<Array<crate::syntax::Arg>, bool, crate::syntax::parser::Ps> parse_paren_args(const crate::syntax::parser::Ps& p0) {
    auto p_ = crate::syntax::parser::adv(p0);
    return crate::syntax::parser::at_close(p_, Text::lit("("))
        ? std::tuple{Array<crate::syntax::Arg>{}, false, crate::syntax::parser::adv(p_)}
        : ({
        auto r = ({
            ArgsRead this_ = ArgsRead{.args = Array<crate::syntax::Arg>{}, .rest = false, .p_ = p_, .going = true};
            while (this_.going && (!this_.p_->bad)) {
                if (crate::syntax::parser::kind(this_.p_) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KDotDot{})) {
                    this_.p_ = crate::syntax::parser::adv(this_.p_);
                    this_.rest = true;
                } else  {
                    auto start = crate::syntax::parser::here(this_.p_);
                    auto [name_opt, p1] = parse_arg_name(this_.p_);
                    auto [value, p2] = parse_arg_expr(p1);
                    this_.args = crate::prelude::push(this_.args, crate::syntax::Arg{.name = name_opt, .value = value, .span = crate::syntax::parser::to(start, value.span)});
                    this_.p_ = p2;
                }
                if (crate::syntax::parser::at_comma(this_.p_)) {
                    this_.p_ = crate::syntax::parser::adv(this_.p_);
                } else  {
                    this_.p_ = crate::syntax::parser::expect_close(this_.p_, Text::lit("("));
                    this_.going = false;
                }
            }
            this_;
        });
        std::tuple{r->args, r.rest, r.p_};
    });
}


prism_rtl::Turn<std::tuple<Array<crate::syntax::Arg>, bool, crate::syntax::parser::Ps>> ParseParenArgs::cycle() const {
    const auto& p0 = this->p0;
    auto p_ = crate::syntax::parser::adv(p0);
    return crate::syntax::parser::at_close(p_, Text::lit("("))
        ? prism_rtl::finished(std::tuple{Array<crate::syntax::Arg>{}, false, crate::syntax::parser::adv(p_)})
        : ({
        ArgsRead this_ = ArgsRead{.args = Array<crate::syntax::Arg>{}, .rest = false, .p_ = p_, .going = true};
        auto p__1 = p_;
        call_then(loop_job(std::tuple{this_}, ({
        auto p__1_2 = p__1;
        [=](std::tuple<ArgsRead> _p0) {
        auto this_ = std::get<0>(_p0);
        return this_.going && (!this_.p_->bad)
            ? ({
            if (crate::syntax::parser::kind(this_.p_) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KDotDot{})) {
                this_.p_ = crate::syntax::parser::adv(this_.p_);
                this_.rest = true;
            } else  {
                auto start = crate::syntax::parser::here(this_.p_);
                auto [name_opt, p1] = parse_arg_name(this_.p_);
                auto [value, p2] = parse_arg_expr(p1);
                this_->args = crate::prelude::push(this_->args, crate::syntax::Arg{.name = name_opt, .value = value, .span = crate::syntax::parser::to(start, value.span)});
                this_.p_ = p2;
            }
            if (crate::syntax::parser::at_comma(this_.p_)) {
                this_.p_ = crate::syntax::parser::adv(this_.p_);
            } else  {
                this_.p_ = crate::syntax::parser::expect_close(this_.p_, Text::lit("("));
                this_.going = false;
            }
            Expected<std::tuple<ArgsRead>, std::tuple<ArgsRead>>(std::tuple{this_});
        })
            : Expected<std::tuple<ArgsRead>, std::tuple<ArgsRead>>(unexpected(std::tuple{this_}));
    };
    })), [=](std::tuple<ArgsRead> _p0) {
        auto this_ = std::get<0>(_p0);
        return ({
            auto r = this_;
            (prism_rtl::finished(std::tuple{r->args, r.rest, r.p_}));
        });
    });
    });
}


/// `Start ParseParenArgs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::syntax::Arg>, bool, crate::syntax::parser::Ps>> start_parse_paren_args(crate::syntax::parser::Ps p0) {
    return prism_rtl::make_rc<ParseParenArgs>(p0);
}


/// ParseArgName: fn Ps -> ((?Ident, Ps))
std::tuple<std::optional<crate::syntax::Ident>, crate::syntax::parser::Ps> parse_arg_name(const crate::syntax::parser::Ps& p_) {
    auto&& _m = crate::syntax::parser::kind(p_);
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        if ((((n.sigils == Text::lit("")) && (len(n->path_) == Nat(1u))) && (n.case_ == crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseLower{}))) && crate::syntax::parser::at_op(crate::syntax::parser::adv(p_), Text::lit("="))) {
            return std::tuple{std::optional(crate::syntax::Ident{.name = or_(index(n->path_, Nat(0u)), Text::lit("")), .span = crate::syntax::parser::here(p_)}), crate::syntax::parser::adv(crate::syntax::parser::adv(p_))};
        }
    }
    {
        return std::tuple{std::optional<crate::syntax::Ident>{}, p_};
    }
}


/// ParsePrimary: unbounded fn Ps, Bool -> ((Expr, Bool, Ps))
std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps> parse_primary(const crate::syntax::parser::Ps& p_, const bool& commas) {
    auto start = crate::syntax::parser::here(p_);
    auto tok = crate::syntax::parser::tk(p_);
    auto&& _m = tok.kind;
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        return name_primary(p_, n, commas);
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& w = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& sigils = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        return keyword_primary(p_, w, sigils, commas);
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KInt>(_m)) {
        return literal_primary(p_);
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KFloat>(_m)) {
        return literal_primary(p_);
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KDuration>(_m)) {
        return literal_primary(p_);
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KChar>(_m)) {
        return literal_primary(p_);
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KText>(_m)) {
        return literal_primary(p_);
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KRegex>(_m)) {
        return literal_primary(p_);
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KTemplate>(_m)) {
        auto&& t = prism_rtl::as<crate::syntax::lexer::TokKind::KTemplate>(_m).a0;
        auto [tpl, q] = parse_template(crate::syntax::parser::adv(p_), t, tok.span);
        return std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ETemplate{tpl})), .span = tok.span}, false, q};
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KOpen>(_m)) {
        auto&& m14436_9_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(_m).a0;
        if (m14436_9_0 == Text::lit("(")) {
            return paren_primary(p_);
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KOpen>(_m)) {
        auto&& m14436_10_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(_m).a0;
        if (m14436_10_0 == Text::lit("[")) {
            return square_primary(p_);
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KOpen>(_m)) {
        return map_primary(p_);
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KDot>(_m) && prism_rtl::as<crate::syntax::lexer::TokKind::KDot>(_m).a0) {
        auto p1 = crate::syntax::parser::adv(p_);
        auto&& _m = crate::syntax::parser::kind(p1);
        if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m)) {
            auto&& n = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
            if (((n.sigils == Text::lit("")) && (len(n->path_) == Nat(1u))) && (n.case_ == crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseLower{}))) {
                auto t = crate::syntax::parser::here(p1);
                return std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ETopicField{crate::syntax::Ident{.name = or_(index(n->path_, Nat(0u)), Text::lit("")), .span = t}})), .span = crate::syntax::parser::to(start, t)}, false, crate::syntax::parser::adv(p1)};
            }
        }
        if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m)) {
            auto&& n = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
            if (n.case_ == crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseUpper{})) {
                return std::tuple{crate::syntax::parser::decls::no_expr(), false, crate::syntax::parser::error_at(p1, start, prism_rtl::cat("a spaced `.", crate::syntax::lexer::chars::join(n->path_, Text::lit(".")), "` begins its own line, below the call it takes as its receiver (layout rule 9)"))};
            }
        }
        {
            return std::tuple{crate::syntax::parser::decls::no_expr(), false, crate::syntax::parser::error_at(p1, start, Text::lit("a prefix `.` takes a field name, applied to the topic `_`"))};
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KLensDot>(_m)) {
        return lens_primary(p_);
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KFree>(_m)) {
        auto&& s = prism_rtl::as<crate::syntax::lexer::TokKind::KFree>(_m).a0;
        return s == Text::lit("!")
            ? std::tuple{crate::syntax::parser::decls::no_expr(), true, crate::syntax::parser::error_at(crate::syntax::parser::adv(p_), tok.span, Text::lit("`!` is never free: no event fires a constant"))}
            : s == Text::lit("&")
            ? std::tuple{crate::syntax::parser::decls::no_expr(), true, crate::syntax::parser::error_at(crate::syntax::parser::adv(p_), tok.span, Text::lit("`&` is never free: no reference exists outside the value an `update` block names"))}
            : ({
            auto [operand, q] = parse_expr_ctx(crate::syntax::parser::adv(p_), commas);
            std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EFreeSigil{s, prism_rtl::rc(operand)})), .span = crate::syntax::parser::to(start, operand.span)}, true, q};
        });
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KBackslash>(_m)) {
        auto [e, q] = parse_lambda(p_);
        return std::tuple{e, true, q};
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KAbsent>(_m)) {
        auto q = crate::syntax::parser::out_of_scope(crate::syntax::parser::adv(p_), tok.span, Text::lit("sparse tuples"), Text::lit("an absent component `-` makes a sparse tuple, which is out of this compiler"));
        return std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EAbsent{})), .span = tok.span}, false, q};
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KDotDot>(_m)) {
        return std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ERest{})), .span = tok.span}, false, crate::syntax::parser::adv(p_)};
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KTrait>(_m)) {
        return std::tuple{crate::syntax::parser::decls::no_expr(), false, crate::syntax::parser::error_at(p_, tok.span, Text::lit("no trait is a value: a `^Trait` stands in a type, a bound, `derive`, `trait` or `impl`"))};
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KFamily>(_m)) {
        auto&& path_ = prism_rtl::as<crate::syntax::lexer::TokKind::KFamily>(_m).a0;
        return std::tuple{crate::syntax::parser::decls::no_expr(), false, crate::syntax::parser::error_at(p_, tok.span, prism_rtl::cat("`", crate::syntax::lexer::chars::join(path_, Text::lit(".")), ".*` names every tag of a family: it stands in a pattern, an `emit` row or a `use`, not in an expression"))};
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KBar>(_m)) {
        return std::tuple{crate::syntax::parser::decls::no_expr(), false, crate::syntax::parser::error_at(p_, tok.span, Text::lit("a bare `|` is not an operator: the merge is `<|`, and `|` separates the families of a row"))};
    }
    {
        return std::tuple{crate::syntax::parser::decls::no_expr(), false, crate::syntax::parser::error_here(p_, Text::lit("expected an expression"))};
    }
}


prism_rtl::Turn<std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps>> ParsePrimary::cycle() const {
    const auto& p_ = this->p_;
    const auto& commas = this->commas;
    auto start = crate::syntax::parser::here(p_);
    auto tok = crate::syntax::parser::tk(p_);
    return ({
        auto&& _m = tok.kind;
        prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m) ? ({
        auto&& n = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        prism_rtl::more(prism_rtl::rc(NamePrimary(p_, n, commas)));
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) ? ({
        auto&& w = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& sigils = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        prism_rtl::more(prism_rtl::rc(KeywordPrimary(p_, w, sigils, commas)));
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KInt>(_m) ? prism_rtl::more(prism_rtl::rc(LiteralPrimary(p_)))
        : prism_rtl::is<crate::syntax::lexer::TokKind::KFloat>(_m) ? prism_rtl::more(prism_rtl::rc(LiteralPrimary(p_)))
        : prism_rtl::is<crate::syntax::lexer::TokKind::KDuration>(_m) ? prism_rtl::more(prism_rtl::rc(LiteralPrimary(p_)))
        : prism_rtl::is<crate::syntax::lexer::TokKind::KChar>(_m) ? prism_rtl::more(prism_rtl::rc(LiteralPrimary(p_)))
        : prism_rtl::is<crate::syntax::lexer::TokKind::KText>(_m) ? prism_rtl::more(prism_rtl::rc(LiteralPrimary(p_)))
        : prism_rtl::is<crate::syntax::lexer::TokKind::KRegex>(_m) ? prism_rtl::more(prism_rtl::rc(LiteralPrimary(p_)))
        : prism_rtl::is<crate::syntax::lexer::TokKind::KTemplate>(_m) ? ({
        auto&& t = prism_rtl::as<crate::syntax::lexer::TokKind::KTemplate>(_m).a0;
        ({
        auto p__1 = p_;
        auto t_2 = t;
        call_then(start_parse_template(crate::syntax::parser::adv(p__1), t_2, tok.span), [=](std::tuple<crate::syntax::Template, crate::syntax::parser::Ps> parse_template_14898) {
        return ({
            auto [tpl, q] = parse_template_14898;
            (prism_rtl::finished(std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ETemplate{tpl})), .span = tok.span}, false, q}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KOpen>(_m) && ({
        auto&& m14436_9_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(_m).a0;
        (m14436_9_0 == Text::lit("("));
    }) ? ({
        auto&& m14436_9_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(_m).a0;
        prism_rtl::more(prism_rtl::rc(ParenPrimary(p_)));
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KOpen>(_m) && ({
        auto&& m14436_10_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(_m).a0;
        (m14436_10_0 == Text::lit("["));
    }) ? ({
        auto&& m14436_10_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(_m).a0;
        prism_rtl::more(prism_rtl::rc(SquarePrimary(p_)));
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KOpen>(_m) ? prism_rtl::more(prism_rtl::rc(MapPrimary(p_)))
        : prism_rtl::is<crate::syntax::lexer::TokKind::KDot>(_m) && prism_rtl::as<crate::syntax::lexer::TokKind::KDot>(_m).a0 ? ({
        auto p1 = crate::syntax::parser::adv(p_);
        ({
        auto&& _m = crate::syntax::parser::kind(p1);
        prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m) && ({
        auto&& n = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        (((n.sigils == Text::lit("")) && (len(n->path_) == Nat(1u))) && (n.case_ == crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseLower{})));
    }) ? ({
        auto&& n = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        ({
        auto t = crate::syntax::parser::here(p1);
        (prism_rtl::finished(std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ETopicField{crate::syntax::Ident{.name = or_(index(n->path_, Nat(0u)), Text::lit("")), .span = t}})), .span = crate::syntax::parser::to(start, t)}, false, crate::syntax::parser::adv(p1)}));
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m) && ({
        auto&& n = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        (n.case_ == crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseUpper{}));
    }) ? ({
        auto&& n = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        prism_rtl::finished(std::tuple{crate::syntax::parser::decls::no_expr(), false, crate::syntax::parser::error_at(p1, start, prism_rtl::cat("a spaced `.", crate::syntax::lexer::chars::join(n->path_, Text::lit(".")), "` begins its own line, below the call it takes as its receiver (layout rule 9)"))});
    })
        : prism_rtl::finished(std::tuple{crate::syntax::parser::decls::no_expr(), false, crate::syntax::parser::error_at(p1, start, Text::lit("a prefix `.` takes a field name, applied to the topic `_`"))});
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KLensDot>(_m) ? prism_rtl::more(prism_rtl::rc(LensPrimary(p_)))
        : prism_rtl::is<crate::syntax::lexer::TokKind::KFree>(_m) ? ({
        auto&& s = prism_rtl::as<crate::syntax::lexer::TokKind::KFree>(_m).a0;
        s == Text::lit("!")
        ? prism_rtl::finished(std::tuple{crate::syntax::parser::decls::no_expr(), true, crate::syntax::parser::error_at(crate::syntax::parser::adv(p_), tok.span, Text::lit("`!` is never free: no event fires a constant"))})
        : s == Text::lit("&")
        ? prism_rtl::finished(std::tuple{crate::syntax::parser::decls::no_expr(), true, crate::syntax::parser::error_at(crate::syntax::parser::adv(p_), tok.span, Text::lit("`&` is never free: no reference exists outside the value an `update` block names"))})
        : ({
        auto commas_1 = commas;
        auto p__2 = p_;
        auto s_3 = s;
        call_then(start_parse_expr_ctx(crate::syntax::parser::adv(p__2), commas_1), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_expr_ctx_16414) {
        return ({
            auto [operand, q] = parse_expr_ctx_16414;
            (prism_rtl::finished(std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EFreeSigil{s_3, prism_rtl::rc(operand)})), .span = crate::syntax::parser::to(start, operand.span)}, true, q}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KBackslash>(_m) ? ({
        auto p__1 = p_;
        call_then(start_parse_lambda(p__1), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_lambda_16585) {
        return ({
            auto [e, q] = parse_lambda_16585;
            (prism_rtl::finished(std::tuple{e, true, q}));
        });
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KAbsent>(_m) ? ({
        auto q = crate::syntax::parser::out_of_scope(crate::syntax::parser::adv(p_), tok.span, Text::lit("sparse tuples"), Text::lit("an absent component `-` makes a sparse tuple, which is out of this compiler"));
        (prism_rtl::finished(std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EAbsent{})), .span = tok.span}, false, q}));
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KDotDot>(_m) ? prism_rtl::finished(std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ERest{})), .span = tok.span}, false, crate::syntax::parser::adv(p_)})
        : prism_rtl::is<crate::syntax::lexer::TokKind::KTrait>(_m) ? prism_rtl::finished(std::tuple{crate::syntax::parser::decls::no_expr(), false, crate::syntax::parser::error_at(p_, tok.span, Text::lit("no trait is a value: a `^Trait` stands in a type, a bound, `derive`, `trait` or `impl`"))})
        : prism_rtl::is<crate::syntax::lexer::TokKind::KFamily>(_m) ? ({
        auto&& path_ = prism_rtl::as<crate::syntax::lexer::TokKind::KFamily>(_m).a0;
        prism_rtl::finished(std::tuple{crate::syntax::parser::decls::no_expr(), false, crate::syntax::parser::error_at(p_, tok.span, prism_rtl::cat("`", crate::syntax::lexer::chars::join(path_, Text::lit(".")), ".*` names every tag of a family: it stands in a pattern, an `emit` row or a `use`, not in an expression"))});
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KBar>(_m) ? prism_rtl::finished(std::tuple{crate::syntax::parser::decls::no_expr(), false, crate::syntax::parser::error_at(p_, tok.span, Text::lit("a bare `|` is not an operator: the merge is `<|`, and `|` separates the families of a row"))})
        : prism_rtl::finished(std::tuple{crate::syntax::parser::decls::no_expr(), false, crate::syntax::parser::error_here(p_, Text::lit("expected an expression"))});
    });
}


/// `Start ParsePrimary, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps>> start_parse_primary(crate::syntax::parser::Ps p_, bool commas) {
    return prism_rtl::make_rc<ParsePrimary>(p_, commas);
}


/// LiteralPrimary: unbounded fn Ps -> ((Expr, Bool, Ps))
std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps> literal_primary(const crate::syntax::parser::Ps& p_) {
    auto [lit, q] = parse_literal(p_);
    return std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ELit{lit})), .span = lit.span}, false, q};
}


prism_rtl::Turn<std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps>> LiteralPrimary::cycle() const {
    const auto& p_ = this->p_;
    auto p__1 = p_;
    return call_then(start_parse_literal(p__1), [=](std::tuple<crate::syntax::Literal, crate::syntax::parser::Ps> parse_literal_17581) {
        return ({
            auto [lit, q] = parse_literal_17581;
            (prism_rtl::finished(std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ELit{lit})), .span = lit.span}, false, q}));
        });
    });
}


/// `Start LiteralPrimary, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps>> start_literal_primary(crate::syntax::parser::Ps p_) {
    return prism_rtl::make_rc<LiteralPrimary>(p_);
}


/// NamePrimary: unbounded fn Ps, NameTok, Bool -> ((Expr, Bool, Ps))
std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps> name_primary(const crate::syntax::parser::Ps& p0, const crate::syntax::lexer::NameTok& n, const bool& commas) {
    auto start = crate::syntax::parser::here(p0);
    auto name = crate::syntax::SName{.sigils = n.sigils, .path_ = n->path_, .span = start};
    auto p1 = crate::syntax::parser::check_name_scope(crate::syntax::parser::adv(p0), name);
    auto plain = crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EName{name})), .span = start};
    auto [e, p_] = crate::syntax::parser::kind(p1) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KLtLt{})
        ? type_args_on(plain, p1, start)
        : std::tuple{plain, p1};
    return crate::syntax::parser::is_callee(name)
        ? crate::syntax::parser::at_single_open(p_, Text::lit("(")) && crate::syntax::parser::tk(p_).touches
        ? ({
        auto [args, rest, q] = parse_paren_args(p_);
        std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ECall{prism_rtl::rc(e), args, true, rest})), .span = crate::syntax::parser::to(start, crate::syntax::parser::prev(q))}, false, q};
    })
        : crate::syntax::parser::at_kw(p_, Text::lit("monad"))
        ? ({
        auto kw = crate::syntax::parser::here(p_);
        auto [body, q] = crate::syntax::parser::blocks::parse_block_after_colon(crate::syntax::parser::out_of_scope(crate::syntax::parser::adv(p_), kw, Text::lit("`T monad:` blocks and `^Monad`"), Text::lit("monad blocks are out of this compiler")));
        std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EMonad{prism_rtl::rc(e), body})), .span = crate::syntax::parser::to(start, body.span)}, true, q};
    })
        : arg_starts_here(p_)
        ? ({
        auto [args, q] = parse_call_args(p_, commas);
        std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ECall{prism_rtl::rc(e), args, false, false})), .span = crate::syntax::parser::to(start, crate::syntax::parser::prev(q))}, true, q};
    })
        : std::tuple{e, false, p_}
        : (crate::syntax::parser::at_single_open(p_, Text::lit("(")) && crate::syntax::parser::tk(p_).touches) && (!crate::syntax::parser::is_topic(name))
        ? std::tuple{e, false, crate::syntax::parser::error_at(p_, crate::syntax::parser::here(p_), prism_rtl::cat("`", crate::syntax::parser::name_text(name), "` is a value and is not applied: a function\'s name is uppercase (case is a mark)"))}
        : std::tuple{e, false, p_};
}


prism_rtl::Turn<std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps>> NamePrimary::cycle() const {
    const auto& p0 = this->p0;
    const auto& n = this->n;
    const auto& commas = this->commas;
    auto start = crate::syntax::parser::here(p0);
    auto name = crate::syntax::SName{.sigils = n.sigils, .path_ = n->path_, .span = start};
    auto p1 = crate::syntax::parser::check_name_scope(crate::syntax::parser::adv(p0), name);
    auto plain = crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EName{name})), .span = start};
    auto [e, p_] = crate::syntax::parser::kind(p1) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KLtLt{})
        ? type_args_on(plain, p1, start)
        : std::tuple{plain, p1};
    return crate::syntax::parser::is_callee(name)
        ? crate::syntax::parser::at_single_open(p_, Text::lit("(")) && crate::syntax::parser::tk(p_).touches
        ? call_then(start_parse_paren_args(p_), [=](std::tuple<Array<crate::syntax::Arg>, bool, crate::syntax::parser::Ps> parse_paren_args_18204) {
        return ({
            auto [args, rest, q] = parse_paren_args_18204;
            (prism_rtl::finished(std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ECall{prism_rtl::rc(e), args, true, rest})), .span = crate::syntax::parser::to(start, crate::syntax::parser::prev(q))}, false, q}));
        });
    })
        : crate::syntax::parser::at_kw(p_, Text::lit("monad"))
        ? ({
        auto kw = crate::syntax::parser::here(p_);
        call_then(crate::syntax::parser::blocks::start_parse_block_after_colon(crate::syntax::parser::out_of_scope(crate::syntax::parser::adv(p_), kw, Text::lit("`T monad:` blocks and `^Monad`"), Text::lit("monad blocks are out of this compiler"))), [=](std::tuple<crate::syntax::Block, crate::syntax::parser::Ps> parse_block_after_colon_18455) {
        return ({
            auto [body, q] = parse_block_after_colon_18455;
            (prism_rtl::finished(std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EMonad{prism_rtl::rc(e), body})), .span = crate::syntax::parser::to(start, body.span)}, true, q}));
        });
    });
    })
        : arg_starts_here(p_)
        ? ({
        auto commas_1 = commas;
        call_then(start_parse_call_args(p_, commas_1), [=](std::tuple<Array<crate::syntax::Arg>, crate::syntax::parser::Ps> parse_call_args_18721) {
        return ({
            auto [args, q] = parse_call_args_18721;
            (prism_rtl::finished(std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ECall{prism_rtl::rc(e), args, false, false})), .span = crate::syntax::parser::to(start, crate::syntax::parser::prev(q))}, true, q}));
        });
    });
    })
        : prism_rtl::finished(std::tuple{e, false, p_})
        : (crate::syntax::parser::at_single_open(p_, Text::lit("(")) && crate::syntax::parser::tk(p_).touches) && (!crate::syntax::parser::is_topic(name))
        ? prism_rtl::finished(std::tuple{e, false, crate::syntax::parser::error_at(p_, crate::syntax::parser::here(p_), prism_rtl::cat("`", crate::syntax::parser::name_text(name), "` is a value and is not applied: a function\'s name is uppercase (case is a mark)"))})
        : prism_rtl::finished(std::tuple{e, false, p_});
}


/// `Start NamePrimary, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps>> start_name_primary(crate::syntax::parser::Ps p0, crate::syntax::lexer::NameTok n, bool commas) {
    return prism_rtl::make_rc<NamePrimary>(p0, n, commas);
}


/// TypeArgsOn: unbounded fn Expr, Ps, Range -> ((Expr, Ps))
std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> type_args_on(const crate::syntax::Expr& e, const crate::syntax::parser::Ps& p_, const crate::syntax::Range& start) {
    auto [types, q] = parse_type_args(p_);
    return std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ETypeArgs{prism_rtl::rc(e), types})), .span = crate::syntax::parser::to(start, crate::syntax::parser::prev(q))}, q};
}


prism_rtl::Turn<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> TypeArgsOn::cycle() const {
    const auto& e = this->e;
    const auto& p_ = this->p_;
    const auto& start = this->start;
    auto e_1 = e;
    auto p__2 = p_;
    auto start_3 = start;
    return call_then(start_parse_type_args(p__2), [=](std::tuple<Array<crate::syntax::Type>, crate::syntax::parser::Ps> parse_type_args_19224) {
        return ({
            auto [types, q] = parse_type_args_19224;
            (prism_rtl::finished(std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ETypeArgs{prism_rtl::rc(e_1), types})), .span = crate::syntax::parser::to(start_3, crate::syntax::parser::prev(q))}, q}));
        });
    });
}


/// `Start TypeArgsOn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> start_type_args_on(crate::syntax::Expr e, crate::syntax::parser::Ps p_, crate::syntax::Range start) {
    return prism_rtl::make_rc<TypeArgsOn>(e, p_, start);
}


/// ParenPrimary: unbounded fn Ps -> ((Expr, Bool, Ps))
std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps> paren_primary(const crate::syntax::parser::Ps& p_) {
    auto start = crate::syntax::parser::here(p_);
    return crate::syntax::parser::at_double_open(p_, Text::lit("("))
        ? ({
        auto [elems, p1] = crate::syntax::parser::commas(crate::syntax::parser::open_double(p_), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([&](crate::syntax::parser::Ps a0) { return entered(start_parse_arg_expr(a0)); })));
        auto p2 = crate::syntax::parser::close_double(p1, Text::lit("("));
        std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ETuple{elems})), .span = crate::syntax::parser::to(start, crate::syntax::parser::prev(p2))}, false, p2};
    })
        : ({
        auto [inner, p1] = crate::syntax::parser::bracketed(crate::syntax::parser::adv(p_), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([&](crate::syntax::parser::Ps a0) { return entered(start_parse_rhs_expr(a0)); })));
        (crate::syntax::parser::at_comma(p1)
        ? std::tuple{crate::syntax::parser::decls::no_expr(), false, crate::syntax::parser::error_at(p1, crate::syntax::parser::here(p1), Text::lit("a group holds one expression: a comma here needs a call at the group\'s head, or `((` `))` for a tuple"))}
        : ({
        auto p2 = crate::syntax::parser::expect_close(p1, Text::lit("("));
        std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EGroup{prism_rtl::rc(inner)})), .span = crate::syntax::parser::to(start, crate::syntax::parser::prev(p2))}, false, p2};
    }));
    });
}


prism_rtl::Turn<std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps>> ParenPrimary::cycle() const {
    const auto& p_ = this->p_;
    auto start = crate::syntax::parser::here(p_);
    return crate::syntax::parser::at_double_open(p_, Text::lit("("))
        ? ({
        auto p__1 = p_;
        call_then(crate::syntax::parser::start_commas(crate::syntax::parser::open_double(p__1), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([&](crate::syntax::parser::Ps a0) { return entered(start_parse_arg_expr(a0)); }))), [=](std::tuple<Array<crate::syntax::Expr>, crate::syntax::parser::Ps> commas_19554) {
        return ({
            auto [elems, p1] = commas_19554;
            auto p2 = crate::syntax::parser::close_double(p1, Text::lit("("));
            (prism_rtl::finished(std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ETuple{elems})), .span = crate::syntax::parser::to(start, crate::syntax::parser::prev(p2))}, false, p2}));
        });
    });
    })
        : ({
        auto p__1 = p_;
        call_then(crate::syntax::parser::start_bracketed(crate::syntax::parser::adv(p__1), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([&](crate::syntax::parser::Ps a0) { return entered(start_parse_rhs_expr(a0)); }))), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> bracketed_19818) {
        return ({
            auto [inner, p1] = bracketed_19818;
            (crate::syntax::parser::at_comma(p1)
            ? prism_rtl::finished(std::tuple{crate::syntax::parser::decls::no_expr(), false, crate::syntax::parser::error_at(p1, crate::syntax::parser::here(p1), Text::lit("a group holds one expression: a comma here needs a call at the group\'s head, or `((` `))` for a tuple"))})
            : ({
            auto p2 = crate::syntax::parser::expect_close(p1, Text::lit("("));
            (prism_rtl::finished(std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EGroup{prism_rtl::rc(inner)})), .span = crate::syntax::parser::to(start, crate::syntax::parser::prev(p2))}, false, p2}));
        }));
        });
    });
    });
}


/// `Start ParenPrimary, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps>> start_paren_primary(crate::syntax::parser::Ps p_) {
    return prism_rtl::make_rc<ParenPrimary>(p_);
}


/// SquarePrimary: unbounded fn Ps -> ((Expr, Bool, Ps))
std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps> square_primary(const crate::syntax::parser::Ps& p_) {
    auto start = crate::syntax::parser::here(p_);
    return crate::syntax::parser::at_double_open(p_, Text::lit("["))
        ? ({
        auto p1 = crate::syntax::parser::open_double(p_);
        auto [elems, p2] = crate::syntax::parser::at_close(p1, Text::lit("["))
            ? std::tuple{Array<crate::syntax::Expr>{}, p1}
            : crate::syntax::parser::commas(p1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([&](crate::syntax::parser::Ps a0) { return entered(start_parse_arg_expr(a0)); })));
        auto p3 = crate::syntax::parser::close_double(p2, Text::lit("["));
        std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EArray{elems})), .span = crate::syntax::parser::to(start, crate::syntax::parser::prev(p3))}, false, p3};
    })
        : ({
        auto [index_, p1] = crate::syntax::parser::bracketed(crate::syntax::parser::adv(p_), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([&](crate::syntax::parser::Ps a0) { return entered(start_parse_expr(a0)); })));
        auto p2 = crate::syntax::parser::expect_close(p1, Text::lit("["));
        std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ETopicIndex{prism_rtl::rc(index_)})), .span = crate::syntax::parser::to(start, crate::syntax::parser::prev(p2))}, false, p2};
    });
}


prism_rtl::Turn<std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps>> SquarePrimary::cycle() const {
    const auto& p_ = this->p_;
    auto start = crate::syntax::parser::here(p_);
    return crate::syntax::parser::at_double_open(p_, Text::lit("["))
        ? ({
        auto p1 = crate::syntax::parser::open_double(p_);
        auto [elems, p2] = crate::syntax::parser::at_close(p1, Text::lit("["))
            ? std::tuple{Array<crate::syntax::Expr>{}, p1}
            : crate::syntax::parser::commas(p1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([&](crate::syntax::parser::Ps a0) { return entered(start_parse_arg_expr(a0)); })));
        auto p3 = crate::syntax::parser::close_double(p2, Text::lit("["));
        (prism_rtl::finished(std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EArray{elems})), .span = crate::syntax::parser::to(start, crate::syntax::parser::prev(p3))}, false, p3}));
    })
        : ({
        auto p__1 = p_;
        call_then(crate::syntax::parser::start_bracketed(crate::syntax::parser::adv(p__1), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([&](crate::syntax::parser::Ps a0) { return entered(start_parse_expr(a0)); }))), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> bracketed_20642) {
        return ({
            auto [index_, p1] = bracketed_20642;
            auto p2 = crate::syntax::parser::expect_close(p1, Text::lit("["));
            (prism_rtl::finished(std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ETopicIndex{prism_rtl::rc(index_)})), .span = crate::syntax::parser::to(start, crate::syntax::parser::prev(p2))}, false, p2}));
        });
    });
    });
}


/// `Start SquarePrimary, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps>> start_square_primary(crate::syntax::parser::Ps p_) {
    return prism_rtl::make_rc<SquarePrimary>(p_);
}


/// MapPrimary: unbounded fn Ps -> ((Expr, Bool, Ps))
std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps> map_primary(const crate::syntax::parser::Ps& p_) {
    auto start = crate::syntax::parser::here(p_);
    auto p1 = crate::syntax::parser::adv(p_);
    auto [entries, p2] = crate::syntax::parser::at_close(p1, Text::lit("{"))
        ? std::tuple{Array<std::tuple<crate::syntax::Expr, crate::syntax::Expr>>{}, p1}
        : crate::syntax::parser::commas(p1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<std::tuple<crate::syntax::Expr, crate::syntax::Expr>, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([&](crate::syntax::parser::Ps a0) { return entered(start_parse_map_entry(a0)); })));
    auto p3 = crate::syntax::parser::expect_close(p2, Text::lit("{"));
    return std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EMap{entries})), .span = crate::syntax::parser::to(start, crate::syntax::parser::prev(p3))}, false, p3};
}


prism_rtl::Turn<std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps>> MapPrimary::cycle() const {
    const auto& p_ = this->p_;
    auto start = crate::syntax::parser::here(p_);
    auto p1 = crate::syntax::parser::adv(p_);
    auto [entries, p2] = crate::syntax::parser::at_close(p1, Text::lit("{"))
        ? std::tuple{Array<std::tuple<crate::syntax::Expr, crate::syntax::Expr>>{}, p1}
        : crate::syntax::parser::commas(p1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<std::tuple<crate::syntax::Expr, crate::syntax::Expr>, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([&](crate::syntax::parser::Ps a0) { return entered(start_parse_map_entry(a0)); })));
    auto p3 = crate::syntax::parser::expect_close(p2, Text::lit("{"));
    return prism_rtl::finished(std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EMap{entries})), .span = crate::syntax::parser::to(start, crate::syntax::parser::prev(p3))}, false, p3});
}


/// `Start MapPrimary, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps>> start_map_primary(crate::syntax::parser::Ps p_) {
    return prism_rtl::make_rc<MapPrimary>(p_);
}


/// ParseMapEntry: unbounded fn Ps -> ((((Expr, Expr)), Ps))
std::tuple<std::tuple<crate::syntax::Expr, crate::syntax::Expr>, crate::syntax::parser::Ps> parse_map_entry(const crate::syntax::parser::Ps& p_) {
    auto [k, p1] = parse_arg_expr(p_);
    auto [v_, p2] = parse_arg_expr(crate::syntax::parser::expect_colon(p1));
    return std::tuple{std::tuple{k, v_}, p2};
}


prism_rtl::Turn<std::tuple<std::tuple<crate::syntax::Expr, crate::syntax::Expr>, crate::syntax::parser::Ps>> ParseMapEntry::cycle() const {
    const auto& p_ = this->p_;
    auto p__1 = p_;
    return call_then(start_parse_arg_expr(p__1), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_arg_expr_21225) {
        return ({
            auto [k, p1] = parse_arg_expr_21225;
            call_then(start_parse_arg_expr(crate::syntax::parser::expect_colon(p1)), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_arg_expr_21260) {
            return ({
                auto [v_, p2] = parse_arg_expr_21260;
                (prism_rtl::finished(std::tuple{std::tuple{k, v_}, p2}));
            });
        });
        });
    });
}


/// `Start ParseMapEntry, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<std::tuple<crate::syntax::Expr, crate::syntax::Expr>, crate::syntax::parser::Ps>> start_parse_map_entry(crate::syntax::parser::Ps p_) {
    return prism_rtl::make_rc<ParseMapEntry>(p_);
}


/// LensPrimary: unbounded fn Ps -> ((Expr, Bool, Ps))
std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps> lens_primary(const crate::syntax::parser::Ps& p0) {
    auto start = crate::syntax::parser::here(p0);
    auto r = ({
        std::tuple<Array<crate::syntax::Ident>, crate::syntax::parser::Ps> this_ = std::tuple{Array<crate::syntax::Ident>{}, crate::syntax::parser::adv(p0)};
        Array<crate::syntax::Ident> path_ = Array<crate::syntax::Ident>{};
        crate::syntax::parser::Ps p_ = crate::syntax::parser::adv(p0);
        bool going = true;
        while (going && (!p_.bad)) {
            ({
                __label__ _done;
                prism_rtl::Slot<Unit> _v;
                auto&& _m = crate::syntax::parser::kind(p_);
                if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m)) {
                    auto&& n = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
                    if (((n.sigils == Text::lit("")) && (n.case_ == crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseLower{}))) && (len(n->path_) == Nat(1u))) {
                        _v.set(({
                            path_ = crate::prelude::push(path_, crate::syntax::Ident{.name = or_(index(n->path_, Nat(0u)), Text::lit("")), .span = crate::syntax::parser::here(p_)});
                            p_ = crate::syntax::parser::adv(p_);
                            if (crate::syntax::parser::kind(p_) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KDot{false})) {
                                p_ = crate::syntax::parser::adv(p_);
                            } else  {
                                going = false;
                            }
                            Unit{};
                        }));
                        goto _done;
                    }
                }
                {
                    _v.set(({
                        p_ = crate::syntax::parser::error_here(p_, Text::lit("expected a field name in a lens path"));
                        Unit{};
                    }));
                    goto _done;
                }
            _done:
                _v.take();
            });
        }
        this_ = std::tuple{path_, p_};
        this_;
    });
    auto [path_, q] = r;
    return std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ELens{path_})), .span = crate::syntax::parser::to(start, crate::syntax::parser::prev(q))}, false, q};
}


prism_rtl::Turn<std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps>> LensPrimary::cycle() const {
    const auto& p0 = this->p0;
    auto start = crate::syntax::parser::here(p0);
    std::tuple<Array<crate::syntax::Ident>, crate::syntax::parser::Ps> this_ = std::tuple{Array<crate::syntax::Ident>{}, crate::syntax::parser::adv(p0)};
    Array<crate::syntax::Ident> path_ = Array<crate::syntax::Ident>{};
    crate::syntax::parser::Ps p_ = crate::syntax::parser::adv(p0);
    bool going = true;
    auto start_1 = start;
    return call_then(loop_job(std::tuple{this_, going, p_, path_}, [=](std::tuple<std::tuple<Array<crate::syntax::Ident>, crate::syntax::parser::Ps>, bool, crate::syntax::parser::Ps, Array<crate::syntax::Ident>> _p0) {
        auto this_ = std::get<0>(_p0);
        auto going = std::get<1>(_p0);
        auto p_ = std::get<2>(_p0);
        auto path_ = std::get<3>(_p0);
        return going && (!p_->bad)
            ? ({
            ({
                __label__ _done;
                prism_rtl::Slot<Unit> _v;
                auto&& _m = crate::syntax::parser::kind(p_);
                if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m)) {
                    auto&& n = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
                    if (((n.sigils == Text::lit("")) && (n.case_ == crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseLower{}))) && (len(n->path_) == Nat(1u))) {
                        _v.set(({
                            path_ = crate::prelude::push(path_, crate::syntax::Ident{.name = or_(index(n->path_, Nat(0u)), Text::lit("")), .span = crate::syntax::parser::here(p_)});
                            p_ = crate::syntax::parser::adv(p_);
                            if (crate::syntax::parser::kind(p_) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KDot{false})) {
                                p_ = crate::syntax::parser::adv(p_);
                            } else  {
                                going = false;
                            }
                            Unit{};
                        }));
                        goto _done;
                    }
                }
                {
                    _v.set(({
                        p_ = crate::syntax::parser::error_here(p_, Text::lit("expected a field name in a lens path"));
                        Unit{};
                    }));
                    goto _done;
                }
            _done:
                _v.take();
            });
            Expected<std::tuple<std::tuple<Array<crate::syntax::Ident>, crate::syntax::parser::Ps>, bool, crate::syntax::parser::Ps, Array<crate::syntax::Ident>>, std::tuple<std::tuple<Array<crate::syntax::Ident>, crate::syntax::parser::Ps>, bool, crate::syntax::parser::Ps, Array<crate::syntax::Ident>>>(std::tuple{this_, going, p_, path_});
        })
            : Expected<std::tuple<std::tuple<Array<crate::syntax::Ident>, crate::syntax::parser::Ps>, bool, crate::syntax::parser::Ps, Array<crate::syntax::Ident>>, std::tuple<std::tuple<Array<crate::syntax::Ident>, crate::syntax::parser::Ps>, bool, crate::syntax::parser::Ps, Array<crate::syntax::Ident>>>(unexpected(std::tuple{this_, going, p_, path_}));
    }), [=](std::tuple<std::tuple<Array<crate::syntax::Ident>, crate::syntax::parser::Ps>, bool, crate::syntax::parser::Ps, Array<crate::syntax::Ident>> _p0) {
        auto this_ = std::get<0>(_p0);
        auto going = std::get<1>(_p0);
        auto p_ = std::get<2>(_p0);
        auto path_ = std::get<3>(_p0);
        return ({
            this_ = std::tuple{path_, p_};
            auto r = this_;
            auto [path_, q] = r;
            (prism_rtl::finished(std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ELens{path_})), .span = crate::syntax::parser::to(start_1, crate::syntax::parser::prev(q))}, false, q}));
        });
    });
}


/// `Start LensPrimary, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps>> start_lens_primary(crate::syntax::parser::Ps p0) {
    return prism_rtl::make_rc<LensPrimary>(p0);
}


/// KeywordPrimary: unbounded fn Ps, Text, Text, Bool -> ((Expr, Bool, Ps))
std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps> keyword_primary(const crate::syntax::parser::Ps& p_, const Text& w, const Text& sigils, const bool& commas) {
    auto start = crate::syntax::parser::here(p_);
    {
        auto&& m22385_0 = w;
        if (m22385_0 == Text::lit("unit")) {
            return std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EUnit{sigils})), .span = start}, false, crate::syntax::parser::adv(p_)};
        }
    }
    {
        auto&& m22385_1 = w;
        if (m22385_1 == Text::lit("nil")) {
            return std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ENil{sigils})), .span = start}, false, crate::syntax::parser::adv(p_)};
        }
    }
    {
        if (crate::syntax::lexer::is_bound_word(w)) {
            return std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EBound{w})), .span = start}, false, crate::syntax::parser::adv(p_)};
        }
    }
    {
        auto&& m22385_3 = w;
        if (m22385_3 == Text::lit("if")) {
            return took(parse_if(p_));
        }
    }
    {
        auto&& m22385_4 = w;
        if (m22385_4 == Text::lit("match")) {
            return took(parse_match(p_));
        }
    }
    {
        auto&& m22385_5 = w;
        if (m22385_5 == Text::lit("rebuild")) {
            auto [scrutinee, p1] = parse_expr(crate::syntax::parser::adv(p_));
            auto [body, p2] = crate::syntax::parser::blocks::parse_block_after_colon(p1);
            return std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ERebuild{prism_rtl::rc(scrutinee), body})), .span = crate::syntax::parser::to(start, body.span)}, true, p2};
        }
    }
    {
        auto&& m22385_6 = w;
        if (m22385_6 == Text::lit("for")) {
            return took(parse_for(p_));
        }
    }
    {
        auto&& m22385_7 = w;
        if (m22385_7 == Text::lit("given")) {
            auto [body, q] = crate::syntax::parser::blocks::parse_block_after_colon(crate::syntax::parser::adv(p_));
            return std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EGiven{body})), .span = crate::syntax::parser::to(start, body.span)}, true, q};
        }
    }
    {
        auto&& m22385_8 = w;
        if (m22385_8 == Text::lit("update")) {
            auto [target, p1] = parse_expr(crate::syntax::parser::adv(p_));
            auto [body, p2] = crate::syntax::parser::blocks::parse_block_after_colon(p1);
            return std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EUpdate{prism_rtl::rc(target), body})), .span = crate::syntax::parser::to(start, body.span)}, true, p2};
        }
    }
    {
        auto&& m22385_9 = w;
        if (m22385_9 == Text::lit("widget")) {
            auto [body, q] = crate::syntax::parser::blocks::parse_block_after_colon(crate::syntax::parser::adv(p_));
            return std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EWidgetBlock{body})), .span = crate::syntax::parser::to(start, body.span)}, true, q};
        }
    }
    {
        auto&& m22385_10 = w;
        if (m22385_10 == Text::lit("any")) {
            auto [operand, q] = parse_expr_ctx(crate::syntax::parser::adv(p_), commas);
            return std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EAny{prism_rtl::rc(operand)})), .span = crate::syntax::parser::to(start, operand.span)}, true, q};
        }
    }
    {
        auto&& m22385_11 = w;
        if (m22385_11 == Text::lit("not")) {
            auto [e, q] = parse_binary(p_, Nat(8u), commas);
            return std::tuple{e, true, q};
        }
    }
    {
        if (((w == Text::lit("output")) || (w == Text::lit("inline_text"))) || (w == Text::lit("raw"))) {
            auto p1 = crate::syntax::parser::adv(p_);
            auto&& _m = crate::syntax::parser::kind(p1);
            if (prism_rtl::is<crate::syntax::lexer::TokKind::KTemplate>(_m)) {
                auto&& t = prism_rtl::as<crate::syntax::lexer::TokKind::KTemplate>(_m).a0;
                auto tspan = crate::syntax::parser::here(p1);
                auto [tpl, q] = parse_template(crate::syntax::parser::adv(p1), t, tspan);
                return std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ETemplate{tpl})), .span = crate::syntax::parser::to(start, tspan)}, false, q};
            }
            {
                return std::tuple{crate::syntax::parser::decls::no_expr(), false, crate::syntax::parser::fail(p1)};
            }
        }
    }
    {
        auto&& m22385_13 = w;
        if (m22385_13 == Text::lit("then")) {
            return std::tuple{crate::syntax::parser::decls::no_expr(), false, crate::syntax::parser::error_at(p_, start, Text::lit("`then` belongs to a hold: `$x <- start then step`"))};
        }
    }
    {
        auto&& m22385_14 = w;
        if (m22385_14 == Text::lit("else")) {
            return std::tuple{crate::syntax::parser::decls::no_expr(), false, crate::syntax::parser::error_at(p_, start, Text::lit("`else` without its `if`"))};
        }
    }
    {
        auto&& m22385_15 = w;
        if (m22385_15 == Text::lit("ignore")) {
            return std::tuple{crate::syntax::parser::decls::no_expr(), false, crate::syntax::parser::error_at(p_, start, Text::lit("`ignore` stands only inside a pattern or as the left side of a bind"))};
        }
    }
    {
        auto&& m22385_16 = w;
        if (m22385_16 == Text::lit("return")) {
            return std::tuple{crate::syntax::parser::decls::no_expr(), false, crate::syntax::parser::error_at(p_, start, Text::lit("`return` ends a monad block, as its last statement"))};
        }
    }
    {
        return std::tuple{crate::syntax::parser::decls::no_expr(), false, crate::syntax::parser::error_here(p_, Text::lit("expected an expression"))};
    }
}


prism_rtl::Turn<std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps>> KeywordPrimary::cycle() const {
    const auto& p_ = this->p_;
    const auto& w = this->w;
    const auto& sigils = this->sigils;
    const auto& commas = this->commas;
    auto start = crate::syntax::parser::here(p_);
    return ({
        ({
        auto&& m22385_0 = w;
        (m22385_0 == Text::lit("unit"));
    }) ? ({
        auto&& m22385_0 = w;
        prism_rtl::finished(std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EUnit{sigils})), .span = start}, false, crate::syntax::parser::adv(p_)});
    })
        : ({
        auto&& m22385_1 = w;
        (m22385_1 == Text::lit("nil"));
    }) ? ({
        auto&& m22385_1 = w;
        prism_rtl::finished(std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ENil{sigils})), .span = start}, false, crate::syntax::parser::adv(p_)});
    })
        : ({
        crate::syntax::lexer::is_bound_word(w);
    }) ? prism_rtl::finished(std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EBound{w})), .span = start}, false, crate::syntax::parser::adv(p_)})
        : ({
        auto&& m22385_3 = w;
        (m22385_3 == Text::lit("if"));
    }) ? ({
        auto&& m22385_3 = w;
        ({
        auto p__1 = p_;
        call_then(start_parse_if(p__1), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_if_22647) { return prism_rtl::finished(took(parse_if_22647)); });
    });
    })
        : ({
        auto&& m22385_4 = w;
        (m22385_4 == Text::lit("match"));
    }) ? ({
        auto&& m22385_4 = w;
        ({
        auto p__1 = p_;
        call_then(start_parse_match(p__1), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_match_22681) { return prism_rtl::finished(took(parse_match_22681)); });
    });
    })
        : ({
        auto&& m22385_5 = w;
        (m22385_5 == Text::lit("rebuild"));
    }) ? ({
        auto&& m22385_5 = w;
        ({
        auto p__1 = p_;
        call_then(start_parse_expr(crate::syntax::parser::adv(p__1)), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_expr_22750) {
        return ({
            auto [scrutinee, p1] = parse_expr_22750;
            call_then(crate::syntax::parser::blocks::start_parse_block_after_colon(p1), [=](std::tuple<crate::syntax::Block, crate::syntax::parser::Ps> parse_block_after_colon_22799) {
            return ({
                auto [body, p2] = parse_block_after_colon_22799;
                (prism_rtl::finished(std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ERebuild{prism_rtl::rc(scrutinee), body})), .span = crate::syntax::parser::to(start, body.span)}, true, p2}));
            });
        });
        });
    });
    });
    })
        : ({
        auto&& m22385_6 = w;
        (m22385_6 == Text::lit("for"));
    }) ? ({
        auto&& m22385_6 = w;
        ({
        auto p__1 = p_;
        call_then(start_parse_for(p__1), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_for_22936) { return prism_rtl::finished(took(parse_for_22936)); });
    });
    })
        : ({
        auto&& m22385_7 = w;
        (m22385_7 == Text::lit("given"));
    }) ? ({
        auto&& m22385_7 = w;
        ({
        auto p__1 = p_;
        call_then(crate::syntax::parser::blocks::start_parse_block_after_colon(crate::syntax::parser::adv(p__1)), [=](std::tuple<crate::syntax::Block, crate::syntax::parser::Ps> parse_block_after_colon_22995) {
        return ({
            auto [body, q] = parse_block_after_colon_22995;
            (prism_rtl::finished(std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EGiven{body})), .span = crate::syntax::parser::to(start, body.span)}, true, q}));
        });
    });
    });
    })
        : ({
        auto&& m22385_8 = w;
        (m22385_8 == Text::lit("update"));
    }) ? ({
        auto&& m22385_8 = w;
        ({
        auto p__1 = p_;
        call_then(start_parse_expr(crate::syntax::parser::adv(p__1)), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_expr_23153) {
        return ({
            auto [target, p1] = parse_expr_23153;
            call_then(crate::syntax::parser::blocks::start_parse_block_after_colon(p1), [=](std::tuple<crate::syntax::Block, crate::syntax::parser::Ps> parse_block_after_colon_23202) {
            return ({
                auto [body, p2] = parse_block_after_colon_23202;
                (prism_rtl::finished(std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EUpdate{prism_rtl::rc(target), body})), .span = crate::syntax::parser::to(start, body.span)}, true, p2}));
            });
        });
        });
    });
    });
    })
        : ({
        auto&& m22385_9 = w;
        (m22385_9 == Text::lit("widget"));
    }) ? ({
        auto&& m22385_9 = w;
        ({
        auto p__1 = p_;
        call_then(crate::syntax::parser::blocks::start_parse_block_after_colon(crate::syntax::parser::adv(p__1)), [=](std::tuple<crate::syntax::Block, crate::syntax::parser::Ps> parse_block_after_colon_23415) {
        return ({
            auto [body, q] = parse_block_after_colon_23415;
            (prism_rtl::finished(std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EWidgetBlock{body})), .span = crate::syntax::parser::to(start, body.span)}, true, q}));
        });
    });
    });
    })
        : ({
        auto&& m22385_10 = w;
        (m22385_10 == Text::lit("any"));
    }) ? ({
        auto&& m22385_10 = w;
        ({
        auto commas_1 = commas;
        auto p__2 = p_;
        call_then(start_parse_expr_ctx(crate::syntax::parser::adv(p__2), commas_1), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_expr_ctx_23576) {
        return ({
            auto [operand, q] = parse_expr_ctx_23576;
            (prism_rtl::finished(std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EAny{prism_rtl::rc(operand)})), .span = crate::syntax::parser::to(start, operand.span)}, true, q}));
        });
    });
    });
    })
        : ({
        auto&& m22385_11 = w;
        (m22385_11 == Text::lit("not"));
    }) ? ({
        auto&& m22385_11 = w;
        ({
        auto commas_1 = commas;
        auto p__2 = p_;
        call_then(start_parse_binary(p__2, Nat(8u), commas_1), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_binary_23729) {
        return ({
            auto [e, q] = parse_binary_23729;
            (prism_rtl::finished(std::tuple{e, true, q}));
        });
    });
    });
    })
        : ({
        (((w == Text::lit("output")) || (w == Text::lit("inline_text"))) || (w == Text::lit("raw")));
    }) ? ({
        auto p1 = crate::syntax::parser::adv(p_);
        ({
        auto&& _m = crate::syntax::parser::kind(p1);
        prism_rtl::is<crate::syntax::lexer::TokKind::KTemplate>(_m) ? ({
        auto&& t = prism_rtl::as<crate::syntax::lexer::TokKind::KTemplate>(_m).a0;
        ({
        auto tspan = crate::syntax::parser::here(p1);
        call_then(start_parse_template(crate::syntax::parser::adv(p1), t, tspan), [=](std::tuple<crate::syntax::Template, crate::syntax::parser::Ps> parse_template_24089) {
        return ({
            auto [tpl, q] = parse_template_24089;
            (prism_rtl::finished(std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ETemplate{tpl})), .span = crate::syntax::parser::to(start, tspan)}, false, q}));
        });
    });
    });
    })
        : prism_rtl::finished(std::tuple{crate::syntax::parser::decls::no_expr(), false, crate::syntax::parser::fail(p1)});
    });
    })
        : ({
        auto&& m22385_13 = w;
        (m22385_13 == Text::lit("then"));
    }) ? ({
        auto&& m22385_13 = w;
        prism_rtl::finished(std::tuple{crate::syntax::parser::decls::no_expr(), false, crate::syntax::parser::error_at(p_, start, Text::lit("`then` belongs to a hold: `$x <- start then step`"))});
    })
        : ({
        auto&& m22385_14 = w;
        (m22385_14 == Text::lit("else"));
    }) ? ({
        auto&& m22385_14 = w;
        prism_rtl::finished(std::tuple{crate::syntax::parser::decls::no_expr(), false, crate::syntax::parser::error_at(p_, start, Text::lit("`else` without its `if`"))});
    })
        : ({
        auto&& m22385_15 = w;
        (m22385_15 == Text::lit("ignore"));
    }) ? ({
        auto&& m22385_15 = w;
        prism_rtl::finished(std::tuple{crate::syntax::parser::decls::no_expr(), false, crate::syntax::parser::error_at(p_, start, Text::lit("`ignore` stands only inside a pattern or as the left side of a bind"))});
    })
        : ({
        auto&& m22385_16 = w;
        (m22385_16 == Text::lit("return"));
    }) ? ({
        auto&& m22385_16 = w;
        prism_rtl::finished(std::tuple{crate::syntax::parser::decls::no_expr(), false, crate::syntax::parser::error_at(p_, start, Text::lit("`return` ends a monad block, as its last statement"))});
    })
        : prism_rtl::finished(std::tuple{crate::syntax::parser::decls::no_expr(), false, crate::syntax::parser::error_here(p_, Text::lit("expected an expression"))});
    });
}


/// `Start KeywordPrimary, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps>> start_keyword_primary(crate::syntax::parser::Ps p_, Text w, Text sigils, bool commas) {
    return prism_rtl::make_rc<KeywordPrimary>(p_, w, sigils, commas);
}


/// Took: fn ((Expr, Ps)) -> ((Expr, Bool, Ps))
std::tuple<crate::syntax::Expr, bool, crate::syntax::parser::Ps> took(const std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>& arg0) {
    {
        auto&& e = std::get<0>(arg0);
        auto&& p_ = std::get<1>(arg0);
        return std::tuple{e, true, p_};
    }
    prism_rtl::unreachable("no arm matched");
}


/// ParseLiteral: unbounded fn Ps -> ((Literal, Ps))
std::tuple<crate::syntax::Literal, crate::syntax::parser::Ps> parse_literal(const crate::syntax::parser::Ps& p_) {
    auto span = crate::syntax::parser::here(p_);
    auto p1 = crate::syntax::parser::adv(p_);
    auto&& _m = crate::syntax::parser::kind(p_);
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KInt>(_m)) {
        auto&& s = prism_rtl::as<crate::syntax::lexer::TokKind::KInt>(_m).a0;
        auto&& t = prism_rtl::as<crate::syntax::lexer::TokKind::KInt>(_m).a1;
        return std::tuple{crate::syntax::Literal{.marks = s, .kind = crate::syntax::LitKind(crate::syntax::LitKind::LInt{t}), .span = span}, p1};
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KFloat>(_m)) {
        auto&& s = prism_rtl::as<crate::syntax::lexer::TokKind::KFloat>(_m).a0;
        auto&& t = prism_rtl::as<crate::syntax::lexer::TokKind::KFloat>(_m).a1;
        return std::tuple{crate::syntax::Literal{.marks = s, .kind = crate::syntax::LitKind(crate::syntax::LitKind::LFloat{t}), .span = span}, p1};
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KDuration>(_m)) {
        auto&& s = prism_rtl::as<crate::syntax::lexer::TokKind::KDuration>(_m).a0;
        auto&& n = prism_rtl::as<crate::syntax::lexer::TokKind::KDuration>(_m).a1;
        auto&& u = prism_rtl::as<crate::syntax::lexer::TokKind::KDuration>(_m).a2;
        return std::tuple{crate::syntax::Literal{.marks = s, .kind = crate::syntax::LitKind(crate::syntax::LitKind::LDuration{n, u}), .span = span}, p1};
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KChar>(_m)) {
        auto&& s = prism_rtl::as<crate::syntax::lexer::TokKind::KChar>(_m).a0;
        auto&& c = prism_rtl::as<crate::syntax::lexer::TokKind::KChar>(_m).a1;
        return std::tuple{crate::syntax::Literal{.marks = s, .kind = crate::syntax::LitKind(crate::syntax::LitKind::LChar{c}), .span = span}, p1};
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KRegex>(_m)) {
        auto&& s = prism_rtl::as<crate::syntax::lexer::TokKind::KRegex>(_m).a0;
        auto&& r = prism_rtl::as<crate::syntax::lexer::TokKind::KRegex>(_m).a1;
        return std::tuple{crate::syntax::Literal{.marks = s, .kind = crate::syntax::LitKind(crate::syntax::LitKind::LRegex{r}), .span = span}, p1};
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KText>(_m)) {
        auto&& s = prism_rtl::as<crate::syntax::lexer::TokKind::KText>(_m).a0;
        auto&& segs = prism_rtl::as<crate::syntax::lexer::TokKind::KText>(_m).a1;
        auto [out, q] = run_to_end(fold_job(segs, std::tuple{Array<crate::syntax::TextSeg>{}, p1}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::syntax::TextSeg>, crate::syntax::parser::Ps>>(std::tuple<std::tuple<Array<crate::syntax::TextSeg>, crate::syntax::parser::Ps>, crate::syntax::lexer::TextSegTok>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<crate::syntax::TextSeg>, crate::syntax::parser::Ps>, crate::syntax::lexer::TextSegTok> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto [acc, pp] = p0;
                    auto seg = p1;
                    (prism_rtl::more(prism_rtl::rc(TextSegment(acc, pp, seg))));
                });
            }));
        }))));
        return std::tuple{crate::syntax::Literal{.marks = s, .kind = crate::syntax::LitKind(crate::syntax::LitKind::LText{out}), .span = span}, q};
    }
    {
        return std::tuple{crate::syntax::Literal{.marks = Text::lit(""), .kind = crate::syntax::LitKind(crate::syntax::LitKind::LInt{Text::lit("")}), .span = span}, crate::syntax::parser::error_at(p1, span, Text::lit("expected a literal"))};
    }
}


prism_rtl::Turn<std::tuple<crate::syntax::Literal, crate::syntax::parser::Ps>> ParseLiteral::cycle() const {
    const auto& p_ = this->p_;
    auto span = crate::syntax::parser::here(p_);
    auto p1 = crate::syntax::parser::adv(p_);
    return ({
        auto&& _m = crate::syntax::parser::kind(p_);
        prism_rtl::is<crate::syntax::lexer::TokKind::KInt>(_m) ? ({
        auto&& s = prism_rtl::as<crate::syntax::lexer::TokKind::KInt>(_m).a0;
        auto&& t = prism_rtl::as<crate::syntax::lexer::TokKind::KInt>(_m).a1;
        prism_rtl::finished(std::tuple{crate::syntax::Literal{.marks = s, .kind = crate::syntax::LitKind(crate::syntax::LitKind::LInt{t}), .span = span}, p1});
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KFloat>(_m) ? ({
        auto&& s = prism_rtl::as<crate::syntax::lexer::TokKind::KFloat>(_m).a0;
        auto&& t = prism_rtl::as<crate::syntax::lexer::TokKind::KFloat>(_m).a1;
        prism_rtl::finished(std::tuple{crate::syntax::Literal{.marks = s, .kind = crate::syntax::LitKind(crate::syntax::LitKind::LFloat{t}), .span = span}, p1});
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KDuration>(_m) ? ({
        auto&& s = prism_rtl::as<crate::syntax::lexer::TokKind::KDuration>(_m).a0;
        auto&& n = prism_rtl::as<crate::syntax::lexer::TokKind::KDuration>(_m).a1;
        auto&& u = prism_rtl::as<crate::syntax::lexer::TokKind::KDuration>(_m).a2;
        prism_rtl::finished(std::tuple{crate::syntax::Literal{.marks = s, .kind = crate::syntax::LitKind(crate::syntax::LitKind::LDuration{n, u}), .span = span}, p1});
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KChar>(_m) ? ({
        auto&& s = prism_rtl::as<crate::syntax::lexer::TokKind::KChar>(_m).a0;
        auto&& c = prism_rtl::as<crate::syntax::lexer::TokKind::KChar>(_m).a1;
        prism_rtl::finished(std::tuple{crate::syntax::Literal{.marks = s, .kind = crate::syntax::LitKind(crate::syntax::LitKind::LChar{c}), .span = span}, p1});
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KRegex>(_m) ? ({
        auto&& s = prism_rtl::as<crate::syntax::lexer::TokKind::KRegex>(_m).a0;
        auto&& r = prism_rtl::as<crate::syntax::lexer::TokKind::KRegex>(_m).a1;
        prism_rtl::finished(std::tuple{crate::syntax::Literal{.marks = s, .kind = crate::syntax::LitKind(crate::syntax::LitKind::LRegex{r}), .span = span}, p1});
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KText>(_m) ? ({
        auto&& s = prism_rtl::as<crate::syntax::lexer::TokKind::KText>(_m).a0;
        auto&& segs = prism_rtl::as<crate::syntax::lexer::TokKind::KText>(_m).a1;
        call_value(fold_job(segs, std::tuple{Array<crate::syntax::TextSeg>{}, p1}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::syntax::TextSeg>, crate::syntax::parser::Ps>>(std::tuple<std::tuple<Array<crate::syntax::TextSeg>, crate::syntax::parser::Ps>, crate::syntax::lexer::TextSegTok>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<crate::syntax::TextSeg>, crate::syntax::parser::Ps>, crate::syntax::lexer::TextSegTok> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto [acc, pp] = p0;
                auto seg = p1;
                (prism_rtl::more(prism_rtl::rc(TextSegment(acc, pp, seg))));
            });
        }));
    }))), [=](std::tuple<Array<crate::syntax::TextSeg>, crate::syntax::parser::Ps> fold_25477) {
        return ({
            auto [out, q] = fold_25477;
            (prism_rtl::finished(std::tuple{crate::syntax::Literal{.marks = s, .kind = crate::syntax::LitKind(crate::syntax::LitKind::LText{out}), .span = span}, q}));
        });
    });
    })
        : prism_rtl::finished(std::tuple{crate::syntax::Literal{.marks = Text::lit(""), .kind = crate::syntax::LitKind(crate::syntax::LitKind::LInt{Text::lit("")}), .span = span}, crate::syntax::parser::error_at(p1, span, Text::lit("expected a literal"))});
    });
}


/// `Start ParseLiteral, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Literal, crate::syntax::parser::Ps>> start_parse_literal(crate::syntax::parser::Ps p_) {
    return prism_rtl::make_rc<ParseLiteral>(p_);
}


/// TextSegment: unbounded fn [TextSeg], Ps, TextSegTok -> (([TextSeg], Ps))
std::tuple<Array<crate::syntax::TextSeg>, crate::syntax::parser::Ps> text_segment(const Array<crate::syntax::TextSeg>& acc, const crate::syntax::parser::Ps& p_, const crate::syntax::lexer::TextSegTok& text_seg_tok2) {
    if (prism_rtl::is<crate::syntax::lexer::TextSegTok::TsPlain>(text_seg_tok2)) {
        auto&& s = prism_rtl::as<crate::syntax::lexer::TextSegTok::TsPlain>(text_seg_tok2).a0;
        return std::tuple{crate::prelude::push(acc, crate::syntax::TextSeg(crate::syntax::TextSeg::SegPlain{s})), p_};
    }
    if (prism_rtl::is<crate::syntax::lexer::TextSegTok::TsPlaceholder>(text_seg_tok2)) {
        auto&& toks = prism_rtl::as<crate::syntax::lexer::TextSegTok::TsPlaceholder>(text_seg_tok2).a0;
        auto&& span = prism_rtl::as<crate::syntax::lexer::TextSegTok::TsPlaceholder>(text_seg_tok2).a1;
        auto [e, q] = parse_nested(p_, toks, span);
        return std::tuple{crate::prelude::push(acc, crate::syntax::TextSeg(crate::syntax::TextSeg::SegPlaceholder{e})), q};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<Array<crate::syntax::TextSeg>, crate::syntax::parser::Ps>> TextSegment::cycle() const {
    const auto& acc = this->acc;
    const auto& p_ = this->p_;
    const auto& text_seg_tok2 = this->text_seg_tok2;
    return ({
        prism_rtl::is<crate::syntax::lexer::TextSegTok::TsPlain>(text_seg_tok2) ? ({
        auto&& s = prism_rtl::as<crate::syntax::lexer::TextSegTok::TsPlain>(text_seg_tok2).a0;
        prism_rtl::finished(std::tuple{crate::prelude::push(acc, crate::syntax::TextSeg(crate::syntax::TextSeg::SegPlain{s})), p_});
    })
        : prism_rtl::is<crate::syntax::lexer::TextSegTok::TsPlaceholder>(text_seg_tok2) ? ({
        auto&& toks = prism_rtl::as<crate::syntax::lexer::TextSegTok::TsPlaceholder>(text_seg_tok2).a0;
        auto&& span = prism_rtl::as<crate::syntax::lexer::TextSegTok::TsPlaceholder>(text_seg_tok2).a1;
        ({
        auto acc_1 = acc;
        auto p__2 = p_;
        auto span_3 = span;
        auto toks_4 = toks;
        call_then(start_parse_nested(p__2, toks_4, span_3), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_nested_25935) {
        return ({
            auto [e, q] = parse_nested_25935;
            (prism_rtl::finished(std::tuple{crate::prelude::push(acc_1, crate::syntax::TextSeg(crate::syntax::TextSeg::SegPlaceholder{e})), q}));
        });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start TextSegment, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::syntax::TextSeg>, crate::syntax::parser::Ps>> start_text_segment(Array<crate::syntax::TextSeg> acc, crate::syntax::parser::Ps p_, crate::syntax::lexer::TextSegTok text_seg_tok2) {
    return prism_rtl::make_rc<TextSegment>(acc, p_, text_seg_tok2);
}


/// ParseNested: unbounded fn Ps, [Tok], Range -> ((Expr, Ps))
std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_nested(const crate::syntax::parser::Ps& p_, const Array<crate::syntax::lexer::Tok>& toks, const crate::syntax::Range& span) {
    auto sub_1 = crate::syntax::parser::with_step_mode(crate::syntax::parser::sub(p_, toks, crate::syntax::parser::at_end(span)), false);
    auto [e, s1] = parse_rhs_expr(sub_1);
    auto s2 = (!s1->bad) && (!crate::syntax::parser::at_eof(s1))
        ? crate::syntax::parser::note_error(s1, crate::syntax::parser::here(s1), prism_rtl::cat("expected the end of the placeholder, found ", crate::syntax::parser::describe(crate::syntax::parser::kind(s1))))
        : s1;
    auto s3 = s2->bad && (len(s2.diags) == Nat(0u))
        ? crate::syntax::parser::note_error(crate::syntax::parser::unbad(s2), span, Text::lit("expected an expression in the placeholder"))
        : s2;
    auto q = crate::syntax::parser::absorb(p_, s3);
    return s1->bad
        ? std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EError{})), .span = span}, q}
        : std::tuple{e, q};
}


prism_rtl::Turn<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> ParseNested::cycle() const {
    const auto& p_ = this->p_;
    const auto& toks = this->toks;
    const auto& span = this->span;
    auto p__1 = p_;
    auto span_2 = span;
    auto toks_3 = toks;
    return call_then(crate::syntax::parser::start_sub(p__1, toks_3, crate::syntax::parser::at_end(span_2)), [=](crate::syntax::parser::Ps sub_26258) {
        return ({
            auto sub = crate::syntax::parser::with_step_mode(sub_26258, false);
            call_then(start_parse_rhs_expr(sub), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_rhs_expr_26312) {
            return ({
                auto [e, s1] = parse_rhs_expr_26312;
                auto s2 = (!s1->bad) && (!crate::syntax::parser::at_eof(s1))
                    ? crate::syntax::parser::note_error(s1, crate::syntax::parser::here(s1), prism_rtl::cat("expected the end of the placeholder, found ", crate::syntax::parser::describe(crate::syntax::parser::kind(s1))))
                    : s1;
                auto s3 = s2->bad && (len(s2.diags) == Nat(0u))
                    ? crate::syntax::parser::note_error(crate::syntax::parser::unbad(s2), span_2, Text::lit("expected an expression in the placeholder"))
                    : s2;
                auto q = crate::syntax::parser::absorb(p__1, s3);
                s1->bad
                ? prism_rtl::finished(std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EError{})), .span = span_2}, q})
                : prism_rtl::finished(std::tuple{e, q});
            });
        });
        });
    });
}


/// `Start ParseNested, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> start_parse_nested(crate::syntax::parser::Ps p_, Array<crate::syntax::lexer::Tok> toks, crate::syntax::Range span) {
    return prism_rtl::make_rc<ParseNested>(p_, toks, span);
}


/// ParseTemplate: unbounded fn Ps, TemplateTok, Range -> ((Template, Ps))
std::tuple<crate::syntax::Template, crate::syntax::parser::Ps> parse_template(const crate::syntax::parser::Ps& p0, const crate::syntax::lexer::TemplateTok& t, const crate::syntax::Range& span) {
    auto p1 = (t.delims == Text::lit("single")) && (t.keyword != Text::lit("Raw"))
        ? crate::syntax::parser::out_of_scope(p0, span, Text::lit("the template notation"), prism_rtl::cat("a `<", t.lang, ">` template is the template notation for an element language, out of this compiler (code templates only)"))
        : p0;
    auto p2 = t.keyword == Text::lit("File")
        ? crate::syntax::parser::out_of_scope(p1, span, Text::lit("the template notation"), Text::lit("a file whose first token is a language tag is a template file, out of this compiler (code templates only)"))
        : p1;
    auto [parts, p3] = template_parts(p2, t.parts);
    return std::tuple{crate::syntax::Template{.keyword = t.keyword, .lang = t.lang, .delims = t.delims, .parts = parts, .span = span}, p3};
}


prism_rtl::Turn<std::tuple<crate::syntax::Template, crate::syntax::parser::Ps>> ParseTemplate::cycle() const {
    const auto& p0 = this->p0;
    const auto& t = this->t;
    const auto& span = this->span;
    auto p1 = (t.delims == Text::lit("single")) && (t.keyword != Text::lit("Raw"))
        ? crate::syntax::parser::out_of_scope(p0, span, Text::lit("the template notation"), prism_rtl::cat("a `<", t.lang, ">` template is the template notation for an element language, out of this compiler (code templates only)"))
        : p0;
    auto p2 = t.keyword == Text::lit("File")
        ? crate::syntax::parser::out_of_scope(p1, span, Text::lit("the template notation"), Text::lit("a file whose first token is a language tag is a template file, out of this compiler (code templates only)"))
        : p1;
    auto span_1 = span;
    auto t_2 = t;
    return call_then(start_template_parts(p2, t_2.parts), [=](std::tuple<Array<crate::syntax::TemplatePart>, crate::syntax::parser::Ps> template_parts_27307) {
        return ({
            auto [parts, p3] = template_parts_27307;
            (prism_rtl::finished(std::tuple{crate::syntax::Template{.keyword = t_2.keyword, .lang = t_2.lang, .delims = t_2.delims, .parts = parts, .span = span_1}, p3}));
        });
    });
}


/// `Start ParseTemplate, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Template, crate::syntax::parser::Ps>> start_parse_template(crate::syntax::parser::Ps p0, crate::syntax::lexer::TemplateTok t, crate::syntax::Range span) {
    return prism_rtl::make_rc<ParseTemplate>(p0, t, span);
}


/// TemplateParts: unbounded fn Ps, [TPartTok] -> (([TemplatePart], Ps))
std::tuple<Array<crate::syntax::TemplatePart>, crate::syntax::parser::Ps> template_parts(const crate::syntax::parser::Ps& p_, const Array<crate::syntax::lexer::TPartTok>& parts) {
    return run_to_end(fold_job(parts, std::tuple{Array<crate::syntax::TemplatePart>{}, p_}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::syntax::TemplatePart>, crate::syntax::parser::Ps>>(std::tuple<std::tuple<Array<crate::syntax::TemplatePart>, crate::syntax::parser::Ps>, crate::syntax::lexer::TPartTok>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<crate::syntax::TemplatePart>, crate::syntax::parser::Ps>, crate::syntax::lexer::TPartTok> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto [acc, q] = p0;
                auto part = p1;
                (prism_rtl::more(prism_rtl::rc(TemplatePartOf(acc, q, part))));
            });
        }));
    }))));
}


prism_rtl::Turn<std::tuple<Array<crate::syntax::TemplatePart>, crate::syntax::parser::Ps>> TemplateParts::cycle() const {
    const auto& p_ = this->p_;
    const auto& parts = this->parts;
    return fold_job(parts, std::tuple{Array<crate::syntax::TemplatePart>{}, p_}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::syntax::TemplatePart>, crate::syntax::parser::Ps>>(std::tuple<std::tuple<Array<crate::syntax::TemplatePart>, crate::syntax::parser::Ps>, crate::syntax::lexer::TPartTok>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<crate::syntax::TemplatePart>, crate::syntax::parser::Ps>, crate::syntax::lexer::TPartTok> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto [acc, q] = p0;
                auto part = p1;
                (prism_rtl::more(prism_rtl::rc(TemplatePartOf(acc, q, part))));
            });
        }));
    })))->cycle();
}


/// `Start TemplateParts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::syntax::TemplatePart>, crate::syntax::parser::Ps>> start_template_parts(crate::syntax::parser::Ps p_, Array<crate::syntax::lexer::TPartTok> parts) {
    return prism_rtl::make_rc<TemplateParts>(p_, parts);
}


/// TemplatePartOf: unbounded fn [TemplatePart], Ps, TPartTok -> (([TemplatePart], Ps))
std::tuple<Array<crate::syntax::TemplatePart>, crate::syntax::parser::Ps> template_part_of(const Array<crate::syntax::TemplatePart>& acc, const crate::syntax::parser::Ps& p_, const crate::syntax::lexer::TPartTok& tpart_tok2) {
    if (prism_rtl::is<crate::syntax::lexer::TPartTok::TptText>(tpart_tok2)) {
        auto&& s = prism_rtl::as<crate::syntax::lexer::TPartTok::TptText>(tpart_tok2).a0;
        return std::tuple{crate::prelude::push(acc, crate::syntax::TemplatePart(crate::syntax::TemplatePart::TpText{s})), p_};
    }
    if (prism_rtl::is<crate::syntax::lexer::TPartTok::TptPlaceholder>(tpart_tok2)) {
        auto&& toks = prism_rtl::as<crate::syntax::lexer::TPartTok::TptPlaceholder>(tpart_tok2).a0;
        auto&& col_opt = prism_rtl::as<crate::syntax::lexer::TPartTok::TptPlaceholder>(tpart_tok2).a1;
        auto&& span = prism_rtl::as<crate::syntax::lexer::TPartTok::TptPlaceholder>(tpart_tok2).a2;
        auto [e, q] = parse_nested(p_, toks, span);
        return std::tuple{crate::prelude::push(acc, crate::syntax::TemplatePart(crate::syntax::TemplatePart::TpPlaceholder{e, col_opt})), q};
    }
    if (prism_rtl::is<crate::syntax::lexer::TPartTok::TptBlock>(tpart_tok2)) {
        auto&& toks = prism_rtl::as<crate::syntax::lexer::TPartTok::TptBlock>(tpart_tok2).a0;
        auto&& span = prism_rtl::as<crate::syntax::lexer::TPartTok::TptBlock>(tpart_tok2).a1;
        auto sub_1 = crate::syntax::parser::sub(p_, toks, crate::syntax::parser::at_end(span));
        auto [block, s1] = crate::syntax::parser::blocks::parse_block_until_eof(sub_1, span);
        return std::tuple{crate::prelude::push(acc, crate::syntax::TemplatePart(crate::syntax::TemplatePart::TpBlock{block})), crate::syntax::parser::absorb(p_, s1)};
    }
    if (prism_rtl::is<crate::syntax::lexer::TPartTok::TptCall>(tpart_tok2)) {
        auto&& name = prism_rtl::as<crate::syntax::lexer::TPartTok::TptCall>(tpart_tok2).a0;
        auto&& attrs = prism_rtl::as<crate::syntax::lexer::TPartTok::TptCall>(tpart_tok2).a1;
        auto&& body_opt = prism_rtl::as<crate::syntax::lexer::TPartTok::TptCall>(tpart_tok2).a2;
        auto&& span = prism_rtl::as<crate::syntax::lexer::TPartTok::TptCall>(tpart_tok2).a3;
        auto sname = crate::syntax::SName{.sigils = name.sigils, .path_ = name->path_, .span = span};
        auto [args, p1] = run_to_end(fold_job(attrs, std::tuple{Array<crate::syntax::Arg>{}, p_}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::syntax::Arg>, crate::syntax::parser::Ps>>(std::tuple<std::tuple<Array<crate::syntax::Arg>, crate::syntax::parser::Ps>, crate::syntax::lexer::AttrTok>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<crate::syntax::Arg>, crate::syntax::parser::Ps>, crate::syntax::lexer::AttrTok> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto [done, q] = p0;
                    auto a = p1;
                    (prism_rtl::more(prism_rtl::rc(AttrArg(done, q, a))));
                });
            }));
        }))));
        auto [inner_opt, p2] = ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<std::optional<Array<crate::syntax::TemplatePart>>, crate::syntax::parser::Ps>> _v;
            if (prism_rtl::is_some(body_opt)) {
                auto&& b = prism_rtl::some_of(body_opt);
                _v.set(({
                    auto [ps, q] = template_parts(p1, b);
                    std::tuple{std::optional(ps), q};
                }));
                goto _done;
            }
            if (prism_rtl::is_none(body_opt)) {
                _v.set(std::tuple{std::optional<Array<crate::syntax::TemplatePart>>{}, p1});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        return std::tuple{crate::prelude::push(acc, crate::syntax::TemplatePart(crate::syntax::TemplatePart::TpCall{sname, args, inner_opt, span})), p2};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<Array<crate::syntax::TemplatePart>, crate::syntax::parser::Ps>> TemplatePartOf::cycle() const {
    const auto& acc = this->acc;
    const auto& p_ = this->p_;
    const auto& tpart_tok2 = this->tpart_tok2;
    return ({
        prism_rtl::is<crate::syntax::lexer::TPartTok::TptText>(tpart_tok2) ? ({
        auto&& s = prism_rtl::as<crate::syntax::lexer::TPartTok::TptText>(tpart_tok2).a0;
        prism_rtl::finished(std::tuple{crate::prelude::push(acc, crate::syntax::TemplatePart(crate::syntax::TemplatePart::TpText{s})), p_});
    })
        : prism_rtl::is<crate::syntax::lexer::TPartTok::TptPlaceholder>(tpart_tok2) ? ({
        auto&& toks = prism_rtl::as<crate::syntax::lexer::TPartTok::TptPlaceholder>(tpart_tok2).a0;
        auto&& col_opt = prism_rtl::as<crate::syntax::lexer::TPartTok::TptPlaceholder>(tpart_tok2).a1;
        auto&& span = prism_rtl::as<crate::syntax::lexer::TPartTok::TptPlaceholder>(tpart_tok2).a2;
        ({
        auto col_opt_1 = col_opt;
        auto acc_2 = acc;
        auto p__3 = p_;
        auto span_4 = span;
        auto toks_5 = toks;
        call_then(start_parse_nested(p__3, toks_5, span_4), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_nested_27833) {
        return ({
            auto [e, q] = parse_nested_27833;
            (prism_rtl::finished(std::tuple{crate::prelude::push(acc_2, crate::syntax::TemplatePart(crate::syntax::TemplatePart::TpPlaceholder{e, col_opt_1})), q}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TPartTok::TptBlock>(tpart_tok2) ? ({
        auto&& toks = prism_rtl::as<crate::syntax::lexer::TPartTok::TptBlock>(tpart_tok2).a0;
        auto&& span = prism_rtl::as<crate::syntax::lexer::TPartTok::TptBlock>(tpart_tok2).a1;
        ({
        auto acc_1 = acc;
        auto p__2 = p_;
        auto span_3 = span;
        auto toks_4 = toks;
        call_then(crate::syntax::parser::start_sub(p__2, toks_4, crate::syntax::parser::at_end(span_3)), [=](crate::syntax::parser::Ps sub_27969) {
        return ({
            auto sub = sub_27969;
            call_then(crate::syntax::parser::blocks::start_parse_block_until_eof(sub, span_3), [=](std::tuple<crate::syntax::Block, crate::syntax::parser::Ps> parse_block_until_eof_28019) {
            return ({
                auto [block, s1] = parse_block_until_eof_28019;
                (prism_rtl::finished(std::tuple{crate::prelude::push(acc_1, crate::syntax::TemplatePart(crate::syntax::TemplatePart::TpBlock{block})), crate::syntax::parser::absorb(p__2, s1)}));
            });
        });
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TPartTok::TptCall>(tpart_tok2) ? ({
        auto&& name = prism_rtl::as<crate::syntax::lexer::TPartTok::TptCall>(tpart_tok2).a0;
        auto&& attrs = prism_rtl::as<crate::syntax::lexer::TPartTok::TptCall>(tpart_tok2).a1;
        auto&& body_opt = prism_rtl::as<crate::syntax::lexer::TPartTok::TptCall>(tpart_tok2).a2;
        auto&& span = prism_rtl::as<crate::syntax::lexer::TPartTok::TptCall>(tpart_tok2).a3;
        ({
        auto sname = crate::syntax::SName{.sigils = name.sigils, .path_ = name->path_, .span = span};
        auto body_opt_1 = body_opt;
        auto acc_2 = acc;
        auto attrs_3 = attrs;
        auto p__4 = p_;
        auto span_5 = span;
        call_value(fold_job(attrs_3, std::tuple{Array<crate::syntax::Arg>{}, p__4}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::syntax::Arg>, crate::syntax::parser::Ps>>(std::tuple<std::tuple<Array<crate::syntax::Arg>, crate::syntax::parser::Ps>, crate::syntax::lexer::AttrTok>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<crate::syntax::Arg>, crate::syntax::parser::Ps>, crate::syntax::lexer::AttrTok> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto [done, q] = p0;
                auto a = p1;
                (prism_rtl::more(prism_rtl::rc(AttrArg(done, q, a))));
            });
        }));
    }))), [=](std::tuple<Array<crate::syntax::Arg>, crate::syntax::parser::Ps> fold_28254) {
        return ({
            auto [args, p1] = fold_28254;
            auto [inner_opt, p2] = ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<std::optional<Array<crate::syntax::TemplatePart>>, crate::syntax::parser::Ps>> _v;
                if (prism_rtl::is_some(body_opt)) {
                    auto&& b = prism_rtl::some_of(body_opt);
                    _v.set(({
                        auto [ps, q] = template_parts(p1, b);
                        std::tuple{std::optional(ps), q};
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(body_opt)) {
                    _v.set(std::tuple{std::optional<Array<crate::syntax::TemplatePart>>{}, p1});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            (prism_rtl::finished(std::tuple{crate::prelude::push(acc_2, crate::syntax::TemplatePart(crate::syntax::TemplatePart::TpCall{sname, args, inner_opt, span_5})), p2}));
        });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start TemplatePartOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::syntax::TemplatePart>, crate::syntax::parser::Ps>> start_template_part_of(Array<crate::syntax::TemplatePart> acc, crate::syntax::parser::Ps p_, crate::syntax::lexer::TPartTok tpart_tok2) {
    return prism_rtl::make_rc<TemplatePartOf>(acc, p_, tpart_tok2);
}


/// AttrArg: unbounded fn [Arg], Ps, AttrTok -> (([Arg], Ps))
std::tuple<Array<crate::syntax::Arg>, crate::syntax::parser::Ps> attr_arg(const Array<crate::syntax::Arg>& done, const crate::syntax::parser::Ps& p_, const crate::syntax::lexer::AttrTok& a) {
    auto [value, q] = parse_nested(p_, a->tokens, a.span);
    return std::tuple{crate::prelude::push(done, crate::syntax::Arg{.name = std::optional(crate::syntax::Ident{.name = a.name, .span = a.span}), .value = value, .span = a.span}), q};
}


prism_rtl::Turn<std::tuple<Array<crate::syntax::Arg>, crate::syntax::parser::Ps>> AttrArg::cycle() const {
    const auto& done = this->done;
    const auto& p_ = this->p_;
    const auto& a = this->a;
    auto a_1 = a;
    auto done_2 = done;
    auto p__3 = p_;
    return call_then(start_parse_nested(p__3, a_1->tokens, a_1.span), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_nested_28628) {
        return ({
            auto [value, q] = parse_nested_28628;
            (prism_rtl::finished(std::tuple{crate::prelude::push(done_2, crate::syntax::Arg{.name = std::optional(crate::syntax::Ident{.name = a_1.name, .span = a_1.span}), .value = value, .span = a_1.span}), q}));
        });
    });
}


/// `Start AttrArg, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::syntax::Arg>, crate::syntax::parser::Ps>> start_attr_arg(Array<crate::syntax::Arg> done, crate::syntax::parser::Ps p_, crate::syntax::lexer::AttrTok a) {
    return prism_rtl::make_rc<AttrArg>(done, p_, a);
}


/// ParseLambda: unbounded fn Ps -> ((Expr, Ps))
std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_lambda(const crate::syntax::parser::Ps& p0) {
    auto start = crate::syntax::parser::here(p0);
    auto p_ = crate::syntax::parser::adv(p0);
    auto [params_opt, p1] = crate::syntax::parser::kind(p_) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KLambdaBar{true})
        ? lambda_params(crate::syntax::parser::adv(p_))
        : std::tuple{std::optional<Array<crate::syntax::Pattern_>>{}, p_};
    return crate::syntax::parser::at_open_l(p1)
        ? ({
        auto [block, q] = crate::syntax::parser::blocks::parse_indented_block(p1);
        std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ELambda{params_opt, prism_rtl::rc(crate::syntax::LambdaBody(crate::syntax::LambdaBody::LbBlock{block}))})), .span = crate::syntax::parser::to(start, block.span)}, q};
    })
        : ({
        auto [body, q] = parse_expr(p1);
        std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ELambda{params_opt, prism_rtl::rc(crate::syntax::LambdaBody(crate::syntax::LambdaBody::LbExpr{prism_rtl::rc(body)}))})), .span = crate::syntax::parser::to(start, body.span)}, q};
    });
}


prism_rtl::Turn<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> ParseLambda::cycle() const {
    const auto& p0 = this->p0;
    auto start = crate::syntax::parser::here(p0);
    auto p_ = crate::syntax::parser::adv(p0);
    auto [params_opt, p1] = crate::syntax::parser::kind(p_) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KLambdaBar{true})
        ? lambda_params(crate::syntax::parser::adv(p_))
        : std::tuple{std::optional<Array<crate::syntax::Pattern_>>{}, p_};
    return crate::syntax::parser::at_open_l(p1)
        ? call_then(crate::syntax::parser::blocks::start_parse_indented_block(p1), [=](std::tuple<crate::syntax::Block, crate::syntax::parser::Ps> parse_indented_block_29257) {
        return ({
            auto [block, q] = parse_indented_block_29257;
            (prism_rtl::finished(std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ELambda{params_opt, prism_rtl::rc(crate::syntax::LambdaBody(crate::syntax::LambdaBody::LbBlock{block}))})), .span = crate::syntax::parser::to(start, block.span)}, q}));
        });
    })
        : call_then(start_parse_expr(p1), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_expr_29405) {
        return ({
            auto [body, q] = parse_expr_29405;
            (prism_rtl::finished(std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ELambda{params_opt, prism_rtl::rc(crate::syntax::LambdaBody(crate::syntax::LambdaBody::LbExpr{prism_rtl::rc(body)}))})), .span = crate::syntax::parser::to(start, body.span)}, q}));
        });
    });
}


/// `Start ParseLambda, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> start_parse_lambda(crate::syntax::parser::Ps p0) {
    return prism_rtl::make_rc<ParseLambda>(p0);
}


/// LambdaParams: unbounded fn Ps -> ((?[Pattern], Ps))
std::tuple<std::optional<Array<crate::syntax::Pattern_>>, crate::syntax::parser::Ps> lambda_params(const crate::syntax::parser::Ps& p_) {
    auto [ps, p1] = crate::syntax::parser::kind(p_) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KLambdaBar{false})
        ? std::tuple{Array<crate::syntax::Pattern_>{}, p_}
        : crate::syntax::parser::commas(p_, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::Pattern_, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([=](crate::syntax::parser::Ps p0) {
        return entered(once_job([=]() {
            return ({
                auto q = p0;
                (prism_rtl::more(prism_rtl::rc(crate::syntax::parser::types::ParsePattern(q, false))));
            });
        }));
    })));
    return crate::syntax::parser::kind(p1) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KLambdaBar{false})
        ? std::tuple{std::optional(ps), crate::syntax::parser::adv(p1)}
        : std::tuple{std::optional<Array<crate::syntax::Pattern_>>{}, crate::syntax::parser::error_here(p1, Text::lit("expected `|` to close the lambda\'s parameters"))};
}


prism_rtl::Turn<std::tuple<std::optional<Array<crate::syntax::Pattern_>>, crate::syntax::parser::Ps>> LambdaParams::cycle() const {
    const auto& p_ = this->p_;
    auto [ps, p1] = crate::syntax::parser::kind(p_) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KLambdaBar{false})
        ? std::tuple{Array<crate::syntax::Pattern_>{}, p_}
        : crate::syntax::parser::commas(p_, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::Pattern_, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([=](crate::syntax::parser::Ps p0) {
        return entered(once_job([=]() {
            return ({
                auto q = p0;
                (prism_rtl::more(prism_rtl::rc(crate::syntax::parser::types::ParsePattern(q, false))));
            });
        }));
    })));
    return crate::syntax::parser::kind(p1) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KLambdaBar{false})
        ? prism_rtl::finished(std::tuple{std::optional(ps), crate::syntax::parser::adv(p1)})
        : prism_rtl::finished(std::tuple{std::optional<Array<crate::syntax::Pattern_>>{}, crate::syntax::parser::error_here(p1, Text::lit("expected `|` to close the lambda\'s parameters"))});
}


/// `Start LambdaParams, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<std::optional<Array<crate::syntax::Pattern_>>, crate::syntax::parser::Ps>> start_lambda_params(crate::syntax::parser::Ps p_) {
    return prism_rtl::make_rc<LambdaParams>(p_);
}


/// ParseCond: unbounded fn Ps, Bool -> ((Cond, Ps))
std::tuple<crate::syntax::Cond, crate::syntax::parser::Ps> parse_cond(const crate::syntax::parser::Ps& p_, const bool& allow_guard) {
    auto [pattern, q] = crate::syntax::parser::types::parse_pattern(p_, true);
    return (!q->bad) && crate::syntax::parser::at_op(q, Text::lit("<-"))
        ? ({
        auto [value, q1] = parse_expr(crate::syntax::parser::adv(q));
        allow_guard && crate::syntax::parser::at_kw(q1, Text::lit("if"))
        ? ({
        auto [guard, q2] = parse_expr(crate::syntax::parser::adv(q1));
        std::tuple{crate::syntax::Cond(crate::syntax::Cond::CondBind{pattern, prism_rtl::rc(value), prism_rtl::rc(std::optional(guard))}), q2};
    })
        : std::tuple{crate::syntax::Cond(crate::syntax::Cond::CondBind{pattern, prism_rtl::rc(value), prism_rtl::rc(std::optional<crate::syntax::Expr>{})}), q1};
    })
        : ({
        auto [e, q1] = parse_expr(p_);
        std::tuple{crate::syntax::Cond(crate::syntax::Cond::CondExpr{prism_rtl::rc(e)}), q1};
    });
}


prism_rtl::Turn<std::tuple<crate::syntax::Cond, crate::syntax::parser::Ps>> ParseCond::cycle() const {
    const auto& p_ = this->p_;
    const auto& allow_guard = this->allow_guard;
    auto allow_guard_1 = allow_guard;
    auto p__2 = p_;
    return call_then(crate::syntax::parser::types::start_parse_pattern(p__2, true), [=](std::tuple<crate::syntax::Pattern_, crate::syntax::parser::Ps> parse_pattern_29990) {
        return ({
            auto [pattern, q] = parse_pattern_29990;
            (!q->bad) && crate::syntax::parser::at_op(q, Text::lit("<-"))
            ? call_then(start_parse_expr(crate::syntax::parser::adv(q)), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_expr_30076) {
            return ({
                auto [value, q1] = parse_expr_30076;
                allow_guard_1 && crate::syntax::parser::at_kw(q1, Text::lit("if"))
                ? call_then(start_parse_expr(crate::syntax::parser::adv(q1)), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_expr_30169) {
                return ({
                    auto [guard, q2] = parse_expr_30169;
                    (prism_rtl::finished(std::tuple{crate::syntax::Cond(crate::syntax::Cond::CondBind{pattern, prism_rtl::rc(value), prism_rtl::rc(std::optional(guard))}), q2}));
                });
            })
                : prism_rtl::finished(std::tuple{crate::syntax::Cond(crate::syntax::Cond::CondBind{pattern, prism_rtl::rc(value), prism_rtl::rc(std::optional<crate::syntax::Expr>{})}), q1});
            });
        })
            : call_then(start_parse_expr(p__2), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_expr_30332) {
            return ({
                auto [e, q1] = parse_expr_30332;
                (prism_rtl::finished(std::tuple{crate::syntax::Cond(crate::syntax::Cond::CondExpr{prism_rtl::rc(e)}), q1}));
            });
        });
        });
    });
}


/// `Start ParseCond, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Cond, crate::syntax::parser::Ps>> start_parse_cond(crate::syntax::parser::Ps p_, bool allow_guard) {
    return prism_rtl::make_rc<ParseCond>(p_, allow_guard);
}


/// ParseIf: unbounded fn Ps -> ((Expr, Ps))
std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_if(const crate::syntax::parser::Ps& p0) {
    auto start = crate::syntax::parser::here(p0);
    auto [cond, p1] = parse_cond(crate::syntax::parser::adv(p0), false);
    auto [then_block, p2] = crate::syntax::parser::blocks::parse_block_after_colon(p1);
    auto p3 = crate::syntax::parser::at_sep(p2) && is_else(crate::syntax::parser::kind_at(p2, Nat(1u)))
        ? crate::syntax::parser::adv(p2)
        : p2;
    return crate::syntax::parser::at_kw(p3, Text::lit("else"))
        ? ({
        auto [else_block, q] = crate::syntax::parser::blocks::parse_block_after_colon(crate::syntax::parser::adv(p3));
        std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EIf{prism_rtl::rc(cond), then_block, std::optional(else_block)})), .span = crate::syntax::parser::to(start, else_block.span)}, q};
    })
        : std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EIf{prism_rtl::rc(cond), then_block, std::optional<crate::syntax::Block>{}})), .span = crate::syntax::parser::to(start, then_block.span)}, p3};
}


prism_rtl::Turn<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> ParseIf::cycle() const {
    const auto& p0 = this->p0;
    auto start = crate::syntax::parser::here(p0);
    auto p0_1 = p0;
    return call_then(start_parse_cond(crate::syntax::parser::adv(p0_1), false), [=](std::tuple<crate::syntax::Cond, crate::syntax::parser::Ps> parse_cond_30565) {
        return ({
            auto [cond, p1] = parse_cond_30565;
            call_then(crate::syntax::parser::blocks::start_parse_block_after_colon(p1), [=](std::tuple<crate::syntax::Block, crate::syntax::parser::Ps> parse_block_after_colon_30619) {
            return ({
                auto [then_block, p2] = parse_block_after_colon_30619;
                auto p3 = crate::syntax::parser::at_sep(p2) && is_else(crate::syntax::parser::kind_at(p2, Nat(1u)))
                    ? crate::syntax::parser::adv(p2)
                    : p2;
                (crate::syntax::parser::at_kw(p3, Text::lit("else"))
                ? call_then(crate::syntax::parser::blocks::start_parse_block_after_colon(crate::syntax::parser::adv(p3)), [=](std::tuple<crate::syntax::Block, crate::syntax::parser::Ps> parse_block_after_colon_30770) {
                return ({
                    auto [else_block, q] = parse_block_after_colon_30770;
                    (prism_rtl::finished(std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EIf{prism_rtl::rc(cond), then_block, std::optional(else_block)})), .span = crate::syntax::parser::to(start, else_block.span)}, q}));
                });
            })
                : prism_rtl::finished(std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EIf{prism_rtl::rc(cond), then_block, std::optional<crate::syntax::Block>{}})), .span = crate::syntax::parser::to(start, then_block.span)}, p3}));
            });
        });
        });
    });
}


/// `Start ParseIf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> start_parse_if(crate::syntax::parser::Ps p0) {
    return prism_rtl::make_rc<ParseIf>(p0);
}


/// IsElse: fn TokKind -> Bool
bool is_else(const crate::syntax::lexer::TokKind& tok_kind0) {
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(tok_kind0)) {
        auto&& c0_0_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(tok_kind0).a0;
        if (c0_0_0 == Text::lit("else")) {
            return true;
        }
    }
    {
        return false;
    }
}


/// ParseMatch: unbounded fn Ps -> ((Expr, Ps))
std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_match(const crate::syntax::parser::Ps& p0) {
    auto start = crate::syntax::parser::here(p0);
    auto [scrutinee, p1] = parse_expr(crate::syntax::parser::adv(p0));
    auto p2 = crate::syntax::parser::expect_colon(p1);
    return crate::syntax::parser::at_open_l(p2)
        ? ({
        auto [arms, q] = match_arms(crate::syntax::parser::adv(p2));
        std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EMatch{prism_rtl::rc(scrutinee), arms})), .span = crate::syntax::parser::to(start, crate::syntax::parser::prev(q))}, q};
    })
        : std::tuple{crate::syntax::parser::decls::no_expr(), crate::syntax::parser::error_here(p2, Text::lit("a `match`\'s arms stand in an indented block after its `:`"))};
}


prism_rtl::Turn<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> ParseMatch::cycle() const {
    const auto& p0 = this->p0;
    auto start = crate::syntax::parser::here(p0);
    auto p0_1 = p0;
    return call_then(start_parse_expr(crate::syntax::parser::adv(p0_1)), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_expr_31351) {
        return ({
            auto [scrutinee, p1] = parse_expr_31351;
            auto p2 = crate::syntax::parser::expect_colon(p1);
            (crate::syntax::parser::at_open_l(p2)
            ? call_then(start_match_arms(crate::syntax::parser::adv(p2)), [=](std::tuple<Array<crate::syntax::Arm>, crate::syntax::parser::Ps> match_arms_31443) {
            return ({
                auto [arms, q] = match_arms_31443;
                (prism_rtl::finished(std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EMatch{prism_rtl::rc(scrutinee), arms})), .span = crate::syntax::parser::to(start, crate::syntax::parser::prev(q))}, q}));
            });
        })
            : prism_rtl::finished(std::tuple{crate::syntax::parser::decls::no_expr(), crate::syntax::parser::error_here(p2, Text::lit("a `match`\'s arms stand in an indented block after its `:`"))}));
        });
    });
}


/// `Start ParseMatch, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> start_parse_match(crate::syntax::parser::Ps p0) {
    return prism_rtl::make_rc<ParseMatch>(p0);
}


/// MatchArms: unbounded fn Ps -> (([Arm], Ps))
std::tuple<Array<crate::syntax::Arm>, crate::syntax::parser::Ps> match_arms(const crate::syntax::parser::Ps& p0) {
    std::tuple<Array<crate::syntax::Arm>, crate::syntax::parser::Ps> this_ = std::tuple{Array<crate::syntax::Arm>{}, p0};
    Array<crate::syntax::Arm> arms = Array<crate::syntax::Arm>{};
    crate::syntax::parser::Ps p_ = p0;
    bool going = true;
    while (going) {
        auto [arm, q] = parse_arm(p_);
        if (!q->bad) {
            arms = crate::prelude::push(arms, arm);
        }
        p_ = crate::syntax::parser::recovered(q);
        {
            auto&& _m = crate::syntax::parser::kind(p_);
            if (prism_rtl::is<crate::syntax::lexer::TokKind::KLaySep>(_m)) {
                p_ = crate::syntax::parser::adv(p_);
            } else if (prism_rtl::is<crate::syntax::lexer::TokKind::KLayClose>(_m)) {
                p_ = crate::syntax::parser::adv(p_);
                going = false;
            } else if (prism_rtl::is<crate::syntax::lexer::TokKind::KEof>(_m)) {
                going = false;
            } else {
                p_ = crate::syntax::parser::recover(crate::syntax::parser::complain(p_, Text::lit("expected the end of the arm")));
            }
        }
    }
    this_ = std::tuple{arms, p_};
    return this_;
}


prism_rtl::Turn<std::tuple<Array<crate::syntax::Arm>, crate::syntax::parser::Ps>> MatchArms::cycle() const {
    const auto& p0 = this->p0;
    std::tuple<Array<crate::syntax::Arm>, crate::syntax::parser::Ps> this_ = std::tuple{Array<crate::syntax::Arm>{}, p0};
    Array<crate::syntax::Arm> arms = Array<crate::syntax::Arm>{};
    crate::syntax::parser::Ps p_ = p0;
    bool going = true;
    return call_then(loop_job(std::tuple{this_, arms, going, p_}, [=](std::tuple<std::tuple<Array<crate::syntax::Arm>, crate::syntax::parser::Ps>, Array<crate::syntax::Arm>, bool, crate::syntax::parser::Ps> _p0) {
        auto this_ = std::get<0>(_p0);
        auto arms = std::get<1>(_p0);
        auto going = std::get<2>(_p0);
        auto p_ = std::get<3>(_p0);
        return going
            ? ({
            auto [arm, q] = parse_arm(p_);
            if (!q->bad) {
                arms = crate::prelude::push(arms, arm);
            }
            p_ = crate::syntax::parser::recovered(q);
            {
                auto&& _m = crate::syntax::parser::kind(p_);
                if (prism_rtl::is<crate::syntax::lexer::TokKind::KLaySep>(_m)) {
                    p_ = crate::syntax::parser::adv(p_);
                } else if (prism_rtl::is<crate::syntax::lexer::TokKind::KLayClose>(_m)) {
                    p_ = crate::syntax::parser::adv(p_);
                    going = false;
                } else if (prism_rtl::is<crate::syntax::lexer::TokKind::KEof>(_m)) {
                    going = false;
                } else {
                    p_ = crate::syntax::parser::recover(crate::syntax::parser::complain(p_, Text::lit("expected the end of the arm")));
                }
            }
            Expected<std::tuple<std::tuple<Array<crate::syntax::Arm>, crate::syntax::parser::Ps>, Array<crate::syntax::Arm>, bool, crate::syntax::parser::Ps>, std::tuple<std::tuple<Array<crate::syntax::Arm>, crate::syntax::parser::Ps>, Array<crate::syntax::Arm>, bool, crate::syntax::parser::Ps>>(std::tuple{this_, arms, going, p_});
        })
            : Expected<std::tuple<std::tuple<Array<crate::syntax::Arm>, crate::syntax::parser::Ps>, Array<crate::syntax::Arm>, bool, crate::syntax::parser::Ps>, std::tuple<std::tuple<Array<crate::syntax::Arm>, crate::syntax::parser::Ps>, Array<crate::syntax::Arm>, bool, crate::syntax::parser::Ps>>(unexpected(std::tuple{this_, arms, going, p_}));
    }), [=](std::tuple<std::tuple<Array<crate::syntax::Arm>, crate::syntax::parser::Ps>, Array<crate::syntax::Arm>, bool, crate::syntax::parser::Ps> _p0) {
        auto this_ = std::get<0>(_p0);
        auto arms = std::get<1>(_p0);
        auto going = std::get<2>(_p0);
        auto p_ = std::get<3>(_p0);
        return ({
            this_ = std::tuple{arms, p_};
            (prism_rtl::finished(this_));
        });
    });
}


/// `Start MatchArms, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::syntax::Arm>, crate::syntax::parser::Ps>> start_match_arms(crate::syntax::parser::Ps p0) {
    return prism_rtl::make_rc<MatchArms>(p0);
}


/// ParseArm: unbounded fn Ps -> ((Arm, Ps))
std::tuple<crate::syntax::Arm, crate::syntax::parser::Ps> parse_arm(const crate::syntax::parser::Ps& p_) {
    auto start = crate::syntax::parser::here(p_);
    return crate::syntax::parser::at_kw(p_, Text::lit("otherwise"))
        ? ({
        auto [body, q] = crate::syntax::parser::blocks::parse_block_after_colon(crate::syntax::parser::adv(p_));
        std::tuple{crate::syntax::Arm{.pattern = std::optional<crate::syntax::Pattern_>{}, .guard = std::optional<crate::syntax::Expr>{}, .body = body, .span = crate::syntax::parser::to(start, body.span)}, q};
    })
        : crate::syntax::parser::at_kw(p_, Text::lit("ignore")) && (crate::syntax::parser::kind_at(p_, Nat(1u)) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KColon{}))
        ? std::tuple{crate::syntax::Arm{.pattern = std::optional<crate::syntax::Pattern_>{}, .guard = std::optional<crate::syntax::Expr>{}, .body = crate::syntax::parser::decls::no_block(), .span = start}, crate::syntax::parser::error_at(p_, crate::syntax::parser::here(p_), Text::lit("an arm beginning `ignore:` would read as \"ignore these cases\": the catch-all is `otherwise:`"))}
        : ({
        auto [pattern, p1] = crate::syntax::parser::types::parse_pattern(p_, true);
        auto [guard_opt, p2] = crate::syntax::parser::at_kw(p1, Text::lit("if"))
            ? optional_expr(crate::syntax::parser::adv(p1))
            : std::tuple{std::optional<crate::syntax::Expr>{}, p1};
        auto [body, p3] = crate::syntax::parser::blocks::parse_block_after_colon(p2);
        std::tuple{crate::syntax::Arm{.pattern = std::optional(pattern), .guard = guard_opt, .body = body, .span = crate::syntax::parser::to(start, body.span)}, p3};
    });
}


/// OptionalExpr: unbounded fn Ps -> ((?Expr, Ps))
std::tuple<std::optional<crate::syntax::Expr>, crate::syntax::parser::Ps> optional_expr(const crate::syntax::parser::Ps& p_) {
    auto [e, q] = parse_expr(p_);
    return std::tuple{std::optional(e), q};
}


/// ParseFor: unbounded fn Ps -> ((Expr, Ps))
std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_for(const crate::syntax::parser::Ps& p0) {
    auto start = crate::syntax::parser::here(p0);
    auto p_ = crate::syntax::parser::adv(p0);
    auto [binders_opt, p1] = for_binders_of(p_);
    auto [source, p2] = parse_expr(p1);
    auto [body, p3] = crate::syntax::parser::blocks::parse_block_after_colon(p2);
    return std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EFor{binders_opt, prism_rtl::rc(source), body})), .span = crate::syntax::parser::to(start, body.span)}, p3};
}


prism_rtl::Turn<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> ParseFor::cycle() const {
    const auto& p0 = this->p0;
    auto start = crate::syntax::parser::here(p0);
    auto p_ = crate::syntax::parser::adv(p0);
    return call_then(start_for_binders_of(p_), [=](std::tuple<std::optional<crate::syntax::ForBinders>, crate::syntax::parser::Ps> for_binders_of_33299) {
        return ({
            auto [binders_opt, p1] = for_binders_of_33299;
            call_then(start_parse_expr(p1), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_expr_33339) {
            return ({
                auto [source, p2] = parse_expr_33339;
                call_then(crate::syntax::parser::blocks::start_parse_block_after_colon(p2), [=](std::tuple<crate::syntax::Block, crate::syntax::parser::Ps> parse_block_after_colon_33375) {
                return ({
                    auto [body, p3] = parse_block_after_colon_33375;
                    (prism_rtl::finished(std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EFor{binders_opt, prism_rtl::rc(source), body})), .span = crate::syntax::parser::to(start, body.span)}, p3}));
                });
            });
            });
        });
        });
    });
}


/// `Start ParseFor, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> start_parse_for(crate::syntax::parser::Ps p0) {
    return prism_rtl::make_rc<ParseFor>(p0);
}


/// ForBindersOf: unbounded fn Ps -> ((?ForBinders, Ps))
std::tuple<std::optional<crate::syntax::ForBinders>, crate::syntax::parser::Ps> for_binders_of(const crate::syntax::parser::Ps& p_) {
    auto [first_, q1] = crate::syntax::parser::types::parse_pattern(p_, false);
    auto [second_opt, q2] = crate::syntax::parser::at_comma(q1)
        ? optional_pattern(crate::syntax::parser::adv(q1))
        : std::tuple{std::optional<crate::syntax::Pattern_>{}, q1};
    return (!q2->bad) && crate::syntax::parser::at_op(q2, Text::lit("<-"))
        ? std::tuple{std::optional(crate::syntax::ForBinders{.first = first_, .second = second_opt}), crate::syntax::parser::adv(q2)}
        : std::tuple{std::optional<crate::syntax::ForBinders>{}, p_};
}


prism_rtl::Turn<std::tuple<std::optional<crate::syntax::ForBinders>, crate::syntax::parser::Ps>> ForBindersOf::cycle() const {
    const auto& p_ = this->p_;
    auto p__1 = p_;
    return call_then(crate::syntax::parser::types::start_parse_pattern(p__1, false), [=](std::tuple<crate::syntax::Pattern_, crate::syntax::parser::Ps> parse_pattern_33660) {
        return ({
            auto [first_, q1] = parse_pattern_33660;
            auto [second_opt, q2] = crate::syntax::parser::at_comma(q1)
                ? optional_pattern(crate::syntax::parser::adv(q1))
                : std::tuple{std::optional<crate::syntax::Pattern_>{}, q1};
            (!q2->bad) && crate::syntax::parser::at_op(q2, Text::lit("<-"))
            ? prism_rtl::finished(std::tuple{std::optional(crate::syntax::ForBinders{.first = first_, .second = second_opt}), crate::syntax::parser::adv(q2)})
            : prism_rtl::finished(std::tuple{std::optional<crate::syntax::ForBinders>{}, p__1});
        });
    });
}


/// `Start ForBindersOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<std::optional<crate::syntax::ForBinders>, crate::syntax::parser::Ps>> start_for_binders_of(crate::syntax::parser::Ps p_) {
    return prism_rtl::make_rc<ForBindersOf>(p_);
}


/// OptionalPattern: unbounded fn Ps -> ((?Pattern, Ps))
std::tuple<std::optional<crate::syntax::Pattern_>, crate::syntax::parser::Ps> optional_pattern(const crate::syntax::parser::Ps& p_) {
    auto [pat, q] = crate::syntax::parser::types::parse_pattern(p_, false);
    return std::tuple{std::optional(pat), q};
}

}  // namespace crate::syntax::parser::expr
