// The module `Lower.Templates`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <lower/templates/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/types/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>

// The module `Lower.Templates`, from `target/bootstrap/cpp-src/prismc/lower/templates.prism`.
namespace crate::lower::templates {

/// TemplateValue: unbounded fn Lx, Env, Template -> Vl
crate::lower::types::Vl template_value_f(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Template& tp_p2) {
    auto start_p3 = Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaMut{Text::lit("out")}), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("String::new"), Array<crate::lower::model::Ex>{}})})});
    auto dos_p4 = crate::prelude::run_to_end(crate::prelude::fold_job(tp_p2.parts_p, start_p3, ({
        auto lx_p0x = lx_p0;
        auto env_p1x = env_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(std::tuple<Array<crate::lower::model::Do>, crate::syntax::TemplatePart>)>>(prism_rtl::rc([=, lx_p0x = std::move(lx_p0x), env_p1x = std::move(env_p1x)](std::tuple<Array<crate::lower::model::Do>, crate::syntax::TemplatePart> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_p0xy = lx_p0x;
            auto env_p1xy = env_p1x;
            (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xy = std::move(lx_p0xy), env_p1xy = std::move(env_p1xy)]() {
            return ({
                auto acc_p5 = p0;
                auto part_p6 = p1;
                (crate::prelude::call_then(start_template_part_dos_f(lx_p0xy, env_p1xy, part_p6), [=, acc_p5 = std::move(acc_p5)](Array<crate::lower::model::Do> template_part_dos_f_1601) { return prism_rtl::finished(crate::prelude::append(acc_p5, template_part_dos_f_1601)); }));
            });
        })));
        });
    })));
    })));
    return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBlock{dos_p4, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Text::from"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("out")})})}))}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutText{})});
}


prism_rtl::Turn<crate::lower::types::Vl> TemplateValue::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& tp_p2 = this->tp_p2;
    auto start_p3 = Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaMut{Text::lit("out")}), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("String::new"), Array<crate::lower::model::Ex>{}})})});
    auto env_p1x = env_p1;
    auto lx_p0x = lx_p0;
    auto tp_p2x = tp_p2;
    return crate::prelude::call_value(crate::prelude::fold_job(prism_rtl::deref(tp_p2x).parts_p, start_p3, ({
        auto lx_p0xx = lx_p0x;
        auto env_p1xx = env_p1x;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(std::tuple<Array<crate::lower::model::Do>, crate::syntax::TemplatePart>)>>(prism_rtl::rc([=, lx_p0xx = std::move(lx_p0xx), env_p1xx = std::move(env_p1xx)](std::tuple<Array<crate::lower::model::Do>, crate::syntax::TemplatePart> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_p0xxy = lx_p0xx;
            auto env_p1xxy = env_p1xx;
            (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xxy = std::move(lx_p0xxy), env_p1xxy = std::move(env_p1xxy)]() {
            return ({
                auto acc_p5 = p0;
                auto part_p6 = p1;
                (crate::prelude::call_then(start_template_part_dos_f(lx_p0xxy, env_p1xxy, part_p6), [=, acc_p5 = std::move(acc_p5)](Array<crate::lower::model::Do> template_part_dos_f_1601) { return prism_rtl::finished(crate::prelude::append(acc_p5, template_part_dos_f_1601)); }));
            });
        })));
        });
    })));
    })), [=](Array<crate::lower::model::Do> fold_1553) {
        return ({
            auto dos_p4 = fold_1553;
            (prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBlock{dos_p4, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Text::from"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("out")})})}))}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutText{})})));
        });
    });
}


/// `Start TemplateValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_template_value_f(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Template tp_p2) {
    return prism_rtl::make_rc<TemplateValue>(lx_p0, env_p1, tp_p2);
}


/// TemplatePartDos: unbounded fn Lx, Env, TemplatePart -> [Do]
Array<crate::lower::model::Do> template_part_dos_f(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::TemplatePart& part_p2) {
    if (prism_rtl::is<crate::syntax::TemplatePart::TpText>(part_p2)) {
        auto&& t_p3 = prism_rtl::as<crate::syntax::TemplatePart::TpText>(part_p2).a0;
        return Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("out")})), Text::lit("push_str"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XStr{t_p3})})})})});
    }
    if (prism_rtl::is<crate::syntax::TemplatePart::TpPlaceholder>(part_p2)) {
        auto&& x_p4 = prism_rtl::as<crate::syntax::TemplatePart::TpPlaceholder>(part_p2).a0;
        auto&& col_o5 = prism_rtl::as<crate::syntax::TemplatePart::TpPlaceholder>(part_p2).a1;
        auto v_p6 = crate::lower::expr::value_of_f(lx_p0, env_p1, x_p4);
        auto column_p7 = ({
            __label__ _done;
            prism_rtl::Slot<crate::lower::model::Ex> _v;
            if (prism_rtl::is_some(col_o5)) {
                auto&& c_p8 = prism_rtl::some_of(col_o5);
                _v.set(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XIndex{c_p8})})}));
                goto _done;
            }
            if (prism_rtl::is_none(col_o5)) {
                _v.set(crate::lower::model::Ex(crate::lower::model::Ex::XNone{}));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        return Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XCall{crate::lower::helper_f(Text::lit("place")), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRefMut{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("out")}))}), shown_text_f(v_p6), column_p7})})})});
    }
    if (prism_rtl::is<crate::syntax::TemplatePart::TpBlock>(part_p2)) {
        auto&& b_p9 = prism_rtl::as<crate::syntax::TemplatePart::TpBlock>(part_p2).a0;
        auto v_pa = crate::lower::expr::block_value_f(lx_p0, env_p1, b_p9);
        return crate::lower::types::value_ty_f(v_pa) == crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})
            ? Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::types::own_f(v_pa)})})
            : Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XCall{crate::lower::helper_f(Text::lit("place")), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRefMut{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("out")}))}), shown_text_f(v_pa), crate::lower::model::Ex(crate::lower::model::Ex::XNone{})})})})});
    }
    if (prism_rtl::is<crate::syntax::TemplatePart::TpCall>(part_p2)) {
        auto&& n_pb = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(part_p2).a0;
        auto&& args_pc = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(part_p2).a1;
        auto&& parts_od = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(part_p2).a2;
        auto plain_pe = crate::syntax::SName{.sigils_p = crate::syntax::lexer::chars::after_first_f(prism_rtl::deref(n_pb).sigils_p), .path_p = prism_rtl::deref(n_pb).path_p, .span_p = prism_rtl::deref(n_pb).span_p};
        auto&& _qk_oj = crate::check::env::names::resolve_value_f(lx_p0.g_p, lx_p0.home_p, n_pb);
        auto&& qk_oj = std::get<0>(_qk_oj);
        auto&& _qk2_ok = crate::check::env::names::resolve_value_f(lx_p0.g_p, lx_p0.home_p, plain_pe);
        auto&& qk2_ok = std::get<0>(_qk2_ok);
        auto callee_pf = ({
            __label__ _done;
            prism_rtl::Slot<Text> _v;
            if (prism_rtl::is_some(qk_oj)) {
                auto&& q_pl = prism_rtl::some_of(qk_oj);
                _v.set(crate::lower::value_path_f(lx_p0, q_pl));
                goto _done;
            }
            if (prism_rtl::is_none(qk_oj)) {
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Text> _v;
                    if (prism_rtl::is_some(qk2_ok)) {
                        auto&& q_pm = prism_rtl::some_of(qk2_ok);
                        _v.set(crate::lower::value_path_f(lx_p0, q_pm));
                        goto _done;
                    }
                    if (prism_rtl::is_none(qk2_ok)) {
                        _v.set(crate::lower::snake_f(crate::check::env::sname_key_f(n_pb)));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto body_pg = ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::lower::model::Ex>> _v;
            if (prism_rtl::is_some(parts_od)) {
                auto&& ps_pn = prism_rtl::some_of(parts_od);
                _v.set(({
                    auto inner_po = crate::prelude::run_to_end(crate::prelude::fold_job(ps_pn, Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaMut{Text::lit("out")}), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("String::new"), Array<crate::lower::model::Ex>{}})})}), ({
                        auto lx_p0x = lx_p0;
                        auto env_p1x = env_p1;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(std::tuple<Array<crate::lower::model::Do>, crate::syntax::TemplatePart>)>>(prism_rtl::rc([=, lx_p0x = std::move(lx_p0x), env_p1x = std::move(env_p1x)](std::tuple<Array<crate::lower::model::Do>, crate::syntax::TemplatePart> _p0) {
                        auto&& p0 = std::get<0>(_p0);
                        auto&& p1 = std::get<1>(_p0);
                        return ({
                            auto lx_p0xy = lx_p0x;
                            auto env_p1xy = env_p1x;
                            (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xy = std::move(lx_p0xy), env_p1xy = std::move(env_p1xy)]() {
                            return ({
                                auto acc_pp = p0;
                                auto p_pq = p1;
                                (crate::prelude::call_then(start_template_part_dos_f(lx_p0xy, env_p1xy, p_pq), [=, acc_pp = std::move(acc_pp)](Array<crate::lower::model::Do> template_part_dos_f_2929) { return prism_rtl::finished(crate::prelude::append(acc_pp, template_part_dos_f_2929)); }));
                            });
                        })));
                        });
                    })));
                    })));
                    (Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XBlock{inner_po, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Text::from"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("out")})})}))}))})}));
                }));
                goto _done;
            }
            if (prism_rtl::is_none(parts_od)) {
                _v.set(Array<crate::lower::model::Ex>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto passed_ph = ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::lower::model::Ex>> _v;
            if (prism_rtl::is_some(qk_oj)) {
                auto&& q_pr = prism_rtl::some_of(qk_oj);
                _v.set(template_args_f(lx_p0, env_p1, q_pr, args_pc, body_pg));
                goto _done;
            }
            if (prism_rtl::is_none(qk_oj)) {
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Array<crate::lower::model::Ex>> _v;
                    if (prism_rtl::is_some(qk2_ok)) {
                        auto&& q_ps = prism_rtl::some_of(qk2_ok);
                        _v.set(template_args_f(lx_p0, env_p1, q_ps, args_pc, body_pg));
                        goto _done;
                    }
                    if (prism_rtl::is_none(qk2_ok)) {
                        _v.set(crate::prelude::append(crate::prelude::run_to_end(crate::prelude::each_job(args_pc, ({
                            auto lx_p0x = lx_p0;
                            auto env_p1x = env_p1;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::Arg)>>(prism_rtl::rc([=, lx_p0x = std::move(lx_p0x), env_p1x = std::move(env_p1x)](crate::syntax::Arg p0) {
                            return ({
                                auto lx_p0xy = lx_p0x;
                                auto env_p1xy = env_p1x;
                                (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xy = std::move(lx_p0xy), env_p1xy = std::move(env_p1xy)]() {
                                return ({
                                    auto a_pt = p0;
                                    (prism_rtl::more(prism_rtl::rc(crate::lower::expr::Argument(lx_p0xy, env_p1xy, prism_rtl::deref(a_pt).value_p))));
                                });
                            })));
                            });
                        })));
                        }))), body_pg));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto call_pi = crate::lower::model::Ex(crate::lower::model::Ex::XCall{callee_pf, passed_ph});
        return Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XCall{crate::lower::helper_f(Text::lit("place")), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRefMut{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("out")}))}), crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(call_pi)}), crate::lower::model::Ex(crate::lower::model::Ex::XNone{})})})})});
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<crate::lower::model::Do>> TemplatePartDos::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& part_p2 = this->part_p2;
    return ({
        prism_rtl::is<crate::syntax::TemplatePart::TpText>(part_p2) ? ({
        auto&& t_p3 = prism_rtl::as<crate::syntax::TemplatePart::TpText>(part_p2).a0;
        prism_rtl::finished(Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("out")})), Text::lit("push_str"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XStr{t_p3})})})})}));
    })
        : prism_rtl::is<crate::syntax::TemplatePart::TpPlaceholder>(part_p2) ? ({
        auto&& x_p4 = prism_rtl::as<crate::syntax::TemplatePart::TpPlaceholder>(part_p2).a0;
        auto&& col_o5 = prism_rtl::as<crate::syntax::TemplatePart::TpPlaceholder>(part_p2).a1;
        ({
        auto col_o5x = col_o5;
        auto env_p1x = env_p1;
        auto lx_p0x = lx_p0;
        auto x_p4x = x_p4;
        (crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0x, env_p1x, x_p4x), [=, col_o5x = std::move(col_o5x)](crate::lower::types::Vl value_of_f_1931) {
        return ({
            auto v_p6 = value_of_f_1931;
            auto column_p7 = ({
                __label__ _done;
                prism_rtl::Slot<crate::lower::model::Ex> _v;
                if (prism_rtl::is_some(col_o5x)) {
                    auto&& c_p8 = prism_rtl::some_of(col_o5x);
                    _v.set(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XIndex{c_p8})})}));
                    goto _done;
                }
                if (prism_rtl::is_none(col_o5x)) {
                    _v.set(crate::lower::model::Ex(crate::lower::model::Ex::XNone{}));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            (prism_rtl::finished(Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XCall{crate::lower::helper_f(Text::lit("place")), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRefMut{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("out")}))}), shown_text_f(v_p6), column_p7})})})})));
        });
    }));
    });
    })
        : prism_rtl::is<crate::syntax::TemplatePart::TpBlock>(part_p2) ? ({
        auto&& b_p9 = prism_rtl::as<crate::syntax::TemplatePart::TpBlock>(part_p2).a0;
        ({
        auto b_p9x = b_p9;
        auto env_p1x = env_p1;
        auto lx_p0x = lx_p0;
        (crate::prelude::call_then(crate::lower::expr::start_block_value_f(lx_p0x, env_p1x, b_p9x), [=](crate::lower::types::Vl block_value_f_2174) {
        return ({
            auto v_pa = block_value_f_2174;
            (crate::lower::types::value_ty_f(v_pa) == crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})
            ? prism_rtl::finished(Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::types::own_f(v_pa)})}))
            : prism_rtl::finished(Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XCall{crate::lower::helper_f(Text::lit("place")), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRefMut{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("out")}))}), shown_text_f(v_pa), crate::lower::model::Ex(crate::lower::model::Ex::XNone{})})})})})));
        });
    }));
    });
    })
        : prism_rtl::is<crate::syntax::TemplatePart::TpCall>(part_p2) ? ({
        auto&& n_pb = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(part_p2).a0;
        auto&& args_pc = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(part_p2).a1;
        auto&& parts_od = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(part_p2).a2;
        ({
        auto plain_pe = crate::syntax::SName{.sigils_p = crate::syntax::lexer::chars::after_first_f(prism_rtl::deref(n_pb).sigils_p), .path_p = prism_rtl::deref(n_pb).path_p, .span_p = prism_rtl::deref(n_pb).span_p};
        auto&& _qk_oj = crate::check::env::names::resolve_value_f(prism_rtl::deref(lx_p0).g_p, prism_rtl::deref(lx_p0).home_p, n_pb);
        auto&& qk_oj = std::get<0>(_qk_oj);
        auto&& _qk2_ok = crate::check::env::names::resolve_value_f(prism_rtl::deref(lx_p0).g_p, prism_rtl::deref(lx_p0).home_p, plain_pe);
        auto&& qk2_ok = std::get<0>(_qk2_ok);
        auto callee_pf = ({
            __label__ _done;
            prism_rtl::Slot<Text> _v;
            if (prism_rtl::is_some(qk_oj)) {
                auto&& q_pl = prism_rtl::some_of(qk_oj);
                _v.set(crate::lower::value_path_f(lx_p0, q_pl));
                goto _done;
            }
            if (prism_rtl::is_none(qk_oj)) {
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Text> _v;
                    if (prism_rtl::is_some(qk2_ok)) {
                        auto&& q_pm = prism_rtl::some_of(qk2_ok);
                        _v.set(crate::lower::value_path_f(lx_p0, q_pm));
                        goto _done;
                    }
                    if (prism_rtl::is_none(qk2_ok)) {
                        _v.set(crate::lower::snake_f(crate::check::env::sname_key_f(n_pb)));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto body_pg = ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::lower::model::Ex>> _v;
            if (prism_rtl::is_some(parts_od)) {
                auto&& ps_pn = prism_rtl::some_of(parts_od);
                _v.set(({
                    auto inner_po = crate::prelude::run_to_end(crate::prelude::fold_job(ps_pn, Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaMut{Text::lit("out")}), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("String::new"), Array<crate::lower::model::Ex>{}})})}), ({
                        auto lx_p0x = lx_p0;
                        auto env_p1x = env_p1;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(std::tuple<Array<crate::lower::model::Do>, crate::syntax::TemplatePart>)>>(prism_rtl::rc([=, lx_p0x = std::move(lx_p0x), env_p1x = std::move(env_p1x)](std::tuple<Array<crate::lower::model::Do>, crate::syntax::TemplatePart> _p0) {
                        auto&& p0 = std::get<0>(_p0);
                        auto&& p1 = std::get<1>(_p0);
                        return ({
                            auto lx_p0xy = lx_p0x;
                            auto env_p1xy = env_p1x;
                            (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xy = std::move(lx_p0xy), env_p1xy = std::move(env_p1xy)]() {
                            return ({
                                auto acc_pp = p0;
                                auto p_pq = p1;
                                (crate::prelude::call_then(start_template_part_dos_f(lx_p0xy, env_p1xy, p_pq), [=, acc_pp = std::move(acc_pp)](Array<crate::lower::model::Do> template_part_dos_f_2929) { return prism_rtl::finished(crate::prelude::append(acc_pp, template_part_dos_f_2929)); }));
                            });
                        })));
                        });
                    })));
                    })));
                    (Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XBlock{inner_po, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Text::from"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("out")})})}))}))})}));
                }));
                goto _done;
            }
            if (prism_rtl::is_none(parts_od)) {
                _v.set(Array<crate::lower::model::Ex>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto passed_ph = ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::lower::model::Ex>> _v;
            if (prism_rtl::is_some(qk_oj)) {
                auto&& q_pr = prism_rtl::some_of(qk_oj);
                _v.set(template_args_f(lx_p0, env_p1, q_pr, args_pc, body_pg));
                goto _done;
            }
            if (prism_rtl::is_none(qk_oj)) {
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Array<crate::lower::model::Ex>> _v;
                    if (prism_rtl::is_some(qk2_ok)) {
                        auto&& q_ps = prism_rtl::some_of(qk2_ok);
                        _v.set(template_args_f(lx_p0, env_p1, q_ps, args_pc, body_pg));
                        goto _done;
                    }
                    if (prism_rtl::is_none(qk2_ok)) {
                        _v.set(crate::prelude::append(crate::prelude::run_to_end(crate::prelude::each_job(args_pc, ({
                            auto lx_p0x = lx_p0;
                            auto env_p1x = env_p1;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::Arg)>>(prism_rtl::rc([=, lx_p0x = std::move(lx_p0x), env_p1x = std::move(env_p1x)](crate::syntax::Arg p0) {
                            return ({
                                auto lx_p0xy = lx_p0x;
                                auto env_p1xy = env_p1x;
                                (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xy = std::move(lx_p0xy), env_p1xy = std::move(env_p1xy)]() {
                                return ({
                                    auto a_pt = p0;
                                    (prism_rtl::more(prism_rtl::rc(crate::lower::expr::Argument(lx_p0xy, env_p1xy, prism_rtl::deref(a_pt).value_p))));
                                });
                            })));
                            });
                        })));
                        }))), body_pg));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto call_pi = crate::lower::model::Ex(crate::lower::model::Ex::XCall{callee_pf, passed_ph});
        (prism_rtl::finished(Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XCall{crate::lower::helper_f(Text::lit("place")), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRefMut{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("out")}))}), crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(call_pi)}), crate::lower::model::Ex(crate::lower::model::Ex::XNone{})})})})})));
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start TemplatePartDos, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::lower::model::Do>> start_template_part_dos_f(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::TemplatePart part_p2) {
    return prism_rtl::make_rc<TemplatePartDos>(lx_p0, env_p1, part_p2);
}


/// TemplateArgs: unbounded fn Lx, Env, Text, [Arg], [Ex] -> [Ex]
Array<crate::lower::model::Ex> template_args_f(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const Text& qk_p2, const Array<crate::syntax::Arg>& args_p3, const Array<crate::lower::model::Ex>& body_p4) {
    auto clauses_p5 = crate::lower::jobs::clauses_of_f(lx_p0.g_p, qk_p2);
    auto arity_p6 = crate::prelude::len(prism_rtl::deref(crate::prelude::or_(crate::prelude::index(clauses_p5, Nat(0u)), crate::lower::functions::dummy_clause_p())).params_p);
    return crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(arity_p6), ({
        auto body_p4x = body_p4;
        auto arity_p6x = arity_p6;
        auto clauses_p5x = clauses_p5;
        auto args_p3x = args_p3;
        auto lx_p0x = lx_p0;
        auto env_p1x = env_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(Nat)>>(prism_rtl::rc([=, body_p4x = std::move(body_p4x), arity_p6x = std::move(arity_p6x), clauses_p5x = std::move(clauses_p5x), args_p3x = std::move(args_p3x), lx_p0x = std::move(lx_p0x), env_p1x = std::move(env_p1x)](Nat p0) {
        return ({
            auto body_p4xy = body_p4x;
            auto arity_p6xy = arity_p6x;
            auto clauses_p5xy = clauses_p5x;
            auto args_p3xy = args_p3x;
            auto lx_p0xy = lx_p0x;
            auto env_p1xy = env_p1x;
            (crate::prelude::entered(crate::prelude::once_job([=, body_p4xy = std::move(body_p4xy), arity_p6xy = std::move(arity_p6xy), clauses_p5xy = std::move(clauses_p5xy), args_p3xy = std::move(args_p3xy), lx_p0xy = std::move(lx_p0xy), env_p1xy = std::move(env_p1xy)]() {
            return ({
                auto j_p7 = p0;
                (crate::prelude::len(body_p4xy) > Nat(0u)) && ((j_p7 + Nat(1u)) == arity_p6xy)
                ? prism_rtl::finished(crate::prelude::or_(crate::prelude::index(body_p4xy, Nat(0u)), crate::lower::model::Ex(crate::lower::model::Ex::XUnit{})))
                : ({
                auto&& _m = attr_at_o(clauses_p5xy, j_p7, args_p3xy);
                prism_rtl::is_some(_m) ? ({
                auto&& a_p8 = prism_rtl::some_of(_m);
                prism_rtl::more(prism_rtl::rc(crate::lower::expr::Argument(lx_p0xy, env_p1xy, prism_rtl::deref(a_p8).value_p)));
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(crate::lower::expr::refusal_f(prism_rtl::cat("a template call that fills no argument at place ", j_p7)))
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        })));
        });
    })));
    })));
}


prism_rtl::Turn<Array<crate::lower::model::Ex>> TemplateArgs::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& qk_p2 = this->qk_p2;
    const auto& args_p3 = this->args_p3;
    const auto& body_p4 = this->body_p4;
    auto clauses_p5 = crate::lower::jobs::clauses_of_f(prism_rtl::deref(lx_p0).g_p, qk_p2);
    auto arity_p6 = crate::prelude::len(prism_rtl::deref(crate::prelude::or_(crate::prelude::index(clauses_p5, Nat(0u)), crate::lower::functions::dummy_clause_p())).params_p);
    return crate::prelude::each_job(crate::check::errors::range0_f(arity_p6), ({
        auto body_p4x = body_p4;
        auto arity_p6x = arity_p6;
        auto clauses_p5x = clauses_p5;
        auto args_p3x = args_p3;
        auto lx_p0x = lx_p0;
        auto env_p1x = env_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(Nat)>>(prism_rtl::rc([=, body_p4x = std::move(body_p4x), arity_p6x = std::move(arity_p6x), clauses_p5x = std::move(clauses_p5x), args_p3x = std::move(args_p3x), lx_p0x = std::move(lx_p0x), env_p1x = std::move(env_p1x)](Nat p0) {
        return ({
            auto body_p4xy = body_p4x;
            auto arity_p6xy = arity_p6x;
            auto clauses_p5xy = clauses_p5x;
            auto args_p3xy = args_p3x;
            auto lx_p0xy = lx_p0x;
            auto env_p1xy = env_p1x;
            (crate::prelude::entered(crate::prelude::once_job([=, body_p4xy = std::move(body_p4xy), arity_p6xy = std::move(arity_p6xy), clauses_p5xy = std::move(clauses_p5xy), args_p3xy = std::move(args_p3xy), lx_p0xy = std::move(lx_p0xy), env_p1xy = std::move(env_p1xy)]() {
            return ({
                auto j_p7 = p0;
                (crate::prelude::len(body_p4xy) > Nat(0u)) && ((j_p7 + Nat(1u)) == arity_p6xy)
                ? prism_rtl::finished(crate::prelude::or_(crate::prelude::index(body_p4xy, Nat(0u)), crate::lower::model::Ex(crate::lower::model::Ex::XUnit{})))
                : ({
                auto&& _m = attr_at_o(clauses_p5xy, j_p7, args_p3xy);
                prism_rtl::is_some(_m) ? ({
                auto&& a_p8 = prism_rtl::some_of(_m);
                prism_rtl::more(prism_rtl::rc(crate::lower::expr::Argument(lx_p0xy, env_p1xy, prism_rtl::deref(a_p8).value_p)));
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(crate::lower::expr::refusal_f(prism_rtl::cat("a template call that fills no argument at place ", j_p7)))
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        })));
        });
    })));
    }))->cycle();
}


/// `Start TemplateArgs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::lower::model::Ex>> start_template_args_f(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, Text qk_p2, Array<crate::syntax::Arg> args_p3, Array<crate::lower::model::Ex> body_p4) {
    return prism_rtl::make_rc<TemplateArgs>(lx_p0, env_p1, qk_p2, args_p3, body_p4);
}


/// ?AttrAt: fn [FnClause], Nat, [Arg] -> ?Arg
std::optional<crate::syntax::Arg> attr_at_o(const Array<crate::syntax::decls::FnClause>& clauses_p0, const Nat& j_p1, const Array<crate::syntax::Arg>& args_p2) {
    auto names_p7 = crate::prelude::fold(clauses_p0, Array<Text>{}, [&](const Array<Text>& acc_p3, const crate::syntax::decls::FnClause& c_p4) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = crate::prelude::index(prism_rtl::deref(c_p4).params_p, j_p1);
            if (prism_rtl::is_some(_m)) {
                auto&& p_p5 = prism_rtl::some_of(_m);
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Array<Text>> _v;
                    auto&& _m = place_name_o(p_p5);
                    if (prism_rtl::is_some(_m)) {
                        auto&& n_p6 = prism_rtl::some_of(_m);
                        _v.set(crate::check::types::add_text_f(acc_p3, n_p6));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(acc_p3);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(acc_p3);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
    return crate::prelude::fold(args_p2, std::optional<crate::syntax::Arg>{}, [&](const std::optional<crate::syntax::Arg>& found_o8, const crate::syntax::Arg& a_p9) {
        return ({
            __label__ _done;
            prism_rtl::Slot<std::optional<crate::syntax::Arg>> _v;
            auto&& _m = prism_rtl::deref(a_p9).name_o;
            if (prism_rtl::is_some(_m)) {
                auto&& n_pa = prism_rtl::some_of(_m);
                _v.set(crate::check::types::has_text_f(names_p7, prism_rtl::deref(n_pa).name_p)
                    ? std::optional(a_p9)
                    : found_o8);
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(found_o8);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
}


/// ?PlaceName: fn Pattern -> ?Text
std::optional<Text> place_name_o(const crate::syntax::Pattern_& p_p0) {
    auto&& _m = prism_rtl::deref(p_p0.kind_p);
    if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
        auto&& n_p1 = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        return std::optional(crate::check::env::dotted_f(prism_rtl::deref(n_p1).path_p));
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PGroup>(_m)) {
        auto&& q_p2 = prism_rtl::as<crate::syntax::PatternKind::PGroup>(_m).a0;
        return place_name_o(prism_rtl::deref(prism_rtl::deref(q_p2)));
    }
    {
        return std::optional<Text>{};
    }
}


/// ShownText: fn Vl -> Ex
crate::lower::model::Ex shown_text_f(const crate::lower::types::Vl& v_p0) {
    auto&& _m = crate::lower::types::value_ty_f(v_p0);
    if (prism_rtl::is<crate::lower::model::OutTy::OutText>(_m)) {
        return crate::lower::types::ref_f(v_p0);
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutChar>(_m)) {
        return crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XFormat{Array(std::vector{crate::lower::types::ref_f(v_p0)})}))});
    }
    {
        return crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{crate::lower::helper_f(Text::lit("show_text")), Array(std::vector{crate::lower::types::ref_f(v_p0)})}))});
    }
}


/// GivenValue: unbounded fn Lx, Env, Block, OutTy, Range -> Vl
crate::lower::types::Vl given_value_f(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Block& b_p2, const crate::lower::model::OutTy& t_p3, const crate::syntax::Range& span_p4) {
    auto label_p5 = prism_rtl::cat("\'g", span_p4.start_p);
    auto is_try_p6 = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        if (prism_rtl::is<crate::lower::model::OutTy::OutRes>(t_p3)) {
            _v.set(true);
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
    auto n_p7 = crate::prelude::len(b_p2.stmts_p);
    auto [dos_po, env2_pp, last_oq] = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(n_p7), std::tuple{Array<crate::lower::model::Do>{}, env_p1, std::optional<crate::lower::types::Vl>{}}, ({
        auto b_p2x = b_p2;
        auto is_try_p6x = std::move(is_try_p6);
        auto lx_p0x = lx_p0;
        auto label_p5x = label_p5;
        auto n_p7x = n_p7;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env, std::optional<crate::lower::types::Vl>>>(std::tuple<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env, std::optional<crate::lower::types::Vl>>, Nat>)>>(prism_rtl::rc([=, b_p2x = std::move(b_p2x), is_try_p6x = std::move(is_try_p6x), lx_p0x = std::move(lx_p0x), label_p5x = std::move(label_p5x), n_p7x = std::move(n_p7x)](std::tuple<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env, std::optional<crate::lower::types::Vl>>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto b_p2xy = b_p2x;
            auto is_try_p6xy = is_try_p6x;
            auto lx_p0xy = lx_p0x;
            auto label_p5xy = label_p5x;
            auto n_p7xy = n_p7x;
            (crate::prelude::entered(crate::prelude::once_job([=, b_p2xy = std::move(b_p2xy), is_try_p6xy = std::move(is_try_p6xy), lx_p0xy = std::move(lx_p0xy), label_p5xy = std::move(label_p5xy), n_p7xy = std::move(n_p7xy)]() {
            return ({
                auto [acc_p9, en_pa, lv_ob] = p0;
                auto i_pc = p1;
                ({
                auto s_pd = crate::prelude::or_(crate::prelude::index(prism_rtl::deref(b_p2xy).stmts_p, i_pc), crate::lower::expr::dummy_stmt_l_p());
                auto fail_pe = is_try_p6xy
                    ? crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Err"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Error::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XStr{Text::lit("Prelude.Unmet")}), crate::lower::model::Ex(crate::lower::model::Ex::XStr{source_text_f(lx_p0xy, prism_rtl::deref(s_pd).span_p)})})})})})
                    : crate::lower::model::Ex(crate::lower::model::Ex::XNone{});
                ({
                auto&& _m = prism_rtl::deref(s_pd).kind_p;
                prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) && prism_rtl::is_none(prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2) ? ({
                auto&& p_pf = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a0;
                auto&& x_pg = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a1;
                ({
                auto p_pfx = p_pf;
                auto x_pgx = x_pg;
                (crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0xy, en_pa, x_pgx), [=, p_pfx = std::move(p_pfx)](crate::lower::types::Vl value_of_f_5976) {
                return ({
                    auto v_ph = value_of_f_5976;
                    (crate::prelude::call_then(crate::lower::patterns::start_rust_pat_f(lx_p0xy, p_pfx, crate::lower::patterns::inner_ty_f(crate::lower::type_at_f(lx_p0xy, prism_rtl::deref(x_pgx).span_p)), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat("g", prism_rtl::deref(prism_rtl::deref(s_pd).span_p).start_p)), [=, v_ph = std::move(v_ph)](crate::lower::patterns::PatOut rust_pat_f_6019) {
                    return ({
                        auto po_pi = rust_pat_f_6019;
                        (crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0xy, crate::lower::patterns::inner_ty_f(crate::lower::type_at_f(lx_p0xy, prism_rtl::deref(x_pgx).span_p))), [=, po_pi = std::move(po_pi)](crate::lower::model::OutTy out_ty_of_f_6161) { return prism_rtl::finished(std::tuple{crate::prelude::push(acc_p9, given_bind_f(is_try_p6xy, prism_rtl::deref(po_pi).pa_p, crate::lower::types::own_f(v_ph), label_p5xy, out_ty_of_f_6161)), crate::lower::expr::bind_all_f(en_pa, prism_rtl::deref(po_pi).binds_p), lv_ob}); }));
                    });
                }));
                });
            }));
            });
            })
                : prism_rtl::is<crate::syntax::StmtKind::SRequire>(_m) ? ({
                auto&& c_pj = prism_rtl::as<crate::syntax::StmtKind::SRequire>(_m).a0;
                ({
                auto c_pjx = c_pj;
                (crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0xy, en_pa, c_pjx), [=](crate::lower::types::Vl value_of_f_6304) { return prism_rtl::finished(std::tuple{crate::prelude::push(acc_p9, crate::lower::model::Do(crate::lower::model::Do::DoIf{crate::lower::model::Ex(crate::lower::model::Ex::XUnary{crate::lower::model::UnOp(crate::lower::model::UnOp::OpNot{}), prism_rtl::rc(crate::lower::types::as_bool_f(value_of_f_6304))}), Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XBreak{label_p5xy, prism_rtl::rc(fail_pe)})})}), Array<crate::lower::model::Do>{}})), en_pa, lv_ob}); }));
            });
            })
                : prism_rtl::is<crate::syntax::StmtKind::SForbid>(_m) ? ({
                auto&& c_pk = prism_rtl::as<crate::syntax::StmtKind::SForbid>(_m).a0;
                ({
                auto c_pkx = c_pk;
                (crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0xy, en_pa, c_pkx), [=](crate::lower::types::Vl value_of_f_6428) { return prism_rtl::finished(std::tuple{crate::prelude::push(acc_p9, crate::lower::model::Do(crate::lower::model::Do::DoIf{crate::lower::types::as_bool_f(value_of_f_6428), Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XBreak{label_p5xy, prism_rtl::rc(fail_pe)})})}), Array<crate::lower::model::Do>{}})), en_pa, lv_ob}); }));
            });
            })
                : prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m) ? ({
                auto&& x_pl = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
                (i_pc + Nat(1u)) == n_p7xy
                ? prism_rtl::finished(std::tuple{acc_p9, en_pa, std::optional(crate::lower::expr::value_of_f(lx_p0xy, en_pa, x_pl))})
                : ({
                auto x_plx = x_pl;
                (crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0xy, en_pa, x_plx), [=](crate::lower::types::Vl value_of_f_6636) { return prism_rtl::finished(std::tuple{crate::prelude::push(acc_p9, crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::types::own_f(value_of_f_6636)})), en_pa, lv_ob}); }));
            });
            })
                : crate::prelude::call_then(crate::lower::expr::start_block_stmt_f(lx_p0xy, en_pa, s_pd), [=](std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env> block_stmt_f_6728) {
                return ({
                    auto [more_pm, en2_pn] = block_stmt_f_6728;
                    (prism_rtl::finished(std::tuple{crate::prelude::append(acc_p9, more_pm), en2_pn, lv_ob}));
                });
            });
            });
            });
            });
        })));
        });
    }));
    })));
    auto last_p8 = crate::prelude::or_(last_oq, crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XNone{}), t_p3}));
    return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XLabeled{label_p5, dos_po, prism_rtl::rc(crate::lower::types::own_f(last_p8)), t_p3}), t_p3});
}


prism_rtl::Turn<crate::lower::types::Vl> GivenValue::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& b_p2 = this->b_p2;
    const auto& t_p3 = this->t_p3;
    const auto& span_p4 = this->span_p4;
    auto label_p5 = prism_rtl::cat("\'g", prism_rtl::deref(span_p4).start_p);
    auto is_try_p6 = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        if (prism_rtl::is<crate::lower::model::OutTy::OutRes>(t_p3)) {
            _v.set(true);
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
    auto n_p7 = crate::prelude::len(prism_rtl::deref(b_p2).stmts_p);
    auto b_p2x = b_p2;
    auto env_p1x = env_p1;
    auto lx_p0x = lx_p0;
    auto span_p4x = span_p4;
    auto t_p3x = t_p3;
    return crate::prelude::call_value(crate::prelude::fold_job(crate::check::errors::range0_f(n_p7), std::tuple{Array<crate::lower::model::Do>{}, env_p1x, std::optional<crate::lower::types::Vl>{}}, ({
        auto b_p2xx = b_p2x;
        auto is_try_p6x = std::move(is_try_p6);
        auto lx_p0xx = lx_p0x;
        auto label_p5x = label_p5;
        auto n_p7x = n_p7;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env, std::optional<crate::lower::types::Vl>>>(std::tuple<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env, std::optional<crate::lower::types::Vl>>, Nat>)>>(prism_rtl::rc([=, b_p2xx = std::move(b_p2xx), is_try_p6x = std::move(is_try_p6x), lx_p0xx = std::move(lx_p0xx), label_p5x = std::move(label_p5x), n_p7x = std::move(n_p7x)](std::tuple<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env, std::optional<crate::lower::types::Vl>>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto b_p2xxy = b_p2xx;
            auto is_try_p6xy = is_try_p6x;
            auto lx_p0xxy = lx_p0xx;
            auto label_p5xy = label_p5x;
            auto n_p7xy = n_p7x;
            (crate::prelude::entered(crate::prelude::once_job([=, b_p2xxy = std::move(b_p2xxy), is_try_p6xy = std::move(is_try_p6xy), lx_p0xxy = std::move(lx_p0xxy), label_p5xy = std::move(label_p5xy), n_p7xy = std::move(n_p7xy)]() {
            return ({
                auto [acc_p9, en_pa, lv_ob] = p0;
                auto i_pc = p1;
                ({
                auto s_pd = crate::prelude::or_(crate::prelude::index(prism_rtl::deref(b_p2xxy).stmts_p, i_pc), crate::lower::expr::dummy_stmt_l_p());
                auto fail_pe = is_try_p6xy
                    ? crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Err"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Error::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XStr{Text::lit("Prelude.Unmet")}), crate::lower::model::Ex(crate::lower::model::Ex::XStr{source_text_f(lx_p0xxy, prism_rtl::deref(s_pd).span_p)})})})})})
                    : crate::lower::model::Ex(crate::lower::model::Ex::XNone{});
                ({
                auto&& _m = prism_rtl::deref(s_pd).kind_p;
                prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) && prism_rtl::is_none(prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2) ? ({
                auto&& p_pf = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a0;
                auto&& x_pg = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a1;
                ({
                auto p_pfx = p_pf;
                auto x_pgx = x_pg;
                (crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0xxy, en_pa, x_pgx), [=, p_pfx = std::move(p_pfx)](crate::lower::types::Vl value_of_f_5976) {
                return ({
                    auto v_ph = value_of_f_5976;
                    (crate::prelude::call_then(crate::lower::patterns::start_rust_pat_f(lx_p0xxy, p_pfx, crate::lower::patterns::inner_ty_f(crate::lower::type_at_f(lx_p0xxy, prism_rtl::deref(x_pgx).span_p)), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat("g", prism_rtl::deref(prism_rtl::deref(s_pd).span_p).start_p)), [=, v_ph = std::move(v_ph)](crate::lower::patterns::PatOut rust_pat_f_6019) {
                    return ({
                        auto po_pi = rust_pat_f_6019;
                        (crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0xxy, crate::lower::patterns::inner_ty_f(crate::lower::type_at_f(lx_p0xxy, prism_rtl::deref(x_pgx).span_p))), [=, po_pi = std::move(po_pi)](crate::lower::model::OutTy out_ty_of_f_6161) { return prism_rtl::finished(std::tuple{crate::prelude::push(acc_p9, given_bind_f(is_try_p6xy, prism_rtl::deref(po_pi).pa_p, crate::lower::types::own_f(v_ph), label_p5xy, out_ty_of_f_6161)), crate::lower::expr::bind_all_f(en_pa, prism_rtl::deref(po_pi).binds_p), lv_ob}); }));
                    });
                }));
                });
            }));
            });
            })
                : prism_rtl::is<crate::syntax::StmtKind::SRequire>(_m) ? ({
                auto&& c_pj = prism_rtl::as<crate::syntax::StmtKind::SRequire>(_m).a0;
                ({
                auto c_pjx = c_pj;
                (crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0xxy, en_pa, c_pjx), [=](crate::lower::types::Vl value_of_f_6304) { return prism_rtl::finished(std::tuple{crate::prelude::push(acc_p9, crate::lower::model::Do(crate::lower::model::Do::DoIf{crate::lower::model::Ex(crate::lower::model::Ex::XUnary{crate::lower::model::UnOp(crate::lower::model::UnOp::OpNot{}), prism_rtl::rc(crate::lower::types::as_bool_f(value_of_f_6304))}), Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XBreak{label_p5xy, prism_rtl::rc(fail_pe)})})}), Array<crate::lower::model::Do>{}})), en_pa, lv_ob}); }));
            });
            })
                : prism_rtl::is<crate::syntax::StmtKind::SForbid>(_m) ? ({
                auto&& c_pk = prism_rtl::as<crate::syntax::StmtKind::SForbid>(_m).a0;
                ({
                auto c_pkx = c_pk;
                (crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0xxy, en_pa, c_pkx), [=](crate::lower::types::Vl value_of_f_6428) { return prism_rtl::finished(std::tuple{crate::prelude::push(acc_p9, crate::lower::model::Do(crate::lower::model::Do::DoIf{crate::lower::types::as_bool_f(value_of_f_6428), Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XBreak{label_p5xy, prism_rtl::rc(fail_pe)})})}), Array<crate::lower::model::Do>{}})), en_pa, lv_ob}); }));
            });
            })
                : prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m) ? ({
                auto&& x_pl = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
                (i_pc + Nat(1u)) == n_p7xy
                ? prism_rtl::finished(std::tuple{acc_p9, en_pa, std::optional(crate::lower::expr::value_of_f(lx_p0xxy, en_pa, x_pl))})
                : ({
                auto x_plx = x_pl;
                (crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0xxy, en_pa, x_plx), [=](crate::lower::types::Vl value_of_f_6636) { return prism_rtl::finished(std::tuple{crate::prelude::push(acc_p9, crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::types::own_f(value_of_f_6636)})), en_pa, lv_ob}); }));
            });
            })
                : crate::prelude::call_then(crate::lower::expr::start_block_stmt_f(lx_p0xxy, en_pa, s_pd), [=](std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env> block_stmt_f_6728) {
                return ({
                    auto [more_pm, en2_pn] = block_stmt_f_6728;
                    (prism_rtl::finished(std::tuple{crate::prelude::append(acc_p9, more_pm), en2_pn, lv_ob}));
                });
            });
            });
            });
            });
        })));
        });
    }));
    })), [=](std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env, std::optional<crate::lower::types::Vl>> fold_5660) {
        return ({
            auto [dos_po, env2_pp, last_oq] = fold_5660;
            auto last_p8 = crate::prelude::or_(last_oq, crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XNone{}), t_p3x}));
            (prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XLabeled{label_p5, dos_po, prism_rtl::rc(crate::lower::types::own_f(last_p8)), t_p3x}), t_p3x})));
        });
    });
}


/// `Start GivenValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_given_value_f(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Block b_p2, crate::lower::model::OutTy t_p3, crate::syntax::Range span_p4) {
    return prism_rtl::make_rc<GivenValue>(lx_p0, env_p1, b_p2, t_p3, span_p4);
}


/// GivenBind: fn Bool, Pa, Ex, Text, OutTy -> Do
crate::lower::model::Do given_bind_f(const bool& is_try_p0, const crate::lower::model::Pa& pa_p1, const crate::lower::model::Ex& x_p2, const Text& label_p3, const crate::lower::model::OutTy& t_p4) {
    return is_try_p0
        ? crate::lower::model::Do(crate::lower::model::Do::DoLet{pa_p1, crate::lower::model::Ex(crate::lower::model::Ex::XMatch{prism_rtl::rc(x_p2), Array(std::vector{crate::lower::model::XArm{.pat_p = crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Ok"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("v")})})}), .conds_p = Array<crate::lower::model::Cc>{}, .body_p = crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("v")})}, crate::lower::model::XArm{.pat_p = crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Err"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("e")})})}), .conds_p = Array<crate::lower::model::Cc>{}, .body_p = crate::lower::model::Ex(crate::lower::model::Ex::XBreak{label_p3, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Err"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("e")})})}))})}}), false, t_p4})})
        : crate::lower::model::Do(crate::lower::model::Do::DoLetElse{crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{pa_p1})}), x_p2, crate::lower::model::Ex(crate::lower::model::Ex::XBreak{label_p3, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XNone{}))})});
}


/// SourceText: fn Lx, Range -> Text
Text source_text_f(const crate::lower::Lx& lx_p0, const crate::syntax::Range& r_p1) {
    auto&& _m = crate::prelude::index(prism_rtl::deref(lx_p0.g_p).srcs_p, lx_p0.file_p);
    if (prism_rtl::is_some(_m)) {
        auto&& src_p2 = prism_rtl::some_of(_m);
        return crate::check::errors::span_text_f(src_p2, r_p1);
    }
    if (prism_rtl::is_none(_m)) {
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}


/// UpdateValue: unbounded fn Lx, Env, Expr, Block, OutTy, Range -> Vl
crate::lower::types::Vl update_value_f(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& target_p2, const crate::syntax::Block& b_p3, const crate::lower::model::OutTy& t_p4, const crate::syntax::Range& span_p5) {
    auto tv_p6 = crate::lower::expr::value_of_f(lx_p0, env_p1, target_p2);
    auto env1_p7 = crate::lower::types::bind_f(env_p1, Text::lit("&_"), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("this")}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), t_p4}));
    auto&& _dos_p8 = upd_stmts_f(lx_p0, env1_p7, b_p3.stmts_p);
    auto&& dos_p8 = std::get<0>(_dos_p8);
    return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBlock{crate::prelude::append(Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaMut{Text::lit("this")})), t_p4}), crate::lower::types::own_f(tv_p6)})}), dos_p8), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("this")}))}), t_p4});
}


prism_rtl::Turn<crate::lower::types::Vl> UpdateValue::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& target_p2 = this->target_p2;
    const auto& b_p3 = this->b_p3;
    const auto& t_p4 = this->t_p4;
    const auto& span_p5 = this->span_p5;
    auto b_p3x = b_p3;
    auto env_p1x = env_p1;
    auto lx_p0x = lx_p0;
    auto t_p4x = t_p4;
    auto target_p2x = target_p2;
    return crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0x, env_p1x, target_p2x), [=](crate::lower::types::Vl value_of_f_7927) {
        return ({
            auto tv_p6 = value_of_f_7927;
            auto env1_p7 = crate::lower::types::bind_f(env_p1x, Text::lit("&_"), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("this")}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), t_p4x}));
            (crate::prelude::call_then(start_upd_stmts_f(lx_p0x, env1_p7, prism_rtl::deref(b_p3x).stmts_p), [=, tv_p6 = std::move(tv_p6)](std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env> upd_stmts_f_8042) {
            return ({
                auto&& _dos_p8 = upd_stmts_f_8042;
                auto&& dos_p8 = std::get<0>(_dos_p8);
                (prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBlock{crate::prelude::append(Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaMut{Text::lit("this")})), t_p4x}), crate::lower::types::own_f(tv_p6)})}), dos_p8), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("this")}))}), t_p4x})));
            });
        }));
        });
    });
}


/// `Start UpdateValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_update_value_f(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr target_p2, crate::syntax::Block b_p3, crate::lower::model::OutTy t_p4, crate::syntax::Range span_p5) {
    return prism_rtl::make_rc<UpdateValue>(lx_p0, env_p1, target_p2, b_p3, t_p4, span_p5);
}


/// UpdStmts: unbounded fn Lx, Env, [Stmt] -> (([Do], Env))
std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env> upd_stmts_f(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const Array<crate::syntax::Stmt>& stmts_p2) {
    return crate::prelude::run_to_end(crate::prelude::fold_job(stmts_p2, std::tuple{Array<crate::lower::model::Do>{}, env_p1}, ({
        auto lx_p0x = lx_p0;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>>(std::tuple<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>, crate::syntax::Stmt>)>>(prism_rtl::rc([=, lx_p0x = std::move(lx_p0x)](std::tuple<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>, crate::syntax::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_p0xy = lx_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xy = std::move(lx_p0xy)]() {
            return ({
                auto [acc_p3, en_p4] = p0;
                auto s_p5 = p1;
                (crate::prelude::call_then(start_upd_stmt_f(lx_p0xy, en_p4, s_p5), [=](std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env> upd_stmt_f_8327) {
                return ({
                    auto [more_p6, en2_p7] = upd_stmt_f_8327;
                    (prism_rtl::finished(std::tuple{crate::prelude::append(acc_p3, more_p6), en2_p7}));
                });
            }));
            });
        })));
        });
    }));
    })));
}


prism_rtl::Turn<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> UpdStmts::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& stmts_p2 = this->stmts_p2;
    return crate::prelude::fold_job(stmts_p2, std::tuple{Array<crate::lower::model::Do>{}, env_p1}, ({
        auto lx_p0x = lx_p0;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>>(std::tuple<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>, crate::syntax::Stmt>)>>(prism_rtl::rc([=, lx_p0x = std::move(lx_p0x)](std::tuple<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>, crate::syntax::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_p0xy = lx_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xy = std::move(lx_p0xy)]() {
            return ({
                auto [acc_p3, en_p4] = p0;
                auto s_p5 = p1;
                (crate::prelude::call_then(start_upd_stmt_f(lx_p0xy, en_p4, s_p5), [=](std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env> upd_stmt_f_8327) {
                return ({
                    auto [more_p6, en2_p7] = upd_stmt_f_8327;
                    (prism_rtl::finished(std::tuple{crate::prelude::append(acc_p3, more_p6), en2_p7}));
                });
            }));
            });
        })));
        });
    }));
    }))->cycle();
}


/// `Start UpdStmts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> start_upd_stmts_f(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, Array<crate::syntax::Stmt> stmts_p2) {
    return prism_rtl::make_rc<UpdStmts>(lx_p0, env_p1, stmts_p2);
}


/// UpdStmt: unbounded fn Lx, Env, Stmt -> (([Do], Env))
std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env> upd_stmt_f(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Stmt& s_p2) {
    auto&& _m = s_p2.kind_p;
    if (prism_rtl::is<crate::syntax::StmtKind::SSet>(_m)) {
        auto&& target_p3 = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a0;
        auto&& value_p4 = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a1;
        auto v_p5 = crate::lower::types::own_f(crate::lower::expr::value_of_f(lx_p0, env_p1, value_p4));
        return std::tuple{Array(std::vector{assign_f(lx_p0, env_p1, target_p3, v_p5)}), env_p1};
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SAccum>(_m)) {
        auto&& target_p6 = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a0;
        auto&& op_p7 = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a1;
        auto&& value_p8 = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a2;
        auto cur_p9 = place_of_f(lx_p0, env_p1, target_p6);
        auto tt_pa = crate::lower::types::out_ty_of_f(lx_p0, crate::lower::types::peel_f(crate::lower::type_at_f(lx_p0, prism_rtl::deref(target_p6).span_p)));
        auto rv_pb = crate::lower::expr::value_of_f(lx_p0, env_p1, value_p8);
        auto bin_pc = crate::syntax::lexer::chars::head_f(op_p7);
        auto next_pd = crate::lower::expr::op_value_f(lx_p0, bin_pc, crate::lower::types::Vl(crate::lower::types::Vl::VlPlace{cur_p9, crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), tt_pa}), rv_pb, s_p2.span_p, tt_pa);
        return std::tuple{Array(std::vector{assign_f(lx_p0, env_p1, target_p6, crate::lower::types::own_f(next_pd))}), env_p1};
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SLet>(_m)) {
        auto&& p_pe = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
        auto&& x_pf = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
        auto v_pg = crate::lower::types::own_f(crate::lower::expr::value_of_f(lx_p0, env_p1, x_pf));
        auto&& _m = prism_rtl::deref(prism_rtl::deref(p_pe).kind_p);
        if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
            auto&& n_ph = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
            return crate::syntax::lexer::chars::has_prefix_f(prism_rtl::deref(n_ph).sigils_p, Text::lit("&"))
                ? ({
                auto rs_pi = crate::lower::local_name_at_f(lx_p0, crate::check::env::sname_key_f(n_ph), prism_rtl::deref(n_ph).span_p);
                auto bt_pj = crate::lower::types::out_ty_of_f(lx_p0, crate::lower::types::peel_f(crate::lower::binder_ty_f(lx_p0, prism_rtl::deref(n_ph).span_p)));
                auto pa_pk = crate::lower::expr::is_known_ty_f(bt_pj)
                    ? crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaMut{prism_rtl::cat(rs_pi)})), bt_pj})
                    : crate::lower::model::Pa(crate::lower::model::Pa::PaMut{prism_rtl::cat(rs_pi)});
                std::tuple{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{pa_pk, v_pg})}), crate::lower::types::bind_f(env_p1, crate::check::env::sname_key_f(n_ph), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{rs_pi}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), bt_pj}))};
            })
                : crate::lower::expr::block_stmt_f(lx_p0, env_p1, s_p2);
        }
        {
            return crate::lower::expr::block_stmt_f(lx_p0, env_p1, s_p2);
        }
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SWhile>(_m)) {
        auto&& c_pl = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a0;
        auto&& body_pm = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a1;
        auto&& _inner_pn = upd_stmts_f(lx_p0, env_p1, prism_rtl::deref(body_pm).stmts_p);
        auto&& inner_pn = std::get<0>(_inner_pn);
        if (prism_rtl::is<crate::syntax::Cond::CondExpr>(c_pl)) {
            auto&& x_po = prism_rtl::as<crate::syntax::Cond::CondExpr>(c_pl).a0;
            return std::tuple{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoWhile{crate::lower::types::as_bool_f(crate::lower::expr::value_of_f(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(x_po)))), inner_pn})}), env_p1};
        }
        if (prism_rtl::is<crate::syntax::Cond::CondBind>(c_pl)) {
            auto&& p_pp = prism_rtl::as<crate::syntax::Cond::CondBind>(c_pl).a0;
            auto&& x_pq = prism_rtl::as<crate::syntax::Cond::CondBind>(c_pl).a1;
            auto&& g_or = prism_rtl::as<crate::syntax::Cond::CondBind>(c_pl).a2;
            auto po_ps = crate::lower::patterns::rust_pat_f(lx_p0, p_pp, crate::lower::type_at_f(lx_p0, prism_rtl::deref(x_pq).span_p), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat("w", prism_rtl::deref(s_p2.span_p).start_p));
            auto env_b_pt = crate::lower::expr::bind_all_f(env_p1, prism_rtl::deref(po_ps).binds_p);
            auto&& _inner2_p13 = upd_stmts_f(lx_p0, env_b_pt, prism_rtl::deref(body_pm).stmts_p);
            auto&& inner2_p13 = std::get<0>(_inner2_p13);
            auto conds_pu = crate::prelude::append(prism_rtl::deref(po_ps).conds_p, guard_conds_f(lx_p0, env_b_pt, prism_rtl::deref(prism_rtl::deref(g_or))));
            auto tests_pv = crate::prelude::fold(conds_pu, Array<crate::lower::model::Ex>{}, [&](const Array<crate::lower::model::Ex>& acc_p14, const crate::lower::model::Cc& c_p15) {
                return ({
                    __label__ _done;
                    prism_rtl::Slot<Array<crate::lower::model::Ex>> _v;
                    if (prism_rtl::is<crate::lower::model::Cc::CcIf>(c_p15)) {
                        auto&& t_p16 = prism_rtl::as<crate::lower::model::Cc::CcIf>(c_p15).a0;
                        _v.set(crate::prelude::push(acc_p14, t_p16));
                        goto _done;
                    }
                    {
                        _v.set(acc_p14);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
            });
            auto lets_p10 = crate::prelude::fold(conds_pu, false, [&](const bool& f_p17, const crate::lower::model::Cc& c_p18) { return prism_rtl::deref(f_p17) || crate::lower::expr::is_let_cond_f(c_p18); });
            auto stop_p11 = crate::prelude::len(tests_pv) == Nat(0u)
                ? Array<crate::lower::model::Do>{}
                : Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoIf{crate::lower::model::Ex(crate::lower::model::Ex::XUnary{crate::lower::model::UnOp(crate::lower::model::UnOp::OpNot{}), prism_rtl::rc(all_of_f(tests_pv))}), Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("break")})})}), Array<crate::lower::model::Do>{}})});
            auto body2_p12 = std::move(lets_p10)
                ? Array(std::vector{crate::lower::expr::refusal_do_f(Text::lit("a `while` whose pattern matches through an `Rc`"))})
                : crate::prelude::append(stop_p11, inner2_p13);
            return std::tuple{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoWhileLet{prism_rtl::deref(po_ps).pa_p, crate::lower::types::own_f(crate::lower::expr::value_of_f(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(x_pq)))), body2_p12})}), env_p1};
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m)) {
        auto&& x_p19 = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
        auto&& _m = prism_rtl::deref(prism_rtl::deref(x_p19).kind_p);
        if (prism_rtl::is<crate::syntax::ExprKind::EIf>(_m)) {
            auto&& c_p1a = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
            auto&& then_b_p1b = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
            auto&& else_b_o1c = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
            return std::tuple{Array(std::vector{upd_if_f(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(c_p1a)), then_b_p1b, else_b_o1c)}), env_p1};
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m)) {
            auto&& scrut_p1d = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
            auto&& arms_p1e = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
            return std::tuple{Array(std::vector{upd_match_f(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(scrut_p1d)), arms_p1e)}), env_p1};
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EFor>(_m)) {
            auto&& binders_o1f = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a0;
            auto&& source_p1g = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a1;
            auto&& body_p1h = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a2;
            return std::tuple{Array(std::vector{upd_for_f(lx_p0, env_p1, binders_o1f, prism_rtl::deref(prism_rtl::deref(source_p1g)), body_p1h, prism_rtl::deref(x_p19).span_p)}), env_p1};
        }
        {
            return std::tuple{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::types::own_f(crate::lower::expr::value_of_f(lx_p0, env_p1, x_p19))})}), env_p1};
        }
    }
    {
        return crate::lower::expr::block_stmt_f(lx_p0, env_p1, s_p2);
    }
}


prism_rtl::Turn<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> UpdStmt::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& s_p2 = this->s_p2;
    return ({
        auto&& _m = prism_rtl::deref(s_p2).kind_p;
        prism_rtl::is<crate::syntax::StmtKind::SSet>(_m) ? ({
        auto&& target_p3 = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a0;
        auto&& value_p4 = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a1;
        ({
        auto env_p1x = env_p1;
        auto lx_p0x = lx_p0;
        auto target_p3x = target_p3;
        auto value_p4x = value_p4;
        (crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0x, env_p1x, value_p4x), [=, target_p3x = std::move(target_p3x)](crate::lower::types::Vl value_of_f_8514) {
        return ({
            auto v_p5 = crate::lower::types::own_f(value_of_f_8514);
            (crate::prelude::call_then(start_assign_f(lx_p0x, env_p1x, target_p3x, v_p5), [=](crate::lower::model::Do assign_f_8551) { return prism_rtl::finished(std::tuple{Array(std::vector{assign_f_8551}), env_p1x}); }));
        });
    }));
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SAccum>(_m) ? ({
        auto&& target_p6 = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a0;
        auto&& op_p7 = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a1;
        auto&& value_p8 = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a2;
        ({
        auto env_p1x = env_p1;
        auto lx_p0x = lx_p0;
        auto op_p7x = op_p7;
        auto s_p2x = s_p2;
        auto target_p6x = target_p6;
        auto value_p8x = value_p8;
        (crate::prelude::call_then(start_place_of_f(lx_p0x, env_p1x, target_p6x), [=, op_p7x = std::move(op_p7x), s_p2x = std::move(s_p2x), value_p8x = std::move(value_p8x)](crate::lower::model::Ex place_of_f_8635) {
        return ({
            auto cur_p9 = place_of_f_8635;
            (crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0x, crate::lower::types::peel_f(crate::lower::type_at_f(lx_p0x, prism_rtl::deref(target_p6x).span_p))), [=, cur_p9 = std::move(cur_p9)](crate::lower::model::OutTy out_ty_of_f_8676) {
            return ({
                auto tt_pa = out_ty_of_f_8676;
                (crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0x, env_p1x, value_p8x), [=, tt_pa = std::move(tt_pa)](crate::lower::types::Vl value_of_f_8737) {
                return ({
                    auto rv_pb = value_of_f_8737;
                    auto bin_pc = crate::syntax::lexer::chars::head_f(op_p7x);
                    auto next_pd = crate::lower::expr::op_value_f(lx_p0x, bin_pc, crate::lower::types::Vl(crate::lower::types::Vl::VlPlace{cur_p9, crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), tt_pa}), rv_pb, prism_rtl::deref(s_p2x).span_p, tt_pa);
                    (crate::prelude::call_then(start_assign_f(lx_p0x, env_p1x, target_p6x, crate::lower::types::own_f(next_pd)), [=](crate::lower::model::Do assign_f_8876) { return prism_rtl::finished(std::tuple{Array(std::vector{assign_f_8876}), env_p1x}); }));
                });
            }));
            });
        }));
        });
    }));
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SLet>(_m) ? ({
        auto&& p_pe = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
        auto&& x_pf = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
        ({
        auto env_p1x = env_p1;
        auto lx_p0x = lx_p0;
        auto p_pex = p_pe;
        auto s_p2x = s_p2;
        auto x_pfx = x_pf;
        (crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0x, env_p1x, x_pfx), [=, p_pex = std::move(p_pex), s_p2x = std::move(s_p2x)](crate::lower::types::Vl value_of_f_8965) {
        return ({
            auto v_pg = crate::lower::types::own_f(value_of_f_8965);
            ({
            auto&& _m = prism_rtl::deref(prism_rtl::deref(p_pex).kind_p);
            prism_rtl::is<crate::syntax::PatternKind::PName>(_m) ? ({
            auto&& n_ph = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
            crate::syntax::lexer::chars::has_prefix_f(prism_rtl::deref(n_ph).sigils_p, Text::lit("&"))
            ? ({
            auto n_phx = n_ph;
            (crate::prelude::call_then(crate::lower::start_local_name_at_f(lx_p0x, crate::check::env::sname_key_f(n_phx), prism_rtl::deref(n_phx).span_p), [=](Text local_name_at_f_9103) {
            return ({
                auto rs_pi = local_name_at_f_9103;
                (crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0x, crate::lower::types::peel_f(crate::lower::binder_ty_f(lx_p0x, prism_rtl::deref(n_phx).span_p))), [=, rs_pi = std::move(rs_pi)](crate::lower::model::OutTy out_ty_of_f_9169) {
                return ({
                    auto bt_pj = out_ty_of_f_9169;
                    (crate::prelude::call_then(crate::lower::expr::start_is_known_ty_f(bt_pj), [=](bool is_known_ty_f_9242) {
                    return ({
                        auto pa_pk = is_known_ty_f_9242
                            ? crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaMut{prism_rtl::cat(rs_pi)})), bt_pj})
                            : crate::lower::model::Pa(crate::lower::model::Pa::PaMut{prism_rtl::cat(rs_pi)});
                        (prism_rtl::finished(std::tuple{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{pa_pk, v_pg})}), crate::lower::types::bind_f(env_p1x, crate::check::env::sname_key_f(n_phx), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{rs_pi}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), bt_pj}))}));
                    });
                }));
                });
            }));
            });
        }));
        })
            : prism_rtl::more(prism_rtl::rc(crate::lower::expr::BlockStmt(lx_p0x, env_p1x, s_p2x)));
        })
            : prism_rtl::more(prism_rtl::rc(crate::lower::expr::BlockStmt(lx_p0x, env_p1x, s_p2x)));
        });
        });
    }));
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SWhile>(_m) ? ({
        auto&& c_pl = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a0;
        auto&& body_pm = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a1;
        ({
        auto body_pmx = body_pm;
        auto c_plx = c_pl;
        auto env_p1x = env_p1;
        auto lx_p0x = lx_p0;
        auto s_p2x = s_p2;
        (crate::prelude::call_then(start_upd_stmts_f(lx_p0x, env_p1x, prism_rtl::deref(body_pmx).stmts_p), [=, c_plx = std::move(c_plx), s_p2x = std::move(s_p2x)](std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env> upd_stmts_f_9541) {
        return ({
            auto&& _inner_pn = upd_stmts_f_9541;
            auto&& inner_pn = std::get<0>(_inner_pn);
            ({
            prism_rtl::is<crate::syntax::Cond::CondExpr>(c_plx) ? ({
            auto&& x_po = prism_rtl::as<crate::syntax::Cond::CondExpr>(c_plx).a0;
            ({
            auto x_pox = prism_rtl::deref(prism_rtl::deref(x_po));
            (crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0x, env_p1x, x_pox), [=](crate::lower::types::Vl value_of_f_9633) { return prism_rtl::finished(std::tuple{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoWhile{crate::lower::types::as_bool_f(value_of_f_9633), inner_pn})}), env_p1x}); }));
        });
        })
            : prism_rtl::is<crate::syntax::Cond::CondBind>(c_plx) ? ({
            auto&& p_pp = prism_rtl::as<crate::syntax::Cond::CondBind>(c_plx).a0;
            auto&& x_pq = prism_rtl::as<crate::syntax::Cond::CondBind>(c_plx).a1;
            auto&& g_or = prism_rtl::as<crate::syntax::Cond::CondBind>(c_plx).a2;
            ({
            auto g_orx = prism_rtl::deref(prism_rtl::deref(g_or));
            auto p_ppx = p_pp;
            auto x_pqx = prism_rtl::deref(prism_rtl::deref(x_pq));
            (crate::prelude::call_then(crate::lower::patterns::start_rust_pat_f(lx_p0x, p_ppx, crate::lower::type_at_f(lx_p0x, prism_rtl::deref(x_pqx).span_p), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat("w", prism_rtl::deref(prism_rtl::deref(s_p2x).span_p).start_p)), [=, g_orx = std::move(g_orx)](crate::lower::patterns::PatOut rust_pat_f_9727) {
            return ({
                auto po_ps = rust_pat_f_9727;
                auto env_b_pt = crate::lower::expr::bind_all_f(env_p1x, prism_rtl::deref(po_ps).binds_p);
                (crate::prelude::call_then(start_upd_stmts_f(lx_p0x, env_b_pt, prism_rtl::deref(body_pmx).stmts_p), [=, po_ps = std::move(po_ps)](std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env> upd_stmts_f_9878) {
                return ({
                    auto&& _inner2_p13 = upd_stmts_f_9878;
                    auto&& inner2_p13 = std::get<0>(_inner2_p13);
                    (crate::prelude::call_then(start_guard_conds_f(lx_p0x, env_b_pt, g_orx), [=](Array<crate::lower::model::Cc> guard_conds_f_10136) {
                    return ({
                        auto conds_pu = crate::prelude::append(prism_rtl::deref(po_ps).conds_p, guard_conds_f_10136);
                        auto tests_pv = crate::prelude::fold(conds_pu, Array<crate::lower::model::Ex>{}, [&](const Array<crate::lower::model::Ex>& acc_p14, const crate::lower::model::Cc& c_p15) {
                            return ({
                                __label__ _done;
                                prism_rtl::Slot<Array<crate::lower::model::Ex>> _v;
                                if (prism_rtl::is<crate::lower::model::Cc::CcIf>(c_p15)) {
                                    auto&& t_p16 = prism_rtl::as<crate::lower::model::Cc::CcIf>(c_p15).a0;
                                    _v.set(crate::prelude::push(acc_p14, t_p16));
                                    goto _done;
                                }
                                {
                                    _v.set(acc_p14);
                                    goto _done;
                                }
                            _done:
                                _v.take();
                            });
                        });
                        auto lets_p10 = crate::prelude::fold(conds_pu, false, [&](const bool& f_p17, const crate::lower::model::Cc& c_p18) { return prism_rtl::deref(f_p17) || crate::lower::expr::is_let_cond_f(c_p18); });
                        auto stop_p11 = crate::prelude::len(tests_pv) == Nat(0u)
                            ? Array<crate::lower::model::Do>{}
                            : Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoIf{crate::lower::model::Ex(crate::lower::model::Ex::XUnary{crate::lower::model::UnOp(crate::lower::model::UnOp::OpNot{}), prism_rtl::rc(all_of_f(tests_pv))}), Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("break")})})}), Array<crate::lower::model::Do>{}})});
                        auto body2_p12 = std::move(lets_p10)
                            ? Array(std::vector{crate::lower::expr::refusal_do_f(Text::lit("a `while` whose pattern matches through an `Rc`"))})
                            : crate::prelude::append(stop_p11, inner2_p13);
                        (crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0x, env_p1x, x_pqx), [=, body2_p12 = std::move(body2_p12)](crate::lower::types::Vl value_of_f_10677) { return prism_rtl::finished(std::tuple{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoWhileLet{prism_rtl::deref(po_ps).pa_p, crate::lower::types::own_f(value_of_f_10677), body2_p12})}), env_p1x}); }));
                    });
                }));
                });
            }));
            });
        }));
        });
        })
            : throw prism_rtl::Panic("no arm matched");
        });
        });
    }));
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m) ? ({
        auto&& x_p19 = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
        ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(x_p19).kind_p);
        prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) ? ({
        auto&& c_p1a = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
        auto&& then_b_p1b = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
        auto&& else_b_o1c = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
        ({
        auto else_b_o1cx = else_b_o1c;
        auto c_p1ax = prism_rtl::deref(prism_rtl::deref(c_p1a));
        auto env_p1x = env_p1;
        auto lx_p0x = lx_p0;
        auto then_b_p1bx = then_b_p1b;
        (crate::prelude::call_then(start_upd_if_f(lx_p0x, env_p1x, c_p1ax, then_b_p1bx, else_b_o1cx), [=](crate::lower::model::Do upd_if_f_10777) { return prism_rtl::finished(std::tuple{Array(std::vector{upd_if_f_10777}), env_p1x}); }));
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m) ? ({
        auto&& scrut_p1d = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
        auto&& arms_p1e = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
        ({
        auto arms_p1ex = arms_p1e;
        auto env_p1x = env_p1;
        auto lx_p0x = lx_p0;
        auto scrut_p1dx = prism_rtl::deref(prism_rtl::deref(scrut_p1d));
        (crate::prelude::call_then(start_upd_match_f(lx_p0x, env_p1x, scrut_p1dx, arms_p1ex), [=](crate::lower::model::Do upd_match_f_10852) { return prism_rtl::finished(std::tuple{Array(std::vector{upd_match_f_10852}), env_p1x}); }));
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EFor>(_m) ? ({
        auto&& binders_o1f = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a0;
        auto&& source_p1g = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a1;
        auto&& body_p1h = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a2;
        ({
        auto binders_o1fx = binders_o1f;
        auto body_p1hx = body_p1h;
        auto env_p1x = env_p1;
        auto lx_p0x = lx_p0;
        auto source_p1gx = prism_rtl::deref(prism_rtl::deref(source_p1g));
        auto x_p19x = x_p19;
        (crate::prelude::call_then(start_upd_for_f(lx_p0x, env_p1x, binders_o1fx, source_p1gx, body_p1hx, prism_rtl::deref(x_p19x).span_p), [=](crate::lower::model::Do upd_for_f_10934) { return prism_rtl::finished(std::tuple{Array(std::vector{upd_for_f_10934}), env_p1x}); }));
    });
    })
        : ({
        auto env_p1x = env_p1;
        auto lx_p0x = lx_p0;
        auto x_p19x = x_p19;
        (crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0x, env_p1x, x_p19x), [=](crate::lower::types::Vl value_of_f_11027) { return prism_rtl::finished(std::tuple{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::types::own_f(value_of_f_11027)})}), env_p1x}); }));
    });
    });
    })
        : prism_rtl::more(prism_rtl::rc(crate::lower::expr::BlockStmt(lx_p0, env_p1, s_p2)));
    });
}


/// `Start UpdStmt, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> start_upd_stmt_f(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Stmt s_p2) {
    return prism_rtl::make_rc<UpdStmt>(lx_p0, env_p1, s_p2);
}


/// UpdFor: unbounded fn Lx, Env, ?ForBinders, Expr, Block, Range -> Do
crate::lower::model::Do upd_for_f(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const std::optional<crate::syntax::ForBinders>& binders_o2, const crate::syntax::Expr& source_p3, const crate::syntax::Block& body_p4, const crate::syntax::Range& span_p5) {
    auto sty_p6 = crate::lower::types::peel_f(crate::lower::type_at_f(lx_p0, source_p3.span_p));
    auto&& _m = ref_binder_o(binders_o2);
    if (prism_rtl::is_some(_m)) {
        auto&& n_p7 = prism_rtl::some_of(_m);
        return is_ref_path_f(source_p3)
            ? upd_for_refs_f(lx_p0, env_p1, n_p7, source_p3, body_p4, span_p5, sty_p6)
            : upd_for_values_f(lx_p0, env_p1, binders_o2, source_p3, body_p4, span_p5, sty_p6);
    }
    if (prism_rtl::is_none(_m)) {
        return upd_for_values_f(lx_p0, env_p1, binders_o2, source_p3, body_p4, span_p5, sty_p6);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::lower::model::Do> UpdFor::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& binders_o2 = this->binders_o2;
    const auto& source_p3 = this->source_p3;
    const auto& body_p4 = this->body_p4;
    const auto& span_p5 = this->span_p5;
    auto sty_p6 = crate::lower::types::peel_f(crate::lower::type_at_f(lx_p0, prism_rtl::deref(source_p3).span_p));
    return ({
        auto&& _m = ref_binder_o(binders_o2);
        prism_rtl::is_some(_m) ? ({
        auto&& n_p7 = prism_rtl::some_of(_m);
        is_ref_path_f(source_p3)
        ? prism_rtl::more(prism_rtl::rc(UpdForRefs(lx_p0, env_p1, n_p7, source_p3, body_p4, span_p5, sty_p6)))
        : prism_rtl::more(prism_rtl::rc(UpdForValues(lx_p0, env_p1, binders_o2, source_p3, body_p4, span_p5, sty_p6)));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::more(prism_rtl::rc(UpdForValues(lx_p0, env_p1, binders_o2, source_p3, body_p4, span_p5, sty_p6)))
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start UpdFor, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Do> start_upd_for_f(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, std::optional<crate::syntax::ForBinders> binders_o2, crate::syntax::Expr source_p3, crate::syntax::Block body_p4, crate::syntax::Range span_p5) {
    return prism_rtl::make_rc<UpdFor>(lx_p0, env_p1, binders_o2, source_p3, body_p4, span_p5);
}


/// UpdForRefs: unbounded fn Lx, Env, SName, Expr, Block, Range, Ty -> Do
crate::lower::model::Do upd_for_refs_f(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::SName& n_p2, const crate::syntax::Expr& source_p3, const crate::syntax::Block& body_p4, const crate::syntax::Range& span_p5, const crate::check::types::Ty& sty_p6) {
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(sty_p6)) {
        auto&& v_p7 = prism_rtl::as<crate::check::types::Ty::TyArray>(sty_p6).a0;
        auto key_name_p8 = prism_rtl::cat("k", span_p5.start_p);
        auto ref_name_p9 = prism_rtl::cat("r", span_p5.start_p);
        auto env1_pa = crate::lower::types::bind_f(crate::lower::types::bind_f(crate::lower::types::bind_f(env_p1, Text::lit("key"), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{key_name_p8}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutNat{})})), Text::lit("ix"), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{key_name_p8}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutNat{})})), crate::check::env::sname_key_f(n_p2), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XTarget{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{ref_name_p9}))}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), crate::lower::types::out_ty_of_f(lx_p0, prism_rtl::deref(prism_rtl::deref(v_p7)))}));
        auto&& _dos_pc = upd_stmts_f(lx_p0, env1_pa, body_p4.stmts_p);
        auto&& dos_pc = std::get<0>(_dos_pc);
        auto head_pb = crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{key_name_p8}), crate::lower::model::Ex(crate::lower::model::Ex::XCall{crate::lower::helper_f(Text::lit("nat_of")), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat("i", span_p5.start_p)})})})});
        return crate::lower::model::Do(crate::lower::model::Do::DoFor{crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{prism_rtl::cat("i", span_p5.start_p)}), crate::lower::model::Pa(crate::lower::model::Pa::PaBind{ref_name_p9})})}), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(place_of_f(lx_p0, env_p1, source_p3)), Text::lit("iter_mut"), Array<crate::lower::model::Ex>{}})), Text::lit("enumerate"), Array<crate::lower::model::Ex>{}}), crate::prelude::append(Array(std::vector{head_pb}), dos_pc)});
    }
    {
        return crate::lower::expr::refusal_do_f(Text::lit("a `for` by reference over what is not an array"));
    }
}


prism_rtl::Turn<crate::lower::model::Do> UpdForRefs::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& n_p2 = this->n_p2;
    const auto& source_p3 = this->source_p3;
    const auto& body_p4 = this->body_p4;
    const auto& span_p5 = this->span_p5;
    const auto& sty_p6 = this->sty_p6;
    return ({
        prism_rtl::is<crate::check::types::Ty::TyArray>(sty_p6) ? ({
        auto&& v_p7 = prism_rtl::as<crate::check::types::Ty::TyArray>(sty_p6).a0;
        ({
        auto key_name_p8 = prism_rtl::cat("k", prism_rtl::deref(span_p5).start_p);
        auto ref_name_p9 = prism_rtl::cat("r", prism_rtl::deref(span_p5).start_p);
        auto body_p4x = body_p4;
        auto env_p1x = env_p1;
        auto lx_p0x = lx_p0;
        auto n_p2x = n_p2;
        auto source_p3x = source_p3;
        auto span_p5x = span_p5;
        auto v_p7x = prism_rtl::deref(prism_rtl::deref(v_p7));
        (crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0x, v_p7x), [=, key_name_p8 = std::move(key_name_p8), ref_name_p9 = std::move(ref_name_p9), body_p4x = std::move(body_p4x), env_p1x = std::move(env_p1x), n_p2x = std::move(n_p2x), source_p3x = std::move(source_p3x), span_p5x = std::move(span_p5x)](crate::lower::model::OutTy out_ty_of_f_12387) {
        return ({
            auto env1_pa = crate::lower::types::bind_f(crate::lower::types::bind_f(crate::lower::types::bind_f(env_p1x, Text::lit("key"), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{key_name_p8}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutNat{})})), Text::lit("ix"), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{key_name_p8}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutNat{})})), crate::check::env::sname_key_f(n_p2x), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XTarget{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{ref_name_p9}))}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), out_ty_of_f_12387}));
            (crate::prelude::call_then(start_upd_stmts_f(lx_p0x, env1_pa, prism_rtl::deref(body_p4x).stmts_p), [=](std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env> upd_stmts_f_12433) {
            return ({
                auto&& _dos_pc = upd_stmts_f_12433;
                auto&& dos_pc = std::get<0>(_dos_pc);
                auto head_pb = crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{key_name_p8}), crate::lower::model::Ex(crate::lower::model::Ex::XCall{crate::lower::helper_f(Text::lit("nat_of")), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat("i", prism_rtl::deref(span_p5x).start_p)})})})});
                (crate::prelude::call_then(start_place_of_f(lx_p0x, env_p1x, source_p3x), [=, head_pb = std::move(head_pb)](crate::lower::model::Ex place_of_f_12651) { return prism_rtl::finished(crate::lower::model::Do(crate::lower::model::Do::DoFor{crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{prism_rtl::cat("i", prism_rtl::deref(span_p5x).start_p)}), crate::lower::model::Pa(crate::lower::model::Pa::PaBind{ref_name_p9})})}), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(place_of_f_12651), Text::lit("iter_mut"), Array<crate::lower::model::Ex>{}})), Text::lit("enumerate"), Array<crate::lower::model::Ex>{}}), crate::prelude::append(Array(std::vector{head_pb}), dos_pc)})); }));
            });
        }));
        });
    }));
    });
    })
        : prism_rtl::finished(crate::lower::expr::refusal_do_f(Text::lit("a `for` by reference over what is not an array")));
    });
}


/// `Start UpdForRefs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Do> start_upd_for_refs_f(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::SName n_p2, crate::syntax::Expr source_p3, crate::syntax::Block body_p4, crate::syntax::Range span_p5, crate::check::types::Ty sty_p6) {
    return prism_rtl::make_rc<UpdForRefs>(lx_p0, env_p1, n_p2, source_p3, body_p4, span_p5, sty_p6);
}


/// ?RefBinder: fn ?ForBinders -> ?SName
std::optional<crate::syntax::SName> ref_binder_o(const std::optional<crate::syntax::ForBinders>& opt0) {
    if (prism_rtl::is_some(opt0)) {
        auto&& fb_p0 = prism_rtl::some_of(opt0);
        auto&& _m = prism_rtl::deref(fb_p0).second_o;
        if (prism_rtl::is_none(_m)) {
            auto&& _m = prism_rtl::deref(prism_rtl::deref(prism_rtl::deref(fb_p0).first_p).kind_p);
            if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
                auto&& n_p1 = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
                return crate::syntax::lexer::chars::has_prefix_f(prism_rtl::deref(n_p1).sigils_p, Text::lit("&"))
                    ? std::optional(n_p1)
                    : std::optional<crate::syntax::SName>{};
            }
            {
                return std::optional<crate::syntax::SName>{};
            }
        }
        {
            return std::optional<crate::syntax::SName>{};
        }
    }
    if (prism_rtl::is_none(opt0)) {
        return std::optional<crate::syntax::SName>{};
    }
    prism_rtl::unreachable("no arm matched");
}


/// IsRefPath: fn Expr -> Bool
bool is_ref_path_f(const crate::syntax::Expr& e_p0) {
    auto&& _m = prism_rtl::deref(e_p0.kind_p);
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n_p1 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        return crate::syntax::lexer::chars::has_prefix_f(prism_rtl::deref(n_p1).sigils_p, Text::lit("&"));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EField>(_m)) {
        auto&& r_p2 = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a0;
        return is_ref_path_f(prism_rtl::deref(prism_rtl::deref(r_p2)));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m)) {
        auto&& r_p3 = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
        return is_ref_path_f(prism_rtl::deref(prism_rtl::deref(r_p3)));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x_p4 = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return is_ref_path_f(prism_rtl::deref(prism_rtl::deref(x_p4)));
    }
    {
        return false;
    }
}


/// UpdForValues: unbounded fn Lx, Env, ?ForBinders, Expr, Block, Range, Ty -> Do
crate::lower::model::Do upd_for_values_f(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const std::optional<crate::syntax::ForBinders>& binders_o2, const crate::syntax::Expr& source_p3, const crate::syntax::Block& body_p4, const crate::syntax::Range& span_p5, const crate::check::types::Ty& sty_p6) {
    auto src_p7 = crate::lower::types::own_f(crate::lower::expr::value_of_f(lx_p0, env_p1, source_p3));
    auto [kt_pf, vt_pg, is_array_ph] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::lower::model::OutTy, crate::lower::model::OutTy, bool>> _v;
        if (prism_rtl::is<crate::check::types::Ty::TyArray>(sty_p6)) {
            auto&& v_pc = prism_rtl::as<crate::check::types::Ty::TyArray>(sty_p6).a0;
            _v.set(std::tuple{crate::lower::model::OutTy(crate::lower::model::OutTy::OutNat{}), crate::lower::types::out_ty_of_f(lx_p0, prism_rtl::deref(prism_rtl::deref(v_pc))), true});
            goto _done;
        }
        if (prism_rtl::is<crate::check::types::Ty::TyMap>(sty_p6)) {
            auto&& k_pd = prism_rtl::as<crate::check::types::Ty::TyMap>(sty_p6).a0;
            auto&& v_pe = prism_rtl::as<crate::check::types::Ty::TyMap>(sty_p6).a1;
            _v.set(std::tuple{crate::lower::types::out_ty_of_f(lx_p0, prism_rtl::deref(prism_rtl::deref(k_pd))), crate::lower::types::out_ty_of_f(lx_p0, prism_rtl::deref(prism_rtl::deref(v_pe))), false});
            goto _done;
        }
        {
            _v.set(std::tuple{crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), true});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto [vty_pl, kty_pm] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::Ty>> _v;
        if (prism_rtl::is<crate::check::types::Ty::TyArray>(sty_p6)) {
            auto&& v_pi = prism_rtl::as<crate::check::types::Ty::TyArray>(sty_p6).a0;
            _v.set(std::tuple{prism_rtl::deref(prism_rtl::deref(v_pi)), crate::check::types::Ty(crate::check::types::Ty::TyCon{Text::lit("Nat"), Array<crate::check::types::Ty>{}})});
            goto _done;
        }
        if (prism_rtl::is<crate::check::types::Ty::TyMap>(sty_p6)) {
            auto&& k_pj = prism_rtl::as<crate::check::types::Ty::TyMap>(sty_p6).a0;
            auto&& v_pk = prism_rtl::as<crate::check::types::Ty::TyMap>(sty_p6).a1;
            _v.set(std::tuple{prism_rtl::deref(prism_rtl::deref(v_pk)), prism_rtl::deref(prism_rtl::deref(k_pj))});
            goto _done;
        }
        {
            _v.set(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::Ty(crate::check::types::Ty::TyErr{})});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto key_name_p8 = prism_rtl::cat("k", span_p5.start_p);
    auto val_name_p9 = prism_rtl::cat("v", span_p5.start_p);
    auto env1_pa = crate::lower::types::bind_f(crate::lower::types::bind_f(env_p1, Text::lit("key"), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{key_name_p8}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), kt_pf})), Text::lit("_"), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{val_name_p9}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), vt_pg}));
    auto env2_pb = is_array_ph
        ? crate::lower::types::bind_f(env1_pa, Text::lit("ix"), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{key_name_p8}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), kt_pf}))
        : env1_pa;
    auto [binds_ps, env3_pt] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> _v;
        if (prism_rtl::is_none(binders_o2)) {
            _v.set(std::tuple{Array<crate::lower::model::Do>{}, env2_pb});
            goto _done;
        }
        if (prism_rtl::is_some(binders_o2)) {
            auto&& fb_pn = prism_rtl::some_of(binders_o2);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> _v;
                auto&& _m = prism_rtl::deref(fb_pn).second_o;
                if (prism_rtl::is_none(_m)) {
                    _v.set(({
                        auto po_po = crate::lower::patterns::rust_pat_f(lx_p0, prism_rtl::deref(fb_pn).first_p, vty_pl, crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat("e", span_p5.start_p));
                        std::tuple{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{prism_rtl::deref(po_po).pa_p, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{val_name_p9}))})})}), crate::lower::expr::bind_all_f(env2_pb, prism_rtl::deref(po_po).binds_p)};
                    }));
                    goto _done;
                }
                if (prism_rtl::is_some(_m)) {
                    auto&& second_pp = prism_rtl::some_of(_m);
                    _v.set(({
                        auto pk_pq = crate::lower::patterns::rust_pat_f(lx_p0, prism_rtl::deref(fb_pn).first_p, kty_pm, crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat("k", span_p5.start_p, "_"));
                        auto pv_pr = crate::lower::patterns::rust_pat_f(lx_p0, second_pp, vty_pl, crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat("e", span_p5.start_p));
                        std::tuple{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{prism_rtl::deref(pk_pq).pa_p, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{key_name_p8}))})}), crate::lower::model::Do(crate::lower::model::Do::DoLet{prism_rtl::deref(pv_pr).pa_p, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{val_name_p9}))})})}), crate::lower::expr::bind_all_f(crate::lower::expr::bind_all_f(env2_pb, prism_rtl::deref(pk_pq).binds_p), prism_rtl::deref(pv_pr).binds_p)};
                    }));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto&& _dos_pu = upd_stmts_f(lx_p0, env3_pt, body_p4.stmts_p);
    auto&& dos_pu = std::get<0>(_dos_pu);
    return is_array_ph
        ? ({
        auto head_pv = crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{key_name_p8}), crate::lower::model::Ex(crate::lower::model::Ex::XCall{crate::lower::helper_f(Text::lit("nat_of")), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat("i", span_p5.start_p)})})})});
        (crate::lower::model::Do(crate::lower::model::Do::DoFor{crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{prism_rtl::cat("i", span_p5.start_p)}), crate::lower::model::Pa(crate::lower::model::Pa::PaBind{val_name_p9})})}), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(src_p7), Text::lit("into_iter"), Array<crate::lower::model::Ex>{}})), Text::lit("enumerate"), Array<crate::lower::model::Ex>{}}), crate::prelude::append(crate::prelude::push(Array<crate::lower::model::Do>{}, head_pv), crate::prelude::append(binds_ps, dos_pu))}));
    })
        : crate::lower::model::Do(crate::lower::model::Do::DoFor{crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{key_name_p8}), crate::lower::model::Pa(crate::lower::model::Pa::PaBind{val_name_p9})})}), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(src_p7), Text::lit("into_iter"), Array<crate::lower::model::Ex>{}}), crate::prelude::append(binds_ps, dos_pu)});
}


prism_rtl::Turn<crate::lower::model::Do> UpdForValues::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& binders_o2 = this->binders_o2;
    const auto& source_p3 = this->source_p3;
    const auto& body_p4 = this->body_p4;
    const auto& span_p5 = this->span_p5;
    const auto& sty_p6 = this->sty_p6;
    auto binders_o2x = binders_o2;
    auto body_p4x = body_p4;
    auto env_p1x = env_p1;
    auto lx_p0x = lx_p0;
    auto source_p3x = source_p3;
    auto span_p5x = span_p5;
    auto sty_p6x = sty_p6;
    return crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0x, env_p1x, source_p3x), [=](crate::lower::types::Vl value_of_f_13546) {
        return ({
            auto src_p7 = crate::lower::types::own_f(value_of_f_13546);
            auto [kt_pf, vt_pg, is_array_ph] = ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<crate::lower::model::OutTy, crate::lower::model::OutTy, bool>> _v;
                if (prism_rtl::is<crate::check::types::Ty::TyArray>(sty_p6x)) {
                    auto&& v_pc = prism_rtl::as<crate::check::types::Ty::TyArray>(sty_p6x).a0;
                    _v.set(std::tuple{crate::lower::model::OutTy(crate::lower::model::OutTy::OutNat{}), crate::lower::types::out_ty_of_f(lx_p0x, prism_rtl::deref(prism_rtl::deref(v_pc))), true});
                    goto _done;
                }
                if (prism_rtl::is<crate::check::types::Ty::TyMap>(sty_p6x)) {
                    auto&& k_pd = prism_rtl::as<crate::check::types::Ty::TyMap>(sty_p6x).a0;
                    auto&& v_pe = prism_rtl::as<crate::check::types::Ty::TyMap>(sty_p6x).a1;
                    _v.set(std::tuple{crate::lower::types::out_ty_of_f(lx_p0x, prism_rtl::deref(prism_rtl::deref(k_pd))), crate::lower::types::out_ty_of_f(lx_p0x, prism_rtl::deref(prism_rtl::deref(v_pe))), false});
                    goto _done;
                }
                {
                    _v.set(std::tuple{crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), true});
                    goto _done;
                }
            _done:
                _v.take();
            });
            auto [vty_pl, kty_pm] = ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::Ty>> _v;
                if (prism_rtl::is<crate::check::types::Ty::TyArray>(sty_p6x)) {
                    auto&& v_pi = prism_rtl::as<crate::check::types::Ty::TyArray>(sty_p6x).a0;
                    _v.set(std::tuple{prism_rtl::deref(prism_rtl::deref(v_pi)), crate::check::types::Ty(crate::check::types::Ty::TyCon{Text::lit("Nat"), Array<crate::check::types::Ty>{}})});
                    goto _done;
                }
                if (prism_rtl::is<crate::check::types::Ty::TyMap>(sty_p6x)) {
                    auto&& k_pj = prism_rtl::as<crate::check::types::Ty::TyMap>(sty_p6x).a0;
                    auto&& v_pk = prism_rtl::as<crate::check::types::Ty::TyMap>(sty_p6x).a1;
                    _v.set(std::tuple{prism_rtl::deref(prism_rtl::deref(v_pk)), prism_rtl::deref(prism_rtl::deref(k_pj))});
                    goto _done;
                }
                {
                    _v.set(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::Ty(crate::check::types::Ty::TyErr{})});
                    goto _done;
                }
            _done:
                _v.take();
            });
            auto key_name_p8 = prism_rtl::cat("k", prism_rtl::deref(span_p5x).start_p);
            auto val_name_p9 = prism_rtl::cat("v", prism_rtl::deref(span_p5x).start_p);
            auto env1_pa = crate::lower::types::bind_f(crate::lower::types::bind_f(env_p1x, Text::lit("key"), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{key_name_p8}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), kt_pf})), Text::lit("_"), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{val_name_p9}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), vt_pg}));
            auto env2_pb = is_array_ph
                ? crate::lower::types::bind_f(env1_pa, Text::lit("ix"), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{key_name_p8}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), kt_pf}))
                : env1_pa;
            auto [binds_ps, env3_pt] = ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> _v;
                if (prism_rtl::is_none(binders_o2x)) {
                    _v.set(std::tuple{Array<crate::lower::model::Do>{}, env2_pb});
                    goto _done;
                }
                if (prism_rtl::is_some(binders_o2x)) {
                    auto&& fb_pn = prism_rtl::some_of(binders_o2x);
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> _v;
                        auto&& _m = prism_rtl::deref(fb_pn).second_o;
                        if (prism_rtl::is_none(_m)) {
                            _v.set(({
                                auto po_po = crate::lower::patterns::rust_pat_f(lx_p0x, prism_rtl::deref(fb_pn).first_p, vty_pl, crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat("e", prism_rtl::deref(span_p5x).start_p));
                                std::tuple{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{prism_rtl::deref(po_po).pa_p, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{val_name_p9}))})})}), crate::lower::expr::bind_all_f(env2_pb, prism_rtl::deref(po_po).binds_p)};
                            }));
                            goto _done;
                        }
                        if (prism_rtl::is_some(_m)) {
                            auto&& second_pp = prism_rtl::some_of(_m);
                            _v.set(({
                                auto pk_pq = crate::lower::patterns::rust_pat_f(lx_p0x, prism_rtl::deref(fb_pn).first_p, kty_pm, crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat("k", prism_rtl::deref(span_p5x).start_p, "_"));
                                auto pv_pr = crate::lower::patterns::rust_pat_f(lx_p0x, second_pp, vty_pl, crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat("e", prism_rtl::deref(span_p5x).start_p));
                                std::tuple{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{prism_rtl::deref(pk_pq).pa_p, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{key_name_p8}))})}), crate::lower::model::Do(crate::lower::model::Do::DoLet{prism_rtl::deref(pv_pr).pa_p, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{val_name_p9}))})})}), crate::lower::expr::bind_all_f(crate::lower::expr::bind_all_f(env2_pb, prism_rtl::deref(pk_pq).binds_p), prism_rtl::deref(pv_pr).binds_p)};
                            }));
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            (crate::prelude::call_then(start_upd_stmts_f(lx_p0x, env3_pt, prism_rtl::deref(body_p4x).stmts_p), [=, src_p7 = std::move(src_p7), key_name_p8 = std::move(key_name_p8), val_name_p9 = std::move(val_name_p9)](std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env> upd_stmts_f_14827) {
            return ({
                auto&& _dos_pu = upd_stmts_f_14827;
                auto&& dos_pu = std::get<0>(_dos_pu);
                is_array_ph
                ? ({
                auto head_pv = crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{key_name_p8}), crate::lower::model::Ex(crate::lower::model::Ex::XCall{crate::lower::helper_f(Text::lit("nat_of")), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat("i", prism_rtl::deref(span_p5x).start_p)})})})});
                (prism_rtl::finished(crate::lower::model::Do(crate::lower::model::Do::DoFor{crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{prism_rtl::cat("i", prism_rtl::deref(span_p5x).start_p)}), crate::lower::model::Pa(crate::lower::model::Pa::PaBind{val_name_p9})})}), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(src_p7), Text::lit("into_iter"), Array<crate::lower::model::Ex>{}})), Text::lit("enumerate"), Array<crate::lower::model::Ex>{}}), crate::prelude::append(crate::prelude::push(Array<crate::lower::model::Do>{}, head_pv), crate::prelude::append(binds_ps, dos_pu))})));
            })
                : prism_rtl::finished(crate::lower::model::Do(crate::lower::model::Do::DoFor{crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{key_name_p8}), crate::lower::model::Pa(crate::lower::model::Pa::PaBind{val_name_p9})})}), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(src_p7), Text::lit("into_iter"), Array<crate::lower::model::Ex>{}}), crate::prelude::append(binds_ps, dos_pu)}));
            });
        }));
        });
    });
}


/// `Start UpdForValues, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Do> start_upd_for_values_f(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, std::optional<crate::syntax::ForBinders> binders_o2, crate::syntax::Expr source_p3, crate::syntax::Block body_p4, crate::syntax::Range span_p5, crate::check::types::Ty sty_p6) {
    return prism_rtl::make_rc<UpdForValues>(lx_p0, env_p1, binders_o2, source_p3, body_p4, span_p5, sty_p6);
}


/// UpdIf: unbounded fn Lx, Env, Cond, Block, ?Block -> Do
crate::lower::model::Do upd_if_f(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Cond& c_p2, const crate::syntax::Block& then_b_p3, const std::optional<crate::syntax::Block>& else_b_o4) {
    auto&& _else_dos_p6 = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> _v;
        if (prism_rtl::is_some(else_b_o4)) {
            auto&& b_p5 = prism_rtl::some_of(else_b_o4);
            _v.set(upd_stmts_f(lx_p0, env_p1, prism_rtl::deref(b_p5).stmts_p));
            goto _done;
        }
        if (prism_rtl::is_none(else_b_o4)) {
            _v.set(std::tuple{Array<crate::lower::model::Do>{}, env_p1});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto&& else_dos_p6 = std::get<0>(_else_dos_p6);
    if (prism_rtl::is<crate::syntax::Cond::CondExpr>(c_p2)) {
        auto&& x_p7 = prism_rtl::as<crate::syntax::Cond::CondExpr>(c_p2).a0;
        auto&& _then_dos_p8 = upd_stmts_f(lx_p0, env_p1, then_b_p3.stmts_p);
        auto&& then_dos_p8 = std::get<0>(_then_dos_p8);
        return crate::lower::model::Do(crate::lower::model::Do::DoIf{crate::lower::types::as_bool_f(crate::lower::expr::value_of_f(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(x_p7)))), then_dos_p8, else_dos_p6});
    }
    if (prism_rtl::is<crate::syntax::Cond::CondBind>(c_p2)) {
        auto&& p_p9 = prism_rtl::as<crate::syntax::Cond::CondBind>(c_p2).a0;
        auto&& x_pa = prism_rtl::as<crate::syntax::Cond::CondBind>(c_p2).a1;
        auto po_pb = crate::lower::patterns::rust_pat_f(lx_p0, p_p9, crate::lower::type_at_f(lx_p0, prism_rtl::deref(x_pa).span_p), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat("u", prism_rtl::deref(prism_rtl::deref(x_pa).span_p).start_p));
        auto&& _then_dos_pc = upd_stmts_f(lx_p0, crate::lower::expr::bind_all_f(env_p1, prism_rtl::deref(po_pb).binds_p), then_b_p3.stmts_p);
        auto&& then_dos_pc = std::get<0>(_then_dos_pc);
        return crate::lower::model::Do(crate::lower::model::Do::DoIfLet{prism_rtl::deref(po_pb).pa_p, crate::lower::types::own_f(crate::lower::expr::value_of_f(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(x_pa)))), then_dos_pc, else_dos_p6});
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::lower::model::Do> UpdIf::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& c_p2 = this->c_p2;
    const auto& then_b_p3 = this->then_b_p3;
    const auto& else_b_o4 = this->else_b_o4;
    auto&& _else_dos_p6 = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> _v;
        if (prism_rtl::is_some(else_b_o4)) {
            auto&& b_p5 = prism_rtl::some_of(else_b_o4);
            _v.set(upd_stmts_f(lx_p0, env_p1, prism_rtl::deref(b_p5).stmts_p));
            goto _done;
        }
        if (prism_rtl::is_none(else_b_o4)) {
            _v.set(std::tuple{Array<crate::lower::model::Do>{}, env_p1});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto&& else_dos_p6 = std::get<0>(_else_dos_p6);
    return ({
        prism_rtl::is<crate::syntax::Cond::CondExpr>(c_p2) ? ({
        auto&& x_p7 = prism_rtl::as<crate::syntax::Cond::CondExpr>(c_p2).a0;
        ({
        auto env_p1x = env_p1;
        auto lx_p0x = lx_p0;
        auto then_b_p3x = then_b_p3;
        auto x_p7x = prism_rtl::deref(prism_rtl::deref(x_p7));
        (crate::prelude::call_then(start_upd_stmts_f(lx_p0x, env_p1x, prism_rtl::deref(then_b_p3x).stmts_p), [=, x_p7x = std::move(x_p7x)](std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env> upd_stmts_f_15546) {
        return ({
            auto&& _then_dos_p8 = upd_stmts_f_15546;
            auto&& then_dos_p8 = std::get<0>(_then_dos_p8);
            (crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0x, env_p1x, x_p7x), [=](crate::lower::types::Vl value_of_f_15602) { return prism_rtl::finished(crate::lower::model::Do(crate::lower::model::Do::DoIf{crate::lower::types::as_bool_f(value_of_f_15602), then_dos_p8, else_dos_p6})); }));
        });
    }));
    });
    })
        : prism_rtl::is<crate::syntax::Cond::CondBind>(c_p2) ? ({
        auto&& p_p9 = prism_rtl::as<crate::syntax::Cond::CondBind>(c_p2).a0;
        auto&& x_pa = prism_rtl::as<crate::syntax::Cond::CondBind>(c_p2).a1;
        ({
        auto env_p1x = env_p1;
        auto lx_p0x = lx_p0;
        auto p_p9x = p_p9;
        auto then_b_p3x = then_b_p3;
        auto x_pax = prism_rtl::deref(prism_rtl::deref(x_pa));
        (crate::prelude::call_then(crate::lower::patterns::start_rust_pat_f(lx_p0x, p_p9x, crate::lower::type_at_f(lx_p0x, prism_rtl::deref(x_pax).span_p), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat("u", prism_rtl::deref(prism_rtl::deref(x_pax).span_p).start_p)), [=, env_p1x = std::move(env_p1x), then_b_p3x = std::move(then_b_p3x)](crate::lower::patterns::PatOut rust_pat_f_15693) {
        return ({
            auto po_pb = rust_pat_f_15693;
            (crate::prelude::call_then(start_upd_stmts_f(lx_p0x, crate::lower::expr::bind_all_f(env_p1x, prism_rtl::deref(po_pb).binds_p), prism_rtl::deref(then_b_p3x).stmts_p), [=](std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env> upd_stmts_f_15792) {
            return ({
                auto&& _then_dos_pc = upd_stmts_f_15792;
                auto&& then_dos_pc = std::get<0>(_then_dos_pc);
                (crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0x, env_p1x, x_pax), [=](crate::lower::types::Vl value_of_f_15875) { return prism_rtl::finished(crate::lower::model::Do(crate::lower::model::Do::DoIfLet{prism_rtl::deref(po_pb).pa_p, crate::lower::types::own_f(value_of_f_15875), then_dos_pc, else_dos_p6})); }));
            });
        }));
        });
    }));
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start UpdIf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Do> start_upd_if_f(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Cond c_p2, crate::syntax::Block then_b_p3, std::optional<crate::syntax::Block> else_b_o4) {
    return prism_rtl::make_rc<UpdIf>(lx_p0, env_p1, c_p2, then_b_p3, else_b_o4);
}


/// UpdMatch: unbounded fn Lx, Env, Expr, [Arm] -> Do
crate::lower::model::Do upd_match_f(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& scrut_p2, const Array<crate::syntax::Arm>& arms_p3) {
    auto sv_p4 = crate::lower::expr::value_of_f(lx_p0, env_p1, scrut_p2);
    auto sty_p5 = crate::lower::type_at_f(lx_p0, scrut_p2.span_p);
    auto arms3_p6 = crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(crate::prelude::len(arms_p3)), ({
        auto arms_p3x = arms_p3;
        auto lx_p0x = lx_p0;
        auto sty_p5x = sty_p5;
        auto scrut_p2x = scrut_p2;
        auto env_p1x = env_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::XArm>(Nat)>>(prism_rtl::rc([=, arms_p3x = std::move(arms_p3x), lx_p0x = std::move(lx_p0x), sty_p5x = std::move(sty_p5x), scrut_p2x = std::move(scrut_p2x), env_p1x = std::move(env_p1x)](Nat p0) {
        return ({
            auto arms_p3xy = arms_p3x;
            auto lx_p0xy = lx_p0x;
            auto sty_p5xy = sty_p5x;
            auto scrut_p2xy = scrut_p2x;
            auto env_p1xy = env_p1x;
            (crate::prelude::entered(crate::prelude::once_job([=, arms_p3xy = std::move(arms_p3xy), lx_p0xy = std::move(lx_p0xy), sty_p5xy = std::move(sty_p5xy), scrut_p2xy = std::move(scrut_p2xy), env_p1xy = std::move(env_p1xy)]() {
            return ({
                auto i_p7 = p0;
                ({
                auto arm_p8 = crate::prelude::or_(crate::prelude::index(arms_p3xy, i_p7), crate::lower::expr::dummy_arm_p());
                (crate::prelude::call_then(crate::lower::expr::start_arm_pat_f(lx_p0xy, prism_rtl::deref(arm_p8).pattern_o, sty_p5xy, crate::lower::types::Holding(crate::lower::types::Holding::ByRef{}), prism_rtl::cat("u", prism_rtl::deref(prism_rtl::deref(scrut_p2xy).span_p).start_p, "_", i_p7)), [=](crate::lower::patterns::PatOut arm_pat_f_16174) {
                return ({
                    auto po_p9 = arm_pat_f_16174;
                    (crate::prelude::call_then(start_upd_stmts_f(lx_p0xy, crate::lower::expr::bind_all_f(env_p1xy, prism_rtl::deref(po_p9).binds_p), prism_rtl::deref(prism_rtl::deref(arm_p8).body_p).stmts_p), [=](std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env> upd_stmts_f_16267) {
                    return ({
                        auto&& _dos_pb = upd_stmts_f_16267;
                        auto&& dos_pb = std::get<0>(_dos_pb);
                        (crate::prelude::call_then(start_guard_conds_f(lx_p0xy, crate::lower::expr::bind_all_f(env_p1xy, prism_rtl::deref(po_p9).binds_p), prism_rtl::deref(arm_p8).guard_o), [=](Array<crate::lower::model::Cc> guard_conds_f_16360) {
                        return ({
                            auto guarded_pa = crate::prelude::append(prism_rtl::deref(po_p9).conds_p, guard_conds_f_16360);
                            (prism_rtl::finished(crate::lower::model::XArm{.pat_p = prism_rtl::deref(po_p9).pa_p, .conds_p = guarded_pa, .body_p = crate::lower::model::Ex(crate::lower::model::Ex::XBlock{dos_pb, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}))})}));
                        });
                    }));
                    });
                }));
                });
            }));
            });
            });
        })));
        });
    })));
    })));
    return crate::prelude::fold(arms3_p6, false, [&](const bool& f_pc, const crate::lower::model::XArm& a_pd) { return prism_rtl::deref(f_pc) || (crate::prelude::len(prism_rtl::deref(a_pd).conds_p) > Nat(0u)); })
        ? crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::types::own_f(crate::lower::expr::arms_value_f(crate::lower::types::ref_f(sv_p4), arms3_p6, prism_rtl::cat("\'u", prism_rtl::deref(scrut_p2.span_p).start_p), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})))})
        : crate::lower::model::Do(crate::lower::model::Do::DoMatch{crate::lower::types::ref_f(sv_p4), crate::prelude::each(arms3_p6, [&](const crate::lower::model::XArm& a_pe) { return std::tuple{prism_rtl::deref(a_pe).pat_p, arm_dos_f(prism_rtl::deref(a_pe).body_p)}; })});
}


prism_rtl::Turn<crate::lower::model::Do> UpdMatch::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& scrut_p2 = this->scrut_p2;
    const auto& arms_p3 = this->arms_p3;
    auto arms_p3x = arms_p3;
    auto env_p1x = env_p1;
    auto lx_p0x = lx_p0;
    auto scrut_p2x = scrut_p2;
    return crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0x, env_p1x, scrut_p2x), [=](crate::lower::types::Vl value_of_f_16012) {
        return ({
            auto sv_p4 = value_of_f_16012;
            auto sty_p5 = crate::lower::type_at_f(lx_p0x, prism_rtl::deref(scrut_p2x).span_p);
            (crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(crate::prelude::len(arms_p3x)), ({
            auto arms_p3xx = arms_p3x;
            auto lx_p0xx = lx_p0x;
            auto sty_p5x = sty_p5;
            auto scrut_p2xx = scrut_p2x;
            auto env_p1xx = env_p1x;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::XArm>(Nat)>>(prism_rtl::rc([=, arms_p3xx = std::move(arms_p3xx), lx_p0xx = std::move(lx_p0xx), sty_p5x = std::move(sty_p5x), scrut_p2xx = std::move(scrut_p2xx), env_p1xx = std::move(env_p1xx)](Nat p0) {
            return ({
                auto arms_p3xxy = arms_p3xx;
                auto lx_p0xxy = lx_p0xx;
                auto sty_p5xy = sty_p5x;
                auto scrut_p2xxy = scrut_p2xx;
                auto env_p1xxy = env_p1xx;
                (crate::prelude::entered(crate::prelude::once_job([=, arms_p3xxy = std::move(arms_p3xxy), lx_p0xxy = std::move(lx_p0xxy), sty_p5xy = std::move(sty_p5xy), scrut_p2xxy = std::move(scrut_p2xxy), env_p1xxy = std::move(env_p1xxy)]() {
                return ({
                    auto i_p7 = p0;
                    ({
                    auto arm_p8 = crate::prelude::or_(crate::prelude::index(arms_p3xxy, i_p7), crate::lower::expr::dummy_arm_p());
                    (crate::prelude::call_then(crate::lower::expr::start_arm_pat_f(lx_p0xxy, prism_rtl::deref(arm_p8).pattern_o, sty_p5xy, crate::lower::types::Holding(crate::lower::types::Holding::ByRef{}), prism_rtl::cat("u", prism_rtl::deref(prism_rtl::deref(scrut_p2xxy).span_p).start_p, "_", i_p7)), [=](crate::lower::patterns::PatOut arm_pat_f_16174) {
                    return ({
                        auto po_p9 = arm_pat_f_16174;
                        (crate::prelude::call_then(start_upd_stmts_f(lx_p0xxy, crate::lower::expr::bind_all_f(env_p1xxy, prism_rtl::deref(po_p9).binds_p), prism_rtl::deref(prism_rtl::deref(arm_p8).body_p).stmts_p), [=](std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env> upd_stmts_f_16267) {
                        return ({
                            auto&& _dos_pb = upd_stmts_f_16267;
                            auto&& dos_pb = std::get<0>(_dos_pb);
                            (crate::prelude::call_then(start_guard_conds_f(lx_p0xxy, crate::lower::expr::bind_all_f(env_p1xxy, prism_rtl::deref(po_p9).binds_p), prism_rtl::deref(arm_p8).guard_o), [=](Array<crate::lower::model::Cc> guard_conds_f_16360) {
                            return ({
                                auto guarded_pa = crate::prelude::append(prism_rtl::deref(po_p9).conds_p, guard_conds_f_16360);
                                (prism_rtl::finished(crate::lower::model::XArm{.pat_p = prism_rtl::deref(po_p9).pa_p, .conds_p = guarded_pa, .body_p = crate::lower::model::Ex(crate::lower::model::Ex::XBlock{dos_pb, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}))})}));
                            });
                        }));
                        });
                    }));
                    });
                }));
                });
                });
            })));
            });
        })));
        })), [=, sv_p4 = std::move(sv_p4)](Array<crate::lower::model::XArm> each_16087) {
            return ({
                auto arms3_p6 = each_16087;
                (crate::prelude::fold(arms3_p6, false, [&](const bool& f_pc, const crate::lower::model::XArm& a_pd) { return prism_rtl::deref(f_pc) || (crate::prelude::len(prism_rtl::deref(a_pd).conds_p) > Nat(0u)); })
                ? prism_rtl::finished(crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::types::own_f(crate::lower::expr::arms_value_f(crate::lower::types::ref_f(sv_p4), arms3_p6, prism_rtl::cat("\'u", prism_rtl::deref(prism_rtl::deref(scrut_p2x).span_p).start_p), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})))}))
                : prism_rtl::finished(crate::lower::model::Do(crate::lower::model::Do::DoMatch{crate::lower::types::ref_f(sv_p4), crate::prelude::each(arms3_p6, [&](const crate::lower::model::XArm& a_pe) { return std::tuple{prism_rtl::deref(a_pe).pat_p, arm_dos_f(prism_rtl::deref(a_pe).body_p)}; })})));
            });
        }));
        });
    });
}


/// `Start UpdMatch, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Do> start_upd_match_f(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr scrut_p2, Array<crate::syntax::Arm> arms_p3) {
    return prism_rtl::make_rc<UpdMatch>(lx_p0, env_p1, scrut_p2, arms_p3);
}


/// AllOf: fn [Ex] -> Ex
crate::lower::model::Ex all_of_f(const Array<crate::lower::model::Ex>& xs0) {
    {
        auto&& c0_0 = xs0;
        if (c0_0.size() == 1u) {
            {
                auto&& _c1 = crate::prelude::index(c0_0, Nat(0u));
                if (prism_rtl::is_some(_c1)) {
                    auto&& one_p0 = prism_rtl::some_of(_c1);
                    return one_p0;
                }
            }
        }
    }
    {
        auto&& xs_p1 = xs0;
        return crate::prelude::fold(crate::prelude::drop(xs_p1, Nat(1u)), crate::prelude::or_(crate::prelude::index(xs_p1, Nat(0u)), crate::lower::model::Ex(crate::lower::model::Ex::XBool{true})), [&](const crate::lower::model::Ex& acc_p2, const crate::lower::model::Ex& x_p3) { return crate::lower::model::Ex(crate::lower::model::Ex::XBin{crate::lower::model::BinOp(crate::lower::model::BinOp::OpAnd{}), prism_rtl::rc(acc_p2), prism_rtl::rc(x_p3)}); });
    }
}


/// ArmDos: fn Ex -> [Do]
Array<crate::lower::model::Do> arm_dos_f(const crate::lower::model::Ex& ex0) {
    if (prism_rtl::is<crate::lower::model::Ex::XBlock>(ex0)) {
        auto&& dos_p0 = prism_rtl::as<crate::lower::model::Ex::XBlock>(ex0).a0;
        return dos_p0;
    }
    {
        auto&& x_p1 = ex0;
        return Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{x_p1})});
    }
}


/// GuardConds: unbounded fn Lx, Env, ?Expr -> [Cc]
Array<crate::lower::model::Cc> guard_conds_f(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const std::optional<crate::syntax::Expr>& opt2) {
    if (prism_rtl::is_some(opt2)) {
        auto&& ge_p2 = prism_rtl::some_of(opt2);
        return Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::types::as_bool_f(crate::lower::expr::value_of_f(lx_p0, env_p1, ge_p2))})});
    }
    if (prism_rtl::is_none(opt2)) {
        return Array<crate::lower::model::Cc>{};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<crate::lower::model::Cc>> GuardConds::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& opt2 = this->opt2;
    return ({
        prism_rtl::is_some(opt2) ? ({
        auto&& ge_p2 = prism_rtl::some_of(opt2);
        ({
        auto env_p1x = env_p1;
        auto ge_p2x = ge_p2;
        auto lx_p0x = lx_p0;
        (crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0x, env_p1x, ge_p2x), [=](crate::lower::types::Vl value_of_f_17203) { return prism_rtl::finished(Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::types::as_bool_f(value_of_f_17203)})})); }));
    });
    })
        : prism_rtl::is_none(opt2) ? prism_rtl::finished(Array<crate::lower::model::Cc>{})
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start GuardConds, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::lower::model::Cc>> start_guard_conds_f(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, std::optional<crate::syntax::Expr> opt2) {
    return prism_rtl::make_rc<GuardConds>(lx_p0, env_p1, opt2);
}


/// PlaceOf: unbounded fn Lx, Env, Expr -> Ex
crate::lower::model::Ex place_of_f(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& e_p2) {
    auto&& _m = prism_rtl::deref(e_p2.kind_p);
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n_p3 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        auto&& _m = crate::prelude::get(env_p1.names_p, crate::check::env::sname_key_f(n_p3));
        if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m))) {
            auto&& rs_p4 = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
            return rs_p4;
        }
        {
            return crate::lower::model::Ex(crate::lower::model::Ex::XVar{crate::lower::snake_f(crate::check::env::sname_key_f(n_p3))});
        }
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EField>(_m)) {
        auto&& r_p5 = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a0;
        auto&& name_p6 = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a2;
        auto&& _f_p7 = crate::lower::expr::field_info_f(lx_p0, crate::lower::types::peel_f(place_ty_f(lx_p0, prism_rtl::deref(prism_rtl::deref(r_p5)))), prism_rtl::deref(name_p6).name_p);
        auto&& f_p7 = std::get<2>(_f_p7);
        return crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(place_of_f(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(r_p5)))), f_p7});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m)) {
        auto&& r_p8 = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
        auto&& k_p9 = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a1;
        auto rt_pa = crate::lower::types::out_ty_of_f(lx_p0, crate::lower::types::peel_f(place_ty_f(lx_p0, prism_rtl::deref(prism_rtl::deref(r_p8)))));
        auto f_pb = ({
            __label__ _done;
            prism_rtl::Slot<Text> _v;
            if (prism_rtl::is<crate::lower::model::OutTy::OutMap>(rt_pa)) {
                _v.set(Text::lit("at_mut_map"));
                goto _done;
            }
            {
                _v.set(Text::lit("at_mut"));
                goto _done;
            }
        _done:
            _v.take();
        });
        return crate::lower::model::Ex(crate::lower::model::Ex::XDeref{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{f_pb, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRefMut{prism_rtl::rc(place_of_f(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(r_p8))))}), crate::lower::expr::argument_f(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(k_p9)))})}))});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x_pc = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return place_of_f(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(x_pc)));
    }
    {
        return crate::lower::expr::refusal_f(Text::lit("a reference path this back end does not lower"));
    }
}


prism_rtl::Turn<crate::lower::model::Ex> PlaceOf::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& e_p2 = this->e_p2;
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p2).kind_p);
        prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? ({
        auto&& n_p3 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(env_p1).names_p, crate::check::env::sname_key_f(n_p3));
        prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)) ? ({
        auto&& rs_p4 = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
        prism_rtl::finished(rs_p4);
    })
        : prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XVar{crate::lower::snake_f(crate::check::env::sname_key_f(n_p3))}));
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EField>(_m) ? ({
        auto&& r_p5 = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a0;
        auto&& name_p6 = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a2;
        ({
        auto env_p1x = env_p1;
        auto lx_p0x = lx_p0;
        auto name_p6x = name_p6;
        auto r_p5x = prism_rtl::deref(prism_rtl::deref(r_p5));
        (crate::prelude::call_then(start_place_ty_f(lx_p0x, r_p5x), [=, env_p1x = std::move(env_p1x), name_p6x = std::move(name_p6x)](crate::check::types::Ty place_ty_f_17620) {
        return crate::prelude::call_then(crate::lower::expr::start_field_info_f(lx_p0x, crate::lower::types::peel_f(place_ty_f_17620), prism_rtl::deref(name_p6x).name_p), [=](std::tuple<crate::lower::model::OutTy, bool, Text> field_info_f_17599) {
            return ({
                auto&& _f_p7 = field_info_f_17599;
                auto&& f_p7 = std::get<2>(_f_p7);
                (crate::prelude::call_then(start_place_of_f(lx_p0x, env_p1x, r_p5x), [=](crate::lower::model::Ex place_of_f_17663) { return prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(place_of_f_17663), f_p7})); }));
            });
        });
    }));
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m) ? ({
        auto&& r_p8 = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
        auto&& k_p9 = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a1;
        ({
        auto env_p1x = env_p1;
        auto k_p9x = prism_rtl::deref(prism_rtl::deref(k_p9));
        auto lx_p0x = lx_p0;
        auto r_p8x = prism_rtl::deref(prism_rtl::deref(r_p8));
        (crate::prelude::call_then(start_place_ty_f(lx_p0x, r_p8x), [=, env_p1x = std::move(env_p1x), k_p9x = std::move(k_p9x)](crate::check::types::Ty place_ty_f_17739) {
        return crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0x, crate::lower::types::peel_f(place_ty_f_17739)), [=](crate::lower::model::OutTy out_ty_of_f_17720) {
            return ({
                auto rt_pa = out_ty_of_f_17720;
                auto f_pb = ({
                    __label__ _done;
                    prism_rtl::Slot<Text> _v;
                    if (prism_rtl::is<crate::lower::model::OutTy::OutMap>(rt_pa)) {
                        _v.set(Text::lit("at_mut_map"));
                        goto _done;
                    }
                    {
                        _v.set(Text::lit("at_mut"));
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                (crate::prelude::call_then(start_place_of_f(lx_p0x, env_p1x, r_p8x), [=, f_pb = std::move(f_pb)](crate::lower::model::Ex place_of_f_17898) { return crate::prelude::call_then(crate::lower::expr::start_argument_f(lx_p0x, env_p1x, k_p9x), [=](crate::lower::model::Ex argument_f_17921) { return prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XDeref{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{f_pb, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRefMut{prism_rtl::rc(place_of_f_17898)}), argument_f_17921})}))})); }); }));
            });
        });
    }));
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
        auto&& x_pc = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(PlaceOf(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(x_pc)))));
    })
        : prism_rtl::finished(crate::lower::expr::refusal_f(Text::lit("a reference path this back end does not lower")));
    });
}


/// `Start PlaceOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Ex> start_place_of_f(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr e_p2) {
    return prism_rtl::make_rc<PlaceOf>(lx_p0, env_p1, e_p2);
}


/// PlaceTy: unbounded fn Lx, Expr -> Ty
crate::check::types::Ty place_ty_f(const crate::lower::Lx& lx_p0, const crate::syntax::Expr& e_p1) {
    auto&& _m = crate::lower::type_at_f(lx_p0, e_p1.span_p);
    if (prism_rtl::is<crate::check::types::Ty::TyErr>(_m)) {
        auto&& _m = prism_rtl::deref(e_p1.kind_p);
        if (prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m)) {
            auto&& r_p2 = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
            auto&& _m = crate::lower::types::peel_f(place_ty_f(lx_p0, prism_rtl::deref(prism_rtl::deref(r_p2))));
            if (prism_rtl::is<crate::check::types::Ty::TyArray>(_m)) {
                auto&& el_p3 = prism_rtl::as<crate::check::types::Ty::TyArray>(_m).a0;
                return prism_rtl::deref(el_p3);
            }
            if (prism_rtl::is<crate::check::types::Ty::TyMap>(_m)) {
                auto&& v_p4 = prism_rtl::as<crate::check::types::Ty::TyMap>(_m).a1;
                return prism_rtl::deref(v_p4);
            }
            {
                return crate::check::types::Ty(crate::check::types::Ty::TyErr{});
            }
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EField>(_m)) {
            auto&& r_p5 = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a0;
            auto&& name_p6 = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a2;
            return field_ty_f(lx_p0, crate::lower::types::peel_f(place_ty_f(lx_p0, prism_rtl::deref(prism_rtl::deref(r_p5)))), prism_rtl::deref(name_p6).name_p);
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
            auto&& x_p7 = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
            return place_ty_f(lx_p0, prism_rtl::deref(prism_rtl::deref(x_p7)));
        }
        {
            return crate::check::types::Ty(crate::check::types::Ty::TyErr{});
        }
    }
    {
        auto&& t_p8 = _m;
        return t_p8;
    }
}


prism_rtl::Turn<crate::check::types::Ty> PlaceTy::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& e_p1 = this->e_p1;
    return ({
        auto&& _m = crate::lower::type_at_f(lx_p0, prism_rtl::deref(e_p1).span_p);
        prism_rtl::is<crate::check::types::Ty::TyErr>(_m) ? ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p1).kind_p);
        prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m) ? ({
        auto&& r_p2 = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
        ({
        auto lx_p0x = lx_p0;
        auto r_p2x = prism_rtl::deref(prism_rtl::deref(r_p2));
        (crate::prelude::call_then(start_place_ty_f(lx_p0x, r_p2x), [=](crate::check::types::Ty place_ty_f_18350) {
        return ({
            auto&& _m = crate::lower::types::peel_f(place_ty_f_18350);
            prism_rtl::is<crate::check::types::Ty::TyArray>(_m) ? ({
            auto&& el_p3 = prism_rtl::as<crate::check::types::Ty::TyArray>(_m).a0;
            prism_rtl::finished(prism_rtl::deref(el_p3));
        })
            : prism_rtl::is<crate::check::types::Ty::TyMap>(_m) ? ({
            auto&& v_p4 = prism_rtl::as<crate::check::types::Ty::TyMap>(_m).a1;
            prism_rtl::finished(prism_rtl::deref(v_p4));
        })
            : prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyErr{}));
        });
    }));
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EField>(_m) ? ({
        auto&& r_p5 = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a0;
        auto&& name_p6 = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a2;
        ({
        auto lx_p0x = lx_p0;
        auto name_p6x = name_p6;
        auto r_p5x = prism_rtl::deref(prism_rtl::deref(r_p5));
        (crate::prelude::call_then(start_place_ty_f(lx_p0x, r_p5x), [=, name_p6x = std::move(name_p6x)](crate::check::types::Ty place_ty_f_18504) { return prism_rtl::more(prism_rtl::rc(FieldTy(lx_p0x, crate::lower::types::peel_f(place_ty_f_18504), prism_rtl::deref(name_p6x).name_p))); }));
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
        auto&& x_p7 = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(PlaceTy(lx_p0, prism_rtl::deref(prism_rtl::deref(x_p7)))));
    })
        : prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyErr{}));
    })
        : ({
        auto&& t_p8 = _m;
        prism_rtl::finished(t_p8);
    });
    });
}


/// `Start PlaceTy, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::Ty> start_place_ty_f(crate::lower::Lx lx_p0, crate::syntax::Expr e_p1) {
    return prism_rtl::make_rc<PlaceTy>(lx_p0, e_p1);
}


/// FieldTy: unbounded fn Lx, Ty, Text -> Ty
crate::check::types::Ty field_ty_f(const crate::lower::Lx& lx_p0, const crate::check::types::Ty& rty_p1, const Text& name_p2) {
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(rty_p1)) {
        auto&& n_p3 = prism_rtl::as<crate::check::types::Ty::TyCon>(rty_p1).a0;
        auto&& args_p4 = prism_rtl::as<crate::check::types::Ty::TyCon>(rty_p1).a1;
        auto&& _m = crate::prelude::get(prism_rtl::deref(lx_p0.g_p).ctors_p, n_p3);
        if (prism_rtl::is_some(_m)) {
            auto&& c_p5 = prism_rtl::some_of(_m);
            return crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(crate::prelude::len(prism_rtl::deref(c_p5).fields_p)), crate::check::types::Ty(crate::check::types::Ty::TyErr{}), ({
                auto c_p5x = c_p5;
                auto name_p2x = name_p2;
                auto args_p4x = args_p4;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(std::tuple<crate::check::types::Ty, Nat>)>>(prism_rtl::rc([=, c_p5x = std::move(c_p5x), name_p2x = std::move(name_p2x), args_p4x = std::move(args_p4x)](std::tuple<crate::check::types::Ty, Nat> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto c_p5xy = c_p5x;
                    auto name_p2xy = name_p2x;
                    auto args_p4xy = args_p4x;
                    (crate::prelude::entered(crate::prelude::once_job([=, c_p5xy = std::move(c_p5xy), name_p2xy = std::move(name_p2xy), args_p4xy = std::move(args_p4xy)]() {
                    return ({
                        auto found_p6 = p0;
                        auto i_p7 = p1;
                        (crate::prelude::or_(crate::prelude::index(prism_rtl::deref(c_p5xy).fields_p, i_p7), Text::lit("")) == name_p2xy
                        ? prism_rtl::more(prism_rtl::rc(crate::lower::expr::Instantiated(crate::prelude::or_(crate::prelude::index(prism_rtl::deref(c_p5xy).args_p, i_p7), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), prism_rtl::deref(c_p5xy).params_p, args_p4xy)))
                        : prism_rtl::finished(found_p6));
                    });
                })));
                });
            })));
            })));
        }
        if (prism_rtl::is_none(_m)) {
            return crate::check::types::Ty(crate::check::types::Ty::TyErr{});
        }
        prism_rtl::unreachable("no arm matched");
    }
    {
        return crate::check::types::Ty(crate::check::types::Ty::TyErr{});
    }
}


prism_rtl::Turn<crate::check::types::Ty> FieldTy::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& rty_p1 = this->rty_p1;
    const auto& name_p2 = this->name_p2;
    return ({
        prism_rtl::is<crate::check::types::Ty::TyCon>(rty_p1) ? ({
        auto&& n_p3 = prism_rtl::as<crate::check::types::Ty::TyCon>(rty_p1).a0;
        auto&& args_p4 = prism_rtl::as<crate::check::types::Ty::TyCon>(rty_p1).a1;
        ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(prism_rtl::deref(lx_p0).g_p).ctors_p, n_p3);
        prism_rtl::is_some(_m) ? ({
        auto&& c_p5 = prism_rtl::some_of(_m);
        crate::prelude::fold_job(crate::check::errors::range0_f(crate::prelude::len(prism_rtl::deref(c_p5).fields_p)), crate::check::types::Ty(crate::check::types::Ty::TyErr{}), ({
        auto c_p5x = c_p5;
        auto name_p2x = name_p2;
        auto args_p4x = args_p4;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(std::tuple<crate::check::types::Ty, Nat>)>>(prism_rtl::rc([=, c_p5x = std::move(c_p5x), name_p2x = std::move(name_p2x), args_p4x = std::move(args_p4x)](std::tuple<crate::check::types::Ty, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto c_p5xy = c_p5x;
            auto name_p2xy = name_p2x;
            auto args_p4xy = args_p4x;
            (crate::prelude::entered(crate::prelude::once_job([=, c_p5xy = std::move(c_p5xy), name_p2xy = std::move(name_p2xy), args_p4xy = std::move(args_p4xy)]() {
            return ({
                auto found_p6 = p0;
                auto i_p7 = p1;
                (crate::prelude::or_(crate::prelude::index(prism_rtl::deref(c_p5xy).fields_p, i_p7), Text::lit("")) == name_p2xy
                ? prism_rtl::more(prism_rtl::rc(crate::lower::expr::Instantiated(crate::prelude::or_(crate::prelude::index(prism_rtl::deref(c_p5xy).args_p, i_p7), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), prism_rtl::deref(c_p5xy).params_p, args_p4xy)))
                : prism_rtl::finished(found_p6));
            });
        })));
        });
    })));
    }))->cycle();
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyErr{}))
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyErr{}));
    });
}


/// `Start FieldTy, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::Ty> start_field_ty_f(crate::lower::Lx lx_p0, crate::check::types::Ty rty_p1, Text name_p2) {
    return prism_rtl::make_rc<FieldTy>(lx_p0, rty_p1, name_p2);
}


/// Assign: unbounded fn Lx, Env, Expr, Ex -> Do
crate::lower::model::Do assign_f(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& target_p2, const crate::lower::model::Ex& v_p3) {
    auto&& _m = prism_rtl::deref(target_p2.kind_p);
    if (prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m)) {
        auto&& r_p4 = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
        auto&& k_p5 = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a1;
        auto rt_p6 = crate::lower::types::out_ty_of_f(lx_p0, crate::lower::types::peel_f(place_ty_f(lx_p0, prism_rtl::deref(prism_rtl::deref(r_p4)))));
        auto f_p7 = ({
            __label__ _done;
            prism_rtl::Slot<Text> _v;
            if (prism_rtl::is<crate::lower::model::OutTy::OutMap>(rt_p6)) {
                _v.set(Text::lit("set_key"));
                goto _done;
            }
            {
                _v.set(Text::lit("set_index"));
                goto _done;
            }
        _done:
            _v.take();
        });
        return crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XCall{f_p7, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRefMut{prism_rtl::rc(place_of_f(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(r_p4))))}), crate::lower::expr::argument_f(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(k_p5))), v_p3})})});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x_p8 = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return assign_f(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(x_p8)), v_p3);
    }
    {
        return crate::lower::model::Do(crate::lower::model::Do::DoAssign{place_of_f(lx_p0, env_p1, target_p2), v_p3});
    }
}


prism_rtl::Turn<crate::lower::model::Do> Assign::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& target_p2 = this->target_p2;
    const auto& v_p3 = this->v_p3;
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(target_p2).kind_p);
        prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m) ? ({
        auto&& r_p4 = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
        auto&& k_p5 = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a1;
        ({
        auto env_p1x = env_p1;
        auto k_p5x = prism_rtl::deref(prism_rtl::deref(k_p5));
        auto lx_p0x = lx_p0;
        auto r_p4x = prism_rtl::deref(prism_rtl::deref(r_p4));
        auto v_p3x = v_p3;
        (crate::prelude::call_then(start_place_ty_f(lx_p0x, r_p4x), [=, env_p1x = std::move(env_p1x), k_p5x = std::move(k_p5x), v_p3x = std::move(v_p3x)](crate::check::types::Ty place_ty_f_19214) {
        return crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0x, crate::lower::types::peel_f(place_ty_f_19214)), [=](crate::lower::model::OutTy out_ty_of_f_19195) {
            return ({
                auto rt_p6 = out_ty_of_f_19195;
                auto f_p7 = ({
                    __label__ _done;
                    prism_rtl::Slot<Text> _v;
                    if (prism_rtl::is<crate::lower::model::OutTy::OutMap>(rt_p6)) {
                        _v.set(Text::lit("set_key"));
                        goto _done;
                    }
                    {
                        _v.set(Text::lit("set_index"));
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                (crate::prelude::call_then(start_place_of_f(lx_p0x, env_p1x, r_p4x), [=, f_p7 = std::move(f_p7)](crate::lower::model::Ex place_of_f_19373) { return crate::prelude::call_then(crate::lower::expr::start_argument_f(lx_p0x, env_p1x, k_p5x), [=](crate::lower::model::Ex argument_f_19396) { return prism_rtl::finished(crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XCall{f_p7, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRefMut{prism_rtl::rc(place_of_f_19373)}), argument_f_19396, v_p3x})})})); }); }));
            });
        });
    }));
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
        auto&& x_p8 = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(Assign(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(x_p8)), v_p3)));
    })
        : ({
        auto env_p1x = env_p1;
        auto lx_p0x = lx_p0;
        auto target_p2x = target_p2;
        auto v_p3x = v_p3;
        (crate::prelude::call_then(start_place_of_f(lx_p0x, env_p1x, target_p2x), [=, v_p3x = std::move(v_p3x)](crate::lower::model::Ex place_of_f_19483) { return prism_rtl::finished(crate::lower::model::Do(crate::lower::model::Do::DoAssign{place_of_f_19483, v_p3x})); }));
    });
    });
}


/// `Start Assign, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Do> start_assign_f(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr target_p2, crate::lower::model::Ex v_p3) {
    return prism_rtl::make_rc<Assign>(lx_p0, env_p1, target_p2, v_p3);
}

}  // namespace crate::lower::templates
