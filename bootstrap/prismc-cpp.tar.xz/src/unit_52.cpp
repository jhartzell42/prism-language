// The module `Lower.Node.Keyed`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <lower/node_/keyed/module.hpp>
#include <lower/model/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Lower.Node.Keyed`, from `target/bootstrap/cpp-src/prismc/lower/node/keyed.prism`.
namespace crate::lower::node_::keyed {

Pod RowLocal::to_pod() const {
    return Pod::record("RowLocal", {{"name", prism_rtl::to_pod(name)}, {"field", prism_rtl::to_pod(field)}, {"ty", prism_rtl::to_pod(ty)}, {"passed", prism_rtl::to_pod(passed)}});
}

Result<RowLocal> RowLocal::from_pod(const Pod& whole) {
    return RowLocal{.name = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .field = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "field")))), .ty = TRY(prism_rtl::from_pod<crate::lower::model::OutTy>(TRY(crate::prelude::field(whole, "ty")))), .passed = TRY(prism_rtl::from_pod<crate::lower::model::Ex>(TRY(crate::prelude::field(whole, "passed"))))};
}


/// ForLine: unbounded fn Wx, Env, Env, ?ForBinders, Expr, Block, Expr, ?Bn -> ((Wx, Wres))
std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> for_line(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& benv_p1, const crate::lower::types::Env& menv_p2, const std::optional<crate::syntax::ForBinders>& binders_o3, const crate::syntax::Expr& source_p4, const crate::syntax::Block& body_p5, const crate::syntax::Expr& e_p6, const std::optional<crate::lower::types::Bn>& bound_o7) {
    auto lx_p8 = wx_p0.lx;
    auto pos_p9 = wx_p0.pos;
    auto wx1_pa = ({
        crate::lower::node_::Wx this_ = wx_p0;
        this_.pos = crate::lower::model::next_pos(this_.pos);
        (std::move(this_));
    });
    auto [src_ex_p12, reads_p13] = crate::lower::node_::dynamics::dynamic_expr(wx1_pa, menv_p2, source_p4);
    auto src_ty_pb = crate::lower::types::peel(crate::lower::type_at(lx_p8, source_p4.span));
    auto [kt_p17, vt_p18, keyed_p19] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::lower::model::OutTy, crate::lower::model::OutTy, bool>> _v;
        if (prism_rtl::is<crate::check::types::Ty::TyMap>(src_ty_pb)) {
            auto&& k_p14 = prism_rtl::as<crate::check::types::Ty::TyMap>(src_ty_pb).a0;
            auto&& v_p15 = prism_rtl::as<crate::check::types::Ty::TyMap>(src_ty_pb).a1;
            _v.set(std::tuple{crate::lower::types::out_ty_of(lx_p8, prism_rtl::deref(prism_rtl::deref(k_p14))), crate::lower::types::out_ty_of(lx_p8, prism_rtl::deref(prism_rtl::deref(v_p15))), true});
            goto _done;
        }
        if (prism_rtl::is<crate::check::types::Ty::TyArray>(src_ty_pb)) {
            auto&& v_p16 = prism_rtl::as<crate::check::types::Ty::TyArray>(src_ty_pb).a0;
            _v.set(std::tuple{crate::lower::model::OutTy(crate::lower::model::OutTy::OutNat{}), crate::lower::types::out_ty_of(lx_p8, prism_rtl::deref(prism_rtl::deref(v_p16))), false});
            goto _done;
        }
        {
            _v.set(std::tuple{crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), true});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto src_pc = keyed_p19
        ? src_ex_p12
        : crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("indexed"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(src_ex_p12)})})});
    auto base_pd = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        if (prism_rtl::is_some(bound_o7) && prism_rtl::is<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(bound_o7))) {
            auto&& er_p1a = prism_rtl::as<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(bound_o7)).a0;
            _v.set(prism_rtl::deref(crate::lower::node_::gn_of(wx1_pa, prism_rtl::deref(er_p1a).node_)).name);
            goto _done;
        }
        {
            _v.set(Text::lit("rows"));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto [name_p1b, wx2a_p1c] = crate::lower::node_::fresh_name(wx1_pa, base_pd);
    auto src_getter_pe = prism_rtl::cat(name_p1b, "_source");
    auto src_cached_pf = crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(src_getter_pe, "_cache")})), Text::lit("get"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{}), crate::lower::model::Ex(crate::lower::model::Ex::XClosure{false, Array<crate::lower::model::Pa>{}, prism_rtl::rc(src_pc)})})});
    auto src_def_pg = crate::lower::model::MethDef{.name = src_getter_pe, .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxRef{}), .ret = crate::lower::model::OutTy(crate::lower::model::OutTy::OutMap{prism_rtl::rc(kt_p17), prism_rtl::rc(vt_p18)}), .body = Array<crate::lower::model::Do>{}, .tail = src_cached_pf, .doc = prism_rtl::cat("The source of the `for` at place ", crate::lower::model::place_text(pos_p9), " by key, at the read point: what its builder and its rows\' entries read, computed once per write behind it.")};
    auto row_name_ph = prism_rtl::cat(wx_p0.node_, row_suffix(wx_p0), "Row");
    auto locals_pi = row_locals(benv_p1, menv_p2, body_p5);
    auto row_fields_pj = append(Array(std::vector{std::tuple{Text::lit("key"), kt_p17, Text::lit("the row\'s key")}, std::tuple{Text::lit("left_entry"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutCell{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutOpt{prism_rtl::rc(vt_p18)}))}), Text::lit("the entry as the tick its key left opened, kept from the row\'s leaving on (R8)")}, std::tuple{Text::lit("parent"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutWeak{wx_p0.node_}), Text::lit("the node of the `for`")}}), each(locals_pi, [&](const RowLocal& l_p1d) { return std::tuple{prism_rtl::deref(l_p1d).field, prism_rtl::deref(l_p1d).ty, prism_rtl::cat("`", prism_rtl::deref(l_p1d).name, "`, the block\'s")}; }));
    auto row_moves_pk = append(Array(std::vector{std::tuple{Text::lit("key"), crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("key")}))})}, std::tuple{Text::lit("left_entry"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("RefCell::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XNone{})})})}, std::tuple{Text::lit("parent"), crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("parent")})}}), each(locals_pi, [&](const RowLocal& l_p1e) { return std::tuple{prism_rtl::deref(l_p1e).field, crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::deref(l_p1e).field})}; }));
    auto row_taken_pl = append(append(crate::lower::node_::node_hooks(), Array(std::vector{Text::lit("key"), Text::lit("value"), Text::lit("parent"), Text::lit("entry"), Text::lit("left_entry")})), each(locals_pi, [&](const RowLocal& l_p1f) { return prism_rtl::deref(l_p1f).field; }));
    auto row_wx0_pm = crate::lower::node_::new_wx(lx_p8, row_name_ph, row_fields_pj, Array<std::tuple<Text, crate::lower::model::Ex>>{}, row_moves_pk, Array(std::vector{entry_getter(src_getter_pe, vt_p18)}), map_of(std::vector{std::tuple{Text::lit("entry"), Array(std::vector{crate::lower::node_::Read(crate::lower::node_::Read::ParentRead{src_getter_pe})})}}), row_taken_pl, wx_p0.inlining, crate::lower::node_::finish::hosted_rows(wx_p0));
    auto [wx2p_p1g, row_wx0p_p1h, ports_p1i] = crate::lower::node_::switch_::row_env(wx2a_p1c, row_wx0_pm, menv_p2, body_p5);
    auto wx2_pn = ({
        crate::lower::node_::Wx this_ = crate::lower::node_::add_field(wx2p_p1g, prism_rtl::cat(src_getter_pe, "_cache"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Cache"), Array(std::vector{crate::lower::model::OutTy(crate::lower::model::OutTy::OutMap{prism_rtl::rc(kt_p17), prism_rtl::rc(vt_p18)})})}), prism_rtl::cat("the source of the `for` at place ", crate::lower::model::place_text(pos_p9), ", cached (gap SR)"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Cache::new"), Array<crate::lower::model::Ex>{}}));
        this_.taken = append(this_.taken, Array(std::vector{src_getter_pe, prism_rtl::cat(src_getter_pe, "_cache")}));
        this_.getters = crate::prelude::push(this_.getters, src_def_pg);
        this_.dyn_reads = insert(this_.dyn_reads, src_getter_pe, reads_p13);
        (std::move(this_));
    });
    auto key_b_po = crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("key")}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), kt_p17});
    auto key_m_pp = crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), Text::lit("key")}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), kt_p17});
    auto benv_l_pq = events_of(ports_p1i, fold(locals_pi, row_reads(benv_p1, crate::lower::node_::switch_::parent_arg()), [&](const crate::lower::types::Env& en_p1j, const RowLocal& l_p1k) { return crate::lower::types::bind(en_p1j, prism_rtl::deref(l_p1k).name, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::deref(l_p1k).field}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::deref(l_p1k).ty})); }));
    auto menv_l_pr = events_of(ports_p1i, fold(locals_pi, row_reads(menv_p2, crate::lower::node_::switch_::parent_ref()), [&](const crate::lower::types::Env& en_p1l, const RowLocal& l_p1m) { return crate::lower::types::bind(en_p1l, prism_rtl::deref(l_p1m).name, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::deref(l_p1m).field}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::deref(l_p1m).ty})); }));
    auto passed_ps = append(hosted_passed(wx_p0), each(locals_pi, [&](const RowLocal& l_p1n) { return prism_rtl::deref(l_p1n).passed; }));
    auto row_params_pt = append(append(Array(std::vector{std::tuple{Text::lit("key"), kt_p17}, std::tuple{Text::lit("value"), vt_p18}, std::tuple{Text::lit("parent"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutWeak{wx_p0.node_})}}), hosted_params(wx_p0)), each(locals_pi, [&](const RowLocal& l_p1o) { return std::tuple{prism_rtl::deref(l_p1o).field, prism_rtl::deref(l_p1o).ty}; }));
    auto [row_wx0f_p20, val_b_p21, val_m_p22, inner_p23] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::lower::node_::Wx, crate::lower::types::Bn, crate::lower::types::Bn, crate::lower::model::OutTy>> _v;
        if (prism_rtl::is<crate::lower::model::OutTy::OutDyn>(vt_p18)) {
            auto&& t_p1p = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(vt_p18).a0;
            _v.set(({
                auto [fname_p1r, row_wx_n_p1s] = crate::lower::node_::fresh_name(row_wx0p_p1h, crate::lower::snake(for_value_name(binders_o3)));
                auto [row_wx_f_p1t, fres_p1u] = crate::lower::node_::switch_::entry_flatten(row_wx_n_p1s, prism_rtl::deref(prism_rtl::deref(t_p1p)), std::optional(crate::lower::types::Bn(crate::lower::types::Bn::BnHold{fname_p1r, prism_rtl::deref(prism_rtl::deref(t_p1p))})));
                auto fb_p1q = crate::lower::node_::def::bundle_bn(fres_p1u);
                std::tuple{row_wx_f_p1t, fb_p1q, fb_p1q, prism_rtl::deref(prism_rtl::deref(t_p1p))};
            }));
            goto _done;
        }
        {
            _v.set(({
                auto entry_m_p1v = crate::lower::types::Bn(crate::lower::types::Bn::BnDyn{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), Text::lit("entry"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), Array(std::vector{crate::lower::node_::Read(crate::lower::node_::Read::ParentRead{src_getter_pe})}), vt_p18});
                std::tuple{row_wx0p_p1h, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("value")}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), vt_p18}), entry_m_p1v, vt_p18};
            }));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto [rbe_p24, rme_p25] = for_envs(benv_l_pq, menv_l_pr, binders_o3, key_b_po, key_m_pp, val_b_p21, val_m_p22, inner_p23);
    auto row_wx_pu = crate::lower::node_::def::block_into(row_wx0f_p20, rbe_p24, rme_p25, body_p5);
    auto wx3_pv = ({
        crate::lower::node_::Wx this_ = wx2_pn;
        this_.row_marks = crate::prelude::push(this_.row_marks, crate::lower::node_::RowMarks{.builder = name_p1b, .reads = row_place_reads(row_wx_pu), .wrote = crate::lower::node_::finish::row_hears(row_wx_pu), .kind = crate::lower::model::RowKind(crate::lower::model::RowKind::ForRow{})});
        (std::move(this_));
    });
    auto full_p10 = crate::lower::type_at(lx_p8, e_p6.span);
    auto out_ty_p11 = crate::lower::types::out_ty_of(lx_p8, crate::lower::types::peel(full_p10));
    auto&& _m = row_wx_pu->result;
    if (prism_rtl::is<crate::lower::node_::Wres::WrEv>(_m)) {
        auto&& r_p26 = prism_rtl::as<crate::lower::node_::Wres::WrEv>(_m).a0;
        auto [gid_p2b, wx4_p2c] = crate::lower::node_::add_gn(wx3_pv, prism_rtl::cat(name_p1b, "_all"), out_ty_p11, crate::lower::node_::GnKind(crate::lower::node_::GnKind::GnGather{}), Nat(1u));
        auto wx5_p27 = crate::lower::node_::add_field_last(wx4_p2c, prism_rtl::cat(name_p1b, "_gathered"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutStamped{prism_rtl::rc(out_ty_p11)}), Text::lit("the rows\' firings this tick, by key"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Stamped::new"), Array<crate::lower::model::Ex>{}}));
        auto wx6_p28 = ({
            crate::lower::node_::Wx this_ = wx5_p27;
            this_.gns = each(this_.gns, [&](const crate::lower::node_::Gn& n_p2d) {
                return prism_rtl::deref(n_p2d).id == gid_p2b
                    ? crate::lower::node_::dynamics::with_inputs(n_p2d, Array(std::vector{prism_rtl::cat(name_p1b, "_gathered")}))
                    : n_p2d;
            });
            (std::move(this_));
        });
        auto row_done_p29 = crate::lower::node_::connect(row_wx_pu, r_p26, crate::lower::node_::Sk(crate::lower::node_::Sk::SkUp{prism_rtl::cat(name_p1b, "_all_in")}));
        auto wx7_p2a = add_builder(wx6_p28, name_p1b, pos_p9, kt_p17, vt_p18, row_name_ph, keyed_p19, reads_p13, crate::lower::node_::PendingRow{.wx = row_done_p29, .qk = row_name_ph, .params = row_params_pt, .gather = std::optional(gid_p2b)}, passed_ps);
        return std::tuple{wx7_p2a, crate::lower::node_::Wres(crate::lower::node_::Wres::WrEv{crate::lower::node_::ev_ref_of(wx7_p2a, gid_p2b)})};
    }
    if (prism_rtl::is<crate::lower::node_::Wres::WrDyn>(_m)) {
        auto&& ex_p2e = prism_rtl::as<crate::lower::node_::Wres::WrDyn>(_m).a0;
        auto&& result_reads_p2f = prism_rtl::as<crate::lower::node_::Wres::WrDyn>(_m).a1;
        auto&& rt_p2g = prism_rtl::as<crate::lower::node_::Wres::WrDyn>(_m).a2;
        auto gathered_p2h = prism_rtl::cat(name_p1b, "_all");
        auto gathered_ty_p2i = crate::lower::model::OutTy(crate::lower::model::OutTy::OutMap{prism_rtl::rc(kt_p17), prism_rtl::rc(rt_p2g)});
        auto own_behind_p2j = filter(crate::lower::node_::finish::reads_closed(prism_rtl::deref(row_wx_pu).dyn_reads, result_reads_p2f), [&](const crate::lower::node_::Read& r_p2p) {
            return ({
                __label__ _done;
                prism_rtl::Slot<bool> _v;
                if (prism_rtl::is<crate::lower::node_::Read::OwnRead>(r_p2p)) {
                    _v.set(true);
                    goto _done;
                }
                if (prism_rtl::is<crate::lower::node_::Read::ParentRead>(r_p2p)) {
                    _v.set(false);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
        });
        auto row_done_p2k = ({
            crate::lower::node_::Wx this_ = row_wx_pu;
            this_.getters = crate::prelude::push(this_.getters, crate::lower::model::MethDef{.name = Text::lit("result"), .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxRef{}), .ret = rt_p2g, .body = Array<crate::lower::model::Do>{}, .tail = ex_p2e, .doc = Text::lit("The row\'s result, which the block gathers by key.")});
            this_.result_moved = len(own_behind_p2j) > Nat(0u)
                ? std::optional(std::tuple{prism_rtl::cat(gathered_p2h, "_moved"), own_behind_p2j})
                : std::optional<std::tuple<Text, Array<crate::lower::node_::Read>>>{};
            (std::move(this_));
        });
        auto wx4_p2l = add_builder(wx3_pv, name_p1b, pos_p9, kt_p17, vt_p18, row_name_ph, keyed_p19, reads_p13, crate::lower::node_::PendingRow{.wx = row_done_p2k, .qk = row_name_ph, .params = row_params_pt, .gather = std::optional<Nat>{}}, passed_ps);
        auto all_p2m = crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), name_p1b})), Text::lit("borrow"), Array<crate::lower::model::Ex>{}})), Text::lit("iter"), Array<crate::lower::model::Ex>{}})), Text::lit("map"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{false, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("k")}), crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("row")})})})}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XTuple{Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("k")}))}), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("row")})), Text::lit("result"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})})}))})})})), Text::lit("collect"), Array<crate::lower::model::Ex>{}});
        auto what_p2n = prism_rtl::cat("the dynamic gathered by the `for` at place ", crate::lower::model::place_text(pos_p9));
        auto wx5_p2o = ({
            crate::lower::node_::Wx this_ = wx4_p2l;
            this_.taken = append(this_.taken, Array(std::vector{gathered_p2h, prism_rtl::cat(gathered_p2h, "_now"), prism_rtl::cat(gathered_p2h, "_snap"), prism_rtl::cat(gathered_p2h, "_moved"), prism_rtl::cat(gathered_p2h, "_publish")}));
            this_.getters = append(this_.getters, Array(std::vector{crate::lower::model::MethDef{.name = prism_rtl::cat(gathered_p2h, "_now"), .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxRef{}), .ret = gathered_ty_p2i, .body = Array<crate::lower::model::Do>{}, .tail = all_p2m, .doc = Text::lit("The rows\' results by key, computed live: what the snapshot of the `for`\'s dynamic is taken from (pick ST).")}, crate::lower::node_::static_::snap_getter(gathered_p2h, gathered_ty_p2i, Text::lit("The `for`\'s dynamic, the rows\' results by key, a structural dynamic (pick ST): one tick behind the rows, the snapshot of the tick before the tick the read point is after."))}));
            this_.fields = crate::prelude::push(this_.fields, std::tuple{prism_rtl::cat(gathered_p2h, "_snap"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutSnapshot{prism_rtl::rc(gathered_ty_p2i)}), prism_rtl::cat("the `for` at place ", crate::lower::model::place_text(pos_p9), "\'s gathered dynamic, structural: its snapshots, the rows\' results and the lagged dynamic (pick ST)")});
            this_.inits = crate::prelude::push(this_.inits, std::tuple{prism_rtl::cat(gathered_p2h, "_snap"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Snapshot::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XStr{what_p2n})})})});
            this_.snaps = crate::prelude::push(this_.snaps, crate::lower::node_::SnapDef{.name = gathered_p2h, .live = prism_rtl::cat(gathered_p2h, "_now"), .ty = gathered_ty_p2i, .eq = crate::lower::program::ty_has_eq(lx_p8, crate::lower::types::peel(full_p10), Array<Text>{}), .builder = name_p1b, .before = false, .what = what_p2n});
            this_.dyn_reads = insert(this_.dyn_reads, prism_rtl::cat(gathered_p2h, "_now"), crate::lower::node_::union_reads(reads_p13, block_reads(crate::lower::node_::finish::reads_closed(prism_rtl::deref(row_wx_pu).dyn_reads, result_reads_p2f))));
            (std::move(this_));
        });
        return std::tuple{wx5_p2o, crate::lower::node_::Wres(crate::lower::node_::Wres::WrDyn{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), gathered_p2h, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), Array(std::vector{crate::lower::node_::Read(crate::lower::node_::Read::OwnRead{gathered_p2h})}), gathered_ty_p2i})};
    }
    if (prism_rtl::is<crate::lower::node_::Wres::WrParts>(_m)) {
        auto wx4_p2q = ({
            crate::lower::node_::Wx this_ = wx3_pv;
            this_.build = crate::prelude::push(this_.build, crate::lower::expr::refusal_do(Text::lit("a `for` whose rows end on a bundle (Semantics ch. 4: gathered part by part)")));
            (std::move(this_));
        });
        return std::tuple{wx4_p2q, crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{})};
    }
    {
        auto wx4_p2r = add_builder(wx3_pv, name_p1b, pos_p9, kt_p17, vt_p18, row_name_ph, keyed_p19, reads_p13, crate::lower::node_::PendingRow{.wx = row_wx_pu, .qk = row_name_ph, .params = row_params_pt, .gather = std::optional<Nat>{}}, passed_ps);
        return std::tuple{wx4_p2r, crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{})};
    }
}


prism_rtl::Turn<std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres>> ForLine::cycle() const {
    const auto& wx_p0 = this->wx_p0;
    const auto& benv_p1 = this->benv_p1;
    const auto& menv_p2 = this->menv_p2;
    const auto& binders_o3 = this->binders_o3;
    const auto& source_p4 = this->source_p4;
    const auto& body_p5 = this->body_p5;
    const auto& e_p6 = this->e_p6;
    const auto& bound_o7 = this->bound_o7;
    auto lx_p8 = prism_rtl::deref(wx_p0).lx;
    auto pos_p9 = prism_rtl::deref(wx_p0).pos;
    auto wx1_pa = ({
        crate::lower::node_::Wx this_ = wx_p0;
        this_.pos = crate::lower::model::next_pos(this_.pos);
        (std::move(this_));
    });
    auto binders_o3_1 = binders_o3;
    auto bound_o7_2 = bound_o7;
    auto benv_p1_3 = benv_p1;
    auto body_p5_4 = body_p5;
    auto e_p6_5 = e_p6;
    auto menv_p2_6 = menv_p2;
    auto source_p4_7 = source_p4;
    auto wx_p0_8 = wx_p0;
    return call_then(crate::lower::node_::dynamics::start_dynamic_expr(wx1_pa, menv_p2_6, source_p4_7), [=](std::tuple<crate::lower::model::Ex, Array<crate::lower::node_::Read>> dynamic_expr_1801) {
        return ({
            auto [src_ex_p12, reads_p13] = dynamic_expr_1801;
            auto src_ty_pb = crate::lower::types::peel(crate::lower::type_at(lx_p8, prism_rtl::deref(source_p4_7).span));
            auto [kt_p17, vt_p18, keyed_p19] = ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<crate::lower::model::OutTy, crate::lower::model::OutTy, bool>> _v;
                if (prism_rtl::is<crate::check::types::Ty::TyMap>(src_ty_pb)) {
                    auto&& k_p14 = prism_rtl::as<crate::check::types::Ty::TyMap>(src_ty_pb).a0;
                    auto&& v_p15 = prism_rtl::as<crate::check::types::Ty::TyMap>(src_ty_pb).a1;
                    _v.set(std::tuple{crate::lower::types::out_ty_of(lx_p8, prism_rtl::deref(prism_rtl::deref(k_p14))), crate::lower::types::out_ty_of(lx_p8, prism_rtl::deref(prism_rtl::deref(v_p15))), true});
                    goto _done;
                }
                if (prism_rtl::is<crate::check::types::Ty::TyArray>(src_ty_pb)) {
                    auto&& v_p16 = prism_rtl::as<crate::check::types::Ty::TyArray>(src_ty_pb).a0;
                    _v.set(std::tuple{crate::lower::model::OutTy(crate::lower::model::OutTy::OutNat{}), crate::lower::types::out_ty_of(lx_p8, prism_rtl::deref(prism_rtl::deref(v_p16))), false});
                    goto _done;
                }
                {
                    _v.set(std::tuple{crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), true});
                    goto _done;
                }
            _done:
                _v.take();
            });
            auto src_pc = keyed_p19
                ? src_ex_p12
                : crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("indexed"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(src_ex_p12)})})});
            auto base_pd = ({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                if (prism_rtl::is_some(bound_o7_2) && prism_rtl::is<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(bound_o7_2))) {
                    auto&& er_p1a = prism_rtl::as<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(bound_o7_2)).a0;
                    _v.set(prism_rtl::deref(crate::lower::node_::gn_of(wx1_pa, prism_rtl::deref(er_p1a).node_)).name);
                    goto _done;
                }
                {
                    _v.set(Text::lit("rows"));
                    goto _done;
                }
            _done:
                _v.take();
            });
            auto [name_p1b, wx2a_p1c] = crate::lower::node_::fresh_name(wx1_pa, base_pd);
            auto src_getter_pe = prism_rtl::cat(name_p1b, "_source");
            auto src_cached_pf = crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(src_getter_pe, "_cache")})), Text::lit("get"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{}), crate::lower::model::Ex(crate::lower::model::Ex::XClosure{false, Array<crate::lower::model::Pa>{}, prism_rtl::rc(src_pc)})})});
            auto src_def_pg = crate::lower::model::MethDef{.name = src_getter_pe, .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxRef{}), .ret = crate::lower::model::OutTy(crate::lower::model::OutTy::OutMap{prism_rtl::rc(kt_p17), prism_rtl::rc(vt_p18)}), .body = Array<crate::lower::model::Do>{}, .tail = src_cached_pf, .doc = prism_rtl::cat("The source of the `for` at place ", crate::lower::model::place_text(pos_p9), " by key, at the read point: what its builder and its rows\' entries read, computed once per write behind it.")};
            auto row_name_ph = prism_rtl::cat(prism_rtl::deref(wx_p0_8).node_, row_suffix(wx_p0_8), "Row");
            auto locals_pi = row_locals(benv_p1_3, menv_p2_6, body_p5_4);
            auto row_fields_pj = append(Array(std::vector{std::tuple{Text::lit("key"), kt_p17, Text::lit("the row\'s key")}, std::tuple{Text::lit("left_entry"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutCell{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutOpt{prism_rtl::rc(vt_p18)}))}), Text::lit("the entry as the tick its key left opened, kept from the row\'s leaving on (R8)")}, std::tuple{Text::lit("parent"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutWeak{prism_rtl::deref(wx_p0_8).node_}), Text::lit("the node of the `for`")}}), each(locals_pi, [&](const RowLocal& l_p1d) { return std::tuple{prism_rtl::deref(l_p1d).field, prism_rtl::deref(l_p1d).ty, prism_rtl::cat("`", prism_rtl::deref(l_p1d).name, "`, the block\'s")}; }));
            auto row_moves_pk = append(Array(std::vector{std::tuple{Text::lit("key"), crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("key")}))})}, std::tuple{Text::lit("left_entry"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("RefCell::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XNone{})})})}, std::tuple{Text::lit("parent"), crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("parent")})}}), each(locals_pi, [&](const RowLocal& l_p1e) { return std::tuple{prism_rtl::deref(l_p1e).field, crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::deref(l_p1e).field})}; }));
            auto row_taken_pl = append(append(crate::lower::node_::node_hooks(), Array(std::vector{Text::lit("key"), Text::lit("value"), Text::lit("parent"), Text::lit("entry"), Text::lit("left_entry")})), each(locals_pi, [&](const RowLocal& l_p1f) { return prism_rtl::deref(l_p1f).field; }));
            auto row_wx0_pm = crate::lower::node_::new_wx(lx_p8, row_name_ph, row_fields_pj, Array<std::tuple<Text, crate::lower::model::Ex>>{}, row_moves_pk, Array(std::vector{entry_getter(src_getter_pe, vt_p18)}), map_of(std::vector{std::tuple{Text::lit("entry"), Array(std::vector{crate::lower::node_::Read(crate::lower::node_::Read::ParentRead{src_getter_pe})})}}), row_taken_pl, prism_rtl::deref(wx_p0_8).inlining, crate::lower::node_::finish::hosted_rows(wx_p0_8));
            auto [wx2p_p1g, row_wx0p_p1h, ports_p1i] = crate::lower::node_::switch_::row_env(wx2a_p1c, row_wx0_pm, menv_p2_6, body_p5_4);
            auto wx2_pn = ({
                crate::lower::node_::Wx this_ = crate::lower::node_::add_field(wx2p_p1g, prism_rtl::cat(src_getter_pe, "_cache"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Cache"), Array(std::vector{crate::lower::model::OutTy(crate::lower::model::OutTy::OutMap{prism_rtl::rc(kt_p17), prism_rtl::rc(vt_p18)})})}), prism_rtl::cat("the source of the `for` at place ", crate::lower::model::place_text(pos_p9), ", cached (gap SR)"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Cache::new"), Array<crate::lower::model::Ex>{}}));
                this_.taken = append(this_.taken, Array(std::vector{src_getter_pe, prism_rtl::cat(src_getter_pe, "_cache")}));
                this_.getters = crate::prelude::push(this_.getters, src_def_pg);
                this_.dyn_reads = insert(this_.dyn_reads, src_getter_pe, reads_p13);
                (std::move(this_));
            });
            auto key_b_po = crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("key")}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), kt_p17});
            auto key_m_pp = crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), Text::lit("key")}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), kt_p17});
            auto benv_l_pq = events_of(ports_p1i, fold(locals_pi, row_reads(benv_p1_3, crate::lower::node_::switch_::parent_arg()), [&](const crate::lower::types::Env& en_p1j, const RowLocal& l_p1k) { return crate::lower::types::bind(en_p1j, prism_rtl::deref(l_p1k).name, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::deref(l_p1k).field}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::deref(l_p1k).ty})); }));
            auto menv_l_pr = events_of(ports_p1i, fold(locals_pi, row_reads(menv_p2_6, crate::lower::node_::switch_::parent_ref()), [&](const crate::lower::types::Env& en_p1l, const RowLocal& l_p1m) { return crate::lower::types::bind(en_p1l, prism_rtl::deref(l_p1m).name, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::deref(l_p1m).field}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::deref(l_p1m).ty})); }));
            auto passed_ps = append(hosted_passed(wx_p0_8), each(locals_pi, [&](const RowLocal& l_p1n) { return prism_rtl::deref(l_p1n).passed; }));
            auto row_params_pt = append(append(Array(std::vector{std::tuple{Text::lit("key"), kt_p17}, std::tuple{Text::lit("value"), vt_p18}, std::tuple{Text::lit("parent"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutWeak{prism_rtl::deref(wx_p0_8).node_})}}), hosted_params(wx_p0_8)), each(locals_pi, [&](const RowLocal& l_p1o) { return std::tuple{prism_rtl::deref(l_p1o).field, prism_rtl::deref(l_p1o).ty}; }));
            auto [row_wx0f_p20, val_b_p21, val_m_p22, inner_p23] = ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<crate::lower::node_::Wx, crate::lower::types::Bn, crate::lower::types::Bn, crate::lower::model::OutTy>> _v;
                if (prism_rtl::is<crate::lower::model::OutTy::OutDyn>(vt_p18)) {
                    auto&& t_p1p = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(vt_p18).a0;
                    _v.set(({
                        auto [fname_p1r, row_wx_n_p1s] = crate::lower::node_::fresh_name(row_wx0p_p1h, crate::lower::snake(for_value_name(binders_o3_1)));
                        auto [row_wx_f_p1t, fres_p1u] = crate::lower::node_::switch_::entry_flatten(row_wx_n_p1s, prism_rtl::deref(prism_rtl::deref(t_p1p)), std::optional(crate::lower::types::Bn(crate::lower::types::Bn::BnHold{fname_p1r, prism_rtl::deref(prism_rtl::deref(t_p1p))})));
                        auto fb_p1q = crate::lower::node_::def::bundle_bn(fres_p1u);
                        std::tuple{row_wx_f_p1t, fb_p1q, fb_p1q, prism_rtl::deref(prism_rtl::deref(t_p1p))};
                    }));
                    goto _done;
                }
                {
                    _v.set(({
                        auto entry_m_p1v = crate::lower::types::Bn(crate::lower::types::Bn::BnDyn{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), Text::lit("entry"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), Array(std::vector{crate::lower::node_::Read(crate::lower::node_::Read::ParentRead{src_getter_pe})}), vt_p18});
                        std::tuple{row_wx0p_p1h, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("value")}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), vt_p18}), entry_m_p1v, vt_p18};
                    }));
                    goto _done;
                }
            _done:
                _v.take();
            });
            auto [rbe_p24, rme_p25] = for_envs(benv_l_pq, menv_l_pr, binders_o3_1, key_b_po, key_m_pp, val_b_p21, val_m_p22, inner_p23);
            call_then(crate::lower::node_::def::start_block_into(row_wx0f_p20, rbe_p24, rme_p25, body_p5_4), [=, row_name_ph = std::move(row_name_ph), wx2_pn = std::move(wx2_pn), passed_ps = std::move(passed_ps), row_params_pt = std::move(row_params_pt)](crate::lower::node_::Wx block_into_6193) {
            return ({
                auto row_wx_pu = block_into_6193;
                auto wx3_pv = ({
                    crate::lower::node_::Wx this_ = wx2_pn;
                    this_.row_marks = crate::prelude::push(this_.row_marks, crate::lower::node_::RowMarks{.builder = name_p1b, .reads = row_place_reads(row_wx_pu), .wrote = crate::lower::node_::finish::row_hears(row_wx_pu), .kind = crate::lower::model::RowKind(crate::lower::model::RowKind::ForRow{})});
                    (std::move(this_));
                });
                auto full_p10 = crate::lower::type_at(lx_p8, prism_rtl::deref(e_p6_5).span);
                call_then(crate::lower::types::start_out_ty_of(lx_p8, crate::lower::types::peel(full_p10)), [=, row_wx_pu = std::move(row_wx_pu), wx3_pv = std::move(wx3_pv)](crate::lower::model::OutTy out_ty_of_6432) {
                return ({
                    auto out_ty_p11 = out_ty_of_6432;
                    ({
                    auto&& _m = row_wx_pu->result;
                    prism_rtl::is<crate::lower::node_::Wres::WrEv>(_m) ? ({
                    auto&& r_p26 = prism_rtl::as<crate::lower::node_::Wres::WrEv>(_m).a0;
                    ({
                    auto [gid_p2b, wx4_p2c] = crate::lower::node_::add_gn(wx3_pv, prism_rtl::cat(name_p1b, "_all"), out_ty_p11, crate::lower::node_::GnKind(crate::lower::node_::GnKind::GnGather{}), Nat(1u));
                    auto wx5_p27 = crate::lower::node_::add_field_last(wx4_p2c, prism_rtl::cat(name_p1b, "_gathered"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutStamped{prism_rtl::rc(out_ty_p11)}), Text::lit("the rows\' firings this tick, by key"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Stamped::new"), Array<crate::lower::model::Ex>{}}));
                    auto wx6_p28 = ({
                        crate::lower::node_::Wx this_ = wx5_p27;
                        this_.gns = each(this_.gns, [&](const crate::lower::node_::Gn& n_p2d) {
                            return prism_rtl::deref(n_p2d).id == gid_p2b
                                ? crate::lower::node_::dynamics::with_inputs(n_p2d, Array(std::vector{prism_rtl::cat(name_p1b, "_gathered")}))
                                : n_p2d;
                        });
                        (std::move(this_));
                    });
                    auto row_done_p29 = crate::lower::node_::connect(row_wx_pu, r_p26, crate::lower::node_::Sk(crate::lower::node_::Sk::SkUp{prism_rtl::cat(name_p1b, "_all_in")}));
                    auto wx7_p2a = add_builder(wx6_p28, name_p1b, pos_p9, kt_p17, vt_p18, row_name_ph, keyed_p19, reads_p13, crate::lower::node_::PendingRow{.wx = row_done_p29, .qk = row_name_ph, .params = row_params_pt, .gather = std::optional(gid_p2b)}, passed_ps);
                    (prism_rtl::finished(std::tuple{wx7_p2a, crate::lower::node_::Wres(crate::lower::node_::Wres::WrEv{crate::lower::node_::ev_ref_of(wx7_p2a, gid_p2b)})}));
                });
                })
                    : prism_rtl::is<crate::lower::node_::Wres::WrDyn>(_m) ? ({
                    auto&& ex_p2e = prism_rtl::as<crate::lower::node_::Wres::WrDyn>(_m).a0;
                    auto&& result_reads_p2f = prism_rtl::as<crate::lower::node_::Wres::WrDyn>(_m).a1;
                    auto&& rt_p2g = prism_rtl::as<crate::lower::node_::Wres::WrDyn>(_m).a2;
                    ({
                    auto gathered_p2h = prism_rtl::cat(name_p1b, "_all");
                    auto gathered_ty_p2i = crate::lower::model::OutTy(crate::lower::model::OutTy::OutMap{prism_rtl::rc(kt_p17), prism_rtl::rc(rt_p2g)});
                    auto own_behind_p2j = filter(crate::lower::node_::finish::reads_closed(prism_rtl::deref(row_wx_pu).dyn_reads, result_reads_p2f), [&](const crate::lower::node_::Read& r_p2p) {
                        return ({
                            __label__ _done;
                            prism_rtl::Slot<bool> _v;
                            if (prism_rtl::is<crate::lower::node_::Read::OwnRead>(r_p2p)) {
                                _v.set(true);
                                goto _done;
                            }
                            if (prism_rtl::is<crate::lower::node_::Read::ParentRead>(r_p2p)) {
                                _v.set(false);
                                goto _done;
                            }
                            prism_rtl::unreachable("no arm matched");
                        _done:
                            _v.take();
                        });
                    });
                    auto row_done_p2k = ({
                        crate::lower::node_::Wx this_ = row_wx_pu;
                        this_.getters = crate::prelude::push(this_.getters, crate::lower::model::MethDef{.name = Text::lit("result"), .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxRef{}), .ret = rt_p2g, .body = Array<crate::lower::model::Do>{}, .tail = ex_p2e, .doc = Text::lit("The row\'s result, which the block gathers by key.")});
                        this_.result_moved = len(own_behind_p2j) > Nat(0u)
                            ? std::optional(std::tuple{prism_rtl::cat(gathered_p2h, "_moved"), own_behind_p2j})
                            : std::optional<std::tuple<Text, Array<crate::lower::node_::Read>>>{};
                        (std::move(this_));
                    });
                    auto wx4_p2l = add_builder(wx3_pv, name_p1b, pos_p9, kt_p17, vt_p18, row_name_ph, keyed_p19, reads_p13, crate::lower::node_::PendingRow{.wx = row_done_p2k, .qk = row_name_ph, .params = row_params_pt, .gather = std::optional<Nat>{}}, passed_ps);
                    auto all_p2m = crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), name_p1b})), Text::lit("borrow"), Array<crate::lower::model::Ex>{}})), Text::lit("iter"), Array<crate::lower::model::Ex>{}})), Text::lit("map"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{false, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("k")}), crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("row")})})})}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XTuple{Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("k")}))}), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("row")})), Text::lit("result"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})})}))})})})), Text::lit("collect"), Array<crate::lower::model::Ex>{}});
                    auto what_p2n = prism_rtl::cat("the dynamic gathered by the `for` at place ", crate::lower::model::place_text(pos_p9));
                    auto wx5_p2o = ({
                        crate::lower::node_::Wx this_ = wx4_p2l;
                        this_.taken = append(this_.taken, Array(std::vector{gathered_p2h, prism_rtl::cat(gathered_p2h, "_now"), prism_rtl::cat(gathered_p2h, "_snap"), prism_rtl::cat(gathered_p2h, "_moved"), prism_rtl::cat(gathered_p2h, "_publish")}));
                        this_.getters = append(this_.getters, Array(std::vector{crate::lower::model::MethDef{.name = prism_rtl::cat(gathered_p2h, "_now"), .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxRef{}), .ret = gathered_ty_p2i, .body = Array<crate::lower::model::Do>{}, .tail = all_p2m, .doc = Text::lit("The rows\' results by key, computed live: what the snapshot of the `for`\'s dynamic is taken from (pick ST).")}, crate::lower::node_::static_::snap_getter(gathered_p2h, gathered_ty_p2i, Text::lit("The `for`\'s dynamic, the rows\' results by key, a structural dynamic (pick ST): one tick behind the rows, the snapshot of the tick before the tick the read point is after."))}));
                        this_.fields = crate::prelude::push(this_.fields, std::tuple{prism_rtl::cat(gathered_p2h, "_snap"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutSnapshot{prism_rtl::rc(gathered_ty_p2i)}), prism_rtl::cat("the `for` at place ", crate::lower::model::place_text(pos_p9), "\'s gathered dynamic, structural: its snapshots, the rows\' results and the lagged dynamic (pick ST)")});
                        this_.inits = crate::prelude::push(this_.inits, std::tuple{prism_rtl::cat(gathered_p2h, "_snap"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Snapshot::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XStr{what_p2n})})})});
                        this_.snaps = crate::prelude::push(this_.snaps, crate::lower::node_::SnapDef{.name = gathered_p2h, .live = prism_rtl::cat(gathered_p2h, "_now"), .ty = gathered_ty_p2i, .eq = crate::lower::program::ty_has_eq(lx_p8, crate::lower::types::peel(full_p10), Array<Text>{}), .builder = name_p1b, .before = false, .what = what_p2n});
                        this_.dyn_reads = insert(this_.dyn_reads, prism_rtl::cat(gathered_p2h, "_now"), crate::lower::node_::union_reads(reads_p13, block_reads(crate::lower::node_::finish::reads_closed(prism_rtl::deref(row_wx_pu).dyn_reads, result_reads_p2f))));
                        (std::move(this_));
                    });
                    (prism_rtl::finished(std::tuple{wx5_p2o, crate::lower::node_::Wres(crate::lower::node_::Wres::WrDyn{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), gathered_p2h, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), Array(std::vector{crate::lower::node_::Read(crate::lower::node_::Read::OwnRead{gathered_p2h})}), gathered_ty_p2i})}));
                });
                })
                    : prism_rtl::is<crate::lower::node_::Wres::WrParts>(_m) ? ({
                    auto wx4_p2q = ({
                        crate::lower::node_::Wx this_ = wx3_pv;
                        this_.build = crate::prelude::push(this_.build, crate::lower::expr::refusal_do(Text::lit("a `for` whose rows end on a bundle (Semantics ch. 4: gathered part by part)")));
                        (std::move(this_));
                    });
                    (prism_rtl::finished(std::tuple{wx4_p2q, crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{})}));
                })
                    : ({
                    auto wx4_p2r = add_builder(wx3_pv, name_p1b, pos_p9, kt_p17, vt_p18, row_name_ph, keyed_p19, reads_p13, crate::lower::node_::PendingRow{.wx = row_wx_pu, .qk = row_name_ph, .params = row_params_pt, .gather = std::optional<Nat>{}}, passed_ps);
                    (prism_rtl::finished(std::tuple{wx4_p2r, crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{})}));
                });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start ForLine, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres>> start_for_line(crate::lower::node_::Wx wx_p0, crate::lower::types::Env benv_p1, crate::lower::types::Env menv_p2, std::optional<crate::syntax::ForBinders> binders_o3, crate::syntax::Expr source_p4, crate::syntax::Block body_p5, crate::syntax::Expr e_p6, std::optional<crate::lower::types::Bn> bound_o7) {
    return prism_rtl::make_rc<ForLine>(wx_p0, benv_p1, menv_p2, binders_o3, source_p4, body_p5, e_p6, bound_o7);
}


/// EntryGetter: fn Text, OutTy -> MethDef
crate::lower::model::MethDef entry_getter(const Text& src_getter_p0, const crate::lower::model::OutTy& vt_p1) {
    auto found_p2 = crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("parent")})), src_getter_p0, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})), Text::lit("get"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), Text::lit("key")}))})})})), Text::lit("cloned"), Array<crate::lower::model::Ex>{}});
    auto opened_p3 = crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCx{})), Text::lit("before"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{false, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("cx")})}), prism_rtl::rc(found_p2)})})})), Text::lit("expect"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XStr{Text::lit("a row\'s key is in its source as its tick opened")})})});
    auto body_p4 = Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoIfLet{crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("v")})})}), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), Text::lit("left_entry")})), Text::lit("borrow"), Array<crate::lower::model::Ex>{}})), Text::lit("as_ref"), Array<crate::lower::model::Ex>{}}), Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoReturn{crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("v")}))})})}), Array<crate::lower::model::Do>{}}), crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("parent")}), crate::lower::node_::switch_::parent_ref()})});
    auto tail_p5 = crate::lower::model::Ex(crate::lower::model::Ex::XMatch{prism_rtl::rc(found_p2), Array(std::vector{crate::lower::model::XArm{.pat = crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("v")})})}), .conds = Array<crate::lower::model::Cc>{}, .body = crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("v")})}, crate::lower::model::XArm{.pat = crate::lower::model::Pa(crate::lower::model::Pa::PaUnit{Text::lit("None")}), .conds = Array<crate::lower::model::Cc>{}, .body = opened_p3}}), false, vt_p1});
    return crate::lower::model::MethDef{.name = Text::lit("entry"), .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxRef{}), .ret = vt_p1, .body = body_p4, .tail = tail_p5, .doc = Text::lit("The row\'s entry, `$_`: the block\'s source at this key, at the read point; from the row\'s leaving on, the value as the leaving tick opened.")};
}


/// AddBuilder: fn Wx, Text, Pos, OutTy, OutTy, Text, Bool, [Read], PendingRow, [Ex] -> Wx
crate::lower::node_::Wx add_builder(const crate::lower::node_::Wx& wx_p0, const Text& name_p1, const crate::lower::model::Pos_& pos_p2, const crate::lower::model::OutTy& kt_p3, const crate::lower::model::OutTy& vt_p4, const Text& row_name_p5, const bool& keyed_p6, const Array<crate::lower::node_::Read>& reads_p7, const crate::lower::node_::PendingRow& waiting_p8, const Array<crate::lower::model::Ex>& passed_p9) {
    auto wx0_pa = crate::lower::node_::add_field_last(wx_p0, name_p1, crate::lower::model::OutTy(crate::lower::model::OutTy::OutCell{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutMap{prism_rtl::rc(kt_p3), prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutRc{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{row_name_p5, Array<crate::lower::model::OutTy>{}}))}))}))}), prism_rtl::cat("the rows of the `for` at place ", crate::lower::model::place_text(pos_p2)), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("RefCell::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Map::new"), Array<crate::lower::model::Ex>{}})})}));
    auto wx1_pb = crate::lower::node_::add_field_last(wx0_pa, prism_rtl::cat(name_p1, "_from"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutCell{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutMap{prism_rtl::rc(kt_p3), prism_rtl::rc(vt_p4)}))}), prism_rtl::cat("the source the rows of the `for` at place ", crate::lower::model::place_text(pos_p2), " were last built from"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("RefCell::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Map::new"), Array<crate::lower::model::Ex>{}})})}));
    auto replaced_pc = each(filter(prism_rtl::deref(waiting_p8.wx).flattens, [&](const crate::lower::node_::FlatDef& fl_pd) { return fl_pd->generation == Text::lit(""); }), [&](const crate::lower::node_::FlatDef& fl_pe) { return prism_rtl::cat(prism_rtl::deref(fl_pe).name, "_replaced"); });
    crate::lower::node_::Wx this_ = wx1_pb;
    this_.builders = crate::prelude::push(this_.builders, crate::lower::model::ForDef{.name = name_p1, .pos = pos_p2, .at = crate::lower::node_::finish::place_at(wx_p0, Text::lit("self"), pos_p2), .key_ty = kt_p3, .value_ty = vt_p4, .row_node = row_name_p5, .keyed = keyed_p6, .source = prism_rtl::cat(name_p1, "_source"), .parent = crate::lower::model::Ex(crate::lower::model::Ex::XWeak{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{}))}), .passed = passed_p9, .moved = or_(crate::lower::node_::finish::hosted_rows(wx_p0), Text::lit("")), .replaced = replaced_pc});
    this_.build_holds = crate::lower::node_::union_reads(this_.build_holds, reads_p7);
    this_.pending = crate::prelude::push(this_.pending, waiting_p8);
    return this_;
}


/// ForValueName: fn ?ForBinders -> Text
Text for_value_name(const std::optional<crate::syntax::ForBinders>& binders_o0) {
    if (prism_rtl::is_some(binders_o0)) {
        auto&& fb_p1 = prism_rtl::some_of(binders_o0);
        auto&& _m = prism_rtl::deref(fb_p1).second;
        if (prism_rtl::is_some(_m)) {
            auto&& p_p2 = prism_rtl::some_of(_m);
            return pattern_name_or(p_p2, Text::lit("flatten"));
        }
        if (prism_rtl::is_none(_m)) {
            return pattern_name_or(prism_rtl::deref(fb_p1).first, Text::lit("flatten"));
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is_none(binders_o0)) {
        return Text::lit("flatten");
    }
    prism_rtl::unreachable("no arm matched");
}


/// PatternNameOr: fn Pattern, Text -> Text
Text pattern_name_or(const crate::syntax::Pattern_& p_p0, const Text& other_p1) {
    auto&& _m = prism_rtl::deref(p_p0.kind);
    if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
        auto&& n_p2 = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        return crate::check::env::sname_key(n_p2);
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PGroup>(_m)) {
        auto&& q_p3 = prism_rtl::as<crate::syntax::PatternKind::PGroup>(_m).a0;
        return pattern_name_or(prism_rtl::deref(prism_rtl::deref(q_p3)), other_p1);
    }
    {
        return other_p1;
    }
}


/// RowPlaceReads: fn Wx -> [Read]
Array<crate::lower::node_::Read> row_place_reads(const crate::lower::node_::Wx& row_wx_p0) {
    return fold(row_wx_p0.places, Array<crate::lower::node_::Read>{}, [&](const Array<crate::lower::node_::Read>& acc_p1, const crate::lower::node_::Place& pl_p2) { return crate::lower::node_::union_reads(acc_p1, block_reads(crate::lower::node_::finish::reads_closed(row_wx_p0.dyn_reads, prism_rtl::deref(pl_p2).reads))); });
}


/// HostedParams: fn Wx -> [((Text, OutTy))]
Array<std::tuple<Text, crate::lower::model::OutTy>> hosted_params(const crate::lower::node_::Wx& wx_p0) {
    auto&& _m = crate::lower::node_::finish::hosted_rows(wx_p0);
    if (prism_rtl::is_some(_m)) {
        return Array(std::vector{std::tuple{Text::lit("enclosing"), crate::lower::types::host_of_ty()}});
    }
    if (prism_rtl::is_none(_m)) {
        return Array<std::tuple<Text, crate::lower::model::OutTy>>{};
    }
    prism_rtl::unreachable("no arm matched");
}


/// HostedPassed: fn Wx -> [Ex]
Array<crate::lower::model::Ex> hosted_passed(const crate::lower::node_::Wx& wx_p0) {
    auto&& _m = crate::lower::node_::finish::hosted_rows(wx_p0);
    if (prism_rtl::is_some(_m)) {
        return Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::node_::finish::host_field_ex(wx_p0, wx_p0.pos))})});
    }
    if (prism_rtl::is_none(_m)) {
        return Array<crate::lower::model::Ex>{};
    }
    prism_rtl::unreachable("no arm matched");
}


/// RowReads: fn Env, Ex -> Env
crate::lower::types::Env row_reads(const crate::lower::types::Env& env_p0, const crate::lower::model::Ex& pref_p1) {
    return fold(keys(env_p0.names), env_p0, [&](const crate::lower::types::Env& en_p2, const Text& k_p3) {
        return ({
            __label__ _done;
            prism_rtl::Slot<crate::lower::types::Env> _v;
            auto&& _m = crate::prelude::get(env_p0.names, k_p3);
            if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnHold>(prism_rtl::some_of(_m))) {
                auto&& f_p4 = prism_rtl::as<crate::lower::types::Bn::BnHold>(prism_rtl::some_of(_m)).a0;
                auto&& t_p5 = prism_rtl::as<crate::lower::types::Bn::BnHold>(prism_rtl::some_of(_m)).a1;
                _v.set(crate::lower::types::bind(en_p2, k_p3, crate::lower::types::Bn(crate::lower::types::Bn::BnDyn{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(pref_p1), f_p4})), Text::lit("get"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), Array(std::vector{crate::lower::node_::Read(crate::lower::node_::Read::ParentRead{f_p4})}), t_p5})));
                goto _done;
            }
            if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)) && prism_rtl::is<crate::lower::model::Ex::XMethod>(prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)).a0)) {
                auto&& m15224_1_0_0 = prism_rtl::as<crate::lower::model::Ex::XMethod>(prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)).a0).a0;
                auto&& m_p6 = prism_rtl::as<crate::lower::model::Ex::XMethod>(prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)).a0).a1;
                auto&& xs_p7 = prism_rtl::as<crate::lower::model::Ex::XMethod>(prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)).a0).a2;
                auto&& t_p8 = prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)).a2;
                if (prism_rtl::is<crate::lower::model::Ex::XSelf>(prism_rtl::deref(prism_rtl::deref(m15224_1_0_0)))) {
                    _v.set(crate::lower::types::bind(en_p2, k_p3, crate::lower::types::Bn(crate::lower::types::Bn::BnDyn{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(pref_p1), m_p6, xs_p7}), Array(std::vector{crate::lower::node_::Read(crate::lower::node_::Read::ParentRead{m_p6})}), t_p8})));
                    goto _done;
                }
            }
            if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m))) {
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<crate::lower::types::Env> _v;
                    auto&& _m = crate::prelude::get(env_p0.names, prism_rtl::cat(k_p3, "#row"));
                    if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)) && prism_rtl::is<crate::lower::model::Ex::XMethod>(prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)).a0)) {
                        auto&& m_p9 = prism_rtl::as<crate::lower::model::Ex::XMethod>(prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)).a0).a1;
                        auto&& xs_pa = prism_rtl::as<crate::lower::model::Ex::XMethod>(prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)).a0).a2;
                        auto&& t_pb = prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)).a2;
                        _v.set(crate::lower::types::bind(en_p2, k_p3, crate::lower::types::Bn(crate::lower::types::Bn::BnDyn{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(pref_p1), m_p9, xs_pa}), Array(std::vector{crate::lower::node_::Read(crate::lower::node_::Read::ParentRead{m_p9})}), t_pb})));
                        goto _done;
                    }
                    {
                        _v.set(en_p2);
                        goto _done;
                    }
                _done:
                    _v.take();
                }));
                goto _done;
            }
            {
                _v.set(en_p2);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


/// EventsOf: fn Env, Env -> Env
crate::lower::types::Env events_of(const crate::lower::types::Env& ports_p0, const crate::lower::types::Env& env_p1) {
    return fold(keys(ports_p0.names), env_p1, [&](const crate::lower::types::Env& en_p2, const Text& k_p3) {
        return ({
            __label__ _done;
            prism_rtl::Slot<crate::lower::types::Env> _v;
            auto&& _m = crate::prelude::get(ports_p0.names, k_p3);
            if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(_m))) {
                auto&& er_p4 = prism_rtl::as<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(_m)).a0;
                auto&& t_p5 = prism_rtl::as<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(_m)).a1;
                _v.set(crate::lower::types::bind(en_p2, k_p3, crate::lower::types::Bn(crate::lower::types::Bn::BnEv{er_p4, t_p5})));
                goto _done;
            }
            {
                _v.set(en_p2);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


/// BlockReads: fn [Read] -> [Read]
Array<crate::lower::node_::Read> block_reads(const Array<crate::lower::node_::Read>& reads_p0) {
    return fold(reads_p0, Array<crate::lower::node_::Read>{}, [&](const Array<crate::lower::node_::Read>& acc_p1, const crate::lower::node_::Read& r_p2) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::lower::node_::Read>> _v;
            if (prism_rtl::is<crate::lower::node_::Read::ParentRead>(r_p2)) {
                auto&& f_p3 = prism_rtl::as<crate::lower::node_::Read::ParentRead>(r_p2).a0;
                _v.set(crate::lower::node_::add_read(acc_p1, crate::lower::node_::Read(crate::lower::node_::Read::OwnRead{f_p3})));
                goto _done;
            }
            if (prism_rtl::is<crate::lower::node_::Read::OwnRead>(r_p2)) {
                _v.set(acc_p1);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
}


/// RowLocals: unbounded fn Env, Env, Block -> [RowLocal]
Array<RowLocal> row_locals(const crate::lower::types::Env& benv_p0, const crate::lower::types::Env& menv_p1, const crate::syntax::Block& body_p2) {
    return fold(crate::lower::expr::read_names(crate::check::typed::print::block_exprs(body_p2)), Array<RowLocal>{}, [&](const Array<RowLocal>& acc_p3, const Text& n_p4) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<RowLocal>> _v;
            auto&& _m = crate::prelude::get(menv_p1.names, n_p4);
            if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m))) {
                auto&& rs_p5 = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                auto&& mode_p6 = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a1;
                auto&& t_p7 = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                _v.set(({
                    auto field_p8 = crate::lower::snake(n_p4);
                    (((field_p8 == Text::lit("key")) || (field_p8 == Text::lit("value"))) || (field_p8 == Text::lit("parent"))) || (field_p8 == Text::lit("path"))
                    ? acc_p3
                    : crate::prelude::push(acc_p3, RowLocal{.name = n_p4, .field = field_p8, .ty = t_p7, .passed = crate::lower::types::own(crate::lower::types::Vl(crate::lower::types::Vl::VlPlace{rs_p5, mode_p6, t_p7}))});
                }));
                goto _done;
            }
            {
                _v.set(acc_p3);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


/// ForEnvs: unbounded fn Env, Env, ?ForBinders, Bn, Bn, Bn, Bn, OutTy -> ((Env, Env))
std::tuple<crate::lower::types::Env, crate::lower::types::Env> for_envs(const crate::lower::types::Env& benv_p0, const crate::lower::types::Env& menv_p1, const std::optional<crate::syntax::ForBinders>& binders_o2, const crate::lower::types::Bn& key_b_p3, const crate::lower::types::Bn& key_m_p4, const crate::lower::types::Bn& val_b_p5, const crate::lower::types::Bn& val_m_p6, const crate::lower::model::OutTy& vt_p7) {
    auto be0_p8 = crate::lower::types::bind(crate::lower::types::bind(benv_p0, Text::lit("key"), key_b_p3), Text::lit("$_"), val_b_p5);
    auto me0_p9 = crate::lower::types::bind(crate::lower::types::bind(menv_p1, Text::lit("key"), key_m_p4), Text::lit("$_"), val_m_p6);
    if (prism_rtl::is_none(binders_o2)) {
        return std::tuple{be0_p8, me0_p9};
    }
    if (prism_rtl::is_some(binders_o2)) {
        auto&& fb_pa = prism_rtl::some_of(binders_o2);
        auto&& _m = prism_rtl::deref(fb_pa).second;
        if (prism_rtl::is_some(_m)) {
            auto&& second_pb = prism_rtl::some_of(_m);
            auto be1_pc = bind_pat(be0_p8, prism_rtl::deref(fb_pa).first, key_b_p3, crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("key")}), kt0());
            auto me1_pd = bind_pat(me0_p9, prism_rtl::deref(fb_pa).first, key_m_p4, crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), Text::lit("key")}), kt0());
            return std::tuple{bind_pat(be1_pc, second_pb, val_b_p5, crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("value")}), vt_p7), bind_pat(me1_pd, second_pb, val_m_p6, crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), vt_p7)};
        }
        if (prism_rtl::is_none(_m)) {
            return std::tuple{bind_pat(be0_p8, prism_rtl::deref(fb_pa).first, val_b_p5, crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("value")}), vt_p7), bind_pat(me0_p9, prism_rtl::deref(fb_pa).first, val_m_p6, crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), vt_p7)};
        }
        prism_rtl::unreachable("no arm matched");
    }
    prism_rtl::unreachable("no arm matched");
}


/// let kt0
crate::lower::model::OutTy kt0() {
    return crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{});
}


/// BindPat: fn Env, Pattern, Bn, Ex, OutTy -> Env
crate::lower::types::Env bind_pat(const crate::lower::types::Env& env_p0, const crate::syntax::Pattern_& p_p1, const crate::lower::types::Bn& b_p2, const crate::lower::model::Ex& whole_p3, const crate::lower::model::OutTy& t_p4) {
    auto&& _m = prism_rtl::deref(p_p1.kind);
    if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
        auto&& n_p5 = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        return crate::lower::types::bind(env_p0, crate::check::env::sname_key(n_p5), b_p2);
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PGroup>(_m)) {
        auto&& q_p6 = prism_rtl::as<crate::syntax::PatternKind::PGroup>(_m).a0;
        return bind_pat(env_p0, prism_rtl::deref(prism_rtl::deref(q_p6)), b_p2, whole_p3, t_p4);
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PTuple>(_m)) {
        auto&& ps_p7 = prism_rtl::as<crate::syntax::PatternKind::PTuple>(_m).a0;
        auto ts_p8 = ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::lower::model::OutTy>> _v;
            if (prism_rtl::is<crate::lower::model::OutTy::OutTuple>(t_p4)) {
                auto&& xs_p9 = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(t_p4).a0;
                _v.set(xs_p9);
                goto _done;
            }
            {
                _v.set(Array<crate::lower::model::OutTy>{});
                goto _done;
            }
        _done:
            _v.take();
        });
        return fold(crate::check::errors::range0(len(ps_p7)), env_p0, [&](const crate::lower::types::Env& en_pa, const Nat& i_pb) {
            return ({
                __label__ _done;
                prism_rtl::Slot<crate::lower::types::Env> _v;
                auto&& _m = index(ps_p7, i_pb);
                if (prism_rtl::is_some(_m)) {
                    auto&& q_pc = prism_rtl::some_of(_m);
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<crate::lower::types::Env> _v;
                        auto&& _m = prism_rtl::deref(prism_rtl::deref(q_pc).kind);
                        if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
                            auto&& n_pd = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
                            _v.set(crate::lower::types::bind(en_pa, crate::check::env::sname_key(n_pd), part_bn(b_p2, whole_p3, i_pb, or_(index(ts_p8, i_pb), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})))));
                            goto _done;
                        }
                        {
                            _v.set(en_pa);
                            goto _done;
                        }
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(en_pa);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
        });
    }
    {
        return env_p0;
    }
}


/// PartBn: fn Bn, Ex, Nat, OutTy -> Bn
crate::lower::types::Bn part_bn(const crate::lower::types::Bn& bn0, const crate::lower::model::Ex& whole_p2, const Nat& i_p3, const crate::lower::model::OutTy& t_p4) {
    if (prism_rtl::is<crate::lower::types::Bn::BnDyn>(bn0)) {
        auto&& x_p0 = prism_rtl::as<crate::lower::types::Bn::BnDyn>(bn0).a0;
        auto&& rds_p1 = prism_rtl::as<crate::lower::types::Bn::BnDyn>(bn0).a1;
        return crate::lower::types::Bn(crate::lower::types::Bn::BnDyn{crate::lower::model::Ex(crate::lower::model::Ex::XPart{prism_rtl::rc(x_p0), i_p3}), rds_p1, t_p4});
    }
    {
        auto&& other_p5 = bn0;
        return crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XPart{prism_rtl::rc(whole_p2), i_p3}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), t_p4});
    }
}


/// RowSuffix: fn Wx -> Text
Text row_suffix(const crate::lower::node_::Wx& wx_p0) {
    auto n_p1 = len(wx_p0.rows) + len(wx_p0.pending);
    return n_p1 == Nat(0u) ? Text::lit("") : prism_rtl::cat(n_p1);
}


/// GnTyNamed: fn Wx, Text -> OutTy
crate::lower::model::OutTy gn_ty_named(const crate::lower::node_::Wx& wx_p0, const Text& n_p1) {
    return fold(wx_p0.gns, crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), [&](const crate::lower::model::OutTy& acc_p2, const crate::lower::node_::Gn& g_p3) { return prism_rtl::deref(g_p3).name == n_p1 ? prism_rtl::deref(g_p3).ty : acc_p2; });
}

}  // namespace crate::lower::node_::keyed
