// The modules `check_types`, `typed`: its records, tags and newtypes (each after the types it holds) and its
// choices' cases, emitted by prismc (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include "check_types.decl.hpp"
#include "typed.decl.hpp"
#include "elem.decl.hpp"
#include "check_errors.decl.hpp"
#include "lexer.decl.hpp"
#include "ast.types.hpp"

namespace crate {

using namespace prelude;

namespace check_types {

/// `CLeq`:
///
/// ```prism
/// type CLeq = record:
/// ```
struct CLeq {
    using prism_value = void;
    Col lo;
    Col hi;
    Nat file;
    ast::Range span;
    Text kind;
    Text name;
    Text why;
    const CLeq* operator->() const { return this; }
    CLeq* operator->() { return this; }
    bool operator==(const CLeq&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<CLeq> from_pod(const Pod& whole);
};


}  // namespace check_types

namespace check_types {

/// `FieldQ`:
///
/// ```prism
/// type FieldQ = record:
/// ```
struct FieldQ {
    using prism_value = void;
    Ty recv;
    Text field;
    Ty result;
    ast::Range span;
    Nat file;
    Array<Text> owners;
    const FieldQ* operator->() const { return this; }
    FieldQ* operator->() { return this; }
    bool operator==(const FieldQ&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<FieldQ> from_pod(const Pod& whole);
};


}  // namespace check_types

namespace check_types {

/// `Inst`:
///
/// ```prism
/// type Inst = record:
/// ```
struct Inst {
    using prism_value = void;
    Map<Text, Ty> tys;
    Map<Text, Tail> rows;
    Map<Text, Col> cols;
    const Inst* operator->() const { return this; }
    Inst* operator->() { return this; }
    bool operator==(const Inst&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Inst> from_pod(const Pod& whole);
};


}  // namespace check_types

namespace check_types {

/// `Rw`:
///
/// ```prism
/// type Rw = record:
/// ```
struct Rw {
    using prism_value = void;
    Array<Text> fams;
    Array<Text> minus;
    Tail tail;
    const Rw* operator->() const { return this; }
    Rw* operator->() { return this; }
    bool operator==(const Rw&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Rw> from_pod(const Pod& whole);
};


}  // namespace check_types

namespace check_types {

/// `Scheme`:
///
/// ```prism
/// type Scheme = record:
/// ```
struct Scheme {
    using prism_value = void;
    Array<Text> qs;
    Array<Text> plain_qs;
    Array<Text> rqs;
    Array<Text> cqs;
    Array<std::tuple<Text, Text>> cjoins;
    Array<std::tuple<Text, Text>> bounds;
    Ty ty;
    const Scheme* operator->() const { return this; }
    Scheme* operator->() { return this; }
    bool operator==(const Scheme&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Scheme> from_pod(const Pod& whole);
};


}  // namespace check_types

namespace check_types {

/// `VInfo`:
///
/// ```prism
/// type VInfo = record:
/// ```
struct VInfo {
    using prism_value = void;
    bool plain;
    Nat level;
    Text name;
    const VInfo* operator->() const { return this; }
    VInfo* operator->() { return this; }
    bool operator==(const VInfo&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<VInfo> from_pod(const Pod& whole);
};


}  // namespace check_types

namespace check_types {

/// `Want`:
///
/// ```prism
/// type Want = record:
/// ```
struct Want {
    using prism_value = void;
    Text cls;
    Ty ty;
    Nat file;
    ast::Range span;
    Nat level;
    const Want* operator->() const { return this; }
    Want* operator->() { return this; }
    bool operator==(const Want&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Want> from_pod(const Pod& whole);
};


}  // namespace check_types

namespace typed {

/// `SrcAt`:
///
/// ```prism
/// type SrcAt = record:
/// ```
struct SrcAt {
    using prism_value = void;
    Nat file;
    ast::Range span;
    const SrcAt* operator->() const { return this; }
    SrcAt* operator->() { return this; }
    bool operator==(const SrcAt&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<SrcAt> from_pod(const Pod& whole);
};


}  // namespace typed

namespace typed {

/// `TProgram`:
///
/// ```prism
/// type TProgram = record:
/// ```
struct TProgram {
    using prism_value = void;
    Array<TyNote> exprs;
    Array<AppNote> apps;
    Array<FnNote> fns;
    Array<ImplNote> impls;
    Array<MethodNote> methods;
    Array<GroupNote> groups;
    Array<BinderNote> binders;
    Array<GenNote> gens;
    Array<InstNote> insts;
    Array<DefNote> defs;
    Array<SrcAt> unshrunk;
    const TProgram* operator->() const { return this; }
    TProgram* operator->() { return this; }
    bool operator==(const TProgram&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<TProgram> from_pod(const Pod& whole);
};


}  // namespace typed

namespace check_types {

/// `Incl`:
///
/// ```prism
/// type Incl = record:
/// ```
struct Incl {
    using prism_value = void;
    Rw sub;
    Rw sup;
    Nat file;
    ast::Range span;
    Text what;
    bool forward;
    const Incl* operator->() const { return this; }
    Incl* operator->() { return this; }
    bool operator==(const Incl&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Incl> from_pod(const Pod& whole);
};


}  // namespace check_types

namespace check_types {

/// `St`:
///
/// ```prism
/// type St = record:
/// ```
struct St {
    using prism_value = void;
    Nat next;
    Map<Nat, Ty> tys;
    Map<Nat, VInfo> infos;
    Map<Nat, Rw> rows;
    Map<Nat, Array<Text>> lacks;
    Array<Want> wants;
    Array<Incl> incls;
    Array<check_errors::CDiag> diags;
    Nat level;
    Nat file;
    Col color;
    Text color_why;
    Array<std::tuple<Col, Text, ast::Range>> color_flex;
    Map<Nat, Col> cols;
    Array<CLeq> cleqs;
    Map<Nat, Text> col_q;
    Map<Text, Text> col_up;
    Array<std::tuple<Ty, Ty, ast::Range>> deferred;
    Map<Nat, ast::Range> binder_at;
    Map<Nat, Text> row_names;
    Array<std::tuple<Ty, ast::Range, Text>> layer_qs;
    Array<FieldQ> field_qs;
    bool recording;
    typed::TProgram typed;
    Map<Text, Array<Text>> choices;
    Map<Text, Ty> size_tys;
    const St* operator->() const { return this; }
    St* operator->() { return this; }
    bool operator==(const St&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<St> from_pod(const Pod& whole);
};


}  // namespace check_types

namespace typed {

/// `AppNote`:
///
/// ```prism
/// type AppNote = record:
/// ```
struct AppNote {
    using prism_value = void;
    SrcAt at;
    Text callee;
    Text kind;
    Text layer;
    Array<Nat> lifted;
    Text inner;
    check_types::Col color;
    const AppNote* operator->() const { return this; }
    AppNote* operator->() { return this; }
    bool operator==(const AppNote&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<AppNote> from_pod(const Pod& whole);
};


}  // namespace typed

namespace typed {

/// `BinderNote`:
///
/// ```prism
/// type BinderNote = record:
/// ```
struct BinderNote {
    using prism_value = void;
    SrcAt at;
    Text name;
    check_types::Ty ty;
    const BinderNote* operator->() const { return this; }
    BinderNote* operator->() { return this; }
    bool operator==(const BinderNote&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<BinderNote> from_pod(const Pod& whole);
};


}  // namespace typed

namespace typed {

/// `DefNote`:
///
/// ```prism
/// type DefNote = record:
/// ```
struct DefNote {
    using prism_value = void;
    SrcAt at;
    Text name;
    check_types::Scheme scheme;
    const DefNote* operator->() const { return this; }
    DefNote* operator->() { return this; }
    bool operator==(const DefNote&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<DefNote> from_pod(const Pod& whole);
};


}  // namespace typed

namespace typed {

/// `FnNote`:
///
/// ```prism
/// type FnNote = record:
/// ```
struct FnNote {
    using prism_value = void;
    SrcAt at;
    Text name;
    check_types::Col declared;
    check_types::Col body;
    const FnNote* operator->() const { return this; }
    FnNote* operator->() { return this; }
    bool operator==(const FnNote&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<FnNote> from_pod(const Pod& whole);
};


}  // namespace typed

namespace typed {

/// `GenNote`:
///
/// ```prism
/// type GenNote = record:
/// ```
struct GenNote {
    using prism_value = void;
    SrcAt at;
    Text name;
    Array<Text> tys;
    Array<Text> cols;
    const GenNote* operator->() const { return this; }
    GenNote* operator->() { return this; }
    bool operator==(const GenNote&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<GenNote> from_pod(const Pod& whole);
};


}  // namespace typed

namespace typed {

/// `GroupNote`:
///
/// ```prism
/// type GroupNote = record:
/// ```
struct GroupNote {
    using prism_value = void;
    SrcAt at;
    Text kind;
    Array<Array<Nat>> order;
    const GroupNote* operator->() const { return this; }
    GroupNote* operator->() { return this; }
    bool operator==(const GroupNote&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<GroupNote> from_pod(const Pod& whole);
};


}  // namespace typed

namespace typed {

/// `ImplNote`:
///
/// ```prism
/// type ImplNote = record:
/// ```
struct ImplNote {
    using prism_value = void;
    SrcAt at;
    Text cls;
    check_types::Ty ty;
    Text how;
    const ImplNote* operator->() const { return this; }
    ImplNote* operator->() { return this; }
    bool operator==(const ImplNote&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<ImplNote> from_pod(const Pod& whole);
};


}  // namespace typed

namespace typed {

/// `InstNote`:
///
/// ```prism
/// type InstNote = record:
/// ```
struct InstNote {
    using prism_value = void;
    SrcAt at;
    Text name;
    Array<std::tuple<Text, check_types::Ty>> tys;
    Array<std::tuple<Text, check_types::Col>> cols;
    const InstNote* operator->() const { return this; }
    InstNote* operator->() { return this; }
    bool operator==(const InstNote&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<InstNote> from_pod(const Pod& whole);
};


}  // namespace typed

namespace typed {

/// `MethodNote`:
///
/// ```prism
/// type MethodNote = record:
/// ```
struct MethodNote {
    using prism_value = void;
    SrcAt at;
    Text method;
    Text cls;
    const MethodNote* operator->() const { return this; }
    MethodNote* operator->() { return this; }
    bool operator==(const MethodNote&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<MethodNote> from_pod(const Pod& whole);
};


}  // namespace typed

namespace typed {

/// `TyNote`:
///
/// ```prism
/// type TyNote = record:
/// ```
struct TyNote {
    using prism_value = void;
    SrcAt at;
    check_types::Ty ty;
    const TyNote* operator->() const { return this; }
    TyNote* operator->() { return this; }
    bool operator==(const TyNote&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<TyNote> from_pod(const Pod& whole);
};


}  // namespace typed

namespace check_types {

struct Col::CBound {
    bool operator==(const CBound&) const = default;
};


struct Col::CUnbound {
    bool operator==(const CUnbound&) const = default;
};


struct Col::CRigid {
    Text a0;
    bool operator==(const CRigid&) const = default;
};


struct Col::CQ {
    Text a0;
    bool operator==(const CQ&) const = default;
};


struct Col::CFlex {
    Nat a0;
    bool operator==(const CFlex&) const = default;
};


inline const Col::Cases& Col::cases() const { return *cases_; }

inline bool operator==(const Col& a, const Col& b) { return a.cases() == b.cases(); }

struct Tail::TlClosed {
    bool operator==(const TlClosed&) const = default;
};


struct Tail::TlFlex {
    Nat a0;
    bool operator==(const TlFlex&) const = default;
};


struct Tail::TlRigid {
    Text a0;
    bool operator==(const TlRigid&) const = default;
};


struct Tail::TlQ {
    Text a0;
    bool operator==(const TlQ&) const = default;
};


inline const Tail::Cases& Tail::cases() const { return *cases_; }

inline bool operator==(const Tail& a, const Tail& b) { return a.cases() == b.cases(); }

struct Ty::TyFlex {
    Nat a0;
    bool operator==(const TyFlex&) const = default;
};


struct Ty::TyRigid {
    Text a0;
    bool operator==(const TyRigid&) const = default;
};


struct Ty::TyQ {
    Text a0;
    bool operator==(const TyQ&) const = default;
};


struct Ty::TyCon {
    Text a0;
    Array<Ty> a1;
    bool operator==(const TyCon&) const = default;
};


struct Ty::TyFn {
    Col a0;
    Array<Ty> a1;
    Ty a2;
    bool operator==(const TyFn&) const = default;
};


struct Ty::TyTuple {
    Array<Ty> a0;
    bool operator==(const TyTuple&) const = default;
};


struct Ty::TyArray {
    Ty a0;
    bool operator==(const TyArray&) const = default;
};


struct Ty::TyMap {
    Ty a0;
    Ty a1;
    bool operator==(const TyMap&) const = default;
};


struct Ty::TySig {
    Text a0;
    Ty a1;
    bool operator==(const TySig&) const = default;
};


struct Ty::TyAt {
    Ty a0;
    Rw a1;
    bool operator==(const TyAt&) const = default;
};


struct Ty::TyElem {
    Rw a0;
    Ty a1;
    bool operator==(const TyElem&) const = default;
};


struct Ty::TyElemAny {
    Rw a0;
    bool operator==(const TyElemAny&) const = default;
};


struct Ty::TyAssoc {
    Text a0;
    Ty a1;
    bool operator==(const TyAssoc&) const = default;
};


struct Ty::TyAny {
    Array<Text> a0;
    bool operator==(const TyAny&) const = default;
};


struct Ty::TyErr {
    bool operator==(const TyErr&) const = default;
};


inline const Ty::Cases& Ty::cases() const { return *cases_; }

inline bool operator==(const Ty& a, const Ty& b) { return a.cases() == b.cases(); }

}  // namespace check_types

}  // namespace crate
