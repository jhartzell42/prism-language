// The module `Emit.Rust`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <emit/rust/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>

// The module `Emit.Rust`, from `target/bootstrap/cpp-src/prismc/emit/rust/mod.prism`.
namespace crate::emit::rust {

/// Type: unbounded fn OutTy -> Text
Text type_f(const crate::lower::model::OutTy& t_p0) {
    if (prism_rtl::is<crate::lower::model::OutTy::OutNat>(t_p0)) {
        return Text::lit("Nat");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutInt>(t_p0)) {
        return Text::lit("Int");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutU8>(t_p0)) {
        return Text::lit("u8");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutFloat>(t_p0)) {
        return Text::lit("Float");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutBool>(t_p0)) {
        return Text::lit("bool");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutChar>(t_p0)) {
        return Text::lit("char");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutText>(t_p0)) {
        return Text::lit("Text");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutCursor>(t_p0)) {
        return Text::lit("Cursor");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutRegex>(t_p0)) {
        return Text::lit("Regex");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutReplacement>(t_p0)) {
        return Text::lit("RegexReplacement");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutUnit>(t_p0)) {
        return Text::lit("()");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutPath>(t_p0)) {
        return Text::lit("Path");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutDuration>(t_p0)) {
        return Text::lit("Duration");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutError>(t_p0)) {
        return Text::lit("Error");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t_p0)) {
        auto&& n_p1 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p0).a0;
        auto&& m1596_14_1 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p0).a1;
        if (m1596_14_1.size() == 0u) {
            return n_p1;
        }
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t_p0)) {
        auto&& n_p2 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p0).a0;
        auto&& args_p3 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p0).a1;
        return prism_rtl::cat(n_p2, "<", types_f(args_p3), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutOpt>(t_p0)) {
        auto&& i_p4 = prism_rtl::as<crate::lower::model::OutTy::OutOpt>(t_p0).a0;
        return prism_rtl::cat("Option<", type_f(prism_rtl::deref(prism_rtl::deref(i_p4))), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutRes>(t_p0)) {
        auto&& i_p5 = prism_rtl::as<crate::lower::model::OutTy::OutRes>(t_p0).a0;
        return prism_rtl::cat("Result<", type_f(prism_rtl::deref(prism_rtl::deref(i_p5))), ", Error>");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutTuple>(t_p0)) {
        auto&& m1596_18_0 = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(t_p0).a0;
        if (m1596_18_0.size() == 1u) {
            {
                auto&& _c1 = crate::prelude::index(m1596_18_0, Nat(0u));
                if (prism_rtl::is_some(_c1)) {
                    auto&& one_p6 = prism_rtl::some_of(_c1);
                    return prism_rtl::cat("(", type_f(one_p6), ",)");
                }
            }
        }
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutTuple>(t_p0)) {
        auto&& ts_p7 = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(t_p0).a0;
        return prism_rtl::cat("(", types_f(ts_p7), ")");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutArray>(t_p0)) {
        auto&& e_p8 = prism_rtl::as<crate::lower::model::OutTy::OutArray>(t_p0).a0;
        return prism_rtl::cat("Array<", type_f(prism_rtl::deref(prism_rtl::deref(e_p8))), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutMap>(t_p0)) {
        auto&& k_p9 = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t_p0).a0;
        auto&& v_pa = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t_p0).a1;
        return prism_rtl::cat("Map<", type_f(prism_rtl::deref(prism_rtl::deref(k_p9))), ", ", type_f(prism_rtl::deref(prism_rtl::deref(v_pa))), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutFn>(t_p0)) {
        auto&& ps_pb = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t_p0).a0;
        auto&& r_pc = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t_p0).a1;
        return prism_rtl::cat("Rc<dyn Fn(", ref_types_f(ps_pb), ") -> ", type_f(prism_rtl::deref(prism_rtl::deref(r_pc))), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutRef>(t_p0)) {
        auto&& i_pd = prism_rtl::as<crate::lower::model::OutTy::OutRef>(t_p0).a0;
        return prism_rtl::cat("&", type_f(prism_rtl::deref(prism_rtl::deref(i_pd))));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(t_p0)) {
        auto&& a_pe = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(t_p0).a0;
        auto&& b_pf = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(t_p0).a1;
        return prism_rtl::cat("Rc<dyn Fn(", type_f(prism_rtl::deref(prism_rtl::deref(a_pe))), ") -> Rc<dyn prism_rtl::Job<", type_f(prism_rtl::deref(prism_rtl::deref(b_pf))), ">>>");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutJob>(t_p0)) {
        auto&& b_pg = prism_rtl::as<crate::lower::model::OutTy::OutJob>(t_p0).a0;
        return prism_rtl::cat("Rc<dyn prism_rtl::Job<", type_f(prism_rtl::deref(prism_rtl::deref(b_pg))), ">>");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutEvent>(t_p0)) {
        auto&& i_ph = prism_rtl::as<crate::lower::model::OutTy::OutEvent>(t_p0).a0;
        return prism_rtl::cat("Event<", type_f(prism_rtl::deref(prism_rtl::deref(i_ph))), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutDyn>(t_p0)) {
        auto&& i_pi = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(t_p0).a0;
        return prism_rtl::cat("Dynamic<", type_f(prism_rtl::deref(prism_rtl::deref(i_pi))), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutGen>(t_p0)) {
        auto&& n_pj = prism_rtl::as<crate::lower::model::OutTy::OutGen>(t_p0).a0;
        return n_pj;
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutRc>(t_p0)) {
        auto&& i_pk = prism_rtl::as<crate::lower::model::OutTy::OutRc>(t_p0).a0;
        return prism_rtl::cat("Rc<", type_f(prism_rtl::deref(prism_rtl::deref(i_pk))), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutPod>(t_p0)) {
        return Text::lit("Pod");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutShowAny>(t_p0)) {
        return Text::lit("Rc<dyn Show>");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutHold>(t_p0)) {
        auto&& i_pl = prism_rtl::as<crate::lower::model::OutTy::OutHold>(t_p0).a0;
        return prism_rtl::cat("Hold<", type_f(prism_rtl::deref(prism_rtl::deref(i_pl))), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutStamped>(t_p0)) {
        auto&& i_pm = prism_rtl::as<crate::lower::model::OutTy::OutStamped>(t_p0).a0;
        return prism_rtl::cat("Stamped<", type_f(prism_rtl::deref(prism_rtl::deref(i_pm))), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutSnapshot>(t_p0)) {
        auto&& i_pn = prism_rtl::as<crate::lower::model::OutTy::OutSnapshot>(t_p0).a0;
        return prism_rtl::cat("Snapshot<", type_f(prism_rtl::deref(prism_rtl::deref(i_pn))), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutDefer>(t_p0)) {
        auto&& i_po = prism_rtl::as<crate::lower::model::OutTy::OutDefer>(t_p0).a0;
        return prism_rtl::cat("Defer<", type_f(prism_rtl::deref(prism_rtl::deref(i_po))), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutWeak>(t_p0)) {
        auto&& n_pp = prism_rtl::as<crate::lower::model::OutTy::OutWeak>(t_p0).a0;
        return prism_rtl::cat("Weak<", n_pp, ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutCell>(t_p0)) {
        auto&& i_pq = prism_rtl::as<crate::lower::model::OutTy::OutCell>(t_p0).a0;
        return prism_rtl::cat("RefCell<", type_f(prism_rtl::deref(prism_rtl::deref(i_pq))), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutWakes>(t_p0)) {
        return Text::lit("Wakes");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutCount>(t_p0)) {
        return Text::lit("u32");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutObj>(t_p0)) {
        auto&& i_pr = prism_rtl::as<crate::lower::model::OutTy::OutObj>(t_p0).a0;
        return prism_rtl::cat("Rc<dyn ", type_f(prism_rtl::deref(prism_rtl::deref(i_pr))), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutSlice>(t_p0)) {
        auto&& i_ps = prism_rtl::as<crate::lower::model::OutTy::OutSlice>(t_p0).a0;
        return prism_rtl::cat("[", type_f(prism_rtl::deref(prism_rtl::deref(i_ps))), "]");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutPort>(t_p0)) {
        auto&& i_pt = prism_rtl::as<crate::lower::model::OutTy::OutPort>(t_p0).a0;
        return prism_rtl::cat("Port<", type_f(prism_rtl::deref(prism_rtl::deref(i_pt))), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutLive>(t_p0)) {
        auto&& i_pu = prism_rtl::as<crate::lower::model::OutTy::OutLive>(t_p0).a0;
        return prism_rtl::cat("Live<", type_f(prism_rtl::deref(prism_rtl::deref(i_pu))), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutTurn>(t_p0)) {
        return Text::lit("() /* the job\'s turn */");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutRefused>(t_p0)) {
        auto&& what_pv = prism_rtl::as<crate::lower::model::OutTy::OutRefused>(t_p0).a0;
        return prism_rtl::cat("compile_error!(\"", crate::lower::expr::lowering_refusal_p(), what_pv, "\")");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutQuantified>(t_p0)) {
        auto&& b_p10 = prism_rtl::as<crate::lower::model::OutTy::OutQuantified>(t_p0).a0;
        return prism_rtl::cat("compile_error!(\"", crate::lower::expr::lowering_refusal_p(), "a quantified type variable of `", b_p10, "`: no instantiation gives it a type\")");
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Text> Type::cycle() const {
    const auto& t_p0 = this->t_p0;
    return ({
        prism_rtl::is<crate::lower::model::OutTy::OutNat>(t_p0) ? prism_rtl::finished(Text::lit("Nat"))
        : prism_rtl::is<crate::lower::model::OutTy::OutInt>(t_p0) ? prism_rtl::finished(Text::lit("Int"))
        : prism_rtl::is<crate::lower::model::OutTy::OutU8>(t_p0) ? prism_rtl::finished(Text::lit("u8"))
        : prism_rtl::is<crate::lower::model::OutTy::OutFloat>(t_p0) ? prism_rtl::finished(Text::lit("Float"))
        : prism_rtl::is<crate::lower::model::OutTy::OutBool>(t_p0) ? prism_rtl::finished(Text::lit("bool"))
        : prism_rtl::is<crate::lower::model::OutTy::OutChar>(t_p0) ? prism_rtl::finished(Text::lit("char"))
        : prism_rtl::is<crate::lower::model::OutTy::OutText>(t_p0) ? prism_rtl::finished(Text::lit("Text"))
        : prism_rtl::is<crate::lower::model::OutTy::OutCursor>(t_p0) ? prism_rtl::finished(Text::lit("Cursor"))
        : prism_rtl::is<crate::lower::model::OutTy::OutRegex>(t_p0) ? prism_rtl::finished(Text::lit("Regex"))
        : prism_rtl::is<crate::lower::model::OutTy::OutReplacement>(t_p0) ? prism_rtl::finished(Text::lit("RegexReplacement"))
        : prism_rtl::is<crate::lower::model::OutTy::OutUnit>(t_p0) ? prism_rtl::finished(Text::lit("()"))
        : prism_rtl::is<crate::lower::model::OutTy::OutPath>(t_p0) ? prism_rtl::finished(Text::lit("Path"))
        : prism_rtl::is<crate::lower::model::OutTy::OutDuration>(t_p0) ? prism_rtl::finished(Text::lit("Duration"))
        : prism_rtl::is<crate::lower::model::OutTy::OutError>(t_p0) ? prism_rtl::finished(Text::lit("Error"))
        : prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t_p0) && ({
        auto&& n_p1 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p0).a0;
        auto&& m1596_14_1 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p0).a1;
        (m1596_14_1.size() == 0u);
    }) ? ({
        auto&& n_p1 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p0).a0;
        auto&& m1596_14_1 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p0).a1;
        prism_rtl::finished(n_p1);
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t_p0) ? ({
        auto&& n_p2 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p0).a0;
        auto&& args_p3 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p0).a1;
        ({
        auto args_p3x = args_p3;
        auto n_p2x = n_p2;
        (crate::prelude::call_then(start_types_f(args_p3x), [=, n_p2x = std::move(n_p2x)](Text types_f_1964) { return prism_rtl::finished(prism_rtl::cat(n_p2x, "<", types_f_1964, ">")); }));
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutOpt>(t_p0) ? ({
        auto&& i_p4 = prism_rtl::as<crate::lower::model::OutTy::OutOpt>(t_p0).a0;
        ({
        auto i_p4x = prism_rtl::deref(prism_rtl::deref(i_p4));
        (crate::prelude::call_then(start_type_f(i_p4x), [=](Text type_f_2001) { return prism_rtl::finished(prism_rtl::cat("Option<", type_f_2001, ">")); }));
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutRes>(t_p0) ? ({
        auto&& i_p5 = prism_rtl::as<crate::lower::model::OutTy::OutRes>(t_p0).a0;
        ({
        auto i_p5x = prism_rtl::deref(prism_rtl::deref(i_p5));
        (crate::prelude::call_then(start_type_f(i_p5x), [=](Text type_f_2034) { return prism_rtl::finished(prism_rtl::cat("Result<", type_f_2034, ", Error>")); }));
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutTuple>(t_p0) && ({
        auto&& m1596_18_0 = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(t_p0).a0;
        (m1596_18_0.size() == 1u) && ({
        auto&& _c1 = crate::prelude::index(m1596_18_0, Nat(0u));
        prism_rtl::is_some(_c1);
    });
    }) ? ({
        auto&& m1596_18_0 = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(t_p0).a0;
        auto&& _c1 = crate::prelude::index(m1596_18_0, Nat(0u));
        auto&& one_p6 = prism_rtl::some_of(_c1);
        crate::prelude::call_then(start_type_f(one_p6), [=](Text type_f_2076) { return prism_rtl::finished(prism_rtl::cat("(", type_f_2076, ",)")); });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutTuple>(t_p0) ? ({
        auto&& ts_p7 = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(t_p0).a0;
        ({
        auto ts_p7x = ts_p7;
        (crate::prelude::call_then(start_types_f(ts_p7x), [=](Text types_f_2109) { return prism_rtl::finished(prism_rtl::cat("(", types_f_2109, ")")); }));
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutArray>(t_p0) ? ({
        auto&& e_p8 = prism_rtl::as<crate::lower::model::OutTy::OutArray>(t_p0).a0;
        ({
        auto e_p8x = prism_rtl::deref(prism_rtl::deref(e_p8));
        (crate::prelude::call_then(start_type_f(e_p8x), [=](Text type_f_2145) { return prism_rtl::finished(prism_rtl::cat("Array<", type_f_2145, ">")); }));
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutMap>(t_p0) ? ({
        auto&& k_p9 = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t_p0).a0;
        auto&& v_pa = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t_p0).a1;
        ({
        auto k_p9x = prism_rtl::deref(prism_rtl::deref(k_p9));
        auto v_pax = prism_rtl::deref(prism_rtl::deref(v_pa));
        (crate::prelude::call_then(start_type_f(k_p9x), [=, v_pax = std::move(v_pax)](Text type_f_2178) { return crate::prelude::call_then(start_type_f(v_pax), [=](Text type_f_2188) { return prism_rtl::finished(prism_rtl::cat("Map<", type_f_2178, ", ", type_f_2188, ">")); }); }));
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutFn>(t_p0) ? ({
        auto&& ps_pb = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t_p0).a0;
        auto&& r_pc = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t_p0).a1;
        ({
        auto ps_pbx = ps_pb;
        auto r_pcx = prism_rtl::deref(prism_rtl::deref(r_pc));
        (crate::prelude::call_then(start_ref_types_f(ps_pbx), [=, r_pcx = std::move(r_pcx)](Text ref_types_f_2227) { return crate::prelude::call_then(start_type_f(r_pcx), [=](Text type_f_2245) { return prism_rtl::finished(prism_rtl::cat("Rc<dyn Fn(", ref_types_f_2227, ") -> ", type_f_2245, ">")); }); }));
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutRef>(t_p0) ? ({
        auto&& i_pd = prism_rtl::as<crate::lower::model::OutTy::OutRef>(t_p0).a0;
        ({
        auto i_pdx = prism_rtl::deref(prism_rtl::deref(i_pd));
        (crate::prelude::call_then(start_type_f(i_pdx), [=](Text type_f_2272) { return prism_rtl::finished(prism_rtl::cat("&", type_f_2272)); }));
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(t_p0) ? ({
        auto&& a_pe = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(t_p0).a0;
        auto&& b_pf = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(t_p0).a1;
        ({
        auto a_pex = prism_rtl::deref(prism_rtl::deref(a_pe));
        auto b_pfx = prism_rtl::deref(prism_rtl::deref(b_pf));
        (crate::prelude::call_then(start_type_f(a_pex), [=, b_pfx = std::move(b_pfx)](Text type_f_2312) { return crate::prelude::call_then(start_type_f(b_pfx), [=](Text type_f_2347) { return prism_rtl::finished(prism_rtl::cat("Rc<dyn Fn(", type_f_2312, ") -> Rc<dyn prism_rtl::Job<", type_f_2347, ">>>")); }); }));
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutJob>(t_p0) ? ({
        auto&& b_pg = prism_rtl::as<crate::lower::model::OutTy::OutJob>(t_p0).a0;
        ({
        auto b_pgx = prism_rtl::deref(prism_rtl::deref(b_pg));
        (crate::prelude::call_then(start_type_f(b_pgx), [=](Text type_f_2397) { return prism_rtl::finished(prism_rtl::cat("Rc<dyn prism_rtl::Job<", type_f_2397, ">>")); }));
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutEvent>(t_p0) ? ({
        auto&& i_ph = prism_rtl::as<crate::lower::model::OutTy::OutEvent>(t_p0).a0;
        ({
        auto i_phx = prism_rtl::deref(prism_rtl::deref(i_ph));
        (crate::prelude::call_then(start_type_f(i_phx), [=](Text type_f_2432) { return prism_rtl::finished(prism_rtl::cat("Event<", type_f_2432, ">")); }));
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutDyn>(t_p0) ? ({
        auto&& i_pi = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(t_p0).a0;
        ({
        auto i_pix = prism_rtl::deref(prism_rtl::deref(i_pi));
        (crate::prelude::call_then(start_type_f(i_pix), [=](Text type_f_2466) { return prism_rtl::finished(prism_rtl::cat("Dynamic<", type_f_2466, ">")); }));
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutGen>(t_p0) ? ({
        auto&& n_pj = prism_rtl::as<crate::lower::model::OutTy::OutGen>(t_p0).a0;
        prism_rtl::finished(n_pj);
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutRc>(t_p0) ? ({
        auto&& i_pk = prism_rtl::as<crate::lower::model::OutTy::OutRc>(t_p0).a0;
        ({
        auto i_pkx = prism_rtl::deref(prism_rtl::deref(i_pk));
        (crate::prelude::call_then(start_type_f(i_pkx), [=](Text type_f_2510) { return prism_rtl::finished(prism_rtl::cat("Rc<", type_f_2510, ">")); }));
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutPod>(t_p0) ? prism_rtl::finished(Text::lit("Pod"))
        : prism_rtl::is<crate::lower::model::OutTy::OutShowAny>(t_p0) ? prism_rtl::finished(Text::lit("Rc<dyn Show>"))
        : prism_rtl::is<crate::lower::model::OutTy::OutHold>(t_p0) ? ({
        auto&& i_pl = prism_rtl::as<crate::lower::model::OutTy::OutHold>(t_p0).a0;
        ({
        auto i_plx = prism_rtl::deref(prism_rtl::deref(i_pl));
        (crate::prelude::call_then(start_type_f(i_plx), [=](Text type_f_2591) { return prism_rtl::finished(prism_rtl::cat("Hold<", type_f_2591, ">")); }));
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutStamped>(t_p0) ? ({
        auto&& i_pm = prism_rtl::as<crate::lower::model::OutTy::OutStamped>(t_p0).a0;
        ({
        auto i_pmx = prism_rtl::deref(prism_rtl::deref(i_pm));
        (crate::prelude::call_then(start_type_f(i_pmx), [=](Text type_f_2629) { return prism_rtl::finished(prism_rtl::cat("Stamped<", type_f_2629, ">")); }));
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutSnapshot>(t_p0) ? ({
        auto&& i_pn = prism_rtl::as<crate::lower::model::OutTy::OutSnapshot>(t_p0).a0;
        ({
        auto i_pnx = prism_rtl::deref(prism_rtl::deref(i_pn));
        (crate::prelude::call_then(start_type_f(i_pnx), [=](Text type_f_2669) { return prism_rtl::finished(prism_rtl::cat("Snapshot<", type_f_2669, ">")); }));
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutDefer>(t_p0) ? ({
        auto&& i_po = prism_rtl::as<crate::lower::model::OutTy::OutDefer>(t_p0).a0;
        ({
        auto i_pox = prism_rtl::deref(prism_rtl::deref(i_po));
        (crate::prelude::call_then(start_type_f(i_pox), [=](Text type_f_2703) { return prism_rtl::finished(prism_rtl::cat("Defer<", type_f_2703, ">")); }));
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutWeak>(t_p0) ? ({
        auto&& n_pp = prism_rtl::as<crate::lower::model::OutTy::OutWeak>(t_p0).a0;
        prism_rtl::finished(prism_rtl::cat("Weak<", n_pp, ">"));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutCell>(t_p0) ? ({
        auto&& i_pq = prism_rtl::as<crate::lower::model::OutTy::OutCell>(t_p0).a0;
        ({
        auto i_pqx = prism_rtl::deref(prism_rtl::deref(i_pq));
        (crate::prelude::call_then(start_type_f(i_pqx), [=](Text type_f_2765) { return prism_rtl::finished(prism_rtl::cat("RefCell<", type_f_2765, ">")); }));
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutWakes>(t_p0) ? prism_rtl::finished(Text::lit("Wakes"))
        : prism_rtl::is<crate::lower::model::OutTy::OutCount>(t_p0) ? prism_rtl::finished(Text::lit("u32"))
        : prism_rtl::is<crate::lower::model::OutTy::OutObj>(t_p0) ? ({
        auto&& i_pr = prism_rtl::as<crate::lower::model::OutTy::OutObj>(t_p0).a0;
        ({
        auto i_prx = prism_rtl::deref(prism_rtl::deref(i_pr));
        (crate::prelude::call_then(start_type_f(i_prx), [=](Text type_f_2840) { return prism_rtl::finished(prism_rtl::cat("Rc<dyn ", type_f_2840, ">")); }));
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutSlice>(t_p0) ? ({
        auto&& i_ps = prism_rtl::as<crate::lower::model::OutTy::OutSlice>(t_p0).a0;
        ({
        auto i_psx = prism_rtl::deref(prism_rtl::deref(i_ps));
        (crate::prelude::call_then(start_type_f(i_psx), [=](Text type_f_2869) { return prism_rtl::finished(prism_rtl::cat("[", type_f_2869, "]")); }));
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutPort>(t_p0) ? ({
        auto&& i_pt = prism_rtl::as<crate::lower::model::OutTy::OutPort>(t_p0).a0;
        ({
        auto i_ptx = prism_rtl::deref(prism_rtl::deref(i_pt));
        (crate::prelude::call_then(start_type_f(i_ptx), [=](Text type_f_2901) { return prism_rtl::finished(prism_rtl::cat("Port<", type_f_2901, ">")); }));
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutLive>(t_p0) ? ({
        auto&& i_pu = prism_rtl::as<crate::lower::model::OutTy::OutLive>(t_p0).a0;
        ({
        auto i_pux = prism_rtl::deref(prism_rtl::deref(i_pu));
        (crate::prelude::call_then(start_type_f(i_pux), [=](Text type_f_2933) { return prism_rtl::finished(prism_rtl::cat("Live<", type_f_2933, ">")); }));
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutTurn>(t_p0) ? prism_rtl::finished(Text::lit("() /* the job\'s turn */"))
        : prism_rtl::is<crate::lower::model::OutTy::OutRefused>(t_p0) ? ({
        auto&& what_pv = prism_rtl::as<crate::lower::model::OutTy::OutRefused>(t_p0).a0;
        prism_rtl::finished(prism_rtl::cat("compile_error!(\"", crate::lower::expr::lowering_refusal_p(), what_pv, "\")"));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutQuantified>(t_p0) ? ({
        auto&& b_p10 = prism_rtl::as<crate::lower::model::OutTy::OutQuantified>(t_p0).a0;
        prism_rtl::finished(prism_rtl::cat("compile_error!(\"", crate::lower::expr::lowering_refusal_p(), "a quantified type variable of `", b_p10, "`: no instantiation gives it a type\")"));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start Type, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_type_f(crate::lower::model::OutTy t_p0) {
    return prism_rtl::make_rc<Type>(t_p0);
}


/// Types: unbounded fn [OutTy] -> Text
Text types_f(const Array<crate::lower::model::OutTy>& ts_p0) {
    return crate::syntax::lexer::chars::join_f(crate::prelude::run_to_end(crate::prelude::each_job(ts_p0, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::OutTy)>>(prism_rtl::rc([=](crate::lower::model::OutTy p0) {
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto t_p1 = p0;
                (prism_rtl::more(prism_rtl::rc(Type(t_p1))));
            });
        }));
    })))), Text::lit(", "));
}


prism_rtl::Turn<Text> Types::cycle() const {
    const auto& ts_p0 = this->ts_p0;
    auto ts_p0x = ts_p0;
    return crate::prelude::call_value(crate::prelude::each_job(ts_p0x, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::OutTy)>>(prism_rtl::rc([=](crate::lower::model::OutTy p0) {
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto t_p1 = p0;
                (prism_rtl::more(prism_rtl::rc(Type(t_p1))));
            });
        }));
    }))), [=](Array<Text> each_3236) { return prism_rtl::finished(crate::syntax::lexer::chars::join_f(each_3236, Text::lit(", "))); });
}


/// `Start Types, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_types_f(Array<crate::lower::model::OutTy> ts_p0) {
    return prism_rtl::make_rc<Types>(ts_p0);
}


/// RefTypes: unbounded fn [OutTy] -> Text
Text ref_types_f(const Array<crate::lower::model::OutTy>& ts_p0) {
    return crate::syntax::lexer::chars::join_f(crate::prelude::run_to_end(crate::prelude::each_job(ts_p0, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::OutTy)>>(prism_rtl::rc([=](crate::lower::model::OutTy p0) {
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto t_p1 = p0;
                (crate::prelude::call_then(start_type_f(t_p1), [=](Text type_f_3344) { return prism_rtl::finished(prism_rtl::cat("&", type_f_3344)); }));
            });
        }));
    })))), Text::lit(", "));
}


prism_rtl::Turn<Text> RefTypes::cycle() const {
    const auto& ts_p0 = this->ts_p0;
    auto ts_p0x = ts_p0;
    return crate::prelude::call_value(crate::prelude::each_job(ts_p0x, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::OutTy)>>(prism_rtl::rc([=](crate::lower::model::OutTy p0) {
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto t_p1 = p0;
                (crate::prelude::call_then(start_type_f(t_p1), [=](Text type_f_3344) { return prism_rtl::finished(prism_rtl::cat("&", type_f_3344)); }));
            });
        }));
    }))), [=](Array<Text> each_3327) { return prism_rtl::finished(crate::syntax::lexer::chars::join_f(each_3327, Text::lit(", "))); });
}


/// `Start RefTypes, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_ref_types_f(Array<crate::lower::model::OutTy> ts_p0) {
    return prism_rtl::make_rc<RefTypes>(ts_p0);
}


/// IsLoose: fn Ex -> Bool
bool is_loose_f(const crate::lower::model::Ex& x_p0) {
    if (prism_rtl::is<crate::lower::model::Ex::XBlock>(x_p0)) {
        auto&& m3669_0_0 = prism_rtl::as<crate::lower::model::Ex::XBlock>(x_p0).a0;
        auto&& inner_p1 = prism_rtl::as<crate::lower::model::Ex::XBlock>(x_p0).a1;
        if (m3669_0_0.size() == 0u) {
            return is_loose_f(prism_rtl::deref(prism_rtl::deref(inner_p1)));
        }
    }
    if (prism_rtl::is<crate::lower::model::Ex::XTyped>(x_p0)) {
        auto&& inner_p2 = prism_rtl::as<crate::lower::model::Ex::XTyped>(x_p0).a0;
        return is_loose_f(prism_rtl::deref(prism_rtl::deref(inner_p2)));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XBin>(x_p0)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XUnary>(x_p0)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XClosure>(x_p0)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XIf>(x_p0)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XMatch>(x_p0)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XChain>(x_p0)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XCast>(x_p0)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XRef>(x_p0)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XRefMut>(x_p0)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XDeref>(x_p0)) {
        return true;
    }
    {
        return false;
    }
}


/// Tight: unbounded fn Ex -> Text
Text tight_f(const crate::lower::model::Ex& x_p0) {
    return is_loose_f(x_p0)
        ? prism_rtl::cat("(", expression_f(x_p0), ")")
        : expression_f(x_p0);
}


prism_rtl::Turn<Text> Tight::cycle() const {
    const auto& x_p0 = this->x_p0;
    return is_loose_f(x_p0)
        ? ({
        auto x_p0x = x_p0;
        (crate::prelude::call_then(start_expression_f(x_p0x), [=](Text expression_f_4186) { return prism_rtl::finished(prism_rtl::cat("(", expression_f_4186, ")")); }));
    })
        : prism_rtl::more(prism_rtl::rc(Expression(x_p0)));
}


/// `Start Tight, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_tight_f(crate::lower::model::Ex x_p0) {
    return prism_rtl::make_rc<Tight>(x_p0);
}


/// Operand: unbounded fn Ex -> Text
Text operand_f(const crate::lower::model::Ex& x_p0) {
    if (prism_rtl::is<crate::lower::model::Ex::XBlock>(x_p0)) {
        auto&& m4270_0_0 = prism_rtl::as<crate::lower::model::Ex::XBlock>(x_p0).a0;
        auto&& inner_p1 = prism_rtl::as<crate::lower::model::Ex::XBlock>(x_p0).a1;
        if (m4270_0_0.size() == 0u) {
            return operand_f(prism_rtl::deref(prism_rtl::deref(inner_p1)));
        }
    }
    if (prism_rtl::is<crate::lower::model::Ex::XTyped>(x_p0)) {
        auto&& inner_p2 = prism_rtl::as<crate::lower::model::Ex::XTyped>(x_p0).a0;
        return operand_f(prism_rtl::deref(prism_rtl::deref(inner_p2)));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XBin>(x_p0)) {
        return prism_rtl::cat("(", expression_f(x_p0), ")");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XClosure>(x_p0)) {
        return prism_rtl::cat("(", expression_f(x_p0), ")");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XIf>(x_p0)) {
        return prism_rtl::cat("(", expression_f(x_p0), ")");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XCast>(x_p0)) {
        return prism_rtl::cat("(", expression_f(x_p0), ")");
    }
    {
        return expression_f(x_p0);
    }
}


prism_rtl::Turn<Text> Operand::cycle() const {
    const auto& x_p0 = this->x_p0;
    return ({
        prism_rtl::is<crate::lower::model::Ex::XBlock>(x_p0) && ({
        auto&& m4270_0_0 = prism_rtl::as<crate::lower::model::Ex::XBlock>(x_p0).a0;
        auto&& inner_p1 = prism_rtl::as<crate::lower::model::Ex::XBlock>(x_p0).a1;
        (m4270_0_0.size() == 0u);
    }) ? ({
        auto&& m4270_0_0 = prism_rtl::as<crate::lower::model::Ex::XBlock>(x_p0).a0;
        auto&& inner_p1 = prism_rtl::as<crate::lower::model::Ex::XBlock>(x_p0).a1;
        prism_rtl::more(prism_rtl::rc(Operand(prism_rtl::deref(prism_rtl::deref(inner_p1)))));
    })
        : prism_rtl::is<crate::lower::model::Ex::XTyped>(x_p0) ? ({
        auto&& inner_p2 = prism_rtl::as<crate::lower::model::Ex::XTyped>(x_p0).a0;
        prism_rtl::more(prism_rtl::rc(Operand(prism_rtl::deref(prism_rtl::deref(inner_p2)))));
    })
        : prism_rtl::is<crate::lower::model::Ex::XBin>(x_p0) ? ({
        auto x_p0x = x_p0;
        (crate::prelude::call_then(start_expression_f(x_p0x), [=](Text expression_f_4393) { return prism_rtl::finished(prism_rtl::cat("(", expression_f_4393, ")")); }));
    })
        : prism_rtl::is<crate::lower::model::Ex::XClosure>(x_p0) ? ({
        auto x_p0x = x_p0;
        (crate::prelude::call_then(start_expression_f(x_p0x), [=](Text expression_f_4449) { return prism_rtl::finished(prism_rtl::cat("(", expression_f_4449, ")")); }));
    })
        : prism_rtl::is<crate::lower::model::Ex::XIf>(x_p0) ? ({
        auto x_p0x = x_p0;
        (crate::prelude::call_then(start_expression_f(x_p0x), [=](Text expression_f_4500) { return prism_rtl::finished(prism_rtl::cat("(", expression_f_4500, ")")); }));
    })
        : prism_rtl::is<crate::lower::model::Ex::XCast>(x_p0) ? ({
        auto x_p0x = x_p0;
        (crate::prelude::call_then(start_expression_f(x_p0x), [=](Text expression_f_4545) { return prism_rtl::finished(prism_rtl::cat("(", expression_f_4545, ")")); }));
    })
        : prism_rtl::more(prism_rtl::rc(Expression(x_p0)));
    });
}


/// `Start Operand, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_operand_f(crate::lower::model::Ex x_p0) {
    return prism_rtl::make_rc<Operand>(x_p0);
}


/// Args: unbounded fn [Ex] -> Text
Text args_f(const Array<crate::lower::model::Ex>& xs_p0) {
    return crate::syntax::lexer::chars::join_f(crate::prelude::run_to_end(crate::prelude::each_job(xs_p0, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Ex)>>(prism_rtl::rc([=](crate::lower::model::Ex p0) {
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto x_p1 = p0;
                (prism_rtl::more(prism_rtl::rc(Expression(x_p1))));
            });
        }));
    })))), Text::lit(", "));
}


prism_rtl::Turn<Text> Args::cycle() const {
    const auto& xs_p0 = this->xs_p0;
    auto xs_p0x = xs_p0;
    return crate::prelude::call_value(crate::prelude::each_job(xs_p0x, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Ex)>>(prism_rtl::rc([=](crate::lower::model::Ex p0) {
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto x_p1 = p0;
                (prism_rtl::more(prism_rtl::rc(Expression(x_p1))));
            });
        }));
    }))), [=](Array<Text> each_4641) { return prism_rtl::finished(crate::syntax::lexer::chars::join_f(each_4641, Text::lit(", "))); });
}


/// `Start Args, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_args_f(Array<crate::lower::model::Ex> xs_p0) {
    return prism_rtl::make_rc<Args>(xs_p0);
}


/// Expression: unbounded fn Ex -> Text
Text expression_f(const crate::lower::model::Ex& x_p0) {
    if (prism_rtl::is<crate::lower::model::Ex::XVar>(x_p0)) {
        auto&& n_p1 = prism_rtl::as<crate::lower::model::Ex::XVar>(x_p0).a0;
        return n_p1;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XPath>(x_p0)) {
        auto&& p_p2 = prism_rtl::as<crate::lower::model::Ex::XPath>(x_p0).a0;
        return p_p2;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XSelf>(x_p0)) {
        return Text::lit("self");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XCx>(x_p0)) {
        return Text::lit("cx");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XConst>(x_p0)) {
        auto&& n_p3 = prism_rtl::as<crate::lower::model::Ex::XConst>(x_p0).a0;
        return prism_rtl::cat("Self::", n_p3);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XUnit>(x_p0)) {
        return Text::lit("()");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XNone>(x_p0)) {
        return Text::lit("None");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XBool>(x_p0)) {
        auto&& b_p4 = prism_rtl::as<crate::lower::model::Ex::XBool>(x_p0).a0;
        return prism_rtl::deref(b_p4) ? Text::lit("true") : Text::lit("false");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XNat>(x_p0)) {
        auto&& d_p5 = prism_rtl::as<crate::lower::model::Ex::XNat>(x_p0).a0;
        return crate::prelude::len_text(d_p5) <= Nat(9u)
            ? prism_rtl::cat("Nat::from(", d_p5, "u32)")
            : crate::prelude::len_text(d_p5) <= Nat(18u)
            ? prism_rtl::cat("Nat::from_int(Int::from(", d_p5, "i64)).unwrap()")
            : prism_rtl::cat("Nat::from_int(Int::parse(\"", d_p5, "\").unwrap()).unwrap()");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XInt>(x_p0)) {
        auto&& d_p6 = prism_rtl::as<crate::lower::model::Ex::XInt>(x_p0).a0;
        return crate::prelude::len_text(crate::syntax::lexer::chars::has_prefix_f(d_p6, Text::lit("-"))
            ? crate::syntax::lexer::chars::after_first_f(d_p6)
            : d_p6) <= Nat(18u)
            ? prism_rtl::cat("Int::from(", d_p6, ")")
            : prism_rtl::cat("Int::parse(\"", d_p6, "\").unwrap()");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XByte>(x_p0)) {
        auto&& d_p7 = prism_rtl::as<crate::lower::model::Ex::XByte>(x_p0).a0;
        return prism_rtl::cat(d_p7, "u8");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XFloat>(x_p0)) {
        auto&& d_p8 = prism_rtl::as<crate::lower::model::Ex::XFloat>(x_p0).a0;
        return prism_rtl::cat("Float(", d_p8, ")");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XIndex>(x_p0)) {
        auto&& n_p9 = prism_rtl::as<crate::lower::model::Ex::XIndex>(x_p0).a0;
        return prism_rtl::cat(n_p9);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XChar>(x_p0)) {
        auto&& c_pa = prism_rtl::as<crate::lower::model::Ex::XChar>(x_p0).a0;
        return prism_rtl::cat("\'", crate::lower::expr::char_escape_f(c_pa), "\'");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XStr>(x_p0)) {
        auto&& t_pb = prism_rtl::as<crate::lower::model::Ex::XStr>(x_p0).a0;
        return prism_rtl::cat("\"", crate::lower::expr::escape_f(t_pb), "\"");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XRegex>(x_p0)) {
        auto&& p_pc = prism_rtl::as<crate::lower::model::Ex::XRegex>(x_p0).a0;
        auto&& f_pd = prism_rtl::as<crate::lower::model::Ex::XRegex>(x_p0).a1;
        return prism_rtl::cat("{ thread_local!(static R: Regex = Regex::lit(\"", crate::lower::expr::escape_f(p_pc), "\", \"", crate::lower::expr::escape_f(f_pd), "\")); R.with(Regex::clone) }");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XReplacement>(x_p0)) {
        auto&& p_pe = prism_rtl::as<crate::lower::model::Ex::XReplacement>(x_p0).a0;
        auto&& r_pf = prism_rtl::as<crate::lower::model::Ex::XReplacement>(x_p0).a1;
        auto&& f_pg = prism_rtl::as<crate::lower::model::Ex::XReplacement>(x_p0).a2;
        return prism_rtl::cat("{ thread_local!(static R: RegexReplacement = RegexReplacement::lit(\"", crate::lower::expr::escape_f(p_pe), "\", \"", crate::lower::expr::escape_f(f_pg), "\", \"", crate::lower::expr::escape_f(r_pf), "\")); R.with(RegexReplacement::clone) }");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XRef>(x_p0)) {
        auto&& y_ph = prism_rtl::as<crate::lower::model::Ex::XRef>(x_p0).a0;
        return prism_rtl::cat("&", operand_f(prism_rtl::deref(prism_rtl::deref(y_ph))));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XRefMut>(x_p0)) {
        auto&& y_pi = prism_rtl::as<crate::lower::model::Ex::XRefMut>(x_p0).a0;
        return prism_rtl::cat("&mut ", operand_f(prism_rtl::deref(prism_rtl::deref(y_pi))));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XDeref>(x_p0)) {
        auto&& y_pj = prism_rtl::as<crate::lower::model::Ex::XDeref>(x_p0).a0;
        return prism_rtl::cat("*", operand_f(prism_rtl::deref(prism_rtl::deref(y_pj))));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XTarget>(x_p0)) {
        auto&& y_pk = prism_rtl::as<crate::lower::model::Ex::XTarget>(x_p0).a0;
        return prism_rtl::cat("(*", expression_f(prism_rtl::deref(prism_rtl::deref(y_pk))), ")");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XClone>(x_p0)) {
        auto&& y_pl = prism_rtl::as<crate::lower::model::Ex::XClone>(x_p0).a0;
        return prism_rtl::cat(tight_f(prism_rtl::deref(prism_rtl::deref(y_pl))), ".clone()");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XWeak>(x_p0)) {
        auto&& y_pm = prism_rtl::as<crate::lower::model::Ex::XWeak>(x_p0).a0;
        return prism_rtl::cat("Rc::downgrade(", expression_f(prism_rtl::deref(prism_rtl::deref(y_pm))), ")");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XUpgrade>(x_p0)) {
        auto&& y_pn = prism_rtl::as<crate::lower::model::Ex::XUpgrade>(x_p0).a0;
        return prism_rtl::cat(tight_f(prism_rtl::deref(prism_rtl::deref(y_pn))), ".upgrade()");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XBreak>(x_p0)) {
        auto&& l_po = prism_rtl::as<crate::lower::model::Ex::XBreak>(x_p0).a0;
        auto&& y_pp = prism_rtl::as<crate::lower::model::Ex::XBreak>(x_p0).a1;
        return prism_rtl::cat("break ", label_f(l_po), " ", expression_f(prism_rtl::deref(prism_rtl::deref(y_pp))));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XBreakLoop>(x_p0)) {
        return Text::lit("break");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XLater>(x_p0)) {
        auto&& y_pq = prism_rtl::as<crate::lower::model::Ex::XLater>(x_p0).a0;
        return prism_rtl::cat("Box::new(move |cx| { ", expression_f(prism_rtl::deref(prism_rtl::deref(y_pq))), "; Ok(()) })");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XFormatStr>(x_p0)) {
        auto&& parts_pr = prism_rtl::as<crate::lower::model::Ex::XFormatStr>(x_p0).a0;
        return format_str_f(parts_pr);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XIsCase>(x_p0)) {
        auto&& y_ps = prism_rtl::as<crate::lower::model::Ex::XIsCase>(x_p0).a0;
        auto&& m4730_28_1 = prism_rtl::as<crate::lower::model::Ex::XIsCase>(x_p0).a1;
        if (m4730_28_1.size() == 0u) {
            return Text::lit("false");
        }
    }
    if (prism_rtl::is<crate::lower::model::Ex::XIsCase>(x_p0)) {
        auto&& y_pt = prism_rtl::as<crate::lower::model::Ex::XIsCase>(x_p0).a0;
        auto&& cs_pu = prism_rtl::as<crate::lower::model::Ex::XIsCase>(x_p0).a1;
        return prism_rtl::cat("matches!(", expression_f(prism_rtl::deref(prism_rtl::deref(y_pt))), ", ", crate::syntax::lexer::chars::join_f(crate::prelude::each(cs_pu, [&](const Text& c_pv) { return prism_rtl::cat(c_pv, "(..)"); }), Text::lit(" | ")), ")");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XRefusal>(x_p0)) {
        auto&& what_p10 = prism_rtl::as<crate::lower::model::Ex::XRefusal>(x_p0).a0;
        return prism_rtl::cat("compile_error!(\"", crate::lower::expr::lowering_refusal_p(), crate::lower::expr::escape_f(what_p10), "\")");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XUnreachable>(x_p0)) {
        return Text::lit("unreachable!()");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XCall>(x_p0)) {
        auto&& f_p11 = prism_rtl::as<crate::lower::model::Ex::XCall>(x_p0).a0;
        auto&& args_p12 = prism_rtl::as<crate::lower::model::Ex::XCall>(x_p0).a1;
        return prism_rtl::cat(f_p11, "(", args_f(args_p12), ")");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XApply>(x_p0)) {
        auto&& f_p13 = prism_rtl::as<crate::lower::model::Ex::XApply>(x_p0).a0;
        auto&& args_p14 = prism_rtl::as<crate::lower::model::Ex::XApply>(x_p0).a1;
        return prism_rtl::cat(tight_f(prism_rtl::deref(prism_rtl::deref(f_p13))), "(", args_f(args_p14), ")");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XMethod>(x_p0)) {
        auto&& r_p15 = prism_rtl::as<crate::lower::model::Ex::XMethod>(x_p0).a0;
        auto&& m_p16 = prism_rtl::as<crate::lower::model::Ex::XMethod>(x_p0).a1;
        auto&& args_p17 = prism_rtl::as<crate::lower::model::Ex::XMethod>(x_p0).a2;
        return prism_rtl::cat(tight_f(prism_rtl::deref(prism_rtl::deref(r_p15))), ".", m_p16, "(", args_f(args_p17), ")");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XBin>(x_p0)) {
        auto&& op_p18 = prism_rtl::as<crate::lower::model::Ex::XBin>(x_p0).a0;
        auto&& l_p19 = prism_rtl::as<crate::lower::model::Ex::XBin>(x_p0).a1;
        auto&& r_p1a = prism_rtl::as<crate::lower::model::Ex::XBin>(x_p0).a2;
        return prism_rtl::cat(operand_f(prism_rtl::deref(prism_rtl::deref(l_p19))), " ", crate::lower::model::bin_op_text_f(op_p18), " ", operand_f(prism_rtl::deref(prism_rtl::deref(r_p1a))));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XUnary>(x_p0)) {
        auto&& op_p1b = prism_rtl::as<crate::lower::model::Ex::XUnary>(x_p0).a0;
        auto&& y_p1c = prism_rtl::as<crate::lower::model::Ex::XUnary>(x_p0).a1;
        return prism_rtl::cat(crate::lower::model::un_op_text_f(op_p1b), operand_f(prism_rtl::deref(prism_rtl::deref(y_p1c))));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XCtor>(x_p0)) {
        auto&& p_p1d = prism_rtl::as<crate::lower::model::Ex::XCtor>(x_p0).a0;
        auto&& args_p1e = prism_rtl::as<crate::lower::model::Ex::XCtor>(x_p0).a1;
        return prism_rtl::cat(p_p1d, "(", args_f(args_p1e), ")");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XRecord>(x_p0)) {
        auto&& p_p1f = prism_rtl::as<crate::lower::model::Ex::XRecord>(x_p0).a0;
        auto&& fs_p1g = prism_rtl::as<crate::lower::model::Ex::XRecord>(x_p0).a1;
        return prism_rtl::cat(p_p1f, " { ", crate::syntax::lexer::chars::join_f(crate::prelude::run_to_end(crate::prelude::each_job(fs_p1g, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::Ex>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::Ex> p0) {
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto [f_p1h, v_p1i] = p0;
                    (prism_rtl::more(prism_rtl::rc(FieldInit(f_p1h, v_p1i))));
                });
            }));
        })))), Text::lit(", ")), " }");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XTuple>(x_p0)) {
        auto&& m4730_39_0 = prism_rtl::as<crate::lower::model::Ex::XTuple>(x_p0).a0;
        if (m4730_39_0.size() == 1u) {
            {
                auto&& _c1 = crate::prelude::index(m4730_39_0, Nat(0u));
                if (prism_rtl::is_some(_c1)) {
                    auto&& one_p1j = prism_rtl::some_of(_c1);
                    return prism_rtl::cat("(", expression_f(one_p1j), ",)");
                }
            }
        }
    }
    if (prism_rtl::is<crate::lower::model::Ex::XTuple>(x_p0)) {
        auto&& xs_p1k = prism_rtl::as<crate::lower::model::Ex::XTuple>(x_p0).a0;
        return prism_rtl::cat("(", args_f(xs_p1k), ")");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XVec>(x_p0)) {
        auto&& xs_p1l = prism_rtl::as<crate::lower::model::Ex::XVec>(x_p0).a0;
        return prism_rtl::cat("vec![", args_f(xs_p1l), "]");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XText>(x_p0)) {
        auto&& t_p1m = prism_rtl::as<crate::lower::model::Ex::XText>(x_p0).a0;
        return prism_rtl::cat("Text::lit(\"", crate::lower::expr::escape_f(t_p1m), "\")");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XFormat>(x_p0)) {
        auto&& parts_p1n = prism_rtl::as<crate::lower::model::Ex::XFormat>(x_p0).a0;
        return format_f(parts_p1n);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XMatch>(x_p0)) {
        auto&& s_p1o = prism_rtl::as<crate::lower::model::Ex::XMatch>(x_p0).a0;
        auto&& arms_p1p = prism_rtl::as<crate::lower::model::Ex::XMatch>(x_p0).a1;
        auto&& fallback_p1q = prism_rtl::as<crate::lower::model::Ex::XMatch>(x_p0).a2;
        return crate::emit::rust::templates::items::match_block_f(expression_f(prism_rtl::deref(prism_rtl::deref(s_p1o))), arms_f(arms_p1p, fallback_p1q));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XChain>(x_p0)) {
        auto&& label_p1r = prism_rtl::as<crate::lower::model::Ex::XChain>(x_p0).a0;
        auto&& s_p1s = prism_rtl::as<crate::lower::model::Ex::XChain>(x_p0).a1;
        auto&& arms_p1t = prism_rtl::as<crate::lower::model::Ex::XChain>(x_p0).a2;
        return chain_f(label_f(label_p1r), prism_rtl::deref(prism_rtl::deref(s_p1s)), arms_p1t);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XIf>(x_p0)) {
        auto&& c_p1u = prism_rtl::as<crate::lower::model::Ex::XIf>(x_p0).a0;
        auto&& t_p1v = prism_rtl::as<crate::lower::model::Ex::XIf>(x_p0).a1;
        auto&& e_p20 = prism_rtl::as<crate::lower::model::Ex::XIf>(x_p0).a2;
        return if_expression_f(prism_rtl::deref(prism_rtl::deref(c_p1u)), prism_rtl::deref(prism_rtl::deref(t_p1v)), prism_rtl::deref(prism_rtl::deref(e_p20)));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XBlock>(x_p0)) {
        auto&& m4730_47_0 = prism_rtl::as<crate::lower::model::Ex::XBlock>(x_p0).a0;
        auto&& e_p21 = prism_rtl::as<crate::lower::model::Ex::XBlock>(x_p0).a1;
        if (m4730_47_0.size() == 0u) {
            return expression_f(prism_rtl::deref(prism_rtl::deref(e_p21)));
        }
    }
    if (prism_rtl::is<crate::lower::model::Ex::XBlock>(x_p0)) {
        auto&& dos_p22 = prism_rtl::as<crate::lower::model::Ex::XBlock>(x_p0).a0;
        auto&& e_p23 = prism_rtl::as<crate::lower::model::Ex::XBlock>(x_p0).a1;
        return crate::emit::rust::templates::items::block_f(statements_f(dos_p22), expression_f(prism_rtl::deref(prism_rtl::deref(e_p23))));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XLabeled>(x_p0)) {
        auto&& label_p24 = prism_rtl::as<crate::lower::model::Ex::XLabeled>(x_p0).a0;
        auto&& dos_p25 = prism_rtl::as<crate::lower::model::Ex::XLabeled>(x_p0).a1;
        auto&& e_p26 = prism_rtl::as<crate::lower::model::Ex::XLabeled>(x_p0).a2;
        return crate::emit::rust::templates::items::labeled_f(label_f(label_p24), statements_f(dos_p25), expression_f(prism_rtl::deref(prism_rtl::deref(e_p26))));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XClosure>(x_p0)) {
        auto&& mv_p27 = prism_rtl::as<crate::lower::model::Ex::XClosure>(x_p0).a0;
        auto&& ps_p28 = prism_rtl::as<crate::lower::model::Ex::XClosure>(x_p0).a1;
        auto&& body_p29 = prism_rtl::as<crate::lower::model::Ex::XClosure>(x_p0).a2;
        return prism_rtl::cat(prism_rtl::deref(mv_p27) ? Text::lit("move ") : Text::lit(""), "|", crate::syntax::lexer::chars::join_f(crate::prelude::run_to_end(crate::prelude::each_job(ps_p28, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Pa)>>(prism_rtl::rc([=](crate::lower::model::Pa p0) {
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto p_p2a = p0;
                    (prism_rtl::more(prism_rtl::rc(Pattern_(p_p2a))));
                });
            }));
        })))), Text::lit(", ")), "| ", expression_f(prism_rtl::deref(prism_rtl::deref(body_p29))));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XTry>(x_p0)) {
        auto&& y_p2b = prism_rtl::as<crate::lower::model::Ex::XTry>(x_p0).a0;
        return prism_rtl::cat(tight_f(prism_rtl::deref(prism_rtl::deref(y_p2b))), "?");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XField>(x_p0)) {
        auto&& r_p2c = prism_rtl::as<crate::lower::model::Ex::XField>(x_p0).a0;
        auto&& f_p2d = prism_rtl::as<crate::lower::model::Ex::XField>(x_p0).a1;
        return prism_rtl::cat(tight_f(prism_rtl::deref(prism_rtl::deref(r_p2c))), ".", f_p2d);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XPart>(x_p0)) {
        auto&& r_p2e = prism_rtl::as<crate::lower::model::Ex::XPart>(x_p0).a0;
        auto&& k_p2f = prism_rtl::as<crate::lower::model::Ex::XPart>(x_p0).a1;
        return prism_rtl::cat(tight_f(prism_rtl::deref(prism_rtl::deref(r_p2e))), ".", k_p2f);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XDecode>(x_p0)) {
        auto&& t_p2g = prism_rtl::as<crate::lower::model::Ex::XDecode>(x_p0).a0;
        auto&& y_p2h = prism_rtl::as<crate::lower::model::Ex::XDecode>(x_p0).a1;
        return prism_rtl::cat(decode_head_f(t_p2g), "::from_pod(", expression_f(prism_rtl::deref(prism_rtl::deref(y_p2h))), ")?");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XCast>(x_p0)) {
        auto&& y_p2i = prism_rtl::as<crate::lower::model::Ex::XCast>(x_p0).a0;
        auto&& t_p2j = prism_rtl::as<crate::lower::model::Ex::XCast>(x_p0).a1;
        return prism_rtl::cat(tight_f(prism_rtl::deref(prism_rtl::deref(y_p2i))), " as ", type_f(t_p2j));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XTyped>(x_p0)) {
        auto&& y_p2k = prism_rtl::as<crate::lower::model::Ex::XTyped>(x_p0).a0;
        return expression_f(prism_rtl::deref(prism_rtl::deref(y_p2k)));
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Text> Expression::cycle() const {
    const auto& x_p0 = this->x_p0;
    return ({
        prism_rtl::is<crate::lower::model::Ex::XVar>(x_p0) ? ({
        auto&& n_p1 = prism_rtl::as<crate::lower::model::Ex::XVar>(x_p0).a0;
        prism_rtl::finished(n_p1);
    })
        : prism_rtl::is<crate::lower::model::Ex::XPath>(x_p0) ? ({
        auto&& p_p2 = prism_rtl::as<crate::lower::model::Ex::XPath>(x_p0).a0;
        prism_rtl::finished(p_p2);
    })
        : prism_rtl::is<crate::lower::model::Ex::XSelf>(x_p0) ? prism_rtl::finished(Text::lit("self"))
        : prism_rtl::is<crate::lower::model::Ex::XCx>(x_p0) ? prism_rtl::finished(Text::lit("cx"))
        : prism_rtl::is<crate::lower::model::Ex::XConst>(x_p0) ? ({
        auto&& n_p3 = prism_rtl::as<crate::lower::model::Ex::XConst>(x_p0).a0;
        prism_rtl::finished(prism_rtl::cat("Self::", n_p3));
    })
        : prism_rtl::is<crate::lower::model::Ex::XUnit>(x_p0) ? prism_rtl::finished(Text::lit("()"))
        : prism_rtl::is<crate::lower::model::Ex::XNone>(x_p0) ? prism_rtl::finished(Text::lit("None"))
        : prism_rtl::is<crate::lower::model::Ex::XBool>(x_p0) ? ({
        auto&& b_p4 = prism_rtl::as<crate::lower::model::Ex::XBool>(x_p0).a0;
        prism_rtl::deref(b_p4)
        ? prism_rtl::finished(Text::lit("true"))
        : prism_rtl::finished(Text::lit("false"));
    })
        : prism_rtl::is<crate::lower::model::Ex::XNat>(x_p0) ? ({
        auto&& d_p5 = prism_rtl::as<crate::lower::model::Ex::XNat>(x_p0).a0;
        crate::prelude::len_text(d_p5) <= Nat(9u)
        ? prism_rtl::finished(prism_rtl::cat("Nat::from(", d_p5, "u32)"))
        : crate::prelude::len_text(d_p5) <= Nat(18u)
        ? prism_rtl::finished(prism_rtl::cat("Nat::from_int(Int::from(", d_p5, "i64)).unwrap()"))
        : prism_rtl::finished(prism_rtl::cat("Nat::from_int(Int::parse(\"", d_p5, "\").unwrap()).unwrap()"));
    })
        : prism_rtl::is<crate::lower::model::Ex::XInt>(x_p0) ? ({
        auto&& d_p6 = prism_rtl::as<crate::lower::model::Ex::XInt>(x_p0).a0;
        crate::prelude::len_text(crate::syntax::lexer::chars::has_prefix_f(d_p6, Text::lit("-"))
        ? crate::syntax::lexer::chars::after_first_f(d_p6)
        : d_p6) <= Nat(18u)
        ? prism_rtl::finished(prism_rtl::cat("Int::from(", d_p6, ")"))
        : prism_rtl::finished(prism_rtl::cat("Int::parse(\"", d_p6, "\").unwrap()"));
    })
        : prism_rtl::is<crate::lower::model::Ex::XByte>(x_p0) ? ({
        auto&& d_p7 = prism_rtl::as<crate::lower::model::Ex::XByte>(x_p0).a0;
        prism_rtl::finished(prism_rtl::cat(d_p7, "u8"));
    })
        : prism_rtl::is<crate::lower::model::Ex::XFloat>(x_p0) ? ({
        auto&& d_p8 = prism_rtl::as<crate::lower::model::Ex::XFloat>(x_p0).a0;
        prism_rtl::finished(prism_rtl::cat("Float(", d_p8, ")"));
    })
        : prism_rtl::is<crate::lower::model::Ex::XIndex>(x_p0) ? ({
        auto&& n_p9 = prism_rtl::as<crate::lower::model::Ex::XIndex>(x_p0).a0;
        prism_rtl::finished(prism_rtl::cat(n_p9));
    })
        : prism_rtl::is<crate::lower::model::Ex::XChar>(x_p0) ? ({
        auto&& c_pa = prism_rtl::as<crate::lower::model::Ex::XChar>(x_p0).a0;
        prism_rtl::finished(prism_rtl::cat("\'", crate::lower::expr::char_escape_f(c_pa), "\'"));
    })
        : prism_rtl::is<crate::lower::model::Ex::XStr>(x_p0) ? ({
        auto&& t_pb = prism_rtl::as<crate::lower::model::Ex::XStr>(x_p0).a0;
        prism_rtl::finished(prism_rtl::cat("\"", crate::lower::expr::escape_f(t_pb), "\""));
    })
        : prism_rtl::is<crate::lower::model::Ex::XRegex>(x_p0) ? ({
        auto&& p_pc = prism_rtl::as<crate::lower::model::Ex::XRegex>(x_p0).a0;
        auto&& f_pd = prism_rtl::as<crate::lower::model::Ex::XRegex>(x_p0).a1;
        prism_rtl::finished(prism_rtl::cat("{ thread_local!(static R: Regex = Regex::lit(\"", crate::lower::expr::escape_f(p_pc), "\", \"", crate::lower::expr::escape_f(f_pd), "\")); R.with(Regex::clone) }"));
    })
        : prism_rtl::is<crate::lower::model::Ex::XReplacement>(x_p0) ? ({
        auto&& p_pe = prism_rtl::as<crate::lower::model::Ex::XReplacement>(x_p0).a0;
        auto&& r_pf = prism_rtl::as<crate::lower::model::Ex::XReplacement>(x_p0).a1;
        auto&& f_pg = prism_rtl::as<crate::lower::model::Ex::XReplacement>(x_p0).a2;
        prism_rtl::finished(prism_rtl::cat("{ thread_local!(static R: RegexReplacement = RegexReplacement::lit(\"", crate::lower::expr::escape_f(p_pe), "\", \"", crate::lower::expr::escape_f(f_pg), "\", \"", crate::lower::expr::escape_f(r_pf), "\")); R.with(RegexReplacement::clone) }"));
    })
        : prism_rtl::is<crate::lower::model::Ex::XRef>(x_p0) ? ({
        auto&& y_ph = prism_rtl::as<crate::lower::model::Ex::XRef>(x_p0).a0;
        ({
        auto y_phx = prism_rtl::deref(prism_rtl::deref(y_ph));
        (crate::prelude::call_then(start_operand_f(y_phx), [=](Text operand_f_5830) { return prism_rtl::finished(prism_rtl::cat("&", operand_f_5830)); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XRefMut>(x_p0) ? ({
        auto&& y_pi = prism_rtl::as<crate::lower::model::Ex::XRefMut>(x_p0).a0;
        ({
        auto y_pix = prism_rtl::deref(prism_rtl::deref(y_pi));
        (crate::prelude::call_then(start_operand_f(y_pix), [=](Text operand_f_5864) { return prism_rtl::finished(prism_rtl::cat("&mut ", operand_f_5864)); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XDeref>(x_p0) ? ({
        auto&& y_pj = prism_rtl::as<crate::lower::model::Ex::XDeref>(x_p0).a0;
        ({
        auto y_pjx = prism_rtl::deref(prism_rtl::deref(y_pj));
        (crate::prelude::call_then(start_operand_f(y_pjx), [=](Text operand_f_5893) { return prism_rtl::finished(prism_rtl::cat("*", operand_f_5893)); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XTarget>(x_p0) ? ({
        auto&& y_pk = prism_rtl::as<crate::lower::model::Ex::XTarget>(x_p0).a0;
        ({
        auto y_pkx = prism_rtl::deref(prism_rtl::deref(y_pk));
        (crate::prelude::call_then(start_expression_f(y_pkx), [=](Text expression_f_5924) { return prism_rtl::finished(prism_rtl::cat("(*", expression_f_5924, ")")); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XClone>(x_p0) ? ({
        auto&& y_pl = prism_rtl::as<crate::lower::model::Ex::XClone>(x_p0).a0;
        ({
        auto y_plx = prism_rtl::deref(prism_rtl::deref(y_pl));
        (crate::prelude::call_then(start_tight_f(y_plx), [=](Text tight_f_5956) { return prism_rtl::finished(prism_rtl::cat(tight_f_5956, ".clone()")); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XWeak>(x_p0) ? ({
        auto&& y_pm = prism_rtl::as<crate::lower::model::Ex::XWeak>(x_p0).a0;
        ({
        auto y_pmx = prism_rtl::deref(prism_rtl::deref(y_pm));
        (crate::prelude::call_then(start_expression_f(y_pmx), [=](Text expression_f_6003) { return prism_rtl::finished(prism_rtl::cat("Rc::downgrade(", expression_f_6003, ")")); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XUpgrade>(x_p0) ? ({
        auto&& y_pn = prism_rtl::as<crate::lower::model::Ex::XUpgrade>(x_p0).a0;
        ({
        auto y_pnx = prism_rtl::deref(prism_rtl::deref(y_pn));
        (crate::prelude::call_then(start_tight_f(y_pnx), [=](Text tight_f_6037) { return prism_rtl::finished(prism_rtl::cat(tight_f_6037, ".upgrade()")); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XBreak>(x_p0) ? ({
        auto&& l_po = prism_rtl::as<crate::lower::model::Ex::XBreak>(x_p0).a0;
        auto&& y_pp = prism_rtl::as<crate::lower::model::Ex::XBreak>(x_p0).a1;
        ({
        auto l_pox = l_po;
        auto y_ppx = prism_rtl::deref(prism_rtl::deref(y_pp));
        (crate::prelude::call_then(start_expression_f(y_ppx), [=, l_pox = std::move(l_pox)](Text expression_f_6092) { return prism_rtl::finished(prism_rtl::cat("break ", label_f(l_pox), " ", expression_f_6092)); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XBreakLoop>(x_p0) ? prism_rtl::finished(Text::lit("break"))
        : prism_rtl::is<crate::lower::model::Ex::XLater>(x_p0) ? ({
        auto&& y_pq = prism_rtl::as<crate::lower::model::Ex::XLater>(x_p0).a0;
        ({
        auto y_pqx = prism_rtl::deref(prism_rtl::deref(y_pq));
        (crate::prelude::call_then(start_expression_f(y_pqx), [=](Text expression_f_6169) { return prism_rtl::finished(prism_rtl::cat("Box::new(move |cx| { ", expression_f_6169, "; Ok(()) })")); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XFormatStr>(x_p0) ? ({
        auto&& parts_pr = prism_rtl::as<crate::lower::model::Ex::XFormatStr>(x_p0).a0;
        prism_rtl::more(prism_rtl::rc(FormatStr(parts_pr)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XIsCase>(x_p0) && ({
        auto&& y_ps = prism_rtl::as<crate::lower::model::Ex::XIsCase>(x_p0).a0;
        auto&& m4730_28_1 = prism_rtl::as<crate::lower::model::Ex::XIsCase>(x_p0).a1;
        (m4730_28_1.size() == 0u);
    }) ? ({
        auto&& y_ps = prism_rtl::as<crate::lower::model::Ex::XIsCase>(x_p0).a0;
        auto&& m4730_28_1 = prism_rtl::as<crate::lower::model::Ex::XIsCase>(x_p0).a1;
        prism_rtl::finished(Text::lit("false"));
    })
        : prism_rtl::is<crate::lower::model::Ex::XIsCase>(x_p0) ? ({
        auto&& y_pt = prism_rtl::as<crate::lower::model::Ex::XIsCase>(x_p0).a0;
        auto&& cs_pu = prism_rtl::as<crate::lower::model::Ex::XIsCase>(x_p0).a1;
        ({
        auto cs_pux = cs_pu;
        auto y_ptx = prism_rtl::deref(prism_rtl::deref(y_pt));
        (crate::prelude::call_then(start_expression_f(y_ptx), [=, cs_pux = std::move(cs_pux)](Text expression_f_6293) { return prism_rtl::finished(prism_rtl::cat("matches!(", expression_f_6293, ", ", crate::syntax::lexer::chars::join_f(crate::prelude::each(cs_pux, [&](const Text& c_pv) { return prism_rtl::cat(c_pv, "(..)"); }), Text::lit(" | ")), ")")); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XRefusal>(x_p0) ? ({
        auto&& what_p10 = prism_rtl::as<crate::lower::model::Ex::XRefusal>(x_p0).a0;
        prism_rtl::finished(prism_rtl::cat("compile_error!(\"", crate::lower::expr::lowering_refusal_p(), crate::lower::expr::escape_f(what_p10), "\")"));
    })
        : prism_rtl::is<crate::lower::model::Ex::XUnreachable>(x_p0) ? prism_rtl::finished(Text::lit("unreachable!()"))
        : prism_rtl::is<crate::lower::model::Ex::XCall>(x_p0) ? ({
        auto&& f_p11 = prism_rtl::as<crate::lower::model::Ex::XCall>(x_p0).a0;
        auto&& args_p12 = prism_rtl::as<crate::lower::model::Ex::XCall>(x_p0).a1;
        ({
        auto args_p12x = args_p12;
        auto f_p11x = f_p11;
        (crate::prelude::call_then(start_args_f(args_p12x), [=, f_p11x = std::move(f_p11x)](Text args_f_6482) { return prism_rtl::finished(prism_rtl::cat(f_p11x, "(", args_f_6482, ")")); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XApply>(x_p0) ? ({
        auto&& f_p13 = prism_rtl::as<crate::lower::model::Ex::XApply>(x_p0).a0;
        auto&& args_p14 = prism_rtl::as<crate::lower::model::Ex::XApply>(x_p0).a1;
        ({
        auto args_p14x = args_p14;
        auto f_p13x = prism_rtl::deref(prism_rtl::deref(f_p13));
        (crate::prelude::call_then(start_tight_f(f_p13x), [=, args_p14x = std::move(args_p14x)](Text tight_f_6517) { return crate::prelude::call_then(start_args_f(args_p14x), [=](Text args_f_6527) { return prism_rtl::finished(prism_rtl::cat(tight_f_6517, "(", args_f_6527, ")")); }); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XMethod>(x_p0) ? ({
        auto&& r_p15 = prism_rtl::as<crate::lower::model::Ex::XMethod>(x_p0).a0;
        auto&& m_p16 = prism_rtl::as<crate::lower::model::Ex::XMethod>(x_p0).a1;
        auto&& args_p17 = prism_rtl::as<crate::lower::model::Ex::XMethod>(x_p0).a2;
        ({
        auto args_p17x = args_p17;
        auto m_p16x = m_p16;
        auto r_p15x = prism_rtl::deref(prism_rtl::deref(r_p15));
        (crate::prelude::call_then(start_tight_f(r_p15x), [=, args_p17x = std::move(args_p17x), m_p16x = std::move(m_p16x)](Text tight_f_6566) { return crate::prelude::call_then(start_args_f(args_p17x), [=](Text args_f_6580) { return prism_rtl::finished(prism_rtl::cat(tight_f_6566, ".", m_p16x, "(", args_f_6580, ")")); }); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XBin>(x_p0) ? ({
        auto&& op_p18 = prism_rtl::as<crate::lower::model::Ex::XBin>(x_p0).a0;
        auto&& l_p19 = prism_rtl::as<crate::lower::model::Ex::XBin>(x_p0).a1;
        auto&& r_p1a = prism_rtl::as<crate::lower::model::Ex::XBin>(x_p0).a2;
        ({
        auto l_p19x = prism_rtl::deref(prism_rtl::deref(l_p19));
        auto op_p18x = op_p18;
        auto r_p1ax = prism_rtl::deref(prism_rtl::deref(r_p1a));
        (crate::prelude::call_then(start_operand_f(l_p19x), [=, op_p18x = std::move(op_p18x), r_p1ax = std::move(r_p1ax)](Text operand_f_6614) { return crate::prelude::call_then(start_operand_f(r_p1ax), [=](Text operand_f_6641) { return prism_rtl::finished(prism_rtl::cat(operand_f_6614, " ", crate::lower::model::bin_op_text_f(op_p18x), " ", operand_f_6641)); }); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XUnary>(x_p0) ? ({
        auto&& op_p1b = prism_rtl::as<crate::lower::model::Ex::XUnary>(x_p0).a0;
        auto&& y_p1c = prism_rtl::as<crate::lower::model::Ex::XUnary>(x_p0).a1;
        ({
        auto op_p1bx = op_p1b;
        auto y_p1cx = prism_rtl::deref(prism_rtl::deref(y_p1c));
        (crate::prelude::call_then(start_operand_f(y_p1cx), [=, op_p1bx = std::move(op_p1bx)](Text operand_f_6686) { return prism_rtl::finished(prism_rtl::cat(crate::lower::model::un_op_text_f(op_p1bx), operand_f_6686)); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XCtor>(x_p0) ? ({
        auto&& p_p1d = prism_rtl::as<crate::lower::model::Ex::XCtor>(x_p0).a0;
        auto&& args_p1e = prism_rtl::as<crate::lower::model::Ex::XCtor>(x_p0).a1;
        ({
        auto args_p1ex = args_p1e;
        auto p_p1dx = p_p1d;
        (crate::prelude::call_then(start_args_f(args_p1ex), [=, p_p1dx = std::move(p_p1dx)](Text args_f_6723) { return prism_rtl::finished(prism_rtl::cat(p_p1dx, "(", args_f_6723, ")")); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XRecord>(x_p0) ? ({
        auto&& p_p1f = prism_rtl::as<crate::lower::model::Ex::XRecord>(x_p0).a0;
        auto&& fs_p1g = prism_rtl::as<crate::lower::model::Ex::XRecord>(x_p0).a1;
        ({
        auto fs_p1gx = fs_p1g;
        auto p_p1fx = p_p1f;
        (crate::prelude::call_value(crate::prelude::each_job(fs_p1gx, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::Ex>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::Ex> p0) {
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto [f_p1h, v_p1i] = p0;
                (prism_rtl::more(prism_rtl::rc(FieldInit(f_p1h, v_p1i))));
            });
        }));
    }))), [=, p_p1fx = std::move(p_p1fx)](Array<Text> each_6770) { return prism_rtl::finished(prism_rtl::cat(p_p1fx, " { ", crate::syntax::lexer::chars::join_f(each_6770, Text::lit(", ")), " }")); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XTuple>(x_p0) && ({
        auto&& m4730_39_0 = prism_rtl::as<crate::lower::model::Ex::XTuple>(x_p0).a0;
        (m4730_39_0.size() == 1u) && ({
        auto&& _c1 = crate::prelude::index(m4730_39_0, Nat(0u));
        prism_rtl::is_some(_c1);
    });
    }) ? ({
        auto&& m4730_39_0 = prism_rtl::as<crate::lower::model::Ex::XTuple>(x_p0).a0;
        auto&& _c1 = crate::prelude::index(m4730_39_0, Nat(0u));
        auto&& one_p1j = prism_rtl::some_of(_c1);
        crate::prelude::call_then(start_expression_f(one_p1j), [=](Text expression_f_6841) { return prism_rtl::finished(prism_rtl::cat("(", expression_f_6841, ",)")); });
    })
        : prism_rtl::is<crate::lower::model::Ex::XTuple>(x_p0) ? ({
        auto&& xs_p1k = prism_rtl::as<crate::lower::model::Ex::XTuple>(x_p0).a0;
        ({
        auto xs_p1kx = xs_p1k;
        (crate::prelude::call_then(start_args_f(xs_p1kx), [=](Text args_f_6878) { return prism_rtl::finished(prism_rtl::cat("(", args_f_6878, ")")); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XVec>(x_p0) ? ({
        auto&& xs_p1l = prism_rtl::as<crate::lower::model::Ex::XVec>(x_p0).a0;
        ({
        auto xs_p1lx = xs_p1l;
        (crate::prelude::call_then(start_args_f(xs_p1lx), [=](Text args_f_6909) { return prism_rtl::finished(prism_rtl::cat("vec![", args_f_6909, "]")); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XText>(x_p0) ? ({
        auto&& t_p1m = prism_rtl::as<crate::lower::model::Ex::XText>(x_p0).a0;
        prism_rtl::finished(prism_rtl::cat("Text::lit(\"", crate::lower::expr::escape_f(t_p1m), "\")"));
    })
        : prism_rtl::is<crate::lower::model::Ex::XFormat>(x_p0) ? ({
        auto&& parts_p1n = prism_rtl::as<crate::lower::model::Ex::XFormat>(x_p0).a0;
        prism_rtl::more(prism_rtl::rc(Format(parts_p1n)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XMatch>(x_p0) ? ({
        auto&& s_p1o = prism_rtl::as<crate::lower::model::Ex::XMatch>(x_p0).a0;
        auto&& arms_p1p = prism_rtl::as<crate::lower::model::Ex::XMatch>(x_p0).a1;
        auto&& fallback_p1q = prism_rtl::as<crate::lower::model::Ex::XMatch>(x_p0).a2;
        ({
        auto arms_p1px = arms_p1p;
        auto fallback_p1qx = prism_rtl::deref(fallback_p1q);
        auto s_p1ox = prism_rtl::deref(prism_rtl::deref(s_p1o));
        (crate::prelude::call_then(start_expression_f(s_p1ox), [=, arms_p1px = std::move(arms_p1px), fallback_p1qx = std::move(fallback_p1qx)](Text expression_f_7043) { return crate::prelude::call_then(start_arms_f(arms_p1px, fallback_p1qx), [=](Text arms_f_7059) { return prism_rtl::finished(crate::emit::rust::templates::items::match_block_f(expression_f_7043, arms_f_7059)); }); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XChain>(x_p0) ? ({
        auto&& label_p1r = prism_rtl::as<crate::lower::model::Ex::XChain>(x_p0).a0;
        auto&& s_p1s = prism_rtl::as<crate::lower::model::Ex::XChain>(x_p0).a1;
        auto&& arms_p1t = prism_rtl::as<crate::lower::model::Ex::XChain>(x_p0).a2;
        prism_rtl::more(prism_rtl::rc(Chain(label_f(label_p1r), prism_rtl::deref(prism_rtl::deref(s_p1s)), arms_p1t)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XIf>(x_p0) ? ({
        auto&& c_p1u = prism_rtl::as<crate::lower::model::Ex::XIf>(x_p0).a0;
        auto&& t_p1v = prism_rtl::as<crate::lower::model::Ex::XIf>(x_p0).a1;
        auto&& e_p20 = prism_rtl::as<crate::lower::model::Ex::XIf>(x_p0).a2;
        prism_rtl::more(prism_rtl::rc(IfExpression(prism_rtl::deref(prism_rtl::deref(c_p1u)), prism_rtl::deref(prism_rtl::deref(t_p1v)), prism_rtl::deref(prism_rtl::deref(e_p20)))));
    })
        : prism_rtl::is<crate::lower::model::Ex::XBlock>(x_p0) && ({
        auto&& m4730_47_0 = prism_rtl::as<crate::lower::model::Ex::XBlock>(x_p0).a0;
        auto&& e_p21 = prism_rtl::as<crate::lower::model::Ex::XBlock>(x_p0).a1;
        (m4730_47_0.size() == 0u);
    }) ? ({
        auto&& m4730_47_0 = prism_rtl::as<crate::lower::model::Ex::XBlock>(x_p0).a0;
        auto&& e_p21 = prism_rtl::as<crate::lower::model::Ex::XBlock>(x_p0).a1;
        prism_rtl::more(prism_rtl::rc(Expression(prism_rtl::deref(prism_rtl::deref(e_p21)))));
    })
        : prism_rtl::is<crate::lower::model::Ex::XBlock>(x_p0) ? ({
        auto&& dos_p22 = prism_rtl::as<crate::lower::model::Ex::XBlock>(x_p0).a0;
        auto&& e_p23 = prism_rtl::as<crate::lower::model::Ex::XBlock>(x_p0).a1;
        ({
        auto dos_p22x = dos_p22;
        auto e_p23x = prism_rtl::deref(prism_rtl::deref(e_p23));
        (crate::prelude::call_then(start_statements_f(dos_p22x), [=, e_p23x = std::move(e_p23x)](Text statements_f_7241) { return crate::prelude::call_then(start_expression_f(e_p23x), [=](Text expression_f_7259) { return prism_rtl::finished(crate::emit::rust::templates::items::block_f(statements_f_7241, expression_f_7259)); }); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XLabeled>(x_p0) ? ({
        auto&& label_p24 = prism_rtl::as<crate::lower::model::Ex::XLabeled>(x_p0).a0;
        auto&& dos_p25 = prism_rtl::as<crate::lower::model::Ex::XLabeled>(x_p0).a1;
        auto&& e_p26 = prism_rtl::as<crate::lower::model::Ex::XLabeled>(x_p0).a2;
        ({
        auto dos_p25x = dos_p25;
        auto e_p26x = prism_rtl::deref(prism_rtl::deref(e_p26));
        auto label_p24x = label_p24;
        (crate::prelude::call_then(start_statements_f(dos_p25x), [=, e_p26x = std::move(e_p26x), label_p24x = std::move(label_p24x)](Text statements_f_7333) { return crate::prelude::call_then(start_expression_f(e_p26x), [=](Text expression_f_7351) { return prism_rtl::finished(crate::emit::rust::templates::items::labeled_f(label_f(label_p24x), statements_f_7333, expression_f_7351)); }); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XClosure>(x_p0) ? ({
        auto&& mv_p27 = prism_rtl::as<crate::lower::model::Ex::XClosure>(x_p0).a0;
        auto&& ps_p28 = prism_rtl::as<crate::lower::model::Ex::XClosure>(x_p0).a1;
        auto&& body_p29 = prism_rtl::as<crate::lower::model::Ex::XClosure>(x_p0).a2;
        ({
        auto body_p29x = prism_rtl::deref(prism_rtl::deref(body_p29));
        auto mv_p27x = prism_rtl::deref(mv_p27);
        auto ps_p28x = ps_p28;
        (crate::prelude::call_value(crate::prelude::each_job(ps_p28x, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Pa)>>(prism_rtl::rc([=](crate::lower::model::Pa p0) {
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto p_p2a = p0;
                (prism_rtl::more(prism_rtl::rc(Pattern_(p_p2a))));
            });
        }));
    }))), [=, body_p29x = std::move(body_p29x), mv_p27x = std::move(mv_p27x)](Array<Text> each_7426) { return crate::prelude::call_then(start_expression_f(body_p29x), [=](Text expression_f_7460) { return prism_rtl::finished(prism_rtl::cat(mv_p27x ? Text::lit("move ") : Text::lit(""), "|", crate::syntax::lexer::chars::join_f(each_7426, Text::lit(", ")), "| ", expression_f_7460)); }); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XTry>(x_p0) ? ({
        auto&& y_p2b = prism_rtl::as<crate::lower::model::Ex::XTry>(x_p0).a0;
        ({
        auto y_p2bx = prism_rtl::deref(prism_rtl::deref(y_p2b));
        (crate::prelude::call_then(start_tight_f(y_p2bx), [=](Text tight_f_7492) { return prism_rtl::finished(prism_rtl::cat(tight_f_7492, "?")); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XField>(x_p0) ? ({
        auto&& r_p2c = prism_rtl::as<crate::lower::model::Ex::XField>(x_p0).a0;
        auto&& f_p2d = prism_rtl::as<crate::lower::model::Ex::XField>(x_p0).a1;
        ({
        auto f_p2dx = f_p2d;
        auto r_p2cx = prism_rtl::deref(prism_rtl::deref(r_p2c));
        (crate::prelude::call_then(start_tight_f(r_p2cx), [=, f_p2dx = std::move(f_p2dx)](Text tight_f_7522) { return prism_rtl::finished(prism_rtl::cat(tight_f_7522, ".", f_p2dx)); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XPart>(x_p0) ? ({
        auto&& r_p2e = prism_rtl::as<crate::lower::model::Ex::XPart>(x_p0).a0;
        auto&& k_p2f = prism_rtl::as<crate::lower::model::Ex::XPart>(x_p0).a1;
        ({
        auto k_p2fx = k_p2f;
        auto r_p2ex = prism_rtl::deref(prism_rtl::deref(r_p2e));
        (crate::prelude::call_then(start_tight_f(r_p2ex), [=, k_p2fx = std::move(k_p2fx)](Text tight_f_7554) { return prism_rtl::finished(prism_rtl::cat(tight_f_7554, ".", k_p2fx)); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XDecode>(x_p0) ? ({
        auto&& t_p2g = prism_rtl::as<crate::lower::model::Ex::XDecode>(x_p0).a0;
        auto&& y_p2h = prism_rtl::as<crate::lower::model::Ex::XDecode>(x_p0).a1;
        ({
        auto t_p2gx = t_p2g;
        auto y_p2hx = prism_rtl::deref(prism_rtl::deref(y_p2h));
        (crate::prelude::call_then(start_decode_head_f(t_p2gx), [=, y_p2hx = std::move(y_p2hx)](Text decode_head_f_7588) { return crate::prelude::call_then(start_expression_f(y_p2hx), [=](Text expression_f_7613) { return prism_rtl::finished(prism_rtl::cat(decode_head_f_7588, "::from_pod(", expression_f_7613, ")?")); }); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XCast>(x_p0) ? ({
        auto&& y_p2i = prism_rtl::as<crate::lower::model::Ex::XCast>(x_p0).a0;
        auto&& t_p2j = prism_rtl::as<crate::lower::model::Ex::XCast>(x_p0).a1;
        ({
        auto t_p2jx = t_p2j;
        auto y_p2ix = prism_rtl::deref(prism_rtl::deref(y_p2i));
        (crate::prelude::call_then(start_tight_f(y_p2ix), [=, t_p2jx = std::move(t_p2jx)](Text tight_f_7648) { return crate::prelude::call_then(start_type_f(t_p2jx), [=](Text type_f_7661) { return prism_rtl::finished(prism_rtl::cat(tight_f_7648, " as ", type_f_7661)); }); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XTyped>(x_p0) ? ({
        auto&& y_p2k = prism_rtl::as<crate::lower::model::Ex::XTyped>(x_p0).a0;
        prism_rtl::more(prism_rtl::rc(Expression(prism_rtl::deref(prism_rtl::deref(y_p2k)))));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start Expression, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_expression_f(crate::lower::model::Ex x_p0) {
    return prism_rtl::make_rc<Expression>(x_p0);
}


/// FieldInit: unbounded fn Text, Ex -> Text
Text field_init_f(const Text& f_p0, const crate::lower::model::Ex& ex1) {
    if (prism_rtl::is<crate::lower::model::Ex::XVar>(ex1)) {
        auto&& v_p1 = prism_rtl::as<crate::lower::model::Ex::XVar>(ex1).a0;
        return v_p1 == f_p0 ? f_p0 : prism_rtl::cat(f_p0, ": ", v_p1);
    }
    {
        auto&& v_p3 = ex1;
        return prism_rtl::cat(f_p0, ": ", expression_f(v_p3));
    }
}


prism_rtl::Turn<Text> FieldInit::cycle() const {
    const auto& f_p0 = this->f_p0;
    const auto& ex1 = this->ex1;
    return ({
        prism_rtl::is<crate::lower::model::Ex::XVar>(ex1) ? ({
        auto&& v_p1 = prism_rtl::as<crate::lower::model::Ex::XVar>(ex1).a0;
        v_p1 == f_p0
        ? prism_rtl::finished(f_p0)
        : prism_rtl::finished(prism_rtl::cat(f_p0, ": ", v_p1));
    })
        : ({
        auto&& v_p3 = ex1;
        ({
        auto f_p0x = f_p0;
        auto v_p3x = v_p3;
        (crate::prelude::call_then(start_expression_f(v_p3x), [=, f_p0x = std::move(f_p0x)](Text expression_f_7831) { return prism_rtl::finished(prism_rtl::cat(f_p0x, ": ", expression_f_7831)); }));
    });
    });
    });
}


/// `Start FieldInit, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_field_init_f(Text f_p0, crate::lower::model::Ex ex1) {
    return prism_rtl::make_rc<FieldInit>(f_p0, ex1);
}


/// DecodeHead: unbounded fn OutTy -> Text
Text decode_head_f(const crate::lower::model::OutTy& t_p0) {
    if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t_p0)) {
        auto&& n_p1 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p0).a0;
        auto&& m7904_0_1 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p0).a1;
        if (m7904_0_1.size() == 0u) {
            return n_p1;
        }
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutNat>(t_p0)) {
        return Text::lit("Nat");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutInt>(t_p0)) {
        return Text::lit("Int");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutText>(t_p0)) {
        return Text::lit("Text");
    }
    {
        return prism_rtl::cat("<", type_f(t_p0), ">");
    }
}


prism_rtl::Turn<Text> DecodeHead::cycle() const {
    const auto& t_p0 = this->t_p0;
    return ({
        prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t_p0) && ({
        auto&& n_p1 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p0).a0;
        auto&& m7904_0_1 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p0).a1;
        (m7904_0_1.size() == 0u);
    }) ? ({
        auto&& n_p1 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p0).a0;
        auto&& m7904_0_1 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p0).a1;
        prism_rtl::finished(n_p1);
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutNat>(t_p0) ? prism_rtl::finished(Text::lit("Nat"))
        : prism_rtl::is<crate::lower::model::OutTy::OutInt>(t_p0) ? prism_rtl::finished(Text::lit("Int"))
        : prism_rtl::is<crate::lower::model::OutTy::OutText>(t_p0) ? prism_rtl::finished(Text::lit("Text"))
        : ({
        auto t_p0x = t_p0;
        (crate::prelude::call_then(start_type_f(t_p0x), [=](Text type_f_8011) { return prism_rtl::finished(prism_rtl::cat("<", type_f_8011, ">")); }));
    });
    });
}


/// `Start DecodeHead, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_decode_head_f(crate::lower::model::OutTy t_p0) {
    return prism_rtl::make_rc<DecodeHead>(t_p0);
}


/// Label: fn Text -> Text
Text label_f(const Text& l_p0) {
    return crate::syntax::lexer::chars::has_prefix_f(l_p0, Text::lit("\'"))
        ? l_p0
        : prism_rtl::cat("\'", l_p0);
}


/// Format: unbounded fn [Ex] -> Text
Text format_f(const Array<crate::lower::model::Ex>& parts_p0) {
    auto lit_p1 = crate::prelude::concat(crate::prelude::each(parts_p0, [&](const crate::lower::model::Ex& p_p3) { return format_piece_f(p_p3); }));
    auto vals_p2 = crate::prelude::filter(parts_p0, [&](const crate::lower::model::Ex& p_p4) { return !is_text_f(p_p4); });
    return crate::prelude::len(vals_p2) == Nat(0u)
        ? prism_rtl::cat("Text::lit(\"", crate::lower::expr::escape_f(crate::prelude::concat(crate::prelude::each(parts_p0, [&](const crate::lower::model::Ex& p_p5) { return plain_piece_f(p_p5); }))), "\")")
        : prism_rtl::cat("Text::from(format!(\"", lit_p1, "\", ", args_f(vals_p2), "))");
}


prism_rtl::Turn<Text> Format::cycle() const {
    const auto& parts_p0 = this->parts_p0;
    auto lit_p1 = crate::prelude::concat(crate::prelude::each(parts_p0, [&](const crate::lower::model::Ex& p_p3) { return format_piece_f(p_p3); }));
    auto vals_p2 = crate::prelude::filter(parts_p0, [&](const crate::lower::model::Ex& p_p4) { return !is_text_f(p_p4); });
    return crate::prelude::len(vals_p2) == Nat(0u)
        ? prism_rtl::finished(prism_rtl::cat("Text::lit(\"", crate::lower::expr::escape_f(crate::prelude::concat(crate::prelude::each(parts_p0, [&](const crate::lower::model::Ex& p_p5) { return plain_piece_f(p_p5); }))), "\")"))
        : crate::prelude::call_then(start_args_f(vals_p2), [=](Text args_f_8526) { return prism_rtl::finished(prism_rtl::cat("Text::from(format!(\"", lit_p1, "\", ", args_f_8526, "))")); });
}


/// `Start Format, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_format_f(Array<crate::lower::model::Ex> parts_p0) {
    return prism_rtl::make_rc<Format>(parts_p0);
}


/// PlainPiece: fn Ex -> Text
Text plain_piece_f(const crate::lower::model::Ex& ex0) {
    if (prism_rtl::is<crate::lower::model::Ex::XText>(ex0)) {
        auto&& t_p0 = prism_rtl::as<crate::lower::model::Ex::XText>(ex0).a0;
        return t_p0;
    }
    {
        auto&& other_p1 = ex0;
        return Text::lit("");
    }
}


/// FormatStr: unbounded fn [Ex] -> Text
Text format_str_f(const Array<crate::lower::model::Ex>& parts_p0) {
    auto lit_p1 = crate::prelude::concat(crate::prelude::each(parts_p0, [&](const crate::lower::model::Ex& p_p3) { return str_piece_f(p_p3); }));
    auto vals_p2 = crate::prelude::filter(parts_p0, [&](const crate::lower::model::Ex& p_p4) { return (!is_text_f(p_p4)) && (!is_var_f(p_p4)); });
    return crate::prelude::len(vals_p2) == Nat(0u)
        ? prism_rtl::cat("\"", lit_p1, "\"")
        : prism_rtl::cat("format!(\"", lit_p1, "\", ", args_f(vals_p2), ")");
}


prism_rtl::Turn<Text> FormatStr::cycle() const {
    const auto& parts_p0 = this->parts_p0;
    auto lit_p1 = crate::prelude::concat(crate::prelude::each(parts_p0, [&](const crate::lower::model::Ex& p_p3) { return str_piece_f(p_p3); }));
    auto vals_p2 = crate::prelude::filter(parts_p0, [&](const crate::lower::model::Ex& p_p4) { return (!is_text_f(p_p4)) && (!is_var_f(p_p4)); });
    return crate::prelude::len(vals_p2) == Nat(0u)
        ? prism_rtl::finished(prism_rtl::cat("\"", lit_p1, "\""))
        : crate::prelude::call_then(start_args_f(vals_p2), [=](Text args_f_8991) { return prism_rtl::finished(prism_rtl::cat("format!(\"", lit_p1, "\", ", args_f_8991, ")")); });
}


/// `Start FormatStr, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_format_str_f(Array<crate::lower::model::Ex> parts_p0) {
    return prism_rtl::make_rc<FormatStr>(parts_p0);
}


/// IsVar: fn Ex -> Bool
bool is_var_f(const crate::lower::model::Ex& ex0) {
    if (prism_rtl::is<crate::lower::model::Ex::XVar>(ex0)) {
        return true;
    }
    {
        auto&& other_p0 = ex0;
        return false;
    }
}


/// StrPiece: fn Ex -> Text
Text str_piece_f(const crate::lower::model::Ex& ex0) {
    if (prism_rtl::is<crate::lower::model::Ex::XVar>(ex0)) {
        auto&& n_p0 = prism_rtl::as<crate::lower::model::Ex::XVar>(ex0).a0;
        return prism_rtl::cat("{", n_p0, "}");
    }
    {
        auto&& other_p1 = ex0;
        return format_piece_f(other_p1);
    }
}


/// IsText: fn Ex -> Bool
bool is_text_f(const crate::lower::model::Ex& ex0) {
    if (prism_rtl::is<crate::lower::model::Ex::XText>(ex0)) {
        return true;
    }
    {
        auto&& other_p0 = ex0;
        return false;
    }
}


/// FormatPiece: fn Ex -> Text
Text format_piece_f(const crate::lower::model::Ex& ex0) {
    if (prism_rtl::is<crate::lower::model::Ex::XText>(ex0)) {
        auto&& t_p0 = prism_rtl::as<crate::lower::model::Ex::XText>(ex0).a0;
        return format_escape_f(crate::lower::expr::escape_f(t_p0));
    }
    {
        auto&& other_p1 = ex0;
        return Text::lit("{}");
    }
}


/// FormatEscape: fn Text -> Text
Text format_escape_f(const Text& t_p0) {
    return crate::syntax::lexer::chars::map_chars_f(t_p0, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Text)>>(prism_rtl::rc([=](Text p0) {
        return crate::prelude::once_job([=]() {
            return ({
                auto c_p1 = p0;
                (prism_rtl::finished(format_escape_char_f(c_p1)));
            });
        });
    })));
}


/// FormatEscapeChar: fn Text -> Text
Text format_escape_char_f(const Text& text0) {
    {
        auto&& c0_0 = text0;
        if (c0_0 == Text::lit("{")) {
            return Text::lit("{{");
        }
    }
    {
        auto&& c1_0 = text0;
        if (c1_0 == Text::lit("}")) {
            return Text::lit("}}");
        }
    }
    {
        auto&& c_p0 = text0;
        return c_p0;
    }
}


/// IfExpression: unbounded fn Ex, Ex, Ex -> Text
Text if_expression_f(const crate::lower::model::Ex& c_p0, const crate::lower::model::Ex& t_p1, const crate::lower::model::Ex& e_p2) {
    auto ct_p3 = expression_f(c_p0);
    auto tt_p4 = expression_f(t_p1);
    auto et_p5 = expression_f(e_p2);
    auto short_p6 = (!crate::syntax::lexer::chars::contains_f(prism_rtl::cat(tt_p4, et_p5), Text::lit("\n"))) && (crate::prelude::len_text(prism_rtl::cat(ct_p3, tt_p4, et_p5)) < Nat(70u));
    return std::move(short_p6)
        ? prism_rtl::cat("if ", ct_p3, " { ", tt_p4, " } else { ", et_p5, " }")
        : crate::emit::rust::templates::items::if_f(ct_p3, tt_p4, et_p5);
}


prism_rtl::Turn<Text> IfExpression::cycle() const {
    const auto& c_p0 = this->c_p0;
    const auto& t_p1 = this->t_p1;
    const auto& e_p2 = this->e_p2;
    auto c_p0x = c_p0;
    auto e_p2x = e_p2;
    auto t_p1x = t_p1;
    return crate::prelude::call_then(start_expression_f(c_p0x), [=](Text expression_f_9729) {
        return ({
            auto ct_p3 = expression_f_9729;
            (crate::prelude::call_then(start_expression_f(t_p1x), [=, ct_p3 = std::move(ct_p3)](Text expression_f_9755) {
            return ({
                auto tt_p4 = expression_f_9755;
                (crate::prelude::call_then(start_expression_f(e_p2x), [=, tt_p4 = std::move(tt_p4)](Text expression_f_9781) {
                return ({
                    auto et_p5 = expression_f_9781;
                    auto short_p6 = (!crate::syntax::lexer::chars::contains_f(prism_rtl::cat(tt_p4, et_p5), Text::lit("\n"))) && (crate::prelude::len_text(prism_rtl::cat(ct_p3, tt_p4, et_p5)) < Nat(70u));
                    (std::move(short_p6)
                    ? prism_rtl::finished(prism_rtl::cat("if ", ct_p3, " { ", tt_p4, " } else { ", et_p5, " }"))
                    : prism_rtl::finished(crate::emit::rust::templates::items::if_f(ct_p3, tt_p4, et_p5)));
                });
            }));
            });
        }));
        });
    });
}


/// `Start IfExpression, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_if_expression_f(crate::lower::model::Ex c_p0, crate::lower::model::Ex t_p1, crate::lower::model::Ex e_p2) {
    return prism_rtl::make_rc<IfExpression>(c_p0, t_p1, e_p2);
}


/// Arms: unbounded fn [XArm], Bool -> Text
Text arms_f(const Array<crate::lower::model::XArm>& arms_p0, const bool& fallback_p1) {
    auto lines_p2 = crate::prelude::run_to_end(crate::prelude::each_job(arms_p0, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::XArm)>>(prism_rtl::rc([=](crate::lower::model::XArm p0) {
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto a_p4 = p0;
                (prism_rtl::more(prism_rtl::rc(Arm(a_p4))));
            });
        }));
    }))));
    auto all_p3 = fallback_p1
        ? crate::prelude::push(lines_p2, Text::lit("_ => unreachable!(\"no arm matched\"),"))
        : lines_p2;
    return crate::syntax::lexer::chars::join_f(all_p3, Text::lit("\n"));
}


prism_rtl::Turn<Text> Arms::cycle() const {
    const auto& arms_p0 = this->arms_p0;
    const auto& fallback_p1 = this->fallback_p1;
    auto arms_p0x = arms_p0;
    auto fallback_p1x = prism_rtl::deref(fallback_p1);
    return crate::prelude::call_value(crate::prelude::each_job(arms_p0x, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::XArm)>>(prism_rtl::rc([=](crate::lower::model::XArm p0) {
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto a_p4 = p0;
                (prism_rtl::more(prism_rtl::rc(Arm(a_p4))));
            });
        }));
    }))), [=](Array<Text> each_10112) {
        return ({
            auto lines_p2 = each_10112;
            auto all_p3 = fallback_p1x
                ? crate::prelude::push(lines_p2, Text::lit("_ => unreachable!(\"no arm matched\"),"))
                : lines_p2;
            (prism_rtl::finished(crate::syntax::lexer::chars::join_f(all_p3, Text::lit("\n"))));
        });
    });
}


/// `Start Arms, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_arms_f(Array<crate::lower::model::XArm> arms_p0, bool fallback_p1) {
    return prism_rtl::make_rc<Arms>(arms_p0, fallback_p1);
}


/// Arm: unbounded fn XArm -> Text
Text arm_f(const crate::lower::model::XArm& a_p0) {
    auto guard_p1 = crate::prelude::len(a_p0.conds_p) == Nat(0u)
        ? Text::lit("")
        : prism_rtl::cat(" if ", crate::syntax::lexer::chars::join_f(crate::prelude::run_to_end(crate::prelude::each_job(a_p0.conds_p, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Cc)>>(prism_rtl::rc([=](crate::lower::model::Cc p0) {
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto c_p3 = p0;
                (prism_rtl::more(prism_rtl::rc(Condition(c_p3))));
            });
        }));
    })))), Text::lit(" && ")));
    auto body_p2 = expression_f(a_p0.body_p);
    return prism_rtl::cat(pattern_f(a_p0.pat_p), guard_p1, " => ", body_p2, ",");
}


prism_rtl::Turn<Text> Arm::cycle() const {
    const auto& a_p0 = this->a_p0;
    auto guard_p1 = crate::prelude::len(prism_rtl::deref(a_p0).conds_p) == Nat(0u)
        ? Text::lit("")
        : prism_rtl::cat(" if ", crate::syntax::lexer::chars::join_f(crate::prelude::run_to_end(crate::prelude::each_job(prism_rtl::deref(a_p0).conds_p, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Cc)>>(prism_rtl::rc([=](crate::lower::model::Cc p0) {
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto c_p3 = p0;
                (prism_rtl::more(prism_rtl::rc(Condition(c_p3))));
            });
        }));
    })))), Text::lit(" && ")));
    auto a_p0x = a_p0;
    return crate::prelude::call_then(start_expression_f(prism_rtl::deref(a_p0x).body_p), [=](Text expression_f_10404) {
        return ({
            auto body_p2 = expression_f_10404;
            (crate::prelude::call_then(start_pattern_f(prism_rtl::deref(a_p0x).pat_p), [=, body_p2 = std::move(body_p2)](Text pattern_f_10428) { return prism_rtl::finished(prism_rtl::cat(pattern_f_10428, guard_p1, " => ", body_p2, ",")); }));
        });
    });
}


/// `Start Arm, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_arm_f(crate::lower::model::XArm a_p0) {
    return prism_rtl::make_rc<Arm>(a_p0);
}


/// Condition: unbounded fn Cc -> Text
Text condition_f(const crate::lower::model::Cc& cc0) {
    if (prism_rtl::is<crate::lower::model::Cc::CcIf>(cc0)) {
        auto&& x_p0 = prism_rtl::as<crate::lower::model::Cc::CcIf>(cc0).a0;
        return operand_f(x_p0);
    }
    if (prism_rtl::is<crate::lower::model::Cc::CcLet>(cc0)) {
        auto&& p_p1 = prism_rtl::as<crate::lower::model::Cc::CcLet>(cc0).a0;
        auto&& x_p2 = prism_rtl::as<crate::lower::model::Cc::CcLet>(cc0).a1;
        return prism_rtl::cat("let ", pattern_f(p_p1), " = ", expression_f(x_p2));
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Text> Condition::cycle() const {
    const auto& cc0 = this->cc0;
    return ({
        prism_rtl::is<crate::lower::model::Cc::CcIf>(cc0) ? ({
        auto&& x_p0 = prism_rtl::as<crate::lower::model::Cc::CcIf>(cc0).a0;
        prism_rtl::more(prism_rtl::rc(Operand(x_p0)));
    })
        : prism_rtl::is<crate::lower::model::Cc::CcLet>(cc0) ? ({
        auto&& p_p1 = prism_rtl::as<crate::lower::model::Cc::CcLet>(cc0).a0;
        auto&& x_p2 = prism_rtl::as<crate::lower::model::Cc::CcLet>(cc0).a1;
        ({
        auto p_p1x = p_p1;
        auto x_p2x = x_p2;
        (crate::prelude::call_then(start_pattern_f(p_p1x), [=, x_p2x = std::move(x_p2x)](Text pattern_f_10566) { return crate::prelude::call_then(start_expression_f(x_p2x), [=](Text expression_f_10580) { return prism_rtl::finished(prism_rtl::cat("let ", pattern_f_10566, " = ", expression_f_10580)); }); }));
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start Condition, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_condition_f(crate::lower::model::Cc cc0) {
    return prism_rtl::make_rc<Condition>(cc0);
}


/// Chain: unbounded fn Text, Ex, [XArm] -> Text
Text chain_f(const Text& label_p0, const crate::lower::model::Ex& s_p1, const Array<crate::lower::model::XArm>& arms_p2) {
    auto in_place_p3 = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        if (prism_rtl::is<crate::lower::model::Ex::XRef>(s_p1)) {
            auto&& y_p8 = prism_rtl::as<crate::lower::model::Ex::XRef>(s_p1).a0;
            _v.set(is_bound_f(prism_rtl::deref(prism_rtl::deref(y_p8))));
            goto _done;
        }
        {
            _v.set(is_bound_f(s_p1));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto [bind_p9, scrut_pa] = std::move(in_place_p3)
        ? std::tuple{Array<Text>{}, expression_f(s_p1)}
        : std::tuple{Array(std::vector{prism_rtl::cat("let scrutinee = ", expression_f(s_p1), ";")}), Text::lit("scrutinee")};
    auto n_p4 = crate::prelude::len(arms_p2);
    auto lines_p5 = crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(n_p4), ({
        auto arms_p2x = arms_p2;
        auto scrut_pax = scrut_pa;
        auto label_p0x = label_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Nat)>>(prism_rtl::rc([=, arms_p2x = std::move(arms_p2x), scrut_pax = std::move(scrut_pax), label_p0x = std::move(label_p0x)](Nat p0) {
        return ({
            auto arms_p2xy = arms_p2x;
            auto scrut_paxy = scrut_pax;
            auto label_p0xy = label_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, arms_p2xy = std::move(arms_p2xy), scrut_paxy = std::move(scrut_paxy), label_p0xy = std::move(label_p0xy)]() {
            return ({
                auto i_pb = p0;
                ({
                auto a_pc = crate::prelude::or_(crate::prelude::index(arms_p2xy, i_pb), crate::lower::model::XArm{.pat_p = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds_p = Array<crate::lower::model::Cc>{}, .body_p = crate::lower::model::Ex(crate::lower::model::Ex::XUnit{})});
                auto catch_all_pd = (prism_rtl::deref(a_pc).pat_p == crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})) && (crate::prelude::len(prism_rtl::deref(a_pc).conds_p) == Nat(0u));
                (std::move(catch_all_pd)
                ? prism_rtl::more(prism_rtl::rc(Expression(prism_rtl::deref(a_pc).body_p)))
                : crate::prelude::call_then(start_pattern_f(prism_rtl::deref(a_pc).pat_p), [=](Text pattern_f_11293) {
                return crate::prelude::call_value(crate::prelude::each_job(prism_rtl::deref(a_pc).conds_p, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Cc)>>(prism_rtl::rc([=](crate::lower::model::Cc p0) {
                    return crate::prelude::entered(crate::prelude::once_job([=]() {
                        return ({
                            auto c_pf = p0;
                            (prism_rtl::more(prism_rtl::rc(Condition(c_pf))));
                        });
                    }));
                }))), [=](Array<Text> each_11323) {
                    return ({
                        auto head_pe = crate::syntax::lexer::chars::join_f(crate::prelude::append(Array(std::vector{prism_rtl::cat("let ", pattern_f_11293, " = ", scrut_paxy)}), each_11323), Text::lit(" && "));
                        (crate::prelude::call_then(start_expression_f(prism_rtl::deref(a_pc).body_p), [=, head_pe = std::move(head_pe)](Text expression_f_11410) { return prism_rtl::finished(crate::emit::rust::templates::items::chain_arm_f(head_pe, label_p0xy, continued_f(expression_f_11410, Text::lit("    ")))); }));
                    });
                });
            }));
            });
            });
        })));
        });
    })));
    })));
    auto ends_p6 = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = crate::syntax::lexer::chars::last_o(arms_p2);
        if (prism_rtl::is_some(_m)) {
            auto&& a_pg = prism_rtl::some_of(_m);
            _v.set((prism_rtl::deref(a_pg).pat_p == crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})) && (crate::prelude::len(prism_rtl::deref(a_pg).conds_p) == Nat(0u)));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(false);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto tail_p7 = std::move(ends_p6)
        ? Array<Text>{}
        : Array(std::vector{Text::lit("unreachable!(\"no clause matched\")")});
    return prism_rtl::cat(label_p0, ": {\n", indent_f(crate::syntax::lexer::chars::join_f(crate::prelude::append(crate::prelude::append(bind_p9, lines_p5), tail_p7), Text::lit("\n"))), "\n}");
}


prism_rtl::Turn<Text> Chain::cycle() const {
    const auto& label_p0 = this->label_p0;
    const auto& s_p1 = this->s_p1;
    const auto& arms_p2 = this->arms_p2;
    auto in_place_p3 = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        if (prism_rtl::is<crate::lower::model::Ex::XRef>(s_p1)) {
            auto&& y_p8 = prism_rtl::as<crate::lower::model::Ex::XRef>(s_p1).a0;
            _v.set(is_bound_f(prism_rtl::deref(prism_rtl::deref(y_p8))));
            goto _done;
        }
        {
            _v.set(is_bound_f(s_p1));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto [bind_p9, scrut_pa] = std::move(in_place_p3)
        ? std::tuple{Array<Text>{}, expression_f(s_p1)}
        : std::tuple{Array(std::vector{prism_rtl::cat("let scrutinee = ", expression_f(s_p1), ";")}), Text::lit("scrutinee")};
    auto n_p4 = crate::prelude::len(arms_p2);
    auto arms_p2x = arms_p2;
    auto label_p0x = label_p0;
    auto s_p1x = s_p1;
    return crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(n_p4), ({
        auto arms_p2xx = arms_p2x;
        auto scrut_pax = scrut_pa;
        auto label_p0xx = label_p0x;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Nat)>>(prism_rtl::rc([=, arms_p2xx = std::move(arms_p2xx), scrut_pax = std::move(scrut_pax), label_p0xx = std::move(label_p0xx)](Nat p0) {
        return ({
            auto arms_p2xxy = arms_p2xx;
            auto scrut_paxy = scrut_pax;
            auto label_p0xxy = label_p0xx;
            (crate::prelude::entered(crate::prelude::once_job([=, arms_p2xxy = std::move(arms_p2xxy), scrut_paxy = std::move(scrut_paxy), label_p0xxy = std::move(label_p0xxy)]() {
            return ({
                auto i_pb = p0;
                ({
                auto a_pc = crate::prelude::or_(crate::prelude::index(arms_p2xxy, i_pb), crate::lower::model::XArm{.pat_p = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds_p = Array<crate::lower::model::Cc>{}, .body_p = crate::lower::model::Ex(crate::lower::model::Ex::XUnit{})});
                auto catch_all_pd = (prism_rtl::deref(a_pc).pat_p == crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})) && (crate::prelude::len(prism_rtl::deref(a_pc).conds_p) == Nat(0u));
                (std::move(catch_all_pd)
                ? prism_rtl::more(prism_rtl::rc(Expression(prism_rtl::deref(a_pc).body_p)))
                : crate::prelude::call_then(start_pattern_f(prism_rtl::deref(a_pc).pat_p), [=](Text pattern_f_11293) {
                return crate::prelude::call_value(crate::prelude::each_job(prism_rtl::deref(a_pc).conds_p, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Cc)>>(prism_rtl::rc([=](crate::lower::model::Cc p0) {
                    return crate::prelude::entered(crate::prelude::once_job([=]() {
                        return ({
                            auto c_pf = p0;
                            (prism_rtl::more(prism_rtl::rc(Condition(c_pf))));
                        });
                    }));
                }))), [=](Array<Text> each_11323) {
                    return ({
                        auto head_pe = crate::syntax::lexer::chars::join_f(crate::prelude::append(Array(std::vector{prism_rtl::cat("let ", pattern_f_11293, " = ", scrut_paxy)}), each_11323), Text::lit(" && "));
                        (crate::prelude::call_then(start_expression_f(prism_rtl::deref(a_pc).body_p), [=, head_pe = std::move(head_pe)](Text expression_f_11410) { return prism_rtl::finished(crate::emit::rust::templates::items::chain_arm_f(head_pe, label_p0xxy, continued_f(expression_f_11410, Text::lit("    ")))); }));
                    });
                });
            }));
            });
            });
        })));
        });
    })));
    })), [=](Array<Text> each_11039) {
        return ({
            auto lines_p5 = each_11039;
            auto ends_p6 = ({
                __label__ _done;
                prism_rtl::Slot<bool> _v;
                auto&& _m = crate::syntax::lexer::chars::last_o(arms_p2x);
                if (prism_rtl::is_some(_m)) {
                    auto&& a_pg = prism_rtl::some_of(_m);
                    _v.set((prism_rtl::deref(a_pg).pat_p == crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})) && (crate::prelude::len(prism_rtl::deref(a_pg).conds_p) == Nat(0u)));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(false);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            auto tail_p7 = std::move(ends_p6)
                ? Array<Text>{}
                : Array(std::vector{Text::lit("unreachable!(\"no clause matched\")")});
            (prism_rtl::finished(prism_rtl::cat(label_p0x, ": {\n", indent_f(crate::syntax::lexer::chars::join_f(crate::prelude::append(crate::prelude::append(bind_p9, lines_p5), tail_p7), Text::lit("\n"))), "\n}")));
        });
    });
}


/// `Start Chain, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_chain_f(Text label_p0, crate::lower::model::Ex s_p1, Array<crate::lower::model::XArm> arms_p2) {
    return prism_rtl::make_rc<Chain>(label_p0, s_p1, arms_p2);
}


/// IsBound: fn Ex -> Bool
bool is_bound_f(const crate::lower::model::Ex& x_p0) {
    if (prism_rtl::is<crate::lower::model::Ex::XVar>(x_p0)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XField>(x_p0)) {
        auto&& m11914_1_0 = prism_rtl::as<crate::lower::model::Ex::XField>(x_p0).a0;
        if (prism_rtl::is<crate::lower::model::Ex::XSelf>(prism_rtl::deref(prism_rtl::deref(m11914_1_0)))) {
            return true;
        }
    }
    if (prism_rtl::is<crate::lower::model::Ex::XField>(x_p0)) {
        auto&& m11914_2_0 = prism_rtl::as<crate::lower::model::Ex::XField>(x_p0).a0;
        if (prism_rtl::is<crate::lower::model::Ex::XMethod>(prism_rtl::deref(prism_rtl::deref(m11914_2_0)))) {
            auto&& m11914_2_0_r_0 = prism_rtl::as<crate::lower::model::Ex::XMethod>(prism_rtl::deref(prism_rtl::deref(m11914_2_0))).a0;
            if (prism_rtl::is<crate::lower::model::Ex::XUpgrade>(prism_rtl::deref(prism_rtl::deref(m11914_2_0_r_0)))) {
                return true;
            }
        }
    }
    if (prism_rtl::is<crate::lower::model::Ex::XTarget>(x_p0)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XPart>(x_p0)) {
        auto&& m11914_4_0 = prism_rtl::as<crate::lower::model::Ex::XPart>(x_p0).a0;
        if (prism_rtl::is<crate::lower::model::Ex::XVar>(prism_rtl::deref(prism_rtl::deref(m11914_4_0)))) {
            return true;
        }
    }
    {
        return false;
    }
}


/// Continued: fn Text, Text -> Text
Text continued_f(const Text& t_p0, const Text& pad_p1) {
    auto ls_p2 = crate::prelude::split_on(t_p0, Text::lit("\n"));
    return crate::syntax::lexer::chars::join_f(crate::prelude::each(crate::check::errors::range0_f(crate::prelude::len(ls_p2)), [&](const Nat& i_p3) {
        return (i_p3 == Nat(0u)) || (crate::prelude::or_(crate::prelude::index(ls_p2, i_p3), Text::lit("")) == Text::lit(""))
            ? crate::prelude::or_(crate::prelude::index(ls_p2, i_p3), Text::lit(""))
            : prism_rtl::cat(pad_p1, crate::prelude::or_(crate::prelude::index(ls_p2, i_p3), Text::lit("")));
    }), Text::lit("\n"));
}


/// BodyLines: unbounded fn Ex -> Text
Text body_lines_f(const crate::lower::model::Ex& ex0) {
    if (prism_rtl::is<crate::lower::model::Ex::XBlock>(ex0)) {
        auto&& dos_p0 = prism_rtl::as<crate::lower::model::Ex::XBlock>(ex0).a0;
        auto&& e_p1 = prism_rtl::as<crate::lower::model::Ex::XBlock>(ex0).a1;
        return crate::prelude::len(dos_p0) == Nat(0u)
            ? body_lines_f(prism_rtl::deref(prism_rtl::deref(e_p1)))
            : prism_rtl::cat(statements_f(dos_p0), "\n", body_lines_f(prism_rtl::deref(prism_rtl::deref(e_p1))));
    }
    {
        auto&& x_p2 = ex0;
        return expression_f(x_p2);
    }
}


prism_rtl::Turn<Text> BodyLines::cycle() const {
    const auto& ex0 = this->ex0;
    return ({
        prism_rtl::is<crate::lower::model::Ex::XBlock>(ex0) ? ({
        auto&& dos_p0 = prism_rtl::as<crate::lower::model::Ex::XBlock>(ex0).a0;
        auto&& e_p1 = prism_rtl::as<crate::lower::model::Ex::XBlock>(ex0).a1;
        crate::prelude::len(dos_p0) == Nat(0u)
        ? prism_rtl::more(prism_rtl::rc(BodyLines(prism_rtl::deref(prism_rtl::deref(e_p1)))))
        : ({
        auto dos_p0x = dos_p0;
        auto e_p1x = prism_rtl::deref(prism_rtl::deref(e_p1));
        (crate::prelude::call_then(start_statements_f(dos_p0x), [=, e_p1x = std::move(e_p1x)](Text statements_f_12600) { return crate::prelude::call_then(start_body_lines_f(e_p1x), [=](Text body_lines_f_12618) { return prism_rtl::finished(prism_rtl::cat(statements_f_12600, "\n", body_lines_f_12618)); }); }));
    });
    })
        : ({
        auto&& x_p2 = ex0;
        prism_rtl::more(prism_rtl::rc(Expression(x_p2)));
    });
    });
}


/// `Start BodyLines, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_body_lines_f(crate::lower::model::Ex ex0) {
    return prism_rtl::make_rc<BodyLines>(ex0);
}


/// Indent: fn Text -> Text
Text indent_f(const Text& t_p0) {
    return crate::syntax::lexer::chars::join_f(crate::prelude::each(crate::prelude::split_on(t_p0, Text::lit("\n")), [&](const Text& l_p1) { return l_p1 == Text::lit("") ? Text::lit("") : prism_rtl::cat("    ", l_p1); }), Text::lit("\n"));
}


/// Pattern: unbounded fn Pa -> Text
Text pattern_f(const crate::lower::model::Pa& p_p0) {
    if (prism_rtl::is<crate::lower::model::Pa::PaWild>(p_p0)) {
        return Text::lit("_");
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaBind>(p_p0)) {
        auto&& n_p1 = prism_rtl::as<crate::lower::model::Pa::PaBind>(p_p0).a0;
        return n_p1;
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaMut>(p_p0)) {
        auto&& n_p2 = prism_rtl::as<crate::lower::model::Pa::PaMut>(p_p0).a0;
        return prism_rtl::cat("mut ", n_p2);
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaCtor>(p_p0)) {
        auto&& c_p3 = prism_rtl::as<crate::lower::model::Pa::PaCtor>(p_p0).a0;
        auto&& ps_p4 = prism_rtl::as<crate::lower::model::Pa::PaCtor>(p_p0).a1;
        return prism_rtl::cat(c_p3, "(", crate::syntax::lexer::chars::join_f(crate::prelude::run_to_end(crate::prelude::each_job(ps_p4, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Pa)>>(prism_rtl::rc([=](crate::lower::model::Pa p0) {
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto q_p5 = p0;
                    (prism_rtl::more(prism_rtl::rc(Pattern_(q_p5))));
                });
            }));
        })))), Text::lit(", ")), ")");
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaUnit>(p_p0)) {
        auto&& c_p6 = prism_rtl::as<crate::lower::model::Pa::PaUnit>(p_p0).a0;
        return c_p6;
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaRecord>(p_p0)) {
        auto&& c_p7 = prism_rtl::as<crate::lower::model::Pa::PaRecord>(p_p0).a0;
        auto&& fs_p8 = prism_rtl::as<crate::lower::model::Pa::PaRecord>(p_p0).a1;
        auto&& rest_p9 = prism_rtl::as<crate::lower::model::Pa::PaRecord>(p_p0).a2;
        auto parts_pa = crate::prelude::run_to_end(crate::prelude::each_job(fs_p8, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::Pa>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::Pa> p0) {
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto [f_pc, q_pd] = p0;
                    ({
                    prism_rtl::is<crate::lower::model::Pa::PaBind>(q_pd) ? ({
                    auto&& n_pe = prism_rtl::as<crate::lower::model::Pa::PaBind>(q_pd).a0;
                    n_pe == f_pc
                    ? prism_rtl::finished(f_pc)
                    : prism_rtl::finished(prism_rtl::cat(f_pc, ": ", n_pe));
                })
                    : crate::prelude::call_then(start_pattern_f(q_pd), [=](Text pattern_f_13371) { return prism_rtl::finished(prism_rtl::cat(f_pc, ": ", pattern_f_13371)); });
                });
                });
            }));
        }))));
        auto all_pb = prism_rtl::deref(rest_p9)
            ? crate::prelude::push(parts_pa, Text::lit(".."))
            : parts_pa;
        return prism_rtl::cat(c_p7, " { ", crate::syntax::lexer::chars::join_f(all_pb, Text::lit(", ")), " }");
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaTuple>(p_p0)) {
        auto&& m13069_6_0 = prism_rtl::as<crate::lower::model::Pa::PaTuple>(p_p0).a0;
        if (m13069_6_0.size() == 1u) {
            {
                auto&& _c1 = crate::prelude::index(m13069_6_0, Nat(0u));
                if (prism_rtl::is_some(_c1)) {
                    auto&& one_pf = prism_rtl::some_of(_c1);
                    return prism_rtl::cat("(", pattern_f(one_pf), ",)");
                }
            }
        }
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaTuple>(p_p0)) {
        auto&& ps_pg = prism_rtl::as<crate::lower::model::Pa::PaTuple>(p_p0).a0;
        return prism_rtl::cat("(", crate::syntax::lexer::chars::join_f(crate::prelude::run_to_end(crate::prelude::each_job(ps_pg, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Pa)>>(prism_rtl::rc([=](crate::lower::model::Pa p0) {
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto q_ph = p0;
                    (prism_rtl::more(prism_rtl::rc(Pattern_(q_ph))));
                });
            }));
        })))), Text::lit(", ")), ")");
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaChar>(p_p0)) {
        auto&& c_pi = prism_rtl::as<crate::lower::model::Pa::PaChar>(p_p0).a0;
        return prism_rtl::cat("\'", crate::lower::expr::char_escape_f(c_pi), "\'");
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaBool>(p_p0)) {
        auto&& b_pj = prism_rtl::as<crate::lower::model::Pa::PaBool>(p_p0).a0;
        return prism_rtl::deref(b_pj) ? Text::lit("true") : Text::lit("false");
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaIndex>(p_p0)) {
        auto&& n_pk = prism_rtl::as<crate::lower::model::Pa::PaIndex>(p_p0).a0;
        return prism_rtl::cat(n_pk);
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaConst>(p_p0)) {
        auto&& n_pl = prism_rtl::as<crate::lower::model::Pa::PaConst>(p_p0).a0;
        return prism_rtl::cat("Self::", n_pl);
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaSlice>(p_p0)) {
        auto&& ps_pm = prism_rtl::as<crate::lower::model::Pa::PaSlice>(p_p0).a0;
        return prism_rtl::cat("[", crate::syntax::lexer::chars::join_f(crate::prelude::run_to_end(crate::prelude::each_job(ps_pm, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Pa)>>(prism_rtl::rc([=](crate::lower::model::Pa p0) {
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto q_pn = p0;
                    (prism_rtl::more(prism_rtl::rc(Pattern_(q_pn))));
                });
            }));
        })))), Text::lit(", ")), "]");
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaRest>(p_p0)) {
        auto&& m13069_13_0 = prism_rtl::as<crate::lower::model::Pa::PaRest>(p_p0).a0;
        if (m13069_13_0 == Text::lit("")) {
            return Text::lit("..");
        }
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaRest>(p_p0)) {
        auto&& n_po = prism_rtl::as<crate::lower::model::Pa::PaRest>(p_p0).a0;
        return prism_rtl::cat(n_po, " @ ..");
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaTyped>(p_p0)) {
        auto&& q_pp = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_p0).a0;
        auto&& t_pq = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_p0).a1;
        return prism_rtl::cat(pattern_f(prism_rtl::deref(prism_rtl::deref(q_pp))), ": ", type_f(t_pq));
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Text> Pattern_::cycle() const {
    const auto& p_p0 = this->p_p0;
    return ({
        prism_rtl::is<crate::lower::model::Pa::PaWild>(p_p0) ? prism_rtl::finished(Text::lit("_"))
        : prism_rtl::is<crate::lower::model::Pa::PaBind>(p_p0) ? ({
        auto&& n_p1 = prism_rtl::as<crate::lower::model::Pa::PaBind>(p_p0).a0;
        prism_rtl::finished(n_p1);
    })
        : prism_rtl::is<crate::lower::model::Pa::PaMut>(p_p0) ? ({
        auto&& n_p2 = prism_rtl::as<crate::lower::model::Pa::PaMut>(p_p0).a0;
        prism_rtl::finished(prism_rtl::cat("mut ", n_p2));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaCtor>(p_p0) ? ({
        auto&& c_p3 = prism_rtl::as<crate::lower::model::Pa::PaCtor>(p_p0).a0;
        auto&& ps_p4 = prism_rtl::as<crate::lower::model::Pa::PaCtor>(p_p0).a1;
        ({
        auto c_p3x = c_p3;
        auto ps_p4x = ps_p4;
        (crate::prelude::call_value(crate::prelude::each_job(ps_p4x, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Pa)>>(prism_rtl::rc([=](crate::lower::model::Pa p0) {
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto q_p5 = p0;
                (prism_rtl::more(prism_rtl::rc(Pattern_(q_p5))));
            });
        }));
    }))), [=, c_p3x = std::move(c_p3x)](Array<Text> each_13163) { return prism_rtl::finished(prism_rtl::cat(c_p3x, "(", crate::syntax::lexer::chars::join_f(each_13163, Text::lit(", ")), ")")); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Pa::PaUnit>(p_p0) ? ({
        auto&& c_p6 = prism_rtl::as<crate::lower::model::Pa::PaUnit>(p_p0).a0;
        prism_rtl::finished(c_p6);
    })
        : prism_rtl::is<crate::lower::model::Pa::PaRecord>(p_p0) ? ({
        auto&& c_p7 = prism_rtl::as<crate::lower::model::Pa::PaRecord>(p_p0).a0;
        auto&& fs_p8 = prism_rtl::as<crate::lower::model::Pa::PaRecord>(p_p0).a1;
        auto&& rest_p9 = prism_rtl::as<crate::lower::model::Pa::PaRecord>(p_p0).a2;
        ({
        auto c_p7x = c_p7;
        auto fs_p8x = fs_p8;
        auto rest_p9x = prism_rtl::deref(rest_p9);
        (crate::prelude::call_value(crate::prelude::each_job(fs_p8x, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::Pa>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::Pa> p0) {
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto [f_pc, q_pd] = p0;
                ({
                prism_rtl::is<crate::lower::model::Pa::PaBind>(q_pd) ? ({
                auto&& n_pe = prism_rtl::as<crate::lower::model::Pa::PaBind>(q_pd).a0;
                n_pe == f_pc
                ? prism_rtl::finished(f_pc)
                : prism_rtl::finished(prism_rtl::cat(f_pc, ": ", n_pe));
            })
                : crate::prelude::call_then(start_pattern_f(q_pd), [=](Text pattern_f_13371) { return prism_rtl::finished(prism_rtl::cat(f_pc, ": ", pattern_f_13371)); });
            });
            });
        }));
    }))), [=, c_p7x = std::move(c_p7x), rest_p9x = std::move(rest_p9x)](Array<Text> each_13259) {
        return ({
            auto parts_pa = each_13259;
            auto all_pb = rest_p9x ? crate::prelude::push(parts_pa, Text::lit("..")) : parts_pa;
            (prism_rtl::finished(prism_rtl::cat(c_p7x, " { ", crate::syntax::lexer::chars::join_f(all_pb, Text::lit(", ")), " }")));
        });
    }));
    });
    })
        : prism_rtl::is<crate::lower::model::Pa::PaTuple>(p_p0) && ({
        auto&& m13069_6_0 = prism_rtl::as<crate::lower::model::Pa::PaTuple>(p_p0).a0;
        (m13069_6_0.size() == 1u) && ({
        auto&& _c1 = crate::prelude::index(m13069_6_0, Nat(0u));
        prism_rtl::is_some(_c1);
    });
    }) ? ({
        auto&& m13069_6_0 = prism_rtl::as<crate::lower::model::Pa::PaTuple>(p_p0).a0;
        auto&& _c1 = crate::prelude::index(m13069_6_0, Nat(0u));
        auto&& one_pf = prism_rtl::some_of(_c1);
        crate::prelude::call_then(start_pattern_f(one_pf), [=](Text pattern_f_13500) { return prism_rtl::finished(prism_rtl::cat("(", pattern_f_13500, ",)")); });
    })
        : prism_rtl::is<crate::lower::model::Pa::PaTuple>(p_p0) ? ({
        auto&& ps_pg = prism_rtl::as<crate::lower::model::Pa::PaTuple>(p_p0).a0;
        ({
        auto ps_pgx = ps_pg;
        (crate::prelude::call_value(crate::prelude::each_job(ps_pgx, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Pa)>>(prism_rtl::rc([=](crate::lower::model::Pa p0) {
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto q_ph = p0;
                (prism_rtl::more(prism_rtl::rc(Pattern_(q_ph))));
            });
        }));
    }))), [=](Array<Text> each_13541) { return prism_rtl::finished(prism_rtl::cat("(", crate::syntax::lexer::chars::join_f(each_13541, Text::lit(", ")), ")")); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Pa::PaChar>(p_p0) ? ({
        auto&& c_pi = prism_rtl::as<crate::lower::model::Pa::PaChar>(p_p0).a0;
        prism_rtl::finished(prism_rtl::cat("\'", crate::lower::expr::char_escape_f(c_pi), "\'"));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaBool>(p_p0) ? ({
        auto&& b_pj = prism_rtl::as<crate::lower::model::Pa::PaBool>(p_p0).a0;
        prism_rtl::deref(b_pj)
        ? prism_rtl::finished(Text::lit("true"))
        : prism_rtl::finished(Text::lit("false"));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaIndex>(p_p0) ? ({
        auto&& n_pk = prism_rtl::as<crate::lower::model::Pa::PaIndex>(p_p0).a0;
        prism_rtl::finished(prism_rtl::cat(n_pk));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaConst>(p_p0) ? ({
        auto&& n_pl = prism_rtl::as<crate::lower::model::Pa::PaConst>(p_p0).a0;
        prism_rtl::finished(prism_rtl::cat("Self::", n_pl));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaSlice>(p_p0) ? ({
        auto&& ps_pm = prism_rtl::as<crate::lower::model::Pa::PaSlice>(p_p0).a0;
        ({
        auto ps_pmx = ps_pm;
        (crate::prelude::call_value(crate::prelude::each_job(ps_pmx, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Pa)>>(prism_rtl::rc([=](crate::lower::model::Pa p0) {
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto q_pn = p0;
                (prism_rtl::more(prism_rtl::rc(Pattern_(q_pn))));
            });
        }));
    }))), [=](Array<Text> each_13722) { return prism_rtl::finished(prism_rtl::cat("[", crate::syntax::lexer::chars::join_f(each_13722, Text::lit(", ")), "]")); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Pa::PaRest>(p_p0) && ({
        auto&& m13069_13_0 = prism_rtl::as<crate::lower::model::Pa::PaRest>(p_p0).a0;
        (m13069_13_0 == Text::lit(""));
    }) ? ({
        auto&& m13069_13_0 = prism_rtl::as<crate::lower::model::Pa::PaRest>(p_p0).a0;
        prism_rtl::finished(Text::lit(".."));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaRest>(p_p0) ? ({
        auto&& n_po = prism_rtl::as<crate::lower::model::Pa::PaRest>(p_p0).a0;
        prism_rtl::finished(prism_rtl::cat(n_po, " @ .."));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaTyped>(p_p0) ? ({
        auto&& q_pp = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_p0).a0;
        auto&& t_pq = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_p0).a1;
        ({
        auto q_ppx = prism_rtl::deref(prism_rtl::deref(q_pp));
        auto t_pqx = t_pq;
        (crate::prelude::call_then(start_pattern_f(q_ppx), [=, t_pqx = std::move(t_pqx)](Text pattern_f_13821) { return crate::prelude::call_then(start_type_f(t_pqx), [=](Text type_f_13834) { return prism_rtl::finished(prism_rtl::cat(pattern_f_13821, ": ", type_f_13834)); }); }));
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start Pattern_, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_pattern_f(crate::lower::model::Pa p_p0) {
    return prism_rtl::make_rc<Pattern_>(p_p0);
}


/// Statements: unbounded fn [Do] -> Text
Text statements_f(const Array<crate::lower::model::Do>& dos_p0) {
    return crate::syntax::lexer::chars::join_f(crate::prelude::run_to_end(crate::prelude::each_job(dos_p0, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Do)>>(prism_rtl::rc([=](crate::lower::model::Do p0) {
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto d_p1 = p0;
                (prism_rtl::more(prism_rtl::rc(Statement(d_p1))));
            });
        }));
    })))), Text::lit("\n"));
}


prism_rtl::Turn<Text> Statements::cycle() const {
    const auto& dos_p0 = this->dos_p0;
    auto dos_p0x = dos_p0;
    return crate::prelude::call_value(crate::prelude::each_job(dos_p0x, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Do)>>(prism_rtl::rc([=](crate::lower::model::Do p0) {
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto d_p1 = p0;
                (prism_rtl::more(prism_rtl::rc(Statement(d_p1))));
            });
        }));
    }))), [=](Array<Text> each_13908) { return prism_rtl::finished(crate::syntax::lexer::chars::join_f(each_13908, Text::lit("\n"))); });
}


/// `Start Statements, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_statements_f(Array<crate::lower::model::Do> dos_p0) {
    return prism_rtl::make_rc<Statements>(dos_p0);
}


/// Statement: unbounded fn Do -> Text
Text statement_f(const crate::lower::model::Do& d_p0) {
    if (prism_rtl::is<crate::lower::model::Do::DoLet>(d_p0)) {
        auto&& p_p1 = prism_rtl::as<crate::lower::model::Do::DoLet>(d_p0).a0;
        auto&& x_p2 = prism_rtl::as<crate::lower::model::Do::DoLet>(d_p0).a1;
        return prism_rtl::cat("let ", pattern_f(p_p1), " = ", expression_f(x_p2), ";");
    }
    if (prism_rtl::is<crate::lower::model::Do::DoLetElse>(d_p0)) {
        auto&& p_p3 = prism_rtl::as<crate::lower::model::Do::DoLetElse>(d_p0).a0;
        auto&& x_p4 = prism_rtl::as<crate::lower::model::Do::DoLetElse>(d_p0).a1;
        auto&& e_p5 = prism_rtl::as<crate::lower::model::Do::DoLetElse>(d_p0).a2;
        return prism_rtl::cat("let ", pattern_f(p_p3), " = ", expression_f(x_p4), " else { ", expression_f(e_p5), " };");
    }
    if (prism_rtl::is<crate::lower::model::Do::DoAssign>(d_p0)) {
        auto&& p_p6 = prism_rtl::as<crate::lower::model::Do::DoAssign>(d_p0).a0;
        auto&& x_p7 = prism_rtl::as<crate::lower::model::Do::DoAssign>(d_p0).a1;
        return prism_rtl::cat(expression_f(p_p6), " = ", expression_f(x_p7), ";");
    }
    if (prism_rtl::is<crate::lower::model::Do::DoWhile>(d_p0)) {
        auto&& c_p8 = prism_rtl::as<crate::lower::model::Do::DoWhile>(d_p0).a0;
        auto&& body_p9 = prism_rtl::as<crate::lower::model::Do::DoWhile>(d_p0).a1;
        return crate::emit::rust::templates::items::if_stmt_f(prism_rtl::cat("while ", expression_f(c_p8)), statements_f(body_p9));
    }
    if (prism_rtl::is<crate::lower::model::Do::DoWhileLet>(d_p0)) {
        auto&& p_pa = prism_rtl::as<crate::lower::model::Do::DoWhileLet>(d_p0).a0;
        auto&& x_pb = prism_rtl::as<crate::lower::model::Do::DoWhileLet>(d_p0).a1;
        auto&& body_pc = prism_rtl::as<crate::lower::model::Do::DoWhileLet>(d_p0).a2;
        return crate::emit::rust::templates::items::if_stmt_f(prism_rtl::cat("while let ", pattern_f(p_pa), " = ", expression_f(x_pb)), statements_f(body_pc));
    }
    if (prism_rtl::is<crate::lower::model::Do::DoFor>(d_p0)) {
        auto&& p_pd = prism_rtl::as<crate::lower::model::Do::DoFor>(d_p0).a0;
        auto&& x_pe = prism_rtl::as<crate::lower::model::Do::DoFor>(d_p0).a1;
        auto&& body_pf = prism_rtl::as<crate::lower::model::Do::DoFor>(d_p0).a2;
        return crate::emit::rust::templates::items::if_stmt_f(prism_rtl::cat("for ", pattern_f(p_pd), " in ", expression_f(x_pe)), statements_f(body_pf));
    }
    if (prism_rtl::is<crate::lower::model::Do::DoExpr>(d_p0)) {
        auto&& x_pg = prism_rtl::as<crate::lower::model::Do::DoExpr>(d_p0).a0;
        return prism_rtl::cat(expression_f(x_pg), ";");
    }
    if (prism_rtl::is<crate::lower::model::Do::DoIf>(d_p0)) {
        auto&& c_ph = prism_rtl::as<crate::lower::model::Do::DoIf>(d_p0).a0;
        auto&& t_pi = prism_rtl::as<crate::lower::model::Do::DoIf>(d_p0).a1;
        auto&& e_pj = prism_rtl::as<crate::lower::model::Do::DoIf>(d_p0).a2;
        return prism_rtl::cat(crate::emit::rust::templates::items::if_stmt_f(prism_rtl::cat("if ", expression_f(c_ph)), statements_f(t_pi)), else_branch_f(e_pj));
    }
    if (prism_rtl::is<crate::lower::model::Do::DoIfLet>(d_p0)) {
        auto&& p_pk = prism_rtl::as<crate::lower::model::Do::DoIfLet>(d_p0).a0;
        auto&& x_pl = prism_rtl::as<crate::lower::model::Do::DoIfLet>(d_p0).a1;
        auto&& t_pm = prism_rtl::as<crate::lower::model::Do::DoIfLet>(d_p0).a2;
        auto&& e_pn = prism_rtl::as<crate::lower::model::Do::DoIfLet>(d_p0).a3;
        return prism_rtl::cat(crate::emit::rust::templates::items::if_stmt_f(prism_rtl::cat("if let ", pattern_f(p_pk), " = ", expression_f(x_pl)), statements_f(t_pm)), else_branch_f(e_pn));
    }
    if (prism_rtl::is<crate::lower::model::Do::DoMatch>(d_p0)) {
        auto&& x_po = prism_rtl::as<crate::lower::model::Do::DoMatch>(d_p0).a0;
        auto&& cases_pp = prism_rtl::as<crate::lower::model::Do::DoMatch>(d_p0).a1;
        return crate::emit::rust::templates::items::match_block_f(expression_f(x_po), crate::syntax::lexer::chars::join_f(crate::prelude::run_to_end(crate::prelude::each_job(cases_pp, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<crate::lower::model::Pa, Array<crate::lower::model::Do>>)>>(prism_rtl::rc([=](std::tuple<crate::lower::model::Pa, Array<crate::lower::model::Do>> p0) {
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto [p_pq, body_pr] = p0;
                    (crate::prelude::call_then(start_pattern_f(p_pq), [=](Text pattern_f_14750) { return crate::prelude::call_then(start_statements_f(body_pr), [=](Text statements_f_14763) { return prism_rtl::finished(crate::emit::rust::templates::items::arm_block_f(pattern_f_14750, statements_f_14763)); }); }));
                });
            }));
        })))), Text::lit("\n")));
    }
    if (prism_rtl::is<crate::lower::model::Do::DoReturn>(d_p0)) {
        auto&& x_ps = prism_rtl::as<crate::lower::model::Do::DoReturn>(d_p0).a0;
        return prism_rtl::cat("return ", expression_f(x_ps), ";");
    }
    if (prism_rtl::is<crate::lower::model::Do::DoBlock>(d_p0)) {
        auto&& body_pt = prism_rtl::as<crate::lower::model::Do::DoBlock>(d_p0).a0;
        return crate::emit::rust::templates::items::scope_f(statements_f(body_pt));
    }
    if (prism_rtl::is<crate::lower::model::Do::DoScope>(d_p0)) {
        auto&& body_pu = prism_rtl::as<crate::lower::model::Do::DoScope>(d_p0).a0;
        return prism_rtl::cat("{ ", inline_statements_f(body_pu), " };");
    }
    if (prism_rtl::is<crate::lower::model::Do::DoLine>(d_p0)) {
        auto&& body_pv = prism_rtl::as<crate::lower::model::Do::DoLine>(d_p0).a0;
        return prism_rtl::cat(inline_statements_f(body_pv), ";");
    }
    if (prism_rtl::is<crate::lower::model::Do::DoNote>(d_p0)) {
        auto&& t_p10 = prism_rtl::as<crate::lower::model::Do::DoNote>(d_p0).a0;
        return prism_rtl::cat("// ", t_p10);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Text> Statement::cycle() const {
    const auto& d_p0 = this->d_p0;
    return ({
        prism_rtl::is<crate::lower::model::Do::DoLet>(d_p0) ? ({
        auto&& p_p1 = prism_rtl::as<crate::lower::model::Do::DoLet>(d_p0).a0;
        auto&& x_p2 = prism_rtl::as<crate::lower::model::Do::DoLet>(d_p0).a1;
        ({
        auto p_p1x = p_p1;
        auto x_p2x = x_p2;
        (crate::prelude::call_then(start_pattern_f(p_p1x), [=, x_p2x = std::move(x_p2x)](Text pattern_f_14026) { return crate::prelude::call_then(start_expression_f(x_p2x), [=](Text expression_f_14040) { return prism_rtl::finished(prism_rtl::cat("let ", pattern_f_14026, " = ", expression_f_14040, ";")); }); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Do::DoLetElse>(d_p0) ? ({
        auto&& p_p3 = prism_rtl::as<crate::lower::model::Do::DoLetElse>(d_p0).a0;
        auto&& x_p4 = prism_rtl::as<crate::lower::model::Do::DoLetElse>(d_p0).a1;
        auto&& e_p5 = prism_rtl::as<crate::lower::model::Do::DoLetElse>(d_p0).a2;
        ({
        auto e_p5x = e_p5;
        auto p_p3x = p_p3;
        auto x_p4x = x_p4;
        (crate::prelude::call_then(start_pattern_f(p_p3x), [=, e_p5x = std::move(e_p5x), x_p4x = std::move(x_p4x)](Text pattern_f_14085) { return crate::prelude::call_then(start_expression_f(x_p4x), [=](Text expression_f_14099) { return crate::prelude::call_then(start_expression_f(e_p5x), [=](Text expression_f_14122) { return prism_rtl::finished(prism_rtl::cat("let ", pattern_f_14085, " = ", expression_f_14099, " else { ", expression_f_14122, " };")); }); }); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Do::DoAssign>(d_p0) ? ({
        auto&& p_p6 = prism_rtl::as<crate::lower::model::Do::DoAssign>(d_p0).a0;
        auto&& x_p7 = prism_rtl::as<crate::lower::model::Do::DoAssign>(d_p0).a1;
        ({
        auto p_p6x = p_p6;
        auto x_p7x = x_p7;
        (crate::prelude::call_then(start_expression_f(p_p6x), [=, x_p7x = std::move(x_p7x)](Text expression_f_14162) { return crate::prelude::call_then(start_expression_f(x_p7x), [=](Text expression_f_14179) { return prism_rtl::finished(prism_rtl::cat(expression_f_14162, " = ", expression_f_14179, ";")); }); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Do::DoWhile>(d_p0) ? ({
        auto&& c_p8 = prism_rtl::as<crate::lower::model::Do::DoWhile>(d_p0).a0;
        auto&& body_p9 = prism_rtl::as<crate::lower::model::Do::DoWhile>(d_p0).a1;
        ({
        auto body_p9x = body_p9;
        auto c_p8x = c_p8;
        (crate::prelude::call_then(start_expression_f(c_p8x), [=, body_p9x = std::move(body_p9x)](Text expression_f_14231) { return crate::prelude::call_then(start_statements_f(body_p9x), [=](Text statements_f_14248) { return prism_rtl::finished(crate::emit::rust::templates::items::if_stmt_f(prism_rtl::cat("while ", expression_f_14231), statements_f_14248)); }); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Do::DoWhileLet>(d_p0) ? ({
        auto&& p_pa = prism_rtl::as<crate::lower::model::Do::DoWhileLet>(d_p0).a0;
        auto&& x_pb = prism_rtl::as<crate::lower::model::Do::DoWhileLet>(d_p0).a1;
        auto&& body_pc = prism_rtl::as<crate::lower::model::Do::DoWhileLet>(d_p0).a2;
        ({
        auto body_pcx = body_pc;
        auto p_pax = p_pa;
        auto x_pbx = x_pb;
        (crate::prelude::call_then(start_pattern_f(p_pax), [=, body_pcx = std::move(body_pcx), x_pbx = std::move(x_pbx)](Text pattern_f_14311) { return crate::prelude::call_then(start_expression_f(x_pbx), [=](Text expression_f_14325) { return crate::prelude::call_then(start_statements_f(body_pcx), [=](Text statements_f_14342) { return prism_rtl::finished(crate::emit::rust::templates::items::if_stmt_f(prism_rtl::cat("while let ", pattern_f_14311, " = ", expression_f_14325), statements_f_14342)); }); }); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Do::DoFor>(d_p0) ? ({
        auto&& p_pd = prism_rtl::as<crate::lower::model::Do::DoFor>(d_p0).a0;
        auto&& x_pe = prism_rtl::as<crate::lower::model::Do::DoFor>(d_p0).a1;
        auto&& body_pf = prism_rtl::as<crate::lower::model::Do::DoFor>(d_p0).a2;
        ({
        auto body_pfx = body_pf;
        auto p_pdx = p_pd;
        auto x_pex = x_pe;
        (crate::prelude::call_then(start_pattern_f(p_pdx), [=, body_pfx = std::move(body_pfx), x_pex = std::move(x_pex)](Text pattern_f_14394) { return crate::prelude::call_then(start_expression_f(x_pex), [=](Text expression_f_14409) { return crate::prelude::call_then(start_statements_f(body_pfx), [=](Text statements_f_14426) { return prism_rtl::finished(crate::emit::rust::templates::items::if_stmt_f(prism_rtl::cat("for ", pattern_f_14394, " in ", expression_f_14409), statements_f_14426)); }); }); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Do::DoExpr>(d_p0) ? ({
        auto&& x_pg = prism_rtl::as<crate::lower::model::Do::DoExpr>(d_p0).a0;
        ({
        auto x_pgx = x_pg;
        (crate::prelude::call_then(start_expression_f(x_pgx), [=](Text expression_f_14459) { return prism_rtl::finished(prism_rtl::cat(expression_f_14459, ";")); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Do::DoIf>(d_p0) ? ({
        auto&& c_ph = prism_rtl::as<crate::lower::model::Do::DoIf>(d_p0).a0;
        auto&& t_pi = prism_rtl::as<crate::lower::model::Do::DoIf>(d_p0).a1;
        auto&& e_pj = prism_rtl::as<crate::lower::model::Do::DoIf>(d_p0).a2;
        ({
        auto c_phx = c_ph;
        auto e_pjx = e_pj;
        auto t_pix = t_pi;
        (crate::prelude::call_then(start_expression_f(c_phx), [=, e_pjx = std::move(e_pjx), t_pix = std::move(t_pix)](Text expression_f_14507) { return crate::prelude::call_then(start_statements_f(t_pix), [=](Text statements_f_14524) { return crate::prelude::call_then(start_else_branch_f(e_pjx), [=](Text else_branch_f_14539) { return prism_rtl::finished(prism_rtl::cat(crate::emit::rust::templates::items::if_stmt_f(prism_rtl::cat("if ", expression_f_14507), statements_f_14524), else_branch_f_14539)); }); }); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Do::DoIfLet>(d_p0) ? ({
        auto&& p_pk = prism_rtl::as<crate::lower::model::Do::DoIfLet>(d_p0).a0;
        auto&& x_pl = prism_rtl::as<crate::lower::model::Do::DoIfLet>(d_p0).a1;
        auto&& t_pm = prism_rtl::as<crate::lower::model::Do::DoIfLet>(d_p0).a2;
        auto&& e_pn = prism_rtl::as<crate::lower::model::Do::DoIfLet>(d_p0).a3;
        ({
        auto e_pnx = e_pn;
        auto p_pkx = p_pk;
        auto t_pmx = t_pm;
        auto x_plx = x_pl;
        (crate::prelude::call_then(start_pattern_f(p_pkx), [=, e_pnx = std::move(e_pnx), t_pmx = std::move(t_pmx), x_plx = std::move(x_plx)](Text pattern_f_14596) { return crate::prelude::call_then(start_expression_f(x_plx), [=](Text expression_f_14610) { return crate::prelude::call_then(start_statements_f(t_pmx), [=](Text statements_f_14627) { return crate::prelude::call_then(start_else_branch_f(e_pnx), [=](Text else_branch_f_14642) { return prism_rtl::finished(prism_rtl::cat(crate::emit::rust::templates::items::if_stmt_f(prism_rtl::cat("if let ", pattern_f_14596, " = ", expression_f_14610), statements_f_14627), else_branch_f_14642)); }); }); }); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Do::DoMatch>(d_p0) ? ({
        auto&& x_po = prism_rtl::as<crate::lower::model::Do::DoMatch>(d_p0).a0;
        auto&& cases_pp = prism_rtl::as<crate::lower::model::Do::DoMatch>(d_p0).a1;
        ({
        auto cases_ppx = cases_pp;
        auto x_pox = x_po;
        (crate::prelude::call_then(start_expression_f(x_pox), [=, cases_ppx = std::move(cases_ppx)](Text expression_f_14691) {
        return crate::prelude::call_value(crate::prelude::each_job(cases_ppx, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<crate::lower::model::Pa, Array<crate::lower::model::Do>>)>>(prism_rtl::rc([=](std::tuple<crate::lower::model::Pa, Array<crate::lower::model::Do>> p0) {
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto [p_pq, body_pr] = p0;
                    (crate::prelude::call_then(start_pattern_f(p_pq), [=](Text pattern_f_14750) { return crate::prelude::call_then(start_statements_f(body_pr), [=](Text statements_f_14763) { return prism_rtl::finished(crate::emit::rust::templates::items::arm_block_f(pattern_f_14750, statements_f_14763)); }); }));
                });
            }));
        }))), [=](Array<Text> each_14713) { return prism_rtl::finished(crate::emit::rust::templates::items::match_block_f(expression_f_14691, crate::syntax::lexer::chars::join_f(each_14713, Text::lit("\n")))); });
    }));
    });
    })
        : prism_rtl::is<crate::lower::model::Do::DoReturn>(d_p0) ? ({
        auto&& x_ps = prism_rtl::as<crate::lower::model::Do::DoReturn>(d_p0).a0;
        ({
        auto x_psx = x_ps;
        (crate::prelude::call_then(start_expression_f(x_psx), [=](Text expression_f_14813) { return prism_rtl::finished(prism_rtl::cat("return ", expression_f_14813, ";")); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Do::DoBlock>(d_p0) ? ({
        auto&& body_pt = prism_rtl::as<crate::lower::model::Do::DoBlock>(d_p0).a0;
        ({
        auto body_ptx = body_pt;
        (crate::prelude::call_then(start_statements_f(body_ptx), [=](Text statements_f_14854) { return prism_rtl::finished(crate::emit::rust::templates::items::scope_f(statements_f_14854)); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Do::DoScope>(d_p0) ? ({
        auto&& body_pu = prism_rtl::as<crate::lower::model::Do::DoScope>(d_p0).a0;
        ({
        auto body_pux = body_pu;
        (crate::prelude::call_then(start_inline_statements_f(body_pux), [=](Text inline_statements_f_14894) { return prism_rtl::finished(prism_rtl::cat("{ ", inline_statements_f_14894, " };")); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Do::DoLine>(d_p0) ? ({
        auto&& body_pv = prism_rtl::as<crate::lower::model::Do::DoLine>(d_p0).a0;
        ({
        auto body_pvx = body_pv;
        (crate::prelude::call_then(start_inline_statements_f(body_pvx), [=](Text inline_statements_f_14941) { return prism_rtl::finished(prism_rtl::cat(inline_statements_f_14941, ";")); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Do::DoNote>(d_p0) ? ({
        auto&& t_p10 = prism_rtl::as<crate::lower::model::Do::DoNote>(d_p0).a0;
        prism_rtl::finished(prism_rtl::cat("// ", t_p10));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start Statement, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_statement_f(crate::lower::model::Do d_p0) {
    return prism_rtl::make_rc<Statement>(d_p0);
}


/// InlineStatements: unbounded fn [Do] -> Text
Text inline_statements_f(const Array<crate::lower::model::Do>& dos_p0) {
    return crate::syntax::lexer::chars::join_f(crate::prelude::run_to_end(crate::prelude::each_job(dos_p0, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Do)>>(prism_rtl::rc([=](crate::lower::model::Do p0) {
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto d_p1 = p0;
                (prism_rtl::more(prism_rtl::rc(InlineStatement(d_p1))));
            });
        }));
    })))), Text::lit(" "));
}


prism_rtl::Turn<Text> InlineStatements::cycle() const {
    const auto& dos_p0 = this->dos_p0;
    auto dos_p0x = dos_p0;
    return crate::prelude::call_value(crate::prelude::each_job(dos_p0x, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Do)>>(prism_rtl::rc([=](crate::lower::model::Do p0) {
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto d_p1 = p0;
                (prism_rtl::more(prism_rtl::rc(InlineStatement(d_p1))));
            });
        }));
    }))), [=](Array<Text> each_15114) { return prism_rtl::finished(crate::syntax::lexer::chars::join_f(each_15114, Text::lit(" "))); });
}


/// `Start InlineStatements, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_inline_statements_f(Array<crate::lower::model::Do> dos_p0) {
    return prism_rtl::make_rc<InlineStatements>(dos_p0);
}


/// InlineStatement: unbounded fn Do -> Text
Text inline_statement_f(const crate::lower::model::Do& do_0) {
    if (prism_rtl::is<crate::lower::model::Do::DoIf>(do_0)) {
        auto&& c_p0 = prism_rtl::as<crate::lower::model::Do::DoIf>(do_0).a0;
        auto&& t_p1 = prism_rtl::as<crate::lower::model::Do::DoIf>(do_0).a1;
        auto&& c0_0_2 = prism_rtl::as<crate::lower::model::Do::DoIf>(do_0).a2;
        if (c0_0_2.size() == 0u) {
            return prism_rtl::cat("if ", expression_f(c_p0), " { ", inline_statements_f(t_p1), " }");
        }
    }
    {
        auto&& d_p2 = do_0;
        return statement_f(d_p2);
    }
}


prism_rtl::Turn<Text> InlineStatement::cycle() const {
    const auto& do_0 = this->do_0;
    return ({
        prism_rtl::is<crate::lower::model::Do::DoIf>(do_0) && ({
        auto&& c_p0 = prism_rtl::as<crate::lower::model::Do::DoIf>(do_0).a0;
        auto&& t_p1 = prism_rtl::as<crate::lower::model::Do::DoIf>(do_0).a1;
        auto&& j0_0_2 = prism_rtl::as<crate::lower::model::Do::DoIf>(do_0).a2;
        (j0_0_2.size() == 0u);
    }) ? ({
        auto&& c_p0 = prism_rtl::as<crate::lower::model::Do::DoIf>(do_0).a0;
        auto&& t_p1 = prism_rtl::as<crate::lower::model::Do::DoIf>(do_0).a1;
        auto&& j0_0_2 = prism_rtl::as<crate::lower::model::Do::DoIf>(do_0).a2;
        ({
        auto c_p0x = c_p0;
        auto t_p1x = t_p1;
        (crate::prelude::call_then(start_expression_f(c_p0x), [=, t_p1x = std::move(t_p1x)](Text expression_f_15239) { return crate::prelude::call_then(start_inline_statements_f(t_p1x), [=](Text inline_statements_f_15257) { return prism_rtl::finished(prism_rtl::cat("if ", expression_f_15239, " { ", inline_statements_f_15257, " }")); }); }));
    });
    })
        : ({
        auto&& d_p2 = do_0;
        prism_rtl::more(prism_rtl::rc(Statement(d_p2)));
    });
    });
}


/// `Start InlineStatement, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_inline_statement_f(crate::lower::model::Do do_0) {
    return prism_rtl::make_rc<InlineStatement>(do_0);
}


/// ElseBranch: unbounded fn [Do] -> Text
Text else_branch_f(const Array<crate::lower::model::Do>& xs0) {
    {
        auto&& c0_0 = xs0;
        if (c0_0.size() == 0u) {
            return Text::lit("");
        }
    }
    {
        auto&& c1_0 = xs0;
        if (c1_0.size() == 1u) {
            {
                auto&& _c1 = crate::prelude::index(c1_0, Nat(0u));
                if (prism_rtl::is_some(_c1) && prism_rtl::is<crate::lower::model::Do::DoIf>(prism_rtl::some_of(_c1))) {
                    auto&& c_p0 = prism_rtl::as<crate::lower::model::Do::DoIf>(prism_rtl::some_of(_c1)).a0;
                    auto&& t_p1 = prism_rtl::as<crate::lower::model::Do::DoIf>(prism_rtl::some_of(_c1)).a1;
                    auto&& e_p2 = prism_rtl::as<crate::lower::model::Do::DoIf>(prism_rtl::some_of(_c1)).a2;
                    return prism_rtl::cat(" else ", statement_f(crate::lower::model::Do(crate::lower::model::Do::DoIf{c_p0, t_p1, e_p2})));
                }
            }
        }
    }
    {
        auto&& c2_0 = xs0;
        if (c2_0.size() == 1u) {
            {
                auto&& _c1 = crate::prelude::index(c2_0, Nat(0u));
                if (prism_rtl::is_some(_c1) && prism_rtl::is<crate::lower::model::Do::DoIfLet>(prism_rtl::some_of(_c1))) {
                    auto&& p_p3 = prism_rtl::as<crate::lower::model::Do::DoIfLet>(prism_rtl::some_of(_c1)).a0;
                    auto&& x_p4 = prism_rtl::as<crate::lower::model::Do::DoIfLet>(prism_rtl::some_of(_c1)).a1;
                    auto&& t_p5 = prism_rtl::as<crate::lower::model::Do::DoIfLet>(prism_rtl::some_of(_c1)).a2;
                    auto&& e_p6 = prism_rtl::as<crate::lower::model::Do::DoIfLet>(prism_rtl::some_of(_c1)).a3;
                    return prism_rtl::cat(" else ", statement_f(crate::lower::model::Do(crate::lower::model::Do::DoIfLet{p_p3, x_p4, t_p5, e_p6})));
                }
            }
        }
    }
    {
        auto&& body_p7 = xs0;
        return crate::emit::rust::templates::items::else_f(statements_f(body_p7));
    }
}


prism_rtl::Turn<Text> ElseBranch::cycle() const {
    const auto& xs0 = this->xs0;
    return ({
        ({
        auto&& j0_0 = xs0;
        (j0_0.size() == 0u);
    }) ? ({
        auto&& j0_0 = xs0;
        prism_rtl::finished(Text::lit(""));
    })
        : ({
        auto&& j1_0 = xs0;
        (j1_0.size() == 1u) && ({
        auto&& _c1 = crate::prelude::index(j1_0, Nat(0u));
        prism_rtl::is_some(_c1) && prism_rtl::is<crate::lower::model::Do::DoIf>(prism_rtl::some_of(_c1));
    });
    }) ? ({
        auto&& j1_0 = xs0;
        auto&& _c1 = crate::prelude::index(j1_0, Nat(0u));
        auto&& c_p0 = prism_rtl::as<crate::lower::model::Do::DoIf>(prism_rtl::some_of(_c1)).a0;
        auto&& t_p1 = prism_rtl::as<crate::lower::model::Do::DoIf>(prism_rtl::some_of(_c1)).a1;
        auto&& e_p2 = prism_rtl::as<crate::lower::model::Do::DoIf>(prism_rtl::some_of(_c1)).a2;
        crate::prelude::call_then(start_statement_f(crate::lower::model::Do(crate::lower::model::Do::DoIf{c_p0, t_p1, e_p2})), [=](Text statement_f_15469) { return prism_rtl::finished(prism_rtl::cat(" else ", statement_f_15469)); });
    })
        : ({
        auto&& j2_0 = xs0;
        (j2_0.size() == 1u) && ({
        auto&& _c1 = crate::prelude::index(j2_0, Nat(0u));
        prism_rtl::is_some(_c1) && prism_rtl::is<crate::lower::model::Do::DoIfLet>(prism_rtl::some_of(_c1));
    });
    }) ? ({
        auto&& j2_0 = xs0;
        auto&& _c1 = crate::prelude::index(j2_0, Nat(0u));
        auto&& p_p3 = prism_rtl::as<crate::lower::model::Do::DoIfLet>(prism_rtl::some_of(_c1)).a0;
        auto&& x_p4 = prism_rtl::as<crate::lower::model::Do::DoIfLet>(prism_rtl::some_of(_c1)).a1;
        auto&& t_p5 = prism_rtl::as<crate::lower::model::Do::DoIfLet>(prism_rtl::some_of(_c1)).a2;
        auto&& e_p6 = prism_rtl::as<crate::lower::model::Do::DoIfLet>(prism_rtl::some_of(_c1)).a3;
        crate::prelude::call_then(start_statement_f(crate::lower::model::Do(crate::lower::model::Do::DoIfLet{p_p3, x_p4, t_p5, e_p6})), [=](Text statement_f_15545) { return prism_rtl::finished(prism_rtl::cat(" else ", statement_f_15545)); });
    })
        : ({
        auto&& body_p7 = xs0;
        ({
        auto body_p7x = body_p7;
        (crate::prelude::call_then(start_statements_f(body_p7x), [=](Text statements_f_15605) { return prism_rtl::finished(crate::emit::rust::templates::items::else_f(statements_f_15605)); }));
    });
    });
    });
}


/// `Start ElseBranch, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_else_branch_f(Array<crate::lower::model::Do> xs0) {
    return prism_rtl::make_rc<ElseBranch>(xs0);
}

}  // namespace crate::emit::rust
