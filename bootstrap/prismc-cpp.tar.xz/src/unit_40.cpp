// The module `Emit.Rust`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <emit/rust/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Emit.Rust`, from `target/bootstrap/cpp-src/prismc/emit/rust/mod.prism`.
namespace crate::emit::rust {

/// Type: unbounded fn OutTy -> Text
Text type_(const crate::lower::model::OutTy& t_p0) {
    if (prism_rtl::is<crate::lower::model::OutTy::OutNat>(t_p0)) {
        return Text::lit("Nat");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutInt>(t_p0)) {
        return Text::lit("Int");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutU8>(t_p0)) {
        return Text::lit("u8");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutFloat>(t_p0)) {
        return Text::lit("Float");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutBool>(t_p0)) {
        return Text::lit("bool");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutChar>(t_p0)) {
        return Text::lit("char");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutText>(t_p0)) {
        return Text::lit("Text");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutCursor>(t_p0)) {
        return Text::lit("Cursor");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutRegex>(t_p0)) {
        return Text::lit("Regex");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutReplacement>(t_p0)) {
        return Text::lit("RegexReplacement");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutUnit>(t_p0)) {
        return Text::lit("()");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutPath>(t_p0)) {
        return Text::lit("Path");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutDuration>(t_p0)) {
        return Text::lit("Duration");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutError>(t_p0)) {
        return Text::lit("Error");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t_p0)) {
        auto&& n_p1 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p0).a0;
        auto&& m1596_14_1 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p0).a1;
        if (m1596_14_1.size() == 0u) {
            return n_p1;
        }
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t_p0)) {
        auto&& n_p2 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p0).a0;
        auto&& args_p3 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p0).a1;
        return prism_rtl::cat(n_p2, "<", types(args_p3), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutOpt>(t_p0)) {
        auto&& i_p4 = prism_rtl::as<crate::lower::model::OutTy::OutOpt>(t_p0).a0;
        return prism_rtl::cat("Option<", type_(prism_rtl::deref(prism_rtl::deref(i_p4))), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutRes>(t_p0)) {
        auto&& i_p5 = prism_rtl::as<crate::lower::model::OutTy::OutRes>(t_p0).a0;
        return prism_rtl::cat("Result<", type_(prism_rtl::deref(prism_rtl::deref(i_p5))), ", Error>");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutTuple>(t_p0)) {
        auto&& m1596_18_0 = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(t_p0).a0;
        if (m1596_18_0.size() == 1u) {
            {
                auto&& _c1 = index(m1596_18_0, Nat(0u));
                if (prism_rtl::is_some(_c1)) {
                    auto&& one_p6 = prism_rtl::some_of(_c1);
                    return prism_rtl::cat("(", type_(one_p6), ",)");
                }
            }
        }
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutTuple>(t_p0)) {
        auto&& ts_p7 = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(t_p0).a0;
        return prism_rtl::cat("(", types(ts_p7), ")");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutArray>(t_p0)) {
        auto&& e_p8 = prism_rtl::as<crate::lower::model::OutTy::OutArray>(t_p0).a0;
        return prism_rtl::cat("Array<", type_(prism_rtl::deref(prism_rtl::deref(e_p8))), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutMap>(t_p0)) {
        auto&& k_p9 = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t_p0).a0;
        auto&& v_pa = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t_p0).a1;
        return prism_rtl::cat("Map<", type_(prism_rtl::deref(prism_rtl::deref(k_p9))), ", ", type_(prism_rtl::deref(prism_rtl::deref(v_pa))), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutFn>(t_p0)) {
        auto&& ps_pb = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t_p0).a0;
        auto&& r_pc = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t_p0).a1;
        return prism_rtl::cat("Rc<dyn Fn(", ref_types(ps_pb), ") -> ", type_(prism_rtl::deref(prism_rtl::deref(r_pc))), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutRef>(t_p0)) {
        auto&& i_pd = prism_rtl::as<crate::lower::model::OutTy::OutRef>(t_p0).a0;
        return prism_rtl::cat("&", type_(prism_rtl::deref(prism_rtl::deref(i_pd))));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(t_p0)) {
        auto&& a_pe = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(t_p0).a0;
        auto&& b_pf = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(t_p0).a1;
        return prism_rtl::cat("Rc<dyn Fn(", type_(prism_rtl::deref(prism_rtl::deref(a_pe))), ") -> Rc<dyn prism_rtl::Job<", type_(prism_rtl::deref(prism_rtl::deref(b_pf))), ">>>");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutJob>(t_p0)) {
        auto&& b_pg = prism_rtl::as<crate::lower::model::OutTy::OutJob>(t_p0).a0;
        return prism_rtl::cat("Rc<dyn prism_rtl::Job<", type_(prism_rtl::deref(prism_rtl::deref(b_pg))), ">>");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutEvent>(t_p0)) {
        auto&& i_ph = prism_rtl::as<crate::lower::model::OutTy::OutEvent>(t_p0).a0;
        return prism_rtl::cat("Event<", type_(prism_rtl::deref(prism_rtl::deref(i_ph))), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutDyn>(t_p0)) {
        auto&& i_pi = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(t_p0).a0;
        return prism_rtl::cat("Dynamic<", type_(prism_rtl::deref(prism_rtl::deref(i_pi))), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutGen>(t_p0)) {
        auto&& n_pj = prism_rtl::as<crate::lower::model::OutTy::OutGen>(t_p0).a0;
        return n_pj;
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutRc>(t_p0)) {
        auto&& i_pk = prism_rtl::as<crate::lower::model::OutTy::OutRc>(t_p0).a0;
        return prism_rtl::cat("Rc<", type_(prism_rtl::deref(prism_rtl::deref(i_pk))), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutPod>(t_p0)) {
        return Text::lit("Pod");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutShowAny>(t_p0)) {
        return Text::lit("Rc<dyn Show>");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutHold>(t_p0)) {
        auto&& i_pl = prism_rtl::as<crate::lower::model::OutTy::OutHold>(t_p0).a0;
        return prism_rtl::cat("Hold<", type_(prism_rtl::deref(prism_rtl::deref(i_pl))), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutStamped>(t_p0)) {
        auto&& i_pm = prism_rtl::as<crate::lower::model::OutTy::OutStamped>(t_p0).a0;
        return prism_rtl::cat("Stamped<", type_(prism_rtl::deref(prism_rtl::deref(i_pm))), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutSnapshot>(t_p0)) {
        auto&& i_pn = prism_rtl::as<crate::lower::model::OutTy::OutSnapshot>(t_p0).a0;
        return prism_rtl::cat("Snapshot<", type_(prism_rtl::deref(prism_rtl::deref(i_pn))), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutDefer>(t_p0)) {
        auto&& i_po = prism_rtl::as<crate::lower::model::OutTy::OutDefer>(t_p0).a0;
        return prism_rtl::cat("Defer<", type_(prism_rtl::deref(prism_rtl::deref(i_po))), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutWeak>(t_p0)) {
        auto&& n_pp = prism_rtl::as<crate::lower::model::OutTy::OutWeak>(t_p0).a0;
        return prism_rtl::cat("Weak<", n_pp, ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutCell>(t_p0)) {
        auto&& i_pq = prism_rtl::as<crate::lower::model::OutTy::OutCell>(t_p0).a0;
        return prism_rtl::cat("RefCell<", type_(prism_rtl::deref(prism_rtl::deref(i_pq))), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutWakes>(t_p0)) {
        return Text::lit("Wakes");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutCount>(t_p0)) {
        return Text::lit("u32");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutObj>(t_p0)) {
        auto&& i_pr = prism_rtl::as<crate::lower::model::OutTy::OutObj>(t_p0).a0;
        return prism_rtl::cat("Rc<dyn ", type_(prism_rtl::deref(prism_rtl::deref(i_pr))), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutSlice>(t_p0)) {
        auto&& i_ps = prism_rtl::as<crate::lower::model::OutTy::OutSlice>(t_p0).a0;
        return prism_rtl::cat("[", type_(prism_rtl::deref(prism_rtl::deref(i_ps))), "]");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutPort>(t_p0)) {
        auto&& i_pt = prism_rtl::as<crate::lower::model::OutTy::OutPort>(t_p0).a0;
        return prism_rtl::cat("Port<", type_(prism_rtl::deref(prism_rtl::deref(i_pt))), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutLive>(t_p0)) {
        auto&& i_pu = prism_rtl::as<crate::lower::model::OutTy::OutLive>(t_p0).a0;
        return prism_rtl::cat("Live<", type_(prism_rtl::deref(prism_rtl::deref(i_pu))), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutUnknown>(t_p0)) {
        auto&& what_pv = prism_rtl::as<crate::lower::model::OutTy::OutUnknown>(t_p0).a0;
        return prism_rtl::cat("() /* ", what_pv, " */");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutQuantified>(t_p0)) {
        auto&& b_p10 = prism_rtl::as<crate::lower::model::OutTy::OutQuantified>(t_p0).a0;
        return prism_rtl::cat("compile_error!(\"", crate::lower::expr::lowering_refusal(), "a quantified type variable of `", b_p10, "`: no instantiation gives it a type\")");
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Text> Type::cycle() const {
    const auto& t_p0 = this->t_p0;
    return ({
        prism_rtl::is<crate::lower::model::OutTy::OutNat>(t_p0) ? prism_rtl::finished(Text::lit("Nat"))
        : prism_rtl::is<crate::lower::model::OutTy::OutInt>(t_p0) ? prism_rtl::finished(Text::lit("Int"))
        : prism_rtl::is<crate::lower::model::OutTy::OutU8>(t_p0) ? prism_rtl::finished(Text::lit("u8"))
        : prism_rtl::is<crate::lower::model::OutTy::OutFloat>(t_p0) ? prism_rtl::finished(Text::lit("Float"))
        : prism_rtl::is<crate::lower::model::OutTy::OutBool>(t_p0) ? prism_rtl::finished(Text::lit("bool"))
        : prism_rtl::is<crate::lower::model::OutTy::OutChar>(t_p0) ? prism_rtl::finished(Text::lit("char"))
        : prism_rtl::is<crate::lower::model::OutTy::OutText>(t_p0) ? prism_rtl::finished(Text::lit("Text"))
        : prism_rtl::is<crate::lower::model::OutTy::OutCursor>(t_p0) ? prism_rtl::finished(Text::lit("Cursor"))
        : prism_rtl::is<crate::lower::model::OutTy::OutRegex>(t_p0) ? prism_rtl::finished(Text::lit("Regex"))
        : prism_rtl::is<crate::lower::model::OutTy::OutReplacement>(t_p0) ? prism_rtl::finished(Text::lit("RegexReplacement"))
        : prism_rtl::is<crate::lower::model::OutTy::OutUnit>(t_p0) ? prism_rtl::finished(Text::lit("()"))
        : prism_rtl::is<crate::lower::model::OutTy::OutPath>(t_p0) ? prism_rtl::finished(Text::lit("Path"))
        : prism_rtl::is<crate::lower::model::OutTy::OutDuration>(t_p0) ? prism_rtl::finished(Text::lit("Duration"))
        : prism_rtl::is<crate::lower::model::OutTy::OutError>(t_p0) ? prism_rtl::finished(Text::lit("Error"))
        : prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t_p0) && ({
        auto&& n_p1 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p0).a0;
        auto&& m1596_14_1 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p0).a1;
        (m1596_14_1.size() == 0u);
    }) ? ({
        auto&& n_p1 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p0).a0;
        auto&& m1596_14_1 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p0).a1;
        prism_rtl::finished(n_p1);
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t_p0) ? ({
        auto&& n_p2 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p0).a0;
        auto&& args_p3 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p0).a1;
        ({
        auto args_p3_1 = args_p3;
        auto n_p2_2 = n_p2;
        call_then(start_types(args_p3_1), [=, n_p2_2 = std::move(n_p2_2)](Text types_1964) { return prism_rtl::finished(prism_rtl::cat(n_p2_2, "<", types_1964, ">")); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutOpt>(t_p0) ? ({
        auto&& i_p4 = prism_rtl::as<crate::lower::model::OutTy::OutOpt>(t_p0).a0;
        ({
        auto i_p4_1 = prism_rtl::deref(prism_rtl::deref(i_p4));
        call_then(start_type_(i_p4_1), [=](Text type__2001) { return prism_rtl::finished(prism_rtl::cat("Option<", type__2001, ">")); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutRes>(t_p0) ? ({
        auto&& i_p5 = prism_rtl::as<crate::lower::model::OutTy::OutRes>(t_p0).a0;
        ({
        auto i_p5_1 = prism_rtl::deref(prism_rtl::deref(i_p5));
        call_then(start_type_(i_p5_1), [=](Text type__2034) { return prism_rtl::finished(prism_rtl::cat("Result<", type__2034, ", Error>")); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutTuple>(t_p0) && ({
        auto&& m1596_18_0 = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(t_p0).a0;
        (m1596_18_0.size() == 1u) && ({
        auto&& _c1 = index(m1596_18_0, Nat(0u));
        prism_rtl::is_some(_c1);
    });
    }) ? ({
        auto&& m1596_18_0 = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(t_p0).a0;
        auto&& _c1 = index(m1596_18_0, Nat(0u));
        auto&& one_p6 = prism_rtl::some_of(_c1);
        call_then(start_type_(one_p6), [=](Text type__2076) { return prism_rtl::finished(prism_rtl::cat("(", type__2076, ",)")); });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutTuple>(t_p0) ? ({
        auto&& ts_p7 = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(t_p0).a0;
        ({
        auto ts_p7_1 = ts_p7;
        call_then(start_types(ts_p7_1), [=](Text types_2109) { return prism_rtl::finished(prism_rtl::cat("(", types_2109, ")")); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutArray>(t_p0) ? ({
        auto&& e_p8 = prism_rtl::as<crate::lower::model::OutTy::OutArray>(t_p0).a0;
        ({
        auto e_p8_1 = prism_rtl::deref(prism_rtl::deref(e_p8));
        call_then(start_type_(e_p8_1), [=](Text type__2145) { return prism_rtl::finished(prism_rtl::cat("Array<", type__2145, ">")); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutMap>(t_p0) ? ({
        auto&& k_p9 = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t_p0).a0;
        auto&& v_pa = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t_p0).a1;
        ({
        auto k_p9_1 = prism_rtl::deref(prism_rtl::deref(k_p9));
        auto v_pa_2 = prism_rtl::deref(prism_rtl::deref(v_pa));
        call_then(start_type_(k_p9_1), [=, v_pa_2 = std::move(v_pa_2)](Text type__2178) { return call_then(start_type_(v_pa_2), [=](Text type__2188) { return prism_rtl::finished(prism_rtl::cat("Map<", type__2178, ", ", type__2188, ">")); }); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutFn>(t_p0) ? ({
        auto&& ps_pb = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t_p0).a0;
        auto&& r_pc = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t_p0).a1;
        ({
        auto ps_pb_1 = ps_pb;
        auto r_pc_2 = prism_rtl::deref(prism_rtl::deref(r_pc));
        call_then(start_ref_types(ps_pb_1), [=, r_pc_2 = std::move(r_pc_2)](Text ref_types_2227) { return call_then(start_type_(r_pc_2), [=](Text type__2245) { return prism_rtl::finished(prism_rtl::cat("Rc<dyn Fn(", ref_types_2227, ") -> ", type__2245, ">")); }); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutRef>(t_p0) ? ({
        auto&& i_pd = prism_rtl::as<crate::lower::model::OutTy::OutRef>(t_p0).a0;
        ({
        auto i_pd_1 = prism_rtl::deref(prism_rtl::deref(i_pd));
        call_then(start_type_(i_pd_1), [=](Text type__2272) { return prism_rtl::finished(prism_rtl::cat("&", type__2272)); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(t_p0) ? ({
        auto&& a_pe = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(t_p0).a0;
        auto&& b_pf = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(t_p0).a1;
        ({
        auto a_pe_1 = prism_rtl::deref(prism_rtl::deref(a_pe));
        auto b_pf_2 = prism_rtl::deref(prism_rtl::deref(b_pf));
        call_then(start_type_(a_pe_1), [=, b_pf_2 = std::move(b_pf_2)](Text type__2312) { return call_then(start_type_(b_pf_2), [=](Text type__2347) { return prism_rtl::finished(prism_rtl::cat("Rc<dyn Fn(", type__2312, ") -> Rc<dyn prism_rtl::Job<", type__2347, ">>>")); }); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutJob>(t_p0) ? ({
        auto&& b_pg = prism_rtl::as<crate::lower::model::OutTy::OutJob>(t_p0).a0;
        ({
        auto b_pg_1 = prism_rtl::deref(prism_rtl::deref(b_pg));
        call_then(start_type_(b_pg_1), [=](Text type__2397) { return prism_rtl::finished(prism_rtl::cat("Rc<dyn prism_rtl::Job<", type__2397, ">>")); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutEvent>(t_p0) ? ({
        auto&& i_ph = prism_rtl::as<crate::lower::model::OutTy::OutEvent>(t_p0).a0;
        ({
        auto i_ph_1 = prism_rtl::deref(prism_rtl::deref(i_ph));
        call_then(start_type_(i_ph_1), [=](Text type__2432) { return prism_rtl::finished(prism_rtl::cat("Event<", type__2432, ">")); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutDyn>(t_p0) ? ({
        auto&& i_pi = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(t_p0).a0;
        ({
        auto i_pi_1 = prism_rtl::deref(prism_rtl::deref(i_pi));
        call_then(start_type_(i_pi_1), [=](Text type__2466) { return prism_rtl::finished(prism_rtl::cat("Dynamic<", type__2466, ">")); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutGen>(t_p0) ? ({
        auto&& n_pj = prism_rtl::as<crate::lower::model::OutTy::OutGen>(t_p0).a0;
        prism_rtl::finished(n_pj);
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutRc>(t_p0) ? ({
        auto&& i_pk = prism_rtl::as<crate::lower::model::OutTy::OutRc>(t_p0).a0;
        ({
        auto i_pk_1 = prism_rtl::deref(prism_rtl::deref(i_pk));
        call_then(start_type_(i_pk_1), [=](Text type__2510) { return prism_rtl::finished(prism_rtl::cat("Rc<", type__2510, ">")); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutPod>(t_p0) ? prism_rtl::finished(Text::lit("Pod"))
        : prism_rtl::is<crate::lower::model::OutTy::OutShowAny>(t_p0) ? prism_rtl::finished(Text::lit("Rc<dyn Show>"))
        : prism_rtl::is<crate::lower::model::OutTy::OutHold>(t_p0) ? ({
        auto&& i_pl = prism_rtl::as<crate::lower::model::OutTy::OutHold>(t_p0).a0;
        ({
        auto i_pl_1 = prism_rtl::deref(prism_rtl::deref(i_pl));
        call_then(start_type_(i_pl_1), [=](Text type__2591) { return prism_rtl::finished(prism_rtl::cat("Hold<", type__2591, ">")); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutStamped>(t_p0) ? ({
        auto&& i_pm = prism_rtl::as<crate::lower::model::OutTy::OutStamped>(t_p0).a0;
        ({
        auto i_pm_1 = prism_rtl::deref(prism_rtl::deref(i_pm));
        call_then(start_type_(i_pm_1), [=](Text type__2629) { return prism_rtl::finished(prism_rtl::cat("Stamped<", type__2629, ">")); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutSnapshot>(t_p0) ? ({
        auto&& i_pn = prism_rtl::as<crate::lower::model::OutTy::OutSnapshot>(t_p0).a0;
        ({
        auto i_pn_1 = prism_rtl::deref(prism_rtl::deref(i_pn));
        call_then(start_type_(i_pn_1), [=](Text type__2669) { return prism_rtl::finished(prism_rtl::cat("Snapshot<", type__2669, ">")); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutDefer>(t_p0) ? ({
        auto&& i_po = prism_rtl::as<crate::lower::model::OutTy::OutDefer>(t_p0).a0;
        ({
        auto i_po_1 = prism_rtl::deref(prism_rtl::deref(i_po));
        call_then(start_type_(i_po_1), [=](Text type__2703) { return prism_rtl::finished(prism_rtl::cat("Defer<", type__2703, ">")); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutWeak>(t_p0) ? ({
        auto&& n_pp = prism_rtl::as<crate::lower::model::OutTy::OutWeak>(t_p0).a0;
        prism_rtl::finished(prism_rtl::cat("Weak<", n_pp, ">"));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutCell>(t_p0) ? ({
        auto&& i_pq = prism_rtl::as<crate::lower::model::OutTy::OutCell>(t_p0).a0;
        ({
        auto i_pq_1 = prism_rtl::deref(prism_rtl::deref(i_pq));
        call_then(start_type_(i_pq_1), [=](Text type__2765) { return prism_rtl::finished(prism_rtl::cat("RefCell<", type__2765, ">")); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutWakes>(t_p0) ? prism_rtl::finished(Text::lit("Wakes"))
        : prism_rtl::is<crate::lower::model::OutTy::OutCount>(t_p0) ? prism_rtl::finished(Text::lit("u32"))
        : prism_rtl::is<crate::lower::model::OutTy::OutObj>(t_p0) ? ({
        auto&& i_pr = prism_rtl::as<crate::lower::model::OutTy::OutObj>(t_p0).a0;
        ({
        auto i_pr_1 = prism_rtl::deref(prism_rtl::deref(i_pr));
        call_then(start_type_(i_pr_1), [=](Text type__2840) { return prism_rtl::finished(prism_rtl::cat("Rc<dyn ", type__2840, ">")); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutSlice>(t_p0) ? ({
        auto&& i_ps = prism_rtl::as<crate::lower::model::OutTy::OutSlice>(t_p0).a0;
        ({
        auto i_ps_1 = prism_rtl::deref(prism_rtl::deref(i_ps));
        call_then(start_type_(i_ps_1), [=](Text type__2869) { return prism_rtl::finished(prism_rtl::cat("[", type__2869, "]")); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutPort>(t_p0) ? ({
        auto&& i_pt = prism_rtl::as<crate::lower::model::OutTy::OutPort>(t_p0).a0;
        ({
        auto i_pt_1 = prism_rtl::deref(prism_rtl::deref(i_pt));
        call_then(start_type_(i_pt_1), [=](Text type__2901) { return prism_rtl::finished(prism_rtl::cat("Port<", type__2901, ">")); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutLive>(t_p0) ? ({
        auto&& i_pu = prism_rtl::as<crate::lower::model::OutTy::OutLive>(t_p0).a0;
        ({
        auto i_pu_1 = prism_rtl::deref(prism_rtl::deref(i_pu));
        call_then(start_type_(i_pu_1), [=](Text type__2933) { return prism_rtl::finished(prism_rtl::cat("Live<", type__2933, ">")); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutUnknown>(t_p0) ? ({
        auto&& what_pv = prism_rtl::as<crate::lower::model::OutTy::OutUnknown>(t_p0).a0;
        prism_rtl::finished(prism_rtl::cat("() /* ", what_pv, " */"));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutQuantified>(t_p0) ? ({
        auto&& b_p10 = prism_rtl::as<crate::lower::model::OutTy::OutQuantified>(t_p0).a0;
        prism_rtl::finished(prism_rtl::cat("compile_error!(\"", crate::lower::expr::lowering_refusal(), "a quantified type variable of `", b_p10, "`: no instantiation gives it a type\")"));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start Type, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_type_(crate::lower::model::OutTy t_p0) {
    return prism_rtl::make_rc<Type>(t_p0);
}


/// Types: unbounded fn [OutTy] -> Text
Text types(const Array<crate::lower::model::OutTy>& ts_p0) {
    return crate::syntax::lexer::chars::join(run_to_end(each_job(ts_p0, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::OutTy)>>(prism_rtl::rc([=](crate::lower::model::OutTy p0) {
        return entered(once_job([=]() {
            return ({
                auto t_p1 = p0;
                (prism_rtl::more(prism_rtl::rc(Type(t_p1))));
            });
        }));
    })))), Text::lit(", "));
}


prism_rtl::Turn<Text> Types::cycle() const {
    const auto& ts_p0 = this->ts_p0;
    auto ts_p0_1 = ts_p0;
    return call_value(each_job(ts_p0_1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::OutTy)>>(prism_rtl::rc([=](crate::lower::model::OutTy p0) {
        return entered(once_job([=]() {
            return ({
                auto t_p1 = p0;
                (prism_rtl::more(prism_rtl::rc(Type(t_p1))));
            });
        }));
    }))), [=](Array<Text> each_3169) { return prism_rtl::finished(crate::syntax::lexer::chars::join(each_3169, Text::lit(", "))); });
}


/// `Start Types, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_types(Array<crate::lower::model::OutTy> ts_p0) {
    return prism_rtl::make_rc<Types>(ts_p0);
}


/// RefTypes: unbounded fn [OutTy] -> Text
Text ref_types(const Array<crate::lower::model::OutTy>& ts_p0) {
    return crate::syntax::lexer::chars::join(run_to_end(each_job(ts_p0, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::OutTy)>>(prism_rtl::rc([=](crate::lower::model::OutTy p0) {
        return entered(once_job([=]() {
            return ({
                auto t_p1 = p0;
                call_then(start_type_(t_p1), [=](Text type__3277) { return prism_rtl::finished(prism_rtl::cat("&", type__3277)); });
            });
        }));
    })))), Text::lit(", "));
}


prism_rtl::Turn<Text> RefTypes::cycle() const {
    const auto& ts_p0 = this->ts_p0;
    auto ts_p0_1 = ts_p0;
    return call_value(each_job(ts_p0_1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::OutTy)>>(prism_rtl::rc([=](crate::lower::model::OutTy p0) {
        return entered(once_job([=]() {
            return ({
                auto t_p1 = p0;
                call_then(start_type_(t_p1), [=](Text type__3277) { return prism_rtl::finished(prism_rtl::cat("&", type__3277)); });
            });
        }));
    }))), [=](Array<Text> each_3260) { return prism_rtl::finished(crate::syntax::lexer::chars::join(each_3260, Text::lit(", "))); });
}


/// `Start RefTypes, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_ref_types(Array<crate::lower::model::OutTy> ts_p0) {
    return prism_rtl::make_rc<RefTypes>(ts_p0);
}


/// IsLoose: fn Ex -> Bool
bool is_loose(const crate::lower::model::Ex& x_p0) {
    if (prism_rtl::is<crate::lower::model::Ex::XBlock>(x_p0)) {
        auto&& m3602_0_0 = prism_rtl::as<crate::lower::model::Ex::XBlock>(x_p0).a0;
        auto&& inner_p1 = prism_rtl::as<crate::lower::model::Ex::XBlock>(x_p0).a1;
        if (m3602_0_0.size() == 0u) {
            return is_loose(prism_rtl::deref(prism_rtl::deref(inner_p1)));
        }
    }
    if (prism_rtl::is<crate::lower::model::Ex::XTyped>(x_p0)) {
        auto&& inner_p2 = prism_rtl::as<crate::lower::model::Ex::XTyped>(x_p0).a0;
        return is_loose(prism_rtl::deref(prism_rtl::deref(inner_p2)));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XBin>(x_p0)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XUnary>(x_p0)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XClosure>(x_p0)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XIf>(x_p0)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XMatch>(x_p0)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XChain>(x_p0)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XCast>(x_p0)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XRef>(x_p0)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XRefMut>(x_p0)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XDeref>(x_p0)) {
        return true;
    }
    {
        return false;
    }
}


/// Tight: unbounded fn Ex -> Text
Text tight(const crate::lower::model::Ex& x_p0) {
    return is_loose(x_p0)
        ? prism_rtl::cat("(", expression(x_p0), ")")
        : expression(x_p0);
}


prism_rtl::Turn<Text> Tight::cycle() const {
    const auto& x_p0 = this->x_p0;
    return is_loose(x_p0)
        ? ({
        auto x_p0_1 = x_p0;
        call_then(start_expression(x_p0_1), [=](Text expression_4119) { return prism_rtl::finished(prism_rtl::cat("(", expression_4119, ")")); });
    })
        : prism_rtl::more(prism_rtl::rc(Expression(x_p0)));
}


/// `Start Tight, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_tight(crate::lower::model::Ex x_p0) {
    return prism_rtl::make_rc<Tight>(x_p0);
}


/// Operand: unbounded fn Ex -> Text
Text operand(const crate::lower::model::Ex& x_p0) {
    if (prism_rtl::is<crate::lower::model::Ex::XBlock>(x_p0)) {
        auto&& m4203_0_0 = prism_rtl::as<crate::lower::model::Ex::XBlock>(x_p0).a0;
        auto&& inner_p1 = prism_rtl::as<crate::lower::model::Ex::XBlock>(x_p0).a1;
        if (m4203_0_0.size() == 0u) {
            return operand(prism_rtl::deref(prism_rtl::deref(inner_p1)));
        }
    }
    if (prism_rtl::is<crate::lower::model::Ex::XTyped>(x_p0)) {
        auto&& inner_p2 = prism_rtl::as<crate::lower::model::Ex::XTyped>(x_p0).a0;
        return operand(prism_rtl::deref(prism_rtl::deref(inner_p2)));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XBin>(x_p0)) {
        return prism_rtl::cat("(", expression(x_p0), ")");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XClosure>(x_p0)) {
        return prism_rtl::cat("(", expression(x_p0), ")");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XIf>(x_p0)) {
        return prism_rtl::cat("(", expression(x_p0), ")");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XCast>(x_p0)) {
        return prism_rtl::cat("(", expression(x_p0), ")");
    }
    {
        return expression(x_p0);
    }
}


prism_rtl::Turn<Text> Operand::cycle() const {
    const auto& x_p0 = this->x_p0;
    return ({
        prism_rtl::is<crate::lower::model::Ex::XBlock>(x_p0) && ({
        auto&& m4203_0_0 = prism_rtl::as<crate::lower::model::Ex::XBlock>(x_p0).a0;
        auto&& inner_p1 = prism_rtl::as<crate::lower::model::Ex::XBlock>(x_p0).a1;
        (m4203_0_0.size() == 0u);
    }) ? ({
        auto&& m4203_0_0 = prism_rtl::as<crate::lower::model::Ex::XBlock>(x_p0).a0;
        auto&& inner_p1 = prism_rtl::as<crate::lower::model::Ex::XBlock>(x_p0).a1;
        prism_rtl::more(prism_rtl::rc(Operand(prism_rtl::deref(prism_rtl::deref(inner_p1)))));
    })
        : prism_rtl::is<crate::lower::model::Ex::XTyped>(x_p0) ? ({
        auto&& inner_p2 = prism_rtl::as<crate::lower::model::Ex::XTyped>(x_p0).a0;
        prism_rtl::more(prism_rtl::rc(Operand(prism_rtl::deref(prism_rtl::deref(inner_p2)))));
    })
        : prism_rtl::is<crate::lower::model::Ex::XBin>(x_p0) ? ({
        auto x_p0_1 = x_p0;
        call_then(start_expression(x_p0_1), [=](Text expression_4326) { return prism_rtl::finished(prism_rtl::cat("(", expression_4326, ")")); });
    })
        : prism_rtl::is<crate::lower::model::Ex::XClosure>(x_p0) ? ({
        auto x_p0_1 = x_p0;
        call_then(start_expression(x_p0_1), [=](Text expression_4382) { return prism_rtl::finished(prism_rtl::cat("(", expression_4382, ")")); });
    })
        : prism_rtl::is<crate::lower::model::Ex::XIf>(x_p0) ? ({
        auto x_p0_1 = x_p0;
        call_then(start_expression(x_p0_1), [=](Text expression_4433) { return prism_rtl::finished(prism_rtl::cat("(", expression_4433, ")")); });
    })
        : prism_rtl::is<crate::lower::model::Ex::XCast>(x_p0) ? ({
        auto x_p0_1 = x_p0;
        call_then(start_expression(x_p0_1), [=](Text expression_4478) { return prism_rtl::finished(prism_rtl::cat("(", expression_4478, ")")); });
    })
        : prism_rtl::more(prism_rtl::rc(Expression(x_p0)));
    });
}


/// `Start Operand, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_operand(crate::lower::model::Ex x_p0) {
    return prism_rtl::make_rc<Operand>(x_p0);
}


/// Args: unbounded fn [Ex] -> Text
Text args(const Array<crate::lower::model::Ex>& xs_p0) {
    return crate::syntax::lexer::chars::join(run_to_end(each_job(xs_p0, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Ex)>>(prism_rtl::rc([=](crate::lower::model::Ex p0) {
        return entered(once_job([=]() {
            return ({
                auto x_p1 = p0;
                (prism_rtl::more(prism_rtl::rc(Expression(x_p1))));
            });
        }));
    })))), Text::lit(", "));
}


prism_rtl::Turn<Text> Args::cycle() const {
    const auto& xs_p0 = this->xs_p0;
    auto xs_p0_1 = xs_p0;
    return call_value(each_job(xs_p0_1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Ex)>>(prism_rtl::rc([=](crate::lower::model::Ex p0) {
        return entered(once_job([=]() {
            return ({
                auto x_p1 = p0;
                (prism_rtl::more(prism_rtl::rc(Expression(x_p1))));
            });
        }));
    }))), [=](Array<Text> each_4574) { return prism_rtl::finished(crate::syntax::lexer::chars::join(each_4574, Text::lit(", "))); });
}


/// `Start Args, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_args(Array<crate::lower::model::Ex> xs_p0) {
    return prism_rtl::make_rc<Args>(xs_p0);
}


/// Expression: unbounded fn Ex -> Text
Text expression(const crate::lower::model::Ex& x_p0) {
    if (prism_rtl::is<crate::lower::model::Ex::XVar>(x_p0)) {
        auto&& n_p1 = prism_rtl::as<crate::lower::model::Ex::XVar>(x_p0).a0;
        return n_p1;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XPath>(x_p0)) {
        auto&& p_p2 = prism_rtl::as<crate::lower::model::Ex::XPath>(x_p0).a0;
        return p_p2;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XSelf>(x_p0)) {
        return Text::lit("self");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XCx>(x_p0)) {
        return Text::lit("cx");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XConst>(x_p0)) {
        auto&& n_p3 = prism_rtl::as<crate::lower::model::Ex::XConst>(x_p0).a0;
        return prism_rtl::cat("Self::", n_p3);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XUnit>(x_p0)) {
        return Text::lit("()");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XNone>(x_p0)) {
        return Text::lit("None");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XBool>(x_p0)) {
        auto&& b_p4 = prism_rtl::as<crate::lower::model::Ex::XBool>(x_p0).a0;
        return prism_rtl::deref(b_p4) ? Text::lit("true") : Text::lit("false");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XNat>(x_p0)) {
        auto&& d_p5 = prism_rtl::as<crate::lower::model::Ex::XNat>(x_p0).a0;
        return len_text(d_p5) <= Nat(9u)
            ? prism_rtl::cat("Nat::from(", d_p5, "u32)")
            : len_text(d_p5) <= Nat(18u)
            ? prism_rtl::cat("Nat::from_int(Int::from(", d_p5, "i64)).unwrap()")
            : prism_rtl::cat("Nat::from_int(Int::parse(\"", d_p5, "\").unwrap()).unwrap()");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XInt>(x_p0)) {
        auto&& d_p6 = prism_rtl::as<crate::lower::model::Ex::XInt>(x_p0).a0;
        return len_text(crate::syntax::lexer::chars::has_prefix(d_p6, Text::lit("-"))
            ? crate::syntax::lexer::chars::after_first(d_p6)
            : d_p6) <= Nat(18u)
            ? prism_rtl::cat("Int::from(", d_p6, ")")
            : prism_rtl::cat("Int::parse(\"", d_p6, "\").unwrap()");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XByte>(x_p0)) {
        auto&& d_p7 = prism_rtl::as<crate::lower::model::Ex::XByte>(x_p0).a0;
        return prism_rtl::cat(d_p7, "u8");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XFloat>(x_p0)) {
        auto&& d_p8 = prism_rtl::as<crate::lower::model::Ex::XFloat>(x_p0).a0;
        return prism_rtl::cat("Float(", d_p8, ")");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XIndex>(x_p0)) {
        auto&& n_p9 = prism_rtl::as<crate::lower::model::Ex::XIndex>(x_p0).a0;
        return prism_rtl::cat(n_p9);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XChar>(x_p0)) {
        auto&& c_pa = prism_rtl::as<crate::lower::model::Ex::XChar>(x_p0).a0;
        return prism_rtl::cat("\'", crate::lower::expr::char_escape(c_pa), "\'");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XStr>(x_p0)) {
        auto&& t_pb = prism_rtl::as<crate::lower::model::Ex::XStr>(x_p0).a0;
        return prism_rtl::cat("\"", crate::lower::expr::escape(t_pb), "\"");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XRegex>(x_p0)) {
        auto&& p_pc = prism_rtl::as<crate::lower::model::Ex::XRegex>(x_p0).a0;
        auto&& f_pd = prism_rtl::as<crate::lower::model::Ex::XRegex>(x_p0).a1;
        return prism_rtl::cat("{ thread_local!(static R: Regex = Regex::lit(\"", crate::lower::expr::escape(p_pc), "\", \"", crate::lower::expr::escape(f_pd), "\")); R.with(Regex::clone) }");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XReplacement>(x_p0)) {
        auto&& p_pe = prism_rtl::as<crate::lower::model::Ex::XReplacement>(x_p0).a0;
        auto&& r_pf = prism_rtl::as<crate::lower::model::Ex::XReplacement>(x_p0).a1;
        auto&& f_pg = prism_rtl::as<crate::lower::model::Ex::XReplacement>(x_p0).a2;
        return prism_rtl::cat("{ thread_local!(static R: RegexReplacement = RegexReplacement::lit(\"", crate::lower::expr::escape(p_pe), "\", \"", crate::lower::expr::escape(f_pg), "\", \"", crate::lower::expr::escape(r_pf), "\")); R.with(RegexReplacement::clone) }");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XRef>(x_p0)) {
        auto&& y_ph = prism_rtl::as<crate::lower::model::Ex::XRef>(x_p0).a0;
        return prism_rtl::cat("&", operand(prism_rtl::deref(prism_rtl::deref(y_ph))));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XRefMut>(x_p0)) {
        auto&& y_pi = prism_rtl::as<crate::lower::model::Ex::XRefMut>(x_p0).a0;
        return prism_rtl::cat("&mut ", operand(prism_rtl::deref(prism_rtl::deref(y_pi))));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XDeref>(x_p0)) {
        auto&& y_pj = prism_rtl::as<crate::lower::model::Ex::XDeref>(x_p0).a0;
        return prism_rtl::cat("*", operand(prism_rtl::deref(prism_rtl::deref(y_pj))));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XTarget>(x_p0)) {
        auto&& y_pk = prism_rtl::as<crate::lower::model::Ex::XTarget>(x_p0).a0;
        return prism_rtl::cat("(*", expression(prism_rtl::deref(prism_rtl::deref(y_pk))), ")");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XClone>(x_p0)) {
        auto&& y_pl = prism_rtl::as<crate::lower::model::Ex::XClone>(x_p0).a0;
        return prism_rtl::cat(tight(prism_rtl::deref(prism_rtl::deref(y_pl))), ".clone()");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XWeak>(x_p0)) {
        auto&& y_pm = prism_rtl::as<crate::lower::model::Ex::XWeak>(x_p0).a0;
        return prism_rtl::cat("Rc::downgrade(", expression(prism_rtl::deref(prism_rtl::deref(y_pm))), ")");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XUpgrade>(x_p0)) {
        auto&& y_pn = prism_rtl::as<crate::lower::model::Ex::XUpgrade>(x_p0).a0;
        return prism_rtl::cat(tight(prism_rtl::deref(prism_rtl::deref(y_pn))), ".upgrade()");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XBreak>(x_p0)) {
        auto&& l_po = prism_rtl::as<crate::lower::model::Ex::XBreak>(x_p0).a0;
        auto&& y_pp = prism_rtl::as<crate::lower::model::Ex::XBreak>(x_p0).a1;
        return prism_rtl::cat("break ", label(l_po), " ", expression(prism_rtl::deref(prism_rtl::deref(y_pp))));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XBreakLoop>(x_p0)) {
        return Text::lit("break");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XLater>(x_p0)) {
        auto&& y_pq = prism_rtl::as<crate::lower::model::Ex::XLater>(x_p0).a0;
        return prism_rtl::cat("Box::new(move |cx| { ", expression(prism_rtl::deref(prism_rtl::deref(y_pq))), "; Ok(()) })");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XFormatStr>(x_p0)) {
        auto&& parts_pr = prism_rtl::as<crate::lower::model::Ex::XFormatStr>(x_p0).a0;
        return format_str(parts_pr);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XIsCase>(x_p0)) {
        auto&& y_ps = prism_rtl::as<crate::lower::model::Ex::XIsCase>(x_p0).a0;
        auto&& m4663_28_1 = prism_rtl::as<crate::lower::model::Ex::XIsCase>(x_p0).a1;
        if (m4663_28_1.size() == 0u) {
            return Text::lit("false");
        }
    }
    if (prism_rtl::is<crate::lower::model::Ex::XIsCase>(x_p0)) {
        auto&& y_pt = prism_rtl::as<crate::lower::model::Ex::XIsCase>(x_p0).a0;
        auto&& cs_pu = prism_rtl::as<crate::lower::model::Ex::XIsCase>(x_p0).a1;
        return prism_rtl::cat("matches!(", expression(prism_rtl::deref(prism_rtl::deref(y_pt))), ", ", crate::syntax::lexer::chars::join(each(cs_pu, [&](const Text& c_pv) { return prism_rtl::cat(c_pv, "(..)"); }), Text::lit(" | ")), ")");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XRefusal>(x_p0)) {
        auto&& what_p10 = prism_rtl::as<crate::lower::model::Ex::XRefusal>(x_p0).a0;
        return prism_rtl::cat("compile_error!(\"", crate::lower::expr::lowering_refusal(), crate::lower::expr::escape(what_p10), "\")");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XUnreachable>(x_p0)) {
        return Text::lit("unreachable!()");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XCall>(x_p0)) {
        auto&& f_p11 = prism_rtl::as<crate::lower::model::Ex::XCall>(x_p0).a0;
        auto&& args_p12 = prism_rtl::as<crate::lower::model::Ex::XCall>(x_p0).a1;
        return prism_rtl::cat(f_p11, "(", crate::emit::rust::args(args_p12), ")");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XApply>(x_p0)) {
        auto&& f_p13 = prism_rtl::as<crate::lower::model::Ex::XApply>(x_p0).a0;
        auto&& args_p14 = prism_rtl::as<crate::lower::model::Ex::XApply>(x_p0).a1;
        return prism_rtl::cat(tight(prism_rtl::deref(prism_rtl::deref(f_p13))), "(", crate::emit::rust::args(args_p14), ")");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XMethod>(x_p0)) {
        auto&& r_p15 = prism_rtl::as<crate::lower::model::Ex::XMethod>(x_p0).a0;
        auto&& m_p16 = prism_rtl::as<crate::lower::model::Ex::XMethod>(x_p0).a1;
        auto&& args_p17 = prism_rtl::as<crate::lower::model::Ex::XMethod>(x_p0).a2;
        return prism_rtl::cat(tight(prism_rtl::deref(prism_rtl::deref(r_p15))), ".", m_p16, "(", crate::emit::rust::args(args_p17), ")");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XBin>(x_p0)) {
        auto&& op_p18 = prism_rtl::as<crate::lower::model::Ex::XBin>(x_p0).a0;
        auto&& l_p19 = prism_rtl::as<crate::lower::model::Ex::XBin>(x_p0).a1;
        auto&& r_p1a = prism_rtl::as<crate::lower::model::Ex::XBin>(x_p0).a2;
        return prism_rtl::cat(operand(prism_rtl::deref(prism_rtl::deref(l_p19))), " ", op_p18, " ", operand(prism_rtl::deref(prism_rtl::deref(r_p1a))));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XUnary>(x_p0)) {
        auto&& op_p1b = prism_rtl::as<crate::lower::model::Ex::XUnary>(x_p0).a0;
        auto&& y_p1c = prism_rtl::as<crate::lower::model::Ex::XUnary>(x_p0).a1;
        return prism_rtl::cat(op_p1b, operand(prism_rtl::deref(prism_rtl::deref(y_p1c))));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XCtor>(x_p0)) {
        auto&& p_p1d = prism_rtl::as<crate::lower::model::Ex::XCtor>(x_p0).a0;
        auto&& args_p1e = prism_rtl::as<crate::lower::model::Ex::XCtor>(x_p0).a1;
        return prism_rtl::cat(p_p1d, "(", crate::emit::rust::args(args_p1e), ")");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XRecord>(x_p0)) {
        auto&& p_p1f = prism_rtl::as<crate::lower::model::Ex::XRecord>(x_p0).a0;
        auto&& fs_p1g = prism_rtl::as<crate::lower::model::Ex::XRecord>(x_p0).a1;
        return prism_rtl::cat(p_p1f, " { ", crate::syntax::lexer::chars::join(run_to_end(each_job(fs_p1g, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::Ex>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::Ex> p0) {
            return entered(once_job([=]() {
                return ({
                    auto [f_p1h, v_p1i] = p0;
                    (prism_rtl::more(prism_rtl::rc(FieldInit(f_p1h, v_p1i))));
                });
            }));
        })))), Text::lit(", ")), " }");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XTuple>(x_p0)) {
        auto&& m4663_39_0 = prism_rtl::as<crate::lower::model::Ex::XTuple>(x_p0).a0;
        if (m4663_39_0.size() == 1u) {
            {
                auto&& _c1 = index(m4663_39_0, Nat(0u));
                if (prism_rtl::is_some(_c1)) {
                    auto&& one_p1j = prism_rtl::some_of(_c1);
                    return prism_rtl::cat("(", expression(one_p1j), ",)");
                }
            }
        }
    }
    if (prism_rtl::is<crate::lower::model::Ex::XTuple>(x_p0)) {
        auto&& xs_p1k = prism_rtl::as<crate::lower::model::Ex::XTuple>(x_p0).a0;
        return prism_rtl::cat("(", crate::emit::rust::args(xs_p1k), ")");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XVec>(x_p0)) {
        auto&& xs_p1l = prism_rtl::as<crate::lower::model::Ex::XVec>(x_p0).a0;
        return prism_rtl::cat("vec![", crate::emit::rust::args(xs_p1l), "]");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XText>(x_p0)) {
        auto&& t_p1m = prism_rtl::as<crate::lower::model::Ex::XText>(x_p0).a0;
        return prism_rtl::cat("Text::lit(\"", crate::lower::expr::escape(t_p1m), "\")");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XFormat>(x_p0)) {
        auto&& parts_p1n = prism_rtl::as<crate::lower::model::Ex::XFormat>(x_p0).a0;
        return format(parts_p1n);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XMatch>(x_p0)) {
        auto&& s_p1o = prism_rtl::as<crate::lower::model::Ex::XMatch>(x_p0).a0;
        auto&& arms_p1p = prism_rtl::as<crate::lower::model::Ex::XMatch>(x_p0).a1;
        auto&& fallback_p1q = prism_rtl::as<crate::lower::model::Ex::XMatch>(x_p0).a2;
        return crate::emit::rust::templates::items::match_block(expression(prism_rtl::deref(prism_rtl::deref(s_p1o))), arms(arms_p1p, fallback_p1q));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XChain>(x_p0)) {
        auto&& label_p1r = prism_rtl::as<crate::lower::model::Ex::XChain>(x_p0).a0;
        auto&& s_p1s = prism_rtl::as<crate::lower::model::Ex::XChain>(x_p0).a1;
        auto&& arms_p1t = prism_rtl::as<crate::lower::model::Ex::XChain>(x_p0).a2;
        return chain(label(label_p1r), prism_rtl::deref(prism_rtl::deref(s_p1s)), arms_p1t);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XIf>(x_p0)) {
        auto&& c_p1u = prism_rtl::as<crate::lower::model::Ex::XIf>(x_p0).a0;
        auto&& t_p1v = prism_rtl::as<crate::lower::model::Ex::XIf>(x_p0).a1;
        auto&& e_p20 = prism_rtl::as<crate::lower::model::Ex::XIf>(x_p0).a2;
        return if_expression(prism_rtl::deref(prism_rtl::deref(c_p1u)), prism_rtl::deref(prism_rtl::deref(t_p1v)), prism_rtl::deref(prism_rtl::deref(e_p20)));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XBlock>(x_p0)) {
        auto&& m4663_47_0 = prism_rtl::as<crate::lower::model::Ex::XBlock>(x_p0).a0;
        auto&& e_p21 = prism_rtl::as<crate::lower::model::Ex::XBlock>(x_p0).a1;
        if (m4663_47_0.size() == 0u) {
            return expression(prism_rtl::deref(prism_rtl::deref(e_p21)));
        }
    }
    if (prism_rtl::is<crate::lower::model::Ex::XBlock>(x_p0)) {
        auto&& dos_p22 = prism_rtl::as<crate::lower::model::Ex::XBlock>(x_p0).a0;
        auto&& e_p23 = prism_rtl::as<crate::lower::model::Ex::XBlock>(x_p0).a1;
        return crate::emit::rust::templates::items::block(statements(dos_p22), expression(prism_rtl::deref(prism_rtl::deref(e_p23))));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XLabeled>(x_p0)) {
        auto&& label_p24 = prism_rtl::as<crate::lower::model::Ex::XLabeled>(x_p0).a0;
        auto&& dos_p25 = prism_rtl::as<crate::lower::model::Ex::XLabeled>(x_p0).a1;
        auto&& e_p26 = prism_rtl::as<crate::lower::model::Ex::XLabeled>(x_p0).a2;
        return crate::emit::rust::templates::items::labeled(label(label_p24), statements(dos_p25), expression(prism_rtl::deref(prism_rtl::deref(e_p26))));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XClosure>(x_p0)) {
        auto&& mv_p27 = prism_rtl::as<crate::lower::model::Ex::XClosure>(x_p0).a0;
        auto&& ps_p28 = prism_rtl::as<crate::lower::model::Ex::XClosure>(x_p0).a1;
        auto&& body_p29 = prism_rtl::as<crate::lower::model::Ex::XClosure>(x_p0).a2;
        return prism_rtl::cat(prism_rtl::deref(mv_p27) ? Text::lit("move ") : Text::lit(""), "|", crate::syntax::lexer::chars::join(run_to_end(each_job(ps_p28, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Pa)>>(prism_rtl::rc([=](crate::lower::model::Pa p0) {
            return entered(once_job([=]() {
                return ({
                    auto p_p2a = p0;
                    (prism_rtl::more(prism_rtl::rc(Pattern_(p_p2a))));
                });
            }));
        })))), Text::lit(", ")), "| ", expression(prism_rtl::deref(prism_rtl::deref(body_p29))));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XTry>(x_p0)) {
        auto&& y_p2b = prism_rtl::as<crate::lower::model::Ex::XTry>(x_p0).a0;
        return prism_rtl::cat(tight(prism_rtl::deref(prism_rtl::deref(y_p2b))), "?");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XField>(x_p0)) {
        auto&& r_p2c = prism_rtl::as<crate::lower::model::Ex::XField>(x_p0).a0;
        auto&& f_p2d = prism_rtl::as<crate::lower::model::Ex::XField>(x_p0).a1;
        return prism_rtl::cat(tight(prism_rtl::deref(prism_rtl::deref(r_p2c))), ".", f_p2d);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XPart>(x_p0)) {
        auto&& r_p2e = prism_rtl::as<crate::lower::model::Ex::XPart>(x_p0).a0;
        auto&& k_p2f = prism_rtl::as<crate::lower::model::Ex::XPart>(x_p0).a1;
        return prism_rtl::cat(tight(prism_rtl::deref(prism_rtl::deref(r_p2e))), ".", k_p2f);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XDecode>(x_p0)) {
        auto&& t_p2g = prism_rtl::as<crate::lower::model::Ex::XDecode>(x_p0).a0;
        auto&& y_p2h = prism_rtl::as<crate::lower::model::Ex::XDecode>(x_p0).a1;
        return prism_rtl::cat(decode_head(t_p2g), "::from_pod(", expression(prism_rtl::deref(prism_rtl::deref(y_p2h))), ")?");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XCast>(x_p0)) {
        auto&& y_p2i = prism_rtl::as<crate::lower::model::Ex::XCast>(x_p0).a0;
        auto&& t_p2j = prism_rtl::as<crate::lower::model::Ex::XCast>(x_p0).a1;
        return prism_rtl::cat(tight(prism_rtl::deref(prism_rtl::deref(y_p2i))), " as ", type_(t_p2j));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XTyped>(x_p0)) {
        auto&& y_p2k = prism_rtl::as<crate::lower::model::Ex::XTyped>(x_p0).a0;
        return expression(prism_rtl::deref(prism_rtl::deref(y_p2k)));
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Text> Expression::cycle() const {
    const auto& x_p0 = this->x_p0;
    return ({
        prism_rtl::is<crate::lower::model::Ex::XVar>(x_p0) ? ({
        auto&& n_p1 = prism_rtl::as<crate::lower::model::Ex::XVar>(x_p0).a0;
        prism_rtl::finished(n_p1);
    })
        : prism_rtl::is<crate::lower::model::Ex::XPath>(x_p0) ? ({
        auto&& p_p2 = prism_rtl::as<crate::lower::model::Ex::XPath>(x_p0).a0;
        prism_rtl::finished(p_p2);
    })
        : prism_rtl::is<crate::lower::model::Ex::XSelf>(x_p0) ? prism_rtl::finished(Text::lit("self"))
        : prism_rtl::is<crate::lower::model::Ex::XCx>(x_p0) ? prism_rtl::finished(Text::lit("cx"))
        : prism_rtl::is<crate::lower::model::Ex::XConst>(x_p0) ? ({
        auto&& n_p3 = prism_rtl::as<crate::lower::model::Ex::XConst>(x_p0).a0;
        prism_rtl::finished(prism_rtl::cat("Self::", n_p3));
    })
        : prism_rtl::is<crate::lower::model::Ex::XUnit>(x_p0) ? prism_rtl::finished(Text::lit("()"))
        : prism_rtl::is<crate::lower::model::Ex::XNone>(x_p0) ? prism_rtl::finished(Text::lit("None"))
        : prism_rtl::is<crate::lower::model::Ex::XBool>(x_p0) ? ({
        auto&& b_p4 = prism_rtl::as<crate::lower::model::Ex::XBool>(x_p0).a0;
        prism_rtl::deref(b_p4)
        ? prism_rtl::finished(Text::lit("true"))
        : prism_rtl::finished(Text::lit("false"));
    })
        : prism_rtl::is<crate::lower::model::Ex::XNat>(x_p0) ? ({
        auto&& d_p5 = prism_rtl::as<crate::lower::model::Ex::XNat>(x_p0).a0;
        len_text(d_p5) <= Nat(9u)
        ? prism_rtl::finished(prism_rtl::cat("Nat::from(", d_p5, "u32)"))
        : len_text(d_p5) <= Nat(18u)
        ? prism_rtl::finished(prism_rtl::cat("Nat::from_int(Int::from(", d_p5, "i64)).unwrap()"))
        : prism_rtl::finished(prism_rtl::cat("Nat::from_int(Int::parse(\"", d_p5, "\").unwrap()).unwrap()"));
    })
        : prism_rtl::is<crate::lower::model::Ex::XInt>(x_p0) ? ({
        auto&& d_p6 = prism_rtl::as<crate::lower::model::Ex::XInt>(x_p0).a0;
        len_text(crate::syntax::lexer::chars::has_prefix(d_p6, Text::lit("-"))
        ? crate::syntax::lexer::chars::after_first(d_p6)
        : d_p6) <= Nat(18u)
        ? prism_rtl::finished(prism_rtl::cat("Int::from(", d_p6, ")"))
        : prism_rtl::finished(prism_rtl::cat("Int::parse(\"", d_p6, "\").unwrap()"));
    })
        : prism_rtl::is<crate::lower::model::Ex::XByte>(x_p0) ? ({
        auto&& d_p7 = prism_rtl::as<crate::lower::model::Ex::XByte>(x_p0).a0;
        prism_rtl::finished(prism_rtl::cat(d_p7, "u8"));
    })
        : prism_rtl::is<crate::lower::model::Ex::XFloat>(x_p0) ? ({
        auto&& d_p8 = prism_rtl::as<crate::lower::model::Ex::XFloat>(x_p0).a0;
        prism_rtl::finished(prism_rtl::cat("Float(", d_p8, ")"));
    })
        : prism_rtl::is<crate::lower::model::Ex::XIndex>(x_p0) ? ({
        auto&& n_p9 = prism_rtl::as<crate::lower::model::Ex::XIndex>(x_p0).a0;
        prism_rtl::finished(prism_rtl::cat(n_p9));
    })
        : prism_rtl::is<crate::lower::model::Ex::XChar>(x_p0) ? ({
        auto&& c_pa = prism_rtl::as<crate::lower::model::Ex::XChar>(x_p0).a0;
        prism_rtl::finished(prism_rtl::cat("\'", crate::lower::expr::char_escape(c_pa), "\'"));
    })
        : prism_rtl::is<crate::lower::model::Ex::XStr>(x_p0) ? ({
        auto&& t_pb = prism_rtl::as<crate::lower::model::Ex::XStr>(x_p0).a0;
        prism_rtl::finished(prism_rtl::cat("\"", crate::lower::expr::escape(t_pb), "\""));
    })
        : prism_rtl::is<crate::lower::model::Ex::XRegex>(x_p0) ? ({
        auto&& p_pc = prism_rtl::as<crate::lower::model::Ex::XRegex>(x_p0).a0;
        auto&& f_pd = prism_rtl::as<crate::lower::model::Ex::XRegex>(x_p0).a1;
        prism_rtl::finished(prism_rtl::cat("{ thread_local!(static R: Regex = Regex::lit(\"", crate::lower::expr::escape(p_pc), "\", \"", crate::lower::expr::escape(f_pd), "\")); R.with(Regex::clone) }"));
    })
        : prism_rtl::is<crate::lower::model::Ex::XReplacement>(x_p0) ? ({
        auto&& p_pe = prism_rtl::as<crate::lower::model::Ex::XReplacement>(x_p0).a0;
        auto&& r_pf = prism_rtl::as<crate::lower::model::Ex::XReplacement>(x_p0).a1;
        auto&& f_pg = prism_rtl::as<crate::lower::model::Ex::XReplacement>(x_p0).a2;
        prism_rtl::finished(prism_rtl::cat("{ thread_local!(static R: RegexReplacement = RegexReplacement::lit(\"", crate::lower::expr::escape(p_pe), "\", \"", crate::lower::expr::escape(f_pg), "\", \"", crate::lower::expr::escape(r_pf), "\")); R.with(RegexReplacement::clone) }"));
    })
        : prism_rtl::is<crate::lower::model::Ex::XRef>(x_p0) ? ({
        auto&& y_ph = prism_rtl::as<crate::lower::model::Ex::XRef>(x_p0).a0;
        ({
        auto y_ph_1 = prism_rtl::deref(prism_rtl::deref(y_ph));
        call_then(start_operand(y_ph_1), [=](Text operand_5763) { return prism_rtl::finished(prism_rtl::cat("&", operand_5763)); });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XRefMut>(x_p0) ? ({
        auto&& y_pi = prism_rtl::as<crate::lower::model::Ex::XRefMut>(x_p0).a0;
        ({
        auto y_pi_1 = prism_rtl::deref(prism_rtl::deref(y_pi));
        call_then(start_operand(y_pi_1), [=](Text operand_5797) { return prism_rtl::finished(prism_rtl::cat("&mut ", operand_5797)); });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XDeref>(x_p0) ? ({
        auto&& y_pj = prism_rtl::as<crate::lower::model::Ex::XDeref>(x_p0).a0;
        ({
        auto y_pj_1 = prism_rtl::deref(prism_rtl::deref(y_pj));
        call_then(start_operand(y_pj_1), [=](Text operand_5826) { return prism_rtl::finished(prism_rtl::cat("*", operand_5826)); });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XTarget>(x_p0) ? ({
        auto&& y_pk = prism_rtl::as<crate::lower::model::Ex::XTarget>(x_p0).a0;
        ({
        auto y_pk_1 = prism_rtl::deref(prism_rtl::deref(y_pk));
        call_then(start_expression(y_pk_1), [=](Text expression_5857) { return prism_rtl::finished(prism_rtl::cat("(*", expression_5857, ")")); });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XClone>(x_p0) ? ({
        auto&& y_pl = prism_rtl::as<crate::lower::model::Ex::XClone>(x_p0).a0;
        ({
        auto y_pl_1 = prism_rtl::deref(prism_rtl::deref(y_pl));
        call_then(start_tight(y_pl_1), [=](Text tight_5889) { return prism_rtl::finished(prism_rtl::cat(tight_5889, ".clone()")); });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XWeak>(x_p0) ? ({
        auto&& y_pm = prism_rtl::as<crate::lower::model::Ex::XWeak>(x_p0).a0;
        ({
        auto y_pm_1 = prism_rtl::deref(prism_rtl::deref(y_pm));
        call_then(start_expression(y_pm_1), [=](Text expression_5936) { return prism_rtl::finished(prism_rtl::cat("Rc::downgrade(", expression_5936, ")")); });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XUpgrade>(x_p0) ? ({
        auto&& y_pn = prism_rtl::as<crate::lower::model::Ex::XUpgrade>(x_p0).a0;
        ({
        auto y_pn_1 = prism_rtl::deref(prism_rtl::deref(y_pn));
        call_then(start_tight(y_pn_1), [=](Text tight_5970) { return prism_rtl::finished(prism_rtl::cat(tight_5970, ".upgrade()")); });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XBreak>(x_p0) ? ({
        auto&& l_po = prism_rtl::as<crate::lower::model::Ex::XBreak>(x_p0).a0;
        auto&& y_pp = prism_rtl::as<crate::lower::model::Ex::XBreak>(x_p0).a1;
        ({
        auto l_po_1 = l_po;
        auto y_pp_2 = prism_rtl::deref(prism_rtl::deref(y_pp));
        call_then(start_expression(y_pp_2), [=, l_po_1 = std::move(l_po_1)](Text expression_6025) { return prism_rtl::finished(prism_rtl::cat("break ", label(l_po_1), " ", expression_6025)); });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XBreakLoop>(x_p0) ? prism_rtl::finished(Text::lit("break"))
        : prism_rtl::is<crate::lower::model::Ex::XLater>(x_p0) ? ({
        auto&& y_pq = prism_rtl::as<crate::lower::model::Ex::XLater>(x_p0).a0;
        ({
        auto y_pq_1 = prism_rtl::deref(prism_rtl::deref(y_pq));
        call_then(start_expression(y_pq_1), [=](Text expression_6102) { return prism_rtl::finished(prism_rtl::cat("Box::new(move |cx| { ", expression_6102, "; Ok(()) })")); });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XFormatStr>(x_p0) ? ({
        auto&& parts_pr = prism_rtl::as<crate::lower::model::Ex::XFormatStr>(x_p0).a0;
        prism_rtl::more(prism_rtl::rc(FormatStr(parts_pr)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XIsCase>(x_p0) && ({
        auto&& y_ps = prism_rtl::as<crate::lower::model::Ex::XIsCase>(x_p0).a0;
        auto&& m4663_28_1 = prism_rtl::as<crate::lower::model::Ex::XIsCase>(x_p0).a1;
        (m4663_28_1.size() == 0u);
    }) ? ({
        auto&& y_ps = prism_rtl::as<crate::lower::model::Ex::XIsCase>(x_p0).a0;
        auto&& m4663_28_1 = prism_rtl::as<crate::lower::model::Ex::XIsCase>(x_p0).a1;
        prism_rtl::finished(Text::lit("false"));
    })
        : prism_rtl::is<crate::lower::model::Ex::XIsCase>(x_p0) ? ({
        auto&& y_pt = prism_rtl::as<crate::lower::model::Ex::XIsCase>(x_p0).a0;
        auto&& cs_pu = prism_rtl::as<crate::lower::model::Ex::XIsCase>(x_p0).a1;
        ({
        auto cs_pu_1 = cs_pu;
        auto y_pt_2 = prism_rtl::deref(prism_rtl::deref(y_pt));
        call_then(start_expression(y_pt_2), [=, cs_pu_1 = std::move(cs_pu_1)](Text expression_6226) { return prism_rtl::finished(prism_rtl::cat("matches!(", expression_6226, ", ", crate::syntax::lexer::chars::join(each(cs_pu_1, [&](const Text& c_pv) { return prism_rtl::cat(c_pv, "(..)"); }), Text::lit(" | ")), ")")); });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XRefusal>(x_p0) ? ({
        auto&& what_p10 = prism_rtl::as<crate::lower::model::Ex::XRefusal>(x_p0).a0;
        prism_rtl::finished(prism_rtl::cat("compile_error!(\"", crate::lower::expr::lowering_refusal(), crate::lower::expr::escape(what_p10), "\")"));
    })
        : prism_rtl::is<crate::lower::model::Ex::XUnreachable>(x_p0) ? prism_rtl::finished(Text::lit("unreachable!()"))
        : prism_rtl::is<crate::lower::model::Ex::XCall>(x_p0) ? ({
        auto&& f_p11 = prism_rtl::as<crate::lower::model::Ex::XCall>(x_p0).a0;
        auto&& args_p12 = prism_rtl::as<crate::lower::model::Ex::XCall>(x_p0).a1;
        ({
        auto args_p12_1 = args_p12;
        auto f_p11_2 = f_p11;
        call_then(start_args(args_p12_1), [=, f_p11_2 = std::move(f_p11_2)](Text args_6415) { return prism_rtl::finished(prism_rtl::cat(f_p11_2, "(", args_6415, ")")); });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XApply>(x_p0) ? ({
        auto&& f_p13 = prism_rtl::as<crate::lower::model::Ex::XApply>(x_p0).a0;
        auto&& args_p14 = prism_rtl::as<crate::lower::model::Ex::XApply>(x_p0).a1;
        ({
        auto args_p14_1 = args_p14;
        auto f_p13_2 = prism_rtl::deref(prism_rtl::deref(f_p13));
        call_then(start_tight(f_p13_2), [=, args_p14_1 = std::move(args_p14_1)](Text tight_6450) { return call_then(start_args(args_p14_1), [=](Text args_6460) { return prism_rtl::finished(prism_rtl::cat(tight_6450, "(", args_6460, ")")); }); });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XMethod>(x_p0) ? ({
        auto&& r_p15 = prism_rtl::as<crate::lower::model::Ex::XMethod>(x_p0).a0;
        auto&& m_p16 = prism_rtl::as<crate::lower::model::Ex::XMethod>(x_p0).a1;
        auto&& args_p17 = prism_rtl::as<crate::lower::model::Ex::XMethod>(x_p0).a2;
        ({
        auto args_p17_1 = args_p17;
        auto m_p16_2 = m_p16;
        auto r_p15_3 = prism_rtl::deref(prism_rtl::deref(r_p15));
        call_then(start_tight(r_p15_3), [=, args_p17_1 = std::move(args_p17_1), m_p16_2 = std::move(m_p16_2)](Text tight_6499) { return call_then(start_args(args_p17_1), [=](Text args_6513) { return prism_rtl::finished(prism_rtl::cat(tight_6499, ".", m_p16_2, "(", args_6513, ")")); }); });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XBin>(x_p0) ? ({
        auto&& op_p18 = prism_rtl::as<crate::lower::model::Ex::XBin>(x_p0).a0;
        auto&& l_p19 = prism_rtl::as<crate::lower::model::Ex::XBin>(x_p0).a1;
        auto&& r_p1a = prism_rtl::as<crate::lower::model::Ex::XBin>(x_p0).a2;
        ({
        auto l_p19_1 = prism_rtl::deref(prism_rtl::deref(l_p19));
        auto op_p18_2 = op_p18;
        auto r_p1a_3 = prism_rtl::deref(prism_rtl::deref(r_p1a));
        call_then(start_operand(l_p19_1), [=, op_p18_2 = std::move(op_p18_2), r_p1a_3 = std::move(r_p1a_3)](Text operand_6547) { return call_then(start_operand(r_p1a_3), [=](Text operand_6564) { return prism_rtl::finished(prism_rtl::cat(operand_6547, " ", op_p18_2, " ", operand_6564)); }); });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XUnary>(x_p0) ? ({
        auto&& op_p1b = prism_rtl::as<crate::lower::model::Ex::XUnary>(x_p0).a0;
        auto&& y_p1c = prism_rtl::as<crate::lower::model::Ex::XUnary>(x_p0).a1;
        ({
        auto op_p1b_1 = op_p1b;
        auto y_p1c_2 = prism_rtl::deref(prism_rtl::deref(y_p1c));
        call_then(start_operand(y_p1c_2), [=, op_p1b_1 = std::move(op_p1b_1)](Text operand_6600) { return prism_rtl::finished(prism_rtl::cat(op_p1b_1, operand_6600)); });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XCtor>(x_p0) ? ({
        auto&& p_p1d = prism_rtl::as<crate::lower::model::Ex::XCtor>(x_p0).a0;
        auto&& args_p1e = prism_rtl::as<crate::lower::model::Ex::XCtor>(x_p0).a1;
        ({
        auto args_p1e_1 = args_p1e;
        auto p_p1d_2 = p_p1d;
        call_then(start_args(args_p1e_1), [=, p_p1d_2 = std::move(p_p1d_2)](Text args_6637) { return prism_rtl::finished(prism_rtl::cat(p_p1d_2, "(", args_6637, ")")); });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XRecord>(x_p0) ? ({
        auto&& p_p1f = prism_rtl::as<crate::lower::model::Ex::XRecord>(x_p0).a0;
        auto&& fs_p1g = prism_rtl::as<crate::lower::model::Ex::XRecord>(x_p0).a1;
        ({
        auto fs_p1g_1 = fs_p1g;
        auto p_p1f_2 = p_p1f;
        call_value(each_job(fs_p1g_1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::Ex>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::Ex> p0) {
        return entered(once_job([=]() {
            return ({
                auto [f_p1h, v_p1i] = p0;
                (prism_rtl::more(prism_rtl::rc(FieldInit(f_p1h, v_p1i))));
            });
        }));
    }))), [=, p_p1f_2 = std::move(p_p1f_2)](Array<Text> each_6684) { return prism_rtl::finished(prism_rtl::cat(p_p1f_2, " { ", crate::syntax::lexer::chars::join(each_6684, Text::lit(", ")), " }")); });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XTuple>(x_p0) && ({
        auto&& m4663_39_0 = prism_rtl::as<crate::lower::model::Ex::XTuple>(x_p0).a0;
        (m4663_39_0.size() == 1u) && ({
        auto&& _c1 = index(m4663_39_0, Nat(0u));
        prism_rtl::is_some(_c1);
    });
    }) ? ({
        auto&& m4663_39_0 = prism_rtl::as<crate::lower::model::Ex::XTuple>(x_p0).a0;
        auto&& _c1 = index(m4663_39_0, Nat(0u));
        auto&& one_p1j = prism_rtl::some_of(_c1);
        call_then(start_expression(one_p1j), [=](Text expression_6755) { return prism_rtl::finished(prism_rtl::cat("(", expression_6755, ",)")); });
    })
        : prism_rtl::is<crate::lower::model::Ex::XTuple>(x_p0) ? ({
        auto&& xs_p1k = prism_rtl::as<crate::lower::model::Ex::XTuple>(x_p0).a0;
        ({
        auto xs_p1k_1 = xs_p1k;
        call_then(start_args(xs_p1k_1), [=](Text args_6792) { return prism_rtl::finished(prism_rtl::cat("(", args_6792, ")")); });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XVec>(x_p0) ? ({
        auto&& xs_p1l = prism_rtl::as<crate::lower::model::Ex::XVec>(x_p0).a0;
        ({
        auto xs_p1l_1 = xs_p1l;
        call_then(start_args(xs_p1l_1), [=](Text args_6823) { return prism_rtl::finished(prism_rtl::cat("vec![", args_6823, "]")); });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XText>(x_p0) ? ({
        auto&& t_p1m = prism_rtl::as<crate::lower::model::Ex::XText>(x_p0).a0;
        prism_rtl::finished(prism_rtl::cat("Text::lit(\"", crate::lower::expr::escape(t_p1m), "\")"));
    })
        : prism_rtl::is<crate::lower::model::Ex::XFormat>(x_p0) ? ({
        auto&& parts_p1n = prism_rtl::as<crate::lower::model::Ex::XFormat>(x_p0).a0;
        prism_rtl::more(prism_rtl::rc(Format(parts_p1n)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XMatch>(x_p0) ? ({
        auto&& s_p1o = prism_rtl::as<crate::lower::model::Ex::XMatch>(x_p0).a0;
        auto&& arms_p1p = prism_rtl::as<crate::lower::model::Ex::XMatch>(x_p0).a1;
        auto&& fallback_p1q = prism_rtl::as<crate::lower::model::Ex::XMatch>(x_p0).a2;
        ({
        auto arms_p1p_1 = arms_p1p;
        auto fallback_p1q_2 = prism_rtl::deref(fallback_p1q);
        auto s_p1o_3 = prism_rtl::deref(prism_rtl::deref(s_p1o));
        call_then(start_expression(s_p1o_3), [=, arms_p1p_1 = std::move(arms_p1p_1), fallback_p1q_2 = std::move(fallback_p1q_2)](Text expression_6957) { return call_then(start_arms(arms_p1p_1, fallback_p1q_2), [=](Text arms_6973) { return prism_rtl::finished(crate::emit::rust::templates::items::match_block(expression_6957, arms_6973)); }); });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XChain>(x_p0) ? ({
        auto&& label_p1r = prism_rtl::as<crate::lower::model::Ex::XChain>(x_p0).a0;
        auto&& s_p1s = prism_rtl::as<crate::lower::model::Ex::XChain>(x_p0).a1;
        auto&& arms_p1t = prism_rtl::as<crate::lower::model::Ex::XChain>(x_p0).a2;
        prism_rtl::more(prism_rtl::rc(Chain(label(label_p1r), prism_rtl::deref(prism_rtl::deref(s_p1s)), arms_p1t)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XIf>(x_p0) ? ({
        auto&& c_p1u = prism_rtl::as<crate::lower::model::Ex::XIf>(x_p0).a0;
        auto&& t_p1v = prism_rtl::as<crate::lower::model::Ex::XIf>(x_p0).a1;
        auto&& e_p20 = prism_rtl::as<crate::lower::model::Ex::XIf>(x_p0).a2;
        prism_rtl::more(prism_rtl::rc(IfExpression(prism_rtl::deref(prism_rtl::deref(c_p1u)), prism_rtl::deref(prism_rtl::deref(t_p1v)), prism_rtl::deref(prism_rtl::deref(e_p20)))));
    })
        : prism_rtl::is<crate::lower::model::Ex::XBlock>(x_p0) && ({
        auto&& m4663_47_0 = prism_rtl::as<crate::lower::model::Ex::XBlock>(x_p0).a0;
        auto&& e_p21 = prism_rtl::as<crate::lower::model::Ex::XBlock>(x_p0).a1;
        (m4663_47_0.size() == 0u);
    }) ? ({
        auto&& m4663_47_0 = prism_rtl::as<crate::lower::model::Ex::XBlock>(x_p0).a0;
        auto&& e_p21 = prism_rtl::as<crate::lower::model::Ex::XBlock>(x_p0).a1;
        prism_rtl::more(prism_rtl::rc(Expression(prism_rtl::deref(prism_rtl::deref(e_p21)))));
    })
        : prism_rtl::is<crate::lower::model::Ex::XBlock>(x_p0) ? ({
        auto&& dos_p22 = prism_rtl::as<crate::lower::model::Ex::XBlock>(x_p0).a0;
        auto&& e_p23 = prism_rtl::as<crate::lower::model::Ex::XBlock>(x_p0).a1;
        ({
        auto dos_p22_1 = dos_p22;
        auto e_p23_2 = prism_rtl::deref(prism_rtl::deref(e_p23));
        call_then(start_statements(dos_p22_1), [=, e_p23_2 = std::move(e_p23_2)](Text statements_7155) { return call_then(start_expression(e_p23_2), [=](Text expression_7173) { return prism_rtl::finished(crate::emit::rust::templates::items::block(statements_7155, expression_7173)); }); });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XLabeled>(x_p0) ? ({
        auto&& label_p24 = prism_rtl::as<crate::lower::model::Ex::XLabeled>(x_p0).a0;
        auto&& dos_p25 = prism_rtl::as<crate::lower::model::Ex::XLabeled>(x_p0).a1;
        auto&& e_p26 = prism_rtl::as<crate::lower::model::Ex::XLabeled>(x_p0).a2;
        ({
        auto dos_p25_1 = dos_p25;
        auto e_p26_2 = prism_rtl::deref(prism_rtl::deref(e_p26));
        auto label_p24_3 = label_p24;
        call_then(start_statements(dos_p25_1), [=, e_p26_2 = std::move(e_p26_2), label_p24_3 = std::move(label_p24_3)](Text statements_7247) { return call_then(start_expression(e_p26_2), [=](Text expression_7265) { return prism_rtl::finished(crate::emit::rust::templates::items::labeled(label(label_p24_3), statements_7247, expression_7265)); }); });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XClosure>(x_p0) ? ({
        auto&& mv_p27 = prism_rtl::as<crate::lower::model::Ex::XClosure>(x_p0).a0;
        auto&& ps_p28 = prism_rtl::as<crate::lower::model::Ex::XClosure>(x_p0).a1;
        auto&& body_p29 = prism_rtl::as<crate::lower::model::Ex::XClosure>(x_p0).a2;
        ({
        auto body_p29_1 = prism_rtl::deref(prism_rtl::deref(body_p29));
        auto mv_p27_2 = prism_rtl::deref(mv_p27);
        auto ps_p28_3 = ps_p28;
        call_value(each_job(ps_p28_3, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Pa)>>(prism_rtl::rc([=](crate::lower::model::Pa p0) {
        return entered(once_job([=]() {
            return ({
                auto p_p2a = p0;
                (prism_rtl::more(prism_rtl::rc(Pattern_(p_p2a))));
            });
        }));
    }))), [=, body_p29_1 = std::move(body_p29_1), mv_p27_2 = std::move(mv_p27_2)](Array<Text> each_7340) { return call_then(start_expression(body_p29_1), [=](Text expression_7374) { return prism_rtl::finished(prism_rtl::cat(mv_p27_2 ? Text::lit("move ") : Text::lit(""), "|", crate::syntax::lexer::chars::join(each_7340, Text::lit(", ")), "| ", expression_7374)); }); });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XTry>(x_p0) ? ({
        auto&& y_p2b = prism_rtl::as<crate::lower::model::Ex::XTry>(x_p0).a0;
        ({
        auto y_p2b_1 = prism_rtl::deref(prism_rtl::deref(y_p2b));
        call_then(start_tight(y_p2b_1), [=](Text tight_7406) { return prism_rtl::finished(prism_rtl::cat(tight_7406, "?")); });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XField>(x_p0) ? ({
        auto&& r_p2c = prism_rtl::as<crate::lower::model::Ex::XField>(x_p0).a0;
        auto&& f_p2d = prism_rtl::as<crate::lower::model::Ex::XField>(x_p0).a1;
        ({
        auto f_p2d_1 = f_p2d;
        auto r_p2c_2 = prism_rtl::deref(prism_rtl::deref(r_p2c));
        call_then(start_tight(r_p2c_2), [=, f_p2d_1 = std::move(f_p2d_1)](Text tight_7436) { return prism_rtl::finished(prism_rtl::cat(tight_7436, ".", f_p2d_1)); });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XPart>(x_p0) ? ({
        auto&& r_p2e = prism_rtl::as<crate::lower::model::Ex::XPart>(x_p0).a0;
        auto&& k_p2f = prism_rtl::as<crate::lower::model::Ex::XPart>(x_p0).a1;
        ({
        auto k_p2f_1 = k_p2f;
        auto r_p2e_2 = prism_rtl::deref(prism_rtl::deref(r_p2e));
        call_then(start_tight(r_p2e_2), [=, k_p2f_1 = std::move(k_p2f_1)](Text tight_7468) { return prism_rtl::finished(prism_rtl::cat(tight_7468, ".", k_p2f_1)); });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XDecode>(x_p0) ? ({
        auto&& t_p2g = prism_rtl::as<crate::lower::model::Ex::XDecode>(x_p0).a0;
        auto&& y_p2h = prism_rtl::as<crate::lower::model::Ex::XDecode>(x_p0).a1;
        ({
        auto t_p2g_1 = t_p2g;
        auto y_p2h_2 = prism_rtl::deref(prism_rtl::deref(y_p2h));
        call_then(start_decode_head(t_p2g_1), [=, y_p2h_2 = std::move(y_p2h_2)](Text decode_head_7502) { return call_then(start_expression(y_p2h_2), [=](Text expression_7527) { return prism_rtl::finished(prism_rtl::cat(decode_head_7502, "::from_pod(", expression_7527, ")?")); }); });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XCast>(x_p0) ? ({
        auto&& y_p2i = prism_rtl::as<crate::lower::model::Ex::XCast>(x_p0).a0;
        auto&& t_p2j = prism_rtl::as<crate::lower::model::Ex::XCast>(x_p0).a1;
        ({
        auto t_p2j_1 = t_p2j;
        auto y_p2i_2 = prism_rtl::deref(prism_rtl::deref(y_p2i));
        call_then(start_tight(y_p2i_2), [=, t_p2j_1 = std::move(t_p2j_1)](Text tight_7562) { return call_then(start_type_(t_p2j_1), [=](Text type__7575) { return prism_rtl::finished(prism_rtl::cat(tight_7562, " as ", type__7575)); }); });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XTyped>(x_p0) ? ({
        auto&& y_p2k = prism_rtl::as<crate::lower::model::Ex::XTyped>(x_p0).a0;
        prism_rtl::more(prism_rtl::rc(Expression(prism_rtl::deref(prism_rtl::deref(y_p2k)))));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start Expression, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_expression(crate::lower::model::Ex x_p0) {
    return prism_rtl::make_rc<Expression>(x_p0);
}


/// FieldInit: unbounded fn Text, Ex -> Text
Text field_init(const Text& f_p0, const crate::lower::model::Ex& ex1) {
    if (prism_rtl::is<crate::lower::model::Ex::XVar>(ex1)) {
        auto&& v_p1 = prism_rtl::as<crate::lower::model::Ex::XVar>(ex1).a0;
        return v_p1 == f_p0 ? f_p0 : prism_rtl::cat(f_p0, ": ", v_p1);
    }
    {
        auto&& v_p3 = ex1;
        return prism_rtl::cat(f_p0, ": ", expression(v_p3));
    }
}


prism_rtl::Turn<Text> FieldInit::cycle() const {
    const auto& f_p0 = this->f_p0;
    const auto& ex1 = this->ex1;
    return ({
        prism_rtl::is<crate::lower::model::Ex::XVar>(ex1) ? ({
        auto&& v_p1 = prism_rtl::as<crate::lower::model::Ex::XVar>(ex1).a0;
        v_p1 == f_p0
        ? prism_rtl::finished(f_p0)
        : prism_rtl::finished(prism_rtl::cat(f_p0, ": ", v_p1));
    })
        : ({
        auto&& v_p3 = ex1;
        ({
        auto f_p0_1 = f_p0;
        auto v_p3_2 = v_p3;
        call_then(start_expression(v_p3_2), [=, f_p0_1 = std::move(f_p0_1)](Text expression_7745) { return prism_rtl::finished(prism_rtl::cat(f_p0_1, ": ", expression_7745)); });
    });
    });
    });
}


/// `Start FieldInit, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_field_init(Text f_p0, crate::lower::model::Ex ex1) {
    return prism_rtl::make_rc<FieldInit>(f_p0, ex1);
}


/// DecodeHead: unbounded fn OutTy -> Text
Text decode_head(const crate::lower::model::OutTy& t_p0) {
    if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t_p0)) {
        auto&& n_p1 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p0).a0;
        auto&& m7818_0_1 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p0).a1;
        if (m7818_0_1.size() == 0u) {
            return n_p1;
        }
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutNat>(t_p0)) {
        return Text::lit("Nat");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutInt>(t_p0)) {
        return Text::lit("Int");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutText>(t_p0)) {
        return Text::lit("Text");
    }
    {
        return prism_rtl::cat("<", type_(t_p0), ">");
    }
}


prism_rtl::Turn<Text> DecodeHead::cycle() const {
    const auto& t_p0 = this->t_p0;
    return ({
        prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t_p0) && ({
        auto&& n_p1 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p0).a0;
        auto&& m7818_0_1 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p0).a1;
        (m7818_0_1.size() == 0u);
    }) ? ({
        auto&& n_p1 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p0).a0;
        auto&& m7818_0_1 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p0).a1;
        prism_rtl::finished(n_p1);
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutNat>(t_p0) ? prism_rtl::finished(Text::lit("Nat"))
        : prism_rtl::is<crate::lower::model::OutTy::OutInt>(t_p0) ? prism_rtl::finished(Text::lit("Int"))
        : prism_rtl::is<crate::lower::model::OutTy::OutText>(t_p0) ? prism_rtl::finished(Text::lit("Text"))
        : ({
        auto t_p0_1 = t_p0;
        call_then(start_type_(t_p0_1), [=](Text type__7925) { return prism_rtl::finished(prism_rtl::cat("<", type__7925, ">")); });
    });
    });
}


/// `Start DecodeHead, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_decode_head(crate::lower::model::OutTy t_p0) {
    return prism_rtl::make_rc<DecodeHead>(t_p0);
}


/// Label: fn Text -> Text
Text label(const Text& l_p0) {
    return crate::syntax::lexer::chars::has_prefix(l_p0, Text::lit("\'"))
        ? l_p0
        : prism_rtl::cat("\'", l_p0);
}


/// Format: unbounded fn [Ex] -> Text
Text format(const Array<crate::lower::model::Ex>& parts_p0) {
    auto lit_p1 = concat(each(parts_p0, [&](const crate::lower::model::Ex& p_p3) { return format_piece(p_p3); }));
    auto vals_p2 = filter(parts_p0, [&](const crate::lower::model::Ex& p_p4) { return !is_text(p_p4); });
    return len(vals_p2) == Nat(0u)
        ? prism_rtl::cat("Text::lit(\"", crate::lower::expr::escape(concat(each(parts_p0, [&](const crate::lower::model::Ex& p_p5) { return plain_piece(p_p5); }))), "\")")
        : prism_rtl::cat("Text::from(format!(\"", lit_p1, "\", ", crate::emit::rust::args(vals_p2), "))");
}


prism_rtl::Turn<Text> Format::cycle() const {
    const auto& parts_p0 = this->parts_p0;
    auto lit_p1 = concat(each(parts_p0, [&](const crate::lower::model::Ex& p_p3) { return format_piece(p_p3); }));
    auto vals_p2 = filter(parts_p0, [&](const crate::lower::model::Ex& p_p4) { return !is_text(p_p4); });
    return len(vals_p2) == Nat(0u)
        ? prism_rtl::finished(prism_rtl::cat("Text::lit(\"", crate::lower::expr::escape(concat(each(parts_p0, [&](const crate::lower::model::Ex& p_p5) { return plain_piece(p_p5); }))), "\")"))
        : call_then(start_args(vals_p2), [=](Text args_8440) { return prism_rtl::finished(prism_rtl::cat("Text::from(format!(\"", lit_p1, "\", ", args_8440, "))")); });
}


/// `Start Format, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_format(Array<crate::lower::model::Ex> parts_p0) {
    return prism_rtl::make_rc<Format>(parts_p0);
}


/// PlainPiece: fn Ex -> Text
Text plain_piece(const crate::lower::model::Ex& ex0) {
    if (prism_rtl::is<crate::lower::model::Ex::XText>(ex0)) {
        auto&& t_p0 = prism_rtl::as<crate::lower::model::Ex::XText>(ex0).a0;
        return t_p0;
    }
    {
        auto&& other_p1 = ex0;
        return Text::lit("");
    }
}


/// FormatStr: unbounded fn [Ex] -> Text
Text format_str(const Array<crate::lower::model::Ex>& parts_p0) {
    auto lit_p1 = concat(each(parts_p0, [&](const crate::lower::model::Ex& p_p3) { return str_piece(p_p3); }));
    auto vals_p2 = filter(parts_p0, [&](const crate::lower::model::Ex& p_p4) { return (!is_text(p_p4)) && (!is_var(p_p4)); });
    return len(vals_p2) == Nat(0u)
        ? prism_rtl::cat("\"", lit_p1, "\"")
        : prism_rtl::cat("format!(\"", lit_p1, "\", ", crate::emit::rust::args(vals_p2), ")");
}


prism_rtl::Turn<Text> FormatStr::cycle() const {
    const auto& parts_p0 = this->parts_p0;
    auto lit_p1 = concat(each(parts_p0, [&](const crate::lower::model::Ex& p_p3) { return str_piece(p_p3); }));
    auto vals_p2 = filter(parts_p0, [&](const crate::lower::model::Ex& p_p4) { return (!is_text(p_p4)) && (!is_var(p_p4)); });
    return len(vals_p2) == Nat(0u)
        ? prism_rtl::finished(prism_rtl::cat("\"", lit_p1, "\""))
        : call_then(start_args(vals_p2), [=](Text args_8905) { return prism_rtl::finished(prism_rtl::cat("format!(\"", lit_p1, "\", ", args_8905, ")")); });
}


/// `Start FormatStr, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_format_str(Array<crate::lower::model::Ex> parts_p0) {
    return prism_rtl::make_rc<FormatStr>(parts_p0);
}


/// IsVar: fn Ex -> Bool
bool is_var(const crate::lower::model::Ex& ex0) {
    if (prism_rtl::is<crate::lower::model::Ex::XVar>(ex0)) {
        return true;
    }
    {
        auto&& other_p0 = ex0;
        return false;
    }
}


/// StrPiece: fn Ex -> Text
Text str_piece(const crate::lower::model::Ex& ex0) {
    if (prism_rtl::is<crate::lower::model::Ex::XVar>(ex0)) {
        auto&& n_p0 = prism_rtl::as<crate::lower::model::Ex::XVar>(ex0).a0;
        return prism_rtl::cat("{", n_p0, "}");
    }
    {
        auto&& other_p1 = ex0;
        return format_piece(other_p1);
    }
}


/// IsText: fn Ex -> Bool
bool is_text(const crate::lower::model::Ex& ex0) {
    if (prism_rtl::is<crate::lower::model::Ex::XText>(ex0)) {
        return true;
    }
    {
        auto&& other_p0 = ex0;
        return false;
    }
}


/// FormatPiece: fn Ex -> Text
Text format_piece(const crate::lower::model::Ex& ex0) {
    if (prism_rtl::is<crate::lower::model::Ex::XText>(ex0)) {
        auto&& t_p0 = prism_rtl::as<crate::lower::model::Ex::XText>(ex0).a0;
        return format_escape(crate::lower::expr::escape(t_p0));
    }
    {
        auto&& other_p1 = ex0;
        return Text::lit("{}");
    }
}


/// FormatEscape: fn Text -> Text
Text format_escape(const Text& t_p0) {
    return crate::syntax::lexer::chars::map_chars(t_p0, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Text)>>(prism_rtl::rc([=](Text p0) {
        return once_job([=]() {
            return ({
                auto c_p1 = p0;
                (prism_rtl::finished(format_escape_char(c_p1)));
            });
        });
    })));
}


/// FormatEscapeChar: fn Text -> Text
Text format_escape_char(const Text& text0) {
    {
        auto&& c0_0 = text0;
        if (c0_0 == Text::lit("{")) {
            return Text::lit("{{");
        }
    }
    {
        auto&& c1_0 = text0;
        if (c1_0 == Text::lit("}")) {
            return Text::lit("}}");
        }
    }
    {
        auto&& c_p0 = text0;
        return c_p0;
    }
}


/// IfExpression: unbounded fn Ex, Ex, Ex -> Text
Text if_expression(const crate::lower::model::Ex& c_p0, const crate::lower::model::Ex& t_p1, const crate::lower::model::Ex& e_p2) {
    auto ct_p3 = expression(c_p0);
    auto tt_p4 = expression(t_p1);
    auto et_p5 = expression(e_p2);
    auto short_p6 = (!crate::syntax::lexer::chars::contains(prism_rtl::cat(tt_p4, et_p5), Text::lit("\n"))) && (len_text(prism_rtl::cat(ct_p3, tt_p4, et_p5)) < Nat(70u));
    return std::move(short_p6)
        ? prism_rtl::cat("if ", ct_p3, " { ", tt_p4, " } else { ", et_p5, " }")
        : crate::emit::rust::templates::items::if_(ct_p3, tt_p4, et_p5);
}


prism_rtl::Turn<Text> IfExpression::cycle() const {
    const auto& c_p0 = this->c_p0;
    const auto& t_p1 = this->t_p1;
    const auto& e_p2 = this->e_p2;
    auto c_p0_1 = c_p0;
    auto e_p2_2 = e_p2;
    auto t_p1_3 = t_p1;
    return call_then(start_expression(c_p0_1), [=](Text expression_9643) {
        return ({
            auto ct_p3 = expression_9643;
            call_then(start_expression(t_p1_3), [=, ct_p3 = std::move(ct_p3)](Text expression_9669) {
            return ({
                auto tt_p4 = expression_9669;
                call_then(start_expression(e_p2_2), [=, tt_p4 = std::move(tt_p4)](Text expression_9695) {
                return ({
                    auto et_p5 = expression_9695;
                    auto short_p6 = (!crate::syntax::lexer::chars::contains(prism_rtl::cat(tt_p4, et_p5), Text::lit("\n"))) && (len_text(prism_rtl::cat(ct_p3, tt_p4, et_p5)) < Nat(70u));
                    (std::move(short_p6)
                    ? prism_rtl::finished(prism_rtl::cat("if ", ct_p3, " { ", tt_p4, " } else { ", et_p5, " }"))
                    : prism_rtl::finished(crate::emit::rust::templates::items::if_(ct_p3, tt_p4, et_p5)));
                });
            });
            });
        });
        });
    });
}


/// `Start IfExpression, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_if_expression(crate::lower::model::Ex c_p0, crate::lower::model::Ex t_p1, crate::lower::model::Ex e_p2) {
    return prism_rtl::make_rc<IfExpression>(c_p0, t_p1, e_p2);
}


/// Arms: unbounded fn [XArm], Bool -> Text
Text arms(const Array<crate::lower::model::XArm>& arms_p0, const bool& fallback_p1) {
    auto lines_p2 = run_to_end(each_job(arms_p0, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::XArm)>>(prism_rtl::rc([=](crate::lower::model::XArm p0) {
        return entered(once_job([=]() {
            return ({
                auto a_p4 = p0;
                (prism_rtl::more(prism_rtl::rc(Arm(a_p4))));
            });
        }));
    }))));
    auto all_p3 = fallback_p1
        ? crate::prelude::push(lines_p2, Text::lit("_ => unreachable!(\"no arm matched\"),"))
        : lines_p2;
    return crate::syntax::lexer::chars::join(all_p3, Text::lit("\n"));
}


prism_rtl::Turn<Text> Arms::cycle() const {
    const auto& arms_p0 = this->arms_p0;
    const auto& fallback_p1 = this->fallback_p1;
    auto arms_p0_1 = arms_p0;
    auto fallback_p1_2 = prism_rtl::deref(fallback_p1);
    return call_value(each_job(arms_p0_1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::XArm)>>(prism_rtl::rc([=](crate::lower::model::XArm p0) {
        return entered(once_job([=]() {
            return ({
                auto a_p4 = p0;
                (prism_rtl::more(prism_rtl::rc(Arm(a_p4))));
            });
        }));
    }))), [=](Array<Text> each_10026) {
        return ({
            auto lines_p2 = each_10026;
            auto all_p3 = fallback_p1_2
                ? crate::prelude::push(lines_p2, Text::lit("_ => unreachable!(\"no arm matched\"),"))
                : lines_p2;
            (prism_rtl::finished(crate::syntax::lexer::chars::join(all_p3, Text::lit("\n"))));
        });
    });
}


/// `Start Arms, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_arms(Array<crate::lower::model::XArm> arms_p0, bool fallback_p1) {
    return prism_rtl::make_rc<Arms>(arms_p0, fallback_p1);
}


/// Arm: unbounded fn XArm -> Text
Text arm(const crate::lower::model::XArm& a_p0) {
    auto guard_p1 = len(a_p0.conds) == Nat(0u)
        ? Text::lit("")
        : prism_rtl::cat(" if ", crate::syntax::lexer::chars::join(run_to_end(each_job(a_p0.conds, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Cc)>>(prism_rtl::rc([=](crate::lower::model::Cc p0) {
        return entered(once_job([=]() {
            return ({
                auto c_p3 = p0;
                (prism_rtl::more(prism_rtl::rc(Condition(c_p3))));
            });
        }));
    })))), Text::lit(" && ")));
    auto body_p2 = expression(a_p0.body);
    return prism_rtl::cat(pattern(a_p0.pat), guard_p1, " => ", body_p2, ",");
}


prism_rtl::Turn<Text> Arm::cycle() const {
    const auto& a_p0 = this->a_p0;
    auto guard_p1 = len(prism_rtl::deref(a_p0).conds) == Nat(0u)
        ? Text::lit("")
        : prism_rtl::cat(" if ", crate::syntax::lexer::chars::join(run_to_end(each_job(prism_rtl::deref(a_p0).conds, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Cc)>>(prism_rtl::rc([=](crate::lower::model::Cc p0) {
        return entered(once_job([=]() {
            return ({
                auto c_p3 = p0;
                (prism_rtl::more(prism_rtl::rc(Condition(c_p3))));
            });
        }));
    })))), Text::lit(" && ")));
    auto a_p0_1 = a_p0;
    return call_then(start_expression(prism_rtl::deref(a_p0_1).body), [=](Text expression_10318) {
        return ({
            auto body_p2 = expression_10318;
            call_then(start_pattern(prism_rtl::deref(a_p0_1).pat), [=, body_p2 = std::move(body_p2)](Text pattern_10342) { return prism_rtl::finished(prism_rtl::cat(pattern_10342, guard_p1, " => ", body_p2, ",")); });
        });
    });
}


/// `Start Arm, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_arm(crate::lower::model::XArm a_p0) {
    return prism_rtl::make_rc<Arm>(a_p0);
}


/// Condition: unbounded fn Cc -> Text
Text condition(const crate::lower::model::Cc& cc0) {
    if (prism_rtl::is<crate::lower::model::Cc::CcIf>(cc0)) {
        auto&& x_p0 = prism_rtl::as<crate::lower::model::Cc::CcIf>(cc0).a0;
        return operand(x_p0);
    }
    if (prism_rtl::is<crate::lower::model::Cc::CcLet>(cc0)) {
        auto&& p_p1 = prism_rtl::as<crate::lower::model::Cc::CcLet>(cc0).a0;
        auto&& x_p2 = prism_rtl::as<crate::lower::model::Cc::CcLet>(cc0).a1;
        return prism_rtl::cat("let ", pattern(p_p1), " = ", expression(x_p2));
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Text> Condition::cycle() const {
    const auto& cc0 = this->cc0;
    return ({
        prism_rtl::is<crate::lower::model::Cc::CcIf>(cc0) ? ({
        auto&& x_p0 = prism_rtl::as<crate::lower::model::Cc::CcIf>(cc0).a0;
        prism_rtl::more(prism_rtl::rc(Operand(x_p0)));
    })
        : prism_rtl::is<crate::lower::model::Cc::CcLet>(cc0) ? ({
        auto&& p_p1 = prism_rtl::as<crate::lower::model::Cc::CcLet>(cc0).a0;
        auto&& x_p2 = prism_rtl::as<crate::lower::model::Cc::CcLet>(cc0).a1;
        ({
        auto p_p1_1 = p_p1;
        auto x_p2_2 = x_p2;
        call_then(start_pattern(p_p1_1), [=, x_p2_2 = std::move(x_p2_2)](Text pattern_10480) { return call_then(start_expression(x_p2_2), [=](Text expression_10494) { return prism_rtl::finished(prism_rtl::cat("let ", pattern_10480, " = ", expression_10494)); }); });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start Condition, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_condition(crate::lower::model::Cc cc0) {
    return prism_rtl::make_rc<Condition>(cc0);
}


/// Chain: unbounded fn Text, Ex, [XArm] -> Text
Text chain(const Text& label_p0, const crate::lower::model::Ex& s_p1, const Array<crate::lower::model::XArm>& arms_p2) {
    auto in_place_p3 = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        if (prism_rtl::is<crate::lower::model::Ex::XRef>(s_p1)) {
            auto&& y_p8 = prism_rtl::as<crate::lower::model::Ex::XRef>(s_p1).a0;
            _v.set(is_bound(prism_rtl::deref(prism_rtl::deref(y_p8))));
            goto _done;
        }
        {
            _v.set(is_bound(s_p1));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto [bind_p9, scrut_pa] = std::move(in_place_p3)
        ? std::tuple{Array<Text>{}, expression(s_p1)}
        : std::tuple{Array(std::vector{prism_rtl::cat("let scrutinee = ", expression(s_p1), ";")}), Text::lit("scrutinee")};
    auto n_p4 = len(arms_p2);
    auto lines_p5 = run_to_end(each_job(crate::check::errors::range0(n_p4), ({
        auto arms_p2_1 = arms_p2;
        auto scrut_pa_2 = scrut_pa;
        auto label_p0_3 = label_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Nat)>>(prism_rtl::rc([=, arms_p2_1 = std::move(arms_p2_1), scrut_pa_2 = std::move(scrut_pa_2), label_p0_3 = std::move(label_p0_3)](Nat p0) {
        return ({
            auto arms_p2_1_4 = arms_p2_1;
            auto scrut_pa_2_4 = scrut_pa_2;
            auto label_p0_3_4 = label_p0_3;
            entered(once_job([=, arms_p2_1_4 = std::move(arms_p2_1_4), scrut_pa_2_4 = std::move(scrut_pa_2_4), label_p0_3_4 = std::move(label_p0_3_4)]() {
            return ({
                auto i_pb = p0;
                ({
                auto a_pc = or_(index(arms_p2_1_4, i_pb), crate::lower::model::XArm{.pat = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds = Array<crate::lower::model::Cc>{}, .body = crate::lower::model::Ex(crate::lower::model::Ex::XUnit{})});
                auto catch_all_pd = (prism_rtl::deref(a_pc).pat == crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})) && (len(prism_rtl::deref(a_pc).conds) == Nat(0u));
                (std::move(catch_all_pd)
                ? prism_rtl::more(prism_rtl::rc(Expression(prism_rtl::deref(a_pc).body)))
                : call_then(start_pattern(prism_rtl::deref(a_pc).pat), [=](Text pattern_11207) {
                return call_value(each_job(prism_rtl::deref(a_pc).conds, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Cc)>>(prism_rtl::rc([=](crate::lower::model::Cc p0) {
                    return entered(once_job([=]() {
                        return ({
                            auto c_pf = p0;
                            (prism_rtl::more(prism_rtl::rc(Condition(c_pf))));
                        });
                    }));
                }))), [=](Array<Text> each_11237) {
                    return ({
                        auto head_pe = crate::syntax::lexer::chars::join(append(Array(std::vector{prism_rtl::cat("let ", pattern_11207, " = ", scrut_pa_2_4)}), each_11237), Text::lit(" && "));
                        call_then(start_expression(prism_rtl::deref(a_pc).body), [=, head_pe = std::move(head_pe)](Text expression_11324) { return prism_rtl::finished(crate::emit::rust::templates::items::chain_arm(head_pe, label_p0_3_4, continued(expression_11324, Text::lit("    ")))); });
                    });
                });
            }));
            });
            });
        }));
        });
    })));
    })));
    auto ends_p6 = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = crate::syntax::lexer::chars::last(arms_p2);
        if (prism_rtl::is_some(_m)) {
            auto&& a_pg = prism_rtl::some_of(_m);
            _v.set((prism_rtl::deref(a_pg).pat == crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})) && (len(prism_rtl::deref(a_pg).conds) == Nat(0u)));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(false);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto tail_p7 = std::move(ends_p6)
        ? Array<Text>{}
        : Array(std::vector{Text::lit("unreachable!(\"no clause matched\")")});
    return prism_rtl::cat(label_p0, ": {\n", indent(crate::syntax::lexer::chars::join(append(append(bind_p9, lines_p5), tail_p7), Text::lit("\n"))), "\n}");
}


prism_rtl::Turn<Text> Chain::cycle() const {
    const auto& label_p0 = this->label_p0;
    const auto& s_p1 = this->s_p1;
    const auto& arms_p2 = this->arms_p2;
    auto in_place_p3 = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        if (prism_rtl::is<crate::lower::model::Ex::XRef>(s_p1)) {
            auto&& y_p8 = prism_rtl::as<crate::lower::model::Ex::XRef>(s_p1).a0;
            _v.set(is_bound(prism_rtl::deref(prism_rtl::deref(y_p8))));
            goto _done;
        }
        {
            _v.set(is_bound(s_p1));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto [bind_p9, scrut_pa] = std::move(in_place_p3)
        ? std::tuple{Array<Text>{}, expression(s_p1)}
        : std::tuple{Array(std::vector{prism_rtl::cat("let scrutinee = ", expression(s_p1), ";")}), Text::lit("scrutinee")};
    auto n_p4 = len(arms_p2);
    auto arms_p2_1 = arms_p2;
    auto label_p0_2 = label_p0;
    auto s_p1_3 = s_p1;
    return call_value(each_job(crate::check::errors::range0(n_p4), ({
        auto arms_p2_1_4 = arms_p2_1;
        auto scrut_pa_4 = scrut_pa;
        auto label_p0_2_5 = label_p0_2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Nat)>>(prism_rtl::rc([=, arms_p2_1_4 = std::move(arms_p2_1_4), scrut_pa_4 = std::move(scrut_pa_4), label_p0_2_5 = std::move(label_p0_2_5)](Nat p0) {
        return ({
            auto arms_p2_1_4_5 = arms_p2_1_4;
            auto scrut_pa_4_5 = scrut_pa_4;
            auto label_p0_2_5_5 = label_p0_2_5;
            entered(once_job([=, arms_p2_1_4_5 = std::move(arms_p2_1_4_5), scrut_pa_4_5 = std::move(scrut_pa_4_5), label_p0_2_5_5 = std::move(label_p0_2_5_5)]() {
            return ({
                auto i_pb = p0;
                ({
                auto a_pc = or_(index(arms_p2_1_4_5, i_pb), crate::lower::model::XArm{.pat = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds = Array<crate::lower::model::Cc>{}, .body = crate::lower::model::Ex(crate::lower::model::Ex::XUnit{})});
                auto catch_all_pd = (prism_rtl::deref(a_pc).pat == crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})) && (len(prism_rtl::deref(a_pc).conds) == Nat(0u));
                (std::move(catch_all_pd)
                ? prism_rtl::more(prism_rtl::rc(Expression(prism_rtl::deref(a_pc).body)))
                : call_then(start_pattern(prism_rtl::deref(a_pc).pat), [=](Text pattern_11207) {
                return call_value(each_job(prism_rtl::deref(a_pc).conds, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Cc)>>(prism_rtl::rc([=](crate::lower::model::Cc p0) {
                    return entered(once_job([=]() {
                        return ({
                            auto c_pf = p0;
                            (prism_rtl::more(prism_rtl::rc(Condition(c_pf))));
                        });
                    }));
                }))), [=](Array<Text> each_11237) {
                    return ({
                        auto head_pe = crate::syntax::lexer::chars::join(append(Array(std::vector{prism_rtl::cat("let ", pattern_11207, " = ", scrut_pa_4_5)}), each_11237), Text::lit(" && "));
                        call_then(start_expression(prism_rtl::deref(a_pc).body), [=, head_pe = std::move(head_pe)](Text expression_11324) { return prism_rtl::finished(crate::emit::rust::templates::items::chain_arm(head_pe, label_p0_2_5_5, continued(expression_11324, Text::lit("    ")))); });
                    });
                });
            }));
            });
            });
        }));
        });
    })));
    })), [=](Array<Text> each_10953) {
        return ({
            auto lines_p5 = each_10953;
            auto ends_p6 = ({
                __label__ _done;
                prism_rtl::Slot<bool> _v;
                auto&& _m = crate::syntax::lexer::chars::last(arms_p2_1);
                if (prism_rtl::is_some(_m)) {
                    auto&& a_pg = prism_rtl::some_of(_m);
                    _v.set((prism_rtl::deref(a_pg).pat == crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})) && (len(prism_rtl::deref(a_pg).conds) == Nat(0u)));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(false);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            auto tail_p7 = std::move(ends_p6)
                ? Array<Text>{}
                : Array(std::vector{Text::lit("unreachable!(\"no clause matched\")")});
            (prism_rtl::finished(prism_rtl::cat(label_p0_2, ": {\n", indent(crate::syntax::lexer::chars::join(append(append(bind_p9, lines_p5), tail_p7), Text::lit("\n"))), "\n}")));
        });
    });
}


/// `Start Chain, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_chain(Text label_p0, crate::lower::model::Ex s_p1, Array<crate::lower::model::XArm> arms_p2) {
    return prism_rtl::make_rc<Chain>(label_p0, s_p1, arms_p2);
}


/// IsBound: fn Ex -> Bool
bool is_bound(const crate::lower::model::Ex& x_p0) {
    if (prism_rtl::is<crate::lower::model::Ex::XVar>(x_p0)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XField>(x_p0)) {
        auto&& m11828_1_0 = prism_rtl::as<crate::lower::model::Ex::XField>(x_p0).a0;
        if (prism_rtl::is<crate::lower::model::Ex::XSelf>(prism_rtl::deref(prism_rtl::deref(m11828_1_0)))) {
            return true;
        }
    }
    if (prism_rtl::is<crate::lower::model::Ex::XField>(x_p0)) {
        auto&& m11828_2_0 = prism_rtl::as<crate::lower::model::Ex::XField>(x_p0).a0;
        if (prism_rtl::is<crate::lower::model::Ex::XMethod>(prism_rtl::deref(prism_rtl::deref(m11828_2_0)))) {
            auto&& m11828_2_0_r_0 = prism_rtl::as<crate::lower::model::Ex::XMethod>(prism_rtl::deref(prism_rtl::deref(m11828_2_0))).a0;
            if (prism_rtl::is<crate::lower::model::Ex::XUpgrade>(prism_rtl::deref(prism_rtl::deref(m11828_2_0_r_0)))) {
                return true;
            }
        }
    }
    if (prism_rtl::is<crate::lower::model::Ex::XTarget>(x_p0)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XPart>(x_p0)) {
        auto&& m11828_4_0 = prism_rtl::as<crate::lower::model::Ex::XPart>(x_p0).a0;
        if (prism_rtl::is<crate::lower::model::Ex::XVar>(prism_rtl::deref(prism_rtl::deref(m11828_4_0)))) {
            return true;
        }
    }
    {
        return false;
    }
}


/// Continued: fn Text, Text -> Text
Text continued(const Text& t_p0, const Text& pad_p1) {
    auto ls_p2 = split_on(t_p0, Text::lit("\n"));
    return crate::syntax::lexer::chars::join(each(crate::check::errors::range0(len(ls_p2)), [&](const Nat& i_p3) {
        return (i_p3 == Nat(0u)) || (or_(index(ls_p2, i_p3), Text::lit("")) == Text::lit(""))
            ? or_(index(ls_p2, i_p3), Text::lit(""))
            : prism_rtl::cat(pad_p1, or_(index(ls_p2, i_p3), Text::lit("")));
    }), Text::lit("\n"));
}


/// BodyLines: unbounded fn Ex -> Text
Text body_lines(const crate::lower::model::Ex& ex0) {
    if (prism_rtl::is<crate::lower::model::Ex::XBlock>(ex0)) {
        auto&& dos_p0 = prism_rtl::as<crate::lower::model::Ex::XBlock>(ex0).a0;
        auto&& e_p1 = prism_rtl::as<crate::lower::model::Ex::XBlock>(ex0).a1;
        return len(dos_p0) == Nat(0u)
            ? body_lines(prism_rtl::deref(prism_rtl::deref(e_p1)))
            : prism_rtl::cat(statements(dos_p0), "\n", body_lines(prism_rtl::deref(prism_rtl::deref(e_p1))));
    }
    {
        auto&& x_p2 = ex0;
        return expression(x_p2);
    }
}


prism_rtl::Turn<Text> BodyLines::cycle() const {
    const auto& ex0 = this->ex0;
    return ({
        prism_rtl::is<crate::lower::model::Ex::XBlock>(ex0) ? ({
        auto&& dos_p0 = prism_rtl::as<crate::lower::model::Ex::XBlock>(ex0).a0;
        auto&& e_p1 = prism_rtl::as<crate::lower::model::Ex::XBlock>(ex0).a1;
        len(dos_p0) == Nat(0u)
        ? prism_rtl::more(prism_rtl::rc(BodyLines(prism_rtl::deref(prism_rtl::deref(e_p1)))))
        : ({
        auto dos_p0_1 = dos_p0;
        auto e_p1_2 = prism_rtl::deref(prism_rtl::deref(e_p1));
        call_then(start_statements(dos_p0_1), [=, e_p1_2 = std::move(e_p1_2)](Text statements_12514) { return call_then(start_body_lines(e_p1_2), [=](Text body_lines_12532) { return prism_rtl::finished(prism_rtl::cat(statements_12514, "\n", body_lines_12532)); }); });
    });
    })
        : ({
        auto&& x_p2 = ex0;
        prism_rtl::more(prism_rtl::rc(Expression(x_p2)));
    });
    });
}


/// `Start BodyLines, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_body_lines(crate::lower::model::Ex ex0) {
    return prism_rtl::make_rc<BodyLines>(ex0);
}


/// Indent: fn Text -> Text
Text indent(const Text& t_p0) {
    return crate::syntax::lexer::chars::join(each(split_on(t_p0, Text::lit("\n")), [&](const Text& l_p1) { return l_p1 == Text::lit("") ? Text::lit("") : prism_rtl::cat("    ", l_p1); }), Text::lit("\n"));
}


/// Pattern: unbounded fn Pa -> Text
Text pattern(const crate::lower::model::Pa& p_p0) {
    if (prism_rtl::is<crate::lower::model::Pa::PaWild>(p_p0)) {
        return Text::lit("_");
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaBind>(p_p0)) {
        auto&& n_p1 = prism_rtl::as<crate::lower::model::Pa::PaBind>(p_p0).a0;
        return n_p1;
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaMut>(p_p0)) {
        auto&& n_p2 = prism_rtl::as<crate::lower::model::Pa::PaMut>(p_p0).a0;
        return prism_rtl::cat("mut ", n_p2);
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaCtor>(p_p0)) {
        auto&& c_p3 = prism_rtl::as<crate::lower::model::Pa::PaCtor>(p_p0).a0;
        auto&& ps_p4 = prism_rtl::as<crate::lower::model::Pa::PaCtor>(p_p0).a1;
        return prism_rtl::cat(c_p3, "(", crate::syntax::lexer::chars::join(run_to_end(each_job(ps_p4, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Pa)>>(prism_rtl::rc([=](crate::lower::model::Pa p0) {
            return entered(once_job([=]() {
                return ({
                    auto q_p5 = p0;
                    (prism_rtl::more(prism_rtl::rc(Pattern_(q_p5))));
                });
            }));
        })))), Text::lit(", ")), ")");
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaUnit>(p_p0)) {
        auto&& c_p6 = prism_rtl::as<crate::lower::model::Pa::PaUnit>(p_p0).a0;
        return c_p6;
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaRecord>(p_p0)) {
        auto&& c_p7 = prism_rtl::as<crate::lower::model::Pa::PaRecord>(p_p0).a0;
        auto&& fs_p8 = prism_rtl::as<crate::lower::model::Pa::PaRecord>(p_p0).a1;
        auto&& rest_p9 = prism_rtl::as<crate::lower::model::Pa::PaRecord>(p_p0).a2;
        auto parts_pa = run_to_end(each_job(fs_p8, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::Pa>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::Pa> p0) {
            return entered(once_job([=]() {
                return ({
                    auto [f_pc, q_pd] = p0;
                    ({
                    prism_rtl::is<crate::lower::model::Pa::PaBind>(q_pd) ? ({
                    auto&& n_pe = prism_rtl::as<crate::lower::model::Pa::PaBind>(q_pd).a0;
                    n_pe == f_pc
                    ? prism_rtl::finished(f_pc)
                    : prism_rtl::finished(prism_rtl::cat(f_pc, ": ", n_pe));
                })
                    : call_then(start_pattern(q_pd), [=](Text pattern_13285) { return prism_rtl::finished(prism_rtl::cat(f_pc, ": ", pattern_13285)); });
                });
                });
            }));
        }))));
        auto all_pb = prism_rtl::deref(rest_p9)
            ? crate::prelude::push(parts_pa, Text::lit(".."))
            : parts_pa;
        return prism_rtl::cat(c_p7, " { ", crate::syntax::lexer::chars::join(all_pb, Text::lit(", ")), " }");
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaTuple>(p_p0)) {
        auto&& m12983_6_0 = prism_rtl::as<crate::lower::model::Pa::PaTuple>(p_p0).a0;
        if (m12983_6_0.size() == 1u) {
            {
                auto&& _c1 = index(m12983_6_0, Nat(0u));
                if (prism_rtl::is_some(_c1)) {
                    auto&& one_pf = prism_rtl::some_of(_c1);
                    return prism_rtl::cat("(", pattern(one_pf), ",)");
                }
            }
        }
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaTuple>(p_p0)) {
        auto&& ps_pg = prism_rtl::as<crate::lower::model::Pa::PaTuple>(p_p0).a0;
        return prism_rtl::cat("(", crate::syntax::lexer::chars::join(run_to_end(each_job(ps_pg, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Pa)>>(prism_rtl::rc([=](crate::lower::model::Pa p0) {
            return entered(once_job([=]() {
                return ({
                    auto q_ph = p0;
                    (prism_rtl::more(prism_rtl::rc(Pattern_(q_ph))));
                });
            }));
        })))), Text::lit(", ")), ")");
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaChar>(p_p0)) {
        auto&& c_pi = prism_rtl::as<crate::lower::model::Pa::PaChar>(p_p0).a0;
        return prism_rtl::cat("\'", crate::lower::expr::char_escape(c_pi), "\'");
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaBool>(p_p0)) {
        auto&& b_pj = prism_rtl::as<crate::lower::model::Pa::PaBool>(p_p0).a0;
        return prism_rtl::deref(b_pj) ? Text::lit("true") : Text::lit("false");
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaIndex>(p_p0)) {
        auto&& n_pk = prism_rtl::as<crate::lower::model::Pa::PaIndex>(p_p0).a0;
        return prism_rtl::cat(n_pk);
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaConst>(p_p0)) {
        auto&& n_pl = prism_rtl::as<crate::lower::model::Pa::PaConst>(p_p0).a0;
        return prism_rtl::cat("Self::", n_pl);
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaSlice>(p_p0)) {
        auto&& ps_pm = prism_rtl::as<crate::lower::model::Pa::PaSlice>(p_p0).a0;
        return prism_rtl::cat("[", crate::syntax::lexer::chars::join(run_to_end(each_job(ps_pm, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Pa)>>(prism_rtl::rc([=](crate::lower::model::Pa p0) {
            return entered(once_job([=]() {
                return ({
                    auto q_pn = p0;
                    (prism_rtl::more(prism_rtl::rc(Pattern_(q_pn))));
                });
            }));
        })))), Text::lit(", ")), "]");
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaRest>(p_p0)) {
        auto&& m12983_13_0 = prism_rtl::as<crate::lower::model::Pa::PaRest>(p_p0).a0;
        if (m12983_13_0 == Text::lit("")) {
            return Text::lit("..");
        }
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaRest>(p_p0)) {
        auto&& n_po = prism_rtl::as<crate::lower::model::Pa::PaRest>(p_p0).a0;
        return prism_rtl::cat(n_po, " @ ..");
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaTyped>(p_p0)) {
        auto&& q_pp = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_p0).a0;
        auto&& t_pq = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_p0).a1;
        return prism_rtl::cat(pattern(prism_rtl::deref(prism_rtl::deref(q_pp))), ": ", type_(t_pq));
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Text> Pattern_::cycle() const {
    const auto& p_p0 = this->p_p0;
    return ({
        prism_rtl::is<crate::lower::model::Pa::PaWild>(p_p0) ? prism_rtl::finished(Text::lit("_"))
        : prism_rtl::is<crate::lower::model::Pa::PaBind>(p_p0) ? ({
        auto&& n_p1 = prism_rtl::as<crate::lower::model::Pa::PaBind>(p_p0).a0;
        prism_rtl::finished(n_p1);
    })
        : prism_rtl::is<crate::lower::model::Pa::PaMut>(p_p0) ? ({
        auto&& n_p2 = prism_rtl::as<crate::lower::model::Pa::PaMut>(p_p0).a0;
        prism_rtl::finished(prism_rtl::cat("mut ", n_p2));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaCtor>(p_p0) ? ({
        auto&& c_p3 = prism_rtl::as<crate::lower::model::Pa::PaCtor>(p_p0).a0;
        auto&& ps_p4 = prism_rtl::as<crate::lower::model::Pa::PaCtor>(p_p0).a1;
        ({
        auto c_p3_1 = c_p3;
        auto ps_p4_2 = ps_p4;
        call_value(each_job(ps_p4_2, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Pa)>>(prism_rtl::rc([=](crate::lower::model::Pa p0) {
        return entered(once_job([=]() {
            return ({
                auto q_p5 = p0;
                (prism_rtl::more(prism_rtl::rc(Pattern_(q_p5))));
            });
        }));
    }))), [=, c_p3_1 = std::move(c_p3_1)](Array<Text> each_13077) { return prism_rtl::finished(prism_rtl::cat(c_p3_1, "(", crate::syntax::lexer::chars::join(each_13077, Text::lit(", ")), ")")); });
    });
    })
        : prism_rtl::is<crate::lower::model::Pa::PaUnit>(p_p0) ? ({
        auto&& c_p6 = prism_rtl::as<crate::lower::model::Pa::PaUnit>(p_p0).a0;
        prism_rtl::finished(c_p6);
    })
        : prism_rtl::is<crate::lower::model::Pa::PaRecord>(p_p0) ? ({
        auto&& c_p7 = prism_rtl::as<crate::lower::model::Pa::PaRecord>(p_p0).a0;
        auto&& fs_p8 = prism_rtl::as<crate::lower::model::Pa::PaRecord>(p_p0).a1;
        auto&& rest_p9 = prism_rtl::as<crate::lower::model::Pa::PaRecord>(p_p0).a2;
        ({
        auto c_p7_1 = c_p7;
        auto fs_p8_2 = fs_p8;
        auto rest_p9_3 = prism_rtl::deref(rest_p9);
        call_value(each_job(fs_p8_2, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::Pa>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::Pa> p0) {
        return entered(once_job([=]() {
            return ({
                auto [f_pc, q_pd] = p0;
                ({
                prism_rtl::is<crate::lower::model::Pa::PaBind>(q_pd) ? ({
                auto&& n_pe = prism_rtl::as<crate::lower::model::Pa::PaBind>(q_pd).a0;
                n_pe == f_pc
                ? prism_rtl::finished(f_pc)
                : prism_rtl::finished(prism_rtl::cat(f_pc, ": ", n_pe));
            })
                : call_then(start_pattern(q_pd), [=](Text pattern_13285) { return prism_rtl::finished(prism_rtl::cat(f_pc, ": ", pattern_13285)); });
            });
            });
        }));
    }))), [=, c_p7_1 = std::move(c_p7_1), rest_p9_3 = std::move(rest_p9_3)](Array<Text> each_13173) {
        return ({
            auto parts_pa = each_13173;
            auto all_pb = rest_p9_3 ? crate::prelude::push(parts_pa, Text::lit("..")) : parts_pa;
            (prism_rtl::finished(prism_rtl::cat(c_p7_1, " { ", crate::syntax::lexer::chars::join(all_pb, Text::lit(", ")), " }")));
        });
    });
    });
    })
        : prism_rtl::is<crate::lower::model::Pa::PaTuple>(p_p0) && ({
        auto&& m12983_6_0 = prism_rtl::as<crate::lower::model::Pa::PaTuple>(p_p0).a0;
        (m12983_6_0.size() == 1u) && ({
        auto&& _c1 = index(m12983_6_0, Nat(0u));
        prism_rtl::is_some(_c1);
    });
    }) ? ({
        auto&& m12983_6_0 = prism_rtl::as<crate::lower::model::Pa::PaTuple>(p_p0).a0;
        auto&& _c1 = index(m12983_6_0, Nat(0u));
        auto&& one_pf = prism_rtl::some_of(_c1);
        call_then(start_pattern(one_pf), [=](Text pattern_13414) { return prism_rtl::finished(prism_rtl::cat("(", pattern_13414, ",)")); });
    })
        : prism_rtl::is<crate::lower::model::Pa::PaTuple>(p_p0) ? ({
        auto&& ps_pg = prism_rtl::as<crate::lower::model::Pa::PaTuple>(p_p0).a0;
        ({
        auto ps_pg_1 = ps_pg;
        call_value(each_job(ps_pg_1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Pa)>>(prism_rtl::rc([=](crate::lower::model::Pa p0) {
        return entered(once_job([=]() {
            return ({
                auto q_ph = p0;
                (prism_rtl::more(prism_rtl::rc(Pattern_(q_ph))));
            });
        }));
    }))), [=](Array<Text> each_13455) { return prism_rtl::finished(prism_rtl::cat("(", crate::syntax::lexer::chars::join(each_13455, Text::lit(", ")), ")")); });
    });
    })
        : prism_rtl::is<crate::lower::model::Pa::PaChar>(p_p0) ? ({
        auto&& c_pi = prism_rtl::as<crate::lower::model::Pa::PaChar>(p_p0).a0;
        prism_rtl::finished(prism_rtl::cat("\'", crate::lower::expr::char_escape(c_pi), "\'"));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaBool>(p_p0) ? ({
        auto&& b_pj = prism_rtl::as<crate::lower::model::Pa::PaBool>(p_p0).a0;
        prism_rtl::deref(b_pj)
        ? prism_rtl::finished(Text::lit("true"))
        : prism_rtl::finished(Text::lit("false"));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaIndex>(p_p0) ? ({
        auto&& n_pk = prism_rtl::as<crate::lower::model::Pa::PaIndex>(p_p0).a0;
        prism_rtl::finished(prism_rtl::cat(n_pk));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaConst>(p_p0) ? ({
        auto&& n_pl = prism_rtl::as<crate::lower::model::Pa::PaConst>(p_p0).a0;
        prism_rtl::finished(prism_rtl::cat("Self::", n_pl));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaSlice>(p_p0) ? ({
        auto&& ps_pm = prism_rtl::as<crate::lower::model::Pa::PaSlice>(p_p0).a0;
        ({
        auto ps_pm_1 = ps_pm;
        call_value(each_job(ps_pm_1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Pa)>>(prism_rtl::rc([=](crate::lower::model::Pa p0) {
        return entered(once_job([=]() {
            return ({
                auto q_pn = p0;
                (prism_rtl::more(prism_rtl::rc(Pattern_(q_pn))));
            });
        }));
    }))), [=](Array<Text> each_13636) { return prism_rtl::finished(prism_rtl::cat("[", crate::syntax::lexer::chars::join(each_13636, Text::lit(", ")), "]")); });
    });
    })
        : prism_rtl::is<crate::lower::model::Pa::PaRest>(p_p0) && ({
        auto&& m12983_13_0 = prism_rtl::as<crate::lower::model::Pa::PaRest>(p_p0).a0;
        (m12983_13_0 == Text::lit(""));
    }) ? ({
        auto&& m12983_13_0 = prism_rtl::as<crate::lower::model::Pa::PaRest>(p_p0).a0;
        prism_rtl::finished(Text::lit(".."));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaRest>(p_p0) ? ({
        auto&& n_po = prism_rtl::as<crate::lower::model::Pa::PaRest>(p_p0).a0;
        prism_rtl::finished(prism_rtl::cat(n_po, " @ .."));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaTyped>(p_p0) ? ({
        auto&& q_pp = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_p0).a0;
        auto&& t_pq = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_p0).a1;
        ({
        auto q_pp_1 = prism_rtl::deref(prism_rtl::deref(q_pp));
        auto t_pq_2 = t_pq;
        call_then(start_pattern(q_pp_1), [=, t_pq_2 = std::move(t_pq_2)](Text pattern_13735) { return call_then(start_type_(t_pq_2), [=](Text type__13748) { return prism_rtl::finished(prism_rtl::cat(pattern_13735, ": ", type__13748)); }); });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start Pattern_, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_pattern(crate::lower::model::Pa p_p0) {
    return prism_rtl::make_rc<Pattern_>(p_p0);
}


/// Statements: unbounded fn [Do] -> Text
Text statements(const Array<crate::lower::model::Do>& dos_p0) {
    return crate::syntax::lexer::chars::join(run_to_end(each_job(dos_p0, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Do)>>(prism_rtl::rc([=](crate::lower::model::Do p0) {
        return entered(once_job([=]() {
            return ({
                auto d_p1 = p0;
                (prism_rtl::more(prism_rtl::rc(Statement(d_p1))));
            });
        }));
    })))), Text::lit("\n"));
}


prism_rtl::Turn<Text> Statements::cycle() const {
    const auto& dos_p0 = this->dos_p0;
    auto dos_p0_1 = dos_p0;
    return call_value(each_job(dos_p0_1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Do)>>(prism_rtl::rc([=](crate::lower::model::Do p0) {
        return entered(once_job([=]() {
            return ({
                auto d_p1 = p0;
                (prism_rtl::more(prism_rtl::rc(Statement(d_p1))));
            });
        }));
    }))), [=](Array<Text> each_13822) { return prism_rtl::finished(crate::syntax::lexer::chars::join(each_13822, Text::lit("\n"))); });
}


/// `Start Statements, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_statements(Array<crate::lower::model::Do> dos_p0) {
    return prism_rtl::make_rc<Statements>(dos_p0);
}


/// Statement: unbounded fn Do -> Text
Text statement(const crate::lower::model::Do& d_p0) {
    if (prism_rtl::is<crate::lower::model::Do::DoLet>(d_p0)) {
        auto&& p_p1 = prism_rtl::as<crate::lower::model::Do::DoLet>(d_p0).a0;
        auto&& x_p2 = prism_rtl::as<crate::lower::model::Do::DoLet>(d_p0).a1;
        return prism_rtl::cat("let ", pattern(p_p1), " = ", expression(x_p2), ";");
    }
    if (prism_rtl::is<crate::lower::model::Do::DoLetElse>(d_p0)) {
        auto&& p_p3 = prism_rtl::as<crate::lower::model::Do::DoLetElse>(d_p0).a0;
        auto&& x_p4 = prism_rtl::as<crate::lower::model::Do::DoLetElse>(d_p0).a1;
        auto&& e_p5 = prism_rtl::as<crate::lower::model::Do::DoLetElse>(d_p0).a2;
        return prism_rtl::cat("let ", pattern(p_p3), " = ", expression(x_p4), " else { ", expression(e_p5), " };");
    }
    if (prism_rtl::is<crate::lower::model::Do::DoAssign>(d_p0)) {
        auto&& p_p6 = prism_rtl::as<crate::lower::model::Do::DoAssign>(d_p0).a0;
        auto&& x_p7 = prism_rtl::as<crate::lower::model::Do::DoAssign>(d_p0).a1;
        return prism_rtl::cat(expression(p_p6), " = ", expression(x_p7), ";");
    }
    if (prism_rtl::is<crate::lower::model::Do::DoWhile>(d_p0)) {
        auto&& c_p8 = prism_rtl::as<crate::lower::model::Do::DoWhile>(d_p0).a0;
        auto&& body_p9 = prism_rtl::as<crate::lower::model::Do::DoWhile>(d_p0).a1;
        return crate::emit::rust::templates::items::if_stmt(prism_rtl::cat("while ", expression(c_p8)), statements(body_p9));
    }
    if (prism_rtl::is<crate::lower::model::Do::DoWhileLet>(d_p0)) {
        auto&& p_pa = prism_rtl::as<crate::lower::model::Do::DoWhileLet>(d_p0).a0;
        auto&& x_pb = prism_rtl::as<crate::lower::model::Do::DoWhileLet>(d_p0).a1;
        auto&& body_pc = prism_rtl::as<crate::lower::model::Do::DoWhileLet>(d_p0).a2;
        return crate::emit::rust::templates::items::if_stmt(prism_rtl::cat("while let ", pattern(p_pa), " = ", expression(x_pb)), statements(body_pc));
    }
    if (prism_rtl::is<crate::lower::model::Do::DoFor>(d_p0)) {
        auto&& p_pd = prism_rtl::as<crate::lower::model::Do::DoFor>(d_p0).a0;
        auto&& x_pe = prism_rtl::as<crate::lower::model::Do::DoFor>(d_p0).a1;
        auto&& body_pf = prism_rtl::as<crate::lower::model::Do::DoFor>(d_p0).a2;
        return crate::emit::rust::templates::items::if_stmt(prism_rtl::cat("for ", pattern(p_pd), " in ", expression(x_pe)), statements(body_pf));
    }
    if (prism_rtl::is<crate::lower::model::Do::DoExpr>(d_p0)) {
        auto&& x_pg = prism_rtl::as<crate::lower::model::Do::DoExpr>(d_p0).a0;
        return prism_rtl::cat(expression(x_pg), ";");
    }
    if (prism_rtl::is<crate::lower::model::Do::DoIf>(d_p0)) {
        auto&& c_ph = prism_rtl::as<crate::lower::model::Do::DoIf>(d_p0).a0;
        auto&& t_pi = prism_rtl::as<crate::lower::model::Do::DoIf>(d_p0).a1;
        auto&& e_pj = prism_rtl::as<crate::lower::model::Do::DoIf>(d_p0).a2;
        return prism_rtl::cat(crate::emit::rust::templates::items::if_stmt(prism_rtl::cat("if ", expression(c_ph)), statements(t_pi)), else_branch(e_pj));
    }
    if (prism_rtl::is<crate::lower::model::Do::DoIfLet>(d_p0)) {
        auto&& p_pk = prism_rtl::as<crate::lower::model::Do::DoIfLet>(d_p0).a0;
        auto&& x_pl = prism_rtl::as<crate::lower::model::Do::DoIfLet>(d_p0).a1;
        auto&& t_pm = prism_rtl::as<crate::lower::model::Do::DoIfLet>(d_p0).a2;
        auto&& e_pn = prism_rtl::as<crate::lower::model::Do::DoIfLet>(d_p0).a3;
        return prism_rtl::cat(crate::emit::rust::templates::items::if_stmt(prism_rtl::cat("if let ", pattern(p_pk), " = ", expression(x_pl)), statements(t_pm)), else_branch(e_pn));
    }
    if (prism_rtl::is<crate::lower::model::Do::DoMatch>(d_p0)) {
        auto&& x_po = prism_rtl::as<crate::lower::model::Do::DoMatch>(d_p0).a0;
        auto&& cases_pp = prism_rtl::as<crate::lower::model::Do::DoMatch>(d_p0).a1;
        return crate::emit::rust::templates::items::match_block(expression(x_po), crate::syntax::lexer::chars::join(run_to_end(each_job(cases_pp, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<crate::lower::model::Pa, Array<crate::lower::model::Do>>)>>(prism_rtl::rc([=](std::tuple<crate::lower::model::Pa, Array<crate::lower::model::Do>> p0) {
            return entered(once_job([=]() {
                return ({
                    auto [p_pq, body_pr] = p0;
                    call_then(start_pattern(p_pq), [=](Text pattern_14664) { return call_then(start_statements(body_pr), [=](Text statements_14677) { return prism_rtl::finished(crate::emit::rust::templates::items::arm_block(pattern_14664, statements_14677)); }); });
                });
            }));
        })))), Text::lit("\n")));
    }
    if (prism_rtl::is<crate::lower::model::Do::DoReturn>(d_p0)) {
        auto&& x_ps = prism_rtl::as<crate::lower::model::Do::DoReturn>(d_p0).a0;
        return prism_rtl::cat("return ", expression(x_ps), ";");
    }
    if (prism_rtl::is<crate::lower::model::Do::DoBlock>(d_p0)) {
        auto&& body_pt = prism_rtl::as<crate::lower::model::Do::DoBlock>(d_p0).a0;
        return crate::emit::rust::templates::items::scope(statements(body_pt));
    }
    if (prism_rtl::is<crate::lower::model::Do::DoScope>(d_p0)) {
        auto&& body_pu = prism_rtl::as<crate::lower::model::Do::DoScope>(d_p0).a0;
        return prism_rtl::cat("{ ", inline_statements(body_pu), " };");
    }
    if (prism_rtl::is<crate::lower::model::Do::DoLine>(d_p0)) {
        auto&& body_pv = prism_rtl::as<crate::lower::model::Do::DoLine>(d_p0).a0;
        return prism_rtl::cat(inline_statements(body_pv), ";");
    }
    if (prism_rtl::is<crate::lower::model::Do::DoNote>(d_p0)) {
        auto&& t_p10 = prism_rtl::as<crate::lower::model::Do::DoNote>(d_p0).a0;
        return prism_rtl::cat("// ", t_p10);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Text> Statement::cycle() const {
    const auto& d_p0 = this->d_p0;
    return ({
        prism_rtl::is<crate::lower::model::Do::DoLet>(d_p0) ? ({
        auto&& p_p1 = prism_rtl::as<crate::lower::model::Do::DoLet>(d_p0).a0;
        auto&& x_p2 = prism_rtl::as<crate::lower::model::Do::DoLet>(d_p0).a1;
        ({
        auto p_p1_1 = p_p1;
        auto x_p2_2 = x_p2;
        call_then(start_pattern(p_p1_1), [=, x_p2_2 = std::move(x_p2_2)](Text pattern_13940) { return call_then(start_expression(x_p2_2), [=](Text expression_13954) { return prism_rtl::finished(prism_rtl::cat("let ", pattern_13940, " = ", expression_13954, ";")); }); });
    });
    })
        : prism_rtl::is<crate::lower::model::Do::DoLetElse>(d_p0) ? ({
        auto&& p_p3 = prism_rtl::as<crate::lower::model::Do::DoLetElse>(d_p0).a0;
        auto&& x_p4 = prism_rtl::as<crate::lower::model::Do::DoLetElse>(d_p0).a1;
        auto&& e_p5 = prism_rtl::as<crate::lower::model::Do::DoLetElse>(d_p0).a2;
        ({
        auto e_p5_1 = e_p5;
        auto p_p3_2 = p_p3;
        auto x_p4_3 = x_p4;
        call_then(start_pattern(p_p3_2), [=, e_p5_1 = std::move(e_p5_1), x_p4_3 = std::move(x_p4_3)](Text pattern_13999) { return call_then(start_expression(x_p4_3), [=](Text expression_14013) { return call_then(start_expression(e_p5_1), [=](Text expression_14036) { return prism_rtl::finished(prism_rtl::cat("let ", pattern_13999, " = ", expression_14013, " else { ", expression_14036, " };")); }); }); });
    });
    })
        : prism_rtl::is<crate::lower::model::Do::DoAssign>(d_p0) ? ({
        auto&& p_p6 = prism_rtl::as<crate::lower::model::Do::DoAssign>(d_p0).a0;
        auto&& x_p7 = prism_rtl::as<crate::lower::model::Do::DoAssign>(d_p0).a1;
        ({
        auto p_p6_1 = p_p6;
        auto x_p7_2 = x_p7;
        call_then(start_expression(p_p6_1), [=, x_p7_2 = std::move(x_p7_2)](Text expression_14076) { return call_then(start_expression(x_p7_2), [=](Text expression_14093) { return prism_rtl::finished(prism_rtl::cat(expression_14076, " = ", expression_14093, ";")); }); });
    });
    })
        : prism_rtl::is<crate::lower::model::Do::DoWhile>(d_p0) ? ({
        auto&& c_p8 = prism_rtl::as<crate::lower::model::Do::DoWhile>(d_p0).a0;
        auto&& body_p9 = prism_rtl::as<crate::lower::model::Do::DoWhile>(d_p0).a1;
        ({
        auto body_p9_1 = body_p9;
        auto c_p8_2 = c_p8;
        call_then(start_expression(c_p8_2), [=, body_p9_1 = std::move(body_p9_1)](Text expression_14145) { return call_then(start_statements(body_p9_1), [=](Text statements_14162) { return prism_rtl::finished(crate::emit::rust::templates::items::if_stmt(prism_rtl::cat("while ", expression_14145), statements_14162)); }); });
    });
    })
        : prism_rtl::is<crate::lower::model::Do::DoWhileLet>(d_p0) ? ({
        auto&& p_pa = prism_rtl::as<crate::lower::model::Do::DoWhileLet>(d_p0).a0;
        auto&& x_pb = prism_rtl::as<crate::lower::model::Do::DoWhileLet>(d_p0).a1;
        auto&& body_pc = prism_rtl::as<crate::lower::model::Do::DoWhileLet>(d_p0).a2;
        ({
        auto body_pc_1 = body_pc;
        auto p_pa_2 = p_pa;
        auto x_pb_3 = x_pb;
        call_then(start_pattern(p_pa_2), [=, body_pc_1 = std::move(body_pc_1), x_pb_3 = std::move(x_pb_3)](Text pattern_14225) { return call_then(start_expression(x_pb_3), [=](Text expression_14239) { return call_then(start_statements(body_pc_1), [=](Text statements_14256) { return prism_rtl::finished(crate::emit::rust::templates::items::if_stmt(prism_rtl::cat("while let ", pattern_14225, " = ", expression_14239), statements_14256)); }); }); });
    });
    })
        : prism_rtl::is<crate::lower::model::Do::DoFor>(d_p0) ? ({
        auto&& p_pd = prism_rtl::as<crate::lower::model::Do::DoFor>(d_p0).a0;
        auto&& x_pe = prism_rtl::as<crate::lower::model::Do::DoFor>(d_p0).a1;
        auto&& body_pf = prism_rtl::as<crate::lower::model::Do::DoFor>(d_p0).a2;
        ({
        auto body_pf_1 = body_pf;
        auto p_pd_2 = p_pd;
        auto x_pe_3 = x_pe;
        call_then(start_pattern(p_pd_2), [=, body_pf_1 = std::move(body_pf_1), x_pe_3 = std::move(x_pe_3)](Text pattern_14308) { return call_then(start_expression(x_pe_3), [=](Text expression_14323) { return call_then(start_statements(body_pf_1), [=](Text statements_14340) { return prism_rtl::finished(crate::emit::rust::templates::items::if_stmt(prism_rtl::cat("for ", pattern_14308, " in ", expression_14323), statements_14340)); }); }); });
    });
    })
        : prism_rtl::is<crate::lower::model::Do::DoExpr>(d_p0) ? ({
        auto&& x_pg = prism_rtl::as<crate::lower::model::Do::DoExpr>(d_p0).a0;
        ({
        auto x_pg_1 = x_pg;
        call_then(start_expression(x_pg_1), [=](Text expression_14373) { return prism_rtl::finished(prism_rtl::cat(expression_14373, ";")); });
    });
    })
        : prism_rtl::is<crate::lower::model::Do::DoIf>(d_p0) ? ({
        auto&& c_ph = prism_rtl::as<crate::lower::model::Do::DoIf>(d_p0).a0;
        auto&& t_pi = prism_rtl::as<crate::lower::model::Do::DoIf>(d_p0).a1;
        auto&& e_pj = prism_rtl::as<crate::lower::model::Do::DoIf>(d_p0).a2;
        ({
        auto c_ph_1 = c_ph;
        auto e_pj_2 = e_pj;
        auto t_pi_3 = t_pi;
        call_then(start_expression(c_ph_1), [=, e_pj_2 = std::move(e_pj_2), t_pi_3 = std::move(t_pi_3)](Text expression_14421) { return call_then(start_statements(t_pi_3), [=](Text statements_14438) { return call_then(start_else_branch(e_pj_2), [=](Text else_branch_14453) { return prism_rtl::finished(prism_rtl::cat(crate::emit::rust::templates::items::if_stmt(prism_rtl::cat("if ", expression_14421), statements_14438), else_branch_14453)); }); }); });
    });
    })
        : prism_rtl::is<crate::lower::model::Do::DoIfLet>(d_p0) ? ({
        auto&& p_pk = prism_rtl::as<crate::lower::model::Do::DoIfLet>(d_p0).a0;
        auto&& x_pl = prism_rtl::as<crate::lower::model::Do::DoIfLet>(d_p0).a1;
        auto&& t_pm = prism_rtl::as<crate::lower::model::Do::DoIfLet>(d_p0).a2;
        auto&& e_pn = prism_rtl::as<crate::lower::model::Do::DoIfLet>(d_p0).a3;
        ({
        auto e_pn_1 = e_pn;
        auto p_pk_2 = p_pk;
        auto t_pm_3 = t_pm;
        auto x_pl_4 = x_pl;
        call_then(start_pattern(p_pk_2), [=, e_pn_1 = std::move(e_pn_1), t_pm_3 = std::move(t_pm_3), x_pl_4 = std::move(x_pl_4)](Text pattern_14510) { return call_then(start_expression(x_pl_4), [=](Text expression_14524) { return call_then(start_statements(t_pm_3), [=](Text statements_14541) { return call_then(start_else_branch(e_pn_1), [=](Text else_branch_14556) { return prism_rtl::finished(prism_rtl::cat(crate::emit::rust::templates::items::if_stmt(prism_rtl::cat("if let ", pattern_14510, " = ", expression_14524), statements_14541), else_branch_14556)); }); }); }); });
    });
    })
        : prism_rtl::is<crate::lower::model::Do::DoMatch>(d_p0) ? ({
        auto&& x_po = prism_rtl::as<crate::lower::model::Do::DoMatch>(d_p0).a0;
        auto&& cases_pp = prism_rtl::as<crate::lower::model::Do::DoMatch>(d_p0).a1;
        ({
        auto cases_pp_1 = cases_pp;
        auto x_po_2 = x_po;
        call_then(start_expression(x_po_2), [=, cases_pp_1 = std::move(cases_pp_1)](Text expression_14605) {
        return call_value(each_job(cases_pp_1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<crate::lower::model::Pa, Array<crate::lower::model::Do>>)>>(prism_rtl::rc([=](std::tuple<crate::lower::model::Pa, Array<crate::lower::model::Do>> p0) {
            return entered(once_job([=]() {
                return ({
                    auto [p_pq, body_pr] = p0;
                    call_then(start_pattern(p_pq), [=](Text pattern_14664) { return call_then(start_statements(body_pr), [=](Text statements_14677) { return prism_rtl::finished(crate::emit::rust::templates::items::arm_block(pattern_14664, statements_14677)); }); });
                });
            }));
        }))), [=](Array<Text> each_14627) { return prism_rtl::finished(crate::emit::rust::templates::items::match_block(expression_14605, crate::syntax::lexer::chars::join(each_14627, Text::lit("\n")))); });
    });
    });
    })
        : prism_rtl::is<crate::lower::model::Do::DoReturn>(d_p0) ? ({
        auto&& x_ps = prism_rtl::as<crate::lower::model::Do::DoReturn>(d_p0).a0;
        ({
        auto x_ps_1 = x_ps;
        call_then(start_expression(x_ps_1), [=](Text expression_14727) { return prism_rtl::finished(prism_rtl::cat("return ", expression_14727, ";")); });
    });
    })
        : prism_rtl::is<crate::lower::model::Do::DoBlock>(d_p0) ? ({
        auto&& body_pt = prism_rtl::as<crate::lower::model::Do::DoBlock>(d_p0).a0;
        ({
        auto body_pt_1 = body_pt;
        call_then(start_statements(body_pt_1), [=](Text statements_14768) { return prism_rtl::finished(crate::emit::rust::templates::items::scope(statements_14768)); });
    });
    })
        : prism_rtl::is<crate::lower::model::Do::DoScope>(d_p0) ? ({
        auto&& body_pu = prism_rtl::as<crate::lower::model::Do::DoScope>(d_p0).a0;
        ({
        auto body_pu_1 = body_pu;
        call_then(start_inline_statements(body_pu_1), [=](Text inline_statements_14808) { return prism_rtl::finished(prism_rtl::cat("{ ", inline_statements_14808, " };")); });
    });
    })
        : prism_rtl::is<crate::lower::model::Do::DoLine>(d_p0) ? ({
        auto&& body_pv = prism_rtl::as<crate::lower::model::Do::DoLine>(d_p0).a0;
        ({
        auto body_pv_1 = body_pv;
        call_then(start_inline_statements(body_pv_1), [=](Text inline_statements_14855) { return prism_rtl::finished(prism_rtl::cat(inline_statements_14855, ";")); });
    });
    })
        : prism_rtl::is<crate::lower::model::Do::DoNote>(d_p0) ? ({
        auto&& t_p10 = prism_rtl::as<crate::lower::model::Do::DoNote>(d_p0).a0;
        prism_rtl::finished(prism_rtl::cat("// ", t_p10));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start Statement, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_statement(crate::lower::model::Do d_p0) {
    return prism_rtl::make_rc<Statement>(d_p0);
}


/// InlineStatements: unbounded fn [Do] -> Text
Text inline_statements(const Array<crate::lower::model::Do>& dos_p0) {
    return crate::syntax::lexer::chars::join(run_to_end(each_job(dos_p0, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Do)>>(prism_rtl::rc([=](crate::lower::model::Do p0) {
        return entered(once_job([=]() {
            return ({
                auto d_p1 = p0;
                (prism_rtl::more(prism_rtl::rc(InlineStatement(d_p1))));
            });
        }));
    })))), Text::lit(" "));
}


prism_rtl::Turn<Text> InlineStatements::cycle() const {
    const auto& dos_p0 = this->dos_p0;
    auto dos_p0_1 = dos_p0;
    return call_value(each_job(dos_p0_1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Do)>>(prism_rtl::rc([=](crate::lower::model::Do p0) {
        return entered(once_job([=]() {
            return ({
                auto d_p1 = p0;
                (prism_rtl::more(prism_rtl::rc(InlineStatement(d_p1))));
            });
        }));
    }))), [=](Array<Text> each_15028) { return prism_rtl::finished(crate::syntax::lexer::chars::join(each_15028, Text::lit(" "))); });
}


/// `Start InlineStatements, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_inline_statements(Array<crate::lower::model::Do> dos_p0) {
    return prism_rtl::make_rc<InlineStatements>(dos_p0);
}


/// InlineStatement: unbounded fn Do -> Text
Text inline_statement(const crate::lower::model::Do& do_0) {
    if (prism_rtl::is<crate::lower::model::Do::DoIf>(do_0)) {
        auto&& c_p0 = prism_rtl::as<crate::lower::model::Do::DoIf>(do_0).a0;
        auto&& t_p1 = prism_rtl::as<crate::lower::model::Do::DoIf>(do_0).a1;
        auto&& c0_0_2 = prism_rtl::as<crate::lower::model::Do::DoIf>(do_0).a2;
        if (c0_0_2.size() == 0u) {
            return prism_rtl::cat("if ", expression(c_p0), " { ", inline_statements(t_p1), " }");
        }
    }
    {
        auto&& d_p2 = do_0;
        return statement(d_p2);
    }
}


prism_rtl::Turn<Text> InlineStatement::cycle() const {
    const auto& do_0 = this->do_0;
    return ({
        prism_rtl::is<crate::lower::model::Do::DoIf>(do_0) && ({
        auto&& c_p0 = prism_rtl::as<crate::lower::model::Do::DoIf>(do_0).a0;
        auto&& t_p1 = prism_rtl::as<crate::lower::model::Do::DoIf>(do_0).a1;
        auto&& j0_0_2 = prism_rtl::as<crate::lower::model::Do::DoIf>(do_0).a2;
        (j0_0_2.size() == 0u);
    }) ? ({
        auto&& c_p0 = prism_rtl::as<crate::lower::model::Do::DoIf>(do_0).a0;
        auto&& t_p1 = prism_rtl::as<crate::lower::model::Do::DoIf>(do_0).a1;
        auto&& j0_0_2 = prism_rtl::as<crate::lower::model::Do::DoIf>(do_0).a2;
        ({
        auto c_p0_1 = c_p0;
        auto t_p1_2 = t_p1;
        call_then(start_expression(c_p0_1), [=, t_p1_2 = std::move(t_p1_2)](Text expression_15153) { return call_then(start_inline_statements(t_p1_2), [=](Text inline_statements_15171) { return prism_rtl::finished(prism_rtl::cat("if ", expression_15153, " { ", inline_statements_15171, " }")); }); });
    });
    })
        : ({
        auto&& d_p2 = do_0;
        prism_rtl::more(prism_rtl::rc(Statement(d_p2)));
    });
    });
}


/// `Start InlineStatement, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_inline_statement(crate::lower::model::Do do_0) {
    return prism_rtl::make_rc<InlineStatement>(do_0);
}


/// ElseBranch: unbounded fn [Do] -> Text
Text else_branch(const Array<crate::lower::model::Do>& xs0) {
    {
        auto&& c0_0 = xs0;
        if (c0_0.size() == 0u) {
            return Text::lit("");
        }
    }
    {
        auto&& c1_0 = xs0;
        if (c1_0.size() == 1u) {
            {
                auto&& _c1 = index(c1_0, Nat(0u));
                if (prism_rtl::is_some(_c1) && prism_rtl::is<crate::lower::model::Do::DoIf>(prism_rtl::some_of(_c1))) {
                    auto&& c_p0 = prism_rtl::as<crate::lower::model::Do::DoIf>(prism_rtl::some_of(_c1)).a0;
                    auto&& t_p1 = prism_rtl::as<crate::lower::model::Do::DoIf>(prism_rtl::some_of(_c1)).a1;
                    auto&& e_p2 = prism_rtl::as<crate::lower::model::Do::DoIf>(prism_rtl::some_of(_c1)).a2;
                    return prism_rtl::cat(" else ", statement(crate::lower::model::Do(crate::lower::model::Do::DoIf{c_p0, t_p1, e_p2})));
                }
            }
        }
    }
    {
        auto&& c2_0 = xs0;
        if (c2_0.size() == 1u) {
            {
                auto&& _c1 = index(c2_0, Nat(0u));
                if (prism_rtl::is_some(_c1) && prism_rtl::is<crate::lower::model::Do::DoIfLet>(prism_rtl::some_of(_c1))) {
                    auto&& p_p3 = prism_rtl::as<crate::lower::model::Do::DoIfLet>(prism_rtl::some_of(_c1)).a0;
                    auto&& x_p4 = prism_rtl::as<crate::lower::model::Do::DoIfLet>(prism_rtl::some_of(_c1)).a1;
                    auto&& t_p5 = prism_rtl::as<crate::lower::model::Do::DoIfLet>(prism_rtl::some_of(_c1)).a2;
                    auto&& e_p6 = prism_rtl::as<crate::lower::model::Do::DoIfLet>(prism_rtl::some_of(_c1)).a3;
                    return prism_rtl::cat(" else ", statement(crate::lower::model::Do(crate::lower::model::Do::DoIfLet{p_p3, x_p4, t_p5, e_p6})));
                }
            }
        }
    }
    {
        auto&& body_p7 = xs0;
        return crate::emit::rust::templates::items::else_(statements(body_p7));
    }
}


prism_rtl::Turn<Text> ElseBranch::cycle() const {
    const auto& xs0 = this->xs0;
    return ({
        ({
        auto&& j0_0 = xs0;
        (j0_0.size() == 0u);
    }) ? ({
        auto&& j0_0 = xs0;
        prism_rtl::finished(Text::lit(""));
    })
        : ({
        auto&& j1_0 = xs0;
        (j1_0.size() == 1u) && ({
        auto&& _c1 = index(j1_0, Nat(0u));
        prism_rtl::is_some(_c1) && prism_rtl::is<crate::lower::model::Do::DoIf>(prism_rtl::some_of(_c1));
    });
    }) ? ({
        auto&& j1_0 = xs0;
        auto&& _c1 = index(j1_0, Nat(0u));
        auto&& c_p0 = prism_rtl::as<crate::lower::model::Do::DoIf>(prism_rtl::some_of(_c1)).a0;
        auto&& t_p1 = prism_rtl::as<crate::lower::model::Do::DoIf>(prism_rtl::some_of(_c1)).a1;
        auto&& e_p2 = prism_rtl::as<crate::lower::model::Do::DoIf>(prism_rtl::some_of(_c1)).a2;
        call_then(start_statement(crate::lower::model::Do(crate::lower::model::Do::DoIf{c_p0, t_p1, e_p2})), [=](Text statement_15383) { return prism_rtl::finished(prism_rtl::cat(" else ", statement_15383)); });
    })
        : ({
        auto&& j2_0 = xs0;
        (j2_0.size() == 1u) && ({
        auto&& _c1 = index(j2_0, Nat(0u));
        prism_rtl::is_some(_c1) && prism_rtl::is<crate::lower::model::Do::DoIfLet>(prism_rtl::some_of(_c1));
    });
    }) ? ({
        auto&& j2_0 = xs0;
        auto&& _c1 = index(j2_0, Nat(0u));
        auto&& p_p3 = prism_rtl::as<crate::lower::model::Do::DoIfLet>(prism_rtl::some_of(_c1)).a0;
        auto&& x_p4 = prism_rtl::as<crate::lower::model::Do::DoIfLet>(prism_rtl::some_of(_c1)).a1;
        auto&& t_p5 = prism_rtl::as<crate::lower::model::Do::DoIfLet>(prism_rtl::some_of(_c1)).a2;
        auto&& e_p6 = prism_rtl::as<crate::lower::model::Do::DoIfLet>(prism_rtl::some_of(_c1)).a3;
        call_then(start_statement(crate::lower::model::Do(crate::lower::model::Do::DoIfLet{p_p3, x_p4, t_p5, e_p6})), [=](Text statement_15459) { return prism_rtl::finished(prism_rtl::cat(" else ", statement_15459)); });
    })
        : ({
        auto&& body_p7 = xs0;
        ({
        auto body_p7_1 = body_p7;
        call_then(start_statements(body_p7_1), [=](Text statements_15519) { return prism_rtl::finished(crate::emit::rust::templates::items::else_(statements_15519)); });
    });
    });
    });
}


/// `Start ElseBranch, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_else_branch(Array<crate::lower::model::Do> xs0) {
    return prism_rtl::make_rc<ElseBranch>(xs0);
}

}  // namespace crate::emit::rust
