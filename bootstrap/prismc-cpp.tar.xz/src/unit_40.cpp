// The module `Lower.Functions`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <lower/functions/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Lower.Functions`, from `target/bootstrap/cpp-src/prismc/lower/functions.prism`.
namespace crate::lower::functions {

/// BoundOf: fn Lx, Text -> [Text]
Array<Text> bound_of(const crate::lower::Lx& lx, const Text& text1) {
    {
        auto&& c0_1 = text1;
        if (c0_1 == Text::lit("Prelude.Eq")) {
            return Array(std::vector{Text::lit("Eq")});
        }
    }
    {
        auto&& c1_1 = text1;
        if (c1_1 == Text::lit("Prelude.Ord")) {
            return Array(std::vector{Text::lit("Ord")});
        }
    }
    {
        auto&& c2_1 = text1;
        if (c2_1 == Text::lit("Prelude.Show")) {
            return Array(std::vector{Text::lit("Show")});
        }
    }
    {
        auto&& c3_1 = text1;
        if (c3_1 == Text::lit("Prelude.Num")) {
            return Array(std::vector{Text::lit("Num")});
        }
    }
    {
        auto&& c4_1 = text1;
        if (c4_1 == Text::lit("Prelude.Pod")) {
            return Array(std::vector{Text::lit("ToPod"), Text::lit("FromPod")});
        }
    }
    {
        auto&& cls = text1;
        auto&& _m = crate::prelude::get(prism_rtl::deref(lx.g).traits, cls);
        if (prism_rtl::is_some(_m)) {
            auto&& tr = prism_rtl::some_of(_m);
            return Array(std::vector{crate::lower::path_in(lx, prism_rtl::deref(tr).home, crate::lower::camel(crate::check::types::bare_name(cls)))});
        }
        if (prism_rtl::is_none(_m)) {
            return Array<Text>{};
        }
        prism_rtl::unreachable("no arm matched");
    }
}


/// SchemeGenerics: fn Lx, Scheme -> [((Text, [Text]))]
Array<std::tuple<Text, Array<Text>>> scheme_generics(const crate::lower::Lx& lx, const crate::check::types::Scheme& sc) {
    return each(sc.qs, [&](const Text& q) {
        return ({
            auto bs = fold(sc.bounds, Array(std::vector{Text::lit("Clone")}), [&](const Array<Text>& acc, const std::tuple<Text, Text>& _p1) {
                auto&& v_ = std::get<0>(_p1);
                auto&& cls = std::get<1>(_p1);
                return v_ == q ? crate::check::types::union_texts(acc, bound_of(lx, cls)) : acc;
            });
            auto keyed = keys_by(sc.ty, q)
                ? crate::check::types::union_texts(bs, Array(std::vector{Text::lit("Ord")}))
                : bs;
            std::tuple{crate::lower::camel(q), keyed};
        });
    });
}


/// KeysBy: fn Ty, Text -> Bool
bool keys_by(const crate::check::types::Ty& t, const Text& q) {
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(t)) {
        auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a0;
        auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a1;
        return ((prism_rtl::deref(prism_rtl::deref(k)) == crate::check::types::Ty(crate::check::types::Ty::TyQ{q})) || keys_by(prism_rtl::deref(prism_rtl::deref(k)), q)) || keys_by(prism_rtl::deref(prism_rtl::deref(v_)), q);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t)) {
        auto&& ts = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        return fold(ts, false, [&](const bool& found, const crate::check::types::Ty& x) { return prism_rtl::deref(found) || keys_by(x, q); });
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(t)) {
        auto&& ps = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a1;
        auto&& r = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a2;
        return fold(ps, false, [&](const bool& found, const crate::check::types::Ty& x) { return prism_rtl::deref(found) || keys_by(x, q); }) || keys_by(prism_rtl::deref(prism_rtl::deref(r)), q);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t)) {
        auto&& ts = prism_rtl::as<crate::check::types::Ty::TyTuple>(t).a0;
        return fold(ts, false, [&](const bool& found, const crate::check::types::Ty& x) { return prism_rtl::deref(found) || keys_by(x, q); });
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(t)) {
        auto&& x = prism_rtl::as<crate::check::types::Ty::TyArray>(t).a0;
        return keys_by(prism_rtl::deref(prism_rtl::deref(x)), q);
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t)) {
        auto&& x = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        return keys_by(prism_rtl::deref(prism_rtl::deref(x)), q);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(t)) {
        auto&& x = prism_rtl::as<crate::check::types::Ty::TyAt>(t).a0;
        return keys_by(prism_rtl::deref(prism_rtl::deref(x)), q);
    }
    {
        return false;
    }
}


/// ParamNames: fn Lx, [FnClause], [OutTy] -> [((Text, Bool))]
Array<std::tuple<Text, bool>> param_names(const crate::lower::Lx& lx, const Array<crate::syntax::decls::FnClause>& clauses, const Array<crate::lower::model::OutTy>& pts) {
    return each(crate::check::errors::range0(len(pts)), [&](const Nat& i) {
        return ({
            auto names = each(clauses, [&](const crate::syntax::decls::FnClause& c) { return plain_binder(lx, or_(index(prism_rtl::deref(c).params, i), crate::lower::patterns::dummy_pat())); });
            auto first_ = or_(index(names, Nat(0u)), Text::lit(""));
            auto same = (first_ != Text::lit("")) && fold(names, true, [&](const bool& ok_, const Text& n) { return prism_rtl::deref(ok_) && (n == first_); });
            std::move(same)
            ? std::tuple{crate::lower::local_name(lx, first_), false}
            : std::tuple{param_word(or_(index(pts, i), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})), i), true};
        });
    });
}


/// PlainBinder: fn Lx, Pattern -> Text
Text plain_binder(const crate::lower::Lx& lx, const crate::syntax::Pattern_& p_) {
    auto&& _m = prism_rtl::deref(p_.kind);
    if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        auto [qk_opt, why] = crate::check::env::names::resolve_value(lx.g, lx.home, n);
        auto is_ctor = ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            if (prism_rtl::is_some(qk_opt)) {
                auto&& qk = prism_rtl::some_of(qk_opt);
                _v.set(crate::check::env::has_key(prism_rtl::deref(lx.g).ctors, qk) && (crate::check::env::is_upper_text(crate::lower::base(crate::check::env::sname_key(n))) || crate::lower::patterns::is_unit_ctor(lx, qk)));
                goto _done;
            }
            if (prism_rtl::is_none(qk_opt)) {
                _v.set(false);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        return std::move(is_ctor) ? Text::lit("") : crate::check::env::sname_key(n);
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PGroup>(_m)) {
        auto&& q = prism_rtl::as<crate::syntax::PatternKind::PGroup>(_m).a0;
        return plain_binder(lx, prism_rtl::deref(prism_rtl::deref(q)));
    }
    {
        return Text::lit("");
    }
}


/// ParamWord: fn OutTy, Nat -> Text
Text param_word(const crate::lower::model::OutTy& t, const Nat& i) {
    auto base = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t)) {
            auto&& n = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t).a0;
            _v.set(crate::lower::snake(or_(crate::syntax::lexer::chars::last(split_on(n, Text::lit("::"))), Text::lit("arg"))));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::OutTy::OutText>(t)) {
            _v.set(Text::lit("text"));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::OutTy::OutNat>(t)) {
            _v.set(Text::lit("n"));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::OutTy::OutInt>(t)) {
            _v.set(Text::lit("i"));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::OutTy::OutArray>(t)) {
            _v.set(Text::lit("xs"));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::OutTy::OutMap>(t)) {
            _v.set(Text::lit("map"));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::OutTy::OutOpt>(t)) {
            _v.set(Text::lit("opt"));
            goto _done;
        }
        {
            _v.set(Text::lit("arg"));
            goto _done;
        }
    _done:
        _v.take();
    });
    return prism_rtl::cat(base, i);
}


/// ClausesBody: unbounded fn Lx, Env, [FnClause], [((Text, Bool))], [Ty], (fn Lx, Env, FnBody -> Ex), Text, OutTy -> Ex
crate::lower::model::Ex clauses_body(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const Array<crate::syntax::decls::FnClause>& clauses, const Array<std::tuple<Text, bool>>& names, const Array<crate::check::types::Ty>& ptys, const prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::Lx, crate::lower::types::Env, crate::syntax::decls::FnBody>)>& body_fn, const Text& label, const crate::lower::model::OutTy& t) {
    auto env1 = run_to_end(fold_job(crate::check::errors::range0(len(names)), env, ({
        auto names_1 = names;
        auto lx_2 = lx;
        auto clauses_3 = clauses;
        auto ptys_4 = ptys;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::types::Env>(std::tuple<crate::lower::types::Env, Nat>)>>(prism_rtl::rc([=, names_1 = std::move(names_1), lx_2 = std::move(lx_2), clauses_3 = std::move(clauses_3), ptys_4 = std::move(ptys_4)](std::tuple<crate::lower::types::Env, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto names_1_5 = names_1;
            auto lx_2_5 = lx_2;
            auto clauses_3_5 = clauses_3;
            auto ptys_4_5 = ptys_4;
            entered(once_job([=, names_1_5 = std::move(names_1_5), lx_2_5 = std::move(lx_2_5), clauses_3_5 = std::move(clauses_3_5), ptys_4_5 = std::move(ptys_4_5)]() {
            return ({
                auto en = p0;
                auto i = p1;
                ({
                auto [rs, matched] = or_(index(names_1_5, i), std::tuple{Text::lit(""), true});
                matched
                ? prism_rtl::finished(en)
                : call_then(crate::lower::types::start_out_ty_of(lx_2_5, crate::lower::types::peel(or_(index(ptys_4_5, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{})))), [=](crate::lower::model::OutTy out_ty_of_4892) { return prism_rtl::finished(crate::lower::types::bind(en, plain_binder(lx_2_5, or_(index(prism_rtl::deref(or_(index(clauses_3_5, Nat(0u)), dummy_clause())).params, i), crate::lower::patterns::dummy_pat())), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{rs}), crate::lower::types::Holding(crate::lower::types::Holding::ByRef{}), out_ty_of_4892}))); });
            });
            });
        }));
        });
    })));
    })));
    auto scrut_ix = filter(crate::check::errors::range0(len(names)), [&](const Nat& i) {
        return ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            auto&& _m = index(names, i);
            if (prism_rtl::is_some(_m) && std::get<1>(prism_rtl::some_of(_m))) {
                _v.set(true);
                goto _done;
            }
            {
                _v.set(false);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    return len(scrut_ix) == Nat(0u)
        ? ({
        auto c = or_(index(clauses, Nat(0u)), dummy_clause());
        run_to_end(body_fn(std::tuple{lx, env1, prism_rtl::deref(c).body}));
    })
        : ({
        auto scrut = ({
            __label__ _done;
            prism_rtl::Slot<crate::lower::model::Ex> _v;
            {
                auto&& m5189_0 = scrut_ix;
                if (m5189_0.size() == 1u) {
                    {
                        auto&& _c1 = index(m5189_0, Nat(0u));
                        if (prism_rtl::is_some(_c1)) {
                            auto&& i = prism_rtl::some_of(_c1);
                            _v.set(crate::lower::model::Ex(crate::lower::model::Ex::XVar{or_(index(each(names, [&](const std::tuple<Text, bool>& _p0) {
                                auto&& n = std::get<0>(_p0);
                                return n;
                            }), i), Text::lit("arg"))}));
                            goto _done;
                        }
                    }
                }
            }
            {
                _v.set(crate::lower::model::Ex(crate::lower::model::Ex::XTuple{each(scrut_ix, [&](const Nat& i) {
                    return crate::lower::model::Ex(crate::lower::model::Ex::XVar{or_(index(each(names, [&](const std::tuple<Text, bool>& _p0) {
                        auto&& n = std::get<0>(_p0);
                        return n;
                    }), i), Text::lit("arg"))});
                })}));
                goto _done;
            }
        _done:
            _v.take();
        });
        auto arms = run_to_end(each_job(crate::check::errors::range0(len(clauses)), ({
            auto clauses_1 = clauses;
            auto scrut_ix_2 = scrut_ix;
            auto lx_3 = lx;
            auto ptys_4 = ptys;
            auto label_5 = label;
            auto body_fn_6 = body_fn;
            auto env1_7 = env1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::XArm>(Nat)>>(prism_rtl::rc([=, clauses_1 = std::move(clauses_1), scrut_ix_2 = std::move(scrut_ix_2), lx_3 = std::move(lx_3), ptys_4 = std::move(ptys_4), label_5 = std::move(label_5), body_fn_6 = std::move(body_fn_6), env1_7 = std::move(env1_7)](Nat p0) {
            return ({
                auto clauses_1_8 = clauses_1;
                auto scrut_ix_2_8 = scrut_ix_2;
                auto lx_3_8 = lx_3;
                auto ptys_4_8 = ptys_4;
                auto label_5_8 = label_5;
                auto body_fn_6_8 = body_fn_6;
                auto env1_7_8 = env1_7;
                entered(once_job([=, clauses_1_8 = std::move(clauses_1_8), scrut_ix_2_8 = std::move(scrut_ix_2_8), lx_3_8 = std::move(lx_3_8), ptys_4_8 = std::move(ptys_4_8), label_5_8 = std::move(label_5_8), body_fn_6_8 = std::move(body_fn_6_8), env1_7_8 = std::move(env1_7_8)]() {
                return ({
                    auto ci = p0;
                    ({
                    auto c = or_(index(clauses_1_8, ci), dummy_clause());
                    call_value(each_job(scrut_ix_2_8, ({
                    auto lx_3_8_8 = lx_3_8;
                    auto c_8 = c;
                    auto ptys_4_8_9 = ptys_4_8;
                    auto label_5_8_9 = label_5_8;
                    auto ci_9 = ci;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::patterns::PatOut>(Nat)>>(prism_rtl::rc([=, lx_3_8_8 = std::move(lx_3_8_8), c_8 = std::move(c_8), ptys_4_8_9 = std::move(ptys_4_8_9), label_5_8_9 = std::move(label_5_8_9), ci_9 = std::move(ci_9)](Nat p0) {
                    return ({
                        auto lx_3_8_8_10 = lx_3_8_8;
                        auto c_8_10 = c_8;
                        auto ptys_4_8_9_10 = ptys_4_8_9;
                        auto label_5_8_9_10 = label_5_8_9;
                        auto ci_9_10 = ci_9;
                        entered(once_job([=, lx_3_8_8_10 = std::move(lx_3_8_8_10), c_8_10 = std::move(c_8_10), ptys_4_8_9_10 = std::move(ptys_4_8_9_10), label_5_8_9_10 = std::move(label_5_8_9_10), ci_9_10 = std::move(ci_9_10)]() {
                        return ({
                            auto i = p0;
                            (prism_rtl::more(prism_rtl::rc(crate::lower::patterns::RustPat(lx_3_8_8_10, or_(index(prism_rtl::deref(c_8_10).params, i), crate::lower::patterns::dummy_pat()), or_(index(ptys_4_8_9_10, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), crate::lower::types::Holding(crate::lower::types::Holding::ByRef{}), prism_rtl::cat(label_5_8_9_10, ci_9_10, "_", i)))));
                        });
                    }));
                    });
                })));
                })), [=](Array<crate::lower::patterns::PatOut> each_5504) {
                    return ({
                        auto pos = each_5504;
                        auto pa = ({
                            __label__ _done;
                            prism_rtl::Slot<crate::lower::model::Pa> _v;
                            {
                                auto&& m5630_0 = pos;
                                if (m5630_0.size() == 1u) {
                                    {
                                        auto&& _c1 = index(m5630_0, Nat(0u));
                                        if (prism_rtl::is_some(_c1)) {
                                            auto&& o = prism_rtl::some_of(_c1);
                                            _v.set(prism_rtl::deref(o).pa);
                                            goto _done;
                                        }
                                    }
                                }
                            }
                            {
                                _v.set(crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{each(pos, [&](const crate::lower::patterns::PatOut& o) { return prism_rtl::deref(o).pa; })}));
                                goto _done;
                            }
                        _done:
                            _v.take();
                        });
                        auto conds = fold(pos, Array<crate::lower::model::Cc>{}, [&](const Array<crate::lower::model::Cc>& acc, const crate::lower::patterns::PatOut& o) { return append(acc, prism_rtl::deref(o).conds); });
                        auto binds = fold(pos, Array<std::tuple<Text, crate::lower::types::Bn>>{}, [&](const Array<std::tuple<Text, crate::lower::types::Bn>>& acc, const crate::lower::patterns::PatOut& o) { return append(acc, prism_rtl::deref(o).binds); });
                        call_value(body_fn_6_8(std::tuple{lx_3_8, crate::lower::expr::bind_all(env1_7_8, binds), prism_rtl::deref(c).body}), [=, pa = std::move(pa), conds = std::move(conds)](crate::lower::model::Ex body_5910) { return prism_rtl::finished(crate::lower::model::XArm{.pat = pa, .conds = conds, .body = body_5910}); });
                    });
                });
                });
                });
            }));
            });
        })));
        })));
        (crate::lower::types::own(crate::lower::expr::arms_value(scrut, arms, prism_rtl::cat("\'", label), t)));
    });
}


prism_rtl::Turn<crate::lower::model::Ex> ClausesBody::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& clauses = this->clauses;
    const auto& names = this->names;
    const auto& ptys = this->ptys;
    const auto& body_fn = this->body_fn;
    const auto& label = this->label;
    const auto& t = this->t;
    auto body_fn_1 = body_fn;
    auto clauses_2 = clauses;
    auto env_3 = env;
    auto label_4 = label;
    auto lx_5 = lx;
    auto names_6 = names;
    auto ptys_7 = ptys;
    auto t_8 = t;
    return call_value(fold_job(crate::check::errors::range0(len(names_6)), env_3, ({
        auto names_6_9 = names_6;
        auto lx_5_9 = lx_5;
        auto clauses_2_9 = clauses_2;
        auto ptys_7_9 = ptys_7;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::types::Env>(std::tuple<crate::lower::types::Env, Nat>)>>(prism_rtl::rc([=, names_6_9 = std::move(names_6_9), lx_5_9 = std::move(lx_5_9), clauses_2_9 = std::move(clauses_2_9), ptys_7_9 = std::move(ptys_7_9)](std::tuple<crate::lower::types::Env, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto names_6_9_9 = names_6_9;
            auto lx_5_9_9 = lx_5_9;
            auto clauses_2_9_9 = clauses_2_9;
            auto ptys_7_9_9 = ptys_7_9;
            entered(once_job([=, names_6_9_9 = std::move(names_6_9_9), lx_5_9_9 = std::move(lx_5_9_9), clauses_2_9_9 = std::move(clauses_2_9_9), ptys_7_9_9 = std::move(ptys_7_9_9)]() {
            return ({
                auto en = p0;
                auto i = p1;
                ({
                auto [rs, matched] = or_(index(names_6_9_9, i), std::tuple{Text::lit(""), true});
                matched
                ? prism_rtl::finished(en)
                : call_then(crate::lower::types::start_out_ty_of(lx_5_9_9, crate::lower::types::peel(or_(index(ptys_7_9_9, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{})))), [=](crate::lower::model::OutTy out_ty_of_4892) { return prism_rtl::finished(crate::lower::types::bind(en, plain_binder(lx_5_9_9, or_(index(prism_rtl::deref(or_(index(clauses_2_9_9, Nat(0u)), dummy_clause())).params, i), crate::lower::patterns::dummy_pat())), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{rs}), crate::lower::types::Holding(crate::lower::types::Holding::ByRef{}), out_ty_of_4892}))); });
            });
            });
        }));
        });
    })));
    })), [=](crate::lower::types::Env fold_4648) {
        return ({
            auto env1 = fold_4648;
            auto scrut_ix = filter(crate::check::errors::range0(len(names_6)), [&](const Nat& i) {
                return ({
                    __label__ _done;
                    prism_rtl::Slot<bool> _v;
                    auto&& _m = index(names_6, i);
                    if (prism_rtl::is_some(_m) && std::get<1>(prism_rtl::some_of(_m))) {
                        _v.set(true);
                        goto _done;
                    }
                    {
                        _v.set(false);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
            });
            len(scrut_ix) == Nat(0u)
            ? ({
            auto c = or_(index(clauses_2, Nat(0u)), dummy_clause());
            body_fn_1(std::tuple{lx_5, env1, prism_rtl::deref(c).body})->cycle();
        })
            : ({
            auto scrut = ({
                __label__ _done;
                prism_rtl::Slot<crate::lower::model::Ex> _v;
                {
                    auto&& m5189_0 = scrut_ix;
                    if (m5189_0.size() == 1u) {
                        {
                            auto&& _c1 = index(m5189_0, Nat(0u));
                            if (prism_rtl::is_some(_c1)) {
                                auto&& i = prism_rtl::some_of(_c1);
                                _v.set(crate::lower::model::Ex(crate::lower::model::Ex::XVar{or_(index(each(names_6, [&](const std::tuple<Text, bool>& _p0) {
                                    auto&& n = std::get<0>(_p0);
                                    return n;
                                }), i), Text::lit("arg"))}));
                                goto _done;
                            }
                        }
                    }
                }
                {
                    _v.set(crate::lower::model::Ex(crate::lower::model::Ex::XTuple{each(scrut_ix, [&](const Nat& i) {
                        return crate::lower::model::Ex(crate::lower::model::Ex::XVar{or_(index(each(names_6, [&](const std::tuple<Text, bool>& _p0) {
                            auto&& n = std::get<0>(_p0);
                            return n;
                        }), i), Text::lit("arg"))});
                    })}));
                    goto _done;
                }
            _done:
                _v.take();
            });
            call_value(each_job(crate::check::errors::range0(len(clauses_2)), ({
            auto clauses_2_9 = clauses_2;
            auto scrut_ix_9 = scrut_ix;
            auto lx_5_10 = lx_5;
            auto ptys_7_10 = ptys_7;
            auto label_4_10 = label_4;
            auto body_fn_1_10 = body_fn_1;
            auto env1_10 = env1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::XArm>(Nat)>>(prism_rtl::rc([=, clauses_2_9 = std::move(clauses_2_9), scrut_ix_9 = std::move(scrut_ix_9), lx_5_10 = std::move(lx_5_10), ptys_7_10 = std::move(ptys_7_10), label_4_10 = std::move(label_4_10), body_fn_1_10 = std::move(body_fn_1_10), env1_10 = std::move(env1_10)](Nat p0) {
            return ({
                auto clauses_2_9_11 = clauses_2_9;
                auto scrut_ix_9_11 = scrut_ix_9;
                auto lx_5_10_11 = lx_5_10;
                auto ptys_7_10_11 = ptys_7_10;
                auto label_4_10_11 = label_4_10;
                auto body_fn_1_10_11 = body_fn_1_10;
                auto env1_10_11 = env1_10;
                entered(once_job([=, clauses_2_9_11 = std::move(clauses_2_9_11), scrut_ix_9_11 = std::move(scrut_ix_9_11), lx_5_10_11 = std::move(lx_5_10_11), ptys_7_10_11 = std::move(ptys_7_10_11), label_4_10_11 = std::move(label_4_10_11), body_fn_1_10_11 = std::move(body_fn_1_10_11), env1_10_11 = std::move(env1_10_11)]() {
                return ({
                    auto ci = p0;
                    ({
                    auto c = or_(index(clauses_2_9_11, ci), dummy_clause());
                    call_value(each_job(scrut_ix_9_11, ({
                    auto lx_5_10_11_11 = lx_5_10_11;
                    auto c_11 = c;
                    auto ptys_7_10_11_12 = ptys_7_10_11;
                    auto label_4_10_11_12 = label_4_10_11;
                    auto ci_12 = ci;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::patterns::PatOut>(Nat)>>(prism_rtl::rc([=, lx_5_10_11_11 = std::move(lx_5_10_11_11), c_11 = std::move(c_11), ptys_7_10_11_12 = std::move(ptys_7_10_11_12), label_4_10_11_12 = std::move(label_4_10_11_12), ci_12 = std::move(ci_12)](Nat p0) {
                    return ({
                        auto lx_5_10_11_11_13 = lx_5_10_11_11;
                        auto c_11_13 = c_11;
                        auto ptys_7_10_11_12_13 = ptys_7_10_11_12;
                        auto label_4_10_11_12_13 = label_4_10_11_12;
                        auto ci_12_13 = ci_12;
                        entered(once_job([=, lx_5_10_11_11_13 = std::move(lx_5_10_11_11_13), c_11_13 = std::move(c_11_13), ptys_7_10_11_12_13 = std::move(ptys_7_10_11_12_13), label_4_10_11_12_13 = std::move(label_4_10_11_12_13), ci_12_13 = std::move(ci_12_13)]() {
                        return ({
                            auto i = p0;
                            (prism_rtl::more(prism_rtl::rc(crate::lower::patterns::RustPat(lx_5_10_11_11_13, or_(index(prism_rtl::deref(c_11_13).params, i), crate::lower::patterns::dummy_pat()), or_(index(ptys_7_10_11_12_13, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), crate::lower::types::Holding(crate::lower::types::Holding::ByRef{}), prism_rtl::cat(label_4_10_11_12_13, ci_12_13, "_", i)))));
                        });
                    }));
                    });
                })));
                })), [=](Array<crate::lower::patterns::PatOut> each_5504) {
                    return ({
                        auto pos = each_5504;
                        auto pa = ({
                            __label__ _done;
                            prism_rtl::Slot<crate::lower::model::Pa> _v;
                            {
                                auto&& m5630_0 = pos;
                                if (m5630_0.size() == 1u) {
                                    {
                                        auto&& _c1 = index(m5630_0, Nat(0u));
                                        if (prism_rtl::is_some(_c1)) {
                                            auto&& o = prism_rtl::some_of(_c1);
                                            _v.set(prism_rtl::deref(o).pa);
                                            goto _done;
                                        }
                                    }
                                }
                            }
                            {
                                _v.set(crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{each(pos, [&](const crate::lower::patterns::PatOut& o) { return prism_rtl::deref(o).pa; })}));
                                goto _done;
                            }
                        _done:
                            _v.take();
                        });
                        auto conds = fold(pos, Array<crate::lower::model::Cc>{}, [&](const Array<crate::lower::model::Cc>& acc, const crate::lower::patterns::PatOut& o) { return append(acc, prism_rtl::deref(o).conds); });
                        auto binds = fold(pos, Array<std::tuple<Text, crate::lower::types::Bn>>{}, [&](const Array<std::tuple<Text, crate::lower::types::Bn>>& acc, const crate::lower::patterns::PatOut& o) { return append(acc, prism_rtl::deref(o).binds); });
                        call_value(body_fn_1_10_11(std::tuple{lx_5_10_11, crate::lower::expr::bind_all(env1_10_11, binds), prism_rtl::deref(c).body}), [=, pa = std::move(pa), conds = std::move(conds)](crate::lower::model::Ex body_5910) { return prism_rtl::finished(crate::lower::model::XArm{.pat = pa, .conds = conds, .body = body_5910}); });
                    });
                });
                });
                });
            }));
            });
        })));
        })), [=, scrut = std::move(scrut)](Array<crate::lower::model::XArm> each_5399) {
            return ({
                auto arms = each_5399;
                (prism_rtl::finished(crate::lower::types::own(crate::lower::expr::arms_value(scrut, arms, prism_rtl::cat("\'", label_4), t_8))));
            });
        });
        });
        });
    });
}


/// `Start ClausesBody, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Ex> start_clauses_body(crate::lower::Lx lx, crate::lower::types::Env env, Array<crate::syntax::decls::FnClause> clauses, Array<std::tuple<Text, bool>> names, Array<crate::check::types::Ty> ptys, prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::Lx, crate::lower::types::Env, crate::syntax::decls::FnBody>)> body_fn, Text label, crate::lower::model::OutTy t) {
    return prism_rtl::make_rc<ClausesBody>(lx, env, clauses, names, ptys, body_fn, label, t);
}


/// let dummyClause
crate::syntax::decls::FnClause dummy_clause() {
    return crate::syntax::decls::FnClause{.name = crate::syntax::decls::DefName(crate::syntax::decls::DefName::DefOp{Text::lit(""), crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}}), .params = Array<crate::syntax::Pattern_>{}, .body = crate::syntax::decls::FnBody(crate::syntax::decls::FnBody::BodyExpr{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EError{})), .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}}}), .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}};
}


/// FnBodyValue: unbounded fn Lx, Env, FnBody -> Ex
crate::lower::model::Ex fn_body_value(const crate::lower::Lx& lx, const crate::lower::types::Env& env, const crate::syntax::decls::FnBody& fn_body2) {
    if (prism_rtl::is<crate::syntax::decls::FnBody::BodyExpr>(fn_body2)) {
        auto&& x = prism_rtl::as<crate::syntax::decls::FnBody::BodyExpr>(fn_body2).a0;
        return crate::lower::types::own(crate::lower::expr::value_of(lx, env, x));
    }
    if (prism_rtl::is<crate::syntax::decls::FnBody::BodyBlock>(fn_body2)) {
        auto&& b = prism_rtl::as<crate::syntax::decls::FnBody::BodyBlock>(fn_body2).a0;
        return crate::lower::types::own(crate::lower::expr::block_value(lx, env, b));
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::lower::model::Ex> FnBodyValue::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& fn_body2 = this->fn_body2;
    return ({
        prism_rtl::is<crate::syntax::decls::FnBody::BodyExpr>(fn_body2) ? ({
        auto&& x = prism_rtl::as<crate::syntax::decls::FnBody::BodyExpr>(fn_body2).a0;
        ({
        auto env_1 = env;
        auto lx_2 = lx;
        auto x_3 = x;
        call_then(crate::lower::expr::start_value_of(lx_2, env_1, x_3), [=](crate::lower::types::Vl value_of_6269) { return prism_rtl::finished(crate::lower::types::own(value_of_6269)); });
    });
    })
        : prism_rtl::is<crate::syntax::decls::FnBody::BodyBlock>(fn_body2) ? ({
        auto&& b = prism_rtl::as<crate::syntax::decls::FnBody::BodyBlock>(fn_body2).a0;
        ({
        auto b_1 = b;
        auto env_2 = env;
        auto lx_3 = lx;
        call_then(crate::lower::expr::start_block_value(lx_3, env_2, b_1), [=](crate::lower::types::Vl block_value_6334) { return prism_rtl::finished(crate::lower::types::own(block_value_6334)); });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start FnBodyValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Ex> start_fn_body_value(crate::lower::Lx lx, crate::lower::types::Env env, crate::syntax::decls::FnBody fn_body2) {
    return prism_rtl::make_rc<FnBodyValue>(lx, env, fn_body2);
}


/// FnDefOf: unbounded fn Lx, Text, [FnClause], Scheme -> FnDef
crate::lower::model::FnDef fn_def_of(const crate::lower::Lx& lx, const Text& qk, const Array<crate::syntax::decls::FnClause>& clauses, const crate::check::types::Scheme& sc) {
    auto [ptys0, res] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Array<crate::check::types::Ty>, crate::check::types::Ty>> _v;
        auto&& _m = sc.ty;
        if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
            auto&& ps = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a1;
            auto&& r = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a2;
            _v.set(std::tuple{ps, prism_rtl::deref(prism_rtl::deref(r))});
            goto _done;
        }
        {
            auto&& other = _m;
            _v.set(std::tuple{Array<crate::check::types::Ty>{}, other});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto ptys = crate::lower::types::has_blueprint(res)
        ? each(ptys0, [&](const crate::check::types::Ty& p_) { return crate::lower::types::event_param(p_); })
        : ptys0;
    auto pts = run_to_end(each_job(ptys, ({
        auto lx_1 = lx;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::OutTy>(crate::check::types::Ty)>>(prism_rtl::rc([=, lx_1 = std::move(lx_1)](crate::check::types::Ty p0) {
        return ({
            auto lx_1_2 = lx_1;
            entered(once_job([=, lx_1_2 = std::move(lx_1_2)]() {
            return ({
                auto p_ = p0;
                (prism_rtl::more(prism_rtl::rc(crate::lower::types::OutTyOf(lx_1_2, crate::lower::types::peel(p_)))));
            });
        }));
        });
    })));
    })));
    auto names = param_names(lx, clauses, pts);
    auto body = clauses_body(lx, crate::lower::types::empty_env(), clauses, names, ptys, static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::Lx, crate::lower::types::Env, crate::syntax::decls::FnBody>)>>(prism_rtl::rc([&](std::tuple<crate::lower::Lx, crate::lower::types::Env, crate::syntax::decls::FnBody> _p0) {
        auto&& a0 = std::get<0>(_p0);
        auto&& a1 = std::get<1>(_p0);
        auto&& a2 = std::get<2>(_p0);
        return entered(start_fn_body_value(a0, a1, a2));
    })), Text::lit("c"), crate::lower::types::out_ty_of(lx, crate::lower::types::peel(res)));
    auto params = each(crate::check::errors::range0(len(pts)), [&](const Nat& i) {
        return std::tuple{or_(index(each(names, [&](const std::tuple<Text, bool>& _p0) {
            auto&& n = std::get<0>(_p0);
            return n;
        }), i), Text::lit("arg")), crate::lower::model::OutTy(crate::lower::model::OutTy::OutRef{prism_rtl::rc(or_(index(pts, i), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})))})};
    });
    auto ret = crate::lower::types::out_ty_of(lx, crate::lower::types::peel(res));
    auto used = fold(crate::prelude::push(pts, ret), Array<Text>{}, [&](const Array<Text>& acc, const crate::lower::model::OutTy& t) { return crate::check::types::union_texts(acc, ty_params_in(t)); });
    auto generics = filter(scheme_generics(lx, sc), [&](const std::tuple<Text, Array<Text>>& _p0) {
        auto&& g = std::get<0>(_p0);
        return crate::check::types::has_text(used, g);
    });
    return crate::lower::model::FnDef{.name = or_(crate::prelude::get(lx.rs_names, qk), crate::lower::snake(crate::check::types::bare_name(qk))), .generics = generics, .params = params, .ret = ret, .body = body, .doc = signature_text(lx, qk), .public_ = true};
}


prism_rtl::Turn<crate::lower::model::FnDef> FnDefOf::cycle() const {
    const auto& lx = this->lx;
    const auto& qk = this->qk;
    const auto& clauses = this->clauses;
    const auto& sc = this->sc;
    auto [ptys0, res] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Array<crate::check::types::Ty>, crate::check::types::Ty>> _v;
        auto&& _m = prism_rtl::deref(sc).ty;
        if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
            auto&& ps = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a1;
            auto&& r = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a2;
            _v.set(std::tuple{ps, prism_rtl::deref(prism_rtl::deref(r))});
            goto _done;
        }
        {
            auto&& other = _m;
            _v.set(std::tuple{Array<crate::check::types::Ty>{}, other});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto ptys = crate::lower::types::has_blueprint(res)
        ? each(ptys0, [&](const crate::check::types::Ty& p_) { return crate::lower::types::event_param(p_); })
        : ptys0;
    auto clauses_1 = clauses;
    auto lx_2 = lx;
    auto qk_3 = qk;
    auto sc_4 = sc;
    return call_value(each_job(ptys, ({
        auto lx_2_5 = lx_2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::OutTy>(crate::check::types::Ty)>>(prism_rtl::rc([=, lx_2_5 = std::move(lx_2_5)](crate::check::types::Ty p0) {
        return ({
            auto lx_2_5_5 = lx_2_5;
            entered(once_job([=, lx_2_5_5 = std::move(lx_2_5_5)]() {
            return ({
                auto p_ = p0;
                (prism_rtl::more(prism_rtl::rc(crate::lower::types::OutTyOf(lx_2_5_5, crate::lower::types::peel(p_)))));
            });
        }));
        });
    })));
    })), [=](Array<crate::lower::model::OutTy> each_6891) {
        return ({
            auto pts = each_6891;
            auto names = param_names(lx_2, clauses_1, pts);
            call_then(crate::lower::types::start_out_ty_of(lx_2, crate::lower::types::peel(res)), [=, pts = std::move(pts), names = std::move(names)](crate::lower::model::OutTy out_ty_of_7054) {
            return call_then(start_clauses_body(lx_2, crate::lower::types::empty_env(), clauses_1, names, ptys, static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::Lx, crate::lower::types::Env, crate::syntax::decls::FnBody>)>>(prism_rtl::rc([&](std::tuple<crate::lower::Lx, crate::lower::types::Env, crate::syntax::decls::FnBody> _p0) {
                auto&& a0 = std::get<0>(_p0);
                auto&& a1 = std::get<1>(_p0);
                auto&& a2 = std::get<2>(_p0);
                return entered(start_fn_body_value(a0, a1, a2));
            })), Text::lit("c"), out_ty_of_7054), [=](crate::lower::model::Ex clauses_body_6987) {
                return ({
                    auto body = clauses_body_6987;
                    auto params = each(crate::check::errors::range0(len(pts)), [&](const Nat& i) {
                        return std::tuple{or_(index(each(names, [&](const std::tuple<Text, bool>& _p0) {
                            auto&& n = std::get<0>(_p0);
                            return n;
                        }), i), Text::lit("arg")), crate::lower::model::OutTy(crate::lower::model::OutTy::OutRef{prism_rtl::rc(or_(index(pts, i), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})))})};
                    });
                    call_then(crate::lower::types::start_out_ty_of(lx_2, crate::lower::types::peel(res)), [=, body = std::move(body), params = std::move(params)](crate::lower::model::OutTy out_ty_of_7222) {
                    return ({
                        auto ret = out_ty_of_7222;
                        auto used = fold(crate::prelude::push(pts, ret), Array<Text>{}, [&](const Array<Text>& acc, const crate::lower::model::OutTy& t) { return crate::check::types::union_texts(acc, ty_params_in(t)); });
                        auto generics = filter(scheme_generics(lx_2, sc_4), [&](const std::tuple<Text, Array<Text>>& _p0) {
                            auto&& g = std::get<0>(_p0);
                            return crate::check::types::has_text(used, g);
                        });
                        (prism_rtl::finished(crate::lower::model::FnDef{.name = or_(crate::prelude::get(prism_rtl::deref(lx_2).rs_names, qk_3), crate::lower::snake(crate::check::types::bare_name(qk_3))), .generics = generics, .params = params, .ret = ret, .body = body, .doc = signature_text(lx_2, qk_3), .public_ = true}));
                    });
                });
                });
            });
        });
        });
    });
}


/// `Start FnDefOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::FnDef> start_fn_def_of(crate::lower::Lx lx, Text qk, Array<crate::syntax::decls::FnClause> clauses, crate::check::types::Scheme sc) {
    return prism_rtl::make_rc<FnDefOf>(lx, qk, clauses, sc);
}


/// TyParamsIn: fn OutTy -> [Text]
Array<Text> ty_params_in(const crate::lower::model::OutTy& t) {
    if (prism_rtl::is<crate::lower::model::OutTy::OutGen>(t)) {
        auto&& n = prism_rtl::as<crate::lower::model::OutTy::OutGen>(t).a0;
        return Array(std::vector{n});
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t)) {
        auto&& ts = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t).a1;
        return fold(ts, Array<Text>{}, [&](const Array<Text>& acc, const crate::lower::model::OutTy& x) { return crate::check::types::union_texts(acc, ty_params_in(x)); });
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutTuple>(t)) {
        auto&& ts = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(t).a0;
        return fold(ts, Array<Text>{}, [&](const Array<Text>& acc, const crate::lower::model::OutTy& x) { return crate::check::types::union_texts(acc, ty_params_in(x)); });
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutFn>(t)) {
        auto&& ts = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t).a0;
        auto&& r = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t).a1;
        return fold(ts, ty_params_in(prism_rtl::deref(prism_rtl::deref(r))), [&](const Array<Text>& acc, const crate::lower::model::OutTy& x) { return crate::check::types::union_texts(acc, ty_params_in(x)); });
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(t)) {
        auto&& a = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(t).a0;
        auto&& r = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(t).a1;
        return crate::check::types::union_texts(ty_params_in(prism_rtl::deref(prism_rtl::deref(a))), ty_params_in(prism_rtl::deref(prism_rtl::deref(r))));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutMap>(t)) {
        auto&& k = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t).a0;
        auto&& v_ = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t).a1;
        return crate::check::types::union_texts(ty_params_in(prism_rtl::deref(prism_rtl::deref(k))), ty_params_in(prism_rtl::deref(prism_rtl::deref(v_))));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutOpt>(t)) {
        auto&& x = prism_rtl::as<crate::lower::model::OutTy::OutOpt>(t).a0;
        return ty_params_in(prism_rtl::deref(prism_rtl::deref(x)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutRes>(t)) {
        auto&& x = prism_rtl::as<crate::lower::model::OutTy::OutRes>(t).a0;
        return ty_params_in(prism_rtl::deref(prism_rtl::deref(x)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutArray>(t)) {
        auto&& x = prism_rtl::as<crate::lower::model::OutTy::OutArray>(t).a0;
        return ty_params_in(prism_rtl::deref(prism_rtl::deref(x)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutJob>(t)) {
        auto&& x = prism_rtl::as<crate::lower::model::OutTy::OutJob>(t).a0;
        return ty_params_in(prism_rtl::deref(prism_rtl::deref(x)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutEvent>(t)) {
        auto&& x = prism_rtl::as<crate::lower::model::OutTy::OutEvent>(t).a0;
        return ty_params_in(prism_rtl::deref(prism_rtl::deref(x)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutDyn>(t)) {
        auto&& x = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(t).a0;
        return ty_params_in(prism_rtl::deref(prism_rtl::deref(x)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutRc>(t)) {
        auto&& x = prism_rtl::as<crate::lower::model::OutTy::OutRc>(t).a0;
        return ty_params_in(prism_rtl::deref(prism_rtl::deref(x)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutRef>(t)) {
        auto&& x = prism_rtl::as<crate::lower::model::OutTy::OutRef>(t).a0;
        return ty_params_in(prism_rtl::deref(prism_rtl::deref(x)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutHold>(t)) {
        auto&& x = prism_rtl::as<crate::lower::model::OutTy::OutHold>(t).a0;
        return ty_params_in(prism_rtl::deref(prism_rtl::deref(x)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutCell>(t)) {
        auto&& x = prism_rtl::as<crate::lower::model::OutTy::OutCell>(t).a0;
        return ty_params_in(prism_rtl::deref(prism_rtl::deref(x)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutLive>(t)) {
        auto&& x = prism_rtl::as<crate::lower::model::OutTy::OutLive>(t).a0;
        return ty_params_in(prism_rtl::deref(prism_rtl::deref(x)));
    }
    {
        return Array<Text>{};
    }
}


/// SignatureText: fn Lx, Text -> Text
Text signature_text(const crate::lower::Lx& lx, const Text& qk) {
    auto&& _m = crate::prelude::get(prism_rtl::deref(lx.g).vals, qk);
    if (prism_rtl::is_some(_m)) {
        auto&& v_ = prism_rtl::some_of(_m);
        auto&& _m = index(prism_rtl::deref(lx.g).srcs, v_->file);
        if (prism_rtl::is_some(_m)) {
            auto&& src = prism_rtl::some_of(_m);
            return crate::syntax::lexer::chars::trim(crate::check::errors::span_text(src, prism_rtl::deref(v_).span));
        }
        if (prism_rtl::is_none(_m)) {
            return crate::check::types::bare_name(qk);
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is_none(_m)) {
        return crate::check::types::bare_name(qk);
    }
    prism_rtl::unreachable("no arm matched");
}


/// DefinitionText: fn Lx, Text -> Text
Text definition_text(const crate::lower::Lx& lx, const Text& qk) {
    auto spans = fold(prism_rtl::deref(lx.g).defs, Array<std::tuple<Nat, crate::syntax::Range>>{}, [&](const Array<std::tuple<Nat, crate::syntax::Range>>& acc, const crate::check::env::Def& d) {
        return prism_rtl::deref(d).qk == qk
            ? crate::prelude::push(acc, std::tuple{d->file, prism_rtl::deref(d).span})
            : acc;
    });
    auto sig = ({
        __label__ _done;
        prism_rtl::Slot<Array<std::tuple<Nat, crate::syntax::Range>>> _v;
        auto&& _m = crate::prelude::get(prism_rtl::deref(lx.g).vals, qk);
        if (prism_rtl::is_some(_m)) {
            auto&& v_ = prism_rtl::some_of(_m);
            _v.set(prism_rtl::deref(prism_rtl::deref(v_).span).start < or_(index(each(spans, [&](const std::tuple<Nat, crate::syntax::Range>& _p0) {
                auto&& r = std::get<1>(_p0);
                return prism_rtl::deref(r).start;
            }), Nat(0u)), Nat(0u))
                ? Array(std::vector{std::tuple{v_->file, prism_rtl::deref(v_).span}})
                : Array<std::tuple<Nat, crate::syntax::Range>>{});
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Array<std::tuple<Nat, crate::syntax::Range>>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return crate::syntax::lexer::chars::join(each(append(sig, spans), [&](const std::tuple<Nat, crate::syntax::Range>& _p0) {
        auto&& f = std::get<0>(_p0);
        auto&& r = std::get<1>(_p0);
        return src_text(lx, f, r);
    }), Text::lit("\n"));
}


/// SrcText: fn Lx, Nat, Range -> Text
Text src_text(const crate::lower::Lx& lx, const Nat& f, const crate::syntax::Range& r) {
    auto&& _m = index(prism_rtl::deref(lx.g).srcs, f);
    if (prism_rtl::is_some(_m)) {
        auto&& src = prism_rtl::some_of(_m);
        return drop_trailing_comments(crate::check::errors::span_text(src, r));
    }
    if (prism_rtl::is_none(_m)) {
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}


/// DropTrailingComments: fn Text -> Text
Text drop_trailing_comments(const Text& t) {
    auto lines = split_on(t, Text::lit("\n"));
    auto keep = fold(crate::check::errors::range0(len(lines)), Nat(0u), [&](const Nat& k, const Nat& i) { return is_code_line(or_(index(lines, i), Text::lit(""))) ? i + Nat(1u) : k; });
    return crate::syntax::lexer::chars::trim_end(crate::syntax::lexer::chars::join(take(lines, keep), Text::lit("\n")));
}


/// IsCodeLine: fn Text -> Bool
bool is_code_line(const Text& l) {
    auto s = crate::syntax::lexer::chars::trim(l);
    return (s != Text::lit("")) && (!crate::syntax::lexer::chars::has_prefix(s, Text::lit("#")));
}


/// LetGetter: unbounded fn Lx, Text, LetDecl -> FnDef
crate::lower::model::FnDef let_getter(const crate::lower::Lx& lx, const Text& qk, const crate::syntax::decls::LetDecl& l) {
    auto t = crate::lower::types::out_ty_of(lx, crate::lower::types::peel(crate::lower::type_at(lx, prism_rtl::deref(l.value).span)));
    auto v_ = crate::lower::expr::value_of(lx, crate::lower::types::empty_env(), l.value);
    return crate::lower::model::FnDef{.name = or_(crate::prelude::get(lx.rs_names, qk), crate::lower::snake(crate::check::types::bare_name(qk))), .generics = Array<std::tuple<Text, Array<Text>>>{}, .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .ret = t, .body = crate::lower::types::own(v_), .doc = prism_rtl::cat("let ", crate::check::types::bare_name(qk)), .public_ = true};
}


prism_rtl::Turn<crate::lower::model::FnDef> LetGetter::cycle() const {
    const auto& lx = this->lx;
    const auto& qk = this->qk;
    const auto& l = this->l;
    auto l_1 = l;
    auto lx_2 = lx;
    auto qk_3 = qk;
    return call_then(crate::lower::types::start_out_ty_of(lx_2, crate::lower::types::peel(crate::lower::type_at(lx_2, prism_rtl::deref(l_1->value).span))), [=](crate::lower::model::OutTy out_ty_of_10073) {
        return ({
            auto t = out_ty_of_10073;
            call_then(crate::lower::expr::start_value_of(lx_2, crate::lower::types::empty_env(), l_1->value), [=, t = std::move(t)](crate::lower::types::Vl value_of_10130) {
            return ({
                auto v_ = value_of_10130;
                (prism_rtl::finished(crate::lower::model::FnDef{.name = or_(crate::prelude::get(prism_rtl::deref(lx_2).rs_names, qk_3), crate::lower::snake(crate::check::types::bare_name(qk_3))), .generics = Array<std::tuple<Text, Array<Text>>>{}, .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .ret = t, .body = crate::lower::types::own(v_), .doc = prism_rtl::cat("let ", crate::check::types::bare_name(qk_3)), .public_ = true}));
            });
        });
        });
    });
}


/// `Start LetGetter, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::FnDef> start_let_getter(crate::lower::Lx lx, Text qk, crate::syntax::decls::LetDecl l) {
    return prism_rtl::make_rc<LetGetter>(lx, qk, l);
}


/// HasOwnShow: fn Lx, Text -> Bool
bool has_own_show(const crate::lower::Lx& lx, const Text& tn) {
    return fold(or_(crate::prelude::get(prism_rtl::deref(lx.g).impls, Text::lit("Prelude.Show")), Array<crate::check::env::ImplInfo>{}), false, [&](const bool& f, const crate::check::env::ImplInfo& im) { return prism_rtl::deref(f) || ((!prism_rtl::deref(im).derived) && (head_name(prism_rtl::deref(im).head) == tn)); });
}


/// HeadName: fn Ty -> Text
Text head_name(const crate::check::types::Ty& ty0) {
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(ty0)) {
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyCon>(ty0).a0;
        return n;
    }
    {
        auto&& other = ty0;
        return Text::lit("");
    }
}


/// SelfIn: unbounded fn Ty, Text -> Ty
crate::check::types::Ty self_in(const crate::check::types::Ty& t, const Text& param) {
    return crate::lower::expr::instantiated(t, Array(std::vector{param}), Array(std::vector{crate::check::types::Ty(crate::check::types::Ty::TyCon{Text::lit("\000Self"sv), Array<crate::check::types::Ty>{}})}));
}


prism_rtl::Turn<crate::check::types::Ty> SelfIn::cycle() const {
    const auto& t = this->t;
    const auto& param = this->param;
    return prism_rtl::more(prism_rtl::rc(crate::lower::expr::Instantiated(t, Array(std::vector{param}), Array(std::vector{crate::check::types::Ty(crate::check::types::Ty::TyCon{Text::lit("\000Self"sv), Array<crate::check::types::Ty>{}})}))));
}


/// `Start SelfIn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::Ty> start_self_in(crate::check::types::Ty t, Text param) {
    return prism_rtl::make_rc<SelfIn>(t, param);
}


/// TraitDefOf: unbounded fn Lx, TraitInfo -> TraitDef
crate::lower::model::TraitDef trait_def_of(const crate::lower::Lx& lx0, const crate::check::env::TraitInfo& tr) {
    auto lx = crate::lower::program::in_module(lx0, tr.file, tr.home);
    auto methods = run_to_end(each_job(tr.methods, ({
        auto lx_1 = lx;
        auto tr_2 = tr;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::FnDef>(Text)>>(prism_rtl::rc([=, lx_1 = std::move(lx_1), tr_2 = std::move(tr_2)](Text p0) {
        return ({
            auto lx_1_3 = lx_1;
            auto tr_2_3 = tr_2;
            entered(once_job([=, lx_1_3 = std::move(lx_1_3), tr_2_3 = std::move(tr_2_3)]() {
            return ({
                auto mq = p0;
                ({
                auto v_ = or_(crate::prelude::get(prism_rtl::deref(prism_rtl::deref(lx_1_3).g).vals, mq), crate::check::env::builtin(mq, crate::check::types::schemes::mono(crate::check::types::Ty(crate::check::types::Ty::TyErr{}))));
                auto sc = ({
                    crate::check::types::Scheme this_ = prism_rtl::deref(v_).scheme;
                    this_.ty = self_in(this_.ty, tr_2_3.param);
                    this_.qs = filter(this_.qs, [&](const Text& q) { return q != tr_2_3.param; });
                    this_.bounds = filter(this_.bounds, [&](const std::tuple<Text, Text>& _p0) {
                        auto&& q = std::get<0>(_p0);
                        return q != tr_2_3.param;
                    });
                    (std::move(this_));
                });
                auto default_qk = fold(tr_2_3.defaults, Text::lit(""), [&](const Text& f, const Text& dq) {
                    return crate::check::types::bare_name(dq) == crate::check::types::bare_name(mq)
                        ? dq
                        : f;
                });
                auto clauses = default_qk == Text::lit("")
                    ? Array<crate::syntax::decls::FnClause>{}
                    : default_clauses(prism_rtl::deref(lx_1_3).g, default_qk);
                call_then(start_fn_def_of(lx_1_3, mq, len(clauses) == Nat(0u) ? Array(std::vector{dummy_clause()}) : clauses, sc), [=](crate::lower::model::FnDef fn_def_of_11667) {
                return ({
                    auto fd = fn_def_of_11667;
                    (prism_rtl::finished(({
                    crate::lower::model::FnDef this_ = fd;
                    this_.public_ = len(clauses) > Nat(0u);
                    (std::move(this_));
                })));
                });
            });
            });
            });
        }));
        });
    })));
    })));
    return crate::lower::model::TraitDef{.name = crate::lower::camel(crate::check::types::bare_name(tr.name)), .methods = methods, .defaults = tr.defaults, .doc = crate::lower::program::type_doc(lx, crate::check::env::TyInfo{.name = tr.name, .home = tr.home, .params = Array<Text>{}, .body = crate::check::env::TyBody(crate::check::env::TyBody::BOpaque{}), .derives = Array<Text>{}, .file = tr.file, .span = tr.span})};
}


prism_rtl::Turn<crate::lower::model::TraitDef> TraitDefOf::cycle() const {
    const auto& lx0 = this->lx0;
    const auto& tr = this->tr;
    auto lx = crate::lower::program::in_module(lx0, tr->file, prism_rtl::deref(tr).home);
    auto tr_1 = tr;
    return call_value(each_job(prism_rtl::deref(tr_1).methods, ({
        auto lx_2 = lx;
        auto tr_1_3 = tr_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::FnDef>(Text)>>(prism_rtl::rc([=, lx_2 = std::move(lx_2), tr_1_3 = std::move(tr_1_3)](Text p0) {
        return ({
            auto lx_2_3 = lx_2;
            auto tr_1_3_3 = tr_1_3;
            entered(once_job([=, lx_2_3 = std::move(lx_2_3), tr_1_3_3 = std::move(tr_1_3_3)]() {
            return ({
                auto mq = p0;
                ({
                auto v_ = or_(crate::prelude::get(prism_rtl::deref(prism_rtl::deref(lx_2_3).g).vals, mq), crate::check::env::builtin(mq, crate::check::types::schemes::mono(crate::check::types::Ty(crate::check::types::Ty::TyErr{}))));
                auto sc = ({
                    crate::check::types::Scheme this_ = prism_rtl::deref(v_).scheme;
                    this_.ty = self_in(this_.ty, prism_rtl::deref(tr_1_3_3).param);
                    this_.qs = filter(this_.qs, [&](const Text& q) { return q != prism_rtl::deref(tr_1_3_3).param; });
                    this_.bounds = filter(this_.bounds, [&](const std::tuple<Text, Text>& _p0) {
                        auto&& q = std::get<0>(_p0);
                        return q != prism_rtl::deref(tr_1_3_3).param;
                    });
                    (std::move(this_));
                });
                auto default_qk = fold(prism_rtl::deref(tr_1_3_3).defaults, Text::lit(""), [&](const Text& f, const Text& dq) {
                    return crate::check::types::bare_name(dq) == crate::check::types::bare_name(mq)
                        ? dq
                        : f;
                });
                auto clauses = default_qk == Text::lit("")
                    ? Array<crate::syntax::decls::FnClause>{}
                    : default_clauses(prism_rtl::deref(lx_2_3).g, default_qk);
                call_then(start_fn_def_of(lx_2_3, mq, len(clauses) == Nat(0u) ? Array(std::vector{dummy_clause()}) : clauses, sc), [=](crate::lower::model::FnDef fn_def_of_11667) {
                return ({
                    auto fd = fn_def_of_11667;
                    (prism_rtl::finished(({
                    crate::lower::model::FnDef this_ = fd;
                    this_.public_ = len(clauses) > Nat(0u);
                    (std::move(this_));
                })));
                });
            });
            });
            });
        }));
        });
    })));
    })), [=](Array<crate::lower::model::FnDef> each_11175) {
        return ({
            auto methods = each_11175;
            (prism_rtl::finished(crate::lower::model::TraitDef{.name = crate::lower::camel(crate::check::types::bare_name(prism_rtl::deref(tr_1).name)), .methods = methods, .defaults = prism_rtl::deref(tr_1).defaults, .doc = crate::lower::program::type_doc(lx, crate::check::env::TyInfo{.name = prism_rtl::deref(tr_1).name, .home = prism_rtl::deref(tr_1).home, .params = Array<Text>{}, .body = crate::check::env::TyBody(crate::check::env::TyBody::BOpaque{}), .derives = Array<Text>{}, .file = tr_1->file, .span = prism_rtl::deref(tr_1).span})}));
        });
    });
}


/// `Start TraitDefOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::TraitDef> start_trait_def_of(crate::lower::Lx lx0, crate::check::env::TraitInfo tr) {
    return prism_rtl::make_rc<TraitDefOf>(lx0, tr);
}


/// DefaultClauses: fn G, Text -> [FnClause]
Array<crate::syntax::decls::FnClause> default_clauses(const crate::check::env::G& g, const Text& qk) {
    return fold(g.defs, Array<crate::syntax::decls::FnClause>{}, [&](const Array<crate::syntax::decls::FnClause>& acc, const crate::check::env::Def& d) { return prism_rtl::deref(d).qk == qk ? default_of(d, acc) : acc; });
}


/// DefaultOf: fn Def, [FnClause] -> [FnClause]
Array<crate::syntax::decls::FnClause> default_of(const crate::check::env::Def& d, const Array<crate::syntax::decls::FnClause>& other) {
    auto&& _m = d.body;
    if (prism_rtl::is<crate::check::env::DefBody::DbDefault>(_m)) {
        auto&& cs = prism_rtl::as<crate::check::env::DefBody::DbDefault>(_m).a0;
        return cs;
    }
    {
        return other;
    }
}


/// ImplDefOf: unbounded fn Lx, ImplInfo -> ImplDef
crate::lower::model::ImplDef impl_def_of(const crate::lower::Lx& lx, const crate::check::env::ImplInfo& im) {
    auto tr = or_(crate::prelude::get(prism_rtl::deref(lx.g).traits, im.cls), crate::lower::expr::dummy_trait_info());
    auto head = crate::lower::types::out_ty_of(lx, im.head);
    auto defs = filter(prism_rtl::deref(lx.g).defs, [&](const crate::check::env::Def& d) { return is_method_of(d, im); });
    auto methods = run_to_end(each_job(defs, ({
        auto tr_1 = tr;
        auto lx_2 = lx;
        auto im_3 = im;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::FnDef>(crate::check::env::Def)>>(prism_rtl::rc([=, tr_1 = std::move(tr_1), lx_2 = std::move(lx_2), im_3 = std::move(im_3)](crate::check::env::Def p0) {
        return ({
            auto tr_1_4 = tr_1;
            auto lx_2_4 = lx_2;
            auto im_3_4 = im_3;
            entered(once_job([=, tr_1_4 = std::move(tr_1_4), lx_2_4 = std::move(lx_2_4), im_3_4 = std::move(im_3_4)]() {
            return ({
                auto d = p0;
                ({
                auto mq = fold(prism_rtl::deref(tr_1_4).methods, Text::lit(""), [&](const Text& found, const Text& q) { return crate::check::types::bare_name(q) == prism_rtl::deref(d).name ? q : found; });
                auto v_ = or_(crate::prelude::get(prism_rtl::deref(lx_2_4.g).vals, mq), crate::check::env::builtin(mq, crate::check::types::schemes::mono(crate::check::types::Ty(crate::check::types::Ty::TyErr{}))));
                auto sc = ({
                    crate::check::types::Scheme this_ = prism_rtl::deref(v_).scheme;
                    this_.ty = crate::lower::expr::instantiated(this_.ty, Array(std::vector{prism_rtl::deref(tr_1_4).param}), Array(std::vector{im_3_4.head}));
                    this_.qs = filter(this_.qs, [&](const Text& q) { return q != prism_rtl::deref(tr_1_4).param; });
                    this_.bounds = filter(this_.bounds, [&](const std::tuple<Text, Text>& _p0) {
                        auto&& q = std::get<0>(_p0);
                        return q != prism_rtl::deref(tr_1_4).param;
                    });
                    (std::move(this_));
                });
                call_then(start_fn_def_of(lx_2_4, mq, method_clauses(d), sc), [=](crate::lower::model::FnDef fn_def_of_13000) {
                return ({
                    auto fd = fn_def_of_13000;
                    (crate::syntax::lexer::chars::has_prefix(im_3_4.cls, Text::lit("Prelude."))
                    ? prism_rtl::finished(renamed(fd, prism_rtl::cat(crate::lower::snake(prism_rtl::deref(d).name), "_", crate::lower::snake(crate::check::types::bare_name(head_name(im_3_4.head))))))
                    : prism_rtl::finished(fd));
                });
            });
            });
            });
        }));
        });
    })));
    })));
    auto generics = each(im.qs, [&](const Text& q) { return std::tuple{crate::lower::camel(q), Array(std::vector{Text::lit("Clone")})}; });
    return crate::lower::model::ImplDef{.cls = im.cls, .tr = crate::lower::path_in(lx, prism_rtl::deref(tr).home, crate::lower::camel(crate::check::types::bare_name(im.cls))), .head = head, .generics = generics, .methods = methods, .doc = Text::lit("")};
}


prism_rtl::Turn<crate::lower::model::ImplDef> ImplDefOf::cycle() const {
    const auto& lx = this->lx;
    const auto& im = this->im;
    auto tr = or_(crate::prelude::get(prism_rtl::deref(prism_rtl::deref(lx).g).traits, prism_rtl::deref(im).cls), crate::lower::expr::dummy_trait_info());
    auto im_1 = im;
    auto lx_2 = lx;
    return call_then(crate::lower::types::start_out_ty_of(lx_2, prism_rtl::deref(im_1).head), [=](crate::lower::model::OutTy out_ty_of_12493) {
        return ({
            auto head = out_ty_of_12493;
            auto defs = filter(prism_rtl::deref(prism_rtl::deref(lx_2).g).defs, [&](const crate::check::env::Def& d) { return is_method_of(d, im_1); });
            call_value(each_job(defs, ({
            auto tr_3 = tr;
            auto lx_2_4 = lx_2;
            auto im_1_4 = im_1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::FnDef>(crate::check::env::Def)>>(prism_rtl::rc([=, tr_3 = std::move(tr_3), lx_2_4 = std::move(lx_2_4), im_1_4 = std::move(im_1_4)](crate::check::env::Def p0) {
            return ({
                auto tr_3_4 = tr_3;
                auto lx_2_4_4 = lx_2_4;
                auto im_1_4_4 = im_1_4;
                entered(once_job([=, tr_3_4 = std::move(tr_3_4), lx_2_4_4 = std::move(lx_2_4_4), im_1_4_4 = std::move(im_1_4_4)]() {
                return ({
                    auto d = p0;
                    ({
                    auto mq = fold(prism_rtl::deref(tr_3_4).methods, Text::lit(""), [&](const Text& found, const Text& q) { return crate::check::types::bare_name(q) == prism_rtl::deref(d).name ? q : found; });
                    auto v_ = or_(crate::prelude::get(prism_rtl::deref(prism_rtl::deref(lx_2_4_4).g).vals, mq), crate::check::env::builtin(mq, crate::check::types::schemes::mono(crate::check::types::Ty(crate::check::types::Ty::TyErr{}))));
                    auto sc = ({
                        crate::check::types::Scheme this_ = prism_rtl::deref(v_).scheme;
                        this_.ty = crate::lower::expr::instantiated(this_.ty, Array(std::vector{prism_rtl::deref(tr_3_4).param}), Array(std::vector{prism_rtl::deref(im_1_4_4).head}));
                        this_.qs = filter(this_.qs, [&](const Text& q) { return q != prism_rtl::deref(tr_3_4).param; });
                        this_.bounds = filter(this_.bounds, [&](const std::tuple<Text, Text>& _p0) {
                            auto&& q = std::get<0>(_p0);
                            return q != prism_rtl::deref(tr_3_4).param;
                        });
                        (std::move(this_));
                    });
                    call_then(start_fn_def_of(lx_2_4_4, mq, method_clauses(d), sc), [=](crate::lower::model::FnDef fn_def_of_13000) {
                    return ({
                        auto fd = fn_def_of_13000;
                        (crate::syntax::lexer::chars::has_prefix(prism_rtl::deref(im_1_4_4).cls, Text::lit("Prelude."))
                        ? prism_rtl::finished(renamed(fd, prism_rtl::cat(crate::lower::snake(prism_rtl::deref(d).name), "_", crate::lower::snake(crate::check::types::bare_name(head_name(prism_rtl::deref(im_1_4_4).head))))))
                        : prism_rtl::finished(fd));
                    });
                });
                });
                });
            }));
            });
        })));
        })), [=, head = std::move(head)](Array<crate::lower::model::FnDef> each_12586) {
            return ({
                auto methods = each_12586;
                auto generics = each(prism_rtl::deref(im_1).qs, [&](const Text& q) { return std::tuple{crate::lower::camel(q), Array(std::vector{Text::lit("Clone")})}; });
                (prism_rtl::finished(crate::lower::model::ImplDef{.cls = prism_rtl::deref(im_1).cls, .tr = crate::lower::path_in(lx_2, prism_rtl::deref(tr).home, crate::lower::camel(crate::check::types::bare_name(prism_rtl::deref(im_1).cls))), .head = head, .generics = generics, .methods = methods, .doc = Text::lit("")}));
            });
        });
        });
    });
}


/// `Start ImplDefOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::ImplDef> start_impl_def_of(crate::lower::Lx lx, crate::check::env::ImplInfo im) {
    return prism_rtl::make_rc<ImplDefOf>(lx, im);
}


/// Renamed: fn FnDef, Text -> FnDef
crate::lower::model::FnDef renamed(const crate::lower::model::FnDef& fd, const Text& n) {
    crate::lower::model::FnDef this_ = fd;
    this_.name = n;
    return this_;
}


/// IsMethodOf: fn Def, ImplInfo -> Bool
bool is_method_of(const crate::check::env::Def& d, const crate::check::env::ImplInfo& im) {
    auto&& _m = d.body;
    if (prism_rtl::is<crate::check::env::DefBody::DbMethod>(_m)) {
        auto&& cls = prism_rtl::as<crate::check::env::DefBody::DbMethod>(_m).a1;
        auto&& other = prism_rtl::as<crate::check::env::DefBody::DbMethod>(_m).a2;
        return ((cls == im.cls) && (prism_rtl::deref(other).span == im.span)) && (other->file == im.file);
    }
    {
        return false;
    }
}


/// MethodClauses: fn Def -> [FnClause]
Array<crate::syntax::decls::FnClause> method_clauses(const crate::check::env::Def& d) {
    auto&& _m = d.body;
    if (prism_rtl::is<crate::check::env::DefBody::DbMethod>(_m)) {
        auto&& cs = prism_rtl::as<crate::check::env::DefBody::DbMethod>(_m).a0;
        return cs;
    }
    {
        return Array<crate::syntax::decls::FnClause>{};
    }
}


/// IfGenLine: unbounded fn Wx, Env, Expr, Block, Block, Expr -> ((Wx, Wres))
std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> if_gen_line(const crate::lower::node_::Wx& wx, const crate::lower::types::Env& menv, const crate::syntax::Expr& c, const crate::syntax::Block& then_b, const crate::syntax::Block& else_b, const crate::syntax::Expr& e) {
    auto lx = wx.lx;
    auto pos = wx.pos;
    auto wx1 = ({
        crate::lower::node_::Wx this_ = wx;
        this_.pos = crate::lower::model::next_pos(this_.pos);
        (std::move(this_));
    });
    auto [name, wx2] = crate::lower::node_::fresh_name(wx1, Text::lit("arm"));
    auto base = prism_rtl::cat(wx.node_, crate::lower::camel(name), crate::lower::node_::keyed::row_suffix(wx));
    auto yes = crate::lower::node_::switch_::gen_row_of(wx2, menv, then_b, crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), prism_rtl::cat(base, "Then"), name);
    auto no = crate::lower::node_::switch_::gen_row_of(yes->parent, menv, else_b, crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), prism_rtl::cat(base, "Else"), name);
    auto cond = crate::lower::types::as_bool(crate::lower::expr::value_of(lx, menv, c));
    auto tail = append(append(Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XWeak{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{}))})}), crate::lower::node_::keyed::hosted_passed(wx)), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})}));
    auto mk_fn = ({
        auto tail_1 = tail;
        (prism_rtl::rc([=, tail_1 = std::move(tail_1)](const crate::lower::model::NodeDef& n) { return crate::lower::model::Ex(crate::lower::model::Ex::XCast{prism_rtl::rc(crate::lower::expr::try_of(crate::lower::model::Ex(crate::lower::model::Ex::XCall{prism_rtl::cat(prism_rtl::deref(n).name, "::build"), append(Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("path")}), crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("value")})}), tail_1)}))), crate::lower::model::OutTy(crate::lower::model::OutTy::OutObj{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Row"), Array<crate::lower::model::OutTy>{}}))})}); }));
    });
    auto select = crate::lower::model::Ex(crate::lower::model::Ex::XIf{prism_rtl::rc(cond), prism_rtl::rc(mk_fn(prism_rtl::deref(yes).node_)), prism_rtl::rc(mk_fn(prism_rtl::deref(no).node_))});
    auto wx3 = ({
        crate::lower::node_::Wx this_ = no->parent;
        this_.gens = crate::prelude::push(this_.gens, crate::lower::model::GenDef{.name = name, .pos = pos, .at = crate::lower::node_::finish::place_at(wx, Text::lit("self"), pos), .source = crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), .value_ty = crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), .select = select, .transparent = false, .width = Nat(0u), .moved = or_(crate::lower::node_::finish::hosted_rows(wx), Text::lit(""))});
        this_.gen_holds = crate::prelude::push(this_.gen_holds, std::tuple{name, Array<crate::lower::node_::Read>{}});
        this_.rows = append(append(append(crate::prelude::push(this_.rows, prism_rtl::deref(yes).node_), prism_rtl::deref(prism_rtl::deref(yes).node_).children), Array(std::vector{prism_rtl::deref(no).node_})), prism_rtl::deref(prism_rtl::deref(no).node_).children);
        this_.getters = crate::prelude::push(this_.getters, crate::lower::model::MethDef{.name = prism_rtl::cat(name, "_up"), .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRc{}), .params = Array(std::vector{std::tuple{Text::lit("v"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})}}), .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxMut{}), .ret = crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), .body = Array<crate::lower::model::Do>{}, .tail = crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), .doc = Text::lit("An arm\'s result, which a building `if` of widgets drops.")});
        (std::move(this_));
    });
    return std::tuple{wx3, crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{})};
}


prism_rtl::Turn<std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres>> IfGenLine::cycle() const {
    const auto& wx = this->wx;
    const auto& menv = this->menv;
    const auto& c = this->c;
    const auto& then_b = this->then_b;
    const auto& else_b = this->else_b;
    const auto& e = this->e;
    auto lx = prism_rtl::deref(wx).lx;
    auto pos = prism_rtl::deref(wx).pos;
    auto wx1 = ({
        crate::lower::node_::Wx this_ = wx;
        this_.pos = crate::lower::model::next_pos(this_.pos);
        (std::move(this_));
    });
    auto [name, wx2] = crate::lower::node_::fresh_name(wx1, Text::lit("arm"));
    auto base = prism_rtl::cat(prism_rtl::deref(wx).node_, crate::lower::camel(name), crate::lower::node_::keyed::row_suffix(wx));
    auto yes = crate::lower::node_::switch_::gen_row_of(wx2, menv, then_b, crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), prism_rtl::cat(base, "Then"), name);
    auto no = crate::lower::node_::switch_::gen_row_of(yes->parent, menv, else_b, crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), prism_rtl::cat(base, "Else"), name);
    auto c_1 = c;
    auto menv_2 = menv;
    auto wx_3 = wx;
    return call_then(crate::lower::expr::start_value_of(lx, menv_2, c_1), [=](crate::lower::types::Vl value_of_14466) {
        return ({
            auto cond = crate::lower::types::as_bool(value_of_14466);
            auto tail = append(append(Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XWeak{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{}))})}), crate::lower::node_::keyed::hosted_passed(wx_3)), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})}));
            auto mk_fn = ({
                auto tail_4 = tail;
                (prism_rtl::rc([=, tail_4 = std::move(tail_4)](const crate::lower::model::NodeDef& n) { return crate::lower::model::Ex(crate::lower::model::Ex::XCast{prism_rtl::rc(crate::lower::expr::try_of(crate::lower::model::Ex(crate::lower::model::Ex::XCall{prism_rtl::cat(prism_rtl::deref(n).name, "::build"), append(Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("path")}), crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("value")})}), tail_4)}))), crate::lower::model::OutTy(crate::lower::model::OutTy::OutObj{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Row"), Array<crate::lower::model::OutTy>{}}))})}); }));
            });
            auto select = crate::lower::model::Ex(crate::lower::model::Ex::XIf{prism_rtl::rc(cond), prism_rtl::rc(mk_fn(prism_rtl::deref(yes).node_)), prism_rtl::rc(mk_fn(prism_rtl::deref(no).node_))});
            auto wx3 = ({
                crate::lower::node_::Wx this_ = no->parent;
                this_.gens = crate::prelude::push(this_.gens, crate::lower::model::GenDef{.name = name, .pos = pos, .at = crate::lower::node_::finish::place_at(wx_3, Text::lit("self"), pos), .source = crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), .value_ty = crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), .select = select, .transparent = false, .width = Nat(0u), .moved = or_(crate::lower::node_::finish::hosted_rows(wx_3), Text::lit(""))});
                this_.gen_holds = crate::prelude::push(this_.gen_holds, std::tuple{name, Array<crate::lower::node_::Read>{}});
                this_.rows = append(append(append(crate::prelude::push(this_.rows, prism_rtl::deref(yes).node_), prism_rtl::deref(prism_rtl::deref(yes).node_).children), Array(std::vector{prism_rtl::deref(no).node_})), prism_rtl::deref(prism_rtl::deref(no).node_).children);
                this_.getters = crate::prelude::push(this_.getters, crate::lower::model::MethDef{.name = prism_rtl::cat(name, "_up"), .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRc{}), .params = Array(std::vector{std::tuple{Text::lit("v"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})}}), .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxMut{}), .ret = crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), .body = Array<crate::lower::model::Do>{}, .tail = crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), .doc = Text::lit("An arm\'s result, which a building `if` of widgets drops.")});
                (std::move(this_));
            });
            (prism_rtl::finished(std::tuple{wx3, crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{})}));
        });
    });
}


/// `Start IfGenLine, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres>> start_if_gen_line(crate::lower::node_::Wx wx, crate::lower::types::Env menv, crate::syntax::Expr c, crate::syntax::Block then_b, crate::syntax::Block else_b, crate::syntax::Expr e) {
    return prism_rtl::make_rc<IfGenLine>(wx, menv, c, then_b, else_b, e);
}

}  // namespace crate::lower::functions
