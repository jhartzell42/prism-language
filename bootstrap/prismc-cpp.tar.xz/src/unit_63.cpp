// The modules `Syntax.Lexer.Templates`, `Syntax.Lexer.Words`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/lexer/chars/generic.hpp>

// The module `Syntax.Lexer.Templates`, from `target/bootstrap/cpp-src/prismc/syntax/lexer/templates.prism`.
namespace crate::syntax::lexer::templates {

bool CallRead::operator==(const CallRead& o) const { return l == o.l && attrs == o.attrs && body == o.body && going == o.going; }

void CallRead::show(Printer& p) const {
    p.record("CallRead", {{"l", l}, {"attrs", attrs}, {"body", body}, {"going", going}});
}

Pod CallRead::to_pod() const {
    return Pod::record("CallRead", {{"l", prism_rtl::to_pod(l)}, {"attrs", prism_rtl::to_pod(attrs)}, {"body", prism_rtl::to_pod(body)}, {"going", prism_rtl::to_pod(going)}});
}

Result<CallRead> CallRead::from_pod(const Pod& whole) {
    return CallRead{.l = TRY(prism_rtl::from_pod<crate::syntax::lexer::Lex>(TRY(crate::prelude::field(whole, "l")))), .attrs = TRY(prism_rtl::from_pod<Array<crate::syntax::lexer::AttrTok>>(TRY(crate::prelude::field(whole, "attrs")))), .body = TRY(prism_rtl::from_pod<std::optional<Array<crate::syntax::lexer::TPartTok>>>(TRY(crate::prelude::field(whole, "body")))), .going = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "going"))))};
}


bool RawItem::RiPlaceholder::operator==(const RiPlaceholder& o) const { return a0 == o.a0 && a1 == o.a1; }

bool RawItem::RiBlock::operator==(const RiBlock& o) const { return a0 == o.a0 && a1 == o.a1; }

bool RawItem::RiCall::operator==(const RiCall& o) const { return a0 == o.a0 && a1 == o.a1 && a2 == o.a2 && a3 == o.a3; }

void RawItem::show(Printer& p) const {
    if (auto c = std::get_if<RiText>(&cases())) p.choice("RiText", {c->a0});
    else if (auto c = std::get_if<RiPlaceholder>(&cases())) p.choice("RiPlaceholder", {c->a0, c->a1});
    else if (auto c = std::get_if<RiBlock>(&cases())) p.choice("RiBlock", {c->a0, c->a1});
    else if (auto c = std::get_if<RiCall>(&cases())) p.choice("RiCall", {c->a0, c->a1, c->a2, c->a3});
}

Pod RawItem::to_pod() const {
    return std::holds_alternative<RiText>(cases()) ? Pod::choice("RiText", {prism_rtl::to_pod(std::get<RiText>(cases()).a0)})
        : std::holds_alternative<RiPlaceholder>(cases()) ? Pod::choice("RiPlaceholder", {prism_rtl::to_pod(std::get<RiPlaceholder>(cases()).a0), prism_rtl::to_pod(std::get<RiPlaceholder>(cases()).a1)})
        : std::holds_alternative<RiBlock>(cases()) ? Pod::choice("RiBlock", {prism_rtl::to_pod(std::get<RiBlock>(cases()).a0), prism_rtl::to_pod(std::get<RiBlock>(cases()).a1)})
        : std::holds_alternative<RiCall>(cases()) ? Pod::choice("RiCall", {prism_rtl::to_pod(std::get<RiCall>(cases()).a0), prism_rtl::to_pod(std::get<RiCall>(cases()).a1), prism_rtl::to_pod(std::get<RiCall>(cases()).a2), prism_rtl::to_pod(std::get<RiCall>(cases()).a3)})
        : Pod();
}

Result<RawItem> RawItem::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "RiText" && c->args.size() == 1) return RawItem(RiText{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "RiPlaceholder" && c->args.size() == 2) return RawItem(RiPlaceholder{TRY(prism_rtl::from_pod<Array<crate::syntax::lexer::Tok>>(c->args[0])), TRY(prism_rtl::from_pod<crate::syntax::Range>(c->args[1]))});
        if (c->ctor == "RiBlock" && c->args.size() == 2) return RawItem(RiBlock{TRY(prism_rtl::from_pod<Array<crate::syntax::lexer::Tok>>(c->args[0])), TRY(prism_rtl::from_pod<crate::syntax::Range>(c->args[1]))});
        if (c->ctor == "RiCall" && c->args.size() == 4) return RawItem(RiCall{TRY(prism_rtl::from_pod<crate::syntax::lexer::NameTok>(c->args[0])), TRY(prism_rtl::from_pod<Array<crate::syntax::lexer::AttrTok>>(c->args[1])), TRY(prism_rtl::from_pod<std::optional<Array<crate::syntax::lexer::TPartTok>>>(c->args[2])), TRY(prism_rtl::from_pod<crate::syntax::Range>(c->args[3]))});
    }
    return mismatch<RawItem>("a RawItem", p);
}


bool RawLine::operator==(const RawLine& o) const { return items == o.items && newline == o.newline && block == o.block; }

void RawLine::show(Printer& p) const {
    p.record("RawLine", {{"items", items}, {"newline", newline}, {"block", block}});
}

Pod RawLine::to_pod() const {
    return Pod::record("RawLine", {{"items", prism_rtl::to_pod(items)}, {"newline", prism_rtl::to_pod(newline)}, {"block", prism_rtl::to_pod(block)}});
}

Result<RawLine> RawLine::from_pod(const Pod& whole) {
    return RawLine{.items = TRY(prism_rtl::from_pod<Array<RawItem>>(TRY(crate::prelude::field(whole, "items")))), .newline = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "newline")))), .block = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "block"))))};
}


void TplHow::show(Printer& p) const {
    p.record("TplHow", {{"close", close}, {"delims", delims}, {"open", open}, {"is_raw", is_raw}, {"first_continues", first_continues}});
}

Pod TplHow::to_pod() const {
    return Pod::record("TplHow", {{"close", prism_rtl::to_pod(close)}, {"delims", prism_rtl::to_pod(delims)}, {"open", prism_rtl::to_pod(open)}, {"is_raw", prism_rtl::to_pod(is_raw)}, {"first_continues", prism_rtl::to_pod(first_continues)}});
}

Result<TplHow> TplHow::from_pod(const Pod& whole) {
    return TplHow{.close = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "close")))), .delims = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "delims")))), .open = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "open")))), .is_raw = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "is_raw")))), .first_continues = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "first_continues"))))};
}


bool TplRead::operator==(const TplRead& o) const { return l == o.l && lines == o.lines && cur == o.cur && closing_col == o.closing_col && closed == o.closed && at_line_start == o.at_line_start && going == o.going; }

void TplRead::show(Printer& p) const {
    p.record("TplRead", {{"l", l}, {"lines", lines}, {"cur", cur}, {"closing_col", closing_col}, {"closed", closed}, {"at_line_start", at_line_start}, {"going", going}});
}

Pod TplRead::to_pod() const {
    return Pod::record("TplRead", {{"l", prism_rtl::to_pod(l)}, {"lines", prism_rtl::to_pod(lines)}, {"cur", prism_rtl::to_pod(cur)}, {"closing_col", prism_rtl::to_pod(closing_col)}, {"closed", prism_rtl::to_pod(closed)}, {"at_line_start", prism_rtl::to_pod(at_line_start)}, {"going", prism_rtl::to_pod(going)}});
}

Result<TplRead> TplRead::from_pod(const Pod& whole) {
    return TplRead{.l = TRY(prism_rtl::from_pod<crate::syntax::lexer::Lex>(TRY(crate::prelude::field(whole, "l")))), .lines = TRY(prism_rtl::from_pod<Array<RawLine>>(TRY(crate::prelude::field(whole, "lines")))), .cur = TRY(prism_rtl::from_pod<RawLine>(TRY(crate::prelude::field(whole, "cur")))), .closing_col = TRY(prism_rtl::from_pod<std::optional<Nat>>(TRY(crate::prelude::field(whole, "closing_col")))), .closed = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "closed")))), .at_line_start = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "at_line_start")))), .going = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "going"))))};
}


/// MaybeTemplate: unbounded fn Lex, Text -> Lex
crate::syntax::lexer::Lex maybe_template(const crate::syntax::lexer::Lex& l0_p0, const Text& kw_p1) {
    auto l_p2 = ({
        crate::syntax::lexer::Lex this_ = l0_p0;
        this_.pos = crate::syntax::lexer::chars::match_end(([]() -> const Regex& { static const Regex r = Regex::lit(" *", ""); return r; }()), this_.src, this_.pos);
        (std::move(this_));
    });
    return (crate::syntax::lexer::chars::peek(l_p2) == Text::lit("<")) && (template_tag_ahead(l_p2) != Text::lit(""))
        ? ({
        auto keyword_p3 = kw_p1 == Text::lit("output")
            ? Text::lit("Output")
            : kw_p1 == Text::lit("inline_text")
            ? Text::lit("InlineText")
            : Text::lit("Raw");
        auto [kind_p5, l2_p6] = lex_template(l_p2, keyword_p3, prism_rtl::deref(l_p2).pos);
        auto l3_p4 = ({
            crate::syntax::lexer::Lex this_ = l2_p6;
            this_.last_ws = true;
            (std::move(this_));
        });
        (crate::syntax::lexer::push_tok(l3_p4, kind_p5, prism_rtl::deref(l_p2).pos, prism_rtl::deref(l3_p4).pos));
    })
        : crate::syntax::lexer::chars::lex_err(l0_p0, l0_p0.pos, l0_p0.pos, prism_rtl::cat("`", kw_p1, "` is followed by a language tag, `<rust>`"));
}


prism_rtl::Turn<crate::syntax::lexer::Lex> MaybeTemplate::cycle() const {
    const auto& l0_p0 = this->l0_p0;
    const auto& kw_p1 = this->kw_p1;
    auto l_p2 = ({
        crate::syntax::lexer::Lex this_ = l0_p0;
        this_.pos = crate::syntax::lexer::chars::match_end(([]() -> const Regex& { static const Regex r = Regex::lit(" *", ""); return r; }()), this_.src, this_.pos);
        (std::move(this_));
    });
    return (crate::syntax::lexer::chars::peek(l_p2) == Text::lit("<")) && (template_tag_ahead(l_p2) != Text::lit(""))
        ? ({
        auto keyword_p3 = kw_p1 == Text::lit("output")
            ? Text::lit("Output")
            : kw_p1 == Text::lit("inline_text")
            ? Text::lit("InlineText")
            : Text::lit("Raw");
        call_then(start_lex_template(l_p2, keyword_p3, prism_rtl::deref(l_p2).pos), [=](std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex> lex_template_1019) {
        return ({
            auto [kind_p5, l2_p6] = lex_template_1019;
            auto l3_p4 = ({
                crate::syntax::lexer::Lex this_ = l2_p6;
                this_.last_ws = true;
                (std::move(this_));
            });
            (prism_rtl::finished(crate::syntax::lexer::push_tok(l3_p4, kind_p5, prism_rtl::deref(l_p2).pos, prism_rtl::deref(l3_p4).pos)));
        });
    });
    })
        : prism_rtl::finished(crate::syntax::lexer::chars::lex_err(l0_p0, prism_rtl::deref(l0_p0).pos, prism_rtl::deref(l0_p0).pos, prism_rtl::cat("`", kw_p1, "` is followed by a language tag, `<rust>`")));
}


/// `Start MaybeTemplate, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_maybe_template(crate::syntax::lexer::Lex l0_p0, Text kw_p1) {
    return prism_rtl::make_rc<MaybeTemplate>(l0_p0, kw_p1);
}


/// TemplateTagAhead: unbounded fn Lex -> Text
Text template_tag_ahead(const crate::syntax::lexer::Lex& l_p0) {
    auto&& _name_p2 = crate::syntax::lexer::words::lex_ident(crate::syntax::lexer::chars::bump(l_p0));
    auto&& name_p2 = std::get<0>(_name_p2);
    auto after_p1 = crate::syntax::lexer::chars::peek_at(l_p0, len_text(name_p2) + Nat(1u));
    return (((crate::syntax::lexer::chars::peek(l_p0) == Text::lit("<")) && (name_p2 != Text::lit(""))) && crate::syntax::lexer::chars::is_lower(crate::syntax::lexer::chars::head(name_p2))) && (after_p1 == Text::lit(">"))
        ? name_p2
        : Text::lit("");
}


prism_rtl::Turn<Text> TemplateTagAhead::cycle() const {
    const auto& l_p0 = this->l_p0;
    auto l_p0_1 = l_p0;
    return call_then(crate::syntax::lexer::words::start_lex_ident(crate::syntax::lexer::chars::bump(l_p0_1)), [=](std::tuple<Text, crate::syntax::lexer::Lex> lex_ident_1410) {
        return ({
            auto&& _name_p2 = lex_ident_1410;
            auto&& name_p2 = std::get<0>(_name_p2);
            auto after_p1 = crate::syntax::lexer::chars::peek_at(l_p0_1, len_text(name_p2) + Nat(1u));
            (((crate::syntax::lexer::chars::peek(l_p0_1) == Text::lit("<")) && (name_p2 != Text::lit(""))) && crate::syntax::lexer::chars::is_lower(crate::syntax::lexer::chars::head(name_p2))) && (after_p1 == Text::lit(">"))
            ? prism_rtl::finished(name_p2)
            : prism_rtl::finished(Text::lit(""));
        });
    });
}


/// `Start TemplateTagAhead, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_template_tag_ahead(crate::syntax::lexer::Lex l_p0) {
    return prism_rtl::make_rc<TemplateTagAhead>(l_p0);
}


/// LexTemplate: unbounded fn Lex, Text, Nat -> ((TokKind, Lex))
std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex> lex_template(const crate::syntax::lexer::Lex& l0_p0, const Text& keyword_p1, const Nat& start_p2) {
    auto lang_p3 = template_tag_ahead(l0_p0);
    auto l1_p4 = crate::syntax::lexer::chars::forward(l0_p0, len_text(lang_p3) + Nat(2u));
    auto delims_p5 = (lang_p3 == Text::lit("markdown")) || (lang_p3 == Text::lit("html"))
        ? Text::lit("single")
        : Text::lit("double");
    auto ends_line_p6 = (crate::syntax::lexer::chars::peek(l1_p4) == Text::lit("\n")) || crate::syntax::lexer::chars::starts_with(l1_p4, Text::lit("\r\n"));
    auto skip_p7 = crate::syntax::lexer::chars::peek(l1_p4) == Text::lit("\r")
        ? Nat(2u)
        : Nat(1u);
    auto l2_p8 = std::move(ends_line_p6)
        ? crate::syntax::lexer::chars::forward(l1_p4, skip_p7)
        : l1_p4;
    auto [parts_pa, l3_pb] = template_body(l2_p8, prism_rtl::cat("</", lang_p3, ">"), delims_p5, keyword_p1 == Text::lit("Raw"), !std::move(ends_line_p6), start_p2);
    auto kind_p9 = crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KTemplate{crate::syntax::lexer::TemplateTok{.keyword = keyword_p1, .lang = lang_p3, .delims = delims_p5, .parts = parts_pa}});
    return std::tuple{kind_p9, l3_pb};
}


prism_rtl::Turn<std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex>> LexTemplate::cycle() const {
    const auto& l0_p0 = this->l0_p0;
    const auto& keyword_p1 = this->keyword_p1;
    const auto& start_p2 = this->start_p2;
    auto keyword_p1_1 = keyword_p1;
    auto l0_p0_2 = l0_p0;
    auto start_p2_3 = start_p2;
    return call_then(start_template_tag_ahead(l0_p0_2), [=](Text template_tag_ahead_1743) {
        return ({
            auto lang_p3 = template_tag_ahead_1743;
            auto l1_p4 = crate::syntax::lexer::chars::forward(l0_p0_2, len_text(lang_p3) + Nat(2u));
            auto delims_p5 = (lang_p3 == Text::lit("markdown")) || (lang_p3 == Text::lit("html"))
                ? Text::lit("single")
                : Text::lit("double");
            auto ends_line_p6 = (crate::syntax::lexer::chars::peek(l1_p4) == Text::lit("\n")) || crate::syntax::lexer::chars::starts_with(l1_p4, Text::lit("\r\n"));
            auto skip_p7 = crate::syntax::lexer::chars::peek(l1_p4) == Text::lit("\r")
                ? Nat(2u)
                : Nat(1u);
            auto l2_p8 = std::move(ends_line_p6)
                ? crate::syntax::lexer::chars::forward(l1_p4, skip_p7)
                : l1_p4;
            call_then(start_template_body(l2_p8, prism_rtl::cat("</", lang_p3, ">"), delims_p5, keyword_p1_1 == Text::lit("Raw"), !std::move(ends_line_p6), start_p2_3), [=](std::tuple<Array<crate::syntax::lexer::TPartTok>, crate::syntax::lexer::Lex> template_body_2157) {
            return ({
                auto [parts_pa, l3_pb] = template_body_2157;
                auto kind_p9 = crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KTemplate{crate::syntax::lexer::TemplateTok{.keyword = keyword_p1_1, .lang = lang_p3, .delims = delims_p5, .parts = parts_pa}});
                (prism_rtl::finished(std::tuple{kind_p9, l3_pb}));
            });
        });
        });
    });
}


/// `Start LexTemplate, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex>> start_lex_template(crate::syntax::lexer::Lex l0_p0, Text keyword_p1, Nat start_p2) {
    return prism_rtl::make_rc<LexTemplate>(l0_p0, keyword_p1, start_p2);
}


/// let emptyLine
RawLine empty_line() {
    return RawLine{.items = Array<RawItem>{}, .newline = false, .block = false};
}


/// AddItem: fn RawLine, RawItem -> RawLine
RawLine add_item(const RawLine& line_p0, const RawItem& item_p1) {
    RawLine this_ = line_p0;
    this_.items = add_raw(this_.items, item_p1);
    return this_;
}


/// AddRaw: fn [RawItem], RawItem -> [RawItem]
Array<RawItem> add_raw(const Array<RawItem>& items_p0, const RawItem& raw_item1) {
    if (prism_rtl::is<RawItem::RiText>(raw_item1)) {
        auto&& t_p1 = prism_rtl::as<RawItem::RiText>(raw_item1).a0;
        auto&& _m = crate::syntax::lexer::chars::last(items_p0);
        if (prism_rtl::is_some(_m) && prism_rtl::is<RawItem::RiText>(prism_rtl::some_of(_m))) {
            auto&& s_p2 = prism_rtl::as<RawItem::RiText>(prism_rtl::some_of(_m)).a0;
            return crate::prelude::push(crate::syntax::lexer::chars::pop(items_p0), RawItem(RawItem::RiText{prism_rtl::cat(s_p2, t_p1)}));
        }
        {
            return crate::prelude::push(items_p0, RawItem(RawItem::RiText{t_p1}));
        }
    }
    {
        auto&& item_p4 = raw_item1;
        return crate::prelude::push(items_p0, item_p4);
    }
}


/// OnlyWhitespace: fn RawLine -> Bool
bool only_whitespace(const RawLine& line_p0) {
    return fold(line_p0.items, true, [&](const bool& ok_p1, const RawItem& it_p2) { return prism_rtl::deref(ok_p1) && is_blank_text(it_p2); });
}


/// IsBlankText: fn RawItem -> Bool
bool is_blank_text(const RawItem& raw_item0) {
    if (prism_rtl::is<RawItem::RiText>(raw_item0)) {
        auto&& s_p0 = prism_rtl::as<RawItem::RiText>(raw_item0).a0;
        return crate::syntax::lexer::chars::all_chars(s_p0, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>>(prism_rtl::rc([=](Text p0) {
            return once_job([=]() {
                return ({
                    auto c_p1 = p0;
                    (prism_rtl::finished((c_p1 == Text::lit(" ")) || (c_p1 == Text::lit("\r"))));
                });
            });
        })));
    }
    {
        return false;
    }
}


/// TextLen: fn RawLine -> Nat
Nat text_len(const RawLine& line_p0) {
    return fold(line_p0.items, Nat(0u), [&](const Nat& n_p1, const RawItem& it_p2) { return n_p1 + text_len_of(it_p2); });
}


/// TextLenOf: fn RawItem -> Nat
Nat text_len_of(const RawItem& raw_item0) {
    if (prism_rtl::is<RawItem::RiText>(raw_item0)) {
        auto&& s_p0 = prism_rtl::as<RawItem::RiText>(raw_item0).a0;
        return len_text(s_p0);
    }
    {
        return Nat(0u);
    }
}


/// TemplateBody: unbounded fn Lex, Text, Text, Bool, Bool, Nat -> (([TPartTok], Lex))
std::tuple<Array<crate::syntax::lexer::TPartTok>, crate::syntax::lexer::Lex> template_body(const crate::syntax::lexer::Lex& l0_p0, const Text& close_p1, const Text& delims_p2, const bool& is_raw_p3, const bool& first_continues_p4, const Nat& open_start_p5) {
    auto open_p6 = delims_p2 == Text::lit("double") ? Text::lit("{{") : Text::lit("{");
    auto how_p7 = TplHow{.close = close_p1, .delims = delims_p2, .open = open_p6, .is_raw = is_raw_p3, .first_continues = first_continues_p4};
    auto start_p8 = TplRead{.l = l0_p0, .lines = Array<RawLine>{}, .cur = empty_line(), .closing_col = std::optional<Nat>{}, .closed = false, .at_line_start = !first_continues_p4, .going = true};
    auto r_p9 = ({
        TplRead this_ = start_p8;
        while (this_.going) {
            this_ = template_step(this_, how_p7);
        }
        (std::move(this_));
    });
    auto l1_pa = prism_rtl::deref(r_p9).closed
        ? prism_rtl::deref(r_p9).l
        : crate::syntax::lexer::chars::lex_err(prism_rtl::deref(r_p9).l, open_start_p5, prism_rtl::deref(prism_rtl::deref(r_p9).l).pos, prism_rtl::cat("a template never closes: expected `", close_p1, "`"));
    return finish_template_lines(l1_pa, crate::prelude::push(prism_rtl::deref(r_p9).lines, prism_rtl::deref(r_p9).cur), or_(prism_rtl::deref(r_p9).closing_col, Nat(0u)), first_continues_p4);
}


prism_rtl::Turn<std::tuple<Array<crate::syntax::lexer::TPartTok>, crate::syntax::lexer::Lex>> TemplateBody::cycle() const {
    const auto& l0_p0 = this->l0_p0;
    const auto& close_p1 = this->close_p1;
    const auto& delims_p2 = this->delims_p2;
    const auto& is_raw_p3 = this->is_raw_p3;
    const auto& first_continues_p4 = this->first_continues_p4;
    const auto& open_start_p5 = this->open_start_p5;
    auto open_p6 = delims_p2 == Text::lit("double") ? Text::lit("{{") : Text::lit("{");
    auto how_p7 = TplHow{.close = close_p1, .delims = delims_p2, .open = open_p6, .is_raw = prism_rtl::deref(is_raw_p3), .first_continues = prism_rtl::deref(first_continues_p4)};
    auto start_p8 = TplRead{.l = l0_p0, .lines = Array<RawLine>{}, .cur = empty_line(), .closing_col = std::optional<Nat>{}, .closed = false, .at_line_start = !prism_rtl::deref(first_continues_p4), .going = true};
    TplRead this_ = start_p8;
    auto close_p1_1 = close_p1;
    auto first_continues_p4_2 = prism_rtl::deref(first_continues_p4);
    auto open_start_p5_3 = open_start_p5;
    return call_then(loop_job(std::tuple{std::move(this_)}, ({
        auto how_p7_4 = how_p7;
        [=, how_p7_4 = std::move(how_p7_4)](std::tuple<TplRead> _p0) {
        auto this_ = std::get<0>(_p0);
        return prism_rtl::deref(this_).going
            ? ({
            this_ = template_step(this_, how_p7_4);
            Expected<std::tuple<TplRead>, std::tuple<TplRead>>(std::tuple{this_});
        })
            : Expected<std::tuple<TplRead>, std::tuple<TplRead>>(unexpected(std::tuple{this_}));
    };
    })), [=](std::tuple<TplRead> _p0) {
        auto this_ = std::get<0>(_p0);
        return ({
            auto r_p9 = this_;
            auto l1_pa = prism_rtl::deref(r_p9).closed
                ? prism_rtl::deref(r_p9).l
                : crate::syntax::lexer::chars::lex_err(prism_rtl::deref(r_p9).l, open_start_p5_3, prism_rtl::deref(prism_rtl::deref(r_p9).l).pos, prism_rtl::cat("a template never closes: expected `", close_p1_1, "`"));
            (prism_rtl::finished(finish_template_lines(l1_pa, crate::prelude::push(prism_rtl::deref(r_p9).lines, prism_rtl::deref(r_p9).cur), or_(prism_rtl::deref(r_p9).closing_col, Nat(0u)), first_continues_p4_2)));
        });
    });
}


/// `Start TemplateBody, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::syntax::lexer::TPartTok>, crate::syntax::lexer::Lex>> start_template_body(crate::syntax::lexer::Lex l0_p0, Text close_p1, Text delims_p2, bool is_raw_p3, bool first_continues_p4, Nat open_start_p5) {
    return prism_rtl::make_rc<TemplateBody>(l0_p0, close_p1, delims_p2, is_raw_p3, first_continues_p4, open_start_p5);
}


/// TemplateStep: unbounded fn TplRead, TplHow -> TplRead
TplRead template_step(const TplRead& s_p0, const TplHow& how_p1) {
    auto c_p2 = crate::syntax::lexer::chars::peek(s_p0.l);
    return (s_p0.at_line_start && (!how_p1.is_raw)) && (crate::syntax::lexer::chars::trim(crate::syntax::lexer::chars::rest_of_line(s_p0.l)) == how_p1.open)
        ? brace_block_line(s_p0, crate::syntax::lexer::chars::rest_of_line(s_p0.l), how_p1)
        : crate::syntax::lexer::chars::starts_with(s_p0.l, how_p1.close)
        ? close_template(s_p0, how_p1)
        : c_p2 == Text::lit("")
        ? ({
        TplRead this_ = s_p0;
        this_.at_line_start = false;
        this_.going = false;
        (std::move(this_));
    })
        : c_p2 == Text::lit("\n")
        ? ({
        TplRead this_ = s_p0;
        this_.l = crate::syntax::lexer::chars::bump(this_.l);
        prism_rtl::deref(this_.cur).newline = true;
        this_.lines = crate::prelude::push(this_.lines, this_.cur);
        this_.cur = empty_line();
        this_.at_line_start = true;
        (std::move(this_));
    })
        : ({
        auto [item_p3, l2_p4] = template_item(s_p0.l, how_p1);
        ({
        TplRead this_ = s_p0;
        this_.at_line_start = false;
        this_.l = l2_p4;
        this_.cur = add_item(this_.cur, item_p3);
        (std::move(this_));
    });
    });
}


prism_rtl::Turn<TplRead> TemplateStep::cycle() const {
    const auto& s_p0 = this->s_p0;
    const auto& how_p1 = this->how_p1;
    auto c_p2 = crate::syntax::lexer::chars::peek(prism_rtl::deref(s_p0).l);
    return (prism_rtl::deref(s_p0).at_line_start && (!prism_rtl::deref(how_p1).is_raw)) && (crate::syntax::lexer::chars::trim(crate::syntax::lexer::chars::rest_of_line(prism_rtl::deref(s_p0).l)) == prism_rtl::deref(how_p1).open)
        ? ({
        auto how_p1_1 = how_p1;
        auto s_p0_2 = s_p0;
        call_then(crate::syntax::lexer::chars::start_rest_of_line(prism_rtl::deref(s_p0_2).l), [=, how_p1_1 = std::move(how_p1_1)](Text rest_of_line_5173) { return prism_rtl::more(prism_rtl::rc(BraceBlockLine(s_p0_2, rest_of_line_5173, how_p1_1))); });
    })
        : crate::syntax::lexer::chars::starts_with(prism_rtl::deref(s_p0).l, prism_rtl::deref(how_p1).close)
        ? prism_rtl::finished(close_template(s_p0, how_p1))
        : c_p2 == Text::lit("")
        ? prism_rtl::finished(({
        TplRead this_ = s_p0;
        this_.at_line_start = false;
        this_.going = false;
        (std::move(this_));
    }))
        : c_p2 == Text::lit("\n")
        ? prism_rtl::finished(({
        TplRead this_ = s_p0;
        this_.l = crate::syntax::lexer::chars::bump(this_.l);
        prism_rtl::deref(this_.cur).newline = true;
        this_.lines = crate::prelude::push(this_.lines, this_.cur);
        this_.cur = empty_line();
        this_.at_line_start = true;
        (std::move(this_));
    }))
        : ({
        auto how_p1_1 = how_p1;
        auto s_p0_2 = s_p0;
        call_then(start_template_item(prism_rtl::deref(s_p0_2).l, how_p1_1), [=](std::tuple<RawItem, crate::syntax::lexer::Lex> template_item_5618) {
        return ({
            auto [item_p3, l2_p4] = template_item_5618;
            (prism_rtl::finished(({
            TplRead this_ = s_p0_2;
            this_.at_line_start = false;
            this_.l = l2_p4;
            this_.cur = add_item(this_.cur, item_p3);
            (std::move(this_));
        })));
        });
    });
    });
}


/// `Start TemplateStep, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<TplRead> start_template_step(TplRead s_p0, TplHow how_p1) {
    return prism_rtl::make_rc<TemplateStep>(s_p0, how_p1);
}


/// BraceBlockLine: unbounded fn TplRead, Text, TplHow -> TplRead
TplRead brace_block_line(const TplRead& s_p0, const Text& rest_p1, const TplHow& how_p2) {
    auto bs_p3 = prism_rtl::deref(s_p0.l).pos;
    auto past_p4 = crate::syntax::lexer::chars::forward(s_p0.l, len_text(rest_p1));
    auto at_p5 = crate::syntax::lexer::chars::peek(past_p4) == Text::lit("\n")
        ? crate::syntax::lexer::chars::bump(past_p4)
        : past_p4;
    auto [toks_p7, l2_p8] = crate::syntax::lexer::layout::nested(at_p5, crate::syntax::lexer::Mode(crate::syntax::lexer::Mode::MBrace{how_p2.delims}));
    auto line_p6 = RawLine{.items = Array(std::vector{RawItem(RawItem::RiBlock{toks_p7, crate::syntax::Range{.start = bs_p3, .end = prism_rtl::deref(l2_p8).pos}})}), .newline = false, .block = true};
    TplRead this_ = s_p0;
    this_.lines = crate::prelude::push(this_.lines, line_p6);
    this_.l = l2_p8;
    return this_;
}


prism_rtl::Turn<TplRead> BraceBlockLine::cycle() const {
    const auto& s_p0 = this->s_p0;
    const auto& rest_p1 = this->rest_p1;
    const auto& how_p2 = this->how_p2;
    auto bs_p3 = prism_rtl::deref(prism_rtl::deref(s_p0).l).pos;
    auto past_p4 = crate::syntax::lexer::chars::forward(prism_rtl::deref(s_p0).l, len_text(rest_p1));
    auto at_p5 = crate::syntax::lexer::chars::peek(past_p4) == Text::lit("\n")
        ? crate::syntax::lexer::chars::bump(past_p4)
        : past_p4;
    auto how_p2_1 = how_p2;
    auto s_p0_2 = s_p0;
    return call_then(crate::syntax::lexer::layout::start_nested(at_p5, crate::syntax::lexer::Mode(crate::syntax::lexer::Mode::MBrace{prism_rtl::deref(how_p2_1).delims})), [=](std::tuple<Array<crate::syntax::lexer::Tok>, crate::syntax::lexer::Lex> nested_5996) {
        return ({
            auto [toks_p7, l2_p8] = nested_5996;
            auto line_p6 = RawLine{.items = Array(std::vector{RawItem(RawItem::RiBlock{toks_p7, crate::syntax::Range{.start = bs_p3, .end = prism_rtl::deref(l2_p8).pos}})}), .newline = false, .block = true};
            (prism_rtl::finished(({
            TplRead this_ = s_p0_2;
            this_.lines = crate::prelude::push(this_.lines, line_p6);
            this_.l = l2_p8;
            (std::move(this_));
        })));
        });
    });
}


/// `Start BraceBlockLine, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<TplRead> start_brace_block_line(TplRead s_p0, Text rest_p1, TplHow how_p2) {
    return prism_rtl::make_rc<BraceBlockLine>(s_p0, rest_p1, how_p2);
}


/// CloseTemplate: fn TplRead, TplHow -> TplRead
TplRead close_template(const TplRead& s_p0, const TplHow& how_p1) {
    TplRead this_ = s_p0;
    this_.at_line_start = false;
    if (only_whitespace(this_.cur) && ((len(this_.lines) > Nat(0u)) || (!how_p1.first_continues))) {
        this_.closing_col = std::optional(text_len(this_.cur));
        prism_rtl::deref(this_.cur).items = Array<RawItem>{};
    }
    this_.l = crate::syntax::lexer::chars::forward(this_.l, len_text(how_p1.close));
    this_.closed = true;
    this_.going = false;
    return this_;
}


/// TemplateItem: unbounded fn Lex, TplHow -> ((RawItem, Lex))
std::tuple<RawItem, crate::syntax::lexer::Lex> template_item(const crate::syntax::lexer::Lex& l_p0, const TplHow& how_p1) {
    auto live_p2 = !how_p1.is_raw;
    return (std::move(live_p2) && (how_p1.delims == Text::lit("double"))) && crate::syntax::lexer::chars::starts_with(l_p0, Text::lit("\\{{"))
        ? std::tuple{RawItem(RawItem::RiText{Text::lit("{{")}), crate::syntax::lexer::chars::forward(l_p0, Nat(3u))}
        : (std::move(live_p2) && (how_p1.delims == Text::lit("single"))) && crate::syntax::lexer::chars::starts_with(l_p0, Text::lit("\\{"))
        ? std::tuple{RawItem(RawItem::RiText{Text::lit("{")}), crate::syntax::lexer::chars::forward(l_p0, Nat(2u))}
        : std::move(live_p2) && crate::syntax::lexer::chars::starts_with(l_p0, how_p1.open)
        ? ({
        auto ps_p3 = l_p0.pos;
        auto [toks_p5, l2_p6] = crate::syntax::lexer::layout::nested(crate::syntax::lexer::chars::forward(l_p0, len_text(how_p1.open)), crate::syntax::lexer::Mode(crate::syntax::lexer::Mode::MPlaceholder{how_p1.delims}));
        auto item_p4 = RawItem(RawItem::RiPlaceholder{toks_p5, crate::syntax::Range{.start = ps_p3, .end = prism_rtl::deref(l2_p6).pos}});
        std::tuple{item_p4, l2_p6};
    })
        : (std::move(live_p2) && crate::syntax::lexer::chars::starts_with(l_p0, Text::lit("<@"))) && crate::syntax::lexer::chars::is_upper(crate::syntax::lexer::chars::peek_at(l_p0, Nat(2u)))
        ? template_call(l_p0, how_p1.delims, how_p1.open)
        : ({
        auto run_p7 = crate::syntax::lexer::chars::match_here(([]() -> const Regex& { static const Regex r = Regex::lit("[^\\\\{<\\n]+", ""); return r; }()), l_p0);
        auto n_p8 = run_p7 == Text::lit("")
            ? len_text(crate::syntax::lexer::chars::peek(l_p0))
            : len_text(run_p7);
        auto l2_p9 = ({
            crate::syntax::lexer::Lex this_ = l_p0;
            this_.pos = this_.pos + n_p8;
            (std::move(this_));
        });
        std::tuple{RawItem(RawItem::RiText{crate::syntax::lexer::chars::slice(l_p0, l_p0.pos, prism_rtl::deref(l2_p9).pos)}), l2_p9};
    });
}


prism_rtl::Turn<std::tuple<RawItem, crate::syntax::lexer::Lex>> TemplateItem::cycle() const {
    const auto& l_p0 = this->l_p0;
    const auto& how_p1 = this->how_p1;
    auto live_p2 = !prism_rtl::deref(how_p1).is_raw;
    return (std::move(live_p2) && (prism_rtl::deref(how_p1).delims == Text::lit("double"))) && crate::syntax::lexer::chars::starts_with(l_p0, Text::lit("\\{{"))
        ? prism_rtl::finished(std::tuple{RawItem(RawItem::RiText{Text::lit("{{")}), crate::syntax::lexer::chars::forward(l_p0, Nat(3u))})
        : (std::move(live_p2) && (prism_rtl::deref(how_p1).delims == Text::lit("single"))) && crate::syntax::lexer::chars::starts_with(l_p0, Text::lit("\\{"))
        ? prism_rtl::finished(std::tuple{RawItem(RawItem::RiText{Text::lit("{")}), crate::syntax::lexer::chars::forward(l_p0, Nat(2u))})
        : std::move(live_p2) && crate::syntax::lexer::chars::starts_with(l_p0, prism_rtl::deref(how_p1).open)
        ? ({
        auto ps_p3 = prism_rtl::deref(l_p0).pos;
        auto how_p1_1 = how_p1;
        auto l_p0_2 = l_p0;
        call_then(crate::syntax::lexer::layout::start_nested(crate::syntax::lexer::chars::forward(l_p0_2, len_text(prism_rtl::deref(how_p1_1).open)), crate::syntax::lexer::Mode(crate::syntax::lexer::Mode::MPlaceholder{prism_rtl::deref(how_p1_1).delims})), [=, ps_p3 = std::move(ps_p3)](std::tuple<Array<crate::syntax::lexer::Tok>, crate::syntax::lexer::Lex> nested_7242) {
        return ({
            auto [toks_p5, l2_p6] = nested_7242;
            auto item_p4 = RawItem(RawItem::RiPlaceholder{toks_p5, crate::syntax::Range{.start = ps_p3, .end = prism_rtl::deref(l2_p6).pos}});
            (prism_rtl::finished(std::tuple{item_p4, l2_p6}));
        });
    });
    })
        : (std::move(live_p2) && crate::syntax::lexer::chars::starts_with(l_p0, Text::lit("<@"))) && crate::syntax::lexer::chars::is_upper(crate::syntax::lexer::chars::peek_at(l_p0, Nat(2u)))
        ? prism_rtl::more(prism_rtl::rc(TemplateCall(l_p0, prism_rtl::deref(how_p1).delims, prism_rtl::deref(how_p1).open)))
        : ({
        auto run_p7 = crate::syntax::lexer::chars::match_here(([]() -> const Regex& { static const Regex r = Regex::lit("[^\\\\{<\\n]+", ""); return r; }()), l_p0);
        auto n_p8 = run_p7 == Text::lit("")
            ? len_text(crate::syntax::lexer::chars::peek(l_p0))
            : len_text(run_p7);
        auto l2_p9 = ({
            crate::syntax::lexer::Lex this_ = l_p0;
            this_.pos = this_.pos + n_p8;
            (std::move(this_));
        });
        (prism_rtl::finished(std::tuple{RawItem(RawItem::RiText{crate::syntax::lexer::chars::slice(l_p0, prism_rtl::deref(l_p0).pos, prism_rtl::deref(l2_p9).pos)}), l2_p9}));
    });
}


/// `Start TemplateItem, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<RawItem, crate::syntax::lexer::Lex>> start_template_item(crate::syntax::lexer::Lex l_p0, TplHow how_p1) {
    return prism_rtl::make_rc<TemplateItem>(l_p0, how_p1);
}


/// TemplateCall: unbounded fn Lex, Text, Text -> ((RawItem, Lex))
std::tuple<RawItem, crate::syntax::lexer::Lex> template_call(const crate::syntax::lexer::Lex& l0_p0, const Text& delims_p1, const Text& open_p2) {
    auto start_p3 = l0_p0.pos;
    auto&& _sigils_p8 = crate::syntax::lexer::words::read_sigils(crate::syntax::lexer::chars::bump(l0_p0));
    auto&& sigils_p8 = std::get<0>(_sigils_p8);
    auto&& l1_p9 = std::get<2>(_sigils_p8);
    auto [path_pa, l2_pb] = crate::syntax::lexer::words::lex_qualified_path(l1_p9);
    auto name_p4 = crate::syntax::lexer::NameTok{.sigils = sigils_p8, .path_ = path_pa, .case_ = crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseUpper{})};
    auto close_p5 = prism_rtl::cat("</", sigils_p8, crate::syntax::lexer::chars::join(path_pa, Text::lit(".")), ">");
    auto r_p6 = ({
        CallRead this_ = CallRead{.l = l2_pb, .attrs = Array<crate::syntax::lexer::AttrTok>{}, .body = std::optional<Array<crate::syntax::lexer::TPartTok>>{}, .going = true};
        while (this_.going) {
            this_ = call_step(this_, start_p3, close_p5, delims_p1, open_p2);
        }
        (std::move(this_));
    });
    auto item_p7 = RawItem(RawItem::RiCall{name_p4, prism_rtl::deref(r_p6).attrs, prism_rtl::deref(r_p6).body, crate::syntax::Range{.start = start_p3, .end = prism_rtl::deref(prism_rtl::deref(r_p6).l).pos}});
    return std::tuple{item_p7, prism_rtl::deref(r_p6).l};
}


prism_rtl::Turn<std::tuple<RawItem, crate::syntax::lexer::Lex>> TemplateCall::cycle() const {
    const auto& l0_p0 = this->l0_p0;
    const auto& delims_p1 = this->delims_p1;
    const auto& open_p2 = this->open_p2;
    auto start_p3 = prism_rtl::deref(l0_p0).pos;
    auto delims_p1_1 = delims_p1;
    auto l0_p0_2 = l0_p0;
    auto open_p2_3 = open_p2;
    return call_then(crate::syntax::lexer::words::start_read_sigils(crate::syntax::lexer::chars::bump(l0_p0_2)), [=](std::tuple<Text, bool, crate::syntax::lexer::Lex> read_sigils_8234) {
        return ({
            auto&& _sigils_p8 = read_sigils_8234;
            auto&& sigils_p8 = std::get<0>(_sigils_p8);
            auto&& l1_p9 = std::get<2>(_sigils_p8);
            call_then(crate::syntax::lexer::words::start_lex_qualified_path(l1_p9), [=](std::tuple<Array<Text>, crate::syntax::lexer::Lex> lex_qualified_path_8278) {
            return ({
                auto [path_pa, l2_pb] = lex_qualified_path_8278;
                auto name_p4 = crate::syntax::lexer::NameTok{.sigils = sigils_p8, .path_ = path_pa, .case_ = crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseUpper{})};
                auto close_p5 = prism_rtl::cat("</", sigils_p8, crate::syntax::lexer::chars::join(path_pa, Text::lit(".")), ">");
                CallRead this_ = CallRead{.l = l2_pb, .attrs = Array<crate::syntax::lexer::AttrTok>{}, .body = std::optional<Array<crate::syntax::lexer::TPartTok>>{}, .going = true};
                auto name_p4_4 = name_p4;
                auto start_p3_5 = start_p3;
                call_then(loop_job(std::tuple{std::move(this_)}, ({
                auto close_p5_6 = close_p5;
                auto delims_p1_1_7 = delims_p1_1;
                auto open_p2_3_7 = open_p2_3;
                auto start_p3_5_7 = start_p3_5;
                [=, close_p5_6 = std::move(close_p5_6), delims_p1_1_7 = std::move(delims_p1_1_7), open_p2_3_7 = std::move(open_p2_3_7), start_p3_5_7 = std::move(start_p3_5_7)](std::tuple<CallRead> _p0) {
                auto this_ = std::get<0>(_p0);
                return prism_rtl::deref(this_).going
                    ? ({
                    this_ = call_step(this_, start_p3_5_7, close_p5_6, delims_p1_1_7, open_p2_3_7);
                    Expected<std::tuple<CallRead>, std::tuple<CallRead>>(std::tuple{this_});
                })
                    : Expected<std::tuple<CallRead>, std::tuple<CallRead>>(unexpected(std::tuple{this_}));
            };
            })), [=, name_p4_4 = std::move(name_p4_4)](std::tuple<CallRead> _p0) {
                auto this_ = std::get<0>(_p0);
                return ({
                    auto r_p6 = this_;
                    auto item_p7 = RawItem(RawItem::RiCall{name_p4_4, prism_rtl::deref(r_p6).attrs, prism_rtl::deref(r_p6).body, crate::syntax::Range{.start = start_p3_5, .end = prism_rtl::deref(prism_rtl::deref(r_p6).l).pos}});
                    (prism_rtl::finished(std::tuple{item_p7, prism_rtl::deref(r_p6).l}));
                });
            });
            });
        });
        });
    });
}


/// `Start TemplateCall, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<RawItem, crate::syntax::lexer::Lex>> start_template_call(crate::syntax::lexer::Lex l0_p0, Text delims_p1, Text open_p2) {
    return prism_rtl::make_rc<TemplateCall>(l0_p0, delims_p1, open_p2);
}


/// CallStep: unbounded fn CallRead, Nat, Text, Text, Text -> CallRead
CallRead call_step(const CallRead& s0_p0, const Nat& start_p1, const Text& close_p2, const Text& delims_p3, const Text& open_p4) {
    auto l_p5 = ({
        crate::syntax::lexer::Lex this_ = s0_p0.l;
        this_.pos = crate::syntax::lexer::chars::match_end(([]() -> const Regex& { static const Regex r = Regex::lit("[ \\n\\r]*", ""); return r; }()), this_.src, this_.pos);
        (std::move(this_));
    });
    auto s_p6 = ({
        CallRead this_ = s0_p0;
        this_.l = l_p5;
        (std::move(this_));
    });
    auto at_p7 = prism_rtl::deref(l_p5).pos;
    return crate::syntax::lexer::chars::starts_with(l_p5, Text::lit("/>"))
        ? ({
        CallRead this_ = s_p6;
        this_.l = crate::syntax::lexer::chars::forward(l_p5, Nat(2u));
        this_.going = false;
        (std::move(this_));
    })
        : crate::syntax::lexer::chars::peek(l_p5) == Text::lit(">")
        ? ({
        auto past_p8 = crate::syntax::lexer::chars::bump(l_p5);
        auto continues_p9 = crate::syntax::lexer::chars::peek(past_p8) != Text::lit("\n");
        auto from_pa = std::move(continues_p9)
            ? past_p8
            : crate::syntax::lexer::chars::bump(past_p8);
        auto [parts_pb, l3_pc] = template_body(from_pa, close_p2, delims_p3, false, continues_p9, start_p1);
        ({
        CallRead this_ = s_p6;
        this_.body = std::optional(parts_pb);
        this_.l = l3_pc;
        this_.going = false;
        (std::move(this_));
    });
    })
        : !crate::syntax::lexer::chars::is_ident_start(crate::syntax::lexer::chars::peek(l_p5))
        ? ({
        CallRead this_ = s_p6;
        this_.l = crate::syntax::lexer::chars::lex_err(l_p5, at_p7, at_p7 + Nat(1u), Text::lit("expected an attribute `name=value`, `/>` or `>` in a template call"));
        this_.going = false;
        (std::move(this_));
    })
        : ({
        auto [aname_pd, l3_pe] = crate::syntax::lexer::words::lex_ident(l_p5);
        (crate::syntax::lexer::chars::peek(l3_pe) != Text::lit("=")
        ? ({
        CallRead this_ = s_p6;
        this_.l = crate::syntax::lexer::chars::lex_err(l3_pe, at_p7, prism_rtl::deref(l3_pe).pos, Text::lit("an attribute is `name=value`"));
        (std::move(this_));
    })
        : ({
        auto [tokens_pf, l4_pg] = attr_value(crate::syntax::lexer::chars::bump(l3_pe), delims_p3, open_p4);
        ({
        CallRead this_ = s_p6;
        this_.attrs = crate::prelude::push(this_.attrs, crate::syntax::lexer::AttrTok{.name = aname_pd, .tokens = tokens_pf, .span = crate::syntax::Range{.start = at_p7, .end = prism_rtl::deref(l4_pg).pos}});
        this_.l = l4_pg;
        (std::move(this_));
    });
    }));
    });
}


prism_rtl::Turn<CallRead> CallStep::cycle() const {
    const auto& s0_p0 = this->s0_p0;
    const auto& start_p1 = this->start_p1;
    const auto& close_p2 = this->close_p2;
    const auto& delims_p3 = this->delims_p3;
    const auto& open_p4 = this->open_p4;
    auto l_p5 = ({
        crate::syntax::lexer::Lex this_ = prism_rtl::deref(s0_p0).l;
        this_.pos = crate::syntax::lexer::chars::match_end(([]() -> const Regex& { static const Regex r = Regex::lit("[ \\n\\r]*", ""); return r; }()), this_.src, this_.pos);
        (std::move(this_));
    });
    auto s_p6 = ({
        CallRead this_ = s0_p0;
        this_.l = l_p5;
        (std::move(this_));
    });
    auto at_p7 = prism_rtl::deref(l_p5).pos;
    return crate::syntax::lexer::chars::starts_with(l_p5, Text::lit("/>"))
        ? prism_rtl::finished(({
        CallRead this_ = s_p6;
        this_.l = crate::syntax::lexer::chars::forward(l_p5, Nat(2u));
        this_.going = false;
        (std::move(this_));
    }))
        : crate::syntax::lexer::chars::peek(l_p5) == Text::lit(">")
        ? ({
        auto past_p8 = crate::syntax::lexer::chars::bump(l_p5);
        auto continues_p9 = crate::syntax::lexer::chars::peek(past_p8) != Text::lit("\n");
        auto from_pa = std::move(continues_p9)
            ? past_p8
            : crate::syntax::lexer::chars::bump(past_p8);
        auto close_p2_1 = close_p2;
        auto delims_p3_2 = delims_p3;
        auto start_p1_3 = start_p1;
        call_then(start_template_body(from_pa, close_p2_1, delims_p3_2, false, std::move(continues_p9), start_p1_3), [=](std::tuple<Array<crate::syntax::lexer::TPartTok>, crate::syntax::lexer::Lex> template_body_9198) {
        return ({
            auto [parts_pb, l3_pc] = template_body_9198;
            (prism_rtl::finished(({
            CallRead this_ = s_p6;
            this_.body = std::optional(parts_pb);
            this_.l = l3_pc;
            this_.going = false;
            (std::move(this_));
        })));
        });
    });
    })
        : !crate::syntax::lexer::chars::is_ident_start(crate::syntax::lexer::chars::peek(l_p5))
        ? prism_rtl::finished(({
        CallRead this_ = s_p6;
        this_.l = crate::syntax::lexer::chars::lex_err(l_p5, at_p7, at_p7 + Nat(1u), Text::lit("expected an attribute `name=value`, `/>` or `>` in a template call"));
        this_.going = false;
        (std::move(this_));
    }))
        : ({
        auto delims_p3_1 = delims_p3;
        auto open_p4_2 = open_p4;
        auto start_p1_3 = start_p1;
        call_then(crate::syntax::lexer::words::start_lex_ident(l_p5), [=, delims_p3_1 = std::move(delims_p3_1), open_p4_2 = std::move(open_p4_2)](std::tuple<Text, crate::syntax::lexer::Lex> lex_ident_9597) {
        return ({
            auto [aname_pd, l3_pe] = lex_ident_9597;
            (crate::syntax::lexer::chars::peek(l3_pe) != Text::lit("=")
            ? prism_rtl::finished(({
            CallRead this_ = s_p6;
            this_.l = crate::syntax::lexer::chars::lex_err(l3_pe, at_p7, prism_rtl::deref(l3_pe).pos, Text::lit("an attribute is `name=value`"));
            (std::move(this_));
        }))
            : ({
            auto [tokens_pf, l4_pg] = attr_value(crate::syntax::lexer::chars::bump(l3_pe), delims_p3_1, open_p4_2);
            (prism_rtl::finished(({
            CallRead this_ = s_p6;
            this_.attrs = crate::prelude::push(this_.attrs, crate::syntax::lexer::AttrTok{.name = aname_pd, .tokens = tokens_pf, .span = crate::syntax::Range{.start = at_p7, .end = prism_rtl::deref(l4_pg).pos}});
            this_.l = l4_pg;
            (std::move(this_));
        })));
        }));
        });
    });
    });
}


/// `Start CallStep, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<CallRead> start_call_step(CallRead s0_p0, Nat start_p1, Text close_p2, Text delims_p3, Text open_p4) {
    return prism_rtl::make_rc<CallStep>(s0_p0, start_p1, close_p2, delims_p3, open_p4);
}


/// AttrValue: unbounded fn Lex, Text, Text -> (([Tok], Lex))
std::tuple<Array<crate::syntax::lexer::Tok>, crate::syntax::lexer::Lex> attr_value(const crate::syntax::lexer::Lex& l_p0, const Text& delims_p1, const Text& open_p2) {
    return crate::syntax::lexer::chars::starts_with(l_p0, open_p2)
        ? crate::syntax::lexer::layout::nested(crate::syntax::lexer::chars::forward(l_p0, len_text(open_p2)), crate::syntax::lexer::Mode(crate::syntax::lexer::Mode::MPlaceholder{delims_p1}))
        : crate::syntax::lexer::chars::peek(l_p0) == Text::lit("\"")
        ? ({
        auto [text_p4, l2_p5] = crate::syntax::lexer::literals::lex_text(l_p0);
        auto tok_p3 = crate::syntax::lexer::Tok{.kind = crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KText{Text::lit(""), text_p4}), .span = crate::syntax::Range{.start = l_p0.pos, .end = prism_rtl::deref(l2_p5).pos}, .touches = false, .line_start = false};
        std::tuple{Array(std::vector{tok_p3}), l2_p5};
    })
        : std::tuple{Array<crate::syntax::lexer::Tok>{}, crate::syntax::lexer::chars::lex_err(l_p0, l_p0.pos, l_p0.pos, prism_rtl::cat("an attribute\'s value is a placeholder `", open_p2, "...` or a text literal"))};
}


/// FinishTemplateLines: fn Lex, [RawLine], Nat, Bool -> (([TPartTok], Lex))
std::tuple<Array<crate::syntax::lexer::TPartTok>, crate::syntax::lexer::Lex> finish_template_lines(const crate::syntax::lexer::Lex& l0_p0, const Array<RawLine>& lines_p1, const Nat& strip_p2, const bool& first_continues_p3) {
    std::tuple<Array<crate::syntax::lexer::TPartTok>, crate::syntax::lexer::Lex> this_ = std::tuple{Array<crate::syntax::lexer::TPartTok>{}, l0_p0};
    crate::syntax::lexer::Lex l_p4 = l0_p0;
    Array<crate::syntax::lexer::TPartTok> parts_p5 = Array<crate::syntax::lexer::TPartTok>{};
    for (auto&& [i10950, v10950] : prism_rtl::enumerate(lines_p1)) {
        auto k10950 = nat_of(i10950);
        auto line_p6 = v10950;
        if (prism_rtl::deref(line_p6).block) {
            parts_p5 = append(parts_p5, block_parts(prism_rtl::deref(line_p6).items));
        } else  {
            auto first_p7 = (k10950 == Nat(0u)) && first_continues_p3;
            auto [items_p8, l2_p9] = (!std::move(first_p7)) && (strip_p2 > Nat(0u))
                ? strip_line(line_p6, strip_p2, l_p4)
                : std::tuple{prism_rtl::deref(line_p6).items, l_p4};
            l_p4 = l2_p9;
            auto non_blank_pc = fold(items_p8, Array<RawItem>{}, [&](const Array<RawItem>& acc_pa, const RawItem& it_pb) { return is_blank_or_empty(it_pb) ? acc_pa : crate::prelude::push(acc_pa, it_pb); });
            auto alone_pd = (((!std::move(first_p7)) && prism_rtl::deref(line_p6).newline) && (len(non_blank_pc) == Nat(1u))) && is_placeholder_item(or_(index(non_blank_pc, Nat(0u)), RawItem(RawItem::RiText{Text::lit("")})));
            if (std::move(alone_pd)) {
                parts_p5 = crate::prelude::push(parts_p5, alone_placeholder(items_p8));
            } else  {
                parts_p5 = fold(items_p8, parts_p5, push_part);
                if (prism_rtl::deref(line_p6).newline) {
                    parts_p5 = push_part(parts_p5, RawItem(RawItem::RiText{Text::lit("\n")}));
                }
            }
        }
    }
    this_ = std::tuple{parts_p5, l_p4};
    return this_;
}


/// BlockParts: fn [RawItem] -> [TPartTok]
Array<crate::syntax::lexer::TPartTok> block_parts(const Array<RawItem>& items_p0) {
    return fold(items_p0, Array<crate::syntax::lexer::TPartTok>{}, [&](const Array<crate::syntax::lexer::TPartTok>& acc_p1, const RawItem& it_p2) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::syntax::lexer::TPartTok>> _v;
            if (prism_rtl::is<RawItem::RiBlock>(it_p2)) {
                auto&& tokens_p3 = prism_rtl::as<RawItem::RiBlock>(it_p2).a0;
                auto&& span_p4 = prism_rtl::as<RawItem::RiBlock>(it_p2).a1;
                _v.set(crate::prelude::push(acc_p1, crate::syntax::lexer::TPartTok(crate::syntax::lexer::TPartTok::TptBlock{tokens_p3, span_p4})));
                goto _done;
            }
            {
                _v.set(acc_p1);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


/// StripLine: fn RawLine, Nat, Lex -> (([RawItem], Lex))
std::tuple<Array<RawItem>, crate::syntax::lexer::Lex> strip_line(const RawLine& line_p0, const Nat& strip_p1, const crate::syntax::lexer::Lex& l_p2) {
    auto blank_p3 = only_whitespace(line_p0);
    auto n_p4 = ({
        __label__ _done;
        prism_rtl::Slot<Nat> _v;
        auto&& _m = index(line_p0.items, Nat(0u));
        if (prism_rtl::is_some(_m) && prism_rtl::is<RawItem::RiText>(prism_rtl::some_of(_m))) {
            auto&& s_p8 = prism_rtl::as<RawItem::RiText>(prism_rtl::some_of(_m)).a0;
            _v.set(crate::syntax::lexer::chars::leading_in(s_p8, Text::lit(" ")));
            goto _done;
        }
        {
            _v.set(Nat(0u));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto items_p5 = ({
        __label__ _done;
        prism_rtl::Slot<Array<RawItem>> _v;
        auto&& _m = index(line_p0.items, Nat(0u));
        if (prism_rtl::is_some(_m) && prism_rtl::is<RawItem::RiText>(prism_rtl::some_of(_m))) {
            auto&& s_p9 = prism_rtl::as<RawItem::RiText>(prism_rtl::some_of(_m)).a0;
            _v.set(({
                auto rest_pa = ({
                    __label__ _done;
                    prism_rtl::Slot<Text> _v;
                    auto&& _m = cursor_at(s_p9, crate::prelude::min(n_p4, strip_p1));
                    if (prism_rtl::is_some(_m)) {
                        auto&& c_pb = prism_rtl::some_of(_m);
                        _v.set(after(c_pb));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(s_p9);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                append(Array(std::vector{RawItem(RawItem::RiText{rest_pa})}), drop(line_p0.items, Nat(1u)));
            }));
            goto _done;
        }
        {
            _v.set(line_p0.items);
            goto _done;
        }
    _done:
        _v.take();
    });
    auto l2_p6 = (n_p4 < strip_p1) && (!std::move(blank_p3))
        ? crate::syntax::lexer::chars::lex_err(l_p2, prism_rtl::deref(first_item_span(items_p5)).start, prism_rtl::deref(first_item_span(items_p5)).end, Text::lit("a template line is indented less than its closing tag (Q-CT3)"))
        : l_p2;
    auto kept_p7 = index(items_p5, Nat(0u)) == std::optional(RawItem(RawItem::RiText{Text::lit("")}))
        ? drop(items_p5, Nat(1u))
        : items_p5;
    return std::tuple{kept_p7, l2_p6};
}


/// IsBlankOrEmpty: fn RawItem -> Bool
bool is_blank_or_empty(const RawItem& raw_item0) {
    if (prism_rtl::is<RawItem::RiText>(raw_item0)) {
        auto&& s_p0 = prism_rtl::as<RawItem::RiText>(raw_item0).a0;
        return crate::syntax::lexer::chars::trim(s_p0) == Text::lit("");
    }
    {
        return false;
    }
}


/// IsPlaceholderItem: fn RawItem -> Bool
bool is_placeholder_item(const RawItem& raw_item0) {
    if (prism_rtl::is<RawItem::RiPlaceholder>(raw_item0)) {
        return true;
    }
    {
        return false;
    }
}


/// FirstItemSpan: fn [RawItem] -> Range
crate::syntax::Range first_item_span(const Array<RawItem>& items_p0) {
    return or_(fold(items_p0, std::optional<crate::syntax::Range>{}, [&](const std::optional<crate::syntax::Range>& found_o1, const RawItem& it_p2) {
        return found_o1 != std::optional<crate::syntax::Range>{}
            ? found_o1
            : item_span(it_p2);
    }), crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)});
}


/// ?ItemSpan: fn RawItem -> ?Range
std::optional<crate::syntax::Range> item_span(const RawItem& raw_item0) {
    if (prism_rtl::is<RawItem::RiPlaceholder>(raw_item0)) {
        auto&& span_p0 = prism_rtl::as<RawItem::RiPlaceholder>(raw_item0).a1;
        return std::optional(span_p0);
    }
    if (prism_rtl::is<RawItem::RiBlock>(raw_item0)) {
        auto&& span_p1 = prism_rtl::as<RawItem::RiBlock>(raw_item0).a1;
        return std::optional(span_p1);
    }
    if (prism_rtl::is<RawItem::RiCall>(raw_item0)) {
        auto&& span_p2 = prism_rtl::as<RawItem::RiCall>(raw_item0).a3;
        return std::optional(span_p2);
    }
    {
        return std::optional<crate::syntax::Range>{};
    }
}


/// AlonePlaceholder: fn [RawItem] -> TPartTok
crate::syntax::lexer::TPartTok alone_placeholder(const Array<RawItem>& items_p0) {
    auto&& _part_p4 = fold(items_p0, std::tuple{Nat(0u), crate::syntax::lexer::TPartTok(crate::syntax::lexer::TPartTok::TptText{Text::lit("")})}, [&](const std::tuple<Nat, crate::syntax::lexer::TPartTok>& _p0, const RawItem& it_p3) {
        auto&& c_p1 = std::get<0>(_p0);
        auto&& p_p2 = std::get<1>(_p0);
        return alone_step(c_p1, p_p2, it_p3);
    });
    auto&& part_p4 = std::get<1>(_part_p4);
    return part_p4;
}


/// AloneStep: fn Nat, TPartTok, RawItem -> ((Nat, TPartTok))
std::tuple<Nat, crate::syntax::lexer::TPartTok> alone_step(const Nat& c_p0, const crate::syntax::lexer::TPartTok& tpart_tok1, const RawItem& raw_item2) {
    auto&& _m = std::tuple{tpart_tok1, raw_item2};
    if (prism_rtl::is<crate::syntax::lexer::TPartTok::TptText>(std::get<0>(_m)) && prism_rtl::is<RawItem::RiText>(std::get<1>(_m))) {
        auto&& c0_1_0 = prism_rtl::as<crate::syntax::lexer::TPartTok::TptText>(std::get<0>(_m)).a0;
        auto&& s_p1 = prism_rtl::as<RawItem::RiText>(std::get<1>(_m)).a0;
        if (c0_1_0 == Text::lit("")) {
            return c_p0 == Nat(0u)
                ? std::tuple{crate::syntax::lexer::chars::leading_in(s_p1, Text::lit(" ")), crate::syntax::lexer::TPartTok(crate::syntax::lexer::TPartTok::TptText{Text::lit("")})}
                : std::tuple{c_p0, crate::syntax::lexer::TPartTok(crate::syntax::lexer::TPartTok::TptText{Text::lit("")})};
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TPartTok::TptText>(std::get<0>(_m)) && prism_rtl::is<RawItem::RiPlaceholder>(std::get<1>(_m))) {
        auto&& c1_1_0 = prism_rtl::as<crate::syntax::lexer::TPartTok::TptText>(std::get<0>(_m)).a0;
        auto&& tokens_p3 = prism_rtl::as<RawItem::RiPlaceholder>(std::get<1>(_m)).a0;
        auto&& span_p4 = prism_rtl::as<RawItem::RiPlaceholder>(std::get<1>(_m)).a1;
        if (c1_1_0 == Text::lit("")) {
            return std::tuple{c_p0, crate::syntax::lexer::TPartTok(crate::syntax::lexer::TPartTok::TptPlaceholder{tokens_p3, std::optional(c_p0), span_p4})};
        }
    }
    {
        auto&& p_p6 = std::get<0>(_m);
        return std::tuple{c_p0, p_p6};
    }
    prism_rtl::unreachable("no arm matched");
}


/// PushPart: fn [TPartTok], RawItem -> [TPartTok]
Array<crate::syntax::lexer::TPartTok> push_part(const Array<crate::syntax::lexer::TPartTok>& parts_p0, const RawItem& raw_item1) {
    if (prism_rtl::is<RawItem::RiText>(raw_item1)) {
        auto&& c0_1_0 = prism_rtl::as<RawItem::RiText>(raw_item1).a0;
        if (c0_1_0 == Text::lit("")) {
            return parts_p0;
        }
    }
    if (prism_rtl::is<RawItem::RiText>(raw_item1)) {
        auto&& t_p2 = prism_rtl::as<RawItem::RiText>(raw_item1).a0;
        auto&& _m = crate::syntax::lexer::chars::last(parts_p0);
        if (prism_rtl::is_some(_m) && prism_rtl::is<crate::syntax::lexer::TPartTok::TptText>(prism_rtl::some_of(_m))) {
            auto&& s_p3 = prism_rtl::as<crate::syntax::lexer::TPartTok::TptText>(prism_rtl::some_of(_m)).a0;
            return crate::prelude::push(crate::syntax::lexer::chars::pop(parts_p0), crate::syntax::lexer::TPartTok(crate::syntax::lexer::TPartTok::TptText{prism_rtl::cat(s_p3, t_p2)}));
        }
        {
            return crate::prelude::push(parts_p0, crate::syntax::lexer::TPartTok(crate::syntax::lexer::TPartTok::TptText{t_p2}));
        }
    }
    if (prism_rtl::is<RawItem::RiPlaceholder>(raw_item1)) {
        auto&& tokens_p5 = prism_rtl::as<RawItem::RiPlaceholder>(raw_item1).a0;
        auto&& span_p6 = prism_rtl::as<RawItem::RiPlaceholder>(raw_item1).a1;
        return crate::prelude::push(parts_p0, crate::syntax::lexer::TPartTok(crate::syntax::lexer::TPartTok::TptPlaceholder{tokens_p5, std::optional<Nat>{}, span_p6}));
    }
    if (prism_rtl::is<RawItem::RiBlock>(raw_item1)) {
        auto&& tokens_p8 = prism_rtl::as<RawItem::RiBlock>(raw_item1).a0;
        auto&& span_p9 = prism_rtl::as<RawItem::RiBlock>(raw_item1).a1;
        return crate::prelude::push(parts_p0, crate::syntax::lexer::TPartTok(crate::syntax::lexer::TPartTok::TptBlock{tokens_p8, span_p9}));
    }
    if (prism_rtl::is<RawItem::RiCall>(raw_item1)) {
        auto&& name_pb = prism_rtl::as<RawItem::RiCall>(raw_item1).a0;
        auto&& attrs_pc = prism_rtl::as<RawItem::RiCall>(raw_item1).a1;
        auto&& body_od = prism_rtl::as<RawItem::RiCall>(raw_item1).a2;
        auto&& span_pe = prism_rtl::as<RawItem::RiCall>(raw_item1).a3;
        return crate::prelude::push(parts_p0, crate::syntax::lexer::TPartTok(crate::syntax::lexer::TPartTok::TptCall{name_pb, attrs_pc, body_od, span_pe}));
    }
    prism_rtl::unreachable("no arm matched");
}

}  // namespace crate::syntax::lexer::templates


// The module `Syntax.Lexer.Words`, from `target/bootstrap/cpp-src/prismc/syntax/lexer/words.prism`.
namespace crate::syntax::lexer::words {

/// LexToken: unbounded fn Lex -> Lex
crate::syntax::lexer::Lex lex_token(const crate::syntax::lexer::Lex& l0_p0) {
    auto start_p1 = l0_p0.pos;
    auto c_p2 = crate::syntax::lexer::chars::peek(l0_p0);
    auto l_p3 = ({
        crate::syntax::lexer::Lex this_ = l0_p0;
        this_.path_next = false;
        (std::move(this_));
    });
    return l0_p0.path_next && ((crate::syntax::lexer::chars::is_digit(c_p2) || (c_p2 == Text::lit("#"))) || (c_p2 == Text::lit("[")))
        ? lex_path_token(l_p3, start_p1)
        : lex_token_at(l_p3, start_p1, c_p2);
}


prism_rtl::Turn<crate::syntax::lexer::Lex> LexToken::cycle() const {
    const auto& l0_p0 = this->l0_p0;
    auto start_p1 = prism_rtl::deref(l0_p0).pos;
    auto c_p2 = crate::syntax::lexer::chars::peek(l0_p0);
    auto l_p3 = ({
        crate::syntax::lexer::Lex this_ = l0_p0;
        this_.path_next = false;
        (std::move(this_));
    });
    return prism_rtl::deref(l0_p0).path_next && ((crate::syntax::lexer::chars::is_digit(c_p2) || (c_p2 == Text::lit("#"))) || (c_p2 == Text::lit("[")))
        ? prism_rtl::more(prism_rtl::rc(LexPathToken(l_p3, start_p1)))
        : prism_rtl::more(prism_rtl::rc(LexTokenAt(l_p3, start_p1, c_p2)));
}


/// `Start LexToken, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_lex_token(crate::syntax::lexer::Lex l0_p0) {
    return prism_rtl::make_rc<LexToken>(l0_p0);
}


/// LexPathToken: unbounded fn Lex, Nat -> Lex
crate::syntax::lexer::Lex lex_path_token(const crate::syntax::lexer::Lex& l_p0, const Nat& start_p1) {
    auto [segs_p2, l2_p3] = crate::syntax::lexer::literals::lex_path(l_p0);
    return crate::syntax::lexer::push_tok(l2_p3, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KPath{segs_p2}), start_p1, prism_rtl::deref(l2_p3).pos);
}


prism_rtl::Turn<crate::syntax::lexer::Lex> LexPathToken::cycle() const {
    const auto& l_p0 = this->l_p0;
    const auto& start_p1 = this->start_p1;
    auto l_p0_1 = l_p0;
    auto start_p1_2 = start_p1;
    return call_then(crate::syntax::lexer::literals::start_lex_path(l_p0_1), [=](std::tuple<Array<crate::syntax::lexer::PathSegTok>, crate::syntax::lexer::Lex> lex_path_963) {
        return ({
            auto [segs_p2, l2_p3] = lex_path_963;
            (prism_rtl::finished(crate::syntax::lexer::push_tok(l2_p3, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KPath{segs_p2}), start_p1_2, prism_rtl::deref(l2_p3).pos)));
        });
    });
}


/// `Start LexPathToken, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_lex_path_token(crate::syntax::lexer::Lex l_p0, Nat start_p1) {
    return prism_rtl::make_rc<LexPathToken>(l_p0, start_p1);
}


/// LexTokenAt: unbounded fn Lex, Nat, Text -> Lex
crate::syntax::lexer::Lex lex_token_at(const crate::syntax::lexer::Lex& l_p0, const Nat& start_p1, const Text& c_p2) {
    {
        auto&& m1093_0 = c_p2;
        if (m1093_0 == Text::lit("\"")) {
            auto [text_p3, l2_p4] = crate::syntax::lexer::literals::lex_text(l_p0);
            return crate::syntax::lexer::push_tok(l2_p4, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KText{Text::lit(""), text_p3}), start_p1, prism_rtl::deref(l2_p4).pos);
        }
    }
    {
        auto&& m1093_1 = c_p2;
        if (m1093_1 == Text::lit("\'")) {
            auto [ch_p5, l2_p6] = crate::syntax::lexer::literals::lex_char(l_p0);
            return crate::syntax::lexer::push_tok(l2_p6, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KChar{Text::lit(""), ch_p5}), start_p1, prism_rtl::deref(l2_p6).pos);
        }
    }
    {
        if (crate::syntax::lexer::chars::is_digit(c_p2)) {
            auto [kind_p7, l2_p8] = crate::syntax::lexer::literals::lex_number(l_p0, Text::lit(""));
            return crate::syntax::lexer::push_tok(l2_p8, kind_p7, start_p1, prism_rtl::deref(l2_p8).pos);
        }
    }
    {
        if (crate::syntax::lexer::chars::is_ident_start(c_p2)) {
            return lex_word_token(l_p0, Text::lit(""), start_p1);
        }
    }
    {
        if (crate::syntax::lexer::chars::contains(Text::lit("$@?~&^"), c_p2)) {
            return lex_sigils(l_p0);
        }
    }
    {
        auto&& m1093_5 = c_p2;
        if (m1093_5 == Text::lit("!")) {
            return crate::syntax::lexer::chars::peek_at(l_p0, Nat(1u)) == Text::lit("=")
                ? push_op_suffix(crate::syntax::lexer::chars::forward(l_p0, Nat(2u)), Text::lit("!="), start_p1)
                : lex_sigils(l_p0);
        }
    }
    {
        if (crate::syntax::lexer::chars::contains(Text::lit("([{"), c_p2)) {
            return lex_open(l_p0, c_p2, start_p1);
        }
    }
    {
        if (crate::syntax::lexer::chars::contains(Text::lit(")]}"), c_p2)) {
            return lex_close(l_p0, c_p2, start_p1);
        }
    }
    {
        auto&& m1093_8 = c_p2;
        if (m1093_8 == Text::lit(",")) {
            return crate::syntax::lexer::push_tok(crate::syntax::lexer::chars::bump(l_p0), crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KComma{}), start_p1, start_p1 + Nat(1u));
        }
    }
    {
        auto&& m1093_9 = c_p2;
        if (m1093_9 == Text::lit(":")) {
            return crate::syntax::lexer::push_tok(crate::syntax::lexer::chars::bump(l_p0), crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KColon{}), start_p1, start_p1 + Nat(1u));
        }
    }
    {
        auto&& m1093_10 = c_p2;
        if (m1093_10 == Text::lit(";")) {
            return crate::syntax::lexer::push_tok(crate::syntax::lexer::chars::bump(l_p0), crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KSemi{}), start_p1, start_p1 + Nat(1u));
        }
    }
    {
        auto&& m1093_11 = c_p2;
        if (m1093_11 == Text::lit("\\")) {
            return lex_backslash(l_p0, start_p1);
        }
    }
    {
        auto&& m1093_12 = c_p2;
        if (m1093_12 == Text::lit("%")) {
            return crate::syntax::lexer::regexes::lex_regex(l_p0, Text::lit(""), start_p1);
        }
    }
    {
        auto&& m1093_13 = c_p2;
        if (m1093_13 == Text::lit("|")) {
            return lex_bar(l_p0, start_p1);
        }
    }
    {
        auto&& m1093_14 = c_p2;
        if (m1093_14 == Text::lit(".")) {
            return lex_dot(l_p0, start_p1);
        }
    }
    {
        auto&& _m = lex_operator(l_p0, start_p1);
        if (prism_rtl::is_some(_m)) {
            auto&& l2_p9 = prism_rtl::some_of(_m);
            return l2_p9;
        }
        if (prism_rtl::is_none(_m)) {
            auto l1_pa = crate::syntax::lexer::chars::bump(l_p0);
            auto l2_pb = crate::syntax::lexer::chars::lex_err(l1_pa, start_p1, prism_rtl::deref(l1_pa).pos, prism_rtl::cat("unexpected character `", c_p2, "`"));
            crate::syntax::lexer::Lex this_ = l2_pb;
            this_.last_ws = true;
            return this_;
        }
        prism_rtl::unreachable("no arm matched");
    }
}


prism_rtl::Turn<crate::syntax::lexer::Lex> LexTokenAt::cycle() const {
    const auto& l_p0 = this->l_p0;
    const auto& start_p1 = this->start_p1;
    const auto& c_p2 = this->c_p2;
    return ({
        ({
        auto&& m1093_0 = c_p2;
        (m1093_0 == Text::lit("\""));
    }) ? ({
        auto&& m1093_0 = c_p2;
        ({
        auto l_p0_1 = l_p0;
        auto start_p1_2 = start_p1;
        call_then(crate::syntax::lexer::literals::start_lex_text(l_p0_1), [=, start_p1_2 = std::move(start_p1_2)](std::tuple<Array<crate::syntax::lexer::TextSegTok>, crate::syntax::lexer::Lex> lex_text_1139) {
        return ({
            auto [text_p3, l2_p4] = lex_text_1139;
            (prism_rtl::finished(crate::syntax::lexer::push_tok(l2_p4, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KText{Text::lit(""), text_p3}), start_p1_2, prism_rtl::deref(l2_p4).pos)));
        });
    });
    });
    })
        : ({
        auto&& m1093_1 = c_p2;
        (m1093_1 == Text::lit("\'"));
    }) ? ({
        auto&& m1093_1 = c_p2;
        ({
        auto l_p0_1 = l_p0;
        auto start_p1_2 = start_p1;
        call_then(crate::syntax::lexer::literals::start_lex_char(l_p0_1), [=, start_p1_2 = std::move(start_p1_2)](std::tuple<Text, crate::syntax::lexer::Lex> lex_char_1235) {
        return ({
            auto [ch_p5, l2_p6] = lex_char_1235;
            (prism_rtl::finished(crate::syntax::lexer::push_tok(l2_p6, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KChar{Text::lit(""), ch_p5}), start_p1_2, prism_rtl::deref(l2_p6).pos)));
        });
    });
    });
    })
        : ({
        crate::syntax::lexer::chars::is_digit(c_p2);
    }) ? ({
        auto l_p0_1 = l_p0;
        auto start_p1_2 = start_p1;
        call_then(crate::syntax::lexer::literals::start_lex_number(l_p0_1, Text::lit("")), [=, start_p1_2 = std::move(start_p1_2)](std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex> lex_number_1347) {
        return ({
            auto [kind_p7, l2_p8] = lex_number_1347;
            (prism_rtl::finished(crate::syntax::lexer::push_tok(l2_p8, kind_p7, start_p1_2, prism_rtl::deref(l2_p8).pos)));
        });
    });
    })
        : ({
        crate::syntax::lexer::chars::is_ident_start(c_p2);
    }) ? prism_rtl::more(prism_rtl::rc(LexWordToken(l_p0, Text::lit(""), start_p1)))
        : ({
        crate::syntax::lexer::chars::contains(Text::lit("$@?~&^"), c_p2);
    }) ? prism_rtl::more(prism_rtl::rc(LexSigils(l_p0)))
        : ({
        auto&& m1093_5 = c_p2;
        (m1093_5 == Text::lit("!"));
    }) ? ({
        auto&& m1093_5 = c_p2;
        crate::syntax::lexer::chars::peek_at(l_p0, Nat(1u)) == Text::lit("=")
        ? prism_rtl::more(prism_rtl::rc(PushOpSuffix(crate::syntax::lexer::chars::forward(l_p0, Nat(2u)), Text::lit("!="), start_p1)))
        : prism_rtl::more(prism_rtl::rc(LexSigils(l_p0)));
    })
        : ({
        crate::syntax::lexer::chars::contains(Text::lit("([{"), c_p2);
    }) ? prism_rtl::finished(lex_open(l_p0, c_p2, start_p1))
        : ({
        crate::syntax::lexer::chars::contains(Text::lit(")]}"), c_p2);
    }) ? prism_rtl::finished(lex_close(l_p0, c_p2, start_p1))
        : ({
        auto&& m1093_8 = c_p2;
        (m1093_8 == Text::lit(","));
    }) ? ({
        auto&& m1093_8 = c_p2;
        prism_rtl::finished(crate::syntax::lexer::push_tok(crate::syntax::lexer::chars::bump(l_p0), crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KComma{}), start_p1, start_p1 + Nat(1u)));
    })
        : ({
        auto&& m1093_9 = c_p2;
        (m1093_9 == Text::lit(":"));
    }) ? ({
        auto&& m1093_9 = c_p2;
        prism_rtl::finished(crate::syntax::lexer::push_tok(crate::syntax::lexer::chars::bump(l_p0), crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KColon{}), start_p1, start_p1 + Nat(1u)));
    })
        : ({
        auto&& m1093_10 = c_p2;
        (m1093_10 == Text::lit(";"));
    }) ? ({
        auto&& m1093_10 = c_p2;
        prism_rtl::finished(crate::syntax::lexer::push_tok(crate::syntax::lexer::chars::bump(l_p0), crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KSemi{}), start_p1, start_p1 + Nat(1u)));
    })
        : ({
        auto&& m1093_11 = c_p2;
        (m1093_11 == Text::lit("\\"));
    }) ? ({
        auto&& m1093_11 = c_p2;
        prism_rtl::finished(lex_backslash(l_p0, start_p1));
    })
        : ({
        auto&& m1093_12 = c_p2;
        (m1093_12 == Text::lit("%"));
    }) ? ({
        auto&& m1093_12 = c_p2;
        prism_rtl::more(prism_rtl::rc(crate::syntax::lexer::regexes::LexRegex(l_p0, Text::lit(""), start_p1)));
    })
        : ({
        auto&& m1093_13 = c_p2;
        (m1093_13 == Text::lit("|"));
    }) ? ({
        auto&& m1093_13 = c_p2;
        prism_rtl::finished(lex_bar(l_p0, start_p1));
    })
        : ({
        auto&& m1093_14 = c_p2;
        (m1093_14 == Text::lit("."));
    }) ? ({
        auto&& m1093_14 = c_p2;
        prism_rtl::finished(lex_dot(l_p0, start_p1));
    })
        : ({
        auto c_p2_1 = c_p2;
        auto l_p0_2 = l_p0;
        auto start_p1_3 = start_p1;
        call_then(start_lex_operator(l_p0_2, start_p1_3), [=, c_p2_1 = std::move(c_p2_1)](std::optional<crate::syntax::lexer::Lex> lex_operator_1998) {
        return ({
            prism_rtl::is_some(lex_operator_1998) ? ({
            auto&& l2_p9 = prism_rtl::some_of(lex_operator_1998);
            prism_rtl::finished(l2_p9);
        })
            : prism_rtl::is_none(lex_operator_1998) ? ({
            auto l1_pa = crate::syntax::lexer::chars::bump(l_p0_2);
            auto l2_pb = crate::syntax::lexer::chars::lex_err(l1_pa, start_p1_3, prism_rtl::deref(l1_pa).pos, prism_rtl::cat("unexpected character `", c_p2_1, "`"));
            (prism_rtl::finished(({
            crate::syntax::lexer::Lex this_ = l2_pb;
            this_.last_ws = true;
            (std::move(this_));
        })));
        })
            : throw prism_rtl::Panic("no arm matched");
        });
    });
    });
    });
}


/// `Start LexTokenAt, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_lex_token_at(crate::syntax::lexer::Lex l_p0, Nat start_p1, Text c_p2) {
    return prism_rtl::make_rc<LexTokenAt>(l_p0, start_p1, c_p2);
}


/// LexOpen: fn Lex, Text, Nat -> Lex
crate::syntax::lexer::Lex lex_open(const crate::syntax::lexer::Lex& l_p0, const Text& c_p1, const Nat& start_p2) {
    auto prefix_p3 = ((c_p1 == Text::lit("[")) && crate::syntax::lexer::prefix_position(l_p0)) && (!crate::syntax::lexer::chars::next_is_space(l_p0, Nat(1u)));
    auto l2_p4 = ({
        crate::syntax::lexer::Lex this_ = crate::syntax::lexer::chars::bump(l_p0);
        this_.frames = crate::prelude::push(this_.frames, c_p1);
        (std::move(this_));
    });
    return crate::syntax::lexer::push_tok(l2_p4, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KOpen{c_p1, std::move(prefix_p3)}), start_p2, prism_rtl::deref(l2_p4).pos);
}


/// LexClose: fn Lex, Text, Nat -> Lex
crate::syntax::lexer::Lex lex_close(const crate::syntax::lexer::Lex& l_p0, const Text& c_p1, const Nat& start_p2) {
    auto kind_p3 = crate::syntax::lexer::open_of(c_p1);
    auto l1_p4 = crate::syntax::lexer::chars::bump(l_p0);
    auto l2_p5 = ({
        __label__ _done;
        prism_rtl::Slot<crate::syntax::lexer::Lex> _v;
        auto&& _m = crate::syntax::lexer::chars::last(prism_rtl::deref(l1_p4).frames);
        if (prism_rtl::is_some(_m)) {
            auto&& k_p6 = prism_rtl::some_of(_m);
            if (k_p6 == kind_p3) {
                _v.set(({
                    crate::syntax::lexer::Lex this_ = l1_p4;
                    this_.frames = crate::syntax::lexer::chars::pop(this_.frames);
                    (std::move(this_));
                }));
                goto _done;
            }
        }
        if (prism_rtl::is_some(_m)) {
            auto&& m2675_1 = prism_rtl::some_of(_m);
            if (m2675_1 == Text::lit("<<")) {
                _v.set(crate::syntax::lexer::chars::lex_err(l1_p4, start_p2, prism_rtl::deref(l1_p4).pos, prism_rtl::cat("`", c_p1, "` inside `<<`: expected `>>`")));
                goto _done;
            }
        }
        if (prism_rtl::is_some(_m)) {
            auto&& k_p7 = prism_rtl::some_of(_m);
            _v.set(({
                auto l3_p8 = crate::syntax::lexer::chars::lex_err(l1_p4, start_p2, prism_rtl::deref(l1_p4).pos, prism_rtl::cat("`", c_p1, "` closes a `", k_p7, "`"));
                ({
                crate::syntax::lexer::Lex this_ = l3_p8;
                this_.frames = crate::syntax::lexer::chars::pop(this_.frames);
                (std::move(this_));
            });
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(crate::syntax::lexer::chars::lex_err(l1_p4, start_p2, prism_rtl::deref(l1_p4).pos, prism_rtl::cat("`", c_p1, "` closes nothing")));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return crate::syntax::lexer::push_tok(l2_p5, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KClose{kind_p3}), start_p2, prism_rtl::deref(l2_p5).pos);
}


/// LexBackslash: fn Lex, Nat -> Lex
crate::syntax::lexer::Lex lex_backslash(const crate::syntax::lexer::Lex& l_p0, const Nat& start_p1) {
    auto l1_p2 = crate::syntax::lexer::push_tok(crate::syntax::lexer::chars::bump(l_p0), crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KBackslash{}), start_p1, start_p1 + Nat(1u));
    return crate::syntax::lexer::chars::peek(l1_p2) == Text::lit("|")
        ? ({
        auto l2_p3 = ({
            crate::syntax::lexer::Lex this_ = crate::syntax::lexer::chars::bump(l1_p2);
            this_.lambda_open = true;
            (std::move(this_));
        });
        (crate::syntax::lexer::push_tok(l2_p3, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KLambdaBar{true}), prism_rtl::deref(l1_p2).pos, prism_rtl::deref(l1_p2).pos + Nat(1u)));
    })
        : l1_p2;
}


/// LexBar: fn Lex, Nat -> Lex
crate::syntax::lexer::Lex lex_bar(const crate::syntax::lexer::Lex& l_p0, const Nat& start_p1) {
    auto l1_p2 = crate::syntax::lexer::chars::bump(l_p0);
    return prism_rtl::deref(l1_p2).lambda_open
        ? ({
        auto l2_p3 = ({
            crate::syntax::lexer::Lex this_ = l1_p2;
            this_.lambda_open = false;
            (std::move(this_));
        });
        (crate::syntax::lexer::push_tok(l2_p3, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KLambdaBar{false}), start_p1, prism_rtl::deref(l2_p3).pos));
    })
        : crate::syntax::lexer::push_tok(l1_p2, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KBar{}), start_p1, prism_rtl::deref(l1_p2).pos);
}


/// LexDot: fn Lex, Nat -> Lex
crate::syntax::lexer::Lex lex_dot(const crate::syntax::lexer::Lex& l_p0, const Nat& start_p1) {
    return crate::syntax::lexer::chars::starts_with(l_p0, Text::lit(".."))
        ? crate::syntax::lexer::push_tok(crate::syntax::lexer::chars::forward(l_p0, Nat(2u)), crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KDotDot{}), start_p1, start_p1 + Nat(2u))
        : ({
        auto prefix_p2 = crate::syntax::lexer::prefix_position(l_p0) && (!crate::syntax::lexer::chars::next_is_space(l_p0, Nat(1u)));
        auto l1_p3 = std::move(prefix_p2) && crate::syntax::lexer::chars::is_digit(crate::syntax::lexer::chars::peek_at(l_p0, Nat(1u)))
            ? crate::syntax::lexer::chars::lex_err(l_p0, start_p1, start_p1 + Nat(1u), Text::lit("a decimal literal has digits on both sides of its point: write `0.5`, not `.5`"))
            : l_p0;
        (crate::syntax::lexer::push_tok(crate::syntax::lexer::chars::bump(l1_p3), crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KDot{std::move(prefix_p2)}), start_p1, start_p1 + Nat(1u)));
    });
}


/// PushOpSuffix: unbounded fn Lex, Text, Nat -> Lex
crate::syntax::lexer::Lex push_op_suffix(const crate::syntax::lexer::Lex& l_p0, const Text& op_p1, const Nat& start_p2) {
    return crate::syntax::lexer::takes_suffix(op_p1) && crate::syntax::lexer::chars::is_upper(crate::syntax::lexer::chars::peek(l_p0))
        ? ({
        auto [path_p3, l2_p4] = lex_qualified_path(l_p0);
        (crate::syntax::lexer::push_tok(l2_p4, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KSuffixed{op_p1, path_p3}), start_p2, prism_rtl::deref(l2_p4).pos));
    })
        : crate::syntax::lexer::push_tok(l_p0, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KOp{op_p1, false}), start_p2, l_p0.pos);
}


prism_rtl::Turn<crate::syntax::lexer::Lex> PushOpSuffix::cycle() const {
    const auto& l_p0 = this->l_p0;
    const auto& op_p1 = this->op_p1;
    const auto& start_p2 = this->start_p2;
    return crate::syntax::lexer::takes_suffix(op_p1) && crate::syntax::lexer::chars::is_upper(crate::syntax::lexer::chars::peek(l_p0))
        ? ({
        auto l_p0_1 = l_p0;
        auto op_p1_2 = op_p1;
        auto start_p2_3 = start_p2;
        call_then(start_lex_qualified_path(l_p0_1), [=, op_p1_2 = std::move(op_p1_2), start_p2_3 = std::move(start_p2_3)](std::tuple<Array<Text>, crate::syntax::lexer::Lex> lex_qualified_path_4539) {
        return ({
            auto [path_p3, l2_p4] = lex_qualified_path_4539;
            (prism_rtl::finished(crate::syntax::lexer::push_tok(l2_p4, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KSuffixed{op_p1_2, path_p3}), start_p2_3, prism_rtl::deref(l2_p4).pos)));
        });
    });
    })
        : prism_rtl::finished(crate::syntax::lexer::push_tok(l_p0, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KOp{op_p1, false}), start_p2, prism_rtl::deref(l_p0).pos));
}


/// `Start PushOpSuffix, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_push_op_suffix(crate::syntax::lexer::Lex l_p0, Text op_p1, Nat start_p2) {
    return prism_rtl::make_rc<PushOpSuffix>(l_p0, op_p1, start_p2);
}


/// FirstOp: fn Lex -> Text
Text first_op(const crate::syntax::lexer::Lex& l_p0) {
    return crate::syntax::lexer::chars::match_here(crate::syntax::lexer::fat_arrow_on(l_p0)
        ? ([]() -> const Regex& { static const Regex r = Regex::lit("==>|<-|<=|<\\||->|-=|-\\?|\\+=|\\+\\?|\\*=|\\*\\?|\\/=|==|>=|=>|<|>|-|\\+|\\*|\\/|=", ""); return r; }())
        : ([]() -> const Regex& { static const Regex r = Regex::lit("==>|<-|<=|<\\||->|-=|-\\?|\\+=|\\+\\?|\\*=|\\*\\?|\\/=|==|>=|<|>|-|\\+|\\*|\\/|=", ""); return r; }()), l_p0);
}


/// EndsMark: fn Text -> Bool
bool ends_mark(const Text& a_p0) {
    return (a_p0 == Text::lit("")) || crate::syntax::lexer::chars::contains(Text::lit(" \n\r,)]}"), a_p0);
}


/// ClosesSquareOrBrace: fn ?Tok -> Bool
bool closes_square_or_brace(const std::optional<crate::syntax::lexer::Tok>& opt0) {
    if (prism_rtl::is_some(opt0)) {
        auto&& t_p0 = prism_rtl::some_of(opt0);
        return (prism_rtl::deref(t_p0).kind == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KClose{Text::lit("[")})) || (prism_rtl::deref(t_p0).kind == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KClose{Text::lit("{")}));
    }
    if (prism_rtl::is_none(opt0)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// ?LexOperator: unbounded fn Lex, Nat -> ?Lex
std::optional<crate::syntax::lexer::Lex> lex_operator(const crate::syntax::lexer::Lex& l_p0, const Nat& start_p1) {
    auto c_p2 = crate::syntax::lexer::chars::peek(l_p0);
    auto after_p3 = crate::syntax::lexer::chars::peek_at(l_p0, Nat(1u));
    auto non_empty_p4 = (((c_p2 == Text::lit("+")) && (!l_p0.last_ws)) && closes_square_or_brace(crate::syntax::lexer::chars::last(l_p0.tokens))) && (ends_mark(after_p3) || ((after_p3 == Text::lit("?")) && ends_mark(crate::syntax::lexer::chars::peek_at(l_p0, Nat(2u)))));
    return (c_p2 == Text::lit("-")) && crate::syntax::lexer::chars::contains(Text::lit(",)]}"), after_p3)
        ? std::optional(crate::syntax::lexer::push_tok(crate::syntax::lexer::chars::bump(l_p0), crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KAbsent{}), start_p1, start_p1 + Nat(1u)))
        : std::move(non_empty_p4)
        ? std::optional(non_empty_mark(l_p0, start_p1, after_p3))
        : crate::syntax::lexer::chars::starts_with(l_p0, Text::lit("<<"))
        ? std::optional(open_type_args(l_p0, start_p1))
        : crate::syntax::lexer::chars::starts_with(l_p0, Text::lit(">>")) && (crate::syntax::lexer::chars::last(l_p0.frames) == std::optional(Text::lit("<<")))
        ? std::optional(close_type_args(l_p0, start_p1))
        : crate::syntax::lexer::chars::starts_with(l_p0, Text::lit(">>"))
        ? std::optional(crate::syntax::lexer::chars::lex_err(crate::syntax::lexer::push_tok(crate::syntax::lexer::chars::forward(l_p0, Nat(2u)), crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KGtGt{}), start_p1, start_p1 + Nat(2u)), start_p1, start_p1 + Nat(2u), Text::lit("`>>` closes explicit type arguments, and none is open (Prism has no shift operators)")))
        : ({
        __label__ _done;
        prism_rtl::Slot<std::optional<crate::syntax::lexer::Lex>> _v;
        auto&& _m = first_op(l_p0);
        {
            auto&& m6465_0 = _m;
            if (m6465_0 == Text::lit("")) {
                _v.set(std::optional<crate::syntax::lexer::Lex>{});
                goto _done;
            }
        }
        {
            auto&& op_p5 = _m;
            _v.set(std::optional(push_operator(l_p0, op_p5, start_p1)));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::optional<crate::syntax::lexer::Lex>> LexOperator::cycle() const {
    const auto& l_p0 = this->l_p0;
    const auto& start_p1 = this->start_p1;
    auto c_p2 = crate::syntax::lexer::chars::peek(l_p0);
    auto after_p3 = crate::syntax::lexer::chars::peek_at(l_p0, Nat(1u));
    auto non_empty_p4 = (((c_p2 == Text::lit("+")) && (!prism_rtl::deref(l_p0).last_ws)) && closes_square_or_brace(crate::syntax::lexer::chars::last(l_p0->tokens))) && (ends_mark(after_p3) || ((after_p3 == Text::lit("?")) && ends_mark(crate::syntax::lexer::chars::peek_at(l_p0, Nat(2u)))));
    return (c_p2 == Text::lit("-")) && crate::syntax::lexer::chars::contains(Text::lit(",)]}"), after_p3)
        ? prism_rtl::finished(std::optional(crate::syntax::lexer::push_tok(crate::syntax::lexer::chars::bump(l_p0), crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KAbsent{}), start_p1, start_p1 + Nat(1u))))
        : std::move(non_empty_p4)
        ? prism_rtl::finished(std::optional(non_empty_mark(l_p0, start_p1, after_p3)))
        : crate::syntax::lexer::chars::starts_with(l_p0, Text::lit("<<"))
        ? prism_rtl::finished(std::optional(open_type_args(l_p0, start_p1)))
        : crate::syntax::lexer::chars::starts_with(l_p0, Text::lit(">>")) && (crate::syntax::lexer::chars::last(prism_rtl::deref(l_p0).frames) == std::optional(Text::lit("<<")))
        ? prism_rtl::finished(std::optional(close_type_args(l_p0, start_p1)))
        : crate::syntax::lexer::chars::starts_with(l_p0, Text::lit(">>"))
        ? prism_rtl::finished(std::optional(crate::syntax::lexer::chars::lex_err(crate::syntax::lexer::push_tok(crate::syntax::lexer::chars::forward(l_p0, Nat(2u)), crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KGtGt{}), start_p1, start_p1 + Nat(2u)), start_p1, start_p1 + Nat(2u), Text::lit("`>>` closes explicit type arguments, and none is open (Prism has no shift operators)"))))
        : ({
        auto&& _m = first_op(l_p0);
        ({
        auto&& m6465_0 = _m;
        (m6465_0 == Text::lit(""));
    }) ? ({
        auto&& m6465_0 = _m;
        prism_rtl::finished(std::optional<crate::syntax::lexer::Lex>{});
    })
        : ({
        auto&& op_p5 = _m;
        prism_rtl::finished(std::optional(push_operator(l_p0, op_p5, start_p1)));
    });
    });
}


/// `Start LexOperator, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<crate::syntax::lexer::Lex>> start_lex_operator(crate::syntax::lexer::Lex l_p0, Nat start_p1) {
    return prism_rtl::make_rc<LexOperator>(l_p0, start_p1);
}


/// NonEmptyMark: fn Lex, Nat, Text -> Lex
crate::syntax::lexer::Lex non_empty_mark(const crate::syntax::lexer::Lex& l_p0, const Nat& start_p1, const Text& after_p2) {
    auto l1_p3 = crate::syntax::lexer::push_tok(crate::syntax::lexer::chars::bump(l_p0), crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KNonEmpty{}), start_p1, start_p1 + Nat(1u));
    return after_p2 == Text::lit("?")
        ? crate::syntax::lexer::push_tok(crate::syntax::lexer::chars::bump(l1_p3), crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KFree{Text::lit("?")}), prism_rtl::deref(l1_p3).pos, prism_rtl::deref(l1_p3).pos + Nat(1u))
        : l1_p3;
}


/// OpenTypeArgs: fn Lex, Nat -> Lex
crate::syntax::lexer::Lex open_type_args(const crate::syntax::lexer::Lex& l_p0, const Nat& start_p1) {
    auto touching_p2 = (!l_p0.last_ws) && is_name_tok(crate::syntax::lexer::chars::last(l_p0.tokens));
    auto l1_p3 = crate::syntax::lexer::chars::forward(l_p0, Nat(2u));
    auto l2_p4 = std::move(touching_p2)
        ? l1_p3
        : crate::syntax::lexer::chars::lex_err(l1_p3, start_p1, prism_rtl::deref(l1_p3).pos, Text::lit("`<<` opens explicit type arguments and must touch a name on its left (Prism has no shift operators)"));
    auto l3_p5 = ({
        crate::syntax::lexer::Lex this_ = l2_p4;
        this_.frames = crate::prelude::push(this_.frames, Text::lit("<<"));
        (std::move(this_));
    });
    return crate::syntax::lexer::push_tok(l3_p5, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KLtLt{}), start_p1, prism_rtl::deref(l3_p5).pos);
}


/// IsNameTok: fn ?Tok -> Bool
bool is_name_tok(const std::optional<crate::syntax::lexer::Tok>& opt0) {
    if (prism_rtl::is_some(opt0)) {
        auto&& t_p0 = prism_rtl::some_of(opt0);
        auto&& _m = prism_rtl::deref(t_p0).kind;
        if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m)) {
            return true;
        }
        {
            return false;
        }
    }
    if (prism_rtl::is_none(opt0)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// CloseTypeArgs: fn Lex, Nat -> Lex
crate::syntax::lexer::Lex close_type_args(const crate::syntax::lexer::Lex& l_p0, const Nat& start_p1) {
    auto l1_p2 = ({
        crate::syntax::lexer::Lex this_ = crate::syntax::lexer::chars::forward(l_p0, Nat(2u));
        this_.frames = crate::syntax::lexer::chars::pop(this_.frames);
        (std::move(this_));
    });
    return crate::syntax::lexer::push_tok(l1_p2, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KGtGt{}), start_p1, prism_rtl::deref(l1_p2).pos);
}


/// PushOperator: unbounded fn Lex, Text, Nat -> Lex
crate::syntax::lexer::Lex push_operator(const crate::syntax::lexer::Lex& l_p0, const Text& op_p1, const Nat& start_p2) {
    auto l1_p3 = crate::syntax::lexer::chars::forward(l_p0, len_text(op_p1));
    return (((op_p1 == Text::lit("+")) || (op_p1 == Text::lit("-"))) || (op_p1 == Text::lit("-?"))) && (!crate::syntax::lexer::chars::is_upper(crate::syntax::lexer::chars::peek(l1_p3)))
        ? crate::syntax::lexer::push_tok(l1_p3, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KOp{op_p1, crate::syntax::lexer::prefix_position(l1_p3) && (!crate::syntax::lexer::chars::next_is_space(l1_p3, Nat(0u)))}), start_p2, prism_rtl::deref(l1_p3).pos)
        : push_op_suffix(l1_p3, op_p1, start_p2);
}


prism_rtl::Turn<crate::syntax::lexer::Lex> PushOperator::cycle() const {
    const auto& l_p0 = this->l_p0;
    const auto& op_p1 = this->op_p1;
    const auto& start_p2 = this->start_p2;
    auto l1_p3 = crate::syntax::lexer::chars::forward(l_p0, len_text(op_p1));
    return (((op_p1 == Text::lit("+")) || (op_p1 == Text::lit("-"))) || (op_p1 == Text::lit("-?"))) && (!crate::syntax::lexer::chars::is_upper(crate::syntax::lexer::chars::peek(l1_p3)))
        ? prism_rtl::finished(crate::syntax::lexer::push_tok(l1_p3, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KOp{op_p1, crate::syntax::lexer::prefix_position(l1_p3) && (!crate::syntax::lexer::chars::next_is_space(l1_p3, Nat(0u)))}), start_p2, prism_rtl::deref(l1_p3).pos))
        : prism_rtl::more(prism_rtl::rc(PushOpSuffix(l1_p3, op_p1, start_p2)));
}


/// `Start PushOperator, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_push_operator(crate::syntax::lexer::Lex l_p0, Text op_p1, Nat start_p2) {
    return prism_rtl::make_rc<PushOperator>(l_p0, op_p1, start_p2);
}


/// LexSigils: unbounded fn Lex -> Lex
crate::syntax::lexer::Lex lex_sigils(const crate::syntax::lexer::Lex& l0_p0) {
    auto start_p1 = l0_p0.pos;
    auto [sigils_p3, caret_p4, l_p5] = read_sigils(l0_p0);
    auto next_p2 = crate::syntax::lexer::chars::peek(l_p5);
    return caret_p4
        ? lex_caret(l_p5, start_p1, sigils_p3, next_p2)
        : ((crate::syntax::lexer::chars::is_ident_start(next_p2) || crate::syntax::lexer::chars::is_digit(next_p2)) || (next_p2 == Text::lit("\""))) || (next_p2 == Text::lit("%"))
        ? lex_attached(l_p5, start_p1, sigils_p3, next_p2)
        : ((sigils_p3 == Text::lit("&")) && (next_p2 == Text::lit("."))) && crate::syntax::lexer::chars::is_lower(crate::syntax::lexer::chars::peek_at(l_p5, Nat(1u)))
        ? crate::syntax::lexer::push_tok(crate::syntax::lexer::chars::bump(l_p5), crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KLensDot{}), start_p1, prism_rtl::deref(l_p5).pos + Nat(1u))
        : free_sigils(l_p5, start_p1, sigils_p3);
}


prism_rtl::Turn<crate::syntax::lexer::Lex> LexSigils::cycle() const {
    const auto& l0_p0 = this->l0_p0;
    auto start_p1 = prism_rtl::deref(l0_p0).pos;
    auto l0_p0_1 = l0_p0;
    return call_then(start_read_sigils(l0_p0_1), [=](std::tuple<Text, bool, crate::syntax::lexer::Lex> read_sigils_8705) {
        return ({
            auto [sigils_p3, caret_p4, l_p5] = read_sigils_8705;
            auto next_p2 = crate::syntax::lexer::chars::peek(l_p5);
            caret_p4
            ? prism_rtl::more(prism_rtl::rc(LexCaret(l_p5, start_p1, sigils_p3, next_p2)))
            : ((crate::syntax::lexer::chars::is_ident_start(next_p2) || crate::syntax::lexer::chars::is_digit(next_p2)) || (next_p2 == Text::lit("\""))) || (next_p2 == Text::lit("%"))
            ? prism_rtl::more(prism_rtl::rc(LexAttached(l_p5, start_p1, sigils_p3, next_p2)))
            : ((sigils_p3 == Text::lit("&")) && (next_p2 == Text::lit("."))) && crate::syntax::lexer::chars::is_lower(crate::syntax::lexer::chars::peek_at(l_p5, Nat(1u)))
            ? prism_rtl::finished(crate::syntax::lexer::push_tok(crate::syntax::lexer::chars::bump(l_p5), crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KLensDot{}), start_p1, prism_rtl::deref(l_p5).pos + Nat(1u)))
            : prism_rtl::finished(free_sigils(l_p5, start_p1, sigils_p3));
        });
    });
}


/// `Start LexSigils, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_lex_sigils(crate::syntax::lexer::Lex l0_p0) {
    return prism_rtl::make_rc<LexSigils>(l0_p0);
}


/// ReadSigils: unbounded fn Lex -> ((Text, Bool, Lex))
std::tuple<Text, bool, crate::syntax::lexer::Lex> read_sigils(const crate::syntax::lexer::Lex& l0_p0) {
    std::tuple<Text, bool, crate::syntax::lexer::Lex> this_ = std::tuple{Text::lit(""), false, l0_p0};
    crate::syntax::lexer::Lex l_p1 = l0_p0;
    Text sigils_p2 = Text::lit("");
    bool caret_p3 = false;
    bool going_p4 = true;
    while (std::move(going_p4)) {
        auto c_p5 = crate::syntax::lexer::chars::peek(l_p1);
        if (c_p5 == Text::lit("^")) {
            l_p1 = crate::syntax::lexer::chars::bump(l_p1);
            caret_p3 = true;
            going_p4 = false;
        } else if (crate::syntax::lexer::chars::is_sigil_char(c_p5) && (!((c_p5 == Text::lit("!")) && (crate::syntax::lexer::chars::peek_at(l_p1, Nat(1u)) == Text::lit("="))))) {
            l_p1 = crate::syntax::lexer::chars::bump(l_p1);
            sigils_p2 = prism_rtl::cat(sigils_p2, c_p5);
        } else  {
            going_p4 = false;
        }
    }
    this_ = std::tuple{sigils_p2, std::move(caret_p3), l_p1};
    return this_;
}


prism_rtl::Turn<std::tuple<Text, bool, crate::syntax::lexer::Lex>> ReadSigils::cycle() const {
    const auto& l0_p0 = this->l0_p0;
    std::tuple<Text, bool, crate::syntax::lexer::Lex> this_ = std::tuple{Text::lit(""), false, l0_p0};
    crate::syntax::lexer::Lex l_p1 = l0_p0;
    Text sigils_p2 = Text::lit("");
    bool caret_p3 = false;
    bool going_p4 = true;
    return call_then(loop_job(std::tuple{std::move(this_), std::move(caret_p3), std::move(going_p4), std::move(l_p1), std::move(sigils_p2)}, [=](std::tuple<std::tuple<Text, bool, crate::syntax::lexer::Lex>, bool, bool, crate::syntax::lexer::Lex, Text> _p0) {
        auto this_ = std::get<0>(_p0);
        auto caret_p3 = std::get<1>(_p0);
        auto going_p4 = std::get<2>(_p0);
        auto l_p1 = std::get<3>(_p0);
        auto sigils_p2 = std::get<4>(_p0);
        return going_p4
            ? ({
            auto c_p5 = crate::syntax::lexer::chars::peek(l_p1);
            if (c_p5 == Text::lit("^")) {
                l_p1 = crate::syntax::lexer::chars::bump(l_p1);
                caret_p3 = true;
                going_p4 = false;
            } else if (crate::syntax::lexer::chars::is_sigil_char(c_p5) && (!((c_p5 == Text::lit("!")) && (crate::syntax::lexer::chars::peek_at(l_p1, Nat(1u)) == Text::lit("="))))) {
                l_p1 = crate::syntax::lexer::chars::bump(l_p1);
                sigils_p2 = prism_rtl::cat(sigils_p2, c_p5);
            } else  {
                going_p4 = false;
            }
            Expected<std::tuple<std::tuple<Text, bool, crate::syntax::lexer::Lex>, bool, bool, crate::syntax::lexer::Lex, Text>, std::tuple<std::tuple<Text, bool, crate::syntax::lexer::Lex>, bool, bool, crate::syntax::lexer::Lex, Text>>(std::tuple{this_, caret_p3, going_p4, l_p1, sigils_p2});
        })
            : Expected<std::tuple<std::tuple<Text, bool, crate::syntax::lexer::Lex>, bool, bool, crate::syntax::lexer::Lex, Text>, std::tuple<std::tuple<Text, bool, crate::syntax::lexer::Lex>, bool, bool, crate::syntax::lexer::Lex, Text>>(unexpected(std::tuple{this_, caret_p3, going_p4, l_p1, sigils_p2}));
    }), [=](std::tuple<std::tuple<Text, bool, crate::syntax::lexer::Lex>, bool, bool, crate::syntax::lexer::Lex, Text> _p0) {
        auto this_ = std::get<0>(_p0);
        auto caret_p3 = std::get<1>(_p0);
        auto going_p4 = std::get<2>(_p0);
        auto l_p1 = std::get<3>(_p0);
        auto sigils_p2 = std::get<4>(_p0);
        return ({
            this_ = std::tuple{sigils_p2, caret_p3, l_p1};
            (prism_rtl::finished(this_));
        });
    });
}


/// `Start ReadSigils, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Text, bool, crate::syntax::lexer::Lex>> start_read_sigils(crate::syntax::lexer::Lex l0_p0) {
    return prism_rtl::make_rc<ReadSigils>(l0_p0);
}


/// LexCaret: unbounded fn Lex, Nat, Text, Text -> Lex
crate::syntax::lexer::Lex lex_caret(const crate::syntax::lexer::Lex& l_p0, const Nat& start_p1, const Text& sigils_p2, const Text& next_p3) {
    return crate::syntax::lexer::chars::is_upper(next_p3) && (sigils_p2 == Text::lit(""))
        ? ({
        auto [path_p4, l2_p5] = lex_qualified_path(l_p0);
        (crate::syntax::lexer::push_tok(l2_p5, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KTrait{path_p4}), start_p1, prism_rtl::deref(l2_p5).pos));
    })
        : ({
        auto&& _skipped_p7 = lex_qualified_path(l_p0);
        auto&& skipped_p7 = std::get<1>(_skipped_p7);
        auto l2_p6 = crate::syntax::lexer::chars::is_ident_start(next_p3) ? skipped_p7 : l_p0;
        (crate::syntax::lexer::chars::lex_err(l2_p6, start_p1, crate::prelude::max(prism_rtl::deref(l2_p6).pos, l_p0.pos), Text::lit("`^` marks a trait and attaches to its uppercase name: no trait is a value")));
    });
}


prism_rtl::Turn<crate::syntax::lexer::Lex> LexCaret::cycle() const {
    const auto& l_p0 = this->l_p0;
    const auto& start_p1 = this->start_p1;
    const auto& sigils_p2 = this->sigils_p2;
    const auto& next_p3 = this->next_p3;
    return crate::syntax::lexer::chars::is_upper(next_p3) && (sigils_p2 == Text::lit(""))
        ? ({
        auto l_p0_1 = l_p0;
        auto start_p1_2 = start_p1;
        call_then(start_lex_qualified_path(l_p0_1), [=, start_p1_2 = std::move(start_p1_2)](std::tuple<Array<Text>, crate::syntax::lexer::Lex> lex_qualified_path_9909) {
        return ({
            auto [path_p4, l2_p5] = lex_qualified_path_9909;
            (prism_rtl::finished(crate::syntax::lexer::push_tok(l2_p5, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KTrait{path_p4}), start_p1_2, prism_rtl::deref(l2_p5).pos)));
        });
    });
    })
        : ({
        auto l_p0_1 = l_p0;
        auto next_p3_2 = next_p3;
        auto start_p1_3 = start_p1;
        call_then(start_lex_qualified_path(l_p0_1), [=, next_p3_2 = std::move(next_p3_2), start_p1_3 = std::move(start_p1_3)](std::tuple<Array<Text>, crate::syntax::lexer::Lex> lex_qualified_path_10021) {
        return ({
            auto&& _skipped_p7 = lex_qualified_path_10021;
            auto&& skipped_p7 = std::get<1>(_skipped_p7);
            auto l2_p6 = crate::syntax::lexer::chars::is_ident_start(next_p3_2)
                ? skipped_p7
                : l_p0_1;
            (prism_rtl::finished(crate::syntax::lexer::chars::lex_err(l2_p6, start_p1_3, crate::prelude::max(prism_rtl::deref(l2_p6).pos, prism_rtl::deref(l_p0_1).pos), Text::lit("`^` marks a trait and attaches to its uppercase name: no trait is a value"))));
        });
    });
    });
}


/// `Start LexCaret, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_lex_caret(crate::syntax::lexer::Lex l_p0, Nat start_p1, Text sigils_p2, Text next_p3) {
    return prism_rtl::make_rc<LexCaret>(l_p0, start_p1, sigils_p2, next_p3);
}


/// LexAttached: unbounded fn Lex, Nat, Text, Text -> Lex
crate::syntax::lexer::Lex lex_attached(const crate::syntax::lexer::Lex& l_p0, const Nat& start_p1, const Text& sigils_p2, const Text& next_p3) {
    return next_p3 == Text::lit("\"")
        ? ({
        auto [text_p4, l2_p5] = crate::syntax::lexer::literals::lex_text(l_p0);
        (crate::syntax::lexer::push_tok(l2_p5, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KText{sigils_p2, text_p4}), start_p1, prism_rtl::deref(l2_p5).pos));
    })
        : crate::syntax::lexer::chars::is_digit(next_p3)
        ? ({
        auto [kind_p6, l2_p7] = crate::syntax::lexer::literals::lex_number(l_p0, sigils_p2);
        (crate::syntax::lexer::push_tok(l2_p7, kind_p6, start_p1, prism_rtl::deref(l2_p7).pos));
    })
        : next_p3 == Text::lit("%")
        ? crate::syntax::lexer::regexes::lex_regex(l_p0, sigils_p2, start_p1)
        : lex_word_token(l_p0, sigils_p2, start_p1);
}


prism_rtl::Turn<crate::syntax::lexer::Lex> LexAttached::cycle() const {
    const auto& l_p0 = this->l_p0;
    const auto& start_p1 = this->start_p1;
    const auto& sigils_p2 = this->sigils_p2;
    const auto& next_p3 = this->next_p3;
    return next_p3 == Text::lit("\"")
        ? ({
        auto l_p0_1 = l_p0;
        auto sigils_p2_2 = sigils_p2;
        auto start_p1_3 = start_p1;
        call_then(crate::syntax::lexer::literals::start_lex_text(l_p0_1), [=, sigils_p2_2 = std::move(sigils_p2_2), start_p1_3 = std::move(start_p1_3)](std::tuple<Array<crate::syntax::lexer::TextSegTok>, crate::syntax::lexer::Lex> lex_text_10360) {
        return ({
            auto [text_p4, l2_p5] = lex_text_10360;
            (prism_rtl::finished(crate::syntax::lexer::push_tok(l2_p5, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KText{sigils_p2_2, text_p4}), start_p1_3, prism_rtl::deref(l2_p5).pos)));
        });
    });
    })
        : crate::syntax::lexer::chars::is_digit(next_p3)
        ? ({
        auto l_p0_1 = l_p0;
        auto sigils_p2_2 = sigils_p2;
        auto start_p1_3 = start_p1;
        call_then(crate::syntax::lexer::literals::start_lex_number(l_p0_1, sigils_p2_2), [=, start_p1_3 = std::move(start_p1_3)](std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex> lex_number_10480) {
        return ({
            auto [kind_p6, l2_p7] = lex_number_10480;
            (prism_rtl::finished(crate::syntax::lexer::push_tok(l2_p7, kind_p6, start_p1_3, prism_rtl::deref(l2_p7).pos)));
        });
    });
    })
        : next_p3 == Text::lit("%")
        ? prism_rtl::more(prism_rtl::rc(crate::syntax::lexer::regexes::LexRegex(l_p0, sigils_p2, start_p1)))
        : prism_rtl::more(prism_rtl::rc(LexWordToken(l_p0, sigils_p2, start_p1)));
}


/// `Start LexAttached, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_lex_attached(crate::syntax::lexer::Lex l_p0, Nat start_p1, Text sigils_p2, Text next_p3) {
    return prism_rtl::make_rc<LexAttached>(l_p0, start_p1, sigils_p2, next_p3);
}


/// FreeSigils: fn Lex, Nat, Text -> Lex
crate::syntax::lexer::Lex free_sigils(const crate::syntax::lexer::Lex& l0_p0, const Nat& start_p1, const Text& sigils_p2) {
    crate::syntax::lexer::Lex this_ = l0_p0;
    auto space_after_p3 = crate::syntax::lexer::chars::next_is_space(this_, Nat(0u));
    auto all_p6 = crate::syntax::lexer::chars::fold_chars(sigils_p2, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Text>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return once_job([=]() {
            return ({
                auto acc_p4 = p0;
                auto c_p5 = p1;
                (prism_rtl::finished(crate::prelude::push(acc_p4, c_p5)));
            });
        });
    })));
    for (auto&& [i10960, v10960] : prism_rtl::enumerate(all_p6)) {
        auto k10960 = nat_of(i10960);
        auto s_p7 = v10960;
        auto at_p8 = start_p1 + k10960;
        if (std::move(space_after_p3) && ((k10960 + Nat(1u)) == len(all_p6))) {
            if (s_p7 == Text::lit("!")) {
                this_ = crate::syntax::lexer::chars::lex_err(this_, at_p8, at_p8 + Nat(1u), Text::lit("`!` is never free: no event fires a constant (write `!e` touching its name)"));
            }
            if (s_p7 == Text::lit("&")) {
                this_ = crate::syntax::lexer::chars::lex_err(this_, at_p8, at_p8 + Nat(1u), Text::lit("`&` is never free: no reference exists outside the value an `update` block names"));
            }
        }
        this_ = crate::syntax::lexer::push_tok(this_, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KFree{s_p7}), at_p8, at_p8 + Nat(1u));
    }
    return this_;
}


/// LexQualifiedPath: unbounded fn Lex -> (([Text], Lex))
std::tuple<Array<Text>, crate::syntax::lexer::Lex> lex_qualified_path(const crate::syntax::lexer::Lex& l0_p0) {
    std::tuple<Array<Text>, crate::syntax::lexer::Lex> this_ = std::tuple{Array<Text>{}, l0_p0};
    auto [first_p1, l1_p2] = lex_ident(l0_p0);
    Array<Text> path_p3 = Array(std::vector{first_p1});
    crate::syntax::lexer::Lex l_p4 = l1_p2;
    bool going_p5 = true;
    while (std::move(going_p5)) {
        auto last_p6 = or_(crate::syntax::lexer::chars::last(path_p3), Text::lit(""));
        auto next_p7 = crate::syntax::lexer::chars::peek_at(l_p4, Nat(1u));
        if ((crate::syntax::lexer::chars::peek(l_p4) != Text::lit(".")) || (!crate::syntax::lexer::chars::is_upper(crate::syntax::lexer::chars::head(last_p6)))) {
            going_p5 = false;
        } else if (crate::syntax::lexer::chars::is_upper(next_p7)) {
            auto [seg_p8, l2_p9] = lex_ident(crate::syntax::lexer::chars::bump(l_p4));
            path_p3 = crate::prelude::push(path_p3, seg_p8);
            l_p4 = l2_p9;
        } else  {
            going_p5 = false;
            if (crate::syntax::lexer::chars::is_ident_start(next_p7)) {
                auto [w_pa, l2_pb] = lex_ident(crate::syntax::lexer::chars::bump(l_p4));
                if (crate::syntax::lexer::chars::is_reserved_ctor(w_pa)) {
                    path_p3 = crate::prelude::push(path_p3, w_pa);
                    l_p4 = l2_pb;
                }
            }
        }
    }
    this_ = std::tuple{path_p3, l_p4};
    return this_;
}


prism_rtl::Turn<std::tuple<Array<Text>, crate::syntax::lexer::Lex>> LexQualifiedPath::cycle() const {
    const auto& l0_p0 = this->l0_p0;
    std::tuple<Array<Text>, crate::syntax::lexer::Lex> this_ = std::tuple{Array<Text>{}, l0_p0};
    auto [first_p1, l1_p2] = lex_ident(l0_p0);
    Array<Text> path_p3 = Array(std::vector{first_p1});
    crate::syntax::lexer::Lex l_p4 = l1_p2;
    bool going_p5 = true;
    return call_then(loop_job(std::tuple{std::move(this_), std::move(going_p5), std::move(l_p4), std::move(path_p3)}, [=](std::tuple<std::tuple<Array<Text>, crate::syntax::lexer::Lex>, bool, crate::syntax::lexer::Lex, Array<Text>> _p0) {
        auto this_ = std::get<0>(_p0);
        auto going_p5 = std::get<1>(_p0);
        auto l_p4 = std::get<2>(_p0);
        auto path_p3 = std::get<3>(_p0);
        return going_p5
            ? ({
            auto last_p6 = or_(crate::syntax::lexer::chars::last(path_p3), Text::lit(""));
            auto next_p7 = crate::syntax::lexer::chars::peek_at(l_p4, Nat(1u));
            if ((crate::syntax::lexer::chars::peek(l_p4) != Text::lit(".")) || (!crate::syntax::lexer::chars::is_upper(crate::syntax::lexer::chars::head(last_p6)))) {
                going_p5 = false;
            } else if (crate::syntax::lexer::chars::is_upper(next_p7)) {
                auto [seg_p8, l2_p9] = lex_ident(crate::syntax::lexer::chars::bump(l_p4));
                path_p3 = crate::prelude::push(path_p3, seg_p8);
                l_p4 = l2_p9;
            } else  {
                going_p5 = false;
                if (crate::syntax::lexer::chars::is_ident_start(next_p7)) {
                    auto [w_pa, l2_pb] = lex_ident(crate::syntax::lexer::chars::bump(l_p4));
                    if (crate::syntax::lexer::chars::is_reserved_ctor(w_pa)) {
                        path_p3 = crate::prelude::push(path_p3, w_pa);
                        l_p4 = l2_pb;
                    }
                }
            }
            Expected<std::tuple<std::tuple<Array<Text>, crate::syntax::lexer::Lex>, bool, crate::syntax::lexer::Lex, Array<Text>>, std::tuple<std::tuple<Array<Text>, crate::syntax::lexer::Lex>, bool, crate::syntax::lexer::Lex, Array<Text>>>(std::tuple{this_, going_p5, l_p4, path_p3});
        })
            : Expected<std::tuple<std::tuple<Array<Text>, crate::syntax::lexer::Lex>, bool, crate::syntax::lexer::Lex, Array<Text>>, std::tuple<std::tuple<Array<Text>, crate::syntax::lexer::Lex>, bool, crate::syntax::lexer::Lex, Array<Text>>>(unexpected(std::tuple{this_, going_p5, l_p4, path_p3}));
    }), [=](std::tuple<std::tuple<Array<Text>, crate::syntax::lexer::Lex>, bool, crate::syntax::lexer::Lex, Array<Text>> _p0) {
        auto this_ = std::get<0>(_p0);
        auto going_p5 = std::get<1>(_p0);
        auto l_p4 = std::get<2>(_p0);
        auto path_p3 = std::get<3>(_p0);
        return ({
            this_ = std::tuple{path_p3, l_p4};
            (prism_rtl::finished(this_));
        });
    });
}


/// `Start LexQualifiedPath, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<Text>, crate::syntax::lexer::Lex>> start_lex_qualified_path(crate::syntax::lexer::Lex l0_p0) {
    return prism_rtl::make_rc<LexQualifiedPath>(l0_p0);
}


/// LexIdent: unbounded fn Lex -> ((Text, Lex))
std::tuple<Text, crate::syntax::lexer::Lex> lex_ident(const crate::syntax::lexer::Lex& l0_p0) {
    auto word_p1 = crate::syntax::lexer::chars::match_here(([]() -> const Regex& { static const Regex r = Regex::lit("[A-Za-z0-9_]*", ""); return r; }()), l0_p0);
    auto l_p2 = ({
        crate::syntax::lexer::Lex this_ = l0_p0;
        this_.pos = this_.pos + len_text(word_p1);
        (std::move(this_));
    });
    return std::tuple{word_p1, l_p2};
}


prism_rtl::Turn<std::tuple<Text, crate::syntax::lexer::Lex>> LexIdent::cycle() const {
    const auto& l0_p0 = this->l0_p0;
    auto word_p1 = crate::syntax::lexer::chars::match_here(([]() -> const Regex& { static const Regex r = Regex::lit("[A-Za-z0-9_]*", ""); return r; }()), l0_p0);
    auto l_p2 = ({
        crate::syntax::lexer::Lex this_ = l0_p0;
        this_.pos = this_.pos + len_text(word_p1);
        (std::move(this_));
    });
    return prism_rtl::finished(std::tuple{word_p1, l_p2});
}


/// `Start LexIdent, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Text, crate::syntax::lexer::Lex>> start_lex_ident(crate::syntax::lexer::Lex l0_p0) {
    return prism_rtl::make_rc<LexIdent>(l0_p0);
}


/// LexWordToken: unbounded fn Lex, Text, Nat -> Lex
crate::syntax::lexer::Lex lex_word_token(const crate::syntax::lexer::Lex& l0_p0, const Text& sigils_p1, const Nat& start_p2) {
    auto w_start_p3 = l0_p0.pos;
    auto [path_p6, l1_p7] = lex_qualified_path(l0_p0);
    auto l_p4 = crate::syntax::lexer::chars::is_non_ascii(crate::syntax::lexer::chars::peek(l1_p7))
        ? skip_non_ascii(l1_p7, w_start_p3)
        : l1_p7;
    auto first_p5 = or_(index(path_p6, Nat(0u)), Text::lit(""));
    return crate::syntax::lexer::chars::starts_with(l_p4, Text::lit(".*")) && crate::syntax::lexer::chars::is_upper(crate::syntax::lexer::chars::head(first_p5))
        ? ({
        auto l2_p8 = crate::syntax::lexer::chars::forward(l_p4, Nat(2u));
        auto l3_p9 = sigils_p1 != Text::lit("")
            ? crate::syntax::lexer::chars::lex_err(l2_p8, start_p2, prism_rtl::deref(l2_p8).pos, Text::lit("a family pattern takes no sigil"))
            : l2_p8;
        (crate::syntax::lexer::push_tok(l3_p9, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KFamily{path_p6}), start_p2, prism_rtl::deref(l3_p9).pos));
    })
        : ((len(path_p6) == Nat(1u)) && crate::syntax::lexer::is_keyword(first_p5)) && (!(crate::syntax::lexer::is_bound_word(first_p5) && (sigils_p1 != Text::lit(""))))
        ? lex_keyword(l_p4, first_p5, sigils_p1, start_p2)
        : lex_name(l_p4, path_p6, sigils_p1, start_p2, w_start_p3);
}


prism_rtl::Turn<crate::syntax::lexer::Lex> LexWordToken::cycle() const {
    const auto& l0_p0 = this->l0_p0;
    const auto& sigils_p1 = this->sigils_p1;
    const auto& start_p2 = this->start_p2;
    auto w_start_p3 = prism_rtl::deref(l0_p0).pos;
    auto l0_p0_1 = l0_p0;
    auto sigils_p1_2 = sigils_p1;
    auto start_p2_3 = start_p2;
    return call_then(start_lex_qualified_path(l0_p0_1), [=](std::tuple<Array<Text>, crate::syntax::lexer::Lex> lex_qualified_path_12808) {
        return ({
            auto [path_p6, l1_p7] = lex_qualified_path_12808;
            auto l_p4 = crate::syntax::lexer::chars::is_non_ascii(crate::syntax::lexer::chars::peek(l1_p7))
                ? skip_non_ascii(l1_p7, w_start_p3)
                : l1_p7;
            auto first_p5 = or_(index(path_p6, Nat(0u)), Text::lit(""));
            (crate::syntax::lexer::chars::starts_with(l_p4, Text::lit(".*")) && crate::syntax::lexer::chars::is_upper(crate::syntax::lexer::chars::head(first_p5))
            ? ({
            auto l2_p8 = crate::syntax::lexer::chars::forward(l_p4, Nat(2u));
            auto l3_p9 = sigils_p1_2 != Text::lit("")
                ? crate::syntax::lexer::chars::lex_err(l2_p8, start_p2_3, prism_rtl::deref(l2_p8).pos, Text::lit("a family pattern takes no sigil"))
                : l2_p8;
            (prism_rtl::finished(crate::syntax::lexer::push_tok(l3_p9, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KFamily{path_p6}), start_p2_3, prism_rtl::deref(l3_p9).pos)));
        })
            : ((len(path_p6) == Nat(1u)) && crate::syntax::lexer::is_keyword(first_p5)) && (!(crate::syntax::lexer::is_bound_word(first_p5) && (sigils_p1_2 != Text::lit(""))))
            ? prism_rtl::more(prism_rtl::rc(LexKeyword(l_p4, first_p5, sigils_p1_2, start_p2_3)))
            : prism_rtl::more(prism_rtl::rc(LexName(l_p4, path_p6, sigils_p1_2, start_p2_3, w_start_p3))));
        });
    });
}


/// `Start LexWordToken, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_lex_word_token(crate::syntax::lexer::Lex l0_p0, Text sigils_p1, Nat start_p2) {
    return prism_rtl::make_rc<LexWordToken>(l0_p0, sigils_p1, start_p2);
}


/// SkipNonAscii: unbounded fn Lex, Nat -> Lex
crate::syntax::lexer::Lex skip_non_ascii(const crate::syntax::lexer::Lex& l0_p0, const Nat& w_start_p1) {
    auto l_p2 = ({
        crate::syntax::lexer::Lex this_ = l0_p0;
        this_.pos = crate::syntax::lexer::chars::match_end(([]() -> const Regex& { static const Regex r = Regex::lit("[A-Za-z0-9_\\x{80}-\\x{10FFFF}]*", ""); return r; }()), this_.src, this_.pos);
        (std::move(this_));
    });
    return crate::syntax::lexer::chars::lex_err(l_p2, w_start_p1, prism_rtl::deref(l_p2).pos, Text::lit("names are ASCII letters, digits and underscores"));
}


prism_rtl::Turn<crate::syntax::lexer::Lex> SkipNonAscii::cycle() const {
    const auto& l0_p0 = this->l0_p0;
    const auto& w_start_p1 = this->w_start_p1;
    auto l_p2 = ({
        crate::syntax::lexer::Lex this_ = l0_p0;
        this_.pos = crate::syntax::lexer::chars::match_end(([]() -> const Regex& { static const Regex r = Regex::lit("[A-Za-z0-9_\\x{80}-\\x{10FFFF}]*", ""); return r; }()), this_.src, this_.pos);
        (std::move(this_));
    });
    return prism_rtl::finished(crate::syntax::lexer::chars::lex_err(l_p2, w_start_p1, prism_rtl::deref(l_p2).pos, Text::lit("names are ASCII letters, digits and underscores")));
}


/// `Start SkipNonAscii, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_skip_non_ascii(crate::syntax::lexer::Lex l0_p0, Nat w_start_p1) {
    return prism_rtl::make_rc<SkipNonAscii>(l0_p0, w_start_p1);
}


/// LexKeyword: unbounded fn Lex, Text, Text, Nat -> Lex
crate::syntax::lexer::Lex lex_keyword(const crate::syntax::lexer::Lex& l_p0, const Text& w_p1, const Text& sigils_p2, const Nat& start_p3) {
    auto l1_p4 = (sigils_p2 != Text::lit("")) && (!(((w_p1 == Text::lit("widget")) || (w_p1 == Text::lit("unit"))) || (w_p1 == Text::lit("nil"))))
        ? crate::syntax::lexer::chars::lex_err(l_p0, start_p3, l_p0.pos, prism_rtl::cat("`", w_p1, "` is a keyword and takes no sigil"))
        : l_p0;
    auto l2_p5 = (w_p1 == Text::lit("widget")) && (sigils_p2 != Text::lit("@"))
        ? crate::syntax::lexer::chars::lex_err(l1_p4, start_p3, prism_rtl::deref(l1_p4).pos, Text::lit("`widget` is a block only as `@widget:`"))
        : l1_p4;
    auto l3_p6 = crate::syntax::lexer::push_tok(l2_p5, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KKw{w_p1, sigils_p2}), start_p3, prism_rtl::deref(l2_p5).pos);
    return ((w_p1 == Text::lit("output")) || (w_p1 == Text::lit("inline_text"))) || (w_p1 == Text::lit("raw"))
        ? crate::syntax::lexer::templates::maybe_template(l3_p6, w_p1)
        : l3_p6;
}


prism_rtl::Turn<crate::syntax::lexer::Lex> LexKeyword::cycle() const {
    const auto& l_p0 = this->l_p0;
    const auto& w_p1 = this->w_p1;
    const auto& sigils_p2 = this->sigils_p2;
    const auto& start_p3 = this->start_p3;
    auto l1_p4 = (sigils_p2 != Text::lit("")) && (!(((w_p1 == Text::lit("widget")) || (w_p1 == Text::lit("unit"))) || (w_p1 == Text::lit("nil"))))
        ? crate::syntax::lexer::chars::lex_err(l_p0, start_p3, prism_rtl::deref(l_p0).pos, prism_rtl::cat("`", w_p1, "` is a keyword and takes no sigil"))
        : l_p0;
    auto l2_p5 = (w_p1 == Text::lit("widget")) && (sigils_p2 != Text::lit("@"))
        ? crate::syntax::lexer::chars::lex_err(l1_p4, start_p3, prism_rtl::deref(l1_p4).pos, Text::lit("`widget` is a block only as `@widget:`"))
        : l1_p4;
    auto l3_p6 = crate::syntax::lexer::push_tok(l2_p5, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KKw{w_p1, sigils_p2}), start_p3, prism_rtl::deref(l2_p5).pos);
    return ((w_p1 == Text::lit("output")) || (w_p1 == Text::lit("inline_text"))) || (w_p1 == Text::lit("raw"))
        ? prism_rtl::more(prism_rtl::rc(crate::syntax::lexer::templates::MaybeTemplate(l3_p6, w_p1)))
        : prism_rtl::finished(l3_p6);
}


/// `Start LexKeyword, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_lex_keyword(crate::syntax::lexer::Lex l_p0, Text w_p1, Text sigils_p2, Nat start_p3) {
    return prism_rtl::make_rc<LexKeyword>(l_p0, w_p1, sigils_p2, start_p3);
}


/// LexName: unbounded fn Lex, [Text], Text, Nat, Nat -> Lex
crate::syntax::lexer::Lex lex_name(const crate::syntax::lexer::Lex& l_p0, const Array<Text>& path_p1, const Text& sigils_p2, const Nat& start_p3, const Nat& w_start_p4) {
    auto [case_p6, l1_p7] = name_case_of(l_p0, path_p1, w_start_p4);
    auto l2_p5 = is_path_word(l1_p7, sigils_p2, path_p1)
        ? ({
        crate::syntax::lexer::Lex this_ = l1_p7;
        this_.path_next = true;
        (std::move(this_));
    })
        : l1_p7;
    return crate::syntax::lexer::push_tok(l2_p5, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KName{crate::syntax::lexer::NameTok{.sigils = sigils_p2, .path_ = path_p1, .case_ = case_p6}}), start_p3, prism_rtl::deref(l2_p5).pos);
}


prism_rtl::Turn<crate::syntax::lexer::Lex> LexName::cycle() const {
    const auto& l_p0 = this->l_p0;
    const auto& path_p1 = this->path_p1;
    const auto& sigils_p2 = this->sigils_p2;
    const auto& start_p3 = this->start_p3;
    const auto& w_start_p4 = this->w_start_p4;
    auto [case_p6, l1_p7] = name_case_of(l_p0, path_p1, w_start_p4);
    auto l2_p5 = is_path_word(l1_p7, sigils_p2, path_p1)
        ? ({
        crate::syntax::lexer::Lex this_ = l1_p7;
        this_.path_next = true;
        (std::move(this_));
    })
        : l1_p7;
    return prism_rtl::finished(crate::syntax::lexer::push_tok(l2_p5, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KName{crate::syntax::lexer::NameTok{.sigils = sigils_p2, .path_ = path_p1, .case_ = case_p6}}), start_p3, prism_rtl::deref(l2_p5).pos));
}


/// `Start LexName, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_lex_name(crate::syntax::lexer::Lex l_p0, Array<Text> path_p1, Text sigils_p2, Nat start_p3, Nat w_start_p4) {
    return prism_rtl::make_rc<LexName>(l_p0, path_p1, sigils_p2, start_p3, w_start_p4);
}


/// NameCaseOf: fn Lex, [Text], Nat -> ((NameCase, Lex))
std::tuple<crate::syntax::lexer::NameCase, crate::syntax::lexer::Lex> name_case_of(const crate::syntax::lexer::Lex& l_p0, const Array<Text>& path_p1, const Nat& w_start_p2) {
    auto last_p3 = or_(crate::syntax::lexer::chars::last(path_p1), Text::lit(""));
    return last_p3 == Text::lit("_")
        ? std::tuple{crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseTopic{}), l_p0}
        : (crate::syntax::lexer::chars::head(last_p3) == Text::lit("_")) && crate::syntax::lexer::chars::all_chars(crate::syntax::lexer::chars::after_first(last_p3), ({
        auto f = prism_rtl::rc(crate::syntax::lexer::chars::is_digit);
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>>(prism_rtl::rc([=, f = std::move(f)](Text a0) {
        return ({
            auto f_1 = f;
            once_job([=, f_1 = std::move(f_1)]() { return prism_rtl::finished(f_1(a0)); });
        });
    })));
    }))
        ? std::tuple{crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseHole{}), l_p0}
        : crate::syntax::lexer::chars::head(last_p3) == Text::lit("_")
        ? std::tuple{crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseLower{}), crate::syntax::lexer::chars::lex_err(l_p0, w_start_p2, l_p0.pos, Text::lit("`_` followed by a letter is not a name: `_` alone is the topic, `_1` a hole"))}
        : crate::syntax::lexer::chars::is_reserved_ctor(last_p3)
        ? std::tuple{crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseReserved{}), l_p0}
        : crate::syntax::lexer::chars::is_upper(crate::syntax::lexer::chars::head(last_p3))
        ? ({
        auto underscored_p4 = fold(path_p1, false, [&](const bool& seen_p5, const Text& seg_p6) { return prism_rtl::deref(seen_p5) || crate::syntax::lexer::chars::contains(seg_p6, Text::lit("_")); });
        std::move(underscored_p4)
        ? std::tuple{crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseUpper{}), crate::syntax::lexer::chars::lex_err(l_p0, w_start_p2, l_p0.pos, prism_rtl::cat("`", crate::syntax::lexer::chars::join(path_p1, Text::lit(".")), "`: a capital promises UpperCamelCase"))}
        : std::tuple{crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseUpper{}), l_p0};
    })
        : std::tuple{crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseLower{}), l_p0};
}


/// IsPathWord: fn Lex, Text, [Text] -> Bool
bool is_path_word(const crate::syntax::lexer::Lex& l_p0, const Text& sigils_p1, const Array<Text>& path_p2) {
    auto w_p3 = or_(index(path_p2, Nat(0u)), Text::lit(""));
    auto words_p4 = w_p3 == Text::lit("at")
        ? Array(std::vector{Text::lit("send"), Text::lit("click"), Text::lit("answer")})
        : Array(std::vector{Text::lit("click")});
    auto prev_p5 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = crate::syntax::lexer::chars::last(l_p0.tokens);
        if (prism_rtl::is_some(_m)) {
            auto&& t_p6 = prism_rtl::some_of(_m);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                auto&& _m = prism_rtl::deref(t_p6).kind;
                if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m)) {
                    auto&& n_p7 = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
                    if ((prism_rtl::deref(n_p7).sigils == Text::lit("")) && (len(n_p7->path_) == Nat(1u))) {
                        _v.set(or_(index(n_p7->path_, Nat(0u)), Text::lit("")));
                        goto _done;
                    }
                }
                {
                    _v.set(Text::lit(""));
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return ((((l_p0.test_depth != std::optional<Nat>{}) && (sigils_p1 == Text::lit(""))) && (len(path_p2) == Nat(1u))) && ((w_p3 == Text::lit("at")) || (w_p3 == Text::lit("element")))) && fold(words_p4, false, [&](const bool& seen_p8, const Text& x_p9) { return prism_rtl::deref(seen_p8) || (x_p9 == prev_p5); });
}

}  // namespace crate::syntax::lexer::words
