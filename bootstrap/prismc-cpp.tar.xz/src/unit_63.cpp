// The modules `Syntax`, `Syntax.Decls`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>

// The module `Syntax`, from `target/bootstrap/cpp-src/prismc/syntax/mod.prism`.
namespace crate::syntax {

void Arg::show(Printer& p) const {
    p.record("Arg", {{"name", name_o}, {"value", value_p}, {"span", span_p}});
}

Pod Arg::to_pod() const {
    return Pod::record("Arg", {{"name", prism_rtl::to_pod(name_o)}, {"value", prism_rtl::to_pod(value_p)}, {"span", prism_rtl::to_pod(span_p)}});
}

Result<Arg> Arg::from_pod(const Pod& whole) {
    return Arg{.name_o = TRY(prism_rtl::from_pod<std::optional<Ident>>(TRY(crate::prelude::field(whole, "name")))), .value_p = TRY(prism_rtl::from_pod<Expr>(TRY(crate::prelude::field(whole, "value")))), .span_p = TRY(prism_rtl::from_pod<Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void Arm::show(Printer& p) const {
    p.record("Arm", {{"pattern", pattern_o}, {"guard", guard_o}, {"body", body_p}, {"span", span_p}});
}

Pod Arm::to_pod() const {
    return Pod::record("Arm", {{"pattern", prism_rtl::to_pod(pattern_o)}, {"guard", prism_rtl::to_pod(guard_o)}, {"body", prism_rtl::to_pod(body_p)}, {"span", prism_rtl::to_pod(span_p)}});
}

Result<Arm> Arm::from_pod(const Pod& whole) {
    return Arm{.pattern_o = TRY(prism_rtl::from_pod<std::optional<Pattern_>>(TRY(crate::prelude::field(whole, "pattern")))), .guard_o = TRY(prism_rtl::from_pod<std::optional<Expr>>(TRY(crate::prelude::field(whole, "guard")))), .body_p = TRY(prism_rtl::from_pod<Block>(TRY(crate::prelude::field(whole, "body")))), .span_p = TRY(prism_rtl::from_pod<Range>(TRY(crate::prelude::field(whole, "span"))))};
}


bool Block::operator==(const Block& o) const { return stmts_p == o.stmts_p && inline_p == o.inline_p && span_p == o.span_p; }

void Block::show(Printer& p) const {
    p.record("Block", {{"stmts", stmts_p}, {"inline", inline_p}, {"span", span_p}});
}

Pod Block::to_pod() const {
    return Pod::record("Block", {{"stmts", prism_rtl::to_pod(stmts_p)}, {"inline", prism_rtl::to_pod(inline_p)}, {"span", prism_rtl::to_pod(span_p)}});
}

Result<Block> Block::from_pod(const Pod& whole) {
    return Block{.stmts_p = TRY(prism_rtl::from_pod<Array<Stmt>>(TRY(crate::prelude::field(whole, "stmts")))), .inline_p = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "inline")))), .span_p = TRY(prism_rtl::from_pod<Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void Color::show(Printer& p) const {
    if (auto c = std::get_if<Bounded>(&cases())) p.choice("Bounded", {});
    else if (auto c = std::get_if<Unbounded>(&cases())) p.choice("Unbounded", {});
    else if (auto c = std::get_if<ColorVar>(&cases())) p.choice("ColorVar", {c->a0});
}

Pod Color::to_pod() const {
    return std::holds_alternative<Bounded>(cases()) ? Pod::choice("Bounded", {})
        : std::holds_alternative<Unbounded>(cases()) ? Pod::choice("Unbounded", {})
        : std::holds_alternative<ColorVar>(cases()) ? Pod::choice("ColorVar", {prism_rtl::to_pod(std::get<ColorVar>(cases()).a0)})
        : Pod();
}

Result<Color> Color::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "Bounded" && c->args.size() == 0) return Color(Bounded{});
        if (c->ctor == "Unbounded" && c->args.size() == 0) return Color(Unbounded{});
        if (c->ctor == "ColorVar" && c->args.size() == 1) return Color(ColorVar{TRY(prism_rtl::from_pod<Ident>(c->args[0]))});
    }
    return mismatch<Color>("a Color", p);
}


bool Cond::CondExpr::operator==(const CondExpr& o) const { return a0 == o.a0; }

bool Cond::CondBind::operator==(const CondBind& o) const { return a0 == o.a0 && a1 == o.a1 && a2 == o.a2; }

void Cond::show(Printer& p) const {
    if (auto c = std::get_if<CondExpr>(&cases())) p.choice("CondExpr", {c->a0});
    else if (auto c = std::get_if<CondBind>(&cases())) p.choice("CondBind", {c->a0, c->a1, c->a2});
}

Pod Cond::to_pod() const {
    return std::holds_alternative<CondExpr>(cases()) ? Pod::choice("CondExpr", {prism_rtl::to_pod(std::get<CondExpr>(cases()).a0)})
        : std::holds_alternative<CondBind>(cases()) ? Pod::choice("CondBind", {prism_rtl::to_pod(std::get<CondBind>(cases()).a0), prism_rtl::to_pod(std::get<CondBind>(cases()).a1), prism_rtl::to_pod(std::get<CondBind>(cases()).a2)})
        : Pod();
}

Result<Cond> Cond::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "CondExpr" && c->args.size() == 1) return Cond(CondExpr{TRY(prism_rtl::from_pod<prism_rtl::Rc<const Expr>>(c->args[0]))});
        if (c->ctor == "CondBind" && c->args.size() == 3) return Cond(CondBind{TRY(prism_rtl::from_pod<Pattern_>(c->args[0])), TRY(prism_rtl::from_pod<prism_rtl::Rc<const Expr>>(c->args[1])), TRY(prism_rtl::from_pod<prism_rtl::Rc<const std::optional<Expr>>>(c->args[2]))});
    }
    return mismatch<Cond>("a Cond", p);
}


void Diag::show(Printer& p) const {
    p.record("Diag", {{"stage", stage_p}, {"span", span_p}, {"message", message_p}, {"feature", feature_o}});
}

Pod Diag::to_pod() const {
    return Pod::record("Diag", {{"stage", prism_rtl::to_pod(stage_p)}, {"span", prism_rtl::to_pod(span_p)}, {"message", prism_rtl::to_pod(message_p)}, {"feature", prism_rtl::to_pod(feature_o)}});
}

Result<Diag> Diag::from_pod(const Pod& whole) {
    return Diag{.stage_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "stage")))), .span_p = TRY(prism_rtl::from_pod<Range>(TRY(crate::prelude::field(whole, "span")))), .message_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "message")))), .feature_o = TRY(prism_rtl::from_pod<std::optional<Text>>(TRY(crate::prelude::field(whole, "feature"))))};
}


bool Expr::operator==(const Expr& o) const { return kind_p == o.kind_p && span_p == o.span_p; }

void Expr::show(Printer& p) const {
    p.record("Expr", {{"kind", kind_p}, {"span", span_p}});
}

Pod Expr::to_pod() const {
    return Pod::record("Expr", {{"kind", prism_rtl::to_pod(kind_p)}, {"span", prism_rtl::to_pod(span_p)}});
}

Result<Expr> Expr::from_pod(const Pod& whole) {
    return Expr{.kind_p = TRY(prism_rtl::from_pod<prism_rtl::Rc<const ExprKind>>(TRY(crate::prelude::field(whole, "kind")))), .span_p = TRY(prism_rtl::from_pod<Range>(TRY(crate::prelude::field(whole, "span"))))};
}


bool ExprKind::ETuple::operator==(const ETuple& o) const { return a0 == o.a0; }

bool ExprKind::EArray::operator==(const EArray& o) const { return a0 == o.a0; }

bool ExprKind::EMap::operator==(const EMap& o) const { return a0 == o.a0; }

bool ExprKind::EGroup::operator==(const EGroup& o) const { return a0 == o.a0; }

bool ExprKind::ECall::operator==(const ECall& o) const { return a0 == o.a0 && a1 == o.a1 && a2 == o.a2 && a3 == o.a3; }

bool ExprKind::EBinary::operator==(const EBinary& o) const { return a0 == o.a0 && a1 == o.a1 && a2 == o.a2; }

bool ExprKind::EUnary::operator==(const EUnary& o) const { return a0 == o.a0 && a1 == o.a1; }

bool ExprKind::ESuffixed::operator==(const ESuffixed& o) const { return a0 == o.a0 && a1 == o.a1 && a2 == o.a2 && a3 == o.a3; }

bool ExprKind::EFreeSigil::operator==(const EFreeSigil& o) const { return a0 == o.a0 && a1 == o.a1; }

bool ExprKind::EField::operator==(const EField& o) const { return a0 == o.a0 && a1 == o.a1 && a2 == o.a2; }

bool ExprKind::EIndex::operator==(const EIndex& o) const { return a0 == o.a0 && a1 == o.a1; }

bool ExprKind::ETopicIndex::operator==(const ETopicIndex& o) const { return a0 == o.a0; }

bool ExprKind::EMethod::operator==(const EMethod& o) const { return a0 == o.a0 && a1 == o.a1 && a2 == o.a2; }

bool ExprKind::ETypeArgs::operator==(const ETypeArgs& o) const { return a0 == o.a0 && a1 == o.a1; }

bool ExprKind::ECast::operator==(const ECast& o) const { return a0 == o.a0 && a1 == o.a1 && a2 == o.a2; }

bool ExprKind::ENonEmpty::operator==(const ENonEmpty& o) const { return a0 == o.a0; }

bool ExprKind::ELambda::operator==(const ELambda& o) const { return a0 == o.a0 && a1 == o.a1; }

bool ExprKind::EIf::operator==(const EIf& o) const { return a0 == o.a0 && a1 == o.a1 && a2 == o.a2; }

bool ExprKind::EMatch::operator==(const EMatch& o) const { return a0 == o.a0 && a1 == o.a1; }

bool ExprKind::ERebuild::operator==(const ERebuild& o) const { return a0 == o.a0 && a1 == o.a1; }

bool ExprKind::EFor::operator==(const EFor& o) const { return a0 == o.a0 && a1 == o.a1 && a2 == o.a2; }

bool ExprKind::EUpdate::operator==(const EUpdate& o) const { return a0 == o.a0 && a1 == o.a1; }

bool ExprKind::EMonad::operator==(const EMonad& o) const { return a0 == o.a0 && a1 == o.a1; }

bool ExprKind::EAny::operator==(const EAny& o) const { return a0 == o.a0; }

bool ExprKind::ELens::operator==(const ELens& o) const { return a0 == o.a0; }

void ExprKind::show(Printer& p) const {
    if (auto c = std::get_if<EName>(&cases())) p.choice("EName", {c->a0});
    else if (auto c = std::get_if<ELit>(&cases())) p.choice("ELit", {c->a0});
    else if (auto c = std::get_if<EUnit>(&cases())) p.choice("EUnit", {c->a0});
    else if (auto c = std::get_if<ENil>(&cases())) p.choice("ENil", {c->a0});
    else if (auto c = std::get_if<EBound>(&cases())) p.choice("EBound", {c->a0});
    else if (auto c = std::get_if<ETuple>(&cases())) p.choice("ETuple", {c->a0});
    else if (auto c = std::get_if<EArray>(&cases())) p.choice("EArray", {c->a0});
    else if (auto c = std::get_if<EMap>(&cases())) p.choice("EMap", {c->a0});
    else if (auto c = std::get_if<EGroup>(&cases())) p.choice("EGroup", {c->a0});
    else if (auto c = std::get_if<ECall>(&cases())) p.choice("ECall", {c->a0, c->a1, c->a2, c->a3});
    else if (auto c = std::get_if<EBinary>(&cases())) p.choice("EBinary", {c->a0, c->a1, c->a2});
    else if (auto c = std::get_if<EUnary>(&cases())) p.choice("EUnary", {c->a0, c->a1});
    else if (auto c = std::get_if<ESuffixed>(&cases())) p.choice("ESuffixed", {c->a0, c->a1, c->a2, c->a3});
    else if (auto c = std::get_if<EFreeSigil>(&cases())) p.choice("EFreeSigil", {c->a0, c->a1});
    else if (auto c = std::get_if<EField>(&cases())) p.choice("EField", {c->a0, c->a1, c->a2});
    else if (auto c = std::get_if<EIndex>(&cases())) p.choice("EIndex", {c->a0, c->a1});
    else if (auto c = std::get_if<ETopicField>(&cases())) p.choice("ETopicField", {c->a0});
    else if (auto c = std::get_if<ETopicIndex>(&cases())) p.choice("ETopicIndex", {c->a0});
    else if (auto c = std::get_if<EMethod>(&cases())) p.choice("EMethod", {c->a0, c->a1, c->a2});
    else if (auto c = std::get_if<ETypeArgs>(&cases())) p.choice("ETypeArgs", {c->a0, c->a1});
    else if (auto c = std::get_if<ECast>(&cases())) p.choice("ECast", {c->a0, c->a1, c->a2});
    else if (auto c = std::get_if<ENonEmpty>(&cases())) p.choice("ENonEmpty", {c->a0});
    else if (auto c = std::get_if<EAbsent>(&cases())) p.choice("EAbsent", {});
    else if (auto c = std::get_if<ERest>(&cases())) p.choice("ERest", {});
    else if (auto c = std::get_if<ELambda>(&cases())) p.choice("ELambda", {c->a0, c->a1});
    else if (auto c = std::get_if<EIf>(&cases())) p.choice("EIf", {c->a0, c->a1, c->a2});
    else if (auto c = std::get_if<EMatch>(&cases())) p.choice("EMatch", {c->a0, c->a1});
    else if (auto c = std::get_if<ERebuild>(&cases())) p.choice("ERebuild", {c->a0, c->a1});
    else if (auto c = std::get_if<EFor>(&cases())) p.choice("EFor", {c->a0, c->a1, c->a2});
    else if (auto c = std::get_if<EGiven>(&cases())) p.choice("EGiven", {c->a0});
    else if (auto c = std::get_if<EUpdate>(&cases())) p.choice("EUpdate", {c->a0, c->a1});
    else if (auto c = std::get_if<EWidgetBlock>(&cases())) p.choice("EWidgetBlock", {c->a0});
    else if (auto c = std::get_if<EMonad>(&cases())) p.choice("EMonad", {c->a0, c->a1});
    else if (auto c = std::get_if<ETemplate>(&cases())) p.choice("ETemplate", {c->a0});
    else if (auto c = std::get_if<EAny>(&cases())) p.choice("EAny", {c->a0});
    else if (auto c = std::get_if<ELens>(&cases())) p.choice("ELens", {c->a0});
    else if (auto c = std::get_if<EError>(&cases())) p.choice("EError", {});
}

Pod ExprKind::to_pod() const {
    return std::holds_alternative<EName>(cases()) ? Pod::choice("EName", {prism_rtl::to_pod(std::get<EName>(cases()).a0)})
        : std::holds_alternative<ELit>(cases()) ? Pod::choice("ELit", {prism_rtl::to_pod(std::get<ELit>(cases()).a0)})
        : std::holds_alternative<EUnit>(cases()) ? Pod::choice("EUnit", {prism_rtl::to_pod(std::get<EUnit>(cases()).a0)})
        : std::holds_alternative<ENil>(cases()) ? Pod::choice("ENil", {prism_rtl::to_pod(std::get<ENil>(cases()).a0)})
        : std::holds_alternative<EBound>(cases()) ? Pod::choice("EBound", {prism_rtl::to_pod(std::get<EBound>(cases()).a0)})
        : std::holds_alternative<ETuple>(cases()) ? Pod::choice("ETuple", {prism_rtl::to_pod(std::get<ETuple>(cases()).a0)})
        : std::holds_alternative<EArray>(cases()) ? Pod::choice("EArray", {prism_rtl::to_pod(std::get<EArray>(cases()).a0)})
        : std::holds_alternative<EMap>(cases()) ? Pod::choice("EMap", {prism_rtl::to_pod(std::get<EMap>(cases()).a0)})
        : std::holds_alternative<EGroup>(cases()) ? Pod::choice("EGroup", {prism_rtl::to_pod(std::get<EGroup>(cases()).a0)})
        : std::holds_alternative<ECall>(cases()) ? Pod::choice("ECall", {prism_rtl::to_pod(std::get<ECall>(cases()).a0), prism_rtl::to_pod(std::get<ECall>(cases()).a1), prism_rtl::to_pod(std::get<ECall>(cases()).a2), prism_rtl::to_pod(std::get<ECall>(cases()).a3)})
        : std::holds_alternative<EBinary>(cases()) ? Pod::choice("EBinary", {prism_rtl::to_pod(std::get<EBinary>(cases()).a0), prism_rtl::to_pod(std::get<EBinary>(cases()).a1), prism_rtl::to_pod(std::get<EBinary>(cases()).a2)})
        : std::holds_alternative<EUnary>(cases()) ? Pod::choice("EUnary", {prism_rtl::to_pod(std::get<EUnary>(cases()).a0), prism_rtl::to_pod(std::get<EUnary>(cases()).a1)})
        : std::holds_alternative<ESuffixed>(cases()) ? Pod::choice("ESuffixed", {prism_rtl::to_pod(std::get<ESuffixed>(cases()).a0), prism_rtl::to_pod(std::get<ESuffixed>(cases()).a1), prism_rtl::to_pod(std::get<ESuffixed>(cases()).a2), prism_rtl::to_pod(std::get<ESuffixed>(cases()).a3)})
        : std::holds_alternative<EFreeSigil>(cases()) ? Pod::choice("EFreeSigil", {prism_rtl::to_pod(std::get<EFreeSigil>(cases()).a0), prism_rtl::to_pod(std::get<EFreeSigil>(cases()).a1)})
        : std::holds_alternative<EField>(cases()) ? Pod::choice("EField", {prism_rtl::to_pod(std::get<EField>(cases()).a0), prism_rtl::to_pod(std::get<EField>(cases()).a1), prism_rtl::to_pod(std::get<EField>(cases()).a2)})
        : std::holds_alternative<EIndex>(cases()) ? Pod::choice("EIndex", {prism_rtl::to_pod(std::get<EIndex>(cases()).a0), prism_rtl::to_pod(std::get<EIndex>(cases()).a1)})
        : std::holds_alternative<ETopicField>(cases()) ? Pod::choice("ETopicField", {prism_rtl::to_pod(std::get<ETopicField>(cases()).a0)})
        : std::holds_alternative<ETopicIndex>(cases()) ? Pod::choice("ETopicIndex", {prism_rtl::to_pod(std::get<ETopicIndex>(cases()).a0)})
        : std::holds_alternative<EMethod>(cases()) ? Pod::choice("EMethod", {prism_rtl::to_pod(std::get<EMethod>(cases()).a0), prism_rtl::to_pod(std::get<EMethod>(cases()).a1), prism_rtl::to_pod(std::get<EMethod>(cases()).a2)})
        : std::holds_alternative<ETypeArgs>(cases()) ? Pod::choice("ETypeArgs", {prism_rtl::to_pod(std::get<ETypeArgs>(cases()).a0), prism_rtl::to_pod(std::get<ETypeArgs>(cases()).a1)})
        : std::holds_alternative<ECast>(cases()) ? Pod::choice("ECast", {prism_rtl::to_pod(std::get<ECast>(cases()).a0), prism_rtl::to_pod(std::get<ECast>(cases()).a1), prism_rtl::to_pod(std::get<ECast>(cases()).a2)})
        : std::holds_alternative<ENonEmpty>(cases()) ? Pod::choice("ENonEmpty", {prism_rtl::to_pod(std::get<ENonEmpty>(cases()).a0)})
        : std::holds_alternative<EAbsent>(cases()) ? Pod::choice("EAbsent", {})
        : std::holds_alternative<ERest>(cases()) ? Pod::choice("ERest", {})
        : std::holds_alternative<ELambda>(cases()) ? Pod::choice("ELambda", {prism_rtl::to_pod(std::get<ELambda>(cases()).a0), prism_rtl::to_pod(std::get<ELambda>(cases()).a1)})
        : std::holds_alternative<EIf>(cases()) ? Pod::choice("EIf", {prism_rtl::to_pod(std::get<EIf>(cases()).a0), prism_rtl::to_pod(std::get<EIf>(cases()).a1), prism_rtl::to_pod(std::get<EIf>(cases()).a2)})
        : std::holds_alternative<EMatch>(cases()) ? Pod::choice("EMatch", {prism_rtl::to_pod(std::get<EMatch>(cases()).a0), prism_rtl::to_pod(std::get<EMatch>(cases()).a1)})
        : std::holds_alternative<ERebuild>(cases()) ? Pod::choice("ERebuild", {prism_rtl::to_pod(std::get<ERebuild>(cases()).a0), prism_rtl::to_pod(std::get<ERebuild>(cases()).a1)})
        : std::holds_alternative<EFor>(cases()) ? Pod::choice("EFor", {prism_rtl::to_pod(std::get<EFor>(cases()).a0), prism_rtl::to_pod(std::get<EFor>(cases()).a1), prism_rtl::to_pod(std::get<EFor>(cases()).a2)})
        : std::holds_alternative<EGiven>(cases()) ? Pod::choice("EGiven", {prism_rtl::to_pod(std::get<EGiven>(cases()).a0)})
        : std::holds_alternative<EUpdate>(cases()) ? Pod::choice("EUpdate", {prism_rtl::to_pod(std::get<EUpdate>(cases()).a0), prism_rtl::to_pod(std::get<EUpdate>(cases()).a1)})
        : std::holds_alternative<EWidgetBlock>(cases()) ? Pod::choice("EWidgetBlock", {prism_rtl::to_pod(std::get<EWidgetBlock>(cases()).a0)})
        : std::holds_alternative<EMonad>(cases()) ? Pod::choice("EMonad", {prism_rtl::to_pod(std::get<EMonad>(cases()).a0), prism_rtl::to_pod(std::get<EMonad>(cases()).a1)})
        : std::holds_alternative<ETemplate>(cases()) ? Pod::choice("ETemplate", {prism_rtl::to_pod(std::get<ETemplate>(cases()).a0)})
        : std::holds_alternative<EAny>(cases()) ? Pod::choice("EAny", {prism_rtl::to_pod(std::get<EAny>(cases()).a0)})
        : std::holds_alternative<ELens>(cases()) ? Pod::choice("ELens", {prism_rtl::to_pod(std::get<ELens>(cases()).a0)})
        : std::holds_alternative<EError>(cases()) ? Pod::choice("EError", {})
        : Pod();
}

Result<ExprKind> ExprKind::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "EName" && c->args.size() == 1) return ExprKind(EName{TRY(prism_rtl::from_pod<SName>(c->args[0]))});
        if (c->ctor == "ELit" && c->args.size() == 1) return ExprKind(ELit{TRY(prism_rtl::from_pod<Literal>(c->args[0]))});
        if (c->ctor == "EUnit" && c->args.size() == 1) return ExprKind(EUnit{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "ENil" && c->args.size() == 1) return ExprKind(ENil{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "EBound" && c->args.size() == 1) return ExprKind(EBound{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "ETuple" && c->args.size() == 1) return ExprKind(ETuple{TRY(prism_rtl::from_pod<Array<Expr>>(c->args[0]))});
        if (c->ctor == "EArray" && c->args.size() == 1) return ExprKind(EArray{TRY(prism_rtl::from_pod<Array<Expr>>(c->args[0]))});
        if (c->ctor == "EMap" && c->args.size() == 1) return ExprKind(EMap{TRY(prism_rtl::from_pod<Array<std::tuple<Expr, Expr>>>(c->args[0]))});
        if (c->ctor == "EGroup" && c->args.size() == 1) return ExprKind(EGroup{TRY(prism_rtl::from_pod<prism_rtl::Rc<const Expr>>(c->args[0]))});
        if (c->ctor == "ECall" && c->args.size() == 4) return ExprKind(ECall{TRY(prism_rtl::from_pod<prism_rtl::Rc<const Expr>>(c->args[0])), TRY(prism_rtl::from_pod<Array<Arg>>(c->args[1])), TRY(prism_rtl::from_pod<bool>(c->args[2])), TRY(prism_rtl::from_pod<bool>(c->args[3]))});
        if (c->ctor == "EBinary" && c->args.size() == 3) return ExprKind(EBinary{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<prism_rtl::Rc<const Expr>>(c->args[1])), TRY(prism_rtl::from_pod<prism_rtl::Rc<const Expr>>(c->args[2]))});
        if (c->ctor == "EUnary" && c->args.size() == 2) return ExprKind(EUnary{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<prism_rtl::Rc<const Expr>>(c->args[1]))});
        if (c->ctor == "ESuffixed" && c->args.size() == 4) return ExprKind(ESuffixed{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<QualName>(c->args[1])), TRY(prism_rtl::from_pod<prism_rtl::Rc<const Expr>>(c->args[2])), TRY(prism_rtl::from_pod<prism_rtl::Rc<const Expr>>(c->args[3]))});
        if (c->ctor == "EFreeSigil" && c->args.size() == 2) return ExprKind(EFreeSigil{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<prism_rtl::Rc<const Expr>>(c->args[1]))});
        if (c->ctor == "EField" && c->args.size() == 3) return ExprKind(EField{TRY(prism_rtl::from_pod<prism_rtl::Rc<const Expr>>(c->args[0])), TRY(prism_rtl::from_pod<Text>(c->args[1])), TRY(prism_rtl::from_pod<Ident>(c->args[2]))});
        if (c->ctor == "EIndex" && c->args.size() == 2) return ExprKind(EIndex{TRY(prism_rtl::from_pod<prism_rtl::Rc<const Expr>>(c->args[0])), TRY(prism_rtl::from_pod<prism_rtl::Rc<const Expr>>(c->args[1]))});
        if (c->ctor == "ETopicField" && c->args.size() == 1) return ExprKind(ETopicField{TRY(prism_rtl::from_pod<Ident>(c->args[0]))});
        if (c->ctor == "ETopicIndex" && c->args.size() == 1) return ExprKind(ETopicIndex{TRY(prism_rtl::from_pod<prism_rtl::Rc<const Expr>>(c->args[0]))});
        if (c->ctor == "EMethod" && c->args.size() == 3) return ExprKind(EMethod{TRY(prism_rtl::from_pod<prism_rtl::Rc<const Expr>>(c->args[0])), TRY(prism_rtl::from_pod<SName>(c->args[1])), TRY(prism_rtl::from_pod<Array<Arg>>(c->args[2]))});
        if (c->ctor == "ETypeArgs" && c->args.size() == 2) return ExprKind(ETypeArgs{TRY(prism_rtl::from_pod<prism_rtl::Rc<const Expr>>(c->args[0])), TRY(prism_rtl::from_pod<Array<Type>>(c->args[1]))});
        if (c->ctor == "ECast" && c->args.size() == 3) return ExprKind(ECast{TRY(prism_rtl::from_pod<prism_rtl::Rc<const Expr>>(c->args[0])), TRY(prism_rtl::from_pod<Type>(c->args[1])), TRY(prism_rtl::from_pod<bool>(c->args[2]))});
        if (c->ctor == "ENonEmpty" && c->args.size() == 1) return ExprKind(ENonEmpty{TRY(prism_rtl::from_pod<prism_rtl::Rc<const Expr>>(c->args[0]))});
        if (c->ctor == "EAbsent" && c->args.size() == 0) return ExprKind(EAbsent{});
        if (c->ctor == "ERest" && c->args.size() == 0) return ExprKind(ERest{});
        if (c->ctor == "ELambda" && c->args.size() == 2) return ExprKind(ELambda{TRY(prism_rtl::from_pod<std::optional<Array<Pattern_>>>(c->args[0])), TRY(prism_rtl::from_pod<prism_rtl::Rc<const LambdaBody>>(c->args[1]))});
        if (c->ctor == "EIf" && c->args.size() == 3) return ExprKind(EIf{TRY(prism_rtl::from_pod<prism_rtl::Rc<const Cond>>(c->args[0])), TRY(prism_rtl::from_pod<Block>(c->args[1])), TRY(prism_rtl::from_pod<std::optional<Block>>(c->args[2]))});
        if (c->ctor == "EMatch" && c->args.size() == 2) return ExprKind(EMatch{TRY(prism_rtl::from_pod<prism_rtl::Rc<const Expr>>(c->args[0])), TRY(prism_rtl::from_pod<Array<Arm>>(c->args[1]))});
        if (c->ctor == "ERebuild" && c->args.size() == 2) return ExprKind(ERebuild{TRY(prism_rtl::from_pod<prism_rtl::Rc<const Expr>>(c->args[0])), TRY(prism_rtl::from_pod<Block>(c->args[1]))});
        if (c->ctor == "EFor" && c->args.size() == 3) return ExprKind(EFor{TRY(prism_rtl::from_pod<std::optional<ForBinders>>(c->args[0])), TRY(prism_rtl::from_pod<prism_rtl::Rc<const Expr>>(c->args[1])), TRY(prism_rtl::from_pod<Block>(c->args[2]))});
        if (c->ctor == "EGiven" && c->args.size() == 1) return ExprKind(EGiven{TRY(prism_rtl::from_pod<Block>(c->args[0]))});
        if (c->ctor == "EUpdate" && c->args.size() == 2) return ExprKind(EUpdate{TRY(prism_rtl::from_pod<prism_rtl::Rc<const Expr>>(c->args[0])), TRY(prism_rtl::from_pod<Block>(c->args[1]))});
        if (c->ctor == "EWidgetBlock" && c->args.size() == 1) return ExprKind(EWidgetBlock{TRY(prism_rtl::from_pod<Block>(c->args[0]))});
        if (c->ctor == "EMonad" && c->args.size() == 2) return ExprKind(EMonad{TRY(prism_rtl::from_pod<prism_rtl::Rc<const Expr>>(c->args[0])), TRY(prism_rtl::from_pod<Block>(c->args[1]))});
        if (c->ctor == "ETemplate" && c->args.size() == 1) return ExprKind(ETemplate{TRY(prism_rtl::from_pod<Template>(c->args[0]))});
        if (c->ctor == "EAny" && c->args.size() == 1) return ExprKind(EAny{TRY(prism_rtl::from_pod<prism_rtl::Rc<const Expr>>(c->args[0]))});
        if (c->ctor == "ELens" && c->args.size() == 1) return ExprKind(ELens{TRY(prism_rtl::from_pod<Array<Ident>>(c->args[0]))});
        if (c->ctor == "EError" && c->args.size() == 0) return ExprKind(EError{});
    }
    return mismatch<ExprKind>("a ExprKind", p);
}


void FieldPat::show(Printer& p) const {
    p.record("FieldPat", {{"name", name_o}, {"pattern", pattern_p}, {"span", span_p}});
}

Pod FieldPat::to_pod() const {
    return Pod::record("FieldPat", {{"name", prism_rtl::to_pod(name_o)}, {"pattern", prism_rtl::to_pod(pattern_p)}, {"span", prism_rtl::to_pod(span_p)}});
}

Result<FieldPat> FieldPat::from_pod(const Pod& whole) {
    return FieldPat{.name_o = TRY(prism_rtl::from_pod<std::optional<Ident>>(TRY(crate::prelude::field(whole, "name")))), .pattern_p = TRY(prism_rtl::from_pod<Pattern_>(TRY(crate::prelude::field(whole, "pattern")))), .span_p = TRY(prism_rtl::from_pod<Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void ForBinders::show(Printer& p) const {
    p.record("ForBinders", {{"first", first_p}, {"second", second_o}});
}

Pod ForBinders::to_pod() const {
    return Pod::record("ForBinders", {{"first", prism_rtl::to_pod(first_p)}, {"second", prism_rtl::to_pod(second_o)}});
}

Result<ForBinders> ForBinders::from_pod(const Pod& whole) {
    return ForBinders{.first_p = TRY(prism_rtl::from_pod<Pattern_>(TRY(crate::prelude::field(whole, "first")))), .second_o = TRY(prism_rtl::from_pod<std::optional<Pattern_>>(TRY(crate::prelude::field(whole, "second"))))};
}


void Ident::show(Printer& p) const {
    p.record("Ident", {{"name", name_p}, {"span", span_p}});
}

Pod Ident::to_pod() const {
    return Pod::record("Ident", {{"name", prism_rtl::to_pod(name_p)}, {"span", prism_rtl::to_pod(span_p)}});
}

Result<Ident> Ident::from_pod(const Pod& whole) {
    return Ident{.name_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .span_p = TRY(prism_rtl::from_pod<Range>(TRY(crate::prelude::field(whole, "span"))))};
}


bool LambdaBody::LbExpr::operator==(const LbExpr& o) const { return a0 == o.a0; }

void LambdaBody::show(Printer& p) const {
    if (auto c = std::get_if<LbExpr>(&cases())) p.choice("LbExpr", {c->a0});
    else if (auto c = std::get_if<LbBlock>(&cases())) p.choice("LbBlock", {c->a0});
}

Pod LambdaBody::to_pod() const {
    return std::holds_alternative<LbExpr>(cases()) ? Pod::choice("LbExpr", {prism_rtl::to_pod(std::get<LbExpr>(cases()).a0)})
        : std::holds_alternative<LbBlock>(cases()) ? Pod::choice("LbBlock", {prism_rtl::to_pod(std::get<LbBlock>(cases()).a0)})
        : Pod();
}

Result<LambdaBody> LambdaBody::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "LbExpr" && c->args.size() == 1) return LambdaBody(LbExpr{TRY(prism_rtl::from_pod<prism_rtl::Rc<const Expr>>(c->args[0]))});
        if (c->ctor == "LbBlock" && c->args.size() == 1) return LambdaBody(LbBlock{TRY(prism_rtl::from_pod<Block>(c->args[0]))});
    }
    return mismatch<LambdaBody>("a LambdaBody", p);
}


bool LitKind::LText::operator==(const LText& o) const { return a0 == o.a0; }

void LitKind::show(Printer& p) const {
    if (auto c = std::get_if<LInt>(&cases())) p.choice("LInt", {c->a0});
    else if (auto c = std::get_if<LFloat>(&cases())) p.choice("LFloat", {c->a0});
    else if (auto c = std::get_if<LDuration>(&cases())) p.choice("LDuration", {c->a0, c->a1});
    else if (auto c = std::get_if<LChar>(&cases())) p.choice("LChar", {c->a0});
    else if (auto c = std::get_if<LText>(&cases())) p.choice("LText", {c->a0});
    else if (auto c = std::get_if<LRegex>(&cases())) p.choice("LRegex", {c->a0});
}

Pod LitKind::to_pod() const {
    return std::holds_alternative<LInt>(cases()) ? Pod::choice("LInt", {prism_rtl::to_pod(std::get<LInt>(cases()).a0)})
        : std::holds_alternative<LFloat>(cases()) ? Pod::choice("LFloat", {prism_rtl::to_pod(std::get<LFloat>(cases()).a0)})
        : std::holds_alternative<LDuration>(cases()) ? Pod::choice("LDuration", {prism_rtl::to_pod(std::get<LDuration>(cases()).a0), prism_rtl::to_pod(std::get<LDuration>(cases()).a1)})
        : std::holds_alternative<LChar>(cases()) ? Pod::choice("LChar", {prism_rtl::to_pod(std::get<LChar>(cases()).a0)})
        : std::holds_alternative<LText>(cases()) ? Pod::choice("LText", {prism_rtl::to_pod(std::get<LText>(cases()).a0)})
        : std::holds_alternative<LRegex>(cases()) ? Pod::choice("LRegex", {prism_rtl::to_pod(std::get<LRegex>(cases()).a0)})
        : Pod();
}

Result<LitKind> LitKind::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "LInt" && c->args.size() == 1) return LitKind(LInt{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "LFloat" && c->args.size() == 1) return LitKind(LFloat{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "LDuration" && c->args.size() == 2) return LitKind(LDuration{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Text>(c->args[1]))});
        if (c->ctor == "LChar" && c->args.size() == 1) return LitKind(LChar{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "LText" && c->args.size() == 1) return LitKind(LText{TRY(prism_rtl::from_pod<Array<TextSeg>>(c->args[0]))});
        if (c->ctor == "LRegex" && c->args.size() == 1) return LitKind(LRegex{TRY(prism_rtl::from_pod<RegexLit>(c->args[0]))});
    }
    return mismatch<LitKind>("a LitKind", p);
}


void Literal::show(Printer& p) const {
    p.record("Literal", {{"marks", marks_p}, {"kind", kind_p}, {"span", span_p}});
}

Pod Literal::to_pod() const {
    return Pod::record("Literal", {{"marks", prism_rtl::to_pod(marks_p)}, {"kind", prism_rtl::to_pod(kind_p)}, {"span", prism_rtl::to_pod(span_p)}});
}

Result<Literal> Literal::from_pod(const Pod& whole) {
    return Literal{.marks_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "marks")))), .kind_p = TRY(prism_rtl::from_pod<LitKind>(TRY(crate::prelude::field(whole, "kind")))), .span_p = TRY(prism_rtl::from_pod<Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void ModLine::show(Printer& p) const {
    p.record("ModLine", {{"name", name_p}, {"isTest", is_test_p}, {"span", span_p}});
}

Pod ModLine::to_pod() const {
    return Pod::record("ModLine", {{"name", prism_rtl::to_pod(name_p)}, {"isTest", prism_rtl::to_pod(is_test_p)}, {"span", prism_rtl::to_pod(span_p)}});
}

Result<ModLine> ModLine::from_pod(const Pod& whole) {
    return ModLine{.name_p = TRY(prism_rtl::from_pod<Ident>(TRY(crate::prelude::field(whole, "name")))), .is_test_p = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "isTest")))), .span_p = TRY(prism_rtl::from_pod<Range>(TRY(crate::prelude::field(whole, "span"))))};
}


bool Module::operator==(const Module& o) const { return name_o == o.name_o && emit_row_o == o.emit_row_o && mods_p == o.mods_p && uses_p == o.uses_p && decls_p == o.decls_p && template_o == o.template_o && span_p == o.span_p; }

void Module::show(Printer& p) const {
    p.record("Module", {{"name", name_o}, {"emitRow", emit_row_o}, {"mods", mods_p}, {"uses", uses_p}, {"decls", decls_p}, {"template", template_o}, {"span", span_p}});
}

Pod Module::to_pod() const {
    return Pod::record("Module", {{"name", prism_rtl::to_pod(name_o)}, {"emitRow", prism_rtl::to_pod(emit_row_o)}, {"mods", prism_rtl::to_pod(mods_p)}, {"uses", prism_rtl::to_pod(uses_p)}, {"decls", prism_rtl::to_pod(decls_p)}, {"template", prism_rtl::to_pod(template_o)}, {"span", prism_rtl::to_pod(span_p)}});
}

Result<Module> Module::from_pod(const Pod& whole) {
    return Module{.name_o = TRY(prism_rtl::from_pod<std::optional<QualName>>(TRY(crate::prelude::field(whole, "name")))), .emit_row_o = TRY(prism_rtl::from_pod<std::optional<Row_>>(TRY(crate::prelude::field(whole, "emitRow")))), .mods_p = TRY(prism_rtl::from_pod<Array<ModLine>>(TRY(crate::prelude::field(whole, "mods")))), .uses_p = TRY(prism_rtl::from_pod<Array<Use>>(TRY(crate::prelude::field(whole, "uses")))), .decls_p = TRY(prism_rtl::from_pod<Array<crate::syntax::decls::Decl>>(TRY(crate::prelude::field(whole, "decls")))), .template_o = TRY(prism_rtl::from_pod<std::optional<Template>>(TRY(crate::prelude::field(whole, "template")))), .span_p = TRY(prism_rtl::from_pod<Range>(TRY(crate::prelude::field(whole, "span"))))};
}


bool Pattern_::operator==(const Pattern_& o) const { return kind_p == o.kind_p && span_p == o.span_p; }

void Pattern_::show(Printer& p) const {
    p.record("Pattern", {{"kind", kind_p}, {"span", span_p}});
}

Pod Pattern_::to_pod() const {
    return Pod::record("Pattern", {{"kind", prism_rtl::to_pod(kind_p)}, {"span", prism_rtl::to_pod(span_p)}});
}

Result<Pattern_> Pattern_::from_pod(const Pod& whole) {
    return Pattern_{.kind_p = TRY(prism_rtl::from_pod<prism_rtl::Rc<const PatternKind>>(TRY(crate::prelude::field(whole, "kind")))), .span_p = TRY(prism_rtl::from_pod<Range>(TRY(crate::prelude::field(whole, "span"))))};
}


bool PatternKind::PCtor::operator==(const PCtor& o) const { return a0 == o.a0 && a1 == o.a1; }

bool PatternKind::PRecord::operator==(const PRecord& o) const { return a0 == o.a0 && a1 == o.a1 && a2 == o.a2; }

bool PatternKind::PSigil::operator==(const PSigil& o) const { return a0 == o.a0 && a1 == o.a1; }

bool PatternKind::PTuple::operator==(const PTuple& o) const { return a0 == o.a0; }

bool PatternKind::PArray::operator==(const PArray& o) const { return a0 == o.a0; }

bool PatternKind::PGroup::operator==(const PGroup& o) const { return a0 == o.a0; }

void PatternKind::show(Printer& p) const {
    if (auto c = std::get_if<PName>(&cases())) p.choice("PName", {c->a0});
    else if (auto c = std::get_if<PIgnore>(&cases())) p.choice("PIgnore", {});
    else if (auto c = std::get_if<PLit>(&cases())) p.choice("PLit", {c->a0});
    else if (auto c = std::get_if<PNeg>(&cases())) p.choice("PNeg", {c->a0});
    else if (auto c = std::get_if<PUnit>(&cases())) p.choice("PUnit", {});
    else if (auto c = std::get_if<PNil>(&cases())) p.choice("PNil", {});
    else if (auto c = std::get_if<PCtor>(&cases())) p.choice("PCtor", {c->a0, c->a1});
    else if (auto c = std::get_if<PRecord>(&cases())) p.choice("PRecord", {c->a0, c->a1, c->a2});
    else if (auto c = std::get_if<PSigil>(&cases())) p.choice("PSigil", {c->a0, c->a1});
    else if (auto c = std::get_if<PTuple>(&cases())) p.choice("PTuple", {c->a0});
    else if (auto c = std::get_if<PArray>(&cases())) p.choice("PArray", {c->a0});
    else if (auto c = std::get_if<PGroup>(&cases())) p.choice("PGroup", {c->a0});
    else if (auto c = std::get_if<PFamily>(&cases())) p.choice("PFamily", {c->a0});
}

Pod PatternKind::to_pod() const {
    return std::holds_alternative<PName>(cases()) ? Pod::choice("PName", {prism_rtl::to_pod(std::get<PName>(cases()).a0)})
        : std::holds_alternative<PIgnore>(cases()) ? Pod::choice("PIgnore", {})
        : std::holds_alternative<PLit>(cases()) ? Pod::choice("PLit", {prism_rtl::to_pod(std::get<PLit>(cases()).a0)})
        : std::holds_alternative<PNeg>(cases()) ? Pod::choice("PNeg", {prism_rtl::to_pod(std::get<PNeg>(cases()).a0)})
        : std::holds_alternative<PUnit>(cases()) ? Pod::choice("PUnit", {})
        : std::holds_alternative<PNil>(cases()) ? Pod::choice("PNil", {})
        : std::holds_alternative<PCtor>(cases()) ? Pod::choice("PCtor", {prism_rtl::to_pod(std::get<PCtor>(cases()).a0), prism_rtl::to_pod(std::get<PCtor>(cases()).a1)})
        : std::holds_alternative<PRecord>(cases()) ? Pod::choice("PRecord", {prism_rtl::to_pod(std::get<PRecord>(cases()).a0), prism_rtl::to_pod(std::get<PRecord>(cases()).a1), prism_rtl::to_pod(std::get<PRecord>(cases()).a2)})
        : std::holds_alternative<PSigil>(cases()) ? Pod::choice("PSigil", {prism_rtl::to_pod(std::get<PSigil>(cases()).a0), prism_rtl::to_pod(std::get<PSigil>(cases()).a1)})
        : std::holds_alternative<PTuple>(cases()) ? Pod::choice("PTuple", {prism_rtl::to_pod(std::get<PTuple>(cases()).a0)})
        : std::holds_alternative<PArray>(cases()) ? Pod::choice("PArray", {prism_rtl::to_pod(std::get<PArray>(cases()).a0)})
        : std::holds_alternative<PGroup>(cases()) ? Pod::choice("PGroup", {prism_rtl::to_pod(std::get<PGroup>(cases()).a0)})
        : std::holds_alternative<PFamily>(cases()) ? Pod::choice("PFamily", {prism_rtl::to_pod(std::get<PFamily>(cases()).a0)})
        : Pod();
}

Result<PatternKind> PatternKind::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "PName" && c->args.size() == 1) return PatternKind(PName{TRY(prism_rtl::from_pod<SName>(c->args[0]))});
        if (c->ctor == "PIgnore" && c->args.size() == 0) return PatternKind(PIgnore{});
        if (c->ctor == "PLit" && c->args.size() == 1) return PatternKind(PLit{TRY(prism_rtl::from_pod<Literal>(c->args[0]))});
        if (c->ctor == "PNeg" && c->args.size() == 1) return PatternKind(PNeg{TRY(prism_rtl::from_pod<Literal>(c->args[0]))});
        if (c->ctor == "PUnit" && c->args.size() == 0) return PatternKind(PUnit{});
        if (c->ctor == "PNil" && c->args.size() == 0) return PatternKind(PNil{});
        if (c->ctor == "PCtor" && c->args.size() == 2) return PatternKind(PCtor{TRY(prism_rtl::from_pod<SName>(c->args[0])), TRY(prism_rtl::from_pod<Array<Pattern_>>(c->args[1]))});
        if (c->ctor == "PRecord" && c->args.size() == 3) return PatternKind(PRecord{TRY(prism_rtl::from_pod<SName>(c->args[0])), TRY(prism_rtl::from_pod<Array<FieldPat>>(c->args[1])), TRY(prism_rtl::from_pod<bool>(c->args[2]))});
        if (c->ctor == "PSigil" && c->args.size() == 2) return PatternKind(PSigil{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<prism_rtl::Rc<const Pattern_>>(c->args[1]))});
        if (c->ctor == "PTuple" && c->args.size() == 1) return PatternKind(PTuple{TRY(prism_rtl::from_pod<Array<Pattern_>>(c->args[0]))});
        if (c->ctor == "PArray" && c->args.size() == 1) return PatternKind(PArray{TRY(prism_rtl::from_pod<Array<Pattern_>>(c->args[0]))});
        if (c->ctor == "PGroup" && c->args.size() == 1) return PatternKind(PGroup{TRY(prism_rtl::from_pod<prism_rtl::Rc<const Pattern_>>(c->args[0]))});
        if (c->ctor == "PFamily" && c->args.size() == 1) return PatternKind(PFamily{TRY(prism_rtl::from_pod<QualName>(c->args[0]))});
    }
    return mismatch<PatternKind>("a PatternKind", p);
}


void QualName::show(Printer& p) const {
    p.record("QualName", {{"path", path_p}, {"span", span_p}});
}

Pod QualName::to_pod() const {
    return Pod::record("QualName", {{"path", prism_rtl::to_pod(path_p)}, {"span", prism_rtl::to_pod(span_p)}});
}

Result<QualName> QualName::from_pod(const Pod& whole) {
    return QualName{.path_p = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "path")))), .span_p = TRY(prism_rtl::from_pod<Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void Range::show(Printer& p) const {
    p.record("Range", {{"start", start_p}, {"end", end_p}});
}

Pod Range::to_pod() const {
    return Pod::record("Range", {{"start", prism_rtl::to_pod(start_p)}, {"end", prism_rtl::to_pod(end_p)}});
}

Result<Range> Range::from_pod(const Pod& whole) {
    return Range{.start_p = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "start")))), .end_p = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "end"))))};
}


void RegexLit::show(Printer& p) const {
    p.record("RegexLit", {{"pattern", pattern_p}, {"patternAt", pattern_at_p}, {"replacement", replacement_o}, {"replacementAt", replacement_at_p}, {"flags", flags_p}, {"flagsAt", flags_at_p}});
}

Pod RegexLit::to_pod() const {
    return Pod::record("RegexLit", {{"pattern", prism_rtl::to_pod(pattern_p)}, {"patternAt", prism_rtl::to_pod(pattern_at_p)}, {"replacement", prism_rtl::to_pod(replacement_o)}, {"replacementAt", prism_rtl::to_pod(replacement_at_p)}, {"flags", prism_rtl::to_pod(flags_p)}, {"flagsAt", prism_rtl::to_pod(flags_at_p)}});
}

Result<RegexLit> RegexLit::from_pod(const Pod& whole) {
    return RegexLit{.pattern_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "pattern")))), .pattern_at_p = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "patternAt")))), .replacement_o = TRY(prism_rtl::from_pod<std::optional<Text>>(TRY(crate::prelude::field(whole, "replacement")))), .replacement_at_p = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "replacementAt")))), .flags_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "flags")))), .flags_at_p = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "flagsAt"))))};
}


bool Row_::operator==(const Row_& o) const { return terms_p == o.terms_p && span_p == o.span_p; }

void Row_::show(Printer& p) const {
    p.record("Row", {{"terms", terms_p}, {"span", span_p}});
}

Pod Row_::to_pod() const {
    return Pod::record("Row", {{"terms", prism_rtl::to_pod(terms_p)}, {"span", prism_rtl::to_pod(span_p)}});
}

Result<Row_> Row_::from_pod(const Pod& whole) {
    return Row_{.terms_p = TRY(prism_rtl::from_pod<Array<RowTerm>>(TRY(crate::prelude::field(whole, "terms")))), .span_p = TRY(prism_rtl::from_pod<Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void RowTerm::show(Printer& p) const {
    if (auto c = std::get_if<RFamily>(&cases())) p.choice("RFamily", {c->a0});
    else if (auto c = std::get_if<RType>(&cases())) p.choice("RType", {c->a0});
    else if (auto c = std::get_if<RVar>(&cases())) p.choice("RVar", {c->a0});
}

Pod RowTerm::to_pod() const {
    return std::holds_alternative<RFamily>(cases()) ? Pod::choice("RFamily", {prism_rtl::to_pod(std::get<RFamily>(cases()).a0)})
        : std::holds_alternative<RType>(cases()) ? Pod::choice("RType", {prism_rtl::to_pod(std::get<RType>(cases()).a0)})
        : std::holds_alternative<RVar>(cases()) ? Pod::choice("RVar", {prism_rtl::to_pod(std::get<RVar>(cases()).a0)})
        : Pod();
}

Result<RowTerm> RowTerm::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "RFamily" && c->args.size() == 1) return RowTerm(RFamily{TRY(prism_rtl::from_pod<QualName>(c->args[0]))});
        if (c->ctor == "RType" && c->args.size() == 1) return RowTerm(RType{TRY(prism_rtl::from_pod<Type>(c->args[0]))});
        if (c->ctor == "RVar" && c->args.size() == 1) return RowTerm(RVar{TRY(prism_rtl::from_pod<Ident>(c->args[0]))});
    }
    return mismatch<RowTerm>("a RowTerm", p);
}


void SName::show(Printer& p) const {
    p.record("SName", {{"sigils", sigils_p}, {"path", path_p}, {"span", span_p}});
}

Pod SName::to_pod() const {
    return Pod::record("SName", {{"sigils", prism_rtl::to_pod(sigils_p)}, {"path", prism_rtl::to_pod(path_p)}, {"span", prism_rtl::to_pod(span_p)}});
}

Result<SName> SName::from_pod(const Pod& whole) {
    return SName{.sigils_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "sigils")))), .path_p = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "path")))), .span_p = TRY(prism_rtl::from_pod<Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void Stmt::show(Printer& p) const {
    p.record("Stmt", {{"kind", kind_p}, {"span", span_p}});
}

Pod Stmt::to_pod() const {
    return Pod::record("Stmt", {{"kind", prism_rtl::to_pod(kind_p)}, {"span", prism_rtl::to_pod(span_p)}});
}

Result<Stmt> Stmt::from_pod(const Pod& whole) {
    return Stmt{.kind_p = TRY(prism_rtl::from_pod<StmtKind>(TRY(crate::prelude::field(whole, "kind")))), .span_p = TRY(prism_rtl::from_pod<Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void StmtKind::show(Printer& p) const {
    if (auto c = std::get_if<SEmit>(&cases())) p.choice("SEmit", {c->a0});
    else if (auto c = std::get_if<SBind>(&cases())) p.choice("SBind", {c->a0, c->a1, c->a2});
    else if (auto c = std::get_if<SIgnore>(&cases())) p.choice("SIgnore", {c->a0});
    else if (auto c = std::get_if<SLet>(&cases())) p.choice("SLet", {c->a0, c->a1, c->a2});
    else if (auto c = std::get_if<SSignature>(&cases())) p.choice("SSignature", {c->a0});
    else if (auto c = std::get_if<SFn>(&cases())) p.choice("SFn", {c->a0});
    else if (auto c = std::get_if<SWidget>(&cases())) p.choice("SWidget", {c->a0});
    else if (auto c = std::get_if<SSet>(&cases())) p.choice("SSet", {c->a0, c->a1});
    else if (auto c = std::get_if<SAccum>(&cases())) p.choice("SAccum", {c->a0, c->a1, c->a2});
    else if (auto c = std::get_if<SRequire>(&cases())) p.choice("SRequire", {c->a0});
    else if (auto c = std::get_if<SForbid>(&cases())) p.choice("SForbid", {c->a0});
    else if (auto c = std::get_if<SWhile>(&cases())) p.choice("SWhile", {c->a0, c->a1});
    else if (auto c = std::get_if<SReturn>(&cases())) p.choice("SReturn", {c->a0});
    else if (auto c = std::get_if<SExpr>(&cases())) p.choice("SExpr", {c->a0});
}

Pod StmtKind::to_pod() const {
    return std::holds_alternative<SEmit>(cases()) ? Pod::choice("SEmit", {prism_rtl::to_pod(std::get<SEmit>(cases()).a0)})
        : std::holds_alternative<SBind>(cases()) ? Pod::choice("SBind", {prism_rtl::to_pod(std::get<SBind>(cases()).a0), prism_rtl::to_pod(std::get<SBind>(cases()).a1), prism_rtl::to_pod(std::get<SBind>(cases()).a2)})
        : std::holds_alternative<SIgnore>(cases()) ? Pod::choice("SIgnore", {prism_rtl::to_pod(std::get<SIgnore>(cases()).a0)})
        : std::holds_alternative<SLet>(cases()) ? Pod::choice("SLet", {prism_rtl::to_pod(std::get<SLet>(cases()).a0), prism_rtl::to_pod(std::get<SLet>(cases()).a1), prism_rtl::to_pod(std::get<SLet>(cases()).a2)})
        : std::holds_alternative<SSignature>(cases()) ? Pod::choice("SSignature", {prism_rtl::to_pod(std::get<SSignature>(cases()).a0)})
        : std::holds_alternative<SFn>(cases()) ? Pod::choice("SFn", {prism_rtl::to_pod(std::get<SFn>(cases()).a0)})
        : std::holds_alternative<SWidget>(cases()) ? Pod::choice("SWidget", {prism_rtl::to_pod(std::get<SWidget>(cases()).a0)})
        : std::holds_alternative<SSet>(cases()) ? Pod::choice("SSet", {prism_rtl::to_pod(std::get<SSet>(cases()).a0), prism_rtl::to_pod(std::get<SSet>(cases()).a1)})
        : std::holds_alternative<SAccum>(cases()) ? Pod::choice("SAccum", {prism_rtl::to_pod(std::get<SAccum>(cases()).a0), prism_rtl::to_pod(std::get<SAccum>(cases()).a1), prism_rtl::to_pod(std::get<SAccum>(cases()).a2)})
        : std::holds_alternative<SRequire>(cases()) ? Pod::choice("SRequire", {prism_rtl::to_pod(std::get<SRequire>(cases()).a0)})
        : std::holds_alternative<SForbid>(cases()) ? Pod::choice("SForbid", {prism_rtl::to_pod(std::get<SForbid>(cases()).a0)})
        : std::holds_alternative<SWhile>(cases()) ? Pod::choice("SWhile", {prism_rtl::to_pod(std::get<SWhile>(cases()).a0), prism_rtl::to_pod(std::get<SWhile>(cases()).a1)})
        : std::holds_alternative<SReturn>(cases()) ? Pod::choice("SReturn", {prism_rtl::to_pod(std::get<SReturn>(cases()).a0)})
        : std::holds_alternative<SExpr>(cases()) ? Pod::choice("SExpr", {prism_rtl::to_pod(std::get<SExpr>(cases()).a0)})
        : Pod();
}

Result<StmtKind> StmtKind::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "SEmit" && c->args.size() == 1) return StmtKind(SEmit{TRY(prism_rtl::from_pod<Row_>(c->args[0]))});
        if (c->ctor == "SBind" && c->args.size() == 3) return StmtKind(SBind{TRY(prism_rtl::from_pod<Pattern_>(c->args[0])), TRY(prism_rtl::from_pod<Expr>(c->args[1])), TRY(prism_rtl::from_pod<std::optional<Expr>>(c->args[2]))});
        if (c->ctor == "SIgnore" && c->args.size() == 1) return StmtKind(SIgnore{TRY(prism_rtl::from_pod<Expr>(c->args[0]))});
        if (c->ctor == "SLet" && c->args.size() == 3) return StmtKind(SLet{TRY(prism_rtl::from_pod<Pattern_>(c->args[0])), TRY(prism_rtl::from_pod<std::optional<Type>>(c->args[1])), TRY(prism_rtl::from_pod<Expr>(c->args[2]))});
        if (c->ctor == "SSignature" && c->args.size() == 1) return StmtKind(SSignature{TRY(prism_rtl::from_pod<crate::syntax::decls::Signature>(c->args[0]))});
        if (c->ctor == "SFn" && c->args.size() == 1) return StmtKind(SFn{TRY(prism_rtl::from_pod<crate::syntax::decls::FnClause>(c->args[0]))});
        if (c->ctor == "SWidget" && c->args.size() == 1) return StmtKind(SWidget{TRY(prism_rtl::from_pod<crate::syntax::decls::WidgetDecl>(c->args[0]))});
        if (c->ctor == "SSet" && c->args.size() == 2) return StmtKind(SSet{TRY(prism_rtl::from_pod<Expr>(c->args[0])), TRY(prism_rtl::from_pod<Expr>(c->args[1]))});
        if (c->ctor == "SAccum" && c->args.size() == 3) return StmtKind(SAccum{TRY(prism_rtl::from_pod<Expr>(c->args[0])), TRY(prism_rtl::from_pod<Text>(c->args[1])), TRY(prism_rtl::from_pod<Expr>(c->args[2]))});
        if (c->ctor == "SRequire" && c->args.size() == 1) return StmtKind(SRequire{TRY(prism_rtl::from_pod<Expr>(c->args[0]))});
        if (c->ctor == "SForbid" && c->args.size() == 1) return StmtKind(SForbid{TRY(prism_rtl::from_pod<Expr>(c->args[0]))});
        if (c->ctor == "SWhile" && c->args.size() == 2) return StmtKind(SWhile{TRY(prism_rtl::from_pod<Cond>(c->args[0])), TRY(prism_rtl::from_pod<Block>(c->args[1]))});
        if (c->ctor == "SReturn" && c->args.size() == 1) return StmtKind(SReturn{TRY(prism_rtl::from_pod<Expr>(c->args[0]))});
        if (c->ctor == "SExpr" && c->args.size() == 1) return StmtKind(SExpr{TRY(prism_rtl::from_pod<Expr>(c->args[0]))});
    }
    return mismatch<StmtKind>("a StmtKind", p);
}


bool Template::operator==(const Template& o) const { return keyword_p == o.keyword_p && lang_p == o.lang_p && delims_p == o.delims_p && parts_p == o.parts_p && span_p == o.span_p; }

void Template::show(Printer& p) const {
    p.record("Template", {{"keyword", keyword_p}, {"lang", lang_p}, {"delims", delims_p}, {"parts", parts_p}, {"span", span_p}});
}

Pod Template::to_pod() const {
    return Pod::record("Template", {{"keyword", prism_rtl::to_pod(keyword_p)}, {"lang", prism_rtl::to_pod(lang_p)}, {"delims", prism_rtl::to_pod(delims_p)}, {"parts", prism_rtl::to_pod(parts_p)}, {"span", prism_rtl::to_pod(span_p)}});
}

Result<Template> Template::from_pod(const Pod& whole) {
    return Template{.keyword_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "keyword")))), .lang_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "lang")))), .delims_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "delims")))), .parts_p = TRY(prism_rtl::from_pod<Array<TemplatePart>>(TRY(crate::prelude::field(whole, "parts")))), .span_p = TRY(prism_rtl::from_pod<Range>(TRY(crate::prelude::field(whole, "span"))))};
}


bool TemplatePart::TpCall::operator==(const TpCall& o) const { return a0 == o.a0 && a1 == o.a1 && a2 == o.a2 && a3 == o.a3; }

void TemplatePart::show(Printer& p) const {
    if (auto c = std::get_if<TpText>(&cases())) p.choice("TpText", {c->a0});
    else if (auto c = std::get_if<TpPlaceholder>(&cases())) p.choice("TpPlaceholder", {c->a0, c->a1});
    else if (auto c = std::get_if<TpBlock>(&cases())) p.choice("TpBlock", {c->a0});
    else if (auto c = std::get_if<TpCall>(&cases())) p.choice("TpCall", {c->a0, c->a1, c->a2, c->a3});
}

Pod TemplatePart::to_pod() const {
    return std::holds_alternative<TpText>(cases()) ? Pod::choice("TpText", {prism_rtl::to_pod(std::get<TpText>(cases()).a0)})
        : std::holds_alternative<TpPlaceholder>(cases()) ? Pod::choice("TpPlaceholder", {prism_rtl::to_pod(std::get<TpPlaceholder>(cases()).a0), prism_rtl::to_pod(std::get<TpPlaceholder>(cases()).a1)})
        : std::holds_alternative<TpBlock>(cases()) ? Pod::choice("TpBlock", {prism_rtl::to_pod(std::get<TpBlock>(cases()).a0)})
        : std::holds_alternative<TpCall>(cases()) ? Pod::choice("TpCall", {prism_rtl::to_pod(std::get<TpCall>(cases()).a0), prism_rtl::to_pod(std::get<TpCall>(cases()).a1), prism_rtl::to_pod(std::get<TpCall>(cases()).a2), prism_rtl::to_pod(std::get<TpCall>(cases()).a3)})
        : Pod();
}

Result<TemplatePart> TemplatePart::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "TpText" && c->args.size() == 1) return TemplatePart(TpText{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "TpPlaceholder" && c->args.size() == 2) return TemplatePart(TpPlaceholder{TRY(prism_rtl::from_pod<Expr>(c->args[0])), TRY(prism_rtl::from_pod<std::optional<Nat>>(c->args[1]))});
        if (c->ctor == "TpBlock" && c->args.size() == 1) return TemplatePart(TpBlock{TRY(prism_rtl::from_pod<Block>(c->args[0]))});
        if (c->ctor == "TpCall" && c->args.size() == 4) return TemplatePart(TpCall{TRY(prism_rtl::from_pod<SName>(c->args[0])), TRY(prism_rtl::from_pod<Array<Arg>>(c->args[1])), TRY(prism_rtl::from_pod<std::optional<Array<TemplatePart>>>(c->args[2])), TRY(prism_rtl::from_pod<Range>(c->args[3]))});
    }
    return mismatch<TemplatePart>("a TemplatePart", p);
}


void TextSeg::show(Printer& p) const {
    if (auto c = std::get_if<SegPlain>(&cases())) p.choice("SegPlain", {c->a0});
    else if (auto c = std::get_if<SegPlaceholder>(&cases())) p.choice("SegPlaceholder", {c->a0});
}

Pod TextSeg::to_pod() const {
    return std::holds_alternative<SegPlain>(cases()) ? Pod::choice("SegPlain", {prism_rtl::to_pod(std::get<SegPlain>(cases()).a0)})
        : std::holds_alternative<SegPlaceholder>(cases()) ? Pod::choice("SegPlaceholder", {prism_rtl::to_pod(std::get<SegPlaceholder>(cases()).a0)})
        : Pod();
}

Result<TextSeg> TextSeg::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "SegPlain" && c->args.size() == 1) return TextSeg(SegPlain{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "SegPlaceholder" && c->args.size() == 1) return TextSeg(SegPlaceholder{TRY(prism_rtl::from_pod<Expr>(c->args[0]))});
    }
    return mismatch<TextSeg>("a TextSeg", p);
}


void TraitRef::show(Printer& p) const {
    p.record("TraitRef", {{"path", path_p}, {"span", span_p}});
}

Pod TraitRef::to_pod() const {
    return Pod::record("TraitRef", {{"path", prism_rtl::to_pod(path_p)}, {"span", prism_rtl::to_pod(span_p)}});
}

Result<TraitRef> TraitRef::from_pod(const Pod& whole) {
    return TraitRef{.path_p = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "path")))), .span_p = TRY(prism_rtl::from_pod<Range>(TRY(crate::prelude::field(whole, "span"))))};
}


bool Type::operator==(const Type& o) const { return kind_p == o.kind_p && span_p == o.span_p; }

void Type::show(Printer& p) const {
    p.record("Type", {{"kind", kind_p}, {"span", span_p}});
}

Pod Type::to_pod() const {
    return Pod::record("Type", {{"kind", prism_rtl::to_pod(kind_p)}, {"span", prism_rtl::to_pod(span_p)}});
}

Result<Type> Type::from_pod(const Pod& whole) {
    return Type{.kind_p = TRY(prism_rtl::from_pod<prism_rtl::Rc<const TypeKind>>(TRY(crate::prelude::field(whole, "kind")))), .span_p = TRY(prism_rtl::from_pod<Range>(TRY(crate::prelude::field(whole, "span"))))};
}


bool TypeKind::TName::operator==(const TName& o) const { return a0 == o.a0 && a1 == o.a1; }

bool TypeKind::TSigiled::operator==(const TSigiled& o) const { return a0 == o.a0 && a1 == o.a1; }

bool TypeKind::TArray::operator==(const TArray& o) const { return a0 == o.a0 && a1 == o.a1; }

bool TypeKind::TTuple::operator==(const TTuple& o) const { return a0 == o.a0; }

bool TypeKind::TGroup::operator==(const TGroup& o) const { return a0 == o.a0; }

bool TypeKind::TMap::operator==(const TMap& o) const { return a0 == o.a0 && a1 == o.a1; }

bool TypeKind::TFn::operator==(const TFn& o) const { return a0 == o.a0 && a1 == o.a1 && a2 == o.a2; }

bool TypeKind::TEmit::operator==(const TEmit& o) const { return a0 == o.a0 && a1 == o.a1; }

bool TypeKind::TRowUnion::operator==(const TRowUnion& o) const { return a0 == o.a0; }

bool TypeKind::TNonEmpty::operator==(const TNonEmpty& o) const { return a0 == o.a0; }

void TypeKind::show(Printer& p) const {
    if (auto c = std::get_if<TName>(&cases())) p.choice("TName", {c->a0, c->a1});
    else if (auto c = std::get_if<TSigiled>(&cases())) p.choice("TSigiled", {c->a0, c->a1});
    else if (auto c = std::get_if<TArray>(&cases())) p.choice("TArray", {c->a0, c->a1});
    else if (auto c = std::get_if<TTuple>(&cases())) p.choice("TTuple", {c->a0});
    else if (auto c = std::get_if<TGroup>(&cases())) p.choice("TGroup", {c->a0});
    else if (auto c = std::get_if<TMap>(&cases())) p.choice("TMap", {c->a0, c->a1});
    else if (auto c = std::get_if<TFn>(&cases())) p.choice("TFn", {c->a0, c->a1, c->a2});
    else if (auto c = std::get_if<TEmit>(&cases())) p.choice("TEmit", {c->a0, c->a1});
    else if (auto c = std::get_if<TRowUnion>(&cases())) p.choice("TRowUnion", {c->a0});
    else if (auto c = std::get_if<TFamily>(&cases())) p.choice("TFamily", {c->a0});
    else if (auto c = std::get_if<TAny>(&cases())) p.choice("TAny", {c->a0});
    else if (auto c = std::get_if<TUnit>(&cases())) p.choice("TUnit", {c->a0});
    else if (auto c = std::get_if<THole>(&cases())) p.choice("THole", {c->a0});
    else if (auto c = std::get_if<TAbsent>(&cases())) p.choice("TAbsent", {});
    else if (auto c = std::get_if<TNonEmpty>(&cases())) p.choice("TNonEmpty", {c->a0});
}

Pod TypeKind::to_pod() const {
    return std::holds_alternative<TName>(cases()) ? Pod::choice("TName", {prism_rtl::to_pod(std::get<TName>(cases()).a0), prism_rtl::to_pod(std::get<TName>(cases()).a1)})
        : std::holds_alternative<TSigiled>(cases()) ? Pod::choice("TSigiled", {prism_rtl::to_pod(std::get<TSigiled>(cases()).a0), prism_rtl::to_pod(std::get<TSigiled>(cases()).a1)})
        : std::holds_alternative<TArray>(cases()) ? Pod::choice("TArray", {prism_rtl::to_pod(std::get<TArray>(cases()).a0), prism_rtl::to_pod(std::get<TArray>(cases()).a1)})
        : std::holds_alternative<TTuple>(cases()) ? Pod::choice("TTuple", {prism_rtl::to_pod(std::get<TTuple>(cases()).a0)})
        : std::holds_alternative<TGroup>(cases()) ? Pod::choice("TGroup", {prism_rtl::to_pod(std::get<TGroup>(cases()).a0)})
        : std::holds_alternative<TMap>(cases()) ? Pod::choice("TMap", {prism_rtl::to_pod(std::get<TMap>(cases()).a0), prism_rtl::to_pod(std::get<TMap>(cases()).a1)})
        : std::holds_alternative<TFn>(cases()) ? Pod::choice("TFn", {prism_rtl::to_pod(std::get<TFn>(cases()).a0), prism_rtl::to_pod(std::get<TFn>(cases()).a1), prism_rtl::to_pod(std::get<TFn>(cases()).a2)})
        : std::holds_alternative<TEmit>(cases()) ? Pod::choice("TEmit", {prism_rtl::to_pod(std::get<TEmit>(cases()).a0), prism_rtl::to_pod(std::get<TEmit>(cases()).a1)})
        : std::holds_alternative<TRowUnion>(cases()) ? Pod::choice("TRowUnion", {prism_rtl::to_pod(std::get<TRowUnion>(cases()).a0)})
        : std::holds_alternative<TFamily>(cases()) ? Pod::choice("TFamily", {prism_rtl::to_pod(std::get<TFamily>(cases()).a0)})
        : std::holds_alternative<TAny>(cases()) ? Pod::choice("TAny", {prism_rtl::to_pod(std::get<TAny>(cases()).a0)})
        : std::holds_alternative<TUnit>(cases()) ? Pod::choice("TUnit", {prism_rtl::to_pod(std::get<TUnit>(cases()).a0)})
        : std::holds_alternative<THole>(cases()) ? Pod::choice("THole", {prism_rtl::to_pod(std::get<THole>(cases()).a0)})
        : std::holds_alternative<TAbsent>(cases()) ? Pod::choice("TAbsent", {})
        : std::holds_alternative<TNonEmpty>(cases()) ? Pod::choice("TNonEmpty", {prism_rtl::to_pod(std::get<TNonEmpty>(cases()).a0)})
        : Pod();
}

Result<TypeKind> TypeKind::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "TName" && c->args.size() == 2) return TypeKind(TName{TRY(prism_rtl::from_pod<SName>(c->args[0])), TRY(prism_rtl::from_pod<Array<Type>>(c->args[1]))});
        if (c->ctor == "TSigiled" && c->args.size() == 2) return TypeKind(TSigiled{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<prism_rtl::Rc<const Type>>(c->args[1]))});
        if (c->ctor == "TArray" && c->args.size() == 2) return TypeKind(TArray{TRY(prism_rtl::from_pod<prism_rtl::Rc<const Type>>(c->args[0])), TRY(prism_rtl::from_pod<bool>(c->args[1]))});
        if (c->ctor == "TTuple" && c->args.size() == 1) return TypeKind(TTuple{TRY(prism_rtl::from_pod<Array<Type>>(c->args[0]))});
        if (c->ctor == "TGroup" && c->args.size() == 1) return TypeKind(TGroup{TRY(prism_rtl::from_pod<prism_rtl::Rc<const Type>>(c->args[0]))});
        if (c->ctor == "TMap" && c->args.size() == 2) return TypeKind(TMap{TRY(prism_rtl::from_pod<prism_rtl::Rc<const Type>>(c->args[0])), TRY(prism_rtl::from_pod<prism_rtl::Rc<const Type>>(c->args[1]))});
        if (c->ctor == "TFn" && c->args.size() == 3) return TypeKind(TFn{TRY(prism_rtl::from_pod<Color>(c->args[0])), TRY(prism_rtl::from_pod<Array<Type>>(c->args[1])), TRY(prism_rtl::from_pod<prism_rtl::Rc<const Type>>(c->args[2]))});
        if (c->ctor == "TEmit" && c->args.size() == 2) return TypeKind(TEmit{TRY(prism_rtl::from_pod<prism_rtl::Rc<const Type>>(c->args[0])), TRY(prism_rtl::from_pod<prism_rtl::Rc<const Type>>(c->args[1]))});
        if (c->ctor == "TRowUnion" && c->args.size() == 1) return TypeKind(TRowUnion{TRY(prism_rtl::from_pod<Array<Type>>(c->args[0]))});
        if (c->ctor == "TFamily" && c->args.size() == 1) return TypeKind(TFamily{TRY(prism_rtl::from_pod<QualName>(c->args[0]))});
        if (c->ctor == "TAny" && c->args.size() == 1) return TypeKind(TAny{TRY(prism_rtl::from_pod<TraitRef>(c->args[0]))});
        if (c->ctor == "TUnit" && c->args.size() == 1) return TypeKind(TUnit{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "THole" && c->args.size() == 1) return TypeKind(THole{TRY(prism_rtl::from_pod<SName>(c->args[0]))});
        if (c->ctor == "TAbsent" && c->args.size() == 0) return TypeKind(TAbsent{});
        if (c->ctor == "TNonEmpty" && c->args.size() == 1) return TypeKind(TNonEmpty{TRY(prism_rtl::from_pod<prism_rtl::Rc<const Type>>(c->args[0]))});
    }
    return mismatch<TypeKind>("a TypeKind", p);
}


void Use::show(Printer& p) const {
    p.record("Use", {{"target", target_p}, {"star", star_p}, {"span", span_p}});
}

Pod Use::to_pod() const {
    return Pod::record("Use", {{"target", prism_rtl::to_pod(target_p)}, {"star", prism_rtl::to_pod(star_p)}, {"span", prism_rtl::to_pod(span_p)}});
}

Result<Use> Use::from_pod(const Pod& whole) {
    return Use{.target_p = TRY(prism_rtl::from_pod<QualName>(TRY(crate::prelude::field(whole, "target")))), .star_p = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "star")))), .span_p = TRY(prism_rtl::from_pod<Range>(TRY(crate::prelude::field(whole, "span"))))};
}

}  // namespace crate::syntax


// The module `Syntax.Decls`, from `target/bootstrap/cpp-src/prismc/syntax/decls.prism`.
namespace crate::syntax::decls {

bool Bound::operator==(const Bound& o) const { return var_p == o.var_p && traits_p == o.traits_p && span_p == o.span_p; }

void Bound::show(Printer& p) const {
    p.record("Bound", {{"var", var_p}, {"traits", traits_p}, {"span", span_p}});
}

Pod Bound::to_pod() const {
    return Pod::record("Bound", {{"var", prism_rtl::to_pod(var_p)}, {"traits", prism_rtl::to_pod(traits_p)}, {"span", prism_rtl::to_pod(span_p)}});
}

Result<Bound> Bound::from_pod(const Pod& whole) {
    return Bound{.var_p = TRY(prism_rtl::from_pod<crate::syntax::Ident>(TRY(crate::prelude::field(whole, "var")))), .traits_p = TRY(prism_rtl::from_pod<Array<crate::syntax::TraitRef>>(TRY(crate::prelude::field(whole, "traits")))), .span_p = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span"))))};
}


bool Case_::operator==(const Case_& o) const { return name_p == o.name_p && args_p == o.args_p && indexed_o == o.indexed_o && span_p == o.span_p; }

void Case_::show(Printer& p) const {
    p.record("Case", {{"name", name_p}, {"args", args_p}, {"indexed", indexed_o}, {"span", span_p}});
}

Pod Case_::to_pod() const {
    return Pod::record("Case", {{"name", prism_rtl::to_pod(name_p)}, {"args", prism_rtl::to_pod(args_p)}, {"indexed", prism_rtl::to_pod(indexed_o)}, {"span", prism_rtl::to_pod(span_p)}});
}

Result<Case_> Case_::from_pod(const Pod& whole) {
    return Case_{.name_p = TRY(prism_rtl::from_pod<crate::syntax::SName>(TRY(crate::prelude::field(whole, "name")))), .args_p = TRY(prism_rtl::from_pod<Array<crate::syntax::Type>>(TRY(crate::prelude::field(whole, "args")))), .indexed_o = TRY(prism_rtl::from_pod<std::optional<crate::syntax::Type>>(TRY(crate::prelude::field(whole, "indexed")))), .span_p = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span"))))};
}


bool CheckDecl::operator==(const CheckDecl& o) const { return name_p == o.name_p && lines_p == o.lines_p && span_p == o.span_p; }

void CheckDecl::show(Printer& p) const {
    p.record("CheckDecl", {{"name", name_p}, {"lines", lines_p}, {"span", span_p}});
}

Pod CheckDecl::to_pod() const {
    return Pod::record("CheckDecl", {{"name", prism_rtl::to_pod(name_p)}, {"lines", prism_rtl::to_pod(lines_p)}, {"span", prism_rtl::to_pod(span_p)}});
}

Result<CheckDecl> CheckDecl::from_pod(const Pod& whole) {
    return CheckDecl{.name_p = TRY(prism_rtl::from_pod<crate::syntax::Ident>(TRY(crate::prelude::field(whole, "name")))), .lines_p = TRY(prism_rtl::from_pod<Array<CheckLine>>(TRY(crate::prelude::field(whole, "lines")))), .span_p = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void CheckLine::show(Printer& p) const {
    p.record("CheckLine", {{"expr", expr_p}, {"pattern", pattern_o}, {"span", span_p}});
}

Pod CheckLine::to_pod() const {
    return Pod::record("CheckLine", {{"expr", prism_rtl::to_pod(expr_p)}, {"pattern", prism_rtl::to_pod(pattern_o)}, {"span", prism_rtl::to_pod(span_p)}});
}

Result<CheckLine> CheckLine::from_pod(const Pod& whole) {
    return CheckLine{.expr_p = TRY(prism_rtl::from_pod<crate::syntax::Expr>(TRY(crate::prelude::field(whole, "expr")))), .pattern_o = TRY(prism_rtl::from_pod<std::optional<crate::syntax::Pattern_>>(TRY(crate::prelude::field(whole, "pattern")))), .span_p = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void Decl::show(Printer& p) const {
    p.record("Decl", {{"kind", kind_p}, {"span", span_p}});
}

Pod Decl::to_pod() const {
    return Pod::record("Decl", {{"kind", prism_rtl::to_pod(kind_p)}, {"span", prism_rtl::to_pod(span_p)}});
}

Result<Decl> Decl::from_pod(const Pod& whole) {
    return Decl{.kind_p = TRY(prism_rtl::from_pod<DeclKind>(TRY(crate::prelude::field(whole, "kind")))), .span_p = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span"))))};
}


bool DeclKind::DDerive::operator==(const DDerive& o) const { return a0 == o.a0; }

void DeclKind::show(Printer& p) const {
    if (auto c = std::get_if<DSignature>(&cases())) p.choice("DSignature", {c->a0});
    else if (auto c = std::get_if<DFn>(&cases())) p.choice("DFn", {c->a0});
    else if (auto c = std::get_if<DLet>(&cases())) p.choice("DLet", {c->a0});
    else if (auto c = std::get_if<DWidget>(&cases())) p.choice("DWidget", {c->a0});
    else if (auto c = std::get_if<DType>(&cases())) p.choice("DType", {c->a0});
    else if (auto c = std::get_if<DTag>(&cases())) p.choice("DTag", {c->a0});
    else if (auto c = std::get_if<DDerive>(&cases())) p.choice("DDerive", {c->a0});
    else if (auto c = std::get_if<DTrait>(&cases())) p.choice("DTrait", {c->a0});
    else if (auto c = std::get_if<DImpl>(&cases())) p.choice("DImpl", {c->a0});
    else if (auto c = std::get_if<DCheck>(&cases())) p.choice("DCheck", {c->a0});
    else if (auto c = std::get_if<DTest>(&cases())) p.choice("DTest", {c->a0});
    else if (auto c = std::get_if<DStmt>(&cases())) p.choice("DStmt", {c->a0});
}

Pod DeclKind::to_pod() const {
    return std::holds_alternative<DSignature>(cases()) ? Pod::choice("DSignature", {prism_rtl::to_pod(std::get<DSignature>(cases()).a0)})
        : std::holds_alternative<DFn>(cases()) ? Pod::choice("DFn", {prism_rtl::to_pod(std::get<DFn>(cases()).a0)})
        : std::holds_alternative<DLet>(cases()) ? Pod::choice("DLet", {prism_rtl::to_pod(std::get<DLet>(cases()).a0)})
        : std::holds_alternative<DWidget>(cases()) ? Pod::choice("DWidget", {prism_rtl::to_pod(std::get<DWidget>(cases()).a0)})
        : std::holds_alternative<DType>(cases()) ? Pod::choice("DType", {prism_rtl::to_pod(std::get<DType>(cases()).a0)})
        : std::holds_alternative<DTag>(cases()) ? Pod::choice("DTag", {prism_rtl::to_pod(std::get<DTag>(cases()).a0)})
        : std::holds_alternative<DDerive>(cases()) ? Pod::choice("DDerive", {prism_rtl::to_pod(std::get<DDerive>(cases()).a0)})
        : std::holds_alternative<DTrait>(cases()) ? Pod::choice("DTrait", {prism_rtl::to_pod(std::get<DTrait>(cases()).a0)})
        : std::holds_alternative<DImpl>(cases()) ? Pod::choice("DImpl", {prism_rtl::to_pod(std::get<DImpl>(cases()).a0)})
        : std::holds_alternative<DCheck>(cases()) ? Pod::choice("DCheck", {prism_rtl::to_pod(std::get<DCheck>(cases()).a0)})
        : std::holds_alternative<DTest>(cases()) ? Pod::choice("DTest", {prism_rtl::to_pod(std::get<DTest>(cases()).a0)})
        : std::holds_alternative<DStmt>(cases()) ? Pod::choice("DStmt", {prism_rtl::to_pod(std::get<DStmt>(cases()).a0)})
        : Pod();
}

Result<DeclKind> DeclKind::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "DSignature" && c->args.size() == 1) return DeclKind(DSignature{TRY(prism_rtl::from_pod<Signature>(c->args[0]))});
        if (c->ctor == "DFn" && c->args.size() == 1) return DeclKind(DFn{TRY(prism_rtl::from_pod<FnClause>(c->args[0]))});
        if (c->ctor == "DLet" && c->args.size() == 1) return DeclKind(DLet{TRY(prism_rtl::from_pod<LetDecl>(c->args[0]))});
        if (c->ctor == "DWidget" && c->args.size() == 1) return DeclKind(DWidget{TRY(prism_rtl::from_pod<WidgetDecl>(c->args[0]))});
        if (c->ctor == "DType" && c->args.size() == 1) return DeclKind(DType{TRY(prism_rtl::from_pod<TypeDecl>(c->args[0]))});
        if (c->ctor == "DTag" && c->args.size() == 1) return DeclKind(DTag{TRY(prism_rtl::from_pod<TagDecl>(c->args[0]))});
        if (c->ctor == "DDerive" && c->args.size() == 1) return DeclKind(DDerive{TRY(prism_rtl::from_pod<Array<crate::syntax::TraitRef>>(c->args[0]))});
        if (c->ctor == "DTrait" && c->args.size() == 1) return DeclKind(DTrait{TRY(prism_rtl::from_pod<TraitDecl>(c->args[0]))});
        if (c->ctor == "DImpl" && c->args.size() == 1) return DeclKind(DImpl{TRY(prism_rtl::from_pod<ImplDecl>(c->args[0]))});
        if (c->ctor == "DCheck" && c->args.size() == 1) return DeclKind(DCheck{TRY(prism_rtl::from_pod<CheckDecl>(c->args[0]))});
        if (c->ctor == "DTest" && c->args.size() == 1) return DeclKind(DTest{TRY(prism_rtl::from_pod<TestDecl>(c->args[0]))});
        if (c->ctor == "DStmt" && c->args.size() == 1) return DeclKind(DStmt{TRY(prism_rtl::from_pod<crate::syntax::Stmt>(c->args[0]))});
    }
    return mismatch<DeclKind>("a DeclKind", p);
}


void DefName::show(Printer& p) const {
    if (auto c = std::get_if<DefSName>(&cases())) p.choice("DefSName", {c->a0});
    else if (auto c = std::get_if<DefOp>(&cases())) p.choice("DefOp", {c->a0, c->a1});
}

Pod DefName::to_pod() const {
    return std::holds_alternative<DefSName>(cases()) ? Pod::choice("DefSName", {prism_rtl::to_pod(std::get<DefSName>(cases()).a0)})
        : std::holds_alternative<DefOp>(cases()) ? Pod::choice("DefOp", {prism_rtl::to_pod(std::get<DefOp>(cases()).a0), prism_rtl::to_pod(std::get<DefOp>(cases()).a1)})
        : Pod();
}

Result<DefName> DefName::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "DefSName" && c->args.size() == 1) return DefName(DefSName{TRY(prism_rtl::from_pod<crate::syntax::SName>(c->args[0]))});
        if (c->ctor == "DefOp" && c->args.size() == 2) return DefName(DefOp{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<crate::syntax::Range>(c->args[1]))});
    }
    return mismatch<DefName>("a DefName", p);
}


void Delivery::show(Printer& p) const {
    p.record("Delivery", {{"kind", kind_p}, {"target", target_p}, {"span", span_p}});
}

Pod Delivery::to_pod() const {
    return Pod::record("Delivery", {{"kind", prism_rtl::to_pod(kind_p)}, {"target", prism_rtl::to_pod(target_p)}, {"span", prism_rtl::to_pod(span_p)}});
}

Result<Delivery> Delivery::from_pod(const Pod& whole) {
    return Delivery{.kind_p = TRY(prism_rtl::from_pod<DeliveryKind>(TRY(crate::prelude::field(whole, "kind")))), .target_p = TRY(prism_rtl::from_pod<Target>(TRY(crate::prelude::field(whole, "target")))), .span_p = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void DeliveryKind::show(Printer& p) const {
    if (auto c = std::get_if<DkSend>(&cases())) p.choice("DkSend", {c->a0});
    else if (auto c = std::get_if<DkClick>(&cases())) p.choice("DkClick", {});
    else if (auto c = std::get_if<DkAnswer>(&cases())) p.choice("DkAnswer", {});
}

Pod DeliveryKind::to_pod() const {
    return std::holds_alternative<DkSend>(cases()) ? Pod::choice("DkSend", {prism_rtl::to_pod(std::get<DkSend>(cases()).a0)})
        : std::holds_alternative<DkClick>(cases()) ? Pod::choice("DkClick", {})
        : std::holds_alternative<DkAnswer>(cases()) ? Pod::choice("DkAnswer", {})
        : Pod();
}

Result<DeliveryKind> DeliveryKind::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "DkSend" && c->args.size() == 1) return DeliveryKind(DkSend{TRY(prism_rtl::from_pod<crate::syntax::Expr>(c->args[0]))});
        if (c->ctor == "DkClick" && c->args.size() == 0) return DeliveryKind(DkClick{});
        if (c->ctor == "DkAnswer" && c->args.size() == 0) return DeliveryKind(DkAnswer{});
    }
    return mismatch<DeliveryKind>("a DeliveryKind", p);
}


void Entry::show(Printer& p) const {
    p.record("Entry", {{"element", element_p}, {"value", value_p}, {"span", span_p}});
}

Pod Entry::to_pod() const {
    return Pod::record("Entry", {{"element", prism_rtl::to_pod(element_p)}, {"value", prism_rtl::to_pod(value_p)}, {"span", prism_rtl::to_pod(span_p)}});
}

Result<Entry> Entry::from_pod(const Pod& whole) {
    return Entry{.element_p = TRY(prism_rtl::from_pod<crate::syntax::Expr>(TRY(crate::prelude::field(whole, "element")))), .value_p = TRY(prism_rtl::from_pod<crate::syntax::Expr>(TRY(crate::prelude::field(whole, "value")))), .span_p = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void Field::show(Printer& p) const {
    p.record("Field", {{"name", name_p}, {"ty", ty_p}, {"span", span_p}});
}

Pod Field::to_pod() const {
    return Pod::record("Field", {{"name", prism_rtl::to_pod(name_p)}, {"ty", prism_rtl::to_pod(ty_p)}, {"span", prism_rtl::to_pod(span_p)}});
}

Result<Field> Field::from_pod(const Pod& whole) {
    return Field{.name_p = TRY(prism_rtl::from_pod<crate::syntax::Ident>(TRY(crate::prelude::field(whole, "name")))), .ty_p = TRY(prism_rtl::from_pod<crate::syntax::Type>(TRY(crate::prelude::field(whole, "ty")))), .span_p = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void FnBody::show(Printer& p) const {
    if (auto c = std::get_if<BodyExpr>(&cases())) p.choice("BodyExpr", {c->a0});
    else if (auto c = std::get_if<BodyBlock>(&cases())) p.choice("BodyBlock", {c->a0});
}

Pod FnBody::to_pod() const {
    return std::holds_alternative<BodyExpr>(cases()) ? Pod::choice("BodyExpr", {prism_rtl::to_pod(std::get<BodyExpr>(cases()).a0)})
        : std::holds_alternative<BodyBlock>(cases()) ? Pod::choice("BodyBlock", {prism_rtl::to_pod(std::get<BodyBlock>(cases()).a0)})
        : Pod();
}

Result<FnBody> FnBody::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "BodyExpr" && c->args.size() == 1) return FnBody(BodyExpr{TRY(prism_rtl::from_pod<crate::syntax::Expr>(c->args[0]))});
        if (c->ctor == "BodyBlock" && c->args.size() == 1) return FnBody(BodyBlock{TRY(prism_rtl::from_pod<crate::syntax::Block>(c->args[0]))});
    }
    return mismatch<FnBody>("a FnBody", p);
}


bool FnClause::operator==(const FnClause& o) const { return name_p == o.name_p && params_p == o.params_p && body_p == o.body_p && span_p == o.span_p; }

void FnClause::show(Printer& p) const {
    p.record("FnClause", {{"name", name_p}, {"params", params_p}, {"body", body_p}, {"span", span_p}});
}

Pod FnClause::to_pod() const {
    return Pod::record("FnClause", {{"name", prism_rtl::to_pod(name_p)}, {"params", prism_rtl::to_pod(params_p)}, {"body", prism_rtl::to_pod(body_p)}, {"span", prism_rtl::to_pod(span_p)}});
}

Result<FnClause> FnClause::from_pod(const Pod& whole) {
    return FnClause{.name_p = TRY(prism_rtl::from_pod<DefName>(TRY(crate::prelude::field(whole, "name")))), .params_p = TRY(prism_rtl::from_pod<Array<crate::syntax::Pattern_>>(TRY(crate::prelude::field(whole, "params")))), .body_p = TRY(prism_rtl::from_pod<FnBody>(TRY(crate::prelude::field(whole, "body")))), .span_p = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span"))))};
}


bool ImplDecl::operator==(const ImplDecl& o) const { return trait_ref_p == o.trait_ref_p && ty_p == o.ty_p && bounds_p == o.bounds_p && items_p == o.items_p && span_p == o.span_p; }

void ImplDecl::show(Printer& p) const {
    p.record("ImplDecl", {{"traitRef", trait_ref_p}, {"ty", ty_p}, {"bounds", bounds_p}, {"items", items_p}, {"span", span_p}});
}

Pod ImplDecl::to_pod() const {
    return Pod::record("ImplDecl", {{"traitRef", prism_rtl::to_pod(trait_ref_p)}, {"ty", prism_rtl::to_pod(ty_p)}, {"bounds", prism_rtl::to_pod(bounds_p)}, {"items", prism_rtl::to_pod(items_p)}, {"span", prism_rtl::to_pod(span_p)}});
}

Result<ImplDecl> ImplDecl::from_pod(const Pod& whole) {
    return ImplDecl{.trait_ref_p = TRY(prism_rtl::from_pod<crate::syntax::TraitRef>(TRY(crate::prelude::field(whole, "traitRef")))), .ty_p = TRY(prism_rtl::from_pod<crate::syntax::Type>(TRY(crate::prelude::field(whole, "ty")))), .bounds_p = TRY(prism_rtl::from_pod<Array<Bound>>(TRY(crate::prelude::field(whole, "bounds")))), .items_p = TRY(prism_rtl::from_pod<Array<TraitItem>>(TRY(crate::prelude::field(whole, "items")))), .span_p = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void LetDecl::show(Printer& p) const {
    p.record("LetDecl", {{"pattern", pattern_p}, {"ty", ty_o}, {"value", value_p}, {"span", span_p}});
}

Pod LetDecl::to_pod() const {
    return Pod::record("LetDecl", {{"pattern", prism_rtl::to_pod(pattern_p)}, {"ty", prism_rtl::to_pod(ty_o)}, {"value", prism_rtl::to_pod(value_p)}, {"span", prism_rtl::to_pod(span_p)}});
}

Result<LetDecl> LetDecl::from_pod(const Pod& whole) {
    return LetDecl{.pattern_p = TRY(prism_rtl::from_pod<crate::syntax::Pattern_>(TRY(crate::prelude::field(whole, "pattern")))), .ty_o = TRY(prism_rtl::from_pod<std::optional<crate::syntax::Type>>(TRY(crate::prelude::field(whole, "ty")))), .value_p = TRY(prism_rtl::from_pod<crate::syntax::Expr>(TRY(crate::prelude::field(whole, "value")))), .span_p = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void PathSeg::show(Printer& p) const {
    if (auto c = std::get_if<PsNum>(&cases())) p.choice("PsNum", {c->a0});
    else if (auto c = std::get_if<PsGen>(&cases())) p.choice("PsGen", {c->a0});
    else if (auto c = std::get_if<PsKey>(&cases())) p.choice("PsKey", {c->a0});
}

Pod PathSeg::to_pod() const {
    return std::holds_alternative<PsNum>(cases()) ? Pod::choice("PsNum", {prism_rtl::to_pod(std::get<PsNum>(cases()).a0)})
        : std::holds_alternative<PsGen>(cases()) ? Pod::choice("PsGen", {prism_rtl::to_pod(std::get<PsGen>(cases()).a0)})
        : std::holds_alternative<PsKey>(cases()) ? Pod::choice("PsKey", {prism_rtl::to_pod(std::get<PsKey>(cases()).a0)})
        : Pod();
}

Result<PathSeg> PathSeg::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "PsNum" && c->args.size() == 1) return PathSeg(PsNum{TRY(prism_rtl::from_pod<Nat>(c->args[0]))});
        if (c->ctor == "PsGen" && c->args.size() == 1) return PathSeg(PsGen{TRY(prism_rtl::from_pod<Nat>(c->args[0]))});
        if (c->ctor == "PsKey" && c->args.size() == 1) return PathSeg(PsKey{TRY(prism_rtl::from_pod<crate::syntax::Expr>(c->args[0]))});
    }
    return mismatch<PathSeg>("a PathSeg", p);
}


bool Signature::operator==(const Signature& o) const { return name_p == o.name_p && ty_p == o.ty_p && bounds_p == o.bounds_p && span_p == o.span_p; }

void Signature::show(Printer& p) const {
    p.record("Signature", {{"name", name_p}, {"ty", ty_p}, {"bounds", bounds_p}, {"span", span_p}});
}

Pod Signature::to_pod() const {
    return Pod::record("Signature", {{"name", prism_rtl::to_pod(name_p)}, {"ty", prism_rtl::to_pod(ty_p)}, {"bounds", prism_rtl::to_pod(bounds_p)}, {"span", prism_rtl::to_pod(span_p)}});
}

Result<Signature> Signature::from_pod(const Pod& whole) {
    return Signature{.name_p = TRY(prism_rtl::from_pod<DefName>(TRY(crate::prelude::field(whole, "name")))), .ty_p = TRY(prism_rtl::from_pod<crate::syntax::Type>(TRY(crate::prelude::field(whole, "ty")))), .bounds_p = TRY(prism_rtl::from_pod<Array<Bound>>(TRY(crate::prelude::field(whole, "bounds")))), .span_p = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span"))))};
}


bool StepAction::SaDeliver::operator==(const SaDeliver& o) const { return a0 == o.a0; }

void StepAction::show(Printer& p) const {
    if (auto c = std::get_if<SaBuild>(&cases())) p.choice("SaBuild", {});
    else if (auto c = std::get_if<SaTick>(&cases())) p.choice("SaTick", {});
    else if (auto c = std::get_if<SaCompute>(&cases())) p.choice("SaCompute", {c->a0});
    else if (auto c = std::get_if<SaPush>(&cases())) p.choice("SaPush", {c->a0});
    else if (auto c = std::get_if<SaDeliver>(&cases())) p.choice("SaDeliver", {c->a0});
    else if (auto c = std::get_if<SaWithOnly>(&cases())) p.choice("SaWithOnly", {});
}

Pod StepAction::to_pod() const {
    return std::holds_alternative<SaBuild>(cases()) ? Pod::choice("SaBuild", {})
        : std::holds_alternative<SaTick>(cases()) ? Pod::choice("SaTick", {})
        : std::holds_alternative<SaCompute>(cases()) ? Pod::choice("SaCompute", {prism_rtl::to_pod(std::get<SaCompute>(cases()).a0)})
        : std::holds_alternative<SaPush>(cases()) ? Pod::choice("SaPush", {prism_rtl::to_pod(std::get<SaPush>(cases()).a0)})
        : std::holds_alternative<SaDeliver>(cases()) ? Pod::choice("SaDeliver", {prism_rtl::to_pod(std::get<SaDeliver>(cases()).a0)})
        : std::holds_alternative<SaWithOnly>(cases()) ? Pod::choice("SaWithOnly", {})
        : Pod();
}

Result<StepAction> StepAction::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "SaBuild" && c->args.size() == 0) return StepAction(SaBuild{});
        if (c->ctor == "SaTick" && c->args.size() == 0) return StepAction(SaTick{});
        if (c->ctor == "SaCompute" && c->args.size() == 1) return StepAction(SaCompute{TRY(prism_rtl::from_pod<bool>(c->args[0]))});
        if (c->ctor == "SaPush" && c->args.size() == 1) return StepAction(SaPush{TRY(prism_rtl::from_pod<Entry>(c->args[0]))});
        if (c->ctor == "SaDeliver" && c->args.size() == 1) return StepAction(SaDeliver{TRY(prism_rtl::from_pod<Array<Delivery>>(c->args[0]))});
        if (c->ctor == "SaWithOnly" && c->args.size() == 0) return StepAction(SaWithOnly{});
    }
    return mismatch<StepAction>("a StepAction", p);
}


bool TagDecl::operator==(const TagDecl& o) const { return name_p == o.name_p && of_type_p == o.of_type_p && bounds_p == o.bounds_p && fields_p == o.fields_p && span_p == o.span_p; }

void TagDecl::show(Printer& p) const {
    p.record("TagDecl", {{"name", name_p}, {"ofType", of_type_p}, {"bounds", bounds_p}, {"fields", fields_p}, {"span", span_p}});
}

Pod TagDecl::to_pod() const {
    return Pod::record("TagDecl", {{"name", prism_rtl::to_pod(name_p)}, {"ofType", prism_rtl::to_pod(of_type_p)}, {"bounds", prism_rtl::to_pod(bounds_p)}, {"fields", prism_rtl::to_pod(fields_p)}, {"span", prism_rtl::to_pod(span_p)}});
}

Result<TagDecl> TagDecl::from_pod(const Pod& whole) {
    return TagDecl{.name_p = TRY(prism_rtl::from_pod<crate::syntax::QualName>(TRY(crate::prelude::field(whole, "name")))), .of_type_p = TRY(prism_rtl::from_pod<crate::syntax::Type>(TRY(crate::prelude::field(whole, "ofType")))), .bounds_p = TRY(prism_rtl::from_pod<Array<Bound>>(TRY(crate::prelude::field(whole, "bounds")))), .fields_p = TRY(prism_rtl::from_pod<Array<Field>>(TRY(crate::prelude::field(whole, "fields")))), .span_p = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void Target::show(Printer& p) const {
    if (auto c = std::get_if<TgPattern>(&cases())) p.choice("TgPattern", {c->a0});
    else if (auto c = std::get_if<TgPath>(&cases())) p.choice("TgPath", {c->a0});
    else if (auto c = std::get_if<TgElement>(&cases())) p.choice("TgElement", {c->a0});
}

Pod Target::to_pod() const {
    return std::holds_alternative<TgPattern>(cases()) ? Pod::choice("TgPattern", {prism_rtl::to_pod(std::get<TgPattern>(cases()).a0)})
        : std::holds_alternative<TgPath>(cases()) ? Pod::choice("TgPath", {prism_rtl::to_pod(std::get<TgPath>(cases()).a0)})
        : std::holds_alternative<TgElement>(cases()) ? Pod::choice("TgElement", {prism_rtl::to_pod(std::get<TgElement>(cases()).a0)})
        : Pod();
}

Result<Target> Target::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "TgPattern" && c->args.size() == 1) return Target(TgPattern{TRY(prism_rtl::from_pod<crate::syntax::Pattern_>(c->args[0]))});
        if (c->ctor == "TgPath" && c->args.size() == 1) return Target(TgPath{TRY(prism_rtl::from_pod<TestPath>(c->args[0]))});
        if (c->ctor == "TgElement" && c->args.size() == 1) return Target(TgElement{TRY(prism_rtl::from_pod<TestPath>(c->args[0]))});
    }
    return mismatch<Target>("a Target", p);
}


void TestCheck::show(Printer& p) const {
    p.record("TestCheck", {{"kind", kind_p}, {"span", span_p}});
}

Pod TestCheck::to_pod() const {
    return Pod::record("TestCheck", {{"kind", prism_rtl::to_pod(kind_p)}, {"span", prism_rtl::to_pod(span_p)}});
}

Result<TestCheck> TestCheck::from_pod(const Pod& whole) {
    return TestCheck{.kind_p = TRY(prism_rtl::from_pod<TestCheckKind>(TRY(crate::prelude::field(whole, "kind")))), .span_p = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void TestCheckKind::show(Printer& p) const {
    if (auto c = std::get_if<CkExpect>(&cases())) p.choice("CkExpect", {c->a0});
    else if (auto c = std::get_if<CkExpectNone>(&cases())) p.choice("CkExpectNone", {c->a0});
    else if (auto c = std::get_if<CkExpectCount>(&cases())) p.choice("CkExpectCount", {c->a0, c->a1});
    else if (auto c = std::get_if<CkExpectTop>(&cases())) p.choice("CkExpectTop", {c->a0});
    else if (auto c = std::get_if<CkExpectTopNone>(&cases())) p.choice("CkExpectTopNone", {c->a0});
    else if (auto c = std::get_if<CkRequested>(&cases())) p.choice("CkRequested", {c->a0, c->a1});
    else if (auto c = std::get_if<CkUnrequested>(&cases())) p.choice("CkUnrequested", {c->a0});
    else if (auto c = std::get_if<CkReturns>(&cases())) p.choice("CkReturns", {c->a0});
    else if (auto c = std::get_if<CkFired>(&cases())) p.choice("CkFired", {c->a0});
    else if (auto c = std::get_if<CkQuiet>(&cases())) p.choice("CkQuiet", {});
    else if (auto c = std::get_if<CkSettles>(&cases())) p.choice("CkSettles", {});
    else if (auto c = std::get_if<CkAborted>(&cases())) p.choice("CkAborted", {});
    else if (auto c = std::get_if<CkSnapshot>(&cases())) p.choice("CkSnapshot", {c->a0});
}

Pod TestCheckKind::to_pod() const {
    return std::holds_alternative<CkExpect>(cases()) ? Pod::choice("CkExpect", {prism_rtl::to_pod(std::get<CkExpect>(cases()).a0)})
        : std::holds_alternative<CkExpectNone>(cases()) ? Pod::choice("CkExpectNone", {prism_rtl::to_pod(std::get<CkExpectNone>(cases()).a0)})
        : std::holds_alternative<CkExpectCount>(cases()) ? Pod::choice("CkExpectCount", {prism_rtl::to_pod(std::get<CkExpectCount>(cases()).a0), prism_rtl::to_pod(std::get<CkExpectCount>(cases()).a1)})
        : std::holds_alternative<CkExpectTop>(cases()) ? Pod::choice("CkExpectTop", {prism_rtl::to_pod(std::get<CkExpectTop>(cases()).a0)})
        : std::holds_alternative<CkExpectTopNone>(cases()) ? Pod::choice("CkExpectTopNone", {prism_rtl::to_pod(std::get<CkExpectTopNone>(cases()).a0)})
        : std::holds_alternative<CkRequested>(cases()) ? Pod::choice("CkRequested", {prism_rtl::to_pod(std::get<CkRequested>(cases()).a0), prism_rtl::to_pod(std::get<CkRequested>(cases()).a1)})
        : std::holds_alternative<CkUnrequested>(cases()) ? Pod::choice("CkUnrequested", {prism_rtl::to_pod(std::get<CkUnrequested>(cases()).a0)})
        : std::holds_alternative<CkReturns>(cases()) ? Pod::choice("CkReturns", {prism_rtl::to_pod(std::get<CkReturns>(cases()).a0)})
        : std::holds_alternative<CkFired>(cases()) ? Pod::choice("CkFired", {prism_rtl::to_pod(std::get<CkFired>(cases()).a0)})
        : std::holds_alternative<CkQuiet>(cases()) ? Pod::choice("CkQuiet", {})
        : std::holds_alternative<CkSettles>(cases()) ? Pod::choice("CkSettles", {})
        : std::holds_alternative<CkAborted>(cases()) ? Pod::choice("CkAborted", {})
        : std::holds_alternative<CkSnapshot>(cases()) ? Pod::choice("CkSnapshot", {prism_rtl::to_pod(std::get<CkSnapshot>(cases()).a0)})
        : Pod();
}

Result<TestCheckKind> TestCheckKind::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "CkExpect" && c->args.size() == 1) return TestCheckKind(CkExpect{TRY(prism_rtl::from_pod<crate::syntax::Pattern_>(c->args[0]))});
        if (c->ctor == "CkExpectNone" && c->args.size() == 1) return TestCheckKind(CkExpectNone{TRY(prism_rtl::from_pod<crate::syntax::Pattern_>(c->args[0]))});
        if (c->ctor == "CkExpectCount" && c->args.size() == 2) return TestCheckKind(CkExpectCount{TRY(prism_rtl::from_pod<crate::syntax::Pattern_>(c->args[0])), TRY(prism_rtl::from_pod<Nat>(c->args[1]))});
        if (c->ctor == "CkExpectTop" && c->args.size() == 1) return TestCheckKind(CkExpectTop{TRY(prism_rtl::from_pod<crate::syntax::Pattern_>(c->args[0]))});
        if (c->ctor == "CkExpectTopNone" && c->args.size() == 1) return TestCheckKind(CkExpectTopNone{TRY(prism_rtl::from_pod<crate::syntax::Pattern_>(c->args[0]))});
        if (c->ctor == "CkRequested" && c->args.size() == 2) return TestCheckKind(CkRequested{TRY(prism_rtl::from_pod<crate::syntax::Pattern_>(c->args[0])), TRY(prism_rtl::from_pod<crate::syntax::Pattern_>(c->args[1]))});
        if (c->ctor == "CkUnrequested" && c->args.size() == 1) return TestCheckKind(CkUnrequested{TRY(prism_rtl::from_pod<crate::syntax::Pattern_>(c->args[0]))});
        if (c->ctor == "CkReturns" && c->args.size() == 1) return TestCheckKind(CkReturns{TRY(prism_rtl::from_pod<crate::syntax::Pattern_>(c->args[0]))});
        if (c->ctor == "CkFired" && c->args.size() == 1) return TestCheckKind(CkFired{TRY(prism_rtl::from_pod<crate::syntax::Pattern_>(c->args[0]))});
        if (c->ctor == "CkQuiet" && c->args.size() == 0) return TestCheckKind(CkQuiet{});
        if (c->ctor == "CkSettles" && c->args.size() == 0) return TestCheckKind(CkSettles{});
        if (c->ctor == "CkAborted" && c->args.size() == 0) return TestCheckKind(CkAborted{});
        if (c->ctor == "CkSnapshot" && c->args.size() == 1) return TestCheckKind(CkSnapshot{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
    }
    return mismatch<TestCheckKind>("a TestCheckKind", p);
}


bool TestDecl::operator==(const TestDecl& o) const { return name_p == o.name_p && blueprint_p == o.blueprint_p && seed_o == o.seed_o && steps_p == o.steps_p && span_p == o.span_p; }

void TestDecl::show(Printer& p) const {
    p.record("TestDecl", {{"name", name_p}, {"blueprint", blueprint_p}, {"seed", seed_o}, {"steps", steps_p}, {"span", span_p}});
}

Pod TestDecl::to_pod() const {
    return Pod::record("TestDecl", {{"name", prism_rtl::to_pod(name_p)}, {"blueprint", prism_rtl::to_pod(blueprint_p)}, {"seed", prism_rtl::to_pod(seed_o)}, {"steps", prism_rtl::to_pod(steps_p)}, {"span", prism_rtl::to_pod(span_p)}});
}

Result<TestDecl> TestDecl::from_pod(const Pod& whole) {
    return TestDecl{.name_p = TRY(prism_rtl::from_pod<crate::syntax::Ident>(TRY(crate::prelude::field(whole, "name")))), .blueprint_p = TRY(prism_rtl::from_pod<crate::syntax::Expr>(TRY(crate::prelude::field(whole, "blueprint")))), .seed_o = TRY(prism_rtl::from_pod<std::optional<Nat>>(TRY(crate::prelude::field(whole, "seed")))), .steps_p = TRY(prism_rtl::from_pod<Array<TestStep>>(TRY(crate::prelude::field(whole, "steps")))), .span_p = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span"))))};
}


bool TestPath::operator==(const TestPath& o) const { return segments_p == o.segments_p && span_p == o.span_p; }

void TestPath::show(Printer& p) const {
    p.record("TestPath", {{"segments", segments_p}, {"span", span_p}});
}

Pod TestPath::to_pod() const {
    return Pod::record("TestPath", {{"segments", prism_rtl::to_pod(segments_p)}, {"span", prism_rtl::to_pod(span_p)}});
}

Result<TestPath> TestPath::from_pod(const Pod& whole) {
    return TestPath{.segments_p = TRY(prism_rtl::from_pod<Array<PathSeg>>(TRY(crate::prelude::field(whole, "segments")))), .span_p = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span"))))};
}


bool TestStep::operator==(const TestStep& o) const { return withs_p == o.withs_p && action_p == o.action_p && checks_p == o.checks_p && span_p == o.span_p; }

void TestStep::show(Printer& p) const {
    p.record("TestStep", {{"withs", withs_p}, {"action", action_p}, {"checks", checks_p}, {"span", span_p}});
}

Pod TestStep::to_pod() const {
    return Pod::record("TestStep", {{"withs", prism_rtl::to_pod(withs_p)}, {"action", prism_rtl::to_pod(action_p)}, {"checks", prism_rtl::to_pod(checks_p)}, {"span", prism_rtl::to_pod(span_p)}});
}

Result<TestStep> TestStep::from_pod(const Pod& whole) {
    return TestStep{.withs_p = TRY(prism_rtl::from_pod<Array<Entry>>(TRY(crate::prelude::field(whole, "withs")))), .action_p = TRY(prism_rtl::from_pod<StepAction>(TRY(crate::prelude::field(whole, "action")))), .checks_p = TRY(prism_rtl::from_pod<Array<TestCheck>>(TRY(crate::prelude::field(whole, "checks")))), .span_p = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span"))))};
}


bool TraitDecl::operator==(const TraitDecl& o) const { return name_p == o.name_p && params_p == o.params_p && bounds_p == o.bounds_p && items_p == o.items_p && span_p == o.span_p; }

void TraitDecl::show(Printer& p) const {
    p.record("TraitDecl", {{"name", name_p}, {"params", params_p}, {"bounds", bounds_p}, {"items", items_p}, {"span", span_p}});
}

Pod TraitDecl::to_pod() const {
    return Pod::record("TraitDecl", {{"name", prism_rtl::to_pod(name_p)}, {"params", prism_rtl::to_pod(params_p)}, {"bounds", prism_rtl::to_pod(bounds_p)}, {"items", prism_rtl::to_pod(items_p)}, {"span", prism_rtl::to_pod(span_p)}});
}

Result<TraitDecl> TraitDecl::from_pod(const Pod& whole) {
    return TraitDecl{.name_p = TRY(prism_rtl::from_pod<crate::syntax::TraitRef>(TRY(crate::prelude::field(whole, "name")))), .params_p = TRY(prism_rtl::from_pod<Array<crate::syntax::Ident>>(TRY(crate::prelude::field(whole, "params")))), .bounds_p = TRY(prism_rtl::from_pod<Array<Bound>>(TRY(crate::prelude::field(whole, "bounds")))), .items_p = TRY(prism_rtl::from_pod<Array<TraitItem>>(TRY(crate::prelude::field(whole, "items")))), .span_p = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span"))))};
}


bool TraitItem::TiAssocType::operator==(const TiAssocType& o) const { return a0 == o.a0 && a1 == o.a1 && a2 == o.a2 && a3 == o.a3; }

void TraitItem::show(Printer& p) const {
    if (auto c = std::get_if<TiSignature>(&cases())) p.choice("TiSignature", {c->a0});
    else if (auto c = std::get_if<TiFn>(&cases())) p.choice("TiFn", {c->a0});
    else if (auto c = std::get_if<TiAssocType>(&cases())) p.choice("TiAssocType", {c->a0, c->a1, c->a2, c->a3});
    else if (auto c = std::get_if<TiAssocRow>(&cases())) p.choice("TiAssocRow", {c->a0, c->a1});
}

Pod TraitItem::to_pod() const {
    return std::holds_alternative<TiSignature>(cases()) ? Pod::choice("TiSignature", {prism_rtl::to_pod(std::get<TiSignature>(cases()).a0)})
        : std::holds_alternative<TiFn>(cases()) ? Pod::choice("TiFn", {prism_rtl::to_pod(std::get<TiFn>(cases()).a0)})
        : std::holds_alternative<TiAssocType>(cases()) ? Pod::choice("TiAssocType", {prism_rtl::to_pod(std::get<TiAssocType>(cases()).a0), prism_rtl::to_pod(std::get<TiAssocType>(cases()).a1), prism_rtl::to_pod(std::get<TiAssocType>(cases()).a2), prism_rtl::to_pod(std::get<TiAssocType>(cases()).a3)})
        : std::holds_alternative<TiAssocRow>(cases()) ? Pod::choice("TiAssocRow", {prism_rtl::to_pod(std::get<TiAssocRow>(cases()).a0), prism_rtl::to_pod(std::get<TiAssocRow>(cases()).a1)})
        : Pod();
}

Result<TraitItem> TraitItem::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "TiSignature" && c->args.size() == 1) return TraitItem(TiSignature{TRY(prism_rtl::from_pod<Signature>(c->args[0]))});
        if (c->ctor == "TiFn" && c->args.size() == 1) return TraitItem(TiFn{TRY(prism_rtl::from_pod<FnClause>(c->args[0]))});
        if (c->ctor == "TiAssocType" && c->args.size() == 4) return TraitItem(TiAssocType{TRY(prism_rtl::from_pod<crate::syntax::Ident>(c->args[0])), TRY(prism_rtl::from_pod<Array<crate::syntax::Ident>>(c->args[1])), TRY(prism_rtl::from_pod<std::optional<crate::syntax::Type>>(c->args[2])), TRY(prism_rtl::from_pod<crate::syntax::Range>(c->args[3]))});
        if (c->ctor == "TiAssocRow" && c->args.size() == 2) return TraitItem(TiAssocRow{TRY(prism_rtl::from_pod<crate::syntax::SName>(c->args[0])), TRY(prism_rtl::from_pod<crate::syntax::Range>(c->args[1]))});
    }
    return mismatch<TraitItem>("a TraitItem", p);
}


bool TypeBody::TbRecord::operator==(const TbRecord& o) const { return a0 == o.a0; }

bool TypeBody::TbChoice::operator==(const TbChoice& o) const { return a0 == o.a0; }

void TypeBody::show(Printer& p) const {
    if (auto c = std::get_if<TbRecord>(&cases())) p.choice("TbRecord", {c->a0});
    else if (auto c = std::get_if<TbChoice>(&cases())) p.choice("TbChoice", {c->a0});
    else if (auto c = std::get_if<TbRow>(&cases())) p.choice("TbRow", {});
    else if (auto c = std::get_if<TbNewtype>(&cases())) p.choice("TbNewtype", {c->a0});
    else if (auto c = std::get_if<TbUnit>(&cases())) p.choice("TbUnit", {c->a0});
    else if (auto c = std::get_if<TbAlias>(&cases())) p.choice("TbAlias", {c->a0});
}

Pod TypeBody::to_pod() const {
    return std::holds_alternative<TbRecord>(cases()) ? Pod::choice("TbRecord", {prism_rtl::to_pod(std::get<TbRecord>(cases()).a0)})
        : std::holds_alternative<TbChoice>(cases()) ? Pod::choice("TbChoice", {prism_rtl::to_pod(std::get<TbChoice>(cases()).a0)})
        : std::holds_alternative<TbRow>(cases()) ? Pod::choice("TbRow", {})
        : std::holds_alternative<TbNewtype>(cases()) ? Pod::choice("TbNewtype", {prism_rtl::to_pod(std::get<TbNewtype>(cases()).a0)})
        : std::holds_alternative<TbUnit>(cases()) ? Pod::choice("TbUnit", {prism_rtl::to_pod(std::get<TbUnit>(cases()).a0)})
        : std::holds_alternative<TbAlias>(cases()) ? Pod::choice("TbAlias", {prism_rtl::to_pod(std::get<TbAlias>(cases()).a0)})
        : Pod();
}

Result<TypeBody> TypeBody::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "TbRecord" && c->args.size() == 1) return TypeBody(TbRecord{TRY(prism_rtl::from_pod<Array<Field>>(c->args[0]))});
        if (c->ctor == "TbChoice" && c->args.size() == 1) return TypeBody(TbChoice{TRY(prism_rtl::from_pod<Array<Case_>>(c->args[0]))});
        if (c->ctor == "TbRow" && c->args.size() == 0) return TypeBody(TbRow{});
        if (c->ctor == "TbNewtype" && c->args.size() == 1) return TypeBody(TbNewtype{TRY(prism_rtl::from_pod<Case_>(c->args[0]))});
        if (c->ctor == "TbUnit" && c->args.size() == 1) return TypeBody(TbUnit{TRY(prism_rtl::from_pod<crate::syntax::Ident>(c->args[0]))});
        if (c->ctor == "TbAlias" && c->args.size() == 1) return TypeBody(TbAlias{TRY(prism_rtl::from_pod<crate::syntax::Type>(c->args[0]))});
    }
    return mismatch<TypeBody>("a TypeBody", p);
}


bool TypeDecl::operator==(const TypeDecl& o) const { return name_p == o.name_p && params_p == o.params_p && body_o == o.body_o && span_p == o.span_p; }

void TypeDecl::show(Printer& p) const {
    p.record("TypeDecl", {{"name", name_p}, {"params", params_p}, {"body", body_o}, {"span", span_p}});
}

Pod TypeDecl::to_pod() const {
    return Pod::record("TypeDecl", {{"name", prism_rtl::to_pod(name_p)}, {"params", prism_rtl::to_pod(params_p)}, {"body", prism_rtl::to_pod(body_o)}, {"span", prism_rtl::to_pod(span_p)}});
}

Result<TypeDecl> TypeDecl::from_pod(const Pod& whole) {
    return TypeDecl{.name_p = TRY(prism_rtl::from_pod<crate::syntax::QualName>(TRY(crate::prelude::field(whole, "name")))), .params_p = TRY(prism_rtl::from_pod<Array<crate::syntax::Ident>>(TRY(crate::prelude::field(whole, "params")))), .body_o = TRY(prism_rtl::from_pod<std::optional<TypeBody>>(TRY(crate::prelude::field(whole, "body")))), .span_p = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void WidgetDecl::show(Printer& p) const {
    p.record("WidgetDecl", {{"name", name_p}, {"body", body_p}, {"span", span_p}});
}

Pod WidgetDecl::to_pod() const {
    return Pod::record("WidgetDecl", {{"name", prism_rtl::to_pod(name_p)}, {"body", prism_rtl::to_pod(body_p)}, {"span", prism_rtl::to_pod(span_p)}});
}

Result<WidgetDecl> WidgetDecl::from_pod(const Pod& whole) {
    return WidgetDecl{.name_p = TRY(prism_rtl::from_pod<crate::syntax::SName>(TRY(crate::prelude::field(whole, "name")))), .body_p = TRY(prism_rtl::from_pod<crate::syntax::Block>(TRY(crate::prelude::field(whole, "body")))), .span_p = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span"))))};
}

}  // namespace crate::syntax::decls
