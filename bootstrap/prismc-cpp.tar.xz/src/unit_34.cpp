// The module `Emit.Cpp.Items`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <emit/cpp/items/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>

// The module `Emit.Cpp.Items`, from `target/bootstrap/cpp-src/prismc/emit/cpp/items.prism`.
namespace crate::emit::cpp::items {

bool Parts::operator==(const Parts& o) const { return forward_p == o.forward_p && values_p == o.values_p && protos_p == o.protos_p && classes_p == o.classes_p && outer_p == o.outer_p && generic_p == o.generic_p && defs_p == o.defs_p; }

void Parts::show(Printer& p) const {
    p.record("Parts", {{"forward", forward_p}, {"values", values_p}, {"protos", protos_p}, {"classes", classes_p}, {"outer", outer_p}, {"generic", generic_p}, {"defs", defs_p}});
}

Pod Parts::to_pod() const {
    return Pod::record("Parts", {{"forward", prism_rtl::to_pod(forward_p)}, {"values", prism_rtl::to_pod(values_p)}, {"protos", prism_rtl::to_pod(protos_p)}, {"classes", prism_rtl::to_pod(classes_p)}, {"outer", prism_rtl::to_pod(outer_p)}, {"generic", prism_rtl::to_pod(generic_p)}, {"defs", prism_rtl::to_pod(defs_p)}});
}

Result<Parts> Parts::from_pod(const Pod& whole) {
    return Parts{.forward_p = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "forward")))), .values_p = TRY(prism_rtl::from_pod<Array<ValueDecl>>(TRY(crate::prelude::field(whole, "values")))), .protos_p = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "protos")))), .classes_p = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "classes")))), .outer_p = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "outer")))), .generic_p = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "generic")))), .defs_p = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "defs"))))};
}


void ValueDecl::show(Printer& p) const {
    p.record("ValueDecl", {{"path", path_p}, {"deps", deps_p}, {"text", text_p}});
}

Pod ValueDecl::to_pod() const {
    return Pod::record("ValueDecl", {{"path", prism_rtl::to_pod(path_p)}, {"deps", prism_rtl::to_pod(deps_p)}, {"text", prism_rtl::to_pod(text_p)}});
}

Result<ValueDecl> ValueDecl::from_pod(const Pod& whole) {
    return ValueDecl{.path_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "path")))), .deps_p = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "deps")))), .text_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "text"))))};
}


/// CppTemplateHead: fn [Text] -> Text
Text cpp_template_head_f(const Array<Text>& xs0) {
    {
        auto&& c0_0 = xs0;
        if (c0_0.size() == 0u) {
            return Text::lit("");
        }
    }
    {
        auto&& ps_p0 = xs0;
        return prism_rtl::cat("template <", crate::syntax::lexer::chars::join_f(crate::prelude::each(ps_p0, [&](const Text& p_p1) { return prism_rtl::cat("class ", p_p1); }), Text::lit(", ")), ">\n");
    }
}


/// GenericNamesOf: fn [((Text, [Text]))] -> [Text]
Array<Text> generic_names_of_f(const Array<std::tuple<Text, Array<Text>>>& gs_p0) {
    return crate::prelude::each(gs_p0, [&](const std::tuple<Text, Array<Text>>& _p0) {
        auto&& g_p1 = std::get<0>(_p0);
        return g_p1;
    });
}


/// HeadOf: fn Text, [Text] -> Text
Text head_of_f(const Text& name_p0, const Array<Text>& xs1) {
    {
        auto&& c0_1 = xs1;
        if (c0_1.size() == 0u) {
            return name_p0;
        }
    }
    {
        auto&& ps_p2 = xs1;
        return prism_rtl::cat(name_p0, "<", crate::syntax::lexer::chars::join_f(ps_p2, Text::lit(", ")), ">");
    }
}


/// CppParams: unbounded fn Cp, [((Text, OutTy))] -> Text
Text cpp_params_f(const crate::emit::cpp::Cp& cp_p0, const Array<std::tuple<Text, crate::lower::model::OutTy>>& ps_p1) {
    return crate::syntax::lexer::chars::join_f(crate::prelude::run_to_end(crate::prelude::each_job(ps_p1, ({
        auto cp_p0x = cp_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=, cp_p0x = std::move(cp_p0x)](std::tuple<Text, crate::lower::model::OutTy> p0) {
        return ({
            auto cp_p0xy = cp_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xy = std::move(cp_p0xy)]() {
            return ({
                auto [n_p2, t_p3] = p0;
                (crate::prelude::call_then(crate::emit::cpp::expr::start_param_type_f(cp_p0xy, t_p3), [=](Text param_type_f_1510) { return prism_rtl::finished(prism_rtl::cat(param_type_f_1510, " ", crate::emit::cpp::cpp_id_f(n_p2))); }));
            });
        })));
        });
    })));
    }))), Text::lit(", "));
}


prism_rtl::Turn<Text> CppParams::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& ps_p1 = this->ps_p1;
    auto cp_p0x = cp_p0;
    auto ps_p1x = ps_p1;
    return crate::prelude::call_value(crate::prelude::each_job(ps_p1x, ({
        auto cp_p0xx = cp_p0x;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=, cp_p0xx = std::move(cp_p0xx)](std::tuple<Text, crate::lower::model::OutTy> p0) {
        return ({
            auto cp_p0xxy = cp_p0xx;
            (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xxy = std::move(cp_p0xxy)]() {
            return ({
                auto [n_p2, t_p3] = p0;
                (crate::prelude::call_then(crate::emit::cpp::expr::start_param_type_f(cp_p0xxy, t_p3), [=](Text param_type_f_1510) { return prism_rtl::finished(prism_rtl::cat(param_type_f_1510, " ", crate::emit::cpp::cpp_id_f(n_p2))); }));
            });
        })));
        });
    })));
    })), [=](Array<Text> each_1487) { return prism_rtl::finished(crate::syntax::lexer::chars::join_f(each_1487, Text::lit(", "))); });
}


/// `Start CppParams, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_params_f(crate::emit::cpp::Cp cp_p0, Array<std::tuple<Text, crate::lower::model::OutTy>> ps_p1) {
    return prism_rtl::make_rc<CppParams>(cp_p0, ps_p1);
}


/// FnSignature: unbounded fn Cp, FnDef -> Text
Text fn_signature_f(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::FnDef& f_p1) {
    return prism_rtl::cat(cpp_template_head_f(generic_names_of_f(f_p1.generics_p)), crate::emit::cpp::cpp_type_f(cp_p0, f_p1.ret_p), " ", crate::emit::cpp::cpp_id_f(f_p1.name_p), "(", cpp_params_f(cp_p0, f_p1.params_p), ")");
}


prism_rtl::Turn<Text> FnSignature::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& f_p1 = this->f_p1;
    auto cp_p0x = cp_p0;
    auto f_p1x = f_p1;
    return crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0x, prism_rtl::deref(f_p1x).ret_p), [=](Text cpp_type_f_1741) { return crate::prelude::call_then(start_cpp_params_f(cp_p0x, prism_rtl::deref(f_p1x).params_p), [=](Text cpp_params_f_1776) { return prism_rtl::finished(prism_rtl::cat(cpp_template_head_f(generic_names_of_f(prism_rtl::deref(f_p1x).generics_p)), cpp_type_f_1741, " ", crate::emit::cpp::cpp_id_f(prism_rtl::deref(f_p1x).name_p), "(", cpp_params_f_1776, ")")); }); });
}


/// `Start FnSignature, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_fn_signature_f(crate::emit::cpp::Cp cp_p0, crate::lower::model::FnDef f_p1) {
    return prism_rtl::make_rc<FnSignature>(cp_p0, f_p1);
}


/// FnDefinition: unbounded fn Cp, FnDef -> Text
Text fn_definition_f(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::FnDef& f_p1) {
    return crate::emit::cpp::templates::items::cpp_function_f(cpp_doc_f(f_p1.doc_p), fn_signature_f(cp_p0, f_p1), crate::emit::cpp::stmts::cpp_body_f(with_params_f(cp_p0, f_p1.params_p), f_p1.body_p));
}


prism_rtl::Turn<Text> FnDefinition::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& f_p1 = this->f_p1;
    auto cp_p0x = cp_p0;
    auto f_p1x = f_p1;
    return crate::prelude::call_then(start_fn_signature_f(cp_p0x, f_p1x), [=](Text fn_signature_f_1901) { return crate::prelude::call_then(crate::emit::cpp::stmts::start_cpp_body_f(with_params_f(cp_p0x, prism_rtl::deref(f_p1x).params_p), prism_rtl::deref(f_p1x).body_p), [=](Text cpp_body_f_1922) { return prism_rtl::finished(crate::emit::cpp::templates::items::cpp_function_f(cpp_doc_f(prism_rtl::deref(f_p1x).doc_p), fn_signature_f_1901, cpp_body_f_1922)); }); });
}


/// `Start FnDefinition, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_fn_definition_f(crate::emit::cpp::Cp cp_p0, crate::lower::model::FnDef f_p1) {
    return prism_rtl::make_rc<FnDefinition>(cp_p0, f_p1);
}


/// WithParams: fn Cp, [((Text, OutTy))] -> Cp
crate::emit::cpp::Cp with_params_f(const crate::emit::cpp::Cp& cp_p0, const Array<std::tuple<Text, crate::lower::model::OutTy>>& ps_p1) {
    return crate::prelude::fold(ps_p1, cp_p0, [&](const crate::emit::cpp::Cp& c_p2, const std::tuple<Text, crate::lower::model::OutTy>& _p1) {
        auto&& n_p3 = std::get<0>(_p1);
        auto&& t_p4 = std::get<1>(_p1);
        return ({
            crate::emit::cpp::Cp this_ = c_p2;
            this_.pointers_p = crate::prelude::insert(this_.pointers_p, n_p3, crate::emit::cpp::expr::is_pointer_ty_f(c_p2, crate::emit::cpp::expr::unref_f(t_p4)));
            this_.local_types_p = crate::prelude::insert(this_.local_types_p, n_p3, t_p4);
            (std::move(this_));
        });
    });
}


/// ValueDeps: unbounded fn Cp, OutTy -> [Text]
Array<Text> value_deps_f(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::OutTy& t_p1) {
    if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t_p1)) {
        auto&& n_p2 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p1).a0;
        auto&& args_p3 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p1).a1;
        auto own_p4 = ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = crate::emit::cpp::type_of_o(cp_p0, n_p2);
            if (prism_rtl::is_some(_m)) {
                auto&& info_p5 = prism_rtl::some_of(_m);
                _v.set(((((prism_rtl::deref(info_p5).kind_p == Text::lit("record")) || (prism_rtl::deref(info_p5).kind_p == Text::lit("newtype"))) || (prism_rtl::deref(info_p5).kind_p == Text::lit("unit"))) || (prism_rtl::deref(info_p5).kind_p == Text::lit("tag"))) || (prism_rtl::deref(info_p5).kind_p == Text::lit("choice"))
                    ? Array(std::vector{dep_path_f(cp_p0, n_p2)})
                    : Array<Text>{});
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(Array<Text>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        return crate::prelude::append(own_p4, crate::emit::cpp::patterns::concat2_f(crate::prelude::run_to_end(crate::prelude::each_job(args_p3, ({
            auto cp_p0x = cp_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(crate::lower::model::OutTy)>>(prism_rtl::rc([=, cp_p0x = std::move(cp_p0x)](crate::lower::model::OutTy p0) {
            return ({
                auto cp_p0xy = cp_p0x;
                (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xy = std::move(cp_p0xy)]() {
                return ({
                    auto a_p6 = p0;
                    (prism_rtl::more(prism_rtl::rc(ValueDeps(cp_p0xy, a_p6))));
                });
            })));
            });
        })));
        })))));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutOpt>(t_p1)) {
        auto&& i_p7 = prism_rtl::as<crate::lower::model::OutTy::OutOpt>(t_p1).a0;
        return value_deps_f(cp_p0, prism_rtl::deref(prism_rtl::deref(i_p7)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutRes>(t_p1)) {
        auto&& i_p8 = prism_rtl::as<crate::lower::model::OutTy::OutRes>(t_p1).a0;
        return value_deps_f(cp_p0, prism_rtl::deref(prism_rtl::deref(i_p8)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutCell>(t_p1)) {
        auto&& i_p9 = prism_rtl::as<crate::lower::model::OutTy::OutCell>(t_p1).a0;
        return value_deps_f(cp_p0, prism_rtl::deref(prism_rtl::deref(i_p9)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutTuple>(t_p1)) {
        auto&& ts_pa = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(t_p1).a0;
        return crate::emit::cpp::patterns::concat2_f(crate::prelude::run_to_end(crate::prelude::each_job(ts_pa, ({
            auto cp_p0x = cp_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(crate::lower::model::OutTy)>>(prism_rtl::rc([=, cp_p0x = std::move(cp_p0x)](crate::lower::model::OutTy p0) {
            return ({
                auto cp_p0xy = cp_p0x;
                (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xy = std::move(cp_p0xy)]() {
                return ({
                    auto a_pb = p0;
                    (prism_rtl::more(prism_rtl::rc(ValueDeps(cp_p0xy, a_pb))));
                });
            })));
            });
        })));
        }))));
    }
    {
        return Array<Text>{};
    }
}


prism_rtl::Turn<Array<Text>> ValueDeps::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& t_p1 = this->t_p1;
    return ({
        prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t_p1) ? ({
        auto&& n_p2 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p1).a0;
        auto&& args_p3 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p1).a1;
        ({
        auto own_p4 = ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = crate::emit::cpp::type_of_o(cp_p0, n_p2);
            if (prism_rtl::is_some(_m)) {
                auto&& info_p5 = prism_rtl::some_of(_m);
                _v.set(((((prism_rtl::deref(info_p5).kind_p == Text::lit("record")) || (prism_rtl::deref(info_p5).kind_p == Text::lit("newtype"))) || (prism_rtl::deref(info_p5).kind_p == Text::lit("unit"))) || (prism_rtl::deref(info_p5).kind_p == Text::lit("tag"))) || (prism_rtl::deref(info_p5).kind_p == Text::lit("choice"))
                    ? Array(std::vector{dep_path_f(cp_p0, n_p2)})
                    : Array<Text>{});
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(Array<Text>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto args_p3x = args_p3;
        auto cp_p0x = cp_p0;
        (crate::prelude::call_value(crate::prelude::each_job(args_p3x, ({
        auto cp_p0xx = cp_p0x;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(crate::lower::model::OutTy)>>(prism_rtl::rc([=, cp_p0xx = std::move(cp_p0xx)](crate::lower::model::OutTy p0) {
        return ({
            auto cp_p0xxy = cp_p0xx;
            (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xxy = std::move(cp_p0xxy)]() {
            return ({
                auto a_p6 = p0;
                (prism_rtl::more(prism_rtl::rc(ValueDeps(cp_p0xxy, a_p6))));
            });
        })));
        });
    })));
    })), [=, own_p4 = std::move(own_p4)](Array<Array<Text>> each_3884) { return prism_rtl::finished(crate::prelude::append(own_p4, crate::emit::cpp::patterns::concat2_f(each_3884))); }));
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutOpt>(t_p1) ? ({
        auto&& i_p7 = prism_rtl::as<crate::lower::model::OutTy::OutOpt>(t_p1).a0;
        prism_rtl::more(prism_rtl::rc(ValueDeps(cp_p0, prism_rtl::deref(prism_rtl::deref(i_p7)))));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutRes>(t_p1) ? ({
        auto&& i_p8 = prism_rtl::as<crate::lower::model::OutTy::OutRes>(t_p1).a0;
        prism_rtl::more(prism_rtl::rc(ValueDeps(cp_p0, prism_rtl::deref(prism_rtl::deref(i_p8)))));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutCell>(t_p1) ? ({
        auto&& i_p9 = prism_rtl::as<crate::lower::model::OutTy::OutCell>(t_p1).a0;
        prism_rtl::more(prism_rtl::rc(ValueDeps(cp_p0, prism_rtl::deref(prism_rtl::deref(i_p9)))));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutTuple>(t_p1) ? ({
        auto&& ts_pa = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(t_p1).a0;
        ({
        auto cp_p0x = cp_p0;
        auto ts_pax = ts_pa;
        (crate::prelude::call_value(crate::prelude::each_job(ts_pax, ({
        auto cp_p0xx = cp_p0x;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(crate::lower::model::OutTy)>>(prism_rtl::rc([=, cp_p0xx = std::move(cp_p0xx)](crate::lower::model::OutTy p0) {
        return ({
            auto cp_p0xxy = cp_p0xx;
            (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xxy = std::move(cp_p0xxy)]() {
            return ({
                auto a_pb = p0;
                (prism_rtl::more(prism_rtl::rc(ValueDeps(cp_p0xxy, a_pb))));
            });
        })));
        });
    })));
    })), [=](Array<Array<Text>> each_4035) { return prism_rtl::finished(crate::emit::cpp::patterns::concat2_f(each_4035)); }));
    });
    })
        : prism_rtl::finished(Array<Text>{});
    });
}


/// `Start ValueDeps, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_value_deps_f(crate::emit::cpp::Cp cp_p0, crate::lower::model::OutTy t_p1) {
    return prism_rtl::make_rc<ValueDeps>(cp_p0, t_p1);
}


/// DepPath: fn Cp, Text -> Text
Text dep_path_f(const crate::emit::cpp::Cp& cp_p0, const Text& n_p1) {
    auto abs_p2 = crate::emit::cpp::absolute_f(cp_p0, n_p1);
    auto q_p3 = crate::syntax::lexer::chars::drop_prefix_f(n_p1, Text::lit("crate::"));
    auto&& _m = crate::prelude::get(cp_p0.types_p, abs_p2);
    if (prism_rtl::is_some(_m)) {
        return abs_p2;
    }
    if (prism_rtl::is_none(_m)) {
        return q_p3;
    }
    prism_rtl::unreachable("no arm matched");
}


/// Behind: unbounded fn Cp, OutTy -> Bool
bool behind_f(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::OutTy& t_p1) {
    if (prism_rtl::is<crate::lower::model::OutTy::OutRc>(t_p1)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutOpt>(t_p1)) {
        auto&& i_p2 = prism_rtl::as<crate::lower::model::OutTy::OutOpt>(t_p1).a0;
        return behind_f(cp_p0, prism_rtl::deref(prism_rtl::deref(i_p2)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutRes>(t_p1)) {
        auto&& i_p3 = prism_rtl::as<crate::lower::model::OutTy::OutRes>(t_p1).a0;
        return behind_f(cp_p0, prism_rtl::deref(prism_rtl::deref(i_p3)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutCell>(t_p1)) {
        auto&& i_p4 = prism_rtl::as<crate::lower::model::OutTy::OutCell>(t_p1).a0;
        return behind_f(cp_p0, prism_rtl::deref(prism_rtl::deref(i_p4)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutTuple>(t_p1)) {
        auto&& ts_p5 = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(t_p1).a0;
        return crate::prelude::run_to_end(crate::prelude::fold_job(ts_p5, false, ({
            auto cp_p0x = cp_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=, cp_p0x = std::move(cp_p0x)](std::tuple<bool, crate::lower::model::OutTy> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto cp_p0xy = cp_p0x;
                (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xy = std::move(cp_p0xy)]() {
                return ({
                    auto f_p6 = p0;
                    auto x_p7 = p1;
                    (prism_rtl::finished(std::move(f_p6) || behind_f(cp_p0xy, x_p7)));
                });
            })));
            });
        })));
        })));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutArray>(t_p1)) {
        auto&& i_p8 = prism_rtl::as<crate::lower::model::OutTy::OutArray>(t_p1).a0;
        return names_program_type_f(cp_p0, prism_rtl::deref(prism_rtl::deref(i_p8)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutMap>(t_p1)) {
        auto&& k_p9 = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t_p1).a0;
        auto&& v_pa = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t_p1).a1;
        return names_program_type_f(cp_p0, prism_rtl::deref(prism_rtl::deref(k_p9))) || names_program_type_f(cp_p0, prism_rtl::deref(prism_rtl::deref(v_pa)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutFn>(t_p1)) {
        auto&& ps_pb = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t_p1).a0;
        auto&& r_pc = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t_p1).a1;
        return crate::prelude::run_to_end(crate::prelude::fold_job(ps_pb, names_program_type_f(cp_p0, prism_rtl::deref(prism_rtl::deref(r_pc))), ({
            auto cp_p0x = cp_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=, cp_p0x = std::move(cp_p0x)](std::tuple<bool, crate::lower::model::OutTy> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto cp_p0xy = cp_p0x;
                (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xy = std::move(cp_p0xy)]() {
                return ({
                    auto f_pd = p0;
                    auto x_pe = p1;
                    (prism_rtl::finished(std::move(f_pd) || names_program_type_f(cp_p0xy, x_pe)));
                });
            })));
            });
        })));
        })));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutDyn>(t_p1)) {
        auto&& i_pf = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(t_p1).a0;
        return names_program_type_f(cp_p0, prism_rtl::deref(prism_rtl::deref(i_pf)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutEvent>(t_p1)) {
        auto&& i_pg = prism_rtl::as<crate::lower::model::OutTy::OutEvent>(t_p1).a0;
        return names_program_type_f(cp_p0, prism_rtl::deref(prism_rtl::deref(i_pg)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t_p1)) {
        auto&& args_ph = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p1).a1;
        return crate::prelude::run_to_end(crate::prelude::fold_job(args_ph, false, ({
            auto cp_p0x = cp_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=, cp_p0x = std::move(cp_p0x)](std::tuple<bool, crate::lower::model::OutTy> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto cp_p0xy = cp_p0x;
                (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xy = std::move(cp_p0xy)]() {
                return ({
                    auto f_pi = p0;
                    auto x_pj = p1;
                    (prism_rtl::finished(std::move(f_pi) || behind_f(cp_p0xy, x_pj)));
                });
            })));
            });
        })));
        })));
    }
    {
        return false;
    }
}


prism_rtl::Turn<bool> Behind::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& t_p1 = this->t_p1;
    return ({
        prism_rtl::is<crate::lower::model::OutTy::OutRc>(t_p1) ? prism_rtl::finished(true)
        : prism_rtl::is<crate::lower::model::OutTy::OutOpt>(t_p1) ? ({
        auto&& i_p2 = prism_rtl::as<crate::lower::model::OutTy::OutOpt>(t_p1).a0;
        prism_rtl::more(prism_rtl::rc(Behind(cp_p0, prism_rtl::deref(prism_rtl::deref(i_p2)))));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutRes>(t_p1) ? ({
        auto&& i_p3 = prism_rtl::as<crate::lower::model::OutTy::OutRes>(t_p1).a0;
        prism_rtl::more(prism_rtl::rc(Behind(cp_p0, prism_rtl::deref(prism_rtl::deref(i_p3)))));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutCell>(t_p1) ? ({
        auto&& i_p4 = prism_rtl::as<crate::lower::model::OutTy::OutCell>(t_p1).a0;
        prism_rtl::more(prism_rtl::rc(Behind(cp_p0, prism_rtl::deref(prism_rtl::deref(i_p4)))));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutTuple>(t_p1) ? ({
        auto&& ts_p5 = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(t_p1).a0;
        crate::prelude::fold_job(ts_p5, false, ({
        auto cp_p0x = cp_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=, cp_p0x = std::move(cp_p0x)](std::tuple<bool, crate::lower::model::OutTy> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto cp_p0xy = cp_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xy = std::move(cp_p0xy)]() {
            return ({
                auto f_p6 = p0;
                auto x_p7 = p1;
                (prism_rtl::finished(std::move(f_p6) || behind_f(cp_p0xy, x_p7)));
            });
        })));
        });
    })));
    }))->cycle();
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutArray>(t_p1) ? ({
        auto&& i_p8 = prism_rtl::as<crate::lower::model::OutTy::OutArray>(t_p1).a0;
        prism_rtl::more(prism_rtl::rc(NamesProgramType(cp_p0, prism_rtl::deref(prism_rtl::deref(i_p8)))));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutMap>(t_p1) ? ({
        auto&& k_p9 = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t_p1).a0;
        auto&& v_pa = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t_p1).a1;
        ({
        auto cp_p0x = cp_p0;
        auto k_p9x = prism_rtl::deref(prism_rtl::deref(k_p9));
        auto v_pax = prism_rtl::deref(prism_rtl::deref(v_pa));
        (crate::prelude::call_then(start_names_program_type_f(cp_p0x, k_p9x), [=, v_pax = std::move(v_pax)](bool names_program_type_f_5369) { return prism_rtl::finished(names_program_type_f_5369 || names_program_type_f(cp_p0x, v_pax)); }));
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutFn>(t_p1) ? ({
        auto&& ps_pb = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t_p1).a0;
        auto&& r_pc = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t_p1).a1;
        ({
        auto cp_p0x = cp_p0;
        auto ps_pbx = ps_pb;
        auto r_pcx = prism_rtl::deref(prism_rtl::deref(r_pc));
        (crate::prelude::call_then(start_names_program_type_f(cp_p0x, r_pcx), [=, ps_pbx = std::move(ps_pbx)](bool names_program_type_f_5446) {
        return crate::prelude::fold_job(ps_pbx, names_program_type_f_5446, ({
            auto cp_p0xx = cp_p0x;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=, cp_p0xx = std::move(cp_p0xx)](std::tuple<bool, crate::lower::model::OutTy> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto cp_p0xxy = cp_p0xx;
                (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xxy = std::move(cp_p0xxy)]() {
                return ({
                    auto f_pd = p0;
                    auto x_pe = p1;
                    (prism_rtl::finished(std::move(f_pd) || names_program_type_f(cp_p0xxy, x_pe)));
                });
            })));
            });
        })));
        }))->cycle();
    }));
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutDyn>(t_p1) ? ({
        auto&& i_pf = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(t_p1).a0;
        prism_rtl::more(prism_rtl::rc(NamesProgramType(cp_p0, prism_rtl::deref(prism_rtl::deref(i_pf)))));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutEvent>(t_p1) ? ({
        auto&& i_pg = prism_rtl::as<crate::lower::model::OutTy::OutEvent>(t_p1).a0;
        prism_rtl::more(prism_rtl::rc(NamesProgramType(cp_p0, prism_rtl::deref(prism_rtl::deref(i_pg)))));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t_p1) ? ({
        auto&& args_ph = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p1).a1;
        crate::prelude::fold_job(args_ph, false, ({
        auto cp_p0x = cp_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=, cp_p0x = std::move(cp_p0x)](std::tuple<bool, crate::lower::model::OutTy> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto cp_p0xy = cp_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xy = std::move(cp_p0xy)]() {
            return ({
                auto f_pi = p0;
                auto x_pj = p1;
                (prism_rtl::finished(std::move(f_pi) || behind_f(cp_p0xy, x_pj)));
            });
        })));
        });
    })));
    }))->cycle();
    })
        : prism_rtl::finished(false);
    });
}


/// `Start Behind, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_behind_f(crate::emit::cpp::Cp cp_p0, crate::lower::model::OutTy t_p1) {
    return prism_rtl::make_rc<Behind>(cp_p0, t_p1);
}


/// NamesProgramType: unbounded fn Cp, OutTy -> Bool
bool names_program_type_f(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::OutTy& t_p1) {
    if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t_p1)) {
        auto&& n_p2 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p1).a0;
        auto&& args_p3 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p1).a1;
        auto own_p4 = ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            auto&& _m = crate::emit::cpp::type_of_o(cp_p0, n_p2);
            if (prism_rtl::is_some(_m)) {
                auto&& info_p5 = prism_rtl::some_of(_m);
                _v.set((prism_rtl::deref(info_p5).kind_p != Text::lit("node")) && (prism_rtl::deref(info_p5).kind_p != Text::lit("job")));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(false);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        return std::move(own_p4) || crate::prelude::run_to_end(crate::prelude::fold_job(args_p3, false, ({
            auto cp_p0x = cp_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=, cp_p0x = std::move(cp_p0x)](std::tuple<bool, crate::lower::model::OutTy> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto cp_p0xy = cp_p0x;
                (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xy = std::move(cp_p0xy)]() {
                return ({
                    auto f_p6 = p0;
                    auto x_p7 = p1;
                    (prism_rtl::finished(std::move(f_p6) || names_program_type_f(cp_p0xy, x_p7)));
                });
            })));
            });
        })));
        })));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutOpt>(t_p1)) {
        auto&& i_p8 = prism_rtl::as<crate::lower::model::OutTy::OutOpt>(t_p1).a0;
        return names_program_type_f(cp_p0, prism_rtl::deref(prism_rtl::deref(i_p8)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutRes>(t_p1)) {
        auto&& i_p9 = prism_rtl::as<crate::lower::model::OutTy::OutRes>(t_p1).a0;
        return names_program_type_f(cp_p0, prism_rtl::deref(prism_rtl::deref(i_p9)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutRc>(t_p1)) {
        auto&& i_pa = prism_rtl::as<crate::lower::model::OutTy::OutRc>(t_p1).a0;
        return names_program_type_f(cp_p0, prism_rtl::deref(prism_rtl::deref(i_pa)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutCell>(t_p1)) {
        auto&& i_pb = prism_rtl::as<crate::lower::model::OutTy::OutCell>(t_p1).a0;
        return names_program_type_f(cp_p0, prism_rtl::deref(prism_rtl::deref(i_pb)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutArray>(t_p1)) {
        auto&& i_pc = prism_rtl::as<crate::lower::model::OutTy::OutArray>(t_p1).a0;
        return names_program_type_f(cp_p0, prism_rtl::deref(prism_rtl::deref(i_pc)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutMap>(t_p1)) {
        auto&& k_pd = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t_p1).a0;
        auto&& v_pe = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t_p1).a1;
        return names_program_type_f(cp_p0, prism_rtl::deref(prism_rtl::deref(k_pd))) || names_program_type_f(cp_p0, prism_rtl::deref(prism_rtl::deref(v_pe)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutTuple>(t_p1)) {
        auto&& ts_pf = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(t_p1).a0;
        return crate::prelude::run_to_end(crate::prelude::fold_job(ts_pf, false, ({
            auto cp_p0x = cp_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=, cp_p0x = std::move(cp_p0x)](std::tuple<bool, crate::lower::model::OutTy> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto cp_p0xy = cp_p0x;
                (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xy = std::move(cp_p0xy)]() {
                return ({
                    auto f_pg = p0;
                    auto x_ph = p1;
                    (prism_rtl::finished(std::move(f_pg) || names_program_type_f(cp_p0xy, x_ph)));
                });
            })));
            });
        })));
        })));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutFn>(t_p1)) {
        auto&& ps_pi = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t_p1).a0;
        auto&& r_pj = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t_p1).a1;
        return crate::prelude::run_to_end(crate::prelude::fold_job(ps_pi, names_program_type_f(cp_p0, prism_rtl::deref(prism_rtl::deref(r_pj))), ({
            auto cp_p0x = cp_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=, cp_p0x = std::move(cp_p0x)](std::tuple<bool, crate::lower::model::OutTy> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto cp_p0xy = cp_p0x;
                (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xy = std::move(cp_p0xy)]() {
                return ({
                    auto f_pk = p0;
                    auto x_pl = p1;
                    (prism_rtl::finished(std::move(f_pk) || names_program_type_f(cp_p0xy, x_pl)));
                });
            })));
            });
        })));
        })));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutDyn>(t_p1)) {
        auto&& i_pm = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(t_p1).a0;
        return names_program_type_f(cp_p0, prism_rtl::deref(prism_rtl::deref(i_pm)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutEvent>(t_p1)) {
        auto&& i_pn = prism_rtl::as<crate::lower::model::OutTy::OutEvent>(t_p1).a0;
        return names_program_type_f(cp_p0, prism_rtl::deref(prism_rtl::deref(i_pn)));
    }
    {
        return false;
    }
}


prism_rtl::Turn<bool> NamesProgramType::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& t_p1 = this->t_p1;
    return ({
        prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t_p1) ? ({
        auto&& n_p2 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p1).a0;
        auto&& args_p3 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p1).a1;
        ({
        auto own_p4 = ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            auto&& _m = crate::emit::cpp::type_of_o(cp_p0, n_p2);
            if (prism_rtl::is_some(_m)) {
                auto&& info_p5 = prism_rtl::some_of(_m);
                _v.set((prism_rtl::deref(info_p5).kind_p != Text::lit("node")) && (prism_rtl::deref(info_p5).kind_p != Text::lit("job")));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(false);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        (prism_rtl::finished(std::move(own_p4) || crate::prelude::run_to_end(crate::prelude::fold_job(args_p3, false, ({
        auto cp_p0x = cp_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=, cp_p0x = std::move(cp_p0x)](std::tuple<bool, crate::lower::model::OutTy> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto cp_p0xy = cp_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xy = std::move(cp_p0xy)]() {
            return ({
                auto f_p6 = p0;
                auto x_p7 = p1;
                (prism_rtl::finished(std::move(f_p6) || names_program_type_f(cp_p0xy, x_p7)));
            });
        })));
        });
    })));
    })))));
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutOpt>(t_p1) ? ({
        auto&& i_p8 = prism_rtl::as<crate::lower::model::OutTy::OutOpt>(t_p1).a0;
        prism_rtl::more(prism_rtl::rc(NamesProgramType(cp_p0, prism_rtl::deref(prism_rtl::deref(i_p8)))));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutRes>(t_p1) ? ({
        auto&& i_p9 = prism_rtl::as<crate::lower::model::OutTy::OutRes>(t_p1).a0;
        prism_rtl::more(prism_rtl::rc(NamesProgramType(cp_p0, prism_rtl::deref(prism_rtl::deref(i_p9)))));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutRc>(t_p1) ? ({
        auto&& i_pa = prism_rtl::as<crate::lower::model::OutTy::OutRc>(t_p1).a0;
        prism_rtl::more(prism_rtl::rc(NamesProgramType(cp_p0, prism_rtl::deref(prism_rtl::deref(i_pa)))));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutCell>(t_p1) ? ({
        auto&& i_pb = prism_rtl::as<crate::lower::model::OutTy::OutCell>(t_p1).a0;
        prism_rtl::more(prism_rtl::rc(NamesProgramType(cp_p0, prism_rtl::deref(prism_rtl::deref(i_pb)))));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutArray>(t_p1) ? ({
        auto&& i_pc = prism_rtl::as<crate::lower::model::OutTy::OutArray>(t_p1).a0;
        prism_rtl::more(prism_rtl::rc(NamesProgramType(cp_p0, prism_rtl::deref(prism_rtl::deref(i_pc)))));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutMap>(t_p1) ? ({
        auto&& k_pd = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t_p1).a0;
        auto&& v_pe = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t_p1).a1;
        ({
        auto cp_p0x = cp_p0;
        auto k_pdx = prism_rtl::deref(prism_rtl::deref(k_pd));
        auto v_pex = prism_rtl::deref(prism_rtl::deref(v_pe));
        (crate::prelude::call_then(start_names_program_type_f(cp_p0x, k_pdx), [=, v_pex = std::move(v_pex)](bool names_program_type_f_6249) { return prism_rtl::finished(names_program_type_f_6249 || names_program_type_f(cp_p0x, v_pex)); }));
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutTuple>(t_p1) ? ({
        auto&& ts_pf = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(t_p1).a0;
        crate::prelude::fold_job(ts_pf, false, ({
        auto cp_p0x = cp_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=, cp_p0x = std::move(cp_p0x)](std::tuple<bool, crate::lower::model::OutTy> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto cp_p0xy = cp_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xy = std::move(cp_p0xy)]() {
            return ({
                auto f_pg = p0;
                auto x_ph = p1;
                (prism_rtl::finished(std::move(f_pg) || names_program_type_f(cp_p0xy, x_ph)));
            });
        })));
        });
    })));
    }))->cycle();
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutFn>(t_p1) ? ({
        auto&& ps_pi = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t_p1).a0;
        auto&& r_pj = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t_p1).a1;
        ({
        auto cp_p0x = cp_p0;
        auto ps_pix = ps_pi;
        auto r_pjx = prism_rtl::deref(prism_rtl::deref(r_pj));
        (crate::prelude::call_then(start_names_program_type_f(cp_p0x, r_pjx), [=, ps_pix = std::move(ps_pix)](bool names_program_type_f_6395) {
        return crate::prelude::fold_job(ps_pix, names_program_type_f_6395, ({
            auto cp_p0xx = cp_p0x;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=, cp_p0xx = std::move(cp_p0xx)](std::tuple<bool, crate::lower::model::OutTy> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto cp_p0xxy = cp_p0xx;
                (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xxy = std::move(cp_p0xxy)]() {
                return ({
                    auto f_pk = p0;
                    auto x_pl = p1;
                    (prism_rtl::finished(std::move(f_pk) || names_program_type_f(cp_p0xxy, x_pl)));
                });
            })));
            });
        })));
        }))->cycle();
    }));
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutDyn>(t_p1) ? ({
        auto&& i_pm = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(t_p1).a0;
        prism_rtl::more(prism_rtl::rc(NamesProgramType(cp_p0, prism_rtl::deref(prism_rtl::deref(i_pm)))));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutEvent>(t_p1) ? ({
        auto&& i_pn = prism_rtl::as<crate::lower::model::OutTy::OutEvent>(t_p1).a0;
        prism_rtl::more(prism_rtl::rc(NamesProgramType(cp_p0, prism_rtl::deref(prism_rtl::deref(i_pn)))));
    })
        : prism_rtl::finished(false);
    });
}


/// `Start NamesProgramType, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_names_program_type_f(crate::emit::cpp::Cp cp_p0, crate::lower::model::OutTy t_p1) {
    return prism_rtl::make_rc<NamesProgramType>(cp_p0, t_p1);
}


/// let noParts
Parts no_parts_p() {
    return Parts{.forward_p = Array<Text>{}, .values_p = Array<ValueDecl>{}, .protos_p = Array<Text>{}, .classes_p = Array<Text>{}, .outer_p = Array<Text>{}, .generic_p = Array<Text>{}, .defs_p = Array<Text>{}};
}


/// JoinParts: fn Parts, Parts -> Parts
Parts join_parts_f(const Parts& a_p0, const Parts& b_p1) {
    return Parts{.forward_p = crate::prelude::append(a_p0.forward_p, b_p1.forward_p), .values_p = crate::prelude::append(a_p0.values_p, b_p1.values_p), .protos_p = crate::prelude::append(a_p0.protos_p, b_p1.protos_p), .classes_p = crate::prelude::append(a_p0.classes_p, b_p1.classes_p), .outer_p = crate::prelude::append(a_p0.outer_p, b_p1.outer_p), .generic_p = crate::prelude::append(a_p0.generic_p, b_p1.generic_p), .defs_p = crate::prelude::append(a_p0.defs_p, b_p1.defs_p)};
}


/// ItemParts: unbounded fn Cp, Item -> Parts
Parts item_parts_f(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::Item& it_p1) {
    if (prism_rtl::is<crate::lower::model::Item::ItType>(it_p1)) {
        auto&& t_p2 = prism_rtl::as<crate::lower::model::Item::ItType>(it_p1).a0;
        return type_parts_f(cp_p0, t_p2);
    }
    if (prism_rtl::is<crate::lower::model::Item::ItTag>(it_p1)) {
        auto&& t_p3 = prism_rtl::as<crate::lower::model::Item::ItTag>(it_p1).a0;
        return tag_parts_f(cp_p0, t_p3);
    }
    if (prism_rtl::is<crate::lower::model::Item::ItRow>(it_p1)) {
        auto&& r_p4 = prism_rtl::as<crate::lower::model::Item::ItRow>(it_p1).a0;
        return row_parts_f(cp_p0, cp_p0.home_p, r_p4);
    }
    if (prism_rtl::is<crate::lower::model::Item::ItFn>(it_p1)) {
        auto&& f_p5 = prism_rtl::as<crate::lower::model::Item::ItFn>(it_p1).a0;
        return fn_parts_f(cp_p0, f_p5);
    }
    if (prism_rtl::is<crate::lower::model::Item::ItJob>(it_p1)) {
        auto&& j_p6 = prism_rtl::as<crate::lower::model::Item::ItJob>(it_p1).a0;
        return job_parts_f(cp_p0, j_p6);
    }
    if (prism_rtl::is<crate::lower::model::Item::ItNode>(it_p1)) {
        auto&& n_p7 = prism_rtl::as<crate::lower::model::Item::ItNode>(it_p1).a0;
        return crate::emit::cpp::program::node_parts_f(cp_p0, n_p7);
    }
    if (prism_rtl::is<crate::lower::model::Item::ItTrait>(it_p1)) {
        auto&& t_p8 = prism_rtl::as<crate::lower::model::Item::ItTrait>(it_p1).a0;
        return trait_parts_f(cp_p0, t_p8);
    }
    if (prism_rtl::is<crate::lower::model::Item::ItImpl>(it_p1)) {
        auto&& i_p9 = prism_rtl::as<crate::lower::model::Item::ItImpl>(it_p1).a0;
        return impl_parts_f(cp_p0, i_p9);
    }
    if (prism_rtl::is<crate::lower::model::Item::ItNote>(it_p1)) {
        auto&& t_pa = prism_rtl::as<crate::lower::model::Item::ItNote>(it_p1).a0;
        return protos_defs_f(Array<Text>{}, Array(std::vector{prism_rtl::cat("// ", t_pa)}));
    }
    if (prism_rtl::is<crate::lower::model::Item::ItRefused>(it_p1)) {
        auto&& t_pb = prism_rtl::as<crate::lower::model::Item::ItRefused>(it_p1).a0;
        return protos_defs_f(Array<Text>{}, Array(std::vector{prism_rtl::cat("compile_error!(\"", crate::lower::expr::lowering_refusal_p(), crate::lower::expr::escape_f(t_pb), "\");")}));
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Parts> ItemParts::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& it_p1 = this->it_p1;
    return ({
        prism_rtl::is<crate::lower::model::Item::ItType>(it_p1) ? ({
        auto&& t_p2 = prism_rtl::as<crate::lower::model::Item::ItType>(it_p1).a0;
        prism_rtl::more(prism_rtl::rc(TypeParts(cp_p0, t_p2)));
    })
        : prism_rtl::is<crate::lower::model::Item::ItTag>(it_p1) ? ({
        auto&& t_p3 = prism_rtl::as<crate::lower::model::Item::ItTag>(it_p1).a0;
        prism_rtl::more(prism_rtl::rc(TagParts(cp_p0, t_p3)));
    })
        : prism_rtl::is<crate::lower::model::Item::ItRow>(it_p1) ? ({
        auto&& r_p4 = prism_rtl::as<crate::lower::model::Item::ItRow>(it_p1).a0;
        prism_rtl::more(prism_rtl::rc(RowParts(cp_p0, prism_rtl::deref(cp_p0).home_p, r_p4)));
    })
        : prism_rtl::is<crate::lower::model::Item::ItFn>(it_p1) ? ({
        auto&& f_p5 = prism_rtl::as<crate::lower::model::Item::ItFn>(it_p1).a0;
        prism_rtl::more(prism_rtl::rc(FnParts(cp_p0, f_p5)));
    })
        : prism_rtl::is<crate::lower::model::Item::ItJob>(it_p1) ? ({
        auto&& j_p6 = prism_rtl::as<crate::lower::model::Item::ItJob>(it_p1).a0;
        prism_rtl::more(prism_rtl::rc(JobParts(cp_p0, j_p6)));
    })
        : prism_rtl::is<crate::lower::model::Item::ItNode>(it_p1) ? ({
        auto&& n_p7 = prism_rtl::as<crate::lower::model::Item::ItNode>(it_p1).a0;
        prism_rtl::more(prism_rtl::rc(crate::emit::cpp::program::NodeParts(cp_p0, n_p7)));
    })
        : prism_rtl::is<crate::lower::model::Item::ItTrait>(it_p1) ? ({
        auto&& t_p8 = prism_rtl::as<crate::lower::model::Item::ItTrait>(it_p1).a0;
        prism_rtl::more(prism_rtl::rc(TraitParts(cp_p0, t_p8)));
    })
        : prism_rtl::is<crate::lower::model::Item::ItImpl>(it_p1) ? ({
        auto&& i_p9 = prism_rtl::as<crate::lower::model::Item::ItImpl>(it_p1).a0;
        prism_rtl::more(prism_rtl::rc(ImplParts(cp_p0, i_p9)));
    })
        : prism_rtl::is<crate::lower::model::Item::ItNote>(it_p1) ? ({
        auto&& t_pa = prism_rtl::as<crate::lower::model::Item::ItNote>(it_p1).a0;
        prism_rtl::finished(protos_defs_f(Array<Text>{}, Array(std::vector{prism_rtl::cat("// ", t_pa)})));
    })
        : prism_rtl::is<crate::lower::model::Item::ItRefused>(it_p1) ? ({
        auto&& t_pb = prism_rtl::as<crate::lower::model::Item::ItRefused>(it_p1).a0;
        prism_rtl::finished(protos_defs_f(Array<Text>{}, Array(std::vector{prism_rtl::cat("compile_error!(\"", crate::lower::expr::lowering_refusal_p(), crate::lower::expr::escape_f(t_pb), "\");")})));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ItemParts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Parts> start_item_parts_f(crate::emit::cpp::Cp cp_p0, crate::lower::model::Item it_p1) {
    return prism_rtl::make_rc<ItemParts>(cp_p0, it_p1);
}


/// FnParts: unbounded fn Cp, FnDef -> Parts
Parts fn_parts_f(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::FnDef& f_p1) {
    return crate::prelude::len(f_p1.generics_p) > Nat(0u)
        ? ({
        Parts this_ = generic_only_f(Array(std::vector{fn_definition_f(cp_p0, f_p1)}));
        this_.protos_p = Array(std::vector{prism_rtl::cat(fn_signature_f(cp_p0, f_p1), ";")});
        (std::move(this_));
    })
        : protos_defs_f(Array(std::vector{prism_rtl::cat(fn_signature_f(cp_p0, f_p1), ";")}), Array(std::vector{fn_definition_f(cp_p0, f_p1)}));
}


prism_rtl::Turn<Parts> FnParts::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& f_p1 = this->f_p1;
    return crate::prelude::len(prism_rtl::deref(f_p1).generics_p) > Nat(0u)
        ? prism_rtl::finished(({
        Parts this_ = generic_only_f(Array(std::vector{fn_definition_f(cp_p0, f_p1)}));
        this_.protos_p = Array(std::vector{prism_rtl::cat(fn_signature_f(cp_p0, f_p1), ";")});
        (std::move(this_));
    }))
        : ({
        auto cp_p0x = cp_p0;
        auto f_p1x = f_p1;
        (crate::prelude::call_then(start_fn_signature_f(cp_p0x, f_p1x), [=](Text fn_signature_f_7638) { return crate::prelude::call_then(start_fn_definition_f(cp_p0x, f_p1x), [=](Text fn_definition_f_7665) { return prism_rtl::finished(protos_defs_f(Array(std::vector{prism_rtl::cat(fn_signature_f_7638, ";")}), Array(std::vector{fn_definition_f_7665}))); }); }));
    });
}


/// `Start FnParts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Parts> start_fn_parts_f(crate::emit::cpp::Cp cp_p0, crate::lower::model::FnDef f_p1) {
    return prism_rtl::make_rc<FnParts>(cp_p0, f_p1);
}


/// CppDoc: fn Text -> Text
Text cpp_doc_f(const Text& text_p0) {
    return text_p0 == Text::lit("")
        ? Text::lit("")
        : crate::prelude::concat(crate::prelude::each(crate::prelude::split_on(text_p0, Text::lit("\n")), [&](const Text& l_p1) {
        return l_p1 == Text::lit("")
            ? Text::lit("///\n")
            : prism_rtl::cat("/// ", l_p1, "\n");
    }));
}


/// CppSourceDoc: fn Text, Text -> Text
Text cpp_source_doc_f(const Text& lead_p0, const Text& source_p1) {
    auto quoted_p2 = crate::prelude::concat(crate::prelude::each(crate::prelude::split_on(source_p1, Text::lit("\n")), [&](const Text& l_p3) {
        return l_p3 == Text::lit("")
            ? Text::lit("///\n")
            : prism_rtl::cat("/// ", l_p3, "\n");
    }));
    return source_p1 == Text::lit("")
        ? cpp_doc_f(lead_p0)
        : lead_p0 == Text::lit("")
        ? prism_rtl::cat("/// ```prism\n", quoted_p2, "/// ```\n")
        : prism_rtl::cat("/// ", lead_p0, "\n///\n/// ```prism\n", quoted_p2, "/// ```\n");
}


/// TypeParts: unbounded fn Cp, TyDef -> Parts
Parts type_parts_f(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::TyDef& t_p1) {
    auto eq_p2 = t_p1.eq_p;
    auto ord_p3 = t_p1.ord_p;
    auto gens_p4 = cpp_template_head_f(t_p1.params_p);
    auto head_p5 = head_of_f(t_p1.name_p, t_p1.params_p);
    auto doc_p6 = cpp_source_doc_f(prism_rtl::cat("`", t_p1.prism_p, "`:"), t_p1.doc_p);
    auto members_p7 = members_f(t_p1.show_p != crate::lower::model::Shown(crate::lower::model::Shown::NotShown{}), t_p1.pod_p, head_p5);
    auto generic_p8 = crate::prelude::len(t_p1.params_p) > Nat(0u);
    auto fwd_p9 = prism_rtl::cat(gens_p4, t_p1.shape_p == crate::lower::model::TyShape(crate::lower::model::TyShape::ShapeChoice{})
        ? Text::lit("class")
        : Text::lit("struct"), " ", t_p1.name_p, ";");
    auto deps_pa = crate::emit::cpp::patterns::concat2_f(crate::prelude::run_to_end(crate::prelude::each_job(t_p1.cases_p, ({
        auto cp_p0x = cp_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(crate::lower::model::CaseDef)>>(prism_rtl::rc([=, cp_p0x = std::move(cp_p0x)](crate::lower::model::CaseDef p0) {
        return ({
            auto cp_p0xy = cp_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xy = std::move(cp_p0xy)]() {
            return ({
                auto c_pc = p0;
                (crate::prelude::call_value(crate::prelude::each_job(prism_rtl::deref(c_pc).fields_p, ({
                auto cp_p0xyx = cp_p0xy;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=, cp_p0xyx = std::move(cp_p0xyx)](std::tuple<Text, crate::lower::model::OutTy> p0) {
                return ({
                    auto cp_p0xyxy = cp_p0xyx;
                    (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xyxy = std::move(cp_p0xyxy)]() {
                    return ({
                        auto&& _ft_pd = p0;
                        auto&& ft_pd = std::get<1>(_ft_pd);
                        (prism_rtl::more(prism_rtl::rc(ValueDeps(cp_p0xyxy, ft_pd))));
                    });
                })));
                });
            })));
            })), [=](Array<Array<Text>> each_9019) { return prism_rtl::finished(crate::emit::cpp::patterns::concat2_f(each_9019)); }));
            });
        })));
        });
    })));
    }))));
    auto [text_p17, cmp_defs_p18] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Text, Array<Text>>> _v;
        auto&& _m = t_p1.shape_p;
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeChoice>(_m)) {
            _v.set(({
                auto names_pe = crate::prelude::each(t_p1.cases_p, [&](const crate::lower::model::CaseDef& c_pj) { return prism_rtl::deref(c_pj).name_p; });
                auto cases_pf = crate::syntax::lexer::chars::join_f(crate::prelude::run_to_end(crate::prelude::each_job(t_p1.cases_p, ({
                    auto cp_p0x = cp_p0;
                    auto eq_p2x = std::move(eq_p2);
                    auto ord_p3x = std::move(ord_p3);
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::CaseDef)>>(prism_rtl::rc([=, cp_p0x = std::move(cp_p0x), eq_p2x = std::move(eq_p2x), ord_p3x = std::move(ord_p3x)](crate::lower::model::CaseDef p0) {
                    return ({
                        auto cp_p0xy = cp_p0x;
                        auto eq_p2xy = eq_p2x;
                        auto ord_p3xy = ord_p3x;
                        (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xy = std::move(cp_p0xy), eq_p2xy = std::move(eq_p2xy), ord_p3xy = std::move(ord_p3xy)]() {
                        return ({
                            auto c_pk = p0;
                            (prism_rtl::more(prism_rtl::rc(CaseStruct(cp_p0xy, c_pk, eq_p2xy, ord_p3xy))));
                        });
                    })));
                    });
                })));
                }))), Text::lit("\n"));
                auto cls_pg = crate::emit::cpp::templates::items::choice_class_f(doc_p6, gens_p4, t_p1.name_p, cases_pf, crate::syntax::lexer::chars::join_f(names_pe, Text::lit(", ")), members_p7);
                auto cmp_ph = crate::syntax::lexer::chars::join_f(crate::prelude::filter(Array(std::vector{std::move(eq_p2)
                    ? prism_rtl::cat(gens_p4, "inline bool operator==(const ", head_p5, "& a, const ", head_p5, "& b) { return a.cases() == b.cases(); }")
                    : Text::lit(""), std::move(ord_p3)
                    ? prism_rtl::cat(gens_p4, "inline std::strong_ordering operator<=>(const ", head_p5, "& a, const ", head_p5, "& b) { return a.cases() <=> b.cases(); }")
                    : Text::lit("")}), [&](const Text& s_pl) { return s_pl != Text::lit(""); }), Text::lit("\n"));
                auto case_defs_pi = crate::prelude::filter(crate::prelude::run_to_end(crate::prelude::each_job(t_p1.cases_p, ({
                    auto cp_p0x = cp_p0;
                    auto gens_p4x = gens_p4;
                    auto head_p5x = head_p5;
                    auto eq_p2x = std::move(eq_p2);
                    auto ord_p3x = std::move(ord_p3);
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::CaseDef)>>(prism_rtl::rc([=, cp_p0x = std::move(cp_p0x), gens_p4x = std::move(gens_p4x), head_p5x = std::move(head_p5x), eq_p2x = std::move(eq_p2x), ord_p3x = std::move(ord_p3x)](crate::lower::model::CaseDef p0) {
                    return ({
                        auto cp_p0xy = cp_p0x;
                        auto gens_p4xy = gens_p4x;
                        auto head_p5xy = head_p5x;
                        auto eq_p2xy = eq_p2x;
                        auto ord_p3xy = ord_p3x;
                        (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xy = std::move(cp_p0xy), gens_p4xy = std::move(gens_p4xy), head_p5xy = std::move(head_p5xy), eq_p2xy = std::move(eq_p2xy), ord_p3xy = std::move(ord_p3xy)]() {
                        return ({
                            auto c_pm = p0;
                            (prism_rtl::more(prism_rtl::rc(CaseCmpDefs(cp_p0xy, gens_p4xy, head_p5xy, c_pm, eq_p2xy, ord_p3xy))));
                        });
                    })));
                    });
                })));
                }))), [&](const Text& s_pn) { return s_pn != Text::lit(""); });
                std::tuple{crate::syntax::lexer::chars::join_f(crate::prelude::filter(Array(std::vector{cls_pg, cmp_ph}), [&](const Text& s_po) { return s_po != Text::lit(""); }), Text::lit("\n")), case_defs_pi};
            }));
            goto _done;
        }
        {
            _v.set(({
                auto first_pp = crate::prelude::or_(crate::prelude::index(t_p1.cases_p, Nat(0u)), crate::lower::model::CaseDef{.name_p = Text::lit(""), .prism_p = Text::lit(""), .fields_p = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .labels_p = Array<Text>{}});
                auto fields_pq = ({
                    __label__ _done;
                    prism_rtl::Slot<Text> _v;
                    auto&& _m = t_p1.shape_p;
                    if (prism_rtl::is<crate::lower::model::TyShape::ShapeRecord>(_m)) {
                        _v.set(crate::syntax::lexer::chars::join_f(crate::prelude::run_to_end(crate::prelude::each_job(prism_rtl::deref(first_pp).fields_p, ({
                            auto cp_p0x = cp_p0;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=, cp_p0x = std::move(cp_p0x)](std::tuple<Text, crate::lower::model::OutTy> p0) {
                            return ({
                                auto cp_p0xy = cp_p0x;
                                (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xy = std::move(cp_p0xy)]() {
                                return ({
                                    auto [f_pu, ft_pv] = p0;
                                    (crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xy, ft_pv), [=](Text cpp_type_f_10242) { return prism_rtl::finished(prism_rtl::cat(cpp_type_f_10242, " ", crate::emit::cpp::field_id_f(f_pu), ";")); }));
                                });
                            })));
                            });
                        })));
                        }))), Text::lit("\n")));
                        goto _done;
                    }
                    if (prism_rtl::is<crate::lower::model::TyShape::ShapeNewtype>(_m)) {
                        _v.set(positional_fields_f(cp_p0, prism_rtl::deref(first_pp).fields_p));
                        goto _done;
                    }
                    {
                        _v.set(Text::lit(""));
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                auto names_pr = ({
                    __label__ _done;
                    prism_rtl::Slot<Array<Text>> _v;
                    auto&& _m = t_p1.shape_p;
                    if (prism_rtl::is<crate::lower::model::TyShape::ShapeRecord>(_m)) {
                        _v.set(crate::prelude::each(prism_rtl::deref(first_pp).fields_p, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
                            auto&& f_p10 = std::get<0>(_p0);
                            return crate::emit::cpp::field_id_f(f_p10);
                        }));
                        goto _done;
                    }
                    if (prism_rtl::is<crate::lower::model::TyShape::ShapeNewtype>(_m)) {
                        _v.set(crate::prelude::each(crate::check::errors::range0_f(crate::prelude::len(prism_rtl::deref(first_pp).fields_p)), [&](const Nat& i_p11) { return prism_rtl::cat("a", i_p11); }));
                        goto _done;
                    }
                    {
                        _v.set(Array<Text>{});
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                auto behind_ps = crate::prelude::run_to_end(crate::prelude::fold_job(prism_rtl::deref(first_pp).fields_p, false, ({
                    auto cp_p0x = cp_p0;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, crate::lower::model::OutTy>>)>>(prism_rtl::rc([=, cp_p0x = std::move(cp_p0x)](std::tuple<bool, std::tuple<Text, crate::lower::model::OutTy>> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto cp_p0xy = cp_p0x;
                        (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xy = std::move(cp_p0xy)]() {
                        return ({
                            auto f_p12 = p0;
                            auto&& _ft_p13 = p1;
                            auto&& ft_p13 = std::get<1>(_ft_p13);
                            (prism_rtl::finished(std::move(f_p12) || behind_f(cp_p0xy, ft_p13)));
                        });
                    })));
                    });
                })));
                })));
                auto [cmps_p14, cmp_defs_p15] = comparisons_f(gens_p4, head_p5, t_p1.name_p, names_pr, eq_p2, ord_p3, behind_ps);
                auto decl_pt = crate::emit::cpp::templates::items::value_struct_f(doc_p6, gens_p4, t_p1.name_p, fields_pq, crate::syntax::lexer::chars::join_f(crate::prelude::filter(Array(std::vector{cmps_p14, members_p7}), [&](const Text& s_p16) { return s_p16 != Text::lit(""); }), Text::lit("\n")));
                std::tuple{decl_pt, cmp_defs_p15 == Text::lit("")
                ? Array<Text>{}
                : Array(std::vector{cmp_defs_p15})};
            }));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto defs_pb = crate::prelude::append(cmp_defs_p18, Array(std::vector{type_defs_f(cp_p0, t_p1, head_p5)}));
    return Parts{.forward_p = Array(std::vector{fwd_p9}), .values_p = Array(std::vector{ValueDecl{.path_p = decl_path_f(cp_p0, t_p1.name_p), .deps_p = deps_pa, .text_p = text_p17}}), .protos_p = Array<Text>{}, .classes_p = Array<Text>{}, .outer_p = Array<Text>{}, .generic_p = std::move(generic_p8) ? defs_pb : Array<Text>{}, .defs_p = std::move(generic_p8) ? Array<Text>{} : defs_pb};
}


prism_rtl::Turn<Parts> TypeParts::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& t_p1 = this->t_p1;
    auto eq_p2 = prism_rtl::deref(t_p1).eq_p;
    auto ord_p3 = prism_rtl::deref(t_p1).ord_p;
    auto gens_p4 = cpp_template_head_f(prism_rtl::deref(t_p1).params_p);
    auto head_p5 = head_of_f(prism_rtl::deref(t_p1).name_p, prism_rtl::deref(t_p1).params_p);
    auto doc_p6 = cpp_source_doc_f(prism_rtl::cat("`", prism_rtl::deref(t_p1).prism_p, "`:"), prism_rtl::deref(t_p1).doc_p);
    auto members_p7 = members_f(prism_rtl::deref(t_p1).show_p != crate::lower::model::Shown(crate::lower::model::Shown::NotShown{}), prism_rtl::deref(t_p1).pod_p, head_p5);
    auto generic_p8 = crate::prelude::len(prism_rtl::deref(t_p1).params_p) > Nat(0u);
    auto fwd_p9 = prism_rtl::cat(gens_p4, prism_rtl::deref(t_p1).shape_p == crate::lower::model::TyShape(crate::lower::model::TyShape::ShapeChoice{})
        ? Text::lit("class")
        : Text::lit("struct"), " ", prism_rtl::deref(t_p1).name_p, ";");
    auto cp_p0x = cp_p0;
    auto t_p1x = t_p1;
    return crate::prelude::call_value(crate::prelude::each_job(prism_rtl::deref(t_p1x).cases_p, ({
        auto cp_p0xx = cp_p0x;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(crate::lower::model::CaseDef)>>(prism_rtl::rc([=, cp_p0xx = std::move(cp_p0xx)](crate::lower::model::CaseDef p0) {
        return ({
            auto cp_p0xxy = cp_p0xx;
            (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xxy = std::move(cp_p0xxy)]() {
            return ({
                auto c_pc = p0;
                (crate::prelude::call_value(crate::prelude::each_job(prism_rtl::deref(c_pc).fields_p, ({
                auto cp_p0xxyx = cp_p0xxy;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=, cp_p0xxyx = std::move(cp_p0xxyx)](std::tuple<Text, crate::lower::model::OutTy> p0) {
                return ({
                    auto cp_p0xxyxy = cp_p0xxyx;
                    (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xxyxy = std::move(cp_p0xxyxy)]() {
                    return ({
                        auto&& _ft_pd = p0;
                        auto&& ft_pd = std::get<1>(_ft_pd);
                        (prism_rtl::more(prism_rtl::rc(ValueDeps(cp_p0xxyxy, ft_pd))));
                    });
                })));
                });
            })));
            })), [=](Array<Array<Text>> each_9019) { return prism_rtl::finished(crate::emit::cpp::patterns::concat2_f(each_9019)); }));
            });
        })));
        });
    })));
    })), [=](Array<Array<Text>> each_8991) {
        return ({
            auto deps_pa = crate::emit::cpp::patterns::concat2_f(each_8991);
            auto [text_p17, cmp_defs_p18] = ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<Text, Array<Text>>> _v;
                auto&& _m = prism_rtl::deref(t_p1x).shape_p;
                if (prism_rtl::is<crate::lower::model::TyShape::ShapeChoice>(_m)) {
                    _v.set(({
                        auto names_pe = crate::prelude::each(prism_rtl::deref(t_p1x).cases_p, [&](const crate::lower::model::CaseDef& c_pj) { return prism_rtl::deref(c_pj).name_p; });
                        auto cases_pf = crate::syntax::lexer::chars::join_f(crate::prelude::run_to_end(crate::prelude::each_job(prism_rtl::deref(t_p1x).cases_p, ({
                            auto cp_p0xx = cp_p0x;
                            auto eq_p2x = eq_p2;
                            auto ord_p3x = ord_p3;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::CaseDef)>>(prism_rtl::rc([=, cp_p0xx = std::move(cp_p0xx), eq_p2x = std::move(eq_p2x), ord_p3x = std::move(ord_p3x)](crate::lower::model::CaseDef p0) {
                            return ({
                                auto cp_p0xxy = cp_p0xx;
                                auto eq_p2xy = eq_p2x;
                                auto ord_p3xy = ord_p3x;
                                (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xxy = std::move(cp_p0xxy), eq_p2xy = std::move(eq_p2xy), ord_p3xy = std::move(ord_p3xy)]() {
                                return ({
                                    auto c_pk = p0;
                                    (prism_rtl::more(prism_rtl::rc(CaseStruct(cp_p0xxy, c_pk, eq_p2xy, ord_p3xy))));
                                });
                            })));
                            });
                        })));
                        }))), Text::lit("\n"));
                        auto cls_pg = crate::emit::cpp::templates::items::choice_class_f(doc_p6, gens_p4, prism_rtl::deref(t_p1x).name_p, cases_pf, crate::syntax::lexer::chars::join_f(names_pe, Text::lit(", ")), members_p7);
                        auto cmp_ph = crate::syntax::lexer::chars::join_f(crate::prelude::filter(Array(std::vector{eq_p2
                            ? prism_rtl::cat(gens_p4, "inline bool operator==(const ", head_p5, "& a, const ", head_p5, "& b) { return a.cases() == b.cases(); }")
                            : Text::lit(""), ord_p3
                            ? prism_rtl::cat(gens_p4, "inline std::strong_ordering operator<=>(const ", head_p5, "& a, const ", head_p5, "& b) { return a.cases() <=> b.cases(); }")
                            : Text::lit("")}), [&](const Text& s_pl) { return s_pl != Text::lit(""); }), Text::lit("\n"));
                        auto case_defs_pi = crate::prelude::filter(crate::prelude::run_to_end(crate::prelude::each_job(prism_rtl::deref(t_p1x).cases_p, ({
                            auto cp_p0xx = cp_p0x;
                            auto gens_p4x = gens_p4;
                            auto head_p5x = head_p5;
                            auto eq_p2x = eq_p2;
                            auto ord_p3x = ord_p3;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::CaseDef)>>(prism_rtl::rc([=, cp_p0xx = std::move(cp_p0xx), gens_p4x = std::move(gens_p4x), head_p5x = std::move(head_p5x), eq_p2x = std::move(eq_p2x), ord_p3x = std::move(ord_p3x)](crate::lower::model::CaseDef p0) {
                            return ({
                                auto cp_p0xxy = cp_p0xx;
                                auto gens_p4xy = gens_p4x;
                                auto head_p5xy = head_p5x;
                                auto eq_p2xy = eq_p2x;
                                auto ord_p3xy = ord_p3x;
                                (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xxy = std::move(cp_p0xxy), gens_p4xy = std::move(gens_p4xy), head_p5xy = std::move(head_p5xy), eq_p2xy = std::move(eq_p2xy), ord_p3xy = std::move(ord_p3xy)]() {
                                return ({
                                    auto c_pm = p0;
                                    (prism_rtl::more(prism_rtl::rc(CaseCmpDefs(cp_p0xxy, gens_p4xy, head_p5xy, c_pm, eq_p2xy, ord_p3xy))));
                                });
                            })));
                            });
                        })));
                        }))), [&](const Text& s_pn) { return s_pn != Text::lit(""); });
                        std::tuple{crate::syntax::lexer::chars::join_f(crate::prelude::filter(Array(std::vector{cls_pg, cmp_ph}), [&](const Text& s_po) { return s_po != Text::lit(""); }), Text::lit("\n")), case_defs_pi};
                    }));
                    goto _done;
                }
                {
                    _v.set(({
                        auto first_pp = crate::prelude::or_(crate::prelude::index(prism_rtl::deref(t_p1x).cases_p, Nat(0u)), crate::lower::model::CaseDef{.name_p = Text::lit(""), .prism_p = Text::lit(""), .fields_p = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .labels_p = Array<Text>{}});
                        auto fields_pq = ({
                            __label__ _done;
                            prism_rtl::Slot<Text> _v;
                            auto&& _m = prism_rtl::deref(t_p1x).shape_p;
                            if (prism_rtl::is<crate::lower::model::TyShape::ShapeRecord>(_m)) {
                                _v.set(crate::syntax::lexer::chars::join_f(crate::prelude::run_to_end(crate::prelude::each_job(prism_rtl::deref(first_pp).fields_p, ({
                                    auto cp_p0xx = cp_p0x;
                                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=, cp_p0xx = std::move(cp_p0xx)](std::tuple<Text, crate::lower::model::OutTy> p0) {
                                    return ({
                                        auto cp_p0xxy = cp_p0xx;
                                        (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xxy = std::move(cp_p0xxy)]() {
                                        return ({
                                            auto [f_pu, ft_pv] = p0;
                                            (crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xxy, ft_pv), [=](Text cpp_type_f_10242) { return prism_rtl::finished(prism_rtl::cat(cpp_type_f_10242, " ", crate::emit::cpp::field_id_f(f_pu), ";")); }));
                                        });
                                    })));
                                    });
                                })));
                                }))), Text::lit("\n")));
                                goto _done;
                            }
                            if (prism_rtl::is<crate::lower::model::TyShape::ShapeNewtype>(_m)) {
                                _v.set(positional_fields_f(cp_p0x, prism_rtl::deref(first_pp).fields_p));
                                goto _done;
                            }
                            {
                                _v.set(Text::lit(""));
                                goto _done;
                            }
                        _done:
                            _v.take();
                        });
                        auto names_pr = ({
                            __label__ _done;
                            prism_rtl::Slot<Array<Text>> _v;
                            auto&& _m = prism_rtl::deref(t_p1x).shape_p;
                            if (prism_rtl::is<crate::lower::model::TyShape::ShapeRecord>(_m)) {
                                _v.set(crate::prelude::each(prism_rtl::deref(first_pp).fields_p, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
                                    auto&& f_p10 = std::get<0>(_p0);
                                    return crate::emit::cpp::field_id_f(f_p10);
                                }));
                                goto _done;
                            }
                            if (prism_rtl::is<crate::lower::model::TyShape::ShapeNewtype>(_m)) {
                                _v.set(crate::prelude::each(crate::check::errors::range0_f(crate::prelude::len(prism_rtl::deref(first_pp).fields_p)), [&](const Nat& i_p11) { return prism_rtl::cat("a", i_p11); }));
                                goto _done;
                            }
                            {
                                _v.set(Array<Text>{});
                                goto _done;
                            }
                        _done:
                            _v.take();
                        });
                        auto behind_ps = crate::prelude::run_to_end(crate::prelude::fold_job(prism_rtl::deref(first_pp).fields_p, false, ({
                            auto cp_p0xx = cp_p0x;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, crate::lower::model::OutTy>>)>>(prism_rtl::rc([=, cp_p0xx = std::move(cp_p0xx)](std::tuple<bool, std::tuple<Text, crate::lower::model::OutTy>> _p0) {
                            auto&& p0 = std::get<0>(_p0);
                            auto&& p1 = std::get<1>(_p0);
                            return ({
                                auto cp_p0xxy = cp_p0xx;
                                (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xxy = std::move(cp_p0xxy)]() {
                                return ({
                                    auto f_p12 = p0;
                                    auto&& _ft_p13 = p1;
                                    auto&& ft_p13 = std::get<1>(_ft_p13);
                                    (prism_rtl::finished(std::move(f_p12) || behind_f(cp_p0xxy, ft_p13)));
                                });
                            })));
                            });
                        })));
                        })));
                        auto [cmps_p14, cmp_defs_p15] = comparisons_f(gens_p4, head_p5, prism_rtl::deref(t_p1x).name_p, names_pr, eq_p2, ord_p3, behind_ps);
                        auto decl_pt = crate::emit::cpp::templates::items::value_struct_f(doc_p6, gens_p4, prism_rtl::deref(t_p1x).name_p, fields_pq, crate::syntax::lexer::chars::join_f(crate::prelude::filter(Array(std::vector{cmps_p14, members_p7}), [&](const Text& s_p16) { return s_p16 != Text::lit(""); }), Text::lit("\n")));
                        std::tuple{decl_pt, cmp_defs_p15 == Text::lit("")
                        ? Array<Text>{}
                        : Array(std::vector{cmp_defs_p15})};
                    }));
                    goto _done;
                }
            _done:
                _v.take();
            });
            (crate::prelude::call_then(start_type_defs_f(cp_p0x, t_p1x, head_p5), [=, deps_pa = std::move(deps_pa)](Text type_defs_f_10992) {
            return ({
                auto defs_pb = crate::prelude::append(cmp_defs_p18, Array(std::vector{type_defs_f_10992}));
                (prism_rtl::finished(Parts{.forward_p = Array(std::vector{fwd_p9}), .values_p = Array(std::vector{ValueDecl{.path_p = decl_path_f(cp_p0x, prism_rtl::deref(t_p1x).name_p), .deps_p = deps_pa, .text_p = text_p17}}), .protos_p = Array<Text>{}, .classes_p = Array<Text>{}, .outer_p = Array<Text>{}, .generic_p = generic_p8 ? defs_pb : Array<Text>{}, .defs_p = generic_p8 ? Array<Text>{} : defs_pb}));
            });
        }));
        });
    });
}


/// `Start TypeParts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Parts> start_type_parts_f(crate::emit::cpp::Cp cp_p0, crate::lower::model::TyDef t_p1) {
    return prism_rtl::make_rc<TypeParts>(cp_p0, t_p1);
}


/// DeclPath: fn Cp, Text -> Text
Text decl_path_f(const crate::emit::cpp::Cp& cp_p0, const Text& name_p1) {
    return cp_p0.home_p == Text::lit("")
        ? name_p1
        : prism_rtl::cat(cp_p0.home_p, "::", name_p1);
}


/// Comparisons: fn Text, Text, Text, [Text], Bool, Bool, Bool -> ((Text, Text))
std::tuple<Text, Text> comparisons_f(const Text& gens_p0, const Text& owner_p1, const Text& self_p2, const Array<Text>& names_p3, const bool& eq_p4, const bool& ord_p5, const bool& behind_p6) {
    return !behind_p6
        ? std::tuple{crate::syntax::lexer::chars::join_f(crate::prelude::filter(Array(std::vector{eq_p4
        ? prism_rtl::cat("bool operator==(const ", self_p2, "&) const = default;")
        : Text::lit(""), ord_p5
        ? prism_rtl::cat("auto operator<=>(const ", self_p2, "&) const = default;")
        : Text::lit("")}), [&](const Text& s_p7) { return s_p7 != Text::lit(""); }), Text::lit("\n")), Text::lit("")}
        : ({
        auto decls_p8 = crate::syntax::lexer::chars::join_f(crate::prelude::filter(Array(std::vector{eq_p4
            ? prism_rtl::cat("bool operator==(const ", self_p2, "&) const;")
            : Text::lit(""), ord_p5
            ? prism_rtl::cat("std::strong_ordering operator<=>(const ", self_p2, "&) const;")
            : Text::lit("")}), [&](const Text& s_pc) { return s_pc != Text::lit(""); }), Text::lit("\n"));
        auto eq_body_p9 = crate::prelude::len(names_p3) == Nat(0u)
            ? Text::lit("true")
            : crate::syntax::lexer::chars::join_f(crate::prelude::each(names_p3, [&](const Text& n_pd) { return prism_rtl::cat(n_pd, " == o.", n_pd); }), Text::lit(" && "));
        auto ord_body_pa = crate::prelude::len(names_p3) == Nat(0u)
            ? Text::lit("std::strong_ordering::equal")
            : prism_rtl::cat("std::tie(", crate::syntax::lexer::chars::join_f(names_p3, Text::lit(", ")), ") <=> std::tie(", crate::syntax::lexer::chars::join_f(crate::prelude::each(names_p3, [&](const Text& n_pe) { return prism_rtl::cat("o.", n_pe); }), Text::lit(", ")), ")");
        auto defs_pb = crate::syntax::lexer::chars::join_f(crate::prelude::filter(Array(std::vector{eq_p4
            ? prism_rtl::cat(gens_p0, "bool ", owner_p1, "::operator==(const ", self_p2, "& o) const { return ", eq_body_p9, "; }")
            : Text::lit(""), ord_p5
            ? prism_rtl::cat(gens_p0, "std::strong_ordering ", owner_p1, "::operator<=>(const ", self_p2, "& o) const { return ", ord_body_pa, "; }")
            : Text::lit("")}), [&](const Text& s_pf) { return s_pf != Text::lit(""); }), Text::lit("\n"));
        std::tuple{decls_p8, defs_pb};
    });
}


/// Members: fn Bool, Bool, Text -> Text
Text members_f(const bool& shown_p0, const bool& pod_p1, const Text& head_p2) {
    auto s_p3 = shown_p0
        ? Array(std::vector{Text::lit("void show(Printer& p) const;")})
        : Array<Text>{};
    auto d_p4 = pod_p1
        ? Array(std::vector{Text::lit("Pod to_pod() const;"), prism_rtl::cat("static Result<", head_p2, "> from_pod(const Pod& whole);")})
        : Array<Text>{};
    return crate::syntax::lexer::chars::join_f(crate::prelude::append(s_p3, d_p4), Text::lit("\n"));
}


/// CaseStruct: unbounded fn Cp, CaseDef, Bool, Bool -> Text
Text case_struct_f(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::CaseDef& c_p1, const bool& eq_p2, const bool& ord_p3) {
    auto fields_p4 = positional_fields_f(cp_p0, c_p1.fields_p);
    auto&& _cmps_p5 = comparisons_f(Text::lit(""), Text::lit(""), c_p1.name_p, case_names_f(c_p1), eq_p2, ord_p3, case_behind_f(cp_p0, c_p1));
    auto&& cmps_p5 = std::get<0>(_cmps_p5);
    return crate::emit::cpp::templates::items::case_decl_f(c_p1.name_p, crate::syntax::lexer::chars::join_f(crate::prelude::filter(Array(std::vector{fields_p4, cmps_p5}), [&](const Text& s_p6) { return s_p6 != Text::lit(""); }), Text::lit("\n")));
}


prism_rtl::Turn<Text> CaseStruct::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& c_p1 = this->c_p1;
    const auto& eq_p2 = this->eq_p2;
    const auto& ord_p3 = this->ord_p3;
    auto c_p1x = c_p1;
    auto cp_p0x = cp_p0;
    auto eq_p2x = prism_rtl::deref(eq_p2);
    auto ord_p3x = prism_rtl::deref(ord_p3);
    return crate::prelude::call_then(start_positional_fields_f(cp_p0x, prism_rtl::deref(c_p1x).fields_p), [=](Text positional_fields_f_13273) {
        return ({
            auto fields_p4 = positional_fields_f_13273;
            (crate::prelude::call_then(start_case_behind_f(cp_p0x, c_p1x), [=, fields_p4 = std::move(fields_p4)](bool case_behind_f_13383) {
            return ({
                auto&& _cmps_p5 = comparisons_f(Text::lit(""), Text::lit(""), prism_rtl::deref(c_p1x).name_p, case_names_f(c_p1x), eq_p2x, ord_p3x, case_behind_f_13383);
                auto&& cmps_p5 = std::get<0>(_cmps_p5);
                (prism_rtl::finished(crate::emit::cpp::templates::items::case_decl_f(prism_rtl::deref(c_p1x).name_p, crate::syntax::lexer::chars::join_f(crate::prelude::filter(Array(std::vector{fields_p4, cmps_p5}), [&](const Text& s_p6) { return s_p6 != Text::lit(""); }), Text::lit("\n")))));
            });
        }));
        });
    });
}


/// `Start CaseStruct, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_case_struct_f(crate::emit::cpp::Cp cp_p0, crate::lower::model::CaseDef c_p1, bool eq_p2, bool ord_p3) {
    return prism_rtl::make_rc<CaseStruct>(cp_p0, c_p1, eq_p2, ord_p3);
}


/// CaseCmpDefs: unbounded fn Cp, Text, Text, CaseDef, Bool, Bool -> Text
Text case_cmp_defs_f(const crate::emit::cpp::Cp& cp_p0, const Text& gens_p1, const Text& head_p2, const crate::lower::model::CaseDef& c_p3, const bool& eq_p4, const bool& ord_p5) {
    auto&& _defs_p6 = comparisons_f(gens_p1, prism_rtl::cat(head_p2, "::", c_p3.name_p), c_p3.name_p, case_names_f(c_p3), eq_p4, ord_p5, case_behind_f(cp_p0, c_p3));
    auto&& defs_p6 = std::get<1>(_defs_p6);
    return defs_p6;
}


prism_rtl::Turn<Text> CaseCmpDefs::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& gens_p1 = this->gens_p1;
    const auto& head_p2 = this->head_p2;
    const auto& c_p3 = this->c_p3;
    const auto& eq_p4 = this->eq_p4;
    const auto& ord_p5 = this->ord_p5;
    auto c_p3x = c_p3;
    auto cp_p0x = cp_p0;
    auto eq_p4x = prism_rtl::deref(eq_p4);
    auto gens_p1x = gens_p1;
    auto head_p2x = head_p2;
    auto ord_p5x = prism_rtl::deref(ord_p5);
    return crate::prelude::call_then(start_case_behind_f(cp_p0x, c_p3x), [=](bool case_behind_f_13776) {
        return ({
            auto&& _defs_p6 = comparisons_f(gens_p1x, prism_rtl::cat(head_p2x, "::", prism_rtl::deref(c_p3x).name_p), prism_rtl::deref(c_p3x).name_p, case_names_f(c_p3x), eq_p4x, ord_p5x, case_behind_f_13776);
            auto&& defs_p6 = std::get<1>(_defs_p6);
            (prism_rtl::finished(defs_p6));
        });
    });
}


/// `Start CaseCmpDefs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_case_cmp_defs_f(crate::emit::cpp::Cp cp_p0, Text gens_p1, Text head_p2, crate::lower::model::CaseDef c_p3, bool eq_p4, bool ord_p5) {
    return prism_rtl::make_rc<CaseCmpDefs>(cp_p0, gens_p1, head_p2, c_p3, eq_p4, ord_p5);
}


/// CaseNames: fn CaseDef -> [Text]
Array<Text> case_names_f(const crate::lower::model::CaseDef& c_p0) {
    return crate::prelude::each(crate::check::errors::range0_f(crate::prelude::len(c_p0.fields_p)), [&](const Nat& i_p1) { return prism_rtl::cat("a", i_p1); });
}


/// CaseBehind: unbounded fn Cp, CaseDef -> Bool
bool case_behind_f(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::CaseDef& c_p1) {
    return crate::prelude::run_to_end(crate::prelude::fold_job(c_p1.fields_p, false, ({
        auto cp_p0x = cp_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, crate::lower::model::OutTy>>)>>(prism_rtl::rc([=, cp_p0x = std::move(cp_p0x)](std::tuple<bool, std::tuple<Text, crate::lower::model::OutTy>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto cp_p0xy = cp_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xy = std::move(cp_p0xy)]() {
            return ({
                auto f_p2 = p0;
                auto&& _ft_p3 = p1;
                auto&& ft_p3 = std::get<1>(_ft_p3);
                (prism_rtl::finished(std::move(f_p2) || behind_f(cp_p0xy, ft_p3)));
            });
        })));
        });
    })));
    })));
}


prism_rtl::Turn<bool> CaseBehind::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& c_p1 = this->c_p1;
    return crate::prelude::fold_job(prism_rtl::deref(c_p1).fields_p, false, ({
        auto cp_p0x = cp_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, crate::lower::model::OutTy>>)>>(prism_rtl::rc([=, cp_p0x = std::move(cp_p0x)](std::tuple<bool, std::tuple<Text, crate::lower::model::OutTy>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto cp_p0xy = cp_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xy = std::move(cp_p0xy)]() {
            return ({
                auto f_p2 = p0;
                auto&& _ft_p3 = p1;
                auto&& ft_p3 = std::get<1>(_ft_p3);
                (prism_rtl::finished(std::move(f_p2) || behind_f(cp_p0xy, ft_p3)));
            });
        })));
        });
    })));
    }))->cycle();
}


/// `Start CaseBehind, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_case_behind_f(crate::emit::cpp::Cp cp_p0, crate::lower::model::CaseDef c_p1) {
    return prism_rtl::make_rc<CaseBehind>(cp_p0, c_p1);
}


/// TypeDefs: unbounded fn Cp, TyDef, Text -> Text
Text type_defs_f(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::TyDef& t_p1, const Text& head_p2) {
    auto gens_p3 = cpp_template_head_f(t_p1.params_p);
    auto show_p4 = t_p1.show_p == crate::lower::model::Shown(crate::lower::model::Shown::ShownDerived{})
        ? Array(std::vector{show_def_f(cp_p0, t_p1, head_p2, gens_p3)})
        : Array<Text>{};
    auto pod_p5 = t_p1.pod_p
        ? Array(std::vector{to_pod_def_f(cp_p0, t_p1, head_p2, gens_p3), from_pod_def_f(cp_p0, t_p1, head_p2, gens_p3)})
        : Array<Text>{};
    return crate::syntax::lexer::chars::join_f(crate::prelude::append(show_p4, pod_p5), Text::lit("\n"));
}


prism_rtl::Turn<Text> TypeDefs::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& t_p1 = this->t_p1;
    const auto& head_p2 = this->head_p2;
    auto gens_p3 = cpp_template_head_f(prism_rtl::deref(t_p1).params_p);
    auto show_p4 = prism_rtl::deref(t_p1).show_p == crate::lower::model::Shown(crate::lower::model::Shown::ShownDerived{})
        ? Array(std::vector{show_def_f(cp_p0, t_p1, head_p2, gens_p3)})
        : Array<Text>{};
    auto pod_p5 = prism_rtl::deref(t_p1).pod_p
        ? Array(std::vector{to_pod_def_f(cp_p0, t_p1, head_p2, gens_p3), from_pod_def_f(cp_p0, t_p1, head_p2, gens_p3)})
        : Array<Text>{};
    return prism_rtl::finished(crate::syntax::lexer::chars::join_f(crate::prelude::append(show_p4, pod_p5), Text::lit("\n")));
}


/// `Start TypeDefs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_type_defs_f(crate::emit::cpp::Cp cp_p0, crate::lower::model::TyDef t_p1, Text head_p2) {
    return prism_rtl::make_rc<TypeDefs>(cp_p0, t_p1, head_p2);
}


/// ShowDef: unbounded fn Cp, TyDef, Text, Text -> Text
Text show_def_f(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::TyDef& t_p1, const Text& head_p2, const Text& gens_p3) {
    auto body_p4 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = t_p1.shape_p;
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeRecord>(_m)) {
            _v.set(({
                auto c_p5 = crate::prelude::or_(crate::prelude::index(t_p1.cases_p, Nat(0u)), crate::lower::model::CaseDef{.name_p = Text::lit(""), .prism_p = Text::lit(""), .fields_p = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .labels_p = Array<Text>{}});
                (prism_rtl::cat("p.record(\"", t_p1.prism_p, "\", {", crate::syntax::lexer::chars::join_f(crate::prelude::each(prism_rtl::deref(c_p5).fields_p, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
                auto&& f_p6 = std::get<0>(_p0);
                return prism_rtl::cat("{\"", prism_field_of_f(c_p5, f_p6), "\", ", crate::emit::cpp::field_id_f(f_p6), "}");
            }), Text::lit(", ")), "});"));
            }));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeChoice>(_m)) {
            _v.set(crate::syntax::lexer::chars::join_f(crate::prelude::each(crate::check::errors::range0_f(crate::prelude::len(t_p1.cases_p)), [&](const Nat& i_p7) { return show_case_f(t_p1, i_p7); }), Text::lit("\n")));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeNewtype>(_m)) {
            _v.set(prism_rtl::cat("p.choice(\"", first_case_f(t_p1), "\", {", crate::syntax::lexer::chars::join_f(crate::prelude::each(crate::check::errors::range0_f(first_arity_f(t_p1)), [&](const Nat& k_p8) { return prism_rtl::cat("a", k_p8); }), Text::lit(", ")), "});"));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeUnit>(_m)) {
            _v.set(prism_rtl::cat("p.choice(\"", first_case_f(t_p1), "\", {});"));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return crate::emit::cpp::templates::items::cpp_function_f(Text::lit(""), prism_rtl::cat(gens_p3, "void ", head_p2, "::show(Printer& p) const"), body_p4);
}


prism_rtl::Turn<Text> ShowDef::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& t_p1 = this->t_p1;
    const auto& head_p2 = this->head_p2;
    const auto& gens_p3 = this->gens_p3;
    auto body_p4 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = prism_rtl::deref(t_p1).shape_p;
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeRecord>(_m)) {
            _v.set(({
                auto c_p5 = crate::prelude::or_(crate::prelude::index(prism_rtl::deref(t_p1).cases_p, Nat(0u)), crate::lower::model::CaseDef{.name_p = Text::lit(""), .prism_p = Text::lit(""), .fields_p = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .labels_p = Array<Text>{}});
                (prism_rtl::cat("p.record(\"", prism_rtl::deref(t_p1).prism_p, "\", {", crate::syntax::lexer::chars::join_f(crate::prelude::each(prism_rtl::deref(c_p5).fields_p, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
                auto&& f_p6 = std::get<0>(_p0);
                return prism_rtl::cat("{\"", prism_field_of_f(c_p5, f_p6), "\", ", crate::emit::cpp::field_id_f(f_p6), "}");
            }), Text::lit(", ")), "});"));
            }));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeChoice>(_m)) {
            _v.set(crate::syntax::lexer::chars::join_f(crate::prelude::each(crate::check::errors::range0_f(crate::prelude::len(prism_rtl::deref(t_p1).cases_p)), [&](const Nat& i_p7) { return show_case_f(t_p1, i_p7); }), Text::lit("\n")));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeNewtype>(_m)) {
            _v.set(prism_rtl::cat("p.choice(\"", first_case_f(t_p1), "\", {", crate::syntax::lexer::chars::join_f(crate::prelude::each(crate::check::errors::range0_f(first_arity_f(t_p1)), [&](const Nat& k_p8) { return prism_rtl::cat("a", k_p8); }), Text::lit(", ")), "});"));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeUnit>(_m)) {
            _v.set(prism_rtl::cat("p.choice(\"", first_case_f(t_p1), "\", {});"));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return prism_rtl::finished(crate::emit::cpp::templates::items::cpp_function_f(Text::lit(""), prism_rtl::cat(gens_p3, "void ", head_p2, "::show(Printer& p) const"), body_p4));
}


/// `Start ShowDef, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_show_def_f(crate::emit::cpp::Cp cp_p0, crate::lower::model::TyDef t_p1, Text head_p2, Text gens_p3) {
    return prism_rtl::make_rc<ShowDef>(cp_p0, t_p1, head_p2, gens_p3);
}


/// ShowCase: fn TyDef, Nat -> Text
Text show_case_f(const crate::lower::model::TyDef& t_p0, const Nat& i_p1) {
    auto c_p2 = crate::prelude::or_(crate::prelude::index(t_p0.cases_p, i_p1), crate::lower::model::CaseDef{.name_p = Text::lit(""), .prism_p = Text::lit(""), .fields_p = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .labels_p = Array<Text>{}});
    auto head_p3 = prism_rtl::cat(i_p1 == Nat(0u) ? Text::lit("if") : Text::lit("else if"), " (auto c = std::get_if<", prism_rtl::deref(c_p2).name_p, ">(&cases()))");
    return prism_rtl::cat(head_p3, " p.choice(\"", prism_rtl::deref(c_p2).prism_p, "\", {", crate::syntax::lexer::chars::join_f(crate::prelude::each(crate::check::errors::range0_f(crate::prelude::len(prism_rtl::deref(c_p2).fields_p)), [&](const Nat& k_p4) { return prism_rtl::cat("c->a", k_p4); }), Text::lit(", ")), "});");
}


/// FirstCase: fn TyDef -> Text
Text first_case_f(const crate::lower::model::TyDef& t_p0) {
    return prism_rtl::deref(crate::prelude::or_(crate::prelude::index(t_p0.cases_p, Nat(0u)), crate::lower::model::CaseDef{.name_p = Text::lit(""), .prism_p = t_p0.prism_p, .fields_p = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .labels_p = Array<Text>{}})).prism_p;
}


/// FirstArity: fn TyDef -> Nat
Nat first_arity_f(const crate::lower::model::TyDef& t_p0) {
    return crate::prelude::len(prism_rtl::deref(crate::prelude::or_(crate::prelude::index(t_p0.cases_p, Nat(0u)), crate::lower::model::CaseDef{.name_p = Text::lit(""), .prism_p = Text::lit(""), .fields_p = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .labels_p = Array<Text>{}})).fields_p);
}


/// FieldTypes: fn [((Text, OutTy))] -> [OutTy]
Array<crate::lower::model::OutTy> field_types_f(const Array<std::tuple<Text, crate::lower::model::OutTy>>& fs_p0) {
    return crate::prelude::each(fs_p0, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
        auto&& t_p1 = std::get<1>(_p0);
        return t_p1;
    });
}


/// PositionalFields: unbounded fn Cp, [((Text, OutTy))] -> Text
Text positional_fields_f(const crate::emit::cpp::Cp& cp_p0, const Array<std::tuple<Text, crate::lower::model::OutTy>>& fs_p1) {
    auto tys_p2 = field_types_f(fs_p1);
    return crate::syntax::lexer::chars::join_f(crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(crate::prelude::len(tys_p2)), ({
        auto cp_p0x = cp_p0;
        auto tys_p2x = tys_p2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Nat)>>(prism_rtl::rc([=, cp_p0x = std::move(cp_p0x), tys_p2x = std::move(tys_p2x)](Nat p0) {
        return ({
            auto cp_p0xy = cp_p0x;
            auto tys_p2xy = tys_p2x;
            (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xy = std::move(cp_p0xy), tys_p2xy = std::move(tys_p2xy)]() {
            return ({
                auto i_p3 = p0;
                (crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xy, crate::prelude::or_(crate::prelude::index(tys_p2xy, i_p3), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}))), [=](Text cpp_type_f_16024) { return prism_rtl::finished(prism_rtl::cat(cpp_type_f_16024, " a", i_p3, ";")); }));
            });
        })));
        });
    })));
    }))), Text::lit("\n"));
}


prism_rtl::Turn<Text> PositionalFields::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& fs_p1 = this->fs_p1;
    auto tys_p2 = field_types_f(fs_p1);
    auto cp_p0x = cp_p0;
    return crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(crate::prelude::len(tys_p2)), ({
        auto cp_p0xx = cp_p0x;
        auto tys_p2x = tys_p2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Nat)>>(prism_rtl::rc([=, cp_p0xx = std::move(cp_p0xx), tys_p2x = std::move(tys_p2x)](Nat p0) {
        return ({
            auto cp_p0xxy = cp_p0xx;
            auto tys_p2xy = tys_p2x;
            (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xxy = std::move(cp_p0xxy), tys_p2xy = std::move(tys_p2xy)]() {
            return ({
                auto i_p3 = p0;
                (crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xxy, crate::prelude::or_(crate::prelude::index(tys_p2xy, i_p3), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}))), [=](Text cpp_type_f_16024) { return prism_rtl::finished(prism_rtl::cat(cpp_type_f_16024, " a", i_p3, ";")); }));
            });
        })));
        });
    })));
    })), [=](Array<Text> each_15992) { return prism_rtl::finished(crate::syntax::lexer::chars::join_f(each_15992, Text::lit("\n"))); });
}


/// `Start PositionalFields, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_positional_fields_f(crate::emit::cpp::Cp cp_p0, Array<std::tuple<Text, crate::lower::model::OutTy>> fs_p1) {
    return prism_rtl::make_rc<PositionalFields>(cp_p0, fs_p1);
}


/// ToPodDef: unbounded fn Cp, TyDef, Text, Text -> Text
Text to_pod_def_f(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::TyDef& t_p1, const Text& head_p2, const Text& gens_p3) {
    auto structure_p4 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = t_p1.shape_p;
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeRecord>(_m)) {
            _v.set(({
                auto c_p6 = crate::prelude::or_(crate::prelude::index(t_p1.cases_p, Nat(0u)), crate::lower::model::CaseDef{.name_p = Text::lit(""), .prism_p = Text::lit(""), .fields_p = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .labels_p = Array<Text>{}});
                (prism_rtl::cat("Pod::record(\"", t_p1.prism_p, "\", {", crate::syntax::lexer::chars::join_f(crate::prelude::each(prism_rtl::deref(c_p6).fields_p, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
                auto&& f_p7 = std::get<0>(_p0);
                return prism_rtl::cat("{\"", prism_field_of_f(c_p6, f_p7), "\", prism_rtl::to_pod(", crate::emit::cpp::field_id_f(f_p7), ")}");
            }), Text::lit(", ")), "})"));
            }));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeChoice>(_m)) {
            _v.set(choice_pod_f(t_p1));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeNewtype>(_m)) {
            _v.set(prism_rtl::cat("Pod::choice(\"", first_case_f(t_p1), "\", {", crate::syntax::lexer::chars::join_f(crate::prelude::each(crate::check::errors::range0_f(first_arity_f(t_p1)), [&](const Nat& k_p8) { return prism_rtl::cat("prism_rtl::to_pod(a", k_p8, ")"); }), Text::lit(", ")), "})"));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeUnit>(_m)) {
            _v.set(prism_rtl::cat("Pod::choice(\"", first_case_f(t_p1), "\", {})"));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto body_p5 = t_p1.show_p == crate::lower::model::Shown(crate::lower::model::Shown::ShownOwn{})
        ? prism_rtl::cat("Pod structure = ", structure_p4, ";\nreturn Pod::shown(prism_rtl::show(*this), structure);")
        : prism_rtl::cat("return ", structure_p4, ";");
    return crate::emit::cpp::templates::items::cpp_function_f(Text::lit(""), prism_rtl::cat(gens_p3, "Pod ", head_p2, "::to_pod() const"), body_p5);
}


prism_rtl::Turn<Text> ToPodDef::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& t_p1 = this->t_p1;
    const auto& head_p2 = this->head_p2;
    const auto& gens_p3 = this->gens_p3;
    auto structure_p4 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = prism_rtl::deref(t_p1).shape_p;
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeRecord>(_m)) {
            _v.set(({
                auto c_p6 = crate::prelude::or_(crate::prelude::index(prism_rtl::deref(t_p1).cases_p, Nat(0u)), crate::lower::model::CaseDef{.name_p = Text::lit(""), .prism_p = Text::lit(""), .fields_p = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .labels_p = Array<Text>{}});
                (prism_rtl::cat("Pod::record(\"", prism_rtl::deref(t_p1).prism_p, "\", {", crate::syntax::lexer::chars::join_f(crate::prelude::each(prism_rtl::deref(c_p6).fields_p, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
                auto&& f_p7 = std::get<0>(_p0);
                return prism_rtl::cat("{\"", prism_field_of_f(c_p6, f_p7), "\", prism_rtl::to_pod(", crate::emit::cpp::field_id_f(f_p7), ")}");
            }), Text::lit(", ")), "})"));
            }));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeChoice>(_m)) {
            _v.set(choice_pod_f(t_p1));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeNewtype>(_m)) {
            _v.set(prism_rtl::cat("Pod::choice(\"", first_case_f(t_p1), "\", {", crate::syntax::lexer::chars::join_f(crate::prelude::each(crate::check::errors::range0_f(first_arity_f(t_p1)), [&](const Nat& k_p8) { return prism_rtl::cat("prism_rtl::to_pod(a", k_p8, ")"); }), Text::lit(", ")), "})"));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeUnit>(_m)) {
            _v.set(prism_rtl::cat("Pod::choice(\"", first_case_f(t_p1), "\", {})"));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto body_p5 = prism_rtl::deref(t_p1).show_p == crate::lower::model::Shown(crate::lower::model::Shown::ShownOwn{})
        ? prism_rtl::cat("Pod structure = ", structure_p4, ";\nreturn Pod::shown(prism_rtl::show(*this), structure);")
        : prism_rtl::cat("return ", structure_p4, ";");
    return prism_rtl::finished(crate::emit::cpp::templates::items::cpp_function_f(Text::lit(""), prism_rtl::cat(gens_p3, "Pod ", head_p2, "::to_pod() const"), body_p5));
}


/// `Start ToPodDef, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_to_pod_def_f(crate::emit::cpp::Cp cp_p0, crate::lower::model::TyDef t_p1, Text head_p2, Text gens_p3) {
    return prism_rtl::make_rc<ToPodDef>(cp_p0, t_p1, head_p2, gens_p3);
}


/// ChoicePod: fn TyDef -> Text
Text choice_pod_f(const crate::lower::model::TyDef& t_p0) {
    auto arms_p1 = crate::prelude::each(crate::check::errors::range0_f(crate::prelude::len(t_p0.cases_p)), [&](const Nat& i_p2) {
        return ({
            auto c_p3 = crate::prelude::or_(crate::prelude::index(t_p0.cases_p, i_p2), crate::lower::model::CaseDef{.name_p = Text::lit(""), .prism_p = Text::lit(""), .fields_p = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .labels_p = Array<Text>{}});
            (prism_rtl::cat("std::holds_alternative<", prism_rtl::deref(c_p3).name_p, ">(cases()) ? Pod::choice(\"", prism_rtl::deref(c_p3).prism_p, "\", {", crate::syntax::lexer::chars::join_f(crate::prelude::each(crate::check::errors::range0_f(crate::prelude::len(prism_rtl::deref(c_p3).fields_p)), [&](const Nat& k_p4) { return prism_rtl::cat("prism_rtl::to_pod(std::get<", prism_rtl::deref(c_p3).name_p, ">(cases()).a", k_p4, ")"); }), Text::lit(", ")), "})"));
        });
    });
    return prism_rtl::cat(crate::syntax::lexer::chars::join_f(arms_p1, Text::lit("\n    : ")), "\n    : Pod()");
}


/// FromPodDef: unbounded fn Cp, TyDef, Text, Text -> Text
Text from_pod_def_f(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::TyDef& t_p1, const Text& head_p2, const Text& gens_p3) {
    auto body_p4 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = t_p1.shape_p;
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeRecord>(_m)) {
            _v.set(({
                auto c_p5 = crate::prelude::or_(crate::prelude::index(t_p1.cases_p, Nat(0u)), crate::lower::model::CaseDef{.name_p = Text::lit(""), .prism_p = Text::lit(""), .fields_p = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .labels_p = Array<Text>{}});
                auto reads_p6 = crate::syntax::lexer::chars::join_f(crate::prelude::run_to_end(crate::prelude::each_job(prism_rtl::deref(c_p5).fields_p, ({
                    auto cp_p0x = cp_p0;
                    auto c_p5x = c_p5;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=, cp_p0x = std::move(cp_p0x), c_p5x = std::move(c_p5x)](std::tuple<Text, crate::lower::model::OutTy> p0) {
                    return ({
                        auto cp_p0xy = cp_p0x;
                        auto c_p5xy = c_p5x;
                        (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xy = std::move(cp_p0xy), c_p5xy = std::move(c_p5xy)]() {
                        return ({
                            auto [f_p7, ft_p8] = p0;
                            (crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xy, ft_p8), [=](Text cpp_type_f_17640) { return prism_rtl::finished(prism_rtl::cat(".", crate::emit::cpp::field_id_f(f_p7), " = TRY(prism_rtl::from_pod<", cpp_type_f_17640, ">(TRY(crate::prelude::field(whole, \"", prism_field_of_f(c_p5xy, f_p7), "\"))))")); }));
                        });
                    })));
                    });
                })));
                }))), Text::lit(", "));
                (prism_rtl::cat("return ", head_p2, "{", reads_p6, "};"));
            }));
            goto _done;
        }
        {
            _v.set(({
                auto arms_p9 = crate::prelude::run_to_end(crate::prelude::each_job(t_p1.cases_p, ({
                    auto cp_p0x = cp_p0;
                    auto t_p1x = t_p1;
                    auto head_p2x = head_p2;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::CaseDef)>>(prism_rtl::rc([=, cp_p0x = std::move(cp_p0x), t_p1x = std::move(t_p1x), head_p2x = std::move(head_p2x)](crate::lower::model::CaseDef p0) {
                    return ({
                        auto cp_p0xy = cp_p0x;
                        auto t_p1xy = t_p1x;
                        auto head_p2xy = head_p2x;
                        (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xy = std::move(cp_p0xy), t_p1xy = std::move(t_p1xy), head_p2xy = std::move(head_p2xy)]() {
                        return ({
                            auto c_pa = p0;
                            ({
                            auto n_pb = crate::prelude::len(prism_rtl::deref(c_pa).fields_p);
                            auto tys_pc = field_types_f(prism_rtl::deref(c_pa).fields_p);
                            (crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(n_pb), ({
                            auto cp_p0xyx = cp_p0xy;
                            auto tys_pcx = tys_pc;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Nat)>>(prism_rtl::rc([=, cp_p0xyx = std::move(cp_p0xyx), tys_pcx = std::move(tys_pcx)](Nat p0) {
                            return ({
                                auto cp_p0xyxy = cp_p0xyx;
                                auto tys_pcxy = tys_pcx;
                                (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xyxy = std::move(cp_p0xyxy), tys_pcxy = std::move(tys_pcxy)]() {
                                return ({
                                    auto i_pf = p0;
                                    (crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xyxy, crate::prelude::or_(crate::prelude::index(tys_pcxy, i_pf), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}))), [=](Text cpp_type_f_17991) { return prism_rtl::finished(prism_rtl::cat("TRY(prism_rtl::from_pod<", cpp_type_f_17991, ">(c->args[", i_pf, "]))")); }));
                                });
                            })));
                            });
                        })));
                        })), [=](Array<Text> each_17943) {
                            return ({
                                auto args_pd = crate::syntax::lexer::chars::join_f(each_17943, Text::lit(", "));
                                auto made_pe = ({
                                    __label__ _done;
                                    prism_rtl::Slot<Text> _v;
                                    auto&& _m = prism_rtl::deref(t_p1xy).shape_p;
                                    if (prism_rtl::is<crate::lower::model::TyShape::ShapeChoice>(_m)) {
                                        _v.set(prism_rtl::cat(head_p2xy, "(", prism_rtl::deref(c_pa).name_p, "{", args_pd, "})"));
                                        goto _done;
                                    }
                                    {
                                        _v.set(prism_rtl::cat(head_p2xy, "{", args_pd, "}"));
                                        goto _done;
                                    }
                                _done:
                                    _v.take();
                                });
                                (prism_rtl::finished(prism_rtl::cat("if (c->ctor == \"", prism_rtl::deref(c_pa).prism_p, "\" && c->args.size() == ", n_pb, ") return ", made_pe, ";")));
                            });
                        }));
                        });
                        });
                    })));
                    });
                })));
                })));
                (prism_rtl::cat("const Pod& p = whole.structure();\nif (auto c = p.if_choice()) {\n", indent_cpp_f(crate::syntax::lexer::chars::join_f(arms_p9, Text::lit("\n"))), "\n}\nreturn mismatch<", head_p2, ">(\"a ", t_p1.prism_p, "\", p);"));
            }));
            goto _done;
        }
    _done:
        _v.take();
    });
    return crate::emit::cpp::templates::items::cpp_function_f(Text::lit(""), prism_rtl::cat(gens_p3, "Result<", head_p2, "> ", head_p2, "::from_pod(const Pod& whole)"), body_p4);
}


prism_rtl::Turn<Text> FromPodDef::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& t_p1 = this->t_p1;
    const auto& head_p2 = this->head_p2;
    const auto& gens_p3 = this->gens_p3;
    auto body_p4 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = prism_rtl::deref(t_p1).shape_p;
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeRecord>(_m)) {
            _v.set(({
                auto c_p5 = crate::prelude::or_(crate::prelude::index(prism_rtl::deref(t_p1).cases_p, Nat(0u)), crate::lower::model::CaseDef{.name_p = Text::lit(""), .prism_p = Text::lit(""), .fields_p = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .labels_p = Array<Text>{}});
                auto reads_p6 = crate::syntax::lexer::chars::join_f(crate::prelude::run_to_end(crate::prelude::each_job(prism_rtl::deref(c_p5).fields_p, ({
                    auto cp_p0x = cp_p0;
                    auto c_p5x = c_p5;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=, cp_p0x = std::move(cp_p0x), c_p5x = std::move(c_p5x)](std::tuple<Text, crate::lower::model::OutTy> p0) {
                    return ({
                        auto cp_p0xy = cp_p0x;
                        auto c_p5xy = c_p5x;
                        (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xy = std::move(cp_p0xy), c_p5xy = std::move(c_p5xy)]() {
                        return ({
                            auto [f_p7, ft_p8] = p0;
                            (crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xy, ft_p8), [=](Text cpp_type_f_17640) { return prism_rtl::finished(prism_rtl::cat(".", crate::emit::cpp::field_id_f(f_p7), " = TRY(prism_rtl::from_pod<", cpp_type_f_17640, ">(TRY(crate::prelude::field(whole, \"", prism_field_of_f(c_p5xy, f_p7), "\"))))")); }));
                        });
                    })));
                    });
                })));
                }))), Text::lit(", "));
                (prism_rtl::cat("return ", head_p2, "{", reads_p6, "};"));
            }));
            goto _done;
        }
        {
            _v.set(({
                auto arms_p9 = crate::prelude::run_to_end(crate::prelude::each_job(prism_rtl::deref(t_p1).cases_p, ({
                    auto cp_p0x = cp_p0;
                    auto t_p1x = t_p1;
                    auto head_p2x = head_p2;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::CaseDef)>>(prism_rtl::rc([=, cp_p0x = std::move(cp_p0x), t_p1x = std::move(t_p1x), head_p2x = std::move(head_p2x)](crate::lower::model::CaseDef p0) {
                    return ({
                        auto cp_p0xy = cp_p0x;
                        auto t_p1xy = t_p1x;
                        auto head_p2xy = head_p2x;
                        (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xy = std::move(cp_p0xy), t_p1xy = std::move(t_p1xy), head_p2xy = std::move(head_p2xy)]() {
                        return ({
                            auto c_pa = p0;
                            ({
                            auto n_pb = crate::prelude::len(prism_rtl::deref(c_pa).fields_p);
                            auto tys_pc = field_types_f(prism_rtl::deref(c_pa).fields_p);
                            (crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(n_pb), ({
                            auto cp_p0xyx = cp_p0xy;
                            auto tys_pcx = tys_pc;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Nat)>>(prism_rtl::rc([=, cp_p0xyx = std::move(cp_p0xyx), tys_pcx = std::move(tys_pcx)](Nat p0) {
                            return ({
                                auto cp_p0xyxy = cp_p0xyx;
                                auto tys_pcxy = tys_pcx;
                                (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xyxy = std::move(cp_p0xyxy), tys_pcxy = std::move(tys_pcxy)]() {
                                return ({
                                    auto i_pf = p0;
                                    (crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xyxy, crate::prelude::or_(crate::prelude::index(tys_pcxy, i_pf), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}))), [=](Text cpp_type_f_17991) { return prism_rtl::finished(prism_rtl::cat("TRY(prism_rtl::from_pod<", cpp_type_f_17991, ">(c->args[", i_pf, "]))")); }));
                                });
                            })));
                            });
                        })));
                        })), [=](Array<Text> each_17943) {
                            return ({
                                auto args_pd = crate::syntax::lexer::chars::join_f(each_17943, Text::lit(", "));
                                auto made_pe = ({
                                    __label__ _done;
                                    prism_rtl::Slot<Text> _v;
                                    auto&& _m = prism_rtl::deref(t_p1xy).shape_p;
                                    if (prism_rtl::is<crate::lower::model::TyShape::ShapeChoice>(_m)) {
                                        _v.set(prism_rtl::cat(head_p2xy, "(", prism_rtl::deref(c_pa).name_p, "{", args_pd, "})"));
                                        goto _done;
                                    }
                                    {
                                        _v.set(prism_rtl::cat(head_p2xy, "{", args_pd, "}"));
                                        goto _done;
                                    }
                                _done:
                                    _v.take();
                                });
                                (prism_rtl::finished(prism_rtl::cat("if (c->ctor == \"", prism_rtl::deref(c_pa).prism_p, "\" && c->args.size() == ", n_pb, ") return ", made_pe, ";")));
                            });
                        }));
                        });
                        });
                    })));
                    });
                })));
                })));
                (prism_rtl::cat("const Pod& p = whole.structure();\nif (auto c = p.if_choice()) {\n", indent_cpp_f(crate::syntax::lexer::chars::join_f(arms_p9, Text::lit("\n"))), "\n}\nreturn mismatch<", head_p2, ">(\"a ", prism_rtl::deref(t_p1).prism_p, "\", p);"));
            }));
            goto _done;
        }
    _done:
        _v.take();
    });
    return prism_rtl::finished(crate::emit::cpp::templates::items::cpp_function_f(Text::lit(""), prism_rtl::cat(gens_p3, "Result<", head_p2, "> ", head_p2, "::from_pod(const Pod& whole)"), body_p4));
}


/// `Start FromPodDef, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_from_pod_def_f(crate::emit::cpp::Cp cp_p0, crate::lower::model::TyDef t_p1, Text head_p2, Text gens_p3) {
    return prism_rtl::make_rc<FromPodDef>(cp_p0, t_p1, head_p2, gens_p3);
}


/// PrismField: fn Text -> Text
Text prism_field_f(const Text& f_p0) {
    return crate::syntax::lexer::chars::last_char_f(f_p0) == Text::lit("_")
        ? crate::syntax::lexer::chars::before_last_f(f_p0)
        : f_p0;
}


/// PrismFieldOf: fn CaseDef, Text -> Text
Text prism_field_of_f(const crate::lower::model::CaseDef& c_p0, const Text& f_p1) {
    return crate::prelude::fold(crate::check::errors::range0_f(crate::prelude::len(c_p0.fields_p)), prism_field_f(f_p1), [&](const Text& found_p2, const Nat& i_p3) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Text> _v;
            auto&& _m = std::tuple{crate::prelude::index(c_p0.fields_p, i_p3), crate::prelude::index(c_p0.labels_p, i_p3)};
            if (prism_rtl::is_some(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m))) {
                auto&& g_p4 = std::get<0>(prism_rtl::some_of(std::get<0>(_m)));
                auto&& label_p5 = prism_rtl::some_of(std::get<1>(_m));
                _v.set(g_p4 == f_p1 ? label_p5 : found_p2);
                goto _done;
            }
            {
                _v.set(found_p2);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


/// IndentCpp: fn Text -> Text
Text indent_cpp_f(const Text& t_p0) {
    return crate::syntax::lexer::chars::join_f(crate::prelude::each(crate::prelude::split_on(t_p0, Text::lit("\n")), [&](const Text& l_p1) { return l_p1 == Text::lit("") ? Text::lit("") : prism_rtl::cat("    ", l_p1); }), Text::lit("\n"));
}


/// TagParts: unbounded fn Cp, TagDef -> Parts
Parts tag_parts_f(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::TagDef& t_p1) {
    auto fields_p2 = crate::syntax::lexer::chars::join_f(crate::prelude::run_to_end(crate::prelude::each_job(t_p1.fields_p, ({
        auto cp_p0x = cp_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=, cp_p0x = std::move(cp_p0x)](std::tuple<Text, Text, crate::lower::model::OutTy> p0) {
        return ({
            auto cp_p0xy = cp_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xy = std::move(cp_p0xy)]() {
            return ({
                auto&& _f_ph = p0;
                auto&& f_ph = std::get<1>(_f_ph);
                auto&& ft_pi = std::get<2>(_f_ph);
                (crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xy, ft_pi), [=](Text cpp_type_f_19342) { return prism_rtl::finished(prism_rtl::cat(cpp_type_f_19342, " ", crate::emit::cpp::field_id_f(f_ph), ";")); }));
            });
        })));
        });
    })));
    }))), Text::lit("\n"));
    auto pods_p3 = crate::syntax::lexer::chars::join_f(crate::prelude::each(t_p1.fields_p, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
        auto&& p_pj = std::get<0>(_p0);
        auto&& f_pk = std::get<1>(_p0);
        return prism_rtl::cat("{\"", p_pj, "\", prism_rtl::to_pod(", crate::emit::cpp::field_id_f(f_pk), ")}");
    }), Text::lit(", "));
    auto reads_p4 = crate::syntax::lexer::chars::join_f(crate::prelude::run_to_end(crate::prelude::each_job(t_p1.fields_p, ({
        auto cp_p0x = cp_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=, cp_p0x = std::move(cp_p0x)](std::tuple<Text, Text, crate::lower::model::OutTy> p0) {
        return ({
            auto cp_p0xy = cp_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xy = std::move(cp_p0xy)]() {
            return ({
                auto [p_pl, f_pm, ft_pn] = p0;
                (crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xy, ft_pn), [=](Text cpp_type_f_19582) { return prism_rtl::finished(prism_rtl::cat(".", crate::emit::cpp::field_id_f(f_pm), " = TRY(prism_rtl::from_pod<", cpp_type_f_19582, ">(TRY(crate::prelude::field(p, \"", p_pl, "\"))))")); }));
            });
        })));
        });
    })));
    }))), Text::lit(", "));
    auto eq_p5 = t_p1.eq_p
        ? prism_rtl::cat("bool operator==(const ", t_p1.name_p, "&) const = default;")
        : Text::lit("");
    auto back_p6 = t_p1.pod_p
        ? prism_rtl::cat("static Result<", t_p1.name_p, "> from_pod(const Pod& p);")
        : Text::lit("");
    auto deep_p7 = crate::prelude::run_to_end(crate::prelude::fold_job(t_p1.fields_p, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, Text, crate::lower::model::OutTy>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<Text, Text, crate::lower::model::OutTy>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto d_po = p0;
                auto&& _ft_pp = p1;
                auto&& ft_pp = std::get<2>(_ft_pp);
                (prism_rtl::finished(std::move(d_po) || crate::lower::types::holds_dyn_f(ft_pp)));
            });
        }));
    }))));
    auto level_decl_p8 = std::move(deep_p7)
        ? Text::lit("/// The level as a World reads it: each dynamic it holds sampled at the read point.\nPod level_pod(const Cx& cx) const;\n/// The update events of the dynamics it holds, and of theirs.\nvoid level_ports(const Cx& cx, std::vector<prism_rtl::Rc<prism_rtl::Port<Unit>>>& out) const;")
        : Text::lit("");
    auto decl_p9 = crate::emit::cpp::templates::items::cpp_tag_struct_f(cpp_source_doc_f(prism_rtl::cat("The `Level` of `", t_p1.tag_name_p, "`:"), t_p1.doc_p), t_p1.name_p, fields_p2, t_p1.tag_name_p, crate::syntax::lexer::chars::join_f(crate::prelude::filter(Array(std::vector{eq_p5, back_p6, level_decl_p8}), [&](const Text& s_pq) { return s_pq != Text::lit(""); }), Text::lit("\n")));
    auto deep_pods_pa = crate::syntax::lexer::chars::join_f(crate::prelude::run_to_end(crate::prelude::each_job(t_p1.fields_p, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, Text, crate::lower::model::OutTy> p0) {
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto [p_pr, f_ps, ft_pt] = p0;
                (prism_rtl::more(prism_rtl::rc(CppDeepField(p_pr, f_ps, ft_pt))));
            });
        }));
    })))), Text::lit(", "));
    auto deep_ports_pb = crate::syntax::lexer::chars::join_f(crate::prelude::filter(crate::prelude::run_to_end(crate::prelude::each_job(t_p1.fields_p, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, Text, crate::lower::model::OutTy> p0) {
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto&& _f_pu = p0;
                auto&& f_pu = std::get<1>(_f_pu);
                auto&& ft_pv = std::get<2>(_f_pu);
                (prism_rtl::more(prism_rtl::rc(CppDeepPorts(f_pu, ft_pv))));
            });
        }));
    })))), [&](const Text& s_p10) { return s_p10 != Text::lit(""); }), Text::lit("\n"));
    auto level_defs_pc = std::move(deep_p7)
        ? Array(std::vector{crate::emit::cpp::templates::items::cpp_function_f(Text::lit(""), prism_rtl::cat("Pod ", t_p1.name_p, "::level_pod(const Cx& cx) const"), prism_rtl::cat("static_cast<void>(cx);\nreturn Pod::element(TAG, {", deep_pods_pa, "});")), crate::emit::cpp::templates::items::cpp_function_f(Text::lit(""), prism_rtl::cat("void ", t_p1.name_p, "::level_ports(const Cx& cx, std::vector<prism_rtl::Rc<prism_rtl::Port<Unit>>>& out) const"), prism_rtl::cat("static_cast<void>(cx);\nstatic_cast<void>(out);", deep_ports_pb == Text::lit("")
        ? Text::lit("")
        : prism_rtl::cat("\n", deep_ports_pb)))})
        : Array<Text>{};
    auto to_pod_pd = crate::emit::cpp::templates::items::cpp_function_f(Text::lit(""), prism_rtl::cat("Pod ", t_p1.name_p, "::to_pod() const"), prism_rtl::cat("return Pod::element(TAG, {", pods_p3, "});"));
    auto show_pe = crate::emit::cpp::templates::items::cpp_function_f(Text::lit(""), prism_rtl::cat("void ", t_p1.name_p, "::show(Printer& p) const"), Text::lit("prism_rtl::to_pod(*this).structure();\nShow<Pod>::show(prism_rtl::to_pod(*this), p);"));
    auto from_pod_pf = t_p1.pod_p
        ? Array(std::vector{crate::emit::cpp::templates::items::cpp_function_f(Text::lit(""), prism_rtl::cat("Result<", t_p1.name_p, "> ", t_p1.name_p, "::from_pod(const Pod& p)"), prism_rtl::cat("if (auto t = p.tag(); t && *t == TAG) return ", t_p1.name_p, "{", reads_p4, "};\nreturn mismatch<", t_p1.name_p, ">(\"a ", t_p1.tag_name_p, "\", p);"))})
        : Array<Text>{};
    auto deps_pg = crate::emit::cpp::patterns::concat2_f(crate::prelude::run_to_end(crate::prelude::each_job(t_p1.fields_p, ({
        auto cp_p0x = cp_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Text, Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=, cp_p0x = std::move(cp_p0x)](std::tuple<Text, Text, crate::lower::model::OutTy> p0) {
        return ({
            auto cp_p0xy = cp_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xy = std::move(cp_p0xy)]() {
            return ({
                auto&& _ft_p11 = p0;
                auto&& ft_p11 = std::get<2>(_ft_p11);
                (prism_rtl::more(prism_rtl::rc(ValueDeps(cp_p0xy, ft_p11))));
            });
        })));
        });
    })));
    }))));
    return Parts{.forward_p = Array(std::vector{prism_rtl::cat("struct ", t_p1.name_p, ";")}), .values_p = Array(std::vector{ValueDecl{.path_p = decl_path_f(cp_p0, t_p1.name_p), .deps_p = deps_pg, .text_p = decl_p9}}), .protos_p = Array<Text>{}, .classes_p = Array<Text>{}, .outer_p = Array<Text>{}, .generic_p = Array<Text>{}, .defs_p = crate::prelude::append(crate::prelude::append(Array(std::vector{to_pod_pd, show_pe}), from_pod_pf), level_defs_pc)};
}


prism_rtl::Turn<Parts> TagParts::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& t_p1 = this->t_p1;
    auto cp_p0x = cp_p0;
    auto t_p1x = t_p1;
    return crate::prelude::call_value(crate::prelude::each_job(prism_rtl::deref(t_p1x).fields_p, ({
        auto cp_p0xx = cp_p0x;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=, cp_p0xx = std::move(cp_p0xx)](std::tuple<Text, Text, crate::lower::model::OutTy> p0) {
        return ({
            auto cp_p0xxy = cp_p0xx;
            (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xxy = std::move(cp_p0xxy)]() {
            return ({
                auto&& _f_ph = p0;
                auto&& f_ph = std::get<1>(_f_ph);
                auto&& ft_pi = std::get<2>(_f_ph);
                (crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xxy, ft_pi), [=](Text cpp_type_f_19342) { return prism_rtl::finished(prism_rtl::cat(cpp_type_f_19342, " ", crate::emit::cpp::field_id_f(f_ph), ";")); }));
            });
        })));
        });
    })));
    })), [=](Array<Text> each_19304) {
        return ({
            auto fields_p2 = crate::syntax::lexer::chars::join_f(each_19304, Text::lit("\n"));
            auto pods_p3 = crate::syntax::lexer::chars::join_f(crate::prelude::each(prism_rtl::deref(t_p1x).fields_p, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
                auto&& p_pj = std::get<0>(_p0);
                auto&& f_pk = std::get<1>(_p0);
                return prism_rtl::cat("{\"", p_pj, "\", prism_rtl::to_pod(", crate::emit::cpp::field_id_f(f_pk), ")}");
            }), Text::lit(", "));
            (crate::prelude::call_value(crate::prelude::each_job(prism_rtl::deref(t_p1x).fields_p, ({
            auto cp_p0xx = cp_p0x;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=, cp_p0xx = std::move(cp_p0xx)](std::tuple<Text, Text, crate::lower::model::OutTy> p0) {
            return ({
                auto cp_p0xxy = cp_p0xx;
                (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xxy = std::move(cp_p0xxy)]() {
                return ({
                    auto [p_pl, f_pm, ft_pn] = p0;
                    (crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xxy, ft_pn), [=](Text cpp_type_f_19582) { return prism_rtl::finished(prism_rtl::cat(".", crate::emit::cpp::field_id_f(f_pm), " = TRY(prism_rtl::from_pod<", cpp_type_f_19582, ">(TRY(crate::prelude::field(p, \"", p_pl, "\"))))")); }));
                });
            })));
            });
        })));
        })), [=, fields_p2 = std::move(fields_p2), pods_p3 = std::move(pods_p3)](Array<Text> each_19510) {
            return ({
                auto reads_p4 = crate::syntax::lexer::chars::join_f(each_19510, Text::lit(", "));
                auto eq_p5 = prism_rtl::deref(t_p1x).eq_p
                    ? prism_rtl::cat("bool operator==(const ", prism_rtl::deref(t_p1x).name_p, "&) const = default;")
                    : Text::lit("");
                auto back_p6 = prism_rtl::deref(t_p1x).pod_p
                    ? prism_rtl::cat("static Result<", prism_rtl::deref(t_p1x).name_p, "> from_pod(const Pod& p);")
                    : Text::lit("");
                (crate::prelude::call_value(crate::prelude::fold_job(prism_rtl::deref(t_p1x).fields_p, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, Text, crate::lower::model::OutTy>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<Text, Text, crate::lower::model::OutTy>> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return crate::prelude::entered(crate::prelude::once_job([=]() {
                    return ({
                        auto d_po = p0;
                        auto&& _ft_pp = p1;
                        auto&& ft_pp = std::get<2>(_ft_pp);
                        (prism_rtl::finished(std::move(d_po) || crate::lower::types::holds_dyn_f(ft_pp)));
                    });
                }));
            }))), [=, reads_p4 = std::move(reads_p4), eq_p5 = std::move(eq_p5), back_p6 = std::move(back_p6)](bool fold_19901) {
                return ({
                    auto deep_p7 = fold_19901;
                    auto level_decl_p8 = std::move(deep_p7)
                        ? Text::lit("/// The level as a World reads it: each dynamic it holds sampled at the read point.\nPod level_pod(const Cx& cx) const;\n/// The update events of the dynamics it holds, and of theirs.\nvoid level_ports(const Cx& cx, std::vector<prism_rtl::Rc<prism_rtl::Port<Unit>>>& out) const;")
                        : Text::lit("");
                    auto decl_p9 = crate::emit::cpp::templates::items::cpp_tag_struct_f(cpp_source_doc_f(prism_rtl::cat("The `Level` of `", prism_rtl::deref(t_p1x).tag_name_p, "`:"), prism_rtl::deref(t_p1x).doc_p), prism_rtl::deref(t_p1x).name_p, fields_p2, prism_rtl::deref(t_p1x).tag_name_p, crate::syntax::lexer::chars::join_f(crate::prelude::filter(Array(std::vector{eq_p5, back_p6, level_decl_p8}), [&](const Text& s_pq) { return s_pq != Text::lit(""); }), Text::lit("\n")));
                    (crate::prelude::call_value(crate::prelude::each_job(prism_rtl::deref(t_p1x).fields_p, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, Text, crate::lower::model::OutTy> p0) {
                    return crate::prelude::entered(crate::prelude::once_job([=]() {
                        return ({
                            auto [p_pr, f_ps, ft_pt] = p0;
                            (prism_rtl::more(prism_rtl::rc(CppDeepField(p_pr, f_ps, ft_pt))));
                        });
                    }));
                }))), [=, deep_p7 = std::move(deep_p7), decl_p9 = std::move(decl_p9)](Array<Text> each_20483) {
                    return ({
                        auto deep_pods_pa = crate::syntax::lexer::chars::join_f(each_20483, Text::lit(", "));
                        (crate::prelude::call_value(crate::prelude::each_job(prism_rtl::deref(t_p1x).fields_p, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, Text, crate::lower::model::OutTy> p0) {
                        return crate::prelude::entered(crate::prelude::once_job([=]() {
                            return ({
                                auto&& _f_pu = p0;
                                auto&& f_pu = std::get<1>(_f_pu);
                                auto&& ft_pv = std::get<2>(_f_pu);
                                (prism_rtl::more(prism_rtl::rc(CppDeepPorts(f_pu, ft_pv))));
                            });
                        }));
                    }))), [=, deep_pods_pa = std::move(deep_pods_pa)](Array<Text> each_20577) {
                        return ({
                            auto deep_ports_pb = crate::syntax::lexer::chars::join_f(crate::prelude::filter(each_20577, [&](const Text& s_p10) { return s_p10 != Text::lit(""); }), Text::lit("\n"));
                            auto level_defs_pc = deep_p7
                                ? Array(std::vector{crate::emit::cpp::templates::items::cpp_function_f(Text::lit(""), prism_rtl::cat("Pod ", prism_rtl::deref(t_p1x).name_p, "::level_pod(const Cx& cx) const"), prism_rtl::cat("static_cast<void>(cx);\nreturn Pod::element(TAG, {", deep_pods_pa, "});")), crate::emit::cpp::templates::items::cpp_function_f(Text::lit(""), prism_rtl::cat("void ", prism_rtl::deref(t_p1x).name_p, "::level_ports(const Cx& cx, std::vector<prism_rtl::Rc<prism_rtl::Port<Unit>>>& out) const"), prism_rtl::cat("static_cast<void>(cx);\nstatic_cast<void>(out);", deep_ports_pb == Text::lit("")
                                ? Text::lit("")
                                : prism_rtl::cat("\n", deep_ports_pb)))})
                                : Array<Text>{};
                            auto to_pod_pd = crate::emit::cpp::templates::items::cpp_function_f(Text::lit(""), prism_rtl::cat("Pod ", prism_rtl::deref(t_p1x).name_p, "::to_pod() const"), prism_rtl::cat("return Pod::element(TAG, {", pods_p3, "});"));
                            auto show_pe = crate::emit::cpp::templates::items::cpp_function_f(Text::lit(""), prism_rtl::cat("void ", prism_rtl::deref(t_p1x).name_p, "::show(Printer& p) const"), Text::lit("prism_rtl::to_pod(*this).structure();\nShow<Pod>::show(prism_rtl::to_pod(*this), p);"));
                            auto from_pod_pf = prism_rtl::deref(t_p1x).pod_p
                                ? Array(std::vector{crate::emit::cpp::templates::items::cpp_function_f(Text::lit(""), prism_rtl::cat("Result<", prism_rtl::deref(t_p1x).name_p, "> ", prism_rtl::deref(t_p1x).name_p, "::from_pod(const Pod& p)"), prism_rtl::cat("if (auto t = p.tag(); t && *t == TAG) return ", prism_rtl::deref(t_p1x).name_p, "{", reads_p4, "};\nreturn mismatch<", prism_rtl::deref(t_p1x).name_p, ">(\"a ", prism_rtl::deref(t_p1x).tag_name_p, "\", p);"))})
                                : Array<Text>{};
                            (crate::prelude::call_value(crate::prelude::each_job(prism_rtl::deref(t_p1x).fields_p, ({
                            auto cp_p0xx = cp_p0x;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Text, Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=, cp_p0xx = std::move(cp_p0xx)](std::tuple<Text, Text, crate::lower::model::OutTy> p0) {
                            return ({
                                auto cp_p0xxy = cp_p0xx;
                                (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xxy = std::move(cp_p0xxy)]() {
                                return ({
                                    auto&& _ft_p11 = p0;
                                    auto&& ft_p11 = std::get<2>(_ft_p11);
                                    (prism_rtl::more(prism_rtl::rc(ValueDeps(cp_p0xxy, ft_p11))));
                                });
                            })));
                            });
                        })));
                        })), [=, level_defs_pc = std::move(level_defs_pc), to_pod_pd = std::move(to_pod_pd), show_pe = std::move(show_pe), from_pod_pf = std::move(from_pod_pf)](Array<Array<Text>> each_21571) {
                            return ({
                                auto deps_pg = crate::emit::cpp::patterns::concat2_f(each_21571);
                                (prism_rtl::finished(Parts{.forward_p = Array(std::vector{prism_rtl::cat("struct ", prism_rtl::deref(t_p1x).name_p, ";")}), .values_p = Array(std::vector{ValueDecl{.path_p = decl_path_f(cp_p0x, prism_rtl::deref(t_p1x).name_p), .deps_p = deps_pg, .text_p = decl_p9}}), .protos_p = Array<Text>{}, .classes_p = Array<Text>{}, .outer_p = Array<Text>{}, .generic_p = Array<Text>{}, .defs_p = crate::prelude::append(crate::prelude::append(Array(std::vector{to_pod_pd, show_pe}), from_pod_pf), level_defs_pc)}));
                            });
                        }));
                        });
                    }));
                    });
                }));
                });
            }));
            });
        }));
        });
    });
}


/// `Start TagParts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Parts> start_tag_parts_f(crate::emit::cpp::Cp cp_p0, crate::lower::model::TagDef t_p1) {
    return prism_rtl::make_rc<TagParts>(cp_p0, t_p1);
}


/// CppDeepField: unbounded fn Text, Text, OutTy -> Text
Text cpp_deep_field_f(const Text& p_p0, const Text& f_p1, const crate::lower::model::OutTy& ft_p2) {
    return prism_rtl::cat("{\"", p_p0, "\", ", cpp_deep_pod_f(f_p1, ft_p2), "}");
}


prism_rtl::Turn<Text> CppDeepField::cycle() const {
    const auto& p_p0 = this->p_p0;
    const auto& f_p1 = this->f_p1;
    const auto& ft_p2 = this->ft_p2;
    auto f_p1x = f_p1;
    auto ft_p2x = ft_p2;
    auto p_p0x = p_p0;
    return crate::prelude::call_then(start_cpp_deep_pod_f(f_p1x, ft_p2x), [=](Text cpp_deep_pod_f_22126) { return prism_rtl::finished(prism_rtl::cat("{\"", p_p0x, "\", ", cpp_deep_pod_f_22126, "}")); });
}


/// `Start CppDeepField, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_deep_field_f(Text p_p0, Text f_p1, crate::lower::model::OutTy ft_p2) {
    return prism_rtl::make_rc<CppDeepField>(p_p0, f_p1, ft_p2);
}


/// CppDeepPod: unbounded fn Text, OutTy -> Text
Text cpp_deep_pod_f(const Text& f_p0, const crate::lower::model::OutTy& ft_p1) {
    if (prism_rtl::is<crate::lower::model::OutTy::OutMap>(ft_p1)) {
        auto&& m22215_0_1 = prism_rtl::as<crate::lower::model::OutTy::OutMap>(ft_p1).a1;
        if (prism_rtl::is<crate::lower::model::OutTy::OutDyn>(prism_rtl::deref(prism_rtl::deref(m22215_0_1)))) {
            auto&& m22215_0_1_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(prism_rtl::deref(prism_rtl::deref(m22215_0_1))).a0;
            if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(prism_rtl::deref(prism_rtl::deref(m22215_0_1_r_0)))) {
                auto&& m22215_0_1_r_0_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(prism_rtl::deref(prism_rtl::deref(m22215_0_1_r_0))).a0;
                if (m22215_0_1_r_0_r_0 == Text::lit("crate::Elem")) {
                    return prism_rtl::cat("prism_rtl::dynamics_pod(", crate::emit::cpp::field_id_f(f_p0), ", cx)");
                }
            }
        }
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutDyn>(ft_p1)) {
        auto&& m22215_1_0 = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(ft_p1).a0;
        if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(prism_rtl::deref(prism_rtl::deref(m22215_1_0)))) {
            auto&& m22215_1_0_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(prism_rtl::deref(prism_rtl::deref(m22215_1_0))).a0;
            if (m22215_1_0_r_0 == Text::lit("crate::Elem")) {
                return prism_rtl::cat("prism_rtl::level_pod(", crate::emit::cpp::field_id_f(f_p0), ".sample(cx), cx)");
            }
        }
    }
    {
        auto&& other_p2 = ft_p1;
        return crate::lower::types::holds_dyn_f(other_p2)
            ? Text::lit("[] { static_assert(false, \"prismc: a tag field holding a dynamic other than `$Elem` or a map of them is not read deep (claude/incremental-host-document.md, doubt WD)\"); return Pod(); }()")
            : prism_rtl::cat("prism_rtl::to_pod(", crate::emit::cpp::field_id_f(f_p0), ")");
    }
}


prism_rtl::Turn<Text> CppDeepPod::cycle() const {
    const auto& f_p0 = this->f_p0;
    const auto& ft_p1 = this->ft_p1;
    return ({
        prism_rtl::is<crate::lower::model::OutTy::OutMap>(ft_p1) && ({
        auto&& m22215_0_1 = prism_rtl::as<crate::lower::model::OutTy::OutMap>(ft_p1).a1;
        prism_rtl::is<crate::lower::model::OutTy::OutDyn>(prism_rtl::deref(prism_rtl::deref(m22215_0_1))) && ({
        auto&& m22215_0_1_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(prism_rtl::deref(prism_rtl::deref(m22215_0_1))).a0;
        prism_rtl::is<crate::lower::model::OutTy::OutNamed>(prism_rtl::deref(prism_rtl::deref(m22215_0_1_r_0))) && ({
        auto&& m22215_0_1_r_0_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(prism_rtl::deref(prism_rtl::deref(m22215_0_1_r_0))).a0;
        (m22215_0_1_r_0_r_0 == Text::lit("crate::Elem"));
    });
    });
    }) ? ({
        auto&& m22215_0_1 = prism_rtl::as<crate::lower::model::OutTy::OutMap>(ft_p1).a1;
        auto&& m22215_0_1_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(prism_rtl::deref(prism_rtl::deref(m22215_0_1))).a0;
        auto&& m22215_0_1_r_0_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(prism_rtl::deref(prism_rtl::deref(m22215_0_1_r_0))).a0;
        prism_rtl::finished(prism_rtl::cat("prism_rtl::dynamics_pod(", crate::emit::cpp::field_id_f(f_p0), ", cx)"));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutDyn>(ft_p1) && ({
        auto&& m22215_1_0 = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(ft_p1).a0;
        prism_rtl::is<crate::lower::model::OutTy::OutNamed>(prism_rtl::deref(prism_rtl::deref(m22215_1_0))) && ({
        auto&& m22215_1_0_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(prism_rtl::deref(prism_rtl::deref(m22215_1_0))).a0;
        (m22215_1_0_r_0 == Text::lit("crate::Elem"));
    });
    }) ? ({
        auto&& m22215_1_0 = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(ft_p1).a0;
        auto&& m22215_1_0_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(prism_rtl::deref(prism_rtl::deref(m22215_1_0))).a0;
        prism_rtl::finished(prism_rtl::cat("prism_rtl::level_pod(", crate::emit::cpp::field_id_f(f_p0), ".sample(cx), cx)"));
    })
        : ({
        auto&& other_p2 = ft_p1;
        ({
        auto f_p0x = f_p0;
        auto other_p2x = other_p2;
        (crate::prelude::call_then(crate::lower::types::start_holds_dyn_f(other_p2x), [=, f_p0x = std::move(f_p0x)](bool holds_dyn_f_22440) {
        return holds_dyn_f_22440
            ? prism_rtl::finished(Text::lit("[] { static_assert(false, \"prismc: a tag field holding a dynamic other than `$Elem` or a map of them is not read deep (claude/incremental-host-document.md, doubt WD)\"); return Pod(); }()"))
            : prism_rtl::finished(prism_rtl::cat("prism_rtl::to_pod(", crate::emit::cpp::field_id_f(f_p0x), ")"));
    }));
    });
    });
    });
}


/// `Start CppDeepPod, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_deep_pod_f(Text f_p0, crate::lower::model::OutTy ft_p1) {
    return prism_rtl::make_rc<CppDeepPod>(f_p0, ft_p1);
}


/// CppDeepPorts: unbounded fn Text, OutTy -> Text
Text cpp_deep_ports_f(const Text& f_p0, const crate::lower::model::OutTy& ft_p1) {
    if (prism_rtl::is<crate::lower::model::OutTy::OutMap>(ft_p1)) {
        auto&& m22760_0_1 = prism_rtl::as<crate::lower::model::OutTy::OutMap>(ft_p1).a1;
        if (prism_rtl::is<crate::lower::model::OutTy::OutDyn>(prism_rtl::deref(prism_rtl::deref(m22760_0_1)))) {
            auto&& m22760_0_1_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(prism_rtl::deref(prism_rtl::deref(m22760_0_1))).a0;
            if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(prism_rtl::deref(prism_rtl::deref(m22760_0_1_r_0)))) {
                auto&& m22760_0_1_r_0_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(prism_rtl::deref(prism_rtl::deref(m22760_0_1_r_0))).a0;
                if (m22760_0_1_r_0_r_0 == Text::lit("crate::Elem")) {
                    return prism_rtl::cat("prism_rtl::dynamics_ports(", crate::emit::cpp::field_id_f(f_p0), ", cx, out);");
                }
            }
        }
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutDyn>(ft_p1)) {
        auto&& m22760_1_0 = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(ft_p1).a0;
        if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(prism_rtl::deref(prism_rtl::deref(m22760_1_0)))) {
            auto&& m22760_1_0_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(prism_rtl::deref(prism_rtl::deref(m22760_1_0))).a0;
            if (m22760_1_0_r_0 == Text::lit("crate::Elem")) {
                return prism_rtl::cat("out.push_back(", crate::emit::cpp::field_id_f(f_p0), ".updates);\nprism_rtl::level_ports(", crate::emit::cpp::field_id_f(f_p0), ".sample(cx), cx, out);");
            }
        }
    }
    {
        return Text::lit("");
    }
}


prism_rtl::Turn<Text> CppDeepPorts::cycle() const {
    const auto& f_p0 = this->f_p0;
    const auto& ft_p1 = this->ft_p1;
    return ({
        prism_rtl::is<crate::lower::model::OutTy::OutMap>(ft_p1) && ({
        auto&& m22760_0_1 = prism_rtl::as<crate::lower::model::OutTy::OutMap>(ft_p1).a1;
        prism_rtl::is<crate::lower::model::OutTy::OutDyn>(prism_rtl::deref(prism_rtl::deref(m22760_0_1))) && ({
        auto&& m22760_0_1_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(prism_rtl::deref(prism_rtl::deref(m22760_0_1))).a0;
        prism_rtl::is<crate::lower::model::OutTy::OutNamed>(prism_rtl::deref(prism_rtl::deref(m22760_0_1_r_0))) && ({
        auto&& m22760_0_1_r_0_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(prism_rtl::deref(prism_rtl::deref(m22760_0_1_r_0))).a0;
        (m22760_0_1_r_0_r_0 == Text::lit("crate::Elem"));
    });
    });
    }) ? ({
        auto&& m22760_0_1 = prism_rtl::as<crate::lower::model::OutTy::OutMap>(ft_p1).a1;
        auto&& m22760_0_1_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(prism_rtl::deref(prism_rtl::deref(m22760_0_1))).a0;
        auto&& m22760_0_1_r_0_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(prism_rtl::deref(prism_rtl::deref(m22760_0_1_r_0))).a0;
        prism_rtl::finished(prism_rtl::cat("prism_rtl::dynamics_ports(", crate::emit::cpp::field_id_f(f_p0), ", cx, out);"));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutDyn>(ft_p1) && ({
        auto&& m22760_1_0 = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(ft_p1).a0;
        prism_rtl::is<crate::lower::model::OutTy::OutNamed>(prism_rtl::deref(prism_rtl::deref(m22760_1_0))) && ({
        auto&& m22760_1_0_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(prism_rtl::deref(prism_rtl::deref(m22760_1_0))).a0;
        (m22760_1_0_r_0 == Text::lit("crate::Elem"));
    });
    }) ? ({
        auto&& m22760_1_0 = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(ft_p1).a0;
        auto&& m22760_1_0_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(prism_rtl::deref(prism_rtl::deref(m22760_1_0))).a0;
        prism_rtl::finished(prism_rtl::cat("out.push_back(", crate::emit::cpp::field_id_f(f_p0), ".updates);\nprism_rtl::level_ports(", crate::emit::cpp::field_id_f(f_p0), ".sample(cx), cx, out);"));
    })
        : prism_rtl::finished(Text::lit(""));
    });
}


/// `Start CppDeepPorts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_deep_ports_f(Text f_p0, crate::lower::model::OutTy ft_p1) {
    return prism_rtl::make_rc<CppDeepPorts>(f_p0, ft_p1);
}


/// RowParts: unbounded fn Cp, Text, RowDef -> Parts
Parts row_parts_f(const crate::emit::cpp::Cp& cp_p0, const Text& m_p1, const crate::lower::model::RowDef& r_p2) {
    auto names_p3 = crate::prelude::each(r_p2.cases_p, [&](const std::tuple<Text, Text>& _p0) {
        auto&& v_pf = std::get<0>(_p0);
        return v_pf;
    });
    auto levels_p4 = r_p2.level_p
        ? Text::lit("\nPod level_pod(const Cx& cx) const;\nvoid level_ports(const Cx& cx, std::vector<prism_rtl::Rc<prism_rtl::Port<Unit>>>& out) const;")
        : Text::lit("");
    auto pod_p5 = prism_rtl::cat("Pod to_pod() const;\nvoid show(Printer& p) const;", r_p2.pod_p
        ? prism_rtl::cat("\nstatic Result<", r_p2.name_p, "> from_pod(const Pod& p);")
        : Text::lit(""), levels_p4);
    auto cases_p6 = crate::syntax::lexer::chars::join_f(crate::prelude::each(r_p2.cases_p, [&](const std::tuple<Text, Text>& _p0) {
        auto&& v_pg = std::get<0>(_p0);
        auto&& st_ph = std::get<1>(_p0);
        return crate::emit::cpp::templates::items::case_decl_f(v_pg, prism_rtl::cat(row_struct_f(m_p1, st_ph), " a0;", r_p2.eq_p
            ? prism_rtl::cat("\nbool operator==(const ", v_pg, "&) const = default;")
            : Text::lit("")));
    }), Text::lit("\n"));
    auto cls_p7 = crate::emit::cpp::templates::items::choice_class_f(cpp_source_doc_f(prism_rtl::cat("`", r_p2.prism_p, "`, a row kind\'s values:"), r_p2.doc_p), Text::lit(""), r_p2.name_p, cases_p6, crate::syntax::lexer::chars::join_f(names_p3, Text::lit(", ")), pod_p5);
    auto eq_p8 = r_p2.eq_p
        ? prism_rtl::cat("\ninline bool operator==(const ", r_p2.name_p, "& a, const ", r_p2.name_p, "& b) { return a.cases() == b.cases(); }")
        : Text::lit("");
    auto level_defs_p9 = r_p2.level_p
        ? Array(std::vector{crate::emit::cpp::templates::items::cpp_function_f(Text::lit(""), prism_rtl::cat("Pod ", r_p2.name_p, "::level_pod(const Cx& cx) const"), Text::lit("return std::visit([&](const auto& c) { return prism_rtl::level_pod(c.a0, cx); }, cases());")), crate::emit::cpp::templates::items::cpp_function_f(Text::lit(""), prism_rtl::cat("void ", r_p2.name_p, "::level_ports(const Cx& cx, std::vector<prism_rtl::Rc<prism_rtl::Port<Unit>>>& out) const"), Text::lit("std::visit([&](const auto& c) { prism_rtl::level_ports(c.a0, cx, out); }, cases());"))})
        : Array<Text>{};
    auto to_pod_pa = crate::emit::cpp::templates::items::cpp_function_f(Text::lit(""), prism_rtl::cat("Pod ", r_p2.name_p, "::to_pod() const"), Text::lit("return std::visit([](const auto& c) { return prism_rtl::to_pod(c.a0); }, cases());"));
    auto show_pb = crate::emit::cpp::templates::items::cpp_function_f(Text::lit(""), prism_rtl::cat("void ", r_p2.name_p, "::show(Printer& p) const"), Text::lit("Show<Pod>::show(to_pod(), p);"));
    auto reads_pc = crate::syntax::lexer::chars::join_f(crate::prelude::each(r_p2.cases_p, [&](const std::tuple<Text, Text>& _p0) {
        auto&& v_pi = std::get<0>(_p0);
        auto&& st_pj = std::get<1>(_p0);
        return prism_rtl::cat("if (*t == ", row_struct_f(m_p1, st_pj), "::TAG) return ", r_p2.name_p, "(", v_pi, "{TRY(prism_rtl::from_pod<", row_struct_f(m_p1, st_pj), ">(p))});");
    }), Text::lit("\n"));
    auto from_pod_pd = r_p2.pod_p
        ? Array(std::vector{crate::emit::cpp::templates::items::cpp_function_f(Text::lit(""), prism_rtl::cat("Result<", r_p2.name_p, "> ", r_p2.name_p, "::from_pod(const Pod& p)"), prism_rtl::cat("if (auto t = p.tag()) {\n", indent_cpp_f(reads_pc), "\n}\nreturn mismatch<", r_p2.name_p, ">(\"a ", r_p2.name_p, "\", p);"))})
        : Array<Text>{};
    auto deps_pe = crate::emit::cpp::patterns::concat2_f(crate::prelude::run_to_end(crate::prelude::each_job(r_p2.cases_p, ({
        auto cp_p0x = cp_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Text, Text>)>>(prism_rtl::rc([=, cp_p0x = std::move(cp_p0x)](std::tuple<Text, Text> p0) {
        return ({
            auto cp_p0xy = cp_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xy = std::move(cp_p0xy)]() {
            return ({
                auto&& _st_pk = p0;
                auto&& st_pk = std::get<1>(_st_pk);
                (prism_rtl::more(prism_rtl::rc(ValueDeps(cp_p0xy, crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{st_pk, Array<crate::lower::model::OutTy>{}})))));
            });
        })));
        });
    })));
    }))));
    return Parts{.forward_p = Array(std::vector{prism_rtl::cat("class ", r_p2.name_p, ";")}), .values_p = Array(std::vector{ValueDecl{.path_p = decl_path_f(cp_p0, r_p2.name_p), .deps_p = deps_pe, .text_p = prism_rtl::cat(cls_p7, eq_p8)}}), .protos_p = Array<Text>{}, .classes_p = Array<Text>{}, .outer_p = Array<Text>{}, .generic_p = Array<Text>{}, .defs_p = crate::prelude::append(crate::prelude::append(Array(std::vector{to_pod_pa, show_pb}), from_pod_pd), level_defs_p9)};
}


prism_rtl::Turn<Parts> RowParts::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& m_p1 = this->m_p1;
    const auto& r_p2 = this->r_p2;
    auto names_p3 = crate::prelude::each(prism_rtl::deref(r_p2).cases_p, [&](const std::tuple<Text, Text>& _p0) {
        auto&& v_pf = std::get<0>(_p0);
        return v_pf;
    });
    auto levels_p4 = prism_rtl::deref(r_p2).level_p
        ? Text::lit("\nPod level_pod(const Cx& cx) const;\nvoid level_ports(const Cx& cx, std::vector<prism_rtl::Rc<prism_rtl::Port<Unit>>>& out) const;")
        : Text::lit("");
    auto pod_p5 = prism_rtl::cat("Pod to_pod() const;\nvoid show(Printer& p) const;", prism_rtl::deref(r_p2).pod_p
        ? prism_rtl::cat("\nstatic Result<", prism_rtl::deref(r_p2).name_p, "> from_pod(const Pod& p);")
        : Text::lit(""), levels_p4);
    auto cases_p6 = crate::syntax::lexer::chars::join_f(crate::prelude::each(prism_rtl::deref(r_p2).cases_p, [&](const std::tuple<Text, Text>& _p0) {
        auto&& v_pg = std::get<0>(_p0);
        auto&& st_ph = std::get<1>(_p0);
        return crate::emit::cpp::templates::items::case_decl_f(v_pg, prism_rtl::cat(row_struct_f(m_p1, st_ph), " a0;", prism_rtl::deref(r_p2).eq_p
            ? prism_rtl::cat("\nbool operator==(const ", v_pg, "&) const = default;")
            : Text::lit("")));
    }), Text::lit("\n"));
    auto cls_p7 = crate::emit::cpp::templates::items::choice_class_f(cpp_source_doc_f(prism_rtl::cat("`", prism_rtl::deref(r_p2).prism_p, "`, a row kind\'s values:"), prism_rtl::deref(r_p2).doc_p), Text::lit(""), prism_rtl::deref(r_p2).name_p, cases_p6, crate::syntax::lexer::chars::join_f(names_p3, Text::lit(", ")), pod_p5);
    auto eq_p8 = prism_rtl::deref(r_p2).eq_p
        ? prism_rtl::cat("\ninline bool operator==(const ", prism_rtl::deref(r_p2).name_p, "& a, const ", prism_rtl::deref(r_p2).name_p, "& b) { return a.cases() == b.cases(); }")
        : Text::lit("");
    auto level_defs_p9 = prism_rtl::deref(r_p2).level_p
        ? Array(std::vector{crate::emit::cpp::templates::items::cpp_function_f(Text::lit(""), prism_rtl::cat("Pod ", prism_rtl::deref(r_p2).name_p, "::level_pod(const Cx& cx) const"), Text::lit("return std::visit([&](const auto& c) { return prism_rtl::level_pod(c.a0, cx); }, cases());")), crate::emit::cpp::templates::items::cpp_function_f(Text::lit(""), prism_rtl::cat("void ", prism_rtl::deref(r_p2).name_p, "::level_ports(const Cx& cx, std::vector<prism_rtl::Rc<prism_rtl::Port<Unit>>>& out) const"), Text::lit("std::visit([&](const auto& c) { prism_rtl::level_ports(c.a0, cx, out); }, cases());"))})
        : Array<Text>{};
    auto to_pod_pa = crate::emit::cpp::templates::items::cpp_function_f(Text::lit(""), prism_rtl::cat("Pod ", prism_rtl::deref(r_p2).name_p, "::to_pod() const"), Text::lit("return std::visit([](const auto& c) { return prism_rtl::to_pod(c.a0); }, cases());"));
    auto show_pb = crate::emit::cpp::templates::items::cpp_function_f(Text::lit(""), prism_rtl::cat("void ", prism_rtl::deref(r_p2).name_p, "::show(Printer& p) const"), Text::lit("Show<Pod>::show(to_pod(), p);"));
    auto reads_pc = crate::syntax::lexer::chars::join_f(crate::prelude::each(prism_rtl::deref(r_p2).cases_p, [&](const std::tuple<Text, Text>& _p0) {
        auto&& v_pi = std::get<0>(_p0);
        auto&& st_pj = std::get<1>(_p0);
        return prism_rtl::cat("if (*t == ", row_struct_f(m_p1, st_pj), "::TAG) return ", prism_rtl::deref(r_p2).name_p, "(", v_pi, "{TRY(prism_rtl::from_pod<", row_struct_f(m_p1, st_pj), ">(p))});");
    }), Text::lit("\n"));
    auto from_pod_pd = prism_rtl::deref(r_p2).pod_p
        ? Array(std::vector{crate::emit::cpp::templates::items::cpp_function_f(Text::lit(""), prism_rtl::cat("Result<", prism_rtl::deref(r_p2).name_p, "> ", prism_rtl::deref(r_p2).name_p, "::from_pod(const Pod& p)"), prism_rtl::cat("if (auto t = p.tag()) {\n", indent_cpp_f(reads_pc), "\n}\nreturn mismatch<", prism_rtl::deref(r_p2).name_p, ">(\"a ", prism_rtl::deref(r_p2).name_p, "\", p);"))})
        : Array<Text>{};
    auto cp_p0x = cp_p0;
    auto r_p2x = r_p2;
    return crate::prelude::call_value(crate::prelude::each_job(prism_rtl::deref(r_p2x).cases_p, ({
        auto cp_p0xx = cp_p0x;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Text, Text>)>>(prism_rtl::rc([=, cp_p0xx = std::move(cp_p0xx)](std::tuple<Text, Text> p0) {
        return ({
            auto cp_p0xxy = cp_p0xx;
            (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xxy = std::move(cp_p0xxy)]() {
            return ({
                auto&& _st_pk = p0;
                auto&& st_pk = std::get<1>(_st_pk);
                (prism_rtl::more(prism_rtl::rc(ValueDeps(cp_p0xxy, crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{st_pk, Array<crate::lower::model::OutTy>{}})))));
            });
        })));
        });
    })));
    })), [=](Array<Array<Text>> each_25198) {
        return ({
            auto deps_pe = crate::emit::cpp::patterns::concat2_f(each_25198);
            (prism_rtl::finished(Parts{.forward_p = Array(std::vector{prism_rtl::cat("class ", prism_rtl::deref(r_p2x).name_p, ";")}), .values_p = Array(std::vector{ValueDecl{.path_p = decl_path_f(cp_p0x, prism_rtl::deref(r_p2x).name_p), .deps_p = deps_pe, .text_p = prism_rtl::cat(cls_p7, eq_p8)}}), .protos_p = Array<Text>{}, .classes_p = Array<Text>{}, .outer_p = Array<Text>{}, .generic_p = Array<Text>{}, .defs_p = crate::prelude::append(crate::prelude::append(Array(std::vector{to_pod_pa, show_pb}), from_pod_pd), level_defs_p9)}));
        });
    });
}


/// `Start RowParts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Parts> start_row_parts_f(crate::emit::cpp::Cp cp_p0, Text m_p1, crate::lower::model::RowDef r_p2) {
    return prism_rtl::make_rc<RowParts>(cp_p0, m_p1, r_p2);
}


/// RowStruct: fn Text, Text -> Text
Text row_struct_f(const Text& m_p0, const Text& st_p1) {
    return crate::syntax::lexer::chars::contains_f(st_p1, Text::lit(":")) || (m_p0 == Text::lit(""))
        ? crate::emit::cpp::type_path_f(st_p1)
        : prism_rtl::cat("crate::", m_p0, "::", st_p1);
}


/// AnswerParts: unbounded fn Cp, AnswerDef -> Parts
Parts answer_parts_f(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::AnswerDef& a_p1) {
    auto names_p2 = crate::prelude::each(a_p1.cases_p, [&](const crate::lower::model::AnswerCase& c_pc) { return prism_rtl::deref(c_pc).variant_p; });
    auto accessors_p3 = crate::syntax::lexer::chars::join_f(crate::prelude::run_to_end(crate::prelude::each_job(a_p1.cases_p, ({
        auto cp_p0x = cp_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::AnswerCase)>>(prism_rtl::rc([=, cp_p0x = std::move(cp_p0x)](crate::lower::model::AnswerCase p0) {
        return ({
            auto cp_p0xy = cp_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xy = std::move(cp_p0xy)]() {
            return ({
                auto c_pd = p0;
                (crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xy, prism_rtl::deref(c_pd).ty_p), [=](Text cpp_type_f_26057) { return prism_rtl::finished(prism_rtl::cat("Result<", cpp_type_f_26057, "> ", prism_rtl::deref(c_pd).accessor_p, "() const;")); }));
            });
        })));
        });
    })));
    }))), Text::lit("\n"));
    auto members_p4 = prism_rtl::cat("const char* tag() const;\n", accessors_p3, "\nstatic Result<Answer> decode(const Elem& e, const Pod& v);");
    auto cases_p5 = crate::syntax::lexer::chars::join_f(crate::prelude::run_to_end(crate::prelude::each_job(a_p1.cases_p, ({
        auto cp_p0x = cp_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::AnswerCase)>>(prism_rtl::rc([=, cp_p0x = std::move(cp_p0x)](crate::lower::model::AnswerCase p0) {
        return ({
            auto cp_p0xy = cp_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xy = std::move(cp_p0xy)]() {
            return ({
                auto c_pe = p0;
                (crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xy, prism_rtl::deref(c_pe).ty_p), [=](Text cpp_type_f_26287) { return prism_rtl::finished(crate::emit::cpp::templates::items::case_decl_f(prism_rtl::deref(c_pe).variant_p, prism_rtl::cat(cpp_type_f_26287, " a0;"))); }));
            });
        })));
        });
    })));
    }))), Text::lit("\n"));
    auto cls_p6 = crate::emit::cpp::templates::items::choice_class_f(cpp_doc_f(Text::lit("`Answer c`: an answer to an element, typed by its tag (Semantics ch. 9): what a host\'s\nsupplier answers a child place with, and what a World\'s answer to a forwarded element\ndecodes to, carrying the tag\'s output.")), Text::lit(""), Text::lit("Answer"), cases_p5, crate::syntax::lexer::chars::join_f(names_p2, Text::lit(", ")), members_p4);
    auto tags_p7 = crate::syntax::lexer::chars::join_f(crate::prelude::each(a_p1.cases_p, [&](const crate::lower::model::AnswerCase& c_pf) { return prism_rtl::cat("if (std::holds_alternative<", prism_rtl::deref(c_pf).variant_p, ">(cases())) return ", crate::emit::cpp::type_path_f(prism_rtl::deref(c_pf).struct_path_p), "::TAG;"); }), Text::lit("\n"));
    auto tag_fn_p8 = crate::emit::cpp::templates::items::cpp_function_f(Text::lit(""), Text::lit("const char* Answer::tag() const"), prism_rtl::cat(tags_p7, "\nprism_rtl::unreachable();"));
    auto getters_p9 = crate::prelude::run_to_end(crate::prelude::each_job(a_p1.cases_p, ({
        auto cp_p0x = cp_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::AnswerCase)>>(prism_rtl::rc([=, cp_p0x = std::move(cp_p0x)](crate::lower::model::AnswerCase p0) {
        return ({
            auto cp_p0xy = cp_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xy = std::move(cp_p0xy)]() {
            return ({
                auto c_pg = p0;
                (crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xy, prism_rtl::deref(c_pg).ty_p), [=](Text cpp_type_f_26953) { return prism_rtl::finished(crate::emit::cpp::templates::items::cpp_function_f(cpp_doc_f(prism_rtl::cat("A `", prism_rtl::deref(c_pg).tag_name_p, "`\'s answer.")), prism_rtl::cat("Result<", cpp_type_f_26953, "> Answer::", prism_rtl::deref(c_pg).accessor_p, "() const"), prism_rtl::cat("if (auto c = std::get_if<", prism_rtl::deref(c_pg).variant_p, ">(&cases())) return c->a0;\nreturn unexpected(Fault::answer(str(\"an answer for \", tag(), \", where ", prism_rtl::deref(c_pg).tag_name_p, "\'s was expected\")));"))); }));
            });
        })));
        });
    })));
    })));
    auto decodes_pa = crate::syntax::lexer::chars::join_f(crate::prelude::run_to_end(crate::prelude::each_job(a_p1.cases_p, ({
        auto cp_p0x = cp_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::AnswerCase)>>(prism_rtl::rc([=, cp_p0x = std::move(cp_p0x)](crate::lower::model::AnswerCase p0) {
        return ({
            auto cp_p0xy = cp_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xy = std::move(cp_p0xy)]() {
            return ({
                auto c_ph = p0;
                (crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xy, prism_rtl::deref(c_ph).ty_p), [=](Text cpp_type_f_27301) { return prism_rtl::finished(prism_rtl::cat("if (is<Elem::", prism_rtl::deref(c_ph).variant_p, ">(e)) return Answer(", prism_rtl::deref(c_ph).variant_p, "{TRY(prism_rtl::from_pod<", cpp_type_f_27301, ">(v))});")); }));
            });
        })));
        });
    })));
    }))), Text::lit("\n"));
    auto decode_pb = crate::emit::cpp::templates::items::cpp_function_f(cpp_doc_f(Text::lit("A World\'s answer to the element `e`, decoded by its tag.")), Text::lit("Result<Answer> Answer::decode(const Elem& e, const Pod& v)"), prism_rtl::cat(decodes_pa, "\nprism_rtl::unreachable();"));
    return Parts{.forward_p = Array(std::vector{Text::lit("class Answer;")}), .values_p = Array(std::vector{ValueDecl{.path_p = Text::lit("Answer"), .deps_p = Array<Text>{}, .text_p = cls_p6}}), .protos_p = Array<Text>{}, .classes_p = Array<Text>{}, .outer_p = Array<Text>{}, .generic_p = Array<Text>{}, .defs_p = crate::prelude::append(Array(std::vector{tag_fn_p8}), crate::prelude::push(getters_p9, decode_pb))};
}


prism_rtl::Turn<Parts> AnswerParts::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& a_p1 = this->a_p1;
    auto names_p2 = crate::prelude::each(prism_rtl::deref(a_p1).cases_p, [&](const crate::lower::model::AnswerCase& c_pc) { return prism_rtl::deref(c_pc).variant_p; });
    auto a_p1x = a_p1;
    auto cp_p0x = cp_p0;
    return crate::prelude::call_value(crate::prelude::each_job(prism_rtl::deref(a_p1x).cases_p, ({
        auto cp_p0xx = cp_p0x;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::AnswerCase)>>(prism_rtl::rc([=, cp_p0xx = std::move(cp_p0xx)](crate::lower::model::AnswerCase p0) {
        return ({
            auto cp_p0xxy = cp_p0xx;
            (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xxy = std::move(cp_p0xxy)]() {
            return ({
                auto c_pd = p0;
                (crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xxy, prism_rtl::deref(c_pd).ty_p), [=](Text cpp_type_f_26057) { return prism_rtl::finished(prism_rtl::cat("Result<", cpp_type_f_26057, "> ", prism_rtl::deref(c_pd).accessor_p, "() const;")); }));
            });
        })));
        });
    })));
    })), [=](Array<Text> each_26029) {
        return ({
            auto accessors_p3 = crate::syntax::lexer::chars::join_f(each_26029, Text::lit("\n"));
            auto members_p4 = prism_rtl::cat("const char* tag() const;\n", accessors_p3, "\nstatic Result<Answer> decode(const Elem& e, const Pod& v);");
            (crate::prelude::call_value(crate::prelude::each_job(prism_rtl::deref(a_p1x).cases_p, ({
            auto cp_p0xx = cp_p0x;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::AnswerCase)>>(prism_rtl::rc([=, cp_p0xx = std::move(cp_p0xx)](crate::lower::model::AnswerCase p0) {
            return ({
                auto cp_p0xxy = cp_p0xx;
                (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xxy = std::move(cp_p0xxy)]() {
                return ({
                    auto c_pe = p0;
                    (crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xxy, prism_rtl::deref(c_pe).ty_p), [=](Text cpp_type_f_26287) { return prism_rtl::finished(crate::emit::cpp::templates::items::case_decl_f(prism_rtl::deref(c_pe).variant_p, prism_rtl::cat(cpp_type_f_26287, " a0;"))); }));
                });
            })));
            });
        })));
        })), [=, members_p4 = std::move(members_p4)](Array<Text> each_26246) {
            return ({
                auto cases_p5 = crate::syntax::lexer::chars::join_f(each_26246, Text::lit("\n"));
                auto cls_p6 = crate::emit::cpp::templates::items::choice_class_f(cpp_doc_f(Text::lit("`Answer c`: an answer to an element, typed by its tag (Semantics ch. 9): what a host\'s\nsupplier answers a child place with, and what a World\'s answer to a forwarded element\ndecodes to, carrying the tag\'s output.")), Text::lit(""), Text::lit("Answer"), cases_p5, crate::syntax::lexer::chars::join_f(names_p2, Text::lit(", ")), members_p4);
                auto tags_p7 = crate::syntax::lexer::chars::join_f(crate::prelude::each(prism_rtl::deref(a_p1x).cases_p, [&](const crate::lower::model::AnswerCase& c_pf) { return prism_rtl::cat("if (std::holds_alternative<", prism_rtl::deref(c_pf).variant_p, ">(cases())) return ", crate::emit::cpp::type_path_f(prism_rtl::deref(c_pf).struct_path_p), "::TAG;"); }), Text::lit("\n"));
                auto tag_fn_p8 = crate::emit::cpp::templates::items::cpp_function_f(Text::lit(""), Text::lit("const char* Answer::tag() const"), prism_rtl::cat(tags_p7, "\nprism_rtl::unreachable();"));
                (crate::prelude::call_value(crate::prelude::each_job(prism_rtl::deref(a_p1x).cases_p, ({
                auto cp_p0xx = cp_p0x;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::AnswerCase)>>(prism_rtl::rc([=, cp_p0xx = std::move(cp_p0xx)](crate::lower::model::AnswerCase p0) {
                return ({
                    auto cp_p0xxy = cp_p0xx;
                    (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xxy = std::move(cp_p0xxy)]() {
                    return ({
                        auto c_pg = p0;
                        (crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xxy, prism_rtl::deref(c_pg).ty_p), [=](Text cpp_type_f_26953) { return prism_rtl::finished(crate::emit::cpp::templates::items::cpp_function_f(cpp_doc_f(prism_rtl::cat("A `", prism_rtl::deref(c_pg).tag_name_p, "`\'s answer.")), prism_rtl::cat("Result<", cpp_type_f_26953, "> Answer::", prism_rtl::deref(c_pg).accessor_p, "() const"), prism_rtl::cat("if (auto c = std::get_if<", prism_rtl::deref(c_pg).variant_p, ">(&cases())) return c->a0;\nreturn unexpected(Fault::answer(str(\"an answer for \", tag(), \", where ", prism_rtl::deref(c_pg).tag_name_p, "\'s was expected\")));"))); }));
                    });
                })));
                });
            })));
            })), [=, cls_p6 = std::move(cls_p6), tag_fn_p8 = std::move(tag_fn_p8)](Array<Text> each_26875) {
                return ({
                    auto getters_p9 = each_26875;
                    (crate::prelude::call_value(crate::prelude::each_job(prism_rtl::deref(a_p1x).cases_p, ({
                    auto cp_p0xx = cp_p0x;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::AnswerCase)>>(prism_rtl::rc([=, cp_p0xx = std::move(cp_p0xx)](crate::lower::model::AnswerCase p0) {
                    return ({
                        auto cp_p0xxy = cp_p0xx;
                        (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xxy = std::move(cp_p0xxy)]() {
                        return ({
                            auto c_ph = p0;
                            (crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xxy, prism_rtl::deref(c_ph).ty_p), [=](Text cpp_type_f_27301) { return prism_rtl::finished(prism_rtl::cat("if (is<Elem::", prism_rtl::deref(c_ph).variant_p, ">(e)) return Answer(", prism_rtl::deref(c_ph).variant_p, "{TRY(prism_rtl::from_pod<", cpp_type_f_27301, ">(v))});")); }));
                        });
                    })));
                    });
                })));
                })), [=, getters_p9 = std::move(getters_p9)](Array<Text> each_27199) {
                    return ({
                        auto decodes_pa = crate::syntax::lexer::chars::join_f(each_27199, Text::lit("\n"));
                        auto decode_pb = crate::emit::cpp::templates::items::cpp_function_f(cpp_doc_f(Text::lit("A World\'s answer to the element `e`, decoded by its tag.")), Text::lit("Result<Answer> Answer::decode(const Elem& e, const Pod& v)"), prism_rtl::cat(decodes_pa, "\nprism_rtl::unreachable();"));
                        (prism_rtl::finished(Parts{.forward_p = Array(std::vector{Text::lit("class Answer;")}), .values_p = Array(std::vector{ValueDecl{.path_p = Text::lit("Answer"), .deps_p = Array<Text>{}, .text_p = cls_p6}}), .protos_p = Array<Text>{}, .classes_p = Array<Text>{}, .outer_p = Array<Text>{}, .generic_p = Array<Text>{}, .defs_p = crate::prelude::append(Array(std::vector{tag_fn_p8}), crate::prelude::push(getters_p9, decode_pb))}));
                    });
                }));
                });
            }));
            });
        }));
        });
    });
}


/// `Start AnswerParts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Parts> start_answer_parts_f(crate::emit::cpp::Cp cp_p0, crate::lower::model::AnswerDef a_p1) {
    return prism_rtl::make_rc<AnswerParts>(cp_p0, a_p1);
}


/// JobParts: unbounded fn Cp, JobDef -> Parts
Parts job_parts_f(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::JobDef& j_p1) {
    auto gens_p2 = cpp_template_head_f(generic_names_of_f(j_p1.generics_p));
    auto head_p3 = head_of_f(j_p1.name_p, generic_names_of_f(j_p1.generics_p));
    auto jcp_p4 = crate::emit::cpp::with_fields_f(cp_p0, j_p1.fields_p);
    auto fields_p5 = crate::syntax::lexer::chars::join_f(crate::prelude::run_to_end(crate::prelude::each_job(j_p1.fields_p, ({
        auto cp_p0x = cp_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=, cp_p0x = std::move(cp_p0x)](std::tuple<Text, crate::lower::model::OutTy> p0) {
        return ({
            auto cp_p0xy = cp_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xy = std::move(cp_p0xy)]() {
            return ({
                auto [n_pe, t_pf] = p0;
                (crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xy, t_pf), [=](Text cpp_type_f_28067) { return prism_rtl::finished(prism_rtl::cat(cpp_type_f_28067, " ", crate::emit::cpp::field_id_f(n_pe), ";")); }));
            });
        })));
        });
    })));
    }))), Text::lit("\n"));
    auto params_p6 = crate::syntax::lexer::chars::join_f(crate::prelude::run_to_end(crate::prelude::each_job(j_p1.fields_p, ({
        auto cp_p0x = cp_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=, cp_p0x = std::move(cp_p0x)](std::tuple<Text, crate::lower::model::OutTy> p0) {
        return ({
            auto cp_p0xy = cp_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xy = std::move(cp_p0xy)]() {
            return ({
                auto [n_pg, t_ph] = p0;
                (crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xy, t_ph), [=](Text cpp_type_f_28155) { return prism_rtl::finished(prism_rtl::cat(cpp_type_f_28155, " ", crate::emit::cpp::field_id_f(n_pg))); }));
            });
        })));
        });
    })));
    }))), Text::lit(", "));
    auto inits_p7 = crate::syntax::lexer::chars::join_f(crate::prelude::each(j_p1.fields_p, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
        auto&& n_pi = std::get<0>(_p0);
        return prism_rtl::cat(crate::emit::cpp::field_id_f(n_pi), "(std::move(", crate::emit::cpp::field_id_f(n_pi), "))");
    }), Text::lit(", "));
    auto ctor_p8 = crate::prelude::len(j_p1.fields_p) == Nat(0u)
        ? Text::lit("")
        : prism_rtl::cat(j_p1.name_p, "(", params_p6, ") : ", inits_p7, " {}");
    auto ret_p9 = crate::emit::cpp::cpp_type_f(cp_p0, j_p1.ret_p);
    auto decl_pa = crate::emit::cpp::templates::items::job_struct_f(cpp_doc_f(j_p1.doc_p), gens_p2, j_p1.name_p, ret_p9, fields_p5, ctor_p8);
    auto cycle_pb = crate::emit::cpp::templates::items::cpp_function_f(Text::lit(""), prism_rtl::cat(gens_p2, "prism_rtl::Turn<", ret_p9, "> ", head_p3, "::cycle() const"), crate::emit::cpp::stmts::cpp_body_f(jcp_p4, j_p1.body_p));
    auto start_pc = crate::emit::cpp::templates::items::cpp_function_f(cpp_doc_f(prism_rtl::cat("`Start ", j_p1.name_p, ", x`: what the function value is when passed to `@Run`.")), prism_rtl::cat(gens_p2, "prism_rtl::JobRef<", ret_p9, "> ", j_p1.start_p, "(", params_p6, ")"), prism_rtl::cat("return prism_rtl::make_rc<", head_p3, ">(", crate::syntax::lexer::chars::join_f(crate::prelude::each(j_p1.fields_p, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
        auto&& n_pj = std::get<0>(_p0);
        return crate::emit::cpp::field_id_f(n_pj);
    }), Text::lit(", ")), ");"));
    auto generic_pd = crate::prelude::len(j_p1.generics_p) > Nat(0u);
    return Parts{.forward_p = Array(std::vector{prism_rtl::cat(gens_p2, "struct ", j_p1.name_p, ";")}), .values_p = Array<ValueDecl>{}, .protos_p = Array(std::vector{prism_rtl::cat(gens_p2, "prism_rtl::JobRef<", ret_p9, "> ", j_p1.start_p, "(", params_p6, ");")}), .classes_p = Array(std::vector{decl_pa}), .outer_p = Array<Text>{}, .generic_p = std::move(generic_pd)
        ? Array(std::vector{cycle_pb, start_pc})
        : Array<Text>{}, .defs_p = std::move(generic_pd)
        ? Array<Text>{}
        : Array(std::vector{cycle_pb, start_pc})};
}


prism_rtl::Turn<Parts> JobParts::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& j_p1 = this->j_p1;
    auto gens_p2 = cpp_template_head_f(generic_names_of_f(prism_rtl::deref(j_p1).generics_p));
    auto head_p3 = head_of_f(prism_rtl::deref(j_p1).name_p, generic_names_of_f(prism_rtl::deref(j_p1).generics_p));
    auto jcp_p4 = crate::emit::cpp::with_fields_f(cp_p0, prism_rtl::deref(j_p1).fields_p);
    auto cp_p0x = cp_p0;
    auto j_p1x = j_p1;
    return crate::prelude::call_value(crate::prelude::each_job(prism_rtl::deref(j_p1x).fields_p, ({
        auto cp_p0xx = cp_p0x;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=, cp_p0xx = std::move(cp_p0xx)](std::tuple<Text, crate::lower::model::OutTy> p0) {
        return ({
            auto cp_p0xxy = cp_p0xx;
            (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xxy = std::move(cp_p0xxy)]() {
            return ({
                auto [n_pe, t_pf] = p0;
                (crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xxy, t_pf), [=](Text cpp_type_f_28067) { return prism_rtl::finished(prism_rtl::cat(cpp_type_f_28067, " ", crate::emit::cpp::field_id_f(n_pe), ";")); }));
            });
        })));
        });
    })));
    })), [=](Array<Text> each_28038) {
        return ({
            auto fields_p5 = crate::syntax::lexer::chars::join_f(each_28038, Text::lit("\n"));
            (crate::prelude::call_value(crate::prelude::each_job(prism_rtl::deref(j_p1x).fields_p, ({
            auto cp_p0xx = cp_p0x;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=, cp_p0xx = std::move(cp_p0xx)](std::tuple<Text, crate::lower::model::OutTy> p0) {
            return ({
                auto cp_p0xxy = cp_p0xx;
                (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xxy = std::move(cp_p0xxy)]() {
                return ({
                    auto [n_pg, t_ph] = p0;
                    (crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xxy, t_ph), [=](Text cpp_type_f_28155) { return prism_rtl::finished(prism_rtl::cat(cpp_type_f_28155, " ", crate::emit::cpp::field_id_f(n_pg))); }));
                });
            })));
            });
        })));
        })), [=, fields_p5 = std::move(fields_p5)](Array<Text> each_28126) {
            return ({
                auto params_p6 = crate::syntax::lexer::chars::join_f(each_28126, Text::lit(", "));
                auto inits_p7 = crate::syntax::lexer::chars::join_f(crate::prelude::each(prism_rtl::deref(j_p1x).fields_p, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
                    auto&& n_pi = std::get<0>(_p0);
                    return prism_rtl::cat(crate::emit::cpp::field_id_f(n_pi), "(std::move(", crate::emit::cpp::field_id_f(n_pi), "))");
                }), Text::lit(", "));
                auto ctor_p8 = crate::prelude::len(prism_rtl::deref(j_p1x).fields_p) == Nat(0u)
                    ? Text::lit("")
                    : prism_rtl::cat(prism_rtl::deref(j_p1x).name_p, "(", params_p6, ") : ", inits_p7, " {}");
                (crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0x, prism_rtl::deref(j_p1x).ret_p), [=, params_p6 = std::move(params_p6), ctor_p8 = std::move(ctor_p8)](Text cpp_type_f_28387) {
                return ({
                    auto ret_p9 = cpp_type_f_28387;
                    auto decl_pa = crate::emit::cpp::templates::items::job_struct_f(cpp_doc_f(prism_rtl::deref(j_p1x).doc_p), gens_p2, prism_rtl::deref(j_p1x).name_p, ret_p9, fields_p5, ctor_p8);
                    (crate::prelude::call_then(crate::emit::cpp::stmts::start_cpp_body_f(jcp_p4, prism_rtl::deref(j_p1x).body_p), [=, ret_p9 = std::move(ret_p9), decl_pa = std::move(decl_pa)](Text cpp_body_f_28565) {
                    return ({
                        auto cycle_pb = crate::emit::cpp::templates::items::cpp_function_f(Text::lit(""), prism_rtl::cat(gens_p2, "prism_rtl::Turn<", ret_p9, "> ", head_p3, "::cycle() const"), cpp_body_f_28565);
                        auto start_pc = crate::emit::cpp::templates::items::cpp_function_f(cpp_doc_f(prism_rtl::cat("`Start ", prism_rtl::deref(j_p1x).name_p, ", x`: what the function value is when passed to `@Run`.")), prism_rtl::cat(gens_p2, "prism_rtl::JobRef<", ret_p9, "> ", prism_rtl::deref(j_p1x).start_p, "(", params_p6, ")"), prism_rtl::cat("return prism_rtl::make_rc<", head_p3, ">(", crate::syntax::lexer::chars::join_f(crate::prelude::each(prism_rtl::deref(j_p1x).fields_p, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
                            auto&& n_pj = std::get<0>(_p0);
                            return crate::emit::cpp::field_id_f(n_pj);
                        }), Text::lit(", ")), ");"));
                        auto generic_pd = crate::prelude::len(prism_rtl::deref(j_p1x).generics_p) > Nat(0u);
                        (prism_rtl::finished(Parts{.forward_p = Array(std::vector{prism_rtl::cat(gens_p2, "struct ", prism_rtl::deref(j_p1x).name_p, ";")}), .values_p = Array<ValueDecl>{}, .protos_p = Array(std::vector{prism_rtl::cat(gens_p2, "prism_rtl::JobRef<", ret_p9, "> ", prism_rtl::deref(j_p1x).start_p, "(", params_p6, ");")}), .classes_p = Array(std::vector{decl_pa}), .outer_p = Array<Text>{}, .generic_p = std::move(generic_pd)
                        ? Array(std::vector{cycle_pb, start_pc})
                        : Array<Text>{}, .defs_p = std::move(generic_pd)
                        ? Array<Text>{}
                        : Array(std::vector{cycle_pb, start_pc})}));
                    });
                }));
                });
            }));
            });
        }));
        });
    });
}


/// `Start JobParts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Parts> start_job_parts_f(crate::emit::cpp::Cp cp_p0, crate::lower::model::JobDef j_p1) {
    return prism_rtl::make_rc<JobParts>(cp_p0, j_p1);
}


/// TraitParts: unbounded fn Cp, TraitDef -> Parts
Parts trait_parts_f(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::TraitDef& t_p1) {
    auto defaults_p2 = crate::prelude::filter(t_p1.methods_p, [&](const crate::lower::model::FnDef& f_p6) { return prism_rtl::deref(f_p6).public_p; });
    auto defs_p3 = crate::prelude::run_to_end(crate::prelude::each_job(defaults_p2, ({
        auto cp_p0x = cp_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::FnDef)>>(prism_rtl::rc([=, cp_p0x = std::move(cp_p0x)](crate::lower::model::FnDef p0) {
        return ({
            auto cp_p0xy = cp_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xy = std::move(cp_p0xy)]() {
            return ({
                auto f_p7 = p0;
                (prism_rtl::more(prism_rtl::rc(FnDefinition(cp_p0xy, with_generics_f(f_p7, Array(std::vector{std::tuple{Text::lit("Self"), Array<Text>{}}}))))));
            });
        })));
        });
    })));
    })));
    auto protos_p4 = crate::prelude::run_to_end(crate::prelude::each_job(t_p1.methods_p, ({
        auto cp_p0x = cp_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::FnDef)>>(prism_rtl::rc([=, cp_p0x = std::move(cp_p0x)](crate::lower::model::FnDef p0) {
        return ({
            auto cp_p0xy = cp_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xy = std::move(cp_p0xy)]() {
            return ({
                auto f_p8 = p0;
                (crate::prelude::call_then(start_fn_signature_f(cp_p0xy, with_generics_f(f_p8, Array(std::vector{std::tuple{Text::lit("Self"), Array<Text>{}}}))), [=](Text fn_signature_f_29805) { return prism_rtl::finished(prism_rtl::cat(fn_signature_f_29805, prism_rtl::deref(f_p8).public_p ? Text::lit("") : Text::lit(" = delete"), ";")); }));
            });
        })));
        });
    })));
    })));
    auto generic_p5 = crate::prelude::len(defaults_p2) == Nat(0u)
        ? Array<Text>{}
        : Array(std::vector{crate::emit::cpp::templates::items::trait_namespace_f(t_p1.name_p, crate::syntax::lexer::chars::join_f(defs_p3, Text::lit("\n")))});
    Parts this_ = generic_only_f(generic_p5);
    this_.protos_p = Array(std::vector{crate::emit::cpp::templates::items::trait_namespace_f(t_p1.name_p, crate::syntax::lexer::chars::join_f(protos_p4, Text::lit("\n")))});
    return this_;
}


prism_rtl::Turn<Parts> TraitParts::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& t_p1 = this->t_p1;
    auto defaults_p2 = crate::prelude::filter(prism_rtl::deref(t_p1).methods_p, [&](const crate::lower::model::FnDef& f_p6) { return prism_rtl::deref(f_p6).public_p; });
    auto cp_p0x = cp_p0;
    auto t_p1x = t_p1;
    return crate::prelude::call_value(crate::prelude::each_job(defaults_p2, ({
        auto cp_p0xx = cp_p0x;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::FnDef)>>(prism_rtl::rc([=, cp_p0xx = std::move(cp_p0xx)](crate::lower::model::FnDef p0) {
        return ({
            auto cp_p0xxy = cp_p0xx;
            (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xxy = std::move(cp_p0xxy)]() {
            return ({
                auto f_p7 = p0;
                (prism_rtl::more(prism_rtl::rc(FnDefinition(cp_p0xxy, with_generics_f(f_p7, Array(std::vector{std::tuple{Text::lit("Self"), Array<Text>{}}}))))));
            });
        })));
        });
    })));
    })), [=](Array<Text> each_29689) {
        return ({
            auto defs_p3 = each_29689;
            (crate::prelude::call_value(crate::prelude::each_job(prism_rtl::deref(t_p1x).methods_p, ({
            auto cp_p0xx = cp_p0x;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::FnDef)>>(prism_rtl::rc([=, cp_p0xx = std::move(cp_p0xx)](crate::lower::model::FnDef p0) {
            return ({
                auto cp_p0xxy = cp_p0xx;
                (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xxy = std::move(cp_p0xxy)]() {
                return ({
                    auto f_p8 = p0;
                    (crate::prelude::call_then(start_fn_signature_f(cp_p0xxy, with_generics_f(f_p8, Array(std::vector{std::tuple{Text::lit("Self"), Array<Text>{}}}))), [=](Text fn_signature_f_29805) { return prism_rtl::finished(prism_rtl::cat(fn_signature_f_29805, prism_rtl::deref(f_p8).public_p ? Text::lit("") : Text::lit(" = delete"), ";")); }));
                });
            })));
            });
        })));
        })), [=, defs_p3 = std::move(defs_p3)](Array<Text> each_29782) {
            return ({
                auto protos_p4 = each_29782;
                auto generic_p5 = crate::prelude::len(defaults_p2) == Nat(0u)
                    ? Array<Text>{}
                    : Array(std::vector{crate::emit::cpp::templates::items::trait_namespace_f(prism_rtl::deref(t_p1x).name_p, crate::syntax::lexer::chars::join_f(defs_p3, Text::lit("\n")))});
                (prism_rtl::finished(({
                Parts this_ = generic_only_f(generic_p5);
                this_.protos_p = Array(std::vector{crate::emit::cpp::templates::items::trait_namespace_f(prism_rtl::deref(t_p1x).name_p, crate::syntax::lexer::chars::join_f(protos_p4, Text::lit("\n")))});
                (std::move(this_));
            })));
            });
        }));
        });
    });
}


/// `Start TraitParts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Parts> start_trait_parts_f(crate::emit::cpp::Cp cp_p0, crate::lower::model::TraitDef t_p1) {
    return prism_rtl::make_rc<TraitParts>(cp_p0, t_p1);
}


/// ImplParts: unbounded fn Cp, ImplDef -> Parts
Parts impl_parts_f(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::ImplDef& i_p1) {
    auto head_p2 = crate::emit::cpp::cpp_type_f(cp_p0, i_p1.head_p);
    auto gens_p3 = cpp_template_head_f(generic_names_of_f(i_p1.generics_p));
    auto fns_p4 = crate::prelude::run_to_end(crate::prelude::each_job(i_p1.methods_p, ({
        auto cp_p0x = cp_p0;
        auto i_p1x = i_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Parts>(crate::lower::model::FnDef)>>(prism_rtl::rc([=, cp_p0x = std::move(cp_p0x), i_p1x = std::move(i_p1x)](crate::lower::model::FnDef p0) {
        return ({
            auto cp_p0xy = cp_p0x;
            auto i_p1xy = i_p1x;
            (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xy = std::move(cp_p0xy), i_p1xy = std::move(i_p1xy)]() {
            return ({
                auto f_p6 = p0;
                (prism_rtl::more(prism_rtl::rc(FnParts(cp_p0xy, with_generics_f(f_p6, prism_rtl::deref(i_p1xy).generics_p)))));
            });
        })));
        });
    })));
    })));
    auto own_p5 = crate::prelude::fold(fns_p4, no_parts_p(), [&](const Parts& acc_p7, const Parts& p_p8) { return join_parts_f(acc_p7, p_p8); });
    auto&& _m = i_p1.cls_p;
    {
        auto&& m30792_0 = _m;
        if (m30792_0 == Text::lit("Prelude.Show")) {
            auto shown_p9 = crate::prelude::or_(crate::prelude::index(crate::prelude::each(i_p1.methods_p, [&](const crate::lower::model::FnDef& f_pa) { return prism_rtl::deref(f_pa).name_p; }), Nat(0u)), Text::lit("show"));
            return join_parts_f(own_p5, protos_defs_f(Array<Text>{}, Array(std::vector{crate::emit::cpp::templates::items::cpp_function_f(Text::lit(""), prism_rtl::cat(gens_p3, "void ", head_p2, "::show(Printer& p) const"), prism_rtl::cat("p.raw(", shown_p9, "(*this).to_string());"))})));
        }
    }
    {
        auto&& m30792_1 = _m;
        if (m30792_1 == Text::lit("Prelude.Eq")) {
            auto eq_pb = crate::prelude::fold(i_p1.methods_p, Text::lit(""), [&](const Text& acc_pc, const crate::lower::model::FnDef& f_pd) {
                return (!crate::syntax::lexer::chars::has_prefix_f(prism_rtl::deref(f_pd).name_p, Text::lit("ne"))) && (acc_pc == Text::lit(""))
                    ? prism_rtl::deref(f_pd).name_p
                    : acc_pc;
            });
            return join_parts_f(own_p5, protos_defs_f(Array(std::vector{prism_rtl::cat(gens_p3, "bool operator==(const ", head_p2, "& a, const ", head_p2, "& b);")}), Array(std::vector{crate::emit::cpp::templates::items::cpp_function_f(Text::lit(""), prism_rtl::cat(gens_p3, "bool operator==(const ", head_p2, "& a, const ", head_p2, "& b)"), prism_rtl::cat("return ", eq_pb, "(a, b);"))})));
        }
    }
    {
        auto tr_pe = crate::syntax::lexer::chars::drop_prefix_f(crate::emit::cpp::type_path_f(i_p1.tr_p), Text::lit("crate::"));
        auto own_pf = !crate::syntax::lexer::chars::contains_f(tr_pe, Text::lit("::"));
        auto ns_pg = std::move(own_pf)
            ? tr_pe
            : prism_rtl::cat("impl_", crate::syntax::lexer::chars::join_f(crate::prelude::split_on(tr_pe, Text::lit("::")), Text::lit("_")));
        auto in_trait_ph = crate::prelude::run_to_end(crate::prelude::each_job(i_p1.methods_p, ({
            auto ns_pgx = ns_pg;
            auto cp_p0x = cp_p0;
            auto i_p1x = i_p1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::FnDef)>>(prism_rtl::rc([=, ns_pgx = std::move(ns_pgx), cp_p0x = std::move(cp_p0x), i_p1x = std::move(i_p1x)](crate::lower::model::FnDef p0) {
            return ({
                auto ns_pgxy = ns_pgx;
                auto cp_p0xy = cp_p0x;
                auto i_p1xy = i_p1x;
                (crate::prelude::entered(crate::prelude::once_job([=, ns_pgxy = std::move(ns_pgxy), cp_p0xy = std::move(cp_p0xy), i_p1xy = std::move(i_p1xy)]() {
                return ({
                    auto f_pk = p0;
                    (crate::prelude::call_then(start_fn_definition_f(cp_p0xy, with_generics_f(f_pk, prism_rtl::deref(i_p1xy).generics_p)), [=](Text fn_definition_f_31659) { return prism_rtl::finished(crate::emit::cpp::templates::items::trait_namespace_f(ns_pgxy, fn_definition_f_31659)); }));
                });
            })));
            });
        })));
        })));
        auto protos_pi = crate::prelude::run_to_end(crate::prelude::each_job(i_p1.methods_p, ({
            auto ns_pgx = ns_pg;
            auto cp_p0x = cp_p0;
            auto i_p1x = i_p1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::FnDef)>>(prism_rtl::rc([=, ns_pgx = std::move(ns_pgx), cp_p0x = std::move(cp_p0x), i_p1x = std::move(i_p1x)](crate::lower::model::FnDef p0) {
            return ({
                auto ns_pgxy = ns_pgx;
                auto cp_p0xy = cp_p0x;
                auto i_p1xy = i_p1x;
                (crate::prelude::entered(crate::prelude::once_job([=, ns_pgxy = std::move(ns_pgxy), cp_p0xy = std::move(cp_p0xy), i_p1xy = std::move(i_p1xy)]() {
                return ({
                    auto f_pl = p0;
                    (crate::prelude::call_then(start_fn_signature_f(cp_p0xy, with_generics_f(f_pl, prism_rtl::deref(i_p1xy).generics_p)), [=](Text fn_signature_f_31773) { return prism_rtl::finished(crate::emit::cpp::templates::items::trait_namespace_f(ns_pgxy, prism_rtl::cat(fn_signature_f_31773, ";"))); }));
                });
            })));
            });
        })));
        })));
        auto outer_pj = std::move(own_pf)
            ? Array<Text>{}
            : Array(std::vector{crate::emit::cpp::templates::items::trait_namespace_f(tr_pe, crate::syntax::lexer::chars::join_f(crate::prelude::each(i_p1.methods_p, [&](const crate::lower::model::FnDef& f_pm) { return prism_rtl::cat("using ::crate::", cp_p0.home_p, "::", ns_pg, "::", crate::emit::cpp::cpp_id_f(prism_rtl::deref(f_pm).name_p), ";"); }), Text::lit("\n")))});
        Parts this_ = protos_defs_f(protos_pi, in_trait_ph);
        this_.outer_p = outer_pj;
        return this_;
    }
}


prism_rtl::Turn<Parts> ImplParts::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& i_p1 = this->i_p1;
    auto cp_p0x = cp_p0;
    auto i_p1x = i_p1;
    return crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0x, prism_rtl::deref(i_p1x).head_p), [=](Text cpp_type_f_30574) {
        return ({
            auto head_p2 = cpp_type_f_30574;
            auto gens_p3 = cpp_template_head_f(generic_names_of_f(prism_rtl::deref(i_p1x).generics_p));
            (crate::prelude::call_value(crate::prelude::each_job(prism_rtl::deref(i_p1x).methods_p, ({
            auto cp_p0xx = cp_p0x;
            auto i_p1xx = i_p1x;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Parts>(crate::lower::model::FnDef)>>(prism_rtl::rc([=, cp_p0xx = std::move(cp_p0xx), i_p1xx = std::move(i_p1xx)](crate::lower::model::FnDef p0) {
            return ({
                auto cp_p0xxy = cp_p0xx;
                auto i_p1xxy = i_p1xx;
                (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xxy = std::move(cp_p0xxy), i_p1xxy = std::move(i_p1xxy)]() {
                return ({
                    auto f_p6 = p0;
                    (prism_rtl::more(prism_rtl::rc(FnParts(cp_p0xxy, with_generics_f(f_p6, prism_rtl::deref(i_p1xxy).generics_p)))));
                });
            })));
            });
        })));
        })), [=, head_p2 = std::move(head_p2), gens_p3 = std::move(gens_p3)](Array<Parts> each_30666) {
            return ({
                auto fns_p4 = each_30666;
                auto own_p5 = crate::prelude::fold(fns_p4, no_parts_p(), [&](const Parts& acc_p7, const Parts& p_p8) { return join_parts_f(acc_p7, p_p8); });
                ({
                auto&& _m = prism_rtl::deref(i_p1x).cls_p;
                ({
                auto&& m30792_0 = _m;
                (m30792_0 == Text::lit("Prelude.Show"));
            }) ? ({
                auto&& m30792_0 = _m;
                ({
                auto shown_p9 = crate::prelude::or_(crate::prelude::index(crate::prelude::each(prism_rtl::deref(i_p1x).methods_p, [&](const crate::lower::model::FnDef& f_pa) { return prism_rtl::deref(f_pa).name_p; }), Nat(0u)), Text::lit("show"));
                (prism_rtl::finished(join_parts_f(own_p5, protos_defs_f(Array<Text>{}, Array(std::vector{crate::emit::cpp::templates::items::cpp_function_f(Text::lit(""), prism_rtl::cat(gens_p3, "void ", head_p2, "::show(Printer& p) const"), prism_rtl::cat("p.raw(", shown_p9, "(*this).to_string());"))})))));
            });
            })
                : ({
                auto&& m30792_1 = _m;
                (m30792_1 == Text::lit("Prelude.Eq"));
            }) ? ({
                auto&& m30792_1 = _m;
                ({
                auto eq_pb = crate::prelude::fold(prism_rtl::deref(i_p1x).methods_p, Text::lit(""), [&](const Text& acc_pc, const crate::lower::model::FnDef& f_pd) {
                    return (!crate::syntax::lexer::chars::has_prefix_f(prism_rtl::deref(f_pd).name_p, Text::lit("ne"))) && (acc_pc == Text::lit(""))
                        ? prism_rtl::deref(f_pd).name_p
                        : acc_pc;
                });
                (prism_rtl::finished(join_parts_f(own_p5, protos_defs_f(Array(std::vector{prism_rtl::cat(gens_p3, "bool operator==(const ", head_p2, "& a, const ", head_p2, "& b);")}), Array(std::vector{crate::emit::cpp::templates::items::cpp_function_f(Text::lit(""), prism_rtl::cat(gens_p3, "bool operator==(const ", head_p2, "& a, const ", head_p2, "& b)"), prism_rtl::cat("return ", eq_pb, "(a, b);"))})))));
            });
            })
                : ({
                auto tr_pe = crate::syntax::lexer::chars::drop_prefix_f(crate::emit::cpp::type_path_f(prism_rtl::deref(i_p1x).tr_p), Text::lit("crate::"));
                auto own_pf = !crate::syntax::lexer::chars::contains_f(tr_pe, Text::lit("::"));
                auto ns_pg = std::move(own_pf)
                    ? tr_pe
                    : prism_rtl::cat("impl_", crate::syntax::lexer::chars::join_f(crate::prelude::split_on(tr_pe, Text::lit("::")), Text::lit("_")));
                (crate::prelude::call_value(crate::prelude::each_job(prism_rtl::deref(i_p1x).methods_p, ({
                auto ns_pgx = ns_pg;
                auto cp_p0xx = cp_p0x;
                auto i_p1xx = i_p1x;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::FnDef)>>(prism_rtl::rc([=, ns_pgx = std::move(ns_pgx), cp_p0xx = std::move(cp_p0xx), i_p1xx = std::move(i_p1xx)](crate::lower::model::FnDef p0) {
                return ({
                    auto ns_pgxy = ns_pgx;
                    auto cp_p0xxy = cp_p0xx;
                    auto i_p1xxy = i_p1xx;
                    (crate::prelude::entered(crate::prelude::once_job([=, ns_pgxy = std::move(ns_pgxy), cp_p0xxy = std::move(cp_p0xxy), i_p1xxy = std::move(i_p1xxy)]() {
                    return ({
                        auto f_pk = p0;
                        (crate::prelude::call_then(start_fn_definition_f(cp_p0xxy, with_generics_f(f_pk, prism_rtl::deref(i_p1xxy).generics_p)), [=](Text fn_definition_f_31659) { return prism_rtl::finished(crate::emit::cpp::templates::items::trait_namespace_f(ns_pgxy, fn_definition_f_31659)); }));
                    });
                })));
                });
            })));
            })), [=, tr_pe = std::move(tr_pe), own_pf = std::move(own_pf)](Array<Text> each_31618) {
                return ({
                    auto in_trait_ph = each_31618;
                    (crate::prelude::call_value(crate::prelude::each_job(prism_rtl::deref(i_p1x).methods_p, ({
                    auto ns_pgx = ns_pg;
                    auto cp_p0xx = cp_p0x;
                    auto i_p1xx = i_p1x;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::FnDef)>>(prism_rtl::rc([=, ns_pgx = std::move(ns_pgx), cp_p0xx = std::move(cp_p0xx), i_p1xx = std::move(i_p1xx)](crate::lower::model::FnDef p0) {
                    return ({
                        auto ns_pgxy = ns_pgx;
                        auto cp_p0xxy = cp_p0xx;
                        auto i_p1xxy = i_p1xx;
                        (crate::prelude::entered(crate::prelude::once_job([=, ns_pgxy = std::move(ns_pgxy), cp_p0xxy = std::move(cp_p0xxy), i_p1xxy = std::move(i_p1xxy)]() {
                        return ({
                            auto f_pl = p0;
                            (crate::prelude::call_then(start_fn_signature_f(cp_p0xxy, with_generics_f(f_pl, prism_rtl::deref(i_p1xxy).generics_p)), [=](Text fn_signature_f_31773) { return prism_rtl::finished(crate::emit::cpp::templates::items::trait_namespace_f(ns_pgxy, prism_rtl::cat(fn_signature_f_31773, ";"))); }));
                        });
                    })));
                    });
                })));
                })), [=, in_trait_ph = std::move(in_trait_ph)](Array<Text> each_31731) {
                    return ({
                        auto protos_pi = each_31731;
                        auto outer_pj = own_pf
                            ? Array<Text>{}
                            : Array(std::vector{crate::emit::cpp::templates::items::trait_namespace_f(tr_pe, crate::syntax::lexer::chars::join_f(crate::prelude::each(prism_rtl::deref(i_p1x).methods_p, [&](const crate::lower::model::FnDef& f_pm) { return prism_rtl::cat("using ::crate::", prism_rtl::deref(cp_p0x).home_p, "::", ns_pg, "::", crate::emit::cpp::cpp_id_f(prism_rtl::deref(f_pm).name_p), ";"); }), Text::lit("\n")))});
                        (prism_rtl::finished(({
                        Parts this_ = protos_defs_f(protos_pi, in_trait_ph);
                        this_.outer_p = outer_pj;
                        (std::move(this_));
                    })));
                    });
                }));
                });
            }));
            });
            });
            });
        }));
        });
    });
}


/// `Start ImplParts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Parts> start_impl_parts_f(crate::emit::cpp::Cp cp_p0, crate::lower::model::ImplDef i_p1) {
    return prism_rtl::make_rc<ImplParts>(cp_p0, i_p1);
}


/// WithGenerics: fn FnDef, [((Text, [Text]))] -> FnDef
crate::lower::model::FnDef with_generics_f(const crate::lower::model::FnDef& f_p0, const Array<std::tuple<Text, Array<Text>>>& gs_p1) {
    crate::lower::model::FnDef this_ = f_p0;
    this_.generics_p = crate::prelude::append(gs_p1, this_.generics_p);
    return this_;
}


/// GenericOnly: fn [Text] -> Parts
Parts generic_only_f(const Array<Text>& xs_p0) {
    Parts this_ = no_parts_p();
    this_.generic_p = xs_p0;
    return this_;
}


/// ProtosDefs: fn [Text], [Text] -> Parts
Parts protos_defs_f(const Array<Text>& ps_p0, const Array<Text>& ds_p1) {
    Parts this_ = no_parts_p();
    this_.protos_p = ps_p0;
    this_.defs_p = ds_p1;
    return this_;
}

}  // namespace crate::emit::cpp::items
