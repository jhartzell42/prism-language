// The module `Emit.Cpp.Items`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <emit/cpp/items/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Emit.Cpp.Items`, from `target/bootstrap/cpp-src/prismc/emit/cpp/items.prism`.
namespace crate::emit::cpp::items {

bool Parts::operator==(const Parts& o) const { return forward == o.forward && values == o.values && protos == o.protos && classes == o.classes && outer == o.outer && generic == o.generic && defs == o.defs; }

void Parts::show(Printer& p) const {
    p.record("Parts", {{"forward", forward}, {"values", values}, {"protos", protos}, {"classes", classes}, {"outer", outer}, {"generic", generic}, {"defs", defs}});
}

Pod Parts::to_pod() const {
    return Pod::record("Parts", {{"forward", prism_rtl::to_pod(forward)}, {"values", prism_rtl::to_pod(values)}, {"protos", prism_rtl::to_pod(protos)}, {"classes", prism_rtl::to_pod(classes)}, {"outer", prism_rtl::to_pod(outer)}, {"generic", prism_rtl::to_pod(generic)}, {"defs", prism_rtl::to_pod(defs)}});
}

Result<Parts> Parts::from_pod(const Pod& whole) {
    return Parts{.forward = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "forward")))), .values = TRY(prism_rtl::from_pod<Array<ValueDecl>>(TRY(crate::prelude::field(whole, "values")))), .protos = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "protos")))), .classes = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "classes")))), .outer = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "outer")))), .generic = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "generic")))), .defs = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "defs"))))};
}


void ValueDecl::show(Printer& p) const {
    p.record("ValueDecl", {{"path", path_}, {"deps", deps}, {"text", text}});
}

Pod ValueDecl::to_pod() const {
    return Pod::record("ValueDecl", {{"path", prism_rtl::to_pod(path_)}, {"deps", prism_rtl::to_pod(deps)}, {"text", prism_rtl::to_pod(text)}});
}

Result<ValueDecl> ValueDecl::from_pod(const Pod& whole) {
    return ValueDecl{.path_ = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "path")))), .deps = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "deps")))), .text = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "text"))))};
}


/// CppTemplateHead: fn [Text] -> Text
Text cpp_template_head(const Array<Text>& xs0) {
    {
        auto&& c0_0 = xs0;
        if (c0_0.size() == 0u) {
            return Text::lit("");
        }
    }
    {
        auto&& ps_p0 = xs0;
        return prism_rtl::cat("template <", crate::syntax::lexer::chars::join(each(ps_p0, [&](const Text& p_p1) { return prism_rtl::cat("class ", p_p1); }), Text::lit(", ")), ">\n");
    }
}


/// GenericNamesOf: fn [((Text, [Text]))] -> [Text]
Array<Text> generic_names_of(const Array<std::tuple<Text, Array<Text>>>& gs_p0) {
    return each(gs_p0, [&](const std::tuple<Text, Array<Text>>& _p0) {
        auto&& g_p1 = std::get<0>(_p0);
        return g_p1;
    });
}


/// HeadOf: fn Text, [Text] -> Text
Text head_of(const Text& name_p0, const Array<Text>& xs1) {
    {
        auto&& c0_1 = xs1;
        if (c0_1.size() == 0u) {
            return name_p0;
        }
    }
    {
        auto&& ps_p2 = xs1;
        return prism_rtl::cat(name_p0, "<", crate::syntax::lexer::chars::join(ps_p2, Text::lit(", ")), ">");
    }
}


/// CppParams: unbounded fn Cp, [((Text, OutTy))] -> Text
Text cpp_params(const crate::emit::cpp::Cp& cp_p0, const Array<std::tuple<Text, crate::lower::model::OutTy>>& ps_p1) {
    return crate::syntax::lexer::chars::join(run_to_end(each_job(ps_p1, ({
        auto cp_p0_1 = cp_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=, cp_p0_1 = std::move(cp_p0_1)](std::tuple<Text, crate::lower::model::OutTy> p0) {
        return ({
            auto cp_p0_1_2 = cp_p0_1;
            entered(once_job([=, cp_p0_1_2 = std::move(cp_p0_1_2)]() {
            return ({
                auto [n_p2, t_p3] = p0;
                call_then(crate::emit::cpp::expr::start_param_type(cp_p0_1_2, t_p3), [=](Text param_type_1510) { return prism_rtl::finished(prism_rtl::cat(param_type_1510, " ", crate::emit::cpp::cpp_id(n_p2))); });
            });
        }));
        });
    })));
    }))), Text::lit(", "));
}


prism_rtl::Turn<Text> CppParams::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& ps_p1 = this->ps_p1;
    auto cp_p0_1 = cp_p0;
    auto ps_p1_2 = ps_p1;
    return call_value(each_job(ps_p1_2, ({
        auto cp_p0_1_3 = cp_p0_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=, cp_p0_1_3 = std::move(cp_p0_1_3)](std::tuple<Text, crate::lower::model::OutTy> p0) {
        return ({
            auto cp_p0_1_3_3 = cp_p0_1_3;
            entered(once_job([=, cp_p0_1_3_3 = std::move(cp_p0_1_3_3)]() {
            return ({
                auto [n_p2, t_p3] = p0;
                call_then(crate::emit::cpp::expr::start_param_type(cp_p0_1_3_3, t_p3), [=](Text param_type_1510) { return prism_rtl::finished(prism_rtl::cat(param_type_1510, " ", crate::emit::cpp::cpp_id(n_p2))); });
            });
        }));
        });
    })));
    })), [=](Array<Text> each_1487) { return prism_rtl::finished(crate::syntax::lexer::chars::join(each_1487, Text::lit(", "))); });
}


/// `Start CppParams, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_params(crate::emit::cpp::Cp cp_p0, Array<std::tuple<Text, crate::lower::model::OutTy>> ps_p1) {
    return prism_rtl::make_rc<CppParams>(cp_p0, ps_p1);
}


/// FnSignature: unbounded fn Cp, FnDef -> Text
Text fn_signature(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::FnDef& f_p1) {
    return prism_rtl::cat(cpp_template_head(generic_names_of(f_p1.generics)), crate::emit::cpp::cpp_type(cp_p0, f_p1.ret), " ", crate::emit::cpp::cpp_id(f_p1.name), "(", cpp_params(cp_p0, f_p1.params), ")");
}


prism_rtl::Turn<Text> FnSignature::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& f_p1 = this->f_p1;
    auto cp_p0_1 = cp_p0;
    auto f_p1_2 = f_p1;
    return call_then(crate::emit::cpp::start_cpp_type(cp_p0_1, prism_rtl::deref(f_p1_2).ret), [=](Text cpp_type_1741) { return call_then(start_cpp_params(cp_p0_1, prism_rtl::deref(f_p1_2).params), [=](Text cpp_params_1776) { return prism_rtl::finished(prism_rtl::cat(cpp_template_head(generic_names_of(prism_rtl::deref(f_p1_2).generics)), cpp_type_1741, " ", crate::emit::cpp::cpp_id(prism_rtl::deref(f_p1_2).name), "(", cpp_params_1776, ")")); }); });
}


/// `Start FnSignature, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_fn_signature(crate::emit::cpp::Cp cp_p0, crate::lower::model::FnDef f_p1) {
    return prism_rtl::make_rc<FnSignature>(cp_p0, f_p1);
}


/// FnDefinition: unbounded fn Cp, FnDef -> Text
Text fn_definition(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::FnDef& f_p1) {
    return crate::emit::cpp::templates::items::cpp_function(cpp_doc(f_p1.doc), fn_signature(cp_p0, f_p1), crate::emit::cpp::stmts::cpp_body(with_params(cp_p0, f_p1.params), f_p1.body));
}


prism_rtl::Turn<Text> FnDefinition::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& f_p1 = this->f_p1;
    auto cp_p0_1 = cp_p0;
    auto f_p1_2 = f_p1;
    return call_then(start_fn_signature(cp_p0_1, f_p1_2), [=](Text fn_signature_1901) { return call_then(crate::emit::cpp::stmts::start_cpp_body(with_params(cp_p0_1, prism_rtl::deref(f_p1_2).params), prism_rtl::deref(f_p1_2).body), [=](Text cpp_body_1922) { return prism_rtl::finished(crate::emit::cpp::templates::items::cpp_function(cpp_doc(prism_rtl::deref(f_p1_2).doc), fn_signature_1901, cpp_body_1922)); }); });
}


/// `Start FnDefinition, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_fn_definition(crate::emit::cpp::Cp cp_p0, crate::lower::model::FnDef f_p1) {
    return prism_rtl::make_rc<FnDefinition>(cp_p0, f_p1);
}


/// WithParams: fn Cp, [((Text, OutTy))] -> Cp
crate::emit::cpp::Cp with_params(const crate::emit::cpp::Cp& cp_p0, const Array<std::tuple<Text, crate::lower::model::OutTy>>& ps_p1) {
    return fold(ps_p1, cp_p0, [&](const crate::emit::cpp::Cp& c_p2, const std::tuple<Text, crate::lower::model::OutTy>& _p1) {
        auto&& n_p3 = std::get<0>(_p1);
        auto&& t_p4 = std::get<1>(_p1);
        return ({
            crate::emit::cpp::Cp this_ = c_p2;
            this_.pointers = insert(this_.pointers, n_p3, crate::emit::cpp::expr::is_pointer_ty(c_p2, crate::emit::cpp::expr::unref(t_p4)));
            this_.local_types = insert(this_.local_types, n_p3, t_p4);
            (std::move(this_));
        });
    });
}


/// ValueDeps: unbounded fn Cp, OutTy -> [Text]
Array<Text> value_deps(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::OutTy& t_p1) {
    if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t_p1)) {
        auto&& n_p2 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p1).a0;
        auto&& args_p3 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p1).a1;
        auto own_p4 = ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = crate::emit::cpp::type_of(cp_p0, n_p2);
            if (prism_rtl::is_some(_m)) {
                auto&& info_p5 = prism_rtl::some_of(_m);
                _v.set(((((prism_rtl::deref(info_p5).kind == Text::lit("record")) || (prism_rtl::deref(info_p5).kind == Text::lit("newtype"))) || (prism_rtl::deref(info_p5).kind == Text::lit("unit"))) || (prism_rtl::deref(info_p5).kind == Text::lit("tag"))) || (prism_rtl::deref(info_p5).kind == Text::lit("choice"))
                    ? Array(std::vector{dep_path(cp_p0, n_p2)})
                    : Array<Text>{});
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(Array<Text>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        return append(own_p4, crate::emit::cpp::patterns::concat2(run_to_end(each_job(args_p3, ({
            auto cp_p0_1 = cp_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(crate::lower::model::OutTy)>>(prism_rtl::rc([=, cp_p0_1 = std::move(cp_p0_1)](crate::lower::model::OutTy p0) {
            return ({
                auto cp_p0_1_2 = cp_p0_1;
                entered(once_job([=, cp_p0_1_2 = std::move(cp_p0_1_2)]() {
                return ({
                    auto a_p6 = p0;
                    (prism_rtl::more(prism_rtl::rc(ValueDeps(cp_p0_1_2, a_p6))));
                });
            }));
            });
        })));
        })))));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutOpt>(t_p1)) {
        auto&& i_p7 = prism_rtl::as<crate::lower::model::OutTy::OutOpt>(t_p1).a0;
        return value_deps(cp_p0, prism_rtl::deref(prism_rtl::deref(i_p7)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutRes>(t_p1)) {
        auto&& i_p8 = prism_rtl::as<crate::lower::model::OutTy::OutRes>(t_p1).a0;
        return value_deps(cp_p0, prism_rtl::deref(prism_rtl::deref(i_p8)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutCell>(t_p1)) {
        auto&& i_p9 = prism_rtl::as<crate::lower::model::OutTy::OutCell>(t_p1).a0;
        return value_deps(cp_p0, prism_rtl::deref(prism_rtl::deref(i_p9)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutTuple>(t_p1)) {
        auto&& ts_pa = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(t_p1).a0;
        return crate::emit::cpp::patterns::concat2(run_to_end(each_job(ts_pa, ({
            auto cp_p0_1 = cp_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(crate::lower::model::OutTy)>>(prism_rtl::rc([=, cp_p0_1 = std::move(cp_p0_1)](crate::lower::model::OutTy p0) {
            return ({
                auto cp_p0_1_2 = cp_p0_1;
                entered(once_job([=, cp_p0_1_2 = std::move(cp_p0_1_2)]() {
                return ({
                    auto a_pb = p0;
                    (prism_rtl::more(prism_rtl::rc(ValueDeps(cp_p0_1_2, a_pb))));
                });
            }));
            });
        })));
        }))));
    }
    {
        return Array<Text>{};
    }
}


prism_rtl::Turn<Array<Text>> ValueDeps::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& t_p1 = this->t_p1;
    return ({
        prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t_p1) ? ({
        auto&& n_p2 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p1).a0;
        auto&& args_p3 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p1).a1;
        ({
        auto own_p4 = ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = crate::emit::cpp::type_of(cp_p0, n_p2);
            if (prism_rtl::is_some(_m)) {
                auto&& info_p5 = prism_rtl::some_of(_m);
                _v.set(((((prism_rtl::deref(info_p5).kind == Text::lit("record")) || (prism_rtl::deref(info_p5).kind == Text::lit("newtype"))) || (prism_rtl::deref(info_p5).kind == Text::lit("unit"))) || (prism_rtl::deref(info_p5).kind == Text::lit("tag"))) || (prism_rtl::deref(info_p5).kind == Text::lit("choice"))
                    ? Array(std::vector{dep_path(cp_p0, n_p2)})
                    : Array<Text>{});
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(Array<Text>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto args_p3_1 = args_p3;
        auto cp_p0_2 = cp_p0;
        call_value(each_job(args_p3_1, ({
        auto cp_p0_2_3 = cp_p0_2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(crate::lower::model::OutTy)>>(prism_rtl::rc([=, cp_p0_2_3 = std::move(cp_p0_2_3)](crate::lower::model::OutTy p0) {
        return ({
            auto cp_p0_2_3_3 = cp_p0_2_3;
            entered(once_job([=, cp_p0_2_3_3 = std::move(cp_p0_2_3_3)]() {
            return ({
                auto a_p6 = p0;
                (prism_rtl::more(prism_rtl::rc(ValueDeps(cp_p0_2_3_3, a_p6))));
            });
        }));
        });
    })));
    })), [=, own_p4 = std::move(own_p4)](Array<Array<Text>> each_3884) { return prism_rtl::finished(append(own_p4, crate::emit::cpp::patterns::concat2(each_3884))); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutOpt>(t_p1) ? ({
        auto&& i_p7 = prism_rtl::as<crate::lower::model::OutTy::OutOpt>(t_p1).a0;
        prism_rtl::more(prism_rtl::rc(ValueDeps(cp_p0, prism_rtl::deref(prism_rtl::deref(i_p7)))));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutRes>(t_p1) ? ({
        auto&& i_p8 = prism_rtl::as<crate::lower::model::OutTy::OutRes>(t_p1).a0;
        prism_rtl::more(prism_rtl::rc(ValueDeps(cp_p0, prism_rtl::deref(prism_rtl::deref(i_p8)))));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutCell>(t_p1) ? ({
        auto&& i_p9 = prism_rtl::as<crate::lower::model::OutTy::OutCell>(t_p1).a0;
        prism_rtl::more(prism_rtl::rc(ValueDeps(cp_p0, prism_rtl::deref(prism_rtl::deref(i_p9)))));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutTuple>(t_p1) ? ({
        auto&& ts_pa = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(t_p1).a0;
        ({
        auto cp_p0_1 = cp_p0;
        auto ts_pa_2 = ts_pa;
        call_value(each_job(ts_pa_2, ({
        auto cp_p0_1_3 = cp_p0_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(crate::lower::model::OutTy)>>(prism_rtl::rc([=, cp_p0_1_3 = std::move(cp_p0_1_3)](crate::lower::model::OutTy p0) {
        return ({
            auto cp_p0_1_3_3 = cp_p0_1_3;
            entered(once_job([=, cp_p0_1_3_3 = std::move(cp_p0_1_3_3)]() {
            return ({
                auto a_pb = p0;
                (prism_rtl::more(prism_rtl::rc(ValueDeps(cp_p0_1_3_3, a_pb))));
            });
        }));
        });
    })));
    })), [=](Array<Array<Text>> each_4035) { return prism_rtl::finished(crate::emit::cpp::patterns::concat2(each_4035)); });
    });
    })
        : prism_rtl::finished(Array<Text>{});
    });
}


/// `Start ValueDeps, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_value_deps(crate::emit::cpp::Cp cp_p0, crate::lower::model::OutTy t_p1) {
    return prism_rtl::make_rc<ValueDeps>(cp_p0, t_p1);
}


/// DepPath: fn Cp, Text -> Text
Text dep_path(const crate::emit::cpp::Cp& cp_p0, const Text& n_p1) {
    auto abs_p2 = crate::emit::cpp::absolute(cp_p0, n_p1);
    auto q_p3 = crate::syntax::lexer::chars::drop_prefix(n_p1, Text::lit("crate::"));
    auto&& _m = crate::prelude::get(cp_p0.types, abs_p2);
    if (prism_rtl::is_some(_m)) {
        return abs_p2;
    }
    if (prism_rtl::is_none(_m)) {
        return q_p3;
    }
    prism_rtl::unreachable("no arm matched");
}


/// Behind: unbounded fn Cp, OutTy -> Bool
bool behind(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::OutTy& t_p1) {
    if (prism_rtl::is<crate::lower::model::OutTy::OutRc>(t_p1)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutOpt>(t_p1)) {
        auto&& i_p2 = prism_rtl::as<crate::lower::model::OutTy::OutOpt>(t_p1).a0;
        return behind(cp_p0, prism_rtl::deref(prism_rtl::deref(i_p2)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutRes>(t_p1)) {
        auto&& i_p3 = prism_rtl::as<crate::lower::model::OutTy::OutRes>(t_p1).a0;
        return behind(cp_p0, prism_rtl::deref(prism_rtl::deref(i_p3)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutCell>(t_p1)) {
        auto&& i_p4 = prism_rtl::as<crate::lower::model::OutTy::OutCell>(t_p1).a0;
        return behind(cp_p0, prism_rtl::deref(prism_rtl::deref(i_p4)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutTuple>(t_p1)) {
        auto&& ts_p5 = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(t_p1).a0;
        return run_to_end(fold_job(ts_p5, false, ({
            auto cp_p0_1 = cp_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=, cp_p0_1 = std::move(cp_p0_1)](std::tuple<bool, crate::lower::model::OutTy> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto cp_p0_1_2 = cp_p0_1;
                entered(once_job([=, cp_p0_1_2 = std::move(cp_p0_1_2)]() {
                return ({
                    auto f_p6 = p0;
                    auto x_p7 = p1;
                    (prism_rtl::finished(std::move(f_p6) || behind(cp_p0_1_2, x_p7)));
                });
            }));
            });
        })));
        })));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutArray>(t_p1)) {
        auto&& i_p8 = prism_rtl::as<crate::lower::model::OutTy::OutArray>(t_p1).a0;
        return names_program_type(cp_p0, prism_rtl::deref(prism_rtl::deref(i_p8)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutMap>(t_p1)) {
        auto&& k_p9 = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t_p1).a0;
        auto&& v_pa = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t_p1).a1;
        return names_program_type(cp_p0, prism_rtl::deref(prism_rtl::deref(k_p9))) || names_program_type(cp_p0, prism_rtl::deref(prism_rtl::deref(v_pa)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutFn>(t_p1)) {
        auto&& ps_pb = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t_p1).a0;
        auto&& r_pc = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t_p1).a1;
        return run_to_end(fold_job(ps_pb, names_program_type(cp_p0, prism_rtl::deref(prism_rtl::deref(r_pc))), ({
            auto cp_p0_1 = cp_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=, cp_p0_1 = std::move(cp_p0_1)](std::tuple<bool, crate::lower::model::OutTy> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto cp_p0_1_2 = cp_p0_1;
                entered(once_job([=, cp_p0_1_2 = std::move(cp_p0_1_2)]() {
                return ({
                    auto f_pd = p0;
                    auto x_pe = p1;
                    (prism_rtl::finished(std::move(f_pd) || names_program_type(cp_p0_1_2, x_pe)));
                });
            }));
            });
        })));
        })));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutDyn>(t_p1)) {
        auto&& i_pf = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(t_p1).a0;
        return names_program_type(cp_p0, prism_rtl::deref(prism_rtl::deref(i_pf)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutEvent>(t_p1)) {
        auto&& i_pg = prism_rtl::as<crate::lower::model::OutTy::OutEvent>(t_p1).a0;
        return names_program_type(cp_p0, prism_rtl::deref(prism_rtl::deref(i_pg)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t_p1)) {
        auto&& args_ph = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p1).a1;
        return run_to_end(fold_job(args_ph, false, ({
            auto cp_p0_1 = cp_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=, cp_p0_1 = std::move(cp_p0_1)](std::tuple<bool, crate::lower::model::OutTy> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto cp_p0_1_2 = cp_p0_1;
                entered(once_job([=, cp_p0_1_2 = std::move(cp_p0_1_2)]() {
                return ({
                    auto f_pi = p0;
                    auto x_pj = p1;
                    (prism_rtl::finished(std::move(f_pi) || behind(cp_p0_1_2, x_pj)));
                });
            }));
            });
        })));
        })));
    }
    {
        return false;
    }
}


prism_rtl::Turn<bool> Behind::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& t_p1 = this->t_p1;
    return ({
        prism_rtl::is<crate::lower::model::OutTy::OutRc>(t_p1) ? prism_rtl::finished(true)
        : prism_rtl::is<crate::lower::model::OutTy::OutOpt>(t_p1) ? ({
        auto&& i_p2 = prism_rtl::as<crate::lower::model::OutTy::OutOpt>(t_p1).a0;
        prism_rtl::more(prism_rtl::rc(Behind(cp_p0, prism_rtl::deref(prism_rtl::deref(i_p2)))));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutRes>(t_p1) ? ({
        auto&& i_p3 = prism_rtl::as<crate::lower::model::OutTy::OutRes>(t_p1).a0;
        prism_rtl::more(prism_rtl::rc(Behind(cp_p0, prism_rtl::deref(prism_rtl::deref(i_p3)))));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutCell>(t_p1) ? ({
        auto&& i_p4 = prism_rtl::as<crate::lower::model::OutTy::OutCell>(t_p1).a0;
        prism_rtl::more(prism_rtl::rc(Behind(cp_p0, prism_rtl::deref(prism_rtl::deref(i_p4)))));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutTuple>(t_p1) ? ({
        auto&& ts_p5 = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(t_p1).a0;
        fold_job(ts_p5, false, ({
        auto cp_p0_1 = cp_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=, cp_p0_1 = std::move(cp_p0_1)](std::tuple<bool, crate::lower::model::OutTy> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto cp_p0_1_2 = cp_p0_1;
            entered(once_job([=, cp_p0_1_2 = std::move(cp_p0_1_2)]() {
            return ({
                auto f_p6 = p0;
                auto x_p7 = p1;
                (prism_rtl::finished(std::move(f_p6) || behind(cp_p0_1_2, x_p7)));
            });
        }));
        });
    })));
    }))->cycle();
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutArray>(t_p1) ? ({
        auto&& i_p8 = prism_rtl::as<crate::lower::model::OutTy::OutArray>(t_p1).a0;
        prism_rtl::more(prism_rtl::rc(NamesProgramType(cp_p0, prism_rtl::deref(prism_rtl::deref(i_p8)))));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutMap>(t_p1) ? ({
        auto&& k_p9 = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t_p1).a0;
        auto&& v_pa = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t_p1).a1;
        ({
        auto cp_p0_1 = cp_p0;
        auto k_p9_2 = prism_rtl::deref(prism_rtl::deref(k_p9));
        auto v_pa_3 = prism_rtl::deref(prism_rtl::deref(v_pa));
        call_then(start_names_program_type(cp_p0_1, k_p9_2), [=, v_pa_3 = std::move(v_pa_3)](bool names_program_type_5369) { return prism_rtl::finished(names_program_type_5369 || names_program_type(cp_p0_1, v_pa_3)); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutFn>(t_p1) ? ({
        auto&& ps_pb = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t_p1).a0;
        auto&& r_pc = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t_p1).a1;
        ({
        auto cp_p0_1 = cp_p0;
        auto ps_pb_2 = ps_pb;
        auto r_pc_3 = prism_rtl::deref(prism_rtl::deref(r_pc));
        call_then(start_names_program_type(cp_p0_1, r_pc_3), [=, ps_pb_2 = std::move(ps_pb_2)](bool names_program_type_5446) {
        return fold_job(ps_pb_2, names_program_type_5446, ({
            auto cp_p0_1_4 = cp_p0_1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=, cp_p0_1_4 = std::move(cp_p0_1_4)](std::tuple<bool, crate::lower::model::OutTy> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto cp_p0_1_4_4 = cp_p0_1_4;
                entered(once_job([=, cp_p0_1_4_4 = std::move(cp_p0_1_4_4)]() {
                return ({
                    auto f_pd = p0;
                    auto x_pe = p1;
                    (prism_rtl::finished(std::move(f_pd) || names_program_type(cp_p0_1_4_4, x_pe)));
                });
            }));
            });
        })));
        }))->cycle();
    });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutDyn>(t_p1) ? ({
        auto&& i_pf = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(t_p1).a0;
        prism_rtl::more(prism_rtl::rc(NamesProgramType(cp_p0, prism_rtl::deref(prism_rtl::deref(i_pf)))));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutEvent>(t_p1) ? ({
        auto&& i_pg = prism_rtl::as<crate::lower::model::OutTy::OutEvent>(t_p1).a0;
        prism_rtl::more(prism_rtl::rc(NamesProgramType(cp_p0, prism_rtl::deref(prism_rtl::deref(i_pg)))));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t_p1) ? ({
        auto&& args_ph = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p1).a1;
        fold_job(args_ph, false, ({
        auto cp_p0_1 = cp_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=, cp_p0_1 = std::move(cp_p0_1)](std::tuple<bool, crate::lower::model::OutTy> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto cp_p0_1_2 = cp_p0_1;
            entered(once_job([=, cp_p0_1_2 = std::move(cp_p0_1_2)]() {
            return ({
                auto f_pi = p0;
                auto x_pj = p1;
                (prism_rtl::finished(std::move(f_pi) || behind(cp_p0_1_2, x_pj)));
            });
        }));
        });
    })));
    }))->cycle();
    })
        : prism_rtl::finished(false);
    });
}


/// `Start Behind, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_behind(crate::emit::cpp::Cp cp_p0, crate::lower::model::OutTy t_p1) {
    return prism_rtl::make_rc<Behind>(cp_p0, t_p1);
}


/// NamesProgramType: unbounded fn Cp, OutTy -> Bool
bool names_program_type(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::OutTy& t_p1) {
    if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t_p1)) {
        auto&& n_p2 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p1).a0;
        auto&& args_p3 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p1).a1;
        auto own_p4 = ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            auto&& _m = crate::emit::cpp::type_of(cp_p0, n_p2);
            if (prism_rtl::is_some(_m)) {
                auto&& info_p5 = prism_rtl::some_of(_m);
                _v.set((prism_rtl::deref(info_p5).kind != Text::lit("node")) && (prism_rtl::deref(info_p5).kind != Text::lit("job")));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(false);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        return std::move(own_p4) || run_to_end(fold_job(args_p3, false, ({
            auto cp_p0_1 = cp_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=, cp_p0_1 = std::move(cp_p0_1)](std::tuple<bool, crate::lower::model::OutTy> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto cp_p0_1_2 = cp_p0_1;
                entered(once_job([=, cp_p0_1_2 = std::move(cp_p0_1_2)]() {
                return ({
                    auto f_p6 = p0;
                    auto x_p7 = p1;
                    (prism_rtl::finished(std::move(f_p6) || names_program_type(cp_p0_1_2, x_p7)));
                });
            }));
            });
        })));
        })));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutOpt>(t_p1)) {
        auto&& i_p8 = prism_rtl::as<crate::lower::model::OutTy::OutOpt>(t_p1).a0;
        return names_program_type(cp_p0, prism_rtl::deref(prism_rtl::deref(i_p8)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutRes>(t_p1)) {
        auto&& i_p9 = prism_rtl::as<crate::lower::model::OutTy::OutRes>(t_p1).a0;
        return names_program_type(cp_p0, prism_rtl::deref(prism_rtl::deref(i_p9)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutRc>(t_p1)) {
        auto&& i_pa = prism_rtl::as<crate::lower::model::OutTy::OutRc>(t_p1).a0;
        return names_program_type(cp_p0, prism_rtl::deref(prism_rtl::deref(i_pa)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutCell>(t_p1)) {
        auto&& i_pb = prism_rtl::as<crate::lower::model::OutTy::OutCell>(t_p1).a0;
        return names_program_type(cp_p0, prism_rtl::deref(prism_rtl::deref(i_pb)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutArray>(t_p1)) {
        auto&& i_pc = prism_rtl::as<crate::lower::model::OutTy::OutArray>(t_p1).a0;
        return names_program_type(cp_p0, prism_rtl::deref(prism_rtl::deref(i_pc)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutMap>(t_p1)) {
        auto&& k_pd = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t_p1).a0;
        auto&& v_pe = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t_p1).a1;
        return names_program_type(cp_p0, prism_rtl::deref(prism_rtl::deref(k_pd))) || names_program_type(cp_p0, prism_rtl::deref(prism_rtl::deref(v_pe)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutTuple>(t_p1)) {
        auto&& ts_pf = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(t_p1).a0;
        return run_to_end(fold_job(ts_pf, false, ({
            auto cp_p0_1 = cp_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=, cp_p0_1 = std::move(cp_p0_1)](std::tuple<bool, crate::lower::model::OutTy> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto cp_p0_1_2 = cp_p0_1;
                entered(once_job([=, cp_p0_1_2 = std::move(cp_p0_1_2)]() {
                return ({
                    auto f_pg = p0;
                    auto x_ph = p1;
                    (prism_rtl::finished(std::move(f_pg) || names_program_type(cp_p0_1_2, x_ph)));
                });
            }));
            });
        })));
        })));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutFn>(t_p1)) {
        auto&& ps_pi = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t_p1).a0;
        auto&& r_pj = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t_p1).a1;
        return run_to_end(fold_job(ps_pi, names_program_type(cp_p0, prism_rtl::deref(prism_rtl::deref(r_pj))), ({
            auto cp_p0_1 = cp_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=, cp_p0_1 = std::move(cp_p0_1)](std::tuple<bool, crate::lower::model::OutTy> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto cp_p0_1_2 = cp_p0_1;
                entered(once_job([=, cp_p0_1_2 = std::move(cp_p0_1_2)]() {
                return ({
                    auto f_pk = p0;
                    auto x_pl = p1;
                    (prism_rtl::finished(std::move(f_pk) || names_program_type(cp_p0_1_2, x_pl)));
                });
            }));
            });
        })));
        })));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutDyn>(t_p1)) {
        auto&& i_pm = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(t_p1).a0;
        return names_program_type(cp_p0, prism_rtl::deref(prism_rtl::deref(i_pm)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutEvent>(t_p1)) {
        auto&& i_pn = prism_rtl::as<crate::lower::model::OutTy::OutEvent>(t_p1).a0;
        return names_program_type(cp_p0, prism_rtl::deref(prism_rtl::deref(i_pn)));
    }
    {
        return false;
    }
}


prism_rtl::Turn<bool> NamesProgramType::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& t_p1 = this->t_p1;
    return ({
        prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t_p1) ? ({
        auto&& n_p2 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p1).a0;
        auto&& args_p3 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p1).a1;
        ({
        auto own_p4 = ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            auto&& _m = crate::emit::cpp::type_of(cp_p0, n_p2);
            if (prism_rtl::is_some(_m)) {
                auto&& info_p5 = prism_rtl::some_of(_m);
                _v.set((prism_rtl::deref(info_p5).kind != Text::lit("node")) && (prism_rtl::deref(info_p5).kind != Text::lit("job")));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(false);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        (prism_rtl::finished(std::move(own_p4) || run_to_end(fold_job(args_p3, false, ({
        auto cp_p0_1 = cp_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=, cp_p0_1 = std::move(cp_p0_1)](std::tuple<bool, crate::lower::model::OutTy> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto cp_p0_1_2 = cp_p0_1;
            entered(once_job([=, cp_p0_1_2 = std::move(cp_p0_1_2)]() {
            return ({
                auto f_p6 = p0;
                auto x_p7 = p1;
                (prism_rtl::finished(std::move(f_p6) || names_program_type(cp_p0_1_2, x_p7)));
            });
        }));
        });
    })));
    })))));
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutOpt>(t_p1) ? ({
        auto&& i_p8 = prism_rtl::as<crate::lower::model::OutTy::OutOpt>(t_p1).a0;
        prism_rtl::more(prism_rtl::rc(NamesProgramType(cp_p0, prism_rtl::deref(prism_rtl::deref(i_p8)))));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutRes>(t_p1) ? ({
        auto&& i_p9 = prism_rtl::as<crate::lower::model::OutTy::OutRes>(t_p1).a0;
        prism_rtl::more(prism_rtl::rc(NamesProgramType(cp_p0, prism_rtl::deref(prism_rtl::deref(i_p9)))));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutRc>(t_p1) ? ({
        auto&& i_pa = prism_rtl::as<crate::lower::model::OutTy::OutRc>(t_p1).a0;
        prism_rtl::more(prism_rtl::rc(NamesProgramType(cp_p0, prism_rtl::deref(prism_rtl::deref(i_pa)))));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutCell>(t_p1) ? ({
        auto&& i_pb = prism_rtl::as<crate::lower::model::OutTy::OutCell>(t_p1).a0;
        prism_rtl::more(prism_rtl::rc(NamesProgramType(cp_p0, prism_rtl::deref(prism_rtl::deref(i_pb)))));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutArray>(t_p1) ? ({
        auto&& i_pc = prism_rtl::as<crate::lower::model::OutTy::OutArray>(t_p1).a0;
        prism_rtl::more(prism_rtl::rc(NamesProgramType(cp_p0, prism_rtl::deref(prism_rtl::deref(i_pc)))));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutMap>(t_p1) ? ({
        auto&& k_pd = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t_p1).a0;
        auto&& v_pe = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t_p1).a1;
        ({
        auto cp_p0_1 = cp_p0;
        auto k_pd_2 = prism_rtl::deref(prism_rtl::deref(k_pd));
        auto v_pe_3 = prism_rtl::deref(prism_rtl::deref(v_pe));
        call_then(start_names_program_type(cp_p0_1, k_pd_2), [=, v_pe_3 = std::move(v_pe_3)](bool names_program_type_6249) { return prism_rtl::finished(names_program_type_6249 || names_program_type(cp_p0_1, v_pe_3)); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutTuple>(t_p1) ? ({
        auto&& ts_pf = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(t_p1).a0;
        fold_job(ts_pf, false, ({
        auto cp_p0_1 = cp_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=, cp_p0_1 = std::move(cp_p0_1)](std::tuple<bool, crate::lower::model::OutTy> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto cp_p0_1_2 = cp_p0_1;
            entered(once_job([=, cp_p0_1_2 = std::move(cp_p0_1_2)]() {
            return ({
                auto f_pg = p0;
                auto x_ph = p1;
                (prism_rtl::finished(std::move(f_pg) || names_program_type(cp_p0_1_2, x_ph)));
            });
        }));
        });
    })));
    }))->cycle();
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutFn>(t_p1) ? ({
        auto&& ps_pi = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t_p1).a0;
        auto&& r_pj = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t_p1).a1;
        ({
        auto cp_p0_1 = cp_p0;
        auto ps_pi_2 = ps_pi;
        auto r_pj_3 = prism_rtl::deref(prism_rtl::deref(r_pj));
        call_then(start_names_program_type(cp_p0_1, r_pj_3), [=, ps_pi_2 = std::move(ps_pi_2)](bool names_program_type_6395) {
        return fold_job(ps_pi_2, names_program_type_6395, ({
            auto cp_p0_1_4 = cp_p0_1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=, cp_p0_1_4 = std::move(cp_p0_1_4)](std::tuple<bool, crate::lower::model::OutTy> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto cp_p0_1_4_4 = cp_p0_1_4;
                entered(once_job([=, cp_p0_1_4_4 = std::move(cp_p0_1_4_4)]() {
                return ({
                    auto f_pk = p0;
                    auto x_pl = p1;
                    (prism_rtl::finished(std::move(f_pk) || names_program_type(cp_p0_1_4_4, x_pl)));
                });
            }));
            });
        })));
        }))->cycle();
    });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutDyn>(t_p1) ? ({
        auto&& i_pm = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(t_p1).a0;
        prism_rtl::more(prism_rtl::rc(NamesProgramType(cp_p0, prism_rtl::deref(prism_rtl::deref(i_pm)))));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutEvent>(t_p1) ? ({
        auto&& i_pn = prism_rtl::as<crate::lower::model::OutTy::OutEvent>(t_p1).a0;
        prism_rtl::more(prism_rtl::rc(NamesProgramType(cp_p0, prism_rtl::deref(prism_rtl::deref(i_pn)))));
    })
        : prism_rtl::finished(false);
    });
}


/// `Start NamesProgramType, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_names_program_type(crate::emit::cpp::Cp cp_p0, crate::lower::model::OutTy t_p1) {
    return prism_rtl::make_rc<NamesProgramType>(cp_p0, t_p1);
}


/// let noParts
Parts no_parts() {
    return Parts{.forward = Array<Text>{}, .values = Array<ValueDecl>{}, .protos = Array<Text>{}, .classes = Array<Text>{}, .outer = Array<Text>{}, .generic = Array<Text>{}, .defs = Array<Text>{}};
}


/// JoinParts: fn Parts, Parts -> Parts
Parts join_parts(const Parts& a_p0, const Parts& b_p1) {
    return Parts{.forward = append(a_p0.forward, b_p1.forward), .values = append(a_p0.values, b_p1.values), .protos = append(a_p0.protos, b_p1.protos), .classes = append(a_p0.classes, b_p1.classes), .outer = append(a_p0.outer, b_p1.outer), .generic = append(a_p0.generic, b_p1.generic), .defs = append(a_p0.defs, b_p1.defs)};
}


/// ItemParts: unbounded fn Cp, Item -> Parts
Parts item_parts(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::Item& it_p1) {
    if (prism_rtl::is<crate::lower::model::Item::ItType>(it_p1)) {
        auto&& t_p2 = prism_rtl::as<crate::lower::model::Item::ItType>(it_p1).a0;
        return type_parts(cp_p0, t_p2);
    }
    if (prism_rtl::is<crate::lower::model::Item::ItTag>(it_p1)) {
        auto&& t_p3 = prism_rtl::as<crate::lower::model::Item::ItTag>(it_p1).a0;
        return tag_parts(cp_p0, t_p3);
    }
    if (prism_rtl::is<crate::lower::model::Item::ItRow>(it_p1)) {
        auto&& r_p4 = prism_rtl::as<crate::lower::model::Item::ItRow>(it_p1).a0;
        return row_parts(cp_p0, cp_p0.home, r_p4);
    }
    if (prism_rtl::is<crate::lower::model::Item::ItFn>(it_p1)) {
        auto&& f_p5 = prism_rtl::as<crate::lower::model::Item::ItFn>(it_p1).a0;
        return fn_parts(cp_p0, f_p5);
    }
    if (prism_rtl::is<crate::lower::model::Item::ItJob>(it_p1)) {
        auto&& j_p6 = prism_rtl::as<crate::lower::model::Item::ItJob>(it_p1).a0;
        return job_parts(cp_p0, j_p6);
    }
    if (prism_rtl::is<crate::lower::model::Item::ItNode>(it_p1)) {
        auto&& n_p7 = prism_rtl::as<crate::lower::model::Item::ItNode>(it_p1).a0;
        return crate::emit::cpp::program::node_parts(cp_p0, n_p7);
    }
    if (prism_rtl::is<crate::lower::model::Item::ItTrait>(it_p1)) {
        auto&& t_p8 = prism_rtl::as<crate::lower::model::Item::ItTrait>(it_p1).a0;
        return trait_parts(cp_p0, t_p8);
    }
    if (prism_rtl::is<crate::lower::model::Item::ItImpl>(it_p1)) {
        auto&& i_p9 = prism_rtl::as<crate::lower::model::Item::ItImpl>(it_p1).a0;
        return impl_parts(cp_p0, i_p9);
    }
    if (prism_rtl::is<crate::lower::model::Item::ItNote>(it_p1)) {
        auto&& t_pa = prism_rtl::as<crate::lower::model::Item::ItNote>(it_p1).a0;
        return protos_defs(Array<Text>{}, Array(std::vector{prism_rtl::cat("// ", t_pa)}));
    }
    if (prism_rtl::is<crate::lower::model::Item::ItRefused>(it_p1)) {
        auto&& t_pb = prism_rtl::as<crate::lower::model::Item::ItRefused>(it_p1).a0;
        return protos_defs(Array<Text>{}, Array(std::vector{prism_rtl::cat("compile_error!(\"", crate::lower::expr::lowering_refusal(), crate::lower::expr::escape(t_pb), "\");")}));
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Parts> ItemParts::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& it_p1 = this->it_p1;
    return ({
        prism_rtl::is<crate::lower::model::Item::ItType>(it_p1) ? ({
        auto&& t_p2 = prism_rtl::as<crate::lower::model::Item::ItType>(it_p1).a0;
        prism_rtl::more(prism_rtl::rc(TypeParts(cp_p0, t_p2)));
    })
        : prism_rtl::is<crate::lower::model::Item::ItTag>(it_p1) ? ({
        auto&& t_p3 = prism_rtl::as<crate::lower::model::Item::ItTag>(it_p1).a0;
        prism_rtl::more(prism_rtl::rc(TagParts(cp_p0, t_p3)));
    })
        : prism_rtl::is<crate::lower::model::Item::ItRow>(it_p1) ? ({
        auto&& r_p4 = prism_rtl::as<crate::lower::model::Item::ItRow>(it_p1).a0;
        prism_rtl::more(prism_rtl::rc(RowParts(cp_p0, prism_rtl::deref(cp_p0).home, r_p4)));
    })
        : prism_rtl::is<crate::lower::model::Item::ItFn>(it_p1) ? ({
        auto&& f_p5 = prism_rtl::as<crate::lower::model::Item::ItFn>(it_p1).a0;
        prism_rtl::more(prism_rtl::rc(FnParts(cp_p0, f_p5)));
    })
        : prism_rtl::is<crate::lower::model::Item::ItJob>(it_p1) ? ({
        auto&& j_p6 = prism_rtl::as<crate::lower::model::Item::ItJob>(it_p1).a0;
        prism_rtl::more(prism_rtl::rc(JobParts(cp_p0, j_p6)));
    })
        : prism_rtl::is<crate::lower::model::Item::ItNode>(it_p1) ? ({
        auto&& n_p7 = prism_rtl::as<crate::lower::model::Item::ItNode>(it_p1).a0;
        prism_rtl::more(prism_rtl::rc(crate::emit::cpp::program::NodeParts(cp_p0, n_p7)));
    })
        : prism_rtl::is<crate::lower::model::Item::ItTrait>(it_p1) ? ({
        auto&& t_p8 = prism_rtl::as<crate::lower::model::Item::ItTrait>(it_p1).a0;
        prism_rtl::more(prism_rtl::rc(TraitParts(cp_p0, t_p8)));
    })
        : prism_rtl::is<crate::lower::model::Item::ItImpl>(it_p1) ? ({
        auto&& i_p9 = prism_rtl::as<crate::lower::model::Item::ItImpl>(it_p1).a0;
        prism_rtl::more(prism_rtl::rc(ImplParts(cp_p0, i_p9)));
    })
        : prism_rtl::is<crate::lower::model::Item::ItNote>(it_p1) ? ({
        auto&& t_pa = prism_rtl::as<crate::lower::model::Item::ItNote>(it_p1).a0;
        prism_rtl::finished(protos_defs(Array<Text>{}, Array(std::vector{prism_rtl::cat("// ", t_pa)})));
    })
        : prism_rtl::is<crate::lower::model::Item::ItRefused>(it_p1) ? ({
        auto&& t_pb = prism_rtl::as<crate::lower::model::Item::ItRefused>(it_p1).a0;
        prism_rtl::finished(protos_defs(Array<Text>{}, Array(std::vector{prism_rtl::cat("compile_error!(\"", crate::lower::expr::lowering_refusal(), crate::lower::expr::escape(t_pb), "\");")})));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ItemParts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Parts> start_item_parts(crate::emit::cpp::Cp cp_p0, crate::lower::model::Item it_p1) {
    return prism_rtl::make_rc<ItemParts>(cp_p0, it_p1);
}


/// FnParts: unbounded fn Cp, FnDef -> Parts
Parts fn_parts(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::FnDef& f_p1) {
    return len(f_p1.generics) > Nat(0u)
        ? ({
        Parts this_ = generic_only(Array(std::vector{fn_definition(cp_p0, f_p1)}));
        this_.protos = Array(std::vector{prism_rtl::cat(fn_signature(cp_p0, f_p1), ";")});
        (std::move(this_));
    })
        : protos_defs(Array(std::vector{prism_rtl::cat(fn_signature(cp_p0, f_p1), ";")}), Array(std::vector{fn_definition(cp_p0, f_p1)}));
}


prism_rtl::Turn<Parts> FnParts::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& f_p1 = this->f_p1;
    return len(prism_rtl::deref(f_p1).generics) > Nat(0u)
        ? prism_rtl::finished(({
        Parts this_ = generic_only(Array(std::vector{fn_definition(cp_p0, f_p1)}));
        this_.protos = Array(std::vector{prism_rtl::cat(fn_signature(cp_p0, f_p1), ";")});
        (std::move(this_));
    }))
        : ({
        auto cp_p0_1 = cp_p0;
        auto f_p1_2 = f_p1;
        call_then(start_fn_signature(cp_p0_1, f_p1_2), [=](Text fn_signature_7638) { return call_then(start_fn_definition(cp_p0_1, f_p1_2), [=](Text fn_definition_7665) { return prism_rtl::finished(protos_defs(Array(std::vector{prism_rtl::cat(fn_signature_7638, ";")}), Array(std::vector{fn_definition_7665}))); }); });
    });
}


/// `Start FnParts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Parts> start_fn_parts(crate::emit::cpp::Cp cp_p0, crate::lower::model::FnDef f_p1) {
    return prism_rtl::make_rc<FnParts>(cp_p0, f_p1);
}


/// CppDoc: fn Text -> Text
Text cpp_doc(const Text& text_p0) {
    return text_p0 == Text::lit("")
        ? Text::lit("")
        : concat(each(split_on(text_p0, Text::lit("\n")), [&](const Text& l_p1) {
        return l_p1 == Text::lit("")
            ? Text::lit("///\n")
            : prism_rtl::cat("/// ", l_p1, "\n");
    }));
}


/// CppSourceDoc: fn Text, Text -> Text
Text cpp_source_doc(const Text& lead_p0, const Text& source_p1) {
    auto quoted_p2 = concat(each(split_on(source_p1, Text::lit("\n")), [&](const Text& l_p3) {
        return l_p3 == Text::lit("")
            ? Text::lit("///\n")
            : prism_rtl::cat("/// ", l_p3, "\n");
    }));
    return source_p1 == Text::lit("")
        ? cpp_doc(lead_p0)
        : lead_p0 == Text::lit("")
        ? prism_rtl::cat("/// ```prism\n", quoted_p2, "/// ```\n")
        : prism_rtl::cat("/// ", lead_p0, "\n///\n/// ```prism\n", quoted_p2, "/// ```\n");
}


/// TypeParts: unbounded fn Cp, TyDef -> Parts
Parts type_parts(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::TyDef& t_p1) {
    auto eq_p2 = t_p1.eq;
    auto ord_p3 = t_p1.ord;
    auto gens_p4 = cpp_template_head(t_p1.params);
    auto head_p5 = head_of(t_p1.name, t_p1.params);
    auto doc_p6 = cpp_source_doc(prism_rtl::cat("`", t_p1.prism, "`:"), t_p1.doc);
    auto members_p7 = members(t_p1.show_ != crate::lower::model::Shown(crate::lower::model::Shown::NotShown{}), t_p1.pod, head_p5);
    auto generic_p8 = len(t_p1.params) > Nat(0u);
    auto fwd_p9 = prism_rtl::cat(gens_p4, t_p1.shape == crate::lower::model::TyShape(crate::lower::model::TyShape::ShapeChoice{})
        ? Text::lit("class")
        : Text::lit("struct"), " ", t_p1.name, ";");
    auto deps_pa = crate::emit::cpp::patterns::concat2(run_to_end(each_job(t_p1.cases_, ({
        auto cp_p0_1 = cp_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(crate::lower::model::CaseDef)>>(prism_rtl::rc([=, cp_p0_1 = std::move(cp_p0_1)](crate::lower::model::CaseDef p0) {
        return ({
            auto cp_p0_1_2 = cp_p0_1;
            entered(once_job([=, cp_p0_1_2 = std::move(cp_p0_1_2)]() {
            return ({
                auto c_pc = p0;
                call_value(each_job(prism_rtl::deref(c_pc).fields, ({
                auto cp_p0_1_2_2 = cp_p0_1_2;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=, cp_p0_1_2_2 = std::move(cp_p0_1_2_2)](std::tuple<Text, crate::lower::model::OutTy> p0) {
                return ({
                    auto cp_p0_1_2_2_2 = cp_p0_1_2_2;
                    entered(once_job([=, cp_p0_1_2_2_2 = std::move(cp_p0_1_2_2_2)]() {
                    return ({
                        auto&& _ft_pd = p0;
                        auto&& ft_pd = std::get<1>(_ft_pd);
                        (prism_rtl::more(prism_rtl::rc(ValueDeps(cp_p0_1_2_2_2, ft_pd))));
                    });
                }));
                });
            })));
            })), [=](Array<Array<Text>> each_9019) { return prism_rtl::finished(crate::emit::cpp::patterns::concat2(each_9019)); });
            });
        }));
        });
    })));
    }))));
    auto [text_p17, cmp_defs_p18] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Text, Array<Text>>> _v;
        auto&& _m = t_p1.shape;
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeChoice>(_m)) {
            _v.set(({
                auto names_pe = each(t_p1.cases_, [&](const crate::lower::model::CaseDef& c_pj) { return prism_rtl::deref(c_pj).name; });
                auto cases_pf = crate::syntax::lexer::chars::join(run_to_end(each_job(t_p1.cases_, ({
                    auto cp_p0_1 = cp_p0;
                    auto eq_p2_2 = std::move(eq_p2);
                    auto ord_p3_3 = std::move(ord_p3);
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::CaseDef)>>(prism_rtl::rc([=, cp_p0_1 = std::move(cp_p0_1), eq_p2_2 = std::move(eq_p2_2), ord_p3_3 = std::move(ord_p3_3)](crate::lower::model::CaseDef p0) {
                    return ({
                        auto cp_p0_1_4 = cp_p0_1;
                        auto eq_p2_2_4 = eq_p2_2;
                        auto ord_p3_3_4 = ord_p3_3;
                        entered(once_job([=, cp_p0_1_4 = std::move(cp_p0_1_4), eq_p2_2_4 = std::move(eq_p2_2_4), ord_p3_3_4 = std::move(ord_p3_3_4)]() {
                        return ({
                            auto c_pk = p0;
                            (prism_rtl::more(prism_rtl::rc(CaseStruct(cp_p0_1_4, c_pk, eq_p2_2_4, ord_p3_3_4))));
                        });
                    }));
                    });
                })));
                }))), Text::lit("\n"));
                auto cls_pg = crate::emit::cpp::templates::items::choice_class(doc_p6, gens_p4, t_p1.name, cases_pf, crate::syntax::lexer::chars::join(names_pe, Text::lit(", ")), members_p7);
                auto cmp_ph = crate::syntax::lexer::chars::join(filter(Array(std::vector{std::move(eq_p2)
                    ? prism_rtl::cat(gens_p4, "inline bool operator==(const ", head_p5, "& a, const ", head_p5, "& b) { return a.cases() == b.cases(); }")
                    : Text::lit(""), std::move(ord_p3)
                    ? prism_rtl::cat(gens_p4, "inline std::strong_ordering operator<=>(const ", head_p5, "& a, const ", head_p5, "& b) { return a.cases() <=> b.cases(); }")
                    : Text::lit("")}), [&](const Text& s_pl) { return s_pl != Text::lit(""); }), Text::lit("\n"));
                auto case_defs_pi = filter(run_to_end(each_job(t_p1.cases_, ({
                    auto cp_p0_1 = cp_p0;
                    auto gens_p4_2 = gens_p4;
                    auto head_p5_3 = head_p5;
                    auto eq_p2_4 = std::move(eq_p2);
                    auto ord_p3_5 = std::move(ord_p3);
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::CaseDef)>>(prism_rtl::rc([=, cp_p0_1 = std::move(cp_p0_1), gens_p4_2 = std::move(gens_p4_2), head_p5_3 = std::move(head_p5_3), eq_p2_4 = std::move(eq_p2_4), ord_p3_5 = std::move(ord_p3_5)](crate::lower::model::CaseDef p0) {
                    return ({
                        auto cp_p0_1_6 = cp_p0_1;
                        auto gens_p4_2_6 = gens_p4_2;
                        auto head_p5_3_6 = head_p5_3;
                        auto eq_p2_4_6 = eq_p2_4;
                        auto ord_p3_5_6 = ord_p3_5;
                        entered(once_job([=, cp_p0_1_6 = std::move(cp_p0_1_6), gens_p4_2_6 = std::move(gens_p4_2_6), head_p5_3_6 = std::move(head_p5_3_6), eq_p2_4_6 = std::move(eq_p2_4_6), ord_p3_5_6 = std::move(ord_p3_5_6)]() {
                        return ({
                            auto c_pm = p0;
                            (prism_rtl::more(prism_rtl::rc(CaseCmpDefs(cp_p0_1_6, gens_p4_2_6, head_p5_3_6, c_pm, eq_p2_4_6, ord_p3_5_6))));
                        });
                    }));
                    });
                })));
                }))), [&](const Text& s_pn) { return s_pn != Text::lit(""); });
                std::tuple{crate::syntax::lexer::chars::join(filter(Array(std::vector{cls_pg, cmp_ph}), [&](const Text& s_po) { return s_po != Text::lit(""); }), Text::lit("\n")), case_defs_pi};
            }));
            goto _done;
        }
        {
            _v.set(({
                auto first_pp = or_(index(t_p1.cases_, Nat(0u)), crate::lower::model::CaseDef{.name = Text::lit(""), .prism = Text::lit(""), .fields = Array<std::tuple<Text, crate::lower::model::OutTy>>{}});
                auto fields_pq = ({
                    __label__ _done;
                    prism_rtl::Slot<Text> _v;
                    auto&& _m = t_p1.shape;
                    if (prism_rtl::is<crate::lower::model::TyShape::ShapeRecord>(_m)) {
                        _v.set(crate::syntax::lexer::chars::join(run_to_end(each_job(prism_rtl::deref(first_pp).fields, ({
                            auto cp_p0_1 = cp_p0;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=, cp_p0_1 = std::move(cp_p0_1)](std::tuple<Text, crate::lower::model::OutTy> p0) {
                            return ({
                                auto cp_p0_1_2 = cp_p0_1;
                                entered(once_job([=, cp_p0_1_2 = std::move(cp_p0_1_2)]() {
                                return ({
                                    auto [f_pu, ft_pv] = p0;
                                    call_then(crate::emit::cpp::start_cpp_type(cp_p0_1_2, ft_pv), [=](Text cpp_type_10229) { return prism_rtl::finished(prism_rtl::cat(cpp_type_10229, " ", crate::emit::cpp::field_id(f_pu), ";")); });
                                });
                            }));
                            });
                        })));
                        }))), Text::lit("\n")));
                        goto _done;
                    }
                    if (prism_rtl::is<crate::lower::model::TyShape::ShapeNewtype>(_m)) {
                        _v.set(positional_fields(cp_p0, prism_rtl::deref(first_pp).fields));
                        goto _done;
                    }
                    {
                        _v.set(Text::lit(""));
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                auto names_pr = ({
                    __label__ _done;
                    prism_rtl::Slot<Array<Text>> _v;
                    auto&& _m = t_p1.shape;
                    if (prism_rtl::is<crate::lower::model::TyShape::ShapeRecord>(_m)) {
                        _v.set(each(prism_rtl::deref(first_pp).fields, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
                            auto&& f_p10 = std::get<0>(_p0);
                            return crate::emit::cpp::field_id(f_p10);
                        }));
                        goto _done;
                    }
                    if (prism_rtl::is<crate::lower::model::TyShape::ShapeNewtype>(_m)) {
                        _v.set(each(crate::check::errors::range0(len(prism_rtl::deref(first_pp).fields)), [&](const Nat& i_p11) { return prism_rtl::cat("a", i_p11); }));
                        goto _done;
                    }
                    {
                        _v.set(Array<Text>{});
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                auto behind_ps = run_to_end(fold_job(prism_rtl::deref(first_pp).fields, false, ({
                    auto cp_p0_1 = cp_p0;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, crate::lower::model::OutTy>>)>>(prism_rtl::rc([=, cp_p0_1 = std::move(cp_p0_1)](std::tuple<bool, std::tuple<Text, crate::lower::model::OutTy>> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto cp_p0_1_2 = cp_p0_1;
                        entered(once_job([=, cp_p0_1_2 = std::move(cp_p0_1_2)]() {
                        return ({
                            auto f_p12 = p0;
                            auto&& _ft_p13 = p1;
                            auto&& ft_p13 = std::get<1>(_ft_p13);
                            (prism_rtl::finished(std::move(f_p12) || behind(cp_p0_1_2, ft_p13)));
                        });
                    }));
                    });
                })));
                })));
                auto [cmps_p14, cmp_defs_p15] = comparisons(gens_p4, head_p5, t_p1.name, names_pr, eq_p2, ord_p3, behind_ps);
                auto decl_pt = crate::emit::cpp::templates::items::value_struct(doc_p6, gens_p4, t_p1.name, fields_pq, crate::syntax::lexer::chars::join(filter(Array(std::vector{cmps_p14, members_p7}), [&](const Text& s_p16) { return s_p16 != Text::lit(""); }), Text::lit("\n")));
                std::tuple{decl_pt, cmp_defs_p15 == Text::lit("")
                ? Array<Text>{}
                : Array(std::vector{cmp_defs_p15})};
            }));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto defs_pb = append(cmp_defs_p18, Array(std::vector{type_defs(cp_p0, t_p1, head_p5)}));
    return Parts{.forward = Array(std::vector{fwd_p9}), .values = Array(std::vector{ValueDecl{.path_ = decl_path(cp_p0, t_p1.name), .deps = deps_pa, .text = text_p17}}), .protos = Array<Text>{}, .classes = Array<Text>{}, .outer = Array<Text>{}, .generic = std::move(generic_p8) ? defs_pb : Array<Text>{}, .defs = std::move(generic_p8) ? Array<Text>{} : defs_pb};
}


prism_rtl::Turn<Parts> TypeParts::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& t_p1 = this->t_p1;
    auto eq_p2 = prism_rtl::deref(t_p1).eq;
    auto ord_p3 = prism_rtl::deref(t_p1).ord;
    auto gens_p4 = cpp_template_head(prism_rtl::deref(t_p1).params);
    auto head_p5 = head_of(prism_rtl::deref(t_p1).name, prism_rtl::deref(t_p1).params);
    auto doc_p6 = cpp_source_doc(prism_rtl::cat("`", prism_rtl::deref(t_p1).prism, "`:"), prism_rtl::deref(t_p1).doc);
    auto members_p7 = members(prism_rtl::deref(t_p1).show_ != crate::lower::model::Shown(crate::lower::model::Shown::NotShown{}), prism_rtl::deref(t_p1).pod, head_p5);
    auto generic_p8 = len(prism_rtl::deref(t_p1).params) > Nat(0u);
    auto fwd_p9 = prism_rtl::cat(gens_p4, prism_rtl::deref(t_p1).shape == crate::lower::model::TyShape(crate::lower::model::TyShape::ShapeChoice{})
        ? Text::lit("class")
        : Text::lit("struct"), " ", prism_rtl::deref(t_p1).name, ";");
    auto cp_p0_1 = cp_p0;
    auto t_p1_2 = t_p1;
    return call_value(each_job(prism_rtl::deref(t_p1_2).cases_, ({
        auto cp_p0_1_3 = cp_p0_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(crate::lower::model::CaseDef)>>(prism_rtl::rc([=, cp_p0_1_3 = std::move(cp_p0_1_3)](crate::lower::model::CaseDef p0) {
        return ({
            auto cp_p0_1_3_3 = cp_p0_1_3;
            entered(once_job([=, cp_p0_1_3_3 = std::move(cp_p0_1_3_3)]() {
            return ({
                auto c_pc = p0;
                call_value(each_job(prism_rtl::deref(c_pc).fields, ({
                auto cp_p0_1_3_3_3 = cp_p0_1_3_3;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=, cp_p0_1_3_3_3 = std::move(cp_p0_1_3_3_3)](std::tuple<Text, crate::lower::model::OutTy> p0) {
                return ({
                    auto cp_p0_1_3_3_3_3 = cp_p0_1_3_3_3;
                    entered(once_job([=, cp_p0_1_3_3_3_3 = std::move(cp_p0_1_3_3_3_3)]() {
                    return ({
                        auto&& _ft_pd = p0;
                        auto&& ft_pd = std::get<1>(_ft_pd);
                        (prism_rtl::more(prism_rtl::rc(ValueDeps(cp_p0_1_3_3_3_3, ft_pd))));
                    });
                }));
                });
            })));
            })), [=](Array<Array<Text>> each_9019) { return prism_rtl::finished(crate::emit::cpp::patterns::concat2(each_9019)); });
            });
        }));
        });
    })));
    })), [=](Array<Array<Text>> each_8991) {
        return ({
            auto deps_pa = crate::emit::cpp::patterns::concat2(each_8991);
            auto [text_p17, cmp_defs_p18] = ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<Text, Array<Text>>> _v;
                auto&& _m = prism_rtl::deref(t_p1_2).shape;
                if (prism_rtl::is<crate::lower::model::TyShape::ShapeChoice>(_m)) {
                    _v.set(({
                        auto names_pe = each(prism_rtl::deref(t_p1_2).cases_, [&](const crate::lower::model::CaseDef& c_pj) { return prism_rtl::deref(c_pj).name; });
                        auto cases_pf = crate::syntax::lexer::chars::join(run_to_end(each_job(prism_rtl::deref(t_p1_2).cases_, ({
                            auto cp_p0_1_3 = cp_p0_1;
                            auto eq_p2_3 = eq_p2;
                            auto ord_p3_4 = ord_p3;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::CaseDef)>>(prism_rtl::rc([=, cp_p0_1_3 = std::move(cp_p0_1_3), eq_p2_3 = std::move(eq_p2_3), ord_p3_4 = std::move(ord_p3_4)](crate::lower::model::CaseDef p0) {
                            return ({
                                auto cp_p0_1_3_5 = cp_p0_1_3;
                                auto eq_p2_3_5 = eq_p2_3;
                                auto ord_p3_4_5 = ord_p3_4;
                                entered(once_job([=, cp_p0_1_3_5 = std::move(cp_p0_1_3_5), eq_p2_3_5 = std::move(eq_p2_3_5), ord_p3_4_5 = std::move(ord_p3_4_5)]() {
                                return ({
                                    auto c_pk = p0;
                                    (prism_rtl::more(prism_rtl::rc(CaseStruct(cp_p0_1_3_5, c_pk, eq_p2_3_5, ord_p3_4_5))));
                                });
                            }));
                            });
                        })));
                        }))), Text::lit("\n"));
                        auto cls_pg = crate::emit::cpp::templates::items::choice_class(doc_p6, gens_p4, prism_rtl::deref(t_p1_2).name, cases_pf, crate::syntax::lexer::chars::join(names_pe, Text::lit(", ")), members_p7);
                        auto cmp_ph = crate::syntax::lexer::chars::join(filter(Array(std::vector{eq_p2
                            ? prism_rtl::cat(gens_p4, "inline bool operator==(const ", head_p5, "& a, const ", head_p5, "& b) { return a.cases() == b.cases(); }")
                            : Text::lit(""), ord_p3
                            ? prism_rtl::cat(gens_p4, "inline std::strong_ordering operator<=>(const ", head_p5, "& a, const ", head_p5, "& b) { return a.cases() <=> b.cases(); }")
                            : Text::lit("")}), [&](const Text& s_pl) { return s_pl != Text::lit(""); }), Text::lit("\n"));
                        auto case_defs_pi = filter(run_to_end(each_job(prism_rtl::deref(t_p1_2).cases_, ({
                            auto cp_p0_1_3 = cp_p0_1;
                            auto gens_p4_3 = gens_p4;
                            auto head_p5_4 = head_p5;
                            auto eq_p2_5 = eq_p2;
                            auto ord_p3_6 = ord_p3;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::CaseDef)>>(prism_rtl::rc([=, cp_p0_1_3 = std::move(cp_p0_1_3), gens_p4_3 = std::move(gens_p4_3), head_p5_4 = std::move(head_p5_4), eq_p2_5 = std::move(eq_p2_5), ord_p3_6 = std::move(ord_p3_6)](crate::lower::model::CaseDef p0) {
                            return ({
                                auto cp_p0_1_3_7 = cp_p0_1_3;
                                auto gens_p4_3_7 = gens_p4_3;
                                auto head_p5_4_7 = head_p5_4;
                                auto eq_p2_5_7 = eq_p2_5;
                                auto ord_p3_6_7 = ord_p3_6;
                                entered(once_job([=, cp_p0_1_3_7 = std::move(cp_p0_1_3_7), gens_p4_3_7 = std::move(gens_p4_3_7), head_p5_4_7 = std::move(head_p5_4_7), eq_p2_5_7 = std::move(eq_p2_5_7), ord_p3_6_7 = std::move(ord_p3_6_7)]() {
                                return ({
                                    auto c_pm = p0;
                                    (prism_rtl::more(prism_rtl::rc(CaseCmpDefs(cp_p0_1_3_7, gens_p4_3_7, head_p5_4_7, c_pm, eq_p2_5_7, ord_p3_6_7))));
                                });
                            }));
                            });
                        })));
                        }))), [&](const Text& s_pn) { return s_pn != Text::lit(""); });
                        std::tuple{crate::syntax::lexer::chars::join(filter(Array(std::vector{cls_pg, cmp_ph}), [&](const Text& s_po) { return s_po != Text::lit(""); }), Text::lit("\n")), case_defs_pi};
                    }));
                    goto _done;
                }
                {
                    _v.set(({
                        auto first_pp = or_(index(prism_rtl::deref(t_p1_2).cases_, Nat(0u)), crate::lower::model::CaseDef{.name = Text::lit(""), .prism = Text::lit(""), .fields = Array<std::tuple<Text, crate::lower::model::OutTy>>{}});
                        auto fields_pq = ({
                            __label__ _done;
                            prism_rtl::Slot<Text> _v;
                            auto&& _m = prism_rtl::deref(t_p1_2).shape;
                            if (prism_rtl::is<crate::lower::model::TyShape::ShapeRecord>(_m)) {
                                _v.set(crate::syntax::lexer::chars::join(run_to_end(each_job(prism_rtl::deref(first_pp).fields, ({
                                    auto cp_p0_1_3 = cp_p0_1;
                                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=, cp_p0_1_3 = std::move(cp_p0_1_3)](std::tuple<Text, crate::lower::model::OutTy> p0) {
                                    return ({
                                        auto cp_p0_1_3_3 = cp_p0_1_3;
                                        entered(once_job([=, cp_p0_1_3_3 = std::move(cp_p0_1_3_3)]() {
                                        return ({
                                            auto [f_pu, ft_pv] = p0;
                                            call_then(crate::emit::cpp::start_cpp_type(cp_p0_1_3_3, ft_pv), [=](Text cpp_type_10229) { return prism_rtl::finished(prism_rtl::cat(cpp_type_10229, " ", crate::emit::cpp::field_id(f_pu), ";")); });
                                        });
                                    }));
                                    });
                                })));
                                }))), Text::lit("\n")));
                                goto _done;
                            }
                            if (prism_rtl::is<crate::lower::model::TyShape::ShapeNewtype>(_m)) {
                                _v.set(positional_fields(cp_p0_1, prism_rtl::deref(first_pp).fields));
                                goto _done;
                            }
                            {
                                _v.set(Text::lit(""));
                                goto _done;
                            }
                        _done:
                            _v.take();
                        });
                        auto names_pr = ({
                            __label__ _done;
                            prism_rtl::Slot<Array<Text>> _v;
                            auto&& _m = prism_rtl::deref(t_p1_2).shape;
                            if (prism_rtl::is<crate::lower::model::TyShape::ShapeRecord>(_m)) {
                                _v.set(each(prism_rtl::deref(first_pp).fields, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
                                    auto&& f_p10 = std::get<0>(_p0);
                                    return crate::emit::cpp::field_id(f_p10);
                                }));
                                goto _done;
                            }
                            if (prism_rtl::is<crate::lower::model::TyShape::ShapeNewtype>(_m)) {
                                _v.set(each(crate::check::errors::range0(len(prism_rtl::deref(first_pp).fields)), [&](const Nat& i_p11) { return prism_rtl::cat("a", i_p11); }));
                                goto _done;
                            }
                            {
                                _v.set(Array<Text>{});
                                goto _done;
                            }
                        _done:
                            _v.take();
                        });
                        auto behind_ps = run_to_end(fold_job(prism_rtl::deref(first_pp).fields, false, ({
                            auto cp_p0_1_3 = cp_p0_1;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, crate::lower::model::OutTy>>)>>(prism_rtl::rc([=, cp_p0_1_3 = std::move(cp_p0_1_3)](std::tuple<bool, std::tuple<Text, crate::lower::model::OutTy>> _p0) {
                            auto&& p0 = std::get<0>(_p0);
                            auto&& p1 = std::get<1>(_p0);
                            return ({
                                auto cp_p0_1_3_3 = cp_p0_1_3;
                                entered(once_job([=, cp_p0_1_3_3 = std::move(cp_p0_1_3_3)]() {
                                return ({
                                    auto f_p12 = p0;
                                    auto&& _ft_p13 = p1;
                                    auto&& ft_p13 = std::get<1>(_ft_p13);
                                    (prism_rtl::finished(std::move(f_p12) || behind(cp_p0_1_3_3, ft_p13)));
                                });
                            }));
                            });
                        })));
                        })));
                        auto [cmps_p14, cmp_defs_p15] = comparisons(gens_p4, head_p5, prism_rtl::deref(t_p1_2).name, names_pr, eq_p2, ord_p3, behind_ps);
                        auto decl_pt = crate::emit::cpp::templates::items::value_struct(doc_p6, gens_p4, prism_rtl::deref(t_p1_2).name, fields_pq, crate::syntax::lexer::chars::join(filter(Array(std::vector{cmps_p14, members_p7}), [&](const Text& s_p16) { return s_p16 != Text::lit(""); }), Text::lit("\n")));
                        std::tuple{decl_pt, cmp_defs_p15 == Text::lit("")
                        ? Array<Text>{}
                        : Array(std::vector{cmp_defs_p15})};
                    }));
                    goto _done;
                }
            _done:
                _v.take();
            });
            call_then(start_type_defs(cp_p0_1, t_p1_2, head_p5), [=, deps_pa = std::move(deps_pa)](Text type_defs_10979) {
            return ({
                auto defs_pb = append(cmp_defs_p18, Array(std::vector{type_defs_10979}));
                (prism_rtl::finished(Parts{.forward = Array(std::vector{fwd_p9}), .values = Array(std::vector{ValueDecl{.path_ = decl_path(cp_p0_1, prism_rtl::deref(t_p1_2).name), .deps = deps_pa, .text = text_p17}}), .protos = Array<Text>{}, .classes = Array<Text>{}, .outer = Array<Text>{}, .generic = generic_p8 ? defs_pb : Array<Text>{}, .defs = generic_p8 ? Array<Text>{} : defs_pb}));
            });
        });
        });
    });
}


/// `Start TypeParts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Parts> start_type_parts(crate::emit::cpp::Cp cp_p0, crate::lower::model::TyDef t_p1) {
    return prism_rtl::make_rc<TypeParts>(cp_p0, t_p1);
}


/// DeclPath: fn Cp, Text -> Text
Text decl_path(const crate::emit::cpp::Cp& cp_p0, const Text& name_p1) {
    return cp_p0.home == Text::lit("")
        ? name_p1
        : prism_rtl::cat(cp_p0.home, "::", name_p1);
}


/// Comparisons: fn Text, Text, Text, [Text], Bool, Bool, Bool -> ((Text, Text))
std::tuple<Text, Text> comparisons(const Text& gens_p0, const Text& owner_p1, const Text& self_p2, const Array<Text>& names_p3, const bool& eq_p4, const bool& ord_p5, const bool& behind_p6) {
    return !behind_p6
        ? std::tuple{crate::syntax::lexer::chars::join(filter(Array(std::vector{eq_p4
        ? prism_rtl::cat("bool operator==(const ", self_p2, "&) const = default;")
        : Text::lit(""), ord_p5
        ? prism_rtl::cat("auto operator<=>(const ", self_p2, "&) const = default;")
        : Text::lit("")}), [&](const Text& s_p7) { return s_p7 != Text::lit(""); }), Text::lit("\n")), Text::lit("")}
        : ({
        auto decls_p8 = crate::syntax::lexer::chars::join(filter(Array(std::vector{eq_p4
            ? prism_rtl::cat("bool operator==(const ", self_p2, "&) const;")
            : Text::lit(""), ord_p5
            ? prism_rtl::cat("std::strong_ordering operator<=>(const ", self_p2, "&) const;")
            : Text::lit("")}), [&](const Text& s_pc) { return s_pc != Text::lit(""); }), Text::lit("\n"));
        auto eq_body_p9 = len(names_p3) == Nat(0u)
            ? Text::lit("true")
            : crate::syntax::lexer::chars::join(each(names_p3, [&](const Text& n_pd) { return prism_rtl::cat(n_pd, " == o.", n_pd); }), Text::lit(" && "));
        auto ord_body_pa = len(names_p3) == Nat(0u)
            ? Text::lit("std::strong_ordering::equal")
            : prism_rtl::cat("std::tie(", crate::syntax::lexer::chars::join(names_p3, Text::lit(", ")), ") <=> std::tie(", crate::syntax::lexer::chars::join(each(names_p3, [&](const Text& n_pe) { return prism_rtl::cat("o.", n_pe); }), Text::lit(", ")), ")");
        auto defs_pb = crate::syntax::lexer::chars::join(filter(Array(std::vector{eq_p4
            ? prism_rtl::cat(gens_p0, "bool ", owner_p1, "::operator==(const ", self_p2, "& o) const { return ", eq_body_p9, "; }")
            : Text::lit(""), ord_p5
            ? prism_rtl::cat(gens_p0, "std::strong_ordering ", owner_p1, "::operator<=>(const ", self_p2, "& o) const { return ", ord_body_pa, "; }")
            : Text::lit("")}), [&](const Text& s_pf) { return s_pf != Text::lit(""); }), Text::lit("\n"));
        std::tuple{decls_p8, defs_pb};
    });
}


/// Members: fn Bool, Bool, Text -> Text
Text members(const bool& shown_p0, const bool& pod_p1, const Text& head_p2) {
    auto s_p3 = shown_p0
        ? Array(std::vector{Text::lit("void show(Printer& p) const;")})
        : Array<Text>{};
    auto d_p4 = pod_p1
        ? Array(std::vector{Text::lit("Pod to_pod() const;"), prism_rtl::cat("static Result<", head_p2, "> from_pod(const Pod& whole);")})
        : Array<Text>{};
    return crate::syntax::lexer::chars::join(append(s_p3, d_p4), Text::lit("\n"));
}


/// CaseStruct: unbounded fn Cp, CaseDef, Bool, Bool -> Text
Text case_struct(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::CaseDef& c_p1, const bool& eq_p2, const bool& ord_p3) {
    auto fields_p4 = positional_fields(cp_p0, c_p1.fields);
    auto&& _cmps_p5 = comparisons(Text::lit(""), Text::lit(""), c_p1.name, case_names(c_p1), eq_p2, ord_p3, case_behind(cp_p0, c_p1));
    auto&& cmps_p5 = std::get<0>(_cmps_p5);
    return crate::emit::cpp::templates::items::case_decl(c_p1.name, crate::syntax::lexer::chars::join(filter(Array(std::vector{fields_p4, cmps_p5}), [&](const Text& s_p6) { return s_p6 != Text::lit(""); }), Text::lit("\n")));
}


prism_rtl::Turn<Text> CaseStruct::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& c_p1 = this->c_p1;
    const auto& eq_p2 = this->eq_p2;
    const auto& ord_p3 = this->ord_p3;
    auto c_p1_1 = c_p1;
    auto cp_p0_2 = cp_p0;
    auto eq_p2_3 = prism_rtl::deref(eq_p2);
    auto ord_p3_4 = prism_rtl::deref(ord_p3);
    return call_then(start_positional_fields(cp_p0_2, prism_rtl::deref(c_p1_1).fields), [=](Text positional_fields_13260) {
        return ({
            auto fields_p4 = positional_fields_13260;
            call_then(start_case_behind(cp_p0_2, c_p1_1), [=, fields_p4 = std::move(fields_p4)](bool case_behind_13370) {
            return ({
                auto&& _cmps_p5 = comparisons(Text::lit(""), Text::lit(""), prism_rtl::deref(c_p1_1).name, case_names(c_p1_1), eq_p2_3, ord_p3_4, case_behind_13370);
                auto&& cmps_p5 = std::get<0>(_cmps_p5);
                (prism_rtl::finished(crate::emit::cpp::templates::items::case_decl(prism_rtl::deref(c_p1_1).name, crate::syntax::lexer::chars::join(filter(Array(std::vector{fields_p4, cmps_p5}), [&](const Text& s_p6) { return s_p6 != Text::lit(""); }), Text::lit("\n")))));
            });
        });
        });
    });
}


/// `Start CaseStruct, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_case_struct(crate::emit::cpp::Cp cp_p0, crate::lower::model::CaseDef c_p1, bool eq_p2, bool ord_p3) {
    return prism_rtl::make_rc<CaseStruct>(cp_p0, c_p1, eq_p2, ord_p3);
}


/// CaseCmpDefs: unbounded fn Cp, Text, Text, CaseDef, Bool, Bool -> Text
Text case_cmp_defs(const crate::emit::cpp::Cp& cp_p0, const Text& gens_p1, const Text& head_p2, const crate::lower::model::CaseDef& c_p3, const bool& eq_p4, const bool& ord_p5) {
    auto&& _defs_p6 = comparisons(gens_p1, prism_rtl::cat(head_p2, "::", c_p3.name), c_p3.name, case_names(c_p3), eq_p4, ord_p5, case_behind(cp_p0, c_p3));
    auto&& defs_p6 = std::get<1>(_defs_p6);
    return defs_p6;
}


prism_rtl::Turn<Text> CaseCmpDefs::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& gens_p1 = this->gens_p1;
    const auto& head_p2 = this->head_p2;
    const auto& c_p3 = this->c_p3;
    const auto& eq_p4 = this->eq_p4;
    const auto& ord_p5 = this->ord_p5;
    auto c_p3_1 = c_p3;
    auto cp_p0_2 = cp_p0;
    auto eq_p4_3 = prism_rtl::deref(eq_p4);
    auto gens_p1_4 = gens_p1;
    auto head_p2_5 = head_p2;
    auto ord_p5_6 = prism_rtl::deref(ord_p5);
    return call_then(start_case_behind(cp_p0_2, c_p3_1), [=](bool case_behind_13763) {
        return ({
            auto&& _defs_p6 = comparisons(gens_p1_4, prism_rtl::cat(head_p2_5, "::", prism_rtl::deref(c_p3_1).name), prism_rtl::deref(c_p3_1).name, case_names(c_p3_1), eq_p4_3, ord_p5_6, case_behind_13763);
            auto&& defs_p6 = std::get<1>(_defs_p6);
            (prism_rtl::finished(defs_p6));
        });
    });
}


/// `Start CaseCmpDefs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_case_cmp_defs(crate::emit::cpp::Cp cp_p0, Text gens_p1, Text head_p2, crate::lower::model::CaseDef c_p3, bool eq_p4, bool ord_p5) {
    return prism_rtl::make_rc<CaseCmpDefs>(cp_p0, gens_p1, head_p2, c_p3, eq_p4, ord_p5);
}


/// CaseNames: fn CaseDef -> [Text]
Array<Text> case_names(const crate::lower::model::CaseDef& c_p0) {
    return each(crate::check::errors::range0(len(c_p0.fields)), [&](const Nat& i_p1) { return prism_rtl::cat("a", i_p1); });
}


/// CaseBehind: unbounded fn Cp, CaseDef -> Bool
bool case_behind(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::CaseDef& c_p1) {
    return run_to_end(fold_job(c_p1.fields, false, ({
        auto cp_p0_1 = cp_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, crate::lower::model::OutTy>>)>>(prism_rtl::rc([=, cp_p0_1 = std::move(cp_p0_1)](std::tuple<bool, std::tuple<Text, crate::lower::model::OutTy>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto cp_p0_1_2 = cp_p0_1;
            entered(once_job([=, cp_p0_1_2 = std::move(cp_p0_1_2)]() {
            return ({
                auto f_p2 = p0;
                auto&& _ft_p3 = p1;
                auto&& ft_p3 = std::get<1>(_ft_p3);
                (prism_rtl::finished(std::move(f_p2) || behind(cp_p0_1_2, ft_p3)));
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<bool> CaseBehind::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& c_p1 = this->c_p1;
    return fold_job(prism_rtl::deref(c_p1).fields, false, ({
        auto cp_p0_1 = cp_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, crate::lower::model::OutTy>>)>>(prism_rtl::rc([=, cp_p0_1 = std::move(cp_p0_1)](std::tuple<bool, std::tuple<Text, crate::lower::model::OutTy>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto cp_p0_1_2 = cp_p0_1;
            entered(once_job([=, cp_p0_1_2 = std::move(cp_p0_1_2)]() {
            return ({
                auto f_p2 = p0;
                auto&& _ft_p3 = p1;
                auto&& ft_p3 = std::get<1>(_ft_p3);
                (prism_rtl::finished(std::move(f_p2) || behind(cp_p0_1_2, ft_p3)));
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start CaseBehind, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_case_behind(crate::emit::cpp::Cp cp_p0, crate::lower::model::CaseDef c_p1) {
    return prism_rtl::make_rc<CaseBehind>(cp_p0, c_p1);
}


/// TypeDefs: unbounded fn Cp, TyDef, Text -> Text
Text type_defs(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::TyDef& t_p1, const Text& head_p2) {
    auto gens_p3 = cpp_template_head(t_p1.params);
    auto show_p4 = t_p1.show_ == crate::lower::model::Shown(crate::lower::model::Shown::ShownDerived{})
        ? Array(std::vector{show_def(cp_p0, t_p1, head_p2, gens_p3)})
        : Array<Text>{};
    auto pod_p5 = t_p1.pod
        ? Array(std::vector{to_pod_def(cp_p0, t_p1, head_p2, gens_p3), from_pod_def(cp_p0, t_p1, head_p2, gens_p3)})
        : Array<Text>{};
    return crate::syntax::lexer::chars::join(append(show_p4, pod_p5), Text::lit("\n"));
}


prism_rtl::Turn<Text> TypeDefs::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& t_p1 = this->t_p1;
    const auto& head_p2 = this->head_p2;
    auto gens_p3 = cpp_template_head(prism_rtl::deref(t_p1).params);
    auto show_p4 = prism_rtl::deref(t_p1).show_ == crate::lower::model::Shown(crate::lower::model::Shown::ShownDerived{})
        ? Array(std::vector{show_def(cp_p0, t_p1, head_p2, gens_p3)})
        : Array<Text>{};
    auto pod_p5 = prism_rtl::deref(t_p1).pod
        ? Array(std::vector{to_pod_def(cp_p0, t_p1, head_p2, gens_p3), from_pod_def(cp_p0, t_p1, head_p2, gens_p3)})
        : Array<Text>{};
    return prism_rtl::finished(crate::syntax::lexer::chars::join(append(show_p4, pod_p5), Text::lit("\n")));
}


/// `Start TypeDefs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_type_defs(crate::emit::cpp::Cp cp_p0, crate::lower::model::TyDef t_p1, Text head_p2) {
    return prism_rtl::make_rc<TypeDefs>(cp_p0, t_p1, head_p2);
}


/// ShowDef: unbounded fn Cp, TyDef, Text, Text -> Text
Text show_def(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::TyDef& t_p1, const Text& head_p2, const Text& gens_p3) {
    auto body_p4 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = t_p1.shape;
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeRecord>(_m)) {
            _v.set(({
                auto c_p5 = or_(index(t_p1.cases_, Nat(0u)), crate::lower::model::CaseDef{.name = Text::lit(""), .prism = Text::lit(""), .fields = Array<std::tuple<Text, crate::lower::model::OutTy>>{}});
                (prism_rtl::cat("p.record(\"", t_p1.prism, "\", {", crate::syntax::lexer::chars::join(each(prism_rtl::deref(c_p5).fields, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
                auto&& f_p6 = std::get<0>(_p0);
                return prism_rtl::cat("{\"", prism_field(f_p6), "\", ", crate::emit::cpp::field_id(f_p6), "}");
            }), Text::lit(", ")), "});"));
            }));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeChoice>(_m)) {
            _v.set(crate::syntax::lexer::chars::join(each(crate::check::errors::range0(len(t_p1.cases_)), [&](const Nat& i_p7) { return show_case(t_p1, i_p7); }), Text::lit("\n")));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeNewtype>(_m)) {
            _v.set(prism_rtl::cat("p.choice(\"", first_case(t_p1), "\", {", crate::syntax::lexer::chars::join(each(crate::check::errors::range0(first_arity(t_p1)), [&](const Nat& k_p8) { return prism_rtl::cat("a", k_p8); }), Text::lit(", ")), "});"));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeUnit>(_m)) {
            _v.set(prism_rtl::cat("p.choice(\"", first_case(t_p1), "\", {});"));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat(gens_p3, "void ", head_p2, "::show(Printer& p) const"), body_p4);
}


prism_rtl::Turn<Text> ShowDef::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& t_p1 = this->t_p1;
    const auto& head_p2 = this->head_p2;
    const auto& gens_p3 = this->gens_p3;
    auto body_p4 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = prism_rtl::deref(t_p1).shape;
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeRecord>(_m)) {
            _v.set(({
                auto c_p5 = or_(index(prism_rtl::deref(t_p1).cases_, Nat(0u)), crate::lower::model::CaseDef{.name = Text::lit(""), .prism = Text::lit(""), .fields = Array<std::tuple<Text, crate::lower::model::OutTy>>{}});
                (prism_rtl::cat("p.record(\"", prism_rtl::deref(t_p1).prism, "\", {", crate::syntax::lexer::chars::join(each(prism_rtl::deref(c_p5).fields, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
                auto&& f_p6 = std::get<0>(_p0);
                return prism_rtl::cat("{\"", prism_field(f_p6), "\", ", crate::emit::cpp::field_id(f_p6), "}");
            }), Text::lit(", ")), "});"));
            }));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeChoice>(_m)) {
            _v.set(crate::syntax::lexer::chars::join(each(crate::check::errors::range0(len(prism_rtl::deref(t_p1).cases_)), [&](const Nat& i_p7) { return show_case(t_p1, i_p7); }), Text::lit("\n")));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeNewtype>(_m)) {
            _v.set(prism_rtl::cat("p.choice(\"", first_case(t_p1), "\", {", crate::syntax::lexer::chars::join(each(crate::check::errors::range0(first_arity(t_p1)), [&](const Nat& k_p8) { return prism_rtl::cat("a", k_p8); }), Text::lit(", ")), "});"));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeUnit>(_m)) {
            _v.set(prism_rtl::cat("p.choice(\"", first_case(t_p1), "\", {});"));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return prism_rtl::finished(crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat(gens_p3, "void ", head_p2, "::show(Printer& p) const"), body_p4));
}


/// `Start ShowDef, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_show_def(crate::emit::cpp::Cp cp_p0, crate::lower::model::TyDef t_p1, Text head_p2, Text gens_p3) {
    return prism_rtl::make_rc<ShowDef>(cp_p0, t_p1, head_p2, gens_p3);
}


/// ShowCase: fn TyDef, Nat -> Text
Text show_case(const crate::lower::model::TyDef& t_p0, const Nat& i_p1) {
    auto c_p2 = or_(index(t_p0.cases_, i_p1), crate::lower::model::CaseDef{.name = Text::lit(""), .prism = Text::lit(""), .fields = Array<std::tuple<Text, crate::lower::model::OutTy>>{}});
    auto head_p3 = prism_rtl::cat(i_p1 == Nat(0u) ? Text::lit("if") : Text::lit("else if"), " (auto c = std::get_if<", prism_rtl::deref(c_p2).name, ">(&cases()))");
    return prism_rtl::cat(head_p3, " p.choice(\"", prism_rtl::deref(c_p2).prism, "\", {", crate::syntax::lexer::chars::join(each(crate::check::errors::range0(len(prism_rtl::deref(c_p2).fields)), [&](const Nat& k_p4) { return prism_rtl::cat("c->a", k_p4); }), Text::lit(", ")), "});");
}


/// FirstCase: fn TyDef -> Text
Text first_case(const crate::lower::model::TyDef& t_p0) {
    return prism_rtl::deref(or_(index(t_p0.cases_, Nat(0u)), crate::lower::model::CaseDef{.name = Text::lit(""), .prism = t_p0.prism, .fields = Array<std::tuple<Text, crate::lower::model::OutTy>>{}})).prism;
}


/// FirstArity: fn TyDef -> Nat
Nat first_arity(const crate::lower::model::TyDef& t_p0) {
    return len(prism_rtl::deref(or_(index(t_p0.cases_, Nat(0u)), crate::lower::model::CaseDef{.name = Text::lit(""), .prism = Text::lit(""), .fields = Array<std::tuple<Text, crate::lower::model::OutTy>>{}})).fields);
}


/// FieldTypes: fn [((Text, OutTy))] -> [OutTy]
Array<crate::lower::model::OutTy> field_types(const Array<std::tuple<Text, crate::lower::model::OutTy>>& fs_p0) {
    return each(fs_p0, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
        auto&& t_p1 = std::get<1>(_p0);
        return t_p1;
    });
}


/// PositionalFields: unbounded fn Cp, [((Text, OutTy))] -> Text
Text positional_fields(const crate::emit::cpp::Cp& cp_p0, const Array<std::tuple<Text, crate::lower::model::OutTy>>& fs_p1) {
    auto tys_p2 = field_types(fs_p1);
    return crate::syntax::lexer::chars::join(run_to_end(each_job(crate::check::errors::range0(len(tys_p2)), ({
        auto cp_p0_1 = cp_p0;
        auto tys_p2_2 = tys_p2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Nat)>>(prism_rtl::rc([=, cp_p0_1 = std::move(cp_p0_1), tys_p2_2 = std::move(tys_p2_2)](Nat p0) {
        return ({
            auto cp_p0_1_3 = cp_p0_1;
            auto tys_p2_2_3 = tys_p2_2;
            entered(once_job([=, cp_p0_1_3 = std::move(cp_p0_1_3), tys_p2_2_3 = std::move(tys_p2_2_3)]() {
            return ({
                auto i_p3 = p0;
                call_then(crate::emit::cpp::start_cpp_type(cp_p0_1_3, or_(index(tys_p2_2_3, i_p3), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}))), [=](Text cpp_type_15954) { return prism_rtl::finished(prism_rtl::cat(cpp_type_15954, " a", i_p3, ";")); });
            });
        }));
        });
    })));
    }))), Text::lit("\n"));
}


prism_rtl::Turn<Text> PositionalFields::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& fs_p1 = this->fs_p1;
    auto tys_p2 = field_types(fs_p1);
    auto cp_p0_1 = cp_p0;
    return call_value(each_job(crate::check::errors::range0(len(tys_p2)), ({
        auto cp_p0_1_2 = cp_p0_1;
        auto tys_p2_2 = tys_p2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Nat)>>(prism_rtl::rc([=, cp_p0_1_2 = std::move(cp_p0_1_2), tys_p2_2 = std::move(tys_p2_2)](Nat p0) {
        return ({
            auto cp_p0_1_2_3 = cp_p0_1_2;
            auto tys_p2_2_3 = tys_p2_2;
            entered(once_job([=, cp_p0_1_2_3 = std::move(cp_p0_1_2_3), tys_p2_2_3 = std::move(tys_p2_2_3)]() {
            return ({
                auto i_p3 = p0;
                call_then(crate::emit::cpp::start_cpp_type(cp_p0_1_2_3, or_(index(tys_p2_2_3, i_p3), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}))), [=](Text cpp_type_15954) { return prism_rtl::finished(prism_rtl::cat(cpp_type_15954, " a", i_p3, ";")); });
            });
        }));
        });
    })));
    })), [=](Array<Text> each_15922) { return prism_rtl::finished(crate::syntax::lexer::chars::join(each_15922, Text::lit("\n"))); });
}


/// `Start PositionalFields, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_positional_fields(crate::emit::cpp::Cp cp_p0, Array<std::tuple<Text, crate::lower::model::OutTy>> fs_p1) {
    return prism_rtl::make_rc<PositionalFields>(cp_p0, fs_p1);
}


/// ToPodDef: unbounded fn Cp, TyDef, Text, Text -> Text
Text to_pod_def(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::TyDef& t_p1, const Text& head_p2, const Text& gens_p3) {
    auto structure_p4 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = t_p1.shape;
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeRecord>(_m)) {
            _v.set(({
                auto c_p6 = or_(index(t_p1.cases_, Nat(0u)), crate::lower::model::CaseDef{.name = Text::lit(""), .prism = Text::lit(""), .fields = Array<std::tuple<Text, crate::lower::model::OutTy>>{}});
                (prism_rtl::cat("Pod::record(\"", t_p1.prism, "\", {", crate::syntax::lexer::chars::join(each(prism_rtl::deref(c_p6).fields, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
                auto&& f_p7 = std::get<0>(_p0);
                return prism_rtl::cat("{\"", prism_field(f_p7), "\", prism_rtl::to_pod(", crate::emit::cpp::field_id(f_p7), ")}");
            }), Text::lit(", ")), "})"));
            }));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeChoice>(_m)) {
            _v.set(choice_pod(t_p1));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeNewtype>(_m)) {
            _v.set(prism_rtl::cat("Pod::choice(\"", first_case(t_p1), "\", {", crate::syntax::lexer::chars::join(each(crate::check::errors::range0(first_arity(t_p1)), [&](const Nat& k_p8) { return prism_rtl::cat("prism_rtl::to_pod(a", k_p8, ")"); }), Text::lit(", ")), "})"));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeUnit>(_m)) {
            _v.set(prism_rtl::cat("Pod::choice(\"", first_case(t_p1), "\", {})"));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto body_p5 = t_p1.show_ == crate::lower::model::Shown(crate::lower::model::Shown::ShownOwn{})
        ? prism_rtl::cat("Pod structure = ", structure_p4, ";\nreturn Pod::shown(prism_rtl::show(*this), structure);")
        : prism_rtl::cat("return ", structure_p4, ";");
    return crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat(gens_p3, "Pod ", head_p2, "::to_pod() const"), body_p5);
}


prism_rtl::Turn<Text> ToPodDef::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& t_p1 = this->t_p1;
    const auto& head_p2 = this->head_p2;
    const auto& gens_p3 = this->gens_p3;
    auto structure_p4 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = prism_rtl::deref(t_p1).shape;
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeRecord>(_m)) {
            _v.set(({
                auto c_p6 = or_(index(prism_rtl::deref(t_p1).cases_, Nat(0u)), crate::lower::model::CaseDef{.name = Text::lit(""), .prism = Text::lit(""), .fields = Array<std::tuple<Text, crate::lower::model::OutTy>>{}});
                (prism_rtl::cat("Pod::record(\"", prism_rtl::deref(t_p1).prism, "\", {", crate::syntax::lexer::chars::join(each(prism_rtl::deref(c_p6).fields, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
                auto&& f_p7 = std::get<0>(_p0);
                return prism_rtl::cat("{\"", prism_field(f_p7), "\", prism_rtl::to_pod(", crate::emit::cpp::field_id(f_p7), ")}");
            }), Text::lit(", ")), "})"));
            }));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeChoice>(_m)) {
            _v.set(choice_pod(t_p1));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeNewtype>(_m)) {
            _v.set(prism_rtl::cat("Pod::choice(\"", first_case(t_p1), "\", {", crate::syntax::lexer::chars::join(each(crate::check::errors::range0(first_arity(t_p1)), [&](const Nat& k_p8) { return prism_rtl::cat("prism_rtl::to_pod(a", k_p8, ")"); }), Text::lit(", ")), "})"));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeUnit>(_m)) {
            _v.set(prism_rtl::cat("Pod::choice(\"", first_case(t_p1), "\", {})"));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto body_p5 = prism_rtl::deref(t_p1).show_ == crate::lower::model::Shown(crate::lower::model::Shown::ShownOwn{})
        ? prism_rtl::cat("Pod structure = ", structure_p4, ";\nreturn Pod::shown(prism_rtl::show(*this), structure);")
        : prism_rtl::cat("return ", structure_p4, ";");
    return prism_rtl::finished(crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat(gens_p3, "Pod ", head_p2, "::to_pod() const"), body_p5));
}


/// `Start ToPodDef, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_to_pod_def(crate::emit::cpp::Cp cp_p0, crate::lower::model::TyDef t_p1, Text head_p2, Text gens_p3) {
    return prism_rtl::make_rc<ToPodDef>(cp_p0, t_p1, head_p2, gens_p3);
}


/// ChoicePod: fn TyDef -> Text
Text choice_pod(const crate::lower::model::TyDef& t_p0) {
    auto arms_p1 = each(crate::check::errors::range0(len(t_p0.cases_)), [&](const Nat& i_p2) {
        return ({
            auto c_p3 = or_(index(t_p0.cases_, i_p2), crate::lower::model::CaseDef{.name = Text::lit(""), .prism = Text::lit(""), .fields = Array<std::tuple<Text, crate::lower::model::OutTy>>{}});
            (prism_rtl::cat("std::holds_alternative<", prism_rtl::deref(c_p3).name, ">(cases()) ? Pod::choice(\"", prism_rtl::deref(c_p3).prism, "\", {", crate::syntax::lexer::chars::join(each(crate::check::errors::range0(len(prism_rtl::deref(c_p3).fields)), [&](const Nat& k_p4) { return prism_rtl::cat("prism_rtl::to_pod(std::get<", prism_rtl::deref(c_p3).name, ">(cases()).a", k_p4, ")"); }), Text::lit(", ")), "})"));
        });
    });
    return prism_rtl::cat(crate::syntax::lexer::chars::join(arms_p1, Text::lit("\n    : ")), "\n    : Pod()");
}


/// FromPodDef: unbounded fn Cp, TyDef, Text, Text -> Text
Text from_pod_def(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::TyDef& t_p1, const Text& head_p2, const Text& gens_p3) {
    auto body_p4 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = t_p1.shape;
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeRecord>(_m)) {
            _v.set(({
                auto c_p5 = or_(index(t_p1.cases_, Nat(0u)), crate::lower::model::CaseDef{.name = Text::lit(""), .prism = Text::lit(""), .fields = Array<std::tuple<Text, crate::lower::model::OutTy>>{}});
                auto reads_p6 = crate::syntax::lexer::chars::join(run_to_end(each_job(prism_rtl::deref(c_p5).fields, ({
                    auto cp_p0_1 = cp_p0;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=, cp_p0_1 = std::move(cp_p0_1)](std::tuple<Text, crate::lower::model::OutTy> p0) {
                    return ({
                        auto cp_p0_1_2 = cp_p0_1;
                        entered(once_job([=, cp_p0_1_2 = std::move(cp_p0_1_2)]() {
                        return ({
                            auto [f_p7, ft_p8] = p0;
                            call_then(crate::emit::cpp::start_cpp_type(cp_p0_1_2, ft_p8), [=](Text cpp_type_17526) { return prism_rtl::finished(prism_rtl::cat(".", crate::emit::cpp::field_id(f_p7), " = TRY(prism_rtl::from_pod<", cpp_type_17526, ">(TRY(crate::prelude::field(whole, \"", prism_field(f_p7), "\"))))")); });
                        });
                    }));
                    });
                })));
                }))), Text::lit(", "));
                (prism_rtl::cat("return ", head_p2, "{", reads_p6, "};"));
            }));
            goto _done;
        }
        {
            _v.set(({
                auto arms_p9 = run_to_end(each_job(t_p1.cases_, ({
                    auto cp_p0_1 = cp_p0;
                    auto t_p1_2 = t_p1;
                    auto head_p2_3 = head_p2;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::CaseDef)>>(prism_rtl::rc([=, cp_p0_1 = std::move(cp_p0_1), t_p1_2 = std::move(t_p1_2), head_p2_3 = std::move(head_p2_3)](crate::lower::model::CaseDef p0) {
                    return ({
                        auto cp_p0_1_4 = cp_p0_1;
                        auto t_p1_2_4 = t_p1_2;
                        auto head_p2_3_4 = head_p2_3;
                        entered(once_job([=, cp_p0_1_4 = std::move(cp_p0_1_4), t_p1_2_4 = std::move(t_p1_2_4), head_p2_3_4 = std::move(head_p2_3_4)]() {
                        return ({
                            auto c_pa = p0;
                            ({
                            auto n_pb = len(prism_rtl::deref(c_pa).fields);
                            auto tys_pc = field_types(prism_rtl::deref(c_pa).fields);
                            call_value(each_job(crate::check::errors::range0(n_pb), ({
                            auto cp_p0_1_4_4 = cp_p0_1_4;
                            auto tys_pc_4 = tys_pc;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Nat)>>(prism_rtl::rc([=, cp_p0_1_4_4 = std::move(cp_p0_1_4_4), tys_pc_4 = std::move(tys_pc_4)](Nat p0) {
                            return ({
                                auto cp_p0_1_4_4_5 = cp_p0_1_4_4;
                                auto tys_pc_4_5 = tys_pc_4;
                                entered(once_job([=, cp_p0_1_4_4_5 = std::move(cp_p0_1_4_4_5), tys_pc_4_5 = std::move(tys_pc_4_5)]() {
                                return ({
                                    auto i_pf = p0;
                                    call_then(crate::emit::cpp::start_cpp_type(cp_p0_1_4_4_5, or_(index(tys_pc_4_5, i_pf), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}))), [=](Text cpp_type_17872) { return prism_rtl::finished(prism_rtl::cat("TRY(prism_rtl::from_pod<", cpp_type_17872, ">(c->args[", i_pf, "]))")); });
                                });
                            }));
                            });
                        })));
                        })), [=](Array<Text> each_17824) {
                            return ({
                                auto args_pd = crate::syntax::lexer::chars::join(each_17824, Text::lit(", "));
                                auto made_pe = ({
                                    __label__ _done;
                                    prism_rtl::Slot<Text> _v;
                                    auto&& _m = t_p1_2_4.shape;
                                    if (prism_rtl::is<crate::lower::model::TyShape::ShapeChoice>(_m)) {
                                        _v.set(prism_rtl::cat(head_p2_3_4, "(", prism_rtl::deref(c_pa).name, "{", args_pd, "})"));
                                        goto _done;
                                    }
                                    {
                                        _v.set(prism_rtl::cat(head_p2_3_4, "{", args_pd, "}"));
                                        goto _done;
                                    }
                                _done:
                                    _v.take();
                                });
                                (prism_rtl::finished(prism_rtl::cat("if (c->ctor == \"", prism_rtl::deref(c_pa).prism, "\" && c->args.size() == ", n_pb, ") return ", made_pe, ";")));
                            });
                        });
                        });
                        });
                    }));
                    });
                })));
                })));
                (prism_rtl::cat("const Pod& p = whole.structure();\nif (auto c = p.if_choice()) {\n", indent_cpp(crate::syntax::lexer::chars::join(arms_p9, Text::lit("\n"))), "\n}\nreturn mismatch<", head_p2, ">(\"a ", t_p1.prism, "\", p);"));
            }));
            goto _done;
        }
    _done:
        _v.take();
    });
    return crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat(gens_p3, "Result<", head_p2, "> ", head_p2, "::from_pod(const Pod& whole)"), body_p4);
}


prism_rtl::Turn<Text> FromPodDef::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& t_p1 = this->t_p1;
    const auto& head_p2 = this->head_p2;
    const auto& gens_p3 = this->gens_p3;
    auto body_p4 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = prism_rtl::deref(t_p1).shape;
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeRecord>(_m)) {
            _v.set(({
                auto c_p5 = or_(index(prism_rtl::deref(t_p1).cases_, Nat(0u)), crate::lower::model::CaseDef{.name = Text::lit(""), .prism = Text::lit(""), .fields = Array<std::tuple<Text, crate::lower::model::OutTy>>{}});
                auto reads_p6 = crate::syntax::lexer::chars::join(run_to_end(each_job(prism_rtl::deref(c_p5).fields, ({
                    auto cp_p0_1 = cp_p0;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=, cp_p0_1 = std::move(cp_p0_1)](std::tuple<Text, crate::lower::model::OutTy> p0) {
                    return ({
                        auto cp_p0_1_2 = cp_p0_1;
                        entered(once_job([=, cp_p0_1_2 = std::move(cp_p0_1_2)]() {
                        return ({
                            auto [f_p7, ft_p8] = p0;
                            call_then(crate::emit::cpp::start_cpp_type(cp_p0_1_2, ft_p8), [=](Text cpp_type_17526) { return prism_rtl::finished(prism_rtl::cat(".", crate::emit::cpp::field_id(f_p7), " = TRY(prism_rtl::from_pod<", cpp_type_17526, ">(TRY(crate::prelude::field(whole, \"", prism_field(f_p7), "\"))))")); });
                        });
                    }));
                    });
                })));
                }))), Text::lit(", "));
                (prism_rtl::cat("return ", head_p2, "{", reads_p6, "};"));
            }));
            goto _done;
        }
        {
            _v.set(({
                auto arms_p9 = run_to_end(each_job(prism_rtl::deref(t_p1).cases_, ({
                    auto cp_p0_1 = cp_p0;
                    auto t_p1_2 = t_p1;
                    auto head_p2_3 = head_p2;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::CaseDef)>>(prism_rtl::rc([=, cp_p0_1 = std::move(cp_p0_1), t_p1_2 = std::move(t_p1_2), head_p2_3 = std::move(head_p2_3)](crate::lower::model::CaseDef p0) {
                    return ({
                        auto cp_p0_1_4 = cp_p0_1;
                        auto t_p1_2_4 = t_p1_2;
                        auto head_p2_3_4 = head_p2_3;
                        entered(once_job([=, cp_p0_1_4 = std::move(cp_p0_1_4), t_p1_2_4 = std::move(t_p1_2_4), head_p2_3_4 = std::move(head_p2_3_4)]() {
                        return ({
                            auto c_pa = p0;
                            ({
                            auto n_pb = len(prism_rtl::deref(c_pa).fields);
                            auto tys_pc = field_types(prism_rtl::deref(c_pa).fields);
                            call_value(each_job(crate::check::errors::range0(n_pb), ({
                            auto cp_p0_1_4_4 = cp_p0_1_4;
                            auto tys_pc_4 = tys_pc;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Nat)>>(prism_rtl::rc([=, cp_p0_1_4_4 = std::move(cp_p0_1_4_4), tys_pc_4 = std::move(tys_pc_4)](Nat p0) {
                            return ({
                                auto cp_p0_1_4_4_5 = cp_p0_1_4_4;
                                auto tys_pc_4_5 = tys_pc_4;
                                entered(once_job([=, cp_p0_1_4_4_5 = std::move(cp_p0_1_4_4_5), tys_pc_4_5 = std::move(tys_pc_4_5)]() {
                                return ({
                                    auto i_pf = p0;
                                    call_then(crate::emit::cpp::start_cpp_type(cp_p0_1_4_4_5, or_(index(tys_pc_4_5, i_pf), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}))), [=](Text cpp_type_17872) { return prism_rtl::finished(prism_rtl::cat("TRY(prism_rtl::from_pod<", cpp_type_17872, ">(c->args[", i_pf, "]))")); });
                                });
                            }));
                            });
                        })));
                        })), [=](Array<Text> each_17824) {
                            return ({
                                auto args_pd = crate::syntax::lexer::chars::join(each_17824, Text::lit(", "));
                                auto made_pe = ({
                                    __label__ _done;
                                    prism_rtl::Slot<Text> _v;
                                    auto&& _m = prism_rtl::deref(t_p1_2_4).shape;
                                    if (prism_rtl::is<crate::lower::model::TyShape::ShapeChoice>(_m)) {
                                        _v.set(prism_rtl::cat(head_p2_3_4, "(", prism_rtl::deref(c_pa).name, "{", args_pd, "})"));
                                        goto _done;
                                    }
                                    {
                                        _v.set(prism_rtl::cat(head_p2_3_4, "{", args_pd, "}"));
                                        goto _done;
                                    }
                                _done:
                                    _v.take();
                                });
                                (prism_rtl::finished(prism_rtl::cat("if (c->ctor == \"", prism_rtl::deref(c_pa).prism, "\" && c->args.size() == ", n_pb, ") return ", made_pe, ";")));
                            });
                        });
                        });
                        });
                    }));
                    });
                })));
                })));
                (prism_rtl::cat("const Pod& p = whole.structure();\nif (auto c = p.if_choice()) {\n", indent_cpp(crate::syntax::lexer::chars::join(arms_p9, Text::lit("\n"))), "\n}\nreturn mismatch<", head_p2, ">(\"a ", prism_rtl::deref(t_p1).prism, "\", p);"));
            }));
            goto _done;
        }
    _done:
        _v.take();
    });
    return prism_rtl::finished(crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat(gens_p3, "Result<", head_p2, "> ", head_p2, "::from_pod(const Pod& whole)"), body_p4));
}


/// `Start FromPodDef, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_from_pod_def(crate::emit::cpp::Cp cp_p0, crate::lower::model::TyDef t_p1, Text head_p2, Text gens_p3) {
    return prism_rtl::make_rc<FromPodDef>(cp_p0, t_p1, head_p2, gens_p3);
}


/// PrismField: fn Text -> Text
Text prism_field(const Text& f_p0) {
    return crate::syntax::lexer::chars::last_char(f_p0) == Text::lit("_")
        ? crate::syntax::lexer::chars::before_last(f_p0)
        : f_p0;
}


/// IndentCpp: fn Text -> Text
Text indent_cpp(const Text& t_p0) {
    return crate::syntax::lexer::chars::join(each(split_on(t_p0, Text::lit("\n")), [&](const Text& l_p1) { return l_p1 == Text::lit("") ? Text::lit("") : prism_rtl::cat("    ", l_p1); }), Text::lit("\n"));
}


/// TagParts: unbounded fn Cp, TagDef -> Parts
Parts tag_parts(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::TagDef& t_p1) {
    auto fields_p2 = crate::syntax::lexer::chars::join(run_to_end(each_job(t_p1.fields, ({
        auto cp_p0_1 = cp_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=, cp_p0_1 = std::move(cp_p0_1)](std::tuple<Text, Text, crate::lower::model::OutTy> p0) {
        return ({
            auto cp_p0_1_2 = cp_p0_1;
            entered(once_job([=, cp_p0_1_2 = std::move(cp_p0_1_2)]() {
            return ({
                auto&& _f_ph = p0;
                auto&& f_ph = std::get<1>(_f_ph);
                auto&& ft_pi = std::get<2>(_f_ph);
                call_then(crate::emit::cpp::start_cpp_type(cp_p0_1_2, ft_pi), [=](Text cpp_type_18900) { return prism_rtl::finished(prism_rtl::cat(cpp_type_18900, " ", crate::emit::cpp::field_id(f_ph), ";")); });
            });
        }));
        });
    })));
    }))), Text::lit("\n"));
    auto pods_p3 = crate::syntax::lexer::chars::join(each(t_p1.fields, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
        auto&& p_pj = std::get<0>(_p0);
        auto&& f_pk = std::get<1>(_p0);
        return prism_rtl::cat("{\"", p_pj, "\", prism_rtl::to_pod(", crate::emit::cpp::field_id(f_pk), ")}");
    }), Text::lit(", "));
    auto reads_p4 = crate::syntax::lexer::chars::join(run_to_end(each_job(t_p1.fields, ({
        auto cp_p0_1 = cp_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=, cp_p0_1 = std::move(cp_p0_1)](std::tuple<Text, Text, crate::lower::model::OutTy> p0) {
        return ({
            auto cp_p0_1_2 = cp_p0_1;
            entered(once_job([=, cp_p0_1_2 = std::move(cp_p0_1_2)]() {
            return ({
                auto [p_pl, f_pm, ft_pn] = p0;
                call_then(crate::emit::cpp::start_cpp_type(cp_p0_1_2, ft_pn), [=](Text cpp_type_19140) { return prism_rtl::finished(prism_rtl::cat(".", crate::emit::cpp::field_id(f_pm), " = TRY(prism_rtl::from_pod<", cpp_type_19140, ">(TRY(crate::prelude::field(p, \"", p_pl, "\"))))")); });
            });
        }));
        });
    })));
    }))), Text::lit(", "));
    auto eq_p5 = t_p1.eq
        ? prism_rtl::cat("bool operator==(const ", t_p1.name, "&) const = default;")
        : Text::lit("");
    auto back_p6 = t_p1.pod
        ? prism_rtl::cat("static Result<", t_p1.name, "> from_pod(const Pod& p);")
        : Text::lit("");
    auto deep_p7 = run_to_end(fold_job(t_p1.fields, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, Text, crate::lower::model::OutTy>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<Text, Text, crate::lower::model::OutTy>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto d_po = p0;
                auto&& _ft_pp = p1;
                auto&& ft_pp = std::get<2>(_ft_pp);
                (prism_rtl::finished(std::move(d_po) || crate::lower::types::holds_dyn(ft_pp)));
            });
        }));
    }))));
    auto level_decl_p8 = std::move(deep_p7)
        ? Text::lit("/// The level as a World reads it: each dynamic it holds sampled at the read point.\nPod level_pod(const Cx& cx) const;\n/// The update events of the dynamics it holds, and of theirs.\nvoid level_ports(const Cx& cx, std::vector<prism_rtl::Rc<prism_rtl::Port<Unit>>>& out) const;")
        : Text::lit("");
    auto decl_p9 = crate::emit::cpp::templates::items::cpp_tag_struct(cpp_source_doc(prism_rtl::cat("The `Level` of `", t_p1.tag_name, "`:"), t_p1.doc), t_p1.name, fields_p2, t_p1.tag_name, crate::syntax::lexer::chars::join(filter(Array(std::vector{eq_p5, back_p6, level_decl_p8}), [&](const Text& s_pq) { return s_pq != Text::lit(""); }), Text::lit("\n")));
    auto deep_pods_pa = crate::syntax::lexer::chars::join(run_to_end(each_job(t_p1.fields, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, Text, crate::lower::model::OutTy> p0) {
        return entered(once_job([=]() {
            return ({
                auto [p_pr, f_ps, ft_pt] = p0;
                (prism_rtl::more(prism_rtl::rc(CppDeepField(p_pr, f_ps, ft_pt))));
            });
        }));
    })))), Text::lit(", "));
    auto deep_ports_pb = crate::syntax::lexer::chars::join(filter(run_to_end(each_job(t_p1.fields, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, Text, crate::lower::model::OutTy> p0) {
        return entered(once_job([=]() {
            return ({
                auto&& _f_pu = p0;
                auto&& f_pu = std::get<1>(_f_pu);
                auto&& ft_pv = std::get<2>(_f_pu);
                (prism_rtl::more(prism_rtl::rc(CppDeepPorts(f_pu, ft_pv))));
            });
        }));
    })))), [&](const Text& s_p10) { return s_p10 != Text::lit(""); }), Text::lit("\n"));
    auto level_defs_pc = std::move(deep_p7)
        ? Array(std::vector{crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat("Pod ", t_p1.name, "::level_pod(const Cx& cx) const"), prism_rtl::cat("static_cast<void>(cx);\nreturn Pod::element(TAG, {", deep_pods_pa, "});")), crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat("void ", t_p1.name, "::level_ports(const Cx& cx, std::vector<prism_rtl::Rc<prism_rtl::Port<Unit>>>& out) const"), prism_rtl::cat("static_cast<void>(cx);\nstatic_cast<void>(out);", deep_ports_pb == Text::lit("")
        ? Text::lit("")
        : prism_rtl::cat("\n", deep_ports_pb)))})
        : Array<Text>{};
    auto to_pod_pd = crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat("Pod ", t_p1.name, "::to_pod() const"), prism_rtl::cat("return Pod::element(TAG, {", pods_p3, "});"));
    auto show_pe = crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat("void ", t_p1.name, "::show(Printer& p) const"), Text::lit("prism_rtl::to_pod(*this).structure();\nShow<Pod>::show(prism_rtl::to_pod(*this), p);"));
    auto from_pod_pf = t_p1.pod
        ? Array(std::vector{crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat("Result<", t_p1.name, "> ", t_p1.name, "::from_pod(const Pod& p)"), prism_rtl::cat("if (auto t = p.tag(); t && *t == TAG) return ", t_p1.name, "{", reads_p4, "};\nreturn mismatch<", t_p1.name, ">(\"a ", t_p1.tag_name, "\", p);"))})
        : Array<Text>{};
    auto deps_pg = crate::emit::cpp::patterns::concat2(run_to_end(each_job(t_p1.fields, ({
        auto cp_p0_1 = cp_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Text, Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=, cp_p0_1 = std::move(cp_p0_1)](std::tuple<Text, Text, crate::lower::model::OutTy> p0) {
        return ({
            auto cp_p0_1_2 = cp_p0_1;
            entered(once_job([=, cp_p0_1_2 = std::move(cp_p0_1_2)]() {
            return ({
                auto&& _ft_p11 = p0;
                auto&& ft_p11 = std::get<2>(_ft_p11);
                (prism_rtl::more(prism_rtl::rc(ValueDeps(cp_p0_1_2, ft_p11))));
            });
        }));
        });
    })));
    }))));
    return Parts{.forward = Array(std::vector{prism_rtl::cat("struct ", t_p1.name, ";")}), .values = Array(std::vector{ValueDecl{.path_ = decl_path(cp_p0, t_p1.name), .deps = deps_pg, .text = decl_p9}}), .protos = Array<Text>{}, .classes = Array<Text>{}, .outer = Array<Text>{}, .generic = Array<Text>{}, .defs = append(append(Array(std::vector{to_pod_pd, show_pe}), from_pod_pf), level_defs_pc)};
}


prism_rtl::Turn<Parts> TagParts::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& t_p1 = this->t_p1;
    auto cp_p0_1 = cp_p0;
    auto t_p1_2 = t_p1;
    return call_value(each_job(prism_rtl::deref(t_p1_2).fields, ({
        auto cp_p0_1_3 = cp_p0_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=, cp_p0_1_3 = std::move(cp_p0_1_3)](std::tuple<Text, Text, crate::lower::model::OutTy> p0) {
        return ({
            auto cp_p0_1_3_3 = cp_p0_1_3;
            entered(once_job([=, cp_p0_1_3_3 = std::move(cp_p0_1_3_3)]() {
            return ({
                auto&& _f_ph = p0;
                auto&& f_ph = std::get<1>(_f_ph);
                auto&& ft_pi = std::get<2>(_f_ph);
                call_then(crate::emit::cpp::start_cpp_type(cp_p0_1_3_3, ft_pi), [=](Text cpp_type_18900) { return prism_rtl::finished(prism_rtl::cat(cpp_type_18900, " ", crate::emit::cpp::field_id(f_ph), ";")); });
            });
        }));
        });
    })));
    })), [=](Array<Text> each_18862) {
        return ({
            auto fields_p2 = crate::syntax::lexer::chars::join(each_18862, Text::lit("\n"));
            auto pods_p3 = crate::syntax::lexer::chars::join(each(prism_rtl::deref(t_p1_2).fields, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
                auto&& p_pj = std::get<0>(_p0);
                auto&& f_pk = std::get<1>(_p0);
                return prism_rtl::cat("{\"", p_pj, "\", prism_rtl::to_pod(", crate::emit::cpp::field_id(f_pk), ")}");
            }), Text::lit(", "));
            call_value(each_job(prism_rtl::deref(t_p1_2).fields, ({
            auto cp_p0_1_3 = cp_p0_1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=, cp_p0_1_3 = std::move(cp_p0_1_3)](std::tuple<Text, Text, crate::lower::model::OutTy> p0) {
            return ({
                auto cp_p0_1_3_3 = cp_p0_1_3;
                entered(once_job([=, cp_p0_1_3_3 = std::move(cp_p0_1_3_3)]() {
                return ({
                    auto [p_pl, f_pm, ft_pn] = p0;
                    call_then(crate::emit::cpp::start_cpp_type(cp_p0_1_3_3, ft_pn), [=](Text cpp_type_19140) { return prism_rtl::finished(prism_rtl::cat(".", crate::emit::cpp::field_id(f_pm), " = TRY(prism_rtl::from_pod<", cpp_type_19140, ">(TRY(crate::prelude::field(p, \"", p_pl, "\"))))")); });
                });
            }));
            });
        })));
        })), [=, fields_p2 = std::move(fields_p2), pods_p3 = std::move(pods_p3)](Array<Text> each_19068) {
            return ({
                auto reads_p4 = crate::syntax::lexer::chars::join(each_19068, Text::lit(", "));
                auto eq_p5 = prism_rtl::deref(t_p1_2).eq
                    ? prism_rtl::cat("bool operator==(const ", prism_rtl::deref(t_p1_2).name, "&) const = default;")
                    : Text::lit("");
                auto back_p6 = prism_rtl::deref(t_p1_2).pod
                    ? prism_rtl::cat("static Result<", prism_rtl::deref(t_p1_2).name, "> from_pod(const Pod& p);")
                    : Text::lit("");
                call_value(fold_job(prism_rtl::deref(t_p1_2).fields, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, Text, crate::lower::model::OutTy>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<Text, Text, crate::lower::model::OutTy>> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return entered(once_job([=]() {
                    return ({
                        auto d_po = p0;
                        auto&& _ft_pp = p1;
                        auto&& ft_pp = std::get<2>(_ft_pp);
                        (prism_rtl::finished(std::move(d_po) || crate::lower::types::holds_dyn(ft_pp)));
                    });
                }));
            }))), [=, reads_p4 = std::move(reads_p4), eq_p5 = std::move(eq_p5), back_p6 = std::move(back_p6)](bool fold_19459) {
                return ({
                    auto deep_p7 = fold_19459;
                    auto level_decl_p8 = std::move(deep_p7)
                        ? Text::lit("/// The level as a World reads it: each dynamic it holds sampled at the read point.\nPod level_pod(const Cx& cx) const;\n/// The update events of the dynamics it holds, and of theirs.\nvoid level_ports(const Cx& cx, std::vector<prism_rtl::Rc<prism_rtl::Port<Unit>>>& out) const;")
                        : Text::lit("");
                    auto decl_p9 = crate::emit::cpp::templates::items::cpp_tag_struct(cpp_source_doc(prism_rtl::cat("The `Level` of `", prism_rtl::deref(t_p1_2).tag_name, "`:"), prism_rtl::deref(t_p1_2).doc), prism_rtl::deref(t_p1_2).name, fields_p2, prism_rtl::deref(t_p1_2).tag_name, crate::syntax::lexer::chars::join(filter(Array(std::vector{eq_p5, back_p6, level_decl_p8}), [&](const Text& s_pq) { return s_pq != Text::lit(""); }), Text::lit("\n")));
                    call_value(each_job(prism_rtl::deref(t_p1_2).fields, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, Text, crate::lower::model::OutTy> p0) {
                    return entered(once_job([=]() {
                        return ({
                            auto [p_pr, f_ps, ft_pt] = p0;
                            (prism_rtl::more(prism_rtl::rc(CppDeepField(p_pr, f_ps, ft_pt))));
                        });
                    }));
                }))), [=, deep_p7 = std::move(deep_p7), decl_p9 = std::move(decl_p9)](Array<Text> each_20041) {
                    return ({
                        auto deep_pods_pa = crate::syntax::lexer::chars::join(each_20041, Text::lit(", "));
                        call_value(each_job(prism_rtl::deref(t_p1_2).fields, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, Text, crate::lower::model::OutTy> p0) {
                        return entered(once_job([=]() {
                            return ({
                                auto&& _f_pu = p0;
                                auto&& f_pu = std::get<1>(_f_pu);
                                auto&& ft_pv = std::get<2>(_f_pu);
                                (prism_rtl::more(prism_rtl::rc(CppDeepPorts(f_pu, ft_pv))));
                            });
                        }));
                    }))), [=, deep_pods_pa = std::move(deep_pods_pa)](Array<Text> each_20135) {
                        return ({
                            auto deep_ports_pb = crate::syntax::lexer::chars::join(filter(each_20135, [&](const Text& s_p10) { return s_p10 != Text::lit(""); }), Text::lit("\n"));
                            auto level_defs_pc = deep_p7
                                ? Array(std::vector{crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat("Pod ", prism_rtl::deref(t_p1_2).name, "::level_pod(const Cx& cx) const"), prism_rtl::cat("static_cast<void>(cx);\nreturn Pod::element(TAG, {", deep_pods_pa, "});")), crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat("void ", prism_rtl::deref(t_p1_2).name, "::level_ports(const Cx& cx, std::vector<prism_rtl::Rc<prism_rtl::Port<Unit>>>& out) const"), prism_rtl::cat("static_cast<void>(cx);\nstatic_cast<void>(out);", deep_ports_pb == Text::lit("")
                                ? Text::lit("")
                                : prism_rtl::cat("\n", deep_ports_pb)))})
                                : Array<Text>{};
                            auto to_pod_pd = crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat("Pod ", prism_rtl::deref(t_p1_2).name, "::to_pod() const"), prism_rtl::cat("return Pod::element(TAG, {", pods_p3, "});"));
                            auto show_pe = crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat("void ", prism_rtl::deref(t_p1_2).name, "::show(Printer& p) const"), Text::lit("prism_rtl::to_pod(*this).structure();\nShow<Pod>::show(prism_rtl::to_pod(*this), p);"));
                            auto from_pod_pf = prism_rtl::deref(t_p1_2).pod
                                ? Array(std::vector{crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat("Result<", prism_rtl::deref(t_p1_2).name, "> ", prism_rtl::deref(t_p1_2).name, "::from_pod(const Pod& p)"), prism_rtl::cat("if (auto t = p.tag(); t && *t == TAG) return ", prism_rtl::deref(t_p1_2).name, "{", reads_p4, "};\nreturn mismatch<", prism_rtl::deref(t_p1_2).name, ">(\"a ", prism_rtl::deref(t_p1_2).tag_name, "\", p);"))})
                                : Array<Text>{};
                            call_value(each_job(prism_rtl::deref(t_p1_2).fields, ({
                            auto cp_p0_1_3 = cp_p0_1;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Text, Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=, cp_p0_1_3 = std::move(cp_p0_1_3)](std::tuple<Text, Text, crate::lower::model::OutTy> p0) {
                            return ({
                                auto cp_p0_1_3_3 = cp_p0_1_3;
                                entered(once_job([=, cp_p0_1_3_3 = std::move(cp_p0_1_3_3)]() {
                                return ({
                                    auto&& _ft_p11 = p0;
                                    auto&& ft_p11 = std::get<2>(_ft_p11);
                                    (prism_rtl::more(prism_rtl::rc(ValueDeps(cp_p0_1_3_3, ft_p11))));
                                });
                            }));
                            });
                        })));
                        })), [=, level_defs_pc = std::move(level_defs_pc), to_pod_pd = std::move(to_pod_pd), show_pe = std::move(show_pe), from_pod_pf = std::move(from_pod_pf)](Array<Array<Text>> each_21129) {
                            return ({
                                auto deps_pg = crate::emit::cpp::patterns::concat2(each_21129);
                                (prism_rtl::finished(Parts{.forward = Array(std::vector{prism_rtl::cat("struct ", prism_rtl::deref(t_p1_2).name, ";")}), .values = Array(std::vector{ValueDecl{.path_ = decl_path(cp_p0_1, prism_rtl::deref(t_p1_2).name), .deps = deps_pg, .text = decl_p9}}), .protos = Array<Text>{}, .classes = Array<Text>{}, .outer = Array<Text>{}, .generic = Array<Text>{}, .defs = append(append(Array(std::vector{to_pod_pd, show_pe}), from_pod_pf), level_defs_pc)}));
                            });
                        });
                        });
                    });
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start TagParts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Parts> start_tag_parts(crate::emit::cpp::Cp cp_p0, crate::lower::model::TagDef t_p1) {
    return prism_rtl::make_rc<TagParts>(cp_p0, t_p1);
}


/// CppDeepField: unbounded fn Text, Text, OutTy -> Text
Text cpp_deep_field(const Text& p_p0, const Text& f_p1, const crate::lower::model::OutTy& ft_p2) {
    return prism_rtl::cat("{\"", p_p0, "\", ", cpp_deep_pod(f_p1, ft_p2), "}");
}


prism_rtl::Turn<Text> CppDeepField::cycle() const {
    const auto& p_p0 = this->p_p0;
    const auto& f_p1 = this->f_p1;
    const auto& ft_p2 = this->ft_p2;
    auto f_p1_1 = f_p1;
    auto ft_p2_2 = ft_p2;
    auto p_p0_3 = p_p0;
    return call_then(start_cpp_deep_pod(f_p1_1, ft_p2_2), [=](Text cpp_deep_pod_21684) { return prism_rtl::finished(prism_rtl::cat("{\"", p_p0_3, "\", ", cpp_deep_pod_21684, "}")); });
}


/// `Start CppDeepField, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_deep_field(Text p_p0, Text f_p1, crate::lower::model::OutTy ft_p2) {
    return prism_rtl::make_rc<CppDeepField>(p_p0, f_p1, ft_p2);
}


/// CppDeepPod: unbounded fn Text, OutTy -> Text
Text cpp_deep_pod(const Text& f_p0, const crate::lower::model::OutTy& ft_p1) {
    if (prism_rtl::is<crate::lower::model::OutTy::OutMap>(ft_p1)) {
        auto&& m21773_0_1 = prism_rtl::as<crate::lower::model::OutTy::OutMap>(ft_p1).a1;
        if (prism_rtl::is<crate::lower::model::OutTy::OutDyn>(prism_rtl::deref(prism_rtl::deref(m21773_0_1)))) {
            auto&& m21773_0_1_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(prism_rtl::deref(prism_rtl::deref(m21773_0_1))).a0;
            if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(prism_rtl::deref(prism_rtl::deref(m21773_0_1_r_0)))) {
                auto&& m21773_0_1_r_0_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(prism_rtl::deref(prism_rtl::deref(m21773_0_1_r_0))).a0;
                if (m21773_0_1_r_0_r_0 == Text::lit("crate::Elem")) {
                    return prism_rtl::cat("prism_rtl::dynamics_pod(", crate::emit::cpp::field_id(f_p0), ", cx)");
                }
            }
        }
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutDyn>(ft_p1)) {
        auto&& m21773_1_0 = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(ft_p1).a0;
        if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(prism_rtl::deref(prism_rtl::deref(m21773_1_0)))) {
            auto&& m21773_1_0_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(prism_rtl::deref(prism_rtl::deref(m21773_1_0))).a0;
            if (m21773_1_0_r_0 == Text::lit("crate::Elem")) {
                return prism_rtl::cat("prism_rtl::level_pod(", crate::emit::cpp::field_id(f_p0), ".sample(cx), cx)");
            }
        }
    }
    {
        auto&& other_p2 = ft_p1;
        return crate::lower::types::holds_dyn(other_p2)
            ? Text::lit("[] { static_assert(false, \"prismc: a tag field holding a dynamic other than `$Elem` or a map of them is not read deep (claude/incremental-host-document.md, doubt WD)\"); return Pod(); }()")
            : prism_rtl::cat("prism_rtl::to_pod(", crate::emit::cpp::field_id(f_p0), ")");
    }
}


prism_rtl::Turn<Text> CppDeepPod::cycle() const {
    const auto& f_p0 = this->f_p0;
    const auto& ft_p1 = this->ft_p1;
    return ({
        prism_rtl::is<crate::lower::model::OutTy::OutMap>(ft_p1) && ({
        auto&& m21773_0_1 = prism_rtl::as<crate::lower::model::OutTy::OutMap>(ft_p1).a1;
        prism_rtl::is<crate::lower::model::OutTy::OutDyn>(prism_rtl::deref(prism_rtl::deref(m21773_0_1))) && ({
        auto&& m21773_0_1_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(prism_rtl::deref(prism_rtl::deref(m21773_0_1))).a0;
        prism_rtl::is<crate::lower::model::OutTy::OutNamed>(prism_rtl::deref(prism_rtl::deref(m21773_0_1_r_0))) && ({
        auto&& m21773_0_1_r_0_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(prism_rtl::deref(prism_rtl::deref(m21773_0_1_r_0))).a0;
        (m21773_0_1_r_0_r_0 == Text::lit("crate::Elem"));
    });
    });
    }) ? ({
        auto&& m21773_0_1 = prism_rtl::as<crate::lower::model::OutTy::OutMap>(ft_p1).a1;
        auto&& m21773_0_1_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(prism_rtl::deref(prism_rtl::deref(m21773_0_1))).a0;
        auto&& m21773_0_1_r_0_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(prism_rtl::deref(prism_rtl::deref(m21773_0_1_r_0))).a0;
        prism_rtl::finished(prism_rtl::cat("prism_rtl::dynamics_pod(", crate::emit::cpp::field_id(f_p0), ", cx)"));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutDyn>(ft_p1) && ({
        auto&& m21773_1_0 = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(ft_p1).a0;
        prism_rtl::is<crate::lower::model::OutTy::OutNamed>(prism_rtl::deref(prism_rtl::deref(m21773_1_0))) && ({
        auto&& m21773_1_0_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(prism_rtl::deref(prism_rtl::deref(m21773_1_0))).a0;
        (m21773_1_0_r_0 == Text::lit("crate::Elem"));
    });
    }) ? ({
        auto&& m21773_1_0 = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(ft_p1).a0;
        auto&& m21773_1_0_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(prism_rtl::deref(prism_rtl::deref(m21773_1_0))).a0;
        prism_rtl::finished(prism_rtl::cat("prism_rtl::level_pod(", crate::emit::cpp::field_id(f_p0), ".sample(cx), cx)"));
    })
        : ({
        auto&& other_p2 = ft_p1;
        ({
        auto f_p0_1 = f_p0;
        auto other_p2_2 = other_p2;
        call_then(crate::lower::types::start_holds_dyn(other_p2_2), [=, f_p0_1 = std::move(f_p0_1)](bool holds_dyn_21998) {
        return holds_dyn_21998
            ? prism_rtl::finished(Text::lit("[] { static_assert(false, \"prismc: a tag field holding a dynamic other than `$Elem` or a map of them is not read deep (claude/incremental-host-document.md, doubt WD)\"); return Pod(); }()"))
            : prism_rtl::finished(prism_rtl::cat("prism_rtl::to_pod(", crate::emit::cpp::field_id(f_p0_1), ")"));
    });
    });
    });
    });
}


/// `Start CppDeepPod, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_deep_pod(Text f_p0, crate::lower::model::OutTy ft_p1) {
    return prism_rtl::make_rc<CppDeepPod>(f_p0, ft_p1);
}


/// CppDeepPorts: unbounded fn Text, OutTy -> Text
Text cpp_deep_ports(const Text& f_p0, const crate::lower::model::OutTy& ft_p1) {
    if (prism_rtl::is<crate::lower::model::OutTy::OutMap>(ft_p1)) {
        auto&& m22318_0_1 = prism_rtl::as<crate::lower::model::OutTy::OutMap>(ft_p1).a1;
        if (prism_rtl::is<crate::lower::model::OutTy::OutDyn>(prism_rtl::deref(prism_rtl::deref(m22318_0_1)))) {
            auto&& m22318_0_1_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(prism_rtl::deref(prism_rtl::deref(m22318_0_1))).a0;
            if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(prism_rtl::deref(prism_rtl::deref(m22318_0_1_r_0)))) {
                auto&& m22318_0_1_r_0_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(prism_rtl::deref(prism_rtl::deref(m22318_0_1_r_0))).a0;
                if (m22318_0_1_r_0_r_0 == Text::lit("crate::Elem")) {
                    return prism_rtl::cat("prism_rtl::dynamics_ports(", crate::emit::cpp::field_id(f_p0), ", cx, out);");
                }
            }
        }
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutDyn>(ft_p1)) {
        auto&& m22318_1_0 = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(ft_p1).a0;
        if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(prism_rtl::deref(prism_rtl::deref(m22318_1_0)))) {
            auto&& m22318_1_0_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(prism_rtl::deref(prism_rtl::deref(m22318_1_0))).a0;
            if (m22318_1_0_r_0 == Text::lit("crate::Elem")) {
                return prism_rtl::cat("out.push_back(", crate::emit::cpp::field_id(f_p0), ".updates);\nprism_rtl::level_ports(", crate::emit::cpp::field_id(f_p0), ".sample(cx), cx, out);");
            }
        }
    }
    {
        return Text::lit("");
    }
}


prism_rtl::Turn<Text> CppDeepPorts::cycle() const {
    const auto& f_p0 = this->f_p0;
    const auto& ft_p1 = this->ft_p1;
    return ({
        prism_rtl::is<crate::lower::model::OutTy::OutMap>(ft_p1) && ({
        auto&& m22318_0_1 = prism_rtl::as<crate::lower::model::OutTy::OutMap>(ft_p1).a1;
        prism_rtl::is<crate::lower::model::OutTy::OutDyn>(prism_rtl::deref(prism_rtl::deref(m22318_0_1))) && ({
        auto&& m22318_0_1_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(prism_rtl::deref(prism_rtl::deref(m22318_0_1))).a0;
        prism_rtl::is<crate::lower::model::OutTy::OutNamed>(prism_rtl::deref(prism_rtl::deref(m22318_0_1_r_0))) && ({
        auto&& m22318_0_1_r_0_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(prism_rtl::deref(prism_rtl::deref(m22318_0_1_r_0))).a0;
        (m22318_0_1_r_0_r_0 == Text::lit("crate::Elem"));
    });
    });
    }) ? ({
        auto&& m22318_0_1 = prism_rtl::as<crate::lower::model::OutTy::OutMap>(ft_p1).a1;
        auto&& m22318_0_1_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(prism_rtl::deref(prism_rtl::deref(m22318_0_1))).a0;
        auto&& m22318_0_1_r_0_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(prism_rtl::deref(prism_rtl::deref(m22318_0_1_r_0))).a0;
        prism_rtl::finished(prism_rtl::cat("prism_rtl::dynamics_ports(", crate::emit::cpp::field_id(f_p0), ", cx, out);"));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutDyn>(ft_p1) && ({
        auto&& m22318_1_0 = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(ft_p1).a0;
        prism_rtl::is<crate::lower::model::OutTy::OutNamed>(prism_rtl::deref(prism_rtl::deref(m22318_1_0))) && ({
        auto&& m22318_1_0_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(prism_rtl::deref(prism_rtl::deref(m22318_1_0))).a0;
        (m22318_1_0_r_0 == Text::lit("crate::Elem"));
    });
    }) ? ({
        auto&& m22318_1_0 = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(ft_p1).a0;
        auto&& m22318_1_0_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(prism_rtl::deref(prism_rtl::deref(m22318_1_0))).a0;
        prism_rtl::finished(prism_rtl::cat("out.push_back(", crate::emit::cpp::field_id(f_p0), ".updates);\nprism_rtl::level_ports(", crate::emit::cpp::field_id(f_p0), ".sample(cx), cx, out);"));
    })
        : prism_rtl::finished(Text::lit(""));
    });
}


/// `Start CppDeepPorts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_deep_ports(Text f_p0, crate::lower::model::OutTy ft_p1) {
    return prism_rtl::make_rc<CppDeepPorts>(f_p0, ft_p1);
}


/// RowParts: unbounded fn Cp, Text, RowDef -> Parts
Parts row_parts(const crate::emit::cpp::Cp& cp_p0, const Text& m_p1, const crate::lower::model::RowDef& r_p2) {
    auto names_p3 = each(r_p2.cases_, [&](const std::tuple<Text, Text>& _p0) {
        auto&& v_pf = std::get<0>(_p0);
        return v_pf;
    });
    auto levels_p4 = r_p2.level
        ? Text::lit("\nPod level_pod(const Cx& cx) const;\nvoid level_ports(const Cx& cx, std::vector<prism_rtl::Rc<prism_rtl::Port<Unit>>>& out) const;")
        : Text::lit("");
    auto pod_p5 = prism_rtl::cat("Pod to_pod() const;\nvoid show(Printer& p) const;", r_p2.pod
        ? prism_rtl::cat("\nstatic Result<", r_p2.name, "> from_pod(const Pod& p);")
        : Text::lit(""), levels_p4);
    auto cases_p6 = crate::syntax::lexer::chars::join(each(r_p2.cases_, [&](const std::tuple<Text, Text>& _p0) {
        auto&& v_pg = std::get<0>(_p0);
        auto&& st_ph = std::get<1>(_p0);
        return crate::emit::cpp::templates::items::case_decl(v_pg, prism_rtl::cat(row_struct(m_p1, st_ph), " a0;", r_p2.eq
            ? prism_rtl::cat("\nbool operator==(const ", v_pg, "&) const = default;")
            : Text::lit("")));
    }), Text::lit("\n"));
    auto cls_p7 = crate::emit::cpp::templates::items::choice_class(cpp_source_doc(prism_rtl::cat("`", r_p2.prism, "`, a row kind\'s values:"), r_p2.doc), Text::lit(""), r_p2.name, cases_p6, crate::syntax::lexer::chars::join(names_p3, Text::lit(", ")), pod_p5);
    auto eq_p8 = r_p2.eq
        ? prism_rtl::cat("\ninline bool operator==(const ", r_p2.name, "& a, const ", r_p2.name, "& b) { return a.cases() == b.cases(); }")
        : Text::lit("");
    auto level_defs_p9 = r_p2.level
        ? Array(std::vector{crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat("Pod ", r_p2.name, "::level_pod(const Cx& cx) const"), Text::lit("return std::visit([&](const auto& c) { return prism_rtl::level_pod(c.a0, cx); }, cases());")), crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat("void ", r_p2.name, "::level_ports(const Cx& cx, std::vector<prism_rtl::Rc<prism_rtl::Port<Unit>>>& out) const"), Text::lit("std::visit([&](const auto& c) { prism_rtl::level_ports(c.a0, cx, out); }, cases());"))})
        : Array<Text>{};
    auto to_pod_pa = crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat("Pod ", r_p2.name, "::to_pod() const"), Text::lit("return std::visit([](const auto& c) { return prism_rtl::to_pod(c.a0); }, cases());"));
    auto show_pb = crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat("void ", r_p2.name, "::show(Printer& p) const"), Text::lit("Show<Pod>::show(to_pod(), p);"));
    auto reads_pc = crate::syntax::lexer::chars::join(each(r_p2.cases_, [&](const std::tuple<Text, Text>& _p0) {
        auto&& v_pi = std::get<0>(_p0);
        auto&& st_pj = std::get<1>(_p0);
        return prism_rtl::cat("if (*t == ", row_struct(m_p1, st_pj), "::TAG) return ", r_p2.name, "(", v_pi, "{TRY(prism_rtl::from_pod<", row_struct(m_p1, st_pj), ">(p))});");
    }), Text::lit("\n"));
    auto from_pod_pd = r_p2.pod
        ? Array(std::vector{crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat("Result<", r_p2.name, "> ", r_p2.name, "::from_pod(const Pod& p)"), prism_rtl::cat("if (auto t = p.tag()) {\n", indent_cpp(reads_pc), "\n}\nreturn mismatch<", r_p2.name, ">(\"a ", r_p2.name, "\", p);"))})
        : Array<Text>{};
    auto deps_pe = crate::emit::cpp::patterns::concat2(run_to_end(each_job(r_p2.cases_, ({
        auto cp_p0_1 = cp_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Text, Text>)>>(prism_rtl::rc([=, cp_p0_1 = std::move(cp_p0_1)](std::tuple<Text, Text> p0) {
        return ({
            auto cp_p0_1_2 = cp_p0_1;
            entered(once_job([=, cp_p0_1_2 = std::move(cp_p0_1_2)]() {
            return ({
                auto&& _st_pk = p0;
                auto&& st_pk = std::get<1>(_st_pk);
                (prism_rtl::more(prism_rtl::rc(ValueDeps(cp_p0_1_2, crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{st_pk, Array<crate::lower::model::OutTy>{}})))));
            });
        }));
        });
    })));
    }))));
    return Parts{.forward = Array(std::vector{prism_rtl::cat("class ", r_p2.name, ";")}), .values = Array(std::vector{ValueDecl{.path_ = decl_path(cp_p0, r_p2.name), .deps = deps_pe, .text = prism_rtl::cat(cls_p7, eq_p8)}}), .protos = Array<Text>{}, .classes = Array<Text>{}, .outer = Array<Text>{}, .generic = Array<Text>{}, .defs = append(append(Array(std::vector{to_pod_pa, show_pb}), from_pod_pd), level_defs_p9)};
}


prism_rtl::Turn<Parts> RowParts::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& m_p1 = this->m_p1;
    const auto& r_p2 = this->r_p2;
    auto names_p3 = each(prism_rtl::deref(r_p2).cases_, [&](const std::tuple<Text, Text>& _p0) {
        auto&& v_pf = std::get<0>(_p0);
        return v_pf;
    });
    auto levels_p4 = prism_rtl::deref(r_p2).level
        ? Text::lit("\nPod level_pod(const Cx& cx) const;\nvoid level_ports(const Cx& cx, std::vector<prism_rtl::Rc<prism_rtl::Port<Unit>>>& out) const;")
        : Text::lit("");
    auto pod_p5 = prism_rtl::cat("Pod to_pod() const;\nvoid show(Printer& p) const;", prism_rtl::deref(r_p2).pod
        ? prism_rtl::cat("\nstatic Result<", prism_rtl::deref(r_p2).name, "> from_pod(const Pod& p);")
        : Text::lit(""), levels_p4);
    auto cases_p6 = crate::syntax::lexer::chars::join(each(prism_rtl::deref(r_p2).cases_, [&](const std::tuple<Text, Text>& _p0) {
        auto&& v_pg = std::get<0>(_p0);
        auto&& st_ph = std::get<1>(_p0);
        return crate::emit::cpp::templates::items::case_decl(v_pg, prism_rtl::cat(row_struct(m_p1, st_ph), " a0;", prism_rtl::deref(r_p2).eq
            ? prism_rtl::cat("\nbool operator==(const ", v_pg, "&) const = default;")
            : Text::lit("")));
    }), Text::lit("\n"));
    auto cls_p7 = crate::emit::cpp::templates::items::choice_class(cpp_source_doc(prism_rtl::cat("`", prism_rtl::deref(r_p2).prism, "`, a row kind\'s values:"), prism_rtl::deref(r_p2).doc), Text::lit(""), prism_rtl::deref(r_p2).name, cases_p6, crate::syntax::lexer::chars::join(names_p3, Text::lit(", ")), pod_p5);
    auto eq_p8 = prism_rtl::deref(r_p2).eq
        ? prism_rtl::cat("\ninline bool operator==(const ", prism_rtl::deref(r_p2).name, "& a, const ", prism_rtl::deref(r_p2).name, "& b) { return a.cases() == b.cases(); }")
        : Text::lit("");
    auto level_defs_p9 = prism_rtl::deref(r_p2).level
        ? Array(std::vector{crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat("Pod ", prism_rtl::deref(r_p2).name, "::level_pod(const Cx& cx) const"), Text::lit("return std::visit([&](const auto& c) { return prism_rtl::level_pod(c.a0, cx); }, cases());")), crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat("void ", prism_rtl::deref(r_p2).name, "::level_ports(const Cx& cx, std::vector<prism_rtl::Rc<prism_rtl::Port<Unit>>>& out) const"), Text::lit("std::visit([&](const auto& c) { prism_rtl::level_ports(c.a0, cx, out); }, cases());"))})
        : Array<Text>{};
    auto to_pod_pa = crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat("Pod ", prism_rtl::deref(r_p2).name, "::to_pod() const"), Text::lit("return std::visit([](const auto& c) { return prism_rtl::to_pod(c.a0); }, cases());"));
    auto show_pb = crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat("void ", prism_rtl::deref(r_p2).name, "::show(Printer& p) const"), Text::lit("Show<Pod>::show(to_pod(), p);"));
    auto reads_pc = crate::syntax::lexer::chars::join(each(prism_rtl::deref(r_p2).cases_, [&](const std::tuple<Text, Text>& _p0) {
        auto&& v_pi = std::get<0>(_p0);
        auto&& st_pj = std::get<1>(_p0);
        return prism_rtl::cat("if (*t == ", row_struct(m_p1, st_pj), "::TAG) return ", prism_rtl::deref(r_p2).name, "(", v_pi, "{TRY(prism_rtl::from_pod<", row_struct(m_p1, st_pj), ">(p))});");
    }), Text::lit("\n"));
    auto from_pod_pd = prism_rtl::deref(r_p2).pod
        ? Array(std::vector{crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat("Result<", prism_rtl::deref(r_p2).name, "> ", prism_rtl::deref(r_p2).name, "::from_pod(const Pod& p)"), prism_rtl::cat("if (auto t = p.tag()) {\n", indent_cpp(reads_pc), "\n}\nreturn mismatch<", prism_rtl::deref(r_p2).name, ">(\"a ", prism_rtl::deref(r_p2).name, "\", p);"))})
        : Array<Text>{};
    auto cp_p0_1 = cp_p0;
    auto r_p2_2 = r_p2;
    return call_value(each_job(prism_rtl::deref(r_p2_2).cases_, ({
        auto cp_p0_1_3 = cp_p0_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Text, Text>)>>(prism_rtl::rc([=, cp_p0_1_3 = std::move(cp_p0_1_3)](std::tuple<Text, Text> p0) {
        return ({
            auto cp_p0_1_3_3 = cp_p0_1_3;
            entered(once_job([=, cp_p0_1_3_3 = std::move(cp_p0_1_3_3)]() {
            return ({
                auto&& _st_pk = p0;
                auto&& st_pk = std::get<1>(_st_pk);
                (prism_rtl::more(prism_rtl::rc(ValueDeps(cp_p0_1_3_3, crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{st_pk, Array<crate::lower::model::OutTy>{}})))));
            });
        }));
        });
    })));
    })), [=](Array<Array<Text>> each_24756) {
        return ({
            auto deps_pe = crate::emit::cpp::patterns::concat2(each_24756);
            (prism_rtl::finished(Parts{.forward = Array(std::vector{prism_rtl::cat("class ", prism_rtl::deref(r_p2_2).name, ";")}), .values = Array(std::vector{ValueDecl{.path_ = decl_path(cp_p0_1, prism_rtl::deref(r_p2_2).name), .deps = deps_pe, .text = prism_rtl::cat(cls_p7, eq_p8)}}), .protos = Array<Text>{}, .classes = Array<Text>{}, .outer = Array<Text>{}, .generic = Array<Text>{}, .defs = append(append(Array(std::vector{to_pod_pa, show_pb}), from_pod_pd), level_defs_p9)}));
        });
    });
}


/// `Start RowParts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Parts> start_row_parts(crate::emit::cpp::Cp cp_p0, Text m_p1, crate::lower::model::RowDef r_p2) {
    return prism_rtl::make_rc<RowParts>(cp_p0, m_p1, r_p2);
}


/// RowStruct: fn Text, Text -> Text
Text row_struct(const Text& m_p0, const Text& st_p1) {
    return crate::syntax::lexer::chars::contains(st_p1, Text::lit(":")) || (m_p0 == Text::lit(""))
        ? crate::emit::cpp::type_path(st_p1)
        : prism_rtl::cat("crate::", m_p0, "::", st_p1);
}


/// AnswerParts: unbounded fn Cp, AnswerDef -> Parts
Parts answer_parts(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::AnswerDef& a_p1) {
    auto names_p2 = each(a_p1.cases_, [&](const crate::lower::model::AnswerCase& c_pc) { return prism_rtl::deref(c_pc).variant; });
    auto accessors_p3 = crate::syntax::lexer::chars::join(run_to_end(each_job(a_p1.cases_, ({
        auto cp_p0_1 = cp_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::AnswerCase)>>(prism_rtl::rc([=, cp_p0_1 = std::move(cp_p0_1)](crate::lower::model::AnswerCase p0) {
        return ({
            auto cp_p0_1_2 = cp_p0_1;
            entered(once_job([=, cp_p0_1_2 = std::move(cp_p0_1_2)]() {
            return ({
                auto c_pd = p0;
                call_then(crate::emit::cpp::start_cpp_type(cp_p0_1_2, prism_rtl::deref(c_pd).ty), [=](Text cpp_type_25615) { return prism_rtl::finished(prism_rtl::cat("Result<", cpp_type_25615, "> ", prism_rtl::deref(c_pd).accessor, "() const;")); });
            });
        }));
        });
    })));
    }))), Text::lit("\n"));
    auto members_p4 = prism_rtl::cat("const char* tag() const;\n", accessors_p3, "\nstatic Result<Answer> decode(const Elem& e, const Pod& v);");
    auto cases_p5 = crate::syntax::lexer::chars::join(run_to_end(each_job(a_p1.cases_, ({
        auto cp_p0_1 = cp_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::AnswerCase)>>(prism_rtl::rc([=, cp_p0_1 = std::move(cp_p0_1)](crate::lower::model::AnswerCase p0) {
        return ({
            auto cp_p0_1_2 = cp_p0_1;
            entered(once_job([=, cp_p0_1_2 = std::move(cp_p0_1_2)]() {
            return ({
                auto c_pe = p0;
                call_then(crate::emit::cpp::start_cpp_type(cp_p0_1_2, prism_rtl::deref(c_pe).ty), [=](Text cpp_type_25845) { return prism_rtl::finished(crate::emit::cpp::templates::items::case_decl(prism_rtl::deref(c_pe).variant, prism_rtl::cat(cpp_type_25845, " a0;"))); });
            });
        }));
        });
    })));
    }))), Text::lit("\n"));
    auto cls_p6 = crate::emit::cpp::templates::items::choice_class(cpp_doc(Text::lit("`Answer c`: an answer to an element, typed by its tag (Semantics ch. 9): what a host\'s\nsupplier answers a child place with, and what a World\'s answer to a forwarded element\ndecodes to, carrying the tag\'s output.")), Text::lit(""), Text::lit("Answer"), cases_p5, crate::syntax::lexer::chars::join(names_p2, Text::lit(", ")), members_p4);
    auto tags_p7 = crate::syntax::lexer::chars::join(each(a_p1.cases_, [&](const crate::lower::model::AnswerCase& c_pf) { return prism_rtl::cat("if (std::holds_alternative<", prism_rtl::deref(c_pf).variant, ">(cases())) return ", crate::emit::cpp::type_path(prism_rtl::deref(c_pf).struct_path), "::TAG;"); }), Text::lit("\n"));
    auto tag_fn_p8 = crate::emit::cpp::templates::items::cpp_function(Text::lit(""), Text::lit("const char* Answer::tag() const"), prism_rtl::cat(tags_p7, "\nprism_rtl::unreachable();"));
    auto getters_p9 = run_to_end(each_job(a_p1.cases_, ({
        auto cp_p0_1 = cp_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::AnswerCase)>>(prism_rtl::rc([=, cp_p0_1 = std::move(cp_p0_1)](crate::lower::model::AnswerCase p0) {
        return ({
            auto cp_p0_1_2 = cp_p0_1;
            entered(once_job([=, cp_p0_1_2 = std::move(cp_p0_1_2)]() {
            return ({
                auto c_pg = p0;
                call_then(crate::emit::cpp::start_cpp_type(cp_p0_1_2, prism_rtl::deref(c_pg).ty), [=](Text cpp_type_26511) { return prism_rtl::finished(crate::emit::cpp::templates::items::cpp_function(cpp_doc(prism_rtl::cat("A `", prism_rtl::deref(c_pg).tag_name, "`\'s answer.")), prism_rtl::cat("Result<", cpp_type_26511, "> Answer::", prism_rtl::deref(c_pg).accessor, "() const"), prism_rtl::cat("if (auto c = std::get_if<", prism_rtl::deref(c_pg).variant, ">(&cases())) return c->a0;\nreturn unexpected(Fault::answer(str(\"an answer for \", tag(), \", where ", prism_rtl::deref(c_pg).tag_name, "\'s was expected\")));"))); });
            });
        }));
        });
    })));
    })));
    auto decodes_pa = crate::syntax::lexer::chars::join(run_to_end(each_job(a_p1.cases_, ({
        auto cp_p0_1 = cp_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::AnswerCase)>>(prism_rtl::rc([=, cp_p0_1 = std::move(cp_p0_1)](crate::lower::model::AnswerCase p0) {
        return ({
            auto cp_p0_1_2 = cp_p0_1;
            entered(once_job([=, cp_p0_1_2 = std::move(cp_p0_1_2)]() {
            return ({
                auto c_ph = p0;
                call_then(crate::emit::cpp::start_cpp_type(cp_p0_1_2, prism_rtl::deref(c_ph).ty), [=](Text cpp_type_26859) { return prism_rtl::finished(prism_rtl::cat("if (is<Elem::", prism_rtl::deref(c_ph).variant, ">(e)) return Answer(", prism_rtl::deref(c_ph).variant, "{TRY(prism_rtl::from_pod<", cpp_type_26859, ">(v))});")); });
            });
        }));
        });
    })));
    }))), Text::lit("\n"));
    auto decode_pb = crate::emit::cpp::templates::items::cpp_function(cpp_doc(Text::lit("A World\'s answer to the element `e`, decoded by its tag.")), Text::lit("Result<Answer> Answer::decode(const Elem& e, const Pod& v)"), prism_rtl::cat(decodes_pa, "\nprism_rtl::unreachable();"));
    return Parts{.forward = Array(std::vector{Text::lit("class Answer;")}), .values = Array(std::vector{ValueDecl{.path_ = Text::lit("Answer"), .deps = Array<Text>{}, .text = cls_p6}}), .protos = Array<Text>{}, .classes = Array<Text>{}, .outer = Array<Text>{}, .generic = Array<Text>{}, .defs = append(Array(std::vector{tag_fn_p8}), crate::prelude::push(getters_p9, decode_pb))};
}


prism_rtl::Turn<Parts> AnswerParts::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& a_p1 = this->a_p1;
    auto names_p2 = each(prism_rtl::deref(a_p1).cases_, [&](const crate::lower::model::AnswerCase& c_pc) { return prism_rtl::deref(c_pc).variant; });
    auto a_p1_1 = a_p1;
    auto cp_p0_2 = cp_p0;
    return call_value(each_job(prism_rtl::deref(a_p1_1).cases_, ({
        auto cp_p0_2_3 = cp_p0_2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::AnswerCase)>>(prism_rtl::rc([=, cp_p0_2_3 = std::move(cp_p0_2_3)](crate::lower::model::AnswerCase p0) {
        return ({
            auto cp_p0_2_3_3 = cp_p0_2_3;
            entered(once_job([=, cp_p0_2_3_3 = std::move(cp_p0_2_3_3)]() {
            return ({
                auto c_pd = p0;
                call_then(crate::emit::cpp::start_cpp_type(cp_p0_2_3_3, prism_rtl::deref(c_pd).ty), [=](Text cpp_type_25615) { return prism_rtl::finished(prism_rtl::cat("Result<", cpp_type_25615, "> ", prism_rtl::deref(c_pd).accessor, "() const;")); });
            });
        }));
        });
    })));
    })), [=](Array<Text> each_25587) {
        return ({
            auto accessors_p3 = crate::syntax::lexer::chars::join(each_25587, Text::lit("\n"));
            auto members_p4 = prism_rtl::cat("const char* tag() const;\n", accessors_p3, "\nstatic Result<Answer> decode(const Elem& e, const Pod& v);");
            call_value(each_job(prism_rtl::deref(a_p1_1).cases_, ({
            auto cp_p0_2_3 = cp_p0_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::AnswerCase)>>(prism_rtl::rc([=, cp_p0_2_3 = std::move(cp_p0_2_3)](crate::lower::model::AnswerCase p0) {
            return ({
                auto cp_p0_2_3_3 = cp_p0_2_3;
                entered(once_job([=, cp_p0_2_3_3 = std::move(cp_p0_2_3_3)]() {
                return ({
                    auto c_pe = p0;
                    call_then(crate::emit::cpp::start_cpp_type(cp_p0_2_3_3, prism_rtl::deref(c_pe).ty), [=](Text cpp_type_25845) { return prism_rtl::finished(crate::emit::cpp::templates::items::case_decl(prism_rtl::deref(c_pe).variant, prism_rtl::cat(cpp_type_25845, " a0;"))); });
                });
            }));
            });
        })));
        })), [=, members_p4 = std::move(members_p4)](Array<Text> each_25804) {
            return ({
                auto cases_p5 = crate::syntax::lexer::chars::join(each_25804, Text::lit("\n"));
                auto cls_p6 = crate::emit::cpp::templates::items::choice_class(cpp_doc(Text::lit("`Answer c`: an answer to an element, typed by its tag (Semantics ch. 9): what a host\'s\nsupplier answers a child place with, and what a World\'s answer to a forwarded element\ndecodes to, carrying the tag\'s output.")), Text::lit(""), Text::lit("Answer"), cases_p5, crate::syntax::lexer::chars::join(names_p2, Text::lit(", ")), members_p4);
                auto tags_p7 = crate::syntax::lexer::chars::join(each(prism_rtl::deref(a_p1_1).cases_, [&](const crate::lower::model::AnswerCase& c_pf) { return prism_rtl::cat("if (std::holds_alternative<", prism_rtl::deref(c_pf).variant, ">(cases())) return ", crate::emit::cpp::type_path(prism_rtl::deref(c_pf).struct_path), "::TAG;"); }), Text::lit("\n"));
                auto tag_fn_p8 = crate::emit::cpp::templates::items::cpp_function(Text::lit(""), Text::lit("const char* Answer::tag() const"), prism_rtl::cat(tags_p7, "\nprism_rtl::unreachable();"));
                call_value(each_job(prism_rtl::deref(a_p1_1).cases_, ({
                auto cp_p0_2_3 = cp_p0_2;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::AnswerCase)>>(prism_rtl::rc([=, cp_p0_2_3 = std::move(cp_p0_2_3)](crate::lower::model::AnswerCase p0) {
                return ({
                    auto cp_p0_2_3_3 = cp_p0_2_3;
                    entered(once_job([=, cp_p0_2_3_3 = std::move(cp_p0_2_3_3)]() {
                    return ({
                        auto c_pg = p0;
                        call_then(crate::emit::cpp::start_cpp_type(cp_p0_2_3_3, prism_rtl::deref(c_pg).ty), [=](Text cpp_type_26511) { return prism_rtl::finished(crate::emit::cpp::templates::items::cpp_function(cpp_doc(prism_rtl::cat("A `", prism_rtl::deref(c_pg).tag_name, "`\'s answer.")), prism_rtl::cat("Result<", cpp_type_26511, "> Answer::", prism_rtl::deref(c_pg).accessor, "() const"), prism_rtl::cat("if (auto c = std::get_if<", prism_rtl::deref(c_pg).variant, ">(&cases())) return c->a0;\nreturn unexpected(Fault::answer(str(\"an answer for \", tag(), \", where ", prism_rtl::deref(c_pg).tag_name, "\'s was expected\")));"))); });
                    });
                }));
                });
            })));
            })), [=, cls_p6 = std::move(cls_p6), tag_fn_p8 = std::move(tag_fn_p8)](Array<Text> each_26433) {
                return ({
                    auto getters_p9 = each_26433;
                    call_value(each_job(prism_rtl::deref(a_p1_1).cases_, ({
                    auto cp_p0_2_3 = cp_p0_2;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::AnswerCase)>>(prism_rtl::rc([=, cp_p0_2_3 = std::move(cp_p0_2_3)](crate::lower::model::AnswerCase p0) {
                    return ({
                        auto cp_p0_2_3_3 = cp_p0_2_3;
                        entered(once_job([=, cp_p0_2_3_3 = std::move(cp_p0_2_3_3)]() {
                        return ({
                            auto c_ph = p0;
                            call_then(crate::emit::cpp::start_cpp_type(cp_p0_2_3_3, prism_rtl::deref(c_ph).ty), [=](Text cpp_type_26859) { return prism_rtl::finished(prism_rtl::cat("if (is<Elem::", prism_rtl::deref(c_ph).variant, ">(e)) return Answer(", prism_rtl::deref(c_ph).variant, "{TRY(prism_rtl::from_pod<", cpp_type_26859, ">(v))});")); });
                        });
                    }));
                    });
                })));
                })), [=, getters_p9 = std::move(getters_p9)](Array<Text> each_26757) {
                    return ({
                        auto decodes_pa = crate::syntax::lexer::chars::join(each_26757, Text::lit("\n"));
                        auto decode_pb = crate::emit::cpp::templates::items::cpp_function(cpp_doc(Text::lit("A World\'s answer to the element `e`, decoded by its tag.")), Text::lit("Result<Answer> Answer::decode(const Elem& e, const Pod& v)"), prism_rtl::cat(decodes_pa, "\nprism_rtl::unreachable();"));
                        (prism_rtl::finished(Parts{.forward = Array(std::vector{Text::lit("class Answer;")}), .values = Array(std::vector{ValueDecl{.path_ = Text::lit("Answer"), .deps = Array<Text>{}, .text = cls_p6}}), .protos = Array<Text>{}, .classes = Array<Text>{}, .outer = Array<Text>{}, .generic = Array<Text>{}, .defs = append(Array(std::vector{tag_fn_p8}), crate::prelude::push(getters_p9, decode_pb))}));
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start AnswerParts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Parts> start_answer_parts(crate::emit::cpp::Cp cp_p0, crate::lower::model::AnswerDef a_p1) {
    return prism_rtl::make_rc<AnswerParts>(cp_p0, a_p1);
}


/// JobParts: unbounded fn Cp, JobDef -> Parts
Parts job_parts(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::JobDef& j_p1) {
    auto gens_p2 = cpp_template_head(generic_names_of(j_p1.generics));
    auto head_p3 = head_of(j_p1.name, generic_names_of(j_p1.generics));
    auto jcp_p4 = crate::emit::cpp::with_fields(cp_p0, j_p1.fields);
    auto fields_p5 = crate::syntax::lexer::chars::join(run_to_end(each_job(j_p1.fields, ({
        auto cp_p0_1 = cp_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=, cp_p0_1 = std::move(cp_p0_1)](std::tuple<Text, crate::lower::model::OutTy> p0) {
        return ({
            auto cp_p0_1_2 = cp_p0_1;
            entered(once_job([=, cp_p0_1_2 = std::move(cp_p0_1_2)]() {
            return ({
                auto [n_pe, t_pf] = p0;
                call_then(crate::emit::cpp::start_cpp_type(cp_p0_1_2, t_pf), [=](Text cpp_type_27625) { return prism_rtl::finished(prism_rtl::cat(cpp_type_27625, " ", crate::emit::cpp::field_id(n_pe), ";")); });
            });
        }));
        });
    })));
    }))), Text::lit("\n"));
    auto params_p6 = crate::syntax::lexer::chars::join(run_to_end(each_job(j_p1.fields, ({
        auto cp_p0_1 = cp_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=, cp_p0_1 = std::move(cp_p0_1)](std::tuple<Text, crate::lower::model::OutTy> p0) {
        return ({
            auto cp_p0_1_2 = cp_p0_1;
            entered(once_job([=, cp_p0_1_2 = std::move(cp_p0_1_2)]() {
            return ({
                auto [n_pg, t_ph] = p0;
                call_then(crate::emit::cpp::start_cpp_type(cp_p0_1_2, t_ph), [=](Text cpp_type_27713) { return prism_rtl::finished(prism_rtl::cat(cpp_type_27713, " ", crate::emit::cpp::field_id(n_pg))); });
            });
        }));
        });
    })));
    }))), Text::lit(", "));
    auto inits_p7 = crate::syntax::lexer::chars::join(each(j_p1.fields, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
        auto&& n_pi = std::get<0>(_p0);
        return prism_rtl::cat(crate::emit::cpp::field_id(n_pi), "(std::move(", crate::emit::cpp::field_id(n_pi), "))");
    }), Text::lit(", "));
    auto ctor_p8 = len(j_p1.fields) == Nat(0u)
        ? Text::lit("")
        : prism_rtl::cat(j_p1.name, "(", params_p6, ") : ", inits_p7, " {}");
    auto ret_p9 = crate::emit::cpp::cpp_type(cp_p0, j_p1.ret);
    auto decl_pa = crate::emit::cpp::templates::items::job_struct(cpp_doc(j_p1.doc), gens_p2, j_p1.name, ret_p9, fields_p5, ctor_p8);
    auto cycle_pb = crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat(gens_p2, "prism_rtl::Turn<", ret_p9, "> ", head_p3, "::cycle() const"), crate::emit::cpp::stmts::cpp_body(jcp_p4, j_p1.body));
    auto start_pc = crate::emit::cpp::templates::items::cpp_function(cpp_doc(prism_rtl::cat("`Start ", j_p1.name, ", x`: what the function value is when passed to `@Run`.")), prism_rtl::cat(gens_p2, "prism_rtl::JobRef<", ret_p9, "> ", j_p1.start, "(", params_p6, ")"), prism_rtl::cat("return prism_rtl::make_rc<", head_p3, ">(", crate::syntax::lexer::chars::join(each(j_p1.fields, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
        auto&& n_pj = std::get<0>(_p0);
        return crate::emit::cpp::field_id(n_pj);
    }), Text::lit(", ")), ");"));
    auto generic_pd = len(j_p1.generics) > Nat(0u);
    return Parts{.forward = Array(std::vector{prism_rtl::cat(gens_p2, "struct ", j_p1.name, ";")}), .values = Array<ValueDecl>{}, .protos = Array(std::vector{prism_rtl::cat(gens_p2, "prism_rtl::JobRef<", ret_p9, "> ", j_p1.start, "(", params_p6, ");")}), .classes = Array(std::vector{decl_pa}), .outer = Array<Text>{}, .generic = std::move(generic_pd)
        ? Array(std::vector{cycle_pb, start_pc})
        : Array<Text>{}, .defs = std::move(generic_pd)
        ? Array<Text>{}
        : Array(std::vector{cycle_pb, start_pc})};
}


prism_rtl::Turn<Parts> JobParts::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& j_p1 = this->j_p1;
    auto gens_p2 = cpp_template_head(generic_names_of(prism_rtl::deref(j_p1).generics));
    auto head_p3 = head_of(prism_rtl::deref(j_p1).name, generic_names_of(prism_rtl::deref(j_p1).generics));
    auto jcp_p4 = crate::emit::cpp::with_fields(cp_p0, prism_rtl::deref(j_p1).fields);
    auto cp_p0_1 = cp_p0;
    auto j_p1_2 = j_p1;
    return call_value(each_job(prism_rtl::deref(j_p1_2).fields, ({
        auto cp_p0_1_3 = cp_p0_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=, cp_p0_1_3 = std::move(cp_p0_1_3)](std::tuple<Text, crate::lower::model::OutTy> p0) {
        return ({
            auto cp_p0_1_3_3 = cp_p0_1_3;
            entered(once_job([=, cp_p0_1_3_3 = std::move(cp_p0_1_3_3)]() {
            return ({
                auto [n_pe, t_pf] = p0;
                call_then(crate::emit::cpp::start_cpp_type(cp_p0_1_3_3, t_pf), [=](Text cpp_type_27625) { return prism_rtl::finished(prism_rtl::cat(cpp_type_27625, " ", crate::emit::cpp::field_id(n_pe), ";")); });
            });
        }));
        });
    })));
    })), [=](Array<Text> each_27596) {
        return ({
            auto fields_p5 = crate::syntax::lexer::chars::join(each_27596, Text::lit("\n"));
            call_value(each_job(prism_rtl::deref(j_p1_2).fields, ({
            auto cp_p0_1_3 = cp_p0_1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=, cp_p0_1_3 = std::move(cp_p0_1_3)](std::tuple<Text, crate::lower::model::OutTy> p0) {
            return ({
                auto cp_p0_1_3_3 = cp_p0_1_3;
                entered(once_job([=, cp_p0_1_3_3 = std::move(cp_p0_1_3_3)]() {
                return ({
                    auto [n_pg, t_ph] = p0;
                    call_then(crate::emit::cpp::start_cpp_type(cp_p0_1_3_3, t_ph), [=](Text cpp_type_27713) { return prism_rtl::finished(prism_rtl::cat(cpp_type_27713, " ", crate::emit::cpp::field_id(n_pg))); });
                });
            }));
            });
        })));
        })), [=, fields_p5 = std::move(fields_p5)](Array<Text> each_27684) {
            return ({
                auto params_p6 = crate::syntax::lexer::chars::join(each_27684, Text::lit(", "));
                auto inits_p7 = crate::syntax::lexer::chars::join(each(prism_rtl::deref(j_p1_2).fields, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
                    auto&& n_pi = std::get<0>(_p0);
                    return prism_rtl::cat(crate::emit::cpp::field_id(n_pi), "(std::move(", crate::emit::cpp::field_id(n_pi), "))");
                }), Text::lit(", "));
                auto ctor_p8 = len(prism_rtl::deref(j_p1_2).fields) == Nat(0u)
                    ? Text::lit("")
                    : prism_rtl::cat(prism_rtl::deref(j_p1_2).name, "(", params_p6, ") : ", inits_p7, " {}");
                call_then(crate::emit::cpp::start_cpp_type(cp_p0_1, prism_rtl::deref(j_p1_2).ret), [=, params_p6 = std::move(params_p6), ctor_p8 = std::move(ctor_p8)](Text cpp_type_27945) {
                return ({
                    auto ret_p9 = cpp_type_27945;
                    auto decl_pa = crate::emit::cpp::templates::items::job_struct(cpp_doc(prism_rtl::deref(j_p1_2).doc), gens_p2, prism_rtl::deref(j_p1_2).name, ret_p9, fields_p5, ctor_p8);
                    call_then(crate::emit::cpp::stmts::start_cpp_body(jcp_p4, prism_rtl::deref(j_p1_2).body), [=, ret_p9 = std::move(ret_p9), decl_pa = std::move(decl_pa)](Text cpp_body_28123) {
                    return ({
                        auto cycle_pb = crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat(gens_p2, "prism_rtl::Turn<", ret_p9, "> ", head_p3, "::cycle() const"), cpp_body_28123);
                        auto start_pc = crate::emit::cpp::templates::items::cpp_function(cpp_doc(prism_rtl::cat("`Start ", prism_rtl::deref(j_p1_2).name, ", x`: what the function value is when passed to `@Run`.")), prism_rtl::cat(gens_p2, "prism_rtl::JobRef<", ret_p9, "> ", prism_rtl::deref(j_p1_2).start, "(", params_p6, ")"), prism_rtl::cat("return prism_rtl::make_rc<", head_p3, ">(", crate::syntax::lexer::chars::join(each(prism_rtl::deref(j_p1_2).fields, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
                            auto&& n_pj = std::get<0>(_p0);
                            return crate::emit::cpp::field_id(n_pj);
                        }), Text::lit(", ")), ");"));
                        auto generic_pd = len(prism_rtl::deref(j_p1_2).generics) > Nat(0u);
                        (prism_rtl::finished(Parts{.forward = Array(std::vector{prism_rtl::cat(gens_p2, "struct ", prism_rtl::deref(j_p1_2).name, ";")}), .values = Array<ValueDecl>{}, .protos = Array(std::vector{prism_rtl::cat(gens_p2, "prism_rtl::JobRef<", ret_p9, "> ", prism_rtl::deref(j_p1_2).start, "(", params_p6, ");")}), .classes = Array(std::vector{decl_pa}), .outer = Array<Text>{}, .generic = std::move(generic_pd)
                        ? Array(std::vector{cycle_pb, start_pc})
                        : Array<Text>{}, .defs = std::move(generic_pd)
                        ? Array<Text>{}
                        : Array(std::vector{cycle_pb, start_pc})}));
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start JobParts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Parts> start_job_parts(crate::emit::cpp::Cp cp_p0, crate::lower::model::JobDef j_p1) {
    return prism_rtl::make_rc<JobParts>(cp_p0, j_p1);
}


/// TraitParts: unbounded fn Cp, TraitDef -> Parts
Parts trait_parts(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::TraitDef& t_p1) {
    auto defaults_p2 = filter(t_p1.methods, [&](const crate::lower::model::FnDef& f_p6) { return prism_rtl::deref(f_p6).public_; });
    auto defs_p3 = run_to_end(each_job(defaults_p2, ({
        auto cp_p0_1 = cp_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::FnDef)>>(prism_rtl::rc([=, cp_p0_1 = std::move(cp_p0_1)](crate::lower::model::FnDef p0) {
        return ({
            auto cp_p0_1_2 = cp_p0_1;
            entered(once_job([=, cp_p0_1_2 = std::move(cp_p0_1_2)]() {
            return ({
                auto f_p7 = p0;
                (prism_rtl::more(prism_rtl::rc(FnDefinition(cp_p0_1_2, with_generics(f_p7, Array(std::vector{std::tuple{Text::lit("Self"), Array<Text>{}}}))))));
            });
        }));
        });
    })));
    })));
    auto protos_p4 = run_to_end(each_job(t_p1.methods, ({
        auto cp_p0_1 = cp_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::FnDef)>>(prism_rtl::rc([=, cp_p0_1 = std::move(cp_p0_1)](crate::lower::model::FnDef p0) {
        return ({
            auto cp_p0_1_2 = cp_p0_1;
            entered(once_job([=, cp_p0_1_2 = std::move(cp_p0_1_2)]() {
            return ({
                auto f_p8 = p0;
                call_then(start_fn_signature(cp_p0_1_2, with_generics(f_p8, Array(std::vector{std::tuple{Text::lit("Self"), Array<Text>{}}}))), [=](Text fn_signature_29363) { return prism_rtl::finished(prism_rtl::cat(fn_signature_29363, prism_rtl::deref(f_p8).public_ ? Text::lit("") : Text::lit(" = delete"), ";")); });
            });
        }));
        });
    })));
    })));
    auto generic_p5 = len(defaults_p2) == Nat(0u)
        ? Array<Text>{}
        : Array(std::vector{crate::emit::cpp::templates::items::trait_namespace(t_p1.name, crate::syntax::lexer::chars::join(defs_p3, Text::lit("\n")))});
    Parts this_ = generic_only(generic_p5);
    this_.protos = Array(std::vector{crate::emit::cpp::templates::items::trait_namespace(t_p1.name, crate::syntax::lexer::chars::join(protos_p4, Text::lit("\n")))});
    return this_;
}


prism_rtl::Turn<Parts> TraitParts::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& t_p1 = this->t_p1;
    auto defaults_p2 = filter(prism_rtl::deref(t_p1).methods, [&](const crate::lower::model::FnDef& f_p6) { return prism_rtl::deref(f_p6).public_; });
    auto cp_p0_1 = cp_p0;
    auto t_p1_2 = t_p1;
    return call_value(each_job(defaults_p2, ({
        auto cp_p0_1_3 = cp_p0_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::FnDef)>>(prism_rtl::rc([=, cp_p0_1_3 = std::move(cp_p0_1_3)](crate::lower::model::FnDef p0) {
        return ({
            auto cp_p0_1_3_3 = cp_p0_1_3;
            entered(once_job([=, cp_p0_1_3_3 = std::move(cp_p0_1_3_3)]() {
            return ({
                auto f_p7 = p0;
                (prism_rtl::more(prism_rtl::rc(FnDefinition(cp_p0_1_3_3, with_generics(f_p7, Array(std::vector{std::tuple{Text::lit("Self"), Array<Text>{}}}))))));
            });
        }));
        });
    })));
    })), [=](Array<Text> each_29247) {
        return ({
            auto defs_p3 = each_29247;
            call_value(each_job(prism_rtl::deref(t_p1_2).methods, ({
            auto cp_p0_1_3 = cp_p0_1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::FnDef)>>(prism_rtl::rc([=, cp_p0_1_3 = std::move(cp_p0_1_3)](crate::lower::model::FnDef p0) {
            return ({
                auto cp_p0_1_3_3 = cp_p0_1_3;
                entered(once_job([=, cp_p0_1_3_3 = std::move(cp_p0_1_3_3)]() {
                return ({
                    auto f_p8 = p0;
                    call_then(start_fn_signature(cp_p0_1_3_3, with_generics(f_p8, Array(std::vector{std::tuple{Text::lit("Self"), Array<Text>{}}}))), [=](Text fn_signature_29363) { return prism_rtl::finished(prism_rtl::cat(fn_signature_29363, prism_rtl::deref(f_p8).public_ ? Text::lit("") : Text::lit(" = delete"), ";")); });
                });
            }));
            });
        })));
        })), [=, defs_p3 = std::move(defs_p3)](Array<Text> each_29340) {
            return ({
                auto protos_p4 = each_29340;
                auto generic_p5 = len(defaults_p2) == Nat(0u)
                    ? Array<Text>{}
                    : Array(std::vector{crate::emit::cpp::templates::items::trait_namespace(prism_rtl::deref(t_p1_2).name, crate::syntax::lexer::chars::join(defs_p3, Text::lit("\n")))});
                (prism_rtl::finished(({
                Parts this_ = generic_only(generic_p5);
                this_.protos = Array(std::vector{crate::emit::cpp::templates::items::trait_namespace(prism_rtl::deref(t_p1_2).name, crate::syntax::lexer::chars::join(protos_p4, Text::lit("\n")))});
                (std::move(this_));
            })));
            });
        });
        });
    });
}


/// `Start TraitParts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Parts> start_trait_parts(crate::emit::cpp::Cp cp_p0, crate::lower::model::TraitDef t_p1) {
    return prism_rtl::make_rc<TraitParts>(cp_p0, t_p1);
}


/// ImplParts: unbounded fn Cp, ImplDef -> Parts
Parts impl_parts(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::ImplDef& i_p1) {
    auto head_p2 = crate::emit::cpp::cpp_type(cp_p0, i_p1.head);
    auto gens_p3 = cpp_template_head(generic_names_of(i_p1.generics));
    auto fns_p4 = run_to_end(each_job(i_p1.methods, ({
        auto cp_p0_1 = cp_p0;
        auto i_p1_2 = i_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Parts>(crate::lower::model::FnDef)>>(prism_rtl::rc([=, cp_p0_1 = std::move(cp_p0_1), i_p1_2 = std::move(i_p1_2)](crate::lower::model::FnDef p0) {
        return ({
            auto cp_p0_1_3 = cp_p0_1;
            auto i_p1_2_3 = i_p1_2;
            entered(once_job([=, cp_p0_1_3 = std::move(cp_p0_1_3), i_p1_2_3 = std::move(i_p1_2_3)]() {
            return ({
                auto f_p6 = p0;
                (prism_rtl::more(prism_rtl::rc(FnParts(cp_p0_1_3, with_generics(f_p6, i_p1_2_3.generics)))));
            });
        }));
        });
    })));
    })));
    auto own_p5 = fold(fns_p4, no_parts(), [&](const Parts& acc_p7, const Parts& p_p8) { return join_parts(acc_p7, p_p8); });
    auto&& _m = i_p1.cls;
    {
        auto&& m30350_0 = _m;
        if (m30350_0 == Text::lit("Prelude.Show")) {
            auto shown_p9 = or_(index(each(i_p1.methods, [&](const crate::lower::model::FnDef& f_pa) { return prism_rtl::deref(f_pa).name; }), Nat(0u)), Text::lit("show"));
            return join_parts(own_p5, protos_defs(Array<Text>{}, Array(std::vector{crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat(gens_p3, "void ", head_p2, "::show(Printer& p) const"), prism_rtl::cat("p.raw(", shown_p9, "(*this).to_string());"))})));
        }
    }
    {
        auto&& m30350_1 = _m;
        if (m30350_1 == Text::lit("Prelude.Eq")) {
            auto eq_pb = fold(i_p1.methods, Text::lit(""), [&](const Text& acc_pc, const crate::lower::model::FnDef& f_pd) {
                return (!crate::syntax::lexer::chars::has_prefix(prism_rtl::deref(f_pd).name, Text::lit("ne"))) && (acc_pc == Text::lit(""))
                    ? prism_rtl::deref(f_pd).name
                    : acc_pc;
            });
            return join_parts(own_p5, protos_defs(Array(std::vector{prism_rtl::cat(gens_p3, "bool operator==(const ", head_p2, "& a, const ", head_p2, "& b);")}), Array(std::vector{crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat(gens_p3, "bool operator==(const ", head_p2, "& a, const ", head_p2, "& b)"), prism_rtl::cat("return ", eq_pb, "(a, b);"))})));
        }
    }
    {
        auto tr_pe = crate::syntax::lexer::chars::drop_prefix(crate::emit::cpp::type_path(i_p1.tr), Text::lit("crate::"));
        auto own_pf = !crate::syntax::lexer::chars::contains(tr_pe, Text::lit("::"));
        auto ns_pg = std::move(own_pf)
            ? tr_pe
            : prism_rtl::cat("impl_", crate::syntax::lexer::chars::join(split_on(tr_pe, Text::lit("::")), Text::lit("_")));
        auto in_trait_ph = run_to_end(each_job(i_p1.methods, ({
            auto ns_pg_1 = ns_pg;
            auto cp_p0_2 = cp_p0;
            auto i_p1_3 = i_p1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::FnDef)>>(prism_rtl::rc([=, ns_pg_1 = std::move(ns_pg_1), cp_p0_2 = std::move(cp_p0_2), i_p1_3 = std::move(i_p1_3)](crate::lower::model::FnDef p0) {
            return ({
                auto ns_pg_1_4 = ns_pg_1;
                auto cp_p0_2_4 = cp_p0_2;
                auto i_p1_3_4 = i_p1_3;
                entered(once_job([=, ns_pg_1_4 = std::move(ns_pg_1_4), cp_p0_2_4 = std::move(cp_p0_2_4), i_p1_3_4 = std::move(i_p1_3_4)]() {
                return ({
                    auto f_pk = p0;
                    call_then(start_fn_definition(cp_p0_2_4, with_generics(f_pk, i_p1_3_4.generics)), [=](Text fn_definition_31217) { return prism_rtl::finished(crate::emit::cpp::templates::items::trait_namespace(ns_pg_1_4, fn_definition_31217)); });
                });
            }));
            });
        })));
        })));
        auto protos_pi = run_to_end(each_job(i_p1.methods, ({
            auto ns_pg_1 = ns_pg;
            auto cp_p0_2 = cp_p0;
            auto i_p1_3 = i_p1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::FnDef)>>(prism_rtl::rc([=, ns_pg_1 = std::move(ns_pg_1), cp_p0_2 = std::move(cp_p0_2), i_p1_3 = std::move(i_p1_3)](crate::lower::model::FnDef p0) {
            return ({
                auto ns_pg_1_4 = ns_pg_1;
                auto cp_p0_2_4 = cp_p0_2;
                auto i_p1_3_4 = i_p1_3;
                entered(once_job([=, ns_pg_1_4 = std::move(ns_pg_1_4), cp_p0_2_4 = std::move(cp_p0_2_4), i_p1_3_4 = std::move(i_p1_3_4)]() {
                return ({
                    auto f_pl = p0;
                    call_then(start_fn_signature(cp_p0_2_4, with_generics(f_pl, i_p1_3_4.generics)), [=](Text fn_signature_31331) { return prism_rtl::finished(crate::emit::cpp::templates::items::trait_namespace(ns_pg_1_4, prism_rtl::cat(fn_signature_31331, ";"))); });
                });
            }));
            });
        })));
        })));
        auto outer_pj = std::move(own_pf)
            ? Array<Text>{}
            : Array(std::vector{crate::emit::cpp::templates::items::trait_namespace(tr_pe, crate::syntax::lexer::chars::join(each(i_p1.methods, [&](const crate::lower::model::FnDef& f_pm) { return prism_rtl::cat("using ::crate::", cp_p0.home, "::", ns_pg, "::", crate::emit::cpp::cpp_id(prism_rtl::deref(f_pm).name), ";"); }), Text::lit("\n")))});
        Parts this_ = protos_defs(protos_pi, in_trait_ph);
        this_.outer = outer_pj;
        return this_;
    }
}


prism_rtl::Turn<Parts> ImplParts::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& i_p1 = this->i_p1;
    auto cp_p0_1 = cp_p0;
    auto i_p1_2 = i_p1;
    return call_then(crate::emit::cpp::start_cpp_type(cp_p0_1, prism_rtl::deref(i_p1_2).head), [=](Text cpp_type_30132) {
        return ({
            auto head_p2 = cpp_type_30132;
            auto gens_p3 = cpp_template_head(generic_names_of(prism_rtl::deref(i_p1_2).generics));
            call_value(each_job(prism_rtl::deref(i_p1_2).methods, ({
            auto cp_p0_1_3 = cp_p0_1;
            auto i_p1_2_3 = i_p1_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Parts>(crate::lower::model::FnDef)>>(prism_rtl::rc([=, cp_p0_1_3 = std::move(cp_p0_1_3), i_p1_2_3 = std::move(i_p1_2_3)](crate::lower::model::FnDef p0) {
            return ({
                auto cp_p0_1_3_3 = cp_p0_1_3;
                auto i_p1_2_3_3 = i_p1_2_3;
                entered(once_job([=, cp_p0_1_3_3 = std::move(cp_p0_1_3_3), i_p1_2_3_3 = std::move(i_p1_2_3_3)]() {
                return ({
                    auto f_p6 = p0;
                    (prism_rtl::more(prism_rtl::rc(FnParts(cp_p0_1_3_3, with_generics(f_p6, prism_rtl::deref(i_p1_2_3_3).generics)))));
                });
            }));
            });
        })));
        })), [=, head_p2 = std::move(head_p2), gens_p3 = std::move(gens_p3)](Array<Parts> each_30224) {
            return ({
                auto fns_p4 = each_30224;
                auto own_p5 = fold(fns_p4, no_parts(), [&](const Parts& acc_p7, const Parts& p_p8) { return join_parts(acc_p7, p_p8); });
                ({
                auto&& _m = prism_rtl::deref(i_p1_2).cls;
                ({
                auto&& m30350_0 = _m;
                (m30350_0 == Text::lit("Prelude.Show"));
            }) ? ({
                auto&& m30350_0 = _m;
                ({
                auto shown_p9 = or_(index(each(prism_rtl::deref(i_p1_2).methods, [&](const crate::lower::model::FnDef& f_pa) { return prism_rtl::deref(f_pa).name; }), Nat(0u)), Text::lit("show"));
                (prism_rtl::finished(join_parts(own_p5, protos_defs(Array<Text>{}, Array(std::vector{crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat(gens_p3, "void ", head_p2, "::show(Printer& p) const"), prism_rtl::cat("p.raw(", shown_p9, "(*this).to_string());"))})))));
            });
            })
                : ({
                auto&& m30350_1 = _m;
                (m30350_1 == Text::lit("Prelude.Eq"));
            }) ? ({
                auto&& m30350_1 = _m;
                ({
                auto eq_pb = fold(prism_rtl::deref(i_p1_2).methods, Text::lit(""), [&](const Text& acc_pc, const crate::lower::model::FnDef& f_pd) {
                    return (!crate::syntax::lexer::chars::has_prefix(prism_rtl::deref(f_pd).name, Text::lit("ne"))) && (acc_pc == Text::lit(""))
                        ? prism_rtl::deref(f_pd).name
                        : acc_pc;
                });
                (prism_rtl::finished(join_parts(own_p5, protos_defs(Array(std::vector{prism_rtl::cat(gens_p3, "bool operator==(const ", head_p2, "& a, const ", head_p2, "& b);")}), Array(std::vector{crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat(gens_p3, "bool operator==(const ", head_p2, "& a, const ", head_p2, "& b)"), prism_rtl::cat("return ", eq_pb, "(a, b);"))})))));
            });
            })
                : ({
                auto tr_pe = crate::syntax::lexer::chars::drop_prefix(crate::emit::cpp::type_path(prism_rtl::deref(i_p1_2).tr), Text::lit("crate::"));
                auto own_pf = !crate::syntax::lexer::chars::contains(tr_pe, Text::lit("::"));
                auto ns_pg = std::move(own_pf)
                    ? tr_pe
                    : prism_rtl::cat("impl_", crate::syntax::lexer::chars::join(split_on(tr_pe, Text::lit("::")), Text::lit("_")));
                call_value(each_job(prism_rtl::deref(i_p1_2).methods, ({
                auto ns_pg_3 = ns_pg;
                auto cp_p0_1_4 = cp_p0_1;
                auto i_p1_2_4 = i_p1_2;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::FnDef)>>(prism_rtl::rc([=, ns_pg_3 = std::move(ns_pg_3), cp_p0_1_4 = std::move(cp_p0_1_4), i_p1_2_4 = std::move(i_p1_2_4)](crate::lower::model::FnDef p0) {
                return ({
                    auto ns_pg_3_4 = ns_pg_3;
                    auto cp_p0_1_4_4 = cp_p0_1_4;
                    auto i_p1_2_4_4 = i_p1_2_4;
                    entered(once_job([=, ns_pg_3_4 = std::move(ns_pg_3_4), cp_p0_1_4_4 = std::move(cp_p0_1_4_4), i_p1_2_4_4 = std::move(i_p1_2_4_4)]() {
                    return ({
                        auto f_pk = p0;
                        call_then(start_fn_definition(cp_p0_1_4_4, with_generics(f_pk, prism_rtl::deref(i_p1_2_4_4).generics)), [=](Text fn_definition_31217) { return prism_rtl::finished(crate::emit::cpp::templates::items::trait_namespace(ns_pg_3_4, fn_definition_31217)); });
                    });
                }));
                });
            })));
            })), [=, tr_pe = std::move(tr_pe), own_pf = std::move(own_pf)](Array<Text> each_31176) {
                return ({
                    auto in_trait_ph = each_31176;
                    call_value(each_job(prism_rtl::deref(i_p1_2).methods, ({
                    auto ns_pg_3 = ns_pg;
                    auto cp_p0_1_4 = cp_p0_1;
                    auto i_p1_2_4 = i_p1_2;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::FnDef)>>(prism_rtl::rc([=, ns_pg_3 = std::move(ns_pg_3), cp_p0_1_4 = std::move(cp_p0_1_4), i_p1_2_4 = std::move(i_p1_2_4)](crate::lower::model::FnDef p0) {
                    return ({
                        auto ns_pg_3_4 = ns_pg_3;
                        auto cp_p0_1_4_4 = cp_p0_1_4;
                        auto i_p1_2_4_4 = i_p1_2_4;
                        entered(once_job([=, ns_pg_3_4 = std::move(ns_pg_3_4), cp_p0_1_4_4 = std::move(cp_p0_1_4_4), i_p1_2_4_4 = std::move(i_p1_2_4_4)]() {
                        return ({
                            auto f_pl = p0;
                            call_then(start_fn_signature(cp_p0_1_4_4, with_generics(f_pl, prism_rtl::deref(i_p1_2_4_4).generics)), [=](Text fn_signature_31331) { return prism_rtl::finished(crate::emit::cpp::templates::items::trait_namespace(ns_pg_3_4, prism_rtl::cat(fn_signature_31331, ";"))); });
                        });
                    }));
                    });
                })));
                })), [=, in_trait_ph = std::move(in_trait_ph)](Array<Text> each_31289) {
                    return ({
                        auto protos_pi = each_31289;
                        auto outer_pj = own_pf
                            ? Array<Text>{}
                            : Array(std::vector{crate::emit::cpp::templates::items::trait_namespace(tr_pe, crate::syntax::lexer::chars::join(each(prism_rtl::deref(i_p1_2).methods, [&](const crate::lower::model::FnDef& f_pm) { return prism_rtl::cat("using ::crate::", prism_rtl::deref(cp_p0_1).home, "::", ns_pg, "::", crate::emit::cpp::cpp_id(prism_rtl::deref(f_pm).name), ";"); }), Text::lit("\n")))});
                        (prism_rtl::finished(({
                        Parts this_ = protos_defs(protos_pi, in_trait_ph);
                        this_.outer = outer_pj;
                        (std::move(this_));
                    })));
                    });
                });
                });
            });
            });
            });
            });
        });
        });
    });
}


/// `Start ImplParts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Parts> start_impl_parts(crate::emit::cpp::Cp cp_p0, crate::lower::model::ImplDef i_p1) {
    return prism_rtl::make_rc<ImplParts>(cp_p0, i_p1);
}


/// WithGenerics: fn FnDef, [((Text, [Text]))] -> FnDef
crate::lower::model::FnDef with_generics(const crate::lower::model::FnDef& f_p0, const Array<std::tuple<Text, Array<Text>>>& gs_p1) {
    crate::lower::model::FnDef this_ = f_p0;
    this_.generics = append(gs_p1, this_.generics);
    return this_;
}


/// GenericOnly: fn [Text] -> Parts
Parts generic_only(const Array<Text>& xs_p0) {
    Parts this_ = no_parts();
    this_.generic = xs_p0;
    return this_;
}


/// ProtosDefs: fn [Text], [Text] -> Parts
Parts protos_defs(const Array<Text>& ps_p0, const Array<Text>& ds_p1) {
    Parts this_ = no_parts();
    this_.protos = ps_p0;
    this_.defs = ds_p1;
    return this_;
}

}  // namespace crate::emit::cpp::items
