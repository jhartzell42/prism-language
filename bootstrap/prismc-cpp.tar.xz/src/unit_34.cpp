// The modules `Emit.Cpp.Stmts`, `Emit.Cpp.Templates`, `Emit.Cpp.Templates.Items`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <emit/cpp/stmts/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Emit.Cpp.Stmts`, from `target/bootstrap/cpp-src/prismc/emit/cpp/stmts.prism`.
namespace crate::emit::cpp::stmts {

/// CppStatements: unbounded fn Cp, [Do] -> Text
Text cpp_statements(const crate::emit::cpp::Cp& cp, const Array<crate::lower::model::Do>& dos) {
    auto&& _st = cpp_statements_cp(cp, dos);
    auto&& st = std::get<0>(_st);
    return st;
}


prism_rtl::Turn<Text> CppStatements::cycle() const {
    const auto& cp = this->cp;
    const auto& dos = this->dos;
    auto cp_1 = cp;
    auto dos_2 = dos;
    return call_then(start_cpp_statements_cp(cp_1, dos_2), [=](std::tuple<Text, crate::emit::cpp::Cp> cpp_statements_cp_1153) {
        return ({
            auto&& _st = cpp_statements_cp_1153;
            auto&& st = std::get<0>(_st);
            (prism_rtl::finished(st));
        });
    });
}


/// `Start CppStatements, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_statements(crate::emit::cpp::Cp cp, Array<crate::lower::model::Do> dos) {
    return prism_rtl::make_rc<CppStatements>(cp, dos);
}


/// CppStatementsCp: unbounded fn Cp, [Do] -> ((Text, Cp))
std::tuple<Text, crate::emit::cpp::Cp> cpp_statements_cp(const crate::emit::cpp::Cp& cp, const Array<crate::lower::model::Do>& dos) {
    auto [lines, last] = run_to_end(fold_job(dos, std::tuple{Array<Text>{}, cp}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, crate::emit::cpp::Cp>>(std::tuple<std::tuple<Array<Text>, crate::emit::cpp::Cp>, crate::lower::model::Do>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<Text>, crate::emit::cpp::Cp>, crate::lower::model::Do> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto [acc, c] = p0;
                auto d = p1;
                call_then(start_rebound(c, d), [=](crate::emit::cpp::Cp rebound_1580) {
                return ({
                    auto c2 = rebound_1580;
                    auto line = ({
                        __label__ _done;
                        prism_rtl::Slot<Text> _v;
                        if (prism_rtl::is<crate::lower::model::Do::DoLet>(d)) {
                            auto&& p_ = prism_rtl::as<crate::lower::model::Do::DoLet>(d).a0;
                            auto&& x = prism_rtl::as<crate::lower::model::Do::DoLet>(d).a1;
                            _v.set(cpp_let(c, c2, p_, x));
                            goto _done;
                        }
                        {
                            _v.set(cpp_statement(c2, d));
                            goto _done;
                        }
                    _done:
                        _v.take();
                    });
                    (prism_rtl::finished(std::tuple{crate::prelude::push(acc, line), c2}));
                });
            });
            });
        }));
    }))));
    return std::tuple{crate::syntax::lexer::chars::join(lines, Text::lit("\n")), last};
}


prism_rtl::Turn<std::tuple<Text, crate::emit::cpp::Cp>> CppStatementsCp::cycle() const {
    const auto& cp = this->cp;
    const auto& dos = this->dos;
    auto cp_1 = cp;
    auto dos_2 = dos;
    return call_value(fold_job(dos_2, std::tuple{Array<Text>{}, cp_1}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, crate::emit::cpp::Cp>>(std::tuple<std::tuple<Array<Text>, crate::emit::cpp::Cp>, crate::lower::model::Do>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<Text>, crate::emit::cpp::Cp>, crate::lower::model::Do> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto [acc, c] = p0;
                auto d = p1;
                call_then(start_rebound(c, d), [=](crate::emit::cpp::Cp rebound_1580) {
                return ({
                    auto c2 = rebound_1580;
                    auto line = ({
                        __label__ _done;
                        prism_rtl::Slot<Text> _v;
                        if (prism_rtl::is<crate::lower::model::Do::DoLet>(d)) {
                            auto&& p_ = prism_rtl::as<crate::lower::model::Do::DoLet>(d).a0;
                            auto&& x = prism_rtl::as<crate::lower::model::Do::DoLet>(d).a1;
                            _v.set(cpp_let(c, c2, p_, x));
                            goto _done;
                        }
                        {
                            _v.set(cpp_statement(c2, d));
                            goto _done;
                        }
                    _done:
                        _v.take();
                    });
                    (prism_rtl::finished(std::tuple{crate::prelude::push(acc, line), c2}));
                });
            });
            });
        }));
    }))), [=](std::tuple<Array<Text>, crate::emit::cpp::Cp> fold_1522) {
        return ({
            auto [lines, last] = fold_1522;
            (prism_rtl::finished(std::tuple{crate::syntax::lexer::chars::join(lines, Text::lit("\n")), last}));
        });
    });
}


/// `Start CppStatementsCp, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Text, crate::emit::cpp::Cp>> start_cpp_statements_cp(crate::emit::cpp::Cp cp, Array<crate::lower::model::Do> dos) {
    return prism_rtl::make_rc<CppStatementsCp>(cp, dos);
}


/// Unvexed: fn Text -> Text
Text unvexed(const Text& t) {
    auto head = or_(index(split_on(t, Text::lit("(")), Nat(0u)), Text::lit(""));
    auto type_like = crate::syntax::lexer::chars::contains(head, Text::lit(":")) || crate::syntax::lexer::chars::contains(Text::lit("ABCDEFGHIJKLMNOPQRSTUVWXYZ"), crate::syntax::lexer::chars::head(head));
    auto vexing = (((crate::syntax::lexer::chars::last_char(t) == Text::lit(")")) && (!crate::syntax::lexer::chars::contains(head, Text::lit(" ")))) && (head != Text::lit(""))) && std::move(type_like);
    return std::move(vexing) ? prism_rtl::cat("(", t, ")") : t;
}


/// Rebound: unbounded fn Cp, Do -> Cp
crate::emit::cpp::Cp rebound(const crate::emit::cpp::Cp& cp, const crate::lower::model::Do& d) {
    if (prism_rtl::is<crate::lower::model::Do::DoLetElse>(d)) {
        auto&& p_ = prism_rtl::as<crate::lower::model::Do::DoLetElse>(d).a0;
        return unbind(cp, pat_names(p_));
    }
    if (prism_rtl::is<crate::lower::model::Do::DoLet>(d) && prism_rtl::is<crate::lower::model::Pa::PaTuple>(prism_rtl::as<crate::lower::model::Do::DoLet>(d).a0)) {
        auto&& ps = prism_rtl::as<crate::lower::model::Pa::PaTuple>(prism_rtl::as<crate::lower::model::Do::DoLet>(d).a0).a0;
        return unbind(cp, pat_names(crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{ps})));
    }
    if (prism_rtl::is<crate::lower::model::Do::DoLet>(d) && prism_rtl::is<crate::lower::model::Pa::PaCtor>(prism_rtl::as<crate::lower::model::Do::DoLet>(d).a0)) {
        auto&& c = prism_rtl::as<crate::lower::model::Pa::PaCtor>(prism_rtl::as<crate::lower::model::Do::DoLet>(d).a0).a0;
        auto&& ps = prism_rtl::as<crate::lower::model::Pa::PaCtor>(prism_rtl::as<crate::lower::model::Do::DoLet>(d).a0).a1;
        return unbind(cp, pat_names(crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{c, ps})));
    }
    if (prism_rtl::is<crate::lower::model::Do::DoLet>(d) && prism_rtl::is<crate::lower::model::Pa::PaRecord>(prism_rtl::as<crate::lower::model::Do::DoLet>(d).a0)) {
        auto&& c = prism_rtl::as<crate::lower::model::Pa::PaRecord>(prism_rtl::as<crate::lower::model::Do::DoLet>(d).a0).a0;
        auto&& fs = prism_rtl::as<crate::lower::model::Pa::PaRecord>(prism_rtl::as<crate::lower::model::Do::DoLet>(d).a0).a1;
        auto&& r = prism_rtl::as<crate::lower::model::Pa::PaRecord>(prism_rtl::as<crate::lower::model::Do::DoLet>(d).a0).a2;
        return unbind(cp, pat_names(crate::lower::model::Pa(crate::lower::model::Pa::PaRecord{c, fs, prism_rtl::deref(r)})));
    }
    if (prism_rtl::is<crate::lower::model::Do::DoLet>(d)) {
        auto&& p_ = prism_rtl::as<crate::lower::model::Do::DoLet>(d).a0;
        auto&& x = prism_rtl::as<crate::lower::model::Do::DoLet>(d).a1;
        auto&& _m = let_name(p_);
        if (prism_rtl::is_some(_m)) {
            auto&& n = prism_rtl::some_of(_m);
            auto pointing_ = is_pointer_let(cp, p_, x) ? pointing(cp, n) : known_value(cp, p_, n);
            auto held = is_value_let(p_, x) ? owning(pointing_, n) : disowning(pointing_, n);
            auto holding = ({
                __label__ _done;
                prism_rtl::Slot<crate::emit::cpp::Cp> _v;
                if (prism_rtl::is<crate::lower::model::Pa::PaTyped>(p_)) {
                    auto&& t = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_).a1;
                    _v.set(({
                        crate::emit::cpp::Cp this_ = held;
                        this_.local_types = insert(this_.local_types, n, t);
                        (std::move(this_));
                    }));
                    goto _done;
                }
                {
                    _v.set(({
                        crate::emit::cpp::Cp this_ = held;
                        this_.local_types = crate::prelude::remove(this_.local_types, n);
                        (std::move(this_));
                    }));
                    goto _done;
                }
            _done:
                _v.take();
            });
            return cpp_mentions(crate::emit::cpp::expr::cpp_expr(cp, x), var_name(cp, n))
                ? ({
                auto fresh = prism_rtl::cat(var_name(cp, n), "_", inc(len(keys(cp.renames))));
                ({
                crate::emit::cpp::Cp this_ = holding;
                this_.renames = insert(this_.renames, n, fresh);
                (std::move(this_));
            });
            })
                : holding;
        }
        if (prism_rtl::is_none(_m)) {
            return cp;
        }
        prism_rtl::unreachable("no arm matched");
    }
    {
        return cp;
    }
}


prism_rtl::Turn<crate::emit::cpp::Cp> Rebound::cycle() const {
    const auto& cp = this->cp;
    const auto& d = this->d;
    return ({
        prism_rtl::is<crate::lower::model::Do::DoLetElse>(d) ? ({
        auto&& p_ = prism_rtl::as<crate::lower::model::Do::DoLetElse>(d).a0;
        ({
        auto cp_1 = cp;
        auto p__2 = p_;
        call_then(start_pat_names(p__2), [=, cp_1 = std::move(cp_1)](Array<Text> pat_names_2376) { return prism_rtl::finished(unbind(cp_1, pat_names_2376)); });
    });
    })
        : prism_rtl::is<crate::lower::model::Do::DoLet>(d) && prism_rtl::is<crate::lower::model::Pa::PaTuple>(prism_rtl::as<crate::lower::model::Do::DoLet>(d).a0) ? ({
        auto&& ps = prism_rtl::as<crate::lower::model::Pa::PaTuple>(prism_rtl::as<crate::lower::model::Do::DoLet>(d).a0).a0;
        ({
        auto cp_1 = cp;
        auto ps_2 = ps;
        call_then(start_pat_names(crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{ps_2})), [=, cp_1 = std::move(cp_1)](Array<Text> pat_names_2432) { return prism_rtl::finished(unbind(cp_1, pat_names_2432)); });
    });
    })
        : prism_rtl::is<crate::lower::model::Do::DoLet>(d) && prism_rtl::is<crate::lower::model::Pa::PaCtor>(prism_rtl::as<crate::lower::model::Do::DoLet>(d).a0) ? ({
        auto&& c = prism_rtl::as<crate::lower::model::Pa::PaCtor>(prism_rtl::as<crate::lower::model::Do::DoLet>(d).a0).a0;
        auto&& ps = prism_rtl::as<crate::lower::model::Pa::PaCtor>(prism_rtl::as<crate::lower::model::Do::DoLet>(d).a0).a1;
        ({
        auto c_1 = c;
        auto cp_2 = cp;
        auto ps_3 = ps;
        call_then(start_pat_names(crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{c_1, ps_3})), [=, cp_2 = std::move(cp_2)](Array<Text> pat_names_2501) { return prism_rtl::finished(unbind(cp_2, pat_names_2501)); });
    });
    })
        : prism_rtl::is<crate::lower::model::Do::DoLet>(d) && prism_rtl::is<crate::lower::model::Pa::PaRecord>(prism_rtl::as<crate::lower::model::Do::DoLet>(d).a0) ? ({
        auto&& c = prism_rtl::as<crate::lower::model::Pa::PaRecord>(prism_rtl::as<crate::lower::model::Do::DoLet>(d).a0).a0;
        auto&& fs = prism_rtl::as<crate::lower::model::Pa::PaRecord>(prism_rtl::as<crate::lower::model::Do::DoLet>(d).a0).a1;
        auto&& r = prism_rtl::as<crate::lower::model::Pa::PaRecord>(prism_rtl::as<crate::lower::model::Do::DoLet>(d).a0).a2;
        ({
        auto c_1 = c;
        auto cp_2 = cp;
        auto fs_3 = fs;
        auto r_4 = prism_rtl::deref(r);
        call_then(start_pat_names(crate::lower::model::Pa(crate::lower::model::Pa::PaRecord{c_1, fs_3, std::move(r_4)})), [=, cp_2 = std::move(cp_2)](Array<Text> pat_names_2577) { return prism_rtl::finished(unbind(cp_2, pat_names_2577)); });
    });
    })
        : prism_rtl::is<crate::lower::model::Do::DoLet>(d) ? ({
        auto&& p_ = prism_rtl::as<crate::lower::model::Do::DoLet>(d).a0;
        auto&& x = prism_rtl::as<crate::lower::model::Do::DoLet>(d).a1;
        ({
        auto&& _m = let_name(p_);
        prism_rtl::is_some(_m) ? ({
        auto&& n = prism_rtl::some_of(_m);
        ({
        auto pointing_ = is_pointer_let(cp, p_, x) ? pointing(cp, n) : known_value(cp, p_, n);
        auto held = is_value_let(p_, x) ? owning(pointing_, n) : disowning(pointing_, n);
        auto holding = ({
            __label__ _done;
            prism_rtl::Slot<crate::emit::cpp::Cp> _v;
            if (prism_rtl::is<crate::lower::model::Pa::PaTyped>(p_)) {
                auto&& t = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_).a1;
                _v.set(({
                    crate::emit::cpp::Cp this_ = held;
                    this_.local_types = insert(this_.local_types, n, t);
                    (std::move(this_));
                }));
                goto _done;
            }
            {
                _v.set(({
                    crate::emit::cpp::Cp this_ = held;
                    this_.local_types = crate::prelude::remove(this_.local_types, n);
                    (std::move(this_));
                }));
                goto _done;
            }
        _done:
            _v.take();
        });
        auto cp_1 = cp;
        auto x_2 = x;
        call_then(crate::emit::cpp::expr::start_cpp_expr(cp_1, x_2), [=, holding = std::move(holding)](Text cpp_expr_3114) {
        return cpp_mentions(cpp_expr_3114, var_name(cp_1, n))
            ? ({
            auto fresh = prism_rtl::cat(var_name(cp_1, n), "_", inc(len(keys(prism_rtl::deref(cp_1).renames))));
            (prism_rtl::finished(({
            crate::emit::cpp::Cp this_ = holding;
            this_.renames = insert(this_.renames, n, fresh);
            (std::move(this_));
        })));
        })
            : prism_rtl::finished(holding);
    });
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(cp)
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : prism_rtl::finished(cp);
    });
}


/// `Start Rebound, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::emit::cpp::Cp> start_rebound(crate::emit::cpp::Cp cp, crate::lower::model::Do d) {
    return prism_rtl::make_rc<Rebound>(cp, d);
}


/// IsValueLet: fn Pa, Ex -> Bool
bool is_value_let(const crate::lower::model::Pa& p_, const crate::lower::model::Ex& x) {
    if (prism_rtl::is<crate::lower::model::Pa::PaBind>(p_)) {
        if (prism_rtl::is<crate::lower::model::Ex::XRef>(x)) {
            return false;
        }
        {
            return true;
        }
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaMut>(p_)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaTyped>(p_) && prism_rtl::is<crate::lower::model::OutTy::OutRef>(prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_).a1)) {
        return false;
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaTyped>(p_)) {
        return true;
    }
    {
        return false;
    }
}


/// Owning: fn Cp, Text -> Cp
crate::emit::cpp::Cp owning(const crate::emit::cpp::Cp& cp, const Text& n) {
    crate::emit::cpp::Cp this_ = cp;
    this_.owned = insert(this_.owned, n, true);
    return this_;
}


/// Disowning: fn Cp, Text -> Cp
crate::emit::cpp::Cp disowning(const crate::emit::cpp::Cp& cp, const Text& n) {
    crate::emit::cpp::Cp this_ = cp;
    this_.owned = crate::prelude::remove(this_.owned, n);
    return this_;
}


/// Captured: fn Cp -> Cp
crate::emit::cpp::Cp captured(const crate::emit::cpp::Cp& cp) {
    crate::emit::cpp::Cp this_ = cp;
    this_.owned = Map<Text, bool>{};
    this_.move_captures = Array<Text>{};
    return this_;
}


/// PatNames: unbounded fn Pa -> [Text]
Array<Text> pat_names(const crate::lower::model::Pa& p_) {
    if (prism_rtl::is<crate::lower::model::Pa::PaBind>(p_)) {
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaBind>(p_).a0;
        return Array(std::vector{n});
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaMut>(p_)) {
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaMut>(p_).a0;
        return Array(std::vector{n});
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaTyped>(p_)) {
        auto&& q = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_).a0;
        return pat_names(prism_rtl::deref(prism_rtl::deref(q)));
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaCtor>(p_)) {
        auto&& ps = prism_rtl::as<crate::lower::model::Pa::PaCtor>(p_).a1;
        return crate::emit::cpp::patterns::concat2(run_to_end(each_job(ps, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(crate::lower::model::Pa)>>(prism_rtl::rc([=](crate::lower::model::Pa p0) {
            return entered(once_job([=]() {
                return ({
                    auto q = p0;
                    (prism_rtl::more(prism_rtl::rc(PatNames(q))));
                });
            }));
        })))));
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaRecord>(p_)) {
        auto&& fs = prism_rtl::as<crate::lower::model::Pa::PaRecord>(p_).a1;
        return crate::emit::cpp::patterns::concat2(run_to_end(each_job(fs, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Text, crate::lower::model::Pa>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::Pa> p0) {
            return entered(once_job([=]() {
                return ({
                    auto&& _q = p0;
                    auto&& q = std::get<1>(_q);
                    (prism_rtl::more(prism_rtl::rc(PatNames(q))));
                });
            }));
        })))));
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaTuple>(p_)) {
        auto&& ps = prism_rtl::as<crate::lower::model::Pa::PaTuple>(p_).a0;
        return crate::emit::cpp::patterns::concat2(run_to_end(each_job(ps, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(crate::lower::model::Pa)>>(prism_rtl::rc([=](crate::lower::model::Pa p0) {
            return entered(once_job([=]() {
                return ({
                    auto q = p0;
                    (prism_rtl::more(prism_rtl::rc(PatNames(q))));
                });
            }));
        })))));
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaSlice>(p_)) {
        auto&& ps = prism_rtl::as<crate::lower::model::Pa::PaSlice>(p_).a0;
        return crate::emit::cpp::patterns::concat2(run_to_end(each_job(ps, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(crate::lower::model::Pa)>>(prism_rtl::rc([=](crate::lower::model::Pa p0) {
            return entered(once_job([=]() {
                return ({
                    auto q = p0;
                    (prism_rtl::more(prism_rtl::rc(PatNames(q))));
                });
            }));
        })))));
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaRest>(p_)) {
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaRest>(p_).a0;
        return n == Text::lit("") ? Array<Text>{} : Array(std::vector{n});
    }
    {
        return Array<Text>{};
    }
}


prism_rtl::Turn<Array<Text>> PatNames::cycle() const {
    const auto& p_ = this->p_;
    return ({
        prism_rtl::is<crate::lower::model::Pa::PaBind>(p_) ? ({
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaBind>(p_).a0;
        prism_rtl::finished(Array(std::vector{n}));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaMut>(p_) ? ({
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaMut>(p_).a0;
        prism_rtl::finished(Array(std::vector{n}));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaTyped>(p_) ? ({
        auto&& q = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_).a0;
        prism_rtl::more(prism_rtl::rc(PatNames(prism_rtl::deref(prism_rtl::deref(q)))));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaCtor>(p_) ? ({
        auto&& ps = prism_rtl::as<crate::lower::model::Pa::PaCtor>(p_).a1;
        ({
        auto ps_1 = ps;
        call_value(each_job(ps_1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(crate::lower::model::Pa)>>(prism_rtl::rc([=](crate::lower::model::Pa p0) {
        return entered(once_job([=]() {
            return ({
                auto q = p0;
                (prism_rtl::more(prism_rtl::rc(PatNames(q))));
            });
        }));
    }))), [=](Array<Array<Text>> each_4680) { return prism_rtl::finished(crate::emit::cpp::patterns::concat2(each_4680)); });
    });
    })
        : prism_rtl::is<crate::lower::model::Pa::PaRecord>(p_) ? ({
        auto&& fs = prism_rtl::as<crate::lower::model::Pa::PaRecord>(p_).a1;
        ({
        auto fs_1 = fs;
        call_value(each_job(fs_1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Text, crate::lower::model::Pa>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::Pa> p0) {
        return entered(once_job([=]() {
            return ({
                auto&& _q = p0;
                auto&& q = std::get<1>(_q);
                (prism_rtl::more(prism_rtl::rc(PatNames(q))));
            });
        }));
    }))), [=](Array<Array<Text>> each_4748) { return prism_rtl::finished(crate::emit::cpp::patterns::concat2(each_4748)); });
    });
    })
        : prism_rtl::is<crate::lower::model::Pa::PaTuple>(p_) ? ({
        auto&& ps = prism_rtl::as<crate::lower::model::Pa::PaTuple>(p_).a0;
        ({
        auto ps_1 = ps;
        call_value(each_job(ps_1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(crate::lower::model::Pa)>>(prism_rtl::rc([=](crate::lower::model::Pa p0) {
        return entered(once_job([=]() {
            return ({
                auto q = p0;
                (prism_rtl::more(prism_rtl::rc(PatNames(q))));
            });
        }));
    }))), [=](Array<Array<Text>> each_4811) { return prism_rtl::finished(crate::emit::cpp::patterns::concat2(each_4811)); });
    });
    })
        : prism_rtl::is<crate::lower::model::Pa::PaSlice>(p_) ? ({
        auto&& ps = prism_rtl::as<crate::lower::model::Pa::PaSlice>(p_).a0;
        ({
        auto ps_1 = ps;
        call_value(each_job(ps_1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(crate::lower::model::Pa)>>(prism_rtl::rc([=](crate::lower::model::Pa p0) {
        return entered(once_job([=]() {
            return ({
                auto q = p0;
                (prism_rtl::more(prism_rtl::rc(PatNames(q))));
            });
        }));
    }))), [=](Array<Array<Text>> each_4862) { return prism_rtl::finished(crate::emit::cpp::patterns::concat2(each_4862)); });
    });
    })
        : prism_rtl::is<crate::lower::model::Pa::PaRest>(p_) ? ({
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaRest>(p_).a0;
        n == Text::lit("")
        ? prism_rtl::finished(Array<Text>{})
        : prism_rtl::finished(Array(std::vector{n}));
    })
        : prism_rtl::finished(Array<Text>{});
    });
}


/// `Start PatNames, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_pat_names(crate::lower::model::Pa p_) {
    return prism_rtl::make_rc<PatNames>(p_);
}


/// ArmNames: unbounded fn XArm -> [Text]
Array<Text> arm_names(const crate::lower::model::XArm& a) {
    return append(pat_names(a.pat), crate::emit::cpp::patterns::concat2(run_to_end(each_job(a.conds, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(crate::lower::model::Cc)>>(prism_rtl::rc([=](crate::lower::model::Cc p0) {
        return entered(once_job([=]() {
            return ({
                auto c = p0;
                (prism_rtl::more(prism_rtl::rc(CondNames(c))));
            });
        }));
    }))))));
}


prism_rtl::Turn<Array<Text>> ArmNames::cycle() const {
    const auto& a = this->a;
    auto a_1 = a;
    return call_then(start_pat_names(prism_rtl::deref(a_1).pat), [=](Array<Text> pat_names_5014) {
        return call_value(each_job(prism_rtl::deref(a_1).conds, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(crate::lower::model::Cc)>>(prism_rtl::rc([=](crate::lower::model::Cc p0) {
            return entered(once_job([=]() {
                return ({
                    auto c = p0;
                    (prism_rtl::more(prism_rtl::rc(CondNames(c))));
                });
            }));
        }))), [=](Array<Array<Text>> each_5041) { return prism_rtl::finished(append(pat_names_5014, crate::emit::cpp::patterns::concat2(each_5041))); });
    });
}


/// `Start ArmNames, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_arm_names(crate::lower::model::XArm a) {
    return prism_rtl::make_rc<ArmNames>(a);
}


/// CondNames: unbounded fn Cc -> [Text]
Array<Text> cond_names(const crate::lower::model::Cc& cc0) {
    if (prism_rtl::is<crate::lower::model::Cc::CcLet>(cc0)) {
        auto&& q = prism_rtl::as<crate::lower::model::Cc::CcLet>(cc0).a0;
        return pat_names(q);
    }
    if (prism_rtl::is<crate::lower::model::Cc::CcIf>(cc0)) {
        return Array<Text>{};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Text>> CondNames::cycle() const {
    const auto& cc0 = this->cc0;
    return ({
        prism_rtl::is<crate::lower::model::Cc::CcLet>(cc0) ? ({
        auto&& q = prism_rtl::as<crate::lower::model::Cc::CcLet>(cc0).a0;
        prism_rtl::more(prism_rtl::rc(PatNames(q)));
    })
        : prism_rtl::is<crate::lower::model::Cc::CcIf>(cc0) ? prism_rtl::finished(Array<Text>{})
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CondNames, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_cond_names(crate::lower::model::Cc cc0) {
    return prism_rtl::make_rc<CondNames>(cc0);
}


/// Unbind: fn Cp, [Text] -> Cp
crate::emit::cpp::Cp unbind(const crate::emit::cpp::Cp& cp, const Array<Text>& names) {
    crate::emit::cpp::Cp this_ = cp;
    this_.renames = fold(names, this_.renames, [&](const Map<Text, Text>& m, const Text& n) { return crate::prelude::remove(m, n); });
    this_.pointers = fold(names, this_.pointers, [&](const Map<Text, bool>& m, const Text& n) { return crate::prelude::remove(m, n); });
    this_.owned = fold(names, this_.owned, [&](const Map<Text, bool>& m, const Text& n) { return crate::prelude::remove(m, n); });
    this_.local_types = fold(names, this_.local_types, [&](const Map<Text, crate::lower::model::OutTy>& m, const Text& n) { return crate::prelude::remove(m, n); });
    return this_;
}


/// Pointing: fn Cp, Text -> Cp
crate::emit::cpp::Cp pointing(const crate::emit::cpp::Cp& cp, const Text& n) {
    crate::emit::cpp::Cp this_ = cp;
    this_.pointers = insert(this_.pointers, n, true);
    return this_;
}


/// KnownValue: fn Cp, Pa, Text -> Cp
crate::emit::cpp::Cp known_value(const crate::emit::cpp::Cp& cp, const crate::lower::model::Pa& p_, const Text& n) {
    if (prism_rtl::is<crate::lower::model::Pa::PaTyped>(p_)) {
        crate::emit::cpp::Cp this_ = cp;
        this_.pointers = insert(this_.pointers, n, false);
        return this_;
    }
    {
        return cp;
    }
}


/// IsPointerLet: fn Cp, Pa, Ex -> Bool
bool is_pointer_let(const crate::emit::cpp::Cp& cp, const crate::lower::model::Pa& p_, const crate::lower::model::Ex& x) {
    if (prism_rtl::is<crate::lower::model::Pa::PaTyped>(p_)) {
        auto&& t = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_).a1;
        return crate::emit::cpp::expr::is_pointer_ty(cp, t);
    }
    {
        if (prism_rtl::is<crate::lower::model::Ex::XCall>(x)) {
            auto&& m6285_0_0 = prism_rtl::as<crate::lower::model::Ex::XCall>(x).a0;
            if (m6285_0_0 == Text::lit("prism_rtl::Host::new")) {
                return true;
            }
        }
        if (prism_rtl::is<crate::lower::model::Ex::XCall>(x)) {
            auto&& m6285_1_0 = prism_rtl::as<crate::lower::model::Ex::XCall>(x).a0;
            auto&& m6285_1_1 = prism_rtl::as<crate::lower::model::Ex::XCall>(x).a1;
            if (m6285_1_0 == Text::lit("Rc::new")) {
                if (m6285_1_1.size() == 1u) {
                    {
                        auto&& _c2 = index(m6285_1_1, Nat(0u));
                        if (prism_rtl::is_some(_c2) && prism_rtl::is<crate::lower::model::Ex::XCall>(prism_rtl::some_of(_c2))) {
                            auto&& m6285_1_1_0_0 = prism_rtl::as<crate::lower::model::Ex::XCall>(prism_rtl::some_of(_c2)).a0;
                            if (m6285_1_1_0_0 == Text::lit("Port::new")) {
                                return true;
                            }
                        }
                    }
                }
            }
        }
        {
            auto&& _m = crate::emit::cpp::expr::pointer(cp, x);
            if (prism_rtl::is_some(_m)) {
                auto&& b = prism_rtl::some_of(_m);
                return b;
            }
            if (prism_rtl::is_none(_m)) {
                return false;
            }
            prism_rtl::unreachable("no arm matched");
        }
    }
}


/// Inc: fn Nat -> Nat
Nat inc(const Nat& n) {
    return n + Nat(1u);
}


/// ?LetName: fn Pa -> ?Text
std::optional<Text> let_name(const crate::lower::model::Pa& p_) {
    if (prism_rtl::is<crate::lower::model::Pa::PaBind>(p_)) {
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaBind>(p_).a0;
        return std::optional(n);
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaMut>(p_)) {
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaMut>(p_).a0;
        return std::optional(n);
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaTyped>(p_)) {
        auto&& q = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_).a0;
        return let_name(prism_rtl::deref(prism_rtl::deref(q)));
    }
    {
        return std::optional<Text>{};
    }
}


/// VarName: fn Cp, Text -> Text
Text var_name(const crate::emit::cpp::Cp& cp, const Text& n) {
    return or_(crate::prelude::get(cp.renames, n), crate::emit::cpp::cpp_id(n));
}


/// CppMentions: fn Text, Text -> Bool
bool cpp_mentions(const Text& t, const Text& n) {
    auto parts = split_on(t, n);
    auto k = len(parts);
    return fold(crate::check::errors::range0(crate::syntax::lexer::chars::dec(k)), false, [&](const bool& f, const Nat& i) { return prism_rtl::deref(f) || ((!cpp_ends_ident(or_(index(parts, i), Text::lit("")))) && (!cpp_starts_ident(or_(index(parts, i + Nat(1u)), Text::lit(""))))); });
}


/// CppEndsIdent: fn Text -> Bool
bool cpp_ends_ident(const Text& t) {
    auto c = crate::syntax::lexer::chars::last_char(t);
    return (cpp_ident_char(c) || (c == Text::lit("."))) || (c == Text::lit(">"));
}


/// CppStartsIdent: fn Text -> Bool
bool cpp_starts_ident(const Text& t) {
    return cpp_ident_char(crate::syntax::lexer::chars::head(t));
}


/// CppIdentChar: fn Text -> Bool
bool cpp_ident_char(const Text& c) {
    return (c != Text::lit("")) && crate::syntax::lexer::chars::contains(Text::lit("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_"), c);
}


/// CppStatement: unbounded fn Cp, Do -> Text
Text cpp_statement(const crate::emit::cpp::Cp& cp, const crate::lower::model::Do& d) {
    if (prism_rtl::is<crate::lower::model::Do::DoLet>(d)) {
        auto&& p_ = prism_rtl::as<crate::lower::model::Do::DoLet>(d).a0;
        auto&& x = prism_rtl::as<crate::lower::model::Do::DoLet>(d).a1;
        return cpp_let(cp, cp, p_, x);
    }
    if (prism_rtl::is<crate::lower::model::Do::DoLetElse>(d)) {
        auto&& p_ = prism_rtl::as<crate::lower::model::Do::DoLetElse>(d).a0;
        auto&& x = prism_rtl::as<crate::lower::model::Do::DoLetElse>(d).a1;
        auto&& e = prism_rtl::as<crate::lower::model::Do::DoLetElse>(d).a2;
        auto v_ = prism_rtl::cat("_", or_(first_binder(p_), Text::lit("m")));
        return prism_rtl::cat("auto&& ", v_, " = ", crate::emit::cpp::expr::cpp_expr(cp, x), ";\nif (!(", crate::emit::cpp::patterns::conds(crate::emit::cpp::patterns::pat_conds(cp, p_, v_)), ")) { ", crate::emit::cpp::expr::cpp_expr(cp, e), "; }\n", crate::syntax::lexer::chars::join(crate::emit::cpp::patterns::pat_binds(cp, p_, v_), Text::lit("\n")));
    }
    if (prism_rtl::is<crate::lower::model::Do::DoAssign>(d)) {
        auto&& p_ = prism_rtl::as<crate::lower::model::Do::DoAssign>(d).a0;
        auto&& x = prism_rtl::as<crate::lower::model::Do::DoAssign>(d).a1;
        return prism_rtl::cat(crate::emit::cpp::expr::cpp_place(cp, p_), " = ", crate::emit::cpp::expr::cpp_expr(cp, x), ";");
    }
    if (prism_rtl::is<crate::lower::model::Do::DoWhile>(d)) {
        auto&& c = prism_rtl::as<crate::lower::model::Do::DoWhile>(d).a0;
        auto&& body = prism_rtl::as<crate::lower::model::Do::DoWhile>(d).a1;
        return crate::emit::cpp::templates::items::block(prism_rtl::cat("while (", crate::emit::cpp::expr::cpp_expr(cp, c), ")"), cpp_statements(cp, body));
    }
    if (prism_rtl::is<crate::lower::model::Do::DoWhileLet>(d)) {
        auto&& p_ = prism_rtl::as<crate::lower::model::Do::DoWhileLet>(d).a0;
        auto&& x = prism_rtl::as<crate::lower::model::Do::DoWhileLet>(d).a1;
        auto&& body = prism_rtl::as<crate::lower::model::Do::DoWhileLet>(d).a2;
        auto v_ = Text::lit("_m");
        auto head = prism_rtl::cat("auto&& _m = ", crate::emit::cpp::expr::cpp_expr(cp, x), ";\nif (!(", crate::emit::cpp::patterns::conds(crate::emit::cpp::patterns::pat_conds(cp, p_, v_)), ")) break;");
        return crate::emit::cpp::templates::items::block(Text::lit("while (true)"), crate::syntax::lexer::chars::join(append(append(Array(std::vector{head}), crate::emit::cpp::patterns::pat_binds(cp, p_, v_)), Array(std::vector{cpp_statements(cp, body)})), Text::lit("\n")));
    }
    if (prism_rtl::is<crate::lower::model::Do::DoFor>(d)) {
        auto&& p_ = prism_rtl::as<crate::lower::model::Do::DoFor>(d).a0;
        auto&& x = prism_rtl::as<crate::lower::model::Do::DoFor>(d).a1;
        auto&& body = prism_rtl::as<crate::lower::model::Do::DoFor>(d).a2;
        return cpp_for(cp, p_, x, body);
    }
    if (prism_rtl::is<crate::lower::model::Do::DoExpr>(d) && prism_rtl::is<crate::lower::model::Ex::XBreak>(prism_rtl::as<crate::lower::model::Do::DoExpr>(d).a0)) {
        auto&& l = prism_rtl::as<crate::lower::model::Ex::XBreak>(prism_rtl::as<crate::lower::model::Do::DoExpr>(d).a0).a0;
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XBreak>(prism_rtl::as<crate::lower::model::Do::DoExpr>(d).a0).a1;
        return crate::emit::cpp::patterns::cpp_break(cp, l, prism_rtl::deref(prism_rtl::deref(y)));
    }
    if (prism_rtl::is<crate::lower::model::Do::DoExpr>(d) && prism_rtl::is<crate::lower::model::Ex::XBreakLoop>(prism_rtl::as<crate::lower::model::Do::DoExpr>(d).a0)) {
        return Text::lit("break;");
    }
    if (prism_rtl::is<crate::lower::model::Do::DoExpr>(d)) {
        auto&& x = prism_rtl::as<crate::lower::model::Do::DoExpr>(d).a0;
        return prism_rtl::cat(crate::emit::cpp::expr::cpp_expr(cp, x), ";");
    }
    if (prism_rtl::is<crate::lower::model::Do::DoIf>(d)) {
        auto&& c = prism_rtl::as<crate::lower::model::Do::DoIf>(d).a0;
        auto&& t = prism_rtl::as<crate::lower::model::Do::DoIf>(d).a1;
        auto&& e = prism_rtl::as<crate::lower::model::Do::DoIf>(d).a2;
        return prism_rtl::cat(crate::emit::cpp::templates::items::block(prism_rtl::cat("if (", crate::emit::cpp::expr::cpp_expr(cp, c), ")"), cpp_statements(cp, t)), cpp_else(cp, e));
    }
    if (prism_rtl::is<crate::lower::model::Do::DoIfLet>(d)) {
        auto&& p_ = prism_rtl::as<crate::lower::model::Do::DoIfLet>(d).a0;
        auto&& x = prism_rtl::as<crate::lower::model::Do::DoIfLet>(d).a1;
        auto&& t = prism_rtl::as<crate::lower::model::Do::DoIfLet>(d).a2;
        auto&& e = prism_rtl::as<crate::lower::model::Do::DoIfLet>(d).a3;
        return cpp_if_let(cp, p_, x, t, e);
    }
    if (prism_rtl::is<crate::lower::model::Do::DoMatch>(d)) {
        auto&& x = prism_rtl::as<crate::lower::model::Do::DoMatch>(d).a0;
        auto&& cases = prism_rtl::as<crate::lower::model::Do::DoMatch>(d).a1;
        return cpp_do_match(cp, x, cases);
    }
    if (prism_rtl::is<crate::lower::model::Do::DoReturn>(d)) {
        auto&& x = prism_rtl::as<crate::lower::model::Do::DoReturn>(d).a0;
        return prism_rtl::cat("return ", cpp_returned(cp, x), ";");
    }
    if (prism_rtl::is<crate::lower::model::Do::DoBlock>(d)) {
        auto&& body = prism_rtl::as<crate::lower::model::Do::DoBlock>(d).a0;
        return crate::emit::cpp::templates::items::braced(cpp_statements(cp, body));
    }
    if (prism_rtl::is<crate::lower::model::Do::DoScope>(d)) {
        auto&& body = prism_rtl::as<crate::lower::model::Do::DoScope>(d).a0;
        return prism_rtl::cat("{ ", cpp_inline(cp, body), " }");
    }
    if (prism_rtl::is<crate::lower::model::Do::DoLine>(d)) {
        auto&& body = prism_rtl::as<crate::lower::model::Do::DoLine>(d).a0;
        return cpp_inline(cp, body);
    }
    if (prism_rtl::is<crate::lower::model::Do::DoNote>(d)) {
        auto&& t = prism_rtl::as<crate::lower::model::Do::DoNote>(d).a0;
        return prism_rtl::cat("// ", t);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Text> CppStatement::cycle() const {
    const auto& cp = this->cp;
    const auto& d = this->d;
    return ({
        prism_rtl::is<crate::lower::model::Do::DoLet>(d) ? ({
        auto&& p_ = prism_rtl::as<crate::lower::model::Do::DoLet>(d).a0;
        auto&& x = prism_rtl::as<crate::lower::model::Do::DoLet>(d).a1;
        prism_rtl::more(prism_rtl::rc(CppLet(cp, cp, p_, x)));
    })
        : prism_rtl::is<crate::lower::model::Do::DoLetElse>(d) ? ({
        auto&& p_ = prism_rtl::as<crate::lower::model::Do::DoLetElse>(d).a0;
        auto&& x = prism_rtl::as<crate::lower::model::Do::DoLetElse>(d).a1;
        auto&& e = prism_rtl::as<crate::lower::model::Do::DoLetElse>(d).a2;
        ({
        auto cp_1 = cp;
        auto e_2 = e;
        auto p__3 = p_;
        auto x_4 = x;
        call_then(start_first_binder(p__3), [=, cp_1 = std::move(cp_1), e_2 = std::move(e_2), x_4 = std::move(x_4)](std::optional<Text> first_binder_7579) {
        return ({
            auto v_ = prism_rtl::cat("_", or_(first_binder_7579, Text::lit("m")));
            call_then(crate::emit::cpp::expr::start_cpp_expr(cp_1, x_4), [=, v_ = std::move(v_)](Text cpp_expr_7625) { return call_then(crate::emit::cpp::patterns::start_pat_conds(cp_1, p__3, v_), [=](Array<Text> pat_conds_7656) { return call_then(crate::emit::cpp::expr::start_cpp_expr(cp_1, e_2), [=](Text cpp_expr_7682) { return call_then(crate::emit::cpp::patterns::start_pat_binds(cp_1, p__3, v_), [=](Array<Text> pat_binds_7709) { return prism_rtl::finished(prism_rtl::cat("auto&& ", v_, " = ", cpp_expr_7625, ";\nif (!(", crate::emit::cpp::patterns::conds(pat_conds_7656), ")) { ", cpp_expr_7682, "; }\n", crate::syntax::lexer::chars::join(pat_binds_7709, Text::lit("\n")))); }); }); }); });
        });
    });
    });
    })
        : prism_rtl::is<crate::lower::model::Do::DoAssign>(d) ? ({
        auto&& p_ = prism_rtl::as<crate::lower::model::Do::DoAssign>(d).a0;
        auto&& x = prism_rtl::as<crate::lower::model::Do::DoAssign>(d).a1;
        ({
        auto cp_1 = cp;
        auto p__2 = p_;
        auto x_3 = x;
        call_then(crate::emit::cpp::expr::start_cpp_place(cp_1, p__2), [=, x_3 = std::move(x_3)](Text cpp_place_7757) { return call_then(crate::emit::cpp::expr::start_cpp_expr(cp_1, x_3), [=](Text cpp_expr_7776) { return prism_rtl::finished(prism_rtl::cat(cpp_place_7757, " = ", cpp_expr_7776, ";")); }); });
    });
    })
        : prism_rtl::is<crate::lower::model::Do::DoWhile>(d) ? ({
        auto&& c = prism_rtl::as<crate::lower::model::Do::DoWhile>(d).a0;
        auto&& body = prism_rtl::as<crate::lower::model::Do::DoWhile>(d).a1;
        ({
        auto body_1 = body;
        auto c_2 = c;
        auto cp_3 = cp;
        call_then(crate::emit::cpp::expr::start_cpp_expr(cp_3, c_2), [=, body_1 = std::move(body_1)](Text cpp_expr_7829) { return call_then(start_cpp_statements(cp_3, body_1), [=](Text cpp_statements_7848) { return prism_rtl::finished(crate::emit::cpp::templates::items::block(prism_rtl::cat("while (", cpp_expr_7829, ")"), cpp_statements_7848)); }); });
    });
    })
        : prism_rtl::is<crate::lower::model::Do::DoWhileLet>(d) ? ({
        auto&& p_ = prism_rtl::as<crate::lower::model::Do::DoWhileLet>(d).a0;
        auto&& x = prism_rtl::as<crate::lower::model::Do::DoWhileLet>(d).a1;
        auto&& body = prism_rtl::as<crate::lower::model::Do::DoWhileLet>(d).a2;
        ({
        auto v_ = Text::lit("_m");
        auto body_1 = body;
        auto cp_2 = cp;
        auto p__3 = p_;
        auto x_4 = x;
        call_then(crate::emit::cpp::expr::start_cpp_expr(cp_2, x_4), [=, v_ = std::move(v_), body_1 = std::move(body_1), p__3 = std::move(p__3)](Text cpp_expr_7953) {
        return call_then(crate::emit::cpp::patterns::start_pat_conds(cp_2, p__3, v_), [=](Array<Text> pat_conds_7984) {
            return ({
                auto head = prism_rtl::cat("auto&& _m = ", cpp_expr_7953, ";\nif (!(", crate::emit::cpp::patterns::conds(pat_conds_7984), ")) break;");
                call_then(crate::emit::cpp::patterns::start_pat_binds(cp_2, p__3, v_), [=, head = std::move(head)](Array<Text> pat_binds_8077) { return call_then(start_cpp_statements(cp_2, body_1), [=](Text cpp_statements_8101) { return prism_rtl::finished(crate::emit::cpp::templates::items::block(Text::lit("while (true)"), crate::syntax::lexer::chars::join(append(append(Array(std::vector{head}), pat_binds_8077), Array(std::vector{cpp_statements_8101})), Text::lit("\n")))); }); });
            });
        });
    });
    });
    })
        : prism_rtl::is<crate::lower::model::Do::DoFor>(d) ? ({
        auto&& p_ = prism_rtl::as<crate::lower::model::Do::DoFor>(d).a0;
        auto&& x = prism_rtl::as<crate::lower::model::Do::DoFor>(d).a1;
        auto&& body = prism_rtl::as<crate::lower::model::Do::DoFor>(d).a2;
        prism_rtl::more(prism_rtl::rc(CppFor(cp, p_, x, body)));
    })
        : prism_rtl::is<crate::lower::model::Do::DoExpr>(d) && prism_rtl::is<crate::lower::model::Ex::XBreak>(prism_rtl::as<crate::lower::model::Do::DoExpr>(d).a0) ? ({
        auto&& l = prism_rtl::as<crate::lower::model::Ex::XBreak>(prism_rtl::as<crate::lower::model::Do::DoExpr>(d).a0).a0;
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XBreak>(prism_rtl::as<crate::lower::model::Do::DoExpr>(d).a0).a1;
        prism_rtl::more(prism_rtl::rc(crate::emit::cpp::patterns::CppBreak(cp, l, prism_rtl::deref(prism_rtl::deref(y)))));
    })
        : prism_rtl::is<crate::lower::model::Do::DoExpr>(d) && prism_rtl::is<crate::lower::model::Ex::XBreakLoop>(prism_rtl::as<crate::lower::model::Do::DoExpr>(d).a0) ? prism_rtl::finished(Text::lit("break;"))
        : prism_rtl::is<crate::lower::model::Do::DoExpr>(d) ? ({
        auto&& x = prism_rtl::as<crate::lower::model::Do::DoExpr>(d).a0;
        ({
        auto cp_1 = cp;
        auto x_2 = x;
        call_then(crate::emit::cpp::expr::start_cpp_expr(cp_1, x_2), [=](Text cpp_expr_8271) { return prism_rtl::finished(prism_rtl::cat(cpp_expr_8271, ";")); });
    });
    })
        : prism_rtl::is<crate::lower::model::Do::DoIf>(d) ? ({
        auto&& c = prism_rtl::as<crate::lower::model::Do::DoIf>(d).a0;
        auto&& t = prism_rtl::as<crate::lower::model::Do::DoIf>(d).a1;
        auto&& e = prism_rtl::as<crate::lower::model::Do::DoIf>(d).a2;
        ({
        auto c_1 = c;
        auto cp_2 = cp;
        auto e_3 = e;
        auto t_4 = t;
        call_then(crate::emit::cpp::expr::start_cpp_expr(cp_2, c_1), [=, e_3 = std::move(e_3), t_4 = std::move(t_4)](Text cpp_expr_8320) { return call_then(start_cpp_statements(cp_2, t_4), [=](Text cpp_statements_8339) { return call_then(start_cpp_else(cp_2, e_3), [=](Text cpp_else_8361) { return prism_rtl::finished(prism_rtl::cat(crate::emit::cpp::templates::items::block(prism_rtl::cat("if (", cpp_expr_8320, ")"), cpp_statements_8339), cpp_else_8361)); }); }); });
    });
    })
        : prism_rtl::is<crate::lower::model::Do::DoIfLet>(d) ? ({
        auto&& p_ = prism_rtl::as<crate::lower::model::Do::DoIfLet>(d).a0;
        auto&& x = prism_rtl::as<crate::lower::model::Do::DoIfLet>(d).a1;
        auto&& t = prism_rtl::as<crate::lower::model::Do::DoIfLet>(d).a2;
        auto&& e = prism_rtl::as<crate::lower::model::Do::DoIfLet>(d).a3;
        prism_rtl::more(prism_rtl::rc(CppIfLet(cp, p_, x, t, e)));
    })
        : prism_rtl::is<crate::lower::model::Do::DoMatch>(d) ? ({
        auto&& x = prism_rtl::as<crate::lower::model::Do::DoMatch>(d).a0;
        auto&& cases = prism_rtl::as<crate::lower::model::Do::DoMatch>(d).a1;
        prism_rtl::more(prism_rtl::rc(CppDoMatch(cp, x, cases)));
    })
        : prism_rtl::is<crate::lower::model::Do::DoReturn>(d) ? ({
        auto&& x = prism_rtl::as<crate::lower::model::Do::DoReturn>(d).a0;
        ({
        auto cp_1 = cp;
        auto x_2 = x;
        call_then(start_cpp_returned(cp_1, x_2), [=](Text cpp_returned_8496) { return prism_rtl::finished(prism_rtl::cat("return ", cpp_returned_8496, ";")); });
    });
    })
        : prism_rtl::is<crate::lower::model::Do::DoBlock>(d) ? ({
        auto&& body = prism_rtl::as<crate::lower::model::Do::DoBlock>(d).a0;
        ({
        auto body_1 = body;
        auto cp_2 = cp;
        call_then(start_cpp_statements(cp_2, body_1), [=](Text cpp_statements_8543) { return prism_rtl::finished(crate::emit::cpp::templates::items::braced(cpp_statements_8543)); });
    });
    })
        : prism_rtl::is<crate::lower::model::Do::DoScope>(d) ? ({
        auto&& body = prism_rtl::as<crate::lower::model::Do::DoScope>(d).a0;
        ({
        auto body_1 = body;
        auto cp_2 = cp;
        call_then(start_cpp_inline(cp_2, body_1), [=](Text cpp_inline_8590) { return prism_rtl::finished(prism_rtl::cat("{ ", cpp_inline_8590, " }")); });
    });
    })
        : prism_rtl::is<crate::lower::model::Do::DoLine>(d) ? ({
        auto&& body = prism_rtl::as<crate::lower::model::Do::DoLine>(d).a0;
        prism_rtl::more(prism_rtl::rc(CppInline(cp, body)));
    })
        : prism_rtl::is<crate::lower::model::Do::DoNote>(d) ? ({
        auto&& t = prism_rtl::as<crate::lower::model::Do::DoNote>(d).a0;
        prism_rtl::finished(prism_rtl::cat("// ", t));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CppStatement, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_statement(crate::emit::cpp::Cp cp, crate::lower::model::Do d) {
    return prism_rtl::make_rc<CppStatement>(cp, d);
}


/// CppInline: unbounded fn Cp, [Do] -> Text
Text cpp_inline(const crate::emit::cpp::Cp& cp, const Array<crate::lower::model::Do>& dos) {
    return crate::syntax::lexer::chars::join(run_to_end(each_job(dos, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Do)>>(prism_rtl::rc([=, cp_1 = std::move(cp_1)](crate::lower::model::Do p0) {
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=, cp_1_2 = std::move(cp_1_2)]() {
            return ({
                auto d = p0;
                (prism_rtl::more(prism_rtl::rc(CppStatement(cp_1_2, d))));
            });
        }));
        });
    })));
    }))), Text::lit(" "));
}


prism_rtl::Turn<Text> CppInline::cycle() const {
    const auto& cp = this->cp;
    const auto& dos = this->dos;
    auto cp_1 = cp;
    auto dos_2 = dos;
    return call_value(each_job(dos_2, ({
        auto cp_1_3 = cp_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Do)>>(prism_rtl::rc([=, cp_1_3 = std::move(cp_1_3)](crate::lower::model::Do p0) {
        return ({
            auto cp_1_3_3 = cp_1_3;
            entered(once_job([=, cp_1_3_3 = std::move(cp_1_3_3)]() {
            return ({
                auto d = p0;
                (prism_rtl::more(prism_rtl::rc(CppStatement(cp_1_3_3, d))));
            });
        }));
        });
    })));
    })), [=](Array<Text> each_8744) { return prism_rtl::finished(crate::syntax::lexer::chars::join(each_8744, Text::lit(" "))); });
}


/// `Start CppInline, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_inline(crate::emit::cpp::Cp cp, Array<crate::lower::model::Do> dos) {
    return prism_rtl::make_rc<CppInline>(cp, dos);
}


/// CppElse: unbounded fn Cp, [Do] -> Text
Text cpp_else(const crate::emit::cpp::Cp& cp, const Array<crate::lower::model::Do>& xs1) {
    {
        auto&& c0_1 = xs1;
        if (c0_1.size() == 0u) {
            return Text::lit("");
        }
    }
    {
        auto&& c1_1 = xs1;
        if (c1_1.size() == 1u) {
            {
                auto&& _c1 = index(c1_1, Nat(0u));
                if (prism_rtl::is_some(_c1) && prism_rtl::is<crate::lower::model::Do::DoIf>(prism_rtl::some_of(_c1))) {
                    auto&& c = prism_rtl::as<crate::lower::model::Do::DoIf>(prism_rtl::some_of(_c1)).a0;
                    auto&& t = prism_rtl::as<crate::lower::model::Do::DoIf>(prism_rtl::some_of(_c1)).a1;
                    auto&& e = prism_rtl::as<crate::lower::model::Do::DoIf>(prism_rtl::some_of(_c1)).a2;
                    return prism_rtl::cat(" else ", cpp_statement(cp, crate::lower::model::Do(crate::lower::model::Do::DoIf{c, t, e})));
                }
            }
        }
    }
    {
        auto&& c2_1 = xs1;
        if (c2_1.size() == 1u) {
            {
                auto&& _c1 = index(c2_1, Nat(0u));
                if (prism_rtl::is_some(_c1) && prism_rtl::is<crate::lower::model::Do::DoIfLet>(prism_rtl::some_of(_c1))) {
                    auto&& p_ = prism_rtl::as<crate::lower::model::Do::DoIfLet>(prism_rtl::some_of(_c1)).a0;
                    auto&& x = prism_rtl::as<crate::lower::model::Do::DoIfLet>(prism_rtl::some_of(_c1)).a1;
                    auto&& t = prism_rtl::as<crate::lower::model::Do::DoIfLet>(prism_rtl::some_of(_c1)).a2;
                    auto&& e = prism_rtl::as<crate::lower::model::Do::DoIfLet>(prism_rtl::some_of(_c1)).a3;
                    return prism_rtl::cat(" else ", cpp_statement(cp, crate::lower::model::Do(crate::lower::model::Do::DoIfLet{p_, x, t, e})));
                }
            }
        }
    }
    {
        auto&& body = xs1;
        return prism_rtl::cat(" else ", crate::emit::cpp::templates::items::block(Text::lit(""), cpp_statements(cp, body)));
    }
}


prism_rtl::Turn<Text> CppElse::cycle() const {
    const auto& cp = this->cp;
    const auto& xs1 = this->xs1;
    return ({
        ({
        auto&& j0_1 = xs1;
        (j0_1.size() == 0u);
    }) ? ({
        auto&& j0_1 = xs1;
        prism_rtl::finished(Text::lit(""));
    })
        : ({
        auto&& j1_1 = xs1;
        (j1_1.size() == 1u) && ({
        auto&& _c1 = index(j1_1, Nat(0u));
        prism_rtl::is_some(_c1) && prism_rtl::is<crate::lower::model::Do::DoIf>(prism_rtl::some_of(_c1));
    });
    }) ? ({
        auto&& j1_1 = xs1;
        auto&& _c1 = index(j1_1, Nat(0u));
        auto&& c = prism_rtl::as<crate::lower::model::Do::DoIf>(prism_rtl::some_of(_c1)).a0;
        auto&& t = prism_rtl::as<crate::lower::model::Do::DoIf>(prism_rtl::some_of(_c1)).a1;
        auto&& e = prism_rtl::as<crate::lower::model::Do::DoIf>(prism_rtl::some_of(_c1)).a2;
        ({
        auto cp_1 = cp;
        call_then(start_cpp_statement(cp_1, crate::lower::model::Do(crate::lower::model::Do::DoIf{c, t, e})), [=](Text cpp_statement_8893) { return prism_rtl::finished(prism_rtl::cat(" else ", cpp_statement_8893)); });
    });
    })
        : ({
        auto&& j2_1 = xs1;
        (j2_1.size() == 1u) && ({
        auto&& _c1 = index(j2_1, Nat(0u));
        prism_rtl::is_some(_c1) && prism_rtl::is<crate::lower::model::Do::DoIfLet>(prism_rtl::some_of(_c1));
    });
    }) ? ({
        auto&& j2_1 = xs1;
        auto&& _c1 = index(j2_1, Nat(0u));
        auto&& p_ = prism_rtl::as<crate::lower::model::Do::DoIfLet>(prism_rtl::some_of(_c1)).a0;
        auto&& x = prism_rtl::as<crate::lower::model::Do::DoIfLet>(prism_rtl::some_of(_c1)).a1;
        auto&& t = prism_rtl::as<crate::lower::model::Do::DoIfLet>(prism_rtl::some_of(_c1)).a2;
        auto&& e = prism_rtl::as<crate::lower::model::Do::DoIfLet>(prism_rtl::some_of(_c1)).a3;
        ({
        auto cp_1 = cp;
        call_then(start_cpp_statement(cp_1, crate::lower::model::Do(crate::lower::model::Do::DoIfLet{p_, x, t, e})), [=](Text cpp_statement_8977) { return prism_rtl::finished(prism_rtl::cat(" else ", cpp_statement_8977)); });
    });
    })
        : ({
        auto&& body = xs1;
        ({
        auto body_1 = body;
        auto cp_2 = cp;
        call_then(start_cpp_statements(cp_2, body_1), [=](Text cpp_statements_9058) { return prism_rtl::finished(prism_rtl::cat(" else ", crate::emit::cpp::templates::items::block(Text::lit(""), cpp_statements_9058))); });
    });
    });
    });
}


/// `Start CppElse, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_else(crate::emit::cpp::Cp cp, Array<crate::lower::model::Do> xs1) {
    return prism_rtl::make_rc<CppElse>(cp, xs1);
}


/// CppLet: unbounded fn Cp, Cp, Pa, Ex -> Text
Text cpp_let(const crate::emit::cpp::Cp& cp, const crate::emit::cpp::Cp& named_, const crate::lower::model::Pa& p_, const crate::lower::model::Ex& x) {
    if (prism_rtl::is<crate::lower::model::Pa::PaWild>(p_)) {
        return prism_rtl::cat("static_cast<void>(", crate::emit::cpp::expr::cpp_expr(cp, x), ");");
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaBind>(p_)) {
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaBind>(p_).a0;
        if (prism_rtl::is<crate::lower::model::Ex::XRef>(x)) {
            return prism_rtl::cat("const auto& ", var_name(named_, n), " = ", crate::emit::cpp::expr::cpp_expr(cp, x), ";");
        }
        {
            return prism_rtl::cat("auto ", var_name(named_, n), " = ", crate::emit::cpp::expr::cpp_expr(cp, x), ";");
        }
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaMut>(p_)) {
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaMut>(p_).a0;
        return prism_rtl::cat("auto ", var_name(named_, n), " = ", crate::emit::cpp::expr::cpp_expr(cp, x), ";");
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaTyped>(p_)) {
        auto&& m9274_3_0 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_).a0;
        auto&& t = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_).a1;
        if (prism_rtl::is<crate::lower::model::Pa::PaBind>(prism_rtl::deref(prism_rtl::deref(m9274_3_0)))) {
            auto&& n = prism_rtl::as<crate::lower::model::Pa::PaBind>(prism_rtl::deref(prism_rtl::deref(m9274_3_0))).a0;
            return prism_rtl::cat(crate::emit::cpp::cpp_type(cp, t), " ", var_name(named_, n), " = ", crate::emit::cpp::expr::cpp_expr(cp, x), ";");
        }
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaTyped>(p_)) {
        auto&& m9274_4_0 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_).a0;
        auto&& t = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_).a1;
        if (prism_rtl::is<crate::lower::model::Pa::PaMut>(prism_rtl::deref(prism_rtl::deref(m9274_4_0)))) {
            auto&& n = prism_rtl::as<crate::lower::model::Pa::PaMut>(prism_rtl::deref(prism_rtl::deref(m9274_4_0))).a0;
            return prism_rtl::cat(crate::emit::cpp::cpp_type(cp, t), " ", var_name(named_, n), " = ", crate::emit::cpp::expr::cpp_expr(cp, x), ";");
        }
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaTuple>(p_)) {
        auto&& ps = prism_rtl::as<crate::lower::model::Pa::PaTuple>(p_).a0;
        return fold(ps, true, [&](const bool& f, const crate::lower::model::Pa& q) { return prism_rtl::deref(f) && is_name(q); })
            ? prism_rtl::cat("auto [", crate::syntax::lexer::chars::join(each(ps, [&](const crate::lower::model::Pa& q) { return pat_name(q); }), Text::lit(", ")), "] = ", crate::emit::cpp::expr::cpp_expr(cp, x), ";")
            : let_through(cp, p_, x);
    }
    {
        return let_through(cp, p_, x);
    }
}


prism_rtl::Turn<Text> CppLet::cycle() const {
    const auto& cp = this->cp;
    const auto& named_ = this->named_;
    const auto& p_ = this->p_;
    const auto& x = this->x;
    return ({
        prism_rtl::is<crate::lower::model::Pa::PaWild>(p_) ? ({
        auto cp_1 = cp;
        auto x_2 = x;
        call_then(crate::emit::cpp::expr::start_cpp_expr(cp_1, x_2), [=](Text cpp_expr_9315) { return prism_rtl::finished(prism_rtl::cat("static_cast<void>(", cpp_expr_9315, ");")); });
    })
        : prism_rtl::is<crate::lower::model::Pa::PaBind>(p_) ? ({
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaBind>(p_).a0;
        ({
        prism_rtl::is<crate::lower::model::Ex::XRef>(x) ? ({
        auto cp_1 = cp;
        auto n_2 = n;
        auto named__3 = named_;
        auto x_4 = x;
        call_then(crate::emit::cpp::expr::start_cpp_expr(cp_1, x_4), [=, n_2 = std::move(n_2), named__3 = std::move(named__3)](Text cpp_expr_9412) { return prism_rtl::finished(prism_rtl::cat("const auto& ", var_name(named__3, n_2), " = ", cpp_expr_9412, ";")); });
    })
        : ({
        auto cp_1 = cp;
        auto n_2 = n;
        auto named__3 = named_;
        auto x_4 = x;
        call_then(crate::emit::cpp::expr::start_cpp_expr(cp_1, x_4), [=, n_2 = std::move(n_2), named__3 = std::move(named__3)](Text cpp_expr_9476) { return prism_rtl::finished(prism_rtl::cat("auto ", var_name(named__3, n_2), " = ", cpp_expr_9476, ";")); });
    });
    });
    })
        : prism_rtl::is<crate::lower::model::Pa::PaMut>(p_) ? ({
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaMut>(p_).a0;
        ({
        auto cp_1 = cp;
        auto n_2 = n;
        auto named__3 = named_;
        auto x_4 = x;
        call_then(crate::emit::cpp::expr::start_cpp_expr(cp_1, x_4), [=, n_2 = std::move(n_2), named__3 = std::move(named__3)](Text cpp_expr_9534) { return prism_rtl::finished(prism_rtl::cat("auto ", var_name(named__3, n_2), " = ", cpp_expr_9534, ";")); });
    });
    })
        : prism_rtl::is<crate::lower::model::Pa::PaTyped>(p_) && ({
        auto&& m9274_3_0 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_).a0;
        auto&& t = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_).a1;
        prism_rtl::is<crate::lower::model::Pa::PaBind>(prism_rtl::deref(prism_rtl::deref(m9274_3_0)));
    }) ? ({
        auto&& m9274_3_0 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_).a0;
        auto&& t = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_).a1;
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaBind>(prism_rtl::deref(prism_rtl::deref(m9274_3_0))).a0;
        ({
        auto cp_1 = cp;
        auto n_2 = n;
        auto named__3 = named_;
        auto t_4 = t;
        auto x_5 = x;
        call_then(crate::emit::cpp::start_cpp_type(cp_1, t_4), [=, n_2 = std::move(n_2), named__3 = std::move(named__3), x_5 = std::move(x_5)](Text cpp_type_9580) { return call_then(crate::emit::cpp::expr::start_cpp_expr(cp_1, x_5), [=](Text cpp_expr_9617) { return prism_rtl::finished(prism_rtl::cat(cpp_type_9580, " ", var_name(named__3, n_2), " = ", cpp_expr_9617, ";")); }); });
    });
    })
        : prism_rtl::is<crate::lower::model::Pa::PaTyped>(p_) && ({
        auto&& m9274_4_0 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_).a0;
        auto&& t = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_).a1;
        prism_rtl::is<crate::lower::model::Pa::PaMut>(prism_rtl::deref(prism_rtl::deref(m9274_4_0)));
    }) ? ({
        auto&& m9274_4_0 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_).a0;
        auto&& t = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_).a1;
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaMut>(prism_rtl::deref(prism_rtl::deref(m9274_4_0))).a0;
        ({
        auto cp_1 = cp;
        auto n_2 = n;
        auto named__3 = named_;
        auto t_4 = t;
        auto x_5 = x;
        call_then(crate::emit::cpp::start_cpp_type(cp_1, t_4), [=, n_2 = std::move(n_2), named__3 = std::move(named__3), x_5 = std::move(x_5)](Text cpp_type_9662) { return call_then(crate::emit::cpp::expr::start_cpp_expr(cp_1, x_5), [=](Text cpp_expr_9699) { return prism_rtl::finished(prism_rtl::cat(cpp_type_9662, " ", var_name(named__3, n_2), " = ", cpp_expr_9699, ";")); }); });
    });
    })
        : prism_rtl::is<crate::lower::model::Pa::PaTuple>(p_) ? ({
        auto&& ps = prism_rtl::as<crate::lower::model::Pa::PaTuple>(p_).a0;
        fold(ps, true, [&](const bool& f, const crate::lower::model::Pa& q) { return prism_rtl::deref(f) && is_name(q); })
        ? ({
        auto cp_1 = cp;
        auto ps_2 = ps;
        auto x_3 = x;
        call_then(crate::emit::cpp::expr::start_cpp_expr(cp_1, x_3), [=, ps_2 = std::move(ps_2)](Text cpp_expr_9832) { return prism_rtl::finished(prism_rtl::cat("auto [", crate::syntax::lexer::chars::join(each(ps_2, [&](const crate::lower::model::Pa& q) { return pat_name(q); }), Text::lit(", ")), "] = ", cpp_expr_9832, ";")); });
    })
        : prism_rtl::more(prism_rtl::rc(LetThrough(cp, p_, x)));
    })
        : prism_rtl::more(prism_rtl::rc(LetThrough(cp, p_, x)));
    });
}


/// `Start CppLet, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_let(crate::emit::cpp::Cp cp, crate::emit::cpp::Cp named_, crate::lower::model::Pa p_, crate::lower::model::Ex x) {
    return prism_rtl::make_rc<CppLet>(cp, named_, p_, x);
}


/// LetThrough: unbounded fn Cp, Pa, Ex -> Text
Text let_through(const crate::emit::cpp::Cp& cp, const crate::lower::model::Pa& p_, const crate::lower::model::Ex& x) {
    auto t_1 = prism_rtl::cat("_", or_(first_binder(p_), Text::lit("t")));
    return prism_rtl::cat("auto&& ", t_1, " = ", crate::emit::cpp::expr::cpp_expr(cp, x), ";\n", crate::syntax::lexer::chars::join(crate::emit::cpp::patterns::pat_binds(cp, p_, t_1), Text::lit("\n")));
}


prism_rtl::Turn<Text> LetThrough::cycle() const {
    const auto& cp = this->cp;
    const auto& p_ = this->p_;
    const auto& x = this->x;
    auto cp_1 = cp;
    auto p__2 = p_;
    auto x_3 = x;
    return call_then(start_first_binder(p__2), [=](std::optional<Text> first_binder_10091) {
        return ({
            auto t_4 = prism_rtl::cat("_", or_(first_binder_10091, Text::lit("t")));
            call_then(crate::emit::cpp::expr::start_cpp_expr(cp_1, x_3), [=, t_4 = std::move(t_4)](Text cpp_expr_10133) { return call_then(crate::emit::cpp::patterns::start_pat_binds(cp_1, p__2, t_4), [=](Array<Text> pat_binds_10157) { return prism_rtl::finished(prism_rtl::cat("auto&& ", t_4, " = ", cpp_expr_10133, ";\n", crate::syntax::lexer::chars::join(pat_binds_10157, Text::lit("\n")))); }); });
        });
    });
}


/// `Start LetThrough, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_let_through(crate::emit::cpp::Cp cp, crate::lower::model::Pa p_, crate::lower::model::Ex x) {
    return prism_rtl::make_rc<LetThrough>(cp, p_, x);
}


/// ?FirstBinder: unbounded fn Pa -> ?Text
std::optional<Text> first_binder(const crate::lower::model::Pa& p_) {
    if (prism_rtl::is<crate::lower::model::Pa::PaBind>(p_)) {
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaBind>(p_).a0;
        return std::optional(n);
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaMut>(p_)) {
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaMut>(p_).a0;
        return std::optional(n);
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaTyped>(p_)) {
        auto&& q = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_).a0;
        return first_binder(prism_rtl::deref(prism_rtl::deref(q)));
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaCtor>(p_)) {
        auto&& ps = prism_rtl::as<crate::lower::model::Pa::PaCtor>(p_).a1;
        return run_to_end(fold_job(ps, std::optional<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::optional<Text>>(std::tuple<std::optional<Text>, crate::lower::model::Pa>)>>(prism_rtl::rc([=](std::tuple<std::optional<Text>, crate::lower::model::Pa> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto f_opt = p0;
                    auto q = p1;
                    ({
                    prism_rtl::is_some(f_opt) ? ({
                    auto&& b = prism_rtl::some_of(f_opt);
                    prism_rtl::finished(std::optional(b));
                })
                    : prism_rtl::is_none(f_opt) ? prism_rtl::more(prism_rtl::rc(FirstBinder(q)))
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaTuple>(p_)) {
        auto&& ps = prism_rtl::as<crate::lower::model::Pa::PaTuple>(p_).a0;
        return run_to_end(fold_job(ps, std::optional<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::optional<Text>>(std::tuple<std::optional<Text>, crate::lower::model::Pa>)>>(prism_rtl::rc([=](std::tuple<std::optional<Text>, crate::lower::model::Pa> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto f_opt = p0;
                    auto q = p1;
                    ({
                    prism_rtl::is_some(f_opt) ? ({
                    auto&& b = prism_rtl::some_of(f_opt);
                    prism_rtl::finished(std::optional(b));
                })
                    : prism_rtl::is_none(f_opt) ? prism_rtl::more(prism_rtl::rc(FirstBinder(q)))
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            }));
        }))));
    }
    {
        return std::optional<Text>{};
    }
}


prism_rtl::Turn<std::optional<Text>> FirstBinder::cycle() const {
    const auto& p_ = this->p_;
    return ({
        prism_rtl::is<crate::lower::model::Pa::PaBind>(p_) ? ({
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaBind>(p_).a0;
        prism_rtl::finished(std::optional(n));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaMut>(p_) ? ({
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaMut>(p_).a0;
        prism_rtl::finished(std::optional(n));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaTyped>(p_) ? ({
        auto&& q = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_).a0;
        prism_rtl::more(prism_rtl::rc(FirstBinder(prism_rtl::deref(prism_rtl::deref(q)))));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaCtor>(p_) ? ({
        auto&& ps = prism_rtl::as<crate::lower::model::Pa::PaCtor>(p_).a1;
        fold_job(ps, std::optional<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::optional<Text>>(std::tuple<std::optional<Text>, crate::lower::model::Pa>)>>(prism_rtl::rc([=](std::tuple<std::optional<Text>, crate::lower::model::Pa> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto f_opt = p0;
                auto q = p1;
                ({
                prism_rtl::is_some(f_opt) ? ({
                auto&& b = prism_rtl::some_of(f_opt);
                prism_rtl::finished(std::optional(b));
            })
                : prism_rtl::is_none(f_opt) ? prism_rtl::more(prism_rtl::rc(FirstBinder(q)))
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::lower::model::Pa::PaTuple>(p_) ? ({
        auto&& ps = prism_rtl::as<crate::lower::model::Pa::PaTuple>(p_).a0;
        fold_job(ps, std::optional<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::optional<Text>>(std::tuple<std::optional<Text>, crate::lower::model::Pa>)>>(prism_rtl::rc([=](std::tuple<std::optional<Text>, crate::lower::model::Pa> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto f_opt = p0;
                auto q = p1;
                ({
                prism_rtl::is_some(f_opt) ? ({
                auto&& b = prism_rtl::some_of(f_opt);
                prism_rtl::finished(std::optional(b));
            })
                : prism_rtl::is_none(f_opt) ? prism_rtl::more(prism_rtl::rc(FirstBinder(q)))
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
    })))->cycle();
    })
        : prism_rtl::finished(std::optional<Text>{});
    });
}


/// `Start FirstBinder, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<Text>> start_first_binder(crate::lower::model::Pa p_) {
    return prism_rtl::make_rc<FirstBinder>(p_);
}


/// IsName: fn Pa -> Bool
bool is_name(const crate::lower::model::Pa& pa0) {
    if (prism_rtl::is<crate::lower::model::Pa::PaBind>(pa0)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaMut>(pa0)) {
        return true;
    }
    {
        auto&& other = pa0;
        return false;
    }
}


/// PatName: fn Pa -> Text
Text pat_name(const crate::lower::model::Pa& pa0) {
    if (prism_rtl::is<crate::lower::model::Pa::PaBind>(pa0)) {
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaBind>(pa0).a0;
        return crate::emit::cpp::cpp_id(n);
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaMut>(pa0)) {
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaMut>(pa0).a0;
        return crate::emit::cpp::cpp_id(n);
    }
    {
        auto&& other = pa0;
        return Text::lit("_");
    }
}


/// CppIfLet: unbounded fn Cp, Pa, Ex, [Do], [Do] -> Text
Text cpp_if_let(const crate::emit::cpp::Cp& cp0, const crate::lower::model::Pa& p_, const crate::lower::model::Ex& x, const Array<crate::lower::model::Do>& t, const Array<crate::lower::model::Do>& e) {
    auto cp = unbind(cp0, pat_names(p_));
    auto v_ = Text::lit("_m");
    auto head = prism_rtl::cat("if (auto&& _m = ", crate::emit::cpp::expr::cpp_expr(cp, x), "; ", crate::emit::cpp::patterns::conds(crate::emit::cpp::patterns::pat_conds(cp, p_, v_)), ")");
    auto body = crate::syntax::lexer::chars::join(append(crate::emit::cpp::patterns::pat_binds(cp, p_, v_), Array(std::vector{cpp_statements(cp, t)})), Text::lit("\n"));
    return prism_rtl::cat(crate::emit::cpp::templates::items::block(head, body), cpp_else(cp, e));
}


prism_rtl::Turn<Text> CppIfLet::cycle() const {
    const auto& cp0 = this->cp0;
    const auto& p_ = this->p_;
    const auto& x = this->x;
    const auto& t = this->t;
    const auto& e = this->e;
    auto cp0_1 = cp0;
    auto e_2 = e;
    auto p__3 = p_;
    auto t_4 = t;
    auto x_5 = x;
    return call_then(start_pat_names(p__3), [=](Array<Text> pat_names_10944) {
        return ({
            auto cp = unbind(cp0_1, pat_names_10944);
            auto v_ = Text::lit("_m");
            call_then(crate::emit::cpp::expr::start_cpp_expr(cp, x_5), [=, v_ = std::move(v_)](Text cpp_expr_11006) {
            return call_then(crate::emit::cpp::patterns::start_pat_conds(cp, p__3, v_), [=](Array<Text> pat_conds_11030) {
                return ({
                    auto head = prism_rtl::cat("if (auto&& _m = ", cpp_expr_11006, "; ", crate::emit::cpp::patterns::conds(pat_conds_11030), ")");
                    call_then(crate::emit::cpp::patterns::start_pat_binds(cp, p__3, v_), [=, head = std::move(head)](Array<Text> pat_binds_11081) {
                    return call_then(start_cpp_statements(cp, t_4), [=](Text cpp_statements_11104) {
                        return ({
                            auto body = crate::syntax::lexer::chars::join(append(pat_binds_11081, Array(std::vector{cpp_statements_11104})), Text::lit("\n"));
                            call_then(start_cpp_else(cp, e_2), [=, body = std::move(body)](Text cpp_else_11158) { return prism_rtl::finished(prism_rtl::cat(crate::emit::cpp::templates::items::block(head, body), cpp_else_11158)); });
                        });
                    });
                });
                });
            });
        });
        });
    });
}


/// `Start CppIfLet, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_if_let(crate::emit::cpp::Cp cp0, crate::lower::model::Pa p_, crate::lower::model::Ex x, Array<crate::lower::model::Do> t, Array<crate::lower::model::Do> e) {
    return prism_rtl::make_rc<CppIfLet>(cp0, p_, x, t, e);
}


/// CppDoMatch: unbounded fn Cp, Ex, [((Pa, [Do]))] -> Text
Text cpp_do_match(const crate::emit::cpp::Cp& cp, const crate::lower::model::Ex& x, const Array<std::tuple<crate::lower::model::Pa, Array<crate::lower::model::Do>>>& cases) {
    auto v_ = Text::lit("_m");
    auto arms = run_to_end(each_job(cases, ({
        auto cp_1 = cp;
        auto v__2 = v_;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, Text>>(std::tuple<crate::lower::model::Pa, Array<crate::lower::model::Do>>)>>(prism_rtl::rc([=, cp_1 = std::move(cp_1), v__2 = std::move(v__2)](std::tuple<crate::lower::model::Pa, Array<crate::lower::model::Do>> p0) {
        return ({
            auto cp_1_3 = cp_1;
            auto v__2_3 = v__2;
            entered(once_job([=, cp_1_3 = std::move(cp_1_3), v__2_3 = std::move(v__2_3)]() {
            return ({
                auto [p_, body] = p0;
                call_then(crate::emit::cpp::patterns::start_pat_conds(cp_1_3, p_, v__2_3), [=](Array<Text> pat_conds_11338) {
                return ({
                    auto tests = pat_conds_11338;
                    call_then(crate::emit::cpp::patterns::start_pat_binds(cp_1_3, p_, v__2_3), [=, tests = std::move(tests)](Array<Text> pat_binds_11390) {
                    return call_then(start_cpp_statements(cp_1_3, body), [=](Text cpp_statements_11413) {
                        return ({
                            auto inner = crate::syntax::lexer::chars::join(append(pat_binds_11390, Array(std::vector{cpp_statements_11413})), Text::lit("\n"));
                            (prism_rtl::finished(std::tuple{tests, inner}));
                        });
                    });
                });
                });
            });
            });
        }));
        });
    }));
    })));
    auto blocks = each(crate::check::errors::range0(len(arms)), [&](const Nat& i) {
        return ({
            auto [tests, inner] = or_(index(arms, i), std::tuple{Array<Text>{}, Text::lit("")});
            auto head = i == Nat(0u)
                ? prism_rtl::cat("if (", crate::emit::cpp::patterns::conds(tests), ")")
                : len(tests) == Nat(0u)
                ? Text::lit("else")
                : prism_rtl::cat("else if (", crate::emit::cpp::patterns::conds(tests), ")");
            (crate::emit::cpp::templates::items::block(head, inner));
        });
    });
    return crate::emit::cpp::templates::items::braced(prism_rtl::cat("auto&& _m = ", crate::emit::cpp::expr::cpp_expr(cp, x), ";\n", crate::syntax::lexer::chars::join(blocks, Text::lit(" "))));
}


prism_rtl::Turn<Text> CppDoMatch::cycle() const {
    const auto& cp = this->cp;
    const auto& x = this->x;
    const auto& cases = this->cases_;
    auto v_ = Text::lit("_m");
    auto cases_1 = cases;
    auto cp_2 = cp;
    auto x_3 = x;
    return call_value(each_job(cases_1, ({
        auto cp_2_4 = cp_2;
        auto v__4 = v_;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, Text>>(std::tuple<crate::lower::model::Pa, Array<crate::lower::model::Do>>)>>(prism_rtl::rc([=, cp_2_4 = std::move(cp_2_4), v__4 = std::move(v__4)](std::tuple<crate::lower::model::Pa, Array<crate::lower::model::Do>> p0) {
        return ({
            auto cp_2_4_5 = cp_2_4;
            auto v__4_5 = v__4;
            entered(once_job([=, cp_2_4_5 = std::move(cp_2_4_5), v__4_5 = std::move(v__4_5)]() {
            return ({
                auto [p_, body] = p0;
                call_then(crate::emit::cpp::patterns::start_pat_conds(cp_2_4_5, p_, v__4_5), [=](Array<Text> pat_conds_11338) {
                return ({
                    auto tests = pat_conds_11338;
                    call_then(crate::emit::cpp::patterns::start_pat_binds(cp_2_4_5, p_, v__4_5), [=, tests = std::move(tests)](Array<Text> pat_binds_11390) {
                    return call_then(start_cpp_statements(cp_2_4_5, body), [=](Text cpp_statements_11413) {
                        return ({
                            auto inner = crate::syntax::lexer::chars::join(append(pat_binds_11390, Array(std::vector{cpp_statements_11413})), Text::lit("\n"));
                            (prism_rtl::finished(std::tuple{tests, inner}));
                        });
                    });
                });
                });
            });
            });
        }));
        });
    }));
    })), [=](Array<std::tuple<Array<Text>, Text>> each_11291) {
        return ({
            auto arms = each_11291;
            auto blocks = each(crate::check::errors::range0(len(arms)), [&](const Nat& i) {
                return ({
                    auto [tests, inner] = or_(index(arms, i), std::tuple{Array<Text>{}, Text::lit("")});
                    auto head = i == Nat(0u)
                        ? prism_rtl::cat("if (", crate::emit::cpp::patterns::conds(tests), ")")
                        : len(tests) == Nat(0u)
                        ? Text::lit("else")
                        : prism_rtl::cat("else if (", crate::emit::cpp::patterns::conds(tests), ")");
                    (crate::emit::cpp::templates::items::block(head, inner));
                });
            });
            call_then(crate::emit::cpp::expr::start_cpp_expr(cp_2, x_3), [=, blocks = std::move(blocks)](Text cpp_expr_11743) { return prism_rtl::finished(crate::emit::cpp::templates::items::braced(prism_rtl::cat("auto&& _m = ", cpp_expr_11743, ";\n", crate::syntax::lexer::chars::join(blocks, Text::lit(" "))))); });
        });
    });
}


/// `Start CppDoMatch, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_do_match(crate::emit::cpp::Cp cp, crate::lower::model::Ex x, Array<std::tuple<crate::lower::model::Pa, Array<crate::lower::model::Do>>> cases_) {
    return prism_rtl::make_rc<CppDoMatch>(cp, x, cases_);
}


/// CppFor: unbounded fn Cp, Pa, Ex, [Do] -> Text
Text cpp_for(const crate::emit::cpp::Cp& cp0, const crate::lower::model::Pa& p_, const crate::lower::model::Ex& x, const Array<crate::lower::model::Do>& body) {
    return cpp_for_in(unbind(cp0, pat_names(p_)), p_, crate::emit::cpp::expr::cpp_place(cp0, x), body);
}


prism_rtl::Turn<Text> CppFor::cycle() const {
    const auto& cp0 = this->cp0;
    const auto& p_ = this->p_;
    const auto& x = this->x;
    const auto& body = this->body;
    auto body_1 = body;
    auto cp0_2 = cp0;
    auto p__3 = p_;
    auto x_4 = x;
    return call_then(start_pat_names(p__3), [=](Array<Text> pat_names_11957) { return call_then(crate::emit::cpp::expr::start_cpp_place(cp0_2, x_4), [=](Text cpp_place_11975) { return prism_rtl::more(prism_rtl::rc(CppForIn(unbind(cp0_2, pat_names_11957), p__3, cpp_place_11975, body_1))); }); });
}


/// `Start CppFor, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_for(crate::emit::cpp::Cp cp0, crate::lower::model::Pa p_, crate::lower::model::Ex x, Array<crate::lower::model::Do> body) {
    return prism_rtl::make_rc<CppFor>(cp0, p_, x, body);
}


/// CppForIn: unbounded fn Cp, Pa, Text, [Do] -> Text
Text cpp_for_in(const crate::emit::cpp::Cp& cp, const crate::lower::model::Pa& p_, const Text& xs, const Array<crate::lower::model::Do>& body) {
    if (prism_rtl::is<crate::lower::model::Pa::PaBind>(p_)) {
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaBind>(p_).a0;
        return crate::emit::cpp::templates::items::block(prism_rtl::cat("for (auto&& ", crate::emit::cpp::cpp_id(n), " : ", xs, ")"), cpp_statements(cp, body));
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaMut>(p_)) {
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaMut>(p_).a0;
        return crate::emit::cpp::templates::items::block(prism_rtl::cat("for (auto ", crate::emit::cpp::cpp_id(n), " : ", xs, ")"), cpp_statements(cp, body));
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaTuple>(p_)) {
        auto&& ps = prism_rtl::as<crate::lower::model::Pa::PaTuple>(p_).a0;
        return fold(ps, true, [&](const bool& f, const crate::lower::model::Pa& q) { return prism_rtl::deref(f) && is_name(q); })
            ? crate::emit::cpp::templates::items::block(prism_rtl::cat("for (auto&& [", crate::syntax::lexer::chars::join(each(ps, [&](const crate::lower::model::Pa& q) { return pat_name(q); }), Text::lit(", ")), "] : ", xs, ")"), cpp_statements(cp, body))
            : crate::emit::cpp::templates::items::block(prism_rtl::cat("for (auto&& _e : ", xs, ")"), crate::syntax::lexer::chars::join(append(crate::emit::cpp::patterns::pat_binds(cp, p_, Text::lit("_e")), Array(std::vector{cpp_statements(cp, body)})), Text::lit("\n")));
    }
    {
        return crate::emit::cpp::templates::items::block(prism_rtl::cat("for (auto&& _e : ", xs, ")"), crate::syntax::lexer::chars::join(append(crate::emit::cpp::patterns::pat_binds(cp, p_, Text::lit("_e")), Array(std::vector{cpp_statements(cp, body)})), Text::lit("\n")));
    }
}


prism_rtl::Turn<Text> CppForIn::cycle() const {
    const auto& cp = this->cp;
    const auto& p_ = this->p_;
    const auto& xs = this->xs;
    const auto& body = this->body;
    return ({
        prism_rtl::is<crate::lower::model::Pa::PaBind>(p_) ? ({
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaBind>(p_).a0;
        ({
        auto body_1 = body;
        auto cp_2 = cp;
        auto n_3 = n;
        auto xs_4 = xs;
        call_then(start_cpp_statements(cp_2, body_1), [=, n_3 = std::move(n_3), xs_4 = std::move(xs_4)](Text cpp_statements_12142) { return prism_rtl::finished(crate::emit::cpp::templates::items::block(prism_rtl::cat("for (auto&& ", crate::emit::cpp::cpp_id(n_3), " : ", xs_4, ")"), cpp_statements_12142)); });
    });
    })
        : prism_rtl::is<crate::lower::model::Pa::PaMut>(p_) ? ({
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaMut>(p_).a0;
        ({
        auto body_1 = body;
        auto cp_2 = cp;
        auto n_3 = n;
        auto xs_4 = xs;
        call_then(start_cpp_statements(cp_2, body_1), [=, n_3 = std::move(n_3), xs_4 = std::move(xs_4)](Text cpp_statements_12217) { return prism_rtl::finished(crate::emit::cpp::templates::items::block(prism_rtl::cat("for (auto ", crate::emit::cpp::cpp_id(n_3), " : ", xs_4, ")"), cpp_statements_12217)); });
    });
    })
        : prism_rtl::is<crate::lower::model::Pa::PaTuple>(p_) ? ({
        auto&& ps = prism_rtl::as<crate::lower::model::Pa::PaTuple>(p_).a0;
        fold(ps, true, [&](const bool& f, const crate::lower::model::Pa& q) { return prism_rtl::deref(f) && is_name(q); })
        ? ({
        auto body_1 = body;
        auto cp_2 = cp;
        auto ps_3 = ps;
        auto xs_4 = xs;
        call_then(start_cpp_statements(cp_2, body_1), [=, ps_3 = std::move(ps_3), xs_4 = std::move(xs_4)](Text cpp_statements_12378) { return prism_rtl::finished(crate::emit::cpp::templates::items::block(prism_rtl::cat("for (auto&& [", crate::syntax::lexer::chars::join(each(ps_3, [&](const crate::lower::model::Pa& q) { return pat_name(q); }), Text::lit(", ")), "] : ", xs_4, ")"), cpp_statements_12378)); });
    })
        : ({
        auto body_1 = body;
        auto cp_2 = cp;
        auto p__3 = p_;
        auto xs_4 = xs;
        call_then(crate::emit::cpp::patterns::start_pat_binds(cp_2, p__3, Text::lit("_e")), [=, body_1 = std::move(body_1), xs_4 = std::move(xs_4)](Array<Text> pat_binds_12463) { return call_then(start_cpp_statements(cp_2, body_1), [=](Text cpp_statements_12489) { return prism_rtl::finished(crate::emit::cpp::templates::items::block(prism_rtl::cat("for (auto&& _e : ", xs_4, ")"), crate::syntax::lexer::chars::join(append(pat_binds_12463, Array(std::vector{cpp_statements_12489})), Text::lit("\n")))); }); });
    });
    })
        : ({
        auto body_1 = body;
        auto cp_2 = cp;
        auto p__3 = p_;
        auto xs_4 = xs;
        call_then(crate::emit::cpp::patterns::start_pat_binds(cp_2, p__3, Text::lit("_e")), [=, body_1 = std::move(body_1), xs_4 = std::move(xs_4)](Array<Text> pat_binds_12585) { return call_then(start_cpp_statements(cp_2, body_1), [=](Text cpp_statements_12611) { return prism_rtl::finished(crate::emit::cpp::templates::items::block(prism_rtl::cat("for (auto&& _e : ", xs_4, ")"), crate::syntax::lexer::chars::join(append(pat_binds_12585, Array(std::vector{cpp_statements_12611})), Text::lit("\n")))); }); });
    });
    });
}


/// `Start CppForIn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_for_in(crate::emit::cpp::Cp cp, crate::lower::model::Pa p_, Text xs, Array<crate::lower::model::Do> body) {
    return prism_rtl::make_rc<CppForIn>(cp, p_, xs, body);
}


/// CppBody: unbounded fn Cp, Ex -> Text
Text cpp_body(const crate::emit::cpp::Cp& cp, const crate::lower::model::Ex& ex1) {
    if (prism_rtl::is<crate::lower::model::Ex::XBlock>(ex1)) {
        auto&& dos = prism_rtl::as<crate::lower::model::Ex::XBlock>(ex1).a0;
        auto&& e = prism_rtl::as<crate::lower::model::Ex::XBlock>(ex1).a1;
        auto [st, cp2] = cpp_statements_cp(cp, dos);
        return len(dos) == Nat(0u)
            ? cpp_body(cp, prism_rtl::deref(prism_rtl::deref(e)))
            : prism_rtl::cat(st, "\n", cpp_body(cp2, prism_rtl::deref(prism_rtl::deref(e))));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XMatch>(ex1)) {
        auto&& s = prism_rtl::as<crate::lower::model::Ex::XMatch>(ex1).a0;
        auto&& arms = prism_rtl::as<crate::lower::model::Ex::XMatch>(ex1).a1;
        auto&& fallback = prism_rtl::as<crate::lower::model::Ex::XMatch>(ex1).a2;
        auto&& t = prism_rtl::as<crate::lower::model::Ex::XMatch>(ex1).a3;
        return crate::emit::cpp::patterns::return_match(cp, prism_rtl::deref(prism_rtl::deref(s)), arms, t);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XChain>(ex1)) {
        auto&& label = prism_rtl::as<crate::lower::model::Ex::XChain>(ex1).a0;
        auto&& s = prism_rtl::as<crate::lower::model::Ex::XChain>(ex1).a1;
        auto&& arms = prism_rtl::as<crate::lower::model::Ex::XChain>(ex1).a2;
        auto&& t = prism_rtl::as<crate::lower::model::Ex::XChain>(ex1).a3;
        return crate::emit::cpp::patterns::return_match(cp, prism_rtl::deref(prism_rtl::deref(s)), arms, t);
    }
    {
        auto&& x = ex1;
        return crate::emit::cpp::patterns::leaves(x)
            ? prism_rtl::cat(crate::emit::cpp::expr::cpp_expr(cp, x), ";")
            : prism_rtl::cat("return ", cpp_returned(cp, x), ";");
    }
}


prism_rtl::Turn<Text> CppBody::cycle() const {
    const auto& cp = this->cp;
    const auto& ex1 = this->ex1;
    return ({
        prism_rtl::is<crate::lower::model::Ex::XBlock>(ex1) ? ({
        auto&& dos = prism_rtl::as<crate::lower::model::Ex::XBlock>(ex1).a0;
        auto&& e = prism_rtl::as<crate::lower::model::Ex::XBlock>(ex1).a1;
        ({
        auto cp_1 = cp;
        auto dos_2 = dos;
        auto e_3 = prism_rtl::deref(prism_rtl::deref(e));
        call_then(start_cpp_statements_cp(cp_1, dos_2), [=, e_3 = std::move(e_3)](std::tuple<Text, crate::emit::cpp::Cp> cpp_statements_cp_12799) {
        return ({
            auto [st, cp2] = cpp_statements_cp_12799;
            len(dos_2) == Nat(0u)
            ? prism_rtl::more(prism_rtl::rc(CppBody(cp_1, e_3)))
            : call_then(start_cpp_body(cp2, e_3), [=](Text cpp_body_12874) { return prism_rtl::finished(prism_rtl::cat(st, "\n", cpp_body_12874)); });
        });
    });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XMatch>(ex1) ? ({
        auto&& s = prism_rtl::as<crate::lower::model::Ex::XMatch>(ex1).a0;
        auto&& arms = prism_rtl::as<crate::lower::model::Ex::XMatch>(ex1).a1;
        auto&& fallback = prism_rtl::as<crate::lower::model::Ex::XMatch>(ex1).a2;
        auto&& t = prism_rtl::as<crate::lower::model::Ex::XMatch>(ex1).a3;
        prism_rtl::more(prism_rtl::rc(crate::emit::cpp::patterns::ReturnMatch(cp, prism_rtl::deref(prism_rtl::deref(s)), arms, t)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XChain>(ex1) ? ({
        auto&& label = prism_rtl::as<crate::lower::model::Ex::XChain>(ex1).a0;
        auto&& s = prism_rtl::as<crate::lower::model::Ex::XChain>(ex1).a1;
        auto&& arms = prism_rtl::as<crate::lower::model::Ex::XChain>(ex1).a2;
        auto&& t = prism_rtl::as<crate::lower::model::Ex::XChain>(ex1).a3;
        prism_rtl::more(prism_rtl::rc(crate::emit::cpp::patterns::ReturnMatch(cp, prism_rtl::deref(prism_rtl::deref(s)), arms, t)));
    })
        : ({
        auto&& x = ex1;
        crate::emit::cpp::patterns::leaves(x)
        ? ({
        auto cp_1 = cp;
        auto x_2 = x;
        call_then(crate::emit::cpp::expr::start_cpp_expr(cp_1, x_2), [=](Text cpp_expr_13070) { return prism_rtl::finished(prism_rtl::cat(cpp_expr_13070, ";")); });
    })
        : ({
        auto cp_1 = cp;
        auto x_2 = x;
        call_then(start_cpp_returned(cp_1, x_2), [=](Text cpp_returned_13102) { return prism_rtl::finished(prism_rtl::cat("return ", cpp_returned_13102, ";")); });
    });
    });
    });
}


/// `Start CppBody, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_body(crate::emit::cpp::Cp cp, crate::lower::model::Ex ex1) {
    return prism_rtl::make_rc<CppBody>(cp, ex1);
}


/// CppReturned: unbounded fn Cp, Ex -> Text
Text cpp_returned(const crate::emit::cpp::Cp& cp, const crate::lower::model::Ex& ex1) {
    if (prism_rtl::is<crate::lower::model::Ex::XVar>(ex1)) {
        auto&& n = prism_rtl::as<crate::lower::model::Ex::XVar>(ex1).a0;
        return var_name(cp, n);
    }
    {
        auto&& x = ex1;
        return crate::emit::cpp::expr::cpp_expr(cp, x);
    }
}


prism_rtl::Turn<Text> CppReturned::cycle() const {
    const auto& cp = this->cp;
    const auto& ex1 = this->ex1;
    return ({
        prism_rtl::is<crate::lower::model::Ex::XVar>(ex1) ? ({
        auto&& n = prism_rtl::as<crate::lower::model::Ex::XVar>(ex1).a0;
        prism_rtl::finished(var_name(cp, n));
    })
        : ({
        auto&& x = ex1;
        prism_rtl::more(prism_rtl::rc(crate::emit::cpp::expr::CppExpr(cp, x)));
    });
    });
}


/// `Start CppReturned, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_returned(crate::emit::cpp::Cp cp, crate::lower::model::Ex ex1) {
    return prism_rtl::make_rc<CppReturned>(cp, ex1);
}

}  // namespace crate::emit::cpp::stmts


// The module `Emit.Cpp.Templates`, from `target/bootstrap/cpp-src/prismc/emit/cpp/templates/mod.prism`.
namespace crate::emit::cpp::templates {

/// CppMakefile: fn Text, Text, Text, Text -> Text
Text cpp_makefile(const Text& name, const Text& runtime, const Text& sources, const Text& canvas) {
    auto out = std::string();
    out.append("# Emitted by prismc. Edit the Prism sources, not this file.\n#   make                   the program, with $(CXX) (g++ by default)\n#   make CXX=clang++\n.DEFAULT_GOAL := ");
    place(out, name, std::nullopt);
    out.append("\n# The repository root: PRISM_ROOT from the environment (the prism script and the bootstrap\n# export their own location), else from this Makefile\'s path, which keeps a symlinked\n# build directory\'s logical path where `make -C`\'s current directory would not.\nHERE := $(patsubst %/,%,$(dir $(abspath $(lastword $(MAKEFILE_LIST)))))\nPRISM_ROOT ?= $(if $(filter /%,");
    place(out, runtime, std::nullopt);
    out.append("),");
    place(out, runtime, std::nullopt);
    out.append(",$(abspath $(HERE)/");
    place(out, runtime, std::nullopt);
    out.append("))\nRT := $(PRISM_ROOT)/runtime/cpp\nWORLD := $(PRISM_ROOT)/worlds/cli/cpp\nCXX ?= g++\nOPT ?= -O3\nCONFIG ?= prog-$(notdir $(CXX))$(subst $() ,,$(OPT))\nLIB := $(RT)/build/$(CONFIG)/libprism_rtl.a\nFLAGS := -std=gnu++20 $(OPT) -I$(RT)/include -I$(WORLD)/include -Isrc -Wall -Wno-unused -Wno-unused-parameter -Wno-unused-label\nSRCS := src/main.cpp ");
    place(out, sources, std::nullopt);
    out.append("\nOBJS := $(SRCS:src/%.cpp=build/%.o)\nWORLD_LIBS :=\nSYS_LIBS :=\n# The runtime\'s regular expressions are on RE2 (runtime/cpp/README.md), which the library\n# needs at link time whenever a program reaches them.\nRE2_LIBS := $(shell pkg-config --libs re2)\n# The allocator is jemalloc, found with pkg-config (runtime/cpp/README.md, pick AL); a\n# sanitizer build (`-fsanitize` in OPT, prism\'s PRISM_SANITIZE) keeps the C library\'s,\n# which AddressSanitizer replaces with its own.\nifeq ($(findstring -fsanitize,$(OPT)),)\nifneq ($(shell pkg-config --exists jemalloc && echo found),found)\n$(error the C++ program links jemalloc, found with pkg-config, and pkg-config does not find it: apt install libjemalloc-dev pkg-config (Debian, Ubuntu), brew install jemalloc (macOS))\nendif\nALLOC_LIBS := $(shell pkg-config --libs jemalloc)\nelse\nALLOC_LIBS :=\nendif\n");
    place(out, canvas, std::optional(0u));
    out.append("\n");
    place(out, name, std::nullopt);
    out.append(": $(OBJS) build/cli.o $(LIB) $(WORLD_LIBS)\n\t$(CXX) $(FLAGS) -o $@ $(OBJS) build/cli.o $(WORLD_LIBS) $(LIB) $(RE2_LIBS) $(SYS_LIBS) $(ALLOC_LIBS)\n\nbuild/cli.o: $(WORLD)/src/cli.cpp $(WORLD)/include/prism_world_cli/cli.hpp\n\t@mkdir -p build\n\t$(CXX) $(FLAGS) -c $< -o $@\n\nbuild/%.o: src/%.cpp\n\t@mkdir -p $(dir $@)\n\t$(CXX) $(FLAGS) -MMD -MP -c $< -o $@\n\n-include $(OBJS:.o=.d)\n\n$(LIB): FORCE\n\t@$(MAKE) -s -C $(RT) lib CXX=$(CXX) CONFIG=$(CONFIG) OPT=\"$(OPT)\"\n\nFORCE:\n.PHONY: FORCE\n");
    return Text(std::move(out));
}


/// CppMakefileCanvas: fn Text -> Text
Text cpp_makefile_canvas(const Text& runtime) {
    auto out = std::string();
    out.append("CANVAS := $(PRISM_ROOT)/worlds/canvas/cpp\nFLAGS += -I$(CANVAS)/include $(shell pkg-config --cflags cairo freetype2)\nWORLD_LIBS := $(CANVAS)/build/$(CONFIG)/libprism_world_canvas.a\nifeq ($(shell uname -s),Darwin)\nSYS_LIBS := $(shell pkg-config --libs cairo freetype2) -framework Cocoa -framework QuartzCore\nelse\nSYS_LIBS := $(shell pkg-config --libs cairo freetype2 x11 xext)\nendif\n\n$(WORLD_LIBS): FORCE | $(LIB)\n\t@$(MAKE) -s -C $(CANVAS) lib CXX=$(CXX) CONFIG=$(CONFIG) OPT=\"$(OPT)\"\n");
    return Text(std::move(out));
}


/// CppDeclHeader: fn Text, Text, Text -> Text
Text cpp_decl_header(const Text& title, const Text& includes, const Text& forward) {
    auto out = std::string();
    out.append("// ");
    place(out, title, std::nullopt);
    out.append(": its types, nodes and jobs declared, emitted by prismc (claude/backend.md).\n// Edit the Prism source, not this file.\n#pragma once\n\n#include \"prelude.hpp\"\n");
    place(out, includes, std::optional(0u));
    out.append("\nnamespace crate {\n\nusing namespace prelude;\n\n");
    place(out, forward, std::optional(0u));
    out.append("\n}  // namespace crate\n");
    return Text(std::move(out));
}


/// CppTypesHeader: fn Text, Text, Text -> Text
Text cpp_types_header(const Text& title, const Text& includes, const Text& values_) {
    auto out = std::string();
    out.append("// ");
    place(out, title, std::nullopt);
    out.append(": its value types (records, tags, newtypes and choices with their cases), each\n// after the types it holds by value, emitted by prismc (claude/backend.md). Edit the Prism\n// source, not this file.\n#pragma once\n\n");
    place(out, includes, std::optional(0u));
    out.append("\nnamespace crate {\n\nusing namespace prelude;\n\n");
    place(out, values_, std::optional(0u));
    out.append("\n}  // namespace crate\n");
    return Text(std::move(out));
}


/// CppTypesInGroup: fn Text, Text -> Text
Text cpp_types_in_group(const Text& title, const Text& group) {
    auto out = std::string();
    out.append("// ");
    place(out, title, std::nullopt);
    out.append(": its records, tags and newtypes and its choices\' cases are defined with those\n// of the modules whose types it holds by value and which hold its own, in `");
    place(out, group, std::nullopt);
    out.append(".types.hpp`,\n// emitted by prismc (claude/backend.md). Edit the Prism source, not this file.\n#pragma once\n\n#include <");
    place(out, group, std::nullopt);
    out.append(".types.hpp>\n");
    return Text(std::move(out));
}


/// CppModHeader: fn Text, Text, Text, Text, Text -> Text
Text cpp_mod_header(const Text& title, const Text& includes, const Text& protos, const Text& outer, const Text& classes) {
    auto out = std::string();
    out.append("// ");
    place(out, title, std::nullopt);
    out.append(": its functions\' prototypes and its nodes and jobs, emitted by prismc\n// (claude/backend.md). Edit the Prism source, not this file.\n#pragma once\n\n");
    place(out, includes, std::optional(0u));
    out.append("\nnamespace crate {\n\nusing namespace prelude;\n\n");
    place(out, protos, std::optional(0u));
    out.append("\n");
    place(out, outer, std::optional(0u));
    out.append("\n");
    place(out, classes, std::optional(0u));
    out.append("\n}  // namespace crate\n");
    return Text(std::move(out));
}


/// CppGenericHeader: fn Text, Text, Text -> Text
Text cpp_generic_header(const Text& title, const Text& includes, const Text& generic) {
    auto out = std::string();
    out.append("// ");
    place(out, title, std::nullopt);
    out.append(": its generic functions\' and types\' definitions, emitted by prismc\n// (claude/backend.md). Edit the Prism source, not this file.\n#pragma once\n\n");
    place(out, includes, std::optional(0u));
    out.append("\nnamespace crate {\n\nusing namespace prelude;\n\n");
    place(out, generic, std::optional(0u));
    out.append("\n}  // namespace crate\n");
    return Text(std::move(out));
}


/// CppElemDecl: fn Text, Text, Text -> Text
Text cpp_elem_decl(const Text& includes, const Text& forward, const Text& rows) {
    auto out = std::string();
    out.append("// The program\'s `Elem` and `Answer` declared, and the prelude\'s rows, emitted by prismc\n// (claude/backend.md). Edit the Prism sources, not this file.\n#pragma once\n\n#include \"prelude.hpp\"\n");
    place(out, includes, std::optional(0u));
    out.append("\nnamespace crate {\n\nusing namespace prelude;\n\n");
    place(out, forward, std::optional(0u));
    out.append("\nnamespace prelude {\n\n");
    place(out, rows, std::optional(0u));
    out.append("\n}  // namespace prelude\n\n}  // namespace crate\n");
    return Text(std::move(out));
}


/// CppElemTypes: fn Text, Text -> Text
Text cpp_elem_types(const Text& includes, const Text& values_) {
    auto out = std::string();
    out.append("// The program\'s `Elem` and `Answer` with their cases, emitted by prismc (claude/backend.md).\n// Edit the Prism sources, not this file.\n#pragma once\n\n#include \"elem.decl.hpp\"\n");
    place(out, includes, std::optional(0u));
    out.append("\nnamespace crate {\n\nusing namespace prelude;\n\n");
    place(out, values_, std::optional(0u));
    out.append("\n}  // namespace crate\n");
    return Text(std::move(out));
}


/// CppUnit: fn Text, Text, Text -> Text
Text cpp_unit(const Text& title, const Text& includes, const Text& parts) {
    auto out = std::string();
    out.append("// ");
    place(out, title, std::nullopt);
    out.append(", emitted by prismc: the functions, nodes\' methods and types\' printers\n// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this\n// file.\n");
    place(out, includes, std::optional(0u));
    out.append("\n");
    place(out, parts, std::optional(0u));
    return Text(std::move(out));
}


/// CppUnitPart: fn Text, Text, Text, Text -> Text
Text cpp_unit_part(const Text& prism, const Text& path_, const Text& ns, const Text& defs) {
    auto out = std::string();
    out.append("// ");
    place(out, prism, std::nullopt);
    out.append(", from `");
    place(out, path_, std::nullopt);
    out.append("`.\nnamespace crate::");
    place(out, ns, std::nullopt);
    out.append(" {\n\n");
    place(out, defs, std::optional(0u));
    out.append("\n}  // namespace crate::");
    place(out, ns, std::nullopt);
    out.append("\n");
    return Text(std::move(out));
}


/// CppProgramsHeader: fn Text, Text, Text -> Text
Text cpp_programs_header(const Text& name, const Text& includes, const Text& programs) {
    auto out = std::string();
    out.append("// The programs of `");
    place(out, name, std::nullopt);
    out.append("`, emitted by prismc (claude/backend.md): each root\'s class, over\n// every module\'s header. Edit the Prism sources, not this file.\n#pragma once\n\n");
    place(out, includes, std::optional(0u));
    out.append("\nnamespace crate {\n\nusing namespace prelude;\n\n");
    place(out, programs, std::optional(0u));
    out.append("\n}  // namespace crate\n");
    return Text(std::move(out));
}


/// CppMain: fn Text, Text, Text, Text, Text, Text, Text, Text -> Text
Text cpp_main(const Text& name, const Text& includes, const Text& registrations, const Text& checks, const Text& scripts, const Text& world, const Text& run_root, const Text& crate_defs) {
    auto out = std::string();
    out.append("// The program `");
    place(out, name, std::nullopt);
    out.append("`, emitted by prismc from Prism (claude/backend.md): C++ over\n// `prism_rtl`, run under the Test World. Edit the Prism sources, not these files.\n");
    place(out, includes, std::optional(0u));
    out.append("\nnamespace crate {\n\nusing namespace prelude;\n\n");
    place(out, crate_defs, std::optional(0u));
    out.append("\n/// The Test World with every root a test names, and the compiled `check` blocks.\nTestWorld test_world() {\n    TestWorld world;\n    world");
    place(out, registrations, std::nullopt);
    place(out, checks, std::nullopt);
    out.append(";\n    return world;\n}\n\n/// The test scripts compiled with the program: `test` runs these when given none.\nconst std::vector<std::string> SCRIPTS = {\n");
    place(out, scripts, std::optional(4u));
    out.append("};\n\n/// The World the root\'s row asks for: `canvas`, `cli`, or `none` (a row with `Ui` and no\n/// `Gui`, which no World answers).\nconst std::string WORLD = \"");
    place(out, world, std::nullopt);
    out.append("\";\n\n/// The root under the World `world`.\nint run_root(const std::string& world, const std::vector<std::string>& args) {\n");
    place(out, run_root, std::optional(4u));
    out.append("}\n\n}  // namespace crate\n\nint main(int argc, char** argv) {\n    std::vector<std::string> args(argv + 1, argv + argc);\n    // The canvas World keeps the main thread for its windows (AppKit\'s rule on macOS) and\n    // ticks on a big stack of its own.\n    if (auto [world, rest] = crate::prelude::world_option(args, crate::WORLD); world == \"canvas\" && (args.empty() || args[0] != \"test\"))\n        return crate::run_root(world, rest);\n    return crate::prelude::on_big_stack([&] {\n        auto [world, rest] = crate::prelude::world_option(args, crate::WORLD);\n        if ((!args.empty() && args[0] == \"test\") || world == \"test\") {\n            std::vector<std::string> scripts;\n            for (const auto& a : rest)\n                if (a != \"test\") scripts.push_back(a);\n            return crate::prelude::run_scripts(crate::test_world(), scripts, crate::SCRIPTS);\n        }\n        return crate::run_root(world, rest);\n    });\n}\n");
    return Text(std::move(out));
}


/// CppNoRoot: fn Text -> Text
Text cpp_no_root(const Text& name) {
    auto out = std::string();
    out.append("static_cast<void>(world);\nstatic_cast<void>(args);\nstd::fprintf(stderr, \"");
    place(out, name, std::nullopt);
    out.append(": the program has no `@main`; `");
    place(out, name, std::nullopt);
    out.append(" test` runs its tests\\n\");\nreturn 2;\n");
    return Text(std::move(out));
}


/// CppRunRoot: fn Text, Text -> Text
Text cpp_run_root(const Text& program, const Text& canvas) {
    auto out = std::string();
    out.append("if (world == \"cli\") return crate::prelude::run_cli<");
    place(out, program, std::nullopt);
    out.append(">(args);\nif (world == \"canvas\") {\n");
    place(out, canvas, std::optional(4u));
    out.append("}\nif (world == \"none\") {\n    std::fprintf(stderr, \"the root\'s row has Ui.* without Gui.*: no World answers Ui elements alone; emit Gui.* for the canvas World, or pass --world\\n\");\n    return 2;\n}\nstd::fprintf(stderr, \"no World %s (cli, canvas, test)\\n\", world.c_str());\nreturn 2;\n");
    return Text(std::move(out));
}


/// CppCanvasRun: fn Text -> Text
Text cpp_canvas_run(const Text& program) {
    auto out = std::string();
    out.append("static_cast<void>(args);\nreturn prism_world_canvas::run<");
    place(out, program, std::nullopt);
    out.append(">();\n");
    return Text(std::move(out));
}


/// CppNoCanvas: fn Text -> Text
Text cpp_no_canvas(const Text& program) {
    auto out = std::string();
    out.append("std::fprintf(stderr, \"the root\'s row emits no Gui.*, so this program is built without the canvas World\\n\");\nreturn 2;\n");
    return Text(std::move(out));
}


/// CppCanvasInclude: fn Text -> Text
Text cpp_canvas_include(const Text& text0) {
    {
        auto out = std::string();
        out.append("#include \"prism_world_canvas/canvas.hpp\"\n");
        return Text(std::move(out));
    }
}

}  // namespace crate::emit::cpp::templates


// The module `Emit.Cpp.Templates.Items`, from `target/bootstrap/cpp-src/prismc/emit/cpp/templates/items.prism`.
namespace crate::emit::cpp::templates::items {

/// ChoiceClass: fn Text, Text, Text, Text, Text, Text -> Text
Text choice_class(const Text& doc, const Text& gens, const Text& name, const Text& cases, const Text& names, const Text& members) {
    auto out = std::string();
    place(out, doc, std::optional(0u));
    place(out, gens, std::nullopt);
    out.append("class ");
    place(out, name, std::nullopt);
    out.append(" {\npublic:\n    using prism_value = void;\n");
    place(out, cases, std::optional(4u));
    out.append("    using Cases = std::variant<");
    place(out, names, std::nullopt);
    out.append(">;\n    template <class C>\n        requires prism_rtl::one_of<C, ");
    place(out, names, std::nullopt);
    out.append(">\n    ");
    place(out, name, std::nullopt);
    out.append("(C c) : cases_(std::move(c)) {}\n    const Cases& cases() const { return cases_; }\n");
    place(out, members, std::optional(4u));
    out.append("\nprivate:\n    Cases cases_;\n};\n");
    return Text(std::move(out));
}


/// CaseDecl: fn Text, Text -> Text
Text case_decl(const Text& name, const Text& fields) {
    auto out = std::string();
    out.append("struct ");
    place(out, name, std::nullopt);
    out.append(" {\n");
    place(out, fields, std::optional(4u));
    out.append("};\n");
    return Text(std::move(out));
}


/// ValueStruct: fn Text, Text, Text, Text, Text -> Text
Text value_struct(const Text& doc, const Text& gens, const Text& name, const Text& fields, const Text& members) {
    auto out = std::string();
    place(out, doc, std::optional(0u));
    place(out, gens, std::nullopt);
    out.append("struct ");
    place(out, name, std::nullopt);
    out.append(" {\n    using prism_value = void;\n");
    place(out, fields, std::optional(4u));
    out.append("    const ");
    place(out, name, std::nullopt);
    out.append("* operator->() const { return this; }\n    ");
    place(out, name, std::nullopt);
    out.append("* operator->() { return this; }\n");
    place(out, members, std::optional(4u));
    out.append("};\n");
    return Text(std::move(out));
}


/// CppTagStruct: fn Text, Text, Text, Text, Text -> Text
Text cpp_tag_struct(const Text& doc, const Text& name, const Text& fields, const Text& tag_name, const Text& members) {
    auto out = std::string();
    place(out, doc, std::optional(0u));
    out.append("struct ");
    place(out, name, std::nullopt);
    out.append(" {\n    using prism_value = void;\n    /// The tag\'s qualified name, as its `Pod` carries it.\n    static constexpr const char* TAG = \"");
    place(out, tag_name, std::nullopt);
    out.append("\";\n");
    place(out, fields, std::optional(4u));
    out.append("    const ");
    place(out, name, std::nullopt);
    out.append("* operator->() const { return this; }\n    ");
    place(out, name, std::nullopt);
    out.append("* operator->() { return this; }\n    Pod to_pod() const;\n    void show(Printer& p) const;\n");
    place(out, members, std::optional(4u));
    out.append("};\n");
    return Text(std::move(out));
}


/// CppFunction: fn Text, Text, Text -> Text
Text cpp_function(const Text& doc, const Text& signature, const Text& body) {
    auto out = std::string();
    place(out, doc, std::optional(0u));
    place(out, signature, std::nullopt);
    out.append(" {\n");
    place(out, body, std::optional(4u));
    out.append("}\n");
    return Text(std::move(out));
}


/// JobStruct: fn Text, Text, Text, Text, Text, Text -> Text
Text job_struct(const Text& doc, const Text& gens, const Text& name, const Text& ret, const Text& fields, const Text& ctor) {
    auto out = std::string();
    out.append("/// The step machine of `");
    place(out, name, std::nullopt);
    out.append("`, stopped at a cycle point: the call about to be\n/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the\n/// callee\'s job, so the job\'s stack is its frames.\n///\n");
    place(out, doc, std::optional(0u));
    place(out, gens, std::nullopt);
    out.append("struct ");
    place(out, name, std::nullopt);
    out.append(" : prism_rtl::Job<");
    place(out, ret, std::nullopt);
    out.append("> {\n");
    place(out, fields, std::optional(4u));
    place(out, ctor, std::optional(4u));
    out.append("    prism_rtl::Turn<");
    place(out, ret, std::nullopt);
    out.append("> cycle() const override;\n};\n");
    return Text(std::move(out));
}


/// TraitNamespace: fn Text, Text -> Text
Text trait_namespace(const Text& name, const Text& body) {
    auto out = std::string();
    out.append("namespace ");
    place(out, name, std::nullopt);
    out.append(" {\n");
    place(out, body, std::optional(0u));
    out.append("}  // namespace ");
    place(out, name, std::nullopt);
    return Text(std::move(out));
}


/// NodeClass: fn Text, Text, Text, Text, Text, Text, Text -> Text
Text node_class(const Text& doc, const Text& name, const Text& base, const Text& fields, const Text& consts, const Text& ctor, const Text& decls) {
    auto out = std::string();
    place(out, doc, std::optional(0u));
    out.append("class ");
    place(out, name, std::nullopt);
    out.append(" : public ");
    place(out, base, std::nullopt);
    out.append(" {\npublic:\n    Path path;\n");
    place(out, fields, std::optional(4u));
    place(out, consts, std::optional(4u));
    place(out, ctor, std::optional(4u));
    out.append("    ");
    place(out, name, std::nullopt);
    out.append("(const ");
    place(out, name, std::nullopt);
    out.append("&) = delete;\n");
    place(out, decls, std::optional(4u));
    out.append("};\n");
    return Text(std::move(out));
}


/// NodeMake: fn Text, Text, Text, Text, Text -> Text
Text node_make(const Text& name, const Text& signature, const Text& lets, const Text& args, const Text& rest) {
    auto out = std::string();
    out.append("/// Built after propagation: holds take their initial values, places go out with\n/// `cx.added`, and nothing fires.\n");
    place(out, signature, std::nullopt);
    out.append(" {\n");
    place(out, lets, std::optional(4u));
    out.append("    prism_rtl::RcPlace<");
    place(out, name, std::nullopt);
    out.append("> _place;\n    auto node = _place.take(new (_place.at()) ");
    place(out, name, std::nullopt);
    out.append("(");
    place(out, args, std::nullopt);
    out.append("));\n");
    place(out, rest, std::optional(4u));
    out.append("}\n");
    return Text(std::move(out));
}


/// ForBuildTemplate: fn Text, Text, Text, Text, Text, Text, Text, Text, Text, Text, Text, Text -> Text
Text for_build_template(const Text& owner, const Text& name, const Text& at_, const Text& key_ty, const Text& value_ty, const Text& row_make, const Text& source, const Text& parent, const Text& passed, const Text& moved, const Text& from, const Text& replaced) {
    auto out = std::string();
    out.append("/// The rows of the `for` at `");
    place(out, at_, std::nullopt);
    out.append("`: rows whose key left are torn down, new keys are\n/// built under it at `[k]` from the values after the tick; kept rows keep reading their\n/// entry out of the source. Nothing to do when the source is the map last built from (one\n/// node, `same`: it has the same keys; Semantics ch. 11, sharing is invisible).\nDone ");
    place(out, owner, std::nullopt);
    out.append("::");
    place(out, name, std::nullopt);
    out.append("_build(Cx& cx) {\n    Map<");
    place(out, key_ty, std::nullopt);
    out.append(", ");
    place(out, value_ty, std::nullopt);
    out.append("> items = ");
    place(out, source, std::nullopt);
    out.append("(cx);\n    if (this->");
    place(out, name, std::nullopt);
    out.append("_from.same(items)) return {};\n");
    place(out, from, std::optional(4u));
    out.append("    auto old = deref(this->");
    place(out, name, std::nullopt);
    out.append(");\n    // the kept rows stay where they are: only the keys that left or came are touched\n    auto next = old;\n    for (auto&& [k, row] : old) {\n        if (!items.contains(k)) {\n            row->leave_row(cx);\n            cx.leave_later(row);\n            next.remove(k);\n        }");
    place(out, replaced, std::nullopt);
    out.append("\n    }\n    for (auto&& [k, v] : items) {\n        if (!old.contains(k)) next.insert(k, TRY(");
    place(out, row_make, std::nullopt);
    out.append("(");
    place(out, at_, std::nullopt);
    out.append(".child(Segment::key(prism_rtl::to_pod(k))), k, v, ");
    place(out, parent, std::nullopt);
    place(out, passed, std::nullopt);
    out.append(", cx)));\n    }\n    deref(this->");
    place(out, name, std::nullopt);
    out.append(") = next;\n    // What the block reads of its rows (a `for` that gives a dynamic) moved.\n    cx.dirty(prism_rtl::share(this));");
    place(out, moved, std::nullopt);
    out.append("\n    return {};\n}\n");
    return Text(std::move(out));
}


/// GenBuildTemplate: fn Text, Text, Text, Text, Text, Text, Text, Text -> Text
Text gen_build_template(const Text& owner, const Text& name, const Text& at_, const Text& path_, const Text& source, const Text& value_ty, const Text& select, const Text& moved) {
    auto out = std::string();
    out.append("/// The `rebuild` at `");
    place(out, at_, std::nullopt);
    out.append("`: the old generation torn down (it ran to the end of the\n/// tick), the next built at `");
    place(out, path_, std::nullopt);
    out.append("` from the source after the tick.\nDone ");
    place(out, owner, std::nullopt);
    out.append("::");
    place(out, name, std::nullopt);
    out.append("_build(Cx& cx) {\n    if (auto old = std::exchange(this->");
    place(out, name, std::nullopt);
    out.append(", std::nullopt)) {\n        (*old)->leave_row(cx);\n        cx.leave_later(*old);\n    }\n    std::uint32_t g = this->");
    place(out, name, std::nullopt);
    out.append("_count;\n    this->");
    place(out, name, std::nullopt);
    out.append("_count = g + 1;\n    Path path = ");
    place(out, path_, std::nullopt);
    out.append(";\n    ");
    place(out, value_ty, std::nullopt);
    out.append(" value = ");
    place(out, source, std::nullopt);
    out.append(";\n    prism_rtl::Rc<Row> row = ");
    place(out, select, std::nullopt);
    out.append(";\n    this->");
    place(out, name, std::nullopt);
    out.append(" = row;");
    place(out, moved, std::nullopt);
    out.append("\n    return {};\n}\n");
    return Text(std::move(out));
}


/// ProgramClass: fn Text, Text, Text, Text, Text -> Text
Text program_class(const Text& name, const Text& prism, const Text& node_, const Text& decode, const Text& root) {
    auto out = std::string();
    out.append("/// The program of `@");
    place(out, prism, std::nullopt);
    out.append("`: the root node and the runtime.\nclass ");
    place(out, name, std::nullopt);
    out.append(" : public Program {\npublic:\n    static Built<");
    place(out, name, std::nullopt);
    out.append("> build(std::span<const Pod> args, const ReadyState& ready) {\n");
    place(out, decode, std::optional(8u));
    out.append("        auto p = std::make_unique<");
    place(out, name, std::nullopt);
    out.append(">();\n        Cx cx = p->rt.build(ready);\n        p->root = ");
    place(out, root, std::nullopt);
    out.append(";\n        TickOut out = TRY(p->rt.close(std::move(cx)));\n        return std::pair<std::unique_ptr<");
    place(out, name, std::nullopt);
    out.append(">, TickOut>(std::move(p), std::move(out));\n    }\n    Result<TickOut> tick(const TickIn& input, const ReadyState& ready) override {\n        return rt.tick(root, input, ready);\n    }\n    void compact() override { rt.compact(); }\n\n    Runtime rt;\n    prism_rtl::Rc<");
    place(out, node_, std::nullopt);
    out.append("> root;\n};\n");
    return Text(std::move(out));
}


/// StmtExpr: fn Text, Text -> Text
Text stmt_expr(const Text& stmts, const Text& tail) {
    auto out = std::string();
    out.append("({\n");
    place(out, stmts, std::optional(4u));
    out.append("    ");
    place(out, tail, std::nullopt);
    out.append(";\n})");
    return Text(std::move(out));
}


/// MatchExpr: fn Text, Text -> Text
Text match_expr(const Text& ty, const Text& arms) {
    auto out = std::string();
    out.append("({\n    __label__ _done;\n    prism_rtl::Slot<");
    place(out, ty, std::nullopt);
    out.append("> _v;\n");
    place(out, arms, std::optional(4u));
    out.append("_done:\n    _v.take();\n})");
    return Text(std::move(out));
}


/// LabeledExpr: fn Text, Text, Text -> Text
Text labeled_expr(const Text& label, const Text& ty, const Text& body) {
    auto out = std::string();
    out.append("({\n    __label__ ");
    place(out, label, std::nullopt);
    out.append(";\n    prism_rtl::Slot<");
    place(out, ty, std::nullopt);
    out.append("> ");
    place(out, label, std::nullopt);
    out.append("_v;\n    {\n");
    place(out, body, std::optional(8u));
    out.append("    }\n");
    place(out, label, std::nullopt);
    out.append(":\n    ");
    place(out, label, std::nullopt);
    out.append("_v.take();\n})");
    return Text(std::move(out));
}


/// CondExpr: fn Text, Text, Text -> Text
Text cond_expr(const Text& cond, const Text& then_x, const Text& else_x) {
    auto out = std::string();
    place(out, cond, std::optional(0u));
    out.append("    ? ");
    place(out, then_x, std::nullopt);
    out.append("\n    : ");
    place(out, else_x, std::nullopt);
    return Text(std::move(out));
}


/// Lambda: fn Text, Text, Text -> Text
Text lambda(const Text& capture, const Text& params, const Text& body) {
    auto out = std::string();
    out.append("[");
    place(out, capture, std::nullopt);
    out.append("](");
    place(out, params, std::nullopt);
    out.append(" {\n");
    place(out, body, std::optional(4u));
    out.append("}");
    return Text(std::move(out));
}


/// Block: fn Text, Text -> Text
Text block(const Text& head, const Text& body) {
    auto out = std::string();
    place(out, head, std::nullopt);
    out.append(" {\n");
    place(out, body, std::optional(4u));
    out.append("}");
    return Text(std::move(out));
}


/// IfBlock: fn Text, Text -> Text
Text if_block(const Text& cond, const Text& body) {
    auto out = std::string();
    out.append("if (");
    place(out, cond, std::nullopt);
    out.append(") {\n");
    place(out, body, std::optional(4u));
    out.append("}");
    return Text(std::move(out));
}


/// Braced: fn Text -> Text
Text braced(const Text& body) {
    auto out = std::string();
    out.append("{\n");
    place(out, body, std::optional(4u));
    out.append("}");
    return Text(std::move(out));
}

}  // namespace crate::emit::cpp::templates::items
