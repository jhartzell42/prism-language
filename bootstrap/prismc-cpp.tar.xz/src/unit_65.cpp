// The module `Syntax.Parser.Decls`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Syntax.Parser.Decls`, from `target/bootstrap/cpp-src/prismc/syntax/parser/decls.prism`.
namespace crate::syntax::parser::decls {

void ModRead::show(Printer& p) const {
    p.record("ModRead", {{"p", p_}, {"m", m}, {"stage", stage}});
}

Pod ModRead::to_pod() const {
    return Pod::record("ModRead", {{"p", prism_rtl::to_pod(p_)}, {"m", prism_rtl::to_pod(m)}, {"stage", prism_rtl::to_pod(stage)}});
}

Result<ModRead> ModRead::from_pod(const Pod& whole) {
    return ModRead{.p_ = TRY(prism_rtl::from_pod<crate::syntax::parser::Ps>(TRY(crate::prelude::field(whole, "p")))), .m = TRY(prism_rtl::from_pod<crate::syntax::Module>(TRY(crate::prelude::field(whole, "m")))), .stage = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "stage"))))};
}


/// ParseModule: unbounded fn Ps, Bool -> ((Module, Ps))
std::tuple<crate::syntax::Module, crate::syntax::parser::Ps> parse_module(const crate::syntax::parser::Ps& p0_p0, const bool& fragment_p1) {
    auto start_p2 = crate::syntax::parser::here(p0_p0);
    auto [template_o9, p1_pa] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<std::optional<crate::syntax::Template>, crate::syntax::parser::Ps>> _v;
        auto&& _m = crate::syntax::parser::kind(p0_p0);
        if (prism_rtl::is<crate::syntax::lexer::TokKind::KTemplate>(_m)) {
            auto&& t_p6 = prism_rtl::as<crate::syntax::lexer::TokKind::KTemplate>(_m).a0;
            _v.set(({
                auto [tpl_p7, q_p8] = crate::syntax::parser::expr::parse_template(crate::syntax::parser::adv(p0_p0), t_p6, crate::syntax::parser::here(p0_p0));
                std::tuple{std::optional(tpl_p7), q_p8};
            }));
            goto _done;
        }
        {
            _v.set(std::tuple{std::optional<crate::syntax::Template>{}, p0_p0});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto m0_p3 = crate::syntax::Module{.name = std::optional<crate::syntax::QualName>{}, .emit_row = std::optional<crate::syntax::Row_>{}, .mods = Array<crate::syntax::ModLine>{}, .uses = Array<crate::syntax::Use>{}, .decls = Array<crate::syntax::decls::Decl>{}, .template_ = template_o9, .span = start_p2};
    auto r_p4 = ({
        ModRead this_ = ModRead{.p_ = p1_pa, .m = m0_p3, .stage = Nat(0u)};
        while (!crate::syntax::parser::at_eof(this_.p_)) {
            this_ = module_item(this_, fragment_p1);
        }
        (std::move(this_));
    });
    auto m_p5 = ({
        crate::syntax::Module this_ = r_p4->m;
        this_.span = crate::syntax::parser::to(start_p2, crate::syntax::parser::prev(prism_rtl::deref(r_p4).p_));
        (std::move(this_));
    });
    return std::tuple{m_p5, prism_rtl::deref(r_p4).p_};
}


prism_rtl::Turn<std::tuple<crate::syntax::Module, crate::syntax::parser::Ps>> ParseModule::cycle() const {
    const auto& p0_p0 = this->p0_p0;
    const auto& fragment_p1 = this->fragment_p1;
    auto start_p2 = crate::syntax::parser::here(p0_p0);
    auto [template_o9, p1_pa] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<std::optional<crate::syntax::Template>, crate::syntax::parser::Ps>> _v;
        auto&& _m = crate::syntax::parser::kind(p0_p0);
        if (prism_rtl::is<crate::syntax::lexer::TokKind::KTemplate>(_m)) {
            auto&& t_p6 = prism_rtl::as<crate::syntax::lexer::TokKind::KTemplate>(_m).a0;
            _v.set(({
                auto [tpl_p7, q_p8] = crate::syntax::parser::expr::parse_template(crate::syntax::parser::adv(p0_p0), t_p6, crate::syntax::parser::here(p0_p0));
                std::tuple{std::optional(tpl_p7), q_p8};
            }));
            goto _done;
        }
        {
            _v.set(std::tuple{std::optional<crate::syntax::Template>{}, p0_p0});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto m0_p3 = crate::syntax::Module{.name = std::optional<crate::syntax::QualName>{}, .emit_row = std::optional<crate::syntax::Row_>{}, .mods = Array<crate::syntax::ModLine>{}, .uses = Array<crate::syntax::Use>{}, .decls = Array<crate::syntax::decls::Decl>{}, .template_ = template_o9, .span = start_p2};
    ModRead this_ = ModRead{.p_ = p1_pa, .m = m0_p3, .stage = Nat(0u)};
    auto start_p2_1 = start_p2;
    return call_then(loop_job(std::tuple{std::move(this_)}, ({
        auto fragment_p1_2 = prism_rtl::deref(fragment_p1);
        [=, fragment_p1_2 = std::move(fragment_p1_2)](std::tuple<ModRead> _p0) {
        auto this_ = std::get<0>(_p0);
        return !crate::syntax::parser::at_eof(prism_rtl::deref(this_).p_)
            ? ({
            this_ = module_item(this_, fragment_p1_2);
            Expected<std::tuple<ModRead>, std::tuple<ModRead>>(std::tuple{this_});
        })
            : Expected<std::tuple<ModRead>, std::tuple<ModRead>>(unexpected(std::tuple{this_}));
    };
    })), [=](std::tuple<ModRead> _p0) {
        auto this_ = std::get<0>(_p0);
        return ({
            auto r_p4 = this_;
            auto m_p5 = ({
                crate::syntax::Module this_ = r_p4->m;
                this_.span = crate::syntax::parser::to(start_p2_1, crate::syntax::parser::prev(prism_rtl::deref(r_p4).p_));
                (std::move(this_));
            });
            (prism_rtl::finished(std::tuple{m_p5, prism_rtl::deref(r_p4).p_}));
        });
    });
}


/// `Start ParseModule, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Module, crate::syntax::parser::Ps>> start_parse_module(crate::syntax::parser::Ps p0_p0, bool fragment_p1) {
    return prism_rtl::make_rc<ParseModule>(p0_p0, fragment_p1);
}


/// ModuleItem: unbounded fn ModRead, Bool -> ModRead
ModRead module_item(const ModRead& s_p0, const bool& fragment_p1) {
    return crate::syntax::parser::at_sep(s_p0.p_)
        ? ({
        ModRead this_ = s_p0;
        this_.p_ = crate::syntax::parser::adv(this_.p_);
        (std::move(this_));
    })
        : ({
        auto s1_p2 = header_or_decl(s_p0, fragment_p1, crate::syntax::parser::here(s_p0.p_));
        auto p2_p3 = crate::syntax::parser::recovered(prism_rtl::deref(s1_p2).p_);
        auto p3_p4 = crate::syntax::parser::at_close_l(p2_p3)
            ? crate::syntax::parser::adv(p2_p3)
            : crate::syntax::parser::at_eof(p2_p3)
            ? p2_p3
            : crate::syntax::parser::expect_stmt_end(p2_p3, Text::lit("declaration"));
        ({
        ModRead this_ = s1_p2;
        this_.p_ = p3_p4;
        (std::move(this_));
    });
    });
}


prism_rtl::Turn<ModRead> ModuleItem::cycle() const {
    const auto& s_p0 = this->s_p0;
    const auto& fragment_p1 = this->fragment_p1;
    return crate::syntax::parser::at_sep(prism_rtl::deref(s_p0).p_)
        ? prism_rtl::finished(({
        ModRead this_ = s_p0;
        this_.p_ = crate::syntax::parser::adv(this_.p_);
        (std::move(this_));
    }))
        : ({
        auto fragment_p1_1 = prism_rtl::deref(fragment_p1);
        auto s_p0_2 = s_p0;
        call_then(start_header_or_decl(s_p0_2, std::move(fragment_p1_1), crate::syntax::parser::here(prism_rtl::deref(s_p0_2).p_)), [=](ModRead header_or_decl_1962) {
        return ({
            auto s1_p2 = header_or_decl_1962;
            call_then(crate::syntax::parser::start_recovered(prism_rtl::deref(s1_p2).p_), [=](crate::syntax::parser::Ps recovered_2016) {
            return ({
                auto p2_p3 = recovered_2016;
                auto p3_p4 = crate::syntax::parser::at_close_l(p2_p3)
                    ? crate::syntax::parser::adv(p2_p3)
                    : crate::syntax::parser::at_eof(p2_p3)
                    ? p2_p3
                    : crate::syntax::parser::expect_stmt_end(p2_p3, Text::lit("declaration"));
                (prism_rtl::finished(({
                ModRead this_ = s1_p2;
                this_.p_ = p3_p4;
                (std::move(this_));
            })));
            });
        });
        });
    });
    });
}


/// `Start ModuleItem, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<ModRead> start_module_item(ModRead s_p0, bool fragment_p1) {
    return prism_rtl::make_rc<ModuleItem>(s_p0, fragment_p1);
}


/// HeaderOrDecl: unbounded fn ModRead, Bool, Range -> ModRead
ModRead header_or_decl(const ModRead& s_p0, const bool& fragment_p1, const crate::syntax::Range& item_start_p2) {
    auto&& _m = crate::syntax::parser::kind(s_p0.p_);
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m2338_0_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m2338_0_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        if (m2338_0_0 == Text::lit("module")) {
            if (m2338_0_1 == Text::lit("")) {
                auto [name_p3, p_p4] = crate::syntax::parser::parse_qual_name(crate::syntax::parser::adv(s_p0.p_));
                return p_p4->bad
                    ? ({
                    ModRead this_ = s_p0;
                    this_.p_ = p_p4;
                    (std::move(this_));
                })
                    : ({
                    auto late_p5 = (s_p0.stage > Nat(0u)) || (prism_rtl::deref(s_p0.m).name != std::optional<crate::syntax::QualName>{});
                    ({
                    ModRead this_ = s_p0;
                    this_.p_ = std::move(late_p5)
                        ? crate::syntax::parser::note_error(p_p4, item_start_p2, Text::lit("the `module` line comes first in a file"))
                        : p_p4;
                    prism_rtl::deref(this_.m).name = std::optional(name_p3);
                    this_.stage = Nat(1u);
                    (std::move(this_));
                });
                });
            }
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m2338_1_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m2338_1_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        if (m2338_1_0 == Text::lit("emit")) {
            if (m2338_1_1 == Text::lit("")) {
                auto [emit_row_p6, p_p7] = crate::syntax::parser::types::parse_row(crate::syntax::parser::adv(s_p0.p_));
                return p_p7->bad
                    ? ({
                    ModRead this_ = s_p0;
                    this_.p_ = p_p7;
                    (std::move(this_));
                })
                    : ({
                    auto late_p8 = (s_p0.stage > Nat(1u)) || (prism_rtl::deref(s_p0.m).emit_row != std::optional<crate::syntax::Row_>{});
                    ({
                    ModRead this_ = s_p0;
                    this_.p_ = std::move(late_p8)
                        ? crate::syntax::parser::note_error(p_p7, item_start_p2, Text::lit("`emit` comes after `module` and above `use`, once (Semantics ch. 6)"))
                        : p_p7;
                    prism_rtl::deref(this_.m).emit_row = std::optional(emit_row_p6);
                    this_.stage = Nat(2u);
                    (std::move(this_));
                });
                });
            }
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m2338_2_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m2338_2_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        if (m2338_2_0 == Text::lit("use")) {
            if (m2338_2_1 == Text::lit("")) {
                auto [u_p9, p_pa] = parse_use(crate::syntax::parser::adv(s_p0.p_), item_start_p2);
                return p_pa->bad
                    ? ({
                    ModRead this_ = s_p0;
                    this_.p_ = p_pa;
                    (std::move(this_));
                })
                    : ({
                    ModRead this_ = s_p0;
                    this_.p_ = s_p0.stage > Nat(4u)
                        ? crate::syntax::parser::note_error(p_pa, item_start_p2, Text::lit("`use` lines belong to the header, above the declarations"))
                        : p_pa;
                    prism_rtl::deref(this_.m).uses = crate::prelude::push(prism_rtl::deref(this_.m).uses, u_p9);
                    this_.stage = Nat(4u);
                    (std::move(this_));
                });
            }
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m2338_3_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m2338_3_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        if (m2338_3_0 == Text::lit("mod")) {
            if (m2338_3_1 == Text::lit("")) {
                return mod_header(s_p0, crate::syntax::parser::adv(s_p0.p_), false, item_start_p2);
            }
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m2338_4_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m2338_4_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        if (m2338_4_0 == Text::lit("test")) {
            if (m2338_4_1 == Text::lit("")) {
                if (is_kw_kind(crate::syntax::parser::kind(crate::syntax::parser::adv(s_p0.p_)), Text::lit("mod"))) {
                    return mod_header(s_p0, crate::syntax::parser::adv(crate::syntax::parser::adv(s_p0.p_)), true, item_start_p2);
                }
            }
        }
    }
    {
        auto [d_pb, p_pc] = parse_decl(s_p0.p_, fragment_p1);
        ModRead this_ = s_p0;
        this_.p_ = p_pc;
        this_.stage = Nat(5u);
        if (!p_pc->bad) {
            prism_rtl::deref(this_.m).decls = crate::prelude::push(prism_rtl::deref(this_.m).decls, d_pb);
        }
        return this_;
    }
}


prism_rtl::Turn<ModRead> HeaderOrDecl::cycle() const {
    const auto& s_p0 = this->s_p0;
    const auto& fragment_p1 = this->fragment_p1;
    const auto& item_start_p2 = this->item_start_p2;
    return ({
        auto&& _m = crate::syntax::parser::kind(prism_rtl::deref(s_p0).p_);
        prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& m2338_0_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m2338_0_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        (m2338_0_0 == Text::lit("module")) && (m2338_0_1 == Text::lit(""));
    }) ? ({
        auto&& m2338_0_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m2338_0_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        ({
        auto [name_p3, p_p4] = crate::syntax::parser::parse_qual_name(crate::syntax::parser::adv(prism_rtl::deref(s_p0).p_));
        p_p4->bad
        ? prism_rtl::finished(({
        ModRead this_ = s_p0;
        this_.p_ = p_p4;
        (std::move(this_));
    }))
        : ({
        auto late_p5 = (prism_rtl::deref(s_p0).stage > Nat(0u)) || (prism_rtl::deref(s_p0->m).name != std::optional<crate::syntax::QualName>{});
        (prism_rtl::finished(({
        ModRead this_ = s_p0;
        this_.p_ = std::move(late_p5)
            ? crate::syntax::parser::note_error(p_p4, item_start_p2, Text::lit("the `module` line comes first in a file"))
            : p_p4;
        prism_rtl::deref(this_.m).name = std::optional(name_p3);
        this_.stage = Nat(1u);
        (std::move(this_));
    })));
    });
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& m2338_1_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m2338_1_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        (m2338_1_0 == Text::lit("emit")) && (m2338_1_1 == Text::lit(""));
    }) ? ({
        auto&& m2338_1_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m2338_1_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        ({
        auto item_start_p2_1 = item_start_p2;
        auto s_p0_2 = s_p0;
        call_then(crate::syntax::parser::types::start_parse_row(crate::syntax::parser::adv(prism_rtl::deref(s_p0_2).p_)), [=, item_start_p2_1 = std::move(item_start_p2_1)](std::tuple<crate::syntax::Row_, crate::syntax::parser::Ps> parse_row_2789) {
        return ({
            auto [emit_row_p6, p_p7] = parse_row_2789;
            p_p7->bad
            ? prism_rtl::finished(({
            ModRead this_ = s_p0_2;
            this_.p_ = p_p7;
            (std::move(this_));
        }))
            : ({
            auto late_p8 = (prism_rtl::deref(s_p0_2).stage > Nat(1u)) || (prism_rtl::deref(s_p0_2->m).emit_row != std::optional<crate::syntax::Row_>{});
            (prism_rtl::finished(({
            ModRead this_ = s_p0_2;
            this_.p_ = std::move(late_p8)
                ? crate::syntax::parser::note_error(p_p7, item_start_p2_1, Text::lit("`emit` comes after `module` and above `use`, once (Semantics ch. 6)"))
                : p_p7;
            prism_rtl::deref(this_.m).emit_row = std::optional(emit_row_p6);
            this_.stage = Nat(2u);
            (std::move(this_));
        })));
        });
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& m2338_2_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m2338_2_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        (m2338_2_0 == Text::lit("use")) && (m2338_2_1 == Text::lit(""));
    }) ? ({
        auto&& m2338_2_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m2338_2_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        ({
        auto [u_p9, p_pa] = parse_use(crate::syntax::parser::adv(prism_rtl::deref(s_p0).p_), item_start_p2);
        p_pa->bad
        ? prism_rtl::finished(({
        ModRead this_ = s_p0;
        this_.p_ = p_pa;
        (std::move(this_));
    }))
        : prism_rtl::finished(({
        ModRead this_ = s_p0;
        this_.p_ = prism_rtl::deref(s_p0).stage > Nat(4u)
            ? crate::syntax::parser::note_error(p_pa, item_start_p2, Text::lit("`use` lines belong to the header, above the declarations"))
            : p_pa;
        prism_rtl::deref(this_.m).uses = crate::prelude::push(prism_rtl::deref(this_.m).uses, u_p9);
        this_.stage = Nat(4u);
        (std::move(this_));
    }));
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& m2338_3_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m2338_3_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        (m2338_3_0 == Text::lit("mod")) && (m2338_3_1 == Text::lit(""));
    }) ? ({
        auto&& m2338_3_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m2338_3_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        prism_rtl::finished(mod_header(s_p0, crate::syntax::parser::adv(prism_rtl::deref(s_p0).p_), false, item_start_p2));
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& m2338_4_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m2338_4_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        (m2338_4_0 == Text::lit("test")) && (m2338_4_1 == Text::lit("")) && is_kw_kind(crate::syntax::parser::kind(crate::syntax::parser::adv(prism_rtl::deref(s_p0).p_)), Text::lit("mod"));
    }) ? ({
        auto&& m2338_4_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m2338_4_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        prism_rtl::finished(mod_header(s_p0, crate::syntax::parser::adv(crate::syntax::parser::adv(prism_rtl::deref(s_p0).p_)), true, item_start_p2));
    })
        : ({
        auto fragment_p1_1 = prism_rtl::deref(fragment_p1);
        auto s_p0_2 = s_p0;
        call_then(start_parse_decl(prism_rtl::deref(s_p0_2).p_, std::move(fragment_p1_1)), [=](std::tuple<crate::syntax::decls::Decl, crate::syntax::parser::Ps> parse_decl_3725) {
        return ({
            auto [d_pb, p_pc] = parse_decl_3725;
            (prism_rtl::finished(({
            ModRead this_ = s_p0_2;
            this_.p_ = p_pc;
            this_.stage = Nat(5u);
            if (!p_pc->bad) {
                prism_rtl::deref(this_.m).decls = crate::prelude::push(prism_rtl::deref(this_.m).decls, d_pb);
            }
            (std::move(this_));
        })));
        });
    });
    });
    });
}


/// `Start HeaderOrDecl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<ModRead> start_header_or_decl(ModRead s_p0, bool fragment_p1, crate::syntax::Range item_start_p2) {
    return prism_rtl::make_rc<HeaderOrDecl>(s_p0, fragment_p1, item_start_p2);
}


/// ModHeader: fn ModRead, Ps, Bool, Range -> ModRead
ModRead mod_header(const ModRead& s_p0, const crate::syntax::parser::Ps& p_p1, const bool& is_test_p2, const crate::syntax::Range& item_start_p3) {
    auto&& _m = crate::syntax::parser::kind(p_p1);
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m)) {
        auto&& n_p4 = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        if ((prism_rtl::deref(n_p4).sigils == Text::lit("")) && (len(n_p4->path_) == Nat(1u))) {
            auto line_p5 = crate::syntax::ModLine{.name = crate::syntax::Ident{.name = or_(index(n_p4->path_, Nat(0u)), Text::lit("")), .span = crate::syntax::parser::here(p_p1)}, .is_test = is_test_p2, .span = crate::syntax::parser::to(item_start_p3, crate::syntax::parser::here(p_p1))};
            ModRead this_ = s_p0;
            this_.p_ = s_p0.stage > Nat(3u)
                ? crate::syntax::parser::note_error(crate::syntax::parser::adv(p_p1), item_start_p3, Text::lit("`mod` lines come after `emit` and above `use` (claude/modules-style-pass.md)"))
                : crate::syntax::parser::adv(p_p1);
            prism_rtl::deref(this_.m).mods = crate::prelude::push(prism_rtl::deref(this_.m).mods, line_p5);
            this_.stage = Nat(3u);
            return this_;
        }
    }
    {
        ModRead this_ = s_p0;
        this_.p_ = crate::syntax::parser::error_here(p_p1, is_test_p2
            ? Text::lit("expected a test module\'s name after `test mod`")
            : Text::lit("expected a module\'s name after `mod`"));
        return this_;
    }
}


/// IsKwKind: fn TokKind, Text -> Bool
bool is_kw_kind(const crate::syntax::lexer::TokKind& k_p0, const Text& w_p1) {
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(k_p0)) {
        auto&& x_p2 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(k_p0).a0;
        return x_p2 == w_p1;
    }
    {
        return false;
    }
}


/// let noQual
crate::syntax::QualName no_qual() {
    return crate::syntax::QualName{.path_ = Array<Text>{}, .span = crate::syntax::parser::no_range()};
}


/// ParseUse: fn Ps, Range -> ((Use, Ps))
std::tuple<crate::syntax::Use, crate::syntax::parser::Ps> parse_use(const crate::syntax::parser::Ps& p_p0, const crate::syntax::Range& start_p1) {
    auto&& _m = crate::syntax::parser::kind(p_p0);
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KFamily>(_m)) {
        auto&& path_p2 = prism_rtl::as<crate::syntax::lexer::TokKind::KFamily>(_m).a0;
        return std::tuple{crate::syntax::Use{.target = crate::syntax::QualName{.path_ = path_p2, .span = crate::syntax::parser::here(p_p0)}, .star = true, .span = crate::syntax::parser::to(start_p1, crate::syntax::parser::here(p_p0))}, crate::syntax::parser::adv(p_p0)};
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m)) {
        auto&& n_p3 = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        if ((prism_rtl::deref(n_p3).sigils == Text::lit("")) && (prism_rtl::deref(n_p3).case_ == crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseUpper{}))) {
            return std::tuple{crate::syntax::Use{.target = crate::syntax::QualName{.path_ = n_p3->path_, .span = crate::syntax::parser::here(p_p0)}, .star = false, .span = crate::syntax::parser::to(start_p1, crate::syntax::parser::here(p_p0))}, crate::syntax::parser::adv(p_p0)};
        }
    }
    {
        return std::tuple{crate::syntax::Use{.target = no_qual(), .star = false, .span = crate::syntax::parser::no_range()}, crate::syntax::parser::error_here(p_p0, Text::lit("expected a module name after `use`"))};
    }
}


/// let noExpr
crate::syntax::Expr no_expr() {
    return crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EError{})), .span = crate::syntax::parser::no_range()};
}


/// let noType
crate::syntax::Type no_type() {
    return crate::syntax::Type{.kind = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TAbsent{})), .span = crate::syntax::parser::no_range()};
}


/// let noPattern
crate::syntax::Pattern_ no_pattern() {
    return crate::syntax::Pattern_{.kind = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PIgnore{})), .span = crate::syntax::parser::no_range()};
}


/// let noBlock
crate::syntax::Block no_block() {
    return crate::syntax::Block{.stmts = Array<crate::syntax::Stmt>{}, .inline_ = true, .span = crate::syntax::parser::no_range()};
}


/// ParseDecl: unbounded fn Ps, Bool -> ((Decl, Ps))
std::tuple<crate::syntax::decls::Decl, crate::syntax::parser::Ps> parse_decl(const crate::syntax::parser::Ps& p_p0, const bool& fragment_p1) {
    auto start_p2 = crate::syntax::parser::here(p_p0);
    auto [kind_p3, q_p4] = decl_kind_of(p_p0, fragment_p1, start_p2);
    return std::tuple{crate::syntax::decls::Decl{.kind = kind_p3, .span = crate::syntax::parser::to(start_p2, crate::syntax::parser::prev(q_p4))}, q_p4};
}


prism_rtl::Turn<std::tuple<crate::syntax::decls::Decl, crate::syntax::parser::Ps>> ParseDecl::cycle() const {
    const auto& p_p0 = this->p_p0;
    const auto& fragment_p1 = this->fragment_p1;
    auto start_p2 = crate::syntax::parser::here(p_p0);
    auto fragment_p1_1 = prism_rtl::deref(fragment_p1);
    auto p_p0_2 = p_p0;
    return call_then(start_decl_kind_of(p_p0_2, std::move(fragment_p1_1), start_p2), [=](std::tuple<crate::syntax::decls::DeclKind, crate::syntax::parser::Ps> decl_kind_of_5602) {
        return ({
            auto [kind_p3, q_p4] = decl_kind_of_5602;
            (prism_rtl::finished(std::tuple{crate::syntax::decls::Decl{.kind = kind_p3, .span = crate::syntax::parser::to(start_p2, crate::syntax::parser::prev(q_p4))}, q_p4}));
        });
    });
}


/// `Start ParseDecl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::decls::Decl, crate::syntax::parser::Ps>> start_parse_decl(crate::syntax::parser::Ps p_p0, bool fragment_p1) {
    return prism_rtl::make_rc<ParseDecl>(p_p0, fragment_p1);
}


/// DeclKindOf: unbounded fn Ps, Bool, Range -> ((DeclKind, Ps))
std::tuple<crate::syntax::decls::DeclKind, crate::syntax::parser::Ps> decl_kind_of(const crate::syntax::parser::Ps& p_p0, const bool& fragment_p1, const crate::syntax::Range& start_p2) {
    auto&& _m = crate::syntax::parser::kind(p_p0);
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m5783_0_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        if (m5783_0_0 == Text::lit("type")) {
            auto [d_p3, q_p4] = parse_type_decl(p_p0);
            return std::tuple{crate::syntax::decls::DeclKind(crate::syntax::decls::DeclKind::DType{d_p3}), q_p4};
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m5783_1_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        if (m5783_1_0 == Text::lit("tag")) {
            auto [d_p5, q_p6] = parse_tag_decl(p_p0);
            return std::tuple{crate::syntax::decls::DeclKind(crate::syntax::decls::DeclKind::DTag{d_p5}), q_p6};
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m5783_2_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        if (m5783_2_0 == Text::lit("derive")) {
            auto [traits_p7, q_p8] = crate::syntax::parser::commas(crate::syntax::parser::adv(p_p0), ({
                auto f = prism_rtl::rc(crate::syntax::parser::parse_trait_ref);
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::TraitRef, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([=, f = std::move(f)](crate::syntax::parser::Ps a0) {
                return ({
                    auto f_1 = f;
                    once_job([=, f_1 = std::move(f_1)]() { return prism_rtl::finished(f_1(a0)); });
                });
            }));
            }));
            return std::tuple{crate::syntax::decls::DeclKind(crate::syntax::decls::DeclKind::DDerive{traits_p7}), q_p8};
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m5783_3_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        if (m5783_3_0 == Text::lit("trait")) {
            auto [d_p9, q_pa] = parse_trait_decl(p_p0);
            return std::tuple{crate::syntax::decls::DeclKind(crate::syntax::decls::DeclKind::DTrait{d_p9}), q_pa};
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m5783_4_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        if (m5783_4_0 == Text::lit("impl")) {
            auto [d_pb, q_pc] = parse_impl_decl(p_p0);
            return std::tuple{crate::syntax::decls::DeclKind(crate::syntax::decls::DeclKind::DImpl{d_pb}), q_pc};
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m5783_5_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        if (m5783_5_0 == Text::lit("check")) {
            auto [d_pd, q_pe] = crate::syntax::parser::test_language::parse_check_decl(p_p0);
            return std::tuple{crate::syntax::decls::DeclKind(crate::syntax::decls::DeclKind::DCheck{d_pd}), q_pe};
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m5783_6_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        if (m5783_6_0 == Text::lit("test")) {
            auto [d_pf, q_pg] = crate::syntax::parser::test_language::parse_test_decl(p_p0);
            return std::tuple{crate::syntax::decls::DeclKind(crate::syntax::decls::DeclKind::DTest{d_pf}), q_pg};
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m5783_7_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        if (m5783_7_0 == Text::lit("fn")) {
            auto [d_ph, q_pi] = parse_fn_clause(p_p0);
            return std::tuple{crate::syntax::decls::DeclKind(crate::syntax::decls::DeclKind::DFn{d_ph}), q_pi};
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m5783_8_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        if (m5783_8_0 == Text::lit("let")) {
            auto [pattern_pj, p1_pk] = crate::syntax::parser::types::parse_pattern(crate::syntax::parser::adv(p_p0), false);
            auto [ty_ol, p2_pm] = optional_annotation(p1_pk);
            auto [value_pn, p3_po] = crate::syntax::parser::expr::parse_rhs_expr(crate::syntax::parser::expect_op(p2_pm, Text::lit("=")));
            return std::tuple{crate::syntax::decls::DeclKind(crate::syntax::decls::DeclKind::DLet{crate::syntax::decls::LetDecl{.pattern = pattern_pj, .ty = ty_ol, .value = value_pn, .span = crate::syntax::parser::to(start_p2, crate::syntax::parser::prev(p3_po))}}), p3_po};
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m)) {
        if (crate::syntax::parser::kind_at(p_p0, Nat(1u)) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KColon{})) {
            return crate::syntax::parser::kind_at(p_p0, Nat(2u)) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KLayOpen{})
                ? ({
                auto [name_pp, p1_pq] = crate::syntax::parser::parse_sname(p_p0);
                auto [body_pr, p2_ps] = crate::syntax::parser::blocks::parse_block_after_colon(p1_pq);
                std::tuple{crate::syntax::decls::DeclKind(crate::syntax::decls::DeclKind::DWidget{crate::syntax::decls::WidgetDecl{.name = name_pp, .body = body_pr, .span = crate::syntax::parser::to(start_p2, prism_rtl::deref(body_pr).span)}}), p2_ps};
            })
                : ({
                auto [sig_pt, q_pu] = parse_signature(p_p0);
                std::tuple{crate::syntax::decls::DeclKind(crate::syntax::decls::DeclKind::DSignature{sig_pt}), q_pu};
            });
        }
    }
    {
        return fragment_p1
            ? ({
            auto [st_pv, q_p10] = crate::syntax::parser::blocks::parse_stmt(p_p0);
            std::tuple{crate::syntax::decls::DeclKind(crate::syntax::decls::DeclKind::DStmt{st_pv}), q_p10};
        })
            : ({
            auto [st_p11, q_p12] = crate::syntax::parser::blocks::parse_stmt(p_p0);
            ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<crate::syntax::decls::DeclKind, crate::syntax::parser::Ps>> _v;
            auto&& _m = prism_rtl::deref(st_p11).kind;
            if (prism_rtl::is<crate::syntax::StmtKind::SBind>(_m)) {
                if (!q_p12->bad) {
                    _v.set(std::tuple{crate::syntax::decls::DeclKind(crate::syntax::decls::DeclKind::DStmt{st_p11}), crate::syntax::parser::error_at(q_p12, start_p2, Text::lit("a bind or hold is a statement of a widget block: nothing at top level is built (Semantics ch. 6)"))});
                    goto _done;
                }
            }
            {
                _v.set(({
                    auto at_p13 = q_p12->bad ? p_p0 : q_p12;
                    std::tuple{crate::syntax::decls::DeclKind(crate::syntax::decls::DeclKind::DStmt{st_p11}), crate::syntax::parser::error_here(at_p13, Text::lit("expected a declaration (`fn`, `let`, `type`, `tag`, `derive`, `trait`, `impl`, `test`, `check`, or a signature `Name: type`)"))};
                }));
                goto _done;
            }
        _done:
            _v.take();
        });
        });
    }
}


prism_rtl::Turn<std::tuple<crate::syntax::decls::DeclKind, crate::syntax::parser::Ps>> DeclKindOf::cycle() const {
    const auto& p_p0 = this->p_p0;
    const auto& fragment_p1 = this->fragment_p1;
    const auto& start_p2 = this->start_p2;
    return ({
        auto&& _m = crate::syntax::parser::kind(p_p0);
        prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& m5783_0_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        (m5783_0_0 == Text::lit("type"));
    }) ? ({
        auto&& m5783_0_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        ({
        auto p_p0_1 = p_p0;
        call_then(start_parse_type_decl(p_p0_1), [=](std::tuple<crate::syntax::decls::TypeDecl, crate::syntax::parser::Ps> parse_type_decl_5844) {
        return ({
            auto [d_p3, q_p4] = parse_type_decl_5844;
            (prism_rtl::finished(std::tuple{crate::syntax::decls::DeclKind(crate::syntax::decls::DeclKind::DType{d_p3}), q_p4}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& m5783_1_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        (m5783_1_0 == Text::lit("tag"));
    }) ? ({
        auto&& m5783_1_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        ({
        auto p_p0_1 = p_p0;
        call_then(start_parse_tag_decl(p_p0_1), [=](std::tuple<crate::syntax::decls::TagDecl, crate::syntax::parser::Ps> parse_tag_decl_5929) {
        return ({
            auto [d_p5, q_p6] = parse_tag_decl_5929;
            (prism_rtl::finished(std::tuple{crate::syntax::decls::DeclKind(crate::syntax::decls::DeclKind::DTag{d_p5}), q_p6}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& m5783_2_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        (m5783_2_0 == Text::lit("derive"));
    }) ? ({
        auto&& m5783_2_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        ({
        auto p_p0_1 = p_p0;
        call_then(crate::syntax::parser::start_commas(crate::syntax::parser::adv(p_p0_1), ({
        auto f = prism_rtl::rc(crate::syntax::parser::parse_trait_ref);
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::TraitRef, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([=, f = std::move(f)](crate::syntax::parser::Ps a0) {
        return ({
            auto f_2 = f;
            once_job([=, f_2 = std::move(f_2)]() { return prism_rtl::finished(f_2(a0)); });
        });
    }));
    })), [=](std::tuple<Array<crate::syntax::TraitRef>, crate::syntax::parser::Ps> commas_6020) {
        return ({
            auto [traits_p7, q_p8] = commas_6020;
            (prism_rtl::finished(std::tuple{crate::syntax::decls::DeclKind(crate::syntax::decls::DeclKind::DDerive{traits_p7}), q_p8}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& m5783_3_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        (m5783_3_0 == Text::lit("trait"));
    }) ? ({
        auto&& m5783_3_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        ({
        auto p_p0_1 = p_p0;
        call_then(start_parse_trait_decl(p_p0_1), [=](std::tuple<crate::syntax::decls::TraitDecl, crate::syntax::parser::Ps> parse_trait_decl_6128) {
        return ({
            auto [d_p9, q_pa] = parse_trait_decl_6128;
            (prism_rtl::finished(std::tuple{crate::syntax::decls::DeclKind(crate::syntax::decls::DeclKind::DTrait{d_p9}), q_pa}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& m5783_4_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        (m5783_4_0 == Text::lit("impl"));
    }) ? ({
        auto&& m5783_4_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        ({
        auto p_p0_1 = p_p0;
        call_then(start_parse_impl_decl(p_p0_1), [=](std::tuple<crate::syntax::decls::ImplDecl, crate::syntax::parser::Ps> parse_impl_decl_6216) {
        return ({
            auto [d_pb, q_pc] = parse_impl_decl_6216;
            (prism_rtl::finished(std::tuple{crate::syntax::decls::DeclKind(crate::syntax::decls::DeclKind::DImpl{d_pb}), q_pc}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& m5783_5_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        (m5783_5_0 == Text::lit("check"));
    }) ? ({
        auto&& m5783_5_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        ({
        auto p_p0_1 = p_p0;
        call_then(crate::syntax::parser::test_language::start_parse_check_decl(p_p0_1), [=](std::tuple<crate::syntax::decls::CheckDecl, crate::syntax::parser::Ps> parse_check_decl_6303) {
        return ({
            auto [d_pd, q_pe] = parse_check_decl_6303;
            (prism_rtl::finished(std::tuple{crate::syntax::decls::DeclKind(crate::syntax::decls::DeclKind::DCheck{d_pd}), q_pe}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& m5783_6_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        (m5783_6_0 == Text::lit("test"));
    }) ? ({
        auto&& m5783_6_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        ({
        auto p_p0_1 = p_p0;
        call_then(crate::syntax::parser::test_language::start_parse_test_decl(p_p0_1), [=](std::tuple<crate::syntax::decls::TestDecl, crate::syntax::parser::Ps> parse_test_decl_6391) {
        return ({
            auto [d_pf, q_pg] = parse_test_decl_6391;
            (prism_rtl::finished(std::tuple{crate::syntax::decls::DeclKind(crate::syntax::decls::DeclKind::DTest{d_pf}), q_pg}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& m5783_7_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        (m5783_7_0 == Text::lit("fn"));
    }) ? ({
        auto&& m5783_7_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        ({
        auto p_p0_1 = p_p0;
        call_then(start_parse_fn_clause(p_p0_1), [=](std::tuple<crate::syntax::decls::FnClause, crate::syntax::parser::Ps> parse_fn_clause_6475) {
        return ({
            auto [d_ph, q_pi] = parse_fn_clause_6475;
            (prism_rtl::finished(std::tuple{crate::syntax::decls::DeclKind(crate::syntax::decls::DeclKind::DFn{d_ph}), q_pi}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& m5783_8_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        (m5783_8_0 == Text::lit("let"));
    }) ? ({
        auto&& m5783_8_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        ({
        auto p_p0_1 = p_p0;
        auto start_p2_2 = start_p2;
        call_then(crate::syntax::parser::types::start_parse_pattern(crate::syntax::parser::adv(p_p0_1), false), [=, start_p2_2 = std::move(start_p2_2)](std::tuple<crate::syntax::Pattern_, crate::syntax::parser::Ps> parse_pattern_6565) {
        return ({
            auto [pattern_pj, p1_pk] = parse_pattern_6565;
            call_then(start_optional_annotation(p1_pk), [=](std::tuple<std::optional<crate::syntax::Type>, crate::syntax::parser::Ps> optional_annotation_6619) {
            return ({
                auto [ty_ol, p2_pm] = optional_annotation_6619;
                call_then(crate::syntax::parser::expr::start_parse_rhs_expr(crate::syntax::parser::expect_op(p2_pm, Text::lit("="))), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_rhs_expr_6669) {
                return ({
                    auto [value_pn, p3_po] = parse_rhs_expr_6669;
                    (prism_rtl::finished(std::tuple{crate::syntax::decls::DeclKind(crate::syntax::decls::DeclKind::DLet{crate::syntax::decls::LetDecl{.pattern = pattern_pj, .ty = ty_ol, .value = value_pn, .span = crate::syntax::parser::to(start_p2_2, crate::syntax::parser::prev(p3_po))}}), p3_po}));
                });
            });
            });
        });
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m) && ({
        (crate::syntax::parser::kind_at(p_p0, Nat(1u)) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KColon{}));
    }) ? crate::syntax::parser::kind_at(p_p0, Nat(2u)) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KLayOpen{})
        ? ({
        auto [name_pp, p1_pq] = crate::syntax::parser::parse_sname(p_p0);
        auto start_p2_1 = start_p2;
        call_then(crate::syntax::parser::blocks::start_parse_block_after_colon(p1_pq), [=, start_p2_1 = std::move(start_p2_1)](std::tuple<crate::syntax::Block, crate::syntax::parser::Ps> parse_block_after_colon_6954) {
        return ({
            auto [body_pr, p2_ps] = parse_block_after_colon_6954;
            (prism_rtl::finished(std::tuple{crate::syntax::decls::DeclKind(crate::syntax::decls::DeclKind::DWidget{crate::syntax::decls::WidgetDecl{.name = name_pp, .body = body_pr, .span = crate::syntax::parser::to(start_p2_1, prism_rtl::deref(body_pr).span)}}), p2_ps}));
        });
    });
    })
        : ({
        auto p_p0_1 = p_p0;
        call_then(start_parse_signature(p_p0_1), [=](std::tuple<crate::syntax::decls::Signature, crate::syntax::parser::Ps> parse_signature_7110) {
        return ({
            auto [sig_pt, q_pu] = parse_signature_7110;
            (prism_rtl::finished(std::tuple{crate::syntax::decls::DeclKind(crate::syntax::decls::DeclKind::DSignature{sig_pt}), q_pu}));
        });
    });
    })
        : prism_rtl::deref(fragment_p1)
        ? ({
        auto p_p0_1 = p_p0;
        call_then(crate::syntax::parser::blocks::start_parse_stmt(p_p0_1), [=](std::tuple<crate::syntax::Stmt, crate::syntax::parser::Ps> parse_stmt_7225) {
        return ({
            auto [st_pv, q_p10] = parse_stmt_7225;
            (prism_rtl::finished(std::tuple{crate::syntax::decls::DeclKind(crate::syntax::decls::DeclKind::DStmt{st_pv}), q_p10}));
        });
    });
    })
        : ({
        auto p_p0_1 = p_p0;
        auto start_p2_2 = start_p2;
        call_then(crate::syntax::parser::blocks::start_parse_stmt(p_p0_1), [=, start_p2_2 = std::move(start_p2_2)](std::tuple<crate::syntax::Stmt, crate::syntax::parser::Ps> parse_stmt_7433) {
        return ({
            auto [st_p11, q_p12] = parse_stmt_7433;
            ({
            auto&& _m = prism_rtl::deref(st_p11).kind;
            prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) && ({
            (!q_p12->bad);
        }) ? prism_rtl::finished(std::tuple{crate::syntax::decls::DeclKind(crate::syntax::decls::DeclKind::DStmt{st_p11}), crate::syntax::parser::error_at(q_p12, start_p2_2, Text::lit("a bind or hold is a statement of a widget block: nothing at top level is built (Semantics ch. 6)"))})
            : ({
            auto at_p13 = q_p12->bad ? p_p0_1 : q_p12;
            (prism_rtl::finished(std::tuple{crate::syntax::decls::DeclKind(crate::syntax::decls::DeclKind::DStmt{st_p11}), crate::syntax::parser::error_here(at_p13, Text::lit("expected a declaration (`fn`, `let`, `type`, `tag`, `derive`, `trait`, `impl`, `test`, `check`, or a signature `Name: type`)"))}));
        });
        });
        });
    });
    });
    });
}


/// `Start DeclKindOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::decls::DeclKind, crate::syntax::parser::Ps>> start_decl_kind_of(crate::syntax::parser::Ps p_p0, bool fragment_p1, crate::syntax::Range start_p2) {
    return prism_rtl::make_rc<DeclKindOf>(p_p0, fragment_p1, start_p2);
}


/// OptionalAnnotation: unbounded fn Ps -> ((?Type, Ps))
std::tuple<std::optional<crate::syntax::Type>, crate::syntax::parser::Ps> optional_annotation(const crate::syntax::parser::Ps& p_p0) {
    return crate::syntax::parser::at_colon(p_p0)
        ? ({
        auto [ty_p1, q_p2] = crate::syntax::parser::types::parse_type(crate::syntax::parser::adv(p_p0));
        std::tuple{std::optional(ty_p1), q_p2};
    })
        : std::tuple{std::optional<crate::syntax::Type>{}, p_p0};
}


prism_rtl::Turn<std::tuple<std::optional<crate::syntax::Type>, crate::syntax::parser::Ps>> OptionalAnnotation::cycle() const {
    const auto& p_p0 = this->p_p0;
    return crate::syntax::parser::at_colon(p_p0)
        ? ({
        auto p_p0_1 = p_p0;
        call_then(crate::syntax::parser::types::start_parse_type(crate::syntax::parser::adv(p_p0_1)), [=](std::tuple<crate::syntax::Type, crate::syntax::parser::Ps> parse_type_8123) {
        return ({
            auto [ty_p1, q_p2] = parse_type_8123;
            (prism_rtl::finished(std::tuple{std::optional(ty_p1), q_p2}));
        });
    });
    })
        : prism_rtl::finished(std::tuple{std::optional<crate::syntax::Type>{}, p_p0});
}


/// `Start OptionalAnnotation, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<std::optional<crate::syntax::Type>, crate::syntax::parser::Ps>> start_optional_annotation(crate::syntax::parser::Ps p_p0) {
    return prism_rtl::make_rc<OptionalAnnotation>(p_p0);
}


/// ParseSignature: unbounded fn Ps -> ((Signature, Ps))
std::tuple<crate::syntax::decls::Signature, crate::syntax::parser::Ps> parse_signature(const crate::syntax::parser::Ps& p_p0) {
    auto start_p1 = crate::syntax::parser::here(p_p0);
    auto [name_p2, p1_p3] = parse_def_name(p_p0);
    auto [ty_p4, p2_p5] = crate::syntax::parser::types::parse_type(crate::syntax::parser::expect_colon(p1_p3));
    auto [bounds_p6, p3_p7] = optional_bounds(p2_p5);
    return std::tuple{crate::syntax::decls::Signature{.name = name_p2, .ty = ty_p4, .bounds = bounds_p6, .span = crate::syntax::parser::to(start_p1, crate::syntax::parser::prev(p3_p7))}, p3_p7};
}


prism_rtl::Turn<std::tuple<crate::syntax::decls::Signature, crate::syntax::parser::Ps>> ParseSignature::cycle() const {
    const auto& p_p0 = this->p_p0;
    auto start_p1 = crate::syntax::parser::here(p_p0);
    auto [name_p2, p1_p3] = parse_def_name(p_p0);
    return call_then(crate::syntax::parser::types::start_parse_type(crate::syntax::parser::expect_colon(p1_p3)), [=](std::tuple<crate::syntax::Type, crate::syntax::parser::Ps> parse_type_8405) {
        return ({
            auto [ty_p4, p2_p5] = parse_type_8405;
            call_then(start_optional_bounds(p2_p5), [=](std::tuple<Array<crate::syntax::decls::Bound>, crate::syntax::parser::Ps> optional_bounds_8457) {
            return ({
                auto [bounds_p6, p3_p7] = optional_bounds_8457;
                (prism_rtl::finished(std::tuple{crate::syntax::decls::Signature{.name = name_p2, .ty = ty_p4, .bounds = bounds_p6, .span = crate::syntax::parser::to(start_p1, crate::syntax::parser::prev(p3_p7))}, p3_p7}));
            });
        });
        });
    });
}


/// `Start ParseSignature, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::decls::Signature, crate::syntax::parser::Ps>> start_parse_signature(crate::syntax::parser::Ps p_p0) {
    return prism_rtl::make_rc<ParseSignature>(p_p0);
}


/// OptionalBounds: unbounded fn Ps -> (([Bound], Ps))
std::tuple<Array<crate::syntax::decls::Bound>, crate::syntax::parser::Ps> optional_bounds(const crate::syntax::parser::Ps& p_p0) {
    return crate::syntax::parser::at_kw(p_p0, Text::lit("where"))
        ? crate::syntax::parser::types::parse_bounds(crate::syntax::parser::adv(p_p0))
        : std::tuple{Array<crate::syntax::decls::Bound>{}, p_p0};
}


prism_rtl::Turn<std::tuple<Array<crate::syntax::decls::Bound>, crate::syntax::parser::Ps>> OptionalBounds::cycle() const {
    const auto& p_p0 = this->p_p0;
    return crate::syntax::parser::at_kw(p_p0, Text::lit("where"))
        ? prism_rtl::more(prism_rtl::rc(crate::syntax::parser::types::ParseBounds(crate::syntax::parser::adv(p_p0))))
        : prism_rtl::finished(std::tuple{Array<crate::syntax::decls::Bound>{}, p_p0});
}


/// `Start OptionalBounds, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::syntax::decls::Bound>, crate::syntax::parser::Ps>> start_optional_bounds(crate::syntax::parser::Ps p_p0) {
    return prism_rtl::make_rc<OptionalBounds>(p_p0);
}


/// ParseDefName: fn Ps -> ((DefName, Ps))
std::tuple<crate::syntax::decls::DefName, crate::syntax::parser::Ps> parse_def_name(const crate::syntax::parser::Ps& p_p0) {
    auto&& _m = crate::syntax::parser::kind(p_p0);
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m)) {
        auto&& n_p1 = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        auto [name_p4, q_p5] = crate::syntax::parser::parse_sname(p_p0);
        auto lens_p2 = crate::syntax::lexer::chars::has_prefix(prism_rtl::deref(n_p1).sigils, Text::lit("&")) && crate::syntax::parser::is_upper_name(name_p4);
        auto q2_p3 = std::move(lens_p2)
            ? crate::syntax::parser::out_of_scope(q_p5, prism_rtl::deref(name_p4).span, Text::lit("named lenses `&Home` and `Over`"), prism_rtl::cat("the named lens `", crate::syntax::parser::name_text(name_p4), "` is out of this compiler"))
            : q_p5;
        return std::tuple{crate::syntax::decls::DefName(crate::syntax::decls::DefName::DefSName{name_p4}), q2_p3};
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KOp>(_m)) {
        auto&& op_p6 = prism_rtl::as<crate::syntax::lexer::TokKind::KOp>(_m).a0;
        if (p_p0.in_trait) {
            auto name_p7 = crate::syntax::decls::DefName(crate::syntax::decls::DefName::DefOp{op_p6, crate::syntax::parser::here(p_p0)});
            return std::tuple{name_p7, crate::syntax::parser::adv(p_p0)};
        }
    }
    {
        return std::tuple{crate::syntax::decls::DefName(crate::syntax::decls::DefName::DefSName{crate::syntax::parser::no_sname()}), crate::syntax::parser::error_here(p_p0, Text::lit("expected a name"))};
    }
}


/// ParseFnClause: unbounded fn Ps -> ((FnClause, Ps))
std::tuple<crate::syntax::decls::FnClause, crate::syntax::parser::Ps> parse_fn_clause(const crate::syntax::parser::Ps& p0_p0) {
    auto start_p1 = crate::syntax::parser::here(p0_p0);
    auto [name_p2, p1_p3] = parse_def_name(crate::syntax::parser::expect_kw(p0_p0, Text::lit("fn")));
    auto [params_p5, p2_p6] = crate::syntax::parser::at_op(p1_p3, Text::lit("=")) || crate::syntax::parser::at_colon(p1_p3)
        ? std::tuple{Array<crate::syntax::Pattern_>{}, p1_p3}
        : crate::syntax::parser::commas(p1_p3, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::Pattern_, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([=](crate::syntax::parser::Ps p0) {
        return entered(once_job([=]() {
            return ({
                auto q_p4 = p0;
                (prism_rtl::more(prism_rtl::rc(crate::syntax::parser::types::ParsePattern(q_p4, false))));
            });
        }));
    })));
    auto [body_p7, p3_p8] = parse_fn_body(p2_p6);
    return std::tuple{crate::syntax::decls::FnClause{.name = name_p2, .params = params_p5, .body = body_p7, .span = crate::syntax::parser::to(start_p1, crate::syntax::parser::prev(p3_p8))}, p3_p8};
}


prism_rtl::Turn<std::tuple<crate::syntax::decls::FnClause, crate::syntax::parser::Ps>> ParseFnClause::cycle() const {
    const auto& p0_p0 = this->p0_p0;
    auto start_p1 = crate::syntax::parser::here(p0_p0);
    auto [name_p2, p1_p3] = parse_def_name(crate::syntax::parser::expect_kw(p0_p0, Text::lit("fn")));
    auto [params_p5, p2_p6] = crate::syntax::parser::at_op(p1_p3, Text::lit("=")) || crate::syntax::parser::at_colon(p1_p3)
        ? std::tuple{Array<crate::syntax::Pattern_>{}, p1_p3}
        : crate::syntax::parser::commas(p1_p3, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::Pattern_, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([=](crate::syntax::parser::Ps p0) {
        return entered(once_job([=]() {
            return ({
                auto q_p4 = p0;
                (prism_rtl::more(prism_rtl::rc(crate::syntax::parser::types::ParsePattern(q_p4, false))));
            });
        }));
    })));
    return call_then(start_parse_fn_body(p2_p6), [=](std::tuple<crate::syntax::decls::FnBody, crate::syntax::parser::Ps> parse_fn_body_9580) {
        return ({
            auto [body_p7, p3_p8] = parse_fn_body_9580;
            (prism_rtl::finished(std::tuple{crate::syntax::decls::FnClause{.name = name_p2, .params = params_p5, .body = body_p7, .span = crate::syntax::parser::to(start_p1, crate::syntax::parser::prev(p3_p8))}, p3_p8}));
        });
    });
}


/// `Start ParseFnClause, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::decls::FnClause, crate::syntax::parser::Ps>> start_parse_fn_clause(crate::syntax::parser::Ps p0_p0) {
    return prism_rtl::make_rc<ParseFnClause>(p0_p0);
}


/// ParseFnBody: unbounded fn Ps -> ((FnBody, Ps))
std::tuple<crate::syntax::decls::FnBody, crate::syntax::parser::Ps> parse_fn_body(const crate::syntax::parser::Ps& p_p0) {
    return crate::syntax::parser::at_op(p_p0, Text::lit("="))
        ? ({
        auto [e_p1, q_p2] = crate::syntax::parser::expr::parse_rhs_expr(crate::syntax::parser::adv(p_p0));
        std::tuple{crate::syntax::decls::FnBody(crate::syntax::decls::FnBody::BodyExpr{e_p1}), q_p2};
    })
        : crate::syntax::parser::at_colon(p_p0)
        ? ({
        auto [b_p3, q_p4] = crate::syntax::parser::blocks::parse_block_after_colon(p_p0);
        std::tuple{crate::syntax::decls::FnBody(crate::syntax::decls::FnBody::BodyBlock{b_p3}), q_p4};
    })
        : std::tuple{crate::syntax::decls::FnBody(crate::syntax::decls::FnBody::BodyExpr{no_expr()}), crate::syntax::parser::error_here(p_p0, Text::lit("expected `=` and an expression, or `:` and a block, after the parameters"))};
}


prism_rtl::Turn<std::tuple<crate::syntax::decls::FnBody, crate::syntax::parser::Ps>> ParseFnBody::cycle() const {
    const auto& p_p0 = this->p_p0;
    return crate::syntax::parser::at_op(p_p0, Text::lit("="))
        ? ({
        auto p_p0_1 = p_p0;
        call_then(crate::syntax::parser::expr::start_parse_rhs_expr(crate::syntax::parser::adv(p_p0_1)), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_rhs_expr_9790) {
        return ({
            auto [e_p1, q_p2] = parse_rhs_expr_9790;
            (prism_rtl::finished(std::tuple{crate::syntax::decls::FnBody(crate::syntax::decls::FnBody::BodyExpr{e_p1}), q_p2}));
        });
    });
    })
        : crate::syntax::parser::at_colon(p_p0)
        ? ({
        auto p_p0_1 = p_p0;
        call_then(crate::syntax::parser::blocks::start_parse_block_after_colon(p_p0_1), [=](std::tuple<crate::syntax::Block, crate::syntax::parser::Ps> parse_block_after_colon_9884) {
        return ({
            auto [b_p3, q_p4] = parse_block_after_colon_9884;
            (prism_rtl::finished(std::tuple{crate::syntax::decls::FnBody(crate::syntax::decls::FnBody::BodyBlock{b_p3}), q_p4}));
        });
    });
    })
        : prism_rtl::finished(std::tuple{crate::syntax::decls::FnBody(crate::syntax::decls::FnBody::BodyExpr{no_expr()}), crate::syntax::parser::error_here(p_p0, Text::lit("expected `=` and an expression, or `:` and a block, after the parameters"))});
}


/// `Start ParseFnBody, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::decls::FnBody, crate::syntax::parser::Ps>> start_parse_fn_body(crate::syntax::parser::Ps p_p0) {
    return prism_rtl::make_rc<ParseFnBody>(p_p0);
}


/// LowerParams: fn Ps -> (([Ident], Ps))
std::tuple<Array<crate::syntax::Ident>, crate::syntax::parser::Ps> lower_params(const crate::syntax::parser::Ps& p0_p0) {
    std::tuple<Array<crate::syntax::Ident>, crate::syntax::parser::Ps> this_ = std::tuple{Array<crate::syntax::Ident>{}, p0_p0};
    Array<crate::syntax::Ident> ps_p1 = Array<crate::syntax::Ident>{};
    crate::syntax::parser::Ps p_p2 = p0_p0;
    Nat fuel_p3 = len(p0_p0.toks);
    while (true) {
        auto&& _m = fuel_p3.checked_sub(Nat(1u));
        if (!(prism_rtl::is_some(_m))) break;
        auto&& left_p4 = prism_rtl::some_of(_m);
        if (!is_plain_lower(crate::syntax::parser::kind(p_p2))) {
            break;
        }
        fuel_p3 = left_p4;
        auto [i_p5, q_p6] = crate::syntax::parser::parse_ident(p_p2);
        ps_p1 = crate::prelude::push(ps_p1, i_p5);
        p_p2 = q_p6;
    }
    this_ = std::tuple{ps_p1, p_p2};
    return this_;
}


/// IsPlainLower: fn TokKind -> Bool
bool is_plain_lower(const crate::syntax::lexer::TokKind& tok_kind0) {
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(tok_kind0)) {
        auto&& n_p0 = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(tok_kind0).a0;
        return (prism_rtl::deref(n_p0).case_ == crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseLower{})) && (prism_rtl::deref(n_p0).sigils == Text::lit(""));
    }
    {
        return false;
    }
}


/// ParseTypeDecl: unbounded fn Ps -> ((TypeDecl, Ps))
std::tuple<crate::syntax::decls::TypeDecl, crate::syntax::parser::Ps> parse_type_decl(const crate::syntax::parser::Ps& p0_p0) {
    auto start_p1 = crate::syntax::parser::here(p0_p0);
    auto [name_p2, p1_p3] = crate::syntax::parser::parse_qual_name(crate::syntax::parser::adv(p0_p0));
    auto [params_p4, p2_p5] = lower_params(p1_p3);
    auto [body_o6, p3_p7] = crate::syntax::parser::at_op(p2_p5, Text::lit("="))
        ? parse_type_body(crate::syntax::parser::adv(p2_p5), name_p2, params_p4)
        : std::tuple{std::optional<crate::syntax::decls::TypeBody>{}, p2_p5};
    return std::tuple{crate::syntax::decls::TypeDecl{.name = name_p2, .params = params_p4, .body = body_o6, .span = crate::syntax::parser::to(start_p1, crate::syntax::parser::prev(p3_p7))}, p3_p7};
}


prism_rtl::Turn<std::tuple<crate::syntax::decls::TypeDecl, crate::syntax::parser::Ps>> ParseTypeDecl::cycle() const {
    const auto& p0_p0 = this->p0_p0;
    auto start_p1 = crate::syntax::parser::here(p0_p0);
    auto [name_p2, p1_p3] = crate::syntax::parser::parse_qual_name(crate::syntax::parser::adv(p0_p0));
    auto [params_p4, p2_p5] = lower_params(p1_p3);
    auto [body_o6, p3_p7] = crate::syntax::parser::at_op(p2_p5, Text::lit("="))
        ? parse_type_body(crate::syntax::parser::adv(p2_p5), name_p2, params_p4)
        : std::tuple{std::optional<crate::syntax::decls::TypeBody>{}, p2_p5};
    return prism_rtl::finished(std::tuple{crate::syntax::decls::TypeDecl{.name = name_p2, .params = params_p4, .body = body_o6, .span = crate::syntax::parser::to(start_p1, crate::syntax::parser::prev(p3_p7))}, p3_p7});
}


/// `Start ParseTypeDecl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::decls::TypeDecl, crate::syntax::parser::Ps>> start_parse_type_decl(crate::syntax::parser::Ps p0_p0) {
    return prism_rtl::make_rc<ParseTypeDecl>(p0_p0);
}


/// ParseTypeBody: unbounded fn Ps, QualName, [Ident] -> ((?TypeBody, Ps))
std::tuple<std::optional<crate::syntax::decls::TypeBody>, crate::syntax::parser::Ps> parse_type_body(const crate::syntax::parser::Ps& p_p0, const crate::syntax::QualName& name_p1, const Array<crate::syntax::Ident>& params_p2) {
    auto&& _m = crate::syntax::parser::kind(p_p0);
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m11097_0_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m11097_0_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        if (m11097_0_0 == Text::lit("record")) {
            if (m11097_0_1 == Text::lit("")) {
                auto [fields_p3, q_p4] = parse_field_block(crate::syntax::parser::adv(p_p0));
                return std::tuple{std::optional(crate::syntax::decls::TypeBody(crate::syntax::decls::TypeBody::TbRecord{fields_p3})), q_p4};
            }
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m11097_1_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m11097_1_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        if (m11097_1_0 == Text::lit("choice")) {
            if (m11097_1_1 == Text::lit("")) {
                auto p1_p5 = crate::syntax::parser::expect_colon(crate::syntax::parser::adv(p_p0));
                return crate::syntax::parser::at_open_l(p1_p5)
                    ? ({
                    auto [cases_p6, q_p7] = crate::syntax::parser::layout_items(crate::syntax::parser::adv(p1_p5), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::decls::Case_, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([&](crate::syntax::parser::Ps a0) { return entered(start_parse_case(a0)); })));
                    std::tuple{std::optional(crate::syntax::decls::TypeBody(crate::syntax::decls::TypeBody::TbChoice{cases_p6})), q_p7};
                })
                    : std::tuple{std::optional<crate::syntax::decls::TypeBody>{}, crate::syntax::parser::error_here(p1_p5, Text::lit("a choice\'s cases stand in an indented block after `choice:`"))};
            }
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m11097_2_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m11097_2_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        if (m11097_2_0 == Text::lit("row")) {
            if (m11097_2_1 == Text::lit("")) {
                return std::tuple{std::optional(crate::syntax::decls::TypeBody(crate::syntax::decls::TypeBody::TbRow{})), crate::syntax::parser::adv(p_p0)};
            }
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m)) {
        auto&& n_p8 = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        if (((prism_rtl::deref(n_p8).sigils == Text::lit("")) && (len(n_p8->path_) == Nat(1u))) && (crate::syntax::lexer::chars::last(n_p8->path_) == crate::syntax::lexer::chars::last(name_p1.path_))) {
            auto [c_p9, q_pa] = parse_case(p_p0);
            return std::tuple{std::optional(crate::syntax::decls::TypeBody(crate::syntax::decls::TypeBody::TbNewtype{c_p9})), q_pa};
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m)) {
        auto&& n_pb = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        if (is_unit_body(p_p0, n_pb, params_p2)) {
            auto [i_pc, q_pd] = crate::syntax::parser::parse_ident(p_p0);
            return std::tuple{std::optional(crate::syntax::decls::TypeBody(crate::syntax::decls::TypeBody::TbUnit{i_pc})), q_pd};
        }
    }
    {
        auto [ty_pe, q_pf] = crate::syntax::parser::types::parse_type(p_p0);
        return std::tuple{std::optional(crate::syntax::decls::TypeBody(crate::syntax::decls::TypeBody::TbAlias{ty_pe})), q_pf};
    }
}


prism_rtl::Turn<std::tuple<std::optional<crate::syntax::decls::TypeBody>, crate::syntax::parser::Ps>> ParseTypeBody::cycle() const {
    const auto& p_p0 = this->p_p0;
    const auto& name_p1 = this->name_p1;
    const auto& params_p2 = this->params_p2;
    return ({
        auto&& _m = crate::syntax::parser::kind(p_p0);
        prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& m11097_0_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m11097_0_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        (m11097_0_0 == Text::lit("record")) && (m11097_0_1 == Text::lit(""));
    }) ? ({
        auto&& m11097_0_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m11097_0_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        ({
        auto p_p0_1 = p_p0;
        call_then(start_parse_field_block(crate::syntax::parser::adv(p_p0_1)), [=](std::tuple<Array<crate::syntax::decls::Field>, crate::syntax::parser::Ps> parse_field_block_11161) {
        return ({
            auto [fields_p3, q_p4] = parse_field_block_11161;
            (prism_rtl::finished(std::tuple{std::optional(crate::syntax::decls::TypeBody(crate::syntax::decls::TypeBody::TbRecord{fields_p3})), q_p4}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& m11097_1_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m11097_1_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        (m11097_1_0 == Text::lit("choice")) && (m11097_1_1 == Text::lit(""));
    }) ? ({
        auto&& m11097_1_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m11097_1_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        ({
        auto p1_p5 = crate::syntax::parser::expect_colon(crate::syntax::parser::adv(p_p0));
        (crate::syntax::parser::at_open_l(p1_p5)
        ? call_then(crate::syntax::parser::start_layout_items(crate::syntax::parser::adv(p1_p5), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::decls::Case_, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([&](crate::syntax::parser::Ps a0) { return entered(start_parse_case(a0)); }))), [=](std::tuple<Array<crate::syntax::decls::Case_>, crate::syntax::parser::Ps> layout_items_11333) {
        return ({
            auto [cases_p6, q_p7] = layout_items_11333;
            (prism_rtl::finished(std::tuple{std::optional(crate::syntax::decls::TypeBody(crate::syntax::decls::TypeBody::TbChoice{cases_p6})), q_p7}));
        });
    })
        : prism_rtl::finished(std::tuple{std::optional<crate::syntax::decls::TypeBody>{}, crate::syntax::parser::error_here(p1_p5, Text::lit("a choice\'s cases stand in an indented block after `choice:`"))}));
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& m11097_2_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m11097_2_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        (m11097_2_0 == Text::lit("row")) && (m11097_2_1 == Text::lit(""));
    }) ? ({
        auto&& m11097_2_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m11097_2_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        prism_rtl::finished(std::tuple{std::optional(crate::syntax::decls::TypeBody(crate::syntax::decls::TypeBody::TbRow{})), crate::syntax::parser::adv(p_p0)});
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m) && ({
        auto&& n_p8 = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        (((prism_rtl::deref(n_p8).sigils == Text::lit("")) && (len(n_p8->path_) == Nat(1u))) && (crate::syntax::lexer::chars::last(n_p8->path_) == crate::syntax::lexer::chars::last(name_p1->path_)));
    }) ? ({
        auto&& n_p8 = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        ({
        auto p_p0_1 = p_p0;
        call_then(start_parse_case(p_p0_1), [=](std::tuple<crate::syntax::decls::Case_, crate::syntax::parser::Ps> parse_case_11752) {
        return ({
            auto [c_p9, q_pa] = parse_case_11752;
            (prism_rtl::finished(std::tuple{std::optional(crate::syntax::decls::TypeBody(crate::syntax::decls::TypeBody::TbNewtype{c_p9})), q_pa}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m) && ({
        auto&& n_pb = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        is_unit_body(p_p0, n_pb, params_p2);
    }) ? ({
        auto&& n_pb = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        ({
        auto [i_pc, q_pd] = crate::syntax::parser::parse_ident(p_p0);
        (prism_rtl::finished(std::tuple{std::optional(crate::syntax::decls::TypeBody(crate::syntax::decls::TypeBody::TbUnit{i_pc})), q_pd}));
    });
    })
        : ({
        auto p_p0_1 = p_p0;
        call_then(crate::syntax::parser::types::start_parse_type(p_p0_1), [=](std::tuple<crate::syntax::Type, crate::syntax::parser::Ps> parse_type_12008) {
        return ({
            auto [ty_pe, q_pf] = parse_type_12008;
            (prism_rtl::finished(std::tuple{std::optional(crate::syntax::decls::TypeBody(crate::syntax::decls::TypeBody::TbAlias{ty_pe})), q_pf}));
        });
    });
    });
    });
}


/// `Start ParseTypeBody, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<std::optional<crate::syntax::decls::TypeBody>, crate::syntax::parser::Ps>> start_parse_type_body(crate::syntax::parser::Ps p_p0, crate::syntax::QualName name_p1, Array<crate::syntax::Ident> params_p2) {
    return prism_rtl::make_rc<ParseTypeBody>(p_p0, name_p1, params_p2);
}


/// IsUnitBody: fn Ps, NameTok, [Ident] -> Bool
bool is_unit_body(const crate::syntax::parser::Ps& p_p0, const crate::syntax::lexer::NameTok& n_p1, const Array<crate::syntax::Ident>& params_p2) {
    auto w_p3 = or_(index(n_p1.path_, Nat(0u)), Text::lit(""));
    auto param_p4 = fold(params_p2, false, [&](const bool& seen_p6, const crate::syntax::Ident& i_p7) { return prism_rtl::deref(seen_p6) || (prism_rtl::deref(i_p7).name == w_p3); });
    auto ends_p5 = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = crate::syntax::parser::kind_at(p_p0, Nat(1u));
        if (prism_rtl::is<crate::syntax::lexer::TokKind::KLaySep>(_m)) {
            _v.set(true);
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::lexer::TokKind::KLayOpen>(_m)) {
            _v.set(true);
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::lexer::TokKind::KLayClose>(_m)) {
            _v.set(true);
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::lexer::TokKind::KEof>(_m)) {
            _v.set(true);
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
    return ((((n_p1.sigils == Text::lit("")) && (n_p1.case_ == crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseLower{}))) && (len(n_p1.path_) == Nat(1u))) && (!std::move(param_p4))) && std::move(ends_p5);
}


/// ParseFieldBlock: unbounded fn Ps -> (([Field], Ps))
std::tuple<Array<crate::syntax::decls::Field>, crate::syntax::parser::Ps> parse_field_block(const crate::syntax::parser::Ps& p0_p0) {
    auto p_p1 = crate::syntax::parser::expect_colon(p0_p0);
    return crate::syntax::parser::at_open_l(p_p1)
        ? crate::syntax::parser::layout_items(crate::syntax::parser::adv(p_p1), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::decls::Field, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([&](crate::syntax::parser::Ps a0) { return entered(start_parse_field(a0)); })))
        : std::tuple{Array<crate::syntax::decls::Field>{}, crate::syntax::parser::error_here(p_p1, Text::lit("fields stand in an indented block, one `name: Type` per line"))};
}


prism_rtl::Turn<std::tuple<Array<crate::syntax::decls::Field>, crate::syntax::parser::Ps>> ParseFieldBlock::cycle() const {
    const auto& p0_p0 = this->p0_p0;
    auto p_p1 = crate::syntax::parser::expect_colon(p0_p0);
    return crate::syntax::parser::at_open_l(p_p1)
        ? prism_rtl::more(prism_rtl::rc(crate::syntax::parser::LayoutItems(crate::syntax::parser::adv(p_p1), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::decls::Field, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([&](crate::syntax::parser::Ps a0) { return entered(start_parse_field(a0)); })))))
        : prism_rtl::finished(std::tuple{Array<crate::syntax::decls::Field>{}, crate::syntax::parser::error_here(p_p1, Text::lit("fields stand in an indented block, one `name: Type` per line"))});
}


/// `Start ParseFieldBlock, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::syntax::decls::Field>, crate::syntax::parser::Ps>> start_parse_field_block(crate::syntax::parser::Ps p0_p0) {
    return prism_rtl::make_rc<ParseFieldBlock>(p0_p0);
}


/// ParseField: unbounded fn Ps -> ((Field, Ps))
std::tuple<crate::syntax::decls::Field, crate::syntax::parser::Ps> parse_field(const crate::syntax::parser::Ps& p_p0) {
    auto start_p1 = crate::syntax::parser::here(p_p0);
    auto [name_p2, p1_p3] = crate::syntax::parser::parse_ident(p_p0);
    auto [ty_p4, p2_p5] = crate::syntax::parser::types::parse_type(crate::syntax::parser::expect_colon(p1_p3));
    return std::tuple{crate::syntax::decls::Field{.name = name_p2, .ty = ty_p4, .span = crate::syntax::parser::to(start_p1, crate::syntax::parser::prev(p2_p5))}, p2_p5};
}


prism_rtl::Turn<std::tuple<crate::syntax::decls::Field, crate::syntax::parser::Ps>> ParseField::cycle() const {
    const auto& p_p0 = this->p_p0;
    auto start_p1 = crate::syntax::parser::here(p_p0);
    auto [name_p2, p1_p3] = crate::syntax::parser::parse_ident(p_p0);
    return call_then(crate::syntax::parser::types::start_parse_type(crate::syntax::parser::expect_colon(p1_p3)), [=](std::tuple<crate::syntax::Type, crate::syntax::parser::Ps> parse_type_12885) {
        return ({
            auto [ty_p4, p2_p5] = parse_type_12885;
            (prism_rtl::finished(std::tuple{crate::syntax::decls::Field{.name = name_p2, .ty = ty_p4, .span = crate::syntax::parser::to(start_p1, crate::syntax::parser::prev(p2_p5))}, p2_p5}));
        });
    });
}


/// `Start ParseField, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::decls::Field, crate::syntax::parser::Ps>> start_parse_field(crate::syntax::parser::Ps p_p0) {
    return prism_rtl::make_rc<ParseField>(p_p0);
}


/// ParseCase: unbounded fn Ps -> ((Case, Ps))
std::tuple<crate::syntax::decls::Case_, crate::syntax::parser::Ps> parse_case(const crate::syntax::parser::Ps& p0_p0) {
    auto start_p1 = crate::syntax::parser::here(p0_p0);
    auto [name_p3, p1_p4] = crate::syntax::parser::parse_sname(p0_p0);
    auto p2_p2 = prism_rtl::deref(name_p3).sigils != Text::lit("")
        ? crate::syntax::parser::note_error(p1_p4, prism_rtl::deref(name_p3).span, Text::lit("a constructor takes no sigil"))
        : p1_p4;
    return crate::syntax::parser::at_colon(p2_p2)
        ? ({
        auto p3_p5 = crate::syntax::parser::adv(p2_p2);
        auto [args_p7, p4_p8] = crate::syntax::parser::at_op(p3_p5, Text::lit("->"))
            ? std::tuple{Array<crate::syntax::Type>{}, p3_p5}
            : crate::syntax::parser::commas(p3_p5, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::Type, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([&](crate::syntax::parser::Ps a0) { return entered(crate::syntax::parser::types::start_parse_emit_type(a0)); })));
        auto [result_p9, p5_pa] = crate::syntax::parser::types::parse_type(crate::syntax::parser::expect_op(p4_p8, Text::lit("->")));
        auto p6_p6 = crate::syntax::parser::out_of_scope(p5_pa, start_p1, Text::lit("indexed choices/GADTs for user types"), prism_rtl::cat("`", crate::syntax::parser::name_text(name_p3), "` is an indexed alternative: indexed choices for user types are out of this compiler"));
        std::tuple{crate::syntax::decls::Case_{.name = name_p3, .args = args_p7, .indexed = std::optional(result_p9), .span = crate::syntax::parser::to(start_p1, crate::syntax::parser::prev(p6_p6))}, p6_p6};
    })
        : ({
        auto [args_pb, p3_pc] = crate::syntax::parser::at_stmt_boundary(p2_p2)
            ? std::tuple{Array<crate::syntax::Type>{}, p2_p2}
            : crate::syntax::parser::commas(p2_p2, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::Type, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([&](crate::syntax::parser::Ps a0) { return entered(crate::syntax::parser::types::start_parse_type(a0)); })));
        std::tuple{crate::syntax::decls::Case_{.name = name_p3, .args = args_pb, .indexed = std::optional<crate::syntax::Type>{}, .span = crate::syntax::parser::to(start_p1, crate::syntax::parser::prev(p3_pc))}, p3_pc};
    });
}


prism_rtl::Turn<std::tuple<crate::syntax::decls::Case_, crate::syntax::parser::Ps>> ParseCase::cycle() const {
    const auto& p0_p0 = this->p0_p0;
    auto start_p1 = crate::syntax::parser::here(p0_p0);
    auto [name_p3, p1_p4] = crate::syntax::parser::parse_sname(p0_p0);
    auto p2_p2 = prism_rtl::deref(name_p3).sigils != Text::lit("")
        ? crate::syntax::parser::note_error(p1_p4, prism_rtl::deref(name_p3).span, Text::lit("a constructor takes no sigil"))
        : p1_p4;
    return crate::syntax::parser::at_colon(p2_p2)
        ? ({
        auto p3_p5 = crate::syntax::parser::adv(p2_p2);
        auto [args_p7, p4_p8] = crate::syntax::parser::at_op(p3_p5, Text::lit("->"))
            ? std::tuple{Array<crate::syntax::Type>{}, p3_p5}
            : crate::syntax::parser::commas(p3_p5, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::Type, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([&](crate::syntax::parser::Ps a0) { return entered(crate::syntax::parser::types::start_parse_emit_type(a0)); })));
        call_then(crate::syntax::parser::types::start_parse_type(crate::syntax::parser::expect_op(p4_p8, Text::lit("->"))), [=](std::tuple<crate::syntax::Type, crate::syntax::parser::Ps> parse_type_13499) {
        return ({
            auto [result_p9, p5_pa] = parse_type_13499;
            auto p6_p6 = crate::syntax::parser::out_of_scope(p5_pa, start_p1, Text::lit("indexed choices/GADTs for user types"), prism_rtl::cat("`", crate::syntax::parser::name_text(name_p3), "` is an indexed alternative: indexed choices for user types are out of this compiler"));
            (prism_rtl::finished(std::tuple{crate::syntax::decls::Case_{.name = name_p3, .args = args_p7, .indexed = std::optional(result_p9), .span = crate::syntax::parser::to(start_p1, crate::syntax::parser::prev(p6_p6))}, p6_p6}));
        });
    });
    })
        : ({
        auto [args_pb, p3_pc] = crate::syntax::parser::at_stmt_boundary(p2_p2)
            ? std::tuple{Array<crate::syntax::Type>{}, p2_p2}
            : crate::syntax::parser::commas(p2_p2, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::Type, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([&](crate::syntax::parser::Ps a0) { return entered(crate::syntax::parser::types::start_parse_type(a0)); })));
        (prism_rtl::finished(std::tuple{crate::syntax::decls::Case_{.name = name_p3, .args = args_pb, .indexed = std::optional<crate::syntax::Type>{}, .span = crate::syntax::parser::to(start_p1, crate::syntax::parser::prev(p3_pc))}, p3_pc}));
    });
}


/// `Start ParseCase, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::decls::Case_, crate::syntax::parser::Ps>> start_parse_case(crate::syntax::parser::Ps p0_p0) {
    return prism_rtl::make_rc<ParseCase>(p0_p0);
}


/// ParseTagDecl: unbounded fn Ps -> ((TagDecl, Ps))
std::tuple<crate::syntax::decls::TagDecl, crate::syntax::parser::Ps> parse_tag_decl(const crate::syntax::parser::Ps& p0_p0) {
    auto start_p1 = crate::syntax::parser::here(p0_p0);
    auto [name_p2, p1_p3] = crate::syntax::parser::parse_qual_name(crate::syntax::parser::adv(p0_p0));
    auto [of_type_p4, p2_p5] = crate::syntax::parser::types::parse_type(crate::syntax::parser::expect_kw(p1_p3, Text::lit("of")));
    auto [bounds_p6, p3_p7] = optional_bounds(p2_p5);
    auto [fields_p8, p4_p9] = crate::syntax::parser::at_colon(p3_p7)
        ? parse_field_block(p3_p7)
        : std::tuple{Array<crate::syntax::decls::Field>{}, p3_p7};
    return std::tuple{crate::syntax::decls::TagDecl{.name = name_p2, .of_type = of_type_p4, .bounds = bounds_p6, .fields = fields_p8, .span = crate::syntax::parser::to(start_p1, crate::syntax::parser::prev(p4_p9))}, p4_p9};
}


prism_rtl::Turn<std::tuple<crate::syntax::decls::TagDecl, crate::syntax::parser::Ps>> ParseTagDecl::cycle() const {
    const auto& p0_p0 = this->p0_p0;
    auto start_p1 = crate::syntax::parser::here(p0_p0);
    auto [name_p2, p1_p3] = crate::syntax::parser::parse_qual_name(crate::syntax::parser::adv(p0_p0));
    return call_then(crate::syntax::parser::types::start_parse_type(crate::syntax::parser::expect_kw(p1_p3, Text::lit("of"))), [=](std::tuple<crate::syntax::Type, crate::syntax::parser::Ps> parse_type_14203) {
        return ({
            auto [of_type_p4, p2_p5] = parse_type_14203;
            call_then(start_optional_bounds(p2_p5), [=](std::tuple<Array<crate::syntax::decls::Bound>, crate::syntax::parser::Ps> optional_bounds_14258) {
            return ({
                auto [bounds_p6, p3_p7] = optional_bounds_14258;
                auto [fields_p8, p4_p9] = crate::syntax::parser::at_colon(p3_p7)
                    ? parse_field_block(p3_p7)
                    : std::tuple{Array<crate::syntax::decls::Field>{}, p3_p7};
                (prism_rtl::finished(std::tuple{crate::syntax::decls::TagDecl{.name = name_p2, .of_type = of_type_p4, .bounds = bounds_p6, .fields = fields_p8, .span = crate::syntax::parser::to(start_p1, crate::syntax::parser::prev(p4_p9))}, p4_p9}));
            });
        });
        });
    });
}


/// `Start ParseTagDecl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::decls::TagDecl, crate::syntax::parser::Ps>> start_parse_tag_decl(crate::syntax::parser::Ps p0_p0) {
    return prism_rtl::make_rc<ParseTagDecl>(p0_p0);
}


/// ParseTraitDecl: unbounded fn Ps -> ((TraitDecl, Ps))
std::tuple<crate::syntax::decls::TraitDecl, crate::syntax::parser::Ps> parse_trait_decl(const crate::syntax::parser::Ps& p0_p0) {
    auto start_p1 = crate::syntax::parser::here(p0_p0);
    auto [name_p3, p1_p4] = crate::syntax::parser::parse_trait_ref(crate::syntax::parser::adv(p0_p0));
    auto [params_p5, p2_p6] = lower_params(p1_p4);
    auto [bounds_p7, p3_p8] = optional_bounds(p2_p6);
    auto [items_p9, p4_pa] = parse_trait_items(p3_p8);
    auto decl_p2 = crate::syntax::decls::TraitDecl{.name = name_p3, .params = params_p5, .bounds = bounds_p7, .items = items_p9, .span = crate::syntax::parser::to(start_p1, crate::syntax::parser::prev(p4_pa))};
    return std::tuple{decl_p2, check_higher_kinded(p4_pa, decl_p2)};
}


prism_rtl::Turn<std::tuple<crate::syntax::decls::TraitDecl, crate::syntax::parser::Ps>> ParseTraitDecl::cycle() const {
    const auto& p0_p0 = this->p0_p0;
    auto start_p1 = crate::syntax::parser::here(p0_p0);
    auto [name_p3, p1_p4] = crate::syntax::parser::parse_trait_ref(crate::syntax::parser::adv(p0_p0));
    auto [params_p5, p2_p6] = lower_params(p1_p4);
    return call_then(start_optional_bounds(p2_p6), [=](std::tuple<Array<crate::syntax::decls::Bound>, crate::syntax::parser::Ps> optional_bounds_14716) {
        return ({
            auto [bounds_p7, p3_p8] = optional_bounds_14716;
            call_then(start_parse_trait_items(p3_p8), [=](std::tuple<Array<crate::syntax::decls::TraitItem>, crate::syntax::parser::Ps> parse_trait_items_14758) {
            return ({
                auto [items_p9, p4_pa] = parse_trait_items_14758;
                auto decl_p2 = crate::syntax::decls::TraitDecl{.name = name_p3, .params = params_p5, .bounds = bounds_p7, .items = items_p9, .span = crate::syntax::parser::to(start_p1, crate::syntax::parser::prev(p4_pa))};
                (prism_rtl::finished(std::tuple{decl_p2, check_higher_kinded(p4_pa, decl_p2)}));
            });
        });
        });
    });
}


/// `Start ParseTraitDecl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::decls::TraitDecl, crate::syntax::parser::Ps>> start_parse_trait_decl(crate::syntax::parser::Ps p0_p0) {
    return prism_rtl::make_rc<ParseTraitDecl>(p0_p0);
}


/// ParseImplDecl: unbounded fn Ps -> ((ImplDecl, Ps))
std::tuple<crate::syntax::decls::ImplDecl, crate::syntax::parser::Ps> parse_impl_decl(const crate::syntax::parser::Ps& p0_p0) {
    auto start_p1 = crate::syntax::parser::here(p0_p0);
    auto [trait_ref_p2, p1_p3] = crate::syntax::parser::parse_trait_ref(crate::syntax::parser::adv(p0_p0));
    auto [ty_p4, p2_p5] = crate::syntax::parser::types::parse_type(p1_p3);
    auto [bounds_p6, p3_p7] = optional_bounds(p2_p5);
    auto [items_p8, p4_p9] = parse_trait_items(p3_p7);
    return std::tuple{crate::syntax::decls::ImplDecl{.trait_ref = trait_ref_p2, .ty = ty_p4, .bounds = bounds_p6, .items = items_p8, .span = crate::syntax::parser::to(start_p1, crate::syntax::parser::prev(p4_p9))}, p4_p9};
}


prism_rtl::Turn<std::tuple<crate::syntax::decls::ImplDecl, crate::syntax::parser::Ps>> ParseImplDecl::cycle() const {
    const auto& p0_p0 = this->p0_p0;
    auto start_p1 = crate::syntax::parser::here(p0_p0);
    auto [trait_ref_p2, p1_p3] = crate::syntax::parser::parse_trait_ref(crate::syntax::parser::adv(p0_p0));
    return call_then(crate::syntax::parser::types::start_parse_type(p1_p3), [=](std::tuple<crate::syntax::Type, crate::syntax::parser::Ps> parse_type_15144) {
        return ({
            auto [ty_p4, p2_p5] = parse_type_15144;
            call_then(start_optional_bounds(p2_p5), [=](std::tuple<Array<crate::syntax::decls::Bound>, crate::syntax::parser::Ps> optional_bounds_15182) {
            return ({
                auto [bounds_p6, p3_p7] = optional_bounds_15182;
                call_then(start_parse_trait_items(p3_p7), [=](std::tuple<Array<crate::syntax::decls::TraitItem>, crate::syntax::parser::Ps> parse_trait_items_15224) {
                return ({
                    auto [items_p8, p4_p9] = parse_trait_items_15224;
                    (prism_rtl::finished(std::tuple{crate::syntax::decls::ImplDecl{.trait_ref = trait_ref_p2, .ty = ty_p4, .bounds = bounds_p6, .items = items_p8, .span = crate::syntax::parser::to(start_p1, crate::syntax::parser::prev(p4_p9))}, p4_p9}));
                });
            });
            });
        });
        });
    });
}


/// `Start ParseImplDecl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::decls::ImplDecl, crate::syntax::parser::Ps>> start_parse_impl_decl(crate::syntax::parser::Ps p0_p0) {
    return prism_rtl::make_rc<ParseImplDecl>(p0_p0);
}


/// ParseTraitItems: unbounded fn Ps -> (([TraitItem], Ps))
std::tuple<Array<crate::syntax::decls::TraitItem>, crate::syntax::parser::Ps> parse_trait_items(const crate::syntax::parser::Ps& p0_p0) {
    auto p_p1 = crate::syntax::parser::expect_colon(p0_p0);
    return crate::syntax::parser::at_open_l(p_p1)
        ? ({
        auto inside_p2 = ({
            crate::syntax::parser::Ps this_ = crate::syntax::parser::adv(p_p1);
            this_.in_trait = true;
            (std::move(this_));
        });
        auto [items_p3, q_p4] = crate::syntax::parser::layout_items(inside_p2, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::decls::TraitItem, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([&](crate::syntax::parser::Ps a0) { return entered(start_parse_trait_item(a0)); })));
        std::tuple{items_p3, ({
        crate::syntax::parser::Ps this_ = q_p4;
        this_.in_trait = prism_rtl::deref(p_p1).in_trait;
        (std::move(this_));
    })};
    })
        : std::tuple{Array<crate::syntax::decls::TraitItem>{}, crate::syntax::parser::error_here(p_p1, Text::lit("a trait\'s or impl\'s items stand in an indented block"))};
}


prism_rtl::Turn<std::tuple<Array<crate::syntax::decls::TraitItem>, crate::syntax::parser::Ps>> ParseTraitItems::cycle() const {
    const auto& p0_p0 = this->p0_p0;
    auto p_p1 = crate::syntax::parser::expect_colon(p0_p0);
    return crate::syntax::parser::at_open_l(p_p1)
        ? ({
        auto inside_p2 = ({
            crate::syntax::parser::Ps this_ = crate::syntax::parser::adv(p_p1);
            this_.in_trait = true;
            (std::move(this_));
        });
        call_then(crate::syntax::parser::start_layout_items(inside_p2, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::syntax::decls::TraitItem, crate::syntax::parser::Ps>>(crate::syntax::parser::Ps)>>(prism_rtl::rc([&](crate::syntax::parser::Ps a0) { return entered(start_parse_trait_item(a0)); }))), [=](std::tuple<Array<crate::syntax::decls::TraitItem>, crate::syntax::parser::Ps> layout_items_15566) {
        return ({
            auto [items_p3, q_p4] = layout_items_15566;
            (prism_rtl::finished(std::tuple{items_p3, ({
            crate::syntax::parser::Ps this_ = q_p4;
            this_.in_trait = prism_rtl::deref(p_p1).in_trait;
            (std::move(this_));
        })}));
        });
    });
    })
        : prism_rtl::finished(std::tuple{Array<crate::syntax::decls::TraitItem>{}, crate::syntax::parser::error_here(p_p1, Text::lit("a trait\'s or impl\'s items stand in an indented block"))});
}


/// `Start ParseTraitItems, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::syntax::decls::TraitItem>, crate::syntax::parser::Ps>> start_parse_trait_items(crate::syntax::parser::Ps p0_p0) {
    return prism_rtl::make_rc<ParseTraitItems>(p0_p0);
}


/// ParseTraitItem: unbounded fn Ps -> ((TraitItem, Ps))
std::tuple<crate::syntax::decls::TraitItem, crate::syntax::parser::Ps> parse_trait_item(const crate::syntax::parser::Ps& p_p0) {
    auto&& _m = crate::syntax::parser::kind(p_p0);
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m15834_0_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        if (m15834_0_0 == Text::lit("fn")) {
            auto [f_p1, q_p2] = parse_fn_clause(p_p0);
            return std::tuple{crate::syntax::decls::TraitItem(crate::syntax::decls::TraitItem::TiFn{f_p1}), q_p2};
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m15834_1_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        if (m15834_1_0 == Text::lit("type")) {
            auto start_p3 = crate::syntax::parser::here(p_p0);
            auto p1_p4 = crate::syntax::parser::adv(p_p0);
            auto&& _m = crate::syntax::parser::kind(p1_p4);
            if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m)) {
                auto&& n_p5 = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
                if (((prism_rtl::deref(n_p5).case_ == crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseUpper{})) && (prism_rtl::deref(n_p5).sigils == Text::lit(""))) && (len(n_p5->path_) == Nat(1u))) {
                    auto name_p6 = crate::syntax::Ident{.name = or_(index(n_p5->path_, Nat(0u)), Text::lit("")), .span = crate::syntax::parser::here(p1_p4)};
                    auto [params_p8, p2_p9] = lower_params(crate::syntax::parser::adv(p1_p4));
                    auto [value_oa, p3_pb] = crate::syntax::parser::at_op(p2_p9, Text::lit("="))
                        ? optional_type(crate::syntax::parser::adv(p2_p9))
                        : std::tuple{std::optional<crate::syntax::Type>{}, p2_p9};
                    auto item_p7 = crate::syntax::decls::TraitItem(crate::syntax::decls::TraitItem::TiAssocType{name_p6, params_p8, value_oa, crate::syntax::parser::to(start_p3, crate::syntax::parser::prev(p3_pb))});
                    return std::tuple{item_p7, p3_pb};
                }
            }
            {
                auto item_pc = crate::syntax::decls::TraitItem(crate::syntax::decls::TraitItem::TiAssocType{crate::syntax::parser::no_ident(), Array<crate::syntax::Ident>{}, std::optional<crate::syntax::Type>{}, crate::syntax::parser::no_range()});
                return std::tuple{item_pc, crate::syntax::parser::error_here(p1_p4, Text::lit("expected the associated type\'s name"))};
            }
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m15834_2_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        if (m15834_2_0 == Text::lit("row")) {
            auto start_pd = crate::syntax::parser::here(p_p0);
            auto [name_pf, q_pg] = crate::syntax::parser::parse_sname(crate::syntax::parser::adv(p_p0));
            auto item_pe = crate::syntax::decls::TraitItem(crate::syntax::decls::TraitItem::TiAssocRow{name_pf, crate::syntax::parser::to(start_pd, crate::syntax::parser::prev(q_pg))});
            return std::tuple{item_pe, q_pg};
        }
    }
    {
        auto [sig_ph, q_pi] = parse_signature(p_p0);
        return std::tuple{crate::syntax::decls::TraitItem(crate::syntax::decls::TraitItem::TiSignature{sig_ph}), q_pi};
    }
}


prism_rtl::Turn<std::tuple<crate::syntax::decls::TraitItem, crate::syntax::parser::Ps>> ParseTraitItem::cycle() const {
    const auto& p_p0 = this->p_p0;
    return ({
        auto&& _m = crate::syntax::parser::kind(p_p0);
        prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& m15834_0_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        (m15834_0_0 == Text::lit("fn"));
    }) ? ({
        auto&& m15834_0_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        ({
        auto p_p0_1 = p_p0;
        call_then(start_parse_fn_clause(p_p0_1), [=](std::tuple<crate::syntax::decls::FnClause, crate::syntax::parser::Ps> parse_fn_clause_15893) {
        return ({
            auto [f_p1, q_p2] = parse_fn_clause_15893;
            (prism_rtl::finished(std::tuple{crate::syntax::decls::TraitItem(crate::syntax::decls::TraitItem::TiFn{f_p1}), q_p2}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& m15834_1_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        (m15834_1_0 == Text::lit("type"));
    }) ? ({
        auto&& m15834_1_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        ({
        auto start_p3 = crate::syntax::parser::here(p_p0);
        auto p1_p4 = crate::syntax::parser::adv(p_p0);
        ({
        auto&& _m = crate::syntax::parser::kind(p1_p4);
        prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m) && ({
        auto&& n_p5 = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        (((prism_rtl::deref(n_p5).case_ == crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseUpper{})) && (prism_rtl::deref(n_p5).sigils == Text::lit(""))) && (len(n_p5->path_) == Nat(1u)));
    }) ? ({
        auto&& n_p5 = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        ({
        auto name_p6 = crate::syntax::Ident{.name = or_(index(n_p5->path_, Nat(0u)), Text::lit("")), .span = crate::syntax::parser::here(p1_p4)};
        auto [params_p8, p2_p9] = lower_params(crate::syntax::parser::adv(p1_p4));
        auto [value_oa, p3_pb] = crate::syntax::parser::at_op(p2_p9, Text::lit("="))
            ? optional_type(crate::syntax::parser::adv(p2_p9))
            : std::tuple{std::optional<crate::syntax::Type>{}, p2_p9};
        auto item_p7 = crate::syntax::decls::TraitItem(crate::syntax::decls::TraitItem::TiAssocType{name_p6, params_p8, value_oa, crate::syntax::parser::to(start_p3, crate::syntax::parser::prev(p3_pb))});
        (prism_rtl::finished(std::tuple{item_p7, p3_pb}));
    });
    })
        : ({
        auto item_pc = crate::syntax::decls::TraitItem(crate::syntax::decls::TraitItem::TiAssocType{crate::syntax::parser::no_ident(), Array<crate::syntax::Ident>{}, std::optional<crate::syntax::Type>{}, crate::syntax::parser::no_range()});
        (prism_rtl::finished(std::tuple{item_pc, crate::syntax::parser::error_here(p1_p4, Text::lit("expected the associated type\'s name"))}));
    });
    });
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& m15834_2_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        (m15834_2_0 == Text::lit("row"));
    }) ? ({
        auto&& m15834_2_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        ({
        auto start_pd = crate::syntax::parser::here(p_p0);
        auto [name_pf, q_pg] = crate::syntax::parser::parse_sname(crate::syntax::parser::adv(p_p0));
        auto item_pe = crate::syntax::decls::TraitItem(crate::syntax::decls::TraitItem::TiAssocRow{name_pf, crate::syntax::parser::to(start_pd, crate::syntax::parser::prev(q_pg))});
        (prism_rtl::finished(std::tuple{item_pe, q_pg}));
    });
    })
        : ({
        auto p_p0_1 = p_p0;
        call_then(start_parse_signature(p_p0_1), [=](std::tuple<crate::syntax::decls::Signature, crate::syntax::parser::Ps> parse_signature_16833) {
        return ({
            auto [sig_ph, q_pi] = parse_signature_16833;
            (prism_rtl::finished(std::tuple{crate::syntax::decls::TraitItem(crate::syntax::decls::TraitItem::TiSignature{sig_ph}), q_pi}));
        });
    });
    });
    });
}


/// `Start ParseTraitItem, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::decls::TraitItem, crate::syntax::parser::Ps>> start_parse_trait_item(crate::syntax::parser::Ps p_p0) {
    return prism_rtl::make_rc<ParseTraitItem>(p_p0);
}


/// OptionalType: unbounded fn Ps -> ((?Type, Ps))
std::tuple<std::optional<crate::syntax::Type>, crate::syntax::parser::Ps> optional_type(const crate::syntax::parser::Ps& p_p0) {
    auto [ty_p1, q_p2] = crate::syntax::parser::types::parse_type(p_p0);
    return std::tuple{std::optional(ty_p1), q_p2};
}


prism_rtl::Turn<std::tuple<std::optional<crate::syntax::Type>, crate::syntax::parser::Ps>> OptionalType::cycle() const {
    const auto& p_p0 = this->p_p0;
    auto p_p0_1 = p_p0;
    return call_then(crate::syntax::parser::types::start_parse_type(p_p0_1), [=](std::tuple<crate::syntax::Type, crate::syntax::parser::Ps> parse_type_16968) {
        return ({
            auto [ty_p1, q_p2] = parse_type_16968;
            (prism_rtl::finished(std::tuple{std::optional(ty_p1), q_p2}));
        });
    });
}


/// `Start OptionalType, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<std::optional<crate::syntax::Type>, crate::syntax::parser::Ps>> start_optional_type(crate::syntax::parser::Ps p_p0) {
    return prism_rtl::make_rc<OptionalType>(p_p0);
}


/// CheckHigherKinded: fn Ps, TraitDecl -> Ps
crate::syntax::parser::Ps check_higher_kinded(const crate::syntax::parser::Ps& p_p0, const crate::syntax::decls::TraitDecl& t_p1) {
    auto hk_p2 = fold(t_p1.items, false, [&](const bool& seen_p3, const crate::syntax::decls::TraitItem& item_p4) { return prism_rtl::deref(seen_p3) || item_applies(item_p4, t_p1.params); });
    return std::move(hk_p2) && (t_p1.name->path_ != Array(std::vector{Text::lit("Monad")}))
        ? crate::syntax::parser::out_of_scope(p_p0, prism_rtl::deref(t_p1.name).span, Text::lit("higher-kinded traits"), prism_rtl::cat("`^", crate::syntax::lexer::chars::join(t_p1.name->path_, Text::lit(".")), "` applies its parameter to arguments: higher-kinded traits are out of this compiler"))
        : p_p0;
}


/// ItemApplies: fn TraitItem, [Ident] -> Bool
bool item_applies(const crate::syntax::decls::TraitItem& trait_item0, const Array<crate::syntax::Ident>& xs1) {
    auto&& _m = std::tuple{trait_item0, xs1};
    if (prism_rtl::is<crate::syntax::decls::TraitItem::TiSignature>(std::get<0>(_m))) {
        auto&& s_p0 = prism_rtl::as<crate::syntax::decls::TraitItem::TiSignature>(std::get<0>(_m)).a0;
        auto&& params_p1 = std::get<1>(_m);
        return applies(prism_rtl::deref(s_p0).ty, params_p1);
    }
    {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// AnyApplies: fn [Type], [Ident] -> Bool
bool any_applies(const Array<crate::syntax::Type>& ts_p0, const Array<crate::syntax::Ident>& params_p1) {
    return fold(ts_p0, false, [&](const bool& seen_p2, const crate::syntax::Type& t_p3) { return prism_rtl::deref(seen_p2) || applies(t_p3, params_p1); });
}


/// Applies: fn Type, [Ident] -> Bool
bool applies(const crate::syntax::Type& ty_p0, const Array<crate::syntax::Ident>& params_p1) {
    auto&& _m = prism_rtl::deref(ty_p0.kind);
    if (prism_rtl::is<crate::syntax::TypeKind::TName>(_m)) {
        auto&& name_p2 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a0;
        auto&& args_p3 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a1;
        auto head_p4 = ((len(args_p3) > Nat(0u)) && (len(name_p2->path_) == Nat(1u))) && fold(params_p1, false, [&](const bool& seen_p5, const crate::syntax::Ident& i_p6) { return prism_rtl::deref(seen_p5) || (prism_rtl::deref(i_p6).name == or_(index(name_p2->path_, Nat(0u)), Text::lit(""))); });
        return std::move(head_p4) || any_applies(args_p3, params_p1);
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TSigiled>(_m)) {
        auto&& inner_p7 = prism_rtl::as<crate::syntax::TypeKind::TSigiled>(_m).a1;
        return applies(prism_rtl::deref(prism_rtl::deref(inner_p7)), params_p1);
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TGroup>(_m)) {
        auto&& inner_p8 = prism_rtl::as<crate::syntax::TypeKind::TGroup>(_m).a0;
        return applies(prism_rtl::deref(prism_rtl::deref(inner_p8)), params_p1);
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TNonEmpty>(_m)) {
        auto&& inner_p9 = prism_rtl::as<crate::syntax::TypeKind::TNonEmpty>(_m).a0;
        return applies(prism_rtl::deref(prism_rtl::deref(inner_p9)), params_p1);
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TArray>(_m)) {
        auto&& elem_pa = prism_rtl::as<crate::syntax::TypeKind::TArray>(_m).a0;
        return applies(prism_rtl::deref(prism_rtl::deref(elem_pa)), params_p1);
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TTuple>(_m)) {
        auto&& ts_pb = prism_rtl::as<crate::syntax::TypeKind::TTuple>(_m).a0;
        return any_applies(ts_pb, params_p1);
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TRowUnion>(_m)) {
        auto&& ts_pc = prism_rtl::as<crate::syntax::TypeKind::TRowUnion>(_m).a0;
        return any_applies(ts_pc, params_p1);
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TMap>(_m)) {
        auto&& k_pd = prism_rtl::as<crate::syntax::TypeKind::TMap>(_m).a0;
        auto&& v_pe = prism_rtl::as<crate::syntax::TypeKind::TMap>(_m).a1;
        return applies(prism_rtl::deref(prism_rtl::deref(k_pd)), params_p1) || applies(prism_rtl::deref(prism_rtl::deref(v_pe)), params_p1);
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TFn>(_m)) {
        auto&& ps_pf = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a1;
        auto&& result_pg = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a2;
        return any_applies(ps_pf, params_p1) || applies(prism_rtl::deref(prism_rtl::deref(result_pg)), params_p1);
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TEmit>(_m)) {
        auto&& t_ph = prism_rtl::as<crate::syntax::TypeKind::TEmit>(_m).a0;
        auto&& r_pi = prism_rtl::as<crate::syntax::TypeKind::TEmit>(_m).a1;
        return applies(prism_rtl::deref(prism_rtl::deref(t_ph)), params_p1) || applies(prism_rtl::deref(prism_rtl::deref(r_pi)), params_p1);
    }
    {
        return false;
    }
}

}  // namespace crate::syntax::parser::decls
