// The program's `Elem` and `Answer` with their cases, emitted by prismc (claude/backend.md).
// Edit the Prism sources, not this file.
#pragma once

#include "elem.decl.hpp"
#include <fs/types.hpp>
#include <process/types.hpp>

namespace crate {

using namespace prelude;

/// `Elem`, a row kind's values:
///
/// ```prism
/// `Elem r`: an element as a document holds it, its `Level` in a tick.
/// ```
class Elem {
public:
    using prism_value = void;
    struct FsContents {
        fs::FsContents a0;
        bool operator==(const FsContents&) const = default;
    };

    struct FsFile {
        fs::FsFile a0;
        bool operator==(const FsFile&) const = default;
    };

    struct FsList_ {
        fs::FsList_ a0;
        bool operator==(const FsList_&) const = default;
    };

    struct FsOutput {
        fs::FsOutput a0;
        bool operator==(const FsOutput&) const = default;
    };

    struct PreludeExceptions {
        prelude::PreludeExceptions a0;
        bool operator==(const PreludeExceptions&) const = default;
    };

    struct PreludeUnwrap {
        prelude::PreludeUnwrap a0;
        bool operator==(const PreludeUnwrap&) const = default;
    };

    struct ProcessArgs {
        process::ProcessArgs a0;
        bool operator==(const ProcessArgs&) const = default;
    };

    struct ProcessEnv {
        process::ProcessEnv a0;
        bool operator==(const ProcessEnv&) const = default;
    };

    struct ProcessExit {
        process::ProcessExit a0;
        bool operator==(const ProcessExit&) const = default;
    };
    using Cases = std::variant<FsContents, FsFile, FsList_, FsOutput, PreludeExceptions, PreludeUnwrap, ProcessArgs, ProcessEnv, ProcessExit>;
    template <class C>
        requires prism_rtl::one_of<C, FsContents, FsFile, FsList_, FsOutput, PreludeExceptions, PreludeUnwrap, ProcessArgs, ProcessEnv, ProcessExit>
    Elem(C c) : cases_(std::move(c)) {}
    const Cases& cases() const { return cases_; }
    Pod to_pod() const;
    void show(Printer& p) const;
    static Result<Elem> from_pod(const Pod& p);
    Pod level_pod(const Cx& cx) const;
    void level_ports(const Cx& cx, std::vector<prism_rtl::Rc<prism_rtl::Port<Unit>>>& out) const;

private:
    Cases cases_;
};

inline bool operator==(const Elem& a, const Elem& b) { return a.cases() == b.cases(); }

/// `Answer c`: an answer to an element, typed by its tag (Semantics ch. 9): what a host's
/// supplier answers a child place with, and what a World's answer to a forwarded element
/// decodes to, carrying the tag's output.
class Answer {
public:
    using prism_value = void;
    struct FsContents {
        Fallible<crate::fs::Contents> a0;
    };

    struct FsFile {
        Fallible<crate::fs::Contents> a0;
    };

    struct FsList_ {
        Array<Text> a0;
    };

    struct FsOutput {
        crate::fs::WriteState a0;
    };

    struct PreludeExceptions {
        Exception a0;
    };

    struct PreludeUnwrap {
        Pod a0;
    };

    struct ProcessArgs {
        Array<Text> a0;
    };

    struct ProcessEnv {
        std::optional<Text> a0;
    };

    struct ProcessExit {
        Unit a0;
    };
    using Cases = std::variant<FsContents, FsFile, FsList_, FsOutput, PreludeExceptions, PreludeUnwrap, ProcessArgs, ProcessEnv, ProcessExit>;
    template <class C>
        requires prism_rtl::one_of<C, FsContents, FsFile, FsList_, FsOutput, PreludeExceptions, PreludeUnwrap, ProcessArgs, ProcessEnv, ProcessExit>
    Answer(C c) : cases_(std::move(c)) {}
    const Cases& cases() const { return cases_; }
    const char* tag() const;
    Result<Fallible<crate::fs::Contents>> fs_contents() const;
    Result<Fallible<crate::fs::Contents>> fs_file() const;
    Result<Array<Text>> fs_list_() const;
    Result<crate::fs::WriteState> fs_output() const;
    Result<Exception> prelude_exceptions() const;
    Result<Pod> prelude_unwrap() const;
    Result<Array<Text>> process_args() const;
    Result<std::optional<Text>> process_env() const;
    Result<Unit> process_exit() const;
    static Result<Answer> decode(const Elem& e, const Pod& v);

private:
    Cases cases_;
};

}  // namespace crate
