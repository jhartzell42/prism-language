// The cases of the program's `Elem` and `Answer`, emitted by prismc (claude/backend.md).
// Edit the Prism sources, not this file.
#pragma once

#include "elem.decl.hpp"
#include "fs.types.hpp"
#include "process.types.hpp"

namespace crate {

using namespace prelude;

struct Elem::FsContents {
    fs::FsContents a0;
    bool operator==(const FsContents&) const = default;
};


struct Elem::FsFile {
    fs::FsFile a0;
    bool operator==(const FsFile&) const = default;
};


struct Elem::FsList_ {
    fs::FsList_ a0;
    bool operator==(const FsList_&) const = default;
};


struct Elem::FsOutput {
    fs::FsOutput a0;
    bool operator==(const FsOutput&) const = default;
};


struct Elem::PreludeExceptions {
    prelude::PreludeExceptions a0;
    bool operator==(const PreludeExceptions&) const = default;
};


struct Elem::PreludeUnwrap {
    prelude::PreludeUnwrap a0;
    bool operator==(const PreludeUnwrap&) const = default;
};


struct Elem::ProcessArgs {
    process::ProcessArgs a0;
    bool operator==(const ProcessArgs&) const = default;
};


struct Elem::ProcessExit {
    process::ProcessExit a0;
    bool operator==(const ProcessExit&) const = default;
};


inline const Elem::Cases& Elem::cases() const { return *cases_; }

inline bool operator==(const Elem& a, const Elem& b) { return a.cases() == b.cases(); }

struct Answer::FsContents {
    Fallible<fs::Contents> a0;
};


struct Answer::FsFile {
    Fallible<fs::Contents> a0;
};


struct Answer::FsList_ {
    Array<Text> a0;
};


struct Answer::FsOutput {
    fs::WriteState a0;
};


struct Answer::PreludeExceptions {
    Exception a0;
};


struct Answer::PreludeUnwrap {
    Pod a0;
};


struct Answer::ProcessArgs {
    Array<Text> a0;
};


struct Answer::ProcessExit {
    Unit a0;
};


inline const Answer::Cases& Answer::cases() const { return *cases_; }

}  // namespace crate
