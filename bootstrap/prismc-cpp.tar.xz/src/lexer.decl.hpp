// The module `Lexer`: its types, nodes and jobs declared, and its choices' handles, emitted by
// prismc (docs/backend.md). Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace lexer {

struct AttrTok;

struct CallRead;

struct Lex;

struct Lexed;

class Mode;

class NameCase;

struct NameTok;

class PathSegTok;

class RawItem;

struct RawLine;

class TPartTok;

struct TemplateTok;

class TextSegTok;

struct Tok;

class TokKind;

struct TplHow;

struct TplRead;

template <class B>
struct FoldChars;

struct RestOfLine;

struct LexFile;

struct TemplateHead;

struct SkipBlankAndCommentLines;

struct Nested;

struct LexStream;

struct BeginLine;

struct Indentation;

struct ClosesBraceBlock;

struct SkipLine;

struct IndentedLine;

struct LexToken;

struct LexPathToken;

struct LexTokenAt;

struct PushOpSuffix;

struct LexOperator;

struct PushOperator;

struct LexSigils;

struct ReadSigils;

struct LexCaret;

struct LexAttached;

struct LexQualifiedPath;

struct LexIdent;

struct LexWordToken;

struct SkipNonAscii;

struct LexKeyword;

struct LexName;

struct LexNumber;

struct LexRadix;

struct SkipDigits;

struct LexDecimal;

struct NumberTail;

struct Exponent;

struct CheckNoSuffix;

struct LexEscape;

struct UnicodeEscape;

struct LexText;

struct LexChar;

struct CharTail;

struct LexPath;

struct MaybeTemplate;

struct TemplateTagAhead;

struct LexTemplate;

struct TemplateBody;

struct TemplateStep;

struct BraceBlockLine;

struct TemplateItem;

struct TemplateCall;

struct CallStep;

}  // namespace lexer

namespace lexer {

/// `Mode`:
///
/// ```prism
/// type Mode = choice:
/// ```
class Mode {
public:
    using prism_value = void;
    struct MFile;
    struct MBrace;
    struct MPlaceholder;
    struct MPathKey;
    using Cases = std::variant<MFile, MBrace, MPlaceholder, MPathKey>;
    template <class C>
        requires prism_rtl::one_of<C, MFile, MBrace, MPlaceholder, MPathKey>
    Mode(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Mode> from_pod(const Pod& whole);
    friend inline bool operator==(const Mode& a, const Mode& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


/// `NameCase`:
///
/// ```prism
/// type NameCase = choice:
/// ```
class NameCase {
public:
    using prism_value = void;
    struct CaseLower;
    struct CaseUpper;
    struct CaseTopic;
    struct CaseHole;
    struct CaseReserved;
    using Cases = std::variant<CaseLower, CaseUpper, CaseTopic, CaseHole, CaseReserved>;
    template <class C>
        requires prism_rtl::one_of<C, CaseLower, CaseUpper, CaseTopic, CaseHole, CaseReserved>
    NameCase(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<NameCase> from_pod(const Pod& whole);
    friend inline bool operator==(const NameCase& a, const NameCase& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


/// `PathSegTok`:
///
/// ```prism
/// type PathSegTok = choice:
/// ```
class PathSegTok {
public:
    using prism_value = void;
    struct PstNum;
    struct PstGen;
    struct PstKey;
    using Cases = std::variant<PstNum, PstGen, PstKey>;
    template <class C>
        requires prism_rtl::one_of<C, PstNum, PstGen, PstKey>
    PathSegTok(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<PathSegTok> from_pod(const Pod& whole);
    friend inline bool operator==(const PathSegTok& a, const PathSegTok& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


/// `RawItem`:
///
/// ```prism
/// type RawItem = choice:
/// ```
class RawItem {
public:
    using prism_value = void;
    struct RiText;
    struct RiPlaceholder;
    struct RiBlock;
    struct RiCall;
    using Cases = std::variant<RiText, RiPlaceholder, RiBlock, RiCall>;
    template <class C>
        requires prism_rtl::one_of<C, RiText, RiPlaceholder, RiBlock, RiCall>
    RawItem(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<RawItem> from_pod(const Pod& whole);
    friend inline bool operator==(const RawItem& a, const RawItem& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


/// `TPartTok`:
///
/// ```prism
/// type TPartTok = choice:
/// ```
class TPartTok {
public:
    using prism_value = void;
    struct TptText;
    struct TptPlaceholder;
    struct TptBlock;
    struct TptCall;
    using Cases = std::variant<TptText, TptPlaceholder, TptBlock, TptCall>;
    template <class C>
        requires prism_rtl::one_of<C, TptText, TptPlaceholder, TptBlock, TptCall>
    TPartTok(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<TPartTok> from_pod(const Pod& whole);
    friend inline bool operator==(const TPartTok& a, const TPartTok& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


/// `TextSegTok`:
///
/// ```prism
/// type TextSegTok = choice:
/// ```
class TextSegTok {
public:
    using prism_value = void;
    struct TsPlain;
    struct TsPlaceholder;
    using Cases = std::variant<TsPlain, TsPlaceholder>;
    template <class C>
        requires prism_rtl::one_of<C, TsPlain, TsPlaceholder>
    TextSegTok(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<TextSegTok> from_pod(const Pod& whole);
    friend inline bool operator==(const TextSegTok& a, const TextSegTok& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


/// `TokKind`:
///
/// ```prism
/// type TokKind = choice:
/// ```
class TokKind {
public:
    using prism_value = void;
    struct KName;
    struct KFamily;
    struct KTrait;
    struct KKw;
    struct KFree;
    struct KLensDot;
    struct KInt;
    struct KFloat;
    struct KDuration;
    struct KChar;
    struct KText;
    struct KTemplate;
    struct KOp;
    struct KSuffixed;
    struct KDot;
    struct KDotDot;
    struct KComma;
    struct KColon;
    struct KSemi;
    struct KBackslash;
    struct KLambdaBar;
    struct KBar;
    struct KLtLt;
    struct KGtGt;
    struct KOpen;
    struct KClose;
    struct KAbsent;
    struct KNonEmpty;
    struct KPath;
    struct KLayOpen;
    struct KLaySep;
    struct KLayClose;
    struct KEof;
    using Cases = std::variant<KName, KFamily, KTrait, KKw, KFree, KLensDot, KInt, KFloat, KDuration, KChar, KText, KTemplate, KOp, KSuffixed, KDot, KDotDot, KComma, KColon, KSemi, KBackslash, KLambdaBar, KBar, KLtLt, KGtGt, KOpen, KClose, KAbsent, KNonEmpty, KPath, KLayOpen, KLaySep, KLayClose, KEof>;
    template <class C>
        requires prism_rtl::one_of<C, KName, KFamily, KTrait, KKw, KFree, KLensDot, KInt, KFloat, KDuration, KChar, KText, KTemplate, KOp, KSuffixed, KDot, KDotDot, KComma, KColon, KSemi, KBackslash, KLambdaBar, KBar, KLtLt, KGtGt, KOpen, KClose, KAbsent, KNonEmpty, KPath, KLayOpen, KLaySep, KLayClose, KEof>
    TokKind(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<TokKind> from_pod(const Pod& whole);
    friend inline bool operator==(const TokKind& a, const TokKind& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


}  // namespace lexer

}  // namespace crate
