// The module `Check.Expr.Patterns`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <check/expr/patterns/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>

// The module `Check.Expr.Patterns`, from `target/bootstrap/cpp-src/prismc/check/expr/patterns.prism`.
namespace crate::check::expr::patterns {

/// BindPattern: unbounded fn Env, St, Pattern, Ty, Bool -> ((Env, St))
std::tuple<crate::check::expr::Env, crate::check::types::St> bind_pattern_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Pattern_& p_p2, const crate::check::types::Ty& t_p3, const bool& refutable_p4) {
    auto&& _m = prism_rtl::deref(p_p2.kind_p);
    if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
        auto&& n_p5 = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        auto bare_p6 = crate::prelude::or_(crate::prelude::index(prism_rtl::deref(n_p5).path_p, Nat(0u)), Text::lit(""));
        auto is_ctor_p7 = (crate::check::env::is_upper_text_f(bare_p6) && (crate::prelude::len_text(prism_rtl::deref(n_p5).sigils_p) == Nat(0u))) && is_ctor_name_f(env_p0, n_p5);
        return std::move(is_ctor_p7) || (crate::prelude::len(prism_rtl::deref(n_p5).path_p) > Nat(1u))
            ? bind_ctor_f(env_p0, st_p1, p_p2, n_p5, Array<crate::syntax::Pattern_>{}, t_p3)
            : bind_name_f(env_p0, st_p1, n_p5, t_p3);
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PIgnore>(_m)) {
        return std::tuple{env_p0, st_p1};
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PLit>(_m)) {
        auto&& l_p8 = prism_rtl::as<crate::syntax::PatternKind::PLit>(_m).a0;
        auto [lt_p9, st2_pa] = crate::check::expr::infer_lit_f(env_p0, st_p1, l_p8, false, p_p2.span_p);
        return std::tuple{env_p0, crate::check::types::unify::unify_f(st2_pa, t_p3, lt_p9, p_p2.span_p)};
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PNeg>(_m)) {
        auto&& l_pb = prism_rtl::as<crate::syntax::PatternKind::PNeg>(_m).a0;
        auto [lt_pc, st2_pd] = crate::check::expr::infer_lit_f(env_p0, st_p1, l_pb, true, p_p2.span_p);
        return std::tuple{env_p0, crate::check::types::unify::unify_f(st2_pd, t_p3, lt_pc, p_p2.span_p)};
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PUnit>(_m)) {
        return std::tuple{env_p0, crate::check::types::unify::unify_f(st_p1, t_p3, crate::check::types::t_unit_p(), p_p2.span_p)};
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PNil>(_m)) {
        auto [v_pe, st2_pf] = crate::check::types::fresh_var_f(st_p1, false, Text::lit(""));
        return std::tuple{env_p0, crate::check::types::unify::unify_f(st2_pf, t_p3, crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("?"), prism_rtl::rc(v_pe)}), p_p2.span_p)};
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PCtor>(_m)) {
        auto&& n_pg = prism_rtl::as<crate::syntax::PatternKind::PCtor>(_m).a0;
        auto&& args_ph = prism_rtl::as<crate::syntax::PatternKind::PCtor>(_m).a1;
        return bind_ctor_f(env_p0, st_p1, p_p2, n_pg, args_ph, t_p3);
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PRecord>(_m)) {
        auto&& n_pi = prism_rtl::as<crate::syntax::PatternKind::PRecord>(_m).a0;
        auto&& fields_pj = prism_rtl::as<crate::syntax::PatternKind::PRecord>(_m).a1;
        auto&& rest_pk = prism_rtl::as<crate::syntax::PatternKind::PRecord>(_m).a2;
        return bind_record_f(env_p0, st_p1, p_p2, n_pi, fields_pj, rest_pk, t_p3);
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PSigil>(_m)) {
        auto&& s_pl = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a0;
        auto&& inner_pm = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a1;
        return (s_pl == Text::lit("?")) || (s_pl == Text::lit("~"))
            ? ({
            auto [v_po, st2_pp] = crate::check::types::fresh_var_f(st_p1, false, Text::lit(""));
            auto st3_pn = crate::check::types::unify::unify_f(st2_pp, t_p3, crate::check::types::Ty(crate::check::types::Ty::TySig{s_pl, prism_rtl::rc(v_po)}), p_p2.span_p);
            bind_pattern_f(env_p0, st3_pn, prism_rtl::deref(prism_rtl::deref(inner_pm)), v_po, refutable_p4);
        })
            : ({
            auto [v_pr, st2_ps] = crate::check::types::fresh_var_f(st_p1, false, Text::lit(""));
            auto st3_pq = crate::check::types::unify::unify_f(st2_ps, t_p3, crate::check::types::with_marks_f(s_pl, v_pr, env_p0.scope_p), p_p2.span_p);
            bind_pattern_f(env_p0, st3_pq, prism_rtl::deref(prism_rtl::deref(inner_pm)), v_pr, refutable_p4);
        });
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PTuple>(_m)) {
        auto&& ps_pt = prism_rtl::as<crate::syntax::PatternKind::PTuple>(_m).a0;
        auto [vs_p13, st2_p14] = crate::prelude::fold(ps_pt, std::tuple{Array<crate::check::types::Ty>{}, st_p1}, [&](const std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>& _p0, const crate::syntax::Pattern_& _p1) {
            auto&& acc_pv = std::get<0>(_p0);
            auto&& s_p10 = std::get<1>(_p0);
            return ({
                auto [v_p11, s2_p12] = crate::check::types::fresh_var_f(s_p10, false, Text::lit(""));
                std::tuple{crate::prelude::push(acc_pv, v_p11), s2_p12};
            });
        });
        auto st3_pu = crate::check::types::unify::unify_f(st2_p14, t_p3, crate::check::types::Ty(crate::check::types::Ty::TyTuple{vs_p13}), p_p2.span_p);
        return crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(crate::prelude::len(ps_pt)), std::tuple{env_p0, st3_pu}, ({
            auto ps_ptx = ps_pt;
            auto p_p2x = p_p2;
            auto vs_p13x = vs_p13;
            auto refutable_p4x = refutable_p4;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>>(std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=, ps_ptx = std::move(ps_ptx), p_p2x = std::move(p_p2x), vs_p13x = std::move(vs_p13x), refutable_p4x = std::move(refutable_p4x)](std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto ps_ptxy = ps_ptx;
                auto p_p2xy = p_p2x;
                auto vs_p13xy = vs_p13x;
                auto refutable_p4xy = refutable_p4x;
                (crate::prelude::entered(crate::prelude::once_job([=, ps_ptxy = std::move(ps_ptxy), p_p2xy = std::move(p_p2xy), vs_p13xy = std::move(vs_p13xy), refutable_p4xy = std::move(refutable_p4xy)]() {
                return ({
                    auto [en_p15, s_p16] = p0;
                    auto i_p17 = p1;
                    (prism_rtl::more(prism_rtl::rc(BindPattern(en_p15, s_p16, crate::prelude::or_(crate::prelude::index(ps_ptxy, i_p17), crate::syntax::Pattern_{.kind_p = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PIgnore{})), .span_p = prism_rtl::deref(p_p2xy).span_p}), crate::prelude::or_(crate::prelude::index(vs_p13xy, i_p17), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), refutable_p4xy))));
                });
            })));
            });
        }));
        })));
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PArray>(_m)) {
        auto&& ps_p18 = prism_rtl::as<crate::syntax::PatternKind::PArray>(_m).a0;
        auto [v_p1a, st2_p1b] = crate::check::types::fresh_var_f(st_p1, false, Text::lit(""));
        auto st3_p19 = crate::check::types::unify::unify_f(st2_p1b, t_p3, crate::check::types::Ty(crate::check::types::Ty::TyArray{prism_rtl::rc(v_p1a)}), p_p2.span_p);
        return crate::prelude::run_to_end(crate::prelude::fold_job(ps_p18, std::tuple{env_p0, st3_p19}, ({
            auto v_p1ax = v_p1a;
            auto refutable_p4x = refutable_p4;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>>(std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, crate::syntax::Pattern_>)>>(prism_rtl::rc([=, v_p1ax = std::move(v_p1ax), refutable_p4x = std::move(refutable_p4x)](std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, crate::syntax::Pattern_> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto v_p1axy = v_p1ax;
                auto refutable_p4xy = refutable_p4x;
                (crate::prelude::entered(crate::prelude::once_job([=, v_p1axy = std::move(v_p1axy), refutable_p4xy = std::move(refutable_p4xy)]() {
                return ({
                    auto [en_p1c, s_p1d] = p0;
                    auto q_p1e = p1;
                    (prism_rtl::more(prism_rtl::rc(BindPattern(en_p1c, s_p1d, q_p1e, v_p1axy, refutable_p4xy))));
                });
            })));
            });
        }));
        })));
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PGroup>(_m)) {
        auto&& q_p1f = prism_rtl::as<crate::syntax::PatternKind::PGroup>(_m).a0;
        return bind_pattern_f(env_p0, st_p1, prism_rtl::deref(prism_rtl::deref(q_p1f)), t_p3, refutable_p4);
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PFamily>(_m)) {
        auto&& q_p1g = prism_rtl::as<crate::syntax::PatternKind::PFamily>(_m).a0;
        return bind_family_f(env_p0, st_p1, crate::check::env::dotted_f(prism_rtl::deref(q_p1g).path_p), t_p3, p_p2.span_p);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St>> BindPattern::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& p_p2 = this->p_p2;
    const auto& t_p3 = this->t_p3;
    const auto& refutable_p4 = this->refutable_p4;
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(p_p2).kind_p);
        prism_rtl::is<crate::syntax::PatternKind::PName>(_m) ? ({
        auto&& n_p5 = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        ({
        auto bare_p6 = crate::prelude::or_(crate::prelude::index(prism_rtl::deref(n_p5).path_p, Nat(0u)), Text::lit(""));
        auto is_ctor_p7 = (crate::check::env::is_upper_text_f(bare_p6) && (crate::prelude::len_text(prism_rtl::deref(n_p5).sigils_p) == Nat(0u))) && is_ctor_name_f(env_p0, n_p5);
        (std::move(is_ctor_p7) || (crate::prelude::len(prism_rtl::deref(n_p5).path_p) > Nat(1u))
        ? prism_rtl::more(prism_rtl::rc(BindCtor(env_p0, st_p1, p_p2, n_p5, Array<crate::syntax::Pattern_>{}, t_p3)))
        : prism_rtl::more(prism_rtl::rc(BindName(env_p0, st_p1, n_p5, t_p3))));
    });
    })
        : prism_rtl::is<crate::syntax::PatternKind::PIgnore>(_m) ? prism_rtl::finished(std::tuple{env_p0, st_p1})
        : prism_rtl::is<crate::syntax::PatternKind::PLit>(_m) ? ({
        auto&& l_p8 = prism_rtl::as<crate::syntax::PatternKind::PLit>(_m).a0;
        ({
        auto env_p0x = env_p0;
        auto l_p8x = l_p8;
        auto p_p2x = p_p2;
        auto st_p1x = st_p1;
        auto t_p3x = t_p3;
        (crate::prelude::call_then(crate::check::expr::start_infer_lit_f(env_p0x, st_p1x, l_p8x, false, prism_rtl::deref(p_p2x).span_p), [=, t_p3x = std::move(t_p3x)](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_lit_f_1841) {
        return ({
            auto [lt_p9, st2_pa] = infer_lit_f_1841;
            (crate::prelude::call_then(crate::check::types::unify::start_unify_f(st2_pa, t_p3x, lt_p9, prism_rtl::deref(p_p2x).span_p), [=](crate::check::types::St unify_f_1892) { return prism_rtl::finished(std::tuple{env_p0x, unify_f_1892}); }));
        });
    }));
    });
    })
        : prism_rtl::is<crate::syntax::PatternKind::PNeg>(_m) ? ({
        auto&& l_pb = prism_rtl::as<crate::syntax::PatternKind::PNeg>(_m).a0;
        ({
        auto env_p0x = env_p0;
        auto l_pbx = l_pb;
        auto p_p2x = p_p2;
        auto st_p1x = st_p1;
        auto t_p3x = t_p3;
        (crate::prelude::call_then(crate::check::expr::start_infer_lit_f(env_p0x, st_p1x, l_pbx, true, prism_rtl::deref(p_p2x).span_p), [=, t_p3x = std::move(t_p3x)](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_lit_f_1958) {
        return ({
            auto [lt_pc, st2_pd] = infer_lit_f_1958;
            (crate::prelude::call_then(crate::check::types::unify::start_unify_f(st2_pd, t_p3x, lt_pc, prism_rtl::deref(p_p2x).span_p), [=](crate::check::types::St unify_f_2008) { return prism_rtl::finished(std::tuple{env_p0x, unify_f_2008}); }));
        });
    }));
    });
    })
        : prism_rtl::is<crate::syntax::PatternKind::PUnit>(_m) ? ({
        auto env_p0x = env_p0;
        auto p_p2x = p_p2;
        auto st_p1x = st_p1;
        auto t_p3x = t_p3;
        (crate::prelude::call_then(crate::check::types::unify::start_unify_f(st_p1x, t_p3x, crate::check::types::t_unit_p(), prism_rtl::deref(p_p2x).span_p), [=, env_p0x = std::move(env_p0x)](crate::check::types::St unify_f_2055) { return prism_rtl::finished(std::tuple{env_p0x, unify_f_2055}); }));
    })
        : prism_rtl::is<crate::syntax::PatternKind::PNil>(_m) ? ({
        auto [v_pe, st2_pf] = crate::check::types::fresh_var_f(st_p1, false, Text::lit(""));
        auto env_p0x = env_p0;
        auto p_p2x = p_p2;
        auto t_p3x = t_p3;
        (crate::prelude::call_then(crate::check::types::unify::start_unify_f(st2_pf, t_p3x, crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("?"), prism_rtl::rc(v_pe)}), prism_rtl::deref(p_p2x).span_p), [=, env_p0x = std::move(env_p0x)](crate::check::types::St unify_f_2159) { return prism_rtl::finished(std::tuple{env_p0x, unify_f_2159}); }));
    })
        : prism_rtl::is<crate::syntax::PatternKind::PCtor>(_m) ? ({
        auto&& n_pg = prism_rtl::as<crate::syntax::PatternKind::PCtor>(_m).a0;
        auto&& args_ph = prism_rtl::as<crate::syntax::PatternKind::PCtor>(_m).a1;
        prism_rtl::more(prism_rtl::rc(BindCtor(env_p0, st_p1, p_p2, n_pg, args_ph, t_p3)));
    })
        : prism_rtl::is<crate::syntax::PatternKind::PRecord>(_m) ? ({
        auto&& n_pi = prism_rtl::as<crate::syntax::PatternKind::PRecord>(_m).a0;
        auto&& fields_pj = prism_rtl::as<crate::syntax::PatternKind::PRecord>(_m).a1;
        auto&& rest_pk = prism_rtl::as<crate::syntax::PatternKind::PRecord>(_m).a2;
        prism_rtl::more(prism_rtl::rc(BindRecord(env_p0, st_p1, p_p2, n_pi, fields_pj, prism_rtl::deref(rest_pk), t_p3)));
    })
        : prism_rtl::is<crate::syntax::PatternKind::PSigil>(_m) ? ({
        auto&& s_pl = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a0;
        auto&& inner_pm = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a1;
        (s_pl == Text::lit("?")) || (s_pl == Text::lit("~"))
        ? ({
        auto [v_po, st2_pp] = crate::check::types::fresh_var_f(st_p1, false, Text::lit(""));
        auto env_p0x = env_p0;
        auto inner_pmx = prism_rtl::deref(prism_rtl::deref(inner_pm));
        auto p_p2x = p_p2;
        auto refutable_p4x = prism_rtl::deref(refutable_p4);
        auto s_plx = s_pl;
        auto t_p3x = t_p3;
        (crate::prelude::call_then(crate::check::types::unify::start_unify_f(st2_pp, t_p3x, crate::check::types::Ty(crate::check::types::Ty::TySig{s_plx, prism_rtl::rc(v_po)}), prism_rtl::deref(p_p2x).span_p), [=, env_p0x = std::move(env_p0x), inner_pmx = std::move(inner_pmx), refutable_p4x = std::move(refutable_p4x)](crate::check::types::St unify_f_2449) {
        return ({
            auto st3_pn = unify_f_2449;
            (prism_rtl::more(prism_rtl::rc(BindPattern(env_p0x, st3_pn, inner_pmx, v_po, refutable_p4x))));
        });
    }));
    })
        : ({
        auto [v_pr, st2_ps] = crate::check::types::fresh_var_f(st_p1, false, Text::lit(""));
        auto env_p0x = env_p0;
        auto inner_pmx = prism_rtl::deref(prism_rtl::deref(inner_pm));
        auto p_p2x = p_p2;
        auto refutable_p4x = prism_rtl::deref(refutable_p4);
        auto s_plx = s_pl;
        auto t_p3x = t_p3;
        (crate::prelude::call_then(crate::check::types::unify::start_unify_f(st2_ps, t_p3x, crate::check::types::with_marks_f(s_plx, v_pr, prism_rtl::deref(env_p0x).scope_p), prism_rtl::deref(p_p2x).span_p), [=, inner_pmx = std::move(inner_pmx), refutable_p4x = std::move(refutable_p4x)](crate::check::types::St unify_f_2626) {
        return ({
            auto st3_pq = unify_f_2626;
            (prism_rtl::more(prism_rtl::rc(BindPattern(env_p0x, st3_pq, inner_pmx, v_pr, refutable_p4x))));
        });
    }));
    });
    })
        : prism_rtl::is<crate::syntax::PatternKind::PTuple>(_m) ? ({
        auto&& ps_pt = prism_rtl::as<crate::syntax::PatternKind::PTuple>(_m).a0;
        ({
        auto [vs_p13, st2_p14] = crate::prelude::fold(ps_pt, std::tuple{Array<crate::check::types::Ty>{}, st_p1}, [&](const std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>& _p0, const crate::syntax::Pattern_& _p1) {
            auto&& acc_pv = std::get<0>(_p0);
            auto&& s_p10 = std::get<1>(_p0);
            return ({
                auto [v_p11, s2_p12] = crate::check::types::fresh_var_f(s_p10, false, Text::lit(""));
                std::tuple{crate::prelude::push(acc_pv, v_p11), s2_p12};
            });
        });
        auto env_p0x = env_p0;
        auto p_p2x = p_p2;
        auto ps_ptx = ps_pt;
        auto refutable_p4x = prism_rtl::deref(refutable_p4);
        auto t_p3x = t_p3;
        (crate::prelude::call_then(crate::check::types::unify::start_unify_f(st2_p14, t_p3x, crate::check::types::Ty(crate::check::types::Ty::TyTuple{vs_p13}), prism_rtl::deref(p_p2x).span_p), [=, env_p0x = std::move(env_p0x), ps_ptx = std::move(ps_ptx), refutable_p4x = std::move(refutable_p4x)](crate::check::types::St unify_f_2918) {
        return ({
            auto st3_pu = unify_f_2918;
            (crate::prelude::fold_job(crate::check::errors::range0_f(crate::prelude::len(ps_ptx)), std::tuple{env_p0x, st3_pu}, ({
            auto ps_ptxx = ps_ptx;
            auto p_p2xx = p_p2x;
            auto vs_p13x = vs_p13;
            auto refutable_p4xx = refutable_p4x;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>>(std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=, ps_ptxx = std::move(ps_ptxx), p_p2xx = std::move(p_p2xx), vs_p13x = std::move(vs_p13x), refutable_p4xx = std::move(refutable_p4xx)](std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto ps_ptxxy = ps_ptxx;
                auto p_p2xxy = p_p2xx;
                auto vs_p13xy = vs_p13x;
                auto refutable_p4xxy = refutable_p4xx;
                (crate::prelude::entered(crate::prelude::once_job([=, ps_ptxxy = std::move(ps_ptxxy), p_p2xxy = std::move(p_p2xxy), vs_p13xy = std::move(vs_p13xy), refutable_p4xxy = std::move(refutable_p4xxy)]() {
                return ({
                    auto [en_p15, s_p16] = p0;
                    auto i_p17 = p1;
                    (prism_rtl::more(prism_rtl::rc(BindPattern(en_p15, s_p16, crate::prelude::or_(crate::prelude::index(ps_ptxxy, i_p17), crate::syntax::Pattern_{.kind_p = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PIgnore{})), .span_p = prism_rtl::deref(p_p2xxy).span_p}), crate::prelude::or_(crate::prelude::index(vs_p13xy, i_p17), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), refutable_p4xxy))));
                });
            })));
            });
        }));
        }))->cycle());
        });
    }));
    });
    })
        : prism_rtl::is<crate::syntax::PatternKind::PArray>(_m) ? ({
        auto&& ps_p18 = prism_rtl::as<crate::syntax::PatternKind::PArray>(_m).a0;
        ({
        auto [v_p1a, st2_p1b] = crate::check::types::fresh_var_f(st_p1, false, Text::lit(""));
        auto env_p0x = env_p0;
        auto p_p2x = p_p2;
        auto ps_p18x = ps_p18;
        auto refutable_p4x = prism_rtl::deref(refutable_p4);
        auto t_p3x = t_p3;
        (crate::prelude::call_then(crate::check::types::unify::start_unify_f(st2_p1b, t_p3x, crate::check::types::Ty(crate::check::types::Ty::TyArray{prism_rtl::rc(v_p1a)}), prism_rtl::deref(p_p2x).span_p), [=, env_p0x = std::move(env_p0x), ps_p18x = std::move(ps_p18x), refutable_p4x = std::move(refutable_p4x)](crate::check::types::St unify_f_3192) {
        return ({
            auto st3_p19 = unify_f_3192;
            (crate::prelude::fold_job(ps_p18x, std::tuple{env_p0x, st3_p19}, ({
            auto v_p1ax = v_p1a;
            auto refutable_p4xx = refutable_p4x;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>>(std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, crate::syntax::Pattern_>)>>(prism_rtl::rc([=, v_p1ax = std::move(v_p1ax), refutable_p4xx = std::move(refutable_p4xx)](std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, crate::syntax::Pattern_> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto v_p1axy = v_p1ax;
                auto refutable_p4xxy = refutable_p4xx;
                (crate::prelude::entered(crate::prelude::once_job([=, v_p1axy = std::move(v_p1axy), refutable_p4xxy = std::move(refutable_p4xxy)]() {
                return ({
                    auto [en_p1c, s_p1d] = p0;
                    auto q_p1e = p1;
                    (prism_rtl::more(prism_rtl::rc(BindPattern(en_p1c, s_p1d, q_p1e, v_p1axy, refutable_p4xxy))));
                });
            })));
            });
        }));
        }))->cycle());
        });
    }));
    });
    })
        : prism_rtl::is<crate::syntax::PatternKind::PGroup>(_m) ? ({
        auto&& q_p1f = prism_rtl::as<crate::syntax::PatternKind::PGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(BindPattern(env_p0, st_p1, prism_rtl::deref(prism_rtl::deref(q_p1f)), t_p3, prism_rtl::deref(refutable_p4))));
    })
        : prism_rtl::is<crate::syntax::PatternKind::PFamily>(_m) ? ({
        auto&& q_p1g = prism_rtl::as<crate::syntax::PatternKind::PFamily>(_m).a0;
        prism_rtl::more(prism_rtl::rc(BindFamily(env_p0, st_p1, crate::check::env::dotted_f(prism_rtl::deref(q_p1g).path_p), t_p3, prism_rtl::deref(p_p2).span_p)));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start BindPattern, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>> start_bind_pattern_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Pattern_ p_p2, crate::check::types::Ty t_p3, bool refutable_p4) {
    return prism_rtl::make_rc<BindPattern>(env_p0, st_p1, p_p2, t_p3, refutable_p4);
}


/// IsCtorName: fn Env, SName -> Bool
bool is_ctor_name_f(const crate::check::expr::Env& env_p0, const crate::syntax::SName& n_p1) {
    auto&& _qk_o2 = crate::check::env::names::resolve_value_f(env_p0.g_p, env_p0.home_p, n_p1);
    auto&& qk_o2 = std::get<0>(_qk_o2);
    if (prism_rtl::is_some(qk_o2)) {
        auto&& qk_p3 = prism_rtl::some_of(qk_o2);
        return crate::check::env::has_key_f(prism_rtl::deref(env_p0.g_p).ctors_p, qk_p3);
    }
    if (prism_rtl::is_none(qk_o2)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// BindName: unbounded fn Env, St, SName, Ty -> ((Env, St))
std::tuple<crate::check::expr::Env, crate::check::types::St> bind_name_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::SName& n_p2, const crate::check::types::Ty& t_p3) {
    auto name_p4 = crate::check::env::sname_key_f(n_p2);
    return crate::check::types::has_text_f(env_p0.pending_p, name_p4)
        ? ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::check::expr::Env, crate::check::types::St>> _v;
        auto&& _m = crate::prelude::get(env_p0.locals_p, name_p4);
        if (prism_rtl::is_some(_m)) {
            auto&& sc_p5 = prism_rtl::some_of(_m);
            _v.set(({
                auto [ok_p8, st1_p9] = crate::check::types::unify::try_unify_f(st_p1, prism_rtl::deref(sc_p5).ty_p, t_p3, n_p2.span_p);
                auto marks_agree_p6 = (crate::check::types::stack_of_f(st_p1, t_p3) == crate::check::expr::lets::type_marks_f(n_p2.sigils_p)) || crate::check::types::is_flex_var_f(st_p1, t_p3);
                auto st_a_p7 = ok_p8
                    ? st1_p9
                    : std::move(marks_agree_p6)
                    ? crate::check::types::unify::unify_f(st_p1, prism_rtl::deref(sc_p5).ty_p, t_p3, n_p2.span_p)
                    : crate::check::types::recording::err_fix_f(st_p1, Text::lit("mark-stack"), n_p2.span_p, prism_rtl::cat("`", name_p4, "` has type `", crate::check::types::show_ty_f(st_p1, t_p3), "`, whose stack is `", crate::check::types::stack_of_f(st_p1, t_p3), "`; the name shows `", crate::check::expr::lets::type_marks_f(n_p2.sigils_p), "`"), prism_rtl::cat("rename to `", crate::check::expr::lets::ref_mark_f(n_p2.sigils_p), crate::check::types::stack_of_f(st_p1, t_p3), crate::syntax::lexer::chars::drop_prefix_f(name_p4, n_p2.sigils_p), "`"));
                (crate::check::expr::bind_local_id_f(env_p0, crate::check::types::recording::note_binder_f(st_a_p7, n_p2.span_p, name_p4, t_p3), name_p4, n_p2.span_p));
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(bind_fresh_f(env_p0, st_p1, n_p2, t_p3));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    })
        : bind_fresh_f(env_p0, st_p1, n_p2, t_p3);
}


prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St>> BindName::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& n_p2 = this->n_p2;
    const auto& t_p3 = this->t_p3;
    auto name_p4 = crate::check::env::sname_key_f(n_p2);
    return crate::check::types::has_text_f(prism_rtl::deref(env_p0).pending_p, name_p4)
        ? ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(env_p0).locals_p, name_p4);
        prism_rtl::is_some(_m) ? ({
        auto&& sc_p5 = prism_rtl::some_of(_m);
        ({
        auto env_p0x = env_p0;
        auto n_p2x = n_p2;
        auto st_p1x = st_p1;
        auto t_p3x = t_p3;
        (crate::prelude::call_then(crate::check::types::unify::start_try_unify_f(st_p1x, prism_rtl::deref(sc_p5).ty_p, t_p3x, prism_rtl::deref(n_p2x).span_p), [=, env_p0x = std::move(env_p0x)](std::tuple<bool, crate::check::types::St> try_unify_f_3987) {
        return ({
            auto [ok_p8, st1_p9] = try_unify_f_3987;
            (crate::prelude::call_then(crate::check::types::start_stack_of_f(st_p1x, t_p3x), [=](Text stack_of_f_4051) {
            return ({
                auto marks_agree_p6 = (stack_of_f_4051 == crate::check::expr::lets::type_marks_f(prism_rtl::deref(n_p2x).sigils_p)) || crate::check::types::is_flex_var_f(st_p1x, t_p3x);
                auto st_a_p7 = ok_p8
                    ? st1_p9
                    : std::move(marks_agree_p6)
                    ? crate::check::types::unify::unify_f(st_p1x, prism_rtl::deref(sc_p5).ty_p, t_p3x, prism_rtl::deref(n_p2x).span_p)
                    : crate::check::types::recording::err_fix_f(st_p1x, Text::lit("mark-stack"), prism_rtl::deref(n_p2x).span_p, prism_rtl::cat("`", name_p4, "` has type `", crate::check::types::show_ty_f(st_p1x, t_p3x), "`, whose stack is `", crate::check::types::stack_of_f(st_p1x, t_p3x), "`; the name shows `", crate::check::expr::lets::type_marks_f(prism_rtl::deref(n_p2x).sigils_p), "`"), prism_rtl::cat("rename to `", crate::check::expr::lets::ref_mark_f(prism_rtl::deref(n_p2x).sigils_p), crate::check::types::stack_of_f(st_p1x, t_p3x), crate::syntax::lexer::chars::drop_prefix_f(name_p4, prism_rtl::deref(n_p2x).sigils_p), "`"));
                (prism_rtl::finished(crate::check::expr::bind_local_id_f(env_p0x, crate::check::types::recording::note_binder_f(st_a_p7, prism_rtl::deref(n_p2x).span_p, name_p4, t_p3x), name_p4, prism_rtl::deref(n_p2x).span_p)));
            });
        }));
        });
    }));
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::more(prism_rtl::rc(BindFresh(env_p0, st_p1, n_p2, t_p3)))
        : throw prism_rtl::Panic("no arm matched");
    })
        : prism_rtl::more(prism_rtl::rc(BindFresh(env_p0, st_p1, n_p2, t_p3)));
}


/// `Start BindName, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>> start_bind_name_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::SName n_p2, crate::check::types::Ty t_p3) {
    return prism_rtl::make_rc<BindName>(env_p0, st_p1, n_p2, t_p3);
}


/// BindFresh: unbounded fn Env, St, SName, Ty -> ((Env, St))
std::tuple<crate::check::expr::Env, crate::check::types::St> bind_fresh_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::SName& n_p2, const crate::check::types::Ty& t_p3) {
    return bind_fresh_marked_f(env_p0, st_p1, n_p2, crate::check::expr::lets::type_marks_f(n_p2.sigils_p), t_p3);
}


prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St>> BindFresh::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& n_p2 = this->n_p2;
    const auto& t_p3 = this->t_p3;
    return prism_rtl::more(prism_rtl::rc(BindFreshMarked(env_p0, st_p1, n_p2, crate::check::expr::lets::type_marks_f(prism_rtl::deref(n_p2).sigils_p), t_p3)));
}


/// `Start BindFresh, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>> start_bind_fresh_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::SName n_p2, crate::check::types::Ty t_p3) {
    return prism_rtl::make_rc<BindFresh>(env_p0, st_p1, n_p2, t_p3);
}


/// BindFreshMarked: unbounded fn Env, St, SName, Text, Ty -> ((Env, St))
std::tuple<crate::check::expr::Env, crate::check::types::St> bind_fresh_marked_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::SName& n_p2, const Text& marks_p3, const crate::check::types::Ty& t_p4) {
    auto name_p5 = crate::check::env::sname_key_f(n_p2);
    auto [v_p8, st2_p9] = crate::check::types::fresh_var_f(st_p1, true, name_p5);
    auto [rw_pa, st3_pb] = crate::check::types::recording::fresh_row_f(st2_p9, Array<Text>{});
    auto marked_p6 = crate::check::types::with_marks_f(marks_p3, v_p8, rw_pa);
    auto [ok_pc, st4_pd] = crate::check::types::unify::try_unify_f(st3_pb, t_p4, marked_p6, n_p2.span_p);
    auto st5_p7 = ok_pc
        ? st4_pd
        : ({
        auto stack_pe = crate::check::types::stack_of_f(st3_pb, t_p4);
        (crate::check::types::recording::err_fix_f(st3_pb, Text::lit("mark-stack"), n_p2.span_p, prism_rtl::cat("`", name_p5, "` has type `", crate::check::types::show_ty_f(st3_pb, t_p4), "`, whose stack is `", stack_pe, "`; the name shows `", marks_p3, "`"), prism_rtl::cat("rename to `", crate::check::expr::lets::ref_mark_f(n_p2.sigils_p), stack_pe, crate::syntax::lexer::chars::drop_prefix_f(name_p5, n_p2.sigils_p), "`")));
    });
    return crate::check::expr::bind_local_id_f(crate::check::expr::with_local_f(env_p0, name_p5, crate::check::types::schemes::mono_f(t_p4)), crate::check::types::recording::note_binder_f(st5_p7, n_p2.span_p, name_p5, t_p4), name_p5, n_p2.span_p);
}


prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St>> BindFreshMarked::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& n_p2 = this->n_p2;
    const auto& marks_p3 = this->marks_p3;
    const auto& t_p4 = this->t_p4;
    auto name_p5 = crate::check::env::sname_key_f(n_p2);
    auto [v_p8, st2_p9] = crate::check::types::fresh_var_f(st_p1, true, name_p5);
    auto [rw_pa, st3_pb] = crate::check::types::recording::fresh_row_f(st2_p9, Array<Text>{});
    auto marked_p6 = crate::check::types::with_marks_f(marks_p3, v_p8, rw_pa);
    auto env_p0x = env_p0;
    auto marks_p3x = marks_p3;
    auto n_p2x = n_p2;
    auto t_p4x = t_p4;
    return crate::prelude::call_then(crate::check::types::unify::start_try_unify_f(st3_pb, t_p4x, marked_p6, prism_rtl::deref(n_p2x).span_p), [=](std::tuple<bool, crate::check::types::St> try_unify_f_5140) {
        return ({
            auto [ok_pc, st4_pd] = try_unify_f_5140;
            auto st5_p7 = ok_pc
                ? st4_pd
                : ({
                auto stack_pe = crate::check::types::stack_of_f(st3_pb, t_p4x);
                (crate::check::types::recording::err_fix_f(st3_pb, Text::lit("mark-stack"), prism_rtl::deref(n_p2x).span_p, prism_rtl::cat("`", name_p5, "` has type `", crate::check::types::show_ty_f(st3_pb, t_p4x), "`, whose stack is `", stack_pe, "`; the name shows `", marks_p3x, "`"), prism_rtl::cat("rename to `", crate::check::expr::lets::ref_mark_f(prism_rtl::deref(n_p2x).sigils_p), stack_pe, crate::syntax::lexer::chars::drop_prefix_f(name_p5, prism_rtl::deref(n_p2x).sigils_p), "`")));
            });
            (prism_rtl::finished(crate::check::expr::bind_local_id_f(crate::check::expr::with_local_f(env_p0x, name_p5, crate::check::types::schemes::mono_f(t_p4x)), crate::check::types::recording::note_binder_f(st5_p7, prism_rtl::deref(n_p2x).span_p, name_p5, t_p4x), name_p5, prism_rtl::deref(n_p2x).span_p)));
        });
    });
}


/// `Start BindFreshMarked, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>> start_bind_fresh_marked_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::SName n_p2, Text marks_p3, crate::check::types::Ty t_p4) {
    return prism_rtl::make_rc<BindFreshMarked>(env_p0, st_p1, n_p2, marks_p3, t_p4);
}


/// BindField: unbounded fn Env, St, Pattern, Ty, Bool -> ((Env, St))
std::tuple<crate::check::expr::Env, crate::check::types::St> bind_field_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Pattern_& p_p2, const crate::check::types::Ty& ft_p3, const bool& snapshot_p4) {
    auto&& _m = crate::check::types::recording::walk_f(st_p1, ft_p3);
    if (prism_rtl::is<crate::check::types::Ty::TySig>(_m)) {
        auto&& s_p5 = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a0;
        auto&& level_p6 = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a1;
        if (snapshot_p4 && (s_p5 == Text::lit("$"))) {
            return bind_level_f(env_p0, st_p1, p_p2, prism_rtl::deref(level_p6));
        }
    }
    {
        return bind_pattern_f(env_p0, st_p1, p_p2, ft_p3, true);
    }
}


prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St>> BindField::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& p_p2 = this->p_p2;
    const auto& ft_p3 = this->ft_p3;
    const auto& snapshot_p4 = this->snapshot_p4;
    auto env_p0x = env_p0;
    auto ft_p3x = ft_p3;
    auto p_p2x = p_p2;
    auto snapshot_p4x = prism_rtl::deref(snapshot_p4);
    auto st_p1x = st_p1;
    return crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p1x, ft_p3x), [=](crate::check::types::Ty walk_f_6089) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TySig>(walk_f_6089) && ({
            auto&& s_p5 = prism_rtl::as<crate::check::types::Ty::TySig>(walk_f_6089).a0;
            auto&& level_p6 = prism_rtl::as<crate::check::types::Ty::TySig>(walk_f_6089).a1;
            (snapshot_p4x && (s_p5 == Text::lit("$")));
        }) ? ({
            auto&& s_p5 = prism_rtl::as<crate::check::types::Ty::TySig>(walk_f_6089).a0;
            auto&& level_p6 = prism_rtl::as<crate::check::types::Ty::TySig>(walk_f_6089).a1;
            prism_rtl::more(prism_rtl::rc(BindLevel(env_p0x, st_p1x, p_p2x, prism_rtl::deref(level_p6))));
        })
            : prism_rtl::more(prism_rtl::rc(BindPattern(env_p0x, st_p1x, p_p2x, ft_p3x, true)));
        });
    });
}


/// `Start BindField, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>> start_bind_field_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Pattern_ p_p2, crate::check::types::Ty ft_p3, bool snapshot_p4) {
    return prism_rtl::make_rc<BindField>(env_p0, st_p1, p_p2, ft_p3, snapshot_p4);
}


/// BindLevel: unbounded fn Env, St, Pattern, Ty -> ((Env, St))
std::tuple<crate::check::expr::Env, crate::check::types::St> bind_level_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Pattern_& p_p2, const crate::check::types::Ty& level_p3) {
    auto&& _m = prism_rtl::deref(p_p2.kind_p);
    if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
        auto&& n_p4 = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        return crate::syntax::lexer::chars::has_prefix_f(prism_rtl::deref(n_p4).sigils_p, Text::lit("$")) && (crate::prelude::len(prism_rtl::deref(n_p4).path_p) == Nat(1u))
            ? bind_fresh_marked_f(env_p0, st_p1, n_p4, crate::syntax::lexer::chars::after_first_f(prism_rtl::deref(n_p4).sigils_p), level_p3)
            : bind_pattern_f(env_p0, st_p1, p_p2, level_p3, true);
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PGroup>(_m)) {
        auto&& q_p5 = prism_rtl::as<crate::syntax::PatternKind::PGroup>(_m).a0;
        return bind_level_f(env_p0, st_p1, prism_rtl::deref(prism_rtl::deref(q_p5)), level_p3);
    }
    {
        return bind_pattern_f(env_p0, st_p1, p_p2, level_p3, true);
    }
}


prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St>> BindLevel::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& p_p2 = this->p_p2;
    const auto& level_p3 = this->level_p3;
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(p_p2).kind_p);
        prism_rtl::is<crate::syntax::PatternKind::PName>(_m) ? ({
        auto&& n_p4 = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        crate::syntax::lexer::chars::has_prefix_f(prism_rtl::deref(n_p4).sigils_p, Text::lit("$")) && (crate::prelude::len(prism_rtl::deref(n_p4).path_p) == Nat(1u))
        ? prism_rtl::more(prism_rtl::rc(BindFreshMarked(env_p0, st_p1, n_p4, crate::syntax::lexer::chars::after_first_f(prism_rtl::deref(n_p4).sigils_p), level_p3)))
        : prism_rtl::more(prism_rtl::rc(BindPattern(env_p0, st_p1, p_p2, level_p3, true)));
    })
        : prism_rtl::is<crate::syntax::PatternKind::PGroup>(_m) ? ({
        auto&& q_p5 = prism_rtl::as<crate::syntax::PatternKind::PGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(BindLevel(env_p0, st_p1, prism_rtl::deref(prism_rtl::deref(q_p5)), level_p3)));
    })
        : prism_rtl::more(prism_rtl::rc(BindPattern(env_p0, st_p1, p_p2, level_p3, true)));
    });
}


/// `Start BindLevel, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>> start_bind_level_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Pattern_ p_p2, crate::check::types::Ty level_p3) {
    return prism_rtl::make_rc<BindLevel>(env_p0, st_p1, p_p2, level_p3);
}


/// BindCtor: unbounded fn Env, St, Pattern, SName, [Pattern], Ty -> ((Env, St))
std::tuple<crate::check::expr::Env, crate::check::types::St> bind_ctor_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Pattern_& p_p2, const crate::syntax::SName& n_p3, const Array<crate::syntax::Pattern_>& args_p4, const crate::check::types::Ty& t_p5) {
    auto [qk_o6, why_p7] = crate::check::env::names::resolve_value_f(env_p0.g_p, env_p0.home_p, n_p3);
    if (prism_rtl::is_none(qk_o6)) {
        return std::tuple{env_p0, crate::check::types::recording::err_f(st_p1, Text::lit("unknown-name"), n_p3.span_p, prism_rtl::cat("no constructor `", crate::check::env::sname_key_f(n_p3), "`"))};
    }
    if (prism_rtl::is_some(qk_o6)) {
        auto&& qk_p8 = prism_rtl::some_of(qk_o6);
        return why_p7 == Text::lit("tag")
            ? bind_tag_pattern_f(env_p0, st_p1, p_p2, qk_p8, Array<crate::syntax::FieldPat>{}, true, t_p5)
            : ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<crate::check::expr::Env, crate::check::types::St>> _v;
            auto&& _m = crate::prelude::get(prism_rtl::deref(env_p0.g_p).ctors_p, qk_p8);
            if (prism_rtl::is_none(_m)) {
                _v.set(std::tuple{env_p0, crate::check::types::recording::err_f(st_p1, Text::lit("unknown-name"), n_p3.span_p, prism_rtl::cat("`", crate::check::env::sname_key_f(n_p3), "` is not a constructor"))});
                goto _done;
            }
            if (prism_rtl::is_some(_m)) {
                auto&& c_p9 = prism_rtl::some_of(_m);
                _v.set(({
                    auto [self_pb, st1_pc, inst_pd] = crate::check::types::schemes::instantiate_with_f(st_p1, crate::check::types::Scheme{.qs_p = prism_rtl::deref(c_p9).params_p, .plain_qs_p = Array<Text>{}, .rqs_p = Array<Text>{}, .cqs_p = Array<Text>{}, .cjoins_p = Array<std::tuple<Text, Text>>{}, .bounds_p = Array<std::tuple<Text, Text>>{}, .ty_p = prism_rtl::deref(c_p9).ty_p}, p_p2.span_p, Array<crate::check::types::Ty>{});
                    auto st2_pa = crate::check::types::unify::unify_f(st1_pc, t_p5, self_pb, p_p2.span_p);
                    (crate::prelude::len(args_p4) != crate::prelude::len(prism_rtl::deref(c_p9).args_p)) && (!((crate::prelude::len(args_p4) == Nat(1u)) && (crate::prelude::len(prism_rtl::deref(c_p9).args_p) > Nat(1u))))
                    ? std::tuple{env_p0, crate::check::types::recording::err_f(st2_pa, Text::lit("mismatch"), p_p2.span_p, prism_rtl::cat("`", crate::check::types::bare_name_f(prism_rtl::deref(c_p9).name_p), "` takes ", crate::check::errors::count_word_f(crate::prelude::len(prism_rtl::deref(c_p9).args_p)), " argument", crate::prelude::len(prism_rtl::deref(c_p9).args_p) == Nat(1u)
                    ? Text::lit("")
                    : Text::lit("s"), "; this pattern gives ", crate::check::errors::count_word_f(crate::prelude::len(args_p4))))}
                    : crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(crate::prelude::len(args_p4)), std::tuple{env_p0, st2_pa}, ({
                    auto args_p4x = args_p4;
                    auto p_p2x = p_p2;
                    auto inst_pdx = inst_pd;
                    auto c_p9x = c_p9;
                    static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>>(std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=, args_p4x = std::move(args_p4x), p_p2x = std::move(p_p2x), inst_pdx = std::move(inst_pdx), c_p9x = std::move(c_p9x)](std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto args_p4xy = args_p4x;
                        auto p_p2xy = p_p2x;
                        auto inst_pdxy = inst_pdx;
                        auto c_p9xy = c_p9x;
                        (crate::prelude::entered(crate::prelude::once_job([=, args_p4xy = std::move(args_p4xy), p_p2xy = std::move(p_p2xy), inst_pdxy = std::move(inst_pdxy), c_p9xy = std::move(c_p9xy)]() {
                        return ({
                            auto [en_pe, s_pf] = p0;
                            auto i_pg = p1;
                            (crate::prelude::call_then(crate::check::types::schemes::start_subst_q_f(inst_pdxy, crate::prelude::or_(crate::prelude::index(prism_rtl::deref(c_p9xy).args_p, i_pg), crate::check::types::Ty(crate::check::types::Ty::TyErr{}))), [=](crate::check::types::Ty subst_q_f_7811) { return prism_rtl::more(prism_rtl::rc(BindPattern(en_pe, s_pf, crate::prelude::or_(crate::prelude::index(args_p4xy, i_pg), crate::syntax::Pattern_{.kind_p = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PIgnore{})), .span_p = prism_rtl::deref(p_p2xy).span_p}), subst_q_f_7811, true))); }));
                        });
                    })));
                    });
                }));
                })));
                }));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St>> BindCtor::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& p_p2 = this->p_p2;
    const auto& n_p3 = this->n_p3;
    const auto& args_p4 = this->args_p4;
    const auto& t_p5 = this->t_p5;
    auto [qk_o6, why_p7] = crate::check::env::names::resolve_value_f(prism_rtl::deref(env_p0).g_p, prism_rtl::deref(env_p0).home_p, n_p3);
    return ({
        prism_rtl::is_none(qk_o6) ? prism_rtl::finished(std::tuple{env_p0, crate::check::types::recording::err_f(st_p1, Text::lit("unknown-name"), prism_rtl::deref(n_p3).span_p, prism_rtl::cat("no constructor `", crate::check::env::sname_key_f(n_p3), "`"))})
        : prism_rtl::is_some(qk_o6) ? ({
        auto&& qk_p8 = prism_rtl::some_of(qk_o6);
        why_p7 == Text::lit("tag")
        ? prism_rtl::more(prism_rtl::rc(BindTagPattern(env_p0, st_p1, p_p2, qk_p8, Array<crate::syntax::FieldPat>{}, true, t_p5)))
        : ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(prism_rtl::deref(env_p0).g_p).ctors_p, qk_p8);
        prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{env_p0, crate::check::types::recording::err_f(st_p1, Text::lit("unknown-name"), prism_rtl::deref(n_p3).span_p, prism_rtl::cat("`", crate::check::env::sname_key_f(n_p3), "` is not a constructor"))})
        : prism_rtl::is_some(_m) ? ({
        auto&& c_p9 = prism_rtl::some_of(_m);
        ({
        auto args_p4x = args_p4;
        auto env_p0x = env_p0;
        auto p_p2x = p_p2;
        auto st_p1x = st_p1;
        auto t_p5x = t_p5;
        (crate::prelude::call_then(crate::check::types::schemes::start_instantiate_with_f(st_p1x, crate::check::types::Scheme{.qs_p = prism_rtl::deref(c_p9).params_p, .plain_qs_p = Array<Text>{}, .rqs_p = Array<Text>{}, .cqs_p = Array<Text>{}, .cjoins_p = Array<std::tuple<Text, Text>>{}, .bounds_p = Array<std::tuple<Text, Text>>{}, .ty_p = prism_rtl::deref(c_p9).ty_p}, prism_rtl::deref(p_p2x).span_p, Array<crate::check::types::Ty>{}), [=, args_p4x = std::move(args_p4x), env_p0x = std::move(env_p0x), t_p5x = std::move(t_p5x)](std::tuple<crate::check::types::Ty, crate::check::types::St, crate::check::types::schemes::Inst> instantiate_with_f_7174) {
        return ({
            auto [self_pb, st1_pc, inst_pd] = instantiate_with_f_7174;
            (crate::prelude::call_then(crate::check::types::unify::start_unify_f(st1_pc, t_p5x, self_pb, prism_rtl::deref(p_p2x).span_p), [=](crate::check::types::St unify_f_7329) {
            return ({
                auto st2_pa = unify_f_7329;
                (crate::prelude::len(args_p4x) != crate::prelude::len(prism_rtl::deref(c_p9).args_p)) && (!((crate::prelude::len(args_p4x) == Nat(1u)) && (crate::prelude::len(prism_rtl::deref(c_p9).args_p) > Nat(1u))))
                ? prism_rtl::finished(std::tuple{env_p0x, crate::check::types::recording::err_f(st2_pa, Text::lit("mismatch"), prism_rtl::deref(p_p2x).span_p, prism_rtl::cat("`", crate::check::types::bare_name_f(prism_rtl::deref(c_p9).name_p), "` takes ", crate::check::errors::count_word_f(crate::prelude::len(prism_rtl::deref(c_p9).args_p)), " argument", crate::prelude::len(prism_rtl::deref(c_p9).args_p) == Nat(1u)
                ? Text::lit("")
                : Text::lit("s"), "; this pattern gives ", crate::check::errors::count_word_f(crate::prelude::len(args_p4x))))})
                : crate::prelude::fold_job(crate::check::errors::range0_f(crate::prelude::len(args_p4x)), std::tuple{env_p0x, st2_pa}, ({
                auto args_p4xx = args_p4x;
                auto p_p2xx = p_p2x;
                auto inst_pdx = inst_pd;
                auto c_p9x = c_p9;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>>(std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=, args_p4xx = std::move(args_p4xx), p_p2xx = std::move(p_p2xx), inst_pdx = std::move(inst_pdx), c_p9x = std::move(c_p9x)](std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto args_p4xxy = args_p4xx;
                    auto p_p2xxy = p_p2xx;
                    auto inst_pdxy = inst_pdx;
                    auto c_p9xy = c_p9x;
                    (crate::prelude::entered(crate::prelude::once_job([=, args_p4xxy = std::move(args_p4xxy), p_p2xxy = std::move(p_p2xxy), inst_pdxy = std::move(inst_pdxy), c_p9xy = std::move(c_p9xy)]() {
                    return ({
                        auto [en_pe, s_pf] = p0;
                        auto i_pg = p1;
                        (crate::prelude::call_then(crate::check::types::schemes::start_subst_q_f(inst_pdxy, crate::prelude::or_(crate::prelude::index(prism_rtl::deref(c_p9xy).args_p, i_pg), crate::check::types::Ty(crate::check::types::Ty::TyErr{}))), [=](crate::check::types::Ty subst_q_f_7811) { return prism_rtl::more(prism_rtl::rc(BindPattern(en_pe, s_pf, crate::prelude::or_(crate::prelude::index(args_p4xxy, i_pg), crate::syntax::Pattern_{.kind_p = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PIgnore{})), .span_p = prism_rtl::deref(p_p2xxy).span_p}), subst_q_f_7811, true))); }));
                    });
                })));
                });
            }));
            }))->cycle();
            });
        }));
        });
    }));
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start BindCtor, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>> start_bind_ctor_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Pattern_ p_p2, crate::syntax::SName n_p3, Array<crate::syntax::Pattern_> args_p4, crate::check::types::Ty t_p5) {
    return prism_rtl::make_rc<BindCtor>(env_p0, st_p1, p_p2, n_p3, args_p4, t_p5);
}


/// BindRecord: unbounded fn Env, St, Pattern, SName, [FieldPat], Bool, Ty -> ((Env, St))
std::tuple<crate::check::expr::Env, crate::check::types::St> bind_record_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Pattern_& p_p2, const crate::syntax::SName& n_p3, const Array<crate::syntax::FieldPat>& fields_p4, const bool& rest_p5, const crate::check::types::Ty& t_p6) {
    auto [qk_o7, why_p8] = crate::check::env::names::resolve_value_f(env_p0.g_p, env_p0.home_p, n_p3);
    if (prism_rtl::is_none(qk_o7)) {
        return std::tuple{env_p0, crate::check::types::recording::err_f(st_p1, Text::lit("unknown-name"), n_p3.span_p, prism_rtl::cat("no record or tag `", crate::check::env::sname_key_f(n_p3), "`"))};
    }
    if (prism_rtl::is_some(qk_o7)) {
        auto&& qk_p9 = prism_rtl::some_of(qk_o7);
        return why_p8 == Text::lit("tag")
            ? bind_tag_pattern_f(env_p0, st_p1, p_p2, qk_p9, fields_p4, rest_p5, t_p6)
            : ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<crate::check::expr::Env, crate::check::types::St>> _v;
            auto&& _m = crate::prelude::get(prism_rtl::deref(env_p0.g_p).ctors_p, qk_p9);
            if (prism_rtl::is_none(_m)) {
                _v.set(std::tuple{env_p0, crate::check::types::recording::err_f(st_p1, Text::lit("unknown-name"), n_p3.span_p, prism_rtl::cat("`", crate::check::env::sname_key_f(n_p3), "` is not a record"))});
                goto _done;
            }
            if (prism_rtl::is_some(_m)) {
                auto&& c_pa = prism_rtl::some_of(_m);
                _v.set(({
                    auto [self_pc, st1_pd, inst_pe] = crate::check::types::schemes::instantiate_with_f(st_p1, crate::check::types::Scheme{.qs_p = prism_rtl::deref(c_pa).params_p, .plain_qs_p = Array<Text>{}, .rqs_p = Array<Text>{}, .cqs_p = Array<Text>{}, .cjoins_p = Array<std::tuple<Text, Text>>{}, .bounds_p = Array<std::tuple<Text, Text>>{}, .ty_p = prism_rtl::deref(c_pa).ty_p}, p_p2.span_p, Array<crate::check::types::Ty>{});
                    auto st2_pb = crate::check::types::unify::unify_f(st1_pd, t_p6, self_pc, p_p2.span_p);
                    (crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(crate::prelude::len(fields_p4)), std::tuple{env_p0, st2_pb}, ({
                    auto fields_p4x = fields_p4;
                    auto p_p2x = p_p2;
                    auto c_pax = c_pa;
                    auto inst_pex = inst_pe;
                    static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>>(std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=, fields_p4x = std::move(fields_p4x), p_p2x = std::move(p_p2x), c_pax = std::move(c_pax), inst_pex = std::move(inst_pex)](std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto fields_p4xy = fields_p4x;
                        auto p_p2xy = p_p2x;
                        auto c_paxy = c_pax;
                        auto inst_pexy = inst_pex;
                        (crate::prelude::entered(crate::prelude::once_job([=, fields_p4xy = std::move(fields_p4xy), p_p2xy = std::move(p_p2xy), c_paxy = std::move(c_paxy), inst_pexy = std::move(inst_pexy)]() {
                        return ({
                            auto [en_pf, s_pg] = p0;
                            auto i_ph = p1;
                            ({
                            auto fp_pi = crate::prelude::or_(crate::prelude::index(fields_p4xy, i_ph), crate::syntax::FieldPat{.name_o = std::optional<crate::syntax::Ident>{}, .pattern_p = crate::syntax::Pattern_{.kind_p = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PIgnore{})), .span_p = prism_rtl::deref(p_p2xy).span_p}, .span_p = prism_rtl::deref(p_p2xy).span_p});
                            auto fname_pj = field_pat_name_f(fp_pi, prism_rtl::deref(c_paxy).fields_p, i_ph);
                            ({
                            auto&& _m = crate::check::expr::operators::index_of_o(prism_rtl::deref(c_paxy).fields_p, fname_pj);
                            prism_rtl::is_some(_m) ? ({
                            auto&& j_pk = prism_rtl::some_of(_m);
                            crate::prelude::call_then(crate::check::types::schemes::start_subst_q_f(inst_pexy, crate::prelude::or_(crate::prelude::index(prism_rtl::deref(c_paxy).args_p, j_pk), crate::check::types::Ty(crate::check::types::Ty::TyErr{}))), [=](crate::check::types::Ty subst_q_f_9164) { return prism_rtl::more(prism_rtl::rc(BindPattern(en_pf, s_pg, prism_rtl::deref(fp_pi).pattern_p, subst_q_f_9164, true))); });
                        })
                            : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{en_pf, crate::check::types::recording::err_f(s_pg, Text::lit("mismatch"), prism_rtl::deref(fp_pi).span_p, prism_rtl::cat("`", crate::check::types::bare_name_f(prism_rtl::deref(c_paxy).owner_p), "` has no field `", fname_pj, "`"))})
                            : throw prism_rtl::Panic("no arm matched");
                        });
                        });
                        });
                    })));
                    });
                }));
                }))));
                }));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St>> BindRecord::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& p_p2 = this->p_p2;
    const auto& n_p3 = this->n_p3;
    const auto& fields_p4 = this->fields_p4;
    const auto& rest_p5 = this->rest_p5;
    const auto& t_p6 = this->t_p6;
    auto [qk_o7, why_p8] = crate::check::env::names::resolve_value_f(prism_rtl::deref(env_p0).g_p, prism_rtl::deref(env_p0).home_p, n_p3);
    return ({
        prism_rtl::is_none(qk_o7) ? prism_rtl::finished(std::tuple{env_p0, crate::check::types::recording::err_f(st_p1, Text::lit("unknown-name"), prism_rtl::deref(n_p3).span_p, prism_rtl::cat("no record or tag `", crate::check::env::sname_key_f(n_p3), "`"))})
        : prism_rtl::is_some(qk_o7) ? ({
        auto&& qk_p9 = prism_rtl::some_of(qk_o7);
        why_p8 == Text::lit("tag")
        ? prism_rtl::more(prism_rtl::rc(BindTagPattern(env_p0, st_p1, p_p2, qk_p9, fields_p4, prism_rtl::deref(rest_p5), t_p6)))
        : ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(prism_rtl::deref(env_p0).g_p).ctors_p, qk_p9);
        prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{env_p0, crate::check::types::recording::err_f(st_p1, Text::lit("unknown-name"), prism_rtl::deref(n_p3).span_p, prism_rtl::cat("`", crate::check::env::sname_key_f(n_p3), "` is not a record"))})
        : prism_rtl::is_some(_m) ? ({
        auto&& c_pa = prism_rtl::some_of(_m);
        ({
        auto env_p0x = env_p0;
        auto fields_p4x = fields_p4;
        auto p_p2x = p_p2;
        auto st_p1x = st_p1;
        auto t_p6x = t_p6;
        (crate::prelude::call_then(crate::check::types::schemes::start_instantiate_with_f(st_p1x, crate::check::types::Scheme{.qs_p = prism_rtl::deref(c_pa).params_p, .plain_qs_p = Array<Text>{}, .rqs_p = Array<Text>{}, .cqs_p = Array<Text>{}, .cjoins_p = Array<std::tuple<Text, Text>>{}, .bounds_p = Array<std::tuple<Text, Text>>{}, .ty_p = prism_rtl::deref(c_pa).ty_p}, prism_rtl::deref(p_p2x).span_p, Array<crate::check::types::Ty>{}), [=, env_p0x = std::move(env_p0x), fields_p4x = std::move(fields_p4x), t_p6x = std::move(t_p6x)](std::tuple<crate::check::types::Ty, crate::check::types::St, crate::check::types::schemes::Inst> instantiate_with_f_8595) {
        return ({
            auto [self_pc, st1_pd, inst_pe] = instantiate_with_f_8595;
            (crate::prelude::call_then(crate::check::types::unify::start_unify_f(st1_pd, t_p6x, self_pc, prism_rtl::deref(p_p2x).span_p), [=](crate::check::types::St unify_f_8750) {
            return ({
                auto st2_pb = unify_f_8750;
                (crate::prelude::fold_job(crate::check::errors::range0_f(crate::prelude::len(fields_p4x)), std::tuple{env_p0x, st2_pb}, ({
                auto fields_p4xx = fields_p4x;
                auto p_p2xx = p_p2x;
                auto c_pax = c_pa;
                auto inst_pex = inst_pe;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>>(std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=, fields_p4xx = std::move(fields_p4xx), p_p2xx = std::move(p_p2xx), c_pax = std::move(c_pax), inst_pex = std::move(inst_pex)](std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto fields_p4xxy = fields_p4xx;
                    auto p_p2xxy = p_p2xx;
                    auto c_paxy = c_pax;
                    auto inst_pexy = inst_pex;
                    (crate::prelude::entered(crate::prelude::once_job([=, fields_p4xxy = std::move(fields_p4xxy), p_p2xxy = std::move(p_p2xxy), c_paxy = std::move(c_paxy), inst_pexy = std::move(inst_pexy)]() {
                    return ({
                        auto [en_pf, s_pg] = p0;
                        auto i_ph = p1;
                        ({
                        auto fp_pi = crate::prelude::or_(crate::prelude::index(fields_p4xxy, i_ph), crate::syntax::FieldPat{.name_o = std::optional<crate::syntax::Ident>{}, .pattern_p = crate::syntax::Pattern_{.kind_p = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PIgnore{})), .span_p = prism_rtl::deref(p_p2xxy).span_p}, .span_p = prism_rtl::deref(p_p2xxy).span_p});
                        auto fname_pj = field_pat_name_f(fp_pi, prism_rtl::deref(c_paxy).fields_p, i_ph);
                        ({
                        auto&& _m = crate::check::expr::operators::index_of_o(prism_rtl::deref(c_paxy).fields_p, fname_pj);
                        prism_rtl::is_some(_m) ? ({
                        auto&& j_pk = prism_rtl::some_of(_m);
                        crate::prelude::call_then(crate::check::types::schemes::start_subst_q_f(inst_pexy, crate::prelude::or_(crate::prelude::index(prism_rtl::deref(c_paxy).args_p, j_pk), crate::check::types::Ty(crate::check::types::Ty::TyErr{}))), [=](crate::check::types::Ty subst_q_f_9164) { return prism_rtl::more(prism_rtl::rc(BindPattern(en_pf, s_pg, prism_rtl::deref(fp_pi).pattern_p, subst_q_f_9164, true))); });
                    })
                        : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{en_pf, crate::check::types::recording::err_f(s_pg, Text::lit("mismatch"), prism_rtl::deref(fp_pi).span_p, prism_rtl::cat("`", crate::check::types::bare_name_f(prism_rtl::deref(c_paxy).owner_p), "` has no field `", fname_pj, "`"))})
                        : throw prism_rtl::Panic("no arm matched");
                    });
                    });
                    });
                })));
                });
            }));
            }))->cycle());
            });
        }));
        });
    }));
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start BindRecord, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>> start_bind_record_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Pattern_ p_p2, crate::syntax::SName n_p3, Array<crate::syntax::FieldPat> fields_p4, bool rest_p5, crate::check::types::Ty t_p6) {
    return prism_rtl::make_rc<BindRecord>(env_p0, st_p1, p_p2, n_p3, fields_p4, rest_p5, t_p6);
}


/// FieldPatName: fn FieldPat, [Text], Nat -> Text
Text field_pat_name_f(const crate::syntax::FieldPat& fp_p0, const Array<Text>& fields_p1, const Nat& i_p2) {
    auto&& _m = fp_p0.name_o;
    if (prism_rtl::is_some(_m)) {
        auto&& id_p3 = prism_rtl::some_of(_m);
        return prism_rtl::deref(id_p3).name_p;
    }
    if (prism_rtl::is_none(_m)) {
        auto&& _m = prism_rtl::deref(prism_rtl::deref(fp_p0.pattern_p).kind_p);
        if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
            auto&& n_p4 = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
            return crate::check::types::has_text_f(fields_p1, crate::check::env::sname_key_f(n_p4))
                ? crate::check::env::sname_key_f(n_p4)
                : crate::prelude::or_(crate::prelude::index(fields_p1, i_p2), Text::lit(""));
        }
        {
            return crate::prelude::or_(crate::prelude::index(fields_p1, i_p2), Text::lit(""));
        }
    }
    prism_rtl::unreachable("no arm matched");
}


/// BindTagPattern: unbounded fn Env, St, Pattern, Text, [FieldPat], Bool, Ty -> ((Env, St))
std::tuple<crate::check::expr::Env, crate::check::types::St> bind_tag_pattern_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Pattern_& p_p2, const Text& name_p3, const Array<crate::syntax::FieldPat>& fields_p4, const bool& rest_p5, const crate::check::types::Ty& t_p6) {
    auto&& _m = crate::prelude::get(prism_rtl::deref(env_p0.g_p).tags_p, name_p3);
    if (prism_rtl::is_none(_m)) {
        return std::tuple{env_p0, crate::check::types::recording::err_f(st_p1, Text::lit("unknown-name"), p_p2.span_p, prism_rtl::cat("no tag `", name_p3, "`"))};
    }
    if (prism_rtl::is_some(_m)) {
        auto&& tg_p7 = prism_rtl::some_of(_m);
        auto st1_p8 = prism_rtl::deref(tg_p7).kind_p == Text::lit("Element")
            ? tag_in_row_f(env_p0, st_p1, tg_p7, t_p6, p_p2.span_p)
            : crate::check::types::unify::unify_f(st_p1, t_p6, crate::check::types::Ty(crate::check::types::Ty::TyCon{prism_rtl::deref(tg_p7).kind_p, Array<crate::check::types::Ty>{}}), p_p2.span_p);
        auto snapshot_p9 = is_snapshot_f(st1_p8, t_p6);
        auto&& _st2_pb = crate::check::types::schemes::instantiate_with_f(st1_p8, crate::check::types::Scheme{.qs_p = prism_rtl::deref(tg_p7).qs_p, .plain_qs_p = Array<Text>{}, .rqs_p = prism_rtl::deref(tg_p7).rqs_p, .cqs_p = Array<Text>{}, .cjoins_p = Array<std::tuple<Text, Text>>{}, .bounds_p = Array<std::tuple<Text, Text>>{}, .ty_p = prism_rtl::deref(tg_p7).out_p}, p_p2.span_p, Array<crate::check::types::Ty>{});
        auto&& st2_pb = std::get<1>(_st2_pb);
        auto&& inst_pc = std::get<2>(_st2_pb);
        auto names_pa = crate::prelude::each(prism_rtl::deref(tg_p7).fields_p, [&](const std::tuple<Text, crate::check::types::Ty>& _p0) {
            auto&& f_pd = std::get<0>(_p0);
            return f_pd;
        });
        return crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(crate::prelude::len(fields_p4)), std::tuple{env_p0, st2_pb}, ({
            auto fields_p4x = fields_p4;
            auto p_p2x = p_p2;
            auto names_pax = names_pa;
            auto tg_p7x = tg_p7;
            auto inst_pcx = inst_pc;
            auto snapshot_p9x = std::move(snapshot_p9);
            auto name_p3x = name_p3;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>>(std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=, fields_p4x = std::move(fields_p4x), p_p2x = std::move(p_p2x), names_pax = std::move(names_pax), tg_p7x = std::move(tg_p7x), inst_pcx = std::move(inst_pcx), snapshot_p9x = std::move(snapshot_p9x), name_p3x = std::move(name_p3x)](std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto fields_p4xy = fields_p4x;
                auto p_p2xy = p_p2x;
                auto names_paxy = names_pax;
                auto tg_p7xy = tg_p7x;
                auto inst_pcxy = inst_pcx;
                auto snapshot_p9xy = snapshot_p9x;
                auto name_p3xy = name_p3x;
                (crate::prelude::entered(crate::prelude::once_job([=, fields_p4xy = std::move(fields_p4xy), p_p2xy = std::move(p_p2xy), names_paxy = std::move(names_paxy), tg_p7xy = std::move(tg_p7xy), inst_pcxy = std::move(inst_pcxy), snapshot_p9xy = std::move(snapshot_p9xy), name_p3xy = std::move(name_p3xy)]() {
                return ({
                    auto [en_pe, s_pf] = p0;
                    auto i_pg = p1;
                    ({
                    auto fp_ph = crate::prelude::or_(crate::prelude::index(fields_p4xy, i_pg), crate::syntax::FieldPat{.name_o = std::optional<crate::syntax::Ident>{}, .pattern_p = crate::syntax::Pattern_{.kind_p = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PIgnore{})), .span_p = prism_rtl::deref(p_p2xy).span_p}, .span_p = prism_rtl::deref(p_p2xy).span_p});
                    auto fname_pi = field_pat_name_f(fp_ph, names_paxy, i_pg);
                    ({
                    auto&& _m = crate::check::expr::calls::field_of_tag_o(tg_p7xy, fname_pi);
                    prism_rtl::is_some(_m) ? ({
                    auto&& ft_pj = prism_rtl::some_of(_m);
                    crate::prelude::call_then(crate::check::types::schemes::start_subst_q_f(inst_pcxy, ft_pj), [=](crate::check::types::Ty subst_q_f_10850) { return prism_rtl::more(prism_rtl::rc(BindField(en_pe, s_pf, prism_rtl::deref(fp_ph).pattern_p, subst_q_f_10850, snapshot_p9xy))); });
                })
                    : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{en_pe, crate::check::types::recording::err_f(s_pf, Text::lit("mismatch"), prism_rtl::deref(fp_ph).span_p, prism_rtl::cat("`", name_p3xy, "` has no field `", fname_pi, "`"))})
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
                });
            })));
            });
        }));
        })));
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St>> BindTagPattern::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& p_p2 = this->p_p2;
    const auto& name_p3 = this->name_p3;
    const auto& fields_p4 = this->fields_p4;
    const auto& rest_p5 = this->rest_p5;
    const auto& t_p6 = this->t_p6;
    return ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(prism_rtl::deref(env_p0).g_p).tags_p, name_p3);
        prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{env_p0, crate::check::types::recording::err_f(st_p1, Text::lit("unknown-name"), prism_rtl::deref(p_p2).span_p, prism_rtl::cat("no tag `", name_p3, "`"))})
        : prism_rtl::is_some(_m) ? ({
        auto&& tg_p7 = prism_rtl::some_of(_m);
        ({
        auto st1_p8 = prism_rtl::deref(tg_p7).kind_p == Text::lit("Element")
            ? tag_in_row_f(env_p0, st_p1, tg_p7, t_p6, prism_rtl::deref(p_p2).span_p)
            : crate::check::types::unify::unify_f(st_p1, t_p6, crate::check::types::Ty(crate::check::types::Ty::TyCon{prism_rtl::deref(tg_p7).kind_p, Array<crate::check::types::Ty>{}}), prism_rtl::deref(p_p2).span_p);
        auto env_p0x = env_p0;
        auto fields_p4x = fields_p4;
        auto name_p3x = name_p3;
        auto p_p2x = p_p2;
        auto t_p6x = t_p6;
        (crate::prelude::call_then(start_is_snapshot_f(st1_p8, t_p6x), [=, env_p0x = std::move(env_p0x), fields_p4x = std::move(fields_p4x), name_p3x = std::move(name_p3x), p_p2x = std::move(p_p2x)](bool is_snapshot_f_10294) {
        return ({
            auto snapshot_p9 = is_snapshot_f_10294;
            (crate::prelude::call_then(crate::check::types::schemes::start_instantiate_with_f(st1_p8, crate::check::types::Scheme{.qs_p = prism_rtl::deref(tg_p7).qs_p, .plain_qs_p = Array<Text>{}, .rqs_p = prism_rtl::deref(tg_p7).rqs_p, .cqs_p = Array<Text>{}, .cjoins_p = Array<std::tuple<Text, Text>>{}, .bounds_p = Array<std::tuple<Text, Text>>{}, .ty_p = prism_rtl::deref(tg_p7).out_p}, prism_rtl::deref(p_p2x).span_p, Array<crate::check::types::Ty>{}), [=, snapshot_p9 = std::move(snapshot_p9)](std::tuple<crate::check::types::Ty, crate::check::types::St, crate::check::types::schemes::Inst> instantiate_with_f_10348) {
            return ({
                auto&& _st2_pb = instantiate_with_f_10348;
                auto&& st2_pb = std::get<1>(_st2_pb);
                auto&& inst_pc = std::get<2>(_st2_pb);
                auto names_pa = crate::prelude::each(prism_rtl::deref(tg_p7).fields_p, [&](const std::tuple<Text, crate::check::types::Ty>& _p0) {
                    auto&& f_pd = std::get<0>(_p0);
                    return f_pd;
                });
                (crate::prelude::fold_job(crate::check::errors::range0_f(crate::prelude::len(fields_p4x)), std::tuple{env_p0x, st2_pb}, ({
                auto fields_p4xx = fields_p4x;
                auto p_p2xx = p_p2x;
                auto names_pax = names_pa;
                auto tg_p7x = tg_p7;
                auto inst_pcx = inst_pc;
                auto snapshot_p9x = snapshot_p9;
                auto name_p3xx = name_p3x;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>>(std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=, fields_p4xx = std::move(fields_p4xx), p_p2xx = std::move(p_p2xx), names_pax = std::move(names_pax), tg_p7x = std::move(tg_p7x), inst_pcx = std::move(inst_pcx), snapshot_p9x = std::move(snapshot_p9x), name_p3xx = std::move(name_p3xx)](std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto fields_p4xxy = fields_p4xx;
                    auto p_p2xxy = p_p2xx;
                    auto names_paxy = names_pax;
                    auto tg_p7xy = tg_p7x;
                    auto inst_pcxy = inst_pcx;
                    auto snapshot_p9xy = snapshot_p9x;
                    auto name_p3xxy = name_p3xx;
                    (crate::prelude::entered(crate::prelude::once_job([=, fields_p4xxy = std::move(fields_p4xxy), p_p2xxy = std::move(p_p2xxy), names_paxy = std::move(names_paxy), tg_p7xy = std::move(tg_p7xy), inst_pcxy = std::move(inst_pcxy), snapshot_p9xy = std::move(snapshot_p9xy), name_p3xxy = std::move(name_p3xxy)]() {
                    return ({
                        auto [en_pe, s_pf] = p0;
                        auto i_pg = p1;
                        ({
                        auto fp_ph = crate::prelude::or_(crate::prelude::index(fields_p4xxy, i_pg), crate::syntax::FieldPat{.name_o = std::optional<crate::syntax::Ident>{}, .pattern_p = crate::syntax::Pattern_{.kind_p = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PIgnore{})), .span_p = prism_rtl::deref(p_p2xxy).span_p}, .span_p = prism_rtl::deref(p_p2xxy).span_p});
                        auto fname_pi = field_pat_name_f(fp_ph, names_paxy, i_pg);
                        ({
                        auto&& _m = crate::check::expr::calls::field_of_tag_o(tg_p7xy, fname_pi);
                        prism_rtl::is_some(_m) ? ({
                        auto&& ft_pj = prism_rtl::some_of(_m);
                        crate::prelude::call_then(crate::check::types::schemes::start_subst_q_f(inst_pcxy, ft_pj), [=](crate::check::types::Ty subst_q_f_10850) { return prism_rtl::more(prism_rtl::rc(BindField(en_pe, s_pf, prism_rtl::deref(fp_ph).pattern_p, subst_q_f_10850, snapshot_p9xy))); });
                    })
                        : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{en_pe, crate::check::types::recording::err_f(s_pf, Text::lit("mismatch"), prism_rtl::deref(fp_ph).span_p, prism_rtl::cat("`", name_p3xxy, "` has no field `", fname_pi, "`"))})
                        : throw prism_rtl::Panic("no arm matched");
                    });
                    });
                    });
                })));
                });
            }));
            }))->cycle());
            });
        }));
        });
    }));
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start BindTagPattern, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>> start_bind_tag_pattern_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Pattern_ p_p2, Text name_p3, Array<crate::syntax::FieldPat> fields_p4, bool rest_p5, crate::check::types::Ty t_p6) {
    return prism_rtl::make_rc<BindTagPattern>(env_p0, st_p1, p_p2, name_p3, fields_p4, rest_p5, t_p6);
}


/// IsSnapshot: unbounded fn St, Ty -> Bool
bool is_snapshot_f(const crate::check::types::St& st_p0, const crate::check::types::Ty& t_p1) {
    auto&& _m = crate::check::types::recording::walk_f(st_p0, t_p1);
    if (prism_rtl::is<crate::check::types::Ty::TyElemAny>(_m)) {
        return true;
    }
    {
        return false;
    }
}


prism_rtl::Turn<bool> IsSnapshot::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& t_p1 = this->t_p1;
    auto st_p0x = st_p0;
    auto t_p1x = t_p1;
    return crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p0x, t_p1x), [=](crate::check::types::Ty walk_f_11187) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TyElemAny>(walk_f_11187) ? prism_rtl::finished(true)
            : prism_rtl::finished(false);
        });
    });
}


/// `Start IsSnapshot, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_is_snapshot_f(crate::check::types::St st_p0, crate::check::types::Ty t_p1) {
    return prism_rtl::make_rc<IsSnapshot>(st_p0, t_p1);
}


/// TagInRow: unbounded fn Env, St, TagInfo, Ty, Range -> St
crate::check::types::St tag_in_row_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::check::env::TagInfo& tg_p2, const crate::check::types::Ty& t_p3, const crate::syntax::Range& span_p4) {
    auto&& _m = crate::check::types::recording::walk_f(st_p1, t_p3);
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(_m)) {
        auto&& rw_p5 = prism_rtl::as<crate::check::types::Ty::TyElem>(_m).a0;
        auto w_p6 = crate::check::types::recording::walk_row_f(st_p1, rw_p5);
        return crate::check::types::has_text_f(prism_rtl::deref(w_p6).fams_p, tg_p2.family_p)
            ? st_p1
            : crate::check::types::recording::err_fix_f(st_p1, Text::lit("row-not-here"), span_p4, prism_rtl::cat("`", tg_p2.name_p, "` is not in this row, `", crate::check::types::show_row_f(w_p6), "`"), prism_rtl::cat("add `", tg_p2.family_p, ".*` to the row, or answer the tag elsewhere"));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElemAny>(_m)) {
        auto&& rw_p7 = prism_rtl::as<crate::check::types::Ty::TyElemAny>(_m).a0;
        auto w_p8 = crate::check::types::recording::walk_row_f(st_p1, rw_p7);
        return crate::check::types::has_text_f(prism_rtl::deref(w_p8).fams_p, tg_p2.family_p)
            ? st_p1
            : crate::check::types::recording::err_fix_f(st_p1, Text::lit("row-not-here"), span_p4, prism_rtl::cat("`", tg_p2.name_p, "` is not in this row, `", crate::check::types::show_row_f(w_p8), "`"), prism_rtl::cat("add `", tg_p2.family_p, ".*` to the row, or answer the tag elsewhere"));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFlex>(_m)) {
        auto [rw_p9, st2_pa] = crate::check::types::recording::fresh_row_f(st_p1, Array(std::vector{tg_p2.family_p}));
        auto [o_pb, st3_pc] = crate::check::types::fresh_var_f(st2_pa, false, Text::lit(""));
        return crate::check::types::unify::unify_f(st3_pc, t_p3, crate::check::types::Ty(crate::check::types::Ty::TyElem{crate::check::types::Rw{.fams_p = Array(std::vector{tg_p2.family_p}), .minus_p = Array<Text>{}, .tail_p = prism_rtl::deref(rw_p9).tail_p}, prism_rtl::rc(o_pb)}), span_p4);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyErr>(_m)) {
        return st_p1;
    }
    {
        auto&& other_pd = _m;
        return crate::check::types::recording::err_f(st_p1, Text::lit("mismatch"), span_p4, prism_rtl::cat("a tag pattern matches an element; this is `", crate::check::types::show_ty_f(st_p1, other_pd), "`"));
    }
}


prism_rtl::Turn<crate::check::types::St> TagInRow::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& tg_p2 = this->tg_p2;
    const auto& t_p3 = this->t_p3;
    const auto& span_p4 = this->span_p4;
    auto span_p4x = span_p4;
    auto st_p1x = st_p1;
    auto t_p3x = t_p3;
    auto tg_p2x = tg_p2;
    return crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p1x, t_p3x), [=](crate::check::types::Ty walk_f_11346) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TyElem>(walk_f_11346) ? ({
            auto&& rw_p5 = prism_rtl::as<crate::check::types::Ty::TyElem>(walk_f_11346).a0;
            crate::prelude::call_then(crate::check::types::recording::start_walk_row_f(st_p1x, rw_p5), [=](crate::check::types::Rw walk_row_f_11397) {
            return ({
                auto w_p6 = walk_row_f_11397;
                (crate::check::types::has_text_f(prism_rtl::deref(w_p6).fams_p, prism_rtl::deref(tg_p2x).family_p)
                ? prism_rtl::finished(st_p1x)
                : prism_rtl::finished(crate::check::types::recording::err_fix_f(st_p1x, Text::lit("row-not-here"), span_p4x, prism_rtl::cat("`", prism_rtl::deref(tg_p2x).name_p, "` is not in this row, `", crate::check::types::show_row_f(w_p6), "`"), prism_rtl::cat("add `", prism_rtl::deref(tg_p2x).family_p, ".*` to the row, or answer the tag elsewhere"))));
            });
        });
        })
            : prism_rtl::is<crate::check::types::Ty::TyElemAny>(walk_f_11346) ? ({
            auto&& rw_p7 = prism_rtl::as<crate::check::types::Ty::TyElemAny>(walk_f_11346).a0;
            crate::prelude::call_then(crate::check::types::recording::start_walk_row_f(st_p1x, rw_p7), [=](crate::check::types::Rw walk_row_f_11645) {
            return ({
                auto w_p8 = walk_row_f_11645;
                (crate::check::types::has_text_f(prism_rtl::deref(w_p8).fams_p, prism_rtl::deref(tg_p2x).family_p)
                ? prism_rtl::finished(st_p1x)
                : prism_rtl::finished(crate::check::types::recording::err_fix_f(st_p1x, Text::lit("row-not-here"), span_p4x, prism_rtl::cat("`", prism_rtl::deref(tg_p2x).name_p, "` is not in this row, `", crate::check::types::show_row_f(w_p8), "`"), prism_rtl::cat("add `", prism_rtl::deref(tg_p2x).family_p, ".*` to the row, or answer the tag elsewhere"))));
            });
        });
        })
            : prism_rtl::is<crate::check::types::Ty::TyFlex>(walk_f_11346) ? ({
            auto [rw_p9, st2_pa] = crate::check::types::recording::fresh_row_f(st_p1x, Array(std::vector{prism_rtl::deref(tg_p2x).family_p}));
            auto [o_pb, st3_pc] = crate::check::types::fresh_var_f(st2_pa, false, Text::lit(""));
            (prism_rtl::more(prism_rtl::rc(crate::check::types::unify::Unify(st3_pc, t_p3x, crate::check::types::Ty(crate::check::types::Ty::TyElem{crate::check::types::Rw{.fams_p = Array(std::vector{prism_rtl::deref(tg_p2x).family_p}), .minus_p = Array<Text>{}, .tail_p = prism_rtl::deref(rw_p9).tail_p}, prism_rtl::rc(o_pb)}), span_p4x))));
        })
            : prism_rtl::is<crate::check::types::Ty::TyErr>(walk_f_11346) ? prism_rtl::finished(st_p1x)
            : ({
            auto&& other_pd = walk_f_11346;
            crate::prelude::call_then(crate::check::types::start_show_ty_f(st_p1x, other_pd), [=](Text show_ty_f_12167) { return prism_rtl::finished(crate::check::types::recording::err_f(st_p1x, Text::lit("mismatch"), span_p4x, prism_rtl::cat("a tag pattern matches an element; this is `", show_ty_f_12167, "`"))); });
        });
        });
    });
}


/// `Start TagInRow, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_tag_in_row_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::check::env::TagInfo tg_p2, crate::check::types::Ty t_p3, crate::syntax::Range span_p4) {
    return prism_rtl::make_rc<TagInRow>(env_p0, st_p1, tg_p2, t_p3, span_p4);
}


/// BindFamily: unbounded fn Env, St, Text, Ty, Range -> ((Env, St))
std::tuple<crate::check::expr::Env, crate::check::types::St> bind_family_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const Text& fam_p2, const crate::check::types::Ty& t_p3, const crate::syntax::Range& span_p4) {
    auto&& _m = crate::check::types::recording::walk_f(st_p1, t_p3);
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(_m)) {
        auto&& rw_p5 = prism_rtl::as<crate::check::types::Ty::TyElem>(_m).a0;
        auto w_p6 = crate::check::types::recording::walk_row_f(st_p1, rw_p5);
        return crate::check::types::has_text_f(prism_rtl::deref(w_p6).fams_p, fam_p2)
            ? std::tuple{env_p0, st_p1}
            : std::tuple{env_p0, crate::check::types::recording::err_fix_f(st_p1, Text::lit("row-not-here"), span_p4, prism_rtl::cat("`", fam_p2, ".*` is not in this row, `", crate::check::types::show_row_f(w_p6), "`"), prism_rtl::cat("add `", fam_p2, ".*` to the row"))};
    }
    {
        return std::tuple{env_p0, st_p1};
    }
}


prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St>> BindFamily::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& fam_p2 = this->fam_p2;
    const auto& t_p3 = this->t_p3;
    const auto& span_p4 = this->span_p4;
    auto env_p0x = env_p0;
    auto fam_p2x = fam_p2;
    auto span_p4x = span_p4;
    auto st_p1x = st_p1;
    auto t_p3x = t_p3;
    return crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p1x, t_p3x), [=](crate::check::types::Ty walk_f_12297) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TyElem>(walk_f_12297) ? ({
            auto&& rw_p5 = prism_rtl::as<crate::check::types::Ty::TyElem>(walk_f_12297).a0;
            crate::prelude::call_then(crate::check::types::recording::start_walk_row_f(st_p1x, rw_p5), [=](crate::check::types::Rw walk_row_f_12348) {
            return ({
                auto w_p6 = walk_row_f_12348;
                (crate::check::types::has_text_f(prism_rtl::deref(w_p6).fams_p, fam_p2x)
                ? prism_rtl::finished(std::tuple{env_p0x, st_p1x})
                : prism_rtl::finished(std::tuple{env_p0x, crate::check::types::recording::err_fix_f(st_p1x, Text::lit("row-not-here"), span_p4x, prism_rtl::cat("`", fam_p2x, ".*` is not in this row, `", crate::check::types::show_row_f(w_p6), "`"), prism_rtl::cat("add `", fam_p2x, ".*` to the row"))}));
            });
        });
        })
            : prism_rtl::finished(std::tuple{env_p0x, st_p1x});
        });
    });
}


/// `Start BindFamily, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>> start_bind_family_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Text fam_p2, crate::check::types::Ty t_p3, crate::syntax::Range span_p4) {
    return prism_rtl::make_rc<BindFamily>(env_p0, st_p1, fam_p2, t_p3, span_p4);
}

}  // namespace crate::check::expr::patterns
