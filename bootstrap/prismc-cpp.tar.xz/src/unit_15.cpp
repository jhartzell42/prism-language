// The module `Check.Expr.Patterns`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <check/expr/patterns/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Check.Expr.Patterns`, from `target/bootstrap/cpp-src/prismc/check/expr/patterns.prism`.
namespace crate::check::expr::patterns {

/// BindPattern: unbounded fn Env, St, Pattern, Ty, Bool -> ((Env, St))
std::tuple<crate::check::expr::Env, crate::check::types::St> bind_pattern(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Pattern_& p_p2, const crate::check::types::Ty& t_p3, const bool& refutable_p4) {
    auto&& _m = prism_rtl::deref(p_p2.kind);
    if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
        auto&& n_p5 = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        auto bare_p6 = or_(index(n_p5->path_, Nat(0u)), Text::lit(""));
        auto is_ctor_p7 = (crate::check::env::is_upper_text(bare_p6) && (len_text(prism_rtl::deref(n_p5).sigils) == Nat(0u))) && is_ctor_name(env_p0, n_p5);
        return std::move(is_ctor_p7) || (len(n_p5->path_) > Nat(1u))
            ? bind_ctor(env_p0, st_p1, p_p2, n_p5, Array<crate::syntax::Pattern_>{}, t_p3)
            : bind_name(env_p0, st_p1, n_p5, t_p3);
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PIgnore>(_m)) {
        return std::tuple{env_p0, st_p1};
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PLit>(_m)) {
        auto&& l_p8 = prism_rtl::as<crate::syntax::PatternKind::PLit>(_m).a0;
        auto [lt_p9, st2_pa] = crate::check::expr::infer_lit(env_p0, st_p1, l_p8, false, p_p2.span);
        return std::tuple{env_p0, crate::check::types::unify::unify(st2_pa, t_p3, lt_p9, p_p2.span)};
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PNeg>(_m)) {
        auto&& l_pb = prism_rtl::as<crate::syntax::PatternKind::PNeg>(_m).a0;
        auto [lt_pc, st2_pd] = crate::check::expr::infer_lit(env_p0, st_p1, l_pb, true, p_p2.span);
        return std::tuple{env_p0, crate::check::types::unify::unify(st2_pd, t_p3, lt_pc, p_p2.span)};
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PUnit>(_m)) {
        return std::tuple{env_p0, crate::check::types::unify::unify(st_p1, t_p3, crate::check::types::t_unit(), p_p2.span)};
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PNil>(_m)) {
        auto [v_pe, st2_pf] = crate::check::types::fresh_var(st_p1, false, Text::lit(""));
        return std::tuple{env_p0, crate::check::types::unify::unify(st2_pf, t_p3, crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("?"), prism_rtl::rc(v_pe)}), p_p2.span)};
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PCtor>(_m)) {
        auto&& n_pg = prism_rtl::as<crate::syntax::PatternKind::PCtor>(_m).a0;
        auto&& args_ph = prism_rtl::as<crate::syntax::PatternKind::PCtor>(_m).a1;
        return bind_ctor(env_p0, st_p1, p_p2, n_pg, args_ph, t_p3);
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PRecord>(_m)) {
        auto&& n_pi = prism_rtl::as<crate::syntax::PatternKind::PRecord>(_m).a0;
        auto&& fields_pj = prism_rtl::as<crate::syntax::PatternKind::PRecord>(_m).a1;
        auto&& rest_pk = prism_rtl::as<crate::syntax::PatternKind::PRecord>(_m).a2;
        return bind_record(env_p0, st_p1, p_p2, n_pi, fields_pj, rest_pk, t_p3);
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PSigil>(_m)) {
        auto&& s_pl = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a0;
        auto&& inner_pm = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a1;
        return (s_pl == Text::lit("?")) || (s_pl == Text::lit("~"))
            ? ({
            auto [v_po, st2_pp] = crate::check::types::fresh_var(st_p1, false, Text::lit(""));
            auto st3_pn = crate::check::types::unify::unify(st2_pp, t_p3, crate::check::types::Ty(crate::check::types::Ty::TySig{s_pl, prism_rtl::rc(v_po)}), p_p2.span);
            bind_pattern(env_p0, st3_pn, prism_rtl::deref(prism_rtl::deref(inner_pm)), v_po, refutable_p4);
        })
            : ({
            auto [v_pr, st2_ps] = crate::check::types::fresh_var(st_p1, false, Text::lit(""));
            auto st3_pq = crate::check::types::unify::unify(st2_ps, t_p3, crate::check::types::with_marks(s_pl, v_pr, env_p0.scope), p_p2.span);
            bind_pattern(env_p0, st3_pq, prism_rtl::deref(prism_rtl::deref(inner_pm)), v_pr, refutable_p4);
        });
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PTuple>(_m)) {
        auto&& ps_pt = prism_rtl::as<crate::syntax::PatternKind::PTuple>(_m).a0;
        auto [vs_p13, st2_p14] = fold(ps_pt, std::tuple{Array<crate::check::types::Ty>{}, st_p1}, [&](const std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>& _p0, const crate::syntax::Pattern_& _p1) {
            auto&& acc_pv = std::get<0>(_p0);
            auto&& s_p10 = std::get<1>(_p0);
            return ({
                auto [v_p11, s2_p12] = crate::check::types::fresh_var(s_p10, false, Text::lit(""));
                std::tuple{crate::prelude::push(acc_pv, v_p11), s2_p12};
            });
        });
        auto st3_pu = crate::check::types::unify::unify(st2_p14, t_p3, crate::check::types::Ty(crate::check::types::Ty::TyTuple{vs_p13}), p_p2.span);
        return run_to_end(fold_job(crate::check::errors::range0(len(ps_pt)), std::tuple{env_p0, st3_pu}, ({
            auto ps_pt_1 = ps_pt;
            auto p_p2_2 = p_p2;
            auto vs_p13_3 = vs_p13;
            auto refutable_p4_4 = refutable_p4;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>>(std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=, ps_pt_1 = std::move(ps_pt_1), p_p2_2 = std::move(p_p2_2), vs_p13_3 = std::move(vs_p13_3), refutable_p4_4 = std::move(refutable_p4_4)](std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto ps_pt_1_5 = ps_pt_1;
                auto p_p2_2_5 = p_p2_2;
                auto vs_p13_3_5 = vs_p13_3;
                auto refutable_p4_4_5 = refutable_p4_4;
                entered(once_job([=, ps_pt_1_5 = std::move(ps_pt_1_5), p_p2_2_5 = std::move(p_p2_2_5), vs_p13_3_5 = std::move(vs_p13_3_5), refutable_p4_4_5 = std::move(refutable_p4_4_5)]() {
                return ({
                    auto [en_p15, s_p16] = p0;
                    auto i_p17 = p1;
                    (prism_rtl::more(prism_rtl::rc(BindPattern(en_p15, s_p16, or_(index(ps_pt_1_5, i_p17), crate::syntax::Pattern_{.kind = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PIgnore{})), .span = p_p2_2_5.span}), or_(index(vs_p13_3_5, i_p17), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), refutable_p4_4_5))));
                });
            }));
            });
        }));
        })));
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PArray>(_m)) {
        auto&& ps_p18 = prism_rtl::as<crate::syntax::PatternKind::PArray>(_m).a0;
        auto [v_p1a, st2_p1b] = crate::check::types::fresh_var(st_p1, false, Text::lit(""));
        auto st3_p19 = crate::check::types::unify::unify(st2_p1b, t_p3, crate::check::types::Ty(crate::check::types::Ty::TyArray{prism_rtl::rc(v_p1a)}), p_p2.span);
        return run_to_end(fold_job(ps_p18, std::tuple{env_p0, st3_p19}, ({
            auto v_p1a_1 = v_p1a;
            auto refutable_p4_2 = refutable_p4;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>>(std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, crate::syntax::Pattern_>)>>(prism_rtl::rc([=, v_p1a_1 = std::move(v_p1a_1), refutable_p4_2 = std::move(refutable_p4_2)](std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, crate::syntax::Pattern_> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto v_p1a_1_3 = v_p1a_1;
                auto refutable_p4_2_3 = refutable_p4_2;
                entered(once_job([=, v_p1a_1_3 = std::move(v_p1a_1_3), refutable_p4_2_3 = std::move(refutable_p4_2_3)]() {
                return ({
                    auto [en_p1c, s_p1d] = p0;
                    auto q_p1e = p1;
                    (prism_rtl::more(prism_rtl::rc(BindPattern(en_p1c, s_p1d, q_p1e, v_p1a_1_3, refutable_p4_2_3))));
                });
            }));
            });
        }));
        })));
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PGroup>(_m)) {
        auto&& q_p1f = prism_rtl::as<crate::syntax::PatternKind::PGroup>(_m).a0;
        return bind_pattern(env_p0, st_p1, prism_rtl::deref(prism_rtl::deref(q_p1f)), t_p3, refutable_p4);
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PFamily>(_m)) {
        auto&& q_p1g = prism_rtl::as<crate::syntax::PatternKind::PFamily>(_m).a0;
        return bind_family(env_p0, st_p1, crate::check::env::dotted(q_p1g->path_), t_p3, p_p2.span);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St>> BindPattern::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& p_p2 = this->p_p2;
    const auto& t_p3 = this->t_p3;
    const auto& refutable_p4 = this->refutable_p4;
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(p_p2).kind);
        prism_rtl::is<crate::syntax::PatternKind::PName>(_m) ? ({
        auto&& n_p5 = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        ({
        auto bare_p6 = or_(index(n_p5->path_, Nat(0u)), Text::lit(""));
        auto is_ctor_p7 = (crate::check::env::is_upper_text(bare_p6) && (len_text(prism_rtl::deref(n_p5).sigils) == Nat(0u))) && is_ctor_name(env_p0, n_p5);
        (std::move(is_ctor_p7) || (len(n_p5->path_) > Nat(1u))
        ? prism_rtl::more(prism_rtl::rc(BindCtor(env_p0, st_p1, p_p2, n_p5, Array<crate::syntax::Pattern_>{}, t_p3)))
        : prism_rtl::more(prism_rtl::rc(BindName(env_p0, st_p1, n_p5, t_p3))));
    });
    })
        : prism_rtl::is<crate::syntax::PatternKind::PIgnore>(_m) ? prism_rtl::finished(std::tuple{env_p0, st_p1})
        : prism_rtl::is<crate::syntax::PatternKind::PLit>(_m) ? ({
        auto&& l_p8 = prism_rtl::as<crate::syntax::PatternKind::PLit>(_m).a0;
        ({
        auto env_p0_1 = env_p0;
        auto l_p8_2 = l_p8;
        auto p_p2_3 = p_p2;
        auto st_p1_4 = st_p1;
        auto t_p3_5 = t_p3;
        call_then(crate::check::expr::start_infer_lit(env_p0_1, st_p1_4, l_p8_2, false, prism_rtl::deref(p_p2_3).span), [=, t_p3_5 = std::move(t_p3_5)](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_lit_1841) {
        return ({
            auto [lt_p9, st2_pa] = infer_lit_1841;
            call_then(crate::check::types::unify::start_unify(st2_pa, t_p3_5, lt_p9, prism_rtl::deref(p_p2_3).span), [=](crate::check::types::St unify_1892) { return prism_rtl::finished(std::tuple{env_p0_1, unify_1892}); });
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::PatternKind::PNeg>(_m) ? ({
        auto&& l_pb = prism_rtl::as<crate::syntax::PatternKind::PNeg>(_m).a0;
        ({
        auto env_p0_1 = env_p0;
        auto l_pb_2 = l_pb;
        auto p_p2_3 = p_p2;
        auto st_p1_4 = st_p1;
        auto t_p3_5 = t_p3;
        call_then(crate::check::expr::start_infer_lit(env_p0_1, st_p1_4, l_pb_2, true, prism_rtl::deref(p_p2_3).span), [=, t_p3_5 = std::move(t_p3_5)](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_lit_1958) {
        return ({
            auto [lt_pc, st2_pd] = infer_lit_1958;
            call_then(crate::check::types::unify::start_unify(st2_pd, t_p3_5, lt_pc, prism_rtl::deref(p_p2_3).span), [=](crate::check::types::St unify_2008) { return prism_rtl::finished(std::tuple{env_p0_1, unify_2008}); });
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::PatternKind::PUnit>(_m) ? ({
        auto env_p0_1 = env_p0;
        auto p_p2_2 = p_p2;
        auto st_p1_3 = st_p1;
        auto t_p3_4 = t_p3;
        call_then(crate::check::types::unify::start_unify(st_p1_3, t_p3_4, crate::check::types::t_unit(), prism_rtl::deref(p_p2_2).span), [=, env_p0_1 = std::move(env_p0_1)](crate::check::types::St unify_2055) { return prism_rtl::finished(std::tuple{env_p0_1, unify_2055}); });
    })
        : prism_rtl::is<crate::syntax::PatternKind::PNil>(_m) ? ({
        auto [v_pe, st2_pf] = crate::check::types::fresh_var(st_p1, false, Text::lit(""));
        auto env_p0_1 = env_p0;
        auto p_p2_2 = p_p2;
        auto t_p3_3 = t_p3;
        call_then(crate::check::types::unify::start_unify(st2_pf, t_p3_3, crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("?"), prism_rtl::rc(v_pe)}), prism_rtl::deref(p_p2_2).span), [=, env_p0_1 = std::move(env_p0_1)](crate::check::types::St unify_2159) { return prism_rtl::finished(std::tuple{env_p0_1, unify_2159}); });
    })
        : prism_rtl::is<crate::syntax::PatternKind::PCtor>(_m) ? ({
        auto&& n_pg = prism_rtl::as<crate::syntax::PatternKind::PCtor>(_m).a0;
        auto&& args_ph = prism_rtl::as<crate::syntax::PatternKind::PCtor>(_m).a1;
        prism_rtl::more(prism_rtl::rc(BindCtor(env_p0, st_p1, p_p2, n_pg, args_ph, t_p3)));
    })
        : prism_rtl::is<crate::syntax::PatternKind::PRecord>(_m) ? ({
        auto&& n_pi = prism_rtl::as<crate::syntax::PatternKind::PRecord>(_m).a0;
        auto&& fields_pj = prism_rtl::as<crate::syntax::PatternKind::PRecord>(_m).a1;
        auto&& rest_pk = prism_rtl::as<crate::syntax::PatternKind::PRecord>(_m).a2;
        prism_rtl::more(prism_rtl::rc(BindRecord(env_p0, st_p1, p_p2, n_pi, fields_pj, prism_rtl::deref(rest_pk), t_p3)));
    })
        : prism_rtl::is<crate::syntax::PatternKind::PSigil>(_m) ? ({
        auto&& s_pl = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a0;
        auto&& inner_pm = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a1;
        (s_pl == Text::lit("?")) || (s_pl == Text::lit("~"))
        ? ({
        auto [v_po, st2_pp] = crate::check::types::fresh_var(st_p1, false, Text::lit(""));
        auto env_p0_1 = env_p0;
        auto inner_pm_2 = prism_rtl::deref(prism_rtl::deref(inner_pm));
        auto p_p2_3 = p_p2;
        auto refutable_p4_4 = prism_rtl::deref(refutable_p4);
        auto s_pl_5 = s_pl;
        auto t_p3_6 = t_p3;
        call_then(crate::check::types::unify::start_unify(st2_pp, t_p3_6, crate::check::types::Ty(crate::check::types::Ty::TySig{s_pl_5, prism_rtl::rc(v_po)}), prism_rtl::deref(p_p2_3).span), [=, env_p0_1 = std::move(env_p0_1), inner_pm_2 = std::move(inner_pm_2), refutable_p4_4 = std::move(refutable_p4_4)](crate::check::types::St unify_2449) {
        return ({
            auto st3_pn = unify_2449;
            (prism_rtl::more(prism_rtl::rc(BindPattern(env_p0_1, st3_pn, inner_pm_2, v_po, refutable_p4_4))));
        });
    });
    })
        : ({
        auto [v_pr, st2_ps] = crate::check::types::fresh_var(st_p1, false, Text::lit(""));
        auto env_p0_1 = env_p0;
        auto inner_pm_2 = prism_rtl::deref(prism_rtl::deref(inner_pm));
        auto p_p2_3 = p_p2;
        auto refutable_p4_4 = prism_rtl::deref(refutable_p4);
        auto s_pl_5 = s_pl;
        auto t_p3_6 = t_p3;
        call_then(crate::check::types::unify::start_unify(st2_ps, t_p3_6, crate::check::types::with_marks(s_pl_5, v_pr, prism_rtl::deref(env_p0_1).scope), prism_rtl::deref(p_p2_3).span), [=, inner_pm_2 = std::move(inner_pm_2), refutable_p4_4 = std::move(refutable_p4_4)](crate::check::types::St unify_2626) {
        return ({
            auto st3_pq = unify_2626;
            (prism_rtl::more(prism_rtl::rc(BindPattern(env_p0_1, st3_pq, inner_pm_2, v_pr, refutable_p4_4))));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::PatternKind::PTuple>(_m) ? ({
        auto&& ps_pt = prism_rtl::as<crate::syntax::PatternKind::PTuple>(_m).a0;
        ({
        auto [vs_p13, st2_p14] = fold(ps_pt, std::tuple{Array<crate::check::types::Ty>{}, st_p1}, [&](const std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>& _p0, const crate::syntax::Pattern_& _p1) {
            auto&& acc_pv = std::get<0>(_p0);
            auto&& s_p10 = std::get<1>(_p0);
            return ({
                auto [v_p11, s2_p12] = crate::check::types::fresh_var(s_p10, false, Text::lit(""));
                std::tuple{crate::prelude::push(acc_pv, v_p11), s2_p12};
            });
        });
        auto env_p0_1 = env_p0;
        auto p_p2_2 = p_p2;
        auto ps_pt_3 = ps_pt;
        auto refutable_p4_4 = prism_rtl::deref(refutable_p4);
        auto t_p3_5 = t_p3;
        call_then(crate::check::types::unify::start_unify(st2_p14, t_p3_5, crate::check::types::Ty(crate::check::types::Ty::TyTuple{vs_p13}), prism_rtl::deref(p_p2_2).span), [=, env_p0_1 = std::move(env_p0_1), ps_pt_3 = std::move(ps_pt_3), refutable_p4_4 = std::move(refutable_p4_4)](crate::check::types::St unify_2918) {
        return ({
            auto st3_pu = unify_2918;
            fold_job(crate::check::errors::range0(len(ps_pt_3)), std::tuple{env_p0_1, st3_pu}, ({
            auto ps_pt_3_6 = ps_pt_3;
            auto p_p2_2_6 = p_p2_2;
            auto vs_p13_6 = vs_p13;
            auto refutable_p4_4_7 = refutable_p4_4;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>>(std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=, ps_pt_3_6 = std::move(ps_pt_3_6), p_p2_2_6 = std::move(p_p2_2_6), vs_p13_6 = std::move(vs_p13_6), refutable_p4_4_7 = std::move(refutable_p4_4_7)](std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto ps_pt_3_6_7 = ps_pt_3_6;
                auto p_p2_2_6_7 = p_p2_2_6;
                auto vs_p13_6_7 = vs_p13_6;
                auto refutable_p4_4_7_7 = refutable_p4_4_7;
                entered(once_job([=, ps_pt_3_6_7 = std::move(ps_pt_3_6_7), p_p2_2_6_7 = std::move(p_p2_2_6_7), vs_p13_6_7 = std::move(vs_p13_6_7), refutable_p4_4_7_7 = std::move(refutable_p4_4_7_7)]() {
                return ({
                    auto [en_p15, s_p16] = p0;
                    auto i_p17 = p1;
                    (prism_rtl::more(prism_rtl::rc(BindPattern(en_p15, s_p16, or_(index(ps_pt_3_6_7, i_p17), crate::syntax::Pattern_{.kind = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PIgnore{})), .span = prism_rtl::deref(p_p2_2_6_7).span}), or_(index(vs_p13_6_7, i_p17), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), refutable_p4_4_7_7))));
                });
            }));
            });
        }));
        }))->cycle();
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::PatternKind::PArray>(_m) ? ({
        auto&& ps_p18 = prism_rtl::as<crate::syntax::PatternKind::PArray>(_m).a0;
        ({
        auto [v_p1a, st2_p1b] = crate::check::types::fresh_var(st_p1, false, Text::lit(""));
        auto env_p0_1 = env_p0;
        auto p_p2_2 = p_p2;
        auto ps_p18_3 = ps_p18;
        auto refutable_p4_4 = prism_rtl::deref(refutable_p4);
        auto t_p3_5 = t_p3;
        call_then(crate::check::types::unify::start_unify(st2_p1b, t_p3_5, crate::check::types::Ty(crate::check::types::Ty::TyArray{prism_rtl::rc(v_p1a)}), prism_rtl::deref(p_p2_2).span), [=, env_p0_1 = std::move(env_p0_1), ps_p18_3 = std::move(ps_p18_3), refutable_p4_4 = std::move(refutable_p4_4)](crate::check::types::St unify_3192) {
        return ({
            auto st3_p19 = unify_3192;
            fold_job(ps_p18_3, std::tuple{env_p0_1, st3_p19}, ({
            auto v_p1a_6 = v_p1a;
            auto refutable_p4_4_7 = refutable_p4_4;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>>(std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, crate::syntax::Pattern_>)>>(prism_rtl::rc([=, v_p1a_6 = std::move(v_p1a_6), refutable_p4_4_7 = std::move(refutable_p4_4_7)](std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, crate::syntax::Pattern_> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto v_p1a_6_7 = v_p1a_6;
                auto refutable_p4_4_7_7 = refutable_p4_4_7;
                entered(once_job([=, v_p1a_6_7 = std::move(v_p1a_6_7), refutable_p4_4_7_7 = std::move(refutable_p4_4_7_7)]() {
                return ({
                    auto [en_p1c, s_p1d] = p0;
                    auto q_p1e = p1;
                    (prism_rtl::more(prism_rtl::rc(BindPattern(en_p1c, s_p1d, q_p1e, v_p1a_6_7, refutable_p4_4_7_7))));
                });
            }));
            });
        }));
        }))->cycle();
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::PatternKind::PGroup>(_m) ? ({
        auto&& q_p1f = prism_rtl::as<crate::syntax::PatternKind::PGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(BindPattern(env_p0, st_p1, prism_rtl::deref(prism_rtl::deref(q_p1f)), t_p3, prism_rtl::deref(refutable_p4))));
    })
        : prism_rtl::is<crate::syntax::PatternKind::PFamily>(_m) ? ({
        auto&& q_p1g = prism_rtl::as<crate::syntax::PatternKind::PFamily>(_m).a0;
        prism_rtl::more(prism_rtl::rc(BindFamily(env_p0, st_p1, crate::check::env::dotted(q_p1g->path_), t_p3, prism_rtl::deref(p_p2).span)));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start BindPattern, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>> start_bind_pattern(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Pattern_ p_p2, crate::check::types::Ty t_p3, bool refutable_p4) {
    return prism_rtl::make_rc<BindPattern>(env_p0, st_p1, p_p2, t_p3, refutable_p4);
}


/// IsCtorName: fn Env, SName -> Bool
bool is_ctor_name(const crate::check::expr::Env& env_p0, const crate::syntax::SName& n_p1) {
    auto&& _qk_o2 = crate::check::env::names::resolve_value(env_p0.g, env_p0.home, n_p1);
    auto&& qk_o2 = std::get<0>(_qk_o2);
    if (prism_rtl::is_some(qk_o2)) {
        auto&& qk_p3 = prism_rtl::some_of(qk_o2);
        return crate::check::env::has_key(prism_rtl::deref(env_p0.g).ctors, qk_p3);
    }
    if (prism_rtl::is_none(qk_o2)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// BindName: unbounded fn Env, St, SName, Ty -> ((Env, St))
std::tuple<crate::check::expr::Env, crate::check::types::St> bind_name(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::SName& n_p2, const crate::check::types::Ty& t_p3) {
    auto name_p4 = crate::check::env::sname_key(n_p2);
    return crate::check::types::has_text(env_p0.pending, name_p4)
        ? ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::check::expr::Env, crate::check::types::St>> _v;
        auto&& _m = crate::prelude::get(env_p0.locals, name_p4);
        if (prism_rtl::is_some(_m)) {
            auto&& sc_p5 = prism_rtl::some_of(_m);
            _v.set(({
                auto [ok_p8, st1_p9] = crate::check::types::unify::try_unify(st_p1, prism_rtl::deref(sc_p5).ty, t_p3, n_p2.span);
                auto marks_agree_p6 = (crate::check::types::stack_of(st_p1, t_p3) == crate::check::expr::lets::type_marks(n_p2.sigils)) || crate::check::types::is_flex_var(st_p1, t_p3);
                auto st_a_p7 = ok_p8
                    ? st1_p9
                    : std::move(marks_agree_p6)
                    ? crate::check::types::unify::unify(st_p1, prism_rtl::deref(sc_p5).ty, t_p3, n_p2.span)
                    : crate::check::types::recording::err_fix(st_p1, Text::lit("mark-stack"), n_p2.span, prism_rtl::cat("`", name_p4, "` has type `", crate::check::types::show_ty(st_p1, t_p3), "`, whose stack is `", crate::check::types::stack_of(st_p1, t_p3), "`; the name shows `", crate::check::expr::lets::type_marks(n_p2.sigils), "`"), prism_rtl::cat("rename to `", crate::check::expr::lets::ref_mark(n_p2.sigils), crate::check::types::stack_of(st_p1, t_p3), crate::syntax::lexer::chars::drop_prefix(name_p4, n_p2.sigils), "`"));
                (crate::check::expr::bind_local_id(env_p0, crate::check::types::recording::note_binder(st_a_p7, n_p2.span, name_p4, t_p3), name_p4, n_p2.span));
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(bind_fresh(env_p0, st_p1, n_p2, t_p3));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    })
        : bind_fresh(env_p0, st_p1, n_p2, t_p3);
}


prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St>> BindName::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& n_p2 = this->n_p2;
    const auto& t_p3 = this->t_p3;
    auto name_p4 = crate::check::env::sname_key(n_p2);
    return crate::check::types::has_text(prism_rtl::deref(env_p0).pending, name_p4)
        ? ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(env_p0).locals, name_p4);
        prism_rtl::is_some(_m) ? ({
        auto&& sc_p5 = prism_rtl::some_of(_m);
        ({
        auto env_p0_1 = env_p0;
        auto n_p2_2 = n_p2;
        auto st_p1_3 = st_p1;
        auto t_p3_4 = t_p3;
        call_then(crate::check::types::unify::start_try_unify(st_p1_3, prism_rtl::deref(sc_p5).ty, t_p3_4, prism_rtl::deref(n_p2_2).span), [=, env_p0_1 = std::move(env_p0_1)](std::tuple<bool, crate::check::types::St> try_unify_3987) {
        return ({
            auto [ok_p8, st1_p9] = try_unify_3987;
            call_then(crate::check::types::start_stack_of(st_p1_3, t_p3_4), [=](Text stack_of_4051) {
            return ({
                auto marks_agree_p6 = (stack_of_4051 == crate::check::expr::lets::type_marks(prism_rtl::deref(n_p2_2).sigils)) || crate::check::types::is_flex_var(st_p1_3, t_p3_4);
                auto st_a_p7 = ok_p8
                    ? st1_p9
                    : std::move(marks_agree_p6)
                    ? crate::check::types::unify::unify(st_p1_3, prism_rtl::deref(sc_p5).ty, t_p3_4, prism_rtl::deref(n_p2_2).span)
                    : crate::check::types::recording::err_fix(st_p1_3, Text::lit("mark-stack"), prism_rtl::deref(n_p2_2).span, prism_rtl::cat("`", name_p4, "` has type `", crate::check::types::show_ty(st_p1_3, t_p3_4), "`, whose stack is `", crate::check::types::stack_of(st_p1_3, t_p3_4), "`; the name shows `", crate::check::expr::lets::type_marks(prism_rtl::deref(n_p2_2).sigils), "`"), prism_rtl::cat("rename to `", crate::check::expr::lets::ref_mark(prism_rtl::deref(n_p2_2).sigils), crate::check::types::stack_of(st_p1_3, t_p3_4), crate::syntax::lexer::chars::drop_prefix(name_p4, prism_rtl::deref(n_p2_2).sigils), "`"));
                (prism_rtl::finished(crate::check::expr::bind_local_id(env_p0_1, crate::check::types::recording::note_binder(st_a_p7, prism_rtl::deref(n_p2_2).span, name_p4, t_p3_4), name_p4, prism_rtl::deref(n_p2_2).span)));
            });
        });
        });
    });
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::more(prism_rtl::rc(BindFresh(env_p0, st_p1, n_p2, t_p3)))
        : throw prism_rtl::Panic("no arm matched");
    })
        : prism_rtl::more(prism_rtl::rc(BindFresh(env_p0, st_p1, n_p2, t_p3)));
}


/// `Start BindName, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>> start_bind_name(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::SName n_p2, crate::check::types::Ty t_p3) {
    return prism_rtl::make_rc<BindName>(env_p0, st_p1, n_p2, t_p3);
}


/// BindFresh: unbounded fn Env, St, SName, Ty -> ((Env, St))
std::tuple<crate::check::expr::Env, crate::check::types::St> bind_fresh(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::SName& n_p2, const crate::check::types::Ty& t_p3) {
    return bind_fresh_marked(env_p0, st_p1, n_p2, crate::check::expr::lets::type_marks(n_p2.sigils), t_p3);
}


prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St>> BindFresh::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& n_p2 = this->n_p2;
    const auto& t_p3 = this->t_p3;
    return prism_rtl::more(prism_rtl::rc(BindFreshMarked(env_p0, st_p1, n_p2, crate::check::expr::lets::type_marks(prism_rtl::deref(n_p2).sigils), t_p3)));
}


/// `Start BindFresh, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>> start_bind_fresh(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::SName n_p2, crate::check::types::Ty t_p3) {
    return prism_rtl::make_rc<BindFresh>(env_p0, st_p1, n_p2, t_p3);
}


/// BindFreshMarked: unbounded fn Env, St, SName, Text, Ty -> ((Env, St))
std::tuple<crate::check::expr::Env, crate::check::types::St> bind_fresh_marked(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::SName& n_p2, const Text& marks_p3, const crate::check::types::Ty& t_p4) {
    auto name_p5 = crate::check::env::sname_key(n_p2);
    auto [v_p8, st2_p9] = crate::check::types::fresh_var(st_p1, true, name_p5);
    auto [rw_pa, st3_pb] = crate::check::types::recording::fresh_row(st2_p9, Array<Text>{});
    auto marked_p6 = crate::check::types::with_marks(marks_p3, v_p8, rw_pa);
    auto [ok_pc, st4_pd] = crate::check::types::unify::try_unify(st3_pb, t_p4, marked_p6, n_p2.span);
    auto st5_p7 = ok_pc
        ? st4_pd
        : ({
        auto stack_pe = crate::check::types::stack_of(st3_pb, t_p4);
        (crate::check::types::recording::err_fix(st3_pb, Text::lit("mark-stack"), n_p2.span, prism_rtl::cat("`", name_p5, "` has type `", crate::check::types::show_ty(st3_pb, t_p4), "`, whose stack is `", stack_pe, "`; the name shows `", marks_p3, "`"), prism_rtl::cat("rename to `", crate::check::expr::lets::ref_mark(n_p2.sigils), stack_pe, crate::syntax::lexer::chars::drop_prefix(name_p5, n_p2.sigils), "`")));
    });
    return crate::check::expr::bind_local_id(crate::check::expr::with_local(env_p0, name_p5, crate::check::types::schemes::mono(t_p4)), crate::check::types::recording::note_binder(st5_p7, n_p2.span, name_p5, t_p4), name_p5, n_p2.span);
}


prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St>> BindFreshMarked::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& n_p2 = this->n_p2;
    const auto& marks_p3 = this->marks_p3;
    const auto& t_p4 = this->t_p4;
    auto name_p5 = crate::check::env::sname_key(n_p2);
    auto [v_p8, st2_p9] = crate::check::types::fresh_var(st_p1, true, name_p5);
    auto [rw_pa, st3_pb] = crate::check::types::recording::fresh_row(st2_p9, Array<Text>{});
    auto marked_p6 = crate::check::types::with_marks(marks_p3, v_p8, rw_pa);
    auto env_p0_1 = env_p0;
    auto marks_p3_2 = marks_p3;
    auto n_p2_3 = n_p2;
    auto t_p4_4 = t_p4;
    return call_then(crate::check::types::unify::start_try_unify(st3_pb, t_p4_4, marked_p6, prism_rtl::deref(n_p2_3).span), [=](std::tuple<bool, crate::check::types::St> try_unify_5140) {
        return ({
            auto [ok_pc, st4_pd] = try_unify_5140;
            auto st5_p7 = ok_pc
                ? st4_pd
                : ({
                auto stack_pe = crate::check::types::stack_of(st3_pb, t_p4_4);
                (crate::check::types::recording::err_fix(st3_pb, Text::lit("mark-stack"), prism_rtl::deref(n_p2_3).span, prism_rtl::cat("`", name_p5, "` has type `", crate::check::types::show_ty(st3_pb, t_p4_4), "`, whose stack is `", stack_pe, "`; the name shows `", marks_p3_2, "`"), prism_rtl::cat("rename to `", crate::check::expr::lets::ref_mark(prism_rtl::deref(n_p2_3).sigils), stack_pe, crate::syntax::lexer::chars::drop_prefix(name_p5, prism_rtl::deref(n_p2_3).sigils), "`")));
            });
            (prism_rtl::finished(crate::check::expr::bind_local_id(crate::check::expr::with_local(env_p0_1, name_p5, crate::check::types::schemes::mono(t_p4_4)), crate::check::types::recording::note_binder(st5_p7, prism_rtl::deref(n_p2_3).span, name_p5, t_p4_4), name_p5, prism_rtl::deref(n_p2_3).span)));
        });
    });
}


/// `Start BindFreshMarked, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>> start_bind_fresh_marked(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::SName n_p2, Text marks_p3, crate::check::types::Ty t_p4) {
    return prism_rtl::make_rc<BindFreshMarked>(env_p0, st_p1, n_p2, marks_p3, t_p4);
}


/// BindField: unbounded fn Env, St, Pattern, Ty, Bool -> ((Env, St))
std::tuple<crate::check::expr::Env, crate::check::types::St> bind_field(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Pattern_& p_p2, const crate::check::types::Ty& ft_p3, const bool& snapshot_p4) {
    auto&& _m = crate::check::types::recording::walk(st_p1, ft_p3);
    if (prism_rtl::is<crate::check::types::Ty::TySig>(_m)) {
        auto&& s_p5 = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a0;
        auto&& level_p6 = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a1;
        if (snapshot_p4 && (s_p5 == Text::lit("$"))) {
            return bind_level(env_p0, st_p1, p_p2, prism_rtl::deref(level_p6));
        }
    }
    {
        return bind_pattern(env_p0, st_p1, p_p2, ft_p3, true);
    }
}


prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St>> BindField::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& p_p2 = this->p_p2;
    const auto& ft_p3 = this->ft_p3;
    const auto& snapshot_p4 = this->snapshot_p4;
    auto env_p0_1 = env_p0;
    auto ft_p3_2 = ft_p3;
    auto p_p2_3 = p_p2;
    auto snapshot_p4_4 = prism_rtl::deref(snapshot_p4);
    auto st_p1_5 = st_p1;
    return call_then(crate::check::types::recording::start_walk(st_p1_5, ft_p3_2), [=](crate::check::types::Ty walk_6089) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TySig>(walk_6089) && ({
            auto&& s_p5 = prism_rtl::as<crate::check::types::Ty::TySig>(walk_6089).a0;
            auto&& level_p6 = prism_rtl::as<crate::check::types::Ty::TySig>(walk_6089).a1;
            (snapshot_p4_4 && (s_p5 == Text::lit("$")));
        }) ? ({
            auto&& s_p5 = prism_rtl::as<crate::check::types::Ty::TySig>(walk_6089).a0;
            auto&& level_p6 = prism_rtl::as<crate::check::types::Ty::TySig>(walk_6089).a1;
            prism_rtl::more(prism_rtl::rc(BindLevel(env_p0_1, st_p1_5, p_p2_3, prism_rtl::deref(level_p6))));
        })
            : prism_rtl::more(prism_rtl::rc(BindPattern(env_p0_1, st_p1_5, p_p2_3, ft_p3_2, true)));
        });
    });
}


/// `Start BindField, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>> start_bind_field(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Pattern_ p_p2, crate::check::types::Ty ft_p3, bool snapshot_p4) {
    return prism_rtl::make_rc<BindField>(env_p0, st_p1, p_p2, ft_p3, snapshot_p4);
}


/// BindLevel: unbounded fn Env, St, Pattern, Ty -> ((Env, St))
std::tuple<crate::check::expr::Env, crate::check::types::St> bind_level(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Pattern_& p_p2, const crate::check::types::Ty& level_p3) {
    auto&& _m = prism_rtl::deref(p_p2.kind);
    if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
        auto&& n_p4 = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        return crate::syntax::lexer::chars::has_prefix(prism_rtl::deref(n_p4).sigils, Text::lit("$")) && (len(n_p4->path_) == Nat(1u))
            ? bind_fresh_marked(env_p0, st_p1, n_p4, crate::syntax::lexer::chars::after_first(prism_rtl::deref(n_p4).sigils), level_p3)
            : bind_pattern(env_p0, st_p1, p_p2, level_p3, true);
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PGroup>(_m)) {
        auto&& q_p5 = prism_rtl::as<crate::syntax::PatternKind::PGroup>(_m).a0;
        return bind_level(env_p0, st_p1, prism_rtl::deref(prism_rtl::deref(q_p5)), level_p3);
    }
    {
        return bind_pattern(env_p0, st_p1, p_p2, level_p3, true);
    }
}


prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St>> BindLevel::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& p_p2 = this->p_p2;
    const auto& level_p3 = this->level_p3;
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(p_p2).kind);
        prism_rtl::is<crate::syntax::PatternKind::PName>(_m) ? ({
        auto&& n_p4 = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        crate::syntax::lexer::chars::has_prefix(prism_rtl::deref(n_p4).sigils, Text::lit("$")) && (len(n_p4->path_) == Nat(1u))
        ? prism_rtl::more(prism_rtl::rc(BindFreshMarked(env_p0, st_p1, n_p4, crate::syntax::lexer::chars::after_first(prism_rtl::deref(n_p4).sigils), level_p3)))
        : prism_rtl::more(prism_rtl::rc(BindPattern(env_p0, st_p1, p_p2, level_p3, true)));
    })
        : prism_rtl::is<crate::syntax::PatternKind::PGroup>(_m) ? ({
        auto&& q_p5 = prism_rtl::as<crate::syntax::PatternKind::PGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(BindLevel(env_p0, st_p1, prism_rtl::deref(prism_rtl::deref(q_p5)), level_p3)));
    })
        : prism_rtl::more(prism_rtl::rc(BindPattern(env_p0, st_p1, p_p2, level_p3, true)));
    });
}


/// `Start BindLevel, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>> start_bind_level(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Pattern_ p_p2, crate::check::types::Ty level_p3) {
    return prism_rtl::make_rc<BindLevel>(env_p0, st_p1, p_p2, level_p3);
}


/// BindCtor: unbounded fn Env, St, Pattern, SName, [Pattern], Ty -> ((Env, St))
std::tuple<crate::check::expr::Env, crate::check::types::St> bind_ctor(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Pattern_& p_p2, const crate::syntax::SName& n_p3, const Array<crate::syntax::Pattern_>& args_p4, const crate::check::types::Ty& t_p5) {
    auto [qk_o6, why_p7] = crate::check::env::names::resolve_value(env_p0.g, env_p0.home, n_p3);
    if (prism_rtl::is_none(qk_o6)) {
        return std::tuple{env_p0, crate::check::types::recording::err(st_p1, Text::lit("unknown-name"), n_p3.span, prism_rtl::cat("no constructor `", crate::check::env::sname_key(n_p3), "`"))};
    }
    if (prism_rtl::is_some(qk_o6)) {
        auto&& qk_p8 = prism_rtl::some_of(qk_o6);
        return why_p7 == Text::lit("tag")
            ? bind_tag_pattern(env_p0, st_p1, p_p2, qk_p8, Array<crate::syntax::FieldPat>{}, true, t_p5)
            : ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<crate::check::expr::Env, crate::check::types::St>> _v;
            auto&& _m = crate::prelude::get(prism_rtl::deref(env_p0.g).ctors, qk_p8);
            if (prism_rtl::is_none(_m)) {
                _v.set(std::tuple{env_p0, crate::check::types::recording::err(st_p1, Text::lit("unknown-name"), n_p3.span, prism_rtl::cat("`", crate::check::env::sname_key(n_p3), "` is not a constructor"))});
                goto _done;
            }
            if (prism_rtl::is_some(_m)) {
                auto&& c_p9 = prism_rtl::some_of(_m);
                _v.set(({
                    auto [self_pb, st1_pc, inst_pd] = crate::check::types::schemes::instantiate_with(st_p1, crate::check::types::Scheme{.qs = prism_rtl::deref(c_p9).params, .plain_qs = Array<Text>{}, .rqs = Array<Text>{}, .cqs = Array<Text>{}, .cjoins = Array<std::tuple<Text, Text>>{}, .bounds = Array<std::tuple<Text, Text>>{}, .ty = prism_rtl::deref(c_p9).ty}, p_p2.span, Array<crate::check::types::Ty>{});
                    auto st2_pa = crate::check::types::unify::unify(st1_pc, t_p5, self_pb, p_p2.span);
                    (len(args_p4) != len(c_p9->args)) && (!((len(args_p4) == Nat(1u)) && (len(c_p9->args) > Nat(1u))))
                    ? std::tuple{env_p0, crate::check::types::recording::err(st2_pa, Text::lit("mismatch"), p_p2.span, prism_rtl::cat("`", crate::check::types::bare_name(prism_rtl::deref(c_p9).name), "` takes ", crate::check::errors::count_word(len(c_p9->args)), " argument", len(c_p9->args) == Nat(1u) ? Text::lit("") : Text::lit("s"), "; this pattern gives ", crate::check::errors::count_word(len(args_p4))))}
                    : run_to_end(fold_job(crate::check::errors::range0(len(args_p4)), std::tuple{env_p0, st2_pa}, ({
                    auto args_p4_1 = args_p4;
                    auto p_p2_2 = p_p2;
                    auto inst_pd_3 = inst_pd;
                    auto c_p9_4 = c_p9;
                    static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>>(std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=, args_p4_1 = std::move(args_p4_1), p_p2_2 = std::move(p_p2_2), inst_pd_3 = std::move(inst_pd_3), c_p9_4 = std::move(c_p9_4)](std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto args_p4_1_5 = args_p4_1;
                        auto p_p2_2_5 = p_p2_2;
                        auto inst_pd_3_5 = inst_pd_3;
                        auto c_p9_4_5 = c_p9_4;
                        entered(once_job([=, args_p4_1_5 = std::move(args_p4_1_5), p_p2_2_5 = std::move(p_p2_2_5), inst_pd_3_5 = std::move(inst_pd_3_5), c_p9_4_5 = std::move(c_p9_4_5)]() {
                        return ({
                            auto [en_pe, s_pf] = p0;
                            auto i_pg = p1;
                            call_then(crate::check::types::schemes::start_subst_q(inst_pd_3_5, or_(index(c_p9_4_5->args, i_pg), crate::check::types::Ty(crate::check::types::Ty::TyErr{}))), [=](crate::check::types::Ty subst_q_7811) { return prism_rtl::more(prism_rtl::rc(BindPattern(en_pe, s_pf, or_(index(args_p4_1_5, i_pg), crate::syntax::Pattern_{.kind = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PIgnore{})), .span = p_p2_2_5.span}), subst_q_7811, true))); });
                        });
                    }));
                    });
                }));
                })));
                }));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St>> BindCtor::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& p_p2 = this->p_p2;
    const auto& n_p3 = this->n_p3;
    const auto& args_p4 = this->args_p4;
    const auto& t_p5 = this->t_p5;
    auto [qk_o6, why_p7] = crate::check::env::names::resolve_value(prism_rtl::deref(env_p0).g, prism_rtl::deref(env_p0).home, n_p3);
    return ({
        prism_rtl::is_none(qk_o6) ? prism_rtl::finished(std::tuple{env_p0, crate::check::types::recording::err(st_p1, Text::lit("unknown-name"), prism_rtl::deref(n_p3).span, prism_rtl::cat("no constructor `", crate::check::env::sname_key(n_p3), "`"))})
        : prism_rtl::is_some(qk_o6) ? ({
        auto&& qk_p8 = prism_rtl::some_of(qk_o6);
        why_p7 == Text::lit("tag")
        ? prism_rtl::more(prism_rtl::rc(BindTagPattern(env_p0, st_p1, p_p2, qk_p8, Array<crate::syntax::FieldPat>{}, true, t_p5)))
        : ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(prism_rtl::deref(env_p0).g).ctors, qk_p8);
        prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{env_p0, crate::check::types::recording::err(st_p1, Text::lit("unknown-name"), prism_rtl::deref(n_p3).span, prism_rtl::cat("`", crate::check::env::sname_key(n_p3), "` is not a constructor"))})
        : prism_rtl::is_some(_m) ? ({
        auto&& c_p9 = prism_rtl::some_of(_m);
        ({
        auto args_p4_1 = args_p4;
        auto env_p0_2 = env_p0;
        auto p_p2_3 = p_p2;
        auto st_p1_4 = st_p1;
        auto t_p5_5 = t_p5;
        call_then(crate::check::types::schemes::start_instantiate_with(st_p1_4, crate::check::types::Scheme{.qs = prism_rtl::deref(c_p9).params, .plain_qs = Array<Text>{}, .rqs = Array<Text>{}, .cqs = Array<Text>{}, .cjoins = Array<std::tuple<Text, Text>>{}, .bounds = Array<std::tuple<Text, Text>>{}, .ty = prism_rtl::deref(c_p9).ty}, prism_rtl::deref(p_p2_3).span, Array<crate::check::types::Ty>{}), [=, args_p4_1 = std::move(args_p4_1), env_p0_2 = std::move(env_p0_2), t_p5_5 = std::move(t_p5_5)](std::tuple<crate::check::types::Ty, crate::check::types::St, crate::check::types::schemes::Inst> instantiate_with_7174) {
        return ({
            auto [self_pb, st1_pc, inst_pd] = instantiate_with_7174;
            call_then(crate::check::types::unify::start_unify(st1_pc, t_p5_5, self_pb, prism_rtl::deref(p_p2_3).span), [=](crate::check::types::St unify_7329) {
            return ({
                auto st2_pa = unify_7329;
                (len(args_p4_1) != len(c_p9->args)) && (!((len(args_p4_1) == Nat(1u)) && (len(c_p9->args) > Nat(1u))))
                ? prism_rtl::finished(std::tuple{env_p0_2, crate::check::types::recording::err(st2_pa, Text::lit("mismatch"), prism_rtl::deref(p_p2_3).span, prism_rtl::cat("`", crate::check::types::bare_name(prism_rtl::deref(c_p9).name), "` takes ", crate::check::errors::count_word(len(c_p9->args)), " argument", len(c_p9->args) == Nat(1u) ? Text::lit("") : Text::lit("s"), "; this pattern gives ", crate::check::errors::count_word(len(args_p4_1))))})
                : fold_job(crate::check::errors::range0(len(args_p4_1)), std::tuple{env_p0_2, st2_pa}, ({
                auto args_p4_1_6 = args_p4_1;
                auto p_p2_3_6 = p_p2_3;
                auto inst_pd_6 = inst_pd;
                auto c_p9_7 = c_p9;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>>(std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=, args_p4_1_6 = std::move(args_p4_1_6), p_p2_3_6 = std::move(p_p2_3_6), inst_pd_6 = std::move(inst_pd_6), c_p9_7 = std::move(c_p9_7)](std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto args_p4_1_6_8 = args_p4_1_6;
                    auto p_p2_3_6_8 = p_p2_3_6;
                    auto inst_pd_6_8 = inst_pd_6;
                    auto c_p9_7_8 = c_p9_7;
                    entered(once_job([=, args_p4_1_6_8 = std::move(args_p4_1_6_8), p_p2_3_6_8 = std::move(p_p2_3_6_8), inst_pd_6_8 = std::move(inst_pd_6_8), c_p9_7_8 = std::move(c_p9_7_8)]() {
                    return ({
                        auto [en_pe, s_pf] = p0;
                        auto i_pg = p1;
                        call_then(crate::check::types::schemes::start_subst_q(inst_pd_6_8, or_(index(c_p9_7_8->args, i_pg), crate::check::types::Ty(crate::check::types::Ty::TyErr{}))), [=](crate::check::types::Ty subst_q_7811) { return prism_rtl::more(prism_rtl::rc(BindPattern(en_pe, s_pf, or_(index(args_p4_1_6_8, i_pg), crate::syntax::Pattern_{.kind = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PIgnore{})), .span = prism_rtl::deref(p_p2_3_6_8).span}), subst_q_7811, true))); });
                    });
                }));
                });
            }));
            }))->cycle();
            });
        });
        });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start BindCtor, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>> start_bind_ctor(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Pattern_ p_p2, crate::syntax::SName n_p3, Array<crate::syntax::Pattern_> args_p4, crate::check::types::Ty t_p5) {
    return prism_rtl::make_rc<BindCtor>(env_p0, st_p1, p_p2, n_p3, args_p4, t_p5);
}


/// BindRecord: unbounded fn Env, St, Pattern, SName, [FieldPat], Bool, Ty -> ((Env, St))
std::tuple<crate::check::expr::Env, crate::check::types::St> bind_record(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Pattern_& p_p2, const crate::syntax::SName& n_p3, const Array<crate::syntax::FieldPat>& fields_p4, const bool& rest_p5, const crate::check::types::Ty& t_p6) {
    auto [qk_o7, why_p8] = crate::check::env::names::resolve_value(env_p0.g, env_p0.home, n_p3);
    if (prism_rtl::is_none(qk_o7)) {
        return std::tuple{env_p0, crate::check::types::recording::err(st_p1, Text::lit("unknown-name"), n_p3.span, prism_rtl::cat("no record or tag `", crate::check::env::sname_key(n_p3), "`"))};
    }
    if (prism_rtl::is_some(qk_o7)) {
        auto&& qk_p9 = prism_rtl::some_of(qk_o7);
        return why_p8 == Text::lit("tag")
            ? bind_tag_pattern(env_p0, st_p1, p_p2, qk_p9, fields_p4, rest_p5, t_p6)
            : ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<crate::check::expr::Env, crate::check::types::St>> _v;
            auto&& _m = crate::prelude::get(prism_rtl::deref(env_p0.g).ctors, qk_p9);
            if (prism_rtl::is_none(_m)) {
                _v.set(std::tuple{env_p0, crate::check::types::recording::err(st_p1, Text::lit("unknown-name"), n_p3.span, prism_rtl::cat("`", crate::check::env::sname_key(n_p3), "` is not a record"))});
                goto _done;
            }
            if (prism_rtl::is_some(_m)) {
                auto&& c_pa = prism_rtl::some_of(_m);
                _v.set(({
                    auto [self_pc, st1_pd, inst_pe] = crate::check::types::schemes::instantiate_with(st_p1, crate::check::types::Scheme{.qs = prism_rtl::deref(c_pa).params, .plain_qs = Array<Text>{}, .rqs = Array<Text>{}, .cqs = Array<Text>{}, .cjoins = Array<std::tuple<Text, Text>>{}, .bounds = Array<std::tuple<Text, Text>>{}, .ty = prism_rtl::deref(c_pa).ty}, p_p2.span, Array<crate::check::types::Ty>{});
                    auto st2_pb = crate::check::types::unify::unify(st1_pd, t_p6, self_pc, p_p2.span);
                    run_to_end(fold_job(crate::check::errors::range0(len(fields_p4)), std::tuple{env_p0, st2_pb}, ({
                    auto fields_p4_1 = fields_p4;
                    auto p_p2_2 = p_p2;
                    auto c_pa_3 = c_pa;
                    auto inst_pe_4 = inst_pe;
                    static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>>(std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=, fields_p4_1 = std::move(fields_p4_1), p_p2_2 = std::move(p_p2_2), c_pa_3 = std::move(c_pa_3), inst_pe_4 = std::move(inst_pe_4)](std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto fields_p4_1_5 = fields_p4_1;
                        auto p_p2_2_5 = p_p2_2;
                        auto c_pa_3_5 = c_pa_3;
                        auto inst_pe_4_5 = inst_pe_4;
                        entered(once_job([=, fields_p4_1_5 = std::move(fields_p4_1_5), p_p2_2_5 = std::move(p_p2_2_5), c_pa_3_5 = std::move(c_pa_3_5), inst_pe_4_5 = std::move(inst_pe_4_5)]() {
                        return ({
                            auto [en_pf, s_pg] = p0;
                            auto i_ph = p1;
                            ({
                            auto fp_pi = or_(index(fields_p4_1_5, i_ph), crate::syntax::FieldPat{.name = std::optional<crate::syntax::Ident>{}, .pattern = crate::syntax::Pattern_{.kind = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PIgnore{})), .span = p_p2_2_5.span}, .span = p_p2_2_5.span});
                            auto fname_pj = field_pat_name(fp_pi, prism_rtl::deref(c_pa_3_5).fields, i_ph);
                            ({
                            auto&& _m = crate::check::expr::operators::index_of(prism_rtl::deref(c_pa_3_5).fields, fname_pj);
                            prism_rtl::is_some(_m) ? ({
                            auto&& j_pk = prism_rtl::some_of(_m);
                            call_then(crate::check::types::schemes::start_subst_q(inst_pe_4_5, or_(index(c_pa_3_5->args, j_pk), crate::check::types::Ty(crate::check::types::Ty::TyErr{}))), [=](crate::check::types::Ty subst_q_9164) { return prism_rtl::more(prism_rtl::rc(BindPattern(en_pf, s_pg, prism_rtl::deref(fp_pi).pattern, subst_q_9164, true))); });
                        })
                            : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{en_pf, crate::check::types::recording::err(s_pg, Text::lit("mismatch"), prism_rtl::deref(fp_pi).span, prism_rtl::cat("`", crate::check::types::bare_name(prism_rtl::deref(c_pa_3_5).owner), "` has no field `", fname_pj, "`"))})
                            : throw prism_rtl::Panic("no arm matched");
                        });
                        });
                        });
                    }));
                    });
                }));
                })));
                }));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St>> BindRecord::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& p_p2 = this->p_p2;
    const auto& n_p3 = this->n_p3;
    const auto& fields_p4 = this->fields_p4;
    const auto& rest_p5 = this->rest_p5;
    const auto& t_p6 = this->t_p6;
    auto [qk_o7, why_p8] = crate::check::env::names::resolve_value(prism_rtl::deref(env_p0).g, prism_rtl::deref(env_p0).home, n_p3);
    return ({
        prism_rtl::is_none(qk_o7) ? prism_rtl::finished(std::tuple{env_p0, crate::check::types::recording::err(st_p1, Text::lit("unknown-name"), prism_rtl::deref(n_p3).span, prism_rtl::cat("no record or tag `", crate::check::env::sname_key(n_p3), "`"))})
        : prism_rtl::is_some(qk_o7) ? ({
        auto&& qk_p9 = prism_rtl::some_of(qk_o7);
        why_p8 == Text::lit("tag")
        ? prism_rtl::more(prism_rtl::rc(BindTagPattern(env_p0, st_p1, p_p2, qk_p9, fields_p4, prism_rtl::deref(rest_p5), t_p6)))
        : ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(prism_rtl::deref(env_p0).g).ctors, qk_p9);
        prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{env_p0, crate::check::types::recording::err(st_p1, Text::lit("unknown-name"), prism_rtl::deref(n_p3).span, prism_rtl::cat("`", crate::check::env::sname_key(n_p3), "` is not a record"))})
        : prism_rtl::is_some(_m) ? ({
        auto&& c_pa = prism_rtl::some_of(_m);
        ({
        auto env_p0_1 = env_p0;
        auto fields_p4_2 = fields_p4;
        auto p_p2_3 = p_p2;
        auto st_p1_4 = st_p1;
        auto t_p6_5 = t_p6;
        call_then(crate::check::types::schemes::start_instantiate_with(st_p1_4, crate::check::types::Scheme{.qs = prism_rtl::deref(c_pa).params, .plain_qs = Array<Text>{}, .rqs = Array<Text>{}, .cqs = Array<Text>{}, .cjoins = Array<std::tuple<Text, Text>>{}, .bounds = Array<std::tuple<Text, Text>>{}, .ty = prism_rtl::deref(c_pa).ty}, prism_rtl::deref(p_p2_3).span, Array<crate::check::types::Ty>{}), [=, env_p0_1 = std::move(env_p0_1), fields_p4_2 = std::move(fields_p4_2), t_p6_5 = std::move(t_p6_5)](std::tuple<crate::check::types::Ty, crate::check::types::St, crate::check::types::schemes::Inst> instantiate_with_8595) {
        return ({
            auto [self_pc, st1_pd, inst_pe] = instantiate_with_8595;
            call_then(crate::check::types::unify::start_unify(st1_pd, t_p6_5, self_pc, prism_rtl::deref(p_p2_3).span), [=](crate::check::types::St unify_8750) {
            return ({
                auto st2_pb = unify_8750;
                fold_job(crate::check::errors::range0(len(fields_p4_2)), std::tuple{env_p0_1, st2_pb}, ({
                auto fields_p4_2_6 = fields_p4_2;
                auto p_p2_3_6 = p_p2_3;
                auto c_pa_6 = c_pa;
                auto inst_pe_7 = inst_pe;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>>(std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=, fields_p4_2_6 = std::move(fields_p4_2_6), p_p2_3_6 = std::move(p_p2_3_6), c_pa_6 = std::move(c_pa_6), inst_pe_7 = std::move(inst_pe_7)](std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto fields_p4_2_6_8 = fields_p4_2_6;
                    auto p_p2_3_6_8 = p_p2_3_6;
                    auto c_pa_6_8 = c_pa_6;
                    auto inst_pe_7_8 = inst_pe_7;
                    entered(once_job([=, fields_p4_2_6_8 = std::move(fields_p4_2_6_8), p_p2_3_6_8 = std::move(p_p2_3_6_8), c_pa_6_8 = std::move(c_pa_6_8), inst_pe_7_8 = std::move(inst_pe_7_8)]() {
                    return ({
                        auto [en_pf, s_pg] = p0;
                        auto i_ph = p1;
                        ({
                        auto fp_pi = or_(index(fields_p4_2_6_8, i_ph), crate::syntax::FieldPat{.name = std::optional<crate::syntax::Ident>{}, .pattern = crate::syntax::Pattern_{.kind = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PIgnore{})), .span = prism_rtl::deref(p_p2_3_6_8).span}, .span = prism_rtl::deref(p_p2_3_6_8).span});
                        auto fname_pj = field_pat_name(fp_pi, prism_rtl::deref(c_pa_6_8).fields, i_ph);
                        ({
                        auto&& _m = crate::check::expr::operators::index_of(prism_rtl::deref(c_pa_6_8).fields, fname_pj);
                        prism_rtl::is_some(_m) ? ({
                        auto&& j_pk = prism_rtl::some_of(_m);
                        call_then(crate::check::types::schemes::start_subst_q(inst_pe_7_8, or_(index(c_pa_6_8->args, j_pk), crate::check::types::Ty(crate::check::types::Ty::TyErr{}))), [=](crate::check::types::Ty subst_q_9164) { return prism_rtl::more(prism_rtl::rc(BindPattern(en_pf, s_pg, prism_rtl::deref(fp_pi).pattern, subst_q_9164, true))); });
                    })
                        : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{en_pf, crate::check::types::recording::err(s_pg, Text::lit("mismatch"), prism_rtl::deref(fp_pi).span, prism_rtl::cat("`", crate::check::types::bare_name(prism_rtl::deref(c_pa_6_8).owner), "` has no field `", fname_pj, "`"))})
                        : throw prism_rtl::Panic("no arm matched");
                    });
                    });
                    });
                }));
                });
            }));
            }))->cycle();
            });
        });
        });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start BindRecord, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>> start_bind_record(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Pattern_ p_p2, crate::syntax::SName n_p3, Array<crate::syntax::FieldPat> fields_p4, bool rest_p5, crate::check::types::Ty t_p6) {
    return prism_rtl::make_rc<BindRecord>(env_p0, st_p1, p_p2, n_p3, fields_p4, rest_p5, t_p6);
}


/// FieldPatName: fn FieldPat, [Text], Nat -> Text
Text field_pat_name(const crate::syntax::FieldPat& fp_p0, const Array<Text>& fields_p1, const Nat& i_p2) {
    auto&& _m = fp_p0.name;
    if (prism_rtl::is_some(_m)) {
        auto&& id_p3 = prism_rtl::some_of(_m);
        return prism_rtl::deref(id_p3).name;
    }
    if (prism_rtl::is_none(_m)) {
        auto&& _m = prism_rtl::deref(prism_rtl::deref(fp_p0.pattern).kind);
        if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
            auto&& n_p4 = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
            return crate::check::types::has_text(fields_p1, crate::check::env::sname_key(n_p4))
                ? crate::check::env::sname_key(n_p4)
                : or_(index(fields_p1, i_p2), Text::lit(""));
        }
        {
            return or_(index(fields_p1, i_p2), Text::lit(""));
        }
    }
    prism_rtl::unreachable("no arm matched");
}


/// BindTagPattern: unbounded fn Env, St, Pattern, Text, [FieldPat], Bool, Ty -> ((Env, St))
std::tuple<crate::check::expr::Env, crate::check::types::St> bind_tag_pattern(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Pattern_& p_p2, const Text& name_p3, const Array<crate::syntax::FieldPat>& fields_p4, const bool& rest_p5, const crate::check::types::Ty& t_p6) {
    auto&& _m = crate::prelude::get(prism_rtl::deref(env_p0.g).tags, name_p3);
    if (prism_rtl::is_none(_m)) {
        return std::tuple{env_p0, crate::check::types::recording::err(st_p1, Text::lit("unknown-name"), p_p2.span, prism_rtl::cat("no tag `", name_p3, "`"))};
    }
    if (prism_rtl::is_some(_m)) {
        auto&& tg_p7 = prism_rtl::some_of(_m);
        auto st1_p8 = prism_rtl::deref(tg_p7).kind == Text::lit("Element")
            ? tag_in_row(env_p0, st_p1, tg_p7, t_p6, p_p2.span)
            : crate::check::types::unify::unify(st_p1, t_p6, crate::check::types::Ty(crate::check::types::Ty::TyCon{prism_rtl::deref(tg_p7).kind, Array<crate::check::types::Ty>{}}), p_p2.span);
        auto snapshot_p9 = is_snapshot(st1_p8, t_p6);
        auto&& _st2_pb = crate::check::types::schemes::instantiate_with(st1_p8, crate::check::types::Scheme{.qs = prism_rtl::deref(tg_p7).qs, .plain_qs = Array<Text>{}, .rqs = prism_rtl::deref(tg_p7).rqs, .cqs = Array<Text>{}, .cjoins = Array<std::tuple<Text, Text>>{}, .bounds = Array<std::tuple<Text, Text>>{}, .ty = tg_p7->out}, p_p2.span, Array<crate::check::types::Ty>{});
        auto&& st2_pb = std::get<1>(_st2_pb);
        auto&& inst_pc = std::get<2>(_st2_pb);
        auto names_pa = each(prism_rtl::deref(tg_p7).fields, [&](const std::tuple<Text, crate::check::types::Ty>& _p0) {
            auto&& f_pd = std::get<0>(_p0);
            return f_pd;
        });
        return run_to_end(fold_job(crate::check::errors::range0(len(fields_p4)), std::tuple{env_p0, st2_pb}, ({
            auto fields_p4_1 = fields_p4;
            auto p_p2_2 = p_p2;
            auto names_pa_3 = names_pa;
            auto tg_p7_4 = tg_p7;
            auto inst_pc_5 = inst_pc;
            auto snapshot_p9_6 = std::move(snapshot_p9);
            auto name_p3_7 = name_p3;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>>(std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=, fields_p4_1 = std::move(fields_p4_1), p_p2_2 = std::move(p_p2_2), names_pa_3 = std::move(names_pa_3), tg_p7_4 = std::move(tg_p7_4), inst_pc_5 = std::move(inst_pc_5), snapshot_p9_6 = std::move(snapshot_p9_6), name_p3_7 = std::move(name_p3_7)](std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto fields_p4_1_8 = fields_p4_1;
                auto p_p2_2_8 = p_p2_2;
                auto names_pa_3_8 = names_pa_3;
                auto tg_p7_4_8 = tg_p7_4;
                auto inst_pc_5_8 = inst_pc_5;
                auto snapshot_p9_6_8 = snapshot_p9_6;
                auto name_p3_7_8 = name_p3_7;
                entered(once_job([=, fields_p4_1_8 = std::move(fields_p4_1_8), p_p2_2_8 = std::move(p_p2_2_8), names_pa_3_8 = std::move(names_pa_3_8), tg_p7_4_8 = std::move(tg_p7_4_8), inst_pc_5_8 = std::move(inst_pc_5_8), snapshot_p9_6_8 = std::move(snapshot_p9_6_8), name_p3_7_8 = std::move(name_p3_7_8)]() {
                return ({
                    auto [en_pe, s_pf] = p0;
                    auto i_pg = p1;
                    ({
                    auto fp_ph = or_(index(fields_p4_1_8, i_pg), crate::syntax::FieldPat{.name = std::optional<crate::syntax::Ident>{}, .pattern = crate::syntax::Pattern_{.kind = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PIgnore{})), .span = p_p2_2_8.span}, .span = p_p2_2_8.span});
                    auto fname_pi = field_pat_name(fp_ph, names_pa_3_8, i_pg);
                    ({
                    auto&& _m = crate::check::expr::calls::field_of_tag(tg_p7_4_8, fname_pi);
                    prism_rtl::is_some(_m) ? ({
                    auto&& ft_pj = prism_rtl::some_of(_m);
                    call_then(crate::check::types::schemes::start_subst_q(inst_pc_5_8, ft_pj), [=](crate::check::types::Ty subst_q_10850) { return prism_rtl::more(prism_rtl::rc(BindField(en_pe, s_pf, prism_rtl::deref(fp_ph).pattern, subst_q_10850, snapshot_p9_6_8))); });
                })
                    : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{en_pe, crate::check::types::recording::err(s_pf, Text::lit("mismatch"), prism_rtl::deref(fp_ph).span, prism_rtl::cat("`", name_p3_7_8, "` has no field `", fname_pi, "`"))})
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
                });
            }));
            });
        }));
        })));
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St>> BindTagPattern::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& p_p2 = this->p_p2;
    const auto& name_p3 = this->name_p3;
    const auto& fields_p4 = this->fields_p4;
    const auto& rest_p5 = this->rest_p5;
    const auto& t_p6 = this->t_p6;
    return ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(prism_rtl::deref(env_p0).g).tags, name_p3);
        prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{env_p0, crate::check::types::recording::err(st_p1, Text::lit("unknown-name"), prism_rtl::deref(p_p2).span, prism_rtl::cat("no tag `", name_p3, "`"))})
        : prism_rtl::is_some(_m) ? ({
        auto&& tg_p7 = prism_rtl::some_of(_m);
        ({
        auto st1_p8 = prism_rtl::deref(tg_p7).kind == Text::lit("Element")
            ? tag_in_row(env_p0, st_p1, tg_p7, t_p6, prism_rtl::deref(p_p2).span)
            : crate::check::types::unify::unify(st_p1, t_p6, crate::check::types::Ty(crate::check::types::Ty::TyCon{prism_rtl::deref(tg_p7).kind, Array<crate::check::types::Ty>{}}), prism_rtl::deref(p_p2).span);
        auto env_p0_1 = env_p0;
        auto fields_p4_2 = fields_p4;
        auto name_p3_3 = name_p3;
        auto p_p2_4 = p_p2;
        auto t_p6_5 = t_p6;
        call_then(start_is_snapshot(st1_p8, t_p6_5), [=, env_p0_1 = std::move(env_p0_1), fields_p4_2 = std::move(fields_p4_2), name_p3_3 = std::move(name_p3_3), p_p2_4 = std::move(p_p2_4)](bool is_snapshot_10294) {
        return ({
            auto snapshot_p9 = is_snapshot_10294;
            call_then(crate::check::types::schemes::start_instantiate_with(st1_p8, crate::check::types::Scheme{.qs = prism_rtl::deref(tg_p7).qs, .plain_qs = Array<Text>{}, .rqs = prism_rtl::deref(tg_p7).rqs, .cqs = Array<Text>{}, .cjoins = Array<std::tuple<Text, Text>>{}, .bounds = Array<std::tuple<Text, Text>>{}, .ty = tg_p7->out}, prism_rtl::deref(p_p2_4).span, Array<crate::check::types::Ty>{}), [=, snapshot_p9 = std::move(snapshot_p9)](std::tuple<crate::check::types::Ty, crate::check::types::St, crate::check::types::schemes::Inst> instantiate_with_10348) {
            return ({
                auto&& _st2_pb = instantiate_with_10348;
                auto&& st2_pb = std::get<1>(_st2_pb);
                auto&& inst_pc = std::get<2>(_st2_pb);
                auto names_pa = each(prism_rtl::deref(tg_p7).fields, [&](const std::tuple<Text, crate::check::types::Ty>& _p0) {
                    auto&& f_pd = std::get<0>(_p0);
                    return f_pd;
                });
                fold_job(crate::check::errors::range0(len(fields_p4_2)), std::tuple{env_p0_1, st2_pb}, ({
                auto fields_p4_2_6 = fields_p4_2;
                auto p_p2_4_6 = p_p2_4;
                auto names_pa_6 = names_pa;
                auto tg_p7_7 = tg_p7;
                auto inst_pc_8 = inst_pc;
                auto snapshot_p9_9 = snapshot_p9;
                auto name_p3_3_10 = name_p3_3;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>>(std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=, fields_p4_2_6 = std::move(fields_p4_2_6), p_p2_4_6 = std::move(p_p2_4_6), names_pa_6 = std::move(names_pa_6), tg_p7_7 = std::move(tg_p7_7), inst_pc_8 = std::move(inst_pc_8), snapshot_p9_9 = std::move(snapshot_p9_9), name_p3_3_10 = std::move(name_p3_3_10)](std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto fields_p4_2_6_10 = fields_p4_2_6;
                    auto p_p2_4_6_10 = p_p2_4_6;
                    auto names_pa_6_10 = names_pa_6;
                    auto tg_p7_7_10 = tg_p7_7;
                    auto inst_pc_8_10 = inst_pc_8;
                    auto snapshot_p9_9_10 = snapshot_p9_9;
                    auto name_p3_3_10_10 = name_p3_3_10;
                    entered(once_job([=, fields_p4_2_6_10 = std::move(fields_p4_2_6_10), p_p2_4_6_10 = std::move(p_p2_4_6_10), names_pa_6_10 = std::move(names_pa_6_10), tg_p7_7_10 = std::move(tg_p7_7_10), inst_pc_8_10 = std::move(inst_pc_8_10), snapshot_p9_9_10 = std::move(snapshot_p9_9_10), name_p3_3_10_10 = std::move(name_p3_3_10_10)]() {
                    return ({
                        auto [en_pe, s_pf] = p0;
                        auto i_pg = p1;
                        ({
                        auto fp_ph = or_(index(fields_p4_2_6_10, i_pg), crate::syntax::FieldPat{.name = std::optional<crate::syntax::Ident>{}, .pattern = crate::syntax::Pattern_{.kind = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PIgnore{})), .span = prism_rtl::deref(p_p2_4_6_10).span}, .span = prism_rtl::deref(p_p2_4_6_10).span});
                        auto fname_pi = field_pat_name(fp_ph, names_pa_6_10, i_pg);
                        ({
                        auto&& _m = crate::check::expr::calls::field_of_tag(tg_p7_7_10, fname_pi);
                        prism_rtl::is_some(_m) ? ({
                        auto&& ft_pj = prism_rtl::some_of(_m);
                        call_then(crate::check::types::schemes::start_subst_q(inst_pc_8_10, ft_pj), [=](crate::check::types::Ty subst_q_10850) { return prism_rtl::more(prism_rtl::rc(BindField(en_pe, s_pf, prism_rtl::deref(fp_ph).pattern, subst_q_10850, snapshot_p9_9_10))); });
                    })
                        : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{en_pe, crate::check::types::recording::err(s_pf, Text::lit("mismatch"), prism_rtl::deref(fp_ph).span, prism_rtl::cat("`", name_p3_3_10_10, "` has no field `", fname_pi, "`"))})
                        : throw prism_rtl::Panic("no arm matched");
                    });
                    });
                    });
                }));
                });
            }));
            }))->cycle();
            });
        });
        });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start BindTagPattern, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>> start_bind_tag_pattern(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Pattern_ p_p2, Text name_p3, Array<crate::syntax::FieldPat> fields_p4, bool rest_p5, crate::check::types::Ty t_p6) {
    return prism_rtl::make_rc<BindTagPattern>(env_p0, st_p1, p_p2, name_p3, fields_p4, rest_p5, t_p6);
}


/// IsSnapshot: unbounded fn St, Ty -> Bool
bool is_snapshot(const crate::check::types::St& st_p0, const crate::check::types::Ty& t_p1) {
    auto&& _m = crate::check::types::recording::walk(st_p0, t_p1);
    if (prism_rtl::is<crate::check::types::Ty::TyElemAny>(_m)) {
        return true;
    }
    {
        return false;
    }
}


prism_rtl::Turn<bool> IsSnapshot::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& t_p1 = this->t_p1;
    auto st_p0_1 = st_p0;
    auto t_p1_2 = t_p1;
    return call_then(crate::check::types::recording::start_walk(st_p0_1, t_p1_2), [=](crate::check::types::Ty walk_11187) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TyElemAny>(walk_11187) ? prism_rtl::finished(true)
            : prism_rtl::finished(false);
        });
    });
}


/// `Start IsSnapshot, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_is_snapshot(crate::check::types::St st_p0, crate::check::types::Ty t_p1) {
    return prism_rtl::make_rc<IsSnapshot>(st_p0, t_p1);
}


/// TagInRow: unbounded fn Env, St, TagInfo, Ty, Range -> St
crate::check::types::St tag_in_row(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::check::env::TagInfo& tg_p2, const crate::check::types::Ty& t_p3, const crate::syntax::Range& span_p4) {
    auto&& _m = crate::check::types::recording::walk(st_p1, t_p3);
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(_m)) {
        auto&& rw_p5 = prism_rtl::as<crate::check::types::Ty::TyElem>(_m).a0;
        auto w_p6 = crate::check::types::recording::walk_row(st_p1, rw_p5);
        return crate::check::types::has_text(prism_rtl::deref(w_p6).fams, tg_p2.family)
            ? st_p1
            : crate::check::types::recording::err_fix(st_p1, Text::lit("row-not-here"), span_p4, prism_rtl::cat("`", tg_p2.name, "` is not in this row, `", crate::check::types::show_row(w_p6), "`"), prism_rtl::cat("add `", tg_p2.family, ".*` to the row, or answer the tag elsewhere"));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElemAny>(_m)) {
        auto&& rw_p7 = prism_rtl::as<crate::check::types::Ty::TyElemAny>(_m).a0;
        auto w_p8 = crate::check::types::recording::walk_row(st_p1, rw_p7);
        return crate::check::types::has_text(prism_rtl::deref(w_p8).fams, tg_p2.family)
            ? st_p1
            : crate::check::types::recording::err_fix(st_p1, Text::lit("row-not-here"), span_p4, prism_rtl::cat("`", tg_p2.name, "` is not in this row, `", crate::check::types::show_row(w_p8), "`"), prism_rtl::cat("add `", tg_p2.family, ".*` to the row, or answer the tag elsewhere"));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFlex>(_m)) {
        auto [rw_p9, st2_pa] = crate::check::types::recording::fresh_row(st_p1, Array(std::vector{tg_p2.family}));
        auto [o_pb, st3_pc] = crate::check::types::fresh_var(st2_pa, false, Text::lit(""));
        return crate::check::types::unify::unify(st3_pc, t_p3, crate::check::types::Ty(crate::check::types::Ty::TyElem{crate::check::types::Rw{.fams = Array(std::vector{tg_p2.family}), .minus = Array<Text>{}, .tail = prism_rtl::deref(rw_p9).tail}, prism_rtl::rc(o_pb)}), span_p4);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyErr>(_m)) {
        return st_p1;
    }
    {
        auto&& other_pd = _m;
        return crate::check::types::recording::err(st_p1, Text::lit("mismatch"), span_p4, prism_rtl::cat("a tag pattern matches an element; this is `", crate::check::types::show_ty(st_p1, other_pd), "`"));
    }
}


prism_rtl::Turn<crate::check::types::St> TagInRow::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& tg_p2 = this->tg_p2;
    const auto& t_p3 = this->t_p3;
    const auto& span_p4 = this->span_p4;
    auto span_p4_1 = span_p4;
    auto st_p1_2 = st_p1;
    auto t_p3_3 = t_p3;
    auto tg_p2_4 = tg_p2;
    return call_then(crate::check::types::recording::start_walk(st_p1_2, t_p3_3), [=](crate::check::types::Ty walk_11346) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TyElem>(walk_11346) ? ({
            auto&& rw_p5 = prism_rtl::as<crate::check::types::Ty::TyElem>(walk_11346).a0;
            call_then(crate::check::types::recording::start_walk_row(st_p1_2, rw_p5), [=](crate::check::types::Rw walk_row_11397) {
            return ({
                auto w_p6 = walk_row_11397;
                (crate::check::types::has_text(prism_rtl::deref(w_p6).fams, prism_rtl::deref(tg_p2_4).family)
                ? prism_rtl::finished(st_p1_2)
                : prism_rtl::finished(crate::check::types::recording::err_fix(st_p1_2, Text::lit("row-not-here"), span_p4_1, prism_rtl::cat("`", prism_rtl::deref(tg_p2_4).name, "` is not in this row, `", crate::check::types::show_row(w_p6), "`"), prism_rtl::cat("add `", prism_rtl::deref(tg_p2_4).family, ".*` to the row, or answer the tag elsewhere"))));
            });
        });
        })
            : prism_rtl::is<crate::check::types::Ty::TyElemAny>(walk_11346) ? ({
            auto&& rw_p7 = prism_rtl::as<crate::check::types::Ty::TyElemAny>(walk_11346).a0;
            call_then(crate::check::types::recording::start_walk_row(st_p1_2, rw_p7), [=](crate::check::types::Rw walk_row_11645) {
            return ({
                auto w_p8 = walk_row_11645;
                (crate::check::types::has_text(prism_rtl::deref(w_p8).fams, prism_rtl::deref(tg_p2_4).family)
                ? prism_rtl::finished(st_p1_2)
                : prism_rtl::finished(crate::check::types::recording::err_fix(st_p1_2, Text::lit("row-not-here"), span_p4_1, prism_rtl::cat("`", prism_rtl::deref(tg_p2_4).name, "` is not in this row, `", crate::check::types::show_row(w_p8), "`"), prism_rtl::cat("add `", prism_rtl::deref(tg_p2_4).family, ".*` to the row, or answer the tag elsewhere"))));
            });
        });
        })
            : prism_rtl::is<crate::check::types::Ty::TyFlex>(walk_11346) ? ({
            auto [rw_p9, st2_pa] = crate::check::types::recording::fresh_row(st_p1_2, Array(std::vector{prism_rtl::deref(tg_p2_4).family}));
            auto [o_pb, st3_pc] = crate::check::types::fresh_var(st2_pa, false, Text::lit(""));
            (prism_rtl::more(prism_rtl::rc(crate::check::types::unify::Unify(st3_pc, t_p3_3, crate::check::types::Ty(crate::check::types::Ty::TyElem{crate::check::types::Rw{.fams = Array(std::vector{prism_rtl::deref(tg_p2_4).family}), .minus = Array<Text>{}, .tail = prism_rtl::deref(rw_p9).tail}, prism_rtl::rc(o_pb)}), span_p4_1))));
        })
            : prism_rtl::is<crate::check::types::Ty::TyErr>(walk_11346) ? prism_rtl::finished(st_p1_2)
            : ({
            auto&& other_pd = walk_11346;
            call_then(crate::check::types::start_show_ty(st_p1_2, other_pd), [=](Text show_ty_12167) { return prism_rtl::finished(crate::check::types::recording::err(st_p1_2, Text::lit("mismatch"), span_p4_1, prism_rtl::cat("a tag pattern matches an element; this is `", show_ty_12167, "`"))); });
        });
        });
    });
}


/// `Start TagInRow, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_tag_in_row(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::check::env::TagInfo tg_p2, crate::check::types::Ty t_p3, crate::syntax::Range span_p4) {
    return prism_rtl::make_rc<TagInRow>(env_p0, st_p1, tg_p2, t_p3, span_p4);
}


/// BindFamily: unbounded fn Env, St, Text, Ty, Range -> ((Env, St))
std::tuple<crate::check::expr::Env, crate::check::types::St> bind_family(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const Text& fam_p2, const crate::check::types::Ty& t_p3, const crate::syntax::Range& span_p4) {
    auto&& _m = crate::check::types::recording::walk(st_p1, t_p3);
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(_m)) {
        auto&& rw_p5 = prism_rtl::as<crate::check::types::Ty::TyElem>(_m).a0;
        auto w_p6 = crate::check::types::recording::walk_row(st_p1, rw_p5);
        return crate::check::types::has_text(prism_rtl::deref(w_p6).fams, fam_p2)
            ? std::tuple{env_p0, st_p1}
            : std::tuple{env_p0, crate::check::types::recording::err_fix(st_p1, Text::lit("row-not-here"), span_p4, prism_rtl::cat("`", fam_p2, ".*` is not in this row, `", crate::check::types::show_row(w_p6), "`"), prism_rtl::cat("add `", fam_p2, ".*` to the row"))};
    }
    {
        return std::tuple{env_p0, st_p1};
    }
}


prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St>> BindFamily::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& fam_p2 = this->fam_p2;
    const auto& t_p3 = this->t_p3;
    const auto& span_p4 = this->span_p4;
    auto env_p0_1 = env_p0;
    auto fam_p2_2 = fam_p2;
    auto span_p4_3 = span_p4;
    auto st_p1_4 = st_p1;
    auto t_p3_5 = t_p3;
    return call_then(crate::check::types::recording::start_walk(st_p1_4, t_p3_5), [=](crate::check::types::Ty walk_12297) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TyElem>(walk_12297) ? ({
            auto&& rw_p5 = prism_rtl::as<crate::check::types::Ty::TyElem>(walk_12297).a0;
            call_then(crate::check::types::recording::start_walk_row(st_p1_4, rw_p5), [=](crate::check::types::Rw walk_row_12348) {
            return ({
                auto w_p6 = walk_row_12348;
                (crate::check::types::has_text(prism_rtl::deref(w_p6).fams, fam_p2_2)
                ? prism_rtl::finished(std::tuple{env_p0_1, st_p1_4})
                : prism_rtl::finished(std::tuple{env_p0_1, crate::check::types::recording::err_fix(st_p1_4, Text::lit("row-not-here"), span_p4_3, prism_rtl::cat("`", fam_p2_2, ".*` is not in this row, `", crate::check::types::show_row(w_p6), "`"), prism_rtl::cat("add `", fam_p2_2, ".*` to the row"))}));
            });
        });
        })
            : prism_rtl::finished(std::tuple{env_p0_1, st_p1_4});
        });
    });
}


/// `Start BindFamily, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>> start_bind_family(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Text fam_p2, crate::check::types::Ty t_p3, crate::syntax::Range span_p4) {
    return prism_rtl::make_rc<BindFamily>(env_p0, st_p1, fam_p2, t_p3, span_p4);
}

}  // namespace crate::check::expr::patterns
