// The module `Check.Expr.Patterns`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <check/expr/patterns/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Check.Expr.Patterns`, from `target/bootstrap/cpp-src/prismc/check/expr/patterns.prism`.
namespace crate::check::expr::patterns {

/// BindPattern: unbounded fn Env, St, Pattern, Ty, Bool -> ((Env, St))
std::tuple<crate::check::expr::Env, crate::check::types::St> bind_pattern(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Pattern_& p_, const crate::check::types::Ty& t, const bool& refutable) {
    auto&& _m = prism_rtl::deref(p_.kind);
    if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        auto bare = or_(index(n->path_, Nat(0u)), Text::lit(""));
        auto is_ctor = (crate::check::env::is_upper_text(bare) && (len_text(prism_rtl::deref(n).sigils) == Nat(0u))) && is_ctor_name(env, n);
        return std::move(is_ctor) || (len(n->path_) > Nat(1u))
            ? bind_ctor(env, st, p_, n, Array<crate::syntax::Pattern_>{}, t)
            : bind_name(env, st, n, t);
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PIgnore>(_m)) {
        return std::tuple{env, st};
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PLit>(_m)) {
        auto&& l = prism_rtl::as<crate::syntax::PatternKind::PLit>(_m).a0;
        auto [lt, st2] = crate::check::expr::infer_lit(env, st, l, false, p_.span);
        return std::tuple{env, crate::check::types::unify::unify(st2, t, lt, p_.span)};
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PNeg>(_m)) {
        auto&& l = prism_rtl::as<crate::syntax::PatternKind::PNeg>(_m).a0;
        auto [lt, st2] = crate::check::expr::infer_lit(env, st, l, true, p_.span);
        return std::tuple{env, crate::check::types::unify::unify(st2, t, lt, p_.span)};
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PUnit>(_m)) {
        return std::tuple{env, crate::check::types::unify::unify(st, t, crate::check::types::t_unit(), p_.span)};
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PNil>(_m)) {
        auto [v_, st2] = crate::check::types::fresh_var(st, false, Text::lit(""));
        return std::tuple{env, crate::check::types::unify::unify(st2, t, crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("?"), prism_rtl::rc(v_)}), p_.span)};
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PCtor>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::PatternKind::PCtor>(_m).a0;
        auto&& args = prism_rtl::as<crate::syntax::PatternKind::PCtor>(_m).a1;
        return bind_ctor(env, st, p_, n, args, t);
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PRecord>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::PatternKind::PRecord>(_m).a0;
        auto&& fields = prism_rtl::as<crate::syntax::PatternKind::PRecord>(_m).a1;
        auto&& rest = prism_rtl::as<crate::syntax::PatternKind::PRecord>(_m).a2;
        return bind_record(env, st, p_, n, fields, rest, t);
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PSigil>(_m)) {
        auto&& s = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a0;
        auto&& inner = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a1;
        return (s == Text::lit("?")) || (s == Text::lit("~"))
            ? ({
            auto [v_, st2] = crate::check::types::fresh_var(st, false, Text::lit(""));
            auto st3 = crate::check::types::unify::unify(st2, t, crate::check::types::Ty(crate::check::types::Ty::TySig{s, prism_rtl::rc(v_)}), p_.span);
            bind_pattern(env, st3, prism_rtl::deref(prism_rtl::deref(inner)), v_, refutable);
        })
            : ({
            auto [v_, st2] = crate::check::types::fresh_var(st, false, Text::lit(""));
            auto st3 = crate::check::types::unify::unify(st2, t, crate::check::types::with_marks(s, v_, env.scope), p_.span);
            bind_pattern(env, st3, prism_rtl::deref(prism_rtl::deref(inner)), v_, refutable);
        });
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PTuple>(_m)) {
        auto&& ps = prism_rtl::as<crate::syntax::PatternKind::PTuple>(_m).a0;
        auto [vs, st2] = fold(ps, std::tuple{Array<crate::check::types::Ty>{}, st}, [&](const std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>& _p0, const crate::syntax::Pattern_& _p1) {
            auto&& acc = std::get<0>(_p0);
            auto&& s = std::get<1>(_p0);
            return ({
                auto [v_, s2] = crate::check::types::fresh_var(s, false, Text::lit(""));
                std::tuple{crate::prelude::push(acc, v_), s2};
            });
        });
        auto st3 = crate::check::types::unify::unify(st2, t, crate::check::types::Ty(crate::check::types::Ty::TyTuple{vs}), p_.span);
        return run_to_end(fold_job(crate::check::errors::range0(len(ps)), std::tuple{env, st3}, ({
            auto ps_1 = ps;
            auto p__2 = p_;
            auto vs_3 = vs;
            auto refutable_4 = refutable;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>>(std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=, ps_1 = std::move(ps_1), p__2 = std::move(p__2), vs_3 = std::move(vs_3), refutable_4 = std::move(refutable_4)](std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto ps_1_5 = ps_1;
                auto p__2_5 = p__2;
                auto vs_3_5 = vs_3;
                auto refutable_4_5 = refutable_4;
                entered(once_job([=, ps_1_5 = std::move(ps_1_5), p__2_5 = std::move(p__2_5), vs_3_5 = std::move(vs_3_5), refutable_4_5 = std::move(refutable_4_5)]() {
                return ({
                    auto [en, s] = p0;
                    auto i = p1;
                    (prism_rtl::more(prism_rtl::rc(BindPattern(en, s, or_(index(ps_1_5, i), crate::syntax::Pattern_{.kind = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PIgnore{})), .span = p__2_5.span}), or_(index(vs_3_5, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), refutable_4_5))));
                });
            }));
            });
        }));
        })));
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PArray>(_m)) {
        auto&& ps = prism_rtl::as<crate::syntax::PatternKind::PArray>(_m).a0;
        auto [v_, st2] = crate::check::types::fresh_var(st, false, Text::lit(""));
        auto st3 = crate::check::types::unify::unify(st2, t, crate::check::types::Ty(crate::check::types::Ty::TyArray{prism_rtl::rc(v_)}), p_.span);
        return run_to_end(fold_job(ps, std::tuple{env, st3}, ({
            auto v__1 = v_;
            auto refutable_2 = refutable;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>>(std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, crate::syntax::Pattern_>)>>(prism_rtl::rc([=, v__1 = std::move(v__1), refutable_2 = std::move(refutable_2)](std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, crate::syntax::Pattern_> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto v__1_3 = v__1;
                auto refutable_2_3 = refutable_2;
                entered(once_job([=, v__1_3 = std::move(v__1_3), refutable_2_3 = std::move(refutable_2_3)]() {
                return ({
                    auto [en, s] = p0;
                    auto q = p1;
                    (prism_rtl::more(prism_rtl::rc(BindPattern(en, s, q, v__1_3, refutable_2_3))));
                });
            }));
            });
        }));
        })));
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PGroup>(_m)) {
        auto&& q = prism_rtl::as<crate::syntax::PatternKind::PGroup>(_m).a0;
        return bind_pattern(env, st, prism_rtl::deref(prism_rtl::deref(q)), t, refutable);
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PFamily>(_m)) {
        auto&& q = prism_rtl::as<crate::syntax::PatternKind::PFamily>(_m).a0;
        return bind_family(env, st, crate::check::env::dotted(q->path_), t, p_.span);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St>> BindPattern::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& p_ = this->p_;
    const auto& t = this->t;
    const auto& refutable = this->refutable;
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(p_).kind);
        prism_rtl::is<crate::syntax::PatternKind::PName>(_m) ? ({
        auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        ({
        auto bare = or_(index(n->path_, Nat(0u)), Text::lit(""));
        auto is_ctor = (crate::check::env::is_upper_text(bare) && (len_text(prism_rtl::deref(n).sigils) == Nat(0u))) && is_ctor_name(env, n);
        (std::move(is_ctor) || (len(n->path_) > Nat(1u))
        ? prism_rtl::more(prism_rtl::rc(BindCtor(env, st, p_, n, Array<crate::syntax::Pattern_>{}, t)))
        : prism_rtl::more(prism_rtl::rc(BindName(env, st, n, t))));
    });
    })
        : prism_rtl::is<crate::syntax::PatternKind::PIgnore>(_m) ? prism_rtl::finished(std::tuple{env, st})
        : prism_rtl::is<crate::syntax::PatternKind::PLit>(_m) ? ({
        auto&& l = prism_rtl::as<crate::syntax::PatternKind::PLit>(_m).a0;
        ({
        auto env_1 = env;
        auto l_2 = l;
        auto p__3 = p_;
        auto st_4 = st;
        auto t_5 = t;
        call_then(crate::check::expr::start_infer_lit(env_1, st_4, l_2, false, prism_rtl::deref(p__3).span), [=, t_5 = std::move(t_5)](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_lit_1841) {
        return ({
            auto [lt, st2] = infer_lit_1841;
            call_then(crate::check::types::unify::start_unify(st2, t_5, lt, prism_rtl::deref(p__3).span), [=](crate::check::types::St unify_1892) { return prism_rtl::finished(std::tuple{env_1, unify_1892}); });
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::PatternKind::PNeg>(_m) ? ({
        auto&& l = prism_rtl::as<crate::syntax::PatternKind::PNeg>(_m).a0;
        ({
        auto env_1 = env;
        auto l_2 = l;
        auto p__3 = p_;
        auto st_4 = st;
        auto t_5 = t;
        call_then(crate::check::expr::start_infer_lit(env_1, st_4, l_2, true, prism_rtl::deref(p__3).span), [=, t_5 = std::move(t_5)](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_lit_1958) {
        return ({
            auto [lt, st2] = infer_lit_1958;
            call_then(crate::check::types::unify::start_unify(st2, t_5, lt, prism_rtl::deref(p__3).span), [=](crate::check::types::St unify_2008) { return prism_rtl::finished(std::tuple{env_1, unify_2008}); });
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::PatternKind::PUnit>(_m) ? ({
        auto env_1 = env;
        auto p__2 = p_;
        auto st_3 = st;
        auto t_4 = t;
        call_then(crate::check::types::unify::start_unify(st_3, t_4, crate::check::types::t_unit(), prism_rtl::deref(p__2).span), [=, env_1 = std::move(env_1)](crate::check::types::St unify_2055) { return prism_rtl::finished(std::tuple{env_1, unify_2055}); });
    })
        : prism_rtl::is<crate::syntax::PatternKind::PNil>(_m) ? ({
        auto [v_, st2] = crate::check::types::fresh_var(st, false, Text::lit(""));
        auto env_1 = env;
        auto p__2 = p_;
        auto t_3 = t;
        call_then(crate::check::types::unify::start_unify(st2, t_3, crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("?"), prism_rtl::rc(v_)}), prism_rtl::deref(p__2).span), [=, env_1 = std::move(env_1)](crate::check::types::St unify_2159) { return prism_rtl::finished(std::tuple{env_1, unify_2159}); });
    })
        : prism_rtl::is<crate::syntax::PatternKind::PCtor>(_m) ? ({
        auto&& n = prism_rtl::as<crate::syntax::PatternKind::PCtor>(_m).a0;
        auto&& args = prism_rtl::as<crate::syntax::PatternKind::PCtor>(_m).a1;
        prism_rtl::more(prism_rtl::rc(BindCtor(env, st, p_, n, args, t)));
    })
        : prism_rtl::is<crate::syntax::PatternKind::PRecord>(_m) ? ({
        auto&& n = prism_rtl::as<crate::syntax::PatternKind::PRecord>(_m).a0;
        auto&& fields = prism_rtl::as<crate::syntax::PatternKind::PRecord>(_m).a1;
        auto&& rest = prism_rtl::as<crate::syntax::PatternKind::PRecord>(_m).a2;
        prism_rtl::more(prism_rtl::rc(BindRecord(env, st, p_, n, fields, prism_rtl::deref(rest), t)));
    })
        : prism_rtl::is<crate::syntax::PatternKind::PSigil>(_m) ? ({
        auto&& s = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a0;
        auto&& inner = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a1;
        (s == Text::lit("?")) || (s == Text::lit("~"))
        ? ({
        auto [v_, st2] = crate::check::types::fresh_var(st, false, Text::lit(""));
        auto env_1 = env;
        auto inner_2 = prism_rtl::deref(prism_rtl::deref(inner));
        auto p__3 = p_;
        auto refutable_4 = prism_rtl::deref(refutable);
        auto s_5 = s;
        auto t_6 = t;
        call_then(crate::check::types::unify::start_unify(st2, t_6, crate::check::types::Ty(crate::check::types::Ty::TySig{s_5, prism_rtl::rc(v_)}), prism_rtl::deref(p__3).span), [=, env_1 = std::move(env_1), inner_2 = std::move(inner_2), refutable_4 = std::move(refutable_4)](crate::check::types::St unify_2449) {
        return ({
            auto st3 = unify_2449;
            (prism_rtl::more(prism_rtl::rc(BindPattern(env_1, st3, inner_2, v_, refutable_4))));
        });
    });
    })
        : ({
        auto [v_, st2] = crate::check::types::fresh_var(st, false, Text::lit(""));
        auto env_1 = env;
        auto inner_2 = prism_rtl::deref(prism_rtl::deref(inner));
        auto p__3 = p_;
        auto refutable_4 = prism_rtl::deref(refutable);
        auto s_5 = s;
        auto t_6 = t;
        call_then(crate::check::types::unify::start_unify(st2, t_6, crate::check::types::with_marks(s_5, v_, prism_rtl::deref(env_1).scope), prism_rtl::deref(p__3).span), [=, inner_2 = std::move(inner_2), refutable_4 = std::move(refutable_4)](crate::check::types::St unify_2626) {
        return ({
            auto st3 = unify_2626;
            (prism_rtl::more(prism_rtl::rc(BindPattern(env_1, st3, inner_2, v_, refutable_4))));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::PatternKind::PTuple>(_m) ? ({
        auto&& ps = prism_rtl::as<crate::syntax::PatternKind::PTuple>(_m).a0;
        ({
        auto [vs, st2] = fold(ps, std::tuple{Array<crate::check::types::Ty>{}, st}, [&](const std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>& _p0, const crate::syntax::Pattern_& _p1) {
            auto&& acc = std::get<0>(_p0);
            auto&& s = std::get<1>(_p0);
            return ({
                auto [v_, s2] = crate::check::types::fresh_var(s, false, Text::lit(""));
                std::tuple{crate::prelude::push(acc, v_), s2};
            });
        });
        auto env_1 = env;
        auto p__2 = p_;
        auto ps_3 = ps;
        auto refutable_4 = prism_rtl::deref(refutable);
        auto t_5 = t;
        call_then(crate::check::types::unify::start_unify(st2, t_5, crate::check::types::Ty(crate::check::types::Ty::TyTuple{vs}), prism_rtl::deref(p__2).span), [=, env_1 = std::move(env_1), ps_3 = std::move(ps_3), refutable_4 = std::move(refutable_4)](crate::check::types::St unify_2918) {
        return ({
            auto st3 = unify_2918;
            fold_job(crate::check::errors::range0(len(ps_3)), std::tuple{env_1, st3}, ({
            auto ps_3_6 = ps_3;
            auto p__2_6 = p__2;
            auto vs_6 = vs;
            auto refutable_4_7 = refutable_4;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>>(std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=, ps_3_6 = std::move(ps_3_6), p__2_6 = std::move(p__2_6), vs_6 = std::move(vs_6), refutable_4_7 = std::move(refutable_4_7)](std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto ps_3_6_7 = ps_3_6;
                auto p__2_6_7 = p__2_6;
                auto vs_6_7 = vs_6;
                auto refutable_4_7_7 = refutable_4_7;
                entered(once_job([=, ps_3_6_7 = std::move(ps_3_6_7), p__2_6_7 = std::move(p__2_6_7), vs_6_7 = std::move(vs_6_7), refutable_4_7_7 = std::move(refutable_4_7_7)]() {
                return ({
                    auto [en, s] = p0;
                    auto i = p1;
                    (prism_rtl::more(prism_rtl::rc(BindPattern(en, s, or_(index(ps_3_6_7, i), crate::syntax::Pattern_{.kind = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PIgnore{})), .span = prism_rtl::deref(p__2_6_7).span}), or_(index(vs_6_7, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), refutable_4_7_7))));
                });
            }));
            });
        }));
        }))->cycle();
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::PatternKind::PArray>(_m) ? ({
        auto&& ps = prism_rtl::as<crate::syntax::PatternKind::PArray>(_m).a0;
        ({
        auto [v_, st2] = crate::check::types::fresh_var(st, false, Text::lit(""));
        auto env_1 = env;
        auto p__2 = p_;
        auto ps_3 = ps;
        auto refutable_4 = prism_rtl::deref(refutable);
        auto t_5 = t;
        call_then(crate::check::types::unify::start_unify(st2, t_5, crate::check::types::Ty(crate::check::types::Ty::TyArray{prism_rtl::rc(v_)}), prism_rtl::deref(p__2).span), [=, env_1 = std::move(env_1), ps_3 = std::move(ps_3), refutable_4 = std::move(refutable_4)](crate::check::types::St unify_3192) {
        return ({
            auto st3 = unify_3192;
            fold_job(ps_3, std::tuple{env_1, st3}, ({
            auto v__6 = v_;
            auto refutable_4_7 = refutable_4;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>>(std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, crate::syntax::Pattern_>)>>(prism_rtl::rc([=, v__6 = std::move(v__6), refutable_4_7 = std::move(refutable_4_7)](std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, crate::syntax::Pattern_> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto v__6_7 = v__6;
                auto refutable_4_7_7 = refutable_4_7;
                entered(once_job([=, v__6_7 = std::move(v__6_7), refutable_4_7_7 = std::move(refutable_4_7_7)]() {
                return ({
                    auto [en, s] = p0;
                    auto q = p1;
                    (prism_rtl::more(prism_rtl::rc(BindPattern(en, s, q, v__6_7, refutable_4_7_7))));
                });
            }));
            });
        }));
        }))->cycle();
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::PatternKind::PGroup>(_m) ? ({
        auto&& q = prism_rtl::as<crate::syntax::PatternKind::PGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(BindPattern(env, st, prism_rtl::deref(prism_rtl::deref(q)), t, prism_rtl::deref(refutable))));
    })
        : prism_rtl::is<crate::syntax::PatternKind::PFamily>(_m) ? ({
        auto&& q = prism_rtl::as<crate::syntax::PatternKind::PFamily>(_m).a0;
        prism_rtl::more(prism_rtl::rc(BindFamily(env, st, crate::check::env::dotted(q->path_), t, prism_rtl::deref(p_).span)));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start BindPattern, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>> start_bind_pattern(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Pattern_ p_, crate::check::types::Ty t, bool refutable) {
    return prism_rtl::make_rc<BindPattern>(env, st, p_, t, refutable);
}


/// IsCtorName: fn Env, SName -> Bool
bool is_ctor_name(const crate::check::expr::Env& env, const crate::syntax::SName& n) {
    auto&& _qk_opt = crate::check::env::names::resolve_value(env.g, env.home, n);
    auto&& qk_opt = std::get<0>(_qk_opt);
    if (prism_rtl::is_some(qk_opt)) {
        auto&& qk = prism_rtl::some_of(qk_opt);
        return crate::check::env::has_key(prism_rtl::deref(env.g).ctors, qk);
    }
    if (prism_rtl::is_none(qk_opt)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// BindName: unbounded fn Env, St, SName, Ty -> ((Env, St))
std::tuple<crate::check::expr::Env, crate::check::types::St> bind_name(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::SName& n, const crate::check::types::Ty& t) {
    auto name = crate::check::env::sname_key(n);
    return crate::check::types::has_text(env.pending, name)
        ? ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::check::expr::Env, crate::check::types::St>> _v;
        auto&& _m = crate::prelude::get(env.locals, name);
        if (prism_rtl::is_some(_m)) {
            auto&& sc = prism_rtl::some_of(_m);
            _v.set(({
                auto [ok_, st1] = crate::check::types::unify::try_unify(st, prism_rtl::deref(sc).ty, t, n.span);
                auto marks_agree = (crate::check::types::stack_of(st, t) == crate::check::expr::lets::type_marks(n.sigils)) || crate::check::types::is_flex_var(st, t);
                auto st_a = ok_
                    ? st1
                    : std::move(marks_agree)
                    ? crate::check::types::unify::unify(st, prism_rtl::deref(sc).ty, t, n.span)
                    : crate::check::types::recording::err_fix(st, Text::lit("mark-stack"), n.span, prism_rtl::cat("`", name, "` has type `", crate::check::types::show_ty(st, t), "`, whose stack is `", crate::check::types::stack_of(st, t), "`; the name shows `", crate::check::expr::lets::type_marks(n.sigils), "`"), prism_rtl::cat("rename to `", crate::check::expr::lets::ref_mark(n.sigils), crate::check::types::stack_of(st, t), crate::syntax::lexer::chars::drop_prefix(name, n.sigils), "`"));
                std::tuple{env, crate::check::types::recording::note_binder(st_a, n.span, name, t)};
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(bind_fresh(env, st, n, t));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    })
        : bind_fresh(env, st, n, t);
}


prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St>> BindName::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& n = this->n;
    const auto& t = this->t;
    auto name = crate::check::env::sname_key(n);
    return crate::check::types::has_text(prism_rtl::deref(env).pending, name)
        ? ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(env).locals, name);
        prism_rtl::is_some(_m) ? ({
        auto&& sc = prism_rtl::some_of(_m);
        ({
        auto env_1 = env;
        auto n_2 = n;
        auto st_3 = st;
        auto t_4 = t;
        call_then(crate::check::types::unify::start_try_unify(st_3, prism_rtl::deref(sc).ty, t_4, prism_rtl::deref(n_2).span), [=, env_1 = std::move(env_1)](std::tuple<bool, crate::check::types::St> try_unify_3987) {
        return ({
            auto [ok_, st1] = try_unify_3987;
            call_then(crate::check::types::start_stack_of(st_3, t_4), [=](Text stack_of_4051) {
            return ({
                auto marks_agree = (stack_of_4051 == crate::check::expr::lets::type_marks(prism_rtl::deref(n_2).sigils)) || crate::check::types::is_flex_var(st_3, t_4);
                auto st_a = ok_
                    ? st1
                    : std::move(marks_agree)
                    ? crate::check::types::unify::unify(st_3, prism_rtl::deref(sc).ty, t_4, prism_rtl::deref(n_2).span)
                    : crate::check::types::recording::err_fix(st_3, Text::lit("mark-stack"), prism_rtl::deref(n_2).span, prism_rtl::cat("`", name, "` has type `", crate::check::types::show_ty(st_3, t_4), "`, whose stack is `", crate::check::types::stack_of(st_3, t_4), "`; the name shows `", crate::check::expr::lets::type_marks(prism_rtl::deref(n_2).sigils), "`"), prism_rtl::cat("rename to `", crate::check::expr::lets::ref_mark(prism_rtl::deref(n_2).sigils), crate::check::types::stack_of(st_3, t_4), crate::syntax::lexer::chars::drop_prefix(name, prism_rtl::deref(n_2).sigils), "`"));
                (prism_rtl::finished(std::tuple{env_1, crate::check::types::recording::note_binder(st_a, prism_rtl::deref(n_2).span, name, t_4)}));
            });
        });
        });
    });
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::more(prism_rtl::rc(BindFresh(env, st, n, t)))
        : throw prism_rtl::Panic("no arm matched");
    })
        : prism_rtl::more(prism_rtl::rc(BindFresh(env, st, n, t)));
}


/// `Start BindName, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>> start_bind_name(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::SName n, crate::check::types::Ty t) {
    return prism_rtl::make_rc<BindName>(env, st, n, t);
}


/// BindFresh: unbounded fn Env, St, SName, Ty -> ((Env, St))
std::tuple<crate::check::expr::Env, crate::check::types::St> bind_fresh(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::SName& n, const crate::check::types::Ty& t) {
    return bind_fresh_marked(env, st, n, crate::check::expr::lets::type_marks(n.sigils), t);
}


prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St>> BindFresh::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& n = this->n;
    const auto& t = this->t;
    return prism_rtl::more(prism_rtl::rc(BindFreshMarked(env, st, n, crate::check::expr::lets::type_marks(prism_rtl::deref(n).sigils), t)));
}


/// `Start BindFresh, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>> start_bind_fresh(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::SName n, crate::check::types::Ty t) {
    return prism_rtl::make_rc<BindFresh>(env, st, n, t);
}


/// BindFreshMarked: unbounded fn Env, St, SName, Text, Ty -> ((Env, St))
std::tuple<crate::check::expr::Env, crate::check::types::St> bind_fresh_marked(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::SName& n, const Text& marks, const crate::check::types::Ty& t) {
    auto name = crate::check::env::sname_key(n);
    auto [v_, st2] = crate::check::types::fresh_var(st, true, name);
    auto [rw, st3] = crate::check::types::recording::fresh_row(st2, Array<Text>{});
    auto marked = crate::check::types::with_marks(marks, v_, rw);
    auto [ok_, st4] = crate::check::types::unify::try_unify(st3, t, marked, n.span);
    auto st5 = ok_
        ? st4
        : ({
        auto stack = crate::check::types::stack_of(st3, t);
        (crate::check::types::recording::err_fix(st3, Text::lit("mark-stack"), n.span, prism_rtl::cat("`", name, "` has type `", crate::check::types::show_ty(st3, t), "`, whose stack is `", stack, "`; the name shows `", marks, "`"), prism_rtl::cat("rename to `", crate::check::expr::lets::ref_mark(n.sigils), stack, crate::syntax::lexer::chars::drop_prefix(name, n.sigils), "`")));
    });
    return std::tuple{crate::check::expr::with_local(env, name, crate::check::types::schemes::mono(t)), crate::check::types::recording::note_binder(st5, n.span, name, t)};
}


prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St>> BindFreshMarked::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& n = this->n;
    const auto& marks = this->marks;
    const auto& t = this->t;
    auto name = crate::check::env::sname_key(n);
    auto [v_, st2] = crate::check::types::fresh_var(st, true, name);
    auto [rw, st3] = crate::check::types::recording::fresh_row(st2, Array<Text>{});
    auto marked = crate::check::types::with_marks(marks, v_, rw);
    auto env_1 = env;
    auto marks_2 = marks;
    auto n_3 = n;
    auto t_4 = t;
    return call_then(crate::check::types::unify::start_try_unify(st3, t_4, marked, prism_rtl::deref(n_3).span), [=](std::tuple<bool, crate::check::types::St> try_unify_5118) {
        return ({
            auto [ok_, st4] = try_unify_5118;
            auto st5 = ok_
                ? st4
                : ({
                auto stack = crate::check::types::stack_of(st3, t_4);
                (crate::check::types::recording::err_fix(st3, Text::lit("mark-stack"), prism_rtl::deref(n_3).span, prism_rtl::cat("`", name, "` has type `", crate::check::types::show_ty(st3, t_4), "`, whose stack is `", stack, "`; the name shows `", marks_2, "`"), prism_rtl::cat("rename to `", crate::check::expr::lets::ref_mark(prism_rtl::deref(n_3).sigils), stack, crate::syntax::lexer::chars::drop_prefix(name, prism_rtl::deref(n_3).sigils), "`")));
            });
            (prism_rtl::finished(std::tuple{crate::check::expr::with_local(env_1, name, crate::check::types::schemes::mono(t_4)), crate::check::types::recording::note_binder(st5, prism_rtl::deref(n_3).span, name, t_4)}));
        });
    });
}


/// `Start BindFreshMarked, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>> start_bind_fresh_marked(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::SName n, Text marks, crate::check::types::Ty t) {
    return prism_rtl::make_rc<BindFreshMarked>(env, st, n, marks, t);
}


/// BindField: unbounded fn Env, St, Pattern, Ty, Bool -> ((Env, St))
std::tuple<crate::check::expr::Env, crate::check::types::St> bind_field(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Pattern_& p_, const crate::check::types::Ty& ft, const bool& snapshot_) {
    auto&& _m = crate::check::types::recording::walk(st, ft);
    if (prism_rtl::is<crate::check::types::Ty::TySig>(_m)) {
        auto&& s = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a0;
        auto&& level = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a1;
        if (snapshot_ && (s == Text::lit("$"))) {
            return bind_level(env, st, p_, prism_rtl::deref(level));
        }
    }
    {
        return bind_pattern(env, st, p_, ft, true);
    }
}


prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St>> BindField::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& p_ = this->p_;
    const auto& ft = this->ft;
    const auto& snapshot_ = this->snapshot_;
    auto env_1 = env;
    auto ft_2 = ft;
    auto p__3 = p_;
    auto snapshot__4 = prism_rtl::deref(snapshot_);
    auto st_5 = st;
    return call_then(crate::check::types::recording::start_walk(st_5, ft_2), [=](crate::check::types::Ty walk_6045) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TySig>(walk_6045) && ({
            auto&& s = prism_rtl::as<crate::check::types::Ty::TySig>(walk_6045).a0;
            auto&& level = prism_rtl::as<crate::check::types::Ty::TySig>(walk_6045).a1;
            (snapshot__4 && (s == Text::lit("$")));
        }) ? ({
            auto&& s = prism_rtl::as<crate::check::types::Ty::TySig>(walk_6045).a0;
            auto&& level = prism_rtl::as<crate::check::types::Ty::TySig>(walk_6045).a1;
            prism_rtl::more(prism_rtl::rc(BindLevel(env_1, st_5, p__3, prism_rtl::deref(level))));
        })
            : prism_rtl::more(prism_rtl::rc(BindPattern(env_1, st_5, p__3, ft_2, true)));
        });
    });
}


/// `Start BindField, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>> start_bind_field(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Pattern_ p_, crate::check::types::Ty ft, bool snapshot_) {
    return prism_rtl::make_rc<BindField>(env, st, p_, ft, snapshot_);
}


/// BindLevel: unbounded fn Env, St, Pattern, Ty -> ((Env, St))
std::tuple<crate::check::expr::Env, crate::check::types::St> bind_level(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Pattern_& p_, const crate::check::types::Ty& level) {
    auto&& _m = prism_rtl::deref(p_.kind);
    if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        return crate::syntax::lexer::chars::has_prefix(prism_rtl::deref(n).sigils, Text::lit("$")) && (len(n->path_) == Nat(1u))
            ? bind_fresh_marked(env, st, n, crate::syntax::lexer::chars::after_first(prism_rtl::deref(n).sigils), level)
            : bind_pattern(env, st, p_, level, true);
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PGroup>(_m)) {
        auto&& q = prism_rtl::as<crate::syntax::PatternKind::PGroup>(_m).a0;
        return bind_level(env, st, prism_rtl::deref(prism_rtl::deref(q)), level);
    }
    {
        return bind_pattern(env, st, p_, level, true);
    }
}


prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St>> BindLevel::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& p_ = this->p_;
    const auto& level = this->level;
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(p_).kind);
        prism_rtl::is<crate::syntax::PatternKind::PName>(_m) ? ({
        auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        crate::syntax::lexer::chars::has_prefix(prism_rtl::deref(n).sigils, Text::lit("$")) && (len(n->path_) == Nat(1u))
        ? prism_rtl::more(prism_rtl::rc(BindFreshMarked(env, st, n, crate::syntax::lexer::chars::after_first(prism_rtl::deref(n).sigils), level)))
        : prism_rtl::more(prism_rtl::rc(BindPattern(env, st, p_, level, true)));
    })
        : prism_rtl::is<crate::syntax::PatternKind::PGroup>(_m) ? ({
        auto&& q = prism_rtl::as<crate::syntax::PatternKind::PGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(BindLevel(env, st, prism_rtl::deref(prism_rtl::deref(q)), level)));
    })
        : prism_rtl::more(prism_rtl::rc(BindPattern(env, st, p_, level, true)));
    });
}


/// `Start BindLevel, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>> start_bind_level(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Pattern_ p_, crate::check::types::Ty level) {
    return prism_rtl::make_rc<BindLevel>(env, st, p_, level);
}


/// BindCtor: unbounded fn Env, St, Pattern, SName, [Pattern], Ty -> ((Env, St))
std::tuple<crate::check::expr::Env, crate::check::types::St> bind_ctor(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Pattern_& p_, const crate::syntax::SName& n, const Array<crate::syntax::Pattern_>& args, const crate::check::types::Ty& t) {
    auto [qk_opt, why] = crate::check::env::names::resolve_value(env.g, env.home, n);
    if (prism_rtl::is_none(qk_opt)) {
        return std::tuple{env, crate::check::types::recording::err(st, Text::lit("unknown-name"), n.span, prism_rtl::cat("no constructor `", crate::check::env::sname_key(n), "`"))};
    }
    if (prism_rtl::is_some(qk_opt)) {
        auto&& qk = prism_rtl::some_of(qk_opt);
        return why == Text::lit("tag")
            ? bind_tag_pattern(env, st, p_, qk, Array<crate::syntax::FieldPat>{}, true, t)
            : ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<crate::check::expr::Env, crate::check::types::St>> _v;
            auto&& _m = crate::prelude::get(prism_rtl::deref(env.g).ctors, qk);
            if (prism_rtl::is_none(_m)) {
                _v.set(std::tuple{env, crate::check::types::recording::err(st, Text::lit("unknown-name"), n.span, prism_rtl::cat("`", crate::check::env::sname_key(n), "` is not a constructor"))});
                goto _done;
            }
            if (prism_rtl::is_some(_m)) {
                auto&& c = prism_rtl::some_of(_m);
                _v.set(({
                    auto [self_, st1, inst] = crate::check::types::schemes::instantiate_with(st, crate::check::types::Scheme{.qs = prism_rtl::deref(c).params, .plain_qs = Array<Text>{}, .rqs = Array<Text>{}, .cqs = Array<Text>{}, .cjoins = Array<std::tuple<Text, Text>>{}, .bounds = Array<std::tuple<Text, Text>>{}, .ty = prism_rtl::deref(c).ty}, p_.span, Array<crate::check::types::Ty>{});
                    auto st2 = crate::check::types::unify::unify(st1, t, self_, p_.span);
                    (len(args) != len(c->args)) && (!((len(args) == Nat(1u)) && (len(c->args) > Nat(1u))))
                    ? std::tuple{env, crate::check::types::recording::err(st2, Text::lit("mismatch"), p_.span, prism_rtl::cat("`", crate::check::types::bare_name(prism_rtl::deref(c).name), "` takes ", crate::check::errors::count_word(len(c->args)), " argument", len(c->args) == Nat(1u) ? Text::lit("") : Text::lit("s"), "; this pattern gives ", crate::check::errors::count_word(len(args))))}
                    : run_to_end(fold_job(crate::check::errors::range0(len(args)), std::tuple{env, st2}, ({
                    auto args_1 = args;
                    auto p__2 = p_;
                    auto inst_3 = inst;
                    auto c_4 = c;
                    static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>>(std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=, args_1 = std::move(args_1), p__2 = std::move(p__2), inst_3 = std::move(inst_3), c_4 = std::move(c_4)](std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto args_1_5 = args_1;
                        auto p__2_5 = p__2;
                        auto inst_3_5 = inst_3;
                        auto c_4_5 = c_4;
                        entered(once_job([=, args_1_5 = std::move(args_1_5), p__2_5 = std::move(p__2_5), inst_3_5 = std::move(inst_3_5), c_4_5 = std::move(c_4_5)]() {
                        return ({
                            auto [en, s] = p0;
                            auto i = p1;
                            call_then(crate::check::types::schemes::start_subst_q(inst_3_5, or_(index(c_4_5->args, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{}))), [=](crate::check::types::Ty subst_q_7767) { return prism_rtl::more(prism_rtl::rc(BindPattern(en, s, or_(index(args_1_5, i), crate::syntax::Pattern_{.kind = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PIgnore{})), .span = p__2_5.span}), subst_q_7767, true))); });
                        });
                    }));
                    });
                }));
                })));
                }));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St>> BindCtor::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& p_ = this->p_;
    const auto& n = this->n;
    const auto& args = this->args;
    const auto& t = this->t;
    auto [qk_opt, why] = crate::check::env::names::resolve_value(prism_rtl::deref(env).g, prism_rtl::deref(env).home, n);
    return ({
        prism_rtl::is_none(qk_opt) ? prism_rtl::finished(std::tuple{env, crate::check::types::recording::err(st, Text::lit("unknown-name"), prism_rtl::deref(n).span, prism_rtl::cat("no constructor `", crate::check::env::sname_key(n), "`"))})
        : prism_rtl::is_some(qk_opt) ? ({
        auto&& qk = prism_rtl::some_of(qk_opt);
        why == Text::lit("tag")
        ? prism_rtl::more(prism_rtl::rc(BindTagPattern(env, st, p_, qk, Array<crate::syntax::FieldPat>{}, true, t)))
        : ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(prism_rtl::deref(env).g).ctors, qk);
        prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{env, crate::check::types::recording::err(st, Text::lit("unknown-name"), prism_rtl::deref(n).span, prism_rtl::cat("`", crate::check::env::sname_key(n), "` is not a constructor"))})
        : prism_rtl::is_some(_m) ? ({
        auto&& c = prism_rtl::some_of(_m);
        ({
        auto args_1 = args;
        auto env_2 = env;
        auto p__3 = p_;
        auto st_4 = st;
        auto t_5 = t;
        call_then(crate::check::types::schemes::start_instantiate_with(st_4, crate::check::types::Scheme{.qs = prism_rtl::deref(c).params, .plain_qs = Array<Text>{}, .rqs = Array<Text>{}, .cqs = Array<Text>{}, .cjoins = Array<std::tuple<Text, Text>>{}, .bounds = Array<std::tuple<Text, Text>>{}, .ty = prism_rtl::deref(c).ty}, prism_rtl::deref(p__3).span, Array<crate::check::types::Ty>{}), [=, args_1 = std::move(args_1), env_2 = std::move(env_2), t_5 = std::move(t_5)](std::tuple<crate::check::types::Ty, crate::check::types::St, crate::check::types::schemes::Inst> instantiate_with_7130) {
        return ({
            auto [self_, st1, inst] = instantiate_with_7130;
            call_then(crate::check::types::unify::start_unify(st1, t_5, self_, prism_rtl::deref(p__3).span), [=](crate::check::types::St unify_7285) {
            return ({
                auto st2 = unify_7285;
                (len(args_1) != len(c->args)) && (!((len(args_1) == Nat(1u)) && (len(c->args) > Nat(1u))))
                ? prism_rtl::finished(std::tuple{env_2, crate::check::types::recording::err(st2, Text::lit("mismatch"), prism_rtl::deref(p__3).span, prism_rtl::cat("`", crate::check::types::bare_name(prism_rtl::deref(c).name), "` takes ", crate::check::errors::count_word(len(c->args)), " argument", len(c->args) == Nat(1u) ? Text::lit("") : Text::lit("s"), "; this pattern gives ", crate::check::errors::count_word(len(args_1))))})
                : fold_job(crate::check::errors::range0(len(args_1)), std::tuple{env_2, st2}, ({
                auto args_1_6 = args_1;
                auto p__3_6 = p__3;
                auto inst_6 = inst;
                auto c_7 = c;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>>(std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=, args_1_6 = std::move(args_1_6), p__3_6 = std::move(p__3_6), inst_6 = std::move(inst_6), c_7 = std::move(c_7)](std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto args_1_6_8 = args_1_6;
                    auto p__3_6_8 = p__3_6;
                    auto inst_6_8 = inst_6;
                    auto c_7_8 = c_7;
                    entered(once_job([=, args_1_6_8 = std::move(args_1_6_8), p__3_6_8 = std::move(p__3_6_8), inst_6_8 = std::move(inst_6_8), c_7_8 = std::move(c_7_8)]() {
                    return ({
                        auto [en, s] = p0;
                        auto i = p1;
                        call_then(crate::check::types::schemes::start_subst_q(inst_6_8, or_(index(c_7_8->args, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{}))), [=](crate::check::types::Ty subst_q_7767) { return prism_rtl::more(prism_rtl::rc(BindPattern(en, s, or_(index(args_1_6_8, i), crate::syntax::Pattern_{.kind = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PIgnore{})), .span = prism_rtl::deref(p__3_6_8).span}), subst_q_7767, true))); });
                    });
                }));
                });
            }));
            }))->cycle();
            });
        });
        });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start BindCtor, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>> start_bind_ctor(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Pattern_ p_, crate::syntax::SName n, Array<crate::syntax::Pattern_> args, crate::check::types::Ty t) {
    return prism_rtl::make_rc<BindCtor>(env, st, p_, n, args, t);
}


/// BindRecord: unbounded fn Env, St, Pattern, SName, [FieldPat], Bool, Ty -> ((Env, St))
std::tuple<crate::check::expr::Env, crate::check::types::St> bind_record(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Pattern_& p_, const crate::syntax::SName& n, const Array<crate::syntax::FieldPat>& fields, const bool& rest, const crate::check::types::Ty& t) {
    auto [qk_opt, why] = crate::check::env::names::resolve_value(env.g, env.home, n);
    if (prism_rtl::is_none(qk_opt)) {
        return std::tuple{env, crate::check::types::recording::err(st, Text::lit("unknown-name"), n.span, prism_rtl::cat("no record or tag `", crate::check::env::sname_key(n), "`"))};
    }
    if (prism_rtl::is_some(qk_opt)) {
        auto&& qk = prism_rtl::some_of(qk_opt);
        return why == Text::lit("tag")
            ? bind_tag_pattern(env, st, p_, qk, fields, rest, t)
            : ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<crate::check::expr::Env, crate::check::types::St>> _v;
            auto&& _m = crate::prelude::get(prism_rtl::deref(env.g).ctors, qk);
            if (prism_rtl::is_none(_m)) {
                _v.set(std::tuple{env, crate::check::types::recording::err(st, Text::lit("unknown-name"), n.span, prism_rtl::cat("`", crate::check::env::sname_key(n), "` is not a record"))});
                goto _done;
            }
            if (prism_rtl::is_some(_m)) {
                auto&& c = prism_rtl::some_of(_m);
                _v.set(({
                    auto [self_, st1, inst] = crate::check::types::schemes::instantiate_with(st, crate::check::types::Scheme{.qs = prism_rtl::deref(c).params, .plain_qs = Array<Text>{}, .rqs = Array<Text>{}, .cqs = Array<Text>{}, .cjoins = Array<std::tuple<Text, Text>>{}, .bounds = Array<std::tuple<Text, Text>>{}, .ty = prism_rtl::deref(c).ty}, p_.span, Array<crate::check::types::Ty>{});
                    auto st2 = crate::check::types::unify::unify(st1, t, self_, p_.span);
                    run_to_end(fold_job(crate::check::errors::range0(len(fields)), std::tuple{env, st2}, ({
                    auto fields_1 = fields;
                    auto p__2 = p_;
                    auto c_3 = c;
                    auto inst_4 = inst;
                    static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>>(std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=, fields_1 = std::move(fields_1), p__2 = std::move(p__2), c_3 = std::move(c_3), inst_4 = std::move(inst_4)](std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto fields_1_5 = fields_1;
                        auto p__2_5 = p__2;
                        auto c_3_5 = c_3;
                        auto inst_4_5 = inst_4;
                        entered(once_job([=, fields_1_5 = std::move(fields_1_5), p__2_5 = std::move(p__2_5), c_3_5 = std::move(c_3_5), inst_4_5 = std::move(inst_4_5)]() {
                        return ({
                            auto [en, s] = p0;
                            auto i = p1;
                            ({
                            auto fp = or_(index(fields_1_5, i), crate::syntax::FieldPat{.name = std::optional<crate::syntax::Ident>{}, .pattern = crate::syntax::Pattern_{.kind = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PIgnore{})), .span = p__2_5.span}, .span = p__2_5.span});
                            auto fname = field_pat_name(fp, prism_rtl::deref(c_3_5).fields, i);
                            ({
                            auto&& _m = crate::check::expr::operators::index_of(prism_rtl::deref(c_3_5).fields, fname);
                            prism_rtl::is_some(_m) ? ({
                            auto&& j = prism_rtl::some_of(_m);
                            call_then(crate::check::types::schemes::start_subst_q(inst_4_5, or_(index(c_3_5->args, j), crate::check::types::Ty(crate::check::types::Ty::TyErr{}))), [=](crate::check::types::Ty subst_q_9120) { return prism_rtl::more(prism_rtl::rc(BindPattern(en, s, prism_rtl::deref(fp).pattern, subst_q_9120, true))); });
                        })
                            : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{en, crate::check::types::recording::err(s, Text::lit("mismatch"), prism_rtl::deref(fp).span, prism_rtl::cat("`", crate::check::types::bare_name(prism_rtl::deref(c_3_5).owner), "` has no field `", fname, "`"))})
                            : throw prism_rtl::Panic("no arm matched");
                        });
                        });
                        });
                    }));
                    });
                }));
                })));
                }));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St>> BindRecord::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& p_ = this->p_;
    const auto& n = this->n;
    const auto& fields = this->fields;
    const auto& rest = this->rest;
    const auto& t = this->t;
    auto [qk_opt, why] = crate::check::env::names::resolve_value(prism_rtl::deref(env).g, prism_rtl::deref(env).home, n);
    return ({
        prism_rtl::is_none(qk_opt) ? prism_rtl::finished(std::tuple{env, crate::check::types::recording::err(st, Text::lit("unknown-name"), prism_rtl::deref(n).span, prism_rtl::cat("no record or tag `", crate::check::env::sname_key(n), "`"))})
        : prism_rtl::is_some(qk_opt) ? ({
        auto&& qk = prism_rtl::some_of(qk_opt);
        why == Text::lit("tag")
        ? prism_rtl::more(prism_rtl::rc(BindTagPattern(env, st, p_, qk, fields, prism_rtl::deref(rest), t)))
        : ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(prism_rtl::deref(env).g).ctors, qk);
        prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{env, crate::check::types::recording::err(st, Text::lit("unknown-name"), prism_rtl::deref(n).span, prism_rtl::cat("`", crate::check::env::sname_key(n), "` is not a record"))})
        : prism_rtl::is_some(_m) ? ({
        auto&& c = prism_rtl::some_of(_m);
        ({
        auto env_1 = env;
        auto fields_2 = fields;
        auto p__3 = p_;
        auto st_4 = st;
        auto t_5 = t;
        call_then(crate::check::types::schemes::start_instantiate_with(st_4, crate::check::types::Scheme{.qs = prism_rtl::deref(c).params, .plain_qs = Array<Text>{}, .rqs = Array<Text>{}, .cqs = Array<Text>{}, .cjoins = Array<std::tuple<Text, Text>>{}, .bounds = Array<std::tuple<Text, Text>>{}, .ty = prism_rtl::deref(c).ty}, prism_rtl::deref(p__3).span, Array<crate::check::types::Ty>{}), [=, env_1 = std::move(env_1), fields_2 = std::move(fields_2), t_5 = std::move(t_5)](std::tuple<crate::check::types::Ty, crate::check::types::St, crate::check::types::schemes::Inst> instantiate_with_8551) {
        return ({
            auto [self_, st1, inst] = instantiate_with_8551;
            call_then(crate::check::types::unify::start_unify(st1, t_5, self_, prism_rtl::deref(p__3).span), [=](crate::check::types::St unify_8706) {
            return ({
                auto st2 = unify_8706;
                fold_job(crate::check::errors::range0(len(fields_2)), std::tuple{env_1, st2}, ({
                auto fields_2_6 = fields_2;
                auto p__3_6 = p__3;
                auto c_6 = c;
                auto inst_7 = inst;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>>(std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=, fields_2_6 = std::move(fields_2_6), p__3_6 = std::move(p__3_6), c_6 = std::move(c_6), inst_7 = std::move(inst_7)](std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto fields_2_6_8 = fields_2_6;
                    auto p__3_6_8 = p__3_6;
                    auto c_6_8 = c_6;
                    auto inst_7_8 = inst_7;
                    entered(once_job([=, fields_2_6_8 = std::move(fields_2_6_8), p__3_6_8 = std::move(p__3_6_8), c_6_8 = std::move(c_6_8), inst_7_8 = std::move(inst_7_8)]() {
                    return ({
                        auto [en, s] = p0;
                        auto i = p1;
                        ({
                        auto fp = or_(index(fields_2_6_8, i), crate::syntax::FieldPat{.name = std::optional<crate::syntax::Ident>{}, .pattern = crate::syntax::Pattern_{.kind = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PIgnore{})), .span = prism_rtl::deref(p__3_6_8).span}, .span = prism_rtl::deref(p__3_6_8).span});
                        auto fname = field_pat_name(fp, prism_rtl::deref(c_6_8).fields, i);
                        ({
                        auto&& _m = crate::check::expr::operators::index_of(prism_rtl::deref(c_6_8).fields, fname);
                        prism_rtl::is_some(_m) ? ({
                        auto&& j = prism_rtl::some_of(_m);
                        call_then(crate::check::types::schemes::start_subst_q(inst_7_8, or_(index(c_6_8->args, j), crate::check::types::Ty(crate::check::types::Ty::TyErr{}))), [=](crate::check::types::Ty subst_q_9120) { return prism_rtl::more(prism_rtl::rc(BindPattern(en, s, prism_rtl::deref(fp).pattern, subst_q_9120, true))); });
                    })
                        : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{en, crate::check::types::recording::err(s, Text::lit("mismatch"), prism_rtl::deref(fp).span, prism_rtl::cat("`", crate::check::types::bare_name(prism_rtl::deref(c_6_8).owner), "` has no field `", fname, "`"))})
                        : throw prism_rtl::Panic("no arm matched");
                    });
                    });
                    });
                }));
                });
            }));
            }))->cycle();
            });
        });
        });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start BindRecord, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>> start_bind_record(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Pattern_ p_, crate::syntax::SName n, Array<crate::syntax::FieldPat> fields, bool rest, crate::check::types::Ty t) {
    return prism_rtl::make_rc<BindRecord>(env, st, p_, n, fields, rest, t);
}


/// FieldPatName: fn FieldPat, [Text], Nat -> Text
Text field_pat_name(const crate::syntax::FieldPat& fp, const Array<Text>& fields, const Nat& i) {
    auto&& _m = fp.name;
    if (prism_rtl::is_some(_m)) {
        auto&& id = prism_rtl::some_of(_m);
        return prism_rtl::deref(id).name;
    }
    if (prism_rtl::is_none(_m)) {
        auto&& _m = prism_rtl::deref(prism_rtl::deref(fp.pattern).kind);
        if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
            auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
            return crate::check::types::has_text(fields, crate::check::env::sname_key(n))
                ? crate::check::env::sname_key(n)
                : or_(index(fields, i), Text::lit(""));
        }
        {
            return or_(index(fields, i), Text::lit(""));
        }
    }
    prism_rtl::unreachable("no arm matched");
}


/// BindTagPattern: unbounded fn Env, St, Pattern, Text, [FieldPat], Bool, Ty -> ((Env, St))
std::tuple<crate::check::expr::Env, crate::check::types::St> bind_tag_pattern(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Pattern_& p_, const Text& name, const Array<crate::syntax::FieldPat>& fields, const bool& rest, const crate::check::types::Ty& t) {
    auto&& _m = crate::prelude::get(prism_rtl::deref(env.g).tags, name);
    if (prism_rtl::is_none(_m)) {
        return std::tuple{env, crate::check::types::recording::err(st, Text::lit("unknown-name"), p_.span, prism_rtl::cat("no tag `", name, "`"))};
    }
    if (prism_rtl::is_some(_m)) {
        auto&& tg = prism_rtl::some_of(_m);
        auto st1 = prism_rtl::deref(tg).kind == Text::lit("Element")
            ? tag_in_row(env, st, tg, t, p_.span)
            : crate::check::types::unify::unify(st, t, crate::check::types::Ty(crate::check::types::Ty::TyCon{prism_rtl::deref(tg).kind, Array<crate::check::types::Ty>{}}), p_.span);
        auto snapshot_ = is_snapshot(st1, t);
        auto&& _st2 = crate::check::types::schemes::instantiate_with(st1, crate::check::types::Scheme{.qs = prism_rtl::deref(tg).qs, .plain_qs = Array<Text>{}, .rqs = prism_rtl::deref(tg).rqs, .cqs = Array<Text>{}, .cjoins = Array<std::tuple<Text, Text>>{}, .bounds = Array<std::tuple<Text, Text>>{}, .ty = tg->out}, p_.span, Array<crate::check::types::Ty>{});
        auto&& st2 = std::get<1>(_st2);
        auto&& inst = std::get<2>(_st2);
        auto names = each(prism_rtl::deref(tg).fields, [&](const std::tuple<Text, crate::check::types::Ty>& _p0) {
            auto&& f = std::get<0>(_p0);
            return f;
        });
        return run_to_end(fold_job(crate::check::errors::range0(len(fields)), std::tuple{env, st2}, ({
            auto fields_1 = fields;
            auto p__2 = p_;
            auto names_3 = names;
            auto tg_4 = tg;
            auto inst_5 = inst;
            auto snapshot__6 = std::move(snapshot_);
            auto name_7 = name;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>>(std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=, fields_1 = std::move(fields_1), p__2 = std::move(p__2), names_3 = std::move(names_3), tg_4 = std::move(tg_4), inst_5 = std::move(inst_5), snapshot__6 = std::move(snapshot__6), name_7 = std::move(name_7)](std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto fields_1_8 = fields_1;
                auto p__2_8 = p__2;
                auto names_3_8 = names_3;
                auto tg_4_8 = tg_4;
                auto inst_5_8 = inst_5;
                auto snapshot__6_8 = snapshot__6;
                auto name_7_8 = name_7;
                entered(once_job([=, fields_1_8 = std::move(fields_1_8), p__2_8 = std::move(p__2_8), names_3_8 = std::move(names_3_8), tg_4_8 = std::move(tg_4_8), inst_5_8 = std::move(inst_5_8), snapshot__6_8 = std::move(snapshot__6_8), name_7_8 = std::move(name_7_8)]() {
                return ({
                    auto [en, s] = p0;
                    auto i = p1;
                    ({
                    auto fp = or_(index(fields_1_8, i), crate::syntax::FieldPat{.name = std::optional<crate::syntax::Ident>{}, .pattern = crate::syntax::Pattern_{.kind = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PIgnore{})), .span = p__2_8.span}, .span = p__2_8.span});
                    auto fname = field_pat_name(fp, names_3_8, i);
                    ({
                    auto&& _m = crate::check::expr::calls::field_of_tag(tg_4_8, fname);
                    prism_rtl::is_some(_m) ? ({
                    auto&& ft = prism_rtl::some_of(_m);
                    call_then(crate::check::types::schemes::start_subst_q(inst_5_8, ft), [=](crate::check::types::Ty subst_q_10806) { return prism_rtl::more(prism_rtl::rc(BindField(en, s, prism_rtl::deref(fp).pattern, subst_q_10806, snapshot__6_8))); });
                })
                    : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{en, crate::check::types::recording::err(s, Text::lit("mismatch"), prism_rtl::deref(fp).span, prism_rtl::cat("`", name_7_8, "` has no field `", fname, "`"))})
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
                });
            }));
            });
        }));
        })));
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St>> BindTagPattern::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& p_ = this->p_;
    const auto& name = this->name;
    const auto& fields = this->fields;
    const auto& rest = this->rest;
    const auto& t = this->t;
    return ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(prism_rtl::deref(env).g).tags, name);
        prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{env, crate::check::types::recording::err(st, Text::lit("unknown-name"), prism_rtl::deref(p_).span, prism_rtl::cat("no tag `", name, "`"))})
        : prism_rtl::is_some(_m) ? ({
        auto&& tg = prism_rtl::some_of(_m);
        ({
        auto st1 = prism_rtl::deref(tg).kind == Text::lit("Element")
            ? tag_in_row(env, st, tg, t, prism_rtl::deref(p_).span)
            : crate::check::types::unify::unify(st, t, crate::check::types::Ty(crate::check::types::Ty::TyCon{prism_rtl::deref(tg).kind, Array<crate::check::types::Ty>{}}), prism_rtl::deref(p_).span);
        auto env_1 = env;
        auto fields_2 = fields;
        auto name_3 = name;
        auto p__4 = p_;
        auto t_5 = t;
        call_then(start_is_snapshot(st1, t_5), [=, env_1 = std::move(env_1), fields_2 = std::move(fields_2), name_3 = std::move(name_3), p__4 = std::move(p__4)](bool is_snapshot_10250) {
        return ({
            auto snapshot_ = is_snapshot_10250;
            call_then(crate::check::types::schemes::start_instantiate_with(st1, crate::check::types::Scheme{.qs = prism_rtl::deref(tg).qs, .plain_qs = Array<Text>{}, .rqs = prism_rtl::deref(tg).rqs, .cqs = Array<Text>{}, .cjoins = Array<std::tuple<Text, Text>>{}, .bounds = Array<std::tuple<Text, Text>>{}, .ty = tg->out}, prism_rtl::deref(p__4).span, Array<crate::check::types::Ty>{}), [=, snapshot_ = std::move(snapshot_)](std::tuple<crate::check::types::Ty, crate::check::types::St, crate::check::types::schemes::Inst> instantiate_with_10304) {
            return ({
                auto&& _st2 = instantiate_with_10304;
                auto&& st2 = std::get<1>(_st2);
                auto&& inst = std::get<2>(_st2);
                auto names = each(prism_rtl::deref(tg).fields, [&](const std::tuple<Text, crate::check::types::Ty>& _p0) {
                    auto&& f = std::get<0>(_p0);
                    return f;
                });
                fold_job(crate::check::errors::range0(len(fields_2)), std::tuple{env_1, st2}, ({
                auto fields_2_6 = fields_2;
                auto p__4_6 = p__4;
                auto names_6 = names;
                auto tg_7 = tg;
                auto inst_8 = inst;
                auto snapshot__9 = snapshot_;
                auto name_3_10 = name_3;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>>(std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=, fields_2_6 = std::move(fields_2_6), p__4_6 = std::move(p__4_6), names_6 = std::move(names_6), tg_7 = std::move(tg_7), inst_8 = std::move(inst_8), snapshot__9 = std::move(snapshot__9), name_3_10 = std::move(name_3_10)](std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto fields_2_6_10 = fields_2_6;
                    auto p__4_6_10 = p__4_6;
                    auto names_6_10 = names_6;
                    auto tg_7_10 = tg_7;
                    auto inst_8_10 = inst_8;
                    auto snapshot__9_10 = snapshot__9;
                    auto name_3_10_10 = name_3_10;
                    entered(once_job([=, fields_2_6_10 = std::move(fields_2_6_10), p__4_6_10 = std::move(p__4_6_10), names_6_10 = std::move(names_6_10), tg_7_10 = std::move(tg_7_10), inst_8_10 = std::move(inst_8_10), snapshot__9_10 = std::move(snapshot__9_10), name_3_10_10 = std::move(name_3_10_10)]() {
                    return ({
                        auto [en, s] = p0;
                        auto i = p1;
                        ({
                        auto fp = or_(index(fields_2_6_10, i), crate::syntax::FieldPat{.name = std::optional<crate::syntax::Ident>{}, .pattern = crate::syntax::Pattern_{.kind = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PIgnore{})), .span = prism_rtl::deref(p__4_6_10).span}, .span = prism_rtl::deref(p__4_6_10).span});
                        auto fname = field_pat_name(fp, names_6_10, i);
                        ({
                        auto&& _m = crate::check::expr::calls::field_of_tag(tg_7_10, fname);
                        prism_rtl::is_some(_m) ? ({
                        auto&& ft = prism_rtl::some_of(_m);
                        call_then(crate::check::types::schemes::start_subst_q(inst_8_10, ft), [=](crate::check::types::Ty subst_q_10806) { return prism_rtl::more(prism_rtl::rc(BindField(en, s, prism_rtl::deref(fp).pattern, subst_q_10806, snapshot__9_10))); });
                    })
                        : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{en, crate::check::types::recording::err(s, Text::lit("mismatch"), prism_rtl::deref(fp).span, prism_rtl::cat("`", name_3_10_10, "` has no field `", fname, "`"))})
                        : throw prism_rtl::Panic("no arm matched");
                    });
                    });
                    });
                }));
                });
            }));
            }))->cycle();
            });
        });
        });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start BindTagPattern, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>> start_bind_tag_pattern(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Pattern_ p_, Text name, Array<crate::syntax::FieldPat> fields, bool rest, crate::check::types::Ty t) {
    return prism_rtl::make_rc<BindTagPattern>(env, st, p_, name, fields, rest, t);
}


/// IsSnapshot: unbounded fn St, Ty -> Bool
bool is_snapshot(const crate::check::types::St& st, const crate::check::types::Ty& t) {
    auto&& _m = crate::check::types::recording::walk(st, t);
    if (prism_rtl::is<crate::check::types::Ty::TyElemAny>(_m)) {
        return true;
    }
    {
        return false;
    }
}


prism_rtl::Turn<bool> IsSnapshot::cycle() const {
    const auto& st = this->st;
    const auto& t = this->t;
    auto st_1 = st;
    auto t_2 = t;
    return call_then(crate::check::types::recording::start_walk(st_1, t_2), [=](crate::check::types::Ty walk_11143) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TyElemAny>(walk_11143) ? prism_rtl::finished(true)
            : prism_rtl::finished(false);
        });
    });
}


/// `Start IsSnapshot, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_is_snapshot(crate::check::types::St st, crate::check::types::Ty t) {
    return prism_rtl::make_rc<IsSnapshot>(st, t);
}


/// TagInRow: unbounded fn Env, St, TagInfo, Ty, Range -> St
crate::check::types::St tag_in_row(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::check::env::TagInfo& tg, const crate::check::types::Ty& t, const crate::syntax::Range& span) {
    auto&& _m = crate::check::types::recording::walk(st, t);
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(_m)) {
        auto&& rw = prism_rtl::as<crate::check::types::Ty::TyElem>(_m).a0;
        auto w = crate::check::types::recording::walk_row(st, rw);
        return crate::check::types::has_text(prism_rtl::deref(w).fams, tg.family)
            ? st
            : crate::check::types::recording::err_fix(st, Text::lit("row-not-here"), span, prism_rtl::cat("`", tg.name, "` is not in this row, `", crate::check::types::show_row(w), "`"), prism_rtl::cat("add `", tg.family, ".*` to the row, or answer the tag elsewhere"));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElemAny>(_m)) {
        auto&& rw = prism_rtl::as<crate::check::types::Ty::TyElemAny>(_m).a0;
        auto w = crate::check::types::recording::walk_row(st, rw);
        return crate::check::types::has_text(prism_rtl::deref(w).fams, tg.family)
            ? st
            : crate::check::types::recording::err_fix(st, Text::lit("row-not-here"), span, prism_rtl::cat("`", tg.name, "` is not in this row, `", crate::check::types::show_row(w), "`"), prism_rtl::cat("add `", tg.family, ".*` to the row, or answer the tag elsewhere"));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFlex>(_m)) {
        auto [rw, st2] = crate::check::types::recording::fresh_row(st, Array(std::vector{tg.family}));
        auto [o, st3] = crate::check::types::fresh_var(st2, false, Text::lit(""));
        return crate::check::types::unify::unify(st3, t, crate::check::types::Ty(crate::check::types::Ty::TyElem{crate::check::types::Rw{.fams = Array(std::vector{tg.family}), .minus = Array<Text>{}, .tail = prism_rtl::deref(rw).tail}, prism_rtl::rc(o)}), span);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyErr>(_m)) {
        return st;
    }
    {
        auto&& other = _m;
        return crate::check::types::recording::err(st, Text::lit("mismatch"), span, prism_rtl::cat("a tag pattern matches an element; this is `", crate::check::types::show_ty(st, other), "`"));
    }
}


prism_rtl::Turn<crate::check::types::St> TagInRow::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& tg = this->tg;
    const auto& t = this->t;
    const auto& span = this->span;
    auto span_1 = span;
    auto st_2 = st;
    auto t_3 = t;
    auto tg_4 = tg;
    return call_then(crate::check::types::recording::start_walk(st_2, t_3), [=](crate::check::types::Ty walk_11302) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TyElem>(walk_11302) ? ({
            auto&& rw = prism_rtl::as<crate::check::types::Ty::TyElem>(walk_11302).a0;
            call_then(crate::check::types::recording::start_walk_row(st_2, rw), [=](crate::check::types::Rw walk_row_11353) {
            return ({
                auto w = walk_row_11353;
                (crate::check::types::has_text(prism_rtl::deref(w).fams, prism_rtl::deref(tg_4).family)
                ? prism_rtl::finished(st_2)
                : prism_rtl::finished(crate::check::types::recording::err_fix(st_2, Text::lit("row-not-here"), span_1, prism_rtl::cat("`", prism_rtl::deref(tg_4).name, "` is not in this row, `", crate::check::types::show_row(w), "`"), prism_rtl::cat("add `", prism_rtl::deref(tg_4).family, ".*` to the row, or answer the tag elsewhere"))));
            });
        });
        })
            : prism_rtl::is<crate::check::types::Ty::TyElemAny>(walk_11302) ? ({
            auto&& rw = prism_rtl::as<crate::check::types::Ty::TyElemAny>(walk_11302).a0;
            call_then(crate::check::types::recording::start_walk_row(st_2, rw), [=](crate::check::types::Rw walk_row_11601) {
            return ({
                auto w = walk_row_11601;
                (crate::check::types::has_text(prism_rtl::deref(w).fams, prism_rtl::deref(tg_4).family)
                ? prism_rtl::finished(st_2)
                : prism_rtl::finished(crate::check::types::recording::err_fix(st_2, Text::lit("row-not-here"), span_1, prism_rtl::cat("`", prism_rtl::deref(tg_4).name, "` is not in this row, `", crate::check::types::show_row(w), "`"), prism_rtl::cat("add `", prism_rtl::deref(tg_4).family, ".*` to the row, or answer the tag elsewhere"))));
            });
        });
        })
            : prism_rtl::is<crate::check::types::Ty::TyFlex>(walk_11302) ? ({
            auto [rw, st2] = crate::check::types::recording::fresh_row(st_2, Array(std::vector{prism_rtl::deref(tg_4).family}));
            auto [o, st3] = crate::check::types::fresh_var(st2, false, Text::lit(""));
            (prism_rtl::more(prism_rtl::rc(crate::check::types::unify::Unify(st3, t_3, crate::check::types::Ty(crate::check::types::Ty::TyElem{crate::check::types::Rw{.fams = Array(std::vector{prism_rtl::deref(tg_4).family}), .minus = Array<Text>{}, .tail = prism_rtl::deref(rw).tail}, prism_rtl::rc(o)}), span_1))));
        })
            : prism_rtl::is<crate::check::types::Ty::TyErr>(walk_11302) ? prism_rtl::finished(st_2)
            : ({
            auto&& other = walk_11302;
            call_then(crate::check::types::start_show_ty(st_2, other), [=](Text show_ty_12123) { return prism_rtl::finished(crate::check::types::recording::err(st_2, Text::lit("mismatch"), span_1, prism_rtl::cat("a tag pattern matches an element; this is `", show_ty_12123, "`"))); });
        });
        });
    });
}


/// `Start TagInRow, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_tag_in_row(crate::check::expr::Env env, crate::check::types::St st, crate::check::env::TagInfo tg, crate::check::types::Ty t, crate::syntax::Range span) {
    return prism_rtl::make_rc<TagInRow>(env, st, tg, t, span);
}


/// BindFamily: unbounded fn Env, St, Text, Ty, Range -> ((Env, St))
std::tuple<crate::check::expr::Env, crate::check::types::St> bind_family(const crate::check::expr::Env& env, const crate::check::types::St& st, const Text& fam, const crate::check::types::Ty& t, const crate::syntax::Range& span) {
    auto&& _m = crate::check::types::recording::walk(st, t);
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(_m)) {
        auto&& rw = prism_rtl::as<crate::check::types::Ty::TyElem>(_m).a0;
        auto w = crate::check::types::recording::walk_row(st, rw);
        return crate::check::types::has_text(prism_rtl::deref(w).fams, fam)
            ? std::tuple{env, st}
            : std::tuple{env, crate::check::types::recording::err_fix(st, Text::lit("row-not-here"), span, prism_rtl::cat("`", fam, ".*` is not in this row, `", crate::check::types::show_row(w), "`"), prism_rtl::cat("add `", fam, ".*` to the row"))};
    }
    {
        return std::tuple{env, st};
    }
}


prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St>> BindFamily::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& fam = this->fam;
    const auto& t = this->t;
    const auto& span = this->span;
    auto env_1 = env;
    auto fam_2 = fam;
    auto span_3 = span;
    auto st_4 = st;
    auto t_5 = t;
    return call_then(crate::check::types::recording::start_walk(st_4, t_5), [=](crate::check::types::Ty walk_12253) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TyElem>(walk_12253) ? ({
            auto&& rw = prism_rtl::as<crate::check::types::Ty::TyElem>(walk_12253).a0;
            call_then(crate::check::types::recording::start_walk_row(st_4, rw), [=](crate::check::types::Rw walk_row_12304) {
            return ({
                auto w = walk_row_12304;
                (crate::check::types::has_text(prism_rtl::deref(w).fams, fam_2)
                ? prism_rtl::finished(std::tuple{env_1, st_4})
                : prism_rtl::finished(std::tuple{env_1, crate::check::types::recording::err_fix(st_4, Text::lit("row-not-here"), span_3, prism_rtl::cat("`", fam_2, ".*` is not in this row, `", crate::check::types::show_row(w), "`"), prism_rtl::cat("add `", fam_2, ".*` to the row"))}));
            });
        });
        })
            : prism_rtl::finished(std::tuple{env_1, st_4});
        });
    });
}


/// `Start BindFamily, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>> start_bind_family(crate::check::expr::Env env, crate::check::types::St st, Text fam, crate::check::types::Ty t, crate::syntax::Range span) {
    return prism_rtl::make_rc<BindFamily>(env, st, fam, t, span);
}

}  // namespace crate::check::expr::patterns
