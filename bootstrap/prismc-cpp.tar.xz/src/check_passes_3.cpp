// The module `CheckPasses`, from `target/bootstrap/cpp-src/prismc/check-passes.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (docs/backend.md). Edit the Prism source, not this file.
#include "crate.hpp"

namespace crate::check_passes {

/// `Start ExprKids, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Kid>> start_expr_kids(ast::Expr e, Map<Text, Rel> m) {
    return std::make_shared<ExprKids>(e, m);
}


/// StmtKids: unbounded fn Stmt, (Text ==> Rel) -> [Kid]
Array<Kid> stmt_kids(const ast::Stmt& s, const Map<Text, Rel>& m) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Array<Kid>> _v;
        auto&& _m = s.kind;
        if (prism_rtl::is<ast::StmtKind::SBind>(_m)) {
            auto&& e = prism_rtl::as<ast::StmtKind::SBind>(_m).a1;
            auto&& t_opt = prism_rtl::as<ast::StmtKind::SBind>(_m).a2;
            _v.set(append(Array(std::vector{Kid(Kid::KidExpr{e, m})}), opt_kids(t_opt, m)));
            goto _done;
        }
        if (prism_rtl::is<ast::StmtKind::SIgnore>(_m)) {
            auto&& e = prism_rtl::as<ast::StmtKind::SIgnore>(_m).a0;
            _v.set(Array(std::vector{Kid(Kid::KidExpr{e, m})}));
            goto _done;
        }
        if (prism_rtl::is<ast::StmtKind::SLet>(_m)) {
            auto&& e = prism_rtl::as<ast::StmtKind::SLet>(_m).a2;
            _v.set(Array(std::vector{Kid(Kid::KidExpr{e, m})}));
            goto _done;
        }
        if (prism_rtl::is<ast::StmtKind::SFn>(_m)) {
            auto&& f = prism_rtl::as<ast::StmtKind::SFn>(_m).a0;
            _v.set(Array(std::vector{body_kid(f.body, later(hide(m, patterns_names(f.params))))}));
            goto _done;
        }
        if (prism_rtl::is<ast::StmtKind::SWidget>(_m)) {
            auto&& w = prism_rtl::as<ast::StmtKind::SWidget>(_m).a0;
            _v.set(Array(std::vector{Kid(Kid::KidStmts{w.body.stmts, later(m)})}));
            goto _done;
        }
        if (prism_rtl::is<ast::StmtKind::SSet>(_m)) {
            auto&& t = prism_rtl::as<ast::StmtKind::SSet>(_m).a0;
            auto&& v_ = prism_rtl::as<ast::StmtKind::SSet>(_m).a1;
            _v.set(exprs_kids(Array(std::vector{t, v_}), m));
            goto _done;
        }
        if (prism_rtl::is<ast::StmtKind::SAccum>(_m)) {
            auto&& t = prism_rtl::as<ast::StmtKind::SAccum>(_m).a0;
            auto&& v_ = prism_rtl::as<ast::StmtKind::SAccum>(_m).a2;
            _v.set(exprs_kids(Array(std::vector{t, v_}), m));
            goto _done;
        }
        if (prism_rtl::is<ast::StmtKind::SRequire>(_m)) {
            auto&& c = prism_rtl::as<ast::StmtKind::SRequire>(_m).a0;
            _v.set(Array(std::vector{Kid(Kid::KidExpr{c, m})}));
            goto _done;
        }
        if (prism_rtl::is<ast::StmtKind::SForbid>(_m)) {
            auto&& c = prism_rtl::as<ast::StmtKind::SForbid>(_m).a0;
            _v.set(Array(std::vector{Kid(Kid::KidExpr{c, m})}));
            goto _done;
        }
        if (prism_rtl::is<ast::StmtKind::SReturn>(_m)) {
            auto&& e = prism_rtl::as<ast::StmtKind::SReturn>(_m).a0;
            _v.set(Array(std::vector{Kid(Kid::KidExpr{e, m})}));
            goto _done;
        }
        if (prism_rtl::is<ast::StmtKind::SWhile>(_m)) {
            auto&& c = prism_rtl::as<ast::StmtKind::SWhile>(_m).a0;
            auto&& b = prism_rtl::as<ast::StmtKind::SWhile>(_m).a1;
            _v.set(prelude::push(cond_kids(c, m), Kid(Kid::KidStmts{b.stmts, cond_rels(c, m)})));
            goto _done;
        }
        if (prism_rtl::is<ast::StmtKind::SExpr>(_m)) {
            auto&& e = prism_rtl::as<ast::StmtKind::SExpr>(_m).a0;
            _v.set(Array(std::vector{Kid(Kid::KidExpr{e, m})}));
            goto _done;
        }
        {
            _v.set(Array<Kid>{});
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Array<Kid>> StmtKids::cycle() const {
    const auto& s = this->s;
    const auto& m = this->m;
    return ({
        auto&& _m = s.kind;
        prism_rtl::is<ast::StmtKind::SBind>(_m) ? ({
        auto&& e = prism_rtl::as<ast::StmtKind::SBind>(_m).a1;
        auto&& t_opt = prism_rtl::as<ast::StmtKind::SBind>(_m).a2;
        prism_rtl::finished(append(Array(std::vector{Kid(Kid::KidExpr{e, m})}), opt_kids(t_opt, m)));
    })
        : prism_rtl::is<ast::StmtKind::SIgnore>(_m) ? ({
        auto&& e = prism_rtl::as<ast::StmtKind::SIgnore>(_m).a0;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{e, m})}));
    })
        : prism_rtl::is<ast::StmtKind::SLet>(_m) ? ({
        auto&& e = prism_rtl::as<ast::StmtKind::SLet>(_m).a2;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{e, m})}));
    })
        : prism_rtl::is<ast::StmtKind::SFn>(_m) ? ({
        auto&& f = prism_rtl::as<ast::StmtKind::SFn>(_m).a0;
        ({
        auto f_1 = f;
        auto m_2 = m;
        call_then(start_patterns_names(f_1.params), [=](Array<Text> patterns_names_83888) { return prism_rtl::finished(Array(std::vector{body_kid(f_1.body, later(hide(m_2, patterns_names_83888)))})); });
    });
    })
        : prism_rtl::is<ast::StmtKind::SWidget>(_m) ? ({
        auto&& w = prism_rtl::as<ast::StmtKind::SWidget>(_m).a0;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidStmts{w.body.stmts, later(m)})}));
    })
        : prism_rtl::is<ast::StmtKind::SSet>(_m) ? ({
        auto&& t = prism_rtl::as<ast::StmtKind::SSet>(_m).a0;
        auto&& v_ = prism_rtl::as<ast::StmtKind::SSet>(_m).a1;
        prism_rtl::finished(exprs_kids(Array(std::vector{t, v_}), m));
    })
        : prism_rtl::is<ast::StmtKind::SAccum>(_m) ? ({
        auto&& t = prism_rtl::as<ast::StmtKind::SAccum>(_m).a0;
        auto&& v_ = prism_rtl::as<ast::StmtKind::SAccum>(_m).a2;
        prism_rtl::finished(exprs_kids(Array(std::vector{t, v_}), m));
    })
        : prism_rtl::is<ast::StmtKind::SRequire>(_m) ? ({
        auto&& c = prism_rtl::as<ast::StmtKind::SRequire>(_m).a0;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{c, m})}));
    })
        : prism_rtl::is<ast::StmtKind::SForbid>(_m) ? ({
        auto&& c = prism_rtl::as<ast::StmtKind::SForbid>(_m).a0;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{c, m})}));
    })
        : prism_rtl::is<ast::StmtKind::SReturn>(_m) ? ({
        auto&& e = prism_rtl::as<ast::StmtKind::SReturn>(_m).a0;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{e, m})}));
    })
        : prism_rtl::is<ast::StmtKind::SWhile>(_m) ? ({
        auto&& c = prism_rtl::as<ast::StmtKind::SWhile>(_m).a0;
        auto&& b = prism_rtl::as<ast::StmtKind::SWhile>(_m).a1;
        ({
        auto b_1 = b;
        auto c_2 = c;
        auto m_3 = m;
        call_then(start_cond_kids(c_2, m_3), [=](Array<Kid> cond_kids_84181) { return call_then(start_cond_rels(c_2, m_3), [=](Map<Text, Rel> cond_rels_84217) { return prism_rtl::finished(prelude::push(cond_kids_84181, Kid(Kid::KidStmts{b_1.stmts, cond_rels_84217}))); }); });
    });
    })
        : prism_rtl::is<ast::StmtKind::SExpr>(_m) ? ({
        auto&& e = prism_rtl::as<ast::StmtKind::SExpr>(_m).a0;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{e, m})}));
    })
        : prism_rtl::finished(Array<Kid>{});
    });
}


/// `Start StmtKids, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Kid>> start_stmt_kids(ast::Stmt s, Map<Text, Rel> m) {
    return std::make_shared<StmtKids>(s, m);
}


/// CondKids: unbounded fn Cond, (Text ==> Rel) -> [Kid]
Array<Kid> cond_kids(const ast::Cond& c, const Map<Text, Rel>& m) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Array<Kid>> _v;
        if (prism_rtl::is<ast::Cond::CondExpr>(c)) {
            auto&& x = prism_rtl::as<ast::Cond::CondExpr>(c).a0;
            _v.set(Array(std::vector{Kid(Kid::KidExpr{x, m})}));
            goto _done;
        }
        if (prism_rtl::is<ast::Cond::CondBind>(c)) {
            auto&& x = prism_rtl::as<ast::Cond::CondBind>(c).a1;
            auto&& g_opt = prism_rtl::as<ast::Cond::CondBind>(c).a2;
            _v.set(append(Array(std::vector{Kid(Kid::KidExpr{x, m})}), opt_kids(g_opt, cond_rels(c, m))));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Array<Kid>> CondKids::cycle() const {
    const auto& c = this->c;
    const auto& m = this->m;
    return ({
        prism_rtl::is<ast::Cond::CondExpr>(c) ? ({
        auto&& x = prism_rtl::as<ast::Cond::CondExpr>(c).a0;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{x, m})}));
    })
        : prism_rtl::is<ast::Cond::CondBind>(c) ? ({
        auto&& x = prism_rtl::as<ast::Cond::CondBind>(c).a1;
        auto&& g_opt = prism_rtl::as<ast::Cond::CondBind>(c).a2;
        ({
        auto g_opt_1 = g_opt;
        auto c_2 = c;
        auto m_3 = m;
        auto x_4 = x;
        call_then(start_cond_rels(c_2, m_3), [=](Map<Text, Rel> cond_rels_84557) { return prism_rtl::finished(append(Array(std::vector{Kid(Kid::KidExpr{x_4, m_3})}), opt_kids(g_opt_1, cond_rels_84557))); });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CondKids, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Kid>> start_cond_kids(ast::Cond c, Map<Text, Rel> m) {
    return std::make_shared<CondKids>(c, m);
}


/// CallKids: unbounded fn Expr, [Arg], (Text ==> Rel) -> [Kid]
Array<Kid> call_kids(const ast::Expr& c, const Array<ast::Arg>& args, const Map<Text, Rel>& m) {
    auto callee = ({
        __label__ _done;
        prism_rtl::Slot<Array<Kid>> _v;
        auto&& _m = callee_name(c);
        if (prism_rtl::is_some(_m)) {
            _v.set(Array<Kid>{});
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Array(std::vector{Kid(Kid::KidExpr{c, m})}));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return ({
        __label__ _done;
        prism_rtl::Slot<Array<Kid>> _v;
        auto&& _m = traversal_of(m, c, args);
        if (prism_rtl::is_none(_m)) {
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<Array<Kid>> _v;
                auto&& _m = acc_callee(m, c, args);
                if (prism_rtl::is_some(_m)) {
                    auto&& cn = prism_rtl::some_of(_m);
                    _v.set(append(callee, run_to_end(fold_job(check_errors::range0(len(args)), Array<Kid>{}, ({
                        auto m_1 = m;
                        auto cn_2 = cn;
                        auto args_3 = args;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Kid>>(std::tuple<Array<Kid>, Nat>)>>(prism_rtl::rc([=](std::tuple<Array<Kid>, Nat> _p0) {
                        auto&& p0 = std::get<0>(_p0);
                        auto&& p1 = std::get<1>(_p0);
                        return ({
                            auto m_1_4 = m_1;
                            auto cn_2_4 = cn_2;
                            auto args_3_4 = args_3;
                            entered(once_job([=]() {
                            return ({
                                auto acc = p0;
                                auto i = p1;
                                call_then(start_acc_kids(m_1_4, cn_2_4, args_3_4, i), [=](Array<Kid> acc_kids_85417) { return prism_rtl::finished(append(acc, acc_kids_85417)); });
                            });
                        }));
                        });
                    })));
                    })))));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(append(callee, exprs_kids(each(args, [&](const ast::Arg& a) { return a->value; }), m)));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_some(_m)) {
            auto&& coll = std::get<0>(prism_rtl::some_of(_m));
            auto&& step_ = std::get<1>(prism_rtl::some_of(_m));
            auto&& at = std::get<2>(prism_rtl::some_of(_m));
            _v.set(({
                auto others = fold(check_errors::range0(len(args)), callee, [&](const Array<Kid>& acc, const Nat& i) {
                    return i == (at + Nat(1u))
                        ? acc
                        : ({
                        __label__ _done;
                        prism_rtl::Slot<Array<Kid>> _v;
                        auto&& _m = index(args, i);
                        if (prism_rtl::is_some(_m)) {
                            auto&& a = prism_rtl::some_of(_m);
                            _v.set(prelude::push(acc, Kid(Kid::KidExpr{a->value, m})));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(acc);
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                });
                ({
                __label__ _done;
                prism_rtl::Slot<Array<Kid>> _v;
                auto&& _m = step_.kind;
                if (prism_rtl::is<ast::ExprKind::ELambda>(_m) && prism_rtl::is_some(prism_rtl::as<ast::ExprKind::ELambda>(_m).a0)) {
                    auto&& ps = prism_rtl::some_of(prism_rtl::as<ast::ExprKind::ELambda>(_m).a0);
                    auto&& body = prism_rtl::as<ast::ExprKind::ELambda>(_m).a1;
                    _v.set(prelude::push(others, lambda_kid(body, step_rels(m, coll, ps, at))));
                    goto _done;
                }
                if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
                    _v.set(others);
                    goto _done;
                }
                {
                    _v.set(prelude::push(others, Kid(Kid::KidExpr{step_, m})));
                    goto _done;
                }
            _done:
                _v.take();
            });
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Array<Kid>> CallKids::cycle() const {
    const auto& c = this->c;
    const auto& args = this->args;
    const auto& m = this->m;
    auto callee = ({
        __label__ _done;
        prism_rtl::Slot<Array<Kid>> _v;
        auto&& _m = callee_name(c);
        if (prism_rtl::is_some(_m)) {
            _v.set(Array<Kid>{});
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Array(std::vector{Kid(Kid::KidExpr{c, m})}));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return ({
        auto&& _m = traversal_of(m, c, args);
        prism_rtl::is_none(_m) ? ({
        auto&& _m = acc_callee(m, c, args);
        prism_rtl::is_some(_m) ? ({
        auto&& cn = prism_rtl::some_of(_m);
        ({
        auto args_1 = args;
        auto m_2 = m;
        call_value(fold_job(check_errors::range0(len(args_1)), Array<Kid>{}, ({
        auto m_2_3 = m_2;
        auto cn_3 = cn;
        auto args_1_4 = args_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Kid>>(std::tuple<Array<Kid>, Nat>)>>(prism_rtl::rc([=](std::tuple<Array<Kid>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto m_2_3_4 = m_2_3;
            auto cn_3_4 = cn_3;
            auto args_1_4_4 = args_1_4;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto i = p1;
                call_then(start_acc_kids(m_2_3_4, cn_3_4, args_1_4_4, i), [=](Array<Kid> acc_kids_85417) { return prism_rtl::finished(append(acc, acc_kids_85417)); });
            });
        }));
        });
    })));
    })), [=](Array<Kid> fold_85362) { return prism_rtl::finished(append(callee, fold_85362)); });
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(append(callee, exprs_kids(each(args, [&](const ast::Arg& a) { return a->value; }), m)))
        : throw prism_rtl::Panic("no arm matched");
    })
        : prism_rtl::is_some(_m) ? ({
        auto&& coll = std::get<0>(prism_rtl::some_of(_m));
        auto&& step_ = std::get<1>(prism_rtl::some_of(_m));
        auto&& at = std::get<2>(prism_rtl::some_of(_m));
        ({
        auto others = fold(check_errors::range0(len(args)), callee, [&](const Array<Kid>& acc, const Nat& i) {
            return i == (at + Nat(1u))
                ? acc
                : ({
                __label__ _done;
                prism_rtl::Slot<Array<Kid>> _v;
                auto&& _m = index(args, i);
                if (prism_rtl::is_some(_m)) {
                    auto&& a = prism_rtl::some_of(_m);
                    _v.set(prelude::push(acc, Kid(Kid::KidExpr{a->value, m})));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(acc);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
        });
        ({
        auto&& _m = step_.kind;
        prism_rtl::is<ast::ExprKind::ELambda>(_m) && prism_rtl::is_some(prism_rtl::as<ast::ExprKind::ELambda>(_m).a0) ? ({
        auto&& ps = prism_rtl::some_of(prism_rtl::as<ast::ExprKind::ELambda>(_m).a0);
        auto&& body = prism_rtl::as<ast::ExprKind::ELambda>(_m).a1;
        ({
        auto body_1 = body;
        auto m_2 = m;
        auto ps_3 = ps;
        call_then(start_step_rels(m_2, coll, ps_3, at), [=](Map<Text, Rel> step_rels_85830) { return prism_rtl::finished(prelude::push(others, lambda_kid(body_1, step_rels_85830))); });
    });
    })
        : prism_rtl::is<ast::ExprKind::EName>(_m) ? prism_rtl::finished(others)
        : prism_rtl::finished(prelude::push(others, Kid(Kid::KidExpr{step_, m})));
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CallKids, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Kid>> start_call_kids(ast::Expr c, Array<ast::Arg> args, Map<Text, Rel> m) {
    return std::make_shared<CallKids>(c, args, m);
}


/// Later: fn (Text ==> Rel) -> (Text ==> Rel)
Map<Text, Rel> later(const Map<Text, Rel>& m) {
    return insert(m, Text("lam:"), no_rel());
}


/// ?AccCallee: fn (Text ==> Rel), Expr, [Arg] -> ?Text
std::optional<Text> acc_callee(const Map<Text, Rel>& m, const ast::Expr& c, const Array<ast::Arg>& args) {
    return ({
        __label__ _done;
        prism_rtl::Slot<std::optional<Text>> _v;
        auto&& _m = callee_name(c);
        if (prism_rtl::is_some(_m)) {
            auto&& cn = prism_rtl::some_of(_m);
            _v.set(is_local(m, cn)
                ? std::optional<Text>{}
                : !fold(args, true, [&](const bool& ok, const ast::Arg& a) { return ok && (a.name == std::optional<ast::Ident>{}); })
                ? std::optional<Text>{}
                : fold(check_errors::range0(len(args)), false, [&](const bool& seen, const Nat& i) { return seen || check_env::has_key(m, prism_rtl::cat("acc:", cn, ":", i)); })
                ? std::optional(cn)
                : std::optional<Text>{});
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(std::optional<Text>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// AccKids: unbounded fn (Text ==> Rel), Text, [Arg], Nat -> [Kid]
Array<Kid> acc_kids(const Map<Text, Rel>& m, const Text& cn, const Array<ast::Arg>& args, const Nat& i) {
    auto a = or_(index(args, i), dummy_arg());
    return !check_env::has_key(m, prism_rtl::cat("acc:", cn, ":", i))
        ? Array(std::vector{Kid(Kid::KidExpr{a->value, m})})
        : ({
        __label__ _done;
        prism_rtl::Slot<Array<Kid>> _v;
        auto&& _m = a->value.kind;
        if (prism_rtl::is<ast::ExprKind::ELambda>(_m)) {
            auto&& ps_opt = prism_rtl::as<ast::ExprKind::ELambda>(_m).a0;
            auto&& body = prism_rtl::as<ast::ExprKind::ELambda>(_m).a1;
            _v.set(Array(std::vector{lambda_kid(body, acc_lambda_rels(m, cn, i, or_(ps_opt, Array<ast::Pattern_>{}), args))}));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
            _v.set(Array<Kid>{});
            goto _done;
        }
        {
            _v.set(Array(std::vector{Kid(Kid::KidExpr{a->value, m})}));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Array<Kid>> AccKids::cycle() const {
    const auto& m = this->m;
    const auto& cn = this->cn;
    const auto& args = this->args;
    const auto& i = this->i;
    auto a = or_(index(args, i), dummy_arg());
    return !check_env::has_key(m, prism_rtl::cat("acc:", cn, ":", i))
        ? prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{a->value, m})}))
        : ({
        auto&& _m = a->value.kind;
        prism_rtl::is<ast::ExprKind::ELambda>(_m) ? ({
        auto&& ps_opt = prism_rtl::as<ast::ExprKind::ELambda>(_m).a0;
        auto&& body = prism_rtl::as<ast::ExprKind::ELambda>(_m).a1;
        prism_rtl::finished(Array(std::vector{lambda_kid(body, acc_lambda_rels(m, cn, i, or_(ps_opt, Array<ast::Pattern_>{}), args))}));
    })
        : prism_rtl::is<ast::ExprKind::EName>(_m) ? prism_rtl::finished(Array<Kid>{})
        : prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{a->value, m})}));
    });
}


/// `Start AccKids, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Kid>> start_acc_kids(Map<Text, Rel> m, Text cn, Array<ast::Arg> args, Nat i) {
    return std::make_shared<AccKids>(m, cn, args, i);
}


/// AccLambdaRels: unbounded fn (Text ==> Rel), Text, Nat, [Pattern], [Arg] -> (Text ==> Rel)
Map<Text, Rel> acc_lambda_rels(const Map<Text, Rel>& m, const Text& cn, const Nat& j, const Array<ast::Pattern_>& ps, const Array<ast::Arg>& args) {
    auto h = hide(m, patterns_names(ps));
    return run_to_end(fold_job(check_errors::range0(len(ps)), h, ({
        auto m_1 = m;
        auto cn_2 = cn;
        auto j_3 = j;
        auto ps_4 = ps;
        auto args_5 = args;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Rel>>(std::tuple<Map<Text, Rel>, Nat>)>>(prism_rtl::rc([=](std::tuple<Map<Text, Rel>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto m_1_6 = m_1;
            auto cn_2_6 = cn_2;
            auto j_3_6 = j_3;
            auto ps_4_6 = ps_4;
            auto args_5_6 = args_5;
            entered(once_job([=]() {
            return ({
                auto m2 = p0;
                auto q = p1;
                ({
                auto&& _m = std::tuple{prelude::get(m_1_6, prism_rtl::cat("sum:", cn_2_6, ":", j_3_6, ":", q)), index(ps_4_6, q)};
                prism_rtl::is_some(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m)) ? ({
                auto&& s = prism_rtl::some_of(std::get<0>(_m));
                auto&& p_ = prism_rtl::some_of(std::get<1>(_m));
                s.param == top_param()
                ? prism_rtl::finished(m2)
                : ({
                auto&& _m = index(args_5_6, s.param);
                prism_rtl::is_some(_m) ? ({
                auto&& a = prism_rtl::some_of(_m);
                call_then(start_rel_of(m_1_6, a->value), [=](std::optional<Rel> rel_of_87818) {
                return ({
                    prism_rtl::is_some(rel_of_87818) ? ({
                    auto&& r = prism_rtl::some_of(rel_of_87818);
                    ({
                    auto&& _m = p_.kind;
                    prism_rtl::is<ast::PatternKind::PName>(_m) ? ({
                    auto&& n = prism_rtl::as<ast::PatternKind::PName>(_m).a0;
                    prism_rtl::finished(insert(m2, check_env::sname_key(n), Rel{.param = r.param, .strict = r.strict || s.strict}));
                })
                    : call_then(check_env::start_pattern_names(p_), [=](Array<Text> pattern_names_88013) { return prism_rtl::finished(fold(pattern_names_88013, m2, [&](const Map<Text, Rel>& m3, const Text& n) { return insert(m3, n, Rel{.param = r.param, .strict = true}); })); });
                });
                })
                    : prism_rtl::is_none(rel_of_87818) ? prism_rtl::finished(m2)
                    : throw prism_rtl::Panic("no arm matched");
                });
            });
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(m2)
                : throw prism_rtl::Panic("no arm matched");
            });
            })
                : prism_rtl::finished(m2);
            });
            });
        }));
        });
    }));
    })));
}


/// let topParam
Nat top_param() {
    return Nat(9999u);
}


/// TemplateKids: unbounded fn [TemplatePart], (Text ==> Rel) -> [Kid]
Array<Kid> template_kids(const Array<ast::TemplatePart>& parts, const Map<Text, Rel>& m) {
    return fold(parts, Array<Kid>{}, [&](const Array<Kid>& acc, const ast::TemplatePart& p_) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Kid>> _v;
            if (prism_rtl::is<ast::TemplatePart::TpPlaceholder>(p_)) {
                auto&& x = prism_rtl::as<ast::TemplatePart::TpPlaceholder>(p_).a0;
                _v.set(prelude::push(acc, Kid(Kid::KidExpr{x, m})));
                goto _done;
            }
            if (prism_rtl::is<ast::TemplatePart::TpBlock>(p_)) {
                auto&& b = prism_rtl::as<ast::TemplatePart::TpBlock>(p_).a0;
                _v.set(prelude::push(acc, Kid(Kid::KidStmts{b.stmts, m})));
                goto _done;
            }
            if (prism_rtl::is<ast::TemplatePart::TpCall>(p_)) {
                auto&& n = prism_rtl::as<ast::TemplatePart::TpCall>(p_).a0;
                auto&& args = prism_rtl::as<ast::TemplatePart::TpCall>(p_).a1;
                auto&& ps_opt = prism_rtl::as<ast::TemplatePart::TpCall>(p_).a2;
                auto&& span = prism_rtl::as<ast::TemplatePart::TpCall>(p_).a3;
                _v.set(prelude::push(acc, Kid(Kid::KidExpr{template_call_expr(n, args, ps_opt, span), m})));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


prism_rtl::Turn<Array<Kid>> TemplateKids::cycle() const {
    const auto& parts = this->parts;
    const auto& m = this->m;
    return prism_rtl::finished(fold(parts, Array<Kid>{}, [&](const Array<Kid>& acc, const ast::TemplatePart& p_) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Kid>> _v;
            if (prism_rtl::is<ast::TemplatePart::TpPlaceholder>(p_)) {
                auto&& x = prism_rtl::as<ast::TemplatePart::TpPlaceholder>(p_).a0;
                _v.set(prelude::push(acc, Kid(Kid::KidExpr{x, m})));
                goto _done;
            }
            if (prism_rtl::is<ast::TemplatePart::TpBlock>(p_)) {
                auto&& b = prism_rtl::as<ast::TemplatePart::TpBlock>(p_).a0;
                _v.set(prelude::push(acc, Kid(Kid::KidStmts{b.stmts, m})));
                goto _done;
            }
            if (prism_rtl::is<ast::TemplatePart::TpCall>(p_)) {
                auto&& n = prism_rtl::as<ast::TemplatePart::TpCall>(p_).a0;
                auto&& args = prism_rtl::as<ast::TemplatePart::TpCall>(p_).a1;
                auto&& ps_opt = prism_rtl::as<ast::TemplatePart::TpCall>(p_).a2;
                auto&& span = prism_rtl::as<ast::TemplatePart::TpCall>(p_).a3;
                _v.set(prelude::push(acc, Kid(Kid::KidExpr{template_call_expr(n, args, ps_opt, span), m})));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    }));
}


/// `Start TemplateKids, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Kid>> start_template_kids(Array<ast::TemplatePart> parts, Map<Text, Rel> m) {
    return std::make_shared<TemplateKids>(parts, m);
}


/// TemplateCallExpr: fn SName, [Arg], ?[TemplatePart], Range -> Expr
ast::Expr template_call_expr(const ast::SName& n, const Array<ast::Arg>& args, const std::optional<Array<ast::TemplatePart>>& ps_opt, const ast::Range& span) {
    auto body_1 = ({
        __label__ _done;
        prism_rtl::Slot<Array<ast::Arg>> _v;
        if (prism_rtl::is_some(ps_opt)) {
            auto&& ps = prism_rtl::some_of(ps_opt);
            _v.set(Array(std::vector{ast::Arg{.name = std::optional(ast::Ident{.name = Text("#body"), .span = span}), .value = ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::ETemplate{ast::Template{.keyword = Text("InlineText"), .lang = Text(""), .delims = Text("double"), .parts = ps, .span = span}})), .span = span}, .span = span}}));
            goto _done;
        }
        if (prism_rtl::is_none(ps_opt)) {
            _v.set(Array<ast::Arg>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::ECall{prism_rtl::rc(ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EName{n})), .span = n.span}), append(args, body_1), false, false})), .span = span};
}


/// ArgOf: fn Expr -> Arg
ast::Arg arg_of(const ast::Expr& x) {
    return ast::Arg{.name = std::optional<ast::Ident>{}, .value = x, .span = x.span};
}


/// ExprsKids: fn [Expr], (Text ==> Rel) -> [Kid]
Array<Kid> exprs_kids(const Array<ast::Expr>& xs, const Map<Text, Rel>& m) {
    return each(xs, [&](const ast::Expr& x) { return Kid(Kid::KidExpr{x, m}); });
}


/// OptKids: fn ?Expr, (Text ==> Rel) -> [Kid]
Array<Kid> opt_kids(const std::optional<ast::Expr>& opt0, const Map<Text, Rel>& map1) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Array<Kid>> _v;
        auto&& _m = std::tuple{opt0, map1};
        if (prism_rtl::is_some(std::get<0>(_m))) {
            auto&& x = prism_rtl::some_of(std::get<0>(_m));
            auto&& m = std::get<1>(_m);
            _v.set(Array(std::vector{Kid(Kid::KidExpr{x, m})}));
            goto _done;
        }
        if (prism_rtl::is_none(std::get<0>(_m))) {
            _v.set(Array<Kid>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// LambdaKid: fn LambdaBody, (Text ==> Rel) -> Kid
Kid lambda_kid(const ast::LambdaBody& lambda_body0, const Map<Text, Rel>& m) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Kid> _v;
        if (prism_rtl::is<ast::LambdaBody::LbExpr>(lambda_body0)) {
            auto&& x = prism_rtl::as<ast::LambdaBody::LbExpr>(lambda_body0).a0;
            _v.set(Kid(Kid::KidExpr{x, m}));
            goto _done;
        }
        if (prism_rtl::is<ast::LambdaBody::LbBlock>(lambda_body0)) {
            auto&& b = prism_rtl::as<ast::LambdaBody::LbBlock>(lambda_body0).a0;
            _v.set(Kid(Kid::KidStmts{b.stmts, m}));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// BodyKid: fn FnBody, (Text ==> Rel) -> Kid
Kid body_kid(const ast::FnBody& fn_body0, const Map<Text, Rel>& m) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Kid> _v;
        if (prism_rtl::is<ast::FnBody::BodyExpr>(fn_body0)) {
            auto&& x = prism_rtl::as<ast::FnBody::BodyExpr>(fn_body0).a0;
            _v.set(Kid(Kid::KidExpr{x, m}));
            goto _done;
        }
        if (prism_rtl::is<ast::FnBody::BodyBlock>(fn_body0)) {
            auto&& b = prism_rtl::as<ast::FnBody::BodyBlock>(fn_body0).a0;
            _v.set(Kid(Kid::KidStmts{b.stmts, m}));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// PatternsNames: unbounded fn [Pattern] -> [Text]
Array<Text> patterns_names(const Array<ast::Pattern_>& ps) {
    return run_to_end(fold_job(ps, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, ast::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, ast::Pattern_> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto a = p0;
                auto p_ = p1;
                call_then(check_env::start_pattern_names(p_), [=](Array<Text> pattern_names_89972) { return prism_rtl::finished(check_types::union_texts(a, pattern_names_89972)); });
            });
        }));
    }))));
}


prism_rtl::Turn<Array<Text>> PatternsNames::cycle() const {
    const auto& ps = this->ps;
    return fold_job(ps, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, ast::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, ast::Pattern_> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto a = p0;
                auto p_ = p1;
                call_then(check_env::start_pattern_names(p_), [=](Array<Text> pattern_names_89972) { return prism_rtl::finished(check_types::union_texts(a, pattern_names_89972)); });
            });
        }));
    })))->cycle();
}


/// `Start PatternsNames, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_patterns_names(Array<ast::Pattern_> ps) {
    return std::make_shared<PatternsNames>(ps);
}


/// ?CalleeName: fn Expr -> ?Text
std::optional<Text> callee_name(const ast::Expr& c) {
    return ({
        __label__ _done;
        prism_rtl::Slot<std::optional<Text>> _v;
        auto&& _m = c.kind;
        if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
            auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
            _v.set(std::optional(check_env::sname_key(n)));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::ETypeArgs>(_m)) {
            auto&& t = prism_rtl::as<ast::ExprKind::ETypeArgs>(_m).a0;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::optional<Text>> _v;
                auto&& _m = t.kind;
                if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
                    auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
                    _v.set(std::optional(check_env::sname_key(n)));
                    goto _done;
                }
                {
                    _v.set(std::optional<Text>{});
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        {
            _v.set(std::optional<Text>{});
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// MethodCallee: fn SName -> Expr
ast::Expr method_callee(const ast::SName& n) {
    return ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EName{n})), .span = n.span};
}


/// MethodArgs: fn Expr, [Arg] -> [Arg]
Array<ast::Arg> method_args(const ast::Expr& r, const Array<ast::Arg>& args) {
    return append(Array(std::vector{ast::Arg{.name = std::optional<ast::Ident>{}, .value = r, .span = r.span}}), args);
}


/// BodySites: unbounded fn FnBody, (Text ==> Rel) -> [Site]
Array<Site> body_sites(const ast::FnBody& body, const Map<Text, Rel>& m) {
    return run_to_end(fold_job(body_spots(body, m), Array<Site>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Site>>(std::tuple<Array<Site>, Spot>)>>(prism_rtl::rc([=](std::tuple<Array<Site>, Spot> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto sp = p1;
                call_then(start_spot_sites(sp), [=](Array<Site> spot_sites_90929) { return prism_rtl::finished(append(acc, spot_sites_90929)); });
            });
        }));
    }))));
}


prism_rtl::Turn<Array<Site>> BodySites::cycle() const {
    const auto& body = this->body;
    const auto& m = this->m;
    auto body_1 = body;
    auto m_2 = m;
    return call_then(start_body_spots(body_1, m_2), [=](Array<Spot> body_spots_90879) {
        return fold_job(body_spots_90879, Array<Site>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Site>>(std::tuple<Array<Site>, Spot>)>>(prism_rtl::rc([=](std::tuple<Array<Site>, Spot> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto sp = p1;
                    call_then(start_spot_sites(sp), [=](Array<Site> spot_sites_90929) { return prism_rtl::finished(append(acc, spot_sites_90929)); });
                });
            }));
        })))->cycle();
    });
}


/// `Start BodySites, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Site>> start_body_sites(ast::FnBody body, Map<Text, Rel> m) {
    return std::make_shared<BodySites>(body, m);
}


/// SpotSites: unbounded fn Spot -> [Site]
Array<Site> spot_sites(const Spot& spot0) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Array<Site>> _v;
        if (prism_rtl::is<Spot::SpotStmt>(spot0)) {
            _v.set(Array<Site>{});
            goto _done;
        }
        if (prism_rtl::is<Spot::SpotExpr>(spot0)) {
            auto&& e = prism_rtl::as<Spot::SpotExpr>(spot0).a0;
            auto&& m = prism_rtl::as<Spot::SpotExpr>(spot0).a1;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<Array<Site>> _v;
                auto&& _m = e.kind;
                if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
                    auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
                    _v.set(Array(std::vector{Site{.callee = check_env::sname_key(n), .args = Array<ast::Arg>{}, .span = e.span, .rels = m}}));
                    goto _done;
                }
                if (prism_rtl::is<ast::ExprKind::ECall>(_m)) {
                    auto&& c = prism_rtl::as<ast::ExprKind::ECall>(_m).a0;
                    auto&& args = prism_rtl::as<ast::ExprKind::ECall>(_m).a1;
                    _v.set(call_sites(c, args, e.span, m));
                    goto _done;
                }
                if (prism_rtl::is<ast::ExprKind::EMethod>(_m)) {
                    auto&& r = prism_rtl::as<ast::ExprKind::EMethod>(_m).a0;
                    auto&& n = prism_rtl::as<ast::ExprKind::EMethod>(_m).a1;
                    auto&& args = prism_rtl::as<ast::ExprKind::EMethod>(_m).a2;
                    _v.set(call_sites(method_callee(n), method_args(r, args), e.span, m));
                    goto _done;
                }
                if (prism_rtl::is<ast::ExprKind::EBinary>(_m)) {
                    auto&& op = prism_rtl::as<ast::ExprKind::EBinary>(_m).a0;
                    auto&& l = prism_rtl::as<ast::ExprKind::EBinary>(_m).a1;
                    auto&& r = prism_rtl::as<ast::ExprKind::EBinary>(_m).a2;
                    _v.set(is_called_op(op)
                        ? Array(std::vector{Site{.callee = op, .args = Array(std::vector{arg_of(l), arg_of(r)}), .span = e.span, .rels = m}})
                        : Array<Site>{});
                    goto _done;
                }
                {
                    _v.set(Array<Site>{});
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Array<Site>> SpotSites::cycle() const {
    const auto& spot0 = this->spot0;
    return ({
        prism_rtl::is<Spot::SpotStmt>(spot0) ? prism_rtl::finished(Array<Site>{})
        : prism_rtl::is<Spot::SpotExpr>(spot0) ? ({
        auto&& e = prism_rtl::as<Spot::SpotExpr>(spot0).a0;
        auto&& m = prism_rtl::as<Spot::SpotExpr>(spot0).a1;
        ({
        auto&& _m = e.kind;
        prism_rtl::is<ast::ExprKind::EName>(_m) ? ({
        auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
        prism_rtl::finished(Array(std::vector{Site{.callee = check_env::sname_key(n), .args = Array<ast::Arg>{}, .span = e.span, .rels = m}}));
    })
        : prism_rtl::is<ast::ExprKind::ECall>(_m) ? ({
        auto&& c = prism_rtl::as<ast::ExprKind::ECall>(_m).a0;
        auto&& args = prism_rtl::as<ast::ExprKind::ECall>(_m).a1;
        prism_rtl::more(prism_rtl::rc(CallSites(c, args, e.span, m)));
    })
        : prism_rtl::is<ast::ExprKind::EMethod>(_m) ? ({
        auto&& r = prism_rtl::as<ast::ExprKind::EMethod>(_m).a0;
        auto&& n = prism_rtl::as<ast::ExprKind::EMethod>(_m).a1;
        auto&& args = prism_rtl::as<ast::ExprKind::EMethod>(_m).a2;
        prism_rtl::more(prism_rtl::rc(CallSites(method_callee(n), method_args(r, args), e.span, m)));
    })
        : prism_rtl::is<ast::ExprKind::EBinary>(_m) ? ({
        auto&& op = prism_rtl::as<ast::ExprKind::EBinary>(_m).a0;
        auto&& l = prism_rtl::as<ast::ExprKind::EBinary>(_m).a1;
        auto&& r = prism_rtl::as<ast::ExprKind::EBinary>(_m).a2;
        is_called_op(op)
        ? prism_rtl::finished(Array(std::vector{Site{.callee = op, .args = Array(std::vector{arg_of(l), arg_of(r)}), .span = e.span, .rels = m}}))
        : prism_rtl::finished(Array<Site>{});
    })
        : prism_rtl::finished(Array<Site>{});
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start SpotSites, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Site>> start_spot_sites(Spot spot0) {
    return std::make_shared<SpotSites>(spot0);
}


/// IsCalledOp: fn Text -> Bool
bool is_called_op(const Text& op) {
    return !check_types::has_text(Array(std::vector{Text("and"), Text("or"), Text("on"), Text("<|"), Text("mod")}), op);
}


/// CallSites: unbounded fn Expr, [Arg], Range, (Text ==> Rel) -> [Site]
Array<Site> call_sites(const ast::Expr& c, const Array<ast::Arg>& args, const ast::Range& span, const Map<Text, Rel>& m) {
    auto direct = ({
        __label__ _done;
        prism_rtl::Slot<Array<Site>> _v;
        auto&& _m = callee_name(c);
        if (prism_rtl::is_some(_m)) {
            auto&& n = prism_rtl::some_of(_m);
            _v.set(Array(std::vector{Site{.callee = n, .args = args, .span = span, .rels = m}}));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Array<Site>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return ({
        __label__ _done;
        prism_rtl::Slot<Array<Site>> _v;
        auto&& _m = traversal_of(m, c, args);
        if (prism_rtl::is_some(_m)) {
            auto&& coll = std::get<0>(prism_rtl::some_of(_m));
            auto&& step_ = std::get<1>(prism_rtl::some_of(_m));
            auto&& at = std::get<2>(prism_rtl::some_of(_m));
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<Array<Site>> _v;
                auto&& _m = step_.kind;
                if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
                    auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
                    _v.set(({
                        auto call_args = at == Nat(1u)
                            ? Array(std::vector{or_(index(args, Nat(1u)), dummy_arg()), arg_of(part_of(coll))})
                            : Array(std::vector{arg_of(part_of(coll))});
                        (prelude::push(direct, Site{.callee = check_env::sname_key(n), .args = call_args, .span = step_.span, .rels = m}));
                    }));
                    goto _done;
                }
                {
                    _v.set(direct);
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<Array<Site>> _v;
                auto&& _m = acc_callee(m, c, args);
                if (prism_rtl::is_some(_m)) {
                    auto&& cn = prism_rtl::some_of(_m);
                    _v.set(append(direct, acc_sites(m, cn, args)));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(direct);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Array<Site>> CallSites::cycle() const {
    const auto& c = this->c;
    const auto& args = this->args;
    const auto& span = this->span;
    const auto& m = this->m;
    auto direct = ({
        __label__ _done;
        prism_rtl::Slot<Array<Site>> _v;
        auto&& _m = callee_name(c);
        if (prism_rtl::is_some(_m)) {
            auto&& n = prism_rtl::some_of(_m);
            _v.set(Array(std::vector{Site{.callee = n, .args = args, .span = span, .rels = m}}));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Array<Site>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return ({
        auto&& _m = traversal_of(m, c, args);
        prism_rtl::is_some(_m) ? ({
        auto&& coll = std::get<0>(prism_rtl::some_of(_m));
        auto&& step_ = std::get<1>(prism_rtl::some_of(_m));
        auto&& at = std::get<2>(prism_rtl::some_of(_m));
        ({
        auto&& _m = step_.kind;
        prism_rtl::is<ast::ExprKind::EName>(_m) ? ({
        auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
        ({
        auto call_args = at == Nat(1u)
            ? Array(std::vector{or_(index(args, Nat(1u)), dummy_arg()), arg_of(part_of(coll))})
            : Array(std::vector{arg_of(part_of(coll))});
        (prism_rtl::finished(prelude::push(direct, Site{.callee = check_env::sname_key(n), .args = call_args, .span = step_.span, .rels = m})));
    });
    })
        : prism_rtl::finished(direct);
    });
    })
        : prism_rtl::is_none(_m) ? ({
        auto&& _m = acc_callee(m, c, args);
        prism_rtl::is_some(_m) ? ({
        auto&& cn = prism_rtl::some_of(_m);
        prism_rtl::finished(append(direct, acc_sites(m, cn, args)));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(direct)
        : throw prism_rtl::Panic("no arm matched");
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CallSites, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Site>> start_call_sites(ast::Expr c, Array<ast::Arg> args, ast::Range span, Map<Text, Rel> m) {
    return std::make_shared<CallSites>(c, args, span, m);
}


/// PartOf: fn Expr -> Expr
ast::Expr part_of(const ast::Expr& x) {
    return ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EField{prism_rtl::rc(x), Text(""), ast::Ident{.name = Text("element"), .span = x.span}})), .span = x.span};
}


/// AccSites: fn (Text ==> Rel), Text, [Arg] -> [Site]
Array<Site> acc_sites(const Map<Text, Rel>& m, const Text& cn, const Array<ast::Arg>& args) {
    return fold(check_errors::range0(len(args)), Array<Site>{}, [&](const Array<Site>& acc, const Nat& j) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Site>> _v;
            auto&& _m = std::tuple{prelude::get(m, prism_rtl::cat("acc:", cn, ":", j)), index(args, j)};
            if (prism_rtl::is_some(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m))) {
                auto&& ar = prism_rtl::some_of(std::get<0>(_m));
                auto&& a = prism_rtl::some_of(std::get<1>(_m));
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Array<Site>> _v;
                    auto&& _m = a->value.kind;
                    if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
                        auto&& f = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
                        _v.set(prelude::push(acc, Site{.callee = check_env::sname_key(f), .args = each(check_errors::range0(ar.param), [&](const Nat& q) { return acc_arg(m, cn, j, q, args); }), .span = a->value.span, .rels = m}));
                        goto _done;
                    }
                    {
                        _v.set(acc);
                        goto _done;
                    }
                _done:
                    _v.take();
                }));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


/// AccArg: fn (Text ==> Rel), Text, Nat, Nat, [Arg] -> Arg
ast::Arg acc_arg(const Map<Text, Rel>& m, const Text& cn, const Nat& j, const Nat& q, const Array<ast::Arg>& args) {
    return ({
        __label__ _done;
        prism_rtl::Slot<ast::Arg> _v;
        auto&& _m = prelude::get(m, prism_rtl::cat("sum:", cn, ":", j, ":", q));
        if (prism_rtl::is_some(_m)) {
            auto&& s = prism_rtl::some_of(_m);
            _v.set(s.param == top_param()
                ? arg_of(top_expr())
                : ({
                __label__ _done;
                prism_rtl::Slot<ast::Arg> _v;
                auto&& _m = index(args, s.param);
                if (prism_rtl::is_some(_m)) {
                    auto&& a = prism_rtl::some_of(_m);
                    _v.set(arg_of(s.strict ? part_of(a->value) : a->value));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(dummy_arg());
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(dummy_arg());
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// let topExpr
ast::Expr top_expr() {
    return ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EName{ast::SName{.sigils = Text(""), .path_ = Array(std::vector{Text("⊤")}), .span = ast::Range{.start = Nat(0u), .end = Nat(0u)}}})), .span = ast::Range{.start = Nat(0u), .end = Nat(0u)}};
}


/// SpotsNames: unbounded fn [Spot] -> [Text]
Array<Text> spots_names(const Array<Spot>& spots) {
    return run_to_end(fold_job(spots, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Spot>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, Spot> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto sp = p1;
                call_then(start_spot_names(sp), [=](Array<Text> spot_names_94268) { return prism_rtl::finished(check_types::union_texts(acc, spot_names_94268)); });
            });
        }));
    }))));
}


prism_rtl::Turn<Array<Text>> SpotsNames::cycle() const {
    const auto& spots = this->spots;
    return fold_job(spots, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Spot>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, Spot> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto sp = p1;
                call_then(start_spot_names(sp), [=](Array<Text> spot_names_94268) { return prism_rtl::finished(check_types::union_texts(acc, spot_names_94268)); });
            });
        }));
    })))->cycle();
}


/// `Start SpotsNames, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_spots_names(Array<Spot> spots) {
    return std::make_shared<SpotsNames>(spots);
}


/// SpotNames: unbounded fn Spot -> [Text]
Array<Text> spot_names(const Spot& sp) {
    auto called = each(spot_sites(sp), [&](const Site& s) { return s.callee; });
    return ({
        __label__ _done;
        prism_rtl::Slot<Array<Text>> _v;
        if (prism_rtl::is<Spot::SpotExpr>(sp)) {
            _v.set(called);
            goto _done;
        }
        if (prism_rtl::is<Spot::SpotStmt>(sp)) {
            auto&& s = prism_rtl::as<Spot::SpotStmt>(sp).a0;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<Array<Text>> _v;
                auto&& _m = s.kind;
                if (prism_rtl::is<ast::StmtKind::SWidget>(_m)) {
                    auto&& w = prism_rtl::as<ast::StmtKind::SWidget>(_m).a0;
                    _v.set(check_types::add_text(called, check_env::sname_key(w.name)));
                    goto _done;
                }
                {
                    _v.set(called);
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Array<Text>> SpotNames::cycle() const {
    const auto& sp = this->sp;
    auto sp_1 = sp;
    return call_then(start_spot_sites(sp_1), [=](Array<Site> spot_sites_94362) {
        return ({
            auto called = each(spot_sites_94362, [&](const Site& s) { return s.callee; });
            ({
            prism_rtl::is<Spot::SpotExpr>(sp_1) ? prism_rtl::finished(called)
            : prism_rtl::is<Spot::SpotStmt>(sp_1) ? ({
            auto&& s = prism_rtl::as<Spot::SpotStmt>(sp_1).a0;
            ({
            auto&& _m = s.kind;
            prism_rtl::is<ast::StmtKind::SWidget>(_m) ? ({
            auto&& w = prism_rtl::as<ast::StmtKind::SWidget>(_m).a0;
            prism_rtl::finished(check_types::add_text(called, check_env::sname_key(w.name)));
        })
            : prism_rtl::finished(called);
        });
        })
            : throw prism_rtl::Panic("no arm matched");
        });
        });
    });
}


/// `Start SpotNames, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_spot_names(Spot sp) {
    return std::make_shared<SpotNames>(sp);
}


/// ?TraversalOf: fn (Text ==> Rel), Expr, [Arg] -> ?((Expr, Expr, Nat))
std::optional<std::tuple<ast::Expr, ast::Expr, Nat>> traversal_of(const Map<Text, Rel>& m, const ast::Expr& c, const Array<ast::Arg>& args) {
    return ({
        __label__ _done;
        prism_rtl::Slot<std::optional<std::tuple<ast::Expr, ast::Expr, Nat>>> _v;
        auto&& _m = c.kind;
        if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
            auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
            _v.set(({
                auto name = check_env::sname_key(n);
                pre_is(m, name, Text("Fold")) && (len(args) == Nat(3u))
                ? ({
                __label__ _done;
                prism_rtl::Slot<std::optional<std::tuple<ast::Expr, ast::Expr, Nat>>> _v;
                auto&& _m = std::tuple{index(args, Nat(0u)), index(args, Nat(2u))};
                if (prism_rtl::is_some(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m))) {
                    auto&& a = prism_rtl::some_of(std::get<0>(_m));
                    auto&& s = prism_rtl::some_of(std::get<1>(_m));
                    _v.set(std::optional(std::tuple{a->value, s->value, Nat(1u)}));
                    goto _done;
                }
                {
                    _v.set(std::optional<std::tuple<ast::Expr, ast::Expr, Nat>>{});
                    goto _done;
                }
            _done:
                _v.take();
            })
                : (pre_is(m, name, Text("Each")) || pre_is(m, name, Text("Filter"))) && (len(args) == Nat(2u))
                ? ({
                __label__ _done;
                prism_rtl::Slot<std::optional<std::tuple<ast::Expr, ast::Expr, Nat>>> _v;
                auto&& _m = std::tuple{index(args, Nat(0u)), index(args, Nat(1u))};
                if (prism_rtl::is_some(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m))) {
                    auto&& a = prism_rtl::some_of(std::get<0>(_m));
                    auto&& s = prism_rtl::some_of(std::get<1>(_m));
                    _v.set(std::optional(std::tuple{a->value, s->value, Nat(0u)}));
                    goto _done;
                }
                {
                    _v.set(std::optional<std::tuple<ast::Expr, ast::Expr, Nat>>{});
                    goto _done;
                }
            _done:
                _v.take();
            })
                : std::optional<std::tuple<ast::Expr, ast::Expr, Nat>>{};
            }));
            goto _done;
        }
        {
            _v.set(std::optional<std::tuple<ast::Expr, ast::Expr, Nat>>{});
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// ?LastExpr: fn Block -> ?Expr
std::optional<ast::Expr> last_expr(const ast::Block& b) {
    return ({
        __label__ _done;
        prism_rtl::Slot<std::optional<ast::Expr>> _v;
        auto&& _m = lexer::last(b.stmts);
        if (prism_rtl::is_some(_m)) {
            auto&& s = prism_rtl::some_of(_m);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::optional<ast::Expr>> _v;
                auto&& _m = s.kind;
                if (prism_rtl::is<ast::StmtKind::SExpr>(_m)) {
                    auto&& x = prism_rtl::as<ast::StmtKind::SExpr>(_m).a0;
                    _v.set(std::optional(x));
                    goto _done;
                }
                {
                    _v.set(std::optional<ast::Expr>{});
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(std::optional<ast::Expr>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// ?RelOf: unbounded fn (Text ==> Rel), Expr -> ?Rel
std::optional<Rel> rel_of(const Map<Text, Rel>& m, const ast::Expr& e) {
    return ({
        __label__ _done;
        prism_rtl::Slot<std::optional<Rel>> _v;
        auto&& _m = e.kind;
        if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
            auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
            _v.set(prelude::get(m, check_env::sname_key(n)));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EField>(_m)) {
            auto&& r = prism_rtl::as<ast::ExprKind::EField>(_m).a0;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::optional<Rel>> _v;
                auto&& _m = rel_of(m, r);
                if (prism_rtl::is_some(_m)) {
                    auto&& x = prism_rtl::some_of(_m);
                    _v.set(std::optional(Rel{.param = x.param, .strict = true}));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(std::optional<Rel>{});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EIndex>(_m)) {
            auto&& r = prism_rtl::as<ast::ExprKind::EIndex>(_m).a0;
            _v.set(rel_of(m, r));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EGroup>(_m)) {
            auto&& x = prism_rtl::as<ast::ExprKind::EGroup>(_m).a0;
            _v.set(rel_of(m, x));
            goto _done;
        }
        {
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::optional<Rel>> _v;
                auto&& _m = call_of(e);
                if (prism_rtl::is_some(_m)) {
                    auto&& c = std::get<0>(prism_rtl::some_of(_m));
                    auto&& args = std::get<1>(prism_rtl::some_of(_m));
                    _v.set(is_non_nat_min(m, e, c) ? std::optional<Rel>{} : rel_of_call(m, c, args));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(std::optional<Rel>{});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::optional<Rel>> RelOf::cycle() const {
    const auto& m = this->m;
    const auto& e = this->e;
    return ({
        auto&& _m = e.kind;
        prism_rtl::is<ast::ExprKind::EName>(_m) ? ({
        auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
        prism_rtl::finished(prelude::get(m, check_env::sname_key(n)));
    })
        : prism_rtl::is<ast::ExprKind::EField>(_m) ? ({
        auto&& r = prism_rtl::as<ast::ExprKind::EField>(_m).a0;
        ({
        auto m_1 = m;
        auto r_2 = r;
        call_then(start_rel_of(m_1, r_2), [=](std::optional<Rel> rel_of_96478) {
        return ({
            prism_rtl::is_some(rel_of_96478) ? ({
            auto&& x = prism_rtl::some_of(rel_of_96478);
            prism_rtl::finished(std::optional(Rel{.param = x.param, .strict = true}));
        })
            : prism_rtl::is_none(rel_of_96478) ? prism_rtl::finished(std::optional<Rel>{})
            : throw prism_rtl::Panic("no arm matched");
        });
    });
    });
    })
        : prism_rtl::is<ast::ExprKind::EIndex>(_m) ? ({
        auto&& r = prism_rtl::as<ast::ExprKind::EIndex>(_m).a0;
        prism_rtl::more(prism_rtl::rc(RelOf(m, r)));
    })
        : prism_rtl::is<ast::ExprKind::EGroup>(_m) ? ({
        auto&& x = prism_rtl::as<ast::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(RelOf(m, x)));
    })
        : ({
        auto&& _m = call_of(e);
        prism_rtl::is_some(_m) ? ({
        auto&& c = std::get<0>(prism_rtl::some_of(_m));
        auto&& args = std::get<1>(prism_rtl::some_of(_m));
        is_non_nat_min(m, e, c)
        ? prism_rtl::finished(std::optional<Rel>{})
        : prism_rtl::more(prism_rtl::rc(RelOfCall(m, c, args)));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(std::optional<Rel>{})
        : throw prism_rtl::Panic("no arm matched");
    });
    });
}


/// `Start RelOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<Rel>> start_rel_of(Map<Text, Rel> m, ast::Expr e) {
    return std::make_shared<RelOf>(m, e);
}


/// IsNonNatMin: fn (Text ==> Rel), Expr, Expr -> Bool
bool is_non_nat_min(const Map<Text, Rel>& m, const ast::Expr& e, const ast::Expr& c) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = callee_name(c);
        if (prism_rtl::is_some(_m)) {
            auto&& n = prism_rtl::some_of(_m);
            _v.set(pre_is(m, n, Text("Min")) ? !is_nat_at(m, e) : false);
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(false);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// IsNatAt: fn (Text ==> Rel), Expr -> Bool
bool is_nat_at(const Map<Text, Rel>& m, const ast::Expr& e) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = prelude::get(m, Text("file:"));
        if (prism_rtl::is_some(_m)) {
            auto&& f = prism_rtl::some_of(_m);
            _v.set(check_env::has_key(m, prism_rtl::cat("nat:", f.param, ":", e.span.start, ":", e.span.end)));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(false);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// ?RelOfCall: unbounded fn (Text ==> Rel), Expr, [Arg] -> ?Rel
std::optional<Rel> rel_of_call(const Map<Text, Rel>& m, const ast::Expr& c, const Array<ast::Arg>& args) {
    return ({
        __label__ _done;
        prism_rtl::Slot<std::optional<Rel>> _v;
        auto&& _m = c.kind;
        if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
            auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
            _v.set(({
                auto name = check_env::sname_key(n);
                (pre_is(m, name, Text("Drop")) && (len(args) == Nat(2u))) && is_positive_lit(or_(index(args, Nat(1u)), dummy_arg())->value)
                ? ({
                __label__ _done;
                prism_rtl::Slot<std::optional<Rel>> _v;
                auto&& _m = index(args, Nat(0u));
                if (prism_rtl::is_some(_m)) {
                    auto&& a = prism_rtl::some_of(_m);
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<std::optional<Rel>> _v;
                        auto&& _m = rel_of(m, a->value);
                        if (prism_rtl::is_some(_m)) {
                            auto&& x = prism_rtl::some_of(_m);
                            _v.set(std::optional(Rel{.param = x.param, .strict = x.strict || known_non_empty(m, a->value)}));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(std::optional<Rel>{});
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(std::optional<Rel>{});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            })
                : (pre_is(m, name, Text("Values")) || pre_is(m, name, Text("Keys"))) && (len(args) == Nat(1u))
                ? rel_of(m, or_(index(args, Nat(0u)), dummy_arg())->value)
                : ({
                __label__ _done;
                prism_rtl::Slot<std::optional<Rel>> _v;
                auto&& _m = no_larger_arg(m, c, args);
                if (prism_rtl::is_some(_m)) {
                    auto&& a = prism_rtl::some_of(_m);
                    _v.set(rel_of(m, a));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(std::optional<Rel>{});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            }));
            goto _done;
        }
        {
            _v.set(std::optional<Rel>{});
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::optional<Rel>> RelOfCall::cycle() const {
    const auto& m = this->m;
    const auto& c = this->c;
    const auto& args = this->args;
    return ({
        auto&& _m = c.kind;
        prism_rtl::is<ast::ExprKind::EName>(_m) ? ({
        auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
        ({
        auto name = check_env::sname_key(n);
        (pre_is(m, name, Text("Drop")) && (len(args) == Nat(2u))) && is_positive_lit(or_(index(args, Nat(1u)), dummy_arg())->value)
        ? ({
        auto&& _m = index(args, Nat(0u));
        prism_rtl::is_some(_m) ? ({
        auto&& a = prism_rtl::some_of(_m);
        ({
        auto m_1 = m;
        call_then(start_rel_of(m_1, a->value), [=](std::optional<Rel> rel_of_97635) {
        return ({
            prism_rtl::is_some(rel_of_97635) ? ({
            auto&& x = prism_rtl::some_of(rel_of_97635);
            prism_rtl::finished(std::optional(Rel{.param = x.param, .strict = x.strict || known_non_empty(m_1, a->value)}));
        })
            : prism_rtl::is_none(rel_of_97635) ? prism_rtl::finished(std::optional<Rel>{})
            : throw prism_rtl::Panic("no arm matched");
        });
    });
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(std::optional<Rel>{})
        : throw prism_rtl::Panic("no arm matched");
    })
        : (pre_is(m, name, Text("Values")) || pre_is(m, name, Text("Keys"))) && (len(args) == Nat(1u))
        ? prism_rtl::more(prism_rtl::rc(RelOf(m, or_(index(args, Nat(0u)), dummy_arg())->value)))
        : ({
        auto&& _m = no_larger_arg(m, c, args);
        prism_rtl::is_some(_m) ? ({
        auto&& a = prism_rtl::some_of(_m);
        prism_rtl::more(prism_rtl::rc(RelOf(m, a)));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(std::optional<Rel>{})
        : throw prism_rtl::Panic("no arm matched");
    });
    });
    })
        : prism_rtl::finished(std::optional<Rel>{});
    });
}


/// `Start RelOfCall, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<Rel>> start_rel_of_call(Map<Text, Rel> m, ast::Expr c, Array<ast::Arg> args) {
    return std::make_shared<RelOfCall>(m, c, args);
}


/// KnownNonEmpty: fn (Text ==> Rel), Expr -> Bool
bool known_non_empty(const Map<Text, Rel>& m, const ast::Expr& e) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = name_of(e);
        if (prism_rtl::is_some(_m)) {
            auto&& n = prism_rtl::some_of(_m);
            _v.set(check_env::has_key(m, prism_rtl::cat("ne:", n)));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(false);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// ?CallOf: fn Expr -> ?((Expr, [Arg]))
std::optional<std::tuple<ast::Expr, Array<ast::Arg>>> call_of(const ast::Expr& e) {
    return ({
        __label__ _done;
        prism_rtl::Slot<std::optional<std::tuple<ast::Expr, Array<ast::Arg>>>> _v;
        auto&& _m = e.kind;
        if (prism_rtl::is<ast::ExprKind::ECall>(_m)) {
            auto&& c = prism_rtl::as<ast::ExprKind::ECall>(_m).a0;
            auto&& args = prism_rtl::as<ast::ExprKind::ECall>(_m).a1;
            _v.set(std::optional(std::tuple{c, args}));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EMethod>(_m)) {
            auto&& r = prism_rtl::as<ast::ExprKind::EMethod>(_m).a0;
            auto&& n = prism_rtl::as<ast::ExprKind::EMethod>(_m).a1;
            auto&& args = prism_rtl::as<ast::ExprKind::EMethod>(_m).a2;
            _v.set(std::optional(std::tuple{method_callee(n), method_args(r, args)}));
            goto _done;
        }
        {
            _v.set(std::optional<std::tuple<ast::Expr, Array<ast::Arg>>>{});
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// ?NoLargerArg: fn (Text ==> Rel), Expr, [Arg] -> ?Expr
std::optional<ast::Expr> no_larger_arg(const Map<Text, Rel>& m, const ast::Expr& c, const Array<ast::Arg>& args) {
    return ({
        __label__ _done;
        prism_rtl::Slot<std::optional<ast::Expr>> _v;
        auto&& _m = callee_name(c);
        if (prism_rtl::is_some(_m)) {
            auto&& n = prism_rtl::some_of(_m);
            _v.set(is_local(m, n)
                ? std::optional<ast::Expr>{}
                : ({
                __label__ _done;
                prism_rtl::Slot<std::optional<ast::Expr>> _v;
                auto&& _m = prelude::get(m, prism_rtl::cat("fn:", n));
                if (prism_rtl::is_some(_m)) {
                    auto&& s = prism_rtl::some_of(_m);
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<std::optional<ast::Expr>> _v;
                        auto&& _m = index(args, s.param);
                        if (prism_rtl::is_some(_m)) {
                            auto&& a = prism_rtl::some_of(_m);
                            _v.set(std::optional(a->value));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(std::optional<ast::Expr>{});
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(std::optional<ast::Expr>{});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(std::optional<ast::Expr>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// IsNoLargerPrelude: fn G, Text -> Bool
bool is_no_larger_prelude(const check_env::G& g, const Text& k) {
    return check_types::has_text(Array(std::vector{Text("Prelude.Take"), Text("Prelude.Drop"), Text("Prelude.Filter"), Text("Prelude.Remove"), Text("Prelude.Min")}), k) && is_prelude_key(g, k);
}


/// PartsSummaries: unbounded fn Shrink, [Def] -> (Text ==> Nat)
Map<Text, Nat> parts_summaries(const Shrink& sk, const Array<check_env::Def>& fns) {
    return run_to_end(fold_job(fns, Map<Text, Nat>{}, ({
        auto sk_1 = sk;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Nat>>(std::tuple<Map<Text, Nat>, check_env::Def>)>>(prism_rtl::rc([=](std::tuple<Map<Text, Nat>, check_env::Def> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sk_1_2 = sk_1;
            entered(once_job([=]() {
            return ({
                auto m = p0;
                auto d = p1;
                ({
                auto&& _m = d.body;
                prism_rtl::is<check_env::DefBody::DbFn>(_m) ? ({
                auto&& clauses = prism_rtl::as<check_env::DefBody::DbFn>(_m).a0;
                ({
                auto n = ({
                    __label__ _done;
                    prism_rtl::Slot<Nat> _v;
                    auto&& _m = index(clauses, Nat(0u));
                    if (prism_rtl::is_some(_m)) {
                        auto&& c0 = prism_rtl::some_of(_m);
                        _v.set(len(c0.params));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(Nat(0u));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                auto clauses_2 = clauses;
                call_value(filter_job(check_errors::range0(n), ({
                auto clauses_2_3 = clauses_2;
                auto sk_1_2_3 = sk_1_2;
                auto d_3 = d;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Nat)>>(prism_rtl::rc([=](Nat p0) {
                return ({
                    auto clauses_2_3_4 = clauses_2_3;
                    auto sk_1_2_3_4 = sk_1_2_3;
                    auto d_3_4 = d_3;
                    entered(once_job([=]() {
                    return ({
                        auto i = p0;
                        fold_job(clauses_2_3_4, true, ({
                        auto sk_1_2_3_4_4 = sk_1_2_3_4;
                        auto d_3_4_4 = d_3_4;
                        auto i_4 = i;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, ast::FnClause>)>>(prism_rtl::rc([=](std::tuple<bool, ast::FnClause> _p0) {
                        auto&& p0 = std::get<0>(_p0);
                        auto&& p1 = std::get<1>(_p0);
                        return ({
                            auto sk_1_2_3_4_4_5 = sk_1_2_3_4_4;
                            auto d_3_4_4_5 = d_3_4_4;
                            auto i_4_5 = i_4;
                            entered(once_job([=]() {
                            return ({
                                auto okc = p0;
                                auto c = p1;
                                (prism_rtl::finished(okc && clause_within(clause_base(sk_1_2_3_4_4_5, d_3_4_4_5, c), c, i_4_5)));
                            });
                        }));
                        });
                    })));
                    }))->cycle();
                    });
                }));
                });
            })));
            })), [=](Array<Nat> filter_100294) {
                return ({
                    auto ok = filter_100294;
                    ({
                    auto&& _m = index(ok, Nat(0u));
                    prism_rtl::is_some(_m) ? ({
                    auto&& i = prism_rtl::some_of(_m);
                    prism_rtl::finished(insert(m, d.qk, i));
                })
                    : prism_rtl::is_none(_m) ? prism_rtl::finished(m)
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            });
            });
            })
                : prism_rtl::finished(m);
            });
            });
        }));
        });
    }));
    })));
}


prism_rtl::Turn<Map<Text, Nat>> PartsSummaries::cycle() const {
    const auto& sk = this->sk;
    const auto& fns = this->fns;
    return fold_job(fns, Map<Text, Nat>{}, ({
        auto sk_1 = sk;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Nat>>(std::tuple<Map<Text, Nat>, check_env::Def>)>>(prism_rtl::rc([=](std::tuple<Map<Text, Nat>, check_env::Def> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sk_1_2 = sk_1;
            entered(once_job([=]() {
            return ({
                auto m = p0;
                auto d = p1;
                ({
                auto&& _m = d.body;
                prism_rtl::is<check_env::DefBody::DbFn>(_m) ? ({
                auto&& clauses = prism_rtl::as<check_env::DefBody::DbFn>(_m).a0;
                ({
                auto n = ({
                    __label__ _done;
                    prism_rtl::Slot<Nat> _v;
                    auto&& _m = index(clauses, Nat(0u));
                    if (prism_rtl::is_some(_m)) {
                        auto&& c0 = prism_rtl::some_of(_m);
                        _v.set(len(c0.params));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(Nat(0u));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                auto clauses_2 = clauses;
                call_value(filter_job(check_errors::range0(n), ({
                auto clauses_2_3 = clauses_2;
                auto sk_1_2_3 = sk_1_2;
                auto d_3 = d;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Nat)>>(prism_rtl::rc([=](Nat p0) {
                return ({
                    auto clauses_2_3_4 = clauses_2_3;
                    auto sk_1_2_3_4 = sk_1_2_3;
                    auto d_3_4 = d_3;
                    entered(once_job([=]() {
                    return ({
                        auto i = p0;
                        fold_job(clauses_2_3_4, true, ({
                        auto sk_1_2_3_4_4 = sk_1_2_3_4;
                        auto d_3_4_4 = d_3_4;
                        auto i_4 = i;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, ast::FnClause>)>>(prism_rtl::rc([=](std::tuple<bool, ast::FnClause> _p0) {
                        auto&& p0 = std::get<0>(_p0);
                        auto&& p1 = std::get<1>(_p0);
                        return ({
                            auto sk_1_2_3_4_4_5 = sk_1_2_3_4_4;
                            auto d_3_4_4_5 = d_3_4_4;
                            auto i_4_5 = i_4;
                            entered(once_job([=]() {
                            return ({
                                auto okc = p0;
                                auto c = p1;
                                (prism_rtl::finished(okc && clause_within(clause_base(sk_1_2_3_4_4_5, d_3_4_4_5, c), c, i_4_5)));
                            });
                        }));
                        });
                    })));
                    }))->cycle();
                    });
                }));
                });
            })));
            })), [=](Array<Nat> filter_100294) {
                return ({
                    auto ok = filter_100294;
                    ({
                    auto&& _m = index(ok, Nat(0u));
                    prism_rtl::is_some(_m) ? ({
                    auto&& i = prism_rtl::some_of(_m);
                    prism_rtl::finished(insert(m, d.qk, i));
                })
                    : prism_rtl::is_none(_m) ? prism_rtl::finished(m)
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            });
            });
            })
                : prism_rtl::finished(m);
            });
            });
        }));
        });
    }));
    }))->cycle();
}


/// `Start PartsSummaries, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, Nat>> start_parts_summaries(Shrink sk, Array<check_env::Def> fns) {
    return std::make_shared<PartsSummaries>(sk, fns);
}


/// ClauseWithin: unbounded fn (Text ==> Rel), FnClause, Nat -> Bool
bool clause_within(const Map<Text, Rel>& base, const ast::FnClause& c, const Nat& i) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = c.body;
        if (prism_rtl::is<ast::FnBody::BodyExpr>(_m)) {
            auto&& e = prism_rtl::as<ast::FnBody::BodyExpr>(_m).a0;
            _v.set(within(base, i, e));
            goto _done;
        }
        if (prism_rtl::is<ast::FnBody::BodyBlock>(_m)) {
            auto&& b = prism_rtl::as<ast::FnBody::BodyBlock>(_m).a0;
            _v.set(within_block(base, i, b));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<bool> ClauseWithin::cycle() const {
    const auto& base = this->base;
    const auto& c = this->c;
    const auto& i = this->i;
    return ({
        auto&& _m = c.body;
        prism_rtl::is<ast::FnBody::BodyExpr>(_m) ? ({
        auto&& e = prism_rtl::as<ast::FnBody::BodyExpr>(_m).a0;
        prism_rtl::more(prism_rtl::rc(Within(base, i, e)));
    })
        : prism_rtl::is<ast::FnBody::BodyBlock>(_m) ? ({
        auto&& b = prism_rtl::as<ast::FnBody::BodyBlock>(_m).a0;
        prism_rtl::more(prism_rtl::rc(WithinBlock(base, i, b)));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ClauseWithin, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_clause_within(Map<Text, Rel> base, ast::FnClause c, Nat i) {
    return std::make_shared<ClauseWithin>(base, c, i);
}


/// Within: unbounded fn (Text ==> Rel), Nat, Expr -> Bool
bool within(const Map<Text, Rel>& m, const Nat& i, const ast::Expr& e) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = rel_of(m, e);
        if (prism_rtl::is_some(_m)) {
            auto&& r = prism_rtl::some_of(_m);
            _v.set(r.param == i);
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<bool> _v;
                auto&& _m = e.kind;
                if (prism_rtl::is<ast::ExprKind::EArray>(_m)) {
                    auto&& es = prism_rtl::as<ast::ExprKind::EArray>(_m).a0;
                    _v.set(run_to_end(fold_job(es, true, ({
                        auto m_1 = m;
                        auto i_2 = i;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, ast::Expr>)>>(prism_rtl::rc([=](std::tuple<bool, ast::Expr> _p0) {
                        auto&& p0 = std::get<0>(_p0);
                        auto&& p1 = std::get<1>(_p0);
                        return ({
                            auto m_1_3 = m_1;
                            auto i_2_3 = i_2;
                            entered(once_job([=]() {
                            return ({
                                auto ok = p0;
                                auto x = p1;
                                (prism_rtl::finished(ok && part(m_1_3, i_2_3, x)));
                            });
                        }));
                        });
                    })));
                    }))));
                    goto _done;
                }
                if (prism_rtl::is<ast::ExprKind::EMap>(_m)) {
                    auto&& kvs = prism_rtl::as<ast::ExprKind::EMap>(_m).a0;
                    _v.set(run_to_end(fold_job(kvs, true, ({
                        auto m_1 = m;
                        auto i_2 = i;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<ast::Expr, ast::Expr>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<ast::Expr, ast::Expr>> _p0) {
                        auto&& p0 = std::get<0>(_p0);
                        auto&& p1 = std::get<1>(_p0);
                        return ({
                            auto m_1_3 = m_1;
                            auto i_2_3 = i_2;
                            entered(once_job([=]() {
                            return ({
                                auto ok = p0;
                                auto [k, v_] = p1;
                                (prism_rtl::finished((ok && part(m_1_3, i_2_3, k)) && part(m_1_3, i_2_3, v_)));
                            });
                        }));
                        });
                    })));
                    }))));
                    goto _done;
                }
                if (prism_rtl::is<ast::ExprKind::EGroup>(_m)) {
                    auto&& x = prism_rtl::as<ast::ExprKind::EGroup>(_m).a0;
                    _v.set(within(m, i, x));
                    goto _done;
                }
                if (prism_rtl::is<ast::ExprKind::EMatch>(_m)) {
                    auto&& s = prism_rtl::as<ast::ExprKind::EMatch>(_m).a0;
                    auto&& arms = prism_rtl::as<ast::ExprKind::EMatch>(_m).a1;
                    _v.set(run_to_end(fold_job(arms, true, ({
                        auto s_1 = s;
                        auto m_2 = m;
                        auto i_3 = i;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, ast::Arm>)>>(prism_rtl::rc([=](std::tuple<bool, ast::Arm> _p0) {
                        auto&& p0 = std::get<0>(_p0);
                        auto&& p1 = std::get<1>(_p0);
                        return ({
                            auto s_1_4 = s_1;
                            auto m_2_4 = m_2;
                            auto i_3_4 = i_3;
                            entered(once_job([=]() {
                            return ({
                                auto ok = p0;
                                auto a = p1;
                                (prism_rtl::finished(ok && within_block(arm_pat_rels(s_1_4, a, m_2_4), i_3_4, a.body)));
                            });
                        }));
                        });
                    })));
                    }))));
                    goto _done;
                }
                if (prism_rtl::is<ast::ExprKind::EIf>(_m) && prism_rtl::is_some(prism_rtl::as<ast::ExprKind::EIf>(_m).a2)) {
                    auto&& c = prism_rtl::as<ast::ExprKind::EIf>(_m).a0;
                    auto&& t = prism_rtl::as<ast::ExprKind::EIf>(_m).a1;
                    auto&& el = prism_rtl::some_of(prism_rtl::as<ast::ExprKind::EIf>(_m).a2);
                    _v.set(within_block(cond_rels(c, m), i, t) && within_block(m, i, el));
                    goto _done;
                }
                if (prism_rtl::is<ast::ExprKind::EUpdate>(_m)) {
                    auto&& start = prism_rtl::as<ast::ExprKind::EUpdate>(_m).a0;
                    auto&& b = prism_rtl::as<ast::ExprKind::EUpdate>(_m).a1;
                    _v.set(within(m, i, start) && update_within(insert(m, Text("&_"), Rel{.param = i, .strict = false}), i, b));
                    goto _done;
                }
                {
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<bool> _v;
                        auto&& _m = call_of(e);
                        if (prism_rtl::is_some(_m)) {
                            auto&& c = std::get<0>(prism_rtl::some_of(_m));
                            auto&& args = std::get<1>(prism_rtl::some_of(_m));
                            _v.set(({
                                __label__ _done;
                                prism_rtl::Slot<bool> _v;
                                auto&& _m = traversal_of(m, c, args);
                                if (prism_rtl::is_some(_m)) {
                                    auto&& coll = std::get<0>(prism_rtl::some_of(_m));
                                    auto&& step_ = std::get<1>(prism_rtl::some_of(_m));
                                    auto&& at = std::get<2>(prism_rtl::some_of(_m));
                                    _v.set(within(m, i, coll) && step_within(m, i, expr_name(c), coll, step_, at, or_(index(args, Nat(1u)), dummy_arg())->value));
                                    goto _done;
                                }
                                if (prism_rtl::is_none(_m)) {
                                    _v.set(false);
                                    goto _done;
                                }
                                prism_rtl::unreachable("no arm matched");
                            _done:
                                _v.take();
                            }));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(false);
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<bool> Within::cycle() const {
    const auto& m = this->m;
    const auto& i = this->i;
    const auto& e = this->e;
    auto e_1 = e;
    auto i_2 = i;
    auto m_3 = m;
    return call_then(start_rel_of(m_3, e_1), [=](std::optional<Rel> rel_of_100754) {
        return ({
            prism_rtl::is_some(rel_of_100754) ? ({
            auto&& r = prism_rtl::some_of(rel_of_100754);
            prism_rtl::finished(r.param == i_2);
        })
            : prism_rtl::is_none(rel_of_100754) ? ({
            auto&& _m = e_1.kind;
            prism_rtl::is<ast::ExprKind::EArray>(_m) ? ({
            auto&& es = prism_rtl::as<ast::ExprKind::EArray>(_m).a0;
            fold_job(es, true, ({
            auto m_3_4 = m_3;
            auto i_2_4 = i_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, ast::Expr>)>>(prism_rtl::rc([=](std::tuple<bool, ast::Expr> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto m_3_4_4 = m_3_4;
                auto i_2_4_4 = i_2_4;
                entered(once_job([=]() {
                return ({
                    auto ok = p0;
                    auto x = p1;
                    (prism_rtl::finished(ok && part(m_3_4_4, i_2_4_4, x)));
                });
            }));
            });
        })));
        }))->cycle();
        })
            : prism_rtl::is<ast::ExprKind::EMap>(_m) ? ({
            auto&& kvs = prism_rtl::as<ast::ExprKind::EMap>(_m).a0;
            fold_job(kvs, true, ({
            auto m_3_4 = m_3;
            auto i_2_4 = i_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<ast::Expr, ast::Expr>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<ast::Expr, ast::Expr>> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto m_3_4_4 = m_3_4;
                auto i_2_4_4 = i_2_4;
                entered(once_job([=]() {
                return ({
                    auto ok = p0;
                    auto [k, v_] = p1;
                    (prism_rtl::finished((ok && part(m_3_4_4, i_2_4_4, k)) && part(m_3_4_4, i_2_4_4, v_)));
                });
            }));
            });
        })));
        }))->cycle();
        })
            : prism_rtl::is<ast::ExprKind::EGroup>(_m) ? ({
            auto&& x = prism_rtl::as<ast::ExprKind::EGroup>(_m).a0;
            prism_rtl::more(prism_rtl::rc(Within(m_3, i_2, x)));
        })
            : prism_rtl::is<ast::ExprKind::EMatch>(_m) ? ({
            auto&& s = prism_rtl::as<ast::ExprKind::EMatch>(_m).a0;
            auto&& arms = prism_rtl::as<ast::ExprKind::EMatch>(_m).a1;
            fold_job(arms, true, ({
            auto s_4 = s;
            auto m_3_5 = m_3;
            auto i_2_5 = i_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, ast::Arm>)>>(prism_rtl::rc([=](std::tuple<bool, ast::Arm> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto s_4_5 = s_4;
                auto m_3_5_5 = m_3_5;
                auto i_2_5_5 = i_2_5;
                entered(once_job([=]() {
                return ({
                    auto ok = p0;
                    auto a = p1;
                    (prism_rtl::finished(ok && within_block(arm_pat_rels(s_4_5, a, m_3_5_5), i_2_5_5, a.body)));
                });
            }));
            });
        })));
        }))->cycle();
        })
            : prism_rtl::is<ast::ExprKind::EIf>(_m) && prism_rtl::is_some(prism_rtl::as<ast::ExprKind::EIf>(_m).a2) ? ({
            auto&& c = prism_rtl::as<ast::ExprKind::EIf>(_m).a0;
            auto&& t = prism_rtl::as<ast::ExprKind::EIf>(_m).a1;
            auto&& el = prism_rtl::some_of(prism_rtl::as<ast::ExprKind::EIf>(_m).a2);
            ({
            auto c_4 = c;
            auto el_5 = el;
            auto t_6 = t;
            call_then(start_cond_rels(c_4, m_3), [=](Map<Text, Rel> cond_rels_101138) { return call_then(start_within_block(cond_rels_101138, i_2, t_6), [=](bool within_block_101125) { return prism_rtl::finished(within_block_101125 && within_block(m_3, i_2, el_5)); }); });
        });
        })
            : prism_rtl::is<ast::ExprKind::EUpdate>(_m) ? ({
            auto&& start = prism_rtl::as<ast::ExprKind::EUpdate>(_m).a0;
            auto&& b = prism_rtl::as<ast::ExprKind::EUpdate>(_m).a1;
            ({
            auto b_4 = b;
            auto start_5 = start;
            call_then(start_within(m_3, i_2, start_5), [=](bool within_101212) { return prism_rtl::finished(within_101212 && update_within(insert(m_3, Text("&_"), Rel{.param = i_2, .strict = false}), i_2, b_4)); });
        });
        })
            : ({
            auto&& _m = call_of(e_1);
            prism_rtl::is_some(_m) ? ({
            auto&& c = std::get<0>(prism_rtl::some_of(_m));
            auto&& args = std::get<1>(prism_rtl::some_of(_m));
            ({
            auto&& _m = traversal_of(m_3, c, args);
            prism_rtl::is_some(_m) ? ({
            auto&& coll = std::get<0>(prism_rtl::some_of(_m));
            auto&& step_ = std::get<1>(prism_rtl::some_of(_m));
            auto&& at = std::get<2>(prism_rtl::some_of(_m));
            call_then(start_within(m_3, i_2, coll), [=](bool within_101433) { return prism_rtl::finished(within_101433 && step_within(m_3, i_2, expr_name(c), coll, step_, at, or_(index(args, Nat(1u)), dummy_arg())->value)); });
        })
            : prism_rtl::is_none(_m) ? prism_rtl::finished(false)
            : throw prism_rtl::Panic("no arm matched");
        });
        })
            : prism_rtl::is_none(_m) ? prism_rtl::finished(false)
            : throw prism_rtl::Panic("no arm matched");
        });
        })
            : throw prism_rtl::Panic("no arm matched");
        });
    });
}


/// `Start Within, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_within(Map<Text, Rel> m, Nat i, ast::Expr e) {
    return std::make_shared<Within>(m, i, e);
}


/// UpdateWithin: unbounded fn (Text ==> Rel), Nat, Block -> Bool
bool update_within(const Map<Text, Rel>& m, const Nat& i, const ast::Block& b) {
    return run_to_end(fold_job(stmts_spots(b.stmts, m), true, ({
        auto i_1 = i;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, Spot>)>>(prism_rtl::rc([=](std::tuple<bool, Spot> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto i_1_2 = i_1;
            entered(once_job([=]() {
            return ({
                auto ok = p0;
                auto sp = p1;
                (prism_rtl::finished(ok && spot_keeps_within(sp, i_1_2)));
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<bool> UpdateWithin::cycle() const {
    const auto& m = this->m;
    const auto& i = this->i;
    const auto& b = this->b;
    auto b_1 = b;
    auto i_2 = i;
    auto m_3 = m;
    return call_then(start_stmts_spots(b_1.stmts, m_3), [=](Array<Spot> stmts_spots_101895) {
        return fold_job(stmts_spots_101895, true, ({
            auto i_2_4 = i_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, Spot>)>>(prism_rtl::rc([=](std::tuple<bool, Spot> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto i_2_4_4 = i_2_4;
                entered(once_job([=]() {
                return ({
                    auto ok = p0;
                    auto sp = p1;
                    (prism_rtl::finished(ok && spot_keeps_within(sp, i_2_4_4)));
                });
            }));
            });
        })));
        }))->cycle();
    });
}


/// `Start UpdateWithin, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_update_within(Map<Text, Rel> m, Nat i, ast::Block b) {
    return std::make_shared<UpdateWithin>(m, i, b);
}


/// SpotKeepsWithin: unbounded fn Spot, Nat -> Bool
bool spot_keeps_within(const Spot& spot0, const Nat& n1) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = std::tuple{spot0, n1};
        if (prism_rtl::is<Spot::SpotStmt>(std::get<0>(_m))) {
            auto&& s = prism_rtl::as<Spot::SpotStmt>(std::get<0>(_m)).a0;
            auto&& m = prism_rtl::as<Spot::SpotStmt>(std::get<0>(_m)).a1;
            auto&& i = std::get<1>(_m);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<bool> _v;
                auto&& _m = s.kind;
                if (prism_rtl::is<ast::StmtKind::SSet>(_m)) {
                    auto&& t = prism_rtl::as<ast::StmtKind::SSet>(_m).a0;
                    auto&& value = prism_rtl::as<ast::StmtKind::SSet>(_m).a1;
                    _v.set(take(ref_path(t), Nat(1u)) != Array(std::vector{Text("&_")})
                        ? true
                        : (ref_path(t) == Array(std::vector{Text("&_")})) && within(m, i, value));
                    goto _done;
                }
                if (prism_rtl::is<ast::StmtKind::SAccum>(_m)) {
                    auto&& t = prism_rtl::as<ast::StmtKind::SAccum>(_m).a0;
                    _v.set(take(ref_path(t), Nat(1u)) != Array(std::vector{Text("&_")}));
                    goto _done;
                }
                {
                    _v.set(true);
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is<Spot::SpotExpr>(std::get<0>(_m))) {
            _v.set(true);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<bool> SpotKeepsWithin::cycle() const {
    const auto& spot0 = this->spot0;
    const auto& n1 = this->n1;
    return ({
        auto&& _m = std::tuple{spot0, n1};
        prism_rtl::is<Spot::SpotStmt>(std::get<0>(_m)) ? ({
        auto&& s = prism_rtl::as<Spot::SpotStmt>(std::get<0>(_m)).a0;
        auto&& m = prism_rtl::as<Spot::SpotStmt>(std::get<0>(_m)).a1;
        auto&& i = std::get<1>(_m);
        ({
        auto&& _m = s.kind;
        prism_rtl::is<ast::StmtKind::SSet>(_m) ? ({
        auto&& t = prism_rtl::as<ast::StmtKind::SSet>(_m).a0;
        auto&& value = prism_rtl::as<ast::StmtKind::SSet>(_m).a1;
        ({
        auto i_1 = i;
        auto m_2 = m;
        auto t_3 = t;
        auto value_4 = value;
        call_then(start_ref_path(t_3), [=](Array<Text> ref_path_102104) {
        return take(ref_path_102104, Nat(1u)) != Array(std::vector{Text("&_")})
            ? prism_rtl::finished(true)
            : call_then(start_ref_path(t_3), [=](Array<Text> ref_path_102152) { return prism_rtl::finished((ref_path_102152 == Array(std::vector{Text("&_")})) && within(m_2, i_1, value_4)); });
    });
    });
    })
        : prism_rtl::is<ast::StmtKind::SAccum>(_m) ? ({
        auto&& t = prism_rtl::as<ast::StmtKind::SAccum>(_m).a0;
        ({
        auto t_1 = t;
        call_then(start_ref_path(t_1), [=](Array<Text> ref_path_102235) { return prism_rtl::finished(take(ref_path_102235, Nat(1u)) != Array(std::vector{Text("&_")})); });
    });
    })
        : prism_rtl::finished(true);
    });
    })
        : prism_rtl::is<Spot::SpotExpr>(std::get<0>(_m)) ? prism_rtl::finished(true)
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start SpotKeepsWithin, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_spot_keeps_within(Spot spot0, Nat n1) {
    return std::make_shared<SpotKeepsWithin>(spot0, n1);
}


/// WithinBlock: unbounded fn (Text ==> Rel), Nat, Block -> Bool
bool within_block(const Map<Text, Rel>& m, const Nat& i, const ast::Block& b) {
    return within(block_rels(b.stmts, m), i, last_or(b));
}


prism_rtl::Turn<bool> WithinBlock::cycle() const {
    const auto& m = this->m;
    const auto& i = this->i;
    const auto& b = this->b;
    auto b_1 = b;
    auto i_2 = i;
    auto m_3 = m;
    return call_then(start_block_rels(b_1.stmts, m_3), [=](Map<Text, Rel> block_rels_102499) { return prism_rtl::more(prism_rtl::rc(Within(block_rels_102499, i_2, last_or(b_1)))); });
}


/// `Start WithinBlock, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_within_block(Map<Text, Rel> m, Nat i, ast::Block b) {
    return std::make_shared<WithinBlock>(m, i, b);
}


/// StepWithin: unbounded fn (Text ==> Rel), Nat, Text, Expr, Expr, Nat, Expr -> Bool
bool step_within(const Map<Text, Rel>& m, const Nat& i, const Text& f, const ast::Expr& coll, const ast::Expr& step_, const Nat& at, const ast::Expr& z) {
    return pre_is(m, f, Text("Filter"))
        ? true
        : ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = step_.kind;
        if (prism_rtl::is<ast::ExprKind::ELambda>(_m) && prism_rtl::is_some(prism_rtl::as<ast::ExprKind::ELambda>(_m).a0)) {
            auto&& ps = prism_rtl::some_of(prism_rtl::as<ast::ExprKind::ELambda>(_m).a0);
            auto&& body = prism_rtl::as<ast::ExprKind::ELambda>(_m).a1;
            _v.set(({
                auto sm = step_rels(m, coll, ps, at);
                auto [bm, x] = ({
                    __label__ _done;
                    prism_rtl::Slot<std::tuple<Map<Text, Rel>, ast::Expr>> _v;
                    auto&& _m = body;
                    if (prism_rtl::is<ast::LambdaBody::LbExpr>(_m)) {
                        auto&& y = prism_rtl::as<ast::LambdaBody::LbExpr>(_m).a0;
                        _v.set(std::tuple{sm, y});
                        goto _done;
                    }
                    if (prism_rtl::is<ast::LambdaBody::LbBlock>(_m)) {
                        auto&& b = prism_rtl::as<ast::LambdaBody::LbBlock>(_m).a0;
                        _v.set(std::tuple{block_rels(b.stmts, sm), last_or(b)});
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                pre_is(m, f, Text("Each"))
                ? part(bm, i, x)
                : ({
                __label__ _done;
                prism_rtl::Slot<bool> _v;
                auto&& _m = index(ps, Nat(0u));
                if (prism_rtl::is_some(_m)) {
                    auto&& acc = prism_rtl::some_of(_m);
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<bool> _v;
                        auto&& _m = acc.kind;
                        if (prism_rtl::is<ast::PatternKind::PName>(_m)) {
                            auto&& n = prism_rtl::as<ast::PatternKind::PName>(_m).a0;
                            _v.set(within(m, i, z) && builds_on(bm, i, check_env::sname_key(n), x));
                            goto _done;
                        }
                        {
                            _v.set(false);
                            goto _done;
                        }
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(false);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            }));
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<bool> StepWithin::cycle() const {
    const auto& m = this->m;
    const auto& i = this->i;
    const auto& f = this->f;
    const auto& coll = this->coll;
    const auto& step_ = this->step_;
    const auto& at = this->at;
    const auto& z = this->z;
    return pre_is(m, f, Text("Filter"))
        ? prism_rtl::finished(true)
        : ({
        auto&& _m = step_.kind;
        prism_rtl::is<ast::ExprKind::ELambda>(_m) && prism_rtl::is_some(prism_rtl::as<ast::ExprKind::ELambda>(_m).a0) ? ({
        auto&& ps = prism_rtl::some_of(prism_rtl::as<ast::ExprKind::ELambda>(_m).a0);
        auto&& body = prism_rtl::as<ast::ExprKind::ELambda>(_m).a1;
        ({
        auto at_1 = at;
        auto body_2 = body;
        auto coll_3 = coll;
        auto f_4 = f;
        auto i_5 = i;
        auto m_6 = m;
        auto ps_7 = ps;
        auto z_8 = z;
        call_then(start_step_rels(m_6, coll_3, ps_7, at_1), [=](Map<Text, Rel> step_rels_102929) {
        return ({
            auto sm = step_rels_102929;
            auto [bm, x] = ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<Map<Text, Rel>, ast::Expr>> _v;
                if (prism_rtl::is<ast::LambdaBody::LbExpr>(body)) {
                    auto&& y = prism_rtl::as<ast::LambdaBody::LbExpr>(body).a0;
                    _v.set(std::tuple{sm, y});
                    goto _done;
                }
                if (prism_rtl::is<ast::LambdaBody::LbBlock>(body)) {
                    auto&& b = prism_rtl::as<ast::LambdaBody::LbBlock>(body).a0;
                    _v.set(std::tuple{block_rels(b.stmts, sm), last_or(b)});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            pre_is(m_6, f_4, Text("Each"))
            ? prism_rtl::more(prism_rtl::rc(Part(bm, i_5, x)))
            : ({
            auto&& _m = index(ps_7, Nat(0u));
            prism_rtl::is_some(_m) ? ({
            auto&& acc = prism_rtl::some_of(_m);
            ({
            auto&& _m = acc.kind;
            prism_rtl::is<ast::PatternKind::PName>(_m) ? ({
            auto&& n = prism_rtl::as<ast::PatternKind::PName>(_m).a0;
            ({
            auto n_9 = n;
            call_then(start_within(m_6, i_5, z_8), [=](bool within_103246) { return prism_rtl::finished(within_103246 && builds_on(bm, i_5, check_env::sname_key(n_9), x)); });
        });
        })
            : prism_rtl::finished(false);
        });
        })
            : prism_rtl::is_none(_m) ? prism_rtl::finished(false)
            : throw prism_rtl::Panic("no arm matched");
        });
        });
    });
    });
    })
        : prism_rtl::finished(false);
    });
}


/// `Start StepWithin, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_step_within(Map<Text, Rel> m, Nat i, Text f, ast::Expr coll, ast::Expr step_, Nat at, ast::Expr z) {
    return std::make_shared<StepWithin>(m, i, f, coll, step_, at, z);
}


/// LastOr: fn Block -> Expr
ast::Expr last_or(const ast::Block& b) {
    return or_(last_expr(b), dummy_arg()->value);
}


/// BuildsOn: unbounded fn (Text ==> Rel), Nat, Text, Expr -> Bool
bool builds_on(const Map<Text, Rel>& m, const Nat& i, const Text& acc, const ast::Expr& e) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = e.kind;
        if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
            auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
            _v.set(check_env::sname_key(n) == acc);
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EGroup>(_m)) {
            auto&& x = prism_rtl::as<ast::ExprKind::EGroup>(_m).a0;
            _v.set(builds_on(m, i, acc, x));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EMatch>(_m)) {
            auto&& s = prism_rtl::as<ast::ExprKind::EMatch>(_m).a0;
            auto&& arms = prism_rtl::as<ast::ExprKind::EMatch>(_m).a1;
            _v.set(run_to_end(fold_job(arms, true, ({
                auto acc_1 = acc;
                auto s_2 = s;
                auto m_3 = m;
                auto i_4 = i;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, ast::Arm>)>>(prism_rtl::rc([=](std::tuple<bool, ast::Arm> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto acc_1_5 = acc_1;
                    auto s_2_5 = s_2;
                    auto m_3_5 = m_3;
                    auto i_4_5 = i_4;
                    entered(once_job([=]() {
                    return ({
                        auto ok = p0;
                        auto a = p1;
                        (prism_rtl::finished((ok && (!check_types::has_text(opt_names(a.pattern), acc_1_5))) && builds_on_block(arm_pat_rels(s_2_5, a, m_3_5), i_4_5, acc_1_5, a.body)));
                    });
                }));
                });
            })));
            }))));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EIf>(_m) && prism_rtl::is_some(prism_rtl::as<ast::ExprKind::EIf>(_m).a2)) {
            auto&& c = prism_rtl::as<ast::ExprKind::EIf>(_m).a0;
            auto&& t = prism_rtl::as<ast::ExprKind::EIf>(_m).a1;
            auto&& el = prism_rtl::some_of(prism_rtl::as<ast::ExprKind::EIf>(_m).a2);
            _v.set(((!check_types::has_text(cond_names(c), acc)) && builds_on_block(cond_rels(c, m), i, acc, t)) && builds_on_block(m, i, acc, el));
            goto _done;
        }
        {
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<bool> _v;
                auto&& _m = call_of(e);
                if (prism_rtl::is_some(_m)) {
                    auto&& c = std::get<0>(prism_rtl::some_of(_m));
                    auto&& args = std::get<1>(prism_rtl::some_of(_m));
                    _v.set(builds_on_call(m, i, acc, c, args));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(false);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<bool> BuildsOn::cycle() const {
    const auto& m = this->m;
    const auto& i = this->i;
    const auto& acc = this->acc;
    const auto& e = this->e;
    return ({
        auto&& _m = e.kind;
        prism_rtl::is<ast::ExprKind::EName>(_m) ? ({
        auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
        prism_rtl::finished(check_env::sname_key(n) == acc);
    })
        : prism_rtl::is<ast::ExprKind::EGroup>(_m) ? ({
        auto&& x = prism_rtl::as<ast::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(BuildsOn(m, i, acc, x)));
    })
        : prism_rtl::is<ast::ExprKind::EMatch>(_m) ? ({
        auto&& s = prism_rtl::as<ast::ExprKind::EMatch>(_m).a0;
        auto&& arms = prism_rtl::as<ast::ExprKind::EMatch>(_m).a1;
        fold_job(arms, true, ({
        auto acc_1 = acc;
        auto s_2 = s;
        auto m_3 = m;
        auto i_4 = i;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, ast::Arm>)>>(prism_rtl::rc([=](std::tuple<bool, ast::Arm> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto acc_1_5 = acc_1;
            auto s_2_5 = s_2;
            auto m_3_5 = m_3;
            auto i_4_5 = i_4;
            entered(once_job([=]() {
            return ({
                auto ok = p0;
                auto a = p1;
                (prism_rtl::finished((ok && (!check_types::has_text(opt_names(a.pattern), acc_1_5))) && builds_on_block(arm_pat_rels(s_2_5, a, m_3_5), i_4_5, acc_1_5, a.body)));
            });
        }));
        });
    })));
    }))->cycle();
    })
        : prism_rtl::is<ast::ExprKind::EIf>(_m) && prism_rtl::is_some(prism_rtl::as<ast::ExprKind::EIf>(_m).a2) ? ({
        auto&& c = prism_rtl::as<ast::ExprKind::EIf>(_m).a0;
        auto&& t = prism_rtl::as<ast::ExprKind::EIf>(_m).a1;
        auto&& el = prism_rtl::some_of(prism_rtl::as<ast::ExprKind::EIf>(_m).a2);
        ({
        auto acc_1 = acc;
        auto c_2 = c;
        auto el_3 = el;
        auto i_4 = i;
        auto m_5 = m;
        auto t_6 = t;
        call_then(start_cond_names(c_2), [=](Array<Text> cond_names_103960) { return prism_rtl::finished(((!check_types::has_text(cond_names_103960, acc_1)) && builds_on_block(cond_rels(c_2, m_5), i_4, acc_1, t_6)) && builds_on_block(m_5, i_4, acc_1, el_3)); });
    });
    })
        : ({
        auto&& _m = call_of(e);
        prism_rtl::is_some(_m) ? ({
        auto&& c = std::get<0>(prism_rtl::some_of(_m));
        auto&& args = std::get<1>(prism_rtl::some_of(_m));
        prism_rtl::more(prism_rtl::rc(BuildsOnCall(m, i, acc, c, args)));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(false)
        : throw prism_rtl::Panic("no arm matched");
    });
    });
}


/// `Start BuildsOn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_builds_on(Map<Text, Rel> m, Nat i, Text acc, ast::Expr e) {
    return std::make_shared<BuildsOn>(m, i, acc, e);
}


/// BuildsOnCall: unbounded fn (Text ==> Rel), Nat, Text, Expr, [Arg] -> Bool
bool builds_on_call(const Map<Text, Rel>& m, const Nat& i, const Text& acc, const ast::Expr& c, const Array<ast::Arg>& args) {
    auto f = expr_name(c);
    auto on_acc = builds_on(m, i, acc, or_(index(args, Nat(0u)), dummy_arg())->value);
    auto rest = each(drop(args, Nat(1u)), [&](const ast::Arg& a) { return a->value; });
    auto parts = run_to_end(fold_job(rest, true, ({
        auto m_1 = m;
        auto i_2 = i;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, ast::Expr>)>>(prism_rtl::rc([=](std::tuple<bool, ast::Expr> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto m_1_3 = m_1;
            auto i_2_3 = i_2;
            entered(once_job([=]() {
            return ({
                auto ok = p0;
                auto x = p1;
                (prism_rtl::finished(ok && part(m_1_3, i_2_3, x)));
            });
        }));
        });
    })));
    })));
    return !on_acc
        ? false
        : pre_is(m, f, Text("Push")) && (len(rest) == Nat(1u))
        ? parts
        : pre_is(m, f, Text("Insert")) && (len(rest) == Nat(2u))
        ? parts
        : pre_is(m, f, Text("Append")) && (len(rest) == Nat(1u))
        ? within(m, i, or_(index(rest, Nat(0u)), dummy_arg()->value))
        : false;
}


prism_rtl::Turn<bool> BuildsOnCall::cycle() const {
    const auto& m = this->m;
    const auto& i = this->i;
    const auto& acc = this->acc;
    const auto& c = this->c;
    const auto& args = this->args;
    auto f = expr_name(c);
    auto acc_1 = acc;
    auto args_2 = args;
    auto i_3 = i;
    auto m_4 = m;
    return call_then(start_builds_on(m_4, i_3, acc_1, or_(index(args_2, Nat(0u)), dummy_arg())->value), [=](bool builds_on_104390) {
        return ({
            auto on_acc = builds_on_104390;
            auto rest = each(drop(args_2, Nat(1u)), [&](const ast::Arg& a) { return a->value; });
            call_value(fold_job(rest, true, ({
            auto m_4_5 = m_4;
            auto i_3_5 = i_3;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, ast::Expr>)>>(prism_rtl::rc([=](std::tuple<bool, ast::Expr> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto m_4_5_5 = m_4_5;
                auto i_3_5_5 = i_3_5;
                entered(once_job([=]() {
                return ({
                    auto ok = p0;
                    auto x = p1;
                    (prism_rtl::finished(ok && part(m_4_5_5, i_3_5_5, x)));
                });
            }));
            });
        })));
        })), [=](bool fold_104504) {
            return ({
                auto parts = fold_104504;
                !on_acc
                ? prism_rtl::finished(false)
                : pre_is(m_4, f, Text("Push")) && (len(rest) == Nat(1u))
                ? prism_rtl::finished(parts)
                : pre_is(m_4, f, Text("Insert")) && (len(rest) == Nat(2u))
                ? prism_rtl::finished(parts)
                : pre_is(m_4, f, Text("Append")) && (len(rest) == Nat(1u))
                ? prism_rtl::more(prism_rtl::rc(Within(m_4, i_3, or_(index(rest, Nat(0u)), dummy_arg()->value))))
                : prism_rtl::finished(false);
            });
        });
        });
    });
}


/// `Start BuildsOnCall, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_builds_on_call(Map<Text, Rel> m, Nat i, Text acc, ast::Expr c, Array<ast::Arg> args) {
    return std::make_shared<BuildsOnCall>(m, i, acc, c, args);
}


/// BuildsOnBlock: unbounded fn (Text ==> Rel), Nat, Text, Block -> Bool
bool builds_on_block(const Map<Text, Rel>& m, const Nat& i, const Text& acc, const ast::Block& b) {
    return (!check_types::has_text(stmts_binders(b.stmts), acc)) && builds_on(block_rels(b.stmts, m), i, acc, last_or(b));
}


prism_rtl::Turn<bool> BuildsOnBlock::cycle() const {
    const auto& m = this->m;
    const auto& i = this->i;
    const auto& acc = this->acc;
    const auto& b = this->b;
    auto acc_1 = acc;
    auto b_2 = b;
    auto i_3 = i;
    auto m_4 = m;
    return call_then(start_stmts_binders(b_2.stmts), [=](Array<Text> stmts_binders_105064) { return prism_rtl::finished((!check_types::has_text(stmts_binders_105064, acc_1)) && builds_on(block_rels(b_2.stmts, m_4), i_3, acc_1, last_or(b_2))); });
}


/// `Start BuildsOnBlock, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_builds_on_block(Map<Text, Rel> m, Nat i, Text acc, ast::Block b) {
    return std::make_shared<BuildsOnBlock>(m, i, acc, b);
}


/// CondNames: unbounded fn Cond -> [Text]
Array<Text> cond_names(const ast::Cond& cond0) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Array<Text>> _v;
        if (prism_rtl::is<ast::Cond::CondBind>(cond0)) {
            auto&& p_ = prism_rtl::as<ast::Cond::CondBind>(cond0).a0;
            _v.set(check_env::pattern_names(p_));
            goto _done;
        }
        if (prism_rtl::is<ast::Cond::CondExpr>(cond0)) {
            _v.set(Array<Text>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Array<Text>> CondNames::cycle() const {
    const auto& cond0 = this->cond0;
    return ({
        prism_rtl::is<ast::Cond::CondBind>(cond0) ? ({
        auto&& p_ = prism_rtl::as<ast::Cond::CondBind>(cond0).a0;
        prism_rtl::more(prism_rtl::rc(check_env::PatternNames(p_)));
    })
        : prism_rtl::is<ast::Cond::CondExpr>(cond0) ? prism_rtl::finished(Array<Text>{})
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CondNames, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_cond_names(ast::Cond cond0) {
    return std::make_shared<CondNames>(cond0);
}


/// Part: unbounded fn (Text ==> Rel), Nat, Expr -> Bool
bool part(const Map<Text, Rel>& m, const Nat& i, const ast::Expr& e) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = e.kind;
        if (prism_rtl::is<ast::ExprKind::ETuple>(_m)) {
            auto&& es = prism_rtl::as<ast::ExprKind::ETuple>(_m).a0;
            _v.set(run_to_end(fold_job(es, true, ({
                auto m_1 = m;
                auto i_2 = i;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, ast::Expr>)>>(prism_rtl::rc([=](std::tuple<bool, ast::Expr> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto m_1_3 = m_1;
                    auto i_2_3 = i_2;
                    entered(once_job([=]() {
                    return ({
                        auto ok = p0;
                        auto x = p1;
                        (prism_rtl::finished(ok && part(m_1_3, i_2_3, x)));
                    });
                }));
                });
            })));
            }))));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EGroup>(_m)) {
            auto&& x = prism_rtl::as<ast::ExprKind::EGroup>(_m).a0;
            _v.set(part(m, i, x));
            goto _done;
        }
        {
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<bool> _v;
                auto&& _m = rel_of(m, e);
                if (prism_rtl::is_some(_m)) {
                    auto&& r = prism_rtl::some_of(_m);
                    _v.set((r.param == i) && r.strict);
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(false);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<bool> Part::cycle() const {
    const auto& m = this->m;
    const auto& i = this->i;
    const auto& e = this->e;
    return ({
        auto&& _m = e.kind;
        prism_rtl::is<ast::ExprKind::ETuple>(_m) ? ({
        auto&& es = prism_rtl::as<ast::ExprKind::ETuple>(_m).a0;
        fold_job(es, true, ({
        auto m_1 = m;
        auto i_2 = i;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, ast::Expr>)>>(prism_rtl::rc([=](std::tuple<bool, ast::Expr> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto m_1_3 = m_1;
            auto i_2_3 = i_2;
            entered(once_job([=]() {
            return ({
                auto ok = p0;
                auto x = p1;
                (prism_rtl::finished(ok && part(m_1_3, i_2_3, x)));
            });
        }));
        });
    })));
    }))->cycle();
    })
        : prism_rtl::is<ast::ExprKind::EGroup>(_m) ? ({
        auto&& x = prism_rtl::as<ast::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(Part(m, i, x)));
    })
        : ({
        auto e_1 = e;
        auto i_2 = i;
        auto m_3 = m;
        call_then(start_rel_of(m_3, e_1), [=](std::optional<Rel> rel_of_105479) {
        return ({
            prism_rtl::is_some(rel_of_105479) ? ({
            auto&& r = prism_rtl::some_of(rel_of_105479);
            prism_rtl::finished((r.param == i_2) && r.strict);
        })
            : prism_rtl::is_none(rel_of_105479) ? prism_rtl::finished(false)
            : throw prism_rtl::Panic("no arm matched");
        });
    });
    });
    });
}


/// `Start Part, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_part(Map<Text, Rel> m, Nat i, ast::Expr e) {
    return std::make_shared<Part>(m, i, e);
}


/// SummarySeeds: unbounded fn Shrink, Def, [Spot], (Text ==> Rel) -> (Text ==> Rel)
Map<Text, Rel> summary_seeds(const Shrink& sk, const check_env::Def& d, const Array<Spot>& spots, const Map<Text, Rel>& rels) {
    return fold(run_to_end(fold_job(spots, Array<Site>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Site>>(std::tuple<Array<Site>, Spot>)>>(prism_rtl::rc([=](std::tuple<Array<Site>, Spot> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto sp = p1;
                call_then(start_spot_sites(sp), [=](Array<Site> spot_sites_106155) { return prism_rtl::finished(append(acc, spot_sites_106155)); });
            });
        }));
    })))), rels, [&](const Map<Text, Rel>& m, const Site& site) {
        return is_local(site.rels, site.callee)
            ? m
            : ({
            __label__ _done;
            prism_rtl::Slot<Map<Text, Rel>> _v;
            auto&& _m = resolve_callee(sk.g, d.home, site.callee);
            if (prism_rtl::is_some(_m)) {
                auto&& k = prism_rtl::some_of(_m);
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Map<Text, Rel>> _v;
                    auto&& _m = prelude::get(sk.sums, k);
                    if (prism_rtl::is_some(_m)) {
                        auto&& i = prism_rtl::some_of(_m);
                        _v.set(insert(m, prism_rtl::cat("fn:", site.callee), Rel{.param = i, .strict = false}));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(is_no_larger_prelude(sk.g, k)
                            ? insert(m, prism_rtl::cat("fn:", site.callee), Rel{.param = Nat(0u), .strict = false})
                            : m);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(m);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
}


prism_rtl::Turn<Map<Text, Rel>> SummarySeeds::cycle() const {
    const auto& sk = this->sk;
    const auto& d = this->d;
    const auto& spots = this->spots;
    const auto& rels = this->rels;
    auto d_1 = d;
    auto rels_2 = rels;
    auto sk_3 = sk;
    auto spots_4 = spots;
    return call_value(fold_job(spots_4, Array<Site>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Site>>(std::tuple<Array<Site>, Spot>)>>(prism_rtl::rc([=](std::tuple<Array<Site>, Spot> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto sp = p1;
                call_then(start_spot_sites(sp), [=](Array<Site> spot_sites_106155) { return prism_rtl::finished(append(acc, spot_sites_106155)); });
            });
        }));
    }))), [=](Array<Site> fold_106113) {
        return prism_rtl::finished(fold(fold_106113, rels_2, [&](const Map<Text, Rel>& m, const Site& site) {
            return is_local(site.rels, site.callee)
                ? m
                : ({
                __label__ _done;
                prism_rtl::Slot<Map<Text, Rel>> _v;
                auto&& _m = resolve_callee(sk_3.g, d_1.home, site.callee);
                if (prism_rtl::is_some(_m)) {
                    auto&& k = prism_rtl::some_of(_m);
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<Map<Text, Rel>> _v;
                        auto&& _m = prelude::get(sk_3.sums, k);
                        if (prism_rtl::is_some(_m)) {
                            auto&& i = prism_rtl::some_of(_m);
                            _v.set(insert(m, prism_rtl::cat("fn:", site.callee), Rel{.param = i, .strict = false}));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(is_no_larger_prelude(sk_3.g, k)
                                ? insert(m, prism_rtl::cat("fn:", site.callee), Rel{.param = Nat(0u), .strict = false})
                                : m);
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(m);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
        }));
    });
}


/// `Start SummarySeeds, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, Rel>> start_summary_seeds(Shrink sk, check_env::Def d, Array<Spot> spots, Map<Text, Rel> rels) {
    return std::make_shared<SummarySeeds>(sk, d, spots, rels);
}


/// OptNames: unbounded fn ?Pattern -> [Text]
Array<Text> opt_names(const std::optional<ast::Pattern_>& opt0) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Array<Text>> _v;
        if (prism_rtl::is_some(opt0)) {
            auto&& p_ = prism_rtl::some_of(opt0);
            _v.set(check_env::pattern_names(p_));
            goto _done;
        }
        if (prism_rtl::is_none(opt0)) {
            _v.set(Array<Text>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Array<Text>> OptNames::cycle() const {
    const auto& opt0 = this->opt0;
    return ({
        prism_rtl::is_some(opt0) ? ({
        auto&& p_ = prism_rtl::some_of(opt0);
        prism_rtl::more(prism_rtl::rc(check_env::PatternNames(p_)));
    })
        : prism_rtl::is_none(opt0) ? prism_rtl::finished(Array<Text>{})
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start OptNames, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_opt_names(std::optional<ast::Pattern_> opt0) {
    return std::make_shared<OptNames>(opt0);
}


/// let dummyArg
ast::Arg dummy_arg() {
    return ast::Arg{.name = std::optional<ast::Ident>{}, .value = ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EError{})), .span = ast::Range{.start = Nat(0u), .end = Nat(0u)}}, .span = ast::Range{.start = Nat(0u), .end = Nat(0u)}};
}


/// ?DecrementOf: unbounded fn (Text ==> Rel), Expr -> ?Rel
std::optional<Rel> decrement_of(const Map<Text, Rel>& m, const ast::Expr& e) {
    return ({
        __label__ _done;
        prism_rtl::Slot<std::optional<Rel>> _v;
        auto&& _m = e.kind;
        if (prism_rtl::is<ast::ExprKind::EBinary>(_m)) {
            auto&& m106963_0_0 = prism_rtl::as<ast::ExprKind::EBinary>(_m).a0;
            auto&& l = prism_rtl::as<ast::ExprKind::EBinary>(_m).a1;
            auto&& r = prism_rtl::as<ast::ExprKind::EBinary>(_m).a2;
            if (m106963_0_0 == Text("-?")) {
                _v.set(is_positive_lit(r) && is_nat_minus(m, e)
                    ? smaller(m, l)
                    : std::optional<Rel>{});
                goto _done;
            }
        }
        if (prism_rtl::is<ast::ExprKind::EGroup>(_m)) {
            auto&& x = prism_rtl::as<ast::ExprKind::EGroup>(_m).a0;
            _v.set(decrement_of(m, x));
            goto _done;
        }
        {
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::optional<Rel>> _v;
                auto&& _m = call_of(e);
                if (prism_rtl::is_some(_m)) {
                    auto&& c = std::get<0>(prism_rtl::some_of(_m));
                    auto&& args = std::get<1>(prism_rtl::some_of(_m));
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<std::optional<Rel>> _v;
                        auto&& _m = callee_name(c);
                        if (prism_rtl::is_some(_m)) {
                            auto&& n = prism_rtl::some_of(_m);
                            _v.set(pre_is(m, n, Text("?Step"))
                                ? smaller(m, or_(index(args, Nat(0u)), dummy_arg())->value)
                                : std::optional<Rel>{});
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(std::optional<Rel>{});
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(std::optional<Rel>{});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::optional<Rel>> DecrementOf::cycle() const {
    const auto& m = this->m;
    const auto& e = this->e;
    return ({
        auto&& _m = e.kind;
        prism_rtl::is<ast::ExprKind::EBinary>(_m) && ({
        auto&& m106963_0_0 = prism_rtl::as<ast::ExprKind::EBinary>(_m).a0;
        auto&& l = prism_rtl::as<ast::ExprKind::EBinary>(_m).a1;
        auto&& r = prism_rtl::as<ast::ExprKind::EBinary>(_m).a2;
        (m106963_0_0 == Text("-?"));
    }) ? ({
        auto&& m106963_0_0 = prism_rtl::as<ast::ExprKind::EBinary>(_m).a0;
        auto&& l = prism_rtl::as<ast::ExprKind::EBinary>(_m).a1;
        auto&& r = prism_rtl::as<ast::ExprKind::EBinary>(_m).a2;
        is_positive_lit(r) && is_nat_minus(m, e)
        ? prism_rtl::finished(smaller(m, l))
        : prism_rtl::finished(std::optional<Rel>{});
    })
        : prism_rtl::is<ast::ExprKind::EGroup>(_m) ? ({
        auto&& x = prism_rtl::as<ast::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(DecrementOf(m, x)));
    })
        : ({
        auto&& _m = call_of(e);
        prism_rtl::is_some(_m) ? ({
        auto&& c = std::get<0>(prism_rtl::some_of(_m));
        auto&& args = std::get<1>(prism_rtl::some_of(_m));
        ({
        auto&& _m = callee_name(c);
        prism_rtl::is_some(_m) ? ({
        auto&& n = prism_rtl::some_of(_m);
        pre_is(m, n, Text("?Step"))
        ? prism_rtl::finished(smaller(m, or_(index(args, Nat(0u)), dummy_arg())->value))
        : prism_rtl::finished(std::optional<Rel>{});
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(std::optional<Rel>{})
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(std::optional<Rel>{})
        : throw prism_rtl::Panic("no arm matched");
    });
    });
}


/// `Start DecrementOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<Rel>> start_decrement_of(Map<Text, Rel> m, ast::Expr e) {
    return std::make_shared<DecrementOf>(m, e);
}


/// IsNatMinus: fn (Text ==> Rel), Expr -> Bool
bool is_nat_minus(const Map<Text, Rel>& m, const ast::Expr& e) {
    return pre_is(m, Text("-?"), Text("-?")) && is_nat_at(m, e);
}


/// ?Smaller: unbounded fn (Text ==> Rel), Expr -> ?Rel
std::optional<Rel> smaller(const Map<Text, Rel>& m, const ast::Expr& x) {
    return ({
        __label__ _done;
        prism_rtl::Slot<std::optional<Rel>> _v;
        auto&& _m = rel_of(m, x);
        if (prism_rtl::is_some(_m)) {
            auto&& r = prism_rtl::some_of(_m);
            _v.set(std::optional(Rel{.param = r.param, .strict = true}));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(std::optional<Rel>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// IsPositiveLit: fn Expr -> Bool
bool is_positive_lit(const ast::Expr& e) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = e.kind;
        if (prism_rtl::is<ast::ExprKind::ELit>(_m)) {
            auto&& l = prism_rtl::as<ast::ExprKind::ELit>(_m).a0;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<bool> _v;
                auto&& _m = l.kind;
                if (prism_rtl::is<ast::LitKind::LInt>(_m)) {
                    auto&& d = prism_rtl::as<ast::LitKind::LInt>(_m).a0;
                    _v.set(d != Text("0"));
                    goto _done;
                }
                {
                    _v.set(false);
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EGroup>(_m)) {
            auto&& x = prism_rtl::as<ast::ExprKind::EGroup>(_m).a0;
            _v.set(is_positive_lit(x));
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// Closure: unbounded fn [Sc] -> [Sc]
Array<Sc> closure(const Array<Sc>& graphs) {
    return closure_from(graphs, dedup(graphs), dedup(graphs));
}


prism_rtl::Turn<Array<Sc>> Closure::cycle() const {
    const auto& graphs = this->graphs;
    return prism_rtl::more(prism_rtl::rc(ClosureFrom(graphs, dedup(graphs), dedup(graphs))));
}


/// `Start Closure, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Sc>> start_closure(Array<Sc> graphs) {
    return std::make_shared<Closure>(graphs);
}


/// Dedup: fn [Sc] -> [Sc]
Array<Sc> dedup(const Array<Sc>& gs) {
    return fold(gs, Array<Sc>{}, [&](const Array<Sc>& acc, const Sc& g) { return has_sc(acc, g) ? acc : prelude::push(acc, g); });
}


/// ClosureFrom: unbounded fn [Sc], [Sc], [Sc] -> [Sc]
Array<Sc> closure_from(const Array<Sc>& base, const Array<Sc>& acc, const Array<Sc>& frontier) {
    auto fresh = fold(frontier, Array<Sc>{}, [&](const Array<Sc>& out, const Sc& a) { return fold(base, out, [&](const Array<Sc>& out2, const Sc& b) { return add_composed(acc, out2, a, b); }); });
    return len(fresh) == Nat(0u) ? acc : closure_from(base, append(acc, fresh), fresh);
}


prism_rtl::Turn<Array<Sc>> ClosureFrom::cycle() const {
    const auto& base = this->base;
    const auto& acc = this->acc;
    const auto& frontier = this->frontier;
    auto fresh = fold(frontier, Array<Sc>{}, [&](const Array<Sc>& out, const Sc& a) { return fold(base, out, [&](const Array<Sc>& out2, const Sc& b) { return add_composed(acc, out2, a, b); }); });
    return len(fresh) == Nat(0u)
        ? prism_rtl::finished(acc)
        : prism_rtl::more(prism_rtl::rc(ClosureFrom(base, append(acc, fresh), fresh)));
}


/// `Start ClosureFrom, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Sc>> start_closure_from(Array<Sc> base, Array<Sc> acc, Array<Sc> frontier) {
    return std::make_shared<ClosureFrom>(base, acc, frontier);
}


/// AddComposed: fn [Sc], [Sc], Sc, Sc -> [Sc]
Array<Sc> add_composed(const Array<Sc>& acc, const Array<Sc>& out, const Sc& a, const Sc& b) {
    return a.callee != b.caller
        ? out
        : ({
        auto c = compose(a, b);
        has_sc(acc, c) || has_sc(out, c) ? out : prelude::push(out, c);
    });
}


/// HasSc: fn [Sc], Sc -> Bool
bool has_sc(const Array<Sc>& xs, const Sc& c) {
    return fold(xs, false, [&](const bool& seen, const Sc& x) { return seen || (((x.caller == c.caller) && (x.callee == c.callee)) && (x->edges == c->edges)); });
}


/// Compose: fn Sc, Sc -> Sc
Sc compose(const Sc& a, const Sc& b) {
    auto pairs = fold(a->edges, Array<std::tuple<Nat, Nat, bool>>{}, [&](const Array<std::tuple<Nat, Nat, bool>>& acc, const std::tuple<Nat, Nat, bool>& _p1) {
        auto&& x = std::get<0>(_p1);
        auto&& y = std::get<1>(_p1);
        auto&& s1 = std::get<2>(_p1);
        return fold(b->edges, acc, [&](const Array<std::tuple<Nat, Nat, bool>>& acc2, const std::tuple<Nat, Nat, bool>& _p1) {
            auto&& y2 = std::get<0>(_p1);
            auto&& z = std::get<1>(_p1);
            auto&& s2 = std::get<2>(_p1);
            return y == y2 ? add_edge(acc2, x, z, s1 || s2) : acc2;
        });
    });
    return Sc{.caller = a.caller, .callee = b.callee, .edges = sort_edges(pairs), .span = a.span, .file = a->file, .arg = a.arg};
}


/// AddEdge: fn [((Nat, Nat, Bool))], Nat, Nat, Bool -> [((Nat, Nat, Bool))]
Array<std::tuple<Nat, Nat, bool>> add_edge(const Array<std::tuple<Nat, Nat, bool>>& es, const Nat& x, const Nat& z, const bool& s) {
    auto others = filter(es, [&](const std::tuple<Nat, Nat, bool>& _p0) {
        auto&& a = std::get<0>(_p0);
        auto&& b = std::get<1>(_p0);
        return !((a == x) && (b == z));
    });
    auto had = fold(es, false, [&](const bool& seen, const std::tuple<Nat, Nat, bool>& _p1) {
        auto&& a = std::get<0>(_p1);
        auto&& b = std::get<1>(_p1);
        auto&& t = std::get<2>(_p1);
        return seen || (((a == x) && (b == z)) && t);
    });
    return prelude::push(others, std::tuple{x, z, s || had});
}


/// SortEdges: fn [((Nat, Nat, Bool))] -> [((Nat, Nat, Bool))]
Array<std::tuple<Nat, Nat, bool>> sort_edges(const Array<std::tuple<Nat, Nat, bool>>& es) {
    return fold(es, Array<std::tuple<Nat, Nat, bool>>{}, [&](const Array<std::tuple<Nat, Nat, bool>>& acc, const std::tuple<Nat, Nat, bool>& e) { return append(prelude::push(filter(acc, [&](const std::tuple<Nat, Nat, bool>& x) { return edge_before(x, e); }), e), filter(acc, [&](const std::tuple<Nat, Nat, bool>& x) { return !edge_before(x, e); })); });
}


/// EdgeBefore: fn ((Nat, Nat, Bool)), ((Nat, Nat, Bool)) -> Bool
bool edge_before(const std::tuple<Nat, Nat, bool>& arg0, const std::tuple<Nat, Nat, bool>& arg1) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = std::tuple{arg0, arg1};
        {
            auto&& a1 = std::get<0>(std::get<0>(_m));
            auto&& b1 = std::get<1>(std::get<0>(_m));
            auto&& a2 = std::get<0>(std::get<1>(_m));
            auto&& b2 = std::get<1>(std::get<1>(_m));
            _v.set((a1 < a2) || ((a1 == a2) && (b1 < b2)));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// LoopsOf: unbounded fn Shrink, St, Def -> St
check_types::St loops_of(const Shrink& sk, const check_types::St& st, const check_env::Def& d) {
    auto unb = is_unbounded_key(sk.g, sig_key_of(sk, d.qk));
    return unb && (!st.recording)
        ? st
        : ({
        auto s0 = ({
            check_types::St this_ = st;
            this_.file = d->file;
            this_;
        });
        auto s1 = run_to_end(fold_job(def_clauses(d), s0, ({
            auto sk_1 = sk;
            auto d_2 = d;
            auto unb_3 = unb;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<check_types::St>(std::tuple<check_types::St, ast::FnClause>)>>(prism_rtl::rc([=](std::tuple<check_types::St, ast::FnClause> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto sk_1_4 = sk_1;
                auto d_2_4 = d_2;
                auto unb_3_4 = unb_3;
                entered(once_job([=]() {
                return ({
                    auto s = p0;
                    auto c = p1;
                    (prism_rtl::more(prism_rtl::rc(ClauseLoops(sk_1_4, s, d_2_4, c, unb_3_4))));
                });
            }));
            });
        })));
        })));
        ({
        check_types::St this_ = s1;
        this_.file = st->file;
        this_;
    });
    });
}


prism_rtl::Turn<check_types::St> LoopsOf::cycle() const {
    const auto& sk = this->sk;
    const auto& st = this->st;
    const auto& d = this->d;
    auto unb = is_unbounded_key(sk.g, sig_key_of(sk, d.qk));
    return unb && (!st.recording)
        ? prism_rtl::finished(st)
        : ({
        auto s0 = ({
            check_types::St this_ = st;
            this_.file = d->file;
            this_;
        });
        auto d_1 = d;
        auto sk_2 = sk;
        auto st_3 = st;
        call_value(fold_job(def_clauses(d_1), s0, ({
        auto sk_2_4 = sk_2;
        auto d_1_4 = d_1;
        auto unb_4 = unb;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<check_types::St>(std::tuple<check_types::St, ast::FnClause>)>>(prism_rtl::rc([=](std::tuple<check_types::St, ast::FnClause> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sk_2_4_5 = sk_2_4;
            auto d_1_4_5 = d_1_4;
            auto unb_4_5 = unb_4;
            entered(once_job([=]() {
            return ({
                auto s = p0;
                auto c = p1;
                (prism_rtl::more(prism_rtl::rc(ClauseLoops(sk_2_4_5, s, d_1_4_5, c, unb_4_5))));
            });
        }));
        });
    })));
    })), [=](check_types::St fold_110934) {
        return ({
            auto s1 = fold_110934;
            (prism_rtl::finished(({
            check_types::St this_ = s1;
            this_.file = st_3->file;
            this_;
        })));
        });
    });
    });
}


/// `Start LoopsOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<check_types::St> start_loops_of(Shrink sk, check_types::St st, check_env::Def d) {
    return std::make_shared<LoopsOf>(sk, st, d);
}


/// ClauseLoops: unbounded fn Shrink, St, Def, FnClause, Bool -> St
check_types::St clause_loops(const Shrink& sk, const check_types::St& st, const check_env::Def& d, const ast::FnClause& c, const bool& unb) {
    auto base = clause_base(sk, d, c);
    auto spots0 = body_spots(c.body, base);
    return !fold(spots0, false, [&](const bool& seen, const Spot& sp) { return seen || is_while_spot(sp); })
        ? st
        : ({
        auto spots = body_spots(c.body, summary_seeds(sk, d, spots0, base));
        run_to_end(fold_job(filter(spots, [&](const Spot& sp) { return is_while_spot(sp); }), st, ({
        auto d_1 = d;
        auto unb_2 = unb;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<check_types::St>(std::tuple<check_types::St, Spot>)>>(prism_rtl::rc([=](std::tuple<check_types::St, Spot> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto d_1_3 = d_1;
            auto unb_2_3 = unb_2;
            entered(once_job([=]() {
            return ({
                auto s = p0;
                auto sp = p1;
                ({
                prism_rtl::is<Spot::SpotStmt>(sp) ? ({
                auto&& w = prism_rtl::as<Spot::SpotStmt>(sp).a0;
                auto&& m = prism_rtl::as<Spot::SpotStmt>(sp).a1;
                ({
                auto&& _m = w.kind;
                prism_rtl::is<ast::StmtKind::SWhile>(_m) ? ({
                auto&& cond = prism_rtl::as<ast::StmtKind::SWhile>(_m).a0;
                auto&& body = prism_rtl::as<ast::StmtKind::SWhile>(_m).a1;
                prism_rtl::more(prism_rtl::rc(CheckWhile(s, cond, body, w.span, d_1_3.name, marks(m), unb_2_3)));
            })
                : prism_rtl::finished(s);
            });
            })
                : prism_rtl::finished(s);
            });
            });
        }));
        });
    })));
    })));
    });
}


prism_rtl::Turn<check_types::St> ClauseLoops::cycle() const {
    const auto& sk = this->sk;
    const auto& st = this->st;
    const auto& d = this->d;
    const auto& c = this->c;
    const auto& unb = this->unb;
    auto c_1 = c;
    auto d_2 = d;
    auto sk_3 = sk;
    auto st_4 = st;
    auto unb_5 = unb;
    return call_then(start_clause_base(sk_3, d_2, c_1), [=](Map<Text, Rel> clause_base_111160) {
        return ({
            auto base = clause_base_111160;
            call_then(start_body_spots(c_1.body, base), [=](Array<Spot> body_spots_111197) {
            return ({
                auto spots0 = body_spots_111197;
                !fold(spots0, false, [&](const bool& seen, const Spot& sp) { return seen || is_while_spot(sp); })
                ? prism_rtl::finished(st_4)
                : call_then(start_summary_seeds(sk_3, d_2, spots0, base), [=](Map<Text, Rel> summary_seeds_111341) {
                return call_then(start_body_spots(c_1.body, summary_seeds_111341), [=](Array<Spot> body_spots_111322) {
                    return ({
                        auto spots = body_spots_111322;
                        fold_job(filter(spots, [&](const Spot& sp) { return is_while_spot(sp); }), st_4, ({
                        auto d_2_6 = d_2;
                        auto unb_5_6 = unb_5;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<check_types::St>(std::tuple<check_types::St, Spot>)>>(prism_rtl::rc([=](std::tuple<check_types::St, Spot> _p0) {
                        auto&& p0 = std::get<0>(_p0);
                        auto&& p1 = std::get<1>(_p0);
                        return ({
                            auto d_2_6_6 = d_2_6;
                            auto unb_5_6_6 = unb_5_6;
                            entered(once_job([=]() {
                            return ({
                                auto s = p0;
                                auto sp = p1;
                                ({
                                prism_rtl::is<Spot::SpotStmt>(sp) ? ({
                                auto&& w = prism_rtl::as<Spot::SpotStmt>(sp).a0;
                                auto&& m = prism_rtl::as<Spot::SpotStmt>(sp).a1;
                                ({
                                auto&& _m = w.kind;
                                prism_rtl::is<ast::StmtKind::SWhile>(_m) ? ({
                                auto&& cond = prism_rtl::as<ast::StmtKind::SWhile>(_m).a0;
                                auto&& body = prism_rtl::as<ast::StmtKind::SWhile>(_m).a1;
                                prism_rtl::more(prism_rtl::rc(CheckWhile(s, cond, body, w.span, d_2_6_6.name, marks(m), unb_5_6_6)));
                            })
                                : prism_rtl::finished(s);
                            });
                            })
                                : prism_rtl::finished(s);
                            });
                            });
                        }));
                        });
                    })));
                    }))->cycle();
                    });
                });
            });
            });
        });
        });
    });
}


/// `Start ClauseLoops, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<check_types::St> start_clause_loops(Shrink sk, check_types::St st, check_env::Def d, ast::FnClause c, bool unb) {
    return std::make_shared<ClauseLoops>(sk, st, d, c, unb);
}


/// Marks: fn (Text ==> Rel) -> (Text ==> Rel)
Map<Text, Rel> marks(const Map<Text, Rel>& m) {
    return fold(keys(m), m, [&](const Map<Text, Rel>& m2, const Text& k) { return lexer::contains(k, Text(":")) ? m2 : prelude::remove(m2, k); });
}


/// IsWhileSpot: fn Spot -> Bool
bool is_while_spot(const Spot& spot0) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        if (prism_rtl::is<Spot::SpotStmt>(spot0)) {
            auto&& s = prism_rtl::as<Spot::SpotStmt>(spot0).a0;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<bool> _v;
                auto&& _m = s.kind;
                if (prism_rtl::is<ast::StmtKind::SWhile>(_m)) {
                    _v.set(true);
                    goto _done;
                }
                {
                    _v.set(false);
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is<Spot::SpotExpr>(spot0)) {
            _v.set(false);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// CheckWhile: unbounded fn St, Cond, Block, Range, Text, (Text ==> Rel), Bool -> St
check_types::St check_while(const check_types::St& st, const ast::Cond& c, const ast::Block& body, const ast::Range& span, const Text& name, const Map<Text, Rel>& seeds, const bool& unb) {
    auto vars = set_targets(body.stmts);
    auto base = fold(check_errors::range0(len(vars)), seeds, [&](const Map<Text, Rel>& m, const Nat& i) { return insert(m, or_(index(vars, i), Text("")), Rel{.param = i, .strict = false}); });
    auto rels = cond_rels(c, base);
    auto ok = run_to_end(fold_job(check_errors::range0(len(vars)), false, ({
        auto body_1 = body;
        auto vars_2 = vars;
        auto rels_3 = rels;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, Nat>)>>(prism_rtl::rc([=](std::tuple<bool, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto body_1_4 = body_1;
            auto vars_2_4 = vars_2;
            auto rels_3_4 = rels_3;
            entered(once_job([=]() {
            return ({
                auto seen = p0;
                auto i = p1;
                (prism_rtl::finished(seen || all_paths_strict(body_1_4.stmts, or_(index(vars_2_4, i), Text("")), i, rels_3_4)));
            });
        }));
        });
    })));
    })));
    return ok
        ? st
        : unb
        ? note_unshrunk(st, span)
        : check_types::err_fix(st, Text("may-not-end"), span, prism_rtl::cat("this loop in `", name, "` may not end: nothing it sets gets smaller on every turn"), prism_rtl::cat("set a local from `&x -? 1` through a pattern, as `while ? left <- &fuel -? 1:`, or mark `", name, "` `unbounded fn`"));
}


prism_rtl::Turn<check_types::St> CheckWhile::cycle() const {
    const auto& st = this->st;
    const auto& c = this->c;
    const auto& body = this->body;
    const auto& span = this->span;
    const auto& name = this->name;
    const auto& seeds = this->seeds;
    const auto& unb = this->unb;
    auto body_1 = body;
    auto c_2 = c;
    auto name_3 = name;
    auto seeds_4 = seeds;
    auto span_5 = span;
    auto st_6 = st;
    auto unb_7 = unb;
    return call_then(start_set_targets(body_1.stmts), [=](Array<Text> set_targets_112448) {
        return ({
            auto vars = set_targets_112448;
            auto base = fold(check_errors::range0(len(vars)), seeds_4, [&](const Map<Text, Rel>& m, const Nat& i) { return insert(m, or_(index(vars, i), Text("")), Rel{.param = i, .strict = false}); });
            call_then(start_cond_rels(c_2, base), [=](Map<Text, Rel> cond_rels_112762) {
            return ({
                auto rels = cond_rels_112762;
                call_value(fold_job(check_errors::range0(len(vars)), false, ({
                auto body_1_8 = body_1;
                auto vars_8 = vars;
                auto rels_9 = rels;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, Nat>)>>(prism_rtl::rc([=](std::tuple<bool, Nat> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto body_1_8_10 = body_1_8;
                    auto vars_8_10 = vars_8;
                    auto rels_9_10 = rels_9;
                    entered(once_job([=]() {
                    return ({
                        auto seen = p0;
                        auto i = p1;
                        (prism_rtl::finished(seen || all_paths_strict(body_1_8_10.stmts, or_(index(vars_8_10, i), Text("")), i, rels_9_10)));
                    });
                }));
                });
            })));
            })), [=](bool fold_112792) {
                return ({
                    auto ok = fold_112792;
                    ok
                    ? prism_rtl::finished(st_6)
                    : unb_7
                    ? prism_rtl::finished(note_unshrunk(st_6, span_5))
                    : prism_rtl::finished(check_types::err_fix(st_6, Text("may-not-end"), span_5, prism_rtl::cat("this loop in `", name_3, "` may not end: nothing it sets gets smaller on every turn"), prism_rtl::cat("set a local from `&x -? 1` through a pattern, as `while ? left <- &fuel -? 1:`, or mark `", name_3, "` `unbounded fn`")));
                });
            });
            });
        });
        });
    });
}


/// `Start CheckWhile, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<check_types::St> start_check_while(check_types::St st, ast::Cond c, ast::Block body, ast::Range span, Text name, Map<Text, Rel> seeds, bool unb) {
    return std::make_shared<CheckWhile>(st, c, body, span, name, seeds, unb);
}


/// NoteUnshrunk: fn St, Range -> St
check_types::St note_unshrunk(const check_types::St& st, const ast::Range& span) {
    check_types::St this_ = st;
    this_.typed.unshrunk = prelude::push(this_.typed.unshrunk, check_types::at_here(st, span));
    return this_;
}


/// SetTargets: unbounded fn [Stmt] -> [Text]
Array<Text> set_targets(const Array<ast::Stmt>& stmts) {
    return run_to_end(fold_job(stmts_spots(stmts, Map<Text, Rel>{}), Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Spot>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, Spot> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto sp = p1;
                call_then(start_spot_set_root(sp), [=](Array<Text> spot_set_root_113658) { return prism_rtl::finished(check_types::union_texts(acc, spot_set_root_113658)); });
            });
        }));
    }))));
}


prism_rtl::Turn<Array<Text>> SetTargets::cycle() const {
    const auto& stmts = this->stmts;
    auto stmts_1 = stmts;
    return call_then(start_stmts_spots(stmts_1, Map<Text, Rel>{}), [=](Array<Spot> stmts_spots_113601) {
        return fold_job(stmts_spots_113601, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Spot>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, Spot> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto sp = p1;
                    call_then(start_spot_set_root(sp), [=](Array<Text> spot_set_root_113658) { return prism_rtl::finished(check_types::union_texts(acc, spot_set_root_113658)); });
                });
            }));
        })))->cycle();
    });
}


/// `Start SetTargets, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_set_targets(Array<ast::Stmt> stmts) {
    return std::make_shared<SetTargets>(stmts);
}


/// SpotSetRoot: unbounded fn Spot -> [Text]
Array<Text> spot_set_root(const Spot& spot0) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Array<Text>> _v;
        if (prism_rtl::is<Spot::SpotStmt>(spot0)) {
            auto&& s = prism_rtl::as<Spot::SpotStmt>(spot0).a0;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<Array<Text>> _v;
                auto&& _m = s.kind;
                if (prism_rtl::is<ast::StmtKind::SSet>(_m)) {
                    auto&& t = prism_rtl::as<ast::StmtKind::SSet>(_m).a0;
                    _v.set(take(ref_path(t), Nat(1u)));
                    goto _done;
                }
                if (prism_rtl::is<ast::StmtKind::SAccum>(_m)) {
                    auto&& t = prism_rtl::as<ast::StmtKind::SAccum>(_m).a0;
                    _v.set(take(ref_path(t), Nat(1u)));
                    goto _done;
                }
                {
                    _v.set(Array<Text>{});
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is<Spot::SpotExpr>(spot0)) {
            _v.set(Array<Text>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Array<Text>> SpotSetRoot::cycle() const {
    const auto& spot0 = this->spot0;
    return ({
        prism_rtl::is<Spot::SpotStmt>(spot0) ? ({
        auto&& s = prism_rtl::as<Spot::SpotStmt>(spot0).a0;
        ({
        auto&& _m = s.kind;
        prism_rtl::is<ast::StmtKind::SSet>(_m) ? ({
        auto&& t = prism_rtl::as<ast::StmtKind::SSet>(_m).a0;
        ({
        auto t_1 = t;
        call_then(start_ref_path(t_1), [=](Array<Text> ref_path_113794) { return prism_rtl::finished(take(ref_path_113794, Nat(1u))); });
    });
    })
        : prism_rtl::is<ast::StmtKind::SAccum>(_m) ? ({
        auto&& t = prism_rtl::as<ast::StmtKind::SAccum>(_m).a0;
        ({
        auto t_1 = t;
        call_then(start_ref_path(t_1), [=](Array<Text> ref_path_113844) { return prism_rtl::finished(take(ref_path_113844, Nat(1u))); });
    });
    })
        : prism_rtl::finished(Array<Text>{});
    });
    })
        : prism_rtl::is<Spot::SpotExpr>(spot0) ? prism_rtl::finished(Array<Text>{})
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start SpotSetRoot, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_spot_set_root(Spot spot0) {
    return std::make_shared<SpotSetRoot>(spot0);
}


/// AllPathsStrict: unbounded fn [Stmt], Text, Nat, (Text ==> Rel) -> Bool
bool all_paths_strict(const Array<ast::Stmt>& stmts, const Text& v_, const Nat& vi, const Map<Text, Rel>& outer) {
    auto rels = block_rels(stmts, outer);
    return run_to_end(fold_job(stmts, false, ({
        auto v__1 = v_;
        auto vi_2 = vi;
        auto rels_3 = rels;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, ast::Stmt>)>>(prism_rtl::rc([=](std::tuple<bool, ast::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto v__1_4 = v__1;
            auto vi_2_4 = vi_2;
            auto rels_3_4 = rels_3;
            entered(once_job([=]() {
            return ({
                auto ok = p0;
                auto s = p1;
                ({
                auto&& _m = s.kind;
                prism_rtl::is<ast::StmtKind::SSet>(_m) ? ({
                auto&& t = prism_rtl::as<ast::StmtKind::SSet>(_m).a0;
                auto&& value = prism_rtl::as<ast::StmtKind::SSet>(_m).a1;
                ({
                auto t_4 = t;
                auto value_5 = value;
                call_then(start_ref_path(t_4), [=](Array<Text> ref_path_114529) {
                return ref_path_114529 == Array(std::vector{v__1_4})
                    ? is_zero_lit(value_5)
                    ? prism_rtl::finished(ok)
                    : prism_rtl::more(prism_rtl::rc(SetsStrict(value_5, v__1_4, vi_2_4, rels_3_4)))
                    : prism_rtl::finished(ok && (!stmt_sets_weak(s, v__1_4, vi_2_4, rels_3_4)));
            });
            });
            })
                : prism_rtl::is<ast::StmtKind::SExpr>(_m) ? ({
                auto&& e = prism_rtl::as<ast::StmtKind::SExpr>(_m).a0;
                ({
                auto&& _m = e.kind;
                prism_rtl::is<ast::ExprKind::EIf>(_m) ? ({
                auto&& c = prism_rtl::as<ast::ExprKind::EIf>(_m).a0;
                auto&& tb = prism_rtl::as<ast::ExprKind::EIf>(_m).a1;
                auto&& eb_opt = prism_rtl::as<ast::ExprKind::EIf>(_m).a2;
                ({
                auto eb_opt_4 = eb_opt;
                auto c_5 = c;
                auto tb_6 = tb;
                call_then(start_cond_rels(c_5, rels_3_4), [=](Map<Text, Rel> cond_rels_114754) {
                return ({
                    auto tr = cond_rels_114754;
                    ({
                    prism_rtl::is_some(eb_opt_4) ? ({
                    auto&& b = prism_rtl::some_of(eb_opt_4);
                    ({
                    auto b_7 = b;
                    call_then(start_all_paths_strict(tb_6.stmts, v__1_4, vi_2_4, tr), [=](bool all_paths_strict_114827) {
                    return all_paths_strict_114827 && all_paths_strict(b_7.stmts, v__1_4, vi_2_4, rels_3_4)
                        ? prism_rtl::finished(true)
                        : prism_rtl::finished((ok && (!sets_weak(tb_6.stmts, v__1_4, vi_2_4, tr))) && (!sets_weak(b_7.stmts, v__1_4, vi_2_4, rels_3_4)));
                });
                });
                })
                    : prism_rtl::is_none(eb_opt_4) ? prism_rtl::finished(ok && (!sets_weak(tb_6.stmts, v__1_4, vi_2_4, tr)))
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            });
            });
            })
                : prism_rtl::is<ast::ExprKind::EMatch>(_m) ? ({
                auto&& subj = prism_rtl::as<ast::ExprKind::EMatch>(_m).a0;
                auto&& arms = prism_rtl::as<ast::ExprKind::EMatch>(_m).a1;
                ({
                auto arms_4 = arms;
                auto subj_5 = subj;
                call_value(fold_job(arms_4, true, ({
                auto v__1_4_6 = v__1_4;
                auto vi_2_4_6 = vi_2_4;
                auto subj_5_6 = subj_5;
                auto rels_3_4_6 = rels_3_4;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, ast::Arm>)>>(prism_rtl::rc([=](std::tuple<bool, ast::Arm> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto v__1_4_6_6 = v__1_4_6;
                    auto vi_2_4_6_6 = vi_2_4_6;
                    auto subj_5_6_6 = subj_5_6;
                    auto rels_3_4_6_6 = rels_3_4_6;
                    entered(once_job([=]() {
                    return ({
                        auto all_arms = p0;
                        auto a = p1;
                        (prism_rtl::finished(all_arms && all_paths_strict(a.body.stmts, v__1_4_6_6, vi_2_4_6_6, arm_pat_rels(subj_5_6_6, a, rels_3_4_6_6))));
                    });
                }));
                });
            })));
            })), [=](bool fold_115116) {
                return fold_115116
                    ? prism_rtl::finished(true)
                    : prism_rtl::finished(ok && (!run_to_end(fold_job(arms_4, false, ({
                    auto v__1_4_6 = v__1_4;
                    auto vi_2_4_6 = vi_2_4;
                    auto subj_5_6 = subj_5;
                    auto rels_3_4_6 = rels_3_4;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, ast::Arm>)>>(prism_rtl::rc([=](std::tuple<bool, ast::Arm> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto v__1_4_6_6 = v__1_4_6;
                        auto vi_2_4_6_6 = vi_2_4_6;
                        auto subj_5_6_6 = subj_5_6;
                        auto rels_3_4_6_6 = rels_3_4_6;
                        entered(once_job([=]() {
                        return ({
                            auto any_arm = p0;
                            auto a = p1;
                            (prism_rtl::finished(any_arm || sets_weak(a.body.stmts, v__1_4_6_6, vi_2_4_6_6, arm_pat_rels(subj_5_6_6, a, rels_3_4_6_6))));
                        });
                    }));
                    });
                })));
                })))));
            });
            });
            })
                : prism_rtl::finished(ok && (!stmt_sets_weak(s, v__1_4, vi_2_4, rels_3_4)));
            });
            })
                : prism_rtl::finished(ok && (!stmt_sets_weak(s, v__1_4, vi_2_4, rels_3_4)));
            });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<bool> AllPathsStrict::cycle() const {
    const auto& stmts = this->stmts;
    const auto& v_ = this->v_;
    const auto& vi = this->vi;
    const auto& outer = this->outer;
    auto outer_1 = outer;
    auto stmts_2 = stmts;
    auto v__3 = v_;
    auto vi_4 = vi;
    return call_then(start_block_rels(stmts_2, outer_1), [=](Map<Text, Rel> block_rels_114421) {
        return ({
            auto rels = block_rels_114421;
            fold_job(stmts_2, false, ({
            auto v__3_5 = v__3;
            auto vi_4_5 = vi_4;
            auto rels_5 = rels;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, ast::Stmt>)>>(prism_rtl::rc([=](std::tuple<bool, ast::Stmt> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto v__3_5_6 = v__3_5;
                auto vi_4_5_6 = vi_4_5;
                auto rels_5_6 = rels_5;
                entered(once_job([=]() {
                return ({
                    auto ok = p0;
                    auto s = p1;
                    ({
                    auto&& _m = s.kind;
                    prism_rtl::is<ast::StmtKind::SSet>(_m) ? ({
                    auto&& t = prism_rtl::as<ast::StmtKind::SSet>(_m).a0;
                    auto&& value = prism_rtl::as<ast::StmtKind::SSet>(_m).a1;
                    ({
                    auto t_6 = t;
                    auto value_7 = value;
                    call_then(start_ref_path(t_6), [=](Array<Text> ref_path_114529) {
                    return ref_path_114529 == Array(std::vector{v__3_5_6})
                        ? is_zero_lit(value_7)
                        ? prism_rtl::finished(ok)
                        : prism_rtl::more(prism_rtl::rc(SetsStrict(value_7, v__3_5_6, vi_4_5_6, rels_5_6)))
                        : prism_rtl::finished(ok && (!stmt_sets_weak(s, v__3_5_6, vi_4_5_6, rels_5_6)));
                });
                });
                })
                    : prism_rtl::is<ast::StmtKind::SExpr>(_m) ? ({
                    auto&& e = prism_rtl::as<ast::StmtKind::SExpr>(_m).a0;
                    ({
                    auto&& _m = e.kind;
                    prism_rtl::is<ast::ExprKind::EIf>(_m) ? ({
                    auto&& c = prism_rtl::as<ast::ExprKind::EIf>(_m).a0;
                    auto&& tb = prism_rtl::as<ast::ExprKind::EIf>(_m).a1;
                    auto&& eb_opt = prism_rtl::as<ast::ExprKind::EIf>(_m).a2;
                    ({
                    auto eb_opt_6 = eb_opt;
                    auto c_7 = c;
                    auto tb_8 = tb;
                    call_then(start_cond_rels(c_7, rels_5_6), [=](Map<Text, Rel> cond_rels_114754) {
                    return ({
                        auto tr = cond_rels_114754;
                        ({
                        prism_rtl::is_some(eb_opt_6) ? ({
                        auto&& b = prism_rtl::some_of(eb_opt_6);
                        ({
                        auto b_9 = b;
                        call_then(start_all_paths_strict(tb_8.stmts, v__3_5_6, vi_4_5_6, tr), [=](bool all_paths_strict_114827) {
                        return all_paths_strict_114827 && all_paths_strict(b_9.stmts, v__3_5_6, vi_4_5_6, rels_5_6)
                            ? prism_rtl::finished(true)
                            : prism_rtl::finished((ok && (!sets_weak(tb_8.stmts, v__3_5_6, vi_4_5_6, tr))) && (!sets_weak(b_9.stmts, v__3_5_6, vi_4_5_6, rels_5_6)));
                    });
                    });
                    })
                        : prism_rtl::is_none(eb_opt_6) ? prism_rtl::finished(ok && (!sets_weak(tb_8.stmts, v__3_5_6, vi_4_5_6, tr)))
                        : throw prism_rtl::Panic("no arm matched");
                    });
                    });
                });
                });
                })
                    : prism_rtl::is<ast::ExprKind::EMatch>(_m) ? ({
                    auto&& subj = prism_rtl::as<ast::ExprKind::EMatch>(_m).a0;
                    auto&& arms = prism_rtl::as<ast::ExprKind::EMatch>(_m).a1;
                    ({
                    auto arms_6 = arms;
                    auto subj_7 = subj;
                    call_value(fold_job(arms_6, true, ({
                    auto v__3_5_6_8 = v__3_5_6;
                    auto vi_4_5_6_8 = vi_4_5_6;
                    auto subj_7_8 = subj_7;
                    auto rels_5_6_8 = rels_5_6;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, ast::Arm>)>>(prism_rtl::rc([=](std::tuple<bool, ast::Arm> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto v__3_5_6_8_8 = v__3_5_6_8;
                        auto vi_4_5_6_8_8 = vi_4_5_6_8;
                        auto subj_7_8_8 = subj_7_8;
                        auto rels_5_6_8_8 = rels_5_6_8;
                        entered(once_job([=]() {
                        return ({
                            auto all_arms = p0;
                            auto a = p1;
                            (prism_rtl::finished(all_arms && all_paths_strict(a.body.stmts, v__3_5_6_8_8, vi_4_5_6_8_8, arm_pat_rels(subj_7_8_8, a, rels_5_6_8_8))));
                        });
                    }));
                    });
                })));
                })), [=](bool fold_115116) {
                    return fold_115116
                        ? prism_rtl::finished(true)
                        : prism_rtl::finished(ok && (!run_to_end(fold_job(arms_6, false, ({
                        auto v__3_5_6_8 = v__3_5_6;
                        auto vi_4_5_6_8 = vi_4_5_6;
                        auto subj_7_8 = subj_7;
                        auto rels_5_6_8 = rels_5_6;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, ast::Arm>)>>(prism_rtl::rc([=](std::tuple<bool, ast::Arm> _p0) {
                        auto&& p0 = std::get<0>(_p0);
                        auto&& p1 = std::get<1>(_p0);
                        return ({
                            auto v__3_5_6_8_8 = v__3_5_6_8;
                            auto vi_4_5_6_8_8 = vi_4_5_6_8;
                            auto subj_7_8_8 = subj_7_8;
                            auto rels_5_6_8_8 = rels_5_6_8;
                            entered(once_job([=]() {
                            return ({
                                auto any_arm = p0;
                                auto a = p1;
                                (prism_rtl::finished(any_arm || sets_weak(a.body.stmts, v__3_5_6_8_8, vi_4_5_6_8_8, arm_pat_rels(subj_7_8_8, a, rels_5_6_8_8))));
                            });
                        }));
                        });
                    })));
                    })))));
                });
                });
                })
                    : prism_rtl::finished(ok && (!stmt_sets_weak(s, v__3_5_6, vi_4_5_6, rels_5_6)));
                });
                })
                    : prism_rtl::finished(ok && (!stmt_sets_weak(s, v__3_5_6, vi_4_5_6, rels_5_6)));
                });
                });
            }));
            });
        })));
        }))->cycle();
        });
    });
}


/// `Start AllPathsStrict, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_all_paths_strict(Array<ast::Stmt> stmts, Text v_, Nat vi, Map<Text, Rel> outer) {
    return std::make_shared<AllPathsStrict>(stmts, v_, vi, outer);
}


/// SetsWeak: unbounded fn [Stmt], Text, Nat, (Text ==> Rel) -> Bool
bool sets_weak(const Array<ast::Stmt>& stmts, const Text& v_, const Nat& vi, const Map<Text, Rel>& outer) {
    return run_to_end(fold_job(stmts_spots(stmts, outer), false, ({
        auto v__1 = v_;
        auto vi_2 = vi;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, Spot>)>>(prism_rtl::rc([=](std::tuple<bool, Spot> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto v__1_3 = v__1;
            auto vi_2_3 = vi_2;
            entered(once_job([=]() {
            return ({
                auto seen = p0;
                auto sp = p1;
                (prism_rtl::finished(seen || spot_sets_weak(sp, v__1_3, vi_2_3)));
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<bool> SetsWeak::cycle() const {
    const auto& stmts = this->stmts;
    const auto& v_ = this->v_;
    const auto& vi = this->vi;
    const auto& outer = this->outer;
    auto outer_1 = outer;
    auto stmts_2 = stmts;
    auto v__3 = v_;
    auto vi_4 = vi;
    return call_then(start_stmts_spots(stmts_2, outer_1), [=](Array<Spot> stmts_spots_115763) {
        return fold_job(stmts_spots_115763, false, ({
            auto v__3_5 = v__3;
            auto vi_4_5 = vi_4;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, Spot>)>>(prism_rtl::rc([=](std::tuple<bool, Spot> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto v__3_5_5 = v__3_5;
                auto vi_4_5_5 = vi_4_5;
                entered(once_job([=]() {
                return ({
                    auto seen = p0;
                    auto sp = p1;
                    (prism_rtl::finished(seen || spot_sets_weak(sp, v__3_5_5, vi_4_5_5)));
                });
            }));
            });
        })));
        }))->cycle();
    });
}


/// `Start SetsWeak, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_sets_weak(Array<ast::Stmt> stmts, Text v_, Nat vi, Map<Text, Rel> outer) {
    return std::make_shared<SetsWeak>(stmts, v_, vi, outer);
}


/// StmtSetsWeak: unbounded fn Stmt, Text, Nat, (Text ==> Rel) -> Bool
bool stmt_sets_weak(const ast::Stmt& s, const Text& v_, const Nat& vi, const Map<Text, Rel>& rels) {
    return run_to_end(fold_job(stmt_spots(s, rels), false, ({
        auto v__1 = v_;
        auto vi_2 = vi;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, Spot>)>>(prism_rtl::rc([=](std::tuple<bool, Spot> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto v__1_3 = v__1;
            auto vi_2_3 = vi_2;
            entered(once_job([=]() {
            return ({
                auto seen = p0;
                auto sp = p1;
                (prism_rtl::finished(seen || spot_sets_weak(sp, v__1_3, vi_2_3)));
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<bool> StmtSetsWeak::cycle() const {
    const auto& s = this->s;
    const auto& v_ = this->v_;
    const auto& vi = this->vi;
    const auto& rels = this->rels;
    auto rels_1 = rels;
    auto s_2 = s;
    auto v__3 = v_;
    auto vi_4 = vi;
    return call_then(start_stmt_spots(s_2, rels_1), [=](Array<Spot> stmt_spots_115946) {
        return fold_job(stmt_spots_115946, false, ({
            auto v__3_5 = v__3;
            auto vi_4_5 = vi_4;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, Spot>)>>(prism_rtl::rc([=](std::tuple<bool, Spot> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto v__3_5_5 = v__3_5;
                auto vi_4_5_5 = vi_4_5;
                entered(once_job([=]() {
                return ({
                    auto seen = p0;
                    auto sp = p1;
                    (prism_rtl::finished(seen || spot_sets_weak(sp, v__3_5_5, vi_4_5_5)));
                });
            }));
            });
        })));
        }))->cycle();
    });
}


/// `Start StmtSetsWeak, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_stmt_sets_weak(ast::Stmt s, Text v_, Nat vi, Map<Text, Rel> rels) {
    return std::make_shared<StmtSetsWeak>(s, v_, vi, rels);
}


/// SpotSetsWeak: unbounded fn Spot, Text, Nat -> Bool
bool spot_sets_weak(const Spot& spot0, const Text& text1, const Nat& n2) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = std::tuple{spot0, text1, n2};
        if (prism_rtl::is<Spot::SpotStmt>(std::get<0>(_m))) {
            auto&& s = prism_rtl::as<Spot::SpotStmt>(std::get<0>(_m)).a0;
            auto&& m = prism_rtl::as<Spot::SpotStmt>(std::get<0>(_m)).a1;
            auto&& v_ = std::get<1>(_m);
            auto&& vi = std::get<2>(_m);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<bool> _v;
                auto&& _m = s.kind;
                if (prism_rtl::is<ast::StmtKind::SSet>(_m)) {
                    auto&& t = prism_rtl::as<ast::StmtKind::SSet>(_m).a0;
                    auto&& value = prism_rtl::as<ast::StmtKind::SSet>(_m).a1;
                    _v.set(((take(ref_path(t), Nat(1u)) == Array(std::vector{v_})) && (!sets_strict(value, v_, vi, m))) && (!((ref_path(t) == Array(std::vector{v_})) && is_zero_lit(value))));
                    goto _done;
                }
                if (prism_rtl::is<ast::StmtKind::SAccum>(_m)) {
                    auto&& t = prism_rtl::as<ast::StmtKind::SAccum>(_m).a0;
                    _v.set(take(ref_path(t), Nat(1u)) == Array(std::vector{v_}));
                    goto _done;
                }
                {
                    _v.set(false);
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is<Spot::SpotExpr>(std::get<0>(_m))) {
            _v.set(false);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<bool> SpotSetsWeak::cycle() const {
    const auto& spot0 = this->spot0;
    const auto& text1 = this->text1;
    const auto& n2 = this->n2;
    return ({
        auto&& _m = std::tuple{spot0, text1, n2};
        prism_rtl::is<Spot::SpotStmt>(std::get<0>(_m)) ? ({
        auto&& s = prism_rtl::as<Spot::SpotStmt>(std::get<0>(_m)).a0;
        auto&& m = prism_rtl::as<Spot::SpotStmt>(std::get<0>(_m)).a1;
        auto&& v_ = std::get<1>(_m);
        auto&& vi = std::get<2>(_m);
        ({
        auto&& _m = s.kind;
        prism_rtl::is<ast::StmtKind::SSet>(_m) ? ({
        auto&& t = prism_rtl::as<ast::StmtKind::SSet>(_m).a0;
        auto&& value = prism_rtl::as<ast::StmtKind::SSet>(_m).a1;
        ({
        auto m_1 = m;
        auto t_2 = t;
        auto v__3 = v_;
        auto value_4 = value;
        auto vi_5 = vi;
        call_then(start_ref_path(t_2), [=](Array<Text> ref_path_116149) { return prism_rtl::finished(((take(ref_path_116149, Nat(1u)) == Array(std::vector{v__3})) && (!sets_strict(value_4, v__3, vi_5, m_1))) && (!((ref_path(t_2) == Array(std::vector{v__3})) && is_zero_lit(value_4)))); });
    });
    })
        : prism_rtl::is<ast::StmtKind::SAccum>(_m) ? ({
        auto&& t = prism_rtl::as<ast::StmtKind::SAccum>(_m).a0;
        ({
        auto t_1 = t;
        auto v__2 = v_;
        call_then(start_ref_path(t_1), [=](Array<Text> ref_path_116298) { return prism_rtl::finished(take(ref_path_116298, Nat(1u)) == Array(std::vector{v__2})); });
    });
    })
        : prism_rtl::finished(false);
    });
    })
        : prism_rtl::is<Spot::SpotExpr>(std::get<0>(_m)) ? prism_rtl::finished(false)
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start SpotSetsWeak, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_spot_sets_weak(Spot spot0, Text text1, Nat n2) {
    return std::make_shared<SpotSetsWeak>(spot0, text1, n2);
}


/// IsZeroLit: fn Expr -> Bool
bool is_zero_lit(const ast::Expr& e) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = e.kind;
        if (prism_rtl::is<ast::ExprKind::ELit>(_m)) {
            auto&& l = prism_rtl::as<ast::ExprKind::ELit>(_m).a0;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<bool> _v;
                auto&& _m = l.kind;
                if (prism_rtl::is<ast::LitKind::LInt>(_m)) {
                    auto&& d = prism_rtl::as<ast::LitKind::LInt>(_m).a0;
                    _v.set(d == Text("0"));
                    goto _done;
                }
                {
                    _v.set(false);
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EGroup>(_m)) {
            auto&& x = prism_rtl::as<ast::ExprKind::EGroup>(_m).a0;
            _v.set(is_zero_lit(x));
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// SetsStrict: unbounded fn Expr, Text, Nat, (Text ==> Rel) -> Bool
bool sets_strict(const ast::Expr& e, const Text& v_, const Nat& vi, const Map<Text, Rel>& rels) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = e.kind;
        if (prism_rtl::is<ast::ExprKind::EGroup>(_m)) {
            auto&& x = prism_rtl::as<ast::ExprKind::EGroup>(_m).a0;
            _v.set(sets_strict(x, v_, vi, rels));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EBinary>(_m)) {
            auto&& m117675_1_0 = prism_rtl::as<ast::ExprKind::EBinary>(_m).a0;
            auto&& l = prism_rtl::as<ast::ExprKind::EBinary>(_m).a1;
            if (m117675_1_0 == Text("-?")) {
                _v.set(is_nat_minus(rels, e) && sets_strict(l, v_, vi, rels));
                goto _done;
            }
        }
        {
            _v.set(rel_strict(rels, e, vi) || call_strict(e, v_, vi, rels));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<bool> SetsStrict::cycle() const {
    const auto& e = this->e;
    const auto& v_ = this->v_;
    const auto& vi = this->vi;
    const auto& rels = this->rels;
    return ({
        auto&& _m = e.kind;
        prism_rtl::is<ast::ExprKind::EGroup>(_m) ? ({
        auto&& x = prism_rtl::as<ast::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(SetsStrict(x, v_, vi, rels)));
    })
        : prism_rtl::is<ast::ExprKind::EBinary>(_m) && ({
        auto&& m117675_1_0 = prism_rtl::as<ast::ExprKind::EBinary>(_m).a0;
        auto&& l = prism_rtl::as<ast::ExprKind::EBinary>(_m).a1;
        (m117675_1_0 == Text("-?"));
    }) ? ({
        auto&& m117675_1_0 = prism_rtl::as<ast::ExprKind::EBinary>(_m).a0;
        auto&& l = prism_rtl::as<ast::ExprKind::EBinary>(_m).a1;
        prism_rtl::finished(is_nat_minus(rels, e) && sets_strict(l, v_, vi, rels));
    })
        : ({
        auto e_1 = e;
        auto rels_2 = rels;
        auto v__3 = v_;
        auto vi_4 = vi;
        call_then(start_rel_strict(rels_2, e_1, vi_4), [=](bool rel_strict_117825) { return prism_rtl::finished(rel_strict_117825 || call_strict(e_1, v__3, vi_4, rels_2)); });
    });
    });
}


/// `Start SetsStrict, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_sets_strict(ast::Expr e, Text v_, Nat vi, Map<Text, Rel> rels) {
    return std::make_shared<SetsStrict>(e, v_, vi, rels);
}


/// RelStrict: unbounded fn (Text ==> Rel), Expr, Nat -> Bool
bool rel_strict(const Map<Text, Rel>& rels, const ast::Expr& e, const Nat& vi) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = rel_of(rels, e);
        if (prism_rtl::is_some(_m)) {
            auto&& r = prism_rtl::some_of(_m);
            _v.set(r.strict && (r.param == vi));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(false);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<bool> RelStrict::cycle() const {
    const auto& rels = this->rels;
    const auto& e = this->e;
    const auto& vi = this->vi;
    auto e_1 = e;
    auto rels_2 = rels;
    auto vi_3 = vi;
    return call_then(start_rel_of(rels_2, e_1), [=](std::optional<Rel> rel_of_117971) {
        return ({
            prism_rtl::is_some(rel_of_117971) ? ({
            auto&& r = prism_rtl::some_of(rel_of_117971);
            prism_rtl::finished(r.strict && (r.param == vi_3));
        })
            : prism_rtl::is_none(rel_of_117971) ? prism_rtl::finished(false)
            : throw prism_rtl::Panic("no arm matched");
        });
    });
}


/// `Start RelStrict, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_rel_strict(Map<Text, Rel> rels, ast::Expr e, Nat vi) {
    return std::make_shared<RelStrict>(rels, e, vi);
}


/// CallStrict: unbounded fn Expr, Text, Nat, (Text ==> Rel) -> Bool
bool call_strict(const ast::Expr& e, const Text& v_, const Nat& vi, const Map<Text, Rel>& rels) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = call_of(e);
        if (prism_rtl::is_some(_m)) {
            auto&& c = std::get<0>(prism_rtl::some_of(_m));
            auto&& args = std::get<1>(prism_rtl::some_of(_m));
            _v.set(is_non_nat_min(rels, e, c)
                ? false
                : ({
                __label__ _done;
                prism_rtl::Slot<bool> _v;
                auto&& _m = no_larger_arg(rels, c, args);
                if (prism_rtl::is_some(_m)) {
                    auto&& a = prism_rtl::some_of(_m);
                    _v.set(sets_strict(a, v_, vi, rels));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(false);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(false);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<bool> CallStrict::cycle() const {
    const auto& e = this->e;
    const auto& v_ = this->v_;
    const auto& vi = this->vi;
    const auto& rels = this->rels;
    return ({
        auto&& _m = call_of(e);
        prism_rtl::is_some(_m) ? ({
        auto&& c = std::get<0>(prism_rtl::some_of(_m));
        auto&& args = std::get<1>(prism_rtl::some_of(_m));
        is_non_nat_min(rels, e, c)
        ? prism_rtl::finished(false)
        : ({
        auto&& _m = no_larger_arg(rels, c, args);
        prism_rtl::is_some(_m) ? ({
        auto&& a = prism_rtl::some_of(_m);
        prism_rtl::more(prism_rtl::rc(SetsStrict(a, v_, vi, rels)));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(false)
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(false)
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CallStrict, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_call_strict(ast::Expr e, Text v_, Nat vi, Map<Text, Rel> rels) {
    return std::make_shared<CallStrict>(e, v_, vi, rels);
}


/// DischargeIncls: unbounded fn G, St, Nat -> St
check_types::St discharge_incls(const check_env::G& g, const check_types::St& st, const Nat& from) {
    auto batch = drop(st.incls, from);
    return run_to_end(fold_job(batch, st, ({
        auto g_1 = g;
        auto batch_2 = batch;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<check_types::St>(std::tuple<check_types::St, check_types::Incl>)>>(prism_rtl::rc([=](std::tuple<check_types::St, check_types::Incl> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_1_3 = g_1;
            auto batch_2_3 = batch_2;
            entered(once_job([=]() {
            return ({
                auto s = p0;
                auto inc = p1;
                call_then(start_through(s, inc, batch_2_3), [=](check_types::Incl through_118996) { return prism_rtl::more(prism_rtl::rc(DischargeOne(g_1_3, s, through_118996))); });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<check_types::St> DischargeIncls::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    const auto& from = this->from;
    auto batch = drop(st.incls, from);
    return fold_job(batch, st, ({
        auto g_1 = g;
        auto batch_2 = batch;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<check_types::St>(std::tuple<check_types::St, check_types::Incl>)>>(prism_rtl::rc([=](std::tuple<check_types::St, check_types::Incl> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_1_3 = g_1;
            auto batch_2_3 = batch_2;
            entered(once_job([=]() {
            return ({
                auto s = p0;
                auto inc = p1;
                call_then(start_through(s, inc, batch_2_3), [=](check_types::Incl through_118996) { return prism_rtl::more(prism_rtl::rc(DischargeOne(g_1_3, s, through_118996))); });
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start DischargeIncls, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<check_types::St> start_discharge_incls(check_env::G g, check_types::St st, Nat from) {
    return std::make_shared<DischargeIncls>(g, st, from);
}


/// Through: unbounded fn St, Incl, [Incl] -> Incl
check_types::Incl through(const check_types::St& st, const check_types::Incl& inc, const Array<check_types::Incl>& batch) {
    auto sup = check_types::walk_row(st, inc.sup);
    return ({
        __label__ _done;
        prism_rtl::Slot<check_types::Incl> _v;
        auto&& _m = sup.tail;
        if (prism_rtl::is<check_types::Tail::TlFlex>(_m)) {
            auto&& n = prism_rtl::as<check_types::Tail::TlFlex>(_m).a0;
            _v.set(len(sup.fams) > Nat(0u)
                ? inc
                : run_to_end(fold_job(batch, inc, ({
                auto st_1 = st;
                auto n_2 = n;
                auto inc_3 = inc;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<check_types::Incl>(std::tuple<check_types::Incl, check_types::Incl>)>>(prism_rtl::rc([=](std::tuple<check_types::Incl, check_types::Incl> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto st_1_4 = st_1;
                    auto n_2_4 = n_2;
                    auto inc_3_4 = inc_3;
                    entered(once_job([=]() {
                    return ({
                        auto acc = p0;
                        auto other = p1;
                        call_then(check_types::start_walk_row(st_1_4, other.sub), [=](check_types::Rw walk_row_119510) {
                        return ({
                            auto sub = walk_row_119510;
                            ((len(sub.fams) == Nat(0u)) && (sub.tail == check_types::Tail(check_types::Tail::TlFlex{n_2_4}))) && (other != inc_3_4)
                            ? prism_rtl::finished(({
                            check_types::Incl this_ = acc;
                            this_.sup = other.sup;
                            this_;
                        }))
                            : prism_rtl::finished(acc);
                        });
                    });
                    });
                }));
                });
            })));
            }))));
            goto _done;
        }
        {
            _v.set(inc);
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<check_types::Incl> Through::cycle() const {
    const auto& st = this->st;
    const auto& inc = this->inc;
    const auto& batch = this->batch;
    auto batch_1 = batch;
    auto inc_2 = inc;
    auto st_3 = st;
    return call_then(check_types::start_walk_row(st_3, inc_2.sup), [=](check_types::Rw walk_row_119338) {
        return ({
            auto sup = walk_row_119338;
            ({
            auto&& _m = sup.tail;
            prism_rtl::is<check_types::Tail::TlFlex>(_m) ? ({
            auto&& n = prism_rtl::as<check_types::Tail::TlFlex>(_m).a0;
            len(sup.fams) > Nat(0u)
            ? prism_rtl::finished(inc_2)
            : fold_job(batch_1, inc_2, ({
            auto st_3_4 = st_3;
            auto n_4 = n;
            auto inc_2_5 = inc_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<check_types::Incl>(std::tuple<check_types::Incl, check_types::Incl>)>>(prism_rtl::rc([=](std::tuple<check_types::Incl, check_types::Incl> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto st_3_4_5 = st_3_4;
                auto n_4_5 = n_4;
                auto inc_2_5_5 = inc_2_5;
                entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto other = p1;
                    call_then(check_types::start_walk_row(st_3_4_5, other.sub), [=](check_types::Rw walk_row_119510) {
                    return ({
                        auto sub = walk_row_119510;
                        ((len(sub.fams) == Nat(0u)) && (sub.tail == check_types::Tail(check_types::Tail::TlFlex{n_4_5}))) && (other != inc_2_5_5)
                        ? prism_rtl::finished(({
                        check_types::Incl this_ = acc;
                        this_.sup = other.sup;
                        this_;
                    }))
                        : prism_rtl::finished(acc);
                    });
                });
                });
            }));
            });
        })));
        }))->cycle();
        })
            : prism_rtl::finished(inc_2);
        });
        });
    });
}


/// `Start Through, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<check_types::Incl> start_through(check_types::St st, check_types::Incl inc, Array<check_types::Incl> batch) {
    return std::make_shared<Through>(st, inc, batch);
}


/// DischargeOne: unbounded fn G, St, Incl -> St
check_types::St discharge_one(const check_env::G& g, const check_types::St& st, const check_types::Incl& inc) {
    auto sub = check_types::walk_row(st, inc.sub);
    auto sup = check_types::walk_row(st, inc.sup);
    auto st1 = ({
        __label__ _done;
        prism_rtl::Slot<check_types::St> _v;
        auto&& _m = sub.tail;
        if (prism_rtl::is<check_types::Tail::TlFlex>(_m)) {
            auto&& n = prism_rtl::as<check_types::Tail::TlFlex>(_m).a0;
            _v.set(close_tail(st, n));
            goto _done;
        }
        {
            _v.set(st);
            goto _done;
        }
    _done:
        _v.take();
    });
    auto sub2 = check_types::walk_row(st1, inc.sub);
    auto left = filter(sub2.fams, [&](const Text& f) { return (!check_types::has_text(sup.fams, f)) && (len(tags_left(g, f, sub2.minus)) > Nat(0u)); });
    auto tail_bad = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = std::tuple{sub2.tail, sup.tail};
        if (prism_rtl::is<check_types::Tail::TlRigid>(std::get<0>(_m)) && prism_rtl::is<check_types::Tail::TlRigid>(std::get<1>(_m))) {
            auto&& a = prism_rtl::as<check_types::Tail::TlRigid>(std::get<0>(_m)).a0;
            auto&& b = prism_rtl::as<check_types::Tail::TlRigid>(std::get<1>(_m)).a0;
            _v.set(a != b);
            goto _done;
        }
        if (prism_rtl::is<check_types::Tail::TlRigid>(std::get<0>(_m))) {
            _v.set(true);
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
    return (len(left) == Nat(0u)) && (!tail_bad)
        ? st1
        : ({
        auto s0 = ({
            check_types::St this_ = st1;
            this_.file = inc->file;
            this_;
        });
        auto tags = fold(left, Array<Text>{}, [&](const Array<Text>& acc, const Text& f) { return append(acc, tags_left(g, f, sub2.minus)); });
        auto s1 = inc.forward
            ? check_types::err_fix(s0, Text("forwarding"), inc.span, prism_rtl::cat("forwarding ", lexer::join(tags, Text(", ")), " from a scope that emits ", check_types::show_row(sup)), prism_rtl::cat("answer ", len(tags) == Nat(1u) ? Text("it") : Text("them"), " above this arm, for example `", or_(index(tags, Nat(0u)), Text("")), "(..): @ never`"))
            : check_types::err_fix(s0, Text("row-outside"), inc.span, prism_rtl::cat("a child that emits `", check_types::show_row(sub2), "` in a scope that emits `", check_types::show_row(sup), "`"), Text("widen the scope's `emit` row, or host the child with `@HostDocument`"));
        ({
        check_types::St this_ = s1;
        this_.file = st1->file;
        this_;
    });
    });
}


prism_rtl::Turn<check_types::St> DischargeOne::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    const auto& inc = this->inc;
    auto g_1 = g;
    auto inc_2 = inc;
    auto st_3 = st;
    return call_then(check_types::start_walk_row(st_3, inc_2.sub), [=](check_types::Rw walk_row_119829) {
        return ({
            auto sub = walk_row_119829;
            call_then(check_types::start_walk_row(st_3, inc_2.sup), [=](check_types::Rw walk_row_119863) {
            return ({
                auto sup = walk_row_119863;
                auto st1 = ({
                    __label__ _done;
                    prism_rtl::Slot<check_types::St> _v;
                    auto&& _m = sub.tail;
                    if (prism_rtl::is<check_types::Tail::TlFlex>(_m)) {
                        auto&& n = prism_rtl::as<check_types::Tail::TlFlex>(_m).a0;
                        _v.set(close_tail(st_3, n));
                        goto _done;
                    }
                    {
                        _v.set(st_3);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                call_then(check_types::start_walk_row(st1, inc_2.sub), [=](check_types::Rw walk_row_119984) {
                return ({
                    auto sub2 = walk_row_119984;
                    auto left = filter(sub2.fams, [&](const Text& f) { return (!check_types::has_text(sup.fams, f)) && (len(tags_left(g_1, f, sub2.minus)) > Nat(0u)); });
                    auto tail_bad = ({
                        __label__ _done;
                        prism_rtl::Slot<bool> _v;
                        auto&& _m = std::tuple{sub2.tail, sup.tail};
                        if (prism_rtl::is<check_types::Tail::TlRigid>(std::get<0>(_m)) && prism_rtl::is<check_types::Tail::TlRigid>(std::get<1>(_m))) {
                            auto&& a = prism_rtl::as<check_types::Tail::TlRigid>(std::get<0>(_m)).a0;
                            auto&& b = prism_rtl::as<check_types::Tail::TlRigid>(std::get<1>(_m)).a0;
                            _v.set(a != b);
                            goto _done;
                        }
                        if (prism_rtl::is<check_types::Tail::TlRigid>(std::get<0>(_m))) {
                            _v.set(true);
                            goto _done;
                        }
                        {
                            _v.set(false);
                            goto _done;
                        }
                    _done:
                        _v.take();
                    });
                    (len(left) == Nat(0u)) && (!tail_bad)
                    ? prism_rtl::finished(st1)
                    : ({
                    auto s0 = ({
                        check_types::St this_ = st1;
                        this_.file = inc_2->file;
                        this_;
                    });
                    auto tags = fold(left, Array<Text>{}, [&](const Array<Text>& acc, const Text& f) { return append(acc, tags_left(g_1, f, sub2.minus)); });
                    auto s1 = inc_2.forward
                        ? check_types::err_fix(s0, Text("forwarding"), inc_2.span, prism_rtl::cat("forwarding ", lexer::join(tags, Text(", ")), " from a scope that emits ", check_types::show_row(sup)), prism_rtl::cat("answer ", len(tags) == Nat(1u) ? Text("it") : Text("them"), " above this arm, for example `", or_(index(tags, Nat(0u)), Text("")), "(..): @ never`"))
                        : check_types::err_fix(s0, Text("row-outside"), inc_2.span, prism_rtl::cat("a child that emits `", check_types::show_row(sub2), "` in a scope that emits `", check_types::show_row(sup), "`"), Text("widen the scope's `emit` row, or host the child with `@HostDocument`"));
                    (prism_rtl::finished(({
                    check_types::St this_ = s1;
                    this_.file = st1->file;
                    this_;
                })));
                });
                });
            });
            });
        });
        });
    });
}


/// `Start DischargeOne, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<check_types::St> start_discharge_one(check_env::G g, check_types::St st, check_types::Incl inc) {
    return std::make_shared<DischargeOne>(g, st, inc);
}


/// TagsLeft: fn G, Text, [Text] -> [Text]
Array<Text> tags_left(const check_env::G& g, const Text& fam, const Array<Text>& minus) {
    return filter(or_(prelude::get(g.families, fam), Array<Text>{}), [&](const Text& t) { return (!check_types::has_text(minus, t)) && is_element_tag(g, t); });
}


/// IsElementTag: fn G, Text -> Bool
bool is_element_tag(const check_env::G& g, const Text& t) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = prelude::get(g.tags, t);
        if (prism_rtl::is_some(_m)) {
            auto&& tg = prism_rtl::some_of(_m);
            _v.set(tg.kind == Text("Element"));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(false);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// CloseTail: fn St, Nat -> St
check_types::St close_tail(const check_types::St& st, const Nat& n) {
    check_types::St this_ = st;
    this_.rows = insert(this_.rows, n, check_types::empty_row());
    return this_;
}


/// CheckProgram: unbounded fn [Src], [Module], [Text], Nat, Bool, Bool -> Report
Report_ check_program(const Array<check_errors::Src>& srcs, const Array<ast::Module>& trees, const Array<Text>& world, const Nat& shown, const bool& recording, const bool& unused) {
    auto [g0a, stb] = check_env::build_g(srcs, trees);
    auto g0 = ({
        check_env::G this_ = g0a;
        this_.prelude_from = shown;
        this_;
    });
    auto st0 = ({
        check_types::St this_ = stb;
        this_.recording = recording;
        this_;
    });
    auto [g1, st1] = top_lets(g0, st0);
    auto [failed, st2] = run_to_end(fold_job(g1.defs, std::tuple{Array<Text>{}, st1}, ({
        auto g1_1 = g1;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, check_types::St>>(std::tuple<std::tuple<Array<Text>, check_types::St>, check_env::Def>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<Text>, check_types::St>, check_env::Def> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g1_1_2 = g1_1;
            entered(once_job([=]() {
            return ({
                auto [bad, s] = p0;
                auto d = p1;
                ({
                auto before = len(s.diags);
                call_then(start_check_def(g1_1_2, s, d), [=](check_types::St check_def_122502) {
                return ({
                    auto s2 = check_def_122502;
                    auto bad2 = len(s2.diags) > before ? prelude::push(bad, own_key(d).qk) : bad;
                    (prism_rtl::finished(std::tuple{bad2, s2}));
                });
            });
            });
            });
        }));
        });
    }));
    })));
    auto st2b = ({
        check_types::St this_ = st2;
        this_.level = Nat(0u);
        this_;
    });
    auto st3 = check_env::default_wants(g1, st2b, Array<std::tuple<Text, Text>>{});
    auto good = filter(g1.defs, [&](const check_env::Def& d) { return !check_types::has_text(failed, own_key(d).qk); });
    auto [st4, refs] = shrink_check(g1, st3, good);
    auto [root_row_, st5] = root_row(g1, st4, world);
    auto warnings = unused ? unused_defs(good, refs, shown) : Array<check_errors::CDiag>{};
    auto diags = check_errors::sort_diags(append(filter(st5.diags, [&](const check_errors::CDiag& d) { return d->file < shown; }), warnings));
    auto text = concat(each(diags, [&](const check_errors::CDiag& d) { return check_errors::render_cdiag(srcs, d); }));
    auto typed_1 = recording ? typed_of(g1, st5, shown) : typed::empty_typed();
    return Report_{.text = text, .errors = len(filter(diags, [&](const check_errors::CDiag& d) { return !check_errors::is_warning(d); })), .root_row = root_row_, .typed = typed_1};
}


prism_rtl::Turn<Report_> CheckProgram::cycle() const {
    const auto& srcs = this->srcs;
    const auto& trees = this->trees;
    const auto& world = this->world;
    const auto& shown = this->shown;
    const auto& recording = this->recording;
    const auto& unused = this->unused;
    auto recording_1 = recording;
    auto shown_2 = shown;
    auto srcs_3 = srcs;
    auto trees_4 = trees;
    auto unused_5 = unused;
    auto world_6 = world;
    return call_then(check_env::start_build_g(srcs_3, trees_4), [=](std::tuple<check_env::G, check_types::St> build_g_122061) {
        return ({
            auto [g0a, stb] = build_g_122061;
            auto g0 = ({
                check_env::G this_ = g0a;
                this_.prelude_from = shown_2;
                this_;
            });
            auto st0 = ({
                check_types::St this_ = stb;
                this_.recording = recording_1;
                this_;
            });
            call_then(start_top_lets(g0, st0), [=](std::tuple<check_env::G, check_types::St> top_lets_122364) {
            return ({
                auto [g1, st1] = top_lets_122364;
                call_value(fold_job(g1.defs, std::tuple{Array<Text>{}, st1}, ({
                auto g1_7 = g1;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, check_types::St>>(std::tuple<std::tuple<Array<Text>, check_types::St>, check_env::Def>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<Text>, check_types::St>, check_env::Def> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto g1_7_8 = g1_7;
                    entered(once_job([=]() {
                    return ({
                        auto [bad, s] = p0;
                        auto d = p1;
                        ({
                        auto before = len(s.diags);
                        call_then(start_check_def(g1_7_8, s, d), [=](check_types::St check_def_122502) {
                        return ({
                            auto s2 = check_def_122502;
                            auto bad2 = len(s2.diags) > before ? prelude::push(bad, own_key(d).qk) : bad;
                            (prism_rtl::finished(std::tuple{bad2, s2}));
                        });
                    });
                    });
                    });
                }));
                });
            }));
            })), [=](std::tuple<Array<Text>, check_types::St> fold_122406) {
                return ({
                    auto [failed, st2] = fold_122406;
                    auto st2b = ({
                        check_types::St this_ = st2;
                        this_.level = Nat(0u);
                        this_;
                    });
                    call_then(check_env::start_default_wants(g1, st2b, Array<std::tuple<Text, Text>>{}), [=](check_types::St default_wants_122685) {
                    return ({
                        auto st3 = default_wants_122685;
                        auto good = filter(g1.defs, [&](const check_env::Def& d) { return !check_types::has_text(failed, own_key(d).qk); });
                        call_then(start_shrink_check(g1, st3, good), [=](std::tuple<check_types::St, Array<std::tuple<Text, Array<Text>>>> shrink_check_122956) {
                        return ({
                            auto [st4, refs] = shrink_check_122956;
                            call_then(start_root_row(g1, st4, world_6), [=](std::tuple<Text, check_types::St> root_row_123009) {
                            return ({
                                auto [root_row_, st5] = root_row_123009;
                                auto warnings = unused_5 ? unused_defs(good, refs, shown_2) : Array<check_errors::CDiag>{};
                                auto diags = check_errors::sort_diags(append(filter(st5.diags, [&](const check_errors::CDiag& d) { return d->file < shown_2; }), warnings));
                                auto text = concat(each(diags, [&](const check_errors::CDiag& d) { return check_errors::render_cdiag(srcs_3, d); }));
                                auto typed_7 = recording_1 ? typed_of(g1, st5, shown_2) : typed::empty_typed();
                                (prism_rtl::finished(Report_{.text = text, .errors = len(filter(diags, [&](const check_errors::CDiag& d) { return !check_errors::is_warning(d); })), .root_row = root_row_, .typed = typed_7}));
                            });
                        });
                        });
                    });
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start CheckProgram, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Report_> start_check_program(Array<check_errors::Src> srcs, Array<ast::Module> trees, Array<Text> world, Nat shown, bool recording, bool unused) {
    return std::make_shared<CheckProgram>(srcs, trees, world, shown, recording, unused);
}


/// TypedOf: unbounded fn G, St, Nat -> TProgram
typed::TProgram typed_of(const check_env::G& g, const check_types::St& st, const Nat& shown) {
    auto z = check_types::zonk_typed(st);
    auto vals = filter(values(g.vals), [&](const check_env::ValInfo& v_) { return ((v_->file < shown) && (v_.sort != Text("builtin"))) && (or_(prelude::get(g.mods, v_.home), check_env::dummy_mod())->file == v_->file); });
    typed::TProgram this_ = z;
    this_.defs = run_to_end(each_job(vals, ({
        auto st_1 = st;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<typed::DefNote>(check_env::ValInfo)>>(prism_rtl::rc([=](check_env::ValInfo p0) {
        return ({
            auto st_1_2 = st_1;
            entered(once_job([=]() {
            return ({
                auto v_ = p0;
                call_then(start_zonk_scheme(st_1_2, v_.scheme), [=](check_types::Scheme zonk_scheme_123896) { return prism_rtl::finished(typed::DefNote{.at = typed::At{.file = v_->file, .span = v_.span}, .name = v_.qk, .scheme = zonk_scheme_123896}); });
            });
        }));
        });
    })));
    })));
    return this_;
}


prism_rtl::Turn<typed::TProgram> TypedOf::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    const auto& shown = this->shown;
    auto g_1 = g;
    auto shown_2 = shown;
    auto st_3 = st;
    return call_then(check_types::start_zonk_typed(st_3), [=](typed::TProgram zonk_typed_123642) {
        return ({
            auto z = zonk_typed_123642;
            auto vals = filter(values(g_1.vals), [&](const check_env::ValInfo& v_) { return ((v_->file < shown_2) && (v_.sort != Text("builtin"))) && (or_(prelude::get(g_1.mods, v_.home), check_env::dummy_mod())->file == v_->file); });
            (prism_rtl::finished(({
            typed::TProgram this_ = z;
            this_.defs = run_to_end(each_job(vals, ({
                auto st_3_4 = st_3;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<typed::DefNote>(check_env::ValInfo)>>(prism_rtl::rc([=](check_env::ValInfo p0) {
                return ({
                    auto st_3_4_4 = st_3_4;
                    entered(once_job([=]() {
                    return ({
                        auto v_ = p0;
                        call_then(start_zonk_scheme(st_3_4_4, v_.scheme), [=](check_types::Scheme zonk_scheme_123896) { return prism_rtl::finished(typed::DefNote{.at = typed::At{.file = v_->file, .span = v_.span}, .name = v_.qk, .scheme = zonk_scheme_123896}); });
                    });
                }));
                });
            })));
            })));
            this_;
        })));
        });
    });
}


/// `Start TypedOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<typed::TProgram> start_typed_of(check_env::G g, check_types::St st, Nat shown) {
    return std::make_shared<TypedOf>(g, st, shown);
}


/// ZonkScheme: unbounded fn St, Scheme -> Scheme
check_types::Scheme zonk_scheme(const check_types::St& st, const check_types::Scheme& sc) {
    check_types::Scheme this_ = sc;
    this_.ty = check_types::zonk(st, this_.ty);
    return this_;
}


prism_rtl::Turn<check_types::Scheme> ZonkScheme::cycle() const {
    const auto& st = this->st;
    const auto& sc = this->sc;
    return prism_rtl::finished(({
        check_types::Scheme this_ = sc;
        this_.ty = check_types::zonk(st, this_.ty);
        this_;
    }));
}


/// `Start ZonkScheme, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<check_types::Scheme> start_zonk_scheme(check_types::St st, check_types::Scheme sc) {
    return std::make_shared<ZonkScheme>(st, sc);
}


/// TopLets: unbounded fn G, St -> ((G, St))
std::tuple<check_env::G, check_types::St> top_lets(const check_env::G& g, const check_types::St& st) {
    auto unsigned_ = filter(g.defs, [&](const check_env::Def& d) { return is_let_def(d) && (!check_env::has_key(g.vals, d.qk)); });
    auto [g1, st1] = fold(unsigned_, std::tuple{g, st}, [&](const std::tuple<check_env::G, check_types::St>& _p0, const check_env::Def& d) {
        auto&& gg = std::get<0>(_p0);
        auto&& s = std::get<1>(_p0);
        return ({
            auto [v_, s2] = check_types::fresh_var(s, false, d.name);
            auto gg2 = ({
                check_env::G this_ = gg;
                this_.vals = insert(this_.vals, d.qk, check_env::ValInfo{.qk = d.qk, .scheme = check_types::mono(v_), .sort = Text("let"), .has_sig = false, .home = d.home, .file = d->file, .span = d.span});
                this_;
            });
            std::tuple{gg2, s2};
        });
    });
    return run_to_end(fold_job(unsigned_, std::tuple{g1, st1}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<check_env::G, check_types::St>>(std::tuple<std::tuple<check_env::G, check_types::St>, check_env::Def>)>>(prism_rtl::rc([=](std::tuple<std::tuple<check_env::G, check_types::St>, check_env::Def> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto [gg, s] = p0;
                auto d = p1;
                ({
                auto&& _m = d.body;
                prism_rtl::is<check_env::DefBody::DbLet>(_m) ? ({
                auto&& l = prism_rtl::as<check_env::DefBody::DbLet>(_m).a0;
                ({
                auto env = def_env(gg, d);
                auto s0 = ({
                    check_types::St this_ = s;
                    this_.file = d->file;
                    this_.level = Nat(1u);
                    this_;
                });
                auto pre = or_(prelude::get(gg.vals, d.qk), dummy_val()).scheme.ty;
                auto l_1 = l;
                call_then(check_expr::start_check(env, s0, l_1->value, pre), [=](check_types::St check_124991) {
                return ({
                    auto s1 = check_124991;
                    call_then(check_env::start_solve_wants(gg, s1, Array<std::tuple<Text, Text>>{}, false), [=](check_types::St solve_wants_125040) {
                    return ({
                        auto s2 = solve_wants_125040;
                        auto s3 = ({
                            check_types::St this_ = s2;
                            this_.level = Nat(0u);
                            this_;
                        });
                        call_then(check_types::start_zonk(s3, pre), [=](check_types::Ty zonk_125153) {
                        return ({
                            auto t = zonk_125153;
                            call_then(check_expr::start_wants_above(s3, t, check_expr::is_lambda(l_1->value)), [=](std::tuple<Array<Nat>, Array<std::tuple<Nat, Text>>, check_types::St> wants_above_125205) {
                            return ({
                                auto [keep, bounds, s4] = wants_above_125205;
                                call_then(check_types::start_holds_node(s4, t), [=](bool holds_node_125274) {
                                return ({
                                    auto [sc, s5] = holds_node_125274
                                        ? std::tuple{check_types::mono(t), s4}
                                        : check_types::generalize(s4, t, keep, bounds);
                                    auto gg2 = ({
                                        check_env::G this_ = gg;
                                        this_.vals = insert(this_.vals, d.qk, check_env::ValInfo{.qk = d.qk, .scheme = sc, .sort = Text("let"), .has_sig = false, .home = d.home, .file = d->file, .span = d.span});
                                        this_;
                                    });
                                    call_then(check_types::start_check_colors(s5), [=](check_types::St check_colors_125593) { return call_then(check_env::start_resolve_fields(gg, check_colors_125593, true), [=](check_types::St resolve_fields_125574) { return call_then(check_types::start_layer_questions(resolve_fields_125574), [=](check_types::St layer_questions_125558) { return call_then(start_discharge_incls(gg, layer_questions_125558, Nat(0u)), [=](check_types::St discharge_incls_125538) { return prism_rtl::finished(std::tuple{gg2, discharge_incls_125538}); }); }); }); });
                                });
                            });
                            });
                        });
                        });
                    });
                    });
                });
                });
            });
            });
            })
                : prism_rtl::finished(std::tuple{gg, s});
            });
            });
        }));
    }))));
}


prism_rtl::Turn<std::tuple<check_env::G, check_types::St>> TopLets::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    auto unsigned_ = filter(g.defs, [&](const check_env::Def& d) { return is_let_def(d) && (!check_env::has_key(g.vals, d.qk)); });
    auto [g1, st1] = fold(unsigned_, std::tuple{g, st}, [&](const std::tuple<check_env::G, check_types::St>& _p0, const check_env::Def& d) {
        auto&& gg = std::get<0>(_p0);
        auto&& s = std::get<1>(_p0);
        return ({
            auto [v_, s2] = check_types::fresh_var(s, false, d.name);
            auto gg2 = ({
                check_env::G this_ = gg;
                this_.vals = insert(this_.vals, d.qk, check_env::ValInfo{.qk = d.qk, .scheme = check_types::mono(v_), .sort = Text("let"), .has_sig = false, .home = d.home, .file = d->file, .span = d.span});
                this_;
            });
            std::tuple{gg2, s2};
        });
    });
    return fold_job(unsigned_, std::tuple{g1, st1}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<check_env::G, check_types::St>>(std::tuple<std::tuple<check_env::G, check_types::St>, check_env::Def>)>>(prism_rtl::rc([=](std::tuple<std::tuple<check_env::G, check_types::St>, check_env::Def> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto [gg, s] = p0;
                auto d = p1;
                ({
                auto&& _m = d.body;
                prism_rtl::is<check_env::DefBody::DbLet>(_m) ? ({
                auto&& l = prism_rtl::as<check_env::DefBody::DbLet>(_m).a0;
                ({
                auto env = def_env(gg, d);
                auto s0 = ({
                    check_types::St this_ = s;
                    this_.file = d->file;
                    this_.level = Nat(1u);
                    this_;
                });
                auto pre = or_(prelude::get(gg.vals, d.qk), dummy_val()).scheme.ty;
                auto l_1 = l;
                call_then(check_expr::start_check(env, s0, l_1->value, pre), [=](check_types::St check_124991) {
                return ({
                    auto s1 = check_124991;
                    call_then(check_env::start_solve_wants(gg, s1, Array<std::tuple<Text, Text>>{}, false), [=](check_types::St solve_wants_125040) {
                    return ({
                        auto s2 = solve_wants_125040;
                        auto s3 = ({
                            check_types::St this_ = s2;
                            this_.level = Nat(0u);
                            this_;
                        });
                        call_then(check_types::start_zonk(s3, pre), [=](check_types::Ty zonk_125153) {
                        return ({
                            auto t = zonk_125153;
                            call_then(check_expr::start_wants_above(s3, t, check_expr::is_lambda(l_1->value)), [=](std::tuple<Array<Nat>, Array<std::tuple<Nat, Text>>, check_types::St> wants_above_125205) {
                            return ({
                                auto [keep, bounds, s4] = wants_above_125205;
                                call_then(check_types::start_holds_node(s4, t), [=](bool holds_node_125274) {
                                return ({
                                    auto [sc, s5] = holds_node_125274
                                        ? std::tuple{check_types::mono(t), s4}
                                        : check_types::generalize(s4, t, keep, bounds);
                                    auto gg2 = ({
                                        check_env::G this_ = gg;
                                        this_.vals = insert(this_.vals, d.qk, check_env::ValInfo{.qk = d.qk, .scheme = sc, .sort = Text("let"), .has_sig = false, .home = d.home, .file = d->file, .span = d.span});
                                        this_;
                                    });
                                    call_then(check_types::start_check_colors(s5), [=](check_types::St check_colors_125593) { return call_then(check_env::start_resolve_fields(gg, check_colors_125593, true), [=](check_types::St resolve_fields_125574) { return call_then(check_types::start_layer_questions(resolve_fields_125574), [=](check_types::St layer_questions_125558) { return call_then(start_discharge_incls(gg, layer_questions_125558, Nat(0u)), [=](check_types::St discharge_incls_125538) { return prism_rtl::finished(std::tuple{gg2, discharge_incls_125538}); }); }); }); });
                                });
                            });
                            });
                        });
                        });
                    });
                    });
                });
                });
            });
            });
            })
                : prism_rtl::finished(std::tuple{gg, s});
            });
            });
        }));
    })))->cycle();
}


/// `Start TopLets, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<check_env::G, check_types::St>> start_top_lets(check_env::G g, check_types::St st) {
    return std::make_shared<TopLets>(g, st);
}


/// let dummyVal
check_env::ValInfo dummy_val() {
    return check_env::ValInfo{.qk = Text(""), .scheme = check_types::mono(check_types::Ty(check_types::Ty::TyErr{})), .sort = Text(""), .has_sig = false, .home = Text(""), .file = Nat(0u), .span = ast::Range{.start = Nat(0u), .end = Nat(0u)}};
}


/// IsLetDef: fn Def -> Bool
bool is_let_def(const check_env::Def& d) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = d.body;
        if (prism_rtl::is<check_env::DefBody::DbLet>(_m)) {
            _v.set(true);
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// DefEnv: fn G, Def -> Env
check_expr::Env def_env(const check_env::G& g, const check_env::Def& d) {
    auto info = or_(prelude::get(g.mods, d.home), check_env::dummy_mod());
    auto scope = ({
        __label__ _done;
        prism_rtl::Slot<check_types::Rw> _v;
        auto&& _m = info.emit_rw.tail;
        if (prism_rtl::is<check_types::Tail::TlQ>(_m)) {
            auto&& v_ = prism_rtl::as<check_types::Tail::TlQ>(_m).a0;
            _v.set(check_types::Rw{.fams = info.emit_rw.fams, .minus = Array<Text>{}, .tail = check_types::Tail(check_types::Tail::TlRigid{v_})});
            goto _done;
        }
        {
            _v.set(info.emit_rw);
            goto _done;
        }
    _done:
        _v.take();
    });
    return check_expr::Env{.g = g, .home = d.home, .file = d->file, .src = or_(index(g.srcs, d->file), check_errors::mk_src(Text(""), Text(""))), .locals = Map<Text, check_types::Scheme>{}, .scope = scope, .givens = Array<std::tuple<Text, Text>>{}, .mark = Text(""), .in_update = false, .def_name = d.name, .refine = Map<Text, check_types::Ty>{}, .pending = Array<Text>{}};
}


/// CheckDef: unbounded fn G, St, Def -> St
check_types::St check_def(const check_env::G& g, const check_types::St& st, const check_env::Def& d) {
    auto env = def_env(g, d);
    auto incls_before = len(st.incls);
    auto s0 = ({
        check_types::St this_ = st;
        this_.file = d->file;
        this_.level = Nat(1u);
        this_.color = check_types::Col(check_types::Col::CBound{});
        this_.color_why = Text("");
        this_.color_flex = Array<std::tuple<check_types::Col, Text, ast::Range>>{};
        this_.cleqs = Array<check_types::CLeq>{};
        this_;
    });
    auto s1 = ({
        __label__ _done;
        prism_rtl::Slot<check_types::St> _v;
        auto&& _m = d.body;
        if (prism_rtl::is<check_env::DefBody::DbFn>(_m)) {
            auto&& clauses = prism_rtl::as<check_env::DefBody::DbFn>(_m).a0;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<check_types::St> _v;
                auto&& _m = prelude::get(g.vals, d.qk);
                if (prism_rtl::is_some(_m)) {
                    auto&& v_ = prism_rtl::some_of(_m);
                    _v.set(check_expr::check_clauses(env, s0, d.name, clauses, v_.scheme, d.span));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(s0);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is<check_env::DefBody::DbWidget>(_m)) {
            auto&& w = prism_rtl::as<check_env::DefBody::DbWidget>(_m).a0;
            _v.set(check_widget_def(env, s0, d, w));
            goto _done;
        }
        if (prism_rtl::is<check_env::DefBody::DbLet>(_m)) {
            auto&& l = prism_rtl::as<check_env::DefBody::DbLet>(_m).a0;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<check_types::St> _v;
                auto&& _m = prelude::get(g.vals, d.qk);
                if (prism_rtl::is_some(_m)) {
                    auto&& v_ = prism_rtl::some_of(_m);
                    _v.set(v_.has_sig
                        ? check_expr::check(env, s0, l->value, check_types::skolemize(v_.scheme))
                        : s0);
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(s0);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is<check_env::DefBody::DbMethod>(_m)) {
            auto&& clauses = prism_rtl::as<check_env::DefBody::DbMethod>(_m).a0;
            auto&& cls = prism_rtl::as<check_env::DefBody::DbMethod>(_m).a1;
            auto&& im = prism_rtl::as<check_env::DefBody::DbMethod>(_m).a2;
            _v.set(check_method(env, s0, d, clauses, cls, im));
            goto _done;
        }
        if (prism_rtl::is<check_env::DefBody::DbDefault>(_m)) {
            auto&& clauses = prism_rtl::as<check_env::DefBody::DbDefault>(_m).a0;
            auto&& cls = prism_rtl::as<check_env::DefBody::DbDefault>(_m).a1;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<check_types::St> _v;
                auto&& _m = method_key(g, cls, d.name);
                if (prism_rtl::is_some(_m)) {
                    auto&& mk = prism_rtl::some_of(_m);
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<check_types::St> _v;
                        auto&& _m = prelude::get(g.vals, mk);
                        if (prism_rtl::is_some(_m)) {
                            auto&& v_ = prism_rtl::some_of(_m);
                            _v.set(check_expr::check_clauses(env, s0, d.name, clauses, v_.scheme, d.span));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(s0);
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(s0);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is<check_env::DefBody::DbCheck>(_m)) {
            auto&& c = prism_rtl::as<check_env::DefBody::DbCheck>(_m).a0;
            _v.set(run_to_end(fold_job(c.lines, s0, ({
                auto env_1 = env;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<check_types::St>(std::tuple<check_types::St, ast::CheckLine>)>>(prism_rtl::rc([=](std::tuple<check_types::St, ast::CheckLine> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto env_1_2 = env_1;
                    entered(once_job([=]() {
                    return ({
                        auto s = p0;
                        auto line = p1;
                        call_then(check_expr::start_infer(env_1_2, s, line.expr), [=](std::tuple<check_types::Ty, check_types::St> infer_127607) {
                        return ({
                            auto [t, s2] = infer_127607;
                            ({
                            auto&& _m = line.pattern;
                            prism_rtl::is_some(_m) ? ({
                            auto&& p_ = prism_rtl::some_of(_m);
                            ({
                            auto p__2 = p_;
                            call_then(check_expr::start_bind_pattern(env_1_2, s2, p__2, t, true), [=](std::tuple<check_expr::Env, check_types::St> bind_pattern_127726) {
                            return ({
                                auto&& _s3 = bind_pattern_127726;
                                auto&& s3 = std::get<1>(_s3);
                                (prism_rtl::finished(s3));
                            });
                        });
                        });
                        })
                            : prism_rtl::is_none(_m) ? prism_rtl::finished(s2)
                            : throw prism_rtl::Panic("no arm matched");
                        });
                        });
                    });
                    });
                }));
                });
            })));
            }))));
            goto _done;
        }
        if (prism_rtl::is<check_env::DefBody::DbTest>(_m)) {
            auto&& t = prism_rtl::as<check_env::DefBody::DbTest>(_m).a0;
            _v.set(({
                auto [bt, s2] = check_expr::infer(env, s0, t.blueprint);
                ({
                __label__ _done;
                prism_rtl::Slot<check_types::St> _v;
                auto&& _m = check_types::walk(s2, bt);
                if (prism_rtl::is<check_types::Ty::TyAt>(_m)) {
                    _v.set(s2);
                    goto _done;
                }
                if (prism_rtl::is<check_types::Ty::TyErr>(_m)) {
                    _v.set(s2);
                    goto _done;
                }
                {
                    auto&& other = _m;
                    _v.set(check_types::err(s2, Text("mismatch"), t.blueprint.span, prism_rtl::cat("a test builds a blueprint; this is `", check_types::show_ty(s2, other), "`")));
                    goto _done;
                }
            _done:
                _v.take();
            });
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto solved = check_types::check_colors(check_env::solve_wants(g, s1, env.givens, false));
    auto defaulted = check_types::layer_questions(check_env::resolve_fields(g, default_def(g, solved), true));
    auto discharged = discharge_incls(g, defaulted, incls_before);
    check_types::St this_ = discharged;
    this_.level = Nat(0u);
    return this_;
}


prism_rtl::Turn<check_types::St> CheckDef::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    const auto& d = this->d;
    auto env = def_env(g, d);
    auto incls_before = len(st.incls);
    auto s0 = ({
        check_types::St this_ = st;
        this_.file = d->file;
        this_.level = Nat(1u);
        this_.color = check_types::Col(check_types::Col::CBound{});
        this_.color_why = Text("");
        this_.color_flex = Array<std::tuple<check_types::Col, Text, ast::Range>>{};
        this_.cleqs = Array<check_types::CLeq>{};
        this_;
    });
    auto s1 = ({
        __label__ _done;
        prism_rtl::Slot<check_types::St> _v;
        auto&& _m = d.body;
        if (prism_rtl::is<check_env::DefBody::DbFn>(_m)) {
            auto&& clauses = prism_rtl::as<check_env::DefBody::DbFn>(_m).a0;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<check_types::St> _v;
                auto&& _m = prelude::get(g.vals, d.qk);
                if (prism_rtl::is_some(_m)) {
                    auto&& v_ = prism_rtl::some_of(_m);
                    _v.set(check_expr::check_clauses(env, s0, d.name, clauses, v_.scheme, d.span));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(s0);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is<check_env::DefBody::DbWidget>(_m)) {
            auto&& w = prism_rtl::as<check_env::DefBody::DbWidget>(_m).a0;
            _v.set(check_widget_def(env, s0, d, w));
            goto _done;
        }
        if (prism_rtl::is<check_env::DefBody::DbLet>(_m)) {
            auto&& l = prism_rtl::as<check_env::DefBody::DbLet>(_m).a0;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<check_types::St> _v;
                auto&& _m = prelude::get(g.vals, d.qk);
                if (prism_rtl::is_some(_m)) {
                    auto&& v_ = prism_rtl::some_of(_m);
                    _v.set(v_.has_sig
                        ? check_expr::check(env, s0, l->value, check_types::skolemize(v_.scheme))
                        : s0);
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(s0);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is<check_env::DefBody::DbMethod>(_m)) {
            auto&& clauses = prism_rtl::as<check_env::DefBody::DbMethod>(_m).a0;
            auto&& cls = prism_rtl::as<check_env::DefBody::DbMethod>(_m).a1;
            auto&& im = prism_rtl::as<check_env::DefBody::DbMethod>(_m).a2;
            _v.set(check_method(env, s0, d, clauses, cls, im));
            goto _done;
        }
        if (prism_rtl::is<check_env::DefBody::DbDefault>(_m)) {
            auto&& clauses = prism_rtl::as<check_env::DefBody::DbDefault>(_m).a0;
            auto&& cls = prism_rtl::as<check_env::DefBody::DbDefault>(_m).a1;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<check_types::St> _v;
                auto&& _m = method_key(g, cls, d.name);
                if (prism_rtl::is_some(_m)) {
                    auto&& mk = prism_rtl::some_of(_m);
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<check_types::St> _v;
                        auto&& _m = prelude::get(g.vals, mk);
                        if (prism_rtl::is_some(_m)) {
                            auto&& v_ = prism_rtl::some_of(_m);
                            _v.set(check_expr::check_clauses(env, s0, d.name, clauses, v_.scheme, d.span));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(s0);
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(s0);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is<check_env::DefBody::DbCheck>(_m)) {
            auto&& c = prism_rtl::as<check_env::DefBody::DbCheck>(_m).a0;
            _v.set(run_to_end(fold_job(c.lines, s0, ({
                auto env_1 = env;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<check_types::St>(std::tuple<check_types::St, ast::CheckLine>)>>(prism_rtl::rc([=](std::tuple<check_types::St, ast::CheckLine> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto env_1_2 = env_1;
                    entered(once_job([=]() {
                    return ({
                        auto s = p0;
                        auto line = p1;
                        call_then(check_expr::start_infer(env_1_2, s, line.expr), [=](std::tuple<check_types::Ty, check_types::St> infer_127607) {
                        return ({
                            auto [t, s2] = infer_127607;
                            ({
                            auto&& _m = line.pattern;
                            prism_rtl::is_some(_m) ? ({
                            auto&& p_ = prism_rtl::some_of(_m);
                            ({
                            auto p__2 = p_;
                            call_then(check_expr::start_bind_pattern(env_1_2, s2, p__2, t, true), [=](std::tuple<check_expr::Env, check_types::St> bind_pattern_127726) {
                            return ({
                                auto&& _s3 = bind_pattern_127726;
                                auto&& s3 = std::get<1>(_s3);
                                (prism_rtl::finished(s3));
                            });
                        });
                        });
                        })
                            : prism_rtl::is_none(_m) ? prism_rtl::finished(s2)
                            : throw prism_rtl::Panic("no arm matched");
                        });
                        });
                    });
                    });
                }));
                });
            })));
            }))));
            goto _done;
        }
        if (prism_rtl::is<check_env::DefBody::DbTest>(_m)) {
            auto&& t = prism_rtl::as<check_env::DefBody::DbTest>(_m).a0;
            _v.set(({
                auto [bt, s2] = check_expr::infer(env, s0, t.blueprint);
                ({
                __label__ _done;
                prism_rtl::Slot<check_types::St> _v;
                auto&& _m = check_types::walk(s2, bt);
                if (prism_rtl::is<check_types::Ty::TyAt>(_m)) {
                    _v.set(s2);
                    goto _done;
                }
                if (prism_rtl::is<check_types::Ty::TyErr>(_m)) {
                    _v.set(s2);
                    goto _done;
                }
                {
                    auto&& other = _m;
                    _v.set(check_types::err(s2, Text("mismatch"), t.blueprint.span, prism_rtl::cat("a test builds a blueprint; this is `", check_types::show_ty(s2, other), "`")));
                    goto _done;
                }
            _done:
                _v.take();
            });
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto g_1 = g;
    return call_then(check_env::start_solve_wants(g_1, s1, env.givens, false), [=](check_types::St solve_wants_128125) {
        return call_then(check_types::start_check_colors(solve_wants_128125), [=](check_types::St check_colors_128112) {
            return ({
                auto solved = check_colors_128112;
                call_then(start_default_def(g_1, solved), [=](check_types::St default_def_128216) {
                return call_then(check_env::start_resolve_fields(g_1, default_def_128216, true), [=](check_types::St resolve_fields_128198) {
                    return call_then(check_types::start_layer_questions(resolve_fields_128198), [=](check_types::St layer_questions_128182) {
                        return ({
                            auto defaulted = layer_questions_128182;
                            call_then(start_discharge_incls(g_1, defaulted, incls_before), [=](check_types::St discharge_incls_128266) {
                            return ({
                                auto discharged = discharge_incls_128266;
                                (prism_rtl::finished(({
                                check_types::St this_ = discharged;
                                this_.level = Nat(0u);
                                this_;
                            })));
                            });
                        });
                        });
                    });
                });
            });
            });
        });
    });
}


/// `Start CheckDef, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<check_types::St> start_check_def(check_env::G g, check_types::St st, check_env::Def d) {
    return std::make_shared<CheckDef>(g, st, d);
}

}  // namespace crate::check_passes
