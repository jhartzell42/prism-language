// The prelude (Semantics Appendix B), emitted by prismc beside every program compiled to
// C++: the builtins and the prelude's own functions over `prism_rtl`.
#pragma once

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <fstream>
#include <iostream>
#include <pthread.h>
#include <set>
#include <sstream>

#include "prism_rtl/lang.hpp"
#include "prism_world_cli/cli.hpp"

namespace crate {

using namespace prism_rtl;
using namespace std::literals;

namespace prelude {

// ---- Types ------------------------------------------------------------------------------

/// `type Ordering = choice: Less | Equal | Greater; derive ^Eq, ^Ord, ^Show`.
class Ordering {
public:
    using prism_value = void;
    struct Less {
        auto operator<=>(const Less&) const = default;
    };
    struct Equal {
        auto operator<=>(const Equal&) const = default;
    };
    struct Greater {
        auto operator<=>(const Greater&) const = default;
    };
    using Cases = std::variant<Less, Equal, Greater>;
    template <class C>
        requires prism_rtl::one_of<C, Less, Equal, Greater>
    Ordering(C c) : cases_(std::move(c)) {}
    const Cases& cases() const { return cases_; }
    const char* name() const {
        return std::holds_alternative<Less>(cases()) ? "Less" : std::holds_alternative<Equal>(cases()) ? "Equal" : "Greater";
    }
    void show(Printer& p) const { p.choice(name(), {}); }
    Pod to_pod() const { return Pod::name(name()); }
    friend bool operator==(const Ordering& a, const Ordering& b) { return a.cases() == b.cases(); }
    friend std::strong_ordering operator<=>(const Ordering& a, const Ordering& b) { return prism_rtl::as_strong(a.cases() <=> b.cases()); }

private:
    Cases cases_;
};

/// A derived `FromPod`'s field.
inline Result<Pod> field(const Pod& p, const char* name) {
    if (auto f = p.field(name)) return *f;
    return unexpected(Fault::answer(str("no field ", name, " in ", p)));
}

/// `type Span = record: file, line, column, binding`.
struct Span {
    using prism_value = void;
    Text file;
    Nat line;
    Nat column;
    Text binding;
    const Span* operator->() const { return this; }
    auto operator<=>(const Span&) const = default;
    Pod to_pod() const {
        return Pod::record("Span", { {"file", prism_rtl::to_pod(file)}, {"line", prism_rtl::to_pod(line)}, {"column", prism_rtl::to_pod(column)}, {"binding", prism_rtl::to_pod(binding)} });
    }
    static Result<Span> from_pod(const Pod& p) {
        return Span{.file = TRY(prism_rtl::from_pod<Text>(TRY(field(p, "file")))), .line = TRY(prism_rtl::from_pod<Nat>(TRY(field(p, "line")))), .column = TRY(prism_rtl::from_pod<Nat>(TRY(field(p, "column")))), .binding = TRY(prism_rtl::from_pod<Text>(TRY(field(p, "binding"))))};
    }
};

/// `type Exception = record: kind, message, spans, path`.
struct Exception {
    using prism_value = void;
    Text kind;
    Text message;
    Array<Span> spans;
    std::optional<Path> path_;
    const Exception* operator->() const { return this; }
    bool operator==(const Exception&) const = default;
    Pod to_pod() const {
        return Pod::record("Exception", { {"kind", prism_rtl::to_pod(kind)}, {"message", prism_rtl::to_pod(message)}, {"spans", prism_rtl::to_pod(spans)}, {"path", prism_rtl::to_pod(path_)} });
    }
    static Result<Exception> from_pod(const Pod& p) {
        return Exception{.kind = TRY(prism_rtl::from_pod<Text>(TRY(field(p, "kind")))), .message = TRY(prism_rtl::from_pod<Text>(TRY(field(p, "message")))), .spans = TRY(prism_rtl::from_pod<Array<Span>>(TRY(field(p, "spans")))), .path_ = TRY(prism_rtl::from_pod<std::optional<Path>>(TRY(field(p, "path"))))};
    }
};

/// `tag Prelude.Unwrap of Element !a: value: !~a`.
struct PreludeUnwrap {
    using prism_value = void;
    static constexpr const char* TAG = "Prelude.Unwrap";
    bool operator==(const PreludeUnwrap&) const = default;
    Pod to_pod() const { return Pod::element(TAG, {}); }
    void show(Printer& p) const { Show<Pod>::show(to_pod(), p); }
    static Result<PreludeUnwrap> from_pod(const Pod& p) {
        if (auto t = p.tag(); t && *t == TAG) return PreludeUnwrap{};
        return mismatch<PreludeUnwrap>("a Prelude.Unwrap", p);
    }
};

/// `tag Prelude.Exceptions of Element !Exception`.
struct PreludeExceptions {
    using prism_value = void;
    static constexpr const char* TAG = "Prelude.Exceptions";
    bool operator==(const PreludeExceptions&) const = default;
    Pod to_pod() const { return Pod::element(TAG, {}); }
    void show(Printer& p) const { Show<Pod>::show(to_pod(), p); }
    static Result<PreludeExceptions> from_pod(const Pod& p) {
        if (auto t = p.tag(); t && *t == TAG) return PreludeExceptions{};
        return mismatch<PreludeExceptions>("a Prelude.Exceptions", p);
    }
};

/// `Duration`: nanoseconds (D14 keeps its arithmetic out).
struct Duration {
    using prism_value = void;
    Nanos a0;
    auto operator<=>(const Duration&) const = default;
    void show(Printer& p) const { p.duration(a0); }
    Pod to_pod() const { return Pod::duration(a0); }
    static Result<Duration> from_pod(const Pod& whole) {
        if (auto ns = whole.structure().if_duration()) return Duration{*ns};
        return mismatch<Duration>("a Duration", whole.structure());
    }
};

// ---- Numbers ----------------------------------------------------------------------------

/// `^Num` (Type System ch. 3) over a type variable: the operators by name.
namespace Num {
inline Nat add(const Nat& a, const Nat& b) { return a + b; }
inline Nat sub(const Nat& a, const Nat& b) { return a.checked_sub(b).value_or(Nat(0u)); }
inline Nat mul(const Nat& a, const Nat& b) { return a * b; }
inline std::optional<Nat> div_opt(const Nat& a, const Nat& b) { return a.div(b); }
inline std::optional<Nat> sub_opt(const Nat& a, const Nat& b) { return a.checked_sub(b); }
inline Int add(const Int& a, const Int& b) { return a + b; }
inline Int sub(const Int& a, const Int& b) { return a - b; }
inline Int mul(const Int& a, const Int& b) { return a * b; }
inline std::optional<Int> div_opt(const Int& a, const Int& b) { return a.div(b); }
inline double add(double a, double b) { return a + b; }
inline double sub(double a, double b) { return a - b; }
inline double mul(double a, double b) { return a * b; }
inline std::optional<double> div_opt(double a, double b) { return a / b; }
inline std::uint8_t add(std::uint8_t a, std::uint8_t b) { return std::uint8_t(a + b); }
inline std::uint8_t sub(std::uint8_t a, std::uint8_t b) { return std::uint8_t(a - b); }
inline std::uint8_t mul(std::uint8_t a, std::uint8_t b) { return std::uint8_t(a * b); }
inline std::optional<std::uint8_t> div_opt(std::uint8_t a, std::uint8_t b) {
    if (b == 0) return std::nullopt;
    return std::uint8_t(a / b);
}
inline std::optional<std::uint8_t> add_opt(std::uint8_t a, std::uint8_t b) {
    if (a + b > 255) return std::nullopt;
    return std::uint8_t(a + b);
}
inline std::optional<std::uint8_t> sub_opt(std::uint8_t a, std::uint8_t b) {
    if (b > a) return std::nullopt;
    return std::uint8_t(a - b);
}
inline std::optional<std::uint8_t> mul_opt(std::uint8_t a, std::uint8_t b) {
    if (a * b > 255) return std::nullopt;
    return std::uint8_t(a * b);
}
template <class A>
std::optional<A> add_opt(const A& a, const A& b) { return add(a, b); }
template <class A>
std::optional<A> sub_opt(const A& a, const A& b) { return sub(a, b); }
template <class A>
std::optional<A> mul_opt(const A& a, const A& b) { return mul(a, b); }
template <class A>
A zero();
template <> inline Nat zero<Nat>() { return Nat(0u); }
template <> inline Int zero<Int>() { return Int(0); }
template <> inline double zero<double>() { return 0.0; }
template <> inline std::uint8_t zero<std::uint8_t>() { return 0; }
}  // namespace Num

/// A `Nat` as an index; one too large for memory indexes nothing.
inline std::size_t ix(const Nat& n) {
    auto i = n.as_int().to_i64();
    return i ? std::size_t(*i) : std::size_t(-1);
}

inline Nat nat_of(std::size_t n) { return Nat::from_int(Int(std::int64_t(n))).value_or(Nat(0u)); }

/// `Int: fn Nat -> Int`.
inline Int int_(const Nat& n) { return n.as_int(); }

/// `?Nat: fn Int -> ?Nat`.
inline std::optional<Nat> nat(const Int& i) { return Nat::from_int(i); }

/// `?U8: fn Int -> ?U8`.
inline std::optional<std::uint8_t> u8_(const Int& i) {
    auto n = i.to_i64();
    if (!n || *n < 0 || *n > 255) return std::nullopt;
    return std::uint8_t(*n);
}

template <class A>
std::optional<A> div(const A& a, const A& b) { return Num::div_opt(a, b); }

inline std::optional<Int> mod_(const Int& a, const Int& b) {
    if (b == Int(0)) return std::nullopt;
    return a.modulo(b);
}
inline std::optional<Nat> mod_(const Nat& a, const Nat& b) {
    if (b == Nat(0u)) return std::nullopt;
    return a.modulo(b);
}
inline std::optional<std::uint8_t> mod_(std::uint8_t a, std::uint8_t b) {
    if (b == 0) return std::nullopt;
    return std::uint8_t(a % b);
}

inline double float_(const Int& i) {
    auto n = i.to_i64();
    return n ? double(*n) : std::stod(i.to_string());
}
inline double to_float(const Int& i) { return float_(i); }
inline double cos(double x) { return std::cos(x); }
inline double sin(double x) { return std::sin(x); }

template <class A>
A abs(const A& a) { return a < Num::zero<A>() ? Num::sub(Num::zero<A>(), a) : a; }

template <class A>
A sum(const Array<A>& xs) {
    A acc = Num::zero<A>();
    for (const A& x : xs) acc = Num::add(acc, x);
    return acc;
}

template <class A>
A max(const A& a, const A& b) { return a < b ? b : a; }
template <class A>
A min(const A& a, const A& b) { return b < a ? b : a; }

/// `Compare` of `^Ord`.
template <class A>
Ordering compare(const A& a, const A& b) {
    if (a < b) return Ordering::Less{};
    if (b < a) return Ordering::Greater{};
    return Ordering::Equal{};
}

// ---- Optionals --------------------------------------------------------------------------

/// `Or: fn ?a, a -> a`.
template <class A, class D>
A or_(const std::optional<A>& o, const D& d) { return o ? *o : A(d); }

// ---- Arrays -----------------------------------------------------------------------------

template <class A>
Nat len(const Array<A>& xs) { return nat_of(xs.size()); }
inline Nat len_text(const Text& t) { return nat_of(t.len()); }
template <class K, class V>
Nat len_map(const Map<K, V>& m) { return nat_of(m.size()); }

template <class A>
Array<A> append(const Array<A>& a, const Array<A>& b) { return a.concat(b); }
template <class A>
Array<A> push(const Array<A>& xs, const A& x) { return xs.pushed(x); }

template <class A, class B, class F>
B fold(const Array<A>& xs, const B& init, const F& f) {
    B acc = init;
    for (const A& x : xs) acc = f(acc, x);
    return acc;
}
template <class K, class V, class B, class F>
B fold_map(const Map<K, V>& m, const B& init, const F& f) {
    B acc = init;
    for (const auto& [k, v] : m) acc = f(acc, k, v);
    return acc;
}
template <class A, class F>
auto each(const Array<A>& xs, const F& f) {
    using B = std::decay_t<std::invoke_result_t<const F&, const A&>>;
    std::vector<B> out;
    out.reserve(xs.size());
    for (const A& x : xs) out.push_back(f(x));
    return Array<B>(std::move(out));
}
template <class A, class F>
Array<A> filter(const Array<A>& xs, const F& keep) {
    std::vector<A> out;
    for (const A& x : xs)
        if (keep(x)) out.push_back(x);
    return Array<A>(std::move(out));
}
inline Text concat(const Array<Text>& xs) {
    std::size_t n = 0;
    for (const Text& t : xs) n += t.len();
    std::string s;
    s.reserve(n);
    for (const Text& t : xs) s += t.view();
    return Text::of_utf8(std::move(s));
}

/// `xs[i]`.
template <class A>
std::optional<A> index(const Array<A>& xs, const Nat& i) {
    if (auto x = xs.get(ix(i))) return *x;
    return std::nullopt;
}

/// `&xs[i]` in an `&` block.
template <class A>
A& at_mut(Array<A>& xs, const Nat& i) { return xs.mut_at(ix(i)); }
template <class K, class V>
V& at_mut_map(Map<K, V>& m, const K& k) {
    V* v = m.mut_get(k);
    if (!v) panic("an `&` path to a key the map does not hold");
    return *v;
}

/// `&xs[i] <= v` in an `&` block: an array has no entry to remove.
template <class A>
void set_index(Array<A>& xs, const Nat& i, std::optional<A> v) {
    if (!v) panic(str("`&xs[", i, "] <= nil`: an array's entry cannot be removed"));
    xs.set(ix(i), std::move(*v));
}
/// `&m[k] <= v` in an `&` block: `? x` writes the key, `nil` removes it.
template <class K, class V>
void set_key(Map<K, V>& m, const K& k, std::optional<V> v) {
    if (v) m.insert(k, std::move(*v));
    else m.remove(k);
}

template <class A>
Array<A> take(const Array<A>& xs, const Nat& n) { return xs.take(std::min(ix(n), xs.size())); }
template <class A>
Array<A> drop(const Array<A>& xs, const Nat& n) { return xs.drop_front(std::min(ix(n), xs.size())); }

// ---- Maps -------------------------------------------------------------------------------

template <class K, class V>
Map<K, V> map_of(std::vector<std::tuple<K, V>> entries) {
    Map<K, V> m;
    for (auto& [k, v] : entries) m.insert(std::move(k), std::move(v));
    return m;
}
template <class K, class V>
Map<K, V> insert(const Map<K, V>& m, const K& k, const V& v) { return m.inserted(k, v); }
template <class K, class V>
Map<K, V> remove(const Map<K, V>& m, const K& k) { return m.removed(k); }
/// `?Get`, and `m[k]`.
template <class K, class V>
std::optional<V> get(const Map<K, V>& m, const K& k) {
    if (auto v = m.get(k)) return *v;
    return std::nullopt;
}
/// `?First`.
template <class K, class V>
std::optional<std::tuple<K, V>> first(const Map<K, V>& m) {
    if (m.empty()) return std::nullopt;
    auto it = m.begin();
    return std::tuple<K, V>(it->first, it->second);
}
template <class K, class V>
Array<K> keys(const Map<K, V>& m) {
    std::vector<K> out;
    for (const auto& [k, v] : m) out.push_back(k);
    return Array<K>(std::move(out));
}
template <class K, class V>
Array<V> values(const Map<K, V>& m) {
    std::vector<V> out;
    for (const auto& [k, v] : m) out.push_back(v);
    return Array<V>(std::move(out));
}
template <class K, class V>
Nat size(const Map<K, V>& m) { return nat_of(m.size()); }
/// A host's rows (`prism_rtl::Rows`, shared), as `Map::values` reads them.
template <class K, class V>
Array<V> values(const prism_rtl::Rc<Map<K, V>>& m) { return values(*m); }
template <class K, class V>
Map<K, V> map(const Array<std::tuple<K, V>>& entries) {
    Map<K, V> m;
    for (const auto& [k, v] : entries) m.insert(k, v);
    return m;
}
/// `Union a, b`: `a`'s entries over `b`'s.
template <class K, class V>
Map<K, V> union_(const Map<K, V>& a, const Map<K, V>& b) {
    return a.united(b);
}
template <class K, class V, class F>
auto each_map(const Map<K, V>& m, const F& f) {
    using B = std::decay_t<std::invoke_result_t<const F&, const K&, const V&>>;
    std::vector<B> out;
    for (const auto& [k, v] : m) out.push_back(f(k, v));
    return Array<B>(std::move(out));
}
template <class K, class V, class F>
Map<K, V> filter_map(const Map<K, V>& m, const F& keep) {
    Map<K, V> out;
    for (const auto& [k, v] : m)
        if (keep(k, v)) out.insert(k, v);
    return out;
}

// ---- Text -------------------------------------------------------------------------------

/// `Text: fn Char -> Text`: the character as a one-character text, its UTF-8.
inline Text text(char32_t c) {
    std::string s;
    prism_rtl::utf8_push(s, c);
    return Text::of_utf8(std::move(s));
}
/// `Upper`, `Lower`: Unicode's default full case mapping, as Rust's `str::to_uppercase`
/// and `to_lowercase` (runtime/cpp/README.md, "Upper and Lower").
inline Text upper(const Text& t) { return text_upper(t); }
inline Text lower(const Text& t) { return text_lower(t); }

/// `SplitOn t, sep`: the pieces between the separators (not in Appendix B, whose `Split`
/// is a regular expression's). An empty separator is refused.
inline Array<Text> split_on(const Text& t, const Text& sep) {
    if (sep.is_empty()) panic("`SplitOn` with an empty separator: walk the text's characters with a cursor (`Front`, `?Step`)");
    return Array<Text>(t.split(sep.view()));
}

/// `Front: fn Text -> Cursor`.
inline Cursor front(const Text& t) { return Cursor::front(t); }
/// `Back: fn Text -> Cursor`.
inline Cursor back(const Text& t) { return Cursor::back(t); }
/// `?Step: fn Cursor -> ?((Char, Cursor))`.
inline std::optional<std::tuple<char32_t, Cursor>> step(const Cursor& c) {
    auto s = c.step();
    if (!s) return std::nullopt;
    return std::tuple<char32_t, Cursor>(s->first, std::move(s->second));
}
/// `?StepBack: fn Cursor -> ?((Char, Cursor))`.
inline std::optional<std::tuple<char32_t, Cursor>> step_back(const Cursor& c) {
    auto s = c.step_back();
    if (!s) return std::nullopt;
    return std::tuple<char32_t, Cursor>(s->first, std::move(s->second));
}
/// `Before: fn Cursor -> Text`.
inline Text before(const Cursor& c) { return c.before(); }
/// `After: fn Cursor -> Text`.
inline Text after(const Cursor& c) { return c.after(); }
/// `At: fn Cursor -> Nat`.
inline Nat at(const Cursor& c) { return nat_of(c.at()); }
/// `?CursorAt: fn Text, Nat -> ?Cursor`.
inline std::optional<Cursor> cursor_at(const Text& t, const Nat& n) { return Cursor::at_byte(t, ix(n)); }

// ---- Regular expressions (Appendix B; claude/regex-dialect.md) --------------------------
// A literal is built where it stands (`Regex::lit`, a function-local static per literal);
// these are the prelude's functions over prism_rtl's regex.hpp, each the runtime's search.
// `Group` and `Match` are the runtime's records, seen through `using namespace prism_rtl`.

/// `?Regex: fn Text -> ?Regex`: the text as a pattern with no flags, none outside the
/// dialect; linear in the text.
inline std::optional<Regex> regex(const Text& t) { return Regex::parse(t); }
/// `?Match: fn Regex, Cursor -> ?Match`: the match that starts at the cursor, seeing the
/// whole text before it.
inline std::optional<Match> match_(const Regex& r, const Cursor& c) { return r.match_at(c); }
/// `?Find: fn Regex, Text -> ?Match`: the leftmost-first match.
inline std::optional<Match> find(const Regex& r, const Text& t) { return r.find(t); }
/// `Matches: fn Regex, Text -> [Match]`: every match, by the iteration rule.
inline Array<Match> matches(const Regex& r, const Text& t) { return r.matches(t); }
/// `Replace: fn RegexReplacement, Text -> Text`: every match replaced.
inline Text replace(const RegexReplacement& r, const Text& t) { return r.replace(t); }
/// `Split: fn Regex, Text -> [Text]`: the `k + 1` views between the `k` matches.
inline Array<Text> split(const Regex& r, const Text& t) { return r.split(t); }

/// `?ParseNat`.
inline std::optional<Nat> parse_nat_opt(const Text& t) {
    std::string_view s = t.view();
    if (s.empty() || !std::all_of(s.begin(), s.end(), [](char c) { return c >= '0' && c <= '9'; })) return std::nullopt;
    return Nat::from_int(*Int::parse(s));
}

/// `~ParseNat`.
inline Fallible<Nat> parse_nat_try(const Text& t) {
    if (auto n = parse_nat_opt(t)) return *n;
    return unexpected(Error("Prelude.NotANumber", Text(str("not a number: ", t))));
}

/// `Buffer.Numbered n`: `0` to `n - 1`, linear.
inline Array<Nat> numbered(const Nat& n) {
    std::vector<Nat> out;
    for (std::size_t i = 0; i < ix(n); ++i) out.push_back(nat_of(i));
    return Array<Nat>(std::move(out));
}

/// `Freeze`: a `Buffer` is an array already.
template <class A>
A freeze(const A& a) { return a; }

/// A code template's placeholder (Templates ch. 2): alone on its line, its text's lines
/// indented to its column, a final newline dropped, an empty text no line; sharing a line,
/// the text as it is.
inline void place(std::string& out, const Text& text, std::optional<std::size_t> column) {
    std::string_view t = text.view();
    if (!column) {
        out += t;
        return;
    }
    if (!t.empty() && t.back() == '\n') t.remove_suffix(1);
    if (t.empty()) return;
    std::size_t from = 0;
    while (true) {
        std::size_t at = t.find('\n', from);
        std::string_view l = t.substr(from, at == std::string_view::npos ? std::string_view::npos : at - from);
        if (!l.empty()) out.append(*column, ' ');
        out += l;
        out += '\n';
        if (at == std::string_view::npos) break;
        from = at + 1;
    }
}

/// An array as the map from each index to its entry, for a `for` over an array.
template <class A>
Map<Nat, A> indexed(const Array<A>& xs) {
    Map<Nat, A> m;
    std::size_t i = 0;
    for (const A& x : xs) m.insert(nat_of(i++), x);
    return m;
}

/// The heights a node with combinators at several heights asked for this tick: its wake
/// runs the lowest one asked (`Node::wake` is not told its height, prismc/README.md WH).
class Wakes {
public:
    void ask(std::uint32_t h) { asked_.insert(h); }
    std::uint32_t next() {
        if (asked_.empty()) return std::uint32_t(-1);
        std::uint32_t h = *asked_.begin();
        asked_.erase(asked_.begin());
        return h;
    }

private:
    std::set<std::uint32_t> asked_;
};

// ---- Jobs -------------------------------------------------------------------------------

/// A frame of a job's stack (D6; claude/backend.md, "Unbounded functions and `@Run`"): the
/// caller of `callee`, a call of an unbounded function that was not in tail position,
/// waiting for its result. A continuation runs once.
template <class A, class B>
struct Frame : Job<B> {
    JobRef<A> callee;
    std::function<Turn<B>(A)> then;
    Frame(JobRef<A> callee, std::function<Turn<B>(A)> then) : callee(std::move(callee)), then(std::move(then)) {}
    Turn<B> cycle() const override {
        Turn<A> t = callee->cycle();
        if (auto m = t.if_more()) return Turn<B>::more(prism_rtl::make_rc<Frame<A, B>>(m->next, then));
        return then(std::move(std::get<typename Turn<A>::Finished>(t.v).value));
    }
};

/// A call that is not in tail position: a cycle point, with `then` the continuation.
template <class A, class F>
auto call_then(JobRef<A> callee, F then) {
    using T = std::invoke_result_t<F, A>;
    using B = typename T::Value;
    return Turn<B>::more(prism_rtl::make_rc<Frame<A, B>>(std::move(callee), std::move(then)));
}

/// A call through an unbounded function value that is not in tail position: the value's
/// job runs its first cycle now.
template <class A, class F>
auto call_value(JobRef<A> callee, F then) {
    using T = std::invoke_result_t<F, A>;
    using B = typename T::Value;
    return Frame<A, B>(std::move(callee), std::move(then)).cycle();
}

/// A named unbounded function's job as its value gives it: entering it is a cycle point.
template <class B>
struct Entered : Job<B> {
    JobRef<B> job;
    explicit Entered(JobRef<B> job) : job(std::move(job)) {}
    Turn<B> cycle() const override { return Turn<B>::more(job); }
};
template <class B>
JobRef<B> entered(JobRef<B> job) { return prism_rtl::make_rc<Entered<B>>(std::move(job)); }

/// A `while` in an `update` block of an unbounded function as a job (D6): each turn is a
/// cycle; `step` answers the next state, or a failure when the condition fails.
template <class S>
struct Looping : Job<S> {
    S state;
    prism_rtl::Rc<const std::function<Expected<S, S>(S)>> step;
    Looping(S state, prism_rtl::Rc<const std::function<Expected<S, S>(S)>> step) : state(std::move(state)), step(std::move(step)) {}
    Turn<S> cycle() const override {
        Expected<S, S> r = (*step)(state);
        if (r) return Turn<S>::more(prism_rtl::make_rc<Looping<S>>(std::move(r).value(), step));
        return Turn<S>::finished(r.error());
    }
};
template <class S, class F>
JobRef<S> loop_job(S state, F step) {
    return prism_rtl::make_rc<Looping<S>>(std::move(state), prism_rtl::make_rc<const std::function<Expected<S, S>(S)>>(std::move(step)));
}

/// A `while` whose body holds a cycle-point loop of its own (D6): a turn is a job.
template <class S>
struct LoopingTurns : Job<S> {
    S state;
    prism_rtl::Rc<const std::function<Turn<Expected<S, S>>(S)>> step;
    LoopingTurns(S state, prism_rtl::Rc<const std::function<Turn<Expected<S, S>>(S)>> step) : state(std::move(state)), step(std::move(step)) {}
    Turn<S> cycle() const override {
        auto st = step;
        std::function<Turn<S>(Expected<S, S>)> again = [st](Expected<S, S> r) -> Turn<S> {
            if (r) return Turn<S>::more(prism_rtl::make_rc<LoopingTurns<S>>(std::move(r).value(), st));
            return Turn<S>::finished(r.error());
        };
        Turn<Expected<S, S>> t = (*step)(state);
        if (auto m = t.if_more()) return Turn<S>::more(prism_rtl::make_rc<Frame<Expected<S, S>, S>>(m->next, again));
        return again(t.if_finished()->value);
    }
};
template <class S, class F>
JobRef<S> loop_turns(S state, F step) {
    return prism_rtl::make_rc<LoopingTurns<S>>(std::move(state), prism_rtl::make_rc<const std::function<Turn<Expected<S, S>>(S)>>(std::move(step)));
}


/// The job of a lambda of unbounded type: its body, run as a job body from its first
/// cycle (prismc/README.md, pick JB).
template <class B>
struct Once : Job<B> {
    std::function<Turn<B>()> body;
    explicit Once(std::function<Turn<B>()> body) : body(std::move(body)) {}
    Turn<B> cycle() const override { return body(); }
};
template <class F>
auto once_job(F body) {
    using B = typename std::invoke_result_t<F>::Value;
    return JobRef<B>(prism_rtl::make_rc<Once<B>>(std::move(body)));
}

/// A job's result, mapped: `g` runs in the cycle the job finishes.
template <class B, class G>
auto map_job(JobRef<B> job, G g) {
    using C = std::decay_t<std::invoke_result_t<G, B>>;
    return JobRef<C>(prism_rtl::make_rc<Frame<B, C>>(std::move(job), [g](B b) { return Turn<C>::finished(g(std::move(b))); }));
}

/// A `for` of an `update` block whose body holds a cycle-point loop (D6, gap LP): a loop
/// over its entries as `loop_turns` is over its condition, taking the next entry its
/// test; `step` takes the block's state and an entry's parts, a turn a job.
template <class S, class E, class F>
JobRef<S> for_turns(std::vector<E> entries, S state, F step) {
    using P = std::pair<S, std::size_t>;
    auto all = prism_rtl::make_rc<const std::vector<E>>(std::move(entries));
    auto st = prism_rtl::make_rc<const F>(std::move(step));
    JobRef<P> job = loop_turns(P(std::move(state), 0), [all, st](P p) -> Turn<Expected<P, P>> {
        std::size_t i = p.second;
        if (i >= all->size()) return Turn<Expected<P, P>>::finished(Expected<P, P>(unexpected(std::move(p))));
        Turn<S> t = std::apply([&](const auto&... parts) { return (*st)(std::move(p.first), parts...); }, (*all)[i]);
        if (auto m = t.if_more()) return call_then(m->next, [i](S s2) { return Turn<Expected<P, P>>::finished(Expected<P, P>(P(std::move(s2), i + 1))); });
        return Turn<Expected<P, P>>::finished(Expected<P, P>(P(std::move(t.if_finished()->value), i + 1)));
    });
    return map_job(job, [](P p) { return std::move(p.first); });
}

/// `for` over a map in a job (`for_turns`): the key and the entry, in key order.
template <class K, class V, class S, class F>
JobRef<S> for_turns_keyed(Map<K, V> m, S state, F step) {
    std::vector<std::pair<K, V>> entries;
    for (auto&& [k, v] : m) entries.emplace_back(k, v);
    return for_turns(std::move(entries), std::move(state), std::move(step));
}

/// `for` over an array in a job (`for_turns`): the index and the entry.
template <class V, class S, class F>
JobRef<S> for_turns_indexed(Array<V> xs, S state, F step) {
    std::vector<std::pair<Nat, V>> entries;
    for (auto&& [i, v] : prism_rtl::enumerate(xs)) entries.emplace_back(nat_of(i), v);
    return for_turns(std::move(entries), std::move(state), std::move(step));
}

// ---- The higher-order functions as jobs (D8) ---------------------------------------------

template <class A, class B, class F>
Turn<B> fold_from(Array<A> xs, std::size_t i, B acc, F f) {
    auto x = xs.get(i);
    if (!x) return Turn<B>::finished(std::move(acc));
    A item = *x;
    return call_value(f(std::tuple<B, A>(std::move(acc), std::move(item))), [xs, i, f](B b) { return fold_from(xs, i + 1, std::move(b), f); });
}
template <class A, class B, class F>
JobRef<B> fold_job(Array<A> xs, B init, F f) {
    return once_job([xs, init, f]() { return fold_from(xs, 0, init, f); });
}
template <class K, class V>
Array<std::tuple<K, V>> pairs_of(const Map<K, V>& m) {
    std::vector<std::tuple<K, V>> out;
    for (const auto& [k, v] : m) out.emplace_back(k, v);
    return Array<std::tuple<K, V>>(std::move(out));
}
template <class K, class V, class B, class F>
JobRef<B> fold_map_job(Map<K, V> m, B init, F f) {
    return fold_job(pairs_of(m), std::move(init), [f](std::tuple<B, std::tuple<K, V>> p) {
        auto& [acc, kv] = p;
        return f(std::tuple<B, K, V>(acc, std::get<0>(kv), std::get<1>(kv)));
    });
}
template <class A, class F>
auto each_job(Array<A> xs, F f) {
    using B = typename std::invoke_result_t<F, A>::element_type::Value;
    return fold_job(std::move(xs), Array<B>(), [f](std::tuple<Array<B>, A> p) {
        auto acc = std::get<0>(p);
        return map_job(f(std::get<1>(p)), [acc](B b) { return acc.pushed(std::move(b)); });
    });
}
template <class K, class V, class F>
auto each_map_job(Map<K, V> m, F f) {
    return each_job(pairs_of(m), std::move(f));
}
template <class A, class F>
JobRef<Array<A>> filter_job(Array<A> xs, F keep) {
    return fold_job(std::move(xs), Array<A>(), [keep](std::tuple<Array<A>, A> p) {
        auto acc = std::get<0>(p);
        auto x = std::get<1>(p);
        return map_job(keep(x), [acc, x](bool k) { return k ? acc.pushed(x) : acc; });
    });
}
template <class K, class V, class F>
JobRef<Map<K, V>> filter_map_job(Map<K, V> m, F keep) {
    return fold_job(pairs_of(m), Map<K, V>(), [keep](std::tuple<Map<K, V>, std::tuple<K, V>> p) {
        auto acc = std::get<0>(p);
        auto kv = std::get<1>(p);
        return map_job(keep(kv), [acc, kv](bool k) { return k ? acc.inserted(std::get<0>(kv), std::get<1>(kv)) : acc; });
    });
}

/// A job run to its result inside the cycle: a call of an unbounded function value from
/// direct-style code (gap DS of prismc/README.md).
template <class B>
B run_to_end(JobRef<B> job) {
    while (true) {
        Turn<B> t = job->cycle();
        if (auto m = t.if_more()) job = m->next;
        else return std::move(std::get<typename Turn<B>::Finished>(t.v).value);
    }
}

// ---- Running ----------------------------------------------------------------------------

/// `--world NAME` as the first argument: the World, and the arguments without the option.
inline std::pair<std::string, std::vector<std::string>> world_option(const std::vector<std::string>& args, const std::string& fallback) {
    if (args.size() > 1 && args[0] == "--world") return {args[1], std::vector<std::string>(args.begin() + 2, args.end())};
    if (!args.empty() && args[0].rfind("--world=", 0) == 0) return {args[0].substr(8), std::vector<std::string>(args.begin() + 1, args.end())};
    return {fallback, args};
}

inline std::optional<std::string> read_file(const std::string& path) {
    std::ifstream f(path, std::ios::binary);
    if (!f) return std::nullopt;
    std::stringstream s;
    s << f.rdbuf();
    return s.str();
}

/// `test`: each script under the Test World. With `--print` the transcripts go to standard
/// output as they are; otherwise each is compared byte for byte with the `.expected` beside
/// it (`tests.expected` for the test module `tests.prism`), and `ok` or the
/// difference is printed.
inline int run_scripts(const TestWorld& world, const std::vector<std::string>& given, const std::vector<std::string>& compiled) {
    bool print = std::find(given.begin(), given.end(), "--print") != given.end();
    std::vector<std::string> paths;
    for (const auto& a : given)
        if (a != "--print") paths.push_back(a);
    if (paths.empty()) paths = compiled;
    int code = 0;
    for (const auto& path : paths) {
        auto script = read_file(path);
        if (!script) {
            std::fprintf(stderr, "%s: cannot read the script\n", path.c_str());
            code = 2;
            continue;
        }
        // a test module's transcript is beside it, its `.prism` dropped
        std::string stem = path.size() > 6 && path.substr(path.size() - 6) == ".prism" ? path.substr(0, path.size() - 6) : path;
        auto expected = print ? std::nullopt : read_file(stem + ".expected");
        if (!expected) {
            Report report = world.run(*script);
            std::fwrite(report.transcript.data(), 1, report.transcript.size(), stdout);
            for (const auto& f : report.failures) std::fprintf(stderr, "%s: %s\n", path.c_str(), f.c_str());
            code = std::max(code, int(report.exit_code));
            continue;
        }
        auto verdict = world.verify(*script, *expected);
        if (verdict) std::printf("ok %s\n", path.c_str());
        else {
            std::printf("FAILED %s: %s\n", path.c_str(), verdict.error().c_str());
            code = 1;
        }
    }
    std::fflush(stdout);
    return code;
}

/// Run on a thread with a large stack (4 GB, committed as it is used): unbounded code runs
/// direct-style within a cycle (doubt DS of prismc/README.md), and a C++ frame of the
/// emitted code is larger than Rust's, whose runner takes 1 GB.
inline int on_big_stack(std::function<int()> f) {
    struct Job {
        std::function<int()> f;
        int code = 1;
    } job{std::move(f)};
    pthread_attr_t attr;
    pthread_attr_init(&attr);
    pthread_attr_setstacksize(&attr, std::size_t(4) << 30);
    pthread_t t;
    auto run = [](void* p) -> void* {
        auto* j = static_cast<Job*>(p);
        j->code = j->f();
        return nullptr;
    };
    if (pthread_create(&t, &attr, run, &job) != 0) {
        std::fprintf(stderr, "prism: no thread with a 4 GB stack: running on the main thread's\n");
        return job.f();
    }
    pthread_join(t, nullptr);
    pthread_attr_destroy(&attr);
    return job.code;
}

/// The root under the CLI World (`worlds/cli/cpp`).
template <class P>
int run_cli(const std::vector<std::string>& args) { return prism_world_cli::run<P>(args); }

}  // namespace prelude
}  // namespace crate
