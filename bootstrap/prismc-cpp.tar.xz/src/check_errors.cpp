// The module `CheckErrors`, from `target/bootstrap/cpp-src/prismc/check-errors.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (claude/backend.md). Edit the Prism source, not this file.
#include "check_errors.hpp"
#include "ast.hpp"
#include "lexer.hpp"
#include "lexer.generic.hpp"

namespace crate::check_errors {

void CDiag::show(Printer& p) const {
    p.record("CDiag", {{"code", code}, {"file", file}, {"span", span}, {"message", message}, {"fix", fix}});
}

Pod CDiag::to_pod() const {
    return Pod::record("CDiag", {{"code", prism_rtl::to_pod(code)}, {"file", prism_rtl::to_pod(file)}, {"span", prism_rtl::to_pod(span)}, {"message", prism_rtl::to_pod(message)}, {"fix", prism_rtl::to_pod(fix)}});
}

Result<CDiag> CDiag::from_pod(const Pod& whole) {
    return CDiag{.code = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "code")))), .file = TRY(prism_rtl::from_pod<Nat>(TRY(prelude::field(whole, "file")))), .span = TRY(prism_rtl::from_pod<ast::Range>(TRY(prelude::field(whole, "span")))), .message = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "message")))), .fix = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "fix"))))};
}


void Src::show(Printer& p) const {
    p.record("Src", {{"path", path_}, {"text", text}, {"starts", starts}});
}

Pod Src::to_pod() const {
    return Pod::record("Src", {{"path", prism_rtl::to_pod(path_)}, {"text", prism_rtl::to_pod(text)}, {"starts", prism_rtl::to_pod(starts)}});
}

Result<Src> Src::from_pod(const Pod& whole) {
    return Src{.path_ = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "path")))), .text = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "text")))), .starts = TRY(prism_rtl::from_pod<Array<Nat>>(TRY(prelude::field(whole, "starts"))))};
}


/// MkSrc: fn Text, Text -> Src
Src mk_src(const Text& path_, const Text& text) {
    return Src{.path_ = path_, .text = text, .starts = cline_starts(text)};
}


/// Diag0: fn Text, Nat, Range, Text -> CDiag
CDiag diag0(const Text& code, const Nat& file, const ast::Range& span, const Text& message) {
    return CDiag{.code = code, .file = file, .span = span, .message = message, .fix = Text::lit("")};
}


/// DiagFix: fn Text, Nat, Range, Text, Text -> CDiag
CDiag diag_fix(const Text& code, const Nat& file, const ast::Range& span, const Text& message, const Text& fix) {
    return CDiag{.code = code, .file = file, .span = span, .message = message, .fix = fix};
}


/// CLineStarts: fn Text -> [Nat]
Array<Nat> cline_starts(const Text& text) {
    auto&& _starts = fold(split(text, Text::lit("\n")), std::tuple{Array<Nat>{}, Nat(0u)}, [&](const std::tuple<Array<Nat>, Nat>& _p0, const Text& line) {
        auto&& acc = std::get<0>(_p0);
        auto&& at_ = std::get<1>(_p0);
        return std::tuple{prelude::push(acc, at_), (at_ + len_text(line)) + Nat(1u)};
    });
    auto&& starts = std::get<0>(_starts);
    return starts;
}


/// CLineOf: fn [Nat], Nat -> Nat
Nat cline_of(const Array<Nat>& starts, const Nat& offset) {
    return lexer::dec(fold(starts, Nat(0u), [&](const Nat& n, const Nat& s) { return s <= offset ? n + Nat(1u) : n; }));
}


/// LineText: fn Src, Nat -> Text
Text line_text(const Src& src, const Nat& n) {
    auto from = or_(index(src.starts, n), Nat(0u));
    auto to = or_(index(src.starts, n + Nat(1u)), len_text(src->text) + Nat(1u));
    return lexer::between(src->text, from, prelude::max(from, or_(to.checked_sub(Nat(1u)), Nat(0u))));
}


/// SpanText: fn Src, Range -> Text
Text span_text(const Src& src, const ast::Range& r) {
    return lexer::between(src->text, r.start, prelude::max(r.start, r.end));
}


/// Repeat: fn Text, Nat -> Text
Text repeat(const Text& t, const Nat& n) {
    return concat(fold(range0(n), Array<Text>{}, [&](const Array<Text>& acc, const Nat& _p1) { return prelude::push(acc, t); }));
}


/// Range0: fn Nat -> [Nat]
Array<Nat> range0(const Nat& n) {
    Array<Nat> this_ = Array<Nat>{};
    Nat i = Nat(0u);
    Nat left = n;
    while (true) {
        auto&& _m = left.checked_sub(Nat(1u));
        if (!(prism_rtl::is_some(_m))) break;
        auto&& m = prism_rtl::some_of(_m);
        left = m;
        this_ = prelude::push(this_, i);
        i = i + Nat(1u);
    }
    return this_;
}


/// RenderCDiag: fn [Src], CDiag -> Text
Text render_cdiag(const Array<Src>& srcs, const CDiag& d) {
    auto&& _m = index(srcs, d->file);
    if (prism_rtl::is_none(_m)) {
        return prism_rtl::cat("?: ", severity(d), "[", d.code, "]: ", d.message, "\n");
    }
    if (prism_rtl::is_some(_m)) {
        auto&& src = prism_rtl::some_of(_m);
        auto line = cline_of(src.starts, d.span.start);
        auto col = lexer::column_of(src->text, or_(index(src.starts, line), Nat(0u)), d.span.start);
        auto text = line_text(src, line);
        auto width = prelude::max(Nat(1u), prelude::min(lexer::count_chars(span_text(src, d.span)), or_(lexer::count_chars(text).checked_sub(col), Nat(1u))));
        auto carets = prism_rtl::cat("    ", repeat(Text::lit(" "), col), repeat(Text::lit("^"), width));
        auto fix_1 = d.fix == Text::lit("")
            ? Text::lit("")
            : prism_rtl::cat("  fix: ", d.fix, "\n");
        return prism_rtl::cat(src->path_, ":", line + Nat(1u), ": ", severity(d), "[", d.code, "]: ", d.message, "\n    ", text, "\n", carets, "\n", fix_1);
    }
    prism_rtl::unreachable("no arm matched");
}


/// Severity: fn CDiag -> Text
Text severity(const CDiag& d) {
    return is_warning(d) ? Text::lit("warning") : Text::lit("error");
}


/// IsWarning: fn CDiag -> Bool
bool is_warning(const CDiag& d) {
    return d.code == Text::lit("unused");
}


/// SortDiags: fn [CDiag] -> [CDiag]
Array<CDiag> sort_diags(const Array<CDiag>& ds) {
    return fold(ds, Array<CDiag>{}, [&](const Array<CDiag>& acc, const CDiag& d) { return insert_sorted(acc, d); });
}


/// InsertSorted: fn [CDiag], CDiag -> [CDiag]
Array<CDiag> insert_sorted(const Array<CDiag>& acc, const CDiag& d) {
    auto before_ = filter(acc, [&](const CDiag& x) { return !diag_before2(d, x); });
    auto after_ = filter(acc, [&](const CDiag& x) { return diag_before2(d, x); });
    return any_is(acc, d) ? acc : append(prelude::push(before_, d), after_);
}


/// AnyIs: fn [CDiag], CDiag -> Bool
bool any_is(const Array<CDiag>& xs, const CDiag& d) {
    return fold(xs, false, [&](const bool& seen, const CDiag& x) { return seen || (x == d); });
}


/// DiagBefore2: fn CDiag, CDiag -> Bool
bool diag_before2(const CDiag& a, const CDiag& b) {
    return a->file != b->file ? a->file < b->file : a.span.start < b.span.start;
}


/// CountWord: fn Nat -> Text
Text count_word(const Nat& n0) {
    {
        auto&& c0_0 = n0;
        if (c0_0 == Nat(0u)) {
            return Text::lit("no");
        }
    }
    {
        auto&& c1_0 = n0;
        if (c1_0 == Nat(1u)) {
            return Text::lit("one");
        }
    }
    {
        auto&& c2_0 = n0;
        if (c2_0 == Nat(2u)) {
            return Text::lit("two");
        }
    }
    {
        auto&& c3_0 = n0;
        if (c3_0 == Nat(3u)) {
            return Text::lit("three");
        }
    }
    {
        auto&& c4_0 = n0;
        if (c4_0 == Nat(4u)) {
            return Text::lit("four");
        }
    }
    {
        auto&& n = n0;
        return show_text(n);
    }
}

}  // namespace crate::check_errors
