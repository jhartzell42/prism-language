// The module `Syntax.Parser.Blocks`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <syntax/parser/blocks/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Syntax.Parser.Blocks`, from `target/bootstrap/cpp-src/prismc/syntax/parser/blocks.prism`.
namespace crate::syntax::parser::blocks {

/// ParseBlockAfterColon: unbounded fn Ps -> ((Block, Ps))
std::tuple<crate::syntax::Block, crate::syntax::parser::Ps> parse_block_after_colon_f(const crate::syntax::parser::Ps& p0_p0) {
    auto p_p1 = crate::syntax::parser::expect_colon_f(p0_p0);
    return crate::syntax::parser::at_open_l_f(p_p1)
        ? parse_indented_block_f(p_p1)
        : crate::syntax::parser::at_stmt_boundary_f(p_p1)
        ? std::tuple{crate::syntax::parser::decls::no_block_p(), crate::syntax::parser::error_here_f(p_p1, Text::lit("expected a statement after `:`"))}
        : ({
        auto start_p2 = crate::syntax::parser::here_f(p_p1);
        auto [first_p4, p1_p5] = parse_stmt_f(p_p1);
        auto r_p3 = ({
            std::tuple<Array<crate::syntax::Stmt>, crate::syntax::parser::Ps> this_ = std::tuple{Array(std::vector{first_p4}), p1_p5};
            Array<crate::syntax::Stmt> stmts_p6 = Array(std::vector{first_p4});
            crate::syntax::parser::Ps q_p7 = p1_p5;
            while ((crate::syntax::parser::kind_f(q_p7) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KSemi{})) && (!q_p7.bad_p)) {
                auto [st_p8, q2_p9] = parse_stmt_f(crate::syntax::parser::adv_f(q_p7));
                stmts_p6 = crate::prelude::push(stmts_p6, st_p8);
                q_p7 = q2_p9;
            }
            this_ = std::tuple{stmts_p6, q_p7};
            (std::move(this_));
        });
        auto [stmts_pa, q_pb] = r_p3;
        std::tuple{crate::syntax::Block{.stmts_p = stmts_pa, .inline_p = true, .span_p = crate::syntax::parser::to_f(start_p2, crate::syntax::parser::prev_f(q_pb))}, q_pb};
    });
}


prism_rtl::Turn<std::tuple<crate::syntax::Block, crate::syntax::parser::Ps>> ParseBlockAfterColon::cycle() const {
    const auto& p0_p0 = this->p0_p0;
    auto p_p1 = crate::syntax::parser::expect_colon_f(p0_p0);
    return crate::syntax::parser::at_open_l_f(p_p1)
        ? prism_rtl::more(prism_rtl::rc(ParseIndentedBlock(p_p1)))
        : crate::syntax::parser::at_stmt_boundary_f(p_p1)
        ? prism_rtl::finished(std::tuple{crate::syntax::parser::decls::no_block_p(), crate::syntax::parser::error_here_f(p_p1, Text::lit("expected a statement after `:`"))})
        : ({
        auto start_p2 = crate::syntax::parser::here_f(p_p1);
        (crate::prelude::call_then(start_parse_stmt_f(p_p1), [=, start_p2 = std::move(start_p2)](std::tuple<crate::syntax::Stmt, crate::syntax::parser::Ps> parse_stmt_f_1224) {
        return ({
            auto [first_p4, p1_p5] = parse_stmt_f_1224;
            std::tuple<Array<crate::syntax::Stmt>, crate::syntax::parser::Ps> this_ = std::tuple{Array(std::vector{first_p4}), p1_p5};
            Array<crate::syntax::Stmt> stmts_p6 = Array(std::vector{first_p4});
            crate::syntax::parser::Ps q_p7 = p1_p5;
            auto start_p2z = start_p2;
            (crate::prelude::call_then(crate::prelude::loop_job(std::tuple{std::move(this_), std::move(q_p7), std::move(stmts_p6)}, [=](std::tuple<std::tuple<Array<crate::syntax::Stmt>, crate::syntax::parser::Ps>, crate::syntax::parser::Ps, Array<crate::syntax::Stmt>> _p0) {
            auto this_ = std::get<0>(_p0);
            auto q_p7 = std::get<1>(_p0);
            auto stmts_p6 = std::get<2>(_p0);
            return (crate::syntax::parser::kind_f(q_p7) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KSemi{})) && (!prism_rtl::deref(q_p7).bad_p)
                ? ({
                auto [st_p8, q2_p9] = parse_stmt_f(crate::syntax::parser::adv_f(q_p7));
                stmts_p6 = crate::prelude::push(stmts_p6, st_p8);
                q_p7 = q2_p9;
                Expected<std::tuple<std::tuple<Array<crate::syntax::Stmt>, crate::syntax::parser::Ps>, crate::syntax::parser::Ps, Array<crate::syntax::Stmt>>, std::tuple<std::tuple<Array<crate::syntax::Stmt>, crate::syntax::parser::Ps>, crate::syntax::parser::Ps, Array<crate::syntax::Stmt>>>(std::tuple{this_, q_p7, stmts_p6});
            })
                : Expected<std::tuple<std::tuple<Array<crate::syntax::Stmt>, crate::syntax::parser::Ps>, crate::syntax::parser::Ps, Array<crate::syntax::Stmt>>, std::tuple<std::tuple<Array<crate::syntax::Stmt>, crate::syntax::parser::Ps>, crate::syntax::parser::Ps, Array<crate::syntax::Stmt>>>(unexpected(std::tuple{this_, q_p7, stmts_p6}));
        }), [=, start_p2z = std::move(start_p2z)](std::tuple<std::tuple<Array<crate::syntax::Stmt>, crate::syntax::parser::Ps>, crate::syntax::parser::Ps, Array<crate::syntax::Stmt>> _p0) {
            auto this_ = std::get<0>(_p0);
            auto q_p7 = std::get<1>(_p0);
            auto stmts_p6 = std::get<2>(_p0);
            return ({
                this_ = std::tuple{stmts_p6, q_p7};
                auto r_p3 = this_;
                auto [stmts_pa, q_pb] = r_p3;
                (prism_rtl::finished(std::tuple{crate::syntax::Block{.stmts_p = stmts_pa, .inline_p = true, .span_p = crate::syntax::parser::to_f(start_p2z, crate::syntax::parser::prev_f(q_pb))}, q_pb}));
            });
        }));
        });
    }));
    });
}


/// `Start ParseBlockAfterColon, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Block, crate::syntax::parser::Ps>> start_parse_block_after_colon_f(crate::syntax::parser::Ps p0_p0) {
    return prism_rtl::make_rc<ParseBlockAfterColon>(p0_p0);
}


/// ParseIndentedBlock: unbounded fn Ps -> ((Block, Ps))
std::tuple<crate::syntax::Block, crate::syntax::parser::Ps> parse_indented_block_f(const crate::syntax::parser::Ps& p0_p0) {
    auto start_p1 = crate::syntax::parser::here_f(p0_p0);
    auto [stmts_p2, q_p3] = stmts_until_f(crate::syntax::parser::adv_f(p0_p0), true);
    return std::tuple{crate::syntax::Block{.stmts_p = stmts_p2, .inline_p = false, .span_p = crate::syntax::parser::to_f(start_p1, crate::syntax::parser::prev_f(q_p3))}, q_p3};
}


prism_rtl::Turn<std::tuple<crate::syntax::Block, crate::syntax::parser::Ps>> ParseIndentedBlock::cycle() const {
    const auto& p0_p0 = this->p0_p0;
    auto start_p1 = crate::syntax::parser::here_f(p0_p0);
    auto p0_p0x = p0_p0;
    return crate::prelude::call_then(start_stmts_until_f(crate::syntax::parser::adv_f(p0_p0x), true), [=](std::tuple<Array<crate::syntax::Stmt>, crate::syntax::parser::Ps> stmts_until_f_1826) {
        return ({
            auto [stmts_p2, q_p3] = stmts_until_f_1826;
            (prism_rtl::finished(std::tuple{crate::syntax::Block{.stmts_p = stmts_p2, .inline_p = false, .span_p = crate::syntax::parser::to_f(start_p1, crate::syntax::parser::prev_f(q_p3))}, q_p3}));
        });
    });
}


/// `Start ParseIndentedBlock, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Block, crate::syntax::parser::Ps>> start_parse_indented_block_f(crate::syntax::parser::Ps p0_p0) {
    return prism_rtl::make_rc<ParseIndentedBlock>(p0_p0);
}


/// ParseBlockUntilEof: unbounded fn Ps, Range -> ((Block, Ps))
std::tuple<crate::syntax::Block, crate::syntax::parser::Ps> parse_block_until_eof_f(const crate::syntax::parser::Ps& p_p0, const crate::syntax::Range& span_p1) {
    auto [stmts_p2, q_p3] = crate::syntax::parser::at_eof_f(p_p0)
        ? std::tuple{Array<crate::syntax::Stmt>{}, p_p0}
        : stmts_until_f(p_p0, false);
    return std::tuple{crate::syntax::Block{.stmts_p = stmts_p2, .inline_p = false, .span_p = span_p1}, q_p3};
}


prism_rtl::Turn<std::tuple<crate::syntax::Block, crate::syntax::parser::Ps>> ParseBlockUntilEof::cycle() const {
    const auto& p_p0 = this->p_p0;
    const auto& span_p1 = this->span_p1;
    auto [stmts_p2, q_p3] = crate::syntax::parser::at_eof_f(p_p0)
        ? std::tuple{Array<crate::syntax::Stmt>{}, p_p0}
        : stmts_until_f(p_p0, false);
    return prism_rtl::finished(std::tuple{crate::syntax::Block{.stmts_p = stmts_p2, .inline_p = false, .span_p = span_p1}, q_p3});
}


/// `Start ParseBlockUntilEof, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Block, crate::syntax::parser::Ps>> start_parse_block_until_eof_f(crate::syntax::parser::Ps p_p0, crate::syntax::Range span_p1) {
    return prism_rtl::make_rc<ParseBlockUntilEof>(p_p0, span_p1);
}


/// StmtsUntil: unbounded fn Ps, Bool -> (([Stmt], Ps))
std::tuple<Array<crate::syntax::Stmt>, crate::syntax::parser::Ps> stmts_until_f(const crate::syntax::parser::Ps& p0_p0, const bool& indented_p1) {
    std::tuple<Array<crate::syntax::Stmt>, crate::syntax::parser::Ps> this_ = std::tuple{Array<crate::syntax::Stmt>{}, p0_p0};
    Array<crate::syntax::Stmt> stmts_p2 = Array<crate::syntax::Stmt>{};
    crate::syntax::parser::Ps p_p3 = p0_p0;
    bool going_p4 = true;
    while (std::move(going_p4)) {
        auto [st_p5, q_p6] = parse_stmt_f(p_p3);
        if (!prism_rtl::deref(q_p6).bad_p) {
            stmts_p2 = crate::prelude::push(stmts_p2, st_p5);
        }
        p_p3 = crate::syntax::parser::recovered_f(q_p6);
        {
            auto&& _m = crate::syntax::parser::kind_f(p_p3);
            if (prism_rtl::is<crate::syntax::lexer::TokKind::KLaySep>(_m)) {
                p_p3 = crate::syntax::parser::adv_f(p_p3);
                if ((!indented_p1) && crate::syntax::parser::at_eof_f(p_p3)) {
                    going_p4 = false;
                }
            } else if (prism_rtl::is<crate::syntax::lexer::TokKind::KLayClose>(_m)) {
                p_p3 = crate::syntax::parser::adv_f(p_p3);
                if (indented_p1 || crate::syntax::parser::at_eof_f(p_p3)) {
                    going_p4 = false;
                }
            } else if (prism_rtl::is<crate::syntax::lexer::TokKind::KEof>(_m)) {
                going_p4 = false;
            } else {
                p_p3 = crate::syntax::parser::recover_f(crate::syntax::parser::complain_f(p_p3, Text::lit("expected the end of the statement")));
            }
        }
    }
    this_ = std::tuple{stmts_p2, p_p3};
    return this_;
}


prism_rtl::Turn<std::tuple<Array<crate::syntax::Stmt>, crate::syntax::parser::Ps>> StmtsUntil::cycle() const {
    const auto& p0_p0 = this->p0_p0;
    const auto& indented_p1 = this->indented_p1;
    std::tuple<Array<crate::syntax::Stmt>, crate::syntax::parser::Ps> this_ = std::tuple{Array<crate::syntax::Stmt>{}, p0_p0};
    Array<crate::syntax::Stmt> stmts_p2 = Array<crate::syntax::Stmt>{};
    crate::syntax::parser::Ps p_p3 = p0_p0;
    bool going_p4 = true;
    return crate::prelude::call_then(crate::prelude::loop_job(std::tuple{std::move(this_), std::move(going_p4), std::move(p_p3), std::move(stmts_p2)}, ({
        auto indented_p1x = prism_rtl::deref(indented_p1);
        [=, indented_p1x = std::move(indented_p1x)](std::tuple<std::tuple<Array<crate::syntax::Stmt>, crate::syntax::parser::Ps>, bool, crate::syntax::parser::Ps, Array<crate::syntax::Stmt>> _p0) {
        auto this_ = std::get<0>(_p0);
        auto going_p4 = std::get<1>(_p0);
        auto p_p3 = std::get<2>(_p0);
        auto stmts_p2 = std::get<3>(_p0);
        return going_p4
            ? ({
            auto [st_p5, q_p6] = parse_stmt_f(p_p3);
            if (!prism_rtl::deref(q_p6).bad_p) {
                stmts_p2 = crate::prelude::push(stmts_p2, st_p5);
            }
            p_p3 = crate::syntax::parser::recovered_f(q_p6);
            {
                auto&& _m = crate::syntax::parser::kind_f(p_p3);
                if (prism_rtl::is<crate::syntax::lexer::TokKind::KLaySep>(_m)) {
                    p_p3 = crate::syntax::parser::adv_f(p_p3);
                    if ((!indented_p1x) && crate::syntax::parser::at_eof_f(p_p3)) {
                        going_p4 = false;
                    }
                } else if (prism_rtl::is<crate::syntax::lexer::TokKind::KLayClose>(_m)) {
                    p_p3 = crate::syntax::parser::adv_f(p_p3);
                    if (indented_p1x || crate::syntax::parser::at_eof_f(p_p3)) {
                        going_p4 = false;
                    }
                } else if (prism_rtl::is<crate::syntax::lexer::TokKind::KEof>(_m)) {
                    going_p4 = false;
                } else {
                    p_p3 = crate::syntax::parser::recover_f(crate::syntax::parser::complain_f(p_p3, Text::lit("expected the end of the statement")));
                }
            }
            Expected<std::tuple<std::tuple<Array<crate::syntax::Stmt>, crate::syntax::parser::Ps>, bool, crate::syntax::parser::Ps, Array<crate::syntax::Stmt>>, std::tuple<std::tuple<Array<crate::syntax::Stmt>, crate::syntax::parser::Ps>, bool, crate::syntax::parser::Ps, Array<crate::syntax::Stmt>>>(std::tuple{this_, going_p4, p_p3, stmts_p2});
        })
            : Expected<std::tuple<std::tuple<Array<crate::syntax::Stmt>, crate::syntax::parser::Ps>, bool, crate::syntax::parser::Ps, Array<crate::syntax::Stmt>>, std::tuple<std::tuple<Array<crate::syntax::Stmt>, crate::syntax::parser::Ps>, bool, crate::syntax::parser::Ps, Array<crate::syntax::Stmt>>>(unexpected(std::tuple{this_, going_p4, p_p3, stmts_p2}));
    };
    })), [=](std::tuple<std::tuple<Array<crate::syntax::Stmt>, crate::syntax::parser::Ps>, bool, crate::syntax::parser::Ps, Array<crate::syntax::Stmt>> _p0) {
        auto this_ = std::get<0>(_p0);
        auto going_p4 = std::get<1>(_p0);
        auto p_p3 = std::get<2>(_p0);
        auto stmts_p2 = std::get<3>(_p0);
        return ({
            this_ = std::tuple{stmts_p2, p_p3};
            (prism_rtl::finished(this_));
        });
    });
}


/// `Start StmtsUntil, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::syntax::Stmt>, crate::syntax::parser::Ps>> start_stmts_until_f(crate::syntax::parser::Ps p0_p0, bool indented_p1) {
    return prism_rtl::make_rc<StmtsUntil>(p0_p0, indented_p1);
}


/// ParseStmt: unbounded fn Ps -> ((Stmt, Ps))
std::tuple<crate::syntax::Stmt, crate::syntax::parser::Ps> parse_stmt_f(const crate::syntax::parser::Ps& p_p0) {
    auto start_p1 = crate::syntax::parser::here_f(p_p0);
    auto [kind_p2, q_p3] = stmt_kind_of_f(p_p0, start_p1);
    return std::tuple{crate::syntax::Stmt{.kind_p = kind_p2, .span_p = crate::syntax::parser::to_f(start_p1, crate::syntax::parser::prev_f(q_p3))}, q_p3};
}


prism_rtl::Turn<std::tuple<crate::syntax::Stmt, crate::syntax::parser::Ps>> ParseStmt::cycle() const {
    const auto& p_p0 = this->p_p0;
    auto start_p1 = crate::syntax::parser::here_f(p_p0);
    auto p_p0x = p_p0;
    return crate::prelude::call_then(start_stmt_kind_of_f(p_p0x, start_p1), [=](std::tuple<crate::syntax::StmtKind, crate::syntax::parser::Ps> stmt_kind_of_f_3254) {
        return ({
            auto [kind_p2, q_p3] = stmt_kind_of_f_3254;
            (prism_rtl::finished(std::tuple{crate::syntax::Stmt{.kind_p = kind_p2, .span_p = crate::syntax::parser::to_f(start_p1, crate::syntax::parser::prev_f(q_p3))}, q_p3}));
        });
    });
}


/// `Start ParseStmt, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Stmt, crate::syntax::parser::Ps>> start_parse_stmt_f(crate::syntax::parser::Ps p_p0) {
    return prism_rtl::make_rc<ParseStmt>(p_p0);
}


/// StmtKindOf: unbounded fn Ps, Range -> ((StmtKind, Ps))
std::tuple<crate::syntax::StmtKind, crate::syntax::parser::Ps> stmt_kind_of_f(const crate::syntax::parser::Ps& p_p0, const crate::syntax::Range& start_p1) {
    auto&& _m = crate::syntax::parser::kind_f(p_p0);
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m3409_0_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m3409_0_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        if (m3409_0_0 == Text::lit("emit")) {
            if (m3409_0_1 == Text::lit("")) {
                auto [r_p2, q_p3] = crate::syntax::parser::types::parse_row_f(crate::syntax::parser::adv_f(p_p0));
                return std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SEmit{r_p2}), q_p3};
            }
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m3409_1_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m3409_1_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        if (m3409_1_0 == Text::lit("let")) {
            if (m3409_1_1 == Text::lit("")) {
                auto [pattern_p4, p1_p5] = crate::syntax::parser::types::parse_pattern_f(crate::syntax::parser::adv_f(p_p0), false);
                auto [ty_o6, p2_p7] = crate::syntax::parser::decls::optional_annotation_f(p1_p5);
                auto [value_p8, p3_p9] = crate::syntax::parser::expr::parse_rhs_expr_f(crate::syntax::parser::expect_op_f(p2_p7, Text::lit("=")));
                return std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SLet{pattern_p4, ty_o6, value_p8}), p3_p9};
            }
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m3409_2_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m3409_2_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        if (m3409_2_0 == Text::lit("fn")) {
            if (m3409_2_1 == Text::lit("")) {
                auto [f_pa, q_pb] = crate::syntax::parser::decls::parse_fn_clause_f(p_p0);
                return std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SFn{f_pa}), q_pb};
            }
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m3409_3_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m3409_3_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        if (m3409_3_0 == Text::lit("ignore")) {
            if (m3409_3_1 == Text::lit("")) {
                if (crate::syntax::parser::at_op_f(crate::syntax::parser::adv_f(p_p0), Text::lit("<-"))) {
                    auto [e_pc, q_pd] = crate::syntax::parser::expr::parse_rhs_expr_f(crate::syntax::parser::adv_f(crate::syntax::parser::adv_f(p_p0)));
                    return std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SIgnore{e_pc}), q_pd};
                }
            }
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& w_pe = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m3409_4_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        if (m3409_4_1 == Text::lit("")) {
            if ((w_pe == Text::lit("require")) || (w_pe == Text::lit("forbid"))) {
                auto [c_pg, p1_ph] = crate::syntax::parser::expr::parse_rhs_expr_f(crate::syntax::parser::adv_f(p_p0));
                auto q_pf = crate::syntax::parser::at_comma_f(p1_ph)
                    ? crate::syntax::parser::error_at_f(p1_ph, crate::syntax::parser::here_f(p1_ph), prism_rtl::cat("`", w_pe, "` takes its condition alone, with no error value after a comma (decisions.md D15): a failed guard under `~` raises `Prelude.Unmet` (D11), and a comma after a guard belongs to a call at the head of its condition, as in `require Clear g, from, corner`"))
                    : p1_ph;
                return w_pe == Text::lit("require")
                    ? std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SRequire{c_pg}), q_pf}
                    : std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SForbid{c_pg}), q_pf};
            }
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m3409_5_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m3409_5_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        if (m3409_5_0 == Text::lit("while")) {
            if (m3409_5_1 == Text::lit("")) {
                auto [cond_pi, p1_pj] = crate::syntax::parser::expr::parse_cond_f(crate::syntax::parser::adv_f(p_p0), true);
                auto [body_pk, q_pl] = parse_block_after_colon_f(p1_pj);
                return std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SWhile{cond_pi, body_pk}), q_pl};
            }
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m3409_6_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m3409_6_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        if (m3409_6_0 == Text::lit("return")) {
            if (m3409_6_1 == Text::lit("")) {
                auto p1_pm = crate::syntax::parser::out_of_scope_f(crate::syntax::parser::adv_f(p_p0), crate::syntax::parser::here_f(p_p0), Text::lit("`T monad:` blocks and `^Monad`"), Text::lit("`return` ends a monad block, which is out of this compiler"));
                auto [e_pn, q_po] = crate::syntax::parser::expr::parse_rhs_expr_f(p1_pm);
                return std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SReturn{e_pn}), q_po};
            }
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m)) {
        if (crate::syntax::parser::kind_at_f(p_p0, Nat(1u)) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KColon{})) {
            return crate::syntax::parser::kind_at_f(p_p0, Nat(2u)) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KLayOpen{})
                ? ({
                auto [name_pp, p1_pq] = crate::syntax::parser::parse_sname_f(p_p0);
                auto [body_pr, q_ps] = parse_block_after_colon_f(p1_pq);
                std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SWidget{crate::syntax::decls::WidgetDecl{.name_p = name_pp, .body_p = body_pr, .span_p = crate::syntax::parser::to_f(start_p1, prism_rtl::deref(body_pr).span_p)}}), q_ps};
            })
                : ({
                auto [sig_pt, q_pu] = crate::syntax::parser::decls::parse_signature_f(p_p0);
                std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SSignature{sig_pt}), q_pu};
            });
        }
    }
    {
        return other_stmt_f(p_p0);
    }
}


prism_rtl::Turn<std::tuple<crate::syntax::StmtKind, crate::syntax::parser::Ps>> StmtKindOf::cycle() const {
    const auto& p_p0 = this->p_p0;
    const auto& start_p1 = this->start_p1;
    return ({
        auto&& _m = crate::syntax::parser::kind_f(p_p0);
        prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& m3409_0_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m3409_0_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        (m3409_0_0 == Text::lit("emit")) && (m3409_0_1 == Text::lit(""));
    }) ? ({
        auto&& m3409_0_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m3409_0_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        ({
        auto p_p0x = p_p0;
        (crate::prelude::call_then(crate::syntax::parser::types::start_parse_row_f(crate::syntax::parser::adv_f(p_p0x)), [=](std::tuple<crate::syntax::Row_, crate::syntax::parser::Ps> parse_row_f_3466) {
        return ({
            auto [r_p2, q_p3] = parse_row_f_3466;
            (prism_rtl::finished(std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SEmit{r_p2}), q_p3}));
        });
    }));
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& m3409_1_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m3409_1_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        (m3409_1_0 == Text::lit("let")) && (m3409_1_1 == Text::lit(""));
    }) ? ({
        auto&& m3409_1_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m3409_1_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        ({
        auto p_p0x = p_p0;
        (crate::prelude::call_then(crate::syntax::parser::types::start_parse_pattern_f(crate::syntax::parser::adv_f(p_p0x), false), [=](std::tuple<crate::syntax::Pattern_, crate::syntax::parser::Ps> parse_pattern_f_3555) {
        return ({
            auto [pattern_p4, p1_p5] = parse_pattern_f_3555;
            (crate::prelude::call_then(crate::syntax::parser::decls::start_optional_annotation_f(p1_p5), [=](std::tuple<std::optional<crate::syntax::Type>, crate::syntax::parser::Ps> optional_annotation_f_3609) {
            return ({
                auto [ty_o6, p2_p7] = optional_annotation_f_3609;
                (crate::prelude::call_then(crate::syntax::parser::expr::start_parse_rhs_expr_f(crate::syntax::parser::expect_op_f(p2_p7, Text::lit("="))), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_rhs_expr_f_3659) {
                return ({
                    auto [value_p8, p3_p9] = parse_rhs_expr_f_3659;
                    (prism_rtl::finished(std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SLet{pattern_p4, ty_o6, value_p8}), p3_p9}));
                });
            }));
            });
        }));
        });
    }));
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& m3409_2_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m3409_2_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        (m3409_2_0 == Text::lit("fn")) && (m3409_2_1 == Text::lit(""));
    }) ? ({
        auto&& m3409_2_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m3409_2_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        ({
        auto p_p0x = p_p0;
        (crate::prelude::call_then(crate::syntax::parser::decls::start_parse_fn_clause_f(p_p0x), [=](std::tuple<crate::syntax::decls::FnClause, crate::syntax::parser::Ps> parse_fn_clause_f_3775) {
        return ({
            auto [f_pa, q_pb] = parse_fn_clause_f_3775;
            (prism_rtl::finished(std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SFn{f_pa}), q_pb}));
        });
    }));
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& m3409_3_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m3409_3_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        (m3409_3_0 == Text::lit("ignore")) && (m3409_3_1 == Text::lit("")) && crate::syntax::parser::at_op_f(crate::syntax::parser::adv_f(p_p0), Text::lit("<-"));
    }) ? ({
        auto&& m3409_3_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m3409_3_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        ({
        auto p_p0x = p_p0;
        (crate::prelude::call_then(crate::syntax::parser::expr::start_parse_rhs_expr_f(crate::syntax::parser::adv_f(crate::syntax::parser::adv_f(p_p0x))), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_rhs_expr_f_3881) {
        return ({
            auto [e_pc, q_pd] = parse_rhs_expr_f_3881;
            (prism_rtl::finished(std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SIgnore{e_pc}), q_pd}));
        });
    }));
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& w_pe = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m3409_4_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        (m3409_4_1 == Text::lit("")) && ((w_pe == Text::lit("require")) || (w_pe == Text::lit("forbid")));
    }) ? ({
        auto&& w_pe = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m3409_4_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        ({
        auto p_p0x = p_p0;
        (crate::prelude::call_then(crate::syntax::parser::expr::start_parse_rhs_expr_f(crate::syntax::parser::adv_f(p_p0x)), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_rhs_expr_f_4174) {
        return ({
            auto [c_pg, p1_ph] = parse_rhs_expr_f_4174;
            auto q_pf = crate::syntax::parser::at_comma_f(p1_ph)
                ? crate::syntax::parser::error_at_f(p1_ph, crate::syntax::parser::here_f(p1_ph), prism_rtl::cat("`", w_pe, "` takes its condition alone, with no error value after a comma (decisions.md D15): a failed guard under `~` raises `Prelude.Unmet` (D11), and a comma after a guard belongs to a call at the head of its condition, as in `require Clear g, from, corner`"))
                : p1_ph;
            w_pe == Text::lit("require")
            ? prism_rtl::finished(std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SRequire{c_pg}), q_pf})
            : prism_rtl::finished(std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SForbid{c_pg}), q_pf});
        });
    }));
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& m3409_5_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m3409_5_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        (m3409_5_0 == Text::lit("while")) && (m3409_5_1 == Text::lit(""));
    }) ? ({
        auto&& m3409_5_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m3409_5_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        ({
        auto p_p0x = p_p0;
        (crate::prelude::call_then(crate::syntax::parser::expr::start_parse_cond_f(crate::syntax::parser::adv_f(p_p0x), true), [=](std::tuple<crate::syntax::Cond, crate::syntax::parser::Ps> parse_cond_f_4630) {
        return ({
            auto [cond_pi, p1_pj] = parse_cond_f_4630;
            (crate::prelude::call_then(start_parse_block_after_colon_f(p1_pj), [=](std::tuple<crate::syntax::Block, crate::syntax::parser::Ps> parse_block_after_colon_f_4680) {
            return ({
                auto [body_pk, q_pl] = parse_block_after_colon_f_4680;
                (prism_rtl::finished(std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SWhile{cond_pi, body_pk}), q_pl}));
            });
        }));
        });
    }));
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& m3409_6_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m3409_6_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        (m3409_6_0 == Text::lit("return")) && (m3409_6_1 == Text::lit(""));
    }) ? ({
        auto&& m3409_6_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m3409_6_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        ({
        auto p1_pm = crate::syntax::parser::out_of_scope_f(crate::syntax::parser::adv_f(p_p0), crate::syntax::parser::here_f(p_p0), Text::lit("`T monad:` blocks and `^Monad`"), Text::lit("`return` ends a monad block, which is out of this compiler"));
        (crate::prelude::call_then(crate::syntax::parser::expr::start_parse_rhs_expr_f(p1_pm), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_rhs_expr_f_4926) {
        return ({
            auto [e_pn, q_po] = parse_rhs_expr_f_4926;
            (prism_rtl::finished(std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SReturn{e_pn}), q_po}));
        });
    }));
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m) && ({
        (crate::syntax::parser::kind_at_f(p_p0, Nat(1u)) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KColon{}));
    }) ? crate::syntax::parser::kind_at_f(p_p0, Nat(2u)) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KLayOpen{})
        ? ({
        auto [name_pp, p1_pq] = crate::syntax::parser::parse_sname_f(p_p0);
        auto start_p1x = start_p1;
        (crate::prelude::call_then(start_parse_block_after_colon_f(p1_pq), [=, start_p1x = std::move(start_p1x)](std::tuple<crate::syntax::Block, crate::syntax::parser::Ps> parse_block_after_colon_f_5173) {
        return ({
            auto [body_pr, q_ps] = parse_block_after_colon_f_5173;
            (prism_rtl::finished(std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SWidget{crate::syntax::decls::WidgetDecl{.name_p = name_pp, .body_p = body_pr, .span_p = crate::syntax::parser::to_f(start_p1x, prism_rtl::deref(body_pr).span_p)}}), q_ps}));
        });
    }));
    })
        : ({
        auto p_p0x = p_p0;
        (crate::prelude::call_then(crate::syntax::parser::decls::start_parse_signature_f(p_p0x), [=](std::tuple<crate::syntax::decls::Signature, crate::syntax::parser::Ps> parse_signature_f_5328) {
        return ({
            auto [sig_pt, q_pu] = parse_signature_f_5328;
            (prism_rtl::finished(std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SSignature{sig_pt}), q_pu}));
        });
    }));
    })
        : prism_rtl::more(prism_rtl::rc(OtherStmt(p_p0)));
    });
}


/// `Start StmtKindOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::StmtKind, crate::syntax::parser::Ps>> start_stmt_kind_of_f(crate::syntax::parser::Ps p_p0, crate::syntax::Range start_p1) {
    return prism_rtl::make_rc<StmtKindOf>(p_p0, start_p1);
}


/// OtherStmt: unbounded fn Ps -> ((StmtKind, Ps))
std::tuple<crate::syntax::StmtKind, crate::syntax::parser::Ps> other_stmt_f(const crate::syntax::parser::Ps& p_p0) {
    auto [upd_p1, u_p2] = parse_update_stmt_f(p_p0);
    auto [pattern_p3, b_p4] = crate::syntax::parser::types::parse_pattern_f(p_p0, true);
    return !prism_rtl::deref(u_p2).bad_p
        ? std::tuple{upd_p1, u_p2}
        : (!prism_rtl::deref(b_p4).bad_p) && crate::syntax::parser::at_op_f(b_p4, Text::lit("<-"))
        ? ({
        auto [value_p5, p1_p6] = crate::syntax::parser::expr::parse_rhs_expr_f(crate::syntax::parser::adv_f(b_p4));
        auto [then_step_o7, p2_p8] = crate::syntax::parser::at_kw_f(p1_p6, Text::lit("then"))
            ? optional_rhs_f(crate::syntax::parser::adv_f(p1_p6))
            : std::tuple{std::optional<crate::syntax::Expr>{}, p1_p6};
        crate::syntax::parser::at_kw_f(p2_p8, Text::lit("then"))
        ? std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SExpr{crate::syntax::parser::decls::no_expr_p()}), crate::syntax::parser::error_at_f(p2_p8, crate::syntax::parser::here_f(p2_p8), Text::lit("`then` does not associate: a hold has one start and one step"))}
        : std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SBind{pattern_p3, value_p5, then_step_o7}), p2_p8};
    })
        : ({
        auto [e_p9, p1_pa] = crate::syntax::parser::expr::parse_rhs_expr_f(p_p0);
        crate::syntax::parser::at_op_f(p1_pa, Text::lit("<-"))
        ? std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SExpr{e_p9}), crate::syntax::parser::error_at_f(p1_pa, crate::syntax::parser::here_f(p1_pa), Text::lit("the left side of `<-` is not a pattern"))}
        : crate::syntax::parser::at_kw_f(p1_pa, Text::lit("then"))
        ? std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SExpr{e_p9}), crate::syntax::parser::error_at_f(p1_pa, crate::syntax::parser::here_f(p1_pa), Text::lit("`then` belongs to a hold: `$x <- start then step`"))}
        : std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SExpr{e_p9}), p1_pa};
    });
}


prism_rtl::Turn<std::tuple<crate::syntax::StmtKind, crate::syntax::parser::Ps>> OtherStmt::cycle() const {
    const auto& p_p0 = this->p_p0;
    auto p_p0x = p_p0;
    return crate::prelude::call_then(start_parse_update_stmt_f(p_p0x), [=](std::tuple<crate::syntax::StmtKind, crate::syntax::parser::Ps> parse_update_stmt_f_5569) {
        return ({
            auto [upd_p1, u_p2] = parse_update_stmt_f_5569;
            (crate::prelude::call_then(crate::syntax::parser::types::start_parse_pattern_f(p_p0x, true), [=](std::tuple<crate::syntax::Pattern_, crate::syntax::parser::Ps> parse_pattern_f_5612) {
            return ({
                auto [pattern_p3, b_p4] = parse_pattern_f_5612;
                (!prism_rtl::deref(u_p2).bad_p
                ? prism_rtl::finished(std::tuple{upd_p1, u_p2})
                : (!prism_rtl::deref(b_p4).bad_p) && crate::syntax::parser::at_op_f(b_p4, Text::lit("<-"))
                ? crate::prelude::call_then(crate::syntax::parser::expr::start_parse_rhs_expr_f(crate::syntax::parser::adv_f(b_p4)), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_rhs_expr_f_5733) {
                return ({
                    auto [value_p5, p1_p6] = parse_rhs_expr_f_5733;
                    auto [then_step_o7, p2_p8] = crate::syntax::parser::at_kw_f(p1_p6, Text::lit("then"))
                        ? optional_rhs_f(crate::syntax::parser::adv_f(p1_p6))
                        : std::tuple{std::optional<crate::syntax::Expr>{}, p1_p6};
                    (crate::syntax::parser::at_kw_f(p2_p8, Text::lit("then"))
                    ? prism_rtl::finished(std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SExpr{crate::syntax::parser::decls::no_expr_p()}), crate::syntax::parser::error_at_f(p2_p8, crate::syntax::parser::here_f(p2_p8), Text::lit("`then` does not associate: a hold has one start and one step"))})
                    : prism_rtl::finished(std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SBind{pattern_p3, value_p5, then_step_o7}), p2_p8}));
                });
            })
                : crate::prelude::call_then(crate::syntax::parser::expr::start_parse_rhs_expr_f(p_p0x), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_rhs_expr_f_6069) {
                return ({
                    auto [e_p9, p1_pa] = parse_rhs_expr_f_6069;
                    (crate::syntax::parser::at_op_f(p1_pa, Text::lit("<-"))
                    ? prism_rtl::finished(std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SExpr{e_p9}), crate::syntax::parser::error_at_f(p1_pa, crate::syntax::parser::here_f(p1_pa), Text::lit("the left side of `<-` is not a pattern"))})
                    : crate::syntax::parser::at_kw_f(p1_pa, Text::lit("then"))
                    ? prism_rtl::finished(std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SExpr{e_p9}), crate::syntax::parser::error_at_f(p1_pa, crate::syntax::parser::here_f(p1_pa), Text::lit("`then` belongs to a hold: `$x <- start then step`"))})
                    : prism_rtl::finished(std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SExpr{e_p9}), p1_pa}));
                });
            }));
            });
        }));
        });
    });
}


/// `Start OtherStmt, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::StmtKind, crate::syntax::parser::Ps>> start_other_stmt_f(crate::syntax::parser::Ps p_p0) {
    return prism_rtl::make_rc<OtherStmt>(p_p0);
}


/// OptionalRhs: unbounded fn Ps -> ((?Expr, Ps))
std::tuple<std::optional<crate::syntax::Expr>, crate::syntax::parser::Ps> optional_rhs_f(const crate::syntax::parser::Ps& p_p0) {
    auto [e_p1, q_p2] = crate::syntax::parser::expr::parse_rhs_expr_f(p_p0);
    return std::tuple{std::optional(e_p1), q_p2};
}


prism_rtl::Turn<std::tuple<std::optional<crate::syntax::Expr>, crate::syntax::parser::Ps>> OptionalRhs::cycle() const {
    const auto& p_p0 = this->p_p0;
    auto p_p0x = p_p0;
    return crate::prelude::call_then(crate::syntax::parser::expr::start_parse_rhs_expr_f(p_p0x), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_rhs_expr_f_6427) {
        return ({
            auto [e_p1, q_p2] = parse_rhs_expr_f_6427;
            (prism_rtl::finished(std::tuple{std::optional(e_p1), q_p2}));
        });
    });
}


/// `Start OptionalRhs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<std::optional<crate::syntax::Expr>, crate::syntax::parser::Ps>> start_optional_rhs_f(crate::syntax::parser::Ps p_p0) {
    return prism_rtl::make_rc<OptionalRhs>(p_p0);
}


/// ParseUpdateStmt: unbounded fn Ps -> ((StmtKind, Ps))
std::tuple<crate::syntax::StmtKind, crate::syntax::parser::Ps> parse_update_stmt_f(const crate::syntax::parser::Ps& p_p0) {
    auto [target_p2, p1_p3] = parse_reference_f(p_p0);
    auto op_p1 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = crate::syntax::parser::kind_f(p1_p3);
        if (prism_rtl::is<crate::syntax::lexer::TokKind::KOp>(_m)) {
            auto&& o_p4 = prism_rtl::as<crate::syntax::lexer::TokKind::KOp>(_m).a0;
            _v.set(o_p4);
            goto _done;
        }
        {
            _v.set(Text::lit(""));
            goto _done;
        }
    _done:
        _v.take();
    });
    return prism_rtl::deref(p1_p3).bad_p || (!(((((op_p1 == Text::lit("<=")) || (op_p1 == Text::lit("+="))) || (op_p1 == Text::lit("-="))) || (op_p1 == Text::lit("*="))) || (op_p1 == Text::lit("/="))))
        ? std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SExpr{crate::syntax::parser::decls::no_expr_p()}), crate::syntax::parser::fail_f(p1_p3)}
        : ({
        auto [value_p5, q_p6] = crate::syntax::parser::expr::parse_rhs_expr_f(crate::syntax::parser::adv_f(p1_p3));
        op_p1 == Text::lit("<=")
        ? std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SSet{target_p2, value_p5}), q_p6}
        : std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SAccum{target_p2, op_p1, value_p5}), q_p6};
    });
}


prism_rtl::Turn<std::tuple<crate::syntax::StmtKind, crate::syntax::parser::Ps>> ParseUpdateStmt::cycle() const {
    const auto& p_p0 = this->p_p0;
    auto p_p0x = p_p0;
    return crate::prelude::call_then(start_parse_reference_f(p_p0x), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_reference_f_6741) {
        return ({
            auto [target_p2, p1_p3] = parse_reference_f_6741;
            auto op_p1 = ({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                auto&& _m = crate::syntax::parser::kind_f(p1_p3);
                if (prism_rtl::is<crate::syntax::lexer::TokKind::KOp>(_m)) {
                    auto&& o_p4 = prism_rtl::as<crate::syntax::lexer::TokKind::KOp>(_m).a0;
                    _v.set(o_p4);
                    goto _done;
                }
                {
                    _v.set(Text::lit(""));
                    goto _done;
                }
            _done:
                _v.take();
            });
            (prism_rtl::deref(p1_p3).bad_p || (!(((((op_p1 == Text::lit("<=")) || (op_p1 == Text::lit("+="))) || (op_p1 == Text::lit("-="))) || (op_p1 == Text::lit("*="))) || (op_p1 == Text::lit("/="))))
            ? prism_rtl::finished(std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SExpr{crate::syntax::parser::decls::no_expr_p()}), crate::syntax::parser::fail_f(p1_p3)})
            : crate::prelude::call_then(crate::syntax::parser::expr::start_parse_rhs_expr_f(crate::syntax::parser::adv_f(p1_p3)), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_rhs_expr_f_6989) {
            return ({
                auto [value_p5, q_p6] = parse_rhs_expr_f_6989;
                op_p1 == Text::lit("<=")
                ? prism_rtl::finished(std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SSet{target_p2, value_p5}), q_p6})
                : prism_rtl::finished(std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SAccum{target_p2, op_p1, value_p5}), q_p6});
            });
        }));
        });
    });
}


/// `Start ParseUpdateStmt, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::StmtKind, crate::syntax::parser::Ps>> start_parse_update_stmt_f(crate::syntax::parser::Ps p_p0) {
    return prism_rtl::make_rc<ParseUpdateStmt>(p_p0);
}


/// ParseReference: unbounded fn Ps -> ((Expr, Ps))
std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_reference_f(const crate::syntax::parser::Ps& p_p0) {
    auto&& _m = crate::syntax::parser::kind_f(p_p0);
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m)) {
        auto&& n_p1 = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        if (crate::syntax::lexer::chars::has_prefix_f(prism_rtl::deref(n_p1).sigils_p, Text::lit("&"))) {
            auto start_p2 = crate::syntax::parser::here_f(p_p0);
            auto [name_p3, p1_p4] = crate::syntax::parser::parse_sname_f(p_p0);
            return crate::syntax::parser::is_upper_name_f(name_p3)
                ? ({
                auto p2_p5 = crate::syntax::parser::out_of_scope_f(p1_p4, prism_rtl::deref(name_p3).span_p, Text::lit("named lenses `&Home` and `Over`"), prism_rtl::cat("the named lens `", crate::syntax::parser::name_text_f(name_p3), "` is out of this compiler; write its path, `&_.score.home`"));
                auto [inner_p7, q_p8] = parse_reference_f(p2_p5);
                auto callee_p6 = crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EName{name_p3})), .span_p = start_p2};
                std::tuple{crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ECall{prism_rtl::rc(callee_p6), Array(std::vector{crate::syntax::Arg{.name_o = std::optional<crate::syntax::Ident>{}, .value_p = inner_p7, .span_p = prism_rtl::deref(inner_p7).span_p}}), false, false})), .span_p = crate::syntax::parser::to_f(start_p2, prism_rtl::deref(inner_p7).span_p)}, q_p8};
            })
                : lens_steps_f(crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EName{name_p3})), .span_p = prism_rtl::deref(name_p3).span_p}, p1_p4);
        }
    }
    {
        return std::tuple{crate::syntax::parser::decls::no_expr_p(), crate::syntax::parser::fail_f(p_p0)};
    }
}


prism_rtl::Turn<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> ParseReference::cycle() const {
    const auto& p_p0 = this->p_p0;
    return ({
        auto&& _m = crate::syntax::parser::kind_f(p_p0);
        prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m) && ({
        auto&& n_p1 = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        crate::syntax::lexer::chars::has_prefix_f(prism_rtl::deref(n_p1).sigils_p, Text::lit("&"));
    }) ? ({
        auto&& n_p1 = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        ({
        auto start_p2 = crate::syntax::parser::here_f(p_p0);
        auto [name_p3, p1_p4] = crate::syntax::parser::parse_sname_f(p_p0);
        (crate::syntax::parser::is_upper_name_f(name_p3)
        ? ({
        auto p2_p5 = crate::syntax::parser::out_of_scope_f(p1_p4, prism_rtl::deref(name_p3).span_p, Text::lit("named lenses `&Home` and `Over`"), prism_rtl::cat("the named lens `", crate::syntax::parser::name_text_f(name_p3), "` is out of this compiler; write its path, `&_.score.home`"));
        (crate::prelude::call_then(start_parse_reference_f(p2_p5), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_reference_f_7673) {
        return ({
            auto [inner_p7, q_p8] = parse_reference_f_7673;
            auto callee_p6 = crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EName{name_p3})), .span_p = start_p2};
            (prism_rtl::finished(std::tuple{crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ECall{prism_rtl::rc(callee_p6), Array(std::vector{crate::syntax::Arg{.name_o = std::optional<crate::syntax::Ident>{}, .value_p = inner_p7, .span_p = prism_rtl::deref(inner_p7).span_p}}), false, false})), .span_p = crate::syntax::parser::to_f(start_p2, prism_rtl::deref(inner_p7).span_p)}, q_p8}));
        });
    }));
    })
        : prism_rtl::finished(lens_steps_f(crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EName{name_p3})), .span_p = prism_rtl::deref(name_p3).span_p}, p1_p4)));
    });
    })
        : prism_rtl::finished(std::tuple{crate::syntax::parser::decls::no_expr_p(), crate::syntax::parser::fail_f(p_p0)});
    });
}


/// `Start ParseReference, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> start_parse_reference_f(crate::syntax::parser::Ps p_p0) {
    return prism_rtl::make_rc<ParseReference>(p_p0);
}


/// LensSteps: unbounded fn Expr, Ps -> ((Expr, Ps))
std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> lens_steps_f(const crate::syntax::Expr& e0_p0, const crate::syntax::parser::Ps& p0_p1) {
    std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> this_ = std::tuple{e0_p0, p0_p1};
    crate::syntax::Expr e_p2 = e0_p0;
    crate::syntax::parser::Ps p_p3 = p0_p1;
    bool going_p4 = true;
    while (std::move(going_p4) && (!p_p3.bad_p)) {
        ({
            __label__ _done;
            prism_rtl::Slot<Unit> _v;
            auto&& _m = crate::syntax::parser::kind_f(p_p3);
            if (prism_rtl::is<crate::syntax::lexer::TokKind::KDot>(_m) && !prism_rtl::as<crate::syntax::lexer::TokKind::KDot>(_m).a0) {
                _v.set(({
                    auto p1_p5 = crate::syntax::parser::adv_f(p_p3);
                    auto t_p6 = crate::syntax::parser::here_f(p1_p5);
                    ({
                        __label__ _done;
                        prism_rtl::Slot<Unit> _v;
                        auto&& _m = crate::syntax::parser::kind_f(p1_p5);
                        if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m)) {
                            auto&& f_p7 = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
                            if ((prism_rtl::deref(f_p7).sigils_p == Text::lit("")) && (prism_rtl::deref(f_p7).case_p == crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseLower{}))) {
                                _v.set(({
                                    e_p2 = crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EField{prism_rtl::rc(e_p2), Text::lit(""), crate::syntax::Ident{.name_p = crate::prelude::or_(crate::prelude::index(prism_rtl::deref(f_p7).path_p, Nat(0u)), Text::lit("")), .span_p = t_p6}})), .span_p = crate::syntax::parser::to_f(e_p2.span_p, t_p6)};
                                    p_p3 = crate::syntax::parser::adv_f(p1_p5);
                                    Unit{};
                                }));
                                goto _done;
                            }
                        }
                        if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
                            auto&& u8306_1_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
                            if (u8306_1_0 == Text::lit("key")) {
                                _v.set(({
                                    e_p2 = crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EField{prism_rtl::rc(e_p2), Text::lit(""), crate::syntax::Ident{.name_p = Text::lit("key"), .span_p = t_p6}})), .span_p = crate::syntax::parser::to_f(e_p2.span_p, t_p6)};
                                    p_p3 = crate::syntax::parser::adv_f(p1_p5);
                                    Unit{};
                                }));
                                goto _done;
                            }
                        }
                        {
                            _v.set(({
                                p_p3 = crate::syntax::parser::fail_f(p1_p5);
                                Unit{};
                            }));
                            goto _done;
                        }
                    _done:
                        _v.take();
                    });
                    Unit{};
                }));
                goto _done;
            }
            if (prism_rtl::is<crate::syntax::lexer::TokKind::KOpen>(_m) && !prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(_m).a1) {
                auto&& u8187_1_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(_m).a0;
                if (u8187_1_0 == Text::lit("[")) {
                    if (prism_rtl::deref(crate::syntax::parser::tk_f(p_p3)).touches_p) {
                        _v.set(({
                            auto [index_p8, p1_p9] = crate::syntax::parser::expr::parse_expr_f(crate::syntax::parser::adv_f(p_p3));
                            auto p2_pa = crate::syntax::parser::expect_close_f(p1_p9, Text::lit("["));
                            e_p2 = crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EIndex{prism_rtl::rc(e_p2), prism_rtl::rc(index_p8)})), .span_p = crate::syntax::parser::to_f(e_p2.span_p, crate::syntax::parser::prev_f(p2_pa))};
                            p_p3 = p2_pa;
                            Unit{};
                        }));
                        goto _done;
                    }
                }
            }
            {
                _v.set(({
                    going_p4 = false;
                    Unit{};
                }));
                goto _done;
            }
        _done:
            _v.take();
        });
    }
    this_ = std::tuple{e_p2, p_p3};
    return this_;
}

}  // namespace crate::syntax::parser::blocks
