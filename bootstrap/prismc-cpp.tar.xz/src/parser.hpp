// The module `Parser`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include "parser.types.hpp"
#include "elem.types.hpp"
#include "ast.types.hpp"
#include "lexer.types.hpp"

namespace crate {

using namespace prelude;

namespace parser {

ast::Range no_range();

lexer::Tok eof_tok();

Pair no_pair();

Parsed parse_file(const Text& src);

prism_rtl::JobRef<Parsed> start_parse_file(Text src);

Parsed parse_fragment(const Text& src);

prism_rtl::JobRef<Parsed> start_parse_fragment(Text src);

Ps new_ps(const Array<lexer::Tok>& toks0);

prism_rtl::JobRef<Ps> start_new_ps(Array<lexer::Tok> toks0);

Ps sub(const Ps& p_, const Array<lexer::Tok>& toks, const ast::Range& end);

prism_rtl::JobRef<Ps> start_sub(Ps p_, Array<lexer::Tok> toks, ast::Range end);

Ps absorb(const Ps& p_, const Ps& sub_);

Array<ast::Diag> finish_diags(const Array<ast::Diag>& ds);

Nat stage_rank(const Text& text0);

bool diag_before(const ast::Diag& a, const ast::Diag& b);

Array<ast::Diag> insert_diag(const Array<ast::Diag>& sorted, const ast::Diag& d);

Array<Pair> pair_brackets(const Array<lexer::Tok>& toks);

prism_rtl::JobRef<Array<Pair>> start_pair_brackets(Array<lexer::Tok> toks);

bool double_at(const Array<Pair>& pairs, const Array<lexer::Tok>& toks, const Nat& i, const Nat& j, const Text& kind_);

std::optional<Text> open_kind_of(const lexer::TokKind& tok_kind0);

std::optional<Text> close_kind_of(const lexer::TokKind& tok_kind0);

bool is_open_of(const lexer::TokKind& tok_kind0, const Text& text1);

lexer::Tok tk(const Ps& p_);

lexer::Tok tk_at(const Ps& p_, const Nat& n);

lexer::TokKind kind(const Ps& p_);

lexer::TokKind kind_at(const Ps& p_, const Nat& n);

ast::Range here(const Ps& p_);

ast::Range prev(const Ps& p_);

ast::Range to(const ast::Range& a, const ast::Range& b);

ast::Range at_end(const ast::Range& r);

Ps adv(const Ps& p_);

Pair pair_at(const Ps& p_);

bool at_eof(const Ps& p_);

bool at_kw(const Ps& p_, const Text& w);

bool at_op(const Ps& p_, const Text& op);

bool at_sep(const Ps& p_);

bool at_open_l(const Ps& p_);

bool at_close_l(const Ps& p_);

bool at_comma(const Ps& p_);

bool at_colon(const Ps& p_);

bool is_open_kind(const lexer::TokKind& tok_kind0, const Text& text1);

bool at_double_open(const Ps& p_, const Text& kind_);

bool at_single_open(const Ps& p_, const Text& kind_);

bool at_close(const Ps& p_, const Text& kind_);

Ps open_double(const Ps& p_);

Ps close_double(const Ps& p_, const Text& kind_);

Ps expect_close(const Ps& p_, const Text& kind_);

ast::Diag parse_diag(const ast::Range& span, const Text& message);

Ps error_at(const Ps& p_, const ast::Range& span, const Text& message);

Ps error_here(const Ps& p_, const Text& message);

Ps fail(const Ps& p_);

Ps unbad(const Ps& p_);

Ps note_error(const Ps& p_, const ast::Range& span, const Text& message);

Ps complain(const Ps& p_, const Text& message);

Ps out_of_scope(const Ps& p_, const ast::Range& span, const Text& feature, const Text& message);

Ps expect_colon(const Ps& p_);

Ps expect_op(const Ps& p_, const Text& op);

Ps expect_kw(const Ps& p_, const Text& w);

Ps recover(const Ps& p0);

prism_rtl::JobRef<Ps> start_recover(Ps p0);

Ps recovered(const Ps& p_);

prism_rtl::JobRef<Ps> start_recovered(Ps p_);

bool at_stmt_boundary(const Ps& p_);

Ps expect_stmt_end(const Ps& p_, const Text& what);

prism_rtl::JobRef<Ps> start_expect_stmt_end(Ps p_, Text what);

Text describe(const lexer::TokKind& tok_kind0);

template <class A>
std::tuple<A, Ps> bracketed(const Ps& p_, const prism_rtl::Fn<prism_rtl::JobRef<std::tuple<A, Ps>>(Ps)>& f_fn);

template <class A>
prism_rtl::JobRef<std::tuple<A, Ps>> start_bracketed(Ps p_, prism_rtl::Fn<prism_rtl::JobRef<std::tuple<A, Ps>>(Ps)> f_fn);

Ps with_step_mode(const Ps& p_, const bool& flag);

template <class A>
std::tuple<Array<A>, Ps> layout_items(const Ps& p0, const prism_rtl::Fn<prism_rtl::JobRef<std::tuple<A, Ps>>(Ps)>& f_fn);

template <class A>
prism_rtl::JobRef<std::tuple<Array<A>, Ps>> start_layout_items(Ps p0, prism_rtl::Fn<prism_rtl::JobRef<std::tuple<A, Ps>>(Ps)> f_fn);

template <class A>
std::tuple<Array<A>, Ps> commas(const Ps& p0, const prism_rtl::Fn<prism_rtl::JobRef<std::tuple<A, Ps>>(Ps)>& f_fn);

template <class A>
prism_rtl::JobRef<std::tuple<Array<A>, Ps>> start_commas(Ps p0, prism_rtl::Fn<prism_rtl::JobRef<std::tuple<A, Ps>>(Ps)> f_fn);

ast::SName no_sname();

ast::Ident no_ident();

bool is_upper_name(const ast::SName& n);

bool is_callee(const ast::SName& n);

bool is_topic(const ast::SName& n);

Text name_text(const ast::SName& n);

std::tuple<ast::SName, Ps> parse_sname(const Ps& p_);

std::tuple<ast::Ident, Ps> parse_ident(const Ps& p_);

std::tuple<ast::QualName, Ps> parse_qual_name(const Ps& p_);

std::tuple<ast::TraitRef, Ps> parse_trait_ref(const Ps& p_);

Ps check_name_scope(const Ps& p_, const ast::SName& name);

Ps check_type_name_scope(const Ps& p_, const ast::SName& name);

std::tuple<ast::Module, Ps> parse_module(const Ps& p0, const bool& fragment);

prism_rtl::JobRef<std::tuple<ast::Module, Ps>> start_parse_module(Ps p0, bool fragment);

ModRead module_item(const ModRead& s, const bool& fragment);

prism_rtl::JobRef<ModRead> start_module_item(ModRead s, bool fragment);

ModRead header_or_decl(const ModRead& s, const bool& fragment, const ast::Range& item_start);

prism_rtl::JobRef<ModRead> start_header_or_decl(ModRead s, bool fragment, ast::Range item_start);

ast::QualName no_qual();

std::tuple<ast::Use, Ps> parse_use(const Ps& p_, const ast::Range& start);

ast::Expr no_expr();

ast::Type no_type();

ast::Pattern_ no_pattern();

ast::Block no_block();

std::tuple<ast::Decl, Ps> parse_decl(const Ps& p_, const bool& fragment);

prism_rtl::JobRef<std::tuple<ast::Decl, Ps>> start_parse_decl(Ps p_, bool fragment);

std::tuple<ast::DeclKind, Ps> decl_kind_of(const Ps& p_, const bool& fragment, const ast::Range& start);

prism_rtl::JobRef<std::tuple<ast::DeclKind, Ps>> start_decl_kind_of(Ps p_, bool fragment, ast::Range start);

std::tuple<std::optional<ast::Type>, Ps> optional_annotation(const Ps& p_);

prism_rtl::JobRef<std::tuple<std::optional<ast::Type>, Ps>> start_optional_annotation(Ps p_);

std::tuple<ast::Signature, Ps> parse_signature(const Ps& p_);

prism_rtl::JobRef<std::tuple<ast::Signature, Ps>> start_parse_signature(Ps p_);

std::tuple<Array<ast::Bound>, Ps> optional_bounds(const Ps& p_);

prism_rtl::JobRef<std::tuple<Array<ast::Bound>, Ps>> start_optional_bounds(Ps p_);

std::tuple<ast::DefName, Ps> parse_def_name(const Ps& p_);

std::tuple<ast::FnClause, Ps> parse_fn_clause(const Ps& p0);

prism_rtl::JobRef<std::tuple<ast::FnClause, Ps>> start_parse_fn_clause(Ps p0);

std::tuple<ast::FnBody, Ps> parse_fn_body(const Ps& p_);

prism_rtl::JobRef<std::tuple<ast::FnBody, Ps>> start_parse_fn_body(Ps p_);

std::tuple<Array<ast::Ident>, Ps> lower_params(const Ps& p0);

bool is_plain_lower(const lexer::TokKind& tok_kind0);

std::tuple<ast::TypeDecl, Ps> parse_type_decl(const Ps& p0);

prism_rtl::JobRef<std::tuple<ast::TypeDecl, Ps>> start_parse_type_decl(Ps p0);

std::tuple<std::optional<ast::TypeBody>, Ps> parse_type_body(const Ps& p_, const ast::QualName& name, const Array<ast::Ident>& params);

prism_rtl::JobRef<std::tuple<std::optional<ast::TypeBody>, Ps>> start_parse_type_body(Ps p_, ast::QualName name, Array<ast::Ident> params);

bool is_unit_body(const Ps& p_, const lexer::NameTok& n, const Array<ast::Ident>& params);

std::tuple<Array<ast::Field>, Ps> parse_field_block(const Ps& p0);

prism_rtl::JobRef<std::tuple<Array<ast::Field>, Ps>> start_parse_field_block(Ps p0);

std::tuple<ast::Field, Ps> parse_field(const Ps& p_);

prism_rtl::JobRef<std::tuple<ast::Field, Ps>> start_parse_field(Ps p_);

std::tuple<ast::Case_, Ps> parse_case(const Ps& p0);

prism_rtl::JobRef<std::tuple<ast::Case_, Ps>> start_parse_case(Ps p0);

std::tuple<ast::TagDecl, Ps> parse_tag_decl(const Ps& p0);

prism_rtl::JobRef<std::tuple<ast::TagDecl, Ps>> start_parse_tag_decl(Ps p0);

std::tuple<ast::TraitDecl, Ps> parse_trait_decl(const Ps& p0);

prism_rtl::JobRef<std::tuple<ast::TraitDecl, Ps>> start_parse_trait_decl(Ps p0);

std::tuple<ast::ImplDecl, Ps> parse_impl_decl(const Ps& p0);

prism_rtl::JobRef<std::tuple<ast::ImplDecl, Ps>> start_parse_impl_decl(Ps p0);

std::tuple<Array<ast::TraitItem>, Ps> parse_trait_items(const Ps& p0);

prism_rtl::JobRef<std::tuple<Array<ast::TraitItem>, Ps>> start_parse_trait_items(Ps p0);

std::tuple<ast::TraitItem, Ps> parse_trait_item(const Ps& p_);

prism_rtl::JobRef<std::tuple<ast::TraitItem, Ps>> start_parse_trait_item(Ps p_);

std::tuple<std::optional<ast::Type>, Ps> optional_type(const Ps& p_);

prism_rtl::JobRef<std::tuple<std::optional<ast::Type>, Ps>> start_optional_type(Ps p_);

Ps check_higher_kinded(const Ps& p_, const ast::TraitDecl& t);

bool item_applies(const ast::TraitItem& trait_item0, const Array<ast::Ident>& xs1);

bool any_applies(const Array<ast::Type>& ts, const Array<ast::Ident>& params);

bool applies(const ast::Type& ty, const Array<ast::Ident>& params);

std::tuple<ast::Expr, Ps> parse_expr(const Ps& p_);

prism_rtl::JobRef<std::tuple<ast::Expr, Ps>> start_parse_expr(Ps p_);

std::tuple<ast::Expr, Ps> parse_arg_expr(const Ps& p_);

prism_rtl::JobRef<std::tuple<ast::Expr, Ps>> start_parse_arg_expr(Ps p_);

std::tuple<ast::Expr, Ps> parse_expr_ctx(const Ps& p_, const bool& commas_);

prism_rtl::JobRef<std::tuple<ast::Expr, Ps>> start_parse_expr_ctx(Ps p_, bool commas_);

std::tuple<ast::Expr, Ps> parse_rhs_expr(const Ps& p0);

prism_rtl::JobRef<std::tuple<ast::Expr, Ps>> start_parse_rhs_expr(Ps p0);

bool at_line_method(const Ps& p_);

bool is_plain_upper(const lexer::TokKind& tok_kind0);

bool is_upper_tok(const lexer::TokKind& tok_kind0);

std::optional<std::tuple<Text, std::optional<Array<Text>>>> peek_binop(const Ps& p_);

bool is_binop(const Text& op);

Nat level(const Text& text0);

std::tuple<ast::Expr, Ps> parse_binary(const Ps& p0, const Nat& min_, const bool& commas_);

prism_rtl::JobRef<std::tuple<ast::Expr, Ps>> start_parse_binary(Ps p0, Nat min_, bool commas_);

Climb climb_step(const Climb& c, const Nat& min_, const bool& commas_);

prism_rtl::JobRef<Climb> start_climb_step(Climb c, Nat min_, bool commas_);

Ps no_operator(const Ps& p_);

std::tuple<ast::Expr, Ps> parse_prefix(const Ps& p_, const Nat& min_, const bool& commas_);

prism_rtl::JobRef<std::tuple<ast::Expr, Ps>> start_parse_prefix(Ps p_, Nat min_, bool commas_);

std::tuple<ast::Expr, Ps> parse_postfix_expr(const Ps& p_, const bool& commas_);

prism_rtl::JobRef<std::tuple<ast::Expr, Ps>> start_parse_postfix_expr(Ps p_, bool commas_);

std::tuple<ast::Expr, Ps> parse_postfix(const ast::Expr& e0, const Ps& p0, const bool& commas_);

prism_rtl::JobRef<std::tuple<ast::Expr, Ps>> start_parse_postfix(ast::Expr e0, Ps p0, bool commas_);

std::tuple<ast::Expr, Ps, bool> postfix_step(const ast::Expr& e, const Ps& p_, const bool& commas_);

prism_rtl::JobRef<std::tuple<ast::Expr, Ps, bool>> start_postfix_step(ast::Expr e, Ps p_, bool commas_);

std::tuple<ast::Expr, Ps, bool> field_or_method(const ast::Expr& e, const Ps& p0, const bool& commas_);

prism_rtl::JobRef<std::tuple<ast::Expr, Ps, bool>> start_field_or_method(ast::Expr e, Ps p0, bool commas_);

std::tuple<Array<ast::Type>, Ps> parse_type_args(const Ps& p_);

prism_rtl::JobRef<std::tuple<Array<ast::Type>, Ps>> start_parse_type_args(Ps p_);

bool arg_starts_here(const Ps& p_);

Array<Text> arg_words();

std::tuple<Array<ast::Arg>, Ps> parse_call_args(const Ps& p_, const bool& commas_);

prism_rtl::JobRef<std::tuple<Array<ast::Arg>, Ps>> start_parse_call_args(Ps p_, bool commas_);

std::tuple<Array<ast::Arg>, Ps> parse_one_arg(const Ps& p_);

prism_rtl::JobRef<std::tuple<Array<ast::Arg>, Ps>> start_parse_one_arg(Ps p_);

std::tuple<ast::Arg, Ps> parse_arg(const Ps& p_);

prism_rtl::JobRef<std::tuple<ast::Arg, Ps>> start_parse_arg(Ps p_);

std::tuple<Array<ast::Arg>, bool, Ps> parse_paren_args(const Ps& p0);

prism_rtl::JobRef<std::tuple<Array<ast::Arg>, bool, Ps>> start_parse_paren_args(Ps p0);

std::tuple<std::optional<ast::Ident>, Ps> parse_arg_name(const Ps& p_);

std::tuple<ast::Expr, bool, Ps> parse_primary(const Ps& p_, const bool& commas_);

prism_rtl::JobRef<std::tuple<ast::Expr, bool, Ps>> start_parse_primary(Ps p_, bool commas_);

std::tuple<ast::Expr, bool, Ps> literal_primary(const Ps& p_);

prism_rtl::JobRef<std::tuple<ast::Expr, bool, Ps>> start_literal_primary(Ps p_);

std::tuple<ast::Expr, bool, Ps> name_primary(const Ps& p0, const lexer::NameTok& n, const bool& commas_);

prism_rtl::JobRef<std::tuple<ast::Expr, bool, Ps>> start_name_primary(Ps p0, lexer::NameTok n, bool commas_);

std::tuple<ast::Expr, Ps> type_args_on(const ast::Expr& e, const Ps& p_, const ast::Range& start);

prism_rtl::JobRef<std::tuple<ast::Expr, Ps>> start_type_args_on(ast::Expr e, Ps p_, ast::Range start);

std::tuple<ast::Expr, bool, Ps> paren_primary(const Ps& p_);

prism_rtl::JobRef<std::tuple<ast::Expr, bool, Ps>> start_paren_primary(Ps p_);

std::tuple<ast::Expr, bool, Ps> square_primary(const Ps& p_);

prism_rtl::JobRef<std::tuple<ast::Expr, bool, Ps>> start_square_primary(Ps p_);

std::tuple<ast::Expr, bool, Ps> map_primary(const Ps& p_);

prism_rtl::JobRef<std::tuple<ast::Expr, bool, Ps>> start_map_primary(Ps p_);

std::tuple<std::tuple<ast::Expr, ast::Expr>, Ps> parse_map_entry(const Ps& p_);

prism_rtl::JobRef<std::tuple<std::tuple<ast::Expr, ast::Expr>, Ps>> start_parse_map_entry(Ps p_);

std::tuple<ast::Expr, bool, Ps> lens_primary(const Ps& p0);

prism_rtl::JobRef<std::tuple<ast::Expr, bool, Ps>> start_lens_primary(Ps p0);

std::tuple<ast::Expr, bool, Ps> keyword_primary(const Ps& p_, const Text& w, const Text& sigils, const bool& commas_);

prism_rtl::JobRef<std::tuple<ast::Expr, bool, Ps>> start_keyword_primary(Ps p_, Text w, Text sigils, bool commas_);

std::tuple<ast::Expr, bool, Ps> took(const std::tuple<ast::Expr, Ps>& arg0);

std::tuple<ast::Literal, Ps> parse_literal(const Ps& p_);

prism_rtl::JobRef<std::tuple<ast::Literal, Ps>> start_parse_literal(Ps p_);

std::tuple<Array<ast::TextSeg>, Ps> text_segment(const Array<ast::TextSeg>& acc, const Ps& p_, const lexer::TextSegTok& text_seg_tok2);

prism_rtl::JobRef<std::tuple<Array<ast::TextSeg>, Ps>> start_text_segment(Array<ast::TextSeg> acc, Ps p_, lexer::TextSegTok text_seg_tok2);

std::tuple<ast::Expr, Ps> parse_nested(const Ps& p_, const Array<lexer::Tok>& toks, const ast::Range& span);

prism_rtl::JobRef<std::tuple<ast::Expr, Ps>> start_parse_nested(Ps p_, Array<lexer::Tok> toks, ast::Range span);

std::tuple<ast::Template, Ps> parse_template(const Ps& p0, const lexer::TemplateTok& t, const ast::Range& span);

prism_rtl::JobRef<std::tuple<ast::Template, Ps>> start_parse_template(Ps p0, lexer::TemplateTok t, ast::Range span);

std::tuple<Array<ast::TemplatePart>, Ps> template_parts(const Ps& p_, const Array<lexer::TPartTok>& parts);

prism_rtl::JobRef<std::tuple<Array<ast::TemplatePart>, Ps>> start_template_parts(Ps p_, Array<lexer::TPartTok> parts);

std::tuple<Array<ast::TemplatePart>, Ps> template_part_of(const Array<ast::TemplatePart>& acc, const Ps& p_, const lexer::TPartTok& tpart_tok2);

prism_rtl::JobRef<std::tuple<Array<ast::TemplatePart>, Ps>> start_template_part_of(Array<ast::TemplatePart> acc, Ps p_, lexer::TPartTok tpart_tok2);

std::tuple<Array<ast::Arg>, Ps> attr_arg(const Array<ast::Arg>& done, const Ps& p_, const lexer::AttrTok& a);

prism_rtl::JobRef<std::tuple<Array<ast::Arg>, Ps>> start_attr_arg(Array<ast::Arg> done, Ps p_, lexer::AttrTok a);

std::tuple<ast::Expr, Ps> parse_lambda(const Ps& p0);

prism_rtl::JobRef<std::tuple<ast::Expr, Ps>> start_parse_lambda(Ps p0);

std::tuple<std::optional<Array<ast::Pattern_>>, Ps> lambda_params(const Ps& p_);

prism_rtl::JobRef<std::tuple<std::optional<Array<ast::Pattern_>>, Ps>> start_lambda_params(Ps p_);

std::tuple<ast::Cond, Ps> parse_cond(const Ps& p_, const bool& allow_guard);

prism_rtl::JobRef<std::tuple<ast::Cond, Ps>> start_parse_cond(Ps p_, bool allow_guard);

std::tuple<ast::Expr, Ps> parse_if(const Ps& p0);

prism_rtl::JobRef<std::tuple<ast::Expr, Ps>> start_parse_if(Ps p0);

bool is_else(const lexer::TokKind& tok_kind0);

std::tuple<ast::Expr, Ps> parse_match(const Ps& p0);

prism_rtl::JobRef<std::tuple<ast::Expr, Ps>> start_parse_match(Ps p0);

std::tuple<Array<ast::Arm>, Ps> match_arms(const Ps& p0);

prism_rtl::JobRef<std::tuple<Array<ast::Arm>, Ps>> start_match_arms(Ps p0);

std::tuple<ast::Arm, Ps> parse_arm(const Ps& p_);

std::tuple<std::optional<ast::Expr>, Ps> optional_expr(const Ps& p_);

std::tuple<ast::Expr, Ps> parse_for(const Ps& p0);

prism_rtl::JobRef<std::tuple<ast::Expr, Ps>> start_parse_for(Ps p0);

std::tuple<std::optional<ast::ForBinders>, Ps> for_binders_of(const Ps& p_);

prism_rtl::JobRef<std::tuple<std::optional<ast::ForBinders>, Ps>> start_for_binders_of(Ps p_);

std::tuple<std::optional<ast::Pattern_>, Ps> optional_pattern(const Ps& p_);

std::tuple<ast::Block, Ps> parse_block_after_colon(const Ps& p0);

prism_rtl::JobRef<std::tuple<ast::Block, Ps>> start_parse_block_after_colon(Ps p0);

std::tuple<ast::Block, Ps> parse_indented_block(const Ps& p0);

prism_rtl::JobRef<std::tuple<ast::Block, Ps>> start_parse_indented_block(Ps p0);

std::tuple<ast::Block, Ps> parse_block_until_eof(const Ps& p_, const ast::Range& span);

prism_rtl::JobRef<std::tuple<ast::Block, Ps>> start_parse_block_until_eof(Ps p_, ast::Range span);

std::tuple<Array<ast::Stmt>, Ps> stmts_until(const Ps& p0, const bool& indented);

prism_rtl::JobRef<std::tuple<Array<ast::Stmt>, Ps>> start_stmts_until(Ps p0, bool indented);

std::tuple<ast::Stmt, Ps> parse_stmt(const Ps& p_);

prism_rtl::JobRef<std::tuple<ast::Stmt, Ps>> start_parse_stmt(Ps p_);

std::tuple<ast::StmtKind, Ps> stmt_kind_of(const Ps& p_, const ast::Range& start);

prism_rtl::JobRef<std::tuple<ast::StmtKind, Ps>> start_stmt_kind_of(Ps p_, ast::Range start);

std::tuple<ast::StmtKind, Ps> other_stmt(const Ps& p_);

prism_rtl::JobRef<std::tuple<ast::StmtKind, Ps>> start_other_stmt(Ps p_);

std::tuple<std::optional<ast::Expr>, Ps> optional_rhs(const Ps& p_);

prism_rtl::JobRef<std::tuple<std::optional<ast::Expr>, Ps>> start_optional_rhs(Ps p_);

std::tuple<ast::StmtKind, Ps> parse_update_stmt(const Ps& p_);

prism_rtl::JobRef<std::tuple<ast::StmtKind, Ps>> start_parse_update_stmt(Ps p_);

std::tuple<ast::Expr, Ps> parse_reference(const Ps& p_);

prism_rtl::JobRef<std::tuple<ast::Expr, Ps>> start_parse_reference(Ps p_);

std::tuple<ast::Expr, Ps> lens_steps(const ast::Expr& e0, const Ps& p0);

std::tuple<ast::Type, Ps> parse_type(const Ps& p_);

prism_rtl::JobRef<std::tuple<ast::Type, Ps>> start_parse_type(Ps p_);

bool is_plain_lower_one(const lexer::TokKind& tok_kind0);

bool is_fn_kw(const lexer::TokKind& tok_kind0);

std::tuple<ast::Color, Ps> color_var_of(const Ps& p_);

std::tuple<ast::Type, Ps> parse_emit_type(const Ps& p_);

prism_rtl::JobRef<std::tuple<ast::Type, Ps>> start_parse_emit_type(Ps p_);

std::tuple<ast::Type, Ps> parse_union_type(const Ps& p_);

prism_rtl::JobRef<std::tuple<ast::Type, Ps>> start_parse_union_type(Ps p_);

std::tuple<ast::Type, Ps> parse_map_type(const Ps& p_);

prism_rtl::JobRef<std::tuple<ast::Type, Ps>> start_parse_map_type(Ps p_);

std::tuple<ast::Type, Ps> parse_sigiled_type(const Ps& p_);

prism_rtl::JobRef<std::tuple<ast::Type, Ps>> start_parse_sigiled_type(Ps p_);

std::tuple<Text, Ps> free_sigil_run(const Ps& p0);

std::tuple<ast::Type, Ps> parse_app_type(const Ps& p_);

prism_rtl::JobRef<std::tuple<ast::Type, Ps>> start_parse_app_type(Ps p_);

bool type_atom_starts_here(const Ps& p_);

std::tuple<ast::Type, Ps> parse_type_atom(const Ps& p_);

prism_rtl::JobRef<std::tuple<ast::Type, Ps>> start_parse_type_atom(Ps p_);

std::tuple<ast::Type, Ps> type_atom_body(const Ps& p_, const ast::Range& start);

prism_rtl::JobRef<std::tuple<ast::Type, Ps>> start_type_atom_body(Ps p_, ast::Range start);

std::tuple<Array<ast::Bound>, Ps> parse_bounds(const Ps& p0);

prism_rtl::JobRef<std::tuple<Array<ast::Bound>, Ps>> start_parse_bounds(Ps p0);

bool is_name_kind(const lexer::TokKind& tok_kind0);

bool is_trait_kind(const lexer::TokKind& tok_kind0);

std::tuple<ast::Bound, Ps> parse_bound(const Ps& p_);

prism_rtl::JobRef<std::tuple<ast::Bound, Ps>> start_parse_bound(Ps p_);

std::tuple<ast::Row_, Ps> parse_row(const Ps& p_);

prism_rtl::JobRef<std::tuple<ast::Row_, Ps>> start_parse_row(Ps p_);

std::tuple<ast::RowTerm, Ps> parse_row_term(const Ps& p_);

prism_rtl::JobRef<std::tuple<ast::RowTerm, Ps>> start_parse_row_term(Ps p_);

bool type_atom_after_name(const Ps& p_);

std::tuple<ast::Pattern_, Ps> parse_pattern(const Ps& p_, const bool& commas0);

prism_rtl::JobRef<std::tuple<ast::Pattern_, Ps>> start_parse_pattern(Ps p_, bool commas0);

bool is_number_kind(const lexer::TokKind& tok_kind0);

std::tuple<ast::Pattern_, Ps> literal_pattern(const Ps& p_);

prism_rtl::JobRef<std::tuple<ast::Pattern_, Ps>> start_literal_pattern(Ps p_);

std::tuple<ast::Pattern_, Ps> name_pattern(const Ps& p0, const lexer::NameTok& n, const bool& commas_);

prism_rtl::JobRef<std::tuple<ast::Pattern_, Ps>> start_name_pattern(Ps p0, lexer::NameTok n, bool commas_);

bool pat_arg_starts_here(const Ps& p_);

std::tuple<ast::Pattern_, Ps> parse_record_pattern(const Ps& p0, const ast::SName& name);

prism_rtl::JobRef<std::tuple<ast::Pattern_, Ps>> start_parse_record_pattern(Ps p0, ast::SName name);

Array<Text> delivery_words();

bool is_delivery_word(const Text& w);

Text step_word(const Ps& p_);

bool at_word(const Ps& p_, const Text& w);

std::tuple<ast::CheckDecl, Ps> parse_check_decl(const Ps& p0);

prism_rtl::JobRef<std::tuple<ast::CheckDecl, Ps>> start_parse_check_decl(Ps p0);

std::tuple<ast::CheckLine, Ps> parse_check_line(const Ps& p_);

prism_rtl::JobRef<std::tuple<ast::CheckLine, Ps>> start_parse_check_line(Ps p_);

std::tuple<std::optional<ast::Pattern_>, Ps> optional_pattern_top(const Ps& p_);

prism_rtl::JobRef<std::tuple<std::optional<ast::Pattern_>, Ps>> start_optional_pattern_top(Ps p_);

std::tuple<ast::TestDecl, Ps> parse_test_decl(const Ps& p0);

prism_rtl::JobRef<std::tuple<ast::TestDecl, Ps>> start_parse_test_decl(Ps p0);

std::tuple<std::optional<Nat>, Ps> parse_seed(const Ps& p_);

std::tuple<ast::TestStep, Ps> step_in(const Ps& p_, const bool& saved);

prism_rtl::JobRef<std::tuple<ast::TestStep, Ps>> start_step_in(Ps p_, bool saved);

std::tuple<ast::TestStep, Ps> parse_step(const Ps& p0);

std::tuple<Array<ast::Entry>, Ps> with_entries(const Ps& p0);

std::tuple<ast::StepAction, Ps> step_action_of(const Ps& p_, const Array<ast::Entry>& withs);

std::tuple<ast::StepAction, Ps> deliveries(const Ps& p0);

bool is_delivery_name(const lexer::TokKind& tok_kind0);

std::tuple<ast::Entry, Ps> parse_entry(const Ps& p_);

std::tuple<ast::Delivery, Ps> parse_delivery(const Ps& p_);

std::tuple<ast::DeliveryKind, Ps> send_value(const Ps& p_);

std::tuple<ast::Target, Ps> parse_target(const Ps& p_);

bool is_path_kind(const lexer::TokKind& tok_kind0);

std::tuple<Array<ast::PathSeg>, Ps> path_seg_of(const Array<ast::PathSeg>& acc, const Ps& p_, const lexer::PathSegTok& path_seg_tok2, const ast::Range& range3);

std::tuple<ast::TestCheck, Ps> parse_test_check(const Ps& p0);

prism_rtl::JobRef<std::tuple<ast::TestCheck, Ps>> start_parse_test_check(Ps p0);

std::tuple<ast::TestCheckKind, Ps> check_kind_of(const Ps& p_, const Text& word);

prism_rtl::JobRef<std::tuple<ast::TestCheckKind, Ps>> start_check_kind_of(Ps p_, Text word);

std::tuple<ast::TestCheckKind, Ps> one_pattern(const Ps& p_, const prism_rtl::Fn<prism_rtl::JobRef<ast::TestCheckKind>(ast::Pattern_)>& make_fn);

prism_rtl::JobRef<std::tuple<ast::TestCheckKind, Ps>> start_one_pattern(Ps p_, prism_rtl::Fn<prism_rtl::JobRef<ast::TestCheckKind>(ast::Pattern_)> make_fn);

bool all_plain(const Array<lexer::TextSegTok>& segs);

bool is_plain_seg(const lexer::TextSegTok& text_seg_tok0);

Text plain_of(const lexer::TextSegTok& text_seg_tok0);

Nat parse_nat_text(const Text& text0);

std::optional<Nat> parse_radix(const Text& t, const Nat& radix);

}  // namespace parser


namespace parser {

/// The step machine of `ParseFile`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseFile: unbounded fn Text -> Parsed
struct ParseFile : prism_rtl::Job<Parsed> {
    Text src;
    ParseFile(Text src) : src(std::move(src)) {}
    prism_rtl::Turn<Parsed> cycle() const override;
};


/// The step machine of `ParseFragment`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseFragment: unbounded fn Text -> Parsed
struct ParseFragment : prism_rtl::Job<Parsed> {
    Text src;
    ParseFragment(Text src) : src(std::move(src)) {}
    prism_rtl::Turn<Parsed> cycle() const override;
};


/// The step machine of `NewPs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// NewPs: unbounded fn [Tok] -> Ps
struct NewPs : prism_rtl::Job<Ps> {
    Array<lexer::Tok> toks0;
    NewPs(Array<lexer::Tok> toks0) : toks0(std::move(toks0)) {}
    prism_rtl::Turn<Ps> cycle() const override;
};


/// The step machine of `Sub`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Sub: unbounded fn Ps, [Tok], Range -> Ps
struct Sub : prism_rtl::Job<Ps> {
    Ps p_;
    Array<lexer::Tok> toks;
    ast::Range end;
    Sub(Ps p_, Array<lexer::Tok> toks, ast::Range end) : p_(std::move(p_)), toks(std::move(toks)), end(std::move(end)) {}
    prism_rtl::Turn<Ps> cycle() const override;
};


/// The step machine of `PairBrackets`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PairBrackets: unbounded fn [Tok] -> [Pair]
struct PairBrackets : prism_rtl::Job<Array<Pair>> {
    Array<lexer::Tok> toks;
    PairBrackets(Array<lexer::Tok> toks) : toks(std::move(toks)) {}
    prism_rtl::Turn<Array<Pair>> cycle() const override;
};


/// The step machine of `Recover`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Recover: unbounded fn Ps -> Ps
struct Recover : prism_rtl::Job<Ps> {
    Ps p0;
    Recover(Ps p0) : p0(std::move(p0)) {}
    prism_rtl::Turn<Ps> cycle() const override;
};


/// The step machine of `Recovered`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Recovered: unbounded fn Ps -> Ps
struct Recovered : prism_rtl::Job<Ps> {
    Ps p_;
    Recovered(Ps p_) : p_(std::move(p_)) {}
    prism_rtl::Turn<Ps> cycle() const override;
};


/// The step machine of `ExpectStmtEnd`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ExpectStmtEnd: unbounded fn Ps, Text -> Ps
struct ExpectStmtEnd : prism_rtl::Job<Ps> {
    Ps p_;
    Text what;
    ExpectStmtEnd(Ps p_, Text what) : p_(std::move(p_)), what(std::move(what)) {}
    prism_rtl::Turn<Ps> cycle() const override;
};


/// The step machine of `Bracketed`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Bracketed: fn Ps, (fn Ps -> ((a, Ps))) -> ((a, Ps))
template <class A>
struct Bracketed : prism_rtl::Job<std::tuple<A, Ps>> {
    Ps p_;
    prism_rtl::Fn<prism_rtl::JobRef<std::tuple<A, Ps>>(Ps)> f_fn;
    Bracketed(Ps p_, prism_rtl::Fn<prism_rtl::JobRef<std::tuple<A, Ps>>(Ps)> f_fn) : p_(std::move(p_)), f_fn(std::move(f_fn)) {}
    prism_rtl::Turn<std::tuple<A, Ps>> cycle() const override;
};


/// The step machine of `LayoutItems`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LayoutItems: unbounded fn Ps, (fn Ps -> ((a, Ps))) -> (([a], Ps))
template <class A>
struct LayoutItems : prism_rtl::Job<std::tuple<Array<A>, Ps>> {
    Ps p0;
    prism_rtl::Fn<prism_rtl::JobRef<std::tuple<A, Ps>>(Ps)> f_fn;
    LayoutItems(Ps p0, prism_rtl::Fn<prism_rtl::JobRef<std::tuple<A, Ps>>(Ps)> f_fn) : p0(std::move(p0)), f_fn(std::move(f_fn)) {}
    prism_rtl::Turn<std::tuple<Array<A>, Ps>> cycle() const override;
};


/// The step machine of `Commas`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Commas: unbounded fn Ps, (fn Ps -> ((a, Ps))) -> (([a], Ps))
template <class A>
struct Commas : prism_rtl::Job<std::tuple<Array<A>, Ps>> {
    Ps p0;
    prism_rtl::Fn<prism_rtl::JobRef<std::tuple<A, Ps>>(Ps)> f_fn;
    Commas(Ps p0, prism_rtl::Fn<prism_rtl::JobRef<std::tuple<A, Ps>>(Ps)> f_fn) : p0(std::move(p0)), f_fn(std::move(f_fn)) {}
    prism_rtl::Turn<std::tuple<Array<A>, Ps>> cycle() const override;
};


/// The step machine of `ParseModule`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseModule: unbounded fn Ps, Bool -> ((Module, Ps))
struct ParseModule : prism_rtl::Job<std::tuple<ast::Module, Ps>> {
    Ps p0;
    bool fragment;
    ParseModule(Ps p0, bool fragment) : p0(std::move(p0)), fragment(std::move(fragment)) {}
    prism_rtl::Turn<std::tuple<ast::Module, Ps>> cycle() const override;
};


/// The step machine of `ModuleItem`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ModuleItem: unbounded fn ModRead, Bool -> ModRead
struct ModuleItem : prism_rtl::Job<ModRead> {
    ModRead s;
    bool fragment;
    ModuleItem(ModRead s, bool fragment) : s(std::move(s)), fragment(std::move(fragment)) {}
    prism_rtl::Turn<ModRead> cycle() const override;
};


/// The step machine of `HeaderOrDecl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// HeaderOrDecl: unbounded fn ModRead, Bool, Range -> ModRead
struct HeaderOrDecl : prism_rtl::Job<ModRead> {
    ModRead s;
    bool fragment;
    ast::Range item_start;
    HeaderOrDecl(ModRead s, bool fragment, ast::Range item_start) : s(std::move(s)), fragment(std::move(fragment)), item_start(std::move(item_start)) {}
    prism_rtl::Turn<ModRead> cycle() const override;
};


/// The step machine of `ParseDecl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseDecl: unbounded fn Ps, Bool -> ((Decl, Ps))
struct ParseDecl : prism_rtl::Job<std::tuple<ast::Decl, Ps>> {
    Ps p_;
    bool fragment;
    ParseDecl(Ps p_, bool fragment) : p_(std::move(p_)), fragment(std::move(fragment)) {}
    prism_rtl::Turn<std::tuple<ast::Decl, Ps>> cycle() const override;
};


/// The step machine of `DeclKindOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// DeclKindOf: unbounded fn Ps, Bool, Range -> ((DeclKind, Ps))
struct DeclKindOf : prism_rtl::Job<std::tuple<ast::DeclKind, Ps>> {
    Ps p_;
    bool fragment;
    ast::Range start;
    DeclKindOf(Ps p_, bool fragment, ast::Range start) : p_(std::move(p_)), fragment(std::move(fragment)), start(std::move(start)) {}
    prism_rtl::Turn<std::tuple<ast::DeclKind, Ps>> cycle() const override;
};


/// The step machine of `OptionalAnnotation`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// OptionalAnnotation: unbounded fn Ps -> ((?Type, Ps))
struct OptionalAnnotation : prism_rtl::Job<std::tuple<std::optional<ast::Type>, Ps>> {
    Ps p_;
    OptionalAnnotation(Ps p_) : p_(std::move(p_)) {}
    prism_rtl::Turn<std::tuple<std::optional<ast::Type>, Ps>> cycle() const override;
};


/// The step machine of `ParseSignature`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseSignature: unbounded fn Ps -> ((Signature, Ps))
struct ParseSignature : prism_rtl::Job<std::tuple<ast::Signature, Ps>> {
    Ps p_;
    ParseSignature(Ps p_) : p_(std::move(p_)) {}
    prism_rtl::Turn<std::tuple<ast::Signature, Ps>> cycle() const override;
};


/// The step machine of `OptionalBounds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// OptionalBounds: unbounded fn Ps -> (([Bound], Ps))
struct OptionalBounds : prism_rtl::Job<std::tuple<Array<ast::Bound>, Ps>> {
    Ps p_;
    OptionalBounds(Ps p_) : p_(std::move(p_)) {}
    prism_rtl::Turn<std::tuple<Array<ast::Bound>, Ps>> cycle() const override;
};


/// The step machine of `ParseFnClause`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseFnClause: unbounded fn Ps -> ((FnClause, Ps))
struct ParseFnClause : prism_rtl::Job<std::tuple<ast::FnClause, Ps>> {
    Ps p0;
    ParseFnClause(Ps p0) : p0(std::move(p0)) {}
    prism_rtl::Turn<std::tuple<ast::FnClause, Ps>> cycle() const override;
};


/// The step machine of `ParseFnBody`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseFnBody: unbounded fn Ps -> ((FnBody, Ps))
struct ParseFnBody : prism_rtl::Job<std::tuple<ast::FnBody, Ps>> {
    Ps p_;
    ParseFnBody(Ps p_) : p_(std::move(p_)) {}
    prism_rtl::Turn<std::tuple<ast::FnBody, Ps>> cycle() const override;
};


/// The step machine of `ParseTypeDecl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseTypeDecl: unbounded fn Ps -> ((TypeDecl, Ps))
struct ParseTypeDecl : prism_rtl::Job<std::tuple<ast::TypeDecl, Ps>> {
    Ps p0;
    ParseTypeDecl(Ps p0) : p0(std::move(p0)) {}
    prism_rtl::Turn<std::tuple<ast::TypeDecl, Ps>> cycle() const override;
};


/// The step machine of `ParseTypeBody`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseTypeBody: unbounded fn Ps, QualName, [Ident] -> ((?TypeBody, Ps))
struct ParseTypeBody : prism_rtl::Job<std::tuple<std::optional<ast::TypeBody>, Ps>> {
    Ps p_;
    ast::QualName name;
    Array<ast::Ident> params;
    ParseTypeBody(Ps p_, ast::QualName name, Array<ast::Ident> params) : p_(std::move(p_)), name(std::move(name)), params(std::move(params)) {}
    prism_rtl::Turn<std::tuple<std::optional<ast::TypeBody>, Ps>> cycle() const override;
};


/// The step machine of `ParseFieldBlock`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseFieldBlock: unbounded fn Ps -> (([Field], Ps))
struct ParseFieldBlock : prism_rtl::Job<std::tuple<Array<ast::Field>, Ps>> {
    Ps p0;
    ParseFieldBlock(Ps p0) : p0(std::move(p0)) {}
    prism_rtl::Turn<std::tuple<Array<ast::Field>, Ps>> cycle() const override;
};


/// The step machine of `ParseField`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseField: unbounded fn Ps -> ((Field, Ps))
struct ParseField : prism_rtl::Job<std::tuple<ast::Field, Ps>> {
    Ps p_;
    ParseField(Ps p_) : p_(std::move(p_)) {}
    prism_rtl::Turn<std::tuple<ast::Field, Ps>> cycle() const override;
};


/// The step machine of `ParseCase`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseCase: unbounded fn Ps -> ((Case, Ps))
struct ParseCase : prism_rtl::Job<std::tuple<ast::Case_, Ps>> {
    Ps p0;
    ParseCase(Ps p0) : p0(std::move(p0)) {}
    prism_rtl::Turn<std::tuple<ast::Case_, Ps>> cycle() const override;
};


/// The step machine of `ParseTagDecl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseTagDecl: unbounded fn Ps -> ((TagDecl, Ps))
struct ParseTagDecl : prism_rtl::Job<std::tuple<ast::TagDecl, Ps>> {
    Ps p0;
    ParseTagDecl(Ps p0) : p0(std::move(p0)) {}
    prism_rtl::Turn<std::tuple<ast::TagDecl, Ps>> cycle() const override;
};


/// The step machine of `ParseTraitDecl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseTraitDecl: unbounded fn Ps -> ((TraitDecl, Ps))
struct ParseTraitDecl : prism_rtl::Job<std::tuple<ast::TraitDecl, Ps>> {
    Ps p0;
    ParseTraitDecl(Ps p0) : p0(std::move(p0)) {}
    prism_rtl::Turn<std::tuple<ast::TraitDecl, Ps>> cycle() const override;
};


/// The step machine of `ParseImplDecl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseImplDecl: unbounded fn Ps -> ((ImplDecl, Ps))
struct ParseImplDecl : prism_rtl::Job<std::tuple<ast::ImplDecl, Ps>> {
    Ps p0;
    ParseImplDecl(Ps p0) : p0(std::move(p0)) {}
    prism_rtl::Turn<std::tuple<ast::ImplDecl, Ps>> cycle() const override;
};


/// The step machine of `ParseTraitItems`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseTraitItems: unbounded fn Ps -> (([TraitItem], Ps))
struct ParseTraitItems : prism_rtl::Job<std::tuple<Array<ast::TraitItem>, Ps>> {
    Ps p0;
    ParseTraitItems(Ps p0) : p0(std::move(p0)) {}
    prism_rtl::Turn<std::tuple<Array<ast::TraitItem>, Ps>> cycle() const override;
};


/// The step machine of `ParseTraitItem`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseTraitItem: unbounded fn Ps -> ((TraitItem, Ps))
struct ParseTraitItem : prism_rtl::Job<std::tuple<ast::TraitItem, Ps>> {
    Ps p_;
    ParseTraitItem(Ps p_) : p_(std::move(p_)) {}
    prism_rtl::Turn<std::tuple<ast::TraitItem, Ps>> cycle() const override;
};


/// The step machine of `OptionalType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// OptionalType: unbounded fn Ps -> ((?Type, Ps))
struct OptionalType : prism_rtl::Job<std::tuple<std::optional<ast::Type>, Ps>> {
    Ps p_;
    OptionalType(Ps p_) : p_(std::move(p_)) {}
    prism_rtl::Turn<std::tuple<std::optional<ast::Type>, Ps>> cycle() const override;
};


/// The step machine of `ParseExpr`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseExpr: unbounded fn Ps -> ((Expr, Ps))
struct ParseExpr : prism_rtl::Job<std::tuple<ast::Expr, Ps>> {
    Ps p_;
    ParseExpr(Ps p_) : p_(std::move(p_)) {}
    prism_rtl::Turn<std::tuple<ast::Expr, Ps>> cycle() const override;
};


/// The step machine of `ParseArgExpr`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseArgExpr: unbounded fn Ps -> ((Expr, Ps))
struct ParseArgExpr : prism_rtl::Job<std::tuple<ast::Expr, Ps>> {
    Ps p_;
    ParseArgExpr(Ps p_) : p_(std::move(p_)) {}
    prism_rtl::Turn<std::tuple<ast::Expr, Ps>> cycle() const override;
};


/// The step machine of `ParseExprCtx`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseExprCtx: unbounded fn Ps, Bool -> ((Expr, Ps))
struct ParseExprCtx : prism_rtl::Job<std::tuple<ast::Expr, Ps>> {
    Ps p_;
    bool commas_;
    ParseExprCtx(Ps p_, bool commas_) : p_(std::move(p_)), commas_(std::move(commas_)) {}
    prism_rtl::Turn<std::tuple<ast::Expr, Ps>> cycle() const override;
};


/// The step machine of `ParseRhsExpr`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseRhsExpr: unbounded fn Ps -> ((Expr, Ps))
struct ParseRhsExpr : prism_rtl::Job<std::tuple<ast::Expr, Ps>> {
    Ps p0;
    ParseRhsExpr(Ps p0) : p0(std::move(p0)) {}
    prism_rtl::Turn<std::tuple<ast::Expr, Ps>> cycle() const override;
};


/// The step machine of `ParseBinary`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseBinary: unbounded fn Ps, Nat, Bool -> ((Expr, Ps))
struct ParseBinary : prism_rtl::Job<std::tuple<ast::Expr, Ps>> {
    Ps p0;
    Nat min_;
    bool commas_;
    ParseBinary(Ps p0, Nat min_, bool commas_) : p0(std::move(p0)), min_(std::move(min_)), commas_(std::move(commas_)) {}
    prism_rtl::Turn<std::tuple<ast::Expr, Ps>> cycle() const override;
};


/// The step machine of `ClimbStep`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ClimbStep: unbounded fn Climb, Nat, Bool -> Climb
struct ClimbStep : prism_rtl::Job<Climb> {
    Climb c;
    Nat min_;
    bool commas_;
    ClimbStep(Climb c, Nat min_, bool commas_) : c(std::move(c)), min_(std::move(min_)), commas_(std::move(commas_)) {}
    prism_rtl::Turn<Climb> cycle() const override;
};


/// The step machine of `ParsePrefix`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParsePrefix: unbounded fn Ps, Nat, Bool -> ((Expr, Ps))
struct ParsePrefix : prism_rtl::Job<std::tuple<ast::Expr, Ps>> {
    Ps p_;
    Nat min_;
    bool commas_;
    ParsePrefix(Ps p_, Nat min_, bool commas_) : p_(std::move(p_)), min_(std::move(min_)), commas_(std::move(commas_)) {}
    prism_rtl::Turn<std::tuple<ast::Expr, Ps>> cycle() const override;
};


/// The step machine of `ParsePostfixExpr`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParsePostfixExpr: unbounded fn Ps, Bool -> ((Expr, Ps))
struct ParsePostfixExpr : prism_rtl::Job<std::tuple<ast::Expr, Ps>> {
    Ps p_;
    bool commas_;
    ParsePostfixExpr(Ps p_, bool commas_) : p_(std::move(p_)), commas_(std::move(commas_)) {}
    prism_rtl::Turn<std::tuple<ast::Expr, Ps>> cycle() const override;
};


/// The step machine of `ParsePostfix`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParsePostfix: unbounded fn Expr, Ps, Bool -> ((Expr, Ps))
struct ParsePostfix : prism_rtl::Job<std::tuple<ast::Expr, Ps>> {
    ast::Expr e0;
    Ps p0;
    bool commas_;
    ParsePostfix(ast::Expr e0, Ps p0, bool commas_) : e0(std::move(e0)), p0(std::move(p0)), commas_(std::move(commas_)) {}
    prism_rtl::Turn<std::tuple<ast::Expr, Ps>> cycle() const override;
};


/// The step machine of `PostfixStep`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PostfixStep: unbounded fn Expr, Ps, Bool -> ((Expr, Ps, Bool))
struct PostfixStep : prism_rtl::Job<std::tuple<ast::Expr, Ps, bool>> {
    ast::Expr e;
    Ps p_;
    bool commas_;
    PostfixStep(ast::Expr e, Ps p_, bool commas_) : e(std::move(e)), p_(std::move(p_)), commas_(std::move(commas_)) {}
    prism_rtl::Turn<std::tuple<ast::Expr, Ps, bool>> cycle() const override;
};


/// The step machine of `FieldOrMethod`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FieldOrMethod: unbounded fn Expr, Ps, Bool -> ((Expr, Ps, Bool))
struct FieldOrMethod : prism_rtl::Job<std::tuple<ast::Expr, Ps, bool>> {
    ast::Expr e;
    Ps p0;
    bool commas_;
    FieldOrMethod(ast::Expr e, Ps p0, bool commas_) : e(std::move(e)), p0(std::move(p0)), commas_(std::move(commas_)) {}
    prism_rtl::Turn<std::tuple<ast::Expr, Ps, bool>> cycle() const override;
};


/// The step machine of `ParseTypeArgs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseTypeArgs: unbounded fn Ps -> (([Type], Ps))
struct ParseTypeArgs : prism_rtl::Job<std::tuple<Array<ast::Type>, Ps>> {
    Ps p_;
    ParseTypeArgs(Ps p_) : p_(std::move(p_)) {}
    prism_rtl::Turn<std::tuple<Array<ast::Type>, Ps>> cycle() const override;
};


/// The step machine of `ParseCallArgs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseCallArgs: unbounded fn Ps, Bool -> (([Arg], Ps))
struct ParseCallArgs : prism_rtl::Job<std::tuple<Array<ast::Arg>, Ps>> {
    Ps p_;
    bool commas_;
    ParseCallArgs(Ps p_, bool commas_) : p_(std::move(p_)), commas_(std::move(commas_)) {}
    prism_rtl::Turn<std::tuple<Array<ast::Arg>, Ps>> cycle() const override;
};


/// The step machine of `ParseOneArg`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseOneArg: unbounded fn Ps -> (([Arg], Ps))
struct ParseOneArg : prism_rtl::Job<std::tuple<Array<ast::Arg>, Ps>> {
    Ps p_;
    ParseOneArg(Ps p_) : p_(std::move(p_)) {}
    prism_rtl::Turn<std::tuple<Array<ast::Arg>, Ps>> cycle() const override;
};


/// The step machine of `ParseArg`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseArg: unbounded fn Ps -> ((Arg, Ps))
struct ParseArg : prism_rtl::Job<std::tuple<ast::Arg, Ps>> {
    Ps p_;
    ParseArg(Ps p_) : p_(std::move(p_)) {}
    prism_rtl::Turn<std::tuple<ast::Arg, Ps>> cycle() const override;
};


/// The step machine of `ParseParenArgs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseParenArgs: unbounded fn Ps -> (([Arg], Bool, Ps))
struct ParseParenArgs : prism_rtl::Job<std::tuple<Array<ast::Arg>, bool, Ps>> {
    Ps p0;
    ParseParenArgs(Ps p0) : p0(std::move(p0)) {}
    prism_rtl::Turn<std::tuple<Array<ast::Arg>, bool, Ps>> cycle() const override;
};


/// The step machine of `ParsePrimary`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParsePrimary: unbounded fn Ps, Bool -> ((Expr, Bool, Ps))
struct ParsePrimary : prism_rtl::Job<std::tuple<ast::Expr, bool, Ps>> {
    Ps p_;
    bool commas_;
    ParsePrimary(Ps p_, bool commas_) : p_(std::move(p_)), commas_(std::move(commas_)) {}
    prism_rtl::Turn<std::tuple<ast::Expr, bool, Ps>> cycle() const override;
};


/// The step machine of `LiteralPrimary`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LiteralPrimary: unbounded fn Ps -> ((Expr, Bool, Ps))
struct LiteralPrimary : prism_rtl::Job<std::tuple<ast::Expr, bool, Ps>> {
    Ps p_;
    LiteralPrimary(Ps p_) : p_(std::move(p_)) {}
    prism_rtl::Turn<std::tuple<ast::Expr, bool, Ps>> cycle() const override;
};


/// The step machine of `NamePrimary`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// NamePrimary: unbounded fn Ps, NameTok, Bool -> ((Expr, Bool, Ps))
struct NamePrimary : prism_rtl::Job<std::tuple<ast::Expr, bool, Ps>> {
    Ps p0;
    lexer::NameTok n;
    bool commas_;
    NamePrimary(Ps p0, lexer::NameTok n, bool commas_) : p0(std::move(p0)), n(std::move(n)), commas_(std::move(commas_)) {}
    prism_rtl::Turn<std::tuple<ast::Expr, bool, Ps>> cycle() const override;
};


/// The step machine of `TypeArgsOn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TypeArgsOn: unbounded fn Expr, Ps, Range -> ((Expr, Ps))
struct TypeArgsOn : prism_rtl::Job<std::tuple<ast::Expr, Ps>> {
    ast::Expr e;
    Ps p_;
    ast::Range start;
    TypeArgsOn(ast::Expr e, Ps p_, ast::Range start) : e(std::move(e)), p_(std::move(p_)), start(std::move(start)) {}
    prism_rtl::Turn<std::tuple<ast::Expr, Ps>> cycle() const override;
};


/// The step machine of `ParenPrimary`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParenPrimary: unbounded fn Ps -> ((Expr, Bool, Ps))
struct ParenPrimary : prism_rtl::Job<std::tuple<ast::Expr, bool, Ps>> {
    Ps p_;
    ParenPrimary(Ps p_) : p_(std::move(p_)) {}
    prism_rtl::Turn<std::tuple<ast::Expr, bool, Ps>> cycle() const override;
};


/// The step machine of `SquarePrimary`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SquarePrimary: unbounded fn Ps -> ((Expr, Bool, Ps))
struct SquarePrimary : prism_rtl::Job<std::tuple<ast::Expr, bool, Ps>> {
    Ps p_;
    SquarePrimary(Ps p_) : p_(std::move(p_)) {}
    prism_rtl::Turn<std::tuple<ast::Expr, bool, Ps>> cycle() const override;
};


/// The step machine of `MapPrimary`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// MapPrimary: unbounded fn Ps -> ((Expr, Bool, Ps))
struct MapPrimary : prism_rtl::Job<std::tuple<ast::Expr, bool, Ps>> {
    Ps p_;
    MapPrimary(Ps p_) : p_(std::move(p_)) {}
    prism_rtl::Turn<std::tuple<ast::Expr, bool, Ps>> cycle() const override;
};


/// The step machine of `ParseMapEntry`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseMapEntry: unbounded fn Ps -> ((((Expr, Expr)), Ps))
struct ParseMapEntry : prism_rtl::Job<std::tuple<std::tuple<ast::Expr, ast::Expr>, Ps>> {
    Ps p_;
    ParseMapEntry(Ps p_) : p_(std::move(p_)) {}
    prism_rtl::Turn<std::tuple<std::tuple<ast::Expr, ast::Expr>, Ps>> cycle() const override;
};


/// The step machine of `LensPrimary`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LensPrimary: unbounded fn Ps -> ((Expr, Bool, Ps))
struct LensPrimary : prism_rtl::Job<std::tuple<ast::Expr, bool, Ps>> {
    Ps p0;
    LensPrimary(Ps p0) : p0(std::move(p0)) {}
    prism_rtl::Turn<std::tuple<ast::Expr, bool, Ps>> cycle() const override;
};


/// The step machine of `KeywordPrimary`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// KeywordPrimary: unbounded fn Ps, Text, Text, Bool -> ((Expr, Bool, Ps))
struct KeywordPrimary : prism_rtl::Job<std::tuple<ast::Expr, bool, Ps>> {
    Ps p_;
    Text w;
    Text sigils;
    bool commas_;
    KeywordPrimary(Ps p_, Text w, Text sigils, bool commas_) : p_(std::move(p_)), w(std::move(w)), sigils(std::move(sigils)), commas_(std::move(commas_)) {}
    prism_rtl::Turn<std::tuple<ast::Expr, bool, Ps>> cycle() const override;
};


/// The step machine of `ParseLiteral`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseLiteral: unbounded fn Ps -> ((Literal, Ps))
struct ParseLiteral : prism_rtl::Job<std::tuple<ast::Literal, Ps>> {
    Ps p_;
    ParseLiteral(Ps p_) : p_(std::move(p_)) {}
    prism_rtl::Turn<std::tuple<ast::Literal, Ps>> cycle() const override;
};


/// The step machine of `TextSegment`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TextSegment: unbounded fn [TextSeg], Ps, TextSegTok -> (([TextSeg], Ps))
struct TextSegment : prism_rtl::Job<std::tuple<Array<ast::TextSeg>, Ps>> {
    Array<ast::TextSeg> acc;
    Ps p_;
    lexer::TextSegTok text_seg_tok2;
    TextSegment(Array<ast::TextSeg> acc, Ps p_, lexer::TextSegTok text_seg_tok2) : acc(std::move(acc)), p_(std::move(p_)), text_seg_tok2(std::move(text_seg_tok2)) {}
    prism_rtl::Turn<std::tuple<Array<ast::TextSeg>, Ps>> cycle() const override;
};


/// The step machine of `ParseNested`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseNested: unbounded fn Ps, [Tok], Range -> ((Expr, Ps))
struct ParseNested : prism_rtl::Job<std::tuple<ast::Expr, Ps>> {
    Ps p_;
    Array<lexer::Tok> toks;
    ast::Range span;
    ParseNested(Ps p_, Array<lexer::Tok> toks, ast::Range span) : p_(std::move(p_)), toks(std::move(toks)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<ast::Expr, Ps>> cycle() const override;
};


/// The step machine of `ParseTemplate`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseTemplate: unbounded fn Ps, TemplateTok, Range -> ((Template, Ps))
struct ParseTemplate : prism_rtl::Job<std::tuple<ast::Template, Ps>> {
    Ps p0;
    lexer::TemplateTok t;
    ast::Range span;
    ParseTemplate(Ps p0, lexer::TemplateTok t, ast::Range span) : p0(std::move(p0)), t(std::move(t)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<ast::Template, Ps>> cycle() const override;
};


/// The step machine of `TemplateParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TemplateParts: unbounded fn Ps, [TPartTok] -> (([TemplatePart], Ps))
struct TemplateParts : prism_rtl::Job<std::tuple<Array<ast::TemplatePart>, Ps>> {
    Ps p_;
    Array<lexer::TPartTok> parts;
    TemplateParts(Ps p_, Array<lexer::TPartTok> parts) : p_(std::move(p_)), parts(std::move(parts)) {}
    prism_rtl::Turn<std::tuple<Array<ast::TemplatePart>, Ps>> cycle() const override;
};


/// The step machine of `TemplatePartOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TemplatePartOf: unbounded fn [TemplatePart], Ps, TPartTok -> (([TemplatePart], Ps))
struct TemplatePartOf : prism_rtl::Job<std::tuple<Array<ast::TemplatePart>, Ps>> {
    Array<ast::TemplatePart> acc;
    Ps p_;
    lexer::TPartTok tpart_tok2;
    TemplatePartOf(Array<ast::TemplatePart> acc, Ps p_, lexer::TPartTok tpart_tok2) : acc(std::move(acc)), p_(std::move(p_)), tpart_tok2(std::move(tpart_tok2)) {}
    prism_rtl::Turn<std::tuple<Array<ast::TemplatePart>, Ps>> cycle() const override;
};


/// The step machine of `AttrArg`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// AttrArg: unbounded fn [Arg], Ps, AttrTok -> (([Arg], Ps))
struct AttrArg : prism_rtl::Job<std::tuple<Array<ast::Arg>, Ps>> {
    Array<ast::Arg> done;
    Ps p_;
    lexer::AttrTok a;
    AttrArg(Array<ast::Arg> done, Ps p_, lexer::AttrTok a) : done(std::move(done)), p_(std::move(p_)), a(std::move(a)) {}
    prism_rtl::Turn<std::tuple<Array<ast::Arg>, Ps>> cycle() const override;
};


/// The step machine of `ParseLambda`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseLambda: unbounded fn Ps -> ((Expr, Ps))
struct ParseLambda : prism_rtl::Job<std::tuple<ast::Expr, Ps>> {
    Ps p0;
    ParseLambda(Ps p0) : p0(std::move(p0)) {}
    prism_rtl::Turn<std::tuple<ast::Expr, Ps>> cycle() const override;
};


/// The step machine of `LambdaParams`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LambdaParams: unbounded fn Ps -> ((?[Pattern], Ps))
struct LambdaParams : prism_rtl::Job<std::tuple<std::optional<Array<ast::Pattern_>>, Ps>> {
    Ps p_;
    LambdaParams(Ps p_) : p_(std::move(p_)) {}
    prism_rtl::Turn<std::tuple<std::optional<Array<ast::Pattern_>>, Ps>> cycle() const override;
};


/// The step machine of `ParseCond`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseCond: unbounded fn Ps, Bool -> ((Cond, Ps))
struct ParseCond : prism_rtl::Job<std::tuple<ast::Cond, Ps>> {
    Ps p_;
    bool allow_guard;
    ParseCond(Ps p_, bool allow_guard) : p_(std::move(p_)), allow_guard(std::move(allow_guard)) {}
    prism_rtl::Turn<std::tuple<ast::Cond, Ps>> cycle() const override;
};


/// The step machine of `ParseIf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseIf: unbounded fn Ps -> ((Expr, Ps))
struct ParseIf : prism_rtl::Job<std::tuple<ast::Expr, Ps>> {
    Ps p0;
    ParseIf(Ps p0) : p0(std::move(p0)) {}
    prism_rtl::Turn<std::tuple<ast::Expr, Ps>> cycle() const override;
};


/// The step machine of `ParseMatch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseMatch: unbounded fn Ps -> ((Expr, Ps))
struct ParseMatch : prism_rtl::Job<std::tuple<ast::Expr, Ps>> {
    Ps p0;
    ParseMatch(Ps p0) : p0(std::move(p0)) {}
    prism_rtl::Turn<std::tuple<ast::Expr, Ps>> cycle() const override;
};


/// The step machine of `MatchArms`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// MatchArms: unbounded fn Ps -> (([Arm], Ps))
struct MatchArms : prism_rtl::Job<std::tuple<Array<ast::Arm>, Ps>> {
    Ps p0;
    MatchArms(Ps p0) : p0(std::move(p0)) {}
    prism_rtl::Turn<std::tuple<Array<ast::Arm>, Ps>> cycle() const override;
};


/// The step machine of `ParseFor`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseFor: unbounded fn Ps -> ((Expr, Ps))
struct ParseFor : prism_rtl::Job<std::tuple<ast::Expr, Ps>> {
    Ps p0;
    ParseFor(Ps p0) : p0(std::move(p0)) {}
    prism_rtl::Turn<std::tuple<ast::Expr, Ps>> cycle() const override;
};


/// The step machine of `ForBindersOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ForBindersOf: unbounded fn Ps -> ((?ForBinders, Ps))
struct ForBindersOf : prism_rtl::Job<std::tuple<std::optional<ast::ForBinders>, Ps>> {
    Ps p_;
    ForBindersOf(Ps p_) : p_(std::move(p_)) {}
    prism_rtl::Turn<std::tuple<std::optional<ast::ForBinders>, Ps>> cycle() const override;
};


/// The step machine of `ParseBlockAfterColon`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseBlockAfterColon: unbounded fn Ps -> ((Block, Ps))
struct ParseBlockAfterColon : prism_rtl::Job<std::tuple<ast::Block, Ps>> {
    Ps p0;
    ParseBlockAfterColon(Ps p0) : p0(std::move(p0)) {}
    prism_rtl::Turn<std::tuple<ast::Block, Ps>> cycle() const override;
};


/// The step machine of `ParseIndentedBlock`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseIndentedBlock: unbounded fn Ps -> ((Block, Ps))
struct ParseIndentedBlock : prism_rtl::Job<std::tuple<ast::Block, Ps>> {
    Ps p0;
    ParseIndentedBlock(Ps p0) : p0(std::move(p0)) {}
    prism_rtl::Turn<std::tuple<ast::Block, Ps>> cycle() const override;
};


/// The step machine of `ParseBlockUntilEof`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseBlockUntilEof: unbounded fn Ps, Range -> ((Block, Ps))
struct ParseBlockUntilEof : prism_rtl::Job<std::tuple<ast::Block, Ps>> {
    Ps p_;
    ast::Range span;
    ParseBlockUntilEof(Ps p_, ast::Range span) : p_(std::move(p_)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<ast::Block, Ps>> cycle() const override;
};


/// The step machine of `StmtsUntil`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// StmtsUntil: unbounded fn Ps, Bool -> (([Stmt], Ps))
struct StmtsUntil : prism_rtl::Job<std::tuple<Array<ast::Stmt>, Ps>> {
    Ps p0;
    bool indented;
    StmtsUntil(Ps p0, bool indented) : p0(std::move(p0)), indented(std::move(indented)) {}
    prism_rtl::Turn<std::tuple<Array<ast::Stmt>, Ps>> cycle() const override;
};


/// The step machine of `ParseStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseStmt: unbounded fn Ps -> ((Stmt, Ps))
struct ParseStmt : prism_rtl::Job<std::tuple<ast::Stmt, Ps>> {
    Ps p_;
    ParseStmt(Ps p_) : p_(std::move(p_)) {}
    prism_rtl::Turn<std::tuple<ast::Stmt, Ps>> cycle() const override;
};


/// The step machine of `StmtKindOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// StmtKindOf: unbounded fn Ps, Range -> ((StmtKind, Ps))
struct StmtKindOf : prism_rtl::Job<std::tuple<ast::StmtKind, Ps>> {
    Ps p_;
    ast::Range start;
    StmtKindOf(Ps p_, ast::Range start) : p_(std::move(p_)), start(std::move(start)) {}
    prism_rtl::Turn<std::tuple<ast::StmtKind, Ps>> cycle() const override;
};


/// The step machine of `OtherStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// OtherStmt: unbounded fn Ps -> ((StmtKind, Ps))
struct OtherStmt : prism_rtl::Job<std::tuple<ast::StmtKind, Ps>> {
    Ps p_;
    OtherStmt(Ps p_) : p_(std::move(p_)) {}
    prism_rtl::Turn<std::tuple<ast::StmtKind, Ps>> cycle() const override;
};


/// The step machine of `OptionalRhs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// OptionalRhs: unbounded fn Ps -> ((?Expr, Ps))
struct OptionalRhs : prism_rtl::Job<std::tuple<std::optional<ast::Expr>, Ps>> {
    Ps p_;
    OptionalRhs(Ps p_) : p_(std::move(p_)) {}
    prism_rtl::Turn<std::tuple<std::optional<ast::Expr>, Ps>> cycle() const override;
};


/// The step machine of `ParseUpdateStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseUpdateStmt: unbounded fn Ps -> ((StmtKind, Ps))
struct ParseUpdateStmt : prism_rtl::Job<std::tuple<ast::StmtKind, Ps>> {
    Ps p_;
    ParseUpdateStmt(Ps p_) : p_(std::move(p_)) {}
    prism_rtl::Turn<std::tuple<ast::StmtKind, Ps>> cycle() const override;
};


/// The step machine of `ParseReference`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseReference: unbounded fn Ps -> ((Expr, Ps))
struct ParseReference : prism_rtl::Job<std::tuple<ast::Expr, Ps>> {
    Ps p_;
    ParseReference(Ps p_) : p_(std::move(p_)) {}
    prism_rtl::Turn<std::tuple<ast::Expr, Ps>> cycle() const override;
};


/// The step machine of `ParseType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseType: unbounded fn Ps -> ((Type, Ps))
struct ParseType : prism_rtl::Job<std::tuple<ast::Type, Ps>> {
    Ps p_;
    ParseType(Ps p_) : p_(std::move(p_)) {}
    prism_rtl::Turn<std::tuple<ast::Type, Ps>> cycle() const override;
};


/// The step machine of `ParseEmitType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseEmitType: unbounded fn Ps -> ((Type, Ps))
struct ParseEmitType : prism_rtl::Job<std::tuple<ast::Type, Ps>> {
    Ps p_;
    ParseEmitType(Ps p_) : p_(std::move(p_)) {}
    prism_rtl::Turn<std::tuple<ast::Type, Ps>> cycle() const override;
};


/// The step machine of `ParseUnionType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseUnionType: unbounded fn Ps -> ((Type, Ps))
struct ParseUnionType : prism_rtl::Job<std::tuple<ast::Type, Ps>> {
    Ps p_;
    ParseUnionType(Ps p_) : p_(std::move(p_)) {}
    prism_rtl::Turn<std::tuple<ast::Type, Ps>> cycle() const override;
};


/// The step machine of `ParseMapType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseMapType: unbounded fn Ps -> ((Type, Ps))
struct ParseMapType : prism_rtl::Job<std::tuple<ast::Type, Ps>> {
    Ps p_;
    ParseMapType(Ps p_) : p_(std::move(p_)) {}
    prism_rtl::Turn<std::tuple<ast::Type, Ps>> cycle() const override;
};


/// The step machine of `ParseSigiledType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseSigiledType: unbounded fn Ps -> ((Type, Ps))
struct ParseSigiledType : prism_rtl::Job<std::tuple<ast::Type, Ps>> {
    Ps p_;
    ParseSigiledType(Ps p_) : p_(std::move(p_)) {}
    prism_rtl::Turn<std::tuple<ast::Type, Ps>> cycle() const override;
};


/// The step machine of `ParseAppType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseAppType: unbounded fn Ps -> ((Type, Ps))
struct ParseAppType : prism_rtl::Job<std::tuple<ast::Type, Ps>> {
    Ps p_;
    ParseAppType(Ps p_) : p_(std::move(p_)) {}
    prism_rtl::Turn<std::tuple<ast::Type, Ps>> cycle() const override;
};


/// The step machine of `ParseTypeAtom`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseTypeAtom: unbounded fn Ps -> ((Type, Ps))
struct ParseTypeAtom : prism_rtl::Job<std::tuple<ast::Type, Ps>> {
    Ps p_;
    ParseTypeAtom(Ps p_) : p_(std::move(p_)) {}
    prism_rtl::Turn<std::tuple<ast::Type, Ps>> cycle() const override;
};


/// The step machine of `TypeAtomBody`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TypeAtomBody: unbounded fn Ps, Range -> ((Type, Ps))
struct TypeAtomBody : prism_rtl::Job<std::tuple<ast::Type, Ps>> {
    Ps p_;
    ast::Range start;
    TypeAtomBody(Ps p_, ast::Range start) : p_(std::move(p_)), start(std::move(start)) {}
    prism_rtl::Turn<std::tuple<ast::Type, Ps>> cycle() const override;
};


/// The step machine of `ParseBounds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseBounds: unbounded fn Ps -> (([Bound], Ps))
struct ParseBounds : prism_rtl::Job<std::tuple<Array<ast::Bound>, Ps>> {
    Ps p0;
    ParseBounds(Ps p0) : p0(std::move(p0)) {}
    prism_rtl::Turn<std::tuple<Array<ast::Bound>, Ps>> cycle() const override;
};


/// The step machine of `ParseBound`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseBound: unbounded fn Ps -> ((Bound, Ps))
struct ParseBound : prism_rtl::Job<std::tuple<ast::Bound, Ps>> {
    Ps p_;
    ParseBound(Ps p_) : p_(std::move(p_)) {}
    prism_rtl::Turn<std::tuple<ast::Bound, Ps>> cycle() const override;
};


/// The step machine of `ParseRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseRow: unbounded fn Ps -> ((Row, Ps))
struct ParseRow : prism_rtl::Job<std::tuple<ast::Row_, Ps>> {
    Ps p_;
    ParseRow(Ps p_) : p_(std::move(p_)) {}
    prism_rtl::Turn<std::tuple<ast::Row_, Ps>> cycle() const override;
};


/// The step machine of `ParseRowTerm`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseRowTerm: unbounded fn Ps -> ((RowTerm, Ps))
struct ParseRowTerm : prism_rtl::Job<std::tuple<ast::RowTerm, Ps>> {
    Ps p_;
    ParseRowTerm(Ps p_) : p_(std::move(p_)) {}
    prism_rtl::Turn<std::tuple<ast::RowTerm, Ps>> cycle() const override;
};


/// The step machine of `ParsePattern`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParsePattern: unbounded fn Ps, Bool -> ((Pattern, Ps))
struct ParsePattern : prism_rtl::Job<std::tuple<ast::Pattern_, Ps>> {
    Ps p_;
    bool commas0;
    ParsePattern(Ps p_, bool commas0) : p_(std::move(p_)), commas0(std::move(commas0)) {}
    prism_rtl::Turn<std::tuple<ast::Pattern_, Ps>> cycle() const override;
};


/// The step machine of `LiteralPattern`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LiteralPattern: unbounded fn Ps -> ((Pattern, Ps))
struct LiteralPattern : prism_rtl::Job<std::tuple<ast::Pattern_, Ps>> {
    Ps p_;
    LiteralPattern(Ps p_) : p_(std::move(p_)) {}
    prism_rtl::Turn<std::tuple<ast::Pattern_, Ps>> cycle() const override;
};


/// The step machine of `NamePattern`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// NamePattern: unbounded fn Ps, NameTok, Bool -> ((Pattern, Ps))
struct NamePattern : prism_rtl::Job<std::tuple<ast::Pattern_, Ps>> {
    Ps p0;
    lexer::NameTok n;
    bool commas_;
    NamePattern(Ps p0, lexer::NameTok n, bool commas_) : p0(std::move(p0)), n(std::move(n)), commas_(std::move(commas_)) {}
    prism_rtl::Turn<std::tuple<ast::Pattern_, Ps>> cycle() const override;
};


/// The step machine of `ParseRecordPattern`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseRecordPattern: unbounded fn Ps, SName -> ((Pattern, Ps))
struct ParseRecordPattern : prism_rtl::Job<std::tuple<ast::Pattern_, Ps>> {
    Ps p0;
    ast::SName name;
    ParseRecordPattern(Ps p0, ast::SName name) : p0(std::move(p0)), name(std::move(name)) {}
    prism_rtl::Turn<std::tuple<ast::Pattern_, Ps>> cycle() const override;
};


/// The step machine of `ParseCheckDecl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseCheckDecl: unbounded fn Ps -> ((CheckDecl, Ps))
struct ParseCheckDecl : prism_rtl::Job<std::tuple<ast::CheckDecl, Ps>> {
    Ps p0;
    ParseCheckDecl(Ps p0) : p0(std::move(p0)) {}
    prism_rtl::Turn<std::tuple<ast::CheckDecl, Ps>> cycle() const override;
};


/// The step machine of `ParseCheckLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseCheckLine: unbounded fn Ps -> ((CheckLine, Ps))
struct ParseCheckLine : prism_rtl::Job<std::tuple<ast::CheckLine, Ps>> {
    Ps p_;
    ParseCheckLine(Ps p_) : p_(std::move(p_)) {}
    prism_rtl::Turn<std::tuple<ast::CheckLine, Ps>> cycle() const override;
};


/// The step machine of `OptionalPatternTop`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// OptionalPatternTop: unbounded fn Ps -> ((?Pattern, Ps))
struct OptionalPatternTop : prism_rtl::Job<std::tuple<std::optional<ast::Pattern_>, Ps>> {
    Ps p_;
    OptionalPatternTop(Ps p_) : p_(std::move(p_)) {}
    prism_rtl::Turn<std::tuple<std::optional<ast::Pattern_>, Ps>> cycle() const override;
};


/// The step machine of `ParseTestDecl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseTestDecl: unbounded fn Ps -> ((TestDecl, Ps))
struct ParseTestDecl : prism_rtl::Job<std::tuple<ast::TestDecl, Ps>> {
    Ps p0;
    ParseTestDecl(Ps p0) : p0(std::move(p0)) {}
    prism_rtl::Turn<std::tuple<ast::TestDecl, Ps>> cycle() const override;
};


/// The step machine of `StepIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// StepIn: unbounded fn Ps, Bool -> ((TestStep, Ps))
struct StepIn : prism_rtl::Job<std::tuple<ast::TestStep, Ps>> {
    Ps p_;
    bool saved;
    StepIn(Ps p_, bool saved) : p_(std::move(p_)), saved(std::move(saved)) {}
    prism_rtl::Turn<std::tuple<ast::TestStep, Ps>> cycle() const override;
};


/// The step machine of `ParseTestCheck`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParseTestCheck: unbounded fn Ps -> ((TestCheck, Ps))
struct ParseTestCheck : prism_rtl::Job<std::tuple<ast::TestCheck, Ps>> {
    Ps p0;
    ParseTestCheck(Ps p0) : p0(std::move(p0)) {}
    prism_rtl::Turn<std::tuple<ast::TestCheck, Ps>> cycle() const override;
};


/// The step machine of `CheckKindOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CheckKindOf: unbounded fn Ps, Text -> ((TestCheckKind, Ps))
struct CheckKindOf : prism_rtl::Job<std::tuple<ast::TestCheckKind, Ps>> {
    Ps p_;
    Text word;
    CheckKindOf(Ps p_, Text word) : p_(std::move(p_)), word(std::move(word)) {}
    prism_rtl::Turn<std::tuple<ast::TestCheckKind, Ps>> cycle() const override;
};


/// The step machine of `OnePattern`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// OnePattern: unbounded fn Ps, (fn Pattern -> TestCheckKind) -> ((TestCheckKind, Ps))
struct OnePattern : prism_rtl::Job<std::tuple<ast::TestCheckKind, Ps>> {
    Ps p_;
    prism_rtl::Fn<prism_rtl::JobRef<ast::TestCheckKind>(ast::Pattern_)> make_fn;
    OnePattern(Ps p_, prism_rtl::Fn<prism_rtl::JobRef<ast::TestCheckKind>(ast::Pattern_)> make_fn) : p_(std::move(p_)), make_fn(std::move(make_fn)) {}
    prism_rtl::Turn<std::tuple<ast::TestCheckKind, Ps>> cycle() const override;
};


}  // namespace parser

}  // namespace crate
