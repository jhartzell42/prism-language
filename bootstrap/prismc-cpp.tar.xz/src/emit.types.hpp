// The module `Emit`: its records, tags and newtypes (each after the types it holds) and its
// choices' cases, emitted by prismc (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include "emit.decl.hpp"
#include "elem.decl.hpp"
#include "ast.decl.hpp"
#include "check_env.decl.hpp"
#include "check_errors.decl.hpp"
#include "check_types.decl.hpp"
#include "lexer.decl.hpp"
#include "lower.decl.hpp"
#include "prelude_template.decl.hpp"
#include "rust_templates.decl.hpp"
#include "typed.decl.hpp"

namespace crate {

using namespace prelude;



}  // namespace crate
