// The module `Check.Blocks`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <check/blocks/module.hpp>
#include <check/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>

// The module `Check.Blocks`, from `target/bootstrap/cpp-src/prismc/check/blocks/mod.prism`.
namespace crate::check::blocks {

/// GroupOrder: unbounded fn [Stmt] -> [Nat]
Array<Nat> group_order_f(const Array<crate::syntax::Stmt>& stmts_p0) {
    auto all_p1 = crate::check::errors::range0_f(crate::prelude::len(stmts_p0));
    auto holds_p2 = crate::prelude::filter(all_p1, [&](const Nat& i_p6) { return is_hold_f(crate::prelude::or_(crate::prelude::index(stmts_p0, i_p6), dummy_stmt2_p())); });
    auto lets_p3 = crate::prelude::filter(all_p1, [&](const Nat& i_p7) { return is_let_like_f(crate::prelude::or_(crate::prelude::index(stmts_p0, i_p7), dummy_stmt2_p())); });
    auto rest_p4 = crate::prelude::filter(all_p1, [&](const Nat& i_p8) { return (!is_hold_f(crate::prelude::or_(crate::prelude::index(stmts_p0, i_p8), dummy_stmt2_p()))) && (!is_let_like_f(crate::prelude::or_(crate::prelude::index(stmts_p0, i_p8), dummy_stmt2_p()))); });
    auto ordered_p5 = crate::prelude::fold(dep_order_f(crate::prelude::each(rest_p4, [&](const Nat& i_p9) { return crate::prelude::or_(crate::prelude::index(stmts_p0, i_p9), dummy_stmt2_p()); })), Array<Nat>{}, [&](const Array<Nat>& acc_pa, const Array<Nat>& comp_pb) { return crate::prelude::append(acc_pa, crate::prelude::each(comp_pb, [&](const Nat& j_pc) { return crate::prelude::or_(crate::prelude::index(rest_p4, j_pc), Nat(0u)); })); });
    return crate::prelude::append(crate::prelude::append(holds_p2, lets_p3), ordered_p5);
}


prism_rtl::Turn<Array<Nat>> GroupOrder::cycle() const {
    const auto& stmts_p0 = this->stmts_p0;
    auto all_p1 = crate::check::errors::range0_f(crate::prelude::len(stmts_p0));
    auto holds_p2 = crate::prelude::filter(all_p1, [&](const Nat& i_p6) { return is_hold_f(crate::prelude::or_(crate::prelude::index(stmts_p0, i_p6), dummy_stmt2_p())); });
    auto lets_p3 = crate::prelude::filter(all_p1, [&](const Nat& i_p7) { return is_let_like_f(crate::prelude::or_(crate::prelude::index(stmts_p0, i_p7), dummy_stmt2_p())); });
    auto rest_p4 = crate::prelude::filter(all_p1, [&](const Nat& i_p8) { return (!is_hold_f(crate::prelude::or_(crate::prelude::index(stmts_p0, i_p8), dummy_stmt2_p()))) && (!is_let_like_f(crate::prelude::or_(crate::prelude::index(stmts_p0, i_p8), dummy_stmt2_p()))); });
    auto stmts_p0x = stmts_p0;
    return crate::prelude::call_then(start_dep_order_f(crate::prelude::each(rest_p4, [&](const Nat& i_p9) { return crate::prelude::or_(crate::prelude::index(stmts_p0x, i_p9), dummy_stmt2_p()); })), [=](Array<Array<Nat>> dep_order_f_2397) {
        return ({
            auto ordered_p5 = crate::prelude::fold(dep_order_f_2397, Array<Nat>{}, [&](const Array<Nat>& acc_pa, const Array<Nat>& comp_pb) { return crate::prelude::append(acc_pa, crate::prelude::each(comp_pb, [&](const Nat& j_pc) { return crate::prelude::or_(crate::prelude::index(rest_p4, j_pc), Nat(0u)); })); });
            (prism_rtl::finished(crate::prelude::append(crate::prelude::append(holds_p2, lets_p3), ordered_p5)));
        });
    });
}


/// `Start GroupOrder, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Nat>> start_group_order_f(Array<crate::syntax::Stmt> stmts_p0) {
    return prism_rtl::make_rc<GroupOrder>(stmts_p0);
}


/// WidgetGroupOrder: unbounded fn [Stmt] -> [Nat]
Array<Nat> widget_group_order_f(const Array<crate::syntax::Stmt>& stmts_p0) {
    return crate::prelude::fold(dep_order_f(stmts_p0), Array<Nat>{}, [&](const Array<Nat>& acc_p1, const Array<Nat>& comp_p2) {
        return ({
            auto holds_p3 = crate::prelude::filter(comp_p2, [&](const Nat& i_p6) { return is_hold_f(crate::prelude::or_(crate::prelude::index(stmts_p0, i_p6), dummy_stmt2_p())); });
            auto lets_p4 = crate::prelude::filter(comp_p2, [&](const Nat& i_p7) { return is_let_like_f(crate::prelude::or_(crate::prelude::index(stmts_p0, i_p7), dummy_stmt2_p())); });
            auto rest_p5 = crate::prelude::filter(comp_p2, [&](const Nat& i_p8) { return (!is_hold_f(crate::prelude::or_(crate::prelude::index(stmts_p0, i_p8), dummy_stmt2_p()))) && (!is_let_like_f(crate::prelude::or_(crate::prelude::index(stmts_p0, i_p8), dummy_stmt2_p()))); });
            (crate::prelude::append(acc_p1, crate::prelude::append(crate::prelude::append(holds_p3, lets_p4), rest_p5)));
        });
    });
}


prism_rtl::Turn<Array<Nat>> WidgetGroupOrder::cycle() const {
    const auto& stmts_p0 = this->stmts_p0;
    auto stmts_p0x = stmts_p0;
    return crate::prelude::call_then(start_dep_order_f(stmts_p0x), [=](Array<Array<Nat>> dep_order_f_3154) {
        return prism_rtl::finished(crate::prelude::fold(dep_order_f_3154, Array<Nat>{}, [&](const Array<Nat>& acc_p1, const Array<Nat>& comp_p2) {
            return ({
                auto holds_p3 = crate::prelude::filter(comp_p2, [&](const Nat& i_p6) { return is_hold_f(crate::prelude::or_(crate::prelude::index(stmts_p0x, i_p6), dummy_stmt2_p())); });
                auto lets_p4 = crate::prelude::filter(comp_p2, [&](const Nat& i_p7) { return is_let_like_f(crate::prelude::or_(crate::prelude::index(stmts_p0x, i_p7), dummy_stmt2_p())); });
                auto rest_p5 = crate::prelude::filter(comp_p2, [&](const Nat& i_p8) { return (!is_hold_f(crate::prelude::or_(crate::prelude::index(stmts_p0x, i_p8), dummy_stmt2_p()))) && (!is_let_like_f(crate::prelude::or_(crate::prelude::index(stmts_p0x, i_p8), dummy_stmt2_p()))); });
                (crate::prelude::append(acc_p1, crate::prelude::append(crate::prelude::append(holds_p3, lets_p4), rest_p5)));
            });
        }));
    });
}


/// `Start WidgetGroupOrder, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Nat>> start_widget_group_order_f(Array<crate::syntax::Stmt> stmts_p0) {
    return prism_rtl::make_rc<WidgetGroupOrder>(stmts_p0);
}


/// DepOrder: unbounded fn [Stmt] -> [ [Nat] ]
Array<Array<Nat>> dep_order_f(const Array<crate::syntax::Stmt>& stmts_p0) {
    auto n_p1 = crate::prelude::len(stmts_p0);
    auto defs_p2 = crate::prelude::run_to_end(crate::prelude::each_job(stmts_p0, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(crate::syntax::Stmt)>>(prism_rtl::rc([=](crate::syntax::Stmt p0) {
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto s_p7 = p0;
                (prism_rtl::more(prism_rtl::rc(GroupDefs(s_p7))));
            });
        }));
    }))));
    auto uses_p3 = crate::prelude::run_to_end(crate::prelude::each_job(stmts_p0, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(crate::syntax::Stmt)>>(prism_rtl::rc([=](crate::syntax::Stmt p0) {
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto s_p8 = p0;
                (prism_rtl::more(prism_rtl::rc(crate::check::shrink::locals::NamesInStmt(s_p8))));
            });
        }));
    }))));
    auto deps_p4 = crate::prelude::each(crate::check::errors::range0_f(n_p1), [&](const Nat& i_p9) { return crate::prelude::filter(crate::check::errors::range0_f(n_p1), [&](const Nat& j_pa) { return crate::prelude::fold(crate::prelude::or_(crate::prelude::index(defs_p2, j_pa), Array<Text>{}), false, [&](const bool& seen_pb, const Text& d_pc) { return prism_rtl::deref(seen_pb) || crate::check::types::has_text_f(crate::prelude::or_(crate::prelude::index(uses_p3, i_p9), Array<Text>{}), d_pc); }); }); });
    auto reach_p5 = crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(n_p1), ({
        auto deps_p4x = deps_p4;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(Nat)>>(prism_rtl::rc([=, deps_p4x = std::move(deps_p4x)](Nat p0) {
        return ({
            auto deps_p4xy = deps_p4x;
            (crate::prelude::entered(crate::prelude::once_job([=, deps_p4xy = std::move(deps_p4xy)]() {
            return ({
                auto i_pd = p0;
                (prism_rtl::more(prism_rtl::rc(ReachIdx(deps_p4xy, crate::prelude::or_(crate::prelude::index(deps_p4xy, i_pd), Array<Nat>{}), Array<Nat>{}))));
            });
        })));
        });
    })));
    })));
    auto comps_p6 = crate::prelude::each(crate::check::errors::range0_f(n_p1), [&](const Nat& i_pe) { return crate::prelude::filter(crate::check::errors::range0_f(n_p1), [&](const Nat& j_pf) { return (j_pf == i_pe) || (crate::check::types::has_nat_f(crate::prelude::or_(crate::prelude::index(reach_p5, i_pe), Array<Nat>{}), j_pf) && crate::check::types::has_nat_f(crate::prelude::or_(crate::prelude::index(reach_p5, j_pf), Array<Nat>{}), i_pe)); }); });
    return emit_groups_f(comps_p6, deps_p4, Array<Nat>{}, Array<Array<Nat>>{});
}


prism_rtl::Turn<Array<Array<Nat>>> DepOrder::cycle() const {
    const auto& stmts_p0 = this->stmts_p0;
    auto n_p1 = crate::prelude::len(stmts_p0);
    auto stmts_p0x = stmts_p0;
    return crate::prelude::call_value(crate::prelude::each_job(stmts_p0x, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(crate::syntax::Stmt)>>(prism_rtl::rc([=](crate::syntax::Stmt p0) {
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto s_p7 = p0;
                (prism_rtl::more(prism_rtl::rc(GroupDefs(s_p7))));
            });
        }));
    }))), [=](Array<Array<Text>> each_4014) {
        return ({
            auto defs_p2 = each_4014;
            (crate::prelude::call_value(crate::prelude::each_job(stmts_p0x, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(crate::syntax::Stmt)>>(prism_rtl::rc([=](crate::syntax::Stmt p0) {
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto s_p8 = p0;
                    (prism_rtl::more(prism_rtl::rc(crate::check::shrink::locals::NamesInStmt(s_p8))));
                });
            }));
        }))), [=, defs_p2 = std::move(defs_p2)](Array<Array<Text>> each_4058) {
            return ({
                auto uses_p3 = each_4058;
                auto deps_p4 = crate::prelude::each(crate::check::errors::range0_f(n_p1), [&](const Nat& i_p9) { return crate::prelude::filter(crate::check::errors::range0_f(n_p1), [&](const Nat& j_pa) { return crate::prelude::fold(crate::prelude::or_(crate::prelude::index(defs_p2, j_pa), Array<Text>{}), false, [&](const bool& seen_pb, const Text& d_pc) { return prism_rtl::deref(seen_pb) || crate::check::types::has_text_f(crate::prelude::or_(crate::prelude::index(uses_p3, i_p9), Array<Text>{}), d_pc); }); }); });
                (crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(n_p1), ({
                auto deps_p4x = deps_p4;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(Nat)>>(prism_rtl::rc([=, deps_p4x = std::move(deps_p4x)](Nat p0) {
                return ({
                    auto deps_p4xy = deps_p4x;
                    (crate::prelude::entered(crate::prelude::once_job([=, deps_p4xy = std::move(deps_p4xy)]() {
                    return ({
                        auto i_pd = p0;
                        (prism_rtl::more(prism_rtl::rc(ReachIdx(deps_p4xy, crate::prelude::or_(crate::prelude::index(deps_p4xy, i_pd), Array<Nat>{}), Array<Nat>{}))));
                    });
                })));
                });
            })));
            })), [=](Array<Array<Nat>> each_4247) {
                return ({
                    auto reach_p5 = each_4247;
                    auto comps_p6 = crate::prelude::each(crate::check::errors::range0_f(n_p1), [&](const Nat& i_pe) { return crate::prelude::filter(crate::check::errors::range0_f(n_p1), [&](const Nat& j_pf) { return (j_pf == i_pe) || (crate::check::types::has_nat_f(crate::prelude::or_(crate::prelude::index(reach_p5, i_pe), Array<Nat>{}), j_pf) && crate::check::types::has_nat_f(crate::prelude::or_(crate::prelude::index(reach_p5, j_pf), Array<Nat>{}), i_pe)); }); });
                    (prism_rtl::more(prism_rtl::rc(EmitGroups(comps_p6, deps_p4, Array<Nat>{}, Array<Array<Nat>>{}))));
                });
            }));
            });
        }));
        });
    });
}


/// `Start DepOrder, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Array<Nat>>> start_dep_order_f(Array<crate::syntax::Stmt> stmts_p0) {
    return prism_rtl::make_rc<DepOrder>(stmts_p0);
}


/// GroupDefs: unbounded fn Stmt -> [Text]
Array<Text> group_defs_f(const crate::syntax::Stmt& s_p0) {
    auto&& _m = s_p0.kind_p;
    if (prism_rtl::is<crate::syntax::StmtKind::SBind>(_m)) {
        auto&& p_p1 = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a0;
        return crate::check::env::names::pattern_names_f(p_p1);
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SLet>(_m)) {
        auto&& p_p2 = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
        return crate::check::env::names::pattern_names_f(p_p2);
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SFn>(_m)) {
        auto&& f_p3 = prism_rtl::as<crate::syntax::StmtKind::SFn>(_m).a0;
        return Array(std::vector{crate::check::env::def_name_text_f(prism_rtl::deref(f_p3).name_p)});
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SWidget>(_m)) {
        auto&& w_p4 = prism_rtl::as<crate::syntax::StmtKind::SWidget>(_m).a0;
        return Array(std::vector{crate::check::env::sname_key_f(prism_rtl::deref(w_p4).name_p)});
    }
    {
        return Array<Text>{};
    }
}


prism_rtl::Turn<Array<Text>> GroupDefs::cycle() const {
    const auto& s_p0 = this->s_p0;
    return ({
        auto&& _m = prism_rtl::deref(s_p0).kind_p;
        prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) ? ({
        auto&& p_p1 = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a0;
        prism_rtl::more(prism_rtl::rc(crate::check::env::names::PatternNames(p_p1)));
    })
        : prism_rtl::is<crate::syntax::StmtKind::SLet>(_m) ? ({
        auto&& p_p2 = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
        prism_rtl::more(prism_rtl::rc(crate::check::env::names::PatternNames(p_p2)));
    })
        : prism_rtl::is<crate::syntax::StmtKind::SFn>(_m) ? ({
        auto&& f_p3 = prism_rtl::as<crate::syntax::StmtKind::SFn>(_m).a0;
        prism_rtl::finished(Array(std::vector{crate::check::env::def_name_text_f(prism_rtl::deref(f_p3).name_p)}));
    })
        : prism_rtl::is<crate::syntax::StmtKind::SWidget>(_m) ? ({
        auto&& w_p4 = prism_rtl::as<crate::syntax::StmtKind::SWidget>(_m).a0;
        prism_rtl::finished(Array(std::vector{crate::check::env::sname_key_f(prism_rtl::deref(w_p4).name_p)}));
    })
        : prism_rtl::finished(Array<Text>{});
    });
}


/// `Start GroupDefs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_group_defs_f(crate::syntax::Stmt s_p0) {
    return prism_rtl::make_rc<GroupDefs>(s_p0);
}


/// ReachIdx: unbounded fn [ [Nat] ], [Nat], [Nat] -> [Nat]
Array<Nat> reach_idx_f(const Array<Array<Nat>>& deps_p0, const Array<Nat>& frontier_p1, const Array<Nat>& seen_p2) {
    auto&& _m = crate::prelude::index(frontier_p1, Nat(0u));
    if (prism_rtl::is_none(_m)) {
        return seen_p2;
    }
    if (prism_rtl::is_some(_m)) {
        auto&& x_p3 = prism_rtl::some_of(_m);
        return crate::check::types::has_nat_f(seen_p2, x_p3)
            ? reach_idx_f(deps_p0, crate::prelude::drop(frontier_p1, Nat(1u)), seen_p2)
            : reach_idx_f(deps_p0, crate::prelude::append(crate::prelude::drop(frontier_p1, Nat(1u)), crate::prelude::or_(crate::prelude::index(deps_p0, x_p3), Array<Nat>{})), crate::prelude::push(seen_p2, x_p3));
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Nat>> ReachIdx::cycle() const {
    const auto& deps_p0 = this->deps_p0;
    const auto& frontier_p1 = this->frontier_p1;
    const auto& seen_p2 = this->seen_p2;
    return ({
        auto&& _m = crate::prelude::index(frontier_p1, Nat(0u));
        prism_rtl::is_none(_m) ? prism_rtl::finished(seen_p2)
        : prism_rtl::is_some(_m) ? ({
        auto&& x_p3 = prism_rtl::some_of(_m);
        crate::check::types::has_nat_f(seen_p2, x_p3)
        ? prism_rtl::more(prism_rtl::rc(ReachIdx(deps_p0, crate::prelude::drop(frontier_p1, Nat(1u)), seen_p2)))
        : prism_rtl::more(prism_rtl::rc(ReachIdx(deps_p0, crate::prelude::append(crate::prelude::drop(frontier_p1, Nat(1u)), crate::prelude::or_(crate::prelude::index(deps_p0, x_p3), Array<Nat>{})), crate::prelude::push(seen_p2, x_p3))));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ReachIdx, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Nat>> start_reach_idx_f(Array<Array<Nat>> deps_p0, Array<Nat> frontier_p1, Array<Nat> seen_p2) {
    return prism_rtl::make_rc<ReachIdx>(deps_p0, frontier_p1, seen_p2);
}


/// EmitGroups: unbounded fn [ [Nat] ], [ [Nat] ], [Nat], [ [Nat] ] -> [ [Nat] ]
Array<Array<Nat>> emit_groups_f(const Array<Array<Nat>>& comps_p0, const Array<Array<Nat>>& deps_p1, const Array<Nat>& done_p2, const Array<Array<Nat>>& acc_p3) {
    auto ready_p4 = crate::prelude::filter(crate::check::errors::range0_f(crate::prelude::len(comps_p0)), [&](const Nat& i_p5) { return (!crate::check::types::has_nat_f(done_p2, i_p5)) && crate::prelude::fold(crate::prelude::or_(crate::prelude::index(deps_p1, i_p5), Array<Nat>{}), true, [&](const bool& ok_p6, const Nat& d_p7) { return prism_rtl::deref(ok_p6) && (crate::check::types::has_nat_f(done_p2, d_p7) || crate::check::types::has_nat_f(crate::prelude::or_(crate::prelude::index(comps_p0, i_p5), Array<Nat>{}), d_p7)); }); });
    auto&& _m = crate::prelude::index(ready_p4, Nat(0u));
    if (prism_rtl::is_none(_m)) {
        return acc_p3;
    }
    if (prism_rtl::is_some(_m)) {
        auto&& i_p8 = prism_rtl::some_of(_m);
        auto c_p9 = crate::prelude::or_(crate::prelude::index(comps_p0, i_p8), Array(std::vector{i_p8}));
        return emit_groups_f(comps_p0, deps_p1, crate::prelude::append(done_p2, c_p9), crate::prelude::push(acc_p3, c_p9));
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Array<Nat>>> EmitGroups::cycle() const {
    const auto& comps_p0 = this->comps_p0;
    const auto& deps_p1 = this->deps_p1;
    const auto& done_p2 = this->done_p2;
    const auto& acc_p3 = this->acc_p3;
    auto ready_p4 = crate::prelude::filter(crate::check::errors::range0_f(crate::prelude::len(comps_p0)), [&](const Nat& i_p5) { return (!crate::check::types::has_nat_f(done_p2, i_p5)) && crate::prelude::fold(crate::prelude::or_(crate::prelude::index(deps_p1, i_p5), Array<Nat>{}), true, [&](const bool& ok_p6, const Nat& d_p7) { return prism_rtl::deref(ok_p6) && (crate::check::types::has_nat_f(done_p2, d_p7) || crate::check::types::has_nat_f(crate::prelude::or_(crate::prelude::index(comps_p0, i_p5), Array<Nat>{}), d_p7)); }); });
    return ({
        auto&& _m = crate::prelude::index(ready_p4, Nat(0u));
        prism_rtl::is_none(_m) ? prism_rtl::finished(acc_p3)
        : prism_rtl::is_some(_m) ? ({
        auto&& i_p8 = prism_rtl::some_of(_m);
        ({
        auto c_p9 = crate::prelude::or_(crate::prelude::index(comps_p0, i_p8), Array(std::vector{i_p8}));
        (prism_rtl::more(prism_rtl::rc(EmitGroups(comps_p0, deps_p1, crate::prelude::append(done_p2, c_p9), crate::prelude::push(acc_p3, c_p9)))));
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start EmitGroups, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Array<Nat>>> start_emit_groups_f(Array<Array<Nat>> comps_p0, Array<Array<Nat>> deps_p1, Array<Nat> done_p2, Array<Array<Nat>> acc_p3) {
    return prism_rtl::make_rc<EmitGroups>(comps_p0, deps_p1, done_p2, acc_p3);
}


/// IsHold: fn Stmt -> Bool
bool is_hold_f(const crate::syntax::Stmt& s_p0) {
    auto&& _m = s_p0.kind_p;
    if (prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) && prism_rtl::is_some(prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2)) {
        return true;
    }
    {
        return false;
    }
}


/// IsLetLike: fn Stmt -> Bool
bool is_let_like_f(const crate::syntax::Stmt& s_p0) {
    auto&& _m = s_p0.kind_p;
    if (prism_rtl::is<crate::syntax::StmtKind::SLet>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SFn>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SSignature>(_m)) {
        return true;
    }
    {
        return false;
    }
}


/// InferWidgetBlock: unbounded fn Env, St, Block -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_widget_block_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Block& b_p2) {
    auto [env1_p6, st1_p7] = block_row_f(env_p0, st_p1, b_p2.stmts_p);
    auto [env2_pb, st2_pc] = crate::prelude::run_to_end(crate::prelude::fold_job(b_p2.stmts_p, std::tuple{env1_p6, st1_p7}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>>(std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, crate::syntax::Stmt>)>>(prism_rtl::rc([=](std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, crate::syntax::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto [en_p8, s_p9] = p0;
                auto stmt_pa = p1;
                (prism_rtl::more(prism_rtl::rc(PreBindStmt(en_p8, s_p9, stmt_pa))));
            });
        }));
    }))));
    auto n_p3 = crate::prelude::len(b_p2.stmts_p);
    auto [env3_pm, st3_pn, res_oo] = crate::prelude::run_to_end(crate::prelude::fold_job(widget_group_order_f(b_p2.stmts_p), std::tuple{env2_pb, st2_pc, std::optional<crate::check::types::Ty>{}}, ({
        auto b_p2x = b_p2;
        auto n_p3x = n_p3;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St, std::optional<crate::check::types::Ty>>>(std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St, std::optional<crate::check::types::Ty>>, Nat>)>>(prism_rtl::rc([=, b_p2x = std::move(b_p2x), n_p3x = std::move(n_p3x)](std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St, std::optional<crate::check::types::Ty>>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto b_p2xy = b_p2x;
            auto n_p3xy = n_p3x;
            (crate::prelude::entered(crate::prelude::once_job([=, b_p2xy = std::move(b_p2xy), n_p3xy = std::move(n_p3xy)]() {
            return ({
                auto [en_pd, s_pe, r_of] = p0;
                auto i_pg = p1;
                ({
                auto stmt_ph = crate::prelude::or_(crate::prelude::index(prism_rtl::deref(b_p2xy).stmts_p, i_pg), dummy_stmt2_p());
                (crate::prelude::call_then(start_widget_stmt_f(en_pd, s_pe, stmt_ph, (i_pg + Nat(1u)) == n_p3xy), [=](std::tuple<crate::check::expr::Env, crate::check::types::St, std::optional<crate::check::types::Ty>> widget_stmt_f_6645) {
                return ({
                    auto [en2_pi, s2_pj, r2_ok] = widget_stmt_f_6645;
                    ({
                    prism_rtl::is_some(r2_ok) ? ({
                    auto&& t_pl = prism_rtl::some_of(r2_ok);
                    prism_rtl::finished(std::tuple{en2_pi, s2_pj, std::optional(t_pl)});
                })
                    : prism_rtl::is_none(r2_ok) ? prism_rtl::finished(std::tuple{en2_pi, s2_pj, r_of})
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            }));
            });
            });
        })));
        });
    }));
    })));
    auto st4_p4 = crate::check::passes::cycles::block_prompt_cycles_f(env3_pm, st3_pn, b_p2);
    auto st5_p5 = prism_rtl::deref(st4_p4).recording_p
        ? crate::check::types::recording::note_group_f(st4_p4, b_p2.span_p, Text::lit("widget"), dep_order_f(b_p2.stmts_p))
        : st4_p4;
    return std::tuple{crate::prelude::or_(res_oo, crate::check::types::t_unit_p()), st5_p5};
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InferWidgetBlock::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& b_p2 = this->b_p2;
    auto b_p2x = b_p2;
    auto env_p0x = env_p0;
    auto st_p1x = st_p1;
    return crate::prelude::call_then(start_block_row_f(env_p0x, st_p1x, prism_rtl::deref(b_p2x).stmts_p), [=](std::tuple<crate::check::expr::Env, crate::check::types::St> block_row_f_6320) {
        return ({
            auto [env1_p6, st1_p7] = block_row_f_6320;
            (crate::prelude::call_value(crate::prelude::fold_job(prism_rtl::deref(b_p2x).stmts_p, std::tuple{env1_p6, st1_p7}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>>(std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, crate::syntax::Stmt>)>>(prism_rtl::rc([=](std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, crate::syntax::Stmt> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto [en_p8, s_p9] = p0;
                    auto stmt_pa = p1;
                    (prism_rtl::more(prism_rtl::rc(PreBindStmt(en_p8, s_p9, stmt_pa))));
                });
            }));
        }))), [=](std::tuple<crate::check::expr::Env, crate::check::types::St> fold_6370) {
            return ({
                auto [env2_pb, st2_pc] = fold_6370;
                auto n_p3 = crate::prelude::len(prism_rtl::deref(b_p2x).stmts_p);
                (crate::prelude::call_then(start_widget_group_order_f(prism_rtl::deref(b_p2x).stmts_p), [=, n_p3 = std::move(n_p3)](Array<Nat> widget_group_order_f_6502) {
                return crate::prelude::call_value(crate::prelude::fold_job(widget_group_order_f_6502, std::tuple{env2_pb, st2_pc, std::optional<crate::check::types::Ty>{}}, ({
                    auto b_p2xx = b_p2x;
                    auto n_p3x = n_p3;
                    static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St, std::optional<crate::check::types::Ty>>>(std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St, std::optional<crate::check::types::Ty>>, Nat>)>>(prism_rtl::rc([=, b_p2xx = std::move(b_p2xx), n_p3x = std::move(n_p3x)](std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St, std::optional<crate::check::types::Ty>>, Nat> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto b_p2xxy = b_p2xx;
                        auto n_p3xy = n_p3x;
                        (crate::prelude::entered(crate::prelude::once_job([=, b_p2xxy = std::move(b_p2xxy), n_p3xy = std::move(n_p3xy)]() {
                        return ({
                            auto [en_pd, s_pe, r_of] = p0;
                            auto i_pg = p1;
                            ({
                            auto stmt_ph = crate::prelude::or_(crate::prelude::index(prism_rtl::deref(b_p2xxy).stmts_p, i_pg), dummy_stmt2_p());
                            (crate::prelude::call_then(start_widget_stmt_f(en_pd, s_pe, stmt_ph, (i_pg + Nat(1u)) == n_p3xy), [=](std::tuple<crate::check::expr::Env, crate::check::types::St, std::optional<crate::check::types::Ty>> widget_stmt_f_6645) {
                            return ({
                                auto [en2_pi, s2_pj, r2_ok] = widget_stmt_f_6645;
                                ({
                                prism_rtl::is_some(r2_ok) ? ({
                                auto&& t_pl = prism_rtl::some_of(r2_ok);
                                prism_rtl::finished(std::tuple{en2_pi, s2_pj, std::optional(t_pl)});
                            })
                                : prism_rtl::is_none(r2_ok) ? prism_rtl::finished(std::tuple{en2_pi, s2_pj, r_of})
                                : throw prism_rtl::Panic("no arm matched");
                            });
                            });
                        }));
                        });
                        });
                    })));
                    });
                }));
                })), [=](std::tuple<crate::check::expr::Env, crate::check::types::St, std::optional<crate::check::types::Ty>> fold_6496) {
                    return ({
                        auto [env3_pm, st3_pn, res_oo] = fold_6496;
                        (crate::prelude::call_then(crate::check::passes::cycles::start_block_prompt_cycles_f(env3_pm, st3_pn, b_p2x), [=](crate::check::types::St block_prompt_cycles_f_6780) {
                        return ({
                            auto st4_p4 = block_prompt_cycles_f_6780;
                            auto st5_p5 = prism_rtl::deref(st4_p4).recording_p
                                ? crate::check::types::recording::note_group_f(st4_p4, prism_rtl::deref(b_p2x).span_p, Text::lit("widget"), dep_order_f(prism_rtl::deref(b_p2x).stmts_p))
                                : st4_p4;
                            (prism_rtl::finished(std::tuple{crate::prelude::or_(res_oo, crate::check::types::t_unit_p()), st5_p5}));
                        });
                    }));
                    });
                });
            }));
            });
        }));
        });
    });
}


/// `Start InferWidgetBlock, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_widget_block_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Block b_p2) {
    return prism_rtl::make_rc<InferWidgetBlock>(env_p0, st_p1, b_p2);
}


/// let dummyStmt2
crate::syntax::Stmt dummy_stmt2_p() {
    return crate::syntax::Stmt{.kind_p = crate::syntax::StmtKind(crate::syntax::StmtKind::SExpr{crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EError{})), .span_p = crate::syntax::Range{.start_p = Nat(0u), .end_p = Nat(0u)}}}), .span_p = crate::syntax::Range{.start_p = Nat(0u), .end_p = Nat(0u)}};
}


/// BlockRow: unbounded fn Env, St, [Stmt] -> ((Env, St))
std::tuple<crate::check::expr::Env, crate::check::types::St> block_row_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const Array<crate::syntax::Stmt>& stmts_p2) {
    return crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(crate::prelude::len(stmts_p2)), std::tuple{env_p0, st_p1}, ({
        auto stmts_p2x = stmts_p2;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>>(std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=, stmts_p2x = std::move(stmts_p2x)](std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto stmts_p2xy = stmts_p2x;
            (crate::prelude::entered(crate::prelude::once_job([=, stmts_p2xy = std::move(stmts_p2xy)]() {
            return ({
                auto [en_p3, s_p4] = p0;
                auto i_p5 = p1;
                ({
                auto&& _m = crate::prelude::index(stmts_p2xy, i_p5);
                prism_rtl::is_some(_m) ? ({
                auto&& stmt_p6 = prism_rtl::some_of(_m);
                ({
                auto&& _m = prism_rtl::deref(stmt_p6).kind_p;
                prism_rtl::is<crate::syntax::StmtKind::SEmit>(_m) ? ({
                auto&& row_decl_p7 = prism_rtl::as<crate::syntax::StmtKind::SEmit>(_m).a0;
                i_p5 > Nat(0u)
                ? prism_rtl::finished(std::tuple{en_p3, crate::check::types::recording::err_fix_f(s_p4, Text::lit("emit-element"), prism_rtl::deref(stmt_p6).span_p, Text::lit("`emit` comes first in its block"), Text::lit("move this line to the top of the block"))})
                : ({
                auto row_decl_p7x = row_decl_p7;
                (crate::prelude::call_then(crate::check::env::reading::start_conv_row_f(crate::check::expr::env_cx_f(en_p3), s_p4, row_as_type_f(row_decl_p7x)), [=](std::tuple<crate::check::types::Rw, crate::check::types::St> conv_row_f_7542) {
                return ({
                    auto [rw_p9, s2_pa] = conv_row_f_7542;
                    auto en2_p8 = ({
                        crate::check::expr::Env this_ = en_p3;
                        this_.scope_p = resolve_scope_row_f(en_p3, rw_p9);
                        (std::move(this_));
                    });
                    (prism_rtl::finished(std::tuple{en2_p8, s2_pa}));
                });
            }));
            });
            })
                : prism_rtl::finished(std::tuple{en_p3, s_p4});
            });
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{en_p3, s_p4})
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        })));
        });
    }));
    })));
}


prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St>> BlockRow::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& stmts_p2 = this->stmts_p2;
    return crate::prelude::fold_job(crate::check::errors::range0_f(crate::prelude::len(stmts_p2)), std::tuple{env_p0, st_p1}, ({
        auto stmts_p2x = stmts_p2;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>>(std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=, stmts_p2x = std::move(stmts_p2x)](std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto stmts_p2xy = stmts_p2x;
            (crate::prelude::entered(crate::prelude::once_job([=, stmts_p2xy = std::move(stmts_p2xy)]() {
            return ({
                auto [en_p3, s_p4] = p0;
                auto i_p5 = p1;
                ({
                auto&& _m = crate::prelude::index(stmts_p2xy, i_p5);
                prism_rtl::is_some(_m) ? ({
                auto&& stmt_p6 = prism_rtl::some_of(_m);
                ({
                auto&& _m = prism_rtl::deref(stmt_p6).kind_p;
                prism_rtl::is<crate::syntax::StmtKind::SEmit>(_m) ? ({
                auto&& row_decl_p7 = prism_rtl::as<crate::syntax::StmtKind::SEmit>(_m).a0;
                i_p5 > Nat(0u)
                ? prism_rtl::finished(std::tuple{en_p3, crate::check::types::recording::err_fix_f(s_p4, Text::lit("emit-element"), prism_rtl::deref(stmt_p6).span_p, Text::lit("`emit` comes first in its block"), Text::lit("move this line to the top of the block"))})
                : ({
                auto row_decl_p7x = row_decl_p7;
                (crate::prelude::call_then(crate::check::env::reading::start_conv_row_f(crate::check::expr::env_cx_f(en_p3), s_p4, row_as_type_f(row_decl_p7x)), [=](std::tuple<crate::check::types::Rw, crate::check::types::St> conv_row_f_7542) {
                return ({
                    auto [rw_p9, s2_pa] = conv_row_f_7542;
                    auto en2_p8 = ({
                        crate::check::expr::Env this_ = en_p3;
                        this_.scope_p = resolve_scope_row_f(en_p3, rw_p9);
                        (std::move(this_));
                    });
                    (prism_rtl::finished(std::tuple{en2_p8, s2_pa}));
                });
            }));
            });
            })
                : prism_rtl::finished(std::tuple{en_p3, s_p4});
            });
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{en_p3, s_p4})
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        })));
        });
    }));
    }))->cycle();
}


/// `Start BlockRow, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>> start_block_row_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Array<crate::syntax::Stmt> stmts_p2) {
    return prism_rtl::make_rc<BlockRow>(env_p0, st_p1, stmts_p2);
}


/// RowAsType: fn Row -> Type
crate::syntax::Type row_as_type_f(const crate::syntax::Row_& row_decl_p0) {
    return crate::syntax::Type{.kind_p = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TRowUnion{crate::prelude::each(row_decl_p0.terms_p, row_term_type_f)})), .span_p = row_decl_p0.span_p};
}


/// RowTermType: fn RowTerm -> Type
crate::syntax::Type row_term_type_f(const crate::syntax::RowTerm& row_term0) {
    if (prism_rtl::is<crate::syntax::RowTerm::RFamily>(row_term0)) {
        auto&& q_p0 = prism_rtl::as<crate::syntax::RowTerm::RFamily>(row_term0).a0;
        return crate::syntax::Type{.kind_p = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TFamily{q_p0})), .span_p = prism_rtl::deref(q_p0).span_p};
    }
    if (prism_rtl::is<crate::syntax::RowTerm::RVar>(row_term0)) {
        auto&& v_p1 = prism_rtl::as<crate::syntax::RowTerm::RVar>(row_term0).a0;
        return crate::syntax::Type{.kind_p = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TName{crate::syntax::SName{.sigils_p = Text::lit(""), .path_p = Array(std::vector{prism_rtl::deref(v_p1).name_p}), .span_p = prism_rtl::deref(v_p1).span_p}, Array<crate::syntax::Type>{}})), .span_p = prism_rtl::deref(v_p1).span_p};
    }
    if (prism_rtl::is<crate::syntax::RowTerm::RType>(row_term0)) {
        auto&& t_p2 = prism_rtl::as<crate::syntax::RowTerm::RType>(row_term0).a0;
        return t_p2;
    }
    prism_rtl::unreachable("no arm matched");
}


/// ResolveScopeRow: fn Env, Rw -> Rw
crate::check::types::Rw resolve_scope_row_f(const crate::check::expr::Env& env_p0, const crate::check::types::Rw& rw_p1) {
    auto&& _m = rw_p1.tail_p;
    if (prism_rtl::is<crate::check::types::Tail::TlQ>(_m)) {
        auto&& v_p2 = prism_rtl::as<crate::check::types::Tail::TlQ>(_m).a0;
        return crate::check::types::Rw{.fams_p = rw_p1.fams_p, .minus_p = rw_p1.minus_p, .tail_p = prism_rtl::deref(env_p0.scope_p).tail_p};
    }
    {
        return rw_p1;
    }
}


/// PreBindStmt: unbounded fn Env, St, Stmt -> ((Env, St))
std::tuple<crate::check::expr::Env, crate::check::types::St> pre_bind_stmt_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Stmt& s_p2) {
    auto&& _m = s_p2.kind_p;
    if (prism_rtl::is<crate::syntax::StmtKind::SBind>(_m)) {
        auto&& p_p3 = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a0;
        return pre_bind_pattern_f(env_p0, st_p1, p_p3);
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SLet>(_m)) {
        return crate::check::expr::lets::pre_bind_f(env_p0, st_p1, s_p2);
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SFn>(_m)) {
        return crate::check::expr::lets::pre_bind_f(env_p0, st_p1, s_p2);
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SSignature>(_m)) {
        return crate::check::expr::lets::pre_bind_f(env_p0, st_p1, s_p2);
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SWidget>(_m)) {
        auto&& w_p4 = prism_rtl::as<crate::syntax::StmtKind::SWidget>(_m).a0;
        auto [v_p5, st2_p6] = crate::check::types::fresh_var_f(st_p1, false, Text::lit(""));
        return crate::check::expr::bind_local_id_f(crate::check::expr::with_local_f(env_p0, crate::check::env::sname_key_f(prism_rtl::deref(w_p4).name_p), crate::check::types::schemes::mono_f(crate::check::types::Ty(crate::check::types::Ty::TyAt{prism_rtl::rc(v_p5), env_p0.scope_p}))), st2_p6, crate::check::env::sname_key_f(prism_rtl::deref(w_p4).name_p), prism_rtl::deref(prism_rtl::deref(w_p4).name_p).span_p);
    }
    {
        return std::tuple{env_p0, st_p1};
    }
}


prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St>> PreBindStmt::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& s_p2 = this->s_p2;
    return ({
        auto&& _m = prism_rtl::deref(s_p2).kind_p;
        prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) ? ({
        auto&& p_p3 = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a0;
        prism_rtl::more(prism_rtl::rc(PreBindPattern(env_p0, st_p1, p_p3)));
    })
        : prism_rtl::is<crate::syntax::StmtKind::SLet>(_m) ? prism_rtl::more(prism_rtl::rc(crate::check::expr::lets::PreBind(env_p0, st_p1, s_p2)))
        : prism_rtl::is<crate::syntax::StmtKind::SFn>(_m) ? prism_rtl::more(prism_rtl::rc(crate::check::expr::lets::PreBind(env_p0, st_p1, s_p2)))
        : prism_rtl::is<crate::syntax::StmtKind::SSignature>(_m) ? prism_rtl::more(prism_rtl::rc(crate::check::expr::lets::PreBind(env_p0, st_p1, s_p2)))
        : prism_rtl::is<crate::syntax::StmtKind::SWidget>(_m) ? ({
        auto&& w_p4 = prism_rtl::as<crate::syntax::StmtKind::SWidget>(_m).a0;
        ({
        auto [v_p5, st2_p6] = crate::check::types::fresh_var_f(st_p1, false, Text::lit(""));
        (prism_rtl::finished(crate::check::expr::bind_local_id_f(crate::check::expr::with_local_f(env_p0, crate::check::env::sname_key_f(prism_rtl::deref(w_p4).name_p), crate::check::types::schemes::mono_f(crate::check::types::Ty(crate::check::types::Ty::TyAt{prism_rtl::rc(v_p5), prism_rtl::deref(env_p0).scope_p}))), st2_p6, crate::check::env::sname_key_f(prism_rtl::deref(w_p4).name_p), prism_rtl::deref(prism_rtl::deref(w_p4).name_p).span_p)));
    });
    })
        : prism_rtl::finished(std::tuple{env_p0, st_p1});
    });
}


/// `Start PreBindStmt, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>> start_pre_bind_stmt_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Stmt s_p2) {
    return prism_rtl::make_rc<PreBindStmt>(env_p0, st_p1, s_p2);
}


/// PreBindPattern: unbounded fn Env, St, Pattern -> ((Env, St))
std::tuple<crate::check::expr::Env, crate::check::types::St> pre_bind_pattern_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Pattern_& p_p2) {
    return crate::prelude::fold(crate::check::env::names::pattern_binders_f(p_p2), std::tuple{env_p0, st_p1}, [&](const std::tuple<crate::check::expr::Env, crate::check::types::St>& _p0, const std::tuple<Text, crate::syntax::Range>& _p1) {
        auto&& en_p3 = std::get<0>(_p0);
        auto&& s_p4 = std::get<1>(_p0);
        auto&& name_p5 = std::get<0>(_p1);
        auto&& at_p6 = std::get<1>(_p1);
        return ({
            auto [v_pa, s1_pb] = crate::check::types::fresh_var_f(s_p4, true, name_p5);
            auto s2_p7 = crate::check::types::recording::at_binder_f(s1_pb, v_pa, at_p6);
            auto [rw_pc, s3_pd] = crate::check::types::recording::fresh_row_f(s2_p7, Array<Text>{});
            auto t_p8 = crate::check::types::with_marks_f(crate::check::expr::lets::type_marks_f(crate::check::types::unify::marks_of_f(name_p5)), v_pa, rw_pc);
            auto en2_p9 = ({
                crate::check::expr::Env this_ = crate::check::expr::with_local_f(en_p3, name_p5, crate::check::types::schemes::mono_f(t_p8));
                this_.pending_p = crate::check::types::add_text_f(this_.pending_p, name_p5);
                (std::move(this_));
            });
            (crate::check::expr::bind_local_id_f(en2_p9, s3_pd, name_p5, at_p6));
        });
    });
}


prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St>> PreBindPattern::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& p_p2 = this->p_p2;
    auto env_p0x = env_p0;
    auto p_p2x = p_p2;
    auto st_p1x = st_p1;
    return crate::prelude::call_then(crate::check::env::names::start_pattern_binders_f(p_p2x), [=](Array<std::tuple<Text, crate::syntax::Range>> pattern_binders_f_9103) {
        return prism_rtl::finished(crate::prelude::fold(pattern_binders_f_9103, std::tuple{env_p0x, st_p1x}, [&](const std::tuple<crate::check::expr::Env, crate::check::types::St>& _p0, const std::tuple<Text, crate::syntax::Range>& _p1) {
            auto&& en_p3 = std::get<0>(_p0);
            auto&& s_p4 = std::get<1>(_p0);
            auto&& name_p5 = std::get<0>(_p1);
            auto&& at_p6 = std::get<1>(_p1);
            return ({
                auto [v_pa, s1_pb] = crate::check::types::fresh_var_f(s_p4, true, name_p5);
                auto s2_p7 = crate::check::types::recording::at_binder_f(s1_pb, v_pa, at_p6);
                auto [rw_pc, s3_pd] = crate::check::types::recording::fresh_row_f(s2_p7, Array<Text>{});
                auto t_p8 = crate::check::types::with_marks_f(crate::check::expr::lets::type_marks_f(crate::check::types::unify::marks_of_f(name_p5)), v_pa, rw_pc);
                auto en2_p9 = ({
                    crate::check::expr::Env this_ = crate::check::expr::with_local_f(en_p3, name_p5, crate::check::types::schemes::mono_f(t_p8));
                    this_.pending_p = crate::check::types::add_text_f(this_.pending_p, name_p5);
                    (std::move(this_));
                });
                (crate::check::expr::bind_local_id_f(en2_p9, s3_pd, name_p5, at_p6));
            });
        }));
    });
}


/// `Start PreBindPattern, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>> start_pre_bind_pattern_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Pattern_ p_p2) {
    return prism_rtl::make_rc<PreBindPattern>(env_p0, st_p1, p_p2);
}


/// WidgetStmt: unbounded fn Env, St, Stmt, Bool -> ((Env, St, ?Ty))
std::tuple<crate::check::expr::Env, crate::check::types::St, std::optional<crate::check::types::Ty>> widget_stmt_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Stmt& s_p2, const bool& last_p3) {
    auto&& _m = s_p2.kind_p;
    if (prism_rtl::is<crate::syntax::StmtKind::SEmit>(_m)) {
        return std::tuple{env_p0, st_p1, last_p3
            ? std::optional(crate::check::types::t_unit_p())
            : std::optional<crate::check::types::Ty>{}};
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) && prism_rtl::is_none(prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2)) {
        auto&& p_p4 = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a0;
        auto&& e_p5 = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a1;
        auto st2_p6 = bind_stmt_f(env_p0, st_p1, p_p4, e_p5, s_p2.span_p);
        return std::tuple{env_p0, st2_p6, last_p3
            ? std::optional(crate::check::types::t_unit_p())
            : std::optional<crate::check::types::Ty>{}};
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) && prism_rtl::is_some(prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2)) {
        auto&& p_p7 = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a0;
        auto&& init_p8 = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a1;
        auto&& step_p9 = prism_rtl::some_of(prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2);
        auto st2_pa = hold_stmt_f(env_p0, st_p1, p_p7, init_p8, step_p9, s_p2.span_p);
        return std::tuple{env_p0, st2_pa, last_p3
            ? std::optional(crate::check::types::t_unit_p())
            : std::optional<crate::check::types::Ty>{}};
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SIgnore>(_m)) {
        auto&& e_pb = prism_rtl::as<crate::syntax::StmtKind::SIgnore>(_m).a0;
        auto st2_pc = ignore_stmt_f(env_p0, st_p1, e_pb, s_p2.span_p);
        return std::tuple{env_p0, st2_pc, last_p3
            ? std::optional(crate::check::types::t_unit_p())
            : std::optional<crate::check::types::Ty>{}};
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SLet>(_m)) {
        auto&& p_pd = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
        auto&& ty_oe = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a1;
        auto&& e_pf = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
        auto [env2_pg, st2_ph] = crate::check::expr::lets::check_let_f(env_p0, st_p1, p_pd, ty_oe, e_pf, s_p2.span_p);
        return std::tuple{env2_pg, st2_ph, last_p3
            ? std::optional(crate::check::types::t_unit_p())
            : std::optional<crate::check::types::Ty>{}};
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SFn>(_m)) {
        auto&& f_pi = prism_rtl::as<crate::syntax::StmtKind::SFn>(_m).a0;
        auto [env2_pj, st2_pk] = crate::check::expr::lets::check_local_fn_f(env_p0, st_p1, f_pi, s_p2.span_p);
        return std::tuple{env2_pj, st2_pk, last_p3
            ? std::optional(crate::check::types::t_unit_p())
            : std::optional<crate::check::types::Ty>{}};
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SSignature>(_m)) {
        return std::tuple{env_p0, st_p1, last_p3
            ? std::optional(crate::check::types::t_unit_p())
            : std::optional<crate::check::types::Ty>{}};
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SWidget>(_m)) {
        auto&& w_pl = prism_rtl::as<crate::syntax::StmtKind::SWidget>(_m).a0;
        auto [t_pn, st2_po] = infer_widget_block_f(env_p0, st_p1, prism_rtl::deref(w_pl).body_p);
        auto st3_pm = ({
            __label__ _done;
            prism_rtl::Slot<crate::check::types::St> _v;
            auto&& _m = crate::prelude::get(env_p0.locals_p, crate::check::env::sname_key_f(prism_rtl::deref(w_pl).name_p));
            if (prism_rtl::is_some(_m)) {
                auto&& sc_pp = prism_rtl::some_of(_m);
                _v.set(crate::check::types::unify::unify_f(st2_po, prism_rtl::deref(sc_pp).ty_p, crate::check::types::Ty(crate::check::types::Ty::TyAt{prism_rtl::rc(t_pn), env_p0.scope_p}), prism_rtl::deref(w_pl).span_p));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(st2_po);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        return std::tuple{env_p0, st3_pm, last_p3
            ? std::optional(crate::check::types::t_unit_p())
            : std::optional<crate::check::types::Ty>{}};
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m)) {
        auto&& e_pq = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
        auto [t_pr, st2_ps] = bare_line_f(env_p0, st_p1, e_pq, last_p3);
        return last_p3
            ? std::tuple{env_p0, st2_ps, std::optional(t_pr)}
            : std::tuple{env_p0, st2_ps, std::optional<crate::check::types::Ty>{}};
    }
    {
        return std::tuple{env_p0, crate::check::types::recording::err_f(st_p1, Text::lit("mismatch"), s_p2.span_p, Text::lit("this statement belongs in a `given:` or `update` block")), last_p3
            ? std::optional(crate::check::types::t_unit_p())
            : std::optional<crate::check::types::Ty>{}};
    }
}


prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St, std::optional<crate::check::types::Ty>>> WidgetStmt::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& s_p2 = this->s_p2;
    const auto& last_p3 = this->last_p3;
    return ({
        auto&& _m = prism_rtl::deref(s_p2).kind_p;
        prism_rtl::is<crate::syntax::StmtKind::SEmit>(_m) ? prism_rtl::finished(std::tuple{env_p0, st_p1, prism_rtl::deref(last_p3)
        ? std::optional(crate::check::types::t_unit_p())
        : std::optional<crate::check::types::Ty>{}})
        : prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) && prism_rtl::is_none(prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2) ? ({
        auto&& p_p4 = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a0;
        auto&& e_p5 = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a1;
        ({
        auto e_p5x = e_p5;
        auto env_p0x = env_p0;
        auto last_p3x = prism_rtl::deref(last_p3);
        auto p_p4x = p_p4;
        auto s_p2x = s_p2;
        auto st_p1x = st_p1;
        (crate::prelude::call_then(start_bind_stmt_f(env_p0x, st_p1x, p_p4x, e_p5x, prism_rtl::deref(s_p2x).span_p), [=, last_p3x = std::move(last_p3x)](crate::check::types::St bind_stmt_f_9746) {
        return ({
            auto st2_p6 = bind_stmt_f_9746;
            (prism_rtl::finished(std::tuple{env_p0x, st2_p6, last_p3x
            ? std::optional(crate::check::types::t_unit_p())
            : std::optional<crate::check::types::Ty>{}}));
        });
    }));
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) && prism_rtl::is_some(prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2) ? ({
        auto&& p_p7 = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a0;
        auto&& init_p8 = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a1;
        auto&& step_p9 = prism_rtl::some_of(prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2);
        ({
        auto env_p0x = env_p0;
        auto init_p8x = init_p8;
        auto last_p3x = prism_rtl::deref(last_p3);
        auto p_p7x = p_p7;
        auto s_p2x = s_p2;
        auto st_p1x = st_p1;
        auto step_p9x = step_p9;
        (crate::prelude::call_then(start_hold_stmt_f(env_p0x, st_p1x, p_p7x, init_p8x, step_p9x, prism_rtl::deref(s_p2x).span_p), [=, last_p3x = std::move(last_p3x)](crate::check::types::St hold_stmt_f_9873) {
        return ({
            auto st2_pa = hold_stmt_f_9873;
            (prism_rtl::finished(std::tuple{env_p0x, st2_pa, last_p3x
            ? std::optional(crate::check::types::t_unit_p())
            : std::optional<crate::check::types::Ty>{}}));
        });
    }));
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SIgnore>(_m) ? ({
        auto&& e_pb = prism_rtl::as<crate::syntax::StmtKind::SIgnore>(_m).a0;
        ({
        auto e_pbx = e_pb;
        auto env_p0x = env_p0;
        auto last_p3x = prism_rtl::deref(last_p3);
        auto s_p2x = s_p2;
        auto st_p1x = st_p1;
        (crate::prelude::call_then(start_ignore_stmt_f(env_p0x, st_p1x, e_pbx, prism_rtl::deref(s_p2x).span_p), [=, last_p3x = std::move(last_p3x)](crate::check::types::St ignore_stmt_f_9995) {
        return ({
            auto st2_pc = ignore_stmt_f_9995;
            (prism_rtl::finished(std::tuple{env_p0x, st2_pc, last_p3x
            ? std::optional(crate::check::types::t_unit_p())
            : std::optional<crate::check::types::Ty>{}}));
        });
    }));
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SLet>(_m) ? ({
        auto&& p_pd = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
        auto&& ty_oe = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a1;
        auto&& e_pf = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
        ({
        auto ty_oex = ty_oe;
        auto e_pfx = e_pf;
        auto env_p0x = env_p0;
        auto last_p3x = prism_rtl::deref(last_p3);
        auto p_pdx = p_pd;
        auto s_p2x = s_p2;
        auto st_p1x = st_p1;
        (crate::prelude::call_then(crate::check::expr::lets::start_check_let_f(env_p0x, st_p1x, p_pdx, ty_oex, e_pfx, prism_rtl::deref(s_p2x).span_p), [=, last_p3x = std::move(last_p3x)](std::tuple<crate::check::expr::Env, crate::check::types::St> check_let_f_10122) {
        return ({
            auto [env2_pg, st2_ph] = check_let_f_10122;
            (prism_rtl::finished(std::tuple{env2_pg, st2_ph, last_p3x
            ? std::optional(crate::check::types::t_unit_p())
            : std::optional<crate::check::types::Ty>{}}));
        });
    }));
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SFn>(_m) ? ({
        auto&& f_pi = prism_rtl::as<crate::syntax::StmtKind::SFn>(_m).a0;
        ({
        auto env_p0x = env_p0;
        auto f_pix = f_pi;
        auto last_p3x = prism_rtl::deref(last_p3);
        auto s_p2x = s_p2;
        auto st_p1x = st_p1;
        (crate::prelude::call_then(crate::check::expr::lets::start_check_local_fn_f(env_p0x, st_p1x, f_pix, prism_rtl::deref(s_p2x).span_p), [=, last_p3x = std::move(last_p3x)](std::tuple<crate::check::expr::Env, crate::check::types::St> check_local_fn_f_10247) {
        return ({
            auto [env2_pj, st2_pk] = check_local_fn_f_10247;
            (prism_rtl::finished(std::tuple{env2_pj, st2_pk, last_p3x
            ? std::optional(crate::check::types::t_unit_p())
            : std::optional<crate::check::types::Ty>{}}));
        });
    }));
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SSignature>(_m) ? prism_rtl::finished(std::tuple{env_p0, st_p1, prism_rtl::deref(last_p3)
        ? std::optional(crate::check::types::t_unit_p())
        : std::optional<crate::check::types::Ty>{}})
        : prism_rtl::is<crate::syntax::StmtKind::SWidget>(_m) ? ({
        auto&& w_pl = prism_rtl::as<crate::syntax::StmtKind::SWidget>(_m).a0;
        ({
        auto env_p0x = env_p0;
        auto last_p3x = prism_rtl::deref(last_p3);
        auto st_p1x = st_p1;
        auto w_plx = w_pl;
        (crate::prelude::call_then(start_infer_widget_block_f(env_p0x, st_p1x, prism_rtl::deref(w_plx).body_p), [=, last_p3x = std::move(last_p3x)](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_widget_block_f_10432) {
        return ({
            auto [t_pn, st2_po] = infer_widget_block_f_10432;
            auto st3_pm = ({
                __label__ _done;
                prism_rtl::Slot<crate::check::types::St> _v;
                auto&& _m = crate::prelude::get(prism_rtl::deref(env_p0x).locals_p, crate::check::env::sname_key_f(prism_rtl::deref(w_plx).name_p));
                if (prism_rtl::is_some(_m)) {
                    auto&& sc_pp = prism_rtl::some_of(_m);
                    _v.set(crate::check::types::unify::unify_f(st2_po, prism_rtl::deref(sc_pp).ty_p, crate::check::types::Ty(crate::check::types::Ty::TyAt{prism_rtl::rc(t_pn), prism_rtl::deref(env_p0x).scope_p}), prism_rtl::deref(w_plx).span_p));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(st2_po);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            (prism_rtl::finished(std::tuple{env_p0x, st3_pm, last_p3x
            ? std::optional(crate::check::types::t_unit_p())
            : std::optional<crate::check::types::Ty>{}}));
        });
    }));
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m) ? ({
        auto&& e_pq = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
        ({
        auto e_pqx = e_pq;
        auto env_p0x = env_p0;
        auto last_p3x = prism_rtl::deref(last_p3);
        auto st_p1x = st_p1;
        (crate::prelude::call_then(start_bare_line_f(env_p0x, st_p1x, e_pqx, std::move(last_p3x)), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> bare_line_f_10690) {
        return ({
            auto [t_pr, st2_ps] = bare_line_f_10690;
            last_p3x
            ? prism_rtl::finished(std::tuple{env_p0x, st2_ps, std::optional(t_pr)})
            : prism_rtl::finished(std::tuple{env_p0x, st2_ps, std::optional<crate::check::types::Ty>{}});
        });
    }));
    });
    })
        : prism_rtl::finished(std::tuple{env_p0, crate::check::types::recording::err_f(st_p1, Text::lit("mismatch"), prism_rtl::deref(s_p2).span_p, Text::lit("this statement belongs in a `given:` or `update` block")), prism_rtl::deref(last_p3)
        ? std::optional(crate::check::types::t_unit_p())
        : std::optional<crate::check::types::Ty>{}});
    });
}


/// `Start WidgetStmt, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St, std::optional<crate::check::types::Ty>>> start_widget_stmt_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Stmt s_p2, bool last_p3) {
    return prism_rtl::make_rc<WidgetStmt>(env_p0, st_p1, s_p2, last_p3);
}


/// BindStmt: unbounded fn Env, St, Pattern, Expr, Range -> St
crate::check::types::St bind_stmt_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Pattern_& p_p2, const crate::syntax::Expr& e_p3, const crate::syntax::Range& span_p4) {
    auto [t_p5, st1_p6] = crate::check::expr::infer_f(env_p0, st_p1, e_p3);
    auto [out_p7, st2_p8] = is_builder_f(e_p3)
        ? std::tuple{t_p5, st1_p6}
        : bind_output_f(env_p0, st1_p6, t_p5, e_p3.span_p);
    auto&& _st3_p9 = crate::check::expr::patterns::bind_pattern_f(env_p0, st2_p8, p_p2, out_p7, false);
    auto&& st3_p9 = std::get<1>(_st3_p9);
    return st3_p9;
}


prism_rtl::Turn<crate::check::types::St> BindStmt::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& p_p2 = this->p_p2;
    const auto& e_p3 = this->e_p3;
    const auto& span_p4 = this->span_p4;
    auto e_p3x = e_p3;
    auto env_p0x = env_p0;
    auto p_p2x = p_p2;
    auto span_p4x = span_p4;
    auto st_p1x = st_p1;
    return crate::prelude::call_then(crate::check::expr::start_infer_f(env_p0x, st_p1x, e_p3x), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_f_11305) {
        return ({
            auto [t_p5, st1_p6] = infer_f_11305;
            auto [out_p7, st2_p8] = is_builder_f(e_p3x)
                ? std::tuple{t_p5, st1_p6}
                : bind_output_f(env_p0x, st1_p6, t_p5, prism_rtl::deref(e_p3x).span_p);
            (crate::prelude::call_then(crate::check::expr::patterns::start_bind_pattern_f(env_p0x, st2_p8, p_p2x, out_p7, false), [=](std::tuple<crate::check::expr::Env, crate::check::types::St> bind_pattern_f_11435) {
            return ({
                auto&& _st3_p9 = bind_pattern_f_11435;
                auto&& st3_p9 = std::get<1>(_st3_p9);
                (prism_rtl::finished(st3_p9));
            });
        }));
        });
    });
}


/// `Start BindStmt, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_bind_stmt_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Pattern_ p_p2, crate::syntax::Expr e_p3, crate::syntax::Range span_p4) {
    return prism_rtl::make_rc<BindStmt>(env_p0, st_p1, p_p2, e_p3, span_p4);
}


/// IsBuilder: fn Expr -> Bool
bool is_builder_f(const crate::syntax::Expr& e_p0) {
    auto&& _m = prism_rtl::deref(e_p0.kind_p);
    if (prism_rtl::is<crate::syntax::ExprKind::ERebuild>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EFor>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x_p1 = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return is_builder_f(prism_rtl::deref(prism_rtl::deref(x_p1)));
    }
    {
        return false;
    }
}


/// BindOutput: unbounded fn Env, St, Ty, Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> bind_output_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::check::types::Ty& t_p2, const crate::syntax::Range& span_p3) {
    auto&& _m = crate::check::types::recording::walk_f(st_p1, t_p2);
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(_m)) {
        auto&& inner_p4 = prism_rtl::as<crate::check::types::Ty::TyAt>(_m).a0;
        auto&& rw_p5 = prism_rtl::as<crate::check::types::Ty::TyAt>(_m).a1;
        return std::tuple{prism_rtl::deref(inner_p4), add_incl_f(st_p1, rw_p5, env_p0.scope_p, span_p3, Text::lit("child"))};
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(_m)) {
        auto&& rw_p6 = prism_rtl::as<crate::check::types::Ty::TyElem>(_m).a0;
        auto&& o_p7 = prism_rtl::as<crate::check::types::Ty::TyElem>(_m).a1;
        return std::tuple{prism_rtl::deref(o_p7), add_incl_f(st_p1, rw_p6, env_p0.scope_p, span_p3, Text::lit("element"))};
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(_m)) {
        auto&& s_p8 = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a0;
        auto&& inner_p9 = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a1;
        auto&& _m = crate::check::types::recording::walk_f(st_p1, prism_rtl::deref(inner_p9));
        if (prism_rtl::is<crate::check::types::Ty::TyAt>(_m)) {
            return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_fix_f(st_p1, Text::lit("bind-dynamic"), span_p3, prism_rtl::cat("binding a `", crate::check::types::show_ty_f(st_p1, t_p2), "`; say what happens to the old widgets with `rebuild`"), Text::lit("write `rebuild` over the dynamic, with the blueprint inside"))};
        }
        if (prism_rtl::is<crate::check::types::Ty::TyElem>(_m)) {
            return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_fix_f(st_p1, Text::lit("bind-dynamic"), span_p3, prism_rtl::cat("binding a `", crate::check::types::show_ty_f(st_p1, t_p2), "`, a ", s_p8 == Text::lit("$") ? Text::lit("dynamic") : Text::lit("event"), " of elements; say what happens to the old element with `rebuild`"), Text::lit("write `rebuild` over the dynamic field\'s value, with the element inside"))};
        }
        {
            return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_f(st_p1, Text::lit("mismatch"), span_p3, prism_rtl::cat("`<-` binds a blueprint or an element; this is `", crate::check::types::show_ty_f(st_p1, t_p2), "`"))};
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFlex>(_m)) {
        auto [v_pa, st2_pb] = crate::check::types::fresh_var_f(st_p1, false, Text::lit(""));
        return std::tuple{v_pa, crate::check::types::unify::unify_f(st2_pb, t_p2, crate::check::types::Ty(crate::check::types::Ty::TyAt{prism_rtl::rc(v_pa), env_p0.scope_p}), span_p3)};
    }
    if (prism_rtl::is<crate::check::types::Ty::TyErr>(_m)) {
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), st_p1};
    }
    {
        auto&& other_pc = _m;
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_f(st_p1, Text::lit("mismatch"), span_p3, prism_rtl::cat("`<-` binds a blueprint or an element; this is `", crate::check::types::show_ty_f(st_p1, other_pc), "`"))};
    }
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> BindOutput::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& t_p2 = this->t_p2;
    const auto& span_p3 = this->span_p3;
    auto env_p0x = env_p0;
    auto span_p3x = span_p3;
    auto st_p1x = st_p1;
    auto t_p2x = t_p2;
    return crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p1x, t_p2x), [=](crate::check::types::Ty walk_f_11830) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TyAt>(walk_f_11830) ? ({
            auto&& inner_p4 = prism_rtl::as<crate::check::types::Ty::TyAt>(walk_f_11830).a0;
            auto&& rw_p5 = prism_rtl::as<crate::check::types::Ty::TyAt>(walk_f_11830).a1;
            prism_rtl::finished(std::tuple{prism_rtl::deref(inner_p4), add_incl_f(st_p1x, rw_p5, prism_rtl::deref(env_p0x).scope_p, span_p3x, Text::lit("child"))});
        })
            : prism_rtl::is<crate::check::types::Ty::TyElem>(walk_f_11830) ? ({
            auto&& rw_p6 = prism_rtl::as<crate::check::types::Ty::TyElem>(walk_f_11830).a0;
            auto&& o_p7 = prism_rtl::as<crate::check::types::Ty::TyElem>(walk_f_11830).a1;
            prism_rtl::finished(std::tuple{prism_rtl::deref(o_p7), add_incl_f(st_p1x, rw_p6, prism_rtl::deref(env_p0x).scope_p, span_p3x, Text::lit("element"))});
        })
            : prism_rtl::is<crate::check::types::Ty::TySig>(walk_f_11830) ? ({
            auto&& s_p8 = prism_rtl::as<crate::check::types::Ty::TySig>(walk_f_11830).a0;
            auto&& inner_p9 = prism_rtl::as<crate::check::types::Ty::TySig>(walk_f_11830).a1;
            crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p1x, prism_rtl::deref(inner_p9)), [=](crate::check::types::Ty walk_f_12020) {
            return ({
                prism_rtl::is<crate::check::types::Ty::TyAt>(walk_f_12020) ? crate::prelude::call_then(crate::check::types::start_show_ty_f(st_p1x, t_p2x), [=](Text show_ty_f_12125) { return prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_fix_f(st_p1x, Text::lit("bind-dynamic"), span_p3x, prism_rtl::cat("binding a `", show_ty_f_12125, "`; say what happens to the old widgets with `rebuild`"), Text::lit("write `rebuild` over the dynamic, with the blueprint inside"))}); })
                : prism_rtl::is<crate::check::types::Ty::TyElem>(walk_f_12020) ? crate::prelude::call_then(crate::check::types::start_show_ty_f(st_p1x, t_p2x), [=](Text show_ty_f_12350) { return prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_fix_f(st_p1x, Text::lit("bind-dynamic"), span_p3x, prism_rtl::cat("binding a `", show_ty_f_12350, "`, a ", s_p8 == Text::lit("$") ? Text::lit("dynamic") : Text::lit("event"), " of elements; say what happens to the old element with `rebuild`"), Text::lit("write `rebuild` over the dynamic field\'s value, with the element inside"))}); })
                : crate::prelude::call_then(crate::check::types::start_show_ty_f(st_p1x, t_p2x), [=](Text show_ty_f_12658) { return prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_f(st_p1x, Text::lit("mismatch"), span_p3x, prism_rtl::cat("`<-` binds a blueprint or an element; this is `", show_ty_f_12658, "`"))}); });
            });
        });
        })
            : prism_rtl::is<crate::check::types::Ty::TyFlex>(walk_f_11830) ? ({
            auto [v_pa, st2_pb] = crate::check::types::fresh_var_f(st_p1x, false, Text::lit(""));
            (crate::prelude::call_then(crate::check::types::unify::start_unify_f(st2_pb, t_p2x, crate::check::types::Ty(crate::check::types::Ty::TyAt{prism_rtl::rc(v_pa), prism_rtl::deref(env_p0x).scope_p}), span_p3x), [=](crate::check::types::St unify_f_12758) { return prism_rtl::finished(std::tuple{v_pa, unify_f_12758}); }));
        })
            : prism_rtl::is<crate::check::types::Ty::TyErr>(walk_f_11830) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), st_p1x})
            : ({
            auto&& other_pc = walk_f_11830;
            crate::prelude::call_then(crate::check::types::start_show_ty_f(st_p1x, other_pc), [=](Text show_ty_f_12922) { return prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_f(st_p1x, Text::lit("mismatch"), span_p3x, prism_rtl::cat("`<-` binds a blueprint or an element; this is `", show_ty_f_12922, "`"))}); });
        });
        });
    });
}


/// `Start BindOutput, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_bind_output_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::check::types::Ty t_p2, crate::syntax::Range span_p3) {
    return prism_rtl::make_rc<BindOutput>(env_p0, st_p1, t_p2, span_p3);
}


/// AddIncl: fn St, Rw, Rw, Range, Text -> St
crate::check::types::St add_incl_f(const crate::check::types::St& st_p0, const crate::check::types::Rw& sub_p1, const crate::check::types::Rw& sup_p2, const crate::syntax::Range& span_p3, const Text& what_p4) {
    crate::check::types::St this_ = st_p0;
    this_.incls_p = crate::prelude::push(this_.incls_p, crate::check::types::Incl{.sub_p = sub_p1, .sup_p = sup_p2, .file_p = this_.file_p, .span_p = span_p3, .what_p = what_p4, .forward_p = false});
    return this_;
}


/// HoldStmt: unbounded fn Env, St, Pattern, Expr, Expr, Range -> St
crate::check::types::St hold_stmt_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Pattern_& p_p2, const crate::syntax::Expr& init_p3, const crate::syntax::Expr& step_p4, const crate::syntax::Range& span_p5) {
    auto [v_p8, st1_p9] = crate::check::types::fresh_var_f(st_p1, false, Text::lit(""));
    auto held_p6 = crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("$"), prism_rtl::rc(v_p8)});
    auto&& _st2_pa = crate::check::expr::patterns::bind_pattern_f(env_p0, st1_p9, p_p2, held_p6, false);
    auto&& st2_pa = std::get<1>(_st2_pa);
    auto st3_p7 = crate::check::expr::check_f(env_p0, st2_pa, init_p3, v_p8);
    auto [step_ty_pb, st4_pc] = crate::check::expr::infer_f(env_p0, st3_p7, step_p4);
    return (crate::check::types::head_sigil_f(st4_pc, step_ty_pb) == Text::lit("!")) || (step_ty_pb == crate::check::types::Ty(crate::check::types::Ty::TyErr{}))
        ? crate::check::types::unify::unify_f(st4_pc, crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("!"), prism_rtl::rc(v_p8)}), step_ty_pb, step_p4.span_p)
        : crate::check::types::recording::err_fix_f(st4_pc, Text::lit("mismatch"), step_p4.span_p, prism_rtl::cat("a hold\'s step is an event; this is `", crate::check::types::show_ty_f(st4_pc, step_ty_pb), "`"), Text::lit("fire it with an event: `... on !e`"));
}


prism_rtl::Turn<crate::check::types::St> HoldStmt::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& p_p2 = this->p_p2;
    const auto& init_p3 = this->init_p3;
    const auto& step_p4 = this->step_p4;
    const auto& span_p5 = this->span_p5;
    auto [v_p8, st1_p9] = crate::check::types::fresh_var_f(st_p1, false, Text::lit(""));
    auto held_p6 = crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("$"), prism_rtl::rc(v_p8)});
    auto env_p0x = env_p0;
    auto init_p3x = init_p3;
    auto p_p2x = p_p2;
    auto span_p5x = span_p5;
    auto step_p4x = step_p4;
    return crate::prelude::call_then(crate::check::expr::patterns::start_bind_pattern_f(env_p0x, st1_p9, p_p2x, held_p6, false), [=](std::tuple<crate::check::expr::Env, crate::check::types::St> bind_pattern_f_13465) {
        return ({
            auto&& _st2_pa = bind_pattern_f_13465;
            auto&& st2_pa = std::get<1>(_st2_pa);
            (crate::prelude::call_then(crate::check::expr::start_check_f(env_p0x, st2_pa, init_p3x, v_p8), [=](crate::check::types::St check_f_13516) {
            return ({
                auto st3_p7 = check_f_13516;
                (crate::prelude::call_then(crate::check::expr::start_infer_f(env_p0x, st3_p7, step_p4x), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_f_13566) {
                return ({
                    auto [step_ty_pb, st4_pc] = infer_f_13566;
                    (crate::prelude::call_then(crate::check::types::start_head_sigil_f(st4_pc, step_ty_pb), [=](Text head_sigil_f_13595) {
                    return (head_sigil_f_13595 == Text::lit("!")) || (step_ty_pb == crate::check::types::Ty(crate::check::types::Ty::TyErr{}))
                        ? prism_rtl::more(prism_rtl::rc(crate::check::types::unify::Unify(st4_pc, crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("!"), prism_rtl::rc(v_p8)}), step_ty_pb, prism_rtl::deref(step_p4x).span_p)))
                        : crate::prelude::call_then(crate::check::types::start_show_ty_f(st4_pc, step_ty_pb), [=](Text show_ty_f_13773) { return prism_rtl::finished(crate::check::types::recording::err_fix_f(st4_pc, Text::lit("mismatch"), prism_rtl::deref(step_p4x).span_p, prism_rtl::cat("a hold\'s step is an event; this is `", show_ty_f_13773, "`"), Text::lit("fire it with an event: `... on !e`"))); });
                }));
                });
            }));
            });
        }));
        });
    });
}


/// `Start HoldStmt, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_hold_stmt_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Pattern_ p_p2, crate::syntax::Expr init_p3, crate::syntax::Expr step_p4, crate::syntax::Range span_p5) {
    return prism_rtl::make_rc<HoldStmt>(env_p0, st_p1, p_p2, init_p3, step_p4, span_p5);
}


/// IgnoreStmt: unbounded fn Env, St, Expr, Range -> St
crate::check::types::St ignore_stmt_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Expr& e_p2, const crate::syntax::Range& span_p3) {
    auto [t_p4, st1_p5] = crate::check::expr::infer_f(env_p0, st_p1, e_p2);
    auto&& _m = crate::check::types::recording::walk_f(st1_p5, t_p4);
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(_m)) {
        auto&& _st2_p6 = bind_output_f(env_p0, st1_p5, t_p4, e_p2.span_p);
        auto&& st2_p6 = std::get<1>(_st2_p6);
        return st2_p6;
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(_m)) {
        auto&& _st2_p7 = bind_output_f(env_p0, st1_p5, t_p4, e_p2.span_p);
        auto&& st2_p7 = std::get<1>(_st2_p7);
        return st2_p7;
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(_m)) {
        auto&& inner_p8 = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a1;
        auto&& _m = crate::check::types::recording::walk_f(st1_p5, prism_rtl::deref(inner_p8));
        if (prism_rtl::is<crate::check::types::Ty::TyAt>(_m)) {
            auto&& _st2_p9 = bind_output_f(env_p0, st1_p5, t_p4, e_p2.span_p);
            auto&& st2_p9 = std::get<1>(_st2_p9);
            return st2_p9;
        }
        if (prism_rtl::is<crate::check::types::Ty::TyElem>(_m)) {
            auto&& _st2_pa = bind_output_f(env_p0, st1_p5, t_p4, e_p2.span_p);
            auto&& st2_pa = std::get<1>(_st2_pa);
            return st2_pa;
        }
        {
            return st1_p5;
        }
    }
    {
        return st1_p5;
    }
}


prism_rtl::Turn<crate::check::types::St> IgnoreStmt::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& e_p2 = this->e_p2;
    const auto& span_p3 = this->span_p3;
    auto e_p2x = e_p2;
    auto env_p0x = env_p0;
    auto span_p3x = span_p3;
    auto st_p1x = st_p1;
    return crate::prelude::call_then(crate::check::expr::start_infer_f(env_p0x, st_p1x, e_p2x), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_f_14006) {
        return ({
            auto [t_p4, st1_p5] = infer_f_14006;
            (crate::prelude::call_then(crate::check::types::recording::start_walk_f(st1_p5, t_p4), [=](crate::check::types::Ty walk_f_14033) {
            return ({
                prism_rtl::is<crate::check::types::Ty::TyAt>(walk_f_14033) ? crate::prelude::call_then(start_bind_output_f(env_p0x, st1_p5, t_p4, prism_rtl::deref(e_p2x).span_p), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> bind_output_f_14109) {
                return ({
                    auto&& _st2_p6 = bind_output_f_14109;
                    auto&& st2_p6 = std::get<1>(_st2_p6);
                    (prism_rtl::finished(st2_p6));
                });
            })
                : prism_rtl::is<crate::check::types::Ty::TyElem>(walk_f_14033) ? crate::prelude::call_then(start_bind_output_f(env_p0x, st1_p5, t_p4, prism_rtl::deref(e_p2x).span_p), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> bind_output_f_14221) {
                return ({
                    auto&& _st2_p7 = bind_output_f_14221;
                    auto&& st2_p7 = std::get<1>(_st2_p7);
                    (prism_rtl::finished(st2_p7));
                });
            })
                : prism_rtl::is<crate::check::types::Ty::TySig>(walk_f_14033) ? ({
                auto&& inner_p8 = prism_rtl::as<crate::check::types::Ty::TySig>(walk_f_14033).a1;
                crate::prelude::call_then(crate::check::types::recording::start_walk_f(st1_p5, prism_rtl::deref(inner_p8)), [=](crate::check::types::Ty walk_f_14303) {
                return ({
                    prism_rtl::is<crate::check::types::Ty::TyAt>(walk_f_14303) ? crate::prelude::call_then(start_bind_output_f(env_p0x, st1_p5, t_p4, prism_rtl::deref(e_p2x).span_p), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> bind_output_f_14391) {
                    return ({
                        auto&& _st2_p9 = bind_output_f_14391;
                        auto&& st2_p9 = std::get<1>(_st2_p9);
                        (prism_rtl::finished(st2_p9));
                    });
                })
                    : prism_rtl::is<crate::check::types::Ty::TyElem>(walk_f_14303) ? crate::prelude::call_then(start_bind_output_f(env_p0x, st1_p5, t_p4, prism_rtl::deref(e_p2x).span_p), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> bind_output_f_14515) {
                    return ({
                        auto&& _st2_pa = bind_output_f_14515;
                        auto&& st2_pa = std::get<1>(_st2_pa);
                        (prism_rtl::finished(st2_pa));
                    });
                })
                    : prism_rtl::finished(st1_p5);
                });
            });
            })
                : prism_rtl::finished(st1_p5);
            });
        }));
        });
    });
}


/// `Start IgnoreStmt, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_ignore_stmt_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Expr e_p2, crate::syntax::Range span_p3) {
    return prism_rtl::make_rc<IgnoreStmt>(env_p0, st_p1, e_p2, span_p3);
}


/// BareLine: unbounded fn Env, St, Expr, Bool -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> bare_line_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Expr& e_p2, const bool& last_p3) {
    auto [t_p5, st2_p6] = bare_line_kind_f(env_p0, st_p1, e_p2, last_p3);
    auto shown_p4 = ({
        __label__ _done;
        prism_rtl::Slot<crate::check::types::Ty> _v;
        auto&& _m = prism_rtl::deref(e_p2.kind_p);
        if (prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m)) {
            auto&& m14974_0_0 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
            if (m14974_0_0 == Text::lit("@")) {
                _v.set(crate::check::types::Ty(crate::check::types::Ty::TyAt{prism_rtl::rc(t_p5), env_p0.scope_p}));
                goto _done;
            }
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m)) {
            _v.set(crate::check::types::Ty(crate::check::types::Ty::TyAt{prism_rtl::rc(t_p5), env_p0.scope_p}));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EIf>(_m)) {
            _v.set(crate::check::types::Ty(crate::check::types::Ty::TyAt{prism_rtl::rc(t_p5), env_p0.scope_p}));
            goto _done;
        }
        {
            _v.set(t_p5);
            goto _done;
        }
    _done:
        _v.take();
    });
    auto&& _m = prism_rtl::deref(e_p2.kind_p);
    if (prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m)) {
        auto&& m15166_0_0 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
        if (m15166_0_0 == Text::lit("@")) {
            return std::tuple{t_p5, crate::check::types::recording::note_ty_f(st2_p6, e_p2.span_p, shown_p4)};
        }
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m)) {
        return std::tuple{t_p5, crate::check::types::recording::note_ty_f(st2_p6, e_p2.span_p, shown_p4)};
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EIf>(_m)) {
        return std::tuple{t_p5, crate::check::types::recording::note_ty_f(st2_p6, e_p2.span_p, shown_p4)};
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        return std::tuple{t_p5, note_as_last_f(st2_p6, e_p2.span_p)};
    }
    {
        return std::tuple{t_p5, st2_p6};
    }
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> BareLine::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& e_p2 = this->e_p2;
    const auto& last_p3 = this->last_p3;
    auto e_p2x = e_p2;
    auto env_p0x = env_p0;
    auto last_p3x = prism_rtl::deref(last_p3);
    auto st_p1x = st_p1;
    return crate::prelude::call_then(start_bare_line_kind_f(env_p0x, st_p1x, e_p2x, std::move(last_p3x)), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> bare_line_kind_f_14928) {
        return ({
            auto [t_p5, st2_p6] = bare_line_kind_f_14928;
            auto shown_p4 = ({
                __label__ _done;
                prism_rtl::Slot<crate::check::types::Ty> _v;
                auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p2x).kind_p);
                if (prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m)) {
                    auto&& m14974_0_0 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
                    if (m14974_0_0 == Text::lit("@")) {
                        _v.set(crate::check::types::Ty(crate::check::types::Ty::TyAt{prism_rtl::rc(t_p5), prism_rtl::deref(env_p0x).scope_p}));
                        goto _done;
                    }
                }
                if (prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m)) {
                    _v.set(crate::check::types::Ty(crate::check::types::Ty::TyAt{prism_rtl::rc(t_p5), prism_rtl::deref(env_p0x).scope_p}));
                    goto _done;
                }
                if (prism_rtl::is<crate::syntax::ExprKind::EIf>(_m)) {
                    _v.set(crate::check::types::Ty(crate::check::types::Ty::TyAt{prism_rtl::rc(t_p5), prism_rtl::deref(env_p0x).scope_p}));
                    goto _done;
                }
                {
                    _v.set(t_p5);
                    goto _done;
                }
            _done:
                _v.take();
            });
            ({
            auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p2x).kind_p);
            prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m) && ({
            auto&& m15166_0_0 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
            (m15166_0_0 == Text::lit("@"));
        }) ? ({
            auto&& m15166_0_0 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
            prism_rtl::finished(std::tuple{t_p5, crate::check::types::recording::note_ty_f(st2_p6, prism_rtl::deref(e_p2x).span_p, shown_p4)});
        })
            : prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m) ? prism_rtl::finished(std::tuple{t_p5, crate::check::types::recording::note_ty_f(st2_p6, prism_rtl::deref(e_p2x).span_p, shown_p4)})
            : prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) ? prism_rtl::finished(std::tuple{t_p5, crate::check::types::recording::note_ty_f(st2_p6, prism_rtl::deref(e_p2x).span_p, shown_p4)})
            : prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? prism_rtl::finished(std::tuple{t_p5, note_as_last_f(st2_p6, prism_rtl::deref(e_p2x).span_p)})
            : prism_rtl::finished(std::tuple{t_p5, st2_p6});
        });
        });
    });
}


/// `Start BareLine, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_bare_line_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Expr e_p2, bool last_p3) {
    return prism_rtl::make_rc<BareLine>(env_p0, st_p1, e_p2, last_p3);
}


/// NoteAsLast: fn St, Range -> St
crate::check::types::St note_as_last_f(const crate::check::types::St& st_p0, const crate::syntax::Range& span_p1) {
    auto&& _m = crate::syntax::lexer::chars::last_o(prism_rtl::deref(st_p0.typed_p).exprs_p);
    if (prism_rtl::is_some(_m)) {
        auto&& n_p2 = prism_rtl::some_of(_m);
        return crate::check::types::recording::note_ty_f(st_p0, span_p1, prism_rtl::deref(n_p2).ty_p);
    }
    if (prism_rtl::is_none(_m)) {
        return st_p0;
    }
    prism_rtl::unreachable("no arm matched");
}


/// BareLineKind: unbounded fn Env, St, Expr, Bool -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> bare_line_kind_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Expr& e_p2, const bool& last_p3) {
    auto&& _m = prism_rtl::deref(e_p2.kind_p);
    if (prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m)) {
        auto&& scrut_p4 = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
        auto&& arms_p5 = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
        return building_match_f(env_p0, st_p1, prism_rtl::deref(prism_rtl::deref(scrut_p4)), arms_p5, e_p2.span_p, last_p3);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EIf>(_m)) {
        auto&& c_p6 = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
        auto&& then_b_p7 = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
        auto&& else_b_o8 = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
        return building_if_f(env_p0, st_p1, prism_rtl::deref(prism_rtl::deref(c_p6)), then_b_p7, else_b_o8, e_p2.span_p, last_p3);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m)) {
        auto&& m15748_2_0 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
        auto&& x_p9 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
        if (m15748_2_0 == Text::lit("@")) {
            auto [t_pa, st2_pb] = crate::check::expr::infer_f(env_p0, st_p1, prism_rtl::deref(prism_rtl::deref(x_p9)));
            return last_p3
                ? std::tuple{t_pa, st2_pb}
                : std::tuple{t_pa, discarded_f(st2_pb, t_pa, e_p2.span_p)};
        }
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x_pc = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return bare_line_f(env_p0, st_p1, prism_rtl::deref(prism_rtl::deref(x_pc)), last_p3);
    }
    {
        auto [t_pd, st1_pe] = crate::check::expr::infer_f(env_p0, st_p1, e_p2);
        auto [res_pg, st2_ph] = ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::St>> _v;
            auto&& _m = crate::check::types::recording::walk_f(st1_pe, t_pd);
            if (prism_rtl::is<crate::check::types::Ty::TyAt>(_m)) {
                _v.set(bind_output_f(env_p0, st1_pe, t_pd, e_p2.span_p));
                goto _done;
            }
            if (prism_rtl::is<crate::check::types::Ty::TyElem>(_m)) {
                _v.set(bind_output_f(env_p0, st1_pe, t_pd, e_p2.span_p));
                goto _done;
            }
            if (prism_rtl::is<crate::check::types::Ty::TyErr>(_m)) {
                _v.set(std::tuple{crate::check::types::t_unit_p(), st1_pe});
                goto _done;
            }
            {
                auto&& other_pf = _m;
                _v.set(is_builder_f(e_p2)
                    ? std::tuple{other_pf, st1_pe}
                    : crate::check::types::recording::walk_f(st1_pe, other_pf) == crate::check::types::t_unit_p()
                    ? std::tuple{crate::check::types::t_unit_p(), st1_pe}
                    : std::tuple{other_pf, crate::check::types::recording::err_fix_f(st1_pe, Text::lit("mismatch"), e_p2.span_p, prism_rtl::cat("a bare line emits an element or builds a blueprint; this is `", crate::check::types::show_ty_f(st1_pe, other_pf), "`"), prism_rtl::cat("end the block on a value with `@ ", crate::check::expr::src_text_f(env_p0, e_p2.span_p), "`"))});
                goto _done;
            }
        _done:
            _v.take();
        });
        return last_p3
            ? std::tuple{res_pg, st2_ph}
            : std::tuple{res_pg, discarded_f(st2_ph, res_pg, e_p2.span_p)};
    }
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> BareLineKind::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& e_p2 = this->e_p2;
    const auto& last_p3 = this->last_p3;
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p2).kind_p);
        prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m) ? ({
        auto&& scrut_p4 = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
        auto&& arms_p5 = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
        prism_rtl::more(prism_rtl::rc(BuildingMatch(env_p0, st_p1, prism_rtl::deref(prism_rtl::deref(scrut_p4)), arms_p5, prism_rtl::deref(e_p2).span_p, prism_rtl::deref(last_p3))));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) ? ({
        auto&& c_p6 = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
        auto&& then_b_p7 = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
        auto&& else_b_o8 = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
        prism_rtl::more(prism_rtl::rc(BuildingIf(env_p0, st_p1, prism_rtl::deref(prism_rtl::deref(c_p6)), then_b_p7, else_b_o8, prism_rtl::deref(e_p2).span_p, prism_rtl::deref(last_p3))));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m) && ({
        auto&& m15748_2_0 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
        auto&& x_p9 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
        (m15748_2_0 == Text::lit("@"));
    }) ? ({
        auto&& m15748_2_0 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
        auto&& x_p9 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
        ({
        auto e_p2x = e_p2;
        auto env_p0x = env_p0;
        auto last_p3x = prism_rtl::deref(last_p3);
        auto st_p1x = st_p1;
        auto x_p9x = prism_rtl::deref(prism_rtl::deref(x_p9));
        (crate::prelude::call_then(crate::check::expr::start_infer_f(env_p0x, st_p1x, x_p9x), [=, e_p2x = std::move(e_p2x), last_p3x = std::move(last_p3x)](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_f_15960) {
        return ({
            auto [t_pa, st2_pb] = infer_f_15960;
            last_p3x
            ? prism_rtl::finished(std::tuple{t_pa, st2_pb})
            : crate::prelude::call_then(start_discarded_f(st2_pb, t_pa, prism_rtl::deref(e_p2x).span_p), [=](crate::check::types::St discarded_f_16017) { return prism_rtl::finished(std::tuple{t_pa, discarded_f_16017}); });
        });
    }));
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
        auto&& x_pc = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(BareLine(env_p0, st_p1, prism_rtl::deref(prism_rtl::deref(x_pc)), prism_rtl::deref(last_p3))));
    })
        : ({
        auto e_p2x = e_p2;
        auto env_p0x = env_p0;
        auto last_p3x = prism_rtl::deref(last_p3);
        auto st_p1x = st_p1;
        (crate::prelude::call_then(crate::check::expr::start_infer_f(env_p0x, st_p1x, e_p2x), [=, last_p3x = std::move(last_p3x)](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_f_16125) {
        return ({
            auto [t_pd, st1_pe] = infer_f_16125;
            (crate::prelude::call_then(crate::check::types::recording::start_walk_f(st1_pe, t_pd), [=](crate::check::types::Ty walk_f_16175) {
            return ({
                auto [res_pg, st2_ph] = ({
                    __label__ _done;
                    prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::St>> _v;
                    if (prism_rtl::is<crate::check::types::Ty::TyAt>(walk_f_16175)) {
                        _v.set(bind_output_f(env_p0x, st1_pe, t_pd, prism_rtl::deref(e_p2x).span_p));
                        goto _done;
                    }
                    if (prism_rtl::is<crate::check::types::Ty::TyElem>(walk_f_16175)) {
                        _v.set(bind_output_f(env_p0x, st1_pe, t_pd, prism_rtl::deref(e_p2x).span_p));
                        goto _done;
                    }
                    if (prism_rtl::is<crate::check::types::Ty::TyErr>(walk_f_16175)) {
                        _v.set(std::tuple{crate::check::types::t_unit_p(), st1_pe});
                        goto _done;
                    }
                    {
                        auto&& other_pf = walk_f_16175;
                        _v.set(is_builder_f(e_p2x)
                            ? std::tuple{other_pf, st1_pe}
                            : crate::check::types::recording::walk_f(st1_pe, other_pf) == crate::check::types::t_unit_p()
                            ? std::tuple{crate::check::types::t_unit_p(), st1_pe}
                            : std::tuple{other_pf, crate::check::types::recording::err_fix_f(st1_pe, Text::lit("mismatch"), prism_rtl::deref(e_p2x).span_p, prism_rtl::cat("a bare line emits an element or builds a blueprint; this is `", crate::check::types::show_ty_f(st1_pe, other_pf), "`"), prism_rtl::cat("end the block on a value with `@ ", crate::check::expr::src_text_f(env_p0x, prism_rtl::deref(e_p2x).span_p), "`"))});
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                last_p3x
                ? prism_rtl::finished(std::tuple{res_pg, st2_ph})
                : crate::prelude::call_then(start_discarded_f(st2_ph, res_pg, prism_rtl::deref(e_p2x).span_p), [=](crate::check::types::St discarded_f_16740) { return prism_rtl::finished(std::tuple{res_pg, discarded_f_16740}); });
            });
        }));
        });
    }));
    });
    });
}


/// `Start BareLineKind, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_bare_line_kind_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Expr e_p2, bool last_p3) {
    return prism_rtl::make_rc<BareLineKind>(env_p0, st_p1, e_p2, last_p3);
}


/// Discarded: unbounded fn St, Ty, Range -> St
crate::check::types::St discarded_f(const crate::check::types::St& st_p0, const crate::check::types::Ty& t_p1, const crate::syntax::Range& span_p2) {
    auto&& _m = crate::check::types::recording::walk_f(st_p0, t_p1);
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
        auto&& m16904_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
        auto&& m16904_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a1;
        if (m16904_0_0 == Text::lit("unit")) {
            if (m16904_0_1.size() == 0u) {
                return st_p0;
            }
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyErr>(_m)) {
        return st_p0;
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFlex>(_m)) {
        return crate::check::types::unify::unify_f(st_p0, crate::check::types::t_unit_p(), t_p1, span_p2);
    }
    {
        auto&& other_p3 = _m;
        return crate::check::types::recording::err_fix_f(st_p0, Text::lit("discarded"), span_p2, prism_rtl::cat("this line\'s result is `", crate::check::types::show_ty_f(st_p0, other_p3), "`; drop it with `ignore <-`"), Text::lit("write `ignore <-` in front of it, or bind it"));
    }
}


prism_rtl::Turn<crate::check::types::St> Discarded::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& t_p1 = this->t_p1;
    const auto& span_p2 = this->span_p2;
    auto span_p2x = span_p2;
    auto st_p0x = st_p0;
    auto t_p1x = t_p1;
    return crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p0x, t_p1x), [=](crate::check::types::Ty walk_f_16910) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TyCon>(walk_f_16910) && ({
            auto&& m16904_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_f_16910).a0;
            auto&& m16904_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_f_16910).a1;
            (m16904_0_0 == Text::lit("unit")) && (m16904_0_1.size() == 0u);
        }) ? ({
            auto&& m16904_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_f_16910).a0;
            auto&& m16904_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_f_16910).a1;
            prism_rtl::finished(st_p0x);
        })
            : prism_rtl::is<crate::check::types::Ty::TyErr>(walk_f_16910) ? prism_rtl::finished(st_p0x)
            : prism_rtl::is<crate::check::types::Ty::TyFlex>(walk_f_16910) ? prism_rtl::more(prism_rtl::rc(crate::check::types::unify::Unify(st_p0x, crate::check::types::t_unit_p(), t_p1x, span_p2x)))
            : ({
            auto&& other_p3 = walk_f_16910;
            crate::prelude::call_then(crate::check::types::start_show_ty_f(st_p0x, other_p3), [=](Text show_ty_f_17073) { return prism_rtl::finished(crate::check::types::recording::err_fix_f(st_p0x, Text::lit("discarded"), span_p2x, prism_rtl::cat("this line\'s result is `", show_ty_f_17073, "`; drop it with `ignore <-`"), Text::lit("write `ignore <-` in front of it, or bind it"))); });
        });
        });
    });
}


/// `Start Discarded, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_discarded_f(crate::check::types::St st_p0, crate::check::types::Ty t_p1, crate::syntax::Range span_p2) {
    return prism_rtl::make_rc<Discarded>(st_p0, t_p1, span_p2);
}


/// BuildingMatch: unbounded fn Env, St, Expr, [Arm], Range, Bool -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> building_match_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Expr& scrut_p2, const Array<crate::syntax::Arm>& arms_p3, const crate::syntax::Range& span_p4, const bool& last_p5) {
    auto [st_ty_pb, st1_pc] = crate::check::expr::infer_f(env_p0, st_p1, scrut_p2);
    auto sh_p6 = crate::check::types::head_sigil_f(st1_pc, st_ty_pb);
    auto st2_p7 = crate::check::expr::is_time_sigil_f(sh_p6)
        ? crate::check::types::recording::err_fix_f(st1_pc, Text::lit("building-match"), scrut_p2.span_p, prism_rtl::cat("a blueprint in a match over a ", sh_p6 == Text::lit("$") ? Text::lit("dynamic") : Text::lit("event"), "; use `rebuild`"), prism_rtl::cat("write `rebuild ", crate::check::expr::src_text_f(env_p0, scrut_p2.span_p), ":` with `match _:` inside"))
        : st1_pc;
    auto plain_scrut_p8 = crate::check::expr::is_time_sigil_f(sh_p6)
        ? crate::check::expr::inner_of_f(st2_p7, st_ty_pb)
        : st_ty_pb;
    auto [res_pd, st3_pe] = crate::check::types::fresh_var_f(st2_p7, false, Text::lit(""));
    auto st4_p9 = crate::prelude::run_to_end(crate::prelude::fold_job(arms_p3, st3_pe, ({
        auto env_p0x = env_p0;
        auto plain_scrut_p8x = plain_scrut_p8;
        auto res_pdx = res_pd;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::Arm>)>>(prism_rtl::rc([=, env_p0x = std::move(env_p0x), plain_scrut_p8x = std::move(plain_scrut_p8x), res_pdx = std::move(res_pdx)](std::tuple<crate::check::types::St, crate::syntax::Arm> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_p0xy = env_p0x;
            auto plain_scrut_p8xy = plain_scrut_p8x;
            auto res_pdxy = res_pdx;
            (crate::prelude::entered(crate::prelude::once_job([=, env_p0xy = std::move(env_p0xy), plain_scrut_p8xy = std::move(plain_scrut_p8xy), res_pdxy = std::move(res_pdxy)]() {
            return ({
                auto s_pf = p0;
                auto arm_pg = p1;
                ({
                auto [env2_pj, s1_pk] = ({
                    __label__ _done;
                    prism_rtl::Slot<std::tuple<crate::check::expr::Env, crate::check::types::St>> _v;
                    auto&& _m = prism_rtl::deref(arm_pg).pattern_o;
                    if (prism_rtl::is_some(_m)) {
                        auto&& p_pi = prism_rtl::some_of(_m);
                        _v.set(crate::check::expr::patterns::bind_pattern_f(env_p0xy, s_pf, p_pi, plain_scrut_p8xy, true));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(std::tuple{env_p0xy, s_pf});
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                auto s2_ph = ({
                    __label__ _done;
                    prism_rtl::Slot<crate::check::types::St> _v;
                    auto&& _m = prism_rtl::deref(arm_pg).guard_o;
                    if (prism_rtl::is_some(_m)) {
                        auto&& gd_pl = prism_rtl::some_of(_m);
                        _v.set(crate::check::expr::lifting::check_cond_f(env2_pj, s1_pk, gd_pl));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(s1_pk);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                auto [bt_pm, s3_pn] = arm_widget_block_f(env2_pj, s2_ph, prism_rtl::deref(arm_pg).body_p);
                (prism_rtl::more(prism_rtl::rc(crate::check::types::unify::Unify(s3_pn, res_pdxy, bt_pm, prism_rtl::deref(prism_rtl::deref(arm_pg).body_p).span_p))));
            });
            });
        })));
        });
    })));
    })));
    auto st5_pa = crate::check::passes::match_coverage_f(env_p0, st4_p9, plain_scrut_p8, arms_p3, span_p4);
    return last_p5
        ? std::tuple{res_pd, st5_pa}
        : std::tuple{res_pd, discarded_f(st5_pa, res_pd, span_p4)};
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> BuildingMatch::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& scrut_p2 = this->scrut_p2;
    const auto& arms_p3 = this->arms_p3;
    const auto& span_p4 = this->span_p4;
    const auto& last_p5 = this->last_p5;
    auto arms_p3x = arms_p3;
    auto env_p0x = env_p0;
    auto last_p5x = prism_rtl::deref(last_p5);
    auto scrut_p2x = scrut_p2;
    auto span_p4x = span_p4;
    auto st_p1x = st_p1;
    return crate::prelude::call_then(crate::check::expr::start_infer_f(env_p0x, st_p1x, scrut_p2x), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_f_17477) {
        return ({
            auto [st_ty_pb, st1_pc] = infer_f_17477;
            (crate::prelude::call_then(crate::check::types::start_head_sigil_f(st1_pc, st_ty_pb), [=](Text head_sigil_f_17511) {
            return ({
                auto sh_p6 = head_sigil_f_17511;
                auto st2_p7 = crate::check::expr::is_time_sigil_f(sh_p6)
                    ? crate::check::types::recording::err_fix_f(st1_pc, Text::lit("building-match"), prism_rtl::deref(scrut_p2x).span_p, prism_rtl::cat("a blueprint in a match over a ", sh_p6 == Text::lit("$") ? Text::lit("dynamic") : Text::lit("event"), "; use `rebuild`"), prism_rtl::cat("write `rebuild ", crate::check::expr::src_text_f(env_p0x, prism_rtl::deref(scrut_p2x).span_p), ":` with `match _:` inside"))
                    : st1_pc;
                auto plain_scrut_p8 = crate::check::expr::is_time_sigil_f(sh_p6)
                    ? crate::check::expr::inner_of_f(st2_p7, st_ty_pb)
                    : st_ty_pb;
                auto [res_pd, st3_pe] = crate::check::types::fresh_var_f(st2_p7, false, Text::lit(""));
                (crate::prelude::call_value(crate::prelude::fold_job(arms_p3x, st3_pe, ({
                auto env_p0xx = env_p0x;
                auto plain_scrut_p8x = plain_scrut_p8;
                auto res_pdx = res_pd;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::Arm>)>>(prism_rtl::rc([=, env_p0xx = std::move(env_p0xx), plain_scrut_p8x = std::move(plain_scrut_p8x), res_pdx = std::move(res_pdx)](std::tuple<crate::check::types::St, crate::syntax::Arm> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto env_p0xxy = env_p0xx;
                    auto plain_scrut_p8xy = plain_scrut_p8x;
                    auto res_pdxy = res_pdx;
                    (crate::prelude::entered(crate::prelude::once_job([=, env_p0xxy = std::move(env_p0xxy), plain_scrut_p8xy = std::move(plain_scrut_p8xy), res_pdxy = std::move(res_pdxy)]() {
                    return ({
                        auto s_pf = p0;
                        auto arm_pg = p1;
                        ({
                        auto [env2_pj, s1_pk] = ({
                            __label__ _done;
                            prism_rtl::Slot<std::tuple<crate::check::expr::Env, crate::check::types::St>> _v;
                            auto&& _m = prism_rtl::deref(arm_pg).pattern_o;
                            if (prism_rtl::is_some(_m)) {
                                auto&& p_pi = prism_rtl::some_of(_m);
                                _v.set(crate::check::expr::patterns::bind_pattern_f(env_p0xxy, s_pf, p_pi, plain_scrut_p8xy, true));
                                goto _done;
                            }
                            if (prism_rtl::is_none(_m)) {
                                _v.set(std::tuple{env_p0xxy, s_pf});
                                goto _done;
                            }
                            prism_rtl::unreachable("no arm matched");
                        _done:
                            _v.take();
                        });
                        auto s2_ph = ({
                            __label__ _done;
                            prism_rtl::Slot<crate::check::types::St> _v;
                            auto&& _m = prism_rtl::deref(arm_pg).guard_o;
                            if (prism_rtl::is_some(_m)) {
                                auto&& gd_pl = prism_rtl::some_of(_m);
                                _v.set(crate::check::expr::lifting::check_cond_f(env2_pj, s1_pk, gd_pl));
                                goto _done;
                            }
                            if (prism_rtl::is_none(_m)) {
                                _v.set(s1_pk);
                                goto _done;
                            }
                            prism_rtl::unreachable("no arm matched");
                        _done:
                            _v.take();
                        });
                        auto [bt_pm, s3_pn] = arm_widget_block_f(env2_pj, s2_ph, prism_rtl::deref(arm_pg).body_p);
                        (prism_rtl::more(prism_rtl::rc(crate::check::types::unify::Unify(s3_pn, res_pdxy, bt_pm, prism_rtl::deref(prism_rtl::deref(arm_pg).body_p).span_p))));
                    });
                    });
                })));
                });
            })));
            })), [=](crate::check::types::St fold_17902) {
                return ({
                    auto st4_p9 = fold_17902;
                    (crate::prelude::call_then(crate::check::passes::start_match_coverage_f(env_p0x, st4_p9, plain_scrut_p8, arms_p3x, span_p4x), [=](crate::check::types::St match_coverage_f_18270) {
                    return ({
                        auto st5_pa = match_coverage_f_18270;
                        last_p5x
                        ? prism_rtl::finished(std::tuple{res_pd, st5_pa})
                        : crate::prelude::call_then(start_discarded_f(st5_pa, res_pd, span_p4x), [=](crate::check::types::St discarded_f_18357) { return prism_rtl::finished(std::tuple{res_pd, discarded_f_18357}); });
                    });
                }));
                });
            }));
            });
        }));
        });
    });
}


/// `Start BuildingMatch, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_building_match_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Expr scrut_p2, Array<crate::syntax::Arm> arms_p3, crate::syntax::Range span_p4, bool last_p5) {
    return prism_rtl::make_rc<BuildingMatch>(env_p0, st_p1, scrut_p2, arms_p3, span_p4, last_p5);
}


/// BuildingIf: unbounded fn Env, St, Cond, Block, ?Block, Range, Bool -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> building_if_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Cond& c_p2, const crate::syntax::Block& then_b_p3, const std::optional<crate::syntax::Block>& else_b_o4, const crate::syntax::Range& span_p5, const bool& last_p6) {
    auto [env2_pk, st1_pl] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::check::expr::Env, crate::check::types::St>> _v;
        if (prism_rtl::is<crate::syntax::Cond::CondExpr>(c_p2)) {
            auto&& e_p7 = prism_rtl::as<crate::syntax::Cond::CondExpr>(c_p2).a0;
            _v.set(({
                auto [ct_pa, s1_pb] = crate::check::expr::infer_f(env_p0, st_p1, prism_rtl::deref(prism_rtl::deref(e_p7)));
                auto sh_p8 = crate::check::types::head_sigil_f(s1_pb, ct_pa);
                auto s2_p9 = crate::check::expr::is_time_sigil_f(sh_p8)
                    ? crate::check::types::recording::err_fix_f(s1_pb, Text::lit("building-match"), prism_rtl::deref(e_p7).span_p, Text::lit("a blueprint in a match over a dynamic; use `rebuild`"), Text::lit("write `rebuild` over the condition, with `if _:` inside"))
                    : s1_pb;
                std::tuple{env_p0, crate::check::types::unify::unify_f(s2_p9, crate::check::types::t_bool_p(), crate::check::expr::is_time_sigil_f(sh_p8)
                ? crate::check::expr::inner_of_f(s2_p9, ct_pa)
                : ct_pa, prism_rtl::deref(e_p7).span_p)};
            }));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::Cond::CondBind>(c_p2)) {
            auto&& p_pc = prism_rtl::as<crate::syntax::Cond::CondBind>(c_p2).a0;
            auto&& e_pd = prism_rtl::as<crate::syntax::Cond::CondBind>(c_p2).a1;
            auto&& gd_oe = prism_rtl::as<crate::syntax::Cond::CondBind>(c_p2).a2;
            _v.set(({
                auto [et_pf, s1_pg] = crate::check::expr::infer_f(env_p0, st_p1, prism_rtl::deref(prism_rtl::deref(e_pd)));
                auto [en_ph, s2_pi] = crate::check::expr::patterns::bind_pattern_f(env_p0, s1_pg, p_pc, et_pf, true);
                ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<crate::check::expr::Env, crate::check::types::St>> _v;
                auto&& _m = prism_rtl::deref(prism_rtl::deref(gd_oe));
                if (prism_rtl::is_some(_m)) {
                    auto&& g_pj = prism_rtl::some_of(_m);
                    _v.set(std::tuple{en_ph, crate::check::expr::lifting::check_cond_f(en_ph, s2_pi, g_pj)});
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(std::tuple{en_ph, s2_pi});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto [t1_pm, st2_pn] = arm_widget_block_f(env2_pk, st1_pl, then_b_p3);
    if (prism_rtl::is_some(else_b_o4)) {
        auto&& b_po = prism_rtl::some_of(else_b_o4);
        auto [t2_pq, st3_pr] = arm_widget_block_f(env_p0, st2_pn, b_po);
        auto st4_pp = crate::check::types::unify::unify_f(st3_pr, t1_pm, t2_pq, prism_rtl::deref(b_po).span_p);
        return last_p6
            ? std::tuple{t1_pm, st4_pp}
            : std::tuple{t1_pm, discarded_f(st4_pp, t1_pm, span_p5)};
    }
    if (prism_rtl::is_none(else_b_o4)) {
        auto st3_ps = crate::check::types::unify::unify_f(st2_pn, crate::check::types::t_unit_p(), t1_pm, then_b_p3.span_p);
        return std::tuple{crate::check::types::t_unit_p(), st3_ps};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> BuildingIf::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& c_p2 = this->c_p2;
    const auto& then_b_p3 = this->then_b_p3;
    const auto& else_b_o4 = this->else_b_o4;
    const auto& span_p5 = this->span_p5;
    const auto& last_p6 = this->last_p6;
    auto [env2_pk, st1_pl] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::check::expr::Env, crate::check::types::St>> _v;
        if (prism_rtl::is<crate::syntax::Cond::CondExpr>(c_p2)) {
            auto&& e_p7 = prism_rtl::as<crate::syntax::Cond::CondExpr>(c_p2).a0;
            _v.set(({
                auto [ct_pa, s1_pb] = crate::check::expr::infer_f(env_p0, st_p1, prism_rtl::deref(prism_rtl::deref(e_p7)));
                auto sh_p8 = crate::check::types::head_sigil_f(s1_pb, ct_pa);
                auto s2_p9 = crate::check::expr::is_time_sigil_f(sh_p8)
                    ? crate::check::types::recording::err_fix_f(s1_pb, Text::lit("building-match"), prism_rtl::deref(e_p7).span_p, Text::lit("a blueprint in a match over a dynamic; use `rebuild`"), Text::lit("write `rebuild` over the condition, with `if _:` inside"))
                    : s1_pb;
                std::tuple{env_p0, crate::check::types::unify::unify_f(s2_p9, crate::check::types::t_bool_p(), crate::check::expr::is_time_sigil_f(sh_p8)
                ? crate::check::expr::inner_of_f(s2_p9, ct_pa)
                : ct_pa, prism_rtl::deref(e_p7).span_p)};
            }));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::Cond::CondBind>(c_p2)) {
            auto&& p_pc = prism_rtl::as<crate::syntax::Cond::CondBind>(c_p2).a0;
            auto&& e_pd = prism_rtl::as<crate::syntax::Cond::CondBind>(c_p2).a1;
            auto&& gd_oe = prism_rtl::as<crate::syntax::Cond::CondBind>(c_p2).a2;
            _v.set(({
                auto [et_pf, s1_pg] = crate::check::expr::infer_f(env_p0, st_p1, prism_rtl::deref(prism_rtl::deref(e_pd)));
                auto [en_ph, s2_pi] = crate::check::expr::patterns::bind_pattern_f(env_p0, s1_pg, p_pc, et_pf, true);
                ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<crate::check::expr::Env, crate::check::types::St>> _v;
                auto&& _m = prism_rtl::deref(prism_rtl::deref(gd_oe));
                if (prism_rtl::is_some(_m)) {
                    auto&& g_pj = prism_rtl::some_of(_m);
                    _v.set(std::tuple{en_ph, crate::check::expr::lifting::check_cond_f(en_ph, s2_pi, g_pj)});
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(std::tuple{en_ph, s2_pi});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto [t1_pm, st2_pn] = arm_widget_block_f(env2_pk, st1_pl, then_b_p3);
    return ({
        prism_rtl::is_some(else_b_o4) ? ({
        auto&& b_po = prism_rtl::some_of(else_b_o4);
        ({
        auto [t2_pq, st3_pr] = arm_widget_block_f(env_p0, st2_pn, b_po);
        auto b_pox = b_po;
        auto last_p6x = prism_rtl::deref(last_p6);
        auto span_p5x = span_p5;
        (crate::prelude::call_then(crate::check::types::unify::start_unify_f(st3_pr, t1_pm, t2_pq, prism_rtl::deref(b_pox).span_p), [=, last_p6x = std::move(last_p6x), span_p5x = std::move(span_p5x)](crate::check::types::St unify_f_19356) {
        return ({
            auto st4_pp = unify_f_19356;
            last_p6x
            ? prism_rtl::finished(std::tuple{t1_pm, st4_pp})
            : crate::prelude::call_then(start_discarded_f(st4_pp, t1_pm, span_p5x), [=](crate::check::types::St discarded_f_19428) { return prism_rtl::finished(std::tuple{t1_pm, discarded_f_19428}); });
        });
    }));
    });
    })
        : prism_rtl::is_none(else_b_o4) ? ({
        auto span_p5x = span_p5;
        auto then_b_p3x = then_b_p3;
        (crate::prelude::call_then(crate::check::types::unify::start_unify_f(st2_pn, crate::check::types::t_unit_p(), t1_pm, prism_rtl::deref(then_b_p3x).span_p), [=](crate::check::types::St unify_f_19490) {
        return ({
            auto st3_ps = unify_f_19490;
            (prism_rtl::finished(std::tuple{crate::check::types::t_unit_p(), st3_ps}));
        });
    }));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start BuildingIf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_building_if_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Cond c_p2, crate::syntax::Block then_b_p3, std::optional<crate::syntax::Block> else_b_o4, crate::syntax::Range span_p5, bool last_p6) {
    return prism_rtl::make_rc<BuildingIf>(env_p0, st_p1, c_p2, then_b_p3, else_b_o4, span_p5, last_p6);
}


/// ArmWidgetBlock: unbounded fn Env, St, Block -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> arm_widget_block_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Block& b_p2) {
    return infer_widget_block_f(env_p0, st_p1, b_p2);
}

}  // namespace crate::check::blocks
