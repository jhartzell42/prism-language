// The module `Lower.Jobs`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <lower/jobs/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>

// The module `Lower.Jobs`, from `target/bootstrap/cpp-src/prismc/lower/jobs.prism`.
namespace crate::lower::jobs {

/// JobDefOf: unbounded fn Lx, Text, [FnClause], Scheme -> JobDef
crate::lower::model::JobDef job_def_of_f(const crate::lower::Lx& lx_p0, const Text& qk_p1, const Array<crate::syntax::decls::FnClause>& clauses_p2, const crate::check::types::Scheme& sc_p3) {
    auto [ptys_pb, res_pc] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Array<crate::check::types::Ty>, crate::check::types::Ty>> _v;
        auto&& _m = sc_p3.ty_p;
        if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
            auto&& ps_p8 = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a1;
            auto&& r_p9 = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a2;
            _v.set(std::tuple{ps_p8, prism_rtl::deref(prism_rtl::deref(r_p9))});
            goto _done;
        }
        {
            auto&& other_pa = _m;
            _v.set(std::tuple{Array<crate::check::types::Ty>{}, other_pa});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto pts_p4 = crate::prelude::run_to_end(crate::prelude::each_job(ptys_pb, ({
        auto lx_p0x = lx_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::OutTy>(crate::check::types::Ty)>>(prism_rtl::rc([=, lx_p0x = std::move(lx_p0x)](crate::check::types::Ty p0) {
        return ({
            auto lx_p0xy = lx_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xy = std::move(lx_p0xy)]() {
            return ({
                auto p_pd = p0;
                (prism_rtl::more(prism_rtl::rc(crate::lower::types::OutTyOf(lx_p0xy, crate::lower::types::peel_f(p_pd)))));
            });
        })));
        });
    })));
    })));
    auto names_p5 = crate::lower::functions::param_names_f(lx_p0, clauses_p2, pts_p4);
    auto body_p6 = job_clauses_f(lx_p0, clauses_p2, names_p5, ptys_pb, pts_p4);
    auto base_p7 = crate::prelude::or_(crate::prelude::get(lx_p0.rs_names_p, qk_p1), crate::lower::snake_f(crate::check::types::bare_name_f(qk_p1)));
    return crate::lower::model::JobDef{.name_p = crate::lower::camel_f(crate::check::types::bare_name_f(qk_p1)), .start_p = prism_rtl::cat("start_", base_p7), .generics_p = crate::lower::functions::scheme_generics_f(lx_p0, sc_p3), .fields_p = crate::prelude::each(crate::check::errors::range0_f(crate::prelude::len(pts_p4)), [&](const Nat& i_pe) {
        return std::tuple{crate::prelude::or_(crate::prelude::index(crate::prelude::each(names_p5, [&](const std::tuple<Text, bool>& _p0) {
            auto&& n_pf = std::get<0>(_p0);
            return n_pf;
        }), i_pe), Text::lit("arg")), crate::prelude::or_(crate::prelude::index(pts_p4, i_pe), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}))};
    }), .ret_p = crate::lower::types::out_ty_of_f(lx_p0, crate::lower::types::peel_f(res_pc)), .body_p = body_p6, .doc_p = crate::lower::functions::signature_text_f(lx_p0, qk_p1)};
}


prism_rtl::Turn<crate::lower::model::JobDef> JobDefOf::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& qk_p1 = this->qk_p1;
    const auto& clauses_p2 = this->clauses_p2;
    const auto& sc_p3 = this->sc_p3;
    auto [ptys_pb, res_pc] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Array<crate::check::types::Ty>, crate::check::types::Ty>> _v;
        auto&& _m = prism_rtl::deref(sc_p3).ty_p;
        if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
            auto&& ps_p8 = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a1;
            auto&& r_p9 = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a2;
            _v.set(std::tuple{ps_p8, prism_rtl::deref(prism_rtl::deref(r_p9))});
            goto _done;
        }
        {
            auto&& other_pa = _m;
            _v.set(std::tuple{Array<crate::check::types::Ty>{}, other_pa});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto clauses_p2x = clauses_p2;
    auto lx_p0x = lx_p0;
    auto qk_p1x = qk_p1;
    auto sc_p3x = sc_p3;
    return crate::prelude::call_value(crate::prelude::each_job(ptys_pb, ({
        auto lx_p0xx = lx_p0x;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::OutTy>(crate::check::types::Ty)>>(prism_rtl::rc([=, lx_p0xx = std::move(lx_p0xx)](crate::check::types::Ty p0) {
        return ({
            auto lx_p0xxy = lx_p0xx;
            (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xxy = std::move(lx_p0xxy)]() {
            return ({
                auto p_pd = p0;
                (prism_rtl::more(prism_rtl::rc(crate::lower::types::OutTyOf(lx_p0xxy, crate::lower::types::peel_f(p_pd)))));
            });
        })));
        });
    })));
    })), [=](Array<crate::lower::model::OutTy> each_32535) {
        return ({
            auto pts_p4 = each_32535;
            (crate::prelude::call_then(crate::lower::functions::start_param_names_f(lx_p0x, clauses_p2x, pts_p4), [=](Array<std::tuple<Text, bool>> param_names_f_32588) {
            return ({
                auto names_p5 = param_names_f_32588;
                (crate::prelude::call_then(start_job_clauses_f(lx_p0x, clauses_p2x, names_p5, ptys_pb, pts_p4), [=](crate::lower::model::Ex job_clauses_f_32631) {
                return ({
                    auto body_p6 = job_clauses_f_32631;
                    auto base_p7 = crate::prelude::or_(crate::prelude::get(prism_rtl::deref(lx_p0x).rs_names_p, qk_p1x), crate::lower::snake_f(crate::check::types::bare_name_f(qk_p1x)));
                    (crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0x, crate::lower::types::peel_f(res_pc)), [=, body_p6 = std::move(body_p6), base_p7 = std::move(base_p7)](crate::lower::model::OutTy out_ty_of_f_32942) {
                    return prism_rtl::finished(crate::lower::model::JobDef{.name_p = crate::lower::camel_f(crate::check::types::bare_name_f(qk_p1x)), .start_p = prism_rtl::cat("start_", base_p7), .generics_p = crate::lower::functions::scheme_generics_f(lx_p0x, sc_p3x), .fields_p = crate::prelude::each(crate::check::errors::range0_f(crate::prelude::len(pts_p4)), [&](const Nat& i_pe) {
                        return std::tuple{crate::prelude::or_(crate::prelude::index(crate::prelude::each(names_p5, [&](const std::tuple<Text, bool>& _p0) {
                            auto&& n_pf = std::get<0>(_p0);
                            return n_pf;
                        }), i_pe), Text::lit("arg")), crate::prelude::or_(crate::prelude::index(pts_p4, i_pe), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}))};
                    }), .ret_p = out_ty_of_f_32942, .body_p = body_p6, .doc_p = crate::lower::functions::signature_text_f(lx_p0x, qk_p1x)});
                }));
                });
            }));
            });
        }));
        });
    });
}


/// `Start JobDefOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::JobDef> start_job_def_of_f(crate::lower::Lx lx_p0, Text qk_p1, Array<crate::syntax::decls::FnClause> clauses_p2, crate::check::types::Scheme sc_p3) {
    return prism_rtl::make_rc<JobDefOf>(lx_p0, qk_p1, clauses_p2, sc_p3);
}


/// JobClauses: unbounded fn Lx, [FnClause], [((Text, Bool))], [Ty], [OutTy] -> Ex
crate::lower::model::Ex job_clauses_f(const crate::lower::Lx& lx_p0, const Array<crate::syntax::decls::FnClause>& clauses_p1, const Array<std::tuple<Text, bool>>& names_p2, const Array<crate::check::types::Ty>& ptys_p3, const Array<crate::lower::model::OutTy>& pts_p4) {
    auto lets_p5 = crate::prelude::each(crate::check::errors::range0_f(crate::prelude::len(names_p2)), [&](const Nat& i_p7) {
        return ({
            auto&& _rs_p8 = crate::prelude::or_(crate::prelude::index(names_p2, i_p7), std::tuple{Text::lit("arg"), true});
            auto&& rs_p8 = std::get<0>(_rs_p8);
            (crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{rs_p8}), crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), rs_p8}))})}));
        });
    });
    auto inner_p6 = crate::lower::functions::clauses_body_f(lx_p0, crate::lower::types::empty_env_p(), clauses_p1, names_p2, ptys_p3, static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::Lx, crate::lower::types::Env, crate::syntax::decls::FnBody>)>>(prism_rtl::rc([&](std::tuple<crate::lower::Lx, crate::lower::types::Env, crate::syntax::decls::FnBody> _p0) {
        auto&& a0 = std::get<0>(_p0);
        auto&& a1 = std::get<1>(_p0);
        auto&& a2 = std::get<2>(_p0);
        return crate::prelude::entered(start_tail_body_f(a0, a1, a2));
    })), Text::lit("j"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutTurn{}));
    return crate::lower::model::Ex(crate::lower::model::Ex::XBlock{lets_p5, prism_rtl::rc(inner_p6)});
}


prism_rtl::Turn<crate::lower::model::Ex> JobClauses::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& clauses_p1 = this->clauses_p1;
    const auto& names_p2 = this->names_p2;
    const auto& ptys_p3 = this->ptys_p3;
    const auto& pts_p4 = this->pts_p4;
    auto lets_p5 = crate::prelude::each(crate::check::errors::range0_f(crate::prelude::len(names_p2)), [&](const Nat& i_p7) {
        return ({
            auto&& _rs_p8 = crate::prelude::or_(crate::prelude::index(names_p2, i_p7), std::tuple{Text::lit("arg"), true});
            auto&& rs_p8 = std::get<0>(_rs_p8);
            (crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{rs_p8}), crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), rs_p8}))})}));
        });
    });
    auto clauses_p1x = clauses_p1;
    auto lx_p0x = lx_p0;
    auto names_p2x = names_p2;
    auto ptys_p3x = ptys_p3;
    return crate::prelude::call_then(crate::lower::functions::start_clauses_body_f(lx_p0x, crate::lower::types::empty_env_p(), clauses_p1x, names_p2x, ptys_p3x, static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::Lx, crate::lower::types::Env, crate::syntax::decls::FnBody>)>>(prism_rtl::rc([&](std::tuple<crate::lower::Lx, crate::lower::types::Env, crate::syntax::decls::FnBody> _p0) {
        auto&& a0 = std::get<0>(_p0);
        auto&& a1 = std::get<1>(_p0);
        auto&& a2 = std::get<2>(_p0);
        return crate::prelude::entered(start_tail_body_f(a0, a1, a2));
    })), Text::lit("j"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutTurn{})), [=](crate::lower::model::Ex clauses_body_f_33371) {
        return ({
            auto inner_p6 = clauses_body_f_33371;
            (prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XBlock{lets_p5, prism_rtl::rc(inner_p6)})));
        });
    });
}


/// `Start JobClauses, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Ex> start_job_clauses_f(crate::lower::Lx lx_p0, Array<crate::syntax::decls::FnClause> clauses_p1, Array<std::tuple<Text, bool>> names_p2, Array<crate::check::types::Ty> ptys_p3, Array<crate::lower::model::OutTy> pts_p4) {
    return prism_rtl::make_rc<JobClauses>(lx_p0, clauses_p1, names_p2, ptys_p3, pts_p4);
}

}  // namespace crate::lower::jobs
