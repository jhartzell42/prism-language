// The module `CheckExpr`: its types, nodes and jobs declared, and its choices' handles, emitted by
// prismc (docs/backend.md). Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace check_expr {

struct Env;

struct Peeled;

struct InnerOf;

struct Infer;

struct InferKind;

struct InferAll;

struct Check;

struct CheckAny;

struct InferName;

struct InferNameIn;

struct InstantiateLocal;

struct InferGlobal;

struct CtorValue;

struct TagValue;

struct InferLit;

struct InferText;

struct ShowWant;

struct InferArray;

struct InferMap;

struct InferBinary;

struct QuotientOf;

struct SubWant;

struct InferOn;

struct InferUnary;

struct InferFreeSigil;

struct InferField;

struct FieldType;

struct InferIndex;

struct InferCall;

struct CallGlobal;

struct RankTwo;

struct Escaped;

struct HasRigid;

struct FoldApp;

struct ApplyFn;

struct ApplyRule;

struct PlainArg;

struct LayeredArg;

struct PeelTimeOnly;

struct CtorApp;

struct TagApp;

struct TagField;

struct InferLambda;

struct InferBareLambda;

struct InferBodyBlock;

struct BindPattern;

struct BindName;

struct BindFresh;

struct BindFreshMarked;

struct BindField;

struct BindLevel;

struct BindCtor;

struct BindRecord;

struct BindTagPattern;

struct IsSnapshot;

struct TagInRow;

struct BindFamily;

struct InferMatch;

struct Narrowed;

struct InferArm;

struct ArmAgainst;

struct CheckCond;

struct SubstRigid;

struct MatchResult;

struct InferIf;

struct UnifyArm;

struct IfBranches;

struct InferExprBlock;

struct BindGroup;

struct PreBind;

struct CheckGroupStmt;

struct CheckLet;

struct AheadUnify;

struct WantsAbove;

struct CheckLocalFn;

struct ClauseLambda;

struct CheckClauses;

struct CheckClause;

struct CheckBody;

struct InferTemplate;

struct TemplatePartCheck;

struct TemplateCallCheck;

struct TemplateMissing;

struct TemplateSlot;

}  // namespace check_expr


}  // namespace crate
