// The module `CheckPasses`, from `target/bootstrap/cpp-src/prismc/check-passes.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (docs/backend.md). Edit the Prism source, not this file.
#include "crate.hpp"

namespace crate::check_passes {

/// DefaultDef: unbounded fn G, St -> St
check_types::St default_def(const check_env::G& g, const check_types::St& st) {
    auto mine = run_to_end(filter_job(st.wants, ({
        auto st_1 = st;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(check_types::Want)>>(prism_rtl::rc([=](check_types::Want p0) {
        return ({
            auto st_1_2 = st_1;
            entered(once_job([=]() {
            return ({
                auto w = p0;
                call_then(check_types::start_walk(st_1_2, w.ty), [=](check_types::Ty walk_128588) {
                return ({
                    prism_rtl::is<check_types::Ty::TyFlex>(walk_128588) ? ({
                    auto&& n = prism_rtl::as<check_types::Ty::TyFlex>(walk_128588).a0;
                    prism_rtl::finished(check_types::info_of(st_1_2, n).level >= Nat(1u));
                })
                    : prism_rtl::finished(true);
                });
            });
            });
        }));
        });
    })));
    })));
    auto theirs = run_to_end(filter_job(st.wants, ({
        auto st_1 = st;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(check_types::Want)>>(prism_rtl::rc([=](check_types::Want p0) {
        return ({
            auto st_1_2 = st_1;
            entered(once_job([=]() {
            return ({
                auto w = p0;
                call_then(check_types::start_walk(st_1_2, w.ty), [=](check_types::Ty walk_128716) {
                return ({
                    prism_rtl::is<check_types::Ty::TyFlex>(walk_128716) ? ({
                    auto&& n = prism_rtl::as<check_types::Ty::TyFlex>(walk_128716).a0;
                    prism_rtl::finished(check_types::info_of(st_1_2, n).level < Nat(1u));
                })
                    : prism_rtl::finished(false);
                });
            });
            });
        }));
        });
    })));
    })));
    auto st1 = ({
        check_types::St this_ = st;
        this_.wants = mine;
        this_;
    });
    auto s2 = check_env::default_wants(g, st1, Array<std::tuple<Text, Text>>{});
    check_types::St this_ = s2;
    this_.wants = append(theirs, this_.wants);
    return this_;
}


prism_rtl::Turn<check_types::St> DefaultDef::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    auto g_1 = g;
    auto st_2 = st;
    return call_value(filter_job(st_2.wants, ({
        auto st_2_3 = st_2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(check_types::Want)>>(prism_rtl::rc([=](check_types::Want p0) {
        return ({
            auto st_2_3_3 = st_2_3;
            entered(once_job([=]() {
            return ({
                auto w = p0;
                call_then(check_types::start_walk(st_2_3_3, w.ty), [=](check_types::Ty walk_128588) {
                return ({
                    prism_rtl::is<check_types::Ty::TyFlex>(walk_128588) ? ({
                    auto&& n = prism_rtl::as<check_types::Ty::TyFlex>(walk_128588).a0;
                    prism_rtl::finished(check_types::info_of(st_2_3_3, n).level >= Nat(1u));
                })
                    : prism_rtl::finished(true);
                });
            });
            });
        }));
        });
    })));
    })), [=](Array<check_types::Want> filter_128560) {
        return ({
            auto mine = filter_128560;
            call_value(filter_job(st_2.wants, ({
            auto st_2_3 = st_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(check_types::Want)>>(prism_rtl::rc([=](check_types::Want p0) {
            return ({
                auto st_2_3_3 = st_2_3;
                entered(once_job([=]() {
                return ({
                    auto w = p0;
                    call_then(check_types::start_walk(st_2_3_3, w.ty), [=](check_types::Ty walk_128716) {
                    return ({
                        prism_rtl::is<check_types::Ty::TyFlex>(walk_128716) ? ({
                        auto&& n = prism_rtl::as<check_types::Ty::TyFlex>(walk_128716).a0;
                        prism_rtl::finished(check_types::info_of(st_2_3_3, n).level < Nat(1u));
                    })
                        : prism_rtl::finished(false);
                    });
                });
                });
            }));
            });
        })));
        })), [=](Array<check_types::Want> filter_128688) {
            return ({
                auto theirs = filter_128688;
                auto st1 = ({
                    check_types::St this_ = st_2;
                    this_.wants = mine;
                    this_;
                });
                call_then(check_env::start_default_wants(g_1, st1, Array<std::tuple<Text, Text>>{}), [=](check_types::St default_wants_128862) {
                return ({
                    auto s2 = default_wants_128862;
                    (prism_rtl::finished(({
                    check_types::St this_ = s2;
                    this_.wants = append(theirs, this_.wants);
                    this_;
                })));
                });
            });
            });
        });
        });
    });
}


/// `Start DefaultDef, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<check_types::St> start_default_def(check_env::G g, check_types::St st) {
    return std::make_shared<DefaultDef>(g, st);
}


/// CheckWidgetDef: unbounded fn Env, St, Def, WidgetDecl -> St
check_types::St check_widget_def(const check_expr::Env& env, const check_types::St& st, const check_env::Def& d, const ast::WidgetDecl& w) {
    return ({
        __label__ _done;
        prism_rtl::Slot<check_types::St> _v;
        auto&& _m = prelude::get(env.g.vals, d.qk);
        if (prism_rtl::is_some(_m)) {
            auto&& v_ = prism_rtl::some_of(_m);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<check_types::St> _v;
                auto&& _m = check_types::skolemize(v_.scheme);
                if (prism_rtl::is<check_types::Ty::TyAt>(_m)) {
                    auto&& inner = prism_rtl::as<check_types::Ty::TyAt>(_m).a0;
                    auto&& rw = prism_rtl::as<check_types::Ty::TyAt>(_m).a1;
                    _v.set(({
                        auto env2 = ({
                            check_expr::Env this_ = env;
                            this_.scope = rw;
                            this_.mark = Text("@");
                            this_;
                        });
                        auto [t, st2] = check_blocks::infer_widget_block(env2, st, w.body);
                        (check_types::note_fn(check_types::unify(st2, inner, t, w.span), w.span, d.name, check_types::Col(check_types::Col::CBound{}), st2.color));
                    }));
                    goto _done;
                }
                {
                    auto&& other = _m;
                    _v.set(check_types::err(st, Text("mismatch"), w.span, prism_rtl::cat("`", d.name, "` is declared `", check_types::show_ty(st, other), "`; a widget block builds a blueprint")));
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(({
                auto [t, st2] = check_blocks::infer_widget_block(env, st, w.body);
                (check_types::note_fn(st2, w.span, d.name, check_types::Col(check_types::Col::CBound{}), st2.color));
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<check_types::St> CheckWidgetDef::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& d = this->d;
    const auto& w = this->w;
    return ({
        auto&& _m = prelude::get(env.g.vals, d.qk);
        prism_rtl::is_some(_m) ? ({
        auto&& v_ = prism_rtl::some_of(_m);
        ({
        auto d_1 = d;
        auto env_2 = env;
        auto st_3 = st;
        auto w_4 = w;
        call_then(check_types::start_skolemize(v_.scheme), [=](check_types::Ty skolemize_129168) {
        return ({
            prism_rtl::is<check_types::Ty::TyAt>(skolemize_129168) ? ({
            auto&& inner = prism_rtl::as<check_types::Ty::TyAt>(skolemize_129168).a0;
            auto&& rw = prism_rtl::as<check_types::Ty::TyAt>(skolemize_129168).a1;
            ({
            auto env2 = ({
                check_expr::Env this_ = env_2;
                this_.scope = rw;
                this_.mark = Text("@");
                this_;
            });
            call_then(check_blocks::start_infer_widget_block(env2, st_3, w_4.body), [=](std::tuple<check_types::Ty, check_types::St> infer_widget_block_129338) {
            return ({
                auto [t, st2] = infer_widget_block_129338;
                call_then(check_types::start_unify(st2, inner, t, w_4.span), [=](check_types::St unify_129392) { return prism_rtl::finished(check_types::note_fn(unify_129392, w_4.span, d_1.name, check_types::Col(check_types::Col::CBound{}), st2.color)); });
            });
        });
        });
        })
            : ({
            auto&& other = skolemize_129168;
            call_then(check_types::start_show_ty(st_3, other), [=](Text show_ty_129525) { return prism_rtl::finished(check_types::err(st_3, Text("mismatch"), w_4.span, prism_rtl::cat("`", d_1.name, "` is declared `", show_ty_129525, "`; a widget block builds a blueprint"))); });
        });
        });
    });
    });
    })
        : prism_rtl::is_none(_m) ? ({
        auto d_1 = d;
        auto env_2 = env;
        auto st_3 = st;
        auto w_4 = w;
        call_then(check_blocks::start_infer_widget_block(env_2, st_3, w_4.body), [=](std::tuple<check_types::Ty, check_types::St> infer_widget_block_129614) {
        return ({
            auto [t, st2] = infer_widget_block_129614;
            (prism_rtl::finished(check_types::note_fn(st2, w_4.span, d_1.name, check_types::Col(check_types::Col::CBound{}), st2.color)));
        });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CheckWidgetDef, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<check_types::St> start_check_widget_def(check_expr::Env env, check_types::St st, check_env::Def d, ast::WidgetDecl w) {
    return std::make_shared<CheckWidgetDef>(env, st, d, w);
}


/// ?MethodKey: fn G, Text, Text -> ?Text
std::optional<Text> method_key(const check_env::G& g, const Text& cls, const Text& name) {
    return fold(or_(prelude::get(g.traits, cls), check_env::dummy_trait()).methods, std::optional<Text>{}, [&](const std::optional<Text>& found_opt, const Text& k) {
        return ({
            __label__ _done;
            prism_rtl::Slot<std::optional<Text>> _v;
            if (prism_rtl::is_some(found_opt)) {
                auto&& f = prism_rtl::some_of(found_opt);
                _v.set(std::optional(f));
                goto _done;
            }
            if (prism_rtl::is_none(found_opt)) {
                _v.set((check_types::bare_name(k) == name) || (drop_text(k, len_text(or_(prelude::get(g.traits, cls), check_env::dummy_trait()).home) + Nat(1u)) == name)
                    ? std::optional(k)
                    : std::optional<Text>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
}


/// CheckMethod: unbounded fn Env, St, Def, [FnClause], Text, ImplInfo -> St
check_types::St check_method(const check_expr::Env& env, const check_types::St& st, const check_env::Def& d, const Array<ast::FnClause>& clauses, const Text& cls, const check_env::ImplInfo& im) {
    return ({
        __label__ _done;
        prism_rtl::Slot<check_types::St> _v;
        auto&& _m = method_key(env.g, cls, d.name);
        if (prism_rtl::is_none(_m)) {
            _v.set(check_types::err(st, Text("mismatch"), d.span, prism_rtl::cat("`^", check_types::bare_name(cls), "` has no method `", d.name, "`")));
            goto _done;
        }
        if (prism_rtl::is_some(_m)) {
            auto&& mk = prism_rtl::some_of(_m);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<check_types::St> _v;
                auto&& _m = prelude::get(env.g.vals, mk);
                if (prism_rtl::is_none(_m)) {
                    _v.set(st);
                    goto _done;
                }
                if (prism_rtl::is_some(_m)) {
                    auto&& v_ = prism_rtl::some_of(_m);
                    _v.set(({
                        auto ti = or_(prelude::get(env.g.traits, cls), check_env::dummy_trait());
                        auto head = check_types::subst_q(check_types::Inst{.tys = fold(im.qs, Map<Text, check_types::Ty>{}, [&](const Map<Text, check_types::Ty>& m, const Text& q) { return insert(m, q, check_types::Ty(check_types::Ty::TyRigid{q})); }), .rows = Map<Text, check_types::Tail>{}, .cols = Map<Text, check_types::Col>{}}, im.head);
                        auto ty = check_types::subst_q(check_types::Inst{.tys = map_of(std::vector{std::tuple{ti.param, head}}), .rows = Map<Text, check_types::Tail>{}, .cols = Map<Text, check_types::Col>{}}, v_.scheme.ty);
                        auto sc = check_types::Scheme{.qs = filter(v_.scheme.qs, [&](const Text& q) { return q != ti.param; }), .plain_qs = Array<Text>{}, .rqs = v_.scheme.rqs, .cqs = v_.scheme.cqs, .cjoins = v_.scheme.cjoins, .bounds = filter(v_.scheme.bounds, [&](const std::tuple<Text, Text>& _p0) {
                            auto&& q = std::get<0>(_p0);
                            return q != ti.param;
                        }), .ty = ty};
                        auto env2 = ({
                            check_expr::Env this_ = env;
                            this_.givens = im.bounds;
                            this_;
                        });
                        (check_expr::check_clauses(env2, st, d.name, clauses, sc, d.span));
                    }));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<check_types::St> CheckMethod::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& d = this->d;
    const auto& clauses = this->clauses;
    const auto& cls = this->cls;
    const auto& im = this->im;
    return ({
        auto&& _m = method_key(env.g, cls, d.name);
        prism_rtl::is_none(_m) ? prism_rtl::finished(check_types::err(st, Text("mismatch"), d.span, prism_rtl::cat("`^", check_types::bare_name(cls), "` has no method `", d.name, "`")))
        : prism_rtl::is_some(_m) ? ({
        auto&& mk = prism_rtl::some_of(_m);
        ({
        auto&& _m = prelude::get(env.g.vals, mk);
        prism_rtl::is_none(_m) ? prism_rtl::finished(st)
        : prism_rtl::is_some(_m) ? ({
        auto&& v_ = prism_rtl::some_of(_m);
        ({
        auto ti = or_(prelude::get(env.g.traits, cls), check_env::dummy_trait());
        auto clauses_1 = clauses;
        auto d_2 = d;
        auto env_3 = env;
        auto im_4 = im;
        auto st_5 = st;
        call_then(check_types::start_subst_q(check_types::Inst{.tys = fold(im_4.qs, Map<Text, check_types::Ty>{}, [&](const Map<Text, check_types::Ty>& m, const Text& q) { return insert(m, q, check_types::Ty(check_types::Ty::TyRigid{q})); }), .rows = Map<Text, check_types::Tail>{}, .cols = Map<Text, check_types::Col>{}}, im_4.head), [=](check_types::Ty subst_q_130484) {
        return ({
            auto head = subst_q_130484;
            call_then(check_types::start_subst_q(check_types::Inst{.tys = map_of(std::vector{std::tuple{ti.param, head}}), .rows = Map<Text, check_types::Tail>{}, .cols = Map<Text, check_types::Col>{}}, v_.scheme.ty), [=](check_types::Ty subst_q_130602) {
            return ({
                auto ty = subst_q_130602;
                auto sc = check_types::Scheme{.qs = filter(v_.scheme.qs, [&](const Text& q) { return q != ti.param; }), .plain_qs = Array<Text>{}, .rqs = v_.scheme.rqs, .cqs = v_.scheme.cqs, .cjoins = v_.scheme.cjoins, .bounds = filter(v_.scheme.bounds, [&](const std::tuple<Text, Text>& _p0) {
                    auto&& q = std::get<0>(_p0);
                    return q != ti.param;
                }), .ty = ty};
                auto env2 = ({
                    check_expr::Env this_ = env_3;
                    this_.givens = im_4.bounds;
                    this_;
                });
                (prism_rtl::more(prism_rtl::rc(check_expr::CheckClauses(env2, st_5, d_2.name, clauses_1, sc, d_2.span))));
            });
        });
        });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CheckMethod, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<check_types::St> start_check_method(check_expr::Env env, check_types::St st, check_env::Def d, Array<ast::FnClause> clauses, Text cls, check_env::ImplInfo im) {
    return std::make_shared<CheckMethod>(env, st, d, clauses, cls, im);
}


/// RootRow: unbounded fn G, St, [Text] -> ((Text, St))
std::tuple<Text, check_types::St> root_row(const check_env::G& g, const check_types::St& st, const Array<Text>& world) {
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Text, check_types::St>> _v;
        auto&& _m = prelude::get(g.mods, Text(""));
        if (prism_rtl::is_none(_m)) {
            _v.set(std::tuple{Text(""), st});
            goto _done;
        }
        if (prism_rtl::is_some(_m)) {
            auto&& info = prism_rtl::some_of(_m);
            _v.set(({
                auto shown = check_types::show_row(info.emit_rw);
                len(world) == Nat(0u)
                ? std::tuple{shown, st}
                : ({
                auto missing = filter(info.emit_rw.fams, [&](const Text& f) { return !check_types::has_text(world, f); });
                len(missing) == Nat(0u)
                ? std::tuple{shown, st}
                : ({
                auto s0 = ({
                    check_types::St this_ = st;
                    this_.file = info->file;
                    this_;
                });
                std::tuple{shown, check_types::err_fix(s0, Text("world-row"), info.tree.span, prism_rtl::cat("the program emits ", lexer::join(each(missing, [&](const Text& f) { return prism_rtl::cat("`", f, ".*`"); }), Text(", ")), ", which this World does not answer"), Text("host the tags it cannot answer, or run under a World that answers them"))};
            });
            });
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::tuple<Text, check_types::St>> RootRow::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    const auto& world = this->world;
    return ({
        auto&& _m = prelude::get(g.mods, Text(""));
        prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{Text(""), st})
        : prism_rtl::is_some(_m) ? ({
        auto&& info = prism_rtl::some_of(_m);
        ({
        auto shown = check_types::show_row(info.emit_rw);
        len(world) == Nat(0u)
        ? prism_rtl::finished(std::tuple{shown, st})
        : ({
        auto missing = filter(info.emit_rw.fams, [&](const Text& f) { return !check_types::has_text(world, f); });
        len(missing) == Nat(0u)
        ? prism_rtl::finished(std::tuple{shown, st})
        : ({
        auto s0 = ({
            check_types::St this_ = st;
            this_.file = info->file;
            this_;
        });
        (prism_rtl::finished(std::tuple{shown, check_types::err_fix(s0, Text("world-row"), info.tree.span, prism_rtl::cat("the program emits ", lexer::join(each(missing, [&](const Text& f) { return prism_rtl::cat("`", f, ".*`"); }), Text(", ")), ", which this World does not answer"), Text("host the tags it cannot answer, or run under a World that answers them"))}));
    });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start RootRow, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Text, check_types::St>> start_root_row(check_env::G g, check_types::St st, Array<Text> world) {
    return std::make_shared<RootRow>(g, st, world);
}

}  // namespace crate::check_passes
