// The module `Lower`, from `target/bootstrap/cpp-src/prismc/lower.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (docs/backend.md). Edit the Prism source, not this file.
#include "crate.hpp"

namespace crate::lower {

prism_rtl::Turn<Do> UpdForRefs::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& n = this->n;
    const auto& source = this->source;
    const auto& body = this->body;
    const auto& span = this->span;
    const auto& sty = this->sty;
    return ({
        prism_rtl::is<check_types::Ty::TyArray>(sty) ? ({
        auto&& v_ = prism_rtl::as<check_types::Ty::TyArray>(sty).a0;
        ({
        auto key_name = prism_rtl::cat("k", span.start);
        auto ref_name = prism_rtl::cat("r", span.start);
        auto body_1 = body;
        auto env_2 = env;
        auto lx_3 = lx;
        auto n_4 = n;
        auto source_5 = source;
        auto span_6 = span;
        auto v__7 = v_;
        call_then(start_out_ty_of(lx_3, v__7), [=](OutTy out_ty_of_131219) {
        return ({
            auto env1 = bind(bind(bind(env_2, Text("key"), Bn(Bn::BnLocal{Ex(Ex::XVar{key_name}), Holding(Holding::Owned{}), OutTy(OutTy::OutNat{})})), Text("ix"), Bn(Bn::BnLocal{Ex(Ex::XVar{key_name}), Holding(Holding::Owned{}), OutTy(OutTy::OutNat{})})), check_env::sname_key(n_4), Bn(Bn::BnLocal{Ex(Ex::XTarget{prism_rtl::rc(Ex(Ex::XVar{ref_name}))}), Holding(Holding::Owned{}), out_ty_of_131219}));
            call_then(start_upd_stmts(lx_3, env1, body_1.stmts), [=](std::tuple<Array<Do>, Env> upd_stmts_131265) {
            return ({
                auto&& _dos = upd_stmts_131265;
                auto&& dos = std::get<0>(_dos);
                auto head = Do(Do::DoLet{Pa(Pa::PaBind{key_name}), Ex(Ex::XCall{Text("nat_of"), Array(std::vector{Ex(Ex::XVar{prism_rtl::cat("i", span_6.start)})})})});
                call_then(start_place_of(lx_3, env_2, source_5), [=](Ex place_of_131474) { return prism_rtl::finished(Do(Do::DoFor{Pa(Pa::PaTuple{Array(std::vector{Pa(Pa::PaBind{prism_rtl::cat("i", span_6.start)}), Pa(Pa::PaBind{ref_name})})}), Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(place_of_131474), Text("iter_mut"), Array<Ex>{}})), Text("enumerate"), Array<Ex>{}}), append(Array(std::vector{head}), dos)})); });
            });
        });
        });
    });
    });
    })
        : prism_rtl::finished(refusal_do(Text("a `for` by reference over what is not an array")));
    });
}


/// `Start UpdForRefs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Do> start_upd_for_refs(Lx lx, Env env, ast::SName n, ast::Expr source, ast::Block body, ast::Range span, check_types::Ty sty) {
    return std::make_shared<UpdForRefs>(lx, env, n, source, body, span, sty);
}


/// ?RefBinder: fn ?ForBinders -> ?SName
std::optional<ast::SName> ref_binder(const std::optional<ast::ForBinders>& opt0) {
    return ({
        __label__ _done;
        prism_rtl::Slot<std::optional<ast::SName>> _v;
        if (prism_rtl::is_some(opt0)) {
            auto&& fb = prism_rtl::some_of(opt0);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::optional<ast::SName>> _v;
                auto&& _m = fb.second;
                if (prism_rtl::is_none(_m)) {
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<std::optional<ast::SName>> _v;
                        auto&& _m = fb.first.kind;
                        if (prism_rtl::is<ast::PatternKind::PName>(_m)) {
                            auto&& n = prism_rtl::as<ast::PatternKind::PName>(_m).a0;
                            _v.set(take_text(n.sigils, Nat(1u)) == Text("&")
                                ? std::optional(n)
                                : std::optional<ast::SName>{});
                            goto _done;
                        }
                        {
                            _v.set(std::optional<ast::SName>{});
                            goto _done;
                        }
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                {
                    _v.set(std::optional<ast::SName>{});
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_none(opt0)) {
            _v.set(std::optional<ast::SName>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// IsRefPath: fn Expr -> Bool
bool is_ref_path(const ast::Expr& e) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = e.kind;
        if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
            auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
            _v.set(take_text(n.sigils, Nat(1u)) == Text("&"));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EField>(_m)) {
            auto&& r = prism_rtl::as<ast::ExprKind::EField>(_m).a0;
            _v.set(is_ref_path(r));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EIndex>(_m)) {
            auto&& r = prism_rtl::as<ast::ExprKind::EIndex>(_m).a0;
            _v.set(is_ref_path(r));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EGroup>(_m)) {
            auto&& x = prism_rtl::as<ast::ExprKind::EGroup>(_m).a0;
            _v.set(is_ref_path(x));
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// UpdForValues: unbounded fn Lx, Env, ?ForBinders, Expr, Block, Range, Ty -> Do
Do upd_for_values(const Lx& lx, const Env& env, const std::optional<ast::ForBinders>& binders_opt, const ast::Expr& source, const ast::Block& body, const ast::Range& span, const check_types::Ty& sty) {
    auto src = own(value_of(lx, env, source));
    auto [kt, vt, is_array] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<OutTy, OutTy, bool>> _v;
        if (prism_rtl::is<check_types::Ty::TyArray>(sty)) {
            auto&& v_ = prism_rtl::as<check_types::Ty::TyArray>(sty).a0;
            _v.set(std::tuple{OutTy(OutTy::OutNat{}), out_ty_of(lx, v_), true});
            goto _done;
        }
        if (prism_rtl::is<check_types::Ty::TyMap>(sty)) {
            auto&& k = prism_rtl::as<check_types::Ty::TyMap>(sty).a0;
            auto&& v_ = prism_rtl::as<check_types::Ty::TyMap>(sty).a1;
            _v.set(std::tuple{out_ty_of(lx, k), out_ty_of(lx, v_), false});
            goto _done;
        }
        {
            _v.set(std::tuple{OutTy(OutTy::OutUnit{}), OutTy(OutTy::OutUnit{}), true});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto [vty, kty] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<check_types::Ty, check_types::Ty>> _v;
        if (prism_rtl::is<check_types::Ty::TyArray>(sty)) {
            auto&& v_ = prism_rtl::as<check_types::Ty::TyArray>(sty).a0;
            _v.set(std::tuple{v_, check_types::Ty(check_types::Ty::TyCon{Text("Nat"), Array<check_types::Ty>{}})});
            goto _done;
        }
        if (prism_rtl::is<check_types::Ty::TyMap>(sty)) {
            auto&& k = prism_rtl::as<check_types::Ty::TyMap>(sty).a0;
            auto&& v_ = prism_rtl::as<check_types::Ty::TyMap>(sty).a1;
            _v.set(std::tuple{v_, k});
            goto _done;
        }
        {
            _v.set(std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::Ty(check_types::Ty::TyErr{})});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto key_name = prism_rtl::cat("k", span.start);
    auto val_name = prism_rtl::cat("v", span.start);
    auto env1 = bind(bind(env, Text("key"), Bn(Bn::BnLocal{Ex(Ex::XVar{key_name}), Holding(Holding::Owned{}), kt})), Text("_"), Bn(Bn::BnLocal{Ex(Ex::XVar{val_name}), Holding(Holding::Owned{}), vt}));
    auto env2 = is_array
        ? bind(env1, Text("ix"), Bn(Bn::BnLocal{Ex(Ex::XVar{key_name}), Holding(Holding::Owned{}), kt}))
        : env1;
    auto [binds, env3] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Array<Do>, Env>> _v;
        if (prism_rtl::is_none(binders_opt)) {
            _v.set(std::tuple{Array<Do>{}, env2});
            goto _done;
        }
        if (prism_rtl::is_some(binders_opt)) {
            auto&& fb = prism_rtl::some_of(binders_opt);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::tuple<Array<Do>, Env>> _v;
                auto&& _m = fb.second;
                if (prism_rtl::is_none(_m)) {
                    _v.set(({
                        auto po = rust_pat(lx, fb.first, vty, Holding(Holding::Owned{}), prism_rtl::cat("e", span.start));
                        std::tuple{Array(std::vector{Do(Do::DoLet{po.pa, Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{val_name}))})})}), bind_all(env2, po.binds)};
                    }));
                    goto _done;
                }
                if (prism_rtl::is_some(_m)) {
                    auto&& second = prism_rtl::some_of(_m);
                    _v.set(({
                        auto pk = rust_pat(lx, fb.first, kty, Holding(Holding::Owned{}), prism_rtl::cat("k", span.start, "_"));
                        auto pv = rust_pat(lx, second, vty, Holding(Holding::Owned{}), prism_rtl::cat("e", span.start));
                        std::tuple{Array(std::vector{Do(Do::DoLet{pk.pa, Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{key_name}))})}), Do(Do::DoLet{pv.pa, Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{val_name}))})})}), bind_all(bind_all(env2, pk.binds), pv.binds)};
                    }));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto&& _dos = upd_stmts(lx, env3, body.stmts);
    auto&& dos = std::get<0>(_dos);
    return is_array
        ? ({
        auto head = Do(Do::DoLet{Pa(Pa::PaBind{key_name}), Ex(Ex::XCall{Text("nat_of"), Array(std::vector{Ex(Ex::XVar{prism_rtl::cat("i", span.start)})})})});
        (Do(Do::DoFor{Pa(Pa::PaTuple{Array(std::vector{Pa(Pa::PaBind{prism_rtl::cat("i", span.start)}), Pa(Pa::PaBind{val_name})})}), Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(src), Text("into_iter"), Array<Ex>{}})), Text("enumerate"), Array<Ex>{}}), append(prelude::push(Array<Do>{}, head), append(binds, dos))}));
    })
        : Do(Do::DoFor{Pa(Pa::PaTuple{Array(std::vector{Pa(Pa::PaBind{key_name}), Pa(Pa::PaBind{val_name})})}), Ex(Ex::XMethod{prism_rtl::rc(src), Text("into_iter"), Array<Ex>{}}), append(binds, dos)});
}


prism_rtl::Turn<Do> UpdForValues::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& binders_opt = this->binders_opt;
    const auto& source = this->source;
    const auto& body = this->body;
    const auto& span = this->span;
    const auto& sty = this->sty;
    auto binders_opt_1 = binders_opt;
    auto body_2 = body;
    auto env_3 = env;
    auto lx_4 = lx;
    auto source_5 = source;
    auto span_6 = span;
    auto sty_7 = sty;
    return call_then(start_value_of(lx_4, env_3, source_5), [=](Vl value_of_132369) {
        return ({
            auto src = own(value_of_132369);
            auto [kt, vt, is_array] = ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<OutTy, OutTy, bool>> _v;
                if (prism_rtl::is<check_types::Ty::TyArray>(sty)) {
                    auto&& v_ = prism_rtl::as<check_types::Ty::TyArray>(sty).a0;
                    _v.set(std::tuple{OutTy(OutTy::OutNat{}), out_ty_of(lx_4, v_), true});
                    goto _done;
                }
                if (prism_rtl::is<check_types::Ty::TyMap>(sty)) {
                    auto&& k = prism_rtl::as<check_types::Ty::TyMap>(sty).a0;
                    auto&& v_ = prism_rtl::as<check_types::Ty::TyMap>(sty).a1;
                    _v.set(std::tuple{out_ty_of(lx_4, k), out_ty_of(lx_4, v_), false});
                    goto _done;
                }
                {
                    _v.set(std::tuple{OutTy(OutTy::OutUnit{}), OutTy(OutTy::OutUnit{}), true});
                    goto _done;
                }
            _done:
                _v.take();
            });
            auto [vty, kty] = ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<check_types::Ty, check_types::Ty>> _v;
                if (prism_rtl::is<check_types::Ty::TyArray>(sty)) {
                    auto&& v_ = prism_rtl::as<check_types::Ty::TyArray>(sty).a0;
                    _v.set(std::tuple{v_, check_types::Ty(check_types::Ty::TyCon{Text("Nat"), Array<check_types::Ty>{}})});
                    goto _done;
                }
                if (prism_rtl::is<check_types::Ty::TyMap>(sty)) {
                    auto&& k = prism_rtl::as<check_types::Ty::TyMap>(sty).a0;
                    auto&& v_ = prism_rtl::as<check_types::Ty::TyMap>(sty).a1;
                    _v.set(std::tuple{v_, k});
                    goto _done;
                }
                {
                    _v.set(std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::Ty(check_types::Ty::TyErr{})});
                    goto _done;
                }
            _done:
                _v.take();
            });
            auto key_name = prism_rtl::cat("k", span_6.start);
            auto val_name = prism_rtl::cat("v", span_6.start);
            auto env1 = bind(bind(env_3, Text("key"), Bn(Bn::BnLocal{Ex(Ex::XVar{key_name}), Holding(Holding::Owned{}), kt})), Text("_"), Bn(Bn::BnLocal{Ex(Ex::XVar{val_name}), Holding(Holding::Owned{}), vt}));
            auto env2 = is_array
                ? bind(env1, Text("ix"), Bn(Bn::BnLocal{Ex(Ex::XVar{key_name}), Holding(Holding::Owned{}), kt}))
                : env1;
            auto [binds, env3] = ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<Array<Do>, Env>> _v;
                if (prism_rtl::is_none(binders_opt)) {
                    _v.set(std::tuple{Array<Do>{}, env2});
                    goto _done;
                }
                if (prism_rtl::is_some(binders_opt)) {
                    auto&& fb = prism_rtl::some_of(binders_opt);
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<std::tuple<Array<Do>, Env>> _v;
                        auto&& _m = fb.second;
                        if (prism_rtl::is_none(_m)) {
                            _v.set(({
                                auto po = rust_pat(lx_4, fb.first, vty, Holding(Holding::Owned{}), prism_rtl::cat("e", span_6.start));
                                std::tuple{Array(std::vector{Do(Do::DoLet{po.pa, Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{val_name}))})})}), bind_all(env2, po.binds)};
                            }));
                            goto _done;
                        }
                        if (prism_rtl::is_some(_m)) {
                            auto&& second = prism_rtl::some_of(_m);
                            _v.set(({
                                auto pk = rust_pat(lx_4, fb.first, kty, Holding(Holding::Owned{}), prism_rtl::cat("k", span_6.start, "_"));
                                auto pv = rust_pat(lx_4, second, vty, Holding(Holding::Owned{}), prism_rtl::cat("e", span_6.start));
                                std::tuple{Array(std::vector{Do(Do::DoLet{pk.pa, Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{key_name}))})}), Do(Do::DoLet{pv.pa, Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{val_name}))})})}), bind_all(bind_all(env2, pk.binds), pv.binds)};
                            }));
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            call_then(start_upd_stmts(lx_4, env3, body_2.stmts), [=](std::tuple<Array<Do>, Env> upd_stmts_133650) {
            return ({
                auto&& _dos = upd_stmts_133650;
                auto&& dos = std::get<0>(_dos);
                is_array
                ? ({
                auto head = Do(Do::DoLet{Pa(Pa::PaBind{key_name}), Ex(Ex::XCall{Text("nat_of"), Array(std::vector{Ex(Ex::XVar{prism_rtl::cat("i", span_6.start)})})})});
                (prism_rtl::finished(Do(Do::DoFor{Pa(Pa::PaTuple{Array(std::vector{Pa(Pa::PaBind{prism_rtl::cat("i", span_6.start)}), Pa(Pa::PaBind{val_name})})}), Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(src), Text("into_iter"), Array<Ex>{}})), Text("enumerate"), Array<Ex>{}}), append(prelude::push(Array<Do>{}, head), append(binds, dos))})));
            })
                : prism_rtl::finished(Do(Do::DoFor{Pa(Pa::PaTuple{Array(std::vector{Pa(Pa::PaBind{key_name}), Pa(Pa::PaBind{val_name})})}), Ex(Ex::XMethod{prism_rtl::rc(src), Text("into_iter"), Array<Ex>{}}), append(binds, dos)}));
            });
        });
        });
    });
}


/// `Start UpdForValues, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Do> start_upd_for_values(Lx lx, Env env, std::optional<ast::ForBinders> binders_opt, ast::Expr source, ast::Block body, ast::Range span, check_types::Ty sty) {
    return std::make_shared<UpdForValues>(lx, env, binders_opt, source, body, span, sty);
}


/// UpdIf: unbounded fn Lx, Env, Cond, Block, ?Block -> Do
Do upd_if(const Lx& lx, const Env& env, const ast::Cond& c, const ast::Block& then_b, const std::optional<ast::Block>& else_b_opt) {
    auto&& _else_dos = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Array<Do>, Env>> _v;
        if (prism_rtl::is_some(else_b_opt)) {
            auto&& b = prism_rtl::some_of(else_b_opt);
            _v.set(upd_stmts(lx, env, b.stmts));
            goto _done;
        }
        if (prism_rtl::is_none(else_b_opt)) {
            _v.set(std::tuple{Array<Do>{}, env});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto&& else_dos = std::get<0>(_else_dos);
    return ({
        __label__ _done;
        prism_rtl::Slot<Do> _v;
        if (prism_rtl::is<ast::Cond::CondExpr>(c)) {
            auto&& x = prism_rtl::as<ast::Cond::CondExpr>(c).a0;
            _v.set(({
                auto&& _then_dos = upd_stmts(lx, env, then_b.stmts);
                auto&& then_dos = std::get<0>(_then_dos);
                (Do(Do::DoIf{as_bool(value_of(lx, env, x)), then_dos, else_dos}));
            }));
            goto _done;
        }
        if (prism_rtl::is<ast::Cond::CondBind>(c)) {
            auto&& p_ = prism_rtl::as<ast::Cond::CondBind>(c).a0;
            auto&& x = prism_rtl::as<ast::Cond::CondBind>(c).a1;
            _v.set(({
                auto po = rust_pat(lx, p_, type_at(lx, x.span), Holding(Holding::Owned{}), prism_rtl::cat("u", x.span.start));
                auto&& _then_dos = upd_stmts(lx, bind_all(env, po.binds), then_b.stmts);
                auto&& then_dos = std::get<0>(_then_dos);
                (Do(Do::DoIfLet{po.pa, own(value_of(lx, env, x)), then_dos, else_dos}));
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Do> UpdIf::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& c = this->c;
    const auto& then_b = this->then_b;
    const auto& else_b_opt = this->else_b_opt;
    auto&& _else_dos = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Array<Do>, Env>> _v;
        if (prism_rtl::is_some(else_b_opt)) {
            auto&& b = prism_rtl::some_of(else_b_opt);
            _v.set(upd_stmts(lx, env, b.stmts));
            goto _done;
        }
        if (prism_rtl::is_none(else_b_opt)) {
            _v.set(std::tuple{Array<Do>{}, env});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto&& else_dos = std::get<0>(_else_dos);
    return ({
        prism_rtl::is<ast::Cond::CondExpr>(c) ? ({
        auto&& x = prism_rtl::as<ast::Cond::CondExpr>(c).a0;
        ({
        auto env_1 = env;
        auto lx_2 = lx;
        auto then_b_3 = then_b;
        auto x_4 = x;
        call_then(start_upd_stmts(lx_2, env_1, then_b_3.stmts), [=](std::tuple<Array<Do>, Env> upd_stmts_134360) {
        return ({
            auto&& _then_dos = upd_stmts_134360;
            auto&& then_dos = std::get<0>(_then_dos);
            call_then(start_value_of(lx_2, env_1, x_4), [=](Vl value_of_134416) { return prism_rtl::finished(Do(Do::DoIf{as_bool(value_of_134416), then_dos, else_dos})); });
        });
    });
    });
    })
        : prism_rtl::is<ast::Cond::CondBind>(c) ? ({
        auto&& p_ = prism_rtl::as<ast::Cond::CondBind>(c).a0;
        auto&& x = prism_rtl::as<ast::Cond::CondBind>(c).a1;
        ({
        auto env_1 = env;
        auto lx_2 = lx;
        auto p__3 = p_;
        auto then_b_4 = then_b;
        auto x_5 = x;
        call_then(start_rust_pat(lx_2, p__3, type_at(lx_2, x_5.span), Holding(Holding::Owned{}), prism_rtl::cat("u", x_5.span.start)), [=](PatOut rust_pat_134507) {
        return ({
            auto po = rust_pat_134507;
            call_then(start_upd_stmts(lx_2, bind_all(env_1, po.binds), then_b_4.stmts), [=](std::tuple<Array<Do>, Env> upd_stmts_134606) {
            return ({
                auto&& _then_dos = upd_stmts_134606;
                auto&& then_dos = std::get<0>(_then_dos);
                call_then(start_value_of(lx_2, env_1, x_5), [=](Vl value_of_134689) { return prism_rtl::finished(Do(Do::DoIfLet{po.pa, own(value_of_134689), then_dos, else_dos})); });
            });
        });
        });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start UpdIf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Do> start_upd_if(Lx lx, Env env, ast::Cond c, ast::Block then_b, std::optional<ast::Block> else_b_opt) {
    return std::make_shared<UpdIf>(lx, env, c, then_b, else_b_opt);
}


/// UpdMatch: unbounded fn Lx, Env, Expr, [Arm] -> Do
Do upd_match(const Lx& lx, const Env& env, const ast::Expr& scrut, const Array<ast::Arm>& arms) {
    auto sv = value_of(lx, env, scrut);
    auto sty = type_at(lx, scrut.span);
    auto arms3 = run_to_end(each_job(check_errors::range0(len(arms)), ({
        auto arms_1 = arms;
        auto lx_2 = lx;
        auto sty_3 = sty;
        auto scrut_4 = scrut;
        auto env_5 = env;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<XArm>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto arms_1_6 = arms_1;
            auto lx_2_6 = lx_2;
            auto sty_3_6 = sty_3;
            auto scrut_4_6 = scrut_4;
            auto env_5_6 = env_5;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                ({
                auto arm = or_(index(arms_1_6, i), dummy_arm());
                call_then(start_arm_pat(lx_2_6, arm.pattern, sty_3_6, Holding(Holding::ByRef{}), prism_rtl::cat("u", scrut_4_6.span.start, "_", i)), [=](PatOut arm_pat_134988) {
                return ({
                    auto po = arm_pat_134988;
                    call_then(start_upd_stmts(lx_2_6, bind_all(env_5_6, po.binds), arm.body.stmts), [=](std::tuple<Array<Do>, Env> upd_stmts_135081) {
                    return ({
                        auto&& _dos = upd_stmts_135081;
                        auto&& dos = std::get<0>(_dos);
                        call_then(start_guard_conds(lx_2_6, bind_all(env_5_6, po.binds), arm.guard), [=](Array<Cc> guard_conds_135174) {
                        return ({
                            auto guarded = append(po.conds, guard_conds_135174);
                            (prism_rtl::finished(XArm{.pat = po.pa, .conds = guarded, .body = Ex(Ex::XBlock{dos, prism_rtl::rc(Ex(Ex::XUnit{}))})}));
                        });
                    });
                    });
                });
                });
            });
            });
            });
        }));
        });
    })));
    })));
    return fold(arms3, false, [&](const bool& f, const XArm& a) { return f || (len(a.conds) > Nat(0u)); })
        ? Do(Do::DoExpr{own(arms_value(ref_(sv), arms3, prism_rtl::cat("'u", scrut.span.start), OutTy(OutTy::OutUnit{})))})
        : Do(Do::DoMatch{ref_(sv), each(arms3, [&](const XArm& a) { return std::tuple{a.pat, arm_dos(a.body)}; })});
}


prism_rtl::Turn<Do> UpdMatch::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& scrut = this->scrut;
    const auto& arms = this->arms;
    auto arms_1 = arms;
    auto env_2 = env;
    auto lx_3 = lx;
    auto scrut_4 = scrut;
    return call_then(start_value_of(lx_3, env_2, scrut_4), [=](Vl value_of_134826) {
        return ({
            auto sv = value_of_134826;
            auto sty = type_at(lx_3, scrut_4.span);
            call_value(each_job(check_errors::range0(len(arms_1)), ({
            auto arms_1_5 = arms_1;
            auto lx_3_5 = lx_3;
            auto sty_5 = sty;
            auto scrut_4_6 = scrut_4;
            auto env_2_6 = env_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<XArm>(Nat)>>(prism_rtl::rc([=](Nat p0) {
            return ({
                auto arms_1_5_6 = arms_1_5;
                auto lx_3_5_6 = lx_3_5;
                auto sty_5_6 = sty_5;
                auto scrut_4_6_6 = scrut_4_6;
                auto env_2_6_6 = env_2_6;
                entered(once_job([=]() {
                return ({
                    auto i = p0;
                    ({
                    auto arm = or_(index(arms_1_5_6, i), dummy_arm());
                    call_then(start_arm_pat(lx_3_5_6, arm.pattern, sty_5_6, Holding(Holding::ByRef{}), prism_rtl::cat("u", scrut_4_6_6.span.start, "_", i)), [=](PatOut arm_pat_134988) {
                    return ({
                        auto po = arm_pat_134988;
                        call_then(start_upd_stmts(lx_3_5_6, bind_all(env_2_6_6, po.binds), arm.body.stmts), [=](std::tuple<Array<Do>, Env> upd_stmts_135081) {
                        return ({
                            auto&& _dos = upd_stmts_135081;
                            auto&& dos = std::get<0>(_dos);
                            call_then(start_guard_conds(lx_3_5_6, bind_all(env_2_6_6, po.binds), arm.guard), [=](Array<Cc> guard_conds_135174) {
                            return ({
                                auto guarded = append(po.conds, guard_conds_135174);
                                (prism_rtl::finished(XArm{.pat = po.pa, .conds = guarded, .body = Ex(Ex::XBlock{dos, prism_rtl::rc(Ex(Ex::XUnit{}))})}));
                            });
                        });
                        });
                    });
                    });
                });
                });
                });
            }));
            });
        })));
        })), [=](Array<XArm> each_134901) {
            return ({
                auto arms3 = each_134901;
                fold(arms3, false, [&](const bool& f, const XArm& a) { return f || (len(a.conds) > Nat(0u)); })
                ? prism_rtl::finished(Do(Do::DoExpr{own(arms_value(ref_(sv), arms3, prism_rtl::cat("'u", scrut_4.span.start), OutTy(OutTy::OutUnit{})))}))
                : prism_rtl::finished(Do(Do::DoMatch{ref_(sv), each(arms3, [&](const XArm& a) { return std::tuple{a.pat, arm_dos(a.body)}; })}));
            });
        });
        });
    });
}


/// `Start UpdMatch, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Do> start_upd_match(Lx lx, Env env, ast::Expr scrut, Array<ast::Arm> arms) {
    return std::make_shared<UpdMatch>(lx, env, scrut, arms);
}


/// AllOf: fn [Ex] -> Ex
Ex all_of(const Array<Ex>& xs0) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Ex> _v;
        {
            auto&& c0_0 = xs0;
            if (c0_0.size() == 1u) {
                {
                    auto&& _c1 = index(c0_0, Nat(0u));
                    if (prism_rtl::is_some(_c1)) {
                        auto&& one = prism_rtl::some_of(_c1);
                        _v.set(one);
                        goto _done;
                    }
                }
            }
        }
        {
            auto&& xs = xs0;
            _v.set(fold(drop(xs, Nat(1u)), or_(index(xs, Nat(0u)), Ex(Ex::XBool{true})), [&](const Ex& acc, const Ex& x) { return Ex(Ex::XBin{Text("&&"), prism_rtl::rc(acc), prism_rtl::rc(x)}); }));
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// ArmDos: fn Ex -> [Do]
Array<Do> arm_dos(const Ex& ex0) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Array<Do>> _v;
        if (prism_rtl::is<Ex::XBlock>(ex0)) {
            auto&& dos = prism_rtl::as<Ex::XBlock>(ex0).a0;
            _v.set(dos);
            goto _done;
        }
        {
            auto&& x = ex0;
            _v.set(Array(std::vector{Do(Do::DoExpr{x})}));
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// GuardConds: unbounded fn Lx, Env, ?Expr -> [Cc]
Array<Cc> guard_conds(const Lx& lx, const Env& env, const std::optional<ast::Expr>& opt2) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Array<Cc>> _v;
        if (prism_rtl::is_some(opt2)) {
            auto&& ge = prism_rtl::some_of(opt2);
            _v.set(Array(std::vector{Cc(Cc::CcIf{as_bool(value_of(lx, env, ge))})}));
            goto _done;
        }
        if (prism_rtl::is_none(opt2)) {
            _v.set(Array<Cc>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Array<Cc>> GuardConds::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& opt2 = this->opt2;
    return ({
        prism_rtl::is_some(opt2) ? ({
        auto&& ge = prism_rtl::some_of(opt2);
        ({
        auto env_1 = env;
        auto ge_2 = ge;
        auto lx_3 = lx;
        call_then(start_value_of(lx_3, env_1, ge_2), [=](Vl value_of_136016) { return prism_rtl::finished(Array(std::vector{Cc(Cc::CcIf{as_bool(value_of_136016)})})); });
    });
    })
        : prism_rtl::is_none(opt2) ? prism_rtl::finished(Array<Cc>{})
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start GuardConds, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Cc>> start_guard_conds(Lx lx, Env env, std::optional<ast::Expr> opt2) {
    return std::make_shared<GuardConds>(lx, env, opt2);
}


/// PlaceOf: unbounded fn Lx, Env, Expr -> Ex
Ex place_of(const Lx& lx, const Env& env, const ast::Expr& e) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Ex> _v;
        auto&& _m = e.kind;
        if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
            auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<Ex> _v;
                auto&& _m = prelude::get(env->names, check_env::sname_key(n));
                if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m))) {
                    auto&& rs = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                    _v.set(rs);
                    goto _done;
                }
                {
                    _v.set(Ex(Ex::XVar{snake(check_env::sname_key(n))}));
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EField>(_m)) {
            auto&& r = prism_rtl::as<ast::ExprKind::EField>(_m).a0;
            auto&& name = prism_rtl::as<ast::ExprKind::EField>(_m).a2;
            _v.set(Ex(Ex::XField{prism_rtl::rc(place_of(lx, env, r)), snake(name.name)}));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EIndex>(_m)) {
            auto&& r = prism_rtl::as<ast::ExprKind::EIndex>(_m).a0;
            auto&& k = prism_rtl::as<ast::ExprKind::EIndex>(_m).a1;
            _v.set(({
                auto rt = out_ty_of(lx, peel(type_at(lx, r.span)));
                auto f = ({
                    __label__ _done;
                    prism_rtl::Slot<Text> _v;
                    if (prism_rtl::is<OutTy::OutMap>(rt)) {
                        _v.set(Text("at_mut_map"));
                        goto _done;
                    }
                    {
                        _v.set(Text("at_mut"));
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                (Ex(Ex::XDeref{prism_rtl::rc(Ex(Ex::XCall{f, Array(std::vector{Ex(Ex::XRefMut{prism_rtl::rc(place_of(lx, env, r))}), argument(lx, env, k)})}))}));
            }));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EGroup>(_m)) {
            auto&& x = prism_rtl::as<ast::ExprKind::EGroup>(_m).a0;
            _v.set(place_of(lx, env, x));
            goto _done;
        }
        {
            _v.set(refusal(Text("a reference path this back end does not lower")));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Ex> PlaceOf::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& e = this->e;
    return ({
        auto&& _m = e.kind;
        prism_rtl::is<ast::ExprKind::EName>(_m) ? ({
        auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
        ({
        auto&& _m = prelude::get(env->names, check_env::sname_key(n));
        prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m)) ? ({
        auto&& rs = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
        prism_rtl::finished(rs);
    })
        : prism_rtl::finished(Ex(Ex::XVar{snake(check_env::sname_key(n))}));
    });
    })
        : prism_rtl::is<ast::ExprKind::EField>(_m) ? ({
        auto&& r = prism_rtl::as<ast::ExprKind::EField>(_m).a0;
        auto&& name = prism_rtl::as<ast::ExprKind::EField>(_m).a2;
        ({
        auto env_1 = env;
        auto lx_2 = lx;
        auto name_3 = name;
        auto r_4 = r;
        call_then(start_place_of(lx_2, env_1, r_4), [=](Ex place_of_136384) { return prism_rtl::finished(Ex(Ex::XField{prism_rtl::rc(place_of_136384), snake(name_3.name)})); });
    });
    })
        : prism_rtl::is<ast::ExprKind::EIndex>(_m) ? ({
        auto&& r = prism_rtl::as<ast::ExprKind::EIndex>(_m).a0;
        auto&& k = prism_rtl::as<ast::ExprKind::EIndex>(_m).a1;
        ({
        auto env_1 = env;
        auto k_2 = k;
        auto lx_3 = lx;
        auto r_4 = r;
        call_then(start_out_ty_of(lx_3, peel(type_at(lx_3, r_4.span))), [=](OutTy out_ty_of_136457) {
        return ({
            auto rt = out_ty_of_136457;
            auto f = ({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                if (prism_rtl::is<OutTy::OutMap>(rt)) {
                    _v.set(Text("at_mut_map"));
                    goto _done;
                }
                {
                    _v.set(Text("at_mut"));
                    goto _done;
                }
            _done:
                _v.take();
            });
            call_then(start_place_of(lx_3, env_1, r_4), [=](Ex place_of_136639) { return call_then(start_argument(lx_3, env_1, k_2), [=](Ex argument_136662) { return prism_rtl::finished(Ex(Ex::XDeref{prism_rtl::rc(Ex(Ex::XCall{f, Array(std::vector{Ex(Ex::XRefMut{prism_rtl::rc(place_of_136639)}), argument_136662})}))})); }); });
        });
    });
    });
    })
        : prism_rtl::is<ast::ExprKind::EGroup>(_m) ? ({
        auto&& x = prism_rtl::as<ast::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(PlaceOf(lx, env, x)));
    })
        : prism_rtl::finished(refusal(Text("a reference path this back end does not lower")));
    });
}


/// `Start PlaceOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Ex> start_place_of(Lx lx, Env env, ast::Expr e) {
    return std::make_shared<PlaceOf>(lx, env, e);
}


/// Assign: unbounded fn Lx, Env, Expr, Ex -> Do
Do assign(const Lx& lx, const Env& env, const ast::Expr& target, const Ex& v_) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Do> _v;
        auto&& _m = target.kind;
        if (prism_rtl::is<ast::ExprKind::EIndex>(_m)) {
            auto&& r = prism_rtl::as<ast::ExprKind::EIndex>(_m).a0;
            auto&& k = prism_rtl::as<ast::ExprKind::EIndex>(_m).a1;
            _v.set(({
                auto rt = out_ty_of(lx, peel(type_at(lx, r.span)));
                auto f = ({
                    __label__ _done;
                    prism_rtl::Slot<Text> _v;
                    if (prism_rtl::is<OutTy::OutMap>(rt)) {
                        _v.set(Text("set_key"));
                        goto _done;
                    }
                    {
                        _v.set(Text("set_index"));
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                (Do(Do::DoExpr{Ex(Ex::XCall{f, Array(std::vector{Ex(Ex::XRefMut{prism_rtl::rc(place_of(lx, env, r))}), argument(lx, env, k), v_})})}));
            }));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EGroup>(_m)) {
            auto&& x = prism_rtl::as<ast::ExprKind::EGroup>(_m).a0;
            _v.set(assign(lx, env, x, v_));
            goto _done;
        }
        {
            _v.set(Do(Do::DoAssign{place_of(lx, env, target), v_}));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Do> Assign::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& target = this->target;
    const auto& v_ = this->v_;
    return ({
        auto&& _m = target.kind;
        prism_rtl::is<ast::ExprKind::EIndex>(_m) ? ({
        auto&& r = prism_rtl::as<ast::ExprKind::EIndex>(_m).a0;
        auto&& k = prism_rtl::as<ast::ExprKind::EIndex>(_m).a1;
        ({
        auto env_1 = env;
        auto k_2 = k;
        auto lx_3 = lx;
        auto r_4 = r;
        auto v__5 = v_;
        call_then(start_out_ty_of(lx_3, peel(type_at(lx_3, r_4.span))), [=](OutTy out_ty_of_137070) {
        return ({
            auto rt = out_ty_of_137070;
            auto f = ({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                if (prism_rtl::is<OutTy::OutMap>(rt)) {
                    _v.set(Text("set_key"));
                    goto _done;
                }
                {
                    _v.set(Text("set_index"));
                    goto _done;
                }
            _done:
                _v.take();
            });
            call_then(start_place_of(lx_3, env_1, r_4), [=](Ex place_of_137252) { return call_then(start_argument(lx_3, env_1, k_2), [=](Ex argument_137275) { return prism_rtl::finished(Do(Do::DoExpr{Ex(Ex::XCall{f, Array(std::vector{Ex(Ex::XRefMut{prism_rtl::rc(place_of_137252)}), argument_137275, v__5})})})); }); });
        });
    });
    });
    })
        : prism_rtl::is<ast::ExprKind::EGroup>(_m) ? ({
        auto&& x = prism_rtl::as<ast::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(Assign(lx, env, x, v_)));
    })
        : ({
        auto env_1 = env;
        auto lx_2 = lx;
        auto target_3 = target;
        auto v__4 = v_;
        call_then(start_place_of(lx_2, env_1, target_3), [=](Ex place_of_137362) { return prism_rtl::finished(Do(Do::DoAssign{place_of_137362, v__4})); });
    });
    });
}


/// `Start Assign, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Do> start_assign(Lx lx, Env env, ast::Expr target, Ex v_) {
    return std::make_shared<Assign>(lx, env, target, v_);
}


/// BoundOf: fn Lx, Text -> [Text]
Array<Text> bound_of(const Lx& lx, const Text& text1) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Array<Text>> _v;
        {
            auto&& c0_1 = text1;
            if (c0_1 == Text("Prelude.Eq")) {
                _v.set(Array(std::vector{Text("PartialEq")}));
                goto _done;
            }
        }
        {
            auto&& c1_1 = text1;
            if (c1_1 == Text("Prelude.Ord")) {
                _v.set(Array(std::vector{Text("PartialOrd")}));
                goto _done;
            }
        }
        {
            auto&& c2_1 = text1;
            if (c2_1 == Text("Prelude.Show")) {
                _v.set(Array(std::vector{Text("Show")}));
                goto _done;
            }
        }
        {
            auto&& c3_1 = text1;
            if (c3_1 == Text("Prelude.Num")) {
                _v.set(Array(std::vector{Text("Num")}));
                goto _done;
            }
        }
        {
            auto&& c4_1 = text1;
            if (c4_1 == Text("Prelude.Pod")) {
                _v.set(Array(std::vector{Text("ToPod"), Text("FromPod")}));
                goto _done;
            }
        }
        {
            auto&& cls = text1;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<Array<Text>> _v;
                auto&& _m = prelude::get(lx.g.traits, cls);
                if (prism_rtl::is_some(_m)) {
                    auto&& tr = prism_rtl::some_of(_m);
                    _v.set(Array(std::vector{path_in(lx, tr.home, camel(check_types::bare_name(cls)))}));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(Array<Text>{});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// SchemeGenerics: fn Lx, Scheme -> [((Text, [Text]))]
Array<std::tuple<Text, Array<Text>>> scheme_generics(const Lx& lx, const check_types::Scheme& sc) {
    return each(sc.qs, [&](const Text& q) {
        return ({
            auto bs = fold(sc.bounds, Array(std::vector{Text("Clone")}), [&](const Array<Text>& acc, const std::tuple<Text, Text>& _p1) {
                auto&& v_ = std::get<0>(_p1);
                auto&& cls = std::get<1>(_p1);
                return v_ == q ? check_types::union_texts(acc, bound_of(lx, cls)) : acc;
            });
            std::tuple{camel(q), bs};
        });
    });
}


/// ParamNames: fn Lx, [FnClause], [OutTy] -> [((Text, Bool))]
Array<std::tuple<Text, bool>> param_names(const Lx& lx, const Array<ast::FnClause>& clauses, const Array<OutTy>& pts) {
    return each(check_errors::range0(len(pts)), [&](const Nat& i) {
        return ({
            auto names = each(clauses, [&](const ast::FnClause& c) { return plain_binder(lx, or_(index(c.params, i), dummy_pat())); });
            auto first_ = or_(index(names, Nat(0u)), Text(""));
            auto same = (first_ != Text("")) && fold(names, true, [&](const bool& ok, const Text& n) { return ok && (n == first_); });
            same
            ? std::tuple{local_name(lx, first_), false}
            : std::tuple{param_word(or_(index(pts, i), OutTy(OutTy::OutUnit{})), i), true};
        });
    });
}


/// PlainBinder: fn Lx, Pattern -> Text
Text plain_binder(const Lx& lx, const ast::Pattern_& p_) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = p_.kind;
        if (prism_rtl::is<ast::PatternKind::PName>(_m)) {
            auto&& n = prism_rtl::as<ast::PatternKind::PName>(_m).a0;
            _v.set(({
                auto [qk_opt, why] = check_env::resolve_value(lx.g, lx.home, n);
                auto is_ctor = ({
                    __label__ _done;
                    prism_rtl::Slot<bool> _v;
                    if (prism_rtl::is_some(qk_opt)) {
                        auto&& qk = prism_rtl::some_of(qk_opt);
                        _v.set(check_env::has_key(lx.g.ctors, qk) && (check_env::is_upper_text(base(check_env::sname_key(n))) || is_unit_ctor(lx, qk)));
                        goto _done;
                    }
                    if (prism_rtl::is_none(qk_opt)) {
                        _v.set(false);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                is_ctor ? Text("") : check_env::sname_key(n);
            }));
            goto _done;
        }
        if (prism_rtl::is<ast::PatternKind::PGroup>(_m)) {
            auto&& q = prism_rtl::as<ast::PatternKind::PGroup>(_m).a0;
            _v.set(plain_binder(lx, q));
            goto _done;
        }
        {
            _v.set(Text(""));
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// ParamWord: fn OutTy, Nat -> Text
Text param_word(const OutTy& t, const Nat& i) {
    auto base_ = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        if (prism_rtl::is<OutTy::OutNamed>(t)) {
            auto&& n = prism_rtl::as<OutTy::OutNamed>(t).a0;
            _v.set(snake(or_(lexer::last(split(n, Text("::"))), Text("arg"))));
            goto _done;
        }
        if (prism_rtl::is<OutTy::OutText>(t)) {
            _v.set(Text("text"));
            goto _done;
        }
        if (prism_rtl::is<OutTy::OutNat>(t)) {
            _v.set(Text("n"));
            goto _done;
        }
        if (prism_rtl::is<OutTy::OutInt>(t)) {
            _v.set(Text("i"));
            goto _done;
        }
        if (prism_rtl::is<OutTy::OutArray>(t)) {
            _v.set(Text("xs"));
            goto _done;
        }
        if (prism_rtl::is<OutTy::OutMap>(t)) {
            _v.set(Text("map"));
            goto _done;
        }
        if (prism_rtl::is<OutTy::OutOpt>(t)) {
            _v.set(Text("opt"));
            goto _done;
        }
        {
            _v.set(Text("arg"));
            goto _done;
        }
    _done:
        _v.take();
    });
    return prism_rtl::cat(base_, i);
}


/// ClausesBody: unbounded fn Lx, Env, [FnClause], [((Text, Bool))], [Ty], (fn Lx, Env, FnBody -> Ex), Text, OutTy -> Ex
Ex clauses_body(const Lx& lx, const Env& env, const Array<ast::FnClause>& clauses, const Array<std::tuple<Text, bool>>& names, const Array<check_types::Ty>& ptys, const prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Lx, Env, ast::FnBody>)>& body_fn, const Text& label, const OutTy& t) {
    auto env1 = run_to_end(fold_job(check_errors::range0(len(names)), env, ({
        auto names_1 = names;
        auto lx_2 = lx;
        auto clauses_3 = clauses;
        auto ptys_4 = ptys;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Env>(std::tuple<Env, Nat>)>>(prism_rtl::rc([=](std::tuple<Env, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto names_1_5 = names_1;
            auto lx_2_5 = lx_2;
            auto clauses_3_5 = clauses_3;
            auto ptys_4_5 = ptys_4;
            entered(once_job([=]() {
            return ({
                auto en = p0;
                auto i = p1;
                ({
                auto [rs, matched] = or_(index(names_1_5, i), std::tuple{Text(""), true});
                matched
                ? prism_rtl::finished(en)
                : call_then(start_out_ty_of(lx_2_5, peel(or_(index(ptys_4_5, i), check_types::Ty(check_types::Ty::TyErr{})))), [=](OutTy out_ty_of_140545) { return prism_rtl::finished(bind(en, plain_binder(lx_2_5, or_(index(or_(index(clauses_3_5, Nat(0u)), dummy_clause()).params, i), dummy_pat())), Bn(Bn::BnLocal{Ex(Ex::XVar{rs}), Holding(Holding::ByRef{}), out_ty_of_140545}))); });
            });
            });
        }));
        });
    })));
    })));
    auto scrut_ix = filter(check_errors::range0(len(names)), [&](const Nat& i) {
        return ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            auto&& _m = index(names, i);
            if (prism_rtl::is_some(_m) && std::get<1>(prism_rtl::some_of(_m))) {
                _v.set(true);
                goto _done;
            }
            {
                _v.set(false);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    return len(scrut_ix) == Nat(0u)
        ? ({
        auto c = or_(index(clauses, Nat(0u)), dummy_clause());
        run_to_end(body_fn(std::tuple{lx, env1, c.body}));
    })
        : ({
        auto scrut = ({
            __label__ _done;
            prism_rtl::Slot<Ex> _v;
            {
                auto&& m140842_0 = scrut_ix;
                if (m140842_0.size() == 1u) {
                    {
                        auto&& _c1 = index(m140842_0, Nat(0u));
                        if (prism_rtl::is_some(_c1)) {
                            auto&& i = prism_rtl::some_of(_c1);
                            _v.set(Ex(Ex::XVar{or_(index(each(names, [&](const std::tuple<Text, bool>& _p0) {
                                auto&& n = std::get<0>(_p0);
                                return n;
                            }), i), Text("arg"))}));
                            goto _done;
                        }
                    }
                }
            }
            {
                _v.set(Ex(Ex::XTuple{each(scrut_ix, [&](const Nat& i) {
                    return Ex(Ex::XVar{or_(index(each(names, [&](const std::tuple<Text, bool>& _p0) {
                        auto&& n = std::get<0>(_p0);
                        return n;
                    }), i), Text("arg"))});
                })}));
                goto _done;
            }
        _done:
            _v.take();
        });
        auto arms = run_to_end(each_job(check_errors::range0(len(clauses)), ({
            auto clauses_1 = clauses;
            auto scrut_ix_2 = scrut_ix;
            auto lx_3 = lx;
            auto ptys_4 = ptys;
            auto label_5 = label;
            auto body_fn_6 = body_fn;
            auto env1_7 = env1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<XArm>(Nat)>>(prism_rtl::rc([=](Nat p0) {
            return ({
                auto clauses_1_8 = clauses_1;
                auto scrut_ix_2_8 = scrut_ix_2;
                auto lx_3_8 = lx_3;
                auto ptys_4_8 = ptys_4;
                auto label_5_8 = label_5;
                auto body_fn_6_8 = body_fn_6;
                auto env1_7_8 = env1_7;
                entered(once_job([=]() {
                return ({
                    auto ci = p0;
                    ({
                    auto c = or_(index(clauses_1_8, ci), dummy_clause());
                    call_value(each_job(scrut_ix_2_8, ({
                    auto lx_3_8_8 = lx_3_8;
                    auto c_8 = c;
                    auto ptys_4_8_9 = ptys_4_8;
                    auto label_5_8_9 = label_5_8;
                    auto ci_9 = ci;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<PatOut>(Nat)>>(prism_rtl::rc([=](Nat p0) {
                    return ({
                        auto lx_3_8_8_10 = lx_3_8_8;
                        auto c_8_10 = c_8;
                        auto ptys_4_8_9_10 = ptys_4_8_9;
                        auto label_5_8_9_10 = label_5_8_9;
                        auto ci_9_10 = ci_9;
                        entered(once_job([=]() {
                        return ({
                            auto i = p0;
                            (prism_rtl::more(prism_rtl::rc(RustPat(lx_3_8_8_10, or_(index(c_8_10.params, i), dummy_pat()), or_(index(ptys_4_8_9_10, i), check_types::Ty(check_types::Ty::TyErr{})), Holding(Holding::ByRef{}), prism_rtl::cat(label_5_8_9_10, ci_9_10, "_", i)))));
                        });
                    }));
                    });
                })));
                })), [=](Array<PatOut> each_141157) {
                    return ({
                        auto pos = each_141157;
                        auto pa = ({
                            __label__ _done;
                            prism_rtl::Slot<Pa> _v;
                            {
                                auto&& m141283_0 = pos;
                                if (m141283_0.size() == 1u) {
                                    {
                                        auto&& _c1 = index(m141283_0, Nat(0u));
                                        if (prism_rtl::is_some(_c1)) {
                                            auto&& o = prism_rtl::some_of(_c1);
                                            _v.set(o.pa);
                                            goto _done;
                                        }
                                    }
                                }
                            }
                            {
                                _v.set(Pa(Pa::PaTuple{each(pos, [&](const PatOut& o) { return o.pa; })}));
                                goto _done;
                            }
                        _done:
                            _v.take();
                        });
                        auto conds = fold(pos, Array<Cc>{}, [&](const Array<Cc>& acc, const PatOut& o) { return append(acc, o.conds); });
                        auto binds = fold(pos, Array<std::tuple<Text, Bn>>{}, [&](const Array<std::tuple<Text, Bn>>& acc, const PatOut& o) { return append(acc, o.binds); });
                        call_value(body_fn_6_8(std::tuple{lx_3_8, bind_all(env1_7_8, binds), c.body}), [=](Ex body_141563) { return prism_rtl::finished(XArm{.pat = pa, .conds = conds, .body = body_141563}); });
                    });
                });
                });
                });
            }));
            });
        })));
        })));
        own(arms_value(scrut, arms, prism_rtl::cat("'", label), t));
    });
}


prism_rtl::Turn<Ex> ClausesBody::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& clauses = this->clauses;
    const auto& names = this->names;
    const auto& ptys = this->ptys;
    const auto& body_fn = this->body_fn;
    const auto& label = this->label;
    const auto& t = this->t;
    auto body_fn_1 = body_fn;
    auto clauses_2 = clauses;
    auto env_3 = env;
    auto label_4 = label;
    auto lx_5 = lx;
    auto names_6 = names;
    auto ptys_7 = ptys;
    auto t_8 = t;
    return call_value(fold_job(check_errors::range0(len(names_6)), env_3, ({
        auto names_6_9 = names_6;
        auto lx_5_9 = lx_5;
        auto clauses_2_9 = clauses_2;
        auto ptys_7_9 = ptys_7;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Env>(std::tuple<Env, Nat>)>>(prism_rtl::rc([=](std::tuple<Env, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto names_6_9_9 = names_6_9;
            auto lx_5_9_9 = lx_5_9;
            auto clauses_2_9_9 = clauses_2_9;
            auto ptys_7_9_9 = ptys_7_9;
            entered(once_job([=]() {
            return ({
                auto en = p0;
                auto i = p1;
                ({
                auto [rs, matched] = or_(index(names_6_9_9, i), std::tuple{Text(""), true});
                matched
                ? prism_rtl::finished(en)
                : call_then(start_out_ty_of(lx_5_9_9, peel(or_(index(ptys_7_9_9, i), check_types::Ty(check_types::Ty::TyErr{})))), [=](OutTy out_ty_of_140545) { return prism_rtl::finished(bind(en, plain_binder(lx_5_9_9, or_(index(or_(index(clauses_2_9_9, Nat(0u)), dummy_clause()).params, i), dummy_pat())), Bn(Bn::BnLocal{Ex(Ex::XVar{rs}), Holding(Holding::ByRef{}), out_ty_of_140545}))); });
            });
            });
        }));
        });
    })));
    })), [=](Env fold_140301) {
        return ({
            auto env1 = fold_140301;
            auto scrut_ix = filter(check_errors::range0(len(names_6)), [&](const Nat& i) {
                return ({
                    __label__ _done;
                    prism_rtl::Slot<bool> _v;
                    auto&& _m = index(names_6, i);
                    if (prism_rtl::is_some(_m) && std::get<1>(prism_rtl::some_of(_m))) {
                        _v.set(true);
                        goto _done;
                    }
                    {
                        _v.set(false);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
            });
            len(scrut_ix) == Nat(0u)
            ? ({
            auto c = or_(index(clauses_2, Nat(0u)), dummy_clause());
            body_fn_1(std::tuple{lx_5, env1, c.body})->cycle();
        })
            : ({
            auto scrut = ({
                __label__ _done;
                prism_rtl::Slot<Ex> _v;
                {
                    auto&& m140842_0 = scrut_ix;
                    if (m140842_0.size() == 1u) {
                        {
                            auto&& _c1 = index(m140842_0, Nat(0u));
                            if (prism_rtl::is_some(_c1)) {
                                auto&& i = prism_rtl::some_of(_c1);
                                _v.set(Ex(Ex::XVar{or_(index(each(names_6, [&](const std::tuple<Text, bool>& _p0) {
                                    auto&& n = std::get<0>(_p0);
                                    return n;
                                }), i), Text("arg"))}));
                                goto _done;
                            }
                        }
                    }
                }
                {
                    _v.set(Ex(Ex::XTuple{each(scrut_ix, [&](const Nat& i) {
                        return Ex(Ex::XVar{or_(index(each(names_6, [&](const std::tuple<Text, bool>& _p0) {
                            auto&& n = std::get<0>(_p0);
                            return n;
                        }), i), Text("arg"))});
                    })}));
                    goto _done;
                }
            _done:
                _v.take();
            });
            call_value(each_job(check_errors::range0(len(clauses_2)), ({
            auto clauses_2_9 = clauses_2;
            auto scrut_ix_9 = scrut_ix;
            auto lx_5_10 = lx_5;
            auto ptys_7_10 = ptys_7;
            auto label_4_10 = label_4;
            auto body_fn_1_10 = body_fn_1;
            auto env1_10 = env1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<XArm>(Nat)>>(prism_rtl::rc([=](Nat p0) {
            return ({
                auto clauses_2_9_11 = clauses_2_9;
                auto scrut_ix_9_11 = scrut_ix_9;
                auto lx_5_10_11 = lx_5_10;
                auto ptys_7_10_11 = ptys_7_10;
                auto label_4_10_11 = label_4_10;
                auto body_fn_1_10_11 = body_fn_1_10;
                auto env1_10_11 = env1_10;
                entered(once_job([=]() {
                return ({
                    auto ci = p0;
                    ({
                    auto c = or_(index(clauses_2_9_11, ci), dummy_clause());
                    call_value(each_job(scrut_ix_9_11, ({
                    auto lx_5_10_11_11 = lx_5_10_11;
                    auto c_11 = c;
                    auto ptys_7_10_11_12 = ptys_7_10_11;
                    auto label_4_10_11_12 = label_4_10_11;
                    auto ci_12 = ci;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<PatOut>(Nat)>>(prism_rtl::rc([=](Nat p0) {
                    return ({
                        auto lx_5_10_11_11_13 = lx_5_10_11_11;
                        auto c_11_13 = c_11;
                        auto ptys_7_10_11_12_13 = ptys_7_10_11_12;
                        auto label_4_10_11_12_13 = label_4_10_11_12;
                        auto ci_12_13 = ci_12;
                        entered(once_job([=]() {
                        return ({
                            auto i = p0;
                            (prism_rtl::more(prism_rtl::rc(RustPat(lx_5_10_11_11_13, or_(index(c_11_13.params, i), dummy_pat()), or_(index(ptys_7_10_11_12_13, i), check_types::Ty(check_types::Ty::TyErr{})), Holding(Holding::ByRef{}), prism_rtl::cat(label_4_10_11_12_13, ci_12_13, "_", i)))));
                        });
                    }));
                    });
                })));
                })), [=](Array<PatOut> each_141157) {
                    return ({
                        auto pos = each_141157;
                        auto pa = ({
                            __label__ _done;
                            prism_rtl::Slot<Pa> _v;
                            {
                                auto&& m141283_0 = pos;
                                if (m141283_0.size() == 1u) {
                                    {
                                        auto&& _c1 = index(m141283_0, Nat(0u));
                                        if (prism_rtl::is_some(_c1)) {
                                            auto&& o = prism_rtl::some_of(_c1);
                                            _v.set(o.pa);
                                            goto _done;
                                        }
                                    }
                                }
                            }
                            {
                                _v.set(Pa(Pa::PaTuple{each(pos, [&](const PatOut& o) { return o.pa; })}));
                                goto _done;
                            }
                        _done:
                            _v.take();
                        });
                        auto conds = fold(pos, Array<Cc>{}, [&](const Array<Cc>& acc, const PatOut& o) { return append(acc, o.conds); });
                        auto binds = fold(pos, Array<std::tuple<Text, Bn>>{}, [&](const Array<std::tuple<Text, Bn>>& acc, const PatOut& o) { return append(acc, o.binds); });
                        call_value(body_fn_1_10_11(std::tuple{lx_5_10_11, bind_all(env1_10_11, binds), c.body}), [=](Ex body_141563) { return prism_rtl::finished(XArm{.pat = pa, .conds = conds, .body = body_141563}); });
                    });
                });
                });
                });
            }));
            });
        })));
        })), [=](Array<XArm> each_141052) {
            return ({
                auto arms = each_141052;
                (prism_rtl::finished(own(arms_value(scrut, arms, prism_rtl::cat("'", label_4), t_8))));
            });
        });
        });
        });
    });
}


/// `Start ClausesBody, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Ex> start_clauses_body(Lx lx, Env env, Array<ast::FnClause> clauses, Array<std::tuple<Text, bool>> names, Array<check_types::Ty> ptys, prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Lx, Env, ast::FnBody>)> body_fn, Text label, OutTy t) {
    return std::make_shared<ClausesBody>(lx, env, clauses, names, ptys, body_fn, label, t);
}


/// let dummyClause
ast::FnClause dummy_clause() {
    return ast::FnClause{.name = ast::DefName(ast::DefName::DefOp{Text(""), ast::Range{.start = Nat(0u), .end = Nat(0u)}}), .params = Array<ast::Pattern_>{}, .body = ast::FnBody(ast::FnBody::BodyExpr{ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EError{})), .span = ast::Range{.start = Nat(0u), .end = Nat(0u)}}}), .span = ast::Range{.start = Nat(0u), .end = Nat(0u)}};
}


/// FnBodyValue: unbounded fn Lx, Env, FnBody -> Ex
Ex fn_body_value(const Lx& lx, const Env& env, const ast::FnBody& fn_body2) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Ex> _v;
        if (prism_rtl::is<ast::FnBody::BodyExpr>(fn_body2)) {
            auto&& x = prism_rtl::as<ast::FnBody::BodyExpr>(fn_body2).a0;
            _v.set(own(value_of(lx, env, x)));
            goto _done;
        }
        if (prism_rtl::is<ast::FnBody::BodyBlock>(fn_body2)) {
            auto&& b = prism_rtl::as<ast::FnBody::BodyBlock>(fn_body2).a0;
            _v.set(own(block_value(lx, env, b)));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Ex> FnBodyValue::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& fn_body2 = this->fn_body2;
    return ({
        prism_rtl::is<ast::FnBody::BodyExpr>(fn_body2) ? ({
        auto&& x = prism_rtl::as<ast::FnBody::BodyExpr>(fn_body2).a0;
        ({
        auto env_1 = env;
        auto lx_2 = lx;
        auto x_3 = x;
        call_then(start_value_of(lx_2, env_1, x_3), [=](Vl value_of_141922) { return prism_rtl::finished(own(value_of_141922)); });
    });
    })
        : prism_rtl::is<ast::FnBody::BodyBlock>(fn_body2) ? ({
        auto&& b = prism_rtl::as<ast::FnBody::BodyBlock>(fn_body2).a0;
        ({
        auto b_1 = b;
        auto env_2 = env;
        auto lx_3 = lx;
        call_then(start_block_value(lx_3, env_2, b_1), [=](Vl block_value_141987) { return prism_rtl::finished(own(block_value_141987)); });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start FnBodyValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Ex> start_fn_body_value(Lx lx, Env env, ast::FnBody fn_body2) {
    return std::make_shared<FnBodyValue>(lx, env, fn_body2);
}


/// FnDefOf: unbounded fn Lx, Text, [FnClause], Scheme -> FnDef
FnDef fn_def_of(const Lx& lx, const Text& qk, const Array<ast::FnClause>& clauses, const check_types::Scheme& sc) {
    auto [ptys0, res] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Array<check_types::Ty>, check_types::Ty>> _v;
        auto&& _m = sc.ty;
        if (prism_rtl::is<check_types::Ty::TyFn>(_m)) {
            auto&& ps = prism_rtl::as<check_types::Ty::TyFn>(_m).a1;
            auto&& r = prism_rtl::as<check_types::Ty::TyFn>(_m).a2;
            _v.set(std::tuple{ps, r});
            goto _done;
        }
        {
            auto&& other = _m;
            _v.set(std::tuple{Array<check_types::Ty>{}, other});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto ptys = has_blueprint(res)
        ? each(ptys0, [&](const check_types::Ty& p_) { return event_param(p_); })
        : ptys0;
    auto pts = run_to_end(each_job(ptys, ({
        auto lx_1 = lx;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<OutTy>(check_types::Ty)>>(prism_rtl::rc([=](check_types::Ty p0) {
        return ({
            auto lx_1_2 = lx_1;
            entered(once_job([=]() {
            return ({
                auto p_ = p0;
                (prism_rtl::more(prism_rtl::rc(OutTyOf(lx_1_2, peel(p_)))));
            });
        }));
        });
    })));
    })));
    auto names = param_names(lx, clauses, pts);
    auto body = clauses_body(lx, empty_env(), clauses, names, ptys, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Lx, Env, ast::FnBody>)>>(prism_rtl::rc([&](std::tuple<Lx, Env, ast::FnBody> _p0) {
        auto&& a0 = std::get<0>(_p0);
        auto&& a1 = std::get<1>(_p0);
        auto&& a2 = std::get<2>(_p0);
        return entered(start_fn_body_value(a0, a1, a2));
    })), Text("c"), out_ty_of(lx, peel(res)));
    auto params = each(check_errors::range0(len(pts)), [&](const Nat& i) {
        return std::tuple{or_(index(each(names, [&](const std::tuple<Text, bool>& _p0) {
            auto&& n = std::get<0>(_p0);
            return n;
        }), i), Text("arg")), OutTy(OutTy::OutRef{prism_rtl::rc(or_(index(pts, i), OutTy(OutTy::OutUnit{})))})};
    });
    auto ret = out_ty_of(lx, peel(res));
    auto used = fold(prelude::push(pts, ret), Array<Text>{}, [&](const Array<Text>& acc, const OutTy& t) { return check_types::union_texts(acc, ty_params_in(t)); });
    auto generics = filter(scheme_generics(lx, sc), [&](const std::tuple<Text, Array<Text>>& _p0) {
        auto&& g = std::get<0>(_p0);
        return check_types::has_text(used, g);
    });
    return FnDef{.name = or_(prelude::get(lx.rs_names, qk), snake(check_types::bare_name(qk))), .generics = generics, .params = params, .ret = ret, .body = body, .doc = signature_text(lx, qk), .public_ = true};
}


prism_rtl::Turn<FnDef> FnDefOf::cycle() const {
    const auto& lx = this->lx;
    const auto& qk = this->qk;
    const auto& clauses = this->clauses;
    const auto& sc = this->sc;
    auto [ptys0, res] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Array<check_types::Ty>, check_types::Ty>> _v;
        auto&& _m = sc.ty;
        if (prism_rtl::is<check_types::Ty::TyFn>(_m)) {
            auto&& ps = prism_rtl::as<check_types::Ty::TyFn>(_m).a1;
            auto&& r = prism_rtl::as<check_types::Ty::TyFn>(_m).a2;
            _v.set(std::tuple{ps, r});
            goto _done;
        }
        {
            auto&& other = _m;
            _v.set(std::tuple{Array<check_types::Ty>{}, other});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto ptys = has_blueprint(res)
        ? each(ptys0, [&](const check_types::Ty& p_) { return event_param(p_); })
        : ptys0;
    auto clauses_1 = clauses;
    auto lx_2 = lx;
    auto qk_3 = qk;
    auto sc_4 = sc;
    return call_value(each_job(ptys, ({
        auto lx_2_5 = lx_2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<OutTy>(check_types::Ty)>>(prism_rtl::rc([=](check_types::Ty p0) {
        return ({
            auto lx_2_5_5 = lx_2_5;
            entered(once_job([=]() {
            return ({
                auto p_ = p0;
                (prism_rtl::more(prism_rtl::rc(OutTyOf(lx_2_5_5, peel(p_)))));
            });
        }));
        });
    })));
    })), [=](Array<OutTy> each_142544) {
        return ({
            auto pts = each_142544;
            auto names = param_names(lx_2, clauses_1, pts);
            call_then(start_out_ty_of(lx_2, peel(res)), [=](OutTy out_ty_of_142707) {
            return call_then(start_clauses_body(lx_2, empty_env(), clauses_1, names, ptys, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Lx, Env, ast::FnBody>)>>(prism_rtl::rc([&](std::tuple<Lx, Env, ast::FnBody> _p0) {
                auto&& a0 = std::get<0>(_p0);
                auto&& a1 = std::get<1>(_p0);
                auto&& a2 = std::get<2>(_p0);
                return entered(start_fn_body_value(a0, a1, a2));
            })), Text("c"), out_ty_of_142707), [=](Ex clauses_body_142640) {
                return ({
                    auto body = clauses_body_142640;
                    auto params = each(check_errors::range0(len(pts)), [&](const Nat& i) {
                        return std::tuple{or_(index(each(names, [&](const std::tuple<Text, bool>& _p0) {
                            auto&& n = std::get<0>(_p0);
                            return n;
                        }), i), Text("arg")), OutTy(OutTy::OutRef{prism_rtl::rc(or_(index(pts, i), OutTy(OutTy::OutUnit{})))})};
                    });
                    call_then(start_out_ty_of(lx_2, peel(res)), [=](OutTy out_ty_of_142875) {
                    return ({
                        auto ret = out_ty_of_142875;
                        auto used = fold(prelude::push(pts, ret), Array<Text>{}, [&](const Array<Text>& acc, const OutTy& t) { return check_types::union_texts(acc, ty_params_in(t)); });
                        auto generics = filter(scheme_generics(lx_2, sc_4), [&](const std::tuple<Text, Array<Text>>& _p0) {
                            auto&& g = std::get<0>(_p0);
                            return check_types::has_text(used, g);
                        });
                        (prism_rtl::finished(FnDef{.name = or_(prelude::get(lx_2.rs_names, qk_3), snake(check_types::bare_name(qk_3))), .generics = generics, .params = params, .ret = ret, .body = body, .doc = signature_text(lx_2, qk_3), .public_ = true}));
                    });
                });
                });
            });
        });
        });
    });
}


/// `Start FnDefOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<FnDef> start_fn_def_of(Lx lx, Text qk, Array<ast::FnClause> clauses, check_types::Scheme sc) {
    return std::make_shared<FnDefOf>(lx, qk, clauses, sc);
}


/// TyParamsIn: fn OutTy -> [Text]
Array<Text> ty_params_in(const OutTy& t) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Array<Text>> _v;
        if (prism_rtl::is<OutTy::OutGen>(t)) {
            auto&& n = prism_rtl::as<OutTy::OutGen>(t).a0;
            _v.set(Array(std::vector{n}));
            goto _done;
        }
        if (prism_rtl::is<OutTy::OutNamed>(t)) {
            auto&& ts = prism_rtl::as<OutTy::OutNamed>(t).a1;
            _v.set(fold(ts, Array<Text>{}, [&](const Array<Text>& acc, const OutTy& x) { return check_types::union_texts(acc, ty_params_in(x)); }));
            goto _done;
        }
        if (prism_rtl::is<OutTy::OutTuple>(t)) {
            auto&& ts = prism_rtl::as<OutTy::OutTuple>(t).a0;
            _v.set(fold(ts, Array<Text>{}, [&](const Array<Text>& acc, const OutTy& x) { return check_types::union_texts(acc, ty_params_in(x)); }));
            goto _done;
        }
        if (prism_rtl::is<OutTy::OutFn>(t)) {
            auto&& ts = prism_rtl::as<OutTy::OutFn>(t).a0;
            auto&& r = prism_rtl::as<OutTy::OutFn>(t).a1;
            _v.set(fold(ts, ty_params_in(r), [&](const Array<Text>& acc, const OutTy& x) { return check_types::union_texts(acc, ty_params_in(x)); }));
            goto _done;
        }
        if (prism_rtl::is<OutTy::OutJobFn>(t)) {
            auto&& a = prism_rtl::as<OutTy::OutJobFn>(t).a0;
            auto&& r = prism_rtl::as<OutTy::OutJobFn>(t).a1;
            _v.set(check_types::union_texts(ty_params_in(a), ty_params_in(r)));
            goto _done;
        }
        if (prism_rtl::is<OutTy::OutMap>(t)) {
            auto&& k = prism_rtl::as<OutTy::OutMap>(t).a0;
            auto&& v_ = prism_rtl::as<OutTy::OutMap>(t).a1;
            _v.set(check_types::union_texts(ty_params_in(k), ty_params_in(v_)));
            goto _done;
        }
        if (prism_rtl::is<OutTy::OutOpt>(t)) {
            auto&& x = prism_rtl::as<OutTy::OutOpt>(t).a0;
            _v.set(ty_params_in(x));
            goto _done;
        }
        if (prism_rtl::is<OutTy::OutRes>(t)) {
            auto&& x = prism_rtl::as<OutTy::OutRes>(t).a0;
            _v.set(ty_params_in(x));
            goto _done;
        }
        if (prism_rtl::is<OutTy::OutArray>(t)) {
            auto&& x = prism_rtl::as<OutTy::OutArray>(t).a0;
            _v.set(ty_params_in(x));
            goto _done;
        }
        if (prism_rtl::is<OutTy::OutJob>(t)) {
            auto&& x = prism_rtl::as<OutTy::OutJob>(t).a0;
            _v.set(ty_params_in(x));
            goto _done;
        }
        if (prism_rtl::is<OutTy::OutEvent>(t)) {
            auto&& x = prism_rtl::as<OutTy::OutEvent>(t).a0;
            _v.set(ty_params_in(x));
            goto _done;
        }
        if (prism_rtl::is<OutTy::OutDyn>(t)) {
            auto&& x = prism_rtl::as<OutTy::OutDyn>(t).a0;
            _v.set(ty_params_in(x));
            goto _done;
        }
        if (prism_rtl::is<OutTy::OutRc>(t)) {
            auto&& x = prism_rtl::as<OutTy::OutRc>(t).a0;
            _v.set(ty_params_in(x));
            goto _done;
        }
        if (prism_rtl::is<OutTy::OutRef>(t)) {
            auto&& x = prism_rtl::as<OutTy::OutRef>(t).a0;
            _v.set(ty_params_in(x));
            goto _done;
        }
        if (prism_rtl::is<OutTy::OutHold>(t)) {
            auto&& x = prism_rtl::as<OutTy::OutHold>(t).a0;
            _v.set(ty_params_in(x));
            goto _done;
        }
        if (prism_rtl::is<OutTy::OutCell>(t)) {
            auto&& x = prism_rtl::as<OutTy::OutCell>(t).a0;
            _v.set(ty_params_in(x));
            goto _done;
        }
        if (prism_rtl::is<OutTy::OutLive>(t)) {
            auto&& x = prism_rtl::as<OutTy::OutLive>(t).a0;
            _v.set(ty_params_in(x));
            goto _done;
        }
        {
            _v.set(Array<Text>{});
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// SignatureText: fn Lx, Text -> Text
Text signature_text(const Lx& lx, const Text& qk) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = prelude::get(lx.g.vals, qk);
        if (prism_rtl::is_some(_m)) {
            auto&& v_ = prism_rtl::some_of(_m);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                auto&& _m = index(lx.g.srcs, v_->file);
                if (prism_rtl::is_some(_m)) {
                    auto&& src = prism_rtl::some_of(_m);
                    _v.set(lexer::trim(check_errors::span_text(src, v_.span)));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(check_types::bare_name(qk));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(check_types::bare_name(qk));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// DefinitionText: fn Lx, Text -> Text
Text definition_text(const Lx& lx, const Text& qk) {
    auto spans = fold(lx.g.defs, Array<std::tuple<Nat, ast::Range>>{}, [&](const Array<std::tuple<Nat, ast::Range>>& acc, const check_env::Def& d) { return d.qk == qk ? prelude::push(acc, std::tuple{d->file, d.span}) : acc; });
    auto sig = ({
        __label__ _done;
        prism_rtl::Slot<Array<std::tuple<Nat, ast::Range>>> _v;
        auto&& _m = prelude::get(lx.g.vals, qk);
        if (prism_rtl::is_some(_m)) {
            auto&& v_ = prism_rtl::some_of(_m);
            _v.set(v_.span.start < or_(index(each(spans, [&](const std::tuple<Nat, ast::Range>& _p0) {
                auto&& r = std::get<1>(_p0);
                return r.start;
            }), Nat(0u)), Nat(0u))
                ? Array(std::vector{std::tuple{v_->file, v_.span}})
                : Array<std::tuple<Nat, ast::Range>>{});
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Array<std::tuple<Nat, ast::Range>>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return lexer::join(each(append(sig, spans), [&](const std::tuple<Nat, ast::Range>& _p0) {
        auto&& f = std::get<0>(_p0);
        auto&& r = std::get<1>(_p0);
        return src_text(lx, f, r);
    }), Text("\n"));
}


/// SrcText: fn Lx, Nat, Range -> Text
Text src_text(const Lx& lx, const Nat& f, const ast::Range& r) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = index(lx.g.srcs, f);
        if (prism_rtl::is_some(_m)) {
            auto&& src = prism_rtl::some_of(_m);
            _v.set(drop_trailing_comments(check_errors::span_text(src, r)));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// DropTrailingComments: fn Text -> Text
Text drop_trailing_comments(const Text& t) {
    auto lines = split(t, Text("\n"));
    auto keep = fold(check_errors::range0(len(lines)), Nat(0u), [&](const Nat& k, const Nat& i) { return is_code_line(or_(index(lines, i), Text(""))) ? i + Nat(1u) : k; });
    return lexer::trim_end(lexer::join(take(lines, keep), Text("\n")));
}


/// IsCodeLine: fn Text -> Bool
bool is_code_line(const Text& l) {
    auto s = lexer::trim(l);
    return (s != Text("")) && (take_text(s, Nat(1u)) != Text("#"));
}


/// LetGetter: unbounded fn Lx, Text, LetDecl -> FnDef
FnDef let_getter(const Lx& lx, const Text& qk, const ast::LetDecl& l) {
    auto t = out_ty_of(lx, peel(type_at(lx, l->value.span)));
    auto v_ = value_of(lx, empty_env(), l->value);
    return FnDef{.name = or_(prelude::get(lx.rs_names, qk), snake(check_types::bare_name(qk))), .generics = Array<std::tuple<Text, Array<Text>>>{}, .params = Array<std::tuple<Text, OutTy>>{}, .ret = t, .body = own(v_), .doc = prism_rtl::cat("let ", check_types::bare_name(qk)), .public_ = true};
}


prism_rtl::Turn<FnDef> LetGetter::cycle() const {
    const auto& lx = this->lx;
    const auto& qk = this->qk;
    const auto& l = this->l;
    auto l_1 = l;
    auto lx_2 = lx;
    auto qk_3 = qk;
    return call_then(start_out_ty_of(lx_2, peel(type_at(lx_2, l_1->value.span))), [=](OutTy out_ty_of_145718) {
        return ({
            auto t = out_ty_of_145718;
            call_then(start_value_of(lx_2, empty_env(), l_1->value), [=](Vl value_of_145775) {
            return ({
                auto v_ = value_of_145775;
                (prism_rtl::finished(FnDef{.name = or_(prelude::get(lx_2.rs_names, qk_3), snake(check_types::bare_name(qk_3))), .generics = Array<std::tuple<Text, Array<Text>>>{}, .params = Array<std::tuple<Text, OutTy>>{}, .ret = t, .body = own(v_), .doc = prism_rtl::cat("let ", check_types::bare_name(qk_3)), .public_ = true}));
            });
        });
        });
    });
}


/// `Start LetGetter, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<FnDef> start_let_getter(Lx lx, Text qk, ast::LetDecl l) {
    return std::make_shared<LetGetter>(lx, qk, l);
}


/// Tail: unbounded fn Lx, Env, Expr -> Ex
Ex tail(const Lx& lx, const Env& env, const ast::Expr& e) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Ex> _v;
        auto&& _m = frame_call(lx, env, e, true);
        if (prism_rtl::is_some(_m)) {
            auto&& c = prism_rtl::some_of(_m);
            _v.set(frame(lx, env, c, rest_text(lx, e.span, c.span, e.span), ({
                auto lx_1 = lx;
                auto e_2 = e;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(Env)>>(prism_rtl::rc([=](Env p0) {
                return ({
                    auto lx_1_3 = lx_1;
                    auto e_2_3 = e_2;
                    entered(once_job([=]() {
                    return ({
                        auto env2 = p0;
                        (prism_rtl::more(prism_rtl::rc(Tail(lx_1_3, env2, e_2_3))));
                    });
                }));
                });
            })));
            })));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(tail_here(lx, env, e));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Ex> Tail::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& e = this->e;
    auto e_1 = e;
    auto env_2 = env;
    auto lx_3 = lx;
    return call_then(start_frame_call(lx_3, env_2, e_1, true), [=](std::optional<ast::Expr> frame_call_146845) {
        return ({
            prism_rtl::is_some(frame_call_146845) ? ({
            auto&& c = prism_rtl::some_of(frame_call_146845);
            prism_rtl::more(prism_rtl::rc(Frame(lx_3, env_2, c, rest_text(lx_3, e_1.span, c.span, e_1.span), ({
            auto lx_3_4 = lx_3;
            auto e_1_4 = e_1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(Env)>>(prism_rtl::rc([=](Env p0) {
            return ({
                auto lx_3_4_4 = lx_3_4;
                auto e_1_4_4 = e_1_4;
                entered(once_job([=]() {
                return ({
                    auto env2 = p0;
                    (prism_rtl::more(prism_rtl::rc(Tail(lx_3_4_4, env2, e_1_4_4))));
                });
            }));
            });
        })));
        }))));
        })
            : prism_rtl::is_none(frame_call_146845) ? prism_rtl::more(prism_rtl::rc(TailHere(lx_3, env_2, e_1)))
            : throw prism_rtl::Panic("no arm matched");
        });
    });
}


/// `Start Tail, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Ex> start_tail(Lx lx, Env env, ast::Expr e) {
    return std::make_shared<Tail>(lx, env, e);
}


/// TailHere: unbounded fn Lx, Env, Expr -> Ex
Ex tail_here(const Lx& lx, const Env& env, const ast::Expr& e) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Ex> _v;
        auto&& _m = e.kind;
        if (prism_rtl::is<ast::ExprKind::EGroup>(_m)) {
            auto&& x = prism_rtl::as<ast::ExprKind::EGroup>(_m).a0;
            _v.set(tail(lx, env, x));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EUpdate>(_m)) {
            auto&& target = prism_rtl::as<ast::ExprKind::EUpdate>(_m).a0;
            auto&& b = prism_rtl::as<ast::ExprKind::EUpdate>(_m).a1;
            _v.set(has_top_while(lx, b)
                ? upd_tail(lx, env, target, b, e.span, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Env, Ex>)>>(prism_rtl::rc([=](std::tuple<Env, Ex> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return once_job([=]() {
                    return ({
                        auto en = p0;
                        auto v_ = p1;
                        (prism_rtl::finished(Ex(Ex::XCtor{Text("prism_rtl::Turn::Finished"), Array(std::vector{v_})})));
                    });
                });
            })))
                : Ex(Ex::XCtor{Text("prism_rtl::Turn::Finished"), Array(std::vector{own(value_of(lx, env, e))})}));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EMatch>(_m)) {
            auto&& s = prism_rtl::as<ast::ExprKind::EMatch>(_m).a0;
            auto&& arms = prism_rtl::as<ast::ExprKind::EMatch>(_m).a1;
            _v.set(tail_match(lx, env, s, arms, e.span));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EIf>(_m) && prism_rtl::is_some(prism_rtl::as<ast::ExprKind::EIf>(_m).a2)) {
            auto&& m147063_3_0 = prism_rtl::as<ast::ExprKind::EIf>(_m).a0;
            auto&& then_b = prism_rtl::as<ast::ExprKind::EIf>(_m).a1;
            auto&& else_b = prism_rtl::some_of(prism_rtl::as<ast::ExprKind::EIf>(_m).a2);
            if (prism_rtl::is<ast::Cond::CondExpr>(m147063_3_0)) {
                auto&& c = prism_rtl::as<ast::Cond::CondExpr>(m147063_3_0).a0;
                _v.set(Ex(Ex::XIf{prism_rtl::rc(as_bool(value_of(lx, env, c))), prism_rtl::rc(tail_block(lx, env, then_b)), prism_rtl::rc(tail_block(lx, env, else_b))}));
                goto _done;
            }
        }
        if (prism_rtl::is<ast::ExprKind::ECall>(_m)) {
            auto&& callee = prism_rtl::as<ast::ExprKind::ECall>(_m).a0;
            auto&& args = prism_rtl::as<ast::ExprKind::ECall>(_m).a1;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<Ex> _v;
                auto&& _m = tail_callee(lx, env, callee);
                if (prism_rtl::is_some(_m)) {
                    auto&& qk = prism_rtl::some_of(_m);
                    _v.set(({
                        auto job = or_(prelude::get(lx.rs_names, qk), snake(check_types::bare_name(qk)));
                        auto job_name = path_in(lx, owner_of(qk), camel(check_types::bare_name(qk)));
                        auto&& _ptys = scheme_parts(lx, qk);
                        auto&& ptys = std::get<0>(_ptys);
                        auto fields = job_field_names(lx, qk);
                        auto vals = named_args_owned(lx, env, qk, args);
                        enters_at_once(lx, qk, args)
                        ? Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XCall{path_in(lx, owner_of(qk), prism_rtl::cat("start_", job)), vals})), Text("cycle"), Array<Ex>{}})
                        : is_color_poly(lx, qk)
                        ? Ex(Ex::XCtor{Text("prism_rtl::Turn::More"), Array(std::vector{Ex(Ex::XCall{path_in(lx, owner_of(qk), prism_rtl::cat("start_", job)), vals})})})
                        : Ex(Ex::XCtor{Text("prism_rtl::Turn::More"), Array(std::vector{Ex(Ex::XCall{Text("Rc::new"), Array(std::vector{Ex(Ex::XRecord{job_name, each(check_errors::range0(len(vals)), [&](const Nat& i) { return std::tuple{or_(index(fields, i), Text("arg")), or_(index(vals, i), Ex(Ex::XUnit{}))}; })})})})})});
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<Ex> _v;
                        auto&& _m = local_job_fn(lx, env, callee);
                        if (prism_rtl::is_some(_m)) {
                            auto&& f = prism_rtl::some_of(_m);
                            _v.set(Ex(Ex::XMethod{prism_rtl::rc(start_call(f, start_args(lx, env, f, args))), Text("cycle"), Array<Ex>{}}));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(({
                                __label__ _done;
                                prism_rtl::Slot<Ex> _v;
                                auto&& _m = prelude_job_call(lx, env, e);
                                if (prism_rtl::is_some(_m)) {
                                    auto&& job = prism_rtl::some_of(_m);
                                    _v.set(Ex(Ex::XMethod{prism_rtl::rc(job), Text("cycle"), Array<Ex>{}}));
                                    goto _done;
                                }
                                if (prism_rtl::is_none(_m)) {
                                    _v.set(Ex(Ex::XCtor{Text("prism_rtl::Turn::Finished"), Array(std::vector{own(value_of(lx, env, e))})}));
                                    goto _done;
                                }
                                prism_rtl::unreachable("no arm matched");
                            _done:
                                _v.take();
                            }));
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        {
            _v.set(Ex(Ex::XCtor{Text("prism_rtl::Turn::Finished"), Array(std::vector{own(value_of(lx, env, e))})}));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Ex> TailHere::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& e = this->e;
    return ({
        auto&& _m = e.kind;
        prism_rtl::is<ast::ExprKind::EGroup>(_m) ? ({
        auto&& x = prism_rtl::as<ast::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(Tail(lx, env, x)));
    })
        : prism_rtl::is<ast::ExprKind::EUpdate>(_m) ? ({
        auto&& target = prism_rtl::as<ast::ExprKind::EUpdate>(_m).a0;
        auto&& b = prism_rtl::as<ast::ExprKind::EUpdate>(_m).a1;
        has_top_while(lx, b)
        ? prism_rtl::more(prism_rtl::rc(UpdTail(lx, env, target, b, e.span, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Env, Ex>)>>(prism_rtl::rc([=](std::tuple<Env, Ex> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return once_job([=]() {
            return ({
                auto en = p0;
                auto v_ = p1;
                (prism_rtl::finished(Ex(Ex::XCtor{Text("prism_rtl::Turn::Finished"), Array(std::vector{v_})})));
            });
        });
    })))))
        : ({
        auto e_1 = e;
        auto env_2 = env;
        auto lx_3 = lx;
        call_then(start_value_of(lx_3, env_2, e_1), [=](Vl value_of_147302) { return prism_rtl::finished(Ex(Ex::XCtor{Text("prism_rtl::Turn::Finished"), Array(std::vector{own(value_of_147302)})})); });
    });
    })
        : prism_rtl::is<ast::ExprKind::EMatch>(_m) ? ({
        auto&& s = prism_rtl::as<ast::ExprKind::EMatch>(_m).a0;
        auto&& arms = prism_rtl::as<ast::ExprKind::EMatch>(_m).a1;
        prism_rtl::more(prism_rtl::rc(TailMatch(lx, env, s, arms, e.span)));
    })
        : prism_rtl::is<ast::ExprKind::EIf>(_m) && prism_rtl::is_some(prism_rtl::as<ast::ExprKind::EIf>(_m).a2) && ({
        auto&& m147063_3_0 = prism_rtl::as<ast::ExprKind::EIf>(_m).a0;
        auto&& then_b = prism_rtl::as<ast::ExprKind::EIf>(_m).a1;
        auto&& else_b = prism_rtl::some_of(prism_rtl::as<ast::ExprKind::EIf>(_m).a2);
        prism_rtl::is<ast::Cond::CondExpr>(m147063_3_0);
    }) ? ({
        auto&& m147063_3_0 = prism_rtl::as<ast::ExprKind::EIf>(_m).a0;
        auto&& then_b = prism_rtl::as<ast::ExprKind::EIf>(_m).a1;
        auto&& else_b = prism_rtl::some_of(prism_rtl::as<ast::ExprKind::EIf>(_m).a2);
        auto&& c = prism_rtl::as<ast::Cond::CondExpr>(m147063_3_0).a0;
        ({
        auto c_1 = c;
        auto else_b_2 = else_b;
        auto env_3 = env;
        auto lx_4 = lx;
        auto then_b_5 = then_b;
        call_then(start_value_of(lx_4, env_3, c_1), [=](Vl value_of_147432) { return call_then(start_tail_block(lx_4, env_3, then_b_5), [=](Ex tail_block_147455) { return call_then(start_tail_block(lx_4, env_3, else_b_2), [=](Ex tail_block_147483) { return prism_rtl::finished(Ex(Ex::XIf{prism_rtl::rc(as_bool(value_of_147432)), prism_rtl::rc(tail_block_147455), prism_rtl::rc(tail_block_147483)})); }); }); });
    });
    })
        : prism_rtl::is<ast::ExprKind::ECall>(_m) ? ({
        auto&& callee = prism_rtl::as<ast::ExprKind::ECall>(_m).a0;
        auto&& args = prism_rtl::as<ast::ExprKind::ECall>(_m).a1;
        ({
        auto&& _m = tail_callee(lx, env, callee);
        prism_rtl::is_some(_m) ? ({
        auto&& qk = prism_rtl::some_of(_m);
        ({
        auto job = or_(prelude::get(lx.rs_names, qk), snake(check_types::bare_name(qk)));
        auto job_name = path_in(lx, owner_of(qk), camel(check_types::bare_name(qk)));
        auto&& _ptys = scheme_parts(lx, qk);
        auto&& ptys = std::get<0>(_ptys);
        auto args_1 = args;
        auto env_2 = env;
        auto lx_3 = lx;
        call_then(start_job_field_names(lx_3, qk), [=](Array<Text> job_field_names_147813) {
        return ({
            auto fields = job_field_names_147813;
            call_then(start_named_args_owned(lx_3, env_2, qk, args_1), [=](Array<Ex> named_args_owned_147857) {
            return ({
                auto vals = named_args_owned_147857;
                enters_at_once(lx_3, qk, args_1)
                ? prism_rtl::finished(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XCall{path_in(lx_3, owner_of(qk), prism_rtl::cat("start_", job)), vals})), Text("cycle"), Array<Ex>{}}))
                : is_color_poly(lx_3, qk)
                ? prism_rtl::finished(Ex(Ex::XCtor{Text("prism_rtl::Turn::More"), Array(std::vector{Ex(Ex::XCall{path_in(lx_3, owner_of(qk), prism_rtl::cat("start_", job)), vals})})}))
                : prism_rtl::finished(Ex(Ex::XCtor{Text("prism_rtl::Turn::More"), Array(std::vector{Ex(Ex::XCall{Text("Rc::new"), Array(std::vector{Ex(Ex::XRecord{job_name, each(check_errors::range0(len(vals)), [&](const Nat& i) { return std::tuple{or_(index(fields, i), Text("arg")), or_(index(vals, i), Ex(Ex::XUnit{}))}; })})})})})}));
            });
        });
        });
    });
    });
    })
        : prism_rtl::is_none(_m) ? ({
        auto args_1 = args;
        auto callee_2 = callee;
        auto e_3 = e;
        auto env_4 = env;
        auto lx_5 = lx;
        call_then(start_local_job_fn(lx_5, env_4, callee_2), [=](std::optional<Vl> local_job_fn_148337) {
        return ({
            prism_rtl::is_some(local_job_fn_148337) ? ({
            auto&& f = prism_rtl::some_of(local_job_fn_148337);
            call_then(start_start_args(lx_5, env_4, f, args_1), [=](Array<Ex> start_args_148406) { return prism_rtl::finished(Ex(Ex::XMethod{prism_rtl::rc(start_call(f, start_args_148406)), Text("cycle"), Array<Ex>{}})); });
        })
            : prism_rtl::is_none(local_job_fn_148337) ? call_then(start_prelude_job_call(lx_5, env_4, e_3), [=](std::optional<Ex> prelude_job_call_148473) {
            return ({
                prism_rtl::is_some(prelude_job_call_148473) ? ({
                auto&& job = prism_rtl::some_of(prelude_job_call_148473);
                prism_rtl::finished(Ex(Ex::XMethod{prism_rtl::rc(job), Text("cycle"), Array<Ex>{}}));
            })
                : prism_rtl::is_none(prelude_job_call_148473) ? call_then(start_value_of(lx_5, env_4, e_3), [=](Vl value_of_148614) { return prism_rtl::finished(Ex(Ex::XCtor{Text("prism_rtl::Turn::Finished"), Array(std::vector{own(value_of_148614)})})); })
                : throw prism_rtl::Panic("no arm matched");
            });
        })
            : throw prism_rtl::Panic("no arm matched");
        });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : ({
        auto e_1 = e;
        auto env_2 = env;
        auto lx_3 = lx;
        call_then(start_value_of(lx_3, env_2, e_1), [=](Vl value_of_148693) { return prism_rtl::finished(Ex(Ex::XCtor{Text("prism_rtl::Turn::Finished"), Array(std::vector{own(value_of_148693)})})); });
    });
    });
}


/// `Start TailHere, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Ex> start_tail_here(Lx lx, Env env, ast::Expr e) {
    return std::make_shared<TailHere>(lx, env, e);
}


/// TailBlock: unbounded fn Lx, Env, Block -> Ex
Ex tail_block(const Lx& lx, const Env& env, const ast::Block& b) {
    return tail_from(lx, env, b, Nat(0u));
}


prism_rtl::Turn<Ex> TailBlock::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& b = this->b;
    return prism_rtl::more(prism_rtl::rc(TailFrom(lx, env, b, Nat(0u))));
}


/// `Start TailBlock, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Ex> start_tail_block(Lx lx, Env env, ast::Block b) {
    return std::make_shared<TailBlock>(lx, env, b);
}


/// TailFrom: unbounded fn Lx, Env, Block, Nat -> Ex
Ex tail_from(const Lx& lx, const Env& env, const ast::Block& b, const Nat& i) {
    auto s = or_(index(b.stmts, i), dummy_stmt_l());
    return (i + Nat(1u)) >= len(b.stmts)
        ? ({
        __label__ _done;
        prism_rtl::Slot<Ex> _v;
        auto&& _m = s.kind;
        if (prism_rtl::is<ast::StmtKind::SExpr>(_m)) {
            auto&& x = prism_rtl::as<ast::StmtKind::SExpr>(_m).a0;
            _v.set(tail(lx, env, x));
            goto _done;
        }
        {
            _v.set(Ex(Ex::XCtor{Text("prism_rtl::Turn::Finished"), Array(std::vector{Ex(Ex::XUnit{})})}));
            goto _done;
        }
    _done:
        _v.take();
    })
        : ({
        auto found_opt = ({
            __label__ _done;
            prism_rtl::Slot<std::optional<ast::Expr>> _v;
            auto&& _m = s.kind;
            if (prism_rtl::is<ast::StmtKind::SLet>(_m)) {
                auto&& x = prism_rtl::as<ast::StmtKind::SLet>(_m).a2;
                _v.set(frame_call(lx, env, x, false));
                goto _done;
            }
            if (prism_rtl::is<ast::StmtKind::SExpr>(_m)) {
                auto&& x = prism_rtl::as<ast::StmtKind::SExpr>(_m).a0;
                _v.set(frame_call(lx, env, x, false));
                goto _done;
            }
            {
                _v.set(std::optional<ast::Expr>{});
                goto _done;
            }
        _done:
            _v.take();
        });
        auto looping_opt = ({
            __label__ _done;
            prism_rtl::Slot<std::optional<std::tuple<ast::Pattern_, ast::Expr, ast::Block, ast::Expr>>> _v;
            auto&& _m = s.kind;
            if (prism_rtl::is<ast::StmtKind::SLet>(_m)) {
                auto&& p_ = prism_rtl::as<ast::StmtKind::SLet>(_m).a0;
                auto&& x = prism_rtl::as<ast::StmtKind::SLet>(_m).a2;
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<std::optional<std::tuple<ast::Pattern_, ast::Expr, ast::Block, ast::Expr>>> _v;
                    auto&& _m = x.kind;
                    if (prism_rtl::is<ast::ExprKind::EUpdate>(_m)) {
                        auto&& target = prism_rtl::as<ast::ExprKind::EUpdate>(_m).a0;
                        auto&& ub = prism_rtl::as<ast::ExprKind::EUpdate>(_m).a1;
                        _v.set(has_top_while(lx, ub)
                            ? std::optional(std::tuple{p_, target, ub, x})
                            : std::optional<std::tuple<ast::Pattern_, ast::Expr, ast::Block, ast::Expr>>{});
                        goto _done;
                    }
                    {
                        _v.set(std::optional<std::tuple<ast::Pattern_, ast::Expr, ast::Block, ast::Expr>>{});
                        goto _done;
                    }
                _done:
                    _v.take();
                }));
                goto _done;
            }
            {
                _v.set(std::optional<std::tuple<ast::Pattern_, ast::Expr, ast::Block, ast::Expr>>{});
                goto _done;
            }
        _done:
            _v.take();
        });
        ({
        __label__ _done;
        prism_rtl::Slot<Ex> _v;
        if (prism_rtl::is_some(looping_opt)) {
            auto&& p_ = std::get<0>(prism_rtl::some_of(looping_opt));
            auto&& target = std::get<1>(prism_rtl::some_of(looping_opt));
            auto&& ub = std::get<2>(prism_rtl::some_of(looping_opt));
            auto&& x = std::get<3>(prism_rtl::some_of(looping_opt));
            _v.set(upd_tail(lx, env, target, ub, b.span, ({
                auto lx_1 = lx;
                auto p__2 = p_;
                auto x_3 = x;
                auto s_4 = s;
                auto b_5 = b;
                auto i_6 = i;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Env, Ex>)>>(prism_rtl::rc([=](std::tuple<Env, Ex> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto lx_1_7 = lx_1;
                    auto p__2_7 = p__2;
                    auto x_3_7 = x_3;
                    auto s_4_7 = s_4;
                    auto b_5_7 = b_5;
                    auto i_6_7 = i_6;
                    entered(once_job([=]() {
                    return ({
                        auto en = p0;
                        auto v_ = p1;
                        call_then(start_rust_pat(lx_1_7, p__2_7, type_at(lx_1_7, x_3_7.span), Holding(Holding::Owned{}), prism_rtl::cat("l", s_4_7.span.start)), [=](PatOut rust_pat_149816) {
                        return ({
                            auto po = rust_pat_149816;
                            call_then(start_tail_from(lx_1_7, bind_all(en, po.binds), b_5_7, i_6_7 + Nat(1u)), [=](Ex tail_from_149908) {
                            return ({
                                auto rest = tail_from_149908;
                                (prism_rtl::finished(prepend(Array(std::vector{Do(Do::DoLet{po.pa, v_})}), rest)));
                            });
                        });
                        });
                    });
                    });
                }));
                });
            })));
            })));
            goto _done;
        }
        if (prism_rtl::is_none(looping_opt)) {
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<Ex> _v;
                if (prism_rtl::is_some(found_opt)) {
                    auto&& c = prism_rtl::some_of(found_opt);
                    _v.set(frame(lx, env, c, rest_text(lx, s.span, c.span, b.span), ({
                        auto lx_1 = lx;
                        auto b_2 = b;
                        auto i_3 = i;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(Env)>>(prism_rtl::rc([=](Env p0) {
                        return ({
                            auto lx_1_4 = lx_1;
                            auto b_2_4 = b_2;
                            auto i_3_4 = i_3;
                            entered(once_job([=]() {
                            return ({
                                auto env2 = p0;
                                (prism_rtl::more(prism_rtl::rc(TailFrom(lx_1_4, env2, b_2_4, i_3_4))));
                            });
                        }));
                        });
                    })));
                    })));
                    goto _done;
                }
                if (prism_rtl::is_none(found_opt)) {
                    _v.set(({
                        auto [dos, env2] = block_stmt(lx, env, s);
                        ({
                        __label__ _done;
                        prism_rtl::Slot<Ex> _v;
                        auto&& _m = tail_from(lx, env2, b, i + Nat(1u));
                        if (prism_rtl::is<Ex::XBlock>(_m)) {
                            auto&& more = prism_rtl::as<Ex::XBlock>(_m).a0;
                            auto&& last = prism_rtl::as<Ex::XBlock>(_m).a1;
                            _v.set(Ex(Ex::XBlock{append(dos, more), prism_rtl::rc(last)}));
                            goto _done;
                        }
                        {
                            auto&& last = _m;
                            _v.set(len(dos) == Nat(0u) ? last : Ex(Ex::XBlock{dos, prism_rtl::rc(last)}));
                            goto _done;
                        }
                    _done:
                        _v.take();
                    });
                    }));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    });
}


prism_rtl::Turn<Ex> TailFrom::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& b = this->b;
    const auto& i = this->i;
    auto s = or_(index(b.stmts, i), dummy_stmt_l());
    return (i + Nat(1u)) >= len(b.stmts)
        ? ({
        auto&& _m = s.kind;
        prism_rtl::is<ast::StmtKind::SExpr>(_m) ? ({
        auto&& x = prism_rtl::as<ast::StmtKind::SExpr>(_m).a0;
        prism_rtl::more(prism_rtl::rc(Tail(lx, env, x)));
    })
        : prism_rtl::finished(Ex(Ex::XCtor{Text("prism_rtl::Turn::Finished"), Array(std::vector{Ex(Ex::XUnit{})})}));
    })
        : ({
        auto found_opt = ({
            __label__ _done;
            prism_rtl::Slot<std::optional<ast::Expr>> _v;
            auto&& _m = s.kind;
            if (prism_rtl::is<ast::StmtKind::SLet>(_m)) {
                auto&& x = prism_rtl::as<ast::StmtKind::SLet>(_m).a2;
                _v.set(frame_call(lx, env, x, false));
                goto _done;
            }
            if (prism_rtl::is<ast::StmtKind::SExpr>(_m)) {
                auto&& x = prism_rtl::as<ast::StmtKind::SExpr>(_m).a0;
                _v.set(frame_call(lx, env, x, false));
                goto _done;
            }
            {
                _v.set(std::optional<ast::Expr>{});
                goto _done;
            }
        _done:
            _v.take();
        });
        auto looping_opt = ({
            __label__ _done;
            prism_rtl::Slot<std::optional<std::tuple<ast::Pattern_, ast::Expr, ast::Block, ast::Expr>>> _v;
            auto&& _m = s.kind;
            if (prism_rtl::is<ast::StmtKind::SLet>(_m)) {
                auto&& p_ = prism_rtl::as<ast::StmtKind::SLet>(_m).a0;
                auto&& x = prism_rtl::as<ast::StmtKind::SLet>(_m).a2;
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<std::optional<std::tuple<ast::Pattern_, ast::Expr, ast::Block, ast::Expr>>> _v;
                    auto&& _m = x.kind;
                    if (prism_rtl::is<ast::ExprKind::EUpdate>(_m)) {
                        auto&& target = prism_rtl::as<ast::ExprKind::EUpdate>(_m).a0;
                        auto&& ub = prism_rtl::as<ast::ExprKind::EUpdate>(_m).a1;
                        _v.set(has_top_while(lx, ub)
                            ? std::optional(std::tuple{p_, target, ub, x})
                            : std::optional<std::tuple<ast::Pattern_, ast::Expr, ast::Block, ast::Expr>>{});
                        goto _done;
                    }
                    {
                        _v.set(std::optional<std::tuple<ast::Pattern_, ast::Expr, ast::Block, ast::Expr>>{});
                        goto _done;
                    }
                _done:
                    _v.take();
                }));
                goto _done;
            }
            {
                _v.set(std::optional<std::tuple<ast::Pattern_, ast::Expr, ast::Block, ast::Expr>>{});
                goto _done;
            }
        _done:
            _v.take();
        });
        ({
        prism_rtl::is_some(looping_opt) ? ({
        auto&& p_ = std::get<0>(prism_rtl::some_of(looping_opt));
        auto&& target = std::get<1>(prism_rtl::some_of(looping_opt));
        auto&& ub = std::get<2>(prism_rtl::some_of(looping_opt));
        auto&& x = std::get<3>(prism_rtl::some_of(looping_opt));
        prism_rtl::more(prism_rtl::rc(UpdTail(lx, env, target, ub, b.span, ({
        auto lx_1 = lx;
        auto p__2 = p_;
        auto x_3 = x;
        auto s_4 = s;
        auto b_5 = b;
        auto i_6 = i;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Env, Ex>)>>(prism_rtl::rc([=](std::tuple<Env, Ex> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_1_7 = lx_1;
            auto p__2_7 = p__2;
            auto x_3_7 = x_3;
            auto s_4_7 = s_4;
            auto b_5_7 = b_5;
            auto i_6_7 = i_6;
            entered(once_job([=]() {
            return ({
                auto en = p0;
                auto v_ = p1;
                call_then(start_rust_pat(lx_1_7, p__2_7, type_at(lx_1_7, x_3_7.span), Holding(Holding::Owned{}), prism_rtl::cat("l", s_4_7.span.start)), [=](PatOut rust_pat_149816) {
                return ({
                    auto po = rust_pat_149816;
                    call_then(start_tail_from(lx_1_7, bind_all(en, po.binds), b_5_7, i_6_7 + Nat(1u)), [=](Ex tail_from_149908) {
                    return ({
                        auto rest = tail_from_149908;
                        (prism_rtl::finished(prepend(Array(std::vector{Do(Do::DoLet{po.pa, v_})}), rest)));
                    });
                });
                });
            });
            });
        }));
        });
    })));
    }))));
    })
        : prism_rtl::is_none(looping_opt) ? ({
        prism_rtl::is_some(found_opt) ? ({
        auto&& c = prism_rtl::some_of(found_opt);
        prism_rtl::more(prism_rtl::rc(Frame(lx, env, c, rest_text(lx, s.span, c.span, b.span), ({
        auto lx_1 = lx;
        auto b_2 = b;
        auto i_3 = i;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(Env)>>(prism_rtl::rc([=](Env p0) {
        return ({
            auto lx_1_4 = lx_1;
            auto b_2_4 = b_2;
            auto i_3_4 = i_3;
            entered(once_job([=]() {
            return ({
                auto env2 = p0;
                (prism_rtl::more(prism_rtl::rc(TailFrom(lx_1_4, env2, b_2_4, i_3_4))));
            });
        }));
        });
    })));
    }))));
    })
        : prism_rtl::is_none(found_opt) ? ({
        auto b_1 = b;
        auto env_2 = env;
        auto i_3 = i;
        auto lx_4 = lx;
        call_then(start_block_stmt(lx_4, env_2, s), [=](std::tuple<Array<Do>, Env> block_stmt_150211) {
        return ({
            auto [dos, env2] = block_stmt_150211;
            call_then(start_tail_from(lx_4, env2, b_1, i_3 + Nat(1u)), [=](Ex tail_from_150258) {
            return ({
                prism_rtl::is<Ex::XBlock>(tail_from_150258) ? ({
                auto&& more = prism_rtl::as<Ex::XBlock>(tail_from_150258).a0;
                auto&& last = prism_rtl::as<Ex::XBlock>(tail_from_150258).a1;
                prism_rtl::finished(Ex(Ex::XBlock{append(dos, more), prism_rtl::rc(last)}));
            })
                : ({
                auto&& last = tail_from_150258;
                len(dos) == Nat(0u)
                ? prism_rtl::finished(last)
                : prism_rtl::finished(Ex(Ex::XBlock{dos, prism_rtl::rc(last)}));
            });
            });
        });
        });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    });
}


/// `Start TailFrom, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Ex> start_tail_from(Lx lx, Env env, ast::Block b, Nat i) {
    return std::make_shared<TailFrom>(lx, env, b, i);
}


/// HasTopWhile: fn Lx, Block -> Bool
bool has_top_while(const Lx& lx, const ast::Block& b) {
    return fold(b.stmts, false, [&](const bool& f, const ast::Stmt& st) { return (f || is_cycle_while(lx, st)) || holds_cycle_while(lx, st); });
}


/// IsCycleWhile: fn Lx, Stmt -> Bool
bool is_cycle_while(const Lx& lx, const ast::Stmt& st) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = st.kind;
        if (prism_rtl::is<ast::StmtKind::SWhile>(_m)) {
            _v.set(check_env::has_key(lx.unshrunk, place_key(lx, st.span)));
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// ElseHasTopWhile: fn Lx, ?Block -> Bool
bool else_has_top_while(const Lx& lx, const std::optional<ast::Block>& opt1) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        if (prism_rtl::is_some(opt1)) {
            auto&& b = prism_rtl::some_of(opt1);
            _v.set(has_top_while(lx, b));
            goto _done;
        }
        if (prism_rtl::is_none(opt1)) {
            _v.set(false);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// HoldsCycleWhile: fn Lx, Stmt -> Bool
bool holds_cycle_while(const Lx& lx, const ast::Stmt& st) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = st.kind;
        if (prism_rtl::is<ast::StmtKind::SWhile>(_m)) {
            auto&& wb = prism_rtl::as<ast::StmtKind::SWhile>(_m).a1;
            _v.set(has_top_while(lx, wb));
            goto _done;
        }
        if (prism_rtl::is<ast::StmtKind::SExpr>(_m)) {
            auto&& x = prism_rtl::as<ast::StmtKind::SExpr>(_m).a0;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<bool> _v;
                auto&& _m = x.kind;
                if (prism_rtl::is<ast::ExprKind::EIf>(_m)) {
                    auto&& then_b = prism_rtl::as<ast::ExprKind::EIf>(_m).a1;
                    auto&& else_b_opt = prism_rtl::as<ast::ExprKind::EIf>(_m).a2;
                    _v.set(has_top_while(lx, then_b) || else_has_top_while(lx, else_b_opt));
                    goto _done;
                }
                {
                    _v.set(false);
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// UpdTail: unbounded fn Lx, Env, Expr, Block, Range, (unbounded fn Env, Ex -> Ex) -> Ex
Ex upd_tail(const Lx& lx, const Env& env, const ast::Expr& target, const ast::Block& b, const ast::Range& to, const prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Env, Ex>)>& cont_fn) {
    auto t = out_ty_of(lx, peel(type_at(lx, target.span)));
    auto tv = value_of(lx, env, target);
    auto env1 = bind(env, Text("&_"), Bn(Bn::BnLocal{Ex(Ex::XVar{Text("this")}), Holding(Holding::Owned{}), t}));
    return prepend(Array(std::vector{Do(Do::DoLet{Pa(Pa::PaTyped{prism_rtl::rc(Pa(Pa::PaMut{Text("this")})), t}), own(tv)})}), upd_tail_from(lx, env, env1, b, Nat(0u), to, cont_fn));
}


prism_rtl::Turn<Ex> UpdTail::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& target = this->target;
    const auto& b = this->b;
    const auto& to = this->to;
    const auto& cont_fn = this->cont_fn;
    auto cont_fn_1 = cont_fn;
    auto b_2 = b;
    auto env_3 = env;
    auto lx_4 = lx;
    auto target_5 = target;
    auto to_6 = to;
    return call_then(start_out_ty_of(lx_4, peel(type_at(lx_4, target_5.span))), [=](OutTy out_ty_of_152510) {
        return ({
            auto t = out_ty_of_152510;
            call_then(start_value_of(lx_4, env_3, target_5), [=](Vl value_of_152567) {
            return ({
                auto tv = value_of_152567;
                auto env1 = bind(env_3, Text("&_"), Bn(Bn::BnLocal{Ex(Ex::XVar{Text("this")}), Holding(Holding::Owned{}), t}));
                call_then(start_upd_tail_from(lx_4, env_3, env1, b_2, Nat(0u), to_6, cont_fn_1), [=](Ex upd_tail_from_152720) { return prism_rtl::finished(prepend(Array(std::vector{Do(Do::DoLet{Pa(Pa::PaTyped{prism_rtl::rc(Pa(Pa::PaMut{Text("this")})), t}), own(tv)})}), upd_tail_from_152720)); });
            });
        });
        });
    });
}


/// `Start UpdTail, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Ex> start_upd_tail(Lx lx, Env env, ast::Expr target, ast::Block b, ast::Range to, prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Env, Ex>)> cont_fn) {
    return std::make_shared<UpdTail>(lx, env, target, b, to, cont_fn);
}


/// UpdTailFrom: unbounded fn Lx, Env, Env, Block, Nat, Range, (unbounded fn Env, Ex -> Ex) -> Ex
Ex upd_tail_from(const Lx& lx, const Env& outer, const Env& env, const ast::Block& b, const Nat& i, const ast::Range& to, const prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Env, Ex>)>& cont_fn) {
    return i >= len(b.stmts)
        ? run_to_end(cont_fn(std::tuple{outer, Ex(Ex::XVar{Text("this")})}))
        : ({
        auto s = or_(index(b.stmts, i), dummy_stmt_l());
        auto rest = rest_text(lx, ast::Range{.start = s.span.end, .end = s.span.end}, ast::Range{.start = s.span.end, .end = s.span.end}, to);
        auto next_fn = ({
            auto lx_1 = lx;
            auto b_2 = b;
            auto i_3 = i;
            auto to_4 = to;
            auto cont_fn_5 = cont_fn;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Env, Env>)>>(prism_rtl::rc([=](std::tuple<Env, Env> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto lx_1_6 = lx_1;
                auto b_2_6 = b_2;
                auto i_3_6 = i_3;
                auto to_4_6 = to_4;
                auto cont_fn_5_6 = cont_fn_5;
                entered(once_job([=]() {
                return ({
                    auto o2 = p0;
                    auto e2 = p1;
                    (prism_rtl::more(prism_rtl::rc(UpdTailFrom(lx_1_6, o2, e2, b_2_6, i_3_6 + Nat(1u), to_4_6, cont_fn_5_6))));
                });
            }));
            });
        })));
        });
        auto loop__opt = ({
            __label__ _done;
            prism_rtl::Slot<std::optional<std::tuple<ast::Cond, ast::Block>>> _v;
            auto&& _m = s.kind;
            if (prism_rtl::is<ast::StmtKind::SWhile>(_m)) {
                auto&& c = prism_rtl::as<ast::StmtKind::SWhile>(_m).a0;
                auto&& wb = prism_rtl::as<ast::StmtKind::SWhile>(_m).a1;
                _v.set(is_cycle_while(lx, s) || holds_cycle_while(lx, s)
                    ? std::optional(std::tuple{c, wb})
                    : std::optional<std::tuple<ast::Cond, ast::Block>>{});
                goto _done;
            }
            {
                _v.set(std::optional<std::tuple<ast::Cond, ast::Block>>{});
                goto _done;
            }
        _done:
            _v.take();
        });
        auto branch_opt = ({
            __label__ _done;
            prism_rtl::Slot<std::optional<std::tuple<ast::Cond, ast::Block, std::optional<ast::Block>>>> _v;
            auto&& _m = s.kind;
            if (prism_rtl::is<ast::StmtKind::SExpr>(_m)) {
                auto&& x = prism_rtl::as<ast::StmtKind::SExpr>(_m).a0;
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<std::optional<std::tuple<ast::Cond, ast::Block, std::optional<ast::Block>>>> _v;
                    auto&& _m = x.kind;
                    if (prism_rtl::is<ast::ExprKind::EIf>(_m)) {
                        auto&& c = prism_rtl::as<ast::ExprKind::EIf>(_m).a0;
                        auto&& then_b = prism_rtl::as<ast::ExprKind::EIf>(_m).a1;
                        auto&& else_b_opt = prism_rtl::as<ast::ExprKind::EIf>(_m).a2;
                        _v.set(holds_cycle_while(lx, s)
                            ? std::optional(std::tuple{c, then_b, else_b_opt})
                            : std::optional<std::tuple<ast::Cond, ast::Block, std::optional<ast::Block>>>{});
                        goto _done;
                    }
                    {
                        _v.set(std::optional<std::tuple<ast::Cond, ast::Block, std::optional<ast::Block>>>{});
                        goto _done;
                    }
                _done:
                    _v.take();
                }));
                goto _done;
            }
            {
                _v.set(std::optional<std::tuple<ast::Cond, ast::Block, std::optional<ast::Block>>>{});
                goto _done;
            }
        _done:
            _v.take();
        });
        ({
        __label__ _done;
        prism_rtl::Slot<Ex> _v;
        auto&& _m = std::tuple{loop__opt, branch_opt};
        if (prism_rtl::is_some(std::get<0>(_m))) {
            auto&& c = std::get<0>(prism_rtl::some_of(std::get<0>(_m)));
            auto&& wb = std::get<1>(prism_rtl::some_of(std::get<0>(_m)));
            _v.set(while_job(lx, outer, env, c, wb, s.span, rest, next_fn));
            goto _done;
        }
        if (prism_rtl::is_none(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m))) {
            auto&& c = std::get<0>(prism_rtl::some_of(std::get<1>(_m)));
            auto&& then_b = std::get<1>(prism_rtl::some_of(std::get<1>(_m)));
            auto&& else_b_opt = std::get<2>(prism_rtl::some_of(std::get<1>(_m)));
            _v.set(if_job(lx, outer, env, c, then_b, else_b_opt, s.span, rest, next_fn));
            goto _done;
        }
        {
            _v.set(({
                auto [dos, env2] = upd_stmt(lx, env, s);
                prepend(dos, upd_tail_from(lx, outer, env2, b, i + Nat(1u), to, cont_fn));
            }));
            goto _done;
        }
    _done:
        _v.take();
    });
    });
}


prism_rtl::Turn<Ex> UpdTailFrom::cycle() const {
    const auto& lx = this->lx;
    const auto& outer = this->outer;
    const auto& env = this->env;
    const auto& b = this->b;
    const auto& i = this->i;
    const auto& to = this->to;
    const auto& cont_fn = this->cont_fn;
    return i >= len(b.stmts)
        ? cont_fn(std::tuple{outer, Ex(Ex::XVar{Text("this")})})->cycle()
        : ({
        auto s = or_(index(b.stmts, i), dummy_stmt_l());
        auto rest = rest_text(lx, ast::Range{.start = s.span.end, .end = s.span.end}, ast::Range{.start = s.span.end, .end = s.span.end}, to);
        auto next_fn = ({
            auto lx_1 = lx;
            auto b_2 = b;
            auto i_3 = i;
            auto to_4 = to;
            auto cont_fn_5 = cont_fn;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Env, Env>)>>(prism_rtl::rc([=](std::tuple<Env, Env> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto lx_1_6 = lx_1;
                auto b_2_6 = b_2;
                auto i_3_6 = i_3;
                auto to_4_6 = to_4;
                auto cont_fn_5_6 = cont_fn_5;
                entered(once_job([=]() {
                return ({
                    auto o2 = p0;
                    auto e2 = p1;
                    (prism_rtl::more(prism_rtl::rc(UpdTailFrom(lx_1_6, o2, e2, b_2_6, i_3_6 + Nat(1u), to_4_6, cont_fn_5_6))));
                });
            }));
            });
        })));
        });
        auto loop__opt = ({
            __label__ _done;
            prism_rtl::Slot<std::optional<std::tuple<ast::Cond, ast::Block>>> _v;
            auto&& _m = s.kind;
            if (prism_rtl::is<ast::StmtKind::SWhile>(_m)) {
                auto&& c = prism_rtl::as<ast::StmtKind::SWhile>(_m).a0;
                auto&& wb = prism_rtl::as<ast::StmtKind::SWhile>(_m).a1;
                _v.set(is_cycle_while(lx, s) || holds_cycle_while(lx, s)
                    ? std::optional(std::tuple{c, wb})
                    : std::optional<std::tuple<ast::Cond, ast::Block>>{});
                goto _done;
            }
            {
                _v.set(std::optional<std::tuple<ast::Cond, ast::Block>>{});
                goto _done;
            }
        _done:
            _v.take();
        });
        auto branch_opt = ({
            __label__ _done;
            prism_rtl::Slot<std::optional<std::tuple<ast::Cond, ast::Block, std::optional<ast::Block>>>> _v;
            auto&& _m = s.kind;
            if (prism_rtl::is<ast::StmtKind::SExpr>(_m)) {
                auto&& x = prism_rtl::as<ast::StmtKind::SExpr>(_m).a0;
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<std::optional<std::tuple<ast::Cond, ast::Block, std::optional<ast::Block>>>> _v;
                    auto&& _m = x.kind;
                    if (prism_rtl::is<ast::ExprKind::EIf>(_m)) {
                        auto&& c = prism_rtl::as<ast::ExprKind::EIf>(_m).a0;
                        auto&& then_b = prism_rtl::as<ast::ExprKind::EIf>(_m).a1;
                        auto&& else_b_opt = prism_rtl::as<ast::ExprKind::EIf>(_m).a2;
                        _v.set(holds_cycle_while(lx, s)
                            ? std::optional(std::tuple{c, then_b, else_b_opt})
                            : std::optional<std::tuple<ast::Cond, ast::Block, std::optional<ast::Block>>>{});
                        goto _done;
                    }
                    {
                        _v.set(std::optional<std::tuple<ast::Cond, ast::Block, std::optional<ast::Block>>>{});
                        goto _done;
                    }
                _done:
                    _v.take();
                }));
                goto _done;
            }
            {
                _v.set(std::optional<std::tuple<ast::Cond, ast::Block, std::optional<ast::Block>>>{});
                goto _done;
            }
        _done:
            _v.take();
        });
        ({
        auto&& _m = std::tuple{loop__opt, branch_opt};
        prism_rtl::is_some(std::get<0>(_m)) ? ({
        auto&& c = std::get<0>(prism_rtl::some_of(std::get<0>(_m)));
        auto&& wb = std::get<1>(prism_rtl::some_of(std::get<0>(_m)));
        prism_rtl::more(prism_rtl::rc(WhileJob(lx, outer, env, c, wb, s.span, rest, next_fn)));
    })
        : prism_rtl::is_none(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m)) ? ({
        auto&& c = std::get<0>(prism_rtl::some_of(std::get<1>(_m)));
        auto&& then_b = std::get<1>(prism_rtl::some_of(std::get<1>(_m)));
        auto&& else_b_opt = std::get<2>(prism_rtl::some_of(std::get<1>(_m)));
        prism_rtl::more(prism_rtl::rc(IfJob(lx, outer, env, c, then_b, else_b_opt, s.span, rest, next_fn)));
    })
        : ({
        auto cont_fn_1 = cont_fn;
        auto b_2 = b;
        auto env_3 = env;
        auto i_4 = i;
        auto lx_5 = lx;
        auto outer_6 = outer;
        auto to_7 = to;
        call_then(start_upd_stmt(lx_5, env_3, s), [=](std::tuple<Array<Do>, Env> upd_stmt_153875) {
        return ({
            auto [dos, env2] = upd_stmt_153875;
            call_then(start_upd_tail_from(lx_5, outer_6, env2, b_2, i_4 + Nat(1u), to_7, cont_fn_1), [=](Ex upd_tail_from_153924) { return prism_rtl::finished(prepend(dos, upd_tail_from_153924)); });
        });
    });
    });
    });
    });
}


/// `Start UpdTailFrom, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Ex> start_upd_tail_from(Lx lx, Env outer, Env env, ast::Block b, Nat i, ast::Range to, prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Env, Ex>)> cont_fn) {
    return std::make_shared<UpdTailFrom>(lx, outer, env, b, i, to, cont_fn);
}


/// Prepend: fn [Do], Ex -> Ex
Ex prepend(const Array<Do>& dos, const Ex& ex1) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Ex> _v;
        if (prism_rtl::is<Ex::XBlock>(ex1)) {
            auto&& more = prism_rtl::as<Ex::XBlock>(ex1).a0;
            auto&& last = prism_rtl::as<Ex::XBlock>(ex1).a1;
            _v.set(Ex(Ex::XBlock{append(dos, more), prism_rtl::rc(last)}));
            goto _done;
        }
        {
            auto&& x = ex1;
            _v.set(len(dos) == Nat(0u) ? x : Ex(Ex::XBlock{dos, prism_rtl::rc(x)}));
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// WhileJob: unbounded fn Lx, Env, Env, Cond, Block, Range, Text, (unbounded fn Env, Env -> Ex) -> Ex
Ex while_job(const Lx& lx, const Env& outer, const Env& env, const ast::Cond& c, const ast::Block& wb, const ast::Range& span, const Text& rest_text_, const prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Env, Env>)>& cont_fn) {
    auto state = fold(keys(env->names), Array<std::tuple<Text, Text, OutTy>>{}, [&](const Array<std::tuple<Text, Text, OutTy>>& acc, const Text& k) {
        return take_text(k, Nat(1u)) != Text("&")
            ? acc
            : ({
            __label__ _done;
            prism_rtl::Slot<Array<std::tuple<Text, Text, OutTy>>> _v;
            auto&& _m = prelude::get(env->names, k);
            if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m))) {
                auto&& rs = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                auto&& bt = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                _v.set(prelude::push(acc, std::tuple{k, place_stem(rs), bt}));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto names = each(state, [&](const std::tuple<Text, Text, OutTy>& _p0) {
        auto&& rs = std::get<1>(_p0);
        return rs;
    });
    auto st_ty = OutTy(OutTy::OutTuple{each(state, [&](const std::tuple<Text, Text, OutTy>& _p0) {
        auto&& bt = std::get<2>(_p0);
        return bt;
    })});
    auto pat = Pa(Pa::PaTuple{each(names, [&](const Text& n) { return Pa(Pa::PaMut{prism_rtl::cat(n)}); })});
    auto pack = Ex(Ex::XTuple{each(names, [&](const Text& n) { return Ex(Ex::XVar{n}); })});
    auto env_s = fold(state, env, [&](const Env& en, const std::tuple<Text, Text, OutTy>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        auto&& bt = std::get<2>(_p1);
        return bind(en, k, Bn(Bn::BnLocal{Ex(Ex::XVar{rs}), Holding(Holding::Owned{}), bt}));
    });
    auto loop_text = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = index(lx.g.srcs, lx->file);
        if (prism_rtl::is_some(_m)) {
            auto&& src = prism_rtl::some_of(_m);
            _v.set(check_errors::span_text(src, span));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto caps = caps_in(env_s, loop_text, names);
    auto cap_dos = each(caps, [&](const std::tuple<Text, Ex, Holding, OutTy>& _p0) {
        auto&& rs = std::get<1>(_p0);
        auto&& mode = std::get<2>(_p0);
        auto&& bt = std::get<3>(_p0);
        return Do(Do::DoLet{Pa(Pa::PaBind{place_stem(rs)}), own(Vl(Vl::VlPlace{rs, mode, bt}))});
    });
    auto env_c = fold(caps, env_s, [&](const Env& en, const std::tuple<Text, Ex, Holding, OutTy>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        auto&& bt = std::get<3>(_p1);
        return bind(en, k, Bn(Bn::BnLocal{Ex(Ex::XVar{place_stem(rs)}), Holding(Holding::Owned{}), bt}));
    });
    auto jobs = has_top_while(lx, wb);
    auto finish_fn = ({
        auto jobs_1 = jobs;
        (prism_rtl::rc([=](const Ex& x) {
        return jobs_1
            ? Ex(Ex::XCtor{Text("prism_rtl::Turn::Finished"), Array(std::vector{x})})
            : x;
    }));
    });
    auto step_ty = OutTy(OutTy::OutNamed{Text("Result"), Array(std::vector{st_ty, st_ty})});
    auto again = finish_fn(Ex(Ex::XTyped{prism_rtl::rc(Ex(Ex::XCtor{Text("Ok"), Array(std::vector{pack})})), step_ty}));
    auto stop = finish_fn(Ex(Ex::XTyped{prism_rtl::rc(Ex(Ex::XCtor{Text("Err"), Array(std::vector{pack})})), step_ty}));
    auto body_fn = ({
        auto jobs_1 = jobs;
        auto lx_2 = lx;
        auto wb_3 = wb;
        auto again_4 = again;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(Env)>>(prism_rtl::rc([=](Env p0) {
        return ({
            auto jobs_1_5 = jobs_1;
            auto lx_2_5 = lx_2;
            auto wb_3_5 = wb_3;
            auto again_4_5 = again_4;
            entered(once_job([=]() {
            return ({
                auto en = p0;
                jobs_1_5
                ? prism_rtl::more(prism_rtl::rc(UpdTailFrom(lx_2_5, en, en, wb_3_5, Nat(0u), wb_3_5.span, ({
                auto again_4_5_5 = again_4_5;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Env, Ex>)>>(prism_rtl::rc([=](std::tuple<Env, Ex> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto again_4_5_5_5 = again_4_5_5;
                    once_job([=]() {
                    return ({
                        auto o2 = p0;
                        auto e2 = p1;
                        (prism_rtl::finished(again_4_5_5_5));
                    });
                });
                });
            })));
            }))))
                : prism_rtl::more(prism_rtl::rc(StmtsThen(lx_2_5, en, wb_3_5, again_4_5)));
            });
        }));
        });
    })));
    });
    auto res_ty = jobs
        ? OutTy(OutTy::OutNamed{Text("prism_rtl::Turn"), Array(std::vector{step_ty})})
        : st_ty;
    auto turn = ({
        __label__ _done;
        prism_rtl::Slot<Ex> _v;
        if (prism_rtl::is<ast::Cond::CondExpr>(c)) {
            auto&& x = prism_rtl::as<ast::Cond::CondExpr>(c).a0;
            _v.set(Ex(Ex::XIf{prism_rtl::rc(as_bool(value_of(lx, env_c, x))), prism_rtl::rc(run_to_end(body_fn(env_c))), prism_rtl::rc(stop)}));
            goto _done;
        }
        if (prism_rtl::is<ast::Cond::CondBind>(c)) {
            auto&& p_ = prism_rtl::as<ast::Cond::CondBind>(c).a0;
            auto&& x = prism_rtl::as<ast::Cond::CondBind>(c).a1;
            auto&& g_opt = prism_rtl::as<ast::Cond::CondBind>(c).a2;
            _v.set(({
                auto po = rust_pat(lx, p_, type_at(lx, x.span), Holding(Holding::Owned{}), prism_rtl::cat("w", span.start));
                auto env_b = bind_all(env_c, po.binds);
                auto conds = append(po.conds, guard_conds(lx, env_b, g_opt));
                own(arms_value(own(value_of(lx, env_c, x)), Array(std::vector{XArm{.pat = po.pa, .conds = conds, .body = run_to_end(body_fn(env_b))}, XArm{.pat = Pa(Pa::PaWild{}), .conds = Array<Cc>{}, .body = stop}}), prism_rtl::cat("'w", span.start), res_ty));
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto out_caps = caps_in(outer, rest_text_, names);
    auto out_dos = each(out_caps, [&](const std::tuple<Text, Ex, Holding, OutTy>& _p0) {
        auto&& rs = std::get<1>(_p0);
        auto&& mode = std::get<2>(_p0);
        auto&& bt = std::get<3>(_p0);
        return Do(Do::DoLet{Pa(Pa::PaBind{place_stem(rs)}), own(Vl(Vl::VlPlace{rs, mode, bt}))});
    });
    auto outer2 = fold(out_caps, outer, [&](const Env& en, const std::tuple<Text, Ex, Holding, OutTy>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        auto&& bt = std::get<3>(_p1);
        return bind(en, k, Bn(Bn::BnLocal{Ex(Ex::XVar{place_stem(rs)}), Holding(Holding::Owned{}), bt}));
    });
    auto env2 = fold(out_caps, env_s, [&](const Env& en, const std::tuple<Text, Ex, Holding, OutTy>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        auto&& bt = std::get<3>(_p1);
        return bind(en, k, Bn(Bn::BnLocal{Ex(Ex::XVar{place_stem(rs)}), Holding(Holding::Owned{}), bt}));
    });
    auto step_fn = prepend(cap_dos, Ex(Ex::XClosure{true, Array(std::vector{Pa(Pa::PaTyped{prism_rtl::rc(pat), st_ty})}), prism_rtl::rc(turn)}));
    auto looping = jobs ? Text("loop_turns") : Text("loop_job");
    auto enter = Ex(Ex::XCall{Text("call_then"), Array(std::vector{Ex(Ex::XCall{looping, Array(std::vector{pack, step_fn})}), Ex(Ex::XClosure{true, Array(std::vector{Pa(Pa::PaTyped{prism_rtl::rc(pat), st_ty})}), prism_rtl::rc(run_to_end(cont_fn(std::tuple{outer2, env2})))})})});
    return prepend(out_dos, enter);
}


prism_rtl::Turn<Ex> WhileJob::cycle() const {
    const auto& lx = this->lx;
    const auto& outer = this->outer;
    const auto& env = this->env;
    const auto& c = this->c;
    const auto& wb = this->wb;
    const auto& span = this->span;
    const auto& rest_text_ = this->rest_text_;
    const auto& cont_fn = this->cont_fn;
    auto state = fold(keys(env->names), Array<std::tuple<Text, Text, OutTy>>{}, [&](const Array<std::tuple<Text, Text, OutTy>>& acc, const Text& k) {
        return take_text(k, Nat(1u)) != Text("&")
            ? acc
            : ({
            __label__ _done;
            prism_rtl::Slot<Array<std::tuple<Text, Text, OutTy>>> _v;
            auto&& _m = prelude::get(env->names, k);
            if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m))) {
                auto&& rs = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                auto&& bt = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                _v.set(prelude::push(acc, std::tuple{k, place_stem(rs), bt}));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto names = each(state, [&](const std::tuple<Text, Text, OutTy>& _p0) {
        auto&& rs = std::get<1>(_p0);
        return rs;
    });
    auto st_ty = OutTy(OutTy::OutTuple{each(state, [&](const std::tuple<Text, Text, OutTy>& _p0) {
        auto&& bt = std::get<2>(_p0);
        return bt;
    })});
    auto pat = Pa(Pa::PaTuple{each(names, [&](const Text& n) { return Pa(Pa::PaMut{prism_rtl::cat(n)}); })});
    auto pack = Ex(Ex::XTuple{each(names, [&](const Text& n) { return Ex(Ex::XVar{n}); })});
    auto env_s = fold(state, env, [&](const Env& en, const std::tuple<Text, Text, OutTy>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        auto&& bt = std::get<2>(_p1);
        return bind(en, k, Bn(Bn::BnLocal{Ex(Ex::XVar{rs}), Holding(Holding::Owned{}), bt}));
    });
    auto loop_text = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = index(lx.g.srcs, lx->file);
        if (prism_rtl::is_some(_m)) {
            auto&& src = prism_rtl::some_of(_m);
            _v.set(check_errors::span_text(src, span));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto caps = caps_in(env_s, loop_text, names);
    auto cap_dos = each(caps, [&](const std::tuple<Text, Ex, Holding, OutTy>& _p0) {
        auto&& rs = std::get<1>(_p0);
        auto&& mode = std::get<2>(_p0);
        auto&& bt = std::get<3>(_p0);
        return Do(Do::DoLet{Pa(Pa::PaBind{place_stem(rs)}), own(Vl(Vl::VlPlace{rs, mode, bt}))});
    });
    auto env_c = fold(caps, env_s, [&](const Env& en, const std::tuple<Text, Ex, Holding, OutTy>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        auto&& bt = std::get<3>(_p1);
        return bind(en, k, Bn(Bn::BnLocal{Ex(Ex::XVar{place_stem(rs)}), Holding(Holding::Owned{}), bt}));
    });
    auto jobs = has_top_while(lx, wb);
    auto finish_fn = ({
        auto jobs_1 = jobs;
        (prism_rtl::rc([=](const Ex& x) {
        return jobs_1
            ? Ex(Ex::XCtor{Text("prism_rtl::Turn::Finished"), Array(std::vector{x})})
            : x;
    }));
    });
    auto step_ty = OutTy(OutTy::OutNamed{Text("Result"), Array(std::vector{st_ty, st_ty})});
    auto again = finish_fn(Ex(Ex::XTyped{prism_rtl::rc(Ex(Ex::XCtor{Text("Ok"), Array(std::vector{pack})})), step_ty}));
    auto stop = finish_fn(Ex(Ex::XTyped{prism_rtl::rc(Ex(Ex::XCtor{Text("Err"), Array(std::vector{pack})})), step_ty}));
    auto body_fn = ({
        auto jobs_1 = jobs;
        auto lx_2 = lx;
        auto wb_3 = wb;
        auto again_4 = again;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(Env)>>(prism_rtl::rc([=](Env p0) {
        return ({
            auto jobs_1_5 = jobs_1;
            auto lx_2_5 = lx_2;
            auto wb_3_5 = wb_3;
            auto again_4_5 = again_4;
            entered(once_job([=]() {
            return ({
                auto en = p0;
                jobs_1_5
                ? prism_rtl::more(prism_rtl::rc(UpdTailFrom(lx_2_5, en, en, wb_3_5, Nat(0u), wb_3_5.span, ({
                auto again_4_5_5 = again_4_5;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Env, Ex>)>>(prism_rtl::rc([=](std::tuple<Env, Ex> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto again_4_5_5_5 = again_4_5_5;
                    once_job([=]() {
                    return ({
                        auto o2 = p0;
                        auto e2 = p1;
                        (prism_rtl::finished(again_4_5_5_5));
                    });
                });
                });
            })));
            }))))
                : prism_rtl::more(prism_rtl::rc(StmtsThen(lx_2_5, en, wb_3_5, again_4_5)));
            });
        }));
        });
    })));
    });
    auto res_ty = jobs
        ? OutTy(OutTy::OutNamed{Text("prism_rtl::Turn"), Array(std::vector{step_ty})})
        : st_ty;
    auto turn = ({
        __label__ _done;
        prism_rtl::Slot<Ex> _v;
        if (prism_rtl::is<ast::Cond::CondExpr>(c)) {
            auto&& x = prism_rtl::as<ast::Cond::CondExpr>(c).a0;
            _v.set(Ex(Ex::XIf{prism_rtl::rc(as_bool(value_of(lx, env_c, x))), prism_rtl::rc(run_to_end(body_fn(env_c))), prism_rtl::rc(stop)}));
            goto _done;
        }
        if (prism_rtl::is<ast::Cond::CondBind>(c)) {
            auto&& p_ = prism_rtl::as<ast::Cond::CondBind>(c).a0;
            auto&& x = prism_rtl::as<ast::Cond::CondBind>(c).a1;
            auto&& g_opt = prism_rtl::as<ast::Cond::CondBind>(c).a2;
            _v.set(({
                auto po = rust_pat(lx, p_, type_at(lx, x.span), Holding(Holding::Owned{}), prism_rtl::cat("w", span.start));
                auto env_b = bind_all(env_c, po.binds);
                auto conds = append(po.conds, guard_conds(lx, env_b, g_opt));
                own(arms_value(own(value_of(lx, env_c, x)), Array(std::vector{XArm{.pat = po.pa, .conds = conds, .body = run_to_end(body_fn(env_b))}, XArm{.pat = Pa(Pa::PaWild{}), .conds = Array<Cc>{}, .body = stop}}), prism_rtl::cat("'w", span.start), res_ty));
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto out_caps = caps_in(outer, rest_text_, names);
    auto out_dos = each(out_caps, [&](const std::tuple<Text, Ex, Holding, OutTy>& _p0) {
        auto&& rs = std::get<1>(_p0);
        auto&& mode = std::get<2>(_p0);
        auto&& bt = std::get<3>(_p0);
        return Do(Do::DoLet{Pa(Pa::PaBind{place_stem(rs)}), own(Vl(Vl::VlPlace{rs, mode, bt}))});
    });
    auto outer2 = fold(out_caps, outer, [&](const Env& en, const std::tuple<Text, Ex, Holding, OutTy>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        auto&& bt = std::get<3>(_p1);
        return bind(en, k, Bn(Bn::BnLocal{Ex(Ex::XVar{place_stem(rs)}), Holding(Holding::Owned{}), bt}));
    });
    auto env2 = fold(out_caps, env_s, [&](const Env& en, const std::tuple<Text, Ex, Holding, OutTy>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        auto&& bt = std::get<3>(_p1);
        return bind(en, k, Bn(Bn::BnLocal{Ex(Ex::XVar{place_stem(rs)}), Holding(Holding::Owned{}), bt}));
    });
    auto step_fn = prepend(cap_dos, Ex(Ex::XClosure{true, Array(std::vector{Pa(Pa::PaTyped{prism_rtl::rc(pat), st_ty})}), prism_rtl::rc(turn)}));
    auto looping = jobs ? Text("loop_turns") : Text("loop_job");
    auto cont_fn_1 = cont_fn;
    return call_value(cont_fn_1(std::tuple{outer2, env2}), [=](Ex cont_157494) {
        return ({
            auto enter = Ex(Ex::XCall{Text("call_then"), Array(std::vector{Ex(Ex::XCall{looping, Array(std::vector{pack, step_fn})}), Ex(Ex::XClosure{true, Array(std::vector{Pa(Pa::PaTyped{prism_rtl::rc(pat), st_ty})}), prism_rtl::rc(cont_157494)})})});
            (prism_rtl::finished(prepend(out_dos, enter)));
        });
    });
}


/// `Start WhileJob, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Ex> start_while_job(Lx lx, Env outer, Env env, ast::Cond c, ast::Block wb, ast::Range span, Text rest_text_, prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Env, Env>)> cont_fn) {
    return std::make_shared<WhileJob>(lx, outer, env, c, wb, span, rest_text_, cont_fn);
}


/// StmtsThen: unbounded fn Lx, Env, Block, Ex -> Ex
Ex stmts_then(const Lx& lx, const Env& env, const ast::Block& b, const Ex& last) {
    auto&& _dos = upd_stmts(lx, env, b.stmts);
    auto&& dos = std::get<0>(_dos);
    return Ex(Ex::XBlock{dos, prism_rtl::rc(last)});
}


prism_rtl::Turn<Ex> StmtsThen::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& b = this->b;
    const auto& last = this->last;
    auto b_1 = b;
    auto env_2 = env;
    auto last_3 = last;
    auto lx_4 = lx;
    return call_then(start_upd_stmts(lx_4, env_2, b_1.stmts), [=](std::tuple<Array<Do>, Env> upd_stmts_157707) {
        return ({
            auto&& _dos = upd_stmts_157707;
            auto&& dos = std::get<0>(_dos);
            (prism_rtl::finished(Ex(Ex::XBlock{dos, prism_rtl::rc(last_3)})));
        });
    });
}


/// `Start StmtsThen, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Ex> start_stmts_then(Lx lx, Env env, ast::Block b, Ex last) {
    return std::make_shared<StmtsThen>(lx, env, b, last);
}


/// IfJob: unbounded fn Lx, Env, Env, Cond, Block, ?Block, Range, Text, (unbounded fn Env, Env -> Ex) -> Ex
Ex if_job(const Lx& lx, const Env& outer, const Env& env, const ast::Cond& c, const ast::Block& then_b, const std::optional<ast::Block>& else_b_opt, const ast::Range& span, const Text& rest_text_, const prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Env, Env>)>& cont_fn) {
    auto state = fold(keys(env->names), Array<std::tuple<Text, Text, OutTy>>{}, [&](const Array<std::tuple<Text, Text, OutTy>>& acc, const Text& k) {
        return take_text(k, Nat(1u)) != Text("&")
            ? acc
            : ({
            __label__ _done;
            prism_rtl::Slot<Array<std::tuple<Text, Text, OutTy>>> _v;
            auto&& _m = prelude::get(env->names, k);
            if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m))) {
                auto&& rs = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                auto&& bt = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                _v.set(prelude::push(acc, std::tuple{k, place_stem(rs), bt}));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto names = each(state, [&](const std::tuple<Text, Text, OutTy>& _p0) {
        auto&& rs = std::get<1>(_p0);
        return rs;
    });
    auto st_ty = OutTy(OutTy::OutTuple{each(state, [&](const std::tuple<Text, Text, OutTy>& _p0) {
        auto&& bt = std::get<2>(_p0);
        return bt;
    })});
    auto pat = Pa(Pa::PaTuple{each(names, [&](const Text& n) { return Pa(Pa::PaMut{prism_rtl::cat(n)}); })});
    auto pack = Ex(Ex::XTuple{each(names, [&](const Text& n) { return Ex(Ex::XVar{n}); })});
    auto env_s = fold(state, env, [&](const Env& en, const std::tuple<Text, Text, OutTy>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        auto&& bt = std::get<2>(_p1);
        return bind(en, k, Bn(Bn::BnLocal{Ex(Ex::XVar{rs}), Holding(Holding::Owned{}), bt}));
    });
    auto out_caps = caps_in(outer, rest_text_, names);
    auto out_dos = each(out_caps, [&](const std::tuple<Text, Ex, Holding, OutTy>& _p0) {
        auto&& rs = std::get<1>(_p0);
        auto&& mode = std::get<2>(_p0);
        auto&& bt = std::get<3>(_p0);
        return Do(Do::DoLet{Pa(Pa::PaBind{place_stem(rs)}), own(Vl(Vl::VlPlace{rs, mode, bt}))});
    });
    auto outer2 = fold(out_caps, outer, [&](const Env& en, const std::tuple<Text, Ex, Holding, OutTy>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        auto&& bt = std::get<3>(_p1);
        return bind(en, k, Bn(Bn::BnLocal{Ex(Ex::XVar{place_stem(rs)}), Holding(Holding::Owned{}), bt}));
    });
    auto env2 = fold(out_caps, env_s, [&](const Env& en, const std::tuple<Text, Ex, Holding, OutTy>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        auto&& bt = std::get<3>(_p1);
        return bind(en, k, Bn(Bn::BnLocal{Ex(Ex::XVar{place_stem(rs)}), Holding(Holding::Owned{}), bt}));
    });
    auto k_name = prism_rtl::cat("k_if", span.start);
    auto k_do = Do(Do::DoLet{Pa(Pa::PaBind{k_name}), Ex(Ex::XClosure{true, Array(std::vector{Pa(Pa::PaTyped{prism_rtl::rc(pat), st_ty})}), prism_rtl::rc(run_to_end(cont_fn(std::tuple{outer2, env2})))})});
    auto to_k_fn = ({
        auto k_name_1 = k_name;
        auto pack_2 = pack;
        (prism_rtl::rc([=](const Env& o2, const Ex& e2) { return Ex(Ex::XCall{k_name_1, Array(std::vector{pack_2})}); }));
    });
    auto branch_fn = ({
        auto lx_1 = lx;
        auto env_2 = env;
        auto to_k_fn_3 = to_k_fn;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(ast::Block)>>(prism_rtl::rc([=](ast::Block p0) {
        return ({
            auto lx_1_4 = lx_1;
            auto env_2_4 = env_2;
            auto to_k_fn_3_4 = to_k_fn_3;
            entered(once_job([=]() {
            return ({
                auto b = p0;
                (prism_rtl::more(prism_rtl::rc(UpdTailFrom(lx_1_4, env_2_4, env_2_4, b, Nat(0u), b.span, ({
                auto f = to_k_fn_3_4;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Env, Ex>)>>(prism_rtl::rc([=](std::tuple<Env, Ex> _p0) {
                auto&& a0 = std::get<0>(_p0);
                auto&& a1 = std::get<1>(_p0);
                return ({
                    auto f_4 = f;
                    once_job([=]() { return prism_rtl::finished(f_4(a0, a1)); });
                });
            })));
            })))));
            });
        }));
        });
    })));
    });
    auto else_x = ({
        __label__ _done;
        prism_rtl::Slot<Ex> _v;
        if (prism_rtl::is_some(else_b_opt)) {
            auto&& eb = prism_rtl::some_of(else_b_opt);
            _v.set(run_to_end(branch_fn(eb)));
            goto _done;
        }
        if (prism_rtl::is_none(else_b_opt)) {
            _v.set(Ex(Ex::XCall{k_name, Array(std::vector{pack})}));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto choose = ({
        __label__ _done;
        prism_rtl::Slot<Ex> _v;
        if (prism_rtl::is<ast::Cond::CondExpr>(c)) {
            auto&& x = prism_rtl::as<ast::Cond::CondExpr>(c).a0;
            _v.set(Ex(Ex::XIf{prism_rtl::rc(as_bool(value_of(lx, env, x))), prism_rtl::rc(run_to_end(branch_fn(then_b))), prism_rtl::rc(else_x)}));
            goto _done;
        }
        if (prism_rtl::is<ast::Cond::CondBind>(c)) {
            auto&& p_ = prism_rtl::as<ast::Cond::CondBind>(c).a0;
            auto&& x = prism_rtl::as<ast::Cond::CondBind>(c).a1;
            _v.set(({
                auto po = rust_pat(lx, p_, type_at(lx, x.span), Holding(Holding::Owned{}), prism_rtl::cat("u", x.span.start));
                auto then_x = upd_tail_from(lx, bind_all(env, po.binds), bind_all(env, po.binds), then_b, Nat(0u), then_b.span, ({
                    auto f = to_k_fn;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Env, Ex>)>>(prism_rtl::rc([=](std::tuple<Env, Ex> _p0) {
                    auto&& a0 = std::get<0>(_p0);
                    auto&& a1 = std::get<1>(_p0);
                    return ({
                        auto f_1 = f;
                        once_job([=]() { return prism_rtl::finished(f_1(a0, a1)); });
                    });
                })));
                }));
                own(arms_value(own(value_of(lx, env, x)), Array(std::vector{XArm{.pat = po.pa, .conds = po.conds, .body = then_x}, XArm{.pat = Pa(Pa::PaWild{}), .conds = Array<Cc>{}, .body = else_x}}), prism_rtl::cat("'u", x.span.start), OutTy(OutTy::OutUnknown{Text("the job's turn")})));
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return prepend(prelude::push(out_dos, k_do), choose);
}


prism_rtl::Turn<Ex> IfJob::cycle() const {
    const auto& lx = this->lx;
    const auto& outer = this->outer;
    const auto& env = this->env;
    const auto& c = this->c;
    const auto& then_b = this->then_b;
    const auto& else_b_opt = this->else_b_opt;
    const auto& span = this->span;
    const auto& rest_text_ = this->rest_text_;
    const auto& cont_fn = this->cont_fn;
    auto state = fold(keys(env->names), Array<std::tuple<Text, Text, OutTy>>{}, [&](const Array<std::tuple<Text, Text, OutTy>>& acc, const Text& k) {
        return take_text(k, Nat(1u)) != Text("&")
            ? acc
            : ({
            __label__ _done;
            prism_rtl::Slot<Array<std::tuple<Text, Text, OutTy>>> _v;
            auto&& _m = prelude::get(env->names, k);
            if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m))) {
                auto&& rs = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                auto&& bt = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                _v.set(prelude::push(acc, std::tuple{k, place_stem(rs), bt}));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto names = each(state, [&](const std::tuple<Text, Text, OutTy>& _p0) {
        auto&& rs = std::get<1>(_p0);
        return rs;
    });
    auto st_ty = OutTy(OutTy::OutTuple{each(state, [&](const std::tuple<Text, Text, OutTy>& _p0) {
        auto&& bt = std::get<2>(_p0);
        return bt;
    })});
    auto pat = Pa(Pa::PaTuple{each(names, [&](const Text& n) { return Pa(Pa::PaMut{prism_rtl::cat(n)}); })});
    auto pack = Ex(Ex::XTuple{each(names, [&](const Text& n) { return Ex(Ex::XVar{n}); })});
    auto env_s = fold(state, env, [&](const Env& en, const std::tuple<Text, Text, OutTy>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        auto&& bt = std::get<2>(_p1);
        return bind(en, k, Bn(Bn::BnLocal{Ex(Ex::XVar{rs}), Holding(Holding::Owned{}), bt}));
    });
    auto out_caps = caps_in(outer, rest_text_, names);
    auto out_dos = each(out_caps, [&](const std::tuple<Text, Ex, Holding, OutTy>& _p0) {
        auto&& rs = std::get<1>(_p0);
        auto&& mode = std::get<2>(_p0);
        auto&& bt = std::get<3>(_p0);
        return Do(Do::DoLet{Pa(Pa::PaBind{place_stem(rs)}), own(Vl(Vl::VlPlace{rs, mode, bt}))});
    });
    auto outer2 = fold(out_caps, outer, [&](const Env& en, const std::tuple<Text, Ex, Holding, OutTy>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        auto&& bt = std::get<3>(_p1);
        return bind(en, k, Bn(Bn::BnLocal{Ex(Ex::XVar{place_stem(rs)}), Holding(Holding::Owned{}), bt}));
    });
    auto env2 = fold(out_caps, env_s, [&](const Env& en, const std::tuple<Text, Ex, Holding, OutTy>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        auto&& bt = std::get<3>(_p1);
        return bind(en, k, Bn(Bn::BnLocal{Ex(Ex::XVar{place_stem(rs)}), Holding(Holding::Owned{}), bt}));
    });
    auto k_name = prism_rtl::cat("k_if", span.start);
    auto else_b_opt_1 = else_b_opt;
    auto cont_fn_2 = cont_fn;
    auto c_3 = c;
    auto env_4 = env;
    auto lx_5 = lx;
    auto span_6 = span;
    auto then_b_7 = then_b;
    return call_value(cont_fn_2(std::tuple{outer2, env2}), [=](Ex cont_159413) {
        return ({
            auto k_do = Do(Do::DoLet{Pa(Pa::PaBind{k_name}), Ex(Ex::XClosure{true, Array(std::vector{Pa(Pa::PaTyped{prism_rtl::rc(pat), st_ty})}), prism_rtl::rc(cont_159413)})});
            auto to_k_fn = ({
                auto k_name_8 = k_name;
                auto pack_9 = pack;
                (prism_rtl::rc([=](const Env& o2, const Ex& e2) { return Ex(Ex::XCall{k_name_8, Array(std::vector{pack_9})}); }));
            });
            auto branch_fn = ({
                auto lx_5_8 = lx_5;
                auto env_4_8 = env_4;
                auto to_k_fn_8 = to_k_fn;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(ast::Block)>>(prism_rtl::rc([=](ast::Block p0) {
                return ({
                    auto lx_5_8_9 = lx_5_8;
                    auto env_4_8_9 = env_4_8;
                    auto to_k_fn_8_9 = to_k_fn_8;
                    entered(once_job([=]() {
                    return ({
                        auto b = p0;
                        (prism_rtl::more(prism_rtl::rc(UpdTailFrom(lx_5_8_9, env_4_8_9, env_4_8_9, b, Nat(0u), b.span, ({
                        auto f = to_k_fn_8_9;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Env, Ex>)>>(prism_rtl::rc([=](std::tuple<Env, Ex> _p0) {
                        auto&& a0 = std::get<0>(_p0);
                        auto&& a1 = std::get<1>(_p0);
                        return ({
                            auto f_9 = f;
                            once_job([=]() { return prism_rtl::finished(f_9(a0, a1)); });
                        });
                    })));
                    })))));
                    });
                }));
                });
            })));
            });
            auto else_x = ({
                __label__ _done;
                prism_rtl::Slot<Ex> _v;
                if (prism_rtl::is_some(else_b_opt)) {
                    auto&& eb = prism_rtl::some_of(else_b_opt);
                    _v.set(run_to_end(branch_fn(eb)));
                    goto _done;
                }
                if (prism_rtl::is_none(else_b_opt)) {
                    _v.set(Ex(Ex::XCall{k_name, Array(std::vector{pack})}));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            auto choose = ({
                __label__ _done;
                prism_rtl::Slot<Ex> _v;
                if (prism_rtl::is<ast::Cond::CondExpr>(c)) {
                    auto&& x = prism_rtl::as<ast::Cond::CondExpr>(c).a0;
                    _v.set(Ex(Ex::XIf{prism_rtl::rc(as_bool(value_of(lx_5, env_4, x))), prism_rtl::rc(run_to_end(branch_fn(then_b_7))), prism_rtl::rc(else_x)}));
                    goto _done;
                }
                if (prism_rtl::is<ast::Cond::CondBind>(c)) {
                    auto&& p_ = prism_rtl::as<ast::Cond::CondBind>(c).a0;
                    auto&& x = prism_rtl::as<ast::Cond::CondBind>(c).a1;
                    _v.set(({
                        auto po = rust_pat(lx_5, p_, type_at(lx_5, x.span), Holding(Holding::Owned{}), prism_rtl::cat("u", x.span.start));
                        auto then_x = upd_tail_from(lx_5, bind_all(env_4, po.binds), bind_all(env_4, po.binds), then_b_7, Nat(0u), then_b_7.span, ({
                            auto f = to_k_fn;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Env, Ex>)>>(prism_rtl::rc([=](std::tuple<Env, Ex> _p0) {
                            auto&& a0 = std::get<0>(_p0);
                            auto&& a1 = std::get<1>(_p0);
                            return ({
                                auto f_8 = f;
                                once_job([=]() { return prism_rtl::finished(f_8(a0, a1)); });
                            });
                        })));
                        }));
                        own(arms_value(own(value_of(lx_5, env_4, x)), Array(std::vector{XArm{.pat = po.pa, .conds = po.conds, .body = then_x}, XArm{.pat = Pa(Pa::PaWild{}), .conds = Array<Cc>{}, .body = else_x}}), prism_rtl::cat("'u", x.span.start), OutTy(OutTy::OutUnknown{Text("the job's turn")})));
                    }));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            (prism_rtl::finished(prepend(prelude::push(out_dos, k_do), choose)));
        });
    });
}


/// `Start IfJob, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Ex> start_if_job(Lx lx, Env outer, Env env, ast::Cond c, ast::Block then_b, std::optional<ast::Block> else_b_opt, ast::Range span, Text rest_text_, prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Env, Env>)> cont_fn) {
    return std::make_shared<IfJob>(lx, outer, env, c, then_b, else_b_opt, span, rest_text_, cont_fn);
}


/// InstanceOf: fn Text -> Text
Text instance_of(const Text& k) {
    return or_(index(split(k, Text("#inst")), Nat(0u)), k);
}


/// CapsIn: fn Env, Text, [Text] -> [((Text, Ex, Holding, OutTy))]
Array<std::tuple<Text, Ex, Holding, OutTy>> caps_in(const Env& env, const Text& text, const Array<Text>& skip) {
    return fold(keys(env->names), Array<std::tuple<Text, Ex, Holding, OutTy>>{}, [&](const Array<std::tuple<Text, Ex, Holding, OutTy>>& acc, const Text& k) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<std::tuple<Text, Ex, Holding, OutTy>>> _v;
            auto&& _m = prelude::get(env->names, k);
            if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m))) {
                auto&& rs = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                auto&& mode = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a1;
                auto&& bt = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                _v.set((check_types::has_text(skip, place_stem(rs)) || on_self(rs)) || (!mentions(text, drop_text(instance_of(k), len_text(check_types::marks_of(k)))))
                    ? acc
                    : prelude::push(acc, std::tuple{k, rs, mode, bt}));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


/// ?FrameCall: unbounded fn Lx, Env, Expr, Bool -> ?Expr
std::optional<ast::Expr> frame_call(const Lx& lx, const Env& env, const ast::Expr& e, const bool& top) {
    return check_env::has_key(env.spans, place_key(lx, e.span))
        ? std::optional<ast::Expr>{}
        : ({
        __label__ _done;
        prism_rtl::Slot<std::optional<ast::Expr>> _v;
        auto&& _m = e.kind;
        if (prism_rtl::is<ast::ExprKind::EGroup>(_m)) {
            auto&& x = prism_rtl::as<ast::ExprKind::EGroup>(_m).a0;
            _v.set(frame_call(lx, env, x, top));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::ECall>(_m)) {
            auto&& c = prism_rtl::as<ast::ExprKind::ECall>(_m).a0;
            auto&& args = prism_rtl::as<ast::ExprKind::ECall>(_m).a1;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::optional<ast::Expr>> _v;
                auto&& _m = first_frame(lx, env, each(args, [&](const ast::Arg& a) { return a->value; }));
                if (prism_rtl::is_some(_m)) {
                    auto&& x = prism_rtl::some_of(_m);
                    _v.set(std::optional(x));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(top
                        ? std::optional<ast::Expr>{}
                        : ({
                        __label__ _done;
                        prism_rtl::Slot<std::optional<ast::Expr>> _v;
                        auto&& _m = tail_callee(lx, env, c);
                        if (prism_rtl::is_some(_m)) {
                            _v.set(std::optional(e));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(({
                                __label__ _done;
                                prism_rtl::Slot<std::optional<ast::Expr>> _v;
                                auto&& _m = local_job_fn(lx, env, c);
                                if (prism_rtl::is_some(_m)) {
                                    _v.set(std::optional(e));
                                    goto _done;
                                }
                                if (prism_rtl::is_none(_m)) {
                                    _v.set(({
                                        __label__ _done;
                                        prism_rtl::Slot<std::optional<ast::Expr>> _v;
                                        auto&& _m = prelude_job_call(lx, env, e);
                                        if (prism_rtl::is_some(_m)) {
                                            _v.set(std::optional(e));
                                            goto _done;
                                        }
                                        if (prism_rtl::is_none(_m)) {
                                            _v.set(std::optional<ast::Expr>{});
                                            goto _done;
                                        }
                                        prism_rtl::unreachable("no arm matched");
                                    _done:
                                        _v.take();
                                    }));
                                    goto _done;
                                }
                                prism_rtl::unreachable("no arm matched");
                            _done:
                                _v.take();
                            }));
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EMatch>(_m)) {
            auto&& x = prism_rtl::as<ast::ExprKind::EMatch>(_m).a0;
            _v.set(frame_call(lx, env, x, false));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EIf>(_m)) {
            auto&& m161318_3_0 = prism_rtl::as<ast::ExprKind::EIf>(_m).a0;
            if (prism_rtl::is<ast::Cond::CondExpr>(m161318_3_0)) {
                auto&& x = prism_rtl::as<ast::Cond::CondExpr>(m161318_3_0).a0;
                _v.set(frame_call(lx, env, x, false));
                goto _done;
            }
        }
        if (prism_rtl::is<ast::ExprKind::EBinary>(_m)) {
            auto&& op = prism_rtl::as<ast::ExprKind::EBinary>(_m).a0;
            auto&& l = prism_rtl::as<ast::ExprKind::EBinary>(_m).a1;
            auto&& r = prism_rtl::as<ast::ExprKind::EBinary>(_m).a2;
            _v.set((op == Text("and")) || (op == Text("or"))
                ? frame_call(lx, env, l, false)
                : first_frame(lx, env, Array(std::vector{l, r})));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::ETuple>(_m)) {
            auto&& es = prism_rtl::as<ast::ExprKind::ETuple>(_m).a0;
            _v.set(first_frame(lx, env, es));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EArray>(_m)) {
            auto&& es = prism_rtl::as<ast::ExprKind::EArray>(_m).a0;
            _v.set(first_frame(lx, env, es));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EUnary>(_m)) {
            auto&& x = prism_rtl::as<ast::ExprKind::EUnary>(_m).a1;
            _v.set(frame_call(lx, env, x, false));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EField>(_m)) {
            auto&& x = prism_rtl::as<ast::ExprKind::EField>(_m).a0;
            _v.set(frame_call(lx, env, x, false));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EIndex>(_m)) {
            auto&& x = prism_rtl::as<ast::ExprKind::EIndex>(_m).a0;
            auto&& i = prism_rtl::as<ast::ExprKind::EIndex>(_m).a1;
            _v.set(first_frame(lx, env, Array(std::vector{x, i})));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EMethod>(_m)) {
            auto&& x = prism_rtl::as<ast::ExprKind::EMethod>(_m).a0;
            auto&& args = prism_rtl::as<ast::ExprKind::EMethod>(_m).a2;
            _v.set(first_frame(lx, env, append(Array(std::vector{x}), each(args, [&](const ast::Arg& a) { return a->value; }))));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::ECast>(_m)) {
            auto&& x = prism_rtl::as<ast::ExprKind::ECast>(_m).a0;
            _v.set(frame_call(lx, env, x, false));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::ELit>(_m)) {
            auto&& l = prism_rtl::as<ast::ExprKind::ELit>(_m).a0;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::optional<ast::Expr>> _v;
                auto&& _m = l.kind;
                if (prism_rtl::is<ast::LitKind::LText>(_m)) {
                    auto&& segs = prism_rtl::as<ast::LitKind::LText>(_m).a0;
                    _v.set(first_frame(lx, env, placeholders(segs)));
                    goto _done;
                }
                {
                    _v.set(std::optional<ast::Expr>{});
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        {
            _v.set(std::optional<ast::Expr>{});
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::optional<ast::Expr>> FrameCall::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& e = this->e;
    const auto& top = this->top;
    return check_env::has_key(env.spans, place_key(lx, e.span))
        ? prism_rtl::finished(std::optional<ast::Expr>{})
        : ({
        auto&& _m = e.kind;
        prism_rtl::is<ast::ExprKind::EGroup>(_m) ? ({
        auto&& x = prism_rtl::as<ast::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(FrameCall(lx, env, x, top)));
    })
        : prism_rtl::is<ast::ExprKind::ECall>(_m) ? ({
        auto&& c = prism_rtl::as<ast::ExprKind::ECall>(_m).a0;
        auto&& args = prism_rtl::as<ast::ExprKind::ECall>(_m).a1;
        ({
        auto args_1 = args;
        auto c_2 = c;
        auto e_3 = e;
        auto env_4 = env;
        auto lx_5 = lx;
        auto top_6 = top;
        call_then(start_first_frame(lx_5, env_4, each(args_1, [&](const ast::Arg& a) { return a->value; })), [=](std::optional<ast::Expr> first_frame_161422) {
        return ({
            prism_rtl::is_some(first_frame_161422) ? ({
            auto&& x = prism_rtl::some_of(first_frame_161422);
            prism_rtl::finished(std::optional(x));
        })
            : prism_rtl::is_none(first_frame_161422) ? top_6
            ? prism_rtl::finished(std::optional<ast::Expr>{})
            : ({
            auto&& _m = tail_callee(lx_5, env_4, c_2);
            prism_rtl::is_some(_m) ? prism_rtl::finished(std::optional(e_3))
            : prism_rtl::is_none(_m) ? call_then(start_local_job_fn(lx_5, env_4, c_2), [=](std::optional<Vl> local_job_fn_161653) {
            return ({
                prism_rtl::is_some(local_job_fn_161653) ? prism_rtl::finished(std::optional(e_3))
                : prism_rtl::is_none(local_job_fn_161653) ? call_then(start_prelude_job_call(lx_5, env_4, e_3), [=](std::optional<Ex> prelude_job_call_161750) {
                return ({
                    prism_rtl::is_some(prelude_job_call_161750) ? prism_rtl::finished(std::optional(e_3))
                    : prism_rtl::is_none(prelude_job_call_161750) ? prism_rtl::finished(std::optional<ast::Expr>{})
                    : throw prism_rtl::Panic("no arm matched");
                });
            })
                : throw prism_rtl::Panic("no arm matched");
            });
        })
            : throw prism_rtl::Panic("no arm matched");
        })
            : throw prism_rtl::Panic("no arm matched");
        });
    });
    });
    })
        : prism_rtl::is<ast::ExprKind::EMatch>(_m) ? ({
        auto&& x = prism_rtl::as<ast::ExprKind::EMatch>(_m).a0;
        prism_rtl::more(prism_rtl::rc(FrameCall(lx, env, x, false)));
    })
        : prism_rtl::is<ast::ExprKind::EIf>(_m) && ({
        auto&& m161318_3_0 = prism_rtl::as<ast::ExprKind::EIf>(_m).a0;
        prism_rtl::is<ast::Cond::CondExpr>(m161318_3_0);
    }) ? ({
        auto&& m161318_3_0 = prism_rtl::as<ast::ExprKind::EIf>(_m).a0;
        auto&& x = prism_rtl::as<ast::Cond::CondExpr>(m161318_3_0).a0;
        prism_rtl::more(prism_rtl::rc(FrameCall(lx, env, x, false)));
    })
        : prism_rtl::is<ast::ExprKind::EBinary>(_m) ? ({
        auto&& op = prism_rtl::as<ast::ExprKind::EBinary>(_m).a0;
        auto&& l = prism_rtl::as<ast::ExprKind::EBinary>(_m).a1;
        auto&& r = prism_rtl::as<ast::ExprKind::EBinary>(_m).a2;
        (op == Text("and")) || (op == Text("or"))
        ? prism_rtl::more(prism_rtl::rc(FrameCall(lx, env, l, false)))
        : prism_rtl::more(prism_rtl::rc(FirstFrame(lx, env, Array(std::vector{l, r}))));
    })
        : prism_rtl::is<ast::ExprKind::ETuple>(_m) ? ({
        auto&& es = prism_rtl::as<ast::ExprKind::ETuple>(_m).a0;
        prism_rtl::more(prism_rtl::rc(FirstFrame(lx, env, es)));
    })
        : prism_rtl::is<ast::ExprKind::EArray>(_m) ? ({
        auto&& es = prism_rtl::as<ast::ExprKind::EArray>(_m).a0;
        prism_rtl::more(prism_rtl::rc(FirstFrame(lx, env, es)));
    })
        : prism_rtl::is<ast::ExprKind::EUnary>(_m) ? ({
        auto&& x = prism_rtl::as<ast::ExprKind::EUnary>(_m).a1;
        prism_rtl::more(prism_rtl::rc(FrameCall(lx, env, x, false)));
    })
        : prism_rtl::is<ast::ExprKind::EField>(_m) ? ({
        auto&& x = prism_rtl::as<ast::ExprKind::EField>(_m).a0;
        prism_rtl::more(prism_rtl::rc(FrameCall(lx, env, x, false)));
    })
        : prism_rtl::is<ast::ExprKind::EIndex>(_m) ? ({
        auto&& x = prism_rtl::as<ast::ExprKind::EIndex>(_m).a0;
        auto&& i = prism_rtl::as<ast::ExprKind::EIndex>(_m).a1;
        prism_rtl::more(prism_rtl::rc(FirstFrame(lx, env, Array(std::vector{x, i}))));
    })
        : prism_rtl::is<ast::ExprKind::EMethod>(_m) ? ({
        auto&& x = prism_rtl::as<ast::ExprKind::EMethod>(_m).a0;
        auto&& args = prism_rtl::as<ast::ExprKind::EMethod>(_m).a2;
        prism_rtl::more(prism_rtl::rc(FirstFrame(lx, env, append(Array(std::vector{x}), each(args, [&](const ast::Arg& a) { return a->value; })))));
    })
        : prism_rtl::is<ast::ExprKind::ECast>(_m) ? ({
        auto&& x = prism_rtl::as<ast::ExprKind::ECast>(_m).a0;
        prism_rtl::more(prism_rtl::rc(FrameCall(lx, env, x, false)));
    })
        : prism_rtl::is<ast::ExprKind::ELit>(_m) ? ({
        auto&& l = prism_rtl::as<ast::ExprKind::ELit>(_m).a0;
        ({
        auto&& _m = l.kind;
        prism_rtl::is<ast::LitKind::LText>(_m) ? ({
        auto&& segs = prism_rtl::as<ast::LitKind::LText>(_m).a0;
        prism_rtl::more(prism_rtl::rc(FirstFrame(lx, env, placeholders(segs))));
    })
        : prism_rtl::finished(std::optional<ast::Expr>{});
    });
    })
        : prism_rtl::finished(std::optional<ast::Expr>{});
    });
}


/// `Start FrameCall, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<ast::Expr>> start_frame_call(Lx lx, Env env, ast::Expr e, bool top) {
    return std::make_shared<FrameCall>(lx, env, e, top);
}


/// Placeholders: fn [TextSeg] -> [Expr]
Array<ast::Expr> placeholders(const Array<ast::TextSeg>& segs) {
    return fold(segs, Array<ast::Expr>{}, [&](const Array<ast::Expr>& acc, const ast::TextSeg& sg) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<ast::Expr>> _v;
            if (prism_rtl::is<ast::TextSeg::SegPlaceholder>(sg)) {
                auto&& x = prism_rtl::as<ast::TextSeg::SegPlaceholder>(sg).a0;
                _v.set(prelude::push(acc, x));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


/// ?FirstFrame: unbounded fn Lx, Env, [Expr] -> ?Expr
std::optional<ast::Expr> first_frame(const Lx& lx, const Env& env, const Array<ast::Expr>& es) {
    return run_to_end(fold_job(es, std::optional<ast::Expr>{}, ({
        auto lx_1 = lx;
        auto env_2 = env;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::optional<ast::Expr>>(std::tuple<std::optional<ast::Expr>, ast::Expr>)>>(prism_rtl::rc([=](std::tuple<std::optional<ast::Expr>, ast::Expr> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_1_3 = lx_1;
            auto env_2_3 = env_2;
            entered(once_job([=]() {
            return ({
                auto found_opt = p0;
                auto x = p1;
                ({
                prism_rtl::is_some(found_opt) ? ({
                auto&& f = prism_rtl::some_of(found_opt);
                prism_rtl::finished(std::optional(f));
            })
                : prism_rtl::is_none(found_opt) ? prism_rtl::more(prism_rtl::rc(FrameCall(lx_1_3, env_2_3, x, false)))
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<std::optional<ast::Expr>> FirstFrame::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& es = this->es;
    return fold_job(es, std::optional<ast::Expr>{}, ({
        auto lx_1 = lx;
        auto env_2 = env;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::optional<ast::Expr>>(std::tuple<std::optional<ast::Expr>, ast::Expr>)>>(prism_rtl::rc([=](std::tuple<std::optional<ast::Expr>, ast::Expr> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_1_3 = lx_1;
            auto env_2_3 = env_2;
            entered(once_job([=]() {
            return ({
                auto found_opt = p0;
                auto x = p1;
                ({
                prism_rtl::is_some(found_opt) ? ({
                auto&& f = prism_rtl::some_of(found_opt);
                prism_rtl::finished(std::optional(f));
            })
                : prism_rtl::is_none(found_opt) ? prism_rtl::more(prism_rtl::rc(FrameCall(lx_1_3, env_2_3, x, false)))
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start FirstFrame, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<ast::Expr>> start_first_frame(Lx lx, Env env, Array<ast::Expr> es) {
    return std::make_shared<FirstFrame>(lx, env, es);
}


/// Frame: unbounded fn Lx, Env, Expr, Text, (unbounded fn Env -> Ex) -> Ex
Ex frame(const Lx& lx, const Env& env, const ast::Expr& call, const Text& rest_text_, const prism_rtl::Fn<prism_rtl::JobRef<Ex>(Env)>& cont_fn) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Ex> _v;
        auto&& _m = call.kind;
        if (prism_rtl::is<ast::ExprKind::ECall>(_m)) {
            auto&& c = prism_rtl::as<ast::ExprKind::ECall>(_m).a0;
            auto&& args = prism_rtl::as<ast::ExprKind::ECall>(_m).a1;
            _v.set(({
                auto qk_opt = tail_callee(lx, env, c);
                auto qk = or_(qk_opt, Text(""));
                auto base_ = ({
                    __label__ _done;
                    prism_rtl::Slot<Text> _v;
                    if (prism_rtl::is_some(qk_opt)) {
                        auto&& q = prism_rtl::some_of(qk_opt);
                        _v.set(or_(prelude::get(lx.rs_names, q), snake(check_types::bare_name(q))));
                        goto _done;
                    }
                    if (prism_rtl::is_none(qk_opt)) {
                        _v.set(snake(callee_text(c)));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                auto v_ = prism_rtl::cat(base_, "_", call.span.start);
                auto t = out_ty_of(lx, peel(type_at(lx, call.span)));
                auto caps = fold(keys(env->names), Array<std::tuple<Text, Ex, Holding, OutTy>>{}, [&](const Array<std::tuple<Text, Ex, Holding, OutTy>>& acc, const Text& k) {
                    return ({
                        __label__ _done;
                        prism_rtl::Slot<Array<std::tuple<Text, Ex, Holding, OutTy>>> _v;
                        auto&& _m = prelude::get(env->names, k);
                        if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m))) {
                            auto&& rs = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                            auto&& mode = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a1;
                            auto&& bt = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                            _v.set(((mode == Holding(Holding::ByRef{})) || (mode == Holding(Holding::RcRef{}))) && mentions(rest_text_, instance_of(k))
                                ? prelude::push(acc, std::tuple{k, rs, mode, bt})
                                : acc);
                            goto _done;
                        }
                        {
                            _v.set(acc);
                            goto _done;
                        }
                    _done:
                        _v.take();
                    });
                });
                auto dos = each(caps, [&](const std::tuple<Text, Ex, Holding, OutTy>& _p0) {
                    auto&& rs = std::get<1>(_p0);
                    auto&& mode = std::get<2>(_p0);
                    auto&& bt = std::get<3>(_p0);
                    return Do(Do::DoLet{Pa(Pa::PaBind{place_stem(rs)}), own(Vl(Vl::VlPlace{rs, mode, bt}))});
                });
                auto env2 = fold(caps, env, [&](const Env& en, const std::tuple<Text, Ex, Holding, OutTy>& _p1) {
                    auto&& k = std::get<0>(_p1);
                    auto&& rs = std::get<1>(_p1);
                    auto&& bt = std::get<3>(_p1);
                    return bind(en, k, Bn(Bn::BnLocal{Ex(Ex::XVar{place_stem(rs)}), Holding(Holding::Owned{}), bt}));
                });
                auto vals = ({
                    __label__ _done;
                    prism_rtl::Slot<Array<Ex>> _v;
                    if (prism_rtl::is_some(qk_opt)) {
                        auto&& q = prism_rtl::some_of(qk_opt);
                        _v.set(named_args_owned(lx, env2, q, args));
                        goto _done;
                    }
                    if (prism_rtl::is_none(qk_opt)) {
                        _v.set(({
                            __label__ _done;
                            prism_rtl::Slot<Array<Ex>> _v;
                            auto&& _m = local_job_fn(lx, env2, c);
                            if (prism_rtl::is_some(_m)) {
                                auto&& f = prism_rtl::some_of(_m);
                                _v.set(start_args(lx, env2, f, args));
                                goto _done;
                            }
                            if (prism_rtl::is_none(_m)) {
                                _v.set(run_to_end(each_job(args, ({
                                    auto lx_1 = lx;
                                    auto env2_2 = env2;
                                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(ast::Arg)>>(prism_rtl::rc([=](ast::Arg p0) {
                                    return ({
                                        auto lx_1_3 = lx_1;
                                        auto env2_2_3 = env2_2;
                                        entered(once_job([=]() {
                                        return ({
                                            auto a = p0;
                                            call_then(start_value_of(lx_1_3, env2_2_3, a->value), [=](Vl value_of_164473) { return prism_rtl::finished(own(value_of_164473)); });
                                        });
                                    }));
                                    });
                                })));
                                }))));
                                goto _done;
                            }
                            prism_rtl::unreachable("no arm matched");
                        _done:
                            _v.take();
                        }));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                auto env3 = bind_span(env2, place_key(lx, call.span), Vl(Vl::VlOwned{Ex(Ex::XVar{v_}), t}));
                auto body = run_to_end(cont_fn(env3));
                auto [job, how] = ({
                    __label__ _done;
                    prism_rtl::Slot<std::tuple<Ex, Text>> _v;
                    if (prism_rtl::is_some(qk_opt)) {
                        auto&& q = prism_rtl::some_of(qk_opt);
                        _v.set(std::tuple{Ex(Ex::XCall{path_in(lx, owner_of(q), prism_rtl::cat("start_", base_)), vals}), enters_at_once(lx, q, args) ? Text("call_value") : Text("call_then")});
                        goto _done;
                    }
                    if (prism_rtl::is_none(qk_opt)) {
                        _v.set(({
                            __label__ _done;
                            prism_rtl::Slot<std::tuple<Ex, Text>> _v;
                            auto&& _m = local_job_fn(lx, env2, c);
                            if (prism_rtl::is_some(_m)) {
                                auto&& f = prism_rtl::some_of(_m);
                                _v.set(std::tuple{start_call(f, vals), Text("call_value")});
                                goto _done;
                            }
                            if (prism_rtl::is_none(_m)) {
                                _v.set(({
                                    __label__ _done;
                                    prism_rtl::Slot<std::tuple<Ex, Text>> _v;
                                    auto&& _m = prelude_job_call(lx, env2, call);
                                    if (prism_rtl::is_some(_m)) {
                                        auto&& pj = prism_rtl::some_of(_m);
                                        _v.set(std::tuple{pj, Text("call_value")});
                                        goto _done;
                                    }
                                    if (prism_rtl::is_none(_m)) {
                                        _v.set(std::tuple{refusal(Text("a call this frame cannot enter")), Text("call_then")});
                                        goto _done;
                                    }
                                    prism_rtl::unreachable("no arm matched");
                                _done:
                                    _v.take();
                                }));
                                goto _done;
                            }
                            prism_rtl::unreachable("no arm matched");
                        _done:
                            _v.take();
                        }));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                auto enter = Ex(Ex::XCall{how, Array(std::vector{job, Ex(Ex::XClosure{true, Array(std::vector{Pa(Pa::PaTyped{prism_rtl::rc(Pa(Pa::PaBind{v_})), t})}), prism_rtl::rc(body)})})});
                len(dos) == Nat(0u) ? enter : Ex(Ex::XBlock{dos, prism_rtl::rc(enter)});
            }));
            goto _done;
        }
        {
            _v.set(run_to_end(cont_fn(env)));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Ex> Frame::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& call = this->call;
    const auto& rest_text_ = this->rest_text_;
    const auto& cont_fn = this->cont_fn;
    return ({
        auto&& _m = call.kind;
        prism_rtl::is<ast::ExprKind::ECall>(_m) ? ({
        auto&& c = prism_rtl::as<ast::ExprKind::ECall>(_m).a0;
        auto&& args = prism_rtl::as<ast::ExprKind::ECall>(_m).a1;
        ({
        auto qk_opt = tail_callee(lx, env, c);
        auto qk = or_(qk_opt, Text(""));
        auto base_ = ({
            __label__ _done;
            prism_rtl::Slot<Text> _v;
            if (prism_rtl::is_some(qk_opt)) {
                auto&& q = prism_rtl::some_of(qk_opt);
                _v.set(or_(prelude::get(lx.rs_names, q), snake(check_types::bare_name(q))));
                goto _done;
            }
            if (prism_rtl::is_none(qk_opt)) {
                _v.set(snake(callee_text(c)));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto v_ = prism_rtl::cat(base_, "_", call.span.start);
        auto cont_fn_1 = cont_fn;
        auto args_2 = args;
        auto c_3 = c;
        auto call_4 = call;
        auto env_5 = env;
        auto lx_6 = lx;
        auto rest_text__7 = rest_text_;
        call_then(start_out_ty_of(lx_6, peel(type_at(lx_6, call_4.span))), [=](OutTy out_ty_of_163718) {
        return ({
            auto t = out_ty_of_163718;
            auto caps = fold(keys(env_5->names), Array<std::tuple<Text, Ex, Holding, OutTy>>{}, [&](const Array<std::tuple<Text, Ex, Holding, OutTy>>& acc, const Text& k) {
                return ({
                    __label__ _done;
                    prism_rtl::Slot<Array<std::tuple<Text, Ex, Holding, OutTy>>> _v;
                    auto&& _m = prelude::get(env_5->names, k);
                    if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m))) {
                        auto&& rs = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                        auto&& mode = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a1;
                        auto&& bt = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                        _v.set(((mode == Holding(Holding::ByRef{})) || (mode == Holding(Holding::RcRef{}))) && mentions(rest_text__7, instance_of(k))
                            ? prelude::push(acc, std::tuple{k, rs, mode, bt})
                            : acc);
                        goto _done;
                    }
                    {
                        _v.set(acc);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
            });
            auto dos = each(caps, [&](const std::tuple<Text, Ex, Holding, OutTy>& _p0) {
                auto&& rs = std::get<1>(_p0);
                auto&& mode = std::get<2>(_p0);
                auto&& bt = std::get<3>(_p0);
                return Do(Do::DoLet{Pa(Pa::PaBind{place_stem(rs)}), own(Vl(Vl::VlPlace{rs, mode, bt}))});
            });
            auto env2 = fold(caps, env_5, [&](const Env& en, const std::tuple<Text, Ex, Holding, OutTy>& _p1) {
                auto&& k = std::get<0>(_p1);
                auto&& rs = std::get<1>(_p1);
                auto&& bt = std::get<3>(_p1);
                return bind(en, k, Bn(Bn::BnLocal{Ex(Ex::XVar{place_stem(rs)}), Holding(Holding::Owned{}), bt}));
            });
            auto vals = ({
                __label__ _done;
                prism_rtl::Slot<Array<Ex>> _v;
                if (prism_rtl::is_some(qk_opt)) {
                    auto&& q = prism_rtl::some_of(qk_opt);
                    _v.set(named_args_owned(lx_6, env2, q, args_2));
                    goto _done;
                }
                if (prism_rtl::is_none(qk_opt)) {
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<Array<Ex>> _v;
                        auto&& _m = local_job_fn(lx_6, env2, c_3);
                        if (prism_rtl::is_some(_m)) {
                            auto&& f = prism_rtl::some_of(_m);
                            _v.set(start_args(lx_6, env2, f, args_2));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(run_to_end(each_job(args_2, ({
                                auto lx_6_8 = lx_6;
                                auto env2_8 = env2;
                                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(ast::Arg)>>(prism_rtl::rc([=](ast::Arg p0) {
                                return ({
                                    auto lx_6_8_9 = lx_6_8;
                                    auto env2_8_9 = env2_8;
                                    entered(once_job([=]() {
                                    return ({
                                        auto a = p0;
                                        call_then(start_value_of(lx_6_8_9, env2_8_9, a->value), [=](Vl value_of_164473) { return prism_rtl::finished(own(value_of_164473)); });
                                    });
                                }));
                                });
                            })));
                            }))));
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            auto env3 = bind_span(env2, place_key(lx_6, call_4.span), Vl(Vl::VlOwned{Ex(Ex::XVar{v_}), t}));
            call_value(cont_fn_1(env3), [=](Ex cont_164601) {
            return ({
                auto body = cont_164601;
                auto [job, how] = ({
                    __label__ _done;
                    prism_rtl::Slot<std::tuple<Ex, Text>> _v;
                    if (prism_rtl::is_some(qk_opt)) {
                        auto&& q = prism_rtl::some_of(qk_opt);
                        _v.set(std::tuple{Ex(Ex::XCall{path_in(lx_6, owner_of(q), prism_rtl::cat("start_", base_)), vals}), enters_at_once(lx_6, q, args_2) ? Text("call_value") : Text("call_then")});
                        goto _done;
                    }
                    if (prism_rtl::is_none(qk_opt)) {
                        _v.set(({
                            __label__ _done;
                            prism_rtl::Slot<std::tuple<Ex, Text>> _v;
                            auto&& _m = local_job_fn(lx_6, env2, c_3);
                            if (prism_rtl::is_some(_m)) {
                                auto&& f = prism_rtl::some_of(_m);
                                _v.set(std::tuple{start_call(f, vals), Text("call_value")});
                                goto _done;
                            }
                            if (prism_rtl::is_none(_m)) {
                                _v.set(({
                                    __label__ _done;
                                    prism_rtl::Slot<std::tuple<Ex, Text>> _v;
                                    auto&& _m = prelude_job_call(lx_6, env2, call_4);
                                    if (prism_rtl::is_some(_m)) {
                                        auto&& pj = prism_rtl::some_of(_m);
                                        _v.set(std::tuple{pj, Text("call_value")});
                                        goto _done;
                                    }
                                    if (prism_rtl::is_none(_m)) {
                                        _v.set(std::tuple{refusal(Text("a call this frame cannot enter")), Text("call_then")});
                                        goto _done;
                                    }
                                    prism_rtl::unreachable("no arm matched");
                                _done:
                                    _v.take();
                                }));
                                goto _done;
                            }
                            prism_rtl::unreachable("no arm matched");
                        _done:
                            _v.take();
                        }));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                auto enter = Ex(Ex::XCall{how, Array(std::vector{job, Ex(Ex::XClosure{true, Array(std::vector{Pa(Pa::PaTyped{prism_rtl::rc(Pa(Pa::PaBind{v_})), t})}), prism_rtl::rc(body)})})});
                len(dos) == Nat(0u)
                ? prism_rtl::finished(enter)
                : prism_rtl::finished(Ex(Ex::XBlock{dos, prism_rtl::rc(enter)}));
            });
        });
        });
    });
    });
    })
        : cont_fn(env)->cycle();
    });
}


/// `Start Frame, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Ex> start_frame(Lx lx, Env env, ast::Expr call, Text rest_text_, prism_rtl::Fn<prism_rtl::JobRef<Ex>(Env)> cont_fn) {
    return std::make_shared<Frame>(lx, env, call, rest_text_, cont_fn);
}


/// ?LocalJobFn: unbounded fn Lx, Env, Expr -> ?Vl
std::optional<Vl> local_job_fn(const Lx& lx, const Env& env, const ast::Expr& c) {
    return ({
        __label__ _done;
        prism_rtl::Slot<std::optional<Vl>> _v;
        auto&& _m = c.kind;
        if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
            auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
            _v.set((len(n->path_) == Nat(1u)) && check_env::has_key(env->names, check_env::sname_key(n))
                ? job_value(name_value(lx, env, n, c.span))
                : std::optional<Vl>{});
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EGroup>(_m)) {
            auto&& x = prism_rtl::as<ast::ExprKind::EGroup>(_m).a0;
            _v.set(local_job_fn(lx, env, x));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EField>(_m)) {
            _v.set(job_value(value_of(lx, env, c)));
            goto _done;
        }
        {
            _v.set(std::optional<Vl>{});
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::optional<Vl>> LocalJobFn::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& c = this->c;
    return ({
        auto&& _m = c.kind;
        prism_rtl::is<ast::ExprKind::EName>(_m) ? ({
        auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
        (len(n->path_) == Nat(1u)) && check_env::has_key(env->names, check_env::sname_key(n))
        ? ({
        auto c_1 = c;
        auto env_2 = env;
        auto lx_3 = lx;
        auto n_4 = n;
        call_then(start_name_value(lx_3, env_2, n_4, c_1.span), [=](Vl name_value_165516) { return prism_rtl::finished(job_value(name_value_165516)); });
    })
        : prism_rtl::finished(std::optional<Vl>{});
    })
        : prism_rtl::is<ast::ExprKind::EGroup>(_m) ? ({
        auto&& x = prism_rtl::as<ast::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(LocalJobFn(lx, env, x)));
    })
        : prism_rtl::is<ast::ExprKind::EField>(_m) ? ({
        auto c_1 = c;
        auto env_2 = env;
        auto lx_3 = lx;
        call_then(start_value_of(lx_3, env_2, c_1), [=](Vl value_of_165647) { return prism_rtl::finished(job_value(value_of_165647)); });
    })
        : prism_rtl::finished(std::optional<Vl>{});
    });
}


/// `Start LocalJobFn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<Vl>> start_local_job_fn(Lx lx, Env env, ast::Expr c) {
    return std::make_shared<LocalJobFn>(lx, env, c);
}


/// ?JobValue: fn Vl -> ?Vl
std::optional<Vl> job_value(const Vl& f) {
    return ({
        __label__ _done;
        prism_rtl::Slot<std::optional<Vl>> _v;
        auto&& _m = value_ty(f);
        if (prism_rtl::is<OutTy::OutJobFn>(_m)) {
            _v.set(std::optional(f));
            goto _done;
        }
        {
            _v.set(std::optional<Vl>{});
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// StartCall: fn Vl, [Ex] -> Ex
Ex start_call(const Vl& f, const Array<Ex>& vals) {
    return Ex(Ex::XApply{prism_rtl::rc(ref_(f)), Array(std::vector{one_or_tuple(vals)})});
}


/// OneOrTuple: fn [Ex] -> Ex
Ex one_or_tuple(const Array<Ex>& xs0) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Ex> _v;
        {
            auto&& c0_0 = xs0;
            if (c0_0.size() == 1u) {
                {
                    auto&& _c1 = index(c0_0, Nat(0u));
                    if (prism_rtl::is_some(_c1)) {
                        auto&& one = prism_rtl::some_of(_c1);
                        _v.set(one);
                        goto _done;
                    }
                }
            }
        }
        {
            auto&& vals = xs0;
            _v.set(Ex(Ex::XTuple{vals}));
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// CalleeText: fn Expr -> Text
Text callee_text(const ast::Expr& c) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = c.kind;
        if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
            auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
            _v.set(check_env::dotted(n->path_));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EGroup>(_m)) {
            auto&& x = prism_rtl::as<ast::ExprKind::EGroup>(_m).a0;
            _v.set(callee_text(x));
            goto _done;
        }
        {
            _v.set(Text("call"));
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// RestText: fn Lx, Range, Range, Range -> Text
Text rest_text(const Lx& lx, const ast::Range& from, const ast::Range& call, const ast::Range& to) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = index(lx.g.srcs, lx->file);
        if (prism_rtl::is_some(_m)) {
            auto&& src = prism_rtl::some_of(_m);
            _v.set(check_errors::span_text(src, ast::Range{.start = from.start, .end = to.end}));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// Mentions: fn Text, Text -> Bool
bool mentions(const Text& text, const Text& name) {
    auto parts = split(text, name);
    auto last = lexer::dec(len(parts));
    return fold(check_errors::range0(last), false, [&](const bool& found, const Nat& i) {
        return ({
            auto before = or_(index(parts, i), Text(""));
            auto after = or_(index(parts, i + Nat(1u)), Text(""));
            auto left_word = before != Text("") ? ends_ident(before) : (i > Nat(0u)) && ends_ident(name);
            auto right_word = after != Text("")
                ? starts_ident(after)
                : ((i + Nat(1u)) < last) && starts_ident(name);
            found || ((!left_word) && (!right_word));
        });
    });
}


/// EndsIdent: fn Text -> Bool
bool ends_ident(const Text& t) {
    return (len_text(t) > Nat(0u)) && lexer::is_ident_char(drop_text(t, lexer::dec(len_text(t))));
}


/// StartsIdent: fn Text -> Bool
bool starts_ident(const Text& t) {
    return (len_text(t) > Nat(0u)) && lexer::is_ident_char(take_text(t, Nat(1u)));
}


/// TailBody: unbounded fn Lx, Env, FnBody -> Ex
Ex tail_body(const Lx& lx, const Env& env, const ast::FnBody& fn_body2) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Ex> _v;
        if (prism_rtl::is<ast::FnBody::BodyExpr>(fn_body2)) {
            auto&& x = prism_rtl::as<ast::FnBody::BodyExpr>(fn_body2).a0;
            _v.set(tail(lx, env, x));
            goto _done;
        }
        if (prism_rtl::is<ast::FnBody::BodyBlock>(fn_body2)) {
            auto&& b = prism_rtl::as<ast::FnBody::BodyBlock>(fn_body2).a0;
            _v.set(tail_block(lx, env, b));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Ex> TailBody::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& fn_body2 = this->fn_body2;
    return ({
        prism_rtl::is<ast::FnBody::BodyExpr>(fn_body2) ? ({
        auto&& x = prism_rtl::as<ast::FnBody::BodyExpr>(fn_body2).a0;
        prism_rtl::more(prism_rtl::rc(Tail(lx, env, x)));
    })
        : prism_rtl::is<ast::FnBody::BodyBlock>(fn_body2) ? ({
        auto&& b = prism_rtl::as<ast::FnBody::BodyBlock>(fn_body2).a0;
        prism_rtl::more(prism_rtl::rc(TailBlock(lx, env, b)));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start TailBody, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Ex> start_tail_body(Lx lx, Env env, ast::FnBody fn_body2) {
    return std::make_shared<TailBody>(lx, env, fn_body2);
}


/// TailMatch: unbounded fn Lx, Env, Expr, [Arm], Range -> Ex
Ex tail_match(const Lx& lx, const Env& env, const ast::Expr& s, const Array<ast::Arm>& arms, const ast::Range& span) {
    auto sv = value_of(lx, env, s);
    auto sty = type_at(lx, s.span);
    auto label = prism_rtl::cat("m", span.start);
    auto by_ref = run_to_end(each_job(check_errors::range0(len(arms)), ({
        auto lx_1 = lx;
        auto arms_2 = arms;
        auto sty_3 = sty;
        auto label_4 = label;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<PatOut>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto lx_1_5 = lx_1;
            auto arms_2_5 = arms_2;
            auto sty_3_5 = sty_3;
            auto label_4_5 = label_4;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                (prism_rtl::more(prism_rtl::rc(ArmPat(lx_1_5, or_(index(arms_2_5, i), dummy_arm()).pattern, sty_3_5, Holding(Holding::ByRef{}), prism_rtl::cat(label_4_5, "_", i)))));
            });
        }));
        });
    })));
    })));
    auto chain = fold(by_ref, false, [&](const bool& f, const PatOut& po) { return f || fold(po.conds, false, [&](const bool& f2, const Cc& c) { return f2 || is_let_cond(c); }); });
    auto owned = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        if (prism_rtl::is<Vl::VlOwned>(sv)) {
            _v.set(!chain);
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
    auto pats = owned
        ? run_to_end(each_job(check_errors::range0(len(arms)), ({
        auto lx_1 = lx;
        auto arms_2 = arms;
        auto sty_3 = sty;
        auto label_4 = label;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<PatOut>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto lx_1_5 = lx_1;
            auto arms_2_5 = arms_2;
            auto sty_3_5 = sty_3;
            auto label_4_5 = label_4;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                (prism_rtl::more(prism_rtl::rc(ArmPat(lx_1_5, or_(index(arms_2_5, i), dummy_arm()).pattern, sty_3_5, Holding(Holding::Owned{}), prism_rtl::cat(label_4_5, "_", i)))));
            });
        }));
        });
    })));
    })))
        : by_ref;
    auto xarms = run_to_end(each_job(check_errors::range0(len(arms)), ({
        auto arms_1 = arms;
        auto pats_2 = pats;
        auto env_3 = env;
        auto lx_4 = lx;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<XArm>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto arms_1_5 = arms_1;
            auto pats_2_5 = pats_2;
            auto env_3_5 = env_3;
            auto lx_4_5 = lx_4;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                ({
                auto arm = or_(index(arms_1_5, i), dummy_arm());
                auto po = or_(index(pats_2_5, i), PatOut{.pa = Pa(Pa::PaWild{}), .conds = Array<Cc>{}, .binds = Array<std::tuple<Text, Bn>>{}});
                auto env2 = bind_all(env_3_5, po.binds);
                call_then(start_guard_conds(lx_4_5, env2, arm.guard), [=](Array<Cc> guard_conds_168571) { return call_then(start_tail_block(lx_4_5, env2, arm.body), [=](Ex tail_block_168612) { return prism_rtl::finished(XArm{.pat = po.pa, .conds = append(po.conds, guard_conds_168571), .body = tail_block_168612}); }); });
            });
            });
        }));
        });
    })));
    })));
    auto scrut = owned ? own(sv) : ref_(sv);
    return own(arms_value(scrut, xarms, prism_rtl::cat("'", label), OutTy(OutTy::OutUnknown{Text("the job's turn")})));
}


prism_rtl::Turn<Ex> TailMatch::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& s = this->s;
    const auto& arms = this->arms;
    const auto& span = this->span;
    auto arms_1 = arms;
    auto env_2 = env;
    auto lx_3 = lx;
    auto s_4 = s;
    auto span_5 = span;
    return call_then(start_value_of(lx_3, env_2, s_4), [=](Vl value_of_167793) {
        return ({
            auto sv = value_of_167793;
            auto sty = type_at(lx_3, s_4.span);
            auto label = prism_rtl::cat("m", span_5.start);
            call_value(each_job(check_errors::range0(len(arms_1)), ({
            auto lx_3_6 = lx_3;
            auto arms_1_6 = arms_1;
            auto sty_6 = sty;
            auto label_7 = label;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<PatOut>(Nat)>>(prism_rtl::rc([=](Nat p0) {
            return ({
                auto lx_3_6_8 = lx_3_6;
                auto arms_1_6_8 = arms_1_6;
                auto sty_6_8 = sty_6;
                auto label_7_8 = label_7;
                entered(once_job([=]() {
                return ({
                    auto i = p0;
                    (prism_rtl::more(prism_rtl::rc(ArmPat(lx_3_6_8, or_(index(arms_1_6_8, i), dummy_arm()).pattern, sty_6_8, Holding(Holding::ByRef{}), prism_rtl::cat(label_7_8, "_", i)))));
                });
            }));
            });
        })));
        })), [=](Array<PatOut> each_167892) {
            return ({
                auto by_ref = each_167892;
                auto chain = fold(by_ref, false, [&](const bool& f, const PatOut& po) { return f || fold(po.conds, false, [&](const bool& f2, const Cc& c) { return f2 || is_let_cond(c); }); });
                auto owned = ({
                    __label__ _done;
                    prism_rtl::Slot<bool> _v;
                    if (prism_rtl::is<Vl::VlOwned>(sv)) {
                        _v.set(!chain);
                        goto _done;
                    }
                    {
                        _v.set(false);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                auto pats = owned
                    ? run_to_end(each_job(check_errors::range0(len(arms_1)), ({
                    auto lx_3_6 = lx_3;
                    auto arms_1_6 = arms_1;
                    auto sty_6 = sty;
                    auto label_7 = label;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<PatOut>(Nat)>>(prism_rtl::rc([=](Nat p0) {
                    return ({
                        auto lx_3_6_8 = lx_3_6;
                        auto arms_1_6_8 = arms_1_6;
                        auto sty_6_8 = sty_6;
                        auto label_7_8 = label_7;
                        entered(once_job([=]() {
                        return ({
                            auto i = p0;
                            (prism_rtl::more(prism_rtl::rc(ArmPat(lx_3_6_8, or_(index(arms_1_6_8, i), dummy_arm()).pattern, sty_6_8, Holding(Holding::Owned{}), prism_rtl::cat(label_7_8, "_", i)))));
                        });
                    }));
                    });
                })));
                })))
                    : by_ref;
                call_value(each_job(check_errors::range0(len(arms_1)), ({
                auto arms_1_6 = arms_1;
                auto pats_6 = pats;
                auto env_2_7 = env_2;
                auto lx_3_7 = lx_3;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<XArm>(Nat)>>(prism_rtl::rc([=](Nat p0) {
                return ({
                    auto arms_1_6_7 = arms_1_6;
                    auto pats_6_7 = pats_6;
                    auto env_2_7_7 = env_2_7;
                    auto lx_3_7_7 = lx_3_7;
                    entered(once_job([=]() {
                    return ({
                        auto i = p0;
                        ({
                        auto arm = or_(index(arms_1_6_7, i), dummy_arm());
                        auto po = or_(index(pats_6_7, i), PatOut{.pa = Pa(Pa::PaWild{}), .conds = Array<Cc>{}, .binds = Array<std::tuple<Text, Bn>>{}});
                        auto env2 = bind_all(env_2_7_7, po.binds);
                        call_then(start_guard_conds(lx_3_7_7, env2, arm.guard), [=](Array<Cc> guard_conds_168571) { return call_then(start_tail_block(lx_3_7_7, env2, arm.body), [=](Ex tail_block_168612) { return prism_rtl::finished(XArm{.pat = po.pa, .conds = append(po.conds, guard_conds_168571), .body = tail_block_168612}); }); });
                    });
                    });
                }));
                });
            })));
            })), [=](Array<XArm> each_168338) {
                return ({
                    auto xarms = each_168338;
                    auto scrut = owned ? own(sv) : ref_(sv);
                    (prism_rtl::finished(own(arms_value(scrut, xarms, prism_rtl::cat("'", label), OutTy(OutTy::OutUnknown{Text("the job's turn")})))));
                });
            });
            });
        });
        });
    });
}


/// `Start TailMatch, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Ex> start_tail_match(Lx lx, Env env, ast::Expr s, Array<ast::Arm> arms, ast::Range span) {
    return std::make_shared<TailMatch>(lx, env, s, arms, span);
}


/// ?TailCallee: fn Lx, Env, Expr -> ?Text
std::optional<Text> tail_callee(const Lx& lx, const Env& env, const ast::Expr& callee) {
    return ({
        __label__ _done;
        prism_rtl::Slot<std::optional<Text>> _v;
        auto&& _m = callee.kind;
        if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
            auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
            _v.set((len(n->path_) == Nat(1u)) && check_env::has_key(env->names, check_env::sname_key(n))
                ? std::optional<Text>{}
                : ({
                auto&& _qk_opt = check_env::resolve_value(lx.g, lx.home, n);
                auto&& qk_opt = std::get<0>(_qk_opt);
                ({
                __label__ _done;
                prism_rtl::Slot<std::optional<Text>> _v;
                if (prism_rtl::is_some(qk_opt)) {
                    auto&& qk = prism_rtl::some_of(qk_opt);
                    _v.set(check_types::has_text(lx.unbs, qk) && (!in_prelude(lx, qk))
                        ? std::optional(qk)
                        : std::optional<Text>{});
                    goto _done;
                }
                if (prism_rtl::is_none(qk_opt)) {
                    _v.set(std::optional<Text>{});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            }));
            goto _done;
        }
        {
            _v.set(std::optional<Text>{});
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// SchemeParts: fn Lx, Text -> (([Ty], Ty))
std::tuple<Array<check_types::Ty>, check_types::Ty> scheme_parts(const Lx& lx, const Text& qk) {
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Array<check_types::Ty>, check_types::Ty>> _v;
        auto&& _m = prelude::get(lx.g.vals, qk);
        if (prism_rtl::is_some(_m)) {
            auto&& v_ = prism_rtl::some_of(_m);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::tuple<Array<check_types::Ty>, check_types::Ty>> _v;
                auto&& _m = v_.scheme.ty;
                if (prism_rtl::is<check_types::Ty::TyFn>(_m)) {
                    auto&& ps = prism_rtl::as<check_types::Ty::TyFn>(_m).a1;
                    auto&& r = prism_rtl::as<check_types::Ty::TyFn>(_m).a2;
                    _v.set(std::tuple{ps, r});
                    goto _done;
                }
                {
                    auto&& other = _m;
                    _v.set(std::tuple{Array<check_types::Ty>{}, other});
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(std::tuple{Array<check_types::Ty>{}, check_types::Ty(check_types::Ty::TyErr{})});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// JobFieldNames: unbounded fn Lx, Text -> [Text]
Array<Text> job_field_names(const Lx& lx, const Text& qk) {
    auto clauses = clauses_of(lx.g, qk);
    auto&& _ptys = scheme_parts(lx, qk);
    auto&& ptys = std::get<0>(_ptys);
    auto pts = run_to_end(each_job(ptys, ({
        auto lx_1 = lx;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<OutTy>(check_types::Ty)>>(prism_rtl::rc([=](check_types::Ty p0) {
        return ({
            auto lx_1_2 = lx_1;
            entered(once_job([=]() {
            return ({
                auto p_ = p0;
                (prism_rtl::more(prism_rtl::rc(OutTyOf(lx_1_2, peel(p_)))));
            });
        }));
        });
    })));
    })));
    return each(param_names(lx, clauses, pts), [&](const std::tuple<Text, bool>& _p0) {
        auto&& n = std::get<0>(_p0);
        return n;
    });
}


prism_rtl::Turn<Array<Text>> JobFieldNames::cycle() const {
    const auto& lx = this->lx;
    const auto& qk = this->qk;
    auto clauses = clauses_of(lx.g, qk);
    auto&& _ptys = scheme_parts(lx, qk);
    auto&& ptys = std::get<0>(_ptys);
    auto lx_1 = lx;
    return call_value(each_job(ptys, ({
        auto lx_1_2 = lx_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<OutTy>(check_types::Ty)>>(prism_rtl::rc([=](check_types::Ty p0) {
        return ({
            auto lx_1_2_2 = lx_1_2;
            entered(once_job([=]() {
            return ({
                auto p_ = p0;
                (prism_rtl::more(prism_rtl::rc(OutTyOf(lx_1_2_2, peel(p_)))));
            });
        }));
        });
    })));
    })), [=](Array<OutTy> each_169679) {
        return ({
            auto pts = each_169679;
            (prism_rtl::finished(each(param_names(lx_1, clauses, pts), [&](const std::tuple<Text, bool>& _p0) {
            auto&& n = std::get<0>(_p0);
            return n;
        })));
        });
    });
}


/// `Start JobFieldNames, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_job_field_names(Lx lx, Text qk) {
    return std::make_shared<JobFieldNames>(lx, qk);
}


/// ClausesOf: fn G, Text -> [FnClause]
Array<ast::FnClause> clauses_of(const check_env::G& g, const Text& qk) {
    return fold(g.defs, Array<ast::FnClause>{}, [&](const Array<ast::FnClause>& acc, const check_env::Def& d) { return d.qk == qk ? def_clauses(d, acc) : acc; });
}


/// DefClauses: fn Def, [FnClause] -> [FnClause]
Array<ast::FnClause> def_clauses(const check_env::Def& d, const Array<ast::FnClause>& other) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Array<ast::FnClause>> _v;
        auto&& _m = d.body;
        if (prism_rtl::is<check_env::DefBody::DbFn>(_m)) {
            auto&& cs = prism_rtl::as<check_env::DefBody::DbFn>(_m).a0;
            _v.set(cs);
            goto _done;
        }
        {
            _v.set(other);
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// JobDefOf: unbounded fn Lx, Text, [FnClause], Scheme -> JobDef
JobDef job_def_of(const Lx& lx, const Text& qk, const Array<ast::FnClause>& clauses, const check_types::Scheme& sc) {
    auto [ptys, res] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Array<check_types::Ty>, check_types::Ty>> _v;
        auto&& _m = sc.ty;
        if (prism_rtl::is<check_types::Ty::TyFn>(_m)) {
            auto&& ps = prism_rtl::as<check_types::Ty::TyFn>(_m).a1;
            auto&& r = prism_rtl::as<check_types::Ty::TyFn>(_m).a2;
            _v.set(std::tuple{ps, r});
            goto _done;
        }
        {
            auto&& other = _m;
            _v.set(std::tuple{Array<check_types::Ty>{}, other});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto pts = run_to_end(each_job(ptys, ({
        auto lx_1 = lx;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<OutTy>(check_types::Ty)>>(prism_rtl::rc([=](check_types::Ty p0) {
        return ({
            auto lx_1_2 = lx_1;
            entered(once_job([=]() {
            return ({
                auto p_ = p0;
                (prism_rtl::more(prism_rtl::rc(OutTyOf(lx_1_2, peel(p_)))));
            });
        }));
        });
    })));
    })));
    auto names = param_names(lx, clauses, pts);
    auto body = job_clauses(lx, clauses, names, ptys, pts);
    auto base_ = or_(prelude::get(lx.rs_names, qk), snake(check_types::bare_name(qk)));
    return JobDef{.name = camel(check_types::bare_name(qk)), .start = prism_rtl::cat("start_", base_), .generics = scheme_generics(lx, sc), .fields = each(check_errors::range0(len(pts)), [&](const Nat& i) {
        return std::tuple{or_(index(each(names, [&](const std::tuple<Text, bool>& _p0) {
            auto&& n = std::get<0>(_p0);
            return n;
        }), i), Text("arg")), or_(index(pts, i), OutTy(OutTy::OutUnit{}))};
    }), .ret = out_ty_of(lx, peel(res)), .body = body, .doc = signature_text(lx, qk)};
}


prism_rtl::Turn<JobDef> JobDefOf::cycle() const {
    const auto& lx = this->lx;
    const auto& qk = this->qk;
    const auto& clauses = this->clauses;
    const auto& sc = this->sc;
    auto [ptys, res] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Array<check_types::Ty>, check_types::Ty>> _v;
        auto&& _m = sc.ty;
        if (prism_rtl::is<check_types::Ty::TyFn>(_m)) {
            auto&& ps = prism_rtl::as<check_types::Ty::TyFn>(_m).a1;
            auto&& r = prism_rtl::as<check_types::Ty::TyFn>(_m).a2;
            _v.set(std::tuple{ps, r});
            goto _done;
        }
        {
            auto&& other = _m;
            _v.set(std::tuple{Array<check_types::Ty>{}, other});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto clauses_1 = clauses;
    auto lx_2 = lx;
    auto qk_3 = qk;
    auto sc_4 = sc;
    return call_value(each_job(ptys, ({
        auto lx_2_5 = lx_2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<OutTy>(check_types::Ty)>>(prism_rtl::rc([=](check_types::Ty p0) {
        return ({
            auto lx_2_5_5 = lx_2_5;
            entered(once_job([=]() {
            return ({
                auto p_ = p0;
                (prism_rtl::more(prism_rtl::rc(OutTyOf(lx_2_5_5, peel(p_)))));
            });
        }));
        });
    })));
    })), [=](Array<OutTy> each_170333) {
        return ({
            auto pts = each_170333;
            auto names = param_names(lx_2, clauses_1, pts);
            call_then(start_job_clauses(lx_2, clauses_1, names, ptys, pts), [=](Ex job_clauses_170429) {
            return ({
                auto body = job_clauses_170429;
                auto base_ = or_(prelude::get(lx_2.rs_names, qk_3), snake(check_types::bare_name(qk_3)));
                call_then(start_out_ty_of(lx_2, peel(res)), [=](OutTy out_ty_of_170740) {
                return prism_rtl::finished(JobDef{.name = camel(check_types::bare_name(qk_3)), .start = prism_rtl::cat("start_", base_), .generics = scheme_generics(lx_2, sc_4), .fields = each(check_errors::range0(len(pts)), [&](const Nat& i) {
                    return std::tuple{or_(index(each(names, [&](const std::tuple<Text, bool>& _p0) {
                        auto&& n = std::get<0>(_p0);
                        return n;
                    }), i), Text("arg")), or_(index(pts, i), OutTy(OutTy::OutUnit{}))};
                }), .ret = out_ty_of_170740, .body = body, .doc = signature_text(lx_2, qk_3)});
            });
            });
        });
        });
    });
}


/// `Start JobDefOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<JobDef> start_job_def_of(Lx lx, Text qk, Array<ast::FnClause> clauses, check_types::Scheme sc) {
    return std::make_shared<JobDefOf>(lx, qk, clauses, sc);
}


/// JobClauses: unbounded fn Lx, [FnClause], [((Text, Bool))], [Ty], [OutTy] -> Ex
Ex job_clauses(const Lx& lx, const Array<ast::FnClause>& clauses, const Array<std::tuple<Text, bool>>& names, const Array<check_types::Ty>& ptys, const Array<OutTy>& pts) {
    auto lets = each(check_errors::range0(len(names)), [&](const Nat& i) {
        return ({
            auto&& _rs = or_(index(names, i), std::tuple{Text("arg"), true});
            auto&& rs = std::get<0>(_rs);
            (Do(Do::DoLet{Pa(Pa::PaBind{rs}), Ex(Ex::XRef{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), rs}))})}));
        });
    });
    auto inner = clauses_body(lx, empty_env(), clauses, names, ptys, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Lx, Env, ast::FnBody>)>>(prism_rtl::rc([&](std::tuple<Lx, Env, ast::FnBody> _p0) {
        auto&& a0 = std::get<0>(_p0);
        auto&& a1 = std::get<1>(_p0);
        auto&& a2 = std::get<2>(_p0);
        return entered(start_tail_body(a0, a1, a2));
    })), Text("j"), OutTy(OutTy::OutUnknown{Text("the job's turn")}));
    return Ex(Ex::XBlock{lets, prism_rtl::rc(inner)});
}


prism_rtl::Turn<Ex> JobClauses::cycle() const {
    const auto& lx = this->lx;
    const auto& clauses = this->clauses;
    const auto& names = this->names;
    const auto& ptys = this->ptys;
    const auto& pts = this->pts;
    auto lets = each(check_errors::range0(len(names)), [&](const Nat& i) {
        return ({
            auto&& _rs = or_(index(names, i), std::tuple{Text("arg"), true});
            auto&& rs = std::get<0>(_rs);
            (Do(Do::DoLet{Pa(Pa::PaBind{rs}), Ex(Ex::XRef{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), rs}))})}));
        });
    });
    auto clauses_1 = clauses;
    auto lx_2 = lx;
    auto names_3 = names;
    auto ptys_4 = ptys;
    return call_then(start_clauses_body(lx_2, empty_env(), clauses_1, names_3, ptys_4, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Lx, Env, ast::FnBody>)>>(prism_rtl::rc([&](std::tuple<Lx, Env, ast::FnBody> _p0) {
        auto&& a0 = std::get<0>(_p0);
        auto&& a1 = std::get<1>(_p0);
        auto&& a2 = std::get<2>(_p0);
        return entered(start_tail_body(a0, a1, a2));
    })), Text("j"), OutTy(OutTy::OutUnknown{Text("the job's turn")})), [=](Ex clauses_body_171169) {
        return ({
            auto inner = clauses_body_171169;
            (prism_rtl::finished(Ex(Ex::XBlock{lets, prism_rtl::rc(inner)})));
        });
    });
}


/// `Start JobClauses, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Ex> start_job_clauses(Lx lx, Array<ast::FnClause> clauses, Array<std::tuple<Text, bool>> names, Array<check_types::Ty> ptys, Array<OutTy> pts) {
    return std::make_shared<JobClauses>(lx, clauses, names, ptys, pts);
}


/// IdPipe: unbounded fn Ex, (unbounded fn Ex -> [Do]) -> [Do]
Array<Do> id_pipe(const Ex& x, const prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(Ex)>& k_fn) {
    return run_to_end(k_fn(x));
}


prism_rtl::Turn<Array<Do>> IdPipe::cycle() const {
    const auto& x = this->x;
    const auto& k_fn = this->k_fn;
    return k_fn(x)->cycle();
}


/// `Start IdPipe, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Do>> start_id_pipe(Ex x, prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(Ex)> k_fn) {
    return std::make_shared<IdPipe>(x, k_fn);
}


/// EvRefOf: fn Nat -> EvRef
EvRef ev_ref_of(const Nat& n) {
    return EvRef{.node_ = n, .pipe = static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(std::tuple<Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(Ex)>>)>>(prism_rtl::rc([&](std::tuple<Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(Ex)>> _p0) {
        auto&& a0 = std::get<0>(_p0);
        auto&& a1 = std::get<1>(_p0);
        return entered(start_id_pipe(a0, a1));
    }))};
}


/// KindWord: fn GnKind -> Text
Text kind_word(const GnKind& k) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        if (prism_rtl::is<GnKind::GnNamed>(k)) {
            _v.set(Text("named"));
            goto _done;
        }
        if (prism_rtl::is<GnKind::GnAnswer>(k)) {
            _v.set(Text("answer"));
            goto _done;
        }
        if (prism_rtl::is<GnKind::GnStarted>(k)) {
            _v.set(Text("started"));
            goto _done;
        }
        if (prism_rtl::is<GnKind::GnDeferred>(k)) {
            _v.set(Text("deferred"));
            goto _done;
        }
        if (prism_rtl::is<GnKind::GnPort>(k)) {
            _v.set(Text("port"));
            goto _done;
        }
        if (prism_rtl::is<GnKind::GnMerge>(k)) {
            _v.set(Text("merge"));
            goto _done;
        }
        if (prism_rtl::is<GnKind::GnUnion>(k)) {
            _v.set(Text("union"));
            goto _done;
        }
        if (prism_rtl::is<GnKind::GnBoth>(k)) {
            _v.set(Text("both"));
            goto _done;
        }
        if (prism_rtl::is<GnKind::GnExcept>(k)) {
            _v.set(Text("except"));
            goto _done;
        }
        if (prism_rtl::is<GnKind::GnMergeAll>(k)) {
            _v.set(Text("mergeall"));
            goto _done;
        }
        if (prism_rtl::is<GnKind::GnGather>(k)) {
            _v.set(Text("gather"));
            goto _done;
        }
        if (prism_rtl::is<GnKind::GnUpdated>(k)) {
            _v.set(Text("updated"));
            goto _done;
        }
        if (prism_rtl::is<GnKind::GnNever>(k)) {
            _v.set(Text("never"));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// HasRead: fn [Read], Read -> Bool
bool has_read(const Array<Read>& rs, const Read& r) {
    return fold(rs, false, [&](const bool& seen, const Read& x) { return seen || (x == r); });
}


/// AddRead: fn [Read], Read -> [Read]
Array<Read> add_read(const Array<Read>& rs, const Read& r) {
    return has_read(rs, r) ? rs : prelude::push(rs, r);
}


/// UnionReads: fn [Read], [Read] -> [Read]
Array<Read> union_reads(const Array<Read>& xs, const Array<Read>& ys) {
    return fold(ys, xs, [&](const Array<Read>& acc, const Read& y) { return add_read(acc, y); });
}


/// let nodeHooks
Array<Text> node_hooks() {
    return Array(std::vector{Text("path"), Text("build"), Text("wake"), Text("started"), Text("deferred"), Text("answer"), Text("push"), Text("swap"), Text("leave"), Text("patch"), Text("clean_up"), Text("edges"), Text("release"), Text("leave_row"), Text("remove_places")});
}


/// NewWx: fn Lx, Text, [((Text, OutTy, Text))], [((Text, Ex))], [((Text, Ex))], [MethDef], (Text ==> [Read]), [Text], Nat, ?Text -> Wx
Wx new_wx(const Lx& lx, const Text& name, const Array<std::tuple<Text, OutTy, Text>>& fields, const Array<std::tuple<Text, Ex>>& inits, const Array<std::tuple<Text, Ex>>& moves_, const Array<MethDef>& getters, const Map<Text, Array<Read>>& dyn_reads, const Array<Text>& taken, const Nat& depth, const std::optional<Text>& hosted_by_opt) {
    auto hosted_fields = ({
        __label__ _done;
        prism_rtl::Slot<Array<std::tuple<Text, OutTy, Text>>> _v;
        if (prism_rtl::is_some(hosted_by_opt)) {
            _v.set(Array(std::vector{std::tuple{Text("enclosing"), host_of_ty(), Text("the host whose document this row's places are entries of (pick HO)")}}));
            goto _done;
        }
        if (prism_rtl::is_none(hosted_by_opt)) {
            _v.set(Array<std::tuple<Text, OutTy, Text>>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto hosted_inits = ({
        __label__ _done;
        prism_rtl::Slot<Array<std::tuple<Text, Ex>>> _v;
        if (prism_rtl::is_some(hosted_by_opt)) {
            _v.set(Array(std::vector{std::tuple{Text("enclosing"), Ex(Ex::XVar{Text("enclosing")})}}));
            goto _done;
        }
        if (prism_rtl::is_none(hosted_by_opt)) {
            _v.set(Array<std::tuple<Text, Ex>>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return Wx{.lx = lx, .node_ = name, .pos = pos0(), .gns = Array<Gn>{}, .fields = append(fields, hosted_fields), .inits = inits, .moves = append(moves_, hosted_inits), .lets = Array<Do>{}, .build = Array<Do>{}, .places = Array<Place>{}, .answers = Array<std::tuple<Pos_, Nat, OutTy, Text>>{}, .started = Array<Nat>{}, .defers = Array<std::tuple<Text, Nat>>{}, .getters = getters, .dyn_reads = dyn_reads, .taken = prelude::push(taken, Text("enclosing")), .fallible = false, .depth = depth, .result = Wres(Wres::WrUnit{}), .rows = Array<NodeDef>{}, .builders = Array<ForDef>{}, .build_holds = Array<Read>{}, .up_sink = Text(""), .gens = Array<GenDef>{}, .gen_holds = Array<std::tuple<Text, Array<Read>>>{}, .ports = Array<Text>{}, .subs = Array<std::tuple<Text, Text, OutTy>>{}, .parent_env = empty_env(), .hosts = Array<HostDef>{}, .dyn_places = Array<std::tuple<Pos_, Text, OutTy, Text>>{}, .scopes = Array<Text>{}, .hosted_by = hosted_by_opt, .root_dyn = std::optional<std::tuple<Ex, Array<Read>, OutTy>>{}, .row_marks = Array<RowMarks>{}, .pending = Array<PendingRow>{}, .floors = Map<Text, Nat>{}, .snaps = Array<SnapDef>{}, .result_moved = std::optional<std::tuple<Text, Array<Read>>>{}, .dyn_answers = Array<std::tuple<Text, Array<Read>>>{}, .inited = Array<Text>{}, .flattens = Array<FlatDef>{}};
}


/// FreshName: fn Wx, Text -> ((Text, Wx))
std::tuple<Text, Wx> fresh_name(const Wx& wx, const Text& base_) {
    auto pick = !check_types::has_text(wx.taken, base_)
        ? base_
        : prism_rtl::cat(base_, "_", first_free(wx.taken, base_, Nat(2u)));
    auto wx2 = ({
        Wx this_ = wx;
        this_.taken = prelude::push(this_.taken, pick);
        this_;
    });
    return std::tuple{pick, wx2};
}


/// FirstFree: fn [Text], Text, Nat -> Nat
Nat first_free(const Array<Text>& taken, const Text& base_, const Nat& from) {
    return fold(check_errors::range0(len(taken)), from, [&](const Nat& n, const Nat& _p1) {
        return check_types::has_text(taken, prism_rtl::cat(base_, "_", n))
            ? n + Nat(1u)
            : n;
    });
}


/// AddGn: fn Wx, Text, OutTy, GnKind, Nat -> ((Nat, Wx))
std::tuple<Nat, Wx> add_gn(const Wx& wx, const Text& name, const OutTy& ty, const GnKind& kind, const Nat& height) {
    auto id = len(wx.gns);
    auto wx2 = ({
        Wx this_ = wx;
        this_.gns = prelude::push(this_.gns, Gn{.id = id, .name = name, .ty = ty, .kind = kind, .height = height, .inputs = Array<Text>{}, .reads = Array<Read>{}, .floor = Nat(0u), .outs = Array<Out>{}});
        this_;
    });
    return std::tuple{id, wx2};
}


/// Connect: fn Wx, EvRef, Sk -> Wx
Wx connect(const Wx& wx, const EvRef& r, const Sk& sink) {
    Wx this_ = wx;
    this_.gns = each(this_.gns, [&](const Gn& n) { return n.id == r.node_ ? add_out(n, Out{.pipe = r.pipe, .sink = sink}) : n; });
    return this_;
}


/// AddOut: fn Gn, Out -> Gn
Gn add_out(const Gn& n, const Out& o) {
    Gn this_ = n;
    this_.outs = prelude::push(this_.outs, o);
    return this_;
}


/// AddField: fn Wx, Text, OutTy, Text, Ex -> Wx
Wx add_field(const Wx& wx, const Text& name, const OutTy& t, const Text& doc, const Ex& init) {
    Wx this_ = wx;
    this_.fields = prelude::push(this_.fields, std::tuple{name, t, doc});
    this_.inits = prelude::push(this_.inits, std::tuple{name, init});
    return this_;
}


/// AddFieldLast: fn Wx, Text, OutTy, Text, Ex -> Wx
Wx add_field_last(const Wx& wx, const Text& name, const OutTy& t, const Text& doc, const Ex& init) {
    Wx this_ = wx;
    this_.fields = prelude::push(this_.fields, std::tuple{name, t, doc});
    this_.moves = prelude::push(this_.moves, std::tuple{name, init});
    return this_;
}


/// GnOf: fn Wx, Nat -> Gn
Gn gn_of(const Wx& wx, const Nat& n) {
    return or_(index(wx.gns, n), Gn{.id = n, .name = Text("never"), .ty = OutTy(OutTy::OutUnit{}), .kind = GnKind(GnKind::GnNever{}), .height = Nat(0u), .inputs = Array<Text>{}, .reads = Array<Read>{}, .floor = Nat(0u), .outs = Array<Out>{}});
}


/// BindPlain: fn Env, Env, Text, Text, OutTy -> ((Env, Env))
std::tuple<Env, Env> bind_plain(const Env& benv, const Env& menv, const Text& nkey, const Text& rs, const OutTy& t) {
    return std::tuple{bind(benv, nkey, Bn(Bn::BnLocal{Ex(Ex::XVar{rs}), Holding(Holding::Owned{}), t})), bind(menv, nkey, Bn(Bn::BnLocal{Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), rs}), Holding(Holding::Owned{}), t}))};
}


/// NodeDefOf: unbounded fn Lx, Text, [Pattern], Block, Scheme, Bool -> NodeDef
NodeDef node_def_of(const Lx& lx, const Text& qk, const Array<ast::Pattern_>& params, const ast::Block& body, const check_types::Scheme& sc, const bool& is_root) {
    auto name = camel(check_types::bare_name(qk));
    auto ptys = ({
        __label__ _done;
        prism_rtl::Slot<Array<check_types::Ty>> _v;
        auto&& _m = sc.ty;
        if (prism_rtl::is<check_types::Ty::TyFn>(_m)) {
            auto&& ps = prism_rtl::as<check_types::Ty::TyFn>(_m).a1;
            _v.set(ps);
            goto _done;
        }
        {
            _v.set(Array<check_types::Ty>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto wx0 = new_wx(lx, name, Array<std::tuple<Text, OutTy, Text>>{}, Array<std::tuple<Text, Ex>>{}, Array<std::tuple<Text, Ex>>{}, Array<MethDef>{}, Map<Text, Array<Read>>{}, node_hooks(), Nat(0u), std::optional<Text>{});
    auto [ps, wx1, benv, menv] = run_to_end(fold_job(check_errors::range0(len(params)), std::tuple{Array<std::tuple<Text, OutTy>>{}, wx0, empty_env(), empty_env()}, ({
        auto params_1 = params;
        auto lx_2 = lx;
        auto ptys_3 = ptys;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, OutTy>>, Wx, Env, Env>>(std::tuple<std::tuple<Array<std::tuple<Text, OutTy>>, Wx, Env, Env>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<std::tuple<Text, OutTy>>, Wx, Env, Env>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto params_1_4 = params_1;
            auto lx_2_4 = lx_2;
            auto ptys_3_4 = ptys_3;
            entered(once_job([=]() {
            return ({
                auto [acc, w, be, me] = p0;
                auto i = p1;
                ({
                auto p_ = or_(index(params_1_4, i), dummy_pat());
                auto nkey = plain_binder(lx_2_4, p_);
                auto base_ = nkey == Text("") ? prism_rtl::cat("arg", i) : snake(nkey);
                auto [rs, w2] = fresh_name(w, base_);
                call_then(start_out_ty_of(lx_2_4, peel(or_(index(ptys_3_4, i), check_types::Ty(check_types::Ty::TyErr{})))), [=](OutTy out_ty_of_186329) {
                return ({
                    auto t = out_ty_of_186329;
                    auto w3 = ({
                        Wx this_ = w2;
                        this_.fields = prelude::push(this_.fields, std::tuple{rs, t, Text("a parameter")});
                        this_.inits = prelude::push(this_.inits, std::tuple{rs, Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{rs}))})});
                        this_;
                    });
                    auto [be2, me2] = bind_plain(be, me, nkey, rs, t);
                    (prism_rtl::finished(std::tuple{prelude::push(acc, std::tuple{rs, t}), w3, be2, me2}));
                });
            });
            });
            });
        }));
        });
    }));
    })));
    auto wx2 = block_into(wx1, benv, menv, body);
    auto wx3 = is_root ? root_result(wx2) : wx2;
    return finish_node(wx3, qk, ps, false);
}


prism_rtl::Turn<NodeDef> NodeDefOf::cycle() const {
    const auto& lx = this->lx;
    const auto& qk = this->qk;
    const auto& params = this->params;
    const auto& body = this->body;
    const auto& sc = this->sc;
    const auto& is_root = this->is_root;
    auto name = camel(check_types::bare_name(qk));
    auto ptys = ({
        __label__ _done;
        prism_rtl::Slot<Array<check_types::Ty>> _v;
        auto&& _m = sc.ty;
        if (prism_rtl::is<check_types::Ty::TyFn>(_m)) {
            auto&& ps = prism_rtl::as<check_types::Ty::TyFn>(_m).a1;
            _v.set(ps);
            goto _done;
        }
        {
            _v.set(Array<check_types::Ty>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto wx0 = new_wx(lx, name, Array<std::tuple<Text, OutTy, Text>>{}, Array<std::tuple<Text, Ex>>{}, Array<std::tuple<Text, Ex>>{}, Array<MethDef>{}, Map<Text, Array<Read>>{}, node_hooks(), Nat(0u), std::optional<Text>{});
    auto body_1 = body;
    auto is_root_2 = is_root;
    auto lx_3 = lx;
    auto params_4 = params;
    auto qk_5 = qk;
    return call_value(fold_job(check_errors::range0(len(params_4)), std::tuple{Array<std::tuple<Text, OutTy>>{}, wx0, empty_env(), empty_env()}, ({
        auto params_4_6 = params_4;
        auto lx_3_6 = lx_3;
        auto ptys_6 = ptys;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, OutTy>>, Wx, Env, Env>>(std::tuple<std::tuple<Array<std::tuple<Text, OutTy>>, Wx, Env, Env>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<std::tuple<Text, OutTy>>, Wx, Env, Env>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto params_4_6_7 = params_4_6;
            auto lx_3_6_7 = lx_3_6;
            auto ptys_6_7 = ptys_6;
            entered(once_job([=]() {
            return ({
                auto [acc, w, be, me] = p0;
                auto i = p1;
                ({
                auto p_ = or_(index(params_4_6_7, i), dummy_pat());
                auto nkey = plain_binder(lx_3_6_7, p_);
                auto base_ = nkey == Text("") ? prism_rtl::cat("arg", i) : snake(nkey);
                auto [rs, w2] = fresh_name(w, base_);
                call_then(start_out_ty_of(lx_3_6_7, peel(or_(index(ptys_6_7, i), check_types::Ty(check_types::Ty::TyErr{})))), [=](OutTy out_ty_of_186329) {
                return ({
                    auto t = out_ty_of_186329;
                    auto w3 = ({
                        Wx this_ = w2;
                        this_.fields = prelude::push(this_.fields, std::tuple{rs, t, Text("a parameter")});
                        this_.inits = prelude::push(this_.inits, std::tuple{rs, Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{rs}))})});
                        this_;
                    });
                    auto [be2, me2] = bind_plain(be, me, nkey, rs, t);
                    (prism_rtl::finished(std::tuple{prelude::push(acc, std::tuple{rs, t}), w3, be2, me2}));
                });
            });
            });
            });
        }));
        });
    }));
    })), [=](std::tuple<Array<std::tuple<Text, OutTy>>, Wx, Env, Env> fold_186046) {
        return ({
            auto [ps, wx1, benv, menv] = fold_186046;
            call_then(start_block_into(wx1, benv, menv, body_1), [=](Wx block_into_186647) {
            return ({
                auto wx2 = block_into_186647;
                auto wx3 = is_root_2 ? root_result(wx2) : wx2;
                (prism_rtl::more(prism_rtl::rc(FinishNode(wx3, qk_5, ps, false))));
            });
        });
        });
    });
}


/// `Start NodeDefOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<NodeDef> start_node_def_of(Lx lx, Text qk, Array<ast::Pattern_> params, ast::Block body, check_types::Scheme sc, bool is_root) {
    return std::make_shared<NodeDefOf>(lx, qk, params, body, sc, is_root);
}


/// RootResult: fn Wx -> Wx
Wx root_result(const Wx& wx) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Wx> _v;
        auto&& _m = wx->result;
        if (prism_rtl::is<Wres::WrEv>(_m)) {
            auto&& r = prism_rtl::as<Wres::WrEv>(_m).a0;
            _v.set(connect(wx, r, Sk(Sk::SkResult{})));
            goto _done;
        }
        if (prism_rtl::is<Wres::WrDyn>(_m)) {
            auto&& x = prism_rtl::as<Wres::WrDyn>(_m).a0;
            auto&& rds = prism_rtl::as<Wres::WrDyn>(_m).a1;
            auto&& t = prism_rtl::as<Wres::WrDyn>(_m).a2;
            _v.set(({
                Wx this_ = wx;
                this_.root_dyn = std::optional(std::tuple{x, rds, t});
                this_.getters = prelude::push(this_.getters, MethDef{.name = Text("result_value"), .recv = Recv(Recv::RecvRef{}), .params = Array<std::tuple<Text, OutTy>>{}, .cx_ = CxArg(CxArg::CxRef{}), .ret = OutTy(OutTy::OutPod{}), .body = Array<Do>{}, .tail = Ex(Ex::XMethod{prism_rtl::rc(x), Text("to_pod"), Array<Ex>{}}), .doc = Text("The root's dynamic result, pulled after the tick.")});
                this_.fields = prelude::push(this_.fields, std::tuple{Text("result_last"), OutTy(OutTy::OutCell{prism_rtl::rc(OutTy(OutTy::OutOpt{prism_rtl::rc(OutTy(OutTy::OutPod{}))}))}), Text("the result the World last heard")});
                this_.moves = prelude::push(this_.moves, std::tuple{Text("result_last"), Ex(Ex::XCall{Text("RefCell::new"), Array(std::vector{Ex(Ex::XNone{})})})});
                this_.build = prelude::push(this_.build, Do(Do::DoScope{result_told(Ex(Ex::XVar{Text("node")}))}));
                this_;
            }));
            goto _done;
        }
        if (prism_rtl::is<Wres::WrPlain>(_m)) {
            auto&& x = prism_rtl::as<Wres::WrPlain>(_m).a0;
            _v.set(({
                Wx this_ = wx;
                this_.build = prelude::push(this_.build, Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XCx{})), Text("result"), Array(std::vector{Ex(Ex::XCtor{Text("Outcome::Value"), Array(std::vector{Ex(Ex::XMethod{prism_rtl::rc(x), Text("to_pod"), Array<Ex>{}})})})})})}));
                this_;
            }));
            goto _done;
        }
        {
            _v.set(wx);
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// BlockInto: unbounded fn Wx, Env, Env, Block -> Wx
Wx block_into(const Wx& wx, const Env& benv, const Env& menv, const ast::Block& b) {
    auto [wx1, be1, me1] = run_to_end(fold_job(b.stmts, std::tuple{wx, benv, menv}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Wx, Env, Env>>(std::tuple<std::tuple<Wx, Env, Env>, ast::Stmt>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Wx, Env, Env>, ast::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto [w, be, me] = p0;
                auto s = p1;
                (prism_rtl::more(prism_rtl::rc(PreBind(w, be, me, s))));
            });
        }));
    }))));
    auto n = len(b.stmts);
    auto&& _wx2 = run_to_end(fold_job(check_errors::range0(n), std::tuple{wx1, be1, me1}, ({
        auto b_1 = b;
        auto n_2 = n;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Wx, Env, Env>>(std::tuple<std::tuple<Wx, Env, Env>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Wx, Env, Env>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto b_1_3 = b_1;
            auto n_2_3 = n_2;
            entered(once_job([=]() {
            return ({
                auto [w, be, me] = p0;
                auto i = p1;
                (prism_rtl::more(prism_rtl::rc(WidgetStmt(w, be, me, or_(index(b_1_3.stmts, i), dummy_stmt_l()), (i + Nat(1u)) == n_2_3))));
            });
        }));
        });
    }));
    })));
    auto&& wx2 = std::get<0>(_wx2);
    return wx2;
}

}  // namespace crate::lower
