// The module `Lower`, from `target/bootstrap/cpp-src/prismc/lower.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (docs/backend.md). Edit the Prism source, not this file.
#include "lower.hpp"
#include "ast.hpp"
#include "check_env.hpp"
#include "check_errors.hpp"
#include "check_types.hpp"
#include "lexer.hpp"
#include "typed.hpp"
#include "lower.generic.hpp"
#include "check_env.generic.hpp"
#include "lexer.generic.hpp"

namespace crate::lower {

prism_rtl::Turn<Ex> ClausesBody::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& clauses = this->clauses;
    const auto& names = this->names;
    const auto& ptys = this->ptys;
    const auto& body_fn = this->body_fn;
    const auto& label = this->label;
    const auto& t = this->t;
    auto body_fn_1 = body_fn;
    auto clauses_2 = clauses;
    auto env_3 = env;
    auto label_4 = label;
    auto lx_5 = lx;
    auto names_6 = names;
    auto ptys_7 = ptys;
    auto t_8 = t;
    return call_value(fold_job(check_errors::range0(len(names_6)), env_3, ({
        auto names_6_9 = names_6;
        auto lx_5_9 = lx_5;
        auto clauses_2_9 = clauses_2;
        auto ptys_7_9 = ptys_7;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Env>(std::tuple<Env, Nat>)>>(prism_rtl::rc([=](std::tuple<Env, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto names_6_9_9 = names_6_9;
            auto lx_5_9_9 = lx_5_9;
            auto clauses_2_9_9 = clauses_2_9;
            auto ptys_7_9_9 = ptys_7_9;
            entered(once_job([=]() {
            return ({
                auto en = p0;
                auto i = p1;
                ({
                auto [rs, matched] = or_(index(names_6_9_9, i), std::tuple{Text::lit(""), true});
                matched
                ? prism_rtl::finished(en)
                : call_then(start_out_ty_of(lx_5_9_9, peel(or_(index(ptys_7_9_9, i), check_types::Ty(check_types::Ty::TyErr{})))), [=](OutTy out_ty_of_142241) { return prism_rtl::finished(bind(en, plain_binder(lx_5_9_9, or_(index(or_(index(clauses_2_9_9, Nat(0u)), dummy_clause()).params, i), dummy_pat())), Bn(Bn::BnLocal{Ex(Ex::XVar{rs}), Holding(Holding::ByRef{}), out_ty_of_142241}))); });
            });
            });
        }));
        });
    })));
    })), [=](Env fold_141997) {
        return ({
            auto env1 = fold_141997;
            auto scrut_ix = filter(check_errors::range0(len(names_6)), [&](const Nat& i) {
                return ({
                    __label__ _done;
                    prism_rtl::Slot<bool> _v;
                    auto&& _m = index(names_6, i);
                    if (prism_rtl::is_some(_m) && std::get<1>(prism_rtl::some_of(_m))) {
                        _v.set(true);
                        goto _done;
                    }
                    {
                        _v.set(false);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
            });
            len(scrut_ix) == Nat(0u)
            ? ({
            auto c = or_(index(clauses_2, Nat(0u)), dummy_clause());
            body_fn_1(std::tuple{lx_5, env1, c.body})->cycle();
        })
            : ({
            auto scrut = ({
                __label__ _done;
                prism_rtl::Slot<Ex> _v;
                {
                    auto&& m142538_0 = scrut_ix;
                    if (m142538_0.size() == 1u) {
                        {
                            auto&& _c1 = index(m142538_0, Nat(0u));
                            if (prism_rtl::is_some(_c1)) {
                                auto&& i = prism_rtl::some_of(_c1);
                                _v.set(Ex(Ex::XVar{or_(index(each(names_6, [&](const std::tuple<Text, bool>& _p0) {
                                    auto&& n = std::get<0>(_p0);
                                    return n;
                                }), i), Text::lit("arg"))}));
                                goto _done;
                            }
                        }
                    }
                }
                {
                    _v.set(Ex(Ex::XTuple{each(scrut_ix, [&](const Nat& i) {
                        return Ex(Ex::XVar{or_(index(each(names_6, [&](const std::tuple<Text, bool>& _p0) {
                            auto&& n = std::get<0>(_p0);
                            return n;
                        }), i), Text::lit("arg"))});
                    })}));
                    goto _done;
                }
            _done:
                _v.take();
            });
            call_value(each_job(check_errors::range0(len(clauses_2)), ({
            auto clauses_2_9 = clauses_2;
            auto scrut_ix_9 = scrut_ix;
            auto lx_5_10 = lx_5;
            auto ptys_7_10 = ptys_7;
            auto label_4_10 = label_4;
            auto body_fn_1_10 = body_fn_1;
            auto env1_10 = env1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<XArm>(Nat)>>(prism_rtl::rc([=](Nat p0) {
            return ({
                auto clauses_2_9_11 = clauses_2_9;
                auto scrut_ix_9_11 = scrut_ix_9;
                auto lx_5_10_11 = lx_5_10;
                auto ptys_7_10_11 = ptys_7_10;
                auto label_4_10_11 = label_4_10;
                auto body_fn_1_10_11 = body_fn_1_10;
                auto env1_10_11 = env1_10;
                entered(once_job([=]() {
                return ({
                    auto ci = p0;
                    ({
                    auto c = or_(index(clauses_2_9_11, ci), dummy_clause());
                    call_value(each_job(scrut_ix_9_11, ({
                    auto lx_5_10_11_11 = lx_5_10_11;
                    auto c_11 = c;
                    auto ptys_7_10_11_12 = ptys_7_10_11;
                    auto label_4_10_11_12 = label_4_10_11;
                    auto ci_12 = ci;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<PatOut>(Nat)>>(prism_rtl::rc([=](Nat p0) {
                    return ({
                        auto lx_5_10_11_11_13 = lx_5_10_11_11;
                        auto c_11_13 = c_11;
                        auto ptys_7_10_11_12_13 = ptys_7_10_11_12;
                        auto label_4_10_11_12_13 = label_4_10_11_12;
                        auto ci_12_13 = ci_12;
                        entered(once_job([=]() {
                        return ({
                            auto i = p0;
                            (prism_rtl::more(prism_rtl::rc(RustPat(lx_5_10_11_11_13, or_(index(c_11_13.params, i), dummy_pat()), or_(index(ptys_7_10_11_12_13, i), check_types::Ty(check_types::Ty::TyErr{})), Holding(Holding::ByRef{}), prism_rtl::cat(label_4_10_11_12_13, ci_12_13, "_", i)))));
                        });
                    }));
                    });
                })));
                })), [=](Array<PatOut> each_142853) {
                    return ({
                        auto pos = each_142853;
                        auto pa = ({
                            __label__ _done;
                            prism_rtl::Slot<Pa> _v;
                            {
                                auto&& m142979_0 = pos;
                                if (m142979_0.size() == 1u) {
                                    {
                                        auto&& _c1 = index(m142979_0, Nat(0u));
                                        if (prism_rtl::is_some(_c1)) {
                                            auto&& o = prism_rtl::some_of(_c1);
                                            _v.set(o.pa);
                                            goto _done;
                                        }
                                    }
                                }
                            }
                            {
                                _v.set(Pa(Pa::PaTuple{each(pos, [&](const PatOut& o) { return o.pa; })}));
                                goto _done;
                            }
                        _done:
                            _v.take();
                        });
                        auto conds = fold(pos, Array<Cc>{}, [&](const Array<Cc>& acc, const PatOut& o) { return append(acc, o.conds); });
                        auto binds = fold(pos, Array<std::tuple<Text, Bn>>{}, [&](const Array<std::tuple<Text, Bn>>& acc, const PatOut& o) { return append(acc, o.binds); });
                        call_value(body_fn_1_10_11(std::tuple{lx_5_10_11, bind_all(env1_10_11, binds), c.body}), [=](Ex body_143259) { return prism_rtl::finished(XArm{.pat = pa, .conds = conds, .body = body_143259}); });
                    });
                });
                });
                });
            }));
            });
        })));
        })), [=](Array<XArm> each_142748) {
            return ({
                auto arms = each_142748;
                (prism_rtl::finished(own(arms_value(scrut, arms, prism_rtl::cat("'", label_4), t_8))));
            });
        });
        });
        });
    });
}


/// `Start ClausesBody, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Ex> start_clauses_body(Lx lx, Env env, Array<ast::FnClause> clauses, Array<std::tuple<Text, bool>> names, Array<check_types::Ty> ptys, prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Lx, Env, ast::FnBody>)> body_fn, Text label, OutTy t) {
    return prism_rtl::make_rc<ClausesBody>(lx, env, clauses, names, ptys, body_fn, label, t);
}


/// let dummyClause
ast::FnClause dummy_clause() {
    return ast::FnClause{.name = ast::DefName(ast::DefName::DefOp{Text::lit(""), ast::Range{.start = Nat(0u), .end = Nat(0u)}}), .params = Array<ast::Pattern_>{}, .body = ast::FnBody(ast::FnBody::BodyExpr{ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EError{})), .span = ast::Range{.start = Nat(0u), .end = Nat(0u)}}}), .span = ast::Range{.start = Nat(0u), .end = Nat(0u)}};
}


/// FnBodyValue: unbounded fn Lx, Env, FnBody -> Ex
Ex fn_body_value(const Lx& lx, const Env& env, const ast::FnBody& fn_body2) {
    if (prism_rtl::is<ast::FnBody::BodyExpr>(fn_body2)) {
        auto&& x = prism_rtl::as<ast::FnBody::BodyExpr>(fn_body2).a0;
        return own(value_of(lx, env, x));
    }
    if (prism_rtl::is<ast::FnBody::BodyBlock>(fn_body2)) {
        auto&& b = prism_rtl::as<ast::FnBody::BodyBlock>(fn_body2).a0;
        return own(block_value(lx, env, b));
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Ex> FnBodyValue::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& fn_body2 = this->fn_body2;
    return ({
        prism_rtl::is<ast::FnBody::BodyExpr>(fn_body2) ? ({
        auto&& x = prism_rtl::as<ast::FnBody::BodyExpr>(fn_body2).a0;
        ({
        auto env_1 = env;
        auto lx_2 = lx;
        auto x_3 = x;
        call_then(start_value_of(lx_2, env_1, x_3), [=](Vl value_of_143618) { return prism_rtl::finished(own(value_of_143618)); });
    });
    })
        : prism_rtl::is<ast::FnBody::BodyBlock>(fn_body2) ? ({
        auto&& b = prism_rtl::as<ast::FnBody::BodyBlock>(fn_body2).a0;
        ({
        auto b_1 = b;
        auto env_2 = env;
        auto lx_3 = lx;
        call_then(start_block_value(lx_3, env_2, b_1), [=](Vl block_value_143683) { return prism_rtl::finished(own(block_value_143683)); });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start FnBodyValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Ex> start_fn_body_value(Lx lx, Env env, ast::FnBody fn_body2) {
    return prism_rtl::make_rc<FnBodyValue>(lx, env, fn_body2);
}


/// FnDefOf: unbounded fn Lx, Text, [FnClause], Scheme -> FnDef
FnDef fn_def_of(const Lx& lx, const Text& qk, const Array<ast::FnClause>& clauses, const check_types::Scheme& sc) {
    auto [ptys0, res] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Array<check_types::Ty>, check_types::Ty>> _v;
        auto&& _m = sc.ty;
        if (prism_rtl::is<check_types::Ty::TyFn>(_m)) {
            auto&& ps = prism_rtl::as<check_types::Ty::TyFn>(_m).a1;
            auto&& r = prism_rtl::as<check_types::Ty::TyFn>(_m).a2;
            _v.set(std::tuple{ps, r});
            goto _done;
        }
        {
            auto&& other = _m;
            _v.set(std::tuple{Array<check_types::Ty>{}, other});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto ptys = has_blueprint(res)
        ? each(ptys0, [&](const check_types::Ty& p_) { return event_param(p_); })
        : ptys0;
    auto pts = run_to_end(each_job(ptys, ({
        auto lx_1 = lx;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<OutTy>(check_types::Ty)>>(prism_rtl::rc([=](check_types::Ty p0) {
        return ({
            auto lx_1_2 = lx_1;
            entered(once_job([=]() {
            return ({
                auto p_ = p0;
                (prism_rtl::more(prism_rtl::rc(OutTyOf(lx_1_2, peel(p_)))));
            });
        }));
        });
    })));
    })));
    auto names = param_names(lx, clauses, pts);
    auto body = clauses_body(lx, empty_env(), clauses, names, ptys, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Lx, Env, ast::FnBody>)>>(prism_rtl::rc([&](std::tuple<Lx, Env, ast::FnBody> _p0) {
        auto&& a0 = std::get<0>(_p0);
        auto&& a1 = std::get<1>(_p0);
        auto&& a2 = std::get<2>(_p0);
        return entered(start_fn_body_value(a0, a1, a2));
    })), Text::lit("c"), out_ty_of(lx, peel(res)));
    auto params = each(check_errors::range0(len(pts)), [&](const Nat& i) {
        return std::tuple{or_(index(each(names, [&](const std::tuple<Text, bool>& _p0) {
            auto&& n = std::get<0>(_p0);
            return n;
        }), i), Text::lit("arg")), OutTy(OutTy::OutRef{prism_rtl::rc(or_(index(pts, i), OutTy(OutTy::OutUnit{})))})};
    });
    auto ret = out_ty_of(lx, peel(res));
    auto used = fold(prelude::push(pts, ret), Array<Text>{}, [&](const Array<Text>& acc, const OutTy& t) { return check_types::union_texts(acc, ty_params_in(t)); });
    auto generics = filter(scheme_generics(lx, sc), [&](const std::tuple<Text, Array<Text>>& _p0) {
        auto&& g = std::get<0>(_p0);
        return check_types::has_text(used, g);
    });
    return FnDef{.name = or_(prelude::get(lx.rs_names, qk), snake(check_types::bare_name(qk))), .generics = generics, .params = params, .ret = ret, .body = body, .doc = signature_text(lx, qk), .public_ = true};
}


prism_rtl::Turn<FnDef> FnDefOf::cycle() const {
    const auto& lx = this->lx;
    const auto& qk = this->qk;
    const auto& clauses = this->clauses;
    const auto& sc = this->sc;
    auto [ptys0, res] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Array<check_types::Ty>, check_types::Ty>> _v;
        auto&& _m = sc.ty;
        if (prism_rtl::is<check_types::Ty::TyFn>(_m)) {
            auto&& ps = prism_rtl::as<check_types::Ty::TyFn>(_m).a1;
            auto&& r = prism_rtl::as<check_types::Ty::TyFn>(_m).a2;
            _v.set(std::tuple{ps, r});
            goto _done;
        }
        {
            auto&& other = _m;
            _v.set(std::tuple{Array<check_types::Ty>{}, other});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto ptys = has_blueprint(res)
        ? each(ptys0, [&](const check_types::Ty& p_) { return event_param(p_); })
        : ptys0;
    auto clauses_1 = clauses;
    auto lx_2 = lx;
    auto qk_3 = qk;
    auto sc_4 = sc;
    return call_value(each_job(ptys, ({
        auto lx_2_5 = lx_2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<OutTy>(check_types::Ty)>>(prism_rtl::rc([=](check_types::Ty p0) {
        return ({
            auto lx_2_5_5 = lx_2_5;
            entered(once_job([=]() {
            return ({
                auto p_ = p0;
                (prism_rtl::more(prism_rtl::rc(OutTyOf(lx_2_5_5, peel(p_)))));
            });
        }));
        });
    })));
    })), [=](Array<OutTy> each_144240) {
        return ({
            auto pts = each_144240;
            auto names = param_names(lx_2, clauses_1, pts);
            call_then(start_out_ty_of(lx_2, peel(res)), [=](OutTy out_ty_of_144403) {
            return call_then(start_clauses_body(lx_2, empty_env(), clauses_1, names, ptys, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Lx, Env, ast::FnBody>)>>(prism_rtl::rc([&](std::tuple<Lx, Env, ast::FnBody> _p0) {
                auto&& a0 = std::get<0>(_p0);
                auto&& a1 = std::get<1>(_p0);
                auto&& a2 = std::get<2>(_p0);
                return entered(start_fn_body_value(a0, a1, a2));
            })), Text::lit("c"), out_ty_of_144403), [=](Ex clauses_body_144336) {
                return ({
                    auto body = clauses_body_144336;
                    auto params = each(check_errors::range0(len(pts)), [&](const Nat& i) {
                        return std::tuple{or_(index(each(names, [&](const std::tuple<Text, bool>& _p0) {
                            auto&& n = std::get<0>(_p0);
                            return n;
                        }), i), Text::lit("arg")), OutTy(OutTy::OutRef{prism_rtl::rc(or_(index(pts, i), OutTy(OutTy::OutUnit{})))})};
                    });
                    call_then(start_out_ty_of(lx_2, peel(res)), [=](OutTy out_ty_of_144571) {
                    return ({
                        auto ret = out_ty_of_144571;
                        auto used = fold(prelude::push(pts, ret), Array<Text>{}, [&](const Array<Text>& acc, const OutTy& t) { return check_types::union_texts(acc, ty_params_in(t)); });
                        auto generics = filter(scheme_generics(lx_2, sc_4), [&](const std::tuple<Text, Array<Text>>& _p0) {
                            auto&& g = std::get<0>(_p0);
                            return check_types::has_text(used, g);
                        });
                        (prism_rtl::finished(FnDef{.name = or_(prelude::get(lx_2.rs_names, qk_3), snake(check_types::bare_name(qk_3))), .generics = generics, .params = params, .ret = ret, .body = body, .doc = signature_text(lx_2, qk_3), .public_ = true}));
                    });
                });
                });
            });
        });
        });
    });
}


/// `Start FnDefOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<FnDef> start_fn_def_of(Lx lx, Text qk, Array<ast::FnClause> clauses, check_types::Scheme sc) {
    return prism_rtl::make_rc<FnDefOf>(lx, qk, clauses, sc);
}


/// TyParamsIn: fn OutTy -> [Text]
Array<Text> ty_params_in(const OutTy& t) {
    if (prism_rtl::is<OutTy::OutGen>(t)) {
        auto&& n = prism_rtl::as<OutTy::OutGen>(t).a0;
        return Array(std::vector{n});
    }
    if (prism_rtl::is<OutTy::OutNamed>(t)) {
        auto&& ts = prism_rtl::as<OutTy::OutNamed>(t).a1;
        return fold(ts, Array<Text>{}, [&](const Array<Text>& acc, const OutTy& x) { return check_types::union_texts(acc, ty_params_in(x)); });
    }
    if (prism_rtl::is<OutTy::OutTuple>(t)) {
        auto&& ts = prism_rtl::as<OutTy::OutTuple>(t).a0;
        return fold(ts, Array<Text>{}, [&](const Array<Text>& acc, const OutTy& x) { return check_types::union_texts(acc, ty_params_in(x)); });
    }
    if (prism_rtl::is<OutTy::OutFn>(t)) {
        auto&& ts = prism_rtl::as<OutTy::OutFn>(t).a0;
        auto&& r = prism_rtl::as<OutTy::OutFn>(t).a1;
        return fold(ts, ty_params_in(r), [&](const Array<Text>& acc, const OutTy& x) { return check_types::union_texts(acc, ty_params_in(x)); });
    }
    if (prism_rtl::is<OutTy::OutJobFn>(t)) {
        auto&& a = prism_rtl::as<OutTy::OutJobFn>(t).a0;
        auto&& r = prism_rtl::as<OutTy::OutJobFn>(t).a1;
        return check_types::union_texts(ty_params_in(a), ty_params_in(r));
    }
    if (prism_rtl::is<OutTy::OutMap>(t)) {
        auto&& k = prism_rtl::as<OutTy::OutMap>(t).a0;
        auto&& v_ = prism_rtl::as<OutTy::OutMap>(t).a1;
        return check_types::union_texts(ty_params_in(k), ty_params_in(v_));
    }
    if (prism_rtl::is<OutTy::OutOpt>(t)) {
        auto&& x = prism_rtl::as<OutTy::OutOpt>(t).a0;
        return ty_params_in(x);
    }
    if (prism_rtl::is<OutTy::OutRes>(t)) {
        auto&& x = prism_rtl::as<OutTy::OutRes>(t).a0;
        return ty_params_in(x);
    }
    if (prism_rtl::is<OutTy::OutArray>(t)) {
        auto&& x = prism_rtl::as<OutTy::OutArray>(t).a0;
        return ty_params_in(x);
    }
    if (prism_rtl::is<OutTy::OutJob>(t)) {
        auto&& x = prism_rtl::as<OutTy::OutJob>(t).a0;
        return ty_params_in(x);
    }
    if (prism_rtl::is<OutTy::OutEvent>(t)) {
        auto&& x = prism_rtl::as<OutTy::OutEvent>(t).a0;
        return ty_params_in(x);
    }
    if (prism_rtl::is<OutTy::OutDyn>(t)) {
        auto&& x = prism_rtl::as<OutTy::OutDyn>(t).a0;
        return ty_params_in(x);
    }
    if (prism_rtl::is<OutTy::OutRc>(t)) {
        auto&& x = prism_rtl::as<OutTy::OutRc>(t).a0;
        return ty_params_in(x);
    }
    if (prism_rtl::is<OutTy::OutRef>(t)) {
        auto&& x = prism_rtl::as<OutTy::OutRef>(t).a0;
        return ty_params_in(x);
    }
    if (prism_rtl::is<OutTy::OutHold>(t)) {
        auto&& x = prism_rtl::as<OutTy::OutHold>(t).a0;
        return ty_params_in(x);
    }
    if (prism_rtl::is<OutTy::OutCell>(t)) {
        auto&& x = prism_rtl::as<OutTy::OutCell>(t).a0;
        return ty_params_in(x);
    }
    if (prism_rtl::is<OutTy::OutLive>(t)) {
        auto&& x = prism_rtl::as<OutTy::OutLive>(t).a0;
        return ty_params_in(x);
    }
    {
        return Array<Text>{};
    }
}


/// SignatureText: fn Lx, Text -> Text
Text signature_text(const Lx& lx, const Text& qk) {
    auto&& _m = prelude::get(lx.g.vals, qk);
    if (prism_rtl::is_some(_m)) {
        auto&& v_ = prism_rtl::some_of(_m);
        auto&& _m = index(lx.g.srcs, v_->file);
        if (prism_rtl::is_some(_m)) {
            auto&& src = prism_rtl::some_of(_m);
            return lexer::trim(check_errors::span_text(src, v_.span));
        }
        if (prism_rtl::is_none(_m)) {
            return check_types::bare_name(qk);
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is_none(_m)) {
        return check_types::bare_name(qk);
    }
    prism_rtl::unreachable("no arm matched");
}


/// DefinitionText: fn Lx, Text -> Text
Text definition_text(const Lx& lx, const Text& qk) {
    auto spans = fold(lx.g.defs, Array<std::tuple<Nat, ast::Range>>{}, [&](const Array<std::tuple<Nat, ast::Range>>& acc, const check_env::Def& d) { return d.qk == qk ? prelude::push(acc, std::tuple{d->file, d.span}) : acc; });
    auto sig = ({
        __label__ _done;
        prism_rtl::Slot<Array<std::tuple<Nat, ast::Range>>> _v;
        auto&& _m = prelude::get(lx.g.vals, qk);
        if (prism_rtl::is_some(_m)) {
            auto&& v_ = prism_rtl::some_of(_m);
            _v.set(v_.span.start < or_(index(each(spans, [&](const std::tuple<Nat, ast::Range>& _p0) {
                auto&& r = std::get<1>(_p0);
                return r.start;
            }), Nat(0u)), Nat(0u))
                ? Array(std::vector{std::tuple{v_->file, v_.span}})
                : Array<std::tuple<Nat, ast::Range>>{});
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Array<std::tuple<Nat, ast::Range>>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return lexer::join(each(append(sig, spans), [&](const std::tuple<Nat, ast::Range>& _p0) {
        auto&& f = std::get<0>(_p0);
        auto&& r = std::get<1>(_p0);
        return src_text(lx, f, r);
    }), Text::lit("\n"));
}


/// SrcText: fn Lx, Nat, Range -> Text
Text src_text(const Lx& lx, const Nat& f, const ast::Range& r) {
    auto&& _m = index(lx.g.srcs, f);
    if (prism_rtl::is_some(_m)) {
        auto&& src = prism_rtl::some_of(_m);
        return drop_trailing_comments(check_errors::span_text(src, r));
    }
    if (prism_rtl::is_none(_m)) {
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}


/// DropTrailingComments: fn Text -> Text
Text drop_trailing_comments(const Text& t) {
    auto lines = split(t, Text::lit("\n"));
    auto keep = fold(check_errors::range0(len(lines)), Nat(0u), [&](const Nat& k, const Nat& i) { return is_code_line(or_(index(lines, i), Text::lit(""))) ? i + Nat(1u) : k; });
    return lexer::trim_end(lexer::join(take(lines, keep), Text::lit("\n")));
}


/// IsCodeLine: fn Text -> Bool
bool is_code_line(const Text& l) {
    auto s = lexer::trim(l);
    return (s != Text::lit("")) && (!lexer::has_prefix(s, Text::lit("#")));
}


/// LetGetter: unbounded fn Lx, Text, LetDecl -> FnDef
FnDef let_getter(const Lx& lx, const Text& qk, const ast::LetDecl& l) {
    auto t = out_ty_of(lx, peel(type_at(lx, l->value.span)));
    auto v_ = value_of(lx, empty_env(), l->value);
    return FnDef{.name = or_(prelude::get(lx.rs_names, qk), snake(check_types::bare_name(qk))), .generics = Array<std::tuple<Text, Array<Text>>>{}, .params = Array<std::tuple<Text, OutTy>>{}, .ret = t, .body = own(v_), .doc = prism_rtl::cat("let ", check_types::bare_name(qk)), .public_ = true};
}


prism_rtl::Turn<FnDef> LetGetter::cycle() const {
    const auto& lx = this->lx;
    const auto& qk = this->qk;
    const auto& l = this->l;
    auto l_1 = l;
    auto lx_2 = lx;
    auto qk_3 = qk;
    return call_then(start_out_ty_of(lx_2, peel(type_at(lx_2, l_1->value.span))), [=](OutTy out_ty_of_147420) {
        return ({
            auto t = out_ty_of_147420;
            call_then(start_value_of(lx_2, empty_env(), l_1->value), [=](Vl value_of_147477) {
            return ({
                auto v_ = value_of_147477;
                (prism_rtl::finished(FnDef{.name = or_(prelude::get(lx_2.rs_names, qk_3), snake(check_types::bare_name(qk_3))), .generics = Array<std::tuple<Text, Array<Text>>>{}, .params = Array<std::tuple<Text, OutTy>>{}, .ret = t, .body = own(v_), .doc = prism_rtl::cat("let ", check_types::bare_name(qk_3)), .public_ = true}));
            });
        });
        });
    });
}


/// `Start LetGetter, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<FnDef> start_let_getter(Lx lx, Text qk, ast::LetDecl l) {
    return prism_rtl::make_rc<LetGetter>(lx, qk, l);
}


/// Tail: unbounded fn Lx, Env, Expr -> Ex
Ex tail(const Lx& lx, const Env& env, const ast::Expr& e) {
    auto&& _m = frame_call(lx, env, e, true);
    if (prism_rtl::is_some(_m)) {
        auto&& c = prism_rtl::some_of(_m);
        return frame(lx, env, c, rest_text(lx, e.span, c.span, e.span), ({
            auto lx_1 = lx;
            auto e_2 = e;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(Env)>>(prism_rtl::rc([=](Env p0) {
            return ({
                auto lx_1_3 = lx_1;
                auto e_2_3 = e_2;
                entered(once_job([=]() {
                return ({
                    auto env2 = p0;
                    (prism_rtl::more(prism_rtl::rc(Tail(lx_1_3, env2, e_2_3))));
                });
            }));
            });
        })));
        }));
    }
    if (prism_rtl::is_none(_m)) {
        return tail_here(lx, env, e);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Ex> Tail::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& e = this->e;
    auto e_1 = e;
    auto env_2 = env;
    auto lx_3 = lx;
    return call_then(start_frame_call(lx_3, env_2, e_1, true), [=](std::optional<ast::Expr> frame_call_148547) {
        return ({
            prism_rtl::is_some(frame_call_148547) ? ({
            auto&& c = prism_rtl::some_of(frame_call_148547);
            prism_rtl::more(prism_rtl::rc(Frame(lx_3, env_2, c, rest_text(lx_3, e_1.span, c.span, e_1.span), ({
            auto lx_3_4 = lx_3;
            auto e_1_4 = e_1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(Env)>>(prism_rtl::rc([=](Env p0) {
            return ({
                auto lx_3_4_4 = lx_3_4;
                auto e_1_4_4 = e_1_4;
                entered(once_job([=]() {
                return ({
                    auto env2 = p0;
                    (prism_rtl::more(prism_rtl::rc(Tail(lx_3_4_4, env2, e_1_4_4))));
                });
            }));
            });
        })));
        }))));
        })
            : prism_rtl::is_none(frame_call_148547) ? prism_rtl::more(prism_rtl::rc(TailHere(lx_3, env_2, e_1)))
            : throw prism_rtl::Panic("no arm matched");
        });
    });
}


/// `Start Tail, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Ex> start_tail(Lx lx, Env env, ast::Expr e) {
    return prism_rtl::make_rc<Tail>(lx, env, e);
}


/// TailHere: unbounded fn Lx, Env, Expr -> Ex
Ex tail_here(const Lx& lx, const Env& env, const ast::Expr& e) {
    auto&& _m = e.kind;
    if (prism_rtl::is<ast::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<ast::ExprKind::EGroup>(_m).a0;
        return tail(lx, env, x);
    }
    if (prism_rtl::is<ast::ExprKind::EUpdate>(_m)) {
        auto&& target = prism_rtl::as<ast::ExprKind::EUpdate>(_m).a0;
        auto&& b = prism_rtl::as<ast::ExprKind::EUpdate>(_m).a1;
        return has_top_while(lx, b)
            ? upd_tail(lx, env, target, b, e.span, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Env, Ex>)>>(prism_rtl::rc([=](std::tuple<Env, Ex> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return once_job([=]() {
                return ({
                    auto en = p0;
                    auto v_ = p1;
                    (prism_rtl::finished(Ex(Ex::XCtor{Text::lit("prism_rtl::Turn::Finished"), Array(std::vector{v_})})));
                });
            });
        })))
            : Ex(Ex::XCtor{Text::lit("prism_rtl::Turn::Finished"), Array(std::vector{own(value_of(lx, env, e))})});
    }
    if (prism_rtl::is<ast::ExprKind::EMatch>(_m)) {
        auto&& s = prism_rtl::as<ast::ExprKind::EMatch>(_m).a0;
        auto&& arms = prism_rtl::as<ast::ExprKind::EMatch>(_m).a1;
        return tail_match(lx, env, s, arms, e.span);
    }
    if (prism_rtl::is<ast::ExprKind::EIf>(_m) && prism_rtl::is_some(prism_rtl::as<ast::ExprKind::EIf>(_m).a2)) {
        auto&& m148765_3_0 = prism_rtl::as<ast::ExprKind::EIf>(_m).a0;
        auto&& then_b = prism_rtl::as<ast::ExprKind::EIf>(_m).a1;
        auto&& else_b = prism_rtl::some_of(prism_rtl::as<ast::ExprKind::EIf>(_m).a2);
        if (prism_rtl::is<ast::Cond::CondExpr>(m148765_3_0)) {
            auto&& c = prism_rtl::as<ast::Cond::CondExpr>(m148765_3_0).a0;
            return Ex(Ex::XIf{prism_rtl::rc(as_bool(value_of(lx, env, c))), prism_rtl::rc(tail_block(lx, env, then_b)), prism_rtl::rc(tail_block(lx, env, else_b))});
        }
    }
    if (prism_rtl::is<ast::ExprKind::ECall>(_m)) {
        auto&& callee = prism_rtl::as<ast::ExprKind::ECall>(_m).a0;
        auto&& args = prism_rtl::as<ast::ExprKind::ECall>(_m).a1;
        auto&& _m = tail_callee(lx, env, callee);
        if (prism_rtl::is_some(_m)) {
            auto&& qk = prism_rtl::some_of(_m);
            auto job = or_(prelude::get(lx.rs_names, qk), snake(check_types::bare_name(qk)));
            auto job_name = path_in(lx, owner_of(qk), camel(check_types::bare_name(qk)));
            auto&& _ptys = scheme_parts(lx, qk);
            auto&& ptys = std::get<0>(_ptys);
            auto fields = job_field_names(lx, qk);
            auto vals = named_args_owned(lx, env, qk, args);
            return enters_at_once(lx, qk, args)
                ? Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XCall{path_in(lx, owner_of(qk), prism_rtl::cat("start_", job)), vals})), Text::lit("cycle"), Array<Ex>{}})
                : is_color_poly(lx, qk)
                ? Ex(Ex::XCtor{Text::lit("prism_rtl::Turn::More"), Array(std::vector{Ex(Ex::XCall{path_in(lx, owner_of(qk), prism_rtl::cat("start_", job)), vals})})})
                : Ex(Ex::XCtor{Text::lit("prism_rtl::Turn::More"), Array(std::vector{Ex(Ex::XCall{Text::lit("Rc::new"), Array(std::vector{Ex(Ex::XRecord{job_name, each(check_errors::range0(len(vals)), [&](const Nat& i) { return std::tuple{or_(index(fields, i), Text::lit("arg")), or_(index(vals, i), Ex(Ex::XUnit{}))}; })})})})})});
        }
        if (prism_rtl::is_none(_m)) {
            auto&& _m = local_job_fn(lx, env, callee);
            if (prism_rtl::is_some(_m)) {
                auto&& f = prism_rtl::some_of(_m);
                return Ex(Ex::XMethod{prism_rtl::rc(start_call(f, start_args(lx, env, f, args))), Text::lit("cycle"), Array<Ex>{}});
            }
            if (prism_rtl::is_none(_m)) {
                auto&& _m = prelude_job_call(lx, env, e);
                if (prism_rtl::is_some(_m)) {
                    auto&& job = prism_rtl::some_of(_m);
                    return Ex(Ex::XMethod{prism_rtl::rc(job), Text::lit("cycle"), Array<Ex>{}});
                }
                if (prism_rtl::is_none(_m)) {
                    return Ex(Ex::XCtor{Text::lit("prism_rtl::Turn::Finished"), Array(std::vector{own(value_of(lx, env, e))})});
                }
                prism_rtl::unreachable("no arm matched");
            }
            prism_rtl::unreachable("no arm matched");
        }
        prism_rtl::unreachable("no arm matched");
    }
    {
        return Ex(Ex::XCtor{Text::lit("prism_rtl::Turn::Finished"), Array(std::vector{own(value_of(lx, env, e))})});
    }
}


prism_rtl::Turn<Ex> TailHere::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& e = this->e;
    return ({
        auto&& _m = e.kind;
        prism_rtl::is<ast::ExprKind::EGroup>(_m) ? ({
        auto&& x = prism_rtl::as<ast::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(Tail(lx, env, x)));
    })
        : prism_rtl::is<ast::ExprKind::EUpdate>(_m) ? ({
        auto&& target = prism_rtl::as<ast::ExprKind::EUpdate>(_m).a0;
        auto&& b = prism_rtl::as<ast::ExprKind::EUpdate>(_m).a1;
        has_top_while(lx, b)
        ? prism_rtl::more(prism_rtl::rc(UpdTail(lx, env, target, b, e.span, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Env, Ex>)>>(prism_rtl::rc([=](std::tuple<Env, Ex> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return once_job([=]() {
            return ({
                auto en = p0;
                auto v_ = p1;
                (prism_rtl::finished(Ex(Ex::XCtor{Text::lit("prism_rtl::Turn::Finished"), Array(std::vector{v_})})));
            });
        });
    })))))
        : ({
        auto e_1 = e;
        auto env_2 = env;
        auto lx_3 = lx;
        call_then(start_value_of(lx_3, env_2, e_1), [=](Vl value_of_149004) { return prism_rtl::finished(Ex(Ex::XCtor{Text::lit("prism_rtl::Turn::Finished"), Array(std::vector{own(value_of_149004)})})); });
    });
    })
        : prism_rtl::is<ast::ExprKind::EMatch>(_m) ? ({
        auto&& s = prism_rtl::as<ast::ExprKind::EMatch>(_m).a0;
        auto&& arms = prism_rtl::as<ast::ExprKind::EMatch>(_m).a1;
        prism_rtl::more(prism_rtl::rc(TailMatch(lx, env, s, arms, e.span)));
    })
        : prism_rtl::is<ast::ExprKind::EIf>(_m) && prism_rtl::is_some(prism_rtl::as<ast::ExprKind::EIf>(_m).a2) && ({
        auto&& m148765_3_0 = prism_rtl::as<ast::ExprKind::EIf>(_m).a0;
        auto&& then_b = prism_rtl::as<ast::ExprKind::EIf>(_m).a1;
        auto&& else_b = prism_rtl::some_of(prism_rtl::as<ast::ExprKind::EIf>(_m).a2);
        prism_rtl::is<ast::Cond::CondExpr>(m148765_3_0);
    }) ? ({
        auto&& m148765_3_0 = prism_rtl::as<ast::ExprKind::EIf>(_m).a0;
        auto&& then_b = prism_rtl::as<ast::ExprKind::EIf>(_m).a1;
        auto&& else_b = prism_rtl::some_of(prism_rtl::as<ast::ExprKind::EIf>(_m).a2);
        auto&& c = prism_rtl::as<ast::Cond::CondExpr>(m148765_3_0).a0;
        ({
        auto c_1 = c;
        auto else_b_2 = else_b;
        auto env_3 = env;
        auto lx_4 = lx;
        auto then_b_5 = then_b;
        call_then(start_value_of(lx_4, env_3, c_1), [=](Vl value_of_149134) { return call_then(start_tail_block(lx_4, env_3, then_b_5), [=](Ex tail_block_149157) { return call_then(start_tail_block(lx_4, env_3, else_b_2), [=](Ex tail_block_149185) { return prism_rtl::finished(Ex(Ex::XIf{prism_rtl::rc(as_bool(value_of_149134)), prism_rtl::rc(tail_block_149157), prism_rtl::rc(tail_block_149185)})); }); }); });
    });
    })
        : prism_rtl::is<ast::ExprKind::ECall>(_m) ? ({
        auto&& callee = prism_rtl::as<ast::ExprKind::ECall>(_m).a0;
        auto&& args = prism_rtl::as<ast::ExprKind::ECall>(_m).a1;
        ({
        auto&& _m = tail_callee(lx, env, callee);
        prism_rtl::is_some(_m) ? ({
        auto&& qk = prism_rtl::some_of(_m);
        ({
        auto job = or_(prelude::get(lx.rs_names, qk), snake(check_types::bare_name(qk)));
        auto job_name = path_in(lx, owner_of(qk), camel(check_types::bare_name(qk)));
        auto&& _ptys = scheme_parts(lx, qk);
        auto&& ptys = std::get<0>(_ptys);
        auto args_1 = args;
        auto env_2 = env;
        auto lx_3 = lx;
        call_then(start_job_field_names(lx_3, qk), [=](Array<Text> job_field_names_149515) {
        return ({
            auto fields = job_field_names_149515;
            call_then(start_named_args_owned(lx_3, env_2, qk, args_1), [=](Array<Ex> named_args_owned_149559) {
            return ({
                auto vals = named_args_owned_149559;
                enters_at_once(lx_3, qk, args_1)
                ? prism_rtl::finished(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XCall{path_in(lx_3, owner_of(qk), prism_rtl::cat("start_", job)), vals})), Text::lit("cycle"), Array<Ex>{}}))
                : is_color_poly(lx_3, qk)
                ? prism_rtl::finished(Ex(Ex::XCtor{Text::lit("prism_rtl::Turn::More"), Array(std::vector{Ex(Ex::XCall{path_in(lx_3, owner_of(qk), prism_rtl::cat("start_", job)), vals})})}))
                : prism_rtl::finished(Ex(Ex::XCtor{Text::lit("prism_rtl::Turn::More"), Array(std::vector{Ex(Ex::XCall{Text::lit("Rc::new"), Array(std::vector{Ex(Ex::XRecord{job_name, each(check_errors::range0(len(vals)), [&](const Nat& i) { return std::tuple{or_(index(fields, i), Text::lit("arg")), or_(index(vals, i), Ex(Ex::XUnit{}))}; })})})})})}));
            });
        });
        });
    });
    });
    })
        : prism_rtl::is_none(_m) ? ({
        auto args_1 = args;
        auto callee_2 = callee;
        auto e_3 = e;
        auto env_4 = env;
        auto lx_5 = lx;
        call_then(start_local_job_fn(lx_5, env_4, callee_2), [=](std::optional<Vl> local_job_fn_150039) {
        return ({
            prism_rtl::is_some(local_job_fn_150039) ? ({
            auto&& f = prism_rtl::some_of(local_job_fn_150039);
            call_then(start_start_args(lx_5, env_4, f, args_1), [=](Array<Ex> start_args_150108) { return prism_rtl::finished(Ex(Ex::XMethod{prism_rtl::rc(start_call(f, start_args_150108)), Text::lit("cycle"), Array<Ex>{}})); });
        })
            : prism_rtl::is_none(local_job_fn_150039) ? call_then(start_prelude_job_call(lx_5, env_4, e_3), [=](std::optional<Ex> prelude_job_call_150175) {
            return ({
                prism_rtl::is_some(prelude_job_call_150175) ? ({
                auto&& job = prism_rtl::some_of(prelude_job_call_150175);
                prism_rtl::finished(Ex(Ex::XMethod{prism_rtl::rc(job), Text::lit("cycle"), Array<Ex>{}}));
            })
                : prism_rtl::is_none(prelude_job_call_150175) ? call_then(start_value_of(lx_5, env_4, e_3), [=](Vl value_of_150316) { return prism_rtl::finished(Ex(Ex::XCtor{Text::lit("prism_rtl::Turn::Finished"), Array(std::vector{own(value_of_150316)})})); })
                : throw prism_rtl::Panic("no arm matched");
            });
        })
            : throw prism_rtl::Panic("no arm matched");
        });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : ({
        auto e_1 = e;
        auto env_2 = env;
        auto lx_3 = lx;
        call_then(start_value_of(lx_3, env_2, e_1), [=](Vl value_of_150395) { return prism_rtl::finished(Ex(Ex::XCtor{Text::lit("prism_rtl::Turn::Finished"), Array(std::vector{own(value_of_150395)})})); });
    });
    });
}


/// `Start TailHere, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Ex> start_tail_here(Lx lx, Env env, ast::Expr e) {
    return prism_rtl::make_rc<TailHere>(lx, env, e);
}


/// TailBlock: unbounded fn Lx, Env, Block -> Ex
Ex tail_block(const Lx& lx, const Env& env, const ast::Block& b) {
    return tail_from(lx, env, b, Nat(0u));
}


prism_rtl::Turn<Ex> TailBlock::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& b = this->b;
    return prism_rtl::more(prism_rtl::rc(TailFrom(lx, env, b, Nat(0u))));
}


/// `Start TailBlock, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Ex> start_tail_block(Lx lx, Env env, ast::Block b) {
    return prism_rtl::make_rc<TailBlock>(lx, env, b);
}


/// TailFrom: unbounded fn Lx, Env, Block, Nat -> Ex
Ex tail_from(const Lx& lx, const Env& env, const ast::Block& b, const Nat& i) {
    auto s = or_(index(b.stmts, i), dummy_stmt_l());
    return (i + Nat(1u)) >= len(b.stmts)
        ? ({
        __label__ _done;
        prism_rtl::Slot<Ex> _v;
        auto&& _m = s.kind;
        if (prism_rtl::is<ast::StmtKind::SExpr>(_m)) {
            auto&& x = prism_rtl::as<ast::StmtKind::SExpr>(_m).a0;
            _v.set(tail(lx, env, x));
            goto _done;
        }
        {
            _v.set(Ex(Ex::XCtor{Text::lit("prism_rtl::Turn::Finished"), Array(std::vector{Ex(Ex::XUnit{})})}));
            goto _done;
        }
    _done:
        _v.take();
    })
        : ({
        auto found_opt = ({
            __label__ _done;
            prism_rtl::Slot<std::optional<ast::Expr>> _v;
            auto&& _m = s.kind;
            if (prism_rtl::is<ast::StmtKind::SLet>(_m)) {
                auto&& x = prism_rtl::as<ast::StmtKind::SLet>(_m).a2;
                _v.set(frame_call(lx, env, x, false));
                goto _done;
            }
            if (prism_rtl::is<ast::StmtKind::SExpr>(_m)) {
                auto&& x = prism_rtl::as<ast::StmtKind::SExpr>(_m).a0;
                _v.set(frame_call(lx, env, x, false));
                goto _done;
            }
            {
                _v.set(std::optional<ast::Expr>{});
                goto _done;
            }
        _done:
            _v.take();
        });
        auto looping_opt = ({
            __label__ _done;
            prism_rtl::Slot<std::optional<std::tuple<ast::Pattern_, ast::Expr, ast::Block, ast::Expr>>> _v;
            auto&& _m = s.kind;
            if (prism_rtl::is<ast::StmtKind::SLet>(_m)) {
                auto&& p_ = prism_rtl::as<ast::StmtKind::SLet>(_m).a0;
                auto&& x = prism_rtl::as<ast::StmtKind::SLet>(_m).a2;
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<std::optional<std::tuple<ast::Pattern_, ast::Expr, ast::Block, ast::Expr>>> _v;
                    auto&& _m = x.kind;
                    if (prism_rtl::is<ast::ExprKind::EUpdate>(_m)) {
                        auto&& target = prism_rtl::as<ast::ExprKind::EUpdate>(_m).a0;
                        auto&& ub = prism_rtl::as<ast::ExprKind::EUpdate>(_m).a1;
                        _v.set(has_top_while(lx, ub)
                            ? std::optional(std::tuple{p_, target, ub, x})
                            : std::optional<std::tuple<ast::Pattern_, ast::Expr, ast::Block, ast::Expr>>{});
                        goto _done;
                    }
                    {
                        _v.set(std::optional<std::tuple<ast::Pattern_, ast::Expr, ast::Block, ast::Expr>>{});
                        goto _done;
                    }
                _done:
                    _v.take();
                }));
                goto _done;
            }
            {
                _v.set(std::optional<std::tuple<ast::Pattern_, ast::Expr, ast::Block, ast::Expr>>{});
                goto _done;
            }
        _done:
            _v.take();
        });
        ({
        __label__ _done;
        prism_rtl::Slot<Ex> _v;
        if (prism_rtl::is_some(looping_opt)) {
            auto&& p_ = std::get<0>(prism_rtl::some_of(looping_opt));
            auto&& target = std::get<1>(prism_rtl::some_of(looping_opt));
            auto&& ub = std::get<2>(prism_rtl::some_of(looping_opt));
            auto&& x = std::get<3>(prism_rtl::some_of(looping_opt));
            _v.set(upd_tail(lx, env, target, ub, b.span, ({
                auto lx_1 = lx;
                auto p__2 = p_;
                auto x_3 = x;
                auto s_4 = s;
                auto b_5 = b;
                auto i_6 = i;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Env, Ex>)>>(prism_rtl::rc([=](std::tuple<Env, Ex> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto lx_1_7 = lx_1;
                    auto p__2_7 = p__2;
                    auto x_3_7 = x_3;
                    auto s_4_7 = s_4;
                    auto b_5_7 = b_5;
                    auto i_6_7 = i_6;
                    entered(once_job([=]() {
                    return ({
                        auto en = p0;
                        auto v_ = p1;
                        call_then(start_rust_pat(lx_1_7, p__2_7, type_at(lx_1_7, x_3_7.span), Holding(Holding::Owned{}), prism_rtl::cat("l", s_4_7.span.start)), [=](PatOut rust_pat_151518) {
                        return ({
                            auto po = rust_pat_151518;
                            call_then(start_tail_from(lx_1_7, bind_all(en, po.binds), b_5_7, i_6_7 + Nat(1u)), [=](Ex tail_from_151610) {
                            return ({
                                auto rest = tail_from_151610;
                                (prism_rtl::finished(prepend(Array(std::vector{Do(Do::DoLet{po.pa, v_})}), rest)));
                            });
                        });
                        });
                    });
                    });
                }));
                });
            })));
            })));
            goto _done;
        }
        if (prism_rtl::is_none(looping_opt)) {
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<Ex> _v;
                if (prism_rtl::is_some(found_opt)) {
                    auto&& c = prism_rtl::some_of(found_opt);
                    _v.set(frame(lx, env, c, rest_text(lx, s.span, c.span, b.span), ({
                        auto lx_1 = lx;
                        auto b_2 = b;
                        auto i_3 = i;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(Env)>>(prism_rtl::rc([=](Env p0) {
                        return ({
                            auto lx_1_4 = lx_1;
                            auto b_2_4 = b_2;
                            auto i_3_4 = i_3;
                            entered(once_job([=]() {
                            return ({
                                auto env2 = p0;
                                (prism_rtl::more(prism_rtl::rc(TailFrom(lx_1_4, env2, b_2_4, i_3_4))));
                            });
                        }));
                        });
                    })));
                    })));
                    goto _done;
                }
                if (prism_rtl::is_none(found_opt)) {
                    _v.set(({
                        auto [dos, env2] = block_stmt(lx, env, s);
                        ({
                        __label__ _done;
                        prism_rtl::Slot<Ex> _v;
                        auto&& _m = tail_from(lx, env2, b, i + Nat(1u));
                        if (prism_rtl::is<Ex::XBlock>(_m)) {
                            auto&& more = prism_rtl::as<Ex::XBlock>(_m).a0;
                            auto&& last = prism_rtl::as<Ex::XBlock>(_m).a1;
                            _v.set(Ex(Ex::XBlock{append(dos, more), prism_rtl::rc(last)}));
                            goto _done;
                        }
                        {
                            auto&& last = _m;
                            _v.set(len(dos) == Nat(0u) ? last : Ex(Ex::XBlock{dos, prism_rtl::rc(last)}));
                            goto _done;
                        }
                    _done:
                        _v.take();
                    });
                    }));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    });
}


prism_rtl::Turn<Ex> TailFrom::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& b = this->b;
    const auto& i = this->i;
    auto s = or_(index(b.stmts, i), dummy_stmt_l());
    return (i + Nat(1u)) >= len(b.stmts)
        ? ({
        auto&& _m = s.kind;
        prism_rtl::is<ast::StmtKind::SExpr>(_m) ? ({
        auto&& x = prism_rtl::as<ast::StmtKind::SExpr>(_m).a0;
        prism_rtl::more(prism_rtl::rc(Tail(lx, env, x)));
    })
        : prism_rtl::finished(Ex(Ex::XCtor{Text::lit("prism_rtl::Turn::Finished"), Array(std::vector{Ex(Ex::XUnit{})})}));
    })
        : ({
        auto found_opt = ({
            __label__ _done;
            prism_rtl::Slot<std::optional<ast::Expr>> _v;
            auto&& _m = s.kind;
            if (prism_rtl::is<ast::StmtKind::SLet>(_m)) {
                auto&& x = prism_rtl::as<ast::StmtKind::SLet>(_m).a2;
                _v.set(frame_call(lx, env, x, false));
                goto _done;
            }
            if (prism_rtl::is<ast::StmtKind::SExpr>(_m)) {
                auto&& x = prism_rtl::as<ast::StmtKind::SExpr>(_m).a0;
                _v.set(frame_call(lx, env, x, false));
                goto _done;
            }
            {
                _v.set(std::optional<ast::Expr>{});
                goto _done;
            }
        _done:
            _v.take();
        });
        auto looping_opt = ({
            __label__ _done;
            prism_rtl::Slot<std::optional<std::tuple<ast::Pattern_, ast::Expr, ast::Block, ast::Expr>>> _v;
            auto&& _m = s.kind;
            if (prism_rtl::is<ast::StmtKind::SLet>(_m)) {
                auto&& p_ = prism_rtl::as<ast::StmtKind::SLet>(_m).a0;
                auto&& x = prism_rtl::as<ast::StmtKind::SLet>(_m).a2;
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<std::optional<std::tuple<ast::Pattern_, ast::Expr, ast::Block, ast::Expr>>> _v;
                    auto&& _m = x.kind;
                    if (prism_rtl::is<ast::ExprKind::EUpdate>(_m)) {
                        auto&& target = prism_rtl::as<ast::ExprKind::EUpdate>(_m).a0;
                        auto&& ub = prism_rtl::as<ast::ExprKind::EUpdate>(_m).a1;
                        _v.set(has_top_while(lx, ub)
                            ? std::optional(std::tuple{p_, target, ub, x})
                            : std::optional<std::tuple<ast::Pattern_, ast::Expr, ast::Block, ast::Expr>>{});
                        goto _done;
                    }
                    {
                        _v.set(std::optional<std::tuple<ast::Pattern_, ast::Expr, ast::Block, ast::Expr>>{});
                        goto _done;
                    }
                _done:
                    _v.take();
                }));
                goto _done;
            }
            {
                _v.set(std::optional<std::tuple<ast::Pattern_, ast::Expr, ast::Block, ast::Expr>>{});
                goto _done;
            }
        _done:
            _v.take();
        });
        ({
        prism_rtl::is_some(looping_opt) ? ({
        auto&& p_ = std::get<0>(prism_rtl::some_of(looping_opt));
        auto&& target = std::get<1>(prism_rtl::some_of(looping_opt));
        auto&& ub = std::get<2>(prism_rtl::some_of(looping_opt));
        auto&& x = std::get<3>(prism_rtl::some_of(looping_opt));
        prism_rtl::more(prism_rtl::rc(UpdTail(lx, env, target, ub, b.span, ({
        auto lx_1 = lx;
        auto p__2 = p_;
        auto x_3 = x;
        auto s_4 = s;
        auto b_5 = b;
        auto i_6 = i;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Env, Ex>)>>(prism_rtl::rc([=](std::tuple<Env, Ex> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_1_7 = lx_1;
            auto p__2_7 = p__2;
            auto x_3_7 = x_3;
            auto s_4_7 = s_4;
            auto b_5_7 = b_5;
            auto i_6_7 = i_6;
            entered(once_job([=]() {
            return ({
                auto en = p0;
                auto v_ = p1;
                call_then(start_rust_pat(lx_1_7, p__2_7, type_at(lx_1_7, x_3_7.span), Holding(Holding::Owned{}), prism_rtl::cat("l", s_4_7.span.start)), [=](PatOut rust_pat_151518) {
                return ({
                    auto po = rust_pat_151518;
                    call_then(start_tail_from(lx_1_7, bind_all(en, po.binds), b_5_7, i_6_7 + Nat(1u)), [=](Ex tail_from_151610) {
                    return ({
                        auto rest = tail_from_151610;
                        (prism_rtl::finished(prepend(Array(std::vector{Do(Do::DoLet{po.pa, v_})}), rest)));
                    });
                });
                });
            });
            });
        }));
        });
    })));
    }))));
    })
        : prism_rtl::is_none(looping_opt) ? ({
        prism_rtl::is_some(found_opt) ? ({
        auto&& c = prism_rtl::some_of(found_opt);
        prism_rtl::more(prism_rtl::rc(Frame(lx, env, c, rest_text(lx, s.span, c.span, b.span), ({
        auto lx_1 = lx;
        auto b_2 = b;
        auto i_3 = i;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(Env)>>(prism_rtl::rc([=](Env p0) {
        return ({
            auto lx_1_4 = lx_1;
            auto b_2_4 = b_2;
            auto i_3_4 = i_3;
            entered(once_job([=]() {
            return ({
                auto env2 = p0;
                (prism_rtl::more(prism_rtl::rc(TailFrom(lx_1_4, env2, b_2_4, i_3_4))));
            });
        }));
        });
    })));
    }))));
    })
        : prism_rtl::is_none(found_opt) ? ({
        auto b_1 = b;
        auto env_2 = env;
        auto i_3 = i;
        auto lx_4 = lx;
        call_then(start_block_stmt(lx_4, env_2, s), [=](std::tuple<Array<Do>, Env> block_stmt_151913) {
        return ({
            auto [dos, env2] = block_stmt_151913;
            call_then(start_tail_from(lx_4, env2, b_1, i_3 + Nat(1u)), [=](Ex tail_from_151960) {
            return ({
                prism_rtl::is<Ex::XBlock>(tail_from_151960) ? ({
                auto&& more = prism_rtl::as<Ex::XBlock>(tail_from_151960).a0;
                auto&& last = prism_rtl::as<Ex::XBlock>(tail_from_151960).a1;
                prism_rtl::finished(Ex(Ex::XBlock{append(dos, more), prism_rtl::rc(last)}));
            })
                : ({
                auto&& last = tail_from_151960;
                len(dos) == Nat(0u)
                ? prism_rtl::finished(last)
                : prism_rtl::finished(Ex(Ex::XBlock{dos, prism_rtl::rc(last)}));
            });
            });
        });
        });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    });
}


/// `Start TailFrom, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Ex> start_tail_from(Lx lx, Env env, ast::Block b, Nat i) {
    return prism_rtl::make_rc<TailFrom>(lx, env, b, i);
}


/// HasTopWhile: fn Lx, Block -> Bool
bool has_top_while(const Lx& lx, const ast::Block& b) {
    return fold(b.stmts, false, [&](const bool& f, const ast::Stmt& st) { return (f || is_cycle_while(lx, st)) || holds_cycle_while(lx, st); });
}


/// IsCycleWhile: fn Lx, Stmt -> Bool
bool is_cycle_while(const Lx& lx, const ast::Stmt& st) {
    auto&& _m = st.kind;
    if (prism_rtl::is<ast::StmtKind::SWhile>(_m)) {
        return check_env::has_key(lx.unshrunk, place_key(lx, st.span));
    }
    {
        return false;
    }
}


/// ElseHasTopWhile: fn Lx, ?Block -> Bool
bool else_has_top_while(const Lx& lx, const std::optional<ast::Block>& opt1) {
    if (prism_rtl::is_some(opt1)) {
        auto&& b = prism_rtl::some_of(opt1);
        return has_top_while(lx, b);
    }
    if (prism_rtl::is_none(opt1)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// HoldsCycleWhile: fn Lx, Stmt -> Bool
bool holds_cycle_while(const Lx& lx, const ast::Stmt& st) {
    auto&& _m = st.kind;
    if (prism_rtl::is<ast::StmtKind::SWhile>(_m)) {
        auto&& wb = prism_rtl::as<ast::StmtKind::SWhile>(_m).a1;
        return has_top_while(lx, wb);
    }
    if (prism_rtl::is<ast::StmtKind::SExpr>(_m)) {
        auto&& x = prism_rtl::as<ast::StmtKind::SExpr>(_m).a0;
        auto&& _m = x.kind;
        if (prism_rtl::is<ast::ExprKind::EIf>(_m)) {
            auto&& then_b = prism_rtl::as<ast::ExprKind::EIf>(_m).a1;
            auto&& else_b_opt = prism_rtl::as<ast::ExprKind::EIf>(_m).a2;
            return has_top_while(lx, then_b) || else_has_top_while(lx, else_b_opt);
        }
        if (prism_rtl::is<ast::ExprKind::EMatch>(_m)) {
            auto&& arms = prism_rtl::as<ast::ExprKind::EMatch>(_m).a1;
            return fold(arms, false, [&](const bool& f, const ast::Arm& a) { return f || has_top_while(lx, a.body); });
        }
        if (prism_rtl::is<ast::ExprKind::EFor>(_m)) {
            auto&& fb = prism_rtl::as<ast::ExprKind::EFor>(_m).a2;
            return has_top_while(lx, fb);
        }
        {
            return false;
        }
    }
    {
        return false;
    }
}


/// UpdTail: unbounded fn Lx, Env, Expr, Block, Range, (unbounded fn Env, Ex -> Ex) -> Ex
Ex upd_tail(const Lx& lx, const Env& env, const ast::Expr& target, const ast::Block& b, const ast::Range& to, const prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Env, Ex>)>& cont_fn) {
    auto t = out_ty_of(lx, peel(type_at(lx, target.span)));
    auto tv = value_of(lx, env, target);
    auto env1 = bind(env, Text::lit("&_"), Bn(Bn::BnLocal{Ex(Ex::XVar{Text::lit("this")}), Holding(Holding::Owned{}), t}));
    return prepend(Array(std::vector{Do(Do::DoLet{Pa(Pa::PaTyped{prism_rtl::rc(Pa(Pa::PaMut{Text::lit("this")})), t}), own(tv)})}), upd_tail_from(lx, env, env1, b, Nat(0u), to, cont_fn));
}


prism_rtl::Turn<Ex> UpdTail::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& target = this->target;
    const auto& b = this->b;
    const auto& to = this->to;
    const auto& cont_fn = this->cont_fn;
    auto cont_fn_1 = cont_fn;
    auto b_2 = b;
    auto env_3 = env;
    auto lx_4 = lx;
    auto target_5 = target;
    auto to_6 = to;
    return call_then(start_out_ty_of(lx_4, peel(type_at(lx_4, target_5.span))), [=](OutTy out_ty_of_154518) {
        return ({
            auto t = out_ty_of_154518;
            call_then(start_value_of(lx_4, env_3, target_5), [=](Vl value_of_154575) {
            return ({
                auto tv = value_of_154575;
                auto env1 = bind(env_3, Text::lit("&_"), Bn(Bn::BnLocal{Ex(Ex::XVar{Text::lit("this")}), Holding(Holding::Owned{}), t}));
                call_then(start_upd_tail_from(lx_4, env_3, env1, b_2, Nat(0u), to_6, cont_fn_1), [=](Ex upd_tail_from_154728) { return prism_rtl::finished(prepend(Array(std::vector{Do(Do::DoLet{Pa(Pa::PaTyped{prism_rtl::rc(Pa(Pa::PaMut{Text::lit("this")})), t}), own(tv)})}), upd_tail_from_154728)); });
            });
        });
        });
    });
}


/// `Start UpdTail, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Ex> start_upd_tail(Lx lx, Env env, ast::Expr target, ast::Block b, ast::Range to, prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Env, Ex>)> cont_fn) {
    return prism_rtl::make_rc<UpdTail>(lx, env, target, b, to, cont_fn);
}


/// UpdTailFrom: unbounded fn Lx, Env, Env, Block, Nat, Range, (unbounded fn Env, Ex -> Ex) -> Ex
Ex upd_tail_from(const Lx& lx, const Env& outer, const Env& env, const ast::Block& b, const Nat& i, const ast::Range& to, const prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Env, Ex>)>& cont_fn) {
    return i >= len(b.stmts)
        ? run_to_end(cont_fn(std::tuple{outer, Ex(Ex::XVar{Text::lit("this")})}))
        : ({
        auto s = or_(index(b.stmts, i), dummy_stmt_l());
        auto rest = rest_text(lx, ast::Range{.start = s.span.end, .end = s.span.end}, ast::Range{.start = s.span.end, .end = s.span.end}, to);
        auto next_fn = ({
            auto lx_1 = lx;
            auto b_2 = b;
            auto i_3 = i;
            auto to_4 = to;
            auto cont_fn_5 = cont_fn;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Env, Env>)>>(prism_rtl::rc([=](std::tuple<Env, Env> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto lx_1_6 = lx_1;
                auto b_2_6 = b_2;
                auto i_3_6 = i_3;
                auto to_4_6 = to_4;
                auto cont_fn_5_6 = cont_fn_5;
                entered(once_job([=]() {
                return ({
                    auto o2 = p0;
                    auto e2 = p1;
                    (prism_rtl::more(prism_rtl::rc(UpdTailFrom(lx_1_6, o2, e2, b_2_6, i_3_6 + Nat(1u), to_4_6, cont_fn_5_6))));
                });
            }));
            });
        })));
        });
        is_cycle_while(lx, s) || holds_cycle_while(lx, s)
        ? stmt_job(lx, outer, env, s, rest, next_fn)
        : ({
        auto [dos, env2] = upd_stmt(lx, env, s);
        prepend(dos, upd_tail_from(lx, outer, env2, b, i + Nat(1u), to, cont_fn));
    });
    });
}


prism_rtl::Turn<Ex> UpdTailFrom::cycle() const {
    const auto& lx = this->lx;
    const auto& outer = this->outer;
    const auto& env = this->env;
    const auto& b = this->b;
    const auto& i = this->i;
    const auto& to = this->to;
    const auto& cont_fn = this->cont_fn;
    return i >= len(b.stmts)
        ? cont_fn(std::tuple{outer, Ex(Ex::XVar{Text::lit("this")})})->cycle()
        : ({
        auto s = or_(index(b.stmts, i), dummy_stmt_l());
        auto rest = rest_text(lx, ast::Range{.start = s.span.end, .end = s.span.end}, ast::Range{.start = s.span.end, .end = s.span.end}, to);
        auto next_fn = ({
            auto lx_1 = lx;
            auto b_2 = b;
            auto i_3 = i;
            auto to_4 = to;
            auto cont_fn_5 = cont_fn;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Env, Env>)>>(prism_rtl::rc([=](std::tuple<Env, Env> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto lx_1_6 = lx_1;
                auto b_2_6 = b_2;
                auto i_3_6 = i_3;
                auto to_4_6 = to_4;
                auto cont_fn_5_6 = cont_fn_5;
                entered(once_job([=]() {
                return ({
                    auto o2 = p0;
                    auto e2 = p1;
                    (prism_rtl::more(prism_rtl::rc(UpdTailFrom(lx_1_6, o2, e2, b_2_6, i_3_6 + Nat(1u), to_4_6, cont_fn_5_6))));
                });
            }));
            });
        })));
        });
        is_cycle_while(lx, s) || holds_cycle_while(lx, s)
        ? prism_rtl::more(prism_rtl::rc(StmtJob(lx, outer, env, s, rest, next_fn)))
        : ({
        auto cont_fn_1 = cont_fn;
        auto b_2 = b;
        auto env_3 = env;
        auto i_4 = i;
        auto lx_5 = lx;
        auto outer_6 = outer;
        auto to_7 = to;
        call_then(start_upd_stmt(lx_5, env_3, s), [=](std::tuple<Array<Do>, Env> upd_stmt_155355) {
        return ({
            auto [dos, env2] = upd_stmt_155355;
            call_then(start_upd_tail_from(lx_5, outer_6, env2, b_2, i_4 + Nat(1u), to_7, cont_fn_1), [=](Ex upd_tail_from_155400) { return prism_rtl::finished(prepend(dos, upd_tail_from_155400)); });
        });
    });
    });
    });
}


/// `Start UpdTailFrom, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Ex> start_upd_tail_from(Lx lx, Env outer, Env env, ast::Block b, Nat i, ast::Range to, prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Env, Ex>)> cont_fn) {
    return prism_rtl::make_rc<UpdTailFrom>(lx, outer, env, b, i, to, cont_fn);
}


/// StmtJob: unbounded fn Lx, Env, Env, Stmt, Text, (unbounded fn Env, Env -> Ex) -> Ex
Ex stmt_job(const Lx& lx, const Env& outer, const Env& env, const ast::Stmt& s, const Text& rest, const prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Env, Env>)>& cont_fn) {
    auto&& _m = s.kind;
    if (prism_rtl::is<ast::StmtKind::SWhile>(_m)) {
        auto&& c = prism_rtl::as<ast::StmtKind::SWhile>(_m).a0;
        auto&& wb = prism_rtl::as<ast::StmtKind::SWhile>(_m).a1;
        return while_job(lx, outer, env, c, wb, s.span, rest, cont_fn);
    }
    if (prism_rtl::is<ast::StmtKind::SExpr>(_m)) {
        auto&& x = prism_rtl::as<ast::StmtKind::SExpr>(_m).a0;
        auto&& _m = x.kind;
        if (prism_rtl::is<ast::ExprKind::EIf>(_m)) {
            auto&& c = prism_rtl::as<ast::ExprKind::EIf>(_m).a0;
            auto&& then_b = prism_rtl::as<ast::ExprKind::EIf>(_m).a1;
            auto&& else_b_opt = prism_rtl::as<ast::ExprKind::EIf>(_m).a2;
            return if_job(lx, outer, env, c, then_b, else_b_opt, s.span, rest, cont_fn);
        }
        if (prism_rtl::is<ast::ExprKind::EMatch>(_m)) {
            auto&& scrut = prism_rtl::as<ast::ExprKind::EMatch>(_m).a0;
            auto&& arms = prism_rtl::as<ast::ExprKind::EMatch>(_m).a1;
            return match_job(lx, outer, env, scrut, arms, s.span, rest, cont_fn);
        }
        if (prism_rtl::is<ast::ExprKind::EFor>(_m)) {
            auto&& binders_opt = prism_rtl::as<ast::ExprKind::EFor>(_m).a0;
            auto&& source = prism_rtl::as<ast::ExprKind::EFor>(_m).a1;
            auto&& body = prism_rtl::as<ast::ExprKind::EFor>(_m).a2;
            auto&& _m = ref_binder(binders_opt);
            if (prism_rtl::is_some(_m)) {
                return refusal(Text::lit("a cycle-point `while` in a `for &` of an `update` block, whose references a job cannot keep (gap LP)"));
            }
            if (prism_rtl::is_none(_m)) {
                return for_job(lx, outer, env, binders_opt, source, body, s.span, rest, cont_fn);
            }
            prism_rtl::unreachable("no arm matched");
        }
        {
            return refusal(prism_rtl::cat("a cycle-point `while` in ", kind_words(x.kind), " (gap LP)"));
        }
    }
    {
        return refusal(Text::lit("a cycle-point `while` in this statement (gap LP)"));
    }
}


prism_rtl::Turn<Ex> StmtJob::cycle() const {
    const auto& lx = this->lx;
    const auto& outer = this->outer;
    const auto& env = this->env;
    const auto& s = this->s;
    const auto& rest = this->rest;
    const auto& cont_fn = this->cont_fn;
    return ({
        auto&& _m = s.kind;
        prism_rtl::is<ast::StmtKind::SWhile>(_m) ? ({
        auto&& c = prism_rtl::as<ast::StmtKind::SWhile>(_m).a0;
        auto&& wb = prism_rtl::as<ast::StmtKind::SWhile>(_m).a1;
        prism_rtl::more(prism_rtl::rc(WhileJob(lx, outer, env, c, wb, s.span, rest, cont_fn)));
    })
        : prism_rtl::is<ast::StmtKind::SExpr>(_m) ? ({
        auto&& x = prism_rtl::as<ast::StmtKind::SExpr>(_m).a0;
        ({
        auto&& _m = x.kind;
        prism_rtl::is<ast::ExprKind::EIf>(_m) ? ({
        auto&& c = prism_rtl::as<ast::ExprKind::EIf>(_m).a0;
        auto&& then_b = prism_rtl::as<ast::ExprKind::EIf>(_m).a1;
        auto&& else_b_opt = prism_rtl::as<ast::ExprKind::EIf>(_m).a2;
        prism_rtl::more(prism_rtl::rc(IfJob(lx, outer, env, c, then_b, else_b_opt, s.span, rest, cont_fn)));
    })
        : prism_rtl::is<ast::ExprKind::EMatch>(_m) ? ({
        auto&& scrut = prism_rtl::as<ast::ExprKind::EMatch>(_m).a0;
        auto&& arms = prism_rtl::as<ast::ExprKind::EMatch>(_m).a1;
        prism_rtl::more(prism_rtl::rc(MatchJob(lx, outer, env, scrut, arms, s.span, rest, cont_fn)));
    })
        : prism_rtl::is<ast::ExprKind::EFor>(_m) ? ({
        auto&& binders_opt = prism_rtl::as<ast::ExprKind::EFor>(_m).a0;
        auto&& source = prism_rtl::as<ast::ExprKind::EFor>(_m).a1;
        auto&& body = prism_rtl::as<ast::ExprKind::EFor>(_m).a2;
        ({
        auto&& _m = ref_binder(binders_opt);
        prism_rtl::is_some(_m) ? prism_rtl::finished(refusal(Text::lit("a cycle-point `while` in a `for &` of an `update` block, whose references a job cannot keep (gap LP)")))
        : prism_rtl::is_none(_m) ? prism_rtl::more(prism_rtl::rc(ForJob(lx, outer, env, binders_opt, source, body, s.span, rest, cont_fn)))
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : prism_rtl::finished(refusal(prism_rtl::cat("a cycle-point `while` in ", kind_words(x.kind), " (gap LP)")));
    });
    })
        : prism_rtl::finished(refusal(Text::lit("a cycle-point `while` in this statement (gap LP)")));
    });
}


/// `Start StmtJob, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Ex> start_stmt_job(Lx lx, Env outer, Env env, ast::Stmt s, Text rest, prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Env, Env>)> cont_fn) {
    return prism_rtl::make_rc<StmtJob>(lx, outer, env, s, rest, cont_fn);
}


/// Prepend: fn [Do], Ex -> Ex
Ex prepend(const Array<Do>& dos, const Ex& ex1) {
    if (prism_rtl::is<Ex::XBlock>(ex1)) {
        auto&& more = prism_rtl::as<Ex::XBlock>(ex1).a0;
        auto&& last = prism_rtl::as<Ex::XBlock>(ex1).a1;
        return Ex(Ex::XBlock{append(dos, more), prism_rtl::rc(last)});
    }
    {
        auto&& x = ex1;
        return len(dos) == Nat(0u) ? x : Ex(Ex::XBlock{dos, prism_rtl::rc(x)});
    }
}


/// WhileJob: unbounded fn Lx, Env, Env, Cond, Block, Range, Text, (unbounded fn Env, Env -> Ex) -> Ex
Ex while_job(const Lx& lx, const Env& outer, const Env& env, const ast::Cond& c, const ast::Block& wb, const ast::Range& span, const Text& rest_text_, const prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Env, Env>)>& cont_fn) {
    auto state = fold(keys(env->names), Array<std::tuple<Text, Text, OutTy>>{}, [&](const Array<std::tuple<Text, Text, OutTy>>& acc, const Text& k) {
        return !lexer::has_prefix(k, Text::lit("&"))
            ? acc
            : ({
            __label__ _done;
            prism_rtl::Slot<Array<std::tuple<Text, Text, OutTy>>> _v;
            auto&& _m = prelude::get(env->names, k);
            if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m))) {
                auto&& rs = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                auto&& bt = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                _v.set(prelude::push(acc, std::tuple{k, place_stem(rs), bt}));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto names = each(state, [&](const std::tuple<Text, Text, OutTy>& _p0) {
        auto&& rs = std::get<1>(_p0);
        return rs;
    });
    auto st_ty = OutTy(OutTy::OutTuple{each(state, [&](const std::tuple<Text, Text, OutTy>& _p0) {
        auto&& bt = std::get<2>(_p0);
        return bt;
    })});
    auto pat = Pa(Pa::PaTuple{each(names, [&](const Text& n) { return Pa(Pa::PaMut{prism_rtl::cat(n)}); })});
    auto pack = Ex(Ex::XTuple{each(names, [&](const Text& n) { return Ex(Ex::XVar{n}); })});
    auto env_s = fold(state, env, [&](const Env& en, const std::tuple<Text, Text, OutTy>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        auto&& bt = std::get<2>(_p1);
        return bind(en, k, Bn(Bn::BnLocal{Ex(Ex::XVar{rs}), Holding(Holding::Owned{}), bt}));
    });
    auto loop_text = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = index(lx.g.srcs, lx->file);
        if (prism_rtl::is_some(_m)) {
            auto&& src = prism_rtl::some_of(_m);
            _v.set(check_errors::span_text(src, span));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto caps = caps_in(env_s, loop_text, names);
    auto cap_dos = each(caps, [&](const std::tuple<Text, Ex, Holding, OutTy>& _p0) {
        auto&& rs = std::get<1>(_p0);
        auto&& mode = std::get<2>(_p0);
        auto&& bt = std::get<3>(_p0);
        return Do(Do::DoLet{Pa(Pa::PaBind{place_stem(rs)}), own(Vl(Vl::VlPlace{rs, mode, bt}))});
    });
    auto env_c = fold(caps, env_s, [&](const Env& en, const std::tuple<Text, Ex, Holding, OutTy>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        auto&& bt = std::get<3>(_p1);
        return bind(en, k, Bn(Bn::BnLocal{Ex(Ex::XVar{place_stem(rs)}), Holding(Holding::Owned{}), bt}));
    });
    auto jobs = has_top_while(lx, wb);
    auto finish_fn = ({
        auto jobs_1 = jobs;
        (prism_rtl::rc([=](const Ex& x) {
        return jobs_1
            ? Ex(Ex::XCtor{Text::lit("prism_rtl::Turn::Finished"), Array(std::vector{x})})
            : x;
    }));
    });
    auto step_ty = OutTy(OutTy::OutNamed{Text::lit("Result"), Array(std::vector{st_ty, st_ty})});
    auto again = finish_fn(Ex(Ex::XTyped{prism_rtl::rc(Ex(Ex::XCtor{Text::lit("Ok"), Array(std::vector{pack})})), step_ty}));
    auto stop = finish_fn(Ex(Ex::XTyped{prism_rtl::rc(Ex(Ex::XCtor{Text::lit("Err"), Array(std::vector{pack})})), step_ty}));
    auto body_fn = ({
        auto jobs_1 = jobs;
        auto lx_2 = lx;
        auto wb_3 = wb;
        auto again_4 = again;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(Env)>>(prism_rtl::rc([=](Env p0) {
        return ({
            auto jobs_1_5 = jobs_1;
            auto lx_2_5 = lx_2;
            auto wb_3_5 = wb_3;
            auto again_4_5 = again_4;
            entered(once_job([=]() {
            return ({
                auto en = p0;
                jobs_1_5
                ? prism_rtl::more(prism_rtl::rc(UpdTailFrom(lx_2_5, en, en, wb_3_5, Nat(0u), wb_3_5.span, ({
                auto again_4_5_5 = again_4_5;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Env, Ex>)>>(prism_rtl::rc([=](std::tuple<Env, Ex> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto again_4_5_5_5 = again_4_5_5;
                    once_job([=]() {
                    return ({
                        auto o2 = p0;
                        auto e2 = p1;
                        (prism_rtl::finished(again_4_5_5_5));
                    });
                });
                });
            })));
            }))))
                : prism_rtl::more(prism_rtl::rc(StmtsThen(lx_2_5, en, wb_3_5, again_4_5)));
            });
        }));
        });
    })));
    });
    auto res_ty = jobs
        ? OutTy(OutTy::OutNamed{Text::lit("prism_rtl::Turn"), Array(std::vector{step_ty})})
        : st_ty;
    auto turn = ({
        __label__ _done;
        prism_rtl::Slot<Ex> _v;
        if (prism_rtl::is<ast::Cond::CondExpr>(c)) {
            auto&& x = prism_rtl::as<ast::Cond::CondExpr>(c).a0;
            _v.set(Ex(Ex::XIf{prism_rtl::rc(as_bool(value_of(lx, env_c, x))), prism_rtl::rc(run_to_end(body_fn(env_c))), prism_rtl::rc(stop)}));
            goto _done;
        }
        if (prism_rtl::is<ast::Cond::CondBind>(c)) {
            auto&& p_ = prism_rtl::as<ast::Cond::CondBind>(c).a0;
            auto&& x = prism_rtl::as<ast::Cond::CondBind>(c).a1;
            auto&& g_opt = prism_rtl::as<ast::Cond::CondBind>(c).a2;
            _v.set(({
                auto po = rust_pat(lx, p_, type_at(lx, x.span), Holding(Holding::Owned{}), prism_rtl::cat("w", span.start));
                auto env_b = bind_all(env_c, po.binds);
                auto conds = append(po.conds, guard_conds(lx, env_b, g_opt));
                own(arms_value(own(value_of(lx, env_c, x)), Array(std::vector{XArm{.pat = po.pa, .conds = conds, .body = run_to_end(body_fn(env_b))}, XArm{.pat = Pa(Pa::PaWild{}), .conds = Array<Cc>{}, .body = stop}}), prism_rtl::cat("'w", span.start), res_ty));
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto out_caps = caps_in(outer, rest_text_, names);
    auto out_dos = each(out_caps, [&](const std::tuple<Text, Ex, Holding, OutTy>& _p0) {
        auto&& rs = std::get<1>(_p0);
        auto&& mode = std::get<2>(_p0);
        auto&& bt = std::get<3>(_p0);
        return Do(Do::DoLet{Pa(Pa::PaBind{place_stem(rs)}), own(Vl(Vl::VlPlace{rs, mode, bt}))});
    });
    auto outer2 = fold(out_caps, outer, [&](const Env& en, const std::tuple<Text, Ex, Holding, OutTy>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        auto&& bt = std::get<3>(_p1);
        return bind(en, k, Bn(Bn::BnLocal{Ex(Ex::XVar{place_stem(rs)}), Holding(Holding::Owned{}), bt}));
    });
    auto env2 = fold(out_caps, env_s, [&](const Env& en, const std::tuple<Text, Ex, Holding, OutTy>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        auto&& bt = std::get<3>(_p1);
        return bind(en, k, Bn(Bn::BnLocal{Ex(Ex::XVar{place_stem(rs)}), Holding(Holding::Owned{}), bt}));
    });
    auto step_fn = prepend(cap_dos, Ex(Ex::XClosure{true, Array(std::vector{Pa(Pa::PaTyped{prism_rtl::rc(pat), st_ty})}), prism_rtl::rc(turn)}));
    auto looping = jobs ? Text::lit("loop_turns") : Text::lit("loop_job");
    auto enter = Ex(Ex::XCall{Text::lit("call_then"), Array(std::vector{Ex(Ex::XCall{looping, Array(std::vector{pack, step_fn})}), Ex(Ex::XClosure{true, Array(std::vector{Pa(Pa::PaTyped{prism_rtl::rc(pat), st_ty})}), prism_rtl::rc(run_to_end(cont_fn(std::tuple{outer2, env2})))})})});
    return prepend(out_dos, enter);
}


prism_rtl::Turn<Ex> WhileJob::cycle() const {
    const auto& lx = this->lx;
    const auto& outer = this->outer;
    const auto& env = this->env;
    const auto& c = this->c;
    const auto& wb = this->wb;
    const auto& span = this->span;
    const auto& rest_text_ = this->rest_text_;
    const auto& cont_fn = this->cont_fn;
    auto state = fold(keys(env->names), Array<std::tuple<Text, Text, OutTy>>{}, [&](const Array<std::tuple<Text, Text, OutTy>>& acc, const Text& k) {
        return !lexer::has_prefix(k, Text::lit("&"))
            ? acc
            : ({
            __label__ _done;
            prism_rtl::Slot<Array<std::tuple<Text, Text, OutTy>>> _v;
            auto&& _m = prelude::get(env->names, k);
            if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m))) {
                auto&& rs = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                auto&& bt = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                _v.set(prelude::push(acc, std::tuple{k, place_stem(rs), bt}));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto names = each(state, [&](const std::tuple<Text, Text, OutTy>& _p0) {
        auto&& rs = std::get<1>(_p0);
        return rs;
    });
    auto st_ty = OutTy(OutTy::OutTuple{each(state, [&](const std::tuple<Text, Text, OutTy>& _p0) {
        auto&& bt = std::get<2>(_p0);
        return bt;
    })});
    auto pat = Pa(Pa::PaTuple{each(names, [&](const Text& n) { return Pa(Pa::PaMut{prism_rtl::cat(n)}); })});
    auto pack = Ex(Ex::XTuple{each(names, [&](const Text& n) { return Ex(Ex::XVar{n}); })});
    auto env_s = fold(state, env, [&](const Env& en, const std::tuple<Text, Text, OutTy>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        auto&& bt = std::get<2>(_p1);
        return bind(en, k, Bn(Bn::BnLocal{Ex(Ex::XVar{rs}), Holding(Holding::Owned{}), bt}));
    });
    auto loop_text = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = index(lx.g.srcs, lx->file);
        if (prism_rtl::is_some(_m)) {
            auto&& src = prism_rtl::some_of(_m);
            _v.set(check_errors::span_text(src, span));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto caps = caps_in(env_s, loop_text, names);
    auto cap_dos = each(caps, [&](const std::tuple<Text, Ex, Holding, OutTy>& _p0) {
        auto&& rs = std::get<1>(_p0);
        auto&& mode = std::get<2>(_p0);
        auto&& bt = std::get<3>(_p0);
        return Do(Do::DoLet{Pa(Pa::PaBind{place_stem(rs)}), own(Vl(Vl::VlPlace{rs, mode, bt}))});
    });
    auto env_c = fold(caps, env_s, [&](const Env& en, const std::tuple<Text, Ex, Holding, OutTy>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        auto&& bt = std::get<3>(_p1);
        return bind(en, k, Bn(Bn::BnLocal{Ex(Ex::XVar{place_stem(rs)}), Holding(Holding::Owned{}), bt}));
    });
    auto jobs = has_top_while(lx, wb);
    auto finish_fn = ({
        auto jobs_1 = jobs;
        (prism_rtl::rc([=](const Ex& x) {
        return jobs_1
            ? Ex(Ex::XCtor{Text::lit("prism_rtl::Turn::Finished"), Array(std::vector{x})})
            : x;
    }));
    });
    auto step_ty = OutTy(OutTy::OutNamed{Text::lit("Result"), Array(std::vector{st_ty, st_ty})});
    auto again = finish_fn(Ex(Ex::XTyped{prism_rtl::rc(Ex(Ex::XCtor{Text::lit("Ok"), Array(std::vector{pack})})), step_ty}));
    auto stop = finish_fn(Ex(Ex::XTyped{prism_rtl::rc(Ex(Ex::XCtor{Text::lit("Err"), Array(std::vector{pack})})), step_ty}));
    auto body_fn = ({
        auto jobs_1 = jobs;
        auto lx_2 = lx;
        auto wb_3 = wb;
        auto again_4 = again;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(Env)>>(prism_rtl::rc([=](Env p0) {
        return ({
            auto jobs_1_5 = jobs_1;
            auto lx_2_5 = lx_2;
            auto wb_3_5 = wb_3;
            auto again_4_5 = again_4;
            entered(once_job([=]() {
            return ({
                auto en = p0;
                jobs_1_5
                ? prism_rtl::more(prism_rtl::rc(UpdTailFrom(lx_2_5, en, en, wb_3_5, Nat(0u), wb_3_5.span, ({
                auto again_4_5_5 = again_4_5;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Env, Ex>)>>(prism_rtl::rc([=](std::tuple<Env, Ex> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto again_4_5_5_5 = again_4_5_5;
                    once_job([=]() {
                    return ({
                        auto o2 = p0;
                        auto e2 = p1;
                        (prism_rtl::finished(again_4_5_5_5));
                    });
                });
                });
            })));
            }))))
                : prism_rtl::more(prism_rtl::rc(StmtsThen(lx_2_5, en, wb_3_5, again_4_5)));
            });
        }));
        });
    })));
    });
    auto res_ty = jobs
        ? OutTy(OutTy::OutNamed{Text::lit("prism_rtl::Turn"), Array(std::vector{step_ty})})
        : st_ty;
    auto turn = ({
        __label__ _done;
        prism_rtl::Slot<Ex> _v;
        if (prism_rtl::is<ast::Cond::CondExpr>(c)) {
            auto&& x = prism_rtl::as<ast::Cond::CondExpr>(c).a0;
            _v.set(Ex(Ex::XIf{prism_rtl::rc(as_bool(value_of(lx, env_c, x))), prism_rtl::rc(run_to_end(body_fn(env_c))), prism_rtl::rc(stop)}));
            goto _done;
        }
        if (prism_rtl::is<ast::Cond::CondBind>(c)) {
            auto&& p_ = prism_rtl::as<ast::Cond::CondBind>(c).a0;
            auto&& x = prism_rtl::as<ast::Cond::CondBind>(c).a1;
            auto&& g_opt = prism_rtl::as<ast::Cond::CondBind>(c).a2;
            _v.set(({
                auto po = rust_pat(lx, p_, type_at(lx, x.span), Holding(Holding::Owned{}), prism_rtl::cat("w", span.start));
                auto env_b = bind_all(env_c, po.binds);
                auto conds = append(po.conds, guard_conds(lx, env_b, g_opt));
                own(arms_value(own(value_of(lx, env_c, x)), Array(std::vector{XArm{.pat = po.pa, .conds = conds, .body = run_to_end(body_fn(env_b))}, XArm{.pat = Pa(Pa::PaWild{}), .conds = Array<Cc>{}, .body = stop}}), prism_rtl::cat("'w", span.start), res_ty));
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto out_caps = caps_in(outer, rest_text_, names);
    auto out_dos = each(out_caps, [&](const std::tuple<Text, Ex, Holding, OutTy>& _p0) {
        auto&& rs = std::get<1>(_p0);
        auto&& mode = std::get<2>(_p0);
        auto&& bt = std::get<3>(_p0);
        return Do(Do::DoLet{Pa(Pa::PaBind{place_stem(rs)}), own(Vl(Vl::VlPlace{rs, mode, bt}))});
    });
    auto outer2 = fold(out_caps, outer, [&](const Env& en, const std::tuple<Text, Ex, Holding, OutTy>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        auto&& bt = std::get<3>(_p1);
        return bind(en, k, Bn(Bn::BnLocal{Ex(Ex::XVar{place_stem(rs)}), Holding(Holding::Owned{}), bt}));
    });
    auto env2 = fold(out_caps, env_s, [&](const Env& en, const std::tuple<Text, Ex, Holding, OutTy>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        auto&& bt = std::get<3>(_p1);
        return bind(en, k, Bn(Bn::BnLocal{Ex(Ex::XVar{place_stem(rs)}), Holding(Holding::Owned{}), bt}));
    });
    auto step_fn = prepend(cap_dos, Ex(Ex::XClosure{true, Array(std::vector{Pa(Pa::PaTyped{prism_rtl::rc(pat), st_ty})}), prism_rtl::rc(turn)}));
    auto looping = jobs ? Text::lit("loop_turns") : Text::lit("loop_job");
    auto cont_fn_1 = cont_fn;
    return call_value(cont_fn_1(std::tuple{outer2, env2}), [=](Ex cont_159905) {
        return ({
            auto enter = Ex(Ex::XCall{Text::lit("call_then"), Array(std::vector{Ex(Ex::XCall{looping, Array(std::vector{pack, step_fn})}), Ex(Ex::XClosure{true, Array(std::vector{Pa(Pa::PaTyped{prism_rtl::rc(pat), st_ty})}), prism_rtl::rc(cont_159905)})})});
            (prism_rtl::finished(prepend(out_dos, enter)));
        });
    });
}


/// `Start WhileJob, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Ex> start_while_job(Lx lx, Env outer, Env env, ast::Cond c, ast::Block wb, ast::Range span, Text rest_text_, prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Env, Env>)> cont_fn) {
    return prism_rtl::make_rc<WhileJob>(lx, outer, env, c, wb, span, rest_text_, cont_fn);
}


/// StmtsThen: unbounded fn Lx, Env, Block, Ex -> Ex
Ex stmts_then(const Lx& lx, const Env& env, const ast::Block& b, const Ex& last) {
    auto&& _dos = upd_stmts(lx, env, b.stmts);
    auto&& dos = std::get<0>(_dos);
    return Ex(Ex::XBlock{dos, prism_rtl::rc(last)});
}


prism_rtl::Turn<Ex> StmtsThen::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& b = this->b;
    const auto& last = this->last;
    auto b_1 = b;
    auto env_2 = env;
    auto last_3 = last;
    auto lx_4 = lx;
    return call_then(start_upd_stmts(lx_4, env_2, b_1.stmts), [=](std::tuple<Array<Do>, Env> upd_stmts_160118) {
        return ({
            auto&& _dos = upd_stmts_160118;
            auto&& dos = std::get<0>(_dos);
            (prism_rtl::finished(Ex(Ex::XBlock{dos, prism_rtl::rc(last_3)})));
        });
    });
}


/// `Start StmtsThen, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Ex> start_stmts_then(Lx lx, Env env, ast::Block b, Ex last) {
    return prism_rtl::make_rc<StmtsThen>(lx, env, b, last);
}


/// IfJob: unbounded fn Lx, Env, Env, Cond, Block, ?Block, Range, Text, (unbounded fn Env, Env -> Ex) -> Ex
Ex if_job(const Lx& lx, const Env& outer, const Env& env, const ast::Cond& c, const ast::Block& then_b, const std::optional<ast::Block>& else_b_opt, const ast::Range& span, const Text& rest_text_, const prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Env, Env>)>& cont_fn) {
    auto state = fold(keys(env->names), Array<std::tuple<Text, Text, OutTy>>{}, [&](const Array<std::tuple<Text, Text, OutTy>>& acc, const Text& k) {
        return !lexer::has_prefix(k, Text::lit("&"))
            ? acc
            : ({
            __label__ _done;
            prism_rtl::Slot<Array<std::tuple<Text, Text, OutTy>>> _v;
            auto&& _m = prelude::get(env->names, k);
            if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m))) {
                auto&& rs = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                auto&& bt = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                _v.set(prelude::push(acc, std::tuple{k, place_stem(rs), bt}));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto names = each(state, [&](const std::tuple<Text, Text, OutTy>& _p0) {
        auto&& rs = std::get<1>(_p0);
        return rs;
    });
    auto st_ty = OutTy(OutTy::OutTuple{each(state, [&](const std::tuple<Text, Text, OutTy>& _p0) {
        auto&& bt = std::get<2>(_p0);
        return bt;
    })});
    auto pat = Pa(Pa::PaTuple{each(names, [&](const Text& n) { return Pa(Pa::PaMut{prism_rtl::cat(n)}); })});
    auto pack = Ex(Ex::XTuple{each(names, [&](const Text& n) { return Ex(Ex::XVar{n}); })});
    auto env_s = fold(state, env, [&](const Env& en, const std::tuple<Text, Text, OutTy>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        auto&& bt = std::get<2>(_p1);
        return bind(en, k, Bn(Bn::BnLocal{Ex(Ex::XVar{rs}), Holding(Holding::Owned{}), bt}));
    });
    auto out_caps = caps_in(outer, rest_text_, names);
    auto out_dos = each(out_caps, [&](const std::tuple<Text, Ex, Holding, OutTy>& _p0) {
        auto&& rs = std::get<1>(_p0);
        auto&& mode = std::get<2>(_p0);
        auto&& bt = std::get<3>(_p0);
        return Do(Do::DoLet{Pa(Pa::PaBind{place_stem(rs)}), own(Vl(Vl::VlPlace{rs, mode, bt}))});
    });
    auto outer2 = fold(out_caps, outer, [&](const Env& en, const std::tuple<Text, Ex, Holding, OutTy>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        auto&& bt = std::get<3>(_p1);
        return bind(en, k, Bn(Bn::BnLocal{Ex(Ex::XVar{place_stem(rs)}), Holding(Holding::Owned{}), bt}));
    });
    auto env2 = fold(out_caps, env_s, [&](const Env& en, const std::tuple<Text, Ex, Holding, OutTy>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        auto&& bt = std::get<3>(_p1);
        return bind(en, k, Bn(Bn::BnLocal{Ex(Ex::XVar{place_stem(rs)}), Holding(Holding::Owned{}), bt}));
    });
    auto k_name = prism_rtl::cat("k_if", span.start);
    auto k_do = Do(Do::DoLet{Pa(Pa::PaBind{k_name}), Ex(Ex::XClosure{true, Array(std::vector{Pa(Pa::PaTyped{prism_rtl::rc(pat), st_ty})}), prism_rtl::rc(run_to_end(cont_fn(std::tuple{outer2, env2})))})});
    auto to_k_fn = ({
        auto k_name_1 = k_name;
        auto pack_2 = pack;
        (prism_rtl::rc([=](const Env& o2, const Ex& e2) { return Ex(Ex::XCall{k_name_1, Array(std::vector{pack_2})}); }));
    });
    auto branch_fn = ({
        auto lx_1 = lx;
        auto env_2 = env;
        auto to_k_fn_3 = to_k_fn;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(ast::Block)>>(prism_rtl::rc([=](ast::Block p0) {
        return ({
            auto lx_1_4 = lx_1;
            auto env_2_4 = env_2;
            auto to_k_fn_3_4 = to_k_fn_3;
            entered(once_job([=]() {
            return ({
                auto b = p0;
                (prism_rtl::more(prism_rtl::rc(UpdTailFrom(lx_1_4, env_2_4, env_2_4, b, Nat(0u), b.span, ({
                auto f = to_k_fn_3_4;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Env, Ex>)>>(prism_rtl::rc([=](std::tuple<Env, Ex> _p0) {
                auto&& a0 = std::get<0>(_p0);
                auto&& a1 = std::get<1>(_p0);
                return ({
                    auto f_4 = f;
                    once_job([=]() { return prism_rtl::finished(f_4(a0, a1)); });
                });
            })));
            })))));
            });
        }));
        });
    })));
    });
    auto else_x = ({
        __label__ _done;
        prism_rtl::Slot<Ex> _v;
        if (prism_rtl::is_some(else_b_opt)) {
            auto&& eb = prism_rtl::some_of(else_b_opt);
            _v.set(run_to_end(branch_fn(eb)));
            goto _done;
        }
        if (prism_rtl::is_none(else_b_opt)) {
            _v.set(Ex(Ex::XCall{k_name, Array(std::vector{pack})}));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto choose = ({
        __label__ _done;
        prism_rtl::Slot<Ex> _v;
        if (prism_rtl::is<ast::Cond::CondExpr>(c)) {
            auto&& x = prism_rtl::as<ast::Cond::CondExpr>(c).a0;
            _v.set(Ex(Ex::XIf{prism_rtl::rc(as_bool(value_of(lx, env, x))), prism_rtl::rc(run_to_end(branch_fn(then_b))), prism_rtl::rc(else_x)}));
            goto _done;
        }
        if (prism_rtl::is<ast::Cond::CondBind>(c)) {
            auto&& p_ = prism_rtl::as<ast::Cond::CondBind>(c).a0;
            auto&& x = prism_rtl::as<ast::Cond::CondBind>(c).a1;
            _v.set(({
                auto po = rust_pat(lx, p_, type_at(lx, x.span), Holding(Holding::Owned{}), prism_rtl::cat("u", x.span.start));
                auto then_x = upd_tail_from(lx, bind_all(env, po.binds), bind_all(env, po.binds), then_b, Nat(0u), then_b.span, ({
                    auto f = to_k_fn;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Env, Ex>)>>(prism_rtl::rc([=](std::tuple<Env, Ex> _p0) {
                    auto&& a0 = std::get<0>(_p0);
                    auto&& a1 = std::get<1>(_p0);
                    return ({
                        auto f_1 = f;
                        once_job([=]() { return prism_rtl::finished(f_1(a0, a1)); });
                    });
                })));
                }));
                own(arms_value(own(value_of(lx, env, x)), Array(std::vector{XArm{.pat = po.pa, .conds = po.conds, .body = then_x}, XArm{.pat = Pa(Pa::PaWild{}), .conds = Array<Cc>{}, .body = else_x}}), prism_rtl::cat("'u", x.span.start), OutTy(OutTy::OutUnknown{Text::lit("the job's turn")})));
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return prepend(prelude::push(out_dos, k_do), choose);
}


prism_rtl::Turn<Ex> IfJob::cycle() const {
    const auto& lx = this->lx;
    const auto& outer = this->outer;
    const auto& env = this->env;
    const auto& c = this->c;
    const auto& then_b = this->then_b;
    const auto& else_b_opt = this->else_b_opt;
    const auto& span = this->span;
    const auto& rest_text_ = this->rest_text_;
    const auto& cont_fn = this->cont_fn;
    auto state = fold(keys(env->names), Array<std::tuple<Text, Text, OutTy>>{}, [&](const Array<std::tuple<Text, Text, OutTy>>& acc, const Text& k) {
        return !lexer::has_prefix(k, Text::lit("&"))
            ? acc
            : ({
            __label__ _done;
            prism_rtl::Slot<Array<std::tuple<Text, Text, OutTy>>> _v;
            auto&& _m = prelude::get(env->names, k);
            if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m))) {
                auto&& rs = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                auto&& bt = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                _v.set(prelude::push(acc, std::tuple{k, place_stem(rs), bt}));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto names = each(state, [&](const std::tuple<Text, Text, OutTy>& _p0) {
        auto&& rs = std::get<1>(_p0);
        return rs;
    });
    auto st_ty = OutTy(OutTy::OutTuple{each(state, [&](const std::tuple<Text, Text, OutTy>& _p0) {
        auto&& bt = std::get<2>(_p0);
        return bt;
    })});
    auto pat = Pa(Pa::PaTuple{each(names, [&](const Text& n) { return Pa(Pa::PaMut{prism_rtl::cat(n)}); })});
    auto pack = Ex(Ex::XTuple{each(names, [&](const Text& n) { return Ex(Ex::XVar{n}); })});
    auto env_s = fold(state, env, [&](const Env& en, const std::tuple<Text, Text, OutTy>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        auto&& bt = std::get<2>(_p1);
        return bind(en, k, Bn(Bn::BnLocal{Ex(Ex::XVar{rs}), Holding(Holding::Owned{}), bt}));
    });
    auto out_caps = caps_in(outer, rest_text_, names);
    auto out_dos = each(out_caps, [&](const std::tuple<Text, Ex, Holding, OutTy>& _p0) {
        auto&& rs = std::get<1>(_p0);
        auto&& mode = std::get<2>(_p0);
        auto&& bt = std::get<3>(_p0);
        return Do(Do::DoLet{Pa(Pa::PaBind{place_stem(rs)}), own(Vl(Vl::VlPlace{rs, mode, bt}))});
    });
    auto outer2 = fold(out_caps, outer, [&](const Env& en, const std::tuple<Text, Ex, Holding, OutTy>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        auto&& bt = std::get<3>(_p1);
        return bind(en, k, Bn(Bn::BnLocal{Ex(Ex::XVar{place_stem(rs)}), Holding(Holding::Owned{}), bt}));
    });
    auto env2 = fold(out_caps, env_s, [&](const Env& en, const std::tuple<Text, Ex, Holding, OutTy>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        auto&& bt = std::get<3>(_p1);
        return bind(en, k, Bn(Bn::BnLocal{Ex(Ex::XVar{place_stem(rs)}), Holding(Holding::Owned{}), bt}));
    });
    auto k_name = prism_rtl::cat("k_if", span.start);
    auto else_b_opt_1 = else_b_opt;
    auto cont_fn_2 = cont_fn;
    auto c_3 = c;
    auto env_4 = env;
    auto lx_5 = lx;
    auto span_6 = span;
    auto then_b_7 = then_b;
    return call_value(cont_fn_2(std::tuple{outer2, env2}), [=](Ex cont_161830) {
        return ({
            auto k_do = Do(Do::DoLet{Pa(Pa::PaBind{k_name}), Ex(Ex::XClosure{true, Array(std::vector{Pa(Pa::PaTyped{prism_rtl::rc(pat), st_ty})}), prism_rtl::rc(cont_161830)})});
            auto to_k_fn = ({
                auto k_name_8 = k_name;
                auto pack_9 = pack;
                (prism_rtl::rc([=](const Env& o2, const Ex& e2) { return Ex(Ex::XCall{k_name_8, Array(std::vector{pack_9})}); }));
            });
            auto branch_fn = ({
                auto lx_5_8 = lx_5;
                auto env_4_8 = env_4;
                auto to_k_fn_8 = to_k_fn;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(ast::Block)>>(prism_rtl::rc([=](ast::Block p0) {
                return ({
                    auto lx_5_8_9 = lx_5_8;
                    auto env_4_8_9 = env_4_8;
                    auto to_k_fn_8_9 = to_k_fn_8;
                    entered(once_job([=]() {
                    return ({
                        auto b = p0;
                        (prism_rtl::more(prism_rtl::rc(UpdTailFrom(lx_5_8_9, env_4_8_9, env_4_8_9, b, Nat(0u), b.span, ({
                        auto f = to_k_fn_8_9;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Env, Ex>)>>(prism_rtl::rc([=](std::tuple<Env, Ex> _p0) {
                        auto&& a0 = std::get<0>(_p0);
                        auto&& a1 = std::get<1>(_p0);
                        return ({
                            auto f_9 = f;
                            once_job([=]() { return prism_rtl::finished(f_9(a0, a1)); });
                        });
                    })));
                    })))));
                    });
                }));
                });
            })));
            });
            auto else_x = ({
                __label__ _done;
                prism_rtl::Slot<Ex> _v;
                if (prism_rtl::is_some(else_b_opt)) {
                    auto&& eb = prism_rtl::some_of(else_b_opt);
                    _v.set(run_to_end(branch_fn(eb)));
                    goto _done;
                }
                if (prism_rtl::is_none(else_b_opt)) {
                    _v.set(Ex(Ex::XCall{k_name, Array(std::vector{pack})}));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            auto choose = ({
                __label__ _done;
                prism_rtl::Slot<Ex> _v;
                if (prism_rtl::is<ast::Cond::CondExpr>(c)) {
                    auto&& x = prism_rtl::as<ast::Cond::CondExpr>(c).a0;
                    _v.set(Ex(Ex::XIf{prism_rtl::rc(as_bool(value_of(lx_5, env_4, x))), prism_rtl::rc(run_to_end(branch_fn(then_b_7))), prism_rtl::rc(else_x)}));
                    goto _done;
                }
                if (prism_rtl::is<ast::Cond::CondBind>(c)) {
                    auto&& p_ = prism_rtl::as<ast::Cond::CondBind>(c).a0;
                    auto&& x = prism_rtl::as<ast::Cond::CondBind>(c).a1;
                    _v.set(({
                        auto po = rust_pat(lx_5, p_, type_at(lx_5, x.span), Holding(Holding::Owned{}), prism_rtl::cat("u", x.span.start));
                        auto then_x = upd_tail_from(lx_5, bind_all(env_4, po.binds), bind_all(env_4, po.binds), then_b_7, Nat(0u), then_b_7.span, ({
                            auto f = to_k_fn;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Env, Ex>)>>(prism_rtl::rc([=](std::tuple<Env, Ex> _p0) {
                            auto&& a0 = std::get<0>(_p0);
                            auto&& a1 = std::get<1>(_p0);
                            return ({
                                auto f_8 = f;
                                once_job([=]() { return prism_rtl::finished(f_8(a0, a1)); });
                            });
                        })));
                        }));
                        own(arms_value(own(value_of(lx_5, env_4, x)), Array(std::vector{XArm{.pat = po.pa, .conds = po.conds, .body = then_x}, XArm{.pat = Pa(Pa::PaWild{}), .conds = Array<Cc>{}, .body = else_x}}), prism_rtl::cat("'u", x.span.start), OutTy(OutTy::OutUnknown{Text::lit("the job's turn")})));
                    }));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            (prism_rtl::finished(prepend(prelude::push(out_dos, k_do), choose)));
        });
    });
}


/// `Start IfJob, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Ex> start_if_job(Lx lx, Env outer, Env env, ast::Cond c, ast::Block then_b, std::optional<ast::Block> else_b_opt, ast::Range span, Text rest_text_, prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Env, Env>)> cont_fn) {
    return prism_rtl::make_rc<IfJob>(lx, outer, env, c, then_b, else_b_opt, span, rest_text_, cont_fn);
}


/// MatchJob: unbounded fn Lx, Env, Env, Expr, [Arm], Range, Text, (unbounded fn Env, Env -> Ex) -> Ex
Ex match_job(const Lx& lx, const Env& outer, const Env& env, const ast::Expr& scrut, const Array<ast::Arm>& arms, const ast::Range& span, const Text& rest_text_, const prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Env, Env>)>& cont_fn) {
    auto state = fold(keys(env->names), Array<std::tuple<Text, Text, OutTy>>{}, [&](const Array<std::tuple<Text, Text, OutTy>>& acc, const Text& k) {
        return !lexer::has_prefix(k, Text::lit("&"))
            ? acc
            : ({
            __label__ _done;
            prism_rtl::Slot<Array<std::tuple<Text, Text, OutTy>>> _v;
            auto&& _m = prelude::get(env->names, k);
            if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m))) {
                auto&& rs = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                auto&& bt = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                _v.set(prelude::push(acc, std::tuple{k, place_stem(rs), bt}));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto names = each(state, [&](const std::tuple<Text, Text, OutTy>& _p0) {
        auto&& rs = std::get<1>(_p0);
        return rs;
    });
    auto st_ty = OutTy(OutTy::OutTuple{each(state, [&](const std::tuple<Text, Text, OutTy>& _p0) {
        auto&& bt = std::get<2>(_p0);
        return bt;
    })});
    auto pat = Pa(Pa::PaTuple{each(names, [&](const Text& n) { return Pa(Pa::PaMut{prism_rtl::cat(n)}); })});
    auto pack = Ex(Ex::XTuple{each(names, [&](const Text& n) { return Ex(Ex::XVar{n}); })});
    auto env_s = fold(state, env, [&](const Env& en, const std::tuple<Text, Text, OutTy>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        auto&& bt = std::get<2>(_p1);
        return bind(en, k, Bn(Bn::BnLocal{Ex(Ex::XVar{rs}), Holding(Holding::Owned{}), bt}));
    });
    auto out_caps = caps_in(outer, rest_text_, names);
    auto out_dos = each(out_caps, [&](const std::tuple<Text, Ex, Holding, OutTy>& _p0) {
        auto&& rs = std::get<1>(_p0);
        auto&& mode = std::get<2>(_p0);
        auto&& bt = std::get<3>(_p0);
        return Do(Do::DoLet{Pa(Pa::PaBind{place_stem(rs)}), own(Vl(Vl::VlPlace{rs, mode, bt}))});
    });
    auto outer2 = fold(out_caps, outer, [&](const Env& en, const std::tuple<Text, Ex, Holding, OutTy>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        auto&& bt = std::get<3>(_p1);
        return bind(en, k, Bn(Bn::BnLocal{Ex(Ex::XVar{place_stem(rs)}), Holding(Holding::Owned{}), bt}));
    });
    auto env2 = fold(out_caps, env_s, [&](const Env& en, const std::tuple<Text, Ex, Holding, OutTy>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        auto&& bt = std::get<3>(_p1);
        return bind(en, k, Bn(Bn::BnLocal{Ex(Ex::XVar{place_stem(rs)}), Holding(Holding::Owned{}), bt}));
    });
    auto k_name = prism_rtl::cat("k_match", span.start);
    auto k_do = Do(Do::DoLet{Pa(Pa::PaBind{k_name}), Ex(Ex::XClosure{true, Array(std::vector{Pa(Pa::PaTyped{prism_rtl::rc(pat), st_ty})}), prism_rtl::rc(run_to_end(cont_fn(std::tuple{outer2, env2})))})});
    auto to_k_fn = ({
        auto k_name_1 = k_name;
        auto pack_2 = pack;
        (prism_rtl::rc([=](const Env& o2, const Ex& e2) { return Ex(Ex::XCall{k_name_1, Array(std::vector{pack_2})}); }));
    });
    auto sty = type_at(lx, scrut.span);
    auto xarms = run_to_end(each_job(check_errors::range0(len(arms)), ({
        auto arms_1 = arms;
        auto lx_2 = lx;
        auto sty_3 = sty;
        auto scrut_4 = scrut;
        auto env_5 = env;
        auto to_k_fn_6 = to_k_fn;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<XArm>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto arms_1_7 = arms_1;
            auto lx_2_7 = lx_2;
            auto sty_3_7 = sty_3;
            auto scrut_4_7 = scrut_4;
            auto env_5_7 = env_5;
            auto to_k_fn_6_7 = to_k_fn_6;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                ({
                auto arm = or_(index(arms_1_7, i), dummy_arm());
                call_then(start_arm_pat(lx_2_7, arm.pattern, sty_3_7, Holding(Holding::Owned{}), prism_rtl::cat("u", scrut_4_7.span.start, "_", i)), [=](PatOut arm_pat_164397) {
                return ({
                    auto po = arm_pat_164397;
                    auto env_a = bind_all(env_5_7, po.binds);
                    call_then(start_guard_conds(lx_2_7, env_a, arm.guard), [=](Array<Cc> guard_conds_164541) {
                    return ({
                        auto guarded = append(po.conds, guard_conds_164541);
                        call_then(start_upd_tail_from(lx_2_7, env_a, env_a, arm.body, Nat(0u), arm.body.span, ({
                        auto f = to_k_fn_6_7;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Env, Ex>)>>(prism_rtl::rc([=](std::tuple<Env, Ex> _p0) {
                        auto&& a0 = std::get<0>(_p0);
                        auto&& a1 = std::get<1>(_p0);
                        return ({
                            auto f_7 = f;
                            once_job([=]() { return prism_rtl::finished(f_7(a0, a1)); });
                        });
                    })));
                    })), [=](Ex upd_tail_from_164619) { return prism_rtl::finished(XArm{.pat = po.pa, .conds = guarded, .body = upd_tail_from_164619}); });
                    });
                });
                });
            });
            });
            });
        }));
        });
    })));
    })));
    return prepend(prelude::push(out_dos, k_do), own(arms_value(own(value_of(lx, env, scrut)), xarms, prism_rtl::cat("'u", scrut.span.start), OutTy(OutTy::OutUnknown{Text::lit("the job's turn")}))));
}


prism_rtl::Turn<Ex> MatchJob::cycle() const {
    const auto& lx = this->lx;
    const auto& outer = this->outer;
    const auto& env = this->env;
    const auto& scrut = this->scrut;
    const auto& arms = this->arms;
    const auto& span = this->span;
    const auto& rest_text_ = this->rest_text_;
    const auto& cont_fn = this->cont_fn;
    auto state = fold(keys(env->names), Array<std::tuple<Text, Text, OutTy>>{}, [&](const Array<std::tuple<Text, Text, OutTy>>& acc, const Text& k) {
        return !lexer::has_prefix(k, Text::lit("&"))
            ? acc
            : ({
            __label__ _done;
            prism_rtl::Slot<Array<std::tuple<Text, Text, OutTy>>> _v;
            auto&& _m = prelude::get(env->names, k);
            if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m))) {
                auto&& rs = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                auto&& bt = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                _v.set(prelude::push(acc, std::tuple{k, place_stem(rs), bt}));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto names = each(state, [&](const std::tuple<Text, Text, OutTy>& _p0) {
        auto&& rs = std::get<1>(_p0);
        return rs;
    });
    auto st_ty = OutTy(OutTy::OutTuple{each(state, [&](const std::tuple<Text, Text, OutTy>& _p0) {
        auto&& bt = std::get<2>(_p0);
        return bt;
    })});
    auto pat = Pa(Pa::PaTuple{each(names, [&](const Text& n) { return Pa(Pa::PaMut{prism_rtl::cat(n)}); })});
    auto pack = Ex(Ex::XTuple{each(names, [&](const Text& n) { return Ex(Ex::XVar{n}); })});
    auto env_s = fold(state, env, [&](const Env& en, const std::tuple<Text, Text, OutTy>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        auto&& bt = std::get<2>(_p1);
        return bind(en, k, Bn(Bn::BnLocal{Ex(Ex::XVar{rs}), Holding(Holding::Owned{}), bt}));
    });
    auto out_caps = caps_in(outer, rest_text_, names);
    auto out_dos = each(out_caps, [&](const std::tuple<Text, Ex, Holding, OutTy>& _p0) {
        auto&& rs = std::get<1>(_p0);
        auto&& mode = std::get<2>(_p0);
        auto&& bt = std::get<3>(_p0);
        return Do(Do::DoLet{Pa(Pa::PaBind{place_stem(rs)}), own(Vl(Vl::VlPlace{rs, mode, bt}))});
    });
    auto outer2 = fold(out_caps, outer, [&](const Env& en, const std::tuple<Text, Ex, Holding, OutTy>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        auto&& bt = std::get<3>(_p1);
        return bind(en, k, Bn(Bn::BnLocal{Ex(Ex::XVar{place_stem(rs)}), Holding(Holding::Owned{}), bt}));
    });
    auto env2 = fold(out_caps, env_s, [&](const Env& en, const std::tuple<Text, Ex, Holding, OutTy>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        auto&& bt = std::get<3>(_p1);
        return bind(en, k, Bn(Bn::BnLocal{Ex(Ex::XVar{place_stem(rs)}), Holding(Holding::Owned{}), bt}));
    });
    auto k_name = prism_rtl::cat("k_match", span.start);
    auto cont_fn_1 = cont_fn;
    auto arms_2 = arms;
    auto env_3 = env;
    auto lx_4 = lx;
    auto scrut_5 = scrut;
    auto span_6 = span;
    return call_value(cont_fn_1(std::tuple{outer2, env2}), [=](Ex cont_164192) {
        return ({
            auto k_do = Do(Do::DoLet{Pa(Pa::PaBind{k_name}), Ex(Ex::XClosure{true, Array(std::vector{Pa(Pa::PaTyped{prism_rtl::rc(pat), st_ty})}), prism_rtl::rc(cont_164192)})});
            auto to_k_fn = ({
                auto k_name_7 = k_name;
                auto pack_8 = pack;
                (prism_rtl::rc([=](const Env& o2, const Ex& e2) { return Ex(Ex::XCall{k_name_7, Array(std::vector{pack_8})}); }));
            });
            auto sty = type_at(lx_4, scrut_5.span);
            call_value(each_job(check_errors::range0(len(arms_2)), ({
            auto arms_2_7 = arms_2;
            auto lx_4_7 = lx_4;
            auto sty_7 = sty;
            auto scrut_5_8 = scrut_5;
            auto env_3_8 = env_3;
            auto to_k_fn_8 = to_k_fn;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<XArm>(Nat)>>(prism_rtl::rc([=](Nat p0) {
            return ({
                auto arms_2_7_9 = arms_2_7;
                auto lx_4_7_9 = lx_4_7;
                auto sty_7_9 = sty_7;
                auto scrut_5_8_9 = scrut_5_8;
                auto env_3_8_9 = env_3_8;
                auto to_k_fn_8_9 = to_k_fn_8;
                entered(once_job([=]() {
                return ({
                    auto i = p0;
                    ({
                    auto arm = or_(index(arms_2_7_9, i), dummy_arm());
                    call_then(start_arm_pat(lx_4_7_9, arm.pattern, sty_7_9, Holding(Holding::Owned{}), prism_rtl::cat("u", scrut_5_8_9.span.start, "_", i)), [=](PatOut arm_pat_164397) {
                    return ({
                        auto po = arm_pat_164397;
                        auto env_a = bind_all(env_3_8_9, po.binds);
                        call_then(start_guard_conds(lx_4_7_9, env_a, arm.guard), [=](Array<Cc> guard_conds_164541) {
                        return ({
                            auto guarded = append(po.conds, guard_conds_164541);
                            call_then(start_upd_tail_from(lx_4_7_9, env_a, env_a, arm.body, Nat(0u), arm.body.span, ({
                            auto f = to_k_fn_8_9;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Env, Ex>)>>(prism_rtl::rc([=](std::tuple<Env, Ex> _p0) {
                            auto&& a0 = std::get<0>(_p0);
                            auto&& a1 = std::get<1>(_p0);
                            return ({
                                auto f_9 = f;
                                once_job([=]() { return prism_rtl::finished(f_9(a0, a1)); });
                            });
                        })));
                        })), [=](Ex upd_tail_from_164619) { return prism_rtl::finished(XArm{.pat = po.pa, .conds = guarded, .body = upd_tail_from_164619}); });
                        });
                    });
                    });
                });
                });
                });
            }));
            });
        })));
        })), [=](Array<XArm> each_164310) {
            return ({
                auto xarms = each_164310;
                call_then(start_value_of(lx_4, env_3, scrut_5), [=](Vl value_of_164735) { return prism_rtl::finished(prepend(prelude::push(out_dos, k_do), own(arms_value(own(value_of_164735), xarms, prism_rtl::cat("'u", scrut_5.span.start), OutTy(OutTy::OutUnknown{Text::lit("the job's turn")}))))); });
            });
        });
        });
    });
}


/// `Start MatchJob, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Ex> start_match_job(Lx lx, Env outer, Env env, ast::Expr scrut, Array<ast::Arm> arms, ast::Range span, Text rest_text_, prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Env, Env>)> cont_fn) {
    return prism_rtl::make_rc<MatchJob>(lx, outer, env, scrut, arms, span, rest_text_, cont_fn);
}


/// ForJob: unbounded fn Lx, Env, Env, ?ForBinders, Expr, Block, Range, Text, (unbounded fn Env, Env -> Ex) -> Ex
Ex for_job(const Lx& lx, const Env& outer, const Env& env, const std::optional<ast::ForBinders>& binders_opt, const ast::Expr& source, const ast::Block& body, const ast::Range& span, const Text& rest_text_, const prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Env, Env>)>& cont_fn) {
    auto state = fold(keys(env->names), Array<std::tuple<Text, Text, OutTy>>{}, [&](const Array<std::tuple<Text, Text, OutTy>>& acc, const Text& k) {
        return !lexer::has_prefix(k, Text::lit("&"))
            ? acc
            : ({
            __label__ _done;
            prism_rtl::Slot<Array<std::tuple<Text, Text, OutTy>>> _v;
            auto&& _m = prelude::get(env->names, k);
            if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m))) {
                auto&& rs = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                auto&& bt = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                _v.set(prelude::push(acc, std::tuple{k, place_stem(rs), bt}));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto names = each(state, [&](const std::tuple<Text, Text, OutTy>& _p0) {
        auto&& rs = std::get<1>(_p0);
        return rs;
    });
    auto st_ty = OutTy(OutTy::OutTuple{each(state, [&](const std::tuple<Text, Text, OutTy>& _p0) {
        auto&& bt = std::get<2>(_p0);
        return bt;
    })});
    auto pat = Pa(Pa::PaTuple{each(names, [&](const Text& n) { return Pa(Pa::PaMut{prism_rtl::cat(n)}); })});
    auto pack = Ex(Ex::XTuple{each(names, [&](const Text& n) { return Ex(Ex::XVar{n}); })});
    auto env_s = fold(state, env, [&](const Env& en, const std::tuple<Text, Text, OutTy>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        auto&& bt = std::get<2>(_p1);
        return bind(en, k, Bn(Bn::BnLocal{Ex(Ex::XVar{rs}), Holding(Holding::Owned{}), bt}));
    });
    auto src = own(value_of(lx, env, source));
    auto sty = peel(type_at(lx, source.span));
    auto [kt, vt, is_array] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<OutTy, OutTy, bool>> _v;
        if (prism_rtl::is<check_types::Ty::TyArray>(sty)) {
            auto&& v_ = prism_rtl::as<check_types::Ty::TyArray>(sty).a0;
            _v.set(std::tuple{OutTy(OutTy::OutNat{}), out_ty_of(lx, v_), true});
            goto _done;
        }
        if (prism_rtl::is<check_types::Ty::TyMap>(sty)) {
            auto&& k = prism_rtl::as<check_types::Ty::TyMap>(sty).a0;
            auto&& v_ = prism_rtl::as<check_types::Ty::TyMap>(sty).a1;
            _v.set(std::tuple{out_ty_of(lx, k), out_ty_of(lx, v_), false});
            goto _done;
        }
        {
            _v.set(std::tuple{OutTy(OutTy::OutUnit{}), OutTy(OutTy::OutUnit{}), true});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto [vty, kty] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<check_types::Ty, check_types::Ty>> _v;
        if (prism_rtl::is<check_types::Ty::TyArray>(sty)) {
            auto&& v_ = prism_rtl::as<check_types::Ty::TyArray>(sty).a0;
            _v.set(std::tuple{v_, check_types::Ty(check_types::Ty::TyCon{Text::lit("Nat"), Array<check_types::Ty>{}})});
            goto _done;
        }
        if (prism_rtl::is<check_types::Ty::TyMap>(sty)) {
            auto&& k = prism_rtl::as<check_types::Ty::TyMap>(sty).a0;
            auto&& v_ = prism_rtl::as<check_types::Ty::TyMap>(sty).a1;
            _v.set(std::tuple{v_, k});
            goto _done;
        }
        {
            _v.set(std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::Ty(check_types::Ty::TyErr{})});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto key_name = prism_rtl::cat("k", span.start);
    auto val_name = prism_rtl::cat("v", span.start);
    auto loop_text = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = index(lx.g.srcs, lx->file);
        if (prism_rtl::is_some(_m)) {
            auto&& src2 = prism_rtl::some_of(_m);
            _v.set(check_errors::span_text(src2, span));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto caps = caps_in(env_s, loop_text, names);
    auto cap_dos = each(caps, [&](const std::tuple<Text, Ex, Holding, OutTy>& _p0) {
        auto&& rs = std::get<1>(_p0);
        auto&& mode = std::get<2>(_p0);
        auto&& bt = std::get<3>(_p0);
        return Do(Do::DoLet{Pa(Pa::PaBind{place_stem(rs)}), own(Vl(Vl::VlPlace{rs, mode, bt}))});
    });
    auto env_c = fold(caps, env_s, [&](const Env& en, const std::tuple<Text, Ex, Holding, OutTy>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        auto&& bt = std::get<3>(_p1);
        return bind(en, k, Bn(Bn::BnLocal{Ex(Ex::XVar{place_stem(rs)}), Holding(Holding::Owned{}), bt}));
    });
    auto env1 = bind(bind(env_c, Text::lit("key"), Bn(Bn::BnLocal{Ex(Ex::XVar{key_name}), Holding(Holding::Owned{}), kt})), Text::lit("_"), Bn(Bn::BnLocal{Ex(Ex::XVar{val_name}), Holding(Holding::Owned{}), vt}));
    auto env_k = is_array
        ? bind(env1, Text::lit("ix"), Bn(Bn::BnLocal{Ex(Ex::XVar{key_name}), Holding(Holding::Owned{}), kt}))
        : env1;
    auto [binds, env_b] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Array<Do>, Env>> _v;
        if (prism_rtl::is_none(binders_opt)) {
            _v.set(std::tuple{Array<Do>{}, env_k});
            goto _done;
        }
        if (prism_rtl::is_some(binders_opt)) {
            auto&& fb = prism_rtl::some_of(binders_opt);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::tuple<Array<Do>, Env>> _v;
                auto&& _m = fb.second;
                if (prism_rtl::is_none(_m)) {
                    _v.set(({
                        auto po = rust_pat(lx, fb.first, vty, Holding(Holding::Owned{}), prism_rtl::cat("e", span.start));
                        std::tuple{Array(std::vector{Do(Do::DoLet{po.pa, Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{val_name}))})})}), bind_all(env_k, po.binds)};
                    }));
                    goto _done;
                }
                if (prism_rtl::is_some(_m)) {
                    auto&& second = prism_rtl::some_of(_m);
                    _v.set(({
                        auto pk = rust_pat(lx, fb.first, kty, Holding(Holding::Owned{}), prism_rtl::cat("k", span.start, "_"));
                        auto pv = rust_pat(lx, second, vty, Holding(Holding::Owned{}), prism_rtl::cat("e", span.start));
                        std::tuple{Array(std::vector{Do(Do::DoLet{pk.pa, Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{key_name}))})}), Do(Do::DoLet{pv.pa, Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{val_name}))})})}), bind_all(bind_all(env_k, pk.binds), pv.binds)};
                    }));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto turn = prepend(binds, upd_tail_from(lx, env_b, env_b, body, Nat(0u), body.span, ({
        auto pack_1 = pack;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Env, Ex>)>>(prism_rtl::rc([=](std::tuple<Env, Ex> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto pack_1_2 = pack_1;
            once_job([=]() {
            return ({
                auto o2 = p0;
                auto e2 = p1;
                (prism_rtl::finished(Ex(Ex::XCtor{Text::lit("prism_rtl::Turn::Finished"), Array(std::vector{pack_1_2})})));
            });
        });
        });
    })));
    })));
    auto step_fn = prepend(cap_dos, Ex(Ex::XClosure{true, Array(std::vector{Pa(Pa::PaTyped{prism_rtl::rc(pat), st_ty}), Pa(Pa::PaTyped{prism_rtl::rc(Pa(Pa::PaBind{key_name})), kt}), Pa(Pa::PaTyped{prism_rtl::rc(Pa(Pa::PaBind{val_name})), vt})}), prism_rtl::rc(turn)}));
    auto out_caps = caps_in(outer, rest_text_, names);
    auto out_dos = each(out_caps, [&](const std::tuple<Text, Ex, Holding, OutTy>& _p0) {
        auto&& rs = std::get<1>(_p0);
        auto&& mode = std::get<2>(_p0);
        auto&& bt = std::get<3>(_p0);
        return Do(Do::DoLet{Pa(Pa::PaBind{place_stem(rs)}), own(Vl(Vl::VlPlace{rs, mode, bt}))});
    });
    auto outer2 = fold(out_caps, outer, [&](const Env& en, const std::tuple<Text, Ex, Holding, OutTy>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        auto&& bt = std::get<3>(_p1);
        return bind(en, k, Bn(Bn::BnLocal{Ex(Ex::XVar{place_stem(rs)}), Holding(Holding::Owned{}), bt}));
    });
    auto env2 = fold(out_caps, env_s, [&](const Env& en, const std::tuple<Text, Ex, Holding, OutTy>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        auto&& bt = std::get<3>(_p1);
        return bind(en, k, Bn(Bn::BnLocal{Ex(Ex::XVar{place_stem(rs)}), Holding(Holding::Owned{}), bt}));
    });
    auto looping = is_array ? Text::lit("for_turns_indexed") : Text::lit("for_turns_keyed");
    auto enter = Ex(Ex::XCall{Text::lit("call_then"), Array(std::vector{Ex(Ex::XCall{looping, Array(std::vector{src, pack, step_fn})}), Ex(Ex::XClosure{true, Array(std::vector{Pa(Pa::PaTyped{prism_rtl::rc(pat), st_ty})}), prism_rtl::rc(run_to_end(cont_fn(std::tuple{outer2, env2})))})})});
    return prepend(out_dos, enter);
}


prism_rtl::Turn<Ex> ForJob::cycle() const {
    const auto& lx = this->lx;
    const auto& outer = this->outer;
    const auto& env = this->env;
    const auto& binders_opt = this->binders_opt;
    const auto& source = this->source;
    const auto& body = this->body;
    const auto& span = this->span;
    const auto& rest_text_ = this->rest_text_;
    const auto& cont_fn = this->cont_fn;
    auto state = fold(keys(env->names), Array<std::tuple<Text, Text, OutTy>>{}, [&](const Array<std::tuple<Text, Text, OutTy>>& acc, const Text& k) {
        return !lexer::has_prefix(k, Text::lit("&"))
            ? acc
            : ({
            __label__ _done;
            prism_rtl::Slot<Array<std::tuple<Text, Text, OutTy>>> _v;
            auto&& _m = prelude::get(env->names, k);
            if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m))) {
                auto&& rs = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                auto&& bt = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                _v.set(prelude::push(acc, std::tuple{k, place_stem(rs), bt}));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto names = each(state, [&](const std::tuple<Text, Text, OutTy>& _p0) {
        auto&& rs = std::get<1>(_p0);
        return rs;
    });
    auto st_ty = OutTy(OutTy::OutTuple{each(state, [&](const std::tuple<Text, Text, OutTy>& _p0) {
        auto&& bt = std::get<2>(_p0);
        return bt;
    })});
    auto pat = Pa(Pa::PaTuple{each(names, [&](const Text& n) { return Pa(Pa::PaMut{prism_rtl::cat(n)}); })});
    auto pack = Ex(Ex::XTuple{each(names, [&](const Text& n) { return Ex(Ex::XVar{n}); })});
    auto env_s = fold(state, env, [&](const Env& en, const std::tuple<Text, Text, OutTy>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        auto&& bt = std::get<2>(_p1);
        return bind(en, k, Bn(Bn::BnLocal{Ex(Ex::XVar{rs}), Holding(Holding::Owned{}), bt}));
    });
    auto binders_opt_1 = binders_opt;
    auto cont_fn_2 = cont_fn;
    auto body_3 = body;
    auto env_4 = env;
    auto lx_5 = lx;
    auto outer_6 = outer;
    auto rest_text__7 = rest_text_;
    auto source_8 = source;
    auto span_9 = span;
    return call_then(start_value_of(lx_5, env_4, source_8), [=](Vl value_of_165972) {
        return ({
            auto src = own(value_of_165972);
            auto sty = peel(type_at(lx_5, source_8.span));
            auto [kt, vt, is_array] = ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<OutTy, OutTy, bool>> _v;
                if (prism_rtl::is<check_types::Ty::TyArray>(sty)) {
                    auto&& v_ = prism_rtl::as<check_types::Ty::TyArray>(sty).a0;
                    _v.set(std::tuple{OutTy(OutTy::OutNat{}), out_ty_of(lx_5, v_), true});
                    goto _done;
                }
                if (prism_rtl::is<check_types::Ty::TyMap>(sty)) {
                    auto&& k = prism_rtl::as<check_types::Ty::TyMap>(sty).a0;
                    auto&& v_ = prism_rtl::as<check_types::Ty::TyMap>(sty).a1;
                    _v.set(std::tuple{out_ty_of(lx_5, k), out_ty_of(lx_5, v_), false});
                    goto _done;
                }
                {
                    _v.set(std::tuple{OutTy(OutTy::OutUnit{}), OutTy(OutTy::OutUnit{}), true});
                    goto _done;
                }
            _done:
                _v.take();
            });
            auto [vty, kty] = ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<check_types::Ty, check_types::Ty>> _v;
                if (prism_rtl::is<check_types::Ty::TyArray>(sty)) {
                    auto&& v_ = prism_rtl::as<check_types::Ty::TyArray>(sty).a0;
                    _v.set(std::tuple{v_, check_types::Ty(check_types::Ty::TyCon{Text::lit("Nat"), Array<check_types::Ty>{}})});
                    goto _done;
                }
                if (prism_rtl::is<check_types::Ty::TyMap>(sty)) {
                    auto&& k = prism_rtl::as<check_types::Ty::TyMap>(sty).a0;
                    auto&& v_ = prism_rtl::as<check_types::Ty::TyMap>(sty).a1;
                    _v.set(std::tuple{v_, k});
                    goto _done;
                }
                {
                    _v.set(std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::Ty(check_types::Ty::TyErr{})});
                    goto _done;
                }
            _done:
                _v.take();
            });
            auto key_name = prism_rtl::cat("k", span_9.start);
            auto val_name = prism_rtl::cat("v", span_9.start);
            auto loop_text = ({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                auto&& _m = index(lx_5.g.srcs, lx_5->file);
                if (prism_rtl::is_some(_m)) {
                    auto&& src2 = prism_rtl::some_of(_m);
                    _v.set(check_errors::span_text(src2, span_9));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(Text::lit(""));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            auto caps = caps_in(env_s, loop_text, names);
            auto cap_dos = each(caps, [&](const std::tuple<Text, Ex, Holding, OutTy>& _p0) {
                auto&& rs = std::get<1>(_p0);
                auto&& mode = std::get<2>(_p0);
                auto&& bt = std::get<3>(_p0);
                return Do(Do::DoLet{Pa(Pa::PaBind{place_stem(rs)}), own(Vl(Vl::VlPlace{rs, mode, bt}))});
            });
            auto env_c = fold(caps, env_s, [&](const Env& en, const std::tuple<Text, Ex, Holding, OutTy>& _p1) {
                auto&& k = std::get<0>(_p1);
                auto&& rs = std::get<1>(_p1);
                auto&& bt = std::get<3>(_p1);
                return bind(en, k, Bn(Bn::BnLocal{Ex(Ex::XVar{place_stem(rs)}), Holding(Holding::Owned{}), bt}));
            });
            auto env1 = bind(bind(env_c, Text::lit("key"), Bn(Bn::BnLocal{Ex(Ex::XVar{key_name}), Holding(Holding::Owned{}), kt})), Text::lit("_"), Bn(Bn::BnLocal{Ex(Ex::XVar{val_name}), Holding(Holding::Owned{}), vt}));
            auto env_k = is_array
                ? bind(env1, Text::lit("ix"), Bn(Bn::BnLocal{Ex(Ex::XVar{key_name}), Holding(Holding::Owned{}), kt}))
                : env1;
            auto [binds, env_b] = ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<Array<Do>, Env>> _v;
                if (prism_rtl::is_none(binders_opt)) {
                    _v.set(std::tuple{Array<Do>{}, env_k});
                    goto _done;
                }
                if (prism_rtl::is_some(binders_opt)) {
                    auto&& fb = prism_rtl::some_of(binders_opt);
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<std::tuple<Array<Do>, Env>> _v;
                        auto&& _m = fb.second;
                        if (prism_rtl::is_none(_m)) {
                            _v.set(({
                                auto po = rust_pat(lx_5, fb.first, vty, Holding(Holding::Owned{}), prism_rtl::cat("e", span_9.start));
                                std::tuple{Array(std::vector{Do(Do::DoLet{po.pa, Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{val_name}))})})}), bind_all(env_k, po.binds)};
                            }));
                            goto _done;
                        }
                        if (prism_rtl::is_some(_m)) {
                            auto&& second = prism_rtl::some_of(_m);
                            _v.set(({
                                auto pk = rust_pat(lx_5, fb.first, kty, Holding(Holding::Owned{}), prism_rtl::cat("k", span_9.start, "_"));
                                auto pv = rust_pat(lx_5, second, vty, Holding(Holding::Owned{}), prism_rtl::cat("e", span_9.start));
                                std::tuple{Array(std::vector{Do(Do::DoLet{pk.pa, Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{key_name}))})}), Do(Do::DoLet{pv.pa, Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{val_name}))})})}), bind_all(bind_all(env_k, pk.binds), pv.binds)};
                            }));
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            call_then(start_upd_tail_from(lx_5, env_b, env_b, body_3, Nat(0u), body_3.span, ({
            auto pack_10 = pack;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Env, Ex>)>>(prism_rtl::rc([=](std::tuple<Env, Ex> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto pack_10_11 = pack_10;
                once_job([=]() {
                return ({
                    auto o2 = p0;
                    auto e2 = p1;
                    (prism_rtl::finished(Ex(Ex::XCtor{Text::lit("prism_rtl::Turn::Finished"), Array(std::vector{pack_10_11})})));
                });
            });
            });
        })));
        })), [=](Ex upd_tail_from_167737) {
            return ({
                auto turn = prepend(binds, upd_tail_from_167737);
                auto step_fn = prepend(cap_dos, Ex(Ex::XClosure{true, Array(std::vector{Pa(Pa::PaTyped{prism_rtl::rc(pat), st_ty}), Pa(Pa::PaTyped{prism_rtl::rc(Pa(Pa::PaBind{key_name})), kt}), Pa(Pa::PaTyped{prism_rtl::rc(Pa(Pa::PaBind{val_name})), vt})}), prism_rtl::rc(turn)}));
                auto out_caps = caps_in(outer_6, rest_text__7, names);
                auto out_dos = each(out_caps, [&](const std::tuple<Text, Ex, Holding, OutTy>& _p0) {
                    auto&& rs = std::get<1>(_p0);
                    auto&& mode = std::get<2>(_p0);
                    auto&& bt = std::get<3>(_p0);
                    return Do(Do::DoLet{Pa(Pa::PaBind{place_stem(rs)}), own(Vl(Vl::VlPlace{rs, mode, bt}))});
                });
                auto outer2 = fold(out_caps, outer_6, [&](const Env& en, const std::tuple<Text, Ex, Holding, OutTy>& _p1) {
                    auto&& k = std::get<0>(_p1);
                    auto&& rs = std::get<1>(_p1);
                    auto&& bt = std::get<3>(_p1);
                    return bind(en, k, Bn(Bn::BnLocal{Ex(Ex::XVar{place_stem(rs)}), Holding(Holding::Owned{}), bt}));
                });
                auto env2 = fold(out_caps, env_s, [&](const Env& en, const std::tuple<Text, Ex, Holding, OutTy>& _p1) {
                    auto&& k = std::get<0>(_p1);
                    auto&& rs = std::get<1>(_p1);
                    auto&& bt = std::get<3>(_p1);
                    return bind(en, k, Bn(Bn::BnLocal{Ex(Ex::XVar{place_stem(rs)}), Holding(Holding::Owned{}), bt}));
                });
                auto looping = is_array ? Text::lit("for_turns_indexed") : Text::lit("for_turns_keyed");
                call_value(cont_fn_2(std::tuple{outer2, env2}), [=](Ex cont_168585) {
                return ({
                    auto enter = Ex(Ex::XCall{Text::lit("call_then"), Array(std::vector{Ex(Ex::XCall{looping, Array(std::vector{src, pack, step_fn})}), Ex(Ex::XClosure{true, Array(std::vector{Pa(Pa::PaTyped{prism_rtl::rc(pat), st_ty})}), prism_rtl::rc(cont_168585)})})});
                    (prism_rtl::finished(prepend(out_dos, enter)));
                });
            });
            });
        });
        });
    });
}


/// `Start ForJob, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Ex> start_for_job(Lx lx, Env outer, Env env, std::optional<ast::ForBinders> binders_opt, ast::Expr source, ast::Block body, ast::Range span, Text rest_text_, prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Env, Env>)> cont_fn) {
    return prism_rtl::make_rc<ForJob>(lx, outer, env, binders_opt, source, body, span, rest_text_, cont_fn);
}


/// InstanceOf: fn Text -> Text
Text instance_of(const Text& k) {
    return or_(index(split(k, Text::lit("#inst")), Nat(0u)), k);
}


/// CapsIn: fn Env, Text, [Text] -> [((Text, Ex, Holding, OutTy))]
Array<std::tuple<Text, Ex, Holding, OutTy>> caps_in(const Env& env, const Text& text, const Array<Text>& skip) {
    return fold(keys(env->names), Array<std::tuple<Text, Ex, Holding, OutTy>>{}, [&](const Array<std::tuple<Text, Ex, Holding, OutTy>>& acc, const Text& k) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<std::tuple<Text, Ex, Holding, OutTy>>> _v;
            auto&& _m = prelude::get(env->names, k);
            if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m))) {
                auto&& rs = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                auto&& mode = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a1;
                auto&& bt = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                _v.set((check_types::has_text(skip, place_stem(rs)) || on_self(rs)) || (!mentions(text, lexer::drop_prefix(instance_of(k), check_types::marks_of(k))))
                    ? acc
                    : prelude::push(acc, std::tuple{k, rs, mode, bt}));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


/// ?FrameCall: unbounded fn Lx, Env, Expr, Bool -> ?Expr
std::optional<ast::Expr> frame_call(const Lx& lx, const Env& env, const ast::Expr& e, const bool& top) {
    return check_env::has_key(env.spans, place_key(lx, e.span))
        ? std::optional<ast::Expr>{}
        : ({
        __label__ _done;
        prism_rtl::Slot<std::optional<ast::Expr>> _v;
        auto&& _m = e.kind;
        if (prism_rtl::is<ast::ExprKind::EGroup>(_m)) {
            auto&& x = prism_rtl::as<ast::ExprKind::EGroup>(_m).a0;
            _v.set(frame_call(lx, env, x, top));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::ECall>(_m)) {
            auto&& c = prism_rtl::as<ast::ExprKind::ECall>(_m).a0;
            auto&& args = prism_rtl::as<ast::ExprKind::ECall>(_m).a1;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::optional<ast::Expr>> _v;
                auto&& _m = first_frame(lx, env, each(args, [&](const ast::Arg& a) { return a->value; }));
                if (prism_rtl::is_some(_m)) {
                    auto&& x = prism_rtl::some_of(_m);
                    _v.set(std::optional(x));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(top
                        ? std::optional<ast::Expr>{}
                        : ({
                        __label__ _done;
                        prism_rtl::Slot<std::optional<ast::Expr>> _v;
                        auto&& _m = tail_callee(lx, env, c);
                        if (prism_rtl::is_some(_m)) {
                            _v.set(std::optional(e));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(({
                                __label__ _done;
                                prism_rtl::Slot<std::optional<ast::Expr>> _v;
                                auto&& _m = local_job_fn(lx, env, c);
                                if (prism_rtl::is_some(_m)) {
                                    _v.set(std::optional(e));
                                    goto _done;
                                }
                                if (prism_rtl::is_none(_m)) {
                                    _v.set(({
                                        __label__ _done;
                                        prism_rtl::Slot<std::optional<ast::Expr>> _v;
                                        auto&& _m = prelude_job_call(lx, env, e);
                                        if (prism_rtl::is_some(_m)) {
                                            _v.set(std::optional(e));
                                            goto _done;
                                        }
                                        if (prism_rtl::is_none(_m)) {
                                            _v.set(std::optional<ast::Expr>{});
                                            goto _done;
                                        }
                                        prism_rtl::unreachable("no arm matched");
                                    _done:
                                        _v.take();
                                    }));
                                    goto _done;
                                }
                                prism_rtl::unreachable("no arm matched");
                            _done:
                                _v.take();
                            }));
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EMatch>(_m)) {
            auto&& x = prism_rtl::as<ast::ExprKind::EMatch>(_m).a0;
            _v.set(frame_call(lx, env, x, false));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EIf>(_m)) {
            auto&& m169751_3_0 = prism_rtl::as<ast::ExprKind::EIf>(_m).a0;
            if (prism_rtl::is<ast::Cond::CondExpr>(m169751_3_0)) {
                auto&& x = prism_rtl::as<ast::Cond::CondExpr>(m169751_3_0).a0;
                _v.set(frame_call(lx, env, x, false));
                goto _done;
            }
        }
        if (prism_rtl::is<ast::ExprKind::EBinary>(_m)) {
            auto&& op = prism_rtl::as<ast::ExprKind::EBinary>(_m).a0;
            auto&& l = prism_rtl::as<ast::ExprKind::EBinary>(_m).a1;
            auto&& r = prism_rtl::as<ast::ExprKind::EBinary>(_m).a2;
            _v.set((op == Text::lit("and")) || (op == Text::lit("or"))
                ? frame_call(lx, env, l, false)
                : first_frame(lx, env, Array(std::vector{l, r})));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::ETuple>(_m)) {
            auto&& es = prism_rtl::as<ast::ExprKind::ETuple>(_m).a0;
            _v.set(first_frame(lx, env, es));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EArray>(_m)) {
            auto&& es = prism_rtl::as<ast::ExprKind::EArray>(_m).a0;
            _v.set(first_frame(lx, env, es));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EUnary>(_m)) {
            auto&& x = prism_rtl::as<ast::ExprKind::EUnary>(_m).a1;
            _v.set(frame_call(lx, env, x, false));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EField>(_m)) {
            auto&& x = prism_rtl::as<ast::ExprKind::EField>(_m).a0;
            _v.set(frame_call(lx, env, x, false));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EIndex>(_m)) {
            auto&& x = prism_rtl::as<ast::ExprKind::EIndex>(_m).a0;
            auto&& i = prism_rtl::as<ast::ExprKind::EIndex>(_m).a1;
            _v.set(first_frame(lx, env, Array(std::vector{x, i})));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EMethod>(_m)) {
            auto&& x = prism_rtl::as<ast::ExprKind::EMethod>(_m).a0;
            auto&& args = prism_rtl::as<ast::ExprKind::EMethod>(_m).a2;
            _v.set(first_frame(lx, env, append(Array(std::vector{x}), each(args, [&](const ast::Arg& a) { return a->value; }))));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::ECast>(_m)) {
            auto&& x = prism_rtl::as<ast::ExprKind::ECast>(_m).a0;
            _v.set(frame_call(lx, env, x, false));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::ELit>(_m)) {
            auto&& l = prism_rtl::as<ast::ExprKind::ELit>(_m).a0;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::optional<ast::Expr>> _v;
                auto&& _m = l.kind;
                if (prism_rtl::is<ast::LitKind::LText>(_m)) {
                    auto&& segs = prism_rtl::as<ast::LitKind::LText>(_m).a0;
                    _v.set(first_frame(lx, env, placeholders(segs)));
                    goto _done;
                }
                {
                    _v.set(std::optional<ast::Expr>{});
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        {
            _v.set(std::optional<ast::Expr>{});
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::optional<ast::Expr>> FrameCall::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& e = this->e;
    const auto& top = this->top;
    return check_env::has_key(env.spans, place_key(lx, e.span))
        ? prism_rtl::finished(std::optional<ast::Expr>{})
        : ({
        auto&& _m = e.kind;
        prism_rtl::is<ast::ExprKind::EGroup>(_m) ? ({
        auto&& x = prism_rtl::as<ast::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(FrameCall(lx, env, x, top)));
    })
        : prism_rtl::is<ast::ExprKind::ECall>(_m) ? ({
        auto&& c = prism_rtl::as<ast::ExprKind::ECall>(_m).a0;
        auto&& args = prism_rtl::as<ast::ExprKind::ECall>(_m).a1;
        ({
        auto args_1 = args;
        auto c_2 = c;
        auto e_3 = e;
        auto env_4 = env;
        auto lx_5 = lx;
        auto top_6 = top;
        call_then(start_first_frame(lx_5, env_4, each(args_1, [&](const ast::Arg& a) { return a->value; })), [=](std::optional<ast::Expr> first_frame_169855) {
        return ({
            prism_rtl::is_some(first_frame_169855) ? ({
            auto&& x = prism_rtl::some_of(first_frame_169855);
            prism_rtl::finished(std::optional(x));
        })
            : prism_rtl::is_none(first_frame_169855) ? top_6
            ? prism_rtl::finished(std::optional<ast::Expr>{})
            : ({
            auto&& _m = tail_callee(lx_5, env_4, c_2);
            prism_rtl::is_some(_m) ? prism_rtl::finished(std::optional(e_3))
            : prism_rtl::is_none(_m) ? call_then(start_local_job_fn(lx_5, env_4, c_2), [=](std::optional<Vl> local_job_fn_170086) {
            return ({
                prism_rtl::is_some(local_job_fn_170086) ? prism_rtl::finished(std::optional(e_3))
                : prism_rtl::is_none(local_job_fn_170086) ? call_then(start_prelude_job_call(lx_5, env_4, e_3), [=](std::optional<Ex> prelude_job_call_170183) {
                return ({
                    prism_rtl::is_some(prelude_job_call_170183) ? prism_rtl::finished(std::optional(e_3))
                    : prism_rtl::is_none(prelude_job_call_170183) ? prism_rtl::finished(std::optional<ast::Expr>{})
                    : throw prism_rtl::Panic("no arm matched");
                });
            })
                : throw prism_rtl::Panic("no arm matched");
            });
        })
            : throw prism_rtl::Panic("no arm matched");
        })
            : throw prism_rtl::Panic("no arm matched");
        });
    });
    });
    })
        : prism_rtl::is<ast::ExprKind::EMatch>(_m) ? ({
        auto&& x = prism_rtl::as<ast::ExprKind::EMatch>(_m).a0;
        prism_rtl::more(prism_rtl::rc(FrameCall(lx, env, x, false)));
    })
        : prism_rtl::is<ast::ExprKind::EIf>(_m) && ({
        auto&& m169751_3_0 = prism_rtl::as<ast::ExprKind::EIf>(_m).a0;
        prism_rtl::is<ast::Cond::CondExpr>(m169751_3_0);
    }) ? ({
        auto&& m169751_3_0 = prism_rtl::as<ast::ExprKind::EIf>(_m).a0;
        auto&& x = prism_rtl::as<ast::Cond::CondExpr>(m169751_3_0).a0;
        prism_rtl::more(prism_rtl::rc(FrameCall(lx, env, x, false)));
    })
        : prism_rtl::is<ast::ExprKind::EBinary>(_m) ? ({
        auto&& op = prism_rtl::as<ast::ExprKind::EBinary>(_m).a0;
        auto&& l = prism_rtl::as<ast::ExprKind::EBinary>(_m).a1;
        auto&& r = prism_rtl::as<ast::ExprKind::EBinary>(_m).a2;
        (op == Text::lit("and")) || (op == Text::lit("or"))
        ? prism_rtl::more(prism_rtl::rc(FrameCall(lx, env, l, false)))
        : prism_rtl::more(prism_rtl::rc(FirstFrame(lx, env, Array(std::vector{l, r}))));
    })
        : prism_rtl::is<ast::ExprKind::ETuple>(_m) ? ({
        auto&& es = prism_rtl::as<ast::ExprKind::ETuple>(_m).a0;
        prism_rtl::more(prism_rtl::rc(FirstFrame(lx, env, es)));
    })
        : prism_rtl::is<ast::ExprKind::EArray>(_m) ? ({
        auto&& es = prism_rtl::as<ast::ExprKind::EArray>(_m).a0;
        prism_rtl::more(prism_rtl::rc(FirstFrame(lx, env, es)));
    })
        : prism_rtl::is<ast::ExprKind::EUnary>(_m) ? ({
        auto&& x = prism_rtl::as<ast::ExprKind::EUnary>(_m).a1;
        prism_rtl::more(prism_rtl::rc(FrameCall(lx, env, x, false)));
    })
        : prism_rtl::is<ast::ExprKind::EField>(_m) ? ({
        auto&& x = prism_rtl::as<ast::ExprKind::EField>(_m).a0;
        prism_rtl::more(prism_rtl::rc(FrameCall(lx, env, x, false)));
    })
        : prism_rtl::is<ast::ExprKind::EIndex>(_m) ? ({
        auto&& x = prism_rtl::as<ast::ExprKind::EIndex>(_m).a0;
        auto&& i = prism_rtl::as<ast::ExprKind::EIndex>(_m).a1;
        prism_rtl::more(prism_rtl::rc(FirstFrame(lx, env, Array(std::vector{x, i}))));
    })
        : prism_rtl::is<ast::ExprKind::EMethod>(_m) ? ({
        auto&& x = prism_rtl::as<ast::ExprKind::EMethod>(_m).a0;
        auto&& args = prism_rtl::as<ast::ExprKind::EMethod>(_m).a2;
        prism_rtl::more(prism_rtl::rc(FirstFrame(lx, env, append(Array(std::vector{x}), each(args, [&](const ast::Arg& a) { return a->value; })))));
    })
        : prism_rtl::is<ast::ExprKind::ECast>(_m) ? ({
        auto&& x = prism_rtl::as<ast::ExprKind::ECast>(_m).a0;
        prism_rtl::more(prism_rtl::rc(FrameCall(lx, env, x, false)));
    })
        : prism_rtl::is<ast::ExprKind::ELit>(_m) ? ({
        auto&& l = prism_rtl::as<ast::ExprKind::ELit>(_m).a0;
        ({
        auto&& _m = l.kind;
        prism_rtl::is<ast::LitKind::LText>(_m) ? ({
        auto&& segs = prism_rtl::as<ast::LitKind::LText>(_m).a0;
        prism_rtl::more(prism_rtl::rc(FirstFrame(lx, env, placeholders(segs))));
    })
        : prism_rtl::finished(std::optional<ast::Expr>{});
    });
    })
        : prism_rtl::finished(std::optional<ast::Expr>{});
    });
}


/// `Start FrameCall, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<ast::Expr>> start_frame_call(Lx lx, Env env, ast::Expr e, bool top) {
    return prism_rtl::make_rc<FrameCall>(lx, env, e, top);
}


/// Placeholders: fn [TextSeg] -> [Expr]
Array<ast::Expr> placeholders(const Array<ast::TextSeg>& segs) {
    return fold(segs, Array<ast::Expr>{}, [&](const Array<ast::Expr>& acc, const ast::TextSeg& sg) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<ast::Expr>> _v;
            if (prism_rtl::is<ast::TextSeg::SegPlaceholder>(sg)) {
                auto&& x = prism_rtl::as<ast::TextSeg::SegPlaceholder>(sg).a0;
                _v.set(prelude::push(acc, x));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


/// ?FirstFrame: unbounded fn Lx, Env, [Expr] -> ?Expr
std::optional<ast::Expr> first_frame(const Lx& lx, const Env& env, const Array<ast::Expr>& es) {
    return run_to_end(fold_job(es, std::optional<ast::Expr>{}, ({
        auto lx_1 = lx;
        auto env_2 = env;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::optional<ast::Expr>>(std::tuple<std::optional<ast::Expr>, ast::Expr>)>>(prism_rtl::rc([=](std::tuple<std::optional<ast::Expr>, ast::Expr> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_1_3 = lx_1;
            auto env_2_3 = env_2;
            entered(once_job([=]() {
            return ({
                auto found_opt = p0;
                auto x = p1;
                ({
                prism_rtl::is_some(found_opt) ? ({
                auto&& f = prism_rtl::some_of(found_opt);
                prism_rtl::finished(std::optional(f));
            })
                : prism_rtl::is_none(found_opt) ? prism_rtl::more(prism_rtl::rc(FrameCall(lx_1_3, env_2_3, x, false)))
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<std::optional<ast::Expr>> FirstFrame::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& es = this->es;
    return fold_job(es, std::optional<ast::Expr>{}, ({
        auto lx_1 = lx;
        auto env_2 = env;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::optional<ast::Expr>>(std::tuple<std::optional<ast::Expr>, ast::Expr>)>>(prism_rtl::rc([=](std::tuple<std::optional<ast::Expr>, ast::Expr> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_1_3 = lx_1;
            auto env_2_3 = env_2;
            entered(once_job([=]() {
            return ({
                auto found_opt = p0;
                auto x = p1;
                ({
                prism_rtl::is_some(found_opt) ? ({
                auto&& f = prism_rtl::some_of(found_opt);
                prism_rtl::finished(std::optional(f));
            })
                : prism_rtl::is_none(found_opt) ? prism_rtl::more(prism_rtl::rc(FrameCall(lx_1_3, env_2_3, x, false)))
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start FirstFrame, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<ast::Expr>> start_first_frame(Lx lx, Env env, Array<ast::Expr> es) {
    return prism_rtl::make_rc<FirstFrame>(lx, env, es);
}


/// Frame: unbounded fn Lx, Env, Expr, Text, (unbounded fn Env -> Ex) -> Ex
Ex frame(const Lx& lx, const Env& env, const ast::Expr& call, const Text& rest_text_, const prism_rtl::Fn<prism_rtl::JobRef<Ex>(Env)>& cont_fn) {
    auto&& _m = call.kind;
    if (prism_rtl::is<ast::ExprKind::ECall>(_m)) {
        auto&& c = prism_rtl::as<ast::ExprKind::ECall>(_m).a0;
        auto&& args = prism_rtl::as<ast::ExprKind::ECall>(_m).a1;
        auto qk_opt = tail_callee(lx, env, c);
        auto qk = or_(qk_opt, Text::lit(""));
        auto base_ = ({
            __label__ _done;
            prism_rtl::Slot<Text> _v;
            if (prism_rtl::is_some(qk_opt)) {
                auto&& q = prism_rtl::some_of(qk_opt);
                _v.set(or_(prelude::get(lx.rs_names, q), snake(check_types::bare_name(q))));
                goto _done;
            }
            if (prism_rtl::is_none(qk_opt)) {
                _v.set(snake(callee_text(c)));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto v_ = prism_rtl::cat(base_, "_", call.span.start);
        auto t = out_ty_of(lx, peel(type_at(lx, call.span)));
        auto caps = fold(keys(env->names), Array<std::tuple<Text, Ex, Holding, OutTy>>{}, [&](const Array<std::tuple<Text, Ex, Holding, OutTy>>& acc, const Text& k) {
            return ({
                __label__ _done;
                prism_rtl::Slot<Array<std::tuple<Text, Ex, Holding, OutTy>>> _v;
                auto&& _m = prelude::get(env->names, k);
                if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m))) {
                    auto&& rs = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                    auto&& mode = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a1;
                    auto&& bt = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                    _v.set(((mode == Holding(Holding::ByRef{})) || (mode == Holding(Holding::RcRef{}))) && mentions(rest_text_, instance_of(k))
                        ? prelude::push(acc, std::tuple{k, rs, mode, bt})
                        : acc);
                    goto _done;
                }
                {
                    _v.set(acc);
                    goto _done;
                }
            _done:
                _v.take();
            });
        });
        auto dos = each(caps, [&](const std::tuple<Text, Ex, Holding, OutTy>& _p0) {
            auto&& rs = std::get<1>(_p0);
            auto&& mode = std::get<2>(_p0);
            auto&& bt = std::get<3>(_p0);
            return Do(Do::DoLet{Pa(Pa::PaBind{place_stem(rs)}), own(Vl(Vl::VlPlace{rs, mode, bt}))});
        });
        auto env2 = fold(caps, env, [&](const Env& en, const std::tuple<Text, Ex, Holding, OutTy>& _p1) {
            auto&& k = std::get<0>(_p1);
            auto&& rs = std::get<1>(_p1);
            auto&& bt = std::get<3>(_p1);
            return bind(en, k, Bn(Bn::BnLocal{Ex(Ex::XVar{place_stem(rs)}), Holding(Holding::Owned{}), bt}));
        });
        auto vals = ({
            __label__ _done;
            prism_rtl::Slot<Array<Ex>> _v;
            if (prism_rtl::is_some(qk_opt)) {
                auto&& q = prism_rtl::some_of(qk_opt);
                _v.set(named_args_owned(lx, env2, q, args));
                goto _done;
            }
            if (prism_rtl::is_none(qk_opt)) {
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Array<Ex>> _v;
                    auto&& _m = local_job_fn(lx, env2, c);
                    if (prism_rtl::is_some(_m)) {
                        auto&& f = prism_rtl::some_of(_m);
                        _v.set(start_args(lx, env2, f, args));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(run_to_end(each_job(args, ({
                            auto lx_1 = lx;
                            auto env2_2 = env2;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(ast::Arg)>>(prism_rtl::rc([=](ast::Arg p0) {
                            return ({
                                auto lx_1_3 = lx_1;
                                auto env2_2_3 = env2_2;
                                entered(once_job([=]() {
                                return ({
                                    auto a = p0;
                                    call_then(start_value_of(lx_1_3, env2_2_3, a->value), [=](Vl value_of_172906) { return prism_rtl::finished(own(value_of_172906)); });
                                });
                            }));
                            });
                        })));
                        }))));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto env3 = bind_span(env2, place_key(lx, call.span), Vl(Vl::VlOwned{Ex(Ex::XVar{v_}), t}));
        auto body = run_to_end(cont_fn(env3));
        auto [job, how] = ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<Ex, Text>> _v;
            if (prism_rtl::is_some(qk_opt)) {
                auto&& q = prism_rtl::some_of(qk_opt);
                _v.set(std::tuple{Ex(Ex::XCall{path_in(lx, owner_of(q), prism_rtl::cat("start_", base_)), vals}), enters_at_once(lx, q, args)
                    ? Text::lit("call_value")
                    : Text::lit("call_then")});
                goto _done;
            }
            if (prism_rtl::is_none(qk_opt)) {
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<std::tuple<Ex, Text>> _v;
                    auto&& _m = local_job_fn(lx, env2, c);
                    if (prism_rtl::is_some(_m)) {
                        auto&& f = prism_rtl::some_of(_m);
                        _v.set(std::tuple{start_call(f, vals), Text::lit("call_value")});
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(({
                            __label__ _done;
                            prism_rtl::Slot<std::tuple<Ex, Text>> _v;
                            auto&& _m = prelude_job_call(lx, env2, call);
                            if (prism_rtl::is_some(_m)) {
                                auto&& pj = prism_rtl::some_of(_m);
                                _v.set(std::tuple{pj, Text::lit("call_value")});
                                goto _done;
                            }
                            if (prism_rtl::is_none(_m)) {
                                _v.set(std::tuple{refusal(Text::lit("a call this frame cannot enter")), Text::lit("call_then")});
                                goto _done;
                            }
                            prism_rtl::unreachable("no arm matched");
                        _done:
                            _v.take();
                        }));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto enter = Ex(Ex::XCall{how, Array(std::vector{job, Ex(Ex::XClosure{true, Array(std::vector{Pa(Pa::PaTyped{prism_rtl::rc(Pa(Pa::PaBind{v_})), t})}), prism_rtl::rc(body)})})});
        return len(dos) == Nat(0u) ? enter : Ex(Ex::XBlock{dos, prism_rtl::rc(enter)});
    }
    {
        return run_to_end(cont_fn(env));
    }
}


prism_rtl::Turn<Ex> Frame::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& call = this->call;
    const auto& rest_text_ = this->rest_text_;
    const auto& cont_fn = this->cont_fn;
    return ({
        auto&& _m = call.kind;
        prism_rtl::is<ast::ExprKind::ECall>(_m) ? ({
        auto&& c = prism_rtl::as<ast::ExprKind::ECall>(_m).a0;
        auto&& args = prism_rtl::as<ast::ExprKind::ECall>(_m).a1;
        ({
        auto qk_opt = tail_callee(lx, env, c);
        auto qk = or_(qk_opt, Text::lit(""));
        auto base_ = ({
            __label__ _done;
            prism_rtl::Slot<Text> _v;
            if (prism_rtl::is_some(qk_opt)) {
                auto&& q = prism_rtl::some_of(qk_opt);
                _v.set(or_(prelude::get(lx.rs_names, q), snake(check_types::bare_name(q))));
                goto _done;
            }
            if (prism_rtl::is_none(qk_opt)) {
                _v.set(snake(callee_text(c)));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto v_ = prism_rtl::cat(base_, "_", call.span.start);
        auto cont_fn_1 = cont_fn;
        auto args_2 = args;
        auto c_3 = c;
        auto call_4 = call;
        auto env_5 = env;
        auto lx_6 = lx;
        auto rest_text__7 = rest_text_;
        call_then(start_out_ty_of(lx_6, peel(type_at(lx_6, call_4.span))), [=](OutTy out_ty_of_172151) {
        return ({
            auto t = out_ty_of_172151;
            auto caps = fold(keys(env_5->names), Array<std::tuple<Text, Ex, Holding, OutTy>>{}, [&](const Array<std::tuple<Text, Ex, Holding, OutTy>>& acc, const Text& k) {
                return ({
                    __label__ _done;
                    prism_rtl::Slot<Array<std::tuple<Text, Ex, Holding, OutTy>>> _v;
                    auto&& _m = prelude::get(env_5->names, k);
                    if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m))) {
                        auto&& rs = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                        auto&& mode = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a1;
                        auto&& bt = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                        _v.set(((mode == Holding(Holding::ByRef{})) || (mode == Holding(Holding::RcRef{}))) && mentions(rest_text__7, instance_of(k))
                            ? prelude::push(acc, std::tuple{k, rs, mode, bt})
                            : acc);
                        goto _done;
                    }
                    {
                        _v.set(acc);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
            });
            auto dos = each(caps, [&](const std::tuple<Text, Ex, Holding, OutTy>& _p0) {
                auto&& rs = std::get<1>(_p0);
                auto&& mode = std::get<2>(_p0);
                auto&& bt = std::get<3>(_p0);
                return Do(Do::DoLet{Pa(Pa::PaBind{place_stem(rs)}), own(Vl(Vl::VlPlace{rs, mode, bt}))});
            });
            auto env2 = fold(caps, env_5, [&](const Env& en, const std::tuple<Text, Ex, Holding, OutTy>& _p1) {
                auto&& k = std::get<0>(_p1);
                auto&& rs = std::get<1>(_p1);
                auto&& bt = std::get<3>(_p1);
                return bind(en, k, Bn(Bn::BnLocal{Ex(Ex::XVar{place_stem(rs)}), Holding(Holding::Owned{}), bt}));
            });
            auto vals = ({
                __label__ _done;
                prism_rtl::Slot<Array<Ex>> _v;
                if (prism_rtl::is_some(qk_opt)) {
                    auto&& q = prism_rtl::some_of(qk_opt);
                    _v.set(named_args_owned(lx_6, env2, q, args_2));
                    goto _done;
                }
                if (prism_rtl::is_none(qk_opt)) {
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<Array<Ex>> _v;
                        auto&& _m = local_job_fn(lx_6, env2, c_3);
                        if (prism_rtl::is_some(_m)) {
                            auto&& f = prism_rtl::some_of(_m);
                            _v.set(start_args(lx_6, env2, f, args_2));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(run_to_end(each_job(args_2, ({
                                auto lx_6_8 = lx_6;
                                auto env2_8 = env2;
                                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(ast::Arg)>>(prism_rtl::rc([=](ast::Arg p0) {
                                return ({
                                    auto lx_6_8_9 = lx_6_8;
                                    auto env2_8_9 = env2_8;
                                    entered(once_job([=]() {
                                    return ({
                                        auto a = p0;
                                        call_then(start_value_of(lx_6_8_9, env2_8_9, a->value), [=](Vl value_of_172906) { return prism_rtl::finished(own(value_of_172906)); });
                                    });
                                }));
                                });
                            })));
                            }))));
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            auto env3 = bind_span(env2, place_key(lx_6, call_4.span), Vl(Vl::VlOwned{Ex(Ex::XVar{v_}), t}));
            call_value(cont_fn_1(env3), [=](Ex cont_173034) {
            return ({
                auto body = cont_173034;
                auto [job, how] = ({
                    __label__ _done;
                    prism_rtl::Slot<std::tuple<Ex, Text>> _v;
                    if (prism_rtl::is_some(qk_opt)) {
                        auto&& q = prism_rtl::some_of(qk_opt);
                        _v.set(std::tuple{Ex(Ex::XCall{path_in(lx_6, owner_of(q), prism_rtl::cat("start_", base_)), vals}), enters_at_once(lx_6, q, args_2)
                            ? Text::lit("call_value")
                            : Text::lit("call_then")});
                        goto _done;
                    }
                    if (prism_rtl::is_none(qk_opt)) {
                        _v.set(({
                            __label__ _done;
                            prism_rtl::Slot<std::tuple<Ex, Text>> _v;
                            auto&& _m = local_job_fn(lx_6, env2, c_3);
                            if (prism_rtl::is_some(_m)) {
                                auto&& f = prism_rtl::some_of(_m);
                                _v.set(std::tuple{start_call(f, vals), Text::lit("call_value")});
                                goto _done;
                            }
                            if (prism_rtl::is_none(_m)) {
                                _v.set(({
                                    __label__ _done;
                                    prism_rtl::Slot<std::tuple<Ex, Text>> _v;
                                    auto&& _m = prelude_job_call(lx_6, env2, call_4);
                                    if (prism_rtl::is_some(_m)) {
                                        auto&& pj = prism_rtl::some_of(_m);
                                        _v.set(std::tuple{pj, Text::lit("call_value")});
                                        goto _done;
                                    }
                                    if (prism_rtl::is_none(_m)) {
                                        _v.set(std::tuple{refusal(Text::lit("a call this frame cannot enter")), Text::lit("call_then")});
                                        goto _done;
                                    }
                                    prism_rtl::unreachable("no arm matched");
                                _done:
                                    _v.take();
                                }));
                                goto _done;
                            }
                            prism_rtl::unreachable("no arm matched");
                        _done:
                            _v.take();
                        }));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                auto enter = Ex(Ex::XCall{how, Array(std::vector{job, Ex(Ex::XClosure{true, Array(std::vector{Pa(Pa::PaTyped{prism_rtl::rc(Pa(Pa::PaBind{v_})), t})}), prism_rtl::rc(body)})})});
                len(dos) == Nat(0u)
                ? prism_rtl::finished(enter)
                : prism_rtl::finished(Ex(Ex::XBlock{dos, prism_rtl::rc(enter)}));
            });
        });
        });
    });
    });
    })
        : cont_fn(env)->cycle();
    });
}


/// `Start Frame, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Ex> start_frame(Lx lx, Env env, ast::Expr call, Text rest_text_, prism_rtl::Fn<prism_rtl::JobRef<Ex>(Env)> cont_fn) {
    return prism_rtl::make_rc<Frame>(lx, env, call, rest_text_, cont_fn);
}


/// ?LocalJobFn: unbounded fn Lx, Env, Expr -> ?Vl
std::optional<Vl> local_job_fn(const Lx& lx, const Env& env, const ast::Expr& c) {
    auto&& _m = c.kind;
    if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
        auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
        return (len(n->path_) == Nat(1u)) && check_env::has_key(env->names, check_env::sname_key(n))
            ? job_value(name_value(lx, env, n, c.span))
            : std::optional<Vl>{};
    }
    if (prism_rtl::is<ast::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<ast::ExprKind::EGroup>(_m).a0;
        return local_job_fn(lx, env, x);
    }
    if (prism_rtl::is<ast::ExprKind::EField>(_m)) {
        return job_value(value_of(lx, env, c));
    }
    {
        return std::optional<Vl>{};
    }
}


prism_rtl::Turn<std::optional<Vl>> LocalJobFn::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& c = this->c;
    return ({
        auto&& _m = c.kind;
        prism_rtl::is<ast::ExprKind::EName>(_m) ? ({
        auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
        (len(n->path_) == Nat(1u)) && check_env::has_key(env->names, check_env::sname_key(n))
        ? ({
        auto c_1 = c;
        auto env_2 = env;
        auto lx_3 = lx;
        auto n_4 = n;
        call_then(start_name_value(lx_3, env_2, n_4, c_1.span), [=](Vl name_value_173949) { return prism_rtl::finished(job_value(name_value_173949)); });
    })
        : prism_rtl::finished(std::optional<Vl>{});
    })
        : prism_rtl::is<ast::ExprKind::EGroup>(_m) ? ({
        auto&& x = prism_rtl::as<ast::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(LocalJobFn(lx, env, x)));
    })
        : prism_rtl::is<ast::ExprKind::EField>(_m) ? ({
        auto c_1 = c;
        auto env_2 = env;
        auto lx_3 = lx;
        call_then(start_value_of(lx_3, env_2, c_1), [=](Vl value_of_174080) { return prism_rtl::finished(job_value(value_of_174080)); });
    })
        : prism_rtl::finished(std::optional<Vl>{});
    });
}


/// `Start LocalJobFn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<Vl>> start_local_job_fn(Lx lx, Env env, ast::Expr c) {
    return prism_rtl::make_rc<LocalJobFn>(lx, env, c);
}


/// ?JobValue: fn Vl -> ?Vl
std::optional<Vl> job_value(const Vl& f) {
    auto&& _m = value_ty(f);
    if (prism_rtl::is<OutTy::OutJobFn>(_m)) {
        return std::optional(f);
    }
    {
        return std::optional<Vl>{};
    }
}


/// StartCall: fn Vl, [Ex] -> Ex
Ex start_call(const Vl& f, const Array<Ex>& vals) {
    return Ex(Ex::XApply{prism_rtl::rc(ref_(f)), Array(std::vector{one_or_tuple(vals)})});
}


/// OneOrTuple: fn [Ex] -> Ex
Ex one_or_tuple(const Array<Ex>& xs0) {
    {
        auto&& c0_0 = xs0;
        if (c0_0.size() == 1u) {
            {
                auto&& _c1 = index(c0_0, Nat(0u));
                if (prism_rtl::is_some(_c1)) {
                    auto&& one = prism_rtl::some_of(_c1);
                    return one;
                }
            }
        }
    }
    {
        auto&& vals = xs0;
        return Ex(Ex::XTuple{vals});
    }
}


/// CalleeText: fn Expr -> Text
Text callee_text(const ast::Expr& c) {
    auto&& _m = c.kind;
    if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
        auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
        return check_env::dotted(n->path_);
    }
    if (prism_rtl::is<ast::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<ast::ExprKind::EGroup>(_m).a0;
        return callee_text(x);
    }
    {
        return Text::lit("call");
    }
}


/// RestText: fn Lx, Range, Range, Range -> Text
Text rest_text(const Lx& lx, const ast::Range& from, const ast::Range& call, const ast::Range& to) {
    auto&& _m = index(lx.g.srcs, lx->file);
    if (prism_rtl::is_some(_m)) {
        auto&& src = prism_rtl::some_of(_m);
        return check_errors::span_text(src, ast::Range{.start = from.start, .end = to.end});
    }
    if (prism_rtl::is_none(_m)) {
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}


/// Mentions: fn Text, Text -> Bool
bool mentions(const Text& text, const Text& name) {
    auto parts = split(text, name);
    auto last = lexer::dec(len(parts));
    return fold(check_errors::range0(last), false, [&](const bool& found, const Nat& i) {
        return ({
            auto before_ = or_(index(parts, i), Text::lit(""));
            auto after_ = or_(index(parts, i + Nat(1u)), Text::lit(""));
            auto left_word = before_ != Text::lit("")
                ? ends_ident(before_)
                : (i > Nat(0u)) && ends_ident(name);
            auto right_word = after_ != Text::lit("")
                ? starts_ident(after_)
                : ((i + Nat(1u)) < last) && starts_ident(name);
            found || ((!left_word) && (!right_word));
        });
    });
}


/// EndsIdent: fn Text -> Bool
bool ends_ident(const Text& t) {
    return (len_text(t) > Nat(0u)) && lexer::is_ident_char(lexer::last_char(t));
}


/// StartsIdent: fn Text -> Bool
bool starts_ident(const Text& t) {
    return (len_text(t) > Nat(0u)) && lexer::is_ident_char(lexer::head(t));
}


/// TailBody: unbounded fn Lx, Env, FnBody -> Ex
Ex tail_body(const Lx& lx, const Env& env, const ast::FnBody& fn_body2) {
    if (prism_rtl::is<ast::FnBody::BodyExpr>(fn_body2)) {
        auto&& x = prism_rtl::as<ast::FnBody::BodyExpr>(fn_body2).a0;
        return tail(lx, env, x);
    }
    if (prism_rtl::is<ast::FnBody::BodyBlock>(fn_body2)) {
        auto&& b = prism_rtl::as<ast::FnBody::BodyBlock>(fn_body2).a0;
        return tail_block(lx, env, b);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Ex> TailBody::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& fn_body2 = this->fn_body2;
    return ({
        prism_rtl::is<ast::FnBody::BodyExpr>(fn_body2) ? ({
        auto&& x = prism_rtl::as<ast::FnBody::BodyExpr>(fn_body2).a0;
        prism_rtl::more(prism_rtl::rc(Tail(lx, env, x)));
    })
        : prism_rtl::is<ast::FnBody::BodyBlock>(fn_body2) ? ({
        auto&& b = prism_rtl::as<ast::FnBody::BodyBlock>(fn_body2).a0;
        prism_rtl::more(prism_rtl::rc(TailBlock(lx, env, b)));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start TailBody, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Ex> start_tail_body(Lx lx, Env env, ast::FnBody fn_body2) {
    return prism_rtl::make_rc<TailBody>(lx, env, fn_body2);
}


/// TailMatch: unbounded fn Lx, Env, Expr, [Arm], Range -> Ex
Ex tail_match(const Lx& lx, const Env& env, const ast::Expr& s, const Array<ast::Arm>& arms, const ast::Range& span) {
    auto sv = value_of(lx, env, s);
    auto sty = type_at(lx, s.span);
    auto label = prism_rtl::cat("m", span.start);
    auto by_ref = run_to_end(each_job(check_errors::range0(len(arms)), ({
        auto lx_1 = lx;
        auto arms_2 = arms;
        auto sty_3 = sty;
        auto label_4 = label;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<PatOut>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto lx_1_5 = lx_1;
            auto arms_2_5 = arms_2;
            auto sty_3_5 = sty_3;
            auto label_4_5 = label_4;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                (prism_rtl::more(prism_rtl::rc(ArmPat(lx_1_5, or_(index(arms_2_5, i), dummy_arm()).pattern, sty_3_5, Holding(Holding::ByRef{}), prism_rtl::cat(label_4_5, "_", i)))));
            });
        }));
        });
    })));
    })));
    auto chain = fold(by_ref, false, [&](const bool& f, const PatOut& po) { return f || fold(po.conds, false, [&](const bool& f2, const Cc& c) { return f2 || is_let_cond(c); }); });
    auto owned = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        if (prism_rtl::is<Vl::VlOwned>(sv)) {
            _v.set(!chain);
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
    auto pats = owned
        ? run_to_end(each_job(check_errors::range0(len(arms)), ({
        auto lx_1 = lx;
        auto arms_2 = arms;
        auto sty_3 = sty;
        auto label_4 = label;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<PatOut>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto lx_1_5 = lx_1;
            auto arms_2_5 = arms_2;
            auto sty_3_5 = sty_3;
            auto label_4_5 = label_4;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                (prism_rtl::more(prism_rtl::rc(ArmPat(lx_1_5, or_(index(arms_2_5, i), dummy_arm()).pattern, sty_3_5, Holding(Holding::Owned{}), prism_rtl::cat(label_4_5, "_", i)))));
            });
        }));
        });
    })));
    })))
        : by_ref;
    auto xarms = run_to_end(each_job(check_errors::range0(len(arms)), ({
        auto arms_1 = arms;
        auto pats_2 = pats;
        auto env_3 = env;
        auto lx_4 = lx;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<XArm>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto arms_1_5 = arms_1;
            auto pats_2_5 = pats_2;
            auto env_3_5 = env_3;
            auto lx_4_5 = lx_4;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                ({
                auto arm = or_(index(arms_1_5, i), dummy_arm());
                auto po = or_(index(pats_2_5, i), PatOut{.pa = Pa(Pa::PaWild{}), .conds = Array<Cc>{}, .binds = Array<std::tuple<Text, Bn>>{}});
                auto env2 = bind_all(env_3_5, po.binds);
                call_then(start_guard_conds(lx_4_5, env2, arm.guard), [=](Array<Cc> guard_conds_176990) { return call_then(start_tail_block(lx_4_5, env2, arm.body), [=](Ex tail_block_177031) { return prism_rtl::finished(XArm{.pat = po.pa, .conds = append(po.conds, guard_conds_176990), .body = tail_block_177031}); }); });
            });
            });
        }));
        });
    })));
    })));
    auto scrut = owned ? own(sv) : ref_(sv);
    return own(arms_value(scrut, xarms, prism_rtl::cat("'", label), OutTy(OutTy::OutUnknown{Text::lit("the job's turn")})));
}


prism_rtl::Turn<Ex> TailMatch::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& s = this->s;
    const auto& arms = this->arms;
    const auto& span = this->span;
    auto arms_1 = arms;
    auto env_2 = env;
    auto lx_3 = lx;
    auto s_4 = s;
    auto span_5 = span;
    return call_then(start_value_of(lx_3, env_2, s_4), [=](Vl value_of_176212) {
        return ({
            auto sv = value_of_176212;
            auto sty = type_at(lx_3, s_4.span);
            auto label = prism_rtl::cat("m", span_5.start);
            call_value(each_job(check_errors::range0(len(arms_1)), ({
            auto lx_3_6 = lx_3;
            auto arms_1_6 = arms_1;
            auto sty_6 = sty;
            auto label_7 = label;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<PatOut>(Nat)>>(prism_rtl::rc([=](Nat p0) {
            return ({
                auto lx_3_6_8 = lx_3_6;
                auto arms_1_6_8 = arms_1_6;
                auto sty_6_8 = sty_6;
                auto label_7_8 = label_7;
                entered(once_job([=]() {
                return ({
                    auto i = p0;
                    (prism_rtl::more(prism_rtl::rc(ArmPat(lx_3_6_8, or_(index(arms_1_6_8, i), dummy_arm()).pattern, sty_6_8, Holding(Holding::ByRef{}), prism_rtl::cat(label_7_8, "_", i)))));
                });
            }));
            });
        })));
        })), [=](Array<PatOut> each_176311) {
            return ({
                auto by_ref = each_176311;
                auto chain = fold(by_ref, false, [&](const bool& f, const PatOut& po) { return f || fold(po.conds, false, [&](const bool& f2, const Cc& c) { return f2 || is_let_cond(c); }); });
                auto owned = ({
                    __label__ _done;
                    prism_rtl::Slot<bool> _v;
                    if (prism_rtl::is<Vl::VlOwned>(sv)) {
                        _v.set(!chain);
                        goto _done;
                    }
                    {
                        _v.set(false);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                auto pats = owned
                    ? run_to_end(each_job(check_errors::range0(len(arms_1)), ({
                    auto lx_3_6 = lx_3;
                    auto arms_1_6 = arms_1;
                    auto sty_6 = sty;
                    auto label_7 = label;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<PatOut>(Nat)>>(prism_rtl::rc([=](Nat p0) {
                    return ({
                        auto lx_3_6_8 = lx_3_6;
                        auto arms_1_6_8 = arms_1_6;
                        auto sty_6_8 = sty_6;
                        auto label_7_8 = label_7;
                        entered(once_job([=]() {
                        return ({
                            auto i = p0;
                            (prism_rtl::more(prism_rtl::rc(ArmPat(lx_3_6_8, or_(index(arms_1_6_8, i), dummy_arm()).pattern, sty_6_8, Holding(Holding::Owned{}), prism_rtl::cat(label_7_8, "_", i)))));
                        });
                    }));
                    });
                })));
                })))
                    : by_ref;
                call_value(each_job(check_errors::range0(len(arms_1)), ({
                auto arms_1_6 = arms_1;
                auto pats_6 = pats;
                auto env_2_7 = env_2;
                auto lx_3_7 = lx_3;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<XArm>(Nat)>>(prism_rtl::rc([=](Nat p0) {
                return ({
                    auto arms_1_6_7 = arms_1_6;
                    auto pats_6_7 = pats_6;
                    auto env_2_7_7 = env_2_7;
                    auto lx_3_7_7 = lx_3_7;
                    entered(once_job([=]() {
                    return ({
                        auto i = p0;
                        ({
                        auto arm = or_(index(arms_1_6_7, i), dummy_arm());
                        auto po = or_(index(pats_6_7, i), PatOut{.pa = Pa(Pa::PaWild{}), .conds = Array<Cc>{}, .binds = Array<std::tuple<Text, Bn>>{}});
                        auto env2 = bind_all(env_2_7_7, po.binds);
                        call_then(start_guard_conds(lx_3_7_7, env2, arm.guard), [=](Array<Cc> guard_conds_176990) { return call_then(start_tail_block(lx_3_7_7, env2, arm.body), [=](Ex tail_block_177031) { return prism_rtl::finished(XArm{.pat = po.pa, .conds = append(po.conds, guard_conds_176990), .body = tail_block_177031}); }); });
                    });
                    });
                }));
                });
            })));
            })), [=](Array<XArm> each_176757) {
                return ({
                    auto xarms = each_176757;
                    auto scrut = owned ? own(sv) : ref_(sv);
                    (prism_rtl::finished(own(arms_value(scrut, xarms, prism_rtl::cat("'", label), OutTy(OutTy::OutUnknown{Text::lit("the job's turn")})))));
                });
            });
            });
        });
        });
    });
}


/// `Start TailMatch, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Ex> start_tail_match(Lx lx, Env env, ast::Expr s, Array<ast::Arm> arms, ast::Range span) {
    return prism_rtl::make_rc<TailMatch>(lx, env, s, arms, span);
}


/// ?TailCallee: fn Lx, Env, Expr -> ?Text
std::optional<Text> tail_callee(const Lx& lx, const Env& env, const ast::Expr& callee) {
    auto&& _m = callee.kind;
    if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
        auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
        return (len(n->path_) == Nat(1u)) && check_env::has_key(env->names, check_env::sname_key(n))
            ? std::optional<Text>{}
            : ({
            auto&& _qk_opt = check_env::resolve_value(lx.g, lx.home, n);
            auto&& qk_opt = std::get<0>(_qk_opt);
            ({
            __label__ _done;
            prism_rtl::Slot<std::optional<Text>> _v;
            if (prism_rtl::is_some(qk_opt)) {
                auto&& qk = prism_rtl::some_of(qk_opt);
                _v.set(check_types::has_text(lx.unbs, qk) && (!in_prelude(lx, qk))
                    ? std::optional(qk)
                    : std::optional<Text>{});
                goto _done;
            }
            if (prism_rtl::is_none(qk_opt)) {
                _v.set(std::optional<Text>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        });
    }
    {
        return std::optional<Text>{};
    }
}


/// SchemeParts: fn Lx, Text -> (([Ty], Ty))
std::tuple<Array<check_types::Ty>, check_types::Ty> scheme_parts(const Lx& lx, const Text& qk) {
    auto&& _m = prelude::get(lx.g.vals, qk);
    if (prism_rtl::is_some(_m)) {
        auto&& v_ = prism_rtl::some_of(_m);
        auto&& _m = v_.scheme.ty;
        if (prism_rtl::is<check_types::Ty::TyFn>(_m)) {
            auto&& ps = prism_rtl::as<check_types::Ty::TyFn>(_m).a1;
            auto&& r = prism_rtl::as<check_types::Ty::TyFn>(_m).a2;
            return std::tuple{ps, r};
        }
        {
            auto&& other = _m;
            return std::tuple{Array<check_types::Ty>{}, other};
        }
    }
    if (prism_rtl::is_none(_m)) {
        return std::tuple{Array<check_types::Ty>{}, check_types::Ty(check_types::Ty::TyErr{})};
    }
    prism_rtl::unreachable("no arm matched");
}


/// JobFieldNames: unbounded fn Lx, Text -> [Text]
Array<Text> job_field_names(const Lx& lx, const Text& qk) {
    auto clauses = clauses_of(lx.g, qk);
    auto&& _ptys = scheme_parts(lx, qk);
    auto&& ptys = std::get<0>(_ptys);
    auto pts = run_to_end(each_job(ptys, ({
        auto lx_1 = lx;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<OutTy>(check_types::Ty)>>(prism_rtl::rc([=](check_types::Ty p0) {
        return ({
            auto lx_1_2 = lx_1;
            entered(once_job([=]() {
            return ({
                auto p_ = p0;
                (prism_rtl::more(prism_rtl::rc(OutTyOf(lx_1_2, peel(p_)))));
            });
        }));
        });
    })));
    })));
    return each(param_names(lx, clauses, pts), [&](const std::tuple<Text, bool>& _p0) {
        auto&& n = std::get<0>(_p0);
        return n;
    });
}


prism_rtl::Turn<Array<Text>> JobFieldNames::cycle() const {
    const auto& lx = this->lx;
    const auto& qk = this->qk;
    auto clauses = clauses_of(lx.g, qk);
    auto&& _ptys = scheme_parts(lx, qk);
    auto&& ptys = std::get<0>(_ptys);
    auto lx_1 = lx;
    return call_value(each_job(ptys, ({
        auto lx_1_2 = lx_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<OutTy>(check_types::Ty)>>(prism_rtl::rc([=](check_types::Ty p0) {
        return ({
            auto lx_1_2_2 = lx_1_2;
            entered(once_job([=]() {
            return ({
                auto p_ = p0;
                (prism_rtl::more(prism_rtl::rc(OutTyOf(lx_1_2_2, peel(p_)))));
            });
        }));
        });
    })));
    })), [=](Array<OutTy> each_178098) {
        return ({
            auto pts = each_178098;
            (prism_rtl::finished(each(param_names(lx_1, clauses, pts), [&](const std::tuple<Text, bool>& _p0) {
            auto&& n = std::get<0>(_p0);
            return n;
        })));
        });
    });
}


/// `Start JobFieldNames, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_job_field_names(Lx lx, Text qk) {
    return prism_rtl::make_rc<JobFieldNames>(lx, qk);
}


/// ClausesOf: fn G, Text -> [FnClause]
Array<ast::FnClause> clauses_of(const check_env::G& g, const Text& qk) {
    return fold(g.defs, Array<ast::FnClause>{}, [&](const Array<ast::FnClause>& acc, const check_env::Def& d) { return d.qk == qk ? def_clauses(d, acc) : acc; });
}


/// DefClauses: fn Def, [FnClause] -> [FnClause]
Array<ast::FnClause> def_clauses(const check_env::Def& d, const Array<ast::FnClause>& other) {
    auto&& _m = d.body;
    if (prism_rtl::is<check_env::DefBody::DbFn>(_m)) {
        auto&& cs = prism_rtl::as<check_env::DefBody::DbFn>(_m).a0;
        return cs;
    }
    {
        return other;
    }
}


/// JobDefOf: unbounded fn Lx, Text, [FnClause], Scheme -> JobDef
JobDef job_def_of(const Lx& lx, const Text& qk, const Array<ast::FnClause>& clauses, const check_types::Scheme& sc) {
    auto [ptys, res] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Array<check_types::Ty>, check_types::Ty>> _v;
        auto&& _m = sc.ty;
        if (prism_rtl::is<check_types::Ty::TyFn>(_m)) {
            auto&& ps = prism_rtl::as<check_types::Ty::TyFn>(_m).a1;
            auto&& r = prism_rtl::as<check_types::Ty::TyFn>(_m).a2;
            _v.set(std::tuple{ps, r});
            goto _done;
        }
        {
            auto&& other = _m;
            _v.set(std::tuple{Array<check_types::Ty>{}, other});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto pts = run_to_end(each_job(ptys, ({
        auto lx_1 = lx;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<OutTy>(check_types::Ty)>>(prism_rtl::rc([=](check_types::Ty p0) {
        return ({
            auto lx_1_2 = lx_1;
            entered(once_job([=]() {
            return ({
                auto p_ = p0;
                (prism_rtl::more(prism_rtl::rc(OutTyOf(lx_1_2, peel(p_)))));
            });
        }));
        });
    })));
    })));
    auto names = param_names(lx, clauses, pts);
    auto body = job_clauses(lx, clauses, names, ptys, pts);
    auto base_ = or_(prelude::get(lx.rs_names, qk), snake(check_types::bare_name(qk)));
    return JobDef{.name = camel(check_types::bare_name(qk)), .start = prism_rtl::cat("start_", base_), .generics = scheme_generics(lx, sc), .fields = each(check_errors::range0(len(pts)), [&](const Nat& i) {
        return std::tuple{or_(index(each(names, [&](const std::tuple<Text, bool>& _p0) {
            auto&& n = std::get<0>(_p0);
            return n;
        }), i), Text::lit("arg")), or_(index(pts, i), OutTy(OutTy::OutUnit{}))};
    }), .ret = out_ty_of(lx, peel(res)), .body = body, .doc = signature_text(lx, qk)};
}


prism_rtl::Turn<JobDef> JobDefOf::cycle() const {
    const auto& lx = this->lx;
    const auto& qk = this->qk;
    const auto& clauses = this->clauses;
    const auto& sc = this->sc;
    auto [ptys, res] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Array<check_types::Ty>, check_types::Ty>> _v;
        auto&& _m = sc.ty;
        if (prism_rtl::is<check_types::Ty::TyFn>(_m)) {
            auto&& ps = prism_rtl::as<check_types::Ty::TyFn>(_m).a1;
            auto&& r = prism_rtl::as<check_types::Ty::TyFn>(_m).a2;
            _v.set(std::tuple{ps, r});
            goto _done;
        }
        {
            auto&& other = _m;
            _v.set(std::tuple{Array<check_types::Ty>{}, other});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto clauses_1 = clauses;
    auto lx_2 = lx;
    auto qk_3 = qk;
    auto sc_4 = sc;
    return call_value(each_job(ptys, ({
        auto lx_2_5 = lx_2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<OutTy>(check_types::Ty)>>(prism_rtl::rc([=](check_types::Ty p0) {
        return ({
            auto lx_2_5_5 = lx_2_5;
            entered(once_job([=]() {
            return ({
                auto p_ = p0;
                (prism_rtl::more(prism_rtl::rc(OutTyOf(lx_2_5_5, peel(p_)))));
            });
        }));
        });
    })));
    })), [=](Array<OutTy> each_178752) {
        return ({
            auto pts = each_178752;
            auto names = param_names(lx_2, clauses_1, pts);
            call_then(start_job_clauses(lx_2, clauses_1, names, ptys, pts), [=](Ex job_clauses_178848) {
            return ({
                auto body = job_clauses_178848;
                auto base_ = or_(prelude::get(lx_2.rs_names, qk_3), snake(check_types::bare_name(qk_3)));
                call_then(start_out_ty_of(lx_2, peel(res)), [=](OutTy out_ty_of_179159) {
                return prism_rtl::finished(JobDef{.name = camel(check_types::bare_name(qk_3)), .start = prism_rtl::cat("start_", base_), .generics = scheme_generics(lx_2, sc_4), .fields = each(check_errors::range0(len(pts)), [&](const Nat& i) {
                    return std::tuple{or_(index(each(names, [&](const std::tuple<Text, bool>& _p0) {
                        auto&& n = std::get<0>(_p0);
                        return n;
                    }), i), Text::lit("arg")), or_(index(pts, i), OutTy(OutTy::OutUnit{}))};
                }), .ret = out_ty_of_179159, .body = body, .doc = signature_text(lx_2, qk_3)});
            });
            });
        });
        });
    });
}


/// `Start JobDefOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<JobDef> start_job_def_of(Lx lx, Text qk, Array<ast::FnClause> clauses, check_types::Scheme sc) {
    return prism_rtl::make_rc<JobDefOf>(lx, qk, clauses, sc);
}


/// JobClauses: unbounded fn Lx, [FnClause], [((Text, Bool))], [Ty], [OutTy] -> Ex
Ex job_clauses(const Lx& lx, const Array<ast::FnClause>& clauses, const Array<std::tuple<Text, bool>>& names, const Array<check_types::Ty>& ptys, const Array<OutTy>& pts) {
    auto lets = each(check_errors::range0(len(names)), [&](const Nat& i) {
        return ({
            auto&& _rs = or_(index(names, i), std::tuple{Text::lit("arg"), true});
            auto&& rs = std::get<0>(_rs);
            (Do(Do::DoLet{Pa(Pa::PaBind{rs}), Ex(Ex::XRef{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), rs}))})}));
        });
    });
    auto inner = clauses_body(lx, empty_env(), clauses, names, ptys, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Lx, Env, ast::FnBody>)>>(prism_rtl::rc([&](std::tuple<Lx, Env, ast::FnBody> _p0) {
        auto&& a0 = std::get<0>(_p0);
        auto&& a1 = std::get<1>(_p0);
        auto&& a2 = std::get<2>(_p0);
        return entered(start_tail_body(a0, a1, a2));
    })), Text::lit("j"), OutTy(OutTy::OutUnknown{Text::lit("the job's turn")}));
    return Ex(Ex::XBlock{lets, prism_rtl::rc(inner)});
}


prism_rtl::Turn<Ex> JobClauses::cycle() const {
    const auto& lx = this->lx;
    const auto& clauses = this->clauses;
    const auto& names = this->names;
    const auto& ptys = this->ptys;
    const auto& pts = this->pts;
    auto lets = each(check_errors::range0(len(names)), [&](const Nat& i) {
        return ({
            auto&& _rs = or_(index(names, i), std::tuple{Text::lit("arg"), true});
            auto&& rs = std::get<0>(_rs);
            (Do(Do::DoLet{Pa(Pa::PaBind{rs}), Ex(Ex::XRef{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), rs}))})}));
        });
    });
    auto clauses_1 = clauses;
    auto lx_2 = lx;
    auto names_3 = names;
    auto ptys_4 = ptys;
    return call_then(start_clauses_body(lx_2, empty_env(), clauses_1, names_3, ptys_4, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Lx, Env, ast::FnBody>)>>(prism_rtl::rc([&](std::tuple<Lx, Env, ast::FnBody> _p0) {
        auto&& a0 = std::get<0>(_p0);
        auto&& a1 = std::get<1>(_p0);
        auto&& a2 = std::get<2>(_p0);
        return entered(start_tail_body(a0, a1, a2));
    })), Text::lit("j"), OutTy(OutTy::OutUnknown{Text::lit("the job's turn")})), [=](Ex clauses_body_179588) {
        return ({
            auto inner = clauses_body_179588;
            (prism_rtl::finished(Ex(Ex::XBlock{lets, prism_rtl::rc(inner)})));
        });
    });
}


/// `Start JobClauses, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Ex> start_job_clauses(Lx lx, Array<ast::FnClause> clauses, Array<std::tuple<Text, bool>> names, Array<check_types::Ty> ptys, Array<OutTy> pts) {
    return prism_rtl::make_rc<JobClauses>(lx, clauses, names, ptys, pts);
}


/// IdPipe: unbounded fn Ex, (unbounded fn Ex -> [Do]) -> [Do]
Array<Do> id_pipe(const Ex& x, const prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(Ex)>& k_fn) {
    return run_to_end(k_fn(x));
}


prism_rtl::Turn<Array<Do>> IdPipe::cycle() const {
    const auto& x = this->x;
    const auto& k_fn = this->k_fn;
    return k_fn(x)->cycle();
}


/// `Start IdPipe, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Do>> start_id_pipe(Ex x, prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(Ex)> k_fn) {
    return prism_rtl::make_rc<IdPipe>(x, k_fn);
}


/// EvRefOf: fn Wx, Nat -> EvRef
EvRef ev_ref_of(const Wx& wx, const Nat& n) {
    return EvRef{.node_ = n, .owner = wx.node_, .pipe = static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(std::tuple<Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(Ex)>>)>>(prism_rtl::rc([&](std::tuple<Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(Ex)>> _p0) {
        auto&& a0 = std::get<0>(_p0);
        auto&& a1 = std::get<1>(_p0);
        return entered(start_id_pipe(a0, a1));
    }))};
}


/// KindWord: fn GnKind -> Text
Text kind_word(const GnKind& k) {
    if (prism_rtl::is<GnKind::GnNamed>(k)) {
        return Text::lit("named");
    }
    if (prism_rtl::is<GnKind::GnAnswer>(k)) {
        return Text::lit("answer");
    }
    if (prism_rtl::is<GnKind::GnStarted>(k)) {
        return Text::lit("started");
    }
    if (prism_rtl::is<GnKind::GnDeferred>(k)) {
        return Text::lit("deferred");
    }
    if (prism_rtl::is<GnKind::GnPort>(k)) {
        return Text::lit("port");
    }
    if (prism_rtl::is<GnKind::GnMerge>(k)) {
        return Text::lit("merge");
    }
    if (prism_rtl::is<GnKind::GnUnion>(k)) {
        return Text::lit("union");
    }
    if (prism_rtl::is<GnKind::GnBoth>(k)) {
        return Text::lit("both");
    }
    if (prism_rtl::is<GnKind::GnExcept>(k)) {
        return Text::lit("except");
    }
    if (prism_rtl::is<GnKind::GnMergeAll>(k)) {
        return Text::lit("mergeall");
    }
    if (prism_rtl::is<GnKind::GnGather>(k)) {
        return Text::lit("gather");
    }
    if (prism_rtl::is<GnKind::GnUpdated>(k)) {
        return Text::lit("updated");
    }
    if (prism_rtl::is<GnKind::GnNever>(k)) {
        return Text::lit("never");
    }
    prism_rtl::unreachable("no arm matched");
}


/// HasRead: fn [Read], Read -> Bool
bool has_read(const Array<Read>& rs, const Read& r) {
    return fold(rs, false, [&](const bool& seen, const Read& x) { return seen || (x == r); });
}


/// AddRead: fn [Read], Read -> [Read]
Array<Read> add_read(const Array<Read>& rs, const Read& r) {
    return has_read(rs, r) ? rs : prelude::push(rs, r);
}


/// UnionReads: fn [Read], [Read] -> [Read]
Array<Read> union_reads(const Array<Read>& xs, const Array<Read>& ys) {
    return fold(ys, xs, [&](const Array<Read>& acc, const Read& y) { return add_read(acc, y); });
}


/// let nodeHooks
Array<Text> node_hooks() {
    return Array(std::vector{Text::lit("path"), Text::lit("build"), Text::lit("wake"), Text::lit("started"), Text::lit("deferred"), Text::lit("answer"), Text::lit("push"), Text::lit("swap"), Text::lit("leave"), Text::lit("patch"), Text::lit("clean_up"), Text::lit("edges"), Text::lit("release"), Text::lit("leave_row"), Text::lit("remove_places")});
}


/// NewWx: fn Lx, Text, [((Text, OutTy, Text))], [((Text, Ex))], [((Text, Ex))], [MethDef], (Text ==> [Read]), [Text], Nat, ?Text -> Wx
Wx new_wx(const Lx& lx, const Text& name, const Array<std::tuple<Text, OutTy, Text>>& fields, const Array<std::tuple<Text, Ex>>& inits, const Array<std::tuple<Text, Ex>>& moves_, const Array<MethDef>& getters, const Map<Text, Array<Read>>& dyn_reads, const Array<Text>& taken, const Nat& depth, const std::optional<Text>& hosted_by_opt) {
    auto hosted_fields = ({
        __label__ _done;
        prism_rtl::Slot<Array<std::tuple<Text, OutTy, Text>>> _v;
        if (prism_rtl::is_some(hosted_by_opt)) {
            _v.set(Array(std::vector{std::tuple{Text::lit("enclosing"), host_of_ty(), Text::lit("the host whose document this row's places are entries of (pick HO)")}}));
            goto _done;
        }
        if (prism_rtl::is_none(hosted_by_opt)) {
            _v.set(Array<std::tuple<Text, OutTy, Text>>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto hosted_inits = ({
        __label__ _done;
        prism_rtl::Slot<Array<std::tuple<Text, Ex>>> _v;
        if (prism_rtl::is_some(hosted_by_opt)) {
            _v.set(Array(std::vector{std::tuple{Text::lit("enclosing"), Ex(Ex::XVar{Text::lit("enclosing")})}}));
            goto _done;
        }
        if (prism_rtl::is_none(hosted_by_opt)) {
            _v.set(Array<std::tuple<Text, Ex>>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return Wx{.lx = lx, .node_ = name, .pos = pos0(), .gns = Array<Gn>{}, .fields = append(fields, hosted_fields), .inits = inits, .moves = append(moves_, hosted_inits), .lets = Array<Do>{}, .build = Array<Do>{}, .places = Array<Place>{}, .answers = Array<std::tuple<Pos_, Nat, OutTy, Text>>{}, .started = Array<Nat>{}, .defers = Array<std::tuple<Text, Nat>>{}, .getters = getters, .dyn_reads = dyn_reads, .taken = prelude::push(taken, Text::lit("enclosing")), .fallible = false, .depth = depth, .result = Wres(Wres::WrUnit{}), .rows = Array<NodeDef>{}, .builders = Array<ForDef>{}, .build_holds = Array<Read>{}, .up_sink = Text::lit(""), .gens = Array<GenDef>{}, .gen_holds = Array<std::tuple<Text, Array<Read>>>{}, .ports = Array<Text>{}, .subs = Array<std::tuple<Text, Text, OutTy>>{}, .parent_env = empty_env(), .hosts = Array<HostDef>{}, .dyn_places = Array<std::tuple<Pos_, Text, OutTy, Text>>{}, .scopes = Array<Text>{}, .hosted_by = hosted_by_opt, .root_dyn = std::optional<std::tuple<Ex, Array<Read>, OutTy>>{}, .row_marks = Array<RowMarks>{}, .pending = Array<PendingRow>{}, .floors = Map<Text, Nat>{}, .snaps = Array<SnapDef>{}, .result_moved = std::optional<std::tuple<Text, Array<Read>>>{}, .dyn_answers = Array<std::tuple<Text, Array<Read>>>{}, .inited = Array<Text>{}, .flattens = Array<FlatDef>{}};
}


/// FreshName: fn Wx, Text -> ((Text, Wx))
std::tuple<Text, Wx> fresh_name(const Wx& wx, const Text& base_) {
    auto pick = !check_types::has_text(wx.taken, base_)
        ? base_
        : prism_rtl::cat(base_, "_", first_free(wx.taken, base_, Nat(2u)));
    auto wx2 = ({
        Wx this_ = wx;
        this_.taken = prelude::push(this_.taken, pick);
        this_;
    });
    return std::tuple{pick, wx2};
}


/// FirstFree: fn [Text], Text, Nat -> Nat
Nat first_free(const Array<Text>& taken, const Text& base_, const Nat& from) {
    return fold(check_errors::range0(len(taken)), from, [&](const Nat& n, const Nat& _p1) {
        return check_types::has_text(taken, prism_rtl::cat(base_, "_", n))
            ? n + Nat(1u)
            : n;
    });
}


/// AddGn: fn Wx, Text, OutTy, GnKind, Nat -> ((Nat, Wx))
std::tuple<Nat, Wx> add_gn(const Wx& wx, const Text& name, const OutTy& ty, const GnKind& kind, const Nat& height) {
    auto id = len(wx.gns);
    auto wx2 = ({
        Wx this_ = wx;
        this_.gns = prelude::push(this_.gns, Gn{.id = id, .name = name, .ty = ty, .kind = kind, .height = height, .inputs = Array<Text>{}, .reads = Array<Read>{}, .floor = Nat(0u), .outs = Array<Out>{}});
        this_;
    });
    return std::tuple{id, wx2};
}


/// Connect: fn Wx, EvRef, Sk -> Wx
Wx connect(const Wx& wx, const EvRef& r, const Sk& sink) {
    return r.owner != wx.node_
        ? crossed(wx, prism_rtl::cat("an event of node `", r.owner, "` (its graph node ", r.node_, ")"))
        : ({
        Wx this_ = wx;
        this_.gns = each(this_.gns, [&](const Gn& n) { return n.id == r.node_ ? add_out(n, Out{.pipe = r.pipe, .sink = sink}) : n; });
        this_;
    });
}


/// Crossed: fn Wx, Text -> Wx
Wx crossed(const Wx& wx, const Text& what) {
    Wx this_ = wx;
    this_.build = prelude::push(this_.build, Do(Do::DoExpr{refusal(prism_rtl::cat(what, " read in node `", wx.node_, "` without a port (a lowering bug)"))}));
    return this_;
}


/// AddOut: fn Gn, Out -> Gn
Gn add_out(const Gn& n, const Out& o) {
    Gn this_ = n;
    this_.outs = prelude::push(this_.outs, o);
    return this_;
}


/// AddField: fn Wx, Text, OutTy, Text, Ex -> Wx
Wx add_field(const Wx& wx, const Text& name, const OutTy& t, const Text& doc, const Ex& init) {
    Wx this_ = wx;
    this_.fields = prelude::push(this_.fields, std::tuple{name, t, doc});
    this_.inits = prelude::push(this_.inits, std::tuple{name, init});
    return this_;
}


/// AddFieldLast: fn Wx, Text, OutTy, Text, Ex -> Wx
Wx add_field_last(const Wx& wx, const Text& name, const OutTy& t, const Text& doc, const Ex& init) {
    Wx this_ = wx;
    this_.fields = prelude::push(this_.fields, std::tuple{name, t, doc});
    this_.moves = prelude::push(this_.moves, std::tuple{name, init});
    return this_;
}


/// GnOf: fn Wx, Nat -> Gn
Gn gn_of(const Wx& wx, const Nat& n) {
    return or_(index(wx.gns, n), Gn{.id = n, .name = Text::lit("never"), .ty = OutTy(OutTy::OutUnit{}), .kind = GnKind(GnKind::GnNever{}), .height = Nat(0u), .inputs = Array<Text>{}, .reads = Array<Read>{}, .floor = Nat(0u), .outs = Array<Out>{}});
}


/// BindPlain: fn Env, Env, Text, Text, OutTy -> ((Env, Env))
std::tuple<Env, Env> bind_plain(const Env& benv, const Env& menv, const Text& nkey, const Text& rs, const OutTy& t) {
    return std::tuple{bind(benv, nkey, Bn(Bn::BnLocal{Ex(Ex::XVar{rs}), Holding(Holding::Owned{}), t})), bind(menv, nkey, Bn(Bn::BnLocal{Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), rs}), Holding(Holding::Owned{}), t}))};
}


/// NodeDefOf: unbounded fn Lx, Text, [Pattern], Block, Scheme, Bool -> NodeDef
NodeDef node_def_of(const Lx& lx, const Text& qk, const Array<ast::Pattern_>& params, const ast::Block& body, const check_types::Scheme& sc, const bool& is_root) {
    auto name = camel(check_types::bare_name(qk));
    auto ptys = ({
        __label__ _done;
        prism_rtl::Slot<Array<check_types::Ty>> _v;
        auto&& _m = sc.ty;
        if (prism_rtl::is<check_types::Ty::TyFn>(_m)) {
            auto&& ps = prism_rtl::as<check_types::Ty::TyFn>(_m).a1;
            _v.set(ps);
            goto _done;
        }
        {
            _v.set(Array<check_types::Ty>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto wx0 = new_wx(lx, name, Array<std::tuple<Text, OutTy, Text>>{}, Array<std::tuple<Text, Ex>>{}, Array<std::tuple<Text, Ex>>{}, Array<MethDef>{}, Map<Text, Array<Read>>{}, node_hooks(), Nat(0u), std::optional<Text>{});
    auto [ps, wx1, benv, menv] = run_to_end(fold_job(check_errors::range0(len(params)), std::tuple{Array<std::tuple<Text, OutTy>>{}, wx0, empty_env(), empty_env()}, ({
        auto params_1 = params;
        auto lx_2 = lx;
        auto ptys_3 = ptys;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, OutTy>>, Wx, Env, Env>>(std::tuple<std::tuple<Array<std::tuple<Text, OutTy>>, Wx, Env, Env>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<std::tuple<Text, OutTy>>, Wx, Env, Env>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto params_1_4 = params_1;
            auto lx_2_4 = lx_2;
            auto ptys_3_4 = ptys_3;
            entered(once_job([=]() {
            return ({
                auto [acc, w, be, me] = p0;
                auto i = p1;
                ({
                auto p_ = or_(index(params_1_4, i), dummy_pat());
                auto nkey = plain_binder(lx_2_4, p_);
                auto base_ = nkey == Text::lit("") ? prism_rtl::cat("arg", i) : snake(nkey);
                auto [rs, w2] = fresh_name(w, base_);
                call_then(start_out_ty_of(lx_2_4, peel(or_(index(ptys_3_4, i), check_types::Ty(check_types::Ty::TyErr{})))), [=](OutTy out_ty_of_195487) {
                return ({
                    auto t = out_ty_of_195487;
                    auto w3 = ({
                        Wx this_ = w2;
                        this_.fields = prelude::push(this_.fields, std::tuple{rs, t, Text::lit("a parameter")});
                        this_.inits = prelude::push(this_.inits, std::tuple{rs, Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{rs}))})});
                        this_;
                    });
                    auto [be2, me2] = bind_plain(be, me, nkey, rs, t);
                    (prism_rtl::finished(std::tuple{prelude::push(acc, std::tuple{rs, t}), w3, be2, me2}));
                });
            });
            });
            });
        }));
        });
    }));
    })));
    auto wx2 = block_into(wx1, benv, menv, body);
    auto wx3 = is_root ? root_result(wx2) : wx2;
    return finish_node(wx3, qk, ps, false);
}


prism_rtl::Turn<NodeDef> NodeDefOf::cycle() const {
    const auto& lx = this->lx;
    const auto& qk = this->qk;
    const auto& params = this->params;
    const auto& body = this->body;
    const auto& sc = this->sc;
    const auto& is_root = this->is_root;
    auto name = camel(check_types::bare_name(qk));
    auto ptys = ({
        __label__ _done;
        prism_rtl::Slot<Array<check_types::Ty>> _v;
        auto&& _m = sc.ty;
        if (prism_rtl::is<check_types::Ty::TyFn>(_m)) {
            auto&& ps = prism_rtl::as<check_types::Ty::TyFn>(_m).a1;
            _v.set(ps);
            goto _done;
        }
        {
            _v.set(Array<check_types::Ty>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto wx0 = new_wx(lx, name, Array<std::tuple<Text, OutTy, Text>>{}, Array<std::tuple<Text, Ex>>{}, Array<std::tuple<Text, Ex>>{}, Array<MethDef>{}, Map<Text, Array<Read>>{}, node_hooks(), Nat(0u), std::optional<Text>{});
    auto body_1 = body;
    auto is_root_2 = is_root;
    auto lx_3 = lx;
    auto params_4 = params;
    auto qk_5 = qk;
    return call_value(fold_job(check_errors::range0(len(params_4)), std::tuple{Array<std::tuple<Text, OutTy>>{}, wx0, empty_env(), empty_env()}, ({
        auto params_4_6 = params_4;
        auto lx_3_6 = lx_3;
        auto ptys_6 = ptys;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, OutTy>>, Wx, Env, Env>>(std::tuple<std::tuple<Array<std::tuple<Text, OutTy>>, Wx, Env, Env>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<std::tuple<Text, OutTy>>, Wx, Env, Env>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto params_4_6_7 = params_4_6;
            auto lx_3_6_7 = lx_3_6;
            auto ptys_6_7 = ptys_6;
            entered(once_job([=]() {
            return ({
                auto [acc, w, be, me] = p0;
                auto i = p1;
                ({
                auto p_ = or_(index(params_4_6_7, i), dummy_pat());
                auto nkey = plain_binder(lx_3_6_7, p_);
                auto base_ = nkey == Text::lit("") ? prism_rtl::cat("arg", i) : snake(nkey);
                auto [rs, w2] = fresh_name(w, base_);
                call_then(start_out_ty_of(lx_3_6_7, peel(or_(index(ptys_6_7, i), check_types::Ty(check_types::Ty::TyErr{})))), [=](OutTy out_ty_of_195487) {
                return ({
                    auto t = out_ty_of_195487;
                    auto w3 = ({
                        Wx this_ = w2;
                        this_.fields = prelude::push(this_.fields, std::tuple{rs, t, Text::lit("a parameter")});
                        this_.inits = prelude::push(this_.inits, std::tuple{rs, Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{rs}))})});
                        this_;
                    });
                    auto [be2, me2] = bind_plain(be, me, nkey, rs, t);
                    (prism_rtl::finished(std::tuple{prelude::push(acc, std::tuple{rs, t}), w3, be2, me2}));
                });
            });
            });
            });
        }));
        });
    }));
    })), [=](std::tuple<Array<std::tuple<Text, OutTy>>, Wx, Env, Env> fold_195204) {
        return ({
            auto [ps, wx1, benv, menv] = fold_195204;
            call_then(start_block_into(wx1, benv, menv, body_1), [=](Wx block_into_195805) {
            return ({
                auto wx2 = block_into_195805;
                auto wx3 = is_root_2 ? root_result(wx2) : wx2;
                (prism_rtl::more(prism_rtl::rc(FinishNode(wx3, qk_5, ps, false))));
            });
        });
        });
    });
}


/// `Start NodeDefOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<NodeDef> start_node_def_of(Lx lx, Text qk, Array<ast::Pattern_> params, ast::Block body, check_types::Scheme sc, bool is_root) {
    return prism_rtl::make_rc<NodeDefOf>(lx, qk, params, body, sc, is_root);
}


/// RootResult: fn Wx -> Wx
Wx root_result(const Wx& wx) {
    auto&& _m = wx->result;
    if (prism_rtl::is<Wres::WrEv>(_m)) {
        auto&& r = prism_rtl::as<Wres::WrEv>(_m).a0;
        return connect(wx, r, Sk(Sk::SkResult{}));
    }
    if (prism_rtl::is<Wres::WrDyn>(_m)) {
        auto&& x = prism_rtl::as<Wres::WrDyn>(_m).a0;
        auto&& rds = prism_rtl::as<Wres::WrDyn>(_m).a1;
        auto&& t = prism_rtl::as<Wres::WrDyn>(_m).a2;
        Wx this_ = wx;
        this_.root_dyn = std::optional(std::tuple{x, rds, t});
        this_.getters = prelude::push(this_.getters, MethDef{.name = Text::lit("result_value"), .recv = Recv(Recv::RecvRef{}), .params = Array<std::tuple<Text, OutTy>>{}, .cx_ = CxArg(CxArg::CxRef{}), .ret = OutTy(OutTy::OutPod{}), .body = Array<Do>{}, .tail = Ex(Ex::XMethod{prism_rtl::rc(x), Text::lit("to_pod"), Array<Ex>{}}), .doc = Text::lit("The root's dynamic result, pulled after the tick.")});
        this_.fields = prelude::push(this_.fields, std::tuple{Text::lit("result_last"), OutTy(OutTy::OutCell{prism_rtl::rc(OutTy(OutTy::OutOpt{prism_rtl::rc(OutTy(OutTy::OutPod{}))}))}), Text::lit("the result the World last heard")});
        this_.moves = prelude::push(this_.moves, std::tuple{Text::lit("result_last"), Ex(Ex::XCall{Text::lit("RefCell::new"), Array(std::vector{Ex(Ex::XNone{})})})});
        this_.build = prelude::push(this_.build, Do(Do::DoScope{result_told(Ex(Ex::XVar{Text::lit("node")}))}));
        return this_;
    }
    if (prism_rtl::is<Wres::WrPlain>(_m)) {
        auto&& x = prism_rtl::as<Wres::WrPlain>(_m).a0;
        Wx this_ = wx;
        this_.build = prelude::push(this_.build, Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XCx{})), Text::lit("result"), Array(std::vector{Ex(Ex::XCtor{Text::lit("Outcome::Value"), Array(std::vector{Ex(Ex::XMethod{prism_rtl::rc(x), Text::lit("to_pod"), Array<Ex>{}})})})})})}));
        return this_;
    }
    {
        return wx;
    }
}


/// BlockInto: unbounded fn Wx, Env, Env, Block -> Wx
Wx block_into(const Wx& wx, const Env& benv, const Env& menv, const ast::Block& b) {
    auto [wx1, be1, me1] = run_to_end(fold_job(b.stmts, std::tuple{wx, benv, menv}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Wx, Env, Env>>(std::tuple<std::tuple<Wx, Env, Env>, ast::Stmt>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Wx, Env, Env>, ast::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto [w, be, me] = p0;
                auto s = p1;
                (prism_rtl::more(prism_rtl::rc(PreBind(w, be, me, s))));
            });
        }));
    }))));
    auto n = len(b.stmts);
    auto&& _wx2 = run_to_end(fold_job(check_errors::range0(n), std::tuple{wx1, be1, me1}, ({
        auto b_1 = b;
        auto n_2 = n;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Wx, Env, Env>>(std::tuple<std::tuple<Wx, Env, Env>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Wx, Env, Env>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto b_1_3 = b_1;
            auto n_2_3 = n_2;
            entered(once_job([=]() {
            return ({
                auto [w, be, me] = p0;
                auto i = p1;
                (prism_rtl::more(prism_rtl::rc(WidgetStmt(w, be, me, or_(index(b_1_3.stmts, i), dummy_stmt_l()), (i + Nat(1u)) == n_2_3))));
            });
        }));
        });
    }));
    })));
    auto&& wx2 = std::get<0>(_wx2);
    return wx2;
}


prism_rtl::Turn<Wx> BlockInto::cycle() const {
    const auto& wx = this->wx;
    const auto& benv = this->benv;
    const auto& menv = this->menv;
    const auto& b = this->b;
    auto b_1 = b;
    auto benv_2 = benv;
    auto menv_3 = menv;
    auto wx_4 = wx;
    return call_value(fold_job(b_1.stmts, std::tuple{wx_4, benv_2, menv_3}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Wx, Env, Env>>(std::tuple<std::tuple<Wx, Env, Env>, ast::Stmt>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Wx, Env, Env>, ast::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto [w, be, me] = p0;
                auto s = p1;
                (prism_rtl::more(prism_rtl::rc(PreBind(w, be, me, s))));
            });
        }));
    }))), [=](std::tuple<Wx, Env, Env> fold_197126) {
        return ({
            auto [wx1, be1, me1] = fold_197126;
            auto n = len(b_1.stmts);
            call_value(fold_job(check_errors::range0(n), std::tuple{wx1, be1, me1}, ({
            auto b_1_5 = b_1;
            auto n_5 = n;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Wx, Env, Env>>(std::tuple<std::tuple<Wx, Env, Env>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Wx, Env, Env>, Nat> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto b_1_5_6 = b_1_5;
                auto n_5_6 = n_5;
                entered(once_job([=]() {
                return ({
                    auto [w, be, me] = p0;
                    auto i = p1;
                    (prism_rtl::more(prism_rtl::rc(WidgetStmt(w, be, me, or_(index(b_1_5_6.stmts, i), dummy_stmt_l()), (i + Nat(1u)) == n_5_6))));
                });
            }));
            });
        }));
        })), [=](std::tuple<Wx, Env, Env> fold_197259) {
            return ({
                auto&& _wx2 = fold_197259;
                auto&& wx2 = std::get<0>(_wx2);
                (prism_rtl::finished(wx2));
            });
        });
        });
    });
}


/// `Start BlockInto, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Wx> start_block_into(Wx wx, Env benv, Env menv, ast::Block b) {
    return prism_rtl::make_rc<BlockInto>(wx, benv, menv, b);
}


/// PreBind: unbounded fn Wx, Env, Env, Stmt -> ((Wx, Env, Env))
std::tuple<Wx, Env, Env> pre_bind(const Wx& wx, const Env& benv, const Env& menv, const ast::Stmt& s) {
    auto&& _m = s.kind;
    if (prism_rtl::is<ast::StmtKind::SBind>(_m)) {
        auto&& p_ = prism_rtl::as<ast::StmtKind::SBind>(_m).a0;
        auto&& init = prism_rtl::as<ast::StmtKind::SBind>(_m).a1;
        auto&& step_opt = prism_rtl::as<ast::StmtKind::SBind>(_m).a2;
        auto&& _m = p_.kind;
        if (prism_rtl::is<ast::PatternKind::PName>(_m)) {
            auto&& n = prism_rtl::as<ast::PatternKind::PName>(_m).a0;
            return pre_bind_name(wx, benv, menv, n, how_bound(step_opt));
        }
        if (prism_rtl::is<ast::PatternKind::PTuple>(_m)) {
            auto&& ps = prism_rtl::as<ast::PatternKind::PTuple>(_m).a0;
            return run_to_end(fold_job(ps, std::tuple{wx, benv, menv}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Wx, Env, Env>>(std::tuple<std::tuple<Wx, Env, Env>, ast::Pattern_>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Wx, Env, Env>, ast::Pattern_> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return entered(once_job([=]() {
                    return ({
                        auto [w, be, me] = p0;
                        auto q = p1;
                        ({
                        auto&& _m = q.kind;
                        prism_rtl::is<ast::PatternKind::PName>(_m) ? ({
                        auto&& n = prism_rtl::as<ast::PatternKind::PName>(_m).a0;
                        prism_rtl::more(prism_rtl::rc(PreBindName(w, be, me, n, HowBound(HowBound::AsBind{}))));
                    })
                        : prism_rtl::finished(std::tuple{w, be, me});
                    });
                    });
                }));
            }))));
        }
        {
            return std::tuple{wx, benv, menv};
        }
    }
    if (prism_rtl::is<ast::StmtKind::SLet>(_m)) {
        auto&& p_ = prism_rtl::as<ast::StmtKind::SLet>(_m).a0;
        auto&& _m = p_.kind;
        if (prism_rtl::is<ast::PatternKind::PName>(_m)) {
            auto&& n = prism_rtl::as<ast::PatternKind::PName>(_m).a0;
            return pre_bind_name(wx, benv, menv, n, HowBound(HowBound::AsLet{}));
        }
        {
            return std::tuple{wx, benv, menv};
        }
    }
    if (prism_rtl::is<ast::StmtKind::SFn>(_m)) {
        auto&& c = prism_rtl::as<ast::StmtKind::SFn>(_m).a0;
        auto fname = check_env::def_name_text(c.name);
        return std::tuple{wx, bind(benv, fname, Bn(Bn::BnLocalFn{c})), bind(menv, fname, Bn(Bn::BnLocalFn{c}))};
    }
    {
        return std::tuple{wx, benv, menv};
    }
}


prism_rtl::Turn<std::tuple<Wx, Env, Env>> PreBind::cycle() const {
    const auto& wx = this->wx;
    const auto& benv = this->benv;
    const auto& menv = this->menv;
    const auto& s = this->s;
    return ({
        auto&& _m = s.kind;
        prism_rtl::is<ast::StmtKind::SBind>(_m) ? ({
        auto&& p_ = prism_rtl::as<ast::StmtKind::SBind>(_m).a0;
        auto&& init = prism_rtl::as<ast::StmtKind::SBind>(_m).a1;
        auto&& step_opt = prism_rtl::as<ast::StmtKind::SBind>(_m).a2;
        ({
        auto&& _m = p_.kind;
        prism_rtl::is<ast::PatternKind::PName>(_m) ? ({
        auto&& n = prism_rtl::as<ast::PatternKind::PName>(_m).a0;
        prism_rtl::more(prism_rtl::rc(PreBindName(wx, benv, menv, n, how_bound(step_opt))));
    })
        : prism_rtl::is<ast::PatternKind::PTuple>(_m) ? ({
        auto&& ps = prism_rtl::as<ast::PatternKind::PTuple>(_m).a0;
        fold_job(ps, std::tuple{wx, benv, menv}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Wx, Env, Env>>(std::tuple<std::tuple<Wx, Env, Env>, ast::Pattern_>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Wx, Env, Env>, ast::Pattern_> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto [w, be, me] = p0;
                auto q = p1;
                ({
                auto&& _m = q.kind;
                prism_rtl::is<ast::PatternKind::PName>(_m) ? ({
                auto&& n = prism_rtl::as<ast::PatternKind::PName>(_m).a0;
                prism_rtl::more(prism_rtl::rc(PreBindName(w, be, me, n, HowBound(HowBound::AsBind{}))));
            })
                : prism_rtl::finished(std::tuple{w, be, me});
            });
            });
        }));
    })))->cycle();
    })
        : prism_rtl::finished(std::tuple{wx, benv, menv});
    });
    })
        : prism_rtl::is<ast::StmtKind::SLet>(_m) ? ({
        auto&& p_ = prism_rtl::as<ast::StmtKind::SLet>(_m).a0;
        ({
        auto&& _m = p_.kind;
        prism_rtl::is<ast::PatternKind::PName>(_m) ? ({
        auto&& n = prism_rtl::as<ast::PatternKind::PName>(_m).a0;
        prism_rtl::more(prism_rtl::rc(PreBindName(wx, benv, menv, n, HowBound(HowBound::AsLet{}))));
    })
        : prism_rtl::finished(std::tuple{wx, benv, menv});
    });
    })
        : prism_rtl::is<ast::StmtKind::SFn>(_m) ? ({
        auto&& c = prism_rtl::as<ast::StmtKind::SFn>(_m).a0;
        ({
        auto fname = check_env::def_name_text(c.name);
        (prism_rtl::finished(std::tuple{wx, bind(benv, fname, Bn(Bn::BnLocalFn{c})), bind(menv, fname, Bn(Bn::BnLocalFn{c}))}));
    });
    })
        : prism_rtl::finished(std::tuple{wx, benv, menv});
    });
}


/// `Start PreBind, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Wx, Env, Env>> start_pre_bind(Wx wx, Env benv, Env menv, ast::Stmt s) {
    return prism_rtl::make_rc<PreBind>(wx, benv, menv, s);
}


/// HowBound: fn ?Expr -> HowBound
HowBound how_bound(const std::optional<ast::Expr>& opt0) {
    if (prism_rtl::is_some(opt0)) {
        return HowBound(HowBound::AsHold{});
    }
    if (prism_rtl::is_none(opt0)) {
        return HowBound(HowBound::AsBind{});
    }
    prism_rtl::unreachable("no arm matched");
}


/// PreBindName: unbounded fn Wx, Env, Env, SName, HowBound -> ((Wx, Env, Env))
std::tuple<Wx, Env, Env> pre_bind_name(const Wx& wx, const Env& benv, const Env& menv, const ast::SName& n, const HowBound& how) {
    auto lx = widget_let_lx(wx.lx, n.span);
    auto nkey = check_env::sname_key(n);
    auto full = binder_ty(lx, n.span);
    auto layer = layer_of(full);
    auto t = out_ty_of(lx, peel(full));
    auto [rs, wx1] = fresh_name(wx, snake(nkey));
    return (layer == Layer(Layer::LyEv{})) || is_switched(full)
        ? ({
        auto et = out_ty_of(lx, peel(peel(full)));
        auto [id, wx2] = add_gn(wx1, rs, et, GnKind(GnKind::GnNamed{}), Nat(0u));
        auto b = Bn(Bn::BnEv{ev_ref_of(wx2, id), t});
        auto pf = prism_rtl::cat(rs, "_v_port");
        auto pt = OutTy(OutTy::OutRc{prism_rtl::rc(OutTy(OutTy::OutPort{prism_rtl::rc(et)}))});
        auto wx3 = ({
            Wx this_ = connect(wx2, ev_ref_of(wx2, id), Sk(Sk::SkPort{prism_rtl::cat(rs, "_v")}));
            this_.lets = prelude::push(this_.lets, Do(Do::DoLet{Pa(Pa::PaTyped{prism_rtl::rc(Pa(Pa::PaBind{pf})), pt}), Ex(Ex::XCall{Text::lit("Rc::new"), Array(std::vector{Ex(Ex::XCall{Text::lit("Port::new"), Array<Ex>{}})})})}));
            this_.fields = prelude::push(this_.fields, std::tuple{pf, pt, prism_rtl::cat("`", nkey, "` as a value: the port it fires")});
            this_.moves = prelude::push(this_.moves, std::tuple{pf, Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{pf}))})});
            this_;
        });
        auto be = bind(bind(benv, nkey, b), prism_rtl::cat(nkey, "#port"), Bn(Bn::BnLocal{Ex(Ex::XVar{pf}), Holding(Holding::Owned{}), pt}));
        auto me = bind(bind(menv, nkey, b), prism_rtl::cat(nkey, "#port"), Bn(Bn::BnLocal{Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), pf}), Holding(Holding::Owned{}), pt}));
        std::tuple{wx3, be, me};
    })
        : ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Wx, Env, Env>> _v;
        auto&& _m = std::tuple{layer, how};
        if (prism_rtl::is<Layer::LyDyn>(std::get<0>(_m)) && prism_rtl::is<HowBound::AsLet>(std::get<1>(_m))) {
            _v.set(({
                auto b = Bn(Bn::BnDyn{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XSelf{})), rs, Array(std::vector{Ex(Ex::XCx{})})}), Array(std::vector{Read(Read::OwnRead{rs})}), t});
                std::tuple{wx1, bind(benv, nkey, b), bind(menv, nkey, b)};
            }));
            goto _done;
        }
        if (prism_rtl::is<Layer::LyDyn>(std::get<0>(_m))) {
            _v.set(({
                auto b = Bn(Bn::BnHold{rs, t});
                std::tuple{wx1, bind(benv, nkey, b), bind(menv, nkey, b)};
            }));
            goto _done;
        }
        {
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::tuple<Wx, Env, Env>> _v;
                auto&& _m = many_instances(wx.lx, n.span);
                if (prism_rtl::is_some(_m)) {
                    auto&& insts = prism_rtl::some_of(_m);
                    _v.set(run_to_end(fold_job(check_errors::range0(len(insts)), std::tuple{wx1, benv, menv}, ({
                        auto insts_1 = insts;
                        auto wx_2 = wx;
                        auto n_3 = n;
                        auto rs_4 = rs;
                        auto nkey_5 = nkey;
                        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Wx, Env, Env>>(std::tuple<std::tuple<Wx, Env, Env>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Wx, Env, Env>, Nat> _p0) {
                        auto&& p0 = std::get<0>(_p0);
                        auto&& p1 = std::get<1>(_p0);
                        return ({
                            auto insts_1_6 = insts_1;
                            auto wx_2_6 = wx_2;
                            auto n_3_6 = n_3;
                            auto rs_4_6 = rs_4;
                            auto nkey_5_6 = nkey_5;
                            entered(once_job([=]() {
                            return ({
                                auto [w, be, me] = p0;
                                auto k = p1;
                                ({
                                auto inst = or_(index(insts_1_6, k), std::tuple{Array<std::tuple<Text, check_types::Ty>>{}, Array<std::tuple<Text, check_types::Col>>{}});
                                auto lxk = at_instance(wx_2_6.lx, inst);
                                call_then(start_out_ty_of(lxk, peel(binder_ty(lxk, n_3_6.span))), [=](OutTy out_ty_of_200621) {
                                return ({
                                    auto tk = out_ty_of_200621;
                                    auto [rk, w2] = k == Nat(0u)
                                        ? std::tuple{rs_4_6, w}
                                        : fresh_name(w, prism_rtl::cat(rs_4_6, "_", k));
                                    auto bkey = k == Nat(0u) ? nkey_5_6 : prism_rtl::cat(nkey_5_6, "#inst", k);
                                    auto [be2, me2] = bind_plain(be, me, bkey, rk, tk);
                                    auto ukey = prism_rtl::cat(nkey_5_6, "#", show_text(inst));
                                    (prism_rtl::finished(std::tuple{w2, with_use(be2, ukey, bkey), with_use(me2, ukey, bkey)}));
                                });
                            });
                            });
                            });
                        }));
                        });
                    }));
                    }))));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(({
                        auto [be, me] = bind_plain(benv, menv, nkey, rs, t);
                        std::tuple{wx1, be, me};
                    }));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::tuple<Wx, Env, Env>> PreBindName::cycle() const {
    const auto& wx = this->wx;
    const auto& benv = this->benv;
    const auto& menv = this->menv;
    const auto& n = this->n;
    const auto& how = this->how;
    auto benv_1 = benv;
    auto how_2 = how;
    auto menv_3 = menv;
    auto n_4 = n;
    auto wx_5 = wx;
    return call_then(start_widget_let_lx(wx_5.lx, n_4.span), [=](Lx widget_let_lx_198606) {
        return ({
            auto lx = widget_let_lx_198606;
            auto nkey = check_env::sname_key(n_4);
            auto full = binder_ty(lx, n_4.span);
            auto layer = layer_of(full);
            call_then(start_out_ty_of(lx, peel(full)), [=](OutTy out_ty_of_198734) {
            return ({
                auto t = out_ty_of_198734;
                auto [rs, wx1] = fresh_name(wx_5, snake(nkey));
                (layer == Layer(Layer::LyEv{})) || is_switched(full)
                ? call_then(start_out_ty_of(lx, peel(peel(full))), [=](OutTy out_ty_of_198865) {
                return ({
                    auto et = out_ty_of_198865;
                    auto [id, wx2] = add_gn(wx1, rs, et, GnKind(GnKind::GnNamed{}), Nat(0u));
                    auto b = Bn(Bn::BnEv{ev_ref_of(wx2, id), t});
                    auto pf = prism_rtl::cat(rs, "_v_port");
                    auto pt = OutTy(OutTy::OutRc{prism_rtl::rc(OutTy(OutTy::OutPort{prism_rtl::rc(et)}))});
                    auto wx3 = ({
                        Wx this_ = connect(wx2, ev_ref_of(wx2, id), Sk(Sk::SkPort{prism_rtl::cat(rs, "_v")}));
                        this_.lets = prelude::push(this_.lets, Do(Do::DoLet{Pa(Pa::PaTyped{prism_rtl::rc(Pa(Pa::PaBind{pf})), pt}), Ex(Ex::XCall{Text::lit("Rc::new"), Array(std::vector{Ex(Ex::XCall{Text::lit("Port::new"), Array<Ex>{}})})})}));
                        this_.fields = prelude::push(this_.fields, std::tuple{pf, pt, prism_rtl::cat("`", nkey, "` as a value: the port it fires")});
                        this_.moves = prelude::push(this_.moves, std::tuple{pf, Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{pf}))})});
                        this_;
                    });
                    auto be = bind(bind(benv_1, nkey, b), prism_rtl::cat(nkey, "#port"), Bn(Bn::BnLocal{Ex(Ex::XVar{pf}), Holding(Holding::Owned{}), pt}));
                    auto me = bind(bind(menv_3, nkey, b), prism_rtl::cat(nkey, "#port"), Bn(Bn::BnLocal{Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), pf}), Holding(Holding::Owned{}), pt}));
                    (prism_rtl::finished(std::tuple{wx3, be, me}));
                });
            })
                : ({
                auto&& _m = std::tuple{layer, how_2};
                prism_rtl::is<Layer::LyDyn>(std::get<0>(_m)) && prism_rtl::is<HowBound::AsLet>(std::get<1>(_m)) ? ({
                auto b = Bn(Bn::BnDyn{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XSelf{})), rs, Array(std::vector{Ex(Ex::XCx{})})}), Array(std::vector{Read(Read::OwnRead{rs})}), t});
                (prism_rtl::finished(std::tuple{wx1, bind(benv_1, nkey, b), bind(menv_3, nkey, b)}));
            })
                : prism_rtl::is<Layer::LyDyn>(std::get<0>(_m)) ? ({
                auto b = Bn(Bn::BnHold{rs, t});
                (prism_rtl::finished(std::tuple{wx1, bind(benv_1, nkey, b), bind(menv_3, nkey, b)}));
            })
                : call_then(start_many_instances(wx_5.lx, n_4.span), [=](std::optional<Array<std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>>>> many_instances_200153) {
                return ({
                    prism_rtl::is_some(many_instances_200153) ? ({
                    auto&& insts = prism_rtl::some_of(many_instances_200153);
                    fold_job(check_errors::range0(len(insts)), std::tuple{wx1, benv_1, menv_3}, ({
                    auto insts_6 = insts;
                    auto wx_5_7 = wx_5;
                    auto n_4_7 = n_4;
                    auto rs_7 = rs;
                    auto nkey_8 = nkey;
                    static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Wx, Env, Env>>(std::tuple<std::tuple<Wx, Env, Env>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Wx, Env, Env>, Nat> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto insts_6_9 = insts_6;
                        auto wx_5_7_9 = wx_5_7;
                        auto n_4_7_9 = n_4_7;
                        auto rs_7_9 = rs_7;
                        auto nkey_8_9 = nkey_8;
                        entered(once_job([=]() {
                        return ({
                            auto [w, be, me] = p0;
                            auto k = p1;
                            ({
                            auto inst = or_(index(insts_6_9, k), std::tuple{Array<std::tuple<Text, check_types::Ty>>{}, Array<std::tuple<Text, check_types::Col>>{}});
                            auto lxk = at_instance(wx_5_7_9.lx, inst);
                            call_then(start_out_ty_of(lxk, peel(binder_ty(lxk, n_4_7_9.span))), [=](OutTy out_ty_of_200621) {
                            return ({
                                auto tk = out_ty_of_200621;
                                auto [rk, w2] = k == Nat(0u)
                                    ? std::tuple{rs_7_9, w}
                                    : fresh_name(w, prism_rtl::cat(rs_7_9, "_", k));
                                auto bkey = k == Nat(0u) ? nkey_8_9 : prism_rtl::cat(nkey_8_9, "#inst", k);
                                auto [be2, me2] = bind_plain(be, me, bkey, rk, tk);
                                auto ukey = prism_rtl::cat(nkey_8_9, "#", show_text(inst));
                                (prism_rtl::finished(std::tuple{w2, with_use(be2, ukey, bkey), with_use(me2, ukey, bkey)}));
                            });
                        });
                        });
                        });
                    }));
                    });
                }));
                }))->cycle();
                })
                    : prism_rtl::is_none(many_instances_200153) ? ({
                    auto [be, me] = bind_plain(benv_1, menv_3, nkey, rs, t);
                    (prism_rtl::finished(std::tuple{wx1, be, me}));
                })
                    : throw prism_rtl::Panic("no arm matched");
                });
            });
            });
            });
        });
        });
    });
}


/// `Start PreBindName, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Wx, Env, Env>> start_pre_bind_name(Wx wx, Env benv, Env menv, ast::SName n, HowBound how) {
    return prism_rtl::make_rc<PreBindName>(wx, benv, menv, n, how);
}


/// WithUse: fn Env, Text, Text -> Env
Env with_use(const Env& env, const Text& ukey, const Text& bkey) {
    Env this_ = env;
    this_.uses = insert(this_.uses, ukey, bkey);
    return this_;
}


/// ?ManyInstances: unbounded fn Lx, Range -> ?[(([((Text, Ty))], [((Text, Col))]))]
std::optional<Array<std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>>>> many_instances(const Lx& lx, const ast::Range& span) {
    auto&& _m = prelude::get(lx.gens, place_key(lx, span));
    if (prism_rtl::is_some(_m)) {
        auto&& gn = prism_rtl::some_of(_m);
        auto insts = instantiations(lx, gn);
        return len(insts) > Nat(1u)
            ? std::optional(insts)
            : std::optional<Array<std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>>>>{};
    }
    if (prism_rtl::is_none(_m)) {
        return std::optional<Array<std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>>>>{};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::optional<Array<std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>>>>> ManyInstances::cycle() const {
    const auto& lx = this->lx;
    const auto& span = this->span;
    return ({
        auto&& _m = prelude::get(lx.gens, place_key(lx, span));
        prism_rtl::is_some(_m) ? ({
        auto&& gn = prism_rtl::some_of(_m);
        ({
        auto lx_1 = lx;
        call_then(start_instantiations(lx_1, gn), [=](Array<std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>>> instantiations_201498) {
        return ({
            auto insts = instantiations_201498;
            len(insts) > Nat(1u)
            ? prism_rtl::finished(std::optional(insts))
            : prism_rtl::finished(std::optional<Array<std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>>>>{});
        });
    });
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(std::optional<Array<std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>>>>{})
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ManyInstances, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<Array<std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>>>>> start_many_instances(Lx lx, ast::Range span) {
    return prism_rtl::make_rc<ManyInstances>(lx, span);
}


/// IsSwitched: fn Ty -> Bool
bool is_switched(const check_types::Ty& t) {
    if (prism_rtl::is<check_types::Ty::TySig>(t)) {
        auto&& m201815_0_0 = prism_rtl::as<check_types::Ty::TySig>(t).a0;
        auto&& m201815_0_1 = prism_rtl::as<check_types::Ty::TySig>(t).a1;
        if (m201815_0_0 == Text::lit("$")) {
            if (prism_rtl::is<check_types::Ty::TySig>(m201815_0_1)) {
                auto&& m201815_0_1_r_0 = prism_rtl::as<check_types::Ty::TySig>(m201815_0_1).a0;
                if (m201815_0_1_r_0 == Text::lit("!")) {
                    return true;
                }
            }
        }
    }
    {
        return false;
    }
}


/// ?BindingOf: fn Env, Pattern -> ?Bn
std::optional<Bn> binding_of(const Env& env, const ast::Pattern_& p_) {
    auto&& _m = p_.kind;
    if (prism_rtl::is<ast::PatternKind::PName>(_m)) {
        auto&& n = prism_rtl::as<ast::PatternKind::PName>(_m).a0;
        return prelude::get(env->names, check_env::sname_key(n));
    }
    if (prism_rtl::is<ast::PatternKind::PTuple>(_m)) {
        auto&& ps = prism_rtl::as<ast::PatternKind::PTuple>(_m).a0;
        return std::optional(Bn(Bn::BnParts{each(ps, [&](const ast::Pattern_& q) { return binding_of_name(env, q); })}));
    }
    {
        return std::optional<Bn>{};
    }
}


/// ?BindingOfName: fn Env, Pattern -> ?Bn
std::optional<Bn> binding_of_name(const Env& env, const ast::Pattern_& p_) {
    auto&& _m = p_.kind;
    if (prism_rtl::is<ast::PatternKind::PName>(_m)) {
        auto&& n = prism_rtl::as<ast::PatternKind::PName>(_m).a0;
        return prelude::get(env->names, check_env::sname_key(n));
    }
    {
        return std::optional<Bn>{};
    }
}


/// WidgetStmt: unbounded fn Wx, Env, Env, Stmt, Bool -> ((Wx, Env, Env))
std::tuple<Wx, Env, Env> widget_stmt(const Wx& wx, const Env& benv, const Env& menv, const ast::Stmt& s, const bool& last) {
    auto lx = wx.lx;
    auto&& _m = s.kind;
    if (prism_rtl::is<ast::StmtKind::SBind>(_m) && prism_rtl::is_none(prism_rtl::as<ast::StmtKind::SBind>(_m).a2)) {
        auto&& p_ = prism_rtl::as<ast::StmtKind::SBind>(_m).a0;
        auto&& e = prism_rtl::as<ast::StmtKind::SBind>(_m).a1;
        auto [wx2, res] = build_line(wx, benv, menv, e, binding_of(menv, p_));
        auto wx3 = bind_res(wx2, menv, p_, res);
        auto&& _m = std::tuple{res, p_.kind};
        if (prism_rtl::is<Wres::WrDyn>(std::get<0>(_m)) && prism_rtl::is<ast::PatternKind::PName>(std::get<1>(_m))) {
            auto&& ex = prism_rtl::as<Wres::WrDyn>(std::get<0>(_m)).a0;
            auto&& rds = prism_rtl::as<Wres::WrDyn>(std::get<0>(_m)).a1;
            auto&& t = prism_rtl::as<Wres::WrDyn>(std::get<0>(_m)).a2;
            auto&& n = prism_rtl::as<ast::PatternKind::PName>(std::get<1>(_m)).a0;
            auto b = Bn(Bn::BnDyn{ex, rds, t});
            return std::tuple{wx3, bind(benv, check_env::sname_key(n), b), bind(menv, check_env::sname_key(n), b)};
        }
        if (prism_rtl::is<Wres::WrHosted>(std::get<0>(_m)) && prism_rtl::is<ast::PatternKind::PTuple>(std::get<1>(_m))) {
            auto&& inner = prism_rtl::as<Wres::WrHosted>(std::get<0>(_m)).a0;
            auto&& doc = prism_rtl::as<Wres::WrHosted>(std::get<0>(_m)).a1;
            auto&& ps = prism_rtl::as<ast::PatternKind::PTuple>(std::get<1>(_m)).a0;
            return bind_hosted(wx3, benv, menv, inner, doc, ps);
        }
        {
            return std::tuple{wx3, benv, menv};
        }
    }
    if (prism_rtl::is<ast::StmtKind::SBind>(_m) && prism_rtl::is_some(prism_rtl::as<ast::StmtKind::SBind>(_m).a2)) {
        auto&& p_ = prism_rtl::as<ast::StmtKind::SBind>(_m).a0;
        auto&& init = prism_rtl::as<ast::StmtKind::SBind>(_m).a1;
        auto&& step_ = prism_rtl::some_of(prism_rtl::as<ast::StmtKind::SBind>(_m).a2);
        auto [wx2, be2] = hold_line(wx, benv, menv, p_, init, step_);
        return std::tuple{wx2, be2, menv};
    }
    if (prism_rtl::is<ast::StmtKind::SIgnore>(_m)) {
        auto&& e = prism_rtl::as<ast::StmtKind::SIgnore>(_m).a0;
        auto&& _wx2 = build_line(wx, benv, menv, e, std::optional<Bn>{});
        auto&& wx2 = std::get<0>(_wx2);
        return std::tuple{wx2, benv, menv};
    }
    if (prism_rtl::is<ast::StmtKind::SLet>(_m)) {
        auto&& p_ = prism_rtl::as<ast::StmtKind::SLet>(_m).a0;
        auto&& e = prism_rtl::as<ast::StmtKind::SLet>(_m).a2;
        auto [wx2, be2] = let_line(wx, benv, menv, p_, e);
        return std::tuple{wx2, be2, menv};
    }
    if (prism_rtl::is<ast::StmtKind::SExpr>(_m)) {
        auto&& e = prism_rtl::as<ast::StmtKind::SExpr>(_m).a0;
        auto&& _m = e.kind;
        if (prism_rtl::is<ast::ExprKind::EFreeSigil>(_m)) {
            auto&& m203332_0_0 = prism_rtl::as<ast::ExprKind::EFreeSigil>(_m).a0;
            auto&& x = prism_rtl::as<ast::ExprKind::EFreeSigil>(_m).a1;
            if (m203332_0_0 == Text::lit("@")) {
                auto [res, wx2] = result_of(wx, benv, menv, x);
                auto wx3 = ({
                    Wx this_ = wx2;
                    this_.result = res;
                    this_;
                });
                return std::tuple{wx3, benv, menv};
            }
        }
        {
            auto [wx2, res] = build_line(wx, benv, menv, e, std::optional<Bn>{});
            auto wx3 = last ? set_result(wx2, res) : wx2;
            return std::tuple{wx3, benv, menv};
        }
    }
    if (prism_rtl::is<ast::StmtKind::SEmit>(_m)) {
        return std::tuple{wx, benv, menv};
    }
    if (prism_rtl::is<ast::StmtKind::SSignature>(_m)) {
        return std::tuple{wx, benv, menv};
    }
    if (prism_rtl::is<ast::StmtKind::SFn>(_m)) {
        auto&& c = prism_rtl::as<ast::StmtKind::SFn>(_m).a0;
        return std::tuple{wx, benv, menv};
    }
    {
        auto wx2 = ({
            Wx this_ = wx;
            this_.build = prelude::push(this_.build, refusal_do(Text::lit("a statement this back end does not lower yet")));
            this_;
        });
        return std::tuple{wx2, benv, menv};
    }
}

}  // namespace crate::lower
