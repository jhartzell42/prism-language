// The module `Syntax.Lexer.Templates`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/lexer/chars/generic.hpp>

// The module `Syntax.Lexer.Templates`, from `target/bootstrap/cpp-src/prismc/syntax/lexer/templates.prism`.
namespace crate::syntax::lexer::templates {

bool CallRead::operator==(const CallRead& o) const { return l_p == o.l_p && attrs_p == o.attrs_p && body_o == o.body_o && going_p == o.going_p; }

void CallRead::show(Printer& p) const {
    p.record("CallRead", {{"l", l_p}, {"attrs", attrs_p}, {"body", body_o}, {"going", going_p}});
}

Pod CallRead::to_pod() const {
    return Pod::record("CallRead", {{"l", prism_rtl::to_pod(l_p)}, {"attrs", prism_rtl::to_pod(attrs_p)}, {"body", prism_rtl::to_pod(body_o)}, {"going", prism_rtl::to_pod(going_p)}});
}

Result<CallRead> CallRead::from_pod(const Pod& whole) {
    return CallRead{.l_p = TRY(prism_rtl::from_pod<crate::syntax::lexer::Lex>(TRY(crate::prelude::field(whole, "l")))), .attrs_p = TRY(prism_rtl::from_pod<Array<crate::syntax::lexer::AttrTok>>(TRY(crate::prelude::field(whole, "attrs")))), .body_o = TRY(prism_rtl::from_pod<std::optional<Array<crate::syntax::lexer::TPartTok>>>(TRY(crate::prelude::field(whole, "body")))), .going_p = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "going"))))};
}


bool RawItem::RiPlaceholder::operator==(const RiPlaceholder& o) const { return a0 == o.a0 && a1 == o.a1; }

bool RawItem::RiBlock::operator==(const RiBlock& o) const { return a0 == o.a0 && a1 == o.a1; }

bool RawItem::RiCall::operator==(const RiCall& o) const { return a0 == o.a0 && a1 == o.a1 && a2 == o.a2 && a3 == o.a3; }

void RawItem::show(Printer& p) const {
    if (auto c = std::get_if<RiText>(&cases())) p.choice("RiText", {c->a0});
    else if (auto c = std::get_if<RiPlaceholder>(&cases())) p.choice("RiPlaceholder", {c->a0, c->a1});
    else if (auto c = std::get_if<RiBlock>(&cases())) p.choice("RiBlock", {c->a0, c->a1});
    else if (auto c = std::get_if<RiCall>(&cases())) p.choice("RiCall", {c->a0, c->a1, c->a2, c->a3});
}

Pod RawItem::to_pod() const {
    return std::holds_alternative<RiText>(cases()) ? Pod::choice("RiText", {prism_rtl::to_pod(std::get<RiText>(cases()).a0)})
        : std::holds_alternative<RiPlaceholder>(cases()) ? Pod::choice("RiPlaceholder", {prism_rtl::to_pod(std::get<RiPlaceholder>(cases()).a0), prism_rtl::to_pod(std::get<RiPlaceholder>(cases()).a1)})
        : std::holds_alternative<RiBlock>(cases()) ? Pod::choice("RiBlock", {prism_rtl::to_pod(std::get<RiBlock>(cases()).a0), prism_rtl::to_pod(std::get<RiBlock>(cases()).a1)})
        : std::holds_alternative<RiCall>(cases()) ? Pod::choice("RiCall", {prism_rtl::to_pod(std::get<RiCall>(cases()).a0), prism_rtl::to_pod(std::get<RiCall>(cases()).a1), prism_rtl::to_pod(std::get<RiCall>(cases()).a2), prism_rtl::to_pod(std::get<RiCall>(cases()).a3)})
        : Pod();
}

Result<RawItem> RawItem::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "RiText" && c->args.size() == 1) return RawItem(RiText{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "RiPlaceholder" && c->args.size() == 2) return RawItem(RiPlaceholder{TRY(prism_rtl::from_pod<Array<crate::syntax::lexer::Tok>>(c->args[0])), TRY(prism_rtl::from_pod<crate::syntax::Range>(c->args[1]))});
        if (c->ctor == "RiBlock" && c->args.size() == 2) return RawItem(RiBlock{TRY(prism_rtl::from_pod<Array<crate::syntax::lexer::Tok>>(c->args[0])), TRY(prism_rtl::from_pod<crate::syntax::Range>(c->args[1]))});
        if (c->ctor == "RiCall" && c->args.size() == 4) return RawItem(RiCall{TRY(prism_rtl::from_pod<crate::syntax::lexer::NameTok>(c->args[0])), TRY(prism_rtl::from_pod<Array<crate::syntax::lexer::AttrTok>>(c->args[1])), TRY(prism_rtl::from_pod<std::optional<Array<crate::syntax::lexer::TPartTok>>>(c->args[2])), TRY(prism_rtl::from_pod<crate::syntax::Range>(c->args[3]))});
    }
    return mismatch<RawItem>("a RawItem", p);
}


bool RawLine::operator==(const RawLine& o) const { return items_p == o.items_p && newline_p == o.newline_p && block_p == o.block_p; }

void RawLine::show(Printer& p) const {
    p.record("RawLine", {{"items", items_p}, {"newline", newline_p}, {"block", block_p}});
}

Pod RawLine::to_pod() const {
    return Pod::record("RawLine", {{"items", prism_rtl::to_pod(items_p)}, {"newline", prism_rtl::to_pod(newline_p)}, {"block", prism_rtl::to_pod(block_p)}});
}

Result<RawLine> RawLine::from_pod(const Pod& whole) {
    return RawLine{.items_p = TRY(prism_rtl::from_pod<Array<RawItem>>(TRY(crate::prelude::field(whole, "items")))), .newline_p = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "newline")))), .block_p = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "block"))))};
}


void TplHow::show(Printer& p) const {
    p.record("TplHow", {{"close", close_p}, {"delims", delims_p}, {"open", open_p}, {"isRaw", is_raw_p}, {"firstContinues", first_continues_p}});
}

Pod TplHow::to_pod() const {
    return Pod::record("TplHow", {{"close", prism_rtl::to_pod(close_p)}, {"delims", prism_rtl::to_pod(delims_p)}, {"open", prism_rtl::to_pod(open_p)}, {"isRaw", prism_rtl::to_pod(is_raw_p)}, {"firstContinues", prism_rtl::to_pod(first_continues_p)}});
}

Result<TplHow> TplHow::from_pod(const Pod& whole) {
    return TplHow{.close_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "close")))), .delims_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "delims")))), .open_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "open")))), .is_raw_p = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "isRaw")))), .first_continues_p = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "firstContinues"))))};
}


bool TplRead::operator==(const TplRead& o) const { return l_p == o.l_p && lines_p == o.lines_p && cur_p == o.cur_p && closing_col_o == o.closing_col_o && closed_p == o.closed_p && at_line_start_p == o.at_line_start_p && going_p == o.going_p; }

void TplRead::show(Printer& p) const {
    p.record("TplRead", {{"l", l_p}, {"lines", lines_p}, {"cur", cur_p}, {"closingCol", closing_col_o}, {"closed", closed_p}, {"atLineStart", at_line_start_p}, {"going", going_p}});
}

Pod TplRead::to_pod() const {
    return Pod::record("TplRead", {{"l", prism_rtl::to_pod(l_p)}, {"lines", prism_rtl::to_pod(lines_p)}, {"cur", prism_rtl::to_pod(cur_p)}, {"closingCol", prism_rtl::to_pod(closing_col_o)}, {"closed", prism_rtl::to_pod(closed_p)}, {"atLineStart", prism_rtl::to_pod(at_line_start_p)}, {"going", prism_rtl::to_pod(going_p)}});
}

Result<TplRead> TplRead::from_pod(const Pod& whole) {
    return TplRead{.l_p = TRY(prism_rtl::from_pod<crate::syntax::lexer::Lex>(TRY(crate::prelude::field(whole, "l")))), .lines_p = TRY(prism_rtl::from_pod<Array<RawLine>>(TRY(crate::prelude::field(whole, "lines")))), .cur_p = TRY(prism_rtl::from_pod<RawLine>(TRY(crate::prelude::field(whole, "cur")))), .closing_col_o = TRY(prism_rtl::from_pod<std::optional<Nat>>(TRY(crate::prelude::field(whole, "closingCol")))), .closed_p = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "closed")))), .at_line_start_p = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "atLineStart")))), .going_p = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "going"))))};
}


/// MaybeTemplate: unbounded fn Lex, Text -> Lex
crate::syntax::lexer::Lex maybe_template_f(const crate::syntax::lexer::Lex& l0_p0, const Text& kw_p1) {
    auto l_p2 = ({
        crate::syntax::lexer::Lex this_ = l0_p0;
        this_.pos_p = crate::syntax::lexer::chars::match_end_f(([]() -> const Regex& { static const Regex r = Regex::lit(" *", ""); return r; }()), this_.src_p, this_.pos_p);
        (std::move(this_));
    });
    return (crate::syntax::lexer::chars::peek_f(l_p2) == Text::lit("<")) && (template_tag_ahead_f(l_p2) != Text::lit(""))
        ? ({
        auto keyword_p3 = kw_p1 == Text::lit("output")
            ? Text::lit("Output")
            : kw_p1 == Text::lit("inline_text")
            ? Text::lit("InlineText")
            : Text::lit("Raw");
        auto [kind_p5, l2_p6] = lex_template_f(l_p2, keyword_p3, prism_rtl::deref(l_p2).pos_p);
        auto l3_p4 = ({
            crate::syntax::lexer::Lex this_ = l2_p6;
            this_.last_ws_p = true;
            (std::move(this_));
        });
        (crate::syntax::lexer::push_tok_f(l3_p4, kind_p5, prism_rtl::deref(l_p2).pos_p, prism_rtl::deref(l3_p4).pos_p));
    })
        : crate::syntax::lexer::chars::lex_err_f(l0_p0, l0_p0.pos_p, l0_p0.pos_p, prism_rtl::cat("`", kw_p1, "` is followed by a language tag, `<rust>`"));
}


prism_rtl::Turn<crate::syntax::lexer::Lex> MaybeTemplate::cycle() const {
    const auto& l0_p0 = this->l0_p0;
    const auto& kw_p1 = this->kw_p1;
    auto l_p2 = ({
        crate::syntax::lexer::Lex this_ = l0_p0;
        this_.pos_p = crate::syntax::lexer::chars::match_end_f(([]() -> const Regex& { static const Regex r = Regex::lit(" *", ""); return r; }()), this_.src_p, this_.pos_p);
        (std::move(this_));
    });
    return (crate::syntax::lexer::chars::peek_f(l_p2) == Text::lit("<")) && (template_tag_ahead_f(l_p2) != Text::lit(""))
        ? ({
        auto keyword_p3 = kw_p1 == Text::lit("output")
            ? Text::lit("Output")
            : kw_p1 == Text::lit("inline_text")
            ? Text::lit("InlineText")
            : Text::lit("Raw");
        (crate::prelude::call_then(start_lex_template_f(l_p2, keyword_p3, prism_rtl::deref(l_p2).pos_p), [=](std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex> lex_template_f_1019) {
        return ({
            auto [kind_p5, l2_p6] = lex_template_f_1019;
            auto l3_p4 = ({
                crate::syntax::lexer::Lex this_ = l2_p6;
                this_.last_ws_p = true;
                (std::move(this_));
            });
            (prism_rtl::finished(crate::syntax::lexer::push_tok_f(l3_p4, kind_p5, prism_rtl::deref(l_p2).pos_p, prism_rtl::deref(l3_p4).pos_p)));
        });
    }));
    })
        : prism_rtl::finished(crate::syntax::lexer::chars::lex_err_f(l0_p0, prism_rtl::deref(l0_p0).pos_p, prism_rtl::deref(l0_p0).pos_p, prism_rtl::cat("`", kw_p1, "` is followed by a language tag, `<rust>`")));
}


/// `Start MaybeTemplate, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_maybe_template_f(crate::syntax::lexer::Lex l0_p0, Text kw_p1) {
    return prism_rtl::make_rc<MaybeTemplate>(l0_p0, kw_p1);
}


/// TemplateTagAhead: unbounded fn Lex -> Text
Text template_tag_ahead_f(const crate::syntax::lexer::Lex& l_p0) {
    auto&& _name_p2 = crate::syntax::lexer::words::lex_ident_f(crate::syntax::lexer::chars::bump_f(l_p0));
    auto&& name_p2 = std::get<0>(_name_p2);
    auto after_p1 = crate::syntax::lexer::chars::peek_at_f(l_p0, crate::prelude::len_text(name_p2) + Nat(1u));
    return (((crate::syntax::lexer::chars::peek_f(l_p0) == Text::lit("<")) && (name_p2 != Text::lit(""))) && crate::syntax::lexer::chars::is_lower_f(crate::syntax::lexer::chars::head_f(name_p2))) && (after_p1 == Text::lit(">"))
        ? name_p2
        : Text::lit("");
}


prism_rtl::Turn<Text> TemplateTagAhead::cycle() const {
    const auto& l_p0 = this->l_p0;
    auto l_p0x = l_p0;
    return crate::prelude::call_then(crate::syntax::lexer::words::start_lex_ident_f(crate::syntax::lexer::chars::bump_f(l_p0x)), [=](std::tuple<Text, crate::syntax::lexer::Lex> lex_ident_f_1410) {
        return ({
            auto&& _name_p2 = lex_ident_f_1410;
            auto&& name_p2 = std::get<0>(_name_p2);
            auto after_p1 = crate::syntax::lexer::chars::peek_at_f(l_p0x, crate::prelude::len_text(name_p2) + Nat(1u));
            (((crate::syntax::lexer::chars::peek_f(l_p0x) == Text::lit("<")) && (name_p2 != Text::lit(""))) && crate::syntax::lexer::chars::is_lower_f(crate::syntax::lexer::chars::head_f(name_p2))) && (after_p1 == Text::lit(">"))
            ? prism_rtl::finished(name_p2)
            : prism_rtl::finished(Text::lit(""));
        });
    });
}


/// `Start TemplateTagAhead, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_template_tag_ahead_f(crate::syntax::lexer::Lex l_p0) {
    return prism_rtl::make_rc<TemplateTagAhead>(l_p0);
}


/// LexTemplate: unbounded fn Lex, Text, Nat -> ((TokKind, Lex))
std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex> lex_template_f(const crate::syntax::lexer::Lex& l0_p0, const Text& keyword_p1, const Nat& start_p2) {
    auto lang_p3 = template_tag_ahead_f(l0_p0);
    auto l1_p4 = crate::syntax::lexer::chars::forward_f(l0_p0, crate::prelude::len_text(lang_p3) + Nat(2u));
    auto delims_p5 = (lang_p3 == Text::lit("markdown")) || (lang_p3 == Text::lit("html"))
        ? Text::lit("single")
        : Text::lit("double");
    auto ends_line_p6 = (crate::syntax::lexer::chars::peek_f(l1_p4) == Text::lit("\n")) || crate::syntax::lexer::chars::starts_with_f(l1_p4, Text::lit("\r\n"));
    auto skip_p7 = crate::syntax::lexer::chars::peek_f(l1_p4) == Text::lit("\r")
        ? Nat(2u)
        : Nat(1u);
    auto l2_p8 = std::move(ends_line_p6)
        ? crate::syntax::lexer::chars::forward_f(l1_p4, skip_p7)
        : l1_p4;
    auto [parts_pa, l3_pb] = template_body_f(l2_p8, prism_rtl::cat("</", lang_p3, ">"), delims_p5, keyword_p1 == Text::lit("Raw"), !std::move(ends_line_p6), start_p2);
    auto kind_p9 = crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KTemplate{crate::syntax::lexer::TemplateTok{.keyword_p = keyword_p1, .lang_p = lang_p3, .delims_p = delims_p5, .parts_p = parts_pa}});
    return std::tuple{kind_p9, l3_pb};
}


prism_rtl::Turn<std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex>> LexTemplate::cycle() const {
    const auto& l0_p0 = this->l0_p0;
    const auto& keyword_p1 = this->keyword_p1;
    const auto& start_p2 = this->start_p2;
    auto keyword_p1x = keyword_p1;
    auto l0_p0x = l0_p0;
    auto start_p2x = start_p2;
    return crate::prelude::call_then(start_template_tag_ahead_f(l0_p0x), [=](Text template_tag_ahead_f_1743) {
        return ({
            auto lang_p3 = template_tag_ahead_f_1743;
            auto l1_p4 = crate::syntax::lexer::chars::forward_f(l0_p0x, crate::prelude::len_text(lang_p3) + Nat(2u));
            auto delims_p5 = (lang_p3 == Text::lit("markdown")) || (lang_p3 == Text::lit("html"))
                ? Text::lit("single")
                : Text::lit("double");
            auto ends_line_p6 = (crate::syntax::lexer::chars::peek_f(l1_p4) == Text::lit("\n")) || crate::syntax::lexer::chars::starts_with_f(l1_p4, Text::lit("\r\n"));
            auto skip_p7 = crate::syntax::lexer::chars::peek_f(l1_p4) == Text::lit("\r")
                ? Nat(2u)
                : Nat(1u);
            auto l2_p8 = std::move(ends_line_p6)
                ? crate::syntax::lexer::chars::forward_f(l1_p4, skip_p7)
                : l1_p4;
            (crate::prelude::call_then(start_template_body_f(l2_p8, prism_rtl::cat("</", lang_p3, ">"), delims_p5, keyword_p1x == Text::lit("Raw"), !std::move(ends_line_p6), start_p2x), [=](std::tuple<Array<crate::syntax::lexer::TPartTok>, crate::syntax::lexer::Lex> template_body_f_2157) {
            return ({
                auto [parts_pa, l3_pb] = template_body_f_2157;
                auto kind_p9 = crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KTemplate{crate::syntax::lexer::TemplateTok{.keyword_p = keyword_p1x, .lang_p = lang_p3, .delims_p = delims_p5, .parts_p = parts_pa}});
                (prism_rtl::finished(std::tuple{kind_p9, l3_pb}));
            });
        }));
        });
    });
}


/// `Start LexTemplate, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex>> start_lex_template_f(crate::syntax::lexer::Lex l0_p0, Text keyword_p1, Nat start_p2) {
    return prism_rtl::make_rc<LexTemplate>(l0_p0, keyword_p1, start_p2);
}


/// let emptyLine
RawLine empty_line_p() {
    return RawLine{.items_p = Array<RawItem>{}, .newline_p = false, .block_p = false};
}


/// AddItem: fn RawLine, RawItem -> RawLine
RawLine add_item_f(const RawLine& line_p0, const RawItem& item_p1) {
    RawLine this_ = line_p0;
    this_.items_p = add_raw_f(this_.items_p, item_p1);
    return this_;
}


/// AddRaw: fn [RawItem], RawItem -> [RawItem]
Array<RawItem> add_raw_f(const Array<RawItem>& items_p0, const RawItem& raw_item1) {
    if (prism_rtl::is<RawItem::RiText>(raw_item1)) {
        auto&& t_p1 = prism_rtl::as<RawItem::RiText>(raw_item1).a0;
        auto&& _m = crate::syntax::lexer::chars::last_o(items_p0);
        if (prism_rtl::is_some(_m) && prism_rtl::is<RawItem::RiText>(prism_rtl::some_of(_m))) {
            auto&& s_p2 = prism_rtl::as<RawItem::RiText>(prism_rtl::some_of(_m)).a0;
            return crate::prelude::push(crate::syntax::lexer::chars::pop_f(items_p0), RawItem(RawItem::RiText{prism_rtl::cat(s_p2, t_p1)}));
        }
        {
            return crate::prelude::push(items_p0, RawItem(RawItem::RiText{t_p1}));
        }
    }
    {
        auto&& item_p4 = raw_item1;
        return crate::prelude::push(items_p0, item_p4);
    }
}


/// OnlyWhitespace: fn RawLine -> Bool
bool only_whitespace_f(const RawLine& line_p0) {
    return crate::prelude::fold(line_p0.items_p, true, [&](const bool& ok_p1, const RawItem& it_p2) { return prism_rtl::deref(ok_p1) && is_blank_text_f(it_p2); });
}


/// IsBlankText: fn RawItem -> Bool
bool is_blank_text_f(const RawItem& raw_item0) {
    if (prism_rtl::is<RawItem::RiText>(raw_item0)) {
        auto&& s_p0 = prism_rtl::as<RawItem::RiText>(raw_item0).a0;
        return crate::syntax::lexer::chars::all_chars_f(s_p0, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>>(prism_rtl::rc([=](Text p0) {
            return crate::prelude::once_job([=]() {
                return ({
                    auto c_p1 = p0;
                    (prism_rtl::finished((c_p1 == Text::lit(" ")) || (c_p1 == Text::lit("\r"))));
                });
            });
        })));
    }
    {
        return false;
    }
}


/// TextLen: fn RawLine -> Nat
Nat text_len_f(const RawLine& line_p0) {
    return crate::prelude::fold(line_p0.items_p, Nat(0u), [&](const Nat& n_p1, const RawItem& it_p2) { return n_p1 + text_len_of_f(it_p2); });
}


/// TextLenOf: fn RawItem -> Nat
Nat text_len_of_f(const RawItem& raw_item0) {
    if (prism_rtl::is<RawItem::RiText>(raw_item0)) {
        auto&& s_p0 = prism_rtl::as<RawItem::RiText>(raw_item0).a0;
        return crate::prelude::len_text(s_p0);
    }
    {
        return Nat(0u);
    }
}


/// TemplateBody: unbounded fn Lex, Text, Text, Bool, Bool, Nat -> (([TPartTok], Lex))
std::tuple<Array<crate::syntax::lexer::TPartTok>, crate::syntax::lexer::Lex> template_body_f(const crate::syntax::lexer::Lex& l0_p0, const Text& close_p1, const Text& delims_p2, const bool& is_raw_p3, const bool& first_continues_p4, const Nat& open_start_p5) {
    auto open_p6 = delims_p2 == Text::lit("double") ? Text::lit("{{") : Text::lit("{");
    auto how_p7 = TplHow{.close_p = close_p1, .delims_p = delims_p2, .open_p = open_p6, .is_raw_p = is_raw_p3, .first_continues_p = first_continues_p4};
    auto start_p8 = TplRead{.l_p = l0_p0, .lines_p = Array<RawLine>{}, .cur_p = empty_line_p(), .closing_col_o = std::optional<Nat>{}, .closed_p = false, .at_line_start_p = !first_continues_p4, .going_p = true};
    auto r_p9 = ({
        TplRead this_ = start_p8;
        while (this_.going_p) {
            this_ = template_step_f(this_, how_p7);
        }
        (std::move(this_));
    });
    auto l1_pa = prism_rtl::deref(r_p9).closed_p
        ? prism_rtl::deref(r_p9).l_p
        : crate::syntax::lexer::chars::lex_err_f(prism_rtl::deref(r_p9).l_p, open_start_p5, prism_rtl::deref(prism_rtl::deref(r_p9).l_p).pos_p, prism_rtl::cat("a template never closes: expected `", close_p1, "`"));
    return finish_template_lines_f(l1_pa, crate::prelude::push(prism_rtl::deref(r_p9).lines_p, prism_rtl::deref(r_p9).cur_p), crate::prelude::or_(prism_rtl::deref(r_p9).closing_col_o, Nat(0u)), first_continues_p4);
}


prism_rtl::Turn<std::tuple<Array<crate::syntax::lexer::TPartTok>, crate::syntax::lexer::Lex>> TemplateBody::cycle() const {
    const auto& l0_p0 = this->l0_p0;
    const auto& close_p1 = this->close_p1;
    const auto& delims_p2 = this->delims_p2;
    const auto& is_raw_p3 = this->is_raw_p3;
    const auto& first_continues_p4 = this->first_continues_p4;
    const auto& open_start_p5 = this->open_start_p5;
    auto open_p6 = delims_p2 == Text::lit("double") ? Text::lit("{{") : Text::lit("{");
    auto how_p7 = TplHow{.close_p = close_p1, .delims_p = delims_p2, .open_p = open_p6, .is_raw_p = prism_rtl::deref(is_raw_p3), .first_continues_p = prism_rtl::deref(first_continues_p4)};
    auto start_p8 = TplRead{.l_p = l0_p0, .lines_p = Array<RawLine>{}, .cur_p = empty_line_p(), .closing_col_o = std::optional<Nat>{}, .closed_p = false, .at_line_start_p = !prism_rtl::deref(first_continues_p4), .going_p = true};
    TplRead this_ = start_p8;
    auto close_p1z = close_p1;
    auto first_continues_p4z = prism_rtl::deref(first_continues_p4);
    auto open_start_p5z = open_start_p5;
    return crate::prelude::call_then(crate::prelude::loop_job(std::tuple{std::move(this_)}, ({
        auto how_p7x = how_p7;
        [=, how_p7x = std::move(how_p7x)](std::tuple<TplRead> _p0) {
        auto this_ = std::get<0>(_p0);
        return prism_rtl::deref(this_).going_p
            ? ({
            this_ = template_step_f(this_, how_p7x);
            Expected<std::tuple<TplRead>, std::tuple<TplRead>>(std::tuple{this_});
        })
            : Expected<std::tuple<TplRead>, std::tuple<TplRead>>(unexpected(std::tuple{this_}));
    };
    })), [=](std::tuple<TplRead> _p0) {
        auto this_ = std::get<0>(_p0);
        return ({
            auto r_p9 = this_;
            auto l1_pa = prism_rtl::deref(r_p9).closed_p
                ? prism_rtl::deref(r_p9).l_p
                : crate::syntax::lexer::chars::lex_err_f(prism_rtl::deref(r_p9).l_p, open_start_p5z, prism_rtl::deref(prism_rtl::deref(r_p9).l_p).pos_p, prism_rtl::cat("a template never closes: expected `", close_p1z, "`"));
            (prism_rtl::finished(finish_template_lines_f(l1_pa, crate::prelude::push(prism_rtl::deref(r_p9).lines_p, prism_rtl::deref(r_p9).cur_p), crate::prelude::or_(prism_rtl::deref(r_p9).closing_col_o, Nat(0u)), first_continues_p4z)));
        });
    });
}


/// `Start TemplateBody, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::syntax::lexer::TPartTok>, crate::syntax::lexer::Lex>> start_template_body_f(crate::syntax::lexer::Lex l0_p0, Text close_p1, Text delims_p2, bool is_raw_p3, bool first_continues_p4, Nat open_start_p5) {
    return prism_rtl::make_rc<TemplateBody>(l0_p0, close_p1, delims_p2, is_raw_p3, first_continues_p4, open_start_p5);
}


/// TemplateStep: unbounded fn TplRead, TplHow -> TplRead
TplRead template_step_f(const TplRead& s_p0, const TplHow& how_p1) {
    auto c_p2 = crate::syntax::lexer::chars::peek_f(s_p0.l_p);
    return (s_p0.at_line_start_p && (!how_p1.is_raw_p)) && (crate::syntax::lexer::chars::trim_f(crate::syntax::lexer::chars::rest_of_line_f(s_p0.l_p)) == how_p1.open_p)
        ? brace_block_line_f(s_p0, crate::syntax::lexer::chars::rest_of_line_f(s_p0.l_p), how_p1)
        : crate::syntax::lexer::chars::starts_with_f(s_p0.l_p, how_p1.close_p)
        ? close_template_f(s_p0, how_p1)
        : c_p2 == Text::lit("")
        ? ({
        TplRead this_ = s_p0;
        this_.at_line_start_p = false;
        this_.going_p = false;
        (std::move(this_));
    })
        : c_p2 == Text::lit("\n")
        ? ({
        TplRead this_ = s_p0;
        this_.l_p = crate::syntax::lexer::chars::bump_f(this_.l_p);
        prism_rtl::deref(this_.cur_p).newline_p = true;
        this_.lines_p = crate::prelude::push(this_.lines_p, this_.cur_p);
        this_.cur_p = empty_line_p();
        this_.at_line_start_p = true;
        (std::move(this_));
    })
        : ({
        auto [item_p3, l2_p4] = template_item_f(s_p0.l_p, how_p1);
        ({
        TplRead this_ = s_p0;
        this_.at_line_start_p = false;
        this_.l_p = l2_p4;
        this_.cur_p = add_item_f(this_.cur_p, item_p3);
        (std::move(this_));
    });
    });
}


prism_rtl::Turn<TplRead> TemplateStep::cycle() const {
    const auto& s_p0 = this->s_p0;
    const auto& how_p1 = this->how_p1;
    auto c_p2 = crate::syntax::lexer::chars::peek_f(prism_rtl::deref(s_p0).l_p);
    return (prism_rtl::deref(s_p0).at_line_start_p && (!prism_rtl::deref(how_p1).is_raw_p)) && (crate::syntax::lexer::chars::trim_f(crate::syntax::lexer::chars::rest_of_line_f(prism_rtl::deref(s_p0).l_p)) == prism_rtl::deref(how_p1).open_p)
        ? ({
        auto how_p1x = how_p1;
        auto s_p0x = s_p0;
        (crate::prelude::call_then(crate::syntax::lexer::chars::start_rest_of_line_f(prism_rtl::deref(s_p0x).l_p), [=, how_p1x = std::move(how_p1x)](Text rest_of_line_f_5173) { return prism_rtl::more(prism_rtl::rc(BraceBlockLine(s_p0x, rest_of_line_f_5173, how_p1x))); }));
    })
        : crate::syntax::lexer::chars::starts_with_f(prism_rtl::deref(s_p0).l_p, prism_rtl::deref(how_p1).close_p)
        ? prism_rtl::finished(close_template_f(s_p0, how_p1))
        : c_p2 == Text::lit("")
        ? prism_rtl::finished(({
        TplRead this_ = s_p0;
        this_.at_line_start_p = false;
        this_.going_p = false;
        (std::move(this_));
    }))
        : c_p2 == Text::lit("\n")
        ? prism_rtl::finished(({
        TplRead this_ = s_p0;
        this_.l_p = crate::syntax::lexer::chars::bump_f(this_.l_p);
        prism_rtl::deref(this_.cur_p).newline_p = true;
        this_.lines_p = crate::prelude::push(this_.lines_p, this_.cur_p);
        this_.cur_p = empty_line_p();
        this_.at_line_start_p = true;
        (std::move(this_));
    }))
        : ({
        auto how_p1x = how_p1;
        auto s_p0x = s_p0;
        (crate::prelude::call_then(start_template_item_f(prism_rtl::deref(s_p0x).l_p, how_p1x), [=](std::tuple<RawItem, crate::syntax::lexer::Lex> template_item_f_5618) {
        return ({
            auto [item_p3, l2_p4] = template_item_f_5618;
            (prism_rtl::finished(({
            TplRead this_ = s_p0x;
            this_.at_line_start_p = false;
            this_.l_p = l2_p4;
            this_.cur_p = add_item_f(this_.cur_p, item_p3);
            (std::move(this_));
        })));
        });
    }));
    });
}


/// `Start TemplateStep, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<TplRead> start_template_step_f(TplRead s_p0, TplHow how_p1) {
    return prism_rtl::make_rc<TemplateStep>(s_p0, how_p1);
}


/// BraceBlockLine: unbounded fn TplRead, Text, TplHow -> TplRead
TplRead brace_block_line_f(const TplRead& s_p0, const Text& rest_p1, const TplHow& how_p2) {
    auto bs_p3 = prism_rtl::deref(s_p0.l_p).pos_p;
    auto past_p4 = crate::syntax::lexer::chars::forward_f(s_p0.l_p, crate::prelude::len_text(rest_p1));
    auto at_p5 = crate::syntax::lexer::chars::peek_f(past_p4) == Text::lit("\n")
        ? crate::syntax::lexer::chars::bump_f(past_p4)
        : past_p4;
    auto [toks_p7, l2_p8] = crate::syntax::lexer::layout::nested_f(at_p5, crate::syntax::lexer::Mode(crate::syntax::lexer::Mode::MBrace{how_p2.delims_p}));
    auto line_p6 = RawLine{.items_p = Array(std::vector{RawItem(RawItem::RiBlock{toks_p7, crate::syntax::Range{.start_p = bs_p3, .end_p = prism_rtl::deref(l2_p8).pos_p}})}), .newline_p = false, .block_p = true};
    TplRead this_ = s_p0;
    this_.lines_p = crate::prelude::push(this_.lines_p, line_p6);
    this_.l_p = l2_p8;
    return this_;
}


prism_rtl::Turn<TplRead> BraceBlockLine::cycle() const {
    const auto& s_p0 = this->s_p0;
    const auto& rest_p1 = this->rest_p1;
    const auto& how_p2 = this->how_p2;
    auto bs_p3 = prism_rtl::deref(prism_rtl::deref(s_p0).l_p).pos_p;
    auto past_p4 = crate::syntax::lexer::chars::forward_f(prism_rtl::deref(s_p0).l_p, crate::prelude::len_text(rest_p1));
    auto at_p5 = crate::syntax::lexer::chars::peek_f(past_p4) == Text::lit("\n")
        ? crate::syntax::lexer::chars::bump_f(past_p4)
        : past_p4;
    auto how_p2x = how_p2;
    auto s_p0x = s_p0;
    return crate::prelude::call_then(crate::syntax::lexer::layout::start_nested_f(at_p5, crate::syntax::lexer::Mode(crate::syntax::lexer::Mode::MBrace{prism_rtl::deref(how_p2x).delims_p})), [=](std::tuple<Array<crate::syntax::lexer::Tok>, crate::syntax::lexer::Lex> nested_f_5996) {
        return ({
            auto [toks_p7, l2_p8] = nested_f_5996;
            auto line_p6 = RawLine{.items_p = Array(std::vector{RawItem(RawItem::RiBlock{toks_p7, crate::syntax::Range{.start_p = bs_p3, .end_p = prism_rtl::deref(l2_p8).pos_p}})}), .newline_p = false, .block_p = true};
            (prism_rtl::finished(({
            TplRead this_ = s_p0x;
            this_.lines_p = crate::prelude::push(this_.lines_p, line_p6);
            this_.l_p = l2_p8;
            (std::move(this_));
        })));
        });
    });
}


/// `Start BraceBlockLine, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<TplRead> start_brace_block_line_f(TplRead s_p0, Text rest_p1, TplHow how_p2) {
    return prism_rtl::make_rc<BraceBlockLine>(s_p0, rest_p1, how_p2);
}


/// CloseTemplate: fn TplRead, TplHow -> TplRead
TplRead close_template_f(const TplRead& s_p0, const TplHow& how_p1) {
    TplRead this_ = s_p0;
    this_.at_line_start_p = false;
    if (only_whitespace_f(this_.cur_p) && ((crate::prelude::len(this_.lines_p) > Nat(0u)) || (!how_p1.first_continues_p))) {
        this_.closing_col_o = std::optional(text_len_f(this_.cur_p));
        prism_rtl::deref(this_.cur_p).items_p = Array<RawItem>{};
    }
    this_.l_p = crate::syntax::lexer::chars::forward_f(this_.l_p, crate::prelude::len_text(how_p1.close_p));
    this_.closed_p = true;
    this_.going_p = false;
    return this_;
}


/// TemplateItem: unbounded fn Lex, TplHow -> ((RawItem, Lex))
std::tuple<RawItem, crate::syntax::lexer::Lex> template_item_f(const crate::syntax::lexer::Lex& l_p0, const TplHow& how_p1) {
    auto live_p2 = !how_p1.is_raw_p;
    return (std::move(live_p2) && (how_p1.delims_p == Text::lit("double"))) && crate::syntax::lexer::chars::starts_with_f(l_p0, Text::lit("\\{{"))
        ? std::tuple{RawItem(RawItem::RiText{Text::lit("{{")}), crate::syntax::lexer::chars::forward_f(l_p0, Nat(3u))}
        : (std::move(live_p2) && (how_p1.delims_p == Text::lit("single"))) && crate::syntax::lexer::chars::starts_with_f(l_p0, Text::lit("\\{"))
        ? std::tuple{RawItem(RawItem::RiText{Text::lit("{")}), crate::syntax::lexer::chars::forward_f(l_p0, Nat(2u))}
        : std::move(live_p2) && crate::syntax::lexer::chars::starts_with_f(l_p0, how_p1.open_p)
        ? ({
        auto ps_p3 = l_p0.pos_p;
        auto [toks_p5, l2_p6] = crate::syntax::lexer::layout::nested_f(crate::syntax::lexer::chars::forward_f(l_p0, crate::prelude::len_text(how_p1.open_p)), crate::syntax::lexer::Mode(crate::syntax::lexer::Mode::MPlaceholder{how_p1.delims_p}));
        auto item_p4 = RawItem(RawItem::RiPlaceholder{toks_p5, crate::syntax::Range{.start_p = ps_p3, .end_p = prism_rtl::deref(l2_p6).pos_p}});
        std::tuple{item_p4, l2_p6};
    })
        : (std::move(live_p2) && crate::syntax::lexer::chars::starts_with_f(l_p0, Text::lit("<@"))) && crate::syntax::lexer::chars::is_upper_f(crate::syntax::lexer::chars::peek_at_f(l_p0, Nat(2u)))
        ? template_call_f(l_p0, how_p1.delims_p, how_p1.open_p)
        : ({
        auto run_p7 = crate::syntax::lexer::chars::match_here_f(([]() -> const Regex& { static const Regex r = Regex::lit("[^\\\\{<\\n]+", ""); return r; }()), l_p0);
        auto n_p8 = run_p7 == Text::lit("")
            ? crate::prelude::len_text(crate::syntax::lexer::chars::peek_f(l_p0))
            : crate::prelude::len_text(run_p7);
        auto l2_p9 = ({
            crate::syntax::lexer::Lex this_ = l_p0;
            this_.pos_p = this_.pos_p + n_p8;
            (std::move(this_));
        });
        std::tuple{RawItem(RawItem::RiText{crate::syntax::lexer::chars::slice_f(l_p0, l_p0.pos_p, prism_rtl::deref(l2_p9).pos_p)}), l2_p9};
    });
}


prism_rtl::Turn<std::tuple<RawItem, crate::syntax::lexer::Lex>> TemplateItem::cycle() const {
    const auto& l_p0 = this->l_p0;
    const auto& how_p1 = this->how_p1;
    auto live_p2 = !prism_rtl::deref(how_p1).is_raw_p;
    return (std::move(live_p2) && (prism_rtl::deref(how_p1).delims_p == Text::lit("double"))) && crate::syntax::lexer::chars::starts_with_f(l_p0, Text::lit("\\{{"))
        ? prism_rtl::finished(std::tuple{RawItem(RawItem::RiText{Text::lit("{{")}), crate::syntax::lexer::chars::forward_f(l_p0, Nat(3u))})
        : (std::move(live_p2) && (prism_rtl::deref(how_p1).delims_p == Text::lit("single"))) && crate::syntax::lexer::chars::starts_with_f(l_p0, Text::lit("\\{"))
        ? prism_rtl::finished(std::tuple{RawItem(RawItem::RiText{Text::lit("{")}), crate::syntax::lexer::chars::forward_f(l_p0, Nat(2u))})
        : std::move(live_p2) && crate::syntax::lexer::chars::starts_with_f(l_p0, prism_rtl::deref(how_p1).open_p)
        ? ({
        auto ps_p3 = prism_rtl::deref(l_p0).pos_p;
        auto how_p1x = how_p1;
        auto l_p0x = l_p0;
        (crate::prelude::call_then(crate::syntax::lexer::layout::start_nested_f(crate::syntax::lexer::chars::forward_f(l_p0x, crate::prelude::len_text(prism_rtl::deref(how_p1x).open_p)), crate::syntax::lexer::Mode(crate::syntax::lexer::Mode::MPlaceholder{prism_rtl::deref(how_p1x).delims_p})), [=, ps_p3 = std::move(ps_p3)](std::tuple<Array<crate::syntax::lexer::Tok>, crate::syntax::lexer::Lex> nested_f_7242) {
        return ({
            auto [toks_p5, l2_p6] = nested_f_7242;
            auto item_p4 = RawItem(RawItem::RiPlaceholder{toks_p5, crate::syntax::Range{.start_p = ps_p3, .end_p = prism_rtl::deref(l2_p6).pos_p}});
            (prism_rtl::finished(std::tuple{item_p4, l2_p6}));
        });
    }));
    })
        : (std::move(live_p2) && crate::syntax::lexer::chars::starts_with_f(l_p0, Text::lit("<@"))) && crate::syntax::lexer::chars::is_upper_f(crate::syntax::lexer::chars::peek_at_f(l_p0, Nat(2u)))
        ? prism_rtl::more(prism_rtl::rc(TemplateCall(l_p0, prism_rtl::deref(how_p1).delims_p, prism_rtl::deref(how_p1).open_p)))
        : ({
        auto run_p7 = crate::syntax::lexer::chars::match_here_f(([]() -> const Regex& { static const Regex r = Regex::lit("[^\\\\{<\\n]+", ""); return r; }()), l_p0);
        auto n_p8 = run_p7 == Text::lit("")
            ? crate::prelude::len_text(crate::syntax::lexer::chars::peek_f(l_p0))
            : crate::prelude::len_text(run_p7);
        auto l2_p9 = ({
            crate::syntax::lexer::Lex this_ = l_p0;
            this_.pos_p = this_.pos_p + n_p8;
            (std::move(this_));
        });
        (prism_rtl::finished(std::tuple{RawItem(RawItem::RiText{crate::syntax::lexer::chars::slice_f(l_p0, prism_rtl::deref(l_p0).pos_p, prism_rtl::deref(l2_p9).pos_p)}), l2_p9}));
    });
}


/// `Start TemplateItem, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<RawItem, crate::syntax::lexer::Lex>> start_template_item_f(crate::syntax::lexer::Lex l_p0, TplHow how_p1) {
    return prism_rtl::make_rc<TemplateItem>(l_p0, how_p1);
}


/// TemplateCall: unbounded fn Lex, Text, Text -> ((RawItem, Lex))
std::tuple<RawItem, crate::syntax::lexer::Lex> template_call_f(const crate::syntax::lexer::Lex& l0_p0, const Text& delims_p1, const Text& open_p2) {
    auto start_p3 = l0_p0.pos_p;
    auto&& _sigils_p8 = crate::syntax::lexer::words::read_sigils_f(crate::syntax::lexer::chars::bump_f(l0_p0));
    auto&& sigils_p8 = std::get<0>(_sigils_p8);
    auto&& l1_p9 = std::get<2>(_sigils_p8);
    auto [path_pa, l2_pb] = crate::syntax::lexer::words::lex_qualified_path_f(l1_p9);
    auto name_p4 = crate::syntax::lexer::NameTok{.sigils_p = sigils_p8, .path_p = path_pa, .case_p = crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseUpper{})};
    auto close_p5 = prism_rtl::cat("</", sigils_p8, crate::syntax::lexer::chars::join_f(path_pa, Text::lit(".")), ">");
    auto r_p6 = ({
        CallRead this_ = CallRead{.l_p = l2_pb, .attrs_p = Array<crate::syntax::lexer::AttrTok>{}, .body_o = std::optional<Array<crate::syntax::lexer::TPartTok>>{}, .going_p = true};
        while (this_.going_p) {
            this_ = call_step_f(this_, start_p3, close_p5, delims_p1, open_p2);
        }
        (std::move(this_));
    });
    auto item_p7 = RawItem(RawItem::RiCall{name_p4, prism_rtl::deref(r_p6).attrs_p, prism_rtl::deref(r_p6).body_o, crate::syntax::Range{.start_p = start_p3, .end_p = prism_rtl::deref(prism_rtl::deref(r_p6).l_p).pos_p}});
    return std::tuple{item_p7, prism_rtl::deref(r_p6).l_p};
}


prism_rtl::Turn<std::tuple<RawItem, crate::syntax::lexer::Lex>> TemplateCall::cycle() const {
    const auto& l0_p0 = this->l0_p0;
    const auto& delims_p1 = this->delims_p1;
    const auto& open_p2 = this->open_p2;
    auto start_p3 = prism_rtl::deref(l0_p0).pos_p;
    auto delims_p1x = delims_p1;
    auto l0_p0x = l0_p0;
    auto open_p2x = open_p2;
    return crate::prelude::call_then(crate::syntax::lexer::words::start_read_sigils_f(crate::syntax::lexer::chars::bump_f(l0_p0x)), [=](std::tuple<Text, bool, crate::syntax::lexer::Lex> read_sigils_f_8234) {
        return ({
            auto&& _sigils_p8 = read_sigils_f_8234;
            auto&& sigils_p8 = std::get<0>(_sigils_p8);
            auto&& l1_p9 = std::get<2>(_sigils_p8);
            (crate::prelude::call_then(crate::syntax::lexer::words::start_lex_qualified_path_f(l1_p9), [=](std::tuple<Array<Text>, crate::syntax::lexer::Lex> lex_qualified_path_f_8278) {
            return ({
                auto [path_pa, l2_pb] = lex_qualified_path_f_8278;
                auto name_p4 = crate::syntax::lexer::NameTok{.sigils_p = sigils_p8, .path_p = path_pa, .case_p = crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseUpper{})};
                auto close_p5 = prism_rtl::cat("</", sigils_p8, crate::syntax::lexer::chars::join_f(path_pa, Text::lit(".")), ">");
                CallRead this_ = CallRead{.l_p = l2_pb, .attrs_p = Array<crate::syntax::lexer::AttrTok>{}, .body_o = std::optional<Array<crate::syntax::lexer::TPartTok>>{}, .going_p = true};
                auto name_p4z = name_p4;
                auto start_p3z = start_p3;
                (crate::prelude::call_then(crate::prelude::loop_job(std::tuple{std::move(this_)}, ({
                auto close_p5x = close_p5;
                auto delims_p1xx = delims_p1x;
                auto open_p2xx = open_p2x;
                auto start_p3x = start_p3;
                [=, close_p5x = std::move(close_p5x), delims_p1xx = std::move(delims_p1xx), open_p2xx = std::move(open_p2xx), start_p3x = std::move(start_p3x)](std::tuple<CallRead> _p0) {
                auto this_ = std::get<0>(_p0);
                return prism_rtl::deref(this_).going_p
                    ? ({
                    this_ = call_step_f(this_, start_p3x, close_p5x, delims_p1xx, open_p2xx);
                    Expected<std::tuple<CallRead>, std::tuple<CallRead>>(std::tuple{this_});
                })
                    : Expected<std::tuple<CallRead>, std::tuple<CallRead>>(unexpected(std::tuple{this_}));
            };
            })), [=, name_p4z = std::move(name_p4z), start_p3z = std::move(start_p3z)](std::tuple<CallRead> _p0) {
                auto this_ = std::get<0>(_p0);
                return ({
                    auto r_p6 = this_;
                    auto item_p7 = RawItem(RawItem::RiCall{name_p4z, prism_rtl::deref(r_p6).attrs_p, prism_rtl::deref(r_p6).body_o, crate::syntax::Range{.start_p = start_p3z, .end_p = prism_rtl::deref(prism_rtl::deref(r_p6).l_p).pos_p}});
                    (prism_rtl::finished(std::tuple{item_p7, prism_rtl::deref(r_p6).l_p}));
                });
            }));
            });
        }));
        });
    });
}


/// `Start TemplateCall, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<RawItem, crate::syntax::lexer::Lex>> start_template_call_f(crate::syntax::lexer::Lex l0_p0, Text delims_p1, Text open_p2) {
    return prism_rtl::make_rc<TemplateCall>(l0_p0, delims_p1, open_p2);
}


/// CallStep: unbounded fn CallRead, Nat, Text, Text, Text -> CallRead
CallRead call_step_f(const CallRead& s0_p0, const Nat& start_p1, const Text& close_p2, const Text& delims_p3, const Text& open_p4) {
    auto l_p5 = ({
        crate::syntax::lexer::Lex this_ = s0_p0.l_p;
        this_.pos_p = crate::syntax::lexer::chars::match_end_f(([]() -> const Regex& { static const Regex r = Regex::lit("[ \\n\\r]*", ""); return r; }()), this_.src_p, this_.pos_p);
        (std::move(this_));
    });
    auto s_p6 = ({
        CallRead this_ = s0_p0;
        this_.l_p = l_p5;
        (std::move(this_));
    });
    auto at_p7 = prism_rtl::deref(l_p5).pos_p;
    return crate::syntax::lexer::chars::starts_with_f(l_p5, Text::lit("/>"))
        ? ({
        CallRead this_ = s_p6;
        this_.l_p = crate::syntax::lexer::chars::forward_f(l_p5, Nat(2u));
        this_.going_p = false;
        (std::move(this_));
    })
        : crate::syntax::lexer::chars::peek_f(l_p5) == Text::lit(">")
        ? ({
        auto past_p8 = crate::syntax::lexer::chars::bump_f(l_p5);
        auto continues_p9 = crate::syntax::lexer::chars::peek_f(past_p8) != Text::lit("\n");
        auto from_pa = std::move(continues_p9)
            ? past_p8
            : crate::syntax::lexer::chars::bump_f(past_p8);
        auto [parts_pb, l3_pc] = template_body_f(from_pa, close_p2, delims_p3, false, continues_p9, start_p1);
        ({
        CallRead this_ = s_p6;
        this_.body_o = std::optional(parts_pb);
        this_.l_p = l3_pc;
        this_.going_p = false;
        (std::move(this_));
    });
    })
        : !crate::syntax::lexer::chars::is_ident_start_f(crate::syntax::lexer::chars::peek_f(l_p5))
        ? ({
        CallRead this_ = s_p6;
        this_.l_p = crate::syntax::lexer::chars::lex_err_f(l_p5, at_p7, at_p7 + Nat(1u), Text::lit("expected an attribute `name=value`, `/>` or `>` in a template call"));
        this_.going_p = false;
        (std::move(this_));
    })
        : ({
        auto [aname_pd, l3_pe] = crate::syntax::lexer::words::lex_ident_f(l_p5);
        (crate::syntax::lexer::chars::peek_f(l3_pe) != Text::lit("=")
        ? ({
        CallRead this_ = s_p6;
        this_.l_p = crate::syntax::lexer::chars::lex_err_f(l3_pe, at_p7, prism_rtl::deref(l3_pe).pos_p, Text::lit("an attribute is `name=value`"));
        (std::move(this_));
    })
        : ({
        auto [tokens_pf, l4_pg] = attr_value_f(crate::syntax::lexer::chars::bump_f(l3_pe), delims_p3, open_p4);
        ({
        CallRead this_ = s_p6;
        this_.attrs_p = crate::prelude::push(this_.attrs_p, crate::syntax::lexer::AttrTok{.name_p = aname_pd, .tokens_p = tokens_pf, .span_p = crate::syntax::Range{.start_p = at_p7, .end_p = prism_rtl::deref(l4_pg).pos_p}});
        this_.l_p = l4_pg;
        (std::move(this_));
    });
    }));
    });
}


prism_rtl::Turn<CallRead> CallStep::cycle() const {
    const auto& s0_p0 = this->s0_p0;
    const auto& start_p1 = this->start_p1;
    const auto& close_p2 = this->close_p2;
    const auto& delims_p3 = this->delims_p3;
    const auto& open_p4 = this->open_p4;
    auto l_p5 = ({
        crate::syntax::lexer::Lex this_ = prism_rtl::deref(s0_p0).l_p;
        this_.pos_p = crate::syntax::lexer::chars::match_end_f(([]() -> const Regex& { static const Regex r = Regex::lit("[ \\n\\r]*", ""); return r; }()), this_.src_p, this_.pos_p);
        (std::move(this_));
    });
    auto s_p6 = ({
        CallRead this_ = s0_p0;
        this_.l_p = l_p5;
        (std::move(this_));
    });
    auto at_p7 = prism_rtl::deref(l_p5).pos_p;
    return crate::syntax::lexer::chars::starts_with_f(l_p5, Text::lit("/>"))
        ? prism_rtl::finished(({
        CallRead this_ = s_p6;
        this_.l_p = crate::syntax::lexer::chars::forward_f(l_p5, Nat(2u));
        this_.going_p = false;
        (std::move(this_));
    }))
        : crate::syntax::lexer::chars::peek_f(l_p5) == Text::lit(">")
        ? ({
        auto past_p8 = crate::syntax::lexer::chars::bump_f(l_p5);
        auto continues_p9 = crate::syntax::lexer::chars::peek_f(past_p8) != Text::lit("\n");
        auto from_pa = std::move(continues_p9)
            ? past_p8
            : crate::syntax::lexer::chars::bump_f(past_p8);
        auto close_p2x = close_p2;
        auto delims_p3x = delims_p3;
        auto start_p1x = start_p1;
        (crate::prelude::call_then(start_template_body_f(from_pa, close_p2x, delims_p3x, false, std::move(continues_p9), start_p1x), [=](std::tuple<Array<crate::syntax::lexer::TPartTok>, crate::syntax::lexer::Lex> template_body_f_9198) {
        return ({
            auto [parts_pb, l3_pc] = template_body_f_9198;
            (prism_rtl::finished(({
            CallRead this_ = s_p6;
            this_.body_o = std::optional(parts_pb);
            this_.l_p = l3_pc;
            this_.going_p = false;
            (std::move(this_));
        })));
        });
    }));
    })
        : !crate::syntax::lexer::chars::is_ident_start_f(crate::syntax::lexer::chars::peek_f(l_p5))
        ? prism_rtl::finished(({
        CallRead this_ = s_p6;
        this_.l_p = crate::syntax::lexer::chars::lex_err_f(l_p5, at_p7, at_p7 + Nat(1u), Text::lit("expected an attribute `name=value`, `/>` or `>` in a template call"));
        this_.going_p = false;
        (std::move(this_));
    }))
        : ({
        auto delims_p3x = delims_p3;
        auto open_p4x = open_p4;
        auto start_p1x = start_p1;
        (crate::prelude::call_then(crate::syntax::lexer::words::start_lex_ident_f(l_p5), [=, delims_p3x = std::move(delims_p3x), open_p4x = std::move(open_p4x)](std::tuple<Text, crate::syntax::lexer::Lex> lex_ident_f_9597) {
        return ({
            auto [aname_pd, l3_pe] = lex_ident_f_9597;
            (crate::syntax::lexer::chars::peek_f(l3_pe) != Text::lit("=")
            ? prism_rtl::finished(({
            CallRead this_ = s_p6;
            this_.l_p = crate::syntax::lexer::chars::lex_err_f(l3_pe, at_p7, prism_rtl::deref(l3_pe).pos_p, Text::lit("an attribute is `name=value`"));
            (std::move(this_));
        }))
            : ({
            auto [tokens_pf, l4_pg] = attr_value_f(crate::syntax::lexer::chars::bump_f(l3_pe), delims_p3x, open_p4x);
            (prism_rtl::finished(({
            CallRead this_ = s_p6;
            this_.attrs_p = crate::prelude::push(this_.attrs_p, crate::syntax::lexer::AttrTok{.name_p = aname_pd, .tokens_p = tokens_pf, .span_p = crate::syntax::Range{.start_p = at_p7, .end_p = prism_rtl::deref(l4_pg).pos_p}});
            this_.l_p = l4_pg;
            (std::move(this_));
        })));
        }));
        });
    }));
    });
}


/// `Start CallStep, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<CallRead> start_call_step_f(CallRead s0_p0, Nat start_p1, Text close_p2, Text delims_p3, Text open_p4) {
    return prism_rtl::make_rc<CallStep>(s0_p0, start_p1, close_p2, delims_p3, open_p4);
}


/// AttrValue: unbounded fn Lex, Text, Text -> (([Tok], Lex))
std::tuple<Array<crate::syntax::lexer::Tok>, crate::syntax::lexer::Lex> attr_value_f(const crate::syntax::lexer::Lex& l_p0, const Text& delims_p1, const Text& open_p2) {
    return crate::syntax::lexer::chars::starts_with_f(l_p0, open_p2)
        ? crate::syntax::lexer::layout::nested_f(crate::syntax::lexer::chars::forward_f(l_p0, crate::prelude::len_text(open_p2)), crate::syntax::lexer::Mode(crate::syntax::lexer::Mode::MPlaceholder{delims_p1}))
        : crate::syntax::lexer::chars::peek_f(l_p0) == Text::lit("\"")
        ? ({
        auto [text_p4, l2_p5] = crate::syntax::lexer::literals::lex_text_f(l_p0);
        auto tok_p3 = crate::syntax::lexer::Tok{.kind_p = crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KText{Text::lit(""), text_p4}), .span_p = crate::syntax::Range{.start_p = l_p0.pos_p, .end_p = prism_rtl::deref(l2_p5).pos_p}, .touches_p = false, .line_start_p = false};
        std::tuple{Array(std::vector{tok_p3}), l2_p5};
    })
        : std::tuple{Array<crate::syntax::lexer::Tok>{}, crate::syntax::lexer::chars::lex_err_f(l_p0, l_p0.pos_p, l_p0.pos_p, prism_rtl::cat("an attribute\'s value is a placeholder `", open_p2, "...` or a text literal"))};
}


/// FinishTemplateLines: fn Lex, [RawLine], Nat, Bool -> (([TPartTok], Lex))
std::tuple<Array<crate::syntax::lexer::TPartTok>, crate::syntax::lexer::Lex> finish_template_lines_f(const crate::syntax::lexer::Lex& l0_p0, const Array<RawLine>& lines_p1, const Nat& strip_p2, const bool& first_continues_p3) {
    std::tuple<Array<crate::syntax::lexer::TPartTok>, crate::syntax::lexer::Lex> this_ = std::tuple{Array<crate::syntax::lexer::TPartTok>{}, l0_p0};
    crate::syntax::lexer::Lex l_p4 = l0_p0;
    Array<crate::syntax::lexer::TPartTok> parts_p5 = Array<crate::syntax::lexer::TPartTok>{};
    for (auto&& [i10950, v10950] : prism_rtl::enumerate(lines_p1)) {
        auto k10950 = crate::prelude::nat_of(i10950);
        auto line_p6 = v10950;
        if (prism_rtl::deref(line_p6).block_p) {
            parts_p5 = crate::prelude::append(parts_p5, block_parts_f(prism_rtl::deref(line_p6).items_p));
        } else  {
            auto first_p7 = (k10950 == Nat(0u)) && first_continues_p3;
            auto [items_p8, l2_p9] = (!std::move(first_p7)) && (strip_p2 > Nat(0u))
                ? strip_line_f(line_p6, strip_p2, l_p4)
                : std::tuple{prism_rtl::deref(line_p6).items_p, l_p4};
            l_p4 = l2_p9;
            auto non_blank_pc = crate::prelude::fold(items_p8, Array<RawItem>{}, [&](const Array<RawItem>& acc_pa, const RawItem& it_pb) { return is_blank_or_empty_f(it_pb) ? acc_pa : crate::prelude::push(acc_pa, it_pb); });
            auto alone_pd = (((!std::move(first_p7)) && prism_rtl::deref(line_p6).newline_p) && (crate::prelude::len(non_blank_pc) == Nat(1u))) && is_placeholder_item_f(crate::prelude::or_(crate::prelude::index(non_blank_pc, Nat(0u)), RawItem(RawItem::RiText{Text::lit("")})));
            if (std::move(alone_pd)) {
                parts_p5 = crate::prelude::push(parts_p5, alone_placeholder_f(items_p8));
            } else  {
                parts_p5 = crate::prelude::fold(items_p8, parts_p5, push_part_f);
                if (prism_rtl::deref(line_p6).newline_p) {
                    parts_p5 = push_part_f(parts_p5, RawItem(RawItem::RiText{Text::lit("\n")}));
                }
            }
        }
    }
    this_ = std::tuple{parts_p5, l_p4};
    return this_;
}


/// BlockParts: fn [RawItem] -> [TPartTok]
Array<crate::syntax::lexer::TPartTok> block_parts_f(const Array<RawItem>& items_p0) {
    return crate::prelude::fold(items_p0, Array<crate::syntax::lexer::TPartTok>{}, [&](const Array<crate::syntax::lexer::TPartTok>& acc_p1, const RawItem& it_p2) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::syntax::lexer::TPartTok>> _v;
            if (prism_rtl::is<RawItem::RiBlock>(it_p2)) {
                auto&& tokens_p3 = prism_rtl::as<RawItem::RiBlock>(it_p2).a0;
                auto&& span_p4 = prism_rtl::as<RawItem::RiBlock>(it_p2).a1;
                _v.set(crate::prelude::push(acc_p1, crate::syntax::lexer::TPartTok(crate::syntax::lexer::TPartTok::TptBlock{tokens_p3, span_p4})));
                goto _done;
            }
            {
                _v.set(acc_p1);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


/// StripLine: fn RawLine, Nat, Lex -> (([RawItem], Lex))
std::tuple<Array<RawItem>, crate::syntax::lexer::Lex> strip_line_f(const RawLine& line_p0, const Nat& strip_p1, const crate::syntax::lexer::Lex& l_p2) {
    auto blank_p3 = only_whitespace_f(line_p0);
    auto n_p4 = ({
        __label__ _done;
        prism_rtl::Slot<Nat> _v;
        auto&& _m = crate::prelude::index(line_p0.items_p, Nat(0u));
        if (prism_rtl::is_some(_m) && prism_rtl::is<RawItem::RiText>(prism_rtl::some_of(_m))) {
            auto&& s_p8 = prism_rtl::as<RawItem::RiText>(prism_rtl::some_of(_m)).a0;
            _v.set(crate::syntax::lexer::chars::leading_in_f(s_p8, Text::lit(" ")));
            goto _done;
        }
        {
            _v.set(Nat(0u));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto items_p5 = ({
        __label__ _done;
        prism_rtl::Slot<Array<RawItem>> _v;
        auto&& _m = crate::prelude::index(line_p0.items_p, Nat(0u));
        if (prism_rtl::is_some(_m) && prism_rtl::is<RawItem::RiText>(prism_rtl::some_of(_m))) {
            auto&& s_p9 = prism_rtl::as<RawItem::RiText>(prism_rtl::some_of(_m)).a0;
            _v.set(({
                auto rest_pa = ({
                    __label__ _done;
                    prism_rtl::Slot<Text> _v;
                    auto&& _m = crate::prelude::cursor_at(s_p9, crate::prelude::min(n_p4, strip_p1));
                    if (prism_rtl::is_some(_m)) {
                        auto&& c_pb = prism_rtl::some_of(_m);
                        _v.set(crate::prelude::after(c_pb));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(s_p9);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                (crate::prelude::append(Array(std::vector{RawItem(RawItem::RiText{rest_pa})}), crate::prelude::drop(line_p0.items_p, Nat(1u))));
            }));
            goto _done;
        }
        {
            _v.set(line_p0.items_p);
            goto _done;
        }
    _done:
        _v.take();
    });
    auto l2_p6 = (n_p4 < strip_p1) && (!std::move(blank_p3))
        ? crate::syntax::lexer::chars::lex_err_f(l_p2, prism_rtl::deref(first_item_span_f(items_p5)).start_p, prism_rtl::deref(first_item_span_f(items_p5)).end_p, Text::lit("a template line is indented less than its closing tag (Q-CT3)"))
        : l_p2;
    auto kept_p7 = crate::prelude::index(items_p5, Nat(0u)) == std::optional(RawItem(RawItem::RiText{Text::lit("")}))
        ? crate::prelude::drop(items_p5, Nat(1u))
        : items_p5;
    return std::tuple{kept_p7, l2_p6};
}


/// IsBlankOrEmpty: fn RawItem -> Bool
bool is_blank_or_empty_f(const RawItem& raw_item0) {
    if (prism_rtl::is<RawItem::RiText>(raw_item0)) {
        auto&& s_p0 = prism_rtl::as<RawItem::RiText>(raw_item0).a0;
        return crate::syntax::lexer::chars::trim_f(s_p0) == Text::lit("");
    }
    {
        return false;
    }
}


/// IsPlaceholderItem: fn RawItem -> Bool
bool is_placeholder_item_f(const RawItem& raw_item0) {
    if (prism_rtl::is<RawItem::RiPlaceholder>(raw_item0)) {
        return true;
    }
    {
        return false;
    }
}


/// FirstItemSpan: fn [RawItem] -> Range
crate::syntax::Range first_item_span_f(const Array<RawItem>& items_p0) {
    return crate::prelude::or_(crate::prelude::fold(items_p0, std::optional<crate::syntax::Range>{}, [&](const std::optional<crate::syntax::Range>& found_o1, const RawItem& it_p2) {
        return found_o1 != std::optional<crate::syntax::Range>{}
            ? found_o1
            : item_span_o(it_p2);
    }), crate::syntax::Range{.start_p = Nat(0u), .end_p = Nat(0u)});
}


/// ?ItemSpan: fn RawItem -> ?Range
std::optional<crate::syntax::Range> item_span_o(const RawItem& raw_item0) {
    if (prism_rtl::is<RawItem::RiPlaceholder>(raw_item0)) {
        auto&& span_p0 = prism_rtl::as<RawItem::RiPlaceholder>(raw_item0).a1;
        return std::optional(span_p0);
    }
    if (prism_rtl::is<RawItem::RiBlock>(raw_item0)) {
        auto&& span_p1 = prism_rtl::as<RawItem::RiBlock>(raw_item0).a1;
        return std::optional(span_p1);
    }
    if (prism_rtl::is<RawItem::RiCall>(raw_item0)) {
        auto&& span_p2 = prism_rtl::as<RawItem::RiCall>(raw_item0).a3;
        return std::optional(span_p2);
    }
    {
        return std::optional<crate::syntax::Range>{};
    }
}


/// AlonePlaceholder: fn [RawItem] -> TPartTok
crate::syntax::lexer::TPartTok alone_placeholder_f(const Array<RawItem>& items_p0) {
    auto&& _part_p4 = crate::prelude::fold(items_p0, std::tuple{Nat(0u), crate::syntax::lexer::TPartTok(crate::syntax::lexer::TPartTok::TptText{Text::lit("")})}, [&](const std::tuple<Nat, crate::syntax::lexer::TPartTok>& _p0, const RawItem& it_p3) {
        auto&& c_p1 = std::get<0>(_p0);
        auto&& p_p2 = std::get<1>(_p0);
        return alone_step_f(c_p1, p_p2, it_p3);
    });
    auto&& part_p4 = std::get<1>(_part_p4);
    return part_p4;
}


/// AloneStep: fn Nat, TPartTok, RawItem -> ((Nat, TPartTok))
std::tuple<Nat, crate::syntax::lexer::TPartTok> alone_step_f(const Nat& c_p0, const crate::syntax::lexer::TPartTok& tpart_tok1, const RawItem& raw_item2) {
    auto&& _m = std::tuple{tpart_tok1, raw_item2};
    if (prism_rtl::is<crate::syntax::lexer::TPartTok::TptText>(std::get<0>(_m)) && prism_rtl::is<RawItem::RiText>(std::get<1>(_m))) {
        auto&& c0_1_0 = prism_rtl::as<crate::syntax::lexer::TPartTok::TptText>(std::get<0>(_m)).a0;
        auto&& s_p1 = prism_rtl::as<RawItem::RiText>(std::get<1>(_m)).a0;
        if (c0_1_0 == Text::lit("")) {
            return c_p0 == Nat(0u)
                ? std::tuple{crate::syntax::lexer::chars::leading_in_f(s_p1, Text::lit(" ")), crate::syntax::lexer::TPartTok(crate::syntax::lexer::TPartTok::TptText{Text::lit("")})}
                : std::tuple{c_p0, crate::syntax::lexer::TPartTok(crate::syntax::lexer::TPartTok::TptText{Text::lit("")})};
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TPartTok::TptText>(std::get<0>(_m)) && prism_rtl::is<RawItem::RiPlaceholder>(std::get<1>(_m))) {
        auto&& c1_1_0 = prism_rtl::as<crate::syntax::lexer::TPartTok::TptText>(std::get<0>(_m)).a0;
        auto&& tokens_p3 = prism_rtl::as<RawItem::RiPlaceholder>(std::get<1>(_m)).a0;
        auto&& span_p4 = prism_rtl::as<RawItem::RiPlaceholder>(std::get<1>(_m)).a1;
        if (c1_1_0 == Text::lit("")) {
            return std::tuple{c_p0, crate::syntax::lexer::TPartTok(crate::syntax::lexer::TPartTok::TptPlaceholder{tokens_p3, std::optional(c_p0), span_p4})};
        }
    }
    {
        auto&& p_p6 = std::get<0>(_m);
        return std::tuple{c_p0, p_p6};
    }
    prism_rtl::unreachable("no arm matched");
}


/// PushPart: fn [TPartTok], RawItem -> [TPartTok]
Array<crate::syntax::lexer::TPartTok> push_part_f(const Array<crate::syntax::lexer::TPartTok>& parts_p0, const RawItem& raw_item1) {
    if (prism_rtl::is<RawItem::RiText>(raw_item1)) {
        auto&& c0_1_0 = prism_rtl::as<RawItem::RiText>(raw_item1).a0;
        if (c0_1_0 == Text::lit("")) {
            return parts_p0;
        }
    }
    if (prism_rtl::is<RawItem::RiText>(raw_item1)) {
        auto&& t_p2 = prism_rtl::as<RawItem::RiText>(raw_item1).a0;
        auto&& _m = crate::syntax::lexer::chars::last_o(parts_p0);
        if (prism_rtl::is_some(_m) && prism_rtl::is<crate::syntax::lexer::TPartTok::TptText>(prism_rtl::some_of(_m))) {
            auto&& s_p3 = prism_rtl::as<crate::syntax::lexer::TPartTok::TptText>(prism_rtl::some_of(_m)).a0;
            return crate::prelude::push(crate::syntax::lexer::chars::pop_f(parts_p0), crate::syntax::lexer::TPartTok(crate::syntax::lexer::TPartTok::TptText{prism_rtl::cat(s_p3, t_p2)}));
        }
        {
            return crate::prelude::push(parts_p0, crate::syntax::lexer::TPartTok(crate::syntax::lexer::TPartTok::TptText{t_p2}));
        }
    }
    if (prism_rtl::is<RawItem::RiPlaceholder>(raw_item1)) {
        auto&& tokens_p5 = prism_rtl::as<RawItem::RiPlaceholder>(raw_item1).a0;
        auto&& span_p6 = prism_rtl::as<RawItem::RiPlaceholder>(raw_item1).a1;
        return crate::prelude::push(parts_p0, crate::syntax::lexer::TPartTok(crate::syntax::lexer::TPartTok::TptPlaceholder{tokens_p5, std::optional<Nat>{}, span_p6}));
    }
    if (prism_rtl::is<RawItem::RiBlock>(raw_item1)) {
        auto&& tokens_p8 = prism_rtl::as<RawItem::RiBlock>(raw_item1).a0;
        auto&& span_p9 = prism_rtl::as<RawItem::RiBlock>(raw_item1).a1;
        return crate::prelude::push(parts_p0, crate::syntax::lexer::TPartTok(crate::syntax::lexer::TPartTok::TptBlock{tokens_p8, span_p9}));
    }
    if (prism_rtl::is<RawItem::RiCall>(raw_item1)) {
        auto&& name_pb = prism_rtl::as<RawItem::RiCall>(raw_item1).a0;
        auto&& attrs_pc = prism_rtl::as<RawItem::RiCall>(raw_item1).a1;
        auto&& body_od = prism_rtl::as<RawItem::RiCall>(raw_item1).a2;
        auto&& span_pe = prism_rtl::as<RawItem::RiCall>(raw_item1).a3;
        return crate::prelude::push(parts_p0, crate::syntax::lexer::TPartTok(crate::syntax::lexer::TPartTok::TptCall{name_pb, attrs_pc, body_od, span_pe}));
    }
    prism_rtl::unreachable("no arm matched");
}

}  // namespace crate::syntax::lexer::templates
