// The module `Parser`: its types, nodes and jobs declared, and its choices' handles, emitted by
// prismc (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace parser {

struct ArgsRead;

struct Climb;

struct FieldsRead;

struct ModRead;

struct Pair;

struct Parsed;

struct Ps;

struct ParseFile;

struct ParseFragment;

struct NewPs;

struct Sub;

struct PairBrackets;

struct Recover;

struct Recovered;

struct ExpectStmtEnd;

template <class A>
struct Bracketed;

template <class A>
struct LayoutItems;

template <class A>
struct Commas;

struct ParseModule;

struct ModuleItem;

struct HeaderOrDecl;

struct ParseDecl;

struct DeclKindOf;

struct OptionalAnnotation;

struct ParseSignature;

struct OptionalBounds;

struct ParseFnClause;

struct ParseFnBody;

struct ParseTypeDecl;

struct ParseTypeBody;

struct ParseFieldBlock;

struct ParseField;

struct ParseCase;

struct ParseTagDecl;

struct ParseTraitDecl;

struct ParseImplDecl;

struct ParseTraitItems;

struct ParseTraitItem;

struct OptionalType;

struct ParseExpr;

struct ParseArgExpr;

struct ParseExprCtx;

struct ParseRhsExpr;

struct ParseBinary;

struct ClimbStep;

struct ParsePrefix;

struct ParsePostfixExpr;

struct ParsePostfix;

struct PostfixStep;

struct FieldOrMethod;

struct ParseTypeArgs;

struct ParseCallArgs;

struct ParseOneArg;

struct ParseArg;

struct ParseParenArgs;

struct ParsePrimary;

struct LiteralPrimary;

struct NamePrimary;

struct TypeArgsOn;

struct ParenPrimary;

struct SquarePrimary;

struct MapPrimary;

struct ParseMapEntry;

struct LensPrimary;

struct KeywordPrimary;

struct ParseLiteral;

struct TextSegment;

struct ParseNested;

struct ParseTemplate;

struct TemplateParts;

struct TemplatePartOf;

struct AttrArg;

struct ParseLambda;

struct LambdaParams;

struct ParseCond;

struct ParseIf;

struct ParseMatch;

struct MatchArms;

struct ParseFor;

struct ForBindersOf;

struct ParseBlockAfterColon;

struct ParseIndentedBlock;

struct ParseBlockUntilEof;

struct StmtsUntil;

struct ParseStmt;

struct StmtKindOf;

struct OtherStmt;

struct OptionalRhs;

struct ParseUpdateStmt;

struct ParseReference;

struct ParseType;

struct ParseEmitType;

struct ParseUnionType;

struct ParseMapType;

struct ParseSigiledType;

struct ParseAppType;

struct ParseTypeAtom;

struct TypeAtomBody;

struct ParseBounds;

struct ParseBound;

struct ParseRow;

struct ParseRowTerm;

struct ParsePattern;

struct LiteralPattern;

struct NamePattern;

struct ParseRecordPattern;

struct ParseCheckDecl;

struct ParseCheckLine;

struct OptionalPatternTop;

struct ParseTestDecl;

struct StepIn;

struct ParseTestCheck;

struct CheckKindOf;

struct OnePattern;

}  // namespace parser


}  // namespace crate
