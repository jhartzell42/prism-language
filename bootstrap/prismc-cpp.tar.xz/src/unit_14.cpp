// The module `Check.Expr.Operators`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <check/expr/operators/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Check.Expr.Operators`, from `target/bootstrap/cpp-src/prismc/check/expr/operators.prism`.
namespace crate::check::expr::operators {

/// InferArray: unbounded fn Env, St, [Expr], Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_array(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const Array<crate::syntax::Expr>& es_p2, const crate::syntax::Range& span_p3) {
    auto [v_p5, st2_p6] = crate::check::types::fresh_var(st_p1, false, Text::lit(""));
    auto st3_p4 = run_to_end(fold_job(es_p2, st2_p6, ({
        auto env_p0_1 = env_p0;
        auto v_p5_2 = v_p5;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::Expr>)>>(prism_rtl::rc([=, env_p0_1 = std::move(env_p0_1), v_p5_2 = std::move(v_p5_2)](std::tuple<crate::check::types::St, crate::syntax::Expr> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_p0_1_3 = env_p0_1;
            auto v_p5_2_3 = v_p5_2;
            entered(once_job([=, env_p0_1_3 = std::move(env_p0_1_3), v_p5_2_3 = std::move(v_p5_2_3)]() {
            return ({
                auto s_p7 = p0;
                auto x_p8 = p1;
                (prism_rtl::more(prism_rtl::rc(crate::check::expr::Check(env_p0_1_3, s_p7, x_p8, v_p5_2_3))));
            });
        }));
        });
    })));
    })));
    return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyArray{prism_rtl::rc(v_p5)}), st3_p4};
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InferArray::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& es_p2 = this->es_p2;
    const auto& span_p3 = this->span_p3;
    auto [v_p5, st2_p6] = crate::check::types::fresh_var(st_p1, false, Text::lit(""));
    auto env_p0_1 = env_p0;
    auto es_p2_2 = es_p2;
    return call_value(fold_job(es_p2_2, st2_p6, ({
        auto env_p0_1_3 = env_p0_1;
        auto v_p5_3 = v_p5;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::Expr>)>>(prism_rtl::rc([=, env_p0_1_3 = std::move(env_p0_1_3), v_p5_3 = std::move(v_p5_3)](std::tuple<crate::check::types::St, crate::syntax::Expr> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_p0_1_3_4 = env_p0_1_3;
            auto v_p5_3_4 = v_p5_3;
            entered(once_job([=, env_p0_1_3_4 = std::move(env_p0_1_3_4), v_p5_3_4 = std::move(v_p5_3_4)]() {
            return ({
                auto s_p7 = p0;
                auto x_p8 = p1;
                (prism_rtl::more(prism_rtl::rc(crate::check::expr::Check(env_p0_1_3_4, s_p7, x_p8, v_p5_3_4))));
            });
        }));
        });
    })));
    })), [=](crate::check::types::St fold_1476) {
        return ({
            auto st3_p4 = fold_1476;
            (prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyArray{prism_rtl::rc(v_p5)}), st3_p4}));
        });
    });
}


/// `Start InferArray, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_array(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Array<crate::syntax::Expr> es_p2, crate::syntax::Range span_p3) {
    return prism_rtl::make_rc<InferArray>(env_p0, st_p1, es_p2, span_p3);
}


/// InferMap: unbounded fn Env, St, [((Expr, Expr))], Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_map(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const Array<std::tuple<crate::syntax::Expr, crate::syntax::Expr>>& entries_p2, const crate::syntax::Range& span_p3) {
    auto [k_p8, st1_p9] = crate::check::types::fresh_var(st_p1, true, Text::lit(""));
    auto [v_pa, st2_pb] = crate::check::types::fresh_var(st1_p9, false, Text::lit(""));
    auto n_p4 = len(entries_p2);
    auto params_p5 = fold(entries_p2, Array<crate::check::types::Ty>{}, [&](const Array<crate::check::types::Ty>& acc_pc, const std::tuple<crate::syntax::Expr, crate::syntax::Expr>& _p1) { return append(acc_pc, Array(std::vector{k_p8, v_pa})); });
    auto args_p6 = fold(entries_p2, Array<crate::syntax::Arg>{}, [&](const Array<crate::syntax::Arg>& acc_pd, const std::tuple<crate::syntax::Expr, crate::syntax::Expr>& _p1) {
        auto&& ke_pe = std::get<0>(_p1);
        auto&& ve_pf = std::get<1>(_p1);
        return append(acc_pd, Array(std::vector{crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = ke_pe, .span = prism_rtl::deref(ke_pe).span}, crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = ve_pf, .span = prism_rtl::deref(ve_pf).span}}));
    });
    auto st3_p7 = n_p4 > Nat(0u)
        ? crate::check::expr::add_want(st2_pb, Text::lit("Prelude.Ord"), k_p8, span_p3)
        : st2_pb;
    return crate::check::expr::calls::apply_rule(env_p0, st3_p7, Text::lit("a map literal"), crate::check::types::Col(crate::check::types::Col::CBound{}), params_p5, crate::check::types::Ty(crate::check::types::Ty::TyMap{prism_rtl::rc(k_p8), prism_rtl::rc(v_pa)}), args_p6, span_p3);
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InferMap::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& entries_p2 = this->entries_p2;
    const auto& span_p3 = this->span_p3;
    auto [k_p8, st1_p9] = crate::check::types::fresh_var(st_p1, true, Text::lit(""));
    auto [v_pa, st2_pb] = crate::check::types::fresh_var(st1_p9, false, Text::lit(""));
    auto n_p4 = len(entries_p2);
    auto params_p5 = fold(entries_p2, Array<crate::check::types::Ty>{}, [&](const Array<crate::check::types::Ty>& acc_pc, const std::tuple<crate::syntax::Expr, crate::syntax::Expr>& _p1) { return append(acc_pc, Array(std::vector{k_p8, v_pa})); });
    auto args_p6 = fold(entries_p2, Array<crate::syntax::Arg>{}, [&](const Array<crate::syntax::Arg>& acc_pd, const std::tuple<crate::syntax::Expr, crate::syntax::Expr>& _p1) {
        auto&& ke_pe = std::get<0>(_p1);
        auto&& ve_pf = std::get<1>(_p1);
        return append(acc_pd, Array(std::vector{crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = ke_pe, .span = prism_rtl::deref(ke_pe).span}, crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = ve_pf, .span = prism_rtl::deref(ve_pf).span}}));
    });
    auto st3_p7 = n_p4 > Nat(0u)
        ? crate::check::expr::add_want(st2_pb, Text::lit("Prelude.Ord"), k_p8, span_p3)
        : st2_pb;
    return prism_rtl::more(prism_rtl::rc(crate::check::expr::calls::ApplyRule(env_p0, st3_p7, Text::lit("a map literal"), crate::check::types::Col(crate::check::types::Col::CBound{}), params_p5, crate::check::types::Ty(crate::check::types::Ty::TyMap{prism_rtl::rc(k_p8), prism_rtl::rc(v_pa)}), args_p6, span_p3)));
}


/// `Start InferMap, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_map(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Array<std::tuple<crate::syntax::Expr, crate::syntax::Expr>> entries_p2, crate::syntax::Range span_p3) {
    return prism_rtl::make_rc<InferMap>(env_p0, st_p1, entries_p2, span_p3);
}


/// InferBinary: unbounded fn Env, St, Text, Expr, Expr, Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_binary(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const Text& op_p2, const crate::syntax::Expr& lhs_p3, const crate::syntax::Expr& rhs_p4, const crate::syntax::Range& span_p5) {
    auto args_p6 = Array(std::vector{crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = lhs_p3, .span = lhs_p3.span}, crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = rhs_p4, .span = rhs_p4.span}});
    return (op_p2 == Text::lit("and")) || (op_p2 == Text::lit("or"))
        ? crate::check::expr::calls::apply_rule(env_p0, st_p1, op_p2, crate::check::types::Col(crate::check::types::Col::CBound{}), Array(std::vector{crate::check::types::t_bool(), crate::check::types::t_bool()}), crate::check::types::t_bool(), args_p6, span_p5)
        : op_p2 == Text::lit("on")
        ? infer_on(env_p0, st_p1, lhs_p3, rhs_p4, span_p5)
        : op_p2 == Text::lit("<|")
        ? ({
        auto [v_p7, st2_p8] = crate::check::types::fresh_var(st_p1, false, Text::lit(""));
        (crate::check::expr::calls::apply_rule(env_p0, st2_p8, op_p2, crate::check::types::Col(crate::check::types::Col::CBound{}), Array(std::vector{crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("!"), prism_rtl::rc(v_p7)}), crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("!"), prism_rtl::rc(v_p7)})}), crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("!"), prism_rtl::rc(v_p7)}), args_p6, span_p5));
    })
        : op_p2 == Text::lit("mod")
        ? ({
        auto [v_pa, st2_pb] = crate::check::types::fresh_var(st_p1, true, Text::lit(""));
        auto st3_p9 = crate::check::expr::add_want(st2_pb, Text::lit("Prelude.Num"), v_pa, span_p5);
        (crate::check::expr::calls::apply_rule(env_p0, st3_p9, op_p2, crate::check::types::Col(crate::check::types::Col::CBound{}), Array(std::vector{v_pa, v_pa}), v_pa, args_p6, span_p5));
    })
        : ({
        auto [t0_pf, st2_pg] = crate::check::expr::infer_name(env_p0, st_p1, crate::syntax::SName{.sigils = Text::lit(""), .path_ = Array(std::vector{op_p2}), .span = span_p5}, span_p5);
        auto t_pc = op_p2 == Text::lit("/") ? quotient_of(st2_pg, t0_pf) : t0_pf;
        auto st2b_pd = op_p2 == Text::lit("-?")
            ? crate::check::types::recording::note_size_ty(st2_pg, span_p5, crate::check::types::recording::walk(st2_pg, t0_pf))
            : st2_pg;
        auto st3_pe = op_p2 == Text::lit("-") ? sub_want(st2b_pd, t_pc, span_p5) : st2b_pd;
        (crate::check::expr::calls::apply_fn(env_p0, st3_pe, op_p2, t_pc, args_p6, span_p5));
    });
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InferBinary::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& op_p2 = this->op_p2;
    const auto& lhs_p3 = this->lhs_p3;
    const auto& rhs_p4 = this->rhs_p4;
    const auto& span_p5 = this->span_p5;
    auto args_p6 = Array(std::vector{crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = lhs_p3, .span = prism_rtl::deref(lhs_p3).span}, crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = rhs_p4, .span = prism_rtl::deref(rhs_p4).span}});
    return (op_p2 == Text::lit("and")) || (op_p2 == Text::lit("or"))
        ? prism_rtl::more(prism_rtl::rc(crate::check::expr::calls::ApplyRule(env_p0, st_p1, op_p2, crate::check::types::Col(crate::check::types::Col::CBound{}), Array(std::vector{crate::check::types::t_bool(), crate::check::types::t_bool()}), crate::check::types::t_bool(), args_p6, span_p5)))
        : op_p2 == Text::lit("on")
        ? prism_rtl::more(prism_rtl::rc(InferOn(env_p0, st_p1, lhs_p3, rhs_p4, span_p5)))
        : op_p2 == Text::lit("<|")
        ? ({
        auto [v_p7, st2_p8] = crate::check::types::fresh_var(st_p1, false, Text::lit(""));
        (prism_rtl::more(prism_rtl::rc(crate::check::expr::calls::ApplyRule(env_p0, st2_p8, op_p2, crate::check::types::Col(crate::check::types::Col::CBound{}), Array(std::vector{crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("!"), prism_rtl::rc(v_p7)}), crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("!"), prism_rtl::rc(v_p7)})}), crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("!"), prism_rtl::rc(v_p7)}), args_p6, span_p5))));
    })
        : op_p2 == Text::lit("mod")
        ? ({
        auto [v_pa, st2_pb] = crate::check::types::fresh_var(st_p1, true, Text::lit(""));
        auto st3_p9 = crate::check::expr::add_want(st2_pb, Text::lit("Prelude.Num"), v_pa, span_p5);
        (prism_rtl::more(prism_rtl::rc(crate::check::expr::calls::ApplyRule(env_p0, st3_p9, op_p2, crate::check::types::Col(crate::check::types::Col::CBound{}), Array(std::vector{v_pa, v_pa}), v_pa, args_p6, span_p5))));
    })
        : ({
        auto env_p0_1 = env_p0;
        auto op_p2_2 = op_p2;
        auto span_p5_3 = span_p5;
        auto st_p1_4 = st_p1;
        call_then(crate::check::expr::start_infer_name(env_p0_1, st_p1_4, crate::syntax::SName{.sigils = Text::lit(""), .path_ = Array(std::vector{op_p2_2}), .span = span_p5_3}, span_p5_3), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_name_3258) {
        return ({
            auto [t0_pf, st2_pg] = infer_name_3258;
            auto t_pc = op_p2_2 == Text::lit("/") ? quotient_of(st2_pg, t0_pf) : t0_pf;
            auto st2b_pd = op_p2_2 == Text::lit("-?")
                ? crate::check::types::recording::note_size_ty(st2_pg, span_p5_3, crate::check::types::recording::walk(st2_pg, t0_pf))
                : st2_pg;
            auto st3_pe = op_p2_2 == Text::lit("-") ? sub_want(st2b_pd, t_pc, span_p5_3) : st2b_pd;
            (prism_rtl::more(prism_rtl::rc(crate::check::expr::calls::ApplyFn(env_p0_1, st3_pe, op_p2_2, t_pc, args_p6, span_p5_3))));
        });
    });
    });
}


/// `Start InferBinary, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_binary(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Text op_p2, crate::syntax::Expr lhs_p3, crate::syntax::Expr rhs_p4, crate::syntax::Range span_p5) {
    return prism_rtl::make_rc<InferBinary>(env_p0, st_p1, op_p2, lhs_p3, rhs_p4, span_p5);
}


/// QuotientOf: unbounded fn St, Ty -> Ty
crate::check::types::Ty quotient_of(const crate::check::types::St& st_p0, const crate::check::types::Ty& t_p1) {
    auto&& _m = crate::check::types::recording::walk(st_p0, t_p1);
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
        auto&& c_p2 = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a0;
        auto&& ps_p3 = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a1;
        auto&& _m = index(ps_p3, Nat(0u));
        if (prism_rtl::is_some(_m)) {
            auto&& p_p4 = prism_rtl::some_of(_m);
            return crate::check::types::Ty(crate::check::types::Ty::TyFn{c_p2, ps_p3, prism_rtl::rc(crate::check::types::Ty(crate::check::types::Ty::TyAssoc{Text::lit("Quotient"), prism_rtl::rc(p_p4)}))});
        }
        if (prism_rtl::is_none(_m)) {
            return t_p1;
        }
        prism_rtl::unreachable("no arm matched");
    }
    {
        auto&& other_p5 = _m;
        return other_p5;
    }
}


prism_rtl::Turn<crate::check::types::Ty> QuotientOf::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& t_p1 = this->t_p1;
    auto st_p0_1 = st_p0;
    auto t_p1_2 = t_p1;
    return call_then(crate::check::types::recording::start_walk(st_p0_1, t_p1_2), [=](crate::check::types::Ty walk_3748) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TyFn>(walk_3748) ? ({
            auto&& c_p2 = prism_rtl::as<crate::check::types::Ty::TyFn>(walk_3748).a0;
            auto&& ps_p3 = prism_rtl::as<crate::check::types::Ty::TyFn>(walk_3748).a1;
            ({
            auto&& _m = index(ps_p3, Nat(0u));
            prism_rtl::is_some(_m) ? ({
            auto&& p_p4 = prism_rtl::some_of(_m);
            prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyFn{c_p2, ps_p3, prism_rtl::rc(crate::check::types::Ty(crate::check::types::Ty::TyAssoc{Text::lit("Quotient"), prism_rtl::rc(p_p4)}))}));
        })
            : prism_rtl::is_none(_m) ? prism_rtl::finished(t_p1_2)
            : throw prism_rtl::Panic("no arm matched");
        });
        })
            : ({
            auto&& other_p5 = walk_3748;
            prism_rtl::finished(other_p5);
        });
        });
    });
}


/// `Start QuotientOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::Ty> start_quotient_of(crate::check::types::St st_p0, crate::check::types::Ty t_p1) {
    return prism_rtl::make_rc<QuotientOf>(st_p0, t_p1);
}


/// SubWant: unbounded fn St, Ty, Range -> St
crate::check::types::St sub_want(const crate::check::types::St& st_p0, const crate::check::types::Ty& t_p1, const crate::syntax::Range& span_p2) {
    auto&& _m = crate::check::types::recording::walk(st_p0, t_p1);
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
        auto&& ps_p3 = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a1;
        auto&& _m = index(ps_p3, Nat(0u));
        if (prism_rtl::is_some(_m)) {
            auto&& p_p4 = prism_rtl::some_of(_m);
            return crate::check::expr::add_want(st_p0, Text::lit("Prelude.Sub"), p_p4, span_p2);
        }
        if (prism_rtl::is_none(_m)) {
            return st_p0;
        }
        prism_rtl::unreachable("no arm matched");
    }
    {
        return st_p0;
    }
}


prism_rtl::Turn<crate::check::types::St> SubWant::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& t_p1 = this->t_p1;
    const auto& span_p2 = this->span_p2;
    auto span_p2_1 = span_p2;
    auto st_p0_2 = st_p0;
    auto t_p1_3 = t_p1;
    return call_then(crate::check::types::recording::start_walk(st_p0_2, t_p1_3), [=](crate::check::types::Ty walk_4076) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TyFn>(walk_4076) ? ({
            auto&& ps_p3 = prism_rtl::as<crate::check::types::Ty::TyFn>(walk_4076).a1;
            ({
            auto&& _m = index(ps_p3, Nat(0u));
            prism_rtl::is_some(_m) ? ({
            auto&& p_p4 = prism_rtl::some_of(_m);
            prism_rtl::finished(crate::check::expr::add_want(st_p0_2, Text::lit("Prelude.Sub"), p_p4, span_p2_1));
        })
            : prism_rtl::is_none(_m) ? prism_rtl::finished(st_p0_2)
            : throw prism_rtl::Panic("no arm matched");
        });
        })
            : prism_rtl::finished(st_p0_2);
        });
    });
}


/// `Start SubWant, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_sub_want(crate::check::types::St st_p0, crate::check::types::Ty t_p1, crate::syntax::Range span_p2) {
    return prism_rtl::make_rc<SubWant>(st_p0, t_p1, span_p2);
}


/// InferOn: unbounded fn Env, St, Expr, Expr, Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_on(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Expr& lhs_p2, const crate::syntax::Expr& rhs_p3, const crate::syntax::Range& span_p4) {
    auto [a_p5, st1_p6] = crate::check::types::fresh_var(st_p1, true, Text::lit(""));
    auto [b_p7, st2_p8] = crate::check::types::fresh_var(st1_p6, true, Text::lit(""));
    auto [rt_p9, st3_pa] = crate::check::expr::infer(env_p0, st2_p8, rhs_p3);
    return ((crate::check::types::head_sigil(st3_pa, rt_p9) != Text::lit("!")) && (rt_p9 != crate::check::types::Ty(crate::check::types::Ty::TyErr{}))) && (!crate::check::types::is_flex_var(st3_pa, rt_p9))
        ? std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st3_pa, Text::lit("mismatch"), rhs_p3.span, prism_rtl::cat("`on` fires with an event on its right; this is `", crate::check::types::show_ty(st3_pa, rt_p9), "`"))}
        : ({
        auto args_pb = Array(std::vector{crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = lhs_p2, .span = lhs_p2.span}, crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = rhs_p3, .span = rhs_p3.span}});
        (crate::check::expr::calls::apply_rule(env_p0, st3_pa, Text::lit("on"), crate::check::types::Col(crate::check::types::Col::CBound{}), Array(std::vector{a_p5, b_p7}), a_p5, args_pb, span_p4));
    });
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InferOn::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& lhs_p2 = this->lhs_p2;
    const auto& rhs_p3 = this->rhs_p3;
    const auto& span_p4 = this->span_p4;
    auto [a_p5, st1_p6] = crate::check::types::fresh_var(st_p1, true, Text::lit(""));
    auto [b_p7, st2_p8] = crate::check::types::fresh_var(st1_p6, true, Text::lit(""));
    auto env_p0_1 = env_p0;
    auto lhs_p2_2 = lhs_p2;
    auto rhs_p3_3 = rhs_p3;
    auto span_p4_4 = span_p4;
    return call_then(crate::check::expr::start_infer(env_p0_1, st2_p8, rhs_p3_3), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_4554) {
        return ({
            auto [rt_p9, st3_pa] = infer_4554;
            call_then(crate::check::types::start_head_sigil(st3_pa, rt_p9), [=](Text head_sigil_4582) {
            return ((head_sigil_4582 != Text::lit("!")) && (rt_p9 != crate::check::types::Ty(crate::check::types::Ty::TyErr{}))) && (!crate::check::types::is_flex_var(st3_pa, rt_p9))
                ? call_then(crate::check::types::start_show_ty(st3_pa, rt_p9), [=](Text show_ty_4752) { return prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st3_pa, Text::lit("mismatch"), prism_rtl::deref(rhs_p3_3).span, prism_rtl::cat("`on` fires with an event on its right; this is `", show_ty_4752, "`"))}); })
                : ({
                auto args_pb = Array(std::vector{crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = lhs_p2_2, .span = prism_rtl::deref(lhs_p2_2).span}, crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = rhs_p3_3, .span = prism_rtl::deref(rhs_p3_3).span}});
                (prism_rtl::more(prism_rtl::rc(crate::check::expr::calls::ApplyRule(env_p0_1, st3_pa, Text::lit("on"), crate::check::types::Col(crate::check::types::Col::CBound{}), Array(std::vector{a_p5, b_p7}), a_p5, args_pb, span_p4_4))));
            });
        });
        });
    });
}


/// `Start InferOn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_on(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Expr lhs_p2, crate::syntax::Expr rhs_p3, crate::syntax::Range span_p4) {
    return prism_rtl::make_rc<InferOn>(env_p0, st_p1, lhs_p2, rhs_p3, span_p4);
}


/// InferUnary: unbounded fn Env, St, Text, Expr, Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_unary(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const Text& op_p2, const crate::syntax::Expr& x_p3, const crate::syntax::Range& span_p4) {
    auto args_p5 = Array(std::vector{crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = x_p3, .span = x_p3.span}});
    {
        auto&& m5115_0 = op_p2;
        if (m5115_0 == Text::lit("not")) {
            return crate::check::expr::calls::apply_rule(env_p0, st_p1, Text::lit("not"), crate::check::types::Col(crate::check::types::Col::CBound{}), Array(std::vector{crate::check::types::t_bool()}), crate::check::types::t_bool(), args_p5, span_p4);
        }
    }
    {
        auto&& m5115_1 = op_p2;
        if (m5115_1 == Text::lit("neg")) {
            auto&& _m = prism_rtl::deref(x_p3.kind);
            if (prism_rtl::is<crate::syntax::ExprKind::ELit>(_m)) {
                auto&& l_p6 = prism_rtl::as<crate::syntax::ExprKind::ELit>(_m).a0;
                auto [t_p7, st2_p8] = crate::check::expr::infer_lit(env_p0, st_p1, l_p6, true, span_p4);
                return std::tuple{t_p7, crate::check::types::recording::note_ty(st2_p8, x_p3.span, t_p7)};
            }
            {
                auto [v_pa, st2_pb] = crate::check::types::fresh_var(st_p1, true, Text::lit(""));
                auto st3_p9 = crate::check::expr::add_want(crate::check::expr::add_want(st2_pb, Text::lit("Prelude.Num"), v_pa, span_p4), Text::lit("Prelude.Signed"), v_pa, span_p4);
                return crate::check::expr::calls::apply_rule(env_p0, st3_p9, Text::lit("-"), crate::check::types::Col(crate::check::types::Col::CBound{}), Array(std::vector{v_pa}), v_pa, args_p5, span_p4);
            }
        }
    }
    {
        return crate::check::expr::infer(env_p0, st_p1, x_p3);
    }
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InferUnary::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& op_p2 = this->op_p2;
    const auto& x_p3 = this->x_p3;
    const auto& span_p4 = this->span_p4;
    auto args_p5 = Array(std::vector{crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = x_p3, .span = prism_rtl::deref(x_p3).span}});
    return ({
        ({
        auto&& m5115_0 = op_p2;
        (m5115_0 == Text::lit("not"));
    }) ? ({
        auto&& m5115_0 = op_p2;
        prism_rtl::more(prism_rtl::rc(crate::check::expr::calls::ApplyRule(env_p0, st_p1, Text::lit("not"), crate::check::types::Col(crate::check::types::Col::CBound{}), Array(std::vector{crate::check::types::t_bool()}), crate::check::types::t_bool(), args_p5, span_p4)));
    })
        : ({
        auto&& m5115_1 = op_p2;
        (m5115_1 == Text::lit("neg"));
    }) ? ({
        auto&& m5115_1 = op_p2;
        ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(x_p3).kind);
        prism_rtl::is<crate::syntax::ExprKind::ELit>(_m) ? ({
        auto&& l_p6 = prism_rtl::as<crate::syntax::ExprKind::ELit>(_m).a0;
        ({
        auto env_p0_1 = env_p0;
        auto l_p6_2 = l_p6;
        auto span_p4_3 = span_p4;
        auto st_p1_4 = st_p1;
        auto x_p3_5 = x_p3;
        call_then(crate::check::expr::start_infer_lit(env_p0_1, st_p1_4, l_p6_2, true, span_p4_3), [=, x_p3_5 = std::move(x_p3_5)](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_lit_5285) {
        return ({
            auto [t_p7, st2_p8] = infer_lit_5285;
            (prism_rtl::finished(std::tuple{t_p7, crate::check::types::recording::note_ty(st2_p8, prism_rtl::deref(x_p3_5).span, t_p7)}));
        });
    });
    });
    })
        : ({
        auto [v_pa, st2_pb] = crate::check::types::fresh_var(st_p1, true, Text::lit(""));
        auto st3_p9 = crate::check::expr::add_want(crate::check::expr::add_want(st2_pb, Text::lit("Prelude.Num"), v_pa, span_p4), Text::lit("Prelude.Signed"), v_pa, span_p4);
        (prism_rtl::more(prism_rtl::rc(crate::check::expr::calls::ApplyRule(env_p0, st3_p9, Text::lit("-"), crate::check::types::Col(crate::check::types::Col::CBound{}), Array(std::vector{v_pa}), v_pa, args_p5, span_p4))));
    });
    });
    })
        : prism_rtl::more(prism_rtl::rc(crate::check::expr::Infer(env_p0, st_p1, x_p3)));
    });
}


/// `Start InferUnary, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_unary(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Text op_p2, crate::syntax::Expr x_p3, crate::syntax::Range span_p4) {
    return prism_rtl::make_rc<InferUnary>(env_p0, st_p1, op_p2, x_p3, span_p4);
}


/// InferFreeSigil: unbounded fn Env, St, Text, Expr, Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_free_sigil(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const Text& s_p2, const crate::syntax::Expr& x_p3, const crate::syntax::Range& span_p4) {
    return s_p2 == Text::lit("@")
        ? ({
        auto [t_p5, st2_p6] = crate::check::expr::infer(env_p0, st_p1, x_p3);
        std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyAt{prism_rtl::rc(t_p5), env_p0.scope}), st2_p6};
    })
        : ((s_p2 == Text::lit("?")) || (s_p2 == Text::lit("~"))) || (s_p2 == Text::lit("$"))
        ? ({
        auto [v_p7, st2_p8] = crate::check::types::fresh_var(st_p1, false, Text::lit(""));
        is_blueprint_expr(env_p0, st2_p8, x_p3)
        ? ({
        auto [t_p9, st3_pa] = crate::check::expr::infer(env_p0, st2_p8, x_p3);
        std::tuple{crate::check::types::Ty(crate::check::types::Ty::TySig{s_p2, prism_rtl::rc(t_p9)}), st3_pa};
    })
        : crate::check::expr::calls::apply_rule(env_p0, st2_p8, prism_rtl::cat(s_p2), crate::check::types::Col(crate::check::types::Col::CBound{}), Array(std::vector{v_p7}), crate::check::types::Ty(crate::check::types::Ty::TySig{s_p2, prism_rtl::rc(v_p7)}), Array(std::vector{crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = x_p3, .span = x_p3.span}}), span_p4);
    })
        : ({
        auto [t_pb, st2_pc] = crate::check::expr::infer(env_p0, st_p1, x_p3);
        std::tuple{crate::check::types::with_marks(s_p2, t_pb, env_p0.scope), st2_pc};
    });
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InferFreeSigil::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& s_p2 = this->s_p2;
    const auto& x_p3 = this->x_p3;
    const auto& span_p4 = this->span_p4;
    return s_p2 == Text::lit("@")
        ? ({
        auto env_p0_1 = env_p0;
        auto st_p1_2 = st_p1;
        auto x_p3_3 = x_p3;
        call_then(crate::check::expr::start_infer(env_p0_1, st_p1_2, x_p3_3), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_5931) {
        return ({
            auto [t_p5, st2_p6] = infer_5931;
            (prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyAt{prism_rtl::rc(t_p5), prism_rtl::deref(env_p0_1).scope}), st2_p6}));
        });
    });
    })
        : ((s_p2 == Text::lit("?")) || (s_p2 == Text::lit("~"))) || (s_p2 == Text::lit("$"))
        ? ({
        auto [v_p7, st2_p8] = crate::check::types::fresh_var(st_p1, false, Text::lit(""));
        is_blueprint_expr(env_p0, st2_p8, x_p3)
        ? ({
        auto env_p0_1 = env_p0;
        auto s_p2_2 = s_p2;
        auto x_p3_3 = x_p3;
        call_then(crate::check::expr::start_infer(env_p0_1, st2_p8, x_p3_3), [=, s_p2_2 = std::move(s_p2_2)](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_6149) {
        return ({
            auto [t_p9, st3_pa] = infer_6149;
            (prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TySig{s_p2_2, prism_rtl::rc(t_p9)}), st3_pa}));
        });
    });
    })
        : prism_rtl::more(prism_rtl::rc(crate::check::expr::calls::ApplyRule(env_p0, st2_p8, prism_rtl::cat(s_p2), crate::check::types::Col(crate::check::types::Col::CBound{}), Array(std::vector{v_p7}), crate::check::types::Ty(crate::check::types::Ty::TySig{s_p2, prism_rtl::rc(v_p7)}), Array(std::vector{crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = x_p3, .span = prism_rtl::deref(x_p3).span}}), span_p4)));
    })
        : ({
        auto env_p0_1 = env_p0;
        auto s_p2_2 = s_p2;
        auto st_p1_3 = st_p1;
        auto x_p3_4 = x_p3;
        call_then(crate::check::expr::start_infer(env_p0_1, st_p1_3, x_p3_4), [=, s_p2_2 = std::move(s_p2_2)](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_6352) {
        return ({
            auto [t_pb, st2_pc] = infer_6352;
            (prism_rtl::finished(std::tuple{crate::check::types::with_marks(s_p2_2, t_pb, prism_rtl::deref(env_p0_1).scope), st2_pc}));
        });
    });
    });
}


/// `Start InferFreeSigil, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_free_sigil(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Text s_p2, crate::syntax::Expr x_p3, crate::syntax::Range span_p4) {
    return prism_rtl::make_rc<InferFreeSigil>(env_p0, st_p1, s_p2, x_p3, span_p4);
}


/// IsBlueprintExpr: fn Env, St, Expr -> Bool
bool is_blueprint_expr(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Expr& x_p2) {
    auto&& _m = prism_rtl::deref(x_p2.kind);
    if (prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m)) {
        auto&& m6632_0_0 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
        if (m6632_0_0 == Text::lit("@")) {
            return true;
        }
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& y_p3 = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return is_blueprint_expr(env_p0, st_p1, prism_rtl::deref(prism_rtl::deref(y_p3)));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
        auto&& c_p4 = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
        auto&& _m = prism_rtl::deref(prism_rtl::deref(c_p4).kind);
        if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
            auto&& n_p5 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
            return crate::syntax::lexer::chars::has_prefix(prism_rtl::deref(n_p5).sigils, Text::lit("@"));
        }
        {
            return false;
        }
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n_p6 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        return crate::syntax::lexer::chars::has_prefix(prism_rtl::deref(n_p6).sigils, Text::lit("@"));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EWidgetBlock>(_m)) {
        return true;
    }
    {
        return false;
    }
}


/// InferField: unbounded fn Env, St, Expr, Text, Ident, Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_field(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Expr& recv_p2, const Text& sigils_p3, const crate::syntax::Ident& name_p4, const crate::syntax::Range& span_p5) {
    auto [rt_pi, st1_pj] = crate::check::expr::infer(env_p0, st_p1, recv_p2);
    auto head_p6 = crate::check::types::head_sigil(st1_pj, rt_pi);
    auto inner_p7 = crate::check::expr::is_time_sigil(head_p6)
        ? crate::check::expr::inner_of(st1_pj, rt_pi)
        : rt_pi;
    auto ih_p8 = crate::check::blocks::borrows::is_ref(recv_p2)
        ? Text::lit("")
        : crate::check::types::head_sigil(st1_pj, inner_p7);
    auto plain_t_p9 = crate::check::expr::is_plain_sigil(crate::check::types::head_sigil(st1_pj, inner_p7))
        ? crate::check::expr::inner_of(st1_pj, inner_p7)
        : inner_p7;
    auto st2_pa = head_p6 == Text::lit("@")
        ? crate::check::types::recording::err(st1_pj, Text::lit("blueprint-operand"), recv_p2.span, prism_rtl::cat("`.", name_p4.name, "` over a blueprint; bind it first"))
        : st1_pj;
    auto [ft_pk, st3_pl] = field_type(env_p0, st2_pa, plain_t_p9, name_p4.name, span_p5);
    auto stack_pb = crate::check::types::stack_of(st3_pl, ft_pk);
    auto bad_pc = (((stack_pb != sigils_p3) && (ft_pk != crate::check::types::Ty(crate::check::types::Ty::TyErr{}))) && (!crate::check::types::is_flex_var(st3_pl, ft_pk))) && (!crate::check::blocks::borrows::is_ref(recv_p2));
    auto st4_pd = std::move(bad_pc)
        ? crate::check::types::recording::err_fix(st3_pl, Text::lit("mark-stack"), name_p4.span, prism_rtl::cat("`.", sigils_p3, name_p4.name, "` has type `", crate::check::types::show_ty(st3_pl, ft_pk), "`, whose stack is `", stack_pb, "`; the access shows `", sigils_p3, "`"), prism_rtl::cat("write `.", stack_pb, name_p4.name, "`"))
        : st3_pl;
    auto with_opt_pe = crate::check::expr::is_plain_sigil(ih_p8)
        ? crate::check::types::Ty(crate::check::types::Ty::TySig{ih_p8, prism_rtl::rc(ft_pk)})
        : ft_pk;
    auto res_pf = crate::check::expr::is_time_sigil(head_p6)
        ? crate::check::types::Ty(crate::check::types::Ty::TySig{head_p6, prism_rtl::rc(with_opt_pe)})
        : with_opt_pe;
    auto st5_pg = crate::check::expr::is_time_sigil(head_p6)
        ? crate::check::expr::calls::elab(st4_pd, span_p5, prism_rtl::cat(".", name_p4.name), Text::lit("map"), head_p6)
        : st4_pd;
    auto st6_ph = crate::check::expr::is_plain_sigil(ih_p8)
        ? crate::check::types::recording::note_lift(st5_pg, span_p5, ih_p8, Array(std::vector{recv_p2.span}))
        : st5_pg;
    return std::tuple{res_pf, st6_ph};
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InferField::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& recv_p2 = this->recv_p2;
    const auto& sigils_p3 = this->sigils_p3;
    const auto& name_p4 = this->name_p4;
    const auto& span_p5 = this->span_p5;
    auto env_p0_1 = env_p0;
    auto name_p4_2 = name_p4;
    auto recv_p2_3 = recv_p2;
    auto sigils_p3_4 = sigils_p3;
    auto span_p5_5 = span_p5;
    auto st_p1_6 = st_p1;
    return call_then(crate::check::expr::start_infer(env_p0_1, st_p1_6, recv_p2_3), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_7445) {
        return ({
            auto [rt_pi, st1_pj] = infer_7445;
            call_then(crate::check::types::start_head_sigil(st1_pj, rt_pi), [=](Text head_sigil_7480) {
            return ({
                auto head_p6 = head_sigil_7480;
                auto inner_p7 = crate::check::expr::is_time_sigil(head_p6)
                    ? crate::check::expr::inner_of(st1_pj, rt_pi)
                    : rt_pi;
                auto ih_p8 = crate::check::blocks::borrows::is_ref(recv_p2_3)
                    ? Text::lit("")
                    : crate::check::types::head_sigil(st1_pj, inner_p7);
                call_then(crate::check::types::start_head_sigil(st1_pj, inner_p7), [=, head_p6 = std::move(head_p6), ih_p8 = std::move(ih_p8)](Text head_sigil_7814) {
                return ({
                    auto plain_t_p9 = crate::check::expr::is_plain_sigil(head_sigil_7814)
                        ? crate::check::expr::inner_of(st1_pj, inner_p7)
                        : inner_p7;
                    auto st2_pa = head_p6 == Text::lit("@")
                        ? crate::check::types::recording::err(st1_pj, Text::lit("blueprint-operand"), prism_rtl::deref(recv_p2_3).span, prism_rtl::cat("`.", prism_rtl::deref(name_p4_2).name, "` over a blueprint; bind it first"))
                        : st1_pj;
                    call_then(start_field_type(env_p0_1, st2_pa, plain_t_p9, prism_rtl::deref(name_p4_2).name, span_p5_5), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> field_type_8020) {
                    return ({
                        auto [ft_pk, st3_pl] = field_type_8020;
                        call_then(crate::check::types::start_stack_of(st3_pl, ft_pk), [=](Text stack_of_8080) {
                        return ({
                            auto stack_pb = stack_of_8080;
                            auto bad_pc = (((stack_pb != sigils_p3_4) && (ft_pk != crate::check::types::Ty(crate::check::types::Ty::TyErr{}))) && (!crate::check::types::is_flex_var(st3_pl, ft_pk))) && (!crate::check::blocks::borrows::is_ref(recv_p2_3));
                            auto st4_pd = std::move(bad_pc)
                                ? crate::check::types::recording::err_fix(st3_pl, Text::lit("mark-stack"), prism_rtl::deref(name_p4_2).span, prism_rtl::cat("`.", sigils_p3_4, prism_rtl::deref(name_p4_2).name, "` has type `", crate::check::types::show_ty(st3_pl, ft_pk), "`, whose stack is `", stack_pb, "`; the access shows `", sigils_p3_4, "`"), prism_rtl::cat("write `.", stack_pb, prism_rtl::deref(name_p4_2).name, "`"))
                                : st3_pl;
                            auto with_opt_pe = crate::check::expr::is_plain_sigil(ih_p8)
                                ? crate::check::types::Ty(crate::check::types::Ty::TySig{ih_p8, prism_rtl::rc(ft_pk)})
                                : ft_pk;
                            auto res_pf = crate::check::expr::is_time_sigil(head_p6)
                                ? crate::check::types::Ty(crate::check::types::Ty::TySig{head_p6, prism_rtl::rc(with_opt_pe)})
                                : with_opt_pe;
                            auto st5_pg = crate::check::expr::is_time_sigil(head_p6)
                                ? crate::check::expr::calls::elab(st4_pd, span_p5_5, prism_rtl::cat(".", prism_rtl::deref(name_p4_2).name), Text::lit("map"), head_p6)
                                : st4_pd;
                            auto st6_ph = crate::check::expr::is_plain_sigil(ih_p8)
                                ? crate::check::types::recording::note_lift(st5_pg, span_p5_5, ih_p8, Array(std::vector{prism_rtl::deref(recv_p2_3).span}))
                                : st5_pg;
                            (prism_rtl::finished(std::tuple{res_pf, st6_ph}));
                        });
                    });
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start InferField, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_field(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Expr recv_p2, Text sigils_p3, crate::syntax::Ident name_p4, crate::syntax::Range span_p5) {
    return prism_rtl::make_rc<InferField>(env_p0, st_p1, recv_p2, sigils_p3, name_p4, span_p5);
}


/// FieldType: unbounded fn Env, St, Ty, Text, Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> field_type(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::check::types::Ty& t_p2, const Text& field_p3, const crate::syntax::Range& span_p4) {
    auto&& _m = crate::check::types::recording::walk(st_p1, t_p2);
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
        auto&& n_p5 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
        auto&& args_p6 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a1;
        auto&& _m = crate::prelude::get(prism_rtl::deref(env_p0.g).ctors, n_p5);
        if (prism_rtl::is_some(_m)) {
            auto&& c_p7 = prism_rtl::some_of(_m);
            auto&& _m = index_of(prism_rtl::deref(c_p7).fields, field_p3);
            if (prism_rtl::is_some(_m)) {
                auto&& i_p8 = prism_rtl::some_of(_m);
                auto inst_p9 = crate::check::env::reading::param_inst(prism_rtl::deref(c_p7).params, args_p6);
                return std::tuple{crate::check::types::schemes::subst_q(inst_p9, or_(index(c_p7->args, i_p8), crate::check::types::Ty(crate::check::types::Ty::TyErr{}))), st_p1};
            }
            if (prism_rtl::is_none(_m)) {
                return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st_p1, Text::lit("mismatch"), span_p4, prism_rtl::cat("`", crate::check::types::bare_name(n_p5), "` has no field `", field_p3, "`"))};
            }
            prism_rtl::unreachable("no arm matched");
        }
        if (prism_rtl::is_none(_m)) {
            return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st_p1, Text::lit("mismatch"), span_p4, prism_rtl::cat("`", crate::check::types::bare_name(n_p5), "` has no fields"))};
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFlex>(_m)) {
        auto owners_pa = filter(values(prism_rtl::deref(env_p0.g).ctors), [&](const crate::check::env::CtorInfo& c_pb) { return crate::check::types::has_text(prism_rtl::deref(c_pb).fields, field_p3); });
        auto&& _m = index(owners_pa, Nat(0u));
        if (prism_rtl::is_some(_m)) {
            auto&& c_pc = prism_rtl::some_of(_m);
            return len(owners_pa) > Nat(1u)
                ? ({
                auto [v_pd, st2_pe] = crate::check::types::fresh_var(st_p1, false, Text::lit(""));
                std::tuple{v_pd, crate::check::types::unify::ask_field(st2_pe, t_p2, field_p3, v_pd, span_p4, each(owners_pa, [&](const crate::check::env::CtorInfo& o_pf) { return crate::check::types::bare_name(prism_rtl::deref(o_pf).owner); }))};
            })
                : ({
                auto [self_ph, st2_pi] = crate::check::expr::ctor_value(env_p0, st_p1, ({
                    crate::check::env::CtorInfo this_ = c_pc;
                    this_.args = Array<crate::check::types::Ty>{};
                    (std::move(this_));
                }), span_p4);
                auto st3_pg = crate::check::types::unify::unify(st2_pi, self_ph, t_p2, span_p4);
                field_type(env_p0, st3_pg, self_ph, field_p3, span_p4);
            });
        }
        if (prism_rtl::is_none(_m)) {
            return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st_p1, Text::lit("mismatch"), span_p4, prism_rtl::cat("no record has a field `", field_p3, "`"))};
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<crate::check::types::Ty::TyErr>(_m)) {
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), st_p1};
    }
    {
        auto&& other_pj = _m;
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st_p1, Text::lit("mismatch"), span_p4, prism_rtl::cat("`", crate::check::types::show_ty(st_p1, other_pj), "` has no field `", field_p3, "`"))};
    }
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> FieldType::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& t_p2 = this->t_p2;
    const auto& field_p3 = this->field_p3;
    const auto& span_p4 = this->span_p4;
    auto env_p0_1 = env_p0;
    auto field_p3_2 = field_p3;
    auto span_p4_3 = span_p4;
    auto st_p1_4 = st_p1;
    auto t_p2_5 = t_p2;
    return call_then(crate::check::types::recording::start_walk(st_p1_4, t_p2_5), [=](crate::check::types::Ty walk_9134) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TyCon>(walk_9134) ? ({
            auto&& n_p5 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_9134).a0;
            auto&& args_p6 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_9134).a1;
            ({
            auto&& _m = crate::prelude::get(prism_rtl::deref(prism_rtl::deref(env_p0_1).g).ctors, n_p5);
            prism_rtl::is_some(_m) ? ({
            auto&& c_p7 = prism_rtl::some_of(_m);
            ({
            auto&& _m = index_of(prism_rtl::deref(c_p7).fields, field_p3_2);
            prism_rtl::is_some(_m) ? ({
            auto&& i_p8 = prism_rtl::some_of(_m);
            ({
            auto inst_p9 = crate::check::env::reading::param_inst(prism_rtl::deref(c_p7).params, args_p6);
            call_then(crate::check::types::schemes::start_subst_q(inst_p9, or_(index(c_p7->args, i_p8), crate::check::types::Ty(crate::check::types::Ty::TyErr{}))), [=](crate::check::types::Ty subst_q_9344) { return prism_rtl::finished(std::tuple{subst_q_9344, st_p1_4}); });
        });
        })
            : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st_p1_4, Text::lit("mismatch"), span_p4_3, prism_rtl::cat("`", crate::check::types::bare_name(n_p5), "` has no field `", field_p3_2, "`"))})
            : throw prism_rtl::Panic("no arm matched");
        });
        })
            : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st_p1_4, Text::lit("mismatch"), span_p4_3, prism_rtl::cat("`", crate::check::types::bare_name(n_p5), "` has no fields"))})
            : throw prism_rtl::Panic("no arm matched");
        });
        })
            : prism_rtl::is<crate::check::types::Ty::TyFlex>(walk_9134) ? ({
            auto owners_pa = filter(values(prism_rtl::deref(prism_rtl::deref(env_p0_1).g).ctors), [&](const crate::check::env::CtorInfo& c_pb) { return crate::check::types::has_text(prism_rtl::deref(c_pb).fields, field_p3_2); });
            ({
            auto&& _m = index(owners_pa, Nat(0u));
            prism_rtl::is_some(_m) ? ({
            auto&& c_pc = prism_rtl::some_of(_m);
            len(owners_pa) > Nat(1u)
            ? ({
            auto [v_pd, st2_pe] = crate::check::types::fresh_var(st_p1_4, false, Text::lit(""));
            (prism_rtl::finished(std::tuple{v_pd, crate::check::types::unify::ask_field(st2_pe, t_p2_5, field_p3_2, v_pd, span_p4_3, each(owners_pa, [&](const crate::check::env::CtorInfo& o_pf) { return crate::check::types::bare_name(prism_rtl::deref(o_pf).owner); }))}));
        })
            : call_then(crate::check::expr::start_ctor_value(env_p0_1, st_p1_4, ({
            crate::check::env::CtorInfo this_ = c_pc;
            this_.args = Array<crate::check::types::Ty>{};
            (std::move(this_));
        }), span_p4_3), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> ctor_value_10228) {
            return ({
                auto [self_ph, st2_pi] = ctor_value_10228;
                call_then(crate::check::types::unify::start_unify(st2_pi, self_ph, t_p2_5, span_p4_3), [=](crate::check::types::St unify_10335) {
                return ({
                    auto st3_pg = unify_10335;
                    (prism_rtl::more(prism_rtl::rc(FieldType(env_p0_1, st3_pg, self_ph, field_p3_2, span_p4_3))));
                });
            });
            });
        });
        })
            : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st_p1_4, Text::lit("mismatch"), span_p4_3, prism_rtl::cat("no record has a field `", field_p3_2, "`"))})
            : throw prism_rtl::Panic("no arm matched");
        });
        })
            : prism_rtl::is<crate::check::types::Ty::TyErr>(walk_9134) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), st_p1_4})
            : ({
            auto&& other_pj = walk_9134;
            call_then(crate::check::types::start_show_ty(st_p1_4, other_pj), [=](Text show_ty_10583) { return prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st_p1_4, Text::lit("mismatch"), span_p4_3, prism_rtl::cat("`", show_ty_10583, "` has no field `", field_p3_2, "`"))}); });
        });
        });
    });
}


/// `Start FieldType, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_field_type(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::check::types::Ty t_p2, Text field_p3, crate::syntax::Range span_p4) {
    return prism_rtl::make_rc<FieldType>(env_p0, st_p1, t_p2, field_p3, span_p4);
}


/// ?IndexOf: fn [Text], Text -> ?Nat
std::optional<Nat> index_of(const Array<Text>& xs_p0, const Text& x_p1) {
    return fold(crate::check::errors::range0(len(xs_p0)), std::optional<Nat>{}, [&](const std::optional<Nat>& found_o2, const Nat& i_p3) {
        return ({
            __label__ _done;
            prism_rtl::Slot<std::optional<Nat>> _v;
            if (prism_rtl::is_some(found_o2)) {
                auto&& f_p4 = prism_rtl::some_of(found_o2);
                _v.set(std::optional(f_p4));
                goto _done;
            }
            if (prism_rtl::is_none(found_o2)) {
                _v.set(index(xs_p0, i_p3) == std::optional(x_p1)
                    ? std::optional(i_p3)
                    : std::optional<Nat>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
}


/// InferIndex: unbounded fn Env, St, Expr, Expr, Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_index(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Expr& recv_p2, const crate::syntax::Expr& idx_p3, const crate::syntax::Range& span_p4) {
    auto [rt_p8, st1_p9] = crate::check::expr::infer(env_p0, st_p1, recv_p2);
    auto head_p5 = crate::check::types::head_sigil(st1_p9, rt_p8);
    auto inner_p6 = crate::check::expr::is_time_sigil(head_p5)
        ? crate::check::expr::inner_of(st1_p9, rt_p8)
        : rt_p8;
    auto [v_pa, st2_pb] = crate::check::types::fresh_var(st1_p9, false, Text::lit(""));
    auto [k_pc, st3_pd] = crate::check::types::fresh_var(st2_pb, true, Text::lit(""));
    auto coll0_p7 = crate::check::expr::is_plain_sigil(crate::check::types::head_sigil(st3_pd, inner_p6))
        ? crate::check::expr::inner_of(st3_pd, inner_p6)
        : inner_p6;
    auto&& _m = crate::check::types::recording::walk(st3_pd, coll0_p7);
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
        auto&& m11500_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
        auto&& m11500_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a1;
        if (m11500_0_0 == Text::lit("Text")) {
            if (m11500_0_1.size() == 0u) {
                return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_fix(st3_pd, Text::lit("mismatch"), span_p4, Text::lit("a text has no index: a position in a text is a cursor"), Text::lit("walk it with `Front` and `?Step`, or make a cursor from a byte offset with `?CursorAt`"))};
            }
        }
    }
    {
        auto [coll_pf, key_ty_pg] = ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::Ty>> _v;
            auto&& _m = crate::check::types::recording::walk(st3_pd, coll0_p7);
            if (prism_rtl::is<crate::check::types::Ty::TyMap>(_m)) {
                _v.set(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyMap{prism_rtl::rc(k_pc), prism_rtl::rc(v_pa)}), k_pc});
                goto _done;
            }
            if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
                auto&& m11793_1_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
                if (m11793_1_0 == Text::lit("Table")) {
                    _v.set(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyCon{Text::lit("Table"), Array(std::vector{k_pc, v_pa})}), k_pc});
                    goto _done;
                }
            }
            if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
                auto&& m11793_2_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
                if (m11793_2_0 == Text::lit("Buffer")) {
                    _v.set(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyCon{Text::lit("Buffer"), Array(std::vector{v_pa})}), crate::check::types::t_nat()});
                    goto _done;
                }
            }
            {
                _v.set(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyArray{prism_rtl::rc(v_pa)}), crate::check::types::t_nat()});
                goto _done;
            }
        _done:
            _v.take();
        });
        auto args_pe = Array(std::vector{crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = recv_p2, .span = recv_p2.span}, crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = idx_p3, .span = idx_p3.span}});
        return crate::check::expr::calls::apply_rule(env_p0, st3_pd, Text::lit("[]"), crate::check::types::Col(crate::check::types::Col::CBound{}), Array(std::vector{coll_pf, key_ty_pg}), crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("?"), prism_rtl::rc(v_pa)}), args_pe, span_p4);
    }
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InferIndex::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& recv_p2 = this->recv_p2;
    const auto& idx_p3 = this->idx_p3;
    const auto& span_p4 = this->span_p4;
    auto env_p0_1 = env_p0;
    auto idx_p3_2 = idx_p3;
    auto recv_p2_3 = recv_p2;
    auto span_p4_4 = span_p4;
    auto st_p1_5 = st_p1;
    return call_then(crate::check::expr::start_infer(env_p0_1, st_p1_5, recv_p2_3), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_11119) {
        return ({
            auto [rt_p8, st1_p9] = infer_11119;
            call_then(crate::check::types::start_head_sigil(st1_p9, rt_p8), [=](Text head_sigil_11154) {
            return ({
                auto head_p5 = head_sigil_11154;
                auto inner_p6 = crate::check::expr::is_time_sigil(head_p5)
                    ? crate::check::expr::inner_of(st1_p9, rt_p8)
                    : rt_p8;
                auto [v_pa, st2_pb] = crate::check::types::fresh_var(st1_p9, false, Text::lit(""));
                auto [k_pc, st3_pd] = crate::check::types::fresh_var(st2_pb, true, Text::lit(""));
                call_then(crate::check::types::start_head_sigil(st3_pd, inner_p6), [=](Text head_sigil_11442) {
                return ({
                    auto coll0_p7 = crate::check::expr::is_plain_sigil(head_sigil_11442)
                        ? crate::check::expr::inner_of(st3_pd, inner_p6)
                        : inner_p6;
                    call_then(crate::check::types::recording::start_walk(st3_pd, coll0_p7), [=](crate::check::types::Ty walk_11506) {
                    return ({
                        prism_rtl::is<crate::check::types::Ty::TyCon>(walk_11506) && ({
                        auto&& m11500_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_11506).a0;
                        auto&& m11500_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_11506).a1;
                        (m11500_0_0 == Text::lit("Text")) && (m11500_0_1.size() == 0u);
                    }) ? ({
                        auto&& m11500_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_11506).a0;
                        auto&& m11500_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_11506).a1;
                        prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_fix(st3_pd, Text::lit("mismatch"), span_p4_4, Text::lit("a text has no index: a position in a text is a cursor"), Text::lit("walk it with `Front` and `?Step`, or make a cursor from a byte offset with `?CursorAt`"))});
                    })
                        : call_then(crate::check::types::recording::start_walk(st3_pd, coll0_p7), [=](crate::check::types::Ty walk_11799) {
                        return ({
                            auto [coll_pf, key_ty_pg] = ({
                                __label__ _done;
                                prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::Ty>> _v;
                                if (prism_rtl::is<crate::check::types::Ty::TyMap>(walk_11799)) {
                                    _v.set(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyMap{prism_rtl::rc(k_pc), prism_rtl::rc(v_pa)}), k_pc});
                                    goto _done;
                                }
                                if (prism_rtl::is<crate::check::types::Ty::TyCon>(walk_11799)) {
                                    auto&& m11793_1_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_11799).a0;
                                    if (m11793_1_0 == Text::lit("Table")) {
                                        _v.set(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyCon{Text::lit("Table"), Array(std::vector{k_pc, v_pa})}), k_pc});
                                        goto _done;
                                    }
                                }
                                if (prism_rtl::is<crate::check::types::Ty::TyCon>(walk_11799)) {
                                    auto&& m11793_2_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_11799).a0;
                                    if (m11793_2_0 == Text::lit("Buffer")) {
                                        _v.set(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyCon{Text::lit("Buffer"), Array(std::vector{v_pa})}), crate::check::types::t_nat()});
                                        goto _done;
                                    }
                                }
                                {
                                    _v.set(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyArray{prism_rtl::rc(v_pa)}), crate::check::types::t_nat()});
                                    goto _done;
                                }
                            _done:
                                _v.take();
                            });
                            auto args_pe = Array(std::vector{crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = recv_p2_3, .span = prism_rtl::deref(recv_p2_3).span}, crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = idx_p3_2, .span = prism_rtl::deref(idx_p3_2).span}});
                            (prism_rtl::more(prism_rtl::rc(crate::check::expr::calls::ApplyRule(env_p0_1, st3_pd, Text::lit("[]"), crate::check::types::Col(crate::check::types::Col::CBound{}), Array(std::vector{coll_pf, key_ty_pg}), crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("?"), prism_rtl::rc(v_pa)}), args_pe, span_p4_4))));
                        });
                    });
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start InferIndex, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_index(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Expr recv_p2, crate::syntax::Expr idx_p3, crate::syntax::Range span_p4) {
    return prism_rtl::make_rc<InferIndex>(env_p0, st_p1, recv_p2, idx_p3, span_p4);
}

}  // namespace crate::check::expr::operators
