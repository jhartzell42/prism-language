// The module `Check.Expr.Operators`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <check/expr/operators/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Check.Expr.Operators`, from `target/bootstrap/cpp-src/prismc/check/expr/operators.prism`.
namespace crate::check::expr::operators {

/// InferArray: unbounded fn Env, St, [Expr], Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_array(const crate::check::expr::Env& env, const crate::check::types::St& st, const Array<crate::syntax::Expr>& es, const crate::syntax::Range& span) {
    auto [v_, st2] = crate::check::types::fresh_var(st, false, Text::lit(""));
    auto st3 = run_to_end(fold_job(es, st2, ({
        auto env_1 = env;
        auto v__2 = v_;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::Expr>)>>(prism_rtl::rc([=, env_1 = std::move(env_1), v__2 = std::move(v__2)](std::tuple<crate::check::types::St, crate::syntax::Expr> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_1_3 = env_1;
            auto v__2_3 = v__2;
            entered(once_job([=, env_1_3 = std::move(env_1_3), v__2_3 = std::move(v__2_3)]() {
            return ({
                auto s = p0;
                auto x = p1;
                (prism_rtl::more(prism_rtl::rc(crate::check::expr::Check(env_1_3, s, x, v__2_3))));
            });
        }));
        });
    })));
    })));
    return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyArray{prism_rtl::rc(v_)}), st3};
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InferArray::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& es = this->es;
    const auto& span = this->span;
    auto [v_, st2] = crate::check::types::fresh_var(st, false, Text::lit(""));
    auto env_1 = env;
    auto es_2 = es;
    return call_value(fold_job(es_2, st2, ({
        auto env_1_3 = env_1;
        auto v__3 = v_;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::Expr>)>>(prism_rtl::rc([=, env_1_3 = std::move(env_1_3), v__3 = std::move(v__3)](std::tuple<crate::check::types::St, crate::syntax::Expr> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_1_3_4 = env_1_3;
            auto v__3_4 = v__3;
            entered(once_job([=, env_1_3_4 = std::move(env_1_3_4), v__3_4 = std::move(v__3_4)]() {
            return ({
                auto s = p0;
                auto x = p1;
                (prism_rtl::more(prism_rtl::rc(crate::check::expr::Check(env_1_3_4, s, x, v__3_4))));
            });
        }));
        });
    })));
    })), [=](crate::check::types::St fold_1476) {
        return ({
            auto st3 = fold_1476;
            (prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyArray{prism_rtl::rc(v_)}), st3}));
        });
    });
}


/// `Start InferArray, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_array(crate::check::expr::Env env, crate::check::types::St st, Array<crate::syntax::Expr> es, crate::syntax::Range span) {
    return prism_rtl::make_rc<InferArray>(env, st, es, span);
}


/// InferMap: unbounded fn Env, St, [((Expr, Expr))], Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_map(const crate::check::expr::Env& env, const crate::check::types::St& st, const Array<std::tuple<crate::syntax::Expr, crate::syntax::Expr>>& entries, const crate::syntax::Range& span) {
    auto [k, st1] = crate::check::types::fresh_var(st, true, Text::lit(""));
    auto [v_, st2] = crate::check::types::fresh_var(st1, false, Text::lit(""));
    auto n = len(entries);
    auto params = fold(entries, Array<crate::check::types::Ty>{}, [&](const Array<crate::check::types::Ty>& acc, const std::tuple<crate::syntax::Expr, crate::syntax::Expr>& _p1) { return append(acc, Array(std::vector{k, v_})); });
    auto args = fold(entries, Array<crate::syntax::Arg>{}, [&](const Array<crate::syntax::Arg>& acc, const std::tuple<crate::syntax::Expr, crate::syntax::Expr>& _p1) {
        auto&& ke = std::get<0>(_p1);
        auto&& ve = std::get<1>(_p1);
        return append(acc, Array(std::vector{crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = ke, .span = prism_rtl::deref(ke).span}, crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = ve, .span = prism_rtl::deref(ve).span}}));
    });
    auto st3 = n > Nat(0u)
        ? crate::check::expr::add_want(st2, Text::lit("Prelude.Ord"), k, span)
        : st2;
    return crate::check::expr::calls::apply_rule(env, st3, Text::lit("a map literal"), crate::check::types::Col(crate::check::types::Col::CBound{}), params, crate::check::types::Ty(crate::check::types::Ty::TyMap{prism_rtl::rc(k), prism_rtl::rc(v_)}), args, span);
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InferMap::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& entries = this->entries;
    const auto& span = this->span;
    auto [k, st1] = crate::check::types::fresh_var(st, true, Text::lit(""));
    auto [v_, st2] = crate::check::types::fresh_var(st1, false, Text::lit(""));
    auto n = len(entries);
    auto params = fold(entries, Array<crate::check::types::Ty>{}, [&](const Array<crate::check::types::Ty>& acc, const std::tuple<crate::syntax::Expr, crate::syntax::Expr>& _p1) { return append(acc, Array(std::vector{k, v_})); });
    auto args = fold(entries, Array<crate::syntax::Arg>{}, [&](const Array<crate::syntax::Arg>& acc, const std::tuple<crate::syntax::Expr, crate::syntax::Expr>& _p1) {
        auto&& ke = std::get<0>(_p1);
        auto&& ve = std::get<1>(_p1);
        return append(acc, Array(std::vector{crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = ke, .span = prism_rtl::deref(ke).span}, crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = ve, .span = prism_rtl::deref(ve).span}}));
    });
    auto st3 = n > Nat(0u)
        ? crate::check::expr::add_want(st2, Text::lit("Prelude.Ord"), k, span)
        : st2;
    return prism_rtl::more(prism_rtl::rc(crate::check::expr::calls::ApplyRule(env, st3, Text::lit("a map literal"), crate::check::types::Col(crate::check::types::Col::CBound{}), params, crate::check::types::Ty(crate::check::types::Ty::TyMap{prism_rtl::rc(k), prism_rtl::rc(v_)}), args, span)));
}


/// `Start InferMap, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_map(crate::check::expr::Env env, crate::check::types::St st, Array<std::tuple<crate::syntax::Expr, crate::syntax::Expr>> entries, crate::syntax::Range span) {
    return prism_rtl::make_rc<InferMap>(env, st, entries, span);
}


/// InferBinary: unbounded fn Env, St, Text, Expr, Expr, Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_binary(const crate::check::expr::Env& env, const crate::check::types::St& st, const Text& op, const crate::syntax::Expr& lhs, const crate::syntax::Expr& rhs, const crate::syntax::Range& span) {
    auto args = Array(std::vector{crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = lhs, .span = lhs.span}, crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = rhs, .span = rhs.span}});
    return (op == Text::lit("and")) || (op == Text::lit("or"))
        ? crate::check::expr::calls::apply_rule(env, st, op, crate::check::types::Col(crate::check::types::Col::CBound{}), Array(std::vector{crate::check::types::t_bool(), crate::check::types::t_bool()}), crate::check::types::t_bool(), args, span)
        : op == Text::lit("on")
        ? infer_on(env, st, lhs, rhs, span)
        : op == Text::lit("<|")
        ? ({
        auto [v_, st2] = crate::check::types::fresh_var(st, false, Text::lit(""));
        (crate::check::expr::calls::apply_rule(env, st2, op, crate::check::types::Col(crate::check::types::Col::CBound{}), Array(std::vector{crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("!"), prism_rtl::rc(v_)}), crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("!"), prism_rtl::rc(v_)})}), crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("!"), prism_rtl::rc(v_)}), args, span));
    })
        : op == Text::lit("mod")
        ? ({
        auto [v_, st2] = crate::check::types::fresh_var(st, true, Text::lit(""));
        auto st3 = crate::check::expr::add_want(st2, Text::lit("Prelude.Num"), v_, span);
        (crate::check::expr::calls::apply_rule(env, st3, op, crate::check::types::Col(crate::check::types::Col::CBound{}), Array(std::vector{v_, v_}), v_, args, span));
    })
        : ({
        auto [t0, st2] = crate::check::expr::infer_name(env, st, crate::syntax::SName{.sigils = Text::lit(""), .path_ = Array(std::vector{op}), .span = span}, span);
        auto t = op == Text::lit("/") ? quotient_of(st2, t0) : t0;
        auto st2b = op == Text::lit("-?")
            ? crate::check::types::recording::note_size_ty(st2, span, crate::check::types::recording::walk(st2, t0))
            : st2;
        auto st3 = op == Text::lit("-") ? sub_want(st2b, t, span) : st2b;
        (crate::check::expr::calls::apply_fn(env, st3, op, t, args, span));
    });
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InferBinary::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& op = this->op;
    const auto& lhs = this->lhs;
    const auto& rhs = this->rhs;
    const auto& span = this->span;
    auto args = Array(std::vector{crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = lhs, .span = prism_rtl::deref(lhs).span}, crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = rhs, .span = prism_rtl::deref(rhs).span}});
    return (op == Text::lit("and")) || (op == Text::lit("or"))
        ? prism_rtl::more(prism_rtl::rc(crate::check::expr::calls::ApplyRule(env, st, op, crate::check::types::Col(crate::check::types::Col::CBound{}), Array(std::vector{crate::check::types::t_bool(), crate::check::types::t_bool()}), crate::check::types::t_bool(), args, span)))
        : op == Text::lit("on")
        ? prism_rtl::more(prism_rtl::rc(InferOn(env, st, lhs, rhs, span)))
        : op == Text::lit("<|")
        ? ({
        auto [v_, st2] = crate::check::types::fresh_var(st, false, Text::lit(""));
        (prism_rtl::more(prism_rtl::rc(crate::check::expr::calls::ApplyRule(env, st2, op, crate::check::types::Col(crate::check::types::Col::CBound{}), Array(std::vector{crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("!"), prism_rtl::rc(v_)}), crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("!"), prism_rtl::rc(v_)})}), crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("!"), prism_rtl::rc(v_)}), args, span))));
    })
        : op == Text::lit("mod")
        ? ({
        auto [v_, st2] = crate::check::types::fresh_var(st, true, Text::lit(""));
        auto st3 = crate::check::expr::add_want(st2, Text::lit("Prelude.Num"), v_, span);
        (prism_rtl::more(prism_rtl::rc(crate::check::expr::calls::ApplyRule(env, st3, op, crate::check::types::Col(crate::check::types::Col::CBound{}), Array(std::vector{v_, v_}), v_, args, span))));
    })
        : ({
        auto env_1 = env;
        auto op_2 = op;
        auto span_3 = span;
        auto st_4 = st;
        call_then(crate::check::expr::start_infer_name(env_1, st_4, crate::syntax::SName{.sigils = Text::lit(""), .path_ = Array(std::vector{op_2}), .span = span_3}, span_3), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_name_3258) {
        return ({
            auto [t0, st2] = infer_name_3258;
            auto t = op_2 == Text::lit("/") ? quotient_of(st2, t0) : t0;
            auto st2b = op_2 == Text::lit("-?")
                ? crate::check::types::recording::note_size_ty(st2, span_3, crate::check::types::recording::walk(st2, t0))
                : st2;
            auto st3 = op_2 == Text::lit("-") ? sub_want(st2b, t, span_3) : st2b;
            (prism_rtl::more(prism_rtl::rc(crate::check::expr::calls::ApplyFn(env_1, st3, op_2, t, args, span_3))));
        });
    });
    });
}


/// `Start InferBinary, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_binary(crate::check::expr::Env env, crate::check::types::St st, Text op, crate::syntax::Expr lhs, crate::syntax::Expr rhs, crate::syntax::Range span) {
    return prism_rtl::make_rc<InferBinary>(env, st, op, lhs, rhs, span);
}


/// QuotientOf: unbounded fn St, Ty -> Ty
crate::check::types::Ty quotient_of(const crate::check::types::St& st, const crate::check::types::Ty& t) {
    auto&& _m = crate::check::types::recording::walk(st, t);
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
        auto&& c = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a0;
        auto&& ps = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a1;
        auto&& _m = index(ps, Nat(0u));
        if (prism_rtl::is_some(_m)) {
            auto&& p_ = prism_rtl::some_of(_m);
            return crate::check::types::Ty(crate::check::types::Ty::TyFn{c, ps, prism_rtl::rc(crate::check::types::Ty(crate::check::types::Ty::TyAssoc{Text::lit("Quotient"), prism_rtl::rc(p_)}))});
        }
        if (prism_rtl::is_none(_m)) {
            return t;
        }
        prism_rtl::unreachable("no arm matched");
    }
    {
        auto&& other = _m;
        return other;
    }
}


prism_rtl::Turn<crate::check::types::Ty> QuotientOf::cycle() const {
    const auto& st = this->st;
    const auto& t = this->t;
    auto st_1 = st;
    auto t_2 = t;
    return call_then(crate::check::types::recording::start_walk(st_1, t_2), [=](crate::check::types::Ty walk_3748) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TyFn>(walk_3748) ? ({
            auto&& c = prism_rtl::as<crate::check::types::Ty::TyFn>(walk_3748).a0;
            auto&& ps = prism_rtl::as<crate::check::types::Ty::TyFn>(walk_3748).a1;
            ({
            auto&& _m = index(ps, Nat(0u));
            prism_rtl::is_some(_m) ? ({
            auto&& p_ = prism_rtl::some_of(_m);
            prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyFn{c, ps, prism_rtl::rc(crate::check::types::Ty(crate::check::types::Ty::TyAssoc{Text::lit("Quotient"), prism_rtl::rc(p_)}))}));
        })
            : prism_rtl::is_none(_m) ? prism_rtl::finished(t_2)
            : throw prism_rtl::Panic("no arm matched");
        });
        })
            : ({
            auto&& other = walk_3748;
            prism_rtl::finished(other);
        });
        });
    });
}


/// `Start QuotientOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::Ty> start_quotient_of(crate::check::types::St st, crate::check::types::Ty t) {
    return prism_rtl::make_rc<QuotientOf>(st, t);
}


/// SubWant: unbounded fn St, Ty, Range -> St
crate::check::types::St sub_want(const crate::check::types::St& st, const crate::check::types::Ty& t, const crate::syntax::Range& span) {
    auto&& _m = crate::check::types::recording::walk(st, t);
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
        auto&& ps = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a1;
        auto&& _m = index(ps, Nat(0u));
        if (prism_rtl::is_some(_m)) {
            auto&& p_ = prism_rtl::some_of(_m);
            return crate::check::expr::add_want(st, Text::lit("Prelude.Sub"), p_, span);
        }
        if (prism_rtl::is_none(_m)) {
            return st;
        }
        prism_rtl::unreachable("no arm matched");
    }
    {
        return st;
    }
}


prism_rtl::Turn<crate::check::types::St> SubWant::cycle() const {
    const auto& st = this->st;
    const auto& t = this->t;
    const auto& span = this->span;
    auto span_1 = span;
    auto st_2 = st;
    auto t_3 = t;
    return call_then(crate::check::types::recording::start_walk(st_2, t_3), [=](crate::check::types::Ty walk_4076) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TyFn>(walk_4076) ? ({
            auto&& ps = prism_rtl::as<crate::check::types::Ty::TyFn>(walk_4076).a1;
            ({
            auto&& _m = index(ps, Nat(0u));
            prism_rtl::is_some(_m) ? ({
            auto&& p_ = prism_rtl::some_of(_m);
            prism_rtl::finished(crate::check::expr::add_want(st_2, Text::lit("Prelude.Sub"), p_, span_1));
        })
            : prism_rtl::is_none(_m) ? prism_rtl::finished(st_2)
            : throw prism_rtl::Panic("no arm matched");
        });
        })
            : prism_rtl::finished(st_2);
        });
    });
}


/// `Start SubWant, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_sub_want(crate::check::types::St st, crate::check::types::Ty t, crate::syntax::Range span) {
    return prism_rtl::make_rc<SubWant>(st, t, span);
}


/// InferOn: unbounded fn Env, St, Expr, Expr, Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_on(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Expr& lhs, const crate::syntax::Expr& rhs, const crate::syntax::Range& span) {
    auto [a, st1] = crate::check::types::fresh_var(st, true, Text::lit(""));
    auto [b, st2] = crate::check::types::fresh_var(st1, true, Text::lit(""));
    auto [rt, st3] = crate::check::expr::infer(env, st2, rhs);
    return ((crate::check::types::head_sigil(st3, rt) != Text::lit("!")) && (rt != crate::check::types::Ty(crate::check::types::Ty::TyErr{}))) && (!crate::check::types::is_flex_var(st3, rt))
        ? std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st3, Text::lit("mismatch"), rhs.span, prism_rtl::cat("`on` fires with an event on its right; this is `", crate::check::types::show_ty(st3, rt), "`"))}
        : ({
        auto args = Array(std::vector{crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = lhs, .span = lhs.span}, crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = rhs, .span = rhs.span}});
        (crate::check::expr::calls::apply_rule(env, st3, Text::lit("on"), crate::check::types::Col(crate::check::types::Col::CBound{}), Array(std::vector{a, b}), a, args, span));
    });
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InferOn::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& lhs = this->lhs;
    const auto& rhs = this->rhs;
    const auto& span = this->span;
    auto [a, st1] = crate::check::types::fresh_var(st, true, Text::lit(""));
    auto [b, st2] = crate::check::types::fresh_var(st1, true, Text::lit(""));
    auto env_1 = env;
    auto lhs_2 = lhs;
    auto rhs_3 = rhs;
    auto span_4 = span;
    return call_then(crate::check::expr::start_infer(env_1, st2, rhs_3), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_4554) {
        return ({
            auto [rt, st3] = infer_4554;
            call_then(crate::check::types::start_head_sigil(st3, rt), [=](Text head_sigil_4582) {
            return ((head_sigil_4582 != Text::lit("!")) && (rt != crate::check::types::Ty(crate::check::types::Ty::TyErr{}))) && (!crate::check::types::is_flex_var(st3, rt))
                ? call_then(crate::check::types::start_show_ty(st3, rt), [=](Text show_ty_4752) { return prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st3, Text::lit("mismatch"), prism_rtl::deref(rhs_3).span, prism_rtl::cat("`on` fires with an event on its right; this is `", show_ty_4752, "`"))}); })
                : ({
                auto args = Array(std::vector{crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = lhs_2, .span = prism_rtl::deref(lhs_2).span}, crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = rhs_3, .span = prism_rtl::deref(rhs_3).span}});
                (prism_rtl::more(prism_rtl::rc(crate::check::expr::calls::ApplyRule(env_1, st3, Text::lit("on"), crate::check::types::Col(crate::check::types::Col::CBound{}), Array(std::vector{a, b}), a, args, span_4))));
            });
        });
        });
    });
}


/// `Start InferOn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_on(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Expr lhs, crate::syntax::Expr rhs, crate::syntax::Range span) {
    return prism_rtl::make_rc<InferOn>(env, st, lhs, rhs, span);
}


/// InferUnary: unbounded fn Env, St, Text, Expr, Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_unary(const crate::check::expr::Env& env, const crate::check::types::St& st, const Text& op, const crate::syntax::Expr& x, const crate::syntax::Range& span) {
    auto args = Array(std::vector{crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = x, .span = x.span}});
    {
        auto&& m5115_0 = op;
        if (m5115_0 == Text::lit("not")) {
            return crate::check::expr::calls::apply_rule(env, st, Text::lit("not"), crate::check::types::Col(crate::check::types::Col::CBound{}), Array(std::vector{crate::check::types::t_bool()}), crate::check::types::t_bool(), args, span);
        }
    }
    {
        auto&& m5115_1 = op;
        if (m5115_1 == Text::lit("neg")) {
            auto&& _m = prism_rtl::deref(x.kind);
            if (prism_rtl::is<crate::syntax::ExprKind::ELit>(_m)) {
                auto&& l = prism_rtl::as<crate::syntax::ExprKind::ELit>(_m).a0;
                auto [t, st2] = crate::check::expr::infer_lit(env, st, l, true, span);
                return std::tuple{t, crate::check::types::recording::note_ty(st2, x.span, t)};
            }
            {
                auto [v_, st2] = crate::check::types::fresh_var(st, true, Text::lit(""));
                auto st3 = crate::check::expr::add_want(crate::check::expr::add_want(st2, Text::lit("Prelude.Num"), v_, span), Text::lit("Prelude.Signed"), v_, span);
                return crate::check::expr::calls::apply_rule(env, st3, Text::lit("-"), crate::check::types::Col(crate::check::types::Col::CBound{}), Array(std::vector{v_}), v_, args, span);
            }
        }
    }
    {
        return crate::check::expr::infer(env, st, x);
    }
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InferUnary::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& op = this->op;
    const auto& x = this->x;
    const auto& span = this->span;
    auto args = Array(std::vector{crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = x, .span = prism_rtl::deref(x).span}});
    return ({
        ({
        auto&& m5115_0 = op;
        (m5115_0 == Text::lit("not"));
    }) ? ({
        auto&& m5115_0 = op;
        prism_rtl::more(prism_rtl::rc(crate::check::expr::calls::ApplyRule(env, st, Text::lit("not"), crate::check::types::Col(crate::check::types::Col::CBound{}), Array(std::vector{crate::check::types::t_bool()}), crate::check::types::t_bool(), args, span)));
    })
        : ({
        auto&& m5115_1 = op;
        (m5115_1 == Text::lit("neg"));
    }) ? ({
        auto&& m5115_1 = op;
        ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(x).kind);
        prism_rtl::is<crate::syntax::ExprKind::ELit>(_m) ? ({
        auto&& l = prism_rtl::as<crate::syntax::ExprKind::ELit>(_m).a0;
        ({
        auto env_1 = env;
        auto l_2 = l;
        auto span_3 = span;
        auto st_4 = st;
        auto x_5 = x;
        call_then(crate::check::expr::start_infer_lit(env_1, st_4, l_2, true, span_3), [=, x_5 = std::move(x_5)](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_lit_5285) {
        return ({
            auto [t, st2] = infer_lit_5285;
            (prism_rtl::finished(std::tuple{t, crate::check::types::recording::note_ty(st2, prism_rtl::deref(x_5).span, t)}));
        });
    });
    });
    })
        : ({
        auto [v_, st2] = crate::check::types::fresh_var(st, true, Text::lit(""));
        auto st3 = crate::check::expr::add_want(crate::check::expr::add_want(st2, Text::lit("Prelude.Num"), v_, span), Text::lit("Prelude.Signed"), v_, span);
        (prism_rtl::more(prism_rtl::rc(crate::check::expr::calls::ApplyRule(env, st3, Text::lit("-"), crate::check::types::Col(crate::check::types::Col::CBound{}), Array(std::vector{v_}), v_, args, span))));
    });
    });
    })
        : prism_rtl::more(prism_rtl::rc(crate::check::expr::Infer(env, st, x)));
    });
}


/// `Start InferUnary, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_unary(crate::check::expr::Env env, crate::check::types::St st, Text op, crate::syntax::Expr x, crate::syntax::Range span) {
    return prism_rtl::make_rc<InferUnary>(env, st, op, x, span);
}


/// InferFreeSigil: unbounded fn Env, St, Text, Expr, Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_free_sigil(const crate::check::expr::Env& env, const crate::check::types::St& st, const Text& s, const crate::syntax::Expr& x, const crate::syntax::Range& span) {
    return s == Text::lit("@")
        ? ({
        auto [t, st2] = crate::check::expr::infer(env, st, x);
        std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyAt{prism_rtl::rc(t), env.scope}), st2};
    })
        : ((s == Text::lit("?")) || (s == Text::lit("~"))) || (s == Text::lit("$"))
        ? ({
        auto [v_, st2] = crate::check::types::fresh_var(st, false, Text::lit(""));
        is_blueprint_expr(env, st2, x)
        ? ({
        auto [t, st3] = crate::check::expr::infer(env, st2, x);
        std::tuple{crate::check::types::Ty(crate::check::types::Ty::TySig{s, prism_rtl::rc(t)}), st3};
    })
        : crate::check::expr::calls::apply_rule(env, st2, prism_rtl::cat(s), crate::check::types::Col(crate::check::types::Col::CBound{}), Array(std::vector{v_}), crate::check::types::Ty(crate::check::types::Ty::TySig{s, prism_rtl::rc(v_)}), Array(std::vector{crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = x, .span = x.span}}), span);
    })
        : ({
        auto [t, st2] = crate::check::expr::infer(env, st, x);
        std::tuple{crate::check::types::with_marks(s, t, env.scope), st2};
    });
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InferFreeSigil::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& s = this->s;
    const auto& x = this->x;
    const auto& span = this->span;
    return s == Text::lit("@")
        ? ({
        auto env_1 = env;
        auto st_2 = st;
        auto x_3 = x;
        call_then(crate::check::expr::start_infer(env_1, st_2, x_3), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_5931) {
        return ({
            auto [t, st2] = infer_5931;
            (prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyAt{prism_rtl::rc(t), prism_rtl::deref(env_1).scope}), st2}));
        });
    });
    })
        : ((s == Text::lit("?")) || (s == Text::lit("~"))) || (s == Text::lit("$"))
        ? ({
        auto [v_, st2] = crate::check::types::fresh_var(st, false, Text::lit(""));
        is_blueprint_expr(env, st2, x)
        ? ({
        auto env_1 = env;
        auto s_2 = s;
        auto x_3 = x;
        call_then(crate::check::expr::start_infer(env_1, st2, x_3), [=, s_2 = std::move(s_2)](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_6149) {
        return ({
            auto [t, st3] = infer_6149;
            (prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TySig{s_2, prism_rtl::rc(t)}), st3}));
        });
    });
    })
        : prism_rtl::more(prism_rtl::rc(crate::check::expr::calls::ApplyRule(env, st2, prism_rtl::cat(s), crate::check::types::Col(crate::check::types::Col::CBound{}), Array(std::vector{v_}), crate::check::types::Ty(crate::check::types::Ty::TySig{s, prism_rtl::rc(v_)}), Array(std::vector{crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = x, .span = prism_rtl::deref(x).span}}), span)));
    })
        : ({
        auto env_1 = env;
        auto s_2 = s;
        auto st_3 = st;
        auto x_4 = x;
        call_then(crate::check::expr::start_infer(env_1, st_3, x_4), [=, s_2 = std::move(s_2)](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_6352) {
        return ({
            auto [t, st2] = infer_6352;
            (prism_rtl::finished(std::tuple{crate::check::types::with_marks(s_2, t, prism_rtl::deref(env_1).scope), st2}));
        });
    });
    });
}


/// `Start InferFreeSigil, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_free_sigil(crate::check::expr::Env env, crate::check::types::St st, Text s, crate::syntax::Expr x, crate::syntax::Range span) {
    return prism_rtl::make_rc<InferFreeSigil>(env, st, s, x, span);
}


/// IsBlueprintExpr: fn Env, St, Expr -> Bool
bool is_blueprint_expr(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Expr& x) {
    auto&& _m = prism_rtl::deref(x.kind);
    if (prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m)) {
        auto&& m6632_0_0 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
        if (m6632_0_0 == Text::lit("@")) {
            return true;
        }
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& y = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return is_blueprint_expr(env, st, prism_rtl::deref(prism_rtl::deref(y)));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
        auto&& c = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
        auto&& _m = prism_rtl::deref(prism_rtl::deref(c).kind);
        if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
            auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
            return crate::syntax::lexer::chars::has_prefix(prism_rtl::deref(n).sigils, Text::lit("@"));
        }
        {
            return false;
        }
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        return crate::syntax::lexer::chars::has_prefix(prism_rtl::deref(n).sigils, Text::lit("@"));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EWidgetBlock>(_m)) {
        return true;
    }
    {
        return false;
    }
}


/// InferField: unbounded fn Env, St, Expr, Text, Ident, Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_field(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Expr& recv, const Text& sigils, const crate::syntax::Ident& name, const crate::syntax::Range& span) {
    auto [rt, st1] = crate::check::expr::infer(env, st, recv);
    auto head = crate::check::types::head_sigil(st1, rt);
    auto inner = crate::check::expr::is_time_sigil(head)
        ? crate::check::expr::inner_of(st1, rt)
        : rt;
    auto ih = crate::check::blocks::borrows::is_ref(recv)
        ? Text::lit("")
        : crate::check::types::head_sigil(st1, inner);
    auto plain_t = crate::check::expr::is_plain_sigil(crate::check::types::head_sigil(st1, inner))
        ? crate::check::expr::inner_of(st1, inner)
        : inner;
    auto st2 = head == Text::lit("@")
        ? crate::check::types::recording::err(st1, Text::lit("blueprint-operand"), recv.span, prism_rtl::cat("`.", name.name, "` over a blueprint; bind it first"))
        : st1;
    auto [ft, st3] = field_type(env, st2, plain_t, name.name, span);
    auto stack = crate::check::types::stack_of(st3, ft);
    auto bad = (((stack != sigils) && (ft != crate::check::types::Ty(crate::check::types::Ty::TyErr{}))) && (!crate::check::types::is_flex_var(st3, ft))) && (!crate::check::blocks::borrows::is_ref(recv));
    auto st4 = std::move(bad)
        ? crate::check::types::recording::err_fix(st3, Text::lit("mark-stack"), name.span, prism_rtl::cat("`.", sigils, name.name, "` has type `", crate::check::types::show_ty(st3, ft), "`, whose stack is `", stack, "`; the access shows `", sigils, "`"), prism_rtl::cat("write `.", stack, name.name, "`"))
        : st3;
    auto with_opt = crate::check::expr::is_plain_sigil(ih)
        ? crate::check::types::Ty(crate::check::types::Ty::TySig{ih, prism_rtl::rc(ft)})
        : ft;
    auto res = crate::check::expr::is_time_sigil(head)
        ? crate::check::types::Ty(crate::check::types::Ty::TySig{head, prism_rtl::rc(with_opt)})
        : with_opt;
    auto st5 = crate::check::expr::is_time_sigil(head)
        ? crate::check::expr::calls::elab(st4, span, prism_rtl::cat(".", name.name), Text::lit("map"), head)
        : st4;
    auto st6 = crate::check::expr::is_plain_sigil(ih)
        ? crate::check::types::recording::note_lift(st5, span, ih, Array(std::vector{recv.span}))
        : st5;
    return std::tuple{res, st6};
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InferField::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& recv = this->recv;
    const auto& sigils = this->sigils;
    const auto& name = this->name;
    const auto& span = this->span;
    auto env_1 = env;
    auto name_2 = name;
    auto recv_3 = recv;
    auto sigils_4 = sigils;
    auto span_5 = span;
    auto st_6 = st;
    return call_then(crate::check::expr::start_infer(env_1, st_6, recv_3), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_7445) {
        return ({
            auto [rt, st1] = infer_7445;
            call_then(crate::check::types::start_head_sigil(st1, rt), [=](Text head_sigil_7480) {
            return ({
                auto head = head_sigil_7480;
                auto inner = crate::check::expr::is_time_sigil(head)
                    ? crate::check::expr::inner_of(st1, rt)
                    : rt;
                auto ih = crate::check::blocks::borrows::is_ref(recv_3)
                    ? Text::lit("")
                    : crate::check::types::head_sigil(st1, inner);
                call_then(crate::check::types::start_head_sigil(st1, inner), [=, head = std::move(head), ih = std::move(ih)](Text head_sigil_7814) {
                return ({
                    auto plain_t = crate::check::expr::is_plain_sigil(head_sigil_7814)
                        ? crate::check::expr::inner_of(st1, inner)
                        : inner;
                    auto st2 = head == Text::lit("@")
                        ? crate::check::types::recording::err(st1, Text::lit("blueprint-operand"), prism_rtl::deref(recv_3).span, prism_rtl::cat("`.", prism_rtl::deref(name_2).name, "` over a blueprint; bind it first"))
                        : st1;
                    call_then(start_field_type(env_1, st2, plain_t, prism_rtl::deref(name_2).name, span_5), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> field_type_8020) {
                    return ({
                        auto [ft, st3] = field_type_8020;
                        call_then(crate::check::types::start_stack_of(st3, ft), [=](Text stack_of_8080) {
                        return ({
                            auto stack = stack_of_8080;
                            auto bad = (((stack != sigils_4) && (ft != crate::check::types::Ty(crate::check::types::Ty::TyErr{}))) && (!crate::check::types::is_flex_var(st3, ft))) && (!crate::check::blocks::borrows::is_ref(recv_3));
                            auto st4 = std::move(bad)
                                ? crate::check::types::recording::err_fix(st3, Text::lit("mark-stack"), prism_rtl::deref(name_2).span, prism_rtl::cat("`.", sigils_4, prism_rtl::deref(name_2).name, "` has type `", crate::check::types::show_ty(st3, ft), "`, whose stack is `", stack, "`; the access shows `", sigils_4, "`"), prism_rtl::cat("write `.", stack, prism_rtl::deref(name_2).name, "`"))
                                : st3;
                            auto with_opt = crate::check::expr::is_plain_sigil(ih)
                                ? crate::check::types::Ty(crate::check::types::Ty::TySig{ih, prism_rtl::rc(ft)})
                                : ft;
                            auto res = crate::check::expr::is_time_sigil(head)
                                ? crate::check::types::Ty(crate::check::types::Ty::TySig{head, prism_rtl::rc(with_opt)})
                                : with_opt;
                            auto st5 = crate::check::expr::is_time_sigil(head)
                                ? crate::check::expr::calls::elab(st4, span_5, prism_rtl::cat(".", prism_rtl::deref(name_2).name), Text::lit("map"), head)
                                : st4;
                            auto st6 = crate::check::expr::is_plain_sigil(ih)
                                ? crate::check::types::recording::note_lift(st5, span_5, ih, Array(std::vector{prism_rtl::deref(recv_3).span}))
                                : st5;
                            (prism_rtl::finished(std::tuple{res, st6}));
                        });
                    });
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start InferField, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_field(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Expr recv, Text sigils, crate::syntax::Ident name, crate::syntax::Range span) {
    return prism_rtl::make_rc<InferField>(env, st, recv, sigils, name, span);
}


/// FieldType: unbounded fn Env, St, Ty, Text, Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> field_type(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::check::types::Ty& t, const Text& field_, const crate::syntax::Range& span) {
    auto&& _m = crate::check::types::recording::walk(st, t);
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
        auto&& args = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a1;
        auto&& _m = crate::prelude::get(prism_rtl::deref(env.g).ctors, n);
        if (prism_rtl::is_some(_m)) {
            auto&& c = prism_rtl::some_of(_m);
            auto&& _m = index_of(prism_rtl::deref(c).fields, field_);
            if (prism_rtl::is_some(_m)) {
                auto&& i = prism_rtl::some_of(_m);
                auto inst = crate::check::env::reading::param_inst(prism_rtl::deref(c).params, args);
                return std::tuple{crate::check::types::schemes::subst_q(inst, or_(index(c->args, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{}))), st};
            }
            if (prism_rtl::is_none(_m)) {
                return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st, Text::lit("mismatch"), span, prism_rtl::cat("`", crate::check::types::bare_name(n), "` has no field `", field_, "`"))};
            }
            prism_rtl::unreachable("no arm matched");
        }
        if (prism_rtl::is_none(_m)) {
            return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st, Text::lit("mismatch"), span, prism_rtl::cat("`", crate::check::types::bare_name(n), "` has no fields"))};
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFlex>(_m)) {
        auto owners = filter(values(prism_rtl::deref(env.g).ctors), [&](const crate::check::env::CtorInfo& c) { return crate::check::types::has_text(prism_rtl::deref(c).fields, field_); });
        auto&& _m = index(owners, Nat(0u));
        if (prism_rtl::is_some(_m)) {
            auto&& c = prism_rtl::some_of(_m);
            return len(owners) > Nat(1u)
                ? ({
                auto [v_, st2] = crate::check::types::fresh_var(st, false, Text::lit(""));
                std::tuple{v_, crate::check::types::unify::ask_field(st2, t, field_, v_, span, each(owners, [&](const crate::check::env::CtorInfo& o) { return crate::check::types::bare_name(prism_rtl::deref(o).owner); }))};
            })
                : ({
                auto [self_, st2] = crate::check::expr::ctor_value(env, st, ({
                    crate::check::env::CtorInfo this_ = c;
                    this_.args = Array<crate::check::types::Ty>{};
                    (std::move(this_));
                }), span);
                auto st3 = crate::check::types::unify::unify(st2, self_, t, span);
                field_type(env, st3, self_, field_, span);
            });
        }
        if (prism_rtl::is_none(_m)) {
            return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st, Text::lit("mismatch"), span, prism_rtl::cat("no record has a field `", field_, "`"))};
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<crate::check::types::Ty::TyErr>(_m)) {
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), st};
    }
    {
        auto&& other = _m;
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st, Text::lit("mismatch"), span, prism_rtl::cat("`", crate::check::types::show_ty(st, other), "` has no field `", field_, "`"))};
    }
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> FieldType::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& t = this->t;
    const auto& field_ = this->field_;
    const auto& span = this->span;
    auto env_1 = env;
    auto field__2 = field_;
    auto span_3 = span;
    auto st_4 = st;
    auto t_5 = t;
    return call_then(crate::check::types::recording::start_walk(st_4, t_5), [=](crate::check::types::Ty walk_9134) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TyCon>(walk_9134) ? ({
            auto&& n = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_9134).a0;
            auto&& args = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_9134).a1;
            ({
            auto&& _m = crate::prelude::get(prism_rtl::deref(prism_rtl::deref(env_1).g).ctors, n);
            prism_rtl::is_some(_m) ? ({
            auto&& c = prism_rtl::some_of(_m);
            ({
            auto&& _m = index_of(prism_rtl::deref(c).fields, field__2);
            prism_rtl::is_some(_m) ? ({
            auto&& i = prism_rtl::some_of(_m);
            ({
            auto inst = crate::check::env::reading::param_inst(prism_rtl::deref(c).params, args);
            call_then(crate::check::types::schemes::start_subst_q(inst, or_(index(c->args, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{}))), [=](crate::check::types::Ty subst_q_9344) { return prism_rtl::finished(std::tuple{subst_q_9344, st_4}); });
        });
        })
            : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st_4, Text::lit("mismatch"), span_3, prism_rtl::cat("`", crate::check::types::bare_name(n), "` has no field `", field__2, "`"))})
            : throw prism_rtl::Panic("no arm matched");
        });
        })
            : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st_4, Text::lit("mismatch"), span_3, prism_rtl::cat("`", crate::check::types::bare_name(n), "` has no fields"))})
            : throw prism_rtl::Panic("no arm matched");
        });
        })
            : prism_rtl::is<crate::check::types::Ty::TyFlex>(walk_9134) ? ({
            auto owners = filter(values(prism_rtl::deref(prism_rtl::deref(env_1).g).ctors), [&](const crate::check::env::CtorInfo& c) { return crate::check::types::has_text(prism_rtl::deref(c).fields, field__2); });
            ({
            auto&& _m = index(owners, Nat(0u));
            prism_rtl::is_some(_m) ? ({
            auto&& c = prism_rtl::some_of(_m);
            len(owners) > Nat(1u)
            ? ({
            auto [v_, st2] = crate::check::types::fresh_var(st_4, false, Text::lit(""));
            (prism_rtl::finished(std::tuple{v_, crate::check::types::unify::ask_field(st2, t_5, field__2, v_, span_3, each(owners, [&](const crate::check::env::CtorInfo& o) { return crate::check::types::bare_name(prism_rtl::deref(o).owner); }))}));
        })
            : call_then(crate::check::expr::start_ctor_value(env_1, st_4, ({
            crate::check::env::CtorInfo this_ = c;
            this_.args = Array<crate::check::types::Ty>{};
            (std::move(this_));
        }), span_3), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> ctor_value_10228) {
            return ({
                auto [self_, st2] = ctor_value_10228;
                call_then(crate::check::types::unify::start_unify(st2, self_, t_5, span_3), [=](crate::check::types::St unify_10335) {
                return ({
                    auto st3 = unify_10335;
                    (prism_rtl::more(prism_rtl::rc(FieldType(env_1, st3, self_, field__2, span_3))));
                });
            });
            });
        });
        })
            : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st_4, Text::lit("mismatch"), span_3, prism_rtl::cat("no record has a field `", field__2, "`"))})
            : throw prism_rtl::Panic("no arm matched");
        });
        })
            : prism_rtl::is<crate::check::types::Ty::TyErr>(walk_9134) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), st_4})
            : ({
            auto&& other = walk_9134;
            call_then(crate::check::types::start_show_ty(st_4, other), [=](Text show_ty_10583) { return prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st_4, Text::lit("mismatch"), span_3, prism_rtl::cat("`", show_ty_10583, "` has no field `", field__2, "`"))}); });
        });
        });
    });
}


/// `Start FieldType, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_field_type(crate::check::expr::Env env, crate::check::types::St st, crate::check::types::Ty t, Text field_, crate::syntax::Range span) {
    return prism_rtl::make_rc<FieldType>(env, st, t, field_, span);
}


/// ?IndexOf: fn [Text], Text -> ?Nat
std::optional<Nat> index_of(const Array<Text>& xs, const Text& x) {
    return fold(crate::check::errors::range0(len(xs)), std::optional<Nat>{}, [&](const std::optional<Nat>& found_opt, const Nat& i) {
        return ({
            __label__ _done;
            prism_rtl::Slot<std::optional<Nat>> _v;
            if (prism_rtl::is_some(found_opt)) {
                auto&& f = prism_rtl::some_of(found_opt);
                _v.set(std::optional(f));
                goto _done;
            }
            if (prism_rtl::is_none(found_opt)) {
                _v.set(index(xs, i) == std::optional(x) ? std::optional(i) : std::optional<Nat>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
}


/// InferIndex: unbounded fn Env, St, Expr, Expr, Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_index(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Expr& recv, const crate::syntax::Expr& idx, const crate::syntax::Range& span) {
    auto [rt, st1] = crate::check::expr::infer(env, st, recv);
    auto head = crate::check::types::head_sigil(st1, rt);
    auto inner = crate::check::expr::is_time_sigil(head)
        ? crate::check::expr::inner_of(st1, rt)
        : rt;
    auto [v_, st2] = crate::check::types::fresh_var(st1, false, Text::lit(""));
    auto [k, st3] = crate::check::types::fresh_var(st2, true, Text::lit(""));
    auto coll0 = crate::check::expr::is_plain_sigil(crate::check::types::head_sigil(st3, inner))
        ? crate::check::expr::inner_of(st3, inner)
        : inner;
    auto&& _m = crate::check::types::recording::walk(st3, coll0);
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
        auto&& m11500_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
        auto&& m11500_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a1;
        if (m11500_0_0 == Text::lit("Text")) {
            if (m11500_0_1.size() == 0u) {
                return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_fix(st3, Text::lit("mismatch"), span, Text::lit("a text has no index: a position in a text is a cursor"), Text::lit("walk it with `Front` and `?Step`, or make a cursor from a byte offset with `?CursorAt`"))};
            }
        }
    }
    {
        auto [coll, key_ty] = ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::Ty>> _v;
            auto&& _m = crate::check::types::recording::walk(st3, coll0);
            if (prism_rtl::is<crate::check::types::Ty::TyMap>(_m)) {
                _v.set(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyMap{prism_rtl::rc(k), prism_rtl::rc(v_)}), k});
                goto _done;
            }
            if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
                auto&& m11793_1_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
                if (m11793_1_0 == Text::lit("Table")) {
                    _v.set(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyCon{Text::lit("Table"), Array(std::vector{k, v_})}), k});
                    goto _done;
                }
            }
            if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
                auto&& m11793_2_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
                if (m11793_2_0 == Text::lit("Buffer")) {
                    _v.set(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyCon{Text::lit("Buffer"), Array(std::vector{v_})}), crate::check::types::t_nat()});
                    goto _done;
                }
            }
            {
                _v.set(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyArray{prism_rtl::rc(v_)}), crate::check::types::t_nat()});
                goto _done;
            }
        _done:
            _v.take();
        });
        auto args = Array(std::vector{crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = recv, .span = recv.span}, crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = idx, .span = idx.span}});
        return crate::check::expr::calls::apply_rule(env, st3, Text::lit("[]"), crate::check::types::Col(crate::check::types::Col::CBound{}), Array(std::vector{coll, key_ty}), crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("?"), prism_rtl::rc(v_)}), args, span);
    }
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InferIndex::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& recv = this->recv;
    const auto& idx = this->idx;
    const auto& span = this->span;
    auto env_1 = env;
    auto idx_2 = idx;
    auto recv_3 = recv;
    auto span_4 = span;
    auto st_5 = st;
    return call_then(crate::check::expr::start_infer(env_1, st_5, recv_3), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_11119) {
        return ({
            auto [rt, st1] = infer_11119;
            call_then(crate::check::types::start_head_sigil(st1, rt), [=](Text head_sigil_11154) {
            return ({
                auto head = head_sigil_11154;
                auto inner = crate::check::expr::is_time_sigil(head)
                    ? crate::check::expr::inner_of(st1, rt)
                    : rt;
                auto [v_, st2] = crate::check::types::fresh_var(st1, false, Text::lit(""));
                auto [k, st3] = crate::check::types::fresh_var(st2, true, Text::lit(""));
                call_then(crate::check::types::start_head_sigil(st3, inner), [=](Text head_sigil_11442) {
                return ({
                    auto coll0 = crate::check::expr::is_plain_sigil(head_sigil_11442)
                        ? crate::check::expr::inner_of(st3, inner)
                        : inner;
                    call_then(crate::check::types::recording::start_walk(st3, coll0), [=](crate::check::types::Ty walk_11506) {
                    return ({
                        prism_rtl::is<crate::check::types::Ty::TyCon>(walk_11506) && ({
                        auto&& m11500_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_11506).a0;
                        auto&& m11500_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_11506).a1;
                        (m11500_0_0 == Text::lit("Text")) && (m11500_0_1.size() == 0u);
                    }) ? ({
                        auto&& m11500_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_11506).a0;
                        auto&& m11500_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_11506).a1;
                        prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_fix(st3, Text::lit("mismatch"), span_4, Text::lit("a text has no index: a position in a text is a cursor"), Text::lit("walk it with `Front` and `?Step`, or make a cursor from a byte offset with `?CursorAt`"))});
                    })
                        : call_then(crate::check::types::recording::start_walk(st3, coll0), [=](crate::check::types::Ty walk_11799) {
                        return ({
                            auto [coll, key_ty] = ({
                                __label__ _done;
                                prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::Ty>> _v;
                                if (prism_rtl::is<crate::check::types::Ty::TyMap>(walk_11799)) {
                                    _v.set(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyMap{prism_rtl::rc(k), prism_rtl::rc(v_)}), k});
                                    goto _done;
                                }
                                if (prism_rtl::is<crate::check::types::Ty::TyCon>(walk_11799)) {
                                    auto&& m11793_1_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_11799).a0;
                                    if (m11793_1_0 == Text::lit("Table")) {
                                        _v.set(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyCon{Text::lit("Table"), Array(std::vector{k, v_})}), k});
                                        goto _done;
                                    }
                                }
                                if (prism_rtl::is<crate::check::types::Ty::TyCon>(walk_11799)) {
                                    auto&& m11793_2_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_11799).a0;
                                    if (m11793_2_0 == Text::lit("Buffer")) {
                                        _v.set(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyCon{Text::lit("Buffer"), Array(std::vector{v_})}), crate::check::types::t_nat()});
                                        goto _done;
                                    }
                                }
                                {
                                    _v.set(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyArray{prism_rtl::rc(v_)}), crate::check::types::t_nat()});
                                    goto _done;
                                }
                            _done:
                                _v.take();
                            });
                            auto args = Array(std::vector{crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = recv_3, .span = prism_rtl::deref(recv_3).span}, crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = idx_2, .span = prism_rtl::deref(idx_2).span}});
                            (prism_rtl::more(prism_rtl::rc(crate::check::expr::calls::ApplyRule(env_1, st3, Text::lit("[]"), crate::check::types::Col(crate::check::types::Col::CBound{}), Array(std::vector{coll, key_ty}), crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("?"), prism_rtl::rc(v_)}), args, span_4))));
                        });
                    });
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start InferIndex, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_index(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Expr recv, crate::syntax::Expr idx, crate::syntax::Range span) {
    return prism_rtl::make_rc<InferIndex>(env, st, recv, idx, span);
}

}  // namespace crate::check::expr::operators
