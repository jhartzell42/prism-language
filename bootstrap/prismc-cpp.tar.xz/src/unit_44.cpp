// The module `Lower.Expr`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <lower/expr/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Lower.Expr`, from `target/bootstrap/cpp-src/prismc/lower/expr.prism`.
namespace crate::lower::expr {

prism_rtl::Turn<crate::lower::types::Vl> CtorFn::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& c_p1 = this->c_p1;
    const auto& pts_p2 = this->pts_p2;
    const auto& span_p3 = this->span_p3;
    const auto& t_p4 = this->t_p4;
    const auto& job_p5 = this->job_p5;
    auto names_p6 = each(crate::check::errors::range0(len(pts_p2)), [&](const Nat& i_pa) { return prism_rtl::cat("a", i_pa); });
    auto fakes_p7 = each(crate::check::errors::range0(len(pts_p2)), [&](const Nat& i_pb) { return crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EAbsent{})), .span = crate::syntax::Range{.start = *Nat::from_int(Int(4000000000ll)) + i_pb, .end = *Nat::from_int(Int(4000000000ll)) + i_pb}}, .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}}; });
    auto env_p8 = fold(crate::check::errors::range0(len(pts_p2)), crate::lower::types::empty_env(), [&](const crate::lower::types::Env& en_pc, const Nat& i_pd) {
        return crate::lower::types::bind_span(en_pc, crate::lower::place_key(lx_p0, crate::syntax::Range{.start = *Nat::from_int(Int(4000000000ll)) + i_pd, .end = *Nat::from_int(Int(4000000000ll)) + i_pd}), crate::lower::types::Vl(crate::lower::types::Vl::VlPlace{crate::lower::model::Ex(crate::lower::model::Ex::XVar{or_(index(names_p6, i_pd), Text::lit("a"))}), prism_rtl::deref(job_p5)
            ? crate::lower::types::Holding(crate::lower::types::Holding::Owned{})
            : crate::lower::types::Holding(crate::lower::types::Holding::ByRef{}), or_(index(pts_p2, i_pd), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}))}));
    });
    auto c_p1_1 = c_p1;
    auto job_p5_2 = prism_rtl::deref(job_p5);
    auto lx_p0_3 = lx_p0;
    auto pts_p2_4 = pts_p2;
    auto span_p3_5 = span_p3;
    auto t_p4_6 = t_p4;
    return call_then(start_ctor_app(lx_p0_3, env_p8, c_p1_1, fakes_p7, span_p3_5), [=](crate::lower::types::Vl ctor_app_38041) {
        return ({
            auto made_p9 = crate::lower::types::own(ctor_app_38041);
            job_p5_2
            ? ({
            auto a_pe = ({
                __label__ _done;
                prism_rtl::Slot<crate::lower::model::OutTy> _v;
                if (prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(t_p4_6)) {
                    auto&& x_pg = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(t_p4_6).a0;
                    _v.set(prism_rtl::deref(prism_rtl::deref(x_pg)));
                    goto _done;
                }
                {
                    _v.set(crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}));
                    goto _done;
                }
            _done:
                _v.take();
            });
            auto pa_pf = len(pts_p2_4) == Nat(1u)
                ? crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("a0")})), a_pe})
                : crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{each(names_p6, [&](const Text& nm_ph) { return crate::lower::model::Pa(crate::lower::model::Pa::PaBind{nm_ph}); })})), a_pe});
            (prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCast{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{pa_pf}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("once_job"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array<crate::lower::model::Pa>{}, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("prism_rtl::Turn::Finished"), Array(std::vector{made_p9})}))})})}))})})})), t_p4_6}), t_p4_6})));
        })
            : ({
            auto pas_pi = each(crate::check::errors::range0(len(pts_p2_4)), [&](const Nat& i_pj) { return crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{or_(index(names_p6, i_pj), Text::lit("a"))})), crate::lower::model::OutTy(crate::lower::model::OutTy::OutRef{prism_rtl::rc(or_(index(pts_p2_4, i_pj), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})))})}); });
            (prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{false, pas_pi, prism_rtl::rc(made_p9)})})}), t_p4_6})));
        });
        });
    });
}


/// `Start CtorFn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_ctor_fn(crate::lower::Lx lx_p0, crate::check::env::CtorInfo c_p1, Array<crate::lower::model::OutTy> pts_p2, crate::syntax::Range span_p3, crate::lower::model::OutTy t_p4, bool job_p5) {
    return prism_rtl::make_rc<CtorFn>(lx_p0, c_p1, pts_p2, span_p3, t_p4, job_p5);
}


/// IsNamedArg: fn Arg -> Bool
bool is_named_arg(const crate::syntax::Arg& a_p0) {
    auto&& _m = a_p0.name;
    if (prism_rtl::is_some(_m)) {
        return true;
    }
    if (prism_rtl::is_none(_m)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// CtorArgs: unbounded fn Lx, Env, CtorInfo, [Arg] -> [Ex]
Array<crate::lower::model::Ex> ctor_args(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::check::env::CtorInfo& c_p2, const Array<crate::syntax::Arg>& args_p3) {
    auto named_p4 = fold(args_p3, false, [&](const bool& f_p6, const crate::syntax::Arg& a_p7) { return prism_rtl::deref(f_p6) || is_named_arg(a_p7); });
    auto ordered_p5 = std::move(named_p4)
        ? each(c_p2.fields, [&](const Text& f_p8) {
        return fold(args_p3, std::optional<crate::syntax::Expr>{}, [&](const std::optional<crate::syntax::Expr>& found_o9, const crate::syntax::Arg& a_pa) {
            return ({
                __label__ _done;
                prism_rtl::Slot<std::optional<crate::syntax::Expr>> _v;
                auto&& _m = prism_rtl::deref(a_pa).name;
                if (prism_rtl::is_some(_m)) {
                    auto&& n_pb = prism_rtl::some_of(_m);
                    _v.set(prism_rtl::deref(n_pb).name == f_p8 ? std::optional(a_pa->value) : found_o9);
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(found_o9);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
        });
    })
        : each(args_p3, [&](const crate::syntax::Arg& a_pc) { return std::optional(a_pc->value); });
    return run_to_end(each_job(crate::check::errors::range0(len(ordered_p5)), ({
        auto ordered_p5_1 = ordered_p5;
        auto lx_p0_2 = lx_p0;
        auto env_p1_3 = env_p1;
        auto c_p2_4 = c_p2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(Nat)>>(prism_rtl::rc([=, ordered_p5_1 = std::move(ordered_p5_1), lx_p0_2 = std::move(lx_p0_2), env_p1_3 = std::move(env_p1_3), c_p2_4 = std::move(c_p2_4)](Nat p0) {
        return ({
            auto ordered_p5_1_5 = ordered_p5_1;
            auto lx_p0_2_5 = lx_p0_2;
            auto env_p1_3_5 = env_p1_3;
            auto c_p2_4_5 = c_p2_4;
            entered(once_job([=, ordered_p5_1_5 = std::move(ordered_p5_1_5), lx_p0_2_5 = std::move(lx_p0_2_5), env_p1_3_5 = std::move(env_p1_3_5), c_p2_4_5 = std::move(c_p2_4_5)]() {
            return ({
                auto i_pd = p0;
                ({
                auto&& _m = index(ordered_p5_1_5, i_pd);
                prism_rtl::is_some(_m) && prism_rtl::is_some(prism_rtl::some_of(_m)) ? ({
                auto&& x_pe = prism_rtl::some_of(prism_rtl::some_of(_m));
                call_then(start_value_of(lx_p0_2_5, env_p1_3_5, x_pe), [=](crate::lower::types::Vl value_of_39306) {
                return ({
                    auto v_pf = crate::lower::types::own(value_of_39306);
                    (c_p2_4_5.owner == Text::lit("Prelude.Error")) && (i_pd == Nat(0u))
                    ? prism_rtl::finished(v_pf)
                    : crate::lower::types::rc_field(lx_p0_2_5, c_p2_4_5.name, i_pd)
                    ? prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{v_pf})}))
                    : prism_rtl::finished(v_pf);
                });
            });
            })
                : prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Default::default"), Array<crate::lower::model::Ex>{}}));
            });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<Array<crate::lower::model::Ex>> CtorArgs::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& c_p2 = this->c_p2;
    const auto& args_p3 = this->args_p3;
    auto named_p4 = fold(args_p3, false, [&](const bool& f_p6, const crate::syntax::Arg& a_p7) { return prism_rtl::deref(f_p6) || is_named_arg(a_p7); });
    auto ordered_p5 = std::move(named_p4)
        ? each(prism_rtl::deref(c_p2).fields, [&](const Text& f_p8) {
        return fold(args_p3, std::optional<crate::syntax::Expr>{}, [&](const std::optional<crate::syntax::Expr>& found_o9, const crate::syntax::Arg& a_pa) {
            return ({
                __label__ _done;
                prism_rtl::Slot<std::optional<crate::syntax::Expr>> _v;
                auto&& _m = prism_rtl::deref(a_pa).name;
                if (prism_rtl::is_some(_m)) {
                    auto&& n_pb = prism_rtl::some_of(_m);
                    _v.set(prism_rtl::deref(n_pb).name == f_p8 ? std::optional(a_pa->value) : found_o9);
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(found_o9);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
        });
    })
        : each(args_p3, [&](const crate::syntax::Arg& a_pc) { return std::optional(a_pc->value); });
    return each_job(crate::check::errors::range0(len(ordered_p5)), ({
        auto ordered_p5_1 = ordered_p5;
        auto lx_p0_2 = lx_p0;
        auto env_p1_3 = env_p1;
        auto c_p2_4 = c_p2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(Nat)>>(prism_rtl::rc([=, ordered_p5_1 = std::move(ordered_p5_1), lx_p0_2 = std::move(lx_p0_2), env_p1_3 = std::move(env_p1_3), c_p2_4 = std::move(c_p2_4)](Nat p0) {
        return ({
            auto ordered_p5_1_5 = ordered_p5_1;
            auto lx_p0_2_5 = lx_p0_2;
            auto env_p1_3_5 = env_p1_3;
            auto c_p2_4_5 = c_p2_4;
            entered(once_job([=, ordered_p5_1_5 = std::move(ordered_p5_1_5), lx_p0_2_5 = std::move(lx_p0_2_5), env_p1_3_5 = std::move(env_p1_3_5), c_p2_4_5 = std::move(c_p2_4_5)]() {
            return ({
                auto i_pd = p0;
                ({
                auto&& _m = index(ordered_p5_1_5, i_pd);
                prism_rtl::is_some(_m) && prism_rtl::is_some(prism_rtl::some_of(_m)) ? ({
                auto&& x_pe = prism_rtl::some_of(prism_rtl::some_of(_m));
                call_then(start_value_of(lx_p0_2_5, env_p1_3_5, x_pe), [=](crate::lower::types::Vl value_of_39306) {
                return ({
                    auto v_pf = crate::lower::types::own(value_of_39306);
                    (prism_rtl::deref(c_p2_4_5).owner == Text::lit("Prelude.Error")) && (i_pd == Nat(0u))
                    ? prism_rtl::finished(v_pf)
                    : crate::lower::types::rc_field(lx_p0_2_5, prism_rtl::deref(c_p2_4_5).name, i_pd)
                    ? prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{v_pf})}))
                    : prism_rtl::finished(v_pf);
                });
            });
            })
                : prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Default::default"), Array<crate::lower::model::Ex>{}}));
            });
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start CtorArgs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::lower::model::Ex>> start_ctor_args(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::check::env::CtorInfo c_p2, Array<crate::syntax::Arg> args_p3) {
    return prism_rtl::make_rc<CtorArgs>(lx_p0, env_p1, c_p2, args_p3);
}


/// MethodCall: unbounded fn Lx, Env, ValInfo, [Arg], Range, OutTy -> Vl
crate::lower::types::Vl method_call(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::check::env::ValInfo& v_p2, const Array<crate::syntax::Arg>& args_p3, const crate::syntax::Range& span_p4, const crate::lower::model::OutTy& t_p5) {
    auto cls_p6 = or_(index(each(prism_rtl::deref(v_p2.scheme).bounds, [&](const std::tuple<Text, Text>& _p0) {
        auto&& c_p9 = std::get<1>(_p0);
        return c_p9;
    }), Nat(0u)), Text::lit(""));
    auto m_p7 = crate::check::types::bare_name(v_p2.qk);
    auto vals_p8 = run_to_end(each_job(args_p3, ({
        auto lx_p0_1 = lx_p0;
        auto env_p1_2 = env_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::types::Vl>(crate::syntax::Arg)>>(prism_rtl::rc([=, lx_p0_1 = std::move(lx_p0_1), env_p1_2 = std::move(env_p1_2)](crate::syntax::Arg p0) {
        return ({
            auto lx_p0_1_3 = lx_p0_1;
            auto env_p1_2_3 = env_p1_2;
            entered(once_job([=, lx_p0_1_3 = std::move(lx_p0_1_3), env_p1_2_3 = std::move(env_p1_2_3)]() {
            return ({
                auto a_pa = p0;
                (prism_rtl::more(prism_rtl::rc(ValueOf(lx_p0_1_3, env_p1_2_3, a_pa->value))));
            });
        }));
        });
    })));
    })));
    return crate::syntax::lexer::chars::has_prefix(cls_p6, Text::lit("Prelude."))
        ? prelude_method(lx_p0, cls_p6, m_p7, vals_p8, span_p4, t_p5)
        : ({
        auto tr_pb = or_(crate::prelude::get(prism_rtl::deref(lx_p0.g).traits, cls_p6), dummy_trait_info());
        auto path_pc = crate::lower::path_in(lx_p0, prism_rtl::deref(tr_pb).home, prism_rtl::cat(crate::lower::camel(crate::check::types::bare_name(cls_p6)), "::", crate::lower::snake(m_p7)));
        (crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{path_pc, run_to_end(each_job(args_p3, ({
        auto lx_p0_1 = lx_p0;
        auto env_p1_2 = env_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::Arg)>>(prism_rtl::rc([=, lx_p0_1 = std::move(lx_p0_1), env_p1_2 = std::move(env_p1_2)](crate::syntax::Arg p0) {
        return ({
            auto lx_p0_1_3 = lx_p0_1;
            auto env_p1_2_3 = env_p1_2;
            entered(once_job([=, lx_p0_1_3 = std::move(lx_p0_1_3), env_p1_2_3 = std::move(env_p1_2_3)]() {
            return ({
                auto a_pd = p0;
                (prism_rtl::more(prism_rtl::rc(Argument(lx_p0_1_3, env_p1_2_3, a_pd->value))));
            });
        }));
        });
    })));
    })))}), t_p5}));
    });
}


prism_rtl::Turn<crate::lower::types::Vl> MethodCall::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& v_p2 = this->v_p2;
    const auto& args_p3 = this->args_p3;
    const auto& span_p4 = this->span_p4;
    const auto& t_p5 = this->t_p5;
    auto cls_p6 = or_(index(each(prism_rtl::deref(prism_rtl::deref(v_p2).scheme).bounds, [&](const std::tuple<Text, Text>& _p0) {
        auto&& c_p9 = std::get<1>(_p0);
        return c_p9;
    }), Nat(0u)), Text::lit(""));
    auto m_p7 = crate::check::types::bare_name(prism_rtl::deref(v_p2).qk);
    auto args_p3_1 = args_p3;
    auto env_p1_2 = env_p1;
    auto lx_p0_3 = lx_p0;
    auto span_p4_4 = span_p4;
    auto t_p5_5 = t_p5;
    return call_value(each_job(args_p3_1, ({
        auto lx_p0_3_6 = lx_p0_3;
        auto env_p1_2_6 = env_p1_2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::types::Vl>(crate::syntax::Arg)>>(prism_rtl::rc([=, lx_p0_3_6 = std::move(lx_p0_3_6), env_p1_2_6 = std::move(env_p1_2_6)](crate::syntax::Arg p0) {
        return ({
            auto lx_p0_3_6_6 = lx_p0_3_6;
            auto env_p1_2_6_6 = env_p1_2_6;
            entered(once_job([=, lx_p0_3_6_6 = std::move(lx_p0_3_6_6), env_p1_2_6_6 = std::move(env_p1_2_6_6)]() {
            return ({
                auto a_pa = p0;
                (prism_rtl::more(prism_rtl::rc(ValueOf(lx_p0_3_6_6, env_p1_2_6_6, a_pa->value))));
            });
        }));
        });
    })));
    })), [=](Array<crate::lower::types::Vl> each_39933) {
        return ({
            auto vals_p8 = each_39933;
            (crate::syntax::lexer::chars::has_prefix(cls_p6, Text::lit("Prelude."))
            ? prism_rtl::more(prism_rtl::rc(PreludeMethod(lx_p0_3, cls_p6, m_p7, vals_p8, span_p4_4, t_p5_5)))
            : ({
            auto tr_pb = or_(crate::prelude::get(prism_rtl::deref(prism_rtl::deref(lx_p0_3).g).traits, cls_p6), dummy_trait_info());
            auto path_pc = crate::lower::path_in(lx_p0_3, prism_rtl::deref(tr_pb).home, prism_rtl::cat(crate::lower::camel(crate::check::types::bare_name(cls_p6)), "::", crate::lower::snake(m_p7)));
            call_value(each_job(args_p3_1, ({
            auto lx_p0_3_6 = lx_p0_3;
            auto env_p1_2_6 = env_p1_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::Arg)>>(prism_rtl::rc([=, lx_p0_3_6 = std::move(lx_p0_3_6), env_p1_2_6 = std::move(env_p1_2_6)](crate::syntax::Arg p0) {
            return ({
                auto lx_p0_3_6_6 = lx_p0_3_6;
                auto env_p1_2_6_6 = env_p1_2_6;
                entered(once_job([=, lx_p0_3_6_6 = std::move(lx_p0_3_6_6), env_p1_2_6_6 = std::move(env_p1_2_6_6)]() {
                return ({
                    auto a_pd = p0;
                    (prism_rtl::more(prism_rtl::rc(Argument(lx_p0_3_6_6, env_p1_2_6_6, a_pd->value))));
                });
            }));
            });
        })));
        })), [=, path_pc = std::move(path_pc)](Array<crate::lower::model::Ex> each_40218) { return prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{path_pc, each_40218}), t_p5_5})); });
        }));
        });
    });
}


/// `Start MethodCall, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_method_call(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::check::env::ValInfo v_p2, Array<crate::syntax::Arg> args_p3, crate::syntax::Range span_p4, crate::lower::model::OutTy t_p5) {
    return prism_rtl::make_rc<MethodCall>(lx_p0, env_p1, v_p2, args_p3, span_p4, t_p5);
}


/// let dummyTraitInfo
crate::check::env::TraitInfo dummy_trait_info() {
    return crate::check::env::TraitInfo{.name = Text::lit(""), .home = Text::lit(""), .param = Text::lit("a"), .supers = Array<Text>{}, .methods = Array<Text>{}, .defaults = Array<Text>{}, .assocs = Array<Text>{}, .file = Nat(0u), .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}};
}


/// PreludeMethod: unbounded fn Lx, Text, Text, [Vl], Range, OutTy -> Vl
crate::lower::types::Vl prelude_method(const crate::lower::Lx& lx_p0, const Text& cls_p1, const Text& m_p2, const Array<crate::lower::types::Vl>& vals_p3, const crate::syntax::Range& span_p4, const crate::lower::model::OutTy& t_p5) {
    auto a_p6 = or_(index(vals_p3, Nat(0u)), crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})}));
    auto b_p7 = or_(index(vals_p3, Nat(1u)), crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})}));
    {
        auto&& m40637_0 = m_p2;
        if (m40637_0 == Text::lit("Show")) {
            return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("show_text"), Array(std::vector{crate::lower::types::ref_(a_p6)})}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutText{})});
        }
    }
    {
        auto&& m40637_1 = m_p2;
        if (m40637_1 == Text::lit("Compare")) {
            return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("compare"), Array(std::vector{crate::lower::types::ref_(a_p6), crate::lower::types::ref_(b_p7)})}), t_p5});
        }
    }
    {
        auto&& m40637_2 = m_p2;
        if (m40637_2 == Text::lit("Children")) {
            return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("children"), Array(std::vector{crate::lower::types::ref_(a_p6)})}), t_p5});
        }
    }
    {
        return op_value(lx_p0, m_p2, a_p6, b_p7, span_p4, t_p5);
    }
}


prism_rtl::Turn<crate::lower::types::Vl> PreludeMethod::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& cls_p1 = this->cls_p1;
    const auto& m_p2 = this->m_p2;
    const auto& vals_p3 = this->vals_p3;
    const auto& span_p4 = this->span_p4;
    const auto& t_p5 = this->t_p5;
    auto a_p6 = or_(index(vals_p3, Nat(0u)), crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})}));
    auto b_p7 = or_(index(vals_p3, Nat(1u)), crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})}));
    return ({
        ({
        auto&& m40637_0 = m_p2;
        (m40637_0 == Text::lit("Show"));
    }) ? ({
        auto&& m40637_0 = m_p2;
        prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("show_text"), Array(std::vector{crate::lower::types::ref_(a_p6)})}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutText{})}));
    })
        : ({
        auto&& m40637_1 = m_p2;
        (m40637_1 == Text::lit("Compare"));
    }) ? ({
        auto&& m40637_1 = m_p2;
        prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("compare"), Array(std::vector{crate::lower::types::ref_(a_p6), crate::lower::types::ref_(b_p7)})}), t_p5}));
    })
        : ({
        auto&& m40637_2 = m_p2;
        (m40637_2 == Text::lit("Children"));
    }) ? ({
        auto&& m40637_2 = m_p2;
        prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("children"), Array(std::vector{crate::lower::types::ref_(a_p6)})}), t_p5}));
    })
        : prism_rtl::finished(op_value(lx_p0, m_p2, a_p6, b_p7, span_p4, t_p5));
    });
}


/// `Start PreludeMethod, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_prelude_method(crate::lower::Lx lx_p0, Text cls_p1, Text m_p2, Array<crate::lower::types::Vl> vals_p3, crate::syntax::Range span_p4, crate::lower::model::OutTy t_p5) {
    return prism_rtl::make_rc<PreludeMethod>(lx_p0, cls_p1, m_p2, vals_p3, span_p4, t_p5);
}


/// BinaryValue: unbounded fn Lx, Env, Text, Expr, Expr, Range -> Vl
crate::lower::types::Vl binary_value(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const Text& op_p2, const crate::syntax::Expr& l_p3, const crate::syntax::Expr& r_p4, const crate::syntax::Range& span_p5) {
    auto t_p6 = crate::lower::types::out_ty_of(lx_p0, crate::lower::types::peel(crate::lower::type_at(lx_p0, span_p5)));
    {
        auto&& m41065_0 = op_p2;
        if (m41065_0 == Text::lit("and")) {
            return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBin{Text::lit("&&"), prism_rtl::rc(crate::lower::types::as_bool(value_of(lx_p0, env_p1, l_p3))), prism_rtl::rc(crate::lower::types::as_bool(value_of(lx_p0, env_p1, r_p4)))}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutBool{})});
        }
    }
    {
        auto&& m41065_1 = op_p2;
        if (m41065_1 == Text::lit("or")) {
            return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBin{Text::lit("||"), prism_rtl::rc(crate::lower::types::as_bool(value_of(lx_p0, env_p1, l_p3))), prism_rtl::rc(crate::lower::types::as_bool(value_of(lx_p0, env_p1, r_p4)))}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutBool{})});
        }
    }
    {
        auto&& m41065_2 = op_p2;
        if (m41065_2 == Text::lit("on")) {
            return value_of(lx_p0, env_p1, l_p3);
        }
    }
    {
        return op_value(lx_p0, op_p2, value_of(lx_p0, env_p1, l_p3), value_of(lx_p0, env_p1, r_p4), span_p5, t_p6);
    }
}


prism_rtl::Turn<crate::lower::types::Vl> BinaryValue::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& op_p2 = this->op_p2;
    const auto& l_p3 = this->l_p3;
    const auto& r_p4 = this->r_p4;
    const auto& span_p5 = this->span_p5;
    auto env_p1_1 = env_p1;
    auto l_p3_2 = l_p3;
    auto lx_p0_3 = lx_p0;
    auto op_p2_4 = op_p2;
    auto r_p4_5 = r_p4;
    auto span_p5_6 = span_p5;
    return call_then(crate::lower::types::start_out_ty_of(lx_p0_3, crate::lower::types::peel(crate::lower::type_at(lx_p0_3, span_p5_6))), [=](crate::lower::model::OutTy out_ty_of_41024) {
        return ({
            auto t_p6 = out_ty_of_41024;
            ({
            ({
            auto&& m41065_0 = op_p2_4;
            (m41065_0 == Text::lit("and"));
        }) ? ({
            auto&& m41065_0 = op_p2_4;
            call_then(start_value_of(lx_p0_3, env_p1_1, l_p3_2), [=](crate::lower::types::Vl value_of_41119) { return call_then(start_value_of(lx_p0_3, env_p1_1, r_p4_5), [=](crate::lower::types::Vl value_of_41150) { return prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBin{Text::lit("&&"), prism_rtl::rc(crate::lower::types::as_bool(value_of_41119)), prism_rtl::rc(crate::lower::types::as_bool(value_of_41150))}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutBool{})})); }); });
        })
            : ({
            auto&& m41065_1 = op_p2_4;
            (m41065_1 == Text::lit("or"));
        }) ? ({
            auto&& m41065_1 = op_p2_4;
            call_then(start_value_of(lx_p0_3, env_p1_1, l_p3_2), [=](crate::lower::types::Vl value_of_41224) { return call_then(start_value_of(lx_p0_3, env_p1_1, r_p4_5), [=](crate::lower::types::Vl value_of_41255) { return prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBin{Text::lit("||"), prism_rtl::rc(crate::lower::types::as_bool(value_of_41224)), prism_rtl::rc(crate::lower::types::as_bool(value_of_41255))}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutBool{})})); }); });
        })
            : ({
            auto&& m41065_2 = op_p2_4;
            (m41065_2 == Text::lit("on"));
        }) ? ({
            auto&& m41065_2 = op_p2_4;
            prism_rtl::more(prism_rtl::rc(ValueOf(lx_p0_3, env_p1_1, l_p3_2)));
        })
            : call_then(start_value_of(lx_p0_3, env_p1_1, l_p3_2), [=, t_p6 = std::move(t_p6)](crate::lower::types::Vl value_of_41521) { return call_then(start_value_of(lx_p0_3, env_p1_1, r_p4_5), [=](crate::lower::types::Vl value_of_41543) { return prism_rtl::finished(op_value(lx_p0_3, op_p2_4, value_of_41521, value_of_41543, span_p5_6, t_p6)); }); });
        });
        });
    });
}


/// `Start BinaryValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_binary_value(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, Text op_p2, crate::syntax::Expr l_p3, crate::syntax::Expr r_p4, crate::syntax::Range span_p5) {
    return prism_rtl::make_rc<BinaryValue>(lx_p0, env_p1, op_p2, l_p3, r_p4, span_p5);
}


/// OpValue: fn Lx, Text, Vl, Vl, Range, OutTy -> Vl
crate::lower::types::Vl op_value(const crate::lower::Lx& lx_p0, const Text& op_p1, const crate::lower::types::Vl& a_p2, const crate::lower::types::Vl& b_p3, const crate::syntax::Range& span_p4, const crate::lower::model::OutTy& t_p5) {
    auto at_p6 = crate::lower::types::value_ty(a_p2);
    auto generic_p7 = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        if (prism_rtl::is<crate::lower::model::OutTy::OutGen>(at_p6)) {
            _v.set(true);
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
    return crate::check::types::has_text(Array(std::vector{Text::lit("=="), Text::lit("!="), Text::lit("<"), Text::lit("<="), Text::lit(">"), Text::lit(">=")}), op_p1)
        ? crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBin{op_p1, prism_rtl::rc(crate::lower::types::ref_(a_p2)), prism_rtl::rc(crate::lower::types::ref_(b_p3))}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutBool{})})
        : op_p1 == Text::lit("mod")
        ? crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::types::ref_(a_p2)), Text::lit("modulo"), Array(std::vector{crate::lower::types::ref_(b_p3)})}), t_p5})
        : std::move(generic_p7)
        ? crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{prism_rtl::cat("Num::", num_method(op_p1)), Array(std::vector{crate::lower::types::ref_(a_p2), crate::lower::types::ref_(b_p3)})}), t_p5})
        : op_p1 == Text::lit("/")
        ? at_p6 == crate::lower::model::OutTy(crate::lower::model::OutTy::OutFloat{})
        ? crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBin{Text::lit("/"), prism_rtl::rc(crate::lower::types::copy(a_p2)), prism_rtl::rc(crate::lower::types::copy(b_p3))}), t_p5})
        : crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::types::ref_(a_p2)), Text::lit("div"), Array(std::vector{crate::lower::types::ref_(b_p3)})}), t_p5})
        : op_p1 == Text::lit("-?")
        ? at_p6 == crate::lower::model::OutTy(crate::lower::model::OutTy::OutNat{})
        ? crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::types::ref_(a_p2)), Text::lit("checked_sub"), Array(std::vector{crate::lower::types::ref_(b_p3)})}), t_p5})
        : crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XBin{Text::lit("-"), prism_rtl::rc(crate::lower::types::ref_(a_p2)), prism_rtl::rc(crate::lower::types::ref_(b_p3))})})}), t_p5})
        : op_p1 == Text::lit("+?")
        ? crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XBin{Text::lit("+"), prism_rtl::rc(crate::lower::types::ref_(a_p2)), prism_rtl::rc(crate::lower::types::ref_(b_p3))})})}), t_p5})
        : op_p1 == Text::lit("*?")
        ? crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XBin{Text::lit("*"), prism_rtl::rc(crate::lower::types::ref_(a_p2)), prism_rtl::rc(crate::lower::types::ref_(b_p3))})})}), t_p5})
        : crate::lower::types::is_copy(at_p6)
        ? crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBin{op_p1, prism_rtl::rc(crate::lower::types::copy(a_p2)), prism_rtl::rc(crate::lower::types::copy(b_p3))}), t_p5})
        : crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBin{op_p1, prism_rtl::rc(crate::lower::types::ref_(a_p2)), prism_rtl::rc(crate::lower::types::ref_(b_p3))}), t_p5});
}


/// NumMethod: fn Text -> Text
Text num_method(const Text& text0) {
    {
        auto&& c0_0 = text0;
        if (c0_0 == Text::lit("+")) {
            return Text::lit("add");
        }
    }
    {
        auto&& c1_0 = text0;
        if (c1_0 == Text::lit("-")) {
            return Text::lit("sub");
        }
    }
    {
        auto&& c2_0 = text0;
        if (c2_0 == Text::lit("*")) {
            return Text::lit("mul");
        }
    }
    {
        auto&& c3_0 = text0;
        if (c3_0 == Text::lit("/")) {
            return Text::lit("div_opt");
        }
    }
    {
        auto&& c4_0 = text0;
        if (c4_0 == Text::lit("+?")) {
            return Text::lit("add_opt");
        }
    }
    {
        auto&& c5_0 = text0;
        if (c5_0 == Text::lit("-?")) {
            return Text::lit("sub_opt");
        }
    }
    {
        auto&& c6_0 = text0;
        if (c6_0 == Text::lit("*?")) {
            return Text::lit("mul_opt");
        }
    }
    {
        auto&& other_p0 = text0;
        return Text::lit("add");
    }
}


/// PreludeCall: unbounded fn Lx, Env, Text, [Arg], Range, OutTy -> Vl
crate::lower::types::Vl prelude_call(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const Text& qk_p2, const Array<crate::syntax::Arg>& args_p3, const crate::syntax::Range& span_p4, const crate::lower::model::OutTy& t_p5) {
    auto name_p6 = or_(crate::prelude::get(lx_p0.rs_names, qk_p2), crate::lower::snake(crate::check::types::bare_name(qk_p2)));
    auto first_p7 = ({
        __label__ _done;
        prism_rtl::Slot<crate::lower::model::OutTy> _v;
        auto&& _m = index(args_p3, Nat(0u));
        if (prism_rtl::is_some(_m)) {
            auto&& a_p9 = prism_rtl::some_of(_m);
            _v.set(crate::lower::types::out_ty_of(lx_p0, crate::lower::types::peel(crate::lower::type_at(lx_p0, prism_rtl::deref(a_p9->value).span))));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto variant_p8 = prelude_variant(name_p6, first_p7);
    auto&& _m = prelude_job(lx_p0, env_p1, variant_p8, args_p3);
    if (prism_rtl::is_some(_m)) {
        auto&& job_pa = prism_rtl::some_of(_m);
        return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("run_to_end"), Array(std::vector{job_pa})}), t_p5});
    }
    if (prism_rtl::is_none(_m)) {
        return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{crate::lower::prelude_path(lx_p0, variant_p8), run_to_end(each_job(args_p3, ({
            auto lx_p0_1 = lx_p0;
            auto env_p1_2 = env_p1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::Arg)>>(prism_rtl::rc([=, lx_p0_1 = std::move(lx_p0_1), env_p1_2 = std::move(env_p1_2)](crate::syntax::Arg p0) {
            return ({
                auto lx_p0_1_3 = lx_p0_1;
                auto env_p1_2_3 = env_p1_2;
                entered(once_job([=, lx_p0_1_3 = std::move(lx_p0_1_3), env_p1_2_3 = std::move(env_p1_2_3)]() {
                return ({
                    auto a_pb = p0;
                    (prism_rtl::more(prism_rtl::rc(Argument(lx_p0_1_3, env_p1_2_3, a_pb->value))));
                });
            }));
            });
        })));
        })))}), t_p5});
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::lower::types::Vl> PreludeCall::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& qk_p2 = this->qk_p2;
    const auto& args_p3 = this->args_p3;
    const auto& span_p4 = this->span_p4;
    const auto& t_p5 = this->t_p5;
    auto name_p6 = or_(crate::prelude::get(prism_rtl::deref(lx_p0).rs_names, qk_p2), crate::lower::snake(crate::check::types::bare_name(qk_p2)));
    auto first_p7 = ({
        __label__ _done;
        prism_rtl::Slot<crate::lower::model::OutTy> _v;
        auto&& _m = index(args_p3, Nat(0u));
        if (prism_rtl::is_some(_m)) {
            auto&& a_p9 = prism_rtl::some_of(_m);
            _v.set(crate::lower::types::out_ty_of(lx_p0, crate::lower::types::peel(crate::lower::type_at(lx_p0, prism_rtl::deref(a_p9->value).span))));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto variant_p8 = prelude_variant(name_p6, first_p7);
    auto args_p3_1 = args_p3;
    auto env_p1_2 = env_p1;
    auto lx_p0_3 = lx_p0;
    auto t_p5_4 = t_p5;
    return call_then(start_prelude_job(lx_p0_3, env_p1_2, variant_p8, args_p3_1), [=](std::optional<crate::lower::model::Ex> prelude_job_43557) {
        return ({
            prism_rtl::is_some(prelude_job_43557) ? ({
            auto&& job_pa = prism_rtl::some_of(prelude_job_43557);
            prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("run_to_end"), Array(std::vector{job_pa})}), t_p5_4}));
        })
            : prism_rtl::is_none(prelude_job_43557) ? call_value(each_job(args_p3_1, ({
            auto lx_p0_3_5 = lx_p0_3;
            auto env_p1_2_5 = env_p1_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::Arg)>>(prism_rtl::rc([=, lx_p0_3_5 = std::move(lx_p0_3_5), env_p1_2_5 = std::move(env_p1_2_5)](crate::syntax::Arg p0) {
            return ({
                auto lx_p0_3_5_5 = lx_p0_3_5;
                auto env_p1_2_5_5 = env_p1_2_5;
                entered(once_job([=, lx_p0_3_5_5 = std::move(lx_p0_3_5_5), env_p1_2_5_5 = std::move(env_p1_2_5_5)]() {
                return ({
                    auto a_pb = p0;
                    (prism_rtl::more(prism_rtl::rc(Argument(lx_p0_3_5_5, env_p1_2_5_5, a_pb->value))));
                });
            }));
            });
        })));
        })), [=](Array<crate::lower::model::Ex> each_43705) { return prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{crate::lower::prelude_path(lx_p0_3, variant_p8), each_43705}), t_p5_4})); })
            : throw prism_rtl::Panic("no arm matched");
        });
    });
}


/// `Start PreludeCall, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_prelude_call(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, Text qk_p2, Array<crate::syntax::Arg> args_p3, crate::syntax::Range span_p4, crate::lower::model::OutTy t_p5) {
    return prism_rtl::make_rc<PreludeCall>(lx_p0, env_p1, qk_p2, args_p3, span_p4, t_p5);
}


/// ?PreludeJob: unbounded fn Lx, Env, Text, [Arg] -> ?Ex
std::optional<crate::lower::model::Ex> prelude_job(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const Text& variant_p2, const Array<crate::syntax::Arg>& args_p3) {
    return crate::check::types::has_text(Array(std::vector{Text::lit("fold"), Text::lit("fold_map"), Text::lit("each"), Text::lit("each_map"), Text::lit("filter"), Text::lit("filter_map")}), variant_p2)
        ? ({
        auto last_p4 = or_(index(args_p3, crate::syntax::lexer::chars::dec(len(args_p3))), crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = dummy_expr(), .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}});
        ({
        __label__ _done;
        prism_rtl::Slot<std::optional<crate::lower::model::Ex>> _v;
        auto&& _m = crate::lower::types::out_ty_of(lx_p0, crate::lower::types::peel(crate::lower::type_at(lx_p0, prism_rtl::deref(last_p4->value).span)));
        if (prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(_m)) {
            _v.set(({
                auto front_p5 = run_to_end(each_job(take(args_p3, crate::syntax::lexer::chars::dec(len(args_p3))), ({
                    auto lx_p0_1 = lx_p0;
                    auto env_p1_2 = env_p1;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::Arg)>>(prism_rtl::rc([=, lx_p0_1 = std::move(lx_p0_1), env_p1_2 = std::move(env_p1_2)](crate::syntax::Arg p0) {
                    return ({
                        auto lx_p0_1_3 = lx_p0_1;
                        auto env_p1_2_3 = env_p1_2;
                        entered(once_job([=, lx_p0_1_3 = std::move(lx_p0_1_3), env_p1_2_3 = std::move(env_p1_2_3)]() {
                        return ({
                            auto a_p6 = p0;
                            call_then(start_value_of(lx_p0_1_3, env_p1_2_3, a_p6->value), [=](crate::lower::types::Vl value_of_44571) { return prism_rtl::finished(crate::lower::types::own(value_of_44571)); });
                        });
                    }));
                    });
                })));
                })));
                (std::optional(crate::lower::model::Ex(crate::lower::model::Ex::XCall{prism_rtl::cat(variant_p2, "_job"), crate::prelude::push(front_p5, as_job_value(lx_p0, env_p1, last_p4->value))})));
            }));
            goto _done;
        }
        {
            _v.set(std::optional<crate::lower::model::Ex>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    })
        : std::optional<crate::lower::model::Ex>{};
}


prism_rtl::Turn<std::optional<crate::lower::model::Ex>> PreludeJob::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& variant_p2 = this->variant_p2;
    const auto& args_p3 = this->args_p3;
    return crate::check::types::has_text(Array(std::vector{Text::lit("fold"), Text::lit("fold_map"), Text::lit("each"), Text::lit("each_map"), Text::lit("filter"), Text::lit("filter_map")}), variant_p2)
        ? ({
        auto last_p4 = or_(index(args_p3, crate::syntax::lexer::chars::dec(len(args_p3))), crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = dummy_expr(), .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}});
        auto args_p3_1 = args_p3;
        auto env_p1_2 = env_p1;
        auto lx_p0_3 = lx_p0;
        auto variant_p2_4 = variant_p2;
        call_then(crate::lower::types::start_out_ty_of(lx_p0_3, crate::lower::types::peel(crate::lower::type_at(lx_p0_3, prism_rtl::deref(last_p4->value).span))), [=, args_p3_1 = std::move(args_p3_1), env_p1_2 = std::move(env_p1_2), variant_p2_4 = std::move(variant_p2_4)](crate::lower::model::OutTy out_ty_of_44411) {
        return ({
            prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(out_ty_of_44411) ? call_value(each_job(take(args_p3_1, crate::syntax::lexer::chars::dec(len(args_p3_1))), ({
            auto lx_p0_3_5 = lx_p0_3;
            auto env_p1_2_5 = env_p1_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::Arg)>>(prism_rtl::rc([=, lx_p0_3_5 = std::move(lx_p0_3_5), env_p1_2_5 = std::move(env_p1_2_5)](crate::syntax::Arg p0) {
            return ({
                auto lx_p0_3_5_5 = lx_p0_3_5;
                auto env_p1_2_5_5 = env_p1_2_5;
                entered(once_job([=, lx_p0_3_5_5 = std::move(lx_p0_3_5_5), env_p1_2_5_5 = std::move(env_p1_2_5_5)]() {
                return ({
                    auto a_p6 = p0;
                    call_then(start_value_of(lx_p0_3_5_5, env_p1_2_5_5, a_p6->value), [=](crate::lower::types::Vl value_of_44571) { return prism_rtl::finished(crate::lower::types::own(value_of_44571)); });
                });
            }));
            });
        })));
        })), [=](Array<crate::lower::model::Ex> each_44525) {
            return ({
                auto front_p5 = each_44525;
                (prism_rtl::finished(std::optional(crate::lower::model::Ex(crate::lower::model::Ex::XCall{prism_rtl::cat(variant_p2_4, "_job"), crate::prelude::push(front_p5, as_job_value(lx_p0_3, env_p1_2, last_p4->value))}))));
            });
        })
            : prism_rtl::finished(std::optional<crate::lower::model::Ex>{});
        });
    });
    })
        : prism_rtl::finished(std::optional<crate::lower::model::Ex>{});
}


/// `Start PreludeJob, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<crate::lower::model::Ex>> start_prelude_job(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, Text variant_p2, Array<crate::syntax::Arg> args_p3) {
    return prism_rtl::make_rc<PreludeJob>(lx_p0, env_p1, variant_p2, args_p3);
}


/// ?PreludeJobCall: unbounded fn Lx, Env, Expr -> ?Ex
std::optional<crate::lower::model::Ex> prelude_job_call(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& e_p2) {
    auto&& _m = prism_rtl::deref(e_p2.kind);
    if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
        auto&& c_p3 = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
        auto&& args_p4 = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
        auto&& _m = prism_rtl::deref(prism_rtl::deref(c_p3).kind);
        if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
            auto&& n_p5 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
            return (len(n_p5->path_) == Nat(1u)) && crate::check::env::has_key(env_p1.names, crate::check::env::sname_key(n_p5))
                ? std::optional<crate::lower::model::Ex>{}
                : ({
                auto&& _qk_o6 = crate::check::env::names::resolve_value(lx_p0.g, lx_p0.home, n_p5);
                auto&& qk_o6 = std::get<0>(_qk_o6);
                ({
                __label__ _done;
                prism_rtl::Slot<std::optional<crate::lower::model::Ex>> _v;
                if (prism_rtl::is_some(qk_o6)) {
                    auto&& qk_p7 = prism_rtl::some_of(qk_o6);
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<std::optional<crate::lower::model::Ex>> _v;
                        auto&& _m = crate::prelude::get(prism_rtl::deref(lx_p0.g).vals, qk_p7);
                        if (prism_rtl::is_some(_m)) {
                            auto&& v_p8 = prism_rtl::some_of(_m);
                            _v.set(prism_rtl::deref(v_p8).home == Text::lit("Prelude")
                                ? ({
                                auto name_p9 = or_(crate::prelude::get(lx_p0.rs_names, qk_p7), crate::lower::snake(crate::check::types::bare_name(qk_p7)));
                                auto first_pa = ({
                                    __label__ _done;
                                    prism_rtl::Slot<crate::lower::model::OutTy> _v;
                                    auto&& _m = index(args_p4, Nat(0u));
                                    if (prism_rtl::is_some(_m)) {
                                        auto&& a_pb = prism_rtl::some_of(_m);
                                        _v.set(crate::lower::types::out_ty_of(lx_p0, crate::lower::types::peel(crate::lower::type_at(lx_p0, prism_rtl::deref(a_pb->value).span))));
                                        goto _done;
                                    }
                                    if (prism_rtl::is_none(_m)) {
                                        _v.set(crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}));
                                        goto _done;
                                    }
                                    prism_rtl::unreachable("no arm matched");
                                _done:
                                    _v.take();
                                });
                                prelude_job(lx_p0, env_p1, prelude_variant(name_p9, first_pa), args_p4);
                            })
                                : std::optional<crate::lower::model::Ex>{});
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(std::optional<crate::lower::model::Ex>{});
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(qk_o6)) {
                    _v.set(std::optional<crate::lower::model::Ex>{});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            });
        }
        {
            return std::optional<crate::lower::model::Ex>{};
        }
    }
    {
        return std::optional<crate::lower::model::Ex>{};
    }
}


prism_rtl::Turn<std::optional<crate::lower::model::Ex>> PreludeJobCall::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& e_p2 = this->e_p2;
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p2).kind);
        prism_rtl::is<crate::syntax::ExprKind::ECall>(_m) ? ({
        auto&& c_p3 = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
        auto&& args_p4 = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
        ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(c_p3).kind);
        prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? ({
        auto&& n_p5 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        (len(n_p5->path_) == Nat(1u)) && crate::check::env::has_key(env_p1->names, crate::check::env::sname_key(n_p5))
        ? prism_rtl::finished(std::optional<crate::lower::model::Ex>{})
        : ({
        auto&& _qk_o6 = crate::check::env::names::resolve_value(prism_rtl::deref(lx_p0).g, prism_rtl::deref(lx_p0).home, n_p5);
        auto&& qk_o6 = std::get<0>(_qk_o6);
        ({
        prism_rtl::is_some(qk_o6) ? ({
        auto&& qk_p7 = prism_rtl::some_of(qk_o6);
        ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(prism_rtl::deref(lx_p0).g).vals, qk_p7);
        prism_rtl::is_some(_m) ? ({
        auto&& v_p8 = prism_rtl::some_of(_m);
        prism_rtl::deref(v_p8).home == Text::lit("Prelude")
        ? ({
        auto name_p9 = or_(crate::prelude::get(prism_rtl::deref(lx_p0).rs_names, qk_p7), crate::lower::snake(crate::check::types::bare_name(qk_p7)));
        auto first_pa = ({
            __label__ _done;
            prism_rtl::Slot<crate::lower::model::OutTy> _v;
            auto&& _m = index(args_p4, Nat(0u));
            if (prism_rtl::is_some(_m)) {
                auto&& a_pb = prism_rtl::some_of(_m);
                _v.set(crate::lower::types::out_ty_of(lx_p0, crate::lower::types::peel(crate::lower::type_at(lx_p0, prism_rtl::deref(a_pb->value).span))));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        (prism_rtl::more(prism_rtl::rc(PreludeJob(lx_p0, env_p1, prelude_variant(name_p9, first_pa), args_p4))));
    })
        : prism_rtl::finished(std::optional<crate::lower::model::Ex>{});
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(std::optional<crate::lower::model::Ex>{})
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : prism_rtl::is_none(qk_o6) ? prism_rtl::finished(std::optional<crate::lower::model::Ex>{})
        : throw prism_rtl::Panic("no arm matched");
    });
    });
    })
        : prism_rtl::finished(std::optional<crate::lower::model::Ex>{});
    });
    })
        : prism_rtl::finished(std::optional<crate::lower::model::Ex>{});
    });
}


/// `Start PreludeJobCall, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<crate::lower::model::Ex>> start_prelude_job_call(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr e_p2) {
    return prism_rtl::make_rc<PreludeJobCall>(lx_p0, env_p1, e_p2);
}


/// AsJobValue: unbounded fn Lx, Env, Expr -> Ex
crate::lower::model::Ex as_job_value(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& e_p2) {
    auto&& _m = prism_rtl::deref(e_p2.kind);
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x_p3 = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return as_job_value(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(x_p3)));
    }
    {
        auto target_p4 = ({
            __label__ _done;
            prism_rtl::Slot<crate::lower::model::OutTy> _v;
            auto&& _m = crate::lower::types::peel(crate::lower::type_at(lx_p0, e_p2.span));
            if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
                auto&& ps_p6 = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a1;
                auto&& r_p7 = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a2;
                _v.set(crate::lower::model::OutTy(crate::lower::model::OutTy::OutJobFn{prism_rtl::rc(crate::lower::types::rust_ty_of_params(lx_p0, ps_p6)), prism_rtl::rc(crate::lower::types::out_ty_of(lx_p0, prism_rtl::deref(r_p7)))}));
                goto _done;
            }
            {
                auto&& other_p8 = _m;
                _v.set(crate::lower::types::out_ty_of(lx_p0, other_p8));
                goto _done;
            }
        _done:
            _v.take();
        });
        auto a_p5 = ({
            __label__ _done;
            prism_rtl::Slot<crate::lower::model::OutTy> _v;
            if (prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(target_p4)) {
                auto&& x_p9 = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(target_p4).a0;
                _v.set(prism_rtl::deref(prism_rtl::deref(x_p9)));
                goto _done;
            }
            {
                _v.set(crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}));
                goto _done;
            }
        _done:
            _v.take();
        });
        auto&& _m = prism_rtl::deref(e_p2.kind);
        if (prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m)) {
            auto&& ps_oa = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0;
            auto&& body_pb = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a1;
            return crate::lower::types::own(job_lambda(lx_p0, env_p1, or_(ps_oa, Array<crate::syntax::Pattern_>{}), prism_rtl::deref(prism_rtl::deref(body_pb)), target_p4, a_p5, enters_lambda(lx_p0, e_p2)));
        }
        {
            auto v_pc = value_of(lx_p0, env_p1, e_p2);
            auto&& _m = crate::lower::types::value_ty(v_pc);
            if (prism_rtl::is<crate::lower::model::OutTy::OutFn>(_m)) {
                auto&& pts_pd = prism_rtl::as<crate::lower::model::OutTy::OutFn>(_m).a0;
                return wrap_as_job(crate::lower::types::own(v_pc), pts_pd, target_p4, a_p5);
            }
            {
                return crate::lower::types::own(v_pc);
            }
        }
    }
}


prism_rtl::Turn<crate::lower::model::Ex> AsJobValue::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& e_p2 = this->e_p2;
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p2).kind);
        prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
        auto&& x_p3 = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(AsJobValue(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(x_p3)))));
    })
        : ({
        auto target_p4 = ({
            __label__ _done;
            prism_rtl::Slot<crate::lower::model::OutTy> _v;
            auto&& _m = crate::lower::types::peel(crate::lower::type_at(lx_p0, prism_rtl::deref(e_p2).span));
            if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
                auto&& ps_p6 = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a1;
                auto&& r_p7 = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a2;
                _v.set(crate::lower::model::OutTy(crate::lower::model::OutTy::OutJobFn{prism_rtl::rc(crate::lower::types::rust_ty_of_params(lx_p0, ps_p6)), prism_rtl::rc(crate::lower::types::out_ty_of(lx_p0, prism_rtl::deref(r_p7)))}));
                goto _done;
            }
            {
                auto&& other_p8 = _m;
                _v.set(crate::lower::types::out_ty_of(lx_p0, other_p8));
                goto _done;
            }
        _done:
            _v.take();
        });
        auto a_p5 = ({
            __label__ _done;
            prism_rtl::Slot<crate::lower::model::OutTy> _v;
            if (prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(target_p4)) {
                auto&& x_p9 = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(target_p4).a0;
                _v.set(prism_rtl::deref(prism_rtl::deref(x_p9)));
                goto _done;
            }
            {
                _v.set(crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}));
                goto _done;
            }
        _done:
            _v.take();
        });
        ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p2).kind);
        prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m) ? ({
        auto&& ps_oa = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0;
        auto&& body_pb = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a1;
        ({
        auto ps_oa_1 = ps_oa;
        auto body_pb_2 = prism_rtl::deref(prism_rtl::deref(body_pb));
        auto e_p2_3 = e_p2;
        auto env_p1_4 = env_p1;
        auto lx_p0_5 = lx_p0;
        call_then(start_job_lambda(lx_p0_5, env_p1_4, or_(ps_oa_1, Array<crate::syntax::Pattern_>{}), body_pb_2, target_p4, a_p5, enters_lambda(lx_p0_5, e_p2_3)), [=](crate::lower::types::Vl job_lambda_46460) { return prism_rtl::finished(crate::lower::types::own(job_lambda_46460)); });
    });
    })
        : ({
        auto e_p2_1 = e_p2;
        auto env_p1_2 = env_p1;
        auto lx_p0_3 = lx_p0;
        call_then(start_value_of(lx_p0_3, env_p1_2, e_p2_1), [=](crate::lower::types::Vl value_of_46581) {
        return ({
            auto v_pc = value_of_46581;
            ({
            auto&& _m = crate::lower::types::value_ty(v_pc);
            prism_rtl::is<crate::lower::model::OutTy::OutFn>(_m) ? ({
            auto&& pts_pd = prism_rtl::as<crate::lower::model::OutTy::OutFn>(_m).a0;
            prism_rtl::finished(wrap_as_job(crate::lower::types::own(v_pc), pts_pd, target_p4, a_p5));
        })
            : prism_rtl::finished(crate::lower::types::own(v_pc));
        });
        });
    });
    });
    });
    });
    });
}


/// `Start AsJobValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Ex> start_as_job_value(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr e_p2) {
    return prism_rtl::make_rc<AsJobValue>(lx_p0, env_p1, e_p2);
}


/// WrapAsJob: fn Ex, [OutTy], OutTy, OutTy -> Ex
crate::lower::model::Ex wrap_as_job(const crate::lower::model::Ex& f_p0, const Array<crate::lower::model::OutTy>& pts_p1, const crate::lower::model::OutTy& target_p2, const crate::lower::model::OutTy& a_p3) {
    auto names_p4 = each(crate::check::errors::range0(len(pts_p1)), [&](const Nat& i_p8) { return prism_rtl::cat("a", i_p8); });
    auto pa_p5 = len(pts_p1) == Nat(1u)
        ? crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("a0")})), a_p3})
        : crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{each(names_p4, [&](const Text& nm_p9) { return crate::lower::model::Pa(crate::lower::model::Pa::PaBind{nm_p9}); })})), a_p3});
    auto call_p6 = crate::lower::model::Ex(crate::lower::model::Ex::XApply{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("f")})), each(names_p4, [&](const Text& nm_pa) { return crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{nm_pa}))}); })});
    auto body_p7 = crate::lower::model::Ex(crate::lower::model::Ex::XBlock{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("f")}), crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("f")}))})})}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("once_job"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array<crate::lower::model::Pa>{}, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("prism_rtl::Turn::Finished"), Array(std::vector{call_p6})}))})})}))});
    return crate::lower::model::Ex(crate::lower::model::Ex::XBlock{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("f")}), f_p0})}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCast{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{pa_p5}), prism_rtl::rc(body_p7)})})})), target_p2}))});
}


/// NamedArgsOwned: unbounded fn Lx, Env, Text, [Arg] -> [Ex]
Array<crate::lower::model::Ex> named_args_owned(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const Text& qk_p2, const Array<crate::syntax::Arg>& args_p3) {
    auto&& _ps_p4 = crate::lower::jobs::scheme_parts(lx_p0, qk_p2);
    auto&& ps_p4 = std::get<0>(_ps_p4);
    return run_to_end(each_job(crate::check::errors::range0(len(args_p3)), ({
        auto args_p3_1 = args_p3;
        auto ps_p4_2 = ps_p4;
        auto lx_p0_3 = lx_p0;
        auto env_p1_4 = env_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(Nat)>>(prism_rtl::rc([=, args_p3_1 = std::move(args_p3_1), ps_p4_2 = std::move(ps_p4_2), lx_p0_3 = std::move(lx_p0_3), env_p1_4 = std::move(env_p1_4)](Nat p0) {
        return ({
            auto args_p3_1_5 = args_p3_1;
            auto ps_p4_2_5 = ps_p4_2;
            auto lx_p0_3_5 = lx_p0_3;
            auto env_p1_4_5 = env_p1_4;
            entered(once_job([=, args_p3_1_5 = std::move(args_p3_1_5), ps_p4_2_5 = std::move(ps_p4_2_5), lx_p0_3_5 = std::move(lx_p0_3_5), env_p1_4_5 = std::move(env_p1_4_5)]() {
            return ({
                auto i_p5 = p0;
                ({
                auto a_p6 = or_(index(args_p3_1_5, i_p5), crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = dummy_expr(), .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}});
                ({
                auto&& _m = crate::lower::types::peel(or_(index(ps_p4_2_5, i_p5), crate::check::types::Ty(crate::check::types::Ty::TyErr{})));
                prism_rtl::is<crate::check::types::Ty::TyFn>(_m) && prism_rtl::is<crate::check::types::Col::CBound>(prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a0) ? call_then(start_value_of(lx_p0_3_5, env_p1_4_5, a_p6->value), [=](crate::lower::types::Vl value_of_47884) { return prism_rtl::finished(crate::lower::types::own(value_of_47884)); })
                : prism_rtl::is<crate::check::types::Ty::TyFn>(_m) ? prism_rtl::more(prism_rtl::rc(AsJobValue(lx_p0_3_5, env_p1_4_5, a_p6->value)))
                : call_then(start_value_of(lx_p0_3_5, env_p1_4_5, a_p6->value), [=](crate::lower::types::Vl value_of_48007) { return prism_rtl::finished(crate::lower::types::own(value_of_48007)); });
            });
            });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<Array<crate::lower::model::Ex>> NamedArgsOwned::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& qk_p2 = this->qk_p2;
    const auto& args_p3 = this->args_p3;
    auto&& _ps_p4 = crate::lower::jobs::scheme_parts(lx_p0, qk_p2);
    auto&& ps_p4 = std::get<0>(_ps_p4);
    return each_job(crate::check::errors::range0(len(args_p3)), ({
        auto args_p3_1 = args_p3;
        auto ps_p4_2 = ps_p4;
        auto lx_p0_3 = lx_p0;
        auto env_p1_4 = env_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(Nat)>>(prism_rtl::rc([=, args_p3_1 = std::move(args_p3_1), ps_p4_2 = std::move(ps_p4_2), lx_p0_3 = std::move(lx_p0_3), env_p1_4 = std::move(env_p1_4)](Nat p0) {
        return ({
            auto args_p3_1_5 = args_p3_1;
            auto ps_p4_2_5 = ps_p4_2;
            auto lx_p0_3_5 = lx_p0_3;
            auto env_p1_4_5 = env_p1_4;
            entered(once_job([=, args_p3_1_5 = std::move(args_p3_1_5), ps_p4_2_5 = std::move(ps_p4_2_5), lx_p0_3_5 = std::move(lx_p0_3_5), env_p1_4_5 = std::move(env_p1_4_5)]() {
            return ({
                auto i_p5 = p0;
                ({
                auto a_p6 = or_(index(args_p3_1_5, i_p5), crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = dummy_expr(), .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}});
                ({
                auto&& _m = crate::lower::types::peel(or_(index(ps_p4_2_5, i_p5), crate::check::types::Ty(crate::check::types::Ty::TyErr{})));
                prism_rtl::is<crate::check::types::Ty::TyFn>(_m) && prism_rtl::is<crate::check::types::Col::CBound>(prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a0) ? call_then(start_value_of(lx_p0_3_5, env_p1_4_5, a_p6->value), [=](crate::lower::types::Vl value_of_47884) { return prism_rtl::finished(crate::lower::types::own(value_of_47884)); })
                : prism_rtl::is<crate::check::types::Ty::TyFn>(_m) ? prism_rtl::more(prism_rtl::rc(AsJobValue(lx_p0_3_5, env_p1_4_5, a_p6->value)))
                : call_then(start_value_of(lx_p0_3_5, env_p1_4_5, a_p6->value), [=](crate::lower::types::Vl value_of_48007) { return prism_rtl::finished(crate::lower::types::own(value_of_48007)); });
            });
            });
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start NamedArgsOwned, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::lower::model::Ex>> start_named_args_owned(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, Text qk_p2, Array<crate::syntax::Arg> args_p3) {
    return prism_rtl::make_rc<NamedArgsOwned>(lx_p0, env_p1, qk_p2, args_p3);
}


/// StartArgs: unbounded fn Lx, Env, Vl, [Arg] -> [Ex]
Array<crate::lower::model::Ex> start_args(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::lower::types::Vl& f_p2, const Array<crate::syntax::Arg>& args_p3) {
    auto pts_p4 = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::lower::model::OutTy>> _v;
        auto&& _m = crate::lower::types::value_ty(f_p2);
        if (prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(_m)) {
            auto&& m48219_0_0 = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(_m).a0;
            if (prism_rtl::is<crate::lower::model::OutTy::OutTuple>(prism_rtl::deref(prism_rtl::deref(m48219_0_0)))) {
                auto&& ts_p5 = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(prism_rtl::deref(prism_rtl::deref(m48219_0_0))).a0;
                _v.set(len(args_p3) == Nat(1u)
                    ? Array(std::vector{crate::lower::model::OutTy(crate::lower::model::OutTy::OutTuple{ts_p5})})
                    : ts_p5);
                goto _done;
            }
        }
        if (prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(_m)) {
            auto&& a_p6 = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(_m).a0;
            _v.set(Array(std::vector{prism_rtl::deref(prism_rtl::deref(a_p6))}));
            goto _done;
        }
        {
            _v.set(Array<crate::lower::model::OutTy>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    return run_to_end(each_job(crate::check::errors::range0(len(args_p3)), ({
        auto args_p3_1 = args_p3;
        auto pts_p4_2 = pts_p4;
        auto lx_p0_3 = lx_p0;
        auto env_p1_4 = env_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(Nat)>>(prism_rtl::rc([=, args_p3_1 = std::move(args_p3_1), pts_p4_2 = std::move(pts_p4_2), lx_p0_3 = std::move(lx_p0_3), env_p1_4 = std::move(env_p1_4)](Nat p0) {
        return ({
            auto args_p3_1_5 = args_p3_1;
            auto pts_p4_2_5 = pts_p4_2;
            auto lx_p0_3_5 = lx_p0_3;
            auto env_p1_4_5 = env_p1_4;
            entered(once_job([=, args_p3_1_5 = std::move(args_p3_1_5), pts_p4_2_5 = std::move(pts_p4_2_5), lx_p0_3_5 = std::move(lx_p0_3_5), env_p1_4_5 = std::move(env_p1_4_5)]() {
            return ({
                auto i_p7 = p0;
                ({
                auto a_p8 = or_(index(args_p3_1_5, i_p7), crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = dummy_expr(), .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}});
                ({
                auto&& _m = or_(index(pts_p4_2_5, i_p7), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}));
                prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(_m) ? prism_rtl::more(prism_rtl::rc(AsJobValue(lx_p0_3_5, env_p1_4_5, a_p8->value)))
                : call_then(start_value_of(lx_p0_3_5, env_p1_4_5, a_p8->value), [=](crate::lower::types::Vl value_of_48630) { return prism_rtl::finished(crate::lower::types::own(value_of_48630)); });
            });
            });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<Array<crate::lower::model::Ex>> StartArgs::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& f_p2 = this->f_p2;
    const auto& args_p3 = this->args_p3;
    auto pts_p4 = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::lower::model::OutTy>> _v;
        auto&& _m = crate::lower::types::value_ty(f_p2);
        if (prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(_m)) {
            auto&& m48219_0_0 = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(_m).a0;
            if (prism_rtl::is<crate::lower::model::OutTy::OutTuple>(prism_rtl::deref(prism_rtl::deref(m48219_0_0)))) {
                auto&& ts_p5 = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(prism_rtl::deref(prism_rtl::deref(m48219_0_0))).a0;
                _v.set(len(args_p3) == Nat(1u)
                    ? Array(std::vector{crate::lower::model::OutTy(crate::lower::model::OutTy::OutTuple{ts_p5})})
                    : ts_p5);
                goto _done;
            }
        }
        if (prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(_m)) {
            auto&& a_p6 = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(_m).a0;
            _v.set(Array(std::vector{prism_rtl::deref(prism_rtl::deref(a_p6))}));
            goto _done;
        }
        {
            _v.set(Array<crate::lower::model::OutTy>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    return each_job(crate::check::errors::range0(len(args_p3)), ({
        auto args_p3_1 = args_p3;
        auto pts_p4_2 = pts_p4;
        auto lx_p0_3 = lx_p0;
        auto env_p1_4 = env_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(Nat)>>(prism_rtl::rc([=, args_p3_1 = std::move(args_p3_1), pts_p4_2 = std::move(pts_p4_2), lx_p0_3 = std::move(lx_p0_3), env_p1_4 = std::move(env_p1_4)](Nat p0) {
        return ({
            auto args_p3_1_5 = args_p3_1;
            auto pts_p4_2_5 = pts_p4_2;
            auto lx_p0_3_5 = lx_p0_3;
            auto env_p1_4_5 = env_p1_4;
            entered(once_job([=, args_p3_1_5 = std::move(args_p3_1_5), pts_p4_2_5 = std::move(pts_p4_2_5), lx_p0_3_5 = std::move(lx_p0_3_5), env_p1_4_5 = std::move(env_p1_4_5)]() {
            return ({
                auto i_p7 = p0;
                ({
                auto a_p8 = or_(index(args_p3_1_5, i_p7), crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = dummy_expr(), .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}});
                ({
                auto&& _m = or_(index(pts_p4_2_5, i_p7), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}));
                prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(_m) ? prism_rtl::more(prism_rtl::rc(AsJobValue(lx_p0_3_5, env_p1_4_5, a_p8->value)))
                : call_then(start_value_of(lx_p0_3_5, env_p1_4_5, a_p8->value), [=](crate::lower::types::Vl value_of_48630) { return prism_rtl::finished(crate::lower::types::own(value_of_48630)); });
            });
            });
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start StartArgs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::lower::model::Ex>> start_start_args(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::lower::types::Vl f_p2, Array<crate::syntax::Arg> args_p3) {
    return prism_rtl::make_rc<StartArgs>(lx_p0, env_p1, f_p2, args_p3);
}


/// PreludeVariant: fn Text, OutTy -> Text
Text prelude_variant(const Text& name_p0, const crate::lower::model::OutTy& first_p1) {
    if (prism_rtl::is<crate::lower::model::OutTy::OutText>(first_p1)) {
        return name_p0 == Text::lit("len") ? Text::lit("len_text") : name_p0;
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutMap>(first_p1)) {
        return crate::check::types::has_text(Array(std::vector{Text::lit("len"), Text::lit("fold"), Text::lit("each"), Text::lit("filter")}), name_p0)
            ? prism_rtl::cat(name_p0, "_map")
            : name_p0;
    }
    {
        return name_p0;
    }
}


/// FieldValue: unbounded fn Lx, Env, Expr, Text -> Vl
crate::lower::types::Vl field_value(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& r_p2, const Text& name_p3) {
    auto rv_p4 = value_of(lx_p0, env_p1, r_p2);
    auto rty_p5 = crate::lower::types::peel(crate::lower::type_at(lx_p0, r_p2.span));
    auto [ft_p8, rc_p9] = field_info(lx_p0, rty_p5, name_p3);
    auto f_p6 = crate::lower::snake(name_p3);
    auto mode_p7 = rc_p9
        ? crate::lower::types::Holding(crate::lower::types::Holding::RcOwned{})
        : crate::lower::types::Holding(crate::lower::types::Holding::Owned{});
    if (prism_rtl::is<crate::lower::types::Vl::VlPlace>(rv_p4)) {
        auto&& x_pa = prism_rtl::as<crate::lower::types::Vl::VlPlace>(rv_p4).a0;
        return crate::lower::types::Vl(crate::lower::types::Vl::VlPlace{crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(x_pa), f_p6}), mode_p7, ft_p8});
    }
    if (prism_rtl::is<crate::lower::types::Vl::VlOwned>(rv_p4)) {
        auto&& x_pb = prism_rtl::as<crate::lower::types::Vl::VlOwned>(rv_p4).a0;
        return crate::lower::types::Vl(crate::lower::types::Vl::VlPlace{crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(x_pb), f_p6}), mode_p7, ft_p8});
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::lower::types::Vl> FieldValue::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& r_p2 = this->r_p2;
    const auto& name_p3 = this->name_p3;
    auto env_p1_1 = env_p1;
    auto lx_p0_2 = lx_p0;
    auto name_p3_3 = name_p3;
    auto r_p2_4 = r_p2;
    return call_then(start_value_of(lx_p0_2, env_p1_1, r_p2_4), [=](crate::lower::types::Vl value_of_49125) {
        return ({
            auto rv_p4 = value_of_49125;
            auto rty_p5 = crate::lower::types::peel(crate::lower::type_at(lx_p0_2, prism_rtl::deref(r_p2_4).span));
            call_then(start_field_info(lx_p0_2, rty_p5, name_p3_3), [=, rv_p4 = std::move(rv_p4)](std::tuple<crate::lower::model::OutTy, bool> field_info_49204) {
            return ({
                auto [ft_p8, rc_p9] = field_info_49204;
                auto f_p6 = crate::lower::snake(name_p3_3);
                auto mode_p7 = rc_p9
                    ? crate::lower::types::Holding(crate::lower::types::Holding::RcOwned{})
                    : crate::lower::types::Holding(crate::lower::types::Holding::Owned{});
                ({
                prism_rtl::is<crate::lower::types::Vl::VlPlace>(rv_p4) ? ({
                auto&& x_pa = prism_rtl::as<crate::lower::types::Vl::VlPlace>(rv_p4).a0;
                prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlPlace{crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(x_pa), f_p6}), mode_p7, ft_p8}));
            })
                : prism_rtl::is<crate::lower::types::Vl::VlOwned>(rv_p4) ? ({
                auto&& x_pb = prism_rtl::as<crate::lower::types::Vl::VlOwned>(rv_p4).a0;
                prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlPlace{crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(x_pb), f_p6}), mode_p7, ft_p8}));
            })
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        });
        });
    });
}


/// `Start FieldValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_field_value(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr r_p2, Text name_p3) {
    return prism_rtl::make_rc<FieldValue>(lx_p0, env_p1, r_p2, name_p3);
}


/// FieldInfo: unbounded fn Lx, Ty, Text -> ((OutTy, Bool))
std::tuple<crate::lower::model::OutTy, bool> field_info(const crate::lower::Lx& lx_p0, const crate::check::types::Ty& rty_p1, const Text& name_p2) {
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(rty_p1)) {
        auto&& n_p3 = prism_rtl::as<crate::check::types::Ty::TyCon>(rty_p1).a0;
        auto&& args_p4 = prism_rtl::as<crate::check::types::Ty::TyCon>(rty_p1).a1;
        auto&& _m = crate::prelude::get(prism_rtl::deref(lx_p0.g).ctors, n_p3);
        if (prism_rtl::is_some(_m)) {
            auto&& c_p5 = prism_rtl::some_of(_m);
            auto fix_o6 = fold(crate::check::errors::range0(len(prism_rtl::deref(c_p5).fields)), std::optional<Nat>{}, [&](const std::optional<Nat>& found_o7, const Nat& i_p8) {
                return or_(index(prism_rtl::deref(c_p5).fields, i_p8), Text::lit("")) == name_p2
                    ? std::optional(i_p8)
                    : found_o7;
            });
            if (prism_rtl::is_some(fix_o6)) {
                auto&& i_p9 = prism_rtl::some_of(fix_o6);
                auto ft_pa = or_(index(c_p5->args, i_p9), crate::check::types::Ty(crate::check::types::Ty::TyErr{}));
                auto inst_pb = instantiated(ft_pa, prism_rtl::deref(c_p5).params, args_p4);
                return std::tuple{crate::lower::types::out_ty_of(lx_p0, inst_pb), crate::lower::types::rc_field(lx_p0, prism_rtl::deref(c_p5).name, i_p9)};
            }
            if (prism_rtl::is_none(fix_o6)) {
                return std::tuple{crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnknown{prism_rtl::cat("a field ", name_p2)}), false};
            }
            prism_rtl::unreachable("no arm matched");
        }
        if (prism_rtl::is_none(_m)) {
            return std::tuple{crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnknown{prism_rtl::cat("a field ", name_p2)}), false};
        }
        prism_rtl::unreachable("no arm matched");
    }
    {
        return std::tuple{crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnknown{prism_rtl::cat("a field ", name_p2, " of a non-record")}), false};
    }
}


prism_rtl::Turn<std::tuple<crate::lower::model::OutTy, bool>> FieldInfo::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& rty_p1 = this->rty_p1;
    const auto& name_p2 = this->name_p2;
    return ({
        prism_rtl::is<crate::check::types::Ty::TyCon>(rty_p1) ? ({
        auto&& n_p3 = prism_rtl::as<crate::check::types::Ty::TyCon>(rty_p1).a0;
        auto&& args_p4 = prism_rtl::as<crate::check::types::Ty::TyCon>(rty_p1).a1;
        ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(prism_rtl::deref(lx_p0).g).ctors, n_p3);
        prism_rtl::is_some(_m) ? ({
        auto&& c_p5 = prism_rtl::some_of(_m);
        ({
        auto fix_o6 = fold(crate::check::errors::range0(len(prism_rtl::deref(c_p5).fields)), std::optional<Nat>{}, [&](const std::optional<Nat>& found_o7, const Nat& i_p8) {
            return or_(index(prism_rtl::deref(c_p5).fields, i_p8), Text::lit("")) == name_p2
                ? std::optional(i_p8)
                : found_o7;
        });
        ({
        prism_rtl::is_some(fix_o6) ? ({
        auto&& i_p9 = prism_rtl::some_of(fix_o6);
        ({
        auto ft_pa = or_(index(c_p5->args, i_p9), crate::check::types::Ty(crate::check::types::Ty::TyErr{}));
        auto args_p4_1 = args_p4;
        auto i_p9_2 = i_p9;
        auto lx_p0_3 = lx_p0;
        auto name_p2_4 = name_p2;
        call_then(start_instantiated(ft_pa, prism_rtl::deref(c_p5).params, args_p4_1), [=, i_p9_2 = std::move(i_p9_2), lx_p0_3 = std::move(lx_p0_3)](crate::check::types::Ty instantiated_49892) {
        return ({
            auto inst_pb = instantiated_49892;
            call_then(crate::lower::types::start_out_ty_of(lx_p0_3, inst_pb), [=](crate::lower::model::OutTy out_ty_of_49947) { return prism_rtl::finished(std::tuple{out_ty_of_49947, crate::lower::types::rc_field(lx_p0_3, prism_rtl::deref(c_p5).name, i_p9_2)}); });
        });
    });
    });
    })
        : prism_rtl::is_none(fix_o6) ? prism_rtl::finished(std::tuple{crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnknown{prism_rtl::cat("a field ", name_p2)}), false})
        : throw prism_rtl::Panic("no arm matched");
    });
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnknown{prism_rtl::cat("a field ", name_p2)}), false})
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : prism_rtl::finished(std::tuple{crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnknown{prism_rtl::cat("a field ", name_p2, " of a non-record")}), false});
    });
}


/// `Start FieldInfo, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::lower::model::OutTy, bool>> start_field_info(crate::lower::Lx lx_p0, crate::check::types::Ty rty_p1, Text name_p2) {
    return prism_rtl::make_rc<FieldInfo>(lx_p0, rty_p1, name_p2);
}


/// Instantiated: unbounded fn Ty, [Text], [Ty] -> Ty
crate::check::types::Ty instantiated(const crate::check::types::Ty& t_p0, const Array<Text>& params_p1, const Array<crate::check::types::Ty>& args_p2) {
    if (prism_rtl::is<crate::check::types::Ty::TyQ>(t_p0)) {
        auto&& q_p3 = prism_rtl::as<crate::check::types::Ty::TyQ>(t_p0).a0;
        auto hit_o4 = fold(crate::check::errors::range0(len(params_p1)), std::optional<crate::check::types::Ty>{}, [&](const std::optional<crate::check::types::Ty>& found_o5, const Nat& i_p6) {
            return or_(index(params_p1, i_p6), Text::lit("")) == q_p3
                ? index(args_p2, i_p6)
                : found_o5;
        });
        return or_(hit_o4, t_p0);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t_p0)) {
        auto&& n_p7 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p0).a0;
        auto&& xs_p8 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p0).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyCon{n_p7, run_to_end(each_job(xs_p8, ({
            auto params_p1_1 = params_p1;
            auto args_p2_2 = args_p2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, params_p1_1 = std::move(params_p1_1), args_p2_2 = std::move(args_p2_2)](crate::check::types::Ty p0) {
            return ({
                auto params_p1_1_3 = params_p1_1;
                auto args_p2_2_3 = args_p2_2;
                entered(once_job([=, params_p1_1_3 = std::move(params_p1_1_3), args_p2_2_3 = std::move(args_p2_2_3)]() {
                return ({
                    auto x_p9 = p0;
                    (prism_rtl::more(prism_rtl::rc(Instantiated(x_p9, params_p1_1_3, args_p2_2_3))));
                });
            }));
            });
        })));
        })))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(t_p0)) {
        auto&& c_pa = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p0).a0;
        auto&& ps_pb = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p0).a1;
        auto&& res_pc = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p0).a2;
        return crate::check::types::Ty(crate::check::types::Ty::TyFn{c_pa, run_to_end(each_job(ps_pb, ({
            auto params_p1_1 = params_p1;
            auto args_p2_2 = args_p2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, params_p1_1 = std::move(params_p1_1), args_p2_2 = std::move(args_p2_2)](crate::check::types::Ty p0) {
            return ({
                auto params_p1_1_3 = params_p1_1;
                auto args_p2_2_3 = args_p2_2;
                entered(once_job([=, params_p1_1_3 = std::move(params_p1_1_3), args_p2_2_3 = std::move(args_p2_2_3)]() {
                return ({
                    auto x_pd = p0;
                    (prism_rtl::more(prism_rtl::rc(Instantiated(x_pd, params_p1_1_3, args_p2_2_3))));
                });
            }));
            });
        })));
        }))), prism_rtl::rc(instantiated(prism_rtl::deref(prism_rtl::deref(res_pc)), params_p1, args_p2))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t_p0)) {
        auto&& ts_pe = prism_rtl::as<crate::check::types::Ty::TyTuple>(t_p0).a0;
        return crate::check::types::Ty(crate::check::types::Ty::TyTuple{run_to_end(each_job(ts_pe, ({
            auto params_p1_1 = params_p1;
            auto args_p2_2 = args_p2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, params_p1_1 = std::move(params_p1_1), args_p2_2 = std::move(args_p2_2)](crate::check::types::Ty p0) {
            return ({
                auto params_p1_1_3 = params_p1_1;
                auto args_p2_2_3 = args_p2_2;
                entered(once_job([=, params_p1_1_3 = std::move(params_p1_1_3), args_p2_2_3 = std::move(args_p2_2_3)]() {
                return ({
                    auto x_pf = p0;
                    (prism_rtl::more(prism_rtl::rc(Instantiated(x_pf, params_p1_1_3, args_p2_2_3))));
                });
            }));
            });
        })));
        })))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(t_p0)) {
        auto&& e_pg = prism_rtl::as<crate::check::types::Ty::TyArray>(t_p0).a0;
        return crate::check::types::Ty(crate::check::types::Ty::TyArray{prism_rtl::rc(instantiated(prism_rtl::deref(prism_rtl::deref(e_pg)), params_p1, args_p2))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(t_p0)) {
        auto&& k_ph = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p0).a0;
        auto&& v_pi = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p0).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyMap{prism_rtl::rc(instantiated(prism_rtl::deref(prism_rtl::deref(k_ph)), params_p1, args_p2)), prism_rtl::rc(instantiated(prism_rtl::deref(prism_rtl::deref(v_pi)), params_p1, args_p2))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t_p0)) {
        auto&& s_pj = prism_rtl::as<crate::check::types::Ty::TySig>(t_p0).a0;
        auto&& i_pk = prism_rtl::as<crate::check::types::Ty::TySig>(t_p0).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TySig{s_pj, prism_rtl::rc(instantiated(prism_rtl::deref(prism_rtl::deref(i_pk)), params_p1, args_p2))});
    }
    {
        return t_p0;
    }
}


prism_rtl::Turn<crate::check::types::Ty> Instantiated::cycle() const {
    const auto& t_p0 = this->t_p0;
    const auto& params_p1 = this->params_p1;
    const auto& args_p2 = this->args_p2;
    return ({
        prism_rtl::is<crate::check::types::Ty::TyQ>(t_p0) ? ({
        auto&& q_p3 = prism_rtl::as<crate::check::types::Ty::TyQ>(t_p0).a0;
        ({
        auto hit_o4 = fold(crate::check::errors::range0(len(params_p1)), std::optional<crate::check::types::Ty>{}, [&](const std::optional<crate::check::types::Ty>& found_o5, const Nat& i_p6) {
            return or_(index(params_p1, i_p6), Text::lit("")) == q_p3
                ? index(args_p2, i_p6)
                : found_o5;
        });
        (prism_rtl::finished(or_(hit_o4, t_p0)));
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t_p0) ? ({
        auto&& n_p7 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p0).a0;
        auto&& xs_p8 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p0).a1;
        ({
        auto args_p2_1 = args_p2;
        auto n_p7_2 = n_p7;
        auto params_p1_3 = params_p1;
        auto xs_p8_4 = xs_p8;
        call_value(each_job(xs_p8_4, ({
        auto params_p1_3_5 = params_p1_3;
        auto args_p2_1_5 = args_p2_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, params_p1_3_5 = std::move(params_p1_3_5), args_p2_1_5 = std::move(args_p2_1_5)](crate::check::types::Ty p0) {
        return ({
            auto params_p1_3_5_5 = params_p1_3_5;
            auto args_p2_1_5_5 = args_p2_1_5;
            entered(once_job([=, params_p1_3_5_5 = std::move(params_p1_3_5_5), args_p2_1_5_5 = std::move(args_p2_1_5_5)]() {
            return ({
                auto x_p9 = p0;
                (prism_rtl::more(prism_rtl::rc(Instantiated(x_p9, params_p1_3_5_5, args_p2_1_5_5))));
            });
        }));
        });
    })));
    })), [=, n_p7_2 = std::move(n_p7_2)](Array<crate::check::types::Ty> each_50527) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyCon{n_p7_2, each_50527})); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyFn>(t_p0) ? ({
        auto&& c_pa = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p0).a0;
        auto&& ps_pb = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p0).a1;
        auto&& res_pc = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p0).a2;
        ({
        auto args_p2_1 = args_p2;
        auto c_pa_2 = c_pa;
        auto params_p1_3 = params_p1;
        auto ps_pb_4 = ps_pb;
        auto res_pc_5 = prism_rtl::deref(prism_rtl::deref(res_pc));
        call_value(each_job(ps_pb_4, ({
        auto params_p1_3_6 = params_p1_3;
        auto args_p2_1_6 = args_p2_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, params_p1_3_6 = std::move(params_p1_3_6), args_p2_1_6 = std::move(args_p2_1_6)](crate::check::types::Ty p0) {
        return ({
            auto params_p1_3_6_6 = params_p1_3_6;
            auto args_p2_1_6_6 = args_p2_1_6;
            entered(once_job([=, params_p1_3_6_6 = std::move(params_p1_3_6_6), args_p2_1_6_6 = std::move(args_p2_1_6_6)]() {
            return ({
                auto x_pd = p0;
                (prism_rtl::more(prism_rtl::rc(Instantiated(x_pd, params_p1_3_6_6, args_p2_1_6_6))));
            });
        }));
        });
    })));
    })), [=, c_pa_2 = std::move(c_pa_2), res_pc_5 = std::move(res_pc_5)](Array<crate::check::types::Ty> each_50601) { return call_then(start_instantiated(res_pc_5, params_p1_3, args_p2_1), [=](crate::check::types::Ty instantiated_50647) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyFn{c_pa_2, each_50601, prism_rtl::rc(instantiated_50647)})); }); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyTuple>(t_p0) ? ({
        auto&& ts_pe = prism_rtl::as<crate::check::types::Ty::TyTuple>(t_p0).a0;
        ({
        auto args_p2_1 = args_p2;
        auto params_p1_2 = params_p1;
        auto ts_pe_3 = ts_pe;
        call_value(each_job(ts_pe_3, ({
        auto params_p1_2_4 = params_p1_2;
        auto args_p2_1_4 = args_p2_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, params_p1_2_4 = std::move(params_p1_2_4), args_p2_1_4 = std::move(args_p2_1_4)](crate::check::types::Ty p0) {
        return ({
            auto params_p1_2_4_4 = params_p1_2_4;
            auto args_p2_1_4_4 = args_p2_1_4;
            entered(once_job([=, params_p1_2_4_4 = std::move(params_p1_2_4_4), args_p2_1_4_4 = std::move(args_p2_1_4_4)]() {
            return ({
                auto x_pf = p0;
                (prism_rtl::more(prism_rtl::rc(Instantiated(x_pf, params_p1_2_4_4, args_p2_1_4_4))));
            });
        }));
        });
    })));
    })), [=](Array<crate::check::types::Ty> each_50704) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyTuple{each_50704})); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyArray>(t_p0) ? ({
        auto&& e_pg = prism_rtl::as<crate::check::types::Ty::TyArray>(t_p0).a0;
        ({
        auto args_p2_1 = args_p2;
        auto e_pg_2 = prism_rtl::deref(prism_rtl::deref(e_pg));
        auto params_p1_3 = params_p1;
        call_then(start_instantiated(e_pg_2, params_p1_3, args_p2_1), [=](crate::check::types::Ty instantiated_50772) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyArray{prism_rtl::rc(instantiated_50772)})); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyMap>(t_p0) ? ({
        auto&& k_ph = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p0).a0;
        auto&& v_pi = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p0).a1;
        ({
        auto args_p2_1 = args_p2;
        auto k_ph_2 = prism_rtl::deref(prism_rtl::deref(k_ph));
        auto params_p1_3 = params_p1;
        auto v_pi_4 = prism_rtl::deref(prism_rtl::deref(v_pi));
        call_then(start_instantiated(k_ph_2, params_p1_3, args_p2_1), [=, v_pi_4 = std::move(v_pi_4)](crate::check::types::Ty instantiated_50825) { return call_then(start_instantiated(v_pi_4, params_p1_3, args_p2_1), [=](crate::check::types::Ty instantiated_50857) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyMap{prism_rtl::rc(instantiated_50825), prism_rtl::rc(instantiated_50857)})); }); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TySig>(t_p0) ? ({
        auto&& s_pj = prism_rtl::as<crate::check::types::Ty::TySig>(t_p0).a0;
        auto&& i_pk = prism_rtl::as<crate::check::types::Ty::TySig>(t_p0).a1;
        ({
        auto args_p2_1 = args_p2;
        auto i_pk_2 = prism_rtl::deref(prism_rtl::deref(i_pk));
        auto params_p1_3 = params_p1;
        auto s_pj_4 = s_pj;
        call_then(start_instantiated(i_pk_2, params_p1_3, args_p2_1), [=, s_pj_4 = std::move(s_pj_4)](crate::check::types::Ty instantiated_50913) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TySig{s_pj_4, prism_rtl::rc(instantiated_50913)})); });
    });
    })
        : prism_rtl::finished(t_p0);
    });
}


/// `Start Instantiated, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::Ty> start_instantiated(crate::check::types::Ty t_p0, Array<Text> params_p1, Array<crate::check::types::Ty> args_p2) {
    return prism_rtl::make_rc<Instantiated>(t_p0, params_p1, args_p2);
}


/// IndexValue: unbounded fn Lx, Env, Expr, Expr, OutTy -> Vl
crate::lower::types::Vl index_value(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& r_p2, const crate::syntax::Expr& i_p3, const crate::lower::model::OutTy& t_p4) {
    auto rt_p5 = crate::lower::types::out_ty_of(lx_p0, crate::lower::types::peel(crate::lower::type_at(lx_p0, r_p2.span)));
    auto f_p6 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        if (prism_rtl::is<crate::lower::model::OutTy::OutMap>(rt_p5)) {
            _v.set(Text::lit("get"));
            goto _done;
        }
        {
            _v.set(Text::lit("index"));
            goto _done;
        }
    _done:
        _v.take();
    });
    return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{f_p6, Array(std::vector{argument(lx_p0, env_p1, r_p2), argument(lx_p0, env_p1, i_p3)})}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutOpt{prism_rtl::rc(t_p4)})});
}


prism_rtl::Turn<crate::lower::types::Vl> IndexValue::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& r_p2 = this->r_p2;
    const auto& i_p3 = this->i_p3;
    const auto& t_p4 = this->t_p4;
    auto env_p1_1 = env_p1;
    auto i_p3_2 = i_p3;
    auto lx_p0_3 = lx_p0;
    auto r_p2_4 = r_p2;
    auto t_p4_5 = t_p4;
    return call_then(crate::lower::types::start_out_ty_of(lx_p0_3, crate::lower::types::peel(crate::lower::type_at(lx_p0_3, prism_rtl::deref(r_p2_4).span))), [=](crate::lower::model::OutTy out_ty_of_51156) {
        return ({
            auto rt_p5 = out_ty_of_51156;
            auto f_p6 = ({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                if (prism_rtl::is<crate::lower::model::OutTy::OutMap>(rt_p5)) {
                    _v.set(Text::lit("get"));
                    goto _done;
                }
                {
                    _v.set(Text::lit("index"));
                    goto _done;
                }
            _done:
                _v.take();
            });
            call_then(start_argument(lx_p0_3, env_p1_1, r_p2_4), [=, f_p6 = std::move(f_p6)](crate::lower::model::Ex argument_51306) { return call_then(start_argument(lx_p0_3, env_p1_1, i_p3_2), [=](crate::lower::model::Ex argument_51329) { return prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{f_p6, Array(std::vector{argument_51306, argument_51329})}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutOpt{prism_rtl::rc(t_p4_5)})})); }); });
        });
    });
}


/// `Start IndexValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_index_value(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr r_p2, crate::syntax::Expr i_p3, crate::lower::model::OutTy t_p4) {
    return prism_rtl::make_rc<IndexValue>(lx_p0, env_p1, r_p2, i_p3, t_p4);
}


/// ReadNames: unbounded fn [Expr] -> [Text]
Array<Text> read_names(const Array<crate::syntax::Expr>& es_p0) {
    return fold(es_p0, Array<Text>{}, [&](const Array<Text>& acc_p1, const crate::syntax::Expr& x_p2) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = prism_rtl::deref(prism_rtl::deref(x_p2).kind);
            if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
                auto&& n_p3 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
                _v.set(len(n_p3->path_) == Nat(1u)
                    ? crate::check::types::add_text(acc_p1, crate::check::env::sname_key(n_p3))
                    : acc_p1);
                goto _done;
            }
            {
                _v.set(acc_p1);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


prism_rtl::Turn<Array<Text>> ReadNames::cycle() const {
    const auto& es_p0 = this->es_p0;
    return prism_rtl::finished(fold(es_p0, Array<Text>{}, [&](const Array<Text>& acc_p1, const crate::syntax::Expr& x_p2) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = prism_rtl::deref(prism_rtl::deref(x_p2).kind);
            if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
                auto&& n_p3 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
                _v.set(len(n_p3->path_) == Nat(1u)
                    ? crate::check::types::add_text(acc_p1, crate::check::env::sname_key(n_p3))
                    : acc_p1);
                goto _done;
            }
            {
                _v.set(acc_p1);
                goto _done;
            }
        _done:
            _v.take();
        });
    }));
}


/// `Start ReadNames, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_read_names(Array<crate::syntax::Expr> es_p0) {
    return prism_rtl::make_rc<ReadNames>(es_p0);
}


/// LambdaExprs: unbounded fn LambdaBody -> [Expr]
Array<crate::syntax::Expr> lambda_exprs(const crate::syntax::LambdaBody& lambda_body0) {
    if (prism_rtl::is<crate::syntax::LambdaBody::LbExpr>(lambda_body0)) {
        auto&& x_p0 = prism_rtl::as<crate::syntax::LambdaBody::LbExpr>(lambda_body0).a0;
        return crate::check::typed::print::exprs_in(prism_rtl::deref(prism_rtl::deref(x_p0)));
    }
    if (prism_rtl::is<crate::syntax::LambdaBody::LbBlock>(lambda_body0)) {
        auto&& b_p1 = prism_rtl::as<crate::syntax::LambdaBody::LbBlock>(lambda_body0).a0;
        return crate::check::typed::print::block_exprs(b_p1);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<crate::syntax::Expr>> LambdaExprs::cycle() const {
    const auto& lambda_body0 = this->lambda_body0;
    return ({
        prism_rtl::is<crate::syntax::LambdaBody::LbExpr>(lambda_body0) ? ({
        auto&& x_p0 = prism_rtl::as<crate::syntax::LambdaBody::LbExpr>(lambda_body0).a0;
        prism_rtl::more(prism_rtl::rc(crate::check::typed::print::ExprsIn(prism_rtl::deref(prism_rtl::deref(x_p0)))));
    })
        : prism_rtl::is<crate::syntax::LambdaBody::LbBlock>(lambda_body0) ? ({
        auto&& b_p1 = prism_rtl::as<crate::syntax::LambdaBody::LbBlock>(lambda_body0).a0;
        prism_rtl::more(prism_rtl::rc(crate::check::typed::print::BlockExprs(b_p1)));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start LambdaExprs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::syntax::Expr>> start_lambda_exprs(crate::syntax::LambdaBody lambda_body0) {
    return prism_rtl::make_rc<LambdaExprs>(lambda_body0);
}


/// FreeReads: unbounded fn [Expr], [(([Text], Range))] -> [Text]
Array<Text> free_reads(const Array<crate::syntax::Expr>& es_p0, const Array<std::tuple<Array<Text>, crate::syntax::Range>>& outer_p1) {
    auto scopes_p2 = run_to_end(fold_job(es_p0, outer_p1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Array<Text>, crate::syntax::Range>>>(std::tuple<Array<std::tuple<Array<Text>, crate::syntax::Range>>, crate::syntax::Expr>)>>(prism_rtl::rc([=](std::tuple<Array<std::tuple<Array<Text>, crate::syntax::Range>>, crate::syntax::Expr> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc_p3 = p0;
                auto e_p4 = p1;
                call_then(start_scopes_of(e_p4), [=, acc_p3 = std::move(acc_p3)](Array<std::tuple<Array<Text>, crate::syntax::Range>> scopes_of_52052) { return prism_rtl::finished(append(acc_p3, scopes_of_52052)); });
            });
        }));
    }))));
    return fold(es_p0, Array<Text>{}, [&](const Array<Text>& acc_p5, const crate::syntax::Expr& e_p6) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p6).kind);
            if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
                auto&& n_p7 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
                _v.set(({
                    auto nkey_p8 = crate::check::env::sname_key(n_p7);
                    auto hidden_p9 = fold(scopes_p2, false, [&](const bool& seen_pa, const std::tuple<Array<Text>, crate::syntax::Range>& _p1) {
                        auto&& names_pb = std::get<0>(_p1);
                        auto&& r_pc = std::get<1>(_p1);
                        return prism_rtl::deref(seen_pa) || ((crate::check::types::has_text(names_pb, nkey_p8) && (prism_rtl::deref(r_pc).start <= prism_rtl::deref(prism_rtl::deref(e_p6).span).start)) && (prism_rtl::deref(prism_rtl::deref(e_p6).span).start < prism_rtl::deref(r_pc).end));
                    });
                    (len(n_p7->path_) != Nat(1u)) || std::move(hidden_p9)
                    ? acc_p5
                    : crate::check::types::add_text(acc_p5, nkey_p8);
                }));
                goto _done;
            }
            {
                _v.set(acc_p5);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


prism_rtl::Turn<Array<Text>> FreeReads::cycle() const {
    const auto& es_p0 = this->es_p0;
    const auto& outer_p1 = this->outer_p1;
    auto es_p0_1 = es_p0;
    auto outer_p1_2 = outer_p1;
    return call_value(fold_job(es_p0_1, outer_p1_2, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Array<Text>, crate::syntax::Range>>>(std::tuple<Array<std::tuple<Array<Text>, crate::syntax::Range>>, crate::syntax::Expr>)>>(prism_rtl::rc([=](std::tuple<Array<std::tuple<Array<Text>, crate::syntax::Range>>, crate::syntax::Expr> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc_p3 = p0;
                auto e_p4 = p1;
                call_then(start_scopes_of(e_p4), [=, acc_p3 = std::move(acc_p3)](Array<std::tuple<Array<Text>, crate::syntax::Range>> scopes_of_52052) { return prism_rtl::finished(append(acc_p3, scopes_of_52052)); });
            });
        }));
    }))), [=](Array<std::tuple<Array<Text>, crate::syntax::Range>> fold_52013) {
        return ({
            auto scopes_p2 = fold_52013;
            (prism_rtl::finished(fold(es_p0_1, Array<Text>{}, [&](const Array<Text>& acc_p5, const crate::syntax::Expr& e_p6) {
            return ({
                __label__ _done;
                prism_rtl::Slot<Array<Text>> _v;
                auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p6).kind);
                if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
                    auto&& n_p7 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
                    _v.set(({
                        auto nkey_p8 = crate::check::env::sname_key(n_p7);
                        auto hidden_p9 = fold(scopes_p2, false, [&](const bool& seen_pa, const std::tuple<Array<Text>, crate::syntax::Range>& _p1) {
                            auto&& names_pb = std::get<0>(_p1);
                            auto&& r_pc = std::get<1>(_p1);
                            return prism_rtl::deref(seen_pa) || ((crate::check::types::has_text(names_pb, nkey_p8) && (prism_rtl::deref(r_pc).start <= prism_rtl::deref(prism_rtl::deref(e_p6).span).start)) && (prism_rtl::deref(prism_rtl::deref(e_p6).span).start < prism_rtl::deref(r_pc).end));
                        });
                        (len(n_p7->path_) != Nat(1u)) || std::move(hidden_p9)
                        ? acc_p5
                        : crate::check::types::add_text(acc_p5, nkey_p8);
                    }));
                    goto _done;
                }
                {
                    _v.set(acc_p5);
                    goto _done;
                }
            _done:
                _v.take();
            });
        })));
        });
    });
}


/// `Start FreeReads, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_free_reads(Array<crate::syntax::Expr> es_p0, Array<std::tuple<Array<Text>, crate::syntax::Range>> outer_p1) {
    return prism_rtl::make_rc<FreeReads>(es_p0, outer_p1);
}


/// ScopesOf: unbounded fn Expr -> [(([Text], Range))]
Array<std::tuple<Array<Text>, crate::syntax::Range>> scopes_of(const crate::syntax::Expr& e_p0) {
    auto&& _m = prism_rtl::deref(e_p0.kind);
    if (prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m)) {
        auto&& ps_o1 = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0;
        auto&& body_p2 = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a1;
        auto names_p3 = run_to_end(fold_job(or_(ps_o1, Array<crate::syntax::Pattern_>{}), Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Pattern_> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc_p5 = p0;
                    auto q_p6 = p1;
                    call_then(crate::check::env::names::start_pattern_names(q_p6), [=, acc_p5 = std::move(acc_p5)](Array<Text> pattern_names_52663) { return prism_rtl::finished(append(acc_p5, pattern_names_52663)); });
                });
            }));
        }))));
        auto inner_p4 = ({
            __label__ _done;
            prism_rtl::Slot<Array<std::tuple<Array<Text>, crate::syntax::Range>>> _v;
            auto&& _m = prism_rtl::deref(prism_rtl::deref(body_p2));
            if (prism_rtl::is<crate::syntax::LambdaBody::LbBlock>(_m)) {
                auto&& b_p7 = prism_rtl::as<crate::syntax::LambdaBody::LbBlock>(_m).a0;
                _v.set(block_scopes(b_p7));
                goto _done;
            }
            {
                _v.set(Array<std::tuple<Array<Text>, crate::syntax::Range>>{});
                goto _done;
            }
        _done:
            _v.take();
        });
        return crate::prelude::push(inner_p4, std::tuple{names_p3, e_p0.span});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m)) {
        auto&& arms_p8 = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
        return run_to_end(fold_job(arms_p8, Array<std::tuple<Array<Text>, crate::syntax::Range>>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Array<Text>, crate::syntax::Range>>>(std::tuple<Array<std::tuple<Array<Text>, crate::syntax::Range>>, crate::syntax::Arm>)>>(prism_rtl::rc([=](std::tuple<Array<std::tuple<Array<Text>, crate::syntax::Range>>, crate::syntax::Arm> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc_p9 = p0;
                    auto a_pa = p1;
                    ({
                    auto names_pb = ({
                        __label__ _done;
                        prism_rtl::Slot<Array<Text>> _v;
                        auto&& _m = prism_rtl::deref(a_pa).pattern;
                        if (prism_rtl::is_some(_m)) {
                            auto&& q_pc = prism_rtl::some_of(_m);
                            _v.set(crate::check::env::names::pattern_names(q_pc));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(Array<Text>{});
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                    (prism_rtl::finished(append(crate::prelude::push(acc_p9, std::tuple{names_pb, prism_rtl::deref(a_pa).span}), block_scopes(prism_rtl::deref(a_pa).body))));
                });
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EIf>(_m)) {
        auto&& c_pd = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
        auto&& t_pe = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
        auto&& el_of = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
        auto bound_pg = ({
            __label__ _done;
            prism_rtl::Slot<Array<std::tuple<Array<Text>, crate::syntax::Range>>> _v;
            auto&& _m = prism_rtl::deref(prism_rtl::deref(c_pd));
            if (prism_rtl::is<crate::syntax::Cond::CondBind>(_m)) {
                auto&& q_pi = prism_rtl::as<crate::syntax::Cond::CondBind>(_m).a0;
                _v.set(Array(std::vector{std::tuple{crate::check::env::names::pattern_names(q_pi), prism_rtl::deref(t_pe).span}}));
                goto _done;
            }
            {
                _v.set(Array<std::tuple<Array<Text>, crate::syntax::Range>>{});
                goto _done;
            }
        _done:
            _v.take();
        });
        auto else_scopes_ph = ({
            __label__ _done;
            prism_rtl::Slot<Array<std::tuple<Array<Text>, crate::syntax::Range>>> _v;
            if (prism_rtl::is_some(el_of)) {
                auto&& b_pj = prism_rtl::some_of(el_of);
                _v.set(block_scopes(b_pj));
                goto _done;
            }
            if (prism_rtl::is_none(el_of)) {
                _v.set(Array<std::tuple<Array<Text>, crate::syntax::Range>>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        return append(append(bound_pg, block_scopes(t_pe)), else_scopes_ph);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EFor>(_m)) {
        auto&& binders_ok = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a0;
        auto&& b_pl = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a2;
        auto names_pm = ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            if (prism_rtl::is_some(binders_ok)) {
                auto&& fb_pn = prism_rtl::some_of(binders_ok);
                _v.set(append(crate::check::env::names::pattern_names(prism_rtl::deref(fb_pn).first), opt_pattern_names(prism_rtl::deref(fb_pn).second)));
                goto _done;
            }
            if (prism_rtl::is_none(binders_ok)) {
                _v.set(Array<Text>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        return crate::prelude::push(block_scopes(b_pl), std::tuple{names_pm, prism_rtl::deref(b_pl).span});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ERebuild>(_m)) {
        auto&& b_po = prism_rtl::as<crate::syntax::ExprKind::ERebuild>(_m).a1;
        return block_scopes(b_po);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGiven>(_m)) {
        auto&& b_pp = prism_rtl::as<crate::syntax::ExprKind::EGiven>(_m).a0;
        return block_scopes(b_pp);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EUpdate>(_m)) {
        auto&& b_pq = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a1;
        return block_scopes(b_pq);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EWidgetBlock>(_m)) {
        auto&& b_pr = prism_rtl::as<crate::syntax::ExprKind::EWidgetBlock>(_m).a0;
        return block_scopes(b_pr);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMonad>(_m)) {
        auto&& b_ps = prism_rtl::as<crate::syntax::ExprKind::EMonad>(_m).a1;
        return block_scopes(b_ps);
    }
    {
        return Array<std::tuple<Array<Text>, crate::syntax::Range>>{};
    }
}


prism_rtl::Turn<Array<std::tuple<Array<Text>, crate::syntax::Range>>> ScopesOf::cycle() const {
    const auto& e_p0 = this->e_p0;
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p0).kind);
        prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m) ? ({
        auto&& ps_o1 = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0;
        auto&& body_p2 = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a1;
        ({
        auto ps_o1_1 = ps_o1;
        auto body_p2_2 = prism_rtl::deref(prism_rtl::deref(body_p2));
        auto e_p0_3 = e_p0;
        call_value(fold_job(or_(ps_o1_1, Array<crate::syntax::Pattern_>{}), Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Pattern_> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc_p5 = p0;
                auto q_p6 = p1;
                call_then(crate::check::env::names::start_pattern_names(q_p6), [=, acc_p5 = std::move(acc_p5)](Array<Text> pattern_names_52663) { return prism_rtl::finished(append(acc_p5, pattern_names_52663)); });
            });
        }));
    }))), [=, body_p2_2 = std::move(body_p2_2), e_p0_3 = std::move(e_p0_3)](Array<Text> fold_52613) {
        return ({
            auto names_p3 = fold_52613;
            auto inner_p4 = ({
                __label__ _done;
                prism_rtl::Slot<Array<std::tuple<Array<Text>, crate::syntax::Range>>> _v;
                if (prism_rtl::is<crate::syntax::LambdaBody::LbBlock>(body_p2_2)) {
                    auto&& b_p7 = prism_rtl::as<crate::syntax::LambdaBody::LbBlock>(body_p2_2).a0;
                    _v.set(block_scopes(b_p7));
                    goto _done;
                }
                {
                    _v.set(Array<std::tuple<Array<Text>, crate::syntax::Range>>{});
                    goto _done;
                }
            _done:
                _v.take();
            });
            (prism_rtl::finished(crate::prelude::push(inner_p4, std::tuple{names_p3, prism_rtl::deref(e_p0_3).span})));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m) ? ({
        auto&& arms_p8 = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
        fold_job(arms_p8, Array<std::tuple<Array<Text>, crate::syntax::Range>>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Array<Text>, crate::syntax::Range>>>(std::tuple<Array<std::tuple<Array<Text>, crate::syntax::Range>>, crate::syntax::Arm>)>>(prism_rtl::rc([=](std::tuple<Array<std::tuple<Array<Text>, crate::syntax::Range>>, crate::syntax::Arm> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc_p9 = p0;
                auto a_pa = p1;
                ({
                auto names_pb = ({
                    __label__ _done;
                    prism_rtl::Slot<Array<Text>> _v;
                    auto&& _m = prism_rtl::deref(a_pa).pattern;
                    if (prism_rtl::is_some(_m)) {
                        auto&& q_pc = prism_rtl::some_of(_m);
                        _v.set(crate::check::env::names::pattern_names(q_pc));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(Array<Text>{});
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                (prism_rtl::finished(append(crate::prelude::push(acc_p9, std::tuple{names_pb, prism_rtl::deref(a_pa).span}), block_scopes(prism_rtl::deref(a_pa).body))));
            });
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) ? ({
        auto&& c_pd = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
        auto&& t_pe = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
        auto&& el_of = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
        ({
        auto bound_pg = ({
            __label__ _done;
            prism_rtl::Slot<Array<std::tuple<Array<Text>, crate::syntax::Range>>> _v;
            auto&& _m = prism_rtl::deref(prism_rtl::deref(c_pd));
            if (prism_rtl::is<crate::syntax::Cond::CondBind>(_m)) {
                auto&& q_pi = prism_rtl::as<crate::syntax::Cond::CondBind>(_m).a0;
                _v.set(Array(std::vector{std::tuple{crate::check::env::names::pattern_names(q_pi), prism_rtl::deref(t_pe).span}}));
                goto _done;
            }
            {
                _v.set(Array<std::tuple<Array<Text>, crate::syntax::Range>>{});
                goto _done;
            }
        _done:
            _v.take();
        });
        auto else_scopes_ph = ({
            __label__ _done;
            prism_rtl::Slot<Array<std::tuple<Array<Text>, crate::syntax::Range>>> _v;
            if (prism_rtl::is_some(el_of)) {
                auto&& b_pj = prism_rtl::some_of(el_of);
                _v.set(block_scopes(b_pj));
                goto _done;
            }
            if (prism_rtl::is_none(el_of)) {
                _v.set(Array<std::tuple<Array<Text>, crate::syntax::Range>>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        (prism_rtl::finished(append(append(bound_pg, block_scopes(t_pe)), else_scopes_ph)));
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EFor>(_m) ? ({
        auto&& binders_ok = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a0;
        auto&& b_pl = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a2;
        ({
        auto names_pm = ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            if (prism_rtl::is_some(binders_ok)) {
                auto&& fb_pn = prism_rtl::some_of(binders_ok);
                _v.set(append(crate::check::env::names::pattern_names(prism_rtl::deref(fb_pn).first), opt_pattern_names(prism_rtl::deref(fb_pn).second)));
                goto _done;
            }
            if (prism_rtl::is_none(binders_ok)) {
                _v.set(Array<Text>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        (prism_rtl::finished(crate::prelude::push(block_scopes(b_pl), std::tuple{names_pm, prism_rtl::deref(b_pl).span})));
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::ERebuild>(_m) ? ({
        auto&& b_po = prism_rtl::as<crate::syntax::ExprKind::ERebuild>(_m).a1;
        prism_rtl::finished(block_scopes(b_po));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EGiven>(_m) ? ({
        auto&& b_pp = prism_rtl::as<crate::syntax::ExprKind::EGiven>(_m).a0;
        prism_rtl::finished(block_scopes(b_pp));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EUpdate>(_m) ? ({
        auto&& b_pq = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a1;
        prism_rtl::finished(block_scopes(b_pq));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EWidgetBlock>(_m) ? ({
        auto&& b_pr = prism_rtl::as<crate::syntax::ExprKind::EWidgetBlock>(_m).a0;
        prism_rtl::finished(block_scopes(b_pr));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EMonad>(_m) ? ({
        auto&& b_ps = prism_rtl::as<crate::syntax::ExprKind::EMonad>(_m).a1;
        prism_rtl::finished(block_scopes(b_ps));
    })
        : prism_rtl::finished(Array<std::tuple<Array<Text>, crate::syntax::Range>>{});
    });
}


/// `Start ScopesOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<std::tuple<Array<Text>, crate::syntax::Range>>> start_scopes_of(crate::syntax::Expr e_p0) {
    return prism_rtl::make_rc<ScopesOf>(e_p0);
}


/// OptPatternNames: unbounded fn ?Pattern -> [Text]
Array<Text> opt_pattern_names(const std::optional<crate::syntax::Pattern_>& opt0) {
    if (prism_rtl::is_some(opt0)) {
        auto&& q_p0 = prism_rtl::some_of(opt0);
        return crate::check::env::names::pattern_names(q_p0);
    }
    if (prism_rtl::is_none(opt0)) {
        return Array<Text>{};
    }
    prism_rtl::unreachable("no arm matched");
}


/// BlockScopes: unbounded fn Block -> [(([Text], Range))]
Array<std::tuple<Array<Text>, crate::syntax::Range>> block_scopes(const crate::syntax::Block& b_p0) {
    return run_to_end(fold_job(b_p0.stmts, Array<std::tuple<Array<Text>, crate::syntax::Range>>{}, ({
        auto b_p0_1 = b_p0;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Array<Text>, crate::syntax::Range>>>(std::tuple<Array<std::tuple<Array<Text>, crate::syntax::Range>>, crate::syntax::Stmt>)>>(prism_rtl::rc([=, b_p0_1 = std::move(b_p0_1)](std::tuple<Array<std::tuple<Array<Text>, crate::syntax::Range>>, crate::syntax::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto b_p0_1_2 = b_p0_1;
            entered(once_job([=, b_p0_1_2 = std::move(b_p0_1_2)]() {
            return ({
                auto acc_p1 = p0;
                auto s_p2 = p1;
                call_then(crate::check::blocks::start_group_defs(s_p2), [=, acc_p1 = std::move(acc_p1)](Array<Text> group_defs_54099) {
                return ({
                    auto own_p3 = crate::prelude::push(acc_p1, std::tuple{group_defs_54099, crate::syntax::Range{.start = prism_rtl::deref(prism_rtl::deref(s_p2).span).start, .end = prism_rtl::deref(b_p0_1_2.span).end}});
                    ({
                    auto&& _m = prism_rtl::deref(s_p2).kind;
                    prism_rtl::is<crate::syntax::StmtKind::SFn>(_m) ? ({
                    auto&& f_p4 = prism_rtl::as<crate::syntax::StmtKind::SFn>(_m).a0;
                    ({
                    auto f_p4_2 = f_p4;
                    call_value(fold_job(prism_rtl::deref(f_p4_2).params, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Pattern_> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return entered(once_job([=]() {
                        return ({
                            auto ps_p5 = p0;
                            auto q_p6 = p1;
                            call_then(crate::check::env::names::start_pattern_names(q_p6), [=, ps_p5 = std::move(ps_p5)](Array<Text> pattern_names_54257) { return prism_rtl::finished(append(ps_p5, pattern_names_54257)); });
                        });
                    }));
                }))), [=](Array<Text> fold_54215) { return prism_rtl::finished(crate::prelude::push(own_p3, std::tuple{fold_54215, prism_rtl::deref(f_p4_2).span})); });
                });
                })
                    : prism_rtl::finished(own_p3);
                });
                });
            });
            });
        }));
        });
    }));
    })));
}


/// LambdaReads: unbounded fn [Pattern], LambdaBody -> [Text]
Array<Text> lambda_reads(const Array<crate::syntax::Pattern_>& ps_p0, const crate::syntax::LambdaBody& body_p1) {
    auto own_p2 = run_to_end(fold_job(ps_p0, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Pattern_> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc_p3 = p0;
                auto q_p4 = p1;
                call_then(crate::check::env::names::start_pattern_names(q_p4), [=, acc_p3 = std::move(acc_p3)](Array<Text> pattern_names_54601) { return prism_rtl::finished(append(acc_p3, pattern_names_54601)); });
            });
        }));
    }))));
    return filter(free_reads(lambda_exprs(body_p1), Array<std::tuple<Array<Text>, crate::syntax::Range>>{}), [&](const Text& n_p5) { return !crate::check::types::has_text(own_p2, n_p5); });
}


prism_rtl::Turn<Array<Text>> LambdaReads::cycle() const {
    const auto& ps_p0 = this->ps_p0;
    const auto& body_p1 = this->body_p1;
    auto body_p1_1 = body_p1;
    auto ps_p0_2 = ps_p0;
    return call_value(fold_job(ps_p0_2, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Pattern_> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc_p3 = p0;
                auto q_p4 = p1;
                call_then(crate::check::env::names::start_pattern_names(q_p4), [=, acc_p3 = std::move(acc_p3)](Array<Text> pattern_names_54601) { return prism_rtl::finished(append(acc_p3, pattern_names_54601)); });
            });
        }));
    }))), [=](Array<Text> fold_54563) {
        return ({
            auto own_p2 = fold_54563;
            call_then(start_lambda_exprs(body_p1_1), [=, own_p2 = std::move(own_p2)](Array<crate::syntax::Expr> lambda_exprs_54640) { return call_then(start_free_reads(lambda_exprs_54640, Array<std::tuple<Array<Text>, crate::syntax::Range>>{}), [=](Array<Text> free_reads_54629) { return prism_rtl::finished(filter(free_reads_54629, [&](const Text& n_p5) { return !crate::check::types::has_text(own_p2, n_p5); })); }); });
        });
    });
}


/// `Start LambdaReads, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_lambda_reads(Array<crate::syntax::Pattern_> ps_p0, crate::syntax::LambdaBody body_p1) {
    return prism_rtl::make_rc<LambdaReads>(ps_p0, body_p1);
}


/// LambdaValue: unbounded fn Lx, Env, Expr, [Pattern], LambdaBody -> Vl
crate::lower::types::Vl lambda_value(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& e_p2, const Array<crate::syntax::Pattern_>& ps_p3, const crate::syntax::LambdaBody& body_p4) {
    auto ft_p5 = crate::lower::types::out_ty_of(lx_p0, crate::lower::types::peel(crate::lower::type_at(lx_p0, e_p2.span)));
    if (prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(ft_p5)) {
        auto&& a_p6 = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(ft_p5).a0;
        return job_lambda(lx_p0, env_p1, ps_p3, body_p4, ft_p5, prism_rtl::deref(prism_rtl::deref(a_p6)), enters_lambda(lx_p0, e_p2));
    }
    {
        return plain_lambda(lx_p0, env_p1, ps_p3, body_p4, ft_p5);
    }
}


prism_rtl::Turn<crate::lower::types::Vl> LambdaValue::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& e_p2 = this->e_p2;
    const auto& ps_p3 = this->ps_p3;
    const auto& body_p4 = this->body_p4;
    auto body_p4_1 = body_p4;
    auto e_p2_2 = e_p2;
    auto env_p1_3 = env_p1;
    auto lx_p0_4 = lx_p0;
    auto ps_p3_5 = ps_p3;
    return call_then(crate::lower::types::start_out_ty_of(lx_p0_4, crate::lower::types::peel(crate::lower::type_at(lx_p0_4, prism_rtl::deref(e_p2_2).span))), [=](crate::lower::model::OutTy out_ty_of_54938) {
        return ({
            auto ft_p5 = out_ty_of_54938;
            ({
            prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(ft_p5) ? ({
            auto&& a_p6 = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(ft_p5).a0;
            prism_rtl::more(prism_rtl::rc(JobLambda(lx_p0_4, env_p1_3, ps_p3_5, body_p4_1, ft_p5, prism_rtl::deref(prism_rtl::deref(a_p6)), enters_lambda(lx_p0_4, e_p2_2))));
        })
            : prism_rtl::more(prism_rtl::rc(PlainLambda(lx_p0_4, env_p1_3, ps_p3_5, body_p4_1, ft_p5)));
        });
        });
    });
}


/// `Start LambdaValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_lambda_value(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr e_p2, Array<crate::syntax::Pattern_> ps_p3, crate::syntax::LambdaBody body_p4) {
    return prism_rtl::make_rc<LambdaValue>(lx_p0, env_p1, e_p2, ps_p3, body_p4);
}


/// PlainLambda: unbounded fn Lx, Env, [Pattern], LambdaBody, OutTy -> Vl
crate::lower::types::Vl plain_lambda(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const Array<crate::syntax::Pattern_>& ps_p2, const crate::syntax::LambdaBody& body_p3, const crate::lower::model::OutTy& ft_p4) {
    auto pts_p5 = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::lower::model::OutTy>> _v;
        if (prism_rtl::is<crate::lower::model::OutTy::OutFn>(ft_p4)) {
            auto&& xs_pa = prism_rtl::as<crate::lower::model::OutTy::OutFn>(ft_p4).a0;
            _v.set(xs_pa);
            goto _done;
        }
        {
            _v.set(Array<crate::lower::model::OutTy>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto read_p6 = crate::lower::types::with_instances(env_p1, lambda_reads(ps_p2, body_p3));
    auto caps0_p7 = filter(read_p6, [&](const Text& n_pb) {
        return ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            auto&& _m = crate::prelude::get(env_p1.names, n_pb);
            if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m))) {
                _v.set(true);
                goto _done;
            }
            {
                _v.set(false);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto caps_p8 = append(append(caps0_p7, filter(each(read_p6, [&](const Text& n_pc) { return prism_rtl::cat(n_pc, "#port"); }), [&](const Text& n_pd) { return crate::check::env::has_key(env_p1.names, n_pd); })), filter(each(read_p6, [&](const Text& n_pe) { return prism_rtl::cat(n_pe, "#init"); }), [&](const Text& n_pf) { return crate::check::env::has_key(env_p1.names, n_pf); }));
    auto [dos_po, env1_pp] = fold(caps_p8, std::tuple{Array<crate::lower::model::Do>{}, env_p1}, [&](const std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>& _p0, const Text& n_pi) {
        auto&& acc_pg = std::get<0>(_p0);
        auto&& en_ph = std::get<1>(_p0);
        return ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> _v;
            auto&& _m = crate::prelude::get(env_p1.names, n_pi);
            if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m))) {
                auto&& rs_pj = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                auto&& mode_pk = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a1;
                auto&& ct_pl = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                _v.set(({
                    auto local_pm = crate::lower::types::place_stem(rs_pj);
                    auto d_pn = crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{local_pm}), crate::lower::types::own(crate::lower::types::local_place(rs_pj, mode_pk, ct_pl))});
                    std::tuple{crate::prelude::push(acc_pg, d_pn), crate::lower::types::bind(en_ph, n_pi, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{local_pm}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), ct_pl}))};
                }));
                goto _done;
            }
            {
                _v.set(std::tuple{acc_pg, en_ph});
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto [pas_pq, env2_pr] = closure_params(lx_p0, env1_pp, ps_p2, pts_p5, true);
    auto v_p9 = lambda_body_value(lx_p0, env2_pr, body_p3);
    return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBlock{dos_po, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCast{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, pas_pq, prism_rtl::rc(crate::lower::types::own(v_p9))})})})), ft_p4}))}), ft_p4});
}


prism_rtl::Turn<crate::lower::types::Vl> PlainLambda::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& ps_p2 = this->ps_p2;
    const auto& body_p3 = this->body_p3;
    const auto& ft_p4 = this->ft_p4;
    auto pts_p5 = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::lower::model::OutTy>> _v;
        if (prism_rtl::is<crate::lower::model::OutTy::OutFn>(ft_p4)) {
            auto&& xs_pa = prism_rtl::as<crate::lower::model::OutTy::OutFn>(ft_p4).a0;
            _v.set(xs_pa);
            goto _done;
        }
        {
            _v.set(Array<crate::lower::model::OutTy>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto body_p3_1 = body_p3;
    auto env_p1_2 = env_p1;
    auto ft_p4_3 = ft_p4;
    auto lx_p0_4 = lx_p0;
    auto ps_p2_5 = ps_p2;
    return call_then(start_lambda_reads(ps_p2_5, body_p3_1), [=](Array<Text> lambda_reads_55350) {
        return ({
            auto read_p6 = crate::lower::types::with_instances(env_p1_2, lambda_reads_55350);
            auto caps0_p7 = filter(read_p6, [&](const Text& n_pb) {
                return ({
                    __label__ _done;
                    prism_rtl::Slot<bool> _v;
                    auto&& _m = crate::prelude::get(env_p1_2->names, n_pb);
                    if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m))) {
                        _v.set(true);
                        goto _done;
                    }
                    {
                        _v.set(false);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
            });
            auto caps_p8 = append(append(caps0_p7, filter(each(read_p6, [&](const Text& n_pc) { return prism_rtl::cat(n_pc, "#port"); }), [&](const Text& n_pd) { return crate::check::env::has_key(env_p1_2->names, n_pd); })), filter(each(read_p6, [&](const Text& n_pe) { return prism_rtl::cat(n_pe, "#init"); }), [&](const Text& n_pf) { return crate::check::env::has_key(env_p1_2->names, n_pf); }));
            auto [dos_po, env1_pp] = fold(caps_p8, std::tuple{Array<crate::lower::model::Do>{}, env_p1_2}, [&](const std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>& _p0, const Text& n_pi) {
                auto&& acc_pg = std::get<0>(_p0);
                auto&& en_ph = std::get<1>(_p0);
                return ({
                    __label__ _done;
                    prism_rtl::Slot<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> _v;
                    auto&& _m = crate::prelude::get(env_p1_2->names, n_pi);
                    if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m))) {
                        auto&& rs_pj = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                        auto&& mode_pk = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a1;
                        auto&& ct_pl = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                        _v.set(({
                            auto local_pm = crate::lower::types::place_stem(rs_pj);
                            auto d_pn = crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{local_pm}), crate::lower::types::own(crate::lower::types::local_place(rs_pj, mode_pk, ct_pl))});
                            std::tuple{crate::prelude::push(acc_pg, d_pn), crate::lower::types::bind(en_ph, n_pi, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{local_pm}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), ct_pl}))};
                        }));
                        goto _done;
                    }
                    {
                        _v.set(std::tuple{acc_pg, en_ph});
                        goto _done;
                    }
                _done:
                    _v.take();
                });
            });
            call_then(start_closure_params(lx_p0_4, env1_pp, ps_p2_5, pts_p5, true), [=](std::tuple<Array<crate::lower::model::Pa>, crate::lower::types::Env> closure_params_56236) {
            return ({
                auto [pas_pq, env2_pr] = closure_params_56236;
                call_then(start_lambda_body_value(lx_p0_4, env2_pr, body_p3_1), [=](crate::lower::types::Vl lambda_body_value_56286) {
                return ({
                    auto v_p9 = lambda_body_value_56286;
                    (prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBlock{dos_po, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCast{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, pas_pq, prism_rtl::rc(crate::lower::types::own(v_p9))})})})), ft_p4_3}))}), ft_p4_3})));
                });
            });
            });
        });
        });
    });
}


/// `Start PlainLambda, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_plain_lambda(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, Array<crate::syntax::Pattern_> ps_p2, crate::syntax::LambdaBody body_p3, crate::lower::model::OutTy ft_p4) {
    return prism_rtl::make_rc<PlainLambda>(lx_p0, env_p1, ps_p2, body_p3, ft_p4);
}


/// LambdaParamTys: unbounded fn Lx, Expr, Nat -> [OutTy]
Array<crate::lower::model::OutTy> lambda_param_tys(const crate::lower::Lx& lx_p0, const crate::syntax::Expr& e_p1, const Nat& n_p2) {
    auto ts_p3 = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::lower::model::OutTy>> _v;
        auto&& _m = crate::lower::types::out_ty_of(lx_p0, crate::lower::types::peel(crate::lower::type_at(lx_p0, e_p1.span)));
        if (prism_rtl::is<crate::lower::model::OutTy::OutFn>(_m)) {
            auto&& xs_p4 = prism_rtl::as<crate::lower::model::OutTy::OutFn>(_m).a0;
            _v.set(xs_p4);
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(_m)) {
            auto&& a_p5 = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(_m).a0;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<Array<crate::lower::model::OutTy>> _v;
                auto&& _m = prism_rtl::deref(a_p5);
                if (prism_rtl::is<crate::lower::model::OutTy::OutTuple>(_m)) {
                    auto&& xs_p6 = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(_m).a0;
                    _v.set(n_p2 == Nat(1u) ? Array(std::vector{prism_rtl::deref(a_p5)}) : xs_p6);
                    goto _done;
                }
                {
                    _v.set(Array(std::vector{prism_rtl::deref(a_p5)}));
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        {
            _v.set(Array<crate::lower::model::OutTy>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    return (len(ts_p3) == n_p2) && run_to_end(fold_job(ts_p3, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<bool, crate::lower::model::OutTy> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto ok_p7 = p0;
                auto t_p8 = p1;
                (prism_rtl::finished(std::move(ok_p7) && is_known_ty(t_p8)));
            });
        }));
    }))))
        ? ts_p3
        : Array<crate::lower::model::OutTy>{};
}


prism_rtl::Turn<Array<crate::lower::model::OutTy>> LambdaParamTys::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& e_p1 = this->e_p1;
    const auto& n_p2 = this->n_p2;
    auto e_p1_1 = e_p1;
    auto lx_p0_2 = lx_p0;
    auto n_p2_3 = n_p2;
    return call_then(crate::lower::types::start_out_ty_of(lx_p0_2, crate::lower::types::peel(crate::lower::type_at(lx_p0_2, prism_rtl::deref(e_p1_1).span))), [=](crate::lower::model::OutTy out_ty_of_56877) {
        return ({
            auto ts_p3 = ({
                __label__ _done;
                prism_rtl::Slot<Array<crate::lower::model::OutTy>> _v;
                if (prism_rtl::is<crate::lower::model::OutTy::OutFn>(out_ty_of_56877)) {
                    auto&& xs_p4 = prism_rtl::as<crate::lower::model::OutTy::OutFn>(out_ty_of_56877).a0;
                    _v.set(xs_p4);
                    goto _done;
                }
                if (prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(out_ty_of_56877)) {
                    auto&& a_p5 = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(out_ty_of_56877).a0;
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<Array<crate::lower::model::OutTy>> _v;
                        auto&& _m = prism_rtl::deref(a_p5);
                        if (prism_rtl::is<crate::lower::model::OutTy::OutTuple>(_m)) {
                            auto&& xs_p6 = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(_m).a0;
                            _v.set(n_p2_3 == Nat(1u) ? Array(std::vector{prism_rtl::deref(a_p5)}) : xs_p6);
                            goto _done;
                        }
                        {
                            _v.set(Array(std::vector{prism_rtl::deref(a_p5)}));
                            goto _done;
                        }
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                {
                    _v.set(Array<crate::lower::model::OutTy>{});
                    goto _done;
                }
            _done:
                _v.take();
            });
            (len(ts_p3) == n_p2_3) && run_to_end(fold_job(ts_p3, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<bool, crate::lower::model::OutTy> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto ok_p7 = p0;
                    auto t_p8 = p1;
                    (prism_rtl::finished(std::move(ok_p7) && is_known_ty(t_p8)));
                });
            }));
        }))))
            ? prism_rtl::finished(ts_p3)
            : prism_rtl::finished(Array<crate::lower::model::OutTy>{});
        });
    });
}


/// `Start LambdaParamTys, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::lower::model::OutTy>> start_lambda_param_tys(crate::lower::Lx lx_p0, crate::syntax::Expr e_p1, Nat n_p2) {
    return prism_rtl::make_rc<LambdaParamTys>(lx_p0, e_p1, n_p2);
}


/// IsKnownTy: unbounded fn OutTy -> Bool
bool is_known_ty(const crate::lower::model::OutTy& t_p0) {
    if (prism_rtl::is<crate::lower::model::OutTy::OutUnknown>(t_p0)) {
        return false;
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutOpt>(t_p0)) {
        auto&& x_p1 = prism_rtl::as<crate::lower::model::OutTy::OutOpt>(t_p0).a0;
        return is_known_ty(prism_rtl::deref(prism_rtl::deref(x_p1)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutRes>(t_p0)) {
        auto&& x_p2 = prism_rtl::as<crate::lower::model::OutTy::OutRes>(t_p0).a0;
        return is_known_ty(prism_rtl::deref(prism_rtl::deref(x_p2)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutArray>(t_p0)) {
        auto&& x_p3 = prism_rtl::as<crate::lower::model::OutTy::OutArray>(t_p0).a0;
        return is_known_ty(prism_rtl::deref(prism_rtl::deref(x_p3)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutRc>(t_p0)) {
        auto&& x_p4 = prism_rtl::as<crate::lower::model::OutTy::OutRc>(t_p0).a0;
        return is_known_ty(prism_rtl::deref(prism_rtl::deref(x_p4)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutMap>(t_p0)) {
        auto&& k_p5 = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t_p0).a0;
        auto&& v_p6 = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t_p0).a1;
        return is_known_ty(prism_rtl::deref(prism_rtl::deref(k_p5))) && is_known_ty(prism_rtl::deref(prism_rtl::deref(v_p6)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutTuple>(t_p0)) {
        auto&& xs_p7 = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(t_p0).a0;
        return run_to_end(fold_job(xs_p7, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<bool, crate::lower::model::OutTy> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto ok_p8 = p0;
                    auto x_p9 = p1;
                    (prism_rtl::finished(std::move(ok_p8) && is_known_ty(x_p9)));
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t_p0)) {
        auto&& xs_pa = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p0).a1;
        return run_to_end(fold_job(xs_pa, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<bool, crate::lower::model::OutTy> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto ok_pb = p0;
                    auto x_pc = p1;
                    (prism_rtl::finished(std::move(ok_pb) && is_known_ty(x_pc)));
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutFn>(t_p0)) {
        auto&& xs_pd = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t_p0).a0;
        auto&& r_pe = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t_p0).a1;
        return run_to_end(fold_job(xs_pd, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<bool, crate::lower::model::OutTy> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto ok_pf = p0;
                    auto x_pg = p1;
                    (prism_rtl::finished(std::move(ok_pf) && is_known_ty(x_pg)));
                });
            }));
        })))) && is_known_ty(prism_rtl::deref(prism_rtl::deref(r_pe)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(t_p0)) {
        auto&& a_ph = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(t_p0).a0;
        auto&& b_pi = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(t_p0).a1;
        return is_known_ty(prism_rtl::deref(prism_rtl::deref(a_ph))) && is_known_ty(prism_rtl::deref(prism_rtl::deref(b_pi)));
    }
    {
        return true;
    }
}


prism_rtl::Turn<bool> IsKnownTy::cycle() const {
    const auto& t_p0 = this->t_p0;
    return ({
        prism_rtl::is<crate::lower::model::OutTy::OutUnknown>(t_p0) ? prism_rtl::finished(false)
        : prism_rtl::is<crate::lower::model::OutTy::OutOpt>(t_p0) ? ({
        auto&& x_p1 = prism_rtl::as<crate::lower::model::OutTy::OutOpt>(t_p0).a0;
        prism_rtl::more(prism_rtl::rc(IsKnownTy(prism_rtl::deref(prism_rtl::deref(x_p1)))));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutRes>(t_p0) ? ({
        auto&& x_p2 = prism_rtl::as<crate::lower::model::OutTy::OutRes>(t_p0).a0;
        prism_rtl::more(prism_rtl::rc(IsKnownTy(prism_rtl::deref(prism_rtl::deref(x_p2)))));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutArray>(t_p0) ? ({
        auto&& x_p3 = prism_rtl::as<crate::lower::model::OutTy::OutArray>(t_p0).a0;
        prism_rtl::more(prism_rtl::rc(IsKnownTy(prism_rtl::deref(prism_rtl::deref(x_p3)))));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutRc>(t_p0) ? ({
        auto&& x_p4 = prism_rtl::as<crate::lower::model::OutTy::OutRc>(t_p0).a0;
        prism_rtl::more(prism_rtl::rc(IsKnownTy(prism_rtl::deref(prism_rtl::deref(x_p4)))));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutMap>(t_p0) ? ({
        auto&& k_p5 = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t_p0).a0;
        auto&& v_p6 = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t_p0).a1;
        ({
        auto k_p5_1 = prism_rtl::deref(prism_rtl::deref(k_p5));
        auto v_p6_2 = prism_rtl::deref(prism_rtl::deref(v_p6));
        call_then(start_is_known_ty(k_p5_1), [=, v_p6_2 = std::move(v_p6_2)](bool is_known_ty_57387) { return prism_rtl::finished(is_known_ty_57387 && is_known_ty(v_p6_2)); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutTuple>(t_p0) ? ({
        auto&& xs_p7 = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(t_p0).a0;
        fold_job(xs_p7, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<bool, crate::lower::model::OutTy> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto ok_p8 = p0;
                auto x_p9 = p1;
                (prism_rtl::finished(std::move(ok_p8) && is_known_ty(x_p9)));
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t_p0) ? ({
        auto&& xs_pa = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p0).a1;
        fold_job(xs_pa, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<bool, crate::lower::model::OutTy> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto ok_pb = p0;
                auto x_pc = p1;
                (prism_rtl::finished(std::move(ok_pb) && is_known_ty(x_pc)));
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutFn>(t_p0) ? ({
        auto&& xs_pd = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t_p0).a0;
        auto&& r_pe = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t_p0).a1;
        ({
        auto r_pe_1 = prism_rtl::deref(prism_rtl::deref(r_pe));
        auto xs_pd_2 = xs_pd;
        call_value(fold_job(xs_pd_2, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<bool, crate::lower::model::OutTy> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto ok_pf = p0;
                auto x_pg = p1;
                (prism_rtl::finished(std::move(ok_pf) && is_known_ty(x_pg)));
            });
        }));
    }))), [=, r_pe_1 = std::move(r_pe_1)](bool fold_57562) { return prism_rtl::finished(fold_57562 && is_known_ty(r_pe_1)); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(t_p0) ? ({
        auto&& a_ph = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(t_p0).a0;
        auto&& b_pi = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(t_p0).a1;
        ({
        auto a_ph_1 = prism_rtl::deref(prism_rtl::deref(a_ph));
        auto b_pi_2 = prism_rtl::deref(prism_rtl::deref(b_pi));
        call_then(start_is_known_ty(a_ph_1), [=, b_pi_2 = std::move(b_pi_2)](bool is_known_ty_57642) { return prism_rtl::finished(is_known_ty_57642 && is_known_ty(b_pi_2)); });
    });
    })
        : prism_rtl::finished(true);
    });
}


/// `Start IsKnownTy, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_is_known_ty(crate::lower::model::OutTy t_p0) {
    return prism_rtl::make_rc<IsKnownTy>(t_p0);
}


/// JobLambda: unbounded fn Lx, Env, [Pattern], LambdaBody, OutTy, OutTy, Bool -> Vl
crate::lower::types::Vl job_lambda(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const Array<crate::syntax::Pattern_>& ps_p2, const crate::syntax::LambdaBody& body_p3, const crate::lower::model::OutTy& ft_p4, const crate::lower::model::OutTy& a_p5, const bool& enter_p6) {
    auto caps_p7 = filter(crate::lower::types::with_instances(env_p1, lambda_reads(ps_p2, body_p3)), [&](const Text& n_pm) {
        return ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            auto&& _m = crate::prelude::get(env_p1.names, n_pm);
            if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m))) {
                _v.set(true);
                goto _done;
            }
            {
                _v.set(false);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto [dos_pu, env1_pv] = fold(caps_p7, std::tuple{Array<crate::lower::model::Do>{}, env_p1}, [&](const std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>& _p0, const Text& n_pp) {
        auto&& acc_pn = std::get<0>(_p0);
        auto&& en_po = std::get<1>(_p0);
        return ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> _v;
            auto&& _m = crate::prelude::get(env_p1.names, n_pp);
            if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m))) {
                auto&& rs_pq = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                auto&& mode_pr = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a1;
                auto&& ct_ps = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                _v.set(({
                    auto d_pt = crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{crate::lower::types::place_stem(rs_pq)}), crate::lower::types::own(crate::lower::types::local_place(rs_pq, mode_pr, ct_ps))});
                    std::tuple{crate::prelude::push(acc_pn, d_pt), crate::lower::types::bind(en_po, n_pp, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{crate::lower::types::place_stem(rs_pq)}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), ct_ps}))};
                }));
                goto _done;
            }
            {
                _v.set(std::tuple{acc_pn, en_po});
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto again_p8 = fold(caps_p7, Array<crate::lower::model::Do>{}, [&](const Array<crate::lower::model::Do>& acc_p10, const Text& n_p11) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::lower::model::Do>> _v;
            auto&& _m = crate::prelude::get(env1_pv->names, n_p11);
            if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m))) {
                auto&& rs_p12 = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                auto&& ct_p13 = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                _v.set(crate::prelude::push(acc_p10, crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{crate::lower::types::place_stem(rs_p12)}), crate::lower::types::own(crate::lower::types::local_place(rs_p12, crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), ct_p13))})));
                goto _done;
            }
            {
                _v.set(acc_p10);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto pts_p9 = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::lower::model::OutTy>> _v;
        if (prism_rtl::is<crate::lower::model::OutTy::OutTuple>(a_p5)) {
            auto&& ts_p14 = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(a_p5).a0;
            _v.set(len(ps_p2) == Nat(1u) ? Array(std::vector{a_p5}) : ts_p14);
            goto _done;
        }
        {
            _v.set(Array(std::vector{a_p5}));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto env1b_pa = only_captured(env1_pv, caps_p7);
    auto pos_pb = run_to_end(each_job(crate::check::errors::range0(len(ps_p2)), ({
        auto ps_p2_1 = ps_p2;
        auto lx_p0_2 = lx_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::patterns::PatOut>(Nat)>>(prism_rtl::rc([=, ps_p2_1 = std::move(ps_p2_1), lx_p0_2 = std::move(lx_p0_2)](Nat p0) {
        return ({
            auto ps_p2_1_3 = ps_p2_1;
            auto lx_p0_2_3 = lx_p0_2;
            entered(once_job([=, ps_p2_1_3 = std::move(ps_p2_1_3), lx_p0_2_3 = std::move(lx_p0_2_3)]() {
            return ({
                auto i_p15 = p0;
                ({
                auto p_p16 = or_(index(ps_p2_1_3, i_p15), crate::lower::patterns::dummy_pat());
                (prism_rtl::more(prism_rtl::rc(crate::lower::patterns::RustPat(lx_p0_2_3, p_p16, binder_ty_of_pattern(lx_p0_2_3, p_p16), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat("p", i_p15, "_")))));
            });
            });
        }));
        });
    })));
    })));
    auto unpack_pc = fold(crate::check::errors::range0(len(pos_pb)), Array<crate::lower::model::Do>{}, [&](const Array<crate::lower::model::Do>& acc_p17, const Nat& i_p18) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::lower::model::Do>> _v;
            auto&& _m = index(pos_pb, i_p18);
            if (prism_rtl::is_some(_m)) {
                auto&& po_p19 = prism_rtl::some_of(_m);
                _v.set(append(crate::prelude::push(acc_p17, crate::lower::model::Do(crate::lower::model::Do::DoLet{prism_rtl::deref(po_p19).pa, crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat("p", i_p18)})})), each(prism_rtl::deref(po_p19).conds, [&](const crate::lower::model::Cc& c_p1a) { return cond_as_let(c_p1a); })));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(acc_p17);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
    auto pos2_pd = each(crate::check::errors::range0(len(pos_pb)), [&](const Nat& i_p1b) {
        return ({
            __label__ _done;
            prism_rtl::Slot<crate::lower::patterns::PatOut> _v;
            auto&& _m = index(pos_pb, i_p1b);
            if (prism_rtl::is_some(_m)) {
                auto&& po_p1c = prism_rtl::some_of(_m);
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<crate::lower::patterns::PatOut> _v;
                    auto&& _m = prism_rtl::deref(prism_rtl::deref(or_(index(ps_p2, i_p1b), crate::lower::patterns::dummy_pat())).kind);
                    if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
                        _v.set(({
                            crate::lower::patterns::PatOut this_ = po_p1c;
                            this_.binds = each(this_.binds, [&](const std::tuple<Text, crate::lower::types::Bn>& _p0) {
                                auto&& n_p1d = std::get<0>(_p0);
                                auto&& b_p1e = std::get<1>(_p0);
                                return ({
                                    __label__ _done;
                                    prism_rtl::Slot<std::tuple<Text, crate::lower::types::Bn>> _v;
                                    if (prism_rtl::is<crate::lower::types::Bn::BnLocal>(b_p1e)) {
                                        auto&& rs_p1f = prism_rtl::as<crate::lower::types::Bn::BnLocal>(b_p1e).a0;
                                        auto&& mode_p1g = prism_rtl::as<crate::lower::types::Bn::BnLocal>(b_p1e).a1;
                                        auto&& bt_p1h = prism_rtl::as<crate::lower::types::Bn::BnLocal>(b_p1e).a2;
                                        _v.set(std::tuple{n_p1d, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{rs_p1f, mode_p1g, or_(index(pts_p9, i_p1b), bt_p1h)})});
                                        goto _done;
                                    }
                                    {
                                        _v.set(std::tuple{n_p1d, b_p1e});
                                        goto _done;
                                    }
                                _done:
                                    _v.take();
                                });
                            });
                            (std::move(this_));
                        }));
                        goto _done;
                    }
                    {
                        _v.set(po_p1c);
                        goto _done;
                    }
                _done:
                    _v.take();
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(crate::lower::patterns::PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds = Array<crate::lower::model::Cc>{}, .binds = Array<std::tuple<Text, crate::lower::types::Bn>>{}});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
    auto env2_pe = fold(pos2_pd, env1b_pa, [&](const crate::lower::types::Env& en_p1i, const crate::lower::patterns::PatOut& po_p1j) { return bind_all(en_p1i, prism_rtl::deref(po_p1j).binds); });
    auto names_pf = each(crate::check::errors::range0(len(ps_p2)), [&](const Nat& i_p1k) { return prism_rtl::cat("p", i_p1k); });
    auto pa_pg = len(ps_p2) == Nat(1u)
        ? crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("p0")})), a_p5})
        : crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{each(names_pf, [&](const Text& nm_p1l) { return crate::lower::model::Pa(crate::lower::model::Pa::PaBind{nm_p1l}); })})), a_p5});
    auto tail0_ph = ({
        __label__ _done;
        prism_rtl::Slot<crate::lower::model::Ex> _v;
        if (prism_rtl::is<crate::syntax::LambdaBody::LbExpr>(body_p3)) {
            auto&& x_p1m = prism_rtl::as<crate::syntax::LambdaBody::LbExpr>(body_p3).a0;
            _v.set(crate::lower::jobs::tail(lx_p0, env2_pe, prism_rtl::deref(prism_rtl::deref(x_p1m))));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::LambdaBody::LbBlock>(body_p3)) {
            auto&& bl_p1n = prism_rtl::as<crate::syntax::LambdaBody::LbBlock>(body_p3).a0;
            _v.set(crate::lower::jobs::tail_block(lx_p0, env2_pe, bl_p1n));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto tail_pi = len(unpack_pc) == Nat(0u)
        ? tail0_ph
        : crate::lower::model::Ex(crate::lower::model::Ex::XBlock{unpack_pc, prism_rtl::rc(tail0_ph)});
    auto job0_pj = crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("once_job"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array<crate::lower::model::Pa>{}, prism_rtl::rc(tail_pi)})})});
    auto job_pk = enter_p6
        ? crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("entered"), Array(std::vector{job0_pj})})
        : job0_pj;
    auto call_pl = len(again_p8) == Nat(0u)
        ? job_pk
        : crate::lower::model::Ex(crate::lower::model::Ex::XBlock{again_p8, prism_rtl::rc(job_pk)});
    return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBlock{dos_pu, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCast{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{pa_pg}), prism_rtl::rc(call_pl)})})})), ft_p4}))}), ft_p4});
}


prism_rtl::Turn<crate::lower::types::Vl> JobLambda::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& ps_p2 = this->ps_p2;
    const auto& body_p3 = this->body_p3;
    const auto& ft_p4 = this->ft_p4;
    const auto& a_p5 = this->a_p5;
    const auto& enter_p6 = this->enter_p6;
    auto a_p5_1 = a_p5;
    auto body_p3_2 = body_p3;
    auto enter_p6_3 = prism_rtl::deref(enter_p6);
    auto env_p1_4 = env_p1;
    auto ft_p4_5 = ft_p4;
    auto lx_p0_6 = lx_p0;
    auto ps_p2_7 = ps_p2;
    return call_then(start_lambda_reads(ps_p2_7, body_p3_2), [=](Array<Text> lambda_reads_58509) {
        return ({
            auto caps_p7 = filter(crate::lower::types::with_instances(env_p1_4, lambda_reads_58509), [&](const Text& n_pm) {
                return ({
                    __label__ _done;
                    prism_rtl::Slot<bool> _v;
                    auto&& _m = crate::prelude::get(env_p1_4->names, n_pm);
                    if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m))) {
                        _v.set(true);
                        goto _done;
                    }
                    {
                        _v.set(false);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
            });
            auto [dos_pu, env1_pv] = fold(caps_p7, std::tuple{Array<crate::lower::model::Do>{}, env_p1_4}, [&](const std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>& _p0, const Text& n_pp) {
                auto&& acc_pn = std::get<0>(_p0);
                auto&& en_po = std::get<1>(_p0);
                return ({
                    __label__ _done;
                    prism_rtl::Slot<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> _v;
                    auto&& _m = crate::prelude::get(env_p1_4->names, n_pp);
                    if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m))) {
                        auto&& rs_pq = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                        auto&& mode_pr = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a1;
                        auto&& ct_ps = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                        _v.set(({
                            auto d_pt = crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{crate::lower::types::place_stem(rs_pq)}), crate::lower::types::own(crate::lower::types::local_place(rs_pq, mode_pr, ct_ps))});
                            std::tuple{crate::prelude::push(acc_pn, d_pt), crate::lower::types::bind(en_po, n_pp, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{crate::lower::types::place_stem(rs_pq)}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), ct_ps}))};
                        }));
                        goto _done;
                    }
                    {
                        _v.set(std::tuple{acc_pn, en_po});
                        goto _done;
                    }
                _done:
                    _v.take();
                });
            });
            auto again_p8 = fold(caps_p7, Array<crate::lower::model::Do>{}, [&](const Array<crate::lower::model::Do>& acc_p10, const Text& n_p11) {
                return ({
                    __label__ _done;
                    prism_rtl::Slot<Array<crate::lower::model::Do>> _v;
                    auto&& _m = crate::prelude::get(env1_pv->names, n_p11);
                    if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m))) {
                        auto&& rs_p12 = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                        auto&& ct_p13 = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                        _v.set(crate::prelude::push(acc_p10, crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{crate::lower::types::place_stem(rs_p12)}), crate::lower::types::own(crate::lower::types::local_place(rs_p12, crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), ct_p13))})));
                        goto _done;
                    }
                    {
                        _v.set(acc_p10);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
            });
            auto pts_p9 = ({
                __label__ _done;
                prism_rtl::Slot<Array<crate::lower::model::OutTy>> _v;
                if (prism_rtl::is<crate::lower::model::OutTy::OutTuple>(a_p5_1)) {
                    auto&& ts_p14 = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(a_p5_1).a0;
                    _v.set(len(ps_p2_7) == Nat(1u) ? Array(std::vector{a_p5_1}) : ts_p14);
                    goto _done;
                }
                {
                    _v.set(Array(std::vector{a_p5_1}));
                    goto _done;
                }
            _done:
                _v.take();
            });
            auto env1b_pa = only_captured(env1_pv, caps_p7);
            call_value(each_job(crate::check::errors::range0(len(ps_p2_7)), ({
            auto ps_p2_7_8 = ps_p2_7;
            auto lx_p0_6_8 = lx_p0_6;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::patterns::PatOut>(Nat)>>(prism_rtl::rc([=, ps_p2_7_8 = std::move(ps_p2_7_8), lx_p0_6_8 = std::move(lx_p0_6_8)](Nat p0) {
            return ({
                auto ps_p2_7_8_8 = ps_p2_7_8;
                auto lx_p0_6_8_8 = lx_p0_6_8;
                entered(once_job([=, ps_p2_7_8_8 = std::move(ps_p2_7_8_8), lx_p0_6_8_8 = std::move(lx_p0_6_8_8)]() {
                return ({
                    auto i_p15 = p0;
                    ({
                    auto p_p16 = or_(index(ps_p2_7_8_8, i_p15), crate::lower::patterns::dummy_pat());
                    (prism_rtl::more(prism_rtl::rc(crate::lower::patterns::RustPat(lx_p0_6_8_8, p_p16, binder_ty_of_pattern(lx_p0_6_8_8, p_p16), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat("p", i_p15, "_")))));
                });
                });
            }));
            });
        })));
        })), [=, again_p8 = std::move(again_p8), pts_p9 = std::move(pts_p9), env1b_pa = std::move(env1b_pa)](Array<crate::lower::patterns::PatOut> each_59540) {
            return ({
                auto pos_pb = each_59540;
                auto unpack_pc = fold(crate::check::errors::range0(len(pos_pb)), Array<crate::lower::model::Do>{}, [&](const Array<crate::lower::model::Do>& acc_p17, const Nat& i_p18) {
                    return ({
                        __label__ _done;
                        prism_rtl::Slot<Array<crate::lower::model::Do>> _v;
                        auto&& _m = index(pos_pb, i_p18);
                        if (prism_rtl::is_some(_m)) {
                            auto&& po_p19 = prism_rtl::some_of(_m);
                            _v.set(append(crate::prelude::push(acc_p17, crate::lower::model::Do(crate::lower::model::Do::DoLet{prism_rtl::deref(po_p19).pa, crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat("p", i_p18)})})), each(prism_rtl::deref(po_p19).conds, [&](const crate::lower::model::Cc& c_p1a) { return cond_as_let(c_p1a); })));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(acc_p17);
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                });
                auto pos2_pd = each(crate::check::errors::range0(len(pos_pb)), [&](const Nat& i_p1b) {
                    return ({
                        __label__ _done;
                        prism_rtl::Slot<crate::lower::patterns::PatOut> _v;
                        auto&& _m = index(pos_pb, i_p1b);
                        if (prism_rtl::is_some(_m)) {
                            auto&& po_p1c = prism_rtl::some_of(_m);
                            _v.set(({
                                __label__ _done;
                                prism_rtl::Slot<crate::lower::patterns::PatOut> _v;
                                auto&& _m = prism_rtl::deref(prism_rtl::deref(or_(index(ps_p2_7, i_p1b), crate::lower::patterns::dummy_pat())).kind);
                                if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
                                    _v.set(({
                                        crate::lower::patterns::PatOut this_ = po_p1c;
                                        this_.binds = each(this_.binds, [&](const std::tuple<Text, crate::lower::types::Bn>& _p0) {
                                            auto&& n_p1d = std::get<0>(_p0);
                                            auto&& b_p1e = std::get<1>(_p0);
                                            return ({
                                                __label__ _done;
                                                prism_rtl::Slot<std::tuple<Text, crate::lower::types::Bn>> _v;
                                                if (prism_rtl::is<crate::lower::types::Bn::BnLocal>(b_p1e)) {
                                                    auto&& rs_p1f = prism_rtl::as<crate::lower::types::Bn::BnLocal>(b_p1e).a0;
                                                    auto&& mode_p1g = prism_rtl::as<crate::lower::types::Bn::BnLocal>(b_p1e).a1;
                                                    auto&& bt_p1h = prism_rtl::as<crate::lower::types::Bn::BnLocal>(b_p1e).a2;
                                                    _v.set(std::tuple{n_p1d, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{rs_p1f, mode_p1g, or_(index(pts_p9, i_p1b), bt_p1h)})});
                                                    goto _done;
                                                }
                                                {
                                                    _v.set(std::tuple{n_p1d, b_p1e});
                                                    goto _done;
                                                }
                                            _done:
                                                _v.take();
                                            });
                                        });
                                        (std::move(this_));
                                    }));
                                    goto _done;
                                }
                                {
                                    _v.set(po_p1c);
                                    goto _done;
                                }
                            _done:
                                _v.take();
                            }));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(crate::lower::patterns::PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds = Array<crate::lower::model::Cc>{}, .binds = Array<std::tuple<Text, crate::lower::types::Bn>>{}});
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                });
                auto env2_pe = fold(pos2_pd, env1b_pa, [&](const crate::lower::types::Env& en_p1i, const crate::lower::patterns::PatOut& po_p1j) { return bind_all(en_p1i, prism_rtl::deref(po_p1j).binds); });
                auto names_pf = each(crate::check::errors::range0(len(ps_p2_7)), [&](const Nat& i_p1k) { return prism_rtl::cat("p", i_p1k); });
                auto pa_pg = len(ps_p2_7) == Nat(1u)
                    ? crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("p0")})), a_p5_1})
                    : crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{each(names_pf, [&](const Text& nm_p1l) { return crate::lower::model::Pa(crate::lower::model::Pa::PaBind{nm_p1l}); })})), a_p5_1});
                auto tail0_ph = ({
                    __label__ _done;
                    prism_rtl::Slot<crate::lower::model::Ex> _v;
                    if (prism_rtl::is<crate::syntax::LambdaBody::LbExpr>(body_p3_2)) {
                        auto&& x_p1m = prism_rtl::as<crate::syntax::LambdaBody::LbExpr>(body_p3_2).a0;
                        _v.set(crate::lower::jobs::tail(lx_p0_6, env2_pe, prism_rtl::deref(prism_rtl::deref(x_p1m))));
                        goto _done;
                    }
                    if (prism_rtl::is<crate::syntax::LambdaBody::LbBlock>(body_p3_2)) {
                        auto&& bl_p1n = prism_rtl::as<crate::syntax::LambdaBody::LbBlock>(body_p3_2).a0;
                        _v.set(crate::lower::jobs::tail_block(lx_p0_6, env2_pe, bl_p1n));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                auto tail_pi = len(unpack_pc) == Nat(0u)
                    ? tail0_ph
                    : crate::lower::model::Ex(crate::lower::model::Ex::XBlock{unpack_pc, prism_rtl::rc(tail0_ph)});
                auto job0_pj = crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("once_job"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array<crate::lower::model::Pa>{}, prism_rtl::rc(tail_pi)})})});
                auto job_pk = enter_p6_3
                    ? crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("entered"), Array(std::vector{job0_pj})})
                    : job0_pj;
                auto call_pl = len(again_p8) == Nat(0u)
                    ? job_pk
                    : crate::lower::model::Ex(crate::lower::model::Ex::XBlock{again_p8, prism_rtl::rc(job_pk)});
                (prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBlock{dos_pu, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCast{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{pa_pg}), prism_rtl::rc(call_pl)})})})), ft_p4_5}))}), ft_p4_5})));
            });
        });
        });
    });
}


/// `Start JobLambda, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_job_lambda(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, Array<crate::syntax::Pattern_> ps_p2, crate::syntax::LambdaBody body_p3, crate::lower::model::OutTy ft_p4, crate::lower::model::OutTy a_p5, bool enter_p6) {
    return prism_rtl::make_rc<JobLambda>(lx_p0, env_p1, ps_p2, body_p3, ft_p4, a_p5, enter_p6);
}


/// EntersLambda: fn Lx, Expr -> Bool
bool enters_lambda(const crate::lower::Lx& lx_p0, const crate::syntax::Expr& e_p1) {
    auto&& _m = crate::lower::types::peel(crate::lower::type_at(lx_p0, e_p1.span));
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m) && prism_rtl::is<crate::check::types::Col::CBound>(prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a0)) {
        return false;
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
        return true;
    }
    {
        return false;
    }
}


/// OnlyCaptured: fn Env, [Text] -> Env
crate::lower::types::Env only_captured(const crate::lower::types::Env& env_p0, const Array<Text>& caps_p1) {
    crate::lower::types::Env this_ = env_p0;
    this_.names = fold(keys(env_p0.names), Map<Text, crate::lower::types::Bn>{}, [&](const Map<Text, crate::lower::types::Bn>& m_p2, const Text& k_p3) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Map<Text, crate::lower::types::Bn>> _v;
            auto&& _m = crate::prelude::get(env_p0.names, k_p3);
            if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m))) {
                auto&& rs_p4 = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                auto&& mode_p5 = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a1;
                auto&& t_p6 = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                _v.set(crate::check::types::has_text(caps_p1, k_p3) || (mode_p5 == crate::lower::types::Holding(crate::lower::types::Holding::Owned{}))
                    ? insert(m_p2, k_p3, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{rs_p4, mode_p5, t_p6}))
                    : m_p2);
                goto _done;
            }
            if (prism_rtl::is_some(_m)) {
                auto&& b_p7 = prism_rtl::some_of(_m);
                _v.set(insert(m_p2, k_p3, b_p7));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(m_p2);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
    return this_;
}


/// CondAsLet: fn Cc -> Do
crate::lower::model::Do cond_as_let(const crate::lower::model::Cc& cc0) {
    if (prism_rtl::is<crate::lower::model::Cc::CcLet>(cc0)) {
        auto&& pa_p0 = prism_rtl::as<crate::lower::model::Cc::CcLet>(cc0).a0;
        auto&& x_p1 = prism_rtl::as<crate::lower::model::Cc::CcLet>(cc0).a1;
        return crate::lower::model::Do(crate::lower::model::Do::DoLet{pa_p0, x_p1});
    }
    if (prism_rtl::is<crate::lower::model::Cc::CcIf>(cc0)) {
        auto&& x_p2 = prism_rtl::as<crate::lower::model::Cc::CcIf>(cc0).a0;
        return crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{})});
    }
    prism_rtl::unreachable("no arm matched");
}


/// LambdaArg: unbounded fn Lx, Env, [Pattern], LambdaBody, [OutTy] -> Ex
crate::lower::model::Ex lambda_arg(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const Array<crate::syntax::Pattern_>& ps_p2, const crate::syntax::LambdaBody& body_p3, const Array<crate::lower::model::OutTy>& pts_p4) {
    auto [pas_p6, env2_p7] = closure_params(lx_p0, env_p1, ps_p2, pts_p4, len(pts_p4) > Nat(0u));
    auto v_p5 = lambda_body_value(lx_p0, env2_p7, body_p3);
    return crate::lower::model::Ex(crate::lower::model::Ex::XClosure{false, pas_p6, prism_rtl::rc(crate::lower::types::own(v_p5))});
}


prism_rtl::Turn<crate::lower::model::Ex> LambdaArg::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& ps_p2 = this->ps_p2;
    const auto& body_p3 = this->body_p3;
    const auto& pts_p4 = this->pts_p4;
    auto body_p3_1 = body_p3;
    auto env_p1_2 = env_p1;
    auto lx_p0_3 = lx_p0;
    auto ps_p2_4 = ps_p2;
    auto pts_p4_5 = pts_p4;
    return call_then(start_closure_params(lx_p0_3, env_p1_2, ps_p2_4, pts_p4_5, len(pts_p4_5) > Nat(0u)), [=](std::tuple<Array<crate::lower::model::Pa>, crate::lower::types::Env> closure_params_62280) {
        return ({
            auto [pas_p6, env2_p7] = closure_params_62280;
            call_then(start_lambda_body_value(lx_p0_3, env2_p7, body_p3_1), [=](crate::lower::types::Vl lambda_body_value_62338) {
            return ({
                auto v_p5 = lambda_body_value_62338;
                (prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XClosure{false, pas_p6, prism_rtl::rc(crate::lower::types::own(v_p5))})));
            });
        });
        });
    });
}


/// `Start LambdaArg, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Ex> start_lambda_arg(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, Array<crate::syntax::Pattern_> ps_p2, crate::syntax::LambdaBody body_p3, Array<crate::lower::model::OutTy> pts_p4) {
    return prism_rtl::make_rc<LambdaArg>(lx_p0, env_p1, ps_p2, body_p3, pts_p4);
}


/// LambdaBodyValue: unbounded fn Lx, Env, LambdaBody -> Vl
crate::lower::types::Vl lambda_body_value(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::LambdaBody& lambda_body2) {
    if (prism_rtl::is<crate::syntax::LambdaBody::LbExpr>(lambda_body2)) {
        auto&& x_p2 = prism_rtl::as<crate::syntax::LambdaBody::LbExpr>(lambda_body2).a0;
        return value_of(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(x_p2)));
    }
    if (prism_rtl::is<crate::syntax::LambdaBody::LbBlock>(lambda_body2)) {
        auto&& b_p5 = prism_rtl::as<crate::syntax::LambdaBody::LbBlock>(lambda_body2).a0;
        return block_value(lx_p0, env_p1, b_p5);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::lower::types::Vl> LambdaBodyValue::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& lambda_body2 = this->lambda_body2;
    return ({
        prism_rtl::is<crate::syntax::LambdaBody::LbExpr>(lambda_body2) ? ({
        auto&& x_p2 = prism_rtl::as<crate::syntax::LambdaBody::LbExpr>(lambda_body2).a0;
        prism_rtl::more(prism_rtl::rc(ValueOf(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(x_p2)))));
    })
        : prism_rtl::is<crate::syntax::LambdaBody::LbBlock>(lambda_body2) ? ({
        auto&& b_p5 = prism_rtl::as<crate::syntax::LambdaBody::LbBlock>(lambda_body2).a0;
        prism_rtl::more(prism_rtl::rc(BlockValue(lx_p0, env_p1, b_p5)));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start LambdaBodyValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_lambda_body_value(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::LambdaBody lambda_body2) {
    return prism_rtl::make_rc<LambdaBodyValue>(lx_p0, env_p1, lambda_body2);
}


/// ClosureParams: unbounded fn Lx, Env, [Pattern], [OutTy], Bool -> (([Pa], Env))
std::tuple<Array<crate::lower::model::Pa>, crate::lower::types::Env> closure_params(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const Array<crate::syntax::Pattern_>& ps_p2, const Array<crate::lower::model::OutTy>& pts_p3, const bool& typed_p4) {
    return run_to_end(fold_job(crate::check::errors::range0(len(ps_p2)), std::tuple{Array<crate::lower::model::Pa>{}, env_p1}, ({
        auto ps_p2_1 = ps_p2;
        auto lx_p0_2 = lx_p0;
        auto typed_p4_3 = typed_p4;
        auto pts_p3_4 = pts_p3;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::lower::model::Pa>, crate::lower::types::Env>>(std::tuple<std::tuple<Array<crate::lower::model::Pa>, crate::lower::types::Env>, Nat>)>>(prism_rtl::rc([=, ps_p2_1 = std::move(ps_p2_1), lx_p0_2 = std::move(lx_p0_2), typed_p4_3 = std::move(typed_p4_3), pts_p3_4 = std::move(pts_p3_4)](std::tuple<std::tuple<Array<crate::lower::model::Pa>, crate::lower::types::Env>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto ps_p2_1_5 = ps_p2_1;
            auto lx_p0_2_5 = lx_p0_2;
            auto typed_p4_3_5 = typed_p4_3;
            auto pts_p3_4_5 = pts_p3_4;
            entered(once_job([=, ps_p2_1_5 = std::move(ps_p2_1_5), lx_p0_2_5 = std::move(lx_p0_2_5), typed_p4_3_5 = std::move(typed_p4_3_5), pts_p3_4_5 = std::move(pts_p3_4_5)]() {
            return ({
                auto [acc_p5, en_p6] = p0;
                auto i_p7 = p1;
                ({
                auto&& _m = index(ps_p2_1_5, i_p7);
                prism_rtl::is_some(_m) ? ({
                auto&& p_p8 = prism_rtl::some_of(_m);
                call_then(crate::lower::patterns::start_rust_pat(lx_p0_2_5, p_p8, binder_ty_of_pattern(lx_p0_2_5, p_p8), crate::lower::types::Holding(crate::lower::types::Holding::ByRef{}), prism_rtl::cat("a", prism_rtl::deref(prism_rtl::deref(p_p8).span).start)), [=](crate::lower::patterns::PatOut rust_pat_62901) {
                return ({
                    auto po_p9 = rust_pat_62901;
                    auto en2_pa = bind_all(en_p6, prism_rtl::deref(po_p9).binds);
                    auto pa_pb = typed_p4_3_5
                        ? crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(prism_rtl::deref(po_p9).pa), crate::lower::model::OutTy(crate::lower::model::OutTy::OutRef{prism_rtl::rc(or_(index(pts_p3_4_5, i_p7), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnknown{Text::lit("a parameter")})))})})
                        : prism_rtl::deref(po_p9).pa;
                    (prism_rtl::finished(std::tuple{crate::prelude::push(acc_p5, pa_pb), en2_pa}));
                });
            });
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{acc_p5, en_p6})
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    }));
    })));
}


prism_rtl::Turn<std::tuple<Array<crate::lower::model::Pa>, crate::lower::types::Env>> ClosureParams::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& ps_p2 = this->ps_p2;
    const auto& pts_p3 = this->pts_p3;
    const auto& typed_p4 = this->typed_p4;
    return fold_job(crate::check::errors::range0(len(ps_p2)), std::tuple{Array<crate::lower::model::Pa>{}, env_p1}, ({
        auto ps_p2_1 = ps_p2;
        auto lx_p0_2 = lx_p0;
        auto typed_p4_3 = prism_rtl::deref(typed_p4);
        auto pts_p3_4 = pts_p3;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::lower::model::Pa>, crate::lower::types::Env>>(std::tuple<std::tuple<Array<crate::lower::model::Pa>, crate::lower::types::Env>, Nat>)>>(prism_rtl::rc([=, ps_p2_1 = std::move(ps_p2_1), lx_p0_2 = std::move(lx_p0_2), typed_p4_3 = std::move(typed_p4_3), pts_p3_4 = std::move(pts_p3_4)](std::tuple<std::tuple<Array<crate::lower::model::Pa>, crate::lower::types::Env>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto ps_p2_1_5 = ps_p2_1;
            auto lx_p0_2_5 = lx_p0_2;
            auto typed_p4_3_5 = typed_p4_3;
            auto pts_p3_4_5 = pts_p3_4;
            entered(once_job([=, ps_p2_1_5 = std::move(ps_p2_1_5), lx_p0_2_5 = std::move(lx_p0_2_5), typed_p4_3_5 = std::move(typed_p4_3_5), pts_p3_4_5 = std::move(pts_p3_4_5)]() {
            return ({
                auto [acc_p5, en_p6] = p0;
                auto i_p7 = p1;
                ({
                auto&& _m = index(ps_p2_1_5, i_p7);
                prism_rtl::is_some(_m) ? ({
                auto&& p_p8 = prism_rtl::some_of(_m);
                call_then(crate::lower::patterns::start_rust_pat(lx_p0_2_5, p_p8, binder_ty_of_pattern(lx_p0_2_5, p_p8), crate::lower::types::Holding(crate::lower::types::Holding::ByRef{}), prism_rtl::cat("a", prism_rtl::deref(prism_rtl::deref(p_p8).span).start)), [=](crate::lower::patterns::PatOut rust_pat_62901) {
                return ({
                    auto po_p9 = rust_pat_62901;
                    auto en2_pa = bind_all(en_p6, prism_rtl::deref(po_p9).binds);
                    auto pa_pb = typed_p4_3_5
                        ? crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(prism_rtl::deref(po_p9).pa), crate::lower::model::OutTy(crate::lower::model::OutTy::OutRef{prism_rtl::rc(or_(index(pts_p3_4_5, i_p7), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnknown{Text::lit("a parameter")})))})})
                        : prism_rtl::deref(po_p9).pa;
                    (prism_rtl::finished(std::tuple{crate::prelude::push(acc_p5, pa_pb), en2_pa}));
                });
            });
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{acc_p5, en_p6})
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    }));
    }))->cycle();
}


/// `Start ClosureParams, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::lower::model::Pa>, crate::lower::types::Env>> start_closure_params(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, Array<crate::syntax::Pattern_> ps_p2, Array<crate::lower::model::OutTy> pts_p3, bool typed_p4) {
    return prism_rtl::make_rc<ClosureParams>(lx_p0, env_p1, ps_p2, pts_p3, typed_p4);
}


/// BindAll: fn Env, [((Text, Bn))] -> Env
crate::lower::types::Env bind_all(const crate::lower::types::Env& env_p0, const Array<std::tuple<Text, crate::lower::types::Bn>>& bs_p1) {
    return fold(bs_p1, env_p0, [&](const crate::lower::types::Env& en_p2, const std::tuple<Text, crate::lower::types::Bn>& _p1) {
        auto&& n_p3 = std::get<0>(_p1);
        auto&& b_p4 = std::get<1>(_p1);
        return crate::lower::types::bind(en_p2, n_p3, b_p4);
    });
}


/// BinderTyOfPattern: fn Lx, Pattern -> Ty
crate::check::types::Ty binder_ty_of_pattern(const crate::lower::Lx& lx_p0, const crate::syntax::Pattern_& p_p1) {
    auto&& _m = prism_rtl::deref(p_p1.kind);
    if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
        auto&& n_p2 = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        return crate::lower::binder_ty(lx_p0, prism_rtl::deref(n_p2).span);
    }
    {
        return crate::lower::type_at(lx_p0, p_p1.span);
    }
}


/// IfValue: unbounded fn Lx, Env, Cond, Block, ?Block, OutTy -> Vl
crate::lower::types::Vl if_value(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Cond& c_p2, const crate::syntax::Block& then_b_p3, const std::optional<crate::syntax::Block>& else_b_o4, const crate::lower::model::OutTy& t_p5) {
    auto else_v_p6 = ({
        __label__ _done;
        prism_rtl::Slot<crate::lower::model::Ex> _v;
        if (prism_rtl::is_some(else_b_o4)) {
            auto&& b_p7 = prism_rtl::some_of(else_b_o4);
            _v.set(crate::lower::node_::def::own_as(t_p5, block_value(lx_p0, env_p1, b_p7)));
            goto _done;
        }
        if (prism_rtl::is_none(else_b_o4)) {
            _v.set(crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    if (prism_rtl::is<crate::syntax::Cond::CondExpr>(c_p2)) {
        auto&& x_p8 = prism_rtl::as<crate::syntax::Cond::CondExpr>(c_p2).a0;
        return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XIf{prism_rtl::rc(crate::lower::types::as_bool(value_of(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(x_p8))))), prism_rtl::rc(crate::lower::node_::def::own_as(t_p5, block_value(lx_p0, env_p1, then_b_p3))), prism_rtl::rc(else_v_p6)}), t_p5});
    }
    if (prism_rtl::is<crate::syntax::Cond::CondBind>(c_p2)) {
        auto&& p_p9 = prism_rtl::as<crate::syntax::Cond::CondBind>(c_p2).a0;
        auto&& x_pa = prism_rtl::as<crate::syntax::Cond::CondBind>(c_p2).a1;
        auto&& g_ob = prism_rtl::as<crate::syntax::Cond::CondBind>(c_p2).a2;
        auto sv_pc = value_of(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(x_pa)));
        auto po_pd = crate::lower::patterns::rust_pat(lx_p0, p_p9, crate::lower::type_at(lx_p0, prism_rtl::deref(x_pa).span), crate::lower::types::Holding(crate::lower::types::Holding::ByRef{}), prism_rtl::cat("c", prism_rtl::deref(prism_rtl::deref(x_pa).span).start));
        auto env2_pe = bind_all(env_p1, prism_rtl::deref(po_pd).binds);
        auto guard_pf = ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::lower::model::Cc>> _v;
            auto&& _m = prism_rtl::deref(prism_rtl::deref(g_ob));
            if (prism_rtl::is_some(_m)) {
                auto&& ge_pi = prism_rtl::some_of(_m);
                _v.set(Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::types::as_bool(value_of(lx_p0, env2_pe, ge_pi))})}));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(Array<crate::lower::model::Cc>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto arm_pg = crate::lower::model::XArm{.pat = prism_rtl::deref(po_pd).pa, .conds = append(prism_rtl::deref(po_pd).conds, guard_pf), .body = crate::lower::node_::def::own_as(t_p5, block_value(lx_p0, env2_pe, then_b_p3))};
        auto other_ph = crate::lower::model::XArm{.pat = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds = Array<crate::lower::model::Cc>{}, .body = else_v_p6};
        return arms_value(crate::lower::types::ref_(sv_pc), Array(std::vector{arm_pg, other_ph}), prism_rtl::cat("c", prism_rtl::deref(prism_rtl::deref(x_pa).span).start), t_p5);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::lower::types::Vl> IfValue::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& c_p2 = this->c_p2;
    const auto& then_b_p3 = this->then_b_p3;
    const auto& else_b_o4 = this->else_b_o4;
    const auto& t_p5 = this->t_p5;
    auto else_v_p6 = ({
        __label__ _done;
        prism_rtl::Slot<crate::lower::model::Ex> _v;
        if (prism_rtl::is_some(else_b_o4)) {
            auto&& b_p7 = prism_rtl::some_of(else_b_o4);
            _v.set(crate::lower::node_::def::own_as(t_p5, block_value(lx_p0, env_p1, b_p7)));
            goto _done;
        }
        if (prism_rtl::is_none(else_b_o4)) {
            _v.set(crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return ({
        prism_rtl::is<crate::syntax::Cond::CondExpr>(c_p2) ? ({
        auto&& x_p8 = prism_rtl::as<crate::syntax::Cond::CondExpr>(c_p2).a0;
        ({
        auto env_p1_1 = env_p1;
        auto lx_p0_2 = lx_p0;
        auto t_p5_3 = t_p5;
        auto then_b_p3_4 = then_b_p3;
        auto x_p8_5 = prism_rtl::deref(prism_rtl::deref(x_p8));
        call_then(start_value_of(lx_p0_2, env_p1_1, x_p8_5), [=, t_p5_3 = std::move(t_p5_3), then_b_p3_4 = std::move(then_b_p3_4)](crate::lower::types::Vl value_of_63807) { return call_then(start_block_value(lx_p0_2, env_p1_1, then_b_p3_4), [=](crate::lower::types::Vl block_value_63840) { return prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XIf{prism_rtl::rc(crate::lower::types::as_bool(value_of_63807)), prism_rtl::rc(crate::lower::node_::def::own_as(t_p5_3, block_value_63840)), prism_rtl::rc(else_v_p6)}), t_p5_3})); }); });
    });
    })
        : prism_rtl::is<crate::syntax::Cond::CondBind>(c_p2) ? ({
        auto&& p_p9 = prism_rtl::as<crate::syntax::Cond::CondBind>(c_p2).a0;
        auto&& x_pa = prism_rtl::as<crate::syntax::Cond::CondBind>(c_p2).a1;
        auto&& g_ob = prism_rtl::as<crate::syntax::Cond::CondBind>(c_p2).a2;
        ({
        auto g_ob_1 = prism_rtl::deref(prism_rtl::deref(g_ob));
        auto c_p2_2 = c_p2;
        auto env_p1_3 = env_p1;
        auto lx_p0_4 = lx_p0;
        auto p_p9_5 = p_p9;
        auto t_p5_6 = t_p5;
        auto then_b_p3_7 = then_b_p3;
        auto x_pa_8 = prism_rtl::deref(prism_rtl::deref(x_pa));
        call_then(start_value_of(lx_p0_4, env_p1_3, x_pa_8), [=, g_ob_1 = std::move(g_ob_1), p_p9_5 = std::move(p_p9_5), t_p5_6 = std::move(t_p5_6), then_b_p3_7 = std::move(then_b_p3_7)](crate::lower::types::Vl value_of_63927) {
        return ({
            auto sv_pc = value_of_63927;
            call_then(crate::lower::patterns::start_rust_pat(lx_p0_4, p_p9_5, crate::lower::type_at(lx_p0_4, prism_rtl::deref(x_pa_8).span), crate::lower::types::Holding(crate::lower::types::Holding::ByRef{}), prism_rtl::cat("c", prism_rtl::deref(prism_rtl::deref(x_pa_8).span).start)), [=, sv_pc = std::move(sv_pc)](crate::lower::patterns::PatOut rust_pat_63967) {
            return ({
                auto po_pd = rust_pat_63967;
                auto env2_pe = bind_all(env_p1_3, prism_rtl::deref(po_pd).binds);
                auto guard_pf = ({
                    __label__ _done;
                    prism_rtl::Slot<Array<crate::lower::model::Cc>> _v;
                    if (prism_rtl::is_some(g_ob_1)) {
                        auto&& ge_pi = prism_rtl::some_of(g_ob_1);
                        _v.set(Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::types::as_bool(value_of(lx_p0_4, env2_pe, ge_pi))})}));
                        goto _done;
                    }
                    if (prism_rtl::is_none(g_ob_1)) {
                        _v.set(Array<crate::lower::model::Cc>{});
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                call_then(start_block_value(lx_p0_4, env2_pe, then_b_p3_7), [=, po_pd = std::move(po_pd), guard_pf = std::move(guard_pf)](crate::lower::types::Vl block_value_64282) {
                return ({
                    auto arm_pg = crate::lower::model::XArm{.pat = prism_rtl::deref(po_pd).pa, .conds = append(prism_rtl::deref(po_pd).conds, guard_pf), .body = crate::lower::node_::def::own_as(t_p5_6, block_value_64282)};
                    auto other_ph = crate::lower::model::XArm{.pat = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds = Array<crate::lower::model::Cc>{}, .body = else_v_p6};
                    (prism_rtl::finished(arms_value(crate::lower::types::ref_(sv_pc), Array(std::vector{arm_pg, other_ph}), prism_rtl::cat("c", prism_rtl::deref(prism_rtl::deref(x_pa_8).span).start), t_p5_6)));
                });
            });
            });
        });
        });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start IfValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_if_value(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Cond c_p2, crate::syntax::Block then_b_p3, std::optional<crate::syntax::Block> else_b_o4, crate::lower::model::OutTy t_p5) {
    return prism_rtl::make_rc<IfValue>(lx_p0, env_p1, c_p2, then_b_p3, else_b_o4, t_p5);
}


/// ArmsValue: fn Ex, [XArm], Text, OutTy -> Vl
crate::lower::types::Vl arms_value(const crate::lower::model::Ex& scrut_p0, const Array<crate::lower::model::XArm>& arms_p1, const Text& label_p2, const crate::lower::model::OutTy& t_p3) {
    auto chain_p4 = fold(arms_p1, false, [&](const bool& f_p6, const crate::lower::model::XArm& a_p7) { return prism_rtl::deref(f_p6) || fold(prism_rtl::deref(a_p7).conds, false, [&](const bool& f2_p8, const crate::lower::model::Cc& c_p9) { return prism_rtl::deref(f2_p8) || is_let_cond(c_p9); }); });
    auto guarded_p5 = fold(arms_p1, false, [&](const bool& f_pa, const crate::lower::model::XArm& a_pb) { return prism_rtl::deref(f_pa) || (len(prism_rtl::deref(a_pb).conds) > Nat(0u)); });
    return std::move(chain_p4)
        ? crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XChain{label_p2, prism_rtl::rc(scrut_p0), arms_p1, t_p3}), t_p3})
        : crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XMatch{prism_rtl::rc(scrut_p0), arms_p1, std::move(guarded_p5), t_p3}), t_p3});
}


/// IsLetCond: fn Cc -> Bool
bool is_let_cond(const crate::lower::model::Cc& cc0) {
    if (prism_rtl::is<crate::lower::model::Cc::CcLet>(cc0)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Cc::CcIf>(cc0)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// MatchValue: unbounded fn Lx, Env, Expr, [Arm], OutTy, Range -> Vl
crate::lower::types::Vl match_value(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& s_p2, const Array<crate::syntax::Arm>& arms_p3, const crate::lower::model::OutTy& t_p4, const crate::syntax::Range& span_p5) {
    auto sv_p6 = value_of(lx_p0, env_p1, s_p2);
    auto sty_p7 = crate::lower::type_at(lx_p0, s_p2.span);
    auto label_p8 = prism_rtl::cat("m", span_p5.start);
    auto by_ref_p9 = run_to_end(each_job(crate::check::errors::range0(len(arms_p3)), ({
        auto lx_p0_1 = lx_p0;
        auto arms_p3_2 = arms_p3;
        auto sty_p7_3 = sty_p7;
        auto label_p8_4 = label_p8;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::patterns::PatOut>(Nat)>>(prism_rtl::rc([=, lx_p0_1 = std::move(lx_p0_1), arms_p3_2 = std::move(arms_p3_2), sty_p7_3 = std::move(sty_p7_3), label_p8_4 = std::move(label_p8_4)](Nat p0) {
        return ({
            auto lx_p0_1_5 = lx_p0_1;
            auto arms_p3_2_5 = arms_p3_2;
            auto sty_p7_3_5 = sty_p7_3;
            auto label_p8_4_5 = label_p8_4;
            entered(once_job([=, lx_p0_1_5 = std::move(lx_p0_1_5), arms_p3_2_5 = std::move(arms_p3_2_5), sty_p7_3_5 = std::move(sty_p7_3_5), label_p8_4_5 = std::move(label_p8_4_5)]() {
            return ({
                auto i_pf = p0;
                (prism_rtl::more(prism_rtl::rc(ArmPat(lx_p0_1_5, prism_rtl::deref(or_(index(arms_p3_2_5, i_pf), dummy_arm())).pattern, sty_p7_3_5, crate::lower::types::Holding(crate::lower::types::Holding::ByRef{}), prism_rtl::cat(label_p8_4_5, "_", i_pf)))));
            });
        }));
        });
    })));
    })));
    auto chain_pa = fold(by_ref_p9, false, [&](const bool& f_pg, const crate::lower::patterns::PatOut& po_ph) { return prism_rtl::deref(f_pg) || fold(prism_rtl::deref(po_ph).conds, false, [&](const bool& f2_pi, const crate::lower::model::Cc& c_pj) { return prism_rtl::deref(f2_pi) || is_let_cond(c_pj); }); });
    auto owned_pb = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        if (prism_rtl::is<crate::lower::types::Vl::VlOwned>(sv_p6)) {
            _v.set(!std::move(chain_pa));
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
    auto pats_pc = std::move(owned_pb)
        ? run_to_end(each_job(crate::check::errors::range0(len(arms_p3)), ({
        auto lx_p0_1 = lx_p0;
        auto arms_p3_2 = arms_p3;
        auto sty_p7_3 = sty_p7;
        auto label_p8_4 = label_p8;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::patterns::PatOut>(Nat)>>(prism_rtl::rc([=, lx_p0_1 = std::move(lx_p0_1), arms_p3_2 = std::move(arms_p3_2), sty_p7_3 = std::move(sty_p7_3), label_p8_4 = std::move(label_p8_4)](Nat p0) {
        return ({
            auto lx_p0_1_5 = lx_p0_1;
            auto arms_p3_2_5 = arms_p3_2;
            auto sty_p7_3_5 = sty_p7_3;
            auto label_p8_4_5 = label_p8_4;
            entered(once_job([=, lx_p0_1_5 = std::move(lx_p0_1_5), arms_p3_2_5 = std::move(arms_p3_2_5), sty_p7_3_5 = std::move(sty_p7_3_5), label_p8_4_5 = std::move(label_p8_4_5)]() {
            return ({
                auto i_pk = p0;
                (prism_rtl::more(prism_rtl::rc(ArmPat(lx_p0_1_5, prism_rtl::deref(or_(index(arms_p3_2_5, i_pk), dummy_arm())).pattern, sty_p7_3_5, crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat(label_p8_4_5, "_", i_pk)))));
            });
        }));
        });
    })));
    })))
        : by_ref_p9;
    auto xarms_pd = run_to_end(each_job(crate::check::errors::range0(len(arms_p3)), ({
        auto arms_p3_1 = arms_p3;
        auto pats_pc_2 = pats_pc;
        auto env_p1_3 = env_p1;
        auto lx_p0_4 = lx_p0;
        auto owned_pb_5 = std::move(owned_pb);
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::XArm>(Nat)>>(prism_rtl::rc([=, arms_p3_1 = std::move(arms_p3_1), pats_pc_2 = std::move(pats_pc_2), env_p1_3 = std::move(env_p1_3), lx_p0_4 = std::move(lx_p0_4), owned_pb_5 = std::move(owned_pb_5)](Nat p0) {
        return ({
            auto arms_p3_1_6 = arms_p3_1;
            auto pats_pc_2_6 = pats_pc_2;
            auto env_p1_3_6 = env_p1_3;
            auto lx_p0_4_6 = lx_p0_4;
            auto owned_pb_5_6 = owned_pb_5;
            entered(once_job([=, arms_p3_1_6 = std::move(arms_p3_1_6), pats_pc_2_6 = std::move(pats_pc_2_6), env_p1_3_6 = std::move(env_p1_3_6), lx_p0_4_6 = std::move(lx_p0_4_6), owned_pb_5_6 = std::move(owned_pb_5_6)]() {
            return ({
                auto i_pl = p0;
                ({
                auto arm_pm = or_(index(arms_p3_1_6, i_pl), dummy_arm());
                auto po_pn = or_(index(pats_pc_2_6, i_pl), crate::lower::patterns::PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds = Array<crate::lower::model::Cc>{}, .binds = Array<std::tuple<Text, crate::lower::types::Bn>>{}});
                auto env2_po = bind_all(env_p1_3_6, prism_rtl::deref(po_pn).binds);
                auto guard_pp = ({
                    __label__ _done;
                    prism_rtl::Slot<Array<crate::lower::model::Cc>> _v;
                    auto&& _m = prism_rtl::deref(arm_pm).guard;
                    if (prism_rtl::is_some(_m)) {
                        auto&& ge_pr = prism_rtl::some_of(_m);
                        _v.set(Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::types::as_bool(value_of(lx_p0_4_6, env2_po, ge_pr))})}));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(Array<crate::lower::model::Cc>{});
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                auto env3_pq = owned_pb_5_6
                    ? moved_once(lx_p0_4_6, env2_po, arm_pm, prism_rtl::deref(po_pn).binds)
                    : env2_po;
                call_then(start_block_value(lx_p0_4_6, env3_pq, prism_rtl::deref(arm_pm).body), [=, po_pn = std::move(po_pn), guard_pp = std::move(guard_pp)](crate::lower::types::Vl block_value_66248) { return prism_rtl::finished(crate::lower::model::XArm{.pat = prism_rtl::deref(po_pn).pa, .conds = append(prism_rtl::deref(po_pn).conds, guard_pp), .body = crate::lower::types::own(block_value_66248)}); });
            });
            });
        }));
        });
    })));
    })));
    auto scrut_pe = std::move(owned_pb)
        ? crate::lower::types::own(sv_p6)
        : crate::lower::types::ref_(sv_p6);
    return arms_value(scrut_pe, xarms_pd, label_p8, t_p4);
}


prism_rtl::Turn<crate::lower::types::Vl> MatchValue::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& s_p2 = this->s_p2;
    const auto& arms_p3 = this->arms_p3;
    const auto& t_p4 = this->t_p4;
    const auto& span_p5 = this->span_p5;
    auto arms_p3_1 = arms_p3;
    auto env_p1_2 = env_p1;
    auto lx_p0_3 = lx_p0;
    auto s_p2_4 = s_p2;
    auto span_p5_5 = span_p5;
    auto t_p4_6 = t_p4;
    return call_then(start_value_of(lx_p0_3, env_p1_2, s_p2_4), [=](crate::lower::types::Vl value_of_65259) {
        return ({
            auto sv_p6 = value_of_65259;
            auto sty_p7 = crate::lower::type_at(lx_p0_3, prism_rtl::deref(s_p2_4).span);
            auto label_p8 = prism_rtl::cat("m", prism_rtl::deref(span_p5_5).start);
            call_value(each_job(crate::check::errors::range0(len(arms_p3_1)), ({
            auto lx_p0_3_7 = lx_p0_3;
            auto arms_p3_1_7 = arms_p3_1;
            auto sty_p7_7 = sty_p7;
            auto label_p8_8 = label_p8;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::patterns::PatOut>(Nat)>>(prism_rtl::rc([=, lx_p0_3_7 = std::move(lx_p0_3_7), arms_p3_1_7 = std::move(arms_p3_1_7), sty_p7_7 = std::move(sty_p7_7), label_p8_8 = std::move(label_p8_8)](Nat p0) {
            return ({
                auto lx_p0_3_7_9 = lx_p0_3_7;
                auto arms_p3_1_7_9 = arms_p3_1_7;
                auto sty_p7_7_9 = sty_p7_7;
                auto label_p8_8_9 = label_p8_8;
                entered(once_job([=, lx_p0_3_7_9 = std::move(lx_p0_3_7_9), arms_p3_1_7_9 = std::move(arms_p3_1_7_9), sty_p7_7_9 = std::move(sty_p7_7_9), label_p8_8_9 = std::move(label_p8_8_9)]() {
                return ({
                    auto i_pf = p0;
                    (prism_rtl::more(prism_rtl::rc(ArmPat(lx_p0_3_7_9, prism_rtl::deref(or_(index(arms_p3_1_7_9, i_pf), dummy_arm())).pattern, sty_p7_7_9, crate::lower::types::Holding(crate::lower::types::Holding::ByRef{}), prism_rtl::cat(label_p8_8_9, "_", i_pf)))));
                });
            }));
            });
        })));
        })), [=, sv_p6 = std::move(sv_p6)](Array<crate::lower::patterns::PatOut> each_65358) {
            return ({
                auto by_ref_p9 = each_65358;
                auto chain_pa = fold(by_ref_p9, false, [&](const bool& f_pg, const crate::lower::patterns::PatOut& po_ph) { return prism_rtl::deref(f_pg) || fold(prism_rtl::deref(po_ph).conds, false, [&](const bool& f2_pi, const crate::lower::model::Cc& c_pj) { return prism_rtl::deref(f2_pi) || is_let_cond(c_pj); }); });
                auto owned_pb = ({
                    __label__ _done;
                    prism_rtl::Slot<bool> _v;
                    if (prism_rtl::is<crate::lower::types::Vl::VlOwned>(sv_p6)) {
                        _v.set(!std::move(chain_pa));
                        goto _done;
                    }
                    {
                        _v.set(false);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                auto pats_pc = std::move(owned_pb)
                    ? run_to_end(each_job(crate::check::errors::range0(len(arms_p3_1)), ({
                    auto lx_p0_3_7 = lx_p0_3;
                    auto arms_p3_1_7 = arms_p3_1;
                    auto sty_p7_7 = sty_p7;
                    auto label_p8_8 = label_p8;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::patterns::PatOut>(Nat)>>(prism_rtl::rc([=, lx_p0_3_7 = std::move(lx_p0_3_7), arms_p3_1_7 = std::move(arms_p3_1_7), sty_p7_7 = std::move(sty_p7_7), label_p8_8 = std::move(label_p8_8)](Nat p0) {
                    return ({
                        auto lx_p0_3_7_9 = lx_p0_3_7;
                        auto arms_p3_1_7_9 = arms_p3_1_7;
                        auto sty_p7_7_9 = sty_p7_7;
                        auto label_p8_8_9 = label_p8_8;
                        entered(once_job([=, lx_p0_3_7_9 = std::move(lx_p0_3_7_9), arms_p3_1_7_9 = std::move(arms_p3_1_7_9), sty_p7_7_9 = std::move(sty_p7_7_9), label_p8_8_9 = std::move(label_p8_8_9)]() {
                        return ({
                            auto i_pk = p0;
                            (prism_rtl::more(prism_rtl::rc(ArmPat(lx_p0_3_7_9, prism_rtl::deref(or_(index(arms_p3_1_7_9, i_pk), dummy_arm())).pattern, sty_p7_7_9, crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat(label_p8_8_9, "_", i_pk)))));
                        });
                    }));
                    });
                })));
                })))
                    : by_ref_p9;
                call_value(each_job(crate::check::errors::range0(len(arms_p3_1)), ({
                auto arms_p3_1_7 = arms_p3_1;
                auto pats_pc_7 = pats_pc;
                auto env_p1_2_8 = env_p1_2;
                auto lx_p0_3_8 = lx_p0_3;
                auto owned_pb_8 = std::move(owned_pb);
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::XArm>(Nat)>>(prism_rtl::rc([=, arms_p3_1_7 = std::move(arms_p3_1_7), pats_pc_7 = std::move(pats_pc_7), env_p1_2_8 = std::move(env_p1_2_8), lx_p0_3_8 = std::move(lx_p0_3_8), owned_pb_8 = std::move(owned_pb_8)](Nat p0) {
                return ({
                    auto arms_p3_1_7_9 = arms_p3_1_7;
                    auto pats_pc_7_9 = pats_pc_7;
                    auto env_p1_2_8_9 = env_p1_2_8;
                    auto lx_p0_3_8_9 = lx_p0_3_8;
                    auto owned_pb_8_9 = owned_pb_8;
                    entered(once_job([=, arms_p3_1_7_9 = std::move(arms_p3_1_7_9), pats_pc_7_9 = std::move(pats_pc_7_9), env_p1_2_8_9 = std::move(env_p1_2_8_9), lx_p0_3_8_9 = std::move(lx_p0_3_8_9), owned_pb_8_9 = std::move(owned_pb_8_9)]() {
                    return ({
                        auto i_pl = p0;
                        ({
                        auto arm_pm = or_(index(arms_p3_1_7_9, i_pl), dummy_arm());
                        auto po_pn = or_(index(pats_pc_7_9, i_pl), crate::lower::patterns::PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds = Array<crate::lower::model::Cc>{}, .binds = Array<std::tuple<Text, crate::lower::types::Bn>>{}});
                        auto env2_po = bind_all(env_p1_2_8_9, prism_rtl::deref(po_pn).binds);
                        auto guard_pp = ({
                            __label__ _done;
                            prism_rtl::Slot<Array<crate::lower::model::Cc>> _v;
                            auto&& _m = prism_rtl::deref(arm_pm).guard;
                            if (prism_rtl::is_some(_m)) {
                                auto&& ge_pr = prism_rtl::some_of(_m);
                                _v.set(Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::types::as_bool(value_of(lx_p0_3_8_9, env2_po, ge_pr))})}));
                                goto _done;
                            }
                            if (prism_rtl::is_none(_m)) {
                                _v.set(Array<crate::lower::model::Cc>{});
                                goto _done;
                            }
                            prism_rtl::unreachable("no arm matched");
                        _done:
                            _v.take();
                        });
                        auto env3_pq = owned_pb_8_9
                            ? moved_once(lx_p0_3_8_9, env2_po, arm_pm, prism_rtl::deref(po_pn).binds)
                            : env2_po;
                        call_then(start_block_value(lx_p0_3_8_9, env3_pq, prism_rtl::deref(arm_pm).body), [=, po_pn = std::move(po_pn), guard_pp = std::move(guard_pp)](crate::lower::types::Vl block_value_66248) { return prism_rtl::finished(crate::lower::model::XArm{.pat = prism_rtl::deref(po_pn).pa, .conds = append(prism_rtl::deref(po_pn).conds, guard_pp), .body = crate::lower::types::own(block_value_66248)}); });
                    });
                    });
                }));
                });
            })));
            })), [=](Array<crate::lower::model::XArm> each_65804) {
                return ({
                    auto xarms_pd = each_65804;
                    auto scrut_pe = owned_pb
                        ? crate::lower::types::own(sv_p6)
                        : crate::lower::types::ref_(sv_p6);
                    (prism_rtl::finished(arms_value(scrut_pe, xarms_pd, label_p8, t_p4_6)));
                });
            });
            });
        });
        });
    });
}


/// `Start MatchValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_match_value(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr s_p2, Array<crate::syntax::Arm> arms_p3, crate::lower::model::OutTy t_p4, crate::syntax::Range span_p5) {
    return prism_rtl::make_rc<MatchValue>(lx_p0, env_p1, s_p2, arms_p3, t_p4, span_p5);
}


/// MovedOnce: unbounded fn Lx, Env, Arm, [((Text, Bn))] -> Env
crate::lower::types::Env moved_once(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Arm& arm_p2, const Array<std::tuple<Text, crate::lower::types::Bn>>& binds_p3) {
    return run_to_end(fold_job(binds_p3, env_p1, ({
        auto lx_p0_1 = lx_p0;
        auto arm_p2_2 = arm_p2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::types::Env>(std::tuple<crate::lower::types::Env, std::tuple<Text, crate::lower::types::Bn>>)>>(prism_rtl::rc([=, lx_p0_1 = std::move(lx_p0_1), arm_p2_2 = std::move(arm_p2_2)](std::tuple<crate::lower::types::Env, std::tuple<Text, crate::lower::types::Bn>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_p0_1_3 = lx_p0_1;
            auto arm_p2_2_3 = arm_p2_2;
            entered(once_job([=, lx_p0_1_3 = std::move(lx_p0_1_3), arm_p2_2_3 = std::move(arm_p2_2_3)]() {
            return ({
                auto en_p4 = p0;
                auto [nkey_p5, bn_p6] = p1;
                ({
                prism_rtl::is<crate::lower::types::Bn::BnLocal>(bn_p6) && prism_rtl::is<crate::lower::model::Ex::XVar>(prism_rtl::as<crate::lower::types::Bn::BnLocal>(bn_p6).a0) && prism_rtl::is<crate::lower::types::Holding::Owned>(prism_rtl::as<crate::lower::types::Bn::BnLocal>(bn_p6).a1) ? ({
                auto&& rs_p7 = prism_rtl::as<crate::lower::model::Ex::XVar>(prism_rtl::as<crate::lower::types::Bn::BnLocal>(bn_p6).a0).a0;
                auto&& bt_p8 = prism_rtl::as<crate::lower::types::Bn::BnLocal>(bn_p6).a2;
                ({
                auto bt_p8_3 = bt_p8;
                auto rs_p7_4 = rs_p7;
                call_then(start_only_read(lx_p0_1_3, arm_p2_2_3, nkey_p5), [=, bt_p8_3 = std::move(bt_p8_3), rs_p7_4 = std::move(rs_p7_4)](std::optional<crate::syntax::Expr> only_read_66897) {
                return ({
                    prism_rtl::is_some(only_read_66897) ? ({
                    auto&& x_p9 = prism_rtl::some_of(only_read_66897);
                    prism_rtl::finished(crate::lower::types::bind_span(en_p4, crate::lower::place_key(lx_p0_1_3, prism_rtl::deref(x_p9).span), crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XVar{rs_p7_4}), bt_p8_3})));
                })
                    : prism_rtl::is_none(only_read_66897) ? prism_rtl::finished(en_p4)
                    : throw prism_rtl::Panic("no arm matched");
                });
            });
            });
            })
                : prism_rtl::finished(en_p4);
            });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<crate::lower::types::Env> MovedOnce::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& arm_p2 = this->arm_p2;
    const auto& binds_p3 = this->binds_p3;
    return fold_job(binds_p3, env_p1, ({
        auto lx_p0_1 = lx_p0;
        auto arm_p2_2 = arm_p2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::types::Env>(std::tuple<crate::lower::types::Env, std::tuple<Text, crate::lower::types::Bn>>)>>(prism_rtl::rc([=, lx_p0_1 = std::move(lx_p0_1), arm_p2_2 = std::move(arm_p2_2)](std::tuple<crate::lower::types::Env, std::tuple<Text, crate::lower::types::Bn>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_p0_1_3 = lx_p0_1;
            auto arm_p2_2_3 = arm_p2_2;
            entered(once_job([=, lx_p0_1_3 = std::move(lx_p0_1_3), arm_p2_2_3 = std::move(arm_p2_2_3)]() {
            return ({
                auto en_p4 = p0;
                auto [nkey_p5, bn_p6] = p1;
                ({
                prism_rtl::is<crate::lower::types::Bn::BnLocal>(bn_p6) && prism_rtl::is<crate::lower::model::Ex::XVar>(prism_rtl::as<crate::lower::types::Bn::BnLocal>(bn_p6).a0) && prism_rtl::is<crate::lower::types::Holding::Owned>(prism_rtl::as<crate::lower::types::Bn::BnLocal>(bn_p6).a1) ? ({
                auto&& rs_p7 = prism_rtl::as<crate::lower::model::Ex::XVar>(prism_rtl::as<crate::lower::types::Bn::BnLocal>(bn_p6).a0).a0;
                auto&& bt_p8 = prism_rtl::as<crate::lower::types::Bn::BnLocal>(bn_p6).a2;
                ({
                auto bt_p8_3 = bt_p8;
                auto rs_p7_4 = rs_p7;
                call_then(start_only_read(lx_p0_1_3, arm_p2_2_3, nkey_p5), [=, bt_p8_3 = std::move(bt_p8_3), rs_p7_4 = std::move(rs_p7_4)](std::optional<crate::syntax::Expr> only_read_66897) {
                return ({
                    prism_rtl::is_some(only_read_66897) ? ({
                    auto&& x_p9 = prism_rtl::some_of(only_read_66897);
                    prism_rtl::finished(crate::lower::types::bind_span(en_p4, crate::lower::place_key(lx_p0_1_3, prism_rtl::deref(x_p9).span), crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XVar{rs_p7_4}), bt_p8_3})));
                })
                    : prism_rtl::is_none(only_read_66897) ? prism_rtl::finished(en_p4)
                    : throw prism_rtl::Panic("no arm matched");
                });
            });
            });
            })
                : prism_rtl::finished(en_p4);
            });
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start MovedOnce, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Env> start_moved_once(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Arm arm_p2, Array<std::tuple<Text, crate::lower::types::Bn>> binds_p3) {
    return prism_rtl::make_rc<MovedOnce>(lx_p0, env_p1, arm_p2, binds_p3);
}


/// ?OnlyRead: unbounded fn Lx, Arm, Text -> ?Expr
std::optional<crate::syntax::Expr> only_read(const crate::lower::Lx& lx_p0, const crate::syntax::Arm& arm_p1, const Text& nkey_p2) {
    auto text_p3 = crate::lower::functions::src_text(lx_p0, lx_p0.file, prism_rtl::deref(arm_p1.body).span);
    auto in_guard_p5 = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = arm_p1.guard;
        if (prism_rtl::is_some(_m)) {
            auto&& ge_p4 = prism_rtl::some_of(_m);
            _v.set(word_count(crate::lower::functions::src_text(lx_p0, lx_p0.file, prism_rtl::deref(ge_p4).span), nkey_p2) > Nat(0u));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(false);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto reads_p8 = filter(crate::check::typed::print::block_exprs(arm_p1.body), [&](const crate::syntax::Expr& x_p6) {
        return ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            auto&& _m = prism_rtl::deref(prism_rtl::deref(x_p6).kind);
            if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
                auto&& n_p7 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
                _v.set((len(n_p7->path_) == Nat(1u)) && (crate::check::env::sname_key(n_p7) == nkey_p2));
                goto _done;
            }
            {
                _v.set(false);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto plain_p9 = (((!std::move(in_guard_p5)) && (word_count(text_p3, nkey_p2) == Nat(1u))) && (!crate::syntax::lexer::chars::contains(text_p3, Text::lit("\\|")))) && (len(matches(([]() -> const Regex& { static const Regex r = Regex::lit("\\b(while|for)\\b", ""); return r; }()), text_p3)) == Nat(0u));
    return std::move(plain_p9) && (len(reads_p8) == Nat(1u))
        ? index(reads_p8, Nat(0u))
        : std::optional<crate::syntax::Expr>{};
}


prism_rtl::Turn<std::optional<crate::syntax::Expr>> OnlyRead::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& arm_p1 = this->arm_p1;
    const auto& nkey_p2 = this->nkey_p2;
    auto text_p3 = crate::lower::functions::src_text(lx_p0, lx_p0->file, prism_rtl::deref(prism_rtl::deref(arm_p1).body).span);
    auto in_guard_p5 = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = prism_rtl::deref(arm_p1).guard;
        if (prism_rtl::is_some(_m)) {
            auto&& ge_p4 = prism_rtl::some_of(_m);
            _v.set(word_count(crate::lower::functions::src_text(lx_p0, lx_p0->file, prism_rtl::deref(ge_p4).span), nkey_p2) > Nat(0u));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(false);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto arm_p1_1 = arm_p1;
    auto nkey_p2_2 = nkey_p2;
    return call_then(crate::check::typed::print::start_block_exprs(prism_rtl::deref(arm_p1_1).body), [=](Array<crate::syntax::Expr> block_exprs_67301) {
        return ({
            auto reads_p8 = filter(block_exprs_67301, [&](const crate::syntax::Expr& x_p6) {
                return ({
                    __label__ _done;
                    prism_rtl::Slot<bool> _v;
                    auto&& _m = prism_rtl::deref(prism_rtl::deref(x_p6).kind);
                    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
                        auto&& n_p7 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
                        _v.set((len(n_p7->path_) == Nat(1u)) && (crate::check::env::sname_key(n_p7) == nkey_p2_2));
                        goto _done;
                    }
                    {
                        _v.set(false);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
            });
            auto plain_p9 = (((!in_guard_p5) && (word_count(text_p3, nkey_p2_2) == Nat(1u))) && (!crate::syntax::lexer::chars::contains(text_p3, Text::lit("\\|")))) && (len(matches(([]() -> const Regex& { static const Regex r = Regex::lit("\\b(while|for)\\b", ""); return r; }()), text_p3)) == Nat(0u));
            (std::move(plain_p9) && (len(reads_p8) == Nat(1u))
            ? prism_rtl::finished(index(reads_p8, Nat(0u)))
            : prism_rtl::finished(std::optional<crate::syntax::Expr>{}));
        });
    });
}


/// `Start OnlyRead, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<crate::syntax::Expr>> start_only_read(crate::lower::Lx lx_p0, crate::syntax::Arm arm_p1, Text nkey_p2) {
    return prism_rtl::make_rc<OnlyRead>(lx_p0, arm_p1, nkey_p2);
}


/// WordCount: fn Text, Text -> Nat
Nat word_count(const Text& text_p0, const Text& name_p1) {
    return len(filter(matches(([]() -> const Regex& { static const Regex r = Regex::lit("[?~$!@&]*[A-Za-z_][A-Za-z0-9_]*", ""); return r; }()), text_p0), [&](const Match& m_p2) { return m_p2->text == name_p1; }));
}


/// let dummyArm
crate::syntax::Arm dummy_arm() {
    return crate::syntax::Arm{.pattern = std::optional<crate::syntax::Pattern_>{}, .guard = std::optional<crate::syntax::Expr>{}, .body = crate::syntax::Block{.stmts = Array<crate::syntax::Stmt>{}, .inline_ = true, .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}}, .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}};
}


/// ArmPat: unbounded fn Lx, ?Pattern, Ty, Holding, Text -> PatOut
crate::lower::patterns::PatOut arm_pat(const crate::lower::Lx& lx_p0, const std::optional<crate::syntax::Pattern_>& opt1, const crate::check::types::Ty& ty_p2, const crate::lower::types::Holding& mode_p3, const Text& fresh_p4) {
    if (prism_rtl::is_some(opt1)) {
        auto&& p_p1 = prism_rtl::some_of(opt1);
        return crate::lower::patterns::rust_pat(lx_p0, p_p1, ty_p2, mode_p3, fresh_p4);
    }
    if (prism_rtl::is_none(opt1)) {
        return crate::lower::patterns::PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds = Array<crate::lower::model::Cc>{}, .binds = Array<std::tuple<Text, crate::lower::types::Bn>>{}};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::lower::patterns::PatOut> ArmPat::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& opt1 = this->opt1;
    const auto& ty_p2 = this->ty_p2;
    const auto& mode_p3 = this->mode_p3;
    const auto& fresh_p4 = this->fresh_p4;
    return ({
        prism_rtl::is_some(opt1) ? ({
        auto&& p_p1 = prism_rtl::some_of(opt1);
        prism_rtl::more(prism_rtl::rc(crate::lower::patterns::RustPat(lx_p0, p_p1, ty_p2, mode_p3, fresh_p4)));
    })
        : prism_rtl::is_none(opt1) ? prism_rtl::finished(crate::lower::patterns::PatOut{.pa = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds = Array<crate::lower::model::Cc>{}, .binds = Array<std::tuple<Text, crate::lower::types::Bn>>{}})
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ArmPat, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::patterns::PatOut> start_arm_pat(crate::lower::Lx lx_p0, std::optional<crate::syntax::Pattern_> opt1, crate::check::types::Ty ty_p2, crate::lower::types::Holding mode_p3, Text fresh_p4) {
    return prism_rtl::make_rc<ArmPat>(lx_p0, opt1, ty_p2, mode_p3, fresh_p4);
}


/// BlockValue: unbounded fn Lx, Env, Block -> Vl
crate::lower::types::Vl block_value(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Block& b_p2) {
    return is_given_block(b_p2.stmts)
        ? crate::lower::templates::given_value(lx_p0, env_p1, b_p2, block_ty(lx_p0, b_p2), b_p2.span)
        : plain_block_value(lx_p0, env_p1, b_p2);
}


prism_rtl::Turn<crate::lower::types::Vl> BlockValue::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& b_p2 = this->b_p2;
    return is_given_block(prism_rtl::deref(b_p2).stmts)
        ? ({
        auto b_p2_1 = b_p2;
        auto env_p1_2 = env_p1;
        auto lx_p0_3 = lx_p0;
        call_then(start_block_ty(lx_p0_3, b_p2_1), [=, env_p1_2 = std::move(env_p1_2)](crate::lower::model::OutTy block_ty_68451) { return prism_rtl::more(prism_rtl::rc(crate::lower::templates::GivenValue(lx_p0_3, env_p1_2, b_p2_1, block_ty_68451, prism_rtl::deref(b_p2_1).span))); });
    })
        : prism_rtl::more(prism_rtl::rc(PlainBlockValue(lx_p0, env_p1, b_p2)));
}


/// `Start BlockValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_block_value(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Block b_p2) {
    return prism_rtl::make_rc<BlockValue>(lx_p0, env_p1, b_p2);
}


/// IsGivenBlock: fn [Stmt] -> Bool
bool is_given_block(const Array<crate::syntax::Stmt>& stmts_p0) {
    return fold(stmts_p0, false, [&](const bool& f_p1, const crate::syntax::Stmt& s_p2) { return prism_rtl::deref(f_p1) || is_guardish(s_p2); });
}


/// IsGuardish: fn Stmt -> Bool
bool is_guardish(const crate::syntax::Stmt& s_p0) {
    auto&& _m = s_p0.kind;
    if (prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) && prism_rtl::is_none(prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SRequire>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SForbid>(_m)) {
        return true;
    }
    {
        return false;
    }
}


/// BlockTy: unbounded fn Lx, Block -> OutTy
crate::lower::model::OutTy block_ty(const crate::lower::Lx& lx_p0, const crate::syntax::Block& b_p1) {
    auto&& _m = prism_rtl::deref(or_(index(b_p1.stmts, crate::syntax::lexer::chars::dec(len(b_p1.stmts))), dummy_stmt_l())).kind;
    if (prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m)) {
        auto&& x_p2 = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
        return crate::lower::types::out_ty_of(lx_p0, crate::lower::types::peel(crate::lower::type_at(lx_p0, prism_rtl::deref(x_p2).span)));
    }
    {
        return crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{});
    }
}


prism_rtl::Turn<crate::lower::model::OutTy> BlockTy::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& b_p1 = this->b_p1;
    return ({
        auto&& _m = prism_rtl::deref(or_(index(prism_rtl::deref(b_p1).stmts, crate::syntax::lexer::chars::dec(len(prism_rtl::deref(b_p1).stmts))), dummy_stmt_l())).kind;
        prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m) ? ({
        auto&& x_p2 = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
        prism_rtl::more(prism_rtl::rc(crate::lower::types::OutTyOf(lx_p0, crate::lower::types::peel(crate::lower::type_at(lx_p0, prism_rtl::deref(x_p2).span)))));
    })
        : prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}));
    });
}


/// `Start BlockTy, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::OutTy> start_block_ty(crate::lower::Lx lx_p0, crate::syntax::Block b_p1) {
    return prism_rtl::make_rc<BlockTy>(lx_p0, b_p1);
}


/// PlainBlockValue: unbounded fn Lx, Env, Block -> Vl
crate::lower::types::Vl plain_block_value(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Block& b_p2) {
    auto n_p3 = len(b_p2.stmts);
    auto [dos_pf, env2_pg, last_oh] = run_to_end(fold_job(crate::check::errors::range0(n_p3), std::tuple{Array<crate::lower::model::Do>{}, env_p1, std::optional<crate::lower::types::Vl>{}}, ({
        auto b_p2_1 = b_p2;
        auto n_p3_2 = n_p3;
        auto lx_p0_3 = lx_p0;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env, std::optional<crate::lower::types::Vl>>>(std::tuple<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env, std::optional<crate::lower::types::Vl>>, Nat>)>>(prism_rtl::rc([=, b_p2_1 = std::move(b_p2_1), n_p3_2 = std::move(n_p3_2), lx_p0_3 = std::move(lx_p0_3)](std::tuple<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env, std::optional<crate::lower::types::Vl>>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto b_p2_1_4 = b_p2_1;
            auto n_p3_2_4 = n_p3_2;
            auto lx_p0_3_4 = lx_p0_3;
            entered(once_job([=, b_p2_1_4 = std::move(b_p2_1_4), n_p3_2_4 = std::move(n_p3_2_4), lx_p0_3_4 = std::move(lx_p0_3_4)]() {
            return ({
                auto [acc_p5, en_p6, lv_o7] = p0;
                auto i_p8 = p1;
                ({
                auto s_p9 = or_(index(b_p2_1_4.stmts, i_p8), dummy_stmt_l());
                (i_p8 + Nat(1u)) == n_p3_2_4
                ? ({
                auto&& _m = prism_rtl::deref(s_p9).kind;
                prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m) ? ({
                auto&& x_pa = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
                prism_rtl::finished(std::tuple{acc_p5, en_p6, std::optional(value_of(lx_p0_3_4, en_p6, x_pa))});
            })
                : call_then(start_block_stmt(lx_p0_3_4, en_p6, s_p9), [=](std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env> block_stmt_69493) {
                return ({
                    auto [more_pb, en2_pc] = block_stmt_69493;
                    (prism_rtl::finished(std::tuple{append(acc_p5, more_pb), en2_pc, std::optional<crate::lower::types::Vl>{}}));
                });
            });
            })
                : call_then(start_block_stmt(lx_p0_3_4, en_p6, s_p9), [=](std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env> block_stmt_69608) {
                return ({
                    auto [more_pd, en2_pe] = block_stmt_69608;
                    (prism_rtl::finished(std::tuple{append(acc_p5, more_pd), en2_pe, lv_o7}));
                });
            });
            });
            });
        }));
        });
    }));
    })));
    auto last_p4 = or_(last_oh, crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})}));
    return len(dos_pf) == Nat(0u)
        ? last_p4
        : crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBlock{dos_pf, prism_rtl::rc(crate::lower::types::own(last_p4))}), crate::lower::types::value_ty(last_p4)});
}


prism_rtl::Turn<crate::lower::types::Vl> PlainBlockValue::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& b_p2 = this->b_p2;
    auto n_p3 = len(prism_rtl::deref(b_p2).stmts);
    auto b_p2_1 = b_p2;
    auto env_p1_2 = env_p1;
    auto lx_p0_3 = lx_p0;
    return call_value(fold_job(crate::check::errors::range0(n_p3), std::tuple{Array<crate::lower::model::Do>{}, env_p1_2, std::optional<crate::lower::types::Vl>{}}, ({
        auto b_p2_1_4 = b_p2_1;
        auto n_p3_4 = n_p3;
        auto lx_p0_3_5 = lx_p0_3;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env, std::optional<crate::lower::types::Vl>>>(std::tuple<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env, std::optional<crate::lower::types::Vl>>, Nat>)>>(prism_rtl::rc([=, b_p2_1_4 = std::move(b_p2_1_4), n_p3_4 = std::move(n_p3_4), lx_p0_3_5 = std::move(lx_p0_3_5)](std::tuple<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env, std::optional<crate::lower::types::Vl>>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto b_p2_1_4_5 = b_p2_1_4;
            auto n_p3_4_5 = n_p3_4;
            auto lx_p0_3_5_5 = lx_p0_3_5;
            entered(once_job([=, b_p2_1_4_5 = std::move(b_p2_1_4_5), n_p3_4_5 = std::move(n_p3_4_5), lx_p0_3_5_5 = std::move(lx_p0_3_5_5)]() {
            return ({
                auto [acc_p5, en_p6, lv_o7] = p0;
                auto i_p8 = p1;
                ({
                auto s_p9 = or_(index(prism_rtl::deref(b_p2_1_4_5).stmts, i_p8), dummy_stmt_l());
                (i_p8 + Nat(1u)) == n_p3_4_5
                ? ({
                auto&& _m = prism_rtl::deref(s_p9).kind;
                prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m) ? ({
                auto&& x_pa = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
                prism_rtl::finished(std::tuple{acc_p5, en_p6, std::optional(value_of(lx_p0_3_5_5, en_p6, x_pa))});
            })
                : call_then(start_block_stmt(lx_p0_3_5_5, en_p6, s_p9), [=](std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env> block_stmt_69493) {
                return ({
                    auto [more_pb, en2_pc] = block_stmt_69493;
                    (prism_rtl::finished(std::tuple{append(acc_p5, more_pb), en2_pc, std::optional<crate::lower::types::Vl>{}}));
                });
            });
            })
                : call_then(start_block_stmt(lx_p0_3_5_5, en_p6, s_p9), [=](std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env> block_stmt_69608) {
                return ({
                    auto [more_pd, en2_pe] = block_stmt_69608;
                    (prism_rtl::finished(std::tuple{append(acc_p5, more_pd), en2_pe, lv_o7}));
                });
            });
            });
            });
        }));
        });
    }));
    })), [=](std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env, std::optional<crate::lower::types::Vl>> fold_69239) {
        return ({
            auto [dos_pf, env2_pg, last_oh] = fold_69239;
            auto last_p4 = or_(last_oh, crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})}));
            len(dos_pf) == Nat(0u)
            ? prism_rtl::finished(last_p4)
            : prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBlock{dos_pf, prism_rtl::rc(crate::lower::types::own(last_p4))}), crate::lower::types::value_ty(last_p4)}));
        });
    });
}

}  // namespace crate::lower::expr
