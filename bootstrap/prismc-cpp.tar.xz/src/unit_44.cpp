// The module `Lower.Expr`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <lower/expr/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <lower/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>

// The module `Lower.Expr`, from `target/bootstrap/cpp-src/prismc/lower/expr.prism`.
namespace crate::lower::expr {

/// `Start ArgsFor, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::lower::model::Ex>> start_args_for_f(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::check::env::ValInfo v_p2, Array<crate::syntax::Arg> args_p3) {
    return prism_rtl::make_rc<ArgsFor>(lx_p0, env_p1, v_p2, args_p3);
}


/// let dummyExpr
crate::syntax::Expr dummy_expr_p() {
    return crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EError{})), .span_p = crate::syntax::Range{.start_p = Nat(0u), .end_p = Nat(0u)}};
}


/// CtorApp: unbounded fn Lx, Env, CtorInfo, [Arg], Range -> Vl
crate::lower::types::Vl ctor_app_f(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::check::env::CtorInfo& c_p2, const Array<crate::syntax::Arg>& args_p3, const crate::syntax::Range& span_p4) {
    auto t_p5 = crate::lower::types::out_ty_of_f(lx_p0, crate::lower::types::peel_f(crate::lower::type_at_f(lx_p0, span_p4)));
    auto owner_p6 = crate::prelude::or_(crate::prelude::get(prism_rtl::deref(lx_p0.g_p).types_p, c_p2.owner_p), crate::check::env::names::dummy_ty_info_p());
    auto ty_path_p7 = crate::lower::path_in_f(lx_p0, prism_rtl::deref(owner_p6).home_p, crate::lower::camel_f(crate::check::types::bare_name_f(c_p2.owner_p)));
    auto vals_p8 = ctor_args_f(lx_p0, env_p1, c_p2, args_p3);
    auto&& _m = c_p2.owner_p;
    {
        auto&& m36659_0 = _m;
        if (m36659_0 == Text::lit("Bool")) {
            return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBool{c_p2.name_p == Text::lit("True")}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutBool{})});
        }
    }
    {
        auto&& m36659_1 = _m;
        if (m36659_1 == Text::lit("Prelude.Error")) {
            auto kind_p9 = crate::prelude::or_(crate::prelude::index(vals_p8, Nat(0u)), crate::lower::model::Ex(crate::lower::model::Ex::XStr{Text::lit("")}));
            auto msg_pa = crate::prelude::or_(crate::prelude::index(vals_p8, Nat(1u)), crate::lower::model::Ex(crate::lower::model::Ex::XText{Text::lit("")}));
            auto made_pb = crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Error::new"), Array(std::vector{kind_p9, msg_pa})});
            if (prism_rtl::is<crate::lower::model::OutTy::OutRes>(t_p5)) {
                return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Err"), Array(std::vector{made_pb})}), t_p5});
            }
            {
                return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{made_pb, crate::lower::model::OutTy(crate::lower::model::OutTy::OutError{})});
            }
        }
    }
    {
        auto&& _m = prism_rtl::deref(owner_p6).body_p;
        if (prism_rtl::is<crate::check::env::TyBody::BRecord>(_m)) {
            auto&& fs_pc = prism_rtl::as<crate::check::env::TyBody::BRecord>(_m).a0;
            return crate::prelude::len(c_p2.fields_p) == Nat(0u)
                ? crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XPath{ty_path_p7}), t_p5})
                : crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XRecord{ty_path_p7, crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(crate::prelude::len(c_p2.fields_p)), ({
                auto c_p2x = c_p2;
                auto vals_p8x = vals_p8;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, crate::lower::model::Ex>>(Nat)>>(prism_rtl::rc([=, c_p2x = std::move(c_p2x), vals_p8x = std::move(vals_p8x)](Nat p0) {
                return ({
                    auto c_p2xy = c_p2x;
                    auto vals_p8xy = vals_p8x;
                    (crate::prelude::entered(crate::prelude::once_job([=, c_p2xy = std::move(c_p2xy), vals_p8xy = std::move(vals_p8xy)]() {
                    return ({
                        auto i_pd = p0;
                        (crate::prelude::call_then(crate::lower::start_field_spell_f(crate::lower::owner_of_f(prism_rtl::deref(c_p2xy).owner_p), crate::prelude::or_(crate::prelude::index(prism_rtl::deref(c_p2xy).fields_p, i_pd), Text::lit("")), crate::prelude::or_(crate::prelude::index(prism_rtl::deref(c_p2xy).args_p, i_pd), crate::check::types::Ty(crate::check::types::Ty::TyErr{}))), [=](Text field_spell_f_37256) { return prism_rtl::finished(std::tuple{field_spell_f_37256, crate::prelude::or_(crate::prelude::index(vals_p8xy, i_pd), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Default::default"), Array<crate::lower::model::Ex>{}}))}); }));
                    });
                })));
                });
            }));
            })))}), t_p5});
        }
        if (prism_rtl::is<crate::check::env::TyBody::BChoice>(_m)) {
            auto&& cases_pe = prism_rtl::as<crate::check::env::TyBody::BChoice>(_m).a0;
            auto is_unit_type_pf = ((crate::prelude::len(cases_pe) == Nat(1u)) && (crate::prelude::len(c_p2.args_p) == Nat(0u))) && crate::check::env::is_lower_text_f(crate::check::types::bare_name_f(c_p2.name_p));
            auto is_newtype_pg = (crate::prelude::len(cases_pe) == Nat(1u)) && (crate::check::types::bare_name_f(c_p2.name_p) == crate::check::types::bare_name_f(c_p2.owner_p));
            auto path_ph = std::move(is_unit_type_pf) || std::move(is_newtype_pg)
                ? ty_path_p7
                : prism_rtl::cat(ty_path_p7, "::", crate::lower::camel_f(crate::check::types::bare_name_f(c_p2.name_p)));
            auto made_pi = crate::prelude::len(c_p2.args_p) == Nat(0u)
                ? crate::lower::model::Ex(crate::lower::model::Ex::XPath{path_ph})
                : crate::lower::model::Ex(crate::lower::model::Ex::XCtor{path_ph, vals_p8});
            return ((crate::prelude::len(prism_rtl::deref(owner_p6).params_p) > Nat(0u)) && (!std::move(is_unit_type_pf))) && (!std::move(is_newtype_pg))
                ? crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XTyped{prism_rtl::rc(made_pi), built_ty_f(t_p5)}), t_p5})
                : crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{made_pi, t_p5});
        }
        {
            return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal_f(prism_rtl::cat("a constructor of ", c_p2.owner_p)), t_p5});
        }
    }
}


prism_rtl::Turn<crate::lower::types::Vl> CtorApp::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& c_p2 = this->c_p2;
    const auto& args_p3 = this->args_p3;
    const auto& span_p4 = this->span_p4;
    auto args_p3x = args_p3;
    auto c_p2x = c_p2;
    auto env_p1x = env_p1;
    auto lx_p0x = lx_p0;
    auto span_p4x = span_p4;
    return crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0x, crate::lower::types::peel_f(crate::lower::type_at_f(lx_p0x, span_p4x))), [=](crate::lower::model::OutTy out_ty_of_f_36458) {
        return ({
            auto t_p5 = out_ty_of_f_36458;
            auto owner_p6 = crate::prelude::or_(crate::prelude::get(prism_rtl::deref(prism_rtl::deref(lx_p0x).g_p).types_p, prism_rtl::deref(c_p2x).owner_p), crate::check::env::names::dummy_ty_info_p());
            auto ty_path_p7 = crate::lower::path_in_f(lx_p0x, prism_rtl::deref(owner_p6).home_p, crate::lower::camel_f(crate::check::types::bare_name_f(prism_rtl::deref(c_p2x).owner_p)));
            (crate::prelude::call_then(start_ctor_args_f(lx_p0x, env_p1x, c_p2x, args_p3x), [=, t_p5 = std::move(t_p5), owner_p6 = std::move(owner_p6), ty_path_p7 = std::move(ty_path_p7)](Array<crate::lower::model::Ex> ctor_args_f_36629) {
            return ({
                auto vals_p8 = ctor_args_f_36629;
                ({
                auto&& _m = prism_rtl::deref(c_p2x).owner_p;
                ({
                auto&& m36659_0 = _m;
                (m36659_0 == Text::lit("Bool"));
            }) ? ({
                auto&& m36659_0 = _m;
                prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBool{prism_rtl::deref(c_p2x).name_p == Text::lit("True")}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutBool{})}));
            })
                : ({
                auto&& m36659_1 = _m;
                (m36659_1 == Text::lit("Prelude.Error"));
            }) ? ({
                auto&& m36659_1 = _m;
                ({
                auto kind_p9 = crate::prelude::or_(crate::prelude::index(vals_p8, Nat(0u)), crate::lower::model::Ex(crate::lower::model::Ex::XStr{Text::lit("")}));
                auto msg_pa = crate::prelude::or_(crate::prelude::index(vals_p8, Nat(1u)), crate::lower::model::Ex(crate::lower::model::Ex::XText{Text::lit("")}));
                auto made_pb = crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Error::new"), Array(std::vector{kind_p9, msg_pa})});
                ({
                prism_rtl::is<crate::lower::model::OutTy::OutRes>(t_p5) ? prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Err"), Array(std::vector{made_pb})}), t_p5}))
                : prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{made_pb, crate::lower::model::OutTy(crate::lower::model::OutTy::OutError{})}));
            });
            });
            })
                : ({
                auto&& _m = prism_rtl::deref(owner_p6).body_p;
                prism_rtl::is<crate::check::env::TyBody::BRecord>(_m) ? ({
                auto&& fs_pc = prism_rtl::as<crate::check::env::TyBody::BRecord>(_m).a0;
                crate::prelude::len(prism_rtl::deref(c_p2x).fields_p) == Nat(0u)
                ? prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XPath{ty_path_p7}), t_p5}))
                : crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(crate::prelude::len(prism_rtl::deref(c_p2x).fields_p)), ({
                auto c_p2xx = c_p2x;
                auto vals_p8x = vals_p8;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, crate::lower::model::Ex>>(Nat)>>(prism_rtl::rc([=, c_p2xx = std::move(c_p2xx), vals_p8x = std::move(vals_p8x)](Nat p0) {
                return ({
                    auto c_p2xxy = c_p2xx;
                    auto vals_p8xy = vals_p8x;
                    (crate::prelude::entered(crate::prelude::once_job([=, c_p2xxy = std::move(c_p2xxy), vals_p8xy = std::move(vals_p8xy)]() {
                    return ({
                        auto i_pd = p0;
                        (crate::prelude::call_then(crate::lower::start_field_spell_f(crate::lower::owner_of_f(prism_rtl::deref(c_p2xxy).owner_p), crate::prelude::or_(crate::prelude::index(prism_rtl::deref(c_p2xxy).fields_p, i_pd), Text::lit("")), crate::prelude::or_(crate::prelude::index(prism_rtl::deref(c_p2xxy).args_p, i_pd), crate::check::types::Ty(crate::check::types::Ty::TyErr{}))), [=](Text field_spell_f_37256) { return prism_rtl::finished(std::tuple{field_spell_f_37256, crate::prelude::or_(crate::prelude::index(vals_p8xy, i_pd), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Default::default"), Array<crate::lower::model::Ex>{}}))}); }));
                    });
                })));
                });
            }));
            })), [=](Array<std::tuple<Text, crate::lower::model::Ex>> each_37218) { return prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XRecord{ty_path_p7, each_37218}), t_p5})); });
            })
                : prism_rtl::is<crate::check::env::TyBody::BChoice>(_m) ? ({
                auto&& cases_pe = prism_rtl::as<crate::check::env::TyBody::BChoice>(_m).a0;
                ({
                auto is_unit_type_pf = ((crate::prelude::len(cases_pe) == Nat(1u)) && (crate::prelude::len(prism_rtl::deref(c_p2x).args_p) == Nat(0u))) && crate::check::env::is_lower_text_f(crate::check::types::bare_name_f(prism_rtl::deref(c_p2x).name_p));
                auto is_newtype_pg = (crate::prelude::len(cases_pe) == Nat(1u)) && (crate::check::types::bare_name_f(prism_rtl::deref(c_p2x).name_p) == crate::check::types::bare_name_f(prism_rtl::deref(c_p2x).owner_p));
                auto path_ph = std::move(is_unit_type_pf) || std::move(is_newtype_pg)
                    ? ty_path_p7
                    : prism_rtl::cat(ty_path_p7, "::", crate::lower::camel_f(crate::check::types::bare_name_f(prism_rtl::deref(c_p2x).name_p)));
                auto made_pi = crate::prelude::len(prism_rtl::deref(c_p2x).args_p) == Nat(0u)
                    ? crate::lower::model::Ex(crate::lower::model::Ex::XPath{path_ph})
                    : crate::lower::model::Ex(crate::lower::model::Ex::XCtor{path_ph, vals_p8});
                ((crate::prelude::len(prism_rtl::deref(owner_p6).params_p) > Nat(0u)) && (!std::move(is_unit_type_pf))) && (!std::move(is_newtype_pg))
                ? prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XTyped{prism_rtl::rc(made_pi), built_ty_f(t_p5)}), t_p5}))
                : prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{made_pi, t_p5}));
            });
            })
                : prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{refusal_f(prism_rtl::cat("a constructor of ", prism_rtl::deref(c_p2x).owner_p)), t_p5}));
            });
            });
            });
        }));
        });
    });
}


/// `Start CtorApp, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_ctor_app_f(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::check::env::CtorInfo c_p2, Array<crate::syntax::Arg> args_p3, crate::syntax::Range span_p4) {
    return prism_rtl::make_rc<CtorApp>(lx_p0, env_p1, c_p2, args_p3, span_p4);
}


/// BuiltTy: fn OutTy -> OutTy
crate::lower::model::OutTy built_ty_f(const crate::lower::model::OutTy& t_p0) {
    if (prism_rtl::is<crate::lower::model::OutTy::OutFn>(t_p0)) {
        auto&& r_p1 = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t_p0).a1;
        return prism_rtl::deref(prism_rtl::deref(r_p1));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(t_p0)) {
        auto&& r_p2 = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(t_p0).a1;
        return prism_rtl::deref(prism_rtl::deref(r_p2));
    }
    {
        return t_p0;
    }
}


/// CtorFn: unbounded fn Lx, CtorInfo, [OutTy], Range, OutTy, Bool -> Vl
crate::lower::types::Vl ctor_fn_f(const crate::lower::Lx& lx_p0, const crate::check::env::CtorInfo& c_p1, const Array<crate::lower::model::OutTy>& pts_p2, const crate::syntax::Range& span_p3, const crate::lower::model::OutTy& t_p4, const bool& job_p5) {
    auto names_p6 = crate::prelude::each(crate::check::errors::range0_f(crate::prelude::len(pts_p2)), [&](const Nat& i_pa) { return prism_rtl::cat("a", i_pa); });
    auto fakes_p7 = crate::prelude::each(crate::check::errors::range0_f(crate::prelude::len(pts_p2)), [&](const Nat& i_pb) { return crate::syntax::Arg{.name_o = std::optional<crate::syntax::Ident>{}, .value_p = crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EAbsent{})), .span_p = crate::syntax::Range{.start_p = *Nat::from_int(Int(4000000000ll)) + i_pb, .end_p = *Nat::from_int(Int(4000000000ll)) + i_pb}}, .span_p = crate::syntax::Range{.start_p = Nat(0u), .end_p = Nat(0u)}}; });
    auto env_p8 = crate::prelude::fold(crate::check::errors::range0_f(crate::prelude::len(pts_p2)), crate::lower::types::empty_env_p(), [&](const crate::lower::types::Env& en_pc, const Nat& i_pd) {
        return crate::lower::types::bind_span_f(en_pc, crate::lower::place_key_f(lx_p0, crate::syntax::Range{.start_p = *Nat::from_int(Int(4000000000ll)) + i_pd, .end_p = *Nat::from_int(Int(4000000000ll)) + i_pd}), crate::lower::types::Vl(crate::lower::types::Vl::VlPlace{crate::lower::model::Ex(crate::lower::model::Ex::XVar{crate::prelude::or_(crate::prelude::index(names_p6, i_pd), Text::lit("a"))}), job_p5
            ? crate::lower::types::Holding(crate::lower::types::Holding::Owned{})
            : crate::lower::types::Holding(crate::lower::types::Holding::ByRef{}), crate::prelude::or_(crate::prelude::index(pts_p2, i_pd), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}))}));
    });
    auto made_p9 = crate::lower::types::own_f(ctor_app_f(lx_p0, env_p8, c_p1, fakes_p7, span_p3));
    return job_p5
        ? ({
        auto a_pe = ({
            __label__ _done;
            prism_rtl::Slot<crate::lower::model::OutTy> _v;
            if (prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(t_p4)) {
                auto&& x_pg = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(t_p4).a0;
                _v.set(prism_rtl::deref(prism_rtl::deref(x_pg)));
                goto _done;
            }
            {
                _v.set(crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}));
                goto _done;
            }
        _done:
            _v.take();
        });
        auto pa_pf = crate::prelude::len(pts_p2) == Nat(1u)
            ? crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("a0")})), a_pe})
            : crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{crate::prelude::each(names_p6, [&](const Text& nm_ph) { return crate::lower::model::Pa(crate::lower::model::Pa::PaBind{nm_ph}); })})), a_pe});
        (crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCast{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{pa_pf}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{crate::lower::helper_f(Text::lit("once_job")), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array<crate::lower::model::Pa>{}, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("prism_rtl::Turn::Finished"), Array(std::vector{made_p9})}))})})}))})})})), t_p4}), t_p4}));
    })
        : ({
        auto pas_pi = crate::prelude::each(crate::check::errors::range0_f(crate::prelude::len(pts_p2)), [&](const Nat& i_pj) { return crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{crate::prelude::or_(crate::prelude::index(names_p6, i_pj), Text::lit("a"))})), crate::lower::model::OutTy(crate::lower::model::OutTy::OutRef{prism_rtl::rc(crate::prelude::or_(crate::prelude::index(pts_p2, i_pj), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})))})}); });
        (crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{false, pas_pi, prism_rtl::rc(made_p9)})})}), t_p4}));
    });
}


prism_rtl::Turn<crate::lower::types::Vl> CtorFn::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& c_p1 = this->c_p1;
    const auto& pts_p2 = this->pts_p2;
    const auto& span_p3 = this->span_p3;
    const auto& t_p4 = this->t_p4;
    const auto& job_p5 = this->job_p5;
    auto names_p6 = crate::prelude::each(crate::check::errors::range0_f(crate::prelude::len(pts_p2)), [&](const Nat& i_pa) { return prism_rtl::cat("a", i_pa); });
    auto fakes_p7 = crate::prelude::each(crate::check::errors::range0_f(crate::prelude::len(pts_p2)), [&](const Nat& i_pb) { return crate::syntax::Arg{.name_o = std::optional<crate::syntax::Ident>{}, .value_p = crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EAbsent{})), .span_p = crate::syntax::Range{.start_p = *Nat::from_int(Int(4000000000ll)) + i_pb, .end_p = *Nat::from_int(Int(4000000000ll)) + i_pb}}, .span_p = crate::syntax::Range{.start_p = Nat(0u), .end_p = Nat(0u)}}; });
    auto env_p8 = crate::prelude::fold(crate::check::errors::range0_f(crate::prelude::len(pts_p2)), crate::lower::types::empty_env_p(), [&](const crate::lower::types::Env& en_pc, const Nat& i_pd) {
        return crate::lower::types::bind_span_f(en_pc, crate::lower::place_key_f(lx_p0, crate::syntax::Range{.start_p = *Nat::from_int(Int(4000000000ll)) + i_pd, .end_p = *Nat::from_int(Int(4000000000ll)) + i_pd}), crate::lower::types::Vl(crate::lower::types::Vl::VlPlace{crate::lower::model::Ex(crate::lower::model::Ex::XVar{crate::prelude::or_(crate::prelude::index(names_p6, i_pd), Text::lit("a"))}), prism_rtl::deref(job_p5)
            ? crate::lower::types::Holding(crate::lower::types::Holding::Owned{})
            : crate::lower::types::Holding(crate::lower::types::Holding::ByRef{}), crate::prelude::or_(crate::prelude::index(pts_p2, i_pd), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}))}));
    });
    auto c_p1x = c_p1;
    auto job_p5x = prism_rtl::deref(job_p5);
    auto lx_p0x = lx_p0;
    auto pts_p2x = pts_p2;
    auto span_p3x = span_p3;
    auto t_p4x = t_p4;
    return crate::prelude::call_then(start_ctor_app_f(lx_p0x, env_p8, c_p1x, fakes_p7, span_p3x), [=](crate::lower::types::Vl ctor_app_f_39317) {
        return ({
            auto made_p9 = crate::lower::types::own_f(ctor_app_f_39317);
            job_p5x
            ? ({
            auto a_pe = ({
                __label__ _done;
                prism_rtl::Slot<crate::lower::model::OutTy> _v;
                if (prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(t_p4x)) {
                    auto&& x_pg = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(t_p4x).a0;
                    _v.set(prism_rtl::deref(prism_rtl::deref(x_pg)));
                    goto _done;
                }
                {
                    _v.set(crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}));
                    goto _done;
                }
            _done:
                _v.take();
            });
            auto pa_pf = crate::prelude::len(pts_p2x) == Nat(1u)
                ? crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("a0")})), a_pe})
                : crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{crate::prelude::each(names_p6, [&](const Text& nm_ph) { return crate::lower::model::Pa(crate::lower::model::Pa::PaBind{nm_ph}); })})), a_pe});
            (prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCast{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{pa_pf}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{crate::lower::helper_f(Text::lit("once_job")), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array<crate::lower::model::Pa>{}, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("prism_rtl::Turn::Finished"), Array(std::vector{made_p9})}))})})}))})})})), t_p4x}), t_p4x})));
        })
            : ({
            auto pas_pi = crate::prelude::each(crate::check::errors::range0_f(crate::prelude::len(pts_p2x)), [&](const Nat& i_pj) { return crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{crate::prelude::or_(crate::prelude::index(names_p6, i_pj), Text::lit("a"))})), crate::lower::model::OutTy(crate::lower::model::OutTy::OutRef{prism_rtl::rc(crate::prelude::or_(crate::prelude::index(pts_p2x, i_pj), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})))})}); });
            (prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{false, pas_pi, prism_rtl::rc(made_p9)})})}), t_p4x})));
        });
        });
    });
}


/// `Start CtorFn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_ctor_fn_f(crate::lower::Lx lx_p0, crate::check::env::CtorInfo c_p1, Array<crate::lower::model::OutTy> pts_p2, crate::syntax::Range span_p3, crate::lower::model::OutTy t_p4, bool job_p5) {
    return prism_rtl::make_rc<CtorFn>(lx_p0, c_p1, pts_p2, span_p3, t_p4, job_p5);
}


/// IsNamedArg: fn Arg -> Bool
bool is_named_arg_f(const crate::syntax::Arg& a_p0) {
    auto&& _m = a_p0.name_o;
    if (prism_rtl::is_some(_m)) {
        return true;
    }
    if (prism_rtl::is_none(_m)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// CtorArgs: unbounded fn Lx, Env, CtorInfo, [Arg] -> [Ex]
Array<crate::lower::model::Ex> ctor_args_f(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::check::env::CtorInfo& c_p2, const Array<crate::syntax::Arg>& args_p3) {
    auto named_p4 = crate::prelude::fold(args_p3, false, [&](const bool& f_p6, const crate::syntax::Arg& a_p7) { return prism_rtl::deref(f_p6) || is_named_arg_f(a_p7); });
    auto ordered_p5 = std::move(named_p4)
        ? crate::prelude::each(c_p2.fields_p, [&](const Text& f_p8) {
        return crate::prelude::fold(args_p3, std::optional<crate::syntax::Expr>{}, [&](const std::optional<crate::syntax::Expr>& found_o9, const crate::syntax::Arg& a_pa) {
            return ({
                __label__ _done;
                prism_rtl::Slot<std::optional<crate::syntax::Expr>> _v;
                auto&& _m = prism_rtl::deref(a_pa).name_o;
                if (prism_rtl::is_some(_m)) {
                    auto&& n_pb = prism_rtl::some_of(_m);
                    _v.set(prism_rtl::deref(n_pb).name_p == f_p8
                        ? std::optional(prism_rtl::deref(a_pa).value_p)
                        : found_o9);
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(found_o9);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
        });
    })
        : crate::prelude::each(args_p3, [&](const crate::syntax::Arg& a_pc) { return std::optional(prism_rtl::deref(a_pc).value_p); });
    return crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(crate::prelude::len(ordered_p5)), ({
        auto ordered_p5x = ordered_p5;
        auto lx_p0x = lx_p0;
        auto env_p1x = env_p1;
        auto c_p2x = c_p2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(Nat)>>(prism_rtl::rc([=, ordered_p5x = std::move(ordered_p5x), lx_p0x = std::move(lx_p0x), env_p1x = std::move(env_p1x), c_p2x = std::move(c_p2x)](Nat p0) {
        return ({
            auto ordered_p5xy = ordered_p5x;
            auto lx_p0xy = lx_p0x;
            auto env_p1xy = env_p1x;
            auto c_p2xy = c_p2x;
            (crate::prelude::entered(crate::prelude::once_job([=, ordered_p5xy = std::move(ordered_p5xy), lx_p0xy = std::move(lx_p0xy), env_p1xy = std::move(env_p1xy), c_p2xy = std::move(c_p2xy)]() {
            return ({
                auto i_pd = p0;
                ({
                auto&& _m = crate::prelude::index(ordered_p5xy, i_pd);
                prism_rtl::is_some(_m) && prism_rtl::is_some(prism_rtl::some_of(_m)) ? ({
                auto&& x_pe = prism_rtl::some_of(prism_rtl::some_of(_m));
                crate::prelude::call_then(start_value_of_f(lx_p0xy, env_p1xy, x_pe), [=](crate::lower::types::Vl value_of_f_40591) {
                return ({
                    auto v_pf = crate::lower::types::own_f(value_of_f_40591);
                    (prism_rtl::deref(c_p2xy).owner_p == Text::lit("Prelude.Error")) && (i_pd == Nat(0u))
                    ? prism_rtl::finished(v_pf)
                    : crate::lower::types::rc_field_f(lx_p0xy, prism_rtl::deref(c_p2xy).name_p, i_pd)
                    ? prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{v_pf})}))
                    : prism_rtl::finished(v_pf);
                });
            });
            })
                : prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Default::default"), Array<crate::lower::model::Ex>{}}));
            });
            });
        })));
        });
    })));
    })));
}


prism_rtl::Turn<Array<crate::lower::model::Ex>> CtorArgs::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& c_p2 = this->c_p2;
    const auto& args_p3 = this->args_p3;
    auto named_p4 = crate::prelude::fold(args_p3, false, [&](const bool& f_p6, const crate::syntax::Arg& a_p7) { return prism_rtl::deref(f_p6) || is_named_arg_f(a_p7); });
    auto ordered_p5 = std::move(named_p4)
        ? crate::prelude::each(prism_rtl::deref(c_p2).fields_p, [&](const Text& f_p8) {
        return crate::prelude::fold(args_p3, std::optional<crate::syntax::Expr>{}, [&](const std::optional<crate::syntax::Expr>& found_o9, const crate::syntax::Arg& a_pa) {
            return ({
                __label__ _done;
                prism_rtl::Slot<std::optional<crate::syntax::Expr>> _v;
                auto&& _m = prism_rtl::deref(a_pa).name_o;
                if (prism_rtl::is_some(_m)) {
                    auto&& n_pb = prism_rtl::some_of(_m);
                    _v.set(prism_rtl::deref(n_pb).name_p == f_p8
                        ? std::optional(prism_rtl::deref(a_pa).value_p)
                        : found_o9);
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(found_o9);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
        });
    })
        : crate::prelude::each(args_p3, [&](const crate::syntax::Arg& a_pc) { return std::optional(prism_rtl::deref(a_pc).value_p); });
    return crate::prelude::each_job(crate::check::errors::range0_f(crate::prelude::len(ordered_p5)), ({
        auto ordered_p5x = ordered_p5;
        auto lx_p0x = lx_p0;
        auto env_p1x = env_p1;
        auto c_p2x = c_p2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(Nat)>>(prism_rtl::rc([=, ordered_p5x = std::move(ordered_p5x), lx_p0x = std::move(lx_p0x), env_p1x = std::move(env_p1x), c_p2x = std::move(c_p2x)](Nat p0) {
        return ({
            auto ordered_p5xy = ordered_p5x;
            auto lx_p0xy = lx_p0x;
            auto env_p1xy = env_p1x;
            auto c_p2xy = c_p2x;
            (crate::prelude::entered(crate::prelude::once_job([=, ordered_p5xy = std::move(ordered_p5xy), lx_p0xy = std::move(lx_p0xy), env_p1xy = std::move(env_p1xy), c_p2xy = std::move(c_p2xy)]() {
            return ({
                auto i_pd = p0;
                ({
                auto&& _m = crate::prelude::index(ordered_p5xy, i_pd);
                prism_rtl::is_some(_m) && prism_rtl::is_some(prism_rtl::some_of(_m)) ? ({
                auto&& x_pe = prism_rtl::some_of(prism_rtl::some_of(_m));
                crate::prelude::call_then(start_value_of_f(lx_p0xy, env_p1xy, x_pe), [=](crate::lower::types::Vl value_of_f_40591) {
                return ({
                    auto v_pf = crate::lower::types::own_f(value_of_f_40591);
                    (prism_rtl::deref(c_p2xy).owner_p == Text::lit("Prelude.Error")) && (i_pd == Nat(0u))
                    ? prism_rtl::finished(v_pf)
                    : crate::lower::types::rc_field_f(lx_p0xy, prism_rtl::deref(c_p2xy).name_p, i_pd)
                    ? prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{v_pf})}))
                    : prism_rtl::finished(v_pf);
                });
            });
            })
                : prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Default::default"), Array<crate::lower::model::Ex>{}}));
            });
            });
        })));
        });
    })));
    }))->cycle();
}


/// `Start CtorArgs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::lower::model::Ex>> start_ctor_args_f(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::check::env::CtorInfo c_p2, Array<crate::syntax::Arg> args_p3) {
    return prism_rtl::make_rc<CtorArgs>(lx_p0, env_p1, c_p2, args_p3);
}


/// MethodCall: unbounded fn Lx, Env, ValInfo, [Arg], Range, OutTy -> Vl
crate::lower::types::Vl method_call_f(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::check::env::ValInfo& v_p2, const Array<crate::syntax::Arg>& args_p3, const crate::syntax::Range& span_p4, const crate::lower::model::OutTy& t_p5) {
    auto cls_p6 = crate::prelude::or_(crate::prelude::index(crate::prelude::each(prism_rtl::deref(v_p2.scheme_p).bounds_p, [&](const std::tuple<Text, Text>& _p0) {
        auto&& c_p9 = std::get<1>(_p0);
        return c_p9;
    }), Nat(0u)), Text::lit(""));
    auto m_p7 = crate::check::types::bare_name_f(v_p2.qk_p);
    auto vals_p8 = crate::prelude::run_to_end(crate::prelude::each_job(args_p3, ({
        auto lx_p0x = lx_p0;
        auto env_p1x = env_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::types::Vl>(crate::syntax::Arg)>>(prism_rtl::rc([=, lx_p0x = std::move(lx_p0x), env_p1x = std::move(env_p1x)](crate::syntax::Arg p0) {
        return ({
            auto lx_p0xy = lx_p0x;
            auto env_p1xy = env_p1x;
            (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xy = std::move(lx_p0xy), env_p1xy = std::move(env_p1xy)]() {
            return ({
                auto a_pa = p0;
                (prism_rtl::more(prism_rtl::rc(ValueOf(lx_p0xy, env_p1xy, prism_rtl::deref(a_pa).value_p))));
            });
        })));
        });
    })));
    })));
    return crate::syntax::lexer::chars::has_prefix_f(cls_p6, Text::lit("Prelude."))
        ? prelude_method_f(lx_p0, cls_p6, m_p7, vals_p8, span_p4, t_p5)
        : ({
        auto tr_pb = crate::prelude::or_(crate::prelude::get(prism_rtl::deref(lx_p0.g_p).traits_p, cls_p6), dummy_trait_info_p());
        auto path_pc = crate::lower::path_in_f(lx_p0, prism_rtl::deref(tr_pb).home_p, prism_rtl::cat(crate::lower::camel_f(crate::check::types::bare_name_f(cls_p6)), "::", crate::prelude::or_(crate::prelude::get(lx_p0.rs_names_p, v_p2.qk_p), crate::lower::snake_f(m_p7))));
        (crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{path_pc, crate::prelude::run_to_end(crate::prelude::each_job(args_p3, ({
        auto lx_p0x = lx_p0;
        auto env_p1x = env_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::Arg)>>(prism_rtl::rc([=, lx_p0x = std::move(lx_p0x), env_p1x = std::move(env_p1x)](crate::syntax::Arg p0) {
        return ({
            auto lx_p0xy = lx_p0x;
            auto env_p1xy = env_p1x;
            (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xy = std::move(lx_p0xy), env_p1xy = std::move(env_p1xy)]() {
            return ({
                auto a_pd = p0;
                (prism_rtl::more(prism_rtl::rc(Argument(lx_p0xy, env_p1xy, prism_rtl::deref(a_pd).value_p))));
            });
        })));
        });
    })));
    })))}), t_p5}));
    });
}


prism_rtl::Turn<crate::lower::types::Vl> MethodCall::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& v_p2 = this->v_p2;
    const auto& args_p3 = this->args_p3;
    const auto& span_p4 = this->span_p4;
    const auto& t_p5 = this->t_p5;
    auto cls_p6 = crate::prelude::or_(crate::prelude::index(crate::prelude::each(prism_rtl::deref(prism_rtl::deref(v_p2).scheme_p).bounds_p, [&](const std::tuple<Text, Text>& _p0) {
        auto&& c_p9 = std::get<1>(_p0);
        return c_p9;
    }), Nat(0u)), Text::lit(""));
    auto m_p7 = crate::check::types::bare_name_f(prism_rtl::deref(v_p2).qk_p);
    auto args_p3x = args_p3;
    auto env_p1x = env_p1;
    auto lx_p0x = lx_p0;
    auto span_p4x = span_p4;
    auto t_p5x = t_p5;
    auto v_p2x = v_p2;
    return crate::prelude::call_value(crate::prelude::each_job(args_p3x, ({
        auto lx_p0xx = lx_p0x;
        auto env_p1xx = env_p1x;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::types::Vl>(crate::syntax::Arg)>>(prism_rtl::rc([=, lx_p0xx = std::move(lx_p0xx), env_p1xx = std::move(env_p1xx)](crate::syntax::Arg p0) {
        return ({
            auto lx_p0xxy = lx_p0xx;
            auto env_p1xxy = env_p1xx;
            (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xxy = std::move(lx_p0xxy), env_p1xxy = std::move(env_p1xxy)]() {
            return ({
                auto a_pa = p0;
                (prism_rtl::more(prism_rtl::rc(ValueOf(lx_p0xxy, env_p1xxy, prism_rtl::deref(a_pa).value_p))));
            });
        })));
        });
    })));
    })), [=](Array<crate::lower::types::Vl> each_41218) {
        return ({
            auto vals_p8 = each_41218;
            (crate::syntax::lexer::chars::has_prefix_f(cls_p6, Text::lit("Prelude."))
            ? prism_rtl::more(prism_rtl::rc(PreludeMethod(lx_p0x, cls_p6, m_p7, vals_p8, span_p4x, t_p5x)))
            : ({
            auto tr_pb = crate::prelude::or_(crate::prelude::get(prism_rtl::deref(prism_rtl::deref(lx_p0x).g_p).traits_p, cls_p6), dummy_trait_info_p());
            auto path_pc = crate::lower::path_in_f(lx_p0x, prism_rtl::deref(tr_pb).home_p, prism_rtl::cat(crate::lower::camel_f(crate::check::types::bare_name_f(cls_p6)), "::", crate::prelude::or_(crate::prelude::get(prism_rtl::deref(lx_p0x).rs_names_p, prism_rtl::deref(v_p2x).qk_p), crate::lower::snake_f(m_p7))));
            (crate::prelude::call_value(crate::prelude::each_job(args_p3x, ({
            auto lx_p0xx = lx_p0x;
            auto env_p1xx = env_p1x;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::Arg)>>(prism_rtl::rc([=, lx_p0xx = std::move(lx_p0xx), env_p1xx = std::move(env_p1xx)](crate::syntax::Arg p0) {
            return ({
                auto lx_p0xxy = lx_p0xx;
                auto env_p1xxy = env_p1xx;
                (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xxy = std::move(lx_p0xxy), env_p1xxy = std::move(env_p1xxy)]() {
                return ({
                    auto a_pd = p0;
                    (prism_rtl::more(prism_rtl::rc(Argument(lx_p0xxy, env_p1xxy, prism_rtl::deref(a_pd).value_p))));
                });
            })));
            });
        })));
        })), [=, path_pc = std::move(path_pc)](Array<crate::lower::model::Ex> each_41526) { return prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{path_pc, each_41526}), t_p5x})); }));
        }));
        });
    });
}


/// `Start MethodCall, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_method_call_f(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::check::env::ValInfo v_p2, Array<crate::syntax::Arg> args_p3, crate::syntax::Range span_p4, crate::lower::model::OutTy t_p5) {
    return prism_rtl::make_rc<MethodCall>(lx_p0, env_p1, v_p2, args_p3, span_p4, t_p5);
}


/// let dummyTraitInfo
crate::check::env::TraitInfo dummy_trait_info_p() {
    return crate::check::env::TraitInfo{.name_p = Text::lit(""), .home_p = Text::lit(""), .param_p = Text::lit("a"), .supers_p = Array<Text>{}, .methods_p = Array<Text>{}, .defaults_p = Array<Text>{}, .assocs_p = Array<Text>{}, .file_p = Nat(0u), .span_p = crate::syntax::Range{.start_p = Nat(0u), .end_p = Nat(0u)}};
}


/// PreludeMethod: unbounded fn Lx, Text, Text, [Vl], Range, OutTy -> Vl
crate::lower::types::Vl prelude_method_f(const crate::lower::Lx& lx_p0, const Text& cls_p1, const Text& m_p2, const Array<crate::lower::types::Vl>& vals_p3, const crate::syntax::Range& span_p4, const crate::lower::model::OutTy& t_p5) {
    auto a_p6 = crate::prelude::or_(crate::prelude::index(vals_p3, Nat(0u)), crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})}));
    auto b_p7 = crate::prelude::or_(crate::prelude::index(vals_p3, Nat(1u)), crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})}));
    {
        auto&& m41945_0 = m_p2;
        if (m41945_0 == Text::lit("Show")) {
            return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{crate::lower::helper_f(Text::lit("show_text")), Array(std::vector{crate::lower::types::ref_f(a_p6)})}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutText{})});
        }
    }
    {
        auto&& m41945_1 = m_p2;
        if (m41945_1 == Text::lit("Compare")) {
            return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{crate::lower::helper_f(Text::lit("compare")), Array(std::vector{crate::lower::types::ref_f(a_p6), crate::lower::types::ref_f(b_p7)})}), t_p5});
        }
    }
    {
        auto&& m41945_2 = m_p2;
        if (m41945_2 == Text::lit("Children")) {
            return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{crate::lower::helper_f(Text::lit("children")), Array(std::vector{crate::lower::types::ref_f(a_p6)})}), t_p5});
        }
    }
    {
        return op_value_f(lx_p0, m_p2, a_p6, b_p7, span_p4, t_p5);
    }
}


prism_rtl::Turn<crate::lower::types::Vl> PreludeMethod::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& cls_p1 = this->cls_p1;
    const auto& m_p2 = this->m_p2;
    const auto& vals_p3 = this->vals_p3;
    const auto& span_p4 = this->span_p4;
    const auto& t_p5 = this->t_p5;
    auto a_p6 = crate::prelude::or_(crate::prelude::index(vals_p3, Nat(0u)), crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})}));
    auto b_p7 = crate::prelude::or_(crate::prelude::index(vals_p3, Nat(1u)), crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})}));
    return ({
        ({
        auto&& m41945_0 = m_p2;
        (m41945_0 == Text::lit("Show"));
    }) ? ({
        auto&& m41945_0 = m_p2;
        prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{crate::lower::helper_f(Text::lit("show_text")), Array(std::vector{crate::lower::types::ref_f(a_p6)})}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutText{})}));
    })
        : ({
        auto&& m41945_1 = m_p2;
        (m41945_1 == Text::lit("Compare"));
    }) ? ({
        auto&& m41945_1 = m_p2;
        prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{crate::lower::helper_f(Text::lit("compare")), Array(std::vector{crate::lower::types::ref_f(a_p6), crate::lower::types::ref_f(b_p7)})}), t_p5}));
    })
        : ({
        auto&& m41945_2 = m_p2;
        (m41945_2 == Text::lit("Children"));
    }) ? ({
        auto&& m41945_2 = m_p2;
        prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{crate::lower::helper_f(Text::lit("children")), Array(std::vector{crate::lower::types::ref_f(a_p6)})}), t_p5}));
    })
        : prism_rtl::finished(op_value_f(lx_p0, m_p2, a_p6, b_p7, span_p4, t_p5));
    });
}


/// `Start PreludeMethod, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_prelude_method_f(crate::lower::Lx lx_p0, Text cls_p1, Text m_p2, Array<crate::lower::types::Vl> vals_p3, crate::syntax::Range span_p4, crate::lower::model::OutTy t_p5) {
    return prism_rtl::make_rc<PreludeMethod>(lx_p0, cls_p1, m_p2, vals_p3, span_p4, t_p5);
}


/// BinaryValue: unbounded fn Lx, Env, Text, Expr, Expr, Range -> Vl
crate::lower::types::Vl binary_value_f(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const Text& op_p2, const crate::syntax::Expr& l_p3, const crate::syntax::Expr& r_p4, const crate::syntax::Range& span_p5) {
    auto t_p6 = crate::lower::types::out_ty_of_f(lx_p0, crate::lower::types::peel_f(crate::lower::type_at_f(lx_p0, span_p5)));
    {
        auto&& m42400_0 = op_p2;
        if (m42400_0 == Text::lit("and")) {
            return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBin{crate::lower::model::BinOp(crate::lower::model::BinOp::OpAnd{}), prism_rtl::rc(crate::lower::types::as_bool_f(value_of_f(lx_p0, env_p1, l_p3))), prism_rtl::rc(crate::lower::types::as_bool_f(value_of_f(lx_p0, env_p1, r_p4)))}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutBool{})});
        }
    }
    {
        auto&& m42400_1 = op_p2;
        if (m42400_1 == Text::lit("or")) {
            return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBin{crate::lower::model::BinOp(crate::lower::model::BinOp::OpOr{}), prism_rtl::rc(crate::lower::types::as_bool_f(value_of_f(lx_p0, env_p1, l_p3))), prism_rtl::rc(crate::lower::types::as_bool_f(value_of_f(lx_p0, env_p1, r_p4)))}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutBool{})});
        }
    }
    {
        auto&& m42400_2 = op_p2;
        if (m42400_2 == Text::lit("on")) {
            return value_of_f(lx_p0, env_p1, l_p3);
        }
    }
    {
        return op_value_f(lx_p0, op_p2, value_of_f(lx_p0, env_p1, l_p3), value_of_f(lx_p0, env_p1, r_p4), span_p5, t_p6);
    }
}


prism_rtl::Turn<crate::lower::types::Vl> BinaryValue::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& op_p2 = this->op_p2;
    const auto& l_p3 = this->l_p3;
    const auto& r_p4 = this->r_p4;
    const auto& span_p5 = this->span_p5;
    auto env_p1x = env_p1;
    auto l_p3x = l_p3;
    auto lx_p0x = lx_p0;
    auto op_p2x = op_p2;
    auto r_p4x = r_p4;
    auto span_p5x = span_p5;
    return crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0x, crate::lower::types::peel_f(crate::lower::type_at_f(lx_p0x, span_p5x))), [=](crate::lower::model::OutTy out_ty_of_f_42359) {
        return ({
            auto t_p6 = out_ty_of_f_42359;
            ({
            ({
            auto&& m42400_0 = op_p2x;
            (m42400_0 == Text::lit("and"));
        }) ? ({
            auto&& m42400_0 = op_p2x;
            crate::prelude::call_then(start_value_of_f(lx_p0x, env_p1x, l_p3x), [=](crate::lower::types::Vl value_of_f_42455) { return crate::prelude::call_then(start_value_of_f(lx_p0x, env_p1x, r_p4x), [=](crate::lower::types::Vl value_of_f_42486) { return prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBin{crate::lower::model::BinOp(crate::lower::model::BinOp::OpAnd{}), prism_rtl::rc(crate::lower::types::as_bool_f(value_of_f_42455)), prism_rtl::rc(crate::lower::types::as_bool_f(value_of_f_42486))}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutBool{})})); }); });
        })
            : ({
            auto&& m42400_1 = op_p2x;
            (m42400_1 == Text::lit("or"));
        }) ? ({
            auto&& m42400_1 = op_p2x;
            crate::prelude::call_then(start_value_of_f(lx_p0x, env_p1x, l_p3x), [=](crate::lower::types::Vl value_of_f_42560) { return crate::prelude::call_then(start_value_of_f(lx_p0x, env_p1x, r_p4x), [=](crate::lower::types::Vl value_of_f_42591) { return prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBin{crate::lower::model::BinOp(crate::lower::model::BinOp::OpOr{}), prism_rtl::rc(crate::lower::types::as_bool_f(value_of_f_42560)), prism_rtl::rc(crate::lower::types::as_bool_f(value_of_f_42591))}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutBool{})})); }); });
        })
            : ({
            auto&& m42400_2 = op_p2x;
            (m42400_2 == Text::lit("on"));
        }) ? ({
            auto&& m42400_2 = op_p2x;
            prism_rtl::more(prism_rtl::rc(ValueOf(lx_p0x, env_p1x, l_p3x)));
        })
            : crate::prelude::call_then(start_value_of_f(lx_p0x, env_p1x, l_p3x), [=, t_p6 = std::move(t_p6)](crate::lower::types::Vl value_of_f_42857) { return crate::prelude::call_then(start_value_of_f(lx_p0x, env_p1x, r_p4x), [=](crate::lower::types::Vl value_of_f_42879) { return prism_rtl::finished(op_value_f(lx_p0x, op_p2x, value_of_f_42857, value_of_f_42879, span_p5x, t_p6)); }); });
        });
        });
    });
}


/// `Start BinaryValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_binary_value_f(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, Text op_p2, crate::syntax::Expr l_p3, crate::syntax::Expr r_p4, crate::syntax::Range span_p5) {
    return prism_rtl::make_rc<BinaryValue>(lx_p0, env_p1, op_p2, l_p3, r_p4, span_p5);
}


/// OpValue: fn Lx, Text, Vl, Vl, Range, OutTy -> Vl
crate::lower::types::Vl op_value_f(const crate::lower::Lx& lx_p0, const Text& op_p1, const crate::lower::types::Vl& a_p2, const crate::lower::types::Vl& b_p3, const crate::syntax::Range& span_p4, const crate::lower::model::OutTy& t_p5) {
    auto at_p6 = crate::lower::types::value_ty_f(a_p2);
    auto generic_p7 = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        if (prism_rtl::is<crate::lower::model::OutTy::OutGen>(at_p6)) {
            _v.set(true);
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
    return crate::check::types::has_text_f(Array(std::vector{Text::lit("=="), Text::lit("!="), Text::lit("<"), Text::lit("<="), Text::lit(">"), Text::lit(">=")}), op_p1)
        ? crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{op_of_f(op_p1, crate::lower::types::ref_f(a_p2), crate::lower::types::ref_f(b_p3)), crate::lower::model::OutTy(crate::lower::model::OutTy::OutBool{})})
        : op_p1 == Text::lit("mod")
        ? crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::types::ref_f(a_p2)), Text::lit("modulo"), Array(std::vector{crate::lower::types::ref_f(b_p3)})}), t_p5})
        : std::move(generic_p7)
        ? crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{prism_rtl::cat("Num::", num_method_f(op_p1)), Array(std::vector{crate::lower::types::ref_f(a_p2), crate::lower::types::ref_f(b_p3)})}), t_p5})
        : op_p1 == Text::lit("/")
        ? at_p6 == crate::lower::model::OutTy(crate::lower::model::OutTy::OutFloat{})
        ? crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBin{crate::lower::model::BinOp(crate::lower::model::BinOp::OpDiv{}), prism_rtl::rc(crate::lower::types::copy_f(a_p2)), prism_rtl::rc(crate::lower::types::copy_f(b_p3))}), t_p5})
        : crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::types::ref_f(a_p2)), Text::lit("div"), Array(std::vector{crate::lower::types::ref_f(b_p3)})}), t_p5})
        : op_p1 == Text::lit("-?")
        ? at_p6 == crate::lower::model::OutTy(crate::lower::model::OutTy::OutNat{})
        ? crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::types::ref_f(a_p2)), Text::lit("checked_sub"), Array(std::vector{crate::lower::types::ref_f(b_p3)})}), t_p5})
        : crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XBin{crate::lower::model::BinOp(crate::lower::model::BinOp::OpSub{}), prism_rtl::rc(crate::lower::types::ref_f(a_p2)), prism_rtl::rc(crate::lower::types::ref_f(b_p3))})})}), t_p5})
        : op_p1 == Text::lit("+?")
        ? crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XBin{crate::lower::model::BinOp(crate::lower::model::BinOp::OpAdd{}), prism_rtl::rc(crate::lower::types::ref_f(a_p2)), prism_rtl::rc(crate::lower::types::ref_f(b_p3))})})}), t_p5})
        : op_p1 == Text::lit("*?")
        ? crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XBin{crate::lower::model::BinOp(crate::lower::model::BinOp::OpMul{}), prism_rtl::rc(crate::lower::types::ref_f(a_p2)), prism_rtl::rc(crate::lower::types::ref_f(b_p3))})})}), t_p5})
        : crate::lower::types::is_copy_f(at_p6)
        ? crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{op_of_f(op_p1, crate::lower::types::copy_f(a_p2), crate::lower::types::copy_f(b_p3)), t_p5})
        : crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{op_of_f(op_p1, crate::lower::types::ref_f(a_p2), crate::lower::types::ref_f(b_p3)), t_p5});
}


/// OpOf: fn Text, Ex, Ex -> Ex
crate::lower::model::Ex op_of_f(const Text& op_p0, const crate::lower::model::Ex& a_p1, const crate::lower::model::Ex& b_p2) {
    auto&& _m = crate::lower::model::bin_op_of_o(op_p0);
    if (prism_rtl::is_some(_m)) {
        auto&& o_p3 = prism_rtl::some_of(_m);
        return crate::lower::model::Ex(crate::lower::model::Ex::XBin{o_p3, prism_rtl::rc(a_p1), prism_rtl::rc(b_p2)});
    }
    if (prism_rtl::is_none(_m)) {
        return refusal_f(prism_rtl::cat("the operator `", op_p0, "`"));
    }
    prism_rtl::unreachable("no arm matched");
}


/// NumMethod: fn Text -> Text
Text num_method_f(const Text& text0) {
    {
        auto&& c0_0 = text0;
        if (c0_0 == Text::lit("+")) {
            return Text::lit("add");
        }
    }
    {
        auto&& c1_0 = text0;
        if (c1_0 == Text::lit("-")) {
            return Text::lit("sub");
        }
    }
    {
        auto&& c2_0 = text0;
        if (c2_0 == Text::lit("*")) {
            return Text::lit("mul");
        }
    }
    {
        auto&& c3_0 = text0;
        if (c3_0 == Text::lit("/")) {
            return Text::lit("div_opt");
        }
    }
    {
        auto&& c4_0 = text0;
        if (c4_0 == Text::lit("+?")) {
            return Text::lit("add_opt");
        }
    }
    {
        auto&& c5_0 = text0;
        if (c5_0 == Text::lit("-?")) {
            return Text::lit("sub_opt");
        }
    }
    {
        auto&& c6_0 = text0;
        if (c6_0 == Text::lit("*?")) {
            return Text::lit("mul_opt");
        }
    }
    {
        auto&& other_p0 = text0;
        return Text::lit("add");
    }
}


/// PreludeCall: unbounded fn Lx, Env, Text, [Arg], Range, OutTy -> Vl
crate::lower::types::Vl prelude_call_f(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const Text& qk_p2, const Array<crate::syntax::Arg>& args_p3, const crate::syntax::Range& span_p4, const crate::lower::model::OutTy& t_p5) {
    auto name_p6 = crate::prelude::or_(crate::prelude::get(lx_p0.rs_names_p, qk_p2), crate::lower::snake_f(crate::check::types::bare_name_f(qk_p2)));
    auto first_p7 = ({
        __label__ _done;
        prism_rtl::Slot<crate::lower::model::OutTy> _v;
        auto&& _m = crate::prelude::index(args_p3, Nat(0u));
        if (prism_rtl::is_some(_m)) {
            auto&& a_p9 = prism_rtl::some_of(_m);
            _v.set(crate::lower::types::out_ty_of_f(lx_p0, crate::lower::types::peel_f(crate::lower::type_at_f(lx_p0, prism_rtl::deref(prism_rtl::deref(a_p9).value_p).span_p))));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto variant_p8 = prelude_variant_f(name_p6, first_p7);
    auto&& _m = prelude_job_o(lx_p0, env_p1, variant_p8, args_p3);
    if (prism_rtl::is_some(_m)) {
        auto&& job_pa = prism_rtl::some_of(_m);
        return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{crate::lower::helper_f(Text::lit("run_to_end")), Array(std::vector{job_pa})}), t_p5});
    }
    if (prism_rtl::is_none(_m)) {
        return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{crate::lower::prelude_path_f(lx_p0, variant_p8), crate::prelude::run_to_end(crate::prelude::each_job(args_p3, ({
            auto lx_p0x = lx_p0;
            auto env_p1x = env_p1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::Arg)>>(prism_rtl::rc([=, lx_p0x = std::move(lx_p0x), env_p1x = std::move(env_p1x)](crate::syntax::Arg p0) {
            return ({
                auto lx_p0xy = lx_p0x;
                auto env_p1xy = env_p1x;
                (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xy = std::move(lx_p0xy), env_p1xy = std::move(env_p1xy)]() {
                return ({
                    auto a_pb = p0;
                    (prism_rtl::more(prism_rtl::rc(Argument(lx_p0xy, env_p1xy, prism_rtl::deref(a_pb).value_p))));
                });
            })));
            });
        })));
        })))}), t_p5});
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::lower::types::Vl> PreludeCall::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& qk_p2 = this->qk_p2;
    const auto& args_p3 = this->args_p3;
    const auto& span_p4 = this->span_p4;
    const auto& t_p5 = this->t_p5;
    auto name_p6 = crate::prelude::or_(crate::prelude::get(prism_rtl::deref(lx_p0).rs_names_p, qk_p2), crate::lower::snake_f(crate::check::types::bare_name_f(qk_p2)));
    auto first_p7 = ({
        __label__ _done;
        prism_rtl::Slot<crate::lower::model::OutTy> _v;
        auto&& _m = crate::prelude::index(args_p3, Nat(0u));
        if (prism_rtl::is_some(_m)) {
            auto&& a_p9 = prism_rtl::some_of(_m);
            _v.set(crate::lower::types::out_ty_of_f(lx_p0, crate::lower::types::peel_f(crate::lower::type_at_f(lx_p0, prism_rtl::deref(prism_rtl::deref(a_p9).value_p).span_p))));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto variant_p8 = prelude_variant_f(name_p6, first_p7);
    auto args_p3x = args_p3;
    auto env_p1x = env_p1;
    auto lx_p0x = lx_p0;
    auto t_p5x = t_p5;
    return crate::prelude::call_then(start_prelude_job_o(lx_p0x, env_p1x, variant_p8, args_p3x), [=](std::optional<crate::lower::model::Ex> prelude_job_o_45126) {
        return ({
            prism_rtl::is_some(prelude_job_o_45126) ? ({
            auto&& job_pa = prism_rtl::some_of(prelude_job_o_45126);
            prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{crate::lower::helper_f(Text::lit("run_to_end")), Array(std::vector{job_pa})}), t_p5x}));
        })
            : prism_rtl::is_none(prelude_job_o_45126) ? crate::prelude::call_value(crate::prelude::each_job(args_p3x, ({
            auto lx_p0xx = lx_p0x;
            auto env_p1xx = env_p1x;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::Arg)>>(prism_rtl::rc([=, lx_p0xx = std::move(lx_p0xx), env_p1xx = std::move(env_p1xx)](crate::syntax::Arg p0) {
            return ({
                auto lx_p0xxy = lx_p0xx;
                auto env_p1xxy = env_p1xx;
                (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xxy = std::move(lx_p0xxy), env_p1xxy = std::move(env_p1xxy)]() {
                return ({
                    auto a_pb = p0;
                    (prism_rtl::more(prism_rtl::rc(Argument(lx_p0xxy, env_p1xxy, prism_rtl::deref(a_pb).value_p))));
                });
            })));
            });
        })));
        })), [=](Array<crate::lower::model::Ex> each_45283) { return prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{crate::lower::prelude_path_f(lx_p0x, variant_p8), each_45283}), t_p5x})); })
            : throw prism_rtl::Panic("no arm matched");
        });
    });
}


/// `Start PreludeCall, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_prelude_call_f(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, Text qk_p2, Array<crate::syntax::Arg> args_p3, crate::syntax::Range span_p4, crate::lower::model::OutTy t_p5) {
    return prism_rtl::make_rc<PreludeCall>(lx_p0, env_p1, qk_p2, args_p3, span_p4, t_p5);
}


/// ?PreludeJob: unbounded fn Lx, Env, Text, [Arg] -> ?Ex
std::optional<crate::lower::model::Ex> prelude_job_o(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const Text& variant_p2, const Array<crate::syntax::Arg>& args_p3) {
    return crate::check::types::has_text_f(Array(std::vector{Text::lit("fold"), Text::lit("fold_map"), Text::lit("each"), Text::lit("each_map"), Text::lit("filter"), Text::lit("filter_map")}), variant_p2)
        ? ({
        auto last_p4 = crate::prelude::or_(crate::prelude::index(args_p3, crate::syntax::lexer::chars::dec_f(crate::prelude::len(args_p3))), crate::syntax::Arg{.name_o = std::optional<crate::syntax::Ident>{}, .value_p = dummy_expr_p(), .span_p = crate::syntax::Range{.start_p = Nat(0u), .end_p = Nat(0u)}});
        ({
        __label__ _done;
        prism_rtl::Slot<std::optional<crate::lower::model::Ex>> _v;
        auto&& _m = crate::lower::types::out_ty_of_f(lx_p0, crate::lower::types::peel_f(crate::lower::type_at_f(lx_p0, prism_rtl::deref(prism_rtl::deref(last_p4).value_p).span_p)));
        if (prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(_m)) {
            _v.set(({
                auto front_p5 = crate::prelude::run_to_end(crate::prelude::each_job(crate::prelude::take(args_p3, crate::syntax::lexer::chars::dec_f(crate::prelude::len(args_p3))), ({
                    auto lx_p0x = lx_p0;
                    auto env_p1x = env_p1;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::Arg)>>(prism_rtl::rc([=, lx_p0x = std::move(lx_p0x), env_p1x = std::move(env_p1x)](crate::syntax::Arg p0) {
                    return ({
                        auto lx_p0xy = lx_p0x;
                        auto env_p1xy = env_p1x;
                        (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xy = std::move(lx_p0xy), env_p1xy = std::move(env_p1xy)]() {
                        return ({
                            auto a_p6 = p0;
                            (crate::prelude::call_then(start_value_of_f(lx_p0xy, env_p1xy, prism_rtl::deref(a_p6).value_p), [=](crate::lower::types::Vl value_of_f_46149) { return prism_rtl::finished(crate::lower::types::own_f(value_of_f_46149)); }));
                        });
                    })));
                    });
                })));
                })));
                (std::optional(crate::lower::model::Ex(crate::lower::model::Ex::XCall{crate::lower::helper_f(prism_rtl::cat(variant_p2, "_job")), crate::prelude::push(front_p5, as_job_value_f(lx_p0, env_p1, prism_rtl::deref(last_p4).value_p))})));
            }));
            goto _done;
        }
        {
            _v.set(std::optional<crate::lower::model::Ex>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    })
        : std::optional<crate::lower::model::Ex>{};
}


prism_rtl::Turn<std::optional<crate::lower::model::Ex>> PreludeJob::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& variant_p2 = this->variant_p2;
    const auto& args_p3 = this->args_p3;
    return crate::check::types::has_text_f(Array(std::vector{Text::lit("fold"), Text::lit("fold_map"), Text::lit("each"), Text::lit("each_map"), Text::lit("filter"), Text::lit("filter_map")}), variant_p2)
        ? ({
        auto last_p4 = crate::prelude::or_(crate::prelude::index(args_p3, crate::syntax::lexer::chars::dec_f(crate::prelude::len(args_p3))), crate::syntax::Arg{.name_o = std::optional<crate::syntax::Ident>{}, .value_p = dummy_expr_p(), .span_p = crate::syntax::Range{.start_p = Nat(0u), .end_p = Nat(0u)}});
        auto args_p3x = args_p3;
        auto env_p1x = env_p1;
        auto lx_p0x = lx_p0;
        auto variant_p2x = variant_p2;
        (crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0x, crate::lower::types::peel_f(crate::lower::type_at_f(lx_p0x, prism_rtl::deref(prism_rtl::deref(last_p4).value_p).span_p))), [=, args_p3x = std::move(args_p3x), env_p1x = std::move(env_p1x), variant_p2x = std::move(variant_p2x)](crate::lower::model::OutTy out_ty_of_f_45989) {
        return ({
            prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(out_ty_of_f_45989) ? crate::prelude::call_value(crate::prelude::each_job(crate::prelude::take(args_p3x, crate::syntax::lexer::chars::dec_f(crate::prelude::len(args_p3x))), ({
            auto lx_p0xx = lx_p0x;
            auto env_p1xx = env_p1x;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(crate::syntax::Arg)>>(prism_rtl::rc([=, lx_p0xx = std::move(lx_p0xx), env_p1xx = std::move(env_p1xx)](crate::syntax::Arg p0) {
            return ({
                auto lx_p0xxy = lx_p0xx;
                auto env_p1xxy = env_p1xx;
                (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xxy = std::move(lx_p0xxy), env_p1xxy = std::move(env_p1xxy)]() {
                return ({
                    auto a_p6 = p0;
                    (crate::prelude::call_then(start_value_of_f(lx_p0xxy, env_p1xxy, prism_rtl::deref(a_p6).value_p), [=](crate::lower::types::Vl value_of_f_46149) { return prism_rtl::finished(crate::lower::types::own_f(value_of_f_46149)); }));
                });
            })));
            });
        })));
        })), [=](Array<crate::lower::model::Ex> each_46103) {
            return ({
                auto front_p5 = each_46103;
                (prism_rtl::finished(std::optional(crate::lower::model::Ex(crate::lower::model::Ex::XCall{crate::lower::helper_f(prism_rtl::cat(variant_p2x, "_job")), crate::prelude::push(front_p5, as_job_value_f(lx_p0x, env_p1x, prism_rtl::deref(last_p4).value_p))}))));
            });
        })
            : prism_rtl::finished(std::optional<crate::lower::model::Ex>{});
        });
    }));
    })
        : prism_rtl::finished(std::optional<crate::lower::model::Ex>{});
}


/// `Start PreludeJob, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<crate::lower::model::Ex>> start_prelude_job_o(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, Text variant_p2, Array<crate::syntax::Arg> args_p3) {
    return prism_rtl::make_rc<PreludeJob>(lx_p0, env_p1, variant_p2, args_p3);
}


/// ?PreludeJobCall: unbounded fn Lx, Env, Expr -> ?Ex
std::optional<crate::lower::model::Ex> prelude_job_call_o(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& e_p2) {
    auto&& _m = prism_rtl::deref(e_p2.kind_p);
    if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
        auto&& c_p3 = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
        auto&& args_p4 = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
        auto&& _m = prism_rtl::deref(prism_rtl::deref(c_p3).kind_p);
        if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
            auto&& n_p5 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
            return (crate::prelude::len(prism_rtl::deref(n_p5).path_p) == Nat(1u)) && crate::check::env::has_key_f(env_p1.names_p, crate::check::env::sname_key_f(n_p5))
                ? std::optional<crate::lower::model::Ex>{}
                : ({
                auto&& _qk_o6 = crate::check::env::names::resolve_value_f(lx_p0.g_p, lx_p0.home_p, n_p5);
                auto&& qk_o6 = std::get<0>(_qk_o6);
                ({
                __label__ _done;
                prism_rtl::Slot<std::optional<crate::lower::model::Ex>> _v;
                if (prism_rtl::is_some(qk_o6)) {
                    auto&& qk_p7 = prism_rtl::some_of(qk_o6);
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<std::optional<crate::lower::model::Ex>> _v;
                        auto&& _m = crate::prelude::get(prism_rtl::deref(lx_p0.g_p).vals_p, qk_p7);
                        if (prism_rtl::is_some(_m)) {
                            auto&& v_p8 = prism_rtl::some_of(_m);
                            _v.set(prism_rtl::deref(v_p8).home_p == Text::lit("Prelude")
                                ? ({
                                auto name_p9 = crate::prelude::or_(crate::prelude::get(lx_p0.rs_names_p, qk_p7), crate::lower::snake_f(crate::check::types::bare_name_f(qk_p7)));
                                auto first_pa = ({
                                    __label__ _done;
                                    prism_rtl::Slot<crate::lower::model::OutTy> _v;
                                    auto&& _m = crate::prelude::index(args_p4, Nat(0u));
                                    if (prism_rtl::is_some(_m)) {
                                        auto&& a_pb = prism_rtl::some_of(_m);
                                        _v.set(crate::lower::types::out_ty_of_f(lx_p0, crate::lower::types::peel_f(crate::lower::type_at_f(lx_p0, prism_rtl::deref(prism_rtl::deref(a_pb).value_p).span_p))));
                                        goto _done;
                                    }
                                    if (prism_rtl::is_none(_m)) {
                                        _v.set(crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}));
                                        goto _done;
                                    }
                                    prism_rtl::unreachable("no arm matched");
                                _done:
                                    _v.take();
                                });
                                prelude_job_o(lx_p0, env_p1, prelude_variant_f(name_p9, first_pa), args_p4);
                            })
                                : std::optional<crate::lower::model::Ex>{});
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(std::optional<crate::lower::model::Ex>{});
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(qk_o6)) {
                    _v.set(std::optional<crate::lower::model::Ex>{});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            });
        }
        {
            return std::optional<crate::lower::model::Ex>{};
        }
    }
    {
        return std::optional<crate::lower::model::Ex>{};
    }
}


prism_rtl::Turn<std::optional<crate::lower::model::Ex>> PreludeJobCall::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& e_p2 = this->e_p2;
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p2).kind_p);
        prism_rtl::is<crate::syntax::ExprKind::ECall>(_m) ? ({
        auto&& c_p3 = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
        auto&& args_p4 = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
        ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(c_p3).kind_p);
        prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? ({
        auto&& n_p5 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        (crate::prelude::len(prism_rtl::deref(n_p5).path_p) == Nat(1u)) && crate::check::env::has_key_f(prism_rtl::deref(env_p1).names_p, crate::check::env::sname_key_f(n_p5))
        ? prism_rtl::finished(std::optional<crate::lower::model::Ex>{})
        : ({
        auto&& _qk_o6 = crate::check::env::names::resolve_value_f(prism_rtl::deref(lx_p0).g_p, prism_rtl::deref(lx_p0).home_p, n_p5);
        auto&& qk_o6 = std::get<0>(_qk_o6);
        ({
        prism_rtl::is_some(qk_o6) ? ({
        auto&& qk_p7 = prism_rtl::some_of(qk_o6);
        ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(prism_rtl::deref(lx_p0).g_p).vals_p, qk_p7);
        prism_rtl::is_some(_m) ? ({
        auto&& v_p8 = prism_rtl::some_of(_m);
        prism_rtl::deref(v_p8).home_p == Text::lit("Prelude")
        ? ({
        auto name_p9 = crate::prelude::or_(crate::prelude::get(prism_rtl::deref(lx_p0).rs_names_p, qk_p7), crate::lower::snake_f(crate::check::types::bare_name_f(qk_p7)));
        auto first_pa = ({
            __label__ _done;
            prism_rtl::Slot<crate::lower::model::OutTy> _v;
            auto&& _m = crate::prelude::index(args_p4, Nat(0u));
            if (prism_rtl::is_some(_m)) {
                auto&& a_pb = prism_rtl::some_of(_m);
                _v.set(crate::lower::types::out_ty_of_f(lx_p0, crate::lower::types::peel_f(crate::lower::type_at_f(lx_p0, prism_rtl::deref(prism_rtl::deref(a_pb).value_p).span_p))));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        (prism_rtl::more(prism_rtl::rc(PreludeJob(lx_p0, env_p1, prelude_variant_f(name_p9, first_pa), args_p4))));
    })
        : prism_rtl::finished(std::optional<crate::lower::model::Ex>{});
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(std::optional<crate::lower::model::Ex>{})
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : prism_rtl::is_none(qk_o6) ? prism_rtl::finished(std::optional<crate::lower::model::Ex>{})
        : throw prism_rtl::Panic("no arm matched");
    });
    });
    })
        : prism_rtl::finished(std::optional<crate::lower::model::Ex>{});
    });
    })
        : prism_rtl::finished(std::optional<crate::lower::model::Ex>{});
    });
}


/// `Start PreludeJobCall, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<crate::lower::model::Ex>> start_prelude_job_call_o(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr e_p2) {
    return prism_rtl::make_rc<PreludeJobCall>(lx_p0, env_p1, e_p2);
}


/// AsJobValue: unbounded fn Lx, Env, Expr -> Ex
crate::lower::model::Ex as_job_value_f(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& e_p2) {
    auto&& _m = prism_rtl::deref(e_p2.kind_p);
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x_p3 = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return as_job_value_f(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(x_p3)));
    }
    {
        auto target_p4 = ({
            __label__ _done;
            prism_rtl::Slot<crate::lower::model::OutTy> _v;
            auto&& _m = crate::lower::types::peel_f(crate::lower::type_at_f(lx_p0, e_p2.span_p));
            if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
                auto&& ps_p6 = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a1;
                auto&& r_p7 = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a2;
                _v.set(crate::lower::model::OutTy(crate::lower::model::OutTy::OutJobFn{prism_rtl::rc(crate::lower::types::rust_ty_of_params_f(lx_p0, ps_p6)), prism_rtl::rc(crate::lower::types::out_ty_of_f(lx_p0, prism_rtl::deref(r_p7)))}));
                goto _done;
            }
            {
                auto&& other_p8 = _m;
                _v.set(crate::lower::types::out_ty_of_f(lx_p0, other_p8));
                goto _done;
            }
        _done:
            _v.take();
        });
        auto a_p5 = ({
            __label__ _done;
            prism_rtl::Slot<crate::lower::model::OutTy> _v;
            if (prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(target_p4)) {
                auto&& x_p9 = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(target_p4).a0;
                _v.set(prism_rtl::deref(prism_rtl::deref(x_p9)));
                goto _done;
            }
            {
                _v.set(crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}));
                goto _done;
            }
        _done:
            _v.take();
        });
        auto&& _m = prism_rtl::deref(e_p2.kind_p);
        if (prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m)) {
            auto&& ps_oa = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0;
            auto&& body_pb = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a1;
            return crate::lower::types::own_f(job_lambda_f(lx_p0, env_p1, crate::prelude::or_(ps_oa, Array<crate::syntax::Pattern_>{}), prism_rtl::deref(prism_rtl::deref(body_pb)), target_p4, a_p5, enters_lambda_f(lx_p0, e_p2)));
        }
        {
            auto v_pc = value_of_f(lx_p0, env_p1, e_p2);
            auto&& _m = crate::lower::types::value_ty_f(v_pc);
            if (prism_rtl::is<crate::lower::model::OutTy::OutFn>(_m)) {
                auto&& pts_pd = prism_rtl::as<crate::lower::model::OutTy::OutFn>(_m).a0;
                return wrap_as_job_f(crate::lower::types::own_f(v_pc), pts_pd, target_p4, a_p5);
            }
            {
                return crate::lower::types::own_f(v_pc);
            }
        }
    }
}


prism_rtl::Turn<crate::lower::model::Ex> AsJobValue::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& e_p2 = this->e_p2;
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p2).kind_p);
        prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
        auto&& x_p3 = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(AsJobValue(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(x_p3)))));
    })
        : ({
        auto target_p4 = ({
            __label__ _done;
            prism_rtl::Slot<crate::lower::model::OutTy> _v;
            auto&& _m = crate::lower::types::peel_f(crate::lower::type_at_f(lx_p0, prism_rtl::deref(e_p2).span_p));
            if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
                auto&& ps_p6 = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a1;
                auto&& r_p7 = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a2;
                _v.set(crate::lower::model::OutTy(crate::lower::model::OutTy::OutJobFn{prism_rtl::rc(crate::lower::types::rust_ty_of_params_f(lx_p0, ps_p6)), prism_rtl::rc(crate::lower::types::out_ty_of_f(lx_p0, prism_rtl::deref(r_p7)))}));
                goto _done;
            }
            {
                auto&& other_p8 = _m;
                _v.set(crate::lower::types::out_ty_of_f(lx_p0, other_p8));
                goto _done;
            }
        _done:
            _v.take();
        });
        auto a_p5 = ({
            __label__ _done;
            prism_rtl::Slot<crate::lower::model::OutTy> _v;
            if (prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(target_p4)) {
                auto&& x_p9 = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(target_p4).a0;
                _v.set(prism_rtl::deref(prism_rtl::deref(x_p9)));
                goto _done;
            }
            {
                _v.set(crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}));
                goto _done;
            }
        _done:
            _v.take();
        });
        ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p2).kind_p);
        prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m) ? ({
        auto&& ps_oa = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0;
        auto&& body_pb = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a1;
        ({
        auto ps_oax = ps_oa;
        auto body_pbx = prism_rtl::deref(prism_rtl::deref(body_pb));
        auto e_p2x = e_p2;
        auto env_p1x = env_p1;
        auto lx_p0x = lx_p0;
        (crate::prelude::call_then(start_job_lambda_f(lx_p0x, env_p1x, crate::prelude::or_(ps_oax, Array<crate::syntax::Pattern_>{}), body_pbx, target_p4, a_p5, enters_lambda_f(lx_p0x, e_p2x)), [=](crate::lower::types::Vl job_lambda_f_48047) { return prism_rtl::finished(crate::lower::types::own_f(job_lambda_f_48047)); }));
    });
    })
        : ({
        auto e_p2x = e_p2;
        auto env_p1x = env_p1;
        auto lx_p0x = lx_p0;
        (crate::prelude::call_then(start_value_of_f(lx_p0x, env_p1x, e_p2x), [=](crate::lower::types::Vl value_of_f_48168) {
        return ({
            auto v_pc = value_of_f_48168;
            ({
            auto&& _m = crate::lower::types::value_ty_f(v_pc);
            prism_rtl::is<crate::lower::model::OutTy::OutFn>(_m) ? ({
            auto&& pts_pd = prism_rtl::as<crate::lower::model::OutTy::OutFn>(_m).a0;
            prism_rtl::finished(wrap_as_job_f(crate::lower::types::own_f(v_pc), pts_pd, target_p4, a_p5));
        })
            : prism_rtl::finished(crate::lower::types::own_f(v_pc));
        });
        });
    }));
    });
    });
    });
    });
}


/// `Start AsJobValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Ex> start_as_job_value_f(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr e_p2) {
    return prism_rtl::make_rc<AsJobValue>(lx_p0, env_p1, e_p2);
}


/// WrapAsJob: fn Ex, [OutTy], OutTy, OutTy -> Ex
crate::lower::model::Ex wrap_as_job_f(const crate::lower::model::Ex& f_p0, const Array<crate::lower::model::OutTy>& pts_p1, const crate::lower::model::OutTy& target_p2, const crate::lower::model::OutTy& a_p3) {
    auto names_p4 = crate::prelude::each(crate::check::errors::range0_f(crate::prelude::len(pts_p1)), [&](const Nat& i_p8) { return prism_rtl::cat("a", i_p8); });
    auto pa_p5 = crate::prelude::len(pts_p1) == Nat(1u)
        ? crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("a0")})), a_p3})
        : crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{crate::prelude::each(names_p4, [&](const Text& nm_p9) { return crate::lower::model::Pa(crate::lower::model::Pa::PaBind{nm_p9}); })})), a_p3});
    auto call_p6 = crate::lower::model::Ex(crate::lower::model::Ex::XApply{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("fy")})), crate::prelude::each(names_p4, [&](const Text& nm_pa) { return crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{nm_pa}))}); })});
    auto body_p7 = crate::lower::model::Ex(crate::lower::model::Ex::XBlock{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("fy")}), crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("f")}))})})}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{crate::lower::helper_f(Text::lit("once_job")), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array<crate::lower::model::Pa>{}, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("prism_rtl::Turn::Finished"), Array(std::vector{call_p6})}))})})}))});
    return crate::lower::model::Ex(crate::lower::model::Ex::XBlock{Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("f")}), f_p0})}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCast{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{pa_p5}), prism_rtl::rc(body_p7)})})})), target_p2}))});
}


/// NamedArgsOwned: unbounded fn Lx, Env, Text, [Arg] -> [Ex]
Array<crate::lower::model::Ex> named_args_owned_f(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const Text& qk_p2, const Array<crate::syntax::Arg>& args_p3) {
    auto&& _ps_p4 = crate::lower::jobs::scheme_parts_f(lx_p0, qk_p2);
    auto&& ps_p4 = std::get<0>(_ps_p4);
    return crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(crate::prelude::len(args_p3)), ({
        auto args_p3x = args_p3;
        auto ps_p4x = ps_p4;
        auto lx_p0x = lx_p0;
        auto env_p1x = env_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(Nat)>>(prism_rtl::rc([=, args_p3x = std::move(args_p3x), ps_p4x = std::move(ps_p4x), lx_p0x = std::move(lx_p0x), env_p1x = std::move(env_p1x)](Nat p0) {
        return ({
            auto args_p3xy = args_p3x;
            auto ps_p4xy = ps_p4x;
            auto lx_p0xy = lx_p0x;
            auto env_p1xy = env_p1x;
            (crate::prelude::entered(crate::prelude::once_job([=, args_p3xy = std::move(args_p3xy), ps_p4xy = std::move(ps_p4xy), lx_p0xy = std::move(lx_p0xy), env_p1xy = std::move(env_p1xy)]() {
            return ({
                auto i_p5 = p0;
                ({
                auto a_p6 = crate::prelude::or_(crate::prelude::index(args_p3xy, i_p5), crate::syntax::Arg{.name_o = std::optional<crate::syntax::Ident>{}, .value_p = dummy_expr_p(), .span_p = crate::syntax::Range{.start_p = Nat(0u), .end_p = Nat(0u)}});
                ({
                auto&& _m = crate::lower::types::peel_f(crate::prelude::or_(crate::prelude::index(ps_p4xy, i_p5), crate::check::types::Ty(crate::check::types::Ty::TyErr{})));
                prism_rtl::is<crate::check::types::Ty::TyFn>(_m) && prism_rtl::is<crate::check::types::Col::CBound>(prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a0) ? crate::prelude::call_then(start_value_of_f(lx_p0xy, env_p1xy, prism_rtl::deref(a_p6).value_p), [=](crate::lower::types::Vl value_of_f_49482) { return prism_rtl::finished(crate::lower::types::own_f(value_of_f_49482)); })
                : prism_rtl::is<crate::check::types::Ty::TyFn>(_m) ? prism_rtl::more(prism_rtl::rc(AsJobValue(lx_p0xy, env_p1xy, prism_rtl::deref(a_p6).value_p)))
                : crate::prelude::call_then(start_value_of_f(lx_p0xy, env_p1xy, prism_rtl::deref(a_p6).value_p), [=](crate::lower::types::Vl value_of_f_49605) { return prism_rtl::finished(crate::lower::types::own_f(value_of_f_49605)); });
            });
            });
            });
        })));
        });
    })));
    })));
}


prism_rtl::Turn<Array<crate::lower::model::Ex>> NamedArgsOwned::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& qk_p2 = this->qk_p2;
    const auto& args_p3 = this->args_p3;
    auto&& _ps_p4 = crate::lower::jobs::scheme_parts_f(lx_p0, qk_p2);
    auto&& ps_p4 = std::get<0>(_ps_p4);
    return crate::prelude::each_job(crate::check::errors::range0_f(crate::prelude::len(args_p3)), ({
        auto args_p3x = args_p3;
        auto ps_p4x = ps_p4;
        auto lx_p0x = lx_p0;
        auto env_p1x = env_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(Nat)>>(prism_rtl::rc([=, args_p3x = std::move(args_p3x), ps_p4x = std::move(ps_p4x), lx_p0x = std::move(lx_p0x), env_p1x = std::move(env_p1x)](Nat p0) {
        return ({
            auto args_p3xy = args_p3x;
            auto ps_p4xy = ps_p4x;
            auto lx_p0xy = lx_p0x;
            auto env_p1xy = env_p1x;
            (crate::prelude::entered(crate::prelude::once_job([=, args_p3xy = std::move(args_p3xy), ps_p4xy = std::move(ps_p4xy), lx_p0xy = std::move(lx_p0xy), env_p1xy = std::move(env_p1xy)]() {
            return ({
                auto i_p5 = p0;
                ({
                auto a_p6 = crate::prelude::or_(crate::prelude::index(args_p3xy, i_p5), crate::syntax::Arg{.name_o = std::optional<crate::syntax::Ident>{}, .value_p = dummy_expr_p(), .span_p = crate::syntax::Range{.start_p = Nat(0u), .end_p = Nat(0u)}});
                ({
                auto&& _m = crate::lower::types::peel_f(crate::prelude::or_(crate::prelude::index(ps_p4xy, i_p5), crate::check::types::Ty(crate::check::types::Ty::TyErr{})));
                prism_rtl::is<crate::check::types::Ty::TyFn>(_m) && prism_rtl::is<crate::check::types::Col::CBound>(prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a0) ? crate::prelude::call_then(start_value_of_f(lx_p0xy, env_p1xy, prism_rtl::deref(a_p6).value_p), [=](crate::lower::types::Vl value_of_f_49482) { return prism_rtl::finished(crate::lower::types::own_f(value_of_f_49482)); })
                : prism_rtl::is<crate::check::types::Ty::TyFn>(_m) ? prism_rtl::more(prism_rtl::rc(AsJobValue(lx_p0xy, env_p1xy, prism_rtl::deref(a_p6).value_p)))
                : crate::prelude::call_then(start_value_of_f(lx_p0xy, env_p1xy, prism_rtl::deref(a_p6).value_p), [=](crate::lower::types::Vl value_of_f_49605) { return prism_rtl::finished(crate::lower::types::own_f(value_of_f_49605)); });
            });
            });
            });
        })));
        });
    })));
    }))->cycle();
}


/// `Start NamedArgsOwned, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::lower::model::Ex>> start_named_args_owned_f(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, Text qk_p2, Array<crate::syntax::Arg> args_p3) {
    return prism_rtl::make_rc<NamedArgsOwned>(lx_p0, env_p1, qk_p2, args_p3);
}


/// StartArgs: unbounded fn Lx, Env, Vl, [Arg] -> [Ex]
Array<crate::lower::model::Ex> start_args_f(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::lower::types::Vl& f_p2, const Array<crate::syntax::Arg>& args_p3) {
    auto pts_p4 = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::lower::model::OutTy>> _v;
        auto&& _m = crate::lower::types::value_ty_f(f_p2);
        if (prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(_m)) {
            auto&& m49817_0_0 = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(_m).a0;
            if (prism_rtl::is<crate::lower::model::OutTy::OutTuple>(prism_rtl::deref(prism_rtl::deref(m49817_0_0)))) {
                auto&& ts_p5 = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(prism_rtl::deref(prism_rtl::deref(m49817_0_0))).a0;
                _v.set(crate::prelude::len(args_p3) == Nat(1u)
                    ? Array(std::vector{crate::lower::model::OutTy(crate::lower::model::OutTy::OutTuple{ts_p5})})
                    : ts_p5);
                goto _done;
            }
        }
        if (prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(_m)) {
            auto&& a_p6 = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(_m).a0;
            _v.set(Array(std::vector{prism_rtl::deref(prism_rtl::deref(a_p6))}));
            goto _done;
        }
        {
            _v.set(Array<crate::lower::model::OutTy>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    return crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(crate::prelude::len(args_p3)), ({
        auto args_p3x = args_p3;
        auto pts_p4x = pts_p4;
        auto lx_p0x = lx_p0;
        auto env_p1x = env_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(Nat)>>(prism_rtl::rc([=, args_p3x = std::move(args_p3x), pts_p4x = std::move(pts_p4x), lx_p0x = std::move(lx_p0x), env_p1x = std::move(env_p1x)](Nat p0) {
        return ({
            auto args_p3xy = args_p3x;
            auto pts_p4xy = pts_p4x;
            auto lx_p0xy = lx_p0x;
            auto env_p1xy = env_p1x;
            (crate::prelude::entered(crate::prelude::once_job([=, args_p3xy = std::move(args_p3xy), pts_p4xy = std::move(pts_p4xy), lx_p0xy = std::move(lx_p0xy), env_p1xy = std::move(env_p1xy)]() {
            return ({
                auto i_p7 = p0;
                ({
                auto a_p8 = crate::prelude::or_(crate::prelude::index(args_p3xy, i_p7), crate::syntax::Arg{.name_o = std::optional<crate::syntax::Ident>{}, .value_p = dummy_expr_p(), .span_p = crate::syntax::Range{.start_p = Nat(0u), .end_p = Nat(0u)}});
                ({
                auto&& _m = crate::prelude::or_(crate::prelude::index(pts_p4xy, i_p7), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}));
                prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(_m) ? prism_rtl::more(prism_rtl::rc(AsJobValue(lx_p0xy, env_p1xy, prism_rtl::deref(a_p8).value_p)))
                : crate::prelude::call_then(start_value_of_f(lx_p0xy, env_p1xy, prism_rtl::deref(a_p8).value_p), [=](crate::lower::types::Vl value_of_f_50228) { return prism_rtl::finished(crate::lower::types::own_f(value_of_f_50228)); });
            });
            });
            });
        })));
        });
    })));
    })));
}


prism_rtl::Turn<Array<crate::lower::model::Ex>> StartArgs::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& f_p2 = this->f_p2;
    const auto& args_p3 = this->args_p3;
    auto pts_p4 = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::lower::model::OutTy>> _v;
        auto&& _m = crate::lower::types::value_ty_f(f_p2);
        if (prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(_m)) {
            auto&& m49817_0_0 = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(_m).a0;
            if (prism_rtl::is<crate::lower::model::OutTy::OutTuple>(prism_rtl::deref(prism_rtl::deref(m49817_0_0)))) {
                auto&& ts_p5 = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(prism_rtl::deref(prism_rtl::deref(m49817_0_0))).a0;
                _v.set(crate::prelude::len(args_p3) == Nat(1u)
                    ? Array(std::vector{crate::lower::model::OutTy(crate::lower::model::OutTy::OutTuple{ts_p5})})
                    : ts_p5);
                goto _done;
            }
        }
        if (prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(_m)) {
            auto&& a_p6 = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(_m).a0;
            _v.set(Array(std::vector{prism_rtl::deref(prism_rtl::deref(a_p6))}));
            goto _done;
        }
        {
            _v.set(Array<crate::lower::model::OutTy>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    return crate::prelude::each_job(crate::check::errors::range0_f(crate::prelude::len(args_p3)), ({
        auto args_p3x = args_p3;
        auto pts_p4x = pts_p4;
        auto lx_p0x = lx_p0;
        auto env_p1x = env_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(Nat)>>(prism_rtl::rc([=, args_p3x = std::move(args_p3x), pts_p4x = std::move(pts_p4x), lx_p0x = std::move(lx_p0x), env_p1x = std::move(env_p1x)](Nat p0) {
        return ({
            auto args_p3xy = args_p3x;
            auto pts_p4xy = pts_p4x;
            auto lx_p0xy = lx_p0x;
            auto env_p1xy = env_p1x;
            (crate::prelude::entered(crate::prelude::once_job([=, args_p3xy = std::move(args_p3xy), pts_p4xy = std::move(pts_p4xy), lx_p0xy = std::move(lx_p0xy), env_p1xy = std::move(env_p1xy)]() {
            return ({
                auto i_p7 = p0;
                ({
                auto a_p8 = crate::prelude::or_(crate::prelude::index(args_p3xy, i_p7), crate::syntax::Arg{.name_o = std::optional<crate::syntax::Ident>{}, .value_p = dummy_expr_p(), .span_p = crate::syntax::Range{.start_p = Nat(0u), .end_p = Nat(0u)}});
                ({
                auto&& _m = crate::prelude::or_(crate::prelude::index(pts_p4xy, i_p7), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}));
                prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(_m) ? prism_rtl::more(prism_rtl::rc(AsJobValue(lx_p0xy, env_p1xy, prism_rtl::deref(a_p8).value_p)))
                : crate::prelude::call_then(start_value_of_f(lx_p0xy, env_p1xy, prism_rtl::deref(a_p8).value_p), [=](crate::lower::types::Vl value_of_f_50228) { return prism_rtl::finished(crate::lower::types::own_f(value_of_f_50228)); });
            });
            });
            });
        })));
        });
    })));
    }))->cycle();
}


/// `Start StartArgs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::lower::model::Ex>> start_start_args_f(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::lower::types::Vl f_p2, Array<crate::syntax::Arg> args_p3) {
    return prism_rtl::make_rc<StartArgs>(lx_p0, env_p1, f_p2, args_p3);
}


/// PreludeVariant: fn Text, OutTy -> Text
Text prelude_variant_f(const Text& name_p0, const crate::lower::model::OutTy& first_p1) {
    if (prism_rtl::is<crate::lower::model::OutTy::OutText>(first_p1)) {
        return name_p0 == Text::lit("len") ? Text::lit("len_text") : name_p0;
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutMap>(first_p1)) {
        return crate::check::types::has_text_f(Array(std::vector{Text::lit("len"), Text::lit("fold"), Text::lit("each"), Text::lit("filter")}), name_p0)
            ? prism_rtl::cat(name_p0, "_map")
            : name_p0;
    }
    {
        return name_p0;
    }
}


/// FieldValue: unbounded fn Lx, Env, Expr, Text -> Vl
crate::lower::types::Vl field_value_f(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& r_p2, const Text& name_p3) {
    auto rv_p4 = value_of_f(lx_p0, env_p1, r_p2);
    auto rty_p5 = crate::lower::types::peel_f(crate::lower::type_at_f(lx_p0, r_p2.span_p));
    auto [ft_p7, rc_p8, f_p9] = field_info_f(lx_p0, rty_p5, name_p3);
    auto mode_p6 = rc_p8
        ? crate::lower::types::Holding(crate::lower::types::Holding::RcOwned{})
        : crate::lower::types::Holding(crate::lower::types::Holding::Owned{});
    if (prism_rtl::is<crate::lower::types::Vl::VlPlace>(rv_p4)) {
        auto&& x_pa = prism_rtl::as<crate::lower::types::Vl::VlPlace>(rv_p4).a0;
        return crate::lower::types::Vl(crate::lower::types::Vl::VlPlace{crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(x_pa), f_p9}), mode_p6, ft_p7});
    }
    if (prism_rtl::is<crate::lower::types::Vl::VlOwned>(rv_p4)) {
        auto&& x_pb = prism_rtl::as<crate::lower::types::Vl::VlOwned>(rv_p4).a0;
        return crate::lower::types::Vl(crate::lower::types::Vl::VlPlace{crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(x_pb), f_p9}), mode_p6, ft_p7});
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::lower::types::Vl> FieldValue::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& r_p2 = this->r_p2;
    const auto& name_p3 = this->name_p3;
    auto env_p1x = env_p1;
    auto lx_p0x = lx_p0;
    auto name_p3x = name_p3;
    auto r_p2x = r_p2;
    return crate::prelude::call_then(start_value_of_f(lx_p0x, env_p1x, r_p2x), [=](crate::lower::types::Vl value_of_f_50723) {
        return ({
            auto rv_p4 = value_of_f_50723;
            auto rty_p5 = crate::lower::types::peel_f(crate::lower::type_at_f(lx_p0x, prism_rtl::deref(r_p2x).span_p));
            (crate::prelude::call_then(start_field_info_f(lx_p0x, rty_p5, name_p3x), [=, rv_p4 = std::move(rv_p4)](std::tuple<crate::lower::model::OutTy, bool, Text> field_info_f_50805) {
            return ({
                auto [ft_p7, rc_p8, f_p9] = field_info_f_50805;
                auto mode_p6 = rc_p8
                    ? crate::lower::types::Holding(crate::lower::types::Holding::RcOwned{})
                    : crate::lower::types::Holding(crate::lower::types::Holding::Owned{});
                ({
                prism_rtl::is<crate::lower::types::Vl::VlPlace>(rv_p4) ? ({
                auto&& x_pa = prism_rtl::as<crate::lower::types::Vl::VlPlace>(rv_p4).a0;
                prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlPlace{crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(x_pa), f_p9}), mode_p6, ft_p7}));
            })
                : prism_rtl::is<crate::lower::types::Vl::VlOwned>(rv_p4) ? ({
                auto&& x_pb = prism_rtl::as<crate::lower::types::Vl::VlOwned>(rv_p4).a0;
                prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlPlace{crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(x_pb), f_p9}), mode_p6, ft_p7}));
            })
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    });
}


/// `Start FieldValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_field_value_f(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr r_p2, Text name_p3) {
    return prism_rtl::make_rc<FieldValue>(lx_p0, env_p1, r_p2, name_p3);
}


/// FieldInfo: unbounded fn Lx, Ty, Text -> ((OutTy, Bool, Text))
std::tuple<crate::lower::model::OutTy, bool, Text> field_info_f(const crate::lower::Lx& lx_p0, const crate::check::types::Ty& rty_p1, const Text& name_p2) {
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(rty_p1)) {
        auto&& m51166_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(rty_p1).a0;
        if (m51166_0_0 == Text::lit("Prelude.Error")) {
            return std::tuple{crate::lower::model::OutTy(crate::lower::model::OutTy::OutRefused{prism_rtl::cat("a field ", name_p2, " of an Error")}), false, crate::lower::field_spell_f(Text::lit("Prelude"), name_p2, crate::check::types::t_text_p())};
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(rty_p1)) {
        auto&& n_p3 = prism_rtl::as<crate::check::types::Ty::TyCon>(rty_p1).a0;
        auto&& args_p4 = prism_rtl::as<crate::check::types::Ty::TyCon>(rty_p1).a1;
        auto&& _m = crate::prelude::get(prism_rtl::deref(lx_p0.g_p).ctors_p, n_p3);
        if (prism_rtl::is_some(_m)) {
            auto&& c_p5 = prism_rtl::some_of(_m);
            auto fix_o6 = crate::prelude::fold(crate::check::errors::range0_f(crate::prelude::len(prism_rtl::deref(c_p5).fields_p)), std::optional<Nat>{}, [&](const std::optional<Nat>& found_o7, const Nat& i_p8) {
                return crate::prelude::or_(crate::prelude::index(prism_rtl::deref(c_p5).fields_p, i_p8), Text::lit("")) == name_p2
                    ? std::optional(i_p8)
                    : found_o7;
            });
            if (prism_rtl::is_some(fix_o6)) {
                auto&& i_p9 = prism_rtl::some_of(fix_o6);
                auto ft_pa = crate::prelude::or_(crate::prelude::index(prism_rtl::deref(c_p5).args_p, i_p9), crate::check::types::Ty(crate::check::types::Ty::TyErr{}));
                auto inst_pb = instantiated_f(ft_pa, prism_rtl::deref(c_p5).params_p, args_p4);
                return std::tuple{crate::lower::types::out_ty_of_f(lx_p0, inst_pb), crate::lower::types::rc_field_f(lx_p0, prism_rtl::deref(c_p5).name_p, i_p9), crate::lower::field_spell_f(crate::lower::owner_of_f(prism_rtl::deref(c_p5).owner_p), crate::prelude::or_(crate::prelude::index(prism_rtl::deref(c_p5).fields_p, i_p9), name_p2), ft_pa)};
            }
            if (prism_rtl::is_none(fix_o6)) {
                return std::tuple{crate::lower::model::OutTy(crate::lower::model::OutTy::OutRefused{prism_rtl::cat("a field ", name_p2)}), false, field_by_name_f(lx_p0, name_p2)};
            }
            prism_rtl::unreachable("no arm matched");
        }
        if (prism_rtl::is_none(_m)) {
            return std::tuple{crate::lower::model::OutTy(crate::lower::model::OutTy::OutRefused{prism_rtl::cat("a field ", name_p2)}), false, field_by_name_f(lx_p0, name_p2)};
        }
        prism_rtl::unreachable("no arm matched");
    }
    {
        return std::tuple{crate::lower::model::OutTy(crate::lower::model::OutTy::OutRefused{prism_rtl::cat("a field ", name_p2, " of a non-record")}), false, field_by_name_f(lx_p0, name_p2)};
    }
}


prism_rtl::Turn<std::tuple<crate::lower::model::OutTy, bool, Text>> FieldInfo::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& rty_p1 = this->rty_p1;
    const auto& name_p2 = this->name_p2;
    return ({
        prism_rtl::is<crate::check::types::Ty::TyCon>(rty_p1) && ({
        auto&& m51166_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(rty_p1).a0;
        (m51166_0_0 == Text::lit("Prelude.Error"));
    }) ? ({
        auto&& m51166_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(rty_p1).a0;
        ({
        auto name_p2x = name_p2;
        (crate::prelude::call_then(crate::lower::start_field_spell_f(Text::lit("Prelude"), name_p2x, crate::check::types::t_text_p()), [=](Text field_spell_f_51357) { return prism_rtl::finished(std::tuple{crate::lower::model::OutTy(crate::lower::model::OutTy::OutRefused{prism_rtl::cat("a field ", name_p2x, " of an Error")}), false, field_spell_f_51357}); }));
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(rty_p1) ? ({
        auto&& n_p3 = prism_rtl::as<crate::check::types::Ty::TyCon>(rty_p1).a0;
        auto&& args_p4 = prism_rtl::as<crate::check::types::Ty::TyCon>(rty_p1).a1;
        ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(prism_rtl::deref(lx_p0).g_p).ctors_p, n_p3);
        prism_rtl::is_some(_m) ? ({
        auto&& c_p5 = prism_rtl::some_of(_m);
        ({
        auto fix_o6 = crate::prelude::fold(crate::check::errors::range0_f(crate::prelude::len(prism_rtl::deref(c_p5).fields_p)), std::optional<Nat>{}, [&](const std::optional<Nat>& found_o7, const Nat& i_p8) {
            return crate::prelude::or_(crate::prelude::index(prism_rtl::deref(c_p5).fields_p, i_p8), Text::lit("")) == name_p2
                ? std::optional(i_p8)
                : found_o7;
        });
        ({
        prism_rtl::is_some(fix_o6) ? ({
        auto&& i_p9 = prism_rtl::some_of(fix_o6);
        ({
        auto ft_pa = crate::prelude::or_(crate::prelude::index(prism_rtl::deref(c_p5).args_p, i_p9), crate::check::types::Ty(crate::check::types::Ty::TyErr{}));
        auto args_p4x = args_p4;
        auto i_p9x = i_p9;
        auto lx_p0x = lx_p0;
        auto name_p2x = name_p2;
        (crate::prelude::call_then(start_instantiated_f(ft_pa, prism_rtl::deref(c_p5).params_p, args_p4x), [=, i_p9x = std::move(i_p9x), lx_p0x = std::move(lx_p0x), name_p2x = std::move(name_p2x)](crate::check::types::Ty instantiated_f_51693) {
        return ({
            auto inst_pb = instantiated_f_51693;
            (crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0x, inst_pb), [=](crate::lower::model::OutTy out_ty_of_f_51748) { return crate::prelude::call_then(crate::lower::start_field_spell_f(crate::lower::owner_of_f(prism_rtl::deref(c_p5).owner_p), crate::prelude::or_(crate::prelude::index(prism_rtl::deref(c_p5).fields_p, i_p9x), name_p2x), ft_pa), [=](Text field_spell_f_51793) { return prism_rtl::finished(std::tuple{out_ty_of_f_51748, crate::lower::types::rc_field_f(lx_p0x, prism_rtl::deref(c_p5).name_p, i_p9x), field_spell_f_51793}); }); }));
        });
    }));
    });
    })
        : prism_rtl::is_none(fix_o6) ? ({
        auto lx_p0x = lx_p0;
        auto name_p2x = name_p2;
        (crate::prelude::call_then(start_field_by_name_f(lx_p0x, name_p2x), [=](Text field_by_name_f_51915) { return prism_rtl::finished(std::tuple{crate::lower::model::OutTy(crate::lower::model::OutTy::OutRefused{prism_rtl::cat("a field ", name_p2x)}), false, field_by_name_f_51915}); }));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    });
    })
        : prism_rtl::is_none(_m) ? ({
        auto lx_p0x = lx_p0;
        auto name_p2x = name_p2;
        (crate::prelude::call_then(start_field_by_name_f(lx_p0x, name_p2x), [=](Text field_by_name_f_51993) { return prism_rtl::finished(std::tuple{crate::lower::model::OutTy(crate::lower::model::OutTy::OutRefused{prism_rtl::cat("a field ", name_p2x)}), false, field_by_name_f_51993}); }));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : ({
        auto lx_p0x = lx_p0;
        auto name_p2x = name_p2;
        (crate::prelude::call_then(start_field_by_name_f(lx_p0x, name_p2x), [=](Text field_by_name_f_52089) { return prism_rtl::finished(std::tuple{crate::lower::model::OutTy(crate::lower::model::OutTy::OutRefused{prism_rtl::cat("a field ", name_p2x, " of a non-record")}), false, field_by_name_f_52089}); }));
    });
    });
}


/// `Start FieldInfo, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::lower::model::OutTy, bool, Text>> start_field_info_f(crate::lower::Lx lx_p0, crate::check::types::Ty rty_p1, Text name_p2) {
    return prism_rtl::make_rc<FieldInfo>(lx_p0, rty_p1, name_p2);
}


/// FieldByName: unbounded fn Lx, Text -> Text
Text field_by_name_f(const crate::lower::Lx& lx_p0, const Text& name_p1) {
    auto spellings_p2 = crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::values(prism_rtl::deref(lx_p0.g_p).ctors_p), Array<Text>{}, ({
        auto name_p1x = name_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::env::CtorInfo>)>>(prism_rtl::rc([=, name_p1x = std::move(name_p1x)](std::tuple<Array<Text>, crate::check::env::CtorInfo> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto name_p1xy = name_p1x;
            (crate::prelude::entered(crate::prelude::once_job([=, name_p1xy = std::move(name_p1xy)]() {
            return ({
                auto acc_p3 = p0;
                auto c_p4 = p1;
                (crate::prelude::fold_job(crate::check::errors::range0_f(crate::prelude::len(prism_rtl::deref(c_p4).fields_p)), acc_p3, ({
                auto c_p4x = c_p4;
                auto name_p1xyx = name_p1xy;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Nat>)>>(prism_rtl::rc([=, c_p4x = std::move(c_p4x), name_p1xyx = std::move(name_p1xyx)](std::tuple<Array<Text>, Nat> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto c_p4xy = c_p4x;
                    auto name_p1xyxy = name_p1xyx;
                    (crate::prelude::entered(crate::prelude::once_job([=, c_p4xy = std::move(c_p4xy), name_p1xyxy = std::move(name_p1xyxy)]() {
                    return ({
                        auto a_p5 = p0;
                        auto i_p6 = p1;
                        (crate::prelude::or_(crate::prelude::index(prism_rtl::deref(c_p4xy).fields_p, i_p6), Text::lit("")) == name_p1xyxy
                        ? crate::prelude::call_then(crate::lower::start_field_spell_f(crate::lower::owner_of_f(prism_rtl::deref(c_p4xy).owner_p), name_p1xyxy, crate::prelude::or_(crate::prelude::index(prism_rtl::deref(c_p4xy).args_p, i_p6), crate::check::types::Ty(crate::check::types::Ty::TyErr{}))), [=](Text field_spell_f_52573) { return prism_rtl::finished(crate::check::types::add_text_f(a_p5, field_spell_f_52573)); })
                        : prism_rtl::finished(a_p5));
                    });
                })));
                });
            })));
            }))->cycle());
            });
        })));
        });
    })));
    })));
    {
        auto&& m52644_0 = spellings_p2;
        if (m52644_0.size() == 1u) {
            {
                auto&& _c1 = crate::prelude::index(m52644_0, Nat(0u));
                if (prism_rtl::is_some(_c1)) {
                    auto&& one_p7 = prism_rtl::some_of(_c1);
                    return one_p7;
                }
            }
        }
    }
    {
        return crate::lower::snake_f(name_p1);
    }
}


prism_rtl::Turn<Text> FieldByName::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& name_p1 = this->name_p1;
    auto lx_p0x = lx_p0;
    auto name_p1x = name_p1;
    return crate::prelude::call_value(crate::prelude::fold_job(crate::prelude::values(prism_rtl::deref(prism_rtl::deref(lx_p0x).g_p).ctors_p), Array<Text>{}, ({
        auto name_p1xx = name_p1x;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::env::CtorInfo>)>>(prism_rtl::rc([=, name_p1xx = std::move(name_p1xx)](std::tuple<Array<Text>, crate::check::env::CtorInfo> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto name_p1xxy = name_p1xx;
            (crate::prelude::entered(crate::prelude::once_job([=, name_p1xxy = std::move(name_p1xxy)]() {
            return ({
                auto acc_p3 = p0;
                auto c_p4 = p1;
                (crate::prelude::fold_job(crate::check::errors::range0_f(crate::prelude::len(prism_rtl::deref(c_p4).fields_p)), acc_p3, ({
                auto c_p4x = c_p4;
                auto name_p1xxyx = name_p1xxy;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Nat>)>>(prism_rtl::rc([=, c_p4x = std::move(c_p4x), name_p1xxyx = std::move(name_p1xxyx)](std::tuple<Array<Text>, Nat> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto c_p4xy = c_p4x;
                    auto name_p1xxyxy = name_p1xxyx;
                    (crate::prelude::entered(crate::prelude::once_job([=, c_p4xy = std::move(c_p4xy), name_p1xxyxy = std::move(name_p1xxyxy)]() {
                    return ({
                        auto a_p5 = p0;
                        auto i_p6 = p1;
                        (crate::prelude::or_(crate::prelude::index(prism_rtl::deref(c_p4xy).fields_p, i_p6), Text::lit("")) == name_p1xxyxy
                        ? crate::prelude::call_then(crate::lower::start_field_spell_f(crate::lower::owner_of_f(prism_rtl::deref(c_p4xy).owner_p), name_p1xxyxy, crate::prelude::or_(crate::prelude::index(prism_rtl::deref(c_p4xy).args_p, i_p6), crate::check::types::Ty(crate::check::types::Ty::TyErr{}))), [=](Text field_spell_f_52573) { return prism_rtl::finished(crate::check::types::add_text_f(a_p5, field_spell_f_52573)); })
                        : prism_rtl::finished(a_p5));
                    });
                })));
                });
            })));
            }))->cycle());
            });
        })));
        });
    })));
    })), [=](Array<Text> fold_52443) {
        return ({
            auto spellings_p2 = fold_52443;
            ({
            ({
            auto&& m52644_0 = spellings_p2;
            (m52644_0.size() == 1u) && ({
            auto&& _c1 = crate::prelude::index(m52644_0, Nat(0u));
            prism_rtl::is_some(_c1);
        });
        }) ? ({
            auto&& m52644_0 = spellings_p2;
            auto&& _c1 = crate::prelude::index(m52644_0, Nat(0u));
            auto&& one_p7 = prism_rtl::some_of(_c1);
            prism_rtl::finished(one_p7);
        })
            : prism_rtl::finished(crate::lower::snake_f(name_p1x));
        });
        });
    });
}


/// `Start FieldByName, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_field_by_name_f(crate::lower::Lx lx_p0, Text name_p1) {
    return prism_rtl::make_rc<FieldByName>(lx_p0, name_p1);
}


/// Instantiated: unbounded fn Ty, [Text], [Ty] -> Ty
crate::check::types::Ty instantiated_f(const crate::check::types::Ty& t_p0, const Array<Text>& params_p1, const Array<crate::check::types::Ty>& args_p2) {
    if (prism_rtl::is<crate::check::types::Ty::TyQ>(t_p0)) {
        auto&& q_p3 = prism_rtl::as<crate::check::types::Ty::TyQ>(t_p0).a0;
        auto hit_o4 = crate::prelude::fold(crate::check::errors::range0_f(crate::prelude::len(params_p1)), std::optional<crate::check::types::Ty>{}, [&](const std::optional<crate::check::types::Ty>& found_o5, const Nat& i_p6) {
            return crate::prelude::or_(crate::prelude::index(params_p1, i_p6), Text::lit("")) == q_p3
                ? crate::prelude::index(args_p2, i_p6)
                : found_o5;
        });
        return crate::prelude::or_(hit_o4, t_p0);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t_p0)) {
        auto&& n_p7 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p0).a0;
        auto&& xs_p8 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p0).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyCon{n_p7, crate::prelude::run_to_end(crate::prelude::each_job(xs_p8, ({
            auto params_p1x = params_p1;
            auto args_p2x = args_p2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, params_p1x = std::move(params_p1x), args_p2x = std::move(args_p2x)](crate::check::types::Ty p0) {
            return ({
                auto params_p1xy = params_p1x;
                auto args_p2xy = args_p2x;
                (crate::prelude::entered(crate::prelude::once_job([=, params_p1xy = std::move(params_p1xy), args_p2xy = std::move(args_p2xy)]() {
                return ({
                    auto x_p9 = p0;
                    (prism_rtl::more(prism_rtl::rc(Instantiated(x_p9, params_p1xy, args_p2xy))));
                });
            })));
            });
        })));
        })))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(t_p0)) {
        auto&& c_pa = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p0).a0;
        auto&& ps_pb = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p0).a1;
        auto&& res_pc = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p0).a2;
        return crate::check::types::Ty(crate::check::types::Ty::TyFn{c_pa, crate::prelude::run_to_end(crate::prelude::each_job(ps_pb, ({
            auto params_p1x = params_p1;
            auto args_p2x = args_p2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, params_p1x = std::move(params_p1x), args_p2x = std::move(args_p2x)](crate::check::types::Ty p0) {
            return ({
                auto params_p1xy = params_p1x;
                auto args_p2xy = args_p2x;
                (crate::prelude::entered(crate::prelude::once_job([=, params_p1xy = std::move(params_p1xy), args_p2xy = std::move(args_p2xy)]() {
                return ({
                    auto x_pd = p0;
                    (prism_rtl::more(prism_rtl::rc(Instantiated(x_pd, params_p1xy, args_p2xy))));
                });
            })));
            });
        })));
        }))), prism_rtl::rc(instantiated_f(prism_rtl::deref(prism_rtl::deref(res_pc)), params_p1, args_p2))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t_p0)) {
        auto&& ts_pe = prism_rtl::as<crate::check::types::Ty::TyTuple>(t_p0).a0;
        return crate::check::types::Ty(crate::check::types::Ty::TyTuple{crate::prelude::run_to_end(crate::prelude::each_job(ts_pe, ({
            auto params_p1x = params_p1;
            auto args_p2x = args_p2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, params_p1x = std::move(params_p1x), args_p2x = std::move(args_p2x)](crate::check::types::Ty p0) {
            return ({
                auto params_p1xy = params_p1x;
                auto args_p2xy = args_p2x;
                (crate::prelude::entered(crate::prelude::once_job([=, params_p1xy = std::move(params_p1xy), args_p2xy = std::move(args_p2xy)]() {
                return ({
                    auto x_pf = p0;
                    (prism_rtl::more(prism_rtl::rc(Instantiated(x_pf, params_p1xy, args_p2xy))));
                });
            })));
            });
        })));
        })))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(t_p0)) {
        auto&& e_pg = prism_rtl::as<crate::check::types::Ty::TyArray>(t_p0).a0;
        return crate::check::types::Ty(crate::check::types::Ty::TyArray{prism_rtl::rc(instantiated_f(prism_rtl::deref(prism_rtl::deref(e_pg)), params_p1, args_p2))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(t_p0)) {
        auto&& k_ph = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p0).a0;
        auto&& v_pi = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p0).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyMap{prism_rtl::rc(instantiated_f(prism_rtl::deref(prism_rtl::deref(k_ph)), params_p1, args_p2)), prism_rtl::rc(instantiated_f(prism_rtl::deref(prism_rtl::deref(v_pi)), params_p1, args_p2))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t_p0)) {
        auto&& s_pj = prism_rtl::as<crate::check::types::Ty::TySig>(t_p0).a0;
        auto&& i_pk = prism_rtl::as<crate::check::types::Ty::TySig>(t_p0).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TySig{s_pj, prism_rtl::rc(instantiated_f(prism_rtl::deref(prism_rtl::deref(i_pk)), params_p1, args_p2))});
    }
    {
        return t_p0;
    }
}


prism_rtl::Turn<crate::check::types::Ty> Instantiated::cycle() const {
    const auto& t_p0 = this->t_p0;
    const auto& params_p1 = this->params_p1;
    const auto& args_p2 = this->args_p2;
    return ({
        prism_rtl::is<crate::check::types::Ty::TyQ>(t_p0) ? ({
        auto&& q_p3 = prism_rtl::as<crate::check::types::Ty::TyQ>(t_p0).a0;
        ({
        auto hit_o4 = crate::prelude::fold(crate::check::errors::range0_f(crate::prelude::len(params_p1)), std::optional<crate::check::types::Ty>{}, [&](const std::optional<crate::check::types::Ty>& found_o5, const Nat& i_p6) {
            return crate::prelude::or_(crate::prelude::index(params_p1, i_p6), Text::lit("")) == q_p3
                ? crate::prelude::index(args_p2, i_p6)
                : found_o5;
        });
        (prism_rtl::finished(crate::prelude::or_(hit_o4, t_p0)));
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t_p0) ? ({
        auto&& n_p7 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p0).a0;
        auto&& xs_p8 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p0).a1;
        ({
        auto args_p2x = args_p2;
        auto n_p7x = n_p7;
        auto params_p1x = params_p1;
        auto xs_p8x = xs_p8;
        (crate::prelude::call_value(crate::prelude::each_job(xs_p8x, ({
        auto params_p1xx = params_p1x;
        auto args_p2xx = args_p2x;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, params_p1xx = std::move(params_p1xx), args_p2xx = std::move(args_p2xx)](crate::check::types::Ty p0) {
        return ({
            auto params_p1xxy = params_p1xx;
            auto args_p2xxy = args_p2xx;
            (crate::prelude::entered(crate::prelude::once_job([=, params_p1xxy = std::move(params_p1xxy), args_p2xxy = std::move(args_p2xxy)]() {
            return ({
                auto x_p9 = p0;
                (prism_rtl::more(prism_rtl::rc(Instantiated(x_p9, params_p1xxy, args_p2xxy))));
            });
        })));
        });
    })));
    })), [=, n_p7x = std::move(n_p7x)](Array<crate::check::types::Ty> each_53059) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyCon{n_p7x, each_53059})); }));
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyFn>(t_p0) ? ({
        auto&& c_pa = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p0).a0;
        auto&& ps_pb = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p0).a1;
        auto&& res_pc = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p0).a2;
        ({
        auto args_p2x = args_p2;
        auto c_pax = c_pa;
        auto params_p1x = params_p1;
        auto ps_pbx = ps_pb;
        auto res_pcx = prism_rtl::deref(prism_rtl::deref(res_pc));
        (crate::prelude::call_value(crate::prelude::each_job(ps_pbx, ({
        auto params_p1xx = params_p1x;
        auto args_p2xx = args_p2x;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, params_p1xx = std::move(params_p1xx), args_p2xx = std::move(args_p2xx)](crate::check::types::Ty p0) {
        return ({
            auto params_p1xxy = params_p1xx;
            auto args_p2xxy = args_p2xx;
            (crate::prelude::entered(crate::prelude::once_job([=, params_p1xxy = std::move(params_p1xxy), args_p2xxy = std::move(args_p2xxy)]() {
            return ({
                auto x_pd = p0;
                (prism_rtl::more(prism_rtl::rc(Instantiated(x_pd, params_p1xxy, args_p2xxy))));
            });
        })));
        });
    })));
    })), [=, c_pax = std::move(c_pax), res_pcx = std::move(res_pcx)](Array<crate::check::types::Ty> each_53133) { return crate::prelude::call_then(start_instantiated_f(res_pcx, params_p1x, args_p2x), [=](crate::check::types::Ty instantiated_f_53179) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyFn{c_pax, each_53133, prism_rtl::rc(instantiated_f_53179)})); }); }));
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyTuple>(t_p0) ? ({
        auto&& ts_pe = prism_rtl::as<crate::check::types::Ty::TyTuple>(t_p0).a0;
        ({
        auto args_p2x = args_p2;
        auto params_p1x = params_p1;
        auto ts_pex = ts_pe;
        (crate::prelude::call_value(crate::prelude::each_job(ts_pex, ({
        auto params_p1xx = params_p1x;
        auto args_p2xx = args_p2x;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, params_p1xx = std::move(params_p1xx), args_p2xx = std::move(args_p2xx)](crate::check::types::Ty p0) {
        return ({
            auto params_p1xxy = params_p1xx;
            auto args_p2xxy = args_p2xx;
            (crate::prelude::entered(crate::prelude::once_job([=, params_p1xxy = std::move(params_p1xxy), args_p2xxy = std::move(args_p2xxy)]() {
            return ({
                auto x_pf = p0;
                (prism_rtl::more(prism_rtl::rc(Instantiated(x_pf, params_p1xxy, args_p2xxy))));
            });
        })));
        });
    })));
    })), [=](Array<crate::check::types::Ty> each_53236) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyTuple{each_53236})); }));
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyArray>(t_p0) ? ({
        auto&& e_pg = prism_rtl::as<crate::check::types::Ty::TyArray>(t_p0).a0;
        ({
        auto args_p2x = args_p2;
        auto e_pgx = prism_rtl::deref(prism_rtl::deref(e_pg));
        auto params_p1x = params_p1;
        (crate::prelude::call_then(start_instantiated_f(e_pgx, params_p1x, args_p2x), [=](crate::check::types::Ty instantiated_f_53304) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyArray{prism_rtl::rc(instantiated_f_53304)})); }));
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyMap>(t_p0) ? ({
        auto&& k_ph = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p0).a0;
        auto&& v_pi = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p0).a1;
        ({
        auto args_p2x = args_p2;
        auto k_phx = prism_rtl::deref(prism_rtl::deref(k_ph));
        auto params_p1x = params_p1;
        auto v_pix = prism_rtl::deref(prism_rtl::deref(v_pi));
        (crate::prelude::call_then(start_instantiated_f(k_phx, params_p1x, args_p2x), [=, v_pix = std::move(v_pix)](crate::check::types::Ty instantiated_f_53357) { return crate::prelude::call_then(start_instantiated_f(v_pix, params_p1x, args_p2x), [=](crate::check::types::Ty instantiated_f_53389) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyMap{prism_rtl::rc(instantiated_f_53357), prism_rtl::rc(instantiated_f_53389)})); }); }));
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TySig>(t_p0) ? ({
        auto&& s_pj = prism_rtl::as<crate::check::types::Ty::TySig>(t_p0).a0;
        auto&& i_pk = prism_rtl::as<crate::check::types::Ty::TySig>(t_p0).a1;
        ({
        auto args_p2x = args_p2;
        auto i_pkx = prism_rtl::deref(prism_rtl::deref(i_pk));
        auto params_p1x = params_p1;
        auto s_pjx = s_pj;
        (crate::prelude::call_then(start_instantiated_f(i_pkx, params_p1x, args_p2x), [=, s_pjx = std::move(s_pjx)](crate::check::types::Ty instantiated_f_53445) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TySig{s_pjx, prism_rtl::rc(instantiated_f_53445)})); }));
    });
    })
        : prism_rtl::finished(t_p0);
    });
}


/// `Start Instantiated, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::Ty> start_instantiated_f(crate::check::types::Ty t_p0, Array<Text> params_p1, Array<crate::check::types::Ty> args_p2) {
    return prism_rtl::make_rc<Instantiated>(t_p0, params_p1, args_p2);
}


/// IndexValue: unbounded fn Lx, Env, Expr, Expr, OutTy -> Vl
crate::lower::types::Vl index_value_f(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& r_p2, const crate::syntax::Expr& i_p3, const crate::lower::model::OutTy& t_p4) {
    auto rt_p5 = crate::lower::types::out_ty_of_f(lx_p0, crate::lower::types::peel_f(crate::lower::type_at_f(lx_p0, r_p2.span_p)));
    auto f_p6 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        if (prism_rtl::is<crate::lower::model::OutTy::OutMap>(rt_p5)) {
            _v.set(crate::lower::helper_f(Text::lit("get")));
            goto _done;
        }
        {
            _v.set(crate::lower::helper_f(Text::lit("index")));
            goto _done;
        }
    _done:
        _v.take();
    });
    return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{f_p6, Array(std::vector{argument_f(lx_p0, env_p1, r_p2), argument_f(lx_p0, env_p1, i_p3)})}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutOpt{prism_rtl::rc(t_p4)})});
}


prism_rtl::Turn<crate::lower::types::Vl> IndexValue::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& r_p2 = this->r_p2;
    const auto& i_p3 = this->i_p3;
    const auto& t_p4 = this->t_p4;
    auto env_p1x = env_p1;
    auto i_p3x = i_p3;
    auto lx_p0x = lx_p0;
    auto r_p2x = r_p2;
    auto t_p4x = t_p4;
    return crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0x, crate::lower::types::peel_f(crate::lower::type_at_f(lx_p0x, prism_rtl::deref(r_p2x).span_p))), [=](crate::lower::model::OutTy out_ty_of_f_53688) {
        return ({
            auto rt_p5 = out_ty_of_f_53688;
            auto f_p6 = ({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                if (prism_rtl::is<crate::lower::model::OutTy::OutMap>(rt_p5)) {
                    _v.set(crate::lower::helper_f(Text::lit("get")));
                    goto _done;
                }
                {
                    _v.set(crate::lower::helper_f(Text::lit("index")));
                    goto _done;
                }
            _done:
                _v.take();
            });
            (crate::prelude::call_then(start_argument_f(lx_p0x, env_p1x, r_p2x), [=, f_p6 = std::move(f_p6)](crate::lower::model::Ex argument_f_53852) { return crate::prelude::call_then(start_argument_f(lx_p0x, env_p1x, i_p3x), [=](crate::lower::model::Ex argument_f_53875) { return prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XCall{f_p6, Array(std::vector{argument_f_53852, argument_f_53875})}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutOpt{prism_rtl::rc(t_p4x)})})); }); }));
        });
    });
}


/// `Start IndexValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_index_value_f(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr r_p2, crate::syntax::Expr i_p3, crate::lower::model::OutTy t_p4) {
    return prism_rtl::make_rc<IndexValue>(lx_p0, env_p1, r_p2, i_p3, t_p4);
}


/// ReadNames: unbounded fn [Expr] -> [Text]
Array<Text> read_names_f(const Array<crate::syntax::Expr>& es_p0) {
    return crate::prelude::fold(es_p0, Array<Text>{}, [&](const Array<Text>& acc_p1, const crate::syntax::Expr& x_p2) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = prism_rtl::deref(prism_rtl::deref(x_p2).kind_p);
            if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
                auto&& n_p3 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
                _v.set(crate::prelude::len(prism_rtl::deref(n_p3).path_p) == Nat(1u)
                    ? crate::check::types::add_text_f(acc_p1, crate::check::env::sname_key_f(n_p3))
                    : acc_p1);
                goto _done;
            }
            {
                _v.set(acc_p1);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


prism_rtl::Turn<Array<Text>> ReadNames::cycle() const {
    const auto& es_p0 = this->es_p0;
    return prism_rtl::finished(crate::prelude::fold(es_p0, Array<Text>{}, [&](const Array<Text>& acc_p1, const crate::syntax::Expr& x_p2) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = prism_rtl::deref(prism_rtl::deref(x_p2).kind_p);
            if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
                auto&& n_p3 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
                _v.set(crate::prelude::len(prism_rtl::deref(n_p3).path_p) == Nat(1u)
                    ? crate::check::types::add_text_f(acc_p1, crate::check::env::sname_key_f(n_p3))
                    : acc_p1);
                goto _done;
            }
            {
                _v.set(acc_p1);
                goto _done;
            }
        _done:
            _v.take();
        });
    }));
}


/// `Start ReadNames, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_read_names_f(Array<crate::syntax::Expr> es_p0) {
    return prism_rtl::make_rc<ReadNames>(es_p0);
}


/// LambdaExprs: unbounded fn LambdaBody -> [Expr]
Array<crate::syntax::Expr> lambda_exprs_f(const crate::syntax::LambdaBody& lambda_body0) {
    if (prism_rtl::is<crate::syntax::LambdaBody::LbExpr>(lambda_body0)) {
        auto&& x_p0 = prism_rtl::as<crate::syntax::LambdaBody::LbExpr>(lambda_body0).a0;
        return crate::check::typed::print::exprs_in_f(prism_rtl::deref(prism_rtl::deref(x_p0)));
    }
    if (prism_rtl::is<crate::syntax::LambdaBody::LbBlock>(lambda_body0)) {
        auto&& b_p1 = prism_rtl::as<crate::syntax::LambdaBody::LbBlock>(lambda_body0).a0;
        return crate::check::typed::print::block_exprs_f(b_p1);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<crate::syntax::Expr>> LambdaExprs::cycle() const {
    const auto& lambda_body0 = this->lambda_body0;
    return ({
        prism_rtl::is<crate::syntax::LambdaBody::LbExpr>(lambda_body0) ? ({
        auto&& x_p0 = prism_rtl::as<crate::syntax::LambdaBody::LbExpr>(lambda_body0).a0;
        prism_rtl::more(prism_rtl::rc(crate::check::typed::print::ExprsIn(prism_rtl::deref(prism_rtl::deref(x_p0)))));
    })
        : prism_rtl::is<crate::syntax::LambdaBody::LbBlock>(lambda_body0) ? ({
        auto&& b_p1 = prism_rtl::as<crate::syntax::LambdaBody::LbBlock>(lambda_body0).a0;
        prism_rtl::more(prism_rtl::rc(crate::check::typed::print::BlockExprs(b_p1)));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start LambdaExprs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::syntax::Expr>> start_lambda_exprs_f(crate::syntax::LambdaBody lambda_body0) {
    return prism_rtl::make_rc<LambdaExprs>(lambda_body0);
}


/// FreeReads: unbounded fn [Expr], [(([Text], Range))] -> [Text]
Array<Text> free_reads_f(const Array<crate::syntax::Expr>& es_p0, const Array<std::tuple<Array<Text>, crate::syntax::Range>>& outer_p1) {
    auto scopes_p2 = crate::prelude::run_to_end(crate::prelude::fold_job(es_p0, outer_p1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Array<Text>, crate::syntax::Range>>>(std::tuple<Array<std::tuple<Array<Text>, crate::syntax::Range>>, crate::syntax::Expr>)>>(prism_rtl::rc([=](std::tuple<Array<std::tuple<Array<Text>, crate::syntax::Range>>, crate::syntax::Expr> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto acc_p3 = p0;
                auto e_p4 = p1;
                (crate::prelude::call_then(start_scopes_of_f(e_p4), [=, acc_p3 = std::move(acc_p3)](Array<std::tuple<Array<Text>, crate::syntax::Range>> scopes_of_f_54598) { return prism_rtl::finished(crate::prelude::append(acc_p3, scopes_of_f_54598)); }));
            });
        }));
    }))));
    return crate::prelude::fold(es_p0, Array<Text>{}, [&](const Array<Text>& acc_p5, const crate::syntax::Expr& e_p6) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p6).kind_p);
            if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
                auto&& n_p7 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
                _v.set(({
                    auto nkey_p8 = crate::check::env::sname_key_f(n_p7);
                    auto hidden_p9 = crate::prelude::fold(scopes_p2, false, [&](const bool& seen_pa, const std::tuple<Array<Text>, crate::syntax::Range>& _p1) {
                        auto&& names_pb = std::get<0>(_p1);
                        auto&& r_pc = std::get<1>(_p1);
                        return prism_rtl::deref(seen_pa) || ((crate::check::types::has_text_f(names_pb, nkey_p8) && (prism_rtl::deref(r_pc).start_p <= prism_rtl::deref(prism_rtl::deref(e_p6).span_p).start_p)) && (prism_rtl::deref(prism_rtl::deref(e_p6).span_p).start_p < prism_rtl::deref(r_pc).end_p));
                    });
                    (crate::prelude::len(prism_rtl::deref(n_p7).path_p) != Nat(1u)) || std::move(hidden_p9)
                    ? acc_p5
                    : crate::check::types::add_text_f(acc_p5, nkey_p8);
                }));
                goto _done;
            }
            {
                _v.set(acc_p5);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


prism_rtl::Turn<Array<Text>> FreeReads::cycle() const {
    const auto& es_p0 = this->es_p0;
    const auto& outer_p1 = this->outer_p1;
    auto es_p0x = es_p0;
    auto outer_p1x = outer_p1;
    return crate::prelude::call_value(crate::prelude::fold_job(es_p0x, outer_p1x, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Array<Text>, crate::syntax::Range>>>(std::tuple<Array<std::tuple<Array<Text>, crate::syntax::Range>>, crate::syntax::Expr>)>>(prism_rtl::rc([=](std::tuple<Array<std::tuple<Array<Text>, crate::syntax::Range>>, crate::syntax::Expr> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto acc_p3 = p0;
                auto e_p4 = p1;
                (crate::prelude::call_then(start_scopes_of_f(e_p4), [=, acc_p3 = std::move(acc_p3)](Array<std::tuple<Array<Text>, crate::syntax::Range>> scopes_of_f_54598) { return prism_rtl::finished(crate::prelude::append(acc_p3, scopes_of_f_54598)); }));
            });
        }));
    }))), [=](Array<std::tuple<Array<Text>, crate::syntax::Range>> fold_54559) {
        return ({
            auto scopes_p2 = fold_54559;
            (prism_rtl::finished(crate::prelude::fold(es_p0x, Array<Text>{}, [&](const Array<Text>& acc_p5, const crate::syntax::Expr& e_p6) {
            return ({
                __label__ _done;
                prism_rtl::Slot<Array<Text>> _v;
                auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p6).kind_p);
                if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
                    auto&& n_p7 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
                    _v.set(({
                        auto nkey_p8 = crate::check::env::sname_key_f(n_p7);
                        auto hidden_p9 = crate::prelude::fold(scopes_p2, false, [&](const bool& seen_pa, const std::tuple<Array<Text>, crate::syntax::Range>& _p1) {
                            auto&& names_pb = std::get<0>(_p1);
                            auto&& r_pc = std::get<1>(_p1);
                            return prism_rtl::deref(seen_pa) || ((crate::check::types::has_text_f(names_pb, nkey_p8) && (prism_rtl::deref(r_pc).start_p <= prism_rtl::deref(prism_rtl::deref(e_p6).span_p).start_p)) && (prism_rtl::deref(prism_rtl::deref(e_p6).span_p).start_p < prism_rtl::deref(r_pc).end_p));
                        });
                        (crate::prelude::len(prism_rtl::deref(n_p7).path_p) != Nat(1u)) || std::move(hidden_p9)
                        ? acc_p5
                        : crate::check::types::add_text_f(acc_p5, nkey_p8);
                    }));
                    goto _done;
                }
                {
                    _v.set(acc_p5);
                    goto _done;
                }
            _done:
                _v.take();
            });
        })));
        });
    });
}


/// `Start FreeReads, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_free_reads_f(Array<crate::syntax::Expr> es_p0, Array<std::tuple<Array<Text>, crate::syntax::Range>> outer_p1) {
    return prism_rtl::make_rc<FreeReads>(es_p0, outer_p1);
}


/// ScopesOf: unbounded fn Expr -> [(([Text], Range))]
Array<std::tuple<Array<Text>, crate::syntax::Range>> scopes_of_f(const crate::syntax::Expr& e_p0) {
    auto&& _m = prism_rtl::deref(e_p0.kind_p);
    if (prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m)) {
        auto&& ps_o1 = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0;
        auto&& body_p2 = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a1;
        auto names_p3 = crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::or_(ps_o1, Array<crate::syntax::Pattern_>{}), Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Pattern_> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto acc_p5 = p0;
                    auto q_p6 = p1;
                    (crate::prelude::call_then(crate::check::env::names::start_pattern_names_f(q_p6), [=, acc_p5 = std::move(acc_p5)](Array<Text> pattern_names_f_55209) { return prism_rtl::finished(crate::prelude::append(acc_p5, pattern_names_f_55209)); }));
                });
            }));
        }))));
        auto inner_p4 = ({
            __label__ _done;
            prism_rtl::Slot<Array<std::tuple<Array<Text>, crate::syntax::Range>>> _v;
            auto&& _m = prism_rtl::deref(prism_rtl::deref(body_p2));
            if (prism_rtl::is<crate::syntax::LambdaBody::LbBlock>(_m)) {
                auto&& b_p7 = prism_rtl::as<crate::syntax::LambdaBody::LbBlock>(_m).a0;
                _v.set(block_scopes_f(b_p7));
                goto _done;
            }
            {
                _v.set(Array<std::tuple<Array<Text>, crate::syntax::Range>>{});
                goto _done;
            }
        _done:
            _v.take();
        });
        return crate::prelude::push(inner_p4, std::tuple{names_p3, e_p0.span_p});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m)) {
        auto&& arms_p8 = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
        return crate::prelude::run_to_end(crate::prelude::fold_job(arms_p8, Array<std::tuple<Array<Text>, crate::syntax::Range>>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Array<Text>, crate::syntax::Range>>>(std::tuple<Array<std::tuple<Array<Text>, crate::syntax::Range>>, crate::syntax::Arm>)>>(prism_rtl::rc([=](std::tuple<Array<std::tuple<Array<Text>, crate::syntax::Range>>, crate::syntax::Arm> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto acc_p9 = p0;
                    auto a_pa = p1;
                    ({
                    auto names_pb = ({
                        __label__ _done;
                        prism_rtl::Slot<Array<Text>> _v;
                        auto&& _m = prism_rtl::deref(a_pa).pattern_o;
                        if (prism_rtl::is_some(_m)) {
                            auto&& q_pc = prism_rtl::some_of(_m);
                            _v.set(crate::check::env::names::pattern_names_f(q_pc));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(Array<Text>{});
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                    (prism_rtl::finished(crate::prelude::append(crate::prelude::push(acc_p9, std::tuple{names_pb, prism_rtl::deref(a_pa).span_p}), block_scopes_f(prism_rtl::deref(a_pa).body_p))));
                });
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EIf>(_m)) {
        auto&& c_pd = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
        auto&& t_pe = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
        auto&& el_of = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
        auto bound_pg = ({
            __label__ _done;
            prism_rtl::Slot<Array<std::tuple<Array<Text>, crate::syntax::Range>>> _v;
            auto&& _m = prism_rtl::deref(prism_rtl::deref(c_pd));
            if (prism_rtl::is<crate::syntax::Cond::CondBind>(_m)) {
                auto&& q_pi = prism_rtl::as<crate::syntax::Cond::CondBind>(_m).a0;
                _v.set(Array(std::vector{std::tuple{crate::check::env::names::pattern_names_f(q_pi), prism_rtl::deref(t_pe).span_p}}));
                goto _done;
            }
            {
                _v.set(Array<std::tuple<Array<Text>, crate::syntax::Range>>{});
                goto _done;
            }
        _done:
            _v.take();
        });
        auto else_scopes_ph = ({
            __label__ _done;
            prism_rtl::Slot<Array<std::tuple<Array<Text>, crate::syntax::Range>>> _v;
            if (prism_rtl::is_some(el_of)) {
                auto&& b_pj = prism_rtl::some_of(el_of);
                _v.set(block_scopes_f(b_pj));
                goto _done;
            }
            if (prism_rtl::is_none(el_of)) {
                _v.set(Array<std::tuple<Array<Text>, crate::syntax::Range>>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        return crate::prelude::append(crate::prelude::append(bound_pg, block_scopes_f(t_pe)), else_scopes_ph);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EFor>(_m)) {
        auto&& binders_ok = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a0;
        auto&& b_pl = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a2;
        auto names_pm = ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            if (prism_rtl::is_some(binders_ok)) {
                auto&& fb_pn = prism_rtl::some_of(binders_ok);
                _v.set(crate::prelude::append(crate::check::env::names::pattern_names_f(prism_rtl::deref(fb_pn).first_p), opt_pattern_names_f(prism_rtl::deref(fb_pn).second_o)));
                goto _done;
            }
            if (prism_rtl::is_none(binders_ok)) {
                _v.set(Array<Text>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        return crate::prelude::push(block_scopes_f(b_pl), std::tuple{names_pm, prism_rtl::deref(b_pl).span_p});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ERebuild>(_m)) {
        auto&& b_po = prism_rtl::as<crate::syntax::ExprKind::ERebuild>(_m).a1;
        return block_scopes_f(b_po);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGiven>(_m)) {
        auto&& b_pp = prism_rtl::as<crate::syntax::ExprKind::EGiven>(_m).a0;
        return block_scopes_f(b_pp);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EUpdate>(_m)) {
        auto&& b_pq = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a1;
        return block_scopes_f(b_pq);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EWidgetBlock>(_m)) {
        auto&& b_pr = prism_rtl::as<crate::syntax::ExprKind::EWidgetBlock>(_m).a0;
        return block_scopes_f(b_pr);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMonad>(_m)) {
        auto&& b_ps = prism_rtl::as<crate::syntax::ExprKind::EMonad>(_m).a1;
        return block_scopes_f(b_ps);
    }
    {
        return Array<std::tuple<Array<Text>, crate::syntax::Range>>{};
    }
}


prism_rtl::Turn<Array<std::tuple<Array<Text>, crate::syntax::Range>>> ScopesOf::cycle() const {
    const auto& e_p0 = this->e_p0;
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p0).kind_p);
        prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m) ? ({
        auto&& ps_o1 = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0;
        auto&& body_p2 = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a1;
        ({
        auto ps_o1x = ps_o1;
        auto body_p2x = prism_rtl::deref(prism_rtl::deref(body_p2));
        auto e_p0x = e_p0;
        (crate::prelude::call_value(crate::prelude::fold_job(crate::prelude::or_(ps_o1x, Array<crate::syntax::Pattern_>{}), Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Pattern_> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto acc_p5 = p0;
                auto q_p6 = p1;
                (crate::prelude::call_then(crate::check::env::names::start_pattern_names_f(q_p6), [=, acc_p5 = std::move(acc_p5)](Array<Text> pattern_names_f_55209) { return prism_rtl::finished(crate::prelude::append(acc_p5, pattern_names_f_55209)); }));
            });
        }));
    }))), [=, body_p2x = std::move(body_p2x), e_p0x = std::move(e_p0x)](Array<Text> fold_55159) {
        return ({
            auto names_p3 = fold_55159;
            auto inner_p4 = ({
                __label__ _done;
                prism_rtl::Slot<Array<std::tuple<Array<Text>, crate::syntax::Range>>> _v;
                if (prism_rtl::is<crate::syntax::LambdaBody::LbBlock>(body_p2x)) {
                    auto&& b_p7 = prism_rtl::as<crate::syntax::LambdaBody::LbBlock>(body_p2x).a0;
                    _v.set(block_scopes_f(b_p7));
                    goto _done;
                }
                {
                    _v.set(Array<std::tuple<Array<Text>, crate::syntax::Range>>{});
                    goto _done;
                }
            _done:
                _v.take();
            });
            (prism_rtl::finished(crate::prelude::push(inner_p4, std::tuple{names_p3, prism_rtl::deref(e_p0x).span_p})));
        });
    }));
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m) ? ({
        auto&& arms_p8 = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
        crate::prelude::fold_job(arms_p8, Array<std::tuple<Array<Text>, crate::syntax::Range>>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Array<Text>, crate::syntax::Range>>>(std::tuple<Array<std::tuple<Array<Text>, crate::syntax::Range>>, crate::syntax::Arm>)>>(prism_rtl::rc([=](std::tuple<Array<std::tuple<Array<Text>, crate::syntax::Range>>, crate::syntax::Arm> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto acc_p9 = p0;
                auto a_pa = p1;
                ({
                auto names_pb = ({
                    __label__ _done;
                    prism_rtl::Slot<Array<Text>> _v;
                    auto&& _m = prism_rtl::deref(a_pa).pattern_o;
                    if (prism_rtl::is_some(_m)) {
                        auto&& q_pc = prism_rtl::some_of(_m);
                        _v.set(crate::check::env::names::pattern_names_f(q_pc));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(Array<Text>{});
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                (prism_rtl::finished(crate::prelude::append(crate::prelude::push(acc_p9, std::tuple{names_pb, prism_rtl::deref(a_pa).span_p}), block_scopes_f(prism_rtl::deref(a_pa).body_p))));
            });
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) ? ({
        auto&& c_pd = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
        auto&& t_pe = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
        auto&& el_of = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
        ({
        auto bound_pg = ({
            __label__ _done;
            prism_rtl::Slot<Array<std::tuple<Array<Text>, crate::syntax::Range>>> _v;
            auto&& _m = prism_rtl::deref(prism_rtl::deref(c_pd));
            if (prism_rtl::is<crate::syntax::Cond::CondBind>(_m)) {
                auto&& q_pi = prism_rtl::as<crate::syntax::Cond::CondBind>(_m).a0;
                _v.set(Array(std::vector{std::tuple{crate::check::env::names::pattern_names_f(q_pi), prism_rtl::deref(t_pe).span_p}}));
                goto _done;
            }
            {
                _v.set(Array<std::tuple<Array<Text>, crate::syntax::Range>>{});
                goto _done;
            }
        _done:
            _v.take();
        });
        auto else_scopes_ph = ({
            __label__ _done;
            prism_rtl::Slot<Array<std::tuple<Array<Text>, crate::syntax::Range>>> _v;
            if (prism_rtl::is_some(el_of)) {
                auto&& b_pj = prism_rtl::some_of(el_of);
                _v.set(block_scopes_f(b_pj));
                goto _done;
            }
            if (prism_rtl::is_none(el_of)) {
                _v.set(Array<std::tuple<Array<Text>, crate::syntax::Range>>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        (prism_rtl::finished(crate::prelude::append(crate::prelude::append(bound_pg, block_scopes_f(t_pe)), else_scopes_ph)));
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EFor>(_m) ? ({
        auto&& binders_ok = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a0;
        auto&& b_pl = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a2;
        ({
        auto names_pm = ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            if (prism_rtl::is_some(binders_ok)) {
                auto&& fb_pn = prism_rtl::some_of(binders_ok);
                _v.set(crate::prelude::append(crate::check::env::names::pattern_names_f(prism_rtl::deref(fb_pn).first_p), opt_pattern_names_f(prism_rtl::deref(fb_pn).second_o)));
                goto _done;
            }
            if (prism_rtl::is_none(binders_ok)) {
                _v.set(Array<Text>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        (prism_rtl::finished(crate::prelude::push(block_scopes_f(b_pl), std::tuple{names_pm, prism_rtl::deref(b_pl).span_p})));
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::ERebuild>(_m) ? ({
        auto&& b_po = prism_rtl::as<crate::syntax::ExprKind::ERebuild>(_m).a1;
        prism_rtl::finished(block_scopes_f(b_po));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EGiven>(_m) ? ({
        auto&& b_pp = prism_rtl::as<crate::syntax::ExprKind::EGiven>(_m).a0;
        prism_rtl::finished(block_scopes_f(b_pp));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EUpdate>(_m) ? ({
        auto&& b_pq = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a1;
        prism_rtl::finished(block_scopes_f(b_pq));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EWidgetBlock>(_m) ? ({
        auto&& b_pr = prism_rtl::as<crate::syntax::ExprKind::EWidgetBlock>(_m).a0;
        prism_rtl::finished(block_scopes_f(b_pr));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EMonad>(_m) ? ({
        auto&& b_ps = prism_rtl::as<crate::syntax::ExprKind::EMonad>(_m).a1;
        prism_rtl::finished(block_scopes_f(b_ps));
    })
        : prism_rtl::finished(Array<std::tuple<Array<Text>, crate::syntax::Range>>{});
    });
}


/// `Start ScopesOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<std::tuple<Array<Text>, crate::syntax::Range>>> start_scopes_of_f(crate::syntax::Expr e_p0) {
    return prism_rtl::make_rc<ScopesOf>(e_p0);
}


/// OptPatternNames: unbounded fn ?Pattern -> [Text]
Array<Text> opt_pattern_names_f(const std::optional<crate::syntax::Pattern_>& opt0) {
    if (prism_rtl::is_some(opt0)) {
        auto&& q_p0 = prism_rtl::some_of(opt0);
        return crate::check::env::names::pattern_names_f(q_p0);
    }
    if (prism_rtl::is_none(opt0)) {
        return Array<Text>{};
    }
    prism_rtl::unreachable("no arm matched");
}


/// BlockScopes: unbounded fn Block -> [(([Text], Range))]
Array<std::tuple<Array<Text>, crate::syntax::Range>> block_scopes_f(const crate::syntax::Block& b_p0) {
    return crate::prelude::run_to_end(crate::prelude::fold_job(b_p0.stmts_p, Array<std::tuple<Array<Text>, crate::syntax::Range>>{}, ({
        auto b_p0x = b_p0;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Array<Text>, crate::syntax::Range>>>(std::tuple<Array<std::tuple<Array<Text>, crate::syntax::Range>>, crate::syntax::Stmt>)>>(prism_rtl::rc([=, b_p0x = std::move(b_p0x)](std::tuple<Array<std::tuple<Array<Text>, crate::syntax::Range>>, crate::syntax::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto b_p0xy = b_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, b_p0xy = std::move(b_p0xy)]() {
            return ({
                auto acc_p1 = p0;
                auto s_p2 = p1;
                (crate::prelude::call_then(crate::check::blocks::start_group_defs_f(s_p2), [=, acc_p1 = std::move(acc_p1)](Array<Text> group_defs_f_56645) {
                return ({
                    auto own_p3 = crate::prelude::push(acc_p1, std::tuple{group_defs_f_56645, crate::syntax::Range{.start_p = prism_rtl::deref(prism_rtl::deref(s_p2).span_p).start_p, .end_p = prism_rtl::deref(prism_rtl::deref(b_p0xy).span_p).end_p}});
                    ({
                    auto&& _m = prism_rtl::deref(s_p2).kind_p;
                    prism_rtl::is<crate::syntax::StmtKind::SFn>(_m) ? ({
                    auto&& f_p4 = prism_rtl::as<crate::syntax::StmtKind::SFn>(_m).a0;
                    ({
                    auto f_p4x = f_p4;
                    (crate::prelude::call_value(crate::prelude::fold_job(prism_rtl::deref(f_p4x).params_p, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Pattern_> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return crate::prelude::entered(crate::prelude::once_job([=]() {
                        return ({
                            auto ps_p5 = p0;
                            auto q_p6 = p1;
                            (crate::prelude::call_then(crate::check::env::names::start_pattern_names_f(q_p6), [=, ps_p5 = std::move(ps_p5)](Array<Text> pattern_names_f_56803) { return prism_rtl::finished(crate::prelude::append(ps_p5, pattern_names_f_56803)); }));
                        });
                    }));
                }))), [=](Array<Text> fold_56761) { return prism_rtl::finished(crate::prelude::push(own_p3, std::tuple{fold_56761, prism_rtl::deref(f_p4x).span_p})); }));
                });
                })
                    : prism_rtl::finished(own_p3);
                });
                });
            }));
            });
        })));
        });
    }));
    })));
}


/// CaptureName: fn Ex -> Text
Text capture_name_f(const crate::lower::model::Ex& rs_p0) {
    return prism_rtl::cat(crate::lower::types::place_stem_f(rs_p0), "x");
}


/// CopyName: fn Ex -> Text
Text copy_name_f(const crate::lower::model::Ex& rs_p0) {
    return prism_rtl::cat(crate::lower::types::place_stem_f(rs_p0), "y");
}


/// OuterName: fn Ex -> Text
Text outer_name_f(const crate::lower::model::Ex& rs_p0) {
    return prism_rtl::cat(crate::lower::types::place_stem_f(rs_p0), "z");
}


/// LambdaReads: unbounded fn [Pattern], LambdaBody -> [Text]
Array<Text> lambda_reads_f(const Array<crate::syntax::Pattern_>& ps_p0, const crate::syntax::LambdaBody& body_p1) {
    auto own_p2 = crate::prelude::run_to_end(crate::prelude::fold_job(ps_p0, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Pattern_> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto acc_p3 = p0;
                auto q_p4 = p1;
                (crate::prelude::call_then(crate::check::env::names::start_pattern_names_f(q_p4), [=, acc_p3 = std::move(acc_p3)](Array<Text> pattern_names_f_57563) { return prism_rtl::finished(crate::prelude::append(acc_p3, pattern_names_f_57563)); }));
            });
        }));
    }))));
    return crate::prelude::filter(free_reads_f(lambda_exprs_f(body_p1), Array<std::tuple<Array<Text>, crate::syntax::Range>>{}), [&](const Text& n_p5) { return !crate::check::types::has_text_f(own_p2, n_p5); });
}


prism_rtl::Turn<Array<Text>> LambdaReads::cycle() const {
    const auto& ps_p0 = this->ps_p0;
    const auto& body_p1 = this->body_p1;
    auto body_p1x = body_p1;
    auto ps_p0x = ps_p0;
    return crate::prelude::call_value(crate::prelude::fold_job(ps_p0x, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Pattern_> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto acc_p3 = p0;
                auto q_p4 = p1;
                (crate::prelude::call_then(crate::check::env::names::start_pattern_names_f(q_p4), [=, acc_p3 = std::move(acc_p3)](Array<Text> pattern_names_f_57563) { return prism_rtl::finished(crate::prelude::append(acc_p3, pattern_names_f_57563)); }));
            });
        }));
    }))), [=](Array<Text> fold_57525) {
        return ({
            auto own_p2 = fold_57525;
            (crate::prelude::call_then(start_lambda_exprs_f(body_p1x), [=, own_p2 = std::move(own_p2)](Array<crate::syntax::Expr> lambda_exprs_f_57602) { return crate::prelude::call_then(start_free_reads_f(lambda_exprs_f_57602, Array<std::tuple<Array<Text>, crate::syntax::Range>>{}), [=](Array<Text> free_reads_f_57591) { return prism_rtl::finished(crate::prelude::filter(free_reads_f_57591, [&](const Text& n_p5) { return !crate::check::types::has_text_f(own_p2, n_p5); })); }); }));
        });
    });
}


/// `Start LambdaReads, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_lambda_reads_f(Array<crate::syntax::Pattern_> ps_p0, crate::syntax::LambdaBody body_p1) {
    return prism_rtl::make_rc<LambdaReads>(ps_p0, body_p1);
}


/// LambdaValue: unbounded fn Lx, Env, Expr, [Pattern], LambdaBody -> Vl
crate::lower::types::Vl lambda_value_f(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Expr& e_p2, const Array<crate::syntax::Pattern_>& ps_p3, const crate::syntax::LambdaBody& body_p4) {
    auto ft_p5 = crate::lower::types::out_ty_of_f(lx_p0, crate::lower::types::peel_f(crate::lower::type_at_f(lx_p0, e_p2.span_p)));
    if (prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(ft_p5)) {
        auto&& a_p6 = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(ft_p5).a0;
        return job_lambda_f(lx_p0, env_p1, ps_p3, body_p4, ft_p5, prism_rtl::deref(prism_rtl::deref(a_p6)), enters_lambda_f(lx_p0, e_p2));
    }
    {
        return plain_lambda_f(lx_p0, env_p1, ps_p3, body_p4, ft_p5);
    }
}


prism_rtl::Turn<crate::lower::types::Vl> LambdaValue::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& e_p2 = this->e_p2;
    const auto& ps_p3 = this->ps_p3;
    const auto& body_p4 = this->body_p4;
    auto body_p4x = body_p4;
    auto e_p2x = e_p2;
    auto env_p1x = env_p1;
    auto lx_p0x = lx_p0;
    auto ps_p3x = ps_p3;
    return crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0x, crate::lower::types::peel_f(crate::lower::type_at_f(lx_p0x, prism_rtl::deref(e_p2x).span_p))), [=](crate::lower::model::OutTy out_ty_of_f_57900) {
        return ({
            auto ft_p5 = out_ty_of_f_57900;
            ({
            prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(ft_p5) ? ({
            auto&& a_p6 = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(ft_p5).a0;
            prism_rtl::more(prism_rtl::rc(JobLambda(lx_p0x, env_p1x, ps_p3x, body_p4x, ft_p5, prism_rtl::deref(prism_rtl::deref(a_p6)), enters_lambda_f(lx_p0x, e_p2x))));
        })
            : prism_rtl::more(prism_rtl::rc(PlainLambda(lx_p0x, env_p1x, ps_p3x, body_p4x, ft_p5)));
        });
        });
    });
}


/// `Start LambdaValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_lambda_value_f(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Expr e_p2, Array<crate::syntax::Pattern_> ps_p3, crate::syntax::LambdaBody body_p4) {
    return prism_rtl::make_rc<LambdaValue>(lx_p0, env_p1, e_p2, ps_p3, body_p4);
}


/// PlainLambda: unbounded fn Lx, Env, [Pattern], LambdaBody, OutTy -> Vl
crate::lower::types::Vl plain_lambda_f(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const Array<crate::syntax::Pattern_>& ps_p2, const crate::syntax::LambdaBody& body_p3, const crate::lower::model::OutTy& ft_p4) {
    auto pts_p5 = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::lower::model::OutTy>> _v;
        if (prism_rtl::is<crate::lower::model::OutTy::OutFn>(ft_p4)) {
            auto&& xs_pa = prism_rtl::as<crate::lower::model::OutTy::OutFn>(ft_p4).a0;
            _v.set(xs_pa);
            goto _done;
        }
        {
            _v.set(Array<crate::lower::model::OutTy>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto read_p6 = crate::lower::types::with_instances_f(env_p1, lambda_reads_f(ps_p2, body_p3));
    auto caps0_p7 = crate::prelude::filter(read_p6, [&](const Text& n_pb) {
        return ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            auto&& _m = crate::prelude::get(env_p1.names_p, n_pb);
            if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m))) {
                _v.set(true);
                goto _done;
            }
            {
                _v.set(false);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto caps_p8 = crate::prelude::append(crate::prelude::append(caps0_p7, crate::prelude::filter(crate::prelude::each(read_p6, [&](const Text& n_pc) { return prism_rtl::cat(n_pc, "#port"); }), [&](const Text& n_pd) { return crate::check::env::has_key_f(env_p1.names_p, n_pd); })), crate::prelude::filter(crate::prelude::each(read_p6, [&](const Text& n_pe) { return prism_rtl::cat(n_pe, "#init"); }), [&](const Text& n_pf) { return crate::check::env::has_key_f(env_p1.names_p, n_pf); }));
    auto [dos_po, env1_pp] = crate::prelude::fold(caps_p8, std::tuple{Array<crate::lower::model::Do>{}, env_p1}, [&](const std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>& _p0, const Text& n_pi) {
        auto&& acc_pg = std::get<0>(_p0);
        auto&& en_ph = std::get<1>(_p0);
        return ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> _v;
            auto&& _m = crate::prelude::get(env_p1.names_p, n_pi);
            if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m))) {
                auto&& rs_pj = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                auto&& mode_pk = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a1;
                auto&& ct_pl = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                _v.set(({
                    auto local_pm = capture_name_f(rs_pj);
                    auto d_pn = crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{local_pm}), crate::lower::types::own_f(crate::lower::types::local_place_f(rs_pj, mode_pk, ct_pl))});
                    std::tuple{crate::prelude::push(acc_pg, d_pn), crate::lower::types::bind_f(en_ph, n_pi, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{local_pm}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), ct_pl}))};
                }));
                goto _done;
            }
            {
                _v.set(std::tuple{acc_pg, en_ph});
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto [pas_pq, env2_pr] = closure_params_f(lx_p0, env1_pp, ps_p2, pts_p5, true);
    auto v_p9 = lambda_body_value_f(lx_p0, env2_pr, body_p3);
    return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBlock{dos_po, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCast{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, pas_pq, prism_rtl::rc(crate::lower::types::own_f(v_p9))})})})), ft_p4}))}), ft_p4});
}


prism_rtl::Turn<crate::lower::types::Vl> PlainLambda::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& ps_p2 = this->ps_p2;
    const auto& body_p3 = this->body_p3;
    const auto& ft_p4 = this->ft_p4;
    auto pts_p5 = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::lower::model::OutTy>> _v;
        if (prism_rtl::is<crate::lower::model::OutTy::OutFn>(ft_p4)) {
            auto&& xs_pa = prism_rtl::as<crate::lower::model::OutTy::OutFn>(ft_p4).a0;
            _v.set(xs_pa);
            goto _done;
        }
        {
            _v.set(Array<crate::lower::model::OutTy>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto body_p3x = body_p3;
    auto env_p1x = env_p1;
    auto ft_p4x = ft_p4;
    auto lx_p0x = lx_p0;
    auto ps_p2x = ps_p2;
    return crate::prelude::call_then(start_lambda_reads_f(ps_p2x, body_p3x), [=](Array<Text> lambda_reads_f_58312) {
        return ({
            auto read_p6 = crate::lower::types::with_instances_f(env_p1x, lambda_reads_f_58312);
            auto caps0_p7 = crate::prelude::filter(read_p6, [&](const Text& n_pb) {
                return ({
                    __label__ _done;
                    prism_rtl::Slot<bool> _v;
                    auto&& _m = crate::prelude::get(prism_rtl::deref(env_p1x).names_p, n_pb);
                    if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m))) {
                        _v.set(true);
                        goto _done;
                    }
                    {
                        _v.set(false);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
            });
            auto caps_p8 = crate::prelude::append(crate::prelude::append(caps0_p7, crate::prelude::filter(crate::prelude::each(read_p6, [&](const Text& n_pc) { return prism_rtl::cat(n_pc, "#port"); }), [&](const Text& n_pd) { return crate::check::env::has_key_f(prism_rtl::deref(env_p1x).names_p, n_pd); })), crate::prelude::filter(crate::prelude::each(read_p6, [&](const Text& n_pe) { return prism_rtl::cat(n_pe, "#init"); }), [&](const Text& n_pf) { return crate::check::env::has_key_f(prism_rtl::deref(env_p1x).names_p, n_pf); }));
            auto [dos_po, env1_pp] = crate::prelude::fold(caps_p8, std::tuple{Array<crate::lower::model::Do>{}, env_p1x}, [&](const std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>& _p0, const Text& n_pi) {
                auto&& acc_pg = std::get<0>(_p0);
                auto&& en_ph = std::get<1>(_p0);
                return ({
                    __label__ _done;
                    prism_rtl::Slot<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> _v;
                    auto&& _m = crate::prelude::get(prism_rtl::deref(env_p1x).names_p, n_pi);
                    if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m))) {
                        auto&& rs_pj = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                        auto&& mode_pk = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a1;
                        auto&& ct_pl = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                        _v.set(({
                            auto local_pm = capture_name_f(rs_pj);
                            auto d_pn = crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{local_pm}), crate::lower::types::own_f(crate::lower::types::local_place_f(rs_pj, mode_pk, ct_pl))});
                            std::tuple{crate::prelude::push(acc_pg, d_pn), crate::lower::types::bind_f(en_ph, n_pi, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{local_pm}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), ct_pl}))};
                        }));
                        goto _done;
                    }
                    {
                        _v.set(std::tuple{acc_pg, en_ph});
                        goto _done;
                    }
                _done:
                    _v.take();
                });
            });
            (crate::prelude::call_then(start_closure_params_f(lx_p0x, env1_pp, ps_p2x, pts_p5, true), [=](std::tuple<Array<crate::lower::model::Pa>, crate::lower::types::Env> closure_params_f_59200) {
            return ({
                auto [pas_pq, env2_pr] = closure_params_f_59200;
                (crate::prelude::call_then(start_lambda_body_value_f(lx_p0x, env2_pr, body_p3x), [=](crate::lower::types::Vl lambda_body_value_f_59250) {
                return ({
                    auto v_p9 = lambda_body_value_f_59250;
                    (prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBlock{dos_po, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCast{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, pas_pq, prism_rtl::rc(crate::lower::types::own_f(v_p9))})})})), ft_p4x}))}), ft_p4x})));
                });
            }));
            });
        }));
        });
    });
}


/// `Start PlainLambda, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_plain_lambda_f(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, Array<crate::syntax::Pattern_> ps_p2, crate::syntax::LambdaBody body_p3, crate::lower::model::OutTy ft_p4) {
    return prism_rtl::make_rc<PlainLambda>(lx_p0, env_p1, ps_p2, body_p3, ft_p4);
}


/// LambdaParamTys: unbounded fn Lx, Expr, Nat -> [OutTy]
Array<crate::lower::model::OutTy> lambda_param_tys_f(const crate::lower::Lx& lx_p0, const crate::syntax::Expr& e_p1, const Nat& n_p2) {
    auto ts_p3 = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::lower::model::OutTy>> _v;
        auto&& _m = crate::lower::types::out_ty_of_f(lx_p0, crate::lower::types::peel_f(crate::lower::type_at_f(lx_p0, e_p1.span_p)));
        if (prism_rtl::is<crate::lower::model::OutTy::OutFn>(_m)) {
            auto&& xs_p4 = prism_rtl::as<crate::lower::model::OutTy::OutFn>(_m).a0;
            _v.set(xs_p4);
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(_m)) {
            auto&& a_p5 = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(_m).a0;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<Array<crate::lower::model::OutTy>> _v;
                auto&& _m = prism_rtl::deref(a_p5);
                if (prism_rtl::is<crate::lower::model::OutTy::OutTuple>(_m)) {
                    auto&& xs_p6 = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(_m).a0;
                    _v.set(n_p2 == Nat(1u) ? Array(std::vector{prism_rtl::deref(a_p5)}) : xs_p6);
                    goto _done;
                }
                {
                    _v.set(Array(std::vector{prism_rtl::deref(a_p5)}));
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        {
            _v.set(Array<crate::lower::model::OutTy>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    return (crate::prelude::len(ts_p3) == n_p2) && crate::prelude::run_to_end(crate::prelude::fold_job(ts_p3, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<bool, crate::lower::model::OutTy> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto ok_p7 = p0;
                auto t_p8 = p1;
                (prism_rtl::finished(std::move(ok_p7) && is_known_ty_f(t_p8)));
            });
        }));
    }))))
        ? ts_p3
        : Array<crate::lower::model::OutTy>{};
}


prism_rtl::Turn<Array<crate::lower::model::OutTy>> LambdaParamTys::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& e_p1 = this->e_p1;
    const auto& n_p2 = this->n_p2;
    auto e_p1x = e_p1;
    auto lx_p0x = lx_p0;
    auto n_p2x = n_p2;
    return crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0x, crate::lower::types::peel_f(crate::lower::type_at_f(lx_p0x, prism_rtl::deref(e_p1x).span_p))), [=](crate::lower::model::OutTy out_ty_of_f_59841) {
        return ({
            auto ts_p3 = ({
                __label__ _done;
                prism_rtl::Slot<Array<crate::lower::model::OutTy>> _v;
                if (prism_rtl::is<crate::lower::model::OutTy::OutFn>(out_ty_of_f_59841)) {
                    auto&& xs_p4 = prism_rtl::as<crate::lower::model::OutTy::OutFn>(out_ty_of_f_59841).a0;
                    _v.set(xs_p4);
                    goto _done;
                }
                if (prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(out_ty_of_f_59841)) {
                    auto&& a_p5 = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(out_ty_of_f_59841).a0;
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<Array<crate::lower::model::OutTy>> _v;
                        auto&& _m = prism_rtl::deref(a_p5);
                        if (prism_rtl::is<crate::lower::model::OutTy::OutTuple>(_m)) {
                            auto&& xs_p6 = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(_m).a0;
                            _v.set(n_p2x == Nat(1u) ? Array(std::vector{prism_rtl::deref(a_p5)}) : xs_p6);
                            goto _done;
                        }
                        {
                            _v.set(Array(std::vector{prism_rtl::deref(a_p5)}));
                            goto _done;
                        }
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                {
                    _v.set(Array<crate::lower::model::OutTy>{});
                    goto _done;
                }
            _done:
                _v.take();
            });
            (crate::prelude::len(ts_p3) == n_p2x) && crate::prelude::run_to_end(crate::prelude::fold_job(ts_p3, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<bool, crate::lower::model::OutTy> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto ok_p7 = p0;
                    auto t_p8 = p1;
                    (prism_rtl::finished(std::move(ok_p7) && is_known_ty_f(t_p8)));
                });
            }));
        }))))
            ? prism_rtl::finished(ts_p3)
            : prism_rtl::finished(Array<crate::lower::model::OutTy>{});
        });
    });
}


/// `Start LambdaParamTys, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::lower::model::OutTy>> start_lambda_param_tys_f(crate::lower::Lx lx_p0, crate::syntax::Expr e_p1, Nat n_p2) {
    return prism_rtl::make_rc<LambdaParamTys>(lx_p0, e_p1, n_p2);
}


/// IsKnownTy: unbounded fn OutTy -> Bool
bool is_known_ty_f(const crate::lower::model::OutTy& t_p0) {
    if (prism_rtl::is<crate::lower::model::OutTy::OutRefused>(t_p0)) {
        return false;
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutOpt>(t_p0)) {
        auto&& x_p1 = prism_rtl::as<crate::lower::model::OutTy::OutOpt>(t_p0).a0;
        return is_known_ty_f(prism_rtl::deref(prism_rtl::deref(x_p1)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutRes>(t_p0)) {
        auto&& x_p2 = prism_rtl::as<crate::lower::model::OutTy::OutRes>(t_p0).a0;
        return is_known_ty_f(prism_rtl::deref(prism_rtl::deref(x_p2)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutArray>(t_p0)) {
        auto&& x_p3 = prism_rtl::as<crate::lower::model::OutTy::OutArray>(t_p0).a0;
        return is_known_ty_f(prism_rtl::deref(prism_rtl::deref(x_p3)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutRc>(t_p0)) {
        auto&& x_p4 = prism_rtl::as<crate::lower::model::OutTy::OutRc>(t_p0).a0;
        return is_known_ty_f(prism_rtl::deref(prism_rtl::deref(x_p4)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutMap>(t_p0)) {
        auto&& k_p5 = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t_p0).a0;
        auto&& v_p6 = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t_p0).a1;
        return is_known_ty_f(prism_rtl::deref(prism_rtl::deref(k_p5))) && is_known_ty_f(prism_rtl::deref(prism_rtl::deref(v_p6)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutTuple>(t_p0)) {
        auto&& xs_p7 = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(t_p0).a0;
        return crate::prelude::run_to_end(crate::prelude::fold_job(xs_p7, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<bool, crate::lower::model::OutTy> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto ok_p8 = p0;
                    auto x_p9 = p1;
                    (prism_rtl::finished(std::move(ok_p8) && is_known_ty_f(x_p9)));
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t_p0)) {
        auto&& xs_pa = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p0).a1;
        return crate::prelude::run_to_end(crate::prelude::fold_job(xs_pa, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<bool, crate::lower::model::OutTy> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto ok_pb = p0;
                    auto x_pc = p1;
                    (prism_rtl::finished(std::move(ok_pb) && is_known_ty_f(x_pc)));
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutFn>(t_p0)) {
        auto&& xs_pd = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t_p0).a0;
        auto&& r_pe = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t_p0).a1;
        return crate::prelude::run_to_end(crate::prelude::fold_job(xs_pd, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<bool, crate::lower::model::OutTy> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto ok_pf = p0;
                    auto x_pg = p1;
                    (prism_rtl::finished(std::move(ok_pf) && is_known_ty_f(x_pg)));
                });
            }));
        })))) && is_known_ty_f(prism_rtl::deref(prism_rtl::deref(r_pe)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(t_p0)) {
        auto&& a_ph = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(t_p0).a0;
        auto&& b_pi = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(t_p0).a1;
        return is_known_ty_f(prism_rtl::deref(prism_rtl::deref(a_ph))) && is_known_ty_f(prism_rtl::deref(prism_rtl::deref(b_pi)));
    }
    {
        return true;
    }
}


prism_rtl::Turn<bool> IsKnownTy::cycle() const {
    const auto& t_p0 = this->t_p0;
    return ({
        prism_rtl::is<crate::lower::model::OutTy::OutRefused>(t_p0) ? prism_rtl::finished(false)
        : prism_rtl::is<crate::lower::model::OutTy::OutOpt>(t_p0) ? ({
        auto&& x_p1 = prism_rtl::as<crate::lower::model::OutTy::OutOpt>(t_p0).a0;
        prism_rtl::more(prism_rtl::rc(IsKnownTy(prism_rtl::deref(prism_rtl::deref(x_p1)))));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutRes>(t_p0) ? ({
        auto&& x_p2 = prism_rtl::as<crate::lower::model::OutTy::OutRes>(t_p0).a0;
        prism_rtl::more(prism_rtl::rc(IsKnownTy(prism_rtl::deref(prism_rtl::deref(x_p2)))));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutArray>(t_p0) ? ({
        auto&& x_p3 = prism_rtl::as<crate::lower::model::OutTy::OutArray>(t_p0).a0;
        prism_rtl::more(prism_rtl::rc(IsKnownTy(prism_rtl::deref(prism_rtl::deref(x_p3)))));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutRc>(t_p0) ? ({
        auto&& x_p4 = prism_rtl::as<crate::lower::model::OutTy::OutRc>(t_p0).a0;
        prism_rtl::more(prism_rtl::rc(IsKnownTy(prism_rtl::deref(prism_rtl::deref(x_p4)))));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutMap>(t_p0) ? ({
        auto&& k_p5 = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t_p0).a0;
        auto&& v_p6 = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t_p0).a1;
        ({
        auto k_p5x = prism_rtl::deref(prism_rtl::deref(k_p5));
        auto v_p6x = prism_rtl::deref(prism_rtl::deref(v_p6));
        (crate::prelude::call_then(start_is_known_ty_f(k_p5x), [=, v_p6x = std::move(v_p6x)](bool is_known_ty_f_60351) { return prism_rtl::finished(is_known_ty_f_60351 && is_known_ty_f(v_p6x)); }));
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutTuple>(t_p0) ? ({
        auto&& xs_p7 = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(t_p0).a0;
        crate::prelude::fold_job(xs_p7, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<bool, crate::lower::model::OutTy> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto ok_p8 = p0;
                auto x_p9 = p1;
                (prism_rtl::finished(std::move(ok_p8) && is_known_ty_f(x_p9)));
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t_p0) ? ({
        auto&& xs_pa = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p0).a1;
        crate::prelude::fold_job(xs_pa, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<bool, crate::lower::model::OutTy> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto ok_pb = p0;
                auto x_pc = p1;
                (prism_rtl::finished(std::move(ok_pb) && is_known_ty_f(x_pc)));
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutFn>(t_p0) ? ({
        auto&& xs_pd = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t_p0).a0;
        auto&& r_pe = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t_p0).a1;
        ({
        auto r_pex = prism_rtl::deref(prism_rtl::deref(r_pe));
        auto xs_pdx = xs_pd;
        (crate::prelude::call_value(crate::prelude::fold_job(xs_pdx, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<bool, crate::lower::model::OutTy> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto ok_pf = p0;
                auto x_pg = p1;
                (prism_rtl::finished(std::move(ok_pf) && is_known_ty_f(x_pg)));
            });
        }));
    }))), [=, r_pex = std::move(r_pex)](bool fold_60526) { return prism_rtl::finished(fold_60526 && is_known_ty_f(r_pex)); }));
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(t_p0) ? ({
        auto&& a_ph = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(t_p0).a0;
        auto&& b_pi = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(t_p0).a1;
        ({
        auto a_phx = prism_rtl::deref(prism_rtl::deref(a_ph));
        auto b_pix = prism_rtl::deref(prism_rtl::deref(b_pi));
        (crate::prelude::call_then(start_is_known_ty_f(a_phx), [=, b_pix = std::move(b_pix)](bool is_known_ty_f_60606) { return prism_rtl::finished(is_known_ty_f_60606 && is_known_ty_f(b_pix)); }));
    });
    })
        : prism_rtl::finished(true);
    });
}


/// `Start IsKnownTy, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_is_known_ty_f(crate::lower::model::OutTy t_p0) {
    return prism_rtl::make_rc<IsKnownTy>(t_p0);
}


/// JobLambda: unbounded fn Lx, Env, [Pattern], LambdaBody, OutTy, OutTy, Bool -> Vl
crate::lower::types::Vl job_lambda_f(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const Array<crate::syntax::Pattern_>& ps_p2, const crate::syntax::LambdaBody& body_p3, const crate::lower::model::OutTy& ft_p4, const crate::lower::model::OutTy& a_p5, const bool& enter_p6) {
    auto caps_p7 = crate::prelude::filter(crate::lower::types::with_instances_f(env_p1, lambda_reads_f(ps_p2, body_p3)), [&](const Text& n_pl) {
        return ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            auto&& _m = crate::prelude::get(env_p1.names_p, n_pl);
            if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m))) {
                _v.set(true);
                goto _done;
            }
            {
                _v.set(false);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto [dos_pt, env1_pu] = crate::prelude::fold(caps_p7, std::tuple{Array<crate::lower::model::Do>{}, env_p1}, [&](const std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>& _p0, const Text& n_po) {
        auto&& acc_pm = std::get<0>(_p0);
        auto&& en_pn = std::get<1>(_p0);
        return ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> _v;
            auto&& _m = crate::prelude::get(env_p1.names_p, n_po);
            if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m))) {
                auto&& rs_pp = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                auto&& mode_pq = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a1;
                auto&& ct_pr = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                _v.set(({
                    auto d_ps = crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{capture_name_f(rs_pp)}), crate::lower::types::own_f(crate::lower::types::local_place_f(rs_pp, mode_pq, ct_pr))});
                    std::tuple{crate::prelude::push(acc_pm, d_ps), crate::lower::types::bind_f(en_pn, n_po, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{capture_name_f(rs_pp)}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), ct_pr}))};
                }));
                goto _done;
            }
            {
                _v.set(std::tuple{acc_pm, en_pn});
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto [again_p14, env_again_p15] = crate::prelude::fold(caps_p7, std::tuple{Array<crate::lower::model::Do>{}, env1_pu}, [&](const std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>& _p0, const Text& n_p11) {
        auto&& acc_pv = std::get<0>(_p0);
        auto&& en_p10 = std::get<1>(_p0);
        return ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> _v;
            auto&& _m = crate::prelude::get(prism_rtl::deref(env1_pu).names_p, n_p11);
            if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m))) {
                auto&& rs_p12 = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                auto&& ct_p13 = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                _v.set(std::tuple{crate::prelude::push(acc_pv, crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{copy_name_f(rs_p12)}), crate::lower::types::own_f(crate::lower::types::local_place_f(rs_p12, crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), ct_p13))})), crate::lower::types::bind_f(en_p10, n_p11, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{copy_name_f(rs_p12)}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), ct_p13}))});
                goto _done;
            }
            {
                _v.set(std::tuple{acc_pv, en_p10});
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto pts_p8 = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::lower::model::OutTy>> _v;
        if (prism_rtl::is<crate::lower::model::OutTy::OutTuple>(a_p5)) {
            auto&& ts_p16 = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(a_p5).a0;
            _v.set(crate::prelude::len(ps_p2) == Nat(1u) ? Array(std::vector{a_p5}) : ts_p16);
            goto _done;
        }
        {
            _v.set(Array(std::vector{a_p5}));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto env1b_p9 = only_captured_f(env_again_p15, caps_p7);
    auto pos_pa = crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(crate::prelude::len(ps_p2)), ({
        auto ps_p2x = ps_p2;
        auto lx_p0x = lx_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::patterns::PatOut>(Nat)>>(prism_rtl::rc([=, ps_p2x = std::move(ps_p2x), lx_p0x = std::move(lx_p0x)](Nat p0) {
        return ({
            auto ps_p2xy = ps_p2x;
            auto lx_p0xy = lx_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, ps_p2xy = std::move(ps_p2xy), lx_p0xy = std::move(lx_p0xy)]() {
            return ({
                auto i_p17 = p0;
                ({
                auto p_p18 = crate::prelude::or_(crate::prelude::index(ps_p2xy, i_p17), crate::lower::patterns::dummy_pat_p());
                (prism_rtl::more(prism_rtl::rc(crate::lower::patterns::RustPat(lx_p0xy, p_p18, binder_ty_of_pattern_f(lx_p0xy, p_p18), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat("p", i_p17, "_")))));
            });
            });
        })));
        });
    })));
    })));
    auto unpack_pb = crate::prelude::fold(crate::check::errors::range0_f(crate::prelude::len(pos_pa)), Array<crate::lower::model::Do>{}, [&](const Array<crate::lower::model::Do>& acc_p19, const Nat& i_p1a) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::lower::model::Do>> _v;
            auto&& _m = crate::prelude::index(pos_pa, i_p1a);
            if (prism_rtl::is_some(_m)) {
                auto&& po_p1b = prism_rtl::some_of(_m);
                _v.set(crate::prelude::append(crate::prelude::push(acc_p19, crate::lower::model::Do(crate::lower::model::Do::DoLet{prism_rtl::deref(po_p1b).pa_p, crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat("p", i_p1a)})})), crate::prelude::each(prism_rtl::deref(po_p1b).conds_p, [&](const crate::lower::model::Cc& c_p1c) { return cond_as_let_f(c_p1c); })));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(acc_p19);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
    auto pos2_pc = crate::prelude::each(crate::check::errors::range0_f(crate::prelude::len(pos_pa)), [&](const Nat& i_p1d) {
        return ({
            __label__ _done;
            prism_rtl::Slot<crate::lower::patterns::PatOut> _v;
            auto&& _m = crate::prelude::index(pos_pa, i_p1d);
            if (prism_rtl::is_some(_m)) {
                auto&& po_p1e = prism_rtl::some_of(_m);
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<crate::lower::patterns::PatOut> _v;
                    auto&& _m = prism_rtl::deref(prism_rtl::deref(crate::prelude::or_(crate::prelude::index(ps_p2, i_p1d), crate::lower::patterns::dummy_pat_p())).kind_p);
                    if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
                        _v.set(({
                            crate::lower::patterns::PatOut this_ = po_p1e;
                            this_.binds_p = crate::prelude::each(this_.binds_p, [&](const std::tuple<Text, crate::lower::types::Bn>& _p0) {
                                auto&& n_p1f = std::get<0>(_p0);
                                auto&& b_p1g = std::get<1>(_p0);
                                return ({
                                    __label__ _done;
                                    prism_rtl::Slot<std::tuple<Text, crate::lower::types::Bn>> _v;
                                    if (prism_rtl::is<crate::lower::types::Bn::BnLocal>(b_p1g)) {
                                        auto&& rs_p1h = prism_rtl::as<crate::lower::types::Bn::BnLocal>(b_p1g).a0;
                                        auto&& mode_p1i = prism_rtl::as<crate::lower::types::Bn::BnLocal>(b_p1g).a1;
                                        auto&& bt_p1j = prism_rtl::as<crate::lower::types::Bn::BnLocal>(b_p1g).a2;
                                        _v.set(std::tuple{n_p1f, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{rs_p1h, mode_p1i, crate::prelude::or_(crate::prelude::index(pts_p8, i_p1d), bt_p1j)})});
                                        goto _done;
                                    }
                                    {
                                        _v.set(std::tuple{n_p1f, b_p1g});
                                        goto _done;
                                    }
                                _done:
                                    _v.take();
                                });
                            });
                            (std::move(this_));
                        }));
                        goto _done;
                    }
                    {
                        _v.set(po_p1e);
                        goto _done;
                    }
                _done:
                    _v.take();
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(crate::lower::patterns::PatOut{.pa_p = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds_p = Array<crate::lower::model::Cc>{}, .binds_p = Array<std::tuple<Text, crate::lower::types::Bn>>{}});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
    auto env2_pd = crate::prelude::fold(pos2_pc, env1b_p9, [&](const crate::lower::types::Env& en_p1k, const crate::lower::patterns::PatOut& po_p1l) { return bind_all_f(en_p1k, prism_rtl::deref(po_p1l).binds_p); });
    auto names_pe = crate::prelude::each(crate::check::errors::range0_f(crate::prelude::len(ps_p2)), [&](const Nat& i_p1m) { return prism_rtl::cat("p", i_p1m); });
    auto pa_pf = crate::prelude::len(ps_p2) == Nat(1u)
        ? crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("p0")})), a_p5})
        : crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{crate::prelude::each(names_pe, [&](const Text& nm_p1n) { return crate::lower::model::Pa(crate::lower::model::Pa::PaBind{nm_p1n}); })})), a_p5});
    auto tail0_pg = ({
        __label__ _done;
        prism_rtl::Slot<crate::lower::model::Ex> _v;
        if (prism_rtl::is<crate::syntax::LambdaBody::LbExpr>(body_p3)) {
            auto&& x_p1o = prism_rtl::as<crate::syntax::LambdaBody::LbExpr>(body_p3).a0;
            _v.set(crate::lower::jobs::tail_f(lx_p0, env2_pd, prism_rtl::deref(prism_rtl::deref(x_p1o))));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::LambdaBody::LbBlock>(body_p3)) {
            auto&& bl_p1p = prism_rtl::as<crate::syntax::LambdaBody::LbBlock>(body_p3).a0;
            _v.set(crate::lower::jobs::tail_block_f(lx_p0, env2_pd, bl_p1p));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto tail_ph = crate::prelude::len(unpack_pb) == Nat(0u)
        ? tail0_pg
        : crate::lower::model::Ex(crate::lower::model::Ex::XBlock{unpack_pb, prism_rtl::rc(tail0_pg)});
    auto job0_pi = crate::lower::model::Ex(crate::lower::model::Ex::XCall{crate::lower::helper_f(Text::lit("once_job")), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array<crate::lower::model::Pa>{}, prism_rtl::rc(tail_ph)})})});
    auto job_pj = enter_p6
        ? crate::lower::model::Ex(crate::lower::model::Ex::XCall{crate::lower::helper_f(Text::lit("entered")), Array(std::vector{job0_pi})})
        : job0_pi;
    auto call_pk = crate::prelude::len(again_p14) == Nat(0u)
        ? job_pj
        : crate::lower::model::Ex(crate::lower::model::Ex::XBlock{again_p14, prism_rtl::rc(job_pj)});
    return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBlock{dos_pt, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCast{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{pa_pf}), prism_rtl::rc(call_pk)})})})), ft_p4}))}), ft_p4});
}


prism_rtl::Turn<crate::lower::types::Vl> JobLambda::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& ps_p2 = this->ps_p2;
    const auto& body_p3 = this->body_p3;
    const auto& ft_p4 = this->ft_p4;
    const auto& a_p5 = this->a_p5;
    const auto& enter_p6 = this->enter_p6;
    auto a_p5x = a_p5;
    auto body_p3x = body_p3;
    auto enter_p6x = prism_rtl::deref(enter_p6);
    auto env_p1x = env_p1;
    auto ft_p4x = ft_p4;
    auto lx_p0x = lx_p0;
    auto ps_p2x = ps_p2;
    return crate::prelude::call_then(start_lambda_reads_f(ps_p2x, body_p3x), [=](Array<Text> lambda_reads_f_61473) {
        return ({
            auto caps_p7 = crate::prelude::filter(crate::lower::types::with_instances_f(env_p1x, lambda_reads_f_61473), [&](const Text& n_pl) {
                return ({
                    __label__ _done;
                    prism_rtl::Slot<bool> _v;
                    auto&& _m = crate::prelude::get(prism_rtl::deref(env_p1x).names_p, n_pl);
                    if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m))) {
                        _v.set(true);
                        goto _done;
                    }
                    {
                        _v.set(false);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
            });
            auto [dos_pt, env1_pu] = crate::prelude::fold(caps_p7, std::tuple{Array<crate::lower::model::Do>{}, env_p1x}, [&](const std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>& _p0, const Text& n_po) {
                auto&& acc_pm = std::get<0>(_p0);
                auto&& en_pn = std::get<1>(_p0);
                return ({
                    __label__ _done;
                    prism_rtl::Slot<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> _v;
                    auto&& _m = crate::prelude::get(prism_rtl::deref(env_p1x).names_p, n_po);
                    if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m))) {
                        auto&& rs_pp = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                        auto&& mode_pq = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a1;
                        auto&& ct_pr = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                        _v.set(({
                            auto d_ps = crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{capture_name_f(rs_pp)}), crate::lower::types::own_f(crate::lower::types::local_place_f(rs_pp, mode_pq, ct_pr))});
                            std::tuple{crate::prelude::push(acc_pm, d_ps), crate::lower::types::bind_f(en_pn, n_po, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{capture_name_f(rs_pp)}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), ct_pr}))};
                        }));
                        goto _done;
                    }
                    {
                        _v.set(std::tuple{acc_pm, en_pn});
                        goto _done;
                    }
                _done:
                    _v.take();
                });
            });
            auto [again_p14, env_again_p15] = crate::prelude::fold(caps_p7, std::tuple{Array<crate::lower::model::Do>{}, env1_pu}, [&](const std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>& _p0, const Text& n_p11) {
                auto&& acc_pv = std::get<0>(_p0);
                auto&& en_p10 = std::get<1>(_p0);
                return ({
                    __label__ _done;
                    prism_rtl::Slot<std::tuple<Array<crate::lower::model::Do>, crate::lower::types::Env>> _v;
                    auto&& _m = crate::prelude::get(prism_rtl::deref(env1_pu).names_p, n_p11);
                    if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m))) {
                        auto&& rs_p12 = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                        auto&& ct_p13 = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                        _v.set(std::tuple{crate::prelude::push(acc_pv, crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{copy_name_f(rs_p12)}), crate::lower::types::own_f(crate::lower::types::local_place_f(rs_p12, crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), ct_p13))})), crate::lower::types::bind_f(en_p10, n_p11, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{copy_name_f(rs_p12)}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), ct_p13}))});
                        goto _done;
                    }
                    {
                        _v.set(std::tuple{acc_pv, en_p10});
                        goto _done;
                    }
                _done:
                    _v.take();
                });
            });
            auto pts_p8 = ({
                __label__ _done;
                prism_rtl::Slot<Array<crate::lower::model::OutTy>> _v;
                if (prism_rtl::is<crate::lower::model::OutTy::OutTuple>(a_p5x)) {
                    auto&& ts_p16 = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(a_p5x).a0;
                    _v.set(crate::prelude::len(ps_p2x) == Nat(1u) ? Array(std::vector{a_p5x}) : ts_p16);
                    goto _done;
                }
                {
                    _v.set(Array(std::vector{a_p5x}));
                    goto _done;
                }
            _done:
                _v.take();
            });
            auto env1b_p9 = only_captured_f(env_again_p15, caps_p7);
            (crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(crate::prelude::len(ps_p2x)), ({
            auto ps_p2xx = ps_p2x;
            auto lx_p0xx = lx_p0x;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::patterns::PatOut>(Nat)>>(prism_rtl::rc([=, ps_p2xx = std::move(ps_p2xx), lx_p0xx = std::move(lx_p0xx)](Nat p0) {
            return ({
                auto ps_p2xxy = ps_p2xx;
                auto lx_p0xxy = lx_p0xx;
                (crate::prelude::entered(crate::prelude::once_job([=, ps_p2xxy = std::move(ps_p2xxy), lx_p0xxy = std::move(lx_p0xxy)]() {
                return ({
                    auto i_p17 = p0;
                    ({
                    auto p_p18 = crate::prelude::or_(crate::prelude::index(ps_p2xxy, i_p17), crate::lower::patterns::dummy_pat_p());
                    (prism_rtl::more(prism_rtl::rc(crate::lower::patterns::RustPat(lx_p0xxy, p_p18, binder_ty_of_pattern_f(lx_p0xxy, p_p18), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), prism_rtl::cat("p", i_p17, "_")))));
                });
                });
            })));
            });
        })));
        })), [=, pts_p8 = std::move(pts_p8), env1b_p9 = std::move(env1b_p9)](Array<crate::lower::patterns::PatOut> each_62690) {
            return ({
                auto pos_pa = each_62690;
                auto unpack_pb = crate::prelude::fold(crate::check::errors::range0_f(crate::prelude::len(pos_pa)), Array<crate::lower::model::Do>{}, [&](const Array<crate::lower::model::Do>& acc_p19, const Nat& i_p1a) {
                    return ({
                        __label__ _done;
                        prism_rtl::Slot<Array<crate::lower::model::Do>> _v;
                        auto&& _m = crate::prelude::index(pos_pa, i_p1a);
                        if (prism_rtl::is_some(_m)) {
                            auto&& po_p1b = prism_rtl::some_of(_m);
                            _v.set(crate::prelude::append(crate::prelude::push(acc_p19, crate::lower::model::Do(crate::lower::model::Do::DoLet{prism_rtl::deref(po_p1b).pa_p, crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat("p", i_p1a)})})), crate::prelude::each(prism_rtl::deref(po_p1b).conds_p, [&](const crate::lower::model::Cc& c_p1c) { return cond_as_let_f(c_p1c); })));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(acc_p19);
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                });
                auto pos2_pc = crate::prelude::each(crate::check::errors::range0_f(crate::prelude::len(pos_pa)), [&](const Nat& i_p1d) {
                    return ({
                        __label__ _done;
                        prism_rtl::Slot<crate::lower::patterns::PatOut> _v;
                        auto&& _m = crate::prelude::index(pos_pa, i_p1d);
                        if (prism_rtl::is_some(_m)) {
                            auto&& po_p1e = prism_rtl::some_of(_m);
                            _v.set(({
                                __label__ _done;
                                prism_rtl::Slot<crate::lower::patterns::PatOut> _v;
                                auto&& _m = prism_rtl::deref(prism_rtl::deref(crate::prelude::or_(crate::prelude::index(ps_p2x, i_p1d), crate::lower::patterns::dummy_pat_p())).kind_p);
                                if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
                                    _v.set(({
                                        crate::lower::patterns::PatOut this_ = po_p1e;
                                        this_.binds_p = crate::prelude::each(this_.binds_p, [&](const std::tuple<Text, crate::lower::types::Bn>& _p0) {
                                            auto&& n_p1f = std::get<0>(_p0);
                                            auto&& b_p1g = std::get<1>(_p0);
                                            return ({
                                                __label__ _done;
                                                prism_rtl::Slot<std::tuple<Text, crate::lower::types::Bn>> _v;
                                                if (prism_rtl::is<crate::lower::types::Bn::BnLocal>(b_p1g)) {
                                                    auto&& rs_p1h = prism_rtl::as<crate::lower::types::Bn::BnLocal>(b_p1g).a0;
                                                    auto&& mode_p1i = prism_rtl::as<crate::lower::types::Bn::BnLocal>(b_p1g).a1;
                                                    auto&& bt_p1j = prism_rtl::as<crate::lower::types::Bn::BnLocal>(b_p1g).a2;
                                                    _v.set(std::tuple{n_p1f, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{rs_p1h, mode_p1i, crate::prelude::or_(crate::prelude::index(pts_p8, i_p1d), bt_p1j)})});
                                                    goto _done;
                                                }
                                                {
                                                    _v.set(std::tuple{n_p1f, b_p1g});
                                                    goto _done;
                                                }
                                            _done:
                                                _v.take();
                                            });
                                        });
                                        (std::move(this_));
                                    }));
                                    goto _done;
                                }
                                {
                                    _v.set(po_p1e);
                                    goto _done;
                                }
                            _done:
                                _v.take();
                            }));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(crate::lower::patterns::PatOut{.pa_p = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds_p = Array<crate::lower::model::Cc>{}, .binds_p = Array<std::tuple<Text, crate::lower::types::Bn>>{}});
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                });
                auto env2_pd = crate::prelude::fold(pos2_pc, env1b_p9, [&](const crate::lower::types::Env& en_p1k, const crate::lower::patterns::PatOut& po_p1l) { return bind_all_f(en_p1k, prism_rtl::deref(po_p1l).binds_p); });
                auto names_pe = crate::prelude::each(crate::check::errors::range0_f(crate::prelude::len(ps_p2x)), [&](const Nat& i_p1m) { return prism_rtl::cat("p", i_p1m); });
                auto pa_pf = crate::prelude::len(ps_p2x) == Nat(1u)
                    ? crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("p0")})), a_p5x})
                    : crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{crate::prelude::each(names_pe, [&](const Text& nm_p1n) { return crate::lower::model::Pa(crate::lower::model::Pa::PaBind{nm_p1n}); })})), a_p5x});
                auto tail0_pg = ({
                    __label__ _done;
                    prism_rtl::Slot<crate::lower::model::Ex> _v;
                    if (prism_rtl::is<crate::syntax::LambdaBody::LbExpr>(body_p3x)) {
                        auto&& x_p1o = prism_rtl::as<crate::syntax::LambdaBody::LbExpr>(body_p3x).a0;
                        _v.set(crate::lower::jobs::tail_f(lx_p0x, env2_pd, prism_rtl::deref(prism_rtl::deref(x_p1o))));
                        goto _done;
                    }
                    if (prism_rtl::is<crate::syntax::LambdaBody::LbBlock>(body_p3x)) {
                        auto&& bl_p1p = prism_rtl::as<crate::syntax::LambdaBody::LbBlock>(body_p3x).a0;
                        _v.set(crate::lower::jobs::tail_block_f(lx_p0x, env2_pd, bl_p1p));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                auto tail_ph = crate::prelude::len(unpack_pb) == Nat(0u)
                    ? tail0_pg
                    : crate::lower::model::Ex(crate::lower::model::Ex::XBlock{unpack_pb, prism_rtl::rc(tail0_pg)});
                auto job0_pi = crate::lower::model::Ex(crate::lower::model::Ex::XCall{crate::lower::helper_f(Text::lit("once_job")), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array<crate::lower::model::Pa>{}, prism_rtl::rc(tail_ph)})})});
                auto job_pj = enter_p6x
                    ? crate::lower::model::Ex(crate::lower::model::Ex::XCall{crate::lower::helper_f(Text::lit("entered")), Array(std::vector{job0_pi})})
                    : job0_pi;
                auto call_pk = crate::prelude::len(again_p14) == Nat(0u)
                    ? job_pj
                    : crate::lower::model::Ex(crate::lower::model::Ex::XBlock{again_p14, prism_rtl::rc(job_pj)});
                (prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XBlock{dos_pt, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCast{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{true, Array(std::vector{pa_pf}), prism_rtl::rc(call_pk)})})})), ft_p4x}))}), ft_p4x})));
            });
        }));
        });
    });
}


/// `Start JobLambda, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_job_lambda_f(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, Array<crate::syntax::Pattern_> ps_p2, crate::syntax::LambdaBody body_p3, crate::lower::model::OutTy ft_p4, crate::lower::model::OutTy a_p5, bool enter_p6) {
    return prism_rtl::make_rc<JobLambda>(lx_p0, env_p1, ps_p2, body_p3, ft_p4, a_p5, enter_p6);
}


/// EntersLambda: fn Lx, Expr -> Bool
bool enters_lambda_f(const crate::lower::Lx& lx_p0, const crate::syntax::Expr& e_p1) {
    auto&& _m = crate::lower::types::peel_f(crate::lower::type_at_f(lx_p0, e_p1.span_p));
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m) && prism_rtl::is<crate::check::types::Col::CBound>(prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a0)) {
        return false;
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
        return true;
    }
    {
        return false;
    }
}


/// OnlyCaptured: fn Env, [Text] -> Env
crate::lower::types::Env only_captured_f(const crate::lower::types::Env& env_p0, const Array<Text>& caps_p1) {
    crate::lower::types::Env this_ = env_p0;
    this_.names_p = crate::prelude::fold(crate::prelude::keys(env_p0.names_p), Map<Text, crate::lower::types::Bn>{}, [&](const Map<Text, crate::lower::types::Bn>& m_p2, const Text& k_p3) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Map<Text, crate::lower::types::Bn>> _v;
            auto&& _m = crate::prelude::get(env_p0.names_p, k_p3);
            if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m))) {
                auto&& rs_p4 = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                auto&& mode_p5 = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a1;
                auto&& t_p6 = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                _v.set(crate::check::types::has_text_f(caps_p1, k_p3) || (mode_p5 == crate::lower::types::Holding(crate::lower::types::Holding::Owned{}))
                    ? crate::prelude::insert(m_p2, k_p3, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{rs_p4, mode_p5, t_p6}))
                    : m_p2);
                goto _done;
            }
            if (prism_rtl::is_some(_m)) {
                auto&& b_p7 = prism_rtl::some_of(_m);
                _v.set(crate::prelude::insert(m_p2, k_p3, b_p7));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(m_p2);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
    return this_;
}


/// CondAsLet: fn Cc -> Do
crate::lower::model::Do cond_as_let_f(const crate::lower::model::Cc& cc0) {
    if (prism_rtl::is<crate::lower::model::Cc::CcLet>(cc0)) {
        auto&& pa_p0 = prism_rtl::as<crate::lower::model::Cc::CcLet>(cc0).a0;
        auto&& x_p1 = prism_rtl::as<crate::lower::model::Cc::CcLet>(cc0).a1;
        return crate::lower::model::Do(crate::lower::model::Do::DoLet{pa_p0, x_p1});
    }
    if (prism_rtl::is<crate::lower::model::Cc::CcIf>(cc0)) {
        auto&& x_p2 = prism_rtl::as<crate::lower::model::Cc::CcIf>(cc0).a0;
        return crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{})});
    }
    prism_rtl::unreachable("no arm matched");
}


/// LambdaArg: unbounded fn Lx, Env, [Pattern], LambdaBody, [OutTy] -> Ex
crate::lower::model::Ex lambda_arg_f(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const Array<crate::syntax::Pattern_>& ps_p2, const crate::syntax::LambdaBody& body_p3, const Array<crate::lower::model::OutTy>& pts_p4) {
    auto [pas_p6, env2_p7] = closure_params_f(lx_p0, env_p1, ps_p2, pts_p4, crate::prelude::len(pts_p4) > Nat(0u));
    auto v_p5 = lambda_body_value_f(lx_p0, env2_p7, body_p3);
    return crate::lower::model::Ex(crate::lower::model::Ex::XClosure{false, pas_p6, prism_rtl::rc(crate::lower::types::own_f(v_p5))});
}


prism_rtl::Turn<crate::lower::model::Ex> LambdaArg::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& ps_p2 = this->ps_p2;
    const auto& body_p3 = this->body_p3;
    const auto& pts_p4 = this->pts_p4;
    auto body_p3x = body_p3;
    auto env_p1x = env_p1;
    auto lx_p0x = lx_p0;
    auto ps_p2x = ps_p2;
    auto pts_p4x = pts_p4;
    return crate::prelude::call_then(start_closure_params_f(lx_p0x, env_p1x, ps_p2x, pts_p4x, crate::prelude::len(pts_p4x) > Nat(0u)), [=](std::tuple<Array<crate::lower::model::Pa>, crate::lower::types::Env> closure_params_f_65448) {
        return ({
            auto [pas_p6, env2_p7] = closure_params_f_65448;
            (crate::prelude::call_then(start_lambda_body_value_f(lx_p0x, env2_p7, body_p3x), [=](crate::lower::types::Vl lambda_body_value_f_65506) {
            return ({
                auto v_p5 = lambda_body_value_f_65506;
                (prism_rtl::finished(crate::lower::model::Ex(crate::lower::model::Ex::XClosure{false, pas_p6, prism_rtl::rc(crate::lower::types::own_f(v_p5))})));
            });
        }));
        });
    });
}


/// `Start LambdaArg, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Ex> start_lambda_arg_f(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, Array<crate::syntax::Pattern_> ps_p2, crate::syntax::LambdaBody body_p3, Array<crate::lower::model::OutTy> pts_p4) {
    return prism_rtl::make_rc<LambdaArg>(lx_p0, env_p1, ps_p2, body_p3, pts_p4);
}


/// LambdaBodyValue: unbounded fn Lx, Env, LambdaBody -> Vl
crate::lower::types::Vl lambda_body_value_f(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::LambdaBody& lambda_body2) {
    if (prism_rtl::is<crate::syntax::LambdaBody::LbExpr>(lambda_body2)) {
        auto&& x_p2 = prism_rtl::as<crate::syntax::LambdaBody::LbExpr>(lambda_body2).a0;
        return value_of_f(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(x_p2)));
    }
    if (prism_rtl::is<crate::syntax::LambdaBody::LbBlock>(lambda_body2)) {
        auto&& b_p5 = prism_rtl::as<crate::syntax::LambdaBody::LbBlock>(lambda_body2).a0;
        return block_value_f(lx_p0, env_p1, b_p5);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::lower::types::Vl> LambdaBodyValue::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& lambda_body2 = this->lambda_body2;
    return ({
        prism_rtl::is<crate::syntax::LambdaBody::LbExpr>(lambda_body2) ? ({
        auto&& x_p2 = prism_rtl::as<crate::syntax::LambdaBody::LbExpr>(lambda_body2).a0;
        prism_rtl::more(prism_rtl::rc(ValueOf(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(x_p2)))));
    })
        : prism_rtl::is<crate::syntax::LambdaBody::LbBlock>(lambda_body2) ? ({
        auto&& b_p5 = prism_rtl::as<crate::syntax::LambdaBody::LbBlock>(lambda_body2).a0;
        prism_rtl::more(prism_rtl::rc(BlockValue(lx_p0, env_p1, b_p5)));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start LambdaBodyValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_lambda_body_value_f(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::LambdaBody lambda_body2) {
    return prism_rtl::make_rc<LambdaBodyValue>(lx_p0, env_p1, lambda_body2);
}


/// ClosureParams: unbounded fn Lx, Env, [Pattern], [OutTy], Bool -> (([Pa], Env))
std::tuple<Array<crate::lower::model::Pa>, crate::lower::types::Env> closure_params_f(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const Array<crate::syntax::Pattern_>& ps_p2, const Array<crate::lower::model::OutTy>& pts_p3, const bool& typed_p4) {
    return crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(crate::prelude::len(ps_p2)), std::tuple{Array<crate::lower::model::Pa>{}, env_p1}, ({
        auto ps_p2x = ps_p2;
        auto lx_p0x = lx_p0;
        auto typed_p4x = typed_p4;
        auto pts_p3x = pts_p3;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::lower::model::Pa>, crate::lower::types::Env>>(std::tuple<std::tuple<Array<crate::lower::model::Pa>, crate::lower::types::Env>, Nat>)>>(prism_rtl::rc([=, ps_p2x = std::move(ps_p2x), lx_p0x = std::move(lx_p0x), typed_p4x = std::move(typed_p4x), pts_p3x = std::move(pts_p3x)](std::tuple<std::tuple<Array<crate::lower::model::Pa>, crate::lower::types::Env>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto ps_p2xy = ps_p2x;
            auto lx_p0xy = lx_p0x;
            auto typed_p4xy = typed_p4x;
            auto pts_p3xy = pts_p3x;
            (crate::prelude::entered(crate::prelude::once_job([=, ps_p2xy = std::move(ps_p2xy), lx_p0xy = std::move(lx_p0xy), typed_p4xy = std::move(typed_p4xy), pts_p3xy = std::move(pts_p3xy)]() {
            return ({
                auto [acc_p5, en_p6] = p0;
                auto i_p7 = p1;
                ({
                auto&& _m = crate::prelude::index(ps_p2xy, i_p7);
                prism_rtl::is_some(_m) ? ({
                auto&& p_p8 = prism_rtl::some_of(_m);
                crate::prelude::call_then(crate::lower::patterns::start_rust_pat_f(lx_p0xy, p_p8, binder_ty_of_pattern_f(lx_p0xy, p_p8), crate::lower::types::Holding(crate::lower::types::Holding::ByRef{}), prism_rtl::cat("a", prism_rtl::deref(prism_rtl::deref(p_p8).span_p).start_p)), [=](crate::lower::patterns::PatOut rust_pat_f_66069) {
                return ({
                    auto po_p9 = rust_pat_f_66069;
                    auto en2_pa = bind_all_f(en_p6, prism_rtl::deref(po_p9).binds_p);
                    auto pa_pb = typed_p4xy
                        ? crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(prism_rtl::deref(po_p9).pa_p), crate::lower::model::OutTy(crate::lower::model::OutTy::OutRef{prism_rtl::rc(crate::prelude::or_(crate::prelude::index(pts_p3xy, i_p7), crate::lower::model::OutTy(crate::lower::model::OutTy::OutRefused{Text::lit("a parameter")})))})})
                        : prism_rtl::deref(po_p9).pa_p;
                    (prism_rtl::finished(std::tuple{crate::prelude::push(acc_p5, pa_pb), en2_pa}));
                });
            });
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{acc_p5, en_p6})
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        })));
        });
    }));
    })));
}


prism_rtl::Turn<std::tuple<Array<crate::lower::model::Pa>, crate::lower::types::Env>> ClosureParams::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& ps_p2 = this->ps_p2;
    const auto& pts_p3 = this->pts_p3;
    const auto& typed_p4 = this->typed_p4;
    return crate::prelude::fold_job(crate::check::errors::range0_f(crate::prelude::len(ps_p2)), std::tuple{Array<crate::lower::model::Pa>{}, env_p1}, ({
        auto ps_p2x = ps_p2;
        auto lx_p0x = lx_p0;
        auto typed_p4x = prism_rtl::deref(typed_p4);
        auto pts_p3x = pts_p3;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::lower::model::Pa>, crate::lower::types::Env>>(std::tuple<std::tuple<Array<crate::lower::model::Pa>, crate::lower::types::Env>, Nat>)>>(prism_rtl::rc([=, ps_p2x = std::move(ps_p2x), lx_p0x = std::move(lx_p0x), typed_p4x = std::move(typed_p4x), pts_p3x = std::move(pts_p3x)](std::tuple<std::tuple<Array<crate::lower::model::Pa>, crate::lower::types::Env>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto ps_p2xy = ps_p2x;
            auto lx_p0xy = lx_p0x;
            auto typed_p4xy = typed_p4x;
            auto pts_p3xy = pts_p3x;
            (crate::prelude::entered(crate::prelude::once_job([=, ps_p2xy = std::move(ps_p2xy), lx_p0xy = std::move(lx_p0xy), typed_p4xy = std::move(typed_p4xy), pts_p3xy = std::move(pts_p3xy)]() {
            return ({
                auto [acc_p5, en_p6] = p0;
                auto i_p7 = p1;
                ({
                auto&& _m = crate::prelude::index(ps_p2xy, i_p7);
                prism_rtl::is_some(_m) ? ({
                auto&& p_p8 = prism_rtl::some_of(_m);
                crate::prelude::call_then(crate::lower::patterns::start_rust_pat_f(lx_p0xy, p_p8, binder_ty_of_pattern_f(lx_p0xy, p_p8), crate::lower::types::Holding(crate::lower::types::Holding::ByRef{}), prism_rtl::cat("a", prism_rtl::deref(prism_rtl::deref(p_p8).span_p).start_p)), [=](crate::lower::patterns::PatOut rust_pat_f_66069) {
                return ({
                    auto po_p9 = rust_pat_f_66069;
                    auto en2_pa = bind_all_f(en_p6, prism_rtl::deref(po_p9).binds_p);
                    auto pa_pb = typed_p4xy
                        ? crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(prism_rtl::deref(po_p9).pa_p), crate::lower::model::OutTy(crate::lower::model::OutTy::OutRef{prism_rtl::rc(crate::prelude::or_(crate::prelude::index(pts_p3xy, i_p7), crate::lower::model::OutTy(crate::lower::model::OutTy::OutRefused{Text::lit("a parameter")})))})})
                        : prism_rtl::deref(po_p9).pa_p;
                    (prism_rtl::finished(std::tuple{crate::prelude::push(acc_p5, pa_pb), en2_pa}));
                });
            });
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{acc_p5, en_p6})
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        })));
        });
    }));
    }))->cycle();
}


/// `Start ClosureParams, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::lower::model::Pa>, crate::lower::types::Env>> start_closure_params_f(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, Array<crate::syntax::Pattern_> ps_p2, Array<crate::lower::model::OutTy> pts_p3, bool typed_p4) {
    return prism_rtl::make_rc<ClosureParams>(lx_p0, env_p1, ps_p2, pts_p3, typed_p4);
}


/// BindAll: fn Env, [((Text, Bn))] -> Env
crate::lower::types::Env bind_all_f(const crate::lower::types::Env& env_p0, const Array<std::tuple<Text, crate::lower::types::Bn>>& bs_p1) {
    return crate::prelude::fold(bs_p1, env_p0, [&](const crate::lower::types::Env& en_p2, const std::tuple<Text, crate::lower::types::Bn>& _p1) {
        auto&& n_p3 = std::get<0>(_p1);
        auto&& b_p4 = std::get<1>(_p1);
        return crate::lower::types::bind_f(en_p2, n_p3, b_p4);
    });
}


/// BinderTyOfPattern: fn Lx, Pattern -> Ty
crate::check::types::Ty binder_ty_of_pattern_f(const crate::lower::Lx& lx_p0, const crate::syntax::Pattern_& p_p1) {
    auto&& _m = prism_rtl::deref(p_p1.kind_p);
    if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
        auto&& n_p2 = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        return crate::lower::binder_ty_f(lx_p0, prism_rtl::deref(n_p2).span_p);
    }
    {
        return crate::lower::type_at_f(lx_p0, p_p1.span_p);
    }
}


/// IfValue: unbounded fn Lx, Env, Cond, Block, ?Block, OutTy -> Vl
crate::lower::types::Vl if_value_f(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::Cond& c_p2, const crate::syntax::Block& then_b_p3, const std::optional<crate::syntax::Block>& else_b_o4, const crate::lower::model::OutTy& t_p5) {
    auto else_v_p6 = ({
        __label__ _done;
        prism_rtl::Slot<crate::lower::model::Ex> _v;
        if (prism_rtl::is_some(else_b_o4)) {
            auto&& b_p7 = prism_rtl::some_of(else_b_o4);
            _v.set(crate::lower::node_::def::own_as_f(t_p5, block_value_f(lx_p0, env_p1, b_p7)));
            goto _done;
        }
        if (prism_rtl::is_none(else_b_o4)) {
            _v.set(crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    if (prism_rtl::is<crate::syntax::Cond::CondExpr>(c_p2)) {
        auto&& x_p8 = prism_rtl::as<crate::syntax::Cond::CondExpr>(c_p2).a0;
        return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XIf{prism_rtl::rc(crate::lower::types::as_bool_f(value_of_f(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(x_p8))))), prism_rtl::rc(crate::lower::node_::def::own_as_f(t_p5, block_value_f(lx_p0, env_p1, then_b_p3))), prism_rtl::rc(else_v_p6)}), t_p5});
    }
    if (prism_rtl::is<crate::syntax::Cond::CondBind>(c_p2)) {
        auto&& p_p9 = prism_rtl::as<crate::syntax::Cond::CondBind>(c_p2).a0;
        auto&& x_pa = prism_rtl::as<crate::syntax::Cond::CondBind>(c_p2).a1;
        auto&& g_ob = prism_rtl::as<crate::syntax::Cond::CondBind>(c_p2).a2;
        auto sv_pc = value_of_f(lx_p0, env_p1, prism_rtl::deref(prism_rtl::deref(x_pa)));
        auto po_pd = crate::lower::patterns::rust_pat_f(lx_p0, p_p9, crate::lower::type_at_f(lx_p0, prism_rtl::deref(x_pa).span_p), crate::lower::types::Holding(crate::lower::types::Holding::ByRef{}), prism_rtl::cat("c", prism_rtl::deref(prism_rtl::deref(x_pa).span_p).start_p));
        auto env2_pe = bind_all_f(env_p1, prism_rtl::deref(po_pd).binds_p);
        auto guard_pf = ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::lower::model::Cc>> _v;
            auto&& _m = prism_rtl::deref(prism_rtl::deref(g_ob));
            if (prism_rtl::is_some(_m)) {
                auto&& ge_pi = prism_rtl::some_of(_m);
                _v.set(Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::types::as_bool_f(value_of_f(lx_p0, env2_pe, ge_pi))})}));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(Array<crate::lower::model::Cc>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto arm_pg = crate::lower::model::XArm{.pat_p = prism_rtl::deref(po_pd).pa_p, .conds_p = crate::prelude::append(prism_rtl::deref(po_pd).conds_p, guard_pf), .body_p = crate::lower::node_::def::own_as_f(t_p5, block_value_f(lx_p0, env2_pe, then_b_p3))};
        auto other_ph = crate::lower::model::XArm{.pat_p = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds_p = Array<crate::lower::model::Cc>{}, .body_p = else_v_p6};
        return arms_value_f(crate::lower::types::ref_f(sv_pc), Array(std::vector{arm_pg, other_ph}), prism_rtl::cat("c", prism_rtl::deref(prism_rtl::deref(x_pa).span_p).start_p), t_p5);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::lower::types::Vl> IfValue::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& c_p2 = this->c_p2;
    const auto& then_b_p3 = this->then_b_p3;
    const auto& else_b_o4 = this->else_b_o4;
    const auto& t_p5 = this->t_p5;
    auto else_v_p6 = ({
        __label__ _done;
        prism_rtl::Slot<crate::lower::model::Ex> _v;
        if (prism_rtl::is_some(else_b_o4)) {
            auto&& b_p7 = prism_rtl::some_of(else_b_o4);
            _v.set(crate::lower::node_::def::own_as_f(t_p5, block_value_f(lx_p0, env_p1, b_p7)));
            goto _done;
        }
        if (prism_rtl::is_none(else_b_o4)) {
            _v.set(crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return ({
        prism_rtl::is<crate::syntax::Cond::CondExpr>(c_p2) ? ({
        auto&& x_p8 = prism_rtl::as<crate::syntax::Cond::CondExpr>(c_p2).a0;
        ({
        auto env_p1x = env_p1;
        auto lx_p0x = lx_p0;
        auto t_p5x = t_p5;
        auto then_b_p3x = then_b_p3;
        auto x_p8x = prism_rtl::deref(prism_rtl::deref(x_p8));
        (crate::prelude::call_then(start_value_of_f(lx_p0x, env_p1x, x_p8x), [=, t_p5x = std::move(t_p5x), then_b_p3x = std::move(then_b_p3x)](crate::lower::types::Vl value_of_f_66975) { return crate::prelude::call_then(start_block_value_f(lx_p0x, env_p1x, then_b_p3x), [=](crate::lower::types::Vl block_value_f_67008) { return prism_rtl::finished(crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XIf{prism_rtl::rc(crate::lower::types::as_bool_f(value_of_f_66975)), prism_rtl::rc(crate::lower::node_::def::own_as_f(t_p5x, block_value_f_67008)), prism_rtl::rc(else_v_p6)}), t_p5x})); }); }));
    });
    })
        : prism_rtl::is<crate::syntax::Cond::CondBind>(c_p2) ? ({
        auto&& p_p9 = prism_rtl::as<crate::syntax::Cond::CondBind>(c_p2).a0;
        auto&& x_pa = prism_rtl::as<crate::syntax::Cond::CondBind>(c_p2).a1;
        auto&& g_ob = prism_rtl::as<crate::syntax::Cond::CondBind>(c_p2).a2;
        ({
        auto g_obx = prism_rtl::deref(prism_rtl::deref(g_ob));
        auto c_p2x = c_p2;
        auto env_p1x = env_p1;
        auto lx_p0x = lx_p0;
        auto p_p9x = p_p9;
        auto t_p5x = t_p5;
        auto then_b_p3x = then_b_p3;
        auto x_pax = prism_rtl::deref(prism_rtl::deref(x_pa));
        (crate::prelude::call_then(start_value_of_f(lx_p0x, env_p1x, x_pax), [=, g_obx = std::move(g_obx), p_p9x = std::move(p_p9x), t_p5x = std::move(t_p5x), then_b_p3x = std::move(then_b_p3x)](crate::lower::types::Vl value_of_f_67095) {
        return ({
            auto sv_pc = value_of_f_67095;
            (crate::prelude::call_then(crate::lower::patterns::start_rust_pat_f(lx_p0x, p_p9x, crate::lower::type_at_f(lx_p0x, prism_rtl::deref(x_pax).span_p), crate::lower::types::Holding(crate::lower::types::Holding::ByRef{}), prism_rtl::cat("c", prism_rtl::deref(prism_rtl::deref(x_pax).span_p).start_p)), [=, sv_pc = std::move(sv_pc)](crate::lower::patterns::PatOut rust_pat_f_67135) {
            return ({
                auto po_pd = rust_pat_f_67135;
                auto env2_pe = bind_all_f(env_p1x, prism_rtl::deref(po_pd).binds_p);
                auto guard_pf = ({
                    __label__ _done;
                    prism_rtl::Slot<Array<crate::lower::model::Cc>> _v;
                    if (prism_rtl::is_some(g_obx)) {
                        auto&& ge_pi = prism_rtl::some_of(g_obx);
                        _v.set(Array(std::vector{crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::types::as_bool_f(value_of_f(lx_p0x, env2_pe, ge_pi))})}));
                        goto _done;
                    }
                    if (prism_rtl::is_none(g_obx)) {
                        _v.set(Array<crate::lower::model::Cc>{});
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                (crate::prelude::call_then(start_block_value_f(lx_p0x, env2_pe, then_b_p3x), [=, po_pd = std::move(po_pd), guard_pf = std::move(guard_pf)](crate::lower::types::Vl block_value_f_67450) {
                return ({
                    auto arm_pg = crate::lower::model::XArm{.pat_p = prism_rtl::deref(po_pd).pa_p, .conds_p = crate::prelude::append(prism_rtl::deref(po_pd).conds_p, guard_pf), .body_p = crate::lower::node_::def::own_as_f(t_p5x, block_value_f_67450)};
                    auto other_ph = crate::lower::model::XArm{.pat_p = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds_p = Array<crate::lower::model::Cc>{}, .body_p = else_v_p6};
                    (prism_rtl::finished(arms_value_f(crate::lower::types::ref_f(sv_pc), Array(std::vector{arm_pg, other_ph}), prism_rtl::cat("c", prism_rtl::deref(prism_rtl::deref(x_pax).span_p).start_p), t_p5x)));
                });
            }));
            });
        }));
        });
    }));
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start IfValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::types::Vl> start_if_value_f(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::Cond c_p2, crate::syntax::Block then_b_p3, std::optional<crate::syntax::Block> else_b_o4, crate::lower::model::OutTy t_p5) {
    return prism_rtl::make_rc<IfValue>(lx_p0, env_p1, c_p2, then_b_p3, else_b_o4, t_p5);
}


/// ArmsValue: fn Ex, [XArm], Text, OutTy -> Vl
crate::lower::types::Vl arms_value_f(const crate::lower::model::Ex& scrut_p0, const Array<crate::lower::model::XArm>& arms_p1, const Text& label_p2, const crate::lower::model::OutTy& t_p3) {
    auto chain_p4 = crate::prelude::fold(arms_p1, false, [&](const bool& f_p6, const crate::lower::model::XArm& a_p7) { return prism_rtl::deref(f_p6) || crate::prelude::fold(prism_rtl::deref(a_p7).conds_p, false, [&](const bool& f2_p8, const crate::lower::model::Cc& c_p9) { return prism_rtl::deref(f2_p8) || is_let_cond_f(c_p9); }); });
    auto guarded_p5 = crate::prelude::fold(arms_p1, false, [&](const bool& f_pa, const crate::lower::model::XArm& a_pb) { return prism_rtl::deref(f_pa) || (crate::prelude::len(prism_rtl::deref(a_pb).conds_p) > Nat(0u)); });
    return std::move(chain_p4)
        ? crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XChain{label_p2, prism_rtl::rc(scrut_p0), arms_p1, t_p3}), t_p3})
        : crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{crate::lower::model::Ex(crate::lower::model::Ex::XMatch{prism_rtl::rc(scrut_p0), arms_p1, std::move(guarded_p5), t_p3}), t_p3});
}

}  // namespace crate::lower::expr
