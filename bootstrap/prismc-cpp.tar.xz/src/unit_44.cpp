// The modules `Lower.Node.Dynamics`, `Lower.Node.Elements`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <lower/node_/dynamics/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Lower.Node.Dynamics`, from `target/bootstrap/cpp-src/prismc/lower/node/dynamics.prism`.
namespace crate::lower::node_::dynamics {

/// DynamicExpr: unbounded fn Wx, Env, Expr -> ((Ex, [Read]))
std::tuple<crate::lower::model::Ex, Array<crate::lower::node_::Read>> dynamic_expr(const crate::lower::node_::Wx& wx, const crate::lower::types::Env& menv, const crate::syntax::Expr& e) {
    auto v_ = crate::lower::expr::value_of(wx.lx, menv, e);
    auto reads = fold(crate::check::typed::print::exprs_in(e), Array<crate::lower::node_::Read>{}, [&](const Array<crate::lower::node_::Read>& acc, const crate::syntax::Expr& x) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::lower::node_::Read>> _v;
            auto&& _m = prism_rtl::deref(prism_rtl::deref(x).kind);
            if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
                auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Array<crate::lower::node_::Read>> _v;
                    auto&& _m = crate::prelude::get(menv.names, crate::check::env::sname_key(n));
                    if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnHold>(prism_rtl::some_of(_m))) {
                        auto&& f = prism_rtl::as<crate::lower::types::Bn::BnHold>(prism_rtl::some_of(_m)).a0;
                        _v.set(crate::lower::node_::add_read(acc, crate::lower::node_::Read(crate::lower::node_::Read::OwnRead{f})));
                        goto _done;
                    }
                    if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m))) {
                        auto&& rs = prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)).a1;
                        _v.set(crate::lower::node_::union_reads(acc, rs));
                        goto _done;
                    }
                    {
                        _v.set(acc);
                        goto _done;
                    }
                _done:
                    _v.take();
                }));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    return std::tuple{crate::lower::types::own(v_), reads};
}


prism_rtl::Turn<std::tuple<crate::lower::model::Ex, Array<crate::lower::node_::Read>>> DynamicExpr::cycle() const {
    const auto& wx = this->wx;
    const auto& menv = this->menv;
    const auto& e = this->e;
    auto e_1 = e;
    auto menv_2 = menv;
    auto wx_3 = wx;
    return call_then(crate::lower::expr::start_value_of(prism_rtl::deref(wx_3).lx, menv_2, e_1), [=](crate::lower::types::Vl value_of_1581) {
        return ({
            auto v_ = value_of_1581;
            call_then(crate::check::typed::print::start_exprs_in(e_1), [=, v_ = std::move(v_)](Array<crate::syntax::Expr> exprs_in_1626) {
            return ({
                auto reads = fold(exprs_in_1626, Array<crate::lower::node_::Read>{}, [&](const Array<crate::lower::node_::Read>& acc, const crate::syntax::Expr& x) {
                    return ({
                        __label__ _done;
                        prism_rtl::Slot<Array<crate::lower::node_::Read>> _v;
                        auto&& _m = prism_rtl::deref(prism_rtl::deref(x).kind);
                        if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
                            auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
                            _v.set(({
                                __label__ _done;
                                prism_rtl::Slot<Array<crate::lower::node_::Read>> _v;
                                auto&& _m = crate::prelude::get(menv_2->names, crate::check::env::sname_key(n));
                                if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnHold>(prism_rtl::some_of(_m))) {
                                    auto&& f = prism_rtl::as<crate::lower::types::Bn::BnHold>(prism_rtl::some_of(_m)).a0;
                                    _v.set(crate::lower::node_::add_read(acc, crate::lower::node_::Read(crate::lower::node_::Read::OwnRead{f})));
                                    goto _done;
                                }
                                if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m))) {
                                    auto&& rs = prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)).a1;
                                    _v.set(crate::lower::node_::union_reads(acc, rs));
                                    goto _done;
                                }
                                {
                                    _v.set(acc);
                                    goto _done;
                                }
                            _done:
                                _v.take();
                            }));
                            goto _done;
                        }
                        {
                            _v.set(acc);
                            goto _done;
                        }
                    _done:
                        _v.take();
                    });
                });
                (prism_rtl::finished(std::tuple{crate::lower::types::own(v_), reads}));
            });
        });
        });
    });
}


/// `Start DynamicExpr, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::lower::model::Ex, Array<crate::lower::node_::Read>>> start_dynamic_expr(crate::lower::node_::Wx wx, crate::lower::types::Env menv, crate::syntax::Expr e) {
    return prism_rtl::make_rc<DynamicExpr>(wx, menv, e);
}


/// NeverEvent: fn Wx, OutTy -> ((EvRef, Wx))
std::tuple<crate::lower::node_::EvRef, crate::lower::node_::Wx> never_event_(const crate::lower::node_::Wx& wx, const crate::lower::model::OutTy& t) {
    auto [id, wx2] = crate::lower::node_::add_gn(wx, Text::lit("never"), t, crate::lower::node_::GnKind(crate::lower::node_::GnKind::GnNever{}), Nat(0u));
    return std::tuple{crate::lower::node_::ev_ref_of(wx2, id), wx2};
}


/// EventRef: unbounded fn Wx, Env, Expr -> ((EvRef, Wx))
std::tuple<crate::lower::node_::EvRef, crate::lower::node_::Wx> event_ref(const crate::lower::node_::Wx& wx, const crate::lower::types::Env& menv, const crate::syntax::Expr& e) {
    auto lx = wx.lx;
    auto t = crate::lower::types::out_ty_of(lx, crate::lower::types::peel(crate::lower::type_at(lx, e.span)));
    auto&& _m = prism_rtl::deref(e.kind);
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return event_ref(wx, menv, prism_rtl::deref(prism_rtl::deref(x)));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        auto&& _m = crate::prelude::get(menv.names, crate::check::env::sname_key(n));
        if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(_m))) {
            auto&& r = prism_rtl::as<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(_m)).a0;
            return prism_rtl::deref(r).owner == wx.node_
                ? std::tuple{r, wx}
                : never_event_(crate::lower::node_::crossed(wx, prism_rtl::cat("the event `", crate::check::env::sname_key(n), "`, of node `", prism_rtl::deref(r).owner, "`,")), t);
        }
        {
            return never_event_(wx, t);
        }
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EBinary>(_m)) {
        auto&& m2490_2_0 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a0;
        auto&& l = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a2;
        if (m2490_2_0 == Text::lit("<|")) {
            auto [lr, w1] = event_ref(wx, menv, prism_rtl::deref(prism_rtl::deref(l)));
            auto [rr, w2] = event_ref(w1, menv, prism_rtl::deref(prism_rtl::deref(r)));
            auto [nm, w3] = crate::lower::node_::fresh_name(w2, Text::lit("anon"));
            auto [id, w4] = crate::lower::node_::dynamics::merge(w3, nm, t, lr, rr);
            return std::tuple{crate::lower::node_::ev_ref_of(w4, id), w4};
        }
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EBinary>(_m)) {
        auto&& m2490_3_0 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a0;
        auto&& l = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a2;
        if (m2490_3_0 == Text::lit("on")) {
            auto [rr, w1] = event_ref(wx, menv, prism_rtl::deref(prism_rtl::deref(r)));
            auto value = crate::lower::types::own(crate::lower::expr::value_of(lx, menv, prism_rtl::deref(prism_rtl::deref(l))));
            return std::tuple{crate::lower::node_::EvRef{.node_ = prism_rtl::deref(rr).node_, .owner = prism_rtl::deref(rr).owner, .pipe = ({
                auto rr_1 = rr;
                auto value_2 = value;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(std::tuple<crate::lower::model::Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>>)>>(prism_rtl::rc([=, rr_1 = std::move(rr_1), value_2 = std::move(value_2)](std::tuple<crate::lower::model::Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto rr_1_3 = rr_1;
                    auto value_2_3 = value_2;
                    entered(once_job([=, rr_1_3 = std::move(rr_1_3), value_2_3 = std::move(value_2_3)]() {
                    return ({
                        auto x = p0;
                        auto k_fn = p1;
                        (prism_rtl::deref(rr_1_3).pipe(std::tuple{x, ({
                        auto k_fn_3 = k_fn;
                        auto value_2_3_4 = value_2_3;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>>(prism_rtl::rc([=, k_fn_3 = std::move(k_fn_3), value_2_3_4 = std::move(value_2_3_4)](crate::lower::model::Ex p0) {
                        return ({
                            auto k_fn_3_4 = k_fn_3;
                            auto value_2_3_4_4 = value_2_3_4;
                            entered(once_job([=, k_fn_3_4 = std::move(k_fn_3_4), value_2_3_4_4 = std::move(value_2_3_4_4)]() {
                            return ({
                                static_cast<void>(p0);
                                k_fn_3_4(value_2_3_4_4)->cycle();
                            });
                        }));
                        });
                    })));
                    })})->cycle());
                    });
                }));
                });
            })));
            })}, w1};
        }
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
        auto&& c = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
        auto&& args = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
        auto&& _m = callee_key(lx, prism_rtl::deref(prism_rtl::deref(c)));
        {
            auto&& m3346_0 = _m;
            if (m3346_0 == Text::lit("Prelude.!Filter")) {
                return filter_event(wx, menv, args, false);
            }
        }
        {
            auto&& m3346_1 = _m;
            if (m3346_1 == Text::lit("Prelude.!Present")) {
                return filter_event(wx, menv, args, true);
            }
        }
        {
            auto&& m3346_2 = _m;
            if (m3346_2 == Text::lit("Prelude.!Gate")) {
                return gate_event(wx, menv, args);
            }
        }
        {
            auto&& m3346_3 = _m;
            if (m3346_3 == Text::lit("Prelude.!Union")) {
                return pair_event(wx, menv, args, crate::lower::node_::GnKind(crate::lower::node_::GnKind::GnUnion{}), t);
            }
        }
        {
            auto&& m3346_4 = _m;
            if (m3346_4 == Text::lit("Prelude.!Both")) {
                return pair_event(wx, menv, args, crate::lower::node_::GnKind(crate::lower::node_::GnKind::GnBoth{}), t);
            }
        }
        {
            auto&& m3346_5 = _m;
            if (m3346_5 == Text::lit("Prelude.!Except")) {
                return pair_event(wx, menv, args, crate::lower::node_::GnKind(crate::lower::node_::GnKind::GnExcept{}), t);
            }
        }
        {
            auto&& m3346_6 = _m;
            if (m3346_6 == Text::lit("Prelude.!MergeAll")) {
                return merge_all_event(wx, menv, args, t);
            }
        }
        {
            auto&& m3346_7 = _m;
            if (m3346_7 == Text::lit("Prelude.!Updated")) {
                return updated_event(wx, menv, args, t);
            }
        }
        {
            return event_map(wx, menv, e);
        }
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) && prism_rtl::is_some(prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2)) {
        auto&& m2490_5_0 = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
        auto&& then_b = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
        auto&& else_b = prism_rtl::some_of(prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2);
        if (prism_rtl::is<crate::syntax::Cond::CondExpr>(prism_rtl::deref(prism_rtl::deref(m2490_5_0)))) {
            auto&& c = prism_rtl::as<crate::syntax::Cond::CondExpr>(prism_rtl::deref(prism_rtl::deref(m2490_5_0))).a0;
            auto&& _m = std::tuple{block_expr(then_b), block_expr(else_b)};
            if (prism_rtl::is_some(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m))) {
                auto&& a = prism_rtl::some_of(std::get<0>(_m));
                auto&& b = prism_rtl::some_of(std::get<1>(_m));
                return event_if(wx, menv, prism_rtl::deref(prism_rtl::deref(c)), a, b, t);
            }
            {
                return event_map(wx, menv, e);
            }
        }
    }
    {
        return event_map(wx, menv, e);
    }
}


prism_rtl::Turn<std::tuple<crate::lower::node_::EvRef, crate::lower::node_::Wx>> EventRef::cycle() const {
    const auto& wx = this->wx;
    const auto& menv = this->menv;
    const auto& e = this->e;
    auto lx = prism_rtl::deref(wx).lx;
    auto e_1 = e;
    auto menv_2 = menv;
    auto wx_3 = wx;
    return call_then(crate::lower::types::start_out_ty_of(lx, crate::lower::types::peel(crate::lower::type_at(lx, prism_rtl::deref(e_1).span))), [=](crate::lower::model::OutTy out_ty_of_2447) {
        return ({
            auto t = out_ty_of_2447;
            ({
            auto&& _m = prism_rtl::deref(prism_rtl::deref(e_1).kind);
            prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
            auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
            prism_rtl::more(prism_rtl::rc(EventRef(wx_3, menv_2, prism_rtl::deref(prism_rtl::deref(x)))));
        })
            : prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? ({
            auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
            ({
            auto&& _m = crate::prelude::get(menv_2->names, crate::check::env::sname_key(n));
            prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(_m)) ? ({
            auto&& r = prism_rtl::as<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(_m)).a0;
            prism_rtl::deref(r).owner == prism_rtl::deref(wx_3).node_
            ? prism_rtl::finished(std::tuple{r, wx_3})
            : prism_rtl::finished(never_event_(crate::lower::node_::crossed(wx_3, prism_rtl::cat("the event `", crate::check::env::sname_key(n), "`, of node `", prism_rtl::deref(r).owner, "`,")), t));
        })
            : prism_rtl::finished(never_event_(wx_3, t));
        });
        })
            : prism_rtl::is<crate::syntax::ExprKind::EBinary>(_m) && ({
            auto&& m2490_2_0 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a0;
            auto&& l = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
            auto&& r = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a2;
            (m2490_2_0 == Text::lit("<|"));
        }) ? ({
            auto&& m2490_2_0 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a0;
            auto&& l = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
            auto&& r = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a2;
            ({
            auto l_4 = prism_rtl::deref(prism_rtl::deref(l));
            auto r_5 = prism_rtl::deref(prism_rtl::deref(r));
            call_then(start_event_ref(wx_3, menv_2, l_4), [=, r_5 = std::move(r_5)](std::tuple<crate::lower::node_::EvRef, crate::lower::node_::Wx> event_ref_2867) {
            return ({
                auto [lr, w1] = event_ref_2867;
                call_then(start_event_ref(w1, menv_2, r_5), [=](std::tuple<crate::lower::node_::EvRef, crate::lower::node_::Wx> event_ref_2917) {
                return ({
                    auto [rr, w2] = event_ref_2917;
                    auto [nm, w3] = crate::lower::node_::fresh_name(w2, Text::lit("anon"));
                    auto [id, w4] = crate::lower::node_::dynamics::merge(w3, nm, t, lr, rr);
                    (prism_rtl::finished(std::tuple{crate::lower::node_::ev_ref_of(w4, id), w4}));
                });
            });
            });
        });
        });
        })
            : prism_rtl::is<crate::syntax::ExprKind::EBinary>(_m) && ({
            auto&& m2490_3_0 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a0;
            auto&& l = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
            auto&& r = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a2;
            (m2490_3_0 == Text::lit("on"));
        }) ? ({
            auto&& m2490_3_0 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a0;
            auto&& l = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
            auto&& r = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a2;
            ({
            auto l_4 = prism_rtl::deref(prism_rtl::deref(l));
            auto r_5 = prism_rtl::deref(prism_rtl::deref(r));
            call_then(start_event_ref(wx_3, menv_2, r_5), [=, l_4 = std::move(l_4)](std::tuple<crate::lower::node_::EvRef, crate::lower::node_::Wx> event_ref_3135) {
            return ({
                auto [rr, w1] = event_ref_3135;
                call_then(crate::lower::expr::start_value_of(lx, menv_2, l_4), [=](crate::lower::types::Vl value_of_3185) {
                return ({
                    auto value = crate::lower::types::own(value_of_3185);
                    (prism_rtl::finished(std::tuple{crate::lower::node_::EvRef{.node_ = prism_rtl::deref(rr).node_, .owner = prism_rtl::deref(rr).owner, .pipe = ({
                    auto rr_6 = rr;
                    auto value_7 = value;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(std::tuple<crate::lower::model::Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>>)>>(prism_rtl::rc([=, rr_6 = std::move(rr_6), value_7 = std::move(value_7)](std::tuple<crate::lower::model::Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto rr_6_8 = rr_6;
                        auto value_7_8 = value_7;
                        entered(once_job([=, rr_6_8 = std::move(rr_6_8), value_7_8 = std::move(value_7_8)]() {
                        return ({
                            auto x = p0;
                            auto k_fn = p1;
                            (prism_rtl::deref(rr_6_8).pipe(std::tuple{x, ({
                            auto k_fn_8 = k_fn;
                            auto value_7_8_9 = value_7_8;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>>(prism_rtl::rc([=, k_fn_8 = std::move(k_fn_8), value_7_8_9 = std::move(value_7_8_9)](crate::lower::model::Ex p0) {
                            return ({
                                auto k_fn_8_9 = k_fn_8;
                                auto value_7_8_9_9 = value_7_8_9;
                                entered(once_job([=, k_fn_8_9 = std::move(k_fn_8_9), value_7_8_9_9 = std::move(value_7_8_9_9)]() {
                                return ({
                                    static_cast<void>(p0);
                                    k_fn_8_9(value_7_8_9_9)->cycle();
                                });
                            }));
                            });
                        })));
                        })})->cycle());
                        });
                    }));
                    });
                })));
                })}, w1}));
                });
            });
            });
        });
        });
        })
            : prism_rtl::is<crate::syntax::ExprKind::ECall>(_m) ? ({
            auto&& c = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
            auto&& args = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
            ({
            auto&& _m = callee_key(lx, prism_rtl::deref(prism_rtl::deref(c)));
            ({
            auto&& m3346_0 = _m;
            (m3346_0 == Text::lit("Prelude.!Filter"));
        }) ? ({
            auto&& m3346_0 = _m;
            prism_rtl::finished(filter_event(wx_3, menv_2, args, false));
        })
            : ({
            auto&& m3346_1 = _m;
            (m3346_1 == Text::lit("Prelude.!Present"));
        }) ? ({
            auto&& m3346_1 = _m;
            prism_rtl::finished(filter_event(wx_3, menv_2, args, true));
        })
            : ({
            auto&& m3346_2 = _m;
            (m3346_2 == Text::lit("Prelude.!Gate"));
        }) ? ({
            auto&& m3346_2 = _m;
            prism_rtl::finished(gate_event(wx_3, menv_2, args));
        })
            : ({
            auto&& m3346_3 = _m;
            (m3346_3 == Text::lit("Prelude.!Union"));
        }) ? ({
            auto&& m3346_3 = _m;
            prism_rtl::finished(pair_event(wx_3, menv_2, args, crate::lower::node_::GnKind(crate::lower::node_::GnKind::GnUnion{}), t));
        })
            : ({
            auto&& m3346_4 = _m;
            (m3346_4 == Text::lit("Prelude.!Both"));
        }) ? ({
            auto&& m3346_4 = _m;
            prism_rtl::finished(pair_event(wx_3, menv_2, args, crate::lower::node_::GnKind(crate::lower::node_::GnKind::GnBoth{}), t));
        })
            : ({
            auto&& m3346_5 = _m;
            (m3346_5 == Text::lit("Prelude.!Except"));
        }) ? ({
            auto&& m3346_5 = _m;
            prism_rtl::finished(pair_event(wx_3, menv_2, args, crate::lower::node_::GnKind(crate::lower::node_::GnKind::GnExcept{}), t));
        })
            : ({
            auto&& m3346_6 = _m;
            (m3346_6 == Text::lit("Prelude.!MergeAll"));
        }) ? ({
            auto&& m3346_6 = _m;
            prism_rtl::finished(merge_all_event(wx_3, menv_2, args, t));
        })
            : ({
            auto&& m3346_7 = _m;
            (m3346_7 == Text::lit("Prelude.!Updated"));
        }) ? ({
            auto&& m3346_7 = _m;
            prism_rtl::finished(updated_event(wx_3, menv_2, args, t));
        })
            : prism_rtl::finished(event_map(wx_3, menv_2, e_1));
        });
        })
            : prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) && prism_rtl::is_some(prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2) && ({
            auto&& m2490_5_0 = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
            auto&& then_b = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
            auto&& else_b = prism_rtl::some_of(prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2);
            prism_rtl::is<crate::syntax::Cond::CondExpr>(prism_rtl::deref(prism_rtl::deref(m2490_5_0)));
        }) ? ({
            auto&& m2490_5_0 = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
            auto&& then_b = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
            auto&& else_b = prism_rtl::some_of(prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2);
            auto&& c = prism_rtl::as<crate::syntax::Cond::CondExpr>(prism_rtl::deref(prism_rtl::deref(m2490_5_0))).a0;
            ({
            auto&& _m = std::tuple{block_expr(then_b), block_expr(else_b)};
            prism_rtl::is_some(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m)) ? ({
            auto&& a = prism_rtl::some_of(std::get<0>(_m));
            auto&& b = prism_rtl::some_of(std::get<1>(_m));
            prism_rtl::finished(event_if(wx_3, menv_2, prism_rtl::deref(prism_rtl::deref(c)), a, b, t));
        })
            : prism_rtl::finished(event_map(wx_3, menv_2, e_1));
        });
        })
            : prism_rtl::finished(event_map(wx_3, menv_2, e_1));
        });
        });
    });
}


/// `Start EventRef, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::lower::node_::EvRef, crate::lower::node_::Wx>> start_event_ref(crate::lower::node_::Wx wx, crate::lower::types::Env menv, crate::syntax::Expr e) {
    return prism_rtl::make_rc<EventRef>(wx, menv, e);
}


/// EventIf: unbounded fn Wx, Env, Expr, Expr, Expr, OutTy -> ((EvRef, Wx))
std::tuple<crate::lower::node_::EvRef, crate::lower::node_::Wx> event_if(const crate::lower::node_::Wx& wx, const crate::lower::types::Env& menv, const crate::syntax::Expr& c, const crate::syntax::Expr& a, const crate::syntax::Expr& b, const crate::lower::model::OutTy& t) {
    auto cond = crate::lower::types::as_bool(crate::lower::expr::value_of(wx.lx, menv, c));
    auto [ra, w1] = event_ref(wx, menv, a);
    auto [rb, w2] = event_ref(w1, menv, b);
    auto ga = crate::lower::node_::EvRef{.node_ = prism_rtl::deref(ra).node_, .owner = prism_rtl::deref(ra).owner, .pipe = ({
        auto ra_1 = ra;
        auto cond_2 = cond;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(std::tuple<crate::lower::model::Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>>)>>(prism_rtl::rc([=, ra_1 = std::move(ra_1), cond_2 = std::move(cond_2)](std::tuple<crate::lower::model::Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto ra_1_3 = ra_1;
            auto cond_2_3 = cond_2;
            entered(once_job([=, ra_1_3 = std::move(ra_1_3), cond_2_3 = std::move(cond_2_3)]() {
            return ({
                auto x = p0;
                auto k_fn = p1;
                (prism_rtl::deref(ra_1_3).pipe(std::tuple{x, ({
                auto cond_2_3_3 = cond_2_3;
                auto k_fn_3 = k_fn;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>>(prism_rtl::rc([=, cond_2_3_3 = std::move(cond_2_3_3), k_fn_3 = std::move(k_fn_3)](crate::lower::model::Ex p0) {
                return ({
                    auto cond_2_3_3_4 = cond_2_3_3;
                    auto k_fn_3_4 = k_fn_3;
                    entered(once_job([=, cond_2_3_3_4 = std::move(cond_2_3_3_4), k_fn_3_4 = std::move(k_fn_3_4)]() {
                    return ({
                        auto y = p0;
                        call_value(k_fn_3_4(y), [=](Array<crate::lower::model::Do> k_4624) { return prism_rtl::finished(Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoIf{cond_2_3_3_4, k_4624, Array<crate::lower::model::Do>{}})})); });
                    });
                }));
                });
            })));
            })})->cycle());
            });
        }));
        });
    })));
    })};
    auto gb = crate::lower::node_::EvRef{.node_ = prism_rtl::deref(rb).node_, .owner = prism_rtl::deref(rb).owner, .pipe = ({
        auto rb_1 = rb;
        auto cond_2 = cond;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(std::tuple<crate::lower::model::Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>>)>>(prism_rtl::rc([=, rb_1 = std::move(rb_1), cond_2 = std::move(cond_2)](std::tuple<crate::lower::model::Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto rb_1_3 = rb_1;
            auto cond_2_3 = cond_2;
            entered(once_job([=, rb_1_3 = std::move(rb_1_3), cond_2_3 = std::move(cond_2_3)]() {
            return ({
                auto x = p0;
                auto k_fn = p1;
                (prism_rtl::deref(rb_1_3).pipe(std::tuple{x, ({
                auto cond_2_3_3 = cond_2_3;
                auto k_fn_3 = k_fn;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>>(prism_rtl::rc([=, cond_2_3_3 = std::move(cond_2_3_3), k_fn_3 = std::move(k_fn_3)](crate::lower::model::Ex p0) {
                return ({
                    auto cond_2_3_3_4 = cond_2_3_3;
                    auto k_fn_3_4 = k_fn_3;
                    entered(once_job([=, cond_2_3_3_4 = std::move(cond_2_3_3_4), k_fn_3_4 = std::move(k_fn_3_4)]() {
                    return ({
                        auto y = p0;
                        call_value(k_fn_3_4(y), [=](Array<crate::lower::model::Do> k_4762) { return prism_rtl::finished(Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoIf{crate::lower::model::Ex(crate::lower::model::Ex::XBin{Text::lit("=="), prism_rtl::rc(cond_2_3_3_4), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XBool{false}))}), k_4762, Array<crate::lower::model::Do>{}})})); });
                    });
                }));
                });
            })));
            })})->cycle());
            });
        }));
        });
    })));
    })};
    auto [nm, w3] = crate::lower::node_::fresh_name(w2, Text::lit("chosen"));
    auto [id, w4] = crate::lower::node_::dynamics::merge(w3, nm, t, ga, gb);
    return std::tuple{crate::lower::node_::ev_ref_of(w4, id), w4};
}


/// ?BlockExpr: fn Block -> ?Expr
std::optional<crate::syntax::Expr> block_expr(const crate::syntax::Block& b) {
    auto&& _m = b.stmts;
    {
        auto&& m4996_0 = _m;
        if (m4996_0.size() == 1u) {
            {
                auto&& _c1 = index(m4996_0, Nat(0u));
                if (prism_rtl::is_some(_c1)) {
                    auto&& st = prism_rtl::some_of(_c1);
                    auto&& _m = prism_rtl::deref(st).kind;
                    if (prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m)) {
                        auto&& x = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
                        return std::optional(x);
                    }
                    {
                        return std::optional<crate::syntax::Expr>{};
                    }
                }
            }
        }
    }
    {
        return std::optional<crate::syntax::Expr>{};
    }
}


/// CalleeKey: fn Lx, Expr -> Text
Text callee_key(const crate::lower::Lx& lx, const crate::syntax::Expr& c) {
    auto&& _m = prism_rtl::deref(c.kind);
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        auto&& _q_opt = crate::check::env::names::resolve_value(lx.g, lx.home, n);
        auto&& q_opt = std::get<0>(_q_opt);
        return or_(q_opt, Text::lit(""));
    }
    {
        return Text::lit("");
    }
}


/// PairEvent: unbounded fn Wx, Env, [Arg], GnKind, OutTy -> ((EvRef, Wx))
std::tuple<crate::lower::node_::EvRef, crate::lower::node_::Wx> pair_event(const crate::lower::node_::Wx& wx, const crate::lower::types::Env& menv, const Array<crate::syntax::Arg>& args, const crate::lower::node_::GnKind& kind, const crate::lower::model::OutTy& t) {
    auto&& _m = std::tuple{index(args, Nat(0u)), index(args, Nat(1u))};
    if (prism_rtl::is_some(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m))) {
        auto&& a = prism_rtl::some_of(std::get<0>(_m));
        auto&& b = prism_rtl::some_of(std::get<1>(_m));
        auto [ra, w1] = event_ref(wx, menv, a->value);
        auto [rb, w2] = event_ref(w1, menv, b->value);
        auto lt = crate::lower::types::out_ty_of(wx.lx, crate::lower::types::peel(crate::lower::type_at(wx.lx, prism_rtl::deref(a->value).span)));
        auto rt = crate::lower::types::out_ty_of(wx.lx, crate::lower::types::peel(crate::lower::type_at(wx.lx, prism_rtl::deref(b->value).span)));
        auto [nm, w3] = crate::lower::node_::fresh_name(w2, crate::lower::node_::kind_word(kind));
        auto [id, w4] = combinator(w3, nm, t, kind, ra, rb, lt, rt);
        return std::tuple{crate::lower::node_::ev_ref_of(w4, id), w4};
    }
    {
        return never_event_(wx, t);
    }
}


/// MergeAllEvent: unbounded fn Wx, Env, [Arg], OutTy -> ((EvRef, Wx))
std::tuple<crate::lower::node_::EvRef, crate::lower::node_::Wx> merge_all_event(const crate::lower::node_::Wx& wx, const crate::lower::types::Env& menv, const Array<crate::syntax::Arg>& args, const crate::lower::model::OutTy& t) {
    auto&& _m = index(args, Nat(0u));
    if (prism_rtl::is_some(_m)) {
        auto&& a = prism_rtl::some_of(_m);
        auto&& _m = prism_rtl::deref(prism_rtl::deref(a->value).kind);
        if (prism_rtl::is<crate::syntax::ExprKind::EArray>(_m)) {
            auto&& es = prism_rtl::as<crate::syntax::ExprKind::EArray>(_m).a0;
            auto et = ({
                __label__ _done;
                prism_rtl::Slot<crate::lower::model::OutTy> _v;
                if (prism_rtl::is<crate::lower::model::OutTy::OutArray>(t)) {
                    auto&& x = prism_rtl::as<crate::lower::model::OutTy::OutArray>(t).a0;
                    _v.set(prism_rtl::deref(prism_rtl::deref(x)));
                    goto _done;
                }
                {
                    _v.set(crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}));
                    goto _done;
                }
            _done:
                _v.take();
            });
            auto [nm, w1] = crate::lower::node_::fresh_name(wx, Text::lit("merged"));
            auto [id, w2] = crate::lower::node_::add_gn(w1, nm, t, crate::lower::node_::GnKind(crate::lower::node_::GnKind::GnMergeAll{}), Nat(1u));
            auto ins = each(crate::check::errors::range0(len(es)), [&](const Nat& i) { return prism_rtl::cat(nm, "_", i); });
            auto w3 = fold(ins, w2, [&](const crate::lower::node_::Wx& w, const Text& f) { return crate::lower::node_::add_field_last(w, f, crate::lower::model::OutTy(crate::lower::model::OutTy::OutStamped{prism_rtl::rc(et)}), Text::lit("an input of `!MergeAll`"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Stamped::new"), Array<crate::lower::model::Ex>{}})); });
            auto w4 = ({
                crate::lower::node_::Wx this_ = w3;
                this_.gns = each(this_.gns, [&](const crate::lower::node_::Gn& n) { return prism_rtl::deref(n).id == id ? with_inputs(n, ins) : n; });
                (std::move(this_));
            });
            auto w5 = run_to_end(fold_job(crate::check::errors::range0(len(es)), w4, ({
                auto menv_1 = menv;
                auto es_2 = es;
                auto a_3 = a;
                auto id_4 = id;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::node_::Wx>(std::tuple<crate::lower::node_::Wx, Nat>)>>(prism_rtl::rc([=, menv_1 = std::move(menv_1), es_2 = std::move(es_2), a_3 = std::move(a_3), id_4 = std::move(id_4)](std::tuple<crate::lower::node_::Wx, Nat> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto menv_1_5 = menv_1;
                    auto es_2_5 = es_2;
                    auto a_3_5 = a_3;
                    auto id_4_5 = id_4;
                    entered(once_job([=, menv_1_5 = std::move(menv_1_5), es_2_5 = std::move(es_2_5), a_3_5 = std::move(a_3_5), id_4_5 = std::move(id_4_5)]() {
                    return ({
                        auto w = p0;
                        auto i = p1;
                        call_then(start_event_ref(w, menv_1_5, or_(index(es_2_5, i), a_3_5->value)), [=](std::tuple<crate::lower::node_::EvRef, crate::lower::node_::Wx> event_ref_6930) {
                        return ({
                            auto [r, w6] = event_ref_6930;
                            (prism_rtl::finished(crate::lower::node_::connect(w6, r, crate::lower::node_::Sk(crate::lower::node_::Sk::SkIn{id_4_5, i}))));
                        });
                    });
                    });
                }));
                });
            })));
            })));
            return std::tuple{crate::lower::node_::ev_ref_of(w5, id), w5};
        }
        {
            auto [r, w1] = never_event_(wx, t);
            auto w2 = ({
                crate::lower::node_::Wx this_ = w1;
                this_.build = crate::prelude::push(this_.build, crate::lower::expr::refusal_do(Text::lit("`!MergeAll` of a list that is not a literal")));
                (std::move(this_));
            });
            return std::tuple{r, w2};
        }
    }
    if (prism_rtl::is_none(_m)) {
        return never_event_(wx, t);
    }
    prism_rtl::unreachable("no arm matched");
}


/// UpdatedEvent: unbounded fn Wx, Env, [Arg], OutTy -> ((EvRef, Wx))
std::tuple<crate::lower::node_::EvRef, crate::lower::node_::Wx> updated_event(const crate::lower::node_::Wx& wx, const crate::lower::types::Env& menv, const Array<crate::syntax::Arg>& args, const crate::lower::model::OutTy& t) {
    auto&& _m = index(args, Nat(0u));
    if (prism_rtl::is_some(_m)) {
        auto&& a = prism_rtl::some_of(_m);
        auto [ex, reads] = dynamic_expr(wx, menv, a->value);
        auto [nm, w1] = crate::lower::node_::fresh_name(wx, Text::lit("updated"));
        auto [id, w2] = crate::lower::node_::add_gn(w1, nm, t, crate::lower::node_::GnKind(crate::lower::node_::GnKind::GnUpdated{}), Nat(1u));
        auto w3 = crate::lower::node_::add_field_last(w2, prism_rtl::cat(nm, "_moved"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Cell"), Array(std::vector{crate::lower::model::OutTy(crate::lower::model::OutTy::OutBool{})})}), prism_rtl::cat("a hold `!", nm, "`\'s dynamic reads was written this tick"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Cell::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XBool{false})})}));
        auto w4 = ({
            crate::lower::node_::Wx this_ = w3;
            this_.gns = each(this_.gns, [&](const crate::lower::node_::Gn& n) { return prism_rtl::deref(n).id == id ? with_reads(n, reads) : n; });
            this_.getters = crate::prelude::push(this_.getters, crate::lower::model::MethDef{.name = prism_rtl::cat(nm, "_value"), .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxRef{}), .ret = t, .body = Array<crate::lower::model::Do>{}, .tail = ex, .doc = prism_rtl::cat("The dynamic `!", nm, "` is the event half of, which the wake reads after the tick.")});
            (std::move(this_));
        });
        return std::tuple{crate::lower::node_::ev_ref_of(w4, id), w4};
    }
    if (prism_rtl::is_none(_m)) {
        return never_event_(wx, t);
    }
    prism_rtl::unreachable("no arm matched");
}


/// FilterEvent: unbounded fn Wx, Env, [Arg], Bool -> ((EvRef, Wx))
std::tuple<crate::lower::node_::EvRef, crate::lower::node_::Wx> filter_event(const crate::lower::node_::Wx& wx, const crate::lower::types::Env& menv, const Array<crate::syntax::Arg>& args, const bool& is_unit) {
    auto&& _m = index(args, Nat(0u));
    if (prism_rtl::is_none(_m)) {
        return never_event_(wx, crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}));
    }
    if (prism_rtl::is_some(_m)) {
        auto&& a = prism_rtl::some_of(_m);
        auto [r, w1] = event_ref(wx, menv, a->value);
        auto bound = is_unit
            ? crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})
            : crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("w")});
        auto pipe = ({
            auto r_1 = r;
            auto bound_2 = bound;
            auto is_unit_3 = is_unit;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(std::tuple<crate::lower::model::Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>>)>>(prism_rtl::rc([=, r_1 = std::move(r_1), bound_2 = std::move(bound_2), is_unit_3 = std::move(is_unit_3)](std::tuple<crate::lower::model::Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto r_1_4 = r_1;
                auto bound_2_4 = bound_2;
                auto is_unit_3_4 = is_unit_3;
                entered(once_job([=, r_1_4 = std::move(r_1_4), bound_2_4 = std::move(bound_2_4), is_unit_3_4 = std::move(is_unit_3_4)]() {
                return ({
                    auto x = p0;
                    auto k_fn = p1;
                    (prism_rtl::deref(r_1_4).pipe(std::tuple{x, ({
                    auto bound_2_4_4 = bound_2_4;
                    auto k_fn_4 = k_fn;
                    auto is_unit_3_4_5 = is_unit_3_4;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>>(prism_rtl::rc([=, bound_2_4_4 = std::move(bound_2_4_4), k_fn_4 = std::move(k_fn_4), is_unit_3_4_5 = std::move(is_unit_3_4_5)](crate::lower::model::Ex p0) {
                    return ({
                        auto bound_2_4_4_5 = bound_2_4_4;
                        auto k_fn_4_5 = k_fn_4;
                        auto is_unit_3_4_5_5 = is_unit_3_4_5;
                        entered(once_job([=, bound_2_4_4_5 = std::move(bound_2_4_4_5), k_fn_4_5 = std::move(k_fn_4_5), is_unit_3_4_5_5 = std::move(is_unit_3_4_5_5)]() {
                        return ({
                            auto y = p0;
                            call_value(k_fn_4_5(is_unit_3_4_5_5
                            ? crate::lower::model::Ex(crate::lower::model::Ex::XUnit{})
                            : crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("w")})), [=, y = std::move(y)](Array<crate::lower::model::Do> k_9292) { return prism_rtl::finished(Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoIfLet{crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{bound_2_4_4_5})}), y, k_9292, Array<crate::lower::model::Do>{}})})); });
                        });
                    }));
                    });
                })));
                })})->cycle());
                });
            }));
            });
        })));
        });
        return std::tuple{crate::lower::node_::EvRef{.node_ = prism_rtl::deref(r).node_, .owner = prism_rtl::deref(r).owner, .pipe = pipe}, w1};
    }
    prism_rtl::unreachable("no arm matched");
}


/// GateEvent: unbounded fn Wx, Env, [Arg] -> ((EvRef, Wx))
std::tuple<crate::lower::node_::EvRef, crate::lower::node_::Wx> gate_event(const crate::lower::node_::Wx& wx, const crate::lower::types::Env& menv, const Array<crate::syntax::Arg>& args) {
    auto&& _m = index(args, Nat(1u));
    if (prism_rtl::is_none(_m)) {
        return never_event_(wx, crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}));
    }
    if (prism_rtl::is_some(_m)) {
        auto&& a = prism_rtl::some_of(_m);
        auto [r, w1] = event_ref(wx, menv, a->value);
        auto cond = ({
            __label__ _done;
            prism_rtl::Slot<crate::lower::model::Ex> _v;
            auto&& _m = index(args, Nat(0u));
            if (prism_rtl::is_some(_m)) {
                auto&& b = prism_rtl::some_of(_m);
                _v.set(crate::lower::types::as_bool(crate::lower::expr::value_of(wx.lx, menv, b->value)));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(crate::lower::model::Ex(crate::lower::model::Ex::XBool{false}));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto pipe = ({
            auto r_1 = r;
            auto cond_2 = cond;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(std::tuple<crate::lower::model::Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>>)>>(prism_rtl::rc([=, r_1 = std::move(r_1), cond_2 = std::move(cond_2)](std::tuple<crate::lower::model::Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto r_1_3 = r_1;
                auto cond_2_3 = cond_2;
                entered(once_job([=, r_1_3 = std::move(r_1_3), cond_2_3 = std::move(cond_2_3)]() {
                return ({
                    auto x = p0;
                    auto k_fn = p1;
                    (prism_rtl::deref(r_1_3).pipe(std::tuple{x, ({
                    auto cond_2_3_3 = cond_2_3;
                    auto k_fn_3 = k_fn;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>>(prism_rtl::rc([=, cond_2_3_3 = std::move(cond_2_3_3), k_fn_3 = std::move(k_fn_3)](crate::lower::model::Ex p0) {
                    return ({
                        auto cond_2_3_3_4 = cond_2_3_3;
                        auto k_fn_3_4 = k_fn_3;
                        entered(once_job([=, cond_2_3_3_4 = std::move(cond_2_3_3_4), k_fn_3_4 = std::move(k_fn_3_4)]() {
                        return ({
                            auto y = p0;
                            call_value(k_fn_3_4(y), [=](Array<crate::lower::model::Do> k_9825) { return prism_rtl::finished(Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoIf{cond_2_3_3_4, k_9825, Array<crate::lower::model::Do>{}})})); });
                        });
                    }));
                    });
                })));
                })})->cycle());
                });
            }));
            });
        })));
        });
        return std::tuple{crate::lower::node_::EvRef{.node_ = prism_rtl::deref(r).node_, .owner = prism_rtl::deref(r).owner, .pipe = pipe}, w1};
    }
    prism_rtl::unreachable("no arm matched");
}


/// EventMap: unbounded fn Wx, Env, Expr -> ((EvRef, Wx))
std::tuple<crate::lower::node_::EvRef, crate::lower::node_::Wx> event_map(const crate::lower::node_::Wx& wx, const crate::lower::types::Env& menv, const crate::syntax::Expr& e) {
    auto lx = wx.lx;
    auto t = crate::lower::types::out_ty_of(lx, crate::lower::types::peel(crate::lower::type_at(lx, e.span)));
    auto evs = filter(operands(e), [&](const crate::syntax::Expr& x) { return crate::lower::types::layer_of(crate::lower::type_at(lx, prism_rtl::deref(x).span)) == crate::lower::types::Layer(crate::lower::types::Layer::LyEv{}); });
    {
        auto&& m10307_0 = evs;
        if (m10307_0.size() == 1u) {
            {
                auto&& _c1 = index(m10307_0, Nat(0u));
                if (prism_rtl::is_some(_c1)) {
                    auto&& one = prism_rtl::some_of(_c1);
                    auto [r, w1] = event_ref(wx, menv, one);
                    auto et = crate::lower::types::out_ty_of(lx, crate::lower::types::peel(crate::lower::type_at(lx, prism_rtl::deref(one).span)));
                    auto k = crate::lower::place_key(lx, prism_rtl::deref(one).span);
                    auto pipe = ({
                        auto r_1 = r;
                        auto lx_2 = lx;
                        auto menv_3 = menv;
                        auto k_4 = k;
                        auto et_5 = et;
                        auto e_6 = e;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(std::tuple<crate::lower::model::Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>>)>>(prism_rtl::rc([=, r_1 = std::move(r_1), lx_2 = std::move(lx_2), menv_3 = std::move(menv_3), k_4 = std::move(k_4), et_5 = std::move(et_5), e_6 = std::move(e_6)](std::tuple<crate::lower::model::Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>> _p0) {
                        auto&& p0 = std::get<0>(_p0);
                        auto&& p1 = std::get<1>(_p0);
                        return ({
                            auto r_1_7 = r_1;
                            auto lx_2_7 = lx_2;
                            auto menv_3_7 = menv_3;
                            auto k_4_7 = k_4;
                            auto et_5_7 = et_5;
                            auto e_6_7 = e_6;
                            entered(once_job([=, r_1_7 = std::move(r_1_7), lx_2_7 = std::move(lx_2_7), menv_3_7 = std::move(menv_3_7), k_4_7 = std::move(k_4_7), et_5_7 = std::move(et_5_7), e_6_7 = std::move(e_6_7)]() {
                            return ({
                                auto x = p0;
                                auto k_fn = p1;
                                (prism_rtl::deref(r_1_7).pipe(std::tuple{x, ({
                                auto k_fn_7 = k_fn;
                                auto lx_2_7_8 = lx_2_7;
                                auto menv_3_7_8 = menv_3_7;
                                auto k_4_7_8 = k_4_7;
                                auto et_5_7_8 = et_5_7;
                                auto e_6_7_8 = e_6_7;
                                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>>(prism_rtl::rc([=, k_fn_7 = std::move(k_fn_7), lx_2_7_8 = std::move(lx_2_7_8), menv_3_7_8 = std::move(menv_3_7_8), k_4_7_8 = std::move(k_4_7_8), et_5_7_8 = std::move(et_5_7_8), e_6_7_8 = std::move(e_6_7_8)](crate::lower::model::Ex p0) {
                                return ({
                                    auto k_fn_7_8 = k_fn_7;
                                    auto lx_2_7_8_8 = lx_2_7_8;
                                    auto menv_3_7_8_8 = menv_3_7_8;
                                    auto k_4_7_8_8 = k_4_7_8;
                                    auto et_5_7_8_8 = et_5_7_8;
                                    auto e_6_7_8_8 = e_6_7_8;
                                    entered(once_job([=, k_fn_7_8 = std::move(k_fn_7_8), lx_2_7_8_8 = std::move(lx_2_7_8_8), menv_3_7_8_8 = std::move(menv_3_7_8_8), k_4_7_8_8 = std::move(k_4_7_8_8), et_5_7_8_8 = std::move(et_5_7_8_8), e_6_7_8_8 = std::move(e_6_7_8_8)]() {
                                    return ({
                                        auto y = p0;
                                        call_then(crate::lower::expr::start_value_of(lx_2_7_8_8, crate::lower::types::bind_span(menv_3_7_8_8, k_4_7_8_8, firing_value(y, et_5_7_8_8)), e_6_7_8_8), [=](crate::lower::types::Vl value_of_10544) { return k_fn_7_8(crate::lower::types::own(value_of_10544))->cycle(); });
                                    });
                                }));
                                });
                            })));
                            })})->cycle());
                            });
                        }));
                        });
                    })));
                    });
                    return std::tuple{crate::lower::node_::EvRef{.node_ = prism_rtl::deref(r).node_, .owner = prism_rtl::deref(r).owner, .pipe = pipe}, w1};
                }
            }
        }
    }
    {
        return never_event_(wx, t);
    }
}


/// FiringValue: fn Ex, OutTy -> Vl
crate::lower::types::Vl firing_value(const crate::lower::model::Ex& ex0, const crate::lower::model::OutTy& t) {
    if (prism_rtl::is<crate::lower::model::Ex::XVar>(ex0)) {
        auto&& n = prism_rtl::as<crate::lower::model::Ex::XVar>(ex0).a0;
        return crate::lower::types::Vl(crate::lower::types::Vl::VlPlace{crate::lower::model::Ex(crate::lower::model::Ex::XVar{n}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), t});
    }
    if (prism_rtl::is<crate::lower::model::Ex::XUnit>(ex0)) {
        return crate::lower::types::Vl(crate::lower::types::Vl::VlPlace{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), t});
    }
    {
        auto&& x = ex0;
        return crate::lower::types::Vl(crate::lower::types::Vl::VlOwned{x, t});
    }
}


/// Operands: fn Expr -> [Expr]
Array<crate::syntax::Expr> operands(const crate::syntax::Expr& e) {
    auto&& _m = prism_rtl::deref(e.kind);
    if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
        auto&& c = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
        auto&& args = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
        return append(Array(std::vector{prism_rtl::deref(prism_rtl::deref(c))}), each(args, [&](const crate::syntax::Arg& a) { return a->value; }));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMethod>(_m)) {
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a0;
        auto&& args = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a2;
        return append(Array(std::vector{prism_rtl::deref(prism_rtl::deref(r))}), each(args, [&](const crate::syntax::Arg& a) { return a->value; }));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EBinary>(_m)) {
        auto&& l = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a2;
        return Array(std::vector{prism_rtl::deref(prism_rtl::deref(l)), prism_rtl::deref(prism_rtl::deref(r))});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EUnary>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a1;
        return Array(std::vector{prism_rtl::deref(prism_rtl::deref(x))});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
        return Array(std::vector{prism_rtl::deref(prism_rtl::deref(x))});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return Array(std::vector{prism_rtl::deref(prism_rtl::deref(x))});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EField>(_m)) {
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a0;
        return Array(std::vector{prism_rtl::deref(prism_rtl::deref(r))});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m)) {
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
        auto&& i = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a1;
        return Array(std::vector{prism_rtl::deref(prism_rtl::deref(r)), prism_rtl::deref(prism_rtl::deref(i))});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ETuple>(_m)) {
        auto&& es = prism_rtl::as<crate::syntax::ExprKind::ETuple>(_m).a0;
        return es;
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EArray>(_m)) {
        auto&& es = prism_rtl::as<crate::syntax::ExprKind::EArray>(_m).a0;
        return es;
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMap>(_m)) {
        auto&& kvs = prism_rtl::as<crate::syntax::ExprKind::EMap>(_m).a0;
        return fold(kvs, Array<crate::syntax::Expr>{}, [&](const Array<crate::syntax::Expr>& acc, const std::tuple<crate::syntax::Expr, crate::syntax::Expr>& _p1) {
            auto&& k = std::get<0>(_p1);
            auto&& v_ = std::get<1>(_p1);
            return append(acc, Array(std::vector{k, v_}));
        });
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ELit>(_m)) {
        auto&& l = prism_rtl::as<crate::syntax::ExprKind::ELit>(_m).a0;
        auto&& _m = prism_rtl::deref(l).kind;
        if (prism_rtl::is<crate::syntax::LitKind::LText>(_m)) {
            auto&& segs = prism_rtl::as<crate::syntax::LitKind::LText>(_m).a0;
            return fold(segs, Array<crate::syntax::Expr>{}, [&](const Array<crate::syntax::Expr>& acc, const crate::syntax::TextSeg& sg) {
                return ({
                    __label__ _done;
                    prism_rtl::Slot<Array<crate::syntax::Expr>> _v;
                    if (prism_rtl::is<crate::syntax::TextSeg::SegPlaceholder>(sg)) {
                        auto&& x = prism_rtl::as<crate::syntax::TextSeg::SegPlaceholder>(sg).a0;
                        _v.set(crate::prelude::push(acc, x));
                        goto _done;
                    }
                    {
                        _v.set(acc);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
            });
        }
        {
            return Array<crate::syntax::Expr>{};
        }
    }
    {
        return Array<crate::syntax::Expr>{};
    }
}


/// Merge: fn Wx, Text, OutTy, EvRef, EvRef -> ((Nat, Wx))
std::tuple<Nat, crate::lower::node_::Wx> merge(const crate::lower::node_::Wx& wx, const Text& name, const crate::lower::model::OutTy& t, const crate::lower::node_::EvRef& l, const crate::lower::node_::EvRef& r) {
    return combinator(wx, name, t, crate::lower::node_::GnKind(crate::lower::node_::GnKind::GnMerge{}), l, r, t, t);
}


/// Combinator: fn Wx, Text, OutTy, GnKind, EvRef, EvRef, OutTy, OutTy -> ((Nat, Wx))
std::tuple<Nat, crate::lower::node_::Wx> combinator(const crate::lower::node_::Wx& wx, const Text& name, const crate::lower::model::OutTy& t, const crate::lower::node_::GnKind& kind, const crate::lower::node_::EvRef& l, const crate::lower::node_::EvRef& r, const crate::lower::model::OutTy& lt, const crate::lower::model::OutTy& rt) {
    auto [id, wx1] = crate::lower::node_::add_gn(wx, name, t, kind, Nat(1u));
    auto wx2 = crate::lower::node_::add_field_last(wx1, prism_rtl::cat(name, "_left"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutStamped{prism_rtl::rc(lt)}), prism_rtl::cat("`", name, "`\'s left input"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Stamped::new"), Array<crate::lower::model::Ex>{}}));
    auto wx3 = crate::lower::node_::add_field_last(wx2, prism_rtl::cat(name, "_right"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutStamped{prism_rtl::rc(rt)}), Text::lit("its right input"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Stamped::new"), Array<crate::lower::model::Ex>{}}));
    auto wx4 = ({
        crate::lower::node_::Wx this_ = wx3;
        this_.gns = each(this_.gns, [&](const crate::lower::node_::Gn& n) {
            return prism_rtl::deref(n).id == id
                ? with_inputs(n, Array(std::vector{prism_rtl::cat(name, "_left"), prism_rtl::cat(name, "_right")}))
                : n;
        });
        (std::move(this_));
    });
    return std::tuple{id, crate::lower::node_::connect(crate::lower::node_::connect(wx4, l, crate::lower::node_::Sk(crate::lower::node_::Sk::SkIn{id, Nat(0u)})), r, crate::lower::node_::Sk(crate::lower::node_::Sk::SkIn{id, Nat(1u)}))};
}


/// WithInputs: fn Gn, [Text] -> Gn
crate::lower::node_::Gn with_inputs(const crate::lower::node_::Gn& n, const Array<Text>& ins) {
    crate::lower::node_::Gn this_ = n;
    this_.inputs = ins;
    return this_;
}


/// WithReads: fn Gn, [Read] -> Gn
crate::lower::node_::Gn with_reads(const crate::lower::node_::Gn& n, const Array<crate::lower::node_::Read>& reads) {
    crate::lower::node_::Gn this_ = n;
    this_.reads = reads;
    return this_;
}

}  // namespace crate::lower::node_::dynamics


// The module `Lower.Node.Elements`, from `target/bootstrap/cpp-src/prismc/lower/node/elements.prism`.
namespace crate::lower::node_::elements {

/// ElementLine: unbounded fn Wx, Env, Env, Expr, ?Bn -> ((Wx, Wres))
std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> element_line(const crate::lower::node_::Wx& wx, const crate::lower::types::Env& benv, const crate::lower::types::Env& menv, const crate::syntax::Expr& e, const std::optional<crate::lower::types::Bn>& bound_opt) {
    auto lx = wx.lx;
    auto [tag_name, args] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Text, Array<crate::syntax::Arg>>> _v;
        auto&& _m = prism_rtl::deref(e.kind);
        if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
            auto&& c = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
            auto&& xs = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
            _v.set(std::tuple{tag_name_of(lx, prism_rtl::deref(prism_rtl::deref(c))), xs});
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
            auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
            _v.set(std::tuple{tag_name_of(lx, e), Array<crate::syntax::Arg>{}});
            goto _done;
        }
        {
            _v.set(std::tuple{Text::lit(""), Array<crate::syntax::Arg>{}});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto full = crate::lower::type_at(lx, e.span);
    auto&& _m = crate::prelude::get(prism_rtl::deref(prism_rtl::deref(lx).g).tags, tag_name);
    if (prism_rtl::is_none(_m)) {
        auto wx2 = ({
            crate::lower::node_::Wx this_ = wx;
            this_.build = crate::prelude::push(this_.build, crate::lower::expr::refusal_do(Text::lit("an element of an unknown tag")));
            (std::move(this_));
        });
        return std::tuple{wx2, crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{})};
    }
    if (prism_rtl::is_some(_m)) {
        auto&& tg = prism_rtl::some_of(_m);
        auto pos = wx.pos;
        auto wx1 = ({
            crate::lower::node_::Wx this_ = wx;
            this_.pos = crate::lower::model::next_pos(this_.pos);
            (std::move(this_));
        });
        auto struct_path = crate::lower::path_in(lx, prism_rtl::deref(tg).home, crate::lower::tag_struct(prism_rtl::deref(tg).name));
        auto [live_fields, const_fields, method_consts, reads, wx2] = run_to_end(fold_job(prism_rtl::deref(tg).fields, std::tuple{Array<std::tuple<Text, crate::lower::model::Ex>>{}, Array<std::tuple<Text, crate::lower::model::Ex>>{}, Array<std::tuple<Text, crate::lower::model::Ex>>{}, Array<crate::lower::node_::Read>{}, wx1}, ({
            auto args_1 = args;
            auto menv_2 = menv;
            auto pos_3 = pos;
            auto tg_4 = tg;
            auto lx_5 = lx;
            auto benv_6 = benv;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, crate::lower::model::Ex>>, Array<std::tuple<Text, crate::lower::model::Ex>>, Array<std::tuple<Text, crate::lower::model::Ex>>, Array<crate::lower::node_::Read>, crate::lower::node_::Wx>>(std::tuple<std::tuple<Array<std::tuple<Text, crate::lower::model::Ex>>, Array<std::tuple<Text, crate::lower::model::Ex>>, Array<std::tuple<Text, crate::lower::model::Ex>>, Array<crate::lower::node_::Read>, crate::lower::node_::Wx>, std::tuple<Text, crate::check::types::Ty>>)>>(prism_rtl::rc([=, args_1 = std::move(args_1), menv_2 = std::move(menv_2), pos_3 = std::move(pos_3), tg_4 = std::move(tg_4), lx_5 = std::move(lx_5), benv_6 = std::move(benv_6)](std::tuple<std::tuple<Array<std::tuple<Text, crate::lower::model::Ex>>, Array<std::tuple<Text, crate::lower::model::Ex>>, Array<std::tuple<Text, crate::lower::model::Ex>>, Array<crate::lower::node_::Read>, crate::lower::node_::Wx>, std::tuple<Text, crate::check::types::Ty>> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto args_1_7 = args_1;
                auto menv_2_7 = menv_2;
                auto pos_3_7 = pos_3;
                auto tg_4_7 = tg_4;
                auto lx_5_7 = lx_5;
                auto benv_6_7 = benv_6;
                entered(once_job([=, args_1_7 = std::move(args_1_7), menv_2_7 = std::move(menv_2_7), pos_3_7 = std::move(pos_3_7), tg_4_7 = std::move(tg_4_7), lx_5_7 = std::move(lx_5_7), benv_6_7 = std::move(benv_6_7)]() {
                return ({
                    auto [lf, cf, mf, rd, w] = p0;
                    auto [fname, fty] = p1;
                    ({
                    auto&& _m = tag_arg(args_1_7, fname);
                    prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{lf, cf, mf, rd, w})
                    : prism_rtl::is_some(_m) ? ({
                    auto&& arg = prism_rtl::some_of(_m);
                    ({
                    auto&& _m = crate::lower::types::layer_of(fty);
                    prism_rtl::is<crate::lower::types::Layer::LyEv>(_m) ? call_then(crate::lower::node_::dynamics::start_event_ref(w, menv_2_7, arg), [=](std::tuple<crate::lower::node_::EvRef, crate::lower::node_::Wx> event_ref_2608) {
                    return ({
                        auto [r, w2] = event_ref_2608;
                        (prism_rtl::finished(std::tuple{lf, cf, mf, rd, crate::lower::node_::connect(w2, r, crate::lower::node_::Sk(crate::lower::node_::Sk::SkRequest{pos_3_7, request_field(tg_4_7, fname)}))}));
                    });
                })
                    : call_then(crate::lower::node_::dynamics::start_dynamic_expr(w, menv_2_7, arg), [=](std::tuple<crate::lower::model::Ex, Array<crate::lower::node_::Read>> dynamic_expr_2830) {
                    return ({
                        auto [ex, rds] = dynamic_expr_2830;
                        call_then(crate::lower::expr::start_value_of(lx_5_7, crate::lower::node_::def::init_env(benv_6_7), arg), [=](crate::lower::types::Vl value_of_3097) {
                        return ({
                            auto cv = crate::lower::types::own(value_of_3097);
                            call_then(crate::lower::expr::start_value_of(lx_5_7, menv_2_7, arg), [=, cv = std::move(cv)](crate::lower::types::Vl value_of_3176) {
                            return ({
                                auto mv = crate::lower::types::own(value_of_3176);
                                (prism_rtl::finished(std::tuple{crate::prelude::push(lf, std::tuple{crate::lower::snake(fname), ex}), crate::prelude::push(cf, std::tuple{crate::lower::snake(fname), cv}), crate::prelude::push(mf, std::tuple{crate::lower::snake(fname), mv}), crate::lower::node_::union_reads(rd, rds), w}));
                            });
                        });
                        });
                    });
                    });
                });
                });
                })
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            }));
            });
        }));
        })));
        auto live = len(reads) > Nat(0u);
        auto [getter, wx3] = std::move(live)
            ? crate::lower::node_::fresh_name(wx2, crate::lower::snake(crate::check::types::bare_name(prism_rtl::deref(tg).name)))
            : std::tuple{Text::lit(""), wx2};
        auto variant = crate::lower::program::variant_of(lx, tg);
        auto level = crate::lower::model::Ex(crate::lower::model::Ex::XCtor{variant, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRecord{struct_path, std::move(live) ? live_fields : method_consts})})});
        auto at_build = crate::lower::model::Ex(crate::lower::model::Ex::XCtor{variant, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRecord{struct_path, const_fields})})});
        auto added = std::move(live)
            ? crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")})), getter, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})
            : at_build;
        auto emits_1 = crate::lower::node_::finish::emits(wx3, pos);
        auto [entry, wx3e] = std::move(emits_1)
            ? std::tuple{Text::lit(""), wx3}
            : crate::lower::node_::fresh_name(wx3, prism_rtl::cat("entry_", crate::lower::model::place_text(pos)));
        auto deep = std::move(emits_1) && crate::lower::program::tag_holds_dyn(lx, tg);
        auto [watch, wx3w] = std::move(deep)
            ? crate::lower::node_::fresh_name(wx3e, prism_rtl::cat("watch_", crate::lower::model::place_text(pos)))
            : std::tuple{Text::lit(""), wx3e};
        auto what = prism_rtl::cat("place ", crate::lower::model::place_text(pos), " (", prism_rtl::deref(tg).name, ") of `", wx.node_, "`");
        auto const_take = std::move(live)
            ? Array<crate::lower::model::Do>{}
            : Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{entry})), Text::lit("take"), Array(std::vector{at_build, crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})})});
        auto wx3h = std::move(emits_1)
            ? wx3w
            : ({
            crate::lower::node_::Wx this_ = wx3w;
            this_.lets = append(crate::prelude::push(this_.lets, crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{entry})), crate::lower::types::entry_ty()}), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("prism_rtl::Entry::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XStr{what})})})})), const_take);
            this_.fields = crate::prelude::push(this_.fields, std::tuple{entry, crate::lower::types::entry_ty(), prism_rtl::cat(what, ", an entry of its host\'s document")});
            this_.moves = crate::prelude::push(this_.moves, std::tuple{entry, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{entry}))})});
            (std::move(this_));
        });
        auto wx3d = std::move(deep)
            ? crate::lower::node_::add_field_last(wx3h, watch, crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("prism_rtl::Watch"), Array<crate::lower::model::OutTy>{}}), prism_rtl::cat("the dynamics place ", crate::lower::model::place_text(pos), "\'s level holds, watched so a move sends it again (doubt WD)"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("prism_rtl::Watch::new"), Array<crate::lower::model::Ex>{}}))
            : wx3h;
        auto sent_2 = std::move(deep)
            ? Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("sent")}), added}), crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCx{})), Text::lit("added"), Array(std::vector{crate::lower::node_::finish::place_at(wx3, Text::lit("node"), pos), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("sent")})), Text::lit("level_pod"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})})})}), crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")})), watch})), Text::lit("renew"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("sent")}))}), crate::lower::model::Ex(crate::lower::model::Ex::XCast{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")}))})), crate::lower::model::OutTy(crate::lower::model::OutTy::OutObj{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Node"), Array<crate::lower::model::OutTy>{}}))})}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})})})
            : Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCx{})), Text::lit("added"), Array(std::vector{crate::lower::node_::finish::place_at(wx3, Text::lit("node"), pos), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(added), Text::lit("level_pod"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})})})})});
        auto wx4 = ({
            crate::lower::node_::Wx this_ = wx3d;
            this_.places = crate::prelude::push(this_.places, crate::lower::node_::Place{.pos = pos, .level = level, .getter = getter, .reads = reads, .entry = entry, .watch = watch});
            this_.build = std::move(emits_1)
                ? std::move(deep)
                ? crate::prelude::push(this_.build, crate::lower::model::Do(crate::lower::model::Do::DoScope{sent_2}))
                : append(this_.build, sent_2)
                : this_.build;
            (std::move(this_));
        });
        return element_output(wx4, menv, tg, element_out(lx, tg, full), pos, bound_opt, at_build);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres>> ElementLine::cycle() const {
    const auto& wx = this->wx;
    const auto& benv = this->benv;
    const auto& menv = this->menv;
    const auto& e = this->e;
    const auto& bound_opt = this->bound_opt;
    auto lx = prism_rtl::deref(wx).lx;
    auto [tag_name, args] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Text, Array<crate::syntax::Arg>>> _v;
        auto&& _m = prism_rtl::deref(prism_rtl::deref(e).kind);
        if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
            auto&& c = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
            auto&& xs = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
            _v.set(std::tuple{tag_name_of(lx, prism_rtl::deref(prism_rtl::deref(c))), xs});
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
            auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
            _v.set(std::tuple{tag_name_of(lx, e), Array<crate::syntax::Arg>{}});
            goto _done;
        }
        {
            _v.set(std::tuple{Text::lit(""), Array<crate::syntax::Arg>{}});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto full = crate::lower::type_at(lx, prism_rtl::deref(e).span);
    return ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(prism_rtl::deref(lx).g).tags, tag_name);
        prism_rtl::is_none(_m) ? ({
        auto wx2 = ({
            crate::lower::node_::Wx this_ = wx;
            this_.build = crate::prelude::push(this_.build, crate::lower::expr::refusal_do(Text::lit("an element of an unknown tag")));
            (std::move(this_));
        });
        (prism_rtl::finished(std::tuple{wx2, crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{})}));
    })
        : prism_rtl::is_some(_m) ? ({
        auto&& tg = prism_rtl::some_of(_m);
        ({
        auto pos = prism_rtl::deref(wx).pos;
        auto wx1 = ({
            crate::lower::node_::Wx this_ = wx;
            this_.pos = crate::lower::model::next_pos(this_.pos);
            (std::move(this_));
        });
        auto struct_path = crate::lower::path_in(lx, prism_rtl::deref(tg).home, crate::lower::tag_struct(prism_rtl::deref(tg).name));
        auto bound_opt_1 = bound_opt;
        auto benv_2 = benv;
        auto menv_3 = menv;
        auto wx_4 = wx;
        call_value(fold_job(prism_rtl::deref(tg).fields, std::tuple{Array<std::tuple<Text, crate::lower::model::Ex>>{}, Array<std::tuple<Text, crate::lower::model::Ex>>{}, Array<std::tuple<Text, crate::lower::model::Ex>>{}, Array<crate::lower::node_::Read>{}, wx1}, ({
        auto args_5 = args;
        auto menv_3_6 = menv_3;
        auto pos_6 = pos;
        auto tg_7 = tg;
        auto lx_8 = lx;
        auto benv_2_9 = benv_2;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, crate::lower::model::Ex>>, Array<std::tuple<Text, crate::lower::model::Ex>>, Array<std::tuple<Text, crate::lower::model::Ex>>, Array<crate::lower::node_::Read>, crate::lower::node_::Wx>>(std::tuple<std::tuple<Array<std::tuple<Text, crate::lower::model::Ex>>, Array<std::tuple<Text, crate::lower::model::Ex>>, Array<std::tuple<Text, crate::lower::model::Ex>>, Array<crate::lower::node_::Read>, crate::lower::node_::Wx>, std::tuple<Text, crate::check::types::Ty>>)>>(prism_rtl::rc([=, args_5 = std::move(args_5), menv_3_6 = std::move(menv_3_6), pos_6 = std::move(pos_6), tg_7 = std::move(tg_7), lx_8 = std::move(lx_8), benv_2_9 = std::move(benv_2_9)](std::tuple<std::tuple<Array<std::tuple<Text, crate::lower::model::Ex>>, Array<std::tuple<Text, crate::lower::model::Ex>>, Array<std::tuple<Text, crate::lower::model::Ex>>, Array<crate::lower::node_::Read>, crate::lower::node_::Wx>, std::tuple<Text, crate::check::types::Ty>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto args_5_9 = args_5;
            auto menv_3_6_9 = menv_3_6;
            auto pos_6_9 = pos_6;
            auto tg_7_9 = tg_7;
            auto lx_8_9 = lx_8;
            auto benv_2_9_9 = benv_2_9;
            entered(once_job([=, args_5_9 = std::move(args_5_9), menv_3_6_9 = std::move(menv_3_6_9), pos_6_9 = std::move(pos_6_9), tg_7_9 = std::move(tg_7_9), lx_8_9 = std::move(lx_8_9), benv_2_9_9 = std::move(benv_2_9_9)]() {
            return ({
                auto [lf, cf, mf, rd, w] = p0;
                auto [fname, fty] = p1;
                ({
                auto&& _m = tag_arg(args_5_9, fname);
                prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{lf, cf, mf, rd, w})
                : prism_rtl::is_some(_m) ? ({
                auto&& arg = prism_rtl::some_of(_m);
                ({
                auto&& _m = crate::lower::types::layer_of(fty);
                prism_rtl::is<crate::lower::types::Layer::LyEv>(_m) ? call_then(crate::lower::node_::dynamics::start_event_ref(w, menv_3_6_9, arg), [=](std::tuple<crate::lower::node_::EvRef, crate::lower::node_::Wx> event_ref_2608) {
                return ({
                    auto [r, w2] = event_ref_2608;
                    (prism_rtl::finished(std::tuple{lf, cf, mf, rd, crate::lower::node_::connect(w2, r, crate::lower::node_::Sk(crate::lower::node_::Sk::SkRequest{pos_6_9, request_field(tg_7_9, fname)}))}));
                });
            })
                : call_then(crate::lower::node_::dynamics::start_dynamic_expr(w, menv_3_6_9, arg), [=](std::tuple<crate::lower::model::Ex, Array<crate::lower::node_::Read>> dynamic_expr_2830) {
                return ({
                    auto [ex, rds] = dynamic_expr_2830;
                    call_then(crate::lower::expr::start_value_of(lx_8_9, crate::lower::node_::def::init_env(benv_2_9_9), arg), [=](crate::lower::types::Vl value_of_3097) {
                    return ({
                        auto cv = crate::lower::types::own(value_of_3097);
                        call_then(crate::lower::expr::start_value_of(lx_8_9, menv_3_6_9, arg), [=, cv = std::move(cv)](crate::lower::types::Vl value_of_3176) {
                        return ({
                            auto mv = crate::lower::types::own(value_of_3176);
                            (prism_rtl::finished(std::tuple{crate::prelude::push(lf, std::tuple{crate::lower::snake(fname), ex}), crate::prelude::push(cf, std::tuple{crate::lower::snake(fname), cv}), crate::prelude::push(mf, std::tuple{crate::lower::snake(fname), mv}), crate::lower::node_::union_reads(rd, rds), w}));
                        });
                    });
                    });
                });
                });
            });
            });
            })
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    }));
    })), [=, struct_path = std::move(struct_path), bound_opt_1 = std::move(bound_opt_1), wx_4 = std::move(wx_4)](std::tuple<Array<std::tuple<Text, crate::lower::model::Ex>>, Array<std::tuple<Text, crate::lower::model::Ex>>, Array<std::tuple<Text, crate::lower::model::Ex>>, Array<crate::lower::node_::Read>, crate::lower::node_::Wx> fold_2276) {
        return ({
            auto [live_fields, const_fields, method_consts, reads, wx2] = fold_2276;
            auto live = len(reads) > Nat(0u);
            auto [getter, wx3] = std::move(live)
                ? crate::lower::node_::fresh_name(wx2, crate::lower::snake(crate::check::types::bare_name(prism_rtl::deref(tg).name)))
                : std::tuple{Text::lit(""), wx2};
            auto variant = crate::lower::program::variant_of(lx, tg);
            auto level = crate::lower::model::Ex(crate::lower::model::Ex::XCtor{variant, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRecord{struct_path, std::move(live) ? live_fields : method_consts})})});
            auto at_build = crate::lower::model::Ex(crate::lower::model::Ex::XCtor{variant, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRecord{struct_path, const_fields})})});
            auto added = std::move(live)
                ? crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")})), getter, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})
                : at_build;
            auto emits_5 = crate::lower::node_::finish::emits(wx3, pos);
            auto [entry, wx3e] = std::move(emits_5)
                ? std::tuple{Text::lit(""), wx3}
                : crate::lower::node_::fresh_name(wx3, prism_rtl::cat("entry_", crate::lower::model::place_text(pos)));
            auto deep = std::move(emits_5) && crate::lower::program::tag_holds_dyn(lx, tg);
            auto [watch, wx3w] = std::move(deep)
                ? crate::lower::node_::fresh_name(wx3e, prism_rtl::cat("watch_", crate::lower::model::place_text(pos)))
                : std::tuple{Text::lit(""), wx3e};
            auto what = prism_rtl::cat("place ", crate::lower::model::place_text(pos), " (", prism_rtl::deref(tg).name, ") of `", prism_rtl::deref(wx_4).node_, "`");
            auto const_take = std::move(live)
                ? Array<crate::lower::model::Do>{}
                : Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{entry})), Text::lit("take"), Array(std::vector{at_build, crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})})});
            auto wx3h = std::move(emits_5)
                ? wx3w
                : ({
                crate::lower::node_::Wx this_ = wx3w;
                this_.lets = append(crate::prelude::push(this_.lets, crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{entry})), crate::lower::types::entry_ty()}), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("prism_rtl::Entry::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XStr{what})})})})), const_take);
                this_.fields = crate::prelude::push(this_.fields, std::tuple{entry, crate::lower::types::entry_ty(), prism_rtl::cat(what, ", an entry of its host\'s document")});
                this_.moves = crate::prelude::push(this_.moves, std::tuple{entry, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{entry}))})});
                (std::move(this_));
            });
            auto wx3d = std::move(deep)
                ? crate::lower::node_::add_field_last(wx3h, watch, crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("prism_rtl::Watch"), Array<crate::lower::model::OutTy>{}}), prism_rtl::cat("the dynamics place ", crate::lower::model::place_text(pos), "\'s level holds, watched so a move sends it again (doubt WD)"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("prism_rtl::Watch::new"), Array<crate::lower::model::Ex>{}}))
                : wx3h;
            auto sent_6 = std::move(deep)
                ? Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("sent")}), added}), crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCx{})), Text::lit("added"), Array(std::vector{crate::lower::node_::finish::place_at(wx3, Text::lit("node"), pos), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("sent")})), Text::lit("level_pod"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})})})}), crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")})), watch})), Text::lit("renew"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("sent")}))}), crate::lower::model::Ex(crate::lower::model::Ex::XCast{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")}))})), crate::lower::model::OutTy(crate::lower::model::OutTy::OutObj{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Node"), Array<crate::lower::model::OutTy>{}}))})}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})})})
                : Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCx{})), Text::lit("added"), Array(std::vector{crate::lower::node_::finish::place_at(wx3, Text::lit("node"), pos), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(added), Text::lit("level_pod"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})})})})});
            auto wx4 = ({
                crate::lower::node_::Wx this_ = wx3d;
                this_.places = crate::prelude::push(this_.places, crate::lower::node_::Place{.pos = pos, .level = level, .getter = getter, .reads = reads, .entry = entry, .watch = watch});
                this_.build = std::move(emits_5)
                    ? std::move(deep)
                    ? crate::prelude::push(this_.build, crate::lower::model::Do(crate::lower::model::Do::DoScope{sent_6}))
                    : append(this_.build, sent_6)
                    : this_.build;
                (std::move(this_));
            });
            (prism_rtl::finished(element_output(wx4, menv_3, tg, element_out(lx, tg, full), pos, bound_opt_1, at_build)));
        });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ElementLine, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres>> start_element_line(crate::lower::node_::Wx wx, crate::lower::types::Env benv, crate::lower::types::Env menv, crate::syntax::Expr e, std::optional<crate::lower::types::Bn> bound_opt) {
    return prism_rtl::make_rc<ElementLine>(wx, benv, menv, e, bound_opt);
}


/// ElementOut: unbounded fn Lx, TagInfo, Ty -> OutTy
crate::lower::model::OutTy element_out(const crate::lower::Lx& lx, const crate::check::env::TagInfo& tg, const crate::check::types::Ty& full) {
    auto t = ({
        __label__ _done;
        prism_rtl::Slot<crate::lower::model::OutTy> _v;
        auto&& _m = crate::lower::types::peel(full);
        if (prism_rtl::is<crate::check::types::Ty::TyElem>(_m)) {
            auto&& o = prism_rtl::as<crate::check::types::Ty::TyElem>(_m).a1;
            _v.set(crate::lower::types::out_ty_of(lx, crate::lower::types::peel(prism_rtl::deref(o))));
            goto _done;
        }
        {
            _v.set(crate::lower::types::out_ty_of(lx, crate::lower::types::peel(tg.out)));
            goto _done;
        }
    _done:
        _v.take();
    });
    if (prism_rtl::is<crate::lower::model::OutTy::OutGen>(t)) {
        return crate::lower::model::OutTy(crate::lower::model::OutTy::OutPod{});
    }
    {
        return t;
    }
}


/// TagNameOf: fn Lx, Expr -> Text
Text tag_name_of(const crate::lower::Lx& lx, const crate::syntax::Expr& c) {
    auto&& _m = prism_rtl::deref(c.kind);
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        auto&& _qk_opt = crate::check::env::names::resolve_value(lx.g, lx.home, n);
        auto&& qk_opt = std::get<0>(_qk_opt);
        return or_(qk_opt, crate::check::env::dotted(n->path_));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return tag_name_of(lx, prism_rtl::deref(prism_rtl::deref(x)));
    }
    {
        return Text::lit("");
    }
}


/// ?TagArg: fn [Arg], Text -> ?Expr
std::optional<crate::syntax::Expr> tag_arg(const Array<crate::syntax::Arg>& args, const Text& fname) {
    return fold(args, std::optional<crate::syntax::Expr>{}, [&](const std::optional<crate::syntax::Expr>& found_opt, const crate::syntax::Arg& a) {
        return ({
            __label__ _done;
            prism_rtl::Slot<std::optional<crate::syntax::Expr>> _v;
            auto&& _m = prism_rtl::deref(a).name;
            if (prism_rtl::is_some(_m)) {
                auto&& n = prism_rtl::some_of(_m);
                _v.set(prism_rtl::deref(n).name == fname ? std::optional(a->value) : found_opt);
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(found_opt);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
}


/// RequestField: fn TagInfo, Text -> Text
Text request_field(const crate::check::env::TagInfo& tg, const Text& fname) {
    auto evs = filter(tg.fields, [&](const std::tuple<Text, crate::check::types::Ty>& _p0) {
        auto&& t = std::get<1>(_p0);
        return crate::lower::types::layer_of(t) == crate::lower::types::Layer(crate::lower::types::Layer::LyEv{});
    });
    return len(evs) > Nat(1u) ? fname : Text::lit("");
}


/// ElementOutput: unbounded fn Wx, Env, TagInfo, OutTy, Pos, ?Bn, Ex -> ((Wx, Wres))
std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> element_output(const crate::lower::node_::Wx& wx, const crate::lower::types::Env& menv, const crate::check::env::TagInfo& tg, const crate::lower::model::OutTy& out, const crate::lower::model::Pos_& pos, const std::optional<crate::lower::types::Bn>& bound_opt, const crate::lower::model::Ex& level) {
    auto lx = wx.lx;
    if (prism_rtl::is_some(bound_opt) && prism_rtl::is<crate::lower::types::Bn::BnParts>(prism_rtl::some_of(bound_opt))) {
        auto&& parts = prism_rtl::as<crate::lower::types::Bn::BnParts>(prism_rtl::some_of(bound_opt)).a0;
        return bundle_output(wx, tg, out, pos, parts, level);
    }
    {
        return element_output_of(wx, menv, tg, out, pos, bound_opt, level);
    }
}


/// BundleOutput: unbounded fn Wx, TagInfo, OutTy, Pos, [?Bn], Ex -> ((Wx, Wres))
std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> bundle_output(const crate::lower::node_::Wx& wx, const crate::check::env::TagInfo& tg, const crate::lower::model::OutTy& out, const crate::lower::model::Pos_& pos, const Array<std::optional<crate::lower::types::Bn>>& parts, const crate::lower::model::Ex& level) {
    return !crate::lower::node_::finish::emits(wx, pos)
        ? ({
        auto wx2 = ({
            crate::lower::node_::Wx this_ = wx;
            this_.build = crate::prelude::push(this_.build, crate::lower::expr::refusal_do(prism_rtl::cat("a bundle (", tg.name, ") in a hosted scope")));
            (std::move(this_));
        });
        std::tuple{wx2, crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{})};
    })
        : bundle_output_of(wx, tg, out, pos, parts, level);
}


/// BundleOutputOf: unbounded fn Wx, TagInfo, OutTy, Pos, [?Bn], Ex -> ((Wx, Wres))
std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> bundle_output_of(const crate::lower::node_::Wx& wx, const crate::check::env::TagInfo& tg, const crate::lower::model::OutTy& out, const crate::lower::model::Pos_& pos, const Array<std::optional<crate::lower::types::Bn>>& parts, const crate::lower::model::Ex& level) {
    auto layers = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::lower::types::Layer>> _v;
        auto&& _m = tg.out;
        if (prism_rtl::is<crate::check::types::Ty::TyTuple>(_m)) {
            auto&& cs = prism_rtl::as<crate::check::types::Ty::TyTuple>(_m).a0;
            _v.set(each(cs, [&](const crate::check::types::Ty& c) { return crate::lower::types::layer_of(c); }));
            goto _done;
        }
        {
            _v.set(Array<crate::lower::types::Layer>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto tys = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::lower::model::OutTy>> _v;
        if (prism_rtl::is<crate::lower::model::OutTy::OutTuple>(out)) {
            auto&& ts = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(out).a0;
            _v.set(ts);
            goto _done;
        }
        {
            _v.set(Array<crate::lower::model::OutTy>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto idx = crate::check::errors::range0(len(layers));
    auto plain_ix = filter(idx, [&](const Nat& i) { return or_(index(layers, i), crate::lower::types::Layer(crate::lower::types::Layer::LyPlain{})) == crate::lower::types::Layer(crate::lower::types::Layer::LyPlain{}); });
    auto ev_ix = filter(idx, [&](const Nat& i) { return or_(index(layers, i), crate::lower::types::Layer(crate::lower::types::Layer::LyPlain{})) == crate::lower::types::Layer(crate::lower::types::Layer::LyEv{}); });
    auto dyn_ix = filter(idx, [&](const Nat& i) { return or_(index(layers, i), crate::lower::types::Layer(crate::lower::types::Layer::LyPlain{})) == crate::lower::types::Layer(crate::lower::types::Layer::LyDyn{}); });
    auto wx1 = bundle_first(wx, tg, pos, plain_ix, tys, parts, level);
    auto wx2 = fold(ev_ix, wx1, [&](const crate::lower::node_::Wx& w, const Nat& i) { return bundle_answer(w, pos, or_(index(tys, i), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})), or_(index(parts, i), std::optional<crate::lower::types::Bn>{})); });
    return (len(ev_ix) > Nat(1u)) || (len(dyn_ix) > Nat(0u))
        ? ({
        auto wx3 = ({
            crate::lower::node_::Wx this_ = wx2;
            this_.build = crate::prelude::push(this_.build, crate::lower::expr::refusal_do(prism_rtl::cat("a bundle with a `$` part or two event parts (", tg.name, ")")));
            (std::move(this_));
        });
        std::tuple{wx3, crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{})};
    })
        : std::tuple{wx2, crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{})};
}


/// BundleFirst: unbounded fn Wx, TagInfo, Pos, [Nat], [OutTy], [?Bn], Ex -> Wx
crate::lower::node_::Wx bundle_first(const crate::lower::node_::Wx& wx, const crate::check::env::TagInfo& tg, const crate::lower::model::Pos_& pos, const Array<Nat>& plain_ix, const Array<crate::lower::model::OutTy>& tys, const Array<std::optional<crate::lower::types::Bn>>& parts, const crate::lower::model::Ex& level) {
    {
        auto&& m10024_0 = plain_ix;
        if (m10024_0.size() == 0u) {
            return wx;
        }
    }
    {
        auto one = len(plain_ix) == Nat(1u);
        auto plain_ty = std::move(one)
            ? or_(index(tys, or_(index(plain_ix, Nat(0u)), Nat(0u))), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}))
            : crate::lower::model::OutTy(crate::lower::model::OutTy::OutTuple{each(plain_ix, [&](const Nat& i) { return or_(index(tys, i), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})); })});
        auto wx1 = ({
            crate::lower::node_::Wx this_ = wx;
            this_.lets = append(this_.lets, Array(std::vector{first_value_let(wx, pos, tg, level), crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{prism_rtl::cat("bundle_", crate::lower::model::place_text(pos))}), crate::lower::model::Ex(crate::lower::model::Ex::XDecode{plain_ty, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat("first_", crate::lower::model::place_text(pos))}))}))})})}));
            this_.fallible = true;
            (std::move(this_));
        });
        return fold(crate::check::errors::range0(len(plain_ix)), wx1, [&](const crate::lower::node_::Wx& w, const Nat& k) {
            return ({
                auto i = or_(index(plain_ix, k), Nat(0u));
                ({
                __label__ _done;
                prism_rtl::Slot<crate::lower::node_::Wx> _v;
                auto&& _m = index(parts, i);
                if (prism_rtl::is_some(_m) && prism_rtl::is_some(prism_rtl::some_of(_m)) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(prism_rtl::some_of(_m)))) {
                    auto&& rs = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(prism_rtl::some_of(_m))).a0;
                    _v.set(({
                        auto f = crate::lower::types::place_stem(rs);
                        auto part = one
                            ? crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat("bundle_", crate::lower::model::place_text(pos))})
                            : crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XPart{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat("bundle_", crate::lower::model::place_text(pos))})), k}))});
                        ({
                        crate::lower::node_::Wx this_ = w;
                        this_.lets = crate::prelude::push(this_.lets, crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{f}), part}));
                        this_.fields = crate::prelude::push(this_.fields, std::tuple{f, or_(index(tys, i), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})), prism_rtl::cat("place ", crate::lower::model::place_text(pos), "\'s answer, part ", i, " of its first value")});
                        this_.inits = crate::prelude::push(this_.inits, std::tuple{f, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{f}))})});
                        (std::move(this_));
                    });
                    }));
                    goto _done;
                }
                {
                    _v.set(w);
                    goto _done;
                }
            _done:
                _v.take();
            });
            });
        });
    }
}


/// BundleAnswer: fn Wx, Pos, OutTy, ?Bn -> Wx
crate::lower::node_::Wx bundle_answer(const crate::lower::node_::Wx& wx, const crate::lower::model::Pos_& pos, const crate::lower::model::OutTy& et, const std::optional<crate::lower::types::Bn>& b_opt) {
    auto t = ({
        __label__ _done;
        prism_rtl::Slot<crate::lower::model::OutTy> _v;
        if (prism_rtl::is<crate::lower::model::OutTy::OutEvent>(et)) {
            auto&& inner = prism_rtl::as<crate::lower::model::OutTy::OutEvent>(et).a0;
            _v.set(prism_rtl::deref(prism_rtl::deref(inner)));
            goto _done;
        }
        {
            _v.set(et);
            goto _done;
        }
    _done:
        _v.take();
    });
    auto [id, wx2] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Nat, crate::lower::node_::Wx>> _v;
        if (prism_rtl::is_some(b_opt) && prism_rtl::is<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(b_opt))) {
            auto&& er = prism_rtl::as<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(b_opt)).a0;
            _v.set(std::tuple{prism_rtl::deref(er).node_, wx});
            goto _done;
        }
        {
            _v.set(({
                auto [nm, w] = crate::lower::node_::fresh_name(wx, prism_rtl::cat("place_", crate::lower::model::place_text(pos)));
                (crate::lower::node_::add_gn(w, nm, t, crate::lower::node_::GnKind(crate::lower::node_::GnKind::GnAnswer{}), Nat(0u)));
            }));
            goto _done;
        }
    _done:
        _v.take();
    });
    crate::lower::node_::Wx this_ = wx2;
    this_.answers = crate::prelude::push(this_.answers, std::tuple{pos, id, t, Text::lit("")});
    return this_;
}


/// FirstValueLet: fn Wx, Pos, TagInfo, Ex -> Do
crate::lower::model::Do first_value_let(const crate::lower::node_::Wx& wx, const crate::lower::model::Pos_& pos, const crate::check::env::TagInfo& tg, const crate::lower::model::Ex& level) {
    auto missing = crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Fault::answer"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XStr{prism_rtl::cat("no first value for ", tg.name)})})});
    return crate::lower::node_::finish::emits(wx, pos)
        ? ({
        auto asked = crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCx{})), Text::lit("first_value"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(level), Text::lit("to_pod"), Array<crate::lower::model::Ex>{}}))})})});
        (crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{prism_rtl::cat("first_", crate::lower::model::place_text(pos))}), crate::lower::expr::try_of(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(asked), Text::lit("ok_or"), Array(std::vector{missing})}))}));
    })
        : ({
        auto host = host_local(wx, pos);
        auto entry = or_(fold(wx.places, std::optional<Text>{}, [&](const std::optional<Text>& e_opt, const crate::lower::node_::Place& pl) { return prism_rtl::deref(pl).pos == pos ? std::optional(pl->entry) : e_opt; }), Text::lit(""));
        auto asked = crate::lower::expr::try_of(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{host})), Text::lit("first_value"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::node_::finish::place_at(wx, Text::lit(""), pos))}), crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(level)}), crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{entry}))}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}));
        (crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{prism_rtl::cat("first_", crate::lower::model::place_text(pos))}), crate::lower::expr::try_of(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::expr::try_of(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(asked), Text::lit("ok_or"), Array(std::vector{missing})}))), answer_accessor(tg), Array<crate::lower::model::Ex>{}}))}));
    });
}


/// HostLocal: fn Wx, Pos -> Text
Text host_local(const crate::lower::node_::Wx& wx, const crate::lower::model::Pos_& pos) {
    return pos.scope == Nat(0u)
        ? Text::lit("enclosing")
        : or_(index(wx.scopes, crate::syntax::lexer::chars::dec(pos.scope)), Text::lit(""));
}


/// AnswerVariant: fn TagInfo -> Text
Text answer_variant(const crate::check::env::TagInfo& tg) {
    return prism_rtl::cat("crate::Answer::", crate::lower::tag_struct(tg.name));
}


/// AnswerAccessor: fn TagInfo -> Text
Text answer_accessor(const crate::check::env::TagInfo& tg) {
    return crate::lower::snake(crate::lower::tag_struct(tg.name));
}


/// ElementOutputOf: unbounded fn Wx, Env, TagInfo, OutTy, Pos, ?Bn, Ex -> ((Wx, Wres))
std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> element_output_of(const crate::lower::node_::Wx& wx, const crate::lower::types::Env& menv, const crate::check::env::TagInfo& tg, const crate::lower::model::OutTy& out, const crate::lower::model::Pos_& pos, const std::optional<crate::lower::types::Bn>& bound_opt, const crate::lower::model::Ex& level) {
    auto lx = wx.lx;
    auto&& _m = crate::lower::types::layer_of(tg.out);
    if (prism_rtl::is<crate::lower::types::Layer::LyEv>(_m)) {
        auto [id, wx2] = ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<Nat, crate::lower::node_::Wx>> _v;
            if (prism_rtl::is_some(bound_opt) && prism_rtl::is<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(bound_opt))) {
                auto&& er = prism_rtl::as<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(bound_opt)).a0;
                _v.set(std::tuple{prism_rtl::deref(er).node_, wx});
                goto _done;
            }
            {
                _v.set(({
                    auto [nm, w] = crate::lower::node_::fresh_name(wx, prism_rtl::cat("place_", crate::lower::model::place_text(pos)));
                    (crate::lower::node_::add_gn(w, nm, out, crate::lower::node_::GnKind(crate::lower::node_::GnKind::GnAnswer{}), Nat(0u)));
                }));
                goto _done;
            }
        _done:
            _v.take();
        });
        auto wx3 = ({
            crate::lower::node_::Wx this_ = wx2;
            this_.answers = crate::prelude::push(this_.answers, std::tuple{pos, id, out, answer_accessor(tg)});
            (std::move(this_));
        });
        return std::tuple{wx3, crate::lower::node_::Wres(crate::lower::node_::Wres::WrEv{crate::lower::node_::ev_ref_of(wx3, id)})};
    }
    if (prism_rtl::is<crate::lower::types::Layer::LyDyn>(_m)) {
        auto [f, wx1] = ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<Text, crate::lower::node_::Wx>> _v;
            if (prism_rtl::is_some(bound_opt) && prism_rtl::is<crate::lower::types::Bn::BnHold>(prism_rtl::some_of(bound_opt))) {
                auto&& hf = prism_rtl::as<crate::lower::types::Bn::BnHold>(prism_rtl::some_of(bound_opt)).a0;
                _v.set(std::tuple{hf, wx});
                goto _done;
            }
            {
                _v.set(crate::lower::node_::fresh_name(wx, prism_rtl::cat("place_", crate::lower::model::place_text(pos))));
                goto _done;
            }
        _done:
            _v.take();
        });
        auto emits_1 = crate::lower::node_::finish::emits(wx, pos);
        auto first__2 = std::move(emits_1)
            ? crate::lower::model::Ex(crate::lower::model::Ex::XDecode{out, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat("first_", crate::lower::model::place_text(pos))}))}))})
            : crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat("first_", crate::lower::model::place_text(pos))});
        auto wx2 = ({
            crate::lower::node_::Wx this_ = wx1;
            this_.lets = crate::prelude::push(this_.lets, first_value_let(wx, pos, tg, level));
            this_.fields = crate::prelude::push(this_.fields, std::tuple{f, crate::lower::model::OutTy(crate::lower::model::OutTy::OutHold{prism_rtl::rc(out)}), prism_rtl::cat("pushed to place ", crate::lower::model::place_text(pos))});
            this_.inits = crate::prelude::push(this_.inits, std::tuple{f, crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Hold::new"), Array(std::vector{first__2, crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})});
            this_.dyn_places = crate::prelude::push(this_.dyn_places, std::tuple{pos, f, out, answer_accessor(tg)});
            this_.fallible = true;
            (std::move(this_));
        });
        auto wx3 = std::move(emits_1)
            ? ({
            crate::lower::node_::Wx this_ = wx2;
            this_.lets = crate::prelude::push(this_.lets, crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{prism_rtl::cat(f, "_element")}), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(level), Text::lit("to_pod"), Array<crate::lower::model::Ex>{}})}));
            this_.fields = crate::prelude::push(this_.fields, std::tuple{prism_rtl::cat(f, "_element"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutPod{}), prism_rtl::cat("place ", crate::lower::model::place_text(pos), "\'s element, which pushes are keyed by")});
            this_.moves = crate::prelude::push(this_.moves, std::tuple{prism_rtl::cat(f, "_element"), crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat(f, "_element")}))})});
            this_.build = crate::prelude::push(this_.build, crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCx{})), Text::lit("listen"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")})), prism_rtl::cat(f, "_element")}))}), crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCast{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")}))})), crate::lower::model::OutTy(crate::lower::model::OutTy::OutObj{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Node"), Array<crate::lower::model::OutTy>{}}))})}))})})})}));
            (std::move(this_));
        })
            : wx2;
        return std::tuple{wx3, crate::lower::node_::Wres(crate::lower::node_::Wres::WrDyn{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(f)})), Text::lit("get"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), Array(std::vector{crate::lower::node_::Read(crate::lower::node_::Read::OwnRead{f})}), out})};
    }
    {
        if (prism_rtl::is_some(bound_opt) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(bound_opt))) {
            auto&& rs = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(bound_opt)).a0;
            auto f = crate::lower::types::place_stem(rs);
            auto first__1 = crate::lower::node_::finish::emits(wx, pos)
                ? crate::lower::model::Ex(crate::lower::model::Ex::XDecode{out, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat("first_", crate::lower::model::place_text(pos))}))}))})
                : crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat("first_", crate::lower::model::place_text(pos))});
            auto wx2 = ({
                crate::lower::node_::Wx this_ = wx;
                this_.lets = append(this_.lets, Array(std::vector{first_value_let(wx, pos, tg, level), crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{f}), first__1})}));
                this_.fields = crate::prelude::push(this_.fields, std::tuple{f, out, prism_rtl::cat("place ", crate::lower::model::place_text(pos), "\'s answer, its first value")});
                this_.inits = crate::prelude::push(this_.inits, std::tuple{f, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{f}))})});
                this_.fallible = true;
                (std::move(this_));
            });
            return std::tuple{wx2, crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{})};
        }
        {
            return std::tuple{wx, crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{})};
        }
    }
}

}  // namespace crate::lower::node_::elements
