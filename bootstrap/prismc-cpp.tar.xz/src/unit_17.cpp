// The module `Check.Passes.Borrows`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <check/passes/borrows/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>

// The module `Check.Passes.Borrows`, from `target/bootstrap/cpp-src/prismc/check/passes/borrows.prism`.
namespace crate::check::passes::borrows {

/// IsLocalType: unbounded fn St, Ty -> Bool
bool is_local_type_f(const crate::check::types::St& st_p0, const crate::check::types::Ty& t_p1) {
    auto&& _m = crate::check::types::recording::walk_f(st_p0, t_p1);
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
        auto&& m1393_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
        if (m1393_0_0 == Text::lit("Buffer")) {
            return true;
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
        auto&& m1393_1_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
        if (m1393_1_0 == Text::lit("Table")) {
            return true;
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(_m)) {
        auto&& e_p2 = prism_rtl::as<crate::check::types::Ty::TyArray>(_m).a0;
        return is_local_type_f(st_p0, prism_rtl::deref(e_p2));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(_m)) {
        auto&& ts_p3 = prism_rtl::as<crate::check::types::Ty::TyTuple>(_m).a0;
        return crate::prelude::run_to_end(crate::prelude::fold_job(ts_p3, false, ({
            auto st_p0x = st_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=, st_p0x = std::move(st_p0x)](std::tuple<bool, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto st_p0xy = st_p0x;
                (crate::prelude::entered(crate::prelude::once_job([=, st_p0xy = std::move(st_p0xy)]() {
                return ({
                    auto seen_p4 = p0;
                    auto x_p5 = p1;
                    (prism_rtl::finished(std::move(seen_p4) || is_local_type_f(st_p0xy, x_p5)));
                });
            })));
            });
        })));
        })));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(_m)) {
        auto&& k_p6 = prism_rtl::as<crate::check::types::Ty::TyMap>(_m).a0;
        auto&& v_p7 = prism_rtl::as<crate::check::types::Ty::TyMap>(_m).a1;
        return is_local_type_f(st_p0, prism_rtl::deref(k_p6)) || is_local_type_f(st_p0, prism_rtl::deref(v_p7));
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(_m)) {
        auto&& i_p8 = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a1;
        return is_local_type_f(st_p0, prism_rtl::deref(i_p8));
    }
    {
        return false;
    }
}


prism_rtl::Turn<bool> IsLocalType::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& t_p1 = this->t_p1;
    auto st_p0x = st_p0;
    auto t_p1x = t_p1;
    return crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p0x, t_p1x), [=](crate::check::types::Ty walk_f_1399) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TyCon>(walk_f_1399) && ({
            auto&& m1393_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_f_1399).a0;
            (m1393_0_0 == Text::lit("Buffer"));
        }) ? ({
            auto&& m1393_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_f_1399).a0;
            prism_rtl::finished(true);
        })
            : prism_rtl::is<crate::check::types::Ty::TyCon>(walk_f_1399) && ({
            auto&& m1393_1_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_f_1399).a0;
            (m1393_1_0 == Text::lit("Table"));
        }) ? ({
            auto&& m1393_1_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_f_1399).a0;
            prism_rtl::finished(true);
        })
            : prism_rtl::is<crate::check::types::Ty::TyArray>(walk_f_1399) ? ({
            auto&& e_p2 = prism_rtl::as<crate::check::types::Ty::TyArray>(walk_f_1399).a0;
            prism_rtl::more(prism_rtl::rc(IsLocalType(st_p0x, prism_rtl::deref(e_p2))));
        })
            : prism_rtl::is<crate::check::types::Ty::TyTuple>(walk_f_1399) ? ({
            auto&& ts_p3 = prism_rtl::as<crate::check::types::Ty::TyTuple>(walk_f_1399).a0;
            crate::prelude::fold_job(ts_p3, false, ({
            auto st_p0xx = st_p0x;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=, st_p0xx = std::move(st_p0xx)](std::tuple<bool, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto st_p0xxy = st_p0xx;
                (crate::prelude::entered(crate::prelude::once_job([=, st_p0xxy = std::move(st_p0xxy)]() {
                return ({
                    auto seen_p4 = p0;
                    auto x_p5 = p1;
                    (prism_rtl::finished(std::move(seen_p4) || is_local_type_f(st_p0xxy, x_p5)));
                });
            })));
            });
        })));
        }))->cycle();
        })
            : prism_rtl::is<crate::check::types::Ty::TyMap>(walk_f_1399) ? ({
            auto&& k_p6 = prism_rtl::as<crate::check::types::Ty::TyMap>(walk_f_1399).a0;
            auto&& v_p7 = prism_rtl::as<crate::check::types::Ty::TyMap>(walk_f_1399).a1;
            crate::prelude::call_then(start_is_local_type_f(st_p0x, prism_rtl::deref(k_p6)), [=](bool is_local_type_f_1595) { return prism_rtl::finished(is_local_type_f_1595 || is_local_type_f(st_p0x, prism_rtl::deref(v_p7))); });
        })
            : prism_rtl::is<crate::check::types::Ty::TySig>(walk_f_1399) ? ({
            auto&& i_p8 = prism_rtl::as<crate::check::types::Ty::TySig>(walk_f_1399).a1;
            prism_rtl::more(prism_rtl::rc(IsLocalType(st_p0x, prism_rtl::deref(i_p8))));
        })
            : prism_rtl::finished(false);
        });
    });
}


/// `Start IsLocalType, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_is_local_type_f(crate::check::types::St st_p0, crate::check::types::Ty t_p1) {
    return prism_rtl::make_rc<IsLocalType>(st_p0, t_p1);
}


/// AndBlockChecks: unbounded fn Env, St, Block, Ty -> St
crate::check::types::St and_block_checks_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Block& b_p2, const crate::check::types::Ty& t_p3) {
    auto st1_p4 = is_local_type_f(st_p1, t_p3)
        ? crate::check::types::recording::err_fix_f(st_p1, Text::lit("local-escapes"), b_p2.span_p, prism_rtl::cat("a `", block_local_name_f(st_p1, t_p3), "` cannot leave its block"), Text::lit("`Freeze` it into a plain value first"))
        : st_p1;
    auto st2_p5 = escape_stmts_f(env_p0, st1_p4, b_p2.stmts_p);
    auto&& _st3_p6 = frozen_stmts_f(env_p0, st2_p5, b_p2.stmts_p, Map<Text, Nat>{});
    auto&& st3_p6 = std::get<1>(_st3_p6);
    return borrow_stmts_f(env_p0, st3_p6, b_p2.stmts_p, Array<Array<Text>>{});
}


prism_rtl::Turn<crate::check::types::St> AndBlockChecks::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& b_p2 = this->b_p2;
    const auto& t_p3 = this->t_p3;
    auto b_p2x = b_p2;
    auto env_p0x = env_p0;
    auto st_p1x = st_p1;
    auto t_p3x = t_p3;
    return crate::prelude::call_then(start_is_local_type_f(st_p1x, t_p3x), [=](bool is_local_type_f_1949) {
        return ({
            auto st1_p4 = is_local_type_f_1949
                ? crate::check::types::recording::err_fix_f(st_p1x, Text::lit("local-escapes"), prism_rtl::deref(b_p2x).span_p, prism_rtl::cat("a `", block_local_name_f(st_p1x, t_p3x), "` cannot leave its block"), Text::lit("`Freeze` it into a plain value first"))
                : st_p1x;
            (crate::prelude::call_then(start_escape_stmts_f(env_p0x, st1_p4, prism_rtl::deref(b_p2x).stmts_p), [=](crate::check::types::St escape_stmts_f_2119) {
            return ({
                auto st2_p5 = escape_stmts_f_2119;
                (crate::prelude::call_then(start_frozen_stmts_f(env_p0x, st2_p5, prism_rtl::deref(b_p2x).stmts_p, Map<Text, Nat>{}), [=](std::tuple<Map<Text, Nat>, crate::check::types::St> frozen_stmts_f_2175) {
                return ({
                    auto&& _st3_p6 = frozen_stmts_f_2175;
                    auto&& st3_p6 = std::get<1>(_st3_p6);
                    (prism_rtl::more(prism_rtl::rc(BorrowStmts(env_p0x, st3_p6, prism_rtl::deref(b_p2x).stmts_p, Array<Array<Text>>{}))));
                });
            }));
            });
        }));
        });
    });
}


/// `Start AndBlockChecks, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_and_block_checks_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Block b_p2, crate::check::types::Ty t_p3) {
    return prism_rtl::make_rc<AndBlockChecks>(env_p0, st_p1, b_p2, t_p3);
}


/// BlockLocalName: unbounded fn St, Ty -> Text
Text block_local_name_f(const crate::check::types::St& st_p0, const crate::check::types::Ty& t_p1) {
    auto&& _m = crate::check::types::recording::walk_f(st_p0, t_p1);
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
        auto&& n_p2 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
        return n_p2;
    }
    {
        return Text::lit("Buffer");
    }
}


prism_rtl::Turn<Text> BlockLocalName::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& t_p1 = this->t_p1;
    auto st_p0x = st_p0;
    auto t_p1x = t_p1;
    return crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p0x, t_p1x), [=](crate::check::types::Ty walk_f_2326) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TyCon>(walk_f_2326) ? ({
            auto&& n_p2 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_f_2326).a0;
            prism_rtl::finished(n_p2);
        })
            : prism_rtl::finished(Text::lit("Buffer"));
        });
    });
}


/// `Start BlockLocalName, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_block_local_name_f(crate::check::types::St st_p0, crate::check::types::Ty t_p1) {
    return prism_rtl::make_rc<BlockLocalName>(st_p0, t_p1);
}


/// EscapeStmts: unbounded fn Env, St, [Stmt] -> St
crate::check::types::St escape_stmts_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const Array<crate::syntax::Stmt>& stmts_p2) {
    return crate::prelude::run_to_end(crate::prelude::fold_job(stmts_p2, st_p1, ({
        auto env_p0x = env_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::Stmt>)>>(prism_rtl::rc([=, env_p0x = std::move(env_p0x)](std::tuple<crate::check::types::St, crate::syntax::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_p0xy = env_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, env_p0xy = std::move(env_p0xy)]() {
            return ({
                auto s_p3 = p0;
                auto stmt_p4 = p1;
                ({
                auto&& _m = prism_rtl::deref(stmt_p4).kind_p;
                prism_rtl::is<crate::syntax::StmtKind::SLet>(_m) ? ({
                auto&& p_p5 = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
                auto&& e_p6 = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
                ({
                auto&& _m = prism_rtl::deref(prism_rtl::deref(p_p5).kind_p);
                prism_rtl::is<crate::syntax::PatternKind::PName>(_m) ? ({
                auto&& n_p7 = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
                crate::syntax::lexer::chars::has_prefix_f(prism_rtl::deref(n_p7).sigils_p, Text::lit("&"))
                ? prism_rtl::finished(s_p3)
                : ({
                auto&& _m = crate::prelude::get(prism_rtl::deref(env_p0xy).locals_p, crate::check::env::sname_key_f(n_p7));
                prism_rtl::is_some(_m) ? prism_rtl::finished(s_p3)
                : prism_rtl::is_none(_m) ? calls_local_maker_f(env_p0xy, e_p6)
                ? prism_rtl::finished(crate::check::types::recording::err_fix_f(s_p3, Text::lit("local-escapes"), prism_rtl::deref(stmt_p4).span_p, prism_rtl::cat("a `Buffer` cannot leave its block: `", crate::check::env::sname_key_f(n_p7), "` is no `&` local"), prism_rtl::cat("write `let &", crate::check::env::sname_key_f(n_p7), " = ...`")))
                : prism_rtl::finished(s_p3)
                : throw prism_rtl::Panic("no arm matched");
            });
            })
                : prism_rtl::finished(s_p3);
            });
            })
                : prism_rtl::is<crate::syntax::StmtKind::SWhile>(_m) ? ({
                auto&& body_p8 = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a1;
                prism_rtl::more(prism_rtl::rc(EscapeStmts(env_p0xy, s_p3, prism_rtl::deref(body_p8).stmts_p)));
            })
                : prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m) ? ({
                auto&& e_p9 = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
                ({
                auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p9).kind_p);
                prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) ? ({
                auto&& tb_pa = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
                auto&& eb_ob = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
                ({
                auto eb_obx = eb_ob;
                auto tb_pax = tb_pa;
                (crate::prelude::call_then(start_escape_stmts_f(env_p0xy, s_p3, prism_rtl::deref(tb_pax).stmts_p), [=, eb_obx = std::move(eb_obx)](crate::check::types::St escape_stmts_f_3035) {
                return ({
                    auto s2_pc = escape_stmts_f_3035;
                    ({
                    prism_rtl::is_some(eb_obx) ? ({
                    auto&& x_pd = prism_rtl::some_of(eb_obx);
                    prism_rtl::more(prism_rtl::rc(EscapeStmts(env_p0xy, s2_pc, prism_rtl::deref(x_pd).stmts_p)));
                })
                    : prism_rtl::is_none(eb_obx) ? prism_rtl::finished(s2_pc)
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            }));
            });
            })
                : prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m) ? ({
                auto&& arms_pe = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
                crate::prelude::fold_job(arms_pe, s_p3, ({
                auto env_p0xyx = env_p0xy;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::Arm>)>>(prism_rtl::rc([=, env_p0xyx = std::move(env_p0xyx)](std::tuple<crate::check::types::St, crate::syntax::Arm> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto env_p0xyxy = env_p0xyx;
                    (crate::prelude::entered(crate::prelude::once_job([=, env_p0xyxy = std::move(env_p0xyxy)]() {
                    return ({
                        auto s3_pf = p0;
                        auto a_pg = p1;
                        (prism_rtl::more(prism_rtl::rc(EscapeStmts(env_p0xyxy, s3_pf, prism_rtl::deref(prism_rtl::deref(a_pg).body_p).stmts_p))));
                    });
                })));
                });
            })));
            }))->cycle();
            })
                : prism_rtl::is<crate::syntax::ExprKind::EFor>(_m) ? ({
                auto&& body_ph = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a2;
                prism_rtl::more(prism_rtl::rc(EscapeStmts(env_p0xy, s_p3, prism_rtl::deref(body_ph).stmts_p)));
            })
                : prism_rtl::finished(s_p3);
            });
            })
                : prism_rtl::finished(s_p3);
            });
            });
        })));
        });
    })));
    })));
}


prism_rtl::Turn<crate::check::types::St> EscapeStmts::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& stmts_p2 = this->stmts_p2;
    return crate::prelude::fold_job(stmts_p2, st_p1, ({
        auto env_p0x = env_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::Stmt>)>>(prism_rtl::rc([=, env_p0x = std::move(env_p0x)](std::tuple<crate::check::types::St, crate::syntax::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_p0xy = env_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, env_p0xy = std::move(env_p0xy)]() {
            return ({
                auto s_p3 = p0;
                auto stmt_p4 = p1;
                ({
                auto&& _m = prism_rtl::deref(stmt_p4).kind_p;
                prism_rtl::is<crate::syntax::StmtKind::SLet>(_m) ? ({
                auto&& p_p5 = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
                auto&& e_p6 = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
                ({
                auto&& _m = prism_rtl::deref(prism_rtl::deref(p_p5).kind_p);
                prism_rtl::is<crate::syntax::PatternKind::PName>(_m) ? ({
                auto&& n_p7 = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
                crate::syntax::lexer::chars::has_prefix_f(prism_rtl::deref(n_p7).sigils_p, Text::lit("&"))
                ? prism_rtl::finished(s_p3)
                : ({
                auto&& _m = crate::prelude::get(prism_rtl::deref(env_p0xy).locals_p, crate::check::env::sname_key_f(n_p7));
                prism_rtl::is_some(_m) ? prism_rtl::finished(s_p3)
                : prism_rtl::is_none(_m) ? calls_local_maker_f(env_p0xy, e_p6)
                ? prism_rtl::finished(crate::check::types::recording::err_fix_f(s_p3, Text::lit("local-escapes"), prism_rtl::deref(stmt_p4).span_p, prism_rtl::cat("a `Buffer` cannot leave its block: `", crate::check::env::sname_key_f(n_p7), "` is no `&` local"), prism_rtl::cat("write `let &", crate::check::env::sname_key_f(n_p7), " = ...`")))
                : prism_rtl::finished(s_p3)
                : throw prism_rtl::Panic("no arm matched");
            });
            })
                : prism_rtl::finished(s_p3);
            });
            })
                : prism_rtl::is<crate::syntax::StmtKind::SWhile>(_m) ? ({
                auto&& body_p8 = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a1;
                prism_rtl::more(prism_rtl::rc(EscapeStmts(env_p0xy, s_p3, prism_rtl::deref(body_p8).stmts_p)));
            })
                : prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m) ? ({
                auto&& e_p9 = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
                ({
                auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p9).kind_p);
                prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) ? ({
                auto&& tb_pa = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
                auto&& eb_ob = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
                ({
                auto eb_obx = eb_ob;
                auto tb_pax = tb_pa;
                (crate::prelude::call_then(start_escape_stmts_f(env_p0xy, s_p3, prism_rtl::deref(tb_pax).stmts_p), [=, eb_obx = std::move(eb_obx)](crate::check::types::St escape_stmts_f_3035) {
                return ({
                    auto s2_pc = escape_stmts_f_3035;
                    ({
                    prism_rtl::is_some(eb_obx) ? ({
                    auto&& x_pd = prism_rtl::some_of(eb_obx);
                    prism_rtl::more(prism_rtl::rc(EscapeStmts(env_p0xy, s2_pc, prism_rtl::deref(x_pd).stmts_p)));
                })
                    : prism_rtl::is_none(eb_obx) ? prism_rtl::finished(s2_pc)
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            }));
            });
            })
                : prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m) ? ({
                auto&& arms_pe = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
                crate::prelude::fold_job(arms_pe, s_p3, ({
                auto env_p0xyx = env_p0xy;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::Arm>)>>(prism_rtl::rc([=, env_p0xyx = std::move(env_p0xyx)](std::tuple<crate::check::types::St, crate::syntax::Arm> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto env_p0xyxy = env_p0xyx;
                    (crate::prelude::entered(crate::prelude::once_job([=, env_p0xyxy = std::move(env_p0xyxy)]() {
                    return ({
                        auto s3_pf = p0;
                        auto a_pg = p1;
                        (prism_rtl::more(prism_rtl::rc(EscapeStmts(env_p0xyxy, s3_pf, prism_rtl::deref(prism_rtl::deref(a_pg).body_p).stmts_p))));
                    });
                })));
                });
            })));
            }))->cycle();
            })
                : prism_rtl::is<crate::syntax::ExprKind::EFor>(_m) ? ({
                auto&& body_ph = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a2;
                prism_rtl::more(prism_rtl::rc(EscapeStmts(env_p0xy, s_p3, prism_rtl::deref(body_ph).stmts_p)));
            })
                : prism_rtl::finished(s_p3);
            });
            })
                : prism_rtl::finished(s_p3);
            });
            });
        })));
        });
    })));
    }))->cycle();
}


/// `Start EscapeStmts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_escape_stmts_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Array<crate::syntax::Stmt> stmts_p2) {
    return prism_rtl::make_rc<EscapeStmts>(env_p0, st_p1, stmts_p2);
}


/// CallsLocalMaker: fn Env, Expr -> Bool
bool calls_local_maker_f(const crate::check::expr::Env& env_p0, const crate::syntax::Expr& e_p1) {
    auto&& _m = prism_rtl::deref(e_p1.kind_p);
    if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
        auto&& c_p2 = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
        return maker_of_o(env_p0, prism_rtl::deref(prism_rtl::deref(c_p2))) != std::optional<Text>{};
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& _m = maker_of_o(env_p0, e_p1);
        if (prism_rtl::is_some(_m)) {
            auto&& k_p3 = prism_rtl::some_of(_m);
            return k_p3 != Text::lit("Buffer.Numbered");
        }
        if (prism_rtl::is_none(_m)) {
            return false;
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x_p4 = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return calls_local_maker_f(env_p0, prism_rtl::deref(prism_rtl::deref(x_p4)));
    }
    {
        return false;
    }
}


/// ?MakerOf: fn Env, Expr -> ?Text
std::optional<Text> maker_of_o(const crate::check::expr::Env& env_p0, const crate::syntax::Expr& c_p1) {
    auto&& _m = crate::check::shrink::walk::callee_name_o(c_p1);
    if (prism_rtl::is_some(_m)) {
        auto&& n_p2 = prism_rtl::some_of(_m);
        return crate::check::env::has_key_f(env_p0.locals_p, n_p2)
            ? std::optional<Text>{}
            : ({
            __label__ _done;
            prism_rtl::Slot<std::optional<Text>> _v;
            auto&& _m = crate::check::shrink::locals::resolve_name_o(env_p0.g_p, env_p0.home_p, n_p2);
            if (prism_rtl::is_some(_m)) {
                auto&& k_p3 = prism_rtl::some_of(_m);
                _v.set(crate::check::expr::calls::is_local_maker_f(k_p3) && (prism_rtl::deref(crate::prelude::or_(crate::prelude::get(prism_rtl::deref(env_p0.g_p).vals_p, k_p3), crate::check::dummy_val_p())).sort_p == Text::lit("builtin"))
                    ? std::optional(k_p3)
                    : std::optional<Text>{});
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(std::optional<Text>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    }
    if (prism_rtl::is_none(_m)) {
        return std::optional<Text>{};
    }
    prism_rtl::unreachable("no arm matched");
}


/// FrozenStmts: unbounded fn Env, St, [Stmt], (Text ==> Nat) -> (((Text ==> Nat), St))
std::tuple<Map<Text, Nat>, crate::check::types::St> frozen_stmts_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const Array<crate::syntax::Stmt>& stmts_p2, const Map<Text, Nat>& frozen_p3) {
    auto pre_p4 = crate::check::shrink::relations::prelude_seeds_f(env_p0.g_p, env_p0.home_p);
    auto seeds_p5 = crate::prelude::fold(crate::prelude::keys(pre_p4), pre_p4, [&](const Map<Text, crate::check::shrink::Rel>& m_p7, const Text& k_p8) {
        return crate::check::env::has_key_f(env_p0.locals_p, crate::syntax::lexer::chars::drop_prefix_f(k_p8, Text::lit("pre:")))
            ? crate::prelude::remove(m_p7, k_p8)
            : m_p7;
    });
    auto bm_p6 = crate::check::shrink::relations::block_rels_f(stmts_p2, seeds_p5);
    return crate::prelude::run_to_end(crate::prelude::fold_job(stmts_p2, std::tuple{frozen_p3, st_p1}, ({
        auto bm_p6x = bm_p6;
        auto env_p0x = env_p0;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Map<Text, Nat>, crate::check::types::St>>(std::tuple<std::tuple<Map<Text, Nat>, crate::check::types::St>, crate::syntax::Stmt>)>>(prism_rtl::rc([=, bm_p6x = std::move(bm_p6x), env_p0x = std::move(env_p0x)](std::tuple<std::tuple<Map<Text, Nat>, crate::check::types::St>, crate::syntax::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto bm_p6xy = bm_p6x;
            auto env_p0xy = env_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, bm_p6xy = std::move(bm_p6xy), env_p0xy = std::move(env_p0xy)]() {
            return ({
                auto [fz_p9, s_pa] = p0;
                auto stmt_pb = p1;
                (crate::prelude::call_then(crate::check::shrink::walk::start_stmt_spots_f(stmt_pb, bm_p6xy), [=](Array<crate::check::shrink::walk::Spot> stmt_spots_f_4900) {
                return ({
                    auto spots_pc = stmt_spots_f_4900;
                    auto reads_pd = crate::prelude::fold(spots_pc, Array<std::tuple<Text, crate::syntax::Range>>{}, [&](const Array<std::tuple<Text, crate::syntax::Range>>& acc_ph, const crate::check::shrink::walk::Spot& sp_pi) { return crate::prelude::append(acc_ph, spot_refs_f(sp_pi)); });
                    auto s2_pe = crate::prelude::fold(reads_pd, s_pa, [&](const crate::check::types::St& s1_pj, const std::tuple<Text, crate::syntax::Range>& _p1) {
                        auto&& n_pk = std::get<0>(_p1);
                        auto&& sp_pl = std::get<1>(_p1);
                        return ({
                            __label__ _done;
                            prism_rtl::Slot<crate::check::types::St> _v;
                            auto&& _m = crate::prelude::get(fz_p9, n_pk);
                            if (prism_rtl::is_some(_m)) {
                                auto&& line_pm = prism_rtl::some_of(_m);
                                _v.set(crate::check::types::recording::err_fix_f(s1_pj, Text::lit("frozen"), sp_pl, prism_rtl::cat("`", n_pk, "` was frozen on line ", line_pm + Nat(1u)), Text::lit("use the frozen value, or make a new local")));
                                goto _done;
                            }
                            if (prism_rtl::is_none(_m)) {
                                _v.set(s1_pj);
                                goto _done;
                            }
                            prism_rtl::unreachable("no arm matched");
                        _done:
                            _v.take();
                        });
                    });
                    auto fz1_pf = ({
                        __label__ _done;
                        prism_rtl::Slot<Map<Text, Nat>> _v;
                        auto&& _m = prism_rtl::deref(stmt_pb).kind_p;
                        if (prism_rtl::is<crate::syntax::StmtKind::SLet>(_m)) {
                            auto&& p_pn = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
                            _v.set(crate::prelude::fold(crate::check::env::names::pattern_names_f(p_pn), fz_p9, [&](const Map<Text, Nat>& m_po, const Text& n_pp) { return crate::prelude::remove(m_po, n_pp); }));
                            goto _done;
                        }
                        {
                            _v.set(fz_p9);
                            goto _done;
                        }
                    _done:
                        _v.take();
                    });
                    (crate::prelude::call_value(crate::prelude::fold_job(spots_pc, fz1_pf, ({
                    auto env_p0xyx = env_p0xy;
                    auto stmt_pbx = stmt_pb;
                    static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Nat>>(std::tuple<Map<Text, Nat>, crate::check::shrink::walk::Spot>)>>(prism_rtl::rc([=, env_p0xyx = std::move(env_p0xyx), stmt_pbx = std::move(stmt_pbx)](std::tuple<Map<Text, Nat>, crate::check::shrink::walk::Spot> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto env_p0xyxy = env_p0xyx;
                        auto stmt_pbxy = stmt_pbx;
                        (crate::prelude::entered(crate::prelude::once_job([=, env_p0xyxy = std::move(env_p0xyxy), stmt_pbxy = std::move(stmt_pbxy)]() {
                        return ({
                            auto m_pq = p0;
                            auto sp_pr = p1;
                            (crate::prelude::call_then(start_spot_freezes_f(sp_pr), [=, m_pq = std::move(m_pq)](Array<Text> spot_freezes_f_5398) { return prism_rtl::finished(crate::prelude::fold(spot_freezes_f_5398, m_pq, [&](const Map<Text, Nat>& m2_ps, const Text& n_pt) { return crate::prelude::insert(m2_ps, n_pt, crate::check::errors::cline_of_f(prism_rtl::deref(prism_rtl::deref(env_p0xyxy).src_p).starts_p, prism_rtl::deref(prism_rtl::deref(stmt_pbxy).span_p).start_p)); })); }));
                        });
                    })));
                    });
                }));
                })), [=, s2_pe = std::move(s2_pe)](Map<Text, Nat> fold_5366) {
                    return ({
                        auto fz2_pg = fold_5366;
                        (prism_rtl::finished(std::tuple{fz2_pg, s2_pe}));
                    });
                }));
                });
            }));
            });
        })));
        });
    }));
    })));
}


prism_rtl::Turn<std::tuple<Map<Text, Nat>, crate::check::types::St>> FrozenStmts::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& stmts_p2 = this->stmts_p2;
    const auto& frozen_p3 = this->frozen_p3;
    auto pre_p4 = crate::check::shrink::relations::prelude_seeds_f(prism_rtl::deref(env_p0).g_p, prism_rtl::deref(env_p0).home_p);
    auto seeds_p5 = crate::prelude::fold(crate::prelude::keys(pre_p4), pre_p4, [&](const Map<Text, crate::check::shrink::Rel>& m_p7, const Text& k_p8) {
        return crate::check::env::has_key_f(prism_rtl::deref(env_p0).locals_p, crate::syntax::lexer::chars::drop_prefix_f(k_p8, Text::lit("pre:")))
            ? crate::prelude::remove(m_p7, k_p8)
            : m_p7;
    });
    auto env_p0x = env_p0;
    auto frozen_p3x = frozen_p3;
    auto st_p1x = st_p1;
    auto stmts_p2x = stmts_p2;
    return crate::prelude::call_then(crate::check::shrink::relations::start_block_rels_f(stmts_p2x, seeds_p5), [=](Map<Text, crate::check::shrink::Rel> block_rels_f_4806) {
        return ({
            auto bm_p6 = block_rels_f_4806;
            (crate::prelude::fold_job(stmts_p2x, std::tuple{frozen_p3x, st_p1x}, ({
            auto bm_p6x = bm_p6;
            auto env_p0xx = env_p0x;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Map<Text, Nat>, crate::check::types::St>>(std::tuple<std::tuple<Map<Text, Nat>, crate::check::types::St>, crate::syntax::Stmt>)>>(prism_rtl::rc([=, bm_p6x = std::move(bm_p6x), env_p0xx = std::move(env_p0xx)](std::tuple<std::tuple<Map<Text, Nat>, crate::check::types::St>, crate::syntax::Stmt> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto bm_p6xy = bm_p6x;
                auto env_p0xxy = env_p0xx;
                (crate::prelude::entered(crate::prelude::once_job([=, bm_p6xy = std::move(bm_p6xy), env_p0xxy = std::move(env_p0xxy)]() {
                return ({
                    auto [fz_p9, s_pa] = p0;
                    auto stmt_pb = p1;
                    (crate::prelude::call_then(crate::check::shrink::walk::start_stmt_spots_f(stmt_pb, bm_p6xy), [=](Array<crate::check::shrink::walk::Spot> stmt_spots_f_4900) {
                    return ({
                        auto spots_pc = stmt_spots_f_4900;
                        auto reads_pd = crate::prelude::fold(spots_pc, Array<std::tuple<Text, crate::syntax::Range>>{}, [&](const Array<std::tuple<Text, crate::syntax::Range>>& acc_ph, const crate::check::shrink::walk::Spot& sp_pi) { return crate::prelude::append(acc_ph, spot_refs_f(sp_pi)); });
                        auto s2_pe = crate::prelude::fold(reads_pd, s_pa, [&](const crate::check::types::St& s1_pj, const std::tuple<Text, crate::syntax::Range>& _p1) {
                            auto&& n_pk = std::get<0>(_p1);
                            auto&& sp_pl = std::get<1>(_p1);
                            return ({
                                __label__ _done;
                                prism_rtl::Slot<crate::check::types::St> _v;
                                auto&& _m = crate::prelude::get(fz_p9, n_pk);
                                if (prism_rtl::is_some(_m)) {
                                    auto&& line_pm = prism_rtl::some_of(_m);
                                    _v.set(crate::check::types::recording::err_fix_f(s1_pj, Text::lit("frozen"), sp_pl, prism_rtl::cat("`", n_pk, "` was frozen on line ", line_pm + Nat(1u)), Text::lit("use the frozen value, or make a new local")));
                                    goto _done;
                                }
                                if (prism_rtl::is_none(_m)) {
                                    _v.set(s1_pj);
                                    goto _done;
                                }
                                prism_rtl::unreachable("no arm matched");
                            _done:
                                _v.take();
                            });
                        });
                        auto fz1_pf = ({
                            __label__ _done;
                            prism_rtl::Slot<Map<Text, Nat>> _v;
                            auto&& _m = prism_rtl::deref(stmt_pb).kind_p;
                            if (prism_rtl::is<crate::syntax::StmtKind::SLet>(_m)) {
                                auto&& p_pn = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
                                _v.set(crate::prelude::fold(crate::check::env::names::pattern_names_f(p_pn), fz_p9, [&](const Map<Text, Nat>& m_po, const Text& n_pp) { return crate::prelude::remove(m_po, n_pp); }));
                                goto _done;
                            }
                            {
                                _v.set(fz_p9);
                                goto _done;
                            }
                        _done:
                            _v.take();
                        });
                        (crate::prelude::call_value(crate::prelude::fold_job(spots_pc, fz1_pf, ({
                        auto env_p0xxyx = env_p0xxy;
                        auto stmt_pbx = stmt_pb;
                        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Nat>>(std::tuple<Map<Text, Nat>, crate::check::shrink::walk::Spot>)>>(prism_rtl::rc([=, env_p0xxyx = std::move(env_p0xxyx), stmt_pbx = std::move(stmt_pbx)](std::tuple<Map<Text, Nat>, crate::check::shrink::walk::Spot> _p0) {
                        auto&& p0 = std::get<0>(_p0);
                        auto&& p1 = std::get<1>(_p0);
                        return ({
                            auto env_p0xxyxy = env_p0xxyx;
                            auto stmt_pbxy = stmt_pbx;
                            (crate::prelude::entered(crate::prelude::once_job([=, env_p0xxyxy = std::move(env_p0xxyxy), stmt_pbxy = std::move(stmt_pbxy)]() {
                            return ({
                                auto m_pq = p0;
                                auto sp_pr = p1;
                                (crate::prelude::call_then(start_spot_freezes_f(sp_pr), [=, m_pq = std::move(m_pq)](Array<Text> spot_freezes_f_5398) { return prism_rtl::finished(crate::prelude::fold(spot_freezes_f_5398, m_pq, [&](const Map<Text, Nat>& m2_ps, const Text& n_pt) { return crate::prelude::insert(m2_ps, n_pt, crate::check::errors::cline_of_f(prism_rtl::deref(prism_rtl::deref(env_p0xxyxy).src_p).starts_p, prism_rtl::deref(prism_rtl::deref(stmt_pbxy).span_p).start_p)); })); }));
                            });
                        })));
                        });
                    }));
                    })), [=, s2_pe = std::move(s2_pe)](Map<Text, Nat> fold_5366) {
                        return ({
                            auto fz2_pg = fold_5366;
                            (prism_rtl::finished(std::tuple{fz2_pg, s2_pe}));
                        });
                    }));
                    });
                }));
                });
            })));
            });
        }));
        }))->cycle());
        });
    });
}


/// `Start FrozenStmts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Map<Text, Nat>, crate::check::types::St>> start_frozen_stmts_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Array<crate::syntax::Stmt> stmts_p2, Map<Text, Nat> frozen_p3) {
    return prism_rtl::make_rc<FrozenStmts>(env_p0, st_p1, stmts_p2, frozen_p3);
}


/// SpotRefs: fn Spot -> [((Text, Range))]
Array<std::tuple<Text, crate::syntax::Range>> spot_refs_f(const crate::check::shrink::walk::Spot& spot0) {
    if (prism_rtl::is<crate::check::shrink::walk::Spot::SpotExpr>(spot0)) {
        auto&& e_p0 = prism_rtl::as<crate::check::shrink::walk::Spot::SpotExpr>(spot0).a0;
        auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p0).kind_p);
        if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
            auto&& n_p1 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
            return crate::syntax::lexer::chars::has_prefix_f(prism_rtl::deref(n_p1).sigils_p, Text::lit("&"))
                ? Array(std::vector{std::tuple{crate::check::env::sname_key_f(n_p1), prism_rtl::deref(n_p1).span_p}})
                : Array<std::tuple<Text, crate::syntax::Range>>{};
        }
        {
            return Array<std::tuple<Text, crate::syntax::Range>>{};
        }
    }
    if (prism_rtl::is<crate::check::shrink::walk::Spot::SpotStmt>(spot0)) {
        return Array<std::tuple<Text, crate::syntax::Range>>{};
    }
    prism_rtl::unreachable("no arm matched");
}


/// SpotFreezes: unbounded fn Spot -> [Text]
Array<Text> spot_freezes_f(const crate::check::shrink::walk::Spot& spot0) {
    if (prism_rtl::is<crate::check::shrink::walk::Spot::SpotExpr>(spot0)) {
        auto&& e_p0 = prism_rtl::as<crate::check::shrink::walk::Spot::SpotExpr>(spot0).a0;
        auto&& m_p1 = prism_rtl::as<crate::check::shrink::walk::Spot::SpotExpr>(spot0).a1;
        auto&& _m = crate::check::shrink::walk::call_of_o(e_p0);
        if (prism_rtl::is_some(_m)) {
            auto&& c_p2 = std::get<0>(prism_rtl::some_of(_m));
            auto&& args_p3 = std::get<1>(prism_rtl::some_of(_m));
            auto&& _m = crate::check::shrink::walk::callee_name_o(c_p2);
            if (prism_rtl::is_some(_m)) {
                auto&& n_p4 = prism_rtl::some_of(_m);
                return crate::check::shrink::relations::pre_is_f(m_p1, n_p4, Text::lit("Freeze"))
                    ? crate::prelude::run_to_end(crate::prelude::fold_job(args_p3, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Arg>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Arg> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return crate::prelude::entered(crate::prelude::once_job([=]() {
                        return ({
                            auto acc_p5 = p0;
                            auto a_p6 = p1;
                            (prism_rtl::finished(crate::prelude::append(acc_p5, crate::prelude::each(refs_in_f(prism_rtl::deref(a_p6).value_p), [&](const std::tuple<Text, crate::syntax::Range>& _p0) {
                            auto&& n2_p7 = std::get<0>(_p0);
                            return n2_p7;
                        }))));
                        });
                    }));
                }))))
                    : Array<Text>{};
            }
            if (prism_rtl::is_none(_m)) {
                return Array<Text>{};
            }
            prism_rtl::unreachable("no arm matched");
        }
        if (prism_rtl::is_none(_m)) {
            return Array<Text>{};
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<crate::check::shrink::walk::Spot::SpotStmt>(spot0)) {
        return Array<Text>{};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Text>> SpotFreezes::cycle() const {
    const auto& spot0 = this->spot0;
    return ({
        prism_rtl::is<crate::check::shrink::walk::Spot::SpotExpr>(spot0) ? ({
        auto&& e_p0 = prism_rtl::as<crate::check::shrink::walk::Spot::SpotExpr>(spot0).a0;
        auto&& m_p1 = prism_rtl::as<crate::check::shrink::walk::Spot::SpotExpr>(spot0).a1;
        ({
        auto&& _m = crate::check::shrink::walk::call_of_o(e_p0);
        prism_rtl::is_some(_m) ? ({
        auto&& c_p2 = std::get<0>(prism_rtl::some_of(_m));
        auto&& args_p3 = std::get<1>(prism_rtl::some_of(_m));
        ({
        auto&& _m = crate::check::shrink::walk::callee_name_o(c_p2);
        prism_rtl::is_some(_m) ? ({
        auto&& n_p4 = prism_rtl::some_of(_m);
        crate::check::shrink::relations::pre_is_f(m_p1, n_p4, Text::lit("Freeze"))
        ? crate::prelude::fold_job(args_p3, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Arg>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Arg> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto acc_p5 = p0;
                auto a_p6 = p1;
                (prism_rtl::finished(crate::prelude::append(acc_p5, crate::prelude::each(refs_in_f(prism_rtl::deref(a_p6).value_p), [&](const std::tuple<Text, crate::syntax::Range>& _p0) {
                auto&& n2_p7 = std::get<0>(_p0);
                return n2_p7;
            }))));
            });
        }));
    })))->cycle()
        : prism_rtl::finished(Array<Text>{});
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(Array<Text>{})
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(Array<Text>{})
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : prism_rtl::is<crate::check::shrink::walk::Spot::SpotStmt>(spot0) ? prism_rtl::finished(Array<Text>{})
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start SpotFreezes, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_spot_freezes_f(crate::check::shrink::walk::Spot spot0) {
    return prism_rtl::make_rc<SpotFreezes>(spot0);
}


/// RefsIn: unbounded fn Expr -> [((Text, Range))]
Array<std::tuple<Text, crate::syntax::Range>> refs_in_f(const crate::syntax::Expr& e_p0) {
    auto&& _m = prism_rtl::deref(e_p0.kind_p);
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n_p1 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        return crate::syntax::lexer::chars::has_prefix_f(prism_rtl::deref(n_p1).sigils_p, Text::lit("&"))
            ? Array(std::vector{std::tuple{crate::check::env::sname_key_f(n_p1), prism_rtl::deref(n_p1).span_p}})
            : Array<std::tuple<Text, crate::syntax::Range>>{};
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
        auto&& c_p2 = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
        auto&& args_p3 = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
        return crate::prelude::run_to_end(crate::prelude::fold_job(args_p3, refs_in_f(prism_rtl::deref(prism_rtl::deref(c_p2))), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Text, crate::syntax::Range>>>(std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::syntax::Arg>)>>(prism_rtl::rc([=](std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::syntax::Arg> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto acc_p4 = p0;
                    auto a_p5 = p1;
                    (prism_rtl::finished(crate::prelude::append(acc_p4, refs_in_f(prism_rtl::deref(a_p5).value_p))));
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EBinary>(_m)) {
        auto&& l_p6 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
        auto&& r_p7 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a2;
        return crate::prelude::append(refs_in_f(prism_rtl::deref(prism_rtl::deref(l_p6))), refs_in_f(prism_rtl::deref(prism_rtl::deref(r_p7))));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EUnary>(_m)) {
        auto&& x_p8 = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a1;
        return refs_in_f(prism_rtl::deref(prism_rtl::deref(x_p8)));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m)) {
        auto&& x_p9 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
        return refs_in_f(prism_rtl::deref(prism_rtl::deref(x_p9)));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EField>(_m)) {
        auto&& r_pa = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a0;
        return refs_in_f(prism_rtl::deref(prism_rtl::deref(r_pa)));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m)) {
        auto&& r_pb = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
        auto&& i_pc = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a1;
        return crate::prelude::append(refs_in_f(prism_rtl::deref(prism_rtl::deref(r_pb))), refs_in_f(prism_rtl::deref(prism_rtl::deref(i_pc))));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x_pd = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return refs_in_f(prism_rtl::deref(prism_rtl::deref(x_pd)));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ETuple>(_m)) {
        auto&& es_pe = prism_rtl::as<crate::syntax::ExprKind::ETuple>(_m).a0;
        return crate::prelude::run_to_end(crate::prelude::fold_job(es_pe, Array<std::tuple<Text, crate::syntax::Range>>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Text, crate::syntax::Range>>>(std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::syntax::Expr>)>>(prism_rtl::rc([=](std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::syntax::Expr> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto acc_pf = p0;
                    auto x_pg = p1;
                    (prism_rtl::finished(crate::prelude::append(acc_pf, refs_in_f(x_pg))));
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EArray>(_m)) {
        auto&& es_ph = prism_rtl::as<crate::syntax::ExprKind::EArray>(_m).a0;
        return crate::prelude::run_to_end(crate::prelude::fold_job(es_ph, Array<std::tuple<Text, crate::syntax::Range>>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Text, crate::syntax::Range>>>(std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::syntax::Expr>)>>(prism_rtl::rc([=](std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::syntax::Expr> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto acc_pi = p0;
                    auto x_pj = p1;
                    (prism_rtl::finished(crate::prelude::append(acc_pi, refs_in_f(x_pj))));
                });
            }));
        }))));
    }
    {
        return Array<std::tuple<Text, crate::syntax::Range>>{};
    }
}


/// BorrowStmts: unbounded fn Env, St, [Stmt], [ [Text] ] -> St
crate::check::types::St borrow_stmts_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const Array<crate::syntax::Stmt>& stmts_p2, const Array<Array<Text>>& lent_p3) {
    return crate::prelude::run_to_end(crate::prelude::fold_job(stmts_p2, st_p1, ({
        auto env_p0x = env_p0;
        auto lent_p3x = lent_p3;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::Stmt>)>>(prism_rtl::rc([=, env_p0x = std::move(env_p0x), lent_p3x = std::move(lent_p3x)](std::tuple<crate::check::types::St, crate::syntax::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_p0xy = env_p0x;
            auto lent_p3xy = lent_p3x;
            (crate::prelude::entered(crate::prelude::once_job([=, env_p0xy = std::move(env_p0xy), lent_p3xy = std::move(lent_p3xy)]() {
            return ({
                auto s_p4 = p0;
                auto stmt_p5 = p1;
                ({
                auto&& _m = prism_rtl::deref(stmt_p5).kind_p;
                prism_rtl::is<crate::syntax::StmtKind::SSet>(_m) ? ({
                auto&& t_p6 = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a0;
                prism_rtl::more(prism_rtl::rc(CheckLent(env_p0xy, s_p4, t_p6, lent_p3xy)));
            })
                : prism_rtl::is<crate::syntax::StmtKind::SAccum>(_m) ? ({
                auto&& t_p7 = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a0;
                prism_rtl::more(prism_rtl::rc(CheckLent(env_p0xy, s_p4, t_p7, lent_p3xy)));
            })
                : prism_rtl::is<crate::syntax::StmtKind::SWhile>(_m) ? ({
                auto&& body_p8 = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a1;
                prism_rtl::more(prism_rtl::rc(BorrowStmts(env_p0xy, s_p4, prism_rtl::deref(body_p8).stmts_p, lent_p3xy)));
            })
                : prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m) ? ({
                auto&& e_p9 = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
                ({
                auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p9).kind_p);
                prism_rtl::is<crate::syntax::ExprKind::EFor>(_m) ? ({
                auto&& binders_oa = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a0;
                auto&& source_pb = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a1;
                auto&& body_pc = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a2;
                ({
                auto binders_oax = binders_oa;
                auto body_pcx = body_pc;
                auto source_pbx = prism_rtl::deref(prism_rtl::deref(source_pb));
                (crate::prelude::call_then(start_ref_path_f(source_pbx), [=, binders_oax = std::move(binders_oax), body_pcx = std::move(body_pcx)](Array<Text> ref_path_f_7339) {
                return ({
                    auto path_pd = ref_path_f_7339;
                    auto lent2_pe = (crate::prelude::len(path_pd) > Nat(0u)) && (binders_oax != std::optional<crate::syntax::ForBinders>{})
                        ? crate::prelude::push(lent_p3xy, path_pd)
                        : lent_p3xy;
                    (prism_rtl::more(prism_rtl::rc(BorrowStmts(env_p0xy, s_p4, prism_rtl::deref(body_pcx).stmts_p, lent2_pe))));
                });
            }));
            });
            })
                : prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) ? ({
                auto&& tb_pf = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
                auto&& eb_og = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
                ({
                auto eb_ogx = eb_og;
                auto tb_pfx = tb_pf;
                (crate::prelude::call_then(start_borrow_stmts_f(env_p0xy, s_p4, prism_rtl::deref(tb_pfx).stmts_p, lent_p3xy), [=, eb_ogx = std::move(eb_ogx)](crate::check::types::St borrow_stmts_f_7544) {
                return ({
                    auto s2_ph = borrow_stmts_f_7544;
                    ({
                    prism_rtl::is_some(eb_ogx) ? ({
                    auto&& x_pi = prism_rtl::some_of(eb_ogx);
                    prism_rtl::more(prism_rtl::rc(BorrowStmts(env_p0xy, s2_ph, prism_rtl::deref(x_pi).stmts_p, lent_p3xy)));
                })
                    : prism_rtl::is_none(eb_ogx) ? prism_rtl::finished(s2_ph)
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            }));
            });
            })
                : prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m) ? ({
                auto&& arms_pj = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
                crate::prelude::fold_job(arms_pj, s_p4, ({
                auto env_p0xyx = env_p0xy;
                auto lent_p3xyx = lent_p3xy;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::Arm>)>>(prism_rtl::rc([=, env_p0xyx = std::move(env_p0xyx), lent_p3xyx = std::move(lent_p3xyx)](std::tuple<crate::check::types::St, crate::syntax::Arm> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto env_p0xyxy = env_p0xyx;
                    auto lent_p3xyxy = lent_p3xyx;
                    (crate::prelude::entered(crate::prelude::once_job([=, env_p0xyxy = std::move(env_p0xyxy), lent_p3xyxy = std::move(lent_p3xyxy)]() {
                    return ({
                        auto s3_pk = p0;
                        auto a_pl = p1;
                        (prism_rtl::more(prism_rtl::rc(BorrowStmts(env_p0xyxy, s3_pk, prism_rtl::deref(prism_rtl::deref(a_pl).body_p).stmts_p, lent_p3xyxy))));
                    });
                })));
                });
            })));
            }))->cycle();
            })
                : prism_rtl::finished(s_p4);
            });
            })
                : prism_rtl::finished(s_p4);
            });
            });
        })));
        });
    })));
    })));
}


prism_rtl::Turn<crate::check::types::St> BorrowStmts::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& stmts_p2 = this->stmts_p2;
    const auto& lent_p3 = this->lent_p3;
    return crate::prelude::fold_job(stmts_p2, st_p1, ({
        auto env_p0x = env_p0;
        auto lent_p3x = lent_p3;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::Stmt>)>>(prism_rtl::rc([=, env_p0x = std::move(env_p0x), lent_p3x = std::move(lent_p3x)](std::tuple<crate::check::types::St, crate::syntax::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_p0xy = env_p0x;
            auto lent_p3xy = lent_p3x;
            (crate::prelude::entered(crate::prelude::once_job([=, env_p0xy = std::move(env_p0xy), lent_p3xy = std::move(lent_p3xy)]() {
            return ({
                auto s_p4 = p0;
                auto stmt_p5 = p1;
                ({
                auto&& _m = prism_rtl::deref(stmt_p5).kind_p;
                prism_rtl::is<crate::syntax::StmtKind::SSet>(_m) ? ({
                auto&& t_p6 = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a0;
                prism_rtl::more(prism_rtl::rc(CheckLent(env_p0xy, s_p4, t_p6, lent_p3xy)));
            })
                : prism_rtl::is<crate::syntax::StmtKind::SAccum>(_m) ? ({
                auto&& t_p7 = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a0;
                prism_rtl::more(prism_rtl::rc(CheckLent(env_p0xy, s_p4, t_p7, lent_p3xy)));
            })
                : prism_rtl::is<crate::syntax::StmtKind::SWhile>(_m) ? ({
                auto&& body_p8 = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a1;
                prism_rtl::more(prism_rtl::rc(BorrowStmts(env_p0xy, s_p4, prism_rtl::deref(body_p8).stmts_p, lent_p3xy)));
            })
                : prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m) ? ({
                auto&& e_p9 = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
                ({
                auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p9).kind_p);
                prism_rtl::is<crate::syntax::ExprKind::EFor>(_m) ? ({
                auto&& binders_oa = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a0;
                auto&& source_pb = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a1;
                auto&& body_pc = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a2;
                ({
                auto binders_oax = binders_oa;
                auto body_pcx = body_pc;
                auto source_pbx = prism_rtl::deref(prism_rtl::deref(source_pb));
                (crate::prelude::call_then(start_ref_path_f(source_pbx), [=, binders_oax = std::move(binders_oax), body_pcx = std::move(body_pcx)](Array<Text> ref_path_f_7339) {
                return ({
                    auto path_pd = ref_path_f_7339;
                    auto lent2_pe = (crate::prelude::len(path_pd) > Nat(0u)) && (binders_oax != std::optional<crate::syntax::ForBinders>{})
                        ? crate::prelude::push(lent_p3xy, path_pd)
                        : lent_p3xy;
                    (prism_rtl::more(prism_rtl::rc(BorrowStmts(env_p0xy, s_p4, prism_rtl::deref(body_pcx).stmts_p, lent2_pe))));
                });
            }));
            });
            })
                : prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) ? ({
                auto&& tb_pf = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
                auto&& eb_og = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
                ({
                auto eb_ogx = eb_og;
                auto tb_pfx = tb_pf;
                (crate::prelude::call_then(start_borrow_stmts_f(env_p0xy, s_p4, prism_rtl::deref(tb_pfx).stmts_p, lent_p3xy), [=, eb_ogx = std::move(eb_ogx)](crate::check::types::St borrow_stmts_f_7544) {
                return ({
                    auto s2_ph = borrow_stmts_f_7544;
                    ({
                    prism_rtl::is_some(eb_ogx) ? ({
                    auto&& x_pi = prism_rtl::some_of(eb_ogx);
                    prism_rtl::more(prism_rtl::rc(BorrowStmts(env_p0xy, s2_ph, prism_rtl::deref(x_pi).stmts_p, lent_p3xy)));
                })
                    : prism_rtl::is_none(eb_ogx) ? prism_rtl::finished(s2_ph)
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            }));
            });
            })
                : prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m) ? ({
                auto&& arms_pj = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
                crate::prelude::fold_job(arms_pj, s_p4, ({
                auto env_p0xyx = env_p0xy;
                auto lent_p3xyx = lent_p3xy;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::Arm>)>>(prism_rtl::rc([=, env_p0xyx = std::move(env_p0xyx), lent_p3xyx = std::move(lent_p3xyx)](std::tuple<crate::check::types::St, crate::syntax::Arm> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto env_p0xyxy = env_p0xyx;
                    auto lent_p3xyxy = lent_p3xyx;
                    (crate::prelude::entered(crate::prelude::once_job([=, env_p0xyxy = std::move(env_p0xyxy), lent_p3xyxy = std::move(lent_p3xyxy)]() {
                    return ({
                        auto s3_pk = p0;
                        auto a_pl = p1;
                        (prism_rtl::more(prism_rtl::rc(BorrowStmts(env_p0xyxy, s3_pk, prism_rtl::deref(prism_rtl::deref(a_pl).body_p).stmts_p, lent_p3xyxy))));
                    });
                })));
                });
            })));
            }))->cycle();
            })
                : prism_rtl::finished(s_p4);
            });
            })
                : prism_rtl::finished(s_p4);
            });
            });
        })));
        });
    })));
    }))->cycle();
}


/// `Start BorrowStmts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_borrow_stmts_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Array<crate::syntax::Stmt> stmts_p2, Array<Array<Text>> lent_p3) {
    return prism_rtl::make_rc<BorrowStmts>(env_p0, st_p1, stmts_p2, lent_p3);
}


/// CheckLent: unbounded fn Env, St, Expr, [ [Text] ] -> St
crate::check::types::St check_lent_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Expr& t_p2, const Array<Array<Text>>& lent_p3) {
    auto path_p4 = ref_path_f(t_p2);
    return crate::prelude::fold(lent_p3, st_p1, [&](const crate::check::types::St& s_p5, const Array<Text>& l_p6) {
        return ((crate::prelude::len(path_p4) > Nat(0u)) && is_prefix_f(l_p6, path_p4)) || is_prefix_f(path_p4, l_p6)
            ? crate::check::types::recording::err_fix_f(s_p5, Text::lit("borrow-overlap"), t_p2.span_p, prism_rtl::cat("`", crate::syntax::lexer::chars::join_f(l_p6, Text::lit(".")), "` is lent to the `for`"), Text::lit("set it after the loop, or loop over a copy"))
            : s_p5;
    });
}


prism_rtl::Turn<crate::check::types::St> CheckLent::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& t_p2 = this->t_p2;
    const auto& lent_p3 = this->lent_p3;
    auto lent_p3x = lent_p3;
    auto st_p1x = st_p1;
    auto t_p2x = t_p2;
    return crate::prelude::call_then(start_ref_path_f(t_p2x), [=](Array<Text> ref_path_f_7915) {
        return ({
            auto path_p4 = ref_path_f_7915;
            (prism_rtl::finished(crate::prelude::fold(lent_p3x, st_p1x, [&](const crate::check::types::St& s_p5, const Array<Text>& l_p6) {
            return ((crate::prelude::len(path_p4) > Nat(0u)) && is_prefix_f(l_p6, path_p4)) || is_prefix_f(path_p4, l_p6)
                ? crate::check::types::recording::err_fix_f(s_p5, Text::lit("borrow-overlap"), prism_rtl::deref(t_p2x).span_p, prism_rtl::cat("`", crate::syntax::lexer::chars::join_f(l_p6, Text::lit(".")), "` is lent to the `for`"), Text::lit("set it after the loop, or loop over a copy"))
                : s_p5;
        })));
        });
    });
}


/// `Start CheckLent, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_check_lent_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Expr t_p2, Array<Array<Text>> lent_p3) {
    return prism_rtl::make_rc<CheckLent>(env_p0, st_p1, t_p2, lent_p3);
}


/// IsPrefix: fn [Text], [Text] -> Bool
bool is_prefix_f(const Array<Text>& a_p0, const Array<Text>& b_p1) {
    return (crate::prelude::len(a_p0) <= crate::prelude::len(b_p1)) && (crate::prelude::take(b_p1, crate::prelude::len(a_p0)) == a_p0);
}


/// RefPath: unbounded fn Expr -> [Text]
Array<Text> ref_path_f(const crate::syntax::Expr& e_p0) {
    auto&& _m = prism_rtl::deref(e_p0.kind_p);
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n_p1 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        return crate::syntax::lexer::chars::has_prefix_f(prism_rtl::deref(n_p1).sigils_p, Text::lit("&"))
            ? Array(std::vector{crate::check::env::sname_key_f(n_p1)})
            : Array<Text>{};
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EField>(_m)) {
        auto&& r_p2 = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a0;
        auto&& f_p3 = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a2;
        auto p_p4 = ref_path_f(prism_rtl::deref(prism_rtl::deref(r_p2)));
        return crate::prelude::len(p_p4) > Nat(0u)
            ? crate::prelude::push(p_p4, prism_rtl::deref(f_p3).name_p)
            : p_p4;
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m)) {
        auto&& r_p5 = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
        auto p_p6 = ref_path_f(prism_rtl::deref(prism_rtl::deref(r_p5)));
        return crate::prelude::len(p_p6) > Nat(0u)
            ? crate::prelude::push(p_p6, Text::lit("[]"))
            : p_p6;
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x_p7 = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return ref_path_f(prism_rtl::deref(prism_rtl::deref(x_p7)));
    }
    {
        return Array<Text>{};
    }
}


prism_rtl::Turn<Array<Text>> RefPath::cycle() const {
    const auto& e_p0 = this->e_p0;
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p0).kind_p);
        prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? ({
        auto&& n_p1 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        crate::syntax::lexer::chars::has_prefix_f(prism_rtl::deref(n_p1).sigils_p, Text::lit("&"))
        ? prism_rtl::finished(Array(std::vector{crate::check::env::sname_key_f(n_p1)}))
        : prism_rtl::finished(Array<Text>{});
    })
        : prism_rtl::is<crate::syntax::ExprKind::EField>(_m) ? ({
        auto&& r_p2 = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a0;
        auto&& f_p3 = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a2;
        ({
        auto f_p3x = f_p3;
        auto r_p2x = prism_rtl::deref(prism_rtl::deref(r_p2));
        (crate::prelude::call_then(start_ref_path_f(r_p2x), [=, f_p3x = std::move(f_p3x)](Array<Text> ref_path_f_8505) {
        return ({
            auto p_p4 = ref_path_f_8505;
            (crate::prelude::len(p_p4) > Nat(0u)
            ? prism_rtl::finished(crate::prelude::push(p_p4, prism_rtl::deref(f_p3x).name_p))
            : prism_rtl::finished(p_p4));
        });
    }));
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m) ? ({
        auto&& r_p5 = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
        ({
        auto r_p5x = prism_rtl::deref(prism_rtl::deref(r_p5));
        (crate::prelude::call_then(start_ref_path_f(r_p5x), [=](Array<Text> ref_path_f_8600) {
        return ({
            auto p_p6 = ref_path_f_8600;
            (crate::prelude::len(p_p6) > Nat(0u)
            ? prism_rtl::finished(crate::prelude::push(p_p6, Text::lit("[]")))
            : prism_rtl::finished(p_p6));
        });
    }));
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
        auto&& x_p7 = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(RefPath(prism_rtl::deref(prism_rtl::deref(x_p7)))));
    })
        : prism_rtl::finished(Array<Text>{});
    });
}


/// `Start RefPath, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_ref_path_f(crate::syntax::Expr e_p0) {
    return prism_rtl::make_rc<RefPath>(e_p0);
}

}  // namespace crate::check::passes::borrows
