// The module `Check.Passes.Borrows`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <check/passes/borrows/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Check.Passes.Borrows`, from `target/bootstrap/cpp-src/prismc/check/passes/borrows.prism`.
namespace crate::check::passes::borrows {

/// IsLocalType: unbounded fn St, Ty -> Bool
bool is_local_type(const crate::check::types::St& st_p0, const crate::check::types::Ty& t_p1) {
    auto&& _m = crate::check::types::recording::walk(st_p0, t_p1);
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
        auto&& m1393_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
        if (m1393_0_0 == Text::lit("Buffer")) {
            return true;
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
        auto&& m1393_1_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
        if (m1393_1_0 == Text::lit("Table")) {
            return true;
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(_m)) {
        auto&& e_p2 = prism_rtl::as<crate::check::types::Ty::TyArray>(_m).a0;
        return is_local_type(st_p0, prism_rtl::deref(e_p2));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(_m)) {
        auto&& ts_p3 = prism_rtl::as<crate::check::types::Ty::TyTuple>(_m).a0;
        return run_to_end(fold_job(ts_p3, false, ({
            auto st_p0_1 = st_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=, st_p0_1 = std::move(st_p0_1)](std::tuple<bool, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto st_p0_1_2 = st_p0_1;
                entered(once_job([=, st_p0_1_2 = std::move(st_p0_1_2)]() {
                return ({
                    auto seen_p4 = p0;
                    auto x_p5 = p1;
                    (prism_rtl::finished(std::move(seen_p4) || is_local_type(st_p0_1_2, x_p5)));
                });
            }));
            });
        })));
        })));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(_m)) {
        auto&& k_p6 = prism_rtl::as<crate::check::types::Ty::TyMap>(_m).a0;
        auto&& v_p7 = prism_rtl::as<crate::check::types::Ty::TyMap>(_m).a1;
        return is_local_type(st_p0, prism_rtl::deref(k_p6)) || is_local_type(st_p0, prism_rtl::deref(v_p7));
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(_m)) {
        auto&& i_p8 = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a1;
        return is_local_type(st_p0, prism_rtl::deref(i_p8));
    }
    {
        return false;
    }
}


prism_rtl::Turn<bool> IsLocalType::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& t_p1 = this->t_p1;
    auto st_p0_1 = st_p0;
    auto t_p1_2 = t_p1;
    return call_then(crate::check::types::recording::start_walk(st_p0_1, t_p1_2), [=](crate::check::types::Ty walk_1399) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TyCon>(walk_1399) && ({
            auto&& m1393_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_1399).a0;
            (m1393_0_0 == Text::lit("Buffer"));
        }) ? ({
            auto&& m1393_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_1399).a0;
            prism_rtl::finished(true);
        })
            : prism_rtl::is<crate::check::types::Ty::TyCon>(walk_1399) && ({
            auto&& m1393_1_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_1399).a0;
            (m1393_1_0 == Text::lit("Table"));
        }) ? ({
            auto&& m1393_1_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_1399).a0;
            prism_rtl::finished(true);
        })
            : prism_rtl::is<crate::check::types::Ty::TyArray>(walk_1399) ? ({
            auto&& e_p2 = prism_rtl::as<crate::check::types::Ty::TyArray>(walk_1399).a0;
            prism_rtl::more(prism_rtl::rc(IsLocalType(st_p0_1, prism_rtl::deref(e_p2))));
        })
            : prism_rtl::is<crate::check::types::Ty::TyTuple>(walk_1399) ? ({
            auto&& ts_p3 = prism_rtl::as<crate::check::types::Ty::TyTuple>(walk_1399).a0;
            fold_job(ts_p3, false, ({
            auto st_p0_1_3 = st_p0_1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=, st_p0_1_3 = std::move(st_p0_1_3)](std::tuple<bool, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto st_p0_1_3_3 = st_p0_1_3;
                entered(once_job([=, st_p0_1_3_3 = std::move(st_p0_1_3_3)]() {
                return ({
                    auto seen_p4 = p0;
                    auto x_p5 = p1;
                    (prism_rtl::finished(std::move(seen_p4) || is_local_type(st_p0_1_3_3, x_p5)));
                });
            }));
            });
        })));
        }))->cycle();
        })
            : prism_rtl::is<crate::check::types::Ty::TyMap>(walk_1399) ? ({
            auto&& k_p6 = prism_rtl::as<crate::check::types::Ty::TyMap>(walk_1399).a0;
            auto&& v_p7 = prism_rtl::as<crate::check::types::Ty::TyMap>(walk_1399).a1;
            call_then(start_is_local_type(st_p0_1, prism_rtl::deref(k_p6)), [=](bool is_local_type_1595) { return prism_rtl::finished(is_local_type_1595 || is_local_type(st_p0_1, prism_rtl::deref(v_p7))); });
        })
            : prism_rtl::is<crate::check::types::Ty::TySig>(walk_1399) ? ({
            auto&& i_p8 = prism_rtl::as<crate::check::types::Ty::TySig>(walk_1399).a1;
            prism_rtl::more(prism_rtl::rc(IsLocalType(st_p0_1, prism_rtl::deref(i_p8))));
        })
            : prism_rtl::finished(false);
        });
    });
}


/// `Start IsLocalType, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_is_local_type(crate::check::types::St st_p0, crate::check::types::Ty t_p1) {
    return prism_rtl::make_rc<IsLocalType>(st_p0, t_p1);
}


/// AndBlockChecks: unbounded fn Env, St, Block, Ty -> St
crate::check::types::St and_block_checks(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Block& b_p2, const crate::check::types::Ty& t_p3) {
    auto st1_p4 = is_local_type(st_p1, t_p3)
        ? crate::check::types::recording::err_fix(st_p1, Text::lit("local-escapes"), b_p2.span, prism_rtl::cat("a `", block_local_name(st_p1, t_p3), "` cannot leave its block"), Text::lit("`Freeze` it into a plain value first"))
        : st_p1;
    auto st2_p5 = escape_stmts(env_p0, st1_p4, b_p2.stmts);
    auto&& _st3_p6 = frozen_stmts(env_p0, st2_p5, b_p2.stmts, Map<Text, Nat>{});
    auto&& st3_p6 = std::get<1>(_st3_p6);
    return borrow_stmts(env_p0, st3_p6, b_p2.stmts, Array<Array<Text>>{});
}


prism_rtl::Turn<crate::check::types::St> AndBlockChecks::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& b_p2 = this->b_p2;
    const auto& t_p3 = this->t_p3;
    auto b_p2_1 = b_p2;
    auto env_p0_2 = env_p0;
    auto st_p1_3 = st_p1;
    auto t_p3_4 = t_p3;
    return call_then(start_is_local_type(st_p1_3, t_p3_4), [=](bool is_local_type_1949) {
        return ({
            auto st1_p4 = is_local_type_1949
                ? crate::check::types::recording::err_fix(st_p1_3, Text::lit("local-escapes"), prism_rtl::deref(b_p2_1).span, prism_rtl::cat("a `", block_local_name(st_p1_3, t_p3_4), "` cannot leave its block"), Text::lit("`Freeze` it into a plain value first"))
                : st_p1_3;
            call_then(start_escape_stmts(env_p0_2, st1_p4, prism_rtl::deref(b_p2_1).stmts), [=](crate::check::types::St escape_stmts_2119) {
            return ({
                auto st2_p5 = escape_stmts_2119;
                call_then(start_frozen_stmts(env_p0_2, st2_p5, prism_rtl::deref(b_p2_1).stmts, Map<Text, Nat>{}), [=](std::tuple<Map<Text, Nat>, crate::check::types::St> frozen_stmts_2175) {
                return ({
                    auto&& _st3_p6 = frozen_stmts_2175;
                    auto&& st3_p6 = std::get<1>(_st3_p6);
                    (prism_rtl::more(prism_rtl::rc(BorrowStmts(env_p0_2, st3_p6, prism_rtl::deref(b_p2_1).stmts, Array<Array<Text>>{}))));
                });
            });
            });
        });
        });
    });
}


/// `Start AndBlockChecks, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_and_block_checks(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Block b_p2, crate::check::types::Ty t_p3) {
    return prism_rtl::make_rc<AndBlockChecks>(env_p0, st_p1, b_p2, t_p3);
}


/// BlockLocalName: unbounded fn St, Ty -> Text
Text block_local_name(const crate::check::types::St& st_p0, const crate::check::types::Ty& t_p1) {
    auto&& _m = crate::check::types::recording::walk(st_p0, t_p1);
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
        auto&& n_p2 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
        return n_p2;
    }
    {
        return Text::lit("Buffer");
    }
}


prism_rtl::Turn<Text> BlockLocalName::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& t_p1 = this->t_p1;
    auto st_p0_1 = st_p0;
    auto t_p1_2 = t_p1;
    return call_then(crate::check::types::recording::start_walk(st_p0_1, t_p1_2), [=](crate::check::types::Ty walk_2326) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TyCon>(walk_2326) ? ({
            auto&& n_p2 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_2326).a0;
            prism_rtl::finished(n_p2);
        })
            : prism_rtl::finished(Text::lit("Buffer"));
        });
    });
}


/// `Start BlockLocalName, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_block_local_name(crate::check::types::St st_p0, crate::check::types::Ty t_p1) {
    return prism_rtl::make_rc<BlockLocalName>(st_p0, t_p1);
}


/// EscapeStmts: unbounded fn Env, St, [Stmt] -> St
crate::check::types::St escape_stmts(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const Array<crate::syntax::Stmt>& stmts_p2) {
    return run_to_end(fold_job(stmts_p2, st_p1, ({
        auto env_p0_1 = env_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::Stmt>)>>(prism_rtl::rc([=, env_p0_1 = std::move(env_p0_1)](std::tuple<crate::check::types::St, crate::syntax::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_p0_1_2 = env_p0_1;
            entered(once_job([=, env_p0_1_2 = std::move(env_p0_1_2)]() {
            return ({
                auto s_p3 = p0;
                auto stmt_p4 = p1;
                ({
                auto&& _m = prism_rtl::deref(stmt_p4).kind;
                prism_rtl::is<crate::syntax::StmtKind::SLet>(_m) ? ({
                auto&& p_p5 = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
                auto&& e_p6 = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
                ({
                auto&& _m = prism_rtl::deref(prism_rtl::deref(p_p5).kind);
                prism_rtl::is<crate::syntax::PatternKind::PName>(_m) ? ({
                auto&& n_p7 = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
                crate::syntax::lexer::chars::has_prefix(prism_rtl::deref(n_p7).sigils, Text::lit("&"))
                ? prism_rtl::finished(s_p3)
                : ({
                auto&& _m = crate::prelude::get(env_p0_1_2.locals, crate::check::env::sname_key(n_p7));
                prism_rtl::is_some(_m) ? prism_rtl::finished(s_p3)
                : prism_rtl::is_none(_m) ? calls_local_maker(env_p0_1_2, e_p6)
                ? prism_rtl::finished(crate::check::types::recording::err_fix(s_p3, Text::lit("local-escapes"), prism_rtl::deref(stmt_p4).span, prism_rtl::cat("a `Buffer` cannot leave its block: `", crate::check::env::sname_key(n_p7), "` is no `&` local"), prism_rtl::cat("write `let &", crate::check::env::sname_key(n_p7), " = ...`")))
                : prism_rtl::finished(s_p3)
                : throw prism_rtl::Panic("no arm matched");
            });
            })
                : prism_rtl::finished(s_p3);
            });
            })
                : prism_rtl::is<crate::syntax::StmtKind::SWhile>(_m) ? ({
                auto&& body_p8 = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a1;
                prism_rtl::more(prism_rtl::rc(EscapeStmts(env_p0_1_2, s_p3, prism_rtl::deref(body_p8).stmts)));
            })
                : prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m) ? ({
                auto&& e_p9 = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
                ({
                auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p9).kind);
                prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) ? ({
                auto&& tb_pa = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
                auto&& eb_ob = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
                ({
                auto eb_ob_2 = eb_ob;
                auto tb_pa_3 = tb_pa;
                call_then(start_escape_stmts(env_p0_1_2, s_p3, prism_rtl::deref(tb_pa_3).stmts), [=, eb_ob_2 = std::move(eb_ob_2)](crate::check::types::St escape_stmts_3035) {
                return ({
                    auto s2_pc = escape_stmts_3035;
                    ({
                    prism_rtl::is_some(eb_ob_2) ? ({
                    auto&& x_pd = prism_rtl::some_of(eb_ob_2);
                    prism_rtl::more(prism_rtl::rc(EscapeStmts(env_p0_1_2, s2_pc, prism_rtl::deref(x_pd).stmts)));
                })
                    : prism_rtl::is_none(eb_ob_2) ? prism_rtl::finished(s2_pc)
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            });
            });
            })
                : prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m) ? ({
                auto&& arms_pe = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
                fold_job(arms_pe, s_p3, ({
                auto env_p0_1_2_2 = env_p0_1_2;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::Arm>)>>(prism_rtl::rc([=, env_p0_1_2_2 = std::move(env_p0_1_2_2)](std::tuple<crate::check::types::St, crate::syntax::Arm> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto env_p0_1_2_2_2 = env_p0_1_2_2;
                    entered(once_job([=, env_p0_1_2_2_2 = std::move(env_p0_1_2_2_2)]() {
                    return ({
                        auto s3_pf = p0;
                        auto a_pg = p1;
                        (prism_rtl::more(prism_rtl::rc(EscapeStmts(env_p0_1_2_2_2, s3_pf, prism_rtl::deref(prism_rtl::deref(a_pg).body).stmts))));
                    });
                }));
                });
            })));
            }))->cycle();
            })
                : prism_rtl::is<crate::syntax::ExprKind::EFor>(_m) ? ({
                auto&& body_ph = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a2;
                prism_rtl::more(prism_rtl::rc(EscapeStmts(env_p0_1_2, s_p3, prism_rtl::deref(body_ph).stmts)));
            })
                : prism_rtl::finished(s_p3);
            });
            })
                : prism_rtl::finished(s_p3);
            });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<crate::check::types::St> EscapeStmts::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& stmts_p2 = this->stmts_p2;
    return fold_job(stmts_p2, st_p1, ({
        auto env_p0_1 = env_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::Stmt>)>>(prism_rtl::rc([=, env_p0_1 = std::move(env_p0_1)](std::tuple<crate::check::types::St, crate::syntax::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_p0_1_2 = env_p0_1;
            entered(once_job([=, env_p0_1_2 = std::move(env_p0_1_2)]() {
            return ({
                auto s_p3 = p0;
                auto stmt_p4 = p1;
                ({
                auto&& _m = prism_rtl::deref(stmt_p4).kind;
                prism_rtl::is<crate::syntax::StmtKind::SLet>(_m) ? ({
                auto&& p_p5 = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
                auto&& e_p6 = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
                ({
                auto&& _m = prism_rtl::deref(prism_rtl::deref(p_p5).kind);
                prism_rtl::is<crate::syntax::PatternKind::PName>(_m) ? ({
                auto&& n_p7 = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
                crate::syntax::lexer::chars::has_prefix(prism_rtl::deref(n_p7).sigils, Text::lit("&"))
                ? prism_rtl::finished(s_p3)
                : ({
                auto&& _m = crate::prelude::get(prism_rtl::deref(env_p0_1_2).locals, crate::check::env::sname_key(n_p7));
                prism_rtl::is_some(_m) ? prism_rtl::finished(s_p3)
                : prism_rtl::is_none(_m) ? calls_local_maker(env_p0_1_2, e_p6)
                ? prism_rtl::finished(crate::check::types::recording::err_fix(s_p3, Text::lit("local-escapes"), prism_rtl::deref(stmt_p4).span, prism_rtl::cat("a `Buffer` cannot leave its block: `", crate::check::env::sname_key(n_p7), "` is no `&` local"), prism_rtl::cat("write `let &", crate::check::env::sname_key(n_p7), " = ...`")))
                : prism_rtl::finished(s_p3)
                : throw prism_rtl::Panic("no arm matched");
            });
            })
                : prism_rtl::finished(s_p3);
            });
            })
                : prism_rtl::is<crate::syntax::StmtKind::SWhile>(_m) ? ({
                auto&& body_p8 = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a1;
                prism_rtl::more(prism_rtl::rc(EscapeStmts(env_p0_1_2, s_p3, prism_rtl::deref(body_p8).stmts)));
            })
                : prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m) ? ({
                auto&& e_p9 = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
                ({
                auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p9).kind);
                prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) ? ({
                auto&& tb_pa = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
                auto&& eb_ob = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
                ({
                auto eb_ob_2 = eb_ob;
                auto tb_pa_3 = tb_pa;
                call_then(start_escape_stmts(env_p0_1_2, s_p3, prism_rtl::deref(tb_pa_3).stmts), [=, eb_ob_2 = std::move(eb_ob_2)](crate::check::types::St escape_stmts_3035) {
                return ({
                    auto s2_pc = escape_stmts_3035;
                    ({
                    prism_rtl::is_some(eb_ob_2) ? ({
                    auto&& x_pd = prism_rtl::some_of(eb_ob_2);
                    prism_rtl::more(prism_rtl::rc(EscapeStmts(env_p0_1_2, s2_pc, prism_rtl::deref(x_pd).stmts)));
                })
                    : prism_rtl::is_none(eb_ob_2) ? prism_rtl::finished(s2_pc)
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            });
            });
            })
                : prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m) ? ({
                auto&& arms_pe = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
                fold_job(arms_pe, s_p3, ({
                auto env_p0_1_2_2 = env_p0_1_2;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::Arm>)>>(prism_rtl::rc([=, env_p0_1_2_2 = std::move(env_p0_1_2_2)](std::tuple<crate::check::types::St, crate::syntax::Arm> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto env_p0_1_2_2_2 = env_p0_1_2_2;
                    entered(once_job([=, env_p0_1_2_2_2 = std::move(env_p0_1_2_2_2)]() {
                    return ({
                        auto s3_pf = p0;
                        auto a_pg = p1;
                        (prism_rtl::more(prism_rtl::rc(EscapeStmts(env_p0_1_2_2_2, s3_pf, prism_rtl::deref(prism_rtl::deref(a_pg).body).stmts))));
                    });
                }));
                });
            })));
            }))->cycle();
            })
                : prism_rtl::is<crate::syntax::ExprKind::EFor>(_m) ? ({
                auto&& body_ph = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a2;
                prism_rtl::more(prism_rtl::rc(EscapeStmts(env_p0_1_2, s_p3, prism_rtl::deref(body_ph).stmts)));
            })
                : prism_rtl::finished(s_p3);
            });
            })
                : prism_rtl::finished(s_p3);
            });
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start EscapeStmts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_escape_stmts(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Array<crate::syntax::Stmt> stmts_p2) {
    return prism_rtl::make_rc<EscapeStmts>(env_p0, st_p1, stmts_p2);
}


/// CallsLocalMaker: fn Env, Expr -> Bool
bool calls_local_maker(const crate::check::expr::Env& env_p0, const crate::syntax::Expr& e_p1) {
    auto&& _m = prism_rtl::deref(e_p1.kind);
    if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
        auto&& c_p2 = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
        return maker_of(env_p0, prism_rtl::deref(prism_rtl::deref(c_p2))) != std::optional<Text>{};
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& _m = maker_of(env_p0, e_p1);
        if (prism_rtl::is_some(_m)) {
            auto&& k_p3 = prism_rtl::some_of(_m);
            return k_p3 != Text::lit("Buffer.Numbered");
        }
        if (prism_rtl::is_none(_m)) {
            return false;
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x_p4 = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return calls_local_maker(env_p0, prism_rtl::deref(prism_rtl::deref(x_p4)));
    }
    {
        return false;
    }
}


/// ?MakerOf: fn Env, Expr -> ?Text
std::optional<Text> maker_of(const crate::check::expr::Env& env_p0, const crate::syntax::Expr& c_p1) {
    auto&& _m = crate::check::shrink::walk::callee_name(c_p1);
    if (prism_rtl::is_some(_m)) {
        auto&& n_p2 = prism_rtl::some_of(_m);
        return crate::check::env::has_key(env_p0.locals, n_p2)
            ? std::optional<Text>{}
            : ({
            __label__ _done;
            prism_rtl::Slot<std::optional<Text>> _v;
            auto&& _m = crate::check::shrink::locals::resolve_name(env_p0.g, env_p0.home, n_p2);
            if (prism_rtl::is_some(_m)) {
                auto&& k_p3 = prism_rtl::some_of(_m);
                _v.set(crate::check::expr::calls::is_local_maker(k_p3) && (prism_rtl::deref(or_(crate::prelude::get(prism_rtl::deref(env_p0.g).vals, k_p3), crate::check::dummy_val())).sort == Text::lit("builtin"))
                    ? std::optional(k_p3)
                    : std::optional<Text>{});
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(std::optional<Text>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    }
    if (prism_rtl::is_none(_m)) {
        return std::optional<Text>{};
    }
    prism_rtl::unreachable("no arm matched");
}


/// FrozenStmts: unbounded fn Env, St, [Stmt], (Text ==> Nat) -> (((Text ==> Nat), St))
std::tuple<Map<Text, Nat>, crate::check::types::St> frozen_stmts(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const Array<crate::syntax::Stmt>& stmts_p2, const Map<Text, Nat>& frozen_p3) {
    auto pre_p4 = crate::check::shrink::relations::prelude_seeds(env_p0.g, env_p0.home);
    auto seeds_p5 = fold(keys(pre_p4), pre_p4, [&](const Map<Text, crate::check::shrink::Rel>& m_p7, const Text& k_p8) {
        return crate::check::env::has_key(env_p0.locals, crate::syntax::lexer::chars::drop_prefix(k_p8, Text::lit("pre:")))
            ? crate::prelude::remove(m_p7, k_p8)
            : m_p7;
    });
    auto bm_p6 = crate::check::shrink::relations::block_rels(stmts_p2, seeds_p5);
    return run_to_end(fold_job(stmts_p2, std::tuple{frozen_p3, st_p1}, ({
        auto bm_p6_1 = bm_p6;
        auto env_p0_2 = env_p0;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Map<Text, Nat>, crate::check::types::St>>(std::tuple<std::tuple<Map<Text, Nat>, crate::check::types::St>, crate::syntax::Stmt>)>>(prism_rtl::rc([=, bm_p6_1 = std::move(bm_p6_1), env_p0_2 = std::move(env_p0_2)](std::tuple<std::tuple<Map<Text, Nat>, crate::check::types::St>, crate::syntax::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto bm_p6_1_3 = bm_p6_1;
            auto env_p0_2_3 = env_p0_2;
            entered(once_job([=, bm_p6_1_3 = std::move(bm_p6_1_3), env_p0_2_3 = std::move(env_p0_2_3)]() {
            return ({
                auto [fz_p9, s_pa] = p0;
                auto stmt_pb = p1;
                call_then(crate::check::shrink::walk::start_stmt_spots(stmt_pb, bm_p6_1_3), [=](Array<crate::check::shrink::walk::Spot> stmt_spots_4900) {
                return ({
                    auto spots_pc = stmt_spots_4900;
                    auto reads_pd = fold(spots_pc, Array<std::tuple<Text, crate::syntax::Range>>{}, [&](const Array<std::tuple<Text, crate::syntax::Range>>& acc_ph, const crate::check::shrink::walk::Spot& sp_pi) { return append(acc_ph, spot_refs(sp_pi)); });
                    auto s2_pe = fold(reads_pd, s_pa, [&](const crate::check::types::St& s1_pj, const std::tuple<Text, crate::syntax::Range>& _p1) {
                        auto&& n_pk = std::get<0>(_p1);
                        auto&& sp_pl = std::get<1>(_p1);
                        return ({
                            __label__ _done;
                            prism_rtl::Slot<crate::check::types::St> _v;
                            auto&& _m = crate::prelude::get(fz_p9, n_pk);
                            if (prism_rtl::is_some(_m)) {
                                auto&& line_pm = prism_rtl::some_of(_m);
                                _v.set(crate::check::types::recording::err_fix(s1_pj, Text::lit("frozen"), sp_pl, prism_rtl::cat("`", n_pk, "` was frozen on line ", line_pm + Nat(1u)), Text::lit("use the frozen value, or make a new local")));
                                goto _done;
                            }
                            if (prism_rtl::is_none(_m)) {
                                _v.set(s1_pj);
                                goto _done;
                            }
                            prism_rtl::unreachable("no arm matched");
                        _done:
                            _v.take();
                        });
                    });
                    auto fz1_pf = ({
                        __label__ _done;
                        prism_rtl::Slot<Map<Text, Nat>> _v;
                        auto&& _m = prism_rtl::deref(stmt_pb).kind;
                        if (prism_rtl::is<crate::syntax::StmtKind::SLet>(_m)) {
                            auto&& p_pn = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
                            _v.set(fold(crate::check::env::names::pattern_names(p_pn), fz_p9, [&](const Map<Text, Nat>& m_po, const Text& n_pp) { return crate::prelude::remove(m_po, n_pp); }));
                            goto _done;
                        }
                        {
                            _v.set(fz_p9);
                            goto _done;
                        }
                    _done:
                        _v.take();
                    });
                    call_value(fold_job(spots_pc, fz1_pf, ({
                    auto env_p0_2_3_3 = env_p0_2_3;
                    auto stmt_pb_3 = stmt_pb;
                    static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Nat>>(std::tuple<Map<Text, Nat>, crate::check::shrink::walk::Spot>)>>(prism_rtl::rc([=, env_p0_2_3_3 = std::move(env_p0_2_3_3), stmt_pb_3 = std::move(stmt_pb_3)](std::tuple<Map<Text, Nat>, crate::check::shrink::walk::Spot> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto env_p0_2_3_3_4 = env_p0_2_3_3;
                        auto stmt_pb_3_4 = stmt_pb_3;
                        entered(once_job([=, env_p0_2_3_3_4 = std::move(env_p0_2_3_3_4), stmt_pb_3_4 = std::move(stmt_pb_3_4)]() {
                        return ({
                            auto m_pq = p0;
                            auto sp_pr = p1;
                            call_then(start_spot_freezes(sp_pr), [=, m_pq = std::move(m_pq)](Array<Text> spot_freezes_5398) { return prism_rtl::finished(fold(spot_freezes_5398, m_pq, [&](const Map<Text, Nat>& m2_ps, const Text& n_pt) { return insert(m2_ps, n_pt, crate::check::errors::cline_of(prism_rtl::deref(env_p0_2_3_3_4.src).starts, prism_rtl::deref(prism_rtl::deref(stmt_pb_3_4).span).start)); })); });
                        });
                    }));
                    });
                }));
                })), [=, s2_pe = std::move(s2_pe)](Map<Text, Nat> fold_5366) {
                    return ({
                        auto fz2_pg = fold_5366;
                        (prism_rtl::finished(std::tuple{fz2_pg, s2_pe}));
                    });
                });
                });
            });
            });
        }));
        });
    }));
    })));
}


prism_rtl::Turn<std::tuple<Map<Text, Nat>, crate::check::types::St>> FrozenStmts::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& stmts_p2 = this->stmts_p2;
    const auto& frozen_p3 = this->frozen_p3;
    auto pre_p4 = crate::check::shrink::relations::prelude_seeds(prism_rtl::deref(env_p0).g, prism_rtl::deref(env_p0).home);
    auto seeds_p5 = fold(keys(pre_p4), pre_p4, [&](const Map<Text, crate::check::shrink::Rel>& m_p7, const Text& k_p8) {
        return crate::check::env::has_key(prism_rtl::deref(env_p0).locals, crate::syntax::lexer::chars::drop_prefix(k_p8, Text::lit("pre:")))
            ? crate::prelude::remove(m_p7, k_p8)
            : m_p7;
    });
    auto env_p0_1 = env_p0;
    auto frozen_p3_2 = frozen_p3;
    auto st_p1_3 = st_p1;
    auto stmts_p2_4 = stmts_p2;
    return call_then(crate::check::shrink::relations::start_block_rels(stmts_p2_4, seeds_p5), [=](Map<Text, crate::check::shrink::Rel> block_rels_4806) {
        return ({
            auto bm_p6 = block_rels_4806;
            fold_job(stmts_p2_4, std::tuple{frozen_p3_2, st_p1_3}, ({
            auto bm_p6_5 = bm_p6;
            auto env_p0_1_6 = env_p0_1;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Map<Text, Nat>, crate::check::types::St>>(std::tuple<std::tuple<Map<Text, Nat>, crate::check::types::St>, crate::syntax::Stmt>)>>(prism_rtl::rc([=, bm_p6_5 = std::move(bm_p6_5), env_p0_1_6 = std::move(env_p0_1_6)](std::tuple<std::tuple<Map<Text, Nat>, crate::check::types::St>, crate::syntax::Stmt> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto bm_p6_5_6 = bm_p6_5;
                auto env_p0_1_6_6 = env_p0_1_6;
                entered(once_job([=, bm_p6_5_6 = std::move(bm_p6_5_6), env_p0_1_6_6 = std::move(env_p0_1_6_6)]() {
                return ({
                    auto [fz_p9, s_pa] = p0;
                    auto stmt_pb = p1;
                    call_then(crate::check::shrink::walk::start_stmt_spots(stmt_pb, bm_p6_5_6), [=](Array<crate::check::shrink::walk::Spot> stmt_spots_4900) {
                    return ({
                        auto spots_pc = stmt_spots_4900;
                        auto reads_pd = fold(spots_pc, Array<std::tuple<Text, crate::syntax::Range>>{}, [&](const Array<std::tuple<Text, crate::syntax::Range>>& acc_ph, const crate::check::shrink::walk::Spot& sp_pi) { return append(acc_ph, spot_refs(sp_pi)); });
                        auto s2_pe = fold(reads_pd, s_pa, [&](const crate::check::types::St& s1_pj, const std::tuple<Text, crate::syntax::Range>& _p1) {
                            auto&& n_pk = std::get<0>(_p1);
                            auto&& sp_pl = std::get<1>(_p1);
                            return ({
                                __label__ _done;
                                prism_rtl::Slot<crate::check::types::St> _v;
                                auto&& _m = crate::prelude::get(fz_p9, n_pk);
                                if (prism_rtl::is_some(_m)) {
                                    auto&& line_pm = prism_rtl::some_of(_m);
                                    _v.set(crate::check::types::recording::err_fix(s1_pj, Text::lit("frozen"), sp_pl, prism_rtl::cat("`", n_pk, "` was frozen on line ", line_pm + Nat(1u)), Text::lit("use the frozen value, or make a new local")));
                                    goto _done;
                                }
                                if (prism_rtl::is_none(_m)) {
                                    _v.set(s1_pj);
                                    goto _done;
                                }
                                prism_rtl::unreachable("no arm matched");
                            _done:
                                _v.take();
                            });
                        });
                        auto fz1_pf = ({
                            __label__ _done;
                            prism_rtl::Slot<Map<Text, Nat>> _v;
                            auto&& _m = prism_rtl::deref(stmt_pb).kind;
                            if (prism_rtl::is<crate::syntax::StmtKind::SLet>(_m)) {
                                auto&& p_pn = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
                                _v.set(fold(crate::check::env::names::pattern_names(p_pn), fz_p9, [&](const Map<Text, Nat>& m_po, const Text& n_pp) { return crate::prelude::remove(m_po, n_pp); }));
                                goto _done;
                            }
                            {
                                _v.set(fz_p9);
                                goto _done;
                            }
                        _done:
                            _v.take();
                        });
                        call_value(fold_job(spots_pc, fz1_pf, ({
                        auto env_p0_1_6_6_6 = env_p0_1_6_6;
                        auto stmt_pb_6 = stmt_pb;
                        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Nat>>(std::tuple<Map<Text, Nat>, crate::check::shrink::walk::Spot>)>>(prism_rtl::rc([=, env_p0_1_6_6_6 = std::move(env_p0_1_6_6_6), stmt_pb_6 = std::move(stmt_pb_6)](std::tuple<Map<Text, Nat>, crate::check::shrink::walk::Spot> _p0) {
                        auto&& p0 = std::get<0>(_p0);
                        auto&& p1 = std::get<1>(_p0);
                        return ({
                            auto env_p0_1_6_6_6_7 = env_p0_1_6_6_6;
                            auto stmt_pb_6_7 = stmt_pb_6;
                            entered(once_job([=, env_p0_1_6_6_6_7 = std::move(env_p0_1_6_6_6_7), stmt_pb_6_7 = std::move(stmt_pb_6_7)]() {
                            return ({
                                auto m_pq = p0;
                                auto sp_pr = p1;
                                call_then(start_spot_freezes(sp_pr), [=, m_pq = std::move(m_pq)](Array<Text> spot_freezes_5398) { return prism_rtl::finished(fold(spot_freezes_5398, m_pq, [&](const Map<Text, Nat>& m2_ps, const Text& n_pt) { return insert(m2_ps, n_pt, crate::check::errors::cline_of(prism_rtl::deref(prism_rtl::deref(env_p0_1_6_6_6_7).src).starts, prism_rtl::deref(prism_rtl::deref(stmt_pb_6_7).span).start)); })); });
                            });
                        }));
                        });
                    }));
                    })), [=, s2_pe = std::move(s2_pe)](Map<Text, Nat> fold_5366) {
                        return ({
                            auto fz2_pg = fold_5366;
                            (prism_rtl::finished(std::tuple{fz2_pg, s2_pe}));
                        });
                    });
                    });
                });
                });
            }));
            });
        }));
        }))->cycle();
        });
    });
}


/// `Start FrozenStmts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Map<Text, Nat>, crate::check::types::St>> start_frozen_stmts(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Array<crate::syntax::Stmt> stmts_p2, Map<Text, Nat> frozen_p3) {
    return prism_rtl::make_rc<FrozenStmts>(env_p0, st_p1, stmts_p2, frozen_p3);
}


/// SpotRefs: fn Spot -> [((Text, Range))]
Array<std::tuple<Text, crate::syntax::Range>> spot_refs(const crate::check::shrink::walk::Spot& spot0) {
    if (prism_rtl::is<crate::check::shrink::walk::Spot::SpotExpr>(spot0)) {
        auto&& e_p0 = prism_rtl::as<crate::check::shrink::walk::Spot::SpotExpr>(spot0).a0;
        auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p0).kind);
        if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
            auto&& n_p1 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
            return crate::syntax::lexer::chars::has_prefix(prism_rtl::deref(n_p1).sigils, Text::lit("&"))
                ? Array(std::vector{std::tuple{crate::check::env::sname_key(n_p1), prism_rtl::deref(n_p1).span}})
                : Array<std::tuple<Text, crate::syntax::Range>>{};
        }
        {
            return Array<std::tuple<Text, crate::syntax::Range>>{};
        }
    }
    if (prism_rtl::is<crate::check::shrink::walk::Spot::SpotStmt>(spot0)) {
        return Array<std::tuple<Text, crate::syntax::Range>>{};
    }
    prism_rtl::unreachable("no arm matched");
}


/// SpotFreezes: unbounded fn Spot -> [Text]
Array<Text> spot_freezes(const crate::check::shrink::walk::Spot& spot0) {
    if (prism_rtl::is<crate::check::shrink::walk::Spot::SpotExpr>(spot0)) {
        auto&& e_p0 = prism_rtl::as<crate::check::shrink::walk::Spot::SpotExpr>(spot0).a0;
        auto&& m_p1 = prism_rtl::as<crate::check::shrink::walk::Spot::SpotExpr>(spot0).a1;
        auto&& _m = crate::check::shrink::walk::call_of(e_p0);
        if (prism_rtl::is_some(_m)) {
            auto&& c_p2 = std::get<0>(prism_rtl::some_of(_m));
            auto&& args_p3 = std::get<1>(prism_rtl::some_of(_m));
            auto&& _m = crate::check::shrink::walk::callee_name(c_p2);
            if (prism_rtl::is_some(_m)) {
                auto&& n_p4 = prism_rtl::some_of(_m);
                return crate::check::shrink::relations::pre_is(m_p1, n_p4, Text::lit("Freeze"))
                    ? run_to_end(fold_job(args_p3, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Arg>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Arg> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return entered(once_job([=]() {
                        return ({
                            auto acc_p5 = p0;
                            auto a_p6 = p1;
                            (prism_rtl::finished(append(acc_p5, each(refs_in(a_p6->value), [&](const std::tuple<Text, crate::syntax::Range>& _p0) {
                            auto&& n2_p7 = std::get<0>(_p0);
                            return n2_p7;
                        }))));
                        });
                    }));
                }))))
                    : Array<Text>{};
            }
            if (prism_rtl::is_none(_m)) {
                return Array<Text>{};
            }
            prism_rtl::unreachable("no arm matched");
        }
        if (prism_rtl::is_none(_m)) {
            return Array<Text>{};
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<crate::check::shrink::walk::Spot::SpotStmt>(spot0)) {
        return Array<Text>{};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Text>> SpotFreezes::cycle() const {
    const auto& spot0 = this->spot0;
    return ({
        prism_rtl::is<crate::check::shrink::walk::Spot::SpotExpr>(spot0) ? ({
        auto&& e_p0 = prism_rtl::as<crate::check::shrink::walk::Spot::SpotExpr>(spot0).a0;
        auto&& m_p1 = prism_rtl::as<crate::check::shrink::walk::Spot::SpotExpr>(spot0).a1;
        ({
        auto&& _m = crate::check::shrink::walk::call_of(e_p0);
        prism_rtl::is_some(_m) ? ({
        auto&& c_p2 = std::get<0>(prism_rtl::some_of(_m));
        auto&& args_p3 = std::get<1>(prism_rtl::some_of(_m));
        ({
        auto&& _m = crate::check::shrink::walk::callee_name(c_p2);
        prism_rtl::is_some(_m) ? ({
        auto&& n_p4 = prism_rtl::some_of(_m);
        crate::check::shrink::relations::pre_is(m_p1, n_p4, Text::lit("Freeze"))
        ? fold_job(args_p3, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Arg>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Arg> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc_p5 = p0;
                auto a_p6 = p1;
                (prism_rtl::finished(append(acc_p5, each(refs_in(a_p6->value), [&](const std::tuple<Text, crate::syntax::Range>& _p0) {
                auto&& n2_p7 = std::get<0>(_p0);
                return n2_p7;
            }))));
            });
        }));
    })))->cycle()
        : prism_rtl::finished(Array<Text>{});
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(Array<Text>{})
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(Array<Text>{})
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : prism_rtl::is<crate::check::shrink::walk::Spot::SpotStmt>(spot0) ? prism_rtl::finished(Array<Text>{})
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start SpotFreezes, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_spot_freezes(crate::check::shrink::walk::Spot spot0) {
    return prism_rtl::make_rc<SpotFreezes>(spot0);
}


/// RefsIn: unbounded fn Expr -> [((Text, Range))]
Array<std::tuple<Text, crate::syntax::Range>> refs_in(const crate::syntax::Expr& e_p0) {
    auto&& _m = prism_rtl::deref(e_p0.kind);
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n_p1 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        return crate::syntax::lexer::chars::has_prefix(prism_rtl::deref(n_p1).sigils, Text::lit("&"))
            ? Array(std::vector{std::tuple{crate::check::env::sname_key(n_p1), prism_rtl::deref(n_p1).span}})
            : Array<std::tuple<Text, crate::syntax::Range>>{};
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
        auto&& c_p2 = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
        auto&& args_p3 = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
        return run_to_end(fold_job(args_p3, refs_in(prism_rtl::deref(prism_rtl::deref(c_p2))), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Text, crate::syntax::Range>>>(std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::syntax::Arg>)>>(prism_rtl::rc([=](std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::syntax::Arg> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc_p4 = p0;
                    auto a_p5 = p1;
                    (prism_rtl::finished(append(acc_p4, refs_in(a_p5->value))));
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EBinary>(_m)) {
        auto&& l_p6 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
        auto&& r_p7 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a2;
        return append(refs_in(prism_rtl::deref(prism_rtl::deref(l_p6))), refs_in(prism_rtl::deref(prism_rtl::deref(r_p7))));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EUnary>(_m)) {
        auto&& x_p8 = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a1;
        return refs_in(prism_rtl::deref(prism_rtl::deref(x_p8)));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m)) {
        auto&& x_p9 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
        return refs_in(prism_rtl::deref(prism_rtl::deref(x_p9)));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EField>(_m)) {
        auto&& r_pa = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a0;
        return refs_in(prism_rtl::deref(prism_rtl::deref(r_pa)));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m)) {
        auto&& r_pb = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
        auto&& i_pc = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a1;
        return append(refs_in(prism_rtl::deref(prism_rtl::deref(r_pb))), refs_in(prism_rtl::deref(prism_rtl::deref(i_pc))));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x_pd = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return refs_in(prism_rtl::deref(prism_rtl::deref(x_pd)));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ETuple>(_m)) {
        auto&& es_pe = prism_rtl::as<crate::syntax::ExprKind::ETuple>(_m).a0;
        return run_to_end(fold_job(es_pe, Array<std::tuple<Text, crate::syntax::Range>>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Text, crate::syntax::Range>>>(std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::syntax::Expr>)>>(prism_rtl::rc([=](std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::syntax::Expr> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc_pf = p0;
                    auto x_pg = p1;
                    (prism_rtl::finished(append(acc_pf, refs_in(x_pg))));
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EArray>(_m)) {
        auto&& es_ph = prism_rtl::as<crate::syntax::ExprKind::EArray>(_m).a0;
        return run_to_end(fold_job(es_ph, Array<std::tuple<Text, crate::syntax::Range>>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Text, crate::syntax::Range>>>(std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::syntax::Expr>)>>(prism_rtl::rc([=](std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::syntax::Expr> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc_pi = p0;
                    auto x_pj = p1;
                    (prism_rtl::finished(append(acc_pi, refs_in(x_pj))));
                });
            }));
        }))));
    }
    {
        return Array<std::tuple<Text, crate::syntax::Range>>{};
    }
}


/// BorrowStmts: unbounded fn Env, St, [Stmt], [ [Text] ] -> St
crate::check::types::St borrow_stmts(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const Array<crate::syntax::Stmt>& stmts_p2, const Array<Array<Text>>& lent_p3) {
    return run_to_end(fold_job(stmts_p2, st_p1, ({
        auto env_p0_1 = env_p0;
        auto lent_p3_2 = lent_p3;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::Stmt>)>>(prism_rtl::rc([=, env_p0_1 = std::move(env_p0_1), lent_p3_2 = std::move(lent_p3_2)](std::tuple<crate::check::types::St, crate::syntax::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_p0_1_3 = env_p0_1;
            auto lent_p3_2_3 = lent_p3_2;
            entered(once_job([=, env_p0_1_3 = std::move(env_p0_1_3), lent_p3_2_3 = std::move(lent_p3_2_3)]() {
            return ({
                auto s_p4 = p0;
                auto stmt_p5 = p1;
                ({
                auto&& _m = prism_rtl::deref(stmt_p5).kind;
                prism_rtl::is<crate::syntax::StmtKind::SSet>(_m) ? ({
                auto&& t_p6 = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a0;
                prism_rtl::more(prism_rtl::rc(CheckLent(env_p0_1_3, s_p4, t_p6, lent_p3_2_3)));
            })
                : prism_rtl::is<crate::syntax::StmtKind::SAccum>(_m) ? ({
                auto&& t_p7 = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a0;
                prism_rtl::more(prism_rtl::rc(CheckLent(env_p0_1_3, s_p4, t_p7, lent_p3_2_3)));
            })
                : prism_rtl::is<crate::syntax::StmtKind::SWhile>(_m) ? ({
                auto&& body_p8 = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a1;
                prism_rtl::more(prism_rtl::rc(BorrowStmts(env_p0_1_3, s_p4, prism_rtl::deref(body_p8).stmts, lent_p3_2_3)));
            })
                : prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m) ? ({
                auto&& e_p9 = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
                ({
                auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p9).kind);
                prism_rtl::is<crate::syntax::ExprKind::EFor>(_m) ? ({
                auto&& binders_oa = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a0;
                auto&& source_pb = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a1;
                auto&& body_pc = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a2;
                ({
                auto binders_oa_3 = binders_oa;
                auto body_pc_4 = body_pc;
                auto source_pb_5 = prism_rtl::deref(prism_rtl::deref(source_pb));
                call_then(start_ref_path(source_pb_5), [=, binders_oa_3 = std::move(binders_oa_3), body_pc_4 = std::move(body_pc_4)](Array<Text> ref_path_7339) {
                return ({
                    auto path_pd = ref_path_7339;
                    auto lent2_pe = (len(path_pd) > Nat(0u)) && (binders_oa_3 != std::optional<crate::syntax::ForBinders>{})
                        ? crate::prelude::push(lent_p3_2_3, path_pd)
                        : lent_p3_2_3;
                    (prism_rtl::more(prism_rtl::rc(BorrowStmts(env_p0_1_3, s_p4, prism_rtl::deref(body_pc_4).stmts, lent2_pe))));
                });
            });
            });
            })
                : prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) ? ({
                auto&& tb_pf = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
                auto&& eb_og = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
                ({
                auto eb_og_3 = eb_og;
                auto tb_pf_4 = tb_pf;
                call_then(start_borrow_stmts(env_p0_1_3, s_p4, prism_rtl::deref(tb_pf_4).stmts, lent_p3_2_3), [=, eb_og_3 = std::move(eb_og_3)](crate::check::types::St borrow_stmts_7544) {
                return ({
                    auto s2_ph = borrow_stmts_7544;
                    ({
                    prism_rtl::is_some(eb_og_3) ? ({
                    auto&& x_pi = prism_rtl::some_of(eb_og_3);
                    prism_rtl::more(prism_rtl::rc(BorrowStmts(env_p0_1_3, s2_ph, prism_rtl::deref(x_pi).stmts, lent_p3_2_3)));
                })
                    : prism_rtl::is_none(eb_og_3) ? prism_rtl::finished(s2_ph)
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            });
            });
            })
                : prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m) ? ({
                auto&& arms_pj = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
                fold_job(arms_pj, s_p4, ({
                auto env_p0_1_3_3 = env_p0_1_3;
                auto lent_p3_2_3_3 = lent_p3_2_3;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::Arm>)>>(prism_rtl::rc([=, env_p0_1_3_3 = std::move(env_p0_1_3_3), lent_p3_2_3_3 = std::move(lent_p3_2_3_3)](std::tuple<crate::check::types::St, crate::syntax::Arm> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto env_p0_1_3_3_3 = env_p0_1_3_3;
                    auto lent_p3_2_3_3_3 = lent_p3_2_3_3;
                    entered(once_job([=, env_p0_1_3_3_3 = std::move(env_p0_1_3_3_3), lent_p3_2_3_3_3 = std::move(lent_p3_2_3_3_3)]() {
                    return ({
                        auto s3_pk = p0;
                        auto a_pl = p1;
                        (prism_rtl::more(prism_rtl::rc(BorrowStmts(env_p0_1_3_3_3, s3_pk, prism_rtl::deref(prism_rtl::deref(a_pl).body).stmts, lent_p3_2_3_3_3))));
                    });
                }));
                });
            })));
            }))->cycle();
            })
                : prism_rtl::finished(s_p4);
            });
            })
                : prism_rtl::finished(s_p4);
            });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<crate::check::types::St> BorrowStmts::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& stmts_p2 = this->stmts_p2;
    const auto& lent_p3 = this->lent_p3;
    return fold_job(stmts_p2, st_p1, ({
        auto env_p0_1 = env_p0;
        auto lent_p3_2 = lent_p3;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::Stmt>)>>(prism_rtl::rc([=, env_p0_1 = std::move(env_p0_1), lent_p3_2 = std::move(lent_p3_2)](std::tuple<crate::check::types::St, crate::syntax::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_p0_1_3 = env_p0_1;
            auto lent_p3_2_3 = lent_p3_2;
            entered(once_job([=, env_p0_1_3 = std::move(env_p0_1_3), lent_p3_2_3 = std::move(lent_p3_2_3)]() {
            return ({
                auto s_p4 = p0;
                auto stmt_p5 = p1;
                ({
                auto&& _m = prism_rtl::deref(stmt_p5).kind;
                prism_rtl::is<crate::syntax::StmtKind::SSet>(_m) ? ({
                auto&& t_p6 = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a0;
                prism_rtl::more(prism_rtl::rc(CheckLent(env_p0_1_3, s_p4, t_p6, lent_p3_2_3)));
            })
                : prism_rtl::is<crate::syntax::StmtKind::SAccum>(_m) ? ({
                auto&& t_p7 = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a0;
                prism_rtl::more(prism_rtl::rc(CheckLent(env_p0_1_3, s_p4, t_p7, lent_p3_2_3)));
            })
                : prism_rtl::is<crate::syntax::StmtKind::SWhile>(_m) ? ({
                auto&& body_p8 = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a1;
                prism_rtl::more(prism_rtl::rc(BorrowStmts(env_p0_1_3, s_p4, prism_rtl::deref(body_p8).stmts, lent_p3_2_3)));
            })
                : prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m) ? ({
                auto&& e_p9 = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
                ({
                auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p9).kind);
                prism_rtl::is<crate::syntax::ExprKind::EFor>(_m) ? ({
                auto&& binders_oa = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a0;
                auto&& source_pb = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a1;
                auto&& body_pc = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a2;
                ({
                auto binders_oa_3 = binders_oa;
                auto body_pc_4 = body_pc;
                auto source_pb_5 = prism_rtl::deref(prism_rtl::deref(source_pb));
                call_then(start_ref_path(source_pb_5), [=, binders_oa_3 = std::move(binders_oa_3), body_pc_4 = std::move(body_pc_4)](Array<Text> ref_path_7339) {
                return ({
                    auto path_pd = ref_path_7339;
                    auto lent2_pe = (len(path_pd) > Nat(0u)) && (binders_oa_3 != std::optional<crate::syntax::ForBinders>{})
                        ? crate::prelude::push(lent_p3_2_3, path_pd)
                        : lent_p3_2_3;
                    (prism_rtl::more(prism_rtl::rc(BorrowStmts(env_p0_1_3, s_p4, prism_rtl::deref(body_pc_4).stmts, lent2_pe))));
                });
            });
            });
            })
                : prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) ? ({
                auto&& tb_pf = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
                auto&& eb_og = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
                ({
                auto eb_og_3 = eb_og;
                auto tb_pf_4 = tb_pf;
                call_then(start_borrow_stmts(env_p0_1_3, s_p4, prism_rtl::deref(tb_pf_4).stmts, lent_p3_2_3), [=, eb_og_3 = std::move(eb_og_3)](crate::check::types::St borrow_stmts_7544) {
                return ({
                    auto s2_ph = borrow_stmts_7544;
                    ({
                    prism_rtl::is_some(eb_og_3) ? ({
                    auto&& x_pi = prism_rtl::some_of(eb_og_3);
                    prism_rtl::more(prism_rtl::rc(BorrowStmts(env_p0_1_3, s2_ph, prism_rtl::deref(x_pi).stmts, lent_p3_2_3)));
                })
                    : prism_rtl::is_none(eb_og_3) ? prism_rtl::finished(s2_ph)
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            });
            });
            })
                : prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m) ? ({
                auto&& arms_pj = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
                fold_job(arms_pj, s_p4, ({
                auto env_p0_1_3_3 = env_p0_1_3;
                auto lent_p3_2_3_3 = lent_p3_2_3;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::Arm>)>>(prism_rtl::rc([=, env_p0_1_3_3 = std::move(env_p0_1_3_3), lent_p3_2_3_3 = std::move(lent_p3_2_3_3)](std::tuple<crate::check::types::St, crate::syntax::Arm> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto env_p0_1_3_3_3 = env_p0_1_3_3;
                    auto lent_p3_2_3_3_3 = lent_p3_2_3_3;
                    entered(once_job([=, env_p0_1_3_3_3 = std::move(env_p0_1_3_3_3), lent_p3_2_3_3_3 = std::move(lent_p3_2_3_3_3)]() {
                    return ({
                        auto s3_pk = p0;
                        auto a_pl = p1;
                        (prism_rtl::more(prism_rtl::rc(BorrowStmts(env_p0_1_3_3_3, s3_pk, prism_rtl::deref(prism_rtl::deref(a_pl).body).stmts, lent_p3_2_3_3_3))));
                    });
                }));
                });
            })));
            }))->cycle();
            })
                : prism_rtl::finished(s_p4);
            });
            })
                : prism_rtl::finished(s_p4);
            });
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start BorrowStmts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_borrow_stmts(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Array<crate::syntax::Stmt> stmts_p2, Array<Array<Text>> lent_p3) {
    return prism_rtl::make_rc<BorrowStmts>(env_p0, st_p1, stmts_p2, lent_p3);
}


/// CheckLent: unbounded fn Env, St, Expr, [ [Text] ] -> St
crate::check::types::St check_lent(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Expr& t_p2, const Array<Array<Text>>& lent_p3) {
    auto path_p4 = ref_path(t_p2);
    return fold(lent_p3, st_p1, [&](const crate::check::types::St& s_p5, const Array<Text>& l_p6) {
        return ((len(path_p4) > Nat(0u)) && is_prefix(l_p6, path_p4)) || is_prefix(path_p4, l_p6)
            ? crate::check::types::recording::err_fix(s_p5, Text::lit("borrow-overlap"), t_p2.span, prism_rtl::cat("`", crate::syntax::lexer::chars::join(l_p6, Text::lit(".")), "` is lent to the `for`"), Text::lit("set it after the loop, or loop over a copy"))
            : s_p5;
    });
}


prism_rtl::Turn<crate::check::types::St> CheckLent::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& t_p2 = this->t_p2;
    const auto& lent_p3 = this->lent_p3;
    auto lent_p3_1 = lent_p3;
    auto st_p1_2 = st_p1;
    auto t_p2_3 = t_p2;
    return call_then(start_ref_path(t_p2_3), [=](Array<Text> ref_path_7915) {
        return ({
            auto path_p4 = ref_path_7915;
            (prism_rtl::finished(fold(lent_p3_1, st_p1_2, [&](const crate::check::types::St& s_p5, const Array<Text>& l_p6) {
            return ((len(path_p4) > Nat(0u)) && is_prefix(l_p6, path_p4)) || is_prefix(path_p4, l_p6)
                ? crate::check::types::recording::err_fix(s_p5, Text::lit("borrow-overlap"), prism_rtl::deref(t_p2_3).span, prism_rtl::cat("`", crate::syntax::lexer::chars::join(l_p6, Text::lit(".")), "` is lent to the `for`"), Text::lit("set it after the loop, or loop over a copy"))
                : s_p5;
        })));
        });
    });
}


/// `Start CheckLent, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_check_lent(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Expr t_p2, Array<Array<Text>> lent_p3) {
    return prism_rtl::make_rc<CheckLent>(env_p0, st_p1, t_p2, lent_p3);
}


/// IsPrefix: fn [Text], [Text] -> Bool
bool is_prefix(const Array<Text>& a_p0, const Array<Text>& b_p1) {
    return (len(a_p0) <= len(b_p1)) && (take(b_p1, len(a_p0)) == a_p0);
}


/// RefPath: unbounded fn Expr -> [Text]
Array<Text> ref_path(const crate::syntax::Expr& e_p0) {
    auto&& _m = prism_rtl::deref(e_p0.kind);
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n_p1 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        return crate::syntax::lexer::chars::has_prefix(prism_rtl::deref(n_p1).sigils, Text::lit("&"))
            ? Array(std::vector{crate::check::env::sname_key(n_p1)})
            : Array<Text>{};
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EField>(_m)) {
        auto&& r_p2 = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a0;
        auto&& f_p3 = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a2;
        auto p_p4 = ref_path(prism_rtl::deref(prism_rtl::deref(r_p2)));
        return len(p_p4) > Nat(0u)
            ? crate::prelude::push(p_p4, prism_rtl::deref(f_p3).name)
            : p_p4;
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m)) {
        auto&& r_p5 = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
        auto p_p6 = ref_path(prism_rtl::deref(prism_rtl::deref(r_p5)));
        return len(p_p6) > Nat(0u) ? crate::prelude::push(p_p6, Text::lit("[]")) : p_p6;
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x_p7 = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return ref_path(prism_rtl::deref(prism_rtl::deref(x_p7)));
    }
    {
        return Array<Text>{};
    }
}


prism_rtl::Turn<Array<Text>> RefPath::cycle() const {
    const auto& e_p0 = this->e_p0;
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p0).kind);
        prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? ({
        auto&& n_p1 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        crate::syntax::lexer::chars::has_prefix(prism_rtl::deref(n_p1).sigils, Text::lit("&"))
        ? prism_rtl::finished(Array(std::vector{crate::check::env::sname_key(n_p1)}))
        : prism_rtl::finished(Array<Text>{});
    })
        : prism_rtl::is<crate::syntax::ExprKind::EField>(_m) ? ({
        auto&& r_p2 = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a0;
        auto&& f_p3 = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a2;
        ({
        auto f_p3_1 = f_p3;
        auto r_p2_2 = prism_rtl::deref(prism_rtl::deref(r_p2));
        call_then(start_ref_path(r_p2_2), [=, f_p3_1 = std::move(f_p3_1)](Array<Text> ref_path_8505) {
        return ({
            auto p_p4 = ref_path_8505;
            len(p_p4) > Nat(0u)
            ? prism_rtl::finished(crate::prelude::push(p_p4, prism_rtl::deref(f_p3_1).name))
            : prism_rtl::finished(p_p4);
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m) ? ({
        auto&& r_p5 = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
        ({
        auto r_p5_1 = prism_rtl::deref(prism_rtl::deref(r_p5));
        call_then(start_ref_path(r_p5_1), [=](Array<Text> ref_path_8600) {
        return ({
            auto p_p6 = ref_path_8600;
            len(p_p6) > Nat(0u)
            ? prism_rtl::finished(crate::prelude::push(p_p6, Text::lit("[]")))
            : prism_rtl::finished(p_p6);
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
        auto&& x_p7 = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(RefPath(prism_rtl::deref(prism_rtl::deref(x_p7)))));
    })
        : prism_rtl::finished(Array<Text>{});
    });
}


/// `Start RefPath, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_ref_path(crate::syntax::Expr e_p0) {
    return prism_rtl::make_rc<RefPath>(e_p0);
}

}  // namespace crate::check::passes::borrows
