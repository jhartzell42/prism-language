// The module `CheckEnv`, from `target/bootstrap/cpp-src/prismc/check-env.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (docs/backend.md). Edit the Prism source, not this file.
#include "check_env.hpp"
#include "check_types.hpp"
#include "ast.hpp"
#include "check_errors.hpp"
#include "lexer.hpp"
#include "typed.hpp"
#include "check_env.generic.hpp"
#include "lexer.generic.hpp"

namespace crate::check_env {

void CtorInfo::show(Printer& p) const {
    p.record("CtorInfo", {{"name", name}, {"owner", owner}, {"params", params}, {"args", args}, {"fields", fields}, {"ty", ty}, {"index", index}});
}

Pod CtorInfo::to_pod() const {
    return Pod::record("CtorInfo", {{"name", prism_rtl::to_pod(name)}, {"owner", prism_rtl::to_pod(owner)}, {"params", prism_rtl::to_pod(params)}, {"args", prism_rtl::to_pod(args)}, {"fields", prism_rtl::to_pod(fields)}, {"ty", prism_rtl::to_pod(ty)}, {"index", prism_rtl::to_pod(index)}});
}

Result<CtorInfo> CtorInfo::from_pod(const Pod& whole) {
    return CtorInfo{.name = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "name")))), .owner = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "owner")))), .params = TRY(prism_rtl::from_pod<Array<Text>>(TRY(prelude::field(whole, "params")))), .args = TRY(prism_rtl::from_pod<Array<check_types::Ty>>(TRY(prelude::field(whole, "args")))), .fields = TRY(prism_rtl::from_pod<Array<Text>>(TRY(prelude::field(whole, "fields")))), .ty = TRY(prism_rtl::from_pod<check_types::Ty>(TRY(prelude::field(whole, "ty")))), .index = TRY(prism_rtl::from_pod<Nat>(TRY(prelude::field(whole, "index"))))};
}


void Cx_::show(Printer& p) const {
    p.record("Cx", {{"g", g}, {"home", home}, {"scope", scope}, {"row_vars", row_vars}, {"unwritten", unwritten}});
}

Pod Cx_::to_pod() const {
    return Pod::record("Cx", {{"g", prism_rtl::to_pod(g)}, {"home", prism_rtl::to_pod(home)}, {"scope", prism_rtl::to_pod(scope)}, {"row_vars", prism_rtl::to_pod(row_vars)}, {"unwritten", prism_rtl::to_pod(unwritten)}});
}

Result<Cx_> Cx_::from_pod(const Pod& whole) {
    return Cx_{.g = TRY(prism_rtl::from_pod<G>(TRY(prelude::field(whole, "g")))), .home = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "home")))), .scope = TRY(prism_rtl::from_pod<check_types::Rw>(TRY(prelude::field(whole, "scope")))), .row_vars = TRY(prism_rtl::from_pod<Array<Text>>(TRY(prelude::field(whole, "row_vars")))), .unwritten = TRY(prism_rtl::from_pod<check_types::Col>(TRY(prelude::field(whole, "unwritten"))))};
}


void Def::show(Printer& p) const {
    p.record("Def", {{"qk", qk}, {"name", name}, {"home", home}, {"file", file}, {"span", span}, {"body", body}});
}

Pod Def::to_pod() const {
    return Pod::record("Def", {{"qk", prism_rtl::to_pod(qk)}, {"name", prism_rtl::to_pod(name)}, {"home", prism_rtl::to_pod(home)}, {"file", prism_rtl::to_pod(file)}, {"span", prism_rtl::to_pod(span)}, {"body", prism_rtl::to_pod(body)}});
}

Result<Def> Def::from_pod(const Pod& whole) {
    return Def{.qk = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "qk")))), .name = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "name")))), .home = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "home")))), .file = TRY(prism_rtl::from_pod<Nat>(TRY(prelude::field(whole, "file")))), .span = TRY(prism_rtl::from_pod<ast::Range>(TRY(prelude::field(whole, "span")))), .body = TRY(prism_rtl::from_pod<DefBody>(TRY(prelude::field(whole, "body"))))};
}


void DefBody::show(Printer& p) const {
    if (auto c = std::get_if<DbFn>(&cases())) p.choice("DbFn", {c->a0});
    else if (auto c = std::get_if<DbLet>(&cases())) p.choice("DbLet", {c->a0});
    else if (auto c = std::get_if<DbWidget>(&cases())) p.choice("DbWidget", {c->a0});
    else if (auto c = std::get_if<DbMethod>(&cases())) p.choice("DbMethod", {c->a0, c->a1, c->a2});
    else if (auto c = std::get_if<DbDefault>(&cases())) p.choice("DbDefault", {c->a0, c->a1});
    else if (auto c = std::get_if<DbCheck>(&cases())) p.choice("DbCheck", {c->a0});
    else if (auto c = std::get_if<DbTest>(&cases())) p.choice("DbTest", {c->a0});
}

Pod DefBody::to_pod() const {
    return std::holds_alternative<DbFn>(cases()) ? Pod::choice("DbFn", {prism_rtl::to_pod(std::get<DbFn>(cases()).a0)})
        : std::holds_alternative<DbLet>(cases()) ? Pod::choice("DbLet", {prism_rtl::to_pod(std::get<DbLet>(cases()).a0)})
        : std::holds_alternative<DbWidget>(cases()) ? Pod::choice("DbWidget", {prism_rtl::to_pod(std::get<DbWidget>(cases()).a0)})
        : std::holds_alternative<DbMethod>(cases()) ? Pod::choice("DbMethod", {prism_rtl::to_pod(std::get<DbMethod>(cases()).a0), prism_rtl::to_pod(std::get<DbMethod>(cases()).a1), prism_rtl::to_pod(std::get<DbMethod>(cases()).a2)})
        : std::holds_alternative<DbDefault>(cases()) ? Pod::choice("DbDefault", {prism_rtl::to_pod(std::get<DbDefault>(cases()).a0), prism_rtl::to_pod(std::get<DbDefault>(cases()).a1)})
        : std::holds_alternative<DbCheck>(cases()) ? Pod::choice("DbCheck", {prism_rtl::to_pod(std::get<DbCheck>(cases()).a0)})
        : std::holds_alternative<DbTest>(cases()) ? Pod::choice("DbTest", {prism_rtl::to_pod(std::get<DbTest>(cases()).a0)})
        : Pod();
}

Result<DefBody> DefBody::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "DbFn" && c->args.size() == 1) return DefBody(DbFn{TRY(prism_rtl::from_pod<Array<ast::FnClause>>(c->args[0]))});
        if (c->ctor == "DbLet" && c->args.size() == 1) return DefBody(DbLet{TRY(prism_rtl::from_pod<ast::LetDecl>(c->args[0]))});
        if (c->ctor == "DbWidget" && c->args.size() == 1) return DefBody(DbWidget{TRY(prism_rtl::from_pod<ast::WidgetDecl>(c->args[0]))});
        if (c->ctor == "DbMethod" && c->args.size() == 3) return DefBody(DbMethod{TRY(prism_rtl::from_pod<Array<ast::FnClause>>(c->args[0])), TRY(prism_rtl::from_pod<Text>(c->args[1])), TRY(prism_rtl::from_pod<ImplInfo>(c->args[2]))});
        if (c->ctor == "DbDefault" && c->args.size() == 2) return DefBody(DbDefault{TRY(prism_rtl::from_pod<Array<ast::FnClause>>(c->args[0])), TRY(prism_rtl::from_pod<Text>(c->args[1]))});
        if (c->ctor == "DbCheck" && c->args.size() == 1) return DefBody(DbCheck{TRY(prism_rtl::from_pod<ast::CheckDecl>(c->args[0]))});
        if (c->ctor == "DbTest" && c->args.size() == 1) return DefBody(DbTest{TRY(prism_rtl::from_pod<ast::TestDecl>(c->args[0]))});
    }
    return mismatch<DefBody>("a DefBody", p);
}


void G::show(Printer& p) const {
    p.record("G", {{"mods", mods}, {"types", types}, {"ctors", ctors}, {"tags", tags}, {"families", families}, {"fam_owner", fam_owner}, {"vals", vals}, {"traits", traits}, {"impls", impls}, {"bare", bare}, {"bare_types", bare_types}, {"bare_traits", bare_traits}, {"srcs", srcs}, {"defs", defs}, {"program_row", program_row}, {"elem_fams", elem_fams}, {"root_module", root_module}, {"fn_at", fn_at}, {"prelude_from", prelude_from}});
}

Pod G::to_pod() const {
    return Pod::record("G", {{"mods", prism_rtl::to_pod(mods)}, {"types", prism_rtl::to_pod(types)}, {"ctors", prism_rtl::to_pod(ctors)}, {"tags", prism_rtl::to_pod(tags)}, {"families", prism_rtl::to_pod(families)}, {"fam_owner", prism_rtl::to_pod(fam_owner)}, {"vals", prism_rtl::to_pod(vals)}, {"traits", prism_rtl::to_pod(traits)}, {"impls", prism_rtl::to_pod(impls)}, {"bare", prism_rtl::to_pod(bare)}, {"bare_types", prism_rtl::to_pod(bare_types)}, {"bare_traits", prism_rtl::to_pod(bare_traits)}, {"srcs", prism_rtl::to_pod(srcs)}, {"defs", prism_rtl::to_pod(defs)}, {"program_row", prism_rtl::to_pod(program_row)}, {"elem_fams", prism_rtl::to_pod(elem_fams)}, {"root_module", prism_rtl::to_pod(root_module)}, {"fn_at", prism_rtl::to_pod(fn_at)}, {"prelude_from", prism_rtl::to_pod(prelude_from)}});
}

Result<G> G::from_pod(const Pod& whole) {
    return G{.mods = TRY(prism_rtl::from_pod<Map<Text, ModInfo>>(TRY(prelude::field(whole, "mods")))), .types = TRY(prism_rtl::from_pod<Map<Text, TyInfo>>(TRY(prelude::field(whole, "types")))), .ctors = TRY(prism_rtl::from_pod<Map<Text, CtorInfo>>(TRY(prelude::field(whole, "ctors")))), .tags = TRY(prism_rtl::from_pod<Map<Text, TagInfo>>(TRY(prelude::field(whole, "tags")))), .families = TRY(prism_rtl::from_pod<Map<Text, Array<Text>>>(TRY(prelude::field(whole, "families")))), .fam_owner = TRY(prism_rtl::from_pod<Map<Text, Text>>(TRY(prelude::field(whole, "fam_owner")))), .vals = TRY(prism_rtl::from_pod<Map<Text, ValInfo>>(TRY(prelude::field(whole, "vals")))), .traits = TRY(prism_rtl::from_pod<Map<Text, TraitInfo>>(TRY(prelude::field(whole, "traits")))), .impls = TRY(prism_rtl::from_pod<Map<Text, Array<ImplInfo>>>(TRY(prelude::field(whole, "impls")))), .bare = TRY(prism_rtl::from_pod<Map<Text, Map<Text, Array<Text>>>>(TRY(prelude::field(whole, "bare")))), .bare_types = TRY(prism_rtl::from_pod<Map<Text, Map<Text, Array<Text>>>>(TRY(prelude::field(whole, "bare_types")))), .bare_traits = TRY(prism_rtl::from_pod<Map<Text, Map<Text, Array<Text>>>>(TRY(prelude::field(whole, "bare_traits")))), .srcs = TRY(prism_rtl::from_pod<Array<check_errors::Src>>(TRY(prelude::field(whole, "srcs")))), .defs = TRY(prism_rtl::from_pod<Array<Def>>(TRY(prelude::field(whole, "defs")))), .program_row = TRY(prism_rtl::from_pod<check_types::Rw>(TRY(prelude::field(whole, "program_row")))), .elem_fams = TRY(prism_rtl::from_pod<Array<Text>>(TRY(prelude::field(whole, "elem_fams")))), .root_module = TRY(prism_rtl::from_pod<std::optional<Text>>(TRY(prelude::field(whole, "root_module")))), .fn_at = TRY(prism_rtl::from_pod<Map<Text, Nat>>(TRY(prelude::field(whole, "fn_at")))), .prelude_from = TRY(prism_rtl::from_pod<Nat>(TRY(prelude::field(whole, "prelude_from"))))};
}


void ImplInfo::show(Printer& p) const {
    p.record("ImplInfo", {{"cls", cls}, {"head", head}, {"qs", qs}, {"bounds", bounds}, {"home", home}, {"file", file}, {"span", span}, {"derived", derived}, {"assocs", assocs}, {"methods", methods}});
}

Pod ImplInfo::to_pod() const {
    return Pod::record("ImplInfo", {{"cls", prism_rtl::to_pod(cls)}, {"head", prism_rtl::to_pod(head)}, {"qs", prism_rtl::to_pod(qs)}, {"bounds", prism_rtl::to_pod(bounds)}, {"home", prism_rtl::to_pod(home)}, {"file", prism_rtl::to_pod(file)}, {"span", prism_rtl::to_pod(span)}, {"derived", prism_rtl::to_pod(derived)}, {"assocs", prism_rtl::to_pod(assocs)}, {"methods", prism_rtl::to_pod(methods)}});
}

Result<ImplInfo> ImplInfo::from_pod(const Pod& whole) {
    return ImplInfo{.cls = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "cls")))), .head = TRY(prism_rtl::from_pod<check_types::Ty>(TRY(prelude::field(whole, "head")))), .qs = TRY(prism_rtl::from_pod<Array<Text>>(TRY(prelude::field(whole, "qs")))), .bounds = TRY(prism_rtl::from_pod<Array<std::tuple<Text, Text>>>(TRY(prelude::field(whole, "bounds")))), .home = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "home")))), .file = TRY(prism_rtl::from_pod<Nat>(TRY(prelude::field(whole, "file")))), .span = TRY(prism_rtl::from_pod<ast::Range>(TRY(prelude::field(whole, "span")))), .derived = TRY(prism_rtl::from_pod<bool>(TRY(prelude::field(whole, "derived")))), .assocs = TRY(prism_rtl::from_pod<Array<std::tuple<Text, check_types::Ty>>>(TRY(prelude::field(whole, "assocs")))), .methods = TRY(prism_rtl::from_pod<Array<Text>>(TRY(prelude::field(whole, "methods"))))};
}


void ModInfo::show(Printer& p) const {
    p.record("ModInfo", {{"name", name}, {"file", file}, {"emit_rw", emit_rw}, {"row_var", row_var}, {"uses", uses}, {"root", root}, {"tree", tree}});
}

Pod ModInfo::to_pod() const {
    return Pod::record("ModInfo", {{"name", prism_rtl::to_pod(name)}, {"file", prism_rtl::to_pod(file)}, {"emit_rw", prism_rtl::to_pod(emit_rw)}, {"row_var", prism_rtl::to_pod(row_var)}, {"uses", prism_rtl::to_pod(uses)}, {"root", prism_rtl::to_pod(root)}, {"tree", prism_rtl::to_pod(tree)}});
}

Result<ModInfo> ModInfo::from_pod(const Pod& whole) {
    return ModInfo{.name = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "name")))), .file = TRY(prism_rtl::from_pod<Nat>(TRY(prelude::field(whole, "file")))), .emit_rw = TRY(prism_rtl::from_pod<check_types::Rw>(TRY(prelude::field(whole, "emit_rw")))), .row_var = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "row_var")))), .uses = TRY(prism_rtl::from_pod<Array<std::tuple<Text, bool>>>(TRY(prelude::field(whole, "uses")))), .root = TRY(prism_rtl::from_pod<bool>(TRY(prelude::field(whole, "root")))), .tree = TRY(prism_rtl::from_pod<ast::Module>(TRY(prelude::field(whole, "tree"))))};
}


void TagInfo::show(Printer& p) const {
    p.record("TagInfo", {{"name", name}, {"family", family}, {"kind", kind}, {"out", out}, {"qs", qs}, {"rqs", rqs}, {"bounds", bounds}, {"fields", fields}, {"home", home}, {"file", file}, {"span", span}});
}

Pod TagInfo::to_pod() const {
    return Pod::record("TagInfo", {{"name", prism_rtl::to_pod(name)}, {"family", prism_rtl::to_pod(family)}, {"kind", prism_rtl::to_pod(kind)}, {"out", prism_rtl::to_pod(out)}, {"qs", prism_rtl::to_pod(qs)}, {"rqs", prism_rtl::to_pod(rqs)}, {"bounds", prism_rtl::to_pod(bounds)}, {"fields", prism_rtl::to_pod(fields)}, {"home", prism_rtl::to_pod(home)}, {"file", prism_rtl::to_pod(file)}, {"span", prism_rtl::to_pod(span)}});
}

Result<TagInfo> TagInfo::from_pod(const Pod& whole) {
    return TagInfo{.name = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "name")))), .family = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "family")))), .kind = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "kind")))), .out = TRY(prism_rtl::from_pod<check_types::Ty>(TRY(prelude::field(whole, "out")))), .qs = TRY(prism_rtl::from_pod<Array<Text>>(TRY(prelude::field(whole, "qs")))), .rqs = TRY(prism_rtl::from_pod<Array<Text>>(TRY(prelude::field(whole, "rqs")))), .bounds = TRY(prism_rtl::from_pod<Array<std::tuple<Text, Text>>>(TRY(prelude::field(whole, "bounds")))), .fields = TRY(prism_rtl::from_pod<Array<std::tuple<Text, check_types::Ty>>>(TRY(prelude::field(whole, "fields")))), .home = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "home")))), .file = TRY(prism_rtl::from_pod<Nat>(TRY(prelude::field(whole, "file")))), .span = TRY(prism_rtl::from_pod<ast::Range>(TRY(prelude::field(whole, "span"))))};
}


void TraitInfo::show(Printer& p) const {
    p.record("TraitInfo", {{"name", name}, {"home", home}, {"param", param}, {"supers", supers}, {"methods", methods}, {"defaults", defaults}, {"assocs", assocs}, {"file", file}, {"span", span}});
}

Pod TraitInfo::to_pod() const {
    return Pod::record("TraitInfo", {{"name", prism_rtl::to_pod(name)}, {"home", prism_rtl::to_pod(home)}, {"param", prism_rtl::to_pod(param)}, {"supers", prism_rtl::to_pod(supers)}, {"methods", prism_rtl::to_pod(methods)}, {"defaults", prism_rtl::to_pod(defaults)}, {"assocs", prism_rtl::to_pod(assocs)}, {"file", prism_rtl::to_pod(file)}, {"span", prism_rtl::to_pod(span)}});
}

Result<TraitInfo> TraitInfo::from_pod(const Pod& whole) {
    return TraitInfo{.name = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "name")))), .home = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "home")))), .param = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "param")))), .supers = TRY(prism_rtl::from_pod<Array<Text>>(TRY(prelude::field(whole, "supers")))), .methods = TRY(prism_rtl::from_pod<Array<Text>>(TRY(prelude::field(whole, "methods")))), .defaults = TRY(prism_rtl::from_pod<Array<Text>>(TRY(prelude::field(whole, "defaults")))), .assocs = TRY(prism_rtl::from_pod<Array<Text>>(TRY(prelude::field(whole, "assocs")))), .file = TRY(prism_rtl::from_pod<Nat>(TRY(prelude::field(whole, "file")))), .span = TRY(prism_rtl::from_pod<ast::Range>(TRY(prelude::field(whole, "span"))))};
}


void TyBody::show(Printer& p) const {
    if (auto c = std::get_if<BRecord>(&cases())) p.choice("BRecord", {c->a0});
    else if (auto c = std::get_if<BChoice>(&cases())) p.choice("BChoice", {c->a0});
    else if (auto c = std::get_if<BRowKind>(&cases())) p.choice("BRowKind", {});
    else if (auto c = std::get_if<BAlias>(&cases())) p.choice("BAlias", {c->a0});
    else if (auto c = std::get_if<BOpaque>(&cases())) p.choice("BOpaque", {});
    else if (auto c = std::get_if<BPrim>(&cases())) p.choice("BPrim", {});
}

Pod TyBody::to_pod() const {
    return std::holds_alternative<BRecord>(cases()) ? Pod::choice("BRecord", {prism_rtl::to_pod(std::get<BRecord>(cases()).a0)})
        : std::holds_alternative<BChoice>(cases()) ? Pod::choice("BChoice", {prism_rtl::to_pod(std::get<BChoice>(cases()).a0)})
        : std::holds_alternative<BRowKind>(cases()) ? Pod::choice("BRowKind", {})
        : std::holds_alternative<BAlias>(cases()) ? Pod::choice("BAlias", {prism_rtl::to_pod(std::get<BAlias>(cases()).a0)})
        : std::holds_alternative<BOpaque>(cases()) ? Pod::choice("BOpaque", {})
        : std::holds_alternative<BPrim>(cases()) ? Pod::choice("BPrim", {})
        : Pod();
}

Result<TyBody> TyBody::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "BRecord" && c->args.size() == 1) return TyBody(BRecord{TRY(prism_rtl::from_pod<Array<std::tuple<Text, check_types::Ty>>>(c->args[0]))});
        if (c->ctor == "BChoice" && c->args.size() == 1) return TyBody(BChoice{TRY(prism_rtl::from_pod<Array<std::tuple<Text, Array<check_types::Ty>>>>(c->args[0]))});
        if (c->ctor == "BRowKind" && c->args.size() == 0) return TyBody(BRowKind{});
        if (c->ctor == "BAlias" && c->args.size() == 1) return TyBody(BAlias{TRY(prism_rtl::from_pod<check_types::Ty>(c->args[0]))});
        if (c->ctor == "BOpaque" && c->args.size() == 0) return TyBody(BOpaque{});
        if (c->ctor == "BPrim" && c->args.size() == 0) return TyBody(BPrim{});
    }
    return mismatch<TyBody>("a TyBody", p);
}


void TyInfo::show(Printer& p) const {
    p.record("TyInfo", {{"name", name}, {"home", home}, {"params", params}, {"body", body}, {"derives", derives}, {"file", file}, {"span", span}});
}

Pod TyInfo::to_pod() const {
    return Pod::record("TyInfo", {{"name", prism_rtl::to_pod(name)}, {"home", prism_rtl::to_pod(home)}, {"params", prism_rtl::to_pod(params)}, {"body", prism_rtl::to_pod(body)}, {"derives", prism_rtl::to_pod(derives)}, {"file", prism_rtl::to_pod(file)}, {"span", prism_rtl::to_pod(span)}});
}

Result<TyInfo> TyInfo::from_pod(const Pod& whole) {
    return TyInfo{.name = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "name")))), .home = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "home")))), .params = TRY(prism_rtl::from_pod<Array<Text>>(TRY(prelude::field(whole, "params")))), .body = TRY(prism_rtl::from_pod<TyBody>(TRY(prelude::field(whole, "body")))), .derives = TRY(prism_rtl::from_pod<Array<Text>>(TRY(prelude::field(whole, "derives")))), .file = TRY(prism_rtl::from_pod<Nat>(TRY(prelude::field(whole, "file")))), .span = TRY(prism_rtl::from_pod<ast::Range>(TRY(prelude::field(whole, "span"))))};
}


void ValInfo::show(Printer& p) const {
    p.record("ValInfo", {{"qk", qk}, {"scheme", scheme}, {"sort", sort}, {"has_sig", has_sig}, {"home", home}, {"file", file}, {"span", span}});
}

Pod ValInfo::to_pod() const {
    return Pod::record("ValInfo", {{"qk", prism_rtl::to_pod(qk)}, {"scheme", prism_rtl::to_pod(scheme)}, {"sort", prism_rtl::to_pod(sort)}, {"has_sig", prism_rtl::to_pod(has_sig)}, {"home", prism_rtl::to_pod(home)}, {"file", prism_rtl::to_pod(file)}, {"span", prism_rtl::to_pod(span)}});
}

Result<ValInfo> ValInfo::from_pod(const Pod& whole) {
    return ValInfo{.qk = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "qk")))), .scheme = TRY(prism_rtl::from_pod<check_types::Scheme>(TRY(prelude::field(whole, "scheme")))), .sort = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "sort")))), .has_sig = TRY(prism_rtl::from_pod<bool>(TRY(prelude::field(whole, "has_sig")))), .home = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "home")))), .file = TRY(prism_rtl::from_pod<Nat>(TRY(prelude::field(whole, "file")))), .span = TRY(prism_rtl::from_pod<ast::Range>(TRY(prelude::field(whole, "span"))))};
}


/// IsPrimType: fn Text -> Bool
bool is_prim_type(const Text& n) {
    return check_types::has_text(Array(std::vector{Text::lit("Bool"), Text::lit("unit"), Text::lit("Char"), Text::lit("Text"), Text::lit("Nat"), Text::lit("Int"), Text::lit("U8"), Text::lit("Float"), Text::lit("Path"), Text::lit("Duration"), Text::lit("Cursor")}), n);
}


/// QualKey: fn Text, Text -> Text
Text qual_key(const Text& m, const Text& name) {
    return m == Text::lit("") ? name : prism_rtl::cat(m, ".", name);
}


/// Dotted: fn [Text] -> Text
Text dotted(const Array<Text>& parts) {
    return lexer::join(parts, Text::lit("."));
}


/// SNameKey: fn SName -> Text
Text sname_key(const ast::SName& n) {
    return prism_rtl::cat(n.sigils, dotted(n->path_));
}


/// DefNameText: fn DefName -> Text
Text def_name_text(const ast::DefName& def_name0) {
    if (prism_rtl::is<ast::DefName::DefSName>(def_name0)) {
        auto&& n = prism_rtl::as<ast::DefName::DefSName>(def_name0).a0;
        return sname_key(n);
    }
    if (prism_rtl::is<ast::DefName::DefOp>(def_name0)) {
        auto&& o = prism_rtl::as<ast::DefName::DefOp>(def_name0).a0;
        return o;
    }
    prism_rtl::unreachable("no arm matched");
}


/// DefNameSpan: fn DefName -> Range
ast::Range def_name_span(const ast::DefName& def_name0) {
    if (prism_rtl::is<ast::DefName::DefSName>(def_name0)) {
        auto&& n = prism_rtl::as<ast::DefName::DefSName>(def_name0).a0;
        return n.span;
    }
    if (prism_rtl::is<ast::DefName::DefOp>(def_name0)) {
        auto&& r = prism_rtl::as<ast::DefName::DefOp>(def_name0).a1;
        return r;
    }
    prism_rtl::unreachable("no arm matched");
}


/// IsLowerText: fn Text -> Bool
bool is_lower_text(const Text& t) {
    return lexer::is_lower(lexer::head(t));
}


/// IsUpperText: fn Text -> Bool
bool is_upper_text(const Text& t) {
    return lexer::is_upper(lexer::head(t));
}


/// BuildG: unbounded fn [Src], [Module] -> ((G, St))
std::tuple<G, check_types::St> build_g(const Array<check_errors::Src>& srcs, const Array<ast::Module>& trees) {
    auto g0 = G{.mods = Map<Text, ModInfo>{}, .types = Map<Text, TyInfo>{}, .ctors = Map<Text, CtorInfo>{}, .tags = Map<Text, TagInfo>{}, .families = Map<Text, Array<Text>>{}, .fam_owner = Map<Text, Text>{}, .vals = Map<Text, ValInfo>{}, .traits = Map<Text, TraitInfo>{}, .impls = Map<Text, Array<ImplInfo>>{}, .bare = Map<Text, Map<Text, Array<Text>>>{}, .bare_types = Map<Text, Map<Text, Array<Text>>>{}, .bare_traits = Map<Text, Map<Text, Array<Text>>>{}, .srcs = srcs, .defs = Array<Def>{}, .program_row = check_types::empty_row(), .elem_fams = Array<Text>{}, .root_module = std::optional<Text>{}, .fn_at = Map<Text, Nat>{}, .prelude_from = len(trees)};
    auto st0 = check_types::new_st(Nat(0u));
    auto [g1, st1] = fold(check_errors::range0(len(trees)), std::tuple{g0, st0}, [&](const std::tuple<G, check_types::St>& _p0, const Nat& i) {
        auto&& g = std::get<0>(_p0);
        auto&& st = std::get<1>(_p0);
        return add_module(g, st, i, or_(index(trees, i), empty_module()));
    });
    auto g2 = add_builtins(g1);
    auto [g3, st3] = run_to_end(fold_job(keys(g2.mods), std::tuple{g2, st1}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<G, check_types::St>>(std::tuple<std::tuple<G, check_types::St>, Text>)>>(prism_rtl::rc([=](std::tuple<std::tuple<G, check_types::St>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto [g, st] = p0;
                auto m = p1;
                (prism_rtl::more(prism_rtl::rc(CollectNames(g, st, m))));
            });
        }));
    }))));
    auto g4 = ({
        G this_ = g3;
        this_.program_row = program_row(this_);
        this_;
    });
    auto [g6, st6] = run_to_end(fold_job(keys(g4.mods), std::tuple{g4, st3}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<G, check_types::St>>(std::tuple<std::tuple<G, check_types::St>, Text>)>>(prism_rtl::rc([=](std::tuple<std::tuple<G, check_types::St>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto [g, st] = p0;
                auto m = p1;
                (prism_rtl::more(prism_rtl::rc(BuildTables(g, st, m))));
            });
        }));
    }))));
    auto [g6b, st6b] = run_to_end(fold_job(keys(g6.mods), std::tuple{g6, st6}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<G, check_types::St>>(std::tuple<std::tuple<G, check_types::St>, Text>)>>(prism_rtl::rc([=](std::tuple<std::tuple<G, check_types::St>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto [g, st] = p0;
                auto m = p1;
                (prism_rtl::more(prism_rtl::rc(ConvertTypes(g, st, m))));
            });
        }));
    }))));
    auto [g7, st7] = run_to_end(fold_job(keys(g6b.mods), std::tuple{g6b, st6b}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<G, check_types::St>>(std::tuple<std::tuple<G, check_types::St>, Text>)>>(prism_rtl::rc([=](std::tuple<std::tuple<G, check_types::St>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto [g, st] = p0;
                auto m = p1;
                (prism_rtl::more(prism_rtl::rc(ConvertDecls(g, st, m))));
            });
        }));
    }))));
    auto g8 = derived_impls(g7);
    auto st8 = coherence(g8, st7);
    return std::tuple{g8, st8};
}


prism_rtl::Turn<std::tuple<G, check_types::St>> BuildG::cycle() const {
    const auto& srcs = this->srcs;
    const auto& trees = this->trees;
    auto g0 = G{.mods = Map<Text, ModInfo>{}, .types = Map<Text, TyInfo>{}, .ctors = Map<Text, CtorInfo>{}, .tags = Map<Text, TagInfo>{}, .families = Map<Text, Array<Text>>{}, .fam_owner = Map<Text, Text>{}, .vals = Map<Text, ValInfo>{}, .traits = Map<Text, TraitInfo>{}, .impls = Map<Text, Array<ImplInfo>>{}, .bare = Map<Text, Map<Text, Array<Text>>>{}, .bare_types = Map<Text, Map<Text, Array<Text>>>{}, .bare_traits = Map<Text, Map<Text, Array<Text>>>{}, .srcs = srcs, .defs = Array<Def>{}, .program_row = check_types::empty_row(), .elem_fams = Array<Text>{}, .root_module = std::optional<Text>{}, .fn_at = Map<Text, Nat>{}, .prelude_from = len(trees)};
    auto st0 = check_types::new_st(Nat(0u));
    auto [g1, st1] = fold(check_errors::range0(len(trees)), std::tuple{g0, st0}, [&](const std::tuple<G, check_types::St>& _p0, const Nat& i) {
        auto&& g = std::get<0>(_p0);
        auto&& st = std::get<1>(_p0);
        return add_module(g, st, i, or_(index(trees, i), empty_module()));
    });
    auto g2 = add_builtins(g1);
    return call_value(fold_job(keys(g2.mods), std::tuple{g2, st1}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<G, check_types::St>>(std::tuple<std::tuple<G, check_types::St>, Text>)>>(prism_rtl::rc([=](std::tuple<std::tuple<G, check_types::St>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto [g, st] = p0;
                auto m = p1;
                (prism_rtl::more(prism_rtl::rc(CollectNames(g, st, m))));
            });
        }));
    }))), [=](std::tuple<G, check_types::St> fold_5244) {
        return ({
            auto [g3, st3] = fold_5244;
            auto g4 = ({
                G this_ = g3;
                this_.program_row = program_row(this_);
                this_;
            });
            call_value(fold_job(keys(g4.mods), std::tuple{g4, st3}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<G, check_types::St>>(std::tuple<std::tuple<G, check_types::St>, Text>)>>(prism_rtl::rc([=](std::tuple<std::tuple<G, check_types::St>, Text> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto [g, st] = p0;
                    auto m = p1;
                    (prism_rtl::more(prism_rtl::rc(BuildTables(g, st, m))));
                });
            }));
        }))), [=](std::tuple<G, check_types::St> fold_5401) {
            return ({
                auto [g6, st6] = fold_5401;
                call_value(fold_job(keys(g6.mods), std::tuple{g6, st6}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<G, check_types::St>>(std::tuple<std::tuple<G, check_types::St>, Text>)>>(prism_rtl::rc([=](std::tuple<std::tuple<G, check_types::St>, Text> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return entered(once_job([=]() {
                    return ({
                        auto [g, st] = p0;
                        auto m = p1;
                        (prism_rtl::more(prism_rtl::rc(ConvertTypes(g, st, m))));
                    });
                }));
            }))), [=](std::tuple<G, check_types::St> fold_5496) {
                return ({
                    auto [g6b, st6b] = fold_5496;
                    call_value(fold_job(keys(g6b.mods), std::tuple{g6b, st6b}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<G, check_types::St>>(std::tuple<std::tuple<G, check_types::St>, Text>)>>(prism_rtl::rc([=](std::tuple<std::tuple<G, check_types::St>, Text> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return entered(once_job([=]() {
                        return ({
                            auto [g, st] = p0;
                            auto m = p1;
                            (prism_rtl::more(prism_rtl::rc(ConvertDecls(g, st, m))));
                        });
                    }));
                }))), [=](std::tuple<G, check_types::St> fold_5590) {
                    return ({
                        auto [g7, st7] = fold_5590;
                        auto g8 = derived_impls(g7);
                        call_then(start_coherence(g8, st7), [=](check_types::St coherence_5708) {
                        return ({
                            auto st8 = coherence_5708;
                            (prism_rtl::finished(std::tuple{g8, st8}));
                        });
                    });
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start BuildG, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<G, check_types::St>> start_build_g(Array<check_errors::Src> srcs, Array<ast::Module> trees) {
    return prism_rtl::make_rc<BuildG>(srcs, trees);
}


/// let emptyModule
ast::Module empty_module() {
    return ast::Module{.name = std::optional<ast::QualName>{}, .emit_row = std::optional<ast::Row_>{}, .uses = Array<ast::Use>{}, .decls = Array<ast::Decl>{}, .template_ = std::optional<ast::Template>{}, .span = ast::Range{.start = Nat(0u), .end = Nat(0u)}};
}


/// ModName: fn Module -> Text
Text mod_name(const ast::Module& m) {
    auto&& _m = m.name;
    if (prism_rtl::is_some(_m)) {
        auto&& q = prism_rtl::some_of(_m);
        return dotted(q->path_);
    }
    if (prism_rtl::is_none(_m)) {
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}


/// AddModule: fn G, St, Nat, Module -> ((G, St))
std::tuple<G, check_types::St> add_module(const G& g, const check_types::St& st, const Nat& i, const ast::Module& tree) {
    auto name = mod_name(tree);
    auto s = ({
        check_types::St this_ = st;
        this_.file = i;
        this_;
    });
    return has_key(g.mods, name)
        ? ({
        auto what = name == Text::lit("")
            ? Text::lit("two files have no `module` line")
            : prism_rtl::cat("two files declare `module ", name, "`");
        std::tuple{g, check_types::err(s, Text::lit("collision"), tree.span, what)};
    })
        : ({
        auto info = ModInfo{.name = name, .file = i, .emit_rw = check_types::empty_row(), .row_var = Text::lit(""), .uses = each(tree.uses, [&](const ast::Use& u) { return std::tuple{dotted(u->target->path_), u.star}; }), .root = name == Text::lit(""), .tree = tree};
        auto g2 = ({
            G this_ = g;
            this_.mods = insert(this_.mods, name, info);
            if (name == Text::lit("")) {
                this_.root_module = std::optional(Text::lit(""));
            }
            this_;
        });
        std::tuple{g2, s};
    });
}


/// AddBuiltins: fn G -> G
G add_builtins(const G& g) {
    auto bool_ctor_fn = prism_rtl::rc([=](const Text& n, const Nat& i) { return CtorInfo{.name = n, .owner = Text::lit("Bool"), .params = Array<Text>{}, .args = Array<check_types::Ty>{}, .fields = Array<Text>{}, .ty = check_types::t_bool(), .index = i}; });
    auto pre = check_types::Scheme{.qs = Array(std::vector{Text::lit("a")}), .plain_qs = Array<Text>{}, .rqs = Array<Text>{}, .cqs = Array<Text>{}, .cjoins = Array<std::tuple<Text, Text>>{}, .bounds = Array<std::tuple<Text, Text>>{}, .ty = check_types::Ty(check_types::Ty::TySig{Text::lit("!"), prism_rtl::rc(check_types::Ty(check_types::Ty::TyQ{Text::lit("a")}))})};
    auto numbered_ = check_types::mono(check_types::Ty(check_types::Ty::TyFn{check_types::Col(check_types::Col::CBound{}), Array(std::vector{check_types::t_nat()}), prism_rtl::rc(check_types::Ty(check_types::Ty::TyCon{Text::lit("Buffer"), Array(std::vector{check_types::t_nat()})}))}));
    auto buf_empty = check_types::Scheme{.qs = Array(std::vector{Text::lit("a")}), .plain_qs = Array<Text>{}, .rqs = Array<Text>{}, .cqs = Array<Text>{}, .cjoins = Array<std::tuple<Text, Text>>{}, .bounds = Array<std::tuple<Text, Text>>{}, .ty = check_types::Ty(check_types::Ty::TyCon{Text::lit("Buffer"), Array(std::vector{check_types::Ty(check_types::Ty::TyQ{Text::lit("a")})})})};
    auto tab_empty = check_types::Scheme{.qs = Array(std::vector{Text::lit("k"), Text::lit("v")}), .plain_qs = Array<Text>{}, .rqs = Array<Text>{}, .cqs = Array<Text>{}, .cjoins = Array<std::tuple<Text, Text>>{}, .bounds = Array<std::tuple<Text, Text>>{}, .ty = check_types::Ty(check_types::Ty::TyCon{Text::lit("Table"), Array(std::vector{check_types::Ty(check_types::Ty::TyQ{Text::lit("k")}), check_types::Ty(check_types::Ty::TyQ{Text::lit("v")})})})};
    G this_ = g;
    this_.ctors = insert(insert(this_.ctors, Text::lit("True"), bool_ctor_fn(Text::lit("True"), Nat(0u))), Text::lit("False"), bool_ctor_fn(Text::lit("False"), Nat(1u)));
    this_.vals = insert(this_.vals, Text::lit("Prelude.never"), builtin(Text::lit("Prelude.never"), pre));
    this_.vals = insert(this_.vals, Text::lit("Buffer.Numbered"), builtin(Text::lit("Buffer.Numbered"), numbered_));
    this_.vals = insert(this_.vals, Text::lit("Buffer.Empty"), builtin(Text::lit("Buffer.Empty"), buf_empty));
    this_.vals = insert(this_.vals, Text::lit("Table.Empty"), builtin(Text::lit("Table.Empty"), tab_empty));
    return this_;
}


/// Builtin: fn Text, Scheme -> ValInfo
ValInfo builtin(const Text& qk, const check_types::Scheme& sc) {
    return ValInfo{.qk = qk, .scheme = sc, .sort = Text::lit("builtin"), .has_sig = true, .home = Text::lit("Prelude"), .file = Nat(0u), .span = ast::Range{.start = Nat(0u), .end = Nat(0u)}};
}


/// CollectNames: unbounded fn G, St, Text -> ((G, St))
std::tuple<G, check_types::St> collect_names(const G& g, const check_types::St& st, const Text& m) {
    auto&& _m = prelude::get(g.mods, m);
    if (prism_rtl::is_none(_m)) {
        return std::tuple{g, st};
    }
    if (prism_rtl::is_some(_m)) {
        auto&& info = prism_rtl::some_of(_m);
        auto s0 = ({
            check_types::St this_ = st;
            this_.file = info->file;
            this_;
        });
        auto&& _g2 = run_to_end(fold_job(info.tree.decls, std::tuple{g, s0, std::optional<Text>{}}, ({
            auto info_1 = info;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<G, check_types::St, std::optional<Text>>>(std::tuple<std::tuple<G, check_types::St, std::optional<Text>>, ast::Decl>)>>(prism_rtl::rc([=](std::tuple<std::tuple<G, check_types::St, std::optional<Text>>, ast::Decl> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto info_1_2 = info_1;
                entered(once_job([=]() {
                return ({
                    auto [gg, s, last_type_opt] = p0;
                    auto d = p1;
                    (prism_rtl::more(prism_rtl::rc(CollectDecl(gg, s, info_1_2, d, last_type_opt))));
                });
            }));
            });
        }));
        })));
        auto&& g2 = std::get<0>(_g2);
        auto&& s2 = std::get<1>(_g2);
        return std::tuple{g2, s2};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<G, check_types::St>> CollectNames::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    const auto& m = this->m;
    return ({
        auto&& _m = prelude::get(g.mods, m);
        prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{g, st})
        : prism_rtl::is_some(_m) ? ({
        auto&& info = prism_rtl::some_of(_m);
        ({
        auto s0 = ({
            check_types::St this_ = st;
            this_.file = info->file;
            this_;
        });
        auto g_1 = g;
        call_value(fold_job(info.tree.decls, std::tuple{g_1, s0, std::optional<Text>{}}, ({
        auto info_2 = info;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<G, check_types::St, std::optional<Text>>>(std::tuple<std::tuple<G, check_types::St, std::optional<Text>>, ast::Decl>)>>(prism_rtl::rc([=](std::tuple<std::tuple<G, check_types::St, std::optional<Text>>, ast::Decl> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto info_2_3 = info_2;
            entered(once_job([=]() {
            return ({
                auto [gg, s, last_type_opt] = p0;
                auto d = p1;
                (prism_rtl::more(prism_rtl::rc(CollectDecl(gg, s, info_2_3, d, last_type_opt))));
            });
        }));
        });
    }));
    })), [=](std::tuple<G, check_types::St, std::optional<Text>> fold_8590) {
        return ({
            auto&& _g2 = fold_8590;
            auto&& g2 = std::get<0>(_g2);
            auto&& s2 = std::get<1>(_g2);
            (prism_rtl::finished(std::tuple{g2, s2}));
        });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CollectNames, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<G, check_types::St>> start_collect_names(G g, check_types::St st, Text m) {
    return prism_rtl::make_rc<CollectNames>(g, st, m);
}


/// CollectDecl: unbounded fn G, St, ModInfo, Decl, ?Text -> ((G, St, ?Text))
std::tuple<G, check_types::St, std::optional<Text>> collect_decl(const G& g, const check_types::St& st, const ModInfo& info, const ast::Decl& d, const std::optional<Text>& last_type_opt) {
    auto&& _m = d.kind;
    if (prism_rtl::is<ast::DeclKind::DType>(_m)) {
        auto&& t = prism_rtl::as<ast::DeclKind::DType>(_m).a0;
        auto name = qual_key(info.name, dotted(t.name->path_));
        auto ti = TyInfo{.name = name, .home = info.name, .params = each(t.params, [&](const ast::Ident& p_) { return p_.name; }), .body = TyBody(TyBody::BOpaque{}), .derives = Array<Text>{}, .file = info->file, .span = d.span};
        return has_key(g.types, name)
            ? std::tuple{g, check_types::err(st, Text::lit("collision"), d.span, prism_rtl::cat("a second type `", dotted(t.name->path_), "`")), last_type_opt}
            : ({
            auto upd = ({
                G this_ = g;
                this_.types = insert(this_.types, name, ti);
                this_;
            });
            std::tuple{upd, st, std::optional(name)};
        });
    }
    if (prism_rtl::is<ast::DeclKind::DDerive>(_m)) {
        auto&& trs = prism_rtl::as<ast::DeclKind::DDerive>(_m).a0;
        if (prism_rtl::is_some(last_type_opt)) {
            auto&& tn = prism_rtl::some_of(last_type_opt);
            auto upd = ({
                G this_ = g;
                this_.types = insert(this_.types, tn, add_derives(or_(prelude::get(g.types, tn), dummy_ty_info()), each(trs, [&](const ast::TraitRef& tr) { return dotted(tr->path_); })));
                this_;
            });
            return std::tuple{upd, st, last_type_opt};
        }
        if (prism_rtl::is_none(last_type_opt)) {
            return std::tuple{g, check_types::err(st, Text::lit("mismatch"), d.span, Text::lit("a `derive` line follows a type declaration")), std::optional<Text>{}};
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<ast::DeclKind::DTag>(_m)) {
        auto&& t = prism_rtl::as<ast::DeclKind::DTag>(_m).a0;
        auto name = dotted(t.name->path_);
        auto family = dotted(take(t.name->path_, lexer::dec(len(t.name->path_))));
        auto tags = or_(prelude::get(g.families, family), Array<Text>{});
        auto owner = or_(prelude::get(g.fam_owner, family), info.name);
        auto st2 = owner != info.name
            ? check_types::err(st, Text::lit("collision"), d.span, prism_rtl::cat("the family `", family, "` is declared in `", owner, "`; every tag of a family is declared in its family's module"))
            : st;
        auto is_elem = ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            auto&& _m = t.of_type.kind;
            if (prism_rtl::is<ast::TypeKind::TName>(_m)) {
                auto&& n = prism_rtl::as<ast::TypeKind::TName>(_m).a0;
                _v.set(dotted(n->path_) == Text::lit("Element"));
                goto _done;
            }
            {
                _v.set(false);
                goto _done;
            }
        _done:
            _v.take();
        });
        auto g2 = ({
            G this_ = g;
            this_.families = insert(this_.families, family, prelude::push(tags, name));
            this_.fam_owner = insert(this_.fam_owner, family, owner);
            if (is_elem) {
                this_.elem_fams = check_types::add_text(this_.elem_fams, family);
            }
            this_;
        });
        return std::tuple{g2, st2, std::optional<Text>{}};
    }
    if (prism_rtl::is<ast::DeclKind::DTrait>(_m)) {
        auto&& t = prism_rtl::as<ast::DeclKind::DTrait>(_m).a0;
        auto name = qual_key(info.name, dotted(t.name->path_));
        auto ti = TraitInfo{.name = name, .home = info.name, .param = or_(index(each(t.params, [&](const ast::Ident& p_) { return p_.name; }), Nat(0u)), Text::lit("a")), .supers = Array<Text>{}, .methods = Array<Text>{}, .defaults = Array<Text>{}, .assocs = Array<Text>{}, .file = info->file, .span = d.span};
        auto upd = ({
            G this_ = g;
            this_.traits = insert(this_.traits, name, ti);
            this_;
        });
        return std::tuple{upd, st, std::optional<Text>{}};
    }
    {
        return std::tuple{g, st, std::optional<Text>{}};
    }
}


prism_rtl::Turn<std::tuple<G, check_types::St, std::optional<Text>>> CollectDecl::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    const auto& info = this->info;
    const auto& d = this->d;
    const auto& last_type_opt = this->last_type_opt;
    return ({
        auto&& _m = d.kind;
        prism_rtl::is<ast::DeclKind::DType>(_m) ? ({
        auto&& t = prism_rtl::as<ast::DeclKind::DType>(_m).a0;
        ({
        auto name = qual_key(info.name, dotted(t.name->path_));
        auto ti = TyInfo{.name = name, .home = info.name, .params = each(t.params, [&](const ast::Ident& p_) { return p_.name; }), .body = TyBody(TyBody::BOpaque{}), .derives = Array<Text>{}, .file = info->file, .span = d.span};
        has_key(g.types, name)
        ? prism_rtl::finished(std::tuple{g, check_types::err(st, Text::lit("collision"), d.span, prism_rtl::cat("a second type `", dotted(t.name->path_), "`")), last_type_opt})
        : ({
        auto upd = ({
            G this_ = g;
            this_.types = insert(this_.types, name, ti);
            this_;
        });
        (prism_rtl::finished(std::tuple{upd, st, std::optional(name)}));
    });
    });
    })
        : prism_rtl::is<ast::DeclKind::DDerive>(_m) ? ({
        auto&& trs = prism_rtl::as<ast::DeclKind::DDerive>(_m).a0;
        ({
        prism_rtl::is_some(last_type_opt) ? ({
        auto&& tn = prism_rtl::some_of(last_type_opt);
        ({
        auto upd = ({
            G this_ = g;
            this_.types = insert(this_.types, tn, add_derives(or_(prelude::get(g.types, tn), dummy_ty_info()), each(trs, [&](const ast::TraitRef& tr) { return dotted(tr->path_); })));
            this_;
        });
        (prism_rtl::finished(std::tuple{upd, st, last_type_opt}));
    });
    })
        : prism_rtl::is_none(last_type_opt) ? prism_rtl::finished(std::tuple{g, check_types::err(st, Text::lit("mismatch"), d.span, Text::lit("a `derive` line follows a type declaration")), std::optional<Text>{}})
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : prism_rtl::is<ast::DeclKind::DTag>(_m) ? ({
        auto&& t = prism_rtl::as<ast::DeclKind::DTag>(_m).a0;
        ({
        auto name = dotted(t.name->path_);
        auto family = dotted(take(t.name->path_, lexer::dec(len(t.name->path_))));
        auto tags = or_(prelude::get(g.families, family), Array<Text>{});
        auto owner = or_(prelude::get(g.fam_owner, family), info.name);
        auto st2 = owner != info.name
            ? check_types::err(st, Text::lit("collision"), d.span, prism_rtl::cat("the family `", family, "` is declared in `", owner, "`; every tag of a family is declared in its family's module"))
            : st;
        auto is_elem = ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            auto&& _m = t.of_type.kind;
            if (prism_rtl::is<ast::TypeKind::TName>(_m)) {
                auto&& n = prism_rtl::as<ast::TypeKind::TName>(_m).a0;
                _v.set(dotted(n->path_) == Text::lit("Element"));
                goto _done;
            }
            {
                _v.set(false);
                goto _done;
            }
        _done:
            _v.take();
        });
        auto g2 = ({
            G this_ = g;
            this_.families = insert(this_.families, family, prelude::push(tags, name));
            this_.fam_owner = insert(this_.fam_owner, family, owner);
            if (is_elem) {
                this_.elem_fams = check_types::add_text(this_.elem_fams, family);
            }
            this_;
        });
        (prism_rtl::finished(std::tuple{g2, st2, std::optional<Text>{}}));
    });
    })
        : prism_rtl::is<ast::DeclKind::DTrait>(_m) ? ({
        auto&& t = prism_rtl::as<ast::DeclKind::DTrait>(_m).a0;
        ({
        auto name = qual_key(info.name, dotted(t.name->path_));
        auto ti = TraitInfo{.name = name, .home = info.name, .param = or_(index(each(t.params, [&](const ast::Ident& p_) { return p_.name; }), Nat(0u)), Text::lit("a")), .supers = Array<Text>{}, .methods = Array<Text>{}, .defaults = Array<Text>{}, .assocs = Array<Text>{}, .file = info->file, .span = d.span};
        auto upd = ({
            G this_ = g;
            this_.traits = insert(this_.traits, name, ti);
            this_;
        });
        (prism_rtl::finished(std::tuple{upd, st, std::optional<Text>{}}));
    });
    })
        : prism_rtl::finished(std::tuple{g, st, std::optional<Text>{}});
    });
}


/// `Start CollectDecl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<G, check_types::St, std::optional<Text>>> start_collect_decl(G g, check_types::St st, ModInfo info, ast::Decl d, std::optional<Text> last_type_opt) {
    return prism_rtl::make_rc<CollectDecl>(g, st, info, d, last_type_opt);
}


/// let dummyTyInfo
TyInfo dummy_ty_info() {
    return TyInfo{.name = Text::lit(""), .home = Text::lit(""), .params = Array<Text>{}, .body = TyBody(TyBody::BOpaque{}), .derives = Array<Text>{}, .file = Nat(0u), .span = ast::Range{.start = Nat(0u), .end = Nat(0u)}};
}


/// AddDerives: fn TyInfo, [Text] -> TyInfo
TyInfo add_derives(const TyInfo& ti, const Array<Text>& trs) {
    TyInfo this_ = ti;
    this_.derives = append(this_.derives, trs);
    return this_;
}


/// ProgramRow: fn G -> Rw
check_types::Rw program_row(const G& g) {
    return check_types::closed(g.elem_fams);
}


/// BuildTables: unbounded fn G, St, Text -> ((G, St))
std::tuple<G, check_types::St> build_tables(const G& g, const check_types::St& st, const Text& m) {
    auto&& _m = prelude::get(g.mods, m);
    if (prism_rtl::is_none(_m)) {
        return std::tuple{g, st};
    }
    if (prism_rtl::is_some(_m)) {
        auto&& info = prism_rtl::some_of(_m);
        auto s0 = ({
            check_types::St this_ = st;
            this_.file = info->file;
            this_;
        });
        auto s1 = fold(info.uses, s0, [&](const check_types::St& s, const std::tuple<Text, bool>& _p1) {
            auto&& u = std::get<0>(_p1);
            return has_key(g.mods, u) || (u == Text::lit("Prelude"))
                ? s
                : check_types::err(s, Text::lit("unknown-name"), info.tree.span, prism_rtl::cat("no module `", u, "` among the program's files"));
        });
        auto starred = filter(each(info.uses, [&](const std::tuple<Text, bool>& _p0) {
            auto&& u = std::get<0>(_p0);
            auto&& star = std::get<1>(_p0);
            return star ? u : Text::lit("");
        }), [&](const Text& u) { return (u != Text::lit("")) && (u != m); });
        auto sources = check_types::add_text(append(Array(std::vector{m}), starred), Text::lit("Prelude"));
        auto vals = run_to_end(fold_job(sources, Map<Text, Array<Text>>{}, ({
            auto g_1 = g;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Array<Text>>>(std::tuple<Map<Text, Array<Text>>, Text>)>>(prism_rtl::rc([=](std::tuple<Map<Text, Array<Text>>, Text> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto g_1_2 = g_1;
                entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto src = p1;
                    (prism_rtl::more(prism_rtl::rc(BareValuesOf(g_1_2, src, acc))));
                });
            }));
            });
        }));
        })));
        auto tys = fold(sources, Map<Text, Array<Text>>{}, [&](const Map<Text, Array<Text>>& acc, const Text& src) { return bare_types_of(g, src, acc); });
        auto trs = fold(sources, Map<Text, Array<Text>>{}, [&](const Map<Text, Array<Text>>& acc, const Text& src) { return bare_traits_of(g, src, acc); });
        auto [rw, rv, s2] = module_row(g, s1, info);
        auto info2 = ({
            ModInfo this_ = info;
            this_.emit_rw = rw;
            this_.row_var = rv;
            this_;
        });
        auto upd = ({
            G this_ = g;
            this_.bare = insert(this_.bare, m, vals);
            this_.bare_types = insert(this_.bare_types, m, tys);
            this_.bare_traits = insert(this_.bare_traits, m, trs);
            this_.mods = insert(this_.mods, m, info2);
            this_;
        });
        return std::tuple{upd, s2};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<G, check_types::St>> BuildTables::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    const auto& m = this->m;
    return ({
        auto&& _m = prelude::get(g.mods, m);
        prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{g, st})
        : prism_rtl::is_some(_m) ? ({
        auto&& info = prism_rtl::some_of(_m);
        ({
        auto s0 = ({
            check_types::St this_ = st;
            this_.file = info->file;
            this_;
        });
        auto s1 = fold(info.uses, s0, [&](const check_types::St& s, const std::tuple<Text, bool>& _p1) {
            auto&& u = std::get<0>(_p1);
            return has_key(g.mods, u) || (u == Text::lit("Prelude"))
                ? s
                : check_types::err(s, Text::lit("unknown-name"), info.tree.span, prism_rtl::cat("no module `", u, "` among the program's files"));
        });
        auto starred = filter(each(info.uses, [&](const std::tuple<Text, bool>& _p0) {
            auto&& u = std::get<0>(_p0);
            auto&& star = std::get<1>(_p0);
            return star ? u : Text::lit("");
        }), [&](const Text& u) { return (u != Text::lit("")) && (u != m); });
        auto sources = check_types::add_text(append(Array(std::vector{m}), starred), Text::lit("Prelude"));
        auto g_1 = g;
        auto m_2 = m;
        call_value(fold_job(sources, Map<Text, Array<Text>>{}, ({
        auto g_1_3 = g_1;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Array<Text>>>(std::tuple<Map<Text, Array<Text>>, Text>)>>(prism_rtl::rc([=](std::tuple<Map<Text, Array<Text>>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_1_3_3 = g_1_3;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto src = p1;
                (prism_rtl::more(prism_rtl::rc(BareValuesOf(g_1_3_3, src, acc))));
            });
        }));
        });
    }));
    })), [=](Map<Text, Array<Text>> fold_12135) {
        return ({
            auto vals = fold_12135;
            auto tys = fold(sources, Map<Text, Array<Text>>{}, [&](const Map<Text, Array<Text>>& acc, const Text& src) { return bare_types_of(g_1, src, acc); });
            auto trs = fold(sources, Map<Text, Array<Text>>{}, [&](const Map<Text, Array<Text>>& acc, const Text& src) { return bare_traits_of(g_1, src, acc); });
            call_then(start_module_row(g_1, s1, info), [=](std::tuple<check_types::Rw, Text, check_types::St> module_row_12364) {
            return ({
                auto [rw, rv, s2] = module_row_12364;
                auto info2 = ({
                    ModInfo this_ = info;
                    this_.emit_rw = rw;
                    this_.row_var = rv;
                    this_;
                });
                auto upd = ({
                    G this_ = g_1;
                    this_.bare = insert(this_.bare, m_2, vals);
                    this_.bare_types = insert(this_.bare_types, m_2, tys);
                    this_.bare_traits = insert(this_.bare_traits, m_2, trs);
                    this_.mods = insert(this_.mods, m_2, info2);
                    this_;
                });
                (prism_rtl::finished(std::tuple{upd, s2}));
            });
        });
        });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start BuildTables, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<G, check_types::St>> start_build_tables(G g, check_types::St st, Text m) {
    return prism_rtl::make_rc<BuildTables>(g, st, m);
}


/// AddBare: fn (Text ==> [Text]), Text, Text -> (Text ==> [Text])
Map<Text, Array<Text>> add_bare(const Map<Text, Array<Text>>& acc, const Text& name, const Text& qk) {
    auto have = or_(prelude::get(acc, name), Array<Text>{});
    return check_types::has_text(have, qk)
        ? acc
        : insert(acc, name, prelude::push(have, qk));
}


/// BareValuesOf: unbounded fn G, Text, (Text ==> [Text]) -> (Text ==> [Text])
Map<Text, Array<Text>> bare_values_of(const G& g, const Text& src, const Map<Text, Array<Text>>& acc) {
    auto&& _m = prelude::get(g.mods, src);
    if (prism_rtl::is_none(_m)) {
        return acc;
    }
    if (prism_rtl::is_some(_m)) {
        auto&& info = prism_rtl::some_of(_m);
        return run_to_end(fold_job(info.tree.decls, acc, ({
            auto src_1 = src;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Array<Text>>>(std::tuple<Map<Text, Array<Text>>, ast::Decl>)>>(prism_rtl::rc([=](std::tuple<Map<Text, Array<Text>>, ast::Decl> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto src_1_2 = src_1;
                entered(once_job([=]() {
                return ({
                    auto a = p0;
                    auto d = p1;
                    (prism_rtl::more(prism_rtl::rc(BareOfDecl(src_1_2, a, d))));
                });
            }));
            });
        }));
        })));
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Map<Text, Array<Text>>> BareValuesOf::cycle() const {
    const auto& g = this->g;
    const auto& src = this->src;
    const auto& acc = this->acc;
    return ({
        auto&& _m = prelude::get(g.mods, src);
        prism_rtl::is_none(_m) ? prism_rtl::finished(acc)
        : prism_rtl::is_some(_m) ? ({
        auto&& info = prism_rtl::some_of(_m);
        fold_job(info.tree.decls, acc, ({
        auto src_1 = src;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Array<Text>>>(std::tuple<Map<Text, Array<Text>>, ast::Decl>)>>(prism_rtl::rc([=](std::tuple<Map<Text, Array<Text>>, ast::Decl> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto src_1_2 = src_1;
            entered(once_job([=]() {
            return ({
                auto a = p0;
                auto d = p1;
                (prism_rtl::more(prism_rtl::rc(BareOfDecl(src_1_2, a, d))));
            });
        }));
        });
    }));
    }))->cycle();
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start BareValuesOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, Array<Text>>> start_bare_values_of(G g, Text src, Map<Text, Array<Text>> acc) {
    return prism_rtl::make_rc<BareValuesOf>(g, src, acc);
}


/// BareOfDecl: unbounded fn Text, (Text ==> [Text]), Decl -> (Text ==> [Text])
Map<Text, Array<Text>> bare_of_decl(const Text& m, const Map<Text, Array<Text>>& acc, const ast::Decl& d) {
    auto&& _m = d.kind;
    if (prism_rtl::is<ast::DeclKind::DSignature>(_m)) {
        auto&& s = prism_rtl::as<ast::DeclKind::DSignature>(_m).a0;
        return add_bare(acc, def_name_text(s.name), qual_key(m, def_name_text(s.name)));
    }
    if (prism_rtl::is<ast::DeclKind::DFn>(_m)) {
        auto&& f = prism_rtl::as<ast::DeclKind::DFn>(_m).a0;
        return add_bare(acc, def_name_text(f.name), qual_key(m, def_name_text(f.name)));
    }
    if (prism_rtl::is<ast::DeclKind::DLet>(_m)) {
        auto&& l = prism_rtl::as<ast::DeclKind::DLet>(_m).a0;
        return fold(pattern_names(l.pattern), acc, [&](const Map<Text, Array<Text>>& a, const Text& n) { return add_bare(a, n, qual_key(m, n)); });
    }
    if (prism_rtl::is<ast::DeclKind::DWidget>(_m)) {
        auto&& w = prism_rtl::as<ast::DeclKind::DWidget>(_m).a0;
        return add_bare(acc, sname_key(w.name), qual_key(m, sname_key(w.name)));
    }
    if (prism_rtl::is<ast::DeclKind::DType>(_m)) {
        auto&& t = prism_rtl::as<ast::DeclKind::DType>(_m).a0;
        return fold(ctor_names_of(t), acc, [&](const Map<Text, Array<Text>>& a, const Text& c) { return add_bare(a, c, qual_key(m, c)); });
    }
    if (prism_rtl::is<ast::DeclKind::DTrait>(_m)) {
        auto&& t = prism_rtl::as<ast::DeclKind::DTrait>(_m).a0;
        return fold(t.items, acc, [&](const Map<Text, Array<Text>>& a, const ast::TraitItem& it) {
            return ({
                __label__ _done;
                prism_rtl::Slot<Map<Text, Array<Text>>> _v;
                if (prism_rtl::is<ast::TraitItem::TiSignature>(it)) {
                    auto&& s = prism_rtl::as<ast::TraitItem::TiSignature>(it).a0;
                    _v.set(add_bare(a, def_name_text(s.name), qual_key(m, def_name_text(s.name))));
                    goto _done;
                }
                {
                    _v.set(a);
                    goto _done;
                }
            _done:
                _v.take();
            });
        });
    }
    {
        return acc;
    }
}


prism_rtl::Turn<Map<Text, Array<Text>>> BareOfDecl::cycle() const {
    const auto& m = this->m;
    const auto& acc = this->acc;
    const auto& d = this->d;
    return ({
        auto&& _m = d.kind;
        prism_rtl::is<ast::DeclKind::DSignature>(_m) ? ({
        auto&& s = prism_rtl::as<ast::DeclKind::DSignature>(_m).a0;
        prism_rtl::finished(add_bare(acc, def_name_text(s.name), qual_key(m, def_name_text(s.name))));
    })
        : prism_rtl::is<ast::DeclKind::DFn>(_m) ? ({
        auto&& f = prism_rtl::as<ast::DeclKind::DFn>(_m).a0;
        prism_rtl::finished(add_bare(acc, def_name_text(f.name), qual_key(m, def_name_text(f.name))));
    })
        : prism_rtl::is<ast::DeclKind::DLet>(_m) ? ({
        auto&& l = prism_rtl::as<ast::DeclKind::DLet>(_m).a0;
        ({
        auto acc_1 = acc;
        auto l_2 = l;
        auto m_3 = m;
        call_then(start_pattern_names(l_2.pattern), [=](Array<Text> pattern_names_13509) { return prism_rtl::finished(fold(pattern_names_13509, acc_1, [&](const Map<Text, Array<Text>>& a, const Text& n) { return add_bare(a, n, qual_key(m_3, n)); })); });
    });
    })
        : prism_rtl::is<ast::DeclKind::DWidget>(_m) ? ({
        auto&& w = prism_rtl::as<ast::DeclKind::DWidget>(_m).a0;
        prism_rtl::finished(add_bare(acc, sname_key(w.name), qual_key(m, sname_key(w.name))));
    })
        : prism_rtl::is<ast::DeclKind::DType>(_m) ? ({
        auto&& t = prism_rtl::as<ast::DeclKind::DType>(_m).a0;
        prism_rtl::finished(fold(ctor_names_of(t), acc, [&](const Map<Text, Array<Text>>& a, const Text& c) { return add_bare(a, c, qual_key(m, c)); }));
    })
        : prism_rtl::is<ast::DeclKind::DTrait>(_m) ? ({
        auto&& t = prism_rtl::as<ast::DeclKind::DTrait>(_m).a0;
        prism_rtl::finished(fold(t.items, acc, [&](const Map<Text, Array<Text>>& a, const ast::TraitItem& it) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Map<Text, Array<Text>>> _v;
            if (prism_rtl::is<ast::TraitItem::TiSignature>(it)) {
                auto&& s = prism_rtl::as<ast::TraitItem::TiSignature>(it).a0;
                _v.set(add_bare(a, def_name_text(s.name), qual_key(m, def_name_text(s.name))));
                goto _done;
            }
            {
                _v.set(a);
                goto _done;
            }
        _done:
            _v.take();
        });
    }));
    })
        : prism_rtl::finished(acc);
    });
}


/// `Start BareOfDecl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, Array<Text>>> start_bare_of_decl(Text m, Map<Text, Array<Text>> acc, ast::Decl d) {
    return prism_rtl::make_rc<BareOfDecl>(m, acc, d);
}


/// CtorNamesOf: fn TypeDecl -> [Text]
Array<Text> ctor_names_of(const ast::TypeDecl& t) {
    auto&& _m = t.body;
    if (prism_rtl::is_some(_m) && prism_rtl::is<ast::TypeBody::TbRecord>(prism_rtl::some_of(_m))) {
        return Array(std::vector{dotted(t.name->path_)});
    }
    if (prism_rtl::is_some(_m) && prism_rtl::is<ast::TypeBody::TbChoice>(prism_rtl::some_of(_m))) {
        auto&& cs = prism_rtl::as<ast::TypeBody::TbChoice>(prism_rtl::some_of(_m)).a0;
        return each(cs, [&](const ast::Case_& c) { return sname_key(c.name); });
    }
    if (prism_rtl::is_some(_m) && prism_rtl::is<ast::TypeBody::TbNewtype>(prism_rtl::some_of(_m))) {
        auto&& c = prism_rtl::as<ast::TypeBody::TbNewtype>(prism_rtl::some_of(_m)).a0;
        return Array(std::vector{sname_key(c.name)});
    }
    if (prism_rtl::is_some(_m) && prism_rtl::is<ast::TypeBody::TbUnit>(prism_rtl::some_of(_m))) {
        auto&& i = prism_rtl::as<ast::TypeBody::TbUnit>(prism_rtl::some_of(_m)).a0;
        return Array(std::vector{i.name});
    }
    {
        return Array<Text>{};
    }
}


/// PatternNames: unbounded fn Pattern -> [Text]
Array<Text> pattern_names(const ast::Pattern_& p_) {
    auto&& _m = p_.kind;
    if (prism_rtl::is<ast::PatternKind::PName>(_m)) {
        auto&& n = prism_rtl::as<ast::PatternKind::PName>(_m).a0;
        return Array(std::vector{sname_key(n)});
    }
    if (prism_rtl::is<ast::PatternKind::PCtor>(_m)) {
        auto&& ps = prism_rtl::as<ast::PatternKind::PCtor>(_m).a1;
        return run_to_end(fold_job(ps, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, ast::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, ast::Pattern_> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto q = p1;
                    call_then(start_pattern_names(q), [=](Array<Text> pattern_names_14385) { return prism_rtl::finished(append(acc, pattern_names_14385)); });
                });
            }));
        }))));
    }
    if (prism_rtl::is<ast::PatternKind::PRecord>(_m)) {
        auto&& fs = prism_rtl::as<ast::PatternKind::PRecord>(_m).a1;
        return run_to_end(fold_job(fs, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, ast::FieldPat>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, ast::FieldPat> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto f = p1;
                    call_then(start_pattern_names(f.pattern), [=](Array<Text> pattern_names_14471) { return prism_rtl::finished(append(acc, pattern_names_14471)); });
                });
            }));
        }))));
    }
    if (prism_rtl::is<ast::PatternKind::PSigil>(_m)) {
        auto&& q = prism_rtl::as<ast::PatternKind::PSigil>(_m).a1;
        return pattern_names(q);
    }
    if (prism_rtl::is<ast::PatternKind::PTuple>(_m)) {
        auto&& ps = prism_rtl::as<ast::PatternKind::PTuple>(_m).a0;
        return run_to_end(fold_job(ps, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, ast::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, ast::Pattern_> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto q = p1;
                    call_then(start_pattern_names(q), [=](Array<Text> pattern_names_14585) { return prism_rtl::finished(append(acc, pattern_names_14585)); });
                });
            }));
        }))));
    }
    if (prism_rtl::is<ast::PatternKind::PArray>(_m)) {
        auto&& ps = prism_rtl::as<ast::PatternKind::PArray>(_m).a0;
        return run_to_end(fold_job(ps, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, ast::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, ast::Pattern_> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto q = p1;
                    call_then(start_pattern_names(q), [=](Array<Text> pattern_names_14654) { return prism_rtl::finished(append(acc, pattern_names_14654)); });
                });
            }));
        }))));
    }
    if (prism_rtl::is<ast::PatternKind::PGroup>(_m)) {
        auto&& q = prism_rtl::as<ast::PatternKind::PGroup>(_m).a0;
        return pattern_names(q);
    }
    {
        return Array<Text>{};
    }
}


prism_rtl::Turn<Array<Text>> PatternNames::cycle() const {
    const auto& p_ = this->p_;
    return ({
        auto&& _m = p_.kind;
        prism_rtl::is<ast::PatternKind::PName>(_m) ? ({
        auto&& n = prism_rtl::as<ast::PatternKind::PName>(_m).a0;
        prism_rtl::finished(Array(std::vector{sname_key(n)}));
    })
        : prism_rtl::is<ast::PatternKind::PCtor>(_m) ? ({
        auto&& ps = prism_rtl::as<ast::PatternKind::PCtor>(_m).a1;
        fold_job(ps, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, ast::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, ast::Pattern_> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto q = p1;
                call_then(start_pattern_names(q), [=](Array<Text> pattern_names_14385) { return prism_rtl::finished(append(acc, pattern_names_14385)); });
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<ast::PatternKind::PRecord>(_m) ? ({
        auto&& fs = prism_rtl::as<ast::PatternKind::PRecord>(_m).a1;
        fold_job(fs, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, ast::FieldPat>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, ast::FieldPat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto f = p1;
                call_then(start_pattern_names(f.pattern), [=](Array<Text> pattern_names_14471) { return prism_rtl::finished(append(acc, pattern_names_14471)); });
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<ast::PatternKind::PSigil>(_m) ? ({
        auto&& q = prism_rtl::as<ast::PatternKind::PSigil>(_m).a1;
        prism_rtl::more(prism_rtl::rc(PatternNames(q)));
    })
        : prism_rtl::is<ast::PatternKind::PTuple>(_m) ? ({
        auto&& ps = prism_rtl::as<ast::PatternKind::PTuple>(_m).a0;
        fold_job(ps, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, ast::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, ast::Pattern_> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto q = p1;
                call_then(start_pattern_names(q), [=](Array<Text> pattern_names_14585) { return prism_rtl::finished(append(acc, pattern_names_14585)); });
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<ast::PatternKind::PArray>(_m) ? ({
        auto&& ps = prism_rtl::as<ast::PatternKind::PArray>(_m).a0;
        fold_job(ps, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, ast::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, ast::Pattern_> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto q = p1;
                call_then(start_pattern_names(q), [=](Array<Text> pattern_names_14654) { return prism_rtl::finished(append(acc, pattern_names_14654)); });
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<ast::PatternKind::PGroup>(_m) ? ({
        auto&& q = prism_rtl::as<ast::PatternKind::PGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(PatternNames(q)));
    })
        : prism_rtl::finished(Array<Text>{});
    });
}


/// `Start PatternNames, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_pattern_names(ast::Pattern_ p_) {
    return prism_rtl::make_rc<PatternNames>(p_);
}


/// PatternBinders: unbounded fn Pattern -> [((Text, Range))]
Array<std::tuple<Text, ast::Range>> pattern_binders(const ast::Pattern_& p_) {
    auto&& _m = p_.kind;
    if (prism_rtl::is<ast::PatternKind::PName>(_m)) {
        auto&& n = prism_rtl::as<ast::PatternKind::PName>(_m).a0;
        return Array(std::vector{std::tuple{sname_key(n), n.span}});
    }
    if (prism_rtl::is<ast::PatternKind::PCtor>(_m)) {
        auto&& ps = prism_rtl::as<ast::PatternKind::PCtor>(_m).a1;
        return run_to_end(fold_job(ps, Array<std::tuple<Text, ast::Range>>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Text, ast::Range>>>(std::tuple<Array<std::tuple<Text, ast::Range>>, ast::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Array<std::tuple<Text, ast::Range>>, ast::Pattern_> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto q = p1;
                    call_then(start_pattern_binders(q), [=](Array<std::tuple<Text, ast::Range>> pattern_binders_14974) { return prism_rtl::finished(append(acc, pattern_binders_14974)); });
                });
            }));
        }))));
    }
    if (prism_rtl::is<ast::PatternKind::PRecord>(_m)) {
        auto&& fs = prism_rtl::as<ast::PatternKind::PRecord>(_m).a1;
        return run_to_end(fold_job(fs, Array<std::tuple<Text, ast::Range>>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Text, ast::Range>>>(std::tuple<Array<std::tuple<Text, ast::Range>>, ast::FieldPat>)>>(prism_rtl::rc([=](std::tuple<Array<std::tuple<Text, ast::Range>>, ast::FieldPat> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto f = p1;
                    call_then(start_pattern_binders(f.pattern), [=](Array<std::tuple<Text, ast::Range>> pattern_binders_15062) { return prism_rtl::finished(append(acc, pattern_binders_15062)); });
                });
            }));
        }))));
    }
    if (prism_rtl::is<ast::PatternKind::PSigil>(_m)) {
        auto&& q = prism_rtl::as<ast::PatternKind::PSigil>(_m).a1;
        return pattern_binders(q);
    }
    if (prism_rtl::is<ast::PatternKind::PTuple>(_m)) {
        auto&& ps = prism_rtl::as<ast::PatternKind::PTuple>(_m).a0;
        return run_to_end(fold_job(ps, Array<std::tuple<Text, ast::Range>>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Text, ast::Range>>>(std::tuple<Array<std::tuple<Text, ast::Range>>, ast::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Array<std::tuple<Text, ast::Range>>, ast::Pattern_> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto q = p1;
                    call_then(start_pattern_binders(q), [=](Array<std::tuple<Text, ast::Range>> pattern_binders_15180) { return prism_rtl::finished(append(acc, pattern_binders_15180)); });
                });
            }));
        }))));
    }
    if (prism_rtl::is<ast::PatternKind::PArray>(_m)) {
        auto&& ps = prism_rtl::as<ast::PatternKind::PArray>(_m).a0;
        return run_to_end(fold_job(ps, Array<std::tuple<Text, ast::Range>>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Text, ast::Range>>>(std::tuple<Array<std::tuple<Text, ast::Range>>, ast::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Array<std::tuple<Text, ast::Range>>, ast::Pattern_> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto q = p1;
                    call_then(start_pattern_binders(q), [=](Array<std::tuple<Text, ast::Range>> pattern_binders_15251) { return prism_rtl::finished(append(acc, pattern_binders_15251)); });
                });
            }));
        }))));
    }
    if (prism_rtl::is<ast::PatternKind::PGroup>(_m)) {
        auto&& q = prism_rtl::as<ast::PatternKind::PGroup>(_m).a0;
        return pattern_binders(q);
    }
    {
        return Array<std::tuple<Text, ast::Range>>{};
    }
}


prism_rtl::Turn<Array<std::tuple<Text, ast::Range>>> PatternBinders::cycle() const {
    const auto& p_ = this->p_;
    return ({
        auto&& _m = p_.kind;
        prism_rtl::is<ast::PatternKind::PName>(_m) ? ({
        auto&& n = prism_rtl::as<ast::PatternKind::PName>(_m).a0;
        prism_rtl::finished(Array(std::vector{std::tuple{sname_key(n), n.span}}));
    })
        : prism_rtl::is<ast::PatternKind::PCtor>(_m) ? ({
        auto&& ps = prism_rtl::as<ast::PatternKind::PCtor>(_m).a1;
        fold_job(ps, Array<std::tuple<Text, ast::Range>>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Text, ast::Range>>>(std::tuple<Array<std::tuple<Text, ast::Range>>, ast::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Array<std::tuple<Text, ast::Range>>, ast::Pattern_> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto q = p1;
                call_then(start_pattern_binders(q), [=](Array<std::tuple<Text, ast::Range>> pattern_binders_14974) { return prism_rtl::finished(append(acc, pattern_binders_14974)); });
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<ast::PatternKind::PRecord>(_m) ? ({
        auto&& fs = prism_rtl::as<ast::PatternKind::PRecord>(_m).a1;
        fold_job(fs, Array<std::tuple<Text, ast::Range>>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Text, ast::Range>>>(std::tuple<Array<std::tuple<Text, ast::Range>>, ast::FieldPat>)>>(prism_rtl::rc([=](std::tuple<Array<std::tuple<Text, ast::Range>>, ast::FieldPat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto f = p1;
                call_then(start_pattern_binders(f.pattern), [=](Array<std::tuple<Text, ast::Range>> pattern_binders_15062) { return prism_rtl::finished(append(acc, pattern_binders_15062)); });
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<ast::PatternKind::PSigil>(_m) ? ({
        auto&& q = prism_rtl::as<ast::PatternKind::PSigil>(_m).a1;
        prism_rtl::more(prism_rtl::rc(PatternBinders(q)));
    })
        : prism_rtl::is<ast::PatternKind::PTuple>(_m) ? ({
        auto&& ps = prism_rtl::as<ast::PatternKind::PTuple>(_m).a0;
        fold_job(ps, Array<std::tuple<Text, ast::Range>>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Text, ast::Range>>>(std::tuple<Array<std::tuple<Text, ast::Range>>, ast::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Array<std::tuple<Text, ast::Range>>, ast::Pattern_> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto q = p1;
                call_then(start_pattern_binders(q), [=](Array<std::tuple<Text, ast::Range>> pattern_binders_15180) { return prism_rtl::finished(append(acc, pattern_binders_15180)); });
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<ast::PatternKind::PArray>(_m) ? ({
        auto&& ps = prism_rtl::as<ast::PatternKind::PArray>(_m).a0;
        fold_job(ps, Array<std::tuple<Text, ast::Range>>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Text, ast::Range>>>(std::tuple<Array<std::tuple<Text, ast::Range>>, ast::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Array<std::tuple<Text, ast::Range>>, ast::Pattern_> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto q = p1;
                call_then(start_pattern_binders(q), [=](Array<std::tuple<Text, ast::Range>> pattern_binders_15251) { return prism_rtl::finished(append(acc, pattern_binders_15251)); });
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<ast::PatternKind::PGroup>(_m) ? ({
        auto&& q = prism_rtl::as<ast::PatternKind::PGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(PatternBinders(q)));
    })
        : prism_rtl::finished(Array<std::tuple<Text, ast::Range>>{});
    });
}


/// `Start PatternBinders, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<std::tuple<Text, ast::Range>>> start_pattern_binders(ast::Pattern_ p_) {
    return prism_rtl::make_rc<PatternBinders>(p_);
}


/// BareTypesOf: fn G, Text, (Text ==> [Text]) -> (Text ==> [Text])
Map<Text, Array<Text>> bare_types_of(const G& g, const Text& src, const Map<Text, Array<Text>>& acc) {
    return fold(keys(g.types), acc, [&](const Map<Text, Array<Text>>& a, const Text& k) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Map<Text, Array<Text>>> _v;
            auto&& _m = prelude::get(g.types, k);
            if (prism_rtl::is_some(_m)) {
                auto&& ti = prism_rtl::some_of(_m);
                _v.set(ti.home == src ? add_bare(a, check_types::bare_name(ti.name), k) : a);
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(a);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
}


/// BareTraitsOf: fn G, Text, (Text ==> [Text]) -> (Text ==> [Text])
Map<Text, Array<Text>> bare_traits_of(const G& g, const Text& src, const Map<Text, Array<Text>>& acc) {
    return fold(keys(g.traits), acc, [&](const Map<Text, Array<Text>>& a, const Text& k) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Map<Text, Array<Text>>> _v;
            auto&& _m = prelude::get(g.traits, k);
            if (prism_rtl::is_some(_m)) {
                auto&& ti = prism_rtl::some_of(_m);
                _v.set(ti.home == src ? add_bare(a, check_types::bare_name(ti.name), k) : a);
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(a);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
}


/// ModuleRow: unbounded fn G, St, ModInfo -> ((Rw, Text, St))
std::tuple<check_types::Rw, Text, check_types::St> module_row(const G& g, const check_types::St& st, const ModInfo& info) {
    auto&& _m = info.tree.emit_row;
    if (prism_rtl::is_none(_m)) {
        return info.root
            ? std::tuple{g.program_row, Text::lit(""), st}
            : std::tuple{check_types::empty_row(), Text::lit(""), check_types::err(st, Text::lit("emit-element"), info.tree.span, Text::lit("a library writes its own row; this one writes no `emit` line"))};
    }
    if (prism_rtl::is_some(_m)) {
        auto&& row_decl = prism_rtl::some_of(_m);
        auto [fams, vars, s2] = fold(row_decl.terms, std::tuple{Array<Text>{}, Array<Text>{}, st}, [&](const std::tuple<Array<Text>, Array<Text>, check_types::St>& _p0, const ast::RowTerm& term) {
            auto&& fs = std::get<0>(_p0);
            auto&& vs = std::get<1>(_p0);
            auto&& s = std::get<2>(_p0);
            return row_term_of(g, s, info, term, fs, vs);
        });
        auto s3 = len(vars) > Nat(1u)
            ? check_types::err_fix(s2, Text::lit("row-two-tails"), row_decl.span, prism_rtl::cat("a row has one variable; `", lexer::join(vars, Text::lit(" | ")), "` names two"), Text::lit("keep one variable"))
            : s2;
        auto tail = ({
            __label__ _done;
            prism_rtl::Slot<check_types::Tail> _v;
            auto&& _m = index(vars, Nat(0u));
            if (prism_rtl::is_some(_m)) {
                auto&& v_ = prism_rtl::some_of(_m);
                _v.set(check_types::Tail(check_types::Tail::TlQ{v_}));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(check_types::Tail(check_types::Tail::TlClosed{}));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        return std::tuple{check_types::Rw{.fams = check_types::sort_texts(fams), .minus = Array<Text>{}, .tail = tail}, or_(index(vars, Nat(0u)), Text::lit("")), s3};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<check_types::Rw, Text, check_types::St>> ModuleRow::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    const auto& info = this->info;
    return ({
        auto&& _m = info.tree.emit_row;
        prism_rtl::is_none(_m) ? info.root
        ? prism_rtl::finished(std::tuple{g.program_row, Text::lit(""), st})
        : prism_rtl::finished(std::tuple{check_types::empty_row(), Text::lit(""), check_types::err(st, Text::lit("emit-element"), info.tree.span, Text::lit("a library writes its own row; this one writes no `emit` line"))})
        : prism_rtl::is_some(_m) ? ({
        auto&& row_decl = prism_rtl::some_of(_m);
        ({
        auto [fams, vars, s2] = fold(row_decl.terms, std::tuple{Array<Text>{}, Array<Text>{}, st}, [&](const std::tuple<Array<Text>, Array<Text>, check_types::St>& _p0, const ast::RowTerm& term) {
            auto&& fs = std::get<0>(_p0);
            auto&& vs = std::get<1>(_p0);
            auto&& s = std::get<2>(_p0);
            return row_term_of(g, s, info, term, fs, vs);
        });
        auto s3 = len(vars) > Nat(1u)
            ? check_types::err_fix(s2, Text::lit("row-two-tails"), row_decl.span, prism_rtl::cat("a row has one variable; `", lexer::join(vars, Text::lit(" | ")), "` names two"), Text::lit("keep one variable"))
            : s2;
        auto tail = ({
            __label__ _done;
            prism_rtl::Slot<check_types::Tail> _v;
            auto&& _m = index(vars, Nat(0u));
            if (prism_rtl::is_some(_m)) {
                auto&& v_ = prism_rtl::some_of(_m);
                _v.set(check_types::Tail(check_types::Tail::TlQ{v_}));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(check_types::Tail(check_types::Tail::TlClosed{}));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        (prism_rtl::finished(std::tuple{check_types::Rw{.fams = check_types::sort_texts(fams), .minus = Array<Text>{}, .tail = tail}, or_(index(vars, Nat(0u)), Text::lit("")), s3}));
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ModuleRow, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<check_types::Rw, Text, check_types::St>> start_module_row(G g, check_types::St st, ModInfo info) {
    return prism_rtl::make_rc<ModuleRow>(g, st, info);
}


/// RowTermOf: fn G, St, ModInfo, RowTerm, [Text], [Text] -> (([Text], [Text], St))
std::tuple<Array<Text>, Array<Text>, check_types::St> row_term_of(const G& g, const check_types::St& s, const ModInfo& info, const ast::RowTerm& term, const Array<Text>& fs, const Array<Text>& vs) {
    if (prism_rtl::is<ast::RowTerm::RFamily>(term)) {
        auto&& q = prism_rtl::as<ast::RowTerm::RFamily>(term).a0;
        return std::tuple{prelude::push(fs, dotted(q->path_)), vs, check_family(g, s, dotted(q->path_), q.span)};
    }
    if (prism_rtl::is<ast::RowTerm::RVar>(term)) {
        auto&& v_ = prism_rtl::as<ast::RowTerm::RVar>(term).a0;
        return std::tuple{fs, prelude::push(vs, v_.name), s};
    }
    if (prism_rtl::is<ast::RowTerm::RType>(term)) {
        auto&& t = prism_rtl::as<ast::RowTerm::RType>(term).a0;
        auto&& _m = t.kind;
        if (prism_rtl::is<ast::TypeKind::TName>(_m)) {
            auto&& n = prism_rtl::as<ast::TypeKind::TName>(_m).a0;
            auto&& m17051_0_1 = prism_rtl::as<ast::TypeKind::TName>(_m).a1;
            if (m17051_0_1.size() == 0u) {
                auto name = dotted(n->path_);
                return (name == Text::lit("Element")) && info.root
                    ? std::tuple{append(fs, g.program_row.fams), vs, s}
                    : name == Text::lit("Element")
                    ? std::tuple{fs, vs, check_types::err(s, Text::lit("emit-element"), t.span, Text::lit("a library writes its own row; `emit Element` names the program's"))}
                    : has_key(g.tags, name) || (len(n->path_) > Nat(1u))
                    ? std::tuple{fs, vs, check_types::err_fix(s, Text::lit("row-single-tag"), t.span, prism_rtl::cat("a row names families, not tags: `", name, "`"), prism_rtl::cat("write `", dotted(take(n->path_, lexer::dec(len(n->path_)))), ".*`"))}
                    : std::tuple{fs, vs, check_types::err(s, Text::lit("kind"), t.span, prism_rtl::cat("`", name, "` is not a row"))};
            }
        }
        {
            return std::tuple{fs, vs, check_types::err(s, Text::lit("kind"), t.span, Text::lit("this is not a row"))};
        }
    }
    prism_rtl::unreachable("no arm matched");
}


/// CheckFamily: fn G, St, Text, Range -> St
check_types::St check_family(const G& g, const check_types::St& s, const Text& fam, const ast::Range& span) {
    return has_key(g.families, fam)
        ? s
        : check_types::err(s, Text::lit("unknown-name"), span, prism_rtl::cat("no family `", fam, "`: no module declares a `", fam, ".` tag"));
}


/// ResolveValue: fn G, Text, SName -> ((?Text, Text))
std::tuple<std::optional<Text>, Text> resolve_value(const G& g, const Text& m, const ast::SName& n) {
    auto marks = n.sigils;
    return len(n->path_) == Nat(1u)
        ? ({
        auto name = prism_rtl::cat(marks, or_(index(n->path_, Nat(0u)), Text::lit("")));
        auto table = or_(prelude::get(g.bare, m), Map<Text, Array<Text>>{});
        auto keys_ = or_(prelude::get(table, name), Array<Text>{});
        len(keys_) == Nat(1u)
        ? std::tuple{index(keys_, Nat(0u)), Text::lit("")}
        : len(keys_) > Nat(1u)
        ? std::tuple{std::optional(own_first(m, keys_)), Text::lit("collision")}
        : name == Text::lit("never")
        ? std::tuple{std::optional(Text::lit("Prelude.never")), Text::lit("")}
        : has_key(g.ctors, name)
        ? std::tuple{std::optional(name), Text::lit("")}
        : std::tuple{std::optional<Text>{}, Text::lit("unknown")};
    })
        : ({
        auto qual = dotted(take(n->path_, lexer::dec(len(n->path_))));
        auto last_1 = or_(lexer::last(n->path_), Text::lit(""));
        auto qk = prism_rtl::cat(qual, ".", marks, last_1);
        (len_text(marks) == Nat(0u)) && has_key(g.tags, dotted(n->path_))
        ? std::tuple{std::optional(dotted(n->path_)), Text::lit("tag")}
        : has_key(g.vals, qk) || has_key(g.ctors, qk)
        ? std::tuple{std::optional(qk), Text::lit("")}
        : std::tuple{std::optional<Text>{}, Text::lit("unknown")};
    });
}


/// ResolveType: fn G, Text, [Text] -> ((?Text, Text))
std::tuple<std::optional<Text>, Text> resolve_type(const G& g, const Text& m, const Array<Text>& path_) {
    return len(path_) == Nat(1u)
        ? ({
        auto keys_ = or_(prelude::get(or_(prelude::get(g.bare_types, m), Map<Text, Array<Text>>{}), or_(index(path_, Nat(0u)), Text::lit(""))), Array<Text>{});
        len(keys_) == Nat(1u)
        ? std::tuple{index(keys_, Nat(0u)), Text::lit("")}
        : len(keys_) > Nat(1u)
        ? std::tuple{std::optional(own_first(m, keys_)), Text::lit("collision")}
        : std::tuple{std::optional<Text>{}, Text::lit("unknown")};
    })
        : ({
        auto qk = dotted(path_);
        has_key(g.types, qk)
        ? std::tuple{std::optional(qk), Text::lit("")}
        : std::tuple{std::optional<Text>{}, Text::lit("unknown")};
    });
}


/// OwnFirst: fn Text, [Text] -> Text
Text own_first(const Text& m, const Array<Text>& keys_) {
    auto own = filter(keys_, [&](const Text& k) { return (qual_key(m, check_types::bare_name(k)) == k) || ((m == Text::lit("")) && (!lexer::contains(k, Text::lit(".")))); });
    return or_(index(own, Nat(0u)), or_(index(keys_, Nat(0u)), Text::lit("")));
}


/// ?ResolveTrait: fn G, Text, [Text] -> ?Text
std::optional<Text> resolve_trait(const G& g, const Text& m, const Array<Text>& path_) {
    return len(path_) == Nat(1u)
        ? ({
        auto keys_ = or_(prelude::get(or_(prelude::get(g.bare_traits, m), Map<Text, Array<Text>>{}), or_(index(path_, Nat(0u)), Text::lit(""))), Array<Text>{});
        index(keys_, Nat(0u));
    })
        : ({
        auto qk = dotted(path_);
        has_key(g.traits, qk) ? std::optional(qk) : std::optional<Text>{};
    });
}


/// CxOf: fn G, Text -> Cx
Cx_ cx_of(const G& g, const Text& m) {
    auto info = or_(prelude::get(g.mods, m), or_(prelude::get(g.mods, Text::lit("")), dummy_mod()));
    return Cx_{.g = g, .home = m, .scope = info.emit_rw, .row_vars = info.row_var == Text::lit("")
        ? Array<Text>{}
        : Array(std::vector{info.row_var}), .unwritten = check_types::Col(check_types::Col::CBound{})};
}


/// let dummyMod
ModInfo dummy_mod() {
    return ModInfo{.name = Text::lit(""), .file = Nat(0u), .emit_rw = check_types::empty_row(), .row_var = Text::lit(""), .uses = Array<std::tuple<Text, bool>>{}, .root = false, .tree = empty_module()};
}


/// ConvType: unbounded fn Cx, St, Type -> ((Ty, St))
std::tuple<check_types::Ty, check_types::St> conv_type(const Cx_& cx_, const check_types::St& st, const ast::Type& t) {
    auto&& _m = t.kind;
    if (prism_rtl::is<ast::TypeKind::TName>(_m)) {
        auto&& n = prism_rtl::as<ast::TypeKind::TName>(_m).a0;
        auto&& args = prism_rtl::as<ast::TypeKind::TName>(_m).a1;
        auto [base, st2] = conv_named(cx_, st, n, args, t.span);
        return std::tuple{check_types::with_marks(n.sigils, base, cx_.scope), st2};
    }
    if (prism_rtl::is<ast::TypeKind::TSigiled>(_m)) {
        auto&& sigils = prism_rtl::as<ast::TypeKind::TSigiled>(_m).a0;
        auto&& inner = prism_rtl::as<ast::TypeKind::TSigiled>(_m).a1;
        auto [i, st2] = conv_type(cx_, st, inner);
        return std::tuple{check_types::with_marks(sigils, i, cx_.scope), st2};
    }
    if (prism_rtl::is<ast::TypeKind::TArray>(_m)) {
        auto&& e = prism_rtl::as<ast::TypeKind::TArray>(_m).a0;
        auto [i, st2] = conv_type(cx_, st, e);
        return std::tuple{check_types::Ty(check_types::Ty::TyArray{prism_rtl::rc(i)}), st2};
    }
    if (prism_rtl::is<ast::TypeKind::TTuple>(_m)) {
        auto&& ts = prism_rtl::as<ast::TypeKind::TTuple>(_m).a0;
        auto [xs, st2] = conv_types(cx_, st, ts);
        return std::tuple{check_types::Ty(check_types::Ty::TyTuple{xs}), st2};
    }
    if (prism_rtl::is<ast::TypeKind::TGroup>(_m)) {
        auto&& x = prism_rtl::as<ast::TypeKind::TGroup>(_m).a0;
        return conv_type(cx_, st, x);
    }
    if (prism_rtl::is<ast::TypeKind::TMap>(_m)) {
        auto&& k = prism_rtl::as<ast::TypeKind::TMap>(_m).a0;
        auto&& v_ = prism_rtl::as<ast::TypeKind::TMap>(_m).a1;
        auto [kk, st2] = conv_type(cx_, st, k);
        auto [vv, st3] = conv_type(cx_, st2, v_);
        return std::tuple{check_types::Ty(check_types::Ty::TyMap{prism_rtl::rc(kk), prism_rtl::rc(vv)}), st3};
    }
    if (prism_rtl::is<ast::TypeKind::TFn>(_m)) {
        auto&& color = prism_rtl::as<ast::TypeKind::TFn>(_m).a0;
        auto&& ps = prism_rtl::as<ast::TypeKind::TFn>(_m).a1;
        auto&& res = prism_rtl::as<ast::TypeKind::TFn>(_m).a2;
        auto [xs, st2] = conv_types(cx_, st, ps);
        auto [r, st3] = conv_type(cx_, st2, res);
        auto c = ({
            __label__ _done;
            prism_rtl::Slot<check_types::Col> _v;
            if (prism_rtl::is<ast::Color::Bounded>(color)) {
                _v.set(cx_.unwritten);
                goto _done;
            }
            if (prism_rtl::is<ast::Color::Unbounded>(color)) {
                _v.set(check_types::Col(check_types::Col::CUnbound{}));
                goto _done;
            }
            if (prism_rtl::is<ast::Color::ColorVar>(color)) {
                auto&& v_ = prism_rtl::as<ast::Color::ColorVar>(color).a0;
                _v.set(v_.name == Text::lit("bounded")
                    ? check_types::Col(check_types::Col::CBound{})
                    : check_types::Col(check_types::Col::CQ{v_.name}));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        return std::tuple{check_types::Ty(check_types::Ty::TyFn{c, xs, prism_rtl::rc(r)}), st3};
    }
    if (prism_rtl::is<ast::TypeKind::TEmit>(_m)) {
        auto&& ty = prism_rtl::as<ast::TypeKind::TEmit>(_m).a0;
        auto&& row_t = prism_rtl::as<ast::TypeKind::TEmit>(_m).a1;
        auto [rw, st2] = conv_row(cx_, st, row_t);
        auto inner = ({
            Cx_ this_ = cx_;
            this_.scope = rw;
            this_;
        });
        return conv_type(inner, st2, ty);
    }
    if (prism_rtl::is<ast::TypeKind::TUnit>(_m)) {
        auto&& sigils = prism_rtl::as<ast::TypeKind::TUnit>(_m).a0;
        return std::tuple{check_types::with_marks(sigils, check_types::t_unit(), cx_.scope), st};
    }
    if (prism_rtl::is<ast::TypeKind::TAny>(_m)) {
        auto&& tr = prism_rtl::as<ast::TypeKind::TAny>(_m).a0;
        auto&& _m = resolve_trait(cx_.g, cx_.home, tr->path_);
        if (prism_rtl::is_some(_m)) {
            auto&& k = prism_rtl::some_of(_m);
            return std::tuple{check_types::Ty(check_types::Ty::TyAny{Array(std::vector{k})}), st};
        }
        if (prism_rtl::is_none(_m)) {
            return std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::err(st, Text::lit("unknown-name"), tr.span, prism_rtl::cat("no trait `^", dotted(tr->path_), "`"))};
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<ast::TypeKind::TAbsent>(_m)) {
        return std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::err(st, Text::lit("unsupported"), t.span, Text::lit("this checker does not implement sparse tuples"))};
    }
    if (prism_rtl::is<ast::TypeKind::TNonEmpty>(_m)) {
        return std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::err(st, Text::lit("unsupported"), t.span, Text::lit("this checker does not implement non-empty arrays"))};
    }
    if (prism_rtl::is<ast::TypeKind::THole>(_m)) {
        return std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::err(st, Text::lit("unsupported"), t.span, Text::lit("this checker does not implement higher-kinded traits"))};
    }
    if (prism_rtl::is<ast::TypeKind::TFamily>(_m)) {
        auto&& q = prism_rtl::as<ast::TypeKind::TFamily>(_m).a0;
        return std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::err(st, Text::lit("kind"), t.span, prism_rtl::cat("`", dotted(q->path_), ".*` is a row, not a type"))};
    }
    if (prism_rtl::is<ast::TypeKind::TRowUnion>(_m)) {
        return std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::err(st, Text::lit("kind"), t.span, Text::lit("a row is not a type"))};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> ConvType::cycle() const {
    const auto& cx_ = this->cx_;
    const auto& st = this->st;
    const auto& t = this->t;
    return ({
        auto&& _m = t.kind;
        prism_rtl::is<ast::TypeKind::TName>(_m) ? ({
        auto&& n = prism_rtl::as<ast::TypeKind::TName>(_m).a0;
        auto&& args = prism_rtl::as<ast::TypeKind::TName>(_m).a1;
        ({
        auto args_1 = args;
        auto cx__2 = cx_;
        auto n_3 = n;
        auto st_4 = st;
        auto t_5 = t;
        call_then(start_conv_named(cx__2, st_4, n_3, args_1, t_5.span), [=](std::tuple<check_types::Ty, check_types::St> conv_named_21027) {
        return ({
            auto [base, st2] = conv_named_21027;
            (prism_rtl::finished(std::tuple{check_types::with_marks(n_3.sigils, base, cx__2.scope), st2}));
        });
    });
    });
    })
        : prism_rtl::is<ast::TypeKind::TSigiled>(_m) ? ({
        auto&& sigils = prism_rtl::as<ast::TypeKind::TSigiled>(_m).a0;
        auto&& inner = prism_rtl::as<ast::TypeKind::TSigiled>(_m).a1;
        ({
        auto cx__1 = cx_;
        auto inner_2 = inner;
        auto sigils_3 = sigils;
        auto st_4 = st;
        call_then(start_conv_type(cx__1, st_4, inner_2), [=](std::tuple<check_types::Ty, check_types::St> conv_type_21168) {
        return ({
            auto [i, st2] = conv_type_21168;
            (prism_rtl::finished(std::tuple{check_types::with_marks(sigils_3, i, cx__1.scope), st2}));
        });
    });
    });
    })
        : prism_rtl::is<ast::TypeKind::TArray>(_m) ? ({
        auto&& e = prism_rtl::as<ast::TypeKind::TArray>(_m).a0;
        ({
        auto cx__1 = cx_;
        auto e_2 = e;
        auto st_3 = st;
        call_then(start_conv_type(cx__1, st_3, e_2), [=](std::tuple<check_types::Ty, check_types::St> conv_type_21287) {
        return ({
            auto [i, st2] = conv_type_21287;
            (prism_rtl::finished(std::tuple{check_types::Ty(check_types::Ty::TyArray{prism_rtl::rc(i)}), st2}));
        });
    });
    });
    })
        : prism_rtl::is<ast::TypeKind::TTuple>(_m) ? ({
        auto&& ts = prism_rtl::as<ast::TypeKind::TTuple>(_m).a0;
        ({
        auto cx__1 = cx_;
        auto st_2 = st;
        auto ts_3 = ts;
        call_then(start_conv_types(cx__1, st_2, ts_3), [=](std::tuple<Array<check_types::Ty>, check_types::St> conv_types_21374) {
        return ({
            auto [xs, st2] = conv_types_21374;
            (prism_rtl::finished(std::tuple{check_types::Ty(check_types::Ty::TyTuple{xs}), st2}));
        });
    });
    });
    })
        : prism_rtl::is<ast::TypeKind::TGroup>(_m) ? ({
        auto&& x = prism_rtl::as<ast::TypeKind::TGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(ConvType(cx_, st, x)));
    })
        : prism_rtl::is<ast::TypeKind::TMap>(_m) ? ({
        auto&& k = prism_rtl::as<ast::TypeKind::TMap>(_m).a0;
        auto&& v_ = prism_rtl::as<ast::TypeKind::TMap>(_m).a1;
        ({
        auto cx__1 = cx_;
        auto k_2 = k;
        auto st_3 = st;
        auto v__4 = v_;
        call_then(start_conv_type(cx__1, st_3, k_2), [=](std::tuple<check_types::Ty, check_types::St> conv_type_21497) {
        return ({
            auto [kk, st2] = conv_type_21497;
            call_then(start_conv_type(cx__1, st2, v__4), [=](std::tuple<check_types::Ty, check_types::St> conv_type_21542) {
            return ({
                auto [vv, st3] = conv_type_21542;
                (prism_rtl::finished(std::tuple{check_types::Ty(check_types::Ty::TyMap{prism_rtl::rc(kk), prism_rtl::rc(vv)}), st3}));
            });
        });
        });
    });
    });
    })
        : prism_rtl::is<ast::TypeKind::TFn>(_m) ? ({
        auto&& color = prism_rtl::as<ast::TypeKind::TFn>(_m).a0;
        auto&& ps = prism_rtl::as<ast::TypeKind::TFn>(_m).a1;
        auto&& res = prism_rtl::as<ast::TypeKind::TFn>(_m).a2;
        ({
        auto color_1 = color;
        auto cx__2 = cx_;
        auto ps_3 = ps;
        auto res_4 = res;
        auto st_5 = st;
        call_then(start_conv_types(cx__2, st_5, ps_3), [=](std::tuple<Array<check_types::Ty>, check_types::St> conv_types_21644) {
        return ({
            auto [xs, st2] = conv_types_21644;
            call_then(start_conv_type(cx__2, st2, res_4), [=](std::tuple<check_types::Ty, check_types::St> conv_type_21690) {
            return ({
                auto [r, st3] = conv_type_21690;
                auto c = ({
                    __label__ _done;
                    prism_rtl::Slot<check_types::Col> _v;
                    if (prism_rtl::is<ast::Color::Bounded>(color)) {
                        _v.set(cx__2.unwritten);
                        goto _done;
                    }
                    if (prism_rtl::is<ast::Color::Unbounded>(color)) {
                        _v.set(check_types::Col(check_types::Col::CUnbound{}));
                        goto _done;
                    }
                    if (prism_rtl::is<ast::Color::ColorVar>(color)) {
                        auto&& v_ = prism_rtl::as<ast::Color::ColorVar>(color).a0;
                        _v.set(v_.name == Text::lit("bounded")
                            ? check_types::Col(check_types::Col::CBound{})
                            : check_types::Col(check_types::Col::CQ{v_.name}));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                (prism_rtl::finished(std::tuple{check_types::Ty(check_types::Ty::TyFn{c, xs, prism_rtl::rc(r)}), st3}));
            });
        });
        });
    });
    });
    })
        : prism_rtl::is<ast::TypeKind::TEmit>(_m) ? ({
        auto&& ty = prism_rtl::as<ast::TypeKind::TEmit>(_m).a0;
        auto&& row_t = prism_rtl::as<ast::TypeKind::TEmit>(_m).a1;
        ({
        auto cx__1 = cx_;
        auto row_t_2 = row_t;
        auto st_3 = st;
        auto ty_4 = ty;
        call_then(start_conv_row(cx__1, st_3, row_t_2), [=](std::tuple<check_types::Rw, check_types::St> conv_row_21957) {
        return ({
            auto [rw, st2] = conv_row_21957;
            auto inner = ({
                Cx_ this_ = cx__1;
                this_.scope = rw;
                this_;
            });
            (prism_rtl::more(prism_rtl::rc(ConvType(inner, st2, ty_4))));
        });
    });
    });
    })
        : prism_rtl::is<ast::TypeKind::TUnit>(_m) ? ({
        auto&& sigils = prism_rtl::as<ast::TypeKind::TUnit>(_m).a0;
        prism_rtl::finished(std::tuple{check_types::with_marks(sigils, check_types::t_unit(), cx_.scope), st});
    })
        : prism_rtl::is<ast::TypeKind::TAny>(_m) ? ({
        auto&& tr = prism_rtl::as<ast::TypeKind::TAny>(_m).a0;
        ({
        auto&& _m = resolve_trait(cx_.g, cx_.home, tr->path_);
        prism_rtl::is_some(_m) ? ({
        auto&& k = prism_rtl::some_of(_m);
        prism_rtl::finished(std::tuple{check_types::Ty(check_types::Ty::TyAny{Array(std::vector{k})}), st});
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::err(st, Text::lit("unknown-name"), tr.span, prism_rtl::cat("no trait `^", dotted(tr->path_), "`"))})
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : prism_rtl::is<ast::TypeKind::TAbsent>(_m) ? prism_rtl::finished(std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::err(st, Text::lit("unsupported"), t.span, Text::lit("this checker does not implement sparse tuples"))})
        : prism_rtl::is<ast::TypeKind::TNonEmpty>(_m) ? prism_rtl::finished(std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::err(st, Text::lit("unsupported"), t.span, Text::lit("this checker does not implement non-empty arrays"))})
        : prism_rtl::is<ast::TypeKind::THole>(_m) ? prism_rtl::finished(std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::err(st, Text::lit("unsupported"), t.span, Text::lit("this checker does not implement higher-kinded traits"))})
        : prism_rtl::is<ast::TypeKind::TFamily>(_m) ? ({
        auto&& q = prism_rtl::as<ast::TypeKind::TFamily>(_m).a0;
        prism_rtl::finished(std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::err(st, Text::lit("kind"), t.span, prism_rtl::cat("`", dotted(q->path_), ".*` is a row, not a type"))});
    })
        : prism_rtl::is<ast::TypeKind::TRowUnion>(_m) ? prism_rtl::finished(std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::err(st, Text::lit("kind"), t.span, Text::lit("a row is not a type"))})
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ConvType, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_conv_type(Cx_ cx_, check_types::St st, ast::Type t) {
    return prism_rtl::make_rc<ConvType>(cx_, st, t);
}


/// ConvTypes: unbounded fn Cx, St, [Type] -> (([Ty], St))
std::tuple<Array<check_types::Ty>, check_types::St> conv_types(const Cx_& cx_, const check_types::St& st, const Array<ast::Type>& ts) {
    return run_to_end(fold_job(ts, std::tuple{Array<check_types::Ty>{}, st}, ({
        auto cx__1 = cx_;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<check_types::Ty>, check_types::St>>(std::tuple<std::tuple<Array<check_types::Ty>, check_types::St>, ast::Type>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<check_types::Ty>, check_types::St>, ast::Type> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto cx__1_2 = cx__1;
            entered(once_job([=]() {
            return ({
                auto [acc, s] = p0;
                auto x = p1;
                call_then(start_conv_type(cx__1_2, s, x), [=](std::tuple<check_types::Ty, check_types::St> conv_type_22967) {
                return ({
                    auto [y, s2] = conv_type_22967;
                    (prism_rtl::finished(std::tuple{prelude::push(acc, y), s2}));
                });
            });
            });
        }));
        });
    }));
    })));
}


prism_rtl::Turn<std::tuple<Array<check_types::Ty>, check_types::St>> ConvTypes::cycle() const {
    const auto& cx_ = this->cx_;
    const auto& st = this->st;
    const auto& ts = this->ts;
    return fold_job(ts, std::tuple{Array<check_types::Ty>{}, st}, ({
        auto cx__1 = cx_;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<check_types::Ty>, check_types::St>>(std::tuple<std::tuple<Array<check_types::Ty>, check_types::St>, ast::Type>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<check_types::Ty>, check_types::St>, ast::Type> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto cx__1_2 = cx__1;
            entered(once_job([=]() {
            return ({
                auto [acc, s] = p0;
                auto x = p1;
                call_then(start_conv_type(cx__1_2, s, x), [=](std::tuple<check_types::Ty, check_types::St> conv_type_22967) {
                return ({
                    auto [y, s2] = conv_type_22967;
                    (prism_rtl::finished(std::tuple{prelude::push(acc, y), s2}));
                });
            });
            });
        }));
        });
    }));
    }))->cycle();
}


/// `Start ConvTypes, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<check_types::Ty>, check_types::St>> start_conv_types(Cx_ cx_, check_types::St st, Array<ast::Type> ts) {
    return prism_rtl::make_rc<ConvTypes>(cx_, st, ts);
}


/// ConvNamed: unbounded fn Cx, St, SName, [Type], Range -> ((Ty, St))
std::tuple<check_types::Ty, check_types::St> conv_named(const Cx_& cx_, const check_types::St& st, const ast::SName& n, const Array<ast::Type>& args, const ast::Range& span) {
    auto name = dotted(n->path_);
    return (len(n->path_) == Nat(1u)) && is_lower_text(name)
        ? len(args) > Nat(0u)
        ? std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::err(st, Text::lit("unsupported"), span, Text::lit("this checker does not implement higher-kinded traits"))}
        : std::tuple{check_types::Ty(check_types::Ty::TyQ{name}), st}
        : (name == Text::lit("Element")) || (name == Text::lit("Prelude.Element"))
        ? ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<check_types::Ty, check_types::St>> _v;
        auto&& _m = len(args);
        {
            auto&& m23564_0 = _m;
            if (m23564_0 == Nat(0u)) {
                _v.set(std::tuple{check_types::Ty(check_types::Ty::TyElem{cx_.scope, prism_rtl::rc(check_types::t_unit())}), st});
                goto _done;
            }
        }
        {
            auto&& m23564_1 = _m;
            if (m23564_1 == Nat(1u)) {
                _v.set(({
                    auto [o, st2] = conv_type(cx_, st, or_(index(args, Nat(0u)), dummy_type()));
                    std::tuple{check_types::Ty(check_types::Ty::TyElem{cx_.scope, prism_rtl::rc(o)}), st2};
                }));
                goto _done;
            }
        }
        {
            auto&& m23564_2 = _m;
            if (m23564_2 == Nat(2u)) {
                _v.set(({
                    auto [rw, st2] = conv_row(cx_, st, or_(index(args, Nat(0u)), dummy_type()));
                    auto [o, st3] = conv_type(cx_, st2, or_(index(args, Nat(1u)), dummy_type()));
                    std::tuple{check_types::Ty(check_types::Ty::TyElem{rw, prism_rtl::rc(o)}), st3};
                }));
                goto _done;
            }
        }
        {
            _v.set(std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::err(st, Text::lit("kind"), span, prism_rtl::cat("`Element` takes a row and a type; here it has ", check_errors::count_word(len(args))))});
            goto _done;
        }
    _done:
        _v.take();
    })
        : name == Text::lit("Elem")
        ? ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<check_types::Ty, check_types::St>> _v;
        auto&& _m = len(args);
        {
            auto&& m24133_0 = _m;
            if (m24133_0 == Nat(0u)) {
                _v.set(std::tuple{check_types::Ty(check_types::Ty::TyElemAny{cx_.scope}), st});
                goto _done;
            }
        }
        {
            auto&& m24133_1 = _m;
            if (m24133_1 == Nat(1u)) {
                _v.set(({
                    auto [rw, st2] = conv_row(cx_, st, or_(index(args, Nat(0u)), dummy_type()));
                    std::tuple{check_types::Ty(check_types::Ty::TyElemAny{rw}), st2};
                }));
                goto _done;
            }
        }
        {
            _v.set(std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::err(st, Text::lit("kind"), span, prism_rtl::cat("`Elem` takes a row; here it has ", check_errors::count_word(len(args))))});
            goto _done;
        }
    _done:
        _v.take();
    })
        : (name == Text::lit("Answer")) || (name == Text::lit("Wired"))
        ? std::tuple{check_types::Ty(check_types::Ty::TyCon{name, Array<check_types::Ty>{}}), st}
        : name == Text::lit("Instant")
        ? std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::err(st, Text::lit("unsupported"), span, Text::lit("this checker does not implement `Instant`"))}
        : check_types::has_text(Array(std::vector{Text::lit("U16"), Text::lit("U32"), Text::lit("U64"), Text::lit("U128"), Text::lit("I8"), Text::lit("I16"), Text::lit("I32"), Text::lit("I64"), Text::lit("I128")}), name)
        ? std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::err(st, Text::lit("unsupported"), span, Text::lit("this checker does not implement sized integers other than `U8`"))}
        : is_prim_type(name)
        ? len(args) == Nat(0u)
        ? std::tuple{check_types::Ty(check_types::Ty::TyCon{name, Array<check_types::Ty>{}}), st}
        : std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::err(st, Text::lit("kind"), span, prism_rtl::cat("`", name, "` takes no type; here it has ", check_errors::count_word(len(args))))}
        : (name == Text::lit("Buffer")) || (name == Text::lit("Table"))
        ? ({
        auto want = name == Text::lit("Buffer") ? Nat(1u) : Nat(2u);
        auto [xs, st2] = conv_types(cx_, st, args);
        len(args) == want
        ? std::tuple{check_types::Ty(check_types::Ty::TyCon{name, xs}), st2}
        : std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::err(st2, Text::lit("kind"), span, prism_rtl::cat("`", name, "` takes ", check_errors::count_word(want), " types; here it has ", check_errors::count_word(len(args))))};
    })
        : ({
        auto [key_opt, why] = resolve_type(cx_.g, cx_.home, n->path_);
        ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<check_types::Ty, check_types::St>> _v;
        if (prism_rtl::is_none(key_opt)) {
            _v.set(std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::err(st, Text::lit("unknown-name"), span, prism_rtl::cat("no type `", name, "`"))});
            goto _done;
        }
        if (prism_rtl::is_some(key_opt)) {
            auto&& qk = prism_rtl::some_of(key_opt);
            _v.set(({
                auto ti = or_(prelude::get(cx_.g.types, qk), dummy_ty_info());
                auto st1 = why == Text::lit("collision")
                    ? check_types::err_fix(st, Text::lit("collision"), span, prism_rtl::cat("`", name, "` is declared by two modules this file reaches by a bare name"), prism_rtl::cat("write it qualified, `", qk, "`, or rename this file's own"))
                    : st;
                auto [xs, st2] = conv_types(cx_, st1, args);
                len(xs) != len(ti.params)
                ? std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::err(st2, Text::lit("kind"), span, prism_rtl::cat("`", name, "` takes ", check_errors::count_word(len(ti.params)), " type", len(ti.params) == Nat(1u) ? Text::lit("") : Text::lit("s"), "; here it has ", check_errors::count_word(len(xs))))}
                : ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<check_types::Ty, check_types::St>> _v;
                auto&& _m = ti.body;
                if (prism_rtl::is<TyBody::BAlias>(_m)) {
                    auto&& body = prism_rtl::as<TyBody::BAlias>(_m).a0;
                    _v.set(std::tuple{check_types::subst_q(param_inst(ti.params, xs), body), st2});
                    goto _done;
                }
                if (prism_rtl::is<TyBody::BRowKind>(_m)) {
                    _v.set(std::tuple{check_types::Ty(check_types::Ty::TyCon{qk, xs}), st2});
                    goto _done;
                }
                {
                    _v.set(std::tuple{check_types::Ty(check_types::Ty::TyCon{qk, xs}), st2});
                    goto _done;
                }
            _done:
                _v.take();
            });
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    });
}


prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> ConvNamed::cycle() const {
    const auto& cx_ = this->cx_;
    const auto& st = this->st;
    const auto& n = this->n;
    const auto& args = this->args;
    const auto& span = this->span;
    auto name = dotted(n->path_);
    return (len(n->path_) == Nat(1u)) && is_lower_text(name)
        ? len(args) > Nat(0u)
        ? prism_rtl::finished(std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::err(st, Text::lit("unsupported"), span, Text::lit("this checker does not implement higher-kinded traits"))})
        : prism_rtl::finished(std::tuple{check_types::Ty(check_types::Ty::TyQ{name}), st})
        : (name == Text::lit("Element")) || (name == Text::lit("Prelude.Element"))
        ? ({
        auto&& _m = len(args);
        ({
        auto&& m23564_0 = _m;
        (m23564_0 == Nat(0u));
    }) ? ({
        auto&& m23564_0 = _m;
        prism_rtl::finished(std::tuple{check_types::Ty(check_types::Ty::TyElem{cx_.scope, prism_rtl::rc(check_types::t_unit())}), st});
    })
        : ({
        auto&& m23564_1 = _m;
        (m23564_1 == Nat(1u));
    }) ? ({
        auto&& m23564_1 = _m;
        ({
        auto args_1 = args;
        auto cx__2 = cx_;
        auto st_3 = st;
        call_then(start_conv_type(cx__2, st_3, or_(index(args_1, Nat(0u)), dummy_type())), [=](std::tuple<check_types::Ty, check_types::St> conv_type_23676) {
        return ({
            auto [o, st2] = conv_type_23676;
            (prism_rtl::finished(std::tuple{check_types::Ty(check_types::Ty::TyElem{cx__2.scope, prism_rtl::rc(o)}), st2}));
        });
    });
    });
    })
        : ({
        auto&& m23564_2 = _m;
        (m23564_2 == Nat(2u));
    }) ? ({
        auto&& m23564_2 = _m;
        ({
        auto args_1 = args;
        auto cx__2 = cx_;
        auto st_3 = st;
        call_then(start_conv_row(cx__2, st_3, or_(index(args_1, Nat(0u)), dummy_type())), [=](std::tuple<check_types::Rw, check_types::St> conv_row_23812) {
        return ({
            auto [rw, st2] = conv_row_23812;
            call_then(start_conv_type(cx__2, st2, or_(index(args_1, Nat(1u)), dummy_type())), [=](std::tuple<check_types::Ty, check_types::St> conv_type_23885) {
            return ({
                auto [o, st3] = conv_type_23885;
                (prism_rtl::finished(std::tuple{check_types::Ty(check_types::Ty::TyElem{rw, prism_rtl::rc(o)}), st3}));
            });
        });
        });
    });
    });
    })
        : prism_rtl::finished(std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::err(st, Text::lit("kind"), span, prism_rtl::cat("`Element` takes a row and a type; here it has ", check_errors::count_word(len(args))))});
    })
        : name == Text::lit("Elem")
        ? ({
        auto&& _m = len(args);
        ({
        auto&& m24133_0 = _m;
        (m24133_0 == Nat(0u));
    }) ? ({
        auto&& m24133_0 = _m;
        prism_rtl::finished(std::tuple{check_types::Ty(check_types::Ty::TyElemAny{cx_.scope}), st});
    })
        : ({
        auto&& m24133_1 = _m;
        (m24133_1 == Nat(1u));
    }) ? ({
        auto&& m24133_1 = _m;
        ({
        auto args_1 = args;
        auto cx__2 = cx_;
        auto st_3 = st;
        call_then(start_conv_row(cx__2, st_3, or_(index(args_1, Nat(0u)), dummy_type())), [=](std::tuple<check_types::Rw, check_types::St> conv_row_24240) {
        return ({
            auto [rw, st2] = conv_row_24240;
            (prism_rtl::finished(std::tuple{check_types::Ty(check_types::Ty::TyElemAny{rw}), st2}));
        });
    });
    });
    })
        : prism_rtl::finished(std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::err(st, Text::lit("kind"), span, prism_rtl::cat("`Elem` takes a row; here it has ", check_errors::count_word(len(args))))});
    })
        : (name == Text::lit("Answer")) || (name == Text::lit("Wired"))
        ? prism_rtl::finished(std::tuple{check_types::Ty(check_types::Ty::TyCon{name, Array<check_types::Ty>{}}), st})
        : name == Text::lit("Instant")
        ? prism_rtl::finished(std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::err(st, Text::lit("unsupported"), span, Text::lit("this checker does not implement `Instant`"))})
        : check_types::has_text(Array(std::vector{Text::lit("U16"), Text::lit("U32"), Text::lit("U64"), Text::lit("U128"), Text::lit("I8"), Text::lit("I16"), Text::lit("I32"), Text::lit("I64"), Text::lit("I128")}), name)
        ? prism_rtl::finished(std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::err(st, Text::lit("unsupported"), span, Text::lit("this checker does not implement sized integers other than `U8`"))})
        : is_prim_type(name)
        ? len(args) == Nat(0u)
        ? prism_rtl::finished(std::tuple{check_types::Ty(check_types::Ty::TyCon{name, Array<check_types::Ty>{}}), st})
        : prism_rtl::finished(std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::err(st, Text::lit("kind"), span, prism_rtl::cat("`", name, "` takes no type; here it has ", check_errors::count_word(len(args))))})
        : (name == Text::lit("Buffer")) || (name == Text::lit("Table"))
        ? ({
        auto want = name == Text::lit("Buffer") ? Nat(1u) : Nat(2u);
        auto args_1 = args;
        auto cx__2 = cx_;
        auto span_3 = span;
        auto st_4 = st;
        call_then(start_conv_types(cx__2, st_4, args_1), [=](std::tuple<Array<check_types::Ty>, check_types::St> conv_types_25175) {
        return ({
            auto [xs, st2] = conv_types_25175;
            len(args_1) == want
            ? prism_rtl::finished(std::tuple{check_types::Ty(check_types::Ty::TyCon{name, xs}), st2})
            : prism_rtl::finished(std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::err(st2, Text::lit("kind"), span_3, prism_rtl::cat("`", name, "` takes ", check_errors::count_word(want), " types; here it has ", check_errors::count_word(len(args_1))))});
        });
    });
    })
        : ({
        auto [key_opt, why] = resolve_type(cx_.g, cx_.home, n->path_);
        ({
        prism_rtl::is_none(key_opt) ? prism_rtl::finished(std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::err(st, Text::lit("unknown-name"), span, prism_rtl::cat("no type `", name, "`"))})
        : prism_rtl::is_some(key_opt) ? ({
        auto&& qk = prism_rtl::some_of(key_opt);
        ({
        auto ti = or_(prelude::get(cx_.g.types, qk), dummy_ty_info());
        auto st1 = why == Text::lit("collision")
            ? check_types::err_fix(st, Text::lit("collision"), span, prism_rtl::cat("`", name, "` is declared by two modules this file reaches by a bare name"), prism_rtl::cat("write it qualified, `", qk, "`, or rename this file's own"))
            : st;
        auto args_1 = args;
        auto cx__2 = cx_;
        auto qk_3 = qk;
        auto span_4 = span;
        call_then(start_conv_types(cx__2, st1, args_1), [=](std::tuple<Array<check_types::Ty>, check_types::St> conv_types_25876) {
        return ({
            auto [xs, st2] = conv_types_25876;
            len(xs) != len(ti.params)
            ? prism_rtl::finished(std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::err(st2, Text::lit("kind"), span_4, prism_rtl::cat("`", name, "` takes ", check_errors::count_word(len(ti.params)), " type", len(ti.params) == Nat(1u) ? Text::lit("") : Text::lit("s"), "; here it has ", check_errors::count_word(len(xs))))})
            : ({
            auto&& _m = ti.body;
            prism_rtl::is<TyBody::BAlias>(_m) ? ({
            auto&& body = prism_rtl::as<TyBody::BAlias>(_m).a0;
            ({
            auto body_5 = body;
            call_then(check_types::start_subst_q(param_inst(ti.params, xs), body_5), [=](check_types::Ty subst_q_26200) { return prism_rtl::finished(std::tuple{subst_q_26200, st2}); });
        });
        })
            : prism_rtl::is<TyBody::BRowKind>(_m) ? prism_rtl::finished(std::tuple{check_types::Ty(check_types::Ty::TyCon{qk_3, xs}), st2})
            : prism_rtl::finished(std::tuple{check_types::Ty(check_types::Ty::TyCon{qk_3, xs}), st2});
        });
        });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    });
}


/// `Start ConvNamed, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_conv_named(Cx_ cx_, check_types::St st, ast::SName n, Array<ast::Type> args, ast::Range span) {
    return prism_rtl::make_rc<ConvNamed>(cx_, st, n, args, span);
}


/// let dummyType
ast::Type dummy_type() {
    return ast::Type{.kind = prism_rtl::rc(ast::TypeKind(ast::TypeKind::TAbsent{})), .span = ast::Range{.start = Nat(0u), .end = Nat(0u)}};
}


/// ParamInst: fn [Text], [Ty] -> Inst
check_types::Inst param_inst(const Array<Text>& ps, const Array<check_types::Ty>& xs) {
    return check_types::Inst{.tys = fold(check_errors::range0(len(ps)), Map<Text, check_types::Ty>{}, [&](const Map<Text, check_types::Ty>& m, const Nat& i) { return insert(m, or_(index(ps, i), Text::lit("")), or_(index(xs, i), check_types::Ty(check_types::Ty::TyErr{}))); }), .rows = Map<Text, check_types::Tail>{}, .cols = Map<Text, check_types::Col>{}};
}


/// ConvRow: unbounded fn Cx, St, Type -> ((Rw, St))
std::tuple<check_types::Rw, check_types::St> conv_row(const Cx_& cx_, const check_types::St& st, const ast::Type& t) {
    auto [fams, vars, st2] = row_parts(cx_, st, t);
    auto st3 = len(vars) > Nat(1u)
        ? check_types::err_fix(st2, Text::lit("row-two-tails"), t.span, prism_rtl::cat("a row has one variable; `", lexer::join(vars, Text::lit(" | ")), "` names two"), Text::lit("keep one variable"))
        : st2;
    auto tail = ({
        __label__ _done;
        prism_rtl::Slot<check_types::Tail> _v;
        auto&& _m = index(vars, Nat(0u));
        if (prism_rtl::is_some(_m)) {
            auto&& v_ = prism_rtl::some_of(_m);
            _v.set(check_types::Tail(check_types::Tail::TlQ{v_}));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(check_types::Tail(check_types::Tail::TlClosed{}));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return std::tuple{check_types::Rw{.fams = check_types::sort_texts(fams), .minus = Array<Text>{}, .tail = tail}, st3};
}


prism_rtl::Turn<std::tuple<check_types::Rw, check_types::St>> ConvRow::cycle() const {
    const auto& cx_ = this->cx_;
    const auto& st = this->st;
    const auto& t = this->t;
    auto cx__1 = cx_;
    auto st_2 = st;
    auto t_3 = t;
    return call_then(start_row_parts(cx__1, st_2, t_3), [=](std::tuple<Array<Text>, Array<Text>, check_types::St> row_parts_26759) {
        return ({
            auto [fams, vars, st2] = row_parts_26759;
            auto st3 = len(vars) > Nat(1u)
                ? check_types::err_fix(st2, Text::lit("row-two-tails"), t_3.span, prism_rtl::cat("a row has one variable; `", lexer::join(vars, Text::lit(" | ")), "` names two"), Text::lit("keep one variable"))
                : st2;
            auto tail = ({
                __label__ _done;
                prism_rtl::Slot<check_types::Tail> _v;
                auto&& _m = index(vars, Nat(0u));
                if (prism_rtl::is_some(_m)) {
                    auto&& v_ = prism_rtl::some_of(_m);
                    _v.set(check_types::Tail(check_types::Tail::TlQ{v_}));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(check_types::Tail(check_types::Tail::TlClosed{}));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            (prism_rtl::finished(std::tuple{check_types::Rw{.fams = check_types::sort_texts(fams), .minus = Array<Text>{}, .tail = tail}, st3}));
        });
    });
}


/// `Start ConvRow, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<check_types::Rw, check_types::St>> start_conv_row(Cx_ cx_, check_types::St st, ast::Type t) {
    return prism_rtl::make_rc<ConvRow>(cx_, st, t);
}


/// RowParts: unbounded fn Cx, St, Type -> (([Text], [Text], St))
std::tuple<Array<Text>, Array<Text>, check_types::St> row_parts(const Cx_& cx_, const check_types::St& st, const ast::Type& t) {
    auto&& _m = t.kind;
    if (prism_rtl::is<ast::TypeKind::TRowUnion>(_m)) {
        auto&& ts = prism_rtl::as<ast::TypeKind::TRowUnion>(_m).a0;
        return run_to_end(fold_job(ts, std::tuple{Array<Text>{}, Array<Text>{}, st}, ({
            auto cx__1 = cx_;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, Array<Text>, check_types::St>>(std::tuple<std::tuple<Array<Text>, Array<Text>, check_types::St>, ast::Type>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<Text>, Array<Text>, check_types::St>, ast::Type> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto cx__1_2 = cx__1;
                entered(once_job([=]() {
                return ({
                    auto [fs, vs, s] = p0;
                    auto x = p1;
                    call_then(start_row_parts(cx__1_2, s, x), [=](std::tuple<Array<Text>, Array<Text>, check_types::St> row_parts_27266) {
                    return ({
                        auto [f2, v2, s2] = row_parts_27266;
                        (prism_rtl::finished(std::tuple{append(fs, f2), append(vs, v2), s2}));
                    });
                });
                });
            }));
            });
        }));
        })));
    }
    if (prism_rtl::is<ast::TypeKind::TGroup>(_m)) {
        auto&& x = prism_rtl::as<ast::TypeKind::TGroup>(_m).a0;
        return row_parts(cx_, st, x);
    }
    if (prism_rtl::is<ast::TypeKind::TFamily>(_m)) {
        auto&& q = prism_rtl::as<ast::TypeKind::TFamily>(_m).a0;
        return std::tuple{Array(std::vector{dotted(q->path_)}), Array<Text>{}, check_family(cx_.g, st, dotted(q->path_), q.span)};
    }
    if (prism_rtl::is<ast::TypeKind::TName>(_m)) {
        auto&& n = prism_rtl::as<ast::TypeKind::TName>(_m).a0;
        auto&& m27156_3_1 = prism_rtl::as<ast::TypeKind::TName>(_m).a1;
        if (m27156_3_1.size() == 0u) {
            auto name = dotted(n->path_);
            return (len(n->path_) == Nat(1u)) && is_lower_text(name)
                ? std::tuple{Array<Text>{}, Array(std::vector{name}), st}
                : name == Text::lit("Element")
                ? std::tuple{cx_.scope.fams, tail_names(cx_.scope.tail), st}
                : std::tuple{Array<Text>{}, Array<Text>{}, check_types::err_fix(st, Text::lit("row-single-tag"), t.span, prism_rtl::cat("a row names families, not tags: `", name, "`"), prism_rtl::cat("write `", dotted(take(n->path_, lexer::dec(len(n->path_)))), ".*`"))};
        }
    }
    {
        return std::tuple{Array<Text>{}, Array<Text>{}, check_types::err(st, Text::lit("kind"), t.span, Text::lit("this is not a row"))};
    }
}


prism_rtl::Turn<std::tuple<Array<Text>, Array<Text>, check_types::St>> RowParts::cycle() const {
    const auto& cx_ = this->cx_;
    const auto& st = this->st;
    const auto& t = this->t;
    return ({
        auto&& _m = t.kind;
        prism_rtl::is<ast::TypeKind::TRowUnion>(_m) ? ({
        auto&& ts = prism_rtl::as<ast::TypeKind::TRowUnion>(_m).a0;
        fold_job(ts, std::tuple{Array<Text>{}, Array<Text>{}, st}, ({
        auto cx__1 = cx_;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, Array<Text>, check_types::St>>(std::tuple<std::tuple<Array<Text>, Array<Text>, check_types::St>, ast::Type>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<Text>, Array<Text>, check_types::St>, ast::Type> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto cx__1_2 = cx__1;
            entered(once_job([=]() {
            return ({
                auto [fs, vs, s] = p0;
                auto x = p1;
                call_then(start_row_parts(cx__1_2, s, x), [=](std::tuple<Array<Text>, Array<Text>, check_types::St> row_parts_27266) {
                return ({
                    auto [f2, v2, s2] = row_parts_27266;
                    (prism_rtl::finished(std::tuple{append(fs, f2), append(vs, v2), s2}));
                });
            });
            });
        }));
        });
    }));
    }))->cycle();
    })
        : prism_rtl::is<ast::TypeKind::TGroup>(_m) ? ({
        auto&& x = prism_rtl::as<ast::TypeKind::TGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(RowParts(cx_, st, x)));
    })
        : prism_rtl::is<ast::TypeKind::TFamily>(_m) ? ({
        auto&& q = prism_rtl::as<ast::TypeKind::TFamily>(_m).a0;
        prism_rtl::finished(std::tuple{Array(std::vector{dotted(q->path_)}), Array<Text>{}, check_family(cx_.g, st, dotted(q->path_), q.span)});
    })
        : prism_rtl::is<ast::TypeKind::TName>(_m) && ({
        auto&& n = prism_rtl::as<ast::TypeKind::TName>(_m).a0;
        auto&& m27156_3_1 = prism_rtl::as<ast::TypeKind::TName>(_m).a1;
        (m27156_3_1.size() == 0u);
    }) ? ({
        auto&& n = prism_rtl::as<ast::TypeKind::TName>(_m).a0;
        auto&& m27156_3_1 = prism_rtl::as<ast::TypeKind::TName>(_m).a1;
        ({
        auto name = dotted(n->path_);
        (len(n->path_) == Nat(1u)) && is_lower_text(name)
        ? prism_rtl::finished(std::tuple{Array<Text>{}, Array(std::vector{name}), st})
        : name == Text::lit("Element")
        ? prism_rtl::finished(std::tuple{cx_.scope.fams, tail_names(cx_.scope.tail), st})
        : prism_rtl::finished(std::tuple{Array<Text>{}, Array<Text>{}, check_types::err_fix(st, Text::lit("row-single-tag"), t.span, prism_rtl::cat("a row names families, not tags: `", name, "`"), prism_rtl::cat("write `", dotted(take(n->path_, lexer::dec(len(n->path_)))), ".*`"))});
    });
    })
        : prism_rtl::finished(std::tuple{Array<Text>{}, Array<Text>{}, check_types::err(st, Text::lit("kind"), t.span, Text::lit("this is not a row"))});
    });
}


/// `Start RowParts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<Text>, Array<Text>, check_types::St>> start_row_parts(Cx_ cx_, check_types::St st, ast::Type t) {
    return prism_rtl::make_rc<RowParts>(cx_, st, t);
}


/// TailNames: fn Tail -> [Text]
Array<Text> tail_names(const check_types::Tail& tail0) {
    if (prism_rtl::is<check_types::Tail::TlQ>(tail0)) {
        auto&& v_ = prism_rtl::as<check_types::Tail::TlQ>(tail0).a0;
        return Array(std::vector{v_});
    }
    if (prism_rtl::is<check_types::Tail::TlRigid>(tail0)) {
        auto&& v_ = prism_rtl::as<check_types::Tail::TlRigid>(tail0).a0;
        return Array(std::vector{v_});
    }
    {
        return Array<Text>{};
    }
}


/// SigScheme: unbounded fn Cx, St, Type, [Bound] -> ((Scheme, St))
std::tuple<check_types::Scheme, check_types::St> sig_scheme(const Cx_& cx_, const check_types::St& st, const ast::Type& t, const Array<ast::Bound>& bounds) {
    auto row_vars = check_types::union_texts(cx_.row_vars, row_vars_of_type(t));
    auto cx2 = ({
        Cx_ this_ = cx_;
        this_.row_vars = row_vars;
        this_.unwritten = check_types::Col(check_types::Col::CBound{});
        this_;
    });
    auto written = color_vars_of_type(t);
    auto [ty, defaults, joins, st2] = sig_type(cx2, st, t, written);
    auto tvs = filter(type_vars_of_type(t), [&](const Text& v_) { return !check_types::has_text(row_vars, v_); });
    auto cqs = fold(defaults, written, [&](const Array<Text>& acc, const Text& v_) { return check_types::add_text(acc, v_); });
    auto [bs, st3] = conv_bounds(cx_, st2, bounds);
    auto rows_used = run_to_end(filter_job(row_vars, ({
        auto t_1 = t;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>>(prism_rtl::rc([=](Text p0) {
        return ({
            auto t_1_2 = t_1;
            entered(once_job([=]() {
            return ({
                auto v_ = p0;
                call_then(start_row_vars_of_type(t_1_2), [=](Array<Text> row_vars_of_type_28787) { return prism_rtl::finished(check_types::has_text(row_vars_of_type_28787, v_) || uses_scope(t_1_2)); });
            });
        }));
        });
    })));
    })));
    return std::tuple{check_types::Scheme{.qs = tvs, .plain_qs = Array<Text>{}, .rqs = rows_used, .cqs = cqs, .cjoins = joins, .bounds = bs, .ty = ty}, st3};
}


prism_rtl::Turn<std::tuple<check_types::Scheme, check_types::St>> SigScheme::cycle() const {
    const auto& cx_ = this->cx_;
    const auto& st = this->st;
    const auto& t = this->t;
    const auto& bounds = this->bounds;
    auto bounds_1 = bounds;
    auto cx__2 = cx_;
    auto st_3 = st;
    auto t_4 = t;
    return call_then(start_row_vars_of_type(t_4), [=](Array<Text> row_vars_of_type_28348) {
        return ({
            auto row_vars = check_types::union_texts(cx__2.row_vars, row_vars_of_type_28348);
            auto cx2 = ({
                Cx_ this_ = cx__2;
                this_.row_vars = row_vars;
                this_.unwritten = check_types::Col(check_types::Col::CBound{});
                this_;
            });
            call_then(start_color_vars_of_type(t_4), [=](Array<Text> color_vars_of_type_28469) {
            return ({
                auto written = color_vars_of_type_28469;
                call_then(start_sig_type(cx2, st_3, t_4, written), [=](std::tuple<check_types::Ty, Array<Text>, Array<std::tuple<Text, Text>>, check_types::St> sig_type_28526) {
                return ({
                    auto [ty, defaults, joins, st2] = sig_type_28526;
                    call_then(start_type_vars_of_type(t_4), [=](Array<Text> type_vars_of_type_28576) {
                    return ({
                        auto tvs = filter(type_vars_of_type_28576, [&](const Text& v_) { return !check_types::has_text(row_vars, v_); });
                        auto cqs = fold(defaults, written, [&](const Array<Text>& acc, const Text& v_) { return check_types::add_text(acc, v_); });
                        auto [bs, st3] = conv_bounds(cx__2, st2, bounds_1);
                        call_value(filter_job(row_vars, ({
                        auto t_4_5 = t_4;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>>(prism_rtl::rc([=](Text p0) {
                        return ({
                            auto t_4_5_5 = t_4_5;
                            entered(once_job([=]() {
                            return ({
                                auto v_ = p0;
                                call_then(start_row_vars_of_type(t_4_5_5), [=](Array<Text> row_vars_of_type_28787) { return prism_rtl::finished(check_types::has_text(row_vars_of_type_28787, v_) || uses_scope(t_4_5_5)); });
                            });
                        }));
                        });
                    })));
                    })), [=](Array<Text> filter_28756) {
                        return ({
                            auto rows_used = filter_28756;
                            (prism_rtl::finished(std::tuple{check_types::Scheme{.qs = tvs, .plain_qs = Array<Text>{}, .rqs = rows_used, .cqs = cqs, .cjoins = joins, .bounds = bs, .ty = ty}, st3}));
                        });
                    });
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start SigScheme, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<check_types::Scheme, check_types::St>> start_sig_scheme(Cx_ cx_, check_types::St st, ast::Type t, Array<ast::Bound> bounds) {
    return prism_rtl::make_rc<SigScheme>(cx_, st, t, bounds);
}


/// SigType: unbounded fn Cx, St, Type, [Text] -> ((Ty, [Text], [((Text, Text))], St))
std::tuple<check_types::Ty, Array<Text>, Array<std::tuple<Text, Text>>, check_types::St> sig_type(const Cx_& cx_, const check_types::St& st, const ast::Type& t, const Array<Text>& written) {
    auto&& _m = t.kind;
    if (prism_rtl::is<ast::TypeKind::TGroup>(_m)) {
        auto&& x = prism_rtl::as<ast::TypeKind::TGroup>(_m).a0;
        return sig_type(cx_, st, x, written);
    }
    if (prism_rtl::is<ast::TypeKind::TFn>(_m)) {
        auto&& color = prism_rtl::as<ast::TypeKind::TFn>(_m).a0;
        auto&& ps = prism_rtl::as<ast::TypeKind::TFn>(_m).a1;
        auto&& res = prism_rtl::as<ast::TypeKind::TFn>(_m).a2;
        return mentions_time(t) || (!takes_closure(t))
            ? bounded_sig(cx_, st, t)
            : closure_sig(cx_, st, color, ps, res, written);
    }
    {
        return bounded_sig(cx_, st, t);
    }
}


prism_rtl::Turn<std::tuple<check_types::Ty, Array<Text>, Array<std::tuple<Text, Text>>, check_types::St>> SigType::cycle() const {
    const auto& cx_ = this->cx_;
    const auto& st = this->st;
    const auto& t = this->t;
    const auto& written = this->written;
    return ({
        auto&& _m = t.kind;
        prism_rtl::is<ast::TypeKind::TGroup>(_m) ? ({
        auto&& x = prism_rtl::as<ast::TypeKind::TGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(SigType(cx_, st, x, written)));
    })
        : prism_rtl::is<ast::TypeKind::TFn>(_m) ? ({
        auto&& color = prism_rtl::as<ast::TypeKind::TFn>(_m).a0;
        auto&& ps = prism_rtl::as<ast::TypeKind::TFn>(_m).a1;
        auto&& res = prism_rtl::as<ast::TypeKind::TFn>(_m).a2;
        ({
        auto color_1 = color;
        auto cx__2 = cx_;
        auto ps_3 = ps;
        auto res_4 = res;
        auto st_5 = st;
        auto t_6 = t;
        auto written_7 = written;
        call_then(start_mentions_time(t_6), [=](bool mentions_time_29929) {
        return mentions_time_29929 || (!takes_closure(t_6))
            ? prism_rtl::more(prism_rtl::rc(BoundedSig(cx__2, st_5, t_6)))
            : prism_rtl::more(prism_rtl::rc(ClosureSig(cx__2, st_5, color_1, ps_3, res_4, written_7)));
    });
    });
    })
        : prism_rtl::more(prism_rtl::rc(BoundedSig(cx_, st, t)));
    });
}


/// `Start SigType, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<check_types::Ty, Array<Text>, Array<std::tuple<Text, Text>>, check_types::St>> start_sig_type(Cx_ cx_, check_types::St st, ast::Type t, Array<Text> written) {
    return prism_rtl::make_rc<SigType>(cx_, st, t, written);
}


/// BoundedSig: unbounded fn Cx, St, Type -> ((Ty, [Text], [((Text, Text))], St))
std::tuple<check_types::Ty, Array<Text>, Array<std::tuple<Text, Text>>, check_types::St> bounded_sig(const Cx_& cx_, const check_types::St& st, const ast::Type& t) {
    auto [ty, st2] = conv_type(cx_, st, t);
    return std::tuple{ty, Array<Text>{}, Array<std::tuple<Text, Text>>{}, st2};
}


prism_rtl::Turn<std::tuple<check_types::Ty, Array<Text>, Array<std::tuple<Text, Text>>, check_types::St>> BoundedSig::cycle() const {
    const auto& cx_ = this->cx_;
    const auto& st = this->st;
    const auto& t = this->t;
    auto cx__1 = cx_;
    auto st_2 = st;
    auto t_3 = t;
    return call_then(start_conv_type(cx__1, st_2, t_3), [=](std::tuple<check_types::Ty, check_types::St> conv_type_30210) {
        return ({
            auto [ty, st2] = conv_type_30210;
            (prism_rtl::finished(std::tuple{ty, Array<Text>{}, Array<std::tuple<Text, Text>>{}, st2}));
        });
    });
}


/// `Start BoundedSig, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<check_types::Ty, Array<Text>, Array<std::tuple<Text, Text>>, check_types::St>> start_bounded_sig(Cx_ cx_, check_types::St st, ast::Type t) {
    return prism_rtl::make_rc<BoundedSig>(cx_, st, t);
}


/// ClosureSig: unbounded fn Cx, St, Color, [Type], Type, [Text] -> ((Ty, [Text], [((Text, Text))], St))
std::tuple<check_types::Ty, Array<Text>, Array<std::tuple<Text, Text>>, check_types::St> closure_sig(const Cx_& cx_, const check_types::St& st, const ast::Color& color, const Array<ast::Type>& ps, const ast::Type& res, const Array<Text>& written) {
    auto [outer_set, outer_w] = written_col(color);
    auto bounded_outer = outer_set && (outer_w == check_types::Col(check_types::Col::CBound{}));
    auto n_default = len(run_to_end(filter_job(ps, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(ast::Type)>>(prism_rtl::rc([=](ast::Type p0) {
        return entered(once_job([=]() {
            return ({
                auto p_ = p0;
                call_then(start_is_fn_type(p_), [=](bool is_fn_type_30548) { return prism_rtl::finished(is_fn_type_30548 && (!writes_col(top_color(p_)))); });
            });
        }));
    })))));
    auto names = fresh_col_names(written, bounded_outer ? Nat(0u) : n_default);
    auto&& _pcols = run_to_end(fold_job(ps, std::tuple{Array<std::tuple<bool, check_types::Col>>{}, Nat(0u)}, ({
        auto bounded_outer_1 = bounded_outer;
        auto names_2 = names;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<std::tuple<bool, check_types::Col>>, Nat>>(std::tuple<std::tuple<Array<std::tuple<bool, check_types::Col>>, Nat>, ast::Type>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<std::tuple<bool, check_types::Col>>, Nat>, ast::Type> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto bounded_outer_1_3 = bounded_outer_1;
            auto names_2_3 = names_2;
            entered(once_job([=]() {
            return ({
                auto [acc, k] = p0;
                auto p_ = p1;
                call_then(start_is_fn_type(p_), [=](bool is_fn_type_30825) {
                return !is_fn_type_30825
                    ? prism_rtl::finished(std::tuple{prelude::push(acc, std::tuple{false, check_types::Col(check_types::Col::CBound{})}), k})
                    : call_then(start_top_color(p_), [=](ast::Color top_color_30930) {
                    return ({
                        auto [set, c] = written_col(top_color_30930);
                        set
                        ? prism_rtl::finished(std::tuple{prelude::push(acc, std::tuple{true, c}), k})
                        : bounded_outer_1_3
                        ? prism_rtl::finished(std::tuple{prelude::push(acc, std::tuple{true, check_types::Col(check_types::Col::CBound{})}), k})
                        : prism_rtl::finished(std::tuple{prelude::push(acc, std::tuple{true, check_types::Col(check_types::Col::CQ{or_(index(names_2_3, k), Text::lit("u"))})}), k + Nat(1u)});
                    });
                });
            });
            });
        }));
        });
    }));
    })));
    auto&& pcols = std::get<0>(_pcols);
    auto vars = fold(pcols, Array<Text>{}, [&](const Array<Text>& acc, const std::tuple<bool, check_types::Col>& _p1) {
        auto&& c = std::get<1>(_p1);
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            if (prism_rtl::is<check_types::Col::CQ>(c)) {
                auto&& v_ = prism_rtl::as<check_types::Col::CQ>(c).a0;
                _v.set(check_types::add_text(acc, v_));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto any_unbounded = fold(pcols, false, [&](const bool& seen, const std::tuple<bool, check_types::Col>& _p1) {
        auto&& c = std::get<1>(_p1);
        return seen || (c == check_types::Col(check_types::Col::CUnbound{}));
    });
    auto spare = fresh_col_names(append(written, names), Nat(1u));
    auto outer_name = (outer_set || any_unbounded) || (len(vars) < Nat(2u))
        ? Text::lit("")
        : or_(index(spare, Nat(0u)), Text::lit("u"));
    auto outer = outer_set
        ? outer_w
        : any_unbounded
        ? check_types::Col(check_types::Col::CUnbound{})
        : len(vars) == Nat(0u)
        ? check_types::Col(check_types::Col::CBound{})
        : len(vars) == Nat(1u)
        ? check_types::Col(check_types::Col::CQ{or_(index(vars, Nat(0u)), Text::lit("u"))})
        : check_types::Col(check_types::Col::CQ{outer_name});
    auto joins = ({
        __label__ _done;
        prism_rtl::Slot<Array<std::tuple<Text, Text>>> _v;
        if (prism_rtl::is<check_types::Col::CQ>(outer)) {
            auto&& hi = prism_rtl::as<check_types::Col::CQ>(outer).a0;
            _v.set(each(filter(vars, [&](const Text& v_) { return v_ != hi; }), [&](const Text& v_) { return std::tuple{v_, hi}; }));
            goto _done;
        }
        {
            _v.set(Array<std::tuple<Text, Text>>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto cx_outer = with_unwritten(cx_, outer);
    auto [xs, st2] = run_to_end(fold_job(check_errors::range0(len(ps)), std::tuple{Array<check_types::Ty>{}, st}, ({
        auto ps_1 = ps;
        auto res_2 = res;
        auto pcols_3 = pcols;
        auto cx__4 = cx_;
        auto cx_outer_5 = cx_outer;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<check_types::Ty>, check_types::St>>(std::tuple<std::tuple<Array<check_types::Ty>, check_types::St>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<check_types::Ty>, check_types::St>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto ps_1_6 = ps_1;
            auto res_2_6 = res_2;
            auto pcols_3_6 = pcols_3;
            auto cx__4_6 = cx__4;
            auto cx_outer_5_6 = cx_outer_5;
            entered(once_job([=]() {
            return ({
                auto [acc, s] = p0;
                auto i = p1;
                ({
                auto p_ = or_(index(ps_1_6, i), res_2_6);
                auto [is_fn, c] = or_(index(pcols_3_6, i), std::tuple{false, check_types::Col(check_types::Col::CBound{})});
                auto pcx = is_fn ? with_unwritten(cx__4_6, c) : cx_outer_5_6;
                call_then(start_conv_type(pcx, s, p_), [=](std::tuple<check_types::Ty, check_types::St> conv_type_32099) {
                return ({
                    auto [y, s2] = conv_type_32099;
                    (prism_rtl::finished(std::tuple{prelude::push(acc, y), s2}));
                });
            });
            });
            });
        }));
        });
    }));
    })));
    auto [r, st3] = conv_type(cx_outer, st2, res);
    auto added = outer_name == Text::lit("") ? names : prelude::push(names, outer_name);
    return std::tuple{check_types::Ty(check_types::Ty::TyFn{outer, xs, prism_rtl::rc(r)}), added, joins, st3};
}


prism_rtl::Turn<std::tuple<check_types::Ty, Array<Text>, Array<std::tuple<Text, Text>>, check_types::St>> ClosureSig::cycle() const {
    const auto& cx_ = this->cx_;
    const auto& st = this->st;
    const auto& color = this->color;
    const auto& ps = this->ps;
    const auto& res = this->res;
    const auto& written = this->written;
    auto [outer_set, outer_w] = written_col(color);
    auto bounded_outer = outer_set && (outer_w == check_types::Col(check_types::Col::CBound{}));
    auto color_1 = color;
    auto cx__2 = cx_;
    auto ps_3 = ps;
    auto res_4 = res;
    auto st_5 = st;
    auto written_6 = written;
    return call_value(filter_job(ps_3, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(ast::Type)>>(prism_rtl::rc([=](ast::Type p0) {
        return entered(once_job([=]() {
            return ({
                auto p_ = p0;
                call_then(start_is_fn_type(p_), [=](bool is_fn_type_30548) { return prism_rtl::finished(is_fn_type_30548 && (!writes_col(top_color(p_)))); });
            });
        }));
    }))), [=](Array<ast::Type> filter_30531) {
        return ({
            auto n_default = len(filter_30531);
            call_then(start_fresh_col_names(written_6, bounded_outer ? Nat(0u) : n_default), [=](Array<Text> fresh_col_names_30610) {
            return ({
                auto names = fresh_col_names_30610;
                call_value(fold_job(ps_3, std::tuple{Array<std::tuple<bool, check_types::Col>>{}, Nat(0u)}, ({
                auto bounded_outer_7 = bounded_outer;
                auto names_8 = names;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<std::tuple<bool, check_types::Col>>, Nat>>(std::tuple<std::tuple<Array<std::tuple<bool, check_types::Col>>, Nat>, ast::Type>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<std::tuple<bool, check_types::Col>>, Nat>, ast::Type> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto bounded_outer_7_9 = bounded_outer_7;
                    auto names_8_9 = names_8;
                    entered(once_job([=]() {
                    return ({
                        auto [acc, k] = p0;
                        auto p_ = p1;
                        call_then(start_is_fn_type(p_), [=](bool is_fn_type_30825) {
                        return !is_fn_type_30825
                            ? prism_rtl::finished(std::tuple{prelude::push(acc, std::tuple{false, check_types::Col(check_types::Col::CBound{})}), k})
                            : call_then(start_top_color(p_), [=](ast::Color top_color_30930) {
                            return ({
                                auto [set, c] = written_col(top_color_30930);
                                set
                                ? prism_rtl::finished(std::tuple{prelude::push(acc, std::tuple{true, c}), k})
                                : bounded_outer_7_9
                                ? prism_rtl::finished(std::tuple{prelude::push(acc, std::tuple{true, check_types::Col(check_types::Col::CBound{})}), k})
                                : prism_rtl::finished(std::tuple{prelude::push(acc, std::tuple{true, check_types::Col(check_types::Col::CQ{or_(index(names_8_9, k), Text::lit("u"))})}), k + Nat(1u)});
                            });
                        });
                    });
                    });
                }));
                });
            }));
            })), [=](std::tuple<Array<std::tuple<bool, check_types::Col>>, Nat> fold_30770) {
                return ({
                    auto&& _pcols = fold_30770;
                    auto&& pcols = std::get<0>(_pcols);
                    auto vars = fold(pcols, Array<Text>{}, [&](const Array<Text>& acc, const std::tuple<bool, check_types::Col>& _p1) {
                        auto&& c = std::get<1>(_p1);
                        return ({
                            __label__ _done;
                            prism_rtl::Slot<Array<Text>> _v;
                            if (prism_rtl::is<check_types::Col::CQ>(c)) {
                                auto&& v_ = prism_rtl::as<check_types::Col::CQ>(c).a0;
                                _v.set(check_types::add_text(acc, v_));
                                goto _done;
                            }
                            {
                                _v.set(acc);
                                goto _done;
                            }
                        _done:
                            _v.take();
                        });
                    });
                    auto any_unbounded = fold(pcols, false, [&](const bool& seen, const std::tuple<bool, check_types::Col>& _p1) {
                        auto&& c = std::get<1>(_p1);
                        return seen || (c == check_types::Col(check_types::Col::CUnbound{}));
                    });
                    call_then(start_fresh_col_names(append(written_6, names), Nat(1u)), [=](Array<Text> fresh_col_names_31358) {
                    return ({
                        auto spare = fresh_col_names_31358;
                        auto outer_name = (outer_set || any_unbounded) || (len(vars) < Nat(2u))
                            ? Text::lit("")
                            : or_(index(spare, Nat(0u)), Text::lit("u"));
                        auto outer = outer_set
                            ? outer_w
                            : any_unbounded
                            ? check_types::Col(check_types::Col::CUnbound{})
                            : len(vars) == Nat(0u)
                            ? check_types::Col(check_types::Col::CBound{})
                            : len(vars) == Nat(1u)
                            ? check_types::Col(check_types::Col::CQ{or_(index(vars, Nat(0u)), Text::lit("u"))})
                            : check_types::Col(check_types::Col::CQ{outer_name});
                        auto joins = ({
                            __label__ _done;
                            prism_rtl::Slot<Array<std::tuple<Text, Text>>> _v;
                            if (prism_rtl::is<check_types::Col::CQ>(outer)) {
                                auto&& hi = prism_rtl::as<check_types::Col::CQ>(outer).a0;
                                _v.set(each(filter(vars, [&](const Text& v_) { return v_ != hi; }), [&](const Text& v_) { return std::tuple{v_, hi}; }));
                                goto _done;
                            }
                            {
                                _v.set(Array<std::tuple<Text, Text>>{});
                                goto _done;
                            }
                        _done:
                            _v.take();
                        });
                        auto cx_outer = with_unwritten(cx__2, outer);
                        call_value(fold_job(check_errors::range0(len(ps_3)), std::tuple{Array<check_types::Ty>{}, st_5}, ({
                        auto ps_3_7 = ps_3;
                        auto res_4_7 = res_4;
                        auto pcols_7 = pcols;
                        auto cx__2_8 = cx__2;
                        auto cx_outer_8 = cx_outer;
                        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<check_types::Ty>, check_types::St>>(std::tuple<std::tuple<Array<check_types::Ty>, check_types::St>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<check_types::Ty>, check_types::St>, Nat> _p0) {
                        auto&& p0 = std::get<0>(_p0);
                        auto&& p1 = std::get<1>(_p0);
                        return ({
                            auto ps_3_7_9 = ps_3_7;
                            auto res_4_7_9 = res_4_7;
                            auto pcols_7_9 = pcols_7;
                            auto cx__2_8_9 = cx__2_8;
                            auto cx_outer_8_9 = cx_outer_8;
                            entered(once_job([=]() {
                            return ({
                                auto [acc, s] = p0;
                                auto i = p1;
                                ({
                                auto p_ = or_(index(ps_3_7_9, i), res_4_7_9);
                                auto [is_fn, c] = or_(index(pcols_7_9, i), std::tuple{false, check_types::Col(check_types::Col::CBound{})});
                                auto pcx = is_fn ? with_unwritten(cx__2_8_9, c) : cx_outer_8_9;
                                call_then(start_conv_type(pcx, s, p_), [=](std::tuple<check_types::Ty, check_types::St> conv_type_32099) {
                                return ({
                                    auto [y, s2] = conv_type_32099;
                                    (prism_rtl::finished(std::tuple{prelude::push(acc, y), s2}));
                                });
                            });
                            });
                            });
                        }));
                        });
                    }));
                    })), [=](std::tuple<Array<check_types::Ty>, check_types::St> fold_31872) {
                        return ({
                            auto [xs, st2] = fold_31872;
                            call_then(start_conv_type(cx_outer, st2, res_4), [=](std::tuple<check_types::Ty, check_types::St> conv_type_32169) {
                            return ({
                                auto [r, st3] = conv_type_32169;
                                auto added = outer_name == Text::lit("") ? names : prelude::push(names, outer_name);
                                (prism_rtl::finished(std::tuple{check_types::Ty(check_types::Ty::TyFn{outer, xs, prism_rtl::rc(r)}), added, joins, st3}));
                            });
                        });
                        });
                    });
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start ClosureSig, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<check_types::Ty, Array<Text>, Array<std::tuple<Text, Text>>, check_types::St>> start_closure_sig(Cx_ cx_, check_types::St st, ast::Color color, Array<ast::Type> ps, ast::Type res, Array<Text> written) {
    return prism_rtl::make_rc<ClosureSig>(cx_, st, color, ps, res, written);
}


/// WrittenCol: fn Color -> ((Bool, Col))
std::tuple<bool, check_types::Col> written_col(const ast::Color& color0) {
    if (prism_rtl::is<ast::Color::Bounded>(color0)) {
        return std::tuple{false, check_types::Col(check_types::Col::CBound{})};
    }
    if (prism_rtl::is<ast::Color::Unbounded>(color0)) {
        return std::tuple{true, check_types::Col(check_types::Col::CUnbound{})};
    }
    if (prism_rtl::is<ast::Color::ColorVar>(color0)) {
        auto&& v_ = prism_rtl::as<ast::Color::ColorVar>(color0).a0;
        return v_.name == Text::lit("bounded")
            ? std::tuple{true, check_types::Col(check_types::Col::CBound{})}
            : std::tuple{true, check_types::Col(check_types::Col::CQ{v_.name})};
    }
    prism_rtl::unreachable("no arm matched");
}


/// WithUnwritten: fn Cx, Col -> Cx
Cx_ with_unwritten(const Cx_& cx_, const check_types::Col& c) {
    Cx_ this_ = cx_;
    this_.unwritten = c;
    return this_;
}


/// WritesCol: fn Color -> Bool
bool writes_col(const ast::Color& color0) {
    if (prism_rtl::is<ast::Color::Bounded>(color0)) {
        return false;
    }
    {
        return true;
    }
}


/// TopColor: unbounded fn Type -> Color
ast::Color top_color(const ast::Type& t) {
    auto&& _m = t.kind;
    if (prism_rtl::is<ast::TypeKind::TFn>(_m)) {
        auto&& c = prism_rtl::as<ast::TypeKind::TFn>(_m).a0;
        return c;
    }
    if (prism_rtl::is<ast::TypeKind::TGroup>(_m)) {
        auto&& x = prism_rtl::as<ast::TypeKind::TGroup>(_m).a0;
        return top_color(x);
    }
    {
        return ast::Color(ast::Color::Bounded{});
    }
}


prism_rtl::Turn<ast::Color> TopColor::cycle() const {
    const auto& t = this->t;
    return ({
        auto&& _m = t.kind;
        prism_rtl::is<ast::TypeKind::TFn>(_m) ? ({
        auto&& c = prism_rtl::as<ast::TypeKind::TFn>(_m).a0;
        prism_rtl::finished(c);
    })
        : prism_rtl::is<ast::TypeKind::TGroup>(_m) ? ({
        auto&& x = prism_rtl::as<ast::TypeKind::TGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(TopColor(x)));
    })
        : prism_rtl::finished(ast::Color(ast::Color::Bounded{}));
    });
}


/// `Start TopColor, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<ast::Color> start_top_color(ast::Type t) {
    return prism_rtl::make_rc<TopColor>(t);
}


/// FreshColNames: unbounded fn [Text], Nat -> [Text]
Array<Text> fresh_col_names(const Array<Text>& taken, const Nat& n) {
    auto&& _names = run_to_end(fold_job(check_errors::range0(n), std::tuple{Array<Text>{}, Nat(1u)}, ({
        auto taken_1 = taken;
        auto n_2 = n;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, Nat>>(std::tuple<std::tuple<Array<Text>, Nat>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<Text>, Nat>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto taken_1_3 = taken_1;
            auto n_2_3 = n_2;
            entered(once_job([=]() {
            return ({
                auto [acc, k] = p0;
                static_cast<void>(p1);
                ({
                auto k2 = next_free_col(append(taken_1_3, acc), n_2_3 == Nat(1u) ? Nat(0u) : k);
                (prism_rtl::finished(std::tuple{prelude::push(acc, sig_col_name(k2)), k2 + Nat(1u)}));
            });
            });
        }));
        });
    }));
    })));
    auto&& names = std::get<0>(_names);
    return names;
}


prism_rtl::Turn<Array<Text>> FreshColNames::cycle() const {
    const auto& taken = this->taken;
    const auto& n = this->n;
    auto n_1 = n;
    auto taken_2 = taken;
    return call_value(fold_job(check_errors::range0(n_1), std::tuple{Array<Text>{}, Nat(1u)}, ({
        auto taken_2_3 = taken_2;
        auto n_1_3 = n_1;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, Nat>>(std::tuple<std::tuple<Array<Text>, Nat>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<Text>, Nat>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto taken_2_3_3 = taken_2_3;
            auto n_1_3_3 = n_1_3;
            entered(once_job([=]() {
            return ({
                auto [acc, k] = p0;
                static_cast<void>(p1);
                ({
                auto k2 = next_free_col(append(taken_2_3_3, acc), n_1_3_3 == Nat(1u) ? Nat(0u) : k);
                (prism_rtl::finished(std::tuple{prelude::push(acc, sig_col_name(k2)), k2 + Nat(1u)}));
            });
            });
        }));
        });
    }));
    })), [=](std::tuple<Array<Text>, Nat> fold_33237) {
        return ({
            auto&& _names = fold_33237;
            auto&& names = std::get<0>(_names);
            (prism_rtl::finished(names));
        });
    });
}


/// `Start FreshColNames, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_fresh_col_names(Array<Text> taken, Nat n) {
    return prism_rtl::make_rc<FreshColNames>(taken, n);
}


/// NextFreeCol: unbounded fn [Text], Nat -> Nat
Nat next_free_col(const Array<Text>& taken, const Nat& k) {
    return check_types::has_text(taken, sig_col_name(k))
        ? next_free_col(taken, k + Nat(1u))
        : k;
}


/// SigColName: fn Nat -> Text
Text sig_col_name(const Nat& n0) {
    {
        auto&& c0_0 = n0;
        if (c0_0 == Nat(0u)) {
            return Text::lit("u");
        }
    }
    {
        auto&& k = n0;
        return prism_rtl::cat("u", k);
    }
}


/// ConvBounds: fn Cx, St, [Bound] -> (([((Text, Text))], St))
std::tuple<Array<std::tuple<Text, Text>>, check_types::St> conv_bounds(const Cx_& cx_, const check_types::St& st, const Array<ast::Bound>& bounds) {
    return fold(bounds, std::tuple{Array<std::tuple<Text, Text>>{}, st}, [&](const std::tuple<Array<std::tuple<Text, Text>>, check_types::St>& _p0, const ast::Bound& b) {
        auto&& acc = std::get<0>(_p0);
        auto&& s = std::get<1>(_p0);
        return fold(b.traits, std::tuple{acc, s}, [&](const std::tuple<Array<std::tuple<Text, Text>>, check_types::St>& _p0, const ast::TraitRef& tr) {
            auto&& a2 = std::get<0>(_p0);
            auto&& s2 = std::get<1>(_p0);
            return ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<Array<std::tuple<Text, Text>>, check_types::St>> _v;
                auto&& _m = resolve_trait(cx_.g, cx_.home, tr->path_);
                if (prism_rtl::is_some(_m)) {
                    auto&& k = prism_rtl::some_of(_m);
                    _v.set(std::tuple{prelude::push(a2, std::tuple{b.var.name, k}), s2});
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(std::tuple{a2, check_types::err(s2, Text::lit("unknown-name"), tr.span, prism_rtl::cat("no trait `^", dotted(tr->path_), "`"))});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
        });
    });
}


/// MentionsTime: unbounded fn Type -> Bool
bool mentions_time(const ast::Type& t) {
    auto&& _m = t.kind;
    if (prism_rtl::is<ast::TypeKind::TName>(_m)) {
        auto&& n = prism_rtl::as<ast::TypeKind::TName>(_m).a0;
        auto&& args = prism_rtl::as<ast::TypeKind::TName>(_m).a1;
        return ((lexer::contains(n.sigils, Text::lit("$")) || lexer::contains(n.sigils, Text::lit("!"))) || lexer::contains(n.sigils, Text::lit("@"))) || run_to_end(fold_job(args, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, ast::Type>)>>(prism_rtl::rc([=](std::tuple<bool, ast::Type> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto seen = p0;
                    auto a = p1;
                    (prism_rtl::finished(seen || mentions_time(a)));
                });
            }));
        }))));
    }
    if (prism_rtl::is<ast::TypeKind::TSigiled>(_m)) {
        auto&& s = prism_rtl::as<ast::TypeKind::TSigiled>(_m).a0;
        auto&& i = prism_rtl::as<ast::TypeKind::TSigiled>(_m).a1;
        return ((lexer::contains(s, Text::lit("$")) || lexer::contains(s, Text::lit("!"))) || lexer::contains(s, Text::lit("@"))) || mentions_time(i);
    }
    if (prism_rtl::is<ast::TypeKind::TUnit>(_m)) {
        auto&& s = prism_rtl::as<ast::TypeKind::TUnit>(_m).a0;
        return (lexer::contains(s, Text::lit("$")) || lexer::contains(s, Text::lit("!"))) || lexer::contains(s, Text::lit("@"));
    }
    if (prism_rtl::is<ast::TypeKind::TArray>(_m)) {
        auto&& e = prism_rtl::as<ast::TypeKind::TArray>(_m).a0;
        return mentions_time(e);
    }
    if (prism_rtl::is<ast::TypeKind::TTuple>(_m)) {
        auto&& ts = prism_rtl::as<ast::TypeKind::TTuple>(_m).a0;
        return run_to_end(fold_job(ts, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, ast::Type>)>>(prism_rtl::rc([=](std::tuple<bool, ast::Type> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto seen = p0;
                    auto a = p1;
                    (prism_rtl::finished(seen || mentions_time(a)));
                });
            }));
        }))));
    }
    if (prism_rtl::is<ast::TypeKind::TGroup>(_m)) {
        auto&& x = prism_rtl::as<ast::TypeKind::TGroup>(_m).a0;
        return mentions_time(x);
    }
    if (prism_rtl::is<ast::TypeKind::TMap>(_m)) {
        auto&& k = prism_rtl::as<ast::TypeKind::TMap>(_m).a0;
        auto&& v_ = prism_rtl::as<ast::TypeKind::TMap>(_m).a1;
        return mentions_time(k) || mentions_time(v_);
    }
    if (prism_rtl::is<ast::TypeKind::TFn>(_m)) {
        auto&& ps = prism_rtl::as<ast::TypeKind::TFn>(_m).a1;
        auto&& res = prism_rtl::as<ast::TypeKind::TFn>(_m).a2;
        return run_to_end(fold_job(ps, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, ast::Type>)>>(prism_rtl::rc([=](std::tuple<bool, ast::Type> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto seen = p0;
                    auto a = p1;
                    (prism_rtl::finished(seen || mentions_time(a)));
                });
            }));
        })))) || mentions_time(res);
    }
    if (prism_rtl::is<ast::TypeKind::TEmit>(_m)) {
        auto&& ty = prism_rtl::as<ast::TypeKind::TEmit>(_m).a0;
        return true;
    }
    {
        return false;
    }
}


prism_rtl::Turn<bool> MentionsTime::cycle() const {
    const auto& t = this->t;
    return ({
        auto&& _m = t.kind;
        prism_rtl::is<ast::TypeKind::TName>(_m) ? ({
        auto&& n = prism_rtl::as<ast::TypeKind::TName>(_m).a0;
        auto&& args = prism_rtl::as<ast::TypeKind::TName>(_m).a1;
        prism_rtl::finished(((lexer::contains(n.sigils, Text::lit("$")) || lexer::contains(n.sigils, Text::lit("!"))) || lexer::contains(n.sigils, Text::lit("@"))) || run_to_end(fold_job(args, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, ast::Type>)>>(prism_rtl::rc([=](std::tuple<bool, ast::Type> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto seen = p0;
                auto a = p1;
                (prism_rtl::finished(seen || mentions_time(a)));
            });
        }));
    })))));
    })
        : prism_rtl::is<ast::TypeKind::TSigiled>(_m) ? ({
        auto&& s = prism_rtl::as<ast::TypeKind::TSigiled>(_m).a0;
        auto&& i = prism_rtl::as<ast::TypeKind::TSigiled>(_m).a1;
        prism_rtl::finished(((lexer::contains(s, Text::lit("$")) || lexer::contains(s, Text::lit("!"))) || lexer::contains(s, Text::lit("@"))) || mentions_time(i));
    })
        : prism_rtl::is<ast::TypeKind::TUnit>(_m) ? ({
        auto&& s = prism_rtl::as<ast::TypeKind::TUnit>(_m).a0;
        prism_rtl::finished((lexer::contains(s, Text::lit("$")) || lexer::contains(s, Text::lit("!"))) || lexer::contains(s, Text::lit("@")));
    })
        : prism_rtl::is<ast::TypeKind::TArray>(_m) ? ({
        auto&& e = prism_rtl::as<ast::TypeKind::TArray>(_m).a0;
        prism_rtl::more(prism_rtl::rc(MentionsTime(e)));
    })
        : prism_rtl::is<ast::TypeKind::TTuple>(_m) ? ({
        auto&& ts = prism_rtl::as<ast::TypeKind::TTuple>(_m).a0;
        fold_job(ts, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, ast::Type>)>>(prism_rtl::rc([=](std::tuple<bool, ast::Type> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto seen = p0;
                auto a = p1;
                (prism_rtl::finished(seen || mentions_time(a)));
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<ast::TypeKind::TGroup>(_m) ? ({
        auto&& x = prism_rtl::as<ast::TypeKind::TGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(MentionsTime(x)));
    })
        : prism_rtl::is<ast::TypeKind::TMap>(_m) ? ({
        auto&& k = prism_rtl::as<ast::TypeKind::TMap>(_m).a0;
        auto&& v_ = prism_rtl::as<ast::TypeKind::TMap>(_m).a1;
        ({
        auto k_1 = k;
        auto v__2 = v_;
        call_then(start_mentions_time(k_1), [=](bool mentions_time_34617) { return prism_rtl::finished(mentions_time_34617 || mentions_time(v__2)); });
    });
    })
        : prism_rtl::is<ast::TypeKind::TFn>(_m) ? ({
        auto&& ps = prism_rtl::as<ast::TypeKind::TFn>(_m).a1;
        auto&& res = prism_rtl::as<ast::TypeKind::TFn>(_m).a2;
        ({
        auto ps_1 = ps;
        auto res_2 = res;
        call_value(fold_job(ps_1, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, ast::Type>)>>(prism_rtl::rc([=](std::tuple<bool, ast::Type> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto seen = p0;
                auto a = p1;
                (prism_rtl::finished(seen || mentions_time(a)));
            });
        }));
    }))), [=](bool fold_34677) { return prism_rtl::finished(fold_34677 || mentions_time(res_2)); });
    });
    })
        : prism_rtl::is<ast::TypeKind::TEmit>(_m) ? ({
        auto&& ty = prism_rtl::as<ast::TypeKind::TEmit>(_m).a0;
        prism_rtl::finished(true);
    })
        : prism_rtl::finished(false);
    });
}


/// `Start MentionsTime, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_mentions_time(ast::Type t) {
    return prism_rtl::make_rc<MentionsTime>(t);
}


/// TakesClosure: unbounded fn Type -> Bool
bool takes_closure(const ast::Type& t) {
    auto&& _m = t.kind;
    if (prism_rtl::is<ast::TypeKind::TFn>(_m)) {
        auto&& ps = prism_rtl::as<ast::TypeKind::TFn>(_m).a1;
        return run_to_end(fold_job(ps, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, ast::Type>)>>(prism_rtl::rc([=](std::tuple<bool, ast::Type> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto seen = p0;
                    auto p_ = p1;
                    (prism_rtl::finished(seen || is_fn_type(p_)));
                });
            }));
        }))));
    }
    {
        return false;
    }
}


prism_rtl::Turn<bool> TakesClosure::cycle() const {
    const auto& t = this->t;
    return ({
        auto&& _m = t.kind;
        prism_rtl::is<ast::TypeKind::TFn>(_m) ? ({
        auto&& ps = prism_rtl::as<ast::TypeKind::TFn>(_m).a1;
        fold_job(ps, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, ast::Type>)>>(prism_rtl::rc([=](std::tuple<bool, ast::Type> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto seen = p0;
                auto p_ = p1;
                (prism_rtl::finished(seen || is_fn_type(p_)));
            });
        }));
    })))->cycle();
    })
        : prism_rtl::finished(false);
    });
}


/// `Start TakesClosure, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_takes_closure(ast::Type t) {
    return prism_rtl::make_rc<TakesClosure>(t);
}


/// IsFnType: unbounded fn Type -> Bool
bool is_fn_type(const ast::Type& t) {
    auto&& _m = t.kind;
    if (prism_rtl::is<ast::TypeKind::TFn>(_m)) {
        return true;
    }
    if (prism_rtl::is<ast::TypeKind::TGroup>(_m)) {
        auto&& x = prism_rtl::as<ast::TypeKind::TGroup>(_m).a0;
        return is_fn_type(x);
    }
    {
        return false;
    }
}


prism_rtl::Turn<bool> IsFnType::cycle() const {
    const auto& t = this->t;
    return ({
        auto&& _m = t.kind;
        prism_rtl::is<ast::TypeKind::TFn>(_m) ? prism_rtl::finished(true)
        : prism_rtl::is<ast::TypeKind::TGroup>(_m) ? ({
        auto&& x = prism_rtl::as<ast::TypeKind::TGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(IsFnType(x)));
    })
        : prism_rtl::finished(false);
    });
}


/// `Start IsFnType, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_is_fn_type(ast::Type t) {
    return prism_rtl::make_rc<IsFnType>(t);
}


/// UsesScope: unbounded fn Type -> Bool
bool uses_scope(const ast::Type& t) {
    auto&& _m = t.kind;
    if (prism_rtl::is<ast::TypeKind::TName>(_m)) {
        auto&& n = prism_rtl::as<ast::TypeKind::TName>(_m).a0;
        auto&& args = prism_rtl::as<ast::TypeKind::TName>(_m).a1;
        return ((lexer::contains(n.sigils, Text::lit("@")) || ((dotted(n->path_) == Text::lit("Element")) && (len(args) < Nat(2u)))) || ((dotted(n->path_) == Text::lit("Elem")) && (len(args) == Nat(0u)))) || run_to_end(fold_job(args, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, ast::Type>)>>(prism_rtl::rc([=](std::tuple<bool, ast::Type> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto seen = p0;
                    auto a = p1;
                    (prism_rtl::finished(seen || uses_scope(a)));
                });
            }));
        }))));
    }
    if (prism_rtl::is<ast::TypeKind::TSigiled>(_m)) {
        auto&& s = prism_rtl::as<ast::TypeKind::TSigiled>(_m).a0;
        auto&& i = prism_rtl::as<ast::TypeKind::TSigiled>(_m).a1;
        return lexer::contains(s, Text::lit("@")) || uses_scope(i);
    }
    if (prism_rtl::is<ast::TypeKind::TUnit>(_m)) {
        auto&& s = prism_rtl::as<ast::TypeKind::TUnit>(_m).a0;
        return lexer::contains(s, Text::lit("@"));
    }
    if (prism_rtl::is<ast::TypeKind::TArray>(_m)) {
        auto&& e = prism_rtl::as<ast::TypeKind::TArray>(_m).a0;
        return uses_scope(e);
    }
    if (prism_rtl::is<ast::TypeKind::TTuple>(_m)) {
        auto&& ts = prism_rtl::as<ast::TypeKind::TTuple>(_m).a0;
        return run_to_end(fold_job(ts, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, ast::Type>)>>(prism_rtl::rc([=](std::tuple<bool, ast::Type> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto seen = p0;
                    auto a = p1;
                    (prism_rtl::finished(seen || uses_scope(a)));
                });
            }));
        }))));
    }
    if (prism_rtl::is<ast::TypeKind::TGroup>(_m)) {
        auto&& x = prism_rtl::as<ast::TypeKind::TGroup>(_m).a0;
        return uses_scope(x);
    }
    if (prism_rtl::is<ast::TypeKind::TMap>(_m)) {
        auto&& k = prism_rtl::as<ast::TypeKind::TMap>(_m).a0;
        auto&& v_ = prism_rtl::as<ast::TypeKind::TMap>(_m).a1;
        return uses_scope(k) || uses_scope(v_);
    }
    if (prism_rtl::is<ast::TypeKind::TFn>(_m)) {
        auto&& ps = prism_rtl::as<ast::TypeKind::TFn>(_m).a1;
        auto&& res = prism_rtl::as<ast::TypeKind::TFn>(_m).a2;
        return run_to_end(fold_job(ps, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, ast::Type>)>>(prism_rtl::rc([=](std::tuple<bool, ast::Type> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto seen = p0;
                    auto a = p1;
                    (prism_rtl::finished(seen || uses_scope(a)));
                });
            }));
        })))) || uses_scope(res);
    }
    if (prism_rtl::is<ast::TypeKind::TEmit>(_m)) {
        auto&& ty = prism_rtl::as<ast::TypeKind::TEmit>(_m).a0;
        auto&& row_t = prism_rtl::as<ast::TypeKind::TEmit>(_m).a1;
        return uses_scope(row_t);
    }
    {
        return false;
    }
}


prism_rtl::Turn<bool> UsesScope::cycle() const {
    const auto& t = this->t;
    return ({
        auto&& _m = t.kind;
        prism_rtl::is<ast::TypeKind::TName>(_m) ? ({
        auto&& n = prism_rtl::as<ast::TypeKind::TName>(_m).a0;
        auto&& args = prism_rtl::as<ast::TypeKind::TName>(_m).a1;
        prism_rtl::finished(((lexer::contains(n.sigils, Text::lit("@")) || ((dotted(n->path_) == Text::lit("Element")) && (len(args) < Nat(2u)))) || ((dotted(n->path_) == Text::lit("Elem")) && (len(args) == Nat(0u)))) || run_to_end(fold_job(args, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, ast::Type>)>>(prism_rtl::rc([=](std::tuple<bool, ast::Type> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto seen = p0;
                auto a = p1;
                (prism_rtl::finished(seen || uses_scope(a)));
            });
        }));
    })))));
    })
        : prism_rtl::is<ast::TypeKind::TSigiled>(_m) ? ({
        auto&& s = prism_rtl::as<ast::TypeKind::TSigiled>(_m).a0;
        auto&& i = prism_rtl::as<ast::TypeKind::TSigiled>(_m).a1;
        prism_rtl::finished(lexer::contains(s, Text::lit("@")) || uses_scope(i));
    })
        : prism_rtl::is<ast::TypeKind::TUnit>(_m) ? ({
        auto&& s = prism_rtl::as<ast::TypeKind::TUnit>(_m).a0;
        prism_rtl::finished(lexer::contains(s, Text::lit("@")));
    })
        : prism_rtl::is<ast::TypeKind::TArray>(_m) ? ({
        auto&& e = prism_rtl::as<ast::TypeKind::TArray>(_m).a0;
        prism_rtl::more(prism_rtl::rc(UsesScope(e)));
    })
        : prism_rtl::is<ast::TypeKind::TTuple>(_m) ? ({
        auto&& ts = prism_rtl::as<ast::TypeKind::TTuple>(_m).a0;
        fold_job(ts, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, ast::Type>)>>(prism_rtl::rc([=](std::tuple<bool, ast::Type> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto seen = p0;
                auto a = p1;
                (prism_rtl::finished(seen || uses_scope(a)));
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<ast::TypeKind::TGroup>(_m) ? ({
        auto&& x = prism_rtl::as<ast::TypeKind::TGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(UsesScope(x)));
    })
        : prism_rtl::is<ast::TypeKind::TMap>(_m) ? ({
        auto&& k = prism_rtl::as<ast::TypeKind::TMap>(_m).a0;
        auto&& v_ = prism_rtl::as<ast::TypeKind::TMap>(_m).a1;
        ({
        auto k_1 = k;
        auto v__2 = v_;
        call_then(start_uses_scope(k_1), [=](bool uses_scope_35684) { return prism_rtl::finished(uses_scope_35684 || uses_scope(v__2)); });
    });
    })
        : prism_rtl::is<ast::TypeKind::TFn>(_m) ? ({
        auto&& ps = prism_rtl::as<ast::TypeKind::TFn>(_m).a1;
        auto&& res = prism_rtl::as<ast::TypeKind::TFn>(_m).a2;
        ({
        auto ps_1 = ps;
        auto res_2 = res;
        call_value(fold_job(ps_1, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, ast::Type>)>>(prism_rtl::rc([=](std::tuple<bool, ast::Type> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto seen = p0;
                auto a = p1;
                (prism_rtl::finished(seen || uses_scope(a)));
            });
        }));
    }))), [=](bool fold_35738) { return prism_rtl::finished(fold_35738 || uses_scope(res_2)); });
    });
    })
        : prism_rtl::is<ast::TypeKind::TEmit>(_m) ? ({
        auto&& ty = prism_rtl::as<ast::TypeKind::TEmit>(_m).a0;
        auto&& row_t = prism_rtl::as<ast::TypeKind::TEmit>(_m).a1;
        prism_rtl::more(prism_rtl::rc(UsesScope(row_t)));
    })
        : prism_rtl::finished(false);
    });
}


/// `Start UsesScope, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_uses_scope(ast::Type t) {
    return prism_rtl::make_rc<UsesScope>(t);
}


/// RowVarsOfType: unbounded fn Type -> [Text]
Array<Text> row_vars_of_type(const ast::Type& t) {
    auto&& _m = t.kind;
    if (prism_rtl::is<ast::TypeKind::TName>(_m)) {
        auto&& n = prism_rtl::as<ast::TypeKind::TName>(_m).a0;
        auto&& args = prism_rtl::as<ast::TypeKind::TName>(_m).a1;
        auto name = dotted(n->path_);
        auto own = ((name == Text::lit("Element")) && (len(args) == Nat(2u))) || ((name == Text::lit("Elem")) && (len(args) == Nat(1u)))
            ? row_names_in(or_(index(args, Nat(0u)), dummy_type()))
            : Array<Text>{};
        auto rest = (name == Text::lit("Element")) && (len(args) == Nat(2u))
            ? drop(args, Nat(1u))
            : name == Text::lit("Elem") ? Array<ast::Type>{} : args;
        return run_to_end(fold_job(rest, own, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, ast::Type>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, ast::Type> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto a = p1;
                    call_then(start_row_vars_of_type(a), [=](Array<Text> row_vars_of_type_36358) { return prism_rtl::finished(check_types::union_texts(acc, row_vars_of_type_36358)); });
                });
            }));
        }))));
    }
    if (prism_rtl::is<ast::TypeKind::TSigiled>(_m)) {
        auto&& i = prism_rtl::as<ast::TypeKind::TSigiled>(_m).a1;
        return row_vars_of_type(i);
    }
    if (prism_rtl::is<ast::TypeKind::TArray>(_m)) {
        auto&& e = prism_rtl::as<ast::TypeKind::TArray>(_m).a0;
        return row_vars_of_type(e);
    }
    if (prism_rtl::is<ast::TypeKind::TTuple>(_m)) {
        auto&& ts = prism_rtl::as<ast::TypeKind::TTuple>(_m).a0;
        return run_to_end(fold_job(ts, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, ast::Type>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, ast::Type> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto a = p1;
                    call_then(start_row_vars_of_type(a), [=](Array<Text> row_vars_of_type_36510) { return prism_rtl::finished(check_types::union_texts(acc, row_vars_of_type_36510)); });
                });
            }));
        }))));
    }
    if (prism_rtl::is<ast::TypeKind::TGroup>(_m)) {
        auto&& x = prism_rtl::as<ast::TypeKind::TGroup>(_m).a0;
        return row_vars_of_type(x);
    }
    if (prism_rtl::is<ast::TypeKind::TMap>(_m)) {
        auto&& k = prism_rtl::as<ast::TypeKind::TMap>(_m).a0;
        auto&& v_ = prism_rtl::as<ast::TypeKind::TMap>(_m).a1;
        return check_types::union_texts(row_vars_of_type(k), row_vars_of_type(v_));
    }
    if (prism_rtl::is<ast::TypeKind::TFn>(_m)) {
        auto&& ps = prism_rtl::as<ast::TypeKind::TFn>(_m).a1;
        auto&& res = prism_rtl::as<ast::TypeKind::TFn>(_m).a2;
        return run_to_end(fold_job(ps, row_vars_of_type(res), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, ast::Type>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, ast::Type> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto a = p1;
                    call_then(start_row_vars_of_type(a), [=](Array<Text> row_vars_of_type_36702) { return prism_rtl::finished(check_types::union_texts(acc, row_vars_of_type_36702)); });
                });
            }));
        }))));
    }
    if (prism_rtl::is<ast::TypeKind::TEmit>(_m)) {
        auto&& ty = prism_rtl::as<ast::TypeKind::TEmit>(_m).a0;
        auto&& row_t = prism_rtl::as<ast::TypeKind::TEmit>(_m).a1;
        return check_types::union_texts(row_vars_of_type(ty), row_names_in(row_t));
    }
    {
        return Array<Text>{};
    }
}


prism_rtl::Turn<Array<Text>> RowVarsOfType::cycle() const {
    const auto& t = this->t;
    return ({
        auto&& _m = t.kind;
        prism_rtl::is<ast::TypeKind::TName>(_m) ? ({
        auto&& n = prism_rtl::as<ast::TypeKind::TName>(_m).a0;
        auto&& args = prism_rtl::as<ast::TypeKind::TName>(_m).a1;
        ({
        auto name = dotted(n->path_);
        auto own = ((name == Text::lit("Element")) && (len(args) == Nat(2u))) || ((name == Text::lit("Elem")) && (len(args) == Nat(1u)))
            ? row_names_in(or_(index(args, Nat(0u)), dummy_type()))
            : Array<Text>{};
        auto rest = (name == Text::lit("Element")) && (len(args) == Nat(2u))
            ? drop(args, Nat(1u))
            : name == Text::lit("Elem") ? Array<ast::Type>{} : args;
        fold_job(rest, own, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, ast::Type>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, ast::Type> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto a = p1;
                call_then(start_row_vars_of_type(a), [=](Array<Text> row_vars_of_type_36358) { return prism_rtl::finished(check_types::union_texts(acc, row_vars_of_type_36358)); });
            });
        }));
    })))->cycle();
    });
    })
        : prism_rtl::is<ast::TypeKind::TSigiled>(_m) ? ({
        auto&& i = prism_rtl::as<ast::TypeKind::TSigiled>(_m).a1;
        prism_rtl::more(prism_rtl::rc(RowVarsOfType(i)));
    })
        : prism_rtl::is<ast::TypeKind::TArray>(_m) ? ({
        auto&& e = prism_rtl::as<ast::TypeKind::TArray>(_m).a0;
        prism_rtl::more(prism_rtl::rc(RowVarsOfType(e)));
    })
        : prism_rtl::is<ast::TypeKind::TTuple>(_m) ? ({
        auto&& ts = prism_rtl::as<ast::TypeKind::TTuple>(_m).a0;
        fold_job(ts, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, ast::Type>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, ast::Type> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto a = p1;
                call_then(start_row_vars_of_type(a), [=](Array<Text> row_vars_of_type_36510) { return prism_rtl::finished(check_types::union_texts(acc, row_vars_of_type_36510)); });
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<ast::TypeKind::TGroup>(_m) ? ({
        auto&& x = prism_rtl::as<ast::TypeKind::TGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(RowVarsOfType(x)));
    })
        : prism_rtl::is<ast::TypeKind::TMap>(_m) ? ({
        auto&& k = prism_rtl::as<ast::TypeKind::TMap>(_m).a0;
        auto&& v_ = prism_rtl::as<ast::TypeKind::TMap>(_m).a1;
        ({
        auto k_1 = k;
        auto v__2 = v_;
        call_then(start_row_vars_of_type(k_1), [=](Array<Text> row_vars_of_type_36584) { return call_then(start_row_vars_of_type(v__2), [=](Array<Text> row_vars_of_type_36603) { return prism_rtl::finished(check_types::union_texts(row_vars_of_type_36584, row_vars_of_type_36603)); }); });
    });
    })
        : prism_rtl::is<ast::TypeKind::TFn>(_m) ? ({
        auto&& ps = prism_rtl::as<ast::TypeKind::TFn>(_m).a1;
        auto&& res = prism_rtl::as<ast::TypeKind::TFn>(_m).a2;
        ({
        auto ps_1 = ps;
        auto res_2 = res;
        call_then(start_row_vars_of_type(res_2), [=](Array<Text> row_vars_of_type_36655) {
        return fold_job(ps_1, row_vars_of_type_36655, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, ast::Type>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, ast::Type> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto a = p1;
                    call_then(start_row_vars_of_type(a), [=](Array<Text> row_vars_of_type_36702) { return prism_rtl::finished(check_types::union_texts(acc, row_vars_of_type_36702)); });
                });
            }));
        })))->cycle();
    });
    });
    })
        : prism_rtl::is<ast::TypeKind::TEmit>(_m) ? ({
        auto&& ty = prism_rtl::as<ast::TypeKind::TEmit>(_m).a0;
        auto&& row_t = prism_rtl::as<ast::TypeKind::TEmit>(_m).a1;
        ({
        auto row_t_1 = row_t;
        auto ty_2 = ty;
        call_then(start_row_vars_of_type(ty_2), [=](Array<Text> row_vars_of_type_36751) { return call_then(start_row_names_in(row_t_1), [=](Array<Text> row_names_in_36771) { return prism_rtl::finished(check_types::union_texts(row_vars_of_type_36751, row_names_in_36771)); }); });
    });
    })
        : prism_rtl::finished(Array<Text>{});
    });
}


/// `Start RowVarsOfType, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_row_vars_of_type(ast::Type t) {
    return prism_rtl::make_rc<RowVarsOfType>(t);
}


/// RowNamesIn: unbounded fn Type -> [Text]
Array<Text> row_names_in(const ast::Type& t) {
    auto&& _m = t.kind;
    if (prism_rtl::is<ast::TypeKind::TName>(_m)) {
        auto&& n = prism_rtl::as<ast::TypeKind::TName>(_m).a0;
        auto&& m36867_0_1 = prism_rtl::as<ast::TypeKind::TName>(_m).a1;
        if (m36867_0_1.size() == 0u) {
            return (len(n->path_) == Nat(1u)) && is_lower_text(dotted(n->path_))
                ? Array(std::vector{dotted(n->path_)})
                : Array<Text>{};
        }
    }
    if (prism_rtl::is<ast::TypeKind::TRowUnion>(_m)) {
        auto&& ts = prism_rtl::as<ast::TypeKind::TRowUnion>(_m).a0;
        return run_to_end(fold_job(ts, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, ast::Type>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, ast::Type> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto a = p1;
                    call_then(start_row_names_in(a), [=](Array<Text> row_names_in_37045) { return prism_rtl::finished(check_types::union_texts(acc, row_names_in_37045)); });
                });
            }));
        }))));
    }
    if (prism_rtl::is<ast::TypeKind::TGroup>(_m)) {
        auto&& x = prism_rtl::as<ast::TypeKind::TGroup>(_m).a0;
        return row_names_in(x);
    }
    {
        return Array<Text>{};
    }
}


prism_rtl::Turn<Array<Text>> RowNamesIn::cycle() const {
    const auto& t = this->t;
    return ({
        auto&& _m = t.kind;
        prism_rtl::is<ast::TypeKind::TName>(_m) && ({
        auto&& n = prism_rtl::as<ast::TypeKind::TName>(_m).a0;
        auto&& m36867_0_1 = prism_rtl::as<ast::TypeKind::TName>(_m).a1;
        (m36867_0_1.size() == 0u);
    }) ? ({
        auto&& n = prism_rtl::as<ast::TypeKind::TName>(_m).a0;
        auto&& m36867_0_1 = prism_rtl::as<ast::TypeKind::TName>(_m).a1;
        (len(n->path_) == Nat(1u)) && is_lower_text(dotted(n->path_))
        ? prism_rtl::finished(Array(std::vector{dotted(n->path_)}))
        : prism_rtl::finished(Array<Text>{});
    })
        : prism_rtl::is<ast::TypeKind::TRowUnion>(_m) ? ({
        auto&& ts = prism_rtl::as<ast::TypeKind::TRowUnion>(_m).a0;
        fold_job(ts, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, ast::Type>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, ast::Type> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto a = p1;
                call_then(start_row_names_in(a), [=](Array<Text> row_names_in_37045) { return prism_rtl::finished(check_types::union_texts(acc, row_names_in_37045)); });
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<ast::TypeKind::TGroup>(_m) ? ({
        auto&& x = prism_rtl::as<ast::TypeKind::TGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(RowNamesIn(x)));
    })
        : prism_rtl::finished(Array<Text>{});
    });
}


/// `Start RowNamesIn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_row_names_in(ast::Type t) {
    return prism_rtl::make_rc<RowNamesIn>(t);
}


/// TypeVarsOfType: unbounded fn Type -> [Text]
Array<Text> type_vars_of_type(const ast::Type& t) {
    return type_vars_into(Array<Text>{}, t);
}


prism_rtl::Turn<Array<Text>> TypeVarsOfType::cycle() const {
    const auto& t = this->t;
    return prism_rtl::more(prism_rtl::rc(TypeVarsInto(Array<Text>{}, t)));
}


/// `Start TypeVarsOfType, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_type_vars_of_type(ast::Type t) {
    return prism_rtl::make_rc<TypeVarsOfType>(t);
}


/// TypeVarsInto: unbounded fn [Text], Type -> [Text]
Array<Text> type_vars_into(const Array<Text>& acc, const ast::Type& t) {
    auto&& _m = t.kind;
    if (prism_rtl::is<ast::TypeKind::TName>(_m)) {
        auto&& n = prism_rtl::as<ast::TypeKind::TName>(_m).a0;
        auto&& args = prism_rtl::as<ast::TypeKind::TName>(_m).a1;
        auto name = dotted(n->path_);
        auto here = ((len(n->path_) == Nat(1u)) && is_lower_text(name)) && (len(args) == Nat(0u))
            ? check_types::add_text(acc, name)
            : acc;
        auto rest = (name == Text::lit("Element")) && (len(args) == Nat(2u))
            ? drop(args, Nat(1u))
            : name == Text::lit("Elem") ? Array<ast::Type>{} : args;
        return run_to_end(fold_job(rest, here, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, ast::Type>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, ast::Type> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto a = p0;
                    auto x = p1;
                    (prism_rtl::more(prism_rtl::rc(TypeVarsInto(a, x))));
                });
            }));
        }))));
    }
    if (prism_rtl::is<ast::TypeKind::TSigiled>(_m)) {
        auto&& i = prism_rtl::as<ast::TypeKind::TSigiled>(_m).a1;
        return type_vars_into(acc, i);
    }
    if (prism_rtl::is<ast::TypeKind::TArray>(_m)) {
        auto&& e = prism_rtl::as<ast::TypeKind::TArray>(_m).a0;
        return type_vars_into(acc, e);
    }
    if (prism_rtl::is<ast::TypeKind::TTuple>(_m)) {
        auto&& ts = prism_rtl::as<ast::TypeKind::TTuple>(_m).a0;
        return run_to_end(fold_job(ts, acc, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, ast::Type>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, ast::Type> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto a = p0;
                    auto x = p1;
                    (prism_rtl::more(prism_rtl::rc(TypeVarsInto(a, x))));
                });
            }));
        }))));
    }
    if (prism_rtl::is<ast::TypeKind::TGroup>(_m)) {
        auto&& x = prism_rtl::as<ast::TypeKind::TGroup>(_m).a0;
        return type_vars_into(acc, x);
    }
    if (prism_rtl::is<ast::TypeKind::TMap>(_m)) {
        auto&& k = prism_rtl::as<ast::TypeKind::TMap>(_m).a0;
        auto&& v_ = prism_rtl::as<ast::TypeKind::TMap>(_m).a1;
        return type_vars_into(type_vars_into(acc, k), v_);
    }
    if (prism_rtl::is<ast::TypeKind::TFn>(_m)) {
        auto&& ps = prism_rtl::as<ast::TypeKind::TFn>(_m).a1;
        auto&& res = prism_rtl::as<ast::TypeKind::TFn>(_m).a2;
        return type_vars_into(run_to_end(fold_job(ps, acc, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, ast::Type>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, ast::Type> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto a = p0;
                    auto x = p1;
                    (prism_rtl::more(prism_rtl::rc(TypeVarsInto(a, x))));
                });
            }));
        })))), res);
    }
    if (prism_rtl::is<ast::TypeKind::TEmit>(_m)) {
        auto&& ty = prism_rtl::as<ast::TypeKind::TEmit>(_m).a0;
        return type_vars_into(acc, ty);
    }
    {
        return acc;
    }
}


prism_rtl::Turn<Array<Text>> TypeVarsInto::cycle() const {
    const auto& acc = this->acc;
    const auto& t = this->t;
    return ({
        auto&& _m = t.kind;
        prism_rtl::is<ast::TypeKind::TName>(_m) ? ({
        auto&& n = prism_rtl::as<ast::TypeKind::TName>(_m).a0;
        auto&& args = prism_rtl::as<ast::TypeKind::TName>(_m).a1;
        ({
        auto name = dotted(n->path_);
        auto here = ((len(n->path_) == Nat(1u)) && is_lower_text(name)) && (len(args) == Nat(0u))
            ? check_types::add_text(acc, name)
            : acc;
        auto rest = (name == Text::lit("Element")) && (len(args) == Nat(2u))
            ? drop(args, Nat(1u))
            : name == Text::lit("Elem") ? Array<ast::Type>{} : args;
        fold_job(rest, here, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, ast::Type>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, ast::Type> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto a = p0;
                auto x = p1;
                (prism_rtl::more(prism_rtl::rc(TypeVarsInto(a, x))));
            });
        }));
    })))->cycle();
    });
    })
        : prism_rtl::is<ast::TypeKind::TSigiled>(_m) ? ({
        auto&& i = prism_rtl::as<ast::TypeKind::TSigiled>(_m).a1;
        prism_rtl::more(prism_rtl::rc(TypeVarsInto(acc, i)));
    })
        : prism_rtl::is<ast::TypeKind::TArray>(_m) ? ({
        auto&& e = prism_rtl::as<ast::TypeKind::TArray>(_m).a0;
        prism_rtl::more(prism_rtl::rc(TypeVarsInto(acc, e)));
    })
        : prism_rtl::is<ast::TypeKind::TTuple>(_m) ? ({
        auto&& ts = prism_rtl::as<ast::TypeKind::TTuple>(_m).a0;
        fold_job(ts, acc, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, ast::Type>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, ast::Type> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto a = p0;
                auto x = p1;
                (prism_rtl::more(prism_rtl::rc(TypeVarsInto(a, x))));
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<ast::TypeKind::TGroup>(_m) ? ({
        auto&& x = prism_rtl::as<ast::TypeKind::TGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(TypeVarsInto(acc, x)));
    })
        : prism_rtl::is<ast::TypeKind::TMap>(_m) ? ({
        auto&& k = prism_rtl::as<ast::TypeKind::TMap>(_m).a0;
        auto&& v_ = prism_rtl::as<ast::TypeKind::TMap>(_m).a1;
        ({
        auto acc_1 = acc;
        auto k_2 = k;
        auto v__3 = v_;
        call_then(start_type_vars_into(acc_1, k_2), [=](Array<Text> type_vars_into_37902) { return prism_rtl::more(prism_rtl::rc(TypeVarsInto(type_vars_into_37902, v__3))); });
    });
    })
        : prism_rtl::is<ast::TypeKind::TFn>(_m) ? ({
        auto&& ps = prism_rtl::as<ast::TypeKind::TFn>(_m).a1;
        auto&& res = prism_rtl::as<ast::TypeKind::TFn>(_m).a2;
        ({
        auto acc_1 = acc;
        auto ps_2 = ps;
        auto res_3 = res;
        call_value(fold_job(ps_2, acc_1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, ast::Type>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, ast::Type> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto a = p0;
                auto x = p1;
                (prism_rtl::more(prism_rtl::rc(TypeVarsInto(a, x))));
            });
        }));
    }))), [=](Array<Text> fold_37965) { return prism_rtl::more(prism_rtl::rc(TypeVarsInto(fold_37965, res_3))); });
    });
    })
        : prism_rtl::is<ast::TypeKind::TEmit>(_m) ? ({
        auto&& ty = prism_rtl::as<ast::TypeKind::TEmit>(_m).a0;
        prism_rtl::more(prism_rtl::rc(TypeVarsInto(acc, ty)));
    })
        : prism_rtl::finished(acc);
    });
}


/// `Start TypeVarsInto, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_type_vars_into(Array<Text> acc, ast::Type t) {
    return prism_rtl::make_rc<TypeVarsInto>(acc, t);
}


/// ColorVarsOfType: unbounded fn Type -> [Text]
Array<Text> color_vars_of_type(const ast::Type& t) {
    auto&& _m = t.kind;
    if (prism_rtl::is<ast::TypeKind::TFn>(_m) && prism_rtl::is<ast::Color::ColorVar>(prism_rtl::as<ast::TypeKind::TFn>(_m).a0)) {
        auto&& v_ = prism_rtl::as<ast::Color::ColorVar>(prism_rtl::as<ast::TypeKind::TFn>(_m).a0).a0;
        auto&& ps = prism_rtl::as<ast::TypeKind::TFn>(_m).a1;
        auto&& res = prism_rtl::as<ast::TypeKind::TFn>(_m).a2;
        auto inner = run_to_end(fold_job(ps, color_vars_of_type(res), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, ast::Type>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, ast::Type> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto a = p1;
                    call_then(start_color_vars_of_type(a), [=](Array<Text> color_vars_of_type_38266) { return prism_rtl::finished(check_types::union_texts(acc, color_vars_of_type_38266)); });
                });
            }));
        }))));
        return v_.name == Text::lit("bounded")
            ? inner
            : check_types::add_text(inner, v_.name);
    }
    if (prism_rtl::is<ast::TypeKind::TFn>(_m)) {
        auto&& ps = prism_rtl::as<ast::TypeKind::TFn>(_m).a1;
        auto&& res = prism_rtl::as<ast::TypeKind::TFn>(_m).a2;
        return run_to_end(fold_job(ps, color_vars_of_type(res), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, ast::Type>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, ast::Type> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto a = p1;
                    call_then(start_color_vars_of_type(a), [=](Array<Text> color_vars_of_type_38435) { return prism_rtl::finished(check_types::union_texts(acc, color_vars_of_type_38435)); });
                });
            }));
        }))));
    }
    if (prism_rtl::is<ast::TypeKind::TName>(_m)) {
        auto&& args = prism_rtl::as<ast::TypeKind::TName>(_m).a1;
        return run_to_end(fold_job(args, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, ast::Type>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, ast::Type> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto a = p1;
                    call_then(start_color_vars_of_type(a), [=](Array<Text> color_vars_of_type_38522) { return prism_rtl::finished(check_types::union_texts(acc, color_vars_of_type_38522)); });
                });
            }));
        }))));
    }
    if (prism_rtl::is<ast::TypeKind::TSigiled>(_m)) {
        auto&& i = prism_rtl::as<ast::TypeKind::TSigiled>(_m).a1;
        return color_vars_of_type(i);
    }
    if (prism_rtl::is<ast::TypeKind::TArray>(_m)) {
        auto&& e = prism_rtl::as<ast::TypeKind::TArray>(_m).a0;
        return color_vars_of_type(e);
    }
    if (prism_rtl::is<ast::TypeKind::TTuple>(_m)) {
        auto&& ts = prism_rtl::as<ast::TypeKind::TTuple>(_m).a0;
        return run_to_end(fold_job(ts, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, ast::Type>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, ast::Type> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto a = p1;
                    call_then(start_color_vars_of_type(a), [=](Array<Text> color_vars_of_type_38680) { return prism_rtl::finished(check_types::union_texts(acc, color_vars_of_type_38680)); });
                });
            }));
        }))));
    }
    if (prism_rtl::is<ast::TypeKind::TGroup>(_m)) {
        auto&& x = prism_rtl::as<ast::TypeKind::TGroup>(_m).a0;
        return color_vars_of_type(x);
    }
    if (prism_rtl::is<ast::TypeKind::TMap>(_m)) {
        auto&& k = prism_rtl::as<ast::TypeKind::TMap>(_m).a0;
        auto&& v_ = prism_rtl::as<ast::TypeKind::TMap>(_m).a1;
        return check_types::union_texts(color_vars_of_type(k), color_vars_of_type(v_));
    }
    if (prism_rtl::is<ast::TypeKind::TEmit>(_m)) {
        auto&& ty = prism_rtl::as<ast::TypeKind::TEmit>(_m).a0;
        return color_vars_of_type(ty);
    }
    {
        return Array<Text>{};
    }
}


prism_rtl::Turn<Array<Text>> ColorVarsOfType::cycle() const {
    const auto& t = this->t;
    return ({
        auto&& _m = t.kind;
        prism_rtl::is<ast::TypeKind::TFn>(_m) && prism_rtl::is<ast::Color::ColorVar>(prism_rtl::as<ast::TypeKind::TFn>(_m).a0) ? ({
        auto&& v_ = prism_rtl::as<ast::Color::ColorVar>(prism_rtl::as<ast::TypeKind::TFn>(_m).a0).a0;
        auto&& ps = prism_rtl::as<ast::TypeKind::TFn>(_m).a1;
        auto&& res = prism_rtl::as<ast::TypeKind::TFn>(_m).a2;
        ({
        auto ps_1 = ps;
        auto res_2 = res;
        auto v__3 = v_;
        call_then(start_color_vars_of_type(res_2), [=](Array<Text> color_vars_of_type_38217) {
        return call_value(fold_job(ps_1, color_vars_of_type_38217, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, ast::Type>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, ast::Type> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto a = p1;
                    call_then(start_color_vars_of_type(a), [=](Array<Text> color_vars_of_type_38266) { return prism_rtl::finished(check_types::union_texts(acc, color_vars_of_type_38266)); });
                });
            }));
        }))), [=](Array<Text> fold_38207) {
            return ({
                auto inner = fold_38207;
                v__3.name == Text::lit("bounded")
                ? prism_rtl::finished(inner)
                : prism_rtl::finished(check_types::add_text(inner, v__3.name));
            });
        });
    });
    });
    })
        : prism_rtl::is<ast::TypeKind::TFn>(_m) ? ({
        auto&& ps = prism_rtl::as<ast::TypeKind::TFn>(_m).a1;
        auto&& res = prism_rtl::as<ast::TypeKind::TFn>(_m).a2;
        ({
        auto ps_1 = ps;
        auto res_2 = res;
        call_then(start_color_vars_of_type(res_2), [=](Array<Text> color_vars_of_type_38386) {
        return fold_job(ps_1, color_vars_of_type_38386, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, ast::Type>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, ast::Type> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto a = p1;
                    call_then(start_color_vars_of_type(a), [=](Array<Text> color_vars_of_type_38435) { return prism_rtl::finished(check_types::union_texts(acc, color_vars_of_type_38435)); });
                });
            }));
        })))->cycle();
    });
    });
    })
        : prism_rtl::is<ast::TypeKind::TName>(_m) ? ({
        auto&& args = prism_rtl::as<ast::TypeKind::TName>(_m).a1;
        fold_job(args, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, ast::Type>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, ast::Type> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto a = p1;
                call_then(start_color_vars_of_type(a), [=](Array<Text> color_vars_of_type_38522) { return prism_rtl::finished(check_types::union_texts(acc, color_vars_of_type_38522)); });
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<ast::TypeKind::TSigiled>(_m) ? ({
        auto&& i = prism_rtl::as<ast::TypeKind::TSigiled>(_m).a1;
        prism_rtl::more(prism_rtl::rc(ColorVarsOfType(i)));
    })
        : prism_rtl::is<ast::TypeKind::TArray>(_m) ? ({
        auto&& e = prism_rtl::as<ast::TypeKind::TArray>(_m).a0;
        prism_rtl::more(prism_rtl::rc(ColorVarsOfType(e)));
    })
        : prism_rtl::is<ast::TypeKind::TTuple>(_m) ? ({
        auto&& ts = prism_rtl::as<ast::TypeKind::TTuple>(_m).a0;
        fold_job(ts, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, ast::Type>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, ast::Type> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto a = p1;
                call_then(start_color_vars_of_type(a), [=](Array<Text> color_vars_of_type_38680) { return prism_rtl::finished(check_types::union_texts(acc, color_vars_of_type_38680)); });
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<ast::TypeKind::TGroup>(_m) ? ({
        auto&& x = prism_rtl::as<ast::TypeKind::TGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(ColorVarsOfType(x)));
    })
        : prism_rtl::is<ast::TypeKind::TMap>(_m) ? ({
        auto&& k = prism_rtl::as<ast::TypeKind::TMap>(_m).a0;
        auto&& v_ = prism_rtl::as<ast::TypeKind::TMap>(_m).a1;
        ({
        auto k_1 = k;
        auto v__2 = v_;
        call_then(start_color_vars_of_type(k_1), [=](Array<Text> color_vars_of_type_38758) { return call_then(start_color_vars_of_type(v__2), [=](Array<Text> color_vars_of_type_38779) { return prism_rtl::finished(check_types::union_texts(color_vars_of_type_38758, color_vars_of_type_38779)); }); });
    });
    })
        : prism_rtl::is<ast::TypeKind::TEmit>(_m) ? ({
        auto&& ty = prism_rtl::as<ast::TypeKind::TEmit>(_m).a0;
        prism_rtl::more(prism_rtl::rc(ColorVarsOfType(ty)));
    })
        : prism_rtl::finished(Array<Text>{});
    });
}


/// `Start ColorVarsOfType, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_color_vars_of_type(ast::Type t) {
    return prism_rtl::make_rc<ColorVarsOfType>(t);
}


/// ConvertTypes: unbounded fn G, St, Text -> ((G, St))
std::tuple<G, check_types::St> convert_types(const G& g, const check_types::St& st, const Text& m) {
    auto&& _m = prelude::get(g.mods, m);
    if (prism_rtl::is_none(_m)) {
        return std::tuple{g, st};
    }
    if (prism_rtl::is_some(_m)) {
        auto&& info = prism_rtl::some_of(_m);
        auto s0 = ({
            check_types::St this_ = st;
            this_.file = info->file;
            this_;
        });
        return run_to_end(fold_job(info.tree.decls, std::tuple{g, s0}, ({
            auto info_1 = info;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<G, check_types::St>>(std::tuple<std::tuple<G, check_types::St>, ast::Decl>)>>(prism_rtl::rc([=](std::tuple<std::tuple<G, check_types::St>, ast::Decl> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto info_1_2 = info_1;
                entered(once_job([=]() {
                return ({
                    auto [gg, s] = p0;
                    auto d = p1;
                    (prism_rtl::more(prism_rtl::rc(ConvertTypeDecl(gg, s, info_1_2, d))));
                });
            }));
            });
        }));
        })));
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<G, check_types::St>> ConvertTypes::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    const auto& m = this->m;
    return ({
        auto&& _m = prelude::get(g.mods, m);
        prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{g, st})
        : prism_rtl::is_some(_m) ? ({
        auto&& info = prism_rtl::some_of(_m);
        ({
        auto s0 = ({
            check_types::St this_ = st;
            this_.file = info->file;
            this_;
        });
        fold_job(info.tree.decls, std::tuple{g, s0}, ({
        auto info_1 = info;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<G, check_types::St>>(std::tuple<std::tuple<G, check_types::St>, ast::Decl>)>>(prism_rtl::rc([=](std::tuple<std::tuple<G, check_types::St>, ast::Decl> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto info_1_2 = info_1;
            entered(once_job([=]() {
            return ({
                auto [gg, s] = p0;
                auto d = p1;
                (prism_rtl::more(prism_rtl::rc(ConvertTypeDecl(gg, s, info_1_2, d))));
            });
        }));
        });
    }));
    }))->cycle();
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ConvertTypes, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<G, check_types::St>> start_convert_types(G g, check_types::St st, Text m) {
    return prism_rtl::make_rc<ConvertTypes>(g, st, m);
}


/// ConvertDecls: unbounded fn G, St, Text -> ((G, St))
std::tuple<G, check_types::St> convert_decls(const G& g, const check_types::St& st, const Text& m) {
    auto&& _m = prelude::get(g.mods, m);
    if (prism_rtl::is_none(_m)) {
        return std::tuple{g, st};
    }
    if (prism_rtl::is_some(_m)) {
        auto&& info = prism_rtl::some_of(_m);
        auto s1 = ({
            check_types::St this_ = st;
            this_.file = info->file;
            this_;
        });
        auto [g2, s2] = run_to_end(fold_job(info.tree.decls, std::tuple{g, s1}, ({
            auto info_1 = info;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<G, check_types::St>>(std::tuple<std::tuple<G, check_types::St>, ast::Decl>)>>(prism_rtl::rc([=](std::tuple<std::tuple<G, check_types::St>, ast::Decl> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto info_1_2 = info_1;
                entered(once_job([=]() {
                return ({
                    auto [gg, s] = p0;
                    auto d = p1;
                    (prism_rtl::more(prism_rtl::rc(ConvertDecl(gg, s, info_1_2, d))));
                });
            }));
            });
        }));
        })));
        auto s3 = missing_signatures(g2, s2, info);
        return std::tuple{g2, s3};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<G, check_types::St>> ConvertDecls::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    const auto& m = this->m;
    return ({
        auto&& _m = prelude::get(g.mods, m);
        prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{g, st})
        : prism_rtl::is_some(_m) ? ({
        auto&& info = prism_rtl::some_of(_m);
        ({
        auto s1 = ({
            check_types::St this_ = st;
            this_.file = info->file;
            this_;
        });
        auto g_1 = g;
        call_value(fold_job(info.tree.decls, std::tuple{g_1, s1}, ({
        auto info_2 = info;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<G, check_types::St>>(std::tuple<std::tuple<G, check_types::St>, ast::Decl>)>>(prism_rtl::rc([=](std::tuple<std::tuple<G, check_types::St>, ast::Decl> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto info_2_3 = info_2;
            entered(once_job([=]() {
            return ({
                auto [gg, s] = p0;
                auto d = p1;
                (prism_rtl::more(prism_rtl::rc(ConvertDecl(gg, s, info_2_3, d))));
            });
        }));
        });
    }));
    })), [=](std::tuple<G, check_types::St> fold_39572) {
        return ({
            auto [g2, s2] = fold_39572;
            auto s3 = missing_signatures(g2, s2, info);
            (prism_rtl::finished(std::tuple{g2, s3}));
        });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ConvertDecls, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<G, check_types::St>> start_convert_decls(G g, check_types::St st, Text m) {
    return prism_rtl::make_rc<ConvertDecls>(g, st, m);
}


/// ConvertTypeDecl: unbounded fn G, St, ModInfo, Decl -> ((G, St))
std::tuple<G, check_types::St> convert_type_decl(const G& g, const check_types::St& st, const ModInfo& info, const ast::Decl& d) {
    auto&& _m = d.kind;
    if (prism_rtl::is<ast::DeclKind::DType>(_m)) {
        auto&& t = prism_rtl::as<ast::DeclKind::DType>(_m).a0;
        auto name = qual_key(info.name, dotted(t.name->path_));
        auto ti = or_(prelude::get(g.types, name), dummy_ty_info());
        auto cx_ = cx_of(g, info.name);
        auto params = each(t.params, [&](const ast::Ident& p_) { return p_.name; });
        auto self_ = check_types::Ty(check_types::Ty::TyCon{name, each(params, [&](const Text& p_) { return check_types::Ty(check_types::Ty::TyQ{p_}); })});
        auto&& _m = t.body;
        if (prism_rtl::is_none(_m)) {
            return std::tuple{g, st};
        }
        if (prism_rtl::is_some(_m)) {
            auto&& body = prism_rtl::some_of(_m);
            if (prism_rtl::is<ast::TypeBody::TbRecord>(body)) {
                auto&& fs = prism_rtl::as<ast::TypeBody::TbRecord>(body).a0;
                auto [fields, st2] = run_to_end(fold_job(fs, std::tuple{Array<std::tuple<Text, check_types::Ty>>{}, st}, ({
                    auto cx__1 = cx_;
                    static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, check_types::Ty>>, check_types::St>>(std::tuple<std::tuple<Array<std::tuple<Text, check_types::Ty>>, check_types::St>, ast::Field>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<std::tuple<Text, check_types::Ty>>, check_types::St>, ast::Field> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto cx__1_2 = cx__1;
                        entered(once_job([=]() {
                        return ({
                            auto [acc, s] = p0;
                            auto f = p1;
                            call_then(start_conv_type(cx__1_2, s, f.ty), [=](std::tuple<check_types::Ty, check_types::St> conv_type_40323) {
                            return ({
                                auto [ft, s2] = conv_type_40323;
                                (prism_rtl::finished(std::tuple{prelude::push(acc, std::tuple{f.name.name, ft}), s2}));
                            });
                        });
                        });
                    }));
                    });
                }));
                })));
                auto ctor = CtorInfo{.name = name, .owner = name, .params = params, .args = each(fields, [&](const std::tuple<Text, check_types::Ty>& _p0) {
                    auto&& ft = std::get<1>(_p0);
                    return ft;
                }), .fields = each(fields, [&](const std::tuple<Text, check_types::Ty>& _p0) {
                    auto&& fname = std::get<0>(_p0);
                    return fname;
                }), .ty = self_, .index = Nat(0u)};
                auto upd = ({
                    G this_ = g;
                    this_.types = insert(this_.types, name, with_body(ti, TyBody(TyBody::BRecord{fields})));
                    this_.ctors = insert(this_.ctors, name, ctor);
                    this_;
                });
                return std::tuple{upd, st2};
            }
            if (prism_rtl::is<ast::TypeBody::TbChoice>(body)) {
                auto&& cs = prism_rtl::as<ast::TypeBody::TbChoice>(body).a0;
                return conv_cases(g, st, cx_, ti, name, params, self_, cs);
            }
            if (prism_rtl::is<ast::TypeBody::TbNewtype>(body)) {
                auto&& c = prism_rtl::as<ast::TypeBody::TbNewtype>(body).a0;
                return conv_cases(g, st, cx_, ti, name, params, self_, Array(std::vector{c}));
            }
            if (prism_rtl::is<ast::TypeBody::TbUnit>(body)) {
                auto&& i = prism_rtl::as<ast::TypeBody::TbUnit>(body).a0;
                auto ctor = CtorInfo{.name = qual_key(info.name, i.name), .owner = name, .params = params, .args = Array<check_types::Ty>{}, .fields = Array<Text>{}, .ty = self_, .index = Nat(0u)};
                auto upd = ({
                    G this_ = g;
                    this_.types = insert(this_.types, name, with_body(ti, TyBody(TyBody::BChoice{Array(std::vector{std::tuple{i.name, Array<check_types::Ty>{}}})})));
                    this_.ctors = insert(this_.ctors, qual_key(info.name, i.name), ctor);
                    this_;
                });
                return std::tuple{upd, st};
            }
            if (prism_rtl::is<ast::TypeBody::TbRow>(body)) {
                auto upd = ({
                    G this_ = g;
                    this_.types = insert(this_.types, name, with_body(ti, TyBody(TyBody::BRowKind{})));
                    this_;
                });
                return std::tuple{upd, st};
            }
            if (prism_rtl::is<ast::TypeBody::TbAlias>(body)) {
                auto&& a = prism_rtl::as<ast::TypeBody::TbAlias>(body).a0;
                auto [at_, st2] = conv_type(cx_, st, a);
                auto upd = ({
                    G this_ = g;
                    this_.types = insert(this_.types, name, with_body(ti, TyBody(TyBody::BAlias{at_})));
                    this_;
                });
                return std::tuple{upd, st2};
            }
            prism_rtl::unreachable("no arm matched");
        }
        prism_rtl::unreachable("no arm matched");
    }
    {
        return std::tuple{g, st};
    }
}


prism_rtl::Turn<std::tuple<G, check_types::St>> ConvertTypeDecl::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    const auto& info = this->info;
    const auto& d = this->d;
    return ({
        auto&& _m = d.kind;
        prism_rtl::is<ast::DeclKind::DType>(_m) ? ({
        auto&& t = prism_rtl::as<ast::DeclKind::DType>(_m).a0;
        ({
        auto name = qual_key(info.name, dotted(t.name->path_));
        auto ti = or_(prelude::get(g.types, name), dummy_ty_info());
        auto cx_ = cx_of(g, info.name);
        auto params = each(t.params, [&](const ast::Ident& p_) { return p_.name; });
        auto self_ = check_types::Ty(check_types::Ty::TyCon{name, each(params, [&](const Text& p_) { return check_types::Ty(check_types::Ty::TyQ{p_}); })});
        ({
        auto&& _m = t.body;
        prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{g, st})
        : prism_rtl::is_some(_m) ? ({
        auto&& body = prism_rtl::some_of(_m);
        ({
        prism_rtl::is<ast::TypeBody::TbRecord>(body) ? ({
        auto&& fs = prism_rtl::as<ast::TypeBody::TbRecord>(body).a0;
        ({
        auto fs_1 = fs;
        auto g_2 = g;
        auto st_3 = st;
        call_value(fold_job(fs_1, std::tuple{Array<std::tuple<Text, check_types::Ty>>{}, st_3}, ({
        auto cx__4 = cx_;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, check_types::Ty>>, check_types::St>>(std::tuple<std::tuple<Array<std::tuple<Text, check_types::Ty>>, check_types::St>, ast::Field>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<std::tuple<Text, check_types::Ty>>, check_types::St>, ast::Field> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto cx__4_5 = cx__4;
            entered(once_job([=]() {
            return ({
                auto [acc, s] = p0;
                auto f = p1;
                call_then(start_conv_type(cx__4_5, s, f.ty), [=](std::tuple<check_types::Ty, check_types::St> conv_type_40323) {
                return ({
                    auto [ft, s2] = conv_type_40323;
                    (prism_rtl::finished(std::tuple{prelude::push(acc, std::tuple{f.name.name, ft}), s2}));
                });
            });
            });
        }));
        });
    }));
    })), [=](std::tuple<Array<std::tuple<Text, check_types::Ty>>, check_types::St> fold_40242) {
        return ({
            auto [fields, st2] = fold_40242;
            auto ctor = CtorInfo{.name = name, .owner = name, .params = params, .args = each(fields, [&](const std::tuple<Text, check_types::Ty>& _p0) {
                auto&& ft = std::get<1>(_p0);
                return ft;
            }), .fields = each(fields, [&](const std::tuple<Text, check_types::Ty>& _p0) {
                auto&& fname = std::get<0>(_p0);
                return fname;
            }), .ty = self_, .index = Nat(0u)};
            auto upd = ({
                G this_ = g_2;
                this_.types = insert(this_.types, name, with_body(ti, TyBody(TyBody::BRecord{fields})));
                this_.ctors = insert(this_.ctors, name, ctor);
                this_;
            });
            (prism_rtl::finished(std::tuple{upd, st2}));
        });
    });
    });
    })
        : prism_rtl::is<ast::TypeBody::TbChoice>(body) ? ({
        auto&& cs = prism_rtl::as<ast::TypeBody::TbChoice>(body).a0;
        prism_rtl::more(prism_rtl::rc(ConvCases(g, st, cx_, ti, name, params, self_, cs)));
    })
        : prism_rtl::is<ast::TypeBody::TbNewtype>(body) ? ({
        auto&& c = prism_rtl::as<ast::TypeBody::TbNewtype>(body).a0;
        prism_rtl::more(prism_rtl::rc(ConvCases(g, st, cx_, ti, name, params, self_, Array(std::vector{c}))));
    })
        : prism_rtl::is<ast::TypeBody::TbUnit>(body) ? ({
        auto&& i = prism_rtl::as<ast::TypeBody::TbUnit>(body).a0;
        ({
        auto ctor = CtorInfo{.name = qual_key(info.name, i.name), .owner = name, .params = params, .args = Array<check_types::Ty>{}, .fields = Array<Text>{}, .ty = self_, .index = Nat(0u)};
        auto upd = ({
            G this_ = g;
            this_.types = insert(this_.types, name, with_body(ti, TyBody(TyBody::BChoice{Array(std::vector{std::tuple{i.name, Array<check_types::Ty>{}}})})));
            this_.ctors = insert(this_.ctors, qual_key(info.name, i.name), ctor);
            this_;
        });
        (prism_rtl::finished(std::tuple{upd, st}));
    });
    })
        : prism_rtl::is<ast::TypeBody::TbRow>(body) ? ({
        auto upd = ({
            G this_ = g;
            this_.types = insert(this_.types, name, with_body(ti, TyBody(TyBody::BRowKind{})));
            this_;
        });
        (prism_rtl::finished(std::tuple{upd, st}));
    })
        : prism_rtl::is<ast::TypeBody::TbAlias>(body) ? ({
        auto&& a = prism_rtl::as<ast::TypeBody::TbAlias>(body).a0;
        ({
        auto a_1 = a;
        auto g_2 = g;
        auto st_3 = st;
        call_then(start_conv_type(cx_, st_3, a_1), [=](std::tuple<check_types::Ty, check_types::St> conv_type_41657) {
        return ({
            auto [at_, st2] = conv_type_41657;
            auto upd = ({
                G this_ = g_2;
                this_.types = insert(this_.types, name, with_body(ti, TyBody(TyBody::BAlias{at_})));
                this_;
            });
            (prism_rtl::finished(std::tuple{upd, st2}));
        });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    });
    })
        : prism_rtl::finished(std::tuple{g, st});
    });
}


/// `Start ConvertTypeDecl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<G, check_types::St>> start_convert_type_decl(G g, check_types::St st, ModInfo info, ast::Decl d) {
    return prism_rtl::make_rc<ConvertTypeDecl>(g, st, info, d);
}


/// WithBody: fn TyInfo, TyBody -> TyInfo
TyInfo with_body(const TyInfo& ti, const TyBody& b) {
    TyInfo this_ = ti;
    this_.body = b;
    return this_;
}


/// ConvCases: unbounded fn G, St, Cx, TyInfo, Text, [Text], Ty, [Case] -> ((G, St))
std::tuple<G, check_types::St> conv_cases(const G& g, const check_types::St& st, const Cx_& cx_, const TyInfo& ti, const Text& name, const Array<Text>& params, const check_types::Ty& self_, const Array<ast::Case_>& cs) {
    auto [cases, st2] = run_to_end(fold_job(cs, std::tuple{Array<std::tuple<Text, Array<check_types::Ty>>>{}, st}, ({
        auto cx__1 = cx_;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, Array<check_types::Ty>>>, check_types::St>>(std::tuple<std::tuple<Array<std::tuple<Text, Array<check_types::Ty>>>, check_types::St>, ast::Case_>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<std::tuple<Text, Array<check_types::Ty>>>, check_types::St>, ast::Case_> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto cx__1_2 = cx__1;
            entered(once_job([=]() {
            return ({
                auto [acc, s] = p0;
                auto c = p1;
                ({
                auto s1 = ({
                    __label__ _done;
                    prism_rtl::Slot<check_types::St> _v;
                    auto&& _m = c.indexed;
                    if (prism_rtl::is_some(_m)) {
                        _v.set(check_types::err(s, Text::lit("unsupported"), c.span, Text::lit("this checker does not implement indexed choices for user types")));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(s);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                call_then(start_conv_types(cx__1_2, s1, c->args), [=](std::tuple<Array<check_types::Ty>, check_types::St> conv_types_42344) {
                return ({
                    auto [args, s2] = conv_types_42344;
                    (prism_rtl::finished(std::tuple{prelude::push(acc, std::tuple{sname_key(c.name), args}), s2}));
                });
            });
            });
            });
        }));
        });
    }));
    })));
    auto g2 = fold(check_errors::range0(len(cases)), g, [&](const G& gg, const Nat& i) {
        return ({
            auto [cn, args] = or_(index(cases, i), std::tuple{Text::lit(""), Array<check_types::Ty>{}});
            auto qk = qual_key(ti.home, cn);
            ({
            G this_ = gg;
            this_.ctors = insert(this_.ctors, qk, CtorInfo{.name = qk, .owner = name, .params = params, .args = args, .fields = Array<Text>{}, .ty = self_, .index = i});
            this_;
        });
        });
    });
    auto upd = ({
        G this_ = g2;
        this_.types = insert(this_.types, name, with_body(ti, TyBody(TyBody::BChoice{cases})));
        this_;
    });
    return std::tuple{upd, st2};
}


prism_rtl::Turn<std::tuple<G, check_types::St>> ConvCases::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    const auto& cx_ = this->cx_;
    const auto& ti = this->ti;
    const auto& name = this->name;
    const auto& params = this->params;
    const auto& self_ = this->self_;
    const auto& cs = this->cs;
    auto cs_1 = cs;
    auto cx__2 = cx_;
    auto g_3 = g;
    auto name_4 = name;
    auto params_5 = params;
    auto self__6 = self_;
    auto st_7 = st;
    auto ti_8 = ti;
    return call_value(fold_job(cs_1, std::tuple{Array<std::tuple<Text, Array<check_types::Ty>>>{}, st_7}, ({
        auto cx__2_9 = cx__2;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, Array<check_types::Ty>>>, check_types::St>>(std::tuple<std::tuple<Array<std::tuple<Text, Array<check_types::Ty>>>, check_types::St>, ast::Case_>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<std::tuple<Text, Array<check_types::Ty>>>, check_types::St>, ast::Case_> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto cx__2_9_9 = cx__2_9;
            entered(once_job([=]() {
            return ({
                auto [acc, s] = p0;
                auto c = p1;
                ({
                auto s1 = ({
                    __label__ _done;
                    prism_rtl::Slot<check_types::St> _v;
                    auto&& _m = c.indexed;
                    if (prism_rtl::is_some(_m)) {
                        _v.set(check_types::err(s, Text::lit("unsupported"), c.span, Text::lit("this checker does not implement indexed choices for user types")));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(s);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                call_then(start_conv_types(cx__2_9_9, s1, c->args), [=](std::tuple<Array<check_types::Ty>, check_types::St> conv_types_42344) {
                return ({
                    auto [args, s2] = conv_types_42344;
                    (prism_rtl::finished(std::tuple{prelude::push(acc, std::tuple{sname_key(c.name), args}), s2}));
                });
            });
            });
            });
        }));
        });
    }));
    })), [=](std::tuple<Array<std::tuple<Text, Array<check_types::Ty>>>, check_types::St> fold_42106) {
        return ({
            auto [cases, st2] = fold_42106;
            auto g2 = fold(check_errors::range0(len(cases)), g_3, [&](const G& gg, const Nat& i) {
                return ({
                    auto [cn, args] = or_(index(cases, i), std::tuple{Text::lit(""), Array<check_types::Ty>{}});
                    auto qk = qual_key(ti_8.home, cn);
                    ({
                    G this_ = gg;
                    this_.ctors = insert(this_.ctors, qk, CtorInfo{.name = qk, .owner = name_4, .params = params_5, .args = args, .fields = Array<Text>{}, .ty = self__6, .index = i});
                    this_;
                });
                });
            });
            auto upd = ({
                G this_ = g2;
                this_.types = insert(this_.types, name_4, with_body(ti_8, TyBody(TyBody::BChoice{cases})));
                this_;
            });
            (prism_rtl::finished(std::tuple{upd, st2}));
        });
    });
}


/// `Start ConvCases, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<G, check_types::St>> start_conv_cases(G g, check_types::St st, Cx_ cx_, TyInfo ti, Text name, Array<Text> params, check_types::Ty self_, Array<ast::Case_> cs) {
    return prism_rtl::make_rc<ConvCases>(g, st, cx_, ti, name, params, self_, cs);
}


/// ConvertDecl: unbounded fn G, St, ModInfo, Decl -> ((G, St))
std::tuple<G, check_types::St> convert_decl(const G& g, const check_types::St& st, const ModInfo& info, const ast::Decl& d) {
    auto&& _m = d.kind;
    if (prism_rtl::is<ast::DeclKind::DSignature>(_m)) {
        auto&& s = prism_rtl::as<ast::DeclKind::DSignature>(_m).a0;
        auto qk = qual_key(info.name, def_name_text(s.name));
        auto cx_ = cx_of(g, info.name);
        auto [sc, st1] = sig_scheme(cx_, st, s.ty, s.bounds);
        auto st2 = lens_check(st1, def_name_text(s.name), s.ty, def_name_span(s.name));
        auto st3 = check_mark_function(st2, def_name_text(s.name), sc.ty, def_name_span(s.name));
        return has_key(g.vals, qk)
            ? std::tuple{g, check_types::err(st3, Text::lit("collision"), d.span, prism_rtl::cat("a second signature for `", def_name_text(s.name), "`"))}
            : ({
            auto upd = ({
                G this_ = g;
                this_.vals = insert(this_.vals, qk, ValInfo{.qk = qk, .scheme = sc, .sort = Text::lit("fn"), .has_sig = true, .home = info.name, .file = info->file, .span = d.span});
                this_;
            });
            std::tuple{upd, st3};
        });
    }
    if (prism_rtl::is<ast::DeclKind::DFn>(_m)) {
        auto&& f = prism_rtl::as<ast::DeclKind::DFn>(_m).a0;
        auto qk = qual_key(info.name, def_name_text(f.name));
        return std::tuple{add_clause(g, info, qk, def_name_text(f.name), f, d.span, st), st};
    }
    if (prism_rtl::is<ast::DeclKind::DLet>(_m)) {
        auto&& l = prism_rtl::as<ast::DeclKind::DLet>(_m).a0;
        auto names = pattern_names(l.pattern);
        auto qk = qual_key(info.name, or_(index(names, Nat(0u)), Text::lit("")));
        auto def = Def{.qk = qk, .name = or_(index(names, Nat(0u)), Text::lit("")), .home = info.name, .file = info->file, .span = d.span, .body = DefBody(DefBody::DbLet{l})};
        auto upd = ({
            G this_ = g;
            this_.defs = prelude::push(this_.defs, def);
            this_;
        });
        return std::tuple{upd, st};
    }
    if (prism_rtl::is<ast::DeclKind::DWidget>(_m)) {
        auto&& w = prism_rtl::as<ast::DeclKind::DWidget>(_m).a0;
        auto qk = qual_key(info.name, sname_key(w.name));
        auto def = Def{.qk = qk, .name = sname_key(w.name), .home = info.name, .file = info->file, .span = d.span, .body = DefBody(DefBody::DbWidget{w})};
        auto upd = ({
            G this_ = g;
            this_.defs = prelude::push(this_.defs, def);
            this_;
        });
        return std::tuple{upd, st};
    }
    if (prism_rtl::is<ast::DeclKind::DTag>(_m)) {
        auto&& t = prism_rtl::as<ast::DeclKind::DTag>(_m).a0;
        return conv_tag(g, st, info, t, d.span);
    }
    if (prism_rtl::is<ast::DeclKind::DTrait>(_m)) {
        auto&& t = prism_rtl::as<ast::DeclKind::DTrait>(_m).a0;
        return conv_trait(g, st, info, t, d.span);
    }
    if (prism_rtl::is<ast::DeclKind::DImpl>(_m)) {
        auto&& i = prism_rtl::as<ast::DeclKind::DImpl>(_m).a0;
        return conv_impl(g, st, info, i, d.span);
    }
    if (prism_rtl::is<ast::DeclKind::DCheck>(_m)) {
        auto&& c = prism_rtl::as<ast::DeclKind::DCheck>(_m).a0;
        auto upd = ({
            G this_ = g;
            this_.defs = prelude::push(this_.defs, Def{.qk = qual_key(info.name, prism_rtl::cat("check ", c.name.name)), .name = c.name.name, .home = info.name, .file = info->file, .span = d.span, .body = DefBody(DefBody::DbCheck{c})});
            this_;
        });
        return std::tuple{upd, st};
    }
    if (prism_rtl::is<ast::DeclKind::DTest>(_m)) {
        auto&& t = prism_rtl::as<ast::DeclKind::DTest>(_m).a0;
        auto upd = ({
            G this_ = g;
            this_.defs = prelude::push(this_.defs, Def{.qk = qual_key(info.name, prism_rtl::cat("test ", t.name.name)), .name = t.name.name, .home = info.name, .file = info->file, .span = d.span, .body = DefBody(DefBody::DbTest{t})});
            this_;
        });
        return std::tuple{upd, st};
    }
    if (prism_rtl::is<ast::DeclKind::DStmt>(_m)) {
        auto&& s = prism_rtl::as<ast::DeclKind::DStmt>(_m).a0;
        auto&& _m = s.kind;
        if (prism_rtl::is<ast::StmtKind::SEmit>(_m)) {
            return std::tuple{g, st};
        }
        {
            return std::tuple{g, check_types::err(st, Text::lit("unsupported"), d.span, Text::lit("a statement at the top of a file: nothing at top level is built"))};
        }
    }
    {
        return std::tuple{g, st};
    }
}


prism_rtl::Turn<std::tuple<G, check_types::St>> ConvertDecl::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    const auto& info = this->info;
    const auto& d = this->d;
    return ({
        auto&& _m = d.kind;
        prism_rtl::is<ast::DeclKind::DSignature>(_m) ? ({
        auto&& s = prism_rtl::as<ast::DeclKind::DSignature>(_m).a0;
        ({
        auto qk = qual_key(info.name, def_name_text(s.name));
        auto cx_ = cx_of(g, info.name);
        auto d_1 = d;
        auto g_2 = g;
        auto info_3 = info;
        auto s_4 = s;
        auto st_5 = st;
        call_then(start_sig_scheme(cx_, st_5, s_4.ty, s_4.bounds), [=](std::tuple<check_types::Scheme, check_types::St> sig_scheme_43075) {
        return ({
            auto [sc, st1] = sig_scheme_43075;
            auto st2 = lens_check(st1, def_name_text(s_4.name), s_4.ty, def_name_span(s_4.name));
            call_then(start_check_mark_function(st2, def_name_text(s_4.name), sc.ty, def_name_span(s_4.name)), [=](check_types::St check_mark_function_43208) {
            return ({
                auto st3 = check_mark_function_43208;
                has_key(g_2.vals, qk)
                ? prism_rtl::finished(std::tuple{g_2, check_types::err(st3, Text::lit("collision"), d_1.span, prism_rtl::cat("a second signature for `", def_name_text(s_4.name), "`"))})
                : ({
                auto upd = ({
                    G this_ = g_2;
                    this_.vals = insert(this_.vals, qk, ValInfo{.qk = qk, .scheme = sc, .sort = Text::lit("fn"), .has_sig = true, .home = info_3.name, .file = info_3->file, .span = d_1.span});
                    this_;
                });
                (prism_rtl::finished(std::tuple{upd, st3}));
            });
            });
        });
        });
    });
    });
    })
        : prism_rtl::is<ast::DeclKind::DFn>(_m) ? ({
        auto&& f = prism_rtl::as<ast::DeclKind::DFn>(_m).a0;
        ({
        auto qk = qual_key(info.name, def_name_text(f.name));
        (prism_rtl::finished(std::tuple{add_clause(g, info, qk, def_name_text(f.name), f, d.span, st), st}));
    });
    })
        : prism_rtl::is<ast::DeclKind::DLet>(_m) ? ({
        auto&& l = prism_rtl::as<ast::DeclKind::DLet>(_m).a0;
        ({
        auto d_1 = d;
        auto g_2 = g;
        auto info_3 = info;
        auto l_4 = l;
        auto st_5 = st;
        call_then(start_pattern_names(l_4.pattern), [=](Array<Text> pattern_names_43788) {
        return ({
            auto names = pattern_names_43788;
            auto qk = qual_key(info_3.name, or_(index(names, Nat(0u)), Text::lit("")));
            auto def = Def{.qk = qk, .name = or_(index(names, Nat(0u)), Text::lit("")), .home = info_3.name, .file = info_3->file, .span = d_1.span, .body = DefBody(DefBody::DbLet{l_4})};
            auto upd = ({
                G this_ = g_2;
                this_.defs = prelude::push(this_.defs, def);
                this_;
            });
            (prism_rtl::finished(std::tuple{upd, st_5}));
        });
    });
    });
    })
        : prism_rtl::is<ast::DeclKind::DWidget>(_m) ? ({
        auto&& w = prism_rtl::as<ast::DeclKind::DWidget>(_m).a0;
        ({
        auto qk = qual_key(info.name, sname_key(w.name));
        auto def = Def{.qk = qk, .name = sname_key(w.name), .home = info.name, .file = info->file, .span = d.span, .body = DefBody(DefBody::DbWidget{w})};
        auto upd = ({
            G this_ = g;
            this_.defs = prelude::push(this_.defs, def);
            this_;
        });
        (prism_rtl::finished(std::tuple{upd, st}));
    });
    })
        : prism_rtl::is<ast::DeclKind::DTag>(_m) ? ({
        auto&& t = prism_rtl::as<ast::DeclKind::DTag>(_m).a0;
        prism_rtl::more(prism_rtl::rc(ConvTag(g, st, info, t, d.span)));
    })
        : prism_rtl::is<ast::DeclKind::DTrait>(_m) ? ({
        auto&& t = prism_rtl::as<ast::DeclKind::DTrait>(_m).a0;
        prism_rtl::more(prism_rtl::rc(ConvTrait(g, st, info, t, d.span)));
    })
        : prism_rtl::is<ast::DeclKind::DImpl>(_m) ? ({
        auto&& i = prism_rtl::as<ast::DeclKind::DImpl>(_m).a0;
        prism_rtl::more(prism_rtl::rc(ConvImpl(g, st, info, i, d.span)));
    })
        : prism_rtl::is<ast::DeclKind::DCheck>(_m) ? ({
        auto&& c = prism_rtl::as<ast::DeclKind::DCheck>(_m).a0;
        ({
        auto upd = ({
            G this_ = g;
            this_.defs = prelude::push(this_.defs, Def{.qk = qual_key(info.name, prism_rtl::cat("check ", c.name.name)), .name = c.name.name, .home = info.name, .file = info->file, .span = d.span, .body = DefBody(DefBody::DbCheck{c})});
            this_;
        });
        (prism_rtl::finished(std::tuple{upd, st}));
    });
    })
        : prism_rtl::is<ast::DeclKind::DTest>(_m) ? ({
        auto&& t = prism_rtl::as<ast::DeclKind::DTest>(_m).a0;
        ({
        auto upd = ({
            G this_ = g;
            this_.defs = prelude::push(this_.defs, Def{.qk = qual_key(info.name, prism_rtl::cat("test ", t.name.name)), .name = t.name.name, .home = info.name, .file = info->file, .span = d.span, .body = DefBody(DefBody::DbTest{t})});
            this_;
        });
        (prism_rtl::finished(std::tuple{upd, st}));
    });
    })
        : prism_rtl::is<ast::DeclKind::DStmt>(_m) ? ({
        auto&& s = prism_rtl::as<ast::DeclKind::DStmt>(_m).a0;
        ({
        auto&& _m = s.kind;
        prism_rtl::is<ast::StmtKind::SEmit>(_m) ? prism_rtl::finished(std::tuple{g, st})
        : prism_rtl::finished(std::tuple{g, check_types::err(st, Text::lit("unsupported"), d.span, Text::lit("a statement at the top of a file: nothing at top level is built"))});
    });
    })
        : prism_rtl::finished(std::tuple{g, st});
    });
}

}  // namespace crate::check_env
