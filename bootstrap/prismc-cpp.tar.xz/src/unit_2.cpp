// The module `Check`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <check/module.hpp>
#include <check/typed/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>

// The module `Check`, from `target/bootstrap/cpp-src/prismc/check/mod.prism`.
namespace crate::check {

void Report_::show(Printer& p) const {
    p.record("Report", {{"text", text_p}, {"errors", errors_p}, {"rootRow", root_row_p}, {"typed", typed_p}});
}

Pod Report_::to_pod() const {
    return Pod::record("Report", {{"text", prism_rtl::to_pod(text_p)}, {"errors", prism_rtl::to_pod(errors_p)}, {"rootRow", prism_rtl::to_pod(root_row_p)}, {"typed", prism_rtl::to_pod(typed_p)}});
}

Result<Report_> Report_::from_pod(const Pod& whole) {
    return Report_{.text_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "text")))), .errors_p = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "errors")))), .root_row_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "rootRow")))), .typed_p = TRY(prism_rtl::from_pod<crate::check::typed::TProgram>(TRY(crate::prelude::field(whole, "typed"))))};
}


/// CheckProgram: unbounded fn [Src], [Module], [Text], Nat, Bool, Bool, [CDiag] -> Report
Report_ check_program_f(const Array<crate::check::errors::Src>& srcs_p0, const Array<crate::syntax::Module>& trees_p1, const Array<Text>& world_p2, const Nat& shown_p3, const bool& recording_p4, const bool& unused_p5, const Array<crate::check::errors::CDiag>& pre_p6) {
    auto [g0a_ph, stb_pi] = crate::check::env::build_g_f(srcs_p0, trees_p1);
    auto g0_p7 = ({
        crate::check::env::G this_ = g0a_ph;
        this_.prelude_from_p = shown_p3;
        (std::move(this_));
    });
    auto st0_p8 = ({
        crate::check::types::St this_ = stb_pi;
        this_.recording_p = recording_p4;
        (std::move(this_));
    });
    auto [g1_pj, st1_pk] = top_lets_f(g0_p7, st0_p8);
    auto [failed_pr, st2_ps] = crate::prelude::run_to_end(crate::prelude::fold_job(prism_rtl::deref(g1_pj).defs_p, std::tuple{Array<Text>{}, st1_pk}, ({
        auto g1_pjx = g1_pj;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, crate::check::types::St>>(std::tuple<std::tuple<Array<Text>, crate::check::types::St>, crate::check::env::Def>)>>(prism_rtl::rc([=, g1_pjx = std::move(g1_pjx)](std::tuple<std::tuple<Array<Text>, crate::check::types::St>, crate::check::env::Def> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g1_pjxy = g1_pjx;
            (crate::prelude::entered(crate::prelude::once_job([=, g1_pjxy = std::move(g1_pjxy)]() {
            return ({
                auto [bad_pl, s_pm] = p0;
                auto d_pn = p1;
                ({
                auto before_po = crate::prelude::len(prism_rtl::deref(s_pm).diags_p);
                (crate::prelude::call_then(start_check_def_f(g1_pjxy, s_pm, d_pn), [=, before_po = std::move(before_po)](crate::check::types::St check_def_f_2629) {
                return ({
                    auto s2_pp = check_def_f_2629;
                    auto bad2_pq = crate::prelude::len(prism_rtl::deref(s2_pp).diags_p) > before_po
                        ? crate::prelude::push(bad_pl, prism_rtl::deref(crate::check::shrink::types::own_key_f(d_pn)).qk_p)
                        : bad_pl;
                    (prism_rtl::finished(std::tuple{bad2_pq, s2_pp}));
                });
            }));
            });
            });
        })));
        });
    }));
    })));
    auto st2b_p9 = ({
        crate::check::types::St this_ = st2_ps;
        this_.level_p = Nat(0u);
        (std::move(this_));
    });
    auto st3_pa = crate::check::env::traits::default_wants_f(g1_pj, st2b_p9, Array<std::tuple<Text, Text>>{});
    auto good_pb = crate::prelude::filter(prism_rtl::deref(g1_pj).defs_p, [&](const crate::check::env::Def& d_pt) { return !crate::check::types::has_text_f(failed_pr, prism_rtl::deref(crate::check::shrink::types::own_key_f(d_pt)).qk_p); });
    auto [st4_pu, refs_pv] = crate::check::shrink::shrink_check_f(g1_pj, st3_pa, good_pb);
    auto [root_row_p10, st5_p11] = root_row_f(g1_pj, st4_pu, world_p2);
    auto warnings_pc = unused_p5
        ? crate::check::shrink::unused_defs_f(good_pb, refs_pv, shown_p3)
        : Array<crate::check::errors::CDiag>{};
    auto reached_pd = crate::check::shrink::test_only_reached_f(srcs_p0, prism_rtl::deref(g1_pj).defs_p, refs_pv);
    auto diags_pe = crate::check::errors::sort_diags_f(crate::prelude::append(crate::prelude::append(crate::prelude::append(crate::prelude::filter(prism_rtl::deref(st5_p11).diags_p, [&](const crate::check::errors::CDiag& d_p12) { return prism_rtl::deref(d_p12).file_p < shown_p3; }), warnings_pc), pre_p6), reached_pd));
    auto text_pf = crate::prelude::concat(crate::prelude::each(diags_pe, [&](const crate::check::errors::CDiag& d_p13) { return crate::check::errors::render_cdiag_f(srcs_p0, d_p13); }));
    auto typed_pg = recording_p4
        ? typed_of_f(g1_pj, st5_p11, shown_p3)
        : crate::check::typed::empty_typed_p();
    return Report_{.text_p = text_pf, .errors_p = crate::prelude::len(crate::prelude::filter(diags_pe, [&](const crate::check::errors::CDiag& d_p14) { return !crate::check::errors::is_warning_f(d_p14); })), .root_row_p = root_row_p10, .typed_p = typed_pg};
}


prism_rtl::Turn<Report_> CheckProgram::cycle() const {
    const auto& srcs_p0 = this->srcs_p0;
    const auto& trees_p1 = this->trees_p1;
    const auto& world_p2 = this->world_p2;
    const auto& shown_p3 = this->shown_p3;
    const auto& recording_p4 = this->recording_p4;
    const auto& unused_p5 = this->unused_p5;
    const auto& pre_p6 = this->pre_p6;
    auto pre_p6x = pre_p6;
    auto recording_p4x = prism_rtl::deref(recording_p4);
    auto shown_p3x = shown_p3;
    auto srcs_p0x = srcs_p0;
    auto trees_p1x = trees_p1;
    auto unused_p5x = prism_rtl::deref(unused_p5);
    auto world_p2x = world_p2;
    return crate::prelude::call_then(crate::check::env::start_build_g_f(srcs_p0x, trees_p1x), [=](std::tuple<crate::check::env::G, crate::check::types::St> build_g_f_2188) {
        return ({
            auto [g0a_ph, stb_pi] = build_g_f_2188;
            auto g0_p7 = ({
                crate::check::env::G this_ = g0a_ph;
                this_.prelude_from_p = shown_p3x;
                (std::move(this_));
            });
            auto st0_p8 = ({
                crate::check::types::St this_ = stb_pi;
                this_.recording_p = recording_p4x;
                (std::move(this_));
            });
            (crate::prelude::call_then(start_top_lets_f(g0_p7, st0_p8), [=](std::tuple<crate::check::env::G, crate::check::types::St> top_lets_f_2491) {
            return ({
                auto [g1_pj, st1_pk] = top_lets_f_2491;
                (crate::prelude::call_value(crate::prelude::fold_job(prism_rtl::deref(g1_pj).defs_p, std::tuple{Array<Text>{}, st1_pk}, ({
                auto g1_pjx = g1_pj;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, crate::check::types::St>>(std::tuple<std::tuple<Array<Text>, crate::check::types::St>, crate::check::env::Def>)>>(prism_rtl::rc([=, g1_pjx = std::move(g1_pjx)](std::tuple<std::tuple<Array<Text>, crate::check::types::St>, crate::check::env::Def> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto g1_pjxy = g1_pjx;
                    (crate::prelude::entered(crate::prelude::once_job([=, g1_pjxy = std::move(g1_pjxy)]() {
                    return ({
                        auto [bad_pl, s_pm] = p0;
                        auto d_pn = p1;
                        ({
                        auto before_po = crate::prelude::len(prism_rtl::deref(s_pm).diags_p);
                        (crate::prelude::call_then(start_check_def_f(g1_pjxy, s_pm, d_pn), [=, before_po = std::move(before_po)](crate::check::types::St check_def_f_2629) {
                        return ({
                            auto s2_pp = check_def_f_2629;
                            auto bad2_pq = crate::prelude::len(prism_rtl::deref(s2_pp).diags_p) > before_po
                                ? crate::prelude::push(bad_pl, prism_rtl::deref(crate::check::shrink::types::own_key_f(d_pn)).qk_p)
                                : bad_pl;
                            (prism_rtl::finished(std::tuple{bad2_pq, s2_pp}));
                        });
                    }));
                    });
                    });
                })));
                });
            }));
            })), [=](std::tuple<Array<Text>, crate::check::types::St> fold_2533) {
                return ({
                    auto [failed_pr, st2_ps] = fold_2533;
                    auto st2b_p9 = ({
                        crate::check::types::St this_ = st2_ps;
                        this_.level_p = Nat(0u);
                        (std::move(this_));
                    });
                    (crate::prelude::call_then(crate::check::env::traits::start_default_wants_f(g1_pj, st2b_p9, Array<std::tuple<Text, Text>>{}), [=](crate::check::types::St default_wants_f_2812) {
                    return ({
                        auto st3_pa = default_wants_f_2812;
                        auto good_pb = crate::prelude::filter(prism_rtl::deref(g1_pj).defs_p, [&](const crate::check::env::Def& d_pt) { return !crate::check::types::has_text_f(failed_pr, prism_rtl::deref(crate::check::shrink::types::own_key_f(d_pt)).qk_p); });
                        (crate::prelude::call_then(crate::check::shrink::start_shrink_check_f(g1_pj, st3_pa, good_pb), [=](std::tuple<crate::check::types::St, Array<std::tuple<Text, Array<Text>>>> shrink_check_f_3083) {
                        return ({
                            auto [st4_pu, refs_pv] = shrink_check_f_3083;
                            (crate::prelude::call_then(start_root_row_f(g1_pj, st4_pu, world_p2x), [=](std::tuple<Text, crate::check::types::St> root_row_f_3136) {
                            return ({
                                auto [root_row_p10, st5_p11] = root_row_f_3136;
                                auto warnings_pc = unused_p5x
                                    ? crate::check::shrink::unused_defs_f(good_pb, refs_pv, shown_p3x)
                                    : Array<crate::check::errors::CDiag>{};
                                auto reached_pd = crate::check::shrink::test_only_reached_f(srcs_p0x, prism_rtl::deref(g1_pj).defs_p, refs_pv);
                                auto diags_pe = crate::check::errors::sort_diags_f(crate::prelude::append(crate::prelude::append(crate::prelude::append(crate::prelude::filter(prism_rtl::deref(st5_p11).diags_p, [&](const crate::check::errors::CDiag& d_p12) { return prism_rtl::deref(d_p12).file_p < shown_p3x; }), warnings_pc), pre_p6x), reached_pd));
                                auto text_pf = crate::prelude::concat(crate::prelude::each(diags_pe, [&](const crate::check::errors::CDiag& d_p13) { return crate::check::errors::render_cdiag_f(srcs_p0x, d_p13); }));
                                auto typed_pg = recording_p4x
                                    ? typed_of_f(g1_pj, st5_p11, shown_p3x)
                                    : crate::check::typed::empty_typed_p();
                                (prism_rtl::finished(Report_{.text_p = text_pf, .errors_p = crate::prelude::len(crate::prelude::filter(diags_pe, [&](const crate::check::errors::CDiag& d_p14) { return !crate::check::errors::is_warning_f(d_p14); })), .root_row_p = root_row_p10, .typed_p = typed_pg}));
                            });
                        }));
                        });
                    }));
                    });
                }));
                });
            }));
            });
        }));
        });
    });
}


/// `Start CheckProgram, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Report_> start_check_program_f(Array<crate::check::errors::Src> srcs_p0, Array<crate::syntax::Module> trees_p1, Array<Text> world_p2, Nat shown_p3, bool recording_p4, bool unused_p5, Array<crate::check::errors::CDiag> pre_p6) {
    return prism_rtl::make_rc<CheckProgram>(srcs_p0, trees_p1, world_p2, shown_p3, recording_p4, unused_p5, pre_p6);
}


/// TypedOf: unbounded fn G, St, Nat -> TProgram
crate::check::typed::TProgram typed_of_f(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const Nat& shown_p2) {
    auto z_p3 = crate::check::types::recording::zonk_typed_f(st_p1);
    auto vals_p4 = crate::prelude::filter(crate::prelude::values(g_p0.vals_p), [&](const crate::check::env::ValInfo& v_p5) { return ((prism_rtl::deref(v_p5).file_p < shown_p2) && (prism_rtl::deref(v_p5).sort_p != Text::lit("builtin"))) && (prism_rtl::deref(crate::prelude::or_(crate::prelude::get(g_p0.mods_p, prism_rtl::deref(v_p5).home_p), crate::check::env::reading::dummy_mod_p())).file_p == prism_rtl::deref(v_p5).file_p); });
    crate::check::typed::TProgram this_ = z_p3;
    this_.defs_p = crate::prelude::run_to_end(crate::prelude::each_job(vals_p4, ({
        auto st_p1x = st_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::typed::DefNote>(crate::check::env::ValInfo)>>(prism_rtl::rc([=, st_p1x = std::move(st_p1x)](crate::check::env::ValInfo p0) {
        return ({
            auto st_p1xy = st_p1x;
            (crate::prelude::entered(crate::prelude::once_job([=, st_p1xy = std::move(st_p1xy)]() {
            return ({
                auto v_p6 = p0;
                (crate::prelude::call_then(start_zonk_scheme_f(st_p1xy, prism_rtl::deref(v_p6).scheme_p), [=](crate::check::types::Scheme zonk_scheme_f_4112) { return prism_rtl::finished(crate::check::typed::DefNote{.at_p = crate::check::typed::SrcAt{.file_p = prism_rtl::deref(v_p6).file_p, .span_p = prism_rtl::deref(v_p6).span_p}, .name_p = prism_rtl::deref(v_p6).qk_p, .scheme_p = zonk_scheme_f_4112}); }));
            });
        })));
        });
    })));
    })));
    return this_;
}


prism_rtl::Turn<crate::check::typed::TProgram> TypedOf::cycle() const {
    const auto& g_p0 = this->g_p0;
    const auto& st_p1 = this->st_p1;
    const auto& shown_p2 = this->shown_p2;
    auto g_p0x = g_p0;
    auto shown_p2x = shown_p2;
    auto st_p1x = st_p1;
    return crate::prelude::call_then(crate::check::types::recording::start_zonk_typed_f(st_p1x), [=](crate::check::typed::TProgram zonk_typed_f_3855) {
        return ({
            auto z_p3 = zonk_typed_f_3855;
            auto vals_p4 = crate::prelude::filter(crate::prelude::values(prism_rtl::deref(g_p0x).vals_p), [&](const crate::check::env::ValInfo& v_p5) { return ((prism_rtl::deref(v_p5).file_p < shown_p2x) && (prism_rtl::deref(v_p5).sort_p != Text::lit("builtin"))) && (prism_rtl::deref(crate::prelude::or_(crate::prelude::get(prism_rtl::deref(g_p0x).mods_p, prism_rtl::deref(v_p5).home_p), crate::check::env::reading::dummy_mod_p())).file_p == prism_rtl::deref(v_p5).file_p); });
            (prism_rtl::finished(({
            crate::check::typed::TProgram this_ = z_p3;
            this_.defs_p = crate::prelude::run_to_end(crate::prelude::each_job(vals_p4, ({
                auto st_p1xx = st_p1x;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::typed::DefNote>(crate::check::env::ValInfo)>>(prism_rtl::rc([=, st_p1xx = std::move(st_p1xx)](crate::check::env::ValInfo p0) {
                return ({
                    auto st_p1xxy = st_p1xx;
                    (crate::prelude::entered(crate::prelude::once_job([=, st_p1xxy = std::move(st_p1xxy)]() {
                    return ({
                        auto v_p6 = p0;
                        (crate::prelude::call_then(start_zonk_scheme_f(st_p1xxy, prism_rtl::deref(v_p6).scheme_p), [=](crate::check::types::Scheme zonk_scheme_f_4112) { return prism_rtl::finished(crate::check::typed::DefNote{.at_p = crate::check::typed::SrcAt{.file_p = prism_rtl::deref(v_p6).file_p, .span_p = prism_rtl::deref(v_p6).span_p}, .name_p = prism_rtl::deref(v_p6).qk_p, .scheme_p = zonk_scheme_f_4112}); }));
                    });
                })));
                });
            })));
            })));
            (std::move(this_));
        })));
        });
    });
}


/// `Start TypedOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::typed::TProgram> start_typed_of_f(crate::check::env::G g_p0, crate::check::types::St st_p1, Nat shown_p2) {
    return prism_rtl::make_rc<TypedOf>(g_p0, st_p1, shown_p2);
}


/// ZonkScheme: unbounded fn St, Scheme -> Scheme
crate::check::types::Scheme zonk_scheme_f(const crate::check::types::St& st_p0, const crate::check::types::Scheme& sc_p1) {
    crate::check::types::Scheme this_ = sc_p1;
    this_.ty_p = crate::check::types::recording::zonk_f(st_p0, this_.ty_p);
    return this_;
}


prism_rtl::Turn<crate::check::types::Scheme> ZonkScheme::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& sc_p1 = this->sc_p1;
    return prism_rtl::finished(({
        crate::check::types::Scheme this_ = sc_p1;
        this_.ty_p = crate::check::types::recording::zonk_f(st_p0, this_.ty_p);
        (std::move(this_));
    }));
}


/// `Start ZonkScheme, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::Scheme> start_zonk_scheme_f(crate::check::types::St st_p0, crate::check::types::Scheme sc_p1) {
    return prism_rtl::make_rc<ZonkScheme>(st_p0, sc_p1);
}


/// TopLets: unbounded fn G, St -> ((G, St))
std::tuple<crate::check::env::G, crate::check::types::St> top_lets_f(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1) {
    auto unsigned_p2 = crate::prelude::filter(g_p0.defs_p, [&](const crate::check::env::Def& d_p3) { return is_let_def_f(d_p3) && (!crate::check::env::has_key_f(g_p0.vals_p, prism_rtl::deref(d_p3).qk_p)); });
    auto [g1_pa, st1_pb] = crate::prelude::fold(unsigned_p2, std::tuple{g_p0, st_p1}, [&](const std::tuple<crate::check::env::G, crate::check::types::St>& _p0, const crate::check::env::Def& d_p6) {
        auto&& gg_p4 = std::get<0>(_p0);
        auto&& s_p5 = std::get<1>(_p0);
        return ({
            auto [v_p8, s2_p9] = crate::check::types::fresh_var_f(s_p5, false, prism_rtl::deref(d_p6).name_p);
            auto gg2_p7 = ({
                crate::check::env::G this_ = gg_p4;
                this_.vals_p = crate::prelude::insert(this_.vals_p, prism_rtl::deref(d_p6).qk_p, crate::check::env::ValInfo{.qk_p = prism_rtl::deref(d_p6).qk_p, .scheme_p = crate::check::types::schemes::mono_f(v_p8), .sort_p = Text::lit("let"), .has_sig_p = false, .home_p = prism_rtl::deref(d_p6).home_p, .file_p = prism_rtl::deref(d_p6).file_p, .span_p = prism_rtl::deref(d_p6).span_p});
                (std::move(this_));
            });
            std::tuple{gg2_p7, s2_p9};
        });
    });
    return crate::prelude::run_to_end(crate::prelude::fold_job(unsigned_p2, std::tuple{g1_pa, st1_pb}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::env::G, crate::check::types::St>>(std::tuple<std::tuple<crate::check::env::G, crate::check::types::St>, crate::check::env::Def>)>>(prism_rtl::rc([=](std::tuple<std::tuple<crate::check::env::G, crate::check::types::St>, crate::check::env::Def> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto [gg_pc, s_pd] = p0;
                auto d_pe = p1;
                ({
                auto&& _m = prism_rtl::deref(d_pe).body_p;
                prism_rtl::is<crate::check::env::DefBody::DbLet>(_m) ? ({
                auto&& l_pf = prism_rtl::as<crate::check::env::DefBody::DbLet>(_m).a0;
                ({
                auto env_pg = def_env_f(gg_pc, d_pe);
                auto s0_ph = ({
                    crate::check::types::St this_ = s_pd;
                    this_.file_p = prism_rtl::deref(d_pe).file_p;
                    this_.level_p = Nat(1u);
                    this_.local_next_p = Nat(0u);
                    (std::move(this_));
                });
                auto pre_pi = prism_rtl::deref(prism_rtl::deref(crate::prelude::or_(crate::prelude::get(prism_rtl::deref(gg_pc).vals_p, prism_rtl::deref(d_pe).qk_p), dummy_val_p())).scheme_p).ty_p;
                auto l_pfx = l_pf;
                (crate::prelude::call_then(crate::check::expr::start_check_f(env_pg, s0_ph, prism_rtl::deref(l_pfx).value_p, pre_pi), [=](crate::check::types::St check_f_5241) {
                return ({
                    auto s1_pj = check_f_5241;
                    (crate::prelude::call_then(crate::check::env::traits::start_solve_wants_f(gg_pc, s1_pj, Array<std::tuple<Text, Text>>{}, false), [=](crate::check::types::St solve_wants_f_5290) {
                    return ({
                        auto s2_pk = solve_wants_f_5290;
                        auto s3_pl = ({
                            crate::check::types::St this_ = s2_pk;
                            this_.level_p = Nat(0u);
                            (std::move(this_));
                        });
                        (crate::prelude::call_then(crate::check::types::recording::start_zonk_f(s3_pl, pre_pi), [=](crate::check::types::Ty zonk_f_5403) {
                        return ({
                            auto t_pm = zonk_f_5403;
                            (crate::prelude::call_then(crate::check::expr::lets::start_wants_above_f(s3_pl, t_pm, crate::check::expr::is_lambda_f(prism_rtl::deref(l_pfx).value_p)), [=](std::tuple<Array<Nat>, Array<std::tuple<Nat, Text>>, crate::check::types::St> wants_above_f_5455) {
                            return ({
                                auto [keep_po, bounds_pp, s4_pq] = wants_above_f_5455;
                                (crate::prelude::call_then(crate::check::types::schemes::start_holds_node_f(s4_pq, t_pm), [=](bool holds_node_f_5524) {
                                return ({
                                    auto [sc_pr, s5_ps] = holds_node_f_5524
                                        ? std::tuple{crate::check::types::schemes::mono_f(t_pm), s4_pq}
                                        : crate::check::types::schemes::generalize_f(s4_pq, t_pm, keep_po, bounds_pp);
                                    auto gg2_pn = ({
                                        crate::check::env::G this_ = gg_pc;
                                        this_.vals_p = crate::prelude::insert(this_.vals_p, prism_rtl::deref(d_pe).qk_p, crate::check::env::ValInfo{.qk_p = prism_rtl::deref(d_pe).qk_p, .scheme_p = sc_pr, .sort_p = Text::lit("let"), .has_sig_p = false, .home_p = prism_rtl::deref(d_pe).home_p, .file_p = prism_rtl::deref(d_pe).file_p, .span_p = prism_rtl::deref(d_pe).span_p});
                                        (std::move(this_));
                                    });
                                    (crate::prelude::call_then(crate::check::types::colors::start_check_colors_f(s5_ps), [=, gg2_pn = std::move(gg2_pn)](crate::check::types::St check_colors_f_5843) { return crate::prelude::call_then(crate::check::env::traits::start_resolve_fields_f(gg_pc, check_colors_f_5843, true), [=](crate::check::types::St resolve_fields_f_5824) { return crate::prelude::call_then(crate::check::types::unify::start_layer_questions_f(resolve_fields_f_5824), [=](crate::check::types::St layer_questions_f_5808) { return crate::prelude::call_then(crate::check::passes::start_discharge_incls_f(gg_pc, layer_questions_f_5808, Nat(0u)), [=](crate::check::types::St discharge_incls_f_5788) { return prism_rtl::finished(std::tuple{gg2_pn, discharge_incls_f_5788}); }); }); }); }));
                                });
                            }));
                            });
                        }));
                        });
                    }));
                    });
                }));
                });
            }));
            });
            })
                : prism_rtl::finished(std::tuple{gg_pc, s_pd});
            });
            });
        }));
    }))));
}


prism_rtl::Turn<std::tuple<crate::check::env::G, crate::check::types::St>> TopLets::cycle() const {
    const auto& g_p0 = this->g_p0;
    const auto& st_p1 = this->st_p1;
    auto unsigned_p2 = crate::prelude::filter(prism_rtl::deref(g_p0).defs_p, [&](const crate::check::env::Def& d_p3) { return is_let_def_f(d_p3) && (!crate::check::env::has_key_f(prism_rtl::deref(g_p0).vals_p, prism_rtl::deref(d_p3).qk_p)); });
    auto [g1_pa, st1_pb] = crate::prelude::fold(unsigned_p2, std::tuple{g_p0, st_p1}, [&](const std::tuple<crate::check::env::G, crate::check::types::St>& _p0, const crate::check::env::Def& d_p6) {
        auto&& gg_p4 = std::get<0>(_p0);
        auto&& s_p5 = std::get<1>(_p0);
        return ({
            auto [v_p8, s2_p9] = crate::check::types::fresh_var_f(s_p5, false, prism_rtl::deref(d_p6).name_p);
            auto gg2_p7 = ({
                crate::check::env::G this_ = gg_p4;
                this_.vals_p = crate::prelude::insert(this_.vals_p, prism_rtl::deref(d_p6).qk_p, crate::check::env::ValInfo{.qk_p = prism_rtl::deref(d_p6).qk_p, .scheme_p = crate::check::types::schemes::mono_f(v_p8), .sort_p = Text::lit("let"), .has_sig_p = false, .home_p = prism_rtl::deref(d_p6).home_p, .file_p = prism_rtl::deref(d_p6).file_p, .span_p = prism_rtl::deref(d_p6).span_p});
                (std::move(this_));
            });
            std::tuple{gg2_p7, s2_p9};
        });
    });
    return crate::prelude::fold_job(unsigned_p2, std::tuple{g1_pa, st1_pb}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::env::G, crate::check::types::St>>(std::tuple<std::tuple<crate::check::env::G, crate::check::types::St>, crate::check::env::Def>)>>(prism_rtl::rc([=](std::tuple<std::tuple<crate::check::env::G, crate::check::types::St>, crate::check::env::Def> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto [gg_pc, s_pd] = p0;
                auto d_pe = p1;
                ({
                auto&& _m = prism_rtl::deref(d_pe).body_p;
                prism_rtl::is<crate::check::env::DefBody::DbLet>(_m) ? ({
                auto&& l_pf = prism_rtl::as<crate::check::env::DefBody::DbLet>(_m).a0;
                ({
                auto env_pg = def_env_f(gg_pc, d_pe);
                auto s0_ph = ({
                    crate::check::types::St this_ = s_pd;
                    this_.file_p = prism_rtl::deref(d_pe).file_p;
                    this_.level_p = Nat(1u);
                    this_.local_next_p = Nat(0u);
                    (std::move(this_));
                });
                auto pre_pi = prism_rtl::deref(prism_rtl::deref(crate::prelude::or_(crate::prelude::get(prism_rtl::deref(gg_pc).vals_p, prism_rtl::deref(d_pe).qk_p), dummy_val_p())).scheme_p).ty_p;
                auto l_pfx = l_pf;
                (crate::prelude::call_then(crate::check::expr::start_check_f(env_pg, s0_ph, prism_rtl::deref(l_pfx).value_p, pre_pi), [=](crate::check::types::St check_f_5241) {
                return ({
                    auto s1_pj = check_f_5241;
                    (crate::prelude::call_then(crate::check::env::traits::start_solve_wants_f(gg_pc, s1_pj, Array<std::tuple<Text, Text>>{}, false), [=](crate::check::types::St solve_wants_f_5290) {
                    return ({
                        auto s2_pk = solve_wants_f_5290;
                        auto s3_pl = ({
                            crate::check::types::St this_ = s2_pk;
                            this_.level_p = Nat(0u);
                            (std::move(this_));
                        });
                        (crate::prelude::call_then(crate::check::types::recording::start_zonk_f(s3_pl, pre_pi), [=](crate::check::types::Ty zonk_f_5403) {
                        return ({
                            auto t_pm = zonk_f_5403;
                            (crate::prelude::call_then(crate::check::expr::lets::start_wants_above_f(s3_pl, t_pm, crate::check::expr::is_lambda_f(prism_rtl::deref(l_pfx).value_p)), [=](std::tuple<Array<Nat>, Array<std::tuple<Nat, Text>>, crate::check::types::St> wants_above_f_5455) {
                            return ({
                                auto [keep_po, bounds_pp, s4_pq] = wants_above_f_5455;
                                (crate::prelude::call_then(crate::check::types::schemes::start_holds_node_f(s4_pq, t_pm), [=](bool holds_node_f_5524) {
                                return ({
                                    auto [sc_pr, s5_ps] = holds_node_f_5524
                                        ? std::tuple{crate::check::types::schemes::mono_f(t_pm), s4_pq}
                                        : crate::check::types::schemes::generalize_f(s4_pq, t_pm, keep_po, bounds_pp);
                                    auto gg2_pn = ({
                                        crate::check::env::G this_ = gg_pc;
                                        this_.vals_p = crate::prelude::insert(this_.vals_p, prism_rtl::deref(d_pe).qk_p, crate::check::env::ValInfo{.qk_p = prism_rtl::deref(d_pe).qk_p, .scheme_p = sc_pr, .sort_p = Text::lit("let"), .has_sig_p = false, .home_p = prism_rtl::deref(d_pe).home_p, .file_p = prism_rtl::deref(d_pe).file_p, .span_p = prism_rtl::deref(d_pe).span_p});
                                        (std::move(this_));
                                    });
                                    (crate::prelude::call_then(crate::check::types::colors::start_check_colors_f(s5_ps), [=, gg2_pn = std::move(gg2_pn)](crate::check::types::St check_colors_f_5843) { return crate::prelude::call_then(crate::check::env::traits::start_resolve_fields_f(gg_pc, check_colors_f_5843, true), [=](crate::check::types::St resolve_fields_f_5824) { return crate::prelude::call_then(crate::check::types::unify::start_layer_questions_f(resolve_fields_f_5824), [=](crate::check::types::St layer_questions_f_5808) { return crate::prelude::call_then(crate::check::passes::start_discharge_incls_f(gg_pc, layer_questions_f_5808, Nat(0u)), [=](crate::check::types::St discharge_incls_f_5788) { return prism_rtl::finished(std::tuple{gg2_pn, discharge_incls_f_5788}); }); }); }); }));
                                });
                            }));
                            });
                        }));
                        });
                    }));
                    });
                }));
                });
            }));
            });
            })
                : prism_rtl::finished(std::tuple{gg_pc, s_pd});
            });
            });
        }));
    })))->cycle();
}


/// `Start TopLets, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::env::G, crate::check::types::St>> start_top_lets_f(crate::check::env::G g_p0, crate::check::types::St st_p1) {
    return prism_rtl::make_rc<TopLets>(g_p0, st_p1);
}


/// let dummyVal
crate::check::env::ValInfo dummy_val_p() {
    return crate::check::env::ValInfo{.qk_p = Text::lit(""), .scheme_p = crate::check::types::schemes::mono_f(crate::check::types::Ty(crate::check::types::Ty::TyErr{})), .sort_p = Text::lit(""), .has_sig_p = false, .home_p = Text::lit(""), .file_p = Nat(0u), .span_p = crate::syntax::Range{.start_p = Nat(0u), .end_p = Nat(0u)}};
}


/// IsLetDef: fn Def -> Bool
bool is_let_def_f(const crate::check::env::Def& d_p0) {
    auto&& _m = d_p0.body_p;
    if (prism_rtl::is<crate::check::env::DefBody::DbLet>(_m)) {
        return true;
    }
    {
        return false;
    }
}


/// DefEnv: fn G, Def -> Env
crate::check::expr::Env def_env_f(const crate::check::env::G& g_p0, const crate::check::env::Def& d_p1) {
    auto info_p2 = crate::prelude::or_(crate::prelude::get(g_p0.mods_p, d_p1.home_p), crate::check::env::reading::dummy_mod_p());
    auto scope_p3 = ({
        __label__ _done;
        prism_rtl::Slot<crate::check::types::Rw> _v;
        auto&& _m = prism_rtl::deref(prism_rtl::deref(info_p2).emit_rw_p).tail_p;
        if (prism_rtl::is<crate::check::types::Tail::TlQ>(_m)) {
            auto&& v_p4 = prism_rtl::as<crate::check::types::Tail::TlQ>(_m).a0;
            _v.set(crate::check::types::Rw{.fams_p = prism_rtl::deref(prism_rtl::deref(info_p2).emit_rw_p).fams_p, .minus_p = Array<Text>{}, .tail_p = crate::check::types::Tail(crate::check::types::Tail::TlRigid{v_p4})});
            goto _done;
        }
        {
            _v.set(prism_rtl::deref(info_p2).emit_rw_p);
            goto _done;
        }
    _done:
        _v.take();
    });
    return crate::check::expr::Env{.g_p = g_p0, .home_p = d_p1.home_p, .file_p = d_p1.file_p, .src_p = crate::prelude::or_(crate::prelude::index(g_p0.srcs_p, d_p1.file_p), crate::check::errors::mk_src_f(Text::lit(""), Text::lit(""))), .locals_p = Map<Text, crate::check::types::Scheme>{}, .scope_p = scope_p3, .givens_p = Array<std::tuple<Text, Text>>{}, .mark_p = Text::lit(""), .in_update_p = false, .def_name_p = d_p1.name_p, .refine_p = Map<Text, crate::check::types::Ty>{}, .pending_p = Array<Text>{}, .ids_p = Map<Text, Nat>{}};
}


/// CheckDef: unbounded fn G, St, Def -> St
crate::check::types::St check_def_f(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const crate::check::env::Def& d_p2) {
    auto env_p3 = def_env_f(g_p0, d_p2);
    auto incls_before_p4 = crate::prelude::len(st_p1.incls_p);
    auto s0_p5 = ({
        crate::check::types::St this_ = st_p1;
        this_.file_p = d_p2.file_p;
        this_.level_p = Nat(1u);
        this_.local_next_p = Nat(0u);
        this_.color_p = crate::check::types::Col(crate::check::types::Col::CBound{});
        this_.color_why_p = Text::lit("");
        this_.color_flex_p = Array<std::tuple<crate::check::types::Col, Text, crate::syntax::Range>>{};
        this_.cleqs_p = Array<crate::check::types::CLeq>{};
        (std::move(this_));
    });
    auto s1_p6 = ({
        __label__ _done;
        prism_rtl::Slot<crate::check::types::St> _v;
        auto&& _m = d_p2.body_p;
        if (prism_rtl::is<crate::check::env::DefBody::DbFn>(_m)) {
            auto&& clauses_pa = prism_rtl::as<crate::check::env::DefBody::DbFn>(_m).a0;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<crate::check::types::St> _v;
                auto&& _m = crate::prelude::get(g_p0.vals_p, d_p2.qk_p);
                if (prism_rtl::is_some(_m)) {
                    auto&& v_pb = prism_rtl::some_of(_m);
                    _v.set(crate::check::expr::lets::check_clauses_f(env_p3, s0_p5, d_p2.name_p, clauses_pa, prism_rtl::deref(v_pb).scheme_p, d_p2.span_p));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(s0_p5);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is<crate::check::env::DefBody::DbWidget>(_m)) {
            auto&& w_pc = prism_rtl::as<crate::check::env::DefBody::DbWidget>(_m).a0;
            _v.set(check_widget_def_f(env_p3, s0_p5, d_p2, w_pc));
            goto _done;
        }
        if (prism_rtl::is<crate::check::env::DefBody::DbLet>(_m)) {
            auto&& l_pd = prism_rtl::as<crate::check::env::DefBody::DbLet>(_m).a0;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<crate::check::types::St> _v;
                auto&& _m = crate::prelude::get(g_p0.vals_p, d_p2.qk_p);
                if (prism_rtl::is_some(_m)) {
                    auto&& v_pe = prism_rtl::some_of(_m);
                    _v.set(prism_rtl::deref(v_pe).has_sig_p
                        ? crate::check::expr::check_f(env_p3, s0_p5, prism_rtl::deref(l_pd).value_p, crate::check::types::schemes::skolemize_f(prism_rtl::deref(v_pe).scheme_p))
                        : s0_p5);
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(s0_p5);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is<crate::check::env::DefBody::DbMethod>(_m)) {
            auto&& clauses_pf = prism_rtl::as<crate::check::env::DefBody::DbMethod>(_m).a0;
            auto&& cls_pg = prism_rtl::as<crate::check::env::DefBody::DbMethod>(_m).a1;
            auto&& im_ph = prism_rtl::as<crate::check::env::DefBody::DbMethod>(_m).a2;
            _v.set(check_method_f(env_p3, s0_p5, d_p2, clauses_pf, cls_pg, im_ph));
            goto _done;
        }
        if (prism_rtl::is<crate::check::env::DefBody::DbDefault>(_m)) {
            auto&& clauses_pi = prism_rtl::as<crate::check::env::DefBody::DbDefault>(_m).a0;
            auto&& cls_pj = prism_rtl::as<crate::check::env::DefBody::DbDefault>(_m).a1;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<crate::check::types::St> _v;
                auto&& _m = method_key_o(g_p0, cls_pj, d_p2.name_p);
                if (prism_rtl::is_some(_m)) {
                    auto&& mk_pk = prism_rtl::some_of(_m);
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<crate::check::types::St> _v;
                        auto&& _m = crate::prelude::get(g_p0.vals_p, mk_pk);
                        if (prism_rtl::is_some(_m)) {
                            auto&& v_pl = prism_rtl::some_of(_m);
                            _v.set(crate::check::expr::lets::check_clauses_f(env_p3, s0_p5, d_p2.name_p, clauses_pi, prism_rtl::deref(v_pl).scheme_p, d_p2.span_p));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(s0_p5);
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(s0_p5);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is<crate::check::env::DefBody::DbCheck>(_m)) {
            auto&& c_pm = prism_rtl::as<crate::check::env::DefBody::DbCheck>(_m).a0;
            _v.set(crate::prelude::run_to_end(crate::prelude::fold_job(prism_rtl::deref(c_pm).lines_p, s0_p5, ({
                auto env_p3x = env_p3;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::decls::CheckLine>)>>(prism_rtl::rc([=, env_p3x = std::move(env_p3x)](std::tuple<crate::check::types::St, crate::syntax::decls::CheckLine> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto env_p3xy = env_p3x;
                    (crate::prelude::entered(crate::prelude::once_job([=, env_p3xy = std::move(env_p3xy)]() {
                    return ({
                        auto s_pn = p0;
                        auto line_po = p1;
                        (crate::prelude::call_then(crate::check::expr::start_infer_f(env_p3xy, s_pn, prism_rtl::deref(line_po).expr_p), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_f_7891) {
                        return ({
                            auto [t_pp, s2_pq] = infer_f_7891;
                            ({
                            auto&& _m = prism_rtl::deref(line_po).pattern_o;
                            prism_rtl::is_some(_m) ? ({
                            auto&& p_pr = prism_rtl::some_of(_m);
                            ({
                            auto p_prx = p_pr;
                            (crate::prelude::call_then(crate::check::expr::patterns::start_bind_pattern_f(env_p3xy, s2_pq, p_prx, t_pp, true), [=](std::tuple<crate::check::expr::Env, crate::check::types::St> bind_pattern_f_8010) {
                            return ({
                                auto&& _s3_ps = bind_pattern_f_8010;
                                auto&& s3_ps = std::get<1>(_s3_ps);
                                (prism_rtl::finished(s3_ps));
                            });
                        }));
                        });
                        })
                            : prism_rtl::is_none(_m) ? prism_rtl::finished(s2_pq)
                            : throw prism_rtl::Panic("no arm matched");
                        });
                        });
                    }));
                    });
                })));
                });
            })));
            }))));
            goto _done;
        }
        if (prism_rtl::is<crate::check::env::DefBody::DbTest>(_m)) {
            auto&& t_pt = prism_rtl::as<crate::check::env::DefBody::DbTest>(_m).a0;
            _v.set(({
                auto [bt_pu, s2_pv] = crate::check::expr::infer_f(env_p3, s0_p5, prism_rtl::deref(t_pt).blueprint_p);
                ({
                __label__ _done;
                prism_rtl::Slot<crate::check::types::St> _v;
                auto&& _m = crate::check::types::recording::walk_f(s2_pv, bt_pu);
                if (prism_rtl::is<crate::check::types::Ty::TyAt>(_m)) {
                    _v.set(s2_pv);
                    goto _done;
                }
                if (prism_rtl::is<crate::check::types::Ty::TyErr>(_m)) {
                    _v.set(s2_pv);
                    goto _done;
                }
                {
                    auto&& other_p10 = _m;
                    _v.set(crate::check::types::recording::err_f(s2_pv, Text::lit("mismatch"), prism_rtl::deref(prism_rtl::deref(t_pt).blueprint_p).span_p, prism_rtl::cat("a test builds a blueprint; this is `", crate::check::types::show_ty_f(s2_pv, other_p10), "`")));
                    goto _done;
                }
            _done:
                _v.take();
            });
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto solved_p7 = crate::check::types::colors::check_colors_f(crate::check::env::traits::solve_wants_f(g_p0, s1_p6, prism_rtl::deref(env_p3).givens_p, false));
    auto defaulted_p8 = crate::check::types::unify::layer_questions_f(crate::check::env::traits::resolve_fields_f(g_p0, default_def_f(g_p0, solved_p7), true));
    auto discharged_p9 = crate::check::passes::discharge_incls_f(g_p0, defaulted_p8, incls_before_p4);
    crate::check::types::St this_ = discharged_p9;
    this_.level_p = Nat(0u);
    return this_;
}


prism_rtl::Turn<crate::check::types::St> CheckDef::cycle() const {
    const auto& g_p0 = this->g_p0;
    const auto& st_p1 = this->st_p1;
    const auto& d_p2 = this->d_p2;
    auto env_p3 = def_env_f(g_p0, d_p2);
    auto incls_before_p4 = crate::prelude::len(prism_rtl::deref(st_p1).incls_p);
    auto s0_p5 = ({
        crate::check::types::St this_ = st_p1;
        this_.file_p = prism_rtl::deref(d_p2).file_p;
        this_.level_p = Nat(1u);
        this_.local_next_p = Nat(0u);
        this_.color_p = crate::check::types::Col(crate::check::types::Col::CBound{});
        this_.color_why_p = Text::lit("");
        this_.color_flex_p = Array<std::tuple<crate::check::types::Col, Text, crate::syntax::Range>>{};
        this_.cleqs_p = Array<crate::check::types::CLeq>{};
        (std::move(this_));
    });
    auto s1_p6 = ({
        __label__ _done;
        prism_rtl::Slot<crate::check::types::St> _v;
        auto&& _m = prism_rtl::deref(d_p2).body_p;
        if (prism_rtl::is<crate::check::env::DefBody::DbFn>(_m)) {
            auto&& clauses_pa = prism_rtl::as<crate::check::env::DefBody::DbFn>(_m).a0;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<crate::check::types::St> _v;
                auto&& _m = crate::prelude::get(prism_rtl::deref(g_p0).vals_p, prism_rtl::deref(d_p2).qk_p);
                if (prism_rtl::is_some(_m)) {
                    auto&& v_pb = prism_rtl::some_of(_m);
                    _v.set(crate::check::expr::lets::check_clauses_f(env_p3, s0_p5, prism_rtl::deref(d_p2).name_p, clauses_pa, prism_rtl::deref(v_pb).scheme_p, prism_rtl::deref(d_p2).span_p));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(s0_p5);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is<crate::check::env::DefBody::DbWidget>(_m)) {
            auto&& w_pc = prism_rtl::as<crate::check::env::DefBody::DbWidget>(_m).a0;
            _v.set(check_widget_def_f(env_p3, s0_p5, d_p2, w_pc));
            goto _done;
        }
        if (prism_rtl::is<crate::check::env::DefBody::DbLet>(_m)) {
            auto&& l_pd = prism_rtl::as<crate::check::env::DefBody::DbLet>(_m).a0;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<crate::check::types::St> _v;
                auto&& _m = crate::prelude::get(prism_rtl::deref(g_p0).vals_p, prism_rtl::deref(d_p2).qk_p);
                if (prism_rtl::is_some(_m)) {
                    auto&& v_pe = prism_rtl::some_of(_m);
                    _v.set(prism_rtl::deref(v_pe).has_sig_p
                        ? crate::check::expr::check_f(env_p3, s0_p5, prism_rtl::deref(l_pd).value_p, crate::check::types::schemes::skolemize_f(prism_rtl::deref(v_pe).scheme_p))
                        : s0_p5);
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(s0_p5);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is<crate::check::env::DefBody::DbMethod>(_m)) {
            auto&& clauses_pf = prism_rtl::as<crate::check::env::DefBody::DbMethod>(_m).a0;
            auto&& cls_pg = prism_rtl::as<crate::check::env::DefBody::DbMethod>(_m).a1;
            auto&& im_ph = prism_rtl::as<crate::check::env::DefBody::DbMethod>(_m).a2;
            _v.set(check_method_f(env_p3, s0_p5, d_p2, clauses_pf, cls_pg, im_ph));
            goto _done;
        }
        if (prism_rtl::is<crate::check::env::DefBody::DbDefault>(_m)) {
            auto&& clauses_pi = prism_rtl::as<crate::check::env::DefBody::DbDefault>(_m).a0;
            auto&& cls_pj = prism_rtl::as<crate::check::env::DefBody::DbDefault>(_m).a1;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<crate::check::types::St> _v;
                auto&& _m = method_key_o(g_p0, cls_pj, prism_rtl::deref(d_p2).name_p);
                if (prism_rtl::is_some(_m)) {
                    auto&& mk_pk = prism_rtl::some_of(_m);
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<crate::check::types::St> _v;
                        auto&& _m = crate::prelude::get(prism_rtl::deref(g_p0).vals_p, mk_pk);
                        if (prism_rtl::is_some(_m)) {
                            auto&& v_pl = prism_rtl::some_of(_m);
                            _v.set(crate::check::expr::lets::check_clauses_f(env_p3, s0_p5, prism_rtl::deref(d_p2).name_p, clauses_pi, prism_rtl::deref(v_pl).scheme_p, prism_rtl::deref(d_p2).span_p));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(s0_p5);
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(s0_p5);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is<crate::check::env::DefBody::DbCheck>(_m)) {
            auto&& c_pm = prism_rtl::as<crate::check::env::DefBody::DbCheck>(_m).a0;
            _v.set(crate::prelude::run_to_end(crate::prelude::fold_job(prism_rtl::deref(c_pm).lines_p, s0_p5, ({
                auto env_p3x = env_p3;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::decls::CheckLine>)>>(prism_rtl::rc([=, env_p3x = std::move(env_p3x)](std::tuple<crate::check::types::St, crate::syntax::decls::CheckLine> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto env_p3xy = env_p3x;
                    (crate::prelude::entered(crate::prelude::once_job([=, env_p3xy = std::move(env_p3xy)]() {
                    return ({
                        auto s_pn = p0;
                        auto line_po = p1;
                        (crate::prelude::call_then(crate::check::expr::start_infer_f(env_p3xy, s_pn, prism_rtl::deref(line_po).expr_p), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_f_7891) {
                        return ({
                            auto [t_pp, s2_pq] = infer_f_7891;
                            ({
                            auto&& _m = prism_rtl::deref(line_po).pattern_o;
                            prism_rtl::is_some(_m) ? ({
                            auto&& p_pr = prism_rtl::some_of(_m);
                            ({
                            auto p_prx = p_pr;
                            (crate::prelude::call_then(crate::check::expr::patterns::start_bind_pattern_f(env_p3xy, s2_pq, p_prx, t_pp, true), [=](std::tuple<crate::check::expr::Env, crate::check::types::St> bind_pattern_f_8010) {
                            return ({
                                auto&& _s3_ps = bind_pattern_f_8010;
                                auto&& s3_ps = std::get<1>(_s3_ps);
                                (prism_rtl::finished(s3_ps));
                            });
                        }));
                        });
                        })
                            : prism_rtl::is_none(_m) ? prism_rtl::finished(s2_pq)
                            : throw prism_rtl::Panic("no arm matched");
                        });
                        });
                    }));
                    });
                })));
                });
            })));
            }))));
            goto _done;
        }
        if (prism_rtl::is<crate::check::env::DefBody::DbTest>(_m)) {
            auto&& t_pt = prism_rtl::as<crate::check::env::DefBody::DbTest>(_m).a0;
            _v.set(({
                auto [bt_pu, s2_pv] = crate::check::expr::infer_f(env_p3, s0_p5, prism_rtl::deref(t_pt).blueprint_p);
                ({
                __label__ _done;
                prism_rtl::Slot<crate::check::types::St> _v;
                auto&& _m = crate::check::types::recording::walk_f(s2_pv, bt_pu);
                if (prism_rtl::is<crate::check::types::Ty::TyAt>(_m)) {
                    _v.set(s2_pv);
                    goto _done;
                }
                if (prism_rtl::is<crate::check::types::Ty::TyErr>(_m)) {
                    _v.set(s2_pv);
                    goto _done;
                }
                {
                    auto&& other_p10 = _m;
                    _v.set(crate::check::types::recording::err_f(s2_pv, Text::lit("mismatch"), prism_rtl::deref(prism_rtl::deref(t_pt).blueprint_p).span_p, prism_rtl::cat("a test builds a blueprint; this is `", crate::check::types::show_ty_f(s2_pv, other_p10), "`")));
                    goto _done;
                }
            _done:
                _v.take();
            });
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto g_p0x = g_p0;
    return crate::prelude::call_then(crate::check::env::traits::start_solve_wants_f(g_p0x, s1_p6, prism_rtl::deref(env_p3).givens_p, false), [=](crate::check::types::St solve_wants_f_8409) {
        return crate::prelude::call_then(crate::check::types::colors::start_check_colors_f(solve_wants_f_8409), [=](crate::check::types::St check_colors_f_8396) {
            return ({
                auto solved_p7 = check_colors_f_8396;
                (crate::prelude::call_then(start_default_def_f(g_p0x, solved_p7), [=](crate::check::types::St default_def_f_8500) {
                return crate::prelude::call_then(crate::check::env::traits::start_resolve_fields_f(g_p0x, default_def_f_8500, true), [=](crate::check::types::St resolve_fields_f_8482) {
                    return crate::prelude::call_then(crate::check::types::unify::start_layer_questions_f(resolve_fields_f_8482), [=](crate::check::types::St layer_questions_f_8466) {
                        return ({
                            auto defaulted_p8 = layer_questions_f_8466;
                            (crate::prelude::call_then(crate::check::passes::start_discharge_incls_f(g_p0x, defaulted_p8, incls_before_p4), [=](crate::check::types::St discharge_incls_f_8550) {
                            return ({
                                auto discharged_p9 = discharge_incls_f_8550;
                                (prism_rtl::finished(({
                                crate::check::types::St this_ = discharged_p9;
                                this_.level_p = Nat(0u);
                                (std::move(this_));
                            })));
                            });
                        }));
                        });
                    });
                });
            }));
            });
        });
    });
}


/// `Start CheckDef, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_check_def_f(crate::check::env::G g_p0, crate::check::types::St st_p1, crate::check::env::Def d_p2) {
    return prism_rtl::make_rc<CheckDef>(g_p0, st_p1, d_p2);
}


/// DefaultDef: unbounded fn G, St -> St
crate::check::types::St default_def_f(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1) {
    auto mine_p2 = crate::prelude::run_to_end(crate::prelude::filter_job(st_p1.wants_p, ({
        auto st_p1x = st_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(crate::check::types::Want)>>(prism_rtl::rc([=, st_p1x = std::move(st_p1x)](crate::check::types::Want p0) {
        return ({
            auto st_p1xy = st_p1x;
            (crate::prelude::entered(crate::prelude::once_job([=, st_p1xy = std::move(st_p1xy)]() {
            return ({
                auto w_p6 = p0;
                (crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p1xy, prism_rtl::deref(w_p6).ty_p), [=](crate::check::types::Ty walk_f_8872) {
                return ({
                    prism_rtl::is<crate::check::types::Ty::TyFlex>(walk_f_8872) ? ({
                    auto&& n_p7 = prism_rtl::as<crate::check::types::Ty::TyFlex>(walk_f_8872).a0;
                    prism_rtl::finished(prism_rtl::deref(crate::check::types::recording::info_of_f(st_p1xy, n_p7)).level_p >= Nat(1u));
                })
                    : prism_rtl::finished(true);
                });
            }));
            });
        })));
        });
    })));
    })));
    auto theirs_p3 = crate::prelude::run_to_end(crate::prelude::filter_job(st_p1.wants_p, ({
        auto st_p1x = st_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(crate::check::types::Want)>>(prism_rtl::rc([=, st_p1x = std::move(st_p1x)](crate::check::types::Want p0) {
        return ({
            auto st_p1xy = st_p1x;
            (crate::prelude::entered(crate::prelude::once_job([=, st_p1xy = std::move(st_p1xy)]() {
            return ({
                auto w_p8 = p0;
                (crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p1xy, prism_rtl::deref(w_p8).ty_p), [=](crate::check::types::Ty walk_f_9000) {
                return ({
                    prism_rtl::is<crate::check::types::Ty::TyFlex>(walk_f_9000) ? ({
                    auto&& n_p9 = prism_rtl::as<crate::check::types::Ty::TyFlex>(walk_f_9000).a0;
                    prism_rtl::finished(prism_rtl::deref(crate::check::types::recording::info_of_f(st_p1xy, n_p9)).level_p < Nat(1u));
                })
                    : prism_rtl::finished(false);
                });
            }));
            });
        })));
        });
    })));
    })));
    auto st1_p4 = ({
        crate::check::types::St this_ = st_p1;
        this_.wants_p = mine_p2;
        (std::move(this_));
    });
    auto s2_p5 = crate::check::env::traits::default_wants_f(g_p0, st1_p4, Array<std::tuple<Text, Text>>{});
    crate::check::types::St this_ = s2_p5;
    this_.wants_p = crate::prelude::append(theirs_p3, this_.wants_p);
    return this_;
}


prism_rtl::Turn<crate::check::types::St> DefaultDef::cycle() const {
    const auto& g_p0 = this->g_p0;
    const auto& st_p1 = this->st_p1;
    auto g_p0x = g_p0;
    auto st_p1x = st_p1;
    return crate::prelude::call_value(crate::prelude::filter_job(prism_rtl::deref(st_p1x).wants_p, ({
        auto st_p1xx = st_p1x;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(crate::check::types::Want)>>(prism_rtl::rc([=, st_p1xx = std::move(st_p1xx)](crate::check::types::Want p0) {
        return ({
            auto st_p1xxy = st_p1xx;
            (crate::prelude::entered(crate::prelude::once_job([=, st_p1xxy = std::move(st_p1xxy)]() {
            return ({
                auto w_p6 = p0;
                (crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p1xxy, prism_rtl::deref(w_p6).ty_p), [=](crate::check::types::Ty walk_f_8872) {
                return ({
                    prism_rtl::is<crate::check::types::Ty::TyFlex>(walk_f_8872) ? ({
                    auto&& n_p7 = prism_rtl::as<crate::check::types::Ty::TyFlex>(walk_f_8872).a0;
                    prism_rtl::finished(prism_rtl::deref(crate::check::types::recording::info_of_f(st_p1xxy, n_p7)).level_p >= Nat(1u));
                })
                    : prism_rtl::finished(true);
                });
            }));
            });
        })));
        });
    })));
    })), [=](Array<crate::check::types::Want> filter_8844) {
        return ({
            auto mine_p2 = filter_8844;
            (crate::prelude::call_value(crate::prelude::filter_job(prism_rtl::deref(st_p1x).wants_p, ({
            auto st_p1xx = st_p1x;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(crate::check::types::Want)>>(prism_rtl::rc([=, st_p1xx = std::move(st_p1xx)](crate::check::types::Want p0) {
            return ({
                auto st_p1xxy = st_p1xx;
                (crate::prelude::entered(crate::prelude::once_job([=, st_p1xxy = std::move(st_p1xxy)]() {
                return ({
                    auto w_p8 = p0;
                    (crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p1xxy, prism_rtl::deref(w_p8).ty_p), [=](crate::check::types::Ty walk_f_9000) {
                    return ({
                        prism_rtl::is<crate::check::types::Ty::TyFlex>(walk_f_9000) ? ({
                        auto&& n_p9 = prism_rtl::as<crate::check::types::Ty::TyFlex>(walk_f_9000).a0;
                        prism_rtl::finished(prism_rtl::deref(crate::check::types::recording::info_of_f(st_p1xxy, n_p9)).level_p < Nat(1u));
                    })
                        : prism_rtl::finished(false);
                    });
                }));
                });
            })));
            });
        })));
        })), [=, mine_p2 = std::move(mine_p2)](Array<crate::check::types::Want> filter_8972) {
            return ({
                auto theirs_p3 = filter_8972;
                auto st1_p4 = ({
                    crate::check::types::St this_ = st_p1x;
                    this_.wants_p = mine_p2;
                    (std::move(this_));
                });
                (crate::prelude::call_then(crate::check::env::traits::start_default_wants_f(g_p0x, st1_p4, Array<std::tuple<Text, Text>>{}), [=, theirs_p3 = std::move(theirs_p3)](crate::check::types::St default_wants_f_9146) {
                return ({
                    auto s2_p5 = default_wants_f_9146;
                    (prism_rtl::finished(({
                    crate::check::types::St this_ = s2_p5;
                    this_.wants_p = crate::prelude::append(theirs_p3, this_.wants_p);
                    (std::move(this_));
                })));
                });
            }));
            });
        }));
        });
    });
}


/// `Start DefaultDef, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_default_def_f(crate::check::env::G g_p0, crate::check::types::St st_p1) {
    return prism_rtl::make_rc<DefaultDef>(g_p0, st_p1);
}


/// CheckWidgetDef: unbounded fn Env, St, Def, WidgetDecl -> St
crate::check::types::St check_widget_def_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::check::env::Def& d_p2, const crate::syntax::decls::WidgetDecl& w_p3) {
    auto&& _m = crate::prelude::get(prism_rtl::deref(env_p0.g_p).vals_p, d_p2.qk_p);
    if (prism_rtl::is_some(_m)) {
        auto&& v_p4 = prism_rtl::some_of(_m);
        auto&& _m = crate::check::types::schemes::skolemize_f(prism_rtl::deref(v_p4).scheme_p);
        if (prism_rtl::is<crate::check::types::Ty::TyAt>(_m)) {
            auto&& inner_p5 = prism_rtl::as<crate::check::types::Ty::TyAt>(_m).a0;
            auto&& rw_p6 = prism_rtl::as<crate::check::types::Ty::TyAt>(_m).a1;
            auto env2_p7 = ({
                crate::check::expr::Env this_ = env_p0;
                this_.scope_p = rw_p6;
                this_.mark_p = Text::lit("@");
                (std::move(this_));
            });
            auto [t_p8, st2_p9] = crate::check::blocks::infer_widget_block_f(env2_p7, st_p1, w_p3.body_p);
            return crate::check::types::recording::note_fn_f(crate::check::types::unify::unify_f(st2_p9, prism_rtl::deref(inner_p5), t_p8, w_p3.span_p), w_p3.span_p, d_p2.name_p, crate::check::types::Col(crate::check::types::Col::CBound{}), prism_rtl::deref(st2_p9).color_p);
        }
        {
            auto&& other_pa = _m;
            return crate::check::types::recording::err_f(st_p1, Text::lit("mismatch"), w_p3.span_p, prism_rtl::cat("`", d_p2.name_p, "` is declared `", crate::check::types::show_ty_f(st_p1, other_pa), "`; a widget block builds a blueprint"));
        }
    }
    if (prism_rtl::is_none(_m)) {
        auto [t_pb, st2_pc] = crate::check::blocks::infer_widget_block_f(env_p0, st_p1, w_p3.body_p);
        return crate::check::types::recording::note_fn_f(st2_pc, w_p3.span_p, d_p2.name_p, crate::check::types::Col(crate::check::types::Col::CBound{}), prism_rtl::deref(st2_pc).color_p);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::check::types::St> CheckWidgetDef::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& d_p2 = this->d_p2;
    const auto& w_p3 = this->w_p3;
    return ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(prism_rtl::deref(env_p0).g_p).vals_p, prism_rtl::deref(d_p2).qk_p);
        prism_rtl::is_some(_m) ? ({
        auto&& v_p4 = prism_rtl::some_of(_m);
        ({
        auto d_p2x = d_p2;
        auto env_p0x = env_p0;
        auto st_p1x = st_p1;
        auto w_p3x = w_p3;
        (crate::prelude::call_then(crate::check::types::schemes::start_skolemize_f(prism_rtl::deref(v_p4).scheme_p), [=, d_p2x = std::move(d_p2x), env_p0x = std::move(env_p0x), st_p1x = std::move(st_p1x), w_p3x = std::move(w_p3x)](crate::check::types::Ty skolemize_f_9452) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TyAt>(skolemize_f_9452) ? ({
            auto&& inner_p5 = prism_rtl::as<crate::check::types::Ty::TyAt>(skolemize_f_9452).a0;
            auto&& rw_p6 = prism_rtl::as<crate::check::types::Ty::TyAt>(skolemize_f_9452).a1;
            ({
            auto env2_p7 = ({
                crate::check::expr::Env this_ = env_p0x;
                this_.scope_p = rw_p6;
                this_.mark_p = Text::lit("@");
                (std::move(this_));
            });
            (crate::prelude::call_then(crate::check::blocks::start_infer_widget_block_f(env2_p7, st_p1x, prism_rtl::deref(w_p3x).body_p), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_widget_block_f_9622) {
            return ({
                auto [t_p8, st2_p9] = infer_widget_block_f_9622;
                (crate::prelude::call_then(crate::check::types::unify::start_unify_f(st2_p9, prism_rtl::deref(inner_p5), t_p8, prism_rtl::deref(w_p3x).span_p), [=](crate::check::types::St unify_f_9676) { return prism_rtl::finished(crate::check::types::recording::note_fn_f(unify_f_9676, prism_rtl::deref(w_p3x).span_p, prism_rtl::deref(d_p2x).name_p, crate::check::types::Col(crate::check::types::Col::CBound{}), prism_rtl::deref(st2_p9).color_p)); }));
            });
        }));
        });
        })
            : ({
            auto&& other_pa = skolemize_f_9452;
            crate::prelude::call_then(crate::check::types::start_show_ty_f(st_p1x, other_pa), [=](Text show_ty_f_9809) { return prism_rtl::finished(crate::check::types::recording::err_f(st_p1x, Text::lit("mismatch"), prism_rtl::deref(w_p3x).span_p, prism_rtl::cat("`", prism_rtl::deref(d_p2x).name_p, "` is declared `", show_ty_f_9809, "`; a widget block builds a blueprint"))); });
        });
        });
    }));
    });
    })
        : prism_rtl::is_none(_m) ? ({
        auto d_p2x = d_p2;
        auto env_p0x = env_p0;
        auto st_p1x = st_p1;
        auto w_p3x = w_p3;
        (crate::prelude::call_then(crate::check::blocks::start_infer_widget_block_f(env_p0x, st_p1x, prism_rtl::deref(w_p3x).body_p), [=, d_p2x = std::move(d_p2x)](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_widget_block_f_9898) {
        return ({
            auto [t_pb, st2_pc] = infer_widget_block_f_9898;
            (prism_rtl::finished(crate::check::types::recording::note_fn_f(st2_pc, prism_rtl::deref(w_p3x).span_p, prism_rtl::deref(d_p2x).name_p, crate::check::types::Col(crate::check::types::Col::CBound{}), prism_rtl::deref(st2_pc).color_p)));
        });
    }));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CheckWidgetDef, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_check_widget_def_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::check::env::Def d_p2, crate::syntax::decls::WidgetDecl w_p3) {
    return prism_rtl::make_rc<CheckWidgetDef>(env_p0, st_p1, d_p2, w_p3);
}


/// ?MethodKey: fn G, Text, Text -> ?Text
std::optional<Text> method_key_o(const crate::check::env::G& g_p0, const Text& cls_p1, const Text& name_p2) {
    return crate::prelude::fold(prism_rtl::deref(crate::prelude::or_(crate::prelude::get(g_p0.traits_p, cls_p1), crate::check::env::traits::dummy_trait_p())).methods_p, std::optional<Text>{}, [&](const std::optional<Text>& found_o3, const Text& k_p4) {
        return ({
            __label__ _done;
            prism_rtl::Slot<std::optional<Text>> _v;
            if (prism_rtl::is_some(found_o3)) {
                auto&& f_p5 = prism_rtl::some_of(found_o3);
                _v.set(std::optional(f_p5));
                goto _done;
            }
            if (prism_rtl::is_none(found_o3)) {
                _v.set((crate::check::types::bare_name_f(k_p4) == name_p2) || (crate::syntax::lexer::chars::drop_prefix_f(k_p4, prism_rtl::cat(prism_rtl::deref(crate::prelude::or_(crate::prelude::get(g_p0.traits_p, cls_p1), crate::check::env::traits::dummy_trait_p())).home_p, ".")) == name_p2)
                    ? std::optional(k_p4)
                    : std::optional<Text>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
}


/// CheckMethod: unbounded fn Env, St, Def, [FnClause], Text, ImplInfo -> St
crate::check::types::St check_method_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::check::env::Def& d_p2, const Array<crate::syntax::decls::FnClause>& clauses_p3, const Text& cls_p4, const crate::check::env::ImplInfo& im_p5) {
    auto&& _m = method_key_o(env_p0.g_p, cls_p4, d_p2.name_p);
    if (prism_rtl::is_none(_m)) {
        return crate::check::types::recording::err_f(st_p1, Text::lit("mismatch"), d_p2.span_p, prism_rtl::cat("`^", crate::check::types::bare_name_f(cls_p4), "` has no method `", d_p2.name_p, "`"));
    }
    if (prism_rtl::is_some(_m)) {
        auto&& mk_p6 = prism_rtl::some_of(_m);
        auto&& _m = crate::prelude::get(prism_rtl::deref(env_p0.g_p).vals_p, mk_p6);
        if (prism_rtl::is_none(_m)) {
            return st_p1;
        }
        if (prism_rtl::is_some(_m)) {
            auto&& v_p7 = prism_rtl::some_of(_m);
            auto ti_p8 = crate::prelude::or_(crate::prelude::get(prism_rtl::deref(env_p0.g_p).traits_p, cls_p4), crate::check::env::traits::dummy_trait_p());
            auto head_p9 = crate::check::types::schemes::subst_q_f(crate::check::types::schemes::Inst{.tys_p = crate::prelude::fold(im_p5.qs_p, Map<Text, crate::check::types::Ty>{}, [&](const Map<Text, crate::check::types::Ty>& m_pd, const Text& q_pe) { return crate::prelude::insert(m_pd, q_pe, crate::check::types::Ty(crate::check::types::Ty::TyRigid{q_pe})); }), .rows_p = Map<Text, crate::check::types::Tail>{}, .cols_p = Map<Text, crate::check::types::Col>{}}, im_p5.head_p);
            auto ty_pa = crate::check::types::schemes::subst_q_f(crate::check::types::schemes::Inst{.tys_p = crate::prelude::map_of(std::vector{std::tuple{prism_rtl::deref(ti_p8).param_p, head_p9}}), .rows_p = Map<Text, crate::check::types::Tail>{}, .cols_p = Map<Text, crate::check::types::Col>{}}, prism_rtl::deref(prism_rtl::deref(v_p7).scheme_p).ty_p);
            auto sc_pb = crate::check::types::Scheme{.qs_p = crate::prelude::filter(prism_rtl::deref(prism_rtl::deref(v_p7).scheme_p).qs_p, [&](const Text& q_pf) { return q_pf != prism_rtl::deref(ti_p8).param_p; }), .plain_qs_p = Array<Text>{}, .rqs_p = prism_rtl::deref(prism_rtl::deref(v_p7).scheme_p).rqs_p, .cqs_p = prism_rtl::deref(prism_rtl::deref(v_p7).scheme_p).cqs_p, .cjoins_p = prism_rtl::deref(prism_rtl::deref(v_p7).scheme_p).cjoins_p, .bounds_p = crate::prelude::filter(prism_rtl::deref(prism_rtl::deref(v_p7).scheme_p).bounds_p, [&](const std::tuple<Text, Text>& _p0) {
                auto&& q_pg = std::get<0>(_p0);
                return q_pg != prism_rtl::deref(ti_p8).param_p;
            }), .ty_p = ty_pa};
            auto env2_pc = ({
                crate::check::expr::Env this_ = env_p0;
                this_.givens_p = im_p5.bounds_p;
                (std::move(this_));
            });
            return crate::check::expr::lets::check_clauses_f(env2_pc, st_p1, d_p2.name_p, clauses_p3, sc_pb, d_p2.span_p);
        }
        prism_rtl::unreachable("no arm matched");
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::check::types::St> CheckMethod::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& d_p2 = this->d_p2;
    const auto& clauses_p3 = this->clauses_p3;
    const auto& cls_p4 = this->cls_p4;
    const auto& im_p5 = this->im_p5;
    return ({
        auto&& _m = method_key_o(prism_rtl::deref(env_p0).g_p, cls_p4, prism_rtl::deref(d_p2).name_p);
        prism_rtl::is_none(_m) ? prism_rtl::finished(crate::check::types::recording::err_f(st_p1, Text::lit("mismatch"), prism_rtl::deref(d_p2).span_p, prism_rtl::cat("`^", crate::check::types::bare_name_f(cls_p4), "` has no method `", prism_rtl::deref(d_p2).name_p, "`")))
        : prism_rtl::is_some(_m) ? ({
        auto&& mk_p6 = prism_rtl::some_of(_m);
        ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(prism_rtl::deref(env_p0).g_p).vals_p, mk_p6);
        prism_rtl::is_none(_m) ? prism_rtl::finished(st_p1)
        : prism_rtl::is_some(_m) ? ({
        auto&& v_p7 = prism_rtl::some_of(_m);
        ({
        auto ti_p8 = crate::prelude::or_(crate::prelude::get(prism_rtl::deref(prism_rtl::deref(env_p0).g_p).traits_p, cls_p4), crate::check::env::traits::dummy_trait_p());
        auto clauses_p3x = clauses_p3;
        auto d_p2x = d_p2;
        auto env_p0x = env_p0;
        auto im_p5x = im_p5;
        auto st_p1x = st_p1;
        (crate::prelude::call_then(crate::check::types::schemes::start_subst_q_f(crate::check::types::schemes::Inst{.tys_p = crate::prelude::fold(prism_rtl::deref(im_p5x).qs_p, Map<Text, crate::check::types::Ty>{}, [&](const Map<Text, crate::check::types::Ty>& m_pd, const Text& q_pe) { return crate::prelude::insert(m_pd, q_pe, crate::check::types::Ty(crate::check::types::Ty::TyRigid{q_pe})); }), .rows_p = Map<Text, crate::check::types::Tail>{}, .cols_p = Map<Text, crate::check::types::Col>{}}, prism_rtl::deref(im_p5x).head_p), [=, ti_p8 = std::move(ti_p8), clauses_p3x = std::move(clauses_p3x), d_p2x = std::move(d_p2x), env_p0x = std::move(env_p0x), st_p1x = std::move(st_p1x)](crate::check::types::Ty subst_q_f_10769) {
        return ({
            auto head_p9 = subst_q_f_10769;
            (crate::prelude::call_then(crate::check::types::schemes::start_subst_q_f(crate::check::types::schemes::Inst{.tys_p = crate::prelude::map_of(std::vector{std::tuple{prism_rtl::deref(ti_p8).param_p, head_p9}}), .rows_p = Map<Text, crate::check::types::Tail>{}, .cols_p = Map<Text, crate::check::types::Col>{}}, prism_rtl::deref(prism_rtl::deref(v_p7).scheme_p).ty_p), [=](crate::check::types::Ty subst_q_f_10887) {
            return ({
                auto ty_pa = subst_q_f_10887;
                auto sc_pb = crate::check::types::Scheme{.qs_p = crate::prelude::filter(prism_rtl::deref(prism_rtl::deref(v_p7).scheme_p).qs_p, [&](const Text& q_pf) { return q_pf != prism_rtl::deref(ti_p8).param_p; }), .plain_qs_p = Array<Text>{}, .rqs_p = prism_rtl::deref(prism_rtl::deref(v_p7).scheme_p).rqs_p, .cqs_p = prism_rtl::deref(prism_rtl::deref(v_p7).scheme_p).cqs_p, .cjoins_p = prism_rtl::deref(prism_rtl::deref(v_p7).scheme_p).cjoins_p, .bounds_p = crate::prelude::filter(prism_rtl::deref(prism_rtl::deref(v_p7).scheme_p).bounds_p, [&](const std::tuple<Text, Text>& _p0) {
                    auto&& q_pg = std::get<0>(_p0);
                    return q_pg != prism_rtl::deref(ti_p8).param_p;
                }), .ty_p = ty_pa};
                auto env2_pc = ({
                    crate::check::expr::Env this_ = env_p0x;
                    this_.givens_p = prism_rtl::deref(im_p5x).bounds_p;
                    (std::move(this_));
                });
                (prism_rtl::more(prism_rtl::rc(crate::check::expr::lets::CheckClauses(env2_pc, st_p1x, prism_rtl::deref(d_p2x).name_p, clauses_p3x, sc_pb, prism_rtl::deref(d_p2x).span_p))));
            });
        }));
        });
    }));
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CheckMethod, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_check_method_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::check::env::Def d_p2, Array<crate::syntax::decls::FnClause> clauses_p3, Text cls_p4, crate::check::env::ImplInfo im_p5) {
    return prism_rtl::make_rc<CheckMethod>(env_p0, st_p1, d_p2, clauses_p3, cls_p4, im_p5);
}


/// RootRow: unbounded fn G, St, [Text] -> ((Text, St))
std::tuple<Text, crate::check::types::St> root_row_f(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const Array<Text>& world_p2) {
    auto&& _m = crate::prelude::get(g_p0.mods_p, Text::lit(""));
    if (prism_rtl::is_none(_m)) {
        return std::tuple{Text::lit(""), st_p1};
    }
    if (prism_rtl::is_some(_m)) {
        auto&& info_p3 = prism_rtl::some_of(_m);
        auto shown_p4 = crate::check::types::show_row_f(prism_rtl::deref(info_p3).emit_rw_p);
        return crate::prelude::len(world_p2) == Nat(0u)
            ? std::tuple{shown_p4, st_p1}
            : ({
            auto missing_p5 = crate::prelude::filter(prism_rtl::deref(prism_rtl::deref(info_p3).emit_rw_p).fams_p, [&](const Text& f_p6) { return !crate::check::types::has_text_f(world_p2, f_p6); });
            (crate::prelude::len(missing_p5) == Nat(0u)
            ? std::tuple{shown_p4, st_p1}
            : ({
            auto s0_p7 = ({
                crate::check::types::St this_ = st_p1;
                this_.file_p = prism_rtl::deref(info_p3).file_p;
                (std::move(this_));
            });
            std::tuple{shown_p4, crate::check::types::recording::err_fix_f(s0_p7, Text::lit("world-row"), prism_rtl::deref(prism_rtl::deref(info_p3).tree_p).span_p, prism_rtl::cat("the program emits ", crate::syntax::lexer::chars::join_f(crate::prelude::each(missing_p5, [&](const Text& f_p8) { return prism_rtl::cat("`", f_p8, ".*`"); }), Text::lit(", ")), ", which this World does not answer"), Text::lit("host the tags it cannot answer, or run under a World that answers them"))};
        }));
        });
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<Text, crate::check::types::St>> RootRow::cycle() const {
    const auto& g_p0 = this->g_p0;
    const auto& st_p1 = this->st_p1;
    const auto& world_p2 = this->world_p2;
    return ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(g_p0).mods_p, Text::lit(""));
        prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{Text::lit(""), st_p1})
        : prism_rtl::is_some(_m) ? ({
        auto&& info_p3 = prism_rtl::some_of(_m);
        ({
        auto shown_p4 = crate::check::types::show_row_f(prism_rtl::deref(info_p3).emit_rw_p);
        (crate::prelude::len(world_p2) == Nat(0u)
        ? prism_rtl::finished(std::tuple{shown_p4, st_p1})
        : ({
        auto missing_p5 = crate::prelude::filter(prism_rtl::deref(prism_rtl::deref(info_p3).emit_rw_p).fams_p, [&](const Text& f_p6) { return !crate::check::types::has_text_f(world_p2, f_p6); });
        (crate::prelude::len(missing_p5) == Nat(0u)
        ? prism_rtl::finished(std::tuple{shown_p4, st_p1})
        : ({
        auto s0_p7 = ({
            crate::check::types::St this_ = st_p1;
            this_.file_p = prism_rtl::deref(info_p3).file_p;
            (std::move(this_));
        });
        (prism_rtl::finished(std::tuple{shown_p4, crate::check::types::recording::err_fix_f(s0_p7, Text::lit("world-row"), prism_rtl::deref(prism_rtl::deref(info_p3).tree_p).span_p, prism_rtl::cat("the program emits ", crate::syntax::lexer::chars::join_f(crate::prelude::each(missing_p5, [&](const Text& f_p8) { return prism_rtl::cat("`", f_p8, ".*`"); }), Text::lit(", ")), ", which this World does not answer"), Text::lit("host the tags it cannot answer, or run under a World that answers them"))}));
    }));
    }));
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start RootRow, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Text, crate::check::types::St>> start_root_row_f(crate::check::env::G g_p0, crate::check::types::St st_p1, Array<Text> world_p2) {
    return prism_rtl::make_rc<RootRow>(g_p0, st_p1, world_p2);
}

}  // namespace crate::check
