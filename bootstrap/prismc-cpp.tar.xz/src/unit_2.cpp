// The module `Check`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <check/module.hpp>
#include <check/typed/module.hpp>
#include <program/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Check`, from `target/bootstrap/cpp-src/prismc/check/mod.prism`.
namespace crate::check {

void Report_::show(Printer& p) const {
    p.record("Report", {{"text", text}, {"errors", errors}, {"root_row", root_row}, {"typed", typed}});
}

Pod Report_::to_pod() const {
    return Pod::record("Report", {{"text", prism_rtl::to_pod(text)}, {"errors", prism_rtl::to_pod(errors)}, {"root_row", prism_rtl::to_pod(root_row)}, {"typed", prism_rtl::to_pod(typed)}});
}

Result<Report_> Report_::from_pod(const Pod& whole) {
    return Report_{.text = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "text")))), .errors = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "errors")))), .root_row = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "root_row")))), .typed = TRY(prism_rtl::from_pod<crate::check::typed::TProgram>(TRY(crate::prelude::field(whole, "typed"))))};
}


/// CheckProgram: unbounded fn [Src], [Module], [Text], Nat, Bool, Bool, [CDiag] -> Report
Report_ check_program(const Array<crate::check::errors::Src>& srcs_p0, const Array<crate::syntax::Module>& trees_p1, const Array<Text>& world_p2, const Nat& shown_p3, const bool& recording_p4, const bool& unused_p5, const Array<crate::check::errors::CDiag>& pre_p6) {
    auto [g0a_ph, stb_pi] = crate::check::env::build_g(srcs_p0, trees_p1);
    auto g0_p7 = ({
        crate::check::env::G this_ = g0a_ph;
        this_.prelude_from = shown_p3;
        (std::move(this_));
    });
    auto st0_p8 = ({
        crate::check::types::St this_ = stb_pi;
        this_.recording = recording_p4;
        (std::move(this_));
    });
    auto [g1_pj, st1_pk] = top_lets(g0_p7, st0_p8);
    auto [failed_pr, st2_ps] = run_to_end(fold_job(prism_rtl::deref(g1_pj).defs, std::tuple{Array<Text>{}, st1_pk}, ({
        auto g1_pj_1 = g1_pj;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, crate::check::types::St>>(std::tuple<std::tuple<Array<Text>, crate::check::types::St>, crate::check::env::Def>)>>(prism_rtl::rc([=, g1_pj_1 = std::move(g1_pj_1)](std::tuple<std::tuple<Array<Text>, crate::check::types::St>, crate::check::env::Def> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g1_pj_1_2 = g1_pj_1;
            entered(once_job([=, g1_pj_1_2 = std::move(g1_pj_1_2)]() {
            return ({
                auto [bad_pl, s_pm] = p0;
                auto d_pn = p1;
                ({
                auto before_po = len(prism_rtl::deref(s_pm).diags);
                call_then(start_check_def(g1_pj_1_2, s_pm, d_pn), [=, before_po = std::move(before_po)](crate::check::types::St check_def_2629) {
                return ({
                    auto s2_pp = check_def_2629;
                    auto bad2_pq = len(prism_rtl::deref(s2_pp).diags) > before_po
                        ? crate::prelude::push(bad_pl, prism_rtl::deref(crate::check::shrink::types::own_key(d_pn)).qk)
                        : bad_pl;
                    (prism_rtl::finished(std::tuple{bad2_pq, s2_pp}));
                });
            });
            });
            });
        }));
        });
    }));
    })));
    auto st2b_p9 = ({
        crate::check::types::St this_ = st2_ps;
        this_.level = Nat(0u);
        (std::move(this_));
    });
    auto st3_pa = crate::check::env::traits::default_wants(g1_pj, st2b_p9, Array<std::tuple<Text, Text>>{});
    auto good_pb = filter(prism_rtl::deref(g1_pj).defs, [&](const crate::check::env::Def& d_pt) { return !crate::check::types::has_text(failed_pr, prism_rtl::deref(crate::check::shrink::types::own_key(d_pt)).qk); });
    auto [st4_pu, refs_pv] = crate::check::shrink::shrink_check(g1_pj, st3_pa, good_pb);
    auto [root_row_p10, st5_p11] = root_row(g1_pj, st4_pu, world_p2);
    auto warnings_pc = unused_p5
        ? crate::check::shrink::unused_defs(good_pb, refs_pv, shown_p3)
        : Array<crate::check::errors::CDiag>{};
    auto reached_pd = crate::check::shrink::test_only_reached(srcs_p0, prism_rtl::deref(g1_pj).defs, refs_pv);
    auto diags_pe = crate::check::errors::sort_diags(append(append(append(filter(prism_rtl::deref(st5_p11).diags, [&](const crate::check::errors::CDiag& d_p12) { return d_p12->file < shown_p3; }), warnings_pc), pre_p6), reached_pd));
    auto text_pf = concat(each(diags_pe, [&](const crate::check::errors::CDiag& d_p13) { return crate::check::errors::render_cdiag(srcs_p0, d_p13); }));
    auto typed_pg = recording_p4
        ? typed_of(g1_pj, st5_p11, shown_p3)
        : crate::check::typed::empty_typed();
    return Report_{.text = text_pf, .errors = len(filter(diags_pe, [&](const crate::check::errors::CDiag& d_p14) { return !crate::check::errors::is_warning(d_p14); })), .root_row = root_row_p10, .typed = typed_pg};
}


prism_rtl::Turn<Report_> CheckProgram::cycle() const {
    const auto& srcs_p0 = this->srcs_p0;
    const auto& trees_p1 = this->trees_p1;
    const auto& world_p2 = this->world_p2;
    const auto& shown_p3 = this->shown_p3;
    const auto& recording_p4 = this->recording_p4;
    const auto& unused_p5 = this->unused_p5;
    const auto& pre_p6 = this->pre_p6;
    auto pre_p6_1 = pre_p6;
    auto recording_p4_2 = prism_rtl::deref(recording_p4);
    auto shown_p3_3 = shown_p3;
    auto srcs_p0_4 = srcs_p0;
    auto trees_p1_5 = trees_p1;
    auto unused_p5_6 = prism_rtl::deref(unused_p5);
    auto world_p2_7 = world_p2;
    return call_then(crate::check::env::start_build_g(srcs_p0_4, trees_p1_5), [=](std::tuple<crate::check::env::G, crate::check::types::St> build_g_2188) {
        return ({
            auto [g0a_ph, stb_pi] = build_g_2188;
            auto g0_p7 = ({
                crate::check::env::G this_ = g0a_ph;
                this_.prelude_from = shown_p3_3;
                (std::move(this_));
            });
            auto st0_p8 = ({
                crate::check::types::St this_ = stb_pi;
                this_.recording = recording_p4_2;
                (std::move(this_));
            });
            call_then(start_top_lets(g0_p7, st0_p8), [=](std::tuple<crate::check::env::G, crate::check::types::St> top_lets_2491) {
            return ({
                auto [g1_pj, st1_pk] = top_lets_2491;
                call_value(fold_job(prism_rtl::deref(g1_pj).defs, std::tuple{Array<Text>{}, st1_pk}, ({
                auto g1_pj_8 = g1_pj;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, crate::check::types::St>>(std::tuple<std::tuple<Array<Text>, crate::check::types::St>, crate::check::env::Def>)>>(prism_rtl::rc([=, g1_pj_8 = std::move(g1_pj_8)](std::tuple<std::tuple<Array<Text>, crate::check::types::St>, crate::check::env::Def> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto g1_pj_8_9 = g1_pj_8;
                    entered(once_job([=, g1_pj_8_9 = std::move(g1_pj_8_9)]() {
                    return ({
                        auto [bad_pl, s_pm] = p0;
                        auto d_pn = p1;
                        ({
                        auto before_po = len(prism_rtl::deref(s_pm).diags);
                        call_then(start_check_def(g1_pj_8_9, s_pm, d_pn), [=, before_po = std::move(before_po)](crate::check::types::St check_def_2629) {
                        return ({
                            auto s2_pp = check_def_2629;
                            auto bad2_pq = len(prism_rtl::deref(s2_pp).diags) > before_po
                                ? crate::prelude::push(bad_pl, prism_rtl::deref(crate::check::shrink::types::own_key(d_pn)).qk)
                                : bad_pl;
                            (prism_rtl::finished(std::tuple{bad2_pq, s2_pp}));
                        });
                    });
                    });
                    });
                }));
                });
            }));
            })), [=](std::tuple<Array<Text>, crate::check::types::St> fold_2533) {
                return ({
                    auto [failed_pr, st2_ps] = fold_2533;
                    auto st2b_p9 = ({
                        crate::check::types::St this_ = st2_ps;
                        this_.level = Nat(0u);
                        (std::move(this_));
                    });
                    call_then(crate::check::env::traits::start_default_wants(g1_pj, st2b_p9, Array<std::tuple<Text, Text>>{}), [=](crate::check::types::St default_wants_2812) {
                    return ({
                        auto st3_pa = default_wants_2812;
                        auto good_pb = filter(prism_rtl::deref(g1_pj).defs, [&](const crate::check::env::Def& d_pt) { return !crate::check::types::has_text(failed_pr, prism_rtl::deref(crate::check::shrink::types::own_key(d_pt)).qk); });
                        call_then(crate::check::shrink::start_shrink_check(g1_pj, st3_pa, good_pb), [=](std::tuple<crate::check::types::St, Array<std::tuple<Text, Array<Text>>>> shrink_check_3083) {
                        return ({
                            auto [st4_pu, refs_pv] = shrink_check_3083;
                            call_then(start_root_row(g1_pj, st4_pu, world_p2_7), [=](std::tuple<Text, crate::check::types::St> root_row_3136) {
                            return ({
                                auto [root_row_p10, st5_p11] = root_row_3136;
                                auto warnings_pc = unused_p5_6
                                    ? crate::check::shrink::unused_defs(good_pb, refs_pv, shown_p3_3)
                                    : Array<crate::check::errors::CDiag>{};
                                auto reached_pd = crate::check::shrink::test_only_reached(srcs_p0_4, prism_rtl::deref(g1_pj).defs, refs_pv);
                                auto diags_pe = crate::check::errors::sort_diags(append(append(append(filter(prism_rtl::deref(st5_p11).diags, [&](const crate::check::errors::CDiag& d_p12) { return d_p12->file < shown_p3_3; }), warnings_pc), pre_p6_1), reached_pd));
                                auto text_pf = concat(each(diags_pe, [&](const crate::check::errors::CDiag& d_p13) { return crate::check::errors::render_cdiag(srcs_p0_4, d_p13); }));
                                auto typed_pg = recording_p4_2
                                    ? typed_of(g1_pj, st5_p11, shown_p3_3)
                                    : crate::check::typed::empty_typed();
                                (prism_rtl::finished(Report_{.text = text_pf, .errors = len(filter(diags_pe, [&](const crate::check::errors::CDiag& d_p14) { return !crate::check::errors::is_warning(d_p14); })), .root_row = root_row_p10, .typed = typed_pg}));
                            });
                        });
                        });
                    });
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start CheckProgram, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Report_> start_check_program(Array<crate::check::errors::Src> srcs_p0, Array<crate::syntax::Module> trees_p1, Array<Text> world_p2, Nat shown_p3, bool recording_p4, bool unused_p5, Array<crate::check::errors::CDiag> pre_p6) {
    return prism_rtl::make_rc<CheckProgram>(srcs_p0, trees_p1, world_p2, shown_p3, recording_p4, unused_p5, pre_p6);
}


/// TypedOf: unbounded fn G, St, Nat -> TProgram
crate::check::typed::TProgram typed_of(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const Nat& shown_p2) {
    auto z_p3 = crate::check::types::recording::zonk_typed(st_p1);
    auto vals_p4 = filter(values(g_p0.vals), [&](const crate::check::env::ValInfo& v_p5) { return ((v_p5->file < shown_p2) && (prism_rtl::deref(v_p5).sort != Text::lit("builtin"))) && (or_(crate::prelude::get(g_p0.mods, prism_rtl::deref(v_p5).home), crate::check::env::reading::dummy_mod())->file == v_p5->file); });
    crate::check::typed::TProgram this_ = z_p3;
    this_.defs = run_to_end(each_job(vals_p4, ({
        auto st_p1_1 = st_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::typed::DefNote>(crate::check::env::ValInfo)>>(prism_rtl::rc([=, st_p1_1 = std::move(st_p1_1)](crate::check::env::ValInfo p0) {
        return ({
            auto st_p1_1_2 = st_p1_1;
            entered(once_job([=, st_p1_1_2 = std::move(st_p1_1_2)]() {
            return ({
                auto v_p6 = p0;
                call_then(start_zonk_scheme(st_p1_1_2, prism_rtl::deref(v_p6).scheme), [=](crate::check::types::Scheme zonk_scheme_4112) { return prism_rtl::finished(crate::check::typed::DefNote{.at = crate::check::typed::SrcAt{.file = v_p6->file, .span = prism_rtl::deref(v_p6).span}, .name = prism_rtl::deref(v_p6).qk, .scheme = zonk_scheme_4112}); });
            });
        }));
        });
    })));
    })));
    return this_;
}


prism_rtl::Turn<crate::check::typed::TProgram> TypedOf::cycle() const {
    const auto& g_p0 = this->g_p0;
    const auto& st_p1 = this->st_p1;
    const auto& shown_p2 = this->shown_p2;
    auto g_p0_1 = g_p0;
    auto shown_p2_2 = shown_p2;
    auto st_p1_3 = st_p1;
    return call_then(crate::check::types::recording::start_zonk_typed(st_p1_3), [=](crate::check::typed::TProgram zonk_typed_3855) {
        return ({
            auto z_p3 = zonk_typed_3855;
            auto vals_p4 = filter(values(prism_rtl::deref(g_p0_1).vals), [&](const crate::check::env::ValInfo& v_p5) { return ((v_p5->file < shown_p2_2) && (prism_rtl::deref(v_p5).sort != Text::lit("builtin"))) && (or_(crate::prelude::get(prism_rtl::deref(g_p0_1).mods, prism_rtl::deref(v_p5).home), crate::check::env::reading::dummy_mod())->file == v_p5->file); });
            (prism_rtl::finished(({
            crate::check::typed::TProgram this_ = z_p3;
            this_.defs = run_to_end(each_job(vals_p4, ({
                auto st_p1_3_4 = st_p1_3;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::typed::DefNote>(crate::check::env::ValInfo)>>(prism_rtl::rc([=, st_p1_3_4 = std::move(st_p1_3_4)](crate::check::env::ValInfo p0) {
                return ({
                    auto st_p1_3_4_4 = st_p1_3_4;
                    entered(once_job([=, st_p1_3_4_4 = std::move(st_p1_3_4_4)]() {
                    return ({
                        auto v_p6 = p0;
                        call_then(start_zonk_scheme(st_p1_3_4_4, prism_rtl::deref(v_p6).scheme), [=](crate::check::types::Scheme zonk_scheme_4112) { return prism_rtl::finished(crate::check::typed::DefNote{.at = crate::check::typed::SrcAt{.file = v_p6->file, .span = prism_rtl::deref(v_p6).span}, .name = prism_rtl::deref(v_p6).qk, .scheme = zonk_scheme_4112}); });
                    });
                }));
                });
            })));
            })));
            (std::move(this_));
        })));
        });
    });
}


/// `Start TypedOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::typed::TProgram> start_typed_of(crate::check::env::G g_p0, crate::check::types::St st_p1, Nat shown_p2) {
    return prism_rtl::make_rc<TypedOf>(g_p0, st_p1, shown_p2);
}


/// ZonkScheme: unbounded fn St, Scheme -> Scheme
crate::check::types::Scheme zonk_scheme(const crate::check::types::St& st_p0, const crate::check::types::Scheme& sc_p1) {
    crate::check::types::Scheme this_ = sc_p1;
    this_.ty = crate::check::types::recording::zonk(st_p0, this_.ty);
    return this_;
}


prism_rtl::Turn<crate::check::types::Scheme> ZonkScheme::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& sc_p1 = this->sc_p1;
    return prism_rtl::finished(({
        crate::check::types::Scheme this_ = sc_p1;
        this_.ty = crate::check::types::recording::zonk(st_p0, this_.ty);
        (std::move(this_));
    }));
}


/// `Start ZonkScheme, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::Scheme> start_zonk_scheme(crate::check::types::St st_p0, crate::check::types::Scheme sc_p1) {
    return prism_rtl::make_rc<ZonkScheme>(st_p0, sc_p1);
}


/// TopLets: unbounded fn G, St -> ((G, St))
std::tuple<crate::check::env::G, crate::check::types::St> top_lets(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1) {
    auto unsigned_p2 = filter(g_p0.defs, [&](const crate::check::env::Def& d_p3) { return is_let_def(d_p3) && (!crate::check::env::has_key(g_p0.vals, prism_rtl::deref(d_p3).qk)); });
    auto [g1_pa, st1_pb] = fold(unsigned_p2, std::tuple{g_p0, st_p1}, [&](const std::tuple<crate::check::env::G, crate::check::types::St>& _p0, const crate::check::env::Def& d_p6) {
        auto&& gg_p4 = std::get<0>(_p0);
        auto&& s_p5 = std::get<1>(_p0);
        return ({
            auto [v_p8, s2_p9] = crate::check::types::fresh_var(s_p5, false, prism_rtl::deref(d_p6).name);
            auto gg2_p7 = ({
                crate::check::env::G this_ = gg_p4;
                this_.vals = insert(this_.vals, prism_rtl::deref(d_p6).qk, crate::check::env::ValInfo{.qk = prism_rtl::deref(d_p6).qk, .scheme = crate::check::types::schemes::mono(v_p8), .sort = Text::lit("let"), .has_sig = false, .home = prism_rtl::deref(d_p6).home, .file = d_p6->file, .span = prism_rtl::deref(d_p6).span});
                (std::move(this_));
            });
            std::tuple{gg2_p7, s2_p9};
        });
    });
    return run_to_end(fold_job(unsigned_p2, std::tuple{g1_pa, st1_pb}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::env::G, crate::check::types::St>>(std::tuple<std::tuple<crate::check::env::G, crate::check::types::St>, crate::check::env::Def>)>>(prism_rtl::rc([=](std::tuple<std::tuple<crate::check::env::G, crate::check::types::St>, crate::check::env::Def> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto [gg_pc, s_pd] = p0;
                auto d_pe = p1;
                ({
                auto&& _m = prism_rtl::deref(d_pe).body;
                prism_rtl::is<crate::check::env::DefBody::DbLet>(_m) ? ({
                auto&& l_pf = prism_rtl::as<crate::check::env::DefBody::DbLet>(_m).a0;
                ({
                auto env_pg = def_env(gg_pc, d_pe);
                auto s0_ph = ({
                    crate::check::types::St this_ = s_pd;
                    this_.file = d_pe->file;
                    this_.level = Nat(1u);
                    this_.local_next = Nat(0u);
                    (std::move(this_));
                });
                auto pre_pi = prism_rtl::deref(prism_rtl::deref(or_(crate::prelude::get(prism_rtl::deref(gg_pc).vals, prism_rtl::deref(d_pe).qk), dummy_val())).scheme).ty;
                auto l_pf_1 = l_pf;
                call_then(crate::check::expr::start_check(env_pg, s0_ph, l_pf_1->value, pre_pi), [=](crate::check::types::St check_5241) {
                return ({
                    auto s1_pj = check_5241;
                    call_then(crate::check::env::traits::start_solve_wants(gg_pc, s1_pj, Array<std::tuple<Text, Text>>{}, false), [=](crate::check::types::St solve_wants_5290) {
                    return ({
                        auto s2_pk = solve_wants_5290;
                        auto s3_pl = ({
                            crate::check::types::St this_ = s2_pk;
                            this_.level = Nat(0u);
                            (std::move(this_));
                        });
                        call_then(crate::check::types::recording::start_zonk(s3_pl, pre_pi), [=](crate::check::types::Ty zonk_5403) {
                        return ({
                            auto t_pm = zonk_5403;
                            call_then(crate::check::expr::lets::start_wants_above(s3_pl, t_pm, crate::check::expr::is_lambda(l_pf_1->value)), [=](std::tuple<Array<Nat>, Array<std::tuple<Nat, Text>>, crate::check::types::St> wants_above_5455) {
                            return ({
                                auto [keep_po, bounds_pp, s4_pq] = wants_above_5455;
                                call_then(crate::check::types::schemes::start_holds_node(s4_pq, t_pm), [=](bool holds_node_5524) {
                                return ({
                                    auto [sc_pr, s5_ps] = holds_node_5524
                                        ? std::tuple{crate::check::types::schemes::mono(t_pm), s4_pq}
                                        : crate::check::types::schemes::generalize(s4_pq, t_pm, keep_po, bounds_pp);
                                    auto gg2_pn = ({
                                        crate::check::env::G this_ = gg_pc;
                                        this_.vals = insert(this_.vals, prism_rtl::deref(d_pe).qk, crate::check::env::ValInfo{.qk = prism_rtl::deref(d_pe).qk, .scheme = sc_pr, .sort = Text::lit("let"), .has_sig = false, .home = prism_rtl::deref(d_pe).home, .file = d_pe->file, .span = prism_rtl::deref(d_pe).span});
                                        (std::move(this_));
                                    });
                                    call_then(crate::check::types::colors::start_check_colors(s5_ps), [=, gg2_pn = std::move(gg2_pn)](crate::check::types::St check_colors_5843) { return call_then(crate::check::env::traits::start_resolve_fields(gg_pc, check_colors_5843, true), [=](crate::check::types::St resolve_fields_5824) { return call_then(crate::check::types::unify::start_layer_questions(resolve_fields_5824), [=](crate::check::types::St layer_questions_5808) { return call_then(crate::check::passes::start_discharge_incls(gg_pc, layer_questions_5808, Nat(0u)), [=](crate::check::types::St discharge_incls_5788) { return prism_rtl::finished(std::tuple{gg2_pn, discharge_incls_5788}); }); }); }); });
                                });
                            });
                            });
                        });
                        });
                    });
                    });
                });
                });
            });
            });
            })
                : prism_rtl::finished(std::tuple{gg_pc, s_pd});
            });
            });
        }));
    }))));
}


prism_rtl::Turn<std::tuple<crate::check::env::G, crate::check::types::St>> TopLets::cycle() const {
    const auto& g_p0 = this->g_p0;
    const auto& st_p1 = this->st_p1;
    auto unsigned_p2 = filter(prism_rtl::deref(g_p0).defs, [&](const crate::check::env::Def& d_p3) { return is_let_def(d_p3) && (!crate::check::env::has_key(prism_rtl::deref(g_p0).vals, prism_rtl::deref(d_p3).qk)); });
    auto [g1_pa, st1_pb] = fold(unsigned_p2, std::tuple{g_p0, st_p1}, [&](const std::tuple<crate::check::env::G, crate::check::types::St>& _p0, const crate::check::env::Def& d_p6) {
        auto&& gg_p4 = std::get<0>(_p0);
        auto&& s_p5 = std::get<1>(_p0);
        return ({
            auto [v_p8, s2_p9] = crate::check::types::fresh_var(s_p5, false, prism_rtl::deref(d_p6).name);
            auto gg2_p7 = ({
                crate::check::env::G this_ = gg_p4;
                this_.vals = insert(this_.vals, prism_rtl::deref(d_p6).qk, crate::check::env::ValInfo{.qk = prism_rtl::deref(d_p6).qk, .scheme = crate::check::types::schemes::mono(v_p8), .sort = Text::lit("let"), .has_sig = false, .home = prism_rtl::deref(d_p6).home, .file = d_p6->file, .span = prism_rtl::deref(d_p6).span});
                (std::move(this_));
            });
            std::tuple{gg2_p7, s2_p9};
        });
    });
    return fold_job(unsigned_p2, std::tuple{g1_pa, st1_pb}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::env::G, crate::check::types::St>>(std::tuple<std::tuple<crate::check::env::G, crate::check::types::St>, crate::check::env::Def>)>>(prism_rtl::rc([=](std::tuple<std::tuple<crate::check::env::G, crate::check::types::St>, crate::check::env::Def> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto [gg_pc, s_pd] = p0;
                auto d_pe = p1;
                ({
                auto&& _m = prism_rtl::deref(d_pe).body;
                prism_rtl::is<crate::check::env::DefBody::DbLet>(_m) ? ({
                auto&& l_pf = prism_rtl::as<crate::check::env::DefBody::DbLet>(_m).a0;
                ({
                auto env_pg = def_env(gg_pc, d_pe);
                auto s0_ph = ({
                    crate::check::types::St this_ = s_pd;
                    this_.file = d_pe->file;
                    this_.level = Nat(1u);
                    this_.local_next = Nat(0u);
                    (std::move(this_));
                });
                auto pre_pi = prism_rtl::deref(prism_rtl::deref(or_(crate::prelude::get(prism_rtl::deref(gg_pc).vals, prism_rtl::deref(d_pe).qk), dummy_val())).scheme).ty;
                auto l_pf_1 = l_pf;
                call_then(crate::check::expr::start_check(env_pg, s0_ph, l_pf_1->value, pre_pi), [=](crate::check::types::St check_5241) {
                return ({
                    auto s1_pj = check_5241;
                    call_then(crate::check::env::traits::start_solve_wants(gg_pc, s1_pj, Array<std::tuple<Text, Text>>{}, false), [=](crate::check::types::St solve_wants_5290) {
                    return ({
                        auto s2_pk = solve_wants_5290;
                        auto s3_pl = ({
                            crate::check::types::St this_ = s2_pk;
                            this_.level = Nat(0u);
                            (std::move(this_));
                        });
                        call_then(crate::check::types::recording::start_zonk(s3_pl, pre_pi), [=](crate::check::types::Ty zonk_5403) {
                        return ({
                            auto t_pm = zonk_5403;
                            call_then(crate::check::expr::lets::start_wants_above(s3_pl, t_pm, crate::check::expr::is_lambda(l_pf_1->value)), [=](std::tuple<Array<Nat>, Array<std::tuple<Nat, Text>>, crate::check::types::St> wants_above_5455) {
                            return ({
                                auto [keep_po, bounds_pp, s4_pq] = wants_above_5455;
                                call_then(crate::check::types::schemes::start_holds_node(s4_pq, t_pm), [=](bool holds_node_5524) {
                                return ({
                                    auto [sc_pr, s5_ps] = holds_node_5524
                                        ? std::tuple{crate::check::types::schemes::mono(t_pm), s4_pq}
                                        : crate::check::types::schemes::generalize(s4_pq, t_pm, keep_po, bounds_pp);
                                    auto gg2_pn = ({
                                        crate::check::env::G this_ = gg_pc;
                                        this_.vals = insert(this_.vals, prism_rtl::deref(d_pe).qk, crate::check::env::ValInfo{.qk = prism_rtl::deref(d_pe).qk, .scheme = sc_pr, .sort = Text::lit("let"), .has_sig = false, .home = prism_rtl::deref(d_pe).home, .file = d_pe->file, .span = prism_rtl::deref(d_pe).span});
                                        (std::move(this_));
                                    });
                                    call_then(crate::check::types::colors::start_check_colors(s5_ps), [=, gg2_pn = std::move(gg2_pn)](crate::check::types::St check_colors_5843) { return call_then(crate::check::env::traits::start_resolve_fields(gg_pc, check_colors_5843, true), [=](crate::check::types::St resolve_fields_5824) { return call_then(crate::check::types::unify::start_layer_questions(resolve_fields_5824), [=](crate::check::types::St layer_questions_5808) { return call_then(crate::check::passes::start_discharge_incls(gg_pc, layer_questions_5808, Nat(0u)), [=](crate::check::types::St discharge_incls_5788) { return prism_rtl::finished(std::tuple{gg2_pn, discharge_incls_5788}); }); }); }); });
                                });
                            });
                            });
                        });
                        });
                    });
                    });
                });
                });
            });
            });
            })
                : prism_rtl::finished(std::tuple{gg_pc, s_pd});
            });
            });
        }));
    })))->cycle();
}


/// `Start TopLets, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::env::G, crate::check::types::St>> start_top_lets(crate::check::env::G g_p0, crate::check::types::St st_p1) {
    return prism_rtl::make_rc<TopLets>(g_p0, st_p1);
}


/// let dummyVal
crate::check::env::ValInfo dummy_val() {
    return crate::check::env::ValInfo{.qk = Text::lit(""), .scheme = crate::check::types::schemes::mono(crate::check::types::Ty(crate::check::types::Ty::TyErr{})), .sort = Text::lit(""), .has_sig = false, .home = Text::lit(""), .file = Nat(0u), .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}};
}


/// IsLetDef: fn Def -> Bool
bool is_let_def(const crate::check::env::Def& d_p0) {
    auto&& _m = d_p0.body;
    if (prism_rtl::is<crate::check::env::DefBody::DbLet>(_m)) {
        return true;
    }
    {
        return false;
    }
}


/// DefEnv: fn G, Def -> Env
crate::check::expr::Env def_env(const crate::check::env::G& g_p0, const crate::check::env::Def& d_p1) {
    auto info_p2 = or_(crate::prelude::get(g_p0.mods, d_p1.home), crate::check::env::reading::dummy_mod());
    auto scope_p3 = ({
        __label__ _done;
        prism_rtl::Slot<crate::check::types::Rw> _v;
        auto&& _m = prism_rtl::deref(prism_rtl::deref(info_p2).emit_rw).tail;
        if (prism_rtl::is<crate::check::types::Tail::TlQ>(_m)) {
            auto&& v_p4 = prism_rtl::as<crate::check::types::Tail::TlQ>(_m).a0;
            _v.set(crate::check::types::Rw{.fams = prism_rtl::deref(prism_rtl::deref(info_p2).emit_rw).fams, .minus = Array<Text>{}, .tail = crate::check::types::Tail(crate::check::types::Tail::TlRigid{v_p4})});
            goto _done;
        }
        {
            _v.set(prism_rtl::deref(info_p2).emit_rw);
            goto _done;
        }
    _done:
        _v.take();
    });
    return crate::check::expr::Env{.g = g_p0, .home = d_p1.home, .file = d_p1.file, .src = or_(index(g_p0.srcs, d_p1.file), crate::check::errors::mk_src(Text::lit(""), Text::lit(""))), .locals = Map<Text, crate::check::types::Scheme>{}, .scope = scope_p3, .givens = Array<std::tuple<Text, Text>>{}, .mark = Text::lit(""), .in_update = false, .def_name = d_p1.name, .refine = Map<Text, crate::check::types::Ty>{}, .pending = Array<Text>{}, .ids = Map<Text, Nat>{}};
}


/// CheckDef: unbounded fn G, St, Def -> St
crate::check::types::St check_def(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const crate::check::env::Def& d_p2) {
    auto env_p3 = def_env(g_p0, d_p2);
    auto incls_before_p4 = len(st_p1.incls);
    auto s0_p5 = ({
        crate::check::types::St this_ = st_p1;
        this_.file = d_p2.file;
        this_.level = Nat(1u);
        this_.local_next = Nat(0u);
        this_.color = crate::check::types::Col(crate::check::types::Col::CBound{});
        this_.color_why = Text::lit("");
        this_.color_flex = Array<std::tuple<crate::check::types::Col, Text, crate::syntax::Range>>{};
        this_.cleqs = Array<crate::check::types::CLeq>{};
        (std::move(this_));
    });
    auto s1_p6 = ({
        __label__ _done;
        prism_rtl::Slot<crate::check::types::St> _v;
        auto&& _m = d_p2.body;
        if (prism_rtl::is<crate::check::env::DefBody::DbFn>(_m)) {
            auto&& clauses_pa = prism_rtl::as<crate::check::env::DefBody::DbFn>(_m).a0;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<crate::check::types::St> _v;
                auto&& _m = crate::prelude::get(g_p0.vals, d_p2.qk);
                if (prism_rtl::is_some(_m)) {
                    auto&& v_pb = prism_rtl::some_of(_m);
                    _v.set(crate::check::expr::lets::check_clauses(env_p3, s0_p5, d_p2.name, clauses_pa, prism_rtl::deref(v_pb).scheme, d_p2.span));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(s0_p5);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is<crate::check::env::DefBody::DbWidget>(_m)) {
            auto&& w_pc = prism_rtl::as<crate::check::env::DefBody::DbWidget>(_m).a0;
            _v.set(check_widget_def(env_p3, s0_p5, d_p2, w_pc));
            goto _done;
        }
        if (prism_rtl::is<crate::check::env::DefBody::DbLet>(_m)) {
            auto&& l_pd = prism_rtl::as<crate::check::env::DefBody::DbLet>(_m).a0;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<crate::check::types::St> _v;
                auto&& _m = crate::prelude::get(g_p0.vals, d_p2.qk);
                if (prism_rtl::is_some(_m)) {
                    auto&& v_pe = prism_rtl::some_of(_m);
                    _v.set(prism_rtl::deref(v_pe).has_sig
                        ? crate::check::expr::check(env_p3, s0_p5, l_pd->value, crate::check::types::schemes::skolemize(prism_rtl::deref(v_pe).scheme))
                        : s0_p5);
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(s0_p5);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is<crate::check::env::DefBody::DbMethod>(_m)) {
            auto&& clauses_pf = prism_rtl::as<crate::check::env::DefBody::DbMethod>(_m).a0;
            auto&& cls_pg = prism_rtl::as<crate::check::env::DefBody::DbMethod>(_m).a1;
            auto&& im_ph = prism_rtl::as<crate::check::env::DefBody::DbMethod>(_m).a2;
            _v.set(check_method(env_p3, s0_p5, d_p2, clauses_pf, cls_pg, im_ph));
            goto _done;
        }
        if (prism_rtl::is<crate::check::env::DefBody::DbDefault>(_m)) {
            auto&& clauses_pi = prism_rtl::as<crate::check::env::DefBody::DbDefault>(_m).a0;
            auto&& cls_pj = prism_rtl::as<crate::check::env::DefBody::DbDefault>(_m).a1;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<crate::check::types::St> _v;
                auto&& _m = method_key(g_p0, cls_pj, d_p2.name);
                if (prism_rtl::is_some(_m)) {
                    auto&& mk_pk = prism_rtl::some_of(_m);
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<crate::check::types::St> _v;
                        auto&& _m = crate::prelude::get(g_p0.vals, mk_pk);
                        if (prism_rtl::is_some(_m)) {
                            auto&& v_pl = prism_rtl::some_of(_m);
                            _v.set(crate::check::expr::lets::check_clauses(env_p3, s0_p5, d_p2.name, clauses_pi, prism_rtl::deref(v_pl).scheme, d_p2.span));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(s0_p5);
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(s0_p5);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is<crate::check::env::DefBody::DbCheck>(_m)) {
            auto&& c_pm = prism_rtl::as<crate::check::env::DefBody::DbCheck>(_m).a0;
            _v.set(run_to_end(fold_job(prism_rtl::deref(c_pm).lines, s0_p5, ({
                auto env_p3_1 = env_p3;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::decls::CheckLine>)>>(prism_rtl::rc([=, env_p3_1 = std::move(env_p3_1)](std::tuple<crate::check::types::St, crate::syntax::decls::CheckLine> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto env_p3_1_2 = env_p3_1;
                    entered(once_job([=, env_p3_1_2 = std::move(env_p3_1_2)]() {
                    return ({
                        auto s_pn = p0;
                        auto line_po = p1;
                        call_then(crate::check::expr::start_infer(env_p3_1_2, s_pn, prism_rtl::deref(line_po).expr), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_7891) {
                        return ({
                            auto [t_pp, s2_pq] = infer_7891;
                            ({
                            auto&& _m = prism_rtl::deref(line_po).pattern;
                            prism_rtl::is_some(_m) ? ({
                            auto&& p_pr = prism_rtl::some_of(_m);
                            ({
                            auto p_pr_2 = p_pr;
                            call_then(crate::check::expr::patterns::start_bind_pattern(env_p3_1_2, s2_pq, p_pr_2, t_pp, true), [=](std::tuple<crate::check::expr::Env, crate::check::types::St> bind_pattern_8010) {
                            return ({
                                auto&& _s3_ps = bind_pattern_8010;
                                auto&& s3_ps = std::get<1>(_s3_ps);
                                (prism_rtl::finished(s3_ps));
                            });
                        });
                        });
                        })
                            : prism_rtl::is_none(_m) ? prism_rtl::finished(s2_pq)
                            : throw prism_rtl::Panic("no arm matched");
                        });
                        });
                    });
                    });
                }));
                });
            })));
            }))));
            goto _done;
        }
        if (prism_rtl::is<crate::check::env::DefBody::DbTest>(_m)) {
            auto&& t_pt = prism_rtl::as<crate::check::env::DefBody::DbTest>(_m).a0;
            _v.set(({
                auto [bt_pu, s2_pv] = crate::check::expr::infer(env_p3, s0_p5, prism_rtl::deref(t_pt).blueprint);
                ({
                __label__ _done;
                prism_rtl::Slot<crate::check::types::St> _v;
                auto&& _m = crate::check::types::recording::walk(s2_pv, bt_pu);
                if (prism_rtl::is<crate::check::types::Ty::TyAt>(_m)) {
                    _v.set(s2_pv);
                    goto _done;
                }
                if (prism_rtl::is<crate::check::types::Ty::TyErr>(_m)) {
                    _v.set(s2_pv);
                    goto _done;
                }
                {
                    auto&& other_p10 = _m;
                    _v.set(crate::check::types::recording::err(s2_pv, Text::lit("mismatch"), prism_rtl::deref(prism_rtl::deref(t_pt).blueprint).span, prism_rtl::cat("a test builds a blueprint; this is `", crate::check::types::show_ty(s2_pv, other_p10), "`")));
                    goto _done;
                }
            _done:
                _v.take();
            });
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto solved_p7 = crate::check::types::colors::check_colors(crate::check::env::traits::solve_wants(g_p0, s1_p6, prism_rtl::deref(env_p3).givens, false));
    auto defaulted_p8 = crate::check::types::unify::layer_questions(crate::check::env::traits::resolve_fields(g_p0, default_def(g_p0, solved_p7), true));
    auto discharged_p9 = crate::check::passes::discharge_incls(g_p0, defaulted_p8, incls_before_p4);
    crate::check::types::St this_ = discharged_p9;
    this_.level = Nat(0u);
    return this_;
}


prism_rtl::Turn<crate::check::types::St> CheckDef::cycle() const {
    const auto& g_p0 = this->g_p0;
    const auto& st_p1 = this->st_p1;
    const auto& d_p2 = this->d_p2;
    auto env_p3 = def_env(g_p0, d_p2);
    auto incls_before_p4 = len(prism_rtl::deref(st_p1).incls);
    auto s0_p5 = ({
        crate::check::types::St this_ = st_p1;
        this_.file = d_p2->file;
        this_.level = Nat(1u);
        this_.local_next = Nat(0u);
        this_.color = crate::check::types::Col(crate::check::types::Col::CBound{});
        this_.color_why = Text::lit("");
        this_.color_flex = Array<std::tuple<crate::check::types::Col, Text, crate::syntax::Range>>{};
        this_.cleqs = Array<crate::check::types::CLeq>{};
        (std::move(this_));
    });
    auto s1_p6 = ({
        __label__ _done;
        prism_rtl::Slot<crate::check::types::St> _v;
        auto&& _m = prism_rtl::deref(d_p2).body;
        if (prism_rtl::is<crate::check::env::DefBody::DbFn>(_m)) {
            auto&& clauses_pa = prism_rtl::as<crate::check::env::DefBody::DbFn>(_m).a0;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<crate::check::types::St> _v;
                auto&& _m = crate::prelude::get(prism_rtl::deref(g_p0).vals, prism_rtl::deref(d_p2).qk);
                if (prism_rtl::is_some(_m)) {
                    auto&& v_pb = prism_rtl::some_of(_m);
                    _v.set(crate::check::expr::lets::check_clauses(env_p3, s0_p5, prism_rtl::deref(d_p2).name, clauses_pa, prism_rtl::deref(v_pb).scheme, prism_rtl::deref(d_p2).span));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(s0_p5);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is<crate::check::env::DefBody::DbWidget>(_m)) {
            auto&& w_pc = prism_rtl::as<crate::check::env::DefBody::DbWidget>(_m).a0;
            _v.set(check_widget_def(env_p3, s0_p5, d_p2, w_pc));
            goto _done;
        }
        if (prism_rtl::is<crate::check::env::DefBody::DbLet>(_m)) {
            auto&& l_pd = prism_rtl::as<crate::check::env::DefBody::DbLet>(_m).a0;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<crate::check::types::St> _v;
                auto&& _m = crate::prelude::get(prism_rtl::deref(g_p0).vals, prism_rtl::deref(d_p2).qk);
                if (prism_rtl::is_some(_m)) {
                    auto&& v_pe = prism_rtl::some_of(_m);
                    _v.set(prism_rtl::deref(v_pe).has_sig
                        ? crate::check::expr::check(env_p3, s0_p5, l_pd->value, crate::check::types::schemes::skolemize(prism_rtl::deref(v_pe).scheme))
                        : s0_p5);
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(s0_p5);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is<crate::check::env::DefBody::DbMethod>(_m)) {
            auto&& clauses_pf = prism_rtl::as<crate::check::env::DefBody::DbMethod>(_m).a0;
            auto&& cls_pg = prism_rtl::as<crate::check::env::DefBody::DbMethod>(_m).a1;
            auto&& im_ph = prism_rtl::as<crate::check::env::DefBody::DbMethod>(_m).a2;
            _v.set(check_method(env_p3, s0_p5, d_p2, clauses_pf, cls_pg, im_ph));
            goto _done;
        }
        if (prism_rtl::is<crate::check::env::DefBody::DbDefault>(_m)) {
            auto&& clauses_pi = prism_rtl::as<crate::check::env::DefBody::DbDefault>(_m).a0;
            auto&& cls_pj = prism_rtl::as<crate::check::env::DefBody::DbDefault>(_m).a1;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<crate::check::types::St> _v;
                auto&& _m = method_key(g_p0, cls_pj, prism_rtl::deref(d_p2).name);
                if (prism_rtl::is_some(_m)) {
                    auto&& mk_pk = prism_rtl::some_of(_m);
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<crate::check::types::St> _v;
                        auto&& _m = crate::prelude::get(prism_rtl::deref(g_p0).vals, mk_pk);
                        if (prism_rtl::is_some(_m)) {
                            auto&& v_pl = prism_rtl::some_of(_m);
                            _v.set(crate::check::expr::lets::check_clauses(env_p3, s0_p5, prism_rtl::deref(d_p2).name, clauses_pi, prism_rtl::deref(v_pl).scheme, prism_rtl::deref(d_p2).span));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(s0_p5);
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(s0_p5);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is<crate::check::env::DefBody::DbCheck>(_m)) {
            auto&& c_pm = prism_rtl::as<crate::check::env::DefBody::DbCheck>(_m).a0;
            _v.set(run_to_end(fold_job(prism_rtl::deref(c_pm).lines, s0_p5, ({
                auto env_p3_1 = env_p3;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::decls::CheckLine>)>>(prism_rtl::rc([=, env_p3_1 = std::move(env_p3_1)](std::tuple<crate::check::types::St, crate::syntax::decls::CheckLine> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto env_p3_1_2 = env_p3_1;
                    entered(once_job([=, env_p3_1_2 = std::move(env_p3_1_2)]() {
                    return ({
                        auto s_pn = p0;
                        auto line_po = p1;
                        call_then(crate::check::expr::start_infer(env_p3_1_2, s_pn, prism_rtl::deref(line_po).expr), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_7891) {
                        return ({
                            auto [t_pp, s2_pq] = infer_7891;
                            ({
                            auto&& _m = prism_rtl::deref(line_po).pattern;
                            prism_rtl::is_some(_m) ? ({
                            auto&& p_pr = prism_rtl::some_of(_m);
                            ({
                            auto p_pr_2 = p_pr;
                            call_then(crate::check::expr::patterns::start_bind_pattern(env_p3_1_2, s2_pq, p_pr_2, t_pp, true), [=](std::tuple<crate::check::expr::Env, crate::check::types::St> bind_pattern_8010) {
                            return ({
                                auto&& _s3_ps = bind_pattern_8010;
                                auto&& s3_ps = std::get<1>(_s3_ps);
                                (prism_rtl::finished(s3_ps));
                            });
                        });
                        });
                        })
                            : prism_rtl::is_none(_m) ? prism_rtl::finished(s2_pq)
                            : throw prism_rtl::Panic("no arm matched");
                        });
                        });
                    });
                    });
                }));
                });
            })));
            }))));
            goto _done;
        }
        if (prism_rtl::is<crate::check::env::DefBody::DbTest>(_m)) {
            auto&& t_pt = prism_rtl::as<crate::check::env::DefBody::DbTest>(_m).a0;
            _v.set(({
                auto [bt_pu, s2_pv] = crate::check::expr::infer(env_p3, s0_p5, prism_rtl::deref(t_pt).blueprint);
                ({
                __label__ _done;
                prism_rtl::Slot<crate::check::types::St> _v;
                auto&& _m = crate::check::types::recording::walk(s2_pv, bt_pu);
                if (prism_rtl::is<crate::check::types::Ty::TyAt>(_m)) {
                    _v.set(s2_pv);
                    goto _done;
                }
                if (prism_rtl::is<crate::check::types::Ty::TyErr>(_m)) {
                    _v.set(s2_pv);
                    goto _done;
                }
                {
                    auto&& other_p10 = _m;
                    _v.set(crate::check::types::recording::err(s2_pv, Text::lit("mismatch"), prism_rtl::deref(prism_rtl::deref(t_pt).blueprint).span, prism_rtl::cat("a test builds a blueprint; this is `", crate::check::types::show_ty(s2_pv, other_p10), "`")));
                    goto _done;
                }
            _done:
                _v.take();
            });
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto g_p0_1 = g_p0;
    return call_then(crate::check::env::traits::start_solve_wants(g_p0_1, s1_p6, prism_rtl::deref(env_p3).givens, false), [=](crate::check::types::St solve_wants_8409) {
        return call_then(crate::check::types::colors::start_check_colors(solve_wants_8409), [=](crate::check::types::St check_colors_8396) {
            return ({
                auto solved_p7 = check_colors_8396;
                call_then(start_default_def(g_p0_1, solved_p7), [=](crate::check::types::St default_def_8500) {
                return call_then(crate::check::env::traits::start_resolve_fields(g_p0_1, default_def_8500, true), [=](crate::check::types::St resolve_fields_8482) {
                    return call_then(crate::check::types::unify::start_layer_questions(resolve_fields_8482), [=](crate::check::types::St layer_questions_8466) {
                        return ({
                            auto defaulted_p8 = layer_questions_8466;
                            call_then(crate::check::passes::start_discharge_incls(g_p0_1, defaulted_p8, incls_before_p4), [=](crate::check::types::St discharge_incls_8550) {
                            return ({
                                auto discharged_p9 = discharge_incls_8550;
                                (prism_rtl::finished(({
                                crate::check::types::St this_ = discharged_p9;
                                this_.level = Nat(0u);
                                (std::move(this_));
                            })));
                            });
                        });
                        });
                    });
                });
            });
            });
        });
    });
}


/// `Start CheckDef, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_check_def(crate::check::env::G g_p0, crate::check::types::St st_p1, crate::check::env::Def d_p2) {
    return prism_rtl::make_rc<CheckDef>(g_p0, st_p1, d_p2);
}


/// DefaultDef: unbounded fn G, St -> St
crate::check::types::St default_def(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1) {
    auto mine_p2 = run_to_end(filter_job(st_p1.wants, ({
        auto st_p1_1 = st_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(crate::check::types::Want)>>(prism_rtl::rc([=, st_p1_1 = std::move(st_p1_1)](crate::check::types::Want p0) {
        return ({
            auto st_p1_1_2 = st_p1_1;
            entered(once_job([=, st_p1_1_2 = std::move(st_p1_1_2)]() {
            return ({
                auto w_p6 = p0;
                call_then(crate::check::types::recording::start_walk(st_p1_1_2, prism_rtl::deref(w_p6).ty), [=](crate::check::types::Ty walk_8872) {
                return ({
                    prism_rtl::is<crate::check::types::Ty::TyFlex>(walk_8872) ? ({
                    auto&& n_p7 = prism_rtl::as<crate::check::types::Ty::TyFlex>(walk_8872).a0;
                    prism_rtl::finished(prism_rtl::deref(crate::check::types::recording::info_of(st_p1_1_2, n_p7)).level >= Nat(1u));
                })
                    : prism_rtl::finished(true);
                });
            });
            });
        }));
        });
    })));
    })));
    auto theirs_p3 = run_to_end(filter_job(st_p1.wants, ({
        auto st_p1_1 = st_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(crate::check::types::Want)>>(prism_rtl::rc([=, st_p1_1 = std::move(st_p1_1)](crate::check::types::Want p0) {
        return ({
            auto st_p1_1_2 = st_p1_1;
            entered(once_job([=, st_p1_1_2 = std::move(st_p1_1_2)]() {
            return ({
                auto w_p8 = p0;
                call_then(crate::check::types::recording::start_walk(st_p1_1_2, prism_rtl::deref(w_p8).ty), [=](crate::check::types::Ty walk_9000) {
                return ({
                    prism_rtl::is<crate::check::types::Ty::TyFlex>(walk_9000) ? ({
                    auto&& n_p9 = prism_rtl::as<crate::check::types::Ty::TyFlex>(walk_9000).a0;
                    prism_rtl::finished(prism_rtl::deref(crate::check::types::recording::info_of(st_p1_1_2, n_p9)).level < Nat(1u));
                })
                    : prism_rtl::finished(false);
                });
            });
            });
        }));
        });
    })));
    })));
    auto st1_p4 = ({
        crate::check::types::St this_ = st_p1;
        this_.wants = mine_p2;
        (std::move(this_));
    });
    auto s2_p5 = crate::check::env::traits::default_wants(g_p0, st1_p4, Array<std::tuple<Text, Text>>{});
    crate::check::types::St this_ = s2_p5;
    this_.wants = append(theirs_p3, this_.wants);
    return this_;
}


prism_rtl::Turn<crate::check::types::St> DefaultDef::cycle() const {
    const auto& g_p0 = this->g_p0;
    const auto& st_p1 = this->st_p1;
    auto g_p0_1 = g_p0;
    auto st_p1_2 = st_p1;
    return call_value(filter_job(prism_rtl::deref(st_p1_2).wants, ({
        auto st_p1_2_3 = st_p1_2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(crate::check::types::Want)>>(prism_rtl::rc([=, st_p1_2_3 = std::move(st_p1_2_3)](crate::check::types::Want p0) {
        return ({
            auto st_p1_2_3_3 = st_p1_2_3;
            entered(once_job([=, st_p1_2_3_3 = std::move(st_p1_2_3_3)]() {
            return ({
                auto w_p6 = p0;
                call_then(crate::check::types::recording::start_walk(st_p1_2_3_3, prism_rtl::deref(w_p6).ty), [=](crate::check::types::Ty walk_8872) {
                return ({
                    prism_rtl::is<crate::check::types::Ty::TyFlex>(walk_8872) ? ({
                    auto&& n_p7 = prism_rtl::as<crate::check::types::Ty::TyFlex>(walk_8872).a0;
                    prism_rtl::finished(prism_rtl::deref(crate::check::types::recording::info_of(st_p1_2_3_3, n_p7)).level >= Nat(1u));
                })
                    : prism_rtl::finished(true);
                });
            });
            });
        }));
        });
    })));
    })), [=](Array<crate::check::types::Want> filter_8844) {
        return ({
            auto mine_p2 = filter_8844;
            call_value(filter_job(prism_rtl::deref(st_p1_2).wants, ({
            auto st_p1_2_3 = st_p1_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(crate::check::types::Want)>>(prism_rtl::rc([=, st_p1_2_3 = std::move(st_p1_2_3)](crate::check::types::Want p0) {
            return ({
                auto st_p1_2_3_3 = st_p1_2_3;
                entered(once_job([=, st_p1_2_3_3 = std::move(st_p1_2_3_3)]() {
                return ({
                    auto w_p8 = p0;
                    call_then(crate::check::types::recording::start_walk(st_p1_2_3_3, prism_rtl::deref(w_p8).ty), [=](crate::check::types::Ty walk_9000) {
                    return ({
                        prism_rtl::is<crate::check::types::Ty::TyFlex>(walk_9000) ? ({
                        auto&& n_p9 = prism_rtl::as<crate::check::types::Ty::TyFlex>(walk_9000).a0;
                        prism_rtl::finished(prism_rtl::deref(crate::check::types::recording::info_of(st_p1_2_3_3, n_p9)).level < Nat(1u));
                    })
                        : prism_rtl::finished(false);
                    });
                });
                });
            }));
            });
        })));
        })), [=, mine_p2 = std::move(mine_p2)](Array<crate::check::types::Want> filter_8972) {
            return ({
                auto theirs_p3 = filter_8972;
                auto st1_p4 = ({
                    crate::check::types::St this_ = st_p1_2;
                    this_.wants = mine_p2;
                    (std::move(this_));
                });
                call_then(crate::check::env::traits::start_default_wants(g_p0_1, st1_p4, Array<std::tuple<Text, Text>>{}), [=, theirs_p3 = std::move(theirs_p3)](crate::check::types::St default_wants_9146) {
                return ({
                    auto s2_p5 = default_wants_9146;
                    (prism_rtl::finished(({
                    crate::check::types::St this_ = s2_p5;
                    this_.wants = append(theirs_p3, this_.wants);
                    (std::move(this_));
                })));
                });
            });
            });
        });
        });
    });
}


/// `Start DefaultDef, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_default_def(crate::check::env::G g_p0, crate::check::types::St st_p1) {
    return prism_rtl::make_rc<DefaultDef>(g_p0, st_p1);
}


/// CheckWidgetDef: unbounded fn Env, St, Def, WidgetDecl -> St
crate::check::types::St check_widget_def(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::check::env::Def& d_p2, const crate::syntax::decls::WidgetDecl& w_p3) {
    auto&& _m = crate::prelude::get(prism_rtl::deref(env_p0.g).vals, d_p2.qk);
    if (prism_rtl::is_some(_m)) {
        auto&& v_p4 = prism_rtl::some_of(_m);
        auto&& _m = crate::check::types::schemes::skolemize(prism_rtl::deref(v_p4).scheme);
        if (prism_rtl::is<crate::check::types::Ty::TyAt>(_m)) {
            auto&& inner_p5 = prism_rtl::as<crate::check::types::Ty::TyAt>(_m).a0;
            auto&& rw_p6 = prism_rtl::as<crate::check::types::Ty::TyAt>(_m).a1;
            auto env2_p7 = ({
                crate::check::expr::Env this_ = env_p0;
                this_.scope = rw_p6;
                this_.mark = Text::lit("@");
                (std::move(this_));
            });
            auto [t_p8, st2_p9] = crate::check::blocks::infer_widget_block(env2_p7, st_p1, w_p3.body);
            return crate::check::types::recording::note_fn(crate::check::types::unify::unify(st2_p9, prism_rtl::deref(inner_p5), t_p8, w_p3.span), w_p3.span, d_p2.name, crate::check::types::Col(crate::check::types::Col::CBound{}), prism_rtl::deref(st2_p9).color);
        }
        {
            auto&& other_pa = _m;
            return crate::check::types::recording::err(st_p1, Text::lit("mismatch"), w_p3.span, prism_rtl::cat("`", d_p2.name, "` is declared `", crate::check::types::show_ty(st_p1, other_pa), "`; a widget block builds a blueprint"));
        }
    }
    if (prism_rtl::is_none(_m)) {
        auto [t_pb, st2_pc] = crate::check::blocks::infer_widget_block(env_p0, st_p1, w_p3.body);
        return crate::check::types::recording::note_fn(st2_pc, w_p3.span, d_p2.name, crate::check::types::Col(crate::check::types::Col::CBound{}), prism_rtl::deref(st2_pc).color);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::check::types::St> CheckWidgetDef::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& d_p2 = this->d_p2;
    const auto& w_p3 = this->w_p3;
    return ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(prism_rtl::deref(env_p0).g).vals, prism_rtl::deref(d_p2).qk);
        prism_rtl::is_some(_m) ? ({
        auto&& v_p4 = prism_rtl::some_of(_m);
        ({
        auto d_p2_1 = d_p2;
        auto env_p0_2 = env_p0;
        auto st_p1_3 = st_p1;
        auto w_p3_4 = w_p3;
        call_then(crate::check::types::schemes::start_skolemize(prism_rtl::deref(v_p4).scheme), [=, d_p2_1 = std::move(d_p2_1), env_p0_2 = std::move(env_p0_2), st_p1_3 = std::move(st_p1_3), w_p3_4 = std::move(w_p3_4)](crate::check::types::Ty skolemize_9452) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TyAt>(skolemize_9452) ? ({
            auto&& inner_p5 = prism_rtl::as<crate::check::types::Ty::TyAt>(skolemize_9452).a0;
            auto&& rw_p6 = prism_rtl::as<crate::check::types::Ty::TyAt>(skolemize_9452).a1;
            ({
            auto env2_p7 = ({
                crate::check::expr::Env this_ = env_p0_2;
                this_.scope = rw_p6;
                this_.mark = Text::lit("@");
                (std::move(this_));
            });
            call_then(crate::check::blocks::start_infer_widget_block(env2_p7, st_p1_3, prism_rtl::deref(w_p3_4).body), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_widget_block_9622) {
            return ({
                auto [t_p8, st2_p9] = infer_widget_block_9622;
                call_then(crate::check::types::unify::start_unify(st2_p9, prism_rtl::deref(inner_p5), t_p8, prism_rtl::deref(w_p3_4).span), [=](crate::check::types::St unify_9676) { return prism_rtl::finished(crate::check::types::recording::note_fn(unify_9676, prism_rtl::deref(w_p3_4).span, prism_rtl::deref(d_p2_1).name, crate::check::types::Col(crate::check::types::Col::CBound{}), prism_rtl::deref(st2_p9).color)); });
            });
        });
        });
        })
            : ({
            auto&& other_pa = skolemize_9452;
            call_then(crate::check::types::start_show_ty(st_p1_3, other_pa), [=](Text show_ty_9809) { return prism_rtl::finished(crate::check::types::recording::err(st_p1_3, Text::lit("mismatch"), prism_rtl::deref(w_p3_4).span, prism_rtl::cat("`", prism_rtl::deref(d_p2_1).name, "` is declared `", show_ty_9809, "`; a widget block builds a blueprint"))); });
        });
        });
    });
    });
    })
        : prism_rtl::is_none(_m) ? ({
        auto d_p2_1 = d_p2;
        auto env_p0_2 = env_p0;
        auto st_p1_3 = st_p1;
        auto w_p3_4 = w_p3;
        call_then(crate::check::blocks::start_infer_widget_block(env_p0_2, st_p1_3, prism_rtl::deref(w_p3_4).body), [=, d_p2_1 = std::move(d_p2_1)](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_widget_block_9898) {
        return ({
            auto [t_pb, st2_pc] = infer_widget_block_9898;
            (prism_rtl::finished(crate::check::types::recording::note_fn(st2_pc, prism_rtl::deref(w_p3_4).span, prism_rtl::deref(d_p2_1).name, crate::check::types::Col(crate::check::types::Col::CBound{}), prism_rtl::deref(st2_pc).color)));
        });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CheckWidgetDef, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_check_widget_def(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::check::env::Def d_p2, crate::syntax::decls::WidgetDecl w_p3) {
    return prism_rtl::make_rc<CheckWidgetDef>(env_p0, st_p1, d_p2, w_p3);
}


/// ?MethodKey: fn G, Text, Text -> ?Text
std::optional<Text> method_key(const crate::check::env::G& g_p0, const Text& cls_p1, const Text& name_p2) {
    return fold(prism_rtl::deref(or_(crate::prelude::get(g_p0.traits, cls_p1), crate::check::env::traits::dummy_trait())).methods, std::optional<Text>{}, [&](const std::optional<Text>& found_o3, const Text& k_p4) {
        return ({
            __label__ _done;
            prism_rtl::Slot<std::optional<Text>> _v;
            if (prism_rtl::is_some(found_o3)) {
                auto&& f_p5 = prism_rtl::some_of(found_o3);
                _v.set(std::optional(f_p5));
                goto _done;
            }
            if (prism_rtl::is_none(found_o3)) {
                _v.set((crate::check::types::bare_name(k_p4) == name_p2) || (crate::syntax::lexer::chars::drop_prefix(k_p4, prism_rtl::cat(prism_rtl::deref(or_(crate::prelude::get(g_p0.traits, cls_p1), crate::check::env::traits::dummy_trait())).home, ".")) == name_p2)
                    ? std::optional(k_p4)
                    : std::optional<Text>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
}


/// CheckMethod: unbounded fn Env, St, Def, [FnClause], Text, ImplInfo -> St
crate::check::types::St check_method(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::check::env::Def& d_p2, const Array<crate::syntax::decls::FnClause>& clauses_p3, const Text& cls_p4, const crate::check::env::ImplInfo& im_p5) {
    auto&& _m = method_key(env_p0.g, cls_p4, d_p2.name);
    if (prism_rtl::is_none(_m)) {
        return crate::check::types::recording::err(st_p1, Text::lit("mismatch"), d_p2.span, prism_rtl::cat("`^", crate::check::types::bare_name(cls_p4), "` has no method `", d_p2.name, "`"));
    }
    if (prism_rtl::is_some(_m)) {
        auto&& mk_p6 = prism_rtl::some_of(_m);
        auto&& _m = crate::prelude::get(prism_rtl::deref(env_p0.g).vals, mk_p6);
        if (prism_rtl::is_none(_m)) {
            return st_p1;
        }
        if (prism_rtl::is_some(_m)) {
            auto&& v_p7 = prism_rtl::some_of(_m);
            auto ti_p8 = or_(crate::prelude::get(prism_rtl::deref(env_p0.g).traits, cls_p4), crate::check::env::traits::dummy_trait());
            auto head_p9 = crate::check::types::schemes::subst_q(crate::check::types::schemes::Inst{.tys = fold(im_p5.qs, Map<Text, crate::check::types::Ty>{}, [&](const Map<Text, crate::check::types::Ty>& m_pd, const Text& q_pe) { return insert(m_pd, q_pe, crate::check::types::Ty(crate::check::types::Ty::TyRigid{q_pe})); }), .rows = Map<Text, crate::check::types::Tail>{}, .cols = Map<Text, crate::check::types::Col>{}}, im_p5.head);
            auto ty_pa = crate::check::types::schemes::subst_q(crate::check::types::schemes::Inst{.tys = map_of(std::vector{std::tuple{prism_rtl::deref(ti_p8).param, head_p9}}), .rows = Map<Text, crate::check::types::Tail>{}, .cols = Map<Text, crate::check::types::Col>{}}, prism_rtl::deref(prism_rtl::deref(v_p7).scheme).ty);
            auto sc_pb = crate::check::types::Scheme{.qs = filter(prism_rtl::deref(prism_rtl::deref(v_p7).scheme).qs, [&](const Text& q_pf) { return q_pf != prism_rtl::deref(ti_p8).param; }), .plain_qs = Array<Text>{}, .rqs = prism_rtl::deref(prism_rtl::deref(v_p7).scheme).rqs, .cqs = prism_rtl::deref(prism_rtl::deref(v_p7).scheme).cqs, .cjoins = prism_rtl::deref(prism_rtl::deref(v_p7).scheme).cjoins, .bounds = filter(prism_rtl::deref(prism_rtl::deref(v_p7).scheme).bounds, [&](const std::tuple<Text, Text>& _p0) {
                auto&& q_pg = std::get<0>(_p0);
                return q_pg != prism_rtl::deref(ti_p8).param;
            }), .ty = ty_pa};
            auto env2_pc = ({
                crate::check::expr::Env this_ = env_p0;
                this_.givens = im_p5.bounds;
                (std::move(this_));
            });
            return crate::check::expr::lets::check_clauses(env2_pc, st_p1, d_p2.name, clauses_p3, sc_pb, d_p2.span);
        }
        prism_rtl::unreachable("no arm matched");
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::check::types::St> CheckMethod::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& d_p2 = this->d_p2;
    const auto& clauses_p3 = this->clauses_p3;
    const auto& cls_p4 = this->cls_p4;
    const auto& im_p5 = this->im_p5;
    return ({
        auto&& _m = method_key(prism_rtl::deref(env_p0).g, cls_p4, prism_rtl::deref(d_p2).name);
        prism_rtl::is_none(_m) ? prism_rtl::finished(crate::check::types::recording::err(st_p1, Text::lit("mismatch"), prism_rtl::deref(d_p2).span, prism_rtl::cat("`^", crate::check::types::bare_name(cls_p4), "` has no method `", prism_rtl::deref(d_p2).name, "`")))
        : prism_rtl::is_some(_m) ? ({
        auto&& mk_p6 = prism_rtl::some_of(_m);
        ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(prism_rtl::deref(env_p0).g).vals, mk_p6);
        prism_rtl::is_none(_m) ? prism_rtl::finished(st_p1)
        : prism_rtl::is_some(_m) ? ({
        auto&& v_p7 = prism_rtl::some_of(_m);
        ({
        auto ti_p8 = or_(crate::prelude::get(prism_rtl::deref(prism_rtl::deref(env_p0).g).traits, cls_p4), crate::check::env::traits::dummy_trait());
        auto clauses_p3_1 = clauses_p3;
        auto d_p2_2 = d_p2;
        auto env_p0_3 = env_p0;
        auto im_p5_4 = im_p5;
        auto st_p1_5 = st_p1;
        call_then(crate::check::types::schemes::start_subst_q(crate::check::types::schemes::Inst{.tys = fold(prism_rtl::deref(im_p5_4).qs, Map<Text, crate::check::types::Ty>{}, [&](const Map<Text, crate::check::types::Ty>& m_pd, const Text& q_pe) { return insert(m_pd, q_pe, crate::check::types::Ty(crate::check::types::Ty::TyRigid{q_pe})); }), .rows = Map<Text, crate::check::types::Tail>{}, .cols = Map<Text, crate::check::types::Col>{}}, prism_rtl::deref(im_p5_4).head), [=, ti_p8 = std::move(ti_p8), clauses_p3_1 = std::move(clauses_p3_1), d_p2_2 = std::move(d_p2_2), env_p0_3 = std::move(env_p0_3), st_p1_5 = std::move(st_p1_5)](crate::check::types::Ty subst_q_10769) {
        return ({
            auto head_p9 = subst_q_10769;
            call_then(crate::check::types::schemes::start_subst_q(crate::check::types::schemes::Inst{.tys = map_of(std::vector{std::tuple{prism_rtl::deref(ti_p8).param, head_p9}}), .rows = Map<Text, crate::check::types::Tail>{}, .cols = Map<Text, crate::check::types::Col>{}}, prism_rtl::deref(prism_rtl::deref(v_p7).scheme).ty), [=](crate::check::types::Ty subst_q_10887) {
            return ({
                auto ty_pa = subst_q_10887;
                auto sc_pb = crate::check::types::Scheme{.qs = filter(prism_rtl::deref(prism_rtl::deref(v_p7).scheme).qs, [&](const Text& q_pf) { return q_pf != prism_rtl::deref(ti_p8).param; }), .plain_qs = Array<Text>{}, .rqs = prism_rtl::deref(prism_rtl::deref(v_p7).scheme).rqs, .cqs = prism_rtl::deref(prism_rtl::deref(v_p7).scheme).cqs, .cjoins = prism_rtl::deref(prism_rtl::deref(v_p7).scheme).cjoins, .bounds = filter(prism_rtl::deref(prism_rtl::deref(v_p7).scheme).bounds, [&](const std::tuple<Text, Text>& _p0) {
                    auto&& q_pg = std::get<0>(_p0);
                    return q_pg != prism_rtl::deref(ti_p8).param;
                }), .ty = ty_pa};
                auto env2_pc = ({
                    crate::check::expr::Env this_ = env_p0_3;
                    this_.givens = prism_rtl::deref(im_p5_4).bounds;
                    (std::move(this_));
                });
                (prism_rtl::more(prism_rtl::rc(crate::check::expr::lets::CheckClauses(env2_pc, st_p1_5, prism_rtl::deref(d_p2_2).name, clauses_p3_1, sc_pb, prism_rtl::deref(d_p2_2).span))));
            });
        });
        });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CheckMethod, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_check_method(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::check::env::Def d_p2, Array<crate::syntax::decls::FnClause> clauses_p3, Text cls_p4, crate::check::env::ImplInfo im_p5) {
    return prism_rtl::make_rc<CheckMethod>(env_p0, st_p1, d_p2, clauses_p3, cls_p4, im_p5);
}


/// RootRow: unbounded fn G, St, [Text] -> ((Text, St))
std::tuple<Text, crate::check::types::St> root_row(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const Array<Text>& world_p2) {
    auto&& _m = crate::prelude::get(g_p0.mods, Text::lit(""));
    if (prism_rtl::is_none(_m)) {
        return std::tuple{Text::lit(""), st_p1};
    }
    if (prism_rtl::is_some(_m)) {
        auto&& info_p3 = prism_rtl::some_of(_m);
        auto shown_p4 = crate::check::types::show_row(prism_rtl::deref(info_p3).emit_rw);
        return len(world_p2) == Nat(0u)
            ? std::tuple{shown_p4, st_p1}
            : ({
            auto missing_p5 = filter(prism_rtl::deref(prism_rtl::deref(info_p3).emit_rw).fams, [&](const Text& f_p6) { return !crate::check::types::has_text(world_p2, f_p6); });
            len(missing_p5) == Nat(0u)
            ? std::tuple{shown_p4, st_p1}
            : ({
            auto s0_p7 = ({
                crate::check::types::St this_ = st_p1;
                this_.file = info_p3->file;
                (std::move(this_));
            });
            std::tuple{shown_p4, crate::check::types::recording::err_fix(s0_p7, Text::lit("world-row"), prism_rtl::deref(prism_rtl::deref(info_p3).tree).span, prism_rtl::cat("the program emits ", crate::syntax::lexer::chars::join(each(missing_p5, [&](const Text& f_p8) { return prism_rtl::cat("`", f_p8, ".*`"); }), Text::lit(", ")), ", which this World does not answer"), Text::lit("host the tags it cannot answer, or run under a World that answers them"))};
        });
        });
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<Text, crate::check::types::St>> RootRow::cycle() const {
    const auto& g_p0 = this->g_p0;
    const auto& st_p1 = this->st_p1;
    const auto& world_p2 = this->world_p2;
    return ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(g_p0).mods, Text::lit(""));
        prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{Text::lit(""), st_p1})
        : prism_rtl::is_some(_m) ? ({
        auto&& info_p3 = prism_rtl::some_of(_m);
        ({
        auto shown_p4 = crate::check::types::show_row(prism_rtl::deref(info_p3).emit_rw);
        len(world_p2) == Nat(0u)
        ? prism_rtl::finished(std::tuple{shown_p4, st_p1})
        : ({
        auto missing_p5 = filter(prism_rtl::deref(prism_rtl::deref(info_p3).emit_rw).fams, [&](const Text& f_p6) { return !crate::check::types::has_text(world_p2, f_p6); });
        len(missing_p5) == Nat(0u)
        ? prism_rtl::finished(std::tuple{shown_p4, st_p1})
        : ({
        auto s0_p7 = ({
            crate::check::types::St this_ = st_p1;
            this_.file = info_p3->file;
            (std::move(this_));
        });
        (prism_rtl::finished(std::tuple{shown_p4, crate::check::types::recording::err_fix(s0_p7, Text::lit("world-row"), prism_rtl::deref(prism_rtl::deref(info_p3).tree).span, prism_rtl::cat("the program emits ", crate::syntax::lexer::chars::join(each(missing_p5, [&](const Text& f_p8) { return prism_rtl::cat("`", f_p8, ".*`"); }), Text::lit(", ")), ", which this World does not answer"), Text::lit("host the tags it cannot answer, or run under a World that answers them"))}));
    });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start RootRow, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Text, crate::check::types::St>> start_root_row(crate::check::env::G g_p0, crate::check::types::St st_p1, Array<Text> world_p2) {
    return prism_rtl::make_rc<RootRow>(g_p0, st_p1, world_p2);
}

}  // namespace crate::check
