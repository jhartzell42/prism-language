// The module `Emit.Rust.Items`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <emit/rust/items/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>

// The module `Emit.Rust.Items`, from `target/bootstrap/cpp-src/prismc/emit/rust/items.prism`.
namespace crate::emit::rust::items {

/// Generics: fn [((Text, [Text]))] -> Text
Text generics_f(const Array<std::tuple<Text, Array<Text>>>& xs0) {
    {
        auto&& c0_0 = xs0;
        if (c0_0.size() == 0u) {
            return Text::lit("");
        }
    }
    {
        auto&& gs_p0 = xs0;
        return prism_rtl::cat("<", crate::syntax::lexer::chars::join_f(crate::prelude::each(gs_p0, [&](const std::tuple<Text, Array<Text>>& _p0) {
            auto&& g_p1 = std::get<0>(_p0);
            auto&& bs_p2 = std::get<1>(_p0);
            return crate::prelude::len(bs_p2) == Nat(0u)
                ? g_p1
                : prism_rtl::cat(g_p1, ": ", crate::syntax::lexer::chars::join_f(bs_p2, Text::lit(" + ")));
        }), Text::lit(", ")), ">");
    }
}


/// GenericNames: fn [Text] -> Text
Text generic_names_f(const Array<Text>& xs0) {
    {
        auto&& c0_0 = xs0;
        if (c0_0.size() == 0u) {
            return Text::lit("");
        }
    }
    {
        auto&& ps_p0 = xs0;
        return prism_rtl::cat("<", crate::syntax::lexer::chars::join_f(ps_p0, Text::lit(", ")), ">");
    }
}


/// Bounded: fn [Text], Text -> Text
Text bounded_f(const Array<Text>& xs0, const Text& text1) {
    auto&& _m = std::tuple{xs0, text1};
    {
        auto&& c0_0 = std::get<0>(_m);
        if (c0_0.size() == 0u) {
            return Text::lit("");
        }
    }
    {
        auto&& ps_p0 = std::get<0>(_m);
        auto&& tr_p1 = std::get<1>(_m);
        return prism_rtl::cat("<", crate::syntax::lexer::chars::join_f(crate::prelude::each(ps_p0, [&](const Text& p_p2) { return prism_rtl::cat(p_p2, ": ", tr_p1); }), Text::lit(", ")), ">");
    }
    prism_rtl::unreachable("no arm matched");
}


/// RustItem: unbounded fn Item -> Text
Text rust_item_f(const crate::lower::model::Item& it_p0) {
    if (prism_rtl::is<crate::lower::model::Item::ItTrait>(it_p0)) {
        auto&& t_p1 = prism_rtl::as<crate::lower::model::Item::ItTrait>(it_p0).a0;
        return rust_trait_f(t_p1);
    }
    if (prism_rtl::is<crate::lower::model::Item::ItImpl>(it_p0)) {
        auto&& i_p2 = prism_rtl::as<crate::lower::model::Item::ItImpl>(it_p0).a0;
        return rust_impl_f(i_p2);
    }
    if (prism_rtl::is<crate::lower::model::Item::ItType>(it_p0)) {
        auto&& t_p3 = prism_rtl::as<crate::lower::model::Item::ItType>(it_p0).a0;
        return type_decl_f(t_p3);
    }
    if (prism_rtl::is<crate::lower::model::Item::ItTag>(it_p0)) {
        auto&& t_p4 = prism_rtl::as<crate::lower::model::Item::ItTag>(it_p0).a0;
        return rust_tag_f(t_p4);
    }
    if (prism_rtl::is<crate::lower::model::Item::ItRow>(it_p0)) {
        auto&& r_p5 = prism_rtl::as<crate::lower::model::Item::ItRow>(it_p0).a0;
        return rust_row_f(r_p5);
    }
    if (prism_rtl::is<crate::lower::model::Item::ItFn>(it_p0)) {
        auto&& f_p6 = prism_rtl::as<crate::lower::model::Item::ItFn>(it_p0).a0;
        return rust_fn_f(f_p6);
    }
    if (prism_rtl::is<crate::lower::model::Item::ItJob>(it_p0)) {
        auto&& j_p7 = prism_rtl::as<crate::lower::model::Item::ItJob>(it_p0).a0;
        return rust_job_f(j_p7);
    }
    if (prism_rtl::is<crate::lower::model::Item::ItNode>(it_p0)) {
        auto&& n_p8 = prism_rtl::as<crate::lower::model::Item::ItNode>(it_p0).a0;
        return rust_node_f(n_p8);
    }
    if (prism_rtl::is<crate::lower::model::Item::ItNote>(it_p0)) {
        auto&& t_p9 = prism_rtl::as<crate::lower::model::Item::ItNote>(it_p0).a0;
        return prism_rtl::cat("// ", t_p9, "\n");
    }
    if (prism_rtl::is<crate::lower::model::Item::ItRefused>(it_p0)) {
        auto&& t_pa = prism_rtl::as<crate::lower::model::Item::ItRefused>(it_p0).a0;
        return prism_rtl::cat("compile_error!(\"", crate::lower::expr::lowering_refusal_p(), crate::lower::expr::escape_f(t_pa), "\");\n");
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Text> RustItem::cycle() const {
    const auto& it_p0 = this->it_p0;
    return ({
        prism_rtl::is<crate::lower::model::Item::ItTrait>(it_p0) ? ({
        auto&& t_p1 = prism_rtl::as<crate::lower::model::Item::ItTrait>(it_p0).a0;
        prism_rtl::more(prism_rtl::rc(RustTrait(t_p1)));
    })
        : prism_rtl::is<crate::lower::model::Item::ItImpl>(it_p0) ? ({
        auto&& i_p2 = prism_rtl::as<crate::lower::model::Item::ItImpl>(it_p0).a0;
        prism_rtl::more(prism_rtl::rc(RustImpl(i_p2)));
    })
        : prism_rtl::is<crate::lower::model::Item::ItType>(it_p0) ? ({
        auto&& t_p3 = prism_rtl::as<crate::lower::model::Item::ItType>(it_p0).a0;
        prism_rtl::more(prism_rtl::rc(TypeDecl(t_p3)));
    })
        : prism_rtl::is<crate::lower::model::Item::ItTag>(it_p0) ? ({
        auto&& t_p4 = prism_rtl::as<crate::lower::model::Item::ItTag>(it_p0).a0;
        prism_rtl::more(prism_rtl::rc(RustTag(t_p4)));
    })
        : prism_rtl::is<crate::lower::model::Item::ItRow>(it_p0) ? ({
        auto&& r_p5 = prism_rtl::as<crate::lower::model::Item::ItRow>(it_p0).a0;
        prism_rtl::more(prism_rtl::rc(RustRow(r_p5)));
    })
        : prism_rtl::is<crate::lower::model::Item::ItFn>(it_p0) ? ({
        auto&& f_p6 = prism_rtl::as<crate::lower::model::Item::ItFn>(it_p0).a0;
        prism_rtl::more(prism_rtl::rc(RustFn(f_p6)));
    })
        : prism_rtl::is<crate::lower::model::Item::ItJob>(it_p0) ? ({
        auto&& j_p7 = prism_rtl::as<crate::lower::model::Item::ItJob>(it_p0).a0;
        prism_rtl::more(prism_rtl::rc(RustJob(j_p7)));
    })
        : prism_rtl::is<crate::lower::model::Item::ItNode>(it_p0) ? ({
        auto&& n_p8 = prism_rtl::as<crate::lower::model::Item::ItNode>(it_p0).a0;
        prism_rtl::more(prism_rtl::rc(RustNode(n_p8)));
    })
        : prism_rtl::is<crate::lower::model::Item::ItNote>(it_p0) ? ({
        auto&& t_p9 = prism_rtl::as<crate::lower::model::Item::ItNote>(it_p0).a0;
        prism_rtl::finished(prism_rtl::cat("// ", t_p9, "\n"));
    })
        : prism_rtl::is<crate::lower::model::Item::ItRefused>(it_p0) ? ({
        auto&& t_pa = prism_rtl::as<crate::lower::model::Item::ItRefused>(it_p0).a0;
        prism_rtl::finished(prism_rtl::cat("compile_error!(\"", crate::lower::expr::lowering_refusal_p(), crate::lower::expr::escape_f(t_pa), "\");\n"));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start RustItem, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_rust_item_f(crate::lower::model::Item it_p0) {
    return prism_rtl::make_rc<RustItem>(it_p0);
}


/// RustTrait: unbounded fn TraitDef -> Text
Text rust_trait_f(const crate::lower::model::TraitDef& t_p0) {
    auto ms_p1 = crate::syntax::lexer::chars::join_f(crate::prelude::run_to_end(crate::prelude::each_job(t_p0.methods_p, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::FnDef)>>(prism_rtl::rc([=](crate::lower::model::FnDef p0) {
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto f_p2 = p0;
                (prism_rtl::more(prism_rtl::rc(TraitMethod(f_p2))));
            });
        }));
    })))), Text::lit("\n"));
    return prism_rtl::cat(crate::emit::rust::templates::source_doc_f(Text::lit(""), t_p0.doc_p), "pub trait ", t_p0.name_p, " {\n", crate::emit::rust::indent_f(ms_p1), "\n}\n");
}


prism_rtl::Turn<Text> RustTrait::cycle() const {
    const auto& t_p0 = this->t_p0;
    auto t_p0x = t_p0;
    return crate::prelude::call_value(crate::prelude::each_job(prism_rtl::deref(t_p0x).methods_p, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::FnDef)>>(prism_rtl::rc([=](crate::lower::model::FnDef p0) {
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto f_p2 = p0;
                (prism_rtl::more(prism_rtl::rc(TraitMethod(f_p2))));
            });
        }));
    }))), [=](Array<Text> each_1796) {
        return ({
            auto ms_p1 = crate::syntax::lexer::chars::join_f(each_1796, Text::lit("\n"));
            (prism_rtl::finished(prism_rtl::cat(crate::emit::rust::templates::source_doc_f(Text::lit(""), prism_rtl::deref(t_p0x).doc_p), "pub trait ", prism_rtl::deref(t_p0x).name_p, " {\n", crate::emit::rust::indent_f(ms_p1), "\n}\n")));
        });
    });
}


/// `Start RustTrait, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_rust_trait_f(crate::lower::model::TraitDef t_p0) {
    return prism_rtl::make_rc<RustTrait>(t_p0);
}


/// Signature: unbounded fn FnDef, Text -> Text
Text signature_f(const crate::lower::model::FnDef& f_p0, const Text& vis_p1) {
    auto params_p2 = crate::syntax::lexer::chars::join_f(crate::prelude::run_to_end(crate::prelude::each_job(f_p0.params_p, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto [n_p3, t_p4] = p0;
                (crate::prelude::call_then(crate::emit::rust::start_type_f(t_p4), [=](Text type_f_2029) { return prism_rtl::finished(prism_rtl::cat(n_p3, ": ", type_f_2029)); }));
            });
        }));
    })))), Text::lit(", "));
    return prism_rtl::cat(vis_p1, "fn ", f_p0.name_p, generics_f(f_p0.generics_p), "(", params_p2, ") -> ", crate::emit::rust::type_f(f_p0.ret_p));
}


prism_rtl::Turn<Text> Signature::cycle() const {
    const auto& f_p0 = this->f_p0;
    const auto& vis_p1 = this->vis_p1;
    auto f_p0x = f_p0;
    auto vis_p1x = vis_p1;
    return crate::prelude::call_value(crate::prelude::each_job(prism_rtl::deref(f_p0x).params_p, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto [n_p3, t_p4] = p0;
                (crate::prelude::call_then(crate::emit::rust::start_type_f(t_p4), [=](Text type_f_2029) { return prism_rtl::finished(prism_rtl::cat(n_p3, ": ", type_f_2029)); }));
            });
        }));
    }))), [=](Array<Text> each_1995) {
        return ({
            auto params_p2 = crate::syntax::lexer::chars::join_f(each_1995, Text::lit(", "));
            (crate::prelude::call_then(crate::emit::rust::start_type_f(prism_rtl::deref(f_p0x).ret_p), [=, params_p2 = std::move(params_p2)](Text type_f_2102) { return prism_rtl::finished(prism_rtl::cat(vis_p1x, "fn ", prism_rtl::deref(f_p0x).name_p, generics_f(prism_rtl::deref(f_p0x).generics_p), "(", params_p2, ") -> ", type_f_2102)); }));
        });
    });
}


/// `Start Signature, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_signature_f(crate::lower::model::FnDef f_p0, Text vis_p1) {
    return prism_rtl::make_rc<Signature>(f_p0, vis_p1);
}


/// TraitMethod: unbounded fn FnDef -> Text
Text trait_method_f(const crate::lower::model::FnDef& f_p0) {
    return f_p0.public_p
        ? crate::emit::rust::templates::items::fn_f(Text::lit(""), signature_f(f_p0, Text::lit("")), crate::emit::rust::body_lines_f(f_p0.body_p))
        : prism_rtl::cat(signature_f(f_p0, Text::lit("")), ";");
}


prism_rtl::Turn<Text> TraitMethod::cycle() const {
    const auto& f_p0 = this->f_p0;
    return prism_rtl::deref(f_p0).public_p
        ? ({
        auto f_p0x = f_p0;
        (crate::prelude::call_then(start_signature_f(f_p0x, Text::lit("")), [=](Text signature_f_2196) { return crate::prelude::call_then(crate::emit::rust::start_body_lines_f(prism_rtl::deref(f_p0x).body_p), [=](Text body_lines_f_2215) { return prism_rtl::finished(crate::emit::rust::templates::items::fn_f(Text::lit(""), signature_f_2196, body_lines_f_2215)); }); }));
    })
        : ({
        auto f_p0x = f_p0;
        (crate::prelude::call_then(start_signature_f(f_p0x, Text::lit("")), [=](Text signature_f_2241) { return prism_rtl::finished(prism_rtl::cat(signature_f_2241, ";")); }));
    });
}


/// `Start TraitMethod, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_trait_method_f(crate::lower::model::FnDef f_p0) {
    return prism_rtl::make_rc<TraitMethod>(f_p0);
}


/// RustImpl: unbounded fn ImplDef -> Text
Text rust_impl_f(const crate::lower::model::ImplDef& i_p0) {
    auto head_p1 = crate::emit::rust::type_f(i_p0.head_p);
    auto gens_p2 = generics_f(i_p0.generics_p);
    auto&& _m = i_p0.cls_p;
    {
        auto&& m2516_0 = _m;
        if (m2516_0 == Text::lit("Prelude.Show")) {
            auto fns_p3 = crate::syntax::lexer::chars::join_f(crate::prelude::run_to_end(crate::prelude::each_job(i_p0.methods_p, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::FnDef)>>(prism_rtl::rc([=](crate::lower::model::FnDef p0) {
                return crate::prelude::entered(crate::prelude::once_job([=]() {
                    return ({
                        auto f_p5 = p0;
                        (prism_rtl::more(prism_rtl::rc(RustFn(f_p5))));
                    });
                }));
            })))), Text::lit("\n"));
            auto shown_p4 = crate::prelude::or_(crate::prelude::index(crate::prelude::each(i_p0.methods_p, [&](const crate::lower::model::FnDef& f_p6) { return prism_rtl::deref(f_p6).name_p; }), Nat(0u)), Text::lit("show"));
            return prism_rtl::cat(fns_p3, "\n", crate::emit::rust::templates::items::impl_f(gens_p2, Text::lit("Show"), head_p1, Text::lit("fn show(&self, p: &mut Printer)"), prism_rtl::cat("p.raw(&", shown_p4, "(self).to_string());")));
        }
    }
    {
        auto&& m2516_1 = _m;
        if (m2516_1 == Text::lit("Prelude.Eq")) {
            auto fns_p7 = crate::syntax::lexer::chars::join_f(crate::prelude::run_to_end(crate::prelude::each_job(i_p0.methods_p, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::FnDef)>>(prism_rtl::rc([=](crate::lower::model::FnDef p0) {
                return crate::prelude::entered(crate::prelude::once_job([=]() {
                    return ({
                        auto f_p9 = p0;
                        (prism_rtl::more(prism_rtl::rc(RustFn(f_p9))));
                    });
                }));
            })))), Text::lit("\n"));
            auto eq_p8 = crate::prelude::fold(i_p0.methods_p, Text::lit(""), [&](const Text& acc_pa, const crate::lower::model::FnDef& f_pb) {
                return (!crate::syntax::lexer::chars::has_prefix_f(prism_rtl::deref(f_pb).name_p, Text::lit("ne"))) && (acc_pa == Text::lit(""))
                    ? prism_rtl::deref(f_pb).name_p
                    : acc_pa;
            });
            return prism_rtl::cat(fns_p7, "\n", crate::emit::rust::templates::items::impl_f(gens_p2, Text::lit("PartialEq"), head_p1, Text::lit("fn eq(&self, other: &Self) -> bool"), prism_rtl::cat(eq_p8, "(self, other)")), "\nimpl", gens_p2, " Eq for ", head_p1, " {}");
        }
    }
    {
        return prism_rtl::cat("impl", gens_p2, " ", i_p0.tr_p, " for ", head_p1, " {\n", crate::emit::rust::indent_f(crate::syntax::lexer::chars::join_f(crate::prelude::run_to_end(crate::prelude::each_job(i_p0.methods_p, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::FnDef)>>(prism_rtl::rc([=](crate::lower::model::FnDef p0) {
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto f_pc = p0;
                    (crate::prelude::call_then(start_signature_f(f_pc, Text::lit("")), [=](Text signature_f_3249) { return crate::prelude::call_then(crate::emit::rust::start_body_lines_f(prism_rtl::deref(f_pc).body_p), [=](Text body_lines_f_3268) { return prism_rtl::finished(crate::emit::rust::templates::items::fn_f(Text::lit(""), signature_f_3249, body_lines_f_3268)); }); }));
                });
            }));
        })))), Text::lit("\n"))), "\n}\n");
    }
}


prism_rtl::Turn<Text> RustImpl::cycle() const {
    const auto& i_p0 = this->i_p0;
    auto i_p0x = i_p0;
    return crate::prelude::call_then(crate::emit::rust::start_type_f(prism_rtl::deref(i_p0x).head_p), [=](Text type_f_2465) {
        return ({
            auto head_p1 = type_f_2465;
            auto gens_p2 = generics_f(prism_rtl::deref(i_p0x).generics_p);
            ({
            auto&& _m = prism_rtl::deref(i_p0x).cls_p;
            ({
            auto&& m2516_0 = _m;
            (m2516_0 == Text::lit("Prelude.Show"));
        }) ? ({
            auto&& m2516_0 = _m;
            crate::prelude::call_value(crate::prelude::each_job(prism_rtl::deref(i_p0x).methods_p, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::FnDef)>>(prism_rtl::rc([=](crate::lower::model::FnDef p0) {
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto f_p5 = p0;
                    (prism_rtl::more(prism_rtl::rc(RustFn(f_p5))));
                });
            }));
        }))), [=, head_p1 = std::move(head_p1), gens_p2 = std::move(gens_p2)](Array<Text> each_2581) {
            return ({
                auto fns_p3 = crate::syntax::lexer::chars::join_f(each_2581, Text::lit("\n"));
                auto shown_p4 = crate::prelude::or_(crate::prelude::index(crate::prelude::each(prism_rtl::deref(i_p0x).methods_p, [&](const crate::lower::model::FnDef& f_p6) { return prism_rtl::deref(f_p6).name_p; }), Nat(0u)), Text::lit("show"));
                (prism_rtl::finished(prism_rtl::cat(fns_p3, "\n", crate::emit::rust::templates::items::impl_f(gens_p2, Text::lit("Show"), head_p1, Text::lit("fn show(&self, p: &mut Printer)"), prism_rtl::cat("p.raw(&", shown_p4, "(self).to_string());")))));
            });
        });
        })
            : ({
            auto&& m2516_1 = _m;
            (m2516_1 == Text::lit("Prelude.Eq"));
        }) ? ({
            auto&& m2516_1 = _m;
            crate::prelude::call_value(crate::prelude::each_job(prism_rtl::deref(i_p0x).methods_p, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::FnDef)>>(prism_rtl::rc([=](crate::lower::model::FnDef p0) {
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto f_p9 = p0;
                    (prism_rtl::more(prism_rtl::rc(RustFn(f_p9))));
                });
            }));
        }))), [=, head_p1 = std::move(head_p1), gens_p2 = std::move(gens_p2)](Array<Text> each_2856) {
            return ({
                auto fns_p7 = crate::syntax::lexer::chars::join_f(each_2856, Text::lit("\n"));
                auto eq_p8 = crate::prelude::fold(prism_rtl::deref(i_p0x).methods_p, Text::lit(""), [&](const Text& acc_pa, const crate::lower::model::FnDef& f_pb) {
                    return (!crate::syntax::lexer::chars::has_prefix_f(prism_rtl::deref(f_pb).name_p, Text::lit("ne"))) && (acc_pa == Text::lit(""))
                        ? prism_rtl::deref(f_pb).name_p
                        : acc_pa;
                });
                (prism_rtl::finished(prism_rtl::cat(fns_p7, "\n", crate::emit::rust::templates::items::impl_f(gens_p2, Text::lit("PartialEq"), head_p1, Text::lit("fn eq(&self, other: &Self) -> bool"), prism_rtl::cat(eq_p8, "(self, other)")), "\nimpl", gens_p2, " Eq for ", head_p1, " {}")));
            });
        });
        })
            : crate::prelude::call_value(crate::prelude::each_job(prism_rtl::deref(i_p0x).methods_p, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::FnDef)>>(prism_rtl::rc([=](crate::lower::model::FnDef p0) {
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto f_pc = p0;
                    (crate::prelude::call_then(start_signature_f(f_pc, Text::lit("")), [=](Text signature_f_3249) { return crate::prelude::call_then(crate::emit::rust::start_body_lines_f(prism_rtl::deref(f_pc).body_p), [=](Text body_lines_f_3268) { return prism_rtl::finished(crate::emit::rust::templates::items::fn_f(Text::lit(""), signature_f_3249, body_lines_f_3268)); }); }));
                });
            }));
        }))), [=, head_p1 = std::move(head_p1), gens_p2 = std::move(gens_p2)](Array<Text> each_3220) { return prism_rtl::finished(prism_rtl::cat("impl", gens_p2, " ", prism_rtl::deref(i_p0x).tr_p, " for ", head_p1, " {\n", crate::emit::rust::indent_f(crate::syntax::lexer::chars::join_f(each_3220, Text::lit("\n"))), "\n}\n")); });
        });
        });
    });
}


/// `Start RustImpl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_rust_impl_f(crate::lower::model::ImplDef i_p0) {
    return prism_rtl::make_rc<RustImpl>(i_p0);
}


/// RustFn: unbounded fn FnDef -> Text
Text rust_fn_f(const crate::lower::model::FnDef& f_p0) {
    auto params_p1 = crate::syntax::lexer::chars::join_f(crate::prelude::run_to_end(crate::prelude::each_job(f_p0.params_p, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto [n_p3, t_p4] = p0;
                (crate::prelude::call_then(crate::emit::rust::start_type_f(t_p4), [=](Text type_f_3408) { return prism_rtl::finished(prism_rtl::cat(n_p3, ": ", type_f_3408)); }));
            });
        }));
    })))), Text::lit(", "));
    auto sig_p2 = prism_rtl::cat("pub fn ", f_p0.name_p, static_generics_f(f_p0.generics_p), "(", params_p1, ") -> ", crate::emit::rust::type_f(f_p0.ret_p));
    return crate::emit::rust::templates::items::fn_f(crate::emit::rust::templates::source_doc_f(Text::lit(""), f_p0.doc_p), sig_p2, crate::emit::rust::body_lines_f(f_p0.body_p));
}


prism_rtl::Turn<Text> RustFn::cycle() const {
    const auto& f_p0 = this->f_p0;
    auto f_p0x = f_p0;
    return crate::prelude::call_value(crate::prelude::each_job(prism_rtl::deref(f_p0x).params_p, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto [n_p3, t_p4] = p0;
                (crate::prelude::call_then(crate::emit::rust::start_type_f(t_p4), [=](Text type_f_3408) { return prism_rtl::finished(prism_rtl::cat(n_p3, ": ", type_f_3408)); }));
            });
        }));
    }))), [=](Array<Text> each_3374) {
        return ({
            auto params_p1 = crate::syntax::lexer::chars::join_f(each_3374, Text::lit(", "));
            (crate::prelude::call_then(crate::emit::rust::start_type_f(prism_rtl::deref(f_p0x).ret_p), [=, params_p1 = std::move(params_p1)](Text type_f_3638) {
            return ({
                auto sig_p2 = prism_rtl::cat("pub fn ", prism_rtl::deref(f_p0x).name_p, static_generics_f(prism_rtl::deref(f_p0x).generics_p), "(", params_p1, ") -> ", type_f_3638);
                (crate::prelude::call_then(crate::emit::rust::start_body_lines_f(prism_rtl::deref(f_p0x).body_p), [=, sig_p2 = std::move(sig_p2)](Text body_lines_f_3687) { return prism_rtl::finished(crate::emit::rust::templates::items::fn_f(crate::emit::rust::templates::source_doc_f(Text::lit(""), prism_rtl::deref(f_p0x).doc_p), sig_p2, body_lines_f_3687)); }));
            });
        }));
        });
    });
}


/// `Start RustFn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_rust_fn_f(crate::lower::model::FnDef f_p0) {
    return prism_rtl::make_rc<RustFn>(f_p0);
}


/// StaticGenerics: fn [((Text, [Text]))] -> Text
Text static_generics_f(const Array<std::tuple<Text, Array<Text>>>& gs_p0) {
    return generics_f(crate::prelude::each(gs_p0, [&](const std::tuple<Text, Array<Text>>& _p0) {
        auto&& g_p1 = std::get<0>(_p0);
        auto&& bs_p2 = std::get<1>(_p0);
        return std::tuple{g_p1, crate::prelude::push(bs_p2, Text::lit("\'static"))};
    }));
}


/// RustJob: unbounded fn JobDef -> Text
Text rust_job_f(const crate::lower::model::JobDef& j_p0) {
    auto gnames_p1 = generic_names_f(crate::prelude::each(j_p0.generics_p, [&](const std::tuple<Text, Array<Text>>& _p0) {
        auto&& g_p7 = std::get<0>(_p0);
        return g_p7;
    }));
    auto fields_p2 = crate::syntax::lexer::chars::join_f(crate::prelude::run_to_end(crate::prelude::each_job(j_p0.fields_p, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto [n_p8, t_p9] = p0;
                (crate::prelude::call_then(crate::emit::rust::start_type_f(t_p9), [=](Text type_f_4093) { return prism_rtl::finished(prism_rtl::cat("pub ", n_p8, ": ", type_f_4093, ",")); }));
            });
        }));
    })))), Text::lit("\n"));
    auto params_p3 = crate::syntax::lexer::chars::join_f(crate::prelude::run_to_end(crate::prelude::each_job(j_p0.fields_p, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto [n_pa, t_pb] = p0;
                (crate::prelude::call_then(crate::emit::rust::start_type_f(t_pb), [=](Text type_f_4167) { return prism_rtl::finished(prism_rtl::cat(n_pa, ": ", type_f_4167)); }));
            });
        }));
    })))), Text::lit(", "));
    auto bounded_p4 = static_generics_f(j_p0.generics_p);
    auto start_p5 = prism_rtl::cat("pub fn ", j_p0.start_p, bounded_p4, "(", params_p3, ") -> Rc<dyn prism_rtl::Job<", crate::emit::rust::type_f(j_p0.ret_p), ">>");
    auto start_body_p6 = prism_rtl::cat("Rc::new(", j_p0.name_p, " { ", crate::syntax::lexer::chars::join_f(crate::prelude::each(j_p0.fields_p, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
        auto&& n_pc = std::get<0>(_p0);
        return n_pc;
    }), Text::lit(", ")), " })");
    return crate::emit::rust::templates::items::job_f(crate::emit::rust::templates::source_doc_f(Text::lit(""), j_p0.doc_p), j_p0.name_p, gnames_p1, bounded_p4, fields_p2, crate::emit::rust::type_f(j_p0.ret_p), crate::emit::rust::body_lines_f(j_p0.body_p), start_p5, start_body_p6);
}


prism_rtl::Turn<Text> RustJob::cycle() const {
    const auto& j_p0 = this->j_p0;
    auto gnames_p1 = generic_names_f(crate::prelude::each(prism_rtl::deref(j_p0).generics_p, [&](const std::tuple<Text, Array<Text>>& _p0) {
        auto&& g_p7 = std::get<0>(_p0);
        return g_p7;
    }));
    auto j_p0x = j_p0;
    return crate::prelude::call_value(crate::prelude::each_job(prism_rtl::deref(j_p0x).fields_p, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto [n_p8, t_p9] = p0;
                (crate::prelude::call_then(crate::emit::rust::start_type_f(t_p9), [=](Text type_f_4093) { return prism_rtl::finished(prism_rtl::cat("pub ", n_p8, ": ", type_f_4093, ",")); }));
            });
        }));
    }))), [=](Array<Text> each_4055) {
        return ({
            auto fields_p2 = crate::syntax::lexer::chars::join_f(each_4055, Text::lit("\n"));
            (crate::prelude::call_value(crate::prelude::each_job(prism_rtl::deref(j_p0x).fields_p, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto [n_pa, t_pb] = p0;
                    (crate::prelude::call_then(crate::emit::rust::start_type_f(t_pb), [=](Text type_f_4167) { return prism_rtl::finished(prism_rtl::cat(n_pa, ": ", type_f_4167)); }));
                });
            }));
        }))), [=, fields_p2 = std::move(fields_p2)](Array<Text> each_4133) {
            return ({
                auto params_p3 = crate::syntax::lexer::chars::join_f(each_4133, Text::lit(", "));
                auto bounded_p4 = static_generics_f(prism_rtl::deref(j_p0x).generics_p);
                (crate::prelude::call_then(crate::emit::rust::start_type_f(prism_rtl::deref(j_p0x).ret_p), [=, params_p3 = std::move(params_p3), bounded_p4 = std::move(bounded_p4)](Text type_f_4391) {
                return ({
                    auto start_p5 = prism_rtl::cat("pub fn ", prism_rtl::deref(j_p0x).start_p, bounded_p4, "(", params_p3, ") -> Rc<dyn prism_rtl::Job<", type_f_4391, ">>");
                    auto start_body_p6 = prism_rtl::cat("Rc::new(", prism_rtl::deref(j_p0x).name_p, " { ", crate::syntax::lexer::chars::join_f(crate::prelude::each(prism_rtl::deref(j_p0x).fields_p, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
                        auto&& n_pc = std::get<0>(_p0);
                        return n_pc;
                    }), Text::lit(", ")), " })");
                    (crate::prelude::call_then(crate::emit::rust::start_type_f(prism_rtl::deref(j_p0x).ret_p), [=, start_p5 = std::move(start_p5), start_body_p6 = std::move(start_body_p6)](Text type_f_4566) { return crate::prelude::call_then(crate::emit::rust::start_body_lines_f(prism_rtl::deref(j_p0x).body_p), [=](Text body_lines_f_4580) { return prism_rtl::finished(crate::emit::rust::templates::items::job_f(crate::emit::rust::templates::source_doc_f(Text::lit(""), prism_rtl::deref(j_p0x).doc_p), prism_rtl::deref(j_p0x).name_p, gnames_p1, bounded_p4, fields_p2, type_f_4566, body_lines_f_4580, start_p5, start_body_p6)); }); }));
                });
            }));
            });
        }));
        });
    });
}


/// `Start RustJob, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_rust_job_f(crate::lower::model::JobDef j_p0) {
    return prism_rtl::make_rc<RustJob>(j_p0);
}


/// TypeDecl: unbounded fn TyDef -> Text
Text type_decl_f(const crate::lower::model::TyDef& t_p0) {
    auto derives_p1 = crate::syntax::lexer::chars::join_f(crate::prelude::filter(Array(std::vector{Text::lit("Clone"), t_p0.eq_p || t_p0.ord_p ? Text::lit("PartialEq, Eq") : Text::lit(""), t_p0.ord_p ? Text::lit("PartialOrd, Ord") : Text::lit("")}), [&](const Text& d_p7) { return d_p7 != Text::lit(""); }), Text::lit(", "));
    auto head_p2 = prism_rtl::cat(t_p0.name_p, generic_names_f(t_p0.params_p));
    auto doc_p3 = crate::emit::rust::templates::source_doc_f(prism_rtl::cat("`", t_p0.prism_p, "`:"), t_p0.doc_p);
    auto decl_p4 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = t_p0.shape_p;
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeRecord>(_m)) {
            _v.set(({
                auto c_p8 = crate::prelude::or_(crate::prelude::index(t_p0.cases_p, Nat(0u)), crate::lower::model::CaseDef{.name_p = Text::lit(""), .prism_p = Text::lit(""), .fields_p = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .labels_p = Array<Text>{}});
                (crate::emit::rust::templates::items::struct_f(doc_p3, derives_p1, head_p2, crate::syntax::lexer::chars::join_f(crate::prelude::run_to_end(crate::prelude::each_job(prism_rtl::deref(c_p8).fields_p, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
                return crate::prelude::entered(crate::prelude::once_job([=]() {
                    return ({
                        auto [f_p9, ft_pa] = p0;
                        (crate::prelude::call_then(crate::emit::rust::start_type_f(ft_pa), [=](Text type_f_5233) { return prism_rtl::finished(prism_rtl::cat("pub ", f_p9, ": ", type_f_5233, ",")); }));
                    });
                }));
            })))), Text::lit("\n"))));
            }));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeUnit>(_m)) {
            _v.set(crate::emit::rust::templates::items::tuple_struct_f(doc_p3, derives_p1, head_p2, Text::lit("")));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeNewtype>(_m)) {
            _v.set(({
                auto c_pb = crate::prelude::or_(crate::prelude::index(t_p0.cases_p, Nat(0u)), crate::lower::model::CaseDef{.name_p = Text::lit(""), .prism_p = Text::lit(""), .fields_p = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .labels_p = Array<Text>{}});
                (crate::emit::rust::templates::items::tuple_struct_f(doc_p3, derives_p1, head_p2, prism_rtl::cat("(", crate::syntax::lexer::chars::join_f(crate::prelude::run_to_end(crate::prelude::each_job(prism_rtl::deref(c_pb).fields_p, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
                return crate::prelude::entered(crate::prelude::once_job([=]() {
                    return ({
                        auto&& _ft_pc = p0;
                        auto&& ft_pc = std::get<1>(_ft_pc);
                        (crate::prelude::call_then(crate::emit::rust::start_type_f(ft_pc), [=](Text type_f_5510) { return prism_rtl::finished(prism_rtl::cat("pub ", type_f_5510)); }));
                    });
                }));
            })))), Text::lit(", ")), ")")));
            }));
            goto _done;
        }
        {
            _v.set(crate::emit::rust::templates::items::enum_f(doc_p3, derives_p1, head_p2, crate::syntax::lexer::chars::join_f(crate::prelude::run_to_end(crate::prelude::each_job(t_p0.cases_p, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::CaseDef)>>(prism_rtl::rc([=](crate::lower::model::CaseDef p0) {
                return crate::prelude::entered(crate::prelude::once_job([=]() {
                    return ({
                        auto c_pd = p0;
                        (prism_rtl::more(prism_rtl::rc(EnumCase(c_pd))));
                    });
                }));
            })))), Text::lit("\n"))));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto show_p5 = t_p0.show_p == crate::lower::model::Shown(crate::lower::model::Shown::ShownDerived{})
        ? prism_rtl::cat("\n", show_impl_f(t_p0, head_p2))
        : Text::lit("");
    auto pod_p6 = t_p0.pod_p
        ? prism_rtl::cat("\n", to_pod_impl_f(t_p0, head_p2), "\n", from_pod_impl_f(t_p0, head_p2))
        : Text::lit("");
    return prism_rtl::cat(decl_p4, show_p5, pod_p6);
}


prism_rtl::Turn<Text> TypeDecl::cycle() const {
    const auto& t_p0 = this->t_p0;
    auto derives_p1 = crate::syntax::lexer::chars::join_f(crate::prelude::filter(Array(std::vector{Text::lit("Clone"), prism_rtl::deref(t_p0).eq_p || prism_rtl::deref(t_p0).ord_p
        ? Text::lit("PartialEq, Eq")
        : Text::lit(""), prism_rtl::deref(t_p0).ord_p ? Text::lit("PartialOrd, Ord") : Text::lit("")}), [&](const Text& d_p7) { return d_p7 != Text::lit(""); }), Text::lit(", "));
    auto head_p2 = prism_rtl::cat(prism_rtl::deref(t_p0).name_p, generic_names_f(prism_rtl::deref(t_p0).params_p));
    auto doc_p3 = crate::emit::rust::templates::source_doc_f(prism_rtl::cat("`", prism_rtl::deref(t_p0).prism_p, "`:"), prism_rtl::deref(t_p0).doc_p);
    auto decl_p4 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = prism_rtl::deref(t_p0).shape_p;
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeRecord>(_m)) {
            _v.set(({
                auto c_p8 = crate::prelude::or_(crate::prelude::index(prism_rtl::deref(t_p0).cases_p, Nat(0u)), crate::lower::model::CaseDef{.name_p = Text::lit(""), .prism_p = Text::lit(""), .fields_p = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .labels_p = Array<Text>{}});
                (crate::emit::rust::templates::items::struct_f(doc_p3, derives_p1, head_p2, crate::syntax::lexer::chars::join_f(crate::prelude::run_to_end(crate::prelude::each_job(prism_rtl::deref(c_p8).fields_p, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
                return crate::prelude::entered(crate::prelude::once_job([=]() {
                    return ({
                        auto [f_p9, ft_pa] = p0;
                        (crate::prelude::call_then(crate::emit::rust::start_type_f(ft_pa), [=](Text type_f_5233) { return prism_rtl::finished(prism_rtl::cat("pub ", f_p9, ": ", type_f_5233, ",")); }));
                    });
                }));
            })))), Text::lit("\n"))));
            }));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeUnit>(_m)) {
            _v.set(crate::emit::rust::templates::items::tuple_struct_f(doc_p3, derives_p1, head_p2, Text::lit("")));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeNewtype>(_m)) {
            _v.set(({
                auto c_pb = crate::prelude::or_(crate::prelude::index(prism_rtl::deref(t_p0).cases_p, Nat(0u)), crate::lower::model::CaseDef{.name_p = Text::lit(""), .prism_p = Text::lit(""), .fields_p = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .labels_p = Array<Text>{}});
                (crate::emit::rust::templates::items::tuple_struct_f(doc_p3, derives_p1, head_p2, prism_rtl::cat("(", crate::syntax::lexer::chars::join_f(crate::prelude::run_to_end(crate::prelude::each_job(prism_rtl::deref(c_pb).fields_p, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
                return crate::prelude::entered(crate::prelude::once_job([=]() {
                    return ({
                        auto&& _ft_pc = p0;
                        auto&& ft_pc = std::get<1>(_ft_pc);
                        (crate::prelude::call_then(crate::emit::rust::start_type_f(ft_pc), [=](Text type_f_5510) { return prism_rtl::finished(prism_rtl::cat("pub ", type_f_5510)); }));
                    });
                }));
            })))), Text::lit(", ")), ")")));
            }));
            goto _done;
        }
        {
            _v.set(crate::emit::rust::templates::items::enum_f(doc_p3, derives_p1, head_p2, crate::syntax::lexer::chars::join_f(crate::prelude::run_to_end(crate::prelude::each_job(prism_rtl::deref(t_p0).cases_p, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::CaseDef)>>(prism_rtl::rc([=](crate::lower::model::CaseDef p0) {
                return crate::prelude::entered(crate::prelude::once_job([=]() {
                    return ({
                        auto c_pd = p0;
                        (prism_rtl::more(prism_rtl::rc(EnumCase(c_pd))));
                    });
                }));
            })))), Text::lit("\n"))));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto show_p5 = prism_rtl::deref(t_p0).show_p == crate::lower::model::Shown(crate::lower::model::Shown::ShownDerived{})
        ? prism_rtl::cat("\n", show_impl_f(t_p0, head_p2))
        : Text::lit("");
    auto pod_p6 = prism_rtl::deref(t_p0).pod_p
        ? prism_rtl::cat("\n", to_pod_impl_f(t_p0, head_p2), "\n", from_pod_impl_f(t_p0, head_p2))
        : Text::lit("");
    return prism_rtl::finished(prism_rtl::cat(decl_p4, show_p5, pod_p6));
}


/// `Start TypeDecl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_type_decl_f(crate::lower::model::TyDef t_p0) {
    return prism_rtl::make_rc<TypeDecl>(t_p0);
}


/// EnumCase: unbounded fn CaseDef -> Text
Text enum_case_f(const crate::lower::model::CaseDef& c_p0) {
    return crate::prelude::len(c_p0.fields_p) == Nat(0u)
        ? prism_rtl::cat(c_p0.name_p, ",")
        : prism_rtl::cat(c_p0.name_p, "(", crate::syntax::lexer::chars::join_f(crate::prelude::run_to_end(crate::prelude::each_job(c_p0.fields_p, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto&& _ft_p1 = p0;
                auto&& ft_p1 = std::get<1>(_ft_p1);
                (prism_rtl::more(prism_rtl::rc(crate::emit::rust::Type(ft_p1))));
            });
        }));
    })))), Text::lit(", ")), "),");
}


prism_rtl::Turn<Text> EnumCase::cycle() const {
    const auto& c_p0 = this->c_p0;
    return crate::prelude::len(prism_rtl::deref(c_p0).fields_p) == Nat(0u)
        ? prism_rtl::finished(prism_rtl::cat(prism_rtl::deref(c_p0).name_p, ","))
        : ({
        auto c_p0x = c_p0;
        (crate::prelude::call_value(crate::prelude::each_job(prism_rtl::deref(c_p0x).fields_p, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto&& _ft_p1 = p0;
                auto&& ft_p1 = std::get<1>(_ft_p1);
                (prism_rtl::more(prism_rtl::rc(crate::emit::rust::Type(ft_p1))));
            });
        }));
    }))), [=](Array<Text> each_5912) { return prism_rtl::finished(prism_rtl::cat(prism_rtl::deref(c_p0x).name_p, "(", crate::syntax::lexer::chars::join_f(each_5912, Text::lit(", ")), "),")); }));
    });
}


/// `Start EnumCase, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_enum_case_f(crate::lower::model::CaseDef c_p0) {
    return prism_rtl::make_rc<EnumCase>(c_p0);
}


/// Binders: fn Nat -> [Text]
Array<Text> binders_f(const Nat& n_p0) {
    return crate::prelude::each(crate::check::errors::range0_f(n_p0), [&](const Nat& i_p1) { return prism_rtl::cat("a", i_p1); });
}


/// CasePattern: fn TyDef, CaseDef -> Text
Text case_pattern_f(const crate::lower::model::TyDef& t_p0, const crate::lower::model::CaseDef& c_p1) {
    auto&& _m = t_p0.shape_p;
    if (prism_rtl::is<crate::lower::model::TyShape::ShapeNewtype>(_m)) {
        return prism_rtl::cat(t_p0.name_p, "(", crate::syntax::lexer::chars::join_f(binders_f(crate::prelude::len(c_p1.fields_p)), Text::lit(", ")), ")");
    }
    if (prism_rtl::is<crate::lower::model::TyShape::ShapeUnit>(_m)) {
        return t_p0.name_p;
    }
    {
        return crate::prelude::len(c_p1.fields_p) == Nat(0u)
            ? prism_rtl::cat(t_p0.name_p, "::", c_p1.name_p)
            : prism_rtl::cat(t_p0.name_p, "::", c_p1.name_p, "(", crate::syntax::lexer::chars::join_f(binders_f(crate::prelude::len(c_p1.fields_p)), Text::lit(", ")), ")");
    }
}


/// ShowImpl: unbounded fn TyDef, Text -> Text
Text show_impl_f(const crate::lower::model::TyDef& t_p0, const Text& head_p1) {
    auto body_p2 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = t_p0.shape_p;
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeRecord>(_m)) {
            _v.set(({
                auto c_p3 = crate::prelude::or_(crate::prelude::index(t_p0.cases_p, Nat(0u)), crate::lower::model::CaseDef{.name_p = Text::lit(""), .prism_p = Text::lit(""), .fields_p = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .labels_p = Array<Text>{}});
                (prism_rtl::cat("p.record(\"", t_p0.prism_p, "\", &[", crate::syntax::lexer::chars::join_f(crate::prelude::each(prism_rtl::deref(c_p3).fields_p, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
                auto&& f_p4 = std::get<0>(_p0);
                return prism_rtl::cat("(\"", prism_field_of_f(c_p3, f_p4), "\", &self.", f_p4, ")");
            }), Text::lit(", ")), "]);"));
            }));
            goto _done;
        }
        {
            _v.set(crate::emit::rust::templates::items::match_self_f(crate::syntax::lexer::chars::join_f(crate::prelude::each(t_p0.cases_p, [&](const crate::lower::model::CaseDef& c_p5) { return prism_rtl::cat(case_pattern_f(t_p0, c_p5), " => p.choice(\"", prism_rtl::deref(c_p5).prism_p, "\", &[", crate::syntax::lexer::chars::join_f(binders_f(crate::prelude::len(prism_rtl::deref(c_p5).fields_p)), Text::lit(", ")), "]),"); }), Text::lit("\n"))));
            goto _done;
        }
    _done:
        _v.take();
    });
    return crate::emit::rust::templates::items::impl_f(bounded_f(t_p0.params_p, Text::lit("Show")), Text::lit("Show"), head_p1, Text::lit("fn show(&self, p: &mut Printer)"), body_p2);
}


prism_rtl::Turn<Text> ShowImpl::cycle() const {
    const auto& t_p0 = this->t_p0;
    const auto& head_p1 = this->head_p1;
    auto body_p2 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = prism_rtl::deref(t_p0).shape_p;
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeRecord>(_m)) {
            _v.set(({
                auto c_p3 = crate::prelude::or_(crate::prelude::index(prism_rtl::deref(t_p0).cases_p, Nat(0u)), crate::lower::model::CaseDef{.name_p = Text::lit(""), .prism_p = Text::lit(""), .fields_p = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .labels_p = Array<Text>{}});
                (prism_rtl::cat("p.record(\"", prism_rtl::deref(t_p0).prism_p, "\", &[", crate::syntax::lexer::chars::join_f(crate::prelude::each(prism_rtl::deref(c_p3).fields_p, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
                auto&& f_p4 = std::get<0>(_p0);
                return prism_rtl::cat("(\"", prism_field_of_f(c_p3, f_p4), "\", &self.", f_p4, ")");
            }), Text::lit(", ")), "]);"));
            }));
            goto _done;
        }
        {
            _v.set(crate::emit::rust::templates::items::match_self_f(crate::syntax::lexer::chars::join_f(crate::prelude::each(prism_rtl::deref(t_p0).cases_p, [&](const crate::lower::model::CaseDef& c_p5) { return prism_rtl::cat(case_pattern_f(t_p0, c_p5), " => p.choice(\"", prism_rtl::deref(c_p5).prism_p, "\", &[", crate::syntax::lexer::chars::join_f(binders_f(crate::prelude::len(prism_rtl::deref(c_p5).fields_p)), Text::lit(", ")), "]),"); }), Text::lit("\n"))));
            goto _done;
        }
    _done:
        _v.take();
    });
    return prism_rtl::finished(crate::emit::rust::templates::items::impl_f(bounded_f(prism_rtl::deref(t_p0).params_p, Text::lit("Show")), Text::lit("Show"), head_p1, Text::lit("fn show(&self, p: &mut Printer)"), body_p2));
}


/// `Start ShowImpl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_show_impl_f(crate::lower::model::TyDef t_p0, Text head_p1) {
    return prism_rtl::make_rc<ShowImpl>(t_p0, head_p1);
}


/// PrismField: fn Text -> Text
Text prism_field_f(const Text& f_p0) {
    return crate::syntax::lexer::chars::last_char_f(f_p0) == Text::lit("_")
        ? crate::syntax::lexer::chars::before_last_f(f_p0)
        : f_p0;
}


/// PrismFieldOf: fn CaseDef, Text -> Text
Text prism_field_of_f(const crate::lower::model::CaseDef& c_p0, const Text& f_p1) {
    return crate::prelude::fold(crate::check::errors::range0_f(crate::prelude::len(c_p0.fields_p)), prism_field_f(f_p1), [&](const Text& found_p2, const Nat& i_p3) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Text> _v;
            auto&& _m = std::tuple{crate::prelude::index(c_p0.fields_p, i_p3), crate::prelude::index(c_p0.labels_p, i_p3)};
            if (prism_rtl::is_some(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m))) {
                auto&& g_p4 = std::get<0>(prism_rtl::some_of(std::get<0>(_m)));
                auto&& label_p5 = prism_rtl::some_of(std::get<1>(_m));
                _v.set(g_p4 == f_p1 ? label_p5 : found_p2);
                goto _done;
            }
            {
                _v.set(found_p2);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


/// ToPodImpl: unbounded fn TyDef, Text -> Text
Text to_pod_impl_f(const crate::lower::model::TyDef& t_p0, const Text& head_p1) {
    auto body_p2 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = t_p0.shape_p;
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeRecord>(_m)) {
            _v.set(({
                auto c_p4 = crate::prelude::or_(crate::prelude::index(t_p0.cases_p, Nat(0u)), crate::lower::model::CaseDef{.name_p = Text::lit(""), .prism_p = Text::lit(""), .fields_p = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .labels_p = Array<Text>{}});
                (prism_rtl::cat("Pod::record(\"", t_p0.prism_p, "\", vec![", crate::syntax::lexer::chars::join_f(crate::prelude::each(prism_rtl::deref(c_p4).fields_p, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
                auto&& f_p5 = std::get<0>(_p0);
                return prism_rtl::cat("(\"", prism_field_of_f(c_p4, f_p5), "\", self.", f_p5, ".to_pod())");
            }), Text::lit(", ")), "])"));
            }));
            goto _done;
        }
        {
            _v.set(crate::emit::rust::templates::items::match_self_f(crate::syntax::lexer::chars::join_f(crate::prelude::each(t_p0.cases_p, [&](const crate::lower::model::CaseDef& c_p6) { return prism_rtl::cat(case_pattern_f(t_p0, c_p6), " => Pod::Choice(\"", prism_rtl::deref(c_p6).prism_p, "\".into(), vec![", crate::syntax::lexer::chars::join_f(crate::prelude::each(binders_f(crate::prelude::len(prism_rtl::deref(c_p6).fields_p)), [&](const Text& b_p7) { return prism_rtl::cat(b_p7, ".to_pod()"); }), Text::lit(", ")), "]),"); }), Text::lit("\n"))));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto shown_p3 = t_p0.show_p == crate::lower::model::Shown(crate::lower::model::Shown::ShownOwn{})
        ? crate::emit::rust::templates::items::shown_pod_f(body_p2)
        : body_p2;
    return crate::emit::rust::templates::items::impl_f(bounded_f(t_p0.params_p, Text::lit("ToPod")), Text::lit("ToPod"), head_p1, Text::lit("fn to_pod(&self) -> Pod"), shown_p3);
}


prism_rtl::Turn<Text> ToPodImpl::cycle() const {
    const auto& t_p0 = this->t_p0;
    const auto& head_p1 = this->head_p1;
    auto body_p2 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = prism_rtl::deref(t_p0).shape_p;
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeRecord>(_m)) {
            _v.set(({
                auto c_p4 = crate::prelude::or_(crate::prelude::index(prism_rtl::deref(t_p0).cases_p, Nat(0u)), crate::lower::model::CaseDef{.name_p = Text::lit(""), .prism_p = Text::lit(""), .fields_p = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .labels_p = Array<Text>{}});
                (prism_rtl::cat("Pod::record(\"", prism_rtl::deref(t_p0).prism_p, "\", vec![", crate::syntax::lexer::chars::join_f(crate::prelude::each(prism_rtl::deref(c_p4).fields_p, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
                auto&& f_p5 = std::get<0>(_p0);
                return prism_rtl::cat("(\"", prism_field_of_f(c_p4, f_p5), "\", self.", f_p5, ".to_pod())");
            }), Text::lit(", ")), "])"));
            }));
            goto _done;
        }
        {
            _v.set(crate::emit::rust::templates::items::match_self_f(crate::syntax::lexer::chars::join_f(crate::prelude::each(prism_rtl::deref(t_p0).cases_p, [&](const crate::lower::model::CaseDef& c_p6) { return prism_rtl::cat(case_pattern_f(t_p0, c_p6), " => Pod::Choice(\"", prism_rtl::deref(c_p6).prism_p, "\".into(), vec![", crate::syntax::lexer::chars::join_f(crate::prelude::each(binders_f(crate::prelude::len(prism_rtl::deref(c_p6).fields_p)), [&](const Text& b_p7) { return prism_rtl::cat(b_p7, ".to_pod()"); }), Text::lit(", ")), "]),"); }), Text::lit("\n"))));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto shown_p3 = prism_rtl::deref(t_p0).show_p == crate::lower::model::Shown(crate::lower::model::Shown::ShownOwn{})
        ? crate::emit::rust::templates::items::shown_pod_f(body_p2)
        : body_p2;
    return prism_rtl::finished(crate::emit::rust::templates::items::impl_f(bounded_f(prism_rtl::deref(t_p0).params_p, Text::lit("ToPod")), Text::lit("ToPod"), head_p1, Text::lit("fn to_pod(&self) -> Pod"), shown_p3));
}


/// `Start ToPodImpl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_to_pod_impl_f(crate::lower::model::TyDef t_p0, Text head_p1) {
    return prism_rtl::make_rc<ToPodImpl>(t_p0, head_p1);
}


/// FromPodImpl: unbounded fn TyDef, Text -> Text
Text from_pod_impl_f(const crate::lower::model::TyDef& t_p0, const Text& head_p1) {
    auto body_p2 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = t_p0.shape_p;
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeRecord>(_m)) {
            _v.set(({
                auto c_p3 = crate::prelude::or_(crate::prelude::index(t_p0.cases_p, Nat(0u)), crate::lower::model::CaseDef{.name_p = Text::lit(""), .prism_p = Text::lit(""), .fields_p = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .labels_p = Array<Text>{}});
                (prism_rtl::cat("Ok(", t_p0.name_p, " { ", crate::syntax::lexer::chars::join_f(crate::prelude::each(prism_rtl::deref(c_p3).fields_p, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
                auto&& f_p4 = std::get<0>(_p0);
                return prism_rtl::cat(f_p4, ": FromPod::from_pod(field(p, \"", prism_field_of_f(c_p3, f_p4), "\")?)?");
            }), Text::lit(", ")), " })"));
            }));
            goto _done;
        }
        {
            _v.set(({
                auto arms_p5 = crate::prelude::each(t_p0.cases_p, [&](const crate::lower::model::CaseDef& c_p6) {
                    return ({
                        auto n_p7 = crate::prelude::len(prism_rtl::deref(c_p6).fields_p);
                        auto made_p8 = n_p7 == Nat(0u)
                            ? t_p0.shape_p == crate::lower::model::TyShape(crate::lower::model::TyShape::ShapeUnit{})
                            ? t_p0.name_p
                            : prism_rtl::cat(t_p0.name_p, "::", prism_rtl::deref(c_p6).name_p)
                            : prism_rtl::cat(t_p0.shape_p == crate::lower::model::TyShape(crate::lower::model::TyShape::ShapeNewtype{})
                            ? t_p0.name_p
                            : prism_rtl::cat(t_p0.name_p, "::", prism_rtl::deref(c_p6).name_p), "(", crate::syntax::lexer::chars::join_f(crate::prelude::each(crate::check::errors::range0_f(n_p7), [&](const Nat& i_p9) { return prism_rtl::cat("FromPod::from_pod(&a[", i_p9, "])?"); }), Text::lit(", ")), ")");
                        (prism_rtl::cat("Pod::Choice(c, a) if &**c == \"", prism_rtl::deref(c_p6).prism_p, "\" && a.len() == ", n_p7, " => Ok(", made_p8, "),"));
                    });
                });
                (crate::emit::rust::templates::items::from_pod_body_f(crate::syntax::lexer::chars::join_f(arms_p5, Text::lit("\n")), prism_rtl::cat("a ", t_p0.prism_p)));
            }));
            goto _done;
        }
    _done:
        _v.take();
    });
    return crate::emit::rust::templates::items::impl_f(bounded_f(t_p0.params_p, Text::lit("FromPod")), Text::lit("FromPod"), head_p1, Text::lit("fn from_pod(p: &Pod) -> Result<Self, Fault>"), body_p2);
}


prism_rtl::Turn<Text> FromPodImpl::cycle() const {
    const auto& t_p0 = this->t_p0;
    const auto& head_p1 = this->head_p1;
    auto body_p2 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = prism_rtl::deref(t_p0).shape_p;
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeRecord>(_m)) {
            _v.set(({
                auto c_p3 = crate::prelude::or_(crate::prelude::index(prism_rtl::deref(t_p0).cases_p, Nat(0u)), crate::lower::model::CaseDef{.name_p = Text::lit(""), .prism_p = Text::lit(""), .fields_p = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .labels_p = Array<Text>{}});
                (prism_rtl::cat("Ok(", prism_rtl::deref(t_p0).name_p, " { ", crate::syntax::lexer::chars::join_f(crate::prelude::each(prism_rtl::deref(c_p3).fields_p, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
                auto&& f_p4 = std::get<0>(_p0);
                return prism_rtl::cat(f_p4, ": FromPod::from_pod(field(p, \"", prism_field_of_f(c_p3, f_p4), "\")?)?");
            }), Text::lit(", ")), " })"));
            }));
            goto _done;
        }
        {
            _v.set(({
                auto arms_p5 = crate::prelude::each(prism_rtl::deref(t_p0).cases_p, [&](const crate::lower::model::CaseDef& c_p6) {
                    return ({
                        auto n_p7 = crate::prelude::len(prism_rtl::deref(c_p6).fields_p);
                        auto made_p8 = n_p7 == Nat(0u)
                            ? prism_rtl::deref(t_p0).shape_p == crate::lower::model::TyShape(crate::lower::model::TyShape::ShapeUnit{})
                            ? prism_rtl::deref(t_p0).name_p
                            : prism_rtl::cat(prism_rtl::deref(t_p0).name_p, "::", prism_rtl::deref(c_p6).name_p)
                            : prism_rtl::cat(prism_rtl::deref(t_p0).shape_p == crate::lower::model::TyShape(crate::lower::model::TyShape::ShapeNewtype{})
                            ? prism_rtl::deref(t_p0).name_p
                            : prism_rtl::cat(prism_rtl::deref(t_p0).name_p, "::", prism_rtl::deref(c_p6).name_p), "(", crate::syntax::lexer::chars::join_f(crate::prelude::each(crate::check::errors::range0_f(n_p7), [&](const Nat& i_p9) { return prism_rtl::cat("FromPod::from_pod(&a[", i_p9, "])?"); }), Text::lit(", ")), ")");
                        (prism_rtl::cat("Pod::Choice(c, a) if &**c == \"", prism_rtl::deref(c_p6).prism_p, "\" && a.len() == ", n_p7, " => Ok(", made_p8, "),"));
                    });
                });
                (crate::emit::rust::templates::items::from_pod_body_f(crate::syntax::lexer::chars::join_f(arms_p5, Text::lit("\n")), prism_rtl::cat("a ", prism_rtl::deref(t_p0).prism_p)));
            }));
            goto _done;
        }
    _done:
        _v.take();
    });
    return prism_rtl::finished(crate::emit::rust::templates::items::impl_f(bounded_f(prism_rtl::deref(t_p0).params_p, Text::lit("FromPod")), Text::lit("FromPod"), head_p1, Text::lit("fn from_pod(p: &Pod) -> Result<Self, Fault>"), body_p2));
}


/// `Start FromPodImpl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_from_pod_impl_f(crate::lower::model::TyDef t_p0, Text head_p1) {
    return prism_rtl::make_rc<FromPodImpl>(t_p0, head_p1);
}


/// RustTag: unbounded fn TagDef -> Text
Text rust_tag_f(const crate::lower::model::TagDef& t_p0) {
    auto fields_p1 = crate::syntax::lexer::chars::join_f(crate::prelude::run_to_end(crate::prelude::each_job(t_p0.fields_p, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, Text, crate::lower::model::OutTy> p0) {
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto&& _f_pa = p0;
                auto&& f_pa = std::get<1>(_f_pa);
                auto&& ft_pb = std::get<2>(_f_pa);
                (crate::prelude::call_then(crate::emit::rust::start_type_f(ft_pb), [=](Text type_f_9296) { return prism_rtl::finished(prism_rtl::cat("pub ", f_pa, ": ", type_f_9296, ",")); }));
            });
        }));
    })))), Text::lit("\n"));
    auto pods_p2 = crate::syntax::lexer::chars::join_f(crate::prelude::each(t_p0.fields_p, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
        auto&& p_pc = std::get<0>(_p0);
        auto&& f_pd = std::get<1>(_p0);
        return prism_rtl::cat("(\"", p_pc, "\", self.", f_pd, ".to_pod())");
    }), Text::lit(", "));
    auto derives_p3 = t_p0.eq_p ? Text::lit("Clone, PartialEq, Eq") : Text::lit("Clone");
    auto reads_p4 = crate::syntax::lexer::chars::join_f(crate::prelude::each(t_p0.fields_p, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
        auto&& p_pe = std::get<0>(_p0);
        auto&& f_pf = std::get<1>(_p0);
        return prism_rtl::cat(f_pf, ": FromPod::from_pod(field(p, \"", p_pe, "\")?)?");
    }), Text::lit(", "));
    auto back_p5 = t_p0.pod_p
        ? prism_rtl::cat("\n", crate::emit::rust::templates::items::tag_from_pod_f(t_p0.name_p, t_p0.tag_name_p, reads_p4))
        : Text::lit("");
    auto deep_p6 = crate::prelude::run_to_end(crate::prelude::fold_job(t_p0.fields_p, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, Text, crate::lower::model::OutTy>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<Text, Text, crate::lower::model::OutTy>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto d_pg = p0;
                auto&& _ft_ph = p1;
                auto&& ft_ph = std::get<2>(_ft_ph);
                (prism_rtl::finished(std::move(d_pg) || crate::lower::types::holds_dyn_f(ft_ph)));
            });
        }));
    }))));
    auto deep_pods_p7 = crate::syntax::lexer::chars::join_f(crate::prelude::run_to_end(crate::prelude::each_job(t_p0.fields_p, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, Text, crate::lower::model::OutTy> p0) {
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto [p_pi, f_pj, ft_pk] = p0;
                (prism_rtl::more(prism_rtl::rc(DeepField(p_pi, f_pj, ft_pk))));
            });
        }));
    })))), Text::lit(", "));
    auto deep_ports_p8 = crate::prelude::concat(crate::prelude::run_to_end(crate::prelude::each_job(t_p0.fields_p, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, Text, crate::lower::model::OutTy> p0) {
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto&& _f_pl = p0;
                auto&& f_pl = std::get<1>(_f_pl);
                auto&& ft_pm = std::get<2>(_f_pl);
                (prism_rtl::more(prism_rtl::rc(DeepPorts(f_pl, ft_pm))));
            });
        }));
    })))));
    auto levels_p9 = std::move(deep_p6)
        ? prism_rtl::cat("\n", crate::emit::rust::templates::items::tag_level_f(t_p0.name_p, t_p0.tag_name_p, deep_pods_p7, deep_ports_p8))
        : Text::lit("");
    return prism_rtl::cat(crate::emit::rust::templates::items::tag_f(crate::emit::rust::templates::source_doc_f(prism_rtl::cat("The `Level` of `", t_p0.tag_name_p, "`:"), t_p0.doc_p), derives_p3, t_p0.name_p, fields_p1, t_p0.tag_name_p, pods_p2), back_p5, levels_p9);
}


prism_rtl::Turn<Text> RustTag::cycle() const {
    const auto& t_p0 = this->t_p0;
    auto t_p0x = t_p0;
    return crate::prelude::call_value(crate::prelude::each_job(prism_rtl::deref(t_p0x).fields_p, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, Text, crate::lower::model::OutTy> p0) {
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto&& _f_pa = p0;
                auto&& f_pa = std::get<1>(_f_pa);
                auto&& ft_pb = std::get<2>(_f_pa);
                (crate::prelude::call_then(crate::emit::rust::start_type_f(ft_pb), [=](Text type_f_9296) { return prism_rtl::finished(prism_rtl::cat("pub ", f_pa, ": ", type_f_9296, ",")); }));
            });
        }));
    }))), [=](Array<Text> each_9249) {
        return ({
            auto fields_p1 = crate::syntax::lexer::chars::join_f(each_9249, Text::lit("\n"));
            auto pods_p2 = crate::syntax::lexer::chars::join_f(crate::prelude::each(prism_rtl::deref(t_p0x).fields_p, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
                auto&& p_pc = std::get<0>(_p0);
                auto&& f_pd = std::get<1>(_p0);
                return prism_rtl::cat("(\"", p_pc, "\", self.", f_pd, ".to_pod())");
            }), Text::lit(", "));
            auto derives_p3 = prism_rtl::deref(t_p0x).eq_p
                ? Text::lit("Clone, PartialEq, Eq")
                : Text::lit("Clone");
            auto reads_p4 = crate::syntax::lexer::chars::join_f(crate::prelude::each(prism_rtl::deref(t_p0x).fields_p, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
                auto&& p_pe = std::get<0>(_p0);
                auto&& f_pf = std::get<1>(_p0);
                return prism_rtl::cat(f_pf, ": FromPod::from_pod(field(p, \"", p_pe, "\")?)?");
            }), Text::lit(", "));
            auto back_p5 = prism_rtl::deref(t_p0x).pod_p
                ? prism_rtl::cat("\n", crate::emit::rust::templates::items::tag_from_pod_f(prism_rtl::deref(t_p0x).name_p, prism_rtl::deref(t_p0x).tag_name_p, reads_p4))
                : Text::lit("");
            (crate::prelude::call_value(crate::prelude::fold_job(prism_rtl::deref(t_p0x).fields_p, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, Text, crate::lower::model::OutTy>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<Text, Text, crate::lower::model::OutTy>> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto d_pg = p0;
                    auto&& _ft_ph = p1;
                    auto&& ft_ph = std::get<2>(_ft_ph);
                    (prism_rtl::finished(std::move(d_pg) || crate::lower::types::holds_dyn_f(ft_ph)));
                });
            }));
        }))), [=, fields_p1 = std::move(fields_p1), pods_p2 = std::move(pods_p2), derives_p3 = std::move(derives_p3), back_p5 = std::move(back_p5)](bool fold_9673) {
            return ({
                auto deep_p6 = fold_9673;
                (crate::prelude::call_value(crate::prelude::each_job(prism_rtl::deref(t_p0x).fields_p, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, Text, crate::lower::model::OutTy> p0) {
                return crate::prelude::entered(crate::prelude::once_job([=]() {
                    return ({
                        auto [p_pi, f_pj, ft_pk] = p0;
                        (prism_rtl::more(prism_rtl::rc(DeepField(p_pi, f_pj, ft_pk))));
                    });
                }));
            }))), [=, deep_p6 = std::move(deep_p6)](Array<Text> each_9766) {
                return ({
                    auto deep_pods_p7 = crate::syntax::lexer::chars::join_f(each_9766, Text::lit(", "));
                    (crate::prelude::call_value(crate::prelude::each_job(prism_rtl::deref(t_p0x).fields_p, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, Text, crate::lower::model::OutTy> p0) {
                    return crate::prelude::entered(crate::prelude::once_job([=]() {
                        return ({
                            auto&& _f_pl = p0;
                            auto&& f_pl = std::get<1>(_f_pl);
                            auto&& ft_pm = std::get<2>(_f_pl);
                            (prism_rtl::more(prism_rtl::rc(DeepPorts(f_pl, ft_pm))));
                        });
                    }));
                }))), [=, deep_pods_p7 = std::move(deep_pods_p7)](Array<Text> each_9851) {
                    return ({
                        auto deep_ports_p8 = crate::prelude::concat(each_9851);
                        auto levels_p9 = deep_p6
                            ? prism_rtl::cat("\n", crate::emit::rust::templates::items::tag_level_f(prism_rtl::deref(t_p0x).name_p, prism_rtl::deref(t_p0x).tag_name_p, deep_pods_p7, deep_ports_p8))
                            : Text::lit("");
                        (prism_rtl::finished(prism_rtl::cat(crate::emit::rust::templates::items::tag_f(crate::emit::rust::templates::source_doc_f(prism_rtl::cat("The `Level` of `", prism_rtl::deref(t_p0x).tag_name_p, "`:"), prism_rtl::deref(t_p0x).doc_p), derives_p3, prism_rtl::deref(t_p0x).name_p, fields_p1, prism_rtl::deref(t_p0x).tag_name_p, pods_p2), back_p5, levels_p9)));
                    });
                }));
                });
            }));
            });
        }));
        });
    });
}


/// `Start RustTag, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_rust_tag_f(crate::lower::model::TagDef t_p0) {
    return prism_rtl::make_rc<RustTag>(t_p0);
}


/// DeepField: unbounded fn Text, Text, OutTy -> Text
Text deep_field_f(const Text& p_p0, const Text& f_p1, const crate::lower::model::OutTy& ft_p2) {
    return prism_rtl::cat("(\"", p_p0, "\", ", deep_pod_f(f_p1, ft_p2), ")");
}


prism_rtl::Turn<Text> DeepField::cycle() const {
    const auto& p_p0 = this->p_p0;
    const auto& f_p1 = this->f_p1;
    const auto& ft_p2 = this->ft_p2;
    auto f_p1x = f_p1;
    auto ft_p2x = ft_p2;
    auto p_p0x = p_p0;
    return crate::prelude::call_then(start_deep_pod_f(f_p1x, ft_p2x), [=](Text deep_pod_f_10199) { return prism_rtl::finished(prism_rtl::cat("(\"", p_p0x, "\", ", deep_pod_f_10199, ")")); });
}


/// `Start DeepField, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_deep_field_f(Text p_p0, Text f_p1, crate::lower::model::OutTy ft_p2) {
    return prism_rtl::make_rc<DeepField>(p_p0, f_p1, ft_p2);
}


/// DeepPod: unbounded fn Text, OutTy -> Text
Text deep_pod_f(const Text& f_p0, const crate::lower::model::OutTy& ft_p1) {
    if (prism_rtl::is<crate::lower::model::OutTy::OutMap>(ft_p1)) {
        auto&& m10453_0_1 = prism_rtl::as<crate::lower::model::OutTy::OutMap>(ft_p1).a1;
        if (prism_rtl::is<crate::lower::model::OutTy::OutDyn>(prism_rtl::deref(prism_rtl::deref(m10453_0_1)))) {
            auto&& m10453_0_1_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(prism_rtl::deref(prism_rtl::deref(m10453_0_1))).a0;
            if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(prism_rtl::deref(prism_rtl::deref(m10453_0_1_r_0)))) {
                auto&& m10453_0_1_r_0_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(prism_rtl::deref(prism_rtl::deref(m10453_0_1_r_0))).a0;
                if (m10453_0_1_r_0_r_0 == Text::lit("crate::Elem")) {
                    return prism_rtl::cat("prism_rtl::dynamics_pod(&self.", f_p0, ", cx)");
                }
            }
        }
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutDyn>(ft_p1)) {
        auto&& m10453_1_0 = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(ft_p1).a0;
        if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(prism_rtl::deref(prism_rtl::deref(m10453_1_0)))) {
            auto&& m10453_1_0_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(prism_rtl::deref(prism_rtl::deref(m10453_1_0))).a0;
            if (m10453_1_0_r_0 == Text::lit("crate::Elem")) {
                return prism_rtl::cat("prism_rtl::Level::level_pod(&self.", f_p0, ".sample(cx), cx)");
            }
        }
    }
    {
        auto&& other_p2 = ft_p1;
        return crate::lower::types::holds_dyn_f(other_p2)
            ? Text::lit("compile_error!(\"prismc: a tag field holding a dynamic other than `$Elem` or a map of them is not read deep (claude/incremental-host-document.md, doubt WD)\")")
            : prism_rtl::cat("self.", f_p0, ".to_pod()");
    }
}


prism_rtl::Turn<Text> DeepPod::cycle() const {
    const auto& f_p0 = this->f_p0;
    const auto& ft_p1 = this->ft_p1;
    return ({
        prism_rtl::is<crate::lower::model::OutTy::OutMap>(ft_p1) && ({
        auto&& m10453_0_1 = prism_rtl::as<crate::lower::model::OutTy::OutMap>(ft_p1).a1;
        prism_rtl::is<crate::lower::model::OutTy::OutDyn>(prism_rtl::deref(prism_rtl::deref(m10453_0_1))) && ({
        auto&& m10453_0_1_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(prism_rtl::deref(prism_rtl::deref(m10453_0_1))).a0;
        prism_rtl::is<crate::lower::model::OutTy::OutNamed>(prism_rtl::deref(prism_rtl::deref(m10453_0_1_r_0))) && ({
        auto&& m10453_0_1_r_0_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(prism_rtl::deref(prism_rtl::deref(m10453_0_1_r_0))).a0;
        (m10453_0_1_r_0_r_0 == Text::lit("crate::Elem"));
    });
    });
    }) ? ({
        auto&& m10453_0_1 = prism_rtl::as<crate::lower::model::OutTy::OutMap>(ft_p1).a1;
        auto&& m10453_0_1_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(prism_rtl::deref(prism_rtl::deref(m10453_0_1))).a0;
        auto&& m10453_0_1_r_0_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(prism_rtl::deref(prism_rtl::deref(m10453_0_1_r_0))).a0;
        prism_rtl::finished(prism_rtl::cat("prism_rtl::dynamics_pod(&self.", f_p0, ", cx)"));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutDyn>(ft_p1) && ({
        auto&& m10453_1_0 = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(ft_p1).a0;
        prism_rtl::is<crate::lower::model::OutTy::OutNamed>(prism_rtl::deref(prism_rtl::deref(m10453_1_0))) && ({
        auto&& m10453_1_0_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(prism_rtl::deref(prism_rtl::deref(m10453_1_0))).a0;
        (m10453_1_0_r_0 == Text::lit("crate::Elem"));
    });
    }) ? ({
        auto&& m10453_1_0 = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(ft_p1).a0;
        auto&& m10453_1_0_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(prism_rtl::deref(prism_rtl::deref(m10453_1_0))).a0;
        prism_rtl::finished(prism_rtl::cat("prism_rtl::Level::level_pod(&self.", f_p0, ".sample(cx), cx)"));
    })
        : ({
        auto&& other_p2 = ft_p1;
        ({
        auto f_p0x = f_p0;
        auto other_p2x = other_p2;
        (crate::prelude::call_then(crate::lower::types::start_holds_dyn_f(other_p2x), [=, f_p0x = std::move(f_p0x)](bool holds_dyn_f_10681) {
        return holds_dyn_f_10681
            ? prism_rtl::finished(Text::lit("compile_error!(\"prismc: a tag field holding a dynamic other than `$Elem` or a map of them is not read deep (claude/incremental-host-document.md, doubt WD)\")"))
            : prism_rtl::finished(prism_rtl::cat("self.", f_p0x, ".to_pod()"));
    }));
    });
    });
    });
}


/// `Start DeepPod, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_deep_pod_f(Text f_p0, crate::lower::model::OutTy ft_p1) {
    return prism_rtl::make_rc<DeepPod>(f_p0, ft_p1);
}


/// DeepPorts: unbounded fn Text, OutTy -> Text
Text deep_ports_f(const Text& f_p0, const crate::lower::model::OutTy& ft_p1) {
    if (prism_rtl::is<crate::lower::model::OutTy::OutMap>(ft_p1)) {
        auto&& m10950_0_1 = prism_rtl::as<crate::lower::model::OutTy::OutMap>(ft_p1).a1;
        if (prism_rtl::is<crate::lower::model::OutTy::OutDyn>(prism_rtl::deref(prism_rtl::deref(m10950_0_1)))) {
            auto&& m10950_0_1_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(prism_rtl::deref(prism_rtl::deref(m10950_0_1))).a0;
            if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(prism_rtl::deref(prism_rtl::deref(m10950_0_1_r_0)))) {
                auto&& m10950_0_1_r_0_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(prism_rtl::deref(prism_rtl::deref(m10950_0_1_r_0))).a0;
                if (m10950_0_1_r_0_r_0 == Text::lit("crate::Elem")) {
                    return prism_rtl::cat("\n        prism_rtl::dynamics_ports(&self.", f_p0, ", cx, out);");
                }
            }
        }
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutDyn>(ft_p1)) {
        auto&& m10950_1_0 = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(ft_p1).a0;
        if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(prism_rtl::deref(prism_rtl::deref(m10950_1_0)))) {
            auto&& m10950_1_0_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(prism_rtl::deref(prism_rtl::deref(m10950_1_0))).a0;
            if (m10950_1_0_r_0 == Text::lit("crate::Elem")) {
                return prism_rtl::cat("\n        out.push(self.", f_p0, ".updates.clone());\n        prism_rtl::Level::level_ports(&self.", f_p0, ".sample(cx), cx, out);");
            }
        }
    }
    {
        return Text::lit("");
    }
}


prism_rtl::Turn<Text> DeepPorts::cycle() const {
    const auto& f_p0 = this->f_p0;
    const auto& ft_p1 = this->ft_p1;
    return ({
        prism_rtl::is<crate::lower::model::OutTy::OutMap>(ft_p1) && ({
        auto&& m10950_0_1 = prism_rtl::as<crate::lower::model::OutTy::OutMap>(ft_p1).a1;
        prism_rtl::is<crate::lower::model::OutTy::OutDyn>(prism_rtl::deref(prism_rtl::deref(m10950_0_1))) && ({
        auto&& m10950_0_1_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(prism_rtl::deref(prism_rtl::deref(m10950_0_1))).a0;
        prism_rtl::is<crate::lower::model::OutTy::OutNamed>(prism_rtl::deref(prism_rtl::deref(m10950_0_1_r_0))) && ({
        auto&& m10950_0_1_r_0_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(prism_rtl::deref(prism_rtl::deref(m10950_0_1_r_0))).a0;
        (m10950_0_1_r_0_r_0 == Text::lit("crate::Elem"));
    });
    });
    }) ? ({
        auto&& m10950_0_1 = prism_rtl::as<crate::lower::model::OutTy::OutMap>(ft_p1).a1;
        auto&& m10950_0_1_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(prism_rtl::deref(prism_rtl::deref(m10950_0_1))).a0;
        auto&& m10950_0_1_r_0_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(prism_rtl::deref(prism_rtl::deref(m10950_0_1_r_0))).a0;
        prism_rtl::finished(prism_rtl::cat("\n        prism_rtl::dynamics_ports(&self.", f_p0, ", cx, out);"));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutDyn>(ft_p1) && ({
        auto&& m10950_1_0 = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(ft_p1).a0;
        prism_rtl::is<crate::lower::model::OutTy::OutNamed>(prism_rtl::deref(prism_rtl::deref(m10950_1_0))) && ({
        auto&& m10950_1_0_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(prism_rtl::deref(prism_rtl::deref(m10950_1_0))).a0;
        (m10950_1_0_r_0 == Text::lit("crate::Elem"));
    });
    }) ? ({
        auto&& m10950_1_0 = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(ft_p1).a0;
        auto&& m10950_1_0_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(prism_rtl::deref(prism_rtl::deref(m10950_1_0))).a0;
        prism_rtl::finished(prism_rtl::cat("\n        out.push(self.", f_p0, ".updates.clone());\n        prism_rtl::Level::level_ports(&self.", f_p0, ".sample(cx), cx, out);"));
    })
        : prism_rtl::finished(Text::lit(""));
    });
}


/// `Start DeepPorts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_deep_ports_f(Text f_p0, crate::lower::model::OutTy ft_p1) {
    return prism_rtl::make_rc<DeepPorts>(f_p0, ft_p1);
}


/// RustRow: unbounded fn RowDef -> Text
Text rust_row_f(const crate::lower::model::RowDef& r_p0) {
    auto derives_p1 = r_p0.eq_p ? Text::lit("Clone, PartialEq, Eq") : Text::lit("Clone");
    auto cases_p2 = crate::syntax::lexer::chars::join_f(crate::prelude::each(r_p0.cases_p, [&](const std::tuple<Text, Text>& _p0) {
        auto&& v_pa = std::get<0>(_p0);
        auto&& st_pb = std::get<1>(_p0);
        return prism_rtl::cat(v_pa, "(", st_pb, "),");
    }), Text::lit("\n"));
    auto pods_p3 = crate::syntax::lexer::chars::join_f(crate::prelude::each(r_p0.cases_p, [&](const std::tuple<Text, Text>& _p0) {
        auto&& v_pc = std::get<0>(_p0);
        return prism_rtl::cat(r_p0.name_p, "::", v_pc, "(x) => x.to_pod(),");
    }), Text::lit("\n"));
    auto reads_p4 = crate::syntax::lexer::chars::join_f(crate::prelude::each(r_p0.cases_p, [&](const std::tuple<Text, Text>& _p0) {
        auto&& v_pd = std::get<0>(_p0);
        auto&& st_pe = std::get<1>(_p0);
        return prism_rtl::cat("Some(t) if t == ", st_pe, "::TAG => Ok(", r_p0.name_p, "::", v_pd, "(FromPod::from_pod(p)?)),");
    }), Text::lit("\n"));
    auto back_p5 = r_p0.pod_p
        ? prism_rtl::cat("\n", crate::emit::rust::templates::items::row_from_pod_f(r_p0.name_p, reads_p4))
        : Text::lit("");
    auto pods2_p6 = crate::prelude::len(r_p0.cases_p) == Nat(0u)
        ? Text::lit("_ => unreachable!(),")
        : pods_p3;
    auto deep_pods_p7 = crate::prelude::concat(crate::prelude::each(r_p0.deep_p, [&](const Text& v_pf) { return prism_rtl::cat(r_p0.name_p, "::", v_pf, "(x) => x.level_pod(cx),\n            "); }));
    auto deep_ports_p8 = crate::prelude::concat(crate::prelude::each(r_p0.deep_p, [&](const Text& v_pg) { return prism_rtl::cat(r_p0.name_p, "::", v_pg, "(x) => x.level_ports(cx, out),\n            "); }));
    auto level_p9 = r_p0.level_p
        ? prism_rtl::cat("\n", crate::emit::rust::templates::items::row_level_f(r_p0.name_p, deep_pods_p7, deep_ports_p8))
        : Text::lit("");
    return prism_rtl::cat(crate::emit::rust::templates::items::row_f(crate::emit::rust::templates::source_doc_f(prism_rtl::cat("`", r_p0.prism_p, "`, a row kind\'s values:"), r_p0.doc_p), derives_p1, r_p0.name_p, cases_p2, pods2_p6), back_p5, level_p9);
}


prism_rtl::Turn<Text> RustRow::cycle() const {
    const auto& r_p0 = this->r_p0;
    auto derives_p1 = prism_rtl::deref(r_p0).eq_p
        ? Text::lit("Clone, PartialEq, Eq")
        : Text::lit("Clone");
    auto cases_p2 = crate::syntax::lexer::chars::join_f(crate::prelude::each(prism_rtl::deref(r_p0).cases_p, [&](const std::tuple<Text, Text>& _p0) {
        auto&& v_pa = std::get<0>(_p0);
        auto&& st_pb = std::get<1>(_p0);
        return prism_rtl::cat(v_pa, "(", st_pb, "),");
    }), Text::lit("\n"));
    auto pods_p3 = crate::syntax::lexer::chars::join_f(crate::prelude::each(prism_rtl::deref(r_p0).cases_p, [&](const std::tuple<Text, Text>& _p0) {
        auto&& v_pc = std::get<0>(_p0);
        return prism_rtl::cat(prism_rtl::deref(r_p0).name_p, "::", v_pc, "(x) => x.to_pod(),");
    }), Text::lit("\n"));
    auto reads_p4 = crate::syntax::lexer::chars::join_f(crate::prelude::each(prism_rtl::deref(r_p0).cases_p, [&](const std::tuple<Text, Text>& _p0) {
        auto&& v_pd = std::get<0>(_p0);
        auto&& st_pe = std::get<1>(_p0);
        return prism_rtl::cat("Some(t) if t == ", st_pe, "::TAG => Ok(", prism_rtl::deref(r_p0).name_p, "::", v_pd, "(FromPod::from_pod(p)?)),");
    }), Text::lit("\n"));
    auto back_p5 = prism_rtl::deref(r_p0).pod_p
        ? prism_rtl::cat("\n", crate::emit::rust::templates::items::row_from_pod_f(prism_rtl::deref(r_p0).name_p, reads_p4))
        : Text::lit("");
    auto pods2_p6 = crate::prelude::len(prism_rtl::deref(r_p0).cases_p) == Nat(0u)
        ? Text::lit("_ => unreachable!(),")
        : pods_p3;
    auto deep_pods_p7 = crate::prelude::concat(crate::prelude::each(prism_rtl::deref(r_p0).deep_p, [&](const Text& v_pf) { return prism_rtl::cat(prism_rtl::deref(r_p0).name_p, "::", v_pf, "(x) => x.level_pod(cx),\n            "); }));
    auto deep_ports_p8 = crate::prelude::concat(crate::prelude::each(prism_rtl::deref(r_p0).deep_p, [&](const Text& v_pg) { return prism_rtl::cat(prism_rtl::deref(r_p0).name_p, "::", v_pg, "(x) => x.level_ports(cx, out),\n            "); }));
    auto level_p9 = prism_rtl::deref(r_p0).level_p
        ? prism_rtl::cat("\n", crate::emit::rust::templates::items::row_level_f(prism_rtl::deref(r_p0).name_p, deep_pods_p7, deep_ports_p8))
        : Text::lit("");
    return prism_rtl::finished(prism_rtl::cat(crate::emit::rust::templates::items::row_f(crate::emit::rust::templates::source_doc_f(prism_rtl::cat("`", prism_rtl::deref(r_p0).prism_p, "`, a row kind\'s values:"), prism_rtl::deref(r_p0).doc_p), derives_p1, prism_rtl::deref(r_p0).name_p, cases_p2, pods2_p6), back_p5, level_p9));
}


/// `Start RustRow, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_rust_row_f(crate::lower::model::RowDef r_p0) {
    return prism_rtl::make_rc<RustRow>(r_p0);
}


/// RustAnswer: unbounded fn AnswerDef -> Text
Text rust_answer_f(const crate::lower::model::AnswerDef& a_p0) {
    auto cases_p1 = crate::syntax::lexer::chars::join_f(crate::prelude::run_to_end(crate::prelude::each_job(a_p0.cases_p, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::AnswerCase)>>(prism_rtl::rc([=](crate::lower::model::AnswerCase p0) {
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto c_p5 = p0;
                (crate::prelude::call_then(crate::emit::rust::start_type_f(prism_rtl::deref(c_p5).ty_p), [=](Text type_f_12746) { return prism_rtl::finished(prism_rtl::cat(prism_rtl::deref(c_p5).variant_p, "(", type_f_12746, "),")); }));
            });
        }));
    })))), Text::lit("\n"));
    auto tags_p2 = crate::prelude::len(a_p0.cases_p) == Nat(0u)
        ? Text::lit("_ => unreachable!(),")
        : crate::syntax::lexer::chars::join_f(crate::prelude::each(a_p0.cases_p, [&](const crate::lower::model::AnswerCase& c_p6) { return prism_rtl::cat("Answer::", prism_rtl::deref(c_p6).variant_p, "(_) => ", prism_rtl::deref(c_p6).struct_path_p, "::TAG,"); }), Text::lit("\n"));
    auto accessors_p3 = crate::syntax::lexer::chars::join_f(crate::prelude::run_to_end(crate::prelude::each_job(a_p0.cases_p, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::AnswerCase)>>(prism_rtl::rc([=](crate::lower::model::AnswerCase p0) {
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto c_p7 = p0;
                (crate::prelude::call_then(crate::emit::rust::start_type_f(prism_rtl::deref(c_p7).ty_p), [=](Text type_f_13008) { return prism_rtl::finished(crate::emit::rust::templates::items::answer_getter_f(prism_rtl::deref(c_p7).accessor_p, prism_rtl::deref(c_p7).variant_p, prism_rtl::deref(c_p7).tag_name_p, type_f_13008)); }));
            });
        }));
    })))), Text::lit("\n"));
    auto decodes_p4 = crate::prelude::len(a_p0.cases_p) == Nat(0u)
        ? Text::lit("_ => unreachable!(),")
        : crate::syntax::lexer::chars::join_f(crate::prelude::run_to_end(crate::prelude::each_job(a_p0.cases_p, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::AnswerCase)>>(prism_rtl::rc([=](crate::lower::model::AnswerCase p0) {
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto c_p8 = p0;
                (crate::prelude::call_then(crate::emit::rust::start_decode_head_f(prism_rtl::deref(c_p8).ty_p), [=](Text decode_head_f_13171) { return prism_rtl::finished(prism_rtl::cat("Elem::", prism_rtl::deref(c_p8).variant_p, "(..) => Ok(Answer::", prism_rtl::deref(c_p8).variant_p, "(", decode_head_f_13171, "::from_pod(v)?)),")); }));
            });
        }));
    })))), Text::lit("\n"));
    return crate::emit::rust::templates::items::answer_type_f(cases_p1, tags_p2, accessors_p3, decodes_p4);
}


prism_rtl::Turn<Text> RustAnswer::cycle() const {
    const auto& a_p0 = this->a_p0;
    auto a_p0x = a_p0;
    return crate::prelude::call_value(crate::prelude::each_job(prism_rtl::deref(a_p0x).cases_p, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::AnswerCase)>>(prism_rtl::rc([=](crate::lower::model::AnswerCase p0) {
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto c_p5 = p0;
                (crate::prelude::call_then(crate::emit::rust::start_type_f(prism_rtl::deref(c_p5).ty_p), [=](Text type_f_12746) { return prism_rtl::finished(prism_rtl::cat(prism_rtl::deref(c_p5).variant_p, "(", type_f_12746, "),")); }));
            });
        }));
    }))), [=](Array<Text> each_12713) {
        return ({
            auto cases_p1 = crate::syntax::lexer::chars::join_f(each_12713, Text::lit("\n"));
            auto tags_p2 = crate::prelude::len(prism_rtl::deref(a_p0x).cases_p) == Nat(0u)
                ? Text::lit("_ => unreachable!(),")
                : crate::syntax::lexer::chars::join_f(crate::prelude::each(prism_rtl::deref(a_p0x).cases_p, [&](const crate::lower::model::AnswerCase& c_p6) { return prism_rtl::cat("Answer::", prism_rtl::deref(c_p6).variant_p, "(_) => ", prism_rtl::deref(c_p6).struct_path_p, "::TAG,"); }), Text::lit("\n"));
            (crate::prelude::call_value(crate::prelude::each_job(prism_rtl::deref(a_p0x).cases_p, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::AnswerCase)>>(prism_rtl::rc([=](crate::lower::model::AnswerCase p0) {
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto c_p7 = p0;
                    (crate::prelude::call_then(crate::emit::rust::start_type_f(prism_rtl::deref(c_p7).ty_p), [=](Text type_f_13008) { return prism_rtl::finished(crate::emit::rust::templates::items::answer_getter_f(prism_rtl::deref(c_p7).accessor_p, prism_rtl::deref(c_p7).variant_p, prism_rtl::deref(c_p7).tag_name_p, type_f_13008)); }));
                });
            }));
        }))), [=, cases_p1 = std::move(cases_p1), tags_p2 = std::move(tags_p2)](Array<Text> each_12941) {
            return ({
                auto accessors_p3 = crate::syntax::lexer::chars::join_f(each_12941, Text::lit("\n"));
                auto decodes_p4 = crate::prelude::len(prism_rtl::deref(a_p0x).cases_p) == Nat(0u)
                    ? Text::lit("_ => unreachable!(),")
                    : crate::syntax::lexer::chars::join_f(crate::prelude::run_to_end(crate::prelude::each_job(prism_rtl::deref(a_p0x).cases_p, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::AnswerCase)>>(prism_rtl::rc([=](crate::lower::model::AnswerCase p0) {
                    return crate::prelude::entered(crate::prelude::once_job([=]() {
                        return ({
                            auto c_p8 = p0;
                            (crate::prelude::call_then(crate::emit::rust::start_decode_head_f(prism_rtl::deref(c_p8).ty_p), [=](Text decode_head_f_13171) { return prism_rtl::finished(prism_rtl::cat("Elem::", prism_rtl::deref(c_p8).variant_p, "(..) => Ok(Answer::", prism_rtl::deref(c_p8).variant_p, "(", decode_head_f_13171, "::from_pod(v)?)),")); }));
                        });
                    }));
                })))), Text::lit("\n"));
                (prism_rtl::finished(crate::emit::rust::templates::items::answer_type_f(cases_p1, tags_p2, accessors_p3, decodes_p4)));
            });
        }));
        });
    });
}


/// `Start RustAnswer, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_rust_answer_f(crate::lower::model::AnswerDef a_p0) {
    return prism_rtl::make_rc<RustAnswer>(a_p0);
}


/// RustNode: unbounded fn NodeDef -> Text
Text rust_node_f(const crate::lower::model::NodeDef& n_p0) {
    auto fields_p1 = crate::syntax::lexer::chars::join_f(crate::prelude::run_to_end(crate::prelude::each_job(n_p0.fields_p, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy, Text>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy, Text> p0) {
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto [f_pf, t_pg, doc_ph] = p0;
                (crate::prelude::call_then(crate::emit::rust::start_type_f(t_pg), [=](Text type_f_13588) { return prism_rtl::finished(prism_rtl::cat(crate::emit::rust::templates::doc_f(doc_ph), f_pf, ": ", type_f_13588, ",")); }));
            });
        }));
    })))), Text::lit("\n"));
    auto consts_p2 = crate::prelude::concat(crate::prelude::each(n_p0.consts_p, [&](const std::tuple<Text, Nat, Text>& _p0) {
        auto&& c_pi = std::get<0>(_p0);
        auto&& h_pj = std::get<1>(_p0);
        auto&& doc_pk = std::get<2>(_p0);
        return prism_rtl::cat(crate::emit::rust::templates::doc_f(prism_rtl::cat("The ", doc_pk, ".")), "const ", c_pi, ": u32 = ", h_pj, ";\n");
    }));
    auto params_p3 = crate::prelude::concat(crate::prelude::run_to_end(crate::prelude::each_job(n_p0.params_p, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto [p_pl, t_pm] = p0;
                (crate::prelude::call_then(crate::emit::rust::start_type_f(t_pm), [=](Text type_f_13766) { return prism_rtl::finished(prism_rtl::cat(p_pl, ": ", type_f_13766, ", ")); }));
            });
        }));
    })))));
    auto ret_p4 = n_p0.fallible_p
        ? prism_rtl::cat("Result<Rc<", n_p0.name_p, ">, Fault>")
        : prism_rtl::cat("Rc<", n_p0.name_p, ">");
    auto inits_p5 = crate::syntax::lexer::chars::join_f(crate::prelude::append(Array(std::vector{Text::lit("path")}), crate::prelude::run_to_end(crate::prelude::each_job(n_p0.inits_p, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::Ex>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::Ex> p0) {
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto [f_pn, v_po] = p0;
                (prism_rtl::more(prism_rtl::rc(crate::emit::rust::FieldInit(f_pn, v_po))));
            });
        }));
    }))))), Text::lit(", "));
    auto tail_p6 = n_p0.fallible_p ? Text::lit("Ok(node)") : Text::lit("node");
    auto rest_text_p7 = crate::prelude::len(n_p0.build_p) == Nat(0u)
        ? tail_p6
        : prism_rtl::cat(crate::emit::rust::statements_f(n_p0.build_p), "\n", tail_p6);
    auto build_p8 = crate::emit::rust::templates::items::build_f(n_p0.name_p, params_p3, ret_p4, crate::emit::rust::statements_f(n_p0.lets_p), inits_p5, rest_text_p7);
    auto methods_p9 = crate::syntax::lexer::chars::join_f(crate::prelude::run_to_end(crate::prelude::each_job(n_p0.methods_p, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::MethDef)>>(prism_rtl::rc([=](crate::lower::model::MethDef p0) {
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto m_pp = p0;
                (prism_rtl::more(prism_rtl::rc(RustMethod(m_pp))));
            });
        }));
    })))), Text::lit("\n"));
    auto answer_pa = crate::prelude::len(n_p0.answers_p) == Nat(0u)
        ? Text::lit("")
        : crate::emit::rust::templates::items::answer_f(crate::syntax::lexer::chars::join_f(crate::prelude::run_to_end(crate::prelude::each_job(n_p0.answers_p, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<crate::lower::model::Pa, crate::lower::model::Ex>)>>(prism_rtl::rc([=](std::tuple<crate::lower::model::Pa, crate::lower::model::Ex> p0) {
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto [pat_pq, call_pr] = p0;
                (crate::prelude::call_then(crate::emit::rust::start_pattern_f(pat_pq), [=](Text pattern_f_14332) { return crate::prelude::call_then(crate::emit::rust::start_expression_f(call_pr), [=](Text expression_f_14349) { return prism_rtl::finished(prism_rtl::cat(pattern_f_14332, " => ", expression_f_14349, ",")); }); }));
            });
        }));
    })))), Text::lit("\n")));
    auto builders_pb = crate::prelude::concat(crate::prelude::append(crate::prelude::run_to_end(crate::prelude::each_job(n_p0.builders_p, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::ForDef)>>(prism_rtl::rc([=](crate::lower::model::ForDef p0) {
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto b_ps = p0;
                (crate::prelude::call_then(start_for_builder_f(b_ps), [=](Text for_builder_f_14437) { return prism_rtl::finished(prism_rtl::cat("\n", for_builder_f_14437)); }));
            });
        }));
    })))), crate::prelude::run_to_end(crate::prelude::each_job(n_p0.gens_p, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::GenDef)>>(prism_rtl::rc([=](crate::lower::model::GenDef p0) {
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto gd_pt = p0;
                (crate::prelude::call_then(start_gen_builder_f(gd_pt), [=](Text gen_builder_f_14478) { return prism_rtl::finished(prism_rtl::cat("\n", gen_builder_f_14478)); }));
            });
        }));
    }))))));
    auto row_impl_pc = n_p0.row_kind_p == crate::lower::model::RowKind(crate::lower::model::RowKind::NotARow{})
        ? Text::lit("")
        : prism_rtl::cat("\n", rust_row_impl_f(n_p0));
    auto hooks_pd = crate::syntax::lexer::chars::join_f(crate::prelude::run_to_end(crate::prelude::each_job(n_p0.hooks_p, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Array<crate::lower::model::Do>>)>>(prism_rtl::rc([=](std::tuple<Text, Array<crate::lower::model::Do>> p0) {
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto [h_pu, body_pv] = p0;
                h_pu == Text::lit("push")
                ? crate::prelude::call_then(crate::emit::rust::start_statements_f(body_pv), [=](Text statements_f_14645) { return prism_rtl::finished(crate::emit::rust::templates::items::push_hook_f(statements_f_14645)); })
                : crate::prelude::call_then(crate::emit::rust::start_statements_f(body_pv), [=](Text statements_f_14677) { return prism_rtl::finished(crate::emit::rust::templates::items::hook_f(h_pu, statements_f_14677)); });
            });
        }));
    })))), Text::lit("\n"));
    auto doc_pe = crate::emit::rust::templates::source_doc_f(prism_rtl::cat("`", n_p0.prism_p, "`: a node of its own (claude/backend.md, \"A widget block\")."), n_p0.doc_p);
    return prism_rtl::cat(crate::emit::rust::templates::items::node_f(doc_pe, n_p0.name_p, fields_p1, consts_p2, build_p8, prism_rtl::cat(methods_p9, builders_pb), hooks_pd, answer_pa), row_impl_pc);
}


prism_rtl::Turn<Text> RustNode::cycle() const {
    const auto& n_p0 = this->n_p0;
    auto n_p0x = n_p0;
    return crate::prelude::call_value(crate::prelude::each_job(prism_rtl::deref(n_p0x).fields_p, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy, Text>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy, Text> p0) {
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto [f_pf, t_pg, doc_ph] = p0;
                (crate::prelude::call_then(crate::emit::rust::start_type_f(t_pg), [=](Text type_f_13588) { return prism_rtl::finished(prism_rtl::cat(crate::emit::rust::templates::doc_f(doc_ph), f_pf, ": ", type_f_13588, ",")); }));
            });
        }));
    }))), [=](Array<Text> each_13540) {
        return ({
            auto fields_p1 = crate::syntax::lexer::chars::join_f(each_13540, Text::lit("\n"));
            auto consts_p2 = crate::prelude::concat(crate::prelude::each(prism_rtl::deref(n_p0x).consts_p, [&](const std::tuple<Text, Nat, Text>& _p0) {
                auto&& c_pi = std::get<0>(_p0);
                auto&& h_pj = std::get<1>(_p0);
                auto&& doc_pk = std::get<2>(_p0);
                return prism_rtl::cat(crate::emit::rust::templates::doc_f(prism_rtl::cat("The ", doc_pk, ".")), "const ", c_pi, ": u32 = ", h_pj, ";\n");
            }));
            (crate::prelude::call_value(crate::prelude::each_job(prism_rtl::deref(n_p0x).params_p, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto [p_pl, t_pm] = p0;
                    (crate::prelude::call_then(crate::emit::rust::start_type_f(t_pm), [=](Text type_f_13766) { return prism_rtl::finished(prism_rtl::cat(p_pl, ": ", type_f_13766, ", ")); }));
                });
            }));
        }))), [=, fields_p1 = std::move(fields_p1), consts_p2 = std::move(consts_p2)](Array<Text> each_13732) {
            return ({
                auto params_p3 = crate::prelude::concat(each_13732);
                auto ret_p4 = prism_rtl::deref(n_p0x).fallible_p
                    ? prism_rtl::cat("Result<Rc<", prism_rtl::deref(n_p0x).name_p, ">, Fault>")
                    : prism_rtl::cat("Rc<", prism_rtl::deref(n_p0x).name_p, ">");
                (crate::prelude::call_value(crate::prelude::each_job(prism_rtl::deref(n_p0x).inits_p, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::Ex>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::Ex> p0) {
                return crate::prelude::entered(crate::prelude::once_job([=]() {
                    return ({
                        auto [f_pn, v_po] = p0;
                        (prism_rtl::more(prism_rtl::rc(crate::emit::rust::FieldInit(f_pn, v_po))));
                    });
                }));
            }))), [=, params_p3 = std::move(params_p3), ret_p4 = std::move(ret_p4)](Array<Text> each_13900) {
                return ({
                    auto inits_p5 = crate::syntax::lexer::chars::join_f(crate::prelude::append(Array(std::vector{Text::lit("path")}), each_13900), Text::lit(", "));
                    auto tail_p6 = prism_rtl::deref(n_p0x).fallible_p
                        ? Text::lit("Ok(node)")
                        : Text::lit("node");
                    auto rest_text_p7 = crate::prelude::len(prism_rtl::deref(n_p0x).build_p) == Nat(0u)
                        ? tail_p6
                        : prism_rtl::cat(crate::emit::rust::statements_f(prism_rtl::deref(n_p0x).build_p), "\n", tail_p6);
                    (crate::prelude::call_then(crate::emit::rust::start_statements_f(prism_rtl::deref(n_p0x).lets_p), [=, inits_p5 = std::move(inits_p5), rest_text_p7 = std::move(rest_text_p7)](Text statements_f_14131) {
                    return ({
                        auto build_p8 = crate::emit::rust::templates::items::build_f(prism_rtl::deref(n_p0x).name_p, params_p3, ret_p4, statements_f_14131, inits_p5, rest_text_p7);
                        (crate::prelude::call_value(crate::prelude::each_job(prism_rtl::deref(n_p0x).methods_p, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::MethDef)>>(prism_rtl::rc([=](crate::lower::model::MethDef p0) {
                        return crate::prelude::entered(crate::prelude::once_job([=]() {
                            return ({
                                auto m_pp = p0;
                                (prism_rtl::more(prism_rtl::rc(RustMethod(m_pp))));
                            });
                        }));
                    }))), [=, build_p8 = std::move(build_p8)](Array<Text> each_14191) {
                        return ({
                            auto methods_p9 = crate::syntax::lexer::chars::join_f(each_14191, Text::lit("\n"));
                            auto answer_pa = crate::prelude::len(prism_rtl::deref(n_p0x).answers_p) == Nat(0u)
                                ? Text::lit("")
                                : crate::emit::rust::templates::items::answer_f(crate::syntax::lexer::chars::join_f(crate::prelude::run_to_end(crate::prelude::each_job(prism_rtl::deref(n_p0x).answers_p, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<crate::lower::model::Pa, crate::lower::model::Ex>)>>(prism_rtl::rc([=](std::tuple<crate::lower::model::Pa, crate::lower::model::Ex> p0) {
                                return crate::prelude::entered(crate::prelude::once_job([=]() {
                                    return ({
                                        auto [pat_pq, call_pr] = p0;
                                        (crate::prelude::call_then(crate::emit::rust::start_pattern_f(pat_pq), [=](Text pattern_f_14332) { return crate::prelude::call_then(crate::emit::rust::start_expression_f(call_pr), [=](Text expression_f_14349) { return prism_rtl::finished(prism_rtl::cat(pattern_f_14332, " => ", expression_f_14349, ",")); }); }));
                                    });
                                }));
                            })))), Text::lit("\n")));
                            (crate::prelude::call_value(crate::prelude::each_job(prism_rtl::deref(n_p0x).builders_p, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::ForDef)>>(prism_rtl::rc([=](crate::lower::model::ForDef p0) {
                            return crate::prelude::entered(crate::prelude::once_job([=]() {
                                return ({
                                    auto b_ps = p0;
                                    (crate::prelude::call_then(start_for_builder_f(b_ps), [=](Text for_builder_f_14437) { return prism_rtl::finished(prism_rtl::cat("\n", for_builder_f_14437)); }));
                                });
                            }));
                        }))), [=, methods_p9 = std::move(methods_p9), answer_pa = std::move(answer_pa)](Array<Text> each_14411) {
                            return crate::prelude::call_value(crate::prelude::each_job(prism_rtl::deref(n_p0x).gens_p, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::GenDef)>>(prism_rtl::rc([=](crate::lower::model::GenDef p0) {
                                return crate::prelude::entered(crate::prelude::once_job([=]() {
                                    return ({
                                        auto gd_pt = p0;
                                        (crate::prelude::call_then(start_gen_builder_f(gd_pt), [=](Text gen_builder_f_14478) { return prism_rtl::finished(prism_rtl::cat("\n", gen_builder_f_14478)); }));
                                    });
                                }));
                            }))), [=](Array<Text> each_14455) {
                                return ({
                                    auto builders_pb = crate::prelude::concat(crate::prelude::append(each_14411, each_14455));
                                    auto row_impl_pc = prism_rtl::deref(n_p0x).row_kind_p == crate::lower::model::RowKind(crate::lower::model::RowKind::NotARow{})
                                        ? Text::lit("")
                                        : prism_rtl::cat("\n", rust_row_impl_f(n_p0x));
                                    (crate::prelude::call_value(crate::prelude::each_job(prism_rtl::deref(n_p0x).hooks_p, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Array<crate::lower::model::Do>>)>>(prism_rtl::rc([=](std::tuple<Text, Array<crate::lower::model::Do>> p0) {
                                    return crate::prelude::entered(crate::prelude::once_job([=]() {
                                        return ({
                                            auto [h_pu, body_pv] = p0;
                                            h_pu == Text::lit("push")
                                            ? crate::prelude::call_then(crate::emit::rust::start_statements_f(body_pv), [=](Text statements_f_14645) { return prism_rtl::finished(crate::emit::rust::templates::items::push_hook_f(statements_f_14645)); })
                                            : crate::prelude::call_then(crate::emit::rust::start_statements_f(body_pv), [=](Text statements_f_14677) { return prism_rtl::finished(crate::emit::rust::templates::items::hook_f(h_pu, statements_f_14677)); });
                                        });
                                    }));
                                }))), [=, builders_pb = std::move(builders_pb), row_impl_pc = std::move(row_impl_pc)](Array<Text> each_14590) {
                                    return ({
                                        auto hooks_pd = crate::syntax::lexer::chars::join_f(each_14590, Text::lit("\n"));
                                        auto doc_pe = crate::emit::rust::templates::source_doc_f(prism_rtl::cat("`", prism_rtl::deref(n_p0x).prism_p, "`: a node of its own (claude/backend.md, \"A widget block\")."), prism_rtl::deref(n_p0x).doc_p);
                                        (prism_rtl::finished(prism_rtl::cat(crate::emit::rust::templates::items::node_f(doc_pe, prism_rtl::deref(n_p0x).name_p, fields_p1, consts_p2, build_p8, prism_rtl::cat(methods_p9, builders_pb), hooks_pd, answer_pa), row_impl_pc)));
                                    });
                                }));
                                });
                            });
                        }));
                        });
                    }));
                    });
                }));
                });
            }));
            });
        }));
        });
    });
}


/// `Start RustNode, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_rust_node_f(crate::lower::model::NodeDef n_p0) {
    return prism_rtl::make_rc<RustNode>(n_p0);
}


/// ForBuilder: unbounded fn ForDef -> Text
Text for_builder_f(const crate::lower::model::ForDef& b_p0) {
    return crate::emit::rust::templates::items::for_build_f(b_p0.name_p, crate::emit::rust::expression_f(b_p0.at_p), crate::emit::rust::type_f(b_p0.key_ty_p), crate::emit::rust::type_f(b_p0.value_ty_p), b_p0.row_node_p, b_p0.source_p, crate::emit::rust::expression_f(b_p0.parent_p), crate::prelude::concat(crate::prelude::run_to_end(crate::prelude::each_job(b_p0.passed_p, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Ex)>>(prism_rtl::rc([=](crate::lower::model::Ex p0) {
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto x_p1 = p0;
                (crate::prelude::call_then(crate::emit::rust::start_expression_f(x_p1), [=](Text expression_f_15170) { return prism_rtl::finished(prism_rtl::cat(", ", expression_f_15170)); }));
            });
        }));
    }))))), moved_call_f(b_p0.name_p, b_p0.moved_p), from_kept_f(b_p0.name_p, b_p0.replaced_p), replaced_call_f(b_p0.replaced_p));
}


prism_rtl::Turn<Text> ForBuilder::cycle() const {
    const auto& b_p0 = this->b_p0;
    auto b_p0x = b_p0;
    return crate::prelude::call_then(crate::emit::rust::start_expression_f(prism_rtl::deref(b_p0x).at_p), [=](Text expression_f_15041) {
        return crate::prelude::call_then(crate::emit::rust::start_type_f(prism_rtl::deref(b_p0x).key_ty_p), [=](Text type_f_15060) {
            return crate::prelude::call_then(crate::emit::rust::start_type_f(prism_rtl::deref(b_p0x).value_ty_p), [=](Text type_f_15076) {
                return crate::prelude::call_then(crate::emit::rust::start_expression_f(prism_rtl::deref(b_p0x).parent_p), [=](Text expression_f_15115) {
                    return crate::prelude::call_value(crate::prelude::each_job(prism_rtl::deref(b_p0x).passed_p, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Ex)>>(prism_rtl::rc([=](crate::lower::model::Ex p0) {
                        return crate::prelude::entered(crate::prelude::once_job([=]() {
                            return ({
                                auto x_p1 = p0;
                                (crate::prelude::call_then(crate::emit::rust::start_expression_f(x_p1), [=](Text expression_f_15170) { return prism_rtl::finished(prism_rtl::cat(", ", expression_f_15170)); }));
                            });
                        }));
                    }))), [=](Array<Text> each_15146) { return prism_rtl::finished(crate::emit::rust::templates::items::for_build_f(prism_rtl::deref(b_p0x).name_p, expression_f_15041, type_f_15060, type_f_15076, prism_rtl::deref(b_p0x).row_node_p, prism_rtl::deref(b_p0x).source_p, expression_f_15115, crate::prelude::concat(each_15146), moved_call_f(prism_rtl::deref(b_p0x).name_p, prism_rtl::deref(b_p0x).moved_p), from_kept_f(prism_rtl::deref(b_p0x).name_p, prism_rtl::deref(b_p0x).replaced_p), replaced_call_f(prism_rtl::deref(b_p0x).replaced_p))); });
                });
            });
        });
    });
}


/// `Start ForBuilder, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_for_builder_f(crate::lower::model::ForDef b_p0) {
    return prism_rtl::make_rc<ForBuilder>(b_p0);
}


/// FromKept: fn Text, [Text] -> Text
Text from_kept_f(const Text& name_p0, const Array<Text>& replaced_p1) {
    return crate::prelude::len(replaced_p1) == Nat(0u)
        ? prism_rtl::cat("*self.", name_p0, "_from.borrow_mut() = items.clone();")
        : prism_rtl::cat("let from = std::mem::replace(&mut *self.", name_p0, "_from.borrow_mut(), items.clone());");
}


/// ReplacedCall: fn [Text] -> Text
Text replaced_call_f(const Array<Text>& replaced_p0) {
    return crate::prelude::len(replaced_p0) == Nat(0u)
        ? Text::lit("")
        : prism_rtl::cat(" else if from.get(k) != items.get(k) {\n            // the dynamic under a kept key was replaced: that row follows it from the next tick\n", crate::prelude::concat(crate::prelude::each(replaced_p0, [&](const Text& m_p1) { return prism_rtl::cat("            row.", m_p1, "(cx);\n"); })), "        }");
}


/// MovedCall: fn Text, Text -> Text
Text moved_call_f(const Text& name_p0, const Text& m_p1) {
    return m_p1 == Text::lit("")
        ? Text::lit("")
        : prism_rtl::cat("\n    // the places of the host\'s child came or went: its document\'s outer moves\n    if !prism_rtl::same_keys(&self.", name_p0, ".borrow(), &old) {\n        self.", m_p1, "(cx);\n    }");
}


/// GenMovedCall: fn Text -> Text
Text gen_moved_call_f(const Text& m_p0) {
    return m_p0 == Text::lit("")
        ? Text::lit("")
        : prism_rtl::cat("\n    // the places of the host\'s child came or went: its document\'s outer moves\n    self.", m_p0, "(cx);");
}


/// GenBuilder: unbounded fn GenDef -> Text
Text gen_builder_f(const crate::lower::model::GenDef& gd_p0) {
    auto path_p1 = gd_p0.transparent_p
        ? Text::lit("self.path.clone()")
        : prism_rtl::cat(crate::emit::rust::expression_f(gd_p0.at_p), ".child(Segment::Gen(g))");
    return crate::emit::rust::templates::items::gen_build_f(gd_p0.name_p, crate::emit::rust::expression_f(gd_p0.at_p), path_p1, crate::emit::rust::expression_f(gd_p0.source_p), crate::emit::rust::type_f(gd_p0.value_ty_p), crate::emit::rust::expression_f(gd_p0.select_p), gen_moved_call_f(gd_p0.moved_p));
}


prism_rtl::Turn<Text> GenBuilder::cycle() const {
    const auto& gd_p0 = this->gd_p0;
    auto path_p1 = prism_rtl::deref(gd_p0).transparent_p
        ? Text::lit("self.path.clone()")
        : prism_rtl::cat(crate::emit::rust::expression_f(prism_rtl::deref(gd_p0).at_p), ".child(Segment::Gen(g))");
    auto gd_p0x = gd_p0;
    return crate::prelude::call_then(crate::emit::rust::start_expression_f(prism_rtl::deref(gd_p0x).at_p), [=](Text expression_f_17157) { return crate::prelude::call_then(crate::emit::rust::start_expression_f(prism_rtl::deref(gd_p0x).source_p), [=](Text expression_f_17183) { return crate::prelude::call_then(crate::emit::rust::start_type_f(prism_rtl::deref(gd_p0x).value_ty_p), [=](Text type_f_17207) { return crate::prelude::call_then(crate::emit::rust::start_expression_f(prism_rtl::deref(gd_p0x).select_p), [=](Text expression_f_17226) { return prism_rtl::finished(crate::emit::rust::templates::items::gen_build_f(prism_rtl::deref(gd_p0x).name_p, expression_f_17157, path_p1, expression_f_17183, type_f_17207, expression_f_17226, gen_moved_call_f(prism_rtl::deref(gd_p0x).moved_p))); }); }); }); });
}


/// `Start GenBuilder, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_gen_builder_f(crate::lower::model::GenDef gd_p0) {
    return prism_rtl::make_rc<GenBuilder>(gd_p0);
}


/// RustRowImpl: unbounded fn NodeDef -> Text
Text rust_row_impl_f(const crate::lower::model::NodeDef& n_p0) {
    auto kept_p1 = n_p0.row_kind_p == crate::lower::model::RowKind(crate::lower::model::RowKind::ForRow{})
        ? Array(std::vector{Text::lit("*self.left_entry.borrow_mut() = Some(self.entry(cx));")})
        : Array<Text>{};
    auto unsubscribe_p2 = crate::prelude::each(n_p0.subs_p, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
        auto&& ev_p3 = std::get<0>(_p0);
        auto&& m_p4 = std::get<1>(_p0);
        return prism_rtl::cat("if let (Some(p), Some(h)) = (self.parent.upgrade(), self.", m_p4, "_sub.take()) {\n    p.", ev_p3, "_port.unsubscribe(h);\n}");
    });
    return crate::emit::rust::templates::items::row_impl_f(n_p0.name_p, crate::syntax::lexer::chars::join_f(crate::prelude::append(crate::prelude::push(kept_p1, Text::lit("self.remove_places(cx);")), unsubscribe_p2), Text::lit("\n")), crate::syntax::lexer::chars::join_f(crate::prelude::run_to_end(crate::prelude::each_job(n_p0.hosted_p, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::MethDef)>>(prism_rtl::rc([=](crate::lower::model::MethDef p0) {
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto m_p5 = p0;
                (prism_rtl::more(prism_rtl::rc(RustMethod(m_p5))));
            });
        }));
    })))), Text::lit("\n")));
}


prism_rtl::Turn<Text> RustRowImpl::cycle() const {
    const auto& n_p0 = this->n_p0;
    auto kept_p1 = prism_rtl::deref(n_p0).row_kind_p == crate::lower::model::RowKind(crate::lower::model::RowKind::ForRow{})
        ? Array(std::vector{Text::lit("*self.left_entry.borrow_mut() = Some(self.entry(cx));")})
        : Array<Text>{};
    auto unsubscribe_p2 = crate::prelude::each(prism_rtl::deref(n_p0).subs_p, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
        auto&& ev_p3 = std::get<0>(_p0);
        auto&& m_p4 = std::get<1>(_p0);
        return prism_rtl::cat("if let (Some(p), Some(h)) = (self.parent.upgrade(), self.", m_p4, "_sub.take()) {\n    p.", ev_p3, "_port.unsubscribe(h);\n}");
    });
    auto n_p0x = n_p0;
    return crate::prelude::call_value(crate::prelude::each_job(prism_rtl::deref(n_p0x).hosted_p, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::MethDef)>>(prism_rtl::rc([=](crate::lower::model::MethDef p0) {
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto m_p5 = p0;
                (prism_rtl::more(prism_rtl::rc(RustMethod(m_p5))));
            });
        }));
    }))), [=](Array<Text> each_17949) { return prism_rtl::finished(crate::emit::rust::templates::items::row_impl_f(prism_rtl::deref(n_p0x).name_p, crate::syntax::lexer::chars::join_f(crate::prelude::append(crate::prelude::push(kept_p1, Text::lit("self.remove_places(cx);")), unsubscribe_p2), Text::lit("\n")), crate::syntax::lexer::chars::join_f(each_17949, Text::lit("\n")))); });
}


/// `Start RustRowImpl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_rust_row_impl_f(crate::lower::model::NodeDef n_p0) {
    return prism_rtl::make_rc<RustRowImpl>(n_p0);
}


/// RustMethod: unbounded fn MethDef -> Text
Text rust_method_f(const crate::lower::model::MethDef& m_p0) {
    auto recv_p1 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = m_p0.recv_p;
        if (prism_rtl::is<crate::lower::model::Recv::RecvRc>(_m)) {
            _v.set(Text::lit("self: &Rc<Self>"));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::Recv::RecvRef>(_m)) {
            _v.set(Text::lit("&self"));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::Recv::RecvOwned>(_m)) {
            _v.set(Text::lit("self: Rc<Self>"));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto cx_p2 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = m_p0.cx_p;
        if (prism_rtl::is<crate::lower::model::CxArg::CxMut>(_m)) {
            _v.set(Text::lit(", cx: &mut Cx"));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::CxArg::CxRef>(_m)) {
            _v.set(Text::lit(", cx: &Cx"));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::CxArg::CxNone>(_m)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto params_p3 = crate::prelude::concat(crate::prelude::run_to_end(crate::prelude::each_job(m_p0.params_p, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto [p_p7, t_p8] = p0;
                (crate::prelude::call_then(crate::emit::rust::start_type_f(t_p8), [=](Text type_f_18336) { return prism_rtl::finished(prism_rtl::cat(", ", p_p7, ": ", type_f_18336)); }));
            });
        }));
    })))));
    auto ret_p4 = m_p0.ret_p == crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})
        ? Text::lit("")
        : prism_rtl::cat(" -> ", crate::emit::rust::type_f(m_p0.ret_p));
    auto sig_p5 = prism_rtl::cat("fn ", m_p0.name_p, "(", recv_p1, params_p3, cx_p2, ")", ret_p4);
    auto body_p6 = m_p0.ret_p == crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})
        ? crate::emit::rust::statements_f(m_p0.body_p)
        : crate::prelude::len(m_p0.body_p) == Nat(0u)
        ? crate::emit::rust::body_lines_f(m_p0.tail_p)
        : prism_rtl::cat(crate::emit::rust::statements_f(m_p0.body_p), "\n", crate::emit::rust::body_lines_f(m_p0.tail_p));
    return crate::emit::rust::templates::items::method_f(crate::emit::rust::templates::doc_f(m_p0.doc_p), sig_p5, body_p6);
}


prism_rtl::Turn<Text> RustMethod::cycle() const {
    const auto& m_p0 = this->m_p0;
    auto recv_p1 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = prism_rtl::deref(m_p0).recv_p;
        if (prism_rtl::is<crate::lower::model::Recv::RecvRc>(_m)) {
            _v.set(Text::lit("self: &Rc<Self>"));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::Recv::RecvRef>(_m)) {
            _v.set(Text::lit("&self"));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::Recv::RecvOwned>(_m)) {
            _v.set(Text::lit("self: Rc<Self>"));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto cx_p2 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = prism_rtl::deref(m_p0).cx_p;
        if (prism_rtl::is<crate::lower::model::CxArg::CxMut>(_m)) {
            _v.set(Text::lit(", cx: &mut Cx"));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::CxArg::CxRef>(_m)) {
            _v.set(Text::lit(", cx: &Cx"));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::CxArg::CxNone>(_m)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto m_p0x = m_p0;
    return crate::prelude::call_value(crate::prelude::each_job(prism_rtl::deref(m_p0x).params_p, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto [p_p7, t_p8] = p0;
                (crate::prelude::call_then(crate::emit::rust::start_type_f(t_p8), [=](Text type_f_18336) { return prism_rtl::finished(prism_rtl::cat(", ", p_p7, ": ", type_f_18336)); }));
            });
        }));
    }))), [=](Array<Text> each_18300) {
        return ({
            auto params_p3 = crate::prelude::concat(each_18300);
            auto ret_p4 = prism_rtl::deref(m_p0x).ret_p == crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})
                ? Text::lit("")
                : prism_rtl::cat(" -> ", crate::emit::rust::type_f(prism_rtl::deref(m_p0x).ret_p));
            auto sig_p5 = prism_rtl::cat("fn ", prism_rtl::deref(m_p0x).name_p, "(", recv_p1, params_p3, cx_p2, ")", ret_p4);
            auto body_p6 = prism_rtl::deref(m_p0x).ret_p == crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})
                ? crate::emit::rust::statements_f(prism_rtl::deref(m_p0x).body_p)
                : crate::prelude::len(prism_rtl::deref(m_p0x).body_p) == Nat(0u)
                ? crate::emit::rust::body_lines_f(prism_rtl::deref(m_p0x).tail_p)
                : prism_rtl::cat(crate::emit::rust::statements_f(prism_rtl::deref(m_p0x).body_p), "\n", crate::emit::rust::body_lines_f(prism_rtl::deref(m_p0x).tail_p));
            (prism_rtl::finished(crate::emit::rust::templates::items::method_f(crate::emit::rust::templates::doc_f(prism_rtl::deref(m_p0x).doc_p), sig_p5, body_p6)));
        });
    });
}


/// `Start RustMethod, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_rust_method_f(crate::lower::model::MethDef m_p0) {
    return prism_rtl::make_rc<RustMethod>(m_p0);
}


/// RustProgram: unbounded fn ProgDef, Bool -> Text
Text rust_program_f(const crate::lower::model::ProgDef& p_p0, const bool& fallible_p1) {
    auto n_p2 = crate::prelude::len(p_p0.params_p);
    auto names_p3 = crate::prelude::each(p_p0.params_p, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
        auto&& a_p6 = std::get<0>(_p0);
        return a_p6;
    });
    auto decode_p4 = n_p2 == Nat(0u)
        ? Text::lit("let _ = args;")
        : decode_args_f(p_p0, names_p3);
    auto call_p5 = prism_rtl::cat(p_p0.node_p, "::build(Path::root(), ", crate::prelude::concat(crate::prelude::each(names_p3, [&](const Text& a_p7) { return prism_rtl::cat(a_p7, ", "); })), "&mut cx)", fallible_p1 ? Text::lit("?") : Text::lit(""));
    return crate::emit::rust::templates::items::program_f(p_p0.name_p, p_p0.prism_p, p_p0.node_p, decode_p4, call_p5);
}


prism_rtl::Turn<Text> RustProgram::cycle() const {
    const auto& p_p0 = this->p_p0;
    const auto& fallible_p1 = this->fallible_p1;
    auto n_p2 = crate::prelude::len(prism_rtl::deref(p_p0).params_p);
    auto names_p3 = crate::prelude::each(prism_rtl::deref(p_p0).params_p, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
        auto&& a_p6 = std::get<0>(_p0);
        return a_p6;
    });
    auto decode_p4 = n_p2 == Nat(0u)
        ? Text::lit("let _ = args;")
        : decode_args_f(p_p0, names_p3);
    auto call_p5 = prism_rtl::cat(prism_rtl::deref(p_p0).node_p, "::build(Path::root(), ", crate::prelude::concat(crate::prelude::each(names_p3, [&](const Text& a_p7) { return prism_rtl::cat(a_p7, ", "); })), "&mut cx)", prism_rtl::deref(fallible_p1) ? Text::lit("?") : Text::lit(""));
    return prism_rtl::finished(crate::emit::rust::templates::items::program_f(prism_rtl::deref(p_p0).name_p, prism_rtl::deref(p_p0).prism_p, prism_rtl::deref(p_p0).node_p, decode_p4, call_p5));
}


/// `Start RustProgram, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_rust_program_f(crate::lower::model::ProgDef p_p0, bool fallible_p1) {
    return prism_rtl::make_rc<RustProgram>(p_p0, fallible_p1);
}


/// DecodeArgs: unbounded fn ProgDef, [Text] -> Text
Text decode_args_f(const crate::lower::model::ProgDef& p_p0, const Array<Text>& names_p1) {
    auto n_p2 = crate::prelude::len(names_p1);
    auto plural_p3 = n_p2 == Nat(1u) ? Text::lit("") : Text::lit("s");
    auto head_p4 = prism_rtl::cat("let [", crate::syntax::lexer::chars::join_f(names_p1, Text::lit(", ")), "] = args else { return Err(Fault::answer(\"@", p_p0.prism_p, " takes ", n_p2, " argument", plural_p3, "\")) };");
    return crate::syntax::lexer::chars::join_f(crate::prelude::append(Array(std::vector{head_p4}), crate::prelude::run_to_end(crate::prelude::each_job(p_p0.params_p, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto [a_p5, t_p6] = p0;
                (crate::prelude::call_then(crate::emit::rust::start_decode_head_f(t_p6), [=](Text decode_head_f_19367) { return prism_rtl::finished(prism_rtl::cat("let ", a_p5, " = ", decode_head_f_19367, "::from_pod(", a_p5, ")?;")); }));
            });
        }));
    }))))), Text::lit("\n"));
}


prism_rtl::Turn<Text> DecodeArgs::cycle() const {
    const auto& p_p0 = this->p_p0;
    const auto& names_p1 = this->names_p1;
    auto n_p2 = crate::prelude::len(names_p1);
    auto plural_p3 = n_p2 == Nat(1u) ? Text::lit("") : Text::lit("s");
    auto head_p4 = prism_rtl::cat("let [", crate::syntax::lexer::chars::join_f(names_p1, Text::lit(", ")), "] = args else { return Err(Fault::answer(\"@", prism_rtl::deref(p_p0).prism_p, " takes ", n_p2, " argument", plural_p3, "\")) };");
    auto p_p0x = p_p0;
    return crate::prelude::call_value(crate::prelude::each_job(prism_rtl::deref(p_p0x).params_p, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto [a_p5, t_p6] = p0;
                (crate::prelude::call_then(crate::emit::rust::start_decode_head_f(t_p6), [=](Text decode_head_f_19367) { return prism_rtl::finished(prism_rtl::cat("let ", a_p5, " = ", decode_head_f_19367, "::from_pod(", a_p5, ")?;")); }));
            });
        }));
    }))), [=](Array<Text> each_19328) { return prism_rtl::finished(crate::syntax::lexer::chars::join_f(crate::prelude::append(Array(std::vector{head_p4}), each_19328), Text::lit("\n"))); });
}


/// `Start DecodeArgs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_decode_args_f(crate::lower::model::ProgDef p_p0, Array<Text> names_p1) {
    return prism_rtl::make_rc<DecodeArgs>(p_p0, names_p1);
}


/// RustModule: unbounded fn ModDef, Text -> Text
Text rust_module_f(const crate::lower::model::ModDef& m_p0, const Text& kids_p1) {
    return crate::emit::rust::templates::module_f(m_p0.prism_p == Text::lit("")
        ? Text::lit("The root module")
        : prism_rtl::cat("The module `", m_p0.prism_p, "`"), m_p0.path_p, kids_p1, crate::syntax::lexer::chars::join_f(crate::prelude::run_to_end(crate::prelude::each_job(m_p0.items_p, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Item)>>(prism_rtl::rc([=](crate::lower::model::Item p0) {
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto it_p2 = p0;
                (prism_rtl::more(prism_rtl::rc(RustItem(it_p2))));
            });
        }));
    })))), Text::lit("\n")));
}


prism_rtl::Turn<Text> RustModule::cycle() const {
    const auto& m_p0 = this->m_p0;
    const auto& kids_p1 = this->kids_p1;
    auto kids_p1x = kids_p1;
    auto m_p0x = m_p0;
    return crate::prelude::call_value(crate::prelude::each_job(prism_rtl::deref(m_p0x).items_p, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Item)>>(prism_rtl::rc([=](crate::lower::model::Item p0) {
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto it_p2 = p0;
                (prism_rtl::more(prism_rtl::rc(RustItem(it_p2))));
            });
        }));
    }))), [=](Array<Text> each_19940) {
        return prism_rtl::finished(crate::emit::rust::templates::module_f(prism_rtl::deref(m_p0x).prism_p == Text::lit("")
            ? Text::lit("The root module")
            : prism_rtl::cat("The module `", prism_rtl::deref(m_p0x).prism_p, "`"), prism_rtl::deref(m_p0x).path_p, kids_p1x, crate::syntax::lexer::chars::join_f(each_19940, Text::lit("\n"))));
    });
}


/// `Start RustModule, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_rust_module_f(crate::lower::model::ModDef m_p0, Text kids_p1) {
    return prism_rtl::make_rc<RustModule>(m_p0, kids_p1);
}


/// NodeFallible: fn Model, Text -> Bool
bool node_fallible_f(const crate::lower::model::Model& model_p0, const Text& path_p1) {
    return crate::prelude::fold(model_p0.mods_p, false, [&](const bool& f_p2, const crate::lower::model::ModDef& m_p3) {
        return crate::prelude::fold(prism_rtl::deref(m_p3).items_p, f_p2, [&](const bool& f2_p4, const crate::lower::model::Item& it_p5) {
            return ({
                __label__ _done;
                prism_rtl::Slot<bool> _v;
                if (prism_rtl::is<crate::lower::model::Item::ItNode>(it_p5)) {
                    auto&& n_p6 = prism_rtl::as<crate::lower::model::Item::ItNode>(it_p5).a0;
                    _v.set(prism_rtl::deref(f2_p4) || ((prism_rtl::cat(prism_rtl::deref(m_p3).name_p, "::", prism_rtl::deref(n_p6).name_p) == path_p1) && prism_rtl::deref(n_p6).fallible_p));
                    goto _done;
                }
                {
                    _v.set(prism_rtl::deref(f2_p4));
                    goto _done;
                }
            _done:
                _v.take();
            });
        });
    });
}


/// EmitCrate: unbounded fn Model, Text, [Text] -> [((Text, Text))]
Array<std::tuple<Text, Text>> emit_crate_f(const crate::lower::model::Model& model_p0, const Text& runtime_p1, const Array<Text>& scripts_p2) {
    auto gui_p3 = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = model_p0.root_o;
        if (prism_rtl::is_some(_m)) {
            auto&& r_ph = prism_rtl::some_of(_m);
            _v.set(prism_rtl::deref(r_ph).world_p == Text::lit("canvas"));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(false);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto cargo_p4 = crate::emit::rust::templates::cargo_f(model_p0.name_p, runtime_p1, std::move(gui_p3) ? Text::lit("\"canvas\"") : Text::lit(""));
    auto paths_p5 = rust_mod_paths_f(model_p0.mods_p);
    auto mods_p6 = crate::prelude::concat(crate::prelude::each(crate::prelude::filter(paths_p5, [&](const Text& p_pi) { return !crate::syntax::lexer::chars::contains_f(p_pi, Text::lit(":")); }), [&](const Text& p_pj) { return prism_rtl::cat("mod ", p_pj, ";\n"); }));
    auto programs_p7 = crate::syntax::lexer::chars::join_f(crate::prelude::run_to_end(crate::prelude::each_job(all_programs_f(model_p0), ({
        auto model_p0x = model_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::ProgDef)>>(prism_rtl::rc([=, model_p0x = std::move(model_p0x)](crate::lower::model::ProgDef p0) {
        return ({
            auto model_p0xy = model_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, model_p0xy = std::move(model_p0xy)]() {
            return ({
                auto p_pk = p0;
                (prism_rtl::more(prism_rtl::rc(RustProgram(p_pk, node_fallible_f(model_p0xy, prism_rtl::deref(p_pk).node_p)))));
            });
        })));
        });
    })));
    }))), Text::lit("\n"));
    auto regs_p8 = crate::prelude::concat(crate::prelude::each(model_p0.programs_p, [&](const crate::lower::model::ProgDef& p_pl) { return prism_rtl::cat(".program::<", prism_rtl::deref(p_pl).name_p, ">(\"", prism_rtl::deref(p_pl).prism_p, "\")\n"); }));
    auto checks_p9 = crate::prelude::concat(crate::prelude::run_to_end(crate::prelude::each_job(model_p0.checks_p, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::CheckDef)>>(prism_rtl::rc([=](crate::lower::model::CheckDef p0) {
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto c_pm = p0;
                (crate::prelude::call_value(crate::prelude::each_job(prism_rtl::deref(c_pm).lines_p, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Ex)>>(prism_rtl::rc([=](crate::lower::model::Ex p0) {
                return crate::prelude::entered(crate::prelude::once_job([=]() {
                    return ({
                        auto l_pn = p0;
                        (prism_rtl::more(prism_rtl::rc(crate::emit::rust::Expression(l_pn))));
                    });
                }));
            }))), [=](Array<Text> each_20969) { return prism_rtl::finished(prism_rtl::cat(".check(\"", prism_rtl::deref(c_pm).name_p, "\", || vec![", crate::syntax::lexer::chars::join_f(each_20969, Text::lit(", ")), "])\n")); }));
            });
        }));
    })))));
    auto script_list_pa = crate::prelude::concat(crate::prelude::each(scripts_p2, [&](const Text& s_po) { return prism_rtl::cat("\"", crate::lower::expr::escape_f(s_po), "\",\n"); }));
    auto run_root_pb = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = model_p0.root_o;
        if (prism_rtl::is_some(_m)) {
            auto&& r_pp = prism_rtl::some_of(_m);
            _v.set(crate::emit::rust::templates::run_root_f(prism_rtl::deref(r_pp).name_p));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(crate::emit::rust::templates::no_root_f(model_p0.name_p));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto world_pc = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = model_p0.root_o;
        if (prism_rtl::is_some(_m)) {
            auto&& r_pq = prism_rtl::some_of(_m);
            _v.set(prism_rtl::deref(r_pq).world_p);
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text::lit("test"));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto main_pd = crate::emit::rust::templates::main_f(model_p0.name_p, prism_rtl::cat("mod prelude;\n", mods_p6), prism_rtl::cat(rust_row_f(model_p0.elem_p), "\n", rust_answer_f(model_p0.answer_p), "\n", programs_p7), prism_rtl::cat(regs_p8, checks_p9), script_list_pa, run_root_pb, world_pc);
    auto files_pe = crate::prelude::run_to_end(crate::prelude::each_job(model_p0.mods_p, ({
        auto paths_p5x = paths_p5;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, Text>>(crate::lower::model::ModDef)>>(prism_rtl::rc([=, paths_p5x = std::move(paths_p5x)](crate::lower::model::ModDef p0) {
        return ({
            auto paths_p5xy = paths_p5x;
            (crate::prelude::entered(crate::prelude::once_job([=, paths_p5xy = std::move(paths_p5xy)]() {
            return ({
                auto m_pr = p0;
                (crate::prelude::call_then(start_rust_module_f(m_pr, kids_of_f(paths_p5xy, prism_rtl::deref(m_pr).name_p)), [=](Text rust_module_f_21483) { return prism_rtl::finished(std::tuple{rust_mod_file_f(prism_rtl::deref(m_pr).name_p), rust_module_f_21483}); }));
            });
        })));
        });
    }));
    })));
    auto named_pf = crate::prelude::each(model_p0.mods_p, [&](const crate::lower::model::ModDef& m_ps) { return prism_rtl::deref(m_ps).name_p; });
    auto bare_pg = crate::prelude::each(crate::prelude::filter(paths_p5, [&](const Text& p_pt) { return !crate::prelude::fold(named_pf, false, [&](const bool& f_pu, const Text& n_pv) { return prism_rtl::deref(f_pu) || (n_pv == p_pt); }); }), [&](const Text& p_p10) { return std::tuple{rust_mod_file_f(p_p10), prism_rtl::cat("//! Emitted by prismc: the modules under `", p_p10, "`, which declares nothing of its own.\n\n", kids_of_f(paths_p5, p_p10))}; });
    return crate::prelude::append(Array(std::vector{std::tuple{Text::lit("Cargo.toml"), cargo_p4}, std::tuple{Text::lit("src/main.rs"), main_pd}, std::tuple{Text::lit("src/prelude.rs"), crate::emit::rust::prelude::prelude_source_f(Text::lit(""))}}), crate::prelude::append(files_pe, bare_pg));
}


prism_rtl::Turn<Array<std::tuple<Text, Text>>> EmitCrate::cycle() const {
    const auto& model_p0 = this->model_p0;
    const auto& runtime_p1 = this->runtime_p1;
    const auto& scripts_p2 = this->scripts_p2;
    auto gui_p3 = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = prism_rtl::deref(model_p0).root_o;
        if (prism_rtl::is_some(_m)) {
            auto&& r_ph = prism_rtl::some_of(_m);
            _v.set(prism_rtl::deref(r_ph).world_p == Text::lit("canvas"));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(false);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto cargo_p4 = crate::emit::rust::templates::cargo_f(prism_rtl::deref(model_p0).name_p, runtime_p1, std::move(gui_p3) ? Text::lit("\"canvas\"") : Text::lit(""));
    auto paths_p5 = rust_mod_paths_f(prism_rtl::deref(model_p0).mods_p);
    auto mods_p6 = crate::prelude::concat(crate::prelude::each(crate::prelude::filter(paths_p5, [&](const Text& p_pi) { return !crate::syntax::lexer::chars::contains_f(p_pi, Text::lit(":")); }), [&](const Text& p_pj) { return prism_rtl::cat("mod ", p_pj, ";\n"); }));
    auto model_p0x = model_p0;
    auto scripts_p2x = scripts_p2;
    return crate::prelude::call_value(crate::prelude::each_job(all_programs_f(model_p0x), ({
        auto model_p0xx = model_p0x;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::ProgDef)>>(prism_rtl::rc([=, model_p0xx = std::move(model_p0xx)](crate::lower::model::ProgDef p0) {
        return ({
            auto model_p0xxy = model_p0xx;
            (crate::prelude::entered(crate::prelude::once_job([=, model_p0xxy = std::move(model_p0xxy)]() {
            return ({
                auto p_pk = p0;
                (prism_rtl::more(prism_rtl::rc(RustProgram(p_pk, node_fallible_f(model_p0xxy, prism_rtl::deref(p_pk).node_p)))));
            });
        })));
        });
    })));
    })), [=](Array<Text> each_20711) {
        return ({
            auto programs_p7 = crate::syntax::lexer::chars::join_f(each_20711, Text::lit("\n"));
            auto regs_p8 = crate::prelude::concat(crate::prelude::each(prism_rtl::deref(model_p0x).programs_p, [&](const crate::lower::model::ProgDef& p_pl) { return prism_rtl::cat(".program::<", prism_rtl::deref(p_pl).name_p, ">(\"", prism_rtl::deref(p_pl).prism_p, "\")\n"); }));
            (crate::prelude::call_value(crate::prelude::each_job(prism_rtl::deref(model_p0x).checks_p, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::CheckDef)>>(prism_rtl::rc([=](crate::lower::model::CheckDef p0) {
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto c_pm = p0;
                    (crate::prelude::call_value(crate::prelude::each_job(prism_rtl::deref(c_pm).lines_p, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Ex)>>(prism_rtl::rc([=](crate::lower::model::Ex p0) {
                    return crate::prelude::entered(crate::prelude::once_job([=]() {
                        return ({
                            auto l_pn = p0;
                            (prism_rtl::more(prism_rtl::rc(crate::emit::rust::Expression(l_pn))));
                        });
                    }));
                }))), [=](Array<Text> each_20969) { return prism_rtl::finished(prism_rtl::cat(".check(\"", prism_rtl::deref(c_pm).name_p, "\", || vec![", crate::syntax::lexer::chars::join_f(each_20969, Text::lit(", ")), "])\n")); }));
                });
            }));
        }))), [=, programs_p7 = std::move(programs_p7), regs_p8 = std::move(regs_p8)](Array<Text> each_20908) {
            return ({
                auto checks_p9 = crate::prelude::concat(each_20908);
                auto script_list_pa = crate::prelude::concat(crate::prelude::each(scripts_p2x, [&](const Text& s_po) { return prism_rtl::cat("\"", crate::lower::expr::escape_f(s_po), "\",\n"); }));
                auto run_root_pb = ({
                    __label__ _done;
                    prism_rtl::Slot<Text> _v;
                    auto&& _m = prism_rtl::deref(model_p0x).root_o;
                    if (prism_rtl::is_some(_m)) {
                        auto&& r_pp = prism_rtl::some_of(_m);
                        _v.set(crate::emit::rust::templates::run_root_f(prism_rtl::deref(r_pp).name_p));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(crate::emit::rust::templates::no_root_f(prism_rtl::deref(model_p0x).name_p));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                auto world_pc = ({
                    __label__ _done;
                    prism_rtl::Slot<Text> _v;
                    auto&& _m = prism_rtl::deref(model_p0x).root_o;
                    if (prism_rtl::is_some(_m)) {
                        auto&& r_pq = prism_rtl::some_of(_m);
                        _v.set(prism_rtl::deref(r_pq).world_p);
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(Text::lit("test"));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                (crate::prelude::call_then(start_rust_row_f(prism_rtl::deref(model_p0x).elem_p), [=, checks_p9 = std::move(checks_p9), script_list_pa = std::move(script_list_pa), run_root_pb = std::move(run_root_pb), world_pc = std::move(world_pc)](Text rust_row_f_21314) {
                return crate::prelude::call_then(start_rust_answer_f(prism_rtl::deref(model_p0x).answer_p), [=](Text rust_answer_f_21336) {
                    return ({
                        auto main_pd = crate::emit::rust::templates::main_f(prism_rtl::deref(model_p0x).name_p, prism_rtl::cat("mod prelude;\n", mods_p6), prism_rtl::cat(rust_row_f_21314, "\n", rust_answer_f_21336, "\n", programs_p7), prism_rtl::cat(regs_p8, checks_p9), script_list_pa, run_root_pb, world_pc);
                        (crate::prelude::call_value(crate::prelude::each_job(prism_rtl::deref(model_p0x).mods_p, ({
                        auto paths_p5x = paths_p5;
                        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, Text>>(crate::lower::model::ModDef)>>(prism_rtl::rc([=, paths_p5x = std::move(paths_p5x)](crate::lower::model::ModDef p0) {
                        return ({
                            auto paths_p5xy = paths_p5x;
                            (crate::prelude::entered(crate::prelude::once_job([=, paths_p5xy = std::move(paths_p5xy)]() {
                            return ({
                                auto m_pr = p0;
                                (crate::prelude::call_then(start_rust_module_f(m_pr, kids_of_f(paths_p5xy, prism_rtl::deref(m_pr).name_p)), [=](Text rust_module_f_21483) { return prism_rtl::finished(std::tuple{rust_mod_file_f(prism_rtl::deref(m_pr).name_p), rust_module_f_21483}); }));
                            });
                        })));
                        });
                    }));
                    })), [=, main_pd = std::move(main_pd)](Array<std::tuple<Text, Text>> each_21436) {
                        return ({
                            auto files_pe = each_21436;
                            auto named_pf = crate::prelude::each(prism_rtl::deref(model_p0x).mods_p, [&](const crate::lower::model::ModDef& m_ps) { return prism_rtl::deref(m_ps).name_p; });
                            auto bare_pg = crate::prelude::each(crate::prelude::filter(paths_p5, [&](const Text& p_pt) { return !crate::prelude::fold(named_pf, false, [&](const bool& f_pu, const Text& n_pv) { return prism_rtl::deref(f_pu) || (n_pv == p_pt); }); }), [&](const Text& p_p10) { return std::tuple{rust_mod_file_f(p_p10), prism_rtl::cat("//! Emitted by prismc: the modules under `", p_p10, "`, which declares nothing of its own.\n\n", kids_of_f(paths_p5, p_p10))}; });
                            (prism_rtl::finished(crate::prelude::append(Array(std::vector{std::tuple{Text::lit("Cargo.toml"), cargo_p4}, std::tuple{Text::lit("src/main.rs"), main_pd}, std::tuple{Text::lit("src/prelude.rs"), crate::emit::rust::prelude::prelude_source_f(Text::lit(""))}}), crate::prelude::append(files_pe, bare_pg))));
                        });
                    }));
                    });
                });
            }));
            });
        }));
        });
    });
}


/// `Start EmitCrate, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<std::tuple<Text, Text>>> start_emit_crate_f(crate::lower::model::Model model_p0, Text runtime_p1, Array<Text> scripts_p2) {
    return prism_rtl::make_rc<EmitCrate>(model_p0, runtime_p1, scripts_p2);
}


/// RustModPaths: fn [ModDef] -> [Text]
Array<Text> rust_mod_paths_f(const Array<crate::lower::model::ModDef>& mods_p0) {
    return crate::prelude::fold(mods_p0, Array<Text>{}, [&](const Array<Text>& acc_p1, const crate::lower::model::ModDef& m_p2) {
        return ({
            auto segs_p3 = crate::prelude::split_on(prism_rtl::deref(m_p2).name_p, Text::lit("::"));
            (crate::prelude::fold(crate::check::errors::range0_f(crate::prelude::len(segs_p3)), acc_p1, [&](const Array<Text>& a_p4, const Nat& i_p5) { return add_path_f(a_p4, crate::syntax::lexer::chars::join_f(crate::prelude::take(segs_p3, i_p5 + Nat(1u)), Text::lit("::"))); }));
        });
    });
}


/// AddPath: fn [Text], Text -> [Text]
Array<Text> add_path_f(const Array<Text>& ps_p0, const Text& p_p1) {
    return crate::prelude::fold(ps_p0, false, [&](const bool& f_p2, const Text& q_p3) { return prism_rtl::deref(f_p2) || (q_p3 == p_p1); })
        ? ps_p0
        : crate::prelude::push(ps_p0, p_p1);
}


/// RustModFile: fn Text -> Text
Text rust_mod_file_f(const Text& p_p0) {
    return p_p0 == Text::lit("program")
        ? Text::lit("src/program.rs")
        : prism_rtl::cat("src/", crate::syntax::lexer::chars::join_f(crate::prelude::split_on(p_p0, Text::lit("::")), Text::lit("/")), "/mod.rs");
}


/// KidsOf: fn [Text], Text -> Text
Text kids_of_f(const Array<Text>& paths_p0, const Text& p_p1) {
    return crate::prelude::concat(crate::prelude::each(crate::prelude::filter(paths_p0, [&](const Text& q_p2) { return crate::syntax::lexer::chars::has_prefix_f(q_p2, prism_rtl::cat(p_p1, "::")) && (!crate::syntax::lexer::chars::contains_f(crate::syntax::lexer::chars::drop_prefix_f(q_p2, prism_rtl::cat(p_p1, "::")), Text::lit(":"))); }), [&](const Text& q_p3) { return prism_rtl::cat("pub mod ", crate::syntax::lexer::chars::drop_prefix_f(q_p3, prism_rtl::cat(p_p1, "::")), ";\n"); }));
}


/// AllPrograms: fn Model -> [ProgDef]
Array<crate::lower::model::ProgDef> all_programs_f(const crate::lower::model::Model& model_p0) {
    auto&& _m = model_p0.root_o;
    if (prism_rtl::is_some(_m)) {
        auto&& r_p1 = prism_rtl::some_of(_m);
        return crate::prelude::fold(model_p0.programs_p, false, [&](const bool& f_p2, const crate::lower::model::ProgDef& p_p3) { return prism_rtl::deref(f_p2) || (prism_rtl::deref(p_p3).name_p == prism_rtl::deref(r_p1).name_p); })
            ? model_p0.programs_p
            : crate::prelude::push(model_p0.programs_p, r_p1);
    }
    if (prism_rtl::is_none(_m)) {
        return model_p0.programs_p;
    }
    prism_rtl::unreachable("no arm matched");
}

}  // namespace crate::emit::rust::items
