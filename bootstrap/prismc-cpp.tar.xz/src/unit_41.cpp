// The module `Emit.Rust.Items`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <emit/rust/items/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Emit.Rust.Items`, from `target/bootstrap/cpp-src/prismc/emit/rust/items.prism`.
namespace crate::emit::rust::items {

/// Generics: fn [((Text, [Text]))] -> Text
Text generics(const Array<std::tuple<Text, Array<Text>>>& xs0) {
    {
        auto&& c0_0 = xs0;
        if (c0_0.size() == 0u) {
            return Text::lit("");
        }
    }
    {
        auto&& gs_p0 = xs0;
        return prism_rtl::cat("<", crate::syntax::lexer::chars::join(each(gs_p0, [&](const std::tuple<Text, Array<Text>>& _p0) {
            auto&& g_p1 = std::get<0>(_p0);
            auto&& bs_p2 = std::get<1>(_p0);
            return len(bs_p2) == Nat(0u)
                ? g_p1
                : prism_rtl::cat(g_p1, ": ", crate::syntax::lexer::chars::join(bs_p2, Text::lit(" + ")));
        }), Text::lit(", ")), ">");
    }
}


/// GenericNames: fn [Text] -> Text
Text generic_names(const Array<Text>& xs0) {
    {
        auto&& c0_0 = xs0;
        if (c0_0.size() == 0u) {
            return Text::lit("");
        }
    }
    {
        auto&& ps_p0 = xs0;
        return prism_rtl::cat("<", crate::syntax::lexer::chars::join(ps_p0, Text::lit(", ")), ">");
    }
}


/// Bounded: fn [Text], Text -> Text
Text bounded(const Array<Text>& xs0, const Text& text1) {
    auto&& _m = std::tuple{xs0, text1};
    {
        auto&& c0_0 = std::get<0>(_m);
        if (c0_0.size() == 0u) {
            return Text::lit("");
        }
    }
    {
        auto&& ps_p0 = std::get<0>(_m);
        auto&& tr_p1 = std::get<1>(_m);
        return prism_rtl::cat("<", crate::syntax::lexer::chars::join(each(ps_p0, [&](const Text& p_p2) { return prism_rtl::cat(p_p2, ": ", tr_p1); }), Text::lit(", ")), ">");
    }
    prism_rtl::unreachable("no arm matched");
}


/// RustItem: unbounded fn Item -> Text
Text rust_item(const crate::lower::model::Item& it_p0) {
    if (prism_rtl::is<crate::lower::model::Item::ItTrait>(it_p0)) {
        auto&& t_p1 = prism_rtl::as<crate::lower::model::Item::ItTrait>(it_p0).a0;
        return rust_trait(t_p1);
    }
    if (prism_rtl::is<crate::lower::model::Item::ItImpl>(it_p0)) {
        auto&& i_p2 = prism_rtl::as<crate::lower::model::Item::ItImpl>(it_p0).a0;
        return rust_impl(i_p2);
    }
    if (prism_rtl::is<crate::lower::model::Item::ItType>(it_p0)) {
        auto&& t_p3 = prism_rtl::as<crate::lower::model::Item::ItType>(it_p0).a0;
        return type_decl(t_p3);
    }
    if (prism_rtl::is<crate::lower::model::Item::ItTag>(it_p0)) {
        auto&& t_p4 = prism_rtl::as<crate::lower::model::Item::ItTag>(it_p0).a0;
        return rust_tag(t_p4);
    }
    if (prism_rtl::is<crate::lower::model::Item::ItRow>(it_p0)) {
        auto&& r_p5 = prism_rtl::as<crate::lower::model::Item::ItRow>(it_p0).a0;
        return rust_row(r_p5);
    }
    if (prism_rtl::is<crate::lower::model::Item::ItFn>(it_p0)) {
        auto&& f_p6 = prism_rtl::as<crate::lower::model::Item::ItFn>(it_p0).a0;
        return rust_fn(f_p6);
    }
    if (prism_rtl::is<crate::lower::model::Item::ItJob>(it_p0)) {
        auto&& j_p7 = prism_rtl::as<crate::lower::model::Item::ItJob>(it_p0).a0;
        return rust_job(j_p7);
    }
    if (prism_rtl::is<crate::lower::model::Item::ItNode>(it_p0)) {
        auto&& n_p8 = prism_rtl::as<crate::lower::model::Item::ItNode>(it_p0).a0;
        return rust_node(n_p8);
    }
    if (prism_rtl::is<crate::lower::model::Item::ItNote>(it_p0)) {
        auto&& t_p9 = prism_rtl::as<crate::lower::model::Item::ItNote>(it_p0).a0;
        return prism_rtl::cat("// ", t_p9, "\n");
    }
    if (prism_rtl::is<crate::lower::model::Item::ItRefused>(it_p0)) {
        auto&& t_pa = prism_rtl::as<crate::lower::model::Item::ItRefused>(it_p0).a0;
        return prism_rtl::cat("compile_error!(\"", crate::lower::expr::lowering_refusal(), crate::lower::expr::escape(t_pa), "\");\n");
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Text> RustItem::cycle() const {
    const auto& it_p0 = this->it_p0;
    return ({
        prism_rtl::is<crate::lower::model::Item::ItTrait>(it_p0) ? ({
        auto&& t_p1 = prism_rtl::as<crate::lower::model::Item::ItTrait>(it_p0).a0;
        prism_rtl::more(prism_rtl::rc(RustTrait(t_p1)));
    })
        : prism_rtl::is<crate::lower::model::Item::ItImpl>(it_p0) ? ({
        auto&& i_p2 = prism_rtl::as<crate::lower::model::Item::ItImpl>(it_p0).a0;
        prism_rtl::more(prism_rtl::rc(RustImpl(i_p2)));
    })
        : prism_rtl::is<crate::lower::model::Item::ItType>(it_p0) ? ({
        auto&& t_p3 = prism_rtl::as<crate::lower::model::Item::ItType>(it_p0).a0;
        prism_rtl::more(prism_rtl::rc(TypeDecl(t_p3)));
    })
        : prism_rtl::is<crate::lower::model::Item::ItTag>(it_p0) ? ({
        auto&& t_p4 = prism_rtl::as<crate::lower::model::Item::ItTag>(it_p0).a0;
        prism_rtl::more(prism_rtl::rc(RustTag(t_p4)));
    })
        : prism_rtl::is<crate::lower::model::Item::ItRow>(it_p0) ? ({
        auto&& r_p5 = prism_rtl::as<crate::lower::model::Item::ItRow>(it_p0).a0;
        prism_rtl::more(prism_rtl::rc(RustRow(r_p5)));
    })
        : prism_rtl::is<crate::lower::model::Item::ItFn>(it_p0) ? ({
        auto&& f_p6 = prism_rtl::as<crate::lower::model::Item::ItFn>(it_p0).a0;
        prism_rtl::more(prism_rtl::rc(RustFn(f_p6)));
    })
        : prism_rtl::is<crate::lower::model::Item::ItJob>(it_p0) ? ({
        auto&& j_p7 = prism_rtl::as<crate::lower::model::Item::ItJob>(it_p0).a0;
        prism_rtl::more(prism_rtl::rc(RustJob(j_p7)));
    })
        : prism_rtl::is<crate::lower::model::Item::ItNode>(it_p0) ? ({
        auto&& n_p8 = prism_rtl::as<crate::lower::model::Item::ItNode>(it_p0).a0;
        prism_rtl::more(prism_rtl::rc(RustNode(n_p8)));
    })
        : prism_rtl::is<crate::lower::model::Item::ItNote>(it_p0) ? ({
        auto&& t_p9 = prism_rtl::as<crate::lower::model::Item::ItNote>(it_p0).a0;
        prism_rtl::finished(prism_rtl::cat("// ", t_p9, "\n"));
    })
        : prism_rtl::is<crate::lower::model::Item::ItRefused>(it_p0) ? ({
        auto&& t_pa = prism_rtl::as<crate::lower::model::Item::ItRefused>(it_p0).a0;
        prism_rtl::finished(prism_rtl::cat("compile_error!(\"", crate::lower::expr::lowering_refusal(), crate::lower::expr::escape(t_pa), "\");\n"));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start RustItem, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_rust_item(crate::lower::model::Item it_p0) {
    return prism_rtl::make_rc<RustItem>(it_p0);
}


/// RustTrait: unbounded fn TraitDef -> Text
Text rust_trait(const crate::lower::model::TraitDef& t_p0) {
    auto ms_p1 = crate::syntax::lexer::chars::join(run_to_end(each_job(t_p0.methods, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::FnDef)>>(prism_rtl::rc([=](crate::lower::model::FnDef p0) {
        return entered(once_job([=]() {
            return ({
                auto f_p2 = p0;
                (prism_rtl::more(prism_rtl::rc(TraitMethod(f_p2))));
            });
        }));
    })))), Text::lit("\n"));
    return prism_rtl::cat(crate::emit::rust::templates::source_doc(Text::lit(""), t_p0.doc), "pub trait ", t_p0.name, " {\n", crate::emit::rust::indent(ms_p1), "\n}\n");
}


prism_rtl::Turn<Text> RustTrait::cycle() const {
    const auto& t_p0 = this->t_p0;
    auto t_p0_1 = t_p0;
    return call_value(each_job(prism_rtl::deref(t_p0_1).methods, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::FnDef)>>(prism_rtl::rc([=](crate::lower::model::FnDef p0) {
        return entered(once_job([=]() {
            return ({
                auto f_p2 = p0;
                (prism_rtl::more(prism_rtl::rc(TraitMethod(f_p2))));
            });
        }));
    }))), [=](Array<Text> each_1796) {
        return ({
            auto ms_p1 = crate::syntax::lexer::chars::join(each_1796, Text::lit("\n"));
            (prism_rtl::finished(prism_rtl::cat(crate::emit::rust::templates::source_doc(Text::lit(""), prism_rtl::deref(t_p0_1).doc), "pub trait ", prism_rtl::deref(t_p0_1).name, " {\n", crate::emit::rust::indent(ms_p1), "\n}\n")));
        });
    });
}


/// `Start RustTrait, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_rust_trait(crate::lower::model::TraitDef t_p0) {
    return prism_rtl::make_rc<RustTrait>(t_p0);
}


/// Signature: unbounded fn FnDef, Text -> Text
Text signature(const crate::lower::model::FnDef& f_p0, const Text& vis_p1) {
    auto params_p2 = crate::syntax::lexer::chars::join(run_to_end(each_job(f_p0.params, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
        return entered(once_job([=]() {
            return ({
                auto [n_p3, t_p4] = p0;
                call_then(crate::emit::rust::start_type_(t_p4), [=](Text type__2029) { return prism_rtl::finished(prism_rtl::cat(n_p3, ": ", type__2029)); });
            });
        }));
    })))), Text::lit(", "));
    return prism_rtl::cat(vis_p1, "fn ", f_p0.name, generics(f_p0.generics), "(", params_p2, ") -> ", crate::emit::rust::type_(f_p0.ret));
}


prism_rtl::Turn<Text> Signature::cycle() const {
    const auto& f_p0 = this->f_p0;
    const auto& vis_p1 = this->vis_p1;
    auto f_p0_1 = f_p0;
    auto vis_p1_2 = vis_p1;
    return call_value(each_job(prism_rtl::deref(f_p0_1).params, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
        return entered(once_job([=]() {
            return ({
                auto [n_p3, t_p4] = p0;
                call_then(crate::emit::rust::start_type_(t_p4), [=](Text type__2029) { return prism_rtl::finished(prism_rtl::cat(n_p3, ": ", type__2029)); });
            });
        }));
    }))), [=](Array<Text> each_1995) {
        return ({
            auto params_p2 = crate::syntax::lexer::chars::join(each_1995, Text::lit(", "));
            call_then(crate::emit::rust::start_type_(prism_rtl::deref(f_p0_1).ret), [=, params_p2 = std::move(params_p2)](Text type__2102) { return prism_rtl::finished(prism_rtl::cat(vis_p1_2, "fn ", prism_rtl::deref(f_p0_1).name, generics(prism_rtl::deref(f_p0_1).generics), "(", params_p2, ") -> ", type__2102)); });
        });
    });
}


/// `Start Signature, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_signature(crate::lower::model::FnDef f_p0, Text vis_p1) {
    return prism_rtl::make_rc<Signature>(f_p0, vis_p1);
}


/// TraitMethod: unbounded fn FnDef -> Text
Text trait_method(const crate::lower::model::FnDef& f_p0) {
    return f_p0.public_
        ? crate::emit::rust::templates::items::fn_(Text::lit(""), signature(f_p0, Text::lit("")), crate::emit::rust::body_lines(f_p0.body))
        : prism_rtl::cat(signature(f_p0, Text::lit("")), ";");
}


prism_rtl::Turn<Text> TraitMethod::cycle() const {
    const auto& f_p0 = this->f_p0;
    return prism_rtl::deref(f_p0).public_
        ? ({
        auto f_p0_1 = f_p0;
        call_then(start_signature(f_p0_1, Text::lit("")), [=](Text signature_2196) { return call_then(crate::emit::rust::start_body_lines(prism_rtl::deref(f_p0_1).body), [=](Text body_lines_2215) { return prism_rtl::finished(crate::emit::rust::templates::items::fn_(Text::lit(""), signature_2196, body_lines_2215)); }); });
    })
        : ({
        auto f_p0_1 = f_p0;
        call_then(start_signature(f_p0_1, Text::lit("")), [=](Text signature_2241) { return prism_rtl::finished(prism_rtl::cat(signature_2241, ";")); });
    });
}


/// `Start TraitMethod, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_trait_method(crate::lower::model::FnDef f_p0) {
    return prism_rtl::make_rc<TraitMethod>(f_p0);
}


/// RustImpl: unbounded fn ImplDef -> Text
Text rust_impl(const crate::lower::model::ImplDef& i_p0) {
    auto head_p1 = crate::emit::rust::type_(i_p0.head);
    auto gens_p2 = generics(i_p0.generics);
    auto&& _m = i_p0.cls;
    {
        auto&& m2516_0 = _m;
        if (m2516_0 == Text::lit("Prelude.Show")) {
            auto fns_p3 = crate::syntax::lexer::chars::join(run_to_end(each_job(i_p0.methods, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::FnDef)>>(prism_rtl::rc([=](crate::lower::model::FnDef p0) {
                return entered(once_job([=]() {
                    return ({
                        auto f_p5 = p0;
                        (prism_rtl::more(prism_rtl::rc(RustFn(f_p5))));
                    });
                }));
            })))), Text::lit("\n"));
            auto shown_p4 = or_(index(each(i_p0.methods, [&](const crate::lower::model::FnDef& f_p6) { return prism_rtl::deref(f_p6).name; }), Nat(0u)), Text::lit("show"));
            return prism_rtl::cat(fns_p3, "\n", crate::emit::rust::templates::items::impl_(gens_p2, Text::lit("Show"), head_p1, Text::lit("fn show(&self, p: &mut Printer)"), prism_rtl::cat("p.raw(&", shown_p4, "(self).to_string());")));
        }
    }
    {
        auto&& m2516_1 = _m;
        if (m2516_1 == Text::lit("Prelude.Eq")) {
            auto fns_p7 = crate::syntax::lexer::chars::join(run_to_end(each_job(i_p0.methods, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::FnDef)>>(prism_rtl::rc([=](crate::lower::model::FnDef p0) {
                return entered(once_job([=]() {
                    return ({
                        auto f_p9 = p0;
                        (prism_rtl::more(prism_rtl::rc(RustFn(f_p9))));
                    });
                }));
            })))), Text::lit("\n"));
            auto eq_p8 = fold(i_p0.methods, Text::lit(""), [&](const Text& acc_pa, const crate::lower::model::FnDef& f_pb) {
                return (!crate::syntax::lexer::chars::has_prefix(prism_rtl::deref(f_pb).name, Text::lit("ne"))) && (acc_pa == Text::lit(""))
                    ? prism_rtl::deref(f_pb).name
                    : acc_pa;
            });
            return prism_rtl::cat(fns_p7, "\n", crate::emit::rust::templates::items::impl_(gens_p2, Text::lit("PartialEq"), head_p1, Text::lit("fn eq(&self, other: &Self) -> bool"), prism_rtl::cat(eq_p8, "(self, other)")), "\nimpl", gens_p2, " Eq for ", head_p1, " {}");
        }
    }
    {
        return prism_rtl::cat("impl", gens_p2, " ", i_p0.tr, " for ", head_p1, " {\n", crate::emit::rust::indent(crate::syntax::lexer::chars::join(run_to_end(each_job(i_p0.methods, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::FnDef)>>(prism_rtl::rc([=](crate::lower::model::FnDef p0) {
            return entered(once_job([=]() {
                return ({
                    auto f_pc = p0;
                    call_then(start_signature(f_pc, Text::lit("")), [=](Text signature_3249) { return call_then(crate::emit::rust::start_body_lines(prism_rtl::deref(f_pc).body), [=](Text body_lines_3268) { return prism_rtl::finished(crate::emit::rust::templates::items::fn_(Text::lit(""), signature_3249, body_lines_3268)); }); });
                });
            }));
        })))), Text::lit("\n"))), "\n}\n");
    }
}


prism_rtl::Turn<Text> RustImpl::cycle() const {
    const auto& i_p0 = this->i_p0;
    auto i_p0_1 = i_p0;
    return call_then(crate::emit::rust::start_type_(prism_rtl::deref(i_p0_1).head), [=](Text type__2465) {
        return ({
            auto head_p1 = type__2465;
            auto gens_p2 = generics(prism_rtl::deref(i_p0_1).generics);
            ({
            auto&& _m = prism_rtl::deref(i_p0_1).cls;
            ({
            auto&& m2516_0 = _m;
            (m2516_0 == Text::lit("Prelude.Show"));
        }) ? ({
            auto&& m2516_0 = _m;
            call_value(each_job(prism_rtl::deref(i_p0_1).methods, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::FnDef)>>(prism_rtl::rc([=](crate::lower::model::FnDef p0) {
            return entered(once_job([=]() {
                return ({
                    auto f_p5 = p0;
                    (prism_rtl::more(prism_rtl::rc(RustFn(f_p5))));
                });
            }));
        }))), [=, head_p1 = std::move(head_p1), gens_p2 = std::move(gens_p2)](Array<Text> each_2581) {
            return ({
                auto fns_p3 = crate::syntax::lexer::chars::join(each_2581, Text::lit("\n"));
                auto shown_p4 = or_(index(each(prism_rtl::deref(i_p0_1).methods, [&](const crate::lower::model::FnDef& f_p6) { return prism_rtl::deref(f_p6).name; }), Nat(0u)), Text::lit("show"));
                (prism_rtl::finished(prism_rtl::cat(fns_p3, "\n", crate::emit::rust::templates::items::impl_(gens_p2, Text::lit("Show"), head_p1, Text::lit("fn show(&self, p: &mut Printer)"), prism_rtl::cat("p.raw(&", shown_p4, "(self).to_string());")))));
            });
        });
        })
            : ({
            auto&& m2516_1 = _m;
            (m2516_1 == Text::lit("Prelude.Eq"));
        }) ? ({
            auto&& m2516_1 = _m;
            call_value(each_job(prism_rtl::deref(i_p0_1).methods, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::FnDef)>>(prism_rtl::rc([=](crate::lower::model::FnDef p0) {
            return entered(once_job([=]() {
                return ({
                    auto f_p9 = p0;
                    (prism_rtl::more(prism_rtl::rc(RustFn(f_p9))));
                });
            }));
        }))), [=, head_p1 = std::move(head_p1), gens_p2 = std::move(gens_p2)](Array<Text> each_2856) {
            return ({
                auto fns_p7 = crate::syntax::lexer::chars::join(each_2856, Text::lit("\n"));
                auto eq_p8 = fold(prism_rtl::deref(i_p0_1).methods, Text::lit(""), [&](const Text& acc_pa, const crate::lower::model::FnDef& f_pb) {
                    return (!crate::syntax::lexer::chars::has_prefix(prism_rtl::deref(f_pb).name, Text::lit("ne"))) && (acc_pa == Text::lit(""))
                        ? prism_rtl::deref(f_pb).name
                        : acc_pa;
                });
                (prism_rtl::finished(prism_rtl::cat(fns_p7, "\n", crate::emit::rust::templates::items::impl_(gens_p2, Text::lit("PartialEq"), head_p1, Text::lit("fn eq(&self, other: &Self) -> bool"), prism_rtl::cat(eq_p8, "(self, other)")), "\nimpl", gens_p2, " Eq for ", head_p1, " {}")));
            });
        });
        })
            : call_value(each_job(prism_rtl::deref(i_p0_1).methods, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::FnDef)>>(prism_rtl::rc([=](crate::lower::model::FnDef p0) {
            return entered(once_job([=]() {
                return ({
                    auto f_pc = p0;
                    call_then(start_signature(f_pc, Text::lit("")), [=](Text signature_3249) { return call_then(crate::emit::rust::start_body_lines(prism_rtl::deref(f_pc).body), [=](Text body_lines_3268) { return prism_rtl::finished(crate::emit::rust::templates::items::fn_(Text::lit(""), signature_3249, body_lines_3268)); }); });
                });
            }));
        }))), [=, head_p1 = std::move(head_p1), gens_p2 = std::move(gens_p2)](Array<Text> each_3220) { return prism_rtl::finished(prism_rtl::cat("impl", gens_p2, " ", prism_rtl::deref(i_p0_1).tr, " for ", head_p1, " {\n", crate::emit::rust::indent(crate::syntax::lexer::chars::join(each_3220, Text::lit("\n"))), "\n}\n")); });
        });
        });
    });
}


/// `Start RustImpl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_rust_impl(crate::lower::model::ImplDef i_p0) {
    return prism_rtl::make_rc<RustImpl>(i_p0);
}


/// RustFn: unbounded fn FnDef -> Text
Text rust_fn(const crate::lower::model::FnDef& f_p0) {
    auto params_p1 = crate::syntax::lexer::chars::join(run_to_end(each_job(f_p0.params, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
        return entered(once_job([=]() {
            return ({
                auto [n_p3, t_p4] = p0;
                call_then(crate::emit::rust::start_type_(t_p4), [=](Text type__3408) { return prism_rtl::finished(prism_rtl::cat(n_p3, ": ", type__3408)); });
            });
        }));
    })))), Text::lit(", "));
    auto sig_p2 = prism_rtl::cat("pub fn ", f_p0.name, static_generics(f_p0.generics), "(", params_p1, ") -> ", crate::emit::rust::type_(f_p0.ret));
    return crate::emit::rust::templates::items::fn_(crate::emit::rust::templates::source_doc(Text::lit(""), f_p0.doc), sig_p2, crate::emit::rust::body_lines(f_p0.body));
}


prism_rtl::Turn<Text> RustFn::cycle() const {
    const auto& f_p0 = this->f_p0;
    auto f_p0_1 = f_p0;
    return call_value(each_job(prism_rtl::deref(f_p0_1).params, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
        return entered(once_job([=]() {
            return ({
                auto [n_p3, t_p4] = p0;
                call_then(crate::emit::rust::start_type_(t_p4), [=](Text type__3408) { return prism_rtl::finished(prism_rtl::cat(n_p3, ": ", type__3408)); });
            });
        }));
    }))), [=](Array<Text> each_3374) {
        return ({
            auto params_p1 = crate::syntax::lexer::chars::join(each_3374, Text::lit(", "));
            call_then(crate::emit::rust::start_type_(prism_rtl::deref(f_p0_1).ret), [=, params_p1 = std::move(params_p1)](Text type__3638) {
            return ({
                auto sig_p2 = prism_rtl::cat("pub fn ", prism_rtl::deref(f_p0_1).name, static_generics(prism_rtl::deref(f_p0_1).generics), "(", params_p1, ") -> ", type__3638);
                call_then(crate::emit::rust::start_body_lines(prism_rtl::deref(f_p0_1).body), [=, sig_p2 = std::move(sig_p2)](Text body_lines_3687) { return prism_rtl::finished(crate::emit::rust::templates::items::fn_(crate::emit::rust::templates::source_doc(Text::lit(""), prism_rtl::deref(f_p0_1).doc), sig_p2, body_lines_3687)); });
            });
        });
        });
    });
}


/// `Start RustFn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_rust_fn(crate::lower::model::FnDef f_p0) {
    return prism_rtl::make_rc<RustFn>(f_p0);
}


/// StaticGenerics: fn [((Text, [Text]))] -> Text
Text static_generics(const Array<std::tuple<Text, Array<Text>>>& gs_p0) {
    return generics(each(gs_p0, [&](const std::tuple<Text, Array<Text>>& _p0) {
        auto&& g_p1 = std::get<0>(_p0);
        auto&& bs_p2 = std::get<1>(_p0);
        return std::tuple{g_p1, crate::prelude::push(bs_p2, Text::lit("\'static"))};
    }));
}


/// RustJob: unbounded fn JobDef -> Text
Text rust_job(const crate::lower::model::JobDef& j_p0) {
    auto gnames_p1 = generic_names(each(j_p0.generics, [&](const std::tuple<Text, Array<Text>>& _p0) {
        auto&& g_p7 = std::get<0>(_p0);
        return g_p7;
    }));
    auto fields_p2 = crate::syntax::lexer::chars::join(run_to_end(each_job(j_p0.fields, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
        return entered(once_job([=]() {
            return ({
                auto [n_p8, t_p9] = p0;
                call_then(crate::emit::rust::start_type_(t_p9), [=](Text type__4093) { return prism_rtl::finished(prism_rtl::cat("pub ", n_p8, ": ", type__4093, ",")); });
            });
        }));
    })))), Text::lit("\n"));
    auto params_p3 = crate::syntax::lexer::chars::join(run_to_end(each_job(j_p0.fields, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
        return entered(once_job([=]() {
            return ({
                auto [n_pa, t_pb] = p0;
                call_then(crate::emit::rust::start_type_(t_pb), [=](Text type__4167) { return prism_rtl::finished(prism_rtl::cat(n_pa, ": ", type__4167)); });
            });
        }));
    })))), Text::lit(", "));
    auto bounded_p4 = static_generics(j_p0.generics);
    auto start_p5 = prism_rtl::cat("pub fn ", j_p0.start, bounded_p4, "(", params_p3, ") -> Rc<dyn prism_rtl::Job<", crate::emit::rust::type_(j_p0.ret), ">>");
    auto start_body_p6 = prism_rtl::cat("Rc::new(", j_p0.name, " { ", crate::syntax::lexer::chars::join(each(j_p0.fields, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
        auto&& n_pc = std::get<0>(_p0);
        return n_pc;
    }), Text::lit(", ")), " })");
    return crate::emit::rust::templates::items::job(crate::emit::rust::templates::source_doc(Text::lit(""), j_p0.doc), j_p0.name, gnames_p1, bounded_p4, fields_p2, crate::emit::rust::type_(j_p0.ret), crate::emit::rust::body_lines(j_p0.body), start_p5, start_body_p6);
}


prism_rtl::Turn<Text> RustJob::cycle() const {
    const auto& j_p0 = this->j_p0;
    auto gnames_p1 = generic_names(each(prism_rtl::deref(j_p0).generics, [&](const std::tuple<Text, Array<Text>>& _p0) {
        auto&& g_p7 = std::get<0>(_p0);
        return g_p7;
    }));
    auto j_p0_1 = j_p0;
    return call_value(each_job(prism_rtl::deref(j_p0_1).fields, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
        return entered(once_job([=]() {
            return ({
                auto [n_p8, t_p9] = p0;
                call_then(crate::emit::rust::start_type_(t_p9), [=](Text type__4093) { return prism_rtl::finished(prism_rtl::cat("pub ", n_p8, ": ", type__4093, ",")); });
            });
        }));
    }))), [=](Array<Text> each_4055) {
        return ({
            auto fields_p2 = crate::syntax::lexer::chars::join(each_4055, Text::lit("\n"));
            call_value(each_job(prism_rtl::deref(j_p0_1).fields, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
            return entered(once_job([=]() {
                return ({
                    auto [n_pa, t_pb] = p0;
                    call_then(crate::emit::rust::start_type_(t_pb), [=](Text type__4167) { return prism_rtl::finished(prism_rtl::cat(n_pa, ": ", type__4167)); });
                });
            }));
        }))), [=, fields_p2 = std::move(fields_p2)](Array<Text> each_4133) {
            return ({
                auto params_p3 = crate::syntax::lexer::chars::join(each_4133, Text::lit(", "));
                auto bounded_p4 = static_generics(prism_rtl::deref(j_p0_1).generics);
                call_then(crate::emit::rust::start_type_(prism_rtl::deref(j_p0_1).ret), [=, params_p3 = std::move(params_p3), bounded_p4 = std::move(bounded_p4)](Text type__4391) {
                return ({
                    auto start_p5 = prism_rtl::cat("pub fn ", prism_rtl::deref(j_p0_1).start, bounded_p4, "(", params_p3, ") -> Rc<dyn prism_rtl::Job<", type__4391, ">>");
                    auto start_body_p6 = prism_rtl::cat("Rc::new(", prism_rtl::deref(j_p0_1).name, " { ", crate::syntax::lexer::chars::join(each(prism_rtl::deref(j_p0_1).fields, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
                        auto&& n_pc = std::get<0>(_p0);
                        return n_pc;
                    }), Text::lit(", ")), " })");
                    call_then(crate::emit::rust::start_type_(prism_rtl::deref(j_p0_1).ret), [=, start_p5 = std::move(start_p5), start_body_p6 = std::move(start_body_p6)](Text type__4566) { return call_then(crate::emit::rust::start_body_lines(prism_rtl::deref(j_p0_1).body), [=](Text body_lines_4580) { return prism_rtl::finished(crate::emit::rust::templates::items::job(crate::emit::rust::templates::source_doc(Text::lit(""), prism_rtl::deref(j_p0_1).doc), prism_rtl::deref(j_p0_1).name, gnames_p1, bounded_p4, fields_p2, type__4566, body_lines_4580, start_p5, start_body_p6)); }); });
                });
            });
            });
        });
        });
    });
}


/// `Start RustJob, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_rust_job(crate::lower::model::JobDef j_p0) {
    return prism_rtl::make_rc<RustJob>(j_p0);
}


/// TypeDecl: unbounded fn TyDef -> Text
Text type_decl(const crate::lower::model::TyDef& t_p0) {
    auto derives_p1 = crate::syntax::lexer::chars::join(filter(Array(std::vector{Text::lit("Clone"), t_p0.eq || t_p0.ord ? Text::lit("PartialEq, Eq") : Text::lit(""), t_p0.ord ? Text::lit("PartialOrd, Ord") : Text::lit("")}), [&](const Text& d_p7) { return d_p7 != Text::lit(""); }), Text::lit(", "));
    auto head_p2 = prism_rtl::cat(t_p0.name, generic_names(t_p0.params));
    auto doc_p3 = crate::emit::rust::templates::source_doc(prism_rtl::cat("`", t_p0.prism, "`:"), t_p0.doc);
    auto decl_p4 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = t_p0.shape;
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeRecord>(_m)) {
            _v.set(({
                auto c_p8 = or_(index(t_p0.cases_, Nat(0u)), crate::lower::model::CaseDef{.name = Text::lit(""), .prism = Text::lit(""), .fields = Array<std::tuple<Text, crate::lower::model::OutTy>>{}});
                (crate::emit::rust::templates::items::struct_(doc_p3, derives_p1, head_p2, crate::syntax::lexer::chars::join(run_to_end(each_job(prism_rtl::deref(c_p8).fields, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
                return entered(once_job([=]() {
                    return ({
                        auto [f_p9, ft_pa] = p0;
                        call_then(crate::emit::rust::start_type_(ft_pa), [=](Text type__5220) { return prism_rtl::finished(prism_rtl::cat("pub ", f_p9, ": ", type__5220, ",")); });
                    });
                }));
            })))), Text::lit("\n"))));
            }));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeUnit>(_m)) {
            _v.set(crate::emit::rust::templates::items::tuple_struct(doc_p3, derives_p1, head_p2, Text::lit("")));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeNewtype>(_m)) {
            _v.set(({
                auto c_pb = or_(index(t_p0.cases_, Nat(0u)), crate::lower::model::CaseDef{.name = Text::lit(""), .prism = Text::lit(""), .fields = Array<std::tuple<Text, crate::lower::model::OutTy>>{}});
                (crate::emit::rust::templates::items::tuple_struct(doc_p3, derives_p1, head_p2, prism_rtl::cat("(", crate::syntax::lexer::chars::join(run_to_end(each_job(prism_rtl::deref(c_pb).fields, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
                return entered(once_job([=]() {
                    return ({
                        auto&& _ft_pc = p0;
                        auto&& ft_pc = std::get<1>(_ft_pc);
                        call_then(crate::emit::rust::start_type_(ft_pc), [=](Text type__5484) { return prism_rtl::finished(prism_rtl::cat("pub ", type__5484)); });
                    });
                }));
            })))), Text::lit(", ")), ")")));
            }));
            goto _done;
        }
        {
            _v.set(crate::emit::rust::templates::items::enum_(doc_p3, derives_p1, head_p2, crate::syntax::lexer::chars::join(run_to_end(each_job(t_p0.cases_, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::CaseDef)>>(prism_rtl::rc([=](crate::lower::model::CaseDef p0) {
                return entered(once_job([=]() {
                    return ({
                        auto c_pd = p0;
                        (prism_rtl::more(prism_rtl::rc(EnumCase(c_pd))));
                    });
                }));
            })))), Text::lit("\n"))));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto show_p5 = t_p0.show_ == crate::lower::model::Shown(crate::lower::model::Shown::ShownDerived{})
        ? prism_rtl::cat("\n", show_impl(t_p0, head_p2))
        : Text::lit("");
    auto pod_p6 = t_p0.pod
        ? prism_rtl::cat("\n", to_pod_impl(t_p0, head_p2), "\n", from_pod_impl(t_p0, head_p2))
        : Text::lit("");
    return prism_rtl::cat(decl_p4, show_p5, pod_p6);
}


prism_rtl::Turn<Text> TypeDecl::cycle() const {
    const auto& t_p0 = this->t_p0;
    auto derives_p1 = crate::syntax::lexer::chars::join(filter(Array(std::vector{Text::lit("Clone"), prism_rtl::deref(t_p0).eq || prism_rtl::deref(t_p0).ord
        ? Text::lit("PartialEq, Eq")
        : Text::lit(""), prism_rtl::deref(t_p0).ord ? Text::lit("PartialOrd, Ord") : Text::lit("")}), [&](const Text& d_p7) { return d_p7 != Text::lit(""); }), Text::lit(", "));
    auto head_p2 = prism_rtl::cat(prism_rtl::deref(t_p0).name, generic_names(prism_rtl::deref(t_p0).params));
    auto doc_p3 = crate::emit::rust::templates::source_doc(prism_rtl::cat("`", prism_rtl::deref(t_p0).prism, "`:"), prism_rtl::deref(t_p0).doc);
    auto decl_p4 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = prism_rtl::deref(t_p0).shape;
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeRecord>(_m)) {
            _v.set(({
                auto c_p8 = or_(index(prism_rtl::deref(t_p0).cases_, Nat(0u)), crate::lower::model::CaseDef{.name = Text::lit(""), .prism = Text::lit(""), .fields = Array<std::tuple<Text, crate::lower::model::OutTy>>{}});
                (crate::emit::rust::templates::items::struct_(doc_p3, derives_p1, head_p2, crate::syntax::lexer::chars::join(run_to_end(each_job(prism_rtl::deref(c_p8).fields, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
                return entered(once_job([=]() {
                    return ({
                        auto [f_p9, ft_pa] = p0;
                        call_then(crate::emit::rust::start_type_(ft_pa), [=](Text type__5220) { return prism_rtl::finished(prism_rtl::cat("pub ", f_p9, ": ", type__5220, ",")); });
                    });
                }));
            })))), Text::lit("\n"))));
            }));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeUnit>(_m)) {
            _v.set(crate::emit::rust::templates::items::tuple_struct(doc_p3, derives_p1, head_p2, Text::lit("")));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeNewtype>(_m)) {
            _v.set(({
                auto c_pb = or_(index(prism_rtl::deref(t_p0).cases_, Nat(0u)), crate::lower::model::CaseDef{.name = Text::lit(""), .prism = Text::lit(""), .fields = Array<std::tuple<Text, crate::lower::model::OutTy>>{}});
                (crate::emit::rust::templates::items::tuple_struct(doc_p3, derives_p1, head_p2, prism_rtl::cat("(", crate::syntax::lexer::chars::join(run_to_end(each_job(prism_rtl::deref(c_pb).fields, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
                return entered(once_job([=]() {
                    return ({
                        auto&& _ft_pc = p0;
                        auto&& ft_pc = std::get<1>(_ft_pc);
                        call_then(crate::emit::rust::start_type_(ft_pc), [=](Text type__5484) { return prism_rtl::finished(prism_rtl::cat("pub ", type__5484)); });
                    });
                }));
            })))), Text::lit(", ")), ")")));
            }));
            goto _done;
        }
        {
            _v.set(crate::emit::rust::templates::items::enum_(doc_p3, derives_p1, head_p2, crate::syntax::lexer::chars::join(run_to_end(each_job(prism_rtl::deref(t_p0).cases_, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::CaseDef)>>(prism_rtl::rc([=](crate::lower::model::CaseDef p0) {
                return entered(once_job([=]() {
                    return ({
                        auto c_pd = p0;
                        (prism_rtl::more(prism_rtl::rc(EnumCase(c_pd))));
                    });
                }));
            })))), Text::lit("\n"))));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto show_p5 = prism_rtl::deref(t_p0).show_ == crate::lower::model::Shown(crate::lower::model::Shown::ShownDerived{})
        ? prism_rtl::cat("\n", show_impl(t_p0, head_p2))
        : Text::lit("");
    auto pod_p6 = prism_rtl::deref(t_p0).pod
        ? prism_rtl::cat("\n", to_pod_impl(t_p0, head_p2), "\n", from_pod_impl(t_p0, head_p2))
        : Text::lit("");
    return prism_rtl::finished(prism_rtl::cat(decl_p4, show_p5, pod_p6));
}


/// `Start TypeDecl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_type_decl(crate::lower::model::TyDef t_p0) {
    return prism_rtl::make_rc<TypeDecl>(t_p0);
}


/// EnumCase: unbounded fn CaseDef -> Text
Text enum_case(const crate::lower::model::CaseDef& c_p0) {
    return len(c_p0.fields) == Nat(0u)
        ? prism_rtl::cat(c_p0.name, ",")
        : prism_rtl::cat(c_p0.name, "(", crate::syntax::lexer::chars::join(run_to_end(each_job(c_p0.fields, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
        return entered(once_job([=]() {
            return ({
                auto&& _ft_p1 = p0;
                auto&& ft_p1 = std::get<1>(_ft_p1);
                (prism_rtl::more(prism_rtl::rc(crate::emit::rust::Type(ft_p1))));
            });
        }));
    })))), Text::lit(", ")), "),");
}


prism_rtl::Turn<Text> EnumCase::cycle() const {
    const auto& c_p0 = this->c_p0;
    return len(prism_rtl::deref(c_p0).fields) == Nat(0u)
        ? prism_rtl::finished(prism_rtl::cat(prism_rtl::deref(c_p0).name, ","))
        : ({
        auto c_p0_1 = c_p0;
        call_value(each_job(prism_rtl::deref(c_p0_1).fields, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
        return entered(once_job([=]() {
            return ({
                auto&& _ft_p1 = p0;
                auto&& ft_p1 = std::get<1>(_ft_p1);
                (prism_rtl::more(prism_rtl::rc(crate::emit::rust::Type(ft_p1))));
            });
        }));
    }))), [=](Array<Text> each_5886) { return prism_rtl::finished(prism_rtl::cat(prism_rtl::deref(c_p0_1).name, "(", crate::syntax::lexer::chars::join(each_5886, Text::lit(", ")), "),")); });
    });
}


/// `Start EnumCase, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_enum_case(crate::lower::model::CaseDef c_p0) {
    return prism_rtl::make_rc<EnumCase>(c_p0);
}


/// Binders: fn Nat -> [Text]
Array<Text> binders(const Nat& n_p0) {
    return each(crate::check::errors::range0(n_p0), [&](const Nat& i_p1) { return prism_rtl::cat("a", i_p1); });
}


/// CasePattern: fn TyDef, CaseDef -> Text
Text case_pattern(const crate::lower::model::TyDef& t_p0, const crate::lower::model::CaseDef& c_p1) {
    auto&& _m = t_p0.shape;
    if (prism_rtl::is<crate::lower::model::TyShape::ShapeNewtype>(_m)) {
        return prism_rtl::cat(t_p0.name, "(", crate::syntax::lexer::chars::join(binders(len(c_p1.fields)), Text::lit(", ")), ")");
    }
    if (prism_rtl::is<crate::lower::model::TyShape::ShapeUnit>(_m)) {
        return t_p0.name;
    }
    {
        return len(c_p1.fields) == Nat(0u)
            ? prism_rtl::cat(t_p0.name, "::", c_p1.name)
            : prism_rtl::cat(t_p0.name, "::", c_p1.name, "(", crate::syntax::lexer::chars::join(binders(len(c_p1.fields)), Text::lit(", ")), ")");
    }
}


/// ShowImpl: unbounded fn TyDef, Text -> Text
Text show_impl(const crate::lower::model::TyDef& t_p0, const Text& head_p1) {
    auto body_p2 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = t_p0.shape;
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeRecord>(_m)) {
            _v.set(({
                auto c_p3 = or_(index(t_p0.cases_, Nat(0u)), crate::lower::model::CaseDef{.name = Text::lit(""), .prism = Text::lit(""), .fields = Array<std::tuple<Text, crate::lower::model::OutTy>>{}});
                (prism_rtl::cat("p.record(\"", t_p0.prism, "\", &[", crate::syntax::lexer::chars::join(each(prism_rtl::deref(c_p3).fields, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
                auto&& f_p4 = std::get<0>(_p0);
                return prism_rtl::cat("(\"", prism_field(f_p4), "\", &self.", f_p4, ")");
            }), Text::lit(", ")), "]);"));
            }));
            goto _done;
        }
        {
            _v.set(crate::emit::rust::templates::items::match_self(crate::syntax::lexer::chars::join(each(t_p0.cases_, [&](const crate::lower::model::CaseDef& c_p5) { return prism_rtl::cat(case_pattern(t_p0, c_p5), " => p.choice(\"", prism_rtl::deref(c_p5).prism, "\", &[", crate::syntax::lexer::chars::join(binders(len(prism_rtl::deref(c_p5).fields)), Text::lit(", ")), "]),"); }), Text::lit("\n"))));
            goto _done;
        }
    _done:
        _v.take();
    });
    return crate::emit::rust::templates::items::impl_(bounded(t_p0.params, Text::lit("Show")), Text::lit("Show"), head_p1, Text::lit("fn show(&self, p: &mut Printer)"), body_p2);
}


prism_rtl::Turn<Text> ShowImpl::cycle() const {
    const auto& t_p0 = this->t_p0;
    const auto& head_p1 = this->head_p1;
    auto body_p2 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = prism_rtl::deref(t_p0).shape;
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeRecord>(_m)) {
            _v.set(({
                auto c_p3 = or_(index(prism_rtl::deref(t_p0).cases_, Nat(0u)), crate::lower::model::CaseDef{.name = Text::lit(""), .prism = Text::lit(""), .fields = Array<std::tuple<Text, crate::lower::model::OutTy>>{}});
                (prism_rtl::cat("p.record(\"", prism_rtl::deref(t_p0).prism, "\", &[", crate::syntax::lexer::chars::join(each(prism_rtl::deref(c_p3).fields, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
                auto&& f_p4 = std::get<0>(_p0);
                return prism_rtl::cat("(\"", prism_field(f_p4), "\", &self.", f_p4, ")");
            }), Text::lit(", ")), "]);"));
            }));
            goto _done;
        }
        {
            _v.set(crate::emit::rust::templates::items::match_self(crate::syntax::lexer::chars::join(each(prism_rtl::deref(t_p0).cases_, [&](const crate::lower::model::CaseDef& c_p5) { return prism_rtl::cat(case_pattern(t_p0, c_p5), " => p.choice(\"", prism_rtl::deref(c_p5).prism, "\", &[", crate::syntax::lexer::chars::join(binders(len(prism_rtl::deref(c_p5).fields)), Text::lit(", ")), "]),"); }), Text::lit("\n"))));
            goto _done;
        }
    _done:
        _v.take();
    });
    return prism_rtl::finished(crate::emit::rust::templates::items::impl_(bounded(prism_rtl::deref(t_p0).params, Text::lit("Show")), Text::lit("Show"), head_p1, Text::lit("fn show(&self, p: &mut Printer)"), body_p2));
}


/// `Start ShowImpl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_show_impl(crate::lower::model::TyDef t_p0, Text head_p1) {
    return prism_rtl::make_rc<ShowImpl>(t_p0, head_p1);
}


/// PrismField: fn Text -> Text
Text prism_field(const Text& f_p0) {
    return crate::syntax::lexer::chars::last_char(f_p0) == Text::lit("_")
        ? crate::syntax::lexer::chars::before_last(f_p0)
        : f_p0;
}


/// ToPodImpl: unbounded fn TyDef, Text -> Text
Text to_pod_impl(const crate::lower::model::TyDef& t_p0, const Text& head_p1) {
    auto body_p2 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = t_p0.shape;
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeRecord>(_m)) {
            _v.set(({
                auto c_p4 = or_(index(t_p0.cases_, Nat(0u)), crate::lower::model::CaseDef{.name = Text::lit(""), .prism = Text::lit(""), .fields = Array<std::tuple<Text, crate::lower::model::OutTy>>{}});
                (prism_rtl::cat("Pod::record(\"", t_p0.prism, "\", vec![", crate::syntax::lexer::chars::join(each(prism_rtl::deref(c_p4).fields, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
                auto&& f_p5 = std::get<0>(_p0);
                return prism_rtl::cat("(\"", prism_field(f_p5), "\", self.", f_p5, ".to_pod())");
            }), Text::lit(", ")), "])"));
            }));
            goto _done;
        }
        {
            _v.set(crate::emit::rust::templates::items::match_self(crate::syntax::lexer::chars::join(each(t_p0.cases_, [&](const crate::lower::model::CaseDef& c_p6) { return prism_rtl::cat(case_pattern(t_p0, c_p6), " => Pod::Choice(\"", prism_rtl::deref(c_p6).prism, "\".into(), vec![", crate::syntax::lexer::chars::join(each(binders(len(prism_rtl::deref(c_p6).fields)), [&](const Text& b_p7) { return prism_rtl::cat(b_p7, ".to_pod()"); }), Text::lit(", ")), "]),"); }), Text::lit("\n"))));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto shown_p3 = t_p0.show_ == crate::lower::model::Shown(crate::lower::model::Shown::ShownOwn{})
        ? crate::emit::rust::templates::items::shown_pod(body_p2)
        : body_p2;
    return crate::emit::rust::templates::items::impl_(bounded(t_p0.params, Text::lit("ToPod")), Text::lit("ToPod"), head_p1, Text::lit("fn to_pod(&self) -> Pod"), shown_p3);
}


prism_rtl::Turn<Text> ToPodImpl::cycle() const {
    const auto& t_p0 = this->t_p0;
    const auto& head_p1 = this->head_p1;
    auto body_p2 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = prism_rtl::deref(t_p0).shape;
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeRecord>(_m)) {
            _v.set(({
                auto c_p4 = or_(index(prism_rtl::deref(t_p0).cases_, Nat(0u)), crate::lower::model::CaseDef{.name = Text::lit(""), .prism = Text::lit(""), .fields = Array<std::tuple<Text, crate::lower::model::OutTy>>{}});
                (prism_rtl::cat("Pod::record(\"", prism_rtl::deref(t_p0).prism, "\", vec![", crate::syntax::lexer::chars::join(each(prism_rtl::deref(c_p4).fields, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
                auto&& f_p5 = std::get<0>(_p0);
                return prism_rtl::cat("(\"", prism_field(f_p5), "\", self.", f_p5, ".to_pod())");
            }), Text::lit(", ")), "])"));
            }));
            goto _done;
        }
        {
            _v.set(crate::emit::rust::templates::items::match_self(crate::syntax::lexer::chars::join(each(prism_rtl::deref(t_p0).cases_, [&](const crate::lower::model::CaseDef& c_p6) { return prism_rtl::cat(case_pattern(t_p0, c_p6), " => Pod::Choice(\"", prism_rtl::deref(c_p6).prism, "\".into(), vec![", crate::syntax::lexer::chars::join(each(binders(len(prism_rtl::deref(c_p6).fields)), [&](const Text& b_p7) { return prism_rtl::cat(b_p7, ".to_pod()"); }), Text::lit(", ")), "]),"); }), Text::lit("\n"))));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto shown_p3 = prism_rtl::deref(t_p0).show_ == crate::lower::model::Shown(crate::lower::model::Shown::ShownOwn{})
        ? crate::emit::rust::templates::items::shown_pod(body_p2)
        : body_p2;
    return prism_rtl::finished(crate::emit::rust::templates::items::impl_(bounded(prism_rtl::deref(t_p0).params, Text::lit("ToPod")), Text::lit("ToPod"), head_p1, Text::lit("fn to_pod(&self) -> Pod"), shown_p3));
}


/// `Start ToPodImpl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_to_pod_impl(crate::lower::model::TyDef t_p0, Text head_p1) {
    return prism_rtl::make_rc<ToPodImpl>(t_p0, head_p1);
}


/// FromPodImpl: unbounded fn TyDef, Text -> Text
Text from_pod_impl(const crate::lower::model::TyDef& t_p0, const Text& head_p1) {
    auto body_p2 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = t_p0.shape;
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeRecord>(_m)) {
            _v.set(({
                auto c_p3 = or_(index(t_p0.cases_, Nat(0u)), crate::lower::model::CaseDef{.name = Text::lit(""), .prism = Text::lit(""), .fields = Array<std::tuple<Text, crate::lower::model::OutTy>>{}});
                (prism_rtl::cat("Ok(", t_p0.name, " { ", crate::syntax::lexer::chars::join(each(prism_rtl::deref(c_p3).fields, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
                auto&& f_p4 = std::get<0>(_p0);
                return prism_rtl::cat(f_p4, ": FromPod::from_pod(field(p, \"", prism_field(f_p4), "\")?)?");
            }), Text::lit(", ")), " })"));
            }));
            goto _done;
        }
        {
            _v.set(({
                auto arms_p5 = each(t_p0.cases_, [&](const crate::lower::model::CaseDef& c_p6) {
                    return ({
                        auto n_p7 = len(prism_rtl::deref(c_p6).fields);
                        auto made_p8 = n_p7 == Nat(0u)
                            ? t_p0.shape == crate::lower::model::TyShape(crate::lower::model::TyShape::ShapeUnit{})
                            ? t_p0.name
                            : prism_rtl::cat(t_p0.name, "::", prism_rtl::deref(c_p6).name)
                            : prism_rtl::cat(t_p0.shape == crate::lower::model::TyShape(crate::lower::model::TyShape::ShapeNewtype{})
                            ? t_p0.name
                            : prism_rtl::cat(t_p0.name, "::", prism_rtl::deref(c_p6).name), "(", crate::syntax::lexer::chars::join(each(crate::check::errors::range0(n_p7), [&](const Nat& i_p9) { return prism_rtl::cat("FromPod::from_pod(&a[", i_p9, "])?"); }), Text::lit(", ")), ")");
                        (prism_rtl::cat("Pod::Choice(c, a) if &**c == \"", prism_rtl::deref(c_p6).prism, "\" && a.len() == ", n_p7, " => Ok(", made_p8, "),"));
                    });
                });
                (crate::emit::rust::templates::items::from_pod_body(crate::syntax::lexer::chars::join(arms_p5, Text::lit("\n")), prism_rtl::cat("a ", t_p0.prism)));
            }));
            goto _done;
        }
    _done:
        _v.take();
    });
    return crate::emit::rust::templates::items::impl_(bounded(t_p0.params, Text::lit("FromPod")), Text::lit("FromPod"), head_p1, Text::lit("fn from_pod(p: &Pod) -> Result<Self, Fault>"), body_p2);
}


prism_rtl::Turn<Text> FromPodImpl::cycle() const {
    const auto& t_p0 = this->t_p0;
    const auto& head_p1 = this->head_p1;
    auto body_p2 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = prism_rtl::deref(t_p0).shape;
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeRecord>(_m)) {
            _v.set(({
                auto c_p3 = or_(index(prism_rtl::deref(t_p0).cases_, Nat(0u)), crate::lower::model::CaseDef{.name = Text::lit(""), .prism = Text::lit(""), .fields = Array<std::tuple<Text, crate::lower::model::OutTy>>{}});
                (prism_rtl::cat("Ok(", prism_rtl::deref(t_p0).name, " { ", crate::syntax::lexer::chars::join(each(prism_rtl::deref(c_p3).fields, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
                auto&& f_p4 = std::get<0>(_p0);
                return prism_rtl::cat(f_p4, ": FromPod::from_pod(field(p, \"", prism_field(f_p4), "\")?)?");
            }), Text::lit(", ")), " })"));
            }));
            goto _done;
        }
        {
            _v.set(({
                auto arms_p5 = each(prism_rtl::deref(t_p0).cases_, [&](const crate::lower::model::CaseDef& c_p6) {
                    return ({
                        auto n_p7 = len(prism_rtl::deref(c_p6).fields);
                        auto made_p8 = n_p7 == Nat(0u)
                            ? prism_rtl::deref(t_p0).shape == crate::lower::model::TyShape(crate::lower::model::TyShape::ShapeUnit{})
                            ? prism_rtl::deref(t_p0).name
                            : prism_rtl::cat(prism_rtl::deref(t_p0).name, "::", prism_rtl::deref(c_p6).name)
                            : prism_rtl::cat(prism_rtl::deref(t_p0).shape == crate::lower::model::TyShape(crate::lower::model::TyShape::ShapeNewtype{})
                            ? prism_rtl::deref(t_p0).name
                            : prism_rtl::cat(prism_rtl::deref(t_p0).name, "::", prism_rtl::deref(c_p6).name), "(", crate::syntax::lexer::chars::join(each(crate::check::errors::range0(n_p7), [&](const Nat& i_p9) { return prism_rtl::cat("FromPod::from_pod(&a[", i_p9, "])?"); }), Text::lit(", ")), ")");
                        (prism_rtl::cat("Pod::Choice(c, a) if &**c == \"", prism_rtl::deref(c_p6).prism, "\" && a.len() == ", n_p7, " => Ok(", made_p8, "),"));
                    });
                });
                (crate::emit::rust::templates::items::from_pod_body(crate::syntax::lexer::chars::join(arms_p5, Text::lit("\n")), prism_rtl::cat("a ", prism_rtl::deref(t_p0).prism)));
            }));
            goto _done;
        }
    _done:
        _v.take();
    });
    return prism_rtl::finished(crate::emit::rust::templates::items::impl_(bounded(prism_rtl::deref(t_p0).params, Text::lit("FromPod")), Text::lit("FromPod"), head_p1, Text::lit("fn from_pod(p: &Pod) -> Result<Self, Fault>"), body_p2));
}


/// `Start FromPodImpl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_from_pod_impl(crate::lower::model::TyDef t_p0, Text head_p1) {
    return prism_rtl::make_rc<FromPodImpl>(t_p0, head_p1);
}


/// RustTag: unbounded fn TagDef -> Text
Text rust_tag(const crate::lower::model::TagDef& t_p0) {
    auto fields_p1 = crate::syntax::lexer::chars::join(run_to_end(each_job(t_p0.fields, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, Text, crate::lower::model::OutTy> p0) {
        return entered(once_job([=]() {
            return ({
                auto&& _f_pa = p0;
                auto&& f_pa = std::get<1>(_f_pa);
                auto&& ft_pb = std::get<2>(_f_pa);
                call_then(crate::emit::rust::start_type_(ft_pb), [=](Text type__8893) { return prism_rtl::finished(prism_rtl::cat("pub ", f_pa, ": ", type__8893, ",")); });
            });
        }));
    })))), Text::lit("\n"));
    auto pods_p2 = crate::syntax::lexer::chars::join(each(t_p0.fields, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
        auto&& p_pc = std::get<0>(_p0);
        auto&& f_pd = std::get<1>(_p0);
        return prism_rtl::cat("(\"", p_pc, "\", self.", f_pd, ".to_pod())");
    }), Text::lit(", "));
    auto derives_p3 = t_p0.eq ? Text::lit("Clone, PartialEq, Eq") : Text::lit("Clone");
    auto reads_p4 = crate::syntax::lexer::chars::join(each(t_p0.fields, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
        auto&& p_pe = std::get<0>(_p0);
        auto&& f_pf = std::get<1>(_p0);
        return prism_rtl::cat(f_pf, ": FromPod::from_pod(field(p, \"", p_pe, "\")?)?");
    }), Text::lit(", "));
    auto back_p5 = t_p0.pod
        ? prism_rtl::cat("\n", crate::emit::rust::templates::items::tag_from_pod(t_p0.name, t_p0.tag_name, reads_p4))
        : Text::lit("");
    auto deep_p6 = run_to_end(fold_job(t_p0.fields, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, Text, crate::lower::model::OutTy>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<Text, Text, crate::lower::model::OutTy>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto d_pg = p0;
                auto&& _ft_ph = p1;
                auto&& ft_ph = std::get<2>(_ft_ph);
                (prism_rtl::finished(std::move(d_pg) || crate::lower::types::holds_dyn(ft_ph)));
            });
        }));
    }))));
    auto deep_pods_p7 = crate::syntax::lexer::chars::join(run_to_end(each_job(t_p0.fields, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, Text, crate::lower::model::OutTy> p0) {
        return entered(once_job([=]() {
            return ({
                auto [p_pi, f_pj, ft_pk] = p0;
                (prism_rtl::more(prism_rtl::rc(DeepField(p_pi, f_pj, ft_pk))));
            });
        }));
    })))), Text::lit(", "));
    auto deep_ports_p8 = concat(run_to_end(each_job(t_p0.fields, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, Text, crate::lower::model::OutTy> p0) {
        return entered(once_job([=]() {
            return ({
                auto&& _f_pl = p0;
                auto&& f_pl = std::get<1>(_f_pl);
                auto&& ft_pm = std::get<2>(_f_pl);
                (prism_rtl::more(prism_rtl::rc(DeepPorts(f_pl, ft_pm))));
            });
        }));
    })))));
    auto levels_p9 = std::move(deep_p6)
        ? prism_rtl::cat("\n", crate::emit::rust::templates::items::tag_level(t_p0.name, t_p0.tag_name, deep_pods_p7, deep_ports_p8))
        : Text::lit("");
    return prism_rtl::cat(crate::emit::rust::templates::items::tag(crate::emit::rust::templates::source_doc(prism_rtl::cat("The `Level` of `", t_p0.tag_name, "`:"), t_p0.doc), derives_p3, t_p0.name, fields_p1, t_p0.tag_name, pods_p2), back_p5, levels_p9);
}


prism_rtl::Turn<Text> RustTag::cycle() const {
    const auto& t_p0 = this->t_p0;
    auto t_p0_1 = t_p0;
    return call_value(each_job(prism_rtl::deref(t_p0_1).fields, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, Text, crate::lower::model::OutTy> p0) {
        return entered(once_job([=]() {
            return ({
                auto&& _f_pa = p0;
                auto&& f_pa = std::get<1>(_f_pa);
                auto&& ft_pb = std::get<2>(_f_pa);
                call_then(crate::emit::rust::start_type_(ft_pb), [=](Text type__8893) { return prism_rtl::finished(prism_rtl::cat("pub ", f_pa, ": ", type__8893, ",")); });
            });
        }));
    }))), [=](Array<Text> each_8846) {
        return ({
            auto fields_p1 = crate::syntax::lexer::chars::join(each_8846, Text::lit("\n"));
            auto pods_p2 = crate::syntax::lexer::chars::join(each(prism_rtl::deref(t_p0_1).fields, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
                auto&& p_pc = std::get<0>(_p0);
                auto&& f_pd = std::get<1>(_p0);
                return prism_rtl::cat("(\"", p_pc, "\", self.", f_pd, ".to_pod())");
            }), Text::lit(", "));
            auto derives_p3 = prism_rtl::deref(t_p0_1).eq
                ? Text::lit("Clone, PartialEq, Eq")
                : Text::lit("Clone");
            auto reads_p4 = crate::syntax::lexer::chars::join(each(prism_rtl::deref(t_p0_1).fields, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
                auto&& p_pe = std::get<0>(_p0);
                auto&& f_pf = std::get<1>(_p0);
                return prism_rtl::cat(f_pf, ": FromPod::from_pod(field(p, \"", p_pe, "\")?)?");
            }), Text::lit(", "));
            auto back_p5 = prism_rtl::deref(t_p0_1).pod
                ? prism_rtl::cat("\n", crate::emit::rust::templates::items::tag_from_pod(prism_rtl::deref(t_p0_1).name, prism_rtl::deref(t_p0_1).tag_name, reads_p4))
                : Text::lit("");
            call_value(fold_job(prism_rtl::deref(t_p0_1).fields, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, Text, crate::lower::model::OutTy>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<Text, Text, crate::lower::model::OutTy>> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto d_pg = p0;
                    auto&& _ft_ph = p1;
                    auto&& ft_ph = std::get<2>(_ft_ph);
                    (prism_rtl::finished(std::move(d_pg) || crate::lower::types::holds_dyn(ft_ph)));
                });
            }));
        }))), [=, fields_p1 = std::move(fields_p1), pods_p2 = std::move(pods_p2), derives_p3 = std::move(derives_p3), back_p5 = std::move(back_p5)](bool fold_9270) {
            return ({
                auto deep_p6 = fold_9270;
                call_value(each_job(prism_rtl::deref(t_p0_1).fields, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, Text, crate::lower::model::OutTy> p0) {
                return entered(once_job([=]() {
                    return ({
                        auto [p_pi, f_pj, ft_pk] = p0;
                        (prism_rtl::more(prism_rtl::rc(DeepField(p_pi, f_pj, ft_pk))));
                    });
                }));
            }))), [=, deep_p6 = std::move(deep_p6)](Array<Text> each_9363) {
                return ({
                    auto deep_pods_p7 = crate::syntax::lexer::chars::join(each_9363, Text::lit(", "));
                    call_value(each_job(prism_rtl::deref(t_p0_1).fields, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, Text, crate::lower::model::OutTy> p0) {
                    return entered(once_job([=]() {
                        return ({
                            auto&& _f_pl = p0;
                            auto&& f_pl = std::get<1>(_f_pl);
                            auto&& ft_pm = std::get<2>(_f_pl);
                            (prism_rtl::more(prism_rtl::rc(DeepPorts(f_pl, ft_pm))));
                        });
                    }));
                }))), [=, deep_pods_p7 = std::move(deep_pods_p7)](Array<Text> each_9448) {
                    return ({
                        auto deep_ports_p8 = concat(each_9448);
                        auto levels_p9 = deep_p6
                            ? prism_rtl::cat("\n", crate::emit::rust::templates::items::tag_level(prism_rtl::deref(t_p0_1).name, prism_rtl::deref(t_p0_1).tag_name, deep_pods_p7, deep_ports_p8))
                            : Text::lit("");
                        (prism_rtl::finished(prism_rtl::cat(crate::emit::rust::templates::items::tag(crate::emit::rust::templates::source_doc(prism_rtl::cat("The `Level` of `", prism_rtl::deref(t_p0_1).tag_name, "`:"), prism_rtl::deref(t_p0_1).doc), derives_p3, prism_rtl::deref(t_p0_1).name, fields_p1, prism_rtl::deref(t_p0_1).tag_name, pods_p2), back_p5, levels_p9)));
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start RustTag, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_rust_tag(crate::lower::model::TagDef t_p0) {
    return prism_rtl::make_rc<RustTag>(t_p0);
}


/// DeepField: unbounded fn Text, Text, OutTy -> Text
Text deep_field(const Text& p_p0, const Text& f_p1, const crate::lower::model::OutTy& ft_p2) {
    return prism_rtl::cat("(\"", p_p0, "\", ", deep_pod(f_p1, ft_p2), ")");
}


prism_rtl::Turn<Text> DeepField::cycle() const {
    const auto& p_p0 = this->p_p0;
    const auto& f_p1 = this->f_p1;
    const auto& ft_p2 = this->ft_p2;
    auto f_p1_1 = f_p1;
    auto ft_p2_2 = ft_p2;
    auto p_p0_3 = p_p0;
    return call_then(start_deep_pod(f_p1_1, ft_p2_2), [=](Text deep_pod_9796) { return prism_rtl::finished(prism_rtl::cat("(\"", p_p0_3, "\", ", deep_pod_9796, ")")); });
}


/// `Start DeepField, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_deep_field(Text p_p0, Text f_p1, crate::lower::model::OutTy ft_p2) {
    return prism_rtl::make_rc<DeepField>(p_p0, f_p1, ft_p2);
}


/// DeepPod: unbounded fn Text, OutTy -> Text
Text deep_pod(const Text& f_p0, const crate::lower::model::OutTy& ft_p1) {
    if (prism_rtl::is<crate::lower::model::OutTy::OutMap>(ft_p1)) {
        auto&& m10050_0_1 = prism_rtl::as<crate::lower::model::OutTy::OutMap>(ft_p1).a1;
        if (prism_rtl::is<crate::lower::model::OutTy::OutDyn>(prism_rtl::deref(prism_rtl::deref(m10050_0_1)))) {
            auto&& m10050_0_1_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(prism_rtl::deref(prism_rtl::deref(m10050_0_1))).a0;
            if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(prism_rtl::deref(prism_rtl::deref(m10050_0_1_r_0)))) {
                auto&& m10050_0_1_r_0_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(prism_rtl::deref(prism_rtl::deref(m10050_0_1_r_0))).a0;
                if (m10050_0_1_r_0_r_0 == Text::lit("crate::Elem")) {
                    return prism_rtl::cat("prism_rtl::dynamics_pod(&self.", f_p0, ", cx)");
                }
            }
        }
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutDyn>(ft_p1)) {
        auto&& m10050_1_0 = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(ft_p1).a0;
        if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(prism_rtl::deref(prism_rtl::deref(m10050_1_0)))) {
            auto&& m10050_1_0_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(prism_rtl::deref(prism_rtl::deref(m10050_1_0))).a0;
            if (m10050_1_0_r_0 == Text::lit("crate::Elem")) {
                return prism_rtl::cat("prism_rtl::Level::level_pod(&self.", f_p0, ".sample(cx), cx)");
            }
        }
    }
    {
        auto&& other_p2 = ft_p1;
        return crate::lower::types::holds_dyn(other_p2)
            ? Text::lit("compile_error!(\"prismc: a tag field holding a dynamic other than `$Elem` or a map of them is not read deep (claude/incremental-host-document.md, doubt WD)\")")
            : prism_rtl::cat("self.", f_p0, ".to_pod()");
    }
}


prism_rtl::Turn<Text> DeepPod::cycle() const {
    const auto& f_p0 = this->f_p0;
    const auto& ft_p1 = this->ft_p1;
    return ({
        prism_rtl::is<crate::lower::model::OutTy::OutMap>(ft_p1) && ({
        auto&& m10050_0_1 = prism_rtl::as<crate::lower::model::OutTy::OutMap>(ft_p1).a1;
        prism_rtl::is<crate::lower::model::OutTy::OutDyn>(prism_rtl::deref(prism_rtl::deref(m10050_0_1))) && ({
        auto&& m10050_0_1_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(prism_rtl::deref(prism_rtl::deref(m10050_0_1))).a0;
        prism_rtl::is<crate::lower::model::OutTy::OutNamed>(prism_rtl::deref(prism_rtl::deref(m10050_0_1_r_0))) && ({
        auto&& m10050_0_1_r_0_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(prism_rtl::deref(prism_rtl::deref(m10050_0_1_r_0))).a0;
        (m10050_0_1_r_0_r_0 == Text::lit("crate::Elem"));
    });
    });
    }) ? ({
        auto&& m10050_0_1 = prism_rtl::as<crate::lower::model::OutTy::OutMap>(ft_p1).a1;
        auto&& m10050_0_1_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(prism_rtl::deref(prism_rtl::deref(m10050_0_1))).a0;
        auto&& m10050_0_1_r_0_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(prism_rtl::deref(prism_rtl::deref(m10050_0_1_r_0))).a0;
        prism_rtl::finished(prism_rtl::cat("prism_rtl::dynamics_pod(&self.", f_p0, ", cx)"));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutDyn>(ft_p1) && ({
        auto&& m10050_1_0 = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(ft_p1).a0;
        prism_rtl::is<crate::lower::model::OutTy::OutNamed>(prism_rtl::deref(prism_rtl::deref(m10050_1_0))) && ({
        auto&& m10050_1_0_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(prism_rtl::deref(prism_rtl::deref(m10050_1_0))).a0;
        (m10050_1_0_r_0 == Text::lit("crate::Elem"));
    });
    }) ? ({
        auto&& m10050_1_0 = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(ft_p1).a0;
        auto&& m10050_1_0_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(prism_rtl::deref(prism_rtl::deref(m10050_1_0))).a0;
        prism_rtl::finished(prism_rtl::cat("prism_rtl::Level::level_pod(&self.", f_p0, ".sample(cx), cx)"));
    })
        : ({
        auto&& other_p2 = ft_p1;
        ({
        auto f_p0_1 = f_p0;
        auto other_p2_2 = other_p2;
        call_then(crate::lower::types::start_holds_dyn(other_p2_2), [=, f_p0_1 = std::move(f_p0_1)](bool holds_dyn_10278) {
        return holds_dyn_10278
            ? prism_rtl::finished(Text::lit("compile_error!(\"prismc: a tag field holding a dynamic other than `$Elem` or a map of them is not read deep (claude/incremental-host-document.md, doubt WD)\")"))
            : prism_rtl::finished(prism_rtl::cat("self.", f_p0_1, ".to_pod()"));
    });
    });
    });
    });
}


/// `Start DeepPod, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_deep_pod(Text f_p0, crate::lower::model::OutTy ft_p1) {
    return prism_rtl::make_rc<DeepPod>(f_p0, ft_p1);
}


/// DeepPorts: unbounded fn Text, OutTy -> Text
Text deep_ports(const Text& f_p0, const crate::lower::model::OutTy& ft_p1) {
    if (prism_rtl::is<crate::lower::model::OutTy::OutMap>(ft_p1)) {
        auto&& m10547_0_1 = prism_rtl::as<crate::lower::model::OutTy::OutMap>(ft_p1).a1;
        if (prism_rtl::is<crate::lower::model::OutTy::OutDyn>(prism_rtl::deref(prism_rtl::deref(m10547_0_1)))) {
            auto&& m10547_0_1_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(prism_rtl::deref(prism_rtl::deref(m10547_0_1))).a0;
            if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(prism_rtl::deref(prism_rtl::deref(m10547_0_1_r_0)))) {
                auto&& m10547_0_1_r_0_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(prism_rtl::deref(prism_rtl::deref(m10547_0_1_r_0))).a0;
                if (m10547_0_1_r_0_r_0 == Text::lit("crate::Elem")) {
                    return prism_rtl::cat("\n        prism_rtl::dynamics_ports(&self.", f_p0, ", cx, out);");
                }
            }
        }
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutDyn>(ft_p1)) {
        auto&& m10547_1_0 = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(ft_p1).a0;
        if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(prism_rtl::deref(prism_rtl::deref(m10547_1_0)))) {
            auto&& m10547_1_0_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(prism_rtl::deref(prism_rtl::deref(m10547_1_0))).a0;
            if (m10547_1_0_r_0 == Text::lit("crate::Elem")) {
                return prism_rtl::cat("\n        out.push(self.", f_p0, ".updates.clone());\n        prism_rtl::Level::level_ports(&self.", f_p0, ".sample(cx), cx, out);");
            }
        }
    }
    {
        return Text::lit("");
    }
}


prism_rtl::Turn<Text> DeepPorts::cycle() const {
    const auto& f_p0 = this->f_p0;
    const auto& ft_p1 = this->ft_p1;
    return ({
        prism_rtl::is<crate::lower::model::OutTy::OutMap>(ft_p1) && ({
        auto&& m10547_0_1 = prism_rtl::as<crate::lower::model::OutTy::OutMap>(ft_p1).a1;
        prism_rtl::is<crate::lower::model::OutTy::OutDyn>(prism_rtl::deref(prism_rtl::deref(m10547_0_1))) && ({
        auto&& m10547_0_1_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(prism_rtl::deref(prism_rtl::deref(m10547_0_1))).a0;
        prism_rtl::is<crate::lower::model::OutTy::OutNamed>(prism_rtl::deref(prism_rtl::deref(m10547_0_1_r_0))) && ({
        auto&& m10547_0_1_r_0_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(prism_rtl::deref(prism_rtl::deref(m10547_0_1_r_0))).a0;
        (m10547_0_1_r_0_r_0 == Text::lit("crate::Elem"));
    });
    });
    }) ? ({
        auto&& m10547_0_1 = prism_rtl::as<crate::lower::model::OutTy::OutMap>(ft_p1).a1;
        auto&& m10547_0_1_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(prism_rtl::deref(prism_rtl::deref(m10547_0_1))).a0;
        auto&& m10547_0_1_r_0_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(prism_rtl::deref(prism_rtl::deref(m10547_0_1_r_0))).a0;
        prism_rtl::finished(prism_rtl::cat("\n        prism_rtl::dynamics_ports(&self.", f_p0, ", cx, out);"));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutDyn>(ft_p1) && ({
        auto&& m10547_1_0 = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(ft_p1).a0;
        prism_rtl::is<crate::lower::model::OutTy::OutNamed>(prism_rtl::deref(prism_rtl::deref(m10547_1_0))) && ({
        auto&& m10547_1_0_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(prism_rtl::deref(prism_rtl::deref(m10547_1_0))).a0;
        (m10547_1_0_r_0 == Text::lit("crate::Elem"));
    });
    }) ? ({
        auto&& m10547_1_0 = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(ft_p1).a0;
        auto&& m10547_1_0_r_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(prism_rtl::deref(prism_rtl::deref(m10547_1_0))).a0;
        prism_rtl::finished(prism_rtl::cat("\n        out.push(self.", f_p0, ".updates.clone());\n        prism_rtl::Level::level_ports(&self.", f_p0, ".sample(cx), cx, out);"));
    })
        : prism_rtl::finished(Text::lit(""));
    });
}


/// `Start DeepPorts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_deep_ports(Text f_p0, crate::lower::model::OutTy ft_p1) {
    return prism_rtl::make_rc<DeepPorts>(f_p0, ft_p1);
}


/// RustRow: unbounded fn RowDef -> Text
Text rust_row(const crate::lower::model::RowDef& r_p0) {
    auto derives_p1 = r_p0.eq ? Text::lit("Clone, PartialEq, Eq") : Text::lit("Clone");
    auto cases_p2 = crate::syntax::lexer::chars::join(each(r_p0.cases_, [&](const std::tuple<Text, Text>& _p0) {
        auto&& v_pa = std::get<0>(_p0);
        auto&& st_pb = std::get<1>(_p0);
        return prism_rtl::cat(v_pa, "(", st_pb, "),");
    }), Text::lit("\n"));
    auto pods_p3 = crate::syntax::lexer::chars::join(each(r_p0.cases_, [&](const std::tuple<Text, Text>& _p0) {
        auto&& v_pc = std::get<0>(_p0);
        return prism_rtl::cat(r_p0.name, "::", v_pc, "(x) => x.to_pod(),");
    }), Text::lit("\n"));
    auto reads_p4 = crate::syntax::lexer::chars::join(each(r_p0.cases_, [&](const std::tuple<Text, Text>& _p0) {
        auto&& v_pd = std::get<0>(_p0);
        auto&& st_pe = std::get<1>(_p0);
        return prism_rtl::cat("Some(t) if t == ", st_pe, "::TAG => Ok(", r_p0.name, "::", v_pd, "(FromPod::from_pod(p)?)),");
    }), Text::lit("\n"));
    auto back_p5 = r_p0.pod
        ? prism_rtl::cat("\n", crate::emit::rust::templates::items::row_from_pod(r_p0.name, reads_p4))
        : Text::lit("");
    auto pods2_p6 = len(r_p0.cases_) == Nat(0u) ? Text::lit("_ => unreachable!(),") : pods_p3;
    auto deep_pods_p7 = concat(each(r_p0.deep, [&](const Text& v_pf) { return prism_rtl::cat(r_p0.name, "::", v_pf, "(x) => x.level_pod(cx),\n            "); }));
    auto deep_ports_p8 = concat(each(r_p0.deep, [&](const Text& v_pg) { return prism_rtl::cat(r_p0.name, "::", v_pg, "(x) => x.level_ports(cx, out),\n            "); }));
    auto level_p9 = r_p0.level
        ? prism_rtl::cat("\n", crate::emit::rust::templates::items::row_level(r_p0.name, deep_pods_p7, deep_ports_p8))
        : Text::lit("");
    return prism_rtl::cat(crate::emit::rust::templates::items::row(crate::emit::rust::templates::source_doc(prism_rtl::cat("`", r_p0.prism, "`, a row kind\'s values:"), r_p0.doc), derives_p1, r_p0.name, cases_p2, pods2_p6), back_p5, level_p9);
}


prism_rtl::Turn<Text> RustRow::cycle() const {
    const auto& r_p0 = this->r_p0;
    auto derives_p1 = prism_rtl::deref(r_p0).eq
        ? Text::lit("Clone, PartialEq, Eq")
        : Text::lit("Clone");
    auto cases_p2 = crate::syntax::lexer::chars::join(each(prism_rtl::deref(r_p0).cases_, [&](const std::tuple<Text, Text>& _p0) {
        auto&& v_pa = std::get<0>(_p0);
        auto&& st_pb = std::get<1>(_p0);
        return prism_rtl::cat(v_pa, "(", st_pb, "),");
    }), Text::lit("\n"));
    auto pods_p3 = crate::syntax::lexer::chars::join(each(prism_rtl::deref(r_p0).cases_, [&](const std::tuple<Text, Text>& _p0) {
        auto&& v_pc = std::get<0>(_p0);
        return prism_rtl::cat(prism_rtl::deref(r_p0).name, "::", v_pc, "(x) => x.to_pod(),");
    }), Text::lit("\n"));
    auto reads_p4 = crate::syntax::lexer::chars::join(each(prism_rtl::deref(r_p0).cases_, [&](const std::tuple<Text, Text>& _p0) {
        auto&& v_pd = std::get<0>(_p0);
        auto&& st_pe = std::get<1>(_p0);
        return prism_rtl::cat("Some(t) if t == ", st_pe, "::TAG => Ok(", prism_rtl::deref(r_p0).name, "::", v_pd, "(FromPod::from_pod(p)?)),");
    }), Text::lit("\n"));
    auto back_p5 = prism_rtl::deref(r_p0).pod
        ? prism_rtl::cat("\n", crate::emit::rust::templates::items::row_from_pod(prism_rtl::deref(r_p0).name, reads_p4))
        : Text::lit("");
    auto pods2_p6 = len(prism_rtl::deref(r_p0).cases_) == Nat(0u)
        ? Text::lit("_ => unreachable!(),")
        : pods_p3;
    auto deep_pods_p7 = concat(each(prism_rtl::deref(r_p0).deep, [&](const Text& v_pf) { return prism_rtl::cat(prism_rtl::deref(r_p0).name, "::", v_pf, "(x) => x.level_pod(cx),\n            "); }));
    auto deep_ports_p8 = concat(each(prism_rtl::deref(r_p0).deep, [&](const Text& v_pg) { return prism_rtl::cat(prism_rtl::deref(r_p0).name, "::", v_pg, "(x) => x.level_ports(cx, out),\n            "); }));
    auto level_p9 = prism_rtl::deref(r_p0).level
        ? prism_rtl::cat("\n", crate::emit::rust::templates::items::row_level(prism_rtl::deref(r_p0).name, deep_pods_p7, deep_ports_p8))
        : Text::lit("");
    return prism_rtl::finished(prism_rtl::cat(crate::emit::rust::templates::items::row(crate::emit::rust::templates::source_doc(prism_rtl::cat("`", prism_rtl::deref(r_p0).prism, "`, a row kind\'s values:"), prism_rtl::deref(r_p0).doc), derives_p1, prism_rtl::deref(r_p0).name, cases_p2, pods2_p6), back_p5, level_p9));
}


/// `Start RustRow, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_rust_row(crate::lower::model::RowDef r_p0) {
    return prism_rtl::make_rc<RustRow>(r_p0);
}


/// RustAnswer: unbounded fn AnswerDef -> Text
Text rust_answer(const crate::lower::model::AnswerDef& a_p0) {
    auto cases_p1 = crate::syntax::lexer::chars::join(run_to_end(each_job(a_p0.cases_, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::AnswerCase)>>(prism_rtl::rc([=](crate::lower::model::AnswerCase p0) {
        return entered(once_job([=]() {
            return ({
                auto c_p5 = p0;
                call_then(crate::emit::rust::start_type_(prism_rtl::deref(c_p5).ty), [=](Text type__12343) { return prism_rtl::finished(prism_rtl::cat(prism_rtl::deref(c_p5).variant, "(", type__12343, "),")); });
            });
        }));
    })))), Text::lit("\n"));
    auto tags_p2 = len(a_p0.cases_) == Nat(0u)
        ? Text::lit("_ => unreachable!(),")
        : crate::syntax::lexer::chars::join(each(a_p0.cases_, [&](const crate::lower::model::AnswerCase& c_p6) { return prism_rtl::cat("Answer::", prism_rtl::deref(c_p6).variant, "(_) => ", prism_rtl::deref(c_p6).struct_path, "::TAG,"); }), Text::lit("\n"));
    auto accessors_p3 = crate::syntax::lexer::chars::join(run_to_end(each_job(a_p0.cases_, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::AnswerCase)>>(prism_rtl::rc([=](crate::lower::model::AnswerCase p0) {
        return entered(once_job([=]() {
            return ({
                auto c_p7 = p0;
                call_then(crate::emit::rust::start_type_(prism_rtl::deref(c_p7).ty), [=](Text type__12605) { return prism_rtl::finished(crate::emit::rust::templates::items::answer_getter(prism_rtl::deref(c_p7).accessor, prism_rtl::deref(c_p7).variant, prism_rtl::deref(c_p7).tag_name, type__12605)); });
            });
        }));
    })))), Text::lit("\n"));
    auto decodes_p4 = len(a_p0.cases_) == Nat(0u)
        ? Text::lit("_ => unreachable!(),")
        : crate::syntax::lexer::chars::join(run_to_end(each_job(a_p0.cases_, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::AnswerCase)>>(prism_rtl::rc([=](crate::lower::model::AnswerCase p0) {
        return entered(once_job([=]() {
            return ({
                auto c_p8 = p0;
                call_then(crate::emit::rust::start_decode_head(prism_rtl::deref(c_p8).ty), [=](Text decode_head_12768) { return prism_rtl::finished(prism_rtl::cat("Elem::", prism_rtl::deref(c_p8).variant, "(..) => Ok(Answer::", prism_rtl::deref(c_p8).variant, "(", decode_head_12768, "::from_pod(v)?)),")); });
            });
        }));
    })))), Text::lit("\n"));
    return crate::emit::rust::templates::items::answer_type(cases_p1, tags_p2, accessors_p3, decodes_p4);
}


prism_rtl::Turn<Text> RustAnswer::cycle() const {
    const auto& a_p0 = this->a_p0;
    auto a_p0_1 = a_p0;
    return call_value(each_job(prism_rtl::deref(a_p0_1).cases_, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::AnswerCase)>>(prism_rtl::rc([=](crate::lower::model::AnswerCase p0) {
        return entered(once_job([=]() {
            return ({
                auto c_p5 = p0;
                call_then(crate::emit::rust::start_type_(prism_rtl::deref(c_p5).ty), [=](Text type__12343) { return prism_rtl::finished(prism_rtl::cat(prism_rtl::deref(c_p5).variant, "(", type__12343, "),")); });
            });
        }));
    }))), [=](Array<Text> each_12310) {
        return ({
            auto cases_p1 = crate::syntax::lexer::chars::join(each_12310, Text::lit("\n"));
            auto tags_p2 = len(prism_rtl::deref(a_p0_1).cases_) == Nat(0u)
                ? Text::lit("_ => unreachable!(),")
                : crate::syntax::lexer::chars::join(each(prism_rtl::deref(a_p0_1).cases_, [&](const crate::lower::model::AnswerCase& c_p6) { return prism_rtl::cat("Answer::", prism_rtl::deref(c_p6).variant, "(_) => ", prism_rtl::deref(c_p6).struct_path, "::TAG,"); }), Text::lit("\n"));
            call_value(each_job(prism_rtl::deref(a_p0_1).cases_, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::AnswerCase)>>(prism_rtl::rc([=](crate::lower::model::AnswerCase p0) {
            return entered(once_job([=]() {
                return ({
                    auto c_p7 = p0;
                    call_then(crate::emit::rust::start_type_(prism_rtl::deref(c_p7).ty), [=](Text type__12605) { return prism_rtl::finished(crate::emit::rust::templates::items::answer_getter(prism_rtl::deref(c_p7).accessor, prism_rtl::deref(c_p7).variant, prism_rtl::deref(c_p7).tag_name, type__12605)); });
                });
            }));
        }))), [=, cases_p1 = std::move(cases_p1), tags_p2 = std::move(tags_p2)](Array<Text> each_12538) {
            return ({
                auto accessors_p3 = crate::syntax::lexer::chars::join(each_12538, Text::lit("\n"));
                auto decodes_p4 = len(prism_rtl::deref(a_p0_1).cases_) == Nat(0u)
                    ? Text::lit("_ => unreachable!(),")
                    : crate::syntax::lexer::chars::join(run_to_end(each_job(prism_rtl::deref(a_p0_1).cases_, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::AnswerCase)>>(prism_rtl::rc([=](crate::lower::model::AnswerCase p0) {
                    return entered(once_job([=]() {
                        return ({
                            auto c_p8 = p0;
                            call_then(crate::emit::rust::start_decode_head(prism_rtl::deref(c_p8).ty), [=](Text decode_head_12768) { return prism_rtl::finished(prism_rtl::cat("Elem::", prism_rtl::deref(c_p8).variant, "(..) => Ok(Answer::", prism_rtl::deref(c_p8).variant, "(", decode_head_12768, "::from_pod(v)?)),")); });
                        });
                    }));
                })))), Text::lit("\n"));
                (prism_rtl::finished(crate::emit::rust::templates::items::answer_type(cases_p1, tags_p2, accessors_p3, decodes_p4)));
            });
        });
        });
    });
}


/// `Start RustAnswer, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_rust_answer(crate::lower::model::AnswerDef a_p0) {
    return prism_rtl::make_rc<RustAnswer>(a_p0);
}


/// RustNode: unbounded fn NodeDef -> Text
Text rust_node(const crate::lower::model::NodeDef& n_p0) {
    auto fields_p1 = crate::syntax::lexer::chars::join(run_to_end(each_job(n_p0.fields, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy, Text>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy, Text> p0) {
        return entered(once_job([=]() {
            return ({
                auto [f_pf, t_pg, doc_ph] = p0;
                call_then(crate::emit::rust::start_type_(t_pg), [=](Text type__13185) { return prism_rtl::finished(prism_rtl::cat(crate::emit::rust::templates::doc(doc_ph), f_pf, ": ", type__13185, ",")); });
            });
        }));
    })))), Text::lit("\n"));
    auto consts_p2 = concat(each(n_p0.consts, [&](const std::tuple<Text, Nat, Text>& _p0) {
        auto&& c_pi = std::get<0>(_p0);
        auto&& h_pj = std::get<1>(_p0);
        auto&& doc_pk = std::get<2>(_p0);
        return prism_rtl::cat(crate::emit::rust::templates::doc(prism_rtl::cat("The ", doc_pk, ".")), "const ", c_pi, ": u32 = ", h_pj, ";\n");
    }));
    auto params_p3 = concat(run_to_end(each_job(n_p0.params, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
        return entered(once_job([=]() {
            return ({
                auto [p_pl, t_pm] = p0;
                call_then(crate::emit::rust::start_type_(t_pm), [=](Text type__13363) { return prism_rtl::finished(prism_rtl::cat(p_pl, ": ", type__13363, ", ")); });
            });
        }));
    })))));
    auto ret_p4 = n_p0.fallible
        ? prism_rtl::cat("Result<Rc<", n_p0.name, ">, Fault>")
        : prism_rtl::cat("Rc<", n_p0.name, ">");
    auto inits_p5 = crate::syntax::lexer::chars::join(append(Array(std::vector{Text::lit("path")}), run_to_end(each_job(n_p0.inits, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::Ex>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::Ex> p0) {
        return entered(once_job([=]() {
            return ({
                auto [f_pn, v_po] = p0;
                (prism_rtl::more(prism_rtl::rc(crate::emit::rust::FieldInit(f_pn, v_po))));
            });
        }));
    }))))), Text::lit(", "));
    auto tail_p6 = n_p0.fallible ? Text::lit("Ok(node)") : Text::lit("node");
    auto rest_text_p7 = len(n_p0.build) == Nat(0u)
        ? tail_p6
        : prism_rtl::cat(crate::emit::rust::statements(n_p0.build), "\n", tail_p6);
    auto build_p8 = crate::emit::rust::templates::items::build(n_p0.name, params_p3, ret_p4, crate::emit::rust::statements(n_p0.lets), inits_p5, rest_text_p7);
    auto methods_p9 = crate::syntax::lexer::chars::join(run_to_end(each_job(n_p0.methods, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::MethDef)>>(prism_rtl::rc([=](crate::lower::model::MethDef p0) {
        return entered(once_job([=]() {
            return ({
                auto m_pp = p0;
                (prism_rtl::more(prism_rtl::rc(RustMethod(m_pp))));
            });
        }));
    })))), Text::lit("\n"));
    auto answer_pa = len(n_p0.answers) == Nat(0u)
        ? Text::lit("")
        : crate::emit::rust::templates::items::answer(crate::syntax::lexer::chars::join(run_to_end(each_job(n_p0.answers, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<crate::lower::model::Pa, crate::lower::model::Ex>)>>(prism_rtl::rc([=](std::tuple<crate::lower::model::Pa, crate::lower::model::Ex> p0) {
        return entered(once_job([=]() {
            return ({
                auto [pat_pq, call_pr] = p0;
                call_then(crate::emit::rust::start_pattern(pat_pq), [=](Text pattern_13929) { return call_then(crate::emit::rust::start_expression(call_pr), [=](Text expression_13946) { return prism_rtl::finished(prism_rtl::cat(pattern_13929, " => ", expression_13946, ",")); }); });
            });
        }));
    })))), Text::lit("\n")));
    auto builders_pb = concat(append(run_to_end(each_job(n_p0.builders, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::ForDef)>>(prism_rtl::rc([=](crate::lower::model::ForDef p0) {
        return entered(once_job([=]() {
            return ({
                auto b_ps = p0;
                call_then(start_for_builder(b_ps), [=](Text for_builder_14034) { return prism_rtl::finished(prism_rtl::cat("\n", for_builder_14034)); });
            });
        }));
    })))), run_to_end(each_job(n_p0.gens, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::GenDef)>>(prism_rtl::rc([=](crate::lower::model::GenDef p0) {
        return entered(once_job([=]() {
            return ({
                auto gd_pt = p0;
                call_then(start_gen_builder(gd_pt), [=](Text gen_builder_14075) { return prism_rtl::finished(prism_rtl::cat("\n", gen_builder_14075)); });
            });
        }));
    }))))));
    auto row_impl_pc = n_p0.row_kind == crate::lower::model::RowKind(crate::lower::model::RowKind::NotARow{})
        ? Text::lit("")
        : prism_rtl::cat("\n", rust_row_impl(n_p0));
    auto hooks_pd = crate::syntax::lexer::chars::join(run_to_end(each_job(n_p0.hooks, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Array<crate::lower::model::Do>>)>>(prism_rtl::rc([=](std::tuple<Text, Array<crate::lower::model::Do>> p0) {
        return entered(once_job([=]() {
            return ({
                auto [h_pu, body_pv] = p0;
                h_pu == Text::lit("push")
                ? call_then(crate::emit::rust::start_statements(body_pv), [=](Text statements_14242) { return prism_rtl::finished(crate::emit::rust::templates::items::push_hook(statements_14242)); })
                : call_then(crate::emit::rust::start_statements(body_pv), [=](Text statements_14274) { return prism_rtl::finished(crate::emit::rust::templates::items::hook(h_pu, statements_14274)); });
            });
        }));
    })))), Text::lit("\n"));
    auto doc_pe = crate::emit::rust::templates::source_doc(prism_rtl::cat("`", n_p0.prism, "`: a node of its own (claude/backend.md, \"A widget block\")."), n_p0.doc);
    return prism_rtl::cat(crate::emit::rust::templates::items::node_(doc_pe, n_p0.name, fields_p1, consts_p2, build_p8, prism_rtl::cat(methods_p9, builders_pb), hooks_pd, answer_pa), row_impl_pc);
}


prism_rtl::Turn<Text> RustNode::cycle() const {
    const auto& n_p0 = this->n_p0;
    auto n_p0_1 = n_p0;
    return call_value(each_job(prism_rtl::deref(n_p0_1).fields, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy, Text>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy, Text> p0) {
        return entered(once_job([=]() {
            return ({
                auto [f_pf, t_pg, doc_ph] = p0;
                call_then(crate::emit::rust::start_type_(t_pg), [=](Text type__13185) { return prism_rtl::finished(prism_rtl::cat(crate::emit::rust::templates::doc(doc_ph), f_pf, ": ", type__13185, ",")); });
            });
        }));
    }))), [=](Array<Text> each_13137) {
        return ({
            auto fields_p1 = crate::syntax::lexer::chars::join(each_13137, Text::lit("\n"));
            auto consts_p2 = concat(each(prism_rtl::deref(n_p0_1).consts, [&](const std::tuple<Text, Nat, Text>& _p0) {
                auto&& c_pi = std::get<0>(_p0);
                auto&& h_pj = std::get<1>(_p0);
                auto&& doc_pk = std::get<2>(_p0);
                return prism_rtl::cat(crate::emit::rust::templates::doc(prism_rtl::cat("The ", doc_pk, ".")), "const ", c_pi, ": u32 = ", h_pj, ";\n");
            }));
            call_value(each_job(prism_rtl::deref(n_p0_1).params, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
            return entered(once_job([=]() {
                return ({
                    auto [p_pl, t_pm] = p0;
                    call_then(crate::emit::rust::start_type_(t_pm), [=](Text type__13363) { return prism_rtl::finished(prism_rtl::cat(p_pl, ": ", type__13363, ", ")); });
                });
            }));
        }))), [=, fields_p1 = std::move(fields_p1), consts_p2 = std::move(consts_p2)](Array<Text> each_13329) {
            return ({
                auto params_p3 = concat(each_13329);
                auto ret_p4 = prism_rtl::deref(n_p0_1).fallible
                    ? prism_rtl::cat("Result<Rc<", prism_rtl::deref(n_p0_1).name, ">, Fault>")
                    : prism_rtl::cat("Rc<", prism_rtl::deref(n_p0_1).name, ">");
                call_value(each_job(prism_rtl::deref(n_p0_1).inits, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::Ex>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::Ex> p0) {
                return entered(once_job([=]() {
                    return ({
                        auto [f_pn, v_po] = p0;
                        (prism_rtl::more(prism_rtl::rc(crate::emit::rust::FieldInit(f_pn, v_po))));
                    });
                }));
            }))), [=, params_p3 = std::move(params_p3), ret_p4 = std::move(ret_p4)](Array<Text> each_13497) {
                return ({
                    auto inits_p5 = crate::syntax::lexer::chars::join(append(Array(std::vector{Text::lit("path")}), each_13497), Text::lit(", "));
                    auto tail_p6 = prism_rtl::deref(n_p0_1).fallible
                        ? Text::lit("Ok(node)")
                        : Text::lit("node");
                    auto rest_text_p7 = len(n_p0_1->build) == Nat(0u)
                        ? tail_p6
                        : prism_rtl::cat(crate::emit::rust::statements(n_p0_1->build), "\n", tail_p6);
                    call_then(crate::emit::rust::start_statements(prism_rtl::deref(n_p0_1).lets), [=, inits_p5 = std::move(inits_p5), rest_text_p7 = std::move(rest_text_p7)](Text statements_13728) {
                    return ({
                        auto build_p8 = crate::emit::rust::templates::items::build(prism_rtl::deref(n_p0_1).name, params_p3, ret_p4, statements_13728, inits_p5, rest_text_p7);
                        call_value(each_job(prism_rtl::deref(n_p0_1).methods, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::MethDef)>>(prism_rtl::rc([=](crate::lower::model::MethDef p0) {
                        return entered(once_job([=]() {
                            return ({
                                auto m_pp = p0;
                                (prism_rtl::more(prism_rtl::rc(RustMethod(m_pp))));
                            });
                        }));
                    }))), [=, build_p8 = std::move(build_p8)](Array<Text> each_13788) {
                        return ({
                            auto methods_p9 = crate::syntax::lexer::chars::join(each_13788, Text::lit("\n"));
                            auto answer_pa = len(prism_rtl::deref(n_p0_1).answers) == Nat(0u)
                                ? Text::lit("")
                                : crate::emit::rust::templates::items::answer(crate::syntax::lexer::chars::join(run_to_end(each_job(prism_rtl::deref(n_p0_1).answers, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<crate::lower::model::Pa, crate::lower::model::Ex>)>>(prism_rtl::rc([=](std::tuple<crate::lower::model::Pa, crate::lower::model::Ex> p0) {
                                return entered(once_job([=]() {
                                    return ({
                                        auto [pat_pq, call_pr] = p0;
                                        call_then(crate::emit::rust::start_pattern(pat_pq), [=](Text pattern_13929) { return call_then(crate::emit::rust::start_expression(call_pr), [=](Text expression_13946) { return prism_rtl::finished(prism_rtl::cat(pattern_13929, " => ", expression_13946, ",")); }); });
                                    });
                                }));
                            })))), Text::lit("\n")));
                            call_value(each_job(prism_rtl::deref(n_p0_1).builders, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::ForDef)>>(prism_rtl::rc([=](crate::lower::model::ForDef p0) {
                            return entered(once_job([=]() {
                                return ({
                                    auto b_ps = p0;
                                    call_then(start_for_builder(b_ps), [=](Text for_builder_14034) { return prism_rtl::finished(prism_rtl::cat("\n", for_builder_14034)); });
                                });
                            }));
                        }))), [=, methods_p9 = std::move(methods_p9), answer_pa = std::move(answer_pa)](Array<Text> each_14008) {
                            return call_value(each_job(prism_rtl::deref(n_p0_1).gens, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::GenDef)>>(prism_rtl::rc([=](crate::lower::model::GenDef p0) {
                                return entered(once_job([=]() {
                                    return ({
                                        auto gd_pt = p0;
                                        call_then(start_gen_builder(gd_pt), [=](Text gen_builder_14075) { return prism_rtl::finished(prism_rtl::cat("\n", gen_builder_14075)); });
                                    });
                                }));
                            }))), [=](Array<Text> each_14052) {
                                return ({
                                    auto builders_pb = concat(append(each_14008, each_14052));
                                    auto row_impl_pc = prism_rtl::deref(n_p0_1).row_kind == crate::lower::model::RowKind(crate::lower::model::RowKind::NotARow{})
                                        ? Text::lit("")
                                        : prism_rtl::cat("\n", rust_row_impl(n_p0_1));
                                    call_value(each_job(prism_rtl::deref(n_p0_1).hooks, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Array<crate::lower::model::Do>>)>>(prism_rtl::rc([=](std::tuple<Text, Array<crate::lower::model::Do>> p0) {
                                    return entered(once_job([=]() {
                                        return ({
                                            auto [h_pu, body_pv] = p0;
                                            h_pu == Text::lit("push")
                                            ? call_then(crate::emit::rust::start_statements(body_pv), [=](Text statements_14242) { return prism_rtl::finished(crate::emit::rust::templates::items::push_hook(statements_14242)); })
                                            : call_then(crate::emit::rust::start_statements(body_pv), [=](Text statements_14274) { return prism_rtl::finished(crate::emit::rust::templates::items::hook(h_pu, statements_14274)); });
                                        });
                                    }));
                                }))), [=, builders_pb = std::move(builders_pb), row_impl_pc = std::move(row_impl_pc)](Array<Text> each_14187) {
                                    return ({
                                        auto hooks_pd = crate::syntax::lexer::chars::join(each_14187, Text::lit("\n"));
                                        auto doc_pe = crate::emit::rust::templates::source_doc(prism_rtl::cat("`", prism_rtl::deref(n_p0_1).prism, "`: a node of its own (claude/backend.md, \"A widget block\")."), prism_rtl::deref(n_p0_1).doc);
                                        (prism_rtl::finished(prism_rtl::cat(crate::emit::rust::templates::items::node_(doc_pe, prism_rtl::deref(n_p0_1).name, fields_p1, consts_p2, build_p8, prism_rtl::cat(methods_p9, builders_pb), hooks_pd, answer_pa), row_impl_pc)));
                                    });
                                });
                                });
                            });
                        });
                        });
                    });
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start RustNode, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_rust_node(crate::lower::model::NodeDef n_p0) {
    return prism_rtl::make_rc<RustNode>(n_p0);
}


/// ForBuilder: unbounded fn ForDef -> Text
Text for_builder(const crate::lower::model::ForDef& b_p0) {
    return crate::emit::rust::templates::items::for_build(b_p0.name, crate::emit::rust::expression(b_p0.at), crate::emit::rust::type_(b_p0.key_ty), crate::emit::rust::type_(b_p0.value_ty), b_p0.row_node, b_p0.source, crate::emit::rust::expression(b_p0.parent), concat(run_to_end(each_job(b_p0.passed, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Ex)>>(prism_rtl::rc([=](crate::lower::model::Ex p0) {
        return entered(once_job([=]() {
            return ({
                auto x_p1 = p0;
                call_then(crate::emit::rust::start_expression(x_p1), [=](Text expression_14767) { return prism_rtl::finished(prism_rtl::cat(", ", expression_14767)); });
            });
        }));
    }))))), moved_call(b_p0.name, b_p0.moved), from_kept(b_p0.name, b_p0.replaced), replaced_call(b_p0.replaced));
}


prism_rtl::Turn<Text> ForBuilder::cycle() const {
    const auto& b_p0 = this->b_p0;
    auto b_p0_1 = b_p0;
    return call_then(crate::emit::rust::start_expression(prism_rtl::deref(b_p0_1).at), [=](Text expression_14638) {
        return call_then(crate::emit::rust::start_type_(prism_rtl::deref(b_p0_1).key_ty), [=](Text type__14657) {
            return call_then(crate::emit::rust::start_type_(prism_rtl::deref(b_p0_1).value_ty), [=](Text type__14673) {
                return call_then(crate::emit::rust::start_expression(b_p0_1->parent), [=](Text expression_14712) {
                    return call_value(each_job(prism_rtl::deref(b_p0_1).passed, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Ex)>>(prism_rtl::rc([=](crate::lower::model::Ex p0) {
                        return entered(once_job([=]() {
                            return ({
                                auto x_p1 = p0;
                                call_then(crate::emit::rust::start_expression(x_p1), [=](Text expression_14767) { return prism_rtl::finished(prism_rtl::cat(", ", expression_14767)); });
                            });
                        }));
                    }))), [=](Array<Text> each_14743) { return prism_rtl::finished(crate::emit::rust::templates::items::for_build(prism_rtl::deref(b_p0_1).name, expression_14638, type__14657, type__14673, prism_rtl::deref(b_p0_1).row_node, b_p0_1->source, expression_14712, concat(each_14743), moved_call(prism_rtl::deref(b_p0_1).name, prism_rtl::deref(b_p0_1).moved), from_kept(prism_rtl::deref(b_p0_1).name, prism_rtl::deref(b_p0_1).replaced), replaced_call(prism_rtl::deref(b_p0_1).replaced))); });
                });
            });
        });
    });
}


/// `Start ForBuilder, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_for_builder(crate::lower::model::ForDef b_p0) {
    return prism_rtl::make_rc<ForBuilder>(b_p0);
}


/// FromKept: fn Text, [Text] -> Text
Text from_kept(const Text& name_p0, const Array<Text>& replaced_p1) {
    return len(replaced_p1) == Nat(0u)
        ? prism_rtl::cat("*self.", name_p0, "_from.borrow_mut() = items.clone();")
        : prism_rtl::cat("let from = std::mem::replace(&mut *self.", name_p0, "_from.borrow_mut(), items.clone());");
}


/// ReplacedCall: fn [Text] -> Text
Text replaced_call(const Array<Text>& replaced_p0) {
    return len(replaced_p0) == Nat(0u)
        ? Text::lit("")
        : prism_rtl::cat(" else if from.get(k) != items.get(k) {\n            // the dynamic under a kept key was replaced: that row follows it from the next tick\n", concat(each(replaced_p0, [&](const Text& m_p1) { return prism_rtl::cat("            row.", m_p1, "(cx);\n"); })), "        }");
}


/// MovedCall: fn Text, Text -> Text
Text moved_call(const Text& name_p0, const Text& m_p1) {
    return m_p1 == Text::lit("")
        ? Text::lit("")
        : prism_rtl::cat("\n    // the places of the host\'s child came or went: its document\'s outer moves\n    if !prism_rtl::same_keys(&self.", name_p0, ".borrow(), &old) {\n        self.", m_p1, "(cx);\n    }");
}


/// GenMovedCall: fn Text -> Text
Text gen_moved_call(const Text& m_p0) {
    return m_p0 == Text::lit("")
        ? Text::lit("")
        : prism_rtl::cat("\n    // the places of the host\'s child came or went: its document\'s outer moves\n    self.", m_p0, "(cx);");
}


/// GenBuilder: unbounded fn GenDef -> Text
Text gen_builder(const crate::lower::model::GenDef& gd_p0) {
    auto path_p1 = gd_p0.transparent
        ? Text::lit("self.path.clone()")
        : prism_rtl::cat(crate::emit::rust::expression(gd_p0.at), ".child(Segment::Gen(g))");
    return crate::emit::rust::templates::items::gen_build(gd_p0.name, crate::emit::rust::expression(gd_p0.at), path_p1, crate::emit::rust::expression(gd_p0.source), crate::emit::rust::type_(gd_p0.value_ty), crate::emit::rust::expression(gd_p0.select), gen_moved_call(gd_p0.moved));
}


prism_rtl::Turn<Text> GenBuilder::cycle() const {
    const auto& gd_p0 = this->gd_p0;
    auto path_p1 = prism_rtl::deref(gd_p0).transparent
        ? Text::lit("self.path.clone()")
        : prism_rtl::cat(crate::emit::rust::expression(prism_rtl::deref(gd_p0).at), ".child(Segment::Gen(g))");
    auto gd_p0_1 = gd_p0;
    return call_then(crate::emit::rust::start_expression(prism_rtl::deref(gd_p0_1).at), [=](Text expression_16754) { return call_then(crate::emit::rust::start_expression(gd_p0_1->source), [=](Text expression_16780) { return call_then(crate::emit::rust::start_type_(prism_rtl::deref(gd_p0_1).value_ty), [=](Text type__16804) { return call_then(crate::emit::rust::start_expression(prism_rtl::deref(gd_p0_1).select), [=](Text expression_16823) { return prism_rtl::finished(crate::emit::rust::templates::items::gen_build(prism_rtl::deref(gd_p0_1).name, expression_16754, path_p1, expression_16780, type__16804, expression_16823, gen_moved_call(prism_rtl::deref(gd_p0_1).moved))); }); }); }); });
}


/// `Start GenBuilder, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_gen_builder(crate::lower::model::GenDef gd_p0) {
    return prism_rtl::make_rc<GenBuilder>(gd_p0);
}


/// RustRowImpl: unbounded fn NodeDef -> Text
Text rust_row_impl(const crate::lower::model::NodeDef& n_p0) {
    auto kept_p1 = n_p0.row_kind == crate::lower::model::RowKind(crate::lower::model::RowKind::ForRow{})
        ? Array(std::vector{Text::lit("*self.left_entry.borrow_mut() = Some(self.entry(cx));")})
        : Array<Text>{};
    auto unsubscribe_p2 = each(n_p0.subs, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
        auto&& ev_p3 = std::get<0>(_p0);
        auto&& m_p4 = std::get<1>(_p0);
        return prism_rtl::cat("if let (Some(p), Some(h)) = (self.parent.upgrade(), self.", m_p4, "_sub.take()) {\n    p.", ev_p3, "_port.unsubscribe(h);\n}");
    });
    return crate::emit::rust::templates::items::row_impl(n_p0.name, crate::syntax::lexer::chars::join(append(crate::prelude::push(kept_p1, Text::lit("self.remove_places(cx);")), unsubscribe_p2), Text::lit("\n")), crate::syntax::lexer::chars::join(run_to_end(each_job(n_p0.hosted, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::MethDef)>>(prism_rtl::rc([=](crate::lower::model::MethDef p0) {
        return entered(once_job([=]() {
            return ({
                auto m_p5 = p0;
                (prism_rtl::more(prism_rtl::rc(RustMethod(m_p5))));
            });
        }));
    })))), Text::lit("\n")));
}


prism_rtl::Turn<Text> RustRowImpl::cycle() const {
    const auto& n_p0 = this->n_p0;
    auto kept_p1 = prism_rtl::deref(n_p0).row_kind == crate::lower::model::RowKind(crate::lower::model::RowKind::ForRow{})
        ? Array(std::vector{Text::lit("*self.left_entry.borrow_mut() = Some(self.entry(cx));")})
        : Array<Text>{};
    auto unsubscribe_p2 = each(prism_rtl::deref(n_p0).subs, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
        auto&& ev_p3 = std::get<0>(_p0);
        auto&& m_p4 = std::get<1>(_p0);
        return prism_rtl::cat("if let (Some(p), Some(h)) = (self.parent.upgrade(), self.", m_p4, "_sub.take()) {\n    p.", ev_p3, "_port.unsubscribe(h);\n}");
    });
    auto n_p0_1 = n_p0;
    return call_value(each_job(prism_rtl::deref(n_p0_1).hosted, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::MethDef)>>(prism_rtl::rc([=](crate::lower::model::MethDef p0) {
        return entered(once_job([=]() {
            return ({
                auto m_p5 = p0;
                (prism_rtl::more(prism_rtl::rc(RustMethod(m_p5))));
            });
        }));
    }))), [=](Array<Text> each_17546) { return prism_rtl::finished(crate::emit::rust::templates::items::row_impl(prism_rtl::deref(n_p0_1).name, crate::syntax::lexer::chars::join(append(crate::prelude::push(kept_p1, Text::lit("self.remove_places(cx);")), unsubscribe_p2), Text::lit("\n")), crate::syntax::lexer::chars::join(each_17546, Text::lit("\n")))); });
}


/// `Start RustRowImpl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_rust_row_impl(crate::lower::model::NodeDef n_p0) {
    return prism_rtl::make_rc<RustRowImpl>(n_p0);
}


/// RustMethod: unbounded fn MethDef -> Text
Text rust_method(const crate::lower::model::MethDef& m_p0) {
    auto recv_p1 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = m_p0.recv;
        if (prism_rtl::is<crate::lower::model::Recv::RecvRc>(_m)) {
            _v.set(Text::lit("self: &Rc<Self>"));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::Recv::RecvRef>(_m)) {
            _v.set(Text::lit("&self"));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::Recv::RecvOwned>(_m)) {
            _v.set(Text::lit("self: Rc<Self>"));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto cx_p2 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = m_p0.cx_;
        if (prism_rtl::is<crate::lower::model::CxArg::CxMut>(_m)) {
            _v.set(Text::lit(", cx: &mut Cx"));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::CxArg::CxRef>(_m)) {
            _v.set(Text::lit(", cx: &Cx"));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::CxArg::CxNone>(_m)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto params_p3 = concat(run_to_end(each_job(m_p0.params, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
        return entered(once_job([=]() {
            return ({
                auto [p_p7, t_p8] = p0;
                call_then(crate::emit::rust::start_type_(t_p8), [=](Text type__17933) { return prism_rtl::finished(prism_rtl::cat(", ", p_p7, ": ", type__17933)); });
            });
        }));
    })))));
    auto ret_p4 = m_p0.ret == crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})
        ? Text::lit("")
        : prism_rtl::cat(" -> ", crate::emit::rust::type_(m_p0.ret));
    auto sig_p5 = prism_rtl::cat("fn ", m_p0.name, "(", recv_p1, params_p3, cx_p2, ")", ret_p4);
    auto body_p6 = m_p0.ret == crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})
        ? crate::emit::rust::statements(m_p0.body)
        : len(m_p0.body) == Nat(0u)
        ? crate::emit::rust::body_lines(m_p0.tail)
        : prism_rtl::cat(crate::emit::rust::statements(m_p0.body), "\n", crate::emit::rust::body_lines(m_p0.tail));
    return crate::emit::rust::templates::items::method(crate::emit::rust::templates::doc(m_p0.doc), sig_p5, body_p6);
}


prism_rtl::Turn<Text> RustMethod::cycle() const {
    const auto& m_p0 = this->m_p0;
    auto recv_p1 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = prism_rtl::deref(m_p0).recv;
        if (prism_rtl::is<crate::lower::model::Recv::RecvRc>(_m)) {
            _v.set(Text::lit("self: &Rc<Self>"));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::Recv::RecvRef>(_m)) {
            _v.set(Text::lit("&self"));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::Recv::RecvOwned>(_m)) {
            _v.set(Text::lit("self: Rc<Self>"));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto cx_p2 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = prism_rtl::deref(m_p0).cx_;
        if (prism_rtl::is<crate::lower::model::CxArg::CxMut>(_m)) {
            _v.set(Text::lit(", cx: &mut Cx"));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::CxArg::CxRef>(_m)) {
            _v.set(Text::lit(", cx: &Cx"));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::CxArg::CxNone>(_m)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto m_p0_1 = m_p0;
    return call_value(each_job(prism_rtl::deref(m_p0_1).params, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
        return entered(once_job([=]() {
            return ({
                auto [p_p7, t_p8] = p0;
                call_then(crate::emit::rust::start_type_(t_p8), [=](Text type__17933) { return prism_rtl::finished(prism_rtl::cat(", ", p_p7, ": ", type__17933)); });
            });
        }));
    }))), [=](Array<Text> each_17897) {
        return ({
            auto params_p3 = concat(each_17897);
            auto ret_p4 = prism_rtl::deref(m_p0_1).ret == crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})
                ? Text::lit("")
                : prism_rtl::cat(" -> ", crate::emit::rust::type_(prism_rtl::deref(m_p0_1).ret));
            auto sig_p5 = prism_rtl::cat("fn ", prism_rtl::deref(m_p0_1).name, "(", recv_p1, params_p3, cx_p2, ")", ret_p4);
            auto body_p6 = prism_rtl::deref(m_p0_1).ret == crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})
                ? crate::emit::rust::statements(prism_rtl::deref(m_p0_1).body)
                : len(prism_rtl::deref(m_p0_1).body) == Nat(0u)
                ? crate::emit::rust::body_lines(prism_rtl::deref(m_p0_1).tail)
                : prism_rtl::cat(crate::emit::rust::statements(prism_rtl::deref(m_p0_1).body), "\n", crate::emit::rust::body_lines(prism_rtl::deref(m_p0_1).tail));
            (prism_rtl::finished(crate::emit::rust::templates::items::method(crate::emit::rust::templates::doc(prism_rtl::deref(m_p0_1).doc), sig_p5, body_p6)));
        });
    });
}


/// `Start RustMethod, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_rust_method(crate::lower::model::MethDef m_p0) {
    return prism_rtl::make_rc<RustMethod>(m_p0);
}


/// RustProgram: unbounded fn ProgDef, Bool -> Text
Text rust_program(const crate::lower::model::ProgDef& p_p0, const bool& fallible_p1) {
    auto n_p2 = len(p_p0.params);
    auto names_p3 = each(p_p0.params, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
        auto&& a_p6 = std::get<0>(_p0);
        return a_p6;
    });
    auto decode_p4 = n_p2 == Nat(0u) ? Text::lit("let _ = args;") : decode_args(p_p0, names_p3);
    auto call_p5 = prism_rtl::cat(p_p0.node_, "::build(Path::root(), ", concat(each(names_p3, [&](const Text& a_p7) { return prism_rtl::cat(a_p7, ", "); })), "&mut cx)", fallible_p1 ? Text::lit("?") : Text::lit(""));
    return crate::emit::rust::templates::items::program(p_p0.name, p_p0.prism, p_p0.node_, decode_p4, call_p5);
}


prism_rtl::Turn<Text> RustProgram::cycle() const {
    const auto& p_p0 = this->p_p0;
    const auto& fallible_p1 = this->fallible_p1;
    auto n_p2 = len(prism_rtl::deref(p_p0).params);
    auto names_p3 = each(prism_rtl::deref(p_p0).params, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
        auto&& a_p6 = std::get<0>(_p0);
        return a_p6;
    });
    auto decode_p4 = n_p2 == Nat(0u) ? Text::lit("let _ = args;") : decode_args(p_p0, names_p3);
    auto call_p5 = prism_rtl::cat(prism_rtl::deref(p_p0).node_, "::build(Path::root(), ", concat(each(names_p3, [&](const Text& a_p7) { return prism_rtl::cat(a_p7, ", "); })), "&mut cx)", prism_rtl::deref(fallible_p1) ? Text::lit("?") : Text::lit(""));
    return prism_rtl::finished(crate::emit::rust::templates::items::program(prism_rtl::deref(p_p0).name, prism_rtl::deref(p_p0).prism, prism_rtl::deref(p_p0).node_, decode_p4, call_p5));
}


/// `Start RustProgram, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_rust_program(crate::lower::model::ProgDef p_p0, bool fallible_p1) {
    return prism_rtl::make_rc<RustProgram>(p_p0, fallible_p1);
}


/// DecodeArgs: unbounded fn ProgDef, [Text] -> Text
Text decode_args(const crate::lower::model::ProgDef& p_p0, const Array<Text>& names_p1) {
    auto n_p2 = len(names_p1);
    auto plural_p3 = n_p2 == Nat(1u) ? Text::lit("") : Text::lit("s");
    auto head_p4 = prism_rtl::cat("let [", crate::syntax::lexer::chars::join(names_p1, Text::lit(", ")), "] = args else { return Err(Fault::answer(\"@", p_p0.prism, " takes ", n_p2, " argument", plural_p3, "\")) };");
    return crate::syntax::lexer::chars::join(append(Array(std::vector{head_p4}), run_to_end(each_job(p_p0.params, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
        return entered(once_job([=]() {
            return ({
                auto [a_p5, t_p6] = p0;
                call_then(crate::emit::rust::start_decode_head(t_p6), [=](Text decode_head_18964) { return prism_rtl::finished(prism_rtl::cat("let ", a_p5, " = ", decode_head_18964, "::from_pod(", a_p5, ")?;")); });
            });
        }));
    }))))), Text::lit("\n"));
}


prism_rtl::Turn<Text> DecodeArgs::cycle() const {
    const auto& p_p0 = this->p_p0;
    const auto& names_p1 = this->names_p1;
    auto n_p2 = len(names_p1);
    auto plural_p3 = n_p2 == Nat(1u) ? Text::lit("") : Text::lit("s");
    auto head_p4 = prism_rtl::cat("let [", crate::syntax::lexer::chars::join(names_p1, Text::lit(", ")), "] = args else { return Err(Fault::answer(\"@", prism_rtl::deref(p_p0).prism, " takes ", n_p2, " argument", plural_p3, "\")) };");
    auto p_p0_1 = p_p0;
    return call_value(each_job(prism_rtl::deref(p_p0_1).params, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
        return entered(once_job([=]() {
            return ({
                auto [a_p5, t_p6] = p0;
                call_then(crate::emit::rust::start_decode_head(t_p6), [=](Text decode_head_18964) { return prism_rtl::finished(prism_rtl::cat("let ", a_p5, " = ", decode_head_18964, "::from_pod(", a_p5, ")?;")); });
            });
        }));
    }))), [=](Array<Text> each_18925) { return prism_rtl::finished(crate::syntax::lexer::chars::join(append(Array(std::vector{head_p4}), each_18925), Text::lit("\n"))); });
}


/// `Start DecodeArgs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_decode_args(crate::lower::model::ProgDef p_p0, Array<Text> names_p1) {
    return prism_rtl::make_rc<DecodeArgs>(p_p0, names_p1);
}


/// RustModule: unbounded fn ModDef, Text -> Text
Text rust_module(const crate::lower::model::ModDef& m_p0, const Text& kids_p1) {
    return crate::emit::rust::templates::module(m_p0.prism == Text::lit("")
        ? Text::lit("The root module")
        : prism_rtl::cat("The module `", m_p0.prism, "`"), m_p0.path_, kids_p1, crate::syntax::lexer::chars::join(run_to_end(each_job(m_p0.items, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Item)>>(prism_rtl::rc([=](crate::lower::model::Item p0) {
        return entered(once_job([=]() {
            return ({
                auto it_p2 = p0;
                (prism_rtl::more(prism_rtl::rc(RustItem(it_p2))));
            });
        }));
    })))), Text::lit("\n")));
}


prism_rtl::Turn<Text> RustModule::cycle() const {
    const auto& m_p0 = this->m_p0;
    const auto& kids_p1 = this->kids_p1;
    auto kids_p1_1 = kids_p1;
    auto m_p0_2 = m_p0;
    return call_value(each_job(prism_rtl::deref(m_p0_2).items, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Item)>>(prism_rtl::rc([=](crate::lower::model::Item p0) {
        return entered(once_job([=]() {
            return ({
                auto it_p2 = p0;
                (prism_rtl::more(prism_rtl::rc(RustItem(it_p2))));
            });
        }));
    }))), [=](Array<Text> each_19537) {
        return prism_rtl::finished(crate::emit::rust::templates::module(prism_rtl::deref(m_p0_2).prism == Text::lit("")
            ? Text::lit("The root module")
            : prism_rtl::cat("The module `", prism_rtl::deref(m_p0_2).prism, "`"), m_p0_2->path_, kids_p1_1, crate::syntax::lexer::chars::join(each_19537, Text::lit("\n"))));
    });
}


/// `Start RustModule, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_rust_module(crate::lower::model::ModDef m_p0, Text kids_p1) {
    return prism_rtl::make_rc<RustModule>(m_p0, kids_p1);
}


/// NodeFallible: fn Model, Text -> Bool
bool node_fallible(const crate::lower::model::Model& model_p0, const Text& path_p1) {
    return fold(model_p0.mods, false, [&](const bool& f_p2, const crate::lower::model::ModDef& m_p3) {
        return fold(prism_rtl::deref(m_p3).items, f_p2, [&](const bool& f2_p4, const crate::lower::model::Item& it_p5) {
            return ({
                __label__ _done;
                prism_rtl::Slot<bool> _v;
                if (prism_rtl::is<crate::lower::model::Item::ItNode>(it_p5)) {
                    auto&& n_p6 = prism_rtl::as<crate::lower::model::Item::ItNode>(it_p5).a0;
                    _v.set(prism_rtl::deref(f2_p4) || ((prism_rtl::cat(prism_rtl::deref(m_p3).name, "::", prism_rtl::deref(n_p6).name) == path_p1) && prism_rtl::deref(n_p6).fallible));
                    goto _done;
                }
                {
                    _v.set(prism_rtl::deref(f2_p4));
                    goto _done;
                }
            _done:
                _v.take();
            });
        });
    });
}


/// EmitCrate: unbounded fn Model, Text, [Text] -> [((Text, Text))]
Array<std::tuple<Text, Text>> emit_crate(const crate::lower::model::Model& model_p0, const Text& runtime_p1, const Array<Text>& scripts_p2) {
    auto gui_p3 = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = model_p0.root;
        if (prism_rtl::is_some(_m)) {
            auto&& r_ph = prism_rtl::some_of(_m);
            _v.set(r_ph->world == Text::lit("canvas"));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(false);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto cargo_p4 = crate::emit::rust::templates::cargo(model_p0.name, runtime_p1, std::move(gui_p3) ? Text::lit("\"canvas\"") : Text::lit(""));
    auto paths_p5 = rust_mod_paths(model_p0.mods);
    auto mods_p6 = concat(each(filter(paths_p5, [&](const Text& p_pi) { return !crate::syntax::lexer::chars::contains(p_pi, Text::lit(":")); }), [&](const Text& p_pj) { return prism_rtl::cat("mod ", p_pj, ";\n"); }));
    auto programs_p7 = crate::syntax::lexer::chars::join(run_to_end(each_job(all_programs(model_p0), ({
        auto model_p0_1 = model_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::ProgDef)>>(prism_rtl::rc([=, model_p0_1 = std::move(model_p0_1)](crate::lower::model::ProgDef p0) {
        return ({
            auto model_p0_1_2 = model_p0_1;
            entered(once_job([=, model_p0_1_2 = std::move(model_p0_1_2)]() {
            return ({
                auto p_pk = p0;
                (prism_rtl::more(prism_rtl::rc(RustProgram(p_pk, node_fallible(model_p0_1_2, prism_rtl::deref(p_pk).node_)))));
            });
        }));
        });
    })));
    }))), Text::lit("\n"));
    auto regs_p8 = concat(each(model_p0.programs, [&](const crate::lower::model::ProgDef& p_pl) { return prism_rtl::cat(".program::<", prism_rtl::deref(p_pl).name, ">(\"", prism_rtl::deref(p_pl).prism, "\")\n"); }));
    auto checks_p9 = concat(run_to_end(each_job(model_p0.checks, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::CheckDef)>>(prism_rtl::rc([=](crate::lower::model::CheckDef p0) {
        return entered(once_job([=]() {
            return ({
                auto c_pm = p0;
                call_value(each_job(prism_rtl::deref(c_pm).lines, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Ex)>>(prism_rtl::rc([=](crate::lower::model::Ex p0) {
                return entered(once_job([=]() {
                    return ({
                        auto l_pn = p0;
                        (prism_rtl::more(prism_rtl::rc(crate::emit::rust::Expression(l_pn))));
                    });
                }));
            }))), [=](Array<Text> each_20566) { return prism_rtl::finished(prism_rtl::cat(".check(\"", prism_rtl::deref(c_pm).name, "\", || vec![", crate::syntax::lexer::chars::join(each_20566, Text::lit(", ")), "])\n")); });
            });
        }));
    })))));
    auto script_list_pa = concat(each(scripts_p2, [&](const Text& s_po) { return prism_rtl::cat("\"", crate::lower::expr::escape(s_po), "\",\n"); }));
    auto run_root_pb = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = model_p0.root;
        if (prism_rtl::is_some(_m)) {
            auto&& r_pp = prism_rtl::some_of(_m);
            _v.set(crate::emit::rust::templates::run_root(prism_rtl::deref(r_pp).name));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(crate::emit::rust::templates::no_root(model_p0.name));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto world_pc = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = model_p0.root;
        if (prism_rtl::is_some(_m)) {
            auto&& r_pq = prism_rtl::some_of(_m);
            _v.set(r_pq->world);
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text::lit("test"));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto main_pd = crate::emit::rust::templates::main(model_p0.name, prism_rtl::cat("mod prelude;\n", mods_p6), prism_rtl::cat(rust_row(model_p0.elem), "\n", rust_answer(model_p0.answer), "\n", programs_p7), prism_rtl::cat(regs_p8, checks_p9), script_list_pa, run_root_pb, world_pc);
    auto files_pe = run_to_end(each_job(model_p0.mods, ({
        auto paths_p5_1 = paths_p5;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, Text>>(crate::lower::model::ModDef)>>(prism_rtl::rc([=, paths_p5_1 = std::move(paths_p5_1)](crate::lower::model::ModDef p0) {
        return ({
            auto paths_p5_1_2 = paths_p5_1;
            entered(once_job([=, paths_p5_1_2 = std::move(paths_p5_1_2)]() {
            return ({
                auto m_pr = p0;
                call_then(start_rust_module(m_pr, kids_of(paths_p5_1_2, prism_rtl::deref(m_pr).name)), [=](Text rust_module_21080) { return prism_rtl::finished(std::tuple{rust_mod_file(prism_rtl::deref(m_pr).name), rust_module_21080}); });
            });
        }));
        });
    }));
    })));
    auto named_pf = each(model_p0.mods, [&](const crate::lower::model::ModDef& m_ps) { return prism_rtl::deref(m_ps).name; });
    auto bare_pg = each(filter(paths_p5, [&](const Text& p_pt) { return !fold(named_pf, false, [&](const bool& f_pu, const Text& n_pv) { return prism_rtl::deref(f_pu) || (n_pv == p_pt); }); }), [&](const Text& p_p10) { return std::tuple{rust_mod_file(p_p10), prism_rtl::cat("//! Emitted by prismc: the modules under `", p_p10, "`, which declares nothing of its own.\n\n", kids_of(paths_p5, p_p10))}; });
    return append(Array(std::vector{std::tuple{Text::lit("Cargo.toml"), cargo_p4}, std::tuple{Text::lit("src/main.rs"), main_pd}, std::tuple{Text::lit("src/prelude.rs"), crate::emit::rust::prelude::prelude_source(Text::lit(""))}}), append(files_pe, bare_pg));
}


prism_rtl::Turn<Array<std::tuple<Text, Text>>> EmitCrate::cycle() const {
    const auto& model_p0 = this->model_p0;
    const auto& runtime_p1 = this->runtime_p1;
    const auto& scripts_p2 = this->scripts_p2;
    auto gui_p3 = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = model_p0->root;
        if (prism_rtl::is_some(_m)) {
            auto&& r_ph = prism_rtl::some_of(_m);
            _v.set(r_ph->world == Text::lit("canvas"));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(false);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto cargo_p4 = crate::emit::rust::templates::cargo(prism_rtl::deref(model_p0).name, runtime_p1, std::move(gui_p3) ? Text::lit("\"canvas\"") : Text::lit(""));
    auto paths_p5 = rust_mod_paths(prism_rtl::deref(model_p0).mods);
    auto mods_p6 = concat(each(filter(paths_p5, [&](const Text& p_pi) { return !crate::syntax::lexer::chars::contains(p_pi, Text::lit(":")); }), [&](const Text& p_pj) { return prism_rtl::cat("mod ", p_pj, ";\n"); }));
    auto model_p0_1 = model_p0;
    auto scripts_p2_2 = scripts_p2;
    return call_value(each_job(all_programs(model_p0_1), ({
        auto model_p0_1_3 = model_p0_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::ProgDef)>>(prism_rtl::rc([=, model_p0_1_3 = std::move(model_p0_1_3)](crate::lower::model::ProgDef p0) {
        return ({
            auto model_p0_1_3_3 = model_p0_1_3;
            entered(once_job([=, model_p0_1_3_3 = std::move(model_p0_1_3_3)]() {
            return ({
                auto p_pk = p0;
                (prism_rtl::more(prism_rtl::rc(RustProgram(p_pk, node_fallible(model_p0_1_3_3, prism_rtl::deref(p_pk).node_)))));
            });
        }));
        });
    })));
    })), [=](Array<Text> each_20308) {
        return ({
            auto programs_p7 = crate::syntax::lexer::chars::join(each_20308, Text::lit("\n"));
            auto regs_p8 = concat(each(prism_rtl::deref(model_p0_1).programs, [&](const crate::lower::model::ProgDef& p_pl) { return prism_rtl::cat(".program::<", prism_rtl::deref(p_pl).name, ">(\"", prism_rtl::deref(p_pl).prism, "\")\n"); }));
            call_value(each_job(prism_rtl::deref(model_p0_1).checks, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::CheckDef)>>(prism_rtl::rc([=](crate::lower::model::CheckDef p0) {
            return entered(once_job([=]() {
                return ({
                    auto c_pm = p0;
                    call_value(each_job(prism_rtl::deref(c_pm).lines, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Ex)>>(prism_rtl::rc([=](crate::lower::model::Ex p0) {
                    return entered(once_job([=]() {
                        return ({
                            auto l_pn = p0;
                            (prism_rtl::more(prism_rtl::rc(crate::emit::rust::Expression(l_pn))));
                        });
                    }));
                }))), [=](Array<Text> each_20566) { return prism_rtl::finished(prism_rtl::cat(".check(\"", prism_rtl::deref(c_pm).name, "\", || vec![", crate::syntax::lexer::chars::join(each_20566, Text::lit(", ")), "])\n")); });
                });
            }));
        }))), [=, programs_p7 = std::move(programs_p7), regs_p8 = std::move(regs_p8)](Array<Text> each_20505) {
            return ({
                auto checks_p9 = concat(each_20505);
                auto script_list_pa = concat(each(scripts_p2_2, [&](const Text& s_po) { return prism_rtl::cat("\"", crate::lower::expr::escape(s_po), "\",\n"); }));
                auto run_root_pb = ({
                    __label__ _done;
                    prism_rtl::Slot<Text> _v;
                    auto&& _m = model_p0_1->root;
                    if (prism_rtl::is_some(_m)) {
                        auto&& r_pp = prism_rtl::some_of(_m);
                        _v.set(crate::emit::rust::templates::run_root(prism_rtl::deref(r_pp).name));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(crate::emit::rust::templates::no_root(prism_rtl::deref(model_p0_1).name));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                auto world_pc = ({
                    __label__ _done;
                    prism_rtl::Slot<Text> _v;
                    auto&& _m = model_p0_1->root;
                    if (prism_rtl::is_some(_m)) {
                        auto&& r_pq = prism_rtl::some_of(_m);
                        _v.set(r_pq->world);
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(Text::lit("test"));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                call_then(start_rust_row(prism_rtl::deref(model_p0_1).elem), [=, checks_p9 = std::move(checks_p9), script_list_pa = std::move(script_list_pa), run_root_pb = std::move(run_root_pb), world_pc = std::move(world_pc)](Text rust_row_20911) {
                return call_then(start_rust_answer(model_p0_1->answer), [=](Text rust_answer_20933) {
                    return ({
                        auto main_pd = crate::emit::rust::templates::main(prism_rtl::deref(model_p0_1).name, prism_rtl::cat("mod prelude;\n", mods_p6), prism_rtl::cat(rust_row_20911, "\n", rust_answer_20933, "\n", programs_p7), prism_rtl::cat(regs_p8, checks_p9), script_list_pa, run_root_pb, world_pc);
                        call_value(each_job(prism_rtl::deref(model_p0_1).mods, ({
                        auto paths_p5_3 = paths_p5;
                        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, Text>>(crate::lower::model::ModDef)>>(prism_rtl::rc([=, paths_p5_3 = std::move(paths_p5_3)](crate::lower::model::ModDef p0) {
                        return ({
                            auto paths_p5_3_4 = paths_p5_3;
                            entered(once_job([=, paths_p5_3_4 = std::move(paths_p5_3_4)]() {
                            return ({
                                auto m_pr = p0;
                                call_then(start_rust_module(m_pr, kids_of(paths_p5_3_4, prism_rtl::deref(m_pr).name)), [=](Text rust_module_21080) { return prism_rtl::finished(std::tuple{rust_mod_file(prism_rtl::deref(m_pr).name), rust_module_21080}); });
                            });
                        }));
                        });
                    }));
                    })), [=, main_pd = std::move(main_pd)](Array<std::tuple<Text, Text>> each_21033) {
                        return ({
                            auto files_pe = each_21033;
                            auto named_pf = each(prism_rtl::deref(model_p0_1).mods, [&](const crate::lower::model::ModDef& m_ps) { return prism_rtl::deref(m_ps).name; });
                            auto bare_pg = each(filter(paths_p5, [&](const Text& p_pt) { return !fold(named_pf, false, [&](const bool& f_pu, const Text& n_pv) { return prism_rtl::deref(f_pu) || (n_pv == p_pt); }); }), [&](const Text& p_p10) { return std::tuple{rust_mod_file(p_p10), prism_rtl::cat("//! Emitted by prismc: the modules under `", p_p10, "`, which declares nothing of its own.\n\n", kids_of(paths_p5, p_p10))}; });
                            (prism_rtl::finished(append(Array(std::vector{std::tuple{Text::lit("Cargo.toml"), cargo_p4}, std::tuple{Text::lit("src/main.rs"), main_pd}, std::tuple{Text::lit("src/prelude.rs"), crate::emit::rust::prelude::prelude_source(Text::lit(""))}}), append(files_pe, bare_pg))));
                        });
                    });
                    });
                });
            });
            });
        });
        });
    });
}


/// `Start EmitCrate, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<std::tuple<Text, Text>>> start_emit_crate(crate::lower::model::Model model_p0, Text runtime_p1, Array<Text> scripts_p2) {
    return prism_rtl::make_rc<EmitCrate>(model_p0, runtime_p1, scripts_p2);
}


/// RustModPaths: fn [ModDef] -> [Text]
Array<Text> rust_mod_paths(const Array<crate::lower::model::ModDef>& mods_p0) {
    return fold(mods_p0, Array<Text>{}, [&](const Array<Text>& acc_p1, const crate::lower::model::ModDef& m_p2) {
        return ({
            auto segs_p3 = split_on(prism_rtl::deref(m_p2).name, Text::lit("::"));
            fold(crate::check::errors::range0(len(segs_p3)), acc_p1, [&](const Array<Text>& a_p4, const Nat& i_p5) { return add_path(a_p4, crate::syntax::lexer::chars::join(take(segs_p3, i_p5 + Nat(1u)), Text::lit("::"))); });
        });
    });
}


/// AddPath: fn [Text], Text -> [Text]
Array<Text> add_path(const Array<Text>& ps_p0, const Text& p_p1) {
    return fold(ps_p0, false, [&](const bool& f_p2, const Text& q_p3) { return prism_rtl::deref(f_p2) || (q_p3 == p_p1); })
        ? ps_p0
        : crate::prelude::push(ps_p0, p_p1);
}


/// RustModFile: fn Text -> Text
Text rust_mod_file(const Text& p_p0) {
    return p_p0 == Text::lit("program")
        ? Text::lit("src/program.rs")
        : prism_rtl::cat("src/", crate::syntax::lexer::chars::join(split_on(p_p0, Text::lit("::")), Text::lit("/")), "/mod.rs");
}


/// KidsOf: fn [Text], Text -> Text
Text kids_of(const Array<Text>& paths_p0, const Text& p_p1) {
    return concat(each(filter(paths_p0, [&](const Text& q_p2) { return crate::syntax::lexer::chars::has_prefix(q_p2, prism_rtl::cat(p_p1, "::")) && (!crate::syntax::lexer::chars::contains(crate::syntax::lexer::chars::drop_prefix(q_p2, prism_rtl::cat(p_p1, "::")), Text::lit(":"))); }), [&](const Text& q_p3) { return prism_rtl::cat("pub mod ", crate::syntax::lexer::chars::drop_prefix(q_p3, prism_rtl::cat(p_p1, "::")), ";\n"); }));
}


/// AllPrograms: fn Model -> [ProgDef]
Array<crate::lower::model::ProgDef> all_programs(const crate::lower::model::Model& model_p0) {
    auto&& _m = model_p0.root;
    if (prism_rtl::is_some(_m)) {
        auto&& r_p1 = prism_rtl::some_of(_m);
        return fold(model_p0.programs, false, [&](const bool& f_p2, const crate::lower::model::ProgDef& p_p3) { return prism_rtl::deref(f_p2) || (prism_rtl::deref(p_p3).name == prism_rtl::deref(r_p1).name); })
            ? model_p0.programs
            : crate::prelude::push(model_p0.programs, r_p1);
    }
    if (prism_rtl::is_none(_m)) {
        return model_p0.programs;
    }
    prism_rtl::unreachable("no arm matched");
}

}  // namespace crate::emit::rust::items
