// The module `Check.Env.Names`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <check/env/names/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>

// The module `Check.Env.Names`, from `target/bootstrap/cpp-src/prismc/check/env/names.prism`.
namespace crate::check::env::names {

/// CollectNames: unbounded fn G, St, Text -> ((G, St))
std::tuple<crate::check::env::G, crate::check::types::St> collect_names_f(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const Text& m_p2) {
    auto&& _m = crate::prelude::get(g_p0.mods_p, m_p2);
    if (prism_rtl::is_none(_m)) {
        return std::tuple{g_p0, st_p1};
    }
    if (prism_rtl::is_some(_m)) {
        auto&& info_p3 = prism_rtl::some_of(_m);
        auto s0_p4 = ({
            crate::check::types::St this_ = st_p1;
            this_.file_p = prism_rtl::deref(info_p3).file_p;
            (std::move(this_));
        });
        auto&& _g2_p9 = crate::prelude::run_to_end(crate::prelude::fold_job(prism_rtl::deref(prism_rtl::deref(info_p3).tree_p).decls_p, std::tuple{g_p0, s0_p4, std::optional<Text>{}}, ({
            auto info_p3x = info_p3;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::env::G, crate::check::types::St, std::optional<Text>>>(std::tuple<std::tuple<crate::check::env::G, crate::check::types::St, std::optional<Text>>, crate::syntax::decls::Decl>)>>(prism_rtl::rc([=, info_p3x = std::move(info_p3x)](std::tuple<std::tuple<crate::check::env::G, crate::check::types::St, std::optional<Text>>, crate::syntax::decls::Decl> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto info_p3xy = info_p3x;
                (crate::prelude::entered(crate::prelude::once_job([=, info_p3xy = std::move(info_p3xy)]() {
                return ({
                    auto [gg_p5, s_p6, last_type_o7] = p0;
                    auto d_p8 = p1;
                    (prism_rtl::more(prism_rtl::rc(CollectDecl(gg_p5, s_p6, info_p3xy, d_p8, last_type_o7))));
                });
            })));
            });
        }));
        })));
        auto&& g2_p9 = std::get<0>(_g2_p9);
        auto&& s2_pa = std::get<1>(_g2_p9);
        return std::tuple{g2_p9, s2_pa};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<crate::check::env::G, crate::check::types::St>> CollectNames::cycle() const {
    const auto& g_p0 = this->g_p0;
    const auto& st_p1 = this->st_p1;
    const auto& m_p2 = this->m_p2;
    return ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(g_p0).mods_p, m_p2);
        prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{g_p0, st_p1})
        : prism_rtl::is_some(_m) ? ({
        auto&& info_p3 = prism_rtl::some_of(_m);
        ({
        auto s0_p4 = ({
            crate::check::types::St this_ = st_p1;
            this_.file_p = prism_rtl::deref(info_p3).file_p;
            (std::move(this_));
        });
        auto g_p0x = g_p0;
        (crate::prelude::call_value(crate::prelude::fold_job(prism_rtl::deref(prism_rtl::deref(info_p3).tree_p).decls_p, std::tuple{g_p0x, s0_p4, std::optional<Text>{}}, ({
        auto info_p3x = info_p3;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::env::G, crate::check::types::St, std::optional<Text>>>(std::tuple<std::tuple<crate::check::env::G, crate::check::types::St, std::optional<Text>>, crate::syntax::decls::Decl>)>>(prism_rtl::rc([=, info_p3x = std::move(info_p3x)](std::tuple<std::tuple<crate::check::env::G, crate::check::types::St, std::optional<Text>>, crate::syntax::decls::Decl> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto info_p3xy = info_p3x;
            (crate::prelude::entered(crate::prelude::once_job([=, info_p3xy = std::move(info_p3xy)]() {
            return ({
                auto [gg_p5, s_p6, last_type_o7] = p0;
                auto d_p8 = p1;
                (prism_rtl::more(prism_rtl::rc(CollectDecl(gg_p5, s_p6, info_p3xy, d_p8, last_type_o7))));
            });
        })));
        });
    }));
    })), [=](std::tuple<crate::check::env::G, crate::check::types::St, std::optional<Text>> fold_1030) {
        return ({
            auto&& _g2_p9 = fold_1030;
            auto&& g2_p9 = std::get<0>(_g2_p9);
            auto&& s2_pa = std::get<1>(_g2_p9);
            (prism_rtl::finished(std::tuple{g2_p9, s2_pa}));
        });
    }));
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CollectNames, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::env::G, crate::check::types::St>> start_collect_names_f(crate::check::env::G g_p0, crate::check::types::St st_p1, Text m_p2) {
    return prism_rtl::make_rc<CollectNames>(g_p0, st_p1, m_p2);
}


/// CollectDecl: unbounded fn G, St, ModInfo, Decl, ?Text -> ((G, St, ?Text))
std::tuple<crate::check::env::G, crate::check::types::St, std::optional<Text>> collect_decl_f(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const crate::check::env::ModInfo& info_p2, const crate::syntax::decls::Decl& d_p3, const std::optional<Text>& last_type_o4) {
    auto&& _m = d_p3.kind_p;
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DType>(_m)) {
        auto&& t_p5 = prism_rtl::as<crate::syntax::decls::DeclKind::DType>(_m).a0;
        auto name_p6 = crate::check::env::qual_key_f(info_p2.name_p, crate::check::env::dotted_f(prism_rtl::deref(prism_rtl::deref(t_p5).name_p).path_p));
        auto ti_p7 = crate::check::env::TyInfo{.name_p = name_p6, .home_p = info_p2.name_p, .params_p = crate::prelude::each(prism_rtl::deref(t_p5).params_p, [&](const crate::syntax::Ident& p_p8) { return prism_rtl::deref(p_p8).name_p; }), .body_p = crate::check::env::TyBody(crate::check::env::TyBody::BOpaque{}), .derives_p = Array<Text>{}, .file_p = info_p2.file_p, .span_p = d_p3.span_p};
        return crate::check::env::has_key_f(g_p0.types_p, name_p6)
            ? std::tuple{g_p0, crate::check::types::recording::err_f(st_p1, Text::lit("collision"), d_p3.span_p, prism_rtl::cat("a second type `", crate::check::env::dotted_f(prism_rtl::deref(prism_rtl::deref(t_p5).name_p).path_p), "`")), last_type_o4}
            : ({
            auto upd_p9 = ({
                crate::check::env::G this_ = g_p0;
                this_.types_p = crate::prelude::insert(this_.types_p, name_p6, ti_p7);
                (std::move(this_));
            });
            std::tuple{upd_p9, st_p1, std::optional(name_p6)};
        });
    }
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DDerive>(_m)) {
        auto&& trs_pa = prism_rtl::as<crate::syntax::decls::DeclKind::DDerive>(_m).a0;
        if (prism_rtl::is_some(last_type_o4)) {
            auto&& tn_pb = prism_rtl::some_of(last_type_o4);
            auto upd_pc = ({
                crate::check::env::G this_ = g_p0;
                this_.types_p = crate::prelude::insert(this_.types_p, tn_pb, add_derives_f(crate::prelude::or_(crate::prelude::get(g_p0.types_p, tn_pb), dummy_ty_info_p()), crate::prelude::each(trs_pa, [&](const crate::syntax::TraitRef& tr_pd) { return crate::check::env::dotted_f(prism_rtl::deref(tr_pd).path_p); })));
                (std::move(this_));
            });
            return std::tuple{upd_pc, st_p1, last_type_o4};
        }
        if (prism_rtl::is_none(last_type_o4)) {
            return std::tuple{g_p0, crate::check::types::recording::err_f(st_p1, Text::lit("mismatch"), d_p3.span_p, Text::lit("a `derive` line follows a type declaration")), std::optional<Text>{}};
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DTag>(_m)) {
        auto&& t_pe = prism_rtl::as<crate::syntax::decls::DeclKind::DTag>(_m).a0;
        auto name_pf = crate::check::env::dotted_f(prism_rtl::deref(prism_rtl::deref(t_pe).name_p).path_p);
        auto family_pg = crate::check::env::dotted_f(crate::prelude::take(prism_rtl::deref(prism_rtl::deref(t_pe).name_p).path_p, crate::syntax::lexer::chars::dec_f(crate::prelude::len(prism_rtl::deref(prism_rtl::deref(t_pe).name_p).path_p))));
        auto tags_ph = crate::prelude::or_(crate::prelude::get(g_p0.families_p, family_pg), Array<Text>{});
        auto owner_pi = crate::prelude::or_(crate::prelude::get(g_p0.fam_owner_p, family_pg), info_p2.name_p);
        auto st2_pj = owner_pi != info_p2.name_p
            ? crate::check::types::recording::err_f(st_p1, Text::lit("collision"), d_p3.span_p, prism_rtl::cat("the family `", family_pg, "` is declared in ", owner_pi == Text::lit("")
            ? Text::lit("the root")
            : prism_rtl::cat("`", owner_pi, "`"), "; every tag of a family is declared in its family\'s module"))
            : st_p1;
        auto is_elem_pk = ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            auto&& _m = prism_rtl::deref(prism_rtl::deref(prism_rtl::deref(t_pe).of_type_p).kind_p);
            if (prism_rtl::is<crate::syntax::TypeKind::TName>(_m)) {
                auto&& n_pm = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a0;
                _v.set(crate::check::env::dotted_f(prism_rtl::deref(n_pm).path_p) == Text::lit("Element"));
                goto _done;
            }
            {
                _v.set(false);
                goto _done;
            }
        _done:
            _v.take();
        });
        auto g2_pl = ({
            crate::check::env::G this_ = g_p0;
            this_.families_p = crate::prelude::insert(this_.families_p, family_pg, crate::prelude::push(tags_ph, name_pf));
            this_.fam_owner_p = crate::prelude::insert(this_.fam_owner_p, family_pg, owner_pi);
            if (std::move(is_elem_pk)) {
                this_.elem_fams_p = crate::check::types::add_text_f(this_.elem_fams_p, family_pg);
            }
            (std::move(this_));
        });
        return std::tuple{g2_pl, st2_pj, std::optional<Text>{}};
    }
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DTrait>(_m)) {
        auto&& t_pn = prism_rtl::as<crate::syntax::decls::DeclKind::DTrait>(_m).a0;
        auto name_po = crate::check::env::qual_key_f(info_p2.name_p, crate::check::env::dotted_f(prism_rtl::deref(prism_rtl::deref(t_pn).name_p).path_p));
        auto ti_pp = crate::check::env::TraitInfo{.name_p = name_po, .home_p = info_p2.name_p, .param_p = crate::prelude::or_(crate::prelude::index(crate::prelude::each(prism_rtl::deref(t_pn).params_p, [&](const crate::syntax::Ident& p_pr) { return prism_rtl::deref(p_pr).name_p; }), Nat(0u)), Text::lit("a")), .supers_p = Array<Text>{}, .methods_p = Array<Text>{}, .defaults_p = Array<Text>{}, .assocs_p = Array<Text>{}, .file_p = info_p2.file_p, .span_p = d_p3.span_p};
        auto upd_pq = ({
            crate::check::env::G this_ = g_p0;
            this_.traits_p = crate::prelude::insert(this_.traits_p, name_po, ti_pp);
            (std::move(this_));
        });
        return std::tuple{upd_pq, st_p1, std::optional<Text>{}};
    }
    {
        return std::tuple{g_p0, st_p1, std::optional<Text>{}};
    }
}


prism_rtl::Turn<std::tuple<crate::check::env::G, crate::check::types::St, std::optional<Text>>> CollectDecl::cycle() const {
    const auto& g_p0 = this->g_p0;
    const auto& st_p1 = this->st_p1;
    const auto& info_p2 = this->info_p2;
    const auto& d_p3 = this->d_p3;
    const auto& last_type_o4 = this->last_type_o4;
    return ({
        auto&& _m = prism_rtl::deref(d_p3).kind_p;
        prism_rtl::is<crate::syntax::decls::DeclKind::DType>(_m) ? ({
        auto&& t_p5 = prism_rtl::as<crate::syntax::decls::DeclKind::DType>(_m).a0;
        ({
        auto name_p6 = crate::check::env::qual_key_f(prism_rtl::deref(info_p2).name_p, crate::check::env::dotted_f(prism_rtl::deref(prism_rtl::deref(t_p5).name_p).path_p));
        auto ti_p7 = crate::check::env::TyInfo{.name_p = name_p6, .home_p = prism_rtl::deref(info_p2).name_p, .params_p = crate::prelude::each(prism_rtl::deref(t_p5).params_p, [&](const crate::syntax::Ident& p_p8) { return prism_rtl::deref(p_p8).name_p; }), .body_p = crate::check::env::TyBody(crate::check::env::TyBody::BOpaque{}), .derives_p = Array<Text>{}, .file_p = prism_rtl::deref(info_p2).file_p, .span_p = prism_rtl::deref(d_p3).span_p};
        (crate::check::env::has_key_f(prism_rtl::deref(g_p0).types_p, name_p6)
        ? prism_rtl::finished(std::tuple{g_p0, crate::check::types::recording::err_f(st_p1, Text::lit("collision"), prism_rtl::deref(d_p3).span_p, prism_rtl::cat("a second type `", crate::check::env::dotted_f(prism_rtl::deref(prism_rtl::deref(t_p5).name_p).path_p), "`")), last_type_o4})
        : ({
        auto upd_p9 = ({
            crate::check::env::G this_ = g_p0;
            this_.types_p = crate::prelude::insert(this_.types_p, name_p6, ti_p7);
            (std::move(this_));
        });
        (prism_rtl::finished(std::tuple{upd_p9, st_p1, std::optional(name_p6)}));
    }));
    });
    })
        : prism_rtl::is<crate::syntax::decls::DeclKind::DDerive>(_m) ? ({
        auto&& trs_pa = prism_rtl::as<crate::syntax::decls::DeclKind::DDerive>(_m).a0;
        ({
        prism_rtl::is_some(last_type_o4) ? ({
        auto&& tn_pb = prism_rtl::some_of(last_type_o4);
        ({
        auto upd_pc = ({
            crate::check::env::G this_ = g_p0;
            this_.types_p = crate::prelude::insert(this_.types_p, tn_pb, add_derives_f(crate::prelude::or_(crate::prelude::get(prism_rtl::deref(g_p0).types_p, tn_pb), dummy_ty_info_p()), crate::prelude::each(trs_pa, [&](const crate::syntax::TraitRef& tr_pd) { return crate::check::env::dotted_f(prism_rtl::deref(tr_pd).path_p); })));
            (std::move(this_));
        });
        (prism_rtl::finished(std::tuple{upd_pc, st_p1, last_type_o4}));
    });
    })
        : prism_rtl::is_none(last_type_o4) ? prism_rtl::finished(std::tuple{g_p0, crate::check::types::recording::err_f(st_p1, Text::lit("mismatch"), prism_rtl::deref(d_p3).span_p, Text::lit("a `derive` line follows a type declaration")), std::optional<Text>{}})
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : prism_rtl::is<crate::syntax::decls::DeclKind::DTag>(_m) ? ({
        auto&& t_pe = prism_rtl::as<crate::syntax::decls::DeclKind::DTag>(_m).a0;
        ({
        auto name_pf = crate::check::env::dotted_f(prism_rtl::deref(prism_rtl::deref(t_pe).name_p).path_p);
        auto family_pg = crate::check::env::dotted_f(crate::prelude::take(prism_rtl::deref(prism_rtl::deref(t_pe).name_p).path_p, crate::syntax::lexer::chars::dec_f(crate::prelude::len(prism_rtl::deref(prism_rtl::deref(t_pe).name_p).path_p))));
        auto tags_ph = crate::prelude::or_(crate::prelude::get(prism_rtl::deref(g_p0).families_p, family_pg), Array<Text>{});
        auto owner_pi = crate::prelude::or_(crate::prelude::get(prism_rtl::deref(g_p0).fam_owner_p, family_pg), prism_rtl::deref(info_p2).name_p);
        auto st2_pj = owner_pi != prism_rtl::deref(info_p2).name_p
            ? crate::check::types::recording::err_f(st_p1, Text::lit("collision"), prism_rtl::deref(d_p3).span_p, prism_rtl::cat("the family `", family_pg, "` is declared in ", owner_pi == Text::lit("")
            ? Text::lit("the root")
            : prism_rtl::cat("`", owner_pi, "`"), "; every tag of a family is declared in its family\'s module"))
            : st_p1;
        auto is_elem_pk = ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            auto&& _m = prism_rtl::deref(prism_rtl::deref(prism_rtl::deref(t_pe).of_type_p).kind_p);
            if (prism_rtl::is<crate::syntax::TypeKind::TName>(_m)) {
                auto&& n_pm = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a0;
                _v.set(crate::check::env::dotted_f(prism_rtl::deref(n_pm).path_p) == Text::lit("Element"));
                goto _done;
            }
            {
                _v.set(false);
                goto _done;
            }
        _done:
            _v.take();
        });
        auto g2_pl = ({
            crate::check::env::G this_ = g_p0;
            this_.families_p = crate::prelude::insert(this_.families_p, family_pg, crate::prelude::push(tags_ph, name_pf));
            this_.fam_owner_p = crate::prelude::insert(this_.fam_owner_p, family_pg, owner_pi);
            if (std::move(is_elem_pk)) {
                this_.elem_fams_p = crate::check::types::add_text_f(this_.elem_fams_p, family_pg);
            }
            (std::move(this_));
        });
        (prism_rtl::finished(std::tuple{g2_pl, st2_pj, std::optional<Text>{}}));
    });
    })
        : prism_rtl::is<crate::syntax::decls::DeclKind::DTrait>(_m) ? ({
        auto&& t_pn = prism_rtl::as<crate::syntax::decls::DeclKind::DTrait>(_m).a0;
        ({
        auto name_po = crate::check::env::qual_key_f(prism_rtl::deref(info_p2).name_p, crate::check::env::dotted_f(prism_rtl::deref(prism_rtl::deref(t_pn).name_p).path_p));
        auto ti_pp = crate::check::env::TraitInfo{.name_p = name_po, .home_p = prism_rtl::deref(info_p2).name_p, .param_p = crate::prelude::or_(crate::prelude::index(crate::prelude::each(prism_rtl::deref(t_pn).params_p, [&](const crate::syntax::Ident& p_pr) { return prism_rtl::deref(p_pr).name_p; }), Nat(0u)), Text::lit("a")), .supers_p = Array<Text>{}, .methods_p = Array<Text>{}, .defaults_p = Array<Text>{}, .assocs_p = Array<Text>{}, .file_p = prism_rtl::deref(info_p2).file_p, .span_p = prism_rtl::deref(d_p3).span_p};
        auto upd_pq = ({
            crate::check::env::G this_ = g_p0;
            this_.traits_p = crate::prelude::insert(this_.traits_p, name_po, ti_pp);
            (std::move(this_));
        });
        (prism_rtl::finished(std::tuple{upd_pq, st_p1, std::optional<Text>{}}));
    });
    })
        : prism_rtl::finished(std::tuple{g_p0, st_p1, std::optional<Text>{}});
    });
}


/// `Start CollectDecl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::env::G, crate::check::types::St, std::optional<Text>>> start_collect_decl_f(crate::check::env::G g_p0, crate::check::types::St st_p1, crate::check::env::ModInfo info_p2, crate::syntax::decls::Decl d_p3, std::optional<Text> last_type_o4) {
    return prism_rtl::make_rc<CollectDecl>(g_p0, st_p1, info_p2, d_p3, last_type_o4);
}


/// let dummyTyInfo
crate::check::env::TyInfo dummy_ty_info_p() {
    return crate::check::env::TyInfo{.name_p = Text::lit(""), .home_p = Text::lit(""), .params_p = Array<Text>{}, .body_p = crate::check::env::TyBody(crate::check::env::TyBody::BOpaque{}), .derives_p = Array<Text>{}, .file_p = Nat(0u), .span_p = crate::syntax::Range{.start_p = Nat(0u), .end_p = Nat(0u)}};
}


/// AddDerives: fn TyInfo, [Text] -> TyInfo
crate::check::env::TyInfo add_derives_f(const crate::check::env::TyInfo& ti_p0, const Array<Text>& trs_p1) {
    crate::check::env::TyInfo this_ = ti_p0;
    this_.derives_p = crate::prelude::append(this_.derives_p, trs_p1);
    return this_;
}


/// ProgramRow: fn G -> Rw
crate::check::types::Rw program_row_f(const crate::check::env::G& g_p0) {
    return crate::check::types::closed_f(g_p0.elem_fams_p);
}


/// BuildTables: unbounded fn G, St, Text -> ((G, St))
std::tuple<crate::check::env::G, crate::check::types::St> build_tables_f(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const Text& m_p2) {
    auto&& _m = crate::prelude::get(g_p0.mods_p, m_p2);
    if (prism_rtl::is_none(_m)) {
        return std::tuple{g_p0, st_p1};
    }
    if (prism_rtl::is_some(_m)) {
        auto&& info_p3 = prism_rtl::some_of(_m);
        auto s0_p4 = ({
            crate::check::types::St this_ = st_p1;
            this_.file_p = prism_rtl::deref(info_p3).file_p;
            (std::move(this_));
        });
        auto s1_p5 = crate::prelude::fold(prism_rtl::deref(info_p3).uses_p, s0_p4, [&](const crate::check::types::St& s_pd, const std::tuple<Text, bool>& _p1) {
            auto&& u_pe = std::get<0>(_p1);
            return crate::check::env::has_key_f(g_p0.mods_p, u_pe) || (u_pe == Text::lit("Prelude"))
                ? s_pd
                : crate::check::types::recording::err_f(s_pd, Text::lit("unknown-name"), prism_rtl::deref(prism_rtl::deref(info_p3).tree_p).span_p, prism_rtl::cat("no module `", u_pe, "` among the program\'s files"));
        });
        auto starred_p6 = crate::prelude::fold(prism_rtl::deref(info_p3).uses_p, Array<Text>{}, [&](const Array<Text>& acc_pf, const std::tuple<Text, bool>& _p1) {
            auto&& u_pg = std::get<0>(_p1);
            auto&& star_ph = std::get<1>(_p1);
            return prism_rtl::deref(star_ph) && (u_pg != m_p2)
                ? crate::prelude::push(acc_pf, u_pg)
                : acc_pf;
        });
        auto sources_p7 = crate::check::types::add_text_f(crate::prelude::append(Array(std::vector{m_p2}), starred_p6), Text::lit("Prelude"));
        auto vals_p8 = crate::prelude::run_to_end(crate::prelude::fold_job(sources_p7, Map<Text, Array<Text>>{}, ({
            auto g_p0x = g_p0;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Array<Text>>>(std::tuple<Map<Text, Array<Text>>, Text>)>>(prism_rtl::rc([=, g_p0x = std::move(g_p0x)](std::tuple<Map<Text, Array<Text>>, Text> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto g_p0xy = g_p0x;
                (crate::prelude::entered(crate::prelude::once_job([=, g_p0xy = std::move(g_p0xy)]() {
                return ({
                    auto acc_pi = p0;
                    auto src_pj = p1;
                    (prism_rtl::more(prism_rtl::rc(BareValuesOf(g_p0xy, src_pj, acc_pi))));
                });
            })));
            });
        }));
        })));
        auto tys_p9 = crate::prelude::fold(sources_p7, Map<Text, Array<Text>>{}, [&](const Map<Text, Array<Text>>& acc_pk, const Text& src_pl) { return bare_types_of_f(g_p0, src_pl, acc_pk); });
        auto trs_pa = crate::prelude::fold(sources_p7, Map<Text, Array<Text>>{}, [&](const Map<Text, Array<Text>>& acc_pm, const Text& src_pn) { return bare_traits_of_f(g_p0, src_pn, acc_pm); });
        auto [rw_po, rv_pp, s2_pq] = module_row_f(g_p0, s1_p5, info_p3);
        auto info2_pb = ({
            crate::check::env::ModInfo this_ = info_p3;
            this_.emit_rw_p = rw_po;
            this_.row_var_p = rv_pp;
            (std::move(this_));
        });
        auto upd_pc = ({
            crate::check::env::G this_ = g_p0;
            this_.bare_p = crate::prelude::insert(this_.bare_p, m_p2, vals_p8);
            this_.bare_types_p = crate::prelude::insert(this_.bare_types_p, m_p2, tys_p9);
            this_.bare_traits_p = crate::prelude::insert(this_.bare_traits_p, m_p2, trs_pa);
            this_.mods_p = crate::prelude::insert(this_.mods_p, m_p2, info2_pb);
            (std::move(this_));
        });
        return std::tuple{upd_pc, s2_pq};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<crate::check::env::G, crate::check::types::St>> BuildTables::cycle() const {
    const auto& g_p0 = this->g_p0;
    const auto& st_p1 = this->st_p1;
    const auto& m_p2 = this->m_p2;
    return ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(g_p0).mods_p, m_p2);
        prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{g_p0, st_p1})
        : prism_rtl::is_some(_m) ? ({
        auto&& info_p3 = prism_rtl::some_of(_m);
        ({
        auto s0_p4 = ({
            crate::check::types::St this_ = st_p1;
            this_.file_p = prism_rtl::deref(info_p3).file_p;
            (std::move(this_));
        });
        auto s1_p5 = crate::prelude::fold(prism_rtl::deref(info_p3).uses_p, s0_p4, [&](const crate::check::types::St& s_pd, const std::tuple<Text, bool>& _p1) {
            auto&& u_pe = std::get<0>(_p1);
            return crate::check::env::has_key_f(prism_rtl::deref(g_p0).mods_p, u_pe) || (u_pe == Text::lit("Prelude"))
                ? s_pd
                : crate::check::types::recording::err_f(s_pd, Text::lit("unknown-name"), prism_rtl::deref(prism_rtl::deref(info_p3).tree_p).span_p, prism_rtl::cat("no module `", u_pe, "` among the program\'s files"));
        });
        auto starred_p6 = crate::prelude::fold(prism_rtl::deref(info_p3).uses_p, Array<Text>{}, [&](const Array<Text>& acc_pf, const std::tuple<Text, bool>& _p1) {
            auto&& u_pg = std::get<0>(_p1);
            auto&& star_ph = std::get<1>(_p1);
            return prism_rtl::deref(star_ph) && (u_pg != m_p2)
                ? crate::prelude::push(acc_pf, u_pg)
                : acc_pf;
        });
        auto sources_p7 = crate::check::types::add_text_f(crate::prelude::append(Array(std::vector{m_p2}), starred_p6), Text::lit("Prelude"));
        auto g_p0x = g_p0;
        auto m_p2x = m_p2;
        (crate::prelude::call_value(crate::prelude::fold_job(sources_p7, Map<Text, Array<Text>>{}, ({
        auto g_p0xx = g_p0x;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Array<Text>>>(std::tuple<Map<Text, Array<Text>>, Text>)>>(prism_rtl::rc([=, g_p0xx = std::move(g_p0xx)](std::tuple<Map<Text, Array<Text>>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_p0xxy = g_p0xx;
            (crate::prelude::entered(crate::prelude::once_job([=, g_p0xxy = std::move(g_p0xxy)]() {
            return ({
                auto acc_pi = p0;
                auto src_pj = p1;
                (prism_rtl::more(prism_rtl::rc(BareValuesOf(g_p0xxy, src_pj, acc_pi))));
            });
        })));
        });
    }));
    })), [=, s1_p5 = std::move(s1_p5), m_p2x = std::move(m_p2x)](Map<Text, Array<Text>> fold_4611) {
        return ({
            auto vals_p8 = fold_4611;
            auto tys_p9 = crate::prelude::fold(sources_p7, Map<Text, Array<Text>>{}, [&](const Map<Text, Array<Text>>& acc_pk, const Text& src_pl) { return bare_types_of_f(g_p0x, src_pl, acc_pk); });
            auto trs_pa = crate::prelude::fold(sources_p7, Map<Text, Array<Text>>{}, [&](const Map<Text, Array<Text>>& acc_pm, const Text& src_pn) { return bare_traits_of_f(g_p0x, src_pn, acc_pm); });
            (crate::prelude::call_then(start_module_row_f(g_p0x, s1_p5, info_p3), [=, vals_p8 = std::move(vals_p8), tys_p9 = std::move(tys_p9), trs_pa = std::move(trs_pa)](std::tuple<crate::check::types::Rw, Text, crate::check::types::St> module_row_f_4840) {
            return ({
                auto [rw_po, rv_pp, s2_pq] = module_row_f_4840;
                auto info2_pb = ({
                    crate::check::env::ModInfo this_ = info_p3;
                    this_.emit_rw_p = rw_po;
                    this_.row_var_p = rv_pp;
                    (std::move(this_));
                });
                auto upd_pc = ({
                    crate::check::env::G this_ = g_p0x;
                    this_.bare_p = crate::prelude::insert(this_.bare_p, m_p2x, vals_p8);
                    this_.bare_types_p = crate::prelude::insert(this_.bare_types_p, m_p2x, tys_p9);
                    this_.bare_traits_p = crate::prelude::insert(this_.bare_traits_p, m_p2x, trs_pa);
                    this_.mods_p = crate::prelude::insert(this_.mods_p, m_p2x, info2_pb);
                    (std::move(this_));
                });
                (prism_rtl::finished(std::tuple{upd_pc, s2_pq}));
            });
        }));
        });
    }));
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start BuildTables, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::env::G, crate::check::types::St>> start_build_tables_f(crate::check::env::G g_p0, crate::check::types::St st_p1, Text m_p2) {
    return prism_rtl::make_rc<BuildTables>(g_p0, st_p1, m_p2);
}


/// AddBare: fn (Text ==> [Text]), Text, Text -> (Text ==> [Text])
Map<Text, Array<Text>> add_bare_f(const Map<Text, Array<Text>>& acc_p0, const Text& name_p1, const Text& qk_p2) {
    auto have_p3 = crate::prelude::or_(crate::prelude::get(acc_p0, name_p1), Array<Text>{});
    return crate::check::types::has_text_f(have_p3, qk_p2)
        ? acc_p0
        : crate::prelude::insert(acc_p0, name_p1, crate::prelude::push(have_p3, qk_p2));
}


/// BareValuesOf: unbounded fn G, Text, (Text ==> [Text]) -> (Text ==> [Text])
Map<Text, Array<Text>> bare_values_of_f(const crate::check::env::G& g_p0, const Text& src_p1, const Map<Text, Array<Text>>& acc_p2) {
    auto&& _m = crate::prelude::get(g_p0.mods_p, src_p1);
    if (prism_rtl::is_none(_m)) {
        return acc_p2;
    }
    if (prism_rtl::is_some(_m)) {
        auto&& info_p3 = prism_rtl::some_of(_m);
        return crate::prelude::run_to_end(crate::prelude::fold_job(prism_rtl::deref(prism_rtl::deref(info_p3).tree_p).decls_p, acc_p2, ({
            auto src_p1x = src_p1;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Array<Text>>>(std::tuple<Map<Text, Array<Text>>, crate::syntax::decls::Decl>)>>(prism_rtl::rc([=, src_p1x = std::move(src_p1x)](std::tuple<Map<Text, Array<Text>>, crate::syntax::decls::Decl> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto src_p1xy = src_p1x;
                (crate::prelude::entered(crate::prelude::once_job([=, src_p1xy = std::move(src_p1xy)]() {
                return ({
                    auto a_p4 = p0;
                    auto d_p5 = p1;
                    (prism_rtl::more(prism_rtl::rc(BareOfDecl(src_p1xy, a_p4, d_p5))));
                });
            })));
            });
        }));
        })));
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Map<Text, Array<Text>>> BareValuesOf::cycle() const {
    const auto& g_p0 = this->g_p0;
    const auto& src_p1 = this->src_p1;
    const auto& acc_p2 = this->acc_p2;
    return ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(g_p0).mods_p, src_p1);
        prism_rtl::is_none(_m) ? prism_rtl::finished(acc_p2)
        : prism_rtl::is_some(_m) ? ({
        auto&& info_p3 = prism_rtl::some_of(_m);
        crate::prelude::fold_job(prism_rtl::deref(prism_rtl::deref(info_p3).tree_p).decls_p, acc_p2, ({
        auto src_p1x = src_p1;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Array<Text>>>(std::tuple<Map<Text, Array<Text>>, crate::syntax::decls::Decl>)>>(prism_rtl::rc([=, src_p1x = std::move(src_p1x)](std::tuple<Map<Text, Array<Text>>, crate::syntax::decls::Decl> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto src_p1xy = src_p1x;
            (crate::prelude::entered(crate::prelude::once_job([=, src_p1xy = std::move(src_p1xy)]() {
            return ({
                auto a_p4 = p0;
                auto d_p5 = p1;
                (prism_rtl::more(prism_rtl::rc(BareOfDecl(src_p1xy, a_p4, d_p5))));
            });
        })));
        });
    }));
    }))->cycle();
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start BareValuesOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, Array<Text>>> start_bare_values_of_f(crate::check::env::G g_p0, Text src_p1, Map<Text, Array<Text>> acc_p2) {
    return prism_rtl::make_rc<BareValuesOf>(g_p0, src_p1, acc_p2);
}


/// BareOfDecl: unbounded fn Text, (Text ==> [Text]), Decl -> (Text ==> [Text])
Map<Text, Array<Text>> bare_of_decl_f(const Text& m_p0, const Map<Text, Array<Text>>& acc_p1, const crate::syntax::decls::Decl& d_p2) {
    auto&& _m = d_p2.kind_p;
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DSignature>(_m)) {
        auto&& s_p3 = prism_rtl::as<crate::syntax::decls::DeclKind::DSignature>(_m).a0;
        return add_bare_f(acc_p1, crate::check::env::def_name_text_f(prism_rtl::deref(s_p3).name_p), crate::check::env::qual_key_f(m_p0, crate::check::env::def_name_text_f(prism_rtl::deref(s_p3).name_p)));
    }
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DFn>(_m)) {
        auto&& f_p4 = prism_rtl::as<crate::syntax::decls::DeclKind::DFn>(_m).a0;
        return add_bare_f(acc_p1, crate::check::env::def_name_text_f(prism_rtl::deref(f_p4).name_p), crate::check::env::qual_key_f(m_p0, crate::check::env::def_name_text_f(prism_rtl::deref(f_p4).name_p)));
    }
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DLet>(_m)) {
        auto&& l_p5 = prism_rtl::as<crate::syntax::decls::DeclKind::DLet>(_m).a0;
        return crate::prelude::fold(pattern_names_f(prism_rtl::deref(l_p5).pattern_p), acc_p1, [&](const Map<Text, Array<Text>>& a_p6, const Text& n_p7) { return add_bare_f(a_p6, n_p7, crate::check::env::qual_key_f(m_p0, n_p7)); });
    }
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DWidget>(_m)) {
        auto&& w_p8 = prism_rtl::as<crate::syntax::decls::DeclKind::DWidget>(_m).a0;
        return add_bare_f(acc_p1, crate::check::env::sname_key_f(prism_rtl::deref(w_p8).name_p), crate::check::env::qual_key_f(m_p0, crate::check::env::sname_key_f(prism_rtl::deref(w_p8).name_p)));
    }
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DType>(_m)) {
        auto&& t_p9 = prism_rtl::as<crate::syntax::decls::DeclKind::DType>(_m).a0;
        return crate::prelude::fold(ctor_names_of_f(t_p9), acc_p1, [&](const Map<Text, Array<Text>>& a_pa, const Text& c_pb) { return add_bare_f(a_pa, c_pb, crate::check::env::qual_key_f(m_p0, c_pb)); });
    }
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DTrait>(_m)) {
        auto&& t_pc = prism_rtl::as<crate::syntax::decls::DeclKind::DTrait>(_m).a0;
        return crate::prelude::fold(prism_rtl::deref(t_pc).items_p, acc_p1, [&](const Map<Text, Array<Text>>& a_pd, const crate::syntax::decls::TraitItem& it_pe) {
            return ({
                __label__ _done;
                prism_rtl::Slot<Map<Text, Array<Text>>> _v;
                if (prism_rtl::is<crate::syntax::decls::TraitItem::TiSignature>(it_pe)) {
                    auto&& s_pf = prism_rtl::as<crate::syntax::decls::TraitItem::TiSignature>(it_pe).a0;
                    _v.set(add_bare_f(a_pd, crate::check::env::def_name_text_f(prism_rtl::deref(s_pf).name_p), crate::check::env::qual_key_f(m_p0, crate::check::env::def_name_text_f(prism_rtl::deref(s_pf).name_p))));
                    goto _done;
                }
                {
                    _v.set(a_pd);
                    goto _done;
                }
            _done:
                _v.take();
            });
        });
    }
    {
        return acc_p1;
    }
}


prism_rtl::Turn<Map<Text, Array<Text>>> BareOfDecl::cycle() const {
    const auto& m_p0 = this->m_p0;
    const auto& acc_p1 = this->acc_p1;
    const auto& d_p2 = this->d_p2;
    return ({
        auto&& _m = prism_rtl::deref(d_p2).kind_p;
        prism_rtl::is<crate::syntax::decls::DeclKind::DSignature>(_m) ? ({
        auto&& s_p3 = prism_rtl::as<crate::syntax::decls::DeclKind::DSignature>(_m).a0;
        prism_rtl::finished(add_bare_f(acc_p1, crate::check::env::def_name_text_f(prism_rtl::deref(s_p3).name_p), crate::check::env::qual_key_f(m_p0, crate::check::env::def_name_text_f(prism_rtl::deref(s_p3).name_p))));
    })
        : prism_rtl::is<crate::syntax::decls::DeclKind::DFn>(_m) ? ({
        auto&& f_p4 = prism_rtl::as<crate::syntax::decls::DeclKind::DFn>(_m).a0;
        prism_rtl::finished(add_bare_f(acc_p1, crate::check::env::def_name_text_f(prism_rtl::deref(f_p4).name_p), crate::check::env::qual_key_f(m_p0, crate::check::env::def_name_text_f(prism_rtl::deref(f_p4).name_p))));
    })
        : prism_rtl::is<crate::syntax::decls::DeclKind::DLet>(_m) ? ({
        auto&& l_p5 = prism_rtl::as<crate::syntax::decls::DeclKind::DLet>(_m).a0;
        ({
        auto acc_p1x = acc_p1;
        auto l_p5x = l_p5;
        auto m_p0x = m_p0;
        (crate::prelude::call_then(start_pattern_names_f(prism_rtl::deref(l_p5x).pattern_p), [=, acc_p1x = std::move(acc_p1x), m_p0x = std::move(m_p0x)](Array<Text> pattern_names_f_5985) { return prism_rtl::finished(crate::prelude::fold(pattern_names_f_5985, acc_p1x, [&](const Map<Text, Array<Text>>& a_p6, const Text& n_p7) { return add_bare_f(a_p6, n_p7, crate::check::env::qual_key_f(m_p0x, n_p7)); })); }));
    });
    })
        : prism_rtl::is<crate::syntax::decls::DeclKind::DWidget>(_m) ? ({
        auto&& w_p8 = prism_rtl::as<crate::syntax::decls::DeclKind::DWidget>(_m).a0;
        prism_rtl::finished(add_bare_f(acc_p1, crate::check::env::sname_key_f(prism_rtl::deref(w_p8).name_p), crate::check::env::qual_key_f(m_p0, crate::check::env::sname_key_f(prism_rtl::deref(w_p8).name_p))));
    })
        : prism_rtl::is<crate::syntax::decls::DeclKind::DType>(_m) ? ({
        auto&& t_p9 = prism_rtl::as<crate::syntax::decls::DeclKind::DType>(_m).a0;
        prism_rtl::finished(crate::prelude::fold(ctor_names_of_f(t_p9), acc_p1, [&](const Map<Text, Array<Text>>& a_pa, const Text& c_pb) { return add_bare_f(a_pa, c_pb, crate::check::env::qual_key_f(m_p0, c_pb)); }));
    })
        : prism_rtl::is<crate::syntax::decls::DeclKind::DTrait>(_m) ? ({
        auto&& t_pc = prism_rtl::as<crate::syntax::decls::DeclKind::DTrait>(_m).a0;
        prism_rtl::finished(crate::prelude::fold(prism_rtl::deref(t_pc).items_p, acc_p1, [&](const Map<Text, Array<Text>>& a_pd, const crate::syntax::decls::TraitItem& it_pe) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Map<Text, Array<Text>>> _v;
            if (prism_rtl::is<crate::syntax::decls::TraitItem::TiSignature>(it_pe)) {
                auto&& s_pf = prism_rtl::as<crate::syntax::decls::TraitItem::TiSignature>(it_pe).a0;
                _v.set(add_bare_f(a_pd, crate::check::env::def_name_text_f(prism_rtl::deref(s_pf).name_p), crate::check::env::qual_key_f(m_p0, crate::check::env::def_name_text_f(prism_rtl::deref(s_pf).name_p))));
                goto _done;
            }
            {
                _v.set(a_pd);
                goto _done;
            }
        _done:
            _v.take();
        });
    }));
    })
        : prism_rtl::finished(acc_p1);
    });
}


/// `Start BareOfDecl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, Array<Text>>> start_bare_of_decl_f(Text m_p0, Map<Text, Array<Text>> acc_p1, crate::syntax::decls::Decl d_p2) {
    return prism_rtl::make_rc<BareOfDecl>(m_p0, acc_p1, d_p2);
}


/// CtorNamesOf: fn TypeDecl -> [Text]
Array<Text> ctor_names_of_f(const crate::syntax::decls::TypeDecl& t_p0) {
    auto&& _m = t_p0.body_o;
    if (prism_rtl::is_some(_m) && prism_rtl::is<crate::syntax::decls::TypeBody::TbRecord>(prism_rtl::some_of(_m))) {
        return Array(std::vector{crate::check::env::dotted_f(prism_rtl::deref(t_p0.name_p).path_p)});
    }
    if (prism_rtl::is_some(_m) && prism_rtl::is<crate::syntax::decls::TypeBody::TbChoice>(prism_rtl::some_of(_m))) {
        auto&& cs_p1 = prism_rtl::as<crate::syntax::decls::TypeBody::TbChoice>(prism_rtl::some_of(_m)).a0;
        return crate::prelude::each(cs_p1, [&](const crate::syntax::decls::Case_& c_p2) { return crate::check::env::sname_key_f(prism_rtl::deref(c_p2).name_p); });
    }
    if (prism_rtl::is_some(_m) && prism_rtl::is<crate::syntax::decls::TypeBody::TbNewtype>(prism_rtl::some_of(_m))) {
        auto&& c_p3 = prism_rtl::as<crate::syntax::decls::TypeBody::TbNewtype>(prism_rtl::some_of(_m)).a0;
        return Array(std::vector{crate::check::env::sname_key_f(prism_rtl::deref(c_p3).name_p)});
    }
    if (prism_rtl::is_some(_m) && prism_rtl::is<crate::syntax::decls::TypeBody::TbUnit>(prism_rtl::some_of(_m))) {
        auto&& i_p4 = prism_rtl::as<crate::syntax::decls::TypeBody::TbUnit>(prism_rtl::some_of(_m)).a0;
        return Array(std::vector{prism_rtl::deref(i_p4).name_p});
    }
    {
        return Array<Text>{};
    }
}


/// PatternNames: unbounded fn Pattern -> [Text]
Array<Text> pattern_names_f(const crate::syntax::Pattern_& p_p0) {
    auto&& _m = prism_rtl::deref(p_p0.kind_p);
    if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
        auto&& n_p1 = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        return Array(std::vector{crate::check::env::sname_key_f(n_p1)});
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PCtor>(_m)) {
        auto&& ps_p2 = prism_rtl::as<crate::syntax::PatternKind::PCtor>(_m).a1;
        return crate::prelude::run_to_end(crate::prelude::fold_job(ps_p2, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Pattern_> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto acc_p3 = p0;
                    auto q_p4 = p1;
                    (crate::prelude::call_then(start_pattern_names_f(q_p4), [=, acc_p3 = std::move(acc_p3)](Array<Text> pattern_names_f_6861) { return prism_rtl::finished(crate::prelude::append(acc_p3, pattern_names_f_6861)); }));
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PRecord>(_m)) {
        auto&& fs_p5 = prism_rtl::as<crate::syntax::PatternKind::PRecord>(_m).a1;
        return crate::prelude::run_to_end(crate::prelude::fold_job(fs_p5, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::FieldPat>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::FieldPat> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto acc_p6 = p0;
                    auto f_p7 = p1;
                    (crate::prelude::call_then(start_pattern_names_f(prism_rtl::deref(f_p7).pattern_p), [=, acc_p6 = std::move(acc_p6)](Array<Text> pattern_names_f_6947) { return prism_rtl::finished(crate::prelude::append(acc_p6, pattern_names_f_6947)); }));
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PSigil>(_m)) {
        auto&& q_p8 = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a1;
        return pattern_names_f(prism_rtl::deref(prism_rtl::deref(q_p8)));
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PTuple>(_m)) {
        auto&& ps_p9 = prism_rtl::as<crate::syntax::PatternKind::PTuple>(_m).a0;
        return crate::prelude::run_to_end(crate::prelude::fold_job(ps_p9, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Pattern_> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto acc_pa = p0;
                    auto q_pb = p1;
                    (crate::prelude::call_then(start_pattern_names_f(q_pb), [=, acc_pa = std::move(acc_pa)](Array<Text> pattern_names_f_7061) { return prism_rtl::finished(crate::prelude::append(acc_pa, pattern_names_f_7061)); }));
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PArray>(_m)) {
        auto&& ps_pc = prism_rtl::as<crate::syntax::PatternKind::PArray>(_m).a0;
        return crate::prelude::run_to_end(crate::prelude::fold_job(ps_pc, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Pattern_> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto acc_pd = p0;
                    auto q_pe = p1;
                    (crate::prelude::call_then(start_pattern_names_f(q_pe), [=, acc_pd = std::move(acc_pd)](Array<Text> pattern_names_f_7130) { return prism_rtl::finished(crate::prelude::append(acc_pd, pattern_names_f_7130)); }));
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PGroup>(_m)) {
        auto&& q_pf = prism_rtl::as<crate::syntax::PatternKind::PGroup>(_m).a0;
        return pattern_names_f(prism_rtl::deref(prism_rtl::deref(q_pf)));
    }
    {
        return Array<Text>{};
    }
}


prism_rtl::Turn<Array<Text>> PatternNames::cycle() const {
    const auto& p_p0 = this->p_p0;
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(p_p0).kind_p);
        prism_rtl::is<crate::syntax::PatternKind::PName>(_m) ? ({
        auto&& n_p1 = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        prism_rtl::finished(Array(std::vector{crate::check::env::sname_key_f(n_p1)}));
    })
        : prism_rtl::is<crate::syntax::PatternKind::PCtor>(_m) ? ({
        auto&& ps_p2 = prism_rtl::as<crate::syntax::PatternKind::PCtor>(_m).a1;
        crate::prelude::fold_job(ps_p2, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Pattern_> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto acc_p3 = p0;
                auto q_p4 = p1;
                (crate::prelude::call_then(start_pattern_names_f(q_p4), [=, acc_p3 = std::move(acc_p3)](Array<Text> pattern_names_f_6861) { return prism_rtl::finished(crate::prelude::append(acc_p3, pattern_names_f_6861)); }));
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::syntax::PatternKind::PRecord>(_m) ? ({
        auto&& fs_p5 = prism_rtl::as<crate::syntax::PatternKind::PRecord>(_m).a1;
        crate::prelude::fold_job(fs_p5, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::FieldPat>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::FieldPat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto acc_p6 = p0;
                auto f_p7 = p1;
                (crate::prelude::call_then(start_pattern_names_f(prism_rtl::deref(f_p7).pattern_p), [=, acc_p6 = std::move(acc_p6)](Array<Text> pattern_names_f_6947) { return prism_rtl::finished(crate::prelude::append(acc_p6, pattern_names_f_6947)); }));
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::syntax::PatternKind::PSigil>(_m) ? ({
        auto&& q_p8 = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a1;
        prism_rtl::more(prism_rtl::rc(PatternNames(prism_rtl::deref(prism_rtl::deref(q_p8)))));
    })
        : prism_rtl::is<crate::syntax::PatternKind::PTuple>(_m) ? ({
        auto&& ps_p9 = prism_rtl::as<crate::syntax::PatternKind::PTuple>(_m).a0;
        crate::prelude::fold_job(ps_p9, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Pattern_> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto acc_pa = p0;
                auto q_pb = p1;
                (crate::prelude::call_then(start_pattern_names_f(q_pb), [=, acc_pa = std::move(acc_pa)](Array<Text> pattern_names_f_7061) { return prism_rtl::finished(crate::prelude::append(acc_pa, pattern_names_f_7061)); }));
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::syntax::PatternKind::PArray>(_m) ? ({
        auto&& ps_pc = prism_rtl::as<crate::syntax::PatternKind::PArray>(_m).a0;
        crate::prelude::fold_job(ps_pc, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Pattern_> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto acc_pd = p0;
                auto q_pe = p1;
                (crate::prelude::call_then(start_pattern_names_f(q_pe), [=, acc_pd = std::move(acc_pd)](Array<Text> pattern_names_f_7130) { return prism_rtl::finished(crate::prelude::append(acc_pd, pattern_names_f_7130)); }));
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::syntax::PatternKind::PGroup>(_m) ? ({
        auto&& q_pf = prism_rtl::as<crate::syntax::PatternKind::PGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(PatternNames(prism_rtl::deref(prism_rtl::deref(q_pf)))));
    })
        : prism_rtl::finished(Array<Text>{});
    });
}


/// `Start PatternNames, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_pattern_names_f(crate::syntax::Pattern_ p_p0) {
    return prism_rtl::make_rc<PatternNames>(p_p0);
}


/// PatternBinders: unbounded fn Pattern -> [((Text, Range))]
Array<std::tuple<Text, crate::syntax::Range>> pattern_binders_f(const crate::syntax::Pattern_& p_p0) {
    auto&& _m = prism_rtl::deref(p_p0.kind_p);
    if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
        auto&& n_p1 = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        return Array(std::vector{std::tuple{crate::check::env::sname_key_f(n_p1), prism_rtl::deref(n_p1).span_p}});
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PCtor>(_m)) {
        auto&& ps_p2 = prism_rtl::as<crate::syntax::PatternKind::PCtor>(_m).a1;
        return crate::prelude::run_to_end(crate::prelude::fold_job(ps_p2, Array<std::tuple<Text, crate::syntax::Range>>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Text, crate::syntax::Range>>>(std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::syntax::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::syntax::Pattern_> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto acc_p3 = p0;
                    auto q_p4 = p1;
                    (crate::prelude::call_then(start_pattern_binders_f(q_p4), [=, acc_p3 = std::move(acc_p3)](Array<std::tuple<Text, crate::syntax::Range>> pattern_binders_f_7450) { return prism_rtl::finished(crate::prelude::append(acc_p3, pattern_binders_f_7450)); }));
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PRecord>(_m)) {
        auto&& fs_p5 = prism_rtl::as<crate::syntax::PatternKind::PRecord>(_m).a1;
        return crate::prelude::run_to_end(crate::prelude::fold_job(fs_p5, Array<std::tuple<Text, crate::syntax::Range>>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Text, crate::syntax::Range>>>(std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::syntax::FieldPat>)>>(prism_rtl::rc([=](std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::syntax::FieldPat> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto acc_p6 = p0;
                    auto f_p7 = p1;
                    (crate::prelude::call_then(start_pattern_binders_f(prism_rtl::deref(f_p7).pattern_p), [=, acc_p6 = std::move(acc_p6)](Array<std::tuple<Text, crate::syntax::Range>> pattern_binders_f_7538) { return prism_rtl::finished(crate::prelude::append(acc_p6, pattern_binders_f_7538)); }));
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PSigil>(_m)) {
        auto&& q_p8 = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a1;
        return pattern_binders_f(prism_rtl::deref(prism_rtl::deref(q_p8)));
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PTuple>(_m)) {
        auto&& ps_p9 = prism_rtl::as<crate::syntax::PatternKind::PTuple>(_m).a0;
        return crate::prelude::run_to_end(crate::prelude::fold_job(ps_p9, Array<std::tuple<Text, crate::syntax::Range>>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Text, crate::syntax::Range>>>(std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::syntax::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::syntax::Pattern_> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto acc_pa = p0;
                    auto q_pb = p1;
                    (crate::prelude::call_then(start_pattern_binders_f(q_pb), [=, acc_pa = std::move(acc_pa)](Array<std::tuple<Text, crate::syntax::Range>> pattern_binders_f_7656) { return prism_rtl::finished(crate::prelude::append(acc_pa, pattern_binders_f_7656)); }));
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PArray>(_m)) {
        auto&& ps_pc = prism_rtl::as<crate::syntax::PatternKind::PArray>(_m).a0;
        return crate::prelude::run_to_end(crate::prelude::fold_job(ps_pc, Array<std::tuple<Text, crate::syntax::Range>>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Text, crate::syntax::Range>>>(std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::syntax::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::syntax::Pattern_> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto acc_pd = p0;
                    auto q_pe = p1;
                    (crate::prelude::call_then(start_pattern_binders_f(q_pe), [=, acc_pd = std::move(acc_pd)](Array<std::tuple<Text, crate::syntax::Range>> pattern_binders_f_7727) { return prism_rtl::finished(crate::prelude::append(acc_pd, pattern_binders_f_7727)); }));
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PGroup>(_m)) {
        auto&& q_pf = prism_rtl::as<crate::syntax::PatternKind::PGroup>(_m).a0;
        return pattern_binders_f(prism_rtl::deref(prism_rtl::deref(q_pf)));
    }
    {
        return Array<std::tuple<Text, crate::syntax::Range>>{};
    }
}


prism_rtl::Turn<Array<std::tuple<Text, crate::syntax::Range>>> PatternBinders::cycle() const {
    const auto& p_p0 = this->p_p0;
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(p_p0).kind_p);
        prism_rtl::is<crate::syntax::PatternKind::PName>(_m) ? ({
        auto&& n_p1 = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        prism_rtl::finished(Array(std::vector{std::tuple{crate::check::env::sname_key_f(n_p1), prism_rtl::deref(n_p1).span_p}}));
    })
        : prism_rtl::is<crate::syntax::PatternKind::PCtor>(_m) ? ({
        auto&& ps_p2 = prism_rtl::as<crate::syntax::PatternKind::PCtor>(_m).a1;
        crate::prelude::fold_job(ps_p2, Array<std::tuple<Text, crate::syntax::Range>>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Text, crate::syntax::Range>>>(std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::syntax::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::syntax::Pattern_> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto acc_p3 = p0;
                auto q_p4 = p1;
                (crate::prelude::call_then(start_pattern_binders_f(q_p4), [=, acc_p3 = std::move(acc_p3)](Array<std::tuple<Text, crate::syntax::Range>> pattern_binders_f_7450) { return prism_rtl::finished(crate::prelude::append(acc_p3, pattern_binders_f_7450)); }));
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::syntax::PatternKind::PRecord>(_m) ? ({
        auto&& fs_p5 = prism_rtl::as<crate::syntax::PatternKind::PRecord>(_m).a1;
        crate::prelude::fold_job(fs_p5, Array<std::tuple<Text, crate::syntax::Range>>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Text, crate::syntax::Range>>>(std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::syntax::FieldPat>)>>(prism_rtl::rc([=](std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::syntax::FieldPat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto acc_p6 = p0;
                auto f_p7 = p1;
                (crate::prelude::call_then(start_pattern_binders_f(prism_rtl::deref(f_p7).pattern_p), [=, acc_p6 = std::move(acc_p6)](Array<std::tuple<Text, crate::syntax::Range>> pattern_binders_f_7538) { return prism_rtl::finished(crate::prelude::append(acc_p6, pattern_binders_f_7538)); }));
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::syntax::PatternKind::PSigil>(_m) ? ({
        auto&& q_p8 = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a1;
        prism_rtl::more(prism_rtl::rc(PatternBinders(prism_rtl::deref(prism_rtl::deref(q_p8)))));
    })
        : prism_rtl::is<crate::syntax::PatternKind::PTuple>(_m) ? ({
        auto&& ps_p9 = prism_rtl::as<crate::syntax::PatternKind::PTuple>(_m).a0;
        crate::prelude::fold_job(ps_p9, Array<std::tuple<Text, crate::syntax::Range>>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Text, crate::syntax::Range>>>(std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::syntax::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::syntax::Pattern_> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto acc_pa = p0;
                auto q_pb = p1;
                (crate::prelude::call_then(start_pattern_binders_f(q_pb), [=, acc_pa = std::move(acc_pa)](Array<std::tuple<Text, crate::syntax::Range>> pattern_binders_f_7656) { return prism_rtl::finished(crate::prelude::append(acc_pa, pattern_binders_f_7656)); }));
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::syntax::PatternKind::PArray>(_m) ? ({
        auto&& ps_pc = prism_rtl::as<crate::syntax::PatternKind::PArray>(_m).a0;
        crate::prelude::fold_job(ps_pc, Array<std::tuple<Text, crate::syntax::Range>>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Text, crate::syntax::Range>>>(std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::syntax::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::syntax::Pattern_> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto acc_pd = p0;
                auto q_pe = p1;
                (crate::prelude::call_then(start_pattern_binders_f(q_pe), [=, acc_pd = std::move(acc_pd)](Array<std::tuple<Text, crate::syntax::Range>> pattern_binders_f_7727) { return prism_rtl::finished(crate::prelude::append(acc_pd, pattern_binders_f_7727)); }));
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::syntax::PatternKind::PGroup>(_m) ? ({
        auto&& q_pf = prism_rtl::as<crate::syntax::PatternKind::PGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(PatternBinders(prism_rtl::deref(prism_rtl::deref(q_pf)))));
    })
        : prism_rtl::finished(Array<std::tuple<Text, crate::syntax::Range>>{});
    });
}


/// `Start PatternBinders, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<std::tuple<Text, crate::syntax::Range>>> start_pattern_binders_f(crate::syntax::Pattern_ p_p0) {
    return prism_rtl::make_rc<PatternBinders>(p_p0);
}


/// BareTypesOf: fn G, Text, (Text ==> [Text]) -> (Text ==> [Text])
Map<Text, Array<Text>> bare_types_of_f(const crate::check::env::G& g_p0, const Text& src_p1, const Map<Text, Array<Text>>& acc_p2) {
    return crate::prelude::fold(crate::prelude::keys(g_p0.types_p), acc_p2, [&](const Map<Text, Array<Text>>& a_p3, const Text& k_p4) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Map<Text, Array<Text>>> _v;
            auto&& _m = crate::prelude::get(g_p0.types_p, k_p4);
            if (prism_rtl::is_some(_m)) {
                auto&& ti_p5 = prism_rtl::some_of(_m);
                _v.set(prism_rtl::deref(ti_p5).home_p == src_p1
                    ? add_bare_f(a_p3, crate::check::types::bare_name_f(prism_rtl::deref(ti_p5).name_p), k_p4)
                    : a_p3);
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(a_p3);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
}


/// BareTraitsOf: fn G, Text, (Text ==> [Text]) -> (Text ==> [Text])
Map<Text, Array<Text>> bare_traits_of_f(const crate::check::env::G& g_p0, const Text& src_p1, const Map<Text, Array<Text>>& acc_p2) {
    return crate::prelude::fold(crate::prelude::keys(g_p0.traits_p), acc_p2, [&](const Map<Text, Array<Text>>& a_p3, const Text& k_p4) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Map<Text, Array<Text>>> _v;
            auto&& _m = crate::prelude::get(g_p0.traits_p, k_p4);
            if (prism_rtl::is_some(_m)) {
                auto&& ti_p5 = prism_rtl::some_of(_m);
                _v.set(prism_rtl::deref(ti_p5).home_p == src_p1
                    ? add_bare_f(a_p3, crate::check::types::bare_name_f(prism_rtl::deref(ti_p5).name_p), k_p4)
                    : a_p3);
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(a_p3);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
}


/// ModuleRow: unbounded fn G, St, ModInfo -> ((Rw, Text, St))
std::tuple<crate::check::types::Rw, Text, crate::check::types::St> module_row_f(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const crate::check::env::ModInfo& info_p2) {
    auto&& _m = prism_rtl::deref(info_p2.tree_p).emit_row_o;
    if (prism_rtl::is_none(_m)) {
        return info_p2.root_p
            ? std::tuple{g_p0.program_row_p, Text::lit(""), st_p1}
            : std::tuple{crate::check::types::empty_row_p(), Text::lit(""), crate::check::types::recording::err_f(st_p1, Text::lit("emit-element"), prism_rtl::deref(info_p2.tree_p).span_p, Text::lit("a library writes its own row; this one writes no `emit` line"))};
    }
    if (prism_rtl::is_some(_m)) {
        auto&& row_decl_p3 = prism_rtl::some_of(_m);
        auto [fams_pa, vars_pb, s2_pc] = crate::prelude::fold(prism_rtl::deref(row_decl_p3).terms_p, std::tuple{Array<Text>{}, Array<Text>{}, st_p1}, [&](const std::tuple<Array<Text>, Array<Text>, crate::check::types::St>& _p0, const crate::syntax::RowTerm& term_p9) {
            auto&& fs_p6 = std::get<0>(_p0);
            auto&& vs_p7 = std::get<1>(_p0);
            auto&& s_p8 = std::get<2>(_p0);
            return row_term_of_f(g_p0, s_p8, info_p2, term_p9, fs_p6, vs_p7);
        });
        auto s3_p4 = crate::prelude::len(vars_pb) > Nat(1u)
            ? crate::check::types::recording::err_fix_f(s2_pc, Text::lit("row-two-tails"), prism_rtl::deref(row_decl_p3).span_p, prism_rtl::cat("a row has one variable; `", crate::syntax::lexer::chars::join_f(vars_pb, Text::lit(" | ")), "` names two"), Text::lit("keep one variable"))
            : s2_pc;
        auto tail_p5 = ({
            __label__ _done;
            prism_rtl::Slot<crate::check::types::Tail> _v;
            auto&& _m = crate::prelude::index(vars_pb, Nat(0u));
            if (prism_rtl::is_some(_m)) {
                auto&& v_pd = prism_rtl::some_of(_m);
                _v.set(crate::check::types::Tail(crate::check::types::Tail::TlQ{v_pd}));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(crate::check::types::Tail(crate::check::types::Tail::TlClosed{}));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        return std::tuple{crate::check::types::Rw{.fams_p = crate::check::types::sort_texts_f(fams_pa), .minus_p = Array<Text>{}, .tail_p = tail_p5}, crate::prelude::or_(crate::prelude::index(vars_pb, Nat(0u)), Text::lit("")), s3_p4};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<crate::check::types::Rw, Text, crate::check::types::St>> ModuleRow::cycle() const {
    const auto& g_p0 = this->g_p0;
    const auto& st_p1 = this->st_p1;
    const auto& info_p2 = this->info_p2;
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(info_p2).tree_p).emit_row_o;
        prism_rtl::is_none(_m) ? prism_rtl::deref(info_p2).root_p
        ? prism_rtl::finished(std::tuple{prism_rtl::deref(g_p0).program_row_p, Text::lit(""), st_p1})
        : prism_rtl::finished(std::tuple{crate::check::types::empty_row_p(), Text::lit(""), crate::check::types::recording::err_f(st_p1, Text::lit("emit-element"), prism_rtl::deref(prism_rtl::deref(info_p2).tree_p).span_p, Text::lit("a library writes its own row; this one writes no `emit` line"))})
        : prism_rtl::is_some(_m) ? ({
        auto&& row_decl_p3 = prism_rtl::some_of(_m);
        ({
        auto [fams_pa, vars_pb, s2_pc] = crate::prelude::fold(prism_rtl::deref(row_decl_p3).terms_p, std::tuple{Array<Text>{}, Array<Text>{}, st_p1}, [&](const std::tuple<Array<Text>, Array<Text>, crate::check::types::St>& _p0, const crate::syntax::RowTerm& term_p9) {
            auto&& fs_p6 = std::get<0>(_p0);
            auto&& vs_p7 = std::get<1>(_p0);
            auto&& s_p8 = std::get<2>(_p0);
            return row_term_of_f(g_p0, s_p8, info_p2, term_p9, fs_p6, vs_p7);
        });
        auto s3_p4 = crate::prelude::len(vars_pb) > Nat(1u)
            ? crate::check::types::recording::err_fix_f(s2_pc, Text::lit("row-two-tails"), prism_rtl::deref(row_decl_p3).span_p, prism_rtl::cat("a row has one variable; `", crate::syntax::lexer::chars::join_f(vars_pb, Text::lit(" | ")), "` names two"), Text::lit("keep one variable"))
            : s2_pc;
        auto tail_p5 = ({
            __label__ _done;
            prism_rtl::Slot<crate::check::types::Tail> _v;
            auto&& _m = crate::prelude::index(vars_pb, Nat(0u));
            if (prism_rtl::is_some(_m)) {
                auto&& v_pd = prism_rtl::some_of(_m);
                _v.set(crate::check::types::Tail(crate::check::types::Tail::TlQ{v_pd}));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(crate::check::types::Tail(crate::check::types::Tail::TlClosed{}));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        (prism_rtl::finished(std::tuple{crate::check::types::Rw{.fams_p = crate::check::types::sort_texts_f(fams_pa), .minus_p = Array<Text>{}, .tail_p = tail_p5}, crate::prelude::or_(crate::prelude::index(vars_pb, Nat(0u)), Text::lit("")), s3_p4}));
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ModuleRow, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Rw, Text, crate::check::types::St>> start_module_row_f(crate::check::env::G g_p0, crate::check::types::St st_p1, crate::check::env::ModInfo info_p2) {
    return prism_rtl::make_rc<ModuleRow>(g_p0, st_p1, info_p2);
}


/// RowTermOf: fn G, St, ModInfo, RowTerm, [Text], [Text] -> (([Text], [Text], St))
std::tuple<Array<Text>, Array<Text>, crate::check::types::St> row_term_of_f(const crate::check::env::G& g_p0, const crate::check::types::St& s_p1, const crate::check::env::ModInfo& info_p2, const crate::syntax::RowTerm& term_p3, const Array<Text>& fs_p4, const Array<Text>& vs_p5) {
    if (prism_rtl::is<crate::syntax::RowTerm::RFamily>(term_p3)) {
        auto&& q_p6 = prism_rtl::as<crate::syntax::RowTerm::RFamily>(term_p3).a0;
        return std::tuple{crate::prelude::push(fs_p4, crate::check::env::dotted_f(prism_rtl::deref(q_p6).path_p)), vs_p5, check_family_f(g_p0, s_p1, crate::check::env::dotted_f(prism_rtl::deref(q_p6).path_p), prism_rtl::deref(q_p6).span_p)};
    }
    if (prism_rtl::is<crate::syntax::RowTerm::RVar>(term_p3)) {
        auto&& v_p7 = prism_rtl::as<crate::syntax::RowTerm::RVar>(term_p3).a0;
        return std::tuple{fs_p4, crate::prelude::push(vs_p5, prism_rtl::deref(v_p7).name_p), s_p1};
    }
    if (prism_rtl::is<crate::syntax::RowTerm::RType>(term_p3)) {
        auto&& t_p8 = prism_rtl::as<crate::syntax::RowTerm::RType>(term_p3).a0;
        auto&& _m = prism_rtl::deref(prism_rtl::deref(t_p8).kind_p);
        if (prism_rtl::is<crate::syntax::TypeKind::TName>(_m)) {
            auto&& n_p9 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a0;
            auto&& m9527_0_1 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a1;
            if (m9527_0_1.size() == 0u) {
                auto name_pa = crate::check::env::dotted_f(prism_rtl::deref(n_p9).path_p);
                return (name_pa == Text::lit("Element")) && info_p2.root_p
                    ? std::tuple{crate::prelude::append(fs_p4, prism_rtl::deref(g_p0.program_row_p).fams_p), vs_p5, s_p1}
                    : name_pa == Text::lit("Element")
                    ? std::tuple{fs_p4, vs_p5, crate::check::types::recording::err_f(s_p1, Text::lit("emit-element"), prism_rtl::deref(t_p8).span_p, Text::lit("a library writes its own row; `emit Element` names the program\'s"))}
                    : crate::check::env::has_key_f(g_p0.tags_p, name_pa) || (crate::prelude::len(prism_rtl::deref(n_p9).path_p) > Nat(1u))
                    ? std::tuple{fs_p4, vs_p5, crate::check::types::recording::err_fix_f(s_p1, Text::lit("row-single-tag"), prism_rtl::deref(t_p8).span_p, prism_rtl::cat("a row names families, not tags: `", name_pa, "`"), prism_rtl::cat("write `", crate::check::env::dotted_f(crate::prelude::take(prism_rtl::deref(n_p9).path_p, crate::syntax::lexer::chars::dec_f(crate::prelude::len(prism_rtl::deref(n_p9).path_p)))), ".*`"))}
                    : std::tuple{fs_p4, vs_p5, crate::check::types::recording::err_f(s_p1, Text::lit("kind"), prism_rtl::deref(t_p8).span_p, prism_rtl::cat("`", name_pa, "` is not a row"))};
            }
        }
        {
            return std::tuple{fs_p4, vs_p5, crate::check::types::recording::err_f(s_p1, Text::lit("kind"), prism_rtl::deref(t_p8).span_p, Text::lit("this is not a row"))};
        }
    }
    prism_rtl::unreachable("no arm matched");
}


/// CheckFamily: fn G, St, Text, Range -> St
crate::check::types::St check_family_f(const crate::check::env::G& g_p0, const crate::check::types::St& s_p1, const Text& fam_p2, const crate::syntax::Range& span_p3) {
    return crate::check::env::has_key_f(g_p0.families_p, fam_p2)
        ? s_p1
        : crate::check::types::recording::err_f(s_p1, Text::lit("unknown-name"), span_p3, prism_rtl::cat("no family `", fam_p2, "`: no module declares a `", fam_p2, ".` tag"));
}


/// ResolveValue: fn G, Text, SName -> ((?Text, Text))
std::tuple<std::optional<Text>, Text> resolve_value_f(const crate::check::env::G& g_p0, const Text& m_p1, const crate::syntax::SName& n_p2) {
    auto marks_p3 = n_p2.sigils_p;
    return crate::prelude::len(n_p2.path_p) == Nat(1u)
        ? ({
        auto name_p4 = prism_rtl::cat(marks_p3, crate::prelude::or_(crate::prelude::index(n_p2.path_p, Nat(0u)), Text::lit("")));
        auto table_p5 = crate::prelude::or_(crate::prelude::get(g_p0.bare_p, m_p1), Map<Text, Array<Text>>{});
        auto keys_p6 = crate::prelude::or_(crate::prelude::get(table_p5, name_p4), Array<Text>{});
        crate::prelude::len(keys_p6) == Nat(1u)
        ? std::tuple{crate::prelude::index(keys_p6, Nat(0u)), Text::lit("")}
        : crate::prelude::len(keys_p6) > Nat(1u)
        ? std::tuple{std::optional(own_first_f(m_p1, keys_p6)), Text::lit("collision")}
        : name_p4 == Text::lit("never")
        ? std::tuple{std::optional(Text::lit("Prelude.never")), Text::lit("")}
        : crate::check::env::has_key_f(g_p0.ctors_p, name_p4)
        ? std::tuple{std::optional(name_p4), Text::lit("")}
        : std::tuple{std::optional<Text>{}, Text::lit("unknown")};
    })
        : ({
        auto qual_p7 = crate::check::env::qual_module_f(g_p0, crate::prelude::take(n_p2.path_p, crate::syntax::lexer::chars::dec_f(crate::prelude::len(n_p2.path_p))));
        auto last_p8 = crate::prelude::or_(crate::syntax::lexer::chars::last_o(n_p2.path_p), Text::lit(""));
        auto qk_p9 = crate::check::env::qual_key_f(qual_p7, prism_rtl::cat(marks_p3, last_p8));
        (crate::prelude::len_text(marks_p3) == Nat(0u)) && crate::check::env::has_key_f(g_p0.tags_p, crate::check::env::dotted_f(n_p2.path_p))
        ? std::tuple{std::optional(crate::check::env::dotted_f(n_p2.path_p)), Text::lit("tag")}
        : crate::check::env::has_key_f(g_p0.vals_p, qk_p9) || crate::check::env::has_key_f(g_p0.ctors_p, qk_p9)
        ? std::tuple{std::optional(qk_p9), Text::lit("")}
        : std::tuple{std::optional<Text>{}, Text::lit("unknown")};
    });
}


/// ResolveType: fn G, Text, [Text] -> ((?Text, Text))
std::tuple<std::optional<Text>, Text> resolve_type_f(const crate::check::env::G& g_p0, const Text& m_p1, const Array<Text>& path_p2) {
    return crate::prelude::len(path_p2) == Nat(1u)
        ? ({
        auto keys_p3 = crate::prelude::or_(crate::prelude::get(crate::prelude::or_(crate::prelude::get(g_p0.bare_types_p, m_p1), Map<Text, Array<Text>>{}), crate::prelude::or_(crate::prelude::index(path_p2, Nat(0u)), Text::lit(""))), Array<Text>{});
        crate::prelude::len(keys_p3) == Nat(1u)
        ? std::tuple{crate::prelude::index(keys_p3, Nat(0u)), Text::lit("")}
        : crate::prelude::len(keys_p3) > Nat(1u)
        ? std::tuple{std::optional(own_first_f(m_p1, keys_p3)), Text::lit("collision")}
        : std::tuple{std::optional<Text>{}, Text::lit("unknown")};
    })
        : ({
        auto qk_p4 = crate::check::env::qual_key_f(crate::check::env::qual_module_f(g_p0, crate::prelude::take(path_p2, crate::syntax::lexer::chars::dec_f(crate::prelude::len(path_p2)))), crate::prelude::or_(crate::syntax::lexer::chars::last_o(path_p2), Text::lit("")));
        crate::check::env::has_key_f(g_p0.types_p, qk_p4)
        ? std::tuple{std::optional(qk_p4), Text::lit("")}
        : std::tuple{std::optional<Text>{}, Text::lit("unknown")};
    });
}


/// OwnFirst: fn Text, [Text] -> Text
Text own_first_f(const Text& m_p0, const Array<Text>& keys_p1) {
    auto own_p2 = crate::prelude::filter(keys_p1, [&](const Text& k_p3) { return (crate::check::env::qual_key_f(m_p0, crate::check::types::bare_name_f(k_p3)) == k_p3) || ((m_p0 == Text::lit("")) && (!crate::syntax::lexer::chars::contains_f(k_p3, Text::lit(".")))); });
    return crate::prelude::or_(crate::prelude::index(own_p2, Nat(0u)), crate::prelude::or_(crate::prelude::index(keys_p1, Nat(0u)), Text::lit("")));
}


/// ?ResolveTrait: fn G, Text, [Text] -> ?Text
std::optional<Text> resolve_trait_o(const crate::check::env::G& g_p0, const Text& m_p1, const Array<Text>& path_p2) {
    return crate::prelude::len(path_p2) == Nat(1u)
        ? ({
        auto keys_p3 = crate::prelude::or_(crate::prelude::get(crate::prelude::or_(crate::prelude::get(g_p0.bare_traits_p, m_p1), Map<Text, Array<Text>>{}), crate::prelude::or_(crate::prelude::index(path_p2, Nat(0u)), Text::lit(""))), Array<Text>{});
        (crate::prelude::index(keys_p3, Nat(0u)));
    })
        : ({
        auto qk_p4 = crate::check::env::qual_key_f(crate::check::env::qual_module_f(g_p0, crate::prelude::take(path_p2, crate::syntax::lexer::chars::dec_f(crate::prelude::len(path_p2)))), crate::prelude::or_(crate::syntax::lexer::chars::last_o(path_p2), Text::lit("")));
        crate::check::env::has_key_f(g_p0.traits_p, qk_p4)
        ? std::optional(qk_p4)
        : std::optional<Text>{};
    });
}

}  // namespace crate::check::env::names
