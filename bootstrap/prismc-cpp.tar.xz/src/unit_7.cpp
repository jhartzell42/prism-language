// The module `Check.Env.Names`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <check/env/names/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Check.Env.Names`, from `target/bootstrap/cpp-src/prismc/check/env/names.prism`.
namespace crate::check::env::names {

/// CollectNames: unbounded fn G, St, Text -> ((G, St))
std::tuple<crate::check::env::G, crate::check::types::St> collect_names(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const Text& m_p2) {
    auto&& _m = crate::prelude::get(g_p0.mods, m_p2);
    if (prism_rtl::is_none(_m)) {
        return std::tuple{g_p0, st_p1};
    }
    if (prism_rtl::is_some(_m)) {
        auto&& info_p3 = prism_rtl::some_of(_m);
        auto s0_p4 = ({
            crate::check::types::St this_ = st_p1;
            this_.file = info_p3->file;
            (std::move(this_));
        });
        auto&& _g2_p9 = run_to_end(fold_job(prism_rtl::deref(prism_rtl::deref(info_p3).tree).decls, std::tuple{g_p0, s0_p4, std::optional<Text>{}}, ({
            auto info_p3_1 = info_p3;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::env::G, crate::check::types::St, std::optional<Text>>>(std::tuple<std::tuple<crate::check::env::G, crate::check::types::St, std::optional<Text>>, crate::syntax::decls::Decl>)>>(prism_rtl::rc([=, info_p3_1 = std::move(info_p3_1)](std::tuple<std::tuple<crate::check::env::G, crate::check::types::St, std::optional<Text>>, crate::syntax::decls::Decl> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto info_p3_1_2 = info_p3_1;
                entered(once_job([=, info_p3_1_2 = std::move(info_p3_1_2)]() {
                return ({
                    auto [gg_p5, s_p6, last_type_o7] = p0;
                    auto d_p8 = p1;
                    (prism_rtl::more(prism_rtl::rc(CollectDecl(gg_p5, s_p6, info_p3_1_2, d_p8, last_type_o7))));
                });
            }));
            });
        }));
        })));
        auto&& g2_p9 = std::get<0>(_g2_p9);
        auto&& s2_pa = std::get<1>(_g2_p9);
        return std::tuple{g2_p9, s2_pa};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<crate::check::env::G, crate::check::types::St>> CollectNames::cycle() const {
    const auto& g_p0 = this->g_p0;
    const auto& st_p1 = this->st_p1;
    const auto& m_p2 = this->m_p2;
    return ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(g_p0).mods, m_p2);
        prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{g_p0, st_p1})
        : prism_rtl::is_some(_m) ? ({
        auto&& info_p3 = prism_rtl::some_of(_m);
        ({
        auto s0_p4 = ({
            crate::check::types::St this_ = st_p1;
            this_.file = info_p3->file;
            (std::move(this_));
        });
        auto g_p0_1 = g_p0;
        call_value(fold_job(prism_rtl::deref(prism_rtl::deref(info_p3).tree).decls, std::tuple{g_p0_1, s0_p4, std::optional<Text>{}}, ({
        auto info_p3_2 = info_p3;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::env::G, crate::check::types::St, std::optional<Text>>>(std::tuple<std::tuple<crate::check::env::G, crate::check::types::St, std::optional<Text>>, crate::syntax::decls::Decl>)>>(prism_rtl::rc([=, info_p3_2 = std::move(info_p3_2)](std::tuple<std::tuple<crate::check::env::G, crate::check::types::St, std::optional<Text>>, crate::syntax::decls::Decl> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto info_p3_2_3 = info_p3_2;
            entered(once_job([=, info_p3_2_3 = std::move(info_p3_2_3)]() {
            return ({
                auto [gg_p5, s_p6, last_type_o7] = p0;
                auto d_p8 = p1;
                (prism_rtl::more(prism_rtl::rc(CollectDecl(gg_p5, s_p6, info_p3_2_3, d_p8, last_type_o7))));
            });
        }));
        });
    }));
    })), [=](std::tuple<crate::check::env::G, crate::check::types::St, std::optional<Text>> fold_1030) {
        return ({
            auto&& _g2_p9 = fold_1030;
            auto&& g2_p9 = std::get<0>(_g2_p9);
            auto&& s2_pa = std::get<1>(_g2_p9);
            (prism_rtl::finished(std::tuple{g2_p9, s2_pa}));
        });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CollectNames, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::env::G, crate::check::types::St>> start_collect_names(crate::check::env::G g_p0, crate::check::types::St st_p1, Text m_p2) {
    return prism_rtl::make_rc<CollectNames>(g_p0, st_p1, m_p2);
}


/// CollectDecl: unbounded fn G, St, ModInfo, Decl, ?Text -> ((G, St, ?Text))
std::tuple<crate::check::env::G, crate::check::types::St, std::optional<Text>> collect_decl(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const crate::check::env::ModInfo& info_p2, const crate::syntax::decls::Decl& d_p3, const std::optional<Text>& last_type_o4) {
    auto&& _m = d_p3.kind;
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DType>(_m)) {
        auto&& t_p5 = prism_rtl::as<crate::syntax::decls::DeclKind::DType>(_m).a0;
        auto name_p6 = crate::check::env::qual_key(info_p2.name, crate::check::env::dotted(prism_rtl::deref(t_p5).name->path_));
        auto ti_p7 = crate::check::env::TyInfo{.name = name_p6, .home = info_p2.name, .params = each(prism_rtl::deref(t_p5).params, [&](const crate::syntax::Ident& p_p8) { return prism_rtl::deref(p_p8).name; }), .body = crate::check::env::TyBody(crate::check::env::TyBody::BOpaque{}), .derives = Array<Text>{}, .file = info_p2.file, .span = d_p3.span};
        return crate::check::env::has_key(g_p0.types, name_p6)
            ? std::tuple{g_p0, crate::check::types::recording::err(st_p1, Text::lit("collision"), d_p3.span, prism_rtl::cat("a second type `", crate::check::env::dotted(prism_rtl::deref(t_p5).name->path_), "`")), last_type_o4}
            : ({
            auto upd_p9 = ({
                crate::check::env::G this_ = g_p0;
                this_.types = insert(this_.types, name_p6, ti_p7);
                (std::move(this_));
            });
            std::tuple{upd_p9, st_p1, std::optional(name_p6)};
        });
    }
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DDerive>(_m)) {
        auto&& trs_pa = prism_rtl::as<crate::syntax::decls::DeclKind::DDerive>(_m).a0;
        if (prism_rtl::is_some(last_type_o4)) {
            auto&& tn_pb = prism_rtl::some_of(last_type_o4);
            auto upd_pc = ({
                crate::check::env::G this_ = g_p0;
                this_.types = insert(this_.types, tn_pb, add_derives(or_(crate::prelude::get(g_p0.types, tn_pb), dummy_ty_info()), each(trs_pa, [&](const crate::syntax::TraitRef& tr_pd) { return crate::check::env::dotted(tr_pd->path_); })));
                (std::move(this_));
            });
            return std::tuple{upd_pc, st_p1, last_type_o4};
        }
        if (prism_rtl::is_none(last_type_o4)) {
            return std::tuple{g_p0, crate::check::types::recording::err(st_p1, Text::lit("mismatch"), d_p3.span, Text::lit("a `derive` line follows a type declaration")), std::optional<Text>{}};
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DTag>(_m)) {
        auto&& t_pe = prism_rtl::as<crate::syntax::decls::DeclKind::DTag>(_m).a0;
        auto name_pf = crate::check::env::dotted(prism_rtl::deref(t_pe).name->path_);
        auto family_pg = crate::check::env::dotted(take(prism_rtl::deref(t_pe).name->path_, crate::syntax::lexer::chars::dec(len(prism_rtl::deref(t_pe).name->path_))));
        auto tags_ph = or_(crate::prelude::get(g_p0.families, family_pg), Array<Text>{});
        auto owner_pi = or_(crate::prelude::get(g_p0.fam_owner, family_pg), info_p2.name);
        auto st2_pj = owner_pi != info_p2.name
            ? crate::check::types::recording::err(st_p1, Text::lit("collision"), d_p3.span, prism_rtl::cat("the family `", family_pg, "` is declared in ", owner_pi == Text::lit("")
            ? Text::lit("the root")
            : prism_rtl::cat("`", owner_pi, "`"), "; every tag of a family is declared in its family\'s module"))
            : st_p1;
        auto is_elem_pk = ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            auto&& _m = prism_rtl::deref(prism_rtl::deref(prism_rtl::deref(t_pe).of_type).kind);
            if (prism_rtl::is<crate::syntax::TypeKind::TName>(_m)) {
                auto&& n_pm = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a0;
                _v.set(crate::check::env::dotted(n_pm->path_) == Text::lit("Element"));
                goto _done;
            }
            {
                _v.set(false);
                goto _done;
            }
        _done:
            _v.take();
        });
        auto g2_pl = ({
            crate::check::env::G this_ = g_p0;
            this_.families = insert(this_.families, family_pg, crate::prelude::push(tags_ph, name_pf));
            this_.fam_owner = insert(this_.fam_owner, family_pg, owner_pi);
            if (std::move(is_elem_pk)) {
                this_.elem_fams = crate::check::types::add_text(this_.elem_fams, family_pg);
            }
            (std::move(this_));
        });
        return std::tuple{g2_pl, st2_pj, std::optional<Text>{}};
    }
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DTrait>(_m)) {
        auto&& t_pn = prism_rtl::as<crate::syntax::decls::DeclKind::DTrait>(_m).a0;
        auto name_po = crate::check::env::qual_key(info_p2.name, crate::check::env::dotted(prism_rtl::deref(t_pn).name->path_));
        auto ti_pp = crate::check::env::TraitInfo{.name = name_po, .home = info_p2.name, .param = or_(index(each(prism_rtl::deref(t_pn).params, [&](const crate::syntax::Ident& p_pr) { return prism_rtl::deref(p_pr).name; }), Nat(0u)), Text::lit("a")), .supers = Array<Text>{}, .methods = Array<Text>{}, .defaults = Array<Text>{}, .assocs = Array<Text>{}, .file = info_p2.file, .span = d_p3.span};
        auto upd_pq = ({
            crate::check::env::G this_ = g_p0;
            this_.traits = insert(this_.traits, name_po, ti_pp);
            (std::move(this_));
        });
        return std::tuple{upd_pq, st_p1, std::optional<Text>{}};
    }
    {
        return std::tuple{g_p0, st_p1, std::optional<Text>{}};
    }
}


prism_rtl::Turn<std::tuple<crate::check::env::G, crate::check::types::St, std::optional<Text>>> CollectDecl::cycle() const {
    const auto& g_p0 = this->g_p0;
    const auto& st_p1 = this->st_p1;
    const auto& info_p2 = this->info_p2;
    const auto& d_p3 = this->d_p3;
    const auto& last_type_o4 = this->last_type_o4;
    return ({
        auto&& _m = prism_rtl::deref(d_p3).kind;
        prism_rtl::is<crate::syntax::decls::DeclKind::DType>(_m) ? ({
        auto&& t_p5 = prism_rtl::as<crate::syntax::decls::DeclKind::DType>(_m).a0;
        ({
        auto name_p6 = crate::check::env::qual_key(prism_rtl::deref(info_p2).name, crate::check::env::dotted(prism_rtl::deref(t_p5).name->path_));
        auto ti_p7 = crate::check::env::TyInfo{.name = name_p6, .home = prism_rtl::deref(info_p2).name, .params = each(prism_rtl::deref(t_p5).params, [&](const crate::syntax::Ident& p_p8) { return prism_rtl::deref(p_p8).name; }), .body = crate::check::env::TyBody(crate::check::env::TyBody::BOpaque{}), .derives = Array<Text>{}, .file = info_p2->file, .span = prism_rtl::deref(d_p3).span};
        (crate::check::env::has_key(prism_rtl::deref(g_p0).types, name_p6)
        ? prism_rtl::finished(std::tuple{g_p0, crate::check::types::recording::err(st_p1, Text::lit("collision"), prism_rtl::deref(d_p3).span, prism_rtl::cat("a second type `", crate::check::env::dotted(prism_rtl::deref(t_p5).name->path_), "`")), last_type_o4})
        : ({
        auto upd_p9 = ({
            crate::check::env::G this_ = g_p0;
            this_.types = insert(this_.types, name_p6, ti_p7);
            (std::move(this_));
        });
        (prism_rtl::finished(std::tuple{upd_p9, st_p1, std::optional(name_p6)}));
    }));
    });
    })
        : prism_rtl::is<crate::syntax::decls::DeclKind::DDerive>(_m) ? ({
        auto&& trs_pa = prism_rtl::as<crate::syntax::decls::DeclKind::DDerive>(_m).a0;
        ({
        prism_rtl::is_some(last_type_o4) ? ({
        auto&& tn_pb = prism_rtl::some_of(last_type_o4);
        ({
        auto upd_pc = ({
            crate::check::env::G this_ = g_p0;
            this_.types = insert(this_.types, tn_pb, add_derives(or_(crate::prelude::get(prism_rtl::deref(g_p0).types, tn_pb), dummy_ty_info()), each(trs_pa, [&](const crate::syntax::TraitRef& tr_pd) { return crate::check::env::dotted(tr_pd->path_); })));
            (std::move(this_));
        });
        (prism_rtl::finished(std::tuple{upd_pc, st_p1, last_type_o4}));
    });
    })
        : prism_rtl::is_none(last_type_o4) ? prism_rtl::finished(std::tuple{g_p0, crate::check::types::recording::err(st_p1, Text::lit("mismatch"), prism_rtl::deref(d_p3).span, Text::lit("a `derive` line follows a type declaration")), std::optional<Text>{}})
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : prism_rtl::is<crate::syntax::decls::DeclKind::DTag>(_m) ? ({
        auto&& t_pe = prism_rtl::as<crate::syntax::decls::DeclKind::DTag>(_m).a0;
        ({
        auto name_pf = crate::check::env::dotted(prism_rtl::deref(t_pe).name->path_);
        auto family_pg = crate::check::env::dotted(take(prism_rtl::deref(t_pe).name->path_, crate::syntax::lexer::chars::dec(len(prism_rtl::deref(t_pe).name->path_))));
        auto tags_ph = or_(crate::prelude::get(prism_rtl::deref(g_p0).families, family_pg), Array<Text>{});
        auto owner_pi = or_(crate::prelude::get(prism_rtl::deref(g_p0).fam_owner, family_pg), prism_rtl::deref(info_p2).name);
        auto st2_pj = owner_pi != prism_rtl::deref(info_p2).name
            ? crate::check::types::recording::err(st_p1, Text::lit("collision"), prism_rtl::deref(d_p3).span, prism_rtl::cat("the family `", family_pg, "` is declared in ", owner_pi == Text::lit("")
            ? Text::lit("the root")
            : prism_rtl::cat("`", owner_pi, "`"), "; every tag of a family is declared in its family\'s module"))
            : st_p1;
        auto is_elem_pk = ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            auto&& _m = prism_rtl::deref(prism_rtl::deref(prism_rtl::deref(t_pe).of_type).kind);
            if (prism_rtl::is<crate::syntax::TypeKind::TName>(_m)) {
                auto&& n_pm = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a0;
                _v.set(crate::check::env::dotted(n_pm->path_) == Text::lit("Element"));
                goto _done;
            }
            {
                _v.set(false);
                goto _done;
            }
        _done:
            _v.take();
        });
        auto g2_pl = ({
            crate::check::env::G this_ = g_p0;
            this_.families = insert(this_.families, family_pg, crate::prelude::push(tags_ph, name_pf));
            this_.fam_owner = insert(this_.fam_owner, family_pg, owner_pi);
            if (std::move(is_elem_pk)) {
                this_.elem_fams = crate::check::types::add_text(this_.elem_fams, family_pg);
            }
            (std::move(this_));
        });
        (prism_rtl::finished(std::tuple{g2_pl, st2_pj, std::optional<Text>{}}));
    });
    })
        : prism_rtl::is<crate::syntax::decls::DeclKind::DTrait>(_m) ? ({
        auto&& t_pn = prism_rtl::as<crate::syntax::decls::DeclKind::DTrait>(_m).a0;
        ({
        auto name_po = crate::check::env::qual_key(prism_rtl::deref(info_p2).name, crate::check::env::dotted(prism_rtl::deref(t_pn).name->path_));
        auto ti_pp = crate::check::env::TraitInfo{.name = name_po, .home = prism_rtl::deref(info_p2).name, .param = or_(index(each(prism_rtl::deref(t_pn).params, [&](const crate::syntax::Ident& p_pr) { return prism_rtl::deref(p_pr).name; }), Nat(0u)), Text::lit("a")), .supers = Array<Text>{}, .methods = Array<Text>{}, .defaults = Array<Text>{}, .assocs = Array<Text>{}, .file = info_p2->file, .span = prism_rtl::deref(d_p3).span};
        auto upd_pq = ({
            crate::check::env::G this_ = g_p0;
            this_.traits = insert(this_.traits, name_po, ti_pp);
            (std::move(this_));
        });
        (prism_rtl::finished(std::tuple{upd_pq, st_p1, std::optional<Text>{}}));
    });
    })
        : prism_rtl::finished(std::tuple{g_p0, st_p1, std::optional<Text>{}});
    });
}


/// `Start CollectDecl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::env::G, crate::check::types::St, std::optional<Text>>> start_collect_decl(crate::check::env::G g_p0, crate::check::types::St st_p1, crate::check::env::ModInfo info_p2, crate::syntax::decls::Decl d_p3, std::optional<Text> last_type_o4) {
    return prism_rtl::make_rc<CollectDecl>(g_p0, st_p1, info_p2, d_p3, last_type_o4);
}


/// let dummyTyInfo
crate::check::env::TyInfo dummy_ty_info() {
    return crate::check::env::TyInfo{.name = Text::lit(""), .home = Text::lit(""), .params = Array<Text>{}, .body = crate::check::env::TyBody(crate::check::env::TyBody::BOpaque{}), .derives = Array<Text>{}, .file = Nat(0u), .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}};
}


/// AddDerives: fn TyInfo, [Text] -> TyInfo
crate::check::env::TyInfo add_derives(const crate::check::env::TyInfo& ti_p0, const Array<Text>& trs_p1) {
    crate::check::env::TyInfo this_ = ti_p0;
    this_.derives = append(this_.derives, trs_p1);
    return this_;
}


/// ProgramRow: fn G -> Rw
crate::check::types::Rw program_row(const crate::check::env::G& g_p0) {
    return crate::check::types::closed(g_p0.elem_fams);
}


/// BuildTables: unbounded fn G, St, Text -> ((G, St))
std::tuple<crate::check::env::G, crate::check::types::St> build_tables(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const Text& m_p2) {
    auto&& _m = crate::prelude::get(g_p0.mods, m_p2);
    if (prism_rtl::is_none(_m)) {
        return std::tuple{g_p0, st_p1};
    }
    if (prism_rtl::is_some(_m)) {
        auto&& info_p3 = prism_rtl::some_of(_m);
        auto s0_p4 = ({
            crate::check::types::St this_ = st_p1;
            this_.file = info_p3->file;
            (std::move(this_));
        });
        auto s1_p5 = fold(prism_rtl::deref(info_p3).uses, s0_p4, [&](const crate::check::types::St& s_pd, const std::tuple<Text, bool>& _p1) {
            auto&& u_pe = std::get<0>(_p1);
            return crate::check::env::has_key(g_p0.mods, u_pe) || (u_pe == Text::lit("Prelude"))
                ? s_pd
                : crate::check::types::recording::err(s_pd, Text::lit("unknown-name"), prism_rtl::deref(prism_rtl::deref(info_p3).tree).span, prism_rtl::cat("no module `", u_pe, "` among the program\'s files"));
        });
        auto starred_p6 = fold(prism_rtl::deref(info_p3).uses, Array<Text>{}, [&](const Array<Text>& acc_pf, const std::tuple<Text, bool>& _p1) {
            auto&& u_pg = std::get<0>(_p1);
            auto&& star_ph = std::get<1>(_p1);
            return prism_rtl::deref(star_ph) && (u_pg != m_p2)
                ? crate::prelude::push(acc_pf, u_pg)
                : acc_pf;
        });
        auto sources_p7 = crate::check::types::add_text(append(Array(std::vector{m_p2}), starred_p6), Text::lit("Prelude"));
        auto vals_p8 = run_to_end(fold_job(sources_p7, Map<Text, Array<Text>>{}, ({
            auto g_p0_1 = g_p0;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Array<Text>>>(std::tuple<Map<Text, Array<Text>>, Text>)>>(prism_rtl::rc([=, g_p0_1 = std::move(g_p0_1)](std::tuple<Map<Text, Array<Text>>, Text> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto g_p0_1_2 = g_p0_1;
                entered(once_job([=, g_p0_1_2 = std::move(g_p0_1_2)]() {
                return ({
                    auto acc_pi = p0;
                    auto src_pj = p1;
                    (prism_rtl::more(prism_rtl::rc(BareValuesOf(g_p0_1_2, src_pj, acc_pi))));
                });
            }));
            });
        }));
        })));
        auto tys_p9 = fold(sources_p7, Map<Text, Array<Text>>{}, [&](const Map<Text, Array<Text>>& acc_pk, const Text& src_pl) { return bare_types_of(g_p0, src_pl, acc_pk); });
        auto trs_pa = fold(sources_p7, Map<Text, Array<Text>>{}, [&](const Map<Text, Array<Text>>& acc_pm, const Text& src_pn) { return bare_traits_of(g_p0, src_pn, acc_pm); });
        auto [rw_po, rv_pp, s2_pq] = module_row(g_p0, s1_p5, info_p3);
        auto info2_pb = ({
            crate::check::env::ModInfo this_ = info_p3;
            this_.emit_rw = rw_po;
            this_.row_var = rv_pp;
            (std::move(this_));
        });
        auto upd_pc = ({
            crate::check::env::G this_ = g_p0;
            this_.bare = insert(this_.bare, m_p2, vals_p8);
            this_.bare_types = insert(this_.bare_types, m_p2, tys_p9);
            this_.bare_traits = insert(this_.bare_traits, m_p2, trs_pa);
            this_.mods = insert(this_.mods, m_p2, info2_pb);
            (std::move(this_));
        });
        return std::tuple{upd_pc, s2_pq};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<crate::check::env::G, crate::check::types::St>> BuildTables::cycle() const {
    const auto& g_p0 = this->g_p0;
    const auto& st_p1 = this->st_p1;
    const auto& m_p2 = this->m_p2;
    return ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(g_p0).mods, m_p2);
        prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{g_p0, st_p1})
        : prism_rtl::is_some(_m) ? ({
        auto&& info_p3 = prism_rtl::some_of(_m);
        ({
        auto s0_p4 = ({
            crate::check::types::St this_ = st_p1;
            this_.file = info_p3->file;
            (std::move(this_));
        });
        auto s1_p5 = fold(prism_rtl::deref(info_p3).uses, s0_p4, [&](const crate::check::types::St& s_pd, const std::tuple<Text, bool>& _p1) {
            auto&& u_pe = std::get<0>(_p1);
            return crate::check::env::has_key(prism_rtl::deref(g_p0).mods, u_pe) || (u_pe == Text::lit("Prelude"))
                ? s_pd
                : crate::check::types::recording::err(s_pd, Text::lit("unknown-name"), prism_rtl::deref(prism_rtl::deref(info_p3).tree).span, prism_rtl::cat("no module `", u_pe, "` among the program\'s files"));
        });
        auto starred_p6 = fold(prism_rtl::deref(info_p3).uses, Array<Text>{}, [&](const Array<Text>& acc_pf, const std::tuple<Text, bool>& _p1) {
            auto&& u_pg = std::get<0>(_p1);
            auto&& star_ph = std::get<1>(_p1);
            return prism_rtl::deref(star_ph) && (u_pg != m_p2)
                ? crate::prelude::push(acc_pf, u_pg)
                : acc_pf;
        });
        auto sources_p7 = crate::check::types::add_text(append(Array(std::vector{m_p2}), starred_p6), Text::lit("Prelude"));
        auto g_p0_1 = g_p0;
        auto m_p2_2 = m_p2;
        call_value(fold_job(sources_p7, Map<Text, Array<Text>>{}, ({
        auto g_p0_1_3 = g_p0_1;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Array<Text>>>(std::tuple<Map<Text, Array<Text>>, Text>)>>(prism_rtl::rc([=, g_p0_1_3 = std::move(g_p0_1_3)](std::tuple<Map<Text, Array<Text>>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_p0_1_3_3 = g_p0_1_3;
            entered(once_job([=, g_p0_1_3_3 = std::move(g_p0_1_3_3)]() {
            return ({
                auto acc_pi = p0;
                auto src_pj = p1;
                (prism_rtl::more(prism_rtl::rc(BareValuesOf(g_p0_1_3_3, src_pj, acc_pi))));
            });
        }));
        });
    }));
    })), [=, s1_p5 = std::move(s1_p5), m_p2_2 = std::move(m_p2_2)](Map<Text, Array<Text>> fold_4611) {
        return ({
            auto vals_p8 = fold_4611;
            auto tys_p9 = fold(sources_p7, Map<Text, Array<Text>>{}, [&](const Map<Text, Array<Text>>& acc_pk, const Text& src_pl) { return bare_types_of(g_p0_1, src_pl, acc_pk); });
            auto trs_pa = fold(sources_p7, Map<Text, Array<Text>>{}, [&](const Map<Text, Array<Text>>& acc_pm, const Text& src_pn) { return bare_traits_of(g_p0_1, src_pn, acc_pm); });
            call_then(start_module_row(g_p0_1, s1_p5, info_p3), [=, vals_p8 = std::move(vals_p8), tys_p9 = std::move(tys_p9), trs_pa = std::move(trs_pa)](std::tuple<crate::check::types::Rw, Text, crate::check::types::St> module_row_4840) {
            return ({
                auto [rw_po, rv_pp, s2_pq] = module_row_4840;
                auto info2_pb = ({
                    crate::check::env::ModInfo this_ = info_p3;
                    this_.emit_rw = rw_po;
                    this_.row_var = rv_pp;
                    (std::move(this_));
                });
                auto upd_pc = ({
                    crate::check::env::G this_ = g_p0_1;
                    this_.bare = insert(this_.bare, m_p2_2, vals_p8);
                    this_.bare_types = insert(this_.bare_types, m_p2_2, tys_p9);
                    this_.bare_traits = insert(this_.bare_traits, m_p2_2, trs_pa);
                    this_.mods = insert(this_.mods, m_p2_2, info2_pb);
                    (std::move(this_));
                });
                (prism_rtl::finished(std::tuple{upd_pc, s2_pq}));
            });
        });
        });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start BuildTables, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::env::G, crate::check::types::St>> start_build_tables(crate::check::env::G g_p0, crate::check::types::St st_p1, Text m_p2) {
    return prism_rtl::make_rc<BuildTables>(g_p0, st_p1, m_p2);
}


/// AddBare: fn (Text ==> [Text]), Text, Text -> (Text ==> [Text])
Map<Text, Array<Text>> add_bare(const Map<Text, Array<Text>>& acc_p0, const Text& name_p1, const Text& qk_p2) {
    auto have_p3 = or_(crate::prelude::get(acc_p0, name_p1), Array<Text>{});
    return crate::check::types::has_text(have_p3, qk_p2)
        ? acc_p0
        : insert(acc_p0, name_p1, crate::prelude::push(have_p3, qk_p2));
}


/// BareValuesOf: unbounded fn G, Text, (Text ==> [Text]) -> (Text ==> [Text])
Map<Text, Array<Text>> bare_values_of(const crate::check::env::G& g_p0, const Text& src_p1, const Map<Text, Array<Text>>& acc_p2) {
    auto&& _m = crate::prelude::get(g_p0.mods, src_p1);
    if (prism_rtl::is_none(_m)) {
        return acc_p2;
    }
    if (prism_rtl::is_some(_m)) {
        auto&& info_p3 = prism_rtl::some_of(_m);
        return run_to_end(fold_job(prism_rtl::deref(prism_rtl::deref(info_p3).tree).decls, acc_p2, ({
            auto src_p1_1 = src_p1;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Array<Text>>>(std::tuple<Map<Text, Array<Text>>, crate::syntax::decls::Decl>)>>(prism_rtl::rc([=, src_p1_1 = std::move(src_p1_1)](std::tuple<Map<Text, Array<Text>>, crate::syntax::decls::Decl> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto src_p1_1_2 = src_p1_1;
                entered(once_job([=, src_p1_1_2 = std::move(src_p1_1_2)]() {
                return ({
                    auto a_p4 = p0;
                    auto d_p5 = p1;
                    (prism_rtl::more(prism_rtl::rc(BareOfDecl(src_p1_1_2, a_p4, d_p5))));
                });
            }));
            });
        }));
        })));
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Map<Text, Array<Text>>> BareValuesOf::cycle() const {
    const auto& g_p0 = this->g_p0;
    const auto& src_p1 = this->src_p1;
    const auto& acc_p2 = this->acc_p2;
    return ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(g_p0).mods, src_p1);
        prism_rtl::is_none(_m) ? prism_rtl::finished(acc_p2)
        : prism_rtl::is_some(_m) ? ({
        auto&& info_p3 = prism_rtl::some_of(_m);
        fold_job(prism_rtl::deref(prism_rtl::deref(info_p3).tree).decls, acc_p2, ({
        auto src_p1_1 = src_p1;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Array<Text>>>(std::tuple<Map<Text, Array<Text>>, crate::syntax::decls::Decl>)>>(prism_rtl::rc([=, src_p1_1 = std::move(src_p1_1)](std::tuple<Map<Text, Array<Text>>, crate::syntax::decls::Decl> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto src_p1_1_2 = src_p1_1;
            entered(once_job([=, src_p1_1_2 = std::move(src_p1_1_2)]() {
            return ({
                auto a_p4 = p0;
                auto d_p5 = p1;
                (prism_rtl::more(prism_rtl::rc(BareOfDecl(src_p1_1_2, a_p4, d_p5))));
            });
        }));
        });
    }));
    }))->cycle();
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start BareValuesOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, Array<Text>>> start_bare_values_of(crate::check::env::G g_p0, Text src_p1, Map<Text, Array<Text>> acc_p2) {
    return prism_rtl::make_rc<BareValuesOf>(g_p0, src_p1, acc_p2);
}


/// BareOfDecl: unbounded fn Text, (Text ==> [Text]), Decl -> (Text ==> [Text])
Map<Text, Array<Text>> bare_of_decl(const Text& m_p0, const Map<Text, Array<Text>>& acc_p1, const crate::syntax::decls::Decl& d_p2) {
    auto&& _m = d_p2.kind;
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DSignature>(_m)) {
        auto&& s_p3 = prism_rtl::as<crate::syntax::decls::DeclKind::DSignature>(_m).a0;
        return add_bare(acc_p1, crate::check::env::def_name_text(prism_rtl::deref(s_p3).name), crate::check::env::qual_key(m_p0, crate::check::env::def_name_text(prism_rtl::deref(s_p3).name)));
    }
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DFn>(_m)) {
        auto&& f_p4 = prism_rtl::as<crate::syntax::decls::DeclKind::DFn>(_m).a0;
        return add_bare(acc_p1, crate::check::env::def_name_text(prism_rtl::deref(f_p4).name), crate::check::env::qual_key(m_p0, crate::check::env::def_name_text(prism_rtl::deref(f_p4).name)));
    }
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DLet>(_m)) {
        auto&& l_p5 = prism_rtl::as<crate::syntax::decls::DeclKind::DLet>(_m).a0;
        return fold(pattern_names(prism_rtl::deref(l_p5).pattern), acc_p1, [&](const Map<Text, Array<Text>>& a_p6, const Text& n_p7) { return add_bare(a_p6, n_p7, crate::check::env::qual_key(m_p0, n_p7)); });
    }
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DWidget>(_m)) {
        auto&& w_p8 = prism_rtl::as<crate::syntax::decls::DeclKind::DWidget>(_m).a0;
        return add_bare(acc_p1, crate::check::env::sname_key(prism_rtl::deref(w_p8).name), crate::check::env::qual_key(m_p0, crate::check::env::sname_key(prism_rtl::deref(w_p8).name)));
    }
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DType>(_m)) {
        auto&& t_p9 = prism_rtl::as<crate::syntax::decls::DeclKind::DType>(_m).a0;
        return fold(ctor_names_of(t_p9), acc_p1, [&](const Map<Text, Array<Text>>& a_pa, const Text& c_pb) { return add_bare(a_pa, c_pb, crate::check::env::qual_key(m_p0, c_pb)); });
    }
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DTrait>(_m)) {
        auto&& t_pc = prism_rtl::as<crate::syntax::decls::DeclKind::DTrait>(_m).a0;
        return fold(prism_rtl::deref(t_pc).items, acc_p1, [&](const Map<Text, Array<Text>>& a_pd, const crate::syntax::decls::TraitItem& it_pe) {
            return ({
                __label__ _done;
                prism_rtl::Slot<Map<Text, Array<Text>>> _v;
                if (prism_rtl::is<crate::syntax::decls::TraitItem::TiSignature>(it_pe)) {
                    auto&& s_pf = prism_rtl::as<crate::syntax::decls::TraitItem::TiSignature>(it_pe).a0;
                    _v.set(add_bare(a_pd, crate::check::env::def_name_text(prism_rtl::deref(s_pf).name), crate::check::env::qual_key(m_p0, crate::check::env::def_name_text(prism_rtl::deref(s_pf).name))));
                    goto _done;
                }
                {
                    _v.set(a_pd);
                    goto _done;
                }
            _done:
                _v.take();
            });
        });
    }
    {
        return acc_p1;
    }
}


prism_rtl::Turn<Map<Text, Array<Text>>> BareOfDecl::cycle() const {
    const auto& m_p0 = this->m_p0;
    const auto& acc_p1 = this->acc_p1;
    const auto& d_p2 = this->d_p2;
    return ({
        auto&& _m = prism_rtl::deref(d_p2).kind;
        prism_rtl::is<crate::syntax::decls::DeclKind::DSignature>(_m) ? ({
        auto&& s_p3 = prism_rtl::as<crate::syntax::decls::DeclKind::DSignature>(_m).a0;
        prism_rtl::finished(add_bare(acc_p1, crate::check::env::def_name_text(prism_rtl::deref(s_p3).name), crate::check::env::qual_key(m_p0, crate::check::env::def_name_text(prism_rtl::deref(s_p3).name))));
    })
        : prism_rtl::is<crate::syntax::decls::DeclKind::DFn>(_m) ? ({
        auto&& f_p4 = prism_rtl::as<crate::syntax::decls::DeclKind::DFn>(_m).a0;
        prism_rtl::finished(add_bare(acc_p1, crate::check::env::def_name_text(prism_rtl::deref(f_p4).name), crate::check::env::qual_key(m_p0, crate::check::env::def_name_text(prism_rtl::deref(f_p4).name))));
    })
        : prism_rtl::is<crate::syntax::decls::DeclKind::DLet>(_m) ? ({
        auto&& l_p5 = prism_rtl::as<crate::syntax::decls::DeclKind::DLet>(_m).a0;
        ({
        auto acc_p1_1 = acc_p1;
        auto l_p5_2 = l_p5;
        auto m_p0_3 = m_p0;
        call_then(start_pattern_names(prism_rtl::deref(l_p5_2).pattern), [=, acc_p1_1 = std::move(acc_p1_1), m_p0_3 = std::move(m_p0_3)](Array<Text> pattern_names_5985) { return prism_rtl::finished(fold(pattern_names_5985, acc_p1_1, [&](const Map<Text, Array<Text>>& a_p6, const Text& n_p7) { return add_bare(a_p6, n_p7, crate::check::env::qual_key(m_p0_3, n_p7)); })); });
    });
    })
        : prism_rtl::is<crate::syntax::decls::DeclKind::DWidget>(_m) ? ({
        auto&& w_p8 = prism_rtl::as<crate::syntax::decls::DeclKind::DWidget>(_m).a0;
        prism_rtl::finished(add_bare(acc_p1, crate::check::env::sname_key(prism_rtl::deref(w_p8).name), crate::check::env::qual_key(m_p0, crate::check::env::sname_key(prism_rtl::deref(w_p8).name))));
    })
        : prism_rtl::is<crate::syntax::decls::DeclKind::DType>(_m) ? ({
        auto&& t_p9 = prism_rtl::as<crate::syntax::decls::DeclKind::DType>(_m).a0;
        prism_rtl::finished(fold(ctor_names_of(t_p9), acc_p1, [&](const Map<Text, Array<Text>>& a_pa, const Text& c_pb) { return add_bare(a_pa, c_pb, crate::check::env::qual_key(m_p0, c_pb)); }));
    })
        : prism_rtl::is<crate::syntax::decls::DeclKind::DTrait>(_m) ? ({
        auto&& t_pc = prism_rtl::as<crate::syntax::decls::DeclKind::DTrait>(_m).a0;
        prism_rtl::finished(fold(prism_rtl::deref(t_pc).items, acc_p1, [&](const Map<Text, Array<Text>>& a_pd, const crate::syntax::decls::TraitItem& it_pe) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Map<Text, Array<Text>>> _v;
            if (prism_rtl::is<crate::syntax::decls::TraitItem::TiSignature>(it_pe)) {
                auto&& s_pf = prism_rtl::as<crate::syntax::decls::TraitItem::TiSignature>(it_pe).a0;
                _v.set(add_bare(a_pd, crate::check::env::def_name_text(prism_rtl::deref(s_pf).name), crate::check::env::qual_key(m_p0, crate::check::env::def_name_text(prism_rtl::deref(s_pf).name))));
                goto _done;
            }
            {
                _v.set(a_pd);
                goto _done;
            }
        _done:
            _v.take();
        });
    }));
    })
        : prism_rtl::finished(acc_p1);
    });
}


/// `Start BareOfDecl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, Array<Text>>> start_bare_of_decl(Text m_p0, Map<Text, Array<Text>> acc_p1, crate::syntax::decls::Decl d_p2) {
    return prism_rtl::make_rc<BareOfDecl>(m_p0, acc_p1, d_p2);
}


/// CtorNamesOf: fn TypeDecl -> [Text]
Array<Text> ctor_names_of(const crate::syntax::decls::TypeDecl& t_p0) {
    auto&& _m = t_p0.body;
    if (prism_rtl::is_some(_m) && prism_rtl::is<crate::syntax::decls::TypeBody::TbRecord>(prism_rtl::some_of(_m))) {
        return Array(std::vector{crate::check::env::dotted(t_p0.name->path_)});
    }
    if (prism_rtl::is_some(_m) && prism_rtl::is<crate::syntax::decls::TypeBody::TbChoice>(prism_rtl::some_of(_m))) {
        auto&& cs_p1 = prism_rtl::as<crate::syntax::decls::TypeBody::TbChoice>(prism_rtl::some_of(_m)).a0;
        return each(cs_p1, [&](const crate::syntax::decls::Case_& c_p2) { return crate::check::env::sname_key(prism_rtl::deref(c_p2).name); });
    }
    if (prism_rtl::is_some(_m) && prism_rtl::is<crate::syntax::decls::TypeBody::TbNewtype>(prism_rtl::some_of(_m))) {
        auto&& c_p3 = prism_rtl::as<crate::syntax::decls::TypeBody::TbNewtype>(prism_rtl::some_of(_m)).a0;
        return Array(std::vector{crate::check::env::sname_key(prism_rtl::deref(c_p3).name)});
    }
    if (prism_rtl::is_some(_m) && prism_rtl::is<crate::syntax::decls::TypeBody::TbUnit>(prism_rtl::some_of(_m))) {
        auto&& i_p4 = prism_rtl::as<crate::syntax::decls::TypeBody::TbUnit>(prism_rtl::some_of(_m)).a0;
        return Array(std::vector{prism_rtl::deref(i_p4).name});
    }
    {
        return Array<Text>{};
    }
}


/// PatternNames: unbounded fn Pattern -> [Text]
Array<Text> pattern_names(const crate::syntax::Pattern_& p_p0) {
    auto&& _m = prism_rtl::deref(p_p0.kind);
    if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
        auto&& n_p1 = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        return Array(std::vector{crate::check::env::sname_key(n_p1)});
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PCtor>(_m)) {
        auto&& ps_p2 = prism_rtl::as<crate::syntax::PatternKind::PCtor>(_m).a1;
        return run_to_end(fold_job(ps_p2, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Pattern_> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc_p3 = p0;
                    auto q_p4 = p1;
                    call_then(start_pattern_names(q_p4), [=, acc_p3 = std::move(acc_p3)](Array<Text> pattern_names_6861) { return prism_rtl::finished(append(acc_p3, pattern_names_6861)); });
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PRecord>(_m)) {
        auto&& fs_p5 = prism_rtl::as<crate::syntax::PatternKind::PRecord>(_m).a1;
        return run_to_end(fold_job(fs_p5, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::FieldPat>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::FieldPat> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc_p6 = p0;
                    auto f_p7 = p1;
                    call_then(start_pattern_names(prism_rtl::deref(f_p7).pattern), [=, acc_p6 = std::move(acc_p6)](Array<Text> pattern_names_6947) { return prism_rtl::finished(append(acc_p6, pattern_names_6947)); });
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PSigil>(_m)) {
        auto&& q_p8 = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a1;
        return pattern_names(prism_rtl::deref(prism_rtl::deref(q_p8)));
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PTuple>(_m)) {
        auto&& ps_p9 = prism_rtl::as<crate::syntax::PatternKind::PTuple>(_m).a0;
        return run_to_end(fold_job(ps_p9, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Pattern_> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc_pa = p0;
                    auto q_pb = p1;
                    call_then(start_pattern_names(q_pb), [=, acc_pa = std::move(acc_pa)](Array<Text> pattern_names_7061) { return prism_rtl::finished(append(acc_pa, pattern_names_7061)); });
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PArray>(_m)) {
        auto&& ps_pc = prism_rtl::as<crate::syntax::PatternKind::PArray>(_m).a0;
        return run_to_end(fold_job(ps_pc, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Pattern_> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc_pd = p0;
                    auto q_pe = p1;
                    call_then(start_pattern_names(q_pe), [=, acc_pd = std::move(acc_pd)](Array<Text> pattern_names_7130) { return prism_rtl::finished(append(acc_pd, pattern_names_7130)); });
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PGroup>(_m)) {
        auto&& q_pf = prism_rtl::as<crate::syntax::PatternKind::PGroup>(_m).a0;
        return pattern_names(prism_rtl::deref(prism_rtl::deref(q_pf)));
    }
    {
        return Array<Text>{};
    }
}


prism_rtl::Turn<Array<Text>> PatternNames::cycle() const {
    const auto& p_p0 = this->p_p0;
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(p_p0).kind);
        prism_rtl::is<crate::syntax::PatternKind::PName>(_m) ? ({
        auto&& n_p1 = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        prism_rtl::finished(Array(std::vector{crate::check::env::sname_key(n_p1)}));
    })
        : prism_rtl::is<crate::syntax::PatternKind::PCtor>(_m) ? ({
        auto&& ps_p2 = prism_rtl::as<crate::syntax::PatternKind::PCtor>(_m).a1;
        fold_job(ps_p2, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Pattern_> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc_p3 = p0;
                auto q_p4 = p1;
                call_then(start_pattern_names(q_p4), [=, acc_p3 = std::move(acc_p3)](Array<Text> pattern_names_6861) { return prism_rtl::finished(append(acc_p3, pattern_names_6861)); });
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::syntax::PatternKind::PRecord>(_m) ? ({
        auto&& fs_p5 = prism_rtl::as<crate::syntax::PatternKind::PRecord>(_m).a1;
        fold_job(fs_p5, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::FieldPat>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::FieldPat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc_p6 = p0;
                auto f_p7 = p1;
                call_then(start_pattern_names(prism_rtl::deref(f_p7).pattern), [=, acc_p6 = std::move(acc_p6)](Array<Text> pattern_names_6947) { return prism_rtl::finished(append(acc_p6, pattern_names_6947)); });
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::syntax::PatternKind::PSigil>(_m) ? ({
        auto&& q_p8 = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a1;
        prism_rtl::more(prism_rtl::rc(PatternNames(prism_rtl::deref(prism_rtl::deref(q_p8)))));
    })
        : prism_rtl::is<crate::syntax::PatternKind::PTuple>(_m) ? ({
        auto&& ps_p9 = prism_rtl::as<crate::syntax::PatternKind::PTuple>(_m).a0;
        fold_job(ps_p9, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Pattern_> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc_pa = p0;
                auto q_pb = p1;
                call_then(start_pattern_names(q_pb), [=, acc_pa = std::move(acc_pa)](Array<Text> pattern_names_7061) { return prism_rtl::finished(append(acc_pa, pattern_names_7061)); });
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::syntax::PatternKind::PArray>(_m) ? ({
        auto&& ps_pc = prism_rtl::as<crate::syntax::PatternKind::PArray>(_m).a0;
        fold_job(ps_pc, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Pattern_> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc_pd = p0;
                auto q_pe = p1;
                call_then(start_pattern_names(q_pe), [=, acc_pd = std::move(acc_pd)](Array<Text> pattern_names_7130) { return prism_rtl::finished(append(acc_pd, pattern_names_7130)); });
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::syntax::PatternKind::PGroup>(_m) ? ({
        auto&& q_pf = prism_rtl::as<crate::syntax::PatternKind::PGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(PatternNames(prism_rtl::deref(prism_rtl::deref(q_pf)))));
    })
        : prism_rtl::finished(Array<Text>{});
    });
}


/// `Start PatternNames, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_pattern_names(crate::syntax::Pattern_ p_p0) {
    return prism_rtl::make_rc<PatternNames>(p_p0);
}


/// PatternBinders: unbounded fn Pattern -> [((Text, Range))]
Array<std::tuple<Text, crate::syntax::Range>> pattern_binders(const crate::syntax::Pattern_& p_p0) {
    auto&& _m = prism_rtl::deref(p_p0.kind);
    if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
        auto&& n_p1 = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        return Array(std::vector{std::tuple{crate::check::env::sname_key(n_p1), prism_rtl::deref(n_p1).span}});
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PCtor>(_m)) {
        auto&& ps_p2 = prism_rtl::as<crate::syntax::PatternKind::PCtor>(_m).a1;
        return run_to_end(fold_job(ps_p2, Array<std::tuple<Text, crate::syntax::Range>>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Text, crate::syntax::Range>>>(std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::syntax::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::syntax::Pattern_> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc_p3 = p0;
                    auto q_p4 = p1;
                    call_then(start_pattern_binders(q_p4), [=, acc_p3 = std::move(acc_p3)](Array<std::tuple<Text, crate::syntax::Range>> pattern_binders_7450) { return prism_rtl::finished(append(acc_p3, pattern_binders_7450)); });
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PRecord>(_m)) {
        auto&& fs_p5 = prism_rtl::as<crate::syntax::PatternKind::PRecord>(_m).a1;
        return run_to_end(fold_job(fs_p5, Array<std::tuple<Text, crate::syntax::Range>>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Text, crate::syntax::Range>>>(std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::syntax::FieldPat>)>>(prism_rtl::rc([=](std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::syntax::FieldPat> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc_p6 = p0;
                    auto f_p7 = p1;
                    call_then(start_pattern_binders(prism_rtl::deref(f_p7).pattern), [=, acc_p6 = std::move(acc_p6)](Array<std::tuple<Text, crate::syntax::Range>> pattern_binders_7538) { return prism_rtl::finished(append(acc_p6, pattern_binders_7538)); });
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PSigil>(_m)) {
        auto&& q_p8 = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a1;
        return pattern_binders(prism_rtl::deref(prism_rtl::deref(q_p8)));
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PTuple>(_m)) {
        auto&& ps_p9 = prism_rtl::as<crate::syntax::PatternKind::PTuple>(_m).a0;
        return run_to_end(fold_job(ps_p9, Array<std::tuple<Text, crate::syntax::Range>>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Text, crate::syntax::Range>>>(std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::syntax::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::syntax::Pattern_> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc_pa = p0;
                    auto q_pb = p1;
                    call_then(start_pattern_binders(q_pb), [=, acc_pa = std::move(acc_pa)](Array<std::tuple<Text, crate::syntax::Range>> pattern_binders_7656) { return prism_rtl::finished(append(acc_pa, pattern_binders_7656)); });
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PArray>(_m)) {
        auto&& ps_pc = prism_rtl::as<crate::syntax::PatternKind::PArray>(_m).a0;
        return run_to_end(fold_job(ps_pc, Array<std::tuple<Text, crate::syntax::Range>>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Text, crate::syntax::Range>>>(std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::syntax::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::syntax::Pattern_> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc_pd = p0;
                    auto q_pe = p1;
                    call_then(start_pattern_binders(q_pe), [=, acc_pd = std::move(acc_pd)](Array<std::tuple<Text, crate::syntax::Range>> pattern_binders_7727) { return prism_rtl::finished(append(acc_pd, pattern_binders_7727)); });
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PGroup>(_m)) {
        auto&& q_pf = prism_rtl::as<crate::syntax::PatternKind::PGroup>(_m).a0;
        return pattern_binders(prism_rtl::deref(prism_rtl::deref(q_pf)));
    }
    {
        return Array<std::tuple<Text, crate::syntax::Range>>{};
    }
}


prism_rtl::Turn<Array<std::tuple<Text, crate::syntax::Range>>> PatternBinders::cycle() const {
    const auto& p_p0 = this->p_p0;
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(p_p0).kind);
        prism_rtl::is<crate::syntax::PatternKind::PName>(_m) ? ({
        auto&& n_p1 = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        prism_rtl::finished(Array(std::vector{std::tuple{crate::check::env::sname_key(n_p1), prism_rtl::deref(n_p1).span}}));
    })
        : prism_rtl::is<crate::syntax::PatternKind::PCtor>(_m) ? ({
        auto&& ps_p2 = prism_rtl::as<crate::syntax::PatternKind::PCtor>(_m).a1;
        fold_job(ps_p2, Array<std::tuple<Text, crate::syntax::Range>>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Text, crate::syntax::Range>>>(std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::syntax::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::syntax::Pattern_> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc_p3 = p0;
                auto q_p4 = p1;
                call_then(start_pattern_binders(q_p4), [=, acc_p3 = std::move(acc_p3)](Array<std::tuple<Text, crate::syntax::Range>> pattern_binders_7450) { return prism_rtl::finished(append(acc_p3, pattern_binders_7450)); });
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::syntax::PatternKind::PRecord>(_m) ? ({
        auto&& fs_p5 = prism_rtl::as<crate::syntax::PatternKind::PRecord>(_m).a1;
        fold_job(fs_p5, Array<std::tuple<Text, crate::syntax::Range>>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Text, crate::syntax::Range>>>(std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::syntax::FieldPat>)>>(prism_rtl::rc([=](std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::syntax::FieldPat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc_p6 = p0;
                auto f_p7 = p1;
                call_then(start_pattern_binders(prism_rtl::deref(f_p7).pattern), [=, acc_p6 = std::move(acc_p6)](Array<std::tuple<Text, crate::syntax::Range>> pattern_binders_7538) { return prism_rtl::finished(append(acc_p6, pattern_binders_7538)); });
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::syntax::PatternKind::PSigil>(_m) ? ({
        auto&& q_p8 = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a1;
        prism_rtl::more(prism_rtl::rc(PatternBinders(prism_rtl::deref(prism_rtl::deref(q_p8)))));
    })
        : prism_rtl::is<crate::syntax::PatternKind::PTuple>(_m) ? ({
        auto&& ps_p9 = prism_rtl::as<crate::syntax::PatternKind::PTuple>(_m).a0;
        fold_job(ps_p9, Array<std::tuple<Text, crate::syntax::Range>>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Text, crate::syntax::Range>>>(std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::syntax::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::syntax::Pattern_> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc_pa = p0;
                auto q_pb = p1;
                call_then(start_pattern_binders(q_pb), [=, acc_pa = std::move(acc_pa)](Array<std::tuple<Text, crate::syntax::Range>> pattern_binders_7656) { return prism_rtl::finished(append(acc_pa, pattern_binders_7656)); });
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::syntax::PatternKind::PArray>(_m) ? ({
        auto&& ps_pc = prism_rtl::as<crate::syntax::PatternKind::PArray>(_m).a0;
        fold_job(ps_pc, Array<std::tuple<Text, crate::syntax::Range>>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Text, crate::syntax::Range>>>(std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::syntax::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::syntax::Pattern_> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc_pd = p0;
                auto q_pe = p1;
                call_then(start_pattern_binders(q_pe), [=, acc_pd = std::move(acc_pd)](Array<std::tuple<Text, crate::syntax::Range>> pattern_binders_7727) { return prism_rtl::finished(append(acc_pd, pattern_binders_7727)); });
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::syntax::PatternKind::PGroup>(_m) ? ({
        auto&& q_pf = prism_rtl::as<crate::syntax::PatternKind::PGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(PatternBinders(prism_rtl::deref(prism_rtl::deref(q_pf)))));
    })
        : prism_rtl::finished(Array<std::tuple<Text, crate::syntax::Range>>{});
    });
}


/// `Start PatternBinders, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<std::tuple<Text, crate::syntax::Range>>> start_pattern_binders(crate::syntax::Pattern_ p_p0) {
    return prism_rtl::make_rc<PatternBinders>(p_p0);
}


/// BareTypesOf: fn G, Text, (Text ==> [Text]) -> (Text ==> [Text])
Map<Text, Array<Text>> bare_types_of(const crate::check::env::G& g_p0, const Text& src_p1, const Map<Text, Array<Text>>& acc_p2) {
    return fold(keys(g_p0.types), acc_p2, [&](const Map<Text, Array<Text>>& a_p3, const Text& k_p4) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Map<Text, Array<Text>>> _v;
            auto&& _m = crate::prelude::get(g_p0.types, k_p4);
            if (prism_rtl::is_some(_m)) {
                auto&& ti_p5 = prism_rtl::some_of(_m);
                _v.set(prism_rtl::deref(ti_p5).home == src_p1
                    ? add_bare(a_p3, crate::check::types::bare_name(prism_rtl::deref(ti_p5).name), k_p4)
                    : a_p3);
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(a_p3);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
}


/// BareTraitsOf: fn G, Text, (Text ==> [Text]) -> (Text ==> [Text])
Map<Text, Array<Text>> bare_traits_of(const crate::check::env::G& g_p0, const Text& src_p1, const Map<Text, Array<Text>>& acc_p2) {
    return fold(keys(g_p0.traits), acc_p2, [&](const Map<Text, Array<Text>>& a_p3, const Text& k_p4) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Map<Text, Array<Text>>> _v;
            auto&& _m = crate::prelude::get(g_p0.traits, k_p4);
            if (prism_rtl::is_some(_m)) {
                auto&& ti_p5 = prism_rtl::some_of(_m);
                _v.set(prism_rtl::deref(ti_p5).home == src_p1
                    ? add_bare(a_p3, crate::check::types::bare_name(prism_rtl::deref(ti_p5).name), k_p4)
                    : a_p3);
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(a_p3);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
}


/// ModuleRow: unbounded fn G, St, ModInfo -> ((Rw, Text, St))
std::tuple<crate::check::types::Rw, Text, crate::check::types::St> module_row(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const crate::check::env::ModInfo& info_p2) {
    auto&& _m = prism_rtl::deref(info_p2.tree).emit_row;
    if (prism_rtl::is_none(_m)) {
        return info_p2.root
            ? std::tuple{g_p0.program_row, Text::lit(""), st_p1}
            : std::tuple{crate::check::types::empty_row(), Text::lit(""), crate::check::types::recording::err(st_p1, Text::lit("emit-element"), prism_rtl::deref(info_p2.tree).span, Text::lit("a library writes its own row; this one writes no `emit` line"))};
    }
    if (prism_rtl::is_some(_m)) {
        auto&& row_decl_p3 = prism_rtl::some_of(_m);
        auto [fams_pa, vars_pb, s2_pc] = fold(prism_rtl::deref(row_decl_p3).terms, std::tuple{Array<Text>{}, Array<Text>{}, st_p1}, [&](const std::tuple<Array<Text>, Array<Text>, crate::check::types::St>& _p0, const crate::syntax::RowTerm& term_p9) {
            auto&& fs_p6 = std::get<0>(_p0);
            auto&& vs_p7 = std::get<1>(_p0);
            auto&& s_p8 = std::get<2>(_p0);
            return row_term_of(g_p0, s_p8, info_p2, term_p9, fs_p6, vs_p7);
        });
        auto s3_p4 = len(vars_pb) > Nat(1u)
            ? crate::check::types::recording::err_fix(s2_pc, Text::lit("row-two-tails"), prism_rtl::deref(row_decl_p3).span, prism_rtl::cat("a row has one variable; `", crate::syntax::lexer::chars::join(vars_pb, Text::lit(" | ")), "` names two"), Text::lit("keep one variable"))
            : s2_pc;
        auto tail_p5 = ({
            __label__ _done;
            prism_rtl::Slot<crate::check::types::Tail> _v;
            auto&& _m = index(vars_pb, Nat(0u));
            if (prism_rtl::is_some(_m)) {
                auto&& v_pd = prism_rtl::some_of(_m);
                _v.set(crate::check::types::Tail(crate::check::types::Tail::TlQ{v_pd}));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(crate::check::types::Tail(crate::check::types::Tail::TlClosed{}));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        return std::tuple{crate::check::types::Rw{.fams = crate::check::types::sort_texts(fams_pa), .minus = Array<Text>{}, .tail = tail_p5}, or_(index(vars_pb, Nat(0u)), Text::lit("")), s3_p4};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<crate::check::types::Rw, Text, crate::check::types::St>> ModuleRow::cycle() const {
    const auto& g_p0 = this->g_p0;
    const auto& st_p1 = this->st_p1;
    const auto& info_p2 = this->info_p2;
    return ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(info_p2).tree).emit_row;
        prism_rtl::is_none(_m) ? info_p2->root
        ? prism_rtl::finished(std::tuple{prism_rtl::deref(g_p0).program_row, Text::lit(""), st_p1})
        : prism_rtl::finished(std::tuple{crate::check::types::empty_row(), Text::lit(""), crate::check::types::recording::err(st_p1, Text::lit("emit-element"), prism_rtl::deref(prism_rtl::deref(info_p2).tree).span, Text::lit("a library writes its own row; this one writes no `emit` line"))})
        : prism_rtl::is_some(_m) ? ({
        auto&& row_decl_p3 = prism_rtl::some_of(_m);
        ({
        auto [fams_pa, vars_pb, s2_pc] = fold(prism_rtl::deref(row_decl_p3).terms, std::tuple{Array<Text>{}, Array<Text>{}, st_p1}, [&](const std::tuple<Array<Text>, Array<Text>, crate::check::types::St>& _p0, const crate::syntax::RowTerm& term_p9) {
            auto&& fs_p6 = std::get<0>(_p0);
            auto&& vs_p7 = std::get<1>(_p0);
            auto&& s_p8 = std::get<2>(_p0);
            return row_term_of(g_p0, s_p8, info_p2, term_p9, fs_p6, vs_p7);
        });
        auto s3_p4 = len(vars_pb) > Nat(1u)
            ? crate::check::types::recording::err_fix(s2_pc, Text::lit("row-two-tails"), prism_rtl::deref(row_decl_p3).span, prism_rtl::cat("a row has one variable; `", crate::syntax::lexer::chars::join(vars_pb, Text::lit(" | ")), "` names two"), Text::lit("keep one variable"))
            : s2_pc;
        auto tail_p5 = ({
            __label__ _done;
            prism_rtl::Slot<crate::check::types::Tail> _v;
            auto&& _m = index(vars_pb, Nat(0u));
            if (prism_rtl::is_some(_m)) {
                auto&& v_pd = prism_rtl::some_of(_m);
                _v.set(crate::check::types::Tail(crate::check::types::Tail::TlQ{v_pd}));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(crate::check::types::Tail(crate::check::types::Tail::TlClosed{}));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        (prism_rtl::finished(std::tuple{crate::check::types::Rw{.fams = crate::check::types::sort_texts(fams_pa), .minus = Array<Text>{}, .tail = tail_p5}, or_(index(vars_pb, Nat(0u)), Text::lit("")), s3_p4}));
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ModuleRow, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Rw, Text, crate::check::types::St>> start_module_row(crate::check::env::G g_p0, crate::check::types::St st_p1, crate::check::env::ModInfo info_p2) {
    return prism_rtl::make_rc<ModuleRow>(g_p0, st_p1, info_p2);
}


/// RowTermOf: fn G, St, ModInfo, RowTerm, [Text], [Text] -> (([Text], [Text], St))
std::tuple<Array<Text>, Array<Text>, crate::check::types::St> row_term_of(const crate::check::env::G& g_p0, const crate::check::types::St& s_p1, const crate::check::env::ModInfo& info_p2, const crate::syntax::RowTerm& term_p3, const Array<Text>& fs_p4, const Array<Text>& vs_p5) {
    if (prism_rtl::is<crate::syntax::RowTerm::RFamily>(term_p3)) {
        auto&& q_p6 = prism_rtl::as<crate::syntax::RowTerm::RFamily>(term_p3).a0;
        return std::tuple{crate::prelude::push(fs_p4, crate::check::env::dotted(q_p6->path_)), vs_p5, check_family(g_p0, s_p1, crate::check::env::dotted(q_p6->path_), prism_rtl::deref(q_p6).span)};
    }
    if (prism_rtl::is<crate::syntax::RowTerm::RVar>(term_p3)) {
        auto&& v_p7 = prism_rtl::as<crate::syntax::RowTerm::RVar>(term_p3).a0;
        return std::tuple{fs_p4, crate::prelude::push(vs_p5, prism_rtl::deref(v_p7).name), s_p1};
    }
    if (prism_rtl::is<crate::syntax::RowTerm::RType>(term_p3)) {
        auto&& t_p8 = prism_rtl::as<crate::syntax::RowTerm::RType>(term_p3).a0;
        auto&& _m = prism_rtl::deref(prism_rtl::deref(t_p8).kind);
        if (prism_rtl::is<crate::syntax::TypeKind::TName>(_m)) {
            auto&& n_p9 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a0;
            auto&& m9527_0_1 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a1;
            if (m9527_0_1.size() == 0u) {
                auto name_pa = crate::check::env::dotted(n_p9->path_);
                return (name_pa == Text::lit("Element")) && info_p2.root
                    ? std::tuple{append(fs_p4, prism_rtl::deref(g_p0.program_row).fams), vs_p5, s_p1}
                    : name_pa == Text::lit("Element")
                    ? std::tuple{fs_p4, vs_p5, crate::check::types::recording::err(s_p1, Text::lit("emit-element"), prism_rtl::deref(t_p8).span, Text::lit("a library writes its own row; `emit Element` names the program\'s"))}
                    : crate::check::env::has_key(g_p0.tags, name_pa) || (len(n_p9->path_) > Nat(1u))
                    ? std::tuple{fs_p4, vs_p5, crate::check::types::recording::err_fix(s_p1, Text::lit("row-single-tag"), prism_rtl::deref(t_p8).span, prism_rtl::cat("a row names families, not tags: `", name_pa, "`"), prism_rtl::cat("write `", crate::check::env::dotted(take(n_p9->path_, crate::syntax::lexer::chars::dec(len(n_p9->path_)))), ".*`"))}
                    : std::tuple{fs_p4, vs_p5, crate::check::types::recording::err(s_p1, Text::lit("kind"), prism_rtl::deref(t_p8).span, prism_rtl::cat("`", name_pa, "` is not a row"))};
            }
        }
        {
            return std::tuple{fs_p4, vs_p5, crate::check::types::recording::err(s_p1, Text::lit("kind"), prism_rtl::deref(t_p8).span, Text::lit("this is not a row"))};
        }
    }
    prism_rtl::unreachable("no arm matched");
}


/// CheckFamily: fn G, St, Text, Range -> St
crate::check::types::St check_family(const crate::check::env::G& g_p0, const crate::check::types::St& s_p1, const Text& fam_p2, const crate::syntax::Range& span_p3) {
    return crate::check::env::has_key(g_p0.families, fam_p2)
        ? s_p1
        : crate::check::types::recording::err(s_p1, Text::lit("unknown-name"), span_p3, prism_rtl::cat("no family `", fam_p2, "`: no module declares a `", fam_p2, ".` tag"));
}


/// ResolveValue: fn G, Text, SName -> ((?Text, Text))
std::tuple<std::optional<Text>, Text> resolve_value(const crate::check::env::G& g_p0, const Text& m_p1, const crate::syntax::SName& n_p2) {
    auto marks_p3 = n_p2.sigils;
    return len(n_p2.path_) == Nat(1u)
        ? ({
        auto name_p4 = prism_rtl::cat(marks_p3, or_(index(n_p2.path_, Nat(0u)), Text::lit("")));
        auto table_p5 = or_(crate::prelude::get(g_p0.bare, m_p1), Map<Text, Array<Text>>{});
        auto keys_p6 = or_(crate::prelude::get(table_p5, name_p4), Array<Text>{});
        len(keys_p6) == Nat(1u)
        ? std::tuple{index(keys_p6, Nat(0u)), Text::lit("")}
        : len(keys_p6) > Nat(1u)
        ? std::tuple{std::optional(own_first(m_p1, keys_p6)), Text::lit("collision")}
        : name_p4 == Text::lit("never")
        ? std::tuple{std::optional(Text::lit("Prelude.never")), Text::lit("")}
        : crate::check::env::has_key(g_p0.ctors, name_p4)
        ? std::tuple{std::optional(name_p4), Text::lit("")}
        : std::tuple{std::optional<Text>{}, Text::lit("unknown")};
    })
        : ({
        auto qual_p7 = crate::check::env::qual_module(g_p0, take(n_p2.path_, crate::syntax::lexer::chars::dec(len(n_p2.path_))));
        auto last_p8 = or_(crate::syntax::lexer::chars::last(n_p2.path_), Text::lit(""));
        auto qk_p9 = crate::check::env::qual_key(qual_p7, prism_rtl::cat(marks_p3, last_p8));
        (len_text(marks_p3) == Nat(0u)) && crate::check::env::has_key(g_p0.tags, crate::check::env::dotted(n_p2.path_))
        ? std::tuple{std::optional(crate::check::env::dotted(n_p2.path_)), Text::lit("tag")}
        : crate::check::env::has_key(g_p0.vals, qk_p9) || crate::check::env::has_key(g_p0.ctors, qk_p9)
        ? std::tuple{std::optional(qk_p9), Text::lit("")}
        : std::tuple{std::optional<Text>{}, Text::lit("unknown")};
    });
}


/// ResolveType: fn G, Text, [Text] -> ((?Text, Text))
std::tuple<std::optional<Text>, Text> resolve_type(const crate::check::env::G& g_p0, const Text& m_p1, const Array<Text>& path_p2) {
    return len(path_p2) == Nat(1u)
        ? ({
        auto keys_p3 = or_(crate::prelude::get(or_(crate::prelude::get(g_p0.bare_types, m_p1), Map<Text, Array<Text>>{}), or_(index(path_p2, Nat(0u)), Text::lit(""))), Array<Text>{});
        len(keys_p3) == Nat(1u)
        ? std::tuple{index(keys_p3, Nat(0u)), Text::lit("")}
        : len(keys_p3) > Nat(1u)
        ? std::tuple{std::optional(own_first(m_p1, keys_p3)), Text::lit("collision")}
        : std::tuple{std::optional<Text>{}, Text::lit("unknown")};
    })
        : ({
        auto qk_p4 = crate::check::env::qual_key(crate::check::env::qual_module(g_p0, take(path_p2, crate::syntax::lexer::chars::dec(len(path_p2)))), or_(crate::syntax::lexer::chars::last(path_p2), Text::lit("")));
        crate::check::env::has_key(g_p0.types, qk_p4)
        ? std::tuple{std::optional(qk_p4), Text::lit("")}
        : std::tuple{std::optional<Text>{}, Text::lit("unknown")};
    });
}


/// OwnFirst: fn Text, [Text] -> Text
Text own_first(const Text& m_p0, const Array<Text>& keys_p1) {
    auto own_p2 = filter(keys_p1, [&](const Text& k_p3) { return (crate::check::env::qual_key(m_p0, crate::check::types::bare_name(k_p3)) == k_p3) || ((m_p0 == Text::lit("")) && (!crate::syntax::lexer::chars::contains(k_p3, Text::lit(".")))); });
    return or_(index(own_p2, Nat(0u)), or_(index(keys_p1, Nat(0u)), Text::lit("")));
}


/// ?ResolveTrait: fn G, Text, [Text] -> ?Text
std::optional<Text> resolve_trait(const crate::check::env::G& g_p0, const Text& m_p1, const Array<Text>& path_p2) {
    return len(path_p2) == Nat(1u)
        ? ({
        auto keys_p3 = or_(crate::prelude::get(or_(crate::prelude::get(g_p0.bare_traits, m_p1), Map<Text, Array<Text>>{}), or_(index(path_p2, Nat(0u)), Text::lit(""))), Array<Text>{});
        index(keys_p3, Nat(0u));
    })
        : ({
        auto qk_p4 = crate::check::env::qual_key(crate::check::env::qual_module(g_p0, take(path_p2, crate::syntax::lexer::chars::dec(len(path_p2)))), or_(crate::syntax::lexer::chars::last(path_p2), Text::lit("")));
        crate::check::env::has_key(g_p0.traits, qk_p4)
        ? std::optional(qk_p4)
        : std::optional<Text>{};
    });
}

}  // namespace crate::check::env::names
