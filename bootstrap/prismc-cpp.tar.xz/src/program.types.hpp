// The root module: its records, tags and newtypes (each after the types it holds) and its
// choices' cases, emitted by prismc (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include "program.decl.hpp"
#include "elem.decl.hpp"
#include "ast.decl.hpp"
#include "check_blocks.decl.hpp"
#include "check_env.decl.hpp"
#include "check_errors.decl.hpp"
#include "check_expr.decl.hpp"
#include "check_passes.decl.hpp"
#include "check_types.decl.hpp"
#include "cpp_prelude_template.decl.hpp"
#include "cpp_templates.decl.hpp"
#include "emit.decl.hpp"
#include "emit_cpp.decl.hpp"
#include "fs.decl.hpp"
#include "lexer.decl.hpp"
#include "lower.decl.hpp"
#include "parser.decl.hpp"
#include "prelude_template.decl.hpp"
#include "process.decl.hpp"
#include "rust_templates.decl.hpp"
#include "sexp.decl.hpp"
#include "typed.decl.hpp"

namespace crate {

using namespace prelude;

namespace program {

/// `CheckJob`:
///
/// ```prism
/// type CheckJob = record:
/// ```
struct CheckJob {
    using prism_value = void;
    Array<std::tuple<Text, Text>> files;
    Array<std::tuple<Text, Text>> prelude;
    Array<Text> world;
    bool typed;
    bool unused;
    const CheckJob* operator->() const { return this; }
    CheckJob* operator->() { return this; }
    bool operator==(const CheckJob&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<CheckJob> from_pod(const Pod& whole);
};


}  // namespace program

namespace program {

/// `CompileJob`:
///
/// ```prism
/// type CompileJob = record:
/// ```
struct CompileJob {
    using prism_value = void;
    Array<std::tuple<Text, Text>> files;
    Array<std::tuple<Text, Text>> prelude;
    Text name;
    Text runtime;
    Text target;
    const CompileJob* operator->() const { return this; }
    CompileJob* operator->() { return this; }
    bool operator==(const CompileJob&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<CompileJob> from_pod(const Pod& whole);
};


}  // namespace program

namespace program {

/// `CompileSettings`:
///
/// ```prism
/// type CompileSettings = record:
/// ```
struct CompileSettings {
    using prism_value = void;
    Text out;
    Text prelude;
    Text name;
    Text runtime;
    Text target;
    const CompileSettings* operator->() const { return this; }
    CompileSettings* operator->() { return this; }
    bool operator==(const CompileSettings&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<CompileSettings> from_pod(const Pod& whole);
};


}  // namespace program

namespace program {

/// `Compiled`:
///
/// ```prism
/// type Compiled = record:
/// ```
struct Compiled {
    using prism_value = void;
    Array<std::tuple<Text, Text>> files;
    bool failed;
    Text report;
    const Compiled* operator->() const { return this; }
    Compiled* operator->() { return this; }
    bool operator==(const Compiled&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Compiled> from_pod(const Pod& whole);
};


}  // namespace program

namespace program {

/// `Job`:
///
/// ```prism
/// type Job = record:
/// ```
struct Job_ {
    using prism_value = void;
    bool tokens;
    bool fragment;
    Text text;
    const Job_* operator->() const { return this; }
    Job_* operator->() { return this; }
    bool operator==(const Job_&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Job_> from_pod(const Pod& whole);
};


}  // namespace program

namespace program {

/// `Outcome`:
///
/// ```prism
/// type Outcome = record:
/// ```
struct Outcome_ {
    using prism_value = void;
    Text text;
    bool failed;
    Text report;
    const Outcome_* operator->() const { return this; }
    Outcome_* operator->() { return this; }
    bool operator==(const Outcome_&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Outcome_> from_pod(const Pod& whole);
};


}  // namespace program


}  // namespace crate
