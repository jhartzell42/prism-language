// The modules `Syntax.Parser`, `Syntax.Parser.Blocks`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <syntax/parser/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Syntax.Parser`, from `target/bootstrap/cpp-src/prismc/syntax/parser/mod.prism`.
namespace crate::syntax::parser {

void Pair::show(Printer& p) const {
    p.record("Pair", {{"partner", partner}, {"outer", outer}, {"inner", inner}});
}

Pod Pair::to_pod() const {
    return Pod::record("Pair", {{"partner", prism_rtl::to_pod(partner)}, {"outer", prism_rtl::to_pod(outer)}, {"inner", prism_rtl::to_pod(inner)}});
}

Result<Pair> Pair::from_pod(const Pod& whole) {
    return Pair{.partner = TRY(prism_rtl::from_pod<std::optional<Nat>>(TRY(crate::prelude::field(whole, "partner")))), .outer = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "outer")))), .inner = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "inner"))))};
}


bool Parsed::operator==(const Parsed& o) const { return tree == o.tree && diags == o.diags; }

void Parsed::show(Printer& p) const {
    p.record("Parsed", {{"tree", tree}, {"diags", diags}});
}

Pod Parsed::to_pod() const {
    return Pod::record("Parsed", {{"tree", prism_rtl::to_pod(tree)}, {"diags", prism_rtl::to_pod(diags)}});
}

Result<Parsed> Parsed::from_pod(const Pod& whole) {
    return Parsed{.tree = TRY(prism_rtl::from_pod<crate::syntax::Module>(TRY(crate::prelude::field(whole, "tree")))), .diags = TRY(prism_rtl::from_pod<Array<crate::syntax::Diag>>(TRY(crate::prelude::field(whole, "diags"))))};
}


bool Ps::operator==(const Ps& o) const { return toks == o.toks && pairs == o.pairs && pos == o.pos && diags == o.diags && out == o.out && step_mode == o.step_mode && in_trait == o.in_trait && bad == o.bad; }

void Ps::show(Printer& p) const {
    p.record("Ps", {{"toks", toks}, {"pairs", pairs}, {"pos", pos}, {"diags", diags}, {"out", out}, {"step_mode", step_mode}, {"in_trait", in_trait}, {"bad", bad}});
}

Pod Ps::to_pod() const {
    return Pod::record("Ps", {{"toks", prism_rtl::to_pod(toks)}, {"pairs", prism_rtl::to_pod(pairs)}, {"pos", prism_rtl::to_pod(pos)}, {"diags", prism_rtl::to_pod(diags)}, {"out", prism_rtl::to_pod(out)}, {"step_mode", prism_rtl::to_pod(step_mode)}, {"in_trait", prism_rtl::to_pod(in_trait)}, {"bad", prism_rtl::to_pod(bad)}});
}

Result<Ps> Ps::from_pod(const Pod& whole) {
    return Ps{.toks = TRY(prism_rtl::from_pod<Array<crate::syntax::lexer::Tok>>(TRY(crate::prelude::field(whole, "toks")))), .pairs = TRY(prism_rtl::from_pod<Array<Pair>>(TRY(crate::prelude::field(whole, "pairs")))), .pos = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "pos")))), .diags = TRY(prism_rtl::from_pod<Array<crate::syntax::Diag>>(TRY(crate::prelude::field(whole, "diags")))), .out = TRY(prism_rtl::from_pod<Array<crate::syntax::Diag>>(TRY(crate::prelude::field(whole, "out")))), .step_mode = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "step_mode")))), .in_trait = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "in_trait")))), .bad = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "bad"))))};
}


/// let noRange
crate::syntax::Range no_range() {
    return crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)};
}


/// let eofTok
crate::syntax::lexer::Tok eof_tok() {
    return crate::syntax::lexer::Tok{.kind = crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KEof{}), .span = no_range(), .touches = false, .line_start = false};
}


/// let noPair
Pair no_pair() {
    return Pair{.partner = std::optional<Nat>{}, .outer = false, .inner = false};
}


/// ParseFile: unbounded fn Text -> Parsed
Parsed parse_file(const Text& src) {
    auto lexed = crate::syntax::lexer::layout::lex_file(src);
    auto [m, p_] = crate::syntax::parser::decls::parse_module(new_ps(lexed->tokens), false);
    return Parsed{.tree = m, .diags = finish_diags(append(append(prism_rtl::deref(lexed).diags, prism_rtl::deref(p_).diags), p_->out))};
}


prism_rtl::Turn<Parsed> ParseFile::cycle() const {
    const auto& src = this->src;
    auto src_1 = src;
    return call_then(crate::syntax::lexer::layout::start_lex_file(src_1), [=](crate::syntax::lexer::Lexed lex_file_3387) {
        return ({
            auto lexed = lex_file_3387;
            call_then(start_new_ps(lexed->tokens), [=](Ps new_ps_3431) {
            return call_then(crate::syntax::parser::decls::start_parse_module(new_ps_3431, false), [=](std::tuple<crate::syntax::Module, Ps> parse_module_3418) {
                return ({
                    auto [m, p_] = parse_module_3418;
                    (prism_rtl::finished(Parsed{.tree = m, .diags = finish_diags(append(append(prism_rtl::deref(lexed).diags, prism_rtl::deref(p_).diags), p_->out))}));
                });
            });
        });
        });
    });
}


/// `Start ParseFile, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Parsed> start_parse_file(Text src) {
    return prism_rtl::make_rc<ParseFile>(src);
}


/// ParseFragment: unbounded fn Text -> Parsed
Parsed parse_fragment(const Text& src) {
    auto lexed = crate::syntax::lexer::layout::lex_file(src);
    auto [m, p_] = crate::syntax::parser::decls::parse_module(new_ps(lexed->tokens), true);
    return Parsed{.tree = m, .diags = finish_diags(append(append(prism_rtl::deref(lexed).diags, prism_rtl::deref(p_).diags), p_->out))};
}


prism_rtl::Turn<Parsed> ParseFragment::cycle() const {
    const auto& src = this->src;
    auto src_1 = src;
    return call_then(crate::syntax::lexer::layout::start_lex_file(src_1), [=](crate::syntax::lexer::Lexed lex_file_3780) {
        return ({
            auto lexed = lex_file_3780;
            call_then(start_new_ps(lexed->tokens), [=](Ps new_ps_3824) {
            return call_then(crate::syntax::parser::decls::start_parse_module(new_ps_3824, true), [=](std::tuple<crate::syntax::Module, Ps> parse_module_3811) {
                return ({
                    auto [m, p_] = parse_module_3811;
                    (prism_rtl::finished(Parsed{.tree = m, .diags = finish_diags(append(append(prism_rtl::deref(lexed).diags, prism_rtl::deref(p_).diags), p_->out))}));
                });
            });
        });
        });
    });
}


/// `Start ParseFragment, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Parsed> start_parse_fragment(Text src) {
    return prism_rtl::make_rc<ParseFragment>(src);
}


/// NewPs: unbounded fn [Tok] -> Ps
Ps new_ps(const Array<crate::syntax::lexer::Tok>& toks0) {
    auto ends = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = crate::syntax::lexer::chars::last(toks0);
        if (prism_rtl::is_some(_m)) {
            auto&& t = prism_rtl::some_of(_m);
            _v.set(prism_rtl::deref(t).kind == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KEof{}));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(false);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto end = ({
        __label__ _done;
        prism_rtl::Slot<crate::syntax::Range> _v;
        auto&& _m = crate::syntax::lexer::chars::last(toks0);
        if (prism_rtl::is_some(_m)) {
            auto&& t = prism_rtl::some_of(_m);
            _v.set(crate::syntax::Range{.start = prism_rtl::deref(prism_rtl::deref(t).span).end, .end = prism_rtl::deref(prism_rtl::deref(t).span).end});
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(no_range());
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto toks = std::move(ends)
        ? toks0
        : crate::prelude::push(toks0, crate::syntax::lexer::Tok{.kind = crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KEof{}), .span = end, .touches = false, .line_start = false});
    return Ps{.toks = toks, .pairs = pair_brackets(toks), .pos = Nat(0u), .diags = Array<crate::syntax::Diag>{}, .out = Array<crate::syntax::Diag>{}, .step_mode = false, .in_trait = false, .bad = false};
}


prism_rtl::Turn<Ps> NewPs::cycle() const {
    const auto& toks0 = this->toks0;
    auto ends = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = crate::syntax::lexer::chars::last(toks0);
        if (prism_rtl::is_some(_m)) {
            auto&& t = prism_rtl::some_of(_m);
            _v.set(prism_rtl::deref(t).kind == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KEof{}));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(false);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto end = ({
        __label__ _done;
        prism_rtl::Slot<crate::syntax::Range> _v;
        auto&& _m = crate::syntax::lexer::chars::last(toks0);
        if (prism_rtl::is_some(_m)) {
            auto&& t = prism_rtl::some_of(_m);
            _v.set(crate::syntax::Range{.start = prism_rtl::deref(prism_rtl::deref(t).span).end, .end = prism_rtl::deref(prism_rtl::deref(t).span).end});
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(no_range());
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto toks = std::move(ends)
        ? toks0
        : crate::prelude::push(toks0, crate::syntax::lexer::Tok{.kind = crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KEof{}), .span = end, .touches = false, .line_start = false});
    return call_then(start_pair_brackets(toks), [=](Array<Pair> pair_brackets_4303) { return prism_rtl::finished(Ps{.toks = toks, .pairs = pair_brackets_4303, .pos = Nat(0u), .diags = Array<crate::syntax::Diag>{}, .out = Array<crate::syntax::Diag>{}, .step_mode = false, .in_trait = false, .bad = false}); });
}


/// `Start NewPs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Ps> start_new_ps(Array<crate::syntax::lexer::Tok> toks0) {
    return prism_rtl::make_rc<NewPs>(toks0);
}


/// Sub: unbounded fn Ps, [Tok], Range -> Ps
Ps sub(const Ps& p_, const Array<crate::syntax::lexer::Tok>& toks, const crate::syntax::Range& end) {
    auto q = new_ps(crate::prelude::push(toks, crate::syntax::lexer::Tok{.kind = crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KEof{}), .span = end, .touches = false, .line_start = false}));
    Ps this_ = q;
    this_.step_mode = p_.step_mode;
    return this_;
}


prism_rtl::Turn<Ps> Sub::cycle() const {
    const auto& p_ = this->p_;
    const auto& toks = this->toks;
    const auto& end = this->end;
    auto end_1 = end;
    auto p__2 = p_;
    auto toks_3 = toks;
    return call_then(start_new_ps(crate::prelude::push(toks_3, crate::syntax::lexer::Tok{.kind = crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KEof{}), .span = end_1, .touches = false, .line_start = false})), [=](Ps new_ps_4612) {
        return ({
            auto q = new_ps_4612;
            (prism_rtl::finished(({
            Ps this_ = q;
            this_.step_mode = prism_rtl::deref(p__2).step_mode;
            (std::move(this_));
        })));
        });
    });
}


/// `Start Sub, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Ps> start_sub(Ps p_, Array<crate::syntax::lexer::Tok> toks, crate::syntax::Range end) {
    return prism_rtl::make_rc<Sub>(p_, toks, end);
}


/// Absorb: fn Ps, Ps -> Ps
Ps absorb(const Ps& p_, const Ps& sub_) {
    Ps this_ = p_;
    this_.diags = append(this_.diags, sub_.diags);
    this_.out = append(this_.out, sub_.out);
    return this_;
}


/// FinishDiags: fn [Diag] -> [Diag]
Array<crate::syntax::Diag> finish_diags(const Array<crate::syntax::Diag>& ds) {
    auto sorted = fold(ds, Array<crate::syntax::Diag>{}, insert_diag);
    return fold(sorted, Array<crate::syntax::Diag>{}, [&](const Array<crate::syntax::Diag>& acc, const crate::syntax::Diag& d) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::syntax::Diag>> _v;
            auto&& _m = crate::syntax::lexer::chars::last(acc);
            if (prism_rtl::is_some(_m)) {
                auto&& e = prism_rtl::some_of(_m);
                if ((prism_rtl::deref(e).span == prism_rtl::deref(d).span) && (prism_rtl::deref(e).message == prism_rtl::deref(d).message)) {
                    _v.set(acc);
                    goto _done;
                }
            }
            {
                _v.set(crate::prelude::push(acc, d));
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


/// StageRank: fn Text -> Nat
Nat stage_rank(const Text& text0) {
    {
        auto&& c0_0 = text0;
        if (c0_0 == Text::lit("lex")) {
            return Nat(0u);
        }
    }
    {
        auto&& c1_0 = text0;
        if (c1_0 == Text::lit("parse")) {
            return Nat(1u);
        }
    }
    {
        return Nat(2u);
    }
}


/// DiagBefore: fn Diag, Diag -> Bool
bool diag_before(const crate::syntax::Diag& a, const crate::syntax::Diag& b) {
    return (prism_rtl::deref(a.span).start < prism_rtl::deref(b.span).start) || ((prism_rtl::deref(a.span).start == prism_rtl::deref(b.span).start) && (stage_rank(a.stage) < stage_rank(b.stage)));
}


/// InsertDiag: fn [Diag], Diag -> [Diag]
Array<crate::syntax::Diag> insert_diag(const Array<crate::syntax::Diag>& sorted, const crate::syntax::Diag& d) {
    auto before_ = fold(sorted, Array<crate::syntax::Diag>{}, [&](const Array<crate::syntax::Diag>& acc, const crate::syntax::Diag& e) { return diag_before(d, e) ? acc : crate::prelude::push(acc, e); });
    auto after_ = fold(sorted, Array<crate::syntax::Diag>{}, [&](const Array<crate::syntax::Diag>& acc, const crate::syntax::Diag& e) { return diag_before(d, e) ? crate::prelude::push(acc, e) : acc; });
    return append(crate::prelude::push(before_, d), after_);
}


/// PairBrackets: unbounded fn [Tok] -> [Pair]
Array<Pair> pair_brackets(const Array<crate::syntax::lexer::Tok>& toks) {
    Array<Pair> this_ = each(toks, [&](const crate::syntax::lexer::Tok& t) { return no_pair(); });
    Array<std::tuple<Nat, Text>> stack = Array<std::tuple<Nat, Text>>{};
    for (auto&& [i6364, v6364] : prism_rtl::enumerate(toks)) {
        auto k6364 = nat_of(i6364);
        auto t = v6364;
        if (auto&& _m = open_kind_of(prism_rtl::deref(t).kind); prism_rtl::is_some(_m)) {
            auto&& k = prism_rtl::some_of(_m);
            stack = crate::prelude::push(stack, std::tuple{k6364, k});
        }
        if (auto&& _m = close_kind_of(prism_rtl::deref(t).kind); prism_rtl::is_some(_m)) {
            auto&& k = prism_rtl::some_of(_m);
            if (auto&& _m = crate::syntax::lexer::chars::last(stack); prism_rtl::is_some(_m)) {
                auto&& j = std::get<0>(prism_rtl::some_of(_m));
                auto&& k2 = std::get<1>(prism_rtl::some_of(_m));
                if (k2 == k) {
                    stack = crate::syntax::lexer::chars::pop(stack);
                    prism_rtl::deref(prism_rtl::deref(at_mut(this_, k6364))).partner = std::optional(j);
                    prism_rtl::deref(prism_rtl::deref(at_mut(this_, j))).partner = std::optional(k6364);
                }
            }
        }
    }
    for (auto&& [i6825, v6825] : prism_rtl::enumerate(toks)) {
        auto k6825 = nat_of(i6825);
        auto t = v6825;
        auto i = k6825;
        if (auto&& _m = open_kind_of(prism_rtl::deref(t).kind); prism_rtl::is_some(_m)) {
            auto&& kind_ = prism_rtl::some_of(_m);
            if ((kind_ != Text::lit("{")) && (!prism_rtl::deref(or_(index(this_, i), no_pair())).inner)) {
                if (auto&& _m = prism_rtl::deref(or_(index(this_, i), no_pair())).partner; prism_rtl::is_some(_m)) {
                    auto&& j = prism_rtl::some_of(_m);
                    if (double_at(this_, toks, i, j, kind_)) {
                        prism_rtl::deref(prism_rtl::deref(at_mut(this_, i))).outer = true;
                        prism_rtl::deref(prism_rtl::deref(at_mut(this_, j))).outer = true;
                        prism_rtl::deref(prism_rtl::deref(at_mut(this_, i + Nat(1u)))).inner = true;
                        prism_rtl::deref(prism_rtl::deref(at_mut(this_, crate::syntax::lexer::chars::dec(j)))).inner = true;
                    }
                }
            }
        }
    }
    return this_;
}


prism_rtl::Turn<Array<Pair>> PairBrackets::cycle() const {
    const auto& toks = this->toks;
    return prism_rtl::finished(({
        Array<Pair> this_ = each(toks, [&](const crate::syntax::lexer::Tok& t) { return no_pair(); });
        Array<std::tuple<Nat, Text>> stack = Array<std::tuple<Nat, Text>>{};
        for (auto&& [i6364, v6364] : prism_rtl::enumerate(toks)) {
            auto k6364 = nat_of(i6364);
            auto t = v6364;
            if (auto&& _m = open_kind_of(prism_rtl::deref(t).kind); prism_rtl::is_some(_m)) {
                auto&& k = prism_rtl::some_of(_m);
                stack = crate::prelude::push(stack, std::tuple{k6364, k});
            }
            if (auto&& _m = close_kind_of(prism_rtl::deref(t).kind); prism_rtl::is_some(_m)) {
                auto&& k = prism_rtl::some_of(_m);
                if (auto&& _m = crate::syntax::lexer::chars::last(stack); prism_rtl::is_some(_m)) {
                    auto&& j = std::get<0>(prism_rtl::some_of(_m));
                    auto&& k2 = std::get<1>(prism_rtl::some_of(_m));
                    if (k2 == k) {
                        stack = crate::syntax::lexer::chars::pop(stack);
                        prism_rtl::deref(prism_rtl::deref(at_mut(this_, k6364))).partner = std::optional(j);
                        prism_rtl::deref(prism_rtl::deref(at_mut(this_, j))).partner = std::optional(k6364);
                    }
                }
            }
        }
        for (auto&& [i6825, v6825] : prism_rtl::enumerate(toks)) {
            auto k6825 = nat_of(i6825);
            auto t = v6825;
            auto i = k6825;
            if (auto&& _m = open_kind_of(prism_rtl::deref(t).kind); prism_rtl::is_some(_m)) {
                auto&& kind_ = prism_rtl::some_of(_m);
                if ((kind_ != Text::lit("{")) && (!prism_rtl::deref(or_(index(this_, i), no_pair())).inner)) {
                    if (auto&& _m = prism_rtl::deref(or_(index(this_, i), no_pair())).partner; prism_rtl::is_some(_m)) {
                        auto&& j = prism_rtl::some_of(_m);
                        if (double_at(this_, toks, i, j, kind_)) {
                            prism_rtl::deref(prism_rtl::deref(at_mut(this_, i))).outer = true;
                            prism_rtl::deref(prism_rtl::deref(at_mut(this_, j))).outer = true;
                            prism_rtl::deref(prism_rtl::deref(at_mut(this_, i + Nat(1u)))).inner = true;
                            prism_rtl::deref(prism_rtl::deref(at_mut(this_, crate::syntax::lexer::chars::dec(j)))).inner = true;
                        }
                    }
                }
            }
        }
        (std::move(this_));
    }));
}


/// `Start PairBrackets, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Pair>> start_pair_brackets(Array<crate::syntax::lexer::Tok> toks) {
    return prism_rtl::make_rc<PairBrackets>(toks);
}


/// DoubleAt: fn [Pair], [Tok], Nat, Nat, Text -> Bool
bool double_at(const Array<Pair>& pairs, const Array<crate::syntax::lexer::Tok>& toks, const Nat& i, const Nat& j, const Text& kind_) {
    auto next_ = or_(index(toks, i + Nat(1u)), eof_tok());
    auto inner_close_opt = prism_rtl::deref(or_(index(pairs, i + Nat(1u)), no_pair())).partner;
    return ((is_open_of(prism_rtl::deref(next_).kind, kind_) && prism_rtl::deref(next_).touches) && (inner_close_opt == std::optional(crate::syntax::lexer::chars::dec(j)))) && prism_rtl::deref(or_(index(toks, j), eof_tok())).touches;
}


/// ?OpenKindOf: fn TokKind -> ?Text
std::optional<Text> open_kind_of(const crate::syntax::lexer::TokKind& tok_kind0) {
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KOpen>(tok_kind0)) {
        auto&& k = prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(tok_kind0).a0;
        return std::optional(k);
    }
    {
        return std::optional<Text>{};
    }
}


/// ?CloseKindOf: fn TokKind -> ?Text
std::optional<Text> close_kind_of(const crate::syntax::lexer::TokKind& tok_kind0) {
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KClose>(tok_kind0)) {
        auto&& k = prism_rtl::as<crate::syntax::lexer::TokKind::KClose>(tok_kind0).a0;
        return std::optional(k);
    }
    {
        return std::optional<Text>{};
    }
}


/// IsOpenOf: fn TokKind, Text -> Bool
bool is_open_of(const crate::syntax::lexer::TokKind& tok_kind0, const Text& text1) {
    auto&& _m = std::tuple{tok_kind0, text1};
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KOpen>(std::get<0>(_m))) {
        auto&& k = prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(std::get<0>(_m)).a0;
        auto&& kind_ = std::get<1>(_m);
        return k == kind_;
    }
    {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// Tk: fn Ps -> Tok
crate::syntax::lexer::Tok tk(const Ps& p_) {
    return p_.bad
        ? eof_tok()
        : or_(index(p_.toks, crate::prelude::min(p_.pos, crate::syntax::lexer::chars::dec(len(p_.toks)))), eof_tok());
}


/// TkAt: fn Ps, Nat -> Tok
crate::syntax::lexer::Tok tk_at(const Ps& p_, const Nat& n) {
    return p_.bad
        ? eof_tok()
        : or_(index(p_.toks, crate::prelude::min(p_.pos + n, crate::syntax::lexer::chars::dec(len(p_.toks)))), eof_tok());
}


/// Kind: fn Ps -> TokKind
crate::syntax::lexer::TokKind kind(const Ps& p_) {
    return prism_rtl::deref(tk(p_)).kind;
}


/// KindAt: fn Ps, Nat -> TokKind
crate::syntax::lexer::TokKind kind_at(const Ps& p_, const Nat& n) {
    return prism_rtl::deref(tk_at(p_, n)).kind;
}


/// Here: fn Ps -> Range
crate::syntax::Range here(const Ps& p_) {
    return prism_rtl::deref(tk(p_)).span;
}


/// Prev: fn Ps -> Range
crate::syntax::Range prev(const Ps& p_) {
    return prism_rtl::deref(or_(index(p_.toks, crate::syntax::lexer::chars::dec(p_.pos)), eof_tok())).span;
}


/// To: fn Range, Range -> Range
crate::syntax::Range to(const crate::syntax::Range& a, const crate::syntax::Range& b) {
    return crate::syntax::Range{.start = crate::prelude::min(a.start, b.start), .end = crate::prelude::max(a.end, b.end)};
}


/// AtEnd: fn Range -> Range
crate::syntax::Range at_end(const crate::syntax::Range& r) {
    return crate::syntax::Range{.start = r.end, .end = r.end};
}


/// Adv: fn Ps -> Ps
Ps adv(const Ps& p_) {
    return p_.bad || ((p_.pos + Nat(1u)) >= len(p_.toks))
        ? p_
        : ({
        Ps this_ = p_;
        this_.pos = this_.pos + Nat(1u);
        (std::move(this_));
    });
}


/// PairAt: fn Ps -> Pair
Pair pair_at(const Ps& p_) {
    return or_(index(p_.pairs, crate::prelude::min(p_.pos, crate::syntax::lexer::chars::dec(len(p_.pairs)))), no_pair());
}


/// AtEof: fn Ps -> Bool
bool at_eof(const Ps& p_) {
    return kind(p_) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KEof{});
}


/// AtKw: fn Ps, Text -> Bool
bool at_kw(const Ps& p_, const Text& w) {
    return kind(p_) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KKw{w, Text::lit("")});
}


/// AtOp: fn Ps, Text -> Bool
bool at_op(const Ps& p_, const Text& op) {
    auto&& _m = kind(p_);
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KOp>(_m)) {
        auto&& o = prism_rtl::as<crate::syntax::lexer::TokKind::KOp>(_m).a0;
        return o == op;
    }
    {
        return false;
    }
}


/// AtSep: fn Ps -> Bool
bool at_sep(const Ps& p_) {
    return kind(p_) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KLaySep{});
}


/// AtOpenL: fn Ps -> Bool
bool at_open_l(const Ps& p_) {
    return kind(p_) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KLayOpen{});
}


/// AtCloseL: fn Ps -> Bool
bool at_close_l(const Ps& p_) {
    return kind(p_) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KLayClose{});
}


/// AtComma: fn Ps -> Bool
bool at_comma(const Ps& p_) {
    return kind(p_) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KComma{});
}


/// AtColon: fn Ps -> Bool
bool at_colon(const Ps& p_) {
    return kind(p_) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KColon{});
}


/// IsOpenKind: fn TokKind, Text -> Bool
bool is_open_kind(const crate::syntax::lexer::TokKind& tok_kind0, const Text& text1) {
    auto&& _m = std::tuple{tok_kind0, text1};
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KOpen>(std::get<0>(_m))) {
        auto&& k = prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(std::get<0>(_m)).a0;
        auto&& kind_ = std::get<1>(_m);
        return k == kind_;
    }
    {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// AtDoubleOpen: fn Ps, Text -> Bool
bool at_double_open(const Ps& p_, const Text& kind_) {
    return is_open_kind(kind(p_), kind_) && prism_rtl::deref(pair_at(p_)).outer;
}


/// AtSingleOpen: fn Ps, Text -> Bool
bool at_single_open(const Ps& p_, const Text& kind_) {
    return is_open_kind(kind(p_), kind_) && (!prism_rtl::deref(pair_at(p_)).outer);
}


/// AtClose: fn Ps, Text -> Bool
bool at_close(const Ps& p_, const Text& kind_) {
    return kind(p_) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KClose{kind_});
}


/// OpenDouble: fn Ps -> Ps
Ps open_double(const Ps& p_) {
    return adv(adv(p_));
}


/// CloseDouble: fn Ps, Text -> Ps
Ps close_double(const Ps& p_, const Text& kind_) {
    auto c = crate::syntax::lexer::close_char(kind_);
    auto p1 = adv(p_);
    return ((at_close(p_, kind_) && prism_rtl::deref(pair_at(p_)).inner) && at_close(p1, kind_)) && prism_rtl::deref(pair_at(p1)).outer
        ? adv(p1)
        : at_close(p_, kind_) && prism_rtl::deref(pair_at(p_)).inner
        ? error_here(p1, prism_rtl::cat("expected `", c, c, "` to close the double bracket"))
        : error_here(p_, prism_rtl::cat("expected `", c, c, "` to close the double bracket"));
}


/// ExpectClose: fn Ps, Text -> Ps
Ps expect_close(const Ps& p_, const Text& kind_) {
    return at_close(p_, kind_)
        ? adv(p_)
        : error_here(p_, prism_rtl::cat("expected `", crate::syntax::lexer::close_char(kind_), "`"));
}


/// ParseDiag: fn Range, Text -> Diag
crate::syntax::Diag parse_diag(const crate::syntax::Range& span, const Text& message) {
    return crate::syntax::Diag{.stage = Text::lit("parse"), .span = span, .message = message, .feature = std::optional<Text>{}};
}


/// ErrorAt: fn Ps, Range, Text -> Ps
Ps error_at(const Ps& p_, const crate::syntax::Range& span, const Text& message) {
    return p_.bad
        ? p_
        : ({
        Ps this_ = p_;
        this_.diags = crate::prelude::push(this_.diags, parse_diag(span, message));
        this_.bad = true;
        (std::move(this_));
    });
}


/// ErrorHere: fn Ps, Text -> Ps
Ps error_here(const Ps& p_, const Text& message) {
    return error_at(p_, here(p_), prism_rtl::cat(message, ", found ", describe(kind(p_))));
}


/// Fail: fn Ps -> Ps
Ps fail(const Ps& p_) {
    Ps this_ = p_;
    this_.bad = true;
    return this_;
}


/// Unbad: fn Ps -> Ps
Ps unbad(const Ps& p_) {
    Ps this_ = p_;
    this_.bad = false;
    return this_;
}


/// NoteError: fn Ps, Range, Text -> Ps
Ps note_error(const Ps& p_, const crate::syntax::Range& span, const Text& message) {
    return p_.bad
        ? p_
        : ({
        Ps this_ = p_;
        this_.diags = crate::prelude::push(this_.diags, parse_diag(span, message));
        (std::move(this_));
    });
}


/// Complain: fn Ps, Text -> Ps
Ps complain(const Ps& p_, const Text& message) {
    return unbad(error_here(p_, message));
}


/// OutOfScope: fn Ps, Range, Text, Text -> Ps
Ps out_of_scope(const Ps& p_, const crate::syntax::Range& span, const Text& feature, const Text& message) {
    return p_.bad
        ? p_
        : ({
        Ps this_ = p_;
        this_.out = crate::prelude::push(this_.out, crate::syntax::Diag{.stage = Text::lit("out"), .span = span, .message = message, .feature = std::optional(feature)});
        (std::move(this_));
    });
}


/// ExpectColon: fn Ps -> Ps
Ps expect_colon(const Ps& p_) {
    return at_colon(p_) ? adv(p_) : error_here(p_, Text::lit("expected `:`"));
}


/// ExpectOp: fn Ps, Text -> Ps
Ps expect_op(const Ps& p_, const Text& op) {
    return at_op(p_, op)
        ? adv(p_)
        : error_here(p_, prism_rtl::cat("expected `", op, "`"));
}


/// ExpectKw: fn Ps, Text -> Ps
Ps expect_kw(const Ps& p_, const Text& w) {
    return at_kw(p_, w)
        ? adv(p_)
        : error_here(p_, prism_rtl::cat("expected `", w, "`"));
}


/// Recover: unbounded fn Ps -> Ps
Ps recover(const Ps& p0) {
    Ps this_ = unbad(p0);
    Nat depth = Nat(0u);
    bool going = true;
    while (std::move(going)) {
        ({
            __label__ _done;
            prism_rtl::Slot<Unit> _v;
            auto&& _m = kind(this_);
            if (prism_rtl::is<crate::syntax::lexer::TokKind::KEof>(_m)) {
                _v.set(({
                    going = false;
                    Unit{};
                }));
                goto _done;
            }
            if (prism_rtl::is<crate::syntax::lexer::TokKind::KLayOpen>(_m)) {
                _v.set(({
                    depth = depth + Nat(1u);
                    this_ = adv(this_);
                    Unit{};
                }));
                goto _done;
            }
            if (prism_rtl::is<crate::syntax::lexer::TokKind::KLayClose>(_m)) {
                _v.set(({
                    if (depth == Nat(0u)) {
                        going = false;
                    } else  {
                        depth = crate::syntax::lexer::chars::dec(depth);
                        this_ = adv(this_);
                    }
                    Unit{};
                }));
                goto _done;
            }
            if (prism_rtl::is<crate::syntax::lexer::TokKind::KLaySep>(_m)) {
                if (depth == Nat(0u)) {
                    _v.set(({
                        going = false;
                        Unit{};
                    }));
                    goto _done;
                }
            }
            {
                _v.set(({
                    this_ = adv(this_);
                    Unit{};
                }));
                goto _done;
            }
        _done:
            _v.take();
        });
    }
    return this_;
}


prism_rtl::Turn<Ps> Recover::cycle() const {
    const auto& p0 = this->p0;
    Ps this_ = unbad(p0);
    Nat depth = Nat(0u);
    bool going = true;
    return call_then(loop_job(std::tuple{std::move(this_), std::move(depth), std::move(going)}, [=](std::tuple<Ps, Nat, bool> _p0) {
        auto this_ = std::get<0>(_p0);
        auto depth = std::get<1>(_p0);
        auto going = std::get<2>(_p0);
        return going
            ? ({
            ({
                __label__ _done;
                prism_rtl::Slot<Unit> _v;
                auto&& _m = kind(this_);
                if (prism_rtl::is<crate::syntax::lexer::TokKind::KEof>(_m)) {
                    _v.set(({
                        going = false;
                        Unit{};
                    }));
                    goto _done;
                }
                if (prism_rtl::is<crate::syntax::lexer::TokKind::KLayOpen>(_m)) {
                    _v.set(({
                        depth = depth + Nat(1u);
                        this_ = adv(this_);
                        Unit{};
                    }));
                    goto _done;
                }
                if (prism_rtl::is<crate::syntax::lexer::TokKind::KLayClose>(_m)) {
                    _v.set(({
                        if (depth == Nat(0u)) {
                            going = false;
                        } else  {
                            depth = crate::syntax::lexer::chars::dec(depth);
                            this_ = adv(this_);
                        }
                        Unit{};
                    }));
                    goto _done;
                }
                if (prism_rtl::is<crate::syntax::lexer::TokKind::KLaySep>(_m)) {
                    if (depth == Nat(0u)) {
                        _v.set(({
                            going = false;
                            Unit{};
                        }));
                        goto _done;
                    }
                }
                {
                    _v.set(({
                        this_ = adv(this_);
                        Unit{};
                    }));
                    goto _done;
                }
            _done:
                _v.take();
            });
            Expected<std::tuple<Ps, Nat, bool>, std::tuple<Ps, Nat, bool>>(std::tuple{this_, depth, going});
        })
            : Expected<std::tuple<Ps, Nat, bool>, std::tuple<Ps, Nat, bool>>(unexpected(std::tuple{this_, depth, going}));
    }), [=](std::tuple<Ps, Nat, bool> _p0) {
        auto this_ = std::get<0>(_p0);
        auto depth = std::get<1>(_p0);
        auto going = std::get<2>(_p0);
        return prism_rtl::finished(this_);
    });
}


/// `Start Recover, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Ps> start_recover(Ps p0) {
    return prism_rtl::make_rc<Recover>(p0);
}


/// Recovered: unbounded fn Ps -> Ps
Ps recovered(const Ps& p_) {
    return p_.bad ? recover(p_) : p_;
}


prism_rtl::Turn<Ps> Recovered::cycle() const {
    const auto& p_ = this->p_;
    return p_->bad
        ? prism_rtl::more(prism_rtl::rc(Recover(p_)))
        : prism_rtl::finished(p_);
}


/// `Start Recovered, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Ps> start_recovered(Ps p_) {
    return prism_rtl::make_rc<Recovered>(p_);
}


/// AtStmtBoundary: fn Ps -> Bool
bool at_stmt_boundary(const Ps& p_) {
    auto&& _m = kind(p_);
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KLaySep>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KLayClose>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KEof>(_m)) {
        return true;
    }
    {
        return false;
    }
}


/// ExpectStmtEnd: unbounded fn Ps, Text -> Ps
Ps expect_stmt_end(const Ps& p_, const Text& what) {
    return at_stmt_boundary(p_)
        ? p_
        : recover(note_error(p_, here(p_), prism_rtl::cat("expected the end of the ", what, ", found ", describe(kind(p_)))));
}


prism_rtl::Turn<Ps> ExpectStmtEnd::cycle() const {
    const auto& p_ = this->p_;
    const auto& what = this->what;
    return at_stmt_boundary(p_)
        ? prism_rtl::finished(p_)
        : prism_rtl::more(prism_rtl::rc(Recover(note_error(p_, here(p_), prism_rtl::cat("expected the end of the ", what, ", found ", describe(kind(p_)))))));
}


/// `Start ExpectStmtEnd, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Ps> start_expect_stmt_end(Ps p_, Text what) {
    return prism_rtl::make_rc<ExpectStmtEnd>(p_, what);
}


/// Describe: fn TokKind -> Text
Text describe(const crate::syntax::lexer::TokKind& tok_kind0) {
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KLayOpen>(tok_kind0)) {
        return Text::lit("an indented block");
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KLaySep>(tok_kind0)) {
        return Text::lit("the end of the line");
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KLayClose>(tok_kind0)) {
        return Text::lit("the end of the block");
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KEof>(tok_kind0)) {
        return Text::lit("the end of the input");
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KText>(tok_kind0)) {
        return Text::lit("a text literal");
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KRegex>(tok_kind0)) {
        return Text::lit("a regular expression");
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KTemplate>(tok_kind0)) {
        return Text::lit("a template");
    }
    {
        auto&& k = tok_kind0;
        return prism_rtl::cat("`", crate::syntax::lexer::corpus::token_text(k), "`");
    }
}


/// WithStepMode: fn Ps, Bool -> Ps
Ps with_step_mode(const Ps& p_, const bool& flag) {
    Ps this_ = p_;
    this_.step_mode = flag;
    return this_;
}


/// let noSName
crate::syntax::SName no_sname() {
    return crate::syntax::SName{.sigils = Text::lit(""), .path_ = Array<Text>{}, .span = no_range()};
}


/// let noIdent
crate::syntax::Ident no_ident() {
    return crate::syntax::Ident{.name = Text::lit(""), .span = no_range()};
}


/// IsUpperName: fn SName -> Bool
bool is_upper_name(const crate::syntax::SName& n) {
    return crate::syntax::lexer::chars::is_upper(crate::syntax::lexer::chars::head(or_(crate::syntax::lexer::chars::last(n.path_), Text::lit(""))));
}


/// IsCallee: fn SName -> Bool
bool is_callee(const crate::syntax::SName& n) {
    return is_upper_name(n) || crate::syntax::lexer::chars::is_reserved_ctor(or_(crate::syntax::lexer::chars::last(n.path_), Text::lit("")));
}


/// IsTopic: fn SName -> Bool
bool is_topic(const crate::syntax::SName& n) {
    return n.path_ == Array(std::vector{Text::lit("_")});
}


/// NameText: fn SName -> Text
Text name_text(const crate::syntax::SName& n) {
    return prism_rtl::cat(n.sigils, crate::syntax::lexer::chars::join(n.path_, Text::lit(".")));
}


/// ParseSName: fn Ps -> ((SName, Ps))
std::tuple<crate::syntax::SName, Ps> parse_sname(const Ps& p_) {
    auto&& _m = kind(p_);
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        return std::tuple{crate::syntax::SName{.sigils = prism_rtl::deref(n).sigils, .path_ = n->path_, .span = here(p_)}, adv(p_)};
    }
    {
        return std::tuple{no_sname(), error_here(p_, Text::lit("expected a name"))};
    }
}


/// ParseIdent: fn Ps -> ((Ident, Ps))
std::tuple<crate::syntax::Ident, Ps> parse_ident(const Ps& p_) {
    auto&& _m = kind(p_);
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        if (((prism_rtl::deref(n).sigils == Text::lit("")) && (len(n->path_) == Nat(1u))) && (prism_rtl::deref(n).case_ == crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseLower{}))) {
            return std::tuple{crate::syntax::Ident{.name = or_(index(n->path_, Nat(0u)), Text::lit("")), .span = here(p_)}, adv(p_)};
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m16443_1_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m16443_1_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        if (m16443_1_0 == Text::lit("key")) {
            if (m16443_1_1 == Text::lit("")) {
                return std::tuple{crate::syntax::Ident{.name = Text::lit("key"), .span = here(p_)}, adv(p_)};
            }
        }
    }
    {
        return std::tuple{no_ident(), error_here(p_, Text::lit("expected a lowercase name"))};
    }
}


/// ParseQualName: fn Ps -> ((QualName, Ps))
std::tuple<crate::syntax::QualName, Ps> parse_qual_name(const Ps& p_) {
    auto&& _m = kind(p_);
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        if ((prism_rtl::deref(n).sigils == Text::lit("")) && (prism_rtl::deref(n).case_ == crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseUpper{}))) {
            return std::tuple{crate::syntax::QualName{.path_ = n->path_, .span = here(p_)}, adv(p_)};
        }
    }
    {
        return std::tuple{crate::syntax::QualName{.path_ = Array<Text>{}, .span = no_range()}, error_here(p_, Text::lit("expected an uppercase name"))};
    }
}


/// ParseTraitRef: fn Ps -> ((TraitRef, Ps))
std::tuple<crate::syntax::TraitRef, Ps> parse_trait_ref(const Ps& p_) {
    auto&& _m = kind(p_);
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KTrait>(_m)) {
        auto&& path_ = prism_rtl::as<crate::syntax::lexer::TokKind::KTrait>(_m).a0;
        auto span = here(p_);
        auto q = path_ == Array(std::vector{Text::lit("Monad")})
            ? out_of_scope(p_, span, Text::lit("`T monad:` blocks and `^Monad`"), Text::lit("`^Monad` is out of this compiler"))
            : p_;
        return std::tuple{crate::syntax::TraitRef{.path_ = path_, .span = span}, adv(q)};
    }
    {
        return std::tuple{crate::syntax::TraitRef{.path_ = Array<Text>{}, .span = no_range()}, error_here(p_, Text::lit("expected a trait, `^Name`"))};
    }
}


/// CheckNameScope: fn Ps, SName -> Ps
Ps check_name_scope(const Ps& p_, const crate::syntax::SName& name) {
    auto text_ = name_text(name);
    auto feature = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        {
            auto&& m17606_0 = text_;
            if (m17606_0 == Text::lit("!Align")) {
                _v.set(Text::lit("`!Align`"));
                goto _done;
            }
        }
        {
            auto&& m17606_1 = text_;
            if (m17606_1 == Text::lit("@Collect")) {
                _v.set(Text::lit("POD hosting (`@Collect`, `@View`, `@Edit`, `@Translate`)"));
                goto _done;
            }
        }
        {
            auto&& m17606_2 = text_;
            if (m17606_2 == Text::lit("@View")) {
                _v.set(Text::lit("POD hosting (`@Collect`, `@View`, `@Edit`, `@Translate`)"));
                goto _done;
            }
        }
        {
            auto&& m17606_3 = text_;
            if (m17606_3 == Text::lit("@Edit")) {
                _v.set(Text::lit("POD hosting (`@Collect`, `@View`, `@Edit`, `@Translate`)"));
                goto _done;
            }
        }
        {
            auto&& m17606_4 = text_;
            if (m17606_4 == Text::lit("@Translate")) {
                _v.set(Text::lit("POD hosting (`@Collect`, `@View`, `@Edit`, `@Translate`)"));
                goto _done;
            }
        }
        {
            auto&& m17606_5 = text_;
            if (m17606_5 == Text::lit("Over")) {
                _v.set(Text::lit("named lenses `&Home` and `Over`"));
                goto _done;
            }
        }
        {
            _v.set(Text::lit(""));
            goto _done;
        }
    _done:
        _v.take();
    });
    return feature == Text::lit("")
        ? p_
        : out_of_scope(p_, name.span, feature, prism_rtl::cat("`", text_, "` is out of this compiler"));
}


/// CheckTypeNameScope: fn Ps, SName -> Ps
Ps check_type_name_scope(const Ps& p_, const crate::syntax::SName& name) {
    auto b = or_(crate::syntax::lexer::chars::last(name.path_), Text::lit(""));
    auto sized = fold(Array(std::vector{Text::lit("U16"), Text::lit("U32"), Text::lit("U64"), Text::lit("U128"), Text::lit("I8"), Text::lit("I16"), Text::lit("I32"), Text::lit("I64"), Text::lit("I128")}), false, [&](const bool& seen, const Text& s) { return prism_rtl::deref(seen) || (s == b); });
    return len(name.path_) != Nat(1u)
        ? p_
        : std::move(sized)
        ? out_of_scope(p_, name.span, Text::lit("sized ints other than `U8`"), prism_rtl::cat("`", b, "` is out of this compiler: the sized integer it has is `U8`"))
        : b == Text::lit("Instant")
        ? out_of_scope(p_, name.span, Text::lit("`Instant`"), Text::lit("`Instant` is out of this compiler"))
        : p_;
}

}  // namespace crate::syntax::parser


// The module `Syntax.Parser.Blocks`, from `target/bootstrap/cpp-src/prismc/syntax/parser/blocks.prism`.
namespace crate::syntax::parser::blocks {

/// ParseBlockAfterColon: unbounded fn Ps -> ((Block, Ps))
std::tuple<crate::syntax::Block, crate::syntax::parser::Ps> parse_block_after_colon(const crate::syntax::parser::Ps& p0) {
    auto p_ = crate::syntax::parser::expect_colon(p0);
    return crate::syntax::parser::at_open_l(p_)
        ? parse_indented_block(p_)
        : crate::syntax::parser::at_stmt_boundary(p_)
        ? std::tuple{crate::syntax::parser::decls::no_block(), crate::syntax::parser::error_here(p_, Text::lit("expected a statement after `:`"))}
        : ({
        auto start = crate::syntax::parser::here(p_);
        auto [first_, p1] = parse_stmt(p_);
        auto r = ({
            std::tuple<Array<crate::syntax::Stmt>, crate::syntax::parser::Ps> this_ = std::tuple{Array(std::vector{first_}), p1};
            Array<crate::syntax::Stmt> stmts = Array(std::vector{first_});
            crate::syntax::parser::Ps q = p1;
            while ((crate::syntax::parser::kind(q) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KSemi{})) && (!q.bad)) {
                auto [st, q2] = parse_stmt(crate::syntax::parser::adv(q));
                stmts = crate::prelude::push(stmts, st);
                q = q2;
            }
            this_ = std::tuple{stmts, q};
            (std::move(this_));
        });
        auto [stmts, q] = r;
        std::tuple{crate::syntax::Block{.stmts = stmts, .inline_ = true, .span = crate::syntax::parser::to(start, crate::syntax::parser::prev(q))}, q};
    });
}


prism_rtl::Turn<std::tuple<crate::syntax::Block, crate::syntax::parser::Ps>> ParseBlockAfterColon::cycle() const {
    const auto& p0 = this->p0;
    auto p_ = crate::syntax::parser::expect_colon(p0);
    return crate::syntax::parser::at_open_l(p_)
        ? prism_rtl::more(prism_rtl::rc(ParseIndentedBlock(p_)))
        : crate::syntax::parser::at_stmt_boundary(p_)
        ? prism_rtl::finished(std::tuple{crate::syntax::parser::decls::no_block(), crate::syntax::parser::error_here(p_, Text::lit("expected a statement after `:`"))})
        : ({
        auto start = crate::syntax::parser::here(p_);
        call_then(start_parse_stmt(p_), [=, start = std::move(start)](std::tuple<crate::syntax::Stmt, crate::syntax::parser::Ps> parse_stmt_1224) {
        return ({
            auto [first_, p1] = parse_stmt_1224;
            std::tuple<Array<crate::syntax::Stmt>, crate::syntax::parser::Ps> this_ = std::tuple{Array(std::vector{first_}), p1};
            Array<crate::syntax::Stmt> stmts = Array(std::vector{first_});
            crate::syntax::parser::Ps q = p1;
            auto start_1 = start;
            call_then(loop_job(std::tuple{std::move(this_), std::move(q), std::move(stmts)}, [=](std::tuple<std::tuple<Array<crate::syntax::Stmt>, crate::syntax::parser::Ps>, crate::syntax::parser::Ps, Array<crate::syntax::Stmt>> _p0) {
            auto this_ = std::get<0>(_p0);
            auto q = std::get<1>(_p0);
            auto stmts = std::get<2>(_p0);
            return (crate::syntax::parser::kind(q) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KSemi{})) && (!q->bad)
                ? ({
                auto [st, q2] = parse_stmt(crate::syntax::parser::adv(q));
                stmts = crate::prelude::push(stmts, st);
                q = q2;
                Expected<std::tuple<std::tuple<Array<crate::syntax::Stmt>, crate::syntax::parser::Ps>, crate::syntax::parser::Ps, Array<crate::syntax::Stmt>>, std::tuple<std::tuple<Array<crate::syntax::Stmt>, crate::syntax::parser::Ps>, crate::syntax::parser::Ps, Array<crate::syntax::Stmt>>>(std::tuple{this_, q, stmts});
            })
                : Expected<std::tuple<std::tuple<Array<crate::syntax::Stmt>, crate::syntax::parser::Ps>, crate::syntax::parser::Ps, Array<crate::syntax::Stmt>>, std::tuple<std::tuple<Array<crate::syntax::Stmt>, crate::syntax::parser::Ps>, crate::syntax::parser::Ps, Array<crate::syntax::Stmt>>>(unexpected(std::tuple{this_, q, stmts}));
        }), [=, start_1 = std::move(start_1)](std::tuple<std::tuple<Array<crate::syntax::Stmt>, crate::syntax::parser::Ps>, crate::syntax::parser::Ps, Array<crate::syntax::Stmt>> _p0) {
            auto this_ = std::get<0>(_p0);
            auto q = std::get<1>(_p0);
            auto stmts = std::get<2>(_p0);
            return ({
                this_ = std::tuple{stmts, q};
                auto r = this_;
                auto [stmts, q] = r;
                (prism_rtl::finished(std::tuple{crate::syntax::Block{.stmts = stmts, .inline_ = true, .span = crate::syntax::parser::to(start_1, crate::syntax::parser::prev(q))}, q}));
            });
        });
        });
    });
    });
}


/// `Start ParseBlockAfterColon, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Block, crate::syntax::parser::Ps>> start_parse_block_after_colon(crate::syntax::parser::Ps p0) {
    return prism_rtl::make_rc<ParseBlockAfterColon>(p0);
}


/// ParseIndentedBlock: unbounded fn Ps -> ((Block, Ps))
std::tuple<crate::syntax::Block, crate::syntax::parser::Ps> parse_indented_block(const crate::syntax::parser::Ps& p0) {
    auto start = crate::syntax::parser::here(p0);
    auto [stmts, q] = stmts_until(crate::syntax::parser::adv(p0), true);
    return std::tuple{crate::syntax::Block{.stmts = stmts, .inline_ = false, .span = crate::syntax::parser::to(start, crate::syntax::parser::prev(q))}, q};
}


prism_rtl::Turn<std::tuple<crate::syntax::Block, crate::syntax::parser::Ps>> ParseIndentedBlock::cycle() const {
    const auto& p0 = this->p0;
    auto start = crate::syntax::parser::here(p0);
    auto p0_1 = p0;
    return call_then(start_stmts_until(crate::syntax::parser::adv(p0_1), true), [=](std::tuple<Array<crate::syntax::Stmt>, crate::syntax::parser::Ps> stmts_until_1826) {
        return ({
            auto [stmts, q] = stmts_until_1826;
            (prism_rtl::finished(std::tuple{crate::syntax::Block{.stmts = stmts, .inline_ = false, .span = crate::syntax::parser::to(start, crate::syntax::parser::prev(q))}, q}));
        });
    });
}


/// `Start ParseIndentedBlock, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Block, crate::syntax::parser::Ps>> start_parse_indented_block(crate::syntax::parser::Ps p0) {
    return prism_rtl::make_rc<ParseIndentedBlock>(p0);
}


/// ParseBlockUntilEof: unbounded fn Ps, Range -> ((Block, Ps))
std::tuple<crate::syntax::Block, crate::syntax::parser::Ps> parse_block_until_eof(const crate::syntax::parser::Ps& p_, const crate::syntax::Range& span) {
    auto [stmts, q] = crate::syntax::parser::at_eof(p_)
        ? std::tuple{Array<crate::syntax::Stmt>{}, p_}
        : stmts_until(p_, false);
    return std::tuple{crate::syntax::Block{.stmts = stmts, .inline_ = false, .span = span}, q};
}


prism_rtl::Turn<std::tuple<crate::syntax::Block, crate::syntax::parser::Ps>> ParseBlockUntilEof::cycle() const {
    const auto& p_ = this->p_;
    const auto& span = this->span;
    auto [stmts, q] = crate::syntax::parser::at_eof(p_)
        ? std::tuple{Array<crate::syntax::Stmt>{}, p_}
        : stmts_until(p_, false);
    return prism_rtl::finished(std::tuple{crate::syntax::Block{.stmts = stmts, .inline_ = false, .span = span}, q});
}


/// `Start ParseBlockUntilEof, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Block, crate::syntax::parser::Ps>> start_parse_block_until_eof(crate::syntax::parser::Ps p_, crate::syntax::Range span) {
    return prism_rtl::make_rc<ParseBlockUntilEof>(p_, span);
}


/// StmtsUntil: unbounded fn Ps, Bool -> (([Stmt], Ps))
std::tuple<Array<crate::syntax::Stmt>, crate::syntax::parser::Ps> stmts_until(const crate::syntax::parser::Ps& p0, const bool& indented) {
    std::tuple<Array<crate::syntax::Stmt>, crate::syntax::parser::Ps> this_ = std::tuple{Array<crate::syntax::Stmt>{}, p0};
    Array<crate::syntax::Stmt> stmts = Array<crate::syntax::Stmt>{};
    crate::syntax::parser::Ps p_ = p0;
    bool going = true;
    while (std::move(going)) {
        auto [st, q] = parse_stmt(p_);
        if (!q->bad) {
            stmts = crate::prelude::push(stmts, st);
        }
        p_ = crate::syntax::parser::recovered(q);
        {
            auto&& _m = crate::syntax::parser::kind(p_);
            if (prism_rtl::is<crate::syntax::lexer::TokKind::KLaySep>(_m)) {
                p_ = crate::syntax::parser::adv(p_);
                if ((!indented) && crate::syntax::parser::at_eof(p_)) {
                    going = false;
                }
            } else if (prism_rtl::is<crate::syntax::lexer::TokKind::KLayClose>(_m)) {
                p_ = crate::syntax::parser::adv(p_);
                if (indented || crate::syntax::parser::at_eof(p_)) {
                    going = false;
                }
            } else if (prism_rtl::is<crate::syntax::lexer::TokKind::KEof>(_m)) {
                going = false;
            } else {
                p_ = crate::syntax::parser::recover(crate::syntax::parser::complain(p_, Text::lit("expected the end of the statement")));
            }
        }
    }
    this_ = std::tuple{stmts, p_};
    return this_;
}


prism_rtl::Turn<std::tuple<Array<crate::syntax::Stmt>, crate::syntax::parser::Ps>> StmtsUntil::cycle() const {
    const auto& p0 = this->p0;
    const auto& indented = this->indented;
    std::tuple<Array<crate::syntax::Stmt>, crate::syntax::parser::Ps> this_ = std::tuple{Array<crate::syntax::Stmt>{}, p0};
    Array<crate::syntax::Stmt> stmts = Array<crate::syntax::Stmt>{};
    crate::syntax::parser::Ps p_ = p0;
    bool going = true;
    return call_then(loop_job(std::tuple{std::move(this_), std::move(going), std::move(p_), std::move(stmts)}, ({
        auto indented_1 = prism_rtl::deref(indented);
        [=, indented_1 = std::move(indented_1)](std::tuple<std::tuple<Array<crate::syntax::Stmt>, crate::syntax::parser::Ps>, bool, crate::syntax::parser::Ps, Array<crate::syntax::Stmt>> _p0) {
        auto this_ = std::get<0>(_p0);
        auto going = std::get<1>(_p0);
        auto p_ = std::get<2>(_p0);
        auto stmts = std::get<3>(_p0);
        return going
            ? ({
            auto [st, q] = parse_stmt(p_);
            if (!q->bad) {
                stmts = crate::prelude::push(stmts, st);
            }
            p_ = crate::syntax::parser::recovered(q);
            {
                auto&& _m = crate::syntax::parser::kind(p_);
                if (prism_rtl::is<crate::syntax::lexer::TokKind::KLaySep>(_m)) {
                    p_ = crate::syntax::parser::adv(p_);
                    if ((!indented_1) && crate::syntax::parser::at_eof(p_)) {
                        going = false;
                    }
                } else if (prism_rtl::is<crate::syntax::lexer::TokKind::KLayClose>(_m)) {
                    p_ = crate::syntax::parser::adv(p_);
                    if (indented_1 || crate::syntax::parser::at_eof(p_)) {
                        going = false;
                    }
                } else if (prism_rtl::is<crate::syntax::lexer::TokKind::KEof>(_m)) {
                    going = false;
                } else {
                    p_ = crate::syntax::parser::recover(crate::syntax::parser::complain(p_, Text::lit("expected the end of the statement")));
                }
            }
            Expected<std::tuple<std::tuple<Array<crate::syntax::Stmt>, crate::syntax::parser::Ps>, bool, crate::syntax::parser::Ps, Array<crate::syntax::Stmt>>, std::tuple<std::tuple<Array<crate::syntax::Stmt>, crate::syntax::parser::Ps>, bool, crate::syntax::parser::Ps, Array<crate::syntax::Stmt>>>(std::tuple{this_, going, p_, stmts});
        })
            : Expected<std::tuple<std::tuple<Array<crate::syntax::Stmt>, crate::syntax::parser::Ps>, bool, crate::syntax::parser::Ps, Array<crate::syntax::Stmt>>, std::tuple<std::tuple<Array<crate::syntax::Stmt>, crate::syntax::parser::Ps>, bool, crate::syntax::parser::Ps, Array<crate::syntax::Stmt>>>(unexpected(std::tuple{this_, going, p_, stmts}));
    };
    })), [=](std::tuple<std::tuple<Array<crate::syntax::Stmt>, crate::syntax::parser::Ps>, bool, crate::syntax::parser::Ps, Array<crate::syntax::Stmt>> _p0) {
        auto this_ = std::get<0>(_p0);
        auto going = std::get<1>(_p0);
        auto p_ = std::get<2>(_p0);
        auto stmts = std::get<3>(_p0);
        return ({
            this_ = std::tuple{stmts, p_};
            (prism_rtl::finished(this_));
        });
    });
}


/// `Start StmtsUntil, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::syntax::Stmt>, crate::syntax::parser::Ps>> start_stmts_until(crate::syntax::parser::Ps p0, bool indented) {
    return prism_rtl::make_rc<StmtsUntil>(p0, indented);
}


/// ParseStmt: unbounded fn Ps -> ((Stmt, Ps))
std::tuple<crate::syntax::Stmt, crate::syntax::parser::Ps> parse_stmt(const crate::syntax::parser::Ps& p_) {
    auto start = crate::syntax::parser::here(p_);
    auto [kind, q] = stmt_kind_of(p_, start);
    return std::tuple{crate::syntax::Stmt{.kind = kind, .span = crate::syntax::parser::to(start, crate::syntax::parser::prev(q))}, q};
}


prism_rtl::Turn<std::tuple<crate::syntax::Stmt, crate::syntax::parser::Ps>> ParseStmt::cycle() const {
    const auto& p_ = this->p_;
    auto start = crate::syntax::parser::here(p_);
    auto p__1 = p_;
    return call_then(start_stmt_kind_of(p__1, start), [=](std::tuple<crate::syntax::StmtKind, crate::syntax::parser::Ps> stmt_kind_of_3254) {
        return ({
            auto [kind, q] = stmt_kind_of_3254;
            (prism_rtl::finished(std::tuple{crate::syntax::Stmt{.kind = kind, .span = crate::syntax::parser::to(start, crate::syntax::parser::prev(q))}, q}));
        });
    });
}


/// `Start ParseStmt, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Stmt, crate::syntax::parser::Ps>> start_parse_stmt(crate::syntax::parser::Ps p_) {
    return prism_rtl::make_rc<ParseStmt>(p_);
}


/// StmtKindOf: unbounded fn Ps, Range -> ((StmtKind, Ps))
std::tuple<crate::syntax::StmtKind, crate::syntax::parser::Ps> stmt_kind_of(const crate::syntax::parser::Ps& p_, const crate::syntax::Range& start) {
    auto&& _m = crate::syntax::parser::kind(p_);
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m3409_0_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m3409_0_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        if (m3409_0_0 == Text::lit("emit")) {
            if (m3409_0_1 == Text::lit("")) {
                auto [r, q] = crate::syntax::parser::types::parse_row(crate::syntax::parser::adv(p_));
                return std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SEmit{r}), q};
            }
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m3409_1_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m3409_1_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        if (m3409_1_0 == Text::lit("let")) {
            if (m3409_1_1 == Text::lit("")) {
                auto [pattern, p1] = crate::syntax::parser::types::parse_pattern(crate::syntax::parser::adv(p_), false);
                auto [ty_opt, p2] = crate::syntax::parser::decls::optional_annotation(p1);
                auto [value, p3] = crate::syntax::parser::expr::parse_rhs_expr(crate::syntax::parser::expect_op(p2, Text::lit("=")));
                return std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SLet{pattern, ty_opt, value}), p3};
            }
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m3409_2_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m3409_2_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        if (m3409_2_0 == Text::lit("fn")) {
            if (m3409_2_1 == Text::lit("")) {
                auto [f, q] = crate::syntax::parser::decls::parse_fn_clause(p_);
                return std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SFn{f}), q};
            }
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m3409_3_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m3409_3_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        if (m3409_3_0 == Text::lit("ignore")) {
            if (m3409_3_1 == Text::lit("")) {
                if (crate::syntax::parser::at_op(crate::syntax::parser::adv(p_), Text::lit("<-"))) {
                    auto [e, q] = crate::syntax::parser::expr::parse_rhs_expr(crate::syntax::parser::adv(crate::syntax::parser::adv(p_)));
                    return std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SIgnore{e}), q};
                }
            }
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& w = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m3409_4_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        if (m3409_4_1 == Text::lit("")) {
            if ((w == Text::lit("require")) || (w == Text::lit("forbid"))) {
                auto [c, p1] = crate::syntax::parser::expr::parse_rhs_expr(crate::syntax::parser::adv(p_));
                auto q = crate::syntax::parser::at_comma(p1)
                    ? crate::syntax::parser::error_at(p1, crate::syntax::parser::here(p1), prism_rtl::cat("`", w, "` takes its condition alone, with no error value after a comma (decisions.md D15): a failed guard under `~` raises `Prelude.Unmet` (D11), and a comma after a guard belongs to a call at the head of its condition, as in `require Clear g, from, corner`"))
                    : p1;
                return w == Text::lit("require")
                    ? std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SRequire{c}), q}
                    : std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SForbid{c}), q};
            }
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m3409_5_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m3409_5_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        if (m3409_5_0 == Text::lit("while")) {
            if (m3409_5_1 == Text::lit("")) {
                auto [cond, p1] = crate::syntax::parser::expr::parse_cond(crate::syntax::parser::adv(p_), true);
                auto [body, q] = parse_block_after_colon(p1);
                return std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SWhile{cond, body}), q};
            }
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m3409_6_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m3409_6_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        if (m3409_6_0 == Text::lit("return")) {
            if (m3409_6_1 == Text::lit("")) {
                auto p1 = crate::syntax::parser::out_of_scope(crate::syntax::parser::adv(p_), crate::syntax::parser::here(p_), Text::lit("`T monad:` blocks and `^Monad`"), Text::lit("`return` ends a monad block, which is out of this compiler"));
                auto [e, q] = crate::syntax::parser::expr::parse_rhs_expr(p1);
                return std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SReturn{e}), q};
            }
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m)) {
        if (crate::syntax::parser::kind_at(p_, Nat(1u)) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KColon{})) {
            return crate::syntax::parser::kind_at(p_, Nat(2u)) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KLayOpen{})
                ? ({
                auto [name, p1] = crate::syntax::parser::parse_sname(p_);
                auto [body, q] = parse_block_after_colon(p1);
                std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SWidget{crate::syntax::decls::WidgetDecl{.name = name, .body = body, .span = crate::syntax::parser::to(start, prism_rtl::deref(body).span)}}), q};
            })
                : ({
                auto [sig, q] = crate::syntax::parser::decls::parse_signature(p_);
                std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SSignature{sig}), q};
            });
        }
    }
    {
        return other_stmt(p_);
    }
}


prism_rtl::Turn<std::tuple<crate::syntax::StmtKind, crate::syntax::parser::Ps>> StmtKindOf::cycle() const {
    const auto& p_ = this->p_;
    const auto& start = this->start;
    return ({
        auto&& _m = crate::syntax::parser::kind(p_);
        prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& m3409_0_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m3409_0_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        (m3409_0_0 == Text::lit("emit")) && (m3409_0_1 == Text::lit(""));
    }) ? ({
        auto&& m3409_0_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m3409_0_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        ({
        auto p__1 = p_;
        call_then(crate::syntax::parser::types::start_parse_row(crate::syntax::parser::adv(p__1)), [=](std::tuple<crate::syntax::Row_, crate::syntax::parser::Ps> parse_row_3466) {
        return ({
            auto [r, q] = parse_row_3466;
            (prism_rtl::finished(std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SEmit{r}), q}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& m3409_1_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m3409_1_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        (m3409_1_0 == Text::lit("let")) && (m3409_1_1 == Text::lit(""));
    }) ? ({
        auto&& m3409_1_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m3409_1_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        ({
        auto p__1 = p_;
        call_then(crate::syntax::parser::types::start_parse_pattern(crate::syntax::parser::adv(p__1), false), [=](std::tuple<crate::syntax::Pattern_, crate::syntax::parser::Ps> parse_pattern_3555) {
        return ({
            auto [pattern, p1] = parse_pattern_3555;
            call_then(crate::syntax::parser::decls::start_optional_annotation(p1), [=](std::tuple<std::optional<crate::syntax::Type>, crate::syntax::parser::Ps> optional_annotation_3609) {
            return ({
                auto [ty_opt, p2] = optional_annotation_3609;
                call_then(crate::syntax::parser::expr::start_parse_rhs_expr(crate::syntax::parser::expect_op(p2, Text::lit("="))), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_rhs_expr_3659) {
                return ({
                    auto [value, p3] = parse_rhs_expr_3659;
                    (prism_rtl::finished(std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SLet{pattern, ty_opt, value}), p3}));
                });
            });
            });
        });
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& m3409_2_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m3409_2_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        (m3409_2_0 == Text::lit("fn")) && (m3409_2_1 == Text::lit(""));
    }) ? ({
        auto&& m3409_2_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m3409_2_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        ({
        auto p__1 = p_;
        call_then(crate::syntax::parser::decls::start_parse_fn_clause(p__1), [=](std::tuple<crate::syntax::decls::FnClause, crate::syntax::parser::Ps> parse_fn_clause_3775) {
        return ({
            auto [f, q] = parse_fn_clause_3775;
            (prism_rtl::finished(std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SFn{f}), q}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& m3409_3_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m3409_3_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        (m3409_3_0 == Text::lit("ignore")) && (m3409_3_1 == Text::lit("")) && crate::syntax::parser::at_op(crate::syntax::parser::adv(p_), Text::lit("<-"));
    }) ? ({
        auto&& m3409_3_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m3409_3_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        ({
        auto p__1 = p_;
        call_then(crate::syntax::parser::expr::start_parse_rhs_expr(crate::syntax::parser::adv(crate::syntax::parser::adv(p__1))), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_rhs_expr_3881) {
        return ({
            auto [e, q] = parse_rhs_expr_3881;
            (prism_rtl::finished(std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SIgnore{e}), q}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& w = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m3409_4_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        (m3409_4_1 == Text::lit("")) && ((w == Text::lit("require")) || (w == Text::lit("forbid")));
    }) ? ({
        auto&& w = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m3409_4_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        ({
        auto p__1 = p_;
        call_then(crate::syntax::parser::expr::start_parse_rhs_expr(crate::syntax::parser::adv(p__1)), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_rhs_expr_4174) {
        return ({
            auto [c, p1] = parse_rhs_expr_4174;
            auto q = crate::syntax::parser::at_comma(p1)
                ? crate::syntax::parser::error_at(p1, crate::syntax::parser::here(p1), prism_rtl::cat("`", w, "` takes its condition alone, with no error value after a comma (decisions.md D15): a failed guard under `~` raises `Prelude.Unmet` (D11), and a comma after a guard belongs to a call at the head of its condition, as in `require Clear g, from, corner`"))
                : p1;
            w == Text::lit("require")
            ? prism_rtl::finished(std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SRequire{c}), q})
            : prism_rtl::finished(std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SForbid{c}), q});
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& m3409_5_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m3409_5_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        (m3409_5_0 == Text::lit("while")) && (m3409_5_1 == Text::lit(""));
    }) ? ({
        auto&& m3409_5_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m3409_5_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        ({
        auto p__1 = p_;
        call_then(crate::syntax::parser::expr::start_parse_cond(crate::syntax::parser::adv(p__1), true), [=](std::tuple<crate::syntax::Cond, crate::syntax::parser::Ps> parse_cond_4630) {
        return ({
            auto [cond, p1] = parse_cond_4630;
            call_then(start_parse_block_after_colon(p1), [=](std::tuple<crate::syntax::Block, crate::syntax::parser::Ps> parse_block_after_colon_4680) {
            return ({
                auto [body, q] = parse_block_after_colon_4680;
                (prism_rtl::finished(std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SWhile{cond, body}), q}));
            });
        });
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& m3409_6_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m3409_6_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        (m3409_6_0 == Text::lit("return")) && (m3409_6_1 == Text::lit(""));
    }) ? ({
        auto&& m3409_6_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m3409_6_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        ({
        auto p1 = crate::syntax::parser::out_of_scope(crate::syntax::parser::adv(p_), crate::syntax::parser::here(p_), Text::lit("`T monad:` blocks and `^Monad`"), Text::lit("`return` ends a monad block, which is out of this compiler"));
        call_then(crate::syntax::parser::expr::start_parse_rhs_expr(p1), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_rhs_expr_4926) {
        return ({
            auto [e, q] = parse_rhs_expr_4926;
            (prism_rtl::finished(std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SReturn{e}), q}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m) && ({
        (crate::syntax::parser::kind_at(p_, Nat(1u)) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KColon{}));
    }) ? crate::syntax::parser::kind_at(p_, Nat(2u)) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KLayOpen{})
        ? ({
        auto [name, p1] = crate::syntax::parser::parse_sname(p_);
        auto start_1 = start;
        call_then(start_parse_block_after_colon(p1), [=, start_1 = std::move(start_1)](std::tuple<crate::syntax::Block, crate::syntax::parser::Ps> parse_block_after_colon_5173) {
        return ({
            auto [body, q] = parse_block_after_colon_5173;
            (prism_rtl::finished(std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SWidget{crate::syntax::decls::WidgetDecl{.name = name, .body = body, .span = crate::syntax::parser::to(start_1, prism_rtl::deref(body).span)}}), q}));
        });
    });
    })
        : ({
        auto p__1 = p_;
        call_then(crate::syntax::parser::decls::start_parse_signature(p__1), [=](std::tuple<crate::syntax::decls::Signature, crate::syntax::parser::Ps> parse_signature_5328) {
        return ({
            auto [sig, q] = parse_signature_5328;
            (prism_rtl::finished(std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SSignature{sig}), q}));
        });
    });
    })
        : prism_rtl::more(prism_rtl::rc(OtherStmt(p_)));
    });
}


/// `Start StmtKindOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::StmtKind, crate::syntax::parser::Ps>> start_stmt_kind_of(crate::syntax::parser::Ps p_, crate::syntax::Range start) {
    return prism_rtl::make_rc<StmtKindOf>(p_, start);
}


/// OtherStmt: unbounded fn Ps -> ((StmtKind, Ps))
std::tuple<crate::syntax::StmtKind, crate::syntax::parser::Ps> other_stmt(const crate::syntax::parser::Ps& p_) {
    auto [upd, u] = parse_update_stmt(p_);
    auto [pattern, b] = crate::syntax::parser::types::parse_pattern(p_, true);
    return !u->bad
        ? std::tuple{upd, u}
        : (!b->bad) && crate::syntax::parser::at_op(b, Text::lit("<-"))
        ? ({
        auto [value, p1] = crate::syntax::parser::expr::parse_rhs_expr(crate::syntax::parser::adv(b));
        auto [then_step_opt, p2] = crate::syntax::parser::at_kw(p1, Text::lit("then"))
            ? optional_rhs(crate::syntax::parser::adv(p1))
            : std::tuple{std::optional<crate::syntax::Expr>{}, p1};
        crate::syntax::parser::at_kw(p2, Text::lit("then"))
        ? std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SExpr{crate::syntax::parser::decls::no_expr()}), crate::syntax::parser::error_at(p2, crate::syntax::parser::here(p2), Text::lit("`then` does not associate: a hold has one start and one step"))}
        : std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SBind{pattern, value, then_step_opt}), p2};
    })
        : ({
        auto [e, p1] = crate::syntax::parser::expr::parse_rhs_expr(p_);
        crate::syntax::parser::at_op(p1, Text::lit("<-"))
        ? std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SExpr{e}), crate::syntax::parser::error_at(p1, crate::syntax::parser::here(p1), Text::lit("the left side of `<-` is not a pattern"))}
        : crate::syntax::parser::at_kw(p1, Text::lit("then"))
        ? std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SExpr{e}), crate::syntax::parser::error_at(p1, crate::syntax::parser::here(p1), Text::lit("`then` belongs to a hold: `$x <- start then step`"))}
        : std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SExpr{e}), p1};
    });
}


prism_rtl::Turn<std::tuple<crate::syntax::StmtKind, crate::syntax::parser::Ps>> OtherStmt::cycle() const {
    const auto& p_ = this->p_;
    auto p__1 = p_;
    return call_then(start_parse_update_stmt(p__1), [=](std::tuple<crate::syntax::StmtKind, crate::syntax::parser::Ps> parse_update_stmt_5569) {
        return ({
            auto [upd, u] = parse_update_stmt_5569;
            call_then(crate::syntax::parser::types::start_parse_pattern(p__1, true), [=](std::tuple<crate::syntax::Pattern_, crate::syntax::parser::Ps> parse_pattern_5612) {
            return ({
                auto [pattern, b] = parse_pattern_5612;
                !u->bad
                ? prism_rtl::finished(std::tuple{upd, u})
                : (!b->bad) && crate::syntax::parser::at_op(b, Text::lit("<-"))
                ? call_then(crate::syntax::parser::expr::start_parse_rhs_expr(crate::syntax::parser::adv(b)), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_rhs_expr_5733) {
                return ({
                    auto [value, p1] = parse_rhs_expr_5733;
                    auto [then_step_opt, p2] = crate::syntax::parser::at_kw(p1, Text::lit("then"))
                        ? optional_rhs(crate::syntax::parser::adv(p1))
                        : std::tuple{std::optional<crate::syntax::Expr>{}, p1};
                    (crate::syntax::parser::at_kw(p2, Text::lit("then"))
                    ? prism_rtl::finished(std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SExpr{crate::syntax::parser::decls::no_expr()}), crate::syntax::parser::error_at(p2, crate::syntax::parser::here(p2), Text::lit("`then` does not associate: a hold has one start and one step"))})
                    : prism_rtl::finished(std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SBind{pattern, value, then_step_opt}), p2}));
                });
            })
                : call_then(crate::syntax::parser::expr::start_parse_rhs_expr(p__1), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_rhs_expr_6069) {
                return ({
                    auto [e, p1] = parse_rhs_expr_6069;
                    (crate::syntax::parser::at_op(p1, Text::lit("<-"))
                    ? prism_rtl::finished(std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SExpr{e}), crate::syntax::parser::error_at(p1, crate::syntax::parser::here(p1), Text::lit("the left side of `<-` is not a pattern"))})
                    : crate::syntax::parser::at_kw(p1, Text::lit("then"))
                    ? prism_rtl::finished(std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SExpr{e}), crate::syntax::parser::error_at(p1, crate::syntax::parser::here(p1), Text::lit("`then` belongs to a hold: `$x <- start then step`"))})
                    : prism_rtl::finished(std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SExpr{e}), p1}));
                });
            });
            });
        });
        });
    });
}


/// `Start OtherStmt, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::StmtKind, crate::syntax::parser::Ps>> start_other_stmt(crate::syntax::parser::Ps p_) {
    return prism_rtl::make_rc<OtherStmt>(p_);
}


/// OptionalRhs: unbounded fn Ps -> ((?Expr, Ps))
std::tuple<std::optional<crate::syntax::Expr>, crate::syntax::parser::Ps> optional_rhs(const crate::syntax::parser::Ps& p_) {
    auto [e, q] = crate::syntax::parser::expr::parse_rhs_expr(p_);
    return std::tuple{std::optional(e), q};
}


prism_rtl::Turn<std::tuple<std::optional<crate::syntax::Expr>, crate::syntax::parser::Ps>> OptionalRhs::cycle() const {
    const auto& p_ = this->p_;
    auto p__1 = p_;
    return call_then(crate::syntax::parser::expr::start_parse_rhs_expr(p__1), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_rhs_expr_6427) {
        return ({
            auto [e, q] = parse_rhs_expr_6427;
            (prism_rtl::finished(std::tuple{std::optional(e), q}));
        });
    });
}


/// `Start OptionalRhs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<std::optional<crate::syntax::Expr>, crate::syntax::parser::Ps>> start_optional_rhs(crate::syntax::parser::Ps p_) {
    return prism_rtl::make_rc<OptionalRhs>(p_);
}


/// ParseUpdateStmt: unbounded fn Ps -> ((StmtKind, Ps))
std::tuple<crate::syntax::StmtKind, crate::syntax::parser::Ps> parse_update_stmt(const crate::syntax::parser::Ps& p_) {
    auto [target, p1] = parse_reference(p_);
    auto op = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = crate::syntax::parser::kind(p1);
        if (prism_rtl::is<crate::syntax::lexer::TokKind::KOp>(_m)) {
            auto&& o = prism_rtl::as<crate::syntax::lexer::TokKind::KOp>(_m).a0;
            _v.set(o);
            goto _done;
        }
        {
            _v.set(Text::lit(""));
            goto _done;
        }
    _done:
        _v.take();
    });
    return p1->bad || (!(((((op == Text::lit("<=")) || (op == Text::lit("+="))) || (op == Text::lit("-="))) || (op == Text::lit("*="))) || (op == Text::lit("/="))))
        ? std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SExpr{crate::syntax::parser::decls::no_expr()}), crate::syntax::parser::fail(p1)}
        : ({
        auto [value, q] = crate::syntax::parser::expr::parse_rhs_expr(crate::syntax::parser::adv(p1));
        op == Text::lit("<=")
        ? std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SSet{target, value}), q}
        : std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SAccum{target, op, value}), q};
    });
}


prism_rtl::Turn<std::tuple<crate::syntax::StmtKind, crate::syntax::parser::Ps>> ParseUpdateStmt::cycle() const {
    const auto& p_ = this->p_;
    auto p__1 = p_;
    return call_then(start_parse_reference(p__1), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_reference_6741) {
        return ({
            auto [target, p1] = parse_reference_6741;
            auto op = ({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                auto&& _m = crate::syntax::parser::kind(p1);
                if (prism_rtl::is<crate::syntax::lexer::TokKind::KOp>(_m)) {
                    auto&& o = prism_rtl::as<crate::syntax::lexer::TokKind::KOp>(_m).a0;
                    _v.set(o);
                    goto _done;
                }
                {
                    _v.set(Text::lit(""));
                    goto _done;
                }
            _done:
                _v.take();
            });
            p1->bad || (!(((((op == Text::lit("<=")) || (op == Text::lit("+="))) || (op == Text::lit("-="))) || (op == Text::lit("*="))) || (op == Text::lit("/="))))
            ? prism_rtl::finished(std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SExpr{crate::syntax::parser::decls::no_expr()}), crate::syntax::parser::fail(p1)})
            : call_then(crate::syntax::parser::expr::start_parse_rhs_expr(crate::syntax::parser::adv(p1)), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_rhs_expr_6989) {
            return ({
                auto [value, q] = parse_rhs_expr_6989;
                op == Text::lit("<=")
                ? prism_rtl::finished(std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SSet{target, value}), q})
                : prism_rtl::finished(std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SAccum{target, op, value}), q});
            });
        });
        });
    });
}


/// `Start ParseUpdateStmt, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::StmtKind, crate::syntax::parser::Ps>> start_parse_update_stmt(crate::syntax::parser::Ps p_) {
    return prism_rtl::make_rc<ParseUpdateStmt>(p_);
}


/// ParseReference: unbounded fn Ps -> ((Expr, Ps))
std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_reference(const crate::syntax::parser::Ps& p_) {
    auto&& _m = crate::syntax::parser::kind(p_);
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        if (crate::syntax::lexer::chars::has_prefix(prism_rtl::deref(n).sigils, Text::lit("&"))) {
            auto start = crate::syntax::parser::here(p_);
            auto [name, p1] = crate::syntax::parser::parse_sname(p_);
            return crate::syntax::parser::is_upper_name(name)
                ? ({
                auto p2 = crate::syntax::parser::out_of_scope(p1, prism_rtl::deref(name).span, Text::lit("named lenses `&Home` and `Over`"), prism_rtl::cat("the named lens `", crate::syntax::parser::name_text(name), "` is out of this compiler; write its path, `&_.score.home`"));
                auto [inner, q] = parse_reference(p2);
                auto callee = crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EName{name})), .span = start};
                std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ECall{prism_rtl::rc(callee), Array(std::vector{crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = inner, .span = prism_rtl::deref(inner).span}}), false, false})), .span = crate::syntax::parser::to(start, prism_rtl::deref(inner).span)}, q};
            })
                : lens_steps(crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EName{name})), .span = prism_rtl::deref(name).span}, p1);
        }
    }
    {
        return std::tuple{crate::syntax::parser::decls::no_expr(), crate::syntax::parser::fail(p_)};
    }
}


prism_rtl::Turn<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> ParseReference::cycle() const {
    const auto& p_ = this->p_;
    return ({
        auto&& _m = crate::syntax::parser::kind(p_);
        prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m) && ({
        auto&& n = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        crate::syntax::lexer::chars::has_prefix(prism_rtl::deref(n).sigils, Text::lit("&"));
    }) ? ({
        auto&& n = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        ({
        auto start = crate::syntax::parser::here(p_);
        auto [name, p1] = crate::syntax::parser::parse_sname(p_);
        (crate::syntax::parser::is_upper_name(name)
        ? ({
        auto p2 = crate::syntax::parser::out_of_scope(p1, prism_rtl::deref(name).span, Text::lit("named lenses `&Home` and `Over`"), prism_rtl::cat("the named lens `", crate::syntax::parser::name_text(name), "` is out of this compiler; write its path, `&_.score.home`"));
        call_then(start_parse_reference(p2), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_reference_7673) {
        return ({
            auto [inner, q] = parse_reference_7673;
            auto callee = crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EName{name})), .span = start};
            (prism_rtl::finished(std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ECall{prism_rtl::rc(callee), Array(std::vector{crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = inner, .span = prism_rtl::deref(inner).span}}), false, false})), .span = crate::syntax::parser::to(start, prism_rtl::deref(inner).span)}, q}));
        });
    });
    })
        : prism_rtl::finished(lens_steps(crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EName{name})), .span = prism_rtl::deref(name).span}, p1)));
    });
    })
        : prism_rtl::finished(std::tuple{crate::syntax::parser::decls::no_expr(), crate::syntax::parser::fail(p_)});
    });
}


/// `Start ParseReference, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> start_parse_reference(crate::syntax::parser::Ps p_) {
    return prism_rtl::make_rc<ParseReference>(p_);
}


/// LensSteps: unbounded fn Expr, Ps -> ((Expr, Ps))
std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> lens_steps(const crate::syntax::Expr& e0, const crate::syntax::parser::Ps& p0) {
    std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> this_ = std::tuple{e0, p0};
    crate::syntax::Expr e = e0;
    crate::syntax::parser::Ps p_ = p0;
    bool going = true;
    while (std::move(going) && (!p_.bad)) {
        ({
            __label__ _done;
            prism_rtl::Slot<Unit> _v;
            auto&& _m = crate::syntax::parser::kind(p_);
            if (prism_rtl::is<crate::syntax::lexer::TokKind::KDot>(_m) && !prism_rtl::as<crate::syntax::lexer::TokKind::KDot>(_m).a0) {
                _v.set(({
                    auto p1 = crate::syntax::parser::adv(p_);
                    auto t = crate::syntax::parser::here(p1);
                    ({
                        __label__ _done;
                        prism_rtl::Slot<Unit> _v;
                        auto&& _m = crate::syntax::parser::kind(p1);
                        if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m)) {
                            auto&& f = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
                            if ((prism_rtl::deref(f).sigils == Text::lit("")) && (prism_rtl::deref(f).case_ == crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseLower{}))) {
                                _v.set(({
                                    e = crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EField{prism_rtl::rc(e), Text::lit(""), crate::syntax::Ident{.name = or_(index(f->path_, Nat(0u)), Text::lit("")), .span = t}})), .span = crate::syntax::parser::to(e.span, t)};
                                    p_ = crate::syntax::parser::adv(p1);
                                    Unit{};
                                }));
                                goto _done;
                            }
                        }
                        if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
                            auto&& u8306_1_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
                            if (u8306_1_0 == Text::lit("key")) {
                                _v.set(({
                                    e = crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EField{prism_rtl::rc(e), Text::lit(""), crate::syntax::Ident{.name = Text::lit("key"), .span = t}})), .span = crate::syntax::parser::to(e.span, t)};
                                    p_ = crate::syntax::parser::adv(p1);
                                    Unit{};
                                }));
                                goto _done;
                            }
                        }
                        {
                            _v.set(({
                                p_ = crate::syntax::parser::fail(p1);
                                Unit{};
                            }));
                            goto _done;
                        }
                    _done:
                        _v.take();
                    });
                    Unit{};
                }));
                goto _done;
            }
            if (prism_rtl::is<crate::syntax::lexer::TokKind::KOpen>(_m) && !prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(_m).a1) {
                auto&& u8187_1_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(_m).a0;
                if (u8187_1_0 == Text::lit("[")) {
                    if (prism_rtl::deref(crate::syntax::parser::tk(p_)).touches) {
                        _v.set(({
                            auto [index_, p1] = crate::syntax::parser::expr::parse_expr(crate::syntax::parser::adv(p_));
                            auto p2 = crate::syntax::parser::expect_close(p1, Text::lit("["));
                            e = crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EIndex{prism_rtl::rc(e), prism_rtl::rc(index_)})), .span = crate::syntax::parser::to(e.span, crate::syntax::parser::prev(p2))};
                            p_ = p2;
                            Unit{};
                        }));
                        goto _done;
                    }
                }
            }
            {
                _v.set(({
                    going = false;
                    Unit{};
                }));
                goto _done;
            }
        _done:
            _v.take();
        });
    }
    this_ = std::tuple{e, p_};
    return this_;
}

}  // namespace crate::syntax::parser::blocks
