// The module `Lower.Program`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <lower/program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>

// The module `Lower.Program`, from `target/bootstrap/cpp-src/prismc/lower/program.prism`.
namespace crate::lower::program {

/// InModule: fn Lx, Nat, Text -> Lx
crate::lower::Lx in_module_f(const crate::lower::Lx& lx_p0, const Nat& file_p1, const Text& home_p2) {
    crate::lower::Lx this_ = lx_p0;
    this_.file_p = file_p1;
    this_.home_p = home_p2;
    this_.site_p = home_p2;
    return this_;
}


/// InModuleAt: fn Lx, Nat, Text, Text -> Lx
crate::lower::Lx in_module_at_f(const crate::lower::Lx& lx_p0, const Nat& file_p1, const Text& home_p2, const Text& site_p3) {
    crate::lower::Lx this_ = lx_p0;
    this_.file_p = file_p1;
    this_.home_p = home_p2;
    this_.site_p = site_p3;
    return this_;
}


/// LowerProgram: unbounded fn [Src], [Module], Nat, TProgram, Text -> Model
crate::lower::model::Model lower_program_f(const Array<crate::check::errors::Src>& srcs_p0, const Array<crate::syntax::Module>& trees_p1, const Nat& shown_p2, const crate::check::typed::TProgram& tp_p3, const Text& name_p4) {
    auto&& _g_pt = crate::check::env::build_g_f(srcs_p0, trees_p1);
    auto&& g_pt = std::get<0>(_g_pt);
    auto [tys_pu, apps_pv, bs_p10, ims_p11] = crate::lower::typed_tables_f(tp_p3);
    auto gens_p5 = crate::prelude::fold(tp_p3.gens_p, Map<Text, crate::check::typed::GenNote>{}, [&](const Map<Text, crate::check::typed::GenNote>& m_p12, const crate::check::typed::GenNote& n_p13) { return crate::prelude::insert(m_p12, crate::check::typed::at_key_f(prism_rtl::deref(n_p13).at_p), n_p13); });
    auto insts_p6 = crate::prelude::fold(tp_p3.insts_p, Map<Text, Array<crate::check::typed::InstNote>>{}, [&](const Map<Text, Array<crate::check::typed::InstNote>>& m_p14, const crate::check::typed::InstNote& n_p15) { return crate::prelude::insert(m_p14, crate::lower::expr::inst_key_f(n_p15), crate::prelude::push(crate::prelude::or_(crate::prelude::get(m_p14, crate::lower::expr::inst_key_f(n_p15)), Array<crate::check::typed::InstNote>{}), n_p15)); });
    auto quants_p7 = crate::prelude::fold(tp_p3.gens_p, Map<Text, Text>{}, [&](const Map<Text, Text>& m_p16, const crate::check::typed::GenNote& n_p17) { return crate::prelude::fold(crate::prelude::append(prism_rtl::deref(n_p17).tys_p, prism_rtl::deref(n_p17).cols_p), m_p16, [&](const Map<Text, Text>& m2_p18, const Text& q_p19) { return crate::prelude::insert(m2_p18, q_p19, prism_rtl::deref(n_p17).name_p); }); });
    auto gen_of_q_p8 = crate::prelude::fold(tp_p3.gens_p, Map<Text, crate::check::typed::GenNote>{}, [&](const Map<Text, crate::check::typed::GenNote>& m_p1a, const crate::check::typed::GenNote& n_p1b) { return crate::prelude::fold(crate::prelude::append(prism_rtl::deref(n_p1b).tys_p, prism_rtl::deref(n_p1b).cols_p), m_p1a, [&](const Map<Text, crate::check::typed::GenNote>& m2_p1c, const Text& q_p1d) { return crate::prelude::insert(m2_p1c, q_p1d, n_p1b); }); });
    auto use_insts_p9 = crate::prelude::fold(tp_p3.insts_p, Map<Text, crate::check::typed::InstNote>{}, [&](const Map<Text, crate::check::typed::InstNote>& m_p1e, const crate::check::typed::InstNote& n_p1f) { return crate::prelude::insert(m_p1e, crate::check::typed::at_key_f(prism_rtl::deref(n_p1f).at_p), n_p1f); });
    auto mods_pa = needed_mods_f(g_pt, shown_p2);
    auto rs_mods_pb = crate::prelude::fold(mods_pa, Map<Text, Text>{}, [&](const Map<Text, Text>& acc_p1g, const Text& m_p1h) { return crate::prelude::insert(acc_p1g, m_p1h, crate::lower::rust_mod_name_f(m_p1h)); });
    auto mod_segments_pc = crate::prelude::fold(crate::prelude::values(rs_mods_pb), Map<Text, bool>{}, [&](const Map<Text, bool>& acc_p1i, const Text& p_p1j) { return crate::prelude::fold(crate::prelude::split_on(p_p1j, Text::lit("::")), acc_p1i, [&](const Map<Text, bool>& a2_p1k, const Text& seg_p1l) { return crate::prelude::insert(a2_p1k, seg_p1l, true); }); });
    auto lx0_pd = crate::lower::Lx{.g_p = g_pt, .tys_p = tys_pu, .apps_p = apps_pv, .lifts_p = crate::prelude::fold(tp_p3.lifts_p, Map<Text, crate::check::typed::LiftNote>{}, [&](const Map<Text, crate::check::typed::LiftNote>& m_p1m, const crate::check::typed::LiftNote& n_p1n) { return crate::prelude::insert(m_p1m, crate::check::typed::at_key_f(prism_rtl::deref(n_p1n).at_p), n_p1n); }), .binders_p = bs_p10, .impls_p = ims_p11, .file_p = Nat(0u), .home_p = Text::lit(""), .site_p = Text::lit(""), .rs_mods_p = rs_mods_pb, .mod_segments_p = mod_segments_pc, .rs_names_p = crate::lower::value_names_f(g_pt), .layouts_p = crate::lower::types::layouts_f(g_pt), .unbs_p = Array<Text>{}, .notes_p = Array<Text>{}, .globals_p = crate::lower::global_names_f(g_pt), .in_node_p = false, .unshrunk_p = crate::prelude::fold(tp_p3.unshrunk_p, Map<Text, bool>{}, [&](const Map<Text, bool>& m_p1o, const crate::check::typed::SrcAt& a_p1p) { return crate::prelude::insert(m_p1o, crate::check::typed::at_key_f(a_p1p), true); }), .gens_p = gens_p5, .insts_p = insts_p6, .quants_p = quants_p7, .gen_of_q_p = gen_of_q_p8, .use_insts_p = use_insts_p9, .local_ids_p = crate::prelude::fold(tp_p3.locals_p, Map<Text, Nat>{}, [&](const Map<Text, Nat>& m_p1q, const crate::check::typed::LocalNote& n_p1r) { return crate::prelude::insert(m_p1q, crate::check::typed::at_key_f(prism_rtl::deref(n_p1r).at_p), prism_rtl::deref(n_p1r).id_p); }), .use_ids_p = crate::prelude::fold(tp_p3.uses_p, Map<Text, Nat>{}, [&](const Map<Text, Nat>& m_p1s, const crate::check::typed::LocalNote& n_p1t) { return crate::prelude::insert(m_p1s, crate::check::typed::at_key_f(prism_rtl::deref(n_p1t).at_p), prism_rtl::deref(n_p1t).id_p); }), .call_ids_p = crate::prelude::fold(tp_p3.calls_p, Map<Text, Nat>{}, [&](const Map<Text, Nat>& m_p1u, const crate::check::typed::LocalNote& n_p1v) { return crate::prelude::insert(m_p1u, crate::check::typed::at_key_f(prism_rtl::deref(n_p1v).at_p), prism_rtl::deref(n_p1v).id_p); }), .inlined_p = Text::lit(""), .subst_p = Map<Text, crate::check::types::Ty>{}, .csubst_p = Map<Text, crate::check::types::Col>{}};
    auto lx_pe = ({
        crate::lower::Lx this_ = lx0_pd;
        this_.unbs_p = job_roots_f(lx0_pd);
        (std::move(this_));
    });
    auto roots_pf = root_widgets_f(lx_pe);
    auto mod_defs_pg = crate::prelude::run_to_end(crate::prelude::each_job(mods_pa, ({
        auto lx_pex = lx_pe;
        auto roots_pfx = roots_pf;
        auto g_ptx = g_pt;
        auto mods_pax = mods_pa;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::ModDef>(Text)>>(prism_rtl::rc([=, lx_pex = std::move(lx_pex), roots_pfx = std::move(roots_pfx), g_ptx = std::move(g_ptx), mods_pax = std::move(mods_pax)](Text p0) {
        return ({
            auto lx_pexy = lx_pex;
            auto roots_pfxy = roots_pfx;
            auto g_ptxy = g_ptx;
            auto mods_paxy = mods_pax;
            (crate::prelude::entered(crate::prelude::once_job([=, lx_pexy = std::move(lx_pexy), roots_pfxy = std::move(roots_pfxy), g_ptxy = std::move(g_ptxy), mods_paxy = std::move(mods_paxy)]() {
            return ({
                auto m_p20 = p0;
                (prism_rtl::more(prism_rtl::rc(ModDefOf(lx_pexy, m_p20, roots_pfxy, crate::prelude::or_(crate::prelude::get(prism_rtl::deref(g_ptxy).mods_p, m_p20), crate::check::env::reading::dummy_mod_p()), mods_paxy))));
            });
        })));
        });
    })));
    })));
    auto programs_ph = crate::prelude::run_to_end(crate::prelude::each_job(roots_pf, ({
        auto lx_pex = lx_pe;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::ProgDef>(std::tuple<Text, bool>)>>(prism_rtl::rc([=, lx_pex = std::move(lx_pex)](std::tuple<Text, bool> p0) {
        return ({
            auto lx_pexy = lx_pex;
            (crate::prelude::entered(crate::prelude::once_job([=, lx_pexy = std::move(lx_pexy)]() {
            return ({
                auto&& _qk_p21 = p0;
                auto&& qk_p21 = std::get<0>(_qk_p21);
                (prism_rtl::more(prism_rtl::rc(ProgDefOf(lx_pexy, qk_p21))));
            });
        })));
        });
    })));
    })));
    auto main_qk_pi = crate::prelude::fold(prism_rtl::deref(g_pt).defs_p, Text::lit(""), [&](const Text& found_p22, const crate::check::env::Def& d_p23) {
        return (found_p22 == Text::lit("")) && is_main_f(prism_rtl::deref(d_p23).qk_p)
            ? prism_rtl::deref(d_p23).qk_p
            : found_p22;
    });
    auto root_oj = main_qk_pi == Text::lit("")
        ? std::optional<crate::lower::model::ProgDef>{}
        : std::optional(prog_def_of_f(lx_pe, main_qk_pi));
    auto checks_pk = crate::prelude::run_to_end(crate::prelude::fold_job(prism_rtl::deref(g_pt).defs_p, Array<crate::lower::model::CheckDef>{}, ({
        auto lx_pex = lx_pe;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::CheckDef>>(std::tuple<Array<crate::lower::model::CheckDef>, crate::check::env::Def>)>>(prism_rtl::rc([=, lx_pex = std::move(lx_pex)](std::tuple<Array<crate::lower::model::CheckDef>, crate::check::env::Def> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_pexy = lx_pex;
            (crate::prelude::entered(crate::prelude::once_job([=, lx_pexy = std::move(lx_pexy)]() {
            return ({
                auto acc_p24 = p0;
                auto d_p25 = p1;
                ({
                auto&& _m = prism_rtl::deref(d_p25).body_p;
                prism_rtl::is<crate::check::env::DefBody::DbCheck>(_m) ? ({
                auto&& c_p26 = prism_rtl::as<crate::check::env::DefBody::DbCheck>(_m).a0;
                ({
                auto c_p26x = c_p26;
                (crate::prelude::call_then(start_check_def_of_f(in_module_at_f(lx_pexy, prism_rtl::deref(d_p25).file_p, prism_rtl::deref(d_p25).home_p, Text::lit("\000main"sv)), c_p26x), [=](crate::lower::model::CheckDef check_def_of_f_3830) { return prism_rtl::finished(crate::prelude::push(acc_p24, check_def_of_f_3830)); }));
            });
            })
                : prism_rtl::finished(acc_p24);
            });
            });
        })));
        });
    })));
    })));
    auto with_needs_pl = with_groups_f(with_needs_f(g_pt, srcs_p0, tp_p3, mod_defs_pg));
    auto elem_pm = elem_row_f(lx_pe, mods_pa);
    auto answer_pn = answer_enum_f(in_module_at_f(lx_pe, Nat(0u), Text::lit(""), Text::lit("\000main"sv)), mods_pa);
    auto names_po = crate::prelude::each(with_needs_pl, [&](const crate::lower::model::ModDef& d_p27) { return prism_rtl::deref(d_p27).name_p; });
    auto value_tys_pp = value_types_f(with_needs_pl);
    auto elem_held_pq = crate::prelude::fold(prism_rtl::deref(elem_pm).cases_p, Array<Text>{}, [&](const Array<Text>& acc_p28, const std::tuple<Text, Text>& _p1) {
        auto&& sp_p29 = std::get<1>(_p1);
        return crate::check::types::union_texts_f(acc_p28, held_in_f(names_po, value_tys_pp, Text::lit(""), crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{sp_p29, Array<crate::lower::model::OutTy>{}})));
    });
    auto answer_held_pr = crate::prelude::fold(prism_rtl::deref(answer_pn).cases_p, elem_held_pq, [&](const Array<Text>& acc_p2a, const crate::lower::model::AnswerCase& k_p2b) { return crate::check::types::union_texts_f(acc_p2a, held_in_f(names_po, value_tys_pp, Text::lit(""), prism_rtl::deref(k_p2b).ty_p)); });
    auto answer_named_ps = crate::prelude::fold(prism_rtl::deref(answer_pn).cases_p, Array<Text>{}, [&](const Array<Text>& acc_p2c, const crate::lower::model::AnswerCase& k_p2d) { return crate::check::types::union_texts_f(acc_p2c, named_in_f(names_po, Text::lit(""), prism_rtl::deref(k_p2d).ty_p)); });
    return crate::lower::model::Model{.name_p = name_p4, .mods_p = with_needs_pl, .programs_p = programs_ph, .root_o = root_oj, .checks_p = checks_pk, .elem_p = elem_pm, .answer_p = answer_pn, .elem_complete_p = answer_held_pr, .elem_declared_p = crate::check::types::minus_texts_f(answer_named_ps, answer_held_pr), .scripts_p = Array<Text>{}, .notes_p = Array<Text>{}};
}


prism_rtl::Turn<crate::lower::model::Model> LowerProgram::cycle() const {
    const auto& srcs_p0 = this->srcs_p0;
    const auto& trees_p1 = this->trees_p1;
    const auto& shown_p2 = this->shown_p2;
    const auto& tp_p3 = this->tp_p3;
    const auto& name_p4 = this->name_p4;
    auto name_p4x = name_p4;
    auto shown_p2x = shown_p2;
    auto srcs_p0x = srcs_p0;
    auto tp_p3x = tp_p3;
    auto trees_p1x = trees_p1;
    return crate::prelude::call_then(crate::check::env::start_build_g_f(srcs_p0x, trees_p1x), [=](std::tuple<crate::check::env::G, crate::check::types::St> build_g_f_1920) {
        return ({
            auto&& _g_pt = build_g_f_1920;
            auto&& g_pt = std::get<0>(_g_pt);
            auto [tys_pu, apps_pv, bs_p10, ims_p11] = crate::lower::typed_tables_f(tp_p3x);
            auto gens_p5 = crate::prelude::fold(prism_rtl::deref(tp_p3x).gens_p, Map<Text, crate::check::typed::GenNote>{}, [&](const Map<Text, crate::check::typed::GenNote>& m_p12, const crate::check::typed::GenNote& n_p13) { return crate::prelude::insert(m_p12, crate::check::typed::at_key_f(prism_rtl::deref(n_p13).at_p), n_p13); });
            auto insts_p6 = crate::prelude::fold(prism_rtl::deref(tp_p3x).insts_p, Map<Text, Array<crate::check::typed::InstNote>>{}, [&](const Map<Text, Array<crate::check::typed::InstNote>>& m_p14, const crate::check::typed::InstNote& n_p15) { return crate::prelude::insert(m_p14, crate::lower::expr::inst_key_f(n_p15), crate::prelude::push(crate::prelude::or_(crate::prelude::get(m_p14, crate::lower::expr::inst_key_f(n_p15)), Array<crate::check::typed::InstNote>{}), n_p15)); });
            auto quants_p7 = crate::prelude::fold(prism_rtl::deref(tp_p3x).gens_p, Map<Text, Text>{}, [&](const Map<Text, Text>& m_p16, const crate::check::typed::GenNote& n_p17) { return crate::prelude::fold(crate::prelude::append(prism_rtl::deref(n_p17).tys_p, prism_rtl::deref(n_p17).cols_p), m_p16, [&](const Map<Text, Text>& m2_p18, const Text& q_p19) { return crate::prelude::insert(m2_p18, q_p19, prism_rtl::deref(n_p17).name_p); }); });
            auto gen_of_q_p8 = crate::prelude::fold(prism_rtl::deref(tp_p3x).gens_p, Map<Text, crate::check::typed::GenNote>{}, [&](const Map<Text, crate::check::typed::GenNote>& m_p1a, const crate::check::typed::GenNote& n_p1b) { return crate::prelude::fold(crate::prelude::append(prism_rtl::deref(n_p1b).tys_p, prism_rtl::deref(n_p1b).cols_p), m_p1a, [&](const Map<Text, crate::check::typed::GenNote>& m2_p1c, const Text& q_p1d) { return crate::prelude::insert(m2_p1c, q_p1d, n_p1b); }); });
            auto use_insts_p9 = crate::prelude::fold(prism_rtl::deref(tp_p3x).insts_p, Map<Text, crate::check::typed::InstNote>{}, [&](const Map<Text, crate::check::typed::InstNote>& m_p1e, const crate::check::typed::InstNote& n_p1f) { return crate::prelude::insert(m_p1e, crate::check::typed::at_key_f(prism_rtl::deref(n_p1f).at_p), n_p1f); });
            (crate::prelude::call_then(start_needed_mods_f(g_pt, shown_p2x), [=, gens_p5 = std::move(gens_p5), insts_p6 = std::move(insts_p6), quants_p7 = std::move(quants_p7), gen_of_q_p8 = std::move(gen_of_q_p8), use_insts_p9 = std::move(use_insts_p9)](Array<Text> needed_mods_f_2446) {
            return ({
                auto mods_pa = needed_mods_f_2446;
                auto rs_mods_pb = crate::prelude::fold(mods_pa, Map<Text, Text>{}, [&](const Map<Text, Text>& acc_p1g, const Text& m_p1h) { return crate::prelude::insert(acc_p1g, m_p1h, crate::lower::rust_mod_name_f(m_p1h)); });
                auto mod_segments_pc = crate::prelude::fold(crate::prelude::values(rs_mods_pb), Map<Text, bool>{}, [&](const Map<Text, bool>& acc_p1i, const Text& p_p1j) { return crate::prelude::fold(crate::prelude::split_on(p_p1j, Text::lit("::")), acc_p1i, [&](const Map<Text, bool>& a2_p1k, const Text& seg_p1l) { return crate::prelude::insert(a2_p1k, seg_p1l, true); }); });
                (crate::prelude::call_then(crate::lower::start_value_names_f(g_pt), [=, mods_pa = std::move(mods_pa), rs_mods_pb = std::move(rs_mods_pb), mod_segments_pc = std::move(mod_segments_pc)](Map<Text, Text> value_names_f_2860) {
                return crate::prelude::call_then(crate::lower::types::start_layouts_f(g_pt), [=](Map<Text, Array<bool>> layouts_f_2884) {
                    return crate::prelude::call_then(crate::lower::start_global_names_f(g_pt), [=](Map<Text, bool> global_names_f_2928) {
                        return ({
                            auto lx0_pd = crate::lower::Lx{.g_p = g_pt, .tys_p = tys_pu, .apps_p = apps_pv, .lifts_p = crate::prelude::fold(prism_rtl::deref(tp_p3x).lifts_p, Map<Text, crate::check::typed::LiftNote>{}, [&](const Map<Text, crate::check::typed::LiftNote>& m_p1m, const crate::check::typed::LiftNote& n_p1n) { return crate::prelude::insert(m_p1m, crate::check::typed::at_key_f(prism_rtl::deref(n_p1n).at_p), n_p1n); }), .binders_p = bs_p10, .impls_p = ims_p11, .file_p = Nat(0u), .home_p = Text::lit(""), .site_p = Text::lit(""), .rs_mods_p = rs_mods_pb, .mod_segments_p = mod_segments_pc, .rs_names_p = value_names_f_2860, .layouts_p = layouts_f_2884, .unbs_p = Array<Text>{}, .notes_p = Array<Text>{}, .globals_p = global_names_f_2928, .in_node_p = false, .unshrunk_p = crate::prelude::fold(prism_rtl::deref(tp_p3x).unshrunk_p, Map<Text, bool>{}, [&](const Map<Text, bool>& m_p1o, const crate::check::typed::SrcAt& a_p1p) { return crate::prelude::insert(m_p1o, crate::check::typed::at_key_f(a_p1p), true); }), .gens_p = gens_p5, .insts_p = insts_p6, .quants_p = quants_p7, .gen_of_q_p = gen_of_q_p8, .use_insts_p = use_insts_p9, .local_ids_p = crate::prelude::fold(prism_rtl::deref(tp_p3x).locals_p, Map<Text, Nat>{}, [&](const Map<Text, Nat>& m_p1q, const crate::check::typed::LocalNote& n_p1r) { return crate::prelude::insert(m_p1q, crate::check::typed::at_key_f(prism_rtl::deref(n_p1r).at_p), prism_rtl::deref(n_p1r).id_p); }), .use_ids_p = crate::prelude::fold(prism_rtl::deref(tp_p3x).uses_p, Map<Text, Nat>{}, [&](const Map<Text, Nat>& m_p1s, const crate::check::typed::LocalNote& n_p1t) { return crate::prelude::insert(m_p1s, crate::check::typed::at_key_f(prism_rtl::deref(n_p1t).at_p), prism_rtl::deref(n_p1t).id_p); }), .call_ids_p = crate::prelude::fold(prism_rtl::deref(tp_p3x).calls_p, Map<Text, Nat>{}, [&](const Map<Text, Nat>& m_p1u, const crate::check::typed::LocalNote& n_p1v) { return crate::prelude::insert(m_p1u, crate::check::typed::at_key_f(prism_rtl::deref(n_p1v).at_p), prism_rtl::deref(n_p1v).id_p); }), .inlined_p = Text::lit(""), .subst_p = Map<Text, crate::check::types::Ty>{}, .csubst_p = Map<Text, crate::check::types::Col>{}};
                            auto lx_pe = ({
                                crate::lower::Lx this_ = lx0_pd;
                                this_.unbs_p = job_roots_f(lx0_pd);
                                (std::move(this_));
                            });
                            auto roots_pf = root_widgets_f(lx_pe);
                            (crate::prelude::call_value(crate::prelude::each_job(mods_pa, ({
                            auto lx_pex = lx_pe;
                            auto roots_pfx = roots_pf;
                            auto g_ptx = g_pt;
                            auto mods_pax = mods_pa;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::ModDef>(Text)>>(prism_rtl::rc([=, lx_pex = std::move(lx_pex), roots_pfx = std::move(roots_pfx), g_ptx = std::move(g_ptx), mods_pax = std::move(mods_pax)](Text p0) {
                            return ({
                                auto lx_pexy = lx_pex;
                                auto roots_pfxy = roots_pfx;
                                auto g_ptxy = g_ptx;
                                auto mods_paxy = mods_pax;
                                (crate::prelude::entered(crate::prelude::once_job([=, lx_pexy = std::move(lx_pexy), roots_pfxy = std::move(roots_pfxy), g_ptxy = std::move(g_ptxy), mods_paxy = std::move(mods_paxy)]() {
                                return ({
                                    auto m_p20 = p0;
                                    (prism_rtl::more(prism_rtl::rc(ModDefOf(lx_pexy, m_p20, roots_pfxy, crate::prelude::or_(crate::prelude::get(prism_rtl::deref(g_ptxy).mods_p, m_p20), crate::check::env::reading::dummy_mod_p()), mods_paxy))));
                                });
                            })));
                            });
                        })));
                        })), [=](Array<crate::lower::model::ModDef> each_3439) {
                            return ({
                                auto mod_defs_pg = each_3439;
                                (crate::prelude::call_value(crate::prelude::each_job(roots_pf, ({
                                auto lx_pex = lx_pe;
                                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::ProgDef>(std::tuple<Text, bool>)>>(prism_rtl::rc([=, lx_pex = std::move(lx_pex)](std::tuple<Text, bool> p0) {
                                return ({
                                    auto lx_pexy = lx_pex;
                                    (crate::prelude::entered(crate::prelude::once_job([=, lx_pexy = std::move(lx_pexy)]() {
                                    return ({
                                        auto&& _qk_p21 = p0;
                                        auto&& qk_p21 = std::get<0>(_qk_p21);
                                        (prism_rtl::more(prism_rtl::rc(ProgDefOf(lx_pexy, qk_p21))));
                                    });
                                })));
                                });
                            })));
                            })), [=, mod_defs_pg = std::move(mod_defs_pg)](Array<crate::lower::model::ProgDef> each_3528) {
                                return ({
                                    auto programs_ph = each_3528;
                                    auto main_qk_pi = crate::prelude::fold(prism_rtl::deref(g_pt).defs_p, Text::lit(""), [&](const Text& found_p22, const crate::check::env::Def& d_p23) {
                                        return (found_p22 == Text::lit("")) && is_main_f(prism_rtl::deref(d_p23).qk_p)
                                            ? prism_rtl::deref(d_p23).qk_p
                                            : found_p22;
                                    });
                                    auto root_oj = main_qk_pi == Text::lit("")
                                        ? std::optional<crate::lower::model::ProgDef>{}
                                        : std::optional(prog_def_of_f(lx_pe, main_qk_pi));
                                    (crate::prelude::call_value(crate::prelude::fold_job(prism_rtl::deref(g_pt).defs_p, Array<crate::lower::model::CheckDef>{}, ({
                                    auto lx_pex = lx_pe;
                                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::CheckDef>>(std::tuple<Array<crate::lower::model::CheckDef>, crate::check::env::Def>)>>(prism_rtl::rc([=, lx_pex = std::move(lx_pex)](std::tuple<Array<crate::lower::model::CheckDef>, crate::check::env::Def> _p0) {
                                    auto&& p0 = std::get<0>(_p0);
                                    auto&& p1 = std::get<1>(_p0);
                                    return ({
                                        auto lx_pexy = lx_pex;
                                        (crate::prelude::entered(crate::prelude::once_job([=, lx_pexy = std::move(lx_pexy)]() {
                                        return ({
                                            auto acc_p24 = p0;
                                            auto d_p25 = p1;
                                            ({
                                            auto&& _m = prism_rtl::deref(d_p25).body_p;
                                            prism_rtl::is<crate::check::env::DefBody::DbCheck>(_m) ? ({
                                            auto&& c_p26 = prism_rtl::as<crate::check::env::DefBody::DbCheck>(_m).a0;
                                            ({
                                            auto c_p26x = c_p26;
                                            (crate::prelude::call_then(start_check_def_of_f(in_module_at_f(lx_pexy, prism_rtl::deref(d_p25).file_p, prism_rtl::deref(d_p25).home_p, Text::lit("\000main"sv)), c_p26x), [=](crate::lower::model::CheckDef check_def_of_f_3830) { return prism_rtl::finished(crate::prelude::push(acc_p24, check_def_of_f_3830)); }));
                                        });
                                        })
                                            : prism_rtl::finished(acc_p24);
                                        });
                                        });
                                    })));
                                    });
                                })));
                                })), [=, programs_ph = std::move(programs_ph), root_oj = std::move(root_oj)](Array<crate::lower::model::CheckDef> fold_3757) {
                                    return ({
                                        auto checks_pk = fold_3757;
                                        (crate::prelude::call_then(start_with_needs_f(g_pt, srcs_p0x, tp_p3x, mod_defs_pg), [=, checks_pk = std::move(checks_pk)](Array<crate::lower::model::ModDef> with_needs_f_3945) {
                                        return crate::prelude::call_then(start_with_groups_f(with_needs_f_3945), [=](Array<crate::lower::model::ModDef> with_groups_f_3933) {
                                            return ({
                                                auto with_needs_pl = with_groups_f_3933;
                                                (crate::prelude::call_then(start_elem_row_f(lx_pe, mods_pa), [=, with_needs_pl = std::move(with_needs_pl)](crate::lower::model::RowDef elem_row_f_3992) {
                                                return ({
                                                    auto elem_pm = elem_row_f_3992;
                                                    (crate::prelude::call_then(start_answer_enum_f(in_module_at_f(lx_pe, Nat(0u), Text::lit(""), Text::lit("\000main"sv)), mods_pa), [=, elem_pm = std::move(elem_pm)](crate::lower::model::AnswerDef answer_enum_f_4026) {
                                                    return ({
                                                        auto answer_pn = answer_enum_f_4026;
                                                        auto names_po = crate::prelude::each(with_needs_pl, [&](const crate::lower::model::ModDef& d_p27) { return prism_rtl::deref(d_p27).name_p; });
                                                        auto value_tys_pp = value_types_f(with_needs_pl);
                                                        auto elem_held_pq = crate::prelude::fold(prism_rtl::deref(elem_pm).cases_p, Array<Text>{}, [&](const Array<Text>& acc_p28, const std::tuple<Text, Text>& _p1) {
                                                            auto&& sp_p29 = std::get<1>(_p1);
                                                            return crate::check::types::union_texts_f(acc_p28, held_in_f(names_po, value_tys_pp, Text::lit(""), crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{sp_p29, Array<crate::lower::model::OutTy>{}})));
                                                        });
                                                        auto answer_held_pr = crate::prelude::fold(prism_rtl::deref(answer_pn).cases_p, elem_held_pq, [&](const Array<Text>& acc_p2a, const crate::lower::model::AnswerCase& k_p2b) { return crate::check::types::union_texts_f(acc_p2a, held_in_f(names_po, value_tys_pp, Text::lit(""), prism_rtl::deref(k_p2b).ty_p)); });
                                                        auto answer_named_ps = crate::prelude::fold(prism_rtl::deref(answer_pn).cases_p, Array<Text>{}, [&](const Array<Text>& acc_p2c, const crate::lower::model::AnswerCase& k_p2d) { return crate::check::types::union_texts_f(acc_p2c, named_in_f(names_po, Text::lit(""), prism_rtl::deref(k_p2d).ty_p)); });
                                                        (prism_rtl::finished(crate::lower::model::Model{.name_p = name_p4x, .mods_p = with_needs_pl, .programs_p = programs_ph, .root_o = root_oj, .checks_p = checks_pk, .elem_p = elem_pm, .answer_p = answer_pn, .elem_complete_p = answer_held_pr, .elem_declared_p = crate::check::types::minus_texts_f(answer_named_ps, answer_held_pr), .scripts_p = Array<Text>{}, .notes_p = Array<Text>{}}));
                                                    });
                                                }));
                                                });
                                            }));
                                            });
                                        });
                                    }));
                                    });
                                }));
                                });
                            }));
                            });
                        }));
                        });
                    });
                });
            }));
            });
        }));
        });
    });
}


/// `Start LowerProgram, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Model> start_lower_program_f(Array<crate::check::errors::Src> srcs_p0, Array<crate::syntax::Module> trees_p1, Nat shown_p2, crate::check::typed::TProgram tp_p3, Text name_p4) {
    return prism_rtl::make_rc<LowerProgram>(srcs_p0, trees_p1, shown_p2, tp_p3, name_p4);
}


/// WithNeeds: unbounded fn G, [Src], TProgram, [ModDef] -> [ModDef]
Array<crate::lower::model::ModDef> with_needs_f(const crate::check::env::G& g_p0, const Array<crate::check::errors::Src>& srcs_p1, const crate::check::typed::TProgram& tp_p2, const Array<crate::lower::model::ModDef>& defs_p3) {
    auto names_p4 = crate::prelude::each(defs_p3, [&](const crate::lower::model::ModDef& d_p7) { return prism_rtl::deref(d_p7).name_p; });
    auto value_tys_p5 = value_types_f(defs_p3);
    auto refs_p6 = named_mods_f(g_p0, srcs_p1, tp_p2, crate::prelude::each(defs_p3, [&](const crate::lower::model::ModDef& d_p8) { return prism_rtl::deref(d_p8).prism_p; }));
    return crate::prelude::run_to_end(crate::prelude::each_job(defs_p3, ({
        auto names_p4x = names_p4;
        auto value_tys_p5x = value_tys_p5;
        auto refs_p6x = refs_p6;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::ModDef>(crate::lower::model::ModDef)>>(prism_rtl::rc([=, names_p4x = std::move(names_p4x), value_tys_p5x = std::move(value_tys_p5x), refs_p6x = std::move(refs_p6x)](crate::lower::model::ModDef p0) {
        return ({
            auto names_p4xy = names_p4x;
            auto value_tys_p5xy = value_tys_p5x;
            auto refs_p6xy = refs_p6x;
            (crate::prelude::entered(crate::prelude::once_job([=, names_p4xy = std::move(names_p4xy), value_tys_p5xy = std::move(value_tys_p5xy), refs_p6xy = std::move(refs_p6xy)]() {
            return ({
                auto d_p9 = p0;
                ({
                auto held_pa = crate::prelude::fold(prism_rtl::deref(d_p9).items_p, Array<Text>{}, [&](const Array<Text>& acc_pe, const crate::lower::model::Item& it_pf) { return crate::check::types::union_texts_f(acc_pe, item_held_f(names_p4xy, value_tys_p5xy, prism_rtl::deref(d_p9).name_p, it_pf)); });
                auto complete_pb = crate::prelude::filter(held_pa, [&](const Text& n_pg) { return n_pg != prism_rtl::deref(d_p9).name_p; });
                (crate::prelude::call_then(start_reached_by_f(refs_p6xy, Array(std::vector{prism_rtl::deref(d_p9).prism_p}), Array<Text>{}), [=, complete_pb = std::move(complete_pb)](Array<Text> reached_by_f_5240) {
                return ({
                    auto reached_pc = crate::prelude::each(reached_by_f_5240, [&](const Text& m_ph) { return crate::lower::rust_mod_name_f(m_ph); });
                    auto declared_pd = crate::prelude::filter(names_p4xy, [&](const Text& n_pi) { return ((n_pi != prism_rtl::deref(d_p9).name_p) && crate::check::types::has_text_f(reached_pc, n_pi)) && (!crate::check::types::has_text_f(complete_pb, n_pi)); });
                    (prism_rtl::finished(({
                    crate::lower::model::ModDef this_ = d_p9;
                    this_.complete_p = complete_pb;
                    this_.declared_p = declared_pd;
                    (std::move(this_));
                })));
                });
            }));
            });
            });
        })));
        });
    })));
    })));
}


prism_rtl::Turn<Array<crate::lower::model::ModDef>> WithNeeds::cycle() const {
    const auto& g_p0 = this->g_p0;
    const auto& srcs_p1 = this->srcs_p1;
    const auto& tp_p2 = this->tp_p2;
    const auto& defs_p3 = this->defs_p3;
    auto names_p4 = crate::prelude::each(defs_p3, [&](const crate::lower::model::ModDef& d_p7) { return prism_rtl::deref(d_p7).name_p; });
    auto value_tys_p5 = value_types_f(defs_p3);
    auto defs_p3x = defs_p3;
    auto g_p0x = g_p0;
    auto srcs_p1x = srcs_p1;
    auto tp_p2x = tp_p2;
    return crate::prelude::call_then(start_named_mods_f(g_p0x, srcs_p1x, tp_p2x, crate::prelude::each(defs_p3x, [&](const crate::lower::model::ModDef& d_p8) { return prism_rtl::deref(d_p8).prism_p; })), [=](Map<Text, Array<Text>> named_mods_f_4985) {
        return ({
            auto refs_p6 = named_mods_f_4985;
            (crate::prelude::each_job(defs_p3x, ({
            auto names_p4x = names_p4;
            auto value_tys_p5x = value_tys_p5;
            auto refs_p6x = refs_p6;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::ModDef>(crate::lower::model::ModDef)>>(prism_rtl::rc([=, names_p4x = std::move(names_p4x), value_tys_p5x = std::move(value_tys_p5x), refs_p6x = std::move(refs_p6x)](crate::lower::model::ModDef p0) {
            return ({
                auto names_p4xy = names_p4x;
                auto value_tys_p5xy = value_tys_p5x;
                auto refs_p6xy = refs_p6x;
                (crate::prelude::entered(crate::prelude::once_job([=, names_p4xy = std::move(names_p4xy), value_tys_p5xy = std::move(value_tys_p5xy), refs_p6xy = std::move(refs_p6xy)]() {
                return ({
                    auto d_p9 = p0;
                    ({
                    auto held_pa = crate::prelude::fold(prism_rtl::deref(d_p9).items_p, Array<Text>{}, [&](const Array<Text>& acc_pe, const crate::lower::model::Item& it_pf) { return crate::check::types::union_texts_f(acc_pe, item_held_f(names_p4xy, value_tys_p5xy, prism_rtl::deref(d_p9).name_p, it_pf)); });
                    auto complete_pb = crate::prelude::filter(held_pa, [&](const Text& n_pg) { return n_pg != prism_rtl::deref(d_p9).name_p; });
                    (crate::prelude::call_then(start_reached_by_f(refs_p6xy, Array(std::vector{prism_rtl::deref(d_p9).prism_p}), Array<Text>{}), [=, complete_pb = std::move(complete_pb)](Array<Text> reached_by_f_5240) {
                    return ({
                        auto reached_pc = crate::prelude::each(reached_by_f_5240, [&](const Text& m_ph) { return crate::lower::rust_mod_name_f(m_ph); });
                        auto declared_pd = crate::prelude::filter(names_p4xy, [&](const Text& n_pi) { return ((n_pi != prism_rtl::deref(d_p9).name_p) && crate::check::types::has_text_f(reached_pc, n_pi)) && (!crate::check::types::has_text_f(complete_pb, n_pi)); });
                        (prism_rtl::finished(({
                        crate::lower::model::ModDef this_ = d_p9;
                        this_.complete_p = complete_pb;
                        this_.declared_p = declared_pd;
                        (std::move(this_));
                    })));
                    });
                }));
                });
                });
            })));
            });
        })));
        }))->cycle());
        });
    });
}


/// `Start WithNeeds, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::lower::model::ModDef>> start_with_needs_f(crate::check::env::G g_p0, Array<crate::check::errors::Src> srcs_p1, crate::check::typed::TProgram tp_p2, Array<crate::lower::model::ModDef> defs_p3) {
    return prism_rtl::make_rc<WithNeeds>(g_p0, srcs_p1, tp_p2, defs_p3);
}


/// NamedMods: unbounded fn G, [Src], TProgram, [Text] -> (Text ==> [Text])
Map<Text, Array<Text>> named_mods_f(const crate::check::env::G& g_p0, const Array<crate::check::errors::Src>& srcs_p1, const crate::check::typed::TProgram& tp_p2, const Array<Text>& ms_p3) {
    auto by_path_p4 = crate::prelude::fold(crate::prelude::values(g_p0.mods_p), Map<Text, Text>{}, [&](const Map<Text, Text>& acc_p7, const crate::check::env::ModInfo& info_p8) { return crate::prelude::insert(acc_p7, prism_rtl::deref(crate::prelude::or_(crate::prelude::index(srcs_p1, prism_rtl::deref(info_p8).file_p), crate::check::errors::mk_src_f(Text::lit(""), Text::lit("")))).path_p, prism_rtl::deref(info_p8).name_p); });
    auto by_file_p5 = crate::prelude::fold(crate::prelude::values(g_p0.mods_p), Map<Nat, Text>{}, [&](const Map<Nat, Text>& acc_p9, const crate::check::env::ModInfo& info_pa) { return crate::prelude::insert(acc_p9, prism_rtl::deref(info_pa).file_p, prism_rtl::deref(info_pa).name_p); });
    auto solved_p6 = crate::prelude::fold(tp_p2.impls_p, Map<Text, Array<Text>>{}, [&](const Map<Text, Array<Text>>& acc_pb, const crate::check::typed::ImplNote& n_pc) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Map<Text, Array<Text>>> _v;
            auto&& _m = crate::prelude::get(by_file_p5, prism_rtl::deref(prism_rtl::deref(n_pc).at_p).file_p);
            if (prism_rtl::is_some(_m)) {
                auto&& site_pd = prism_rtl::some_of(_m);
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Map<Text, Array<Text>>> _v;
                    auto&& _m = crate::prelude::get(by_path_p4, impl_path_f(prism_rtl::deref(n_pc).how_p));
                    if (prism_rtl::is_some(_m)) {
                        auto&& home_pe = prism_rtl::some_of(_m);
                        _v.set((home_pe == site_pd) || crate::check::types::has_text_f(crate::prelude::or_(crate::prelude::get(acc_pb, site_pd), Array<Text>{}), home_pe)
                            ? acc_pb
                            : crate::prelude::insert(acc_pb, site_pd, crate::prelude::push(crate::prelude::or_(crate::prelude::get(acc_pb, site_pd), Array<Text>{}), home_pe)));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(acc_pb);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(acc_pb);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
    return crate::prelude::run_to_end(crate::prelude::fold_job(ms_p3, Map<Text, Array<Text>>{}, ({
        auto g_p0x = g_p0;
        auto tp_p2x = tp_p2;
        auto ms_p3x = ms_p3;
        auto solved_p6x = solved_p6;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Array<Text>>>(std::tuple<Map<Text, Array<Text>>, Text>)>>(prism_rtl::rc([=, g_p0x = std::move(g_p0x), tp_p2x = std::move(tp_p2x), ms_p3x = std::move(ms_p3x), solved_p6x = std::move(solved_p6x)](std::tuple<Map<Text, Array<Text>>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_p0xy = g_p0x;
            auto tp_p2xy = tp_p2x;
            auto ms_p3xy = ms_p3x;
            auto solved_p6xy = solved_p6x;
            (crate::prelude::entered(crate::prelude::once_job([=, g_p0xy = std::move(g_p0xy), tp_p2xy = std::move(tp_p2xy), ms_p3xy = std::move(ms_p3xy), solved_p6xy = std::move(solved_p6xy)]() {
            return ({
                auto acc_pf = p0;
                auto m_pg = p1;
                ({
                auto&& _m = crate::prelude::get(prism_rtl::deref(g_p0xy).mods_p, m_pg);
                prism_rtl::is_some(_m) ? ({
                auto&& info_ph = prism_rtl::some_of(_m);
                crate::prelude::call_then(start_types_named_in_f(tp_p2xy, prism_rtl::deref(info_ph).file_p), [=](Array<Text> types_named_in_f_6710) {
                return ({
                    auto named_pi = crate::prelude::append(crate::prelude::each(crate::prelude::filter(prism_rtl::deref(tp_p2xy).globals_p, [&](const crate::check::typed::GlobalNote& n_pk) { return prism_rtl::deref(prism_rtl::deref(n_pk).at_p).file_p == prism_rtl::deref(info_ph).file_p; }), [&](const crate::check::typed::GlobalNote& n_pl) { return prism_rtl::deref(n_pl).target_p; }), types_named_in_f_6710);
                    auto qualified_pj = crate::prelude::filter(ms_p3xy, [&](const Text& o_pm) { return ((o_pm != m_pg) && (o_pm != Text::lit(""))) && crate::prelude::fold(named_pi, false, [&](const bool& f_pn, const Text& k_po) { return prism_rtl::deref(f_pn) || (crate::lower::owner_of_f(k_po) == o_pm); }); });
                    (crate::prelude::call_then(start_mod_refs_f(g_p0xy, m_pg), [=, qualified_pj = std::move(qualified_pj)](Array<Text> mod_refs_f_6906) { return prism_rtl::finished(crate::prelude::insert(acc_pf, m_pg, crate::check::types::union_texts_f(crate::check::types::union_texts_f(mod_refs_f_6906, qualified_pj), crate::prelude::or_(crate::prelude::get(solved_p6xy, m_pg), Array<Text>{})))); }));
                });
            });
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(acc_pf)
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        })));
        });
    }));
    })));
}


prism_rtl::Turn<Map<Text, Array<Text>>> NamedMods::cycle() const {
    const auto& g_p0 = this->g_p0;
    const auto& srcs_p1 = this->srcs_p1;
    const auto& tp_p2 = this->tp_p2;
    const auto& ms_p3 = this->ms_p3;
    auto by_path_p4 = crate::prelude::fold(crate::prelude::values(prism_rtl::deref(g_p0).mods_p), Map<Text, Text>{}, [&](const Map<Text, Text>& acc_p7, const crate::check::env::ModInfo& info_p8) { return crate::prelude::insert(acc_p7, prism_rtl::deref(crate::prelude::or_(crate::prelude::index(srcs_p1, prism_rtl::deref(info_p8).file_p), crate::check::errors::mk_src_f(Text::lit(""), Text::lit("")))).path_p, prism_rtl::deref(info_p8).name_p); });
    auto by_file_p5 = crate::prelude::fold(crate::prelude::values(prism_rtl::deref(g_p0).mods_p), Map<Nat, Text>{}, [&](const Map<Nat, Text>& acc_p9, const crate::check::env::ModInfo& info_pa) { return crate::prelude::insert(acc_p9, prism_rtl::deref(info_pa).file_p, prism_rtl::deref(info_pa).name_p); });
    auto solved_p6 = crate::prelude::fold(prism_rtl::deref(tp_p2).impls_p, Map<Text, Array<Text>>{}, [&](const Map<Text, Array<Text>>& acc_pb, const crate::check::typed::ImplNote& n_pc) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Map<Text, Array<Text>>> _v;
            auto&& _m = crate::prelude::get(by_file_p5, prism_rtl::deref(prism_rtl::deref(n_pc).at_p).file_p);
            if (prism_rtl::is_some(_m)) {
                auto&& site_pd = prism_rtl::some_of(_m);
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Map<Text, Array<Text>>> _v;
                    auto&& _m = crate::prelude::get(by_path_p4, impl_path_f(prism_rtl::deref(n_pc).how_p));
                    if (prism_rtl::is_some(_m)) {
                        auto&& home_pe = prism_rtl::some_of(_m);
                        _v.set((home_pe == site_pd) || crate::check::types::has_text_f(crate::prelude::or_(crate::prelude::get(acc_pb, site_pd), Array<Text>{}), home_pe)
                            ? acc_pb
                            : crate::prelude::insert(acc_pb, site_pd, crate::prelude::push(crate::prelude::or_(crate::prelude::get(acc_pb, site_pd), Array<Text>{}), home_pe)));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(acc_pb);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(acc_pb);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
    return crate::prelude::fold_job(ms_p3, Map<Text, Array<Text>>{}, ({
        auto g_p0x = g_p0;
        auto tp_p2x = tp_p2;
        auto ms_p3x = ms_p3;
        auto solved_p6x = solved_p6;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Array<Text>>>(std::tuple<Map<Text, Array<Text>>, Text>)>>(prism_rtl::rc([=, g_p0x = std::move(g_p0x), tp_p2x = std::move(tp_p2x), ms_p3x = std::move(ms_p3x), solved_p6x = std::move(solved_p6x)](std::tuple<Map<Text, Array<Text>>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_p0xy = g_p0x;
            auto tp_p2xy = tp_p2x;
            auto ms_p3xy = ms_p3x;
            auto solved_p6xy = solved_p6x;
            (crate::prelude::entered(crate::prelude::once_job([=, g_p0xy = std::move(g_p0xy), tp_p2xy = std::move(tp_p2xy), ms_p3xy = std::move(ms_p3xy), solved_p6xy = std::move(solved_p6xy)]() {
            return ({
                auto acc_pf = p0;
                auto m_pg = p1;
                ({
                auto&& _m = crate::prelude::get(prism_rtl::deref(g_p0xy).mods_p, m_pg);
                prism_rtl::is_some(_m) ? ({
                auto&& info_ph = prism_rtl::some_of(_m);
                crate::prelude::call_then(start_types_named_in_f(tp_p2xy, prism_rtl::deref(info_ph).file_p), [=](Array<Text> types_named_in_f_6710) {
                return ({
                    auto named_pi = crate::prelude::append(crate::prelude::each(crate::prelude::filter(prism_rtl::deref(tp_p2xy).globals_p, [&](const crate::check::typed::GlobalNote& n_pk) { return prism_rtl::deref(prism_rtl::deref(n_pk).at_p).file_p == prism_rtl::deref(info_ph).file_p; }), [&](const crate::check::typed::GlobalNote& n_pl) { return prism_rtl::deref(n_pl).target_p; }), types_named_in_f_6710);
                    auto qualified_pj = crate::prelude::filter(ms_p3xy, [&](const Text& o_pm) { return ((o_pm != m_pg) && (o_pm != Text::lit(""))) && crate::prelude::fold(named_pi, false, [&](const bool& f_pn, const Text& k_po) { return prism_rtl::deref(f_pn) || (crate::lower::owner_of_f(k_po) == o_pm); }); });
                    (crate::prelude::call_then(start_mod_refs_f(g_p0xy, m_pg), [=, qualified_pj = std::move(qualified_pj)](Array<Text> mod_refs_f_6906) { return prism_rtl::finished(crate::prelude::insert(acc_pf, m_pg, crate::check::types::union_texts_f(crate::check::types::union_texts_f(mod_refs_f_6906, qualified_pj), crate::prelude::or_(crate::prelude::get(solved_p6xy, m_pg), Array<Text>{})))); }));
                });
            });
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(acc_pf)
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        })));
        });
    }));
    }))->cycle();
}


/// `Start NamedMods, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, Array<Text>>> start_named_mods_f(crate::check::env::G g_p0, Array<crate::check::errors::Src> srcs_p1, crate::check::typed::TProgram tp_p2, Array<Text> ms_p3) {
    return prism_rtl::make_rc<NamedMods>(g_p0, srcs_p1, tp_p2, ms_p3);
}


/// TypesNamedIn: unbounded fn TProgram, Nat -> [Text]
Array<Text> types_named_in_f(const crate::check::typed::TProgram& tp_p0, const Nat& file_p1) {
    auto from_exprs_p2 = crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::filter(tp_p0.exprs_p, [&](const crate::check::typed::TyNote& n_p4) { return prism_rtl::deref(prism_rtl::deref(n_p4).at_p).file_p == file_p1; }), Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::typed::TyNote>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::typed::TyNote> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto acc_p5 = p0;
                auto n_p6 = p1;
                (crate::prelude::call_then(start_ty_con_names_f(prism_rtl::deref(n_p6).ty_p), [=, acc_p5 = std::move(acc_p5)](Array<Text> ty_con_names_f_7321) { return prism_rtl::finished(crate::check::types::union_texts_f(acc_p5, ty_con_names_f_7321)); }));
            });
        }));
    }))));
    auto from_binders_p3 = crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::filter(tp_p0.binders_p, [&](const crate::check::typed::BinderNote& n_p7) { return prism_rtl::deref(prism_rtl::deref(n_p7).at_p).file_p == file_p1; }), from_exprs_p2, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::typed::BinderNote>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::typed::BinderNote> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto acc_p8 = p0;
                auto n_p9 = p1;
                (crate::prelude::call_then(start_ty_con_names_f(prism_rtl::deref(n_p9).ty_p), [=, acc_p8 = std::move(acc_p8)](Array<Text> ty_con_names_f_7448) { return prism_rtl::finished(crate::check::types::union_texts_f(acc_p8, ty_con_names_f_7448)); }));
            });
        }));
    }))));
    return crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::filter(tp_p0.defs_p, [&](const crate::check::typed::DefNote& n_pa) { return prism_rtl::deref(prism_rtl::deref(n_pa).at_p).file_p == file_p1; }), from_binders_p3, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::typed::DefNote>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::typed::DefNote> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto acc_pb = p0;
                auto n_pc = p1;
                (crate::prelude::call_then(start_ty_con_names_f(prism_rtl::deref(prism_rtl::deref(n_pc).scheme_p).ty_p), [=, acc_pb = std::move(acc_pb)](Array<Text> ty_con_names_f_7556) { return prism_rtl::finished(crate::check::types::union_texts_f(acc_pb, ty_con_names_f_7556)); }));
            });
        }));
    }))));
}


prism_rtl::Turn<Array<Text>> TypesNamedIn::cycle() const {
    const auto& tp_p0 = this->tp_p0;
    const auto& file_p1 = this->file_p1;
    auto file_p1x = file_p1;
    auto tp_p0x = tp_p0;
    return crate::prelude::call_value(crate::prelude::fold_job(crate::prelude::filter(prism_rtl::deref(tp_p0x).exprs_p, [&](const crate::check::typed::TyNote& n_p4) { return prism_rtl::deref(prism_rtl::deref(n_p4).at_p).file_p == file_p1x; }), Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::typed::TyNote>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::typed::TyNote> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto acc_p5 = p0;
                auto n_p6 = p1;
                (crate::prelude::call_then(start_ty_con_names_f(prism_rtl::deref(n_p6).ty_p), [=, acc_p5 = std::move(acc_p5)](Array<Text> ty_con_names_f_7321) { return prism_rtl::finished(crate::check::types::union_texts_f(acc_p5, ty_con_names_f_7321)); }));
            });
        }));
    }))), [=](Array<Text> fold_7240) {
        return ({
            auto from_exprs_p2 = fold_7240;
            (crate::prelude::call_value(crate::prelude::fold_job(crate::prelude::filter(prism_rtl::deref(tp_p0x).binders_p, [&](const crate::check::typed::BinderNote& n_p7) { return prism_rtl::deref(prism_rtl::deref(n_p7).at_p).file_p == file_p1x; }), from_exprs_p2, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::typed::BinderNote>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::typed::BinderNote> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto acc_p8 = p0;
                    auto n_p9 = p1;
                    (crate::prelude::call_then(start_ty_con_names_f(prism_rtl::deref(n_p9).ty_p), [=, acc_p8 = std::move(acc_p8)](Array<Text> ty_con_names_f_7448) { return prism_rtl::finished(crate::check::types::union_texts_f(acc_p8, ty_con_names_f_7448)); }));
                });
            }));
        }))), [=](Array<Text> fold_7360) {
            return ({
                auto from_binders_p3 = fold_7360;
                (crate::prelude::fold_job(crate::prelude::filter(prism_rtl::deref(tp_p0x).defs_p, [&](const crate::check::typed::DefNote& n_pa) { return prism_rtl::deref(prism_rtl::deref(n_pa).at_p).file_p == file_p1x; }), from_binders_p3, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::typed::DefNote>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::typed::DefNote> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return crate::prelude::entered(crate::prelude::once_job([=]() {
                    return ({
                        auto acc_pb = p0;
                        auto n_pc = p1;
                        (crate::prelude::call_then(start_ty_con_names_f(prism_rtl::deref(prism_rtl::deref(n_pc).scheme_p).ty_p), [=, acc_pb = std::move(acc_pb)](Array<Text> ty_con_names_f_7556) { return prism_rtl::finished(crate::check::types::union_texts_f(acc_pb, ty_con_names_f_7556)); }));
                    });
                }));
            })))->cycle());
            });
        }));
        });
    });
}


/// `Start TypesNamedIn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_types_named_in_f(crate::check::typed::TProgram tp_p0, Nat file_p1) {
    return prism_rtl::make_rc<TypesNamedIn>(tp_p0, file_p1);
}


/// TyConNames: unbounded fn Ty -> [Text]
Array<Text> ty_con_names_f(const crate::check::types::Ty& t_p0) {
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t_p0)) {
        auto&& n_p1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p0).a0;
        auto&& args_p2 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p0).a1;
        return crate::prelude::run_to_end(crate::prelude::fold_job(args_p2, Array(std::vector{n_p1}), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto acc_p3 = p0;
                    auto a_p4 = p1;
                    (crate::prelude::call_then(start_ty_con_names_f(a_p4), [=, acc_p3 = std::move(acc_p3)](Array<Text> ty_con_names_f_7710) { return prism_rtl::finished(crate::check::types::union_texts_f(acc_p3, ty_con_names_f_7710)); }));
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(t_p0)) {
        auto&& ps_p5 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p0).a1;
        auto&& r_p6 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p0).a2;
        return crate::prelude::run_to_end(crate::prelude::fold_job(ps_p5, ty_con_names_f(prism_rtl::deref(prism_rtl::deref(r_p6))), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto acc_p7 = p0;
                    auto a_p8 = p1;
                    (crate::prelude::call_then(start_ty_con_names_f(a_p8), [=, acc_p7 = std::move(acc_p7)](Array<Text> ty_con_names_f_7800) { return prism_rtl::finished(crate::check::types::union_texts_f(acc_p7, ty_con_names_f_7800)); }));
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t_p0)) {
        auto&& ts_p9 = prism_rtl::as<crate::check::types::Ty::TyTuple>(t_p0).a0;
        return crate::prelude::run_to_end(crate::prelude::fold_job(ts_p9, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto acc_pa = p0;
                    auto a_pb = p1;
                    (crate::prelude::call_then(start_ty_con_names_f(a_pb), [=, acc_pa = std::move(acc_pa)](Array<Text> ty_con_names_f_7872) { return prism_rtl::finished(crate::check::types::union_texts_f(acc_pa, ty_con_names_f_7872)); }));
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(t_p0)) {
        auto&& x_pc = prism_rtl::as<crate::check::types::Ty::TyArray>(t_p0).a0;
        return ty_con_names_f(prism_rtl::deref(prism_rtl::deref(x_pc)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(t_p0)) {
        auto&& k_pd = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p0).a0;
        auto&& v_pe = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p0).a1;
        return crate::check::types::union_texts_f(ty_con_names_f(prism_rtl::deref(prism_rtl::deref(k_pd))), ty_con_names_f(prism_rtl::deref(prism_rtl::deref(v_pe))));
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t_p0)) {
        auto&& x_pf = prism_rtl::as<crate::check::types::Ty::TySig>(t_p0).a1;
        return ty_con_names_f(prism_rtl::deref(prism_rtl::deref(x_pf)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(t_p0)) {
        auto&& x_pg = prism_rtl::as<crate::check::types::Ty::TyAt>(t_p0).a0;
        return ty_con_names_f(prism_rtl::deref(prism_rtl::deref(x_pg)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(t_p0)) {
        auto&& x_ph = prism_rtl::as<crate::check::types::Ty::TyElem>(t_p0).a1;
        return ty_con_names_f(prism_rtl::deref(prism_rtl::deref(x_ph)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAssoc>(t_p0)) {
        auto&& x_pi = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t_p0).a1;
        return ty_con_names_f(prism_rtl::deref(prism_rtl::deref(x_pi)));
    }
    {
        return Array<Text>{};
    }
}


prism_rtl::Turn<Array<Text>> TyConNames::cycle() const {
    const auto& t_p0 = this->t_p0;
    return ({
        prism_rtl::is<crate::check::types::Ty::TyCon>(t_p0) ? ({
        auto&& n_p1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p0).a0;
        auto&& args_p2 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p0).a1;
        crate::prelude::fold_job(args_p2, Array(std::vector{n_p1}), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto acc_p3 = p0;
                auto a_p4 = p1;
                (crate::prelude::call_then(start_ty_con_names_f(a_p4), [=, acc_p3 = std::move(acc_p3)](Array<Text> ty_con_names_f_7710) { return prism_rtl::finished(crate::check::types::union_texts_f(acc_p3, ty_con_names_f_7710)); }));
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::check::types::Ty::TyFn>(t_p0) ? ({
        auto&& ps_p5 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p0).a1;
        auto&& r_p6 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p0).a2;
        ({
        auto ps_p5x = ps_p5;
        auto r_p6x = prism_rtl::deref(prism_rtl::deref(r_p6));
        (crate::prelude::call_then(start_ty_con_names_f(r_p6x), [=, ps_p5x = std::move(ps_p5x)](Array<Text> ty_con_names_f_7758) {
        return crate::prelude::fold_job(ps_p5x, ty_con_names_f_7758, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto acc_p7 = p0;
                    auto a_p8 = p1;
                    (crate::prelude::call_then(start_ty_con_names_f(a_p8), [=, acc_p7 = std::move(acc_p7)](Array<Text> ty_con_names_f_7800) { return prism_rtl::finished(crate::check::types::union_texts_f(acc_p7, ty_con_names_f_7800)); }));
                });
            }));
        })))->cycle();
    }));
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyTuple>(t_p0) ? ({
        auto&& ts_p9 = prism_rtl::as<crate::check::types::Ty::TyTuple>(t_p0).a0;
        crate::prelude::fold_job(ts_p9, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto acc_pa = p0;
                auto a_pb = p1;
                (crate::prelude::call_then(start_ty_con_names_f(a_pb), [=, acc_pa = std::move(acc_pa)](Array<Text> ty_con_names_f_7872) { return prism_rtl::finished(crate::check::types::union_texts_f(acc_pa, ty_con_names_f_7872)); }));
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::check::types::Ty::TyArray>(t_p0) ? ({
        auto&& x_pc = prism_rtl::as<crate::check::types::Ty::TyArray>(t_p0).a0;
        prism_rtl::more(prism_rtl::rc(TyConNames(prism_rtl::deref(prism_rtl::deref(x_pc)))));
    })
        : prism_rtl::is<crate::check::types::Ty::TyMap>(t_p0) ? ({
        auto&& k_pd = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p0).a0;
        auto&& v_pe = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p0).a1;
        ({
        auto k_pdx = prism_rtl::deref(prism_rtl::deref(k_pd));
        auto v_pex = prism_rtl::deref(prism_rtl::deref(v_pe));
        (crate::prelude::call_then(start_ty_con_names_f(k_pdx), [=, v_pex = std::move(v_pex)](Array<Text> ty_con_names_f_7942) { return crate::prelude::call_then(start_ty_con_names_f(v_pex), [=](Array<Text> ty_con_names_f_7958) { return prism_rtl::finished(crate::check::types::union_texts_f(ty_con_names_f_7942, ty_con_names_f_7958)); }); }));
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TySig>(t_p0) ? ({
        auto&& x_pf = prism_rtl::as<crate::check::types::Ty::TySig>(t_p0).a1;
        prism_rtl::more(prism_rtl::rc(TyConNames(prism_rtl::deref(prism_rtl::deref(x_pf)))));
    })
        : prism_rtl::is<crate::check::types::Ty::TyAt>(t_p0) ? ({
        auto&& x_pg = prism_rtl::as<crate::check::types::Ty::TyAt>(t_p0).a0;
        prism_rtl::more(prism_rtl::rc(TyConNames(prism_rtl::deref(prism_rtl::deref(x_pg)))));
    })
        : prism_rtl::is<crate::check::types::Ty::TyElem>(t_p0) ? ({
        auto&& x_ph = prism_rtl::as<crate::check::types::Ty::TyElem>(t_p0).a1;
        prism_rtl::more(prism_rtl::rc(TyConNames(prism_rtl::deref(prism_rtl::deref(x_ph)))));
    })
        : prism_rtl::is<crate::check::types::Ty::TyAssoc>(t_p0) ? ({
        auto&& x_pi = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t_p0).a1;
        prism_rtl::more(prism_rtl::rc(TyConNames(prism_rtl::deref(prism_rtl::deref(x_pi)))));
    })
        : prism_rtl::finished(Array<Text>{});
    });
}


/// `Start TyConNames, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_ty_con_names_f(crate::check::types::Ty t_p0) {
    return prism_rtl::make_rc<TyConNames>(t_p0);
}


/// ImplPath: fn Text -> Text
Text impl_path_f(const Text& how_p0) {
    auto rest_p1 = crate::prelude::or_(crate::syntax::lexer::chars::after_prefix_o(how_p0, Text::lit("impl ")), crate::prelude::or_(crate::syntax::lexer::chars::after_prefix_o(how_p0, Text::lit("derived ")), Text::lit("")));
    auto parts_p2 = crate::prelude::split_on(rest_p1, Text::lit(":"));
    return crate::syntax::lexer::chars::join_f(crate::prelude::take(parts_p2, crate::syntax::lexer::chars::dec_f(crate::prelude::len(parts_p2))), Text::lit(":"));
}


/// ValueTypes: fn [ModDef] -> (Text ==> Bool)
Map<Text, bool> value_types_f(const Array<crate::lower::model::ModDef>& defs_p0) {
    return crate::prelude::fold(defs_p0, Map<Text, bool>{}, [&](const Map<Text, bool>& acc_p1, const crate::lower::model::ModDef& d_p2) {
        return crate::prelude::fold(prism_rtl::deref(d_p2).items_p, acc_p1, [&](const Map<Text, bool>& a_p3, const crate::lower::model::Item& it_p4) {
            return ({
                __label__ _done;
                prism_rtl::Slot<Map<Text, bool>> _v;
                if (prism_rtl::is<crate::lower::model::Item::ItType>(it_p4)) {
                    auto&& t_p5 = prism_rtl::as<crate::lower::model::Item::ItType>(it_p4).a0;
                    _v.set(crate::prelude::insert(a_p3, prism_rtl::cat(prism_rtl::deref(d_p2).name_p, "::", prism_rtl::deref(t_p5).name_p), true));
                    goto _done;
                }
                if (prism_rtl::is<crate::lower::model::Item::ItTag>(it_p4)) {
                    auto&& t_p6 = prism_rtl::as<crate::lower::model::Item::ItTag>(it_p4).a0;
                    _v.set(crate::prelude::insert(a_p3, prism_rtl::cat(prism_rtl::deref(d_p2).name_p, "::", prism_rtl::deref(t_p6).name_p), true));
                    goto _done;
                }
                {
                    _v.set(a_p3);
                    goto _done;
                }
            _done:
                _v.take();
            });
        });
    });
}


/// ItemHeld: fn [Text], (Text ==> Bool), Text, Item -> [Text]
Array<Text> item_held_f(const Array<Text>& names_p0, const Map<Text, bool>& value_tys_p1, const Text& home_p2, const crate::lower::model::Item& it_p3) {
    if (prism_rtl::is<crate::lower::model::Item::ItType>(it_p3)) {
        auto&& t_p4 = prism_rtl::as<crate::lower::model::Item::ItType>(it_p3).a0;
        return crate::prelude::fold(prism_rtl::deref(t_p4).cases_p, Array<Text>{}, [&](const Array<Text>& acc_p5, const crate::lower::model::CaseDef& c_p6) {
            return crate::prelude::fold(prism_rtl::deref(c_p6).fields_p, acc_p5, [&](const Array<Text>& a_p7, const std::tuple<Text, crate::lower::model::OutTy>& _p1) {
                auto&& ft_p8 = std::get<1>(_p1);
                return crate::check::types::union_texts_f(a_p7, held_in_f(names_p0, value_tys_p1, home_p2, ft_p8));
            });
        });
    }
    if (prism_rtl::is<crate::lower::model::Item::ItTag>(it_p3)) {
        auto&& t_p9 = prism_rtl::as<crate::lower::model::Item::ItTag>(it_p3).a0;
        return crate::prelude::fold(prism_rtl::deref(t_p9).fields_p, Array<Text>{}, [&](const Array<Text>& acc_pa, const std::tuple<Text, Text, crate::lower::model::OutTy>& _p1) {
            auto&& ft_pb = std::get<2>(_p1);
            return crate::check::types::union_texts_f(acc_pa, held_in_f(names_p0, value_tys_p1, home_p2, ft_pb));
        });
    }
    if (prism_rtl::is<crate::lower::model::Item::ItRow>(it_p3)) {
        auto&& r_pc = prism_rtl::as<crate::lower::model::Item::ItRow>(it_p3).a0;
        return crate::prelude::fold(prism_rtl::deref(r_pc).cases_p, Array<Text>{}, [&](const Array<Text>& acc_pd, const std::tuple<Text, Text>& _p1) {
            auto&& sp_pe = std::get<1>(_p1);
            return crate::check::types::union_texts_f(acc_pd, held_in_f(names_p0, value_tys_p1, home_p2, crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{sp_pe, Array<crate::lower::model::OutTy>{}})));
        });
    }
    {
        return Array<Text>{};
    }
}


/// HeldIn: fn [Text], (Text ==> Bool), Text, OutTy -> [Text]
Array<Text> held_in_f(const Array<Text>& names_p0, const Map<Text, bool>& value_tys_p1, const Text& home_p2, const crate::lower::model::OutTy& t_p3) {
    if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t_p3)) {
        auto&& n_p4 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p3).a0;
        auto&& args_p5 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p3).a1;
        auto p_p6 = path_from_f(names_p0, home_p2, n_p4);
        auto own_p7 = crate::check::env::has_key_f(value_tys_p1, p_p6)
            ? Array(std::vector{parent_of_f(p_p6)})
            : Array<Text>{};
        return crate::prelude::fold(args_p5, own_p7, [&](const Array<Text>& acc_p8, const crate::lower::model::OutTy& a_p9) { return crate::check::types::union_texts_f(acc_p8, held_in_f(names_p0, value_tys_p1, home_p2, a_p9)); });
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutOpt>(t_p3)) {
        auto&& i_pa = prism_rtl::as<crate::lower::model::OutTy::OutOpt>(t_p3).a0;
        return held_in_f(names_p0, value_tys_p1, home_p2, prism_rtl::deref(prism_rtl::deref(i_pa)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutRes>(t_p3)) {
        auto&& i_pb = prism_rtl::as<crate::lower::model::OutTy::OutRes>(t_p3).a0;
        return held_in_f(names_p0, value_tys_p1, home_p2, prism_rtl::deref(prism_rtl::deref(i_pb)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutCell>(t_p3)) {
        auto&& i_pc = prism_rtl::as<crate::lower::model::OutTy::OutCell>(t_p3).a0;
        return held_in_f(names_p0, value_tys_p1, home_p2, prism_rtl::deref(prism_rtl::deref(i_pc)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutTuple>(t_p3)) {
        auto&& ts_pd = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(t_p3).a0;
        return crate::prelude::fold(ts_pd, Array<Text>{}, [&](const Array<Text>& acc_pe, const crate::lower::model::OutTy& a_pf) { return crate::check::types::union_texts_f(acc_pe, held_in_f(names_p0, value_tys_p1, home_p2, a_pf)); });
    }
    {
        return Array<Text>{};
    }
}


/// NamedIn: fn [Text], Text, OutTy -> [Text]
Array<Text> named_in_f(const Array<Text>& names_p0, const Text& home_p1, const crate::lower::model::OutTy& t_p2) {
    if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t_p2)) {
        auto&& n_p3 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p2).a0;
        auto&& args_p4 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p2).a1;
        auto p_p5 = path_from_f(names_p0, home_p1, n_p3);
        auto own_p6 = crate::check::types::has_text_f(names_p0, parent_of_f(p_p5))
            ? Array(std::vector{parent_of_f(p_p5)})
            : Array<Text>{};
        return crate::prelude::fold(args_p4, own_p6, [&](const Array<Text>& acc_p7, const crate::lower::model::OutTy& a_p8) { return crate::check::types::union_texts_f(acc_p7, named_in_f(names_p0, home_p1, a_p8)); });
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutOpt>(t_p2)) {
        auto&& i_p9 = prism_rtl::as<crate::lower::model::OutTy::OutOpt>(t_p2).a0;
        return named_in_f(names_p0, home_p1, prism_rtl::deref(prism_rtl::deref(i_p9)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutRes>(t_p2)) {
        auto&& i_pa = prism_rtl::as<crate::lower::model::OutTy::OutRes>(t_p2).a0;
        return named_in_f(names_p0, home_p1, prism_rtl::deref(prism_rtl::deref(i_pa)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutCell>(t_p2)) {
        auto&& i_pb = prism_rtl::as<crate::lower::model::OutTy::OutCell>(t_p2).a0;
        return named_in_f(names_p0, home_p1, prism_rtl::deref(prism_rtl::deref(i_pb)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutArray>(t_p2)) {
        auto&& i_pc = prism_rtl::as<crate::lower::model::OutTy::OutArray>(t_p2).a0;
        return named_in_f(names_p0, home_p1, prism_rtl::deref(prism_rtl::deref(i_pc)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutRc>(t_p2)) {
        auto&& i_pd = prism_rtl::as<crate::lower::model::OutTy::OutRc>(t_p2).a0;
        return named_in_f(names_p0, home_p1, prism_rtl::deref(prism_rtl::deref(i_pd)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutEvent>(t_p2)) {
        auto&& i_pe = prism_rtl::as<crate::lower::model::OutTy::OutEvent>(t_p2).a0;
        return named_in_f(names_p0, home_p1, prism_rtl::deref(prism_rtl::deref(i_pe)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutDyn>(t_p2)) {
        auto&& i_pf = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(t_p2).a0;
        return named_in_f(names_p0, home_p1, prism_rtl::deref(prism_rtl::deref(i_pf)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutMap>(t_p2)) {
        auto&& k_pg = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t_p2).a0;
        auto&& v_ph = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t_p2).a1;
        return crate::check::types::union_texts_f(named_in_f(names_p0, home_p1, prism_rtl::deref(prism_rtl::deref(k_pg))), named_in_f(names_p0, home_p1, prism_rtl::deref(prism_rtl::deref(v_ph))));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutTuple>(t_p2)) {
        auto&& ts_pi = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(t_p2).a0;
        return crate::prelude::fold(ts_pi, Array<Text>{}, [&](const Array<Text>& acc_pj, const crate::lower::model::OutTy& a_pk) { return crate::check::types::union_texts_f(acc_pj, named_in_f(names_p0, home_p1, a_pk)); });
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutFn>(t_p2)) {
        auto&& ps_pl = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t_p2).a0;
        auto&& r_pm = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t_p2).a1;
        return crate::prelude::fold(ps_pl, named_in_f(names_p0, home_p1, prism_rtl::deref(prism_rtl::deref(r_pm))), [&](const Array<Text>& acc_pn, const crate::lower::model::OutTy& a_po) { return crate::check::types::union_texts_f(acc_pn, named_in_f(names_p0, home_p1, a_po)); });
    }
    {
        return Array<Text>{};
    }
}


/// PathFrom: fn [Text], Text, Text -> Text
Text path_from_f(const Array<Text>& names_p0, const Text& home_p1, const Text& n_p2) {
    auto q_p3 = crate::syntax::lexer::chars::drop_prefix_f(n_p2, Text::lit("crate::"));
    return starts_with_module_f(names_p0, q_p3)
        ? q_p3
        : home_p1 == Text::lit("") ? q_p3 : prism_rtl::cat(home_p1, "::", q_p3);
}


/// StartsWithModule: fn [Text], Text -> Bool
bool starts_with_module_f(const Array<Text>& names_p0, const Text& q_p1) {
    return crate::prelude::fold(names_p0, false, [&](const bool& f_p2, const Text& n_p3) { return prism_rtl::deref(f_p2) || ((n_p3 != Text::lit("")) && crate::syntax::lexer::chars::has_prefix_f(q_p1, prism_rtl::cat(n_p3, "::"))); });
}


/// ParentOf: fn Text -> Text
Text parent_of_f(const Text& p_p0) {
    auto segs_p1 = crate::prelude::split_on(p_p0, Text::lit("::"));
    return crate::syntax::lexer::chars::join_f(crate::prelude::take(segs_p1, crate::syntax::lexer::chars::dec_f(crate::prelude::len(segs_p1))), Text::lit("::"));
}


/// WithGroups: unbounded fn [ModDef] -> [ModDef]
Array<crate::lower::model::ModDef> with_groups_f(const Array<crate::lower::model::ModDef>& defs_p0) {
    auto edges_p1 = crate::prelude::fold(defs_p0, Map<Text, Array<Text>>{}, [&](const Map<Text, Array<Text>>& m_p3, const crate::lower::model::ModDef& d_p4) { return crate::prelude::insert(m_p3, prism_rtl::deref(d_p4).name_p, prism_rtl::deref(d_p4).complete_p); });
    auto reach_p2 = crate::prelude::run_to_end(crate::prelude::fold_job(defs_p0, Map<Text, Array<Text>>{}, ({
        auto edges_p1x = edges_p1;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Array<Text>>>(std::tuple<Map<Text, Array<Text>>, crate::lower::model::ModDef>)>>(prism_rtl::rc([=, edges_p1x = std::move(edges_p1x)](std::tuple<Map<Text, Array<Text>>, crate::lower::model::ModDef> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto edges_p1xy = edges_p1x;
            (crate::prelude::entered(crate::prelude::once_job([=, edges_p1xy = std::move(edges_p1xy)]() {
            return ({
                auto m_p5 = p0;
                auto d_p6 = p1;
                (crate::prelude::call_then(start_reached_by_f(edges_p1xy, Array(std::vector{prism_rtl::deref(d_p6).name_p}), Array<Text>{}), [=, m_p5 = std::move(m_p5)](Array<Text> reached_by_f_12517) { return prism_rtl::finished(crate::prelude::insert(m_p5, prism_rtl::deref(d_p6).name_p, reached_by_f_12517)); }));
            });
        })));
        });
    }));
    })));
    return crate::prelude::each(defs_p0, [&](const crate::lower::model::ModDef& d_p7) {
        return ({
            auto mine_p8 = crate::prelude::or_(crate::prelude::get(reach_p2, prism_rtl::deref(d_p7).name_p), Array<Text>{});
            ({
            crate::lower::model::ModDef this_ = d_p7;
            this_.types_with_p = crate::prelude::filter(crate::prelude::each(defs_p0, [&](const crate::lower::model::ModDef& o_p9) { return prism_rtl::deref(o_p9).name_p; }), [&](const Text& n_pa) { return (n_pa == prism_rtl::deref(d_p7).name_p) || (crate::check::types::has_text_f(mine_p8, n_pa) && crate::check::types::has_text_f(crate::prelude::or_(crate::prelude::get(reach_p2, n_pa), Array<Text>{}), prism_rtl::deref(d_p7).name_p)); });
            (std::move(this_));
        });
        });
    });
}


prism_rtl::Turn<Array<crate::lower::model::ModDef>> WithGroups::cycle() const {
    const auto& defs_p0 = this->defs_p0;
    auto edges_p1 = crate::prelude::fold(defs_p0, Map<Text, Array<Text>>{}, [&](const Map<Text, Array<Text>>& m_p3, const crate::lower::model::ModDef& d_p4) { return crate::prelude::insert(m_p3, prism_rtl::deref(d_p4).name_p, prism_rtl::deref(d_p4).complete_p); });
    auto defs_p0x = defs_p0;
    return crate::prelude::call_value(crate::prelude::fold_job(defs_p0x, Map<Text, Array<Text>>{}, ({
        auto edges_p1x = edges_p1;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Array<Text>>>(std::tuple<Map<Text, Array<Text>>, crate::lower::model::ModDef>)>>(prism_rtl::rc([=, edges_p1x = std::move(edges_p1x)](std::tuple<Map<Text, Array<Text>>, crate::lower::model::ModDef> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto edges_p1xy = edges_p1x;
            (crate::prelude::entered(crate::prelude::once_job([=, edges_p1xy = std::move(edges_p1xy)]() {
            return ({
                auto m_p5 = p0;
                auto d_p6 = p1;
                (crate::prelude::call_then(start_reached_by_f(edges_p1xy, Array(std::vector{prism_rtl::deref(d_p6).name_p}), Array<Text>{}), [=, m_p5 = std::move(m_p5)](Array<Text> reached_by_f_12517) { return prism_rtl::finished(crate::prelude::insert(m_p5, prism_rtl::deref(d_p6).name_p, reached_by_f_12517)); }));
            });
        })));
        });
    }));
    })), [=](Map<Text, Array<Text>> fold_12475) {
        return ({
            auto reach_p2 = fold_12475;
            (prism_rtl::finished(crate::prelude::each(defs_p0x, [&](const crate::lower::model::ModDef& d_p7) {
            return ({
                auto mine_p8 = crate::prelude::or_(crate::prelude::get(reach_p2, prism_rtl::deref(d_p7).name_p), Array<Text>{});
                ({
                crate::lower::model::ModDef this_ = d_p7;
                this_.types_with_p = crate::prelude::filter(crate::prelude::each(defs_p0x, [&](const crate::lower::model::ModDef& o_p9) { return prism_rtl::deref(o_p9).name_p; }), [&](const Text& n_pa) { return (n_pa == prism_rtl::deref(d_p7).name_p) || (crate::check::types::has_text_f(mine_p8, n_pa) && crate::check::types::has_text_f(crate::prelude::or_(crate::prelude::get(reach_p2, n_pa), Array<Text>{}), prism_rtl::deref(d_p7).name_p)); });
                (std::move(this_));
            });
            });
        })));
        });
    });
}


/// `Start WithGroups, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::lower::model::ModDef>> start_with_groups_f(Array<crate::lower::model::ModDef> defs_p0) {
    return prism_rtl::make_rc<WithGroups>(defs_p0);
}


/// ReachedBy: unbounded fn (Text ==> [Text]), [Text], [Text] -> [Text]
Array<Text> reached_by_f(const Map<Text, Array<Text>>& edges_p0, const Array<Text>& todo_p1, const Array<Text>& seen_p2) {
    auto&& _m = crate::prelude::index(todo_p1, Nat(0u));
    if (prism_rtl::is_none(_m)) {
        return seen_p2;
    }
    if (prism_rtl::is_some(_m)) {
        auto&& m_p3 = prism_rtl::some_of(_m);
        return crate::check::types::has_text_f(seen_p2, m_p3)
            ? reached_by_f(edges_p0, crate::prelude::drop(todo_p1, Nat(1u)), seen_p2)
            : reached_by_f(edges_p0, crate::prelude::append(crate::prelude::drop(todo_p1, Nat(1u)), crate::prelude::or_(crate::prelude::get(edges_p0, m_p3), Array<Text>{})), crate::prelude::push(seen_p2, m_p3));
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Text>> ReachedBy::cycle() const {
    const auto& edges_p0 = this->edges_p0;
    const auto& todo_p1 = this->todo_p1;
    const auto& seen_p2 = this->seen_p2;
    return ({
        auto&& _m = crate::prelude::index(todo_p1, Nat(0u));
        prism_rtl::is_none(_m) ? prism_rtl::finished(seen_p2)
        : prism_rtl::is_some(_m) ? ({
        auto&& m_p3 = prism_rtl::some_of(_m);
        crate::check::types::has_text_f(seen_p2, m_p3)
        ? prism_rtl::more(prism_rtl::rc(ReachedBy(edges_p0, crate::prelude::drop(todo_p1, Nat(1u)), seen_p2)))
        : prism_rtl::more(prism_rtl::rc(ReachedBy(edges_p0, crate::prelude::append(crate::prelude::drop(todo_p1, Nat(1u)), crate::prelude::or_(crate::prelude::get(edges_p0, m_p3), Array<Text>{})), crate::prelude::push(seen_p2, m_p3))));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ReachedBy, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_reached_by_f(Map<Text, Array<Text>> edges_p0, Array<Text> todo_p1, Array<Text> seen_p2) {
    return prism_rtl::make_rc<ReachedBy>(edges_p0, todo_p1, seen_p2);
}


/// NeededMods: unbounded fn G, Nat -> [Text]
Array<Text> needed_mods_f(const crate::check::env::G& g_p0, const Nat& shown_p1) {
    auto own_p2 = crate::prelude::filter(crate::prelude::keys(g_p0.mods_p), [&](const Text& m_p4) { return (prism_rtl::deref(crate::prelude::or_(crate::prelude::get(g_p0.mods_p, m_p4), crate::check::env::reading::dummy_mod_p())).file_p < shown_p1) && (m_p4 != Text::lit("Prelude")); });
    auto grown_p3 = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(Nat(6u)), own_p2, ({
        auto g_p0x = g_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Nat>)>>(prism_rtl::rc([=, g_p0x = std::move(g_p0x)](std::tuple<Array<Text>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_p0xy = g_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, g_p0xy = std::move(g_p0xy)]() {
            return ({
                auto acc_p5 = p0;
                static_cast<void>(p1);
                (crate::prelude::fold_job(acc_p5, acc_p5, ({
                auto g_p0xyx = g_p0xy;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Text>)>>(prism_rtl::rc([=, g_p0xyx = std::move(g_p0xyx)](std::tuple<Array<Text>, Text> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto g_p0xyxy = g_p0xyx;
                    (crate::prelude::entered(crate::prelude::once_job([=, g_p0xyxy = std::move(g_p0xyxy)]() {
                    return ({
                        auto a_p6 = p0;
                        auto m_p7 = p1;
                        (crate::prelude::call_then(start_mod_refs_f(g_p0xyxy, m_p7), [=, a_p6 = std::move(a_p6)](Array<Text> mod_refs_f_13540) { return prism_rtl::finished(crate::check::types::union_texts_f(a_p6, mod_refs_f_13540)); }));
                    });
                })));
                });
            })));
            }))->cycle());
            });
        })));
        });
    })));
    })));
    return crate::prelude::filter(crate::prelude::keys(g_p0.mods_p), [&](const Text& m_p8) { return (m_p8 != Text::lit("Prelude")) && crate::check::types::has_text_f(grown_p3, m_p8); });
}


prism_rtl::Turn<Array<Text>> NeededMods::cycle() const {
    const auto& g_p0 = this->g_p0;
    const auto& shown_p1 = this->shown_p1;
    auto own_p2 = crate::prelude::filter(crate::prelude::keys(prism_rtl::deref(g_p0).mods_p), [&](const Text& m_p4) { return (prism_rtl::deref(crate::prelude::or_(crate::prelude::get(prism_rtl::deref(g_p0).mods_p, m_p4), crate::check::env::reading::dummy_mod_p())).file_p < shown_p1) && (m_p4 != Text::lit("Prelude")); });
    auto g_p0x = g_p0;
    return crate::prelude::call_value(crate::prelude::fold_job(crate::check::errors::range0_f(Nat(6u)), own_p2, ({
        auto g_p0xx = g_p0x;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Nat>)>>(prism_rtl::rc([=, g_p0xx = std::move(g_p0xx)](std::tuple<Array<Text>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_p0xxy = g_p0xx;
            (crate::prelude::entered(crate::prelude::once_job([=, g_p0xxy = std::move(g_p0xxy)]() {
            return ({
                auto acc_p5 = p0;
                static_cast<void>(p1);
                (crate::prelude::fold_job(acc_p5, acc_p5, ({
                auto g_p0xxyx = g_p0xxy;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Text>)>>(prism_rtl::rc([=, g_p0xxyx = std::move(g_p0xxyx)](std::tuple<Array<Text>, Text> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto g_p0xxyxy = g_p0xxyx;
                    (crate::prelude::entered(crate::prelude::once_job([=, g_p0xxyxy = std::move(g_p0xxyxy)]() {
                    return ({
                        auto a_p6 = p0;
                        auto m_p7 = p1;
                        (crate::prelude::call_then(start_mod_refs_f(g_p0xxyxy, m_p7), [=, a_p6 = std::move(a_p6)](Array<Text> mod_refs_f_13540) { return prism_rtl::finished(crate::check::types::union_texts_f(a_p6, mod_refs_f_13540)); }));
                    });
                })));
                });
            })));
            }))->cycle());
            });
        })));
        });
    })));
    })), [=](Array<Text> fold_13465) {
        return ({
            auto grown_p3 = fold_13465;
            (prism_rtl::finished(crate::prelude::filter(crate::prelude::keys(prism_rtl::deref(g_p0x).mods_p), [&](const Text& m_p8) { return (m_p8 != Text::lit("Prelude")) && crate::check::types::has_text_f(grown_p3, m_p8); })));
        });
    });
}


/// `Start NeededMods, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_needed_mods_f(crate::check::env::G g_p0, Nat shown_p1) {
    return prism_rtl::make_rc<NeededMods>(g_p0, shown_p1);
}


/// ModRefs: unbounded fn G, Text -> [Text]
Array<Text> mod_refs_f(const crate::check::env::G& g_p0, const Text& m_p1) {
    auto&& _m = crate::prelude::get(g_p0.mods_p, m_p1);
    if (prism_rtl::is_some(_m)) {
        auto&& info_p2 = prism_rtl::some_of(_m);
        auto used_p3 = crate::prelude::each(prism_rtl::deref(info_p2).uses_p, [&](const std::tuple<Text, bool>& _p0) {
            auto&& u_p5 = std::get<0>(_p0);
            return u_p5;
        });
        auto fams_p4 = ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = prism_rtl::deref(prism_rtl::deref(info_p2).tree_p).emit_row_o;
            if (prism_rtl::is_some(_m)) {
                auto&& rw_p6 = prism_rtl::some_of(_m);
                _v.set(crate::prelude::fold(prism_rtl::deref(rw_p6).terms_p, Array<Text>{}, [&](const Array<Text>& acc_p7, const crate::syntax::RowTerm& t_p8) {
                    return ({
                        __label__ _done;
                        prism_rtl::Slot<Array<Text>> _v;
                        if (prism_rtl::is<crate::syntax::RowTerm::RFamily>(t_p8)) {
                            auto&& q_p9 = prism_rtl::as<crate::syntax::RowTerm::RFamily>(t_p8).a0;
                            _v.set(crate::prelude::push(acc_p7, crate::prelude::or_(crate::prelude::get(g_p0.fam_owner_p, crate::check::env::dotted_f(prism_rtl::deref(q_p9).path_p)), crate::check::env::dotted_f(prism_rtl::deref(q_p9).path_p))));
                            goto _done;
                        }
                        {
                            _v.set(acc_p7);
                            goto _done;
                        }
                    _done:
                        _v.take();
                    });
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(Array<Text>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        return crate::prelude::filter(crate::prelude::append(used_p3, fams_p4), [&](const Text& x_pa) { return crate::check::env::has_key_f(g_p0.mods_p, x_pa); });
    }
    if (prism_rtl::is_none(_m)) {
        return Array<Text>{};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Text>> ModRefs::cycle() const {
    const auto& g_p0 = this->g_p0;
    const auto& m_p1 = this->m_p1;
    return ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(g_p0).mods_p, m_p1);
        prism_rtl::is_some(_m) ? ({
        auto&& info_p2 = prism_rtl::some_of(_m);
        ({
        auto used_p3 = crate::prelude::each(prism_rtl::deref(info_p2).uses_p, [&](const std::tuple<Text, bool>& _p0) {
            auto&& u_p5 = std::get<0>(_p0);
            return u_p5;
        });
        auto fams_p4 = ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = prism_rtl::deref(prism_rtl::deref(info_p2).tree_p).emit_row_o;
            if (prism_rtl::is_some(_m)) {
                auto&& rw_p6 = prism_rtl::some_of(_m);
                _v.set(crate::prelude::fold(prism_rtl::deref(rw_p6).terms_p, Array<Text>{}, [&](const Array<Text>& acc_p7, const crate::syntax::RowTerm& t_p8) {
                    return ({
                        __label__ _done;
                        prism_rtl::Slot<Array<Text>> _v;
                        if (prism_rtl::is<crate::syntax::RowTerm::RFamily>(t_p8)) {
                            auto&& q_p9 = prism_rtl::as<crate::syntax::RowTerm::RFamily>(t_p8).a0;
                            _v.set(crate::prelude::push(acc_p7, crate::prelude::or_(crate::prelude::get(prism_rtl::deref(g_p0).fam_owner_p, crate::check::env::dotted_f(prism_rtl::deref(q_p9).path_p)), crate::check::env::dotted_f(prism_rtl::deref(q_p9).path_p))));
                            goto _done;
                        }
                        {
                            _v.set(acc_p7);
                            goto _done;
                        }
                    _done:
                        _v.take();
                    });
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(Array<Text>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        (prism_rtl::finished(crate::prelude::filter(crate::prelude::append(used_p3, fams_p4), [&](const Text& x_pa) { return crate::check::env::has_key_f(prism_rtl::deref(g_p0).mods_p, x_pa); })));
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(Array<Text>{})
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ModRefs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_mod_refs_f(crate::check::env::G g_p0, Text m_p1) {
    return prism_rtl::make_rc<ModRefs>(g_p0, m_p1);
}


/// RootWidgets: fn Lx -> [((Text, Bool))]
Array<std::tuple<Text, bool>> root_widgets_f(const crate::lower::Lx& lx_p0) {
    auto tested_p1 = crate::prelude::fold(prism_rtl::deref(lx_p0.g_p).defs_p, Array<std::tuple<Text, bool>>{}, [&](const Array<std::tuple<Text, bool>>& acc_p3, const crate::check::env::Def& d_p4) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<std::tuple<Text, bool>>> _v;
            auto&& _m = prism_rtl::deref(d_p4).body_p;
            if (prism_rtl::is<crate::check::env::DefBody::DbTest>(_m)) {
                auto&& t_p5 = prism_rtl::as<crate::check::env::DefBody::DbTest>(_m).a0;
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Array<std::tuple<Text, bool>>> _v;
                    auto&& _m = blueprint_qk_f(in_module_f(lx_p0, prism_rtl::deref(d_p4).file_p, prism_rtl::deref(d_p4).home_p), prism_rtl::deref(t_p5).blueprint_p);
                    {
                        auto&& m14294_0 = _m;
                        if (m14294_0 == Text::lit("")) {
                            _v.set(acc_p3);
                            goto _done;
                        }
                    }
                    {
                        auto&& qk_p6 = _m;
                        _v.set(crate::check::types::has_text_f(crate::prelude::each(acc_p3, [&](const std::tuple<Text, bool>& _p0) {
                            auto&& q_p7 = std::get<0>(_p0);
                            return q_p7;
                        }), qk_p6)
                            ? acc_p3
                            : crate::prelude::push(acc_p3, std::tuple{qk_p6, true}));
                        goto _done;
                    }
                _done:
                    _v.take();
                }));
                goto _done;
            }
            {
                _v.set(acc_p3);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto main_p2 = crate::prelude::fold(prism_rtl::deref(lx_p0.g_p).defs_p, Array<std::tuple<Text, bool>>{}, [&](const Array<std::tuple<Text, bool>>& acc_p8, const crate::check::env::Def& d_p9) {
        return is_main_f(prism_rtl::deref(d_p9).qk_p)
            ? crate::prelude::push(acc_p8, std::tuple{prism_rtl::deref(d_p9).qk_p, false})
            : acc_p8;
    });
    return crate::prelude::fold(main_p2, tested_p1, [&](const Array<std::tuple<Text, bool>>& acc_pa, const std::tuple<Text, bool>& _p1) {
        auto&& k_pb = std::get<0>(_p1);
        auto&& b_pc = std::get<1>(_p1);
        return crate::check::types::has_text_f(crate::prelude::each(acc_pa, [&](const std::tuple<Text, bool>& _p0) {
            auto&& q_pd = std::get<0>(_p0);
            return q_pd;
        }), k_pb)
            ? acc_pa
            : crate::prelude::push(acc_pa, std::tuple{k_pb, prism_rtl::deref(b_pc)});
    });
}


/// IsMain: fn Text -> Bool
bool is_main_f(const Text& qk_p0) {
    return ((crate::lower::owner_of_f(qk_p0) == Text::lit("")) && (crate::lower::base_f(crate::check::types::bare_name_f(qk_p0)) == Text::lit("main"))) && crate::syntax::lexer::chars::has_prefix_f(crate::check::types::bare_name_f(qk_p0), Text::lit("@"));
}


/// BlueprintQk: fn Lx, Expr -> Text
Text blueprint_qk_f(const crate::lower::Lx& lx_p0, const crate::syntax::Expr& e_p1) {
    auto&& _m = prism_rtl::deref(e_p1.kind_p);
    if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
        auto&& c_p2 = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
        return blueprint_qk_f(lx_p0, prism_rtl::deref(prism_rtl::deref(c_p2)));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x_p3 = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return blueprint_qk_f(lx_p0, prism_rtl::deref(prism_rtl::deref(x_p3)));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n_p4 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        auto&& _q_o5 = crate::check::env::names::resolve_value_f(lx_p0.g_p, lx_p0.home_p, n_p4);
        auto&& q_o5 = std::get<0>(_q_o5);
        return crate::prelude::or_(q_o5, Text::lit(""));
    }
    {
        return Text::lit("");
    }
}


/// ValOf: fn Lx, Text -> ValInfo
crate::check::env::ValInfo val_of_f(const crate::lower::Lx& lx_p0, const Text& qk_p1) {
    auto&& _m = crate::prelude::get(prism_rtl::deref(lx_p0.g_p).vals_p, qk_p1);
    if (prism_rtl::is_some(_m)) {
        auto&& v_p2 = prism_rtl::some_of(_m);
        return v_p2;
    }
    if (prism_rtl::is_none(_m)) {
        auto d_p3 = crate::prelude::fold(prism_rtl::deref(lx_p0.g_p).defs_p, crate::check::env::decls::dummy_def_p(), [&](const crate::check::env::Def& found_p4, const crate::check::env::Def& df_p5) { return prism_rtl::deref(df_p5).qk_p == qk_p1 ? df_p5 : found_p4; });
        return crate::check::env::ValInfo{.qk_p = qk_p1, .scheme_p = crate::check::types::schemes::mono_f(crate::check::types::Ty(crate::check::types::Ty::TyErr{})), .sort_p = Text::lit("fn"), .has_sig_p = false, .home_p = prism_rtl::deref(d_p3).home_p, .file_p = prism_rtl::deref(d_p3).file_p, .span_p = prism_rtl::deref(d_p3).span_p};
    }
    prism_rtl::unreachable("no arm matched");
}


/// ProgDefOf: unbounded fn Lx, Text -> ProgDef
crate::lower::model::ProgDef prog_def_of_f(const crate::lower::Lx& lx_p0, const Text& qk_p1) {
    auto v_p2 = val_of_f(lx_p0, qk_p1);
    auto ptys_p3 = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::check::types::Ty>> _v;
        auto&& _m = prism_rtl::deref(prism_rtl::deref(v_p2).scheme_p).ty_p;
        if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
            auto&& ps_p9 = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a1;
            _v.set(ps_p9);
            goto _done;
        }
        {
            _v.set(Array<crate::check::types::Ty>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto lxm_p4 = in_module_at_f(lx_p0, prism_rtl::deref(v_p2).file_p, prism_rtl::deref(v_p2).home_p, Text::lit("\000main"sv));
    auto params_p5 = crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(crate::prelude::len(ptys_p3)), ({
        auto lxm_p4x = lxm_p4;
        auto ptys_p3x = ptys_p3;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, crate::lower::model::OutTy>>(Nat)>>(prism_rtl::rc([=, lxm_p4x = std::move(lxm_p4x), ptys_p3x = std::move(ptys_p3x)](Nat p0) {
        return ({
            auto lxm_p4xy = lxm_p4x;
            auto ptys_p3xy = ptys_p3x;
            (crate::prelude::entered(crate::prelude::once_job([=, lxm_p4xy = std::move(lxm_p4xy), ptys_p3xy = std::move(ptys_p3xy)]() {
            return ({
                auto i_pa = p0;
                (crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lxm_p4xy, crate::lower::types::peel_f(crate::prelude::or_(crate::prelude::index(ptys_p3xy, i_pa), crate::check::types::Ty(crate::check::types::Ty::TyErr{})))), [=](crate::lower::model::OutTy out_ty_of_f_15869) { return prism_rtl::finished(std::tuple{prism_rtl::cat("arg", i_pa), out_ty_of_f_15869}); }));
            });
        })));
        });
    }));
    })));
    auto node_p6 = prism_rtl::cat(crate::lower::rust_mod_name_f(prism_rtl::deref(v_p2).home_p), "::", crate::lower::camel_f(crate::check::types::bare_name_f(qk_p1)));
    auto fams_p7 = prism_rtl::deref(prism_rtl::deref(crate::prelude::or_(crate::prelude::get(prism_rtl::deref(lx_p0.g_p).mods_p, prism_rtl::deref(v_p2).home_p), crate::check::env::reading::dummy_mod_p())).emit_rw_p).fams_p;
    auto world_p8 = crate::check::types::has_text_f(fams_p7, Text::lit("Gui"))
        ? Text::lit("canvas")
        : crate::check::types::has_text_f(fams_p7, Text::lit("Ui"))
        ? Text::lit("none")
        : Text::lit("cli");
    return crate::lower::model::ProgDef{.name_p = prism_rtl::cat(crate::lower::camel_f(crate::check::types::bare_name_f(qk_p1)), "Program"), .prism_p = crate::syntax::lexer::chars::after_first_f(crate::check::types::bare_name_f(qk_p1)), .node_p = node_p6, .params_p = params_p5, .fallible_p = true, .world_p = world_p8};
}


prism_rtl::Turn<crate::lower::model::ProgDef> ProgDefOf::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& qk_p1 = this->qk_p1;
    auto v_p2 = val_of_f(lx_p0, qk_p1);
    auto ptys_p3 = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::check::types::Ty>> _v;
        auto&& _m = prism_rtl::deref(prism_rtl::deref(v_p2).scheme_p).ty_p;
        if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
            auto&& ps_p9 = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a1;
            _v.set(ps_p9);
            goto _done;
        }
        {
            _v.set(Array<crate::check::types::Ty>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto lxm_p4 = in_module_at_f(lx_p0, prism_rtl::deref(v_p2).file_p, prism_rtl::deref(v_p2).home_p, Text::lit("\000main"sv));
    auto lx_p0x = lx_p0;
    auto qk_p1x = qk_p1;
    return crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(crate::prelude::len(ptys_p3)), ({
        auto lxm_p4x = lxm_p4;
        auto ptys_p3x = ptys_p3;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, crate::lower::model::OutTy>>(Nat)>>(prism_rtl::rc([=, lxm_p4x = std::move(lxm_p4x), ptys_p3x = std::move(ptys_p3x)](Nat p0) {
        return ({
            auto lxm_p4xy = lxm_p4x;
            auto ptys_p3xy = ptys_p3x;
            (crate::prelude::entered(crate::prelude::once_job([=, lxm_p4xy = std::move(lxm_p4xy), ptys_p3xy = std::move(ptys_p3xy)]() {
            return ({
                auto i_pa = p0;
                (crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lxm_p4xy, crate::lower::types::peel_f(crate::prelude::or_(crate::prelude::index(ptys_p3xy, i_pa), crate::check::types::Ty(crate::check::types::Ty::TyErr{})))), [=](crate::lower::model::OutTy out_ty_of_f_15869) { return prism_rtl::finished(std::tuple{prism_rtl::cat("arg", i_pa), out_ty_of_f_15869}); }));
            });
        })));
        });
    }));
    })), [=](Array<std::tuple<Text, crate::lower::model::OutTy>> each_15825) {
        return ({
            auto params_p5 = each_15825;
            auto node_p6 = prism_rtl::cat(crate::lower::rust_mod_name_f(prism_rtl::deref(v_p2).home_p), "::", crate::lower::camel_f(crate::check::types::bare_name_f(qk_p1x)));
            auto fams_p7 = prism_rtl::deref(prism_rtl::deref(crate::prelude::or_(crate::prelude::get(prism_rtl::deref(prism_rtl::deref(lx_p0x).g_p).mods_p, prism_rtl::deref(v_p2).home_p), crate::check::env::reading::dummy_mod_p())).emit_rw_p).fams_p;
            auto world_p8 = crate::check::types::has_text_f(fams_p7, Text::lit("Gui"))
                ? Text::lit("canvas")
                : crate::check::types::has_text_f(fams_p7, Text::lit("Ui"))
                ? Text::lit("none")
                : Text::lit("cli");
            (prism_rtl::finished(crate::lower::model::ProgDef{.name_p = prism_rtl::cat(crate::lower::camel_f(crate::check::types::bare_name_f(qk_p1x)), "Program"), .prism_p = crate::syntax::lexer::chars::after_first_f(crate::check::types::bare_name_f(qk_p1x)), .node_p = node_p6, .params_p = params_p5, .fallible_p = true, .world_p = world_p8}));
        });
    });
}


/// `Start ProgDefOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::ProgDef> start_prog_def_of_f(crate::lower::Lx lx_p0, Text qk_p1) {
    return prism_rtl::make_rc<ProgDefOf>(lx_p0, qk_p1);
}


/// JobRoots: unbounded fn Lx -> [Text]
Array<Text> job_roots_f(const crate::lower::Lx& lx_p0) {
    auto direct_p1 = crate::prelude::run_to_end(crate::prelude::fold_job(prism_rtl::deref(lx_p0.g_p).defs_p, Array<Text>{}, ({
        auto lx_p0x = lx_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::env::Def>)>>(prism_rtl::rc([=, lx_p0x = std::move(lx_p0x)](std::tuple<Array<Text>, crate::check::env::Def> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_p0xy = lx_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xy = std::move(lx_p0xy)]() {
            return ({
                auto acc_p2 = p0;
                auto d_p3 = p1;
                ({
                auto lxd_p4 = in_module_f(lx_p0xy, prism_rtl::deref(d_p3).file_p, prism_rtl::deref(d_p3).home_p);
                (crate::prelude::call_then(start_run_targets_f(lxd_p4, d_p3), [=](Array<Text> run_targets_f_16704) { return crate::prelude::call_then(start_unbounded_values_f(lxd_p4, d_p3), [=](Array<Text> unbounded_values_f_16726) { return prism_rtl::finished(crate::check::types::union_texts_f(crate::check::types::union_texts_f(acc_p2, run_targets_f_16704), unbounded_values_f_16726)); }); }));
            });
            });
        })));
        });
    })));
    })));
    return crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(Nat(8u)), direct_p1, ({
        auto lx_p0x = lx_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Nat>)>>(prism_rtl::rc([=, lx_p0x = std::move(lx_p0x)](std::tuple<Array<Text>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_p0xy = lx_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xy = std::move(lx_p0xy)]() {
            return ({
                auto acc_p5 = p0;
                static_cast<void>(p1);
                (crate::prelude::fold_job(acc_p5, acc_p5, ({
                auto lx_p0xyx = lx_p0xy;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Text>)>>(prism_rtl::rc([=, lx_p0xyx = std::move(lx_p0xyx)](std::tuple<Array<Text>, Text> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto lx_p0xyxy = lx_p0xyx;
                    (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xyxy = std::move(lx_p0xyxy)]() {
                    return ({
                        auto a_p6 = p0;
                        auto qk_p7 = p1;
                        (crate::prelude::call_then(start_tail_targets_f(lx_p0xyxy, qk_p7), [=, a_p6 = std::move(a_p6)](Array<Text> tail_targets_f_16833) { return prism_rtl::finished(crate::check::types::union_texts_f(a_p6, tail_targets_f_16833)); }));
                    });
                })));
                });
            })));
            }))->cycle());
            });
        })));
        });
    })));
    })));
}


prism_rtl::Turn<Array<Text>> JobRoots::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    auto lx_p0x = lx_p0;
    return crate::prelude::call_value(crate::prelude::fold_job(prism_rtl::deref(prism_rtl::deref(lx_p0x).g_p).defs_p, Array<Text>{}, ({
        auto lx_p0xx = lx_p0x;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::env::Def>)>>(prism_rtl::rc([=, lx_p0xx = std::move(lx_p0xx)](std::tuple<Array<Text>, crate::check::env::Def> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_p0xxy = lx_p0xx;
            (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xxy = std::move(lx_p0xxy)]() {
            return ({
                auto acc_p2 = p0;
                auto d_p3 = p1;
                ({
                auto lxd_p4 = in_module_f(lx_p0xxy, prism_rtl::deref(d_p3).file_p, prism_rtl::deref(d_p3).home_p);
                (crate::prelude::call_then(start_run_targets_f(lxd_p4, d_p3), [=](Array<Text> run_targets_f_16704) { return crate::prelude::call_then(start_unbounded_values_f(lxd_p4, d_p3), [=](Array<Text> unbounded_values_f_16726) { return prism_rtl::finished(crate::check::types::union_texts_f(crate::check::types::union_texts_f(acc_p2, run_targets_f_16704), unbounded_values_f_16726)); }); }));
            });
            });
        })));
        });
    })));
    })), [=](Array<Text> fold_16589) {
        return ({
            auto direct_p1 = fold_16589;
            (crate::prelude::fold_job(crate::check::errors::range0_f(Nat(8u)), direct_p1, ({
            auto lx_p0xx = lx_p0x;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Nat>)>>(prism_rtl::rc([=, lx_p0xx = std::move(lx_p0xx)](std::tuple<Array<Text>, Nat> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto lx_p0xxy = lx_p0xx;
                (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xxy = std::move(lx_p0xxy)]() {
                return ({
                    auto acc_p5 = p0;
                    static_cast<void>(p1);
                    (crate::prelude::fold_job(acc_p5, acc_p5, ({
                    auto lx_p0xxyx = lx_p0xxy;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Text>)>>(prism_rtl::rc([=, lx_p0xxyx = std::move(lx_p0xxyx)](std::tuple<Array<Text>, Text> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto lx_p0xxyxy = lx_p0xxyx;
                        (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xxyxy = std::move(lx_p0xxyxy)]() {
                        return ({
                            auto a_p6 = p0;
                            auto qk_p7 = p1;
                            (crate::prelude::call_then(start_tail_targets_f(lx_p0xxyxy, qk_p7), [=, a_p6 = std::move(a_p6)](Array<Text> tail_targets_f_16833) { return prism_rtl::finished(crate::check::types::union_texts_f(a_p6, tail_targets_f_16833)); }));
                        });
                    })));
                    });
                })));
                }))->cycle());
                });
            })));
            });
        })));
        }))->cycle());
        });
    });
}


/// `Start JobRoots, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_job_roots_f(crate::lower::Lx lx_p0) {
    return prism_rtl::make_rc<JobRoots>(lx_p0);
}


/// UnboundedValues: unbounded fn Lx, Def -> [Text]
Array<Text> unbounded_values_f(const crate::lower::Lx& lx_p0, const crate::check::env::Def& d_p1) {
    auto es_p2 = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::syntax::Expr>> _v;
        auto&& _m = d_p1.body_p;
        if (prism_rtl::is<crate::check::env::DefBody::DbWidget>(_m)) {
            auto&& w_p4 = prism_rtl::as<crate::check::env::DefBody::DbWidget>(_m).a0;
            _v.set(crate::check::typed::print::block_exprs_f(prism_rtl::deref(w_p4).body_p));
            goto _done;
        }
        if (prism_rtl::is<crate::check::env::DefBody::DbFn>(_m)) {
            auto&& cs_p5 = prism_rtl::as<crate::check::env::DefBody::DbFn>(_m).a0;
            _v.set(crate::prelude::run_to_end(crate::prelude::fold_job(cs_p5, Array<crate::syntax::Expr>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::syntax::Expr>>(std::tuple<Array<crate::syntax::Expr>, crate::syntax::decls::FnClause>)>>(prism_rtl::rc([=](std::tuple<Array<crate::syntax::Expr>, crate::syntax::decls::FnClause> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return crate::prelude::entered(crate::prelude::once_job([=]() {
                    return ({
                        auto acc_p6 = p0;
                        auto c_p7 = p1;
                        (crate::prelude::call_then(crate::check::typed::print::start_body_exprs_f(prism_rtl::deref(c_p7).body_p), [=, acc_p6 = std::move(acc_p6)](Array<crate::syntax::Expr> body_exprs_f_17184) { return prism_rtl::finished(crate::prelude::append(acc_p6, body_exprs_f_17184)); }));
                    });
                }));
            })))));
            goto _done;
        }
        if (prism_rtl::is<crate::check::env::DefBody::DbLet>(_m)) {
            auto&& l_p8 = prism_rtl::as<crate::check::env::DefBody::DbLet>(_m).a0;
            _v.set(crate::check::typed::print::exprs_in_f(prism_rtl::deref(l_p8).value_p));
            goto _done;
        }
        {
            _v.set(Array<crate::syntax::Expr>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto callees_p3 = crate::prelude::fold(es_p2, Array<Text>{}, [&](const Array<Text>& acc_p9, const crate::syntax::Expr& e_pa) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = prism_rtl::deref(prism_rtl::deref(e_pa).kind_p);
            if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
                auto&& c_pb = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
                _v.set(crate::prelude::push(acc_p9, crate::lower::place_key_f(lx_p0, prism_rtl::deref(c_pb).span_p)));
                goto _done;
            }
            {
                _v.set(acc_p9);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    return crate::prelude::fold(es_p2, Array<Text>{}, [&](const Array<Text>& acc_pc, const crate::syntax::Expr& e_pd) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = prism_rtl::deref(prism_rtl::deref(e_pd).kind_p);
            if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
                auto&& n_pe = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
                _v.set(crate::check::types::has_text_f(callees_p3, crate::lower::place_key_f(lx_p0, prism_rtl::deref(e_pd).span_p))
                    ? acc_pc
                    : ({
                    auto&& _q_of = crate::check::env::names::resolve_value_f(lx_p0.g_p, lx_p0.home_p, n_pe);
                    auto&& q_of = std::get<0>(_q_of);
                    ({
                    __label__ _done;
                    prism_rtl::Slot<Array<Text>> _v;
                    if (prism_rtl::is_some(q_of)) {
                        auto&& q_pg = prism_rtl::some_of(q_of);
                        _v.set(is_unbounded_f(lx_p0, q_pg)
                            ? crate::check::types::add_text_f(acc_pc, q_pg)
                            : acc_pc);
                        goto _done;
                    }
                    if (prism_rtl::is_none(q_of)) {
                        _v.set(acc_pc);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                }));
                goto _done;
            }
            {
                _v.set(acc_pc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


prism_rtl::Turn<Array<Text>> UnboundedValues::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& d_p1 = this->d_p1;
    auto es_p2 = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::syntax::Expr>> _v;
        auto&& _m = prism_rtl::deref(d_p1).body_p;
        if (prism_rtl::is<crate::check::env::DefBody::DbWidget>(_m)) {
            auto&& w_p4 = prism_rtl::as<crate::check::env::DefBody::DbWidget>(_m).a0;
            _v.set(crate::check::typed::print::block_exprs_f(prism_rtl::deref(w_p4).body_p));
            goto _done;
        }
        if (prism_rtl::is<crate::check::env::DefBody::DbFn>(_m)) {
            auto&& cs_p5 = prism_rtl::as<crate::check::env::DefBody::DbFn>(_m).a0;
            _v.set(crate::prelude::run_to_end(crate::prelude::fold_job(cs_p5, Array<crate::syntax::Expr>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::syntax::Expr>>(std::tuple<Array<crate::syntax::Expr>, crate::syntax::decls::FnClause>)>>(prism_rtl::rc([=](std::tuple<Array<crate::syntax::Expr>, crate::syntax::decls::FnClause> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return crate::prelude::entered(crate::prelude::once_job([=]() {
                    return ({
                        auto acc_p6 = p0;
                        auto c_p7 = p1;
                        (crate::prelude::call_then(crate::check::typed::print::start_body_exprs_f(prism_rtl::deref(c_p7).body_p), [=, acc_p6 = std::move(acc_p6)](Array<crate::syntax::Expr> body_exprs_f_17184) { return prism_rtl::finished(crate::prelude::append(acc_p6, body_exprs_f_17184)); }));
                    });
                }));
            })))));
            goto _done;
        }
        if (prism_rtl::is<crate::check::env::DefBody::DbLet>(_m)) {
            auto&& l_p8 = prism_rtl::as<crate::check::env::DefBody::DbLet>(_m).a0;
            _v.set(crate::check::typed::print::exprs_in_f(prism_rtl::deref(l_p8).value_p));
            goto _done;
        }
        {
            _v.set(Array<crate::syntax::Expr>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto callees_p3 = crate::prelude::fold(es_p2, Array<Text>{}, [&](const Array<Text>& acc_p9, const crate::syntax::Expr& e_pa) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = prism_rtl::deref(prism_rtl::deref(e_pa).kind_p);
            if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
                auto&& c_pb = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
                _v.set(crate::prelude::push(acc_p9, crate::lower::place_key_f(lx_p0, prism_rtl::deref(c_pb).span_p)));
                goto _done;
            }
            {
                _v.set(acc_p9);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    return prism_rtl::finished(crate::prelude::fold(es_p2, Array<Text>{}, [&](const Array<Text>& acc_pc, const crate::syntax::Expr& e_pd) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = prism_rtl::deref(prism_rtl::deref(e_pd).kind_p);
            if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
                auto&& n_pe = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
                _v.set(crate::check::types::has_text_f(callees_p3, crate::lower::place_key_f(lx_p0, prism_rtl::deref(e_pd).span_p))
                    ? acc_pc
                    : ({
                    auto&& _q_of = crate::check::env::names::resolve_value_f(prism_rtl::deref(lx_p0).g_p, prism_rtl::deref(lx_p0).home_p, n_pe);
                    auto&& q_of = std::get<0>(_q_of);
                    ({
                    __label__ _done;
                    prism_rtl::Slot<Array<Text>> _v;
                    if (prism_rtl::is_some(q_of)) {
                        auto&& q_pg = prism_rtl::some_of(q_of);
                        _v.set(is_unbounded_f(lx_p0, q_pg)
                            ? crate::check::types::add_text_f(acc_pc, q_pg)
                            : acc_pc);
                        goto _done;
                    }
                    if (prism_rtl::is_none(q_of)) {
                        _v.set(acc_pc);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                }));
                goto _done;
            }
            {
                _v.set(acc_pc);
                goto _done;
            }
        _done:
            _v.take();
        });
    }));
}


/// `Start UnboundedValues, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_unbounded_values_f(crate::lower::Lx lx_p0, crate::check::env::Def d_p1) {
    return prism_rtl::make_rc<UnboundedValues>(lx_p0, d_p1);
}


/// InPrelude: fn Lx, Text -> Bool
bool in_prelude_f(const crate::lower::Lx& lx_p0, const Text& q_p1) {
    auto&& _m = crate::prelude::get(prism_rtl::deref(lx_p0.g_p).vals_p, q_p1);
    if (prism_rtl::is_some(_m)) {
        auto&& v_p2 = prism_rtl::some_of(_m);
        return prism_rtl::deref(v_p2).home_p == Text::lit("Prelude");
    }
    if (prism_rtl::is_none(_m)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// IsColorPoly: fn Lx, Text -> Bool
bool is_color_poly_f(const crate::lower::Lx& lx_p0, const Text& q_p1) {
    auto&& _m = crate::prelude::get(prism_rtl::deref(lx_p0.g_p).vals_p, q_p1);
    if (prism_rtl::is_some(_m)) {
        auto&& v_p2 = prism_rtl::some_of(_m);
        auto&& _m = prism_rtl::deref(prism_rtl::deref(v_p2).scheme_p).ty_p;
        if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m) && prism_rtl::is<crate::check::types::Col::CQ>(prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a0)) {
            return true;
        }
        if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m) && prism_rtl::is<crate::check::types::Col::CRigid>(prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a0)) {
            return true;
        }
        {
            return false;
        }
    }
    if (prism_rtl::is_none(_m)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// EntersAtOnce: fn Lx, Text, [Arg] -> Bool
bool enters_at_once_f(const crate::lower::Lx& lx_p0, const Text& q_p1, const Array<crate::syntax::Arg>& args_p2) {
    return is_color_poly_f(lx_p0, q_p1) && (!crate::prelude::fold(args_p2, false, [&](const bool& seen_p3, const crate::syntax::Arg& a_p4) { return prism_rtl::deref(seen_p3) || is_unbounded_arg_f(lx_p0, a_p4); }));
}


/// IsUnboundedArg: fn Lx, Arg -> Bool
bool is_unbounded_arg_f(const crate::lower::Lx& lx_p0, const crate::syntax::Arg& a_p1) {
    auto&& _m = crate::lower::types::peel_f(crate::lower::type_at_f(lx_p0, prism_rtl::deref(a_p1.value_p).span_p));
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m) && prism_rtl::is<crate::check::types::Col::CUnbound>(prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a0)) {
        return true;
    }
    {
        return false;
    }
}


/// IsUnbounded: fn Lx, Text -> Bool
bool is_unbounded_f(const crate::lower::Lx& lx_p0, const Text& q_p1) {
    auto&& _m = crate::prelude::get(prism_rtl::deref(lx_p0.g_p).vals_p, q_p1);
    if (prism_rtl::is_some(_m)) {
        auto&& v_p2 = prism_rtl::some_of(_m);
        auto&& _m = prism_rtl::deref(prism_rtl::deref(v_p2).scheme_p).ty_p;
        if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m) && prism_rtl::is<crate::check::types::Col::CBound>(prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a0)) {
            return false;
        }
        if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
            return true;
        }
        {
            return false;
        }
    }
    if (prism_rtl::is_none(_m)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// RunTargets: unbounded fn Lx, Def -> [Text]
Array<Text> run_targets_f(const crate::lower::Lx& lx_p0, const crate::check::env::Def& d_p1) {
    auto es_p2 = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::syntax::Expr>> _v;
        auto&& _m = d_p1.body_p;
        if (prism_rtl::is<crate::check::env::DefBody::DbWidget>(_m)) {
            auto&& w_p3 = prism_rtl::as<crate::check::env::DefBody::DbWidget>(_m).a0;
            _v.set(crate::check::typed::print::block_exprs_f(prism_rtl::deref(w_p3).body_p));
            goto _done;
        }
        if (prism_rtl::is<crate::check::env::DefBody::DbFn>(_m)) {
            auto&& cs_p4 = prism_rtl::as<crate::check::env::DefBody::DbFn>(_m).a0;
            _v.set(crate::prelude::run_to_end(crate::prelude::fold_job(cs_p4, Array<crate::syntax::Expr>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::syntax::Expr>>(std::tuple<Array<crate::syntax::Expr>, crate::syntax::decls::FnClause>)>>(prism_rtl::rc([=](std::tuple<Array<crate::syntax::Expr>, crate::syntax::decls::FnClause> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return crate::prelude::entered(crate::prelude::once_job([=]() {
                    return ({
                        auto acc_p5 = p0;
                        auto c_p6 = p1;
                        (crate::prelude::call_then(crate::check::typed::print::start_body_exprs_f(prism_rtl::deref(c_p6).body_p), [=, acc_p5 = std::move(acc_p5)](Array<crate::syntax::Expr> body_exprs_f_19413) { return prism_rtl::finished(crate::prelude::append(acc_p5, body_exprs_f_19413)); }));
                    });
                }));
            })))));
            goto _done;
        }
        {
            _v.set(Array<crate::syntax::Expr>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    return crate::prelude::fold(es_p2, Array<Text>{}, [&](const Array<Text>& acc_p7, const crate::syntax::Expr& e_p8) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p8).kind_p);
            if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
                auto&& c_p9 = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
                auto&& args_pa = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
                _v.set(blueprint_qk_f(lx_p0, prism_rtl::deref(prism_rtl::deref(c_p9))) == Text::lit("Prelude.@Run")
                    ? ({
                    __label__ _done;
                    prism_rtl::Slot<Array<Text>> _v;
                    auto&& _m = crate::prelude::index(args_pa, Nat(0u));
                    if (prism_rtl::is_some(_m)) {
                        auto&& a_pb = prism_rtl::some_of(_m);
                        _v.set(({
                            __label__ _done;
                            prism_rtl::Slot<Array<Text>> _v;
                            auto&& _m = prism_rtl::deref(prism_rtl::deref(prism_rtl::deref(a_pb).value_p).kind_p);
                            if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
                                auto&& n_pc = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
                                _v.set(({
                                    auto&& _q_od = crate::check::env::names::resolve_value_f(lx_p0.g_p, lx_p0.home_p, n_pc);
                                    auto&& q_od = std::get<0>(_q_od);
                                    ({
                                    __label__ _done;
                                    prism_rtl::Slot<Array<Text>> _v;
                                    if (prism_rtl::is_some(q_od)) {
                                        auto&& q_pe = prism_rtl::some_of(q_od);
                                        _v.set(crate::check::types::add_text_f(acc_p7, q_pe));
                                        goto _done;
                                    }
                                    if (prism_rtl::is_none(q_od)) {
                                        _v.set(acc_p7);
                                        goto _done;
                                    }
                                    prism_rtl::unreachable("no arm matched");
                                _done:
                                    _v.take();
                                });
                                }));
                                goto _done;
                            }
                            {
                                _v.set(acc_p7);
                                goto _done;
                            }
                        _done:
                            _v.take();
                        }));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(acc_p7);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                })
                    : acc_p7);
                goto _done;
            }
            {
                _v.set(acc_p7);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


prism_rtl::Turn<Array<Text>> RunTargets::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& d_p1 = this->d_p1;
    auto es_p2 = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::syntax::Expr>> _v;
        auto&& _m = prism_rtl::deref(d_p1).body_p;
        if (prism_rtl::is<crate::check::env::DefBody::DbWidget>(_m)) {
            auto&& w_p3 = prism_rtl::as<crate::check::env::DefBody::DbWidget>(_m).a0;
            _v.set(crate::check::typed::print::block_exprs_f(prism_rtl::deref(w_p3).body_p));
            goto _done;
        }
        if (prism_rtl::is<crate::check::env::DefBody::DbFn>(_m)) {
            auto&& cs_p4 = prism_rtl::as<crate::check::env::DefBody::DbFn>(_m).a0;
            _v.set(crate::prelude::run_to_end(crate::prelude::fold_job(cs_p4, Array<crate::syntax::Expr>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::syntax::Expr>>(std::tuple<Array<crate::syntax::Expr>, crate::syntax::decls::FnClause>)>>(prism_rtl::rc([=](std::tuple<Array<crate::syntax::Expr>, crate::syntax::decls::FnClause> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return crate::prelude::entered(crate::prelude::once_job([=]() {
                    return ({
                        auto acc_p5 = p0;
                        auto c_p6 = p1;
                        (crate::prelude::call_then(crate::check::typed::print::start_body_exprs_f(prism_rtl::deref(c_p6).body_p), [=, acc_p5 = std::move(acc_p5)](Array<crate::syntax::Expr> body_exprs_f_19413) { return prism_rtl::finished(crate::prelude::append(acc_p5, body_exprs_f_19413)); }));
                    });
                }));
            })))));
            goto _done;
        }
        {
            _v.set(Array<crate::syntax::Expr>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    return prism_rtl::finished(crate::prelude::fold(es_p2, Array<Text>{}, [&](const Array<Text>& acc_p7, const crate::syntax::Expr& e_p8) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p8).kind_p);
            if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
                auto&& c_p9 = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
                auto&& args_pa = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
                _v.set(blueprint_qk_f(lx_p0, prism_rtl::deref(prism_rtl::deref(c_p9))) == Text::lit("Prelude.@Run")
                    ? ({
                    __label__ _done;
                    prism_rtl::Slot<Array<Text>> _v;
                    auto&& _m = crate::prelude::index(args_pa, Nat(0u));
                    if (prism_rtl::is_some(_m)) {
                        auto&& a_pb = prism_rtl::some_of(_m);
                        _v.set(({
                            __label__ _done;
                            prism_rtl::Slot<Array<Text>> _v;
                            auto&& _m = prism_rtl::deref(prism_rtl::deref(prism_rtl::deref(a_pb).value_p).kind_p);
                            if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
                                auto&& n_pc = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
                                _v.set(({
                                    auto&& _q_od = crate::check::env::names::resolve_value_f(prism_rtl::deref(lx_p0).g_p, prism_rtl::deref(lx_p0).home_p, n_pc);
                                    auto&& q_od = std::get<0>(_q_od);
                                    ({
                                    __label__ _done;
                                    prism_rtl::Slot<Array<Text>> _v;
                                    if (prism_rtl::is_some(q_od)) {
                                        auto&& q_pe = prism_rtl::some_of(q_od);
                                        _v.set(crate::check::types::add_text_f(acc_p7, q_pe));
                                        goto _done;
                                    }
                                    if (prism_rtl::is_none(q_od)) {
                                        _v.set(acc_p7);
                                        goto _done;
                                    }
                                    prism_rtl::unreachable("no arm matched");
                                _done:
                                    _v.take();
                                });
                                }));
                                goto _done;
                            }
                            {
                                _v.set(acc_p7);
                                goto _done;
                            }
                        _done:
                            _v.take();
                        }));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(acc_p7);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                })
                    : acc_p7);
                goto _done;
            }
            {
                _v.set(acc_p7);
                goto _done;
            }
        _done:
            _v.take();
        });
    }));
}


/// `Start RunTargets, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_run_targets_f(crate::lower::Lx lx_p0, crate::check::env::Def d_p1) {
    return prism_rtl::make_rc<RunTargets>(lx_p0, d_p1);
}


/// TailTargets: unbounded fn Lx, Text -> [Text]
Array<Text> tail_targets_f(const crate::lower::Lx& lx_p0, const Text& qk_p1) {
    auto v_p2 = crate::prelude::or_(crate::prelude::get(prism_rtl::deref(lx_p0.g_p).vals_p, qk_p1), crate::check::env::builtin_f(qk_p1, crate::check::types::schemes::mono_f(crate::check::types::Ty(crate::check::types::Ty::TyErr{}))));
    auto lxm_p3 = in_module_f(lx_p0, prism_rtl::deref(v_p2).file_p, prism_rtl::deref(v_p2).home_p);
    return crate::prelude::run_to_end(crate::prelude::fold_job(crate::lower::jobs::clauses_of_f(lx_p0.g_p, qk_p1), Array<Text>{}, ({
        auto lxm_p3x = lxm_p3;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::decls::FnClause>)>>(prism_rtl::rc([=, lxm_p3x = std::move(lxm_p3x)](std::tuple<Array<Text>, crate::syntax::decls::FnClause> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lxm_p3xy = lxm_p3x;
            (crate::prelude::entered(crate::prelude::once_job([=, lxm_p3xy = std::move(lxm_p3xy)]() {
            return ({
                auto acc_p4 = p0;
                auto c_p5 = p1;
                (crate::prelude::call_then(start_tails_of_body_f(lxm_p3xy, prism_rtl::deref(c_p5).body_p), [=, acc_p4 = std::move(acc_p4)](Array<Text> tails_of_body_f_20292) { return prism_rtl::finished(crate::check::types::union_texts_f(acc_p4, tails_of_body_f_20292)); }));
            });
        })));
        });
    })));
    })));
}


prism_rtl::Turn<Array<Text>> TailTargets::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& qk_p1 = this->qk_p1;
    auto v_p2 = crate::prelude::or_(crate::prelude::get(prism_rtl::deref(prism_rtl::deref(lx_p0).g_p).vals_p, qk_p1), crate::check::env::builtin_f(qk_p1, crate::check::types::schemes::mono_f(crate::check::types::Ty(crate::check::types::Ty::TyErr{}))));
    auto lxm_p3 = in_module_f(lx_p0, prism_rtl::deref(v_p2).file_p, prism_rtl::deref(v_p2).home_p);
    return crate::prelude::fold_job(crate::lower::jobs::clauses_of_f(prism_rtl::deref(lx_p0).g_p, qk_p1), Array<Text>{}, ({
        auto lxm_p3x = lxm_p3;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::decls::FnClause>)>>(prism_rtl::rc([=, lxm_p3x = std::move(lxm_p3x)](std::tuple<Array<Text>, crate::syntax::decls::FnClause> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lxm_p3xy = lxm_p3x;
            (crate::prelude::entered(crate::prelude::once_job([=, lxm_p3xy = std::move(lxm_p3xy)]() {
            return ({
                auto acc_p4 = p0;
                auto c_p5 = p1;
                (crate::prelude::call_then(start_tails_of_body_f(lxm_p3xy, prism_rtl::deref(c_p5).body_p), [=, acc_p4 = std::move(acc_p4)](Array<Text> tails_of_body_f_20292) { return prism_rtl::finished(crate::check::types::union_texts_f(acc_p4, tails_of_body_f_20292)); }));
            });
        })));
        });
    })));
    }))->cycle();
}


/// `Start TailTargets, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_tail_targets_f(crate::lower::Lx lx_p0, Text qk_p1) {
    return prism_rtl::make_rc<TailTargets>(lx_p0, qk_p1);
}


/// TailsOfBody: unbounded fn Lx, FnBody -> [Text]
Array<Text> tails_of_body_f(const crate::lower::Lx& lx_p0, const crate::syntax::decls::FnBody& body_p1) {
    return crate::prelude::fold(crate::check::typed::print::body_exprs_f(body_p1), Array<Text>{}, [&](const Array<Text>& acc_p2, const crate::syntax::Expr& e_p3) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p3).kind_p);
            if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
                auto&& c_p4 = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
                _v.set(({
                    auto q_p5 = blueprint_qk_f(lx_p0, prism_rtl::deref(prism_rtl::deref(c_p4)));
                    ({
                    __label__ _done;
                    prism_rtl::Slot<Array<Text>> _v;
                    auto&& _m = crate::prelude::get(prism_rtl::deref(lx_p0.g_p).vals_p, q_p5);
                    if (prism_rtl::is_some(_m)) {
                        auto&& v_p6 = prism_rtl::some_of(_m);
                        _v.set(({
                            __label__ _done;
                            prism_rtl::Slot<Array<Text>> _v;
                            auto&& _m = prism_rtl::deref(prism_rtl::deref(v_p6).scheme_p).ty_p;
                            if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m) && prism_rtl::is<crate::check::types::Col::CBound>(prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a0)) {
                                _v.set(acc_p2);
                                goto _done;
                            }
                            if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
                                _v.set(crate::check::types::add_text_f(acc_p2, q_p5));
                                goto _done;
                            }
                            {
                                _v.set(acc_p2);
                                goto _done;
                            }
                        _done:
                            _v.take();
                        }));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(acc_p2);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                }));
                goto _done;
            }
            {
                _v.set(acc_p2);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


prism_rtl::Turn<Array<Text>> TailsOfBody::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& body_p1 = this->body_p1;
    auto body_p1x = body_p1;
    auto lx_p0x = lx_p0;
    return crate::prelude::call_then(crate::check::typed::print::start_body_exprs_f(body_p1x), [=](Array<crate::syntax::Expr> body_exprs_f_20397) {
        return prism_rtl::finished(crate::prelude::fold(body_exprs_f_20397, Array<Text>{}, [&](const Array<Text>& acc_p2, const crate::syntax::Expr& e_p3) {
            return ({
                __label__ _done;
                prism_rtl::Slot<Array<Text>> _v;
                auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p3).kind_p);
                if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
                    auto&& c_p4 = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
                    _v.set(({
                        auto q_p5 = blueprint_qk_f(lx_p0x, prism_rtl::deref(prism_rtl::deref(c_p4)));
                        ({
                        __label__ _done;
                        prism_rtl::Slot<Array<Text>> _v;
                        auto&& _m = crate::prelude::get(prism_rtl::deref(prism_rtl::deref(lx_p0x).g_p).vals_p, q_p5);
                        if (prism_rtl::is_some(_m)) {
                            auto&& v_p6 = prism_rtl::some_of(_m);
                            _v.set(({
                                __label__ _done;
                                prism_rtl::Slot<Array<Text>> _v;
                                auto&& _m = prism_rtl::deref(prism_rtl::deref(v_p6).scheme_p).ty_p;
                                if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m) && prism_rtl::is<crate::check::types::Col::CBound>(prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a0)) {
                                    _v.set(acc_p2);
                                    goto _done;
                                }
                                if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
                                    _v.set(crate::check::types::add_text_f(acc_p2, q_p5));
                                    goto _done;
                                }
                                {
                                    _v.set(acc_p2);
                                    goto _done;
                                }
                            _done:
                                _v.take();
                            }));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(acc_p2);
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                    }));
                    goto _done;
                }
                {
                    _v.set(acc_p2);
                    goto _done;
                }
            _done:
                _v.take();
            });
        }));
    });
}


/// `Start TailsOfBody, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_tails_of_body_f(crate::lower::Lx lx_p0, crate::syntax::decls::FnBody body_p1) {
    return prism_rtl::make_rc<TailsOfBody>(lx_p0, body_p1);
}


/// ModDefOf: unbounded fn Lx, Text, [((Text, Bool))], ModInfo, [Text] -> ModDef
crate::lower::model::ModDef mod_def_of_f(const crate::lower::Lx& lx0_p0, const Text& m_p1, const Array<std::tuple<Text, bool>>& roots_p2, const crate::check::env::ModInfo& info_p3, const Array<Text>& mods_p4) {
    auto lx_p5 = in_module_f(lx0_p0, info_p3.file_p, m_p1);
    auto path_p6 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = crate::prelude::index(prism_rtl::deref(prism_rtl::deref(lx_p5).g_p).srcs_p, info_p3.file_p);
        if (prism_rtl::is_some(_m)) {
            auto&& src_pd = prism_rtl::some_of(_m);
            _v.set(prism_rtl::deref(src_pd).path_p);
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto types_p7 = crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::values(prism_rtl::deref(prism_rtl::deref(lx_p5).g_p).types_p), Array<crate::lower::model::Item>{}, ({
        auto m_p1x = m_p1;
        auto lx_p5x = lx_p5;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Item>>(std::tuple<Array<crate::lower::model::Item>, crate::check::env::TyInfo>)>>(prism_rtl::rc([=, m_p1x = std::move(m_p1x), lx_p5x = std::move(lx_p5x)](std::tuple<Array<crate::lower::model::Item>, crate::check::env::TyInfo> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto m_p1xy = m_p1x;
            auto lx_p5xy = lx_p5x;
            (crate::prelude::entered(crate::prelude::once_job([=, m_p1xy = std::move(m_p1xy), lx_p5xy = std::move(lx_p5xy)]() {
            return ({
                auto acc_pe = p0;
                auto ti_pf = p1;
                (prism_rtl::deref(ti_pf).home_p == m_p1xy
                ? crate::prelude::call_then(start_ty_defs_f(lx_p5xy, ti_pf), [=](Array<crate::lower::model::Item> ty_defs_f_21122) { return prism_rtl::finished(crate::prelude::append(acc_pe, ty_defs_f_21122)); })
                : prism_rtl::finished(acc_pe));
            });
        })));
        });
    })));
    })));
    auto tags_p8 = crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::values(prism_rtl::deref(prism_rtl::deref(lx_p5).g_p).tags_p), Array<crate::lower::model::Item>{}, ({
        auto m_p1x = m_p1;
        auto lx_p5x = lx_p5;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Item>>(std::tuple<Array<crate::lower::model::Item>, crate::check::env::TagInfo>)>>(prism_rtl::rc([=, m_p1x = std::move(m_p1x), lx_p5x = std::move(lx_p5x)](std::tuple<Array<crate::lower::model::Item>, crate::check::env::TagInfo> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto m_p1xy = m_p1x;
            auto lx_p5xy = lx_p5x;
            (crate::prelude::entered(crate::prelude::once_job([=, m_p1xy = std::move(m_p1xy), lx_p5xy = std::move(lx_p5xy)]() {
            return ({
                auto acc_pg = p0;
                auto tg_ph = p1;
                (prism_rtl::deref(tg_ph).home_p == m_p1xy) && (prism_rtl::deref(tg_ph).kind_p != Text::lit("Prelude.Fault"))
                ? crate::prelude::call_then(start_tag_def_of_f(lx_p5xy, tg_ph), [=](crate::lower::model::TagDef tag_def_of_f_21270) { return prism_rtl::finished(crate::prelude::push(acc_pg, crate::lower::model::Item(crate::lower::model::Item::ItTag{tag_def_of_f_21270}))); })
                : prism_rtl::finished(acc_pg);
            });
        })));
        });
    })));
    })));
    auto defs_p9 = crate::prelude::run_to_end(crate::prelude::fold_job(prism_rtl::deref(prism_rtl::deref(lx_p5).g_p).defs_p, Array<crate::lower::model::Item>{}, ({
        auto m_p1x = m_p1;
        auto lx_p5x = lx_p5;
        auto roots_p2x = roots_p2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Item>>(std::tuple<Array<crate::lower::model::Item>, crate::check::env::Def>)>>(prism_rtl::rc([=, m_p1x = std::move(m_p1x), lx_p5x = std::move(lx_p5x), roots_p2x = std::move(roots_p2x)](std::tuple<Array<crate::lower::model::Item>, crate::check::env::Def> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto m_p1xy = m_p1x;
            auto lx_p5xy = lx_p5x;
            auto roots_p2xy = roots_p2x;
            (crate::prelude::entered(crate::prelude::once_job([=, m_p1xy = std::move(m_p1xy), lx_p5xy = std::move(lx_p5xy), roots_p2xy = std::move(roots_p2xy)]() {
            return ({
                auto acc_pi = p0;
                auto d_pj = p1;
                (prism_rtl::deref(d_pj).home_p == m_p1xy
                ? crate::prelude::call_then(start_def_items_f(in_module_f(lx_p5xy, prism_rtl::deref(d_pj).file_p, m_p1xy), d_pj, roots_p2xy), [=](Array<crate::lower::model::Item> def_items_f_21374) { return prism_rtl::finished(crate::prelude::append(acc_pi, def_items_f_21374)); })
                : prism_rtl::finished(acc_pi));
            });
        })));
        });
    })));
    })));
    auto traits_pa = crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::values(prism_rtl::deref(prism_rtl::deref(lx_p5).g_p).traits_p), Array<crate::lower::model::Item>{}, ({
        auto m_p1x = m_p1;
        auto lx_p5x = lx_p5;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Item>>(std::tuple<Array<crate::lower::model::Item>, crate::check::env::TraitInfo>)>>(prism_rtl::rc([=, m_p1x = std::move(m_p1x), lx_p5x = std::move(lx_p5x)](std::tuple<Array<crate::lower::model::Item>, crate::check::env::TraitInfo> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto m_p1xy = m_p1x;
            auto lx_p5xy = lx_p5x;
            (crate::prelude::entered(crate::prelude::once_job([=, m_p1xy = std::move(m_p1xy), lx_p5xy = std::move(lx_p5xy)]() {
            return ({
                auto acc_pk = p0;
                auto tr_pl = p1;
                (prism_rtl::deref(tr_pl).home_p == m_p1xy
                ? crate::prelude::call_then(crate::lower::functions::start_trait_def_of_f(lx_p5xy, tr_pl), [=](crate::lower::model::TraitDef trait_def_of_f_21527) { return prism_rtl::finished(crate::prelude::push(acc_pk, crate::lower::model::Item(crate::lower::model::Item::ItTrait{trait_def_of_f_21527}))); })
                : prism_rtl::finished(acc_pk));
            });
        })));
        });
    })));
    })));
    auto impls_pb = crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::values(prism_rtl::deref(prism_rtl::deref(lx_p5).g_p).impls_p), Array<crate::lower::model::Item>{}, ({
        auto m_p1x = m_p1;
        auto lx_p5x = lx_p5;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Item>>(std::tuple<Array<crate::lower::model::Item>, Array<crate::check::env::ImplInfo>>)>>(prism_rtl::rc([=, m_p1x = std::move(m_p1x), lx_p5x = std::move(lx_p5x)](std::tuple<Array<crate::lower::model::Item>, Array<crate::check::env::ImplInfo>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto m_p1xy = m_p1x;
            auto lx_p5xy = lx_p5x;
            (crate::prelude::entered(crate::prelude::once_job([=, m_p1xy = std::move(m_p1xy), lx_p5xy = std::move(lx_p5xy)]() {
            return ({
                auto acc_pm = p0;
                auto ims_pn = p1;
                (crate::prelude::fold_job(ims_pn, acc_pm, ({
                auto m_p1xyx = m_p1xy;
                auto lx_p5xyx = lx_p5xy;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Item>>(std::tuple<Array<crate::lower::model::Item>, crate::check::env::ImplInfo>)>>(prism_rtl::rc([=, m_p1xyx = std::move(m_p1xyx), lx_p5xyx = std::move(lx_p5xyx)](std::tuple<Array<crate::lower::model::Item>, crate::check::env::ImplInfo> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto m_p1xyxy = m_p1xyx;
                    auto lx_p5xyxy = lx_p5xyx;
                    (crate::prelude::entered(crate::prelude::once_job([=, m_p1xyxy = std::move(m_p1xyxy), lx_p5xyxy = std::move(lx_p5xyxy)]() {
                    return ({
                        auto a_po = p0;
                        auto im_pp = p1;
                        (prism_rtl::deref(im_pp).home_p == m_p1xyxy) && (!prism_rtl::deref(im_pp).derived_p)
                        ? crate::prelude::call_then(crate::lower::functions::start_impl_def_of_f(in_module_f(lx_p5xyxy, prism_rtl::deref(im_pp).file_p, m_p1xyxy), im_pp), [=](crate::lower::model::ImplDef impl_def_of_f_21694) { return prism_rtl::finished(crate::prelude::push(a_po, crate::lower::model::Item(crate::lower::model::Item::ItImpl{impl_def_of_f_21694}))); })
                        : prism_rtl::finished(a_po);
                    });
                })));
                });
            })));
            }))->cycle());
            });
        })));
        });
    })));
    })));
    auto uses_pc = crate::prelude::filter(crate::prelude::each(mods_p4, [&](const Text& o_pq) { return crate::lower::rust_mod_name_f(o_pq); }), [&](const Text& o_pr) { return o_pr != crate::lower::rust_mod_name_f(m_p1); });
    return crate::lower::model::ModDef{.name_p = crate::lower::rust_mod_name_f(m_p1), .prism_p = m_p1, .path_p = path_p6, .uses_p = uses_pc, .complete_p = Array<Text>{}, .declared_p = Array<Text>{}, .types_with_p = Array<Text>{}, .items_p = crate::prelude::append(crate::prelude::append(crate::prelude::append(crate::prelude::append(types_p7, tags_p8), traits_pa), impls_pb), defs_p9)};
}


prism_rtl::Turn<crate::lower::model::ModDef> ModDefOf::cycle() const {
    const auto& lx0_p0 = this->lx0_p0;
    const auto& m_p1 = this->m_p1;
    const auto& roots_p2 = this->roots_p2;
    const auto& info_p3 = this->info_p3;
    const auto& mods_p4 = this->mods_p4;
    auto lx_p5 = in_module_f(lx0_p0, prism_rtl::deref(info_p3).file_p, m_p1);
    auto path_p6 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = crate::prelude::index(prism_rtl::deref(prism_rtl::deref(lx_p5).g_p).srcs_p, prism_rtl::deref(info_p3).file_p);
        if (prism_rtl::is_some(_m)) {
            auto&& src_pd = prism_rtl::some_of(_m);
            _v.set(prism_rtl::deref(src_pd).path_p);
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto m_p1x = m_p1;
    auto mods_p4x = mods_p4;
    auto roots_p2x = roots_p2;
    return crate::prelude::call_value(crate::prelude::fold_job(crate::prelude::values(prism_rtl::deref(prism_rtl::deref(lx_p5).g_p).types_p), Array<crate::lower::model::Item>{}, ({
        auto m_p1xx = m_p1x;
        auto lx_p5x = lx_p5;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Item>>(std::tuple<Array<crate::lower::model::Item>, crate::check::env::TyInfo>)>>(prism_rtl::rc([=, m_p1xx = std::move(m_p1xx), lx_p5x = std::move(lx_p5x)](std::tuple<Array<crate::lower::model::Item>, crate::check::env::TyInfo> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto m_p1xxy = m_p1xx;
            auto lx_p5xy = lx_p5x;
            (crate::prelude::entered(crate::prelude::once_job([=, m_p1xxy = std::move(m_p1xxy), lx_p5xy = std::move(lx_p5xy)]() {
            return ({
                auto acc_pe = p0;
                auto ti_pf = p1;
                (prism_rtl::deref(ti_pf).home_p == m_p1xxy
                ? crate::prelude::call_then(start_ty_defs_f(lx_p5xy, ti_pf), [=](Array<crate::lower::model::Item> ty_defs_f_21122) { return prism_rtl::finished(crate::prelude::append(acc_pe, ty_defs_f_21122)); })
                : prism_rtl::finished(acc_pe));
            });
        })));
        });
    })));
    })), [=](Array<crate::lower::model::Item> fold_21049) {
        return ({
            auto types_p7 = fold_21049;
            (crate::prelude::call_value(crate::prelude::fold_job(crate::prelude::values(prism_rtl::deref(prism_rtl::deref(lx_p5).g_p).tags_p), Array<crate::lower::model::Item>{}, ({
            auto m_p1xx = m_p1x;
            auto lx_p5x = lx_p5;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Item>>(std::tuple<Array<crate::lower::model::Item>, crate::check::env::TagInfo>)>>(prism_rtl::rc([=, m_p1xx = std::move(m_p1xx), lx_p5x = std::move(lx_p5x)](std::tuple<Array<crate::lower::model::Item>, crate::check::env::TagInfo> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto m_p1xxy = m_p1xx;
                auto lx_p5xy = lx_p5x;
                (crate::prelude::entered(crate::prelude::once_job([=, m_p1xxy = std::move(m_p1xxy), lx_p5xy = std::move(lx_p5xy)]() {
                return ({
                    auto acc_pg = p0;
                    auto tg_ph = p1;
                    (prism_rtl::deref(tg_ph).home_p == m_p1xxy) && (prism_rtl::deref(tg_ph).kind_p != Text::lit("Prelude.Fault"))
                    ? crate::prelude::call_then(start_tag_def_of_f(lx_p5xy, tg_ph), [=](crate::lower::model::TagDef tag_def_of_f_21270) { return prism_rtl::finished(crate::prelude::push(acc_pg, crate::lower::model::Item(crate::lower::model::Item::ItTag{tag_def_of_f_21270}))); })
                    : prism_rtl::finished(acc_pg);
                });
            })));
            });
        })));
        })), [=, types_p7 = std::move(types_p7)](Array<crate::lower::model::Item> fold_21162) {
            return ({
                auto tags_p8 = fold_21162;
                (crate::prelude::call_value(crate::prelude::fold_job(prism_rtl::deref(prism_rtl::deref(lx_p5).g_p).defs_p, Array<crate::lower::model::Item>{}, ({
                auto m_p1xx = m_p1x;
                auto lx_p5x = lx_p5;
                auto roots_p2xx = roots_p2x;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Item>>(std::tuple<Array<crate::lower::model::Item>, crate::check::env::Def>)>>(prism_rtl::rc([=, m_p1xx = std::move(m_p1xx), lx_p5x = std::move(lx_p5x), roots_p2xx = std::move(roots_p2xx)](std::tuple<Array<crate::lower::model::Item>, crate::check::env::Def> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto m_p1xxy = m_p1xx;
                    auto lx_p5xy = lx_p5x;
                    auto roots_p2xxy = roots_p2xx;
                    (crate::prelude::entered(crate::prelude::once_job([=, m_p1xxy = std::move(m_p1xxy), lx_p5xy = std::move(lx_p5xy), roots_p2xxy = std::move(roots_p2xxy)]() {
                    return ({
                        auto acc_pi = p0;
                        auto d_pj = p1;
                        (prism_rtl::deref(d_pj).home_p == m_p1xxy
                        ? crate::prelude::call_then(start_def_items_f(in_module_f(lx_p5xy, prism_rtl::deref(d_pj).file_p, m_p1xxy), d_pj, roots_p2xxy), [=](Array<crate::lower::model::Item> def_items_f_21374) { return prism_rtl::finished(crate::prelude::append(acc_pi, def_items_f_21374)); })
                        : prism_rtl::finished(acc_pi));
                    });
                })));
                });
            })));
            })), [=, tags_p8 = std::move(tags_p8)](Array<crate::lower::model::Item> fold_21313) {
                return ({
                    auto defs_p9 = fold_21313;
                    (crate::prelude::call_value(crate::prelude::fold_job(crate::prelude::values(prism_rtl::deref(prism_rtl::deref(lx_p5).g_p).traits_p), Array<crate::lower::model::Item>{}, ({
                    auto m_p1xx = m_p1x;
                    auto lx_p5x = lx_p5;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Item>>(std::tuple<Array<crate::lower::model::Item>, crate::check::env::TraitInfo>)>>(prism_rtl::rc([=, m_p1xx = std::move(m_p1xx), lx_p5x = std::move(lx_p5x)](std::tuple<Array<crate::lower::model::Item>, crate::check::env::TraitInfo> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto m_p1xxy = m_p1xx;
                        auto lx_p5xy = lx_p5x;
                        (crate::prelude::entered(crate::prelude::once_job([=, m_p1xxy = std::move(m_p1xxy), lx_p5xy = std::move(lx_p5xy)]() {
                        return ({
                            auto acc_pk = p0;
                            auto tr_pl = p1;
                            (prism_rtl::deref(tr_pl).home_p == m_p1xxy
                            ? crate::prelude::call_then(crate::lower::functions::start_trait_def_of_f(lx_p5xy, tr_pl), [=](crate::lower::model::TraitDef trait_def_of_f_21527) { return prism_rtl::finished(crate::prelude::push(acc_pk, crate::lower::model::Item(crate::lower::model::Item::ItTrait{trait_def_of_f_21527}))); })
                            : prism_rtl::finished(acc_pk));
                        });
                    })));
                    });
                })));
                })), [=, defs_p9 = std::move(defs_p9)](Array<crate::lower::model::Item> fold_21446) {
                    return ({
                        auto traits_pa = fold_21446;
                        (crate::prelude::call_value(crate::prelude::fold_job(crate::prelude::values(prism_rtl::deref(prism_rtl::deref(lx_p5).g_p).impls_p), Array<crate::lower::model::Item>{}, ({
                        auto m_p1xx = m_p1x;
                        auto lx_p5x = lx_p5;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Item>>(std::tuple<Array<crate::lower::model::Item>, Array<crate::check::env::ImplInfo>>)>>(prism_rtl::rc([=, m_p1xx = std::move(m_p1xx), lx_p5x = std::move(lx_p5x)](std::tuple<Array<crate::lower::model::Item>, Array<crate::check::env::ImplInfo>> _p0) {
                        auto&& p0 = std::get<0>(_p0);
                        auto&& p1 = std::get<1>(_p0);
                        return ({
                            auto m_p1xxy = m_p1xx;
                            auto lx_p5xy = lx_p5x;
                            (crate::prelude::entered(crate::prelude::once_job([=, m_p1xxy = std::move(m_p1xxy), lx_p5xy = std::move(lx_p5xy)]() {
                            return ({
                                auto acc_pm = p0;
                                auto ims_pn = p1;
                                (crate::prelude::fold_job(ims_pn, acc_pm, ({
                                auto m_p1xxyx = m_p1xxy;
                                auto lx_p5xyx = lx_p5xy;
                                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Item>>(std::tuple<Array<crate::lower::model::Item>, crate::check::env::ImplInfo>)>>(prism_rtl::rc([=, m_p1xxyx = std::move(m_p1xxyx), lx_p5xyx = std::move(lx_p5xyx)](std::tuple<Array<crate::lower::model::Item>, crate::check::env::ImplInfo> _p0) {
                                auto&& p0 = std::get<0>(_p0);
                                auto&& p1 = std::get<1>(_p0);
                                return ({
                                    auto m_p1xxyxy = m_p1xxyx;
                                    auto lx_p5xyxy = lx_p5xyx;
                                    (crate::prelude::entered(crate::prelude::once_job([=, m_p1xxyxy = std::move(m_p1xxyxy), lx_p5xyxy = std::move(lx_p5xyxy)]() {
                                    return ({
                                        auto a_po = p0;
                                        auto im_pp = p1;
                                        (prism_rtl::deref(im_pp).home_p == m_p1xxyxy) && (!prism_rtl::deref(im_pp).derived_p)
                                        ? crate::prelude::call_then(crate::lower::functions::start_impl_def_of_f(in_module_f(lx_p5xyxy, prism_rtl::deref(im_pp).file_p, m_p1xxyxy), im_pp), [=](crate::lower::model::ImplDef impl_def_of_f_21694) { return prism_rtl::finished(crate::prelude::push(a_po, crate::lower::model::Item(crate::lower::model::Item::ItImpl{impl_def_of_f_21694}))); })
                                        : prism_rtl::finished(a_po);
                                    });
                                })));
                                });
                            })));
                            }))->cycle());
                            });
                        })));
                        });
                    })));
                    })), [=, traits_pa = std::move(traits_pa)](Array<crate::lower::model::Item> fold_21573) {
                        return ({
                            auto impls_pb = fold_21573;
                            auto uses_pc = crate::prelude::filter(crate::prelude::each(mods_p4x, [&](const Text& o_pq) { return crate::lower::rust_mod_name_f(o_pq); }), [&](const Text& o_pr) { return o_pr != crate::lower::rust_mod_name_f(m_p1x); });
                            (prism_rtl::finished(crate::lower::model::ModDef{.name_p = crate::lower::rust_mod_name_f(m_p1x), .prism_p = m_p1x, .path_p = path_p6, .uses_p = uses_pc, .complete_p = Array<Text>{}, .declared_p = Array<Text>{}, .types_with_p = Array<Text>{}, .items_p = crate::prelude::append(crate::prelude::append(crate::prelude::append(crate::prelude::append(types_p7, tags_p8), traits_pa), impls_pb), defs_p9)}));
                        });
                    }));
                    });
                }));
                });
            }));
            });
        }));
        });
    });
}


/// `Start ModDefOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::ModDef> start_mod_def_of_f(crate::lower::Lx lx0_p0, Text m_p1, Array<std::tuple<Text, bool>> roots_p2, crate::check::env::ModInfo info_p3, Array<Text> mods_p4) {
    return prism_rtl::make_rc<ModDefOf>(lx0_p0, m_p1, roots_p2, info_p3, mods_p4);
}


/// DefItems: unbounded fn Lx, Def, [((Text, Bool))] -> [Item]
Array<crate::lower::model::Item> def_items_f(const crate::lower::Lx& lx_p0, const crate::check::env::Def& d_p1, const Array<std::tuple<Text, bool>>& roots_p2) {
    auto is_root_p3 = crate::check::types::has_text_f(crate::prelude::each(roots_p2, [&](const std::tuple<Text, bool>& _p0) {
        auto&& q_p4 = std::get<0>(_p0);
        return q_p4;
    }), d_p1.qk_p);
    auto&& _m = d_p1.body_p;
    if (prism_rtl::is<crate::check::env::DefBody::DbWidget>(_m)) {
        auto&& w_p5 = prism_rtl::as<crate::check::env::DefBody::DbWidget>(_m).a0;
        return std::move(is_root_p3)
            ? node_items_f(crate::lower::node_::def::node_def_of_f(lx_p0, d_p1.qk_p, Array<crate::syntax::Pattern_>{}, prism_rtl::deref(w_p5).body_p, prism_rtl::deref(crate::prelude::or_(crate::prelude::get(prism_rtl::deref(lx_p0.g_p).vals_p, d_p1.qk_p), crate::check::env::builtin_f(d_p1.qk_p, crate::check::types::schemes::mono_f(crate::check::types::Ty(crate::check::types::Ty::TyErr{}))))).scheme_p, true))
            : Array(std::vector{crate::lower::model::Item(crate::lower::model::Item::ItNote{prism_rtl::cat("`", d_p1.name_p, "` is inlined where it is applied.")})});
    }
    if (prism_rtl::is<crate::check::env::DefBody::DbFn>(_m)) {
        auto&& clauses_p6 = prism_rtl::as<crate::check::env::DefBody::DbFn>(_m).a0;
        auto&& _m = crate::prelude::get(prism_rtl::deref(lx_p0.g_p).vals_p, d_p1.qk_p);
        if (prism_rtl::is_none(_m)) {
            return Array<crate::lower::model::Item>{};
        }
        if (prism_rtl::is_some(_m)) {
            auto&& v_p7 = prism_rtl::some_of(_m);
            auto&& _m = prism_rtl::deref(prism_rtl::deref(v_p7).scheme_p).ty_p;
            if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
                auto&& m22612_0_2 = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a2;
                if (prism_rtl::is<crate::check::types::Ty::TyAt>(prism_rtl::deref(prism_rtl::deref(m22612_0_2)))) {
                    return !std::move(is_root_p3)
                        ? Array(std::vector{crate::lower::model::Item(crate::lower::model::Item::ItNote{prism_rtl::cat("`", d_p1.name_p, "` is inlined where it is applied.")})})
                        : ({
                        __label__ _done;
                        prism_rtl::Slot<Array<crate::lower::model::Item>> _v;
                        {
                            auto&& m22808_0 = clauses_p6;
                            if (m22808_0.size() == 1u) {
                                {
                                    auto&& _c1 = crate::prelude::index(m22808_0, Nat(0u));
                                    if (prism_rtl::is_some(_c1)) {
                                        auto&& c_p8 = prism_rtl::some_of(_c1);
                                        _v.set(({
                                            __label__ _done;
                                            prism_rtl::Slot<Array<crate::lower::model::Item>> _v;
                                            auto&& _m = prism_rtl::deref(c_p8).body_p;
                                            if (prism_rtl::is<crate::syntax::decls::FnBody::BodyBlock>(_m)) {
                                                auto&& b_p9 = prism_rtl::as<crate::syntax::decls::FnBody::BodyBlock>(_m).a0;
                                                _v.set(node_items_f(crate::lower::node_::def::node_def_of_f(lx_p0, d_p1.qk_p, prism_rtl::deref(c_p8).params_p, b_p9, prism_rtl::deref(v_p7).scheme_p, true)));
                                                goto _done;
                                            }
                                            {
                                                _v.set(Array(std::vector{crate::lower::model::Item(crate::lower::model::Item::ItRefused{prism_rtl::cat("`", d_p1.name_p, "`, a root widget whose body is one expression")})}));
                                                goto _done;
                                            }
                                        _done:
                                            _v.take();
                                        }));
                                        goto _done;
                                    }
                                }
                            }
                        }
                        {
                            _v.set(Array(std::vector{crate::lower::model::Item(crate::lower::model::Item::ItRefused{prism_rtl::cat("`", d_p1.name_p, "`, a root widget of several clauses")})}));
                            goto _done;
                        }
                    _done:
                        _v.take();
                    });
                }
            }
            {
                auto f_pa = crate::lower::model::Item(crate::lower::model::Item::ItFn{crate::lower::functions::fn_def_of_f(lx_p0, d_p1.qk_p, clauses_p6, prism_rtl::deref(v_p7).scheme_p)});
                return crate::check::types::has_text_f(lx_p0.unbs_p, d_p1.qk_p)
                    ? Array(std::vector{f_pa, crate::lower::model::Item(crate::lower::model::Item::ItJob{crate::lower::jobs::job_def_of_f(lx_p0, d_p1.qk_p, clauses_p6, prism_rtl::deref(v_p7).scheme_p)})})
                    : Array(std::vector{f_pa});
            }
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<crate::check::env::DefBody::DbLet>(_m)) {
        auto&& l_pb = prism_rtl::as<crate::check::env::DefBody::DbLet>(_m).a0;
        return Array(std::vector{crate::lower::model::Item(crate::lower::model::Item::ItFn{crate::lower::functions::let_getter_f(lx_p0, d_p1.qk_p, l_pb)})});
    }
    {
        return Array<crate::lower::model::Item>{};
    }
}


prism_rtl::Turn<Array<crate::lower::model::Item>> DefItems::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& d_p1 = this->d_p1;
    const auto& roots_p2 = this->roots_p2;
    auto is_root_p3 = crate::check::types::has_text_f(crate::prelude::each(roots_p2, [&](const std::tuple<Text, bool>& _p0) {
        auto&& q_p4 = std::get<0>(_p0);
        return q_p4;
    }), prism_rtl::deref(d_p1).qk_p);
    return ({
        auto&& _m = prism_rtl::deref(d_p1).body_p;
        prism_rtl::is<crate::check::env::DefBody::DbWidget>(_m) ? ({
        auto&& w_p5 = prism_rtl::as<crate::check::env::DefBody::DbWidget>(_m).a0;
        std::move(is_root_p3)
        ? ({
        auto d_p1x = d_p1;
        auto lx_p0x = lx_p0;
        auto w_p5x = w_p5;
        (crate::prelude::call_then(crate::lower::node_::def::start_node_def_of_f(lx_p0x, prism_rtl::deref(d_p1x).qk_p, Array<crate::syntax::Pattern_>{}, prism_rtl::deref(w_p5x).body_p, prism_rtl::deref(crate::prelude::or_(crate::prelude::get(prism_rtl::deref(prism_rtl::deref(lx_p0x).g_p).vals_p, prism_rtl::deref(d_p1x).qk_p), crate::check::env::builtin_f(prism_rtl::deref(d_p1x).qk_p, crate::check::types::schemes::mono_f(crate::check::types::Ty(crate::check::types::Ty::TyErr{}))))).scheme_p, true), [=](crate::lower::model::NodeDef node_def_of_f_22355) { return prism_rtl::finished(node_items_f(node_def_of_f_22355)); }));
    })
        : prism_rtl::finished(Array(std::vector{crate::lower::model::Item(crate::lower::model::Item::ItNote{prism_rtl::cat("`", prism_rtl::deref(d_p1).name_p, "` is inlined where it is applied.")})}));
    })
        : prism_rtl::is<crate::check::env::DefBody::DbFn>(_m) ? ({
        auto&& clauses_p6 = prism_rtl::as<crate::check::env::DefBody::DbFn>(_m).a0;
        ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(prism_rtl::deref(lx_p0).g_p).vals_p, prism_rtl::deref(d_p1).qk_p);
        prism_rtl::is_none(_m) ? prism_rtl::finished(Array<crate::lower::model::Item>{})
        : prism_rtl::is_some(_m) ? ({
        auto&& v_p7 = prism_rtl::some_of(_m);
        ({
        auto&& _m = prism_rtl::deref(prism_rtl::deref(v_p7).scheme_p).ty_p;
        prism_rtl::is<crate::check::types::Ty::TyFn>(_m) && ({
        auto&& m22612_0_2 = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a2;
        prism_rtl::is<crate::check::types::Ty::TyAt>(prism_rtl::deref(prism_rtl::deref(m22612_0_2)));
    }) ? ({
        auto&& m22612_0_2 = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a2;
        !std::move(is_root_p3)
        ? prism_rtl::finished(Array(std::vector{crate::lower::model::Item(crate::lower::model::Item::ItNote{prism_rtl::cat("`", prism_rtl::deref(d_p1).name_p, "` is inlined where it is applied.")})}))
        : ({
        ({
        auto&& m22808_0 = clauses_p6;
        (m22808_0.size() == 1u) && ({
        auto&& _c1 = crate::prelude::index(m22808_0, Nat(0u));
        prism_rtl::is_some(_c1);
    });
    }) ? ({
        auto&& m22808_0 = clauses_p6;
        auto&& _c1 = crate::prelude::index(m22808_0, Nat(0u));
        auto&& c_p8 = prism_rtl::some_of(_c1);
        ({
        auto&& _m = prism_rtl::deref(c_p8).body_p;
        prism_rtl::is<crate::syntax::decls::FnBody::BodyBlock>(_m) ? ({
        auto&& b_p9 = prism_rtl::as<crate::syntax::decls::FnBody::BodyBlock>(_m).a0;
        ({
        auto b_p9x = b_p9;
        auto d_p1x = d_p1;
        auto lx_p0x = lx_p0;
        (crate::prelude::call_then(crate::lower::node_::def::start_node_def_of_f(lx_p0x, prism_rtl::deref(d_p1x).qk_p, prism_rtl::deref(c_p8).params_p, b_p9x, prism_rtl::deref(v_p7).scheme_p, true), [=](crate::lower::model::NodeDef node_def_of_f_22920) { return prism_rtl::finished(node_items_f(node_def_of_f_22920)); }));
    });
    })
        : prism_rtl::finished(Array(std::vector{crate::lower::model::Item(crate::lower::model::Item::ItRefused{prism_rtl::cat("`", prism_rtl::deref(d_p1).name_p, "`, a root widget whose body is one expression")})}));
    });
    })
        : prism_rtl::finished(Array(std::vector{crate::lower::model::Item(crate::lower::model::Item::ItRefused{prism_rtl::cat("`", prism_rtl::deref(d_p1).name_p, "`, a root widget of several clauses")})}));
    });
    })
        : ({
        auto clauses_p6x = clauses_p6;
        auto d_p1x = d_p1;
        auto lx_p0x = lx_p0;
        (crate::prelude::call_then(crate::lower::functions::start_fn_def_of_f(lx_p0x, prism_rtl::deref(d_p1x).qk_p, clauses_p6x, prism_rtl::deref(v_p7).scheme_p), [=](crate::lower::model::FnDef fn_def_of_f_23236) {
        return ({
            auto f_pa = crate::lower::model::Item(crate::lower::model::Item::ItFn{fn_def_of_f_23236});
            (crate::check::types::has_text_f(prism_rtl::deref(lx_p0x).unbs_p, prism_rtl::deref(d_p1x).qk_p)
            ? crate::prelude::call_then(crate::lower::jobs::start_job_def_of_f(lx_p0x, prism_rtl::deref(d_p1x).qk_p, clauses_p6x, prism_rtl::deref(v_p7).scheme_p), [=](crate::lower::model::JobDef job_def_of_f_23331) { return prism_rtl::finished(Array(std::vector{f_pa, crate::lower::model::Item(crate::lower::model::Item::ItJob{job_def_of_f_23331})})); })
            : prism_rtl::finished(Array(std::vector{f_pa})));
        });
    }));
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : prism_rtl::is<crate::check::env::DefBody::DbLet>(_m) ? ({
        auto&& l_pb = prism_rtl::as<crate::check::env::DefBody::DbLet>(_m).a0;
        ({
        auto d_p1x = d_p1;
        auto l_pbx = l_pb;
        auto lx_p0x = lx_p0;
        (crate::prelude::call_then(crate::lower::functions::start_let_getter_f(lx_p0x, prism_rtl::deref(d_p1x).qk_p, l_pbx), [=](crate::lower::model::FnDef let_getter_f_23408) { return prism_rtl::finished(Array(std::vector{crate::lower::model::Item(crate::lower::model::Item::ItFn{let_getter_f_23408})})); }));
    });
    })
        : prism_rtl::finished(Array<crate::lower::model::Item>{});
    });
}


/// `Start DefItems, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::lower::model::Item>> start_def_items_f(crate::lower::Lx lx_p0, crate::check::env::Def d_p1, Array<std::tuple<Text, bool>> roots_p2) {
    return prism_rtl::make_rc<DefItems>(lx_p0, d_p1, roots_p2);
}


/// NodeItems: fn NodeDef -> [Item]
Array<crate::lower::model::Item> node_items_f(const crate::lower::model::NodeDef& n_p0) {
    return crate::prelude::append(Array(std::vector{crate::lower::model::Item(crate::lower::model::Item::ItNode{n_p0})}), crate::prelude::each(n_p0.children_p, [&](const crate::lower::model::NodeDef& c_p1) { return crate::lower::model::Item(crate::lower::model::Item::ItNode{c_p1}); }));
}


/// TyDefs: unbounded fn Lx, TyInfo -> [Item]
Array<crate::lower::model::Item> ty_defs_f(const crate::lower::Lx& lx_p0, const crate::check::env::TyInfo& ti_p1) {
    auto derives_p2 = crate::prelude::fold(ti_p1.derives_p, Array<Text>{}, [&](const Array<Text>& acc_p6, const Text& dn_p7) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = crate::check::env::names::resolve_trait_o(lx_p0.g_p, ti_p1.home_p, crate::prelude::split_on(dn_p7, Text::lit(".")));
            if (prism_rtl::is_some(_m)) {
                auto&& cls_p8 = prism_rtl::some_of(_m);
                _v.set(crate::prelude::push(acc_p6, cls_p8));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(acc_p6);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
    auto params_p3 = crate::prelude::each(ti_p1.params_p, [&](const Text& p_p9) { return crate::lower::camel_f(p_p9); });
    auto bare_p4 = crate::check::types::bare_name_f(ti_p1.name_p);
    auto mk_f5 = ({
        auto bare_p4x = bare_p4;
        auto params_p3x = params_p3;
        auto derives_p2x = derives_p2;
        auto lx_p0x = lx_p0;
        auto ti_p1x = ti_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::TyDef>(std::tuple<crate::lower::model::TyShape, Array<crate::lower::model::CaseDef>>)>>(prism_rtl::rc([=, bare_p4x = std::move(bare_p4x), params_p3x = std::move(params_p3x), derives_p2x = std::move(derives_p2x), lx_p0x = std::move(lx_p0x), ti_p1x = std::move(ti_p1x)](std::tuple<crate::lower::model::TyShape, Array<crate::lower::model::CaseDef>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto bare_p4xy = bare_p4x;
            auto params_p3xy = params_p3x;
            auto derives_p2xy = derives_p2x;
            auto lx_p0xy = lx_p0x;
            auto ti_p1xy = ti_p1x;
            (crate::prelude::entered(crate::prelude::once_job([=, bare_p4xy = std::move(bare_p4xy), params_p3xy = std::move(params_p3xy), derives_p2xy = std::move(derives_p2xy), lx_p0xy = std::move(lx_p0xy), ti_p1xy = std::move(ti_p1xy)]() {
            return ({
                auto shape_pa = p0;
                auto cases_pb = p1;
                (crate::prelude::call_then(start_ty_podable_f(lx_p0xy, crate::check::types::Ty(crate::check::types::Ty::TyCon{prism_rtl::deref(ti_p1xy).name_p, Array<crate::check::types::Ty>{}}), Array<Text>{}), [=, shape_pa = std::move(shape_pa), cases_pb = std::move(cases_pb)](bool ty_podable_f_24340) {
                return prism_rtl::finished(crate::lower::model::TyDef{.name_p = crate::lower::camel_f(bare_p4xy), .prism_p = bare_p4xy, .params_p = params_p3xy, .shape_p = shape_pa, .cases_p = cases_pb, .eq_p = crate::check::types::has_text_f(derives_p2xy, Text::lit("Prelude.Eq")), .ord_p = crate::check::types::has_text_f(derives_p2xy, Text::lit("Prelude.Ord")), .show_p = crate::lower::functions::has_own_show_f(lx_p0xy, prism_rtl::deref(ti_p1xy).name_p)
                    ? crate::lower::model::Shown(crate::lower::model::Shown::ShownOwn{})
                    : crate::check::types::has_text_f(derives_p2xy, Text::lit("Prelude.Show"))
                    ? crate::lower::model::Shown(crate::lower::model::Shown::ShownDerived{})
                    : crate::lower::model::Shown(crate::lower::model::Shown::NotShown{}), .pod_p = ty_podable_f_24340 && crate::prelude::run_to_end(crate::prelude::fold_job(cases_pb, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::CaseDef>)>>(prism_rtl::rc([=](std::tuple<bool, crate::lower::model::CaseDef> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return crate::prelude::entered(crate::prelude::once_job([=]() {
                        return ({
                            auto ok_pc = p0;
                            auto c_pd = p1;
                            (prism_rtl::finished(std::move(ok_pc) && crate::prelude::run_to_end(crate::prelude::fold_job(prism_rtl::deref(c_pd).fields_p, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, crate::lower::model::OutTy>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<Text, crate::lower::model::OutTy>> _p0) {
                            auto&& p0 = std::get<0>(_p0);
                            auto&& p1 = std::get<1>(_p0);
                            return crate::prelude::entered(crate::prelude::once_job([=]() {
                                return ({
                                    auto ok2_pe = p0;
                                    auto&& _ft_pf = p1;
                                    auto&& ft_pf = std::get<1>(_ft_pf);
                                    (prism_rtl::finished(std::move(ok2_pe) && crate::lower::types::podable_f(ft_pf)));
                                });
                            }));
                        }))))));
                        });
                    }));
                })))), .doc_p = type_doc_f(lx_p0xy, ti_p1xy)});
            }));
            });
        })));
        });
    })));
    });
    auto&& _m = ti_p1.body_p;
    if (prism_rtl::is<crate::check::env::TyBody::BRecord>(_m)) {
        auto&& fs_pg = prism_rtl::as<crate::check::env::TyBody::BRecord>(_m).a0;
        auto fields_ph = crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(crate::prelude::len(fs_pg)), ({
            auto fs_pgx = fs_pg;
            auto lx_p0x = lx_p0;
            auto ti_p1x = ti_p1;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, crate::lower::model::OutTy>>(Nat)>>(prism_rtl::rc([=, fs_pgx = std::move(fs_pgx), lx_p0x = std::move(lx_p0x), ti_p1x = std::move(ti_p1x)](Nat p0) {
            return ({
                auto fs_pgxy = fs_pgx;
                auto lx_p0xy = lx_p0x;
                auto ti_p1xy = ti_p1x;
                (crate::prelude::entered(crate::prelude::once_job([=, fs_pgxy = std::move(fs_pgxy), lx_p0xy = std::move(lx_p0xy), ti_p1xy = std::move(ti_p1xy)]() {
                return ({
                    auto i_pi = p0;
                    ({
                    auto [fname_pk, ft_pl] = crate::prelude::or_(crate::prelude::index(fs_pgxy, i_pi), std::tuple{Text::lit(""), crate::check::types::Ty(crate::check::types::Ty::TyErr{})});
                    (crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0xy, ft_pl), [=](crate::lower::model::OutTy out_ty_of_f_24686) {
                    return ({
                        auto rt_pj = out_ty_of_f_24686;
                        (crate::prelude::call_then(crate::lower::start_field_spell_f(prism_rtl::deref(ti_p1xy).home_p, fname_pk, ft_pl), [=, rt_pj = std::move(rt_pj)](Text field_spell_f_24720) {
                        return prism_rtl::finished(std::tuple{field_spell_f_24720, crate::lower::types::rc_field_f(lx_p0xy, prism_rtl::deref(ti_p1xy).name_p, i_pi)
                            ? crate::lower::model::OutTy(crate::lower::model::OutTy::OutRc{prism_rtl::rc(rt_pj)})
                            : rt_pj});
                    }));
                    });
                }));
                });
                });
            })));
            });
        }));
        })));
        return Array(std::vector{crate::lower::model::Item(crate::lower::model::Item::ItType{crate::prelude::run_to_end(mk_f5(std::tuple{crate::lower::model::TyShape(crate::lower::model::TyShape::ShapeRecord{}), Array(std::vector{crate::lower::model::CaseDef{.name_p = crate::lower::camel_f(bare_p4), .prism_p = bare_p4, .fields_p = fields_ph, .labels_p = crate::prelude::each(fs_pg, [&](const std::tuple<Text, crate::check::types::Ty>& _p0) {
            auto&& fname_pm = std::get<0>(_p0);
            return fname_pm;
        })}})}))})});
    }
    if (prism_rtl::is<crate::check::env::TyBody::BChoice>(_m)) {
        auto&& cases_pn = prism_rtl::as<crate::check::env::TyBody::BChoice>(_m).a0;
        auto defs_po = crate::prelude::run_to_end(crate::prelude::each_job(cases_pn, ({
            auto ti_p1x = ti_p1;
            auto lx_p0x = lx_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::CaseDef>(std::tuple<Text, Array<crate::check::types::Ty>>)>>(prism_rtl::rc([=, ti_p1x = std::move(ti_p1x), lx_p0x = std::move(lx_p0x)](std::tuple<Text, Array<crate::check::types::Ty>> p0) {
            return ({
                auto ti_p1xy = ti_p1x;
                auto lx_p0xy = lx_p0x;
                (crate::prelude::entered(crate::prelude::once_job([=, ti_p1xy = std::move(ti_p1xy), lx_p0xy = std::move(lx_p0xy)]() {
                return ({
                    auto [cn_pq, ats_pr] = p0;
                    ({
                    auto ck_ps = crate::check::env::qual_key_f(prism_rtl::deref(ti_p1xy).home_p, cn_pq);
                    (crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(crate::prelude::len(ats_pr)), ({
                    auto lx_p0xyx = lx_p0xy;
                    auto ck_psx = ck_ps;
                    auto ats_prx = ats_pr;
                    static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, crate::lower::model::OutTy>>(Nat)>>(prism_rtl::rc([=, lx_p0xyx = std::move(lx_p0xyx), ck_psx = std::move(ck_psx), ats_prx = std::move(ats_prx)](Nat p0) {
                    return ({
                        auto lx_p0xyxy = lx_p0xyx;
                        auto ck_psxy = ck_psx;
                        auto ats_prxy = ats_prx;
                        (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xyxy = std::move(lx_p0xyxy), ck_psxy = std::move(ck_psxy), ats_prxy = std::move(ats_prxy)]() {
                        return ({
                            auto i_pt = p0;
                            (crate::prelude::call_then(start_case_field_f(lx_p0xyxy, ck_psxy, i_pt, crate::prelude::or_(crate::prelude::index(ats_prxy, i_pt), crate::check::types::Ty(crate::check::types::Ty::TyErr{}))), [=](crate::lower::model::OutTy case_field_f_25160) { return prism_rtl::finished(std::tuple{Text::lit(""), case_field_f_25160}); }));
                        });
                    })));
                    });
                }));
                })), [=](Array<std::tuple<Text, crate::lower::model::OutTy>> each_25123) { return prism_rtl::finished(crate::lower::model::CaseDef{.name_p = crate::lower::camel_f(cn_pq), .prism_p = cn_pq, .fields_p = each_25123, .labels_p = Array<Text>{}}); }));
                });
                });
            })));
            });
        })));
        })));
        auto shape_pp = ({
            __label__ _done;
            prism_rtl::Slot<crate::lower::model::TyShape> _v;
            {
                auto&& m25242_0 = cases_pn;
                if (m25242_0.size() == 1u) {
                    {
                        auto&& _c2 = crate::prelude::index(m25242_0, Nat(0u));
                        if (prism_rtl::is_some(_c2)) {
                            auto&& cn_pu = std::get<0>(prism_rtl::some_of(_c2));
                            auto&& m25242_0_0_1 = std::get<1>(prism_rtl::some_of(_c2));
                            if (m25242_0_0_1.size() == 0u) {
                                _v.set(crate::check::env::is_lower_text_f(cn_pu)
                                    ? crate::lower::model::TyShape(crate::lower::model::TyShape::ShapeUnit{})
                                    : crate::lower::model::TyShape(crate::lower::model::TyShape::ShapeChoice{}));
                                goto _done;
                            }
                        }
                    }
                }
            }
            {
                auto&& m25242_1 = cases_pn;
                if (m25242_1.size() == 1u) {
                    {
                        auto&& _c1 = crate::prelude::index(m25242_1, Nat(0u));
                        if (prism_rtl::is_some(_c1)) {
                            auto&& cn_pv = std::get<0>(prism_rtl::some_of(_c1));
                            _v.set(cn_pv == bare_p4
                                ? crate::lower::model::TyShape(crate::lower::model::TyShape::ShapeNewtype{})
                                : crate::lower::model::TyShape(crate::lower::model::TyShape::ShapeChoice{}));
                            goto _done;
                        }
                    }
                }
            }
            {
                _v.set(crate::lower::model::TyShape(crate::lower::model::TyShape::ShapeChoice{}));
                goto _done;
            }
        _done:
            _v.take();
        });
        return Array(std::vector{crate::lower::model::Item(crate::lower::model::Item::ItType{crate::prelude::run_to_end(mk_f5(std::tuple{shape_pp, defs_po}))})});
    }
    if (prism_rtl::is<crate::check::env::TyBody::BRowKind>(_m)) {
        return ti_p1.name_p == Text::lit("Prelude.Fault")
            ? Array<crate::lower::model::Item>{}
            : Array(std::vector{crate::lower::model::Item(crate::lower::model::Item::ItRow{row_def_of_f(lx_p0, ti_p1)})});
    }
    {
        return Array<crate::lower::model::Item>{};
    }
}


prism_rtl::Turn<Array<crate::lower::model::Item>> TyDefs::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& ti_p1 = this->ti_p1;
    auto derives_p2 = crate::prelude::fold(prism_rtl::deref(ti_p1).derives_p, Array<Text>{}, [&](const Array<Text>& acc_p6, const Text& dn_p7) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = crate::check::env::names::resolve_trait_o(prism_rtl::deref(lx_p0).g_p, prism_rtl::deref(ti_p1).home_p, crate::prelude::split_on(dn_p7, Text::lit(".")));
            if (prism_rtl::is_some(_m)) {
                auto&& cls_p8 = prism_rtl::some_of(_m);
                _v.set(crate::prelude::push(acc_p6, cls_p8));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(acc_p6);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
    auto params_p3 = crate::prelude::each(prism_rtl::deref(ti_p1).params_p, [&](const Text& p_p9) { return crate::lower::camel_f(p_p9); });
    auto bare_p4 = crate::check::types::bare_name_f(prism_rtl::deref(ti_p1).name_p);
    auto mk_f5 = ({
        auto bare_p4x = bare_p4;
        auto params_p3x = params_p3;
        auto derives_p2x = derives_p2;
        auto lx_p0x = lx_p0;
        auto ti_p1x = ti_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::TyDef>(std::tuple<crate::lower::model::TyShape, Array<crate::lower::model::CaseDef>>)>>(prism_rtl::rc([=, bare_p4x = std::move(bare_p4x), params_p3x = std::move(params_p3x), derives_p2x = std::move(derives_p2x), lx_p0x = std::move(lx_p0x), ti_p1x = std::move(ti_p1x)](std::tuple<crate::lower::model::TyShape, Array<crate::lower::model::CaseDef>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto bare_p4xy = bare_p4x;
            auto params_p3xy = params_p3x;
            auto derives_p2xy = derives_p2x;
            auto lx_p0xy = lx_p0x;
            auto ti_p1xy = ti_p1x;
            (crate::prelude::entered(crate::prelude::once_job([=, bare_p4xy = std::move(bare_p4xy), params_p3xy = std::move(params_p3xy), derives_p2xy = std::move(derives_p2xy), lx_p0xy = std::move(lx_p0xy), ti_p1xy = std::move(ti_p1xy)]() {
            return ({
                auto shape_pa = p0;
                auto cases_pb = p1;
                (crate::prelude::call_then(start_ty_podable_f(lx_p0xy, crate::check::types::Ty(crate::check::types::Ty::TyCon{prism_rtl::deref(ti_p1xy).name_p, Array<crate::check::types::Ty>{}}), Array<Text>{}), [=, shape_pa = std::move(shape_pa), cases_pb = std::move(cases_pb)](bool ty_podable_f_24340) {
                return prism_rtl::finished(crate::lower::model::TyDef{.name_p = crate::lower::camel_f(bare_p4xy), .prism_p = bare_p4xy, .params_p = params_p3xy, .shape_p = shape_pa, .cases_p = cases_pb, .eq_p = crate::check::types::has_text_f(derives_p2xy, Text::lit("Prelude.Eq")), .ord_p = crate::check::types::has_text_f(derives_p2xy, Text::lit("Prelude.Ord")), .show_p = crate::lower::functions::has_own_show_f(lx_p0xy, prism_rtl::deref(ti_p1xy).name_p)
                    ? crate::lower::model::Shown(crate::lower::model::Shown::ShownOwn{})
                    : crate::check::types::has_text_f(derives_p2xy, Text::lit("Prelude.Show"))
                    ? crate::lower::model::Shown(crate::lower::model::Shown::ShownDerived{})
                    : crate::lower::model::Shown(crate::lower::model::Shown::NotShown{}), .pod_p = ty_podable_f_24340 && crate::prelude::run_to_end(crate::prelude::fold_job(cases_pb, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::CaseDef>)>>(prism_rtl::rc([=](std::tuple<bool, crate::lower::model::CaseDef> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return crate::prelude::entered(crate::prelude::once_job([=]() {
                        return ({
                            auto ok_pc = p0;
                            auto c_pd = p1;
                            (prism_rtl::finished(std::move(ok_pc) && crate::prelude::run_to_end(crate::prelude::fold_job(prism_rtl::deref(c_pd).fields_p, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, crate::lower::model::OutTy>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<Text, crate::lower::model::OutTy>> _p0) {
                            auto&& p0 = std::get<0>(_p0);
                            auto&& p1 = std::get<1>(_p0);
                            return crate::prelude::entered(crate::prelude::once_job([=]() {
                                return ({
                                    auto ok2_pe = p0;
                                    auto&& _ft_pf = p1;
                                    auto&& ft_pf = std::get<1>(_ft_pf);
                                    (prism_rtl::finished(std::move(ok2_pe) && crate::lower::types::podable_f(ft_pf)));
                                });
                            }));
                        }))))));
                        });
                    }));
                })))), .doc_p = type_doc_f(lx_p0xy, ti_p1xy)});
            }));
            });
        })));
        });
    })));
    });
    return ({
        auto&& _m = prism_rtl::deref(ti_p1).body_p;
        prism_rtl::is<crate::check::env::TyBody::BRecord>(_m) ? ({
        auto&& fs_pg = prism_rtl::as<crate::check::env::TyBody::BRecord>(_m).a0;
        ({
        auto fs_pgx = fs_pg;
        auto lx_p0x = lx_p0;
        auto ti_p1x = ti_p1;
        (crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(crate::prelude::len(fs_pgx)), ({
        auto fs_pgxx = fs_pgx;
        auto lx_p0xx = lx_p0x;
        auto ti_p1xx = ti_p1x;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, crate::lower::model::OutTy>>(Nat)>>(prism_rtl::rc([=, fs_pgxx = std::move(fs_pgxx), lx_p0xx = std::move(lx_p0xx), ti_p1xx = std::move(ti_p1xx)](Nat p0) {
        return ({
            auto fs_pgxxy = fs_pgxx;
            auto lx_p0xxy = lx_p0xx;
            auto ti_p1xxy = ti_p1xx;
            (crate::prelude::entered(crate::prelude::once_job([=, fs_pgxxy = std::move(fs_pgxxy), lx_p0xxy = std::move(lx_p0xxy), ti_p1xxy = std::move(ti_p1xxy)]() {
            return ({
                auto i_pi = p0;
                ({
                auto [fname_pk, ft_pl] = crate::prelude::or_(crate::prelude::index(fs_pgxxy, i_pi), std::tuple{Text::lit(""), crate::check::types::Ty(crate::check::types::Ty::TyErr{})});
                (crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0xxy, ft_pl), [=](crate::lower::model::OutTy out_ty_of_f_24686) {
                return ({
                    auto rt_pj = out_ty_of_f_24686;
                    (crate::prelude::call_then(crate::lower::start_field_spell_f(prism_rtl::deref(ti_p1xxy).home_p, fname_pk, ft_pl), [=, rt_pj = std::move(rt_pj)](Text field_spell_f_24720) {
                    return prism_rtl::finished(std::tuple{field_spell_f_24720, crate::lower::types::rc_field_f(lx_p0xxy, prism_rtl::deref(ti_p1xxy).name_p, i_pi)
                        ? crate::lower::model::OutTy(crate::lower::model::OutTy::OutRc{prism_rtl::rc(rt_pj)})
                        : rt_pj});
                }));
                });
            }));
            });
            });
        })));
        });
    }));
    })), [=](Array<std::tuple<Text, crate::lower::model::OutTy>> each_24572) {
        return ({
            auto fields_ph = each_24572;
            (crate::prelude::call_value(mk_f5(std::tuple{crate::lower::model::TyShape(crate::lower::model::TyShape::ShapeRecord{}), Array(std::vector{crate::lower::model::CaseDef{.name_p = crate::lower::camel_f(bare_p4), .prism_p = bare_p4, .fields_p = fields_ph, .labels_p = crate::prelude::each(fs_pgx, [&](const std::tuple<Text, crate::check::types::Ty>& _p0) {
            auto&& fname_pm = std::get<0>(_p0);
            return fname_pm;
        })}})}), [=](crate::lower::model::TyDef mk_24823) { return prism_rtl::finished(Array(std::vector{crate::lower::model::Item(crate::lower::model::Item::ItType{mk_24823})})); }));
        });
    }));
    });
    })
        : prism_rtl::is<crate::check::env::TyBody::BChoice>(_m) ? ({
        auto&& cases_pn = prism_rtl::as<crate::check::env::TyBody::BChoice>(_m).a0;
        ({
        auto cases_pnx = cases_pn;
        auto lx_p0x = lx_p0;
        auto ti_p1x = ti_p1;
        (crate::prelude::call_value(crate::prelude::each_job(cases_pnx, ({
        auto ti_p1xx = ti_p1x;
        auto lx_p0xx = lx_p0x;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::CaseDef>(std::tuple<Text, Array<crate::check::types::Ty>>)>>(prism_rtl::rc([=, ti_p1xx = std::move(ti_p1xx), lx_p0xx = std::move(lx_p0xx)](std::tuple<Text, Array<crate::check::types::Ty>> p0) {
        return ({
            auto ti_p1xxy = ti_p1xx;
            auto lx_p0xxy = lx_p0xx;
            (crate::prelude::entered(crate::prelude::once_job([=, ti_p1xxy = std::move(ti_p1xxy), lx_p0xxy = std::move(lx_p0xxy)]() {
            return ({
                auto [cn_pq, ats_pr] = p0;
                ({
                auto ck_ps = crate::check::env::qual_key_f(prism_rtl::deref(ti_p1xxy).home_p, cn_pq);
                (crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(crate::prelude::len(ats_pr)), ({
                auto lx_p0xxyx = lx_p0xxy;
                auto ck_psx = ck_ps;
                auto ats_prx = ats_pr;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, crate::lower::model::OutTy>>(Nat)>>(prism_rtl::rc([=, lx_p0xxyx = std::move(lx_p0xxyx), ck_psx = std::move(ck_psx), ats_prx = std::move(ats_prx)](Nat p0) {
                return ({
                    auto lx_p0xxyxy = lx_p0xxyx;
                    auto ck_psxy = ck_psx;
                    auto ats_prxy = ats_prx;
                    (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xxyxy = std::move(lx_p0xxyxy), ck_psxy = std::move(ck_psxy), ats_prxy = std::move(ats_prxy)]() {
                    return ({
                        auto i_pt = p0;
                        (crate::prelude::call_then(start_case_field_f(lx_p0xxyxy, ck_psxy, i_pt, crate::prelude::or_(crate::prelude::index(ats_prxy, i_pt), crate::check::types::Ty(crate::check::types::Ty::TyErr{}))), [=](crate::lower::model::OutTy case_field_f_25160) { return prism_rtl::finished(std::tuple{Text::lit(""), case_field_f_25160}); }));
                    });
                })));
                });
            }));
            })), [=](Array<std::tuple<Text, crate::lower::model::OutTy>> each_25123) { return prism_rtl::finished(crate::lower::model::CaseDef{.name_p = crate::lower::camel_f(cn_pq), .prism_p = cn_pq, .fields_p = each_25123, .labels_p = Array<Text>{}}); }));
            });
            });
        })));
        });
    })));
    })), [=](Array<crate::lower::model::CaseDef> each_24992) {
        return ({
            auto defs_po = each_24992;
            auto shape_pp = ({
                __label__ _done;
                prism_rtl::Slot<crate::lower::model::TyShape> _v;
                {
                    auto&& m25242_0 = cases_pnx;
                    if (m25242_0.size() == 1u) {
                        {
                            auto&& _c2 = crate::prelude::index(m25242_0, Nat(0u));
                            if (prism_rtl::is_some(_c2)) {
                                auto&& cn_pu = std::get<0>(prism_rtl::some_of(_c2));
                                auto&& m25242_0_0_1 = std::get<1>(prism_rtl::some_of(_c2));
                                if (m25242_0_0_1.size() == 0u) {
                                    _v.set(crate::check::env::is_lower_text_f(cn_pu)
                                        ? crate::lower::model::TyShape(crate::lower::model::TyShape::ShapeUnit{})
                                        : crate::lower::model::TyShape(crate::lower::model::TyShape::ShapeChoice{}));
                                    goto _done;
                                }
                            }
                        }
                    }
                }
                {
                    auto&& m25242_1 = cases_pnx;
                    if (m25242_1.size() == 1u) {
                        {
                            auto&& _c1 = crate::prelude::index(m25242_1, Nat(0u));
                            if (prism_rtl::is_some(_c1)) {
                                auto&& cn_pv = std::get<0>(prism_rtl::some_of(_c1));
                                _v.set(cn_pv == bare_p4
                                    ? crate::lower::model::TyShape(crate::lower::model::TyShape::ShapeNewtype{})
                                    : crate::lower::model::TyShape(crate::lower::model::TyShape::ShapeChoice{}));
                                goto _done;
                            }
                        }
                    }
                }
                {
                    _v.set(crate::lower::model::TyShape(crate::lower::model::TyShape::ShapeChoice{}));
                    goto _done;
                }
            _done:
                _v.take();
            });
            (crate::prelude::call_value(mk_f5(std::tuple{shape_pp, defs_po}), [=](crate::lower::model::TyDef mk_25479) { return prism_rtl::finished(Array(std::vector{crate::lower::model::Item(crate::lower::model::Item::ItType{mk_25479})})); }));
        });
    }));
    });
    })
        : prism_rtl::is<crate::check::env::TyBody::BRowKind>(_m) ? prism_rtl::deref(ti_p1).name_p == Text::lit("Prelude.Fault")
        ? prism_rtl::finished(Array<crate::lower::model::Item>{})
        : ({
        auto lx_p0x = lx_p0;
        auto ti_p1x = ti_p1;
        (crate::prelude::call_then(start_row_def_of_f(lx_p0x, ti_p1x), [=](crate::lower::model::RowDef row_def_of_f_25566) { return prism_rtl::finished(Array(std::vector{crate::lower::model::Item(crate::lower::model::Item::ItRow{row_def_of_f_25566})})); }));
    })
        : prism_rtl::finished(Array<crate::lower::model::Item>{});
    });
}


/// `Start TyDefs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::lower::model::Item>> start_ty_defs_f(crate::lower::Lx lx_p0, crate::check::env::TyInfo ti_p1) {
    return prism_rtl::make_rc<TyDefs>(lx_p0, ti_p1);
}


/// TyPodable: unbounded fn Lx, Ty, [Text] -> Bool
bool ty_podable_f(const crate::lower::Lx& lx_p0, const crate::check::types::Ty& t_p1, const Array<Text>& seen_p2) {
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(t_p1)) {
        return false;
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(t_p1)) {
        return false;
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t_p1)) {
        auto&& m25887_2_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a0;
        if (m25887_2_0 == Text::lit("!")) {
            return false;
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t_p1)) {
        auto&& m25887_3_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a0;
        if (m25887_3_0 == Text::lit("$")) {
            return false;
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t_p1)) {
        auto&& i_p3 = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a1;
        return ty_podable_f(lx_p0, prism_rtl::deref(prism_rtl::deref(i_p3)), seen_p2);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t_p1)) {
        auto&& ts_p4 = prism_rtl::as<crate::check::types::Ty::TyTuple>(t_p1).a0;
        return crate::prelude::run_to_end(crate::prelude::fold_job(ts_p4, true, ({
            auto lx_p0x = lx_p0;
            auto seen_p2x = seen_p2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=, lx_p0x = std::move(lx_p0x), seen_p2x = std::move(seen_p2x)](std::tuple<bool, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto lx_p0xy = lx_p0x;
                auto seen_p2xy = seen_p2x;
                (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xy = std::move(lx_p0xy), seen_p2xy = std::move(seen_p2xy)]() {
                return ({
                    auto ok_p5 = p0;
                    auto x_p6 = p1;
                    (prism_rtl::finished(std::move(ok_p5) && ty_podable_f(lx_p0xy, x_p6, seen_p2xy)));
                });
            })));
            });
        })));
        })));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(t_p1)) {
        auto&& e_p7 = prism_rtl::as<crate::check::types::Ty::TyArray>(t_p1).a0;
        return ty_podable_f(lx_p0, prism_rtl::deref(prism_rtl::deref(e_p7)), seen_p2);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(t_p1)) {
        auto&& k_p8 = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p1).a0;
        auto&& v_p9 = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p1).a1;
        return ty_podable_f(lx_p0, prism_rtl::deref(prism_rtl::deref(k_p8)), seen_p2) && ty_podable_f(lx_p0, prism_rtl::deref(prism_rtl::deref(v_p9)), seen_p2);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t_p1)) {
        auto&& n_pa = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a0;
        auto&& args_pb = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a1;
        return crate::check::types::has_text_f(seen_p2, n_pa)
            ? true
            : ({
            auto more_pc = crate::prelude::push(seen_p2, n_pa);
            auto args_ok_pd = crate::prelude::run_to_end(crate::prelude::fold_job(args_pb, true, ({
                auto lx_p0x = lx_p0;
                auto more_pcx = more_pc;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=, lx_p0x = std::move(lx_p0x), more_pcx = std::move(more_pcx)](std::tuple<bool, crate::check::types::Ty> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto lx_p0xy = lx_p0x;
                    auto more_pcxy = more_pcx;
                    (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xy = std::move(lx_p0xy), more_pcxy = std::move(more_pcxy)]() {
                    return ({
                        auto ok_pe = p0;
                        auto x_pf = p1;
                        (prism_rtl::finished(std::move(ok_pe) && ty_podable_f(lx_p0xy, x_pf, more_pcxy)));
                    });
                })));
                });
            })));
            })));
            (std::move(args_ok_pd) && ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            auto&& _m = crate::prelude::get(prism_rtl::deref(lx_p0.g_p).types_p, n_pa);
            if (prism_rtl::is_some(_m)) {
                auto&& ti_pg = prism_rtl::some_of(_m);
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<bool> _v;
                    auto&& _m = prism_rtl::deref(ti_pg).body_p;
                    if (prism_rtl::is<crate::check::env::TyBody::BRecord>(_m)) {
                        auto&& fs_ph = prism_rtl::as<crate::check::env::TyBody::BRecord>(_m).a0;
                        _v.set(crate::prelude::run_to_end(crate::prelude::fold_job(fs_ph, true, ({
                            auto lx_p0x = lx_p0;
                            auto more_pcx = more_pc;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, crate::check::types::Ty>>)>>(prism_rtl::rc([=, lx_p0x = std::move(lx_p0x), more_pcx = std::move(more_pcx)](std::tuple<bool, std::tuple<Text, crate::check::types::Ty>> _p0) {
                            auto&& p0 = std::get<0>(_p0);
                            auto&& p1 = std::get<1>(_p0);
                            return ({
                                auto lx_p0xy = lx_p0x;
                                auto more_pcxy = more_pcx;
                                (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xy = std::move(lx_p0xy), more_pcxy = std::move(more_pcxy)]() {
                                return ({
                                    auto ok_pi = p0;
                                    auto&& _ft_pj = p1;
                                    auto&& ft_pj = std::get<1>(_ft_pj);
                                    (prism_rtl::finished(std::move(ok_pi) && ty_podable_f(lx_p0xy, ft_pj, more_pcxy)));
                                });
                            })));
                            });
                        })));
                        }))));
                        goto _done;
                    }
                    if (prism_rtl::is<crate::check::env::TyBody::BChoice>(_m)) {
                        auto&& cs_pk = prism_rtl::as<crate::check::env::TyBody::BChoice>(_m).a0;
                        _v.set(crate::prelude::run_to_end(crate::prelude::fold_job(cs_pk, true, ({
                            auto lx_p0x = lx_p0;
                            auto more_pcx = more_pc;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, Array<crate::check::types::Ty>>>)>>(prism_rtl::rc([=, lx_p0x = std::move(lx_p0x), more_pcx = std::move(more_pcx)](std::tuple<bool, std::tuple<Text, Array<crate::check::types::Ty>>> _p0) {
                            auto&& p0 = std::get<0>(_p0);
                            auto&& p1 = std::get<1>(_p0);
                            return ({
                                auto lx_p0xy = lx_p0x;
                                auto more_pcxy = more_pcx;
                                (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xy = std::move(lx_p0xy), more_pcxy = std::move(more_pcxy)]() {
                                return ({
                                    auto ok_pl = p0;
                                    auto&& _ats_pm = p1;
                                    auto&& ats_pm = std::get<1>(_ats_pm);
                                    (prism_rtl::finished(std::move(ok_pl) && crate::prelude::run_to_end(crate::prelude::fold_job(ats_pm, true, ({
                                    auto lx_p0xyx = lx_p0xy;
                                    auto more_pcxyx = more_pcxy;
                                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=, lx_p0xyx = std::move(lx_p0xyx), more_pcxyx = std::move(more_pcxyx)](std::tuple<bool, crate::check::types::Ty> _p0) {
                                    auto&& p0 = std::get<0>(_p0);
                                    auto&& p1 = std::get<1>(_p0);
                                    return ({
                                        auto lx_p0xyxy = lx_p0xyx;
                                        auto more_pcxyxy = more_pcxyx;
                                        (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xyxy = std::move(lx_p0xyxy), more_pcxyxy = std::move(more_pcxyxy)]() {
                                        return ({
                                            auto ok2_pn = p0;
                                            auto x_po = p1;
                                            (prism_rtl::finished(std::move(ok2_pn) && ty_podable_f(lx_p0xyxy, x_po, more_pcxyxy)));
                                        });
                                    })));
                                    });
                                })));
                                })))));
                                });
                            })));
                            });
                        })));
                        }))));
                        goto _done;
                    }
                    if (prism_rtl::is<crate::check::env::TyBody::BAlias>(_m)) {
                        auto&& a_pp = prism_rtl::as<crate::check::env::TyBody::BAlias>(_m).a0;
                        _v.set(ty_podable_f(lx_p0, a_pp, more_pc));
                        goto _done;
                    }
                    {
                        _v.set(true);
                        goto _done;
                    }
                _done:
                    _v.take();
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(true);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        }));
        });
    }
    {
        return true;
    }
}


prism_rtl::Turn<bool> TyPodable::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& t_p1 = this->t_p1;
    const auto& seen_p2 = this->seen_p2;
    return ({
        prism_rtl::is<crate::check::types::Ty::TyFn>(t_p1) ? prism_rtl::finished(false)
        : prism_rtl::is<crate::check::types::Ty::TyAt>(t_p1) ? prism_rtl::finished(false)
        : prism_rtl::is<crate::check::types::Ty::TySig>(t_p1) && ({
        auto&& m25887_2_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a0;
        (m25887_2_0 == Text::lit("!"));
    }) ? ({
        auto&& m25887_2_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a0;
        prism_rtl::finished(false);
    })
        : prism_rtl::is<crate::check::types::Ty::TySig>(t_p1) && ({
        auto&& m25887_3_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a0;
        (m25887_3_0 == Text::lit("$"));
    }) ? ({
        auto&& m25887_3_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a0;
        prism_rtl::finished(false);
    })
        : prism_rtl::is<crate::check::types::Ty::TySig>(t_p1) ? ({
        auto&& i_p3 = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a1;
        prism_rtl::more(prism_rtl::rc(TyPodable(lx_p0, prism_rtl::deref(prism_rtl::deref(i_p3)), seen_p2)));
    })
        : prism_rtl::is<crate::check::types::Ty::TyTuple>(t_p1) ? ({
        auto&& ts_p4 = prism_rtl::as<crate::check::types::Ty::TyTuple>(t_p1).a0;
        crate::prelude::fold_job(ts_p4, true, ({
        auto lx_p0x = lx_p0;
        auto seen_p2x = seen_p2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=, lx_p0x = std::move(lx_p0x), seen_p2x = std::move(seen_p2x)](std::tuple<bool, crate::check::types::Ty> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_p0xy = lx_p0x;
            auto seen_p2xy = seen_p2x;
            (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xy = std::move(lx_p0xy), seen_p2xy = std::move(seen_p2xy)]() {
            return ({
                auto ok_p5 = p0;
                auto x_p6 = p1;
                (prism_rtl::finished(std::move(ok_p5) && ty_podable_f(lx_p0xy, x_p6, seen_p2xy)));
            });
        })));
        });
    })));
    }))->cycle();
    })
        : prism_rtl::is<crate::check::types::Ty::TyArray>(t_p1) ? ({
        auto&& e_p7 = prism_rtl::as<crate::check::types::Ty::TyArray>(t_p1).a0;
        prism_rtl::more(prism_rtl::rc(TyPodable(lx_p0, prism_rtl::deref(prism_rtl::deref(e_p7)), seen_p2)));
    })
        : prism_rtl::is<crate::check::types::Ty::TyMap>(t_p1) ? ({
        auto&& k_p8 = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p1).a0;
        auto&& v_p9 = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p1).a1;
        ({
        auto k_p8x = prism_rtl::deref(prism_rtl::deref(k_p8));
        auto lx_p0x = lx_p0;
        auto seen_p2x = seen_p2;
        auto v_p9x = prism_rtl::deref(prism_rtl::deref(v_p9));
        (crate::prelude::call_then(start_ty_podable_f(lx_p0x, k_p8x, seen_p2x), [=, v_p9x = std::move(v_p9x)](bool ty_podable_f_26190) { return prism_rtl::finished(ty_podable_f_26190 && ty_podable_f(lx_p0x, v_p9x, seen_p2x)); }));
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t_p1) ? ({
        auto&& n_pa = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a0;
        auto&& args_pb = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a1;
        crate::check::types::has_text_f(seen_p2, n_pa)
        ? prism_rtl::finished(true)
        : ({
        auto more_pc = crate::prelude::push(seen_p2, n_pa);
        auto args_pbx = args_pb;
        auto lx_p0x = lx_p0;
        auto n_pax = n_pa;
        (crate::prelude::call_value(crate::prelude::fold_job(args_pbx, true, ({
        auto lx_p0xx = lx_p0x;
        auto more_pcx = more_pc;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=, lx_p0xx = std::move(lx_p0xx), more_pcx = std::move(more_pcx)](std::tuple<bool, crate::check::types::Ty> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_p0xxy = lx_p0xx;
            auto more_pcxy = more_pcx;
            (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xxy = std::move(lx_p0xxy), more_pcxy = std::move(more_pcxy)]() {
            return ({
                auto ok_pe = p0;
                auto x_pf = p1;
                (prism_rtl::finished(std::move(ok_pe) && ty_podable_f(lx_p0xxy, x_pf, more_pcxy)));
            });
        })));
        });
    })));
    })), [=, n_pax = std::move(n_pax)](bool fold_26366) {
        return ({
            auto args_ok_pd = fold_26366;
            (prism_rtl::finished(std::move(args_ok_pd) && ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            auto&& _m = crate::prelude::get(prism_rtl::deref(prism_rtl::deref(lx_p0x).g_p).types_p, n_pax);
            if (prism_rtl::is_some(_m)) {
                auto&& ti_pg = prism_rtl::some_of(_m);
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<bool> _v;
                    auto&& _m = prism_rtl::deref(ti_pg).body_p;
                    if (prism_rtl::is<crate::check::env::TyBody::BRecord>(_m)) {
                        auto&& fs_ph = prism_rtl::as<crate::check::env::TyBody::BRecord>(_m).a0;
                        _v.set(crate::prelude::run_to_end(crate::prelude::fold_job(fs_ph, true, ({
                            auto lx_p0xx = lx_p0x;
                            auto more_pcx = more_pc;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, crate::check::types::Ty>>)>>(prism_rtl::rc([=, lx_p0xx = std::move(lx_p0xx), more_pcx = std::move(more_pcx)](std::tuple<bool, std::tuple<Text, crate::check::types::Ty>> _p0) {
                            auto&& p0 = std::get<0>(_p0);
                            auto&& p1 = std::get<1>(_p0);
                            return ({
                                auto lx_p0xxy = lx_p0xx;
                                auto more_pcxy = more_pcx;
                                (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xxy = std::move(lx_p0xxy), more_pcxy = std::move(more_pcxy)]() {
                                return ({
                                    auto ok_pi = p0;
                                    auto&& _ft_pj = p1;
                                    auto&& ft_pj = std::get<1>(_ft_pj);
                                    (prism_rtl::finished(std::move(ok_pi) && ty_podable_f(lx_p0xxy, ft_pj, more_pcxy)));
                                });
                            })));
                            });
                        })));
                        }))));
                        goto _done;
                    }
                    if (prism_rtl::is<crate::check::env::TyBody::BChoice>(_m)) {
                        auto&& cs_pk = prism_rtl::as<crate::check::env::TyBody::BChoice>(_m).a0;
                        _v.set(crate::prelude::run_to_end(crate::prelude::fold_job(cs_pk, true, ({
                            auto lx_p0xx = lx_p0x;
                            auto more_pcx = more_pc;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, Array<crate::check::types::Ty>>>)>>(prism_rtl::rc([=, lx_p0xx = std::move(lx_p0xx), more_pcx = std::move(more_pcx)](std::tuple<bool, std::tuple<Text, Array<crate::check::types::Ty>>> _p0) {
                            auto&& p0 = std::get<0>(_p0);
                            auto&& p1 = std::get<1>(_p0);
                            return ({
                                auto lx_p0xxy = lx_p0xx;
                                auto more_pcxy = more_pcx;
                                (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xxy = std::move(lx_p0xxy), more_pcxy = std::move(more_pcxy)]() {
                                return ({
                                    auto ok_pl = p0;
                                    auto&& _ats_pm = p1;
                                    auto&& ats_pm = std::get<1>(_ats_pm);
                                    (prism_rtl::finished(std::move(ok_pl) && crate::prelude::run_to_end(crate::prelude::fold_job(ats_pm, true, ({
                                    auto lx_p0xxyx = lx_p0xxy;
                                    auto more_pcxyx = more_pcxy;
                                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=, lx_p0xxyx = std::move(lx_p0xxyx), more_pcxyx = std::move(more_pcxyx)](std::tuple<bool, crate::check::types::Ty> _p0) {
                                    auto&& p0 = std::get<0>(_p0);
                                    auto&& p1 = std::get<1>(_p0);
                                    return ({
                                        auto lx_p0xxyxy = lx_p0xxyx;
                                        auto more_pcxyxy = more_pcxyx;
                                        (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xxyxy = std::move(lx_p0xxyxy), more_pcxyxy = std::move(more_pcxyxy)]() {
                                        return ({
                                            auto ok2_pn = p0;
                                            auto x_po = p1;
                                            (prism_rtl::finished(std::move(ok2_pn) && ty_podable_f(lx_p0xxyxy, x_po, more_pcxyxy)));
                                        });
                                    })));
                                    });
                                })));
                                })))));
                                });
                            })));
                            });
                        })));
                        }))));
                        goto _done;
                    }
                    if (prism_rtl::is<crate::check::env::TyBody::BAlias>(_m)) {
                        auto&& a_pp = prism_rtl::as<crate::check::env::TyBody::BAlias>(_m).a0;
                        _v.set(ty_podable_f(lx_p0x, a_pp, more_pc));
                        goto _done;
                    }
                    {
                        _v.set(true);
                        goto _done;
                    }
                _done:
                    _v.take();
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(true);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        })));
        });
    }));
    });
    })
        : prism_rtl::finished(true);
    });
}


/// `Start TyPodable, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_ty_podable_f(crate::lower::Lx lx_p0, crate::check::types::Ty t_p1, Array<Text> seen_p2) {
    return prism_rtl::make_rc<TyPodable>(lx_p0, t_p1, seen_p2);
}


/// TyHasEq: unbounded fn Lx, Ty, [Text] -> Bool
bool ty_has_eq_f(const crate::lower::Lx& lx_p0, const crate::check::types::Ty& t_p1, const Array<Text>& seen_p2) {
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(t_p1)) {
        return false;
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(t_p1)) {
        return false;
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t_p1)) {
        auto&& m27320_2_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a0;
        if (m27320_2_0 == Text::lit("!")) {
            return false;
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t_p1)) {
        auto&& m27320_3_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a0;
        if (m27320_3_0 == Text::lit("$")) {
            return false;
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t_p1)) {
        auto&& i_p3 = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a1;
        return ty_has_eq_f(lx_p0, prism_rtl::deref(prism_rtl::deref(i_p3)), seen_p2);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t_p1)) {
        auto&& ts_p4 = prism_rtl::as<crate::check::types::Ty::TyTuple>(t_p1).a0;
        return crate::prelude::run_to_end(crate::prelude::fold_job(ts_p4, true, ({
            auto lx_p0x = lx_p0;
            auto seen_p2x = seen_p2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=, lx_p0x = std::move(lx_p0x), seen_p2x = std::move(seen_p2x)](std::tuple<bool, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto lx_p0xy = lx_p0x;
                auto seen_p2xy = seen_p2x;
                (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xy = std::move(lx_p0xy), seen_p2xy = std::move(seen_p2xy)]() {
                return ({
                    auto ok_p5 = p0;
                    auto x_p6 = p1;
                    (prism_rtl::finished(std::move(ok_p5) && ty_has_eq_f(lx_p0xy, x_p6, seen_p2xy)));
                });
            })));
            });
        })));
        })));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(t_p1)) {
        auto&& e_p7 = prism_rtl::as<crate::check::types::Ty::TyArray>(t_p1).a0;
        return ty_has_eq_f(lx_p0, prism_rtl::deref(prism_rtl::deref(e_p7)), seen_p2);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(t_p1)) {
        auto&& k_p8 = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p1).a0;
        auto&& v_p9 = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p1).a1;
        return ty_has_eq_f(lx_p0, prism_rtl::deref(prism_rtl::deref(k_p8)), seen_p2) && ty_has_eq_f(lx_p0, prism_rtl::deref(prism_rtl::deref(v_p9)), seen_p2);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(t_p1)) {
        return true;
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElemAny>(t_p1)) {
        return true;
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t_p1)) {
        auto&& n_pa = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a0;
        auto&& args_pb = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a1;
        return crate::check::types::has_text_f(seen_p2, n_pa)
            ? true
            : ({
            auto args_ok_pc = crate::prelude::run_to_end(crate::prelude::fold_job(args_pb, true, ({
                auto lx_p0x = lx_p0;
                auto seen_p2x = seen_p2;
                auto n_pax = n_pa;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=, lx_p0x = std::move(lx_p0x), seen_p2x = std::move(seen_p2x), n_pax = std::move(n_pax)](std::tuple<bool, crate::check::types::Ty> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto lx_p0xy = lx_p0x;
                    auto seen_p2xy = seen_p2x;
                    auto n_paxy = n_pax;
                    (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xy = std::move(lx_p0xy), seen_p2xy = std::move(seen_p2xy), n_paxy = std::move(n_paxy)]() {
                    return ({
                        auto ok_pd = p0;
                        auto x_pe = p1;
                        (prism_rtl::finished(std::move(ok_pd) && ty_has_eq_f(lx_p0xy, x_pe, crate::prelude::push(seen_p2xy, n_paxy))));
                    });
                })));
                });
            })));
            })));
            (std::move(args_ok_pc) && ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            auto&& _m = crate::prelude::get(prism_rtl::deref(lx_p0.g_p).types_p, n_pa);
            if (prism_rtl::is_some(_m)) {
                auto&& ti_pf = prism_rtl::some_of(_m);
                _v.set(crate::prelude::fold(prism_rtl::deref(ti_pf).derives_p, false, [&](const bool& f_pg, const Text& d_ph) { return prism_rtl::deref(f_pg) || (crate::check::env::names::resolve_trait_o(lx_p0.g_p, prism_rtl::deref(ti_pf).home_p, crate::prelude::split_on(d_ph, Text::lit("."))) == std::optional(Text::lit("Prelude.Eq"))); }) || has_own_eq_f(lx_p0, n_pa));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(true);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        }));
        });
    }
    {
        return false;
    }
}


/// HasOwnEq: fn Lx, Text -> Bool
bool has_own_eq_f(const crate::lower::Lx& lx_p0, const Text& tn_p1) {
    return crate::prelude::fold(crate::prelude::or_(crate::prelude::get(prism_rtl::deref(lx_p0.g_p).impls_p, Text::lit("Prelude.Eq")), Array<crate::check::env::ImplInfo>{}), false, [&](const bool& f_p2, const crate::check::env::ImplInfo& im_p3) { return prism_rtl::deref(f_p2) || (crate::lower::functions::head_name_f(prism_rtl::deref(im_p3).head_p) == tn_p1); });
}


/// CaseField: unbounded fn Lx, Text, Nat, Ty -> OutTy
crate::lower::model::OutTy case_field_f(const crate::lower::Lx& lx_p0, const Text& ck_p1, const Nat& i_p2, const crate::check::types::Ty& t_p3) {
    auto rt_p4 = crate::lower::types::out_ty_of_f(lx_p0, t_p3);
    return crate::lower::types::rc_field_f(lx_p0, ck_p1, i_p2)
        ? crate::lower::model::OutTy(crate::lower::model::OutTy::OutRc{prism_rtl::rc(rt_p4)})
        : rt_p4;
}


prism_rtl::Turn<crate::lower::model::OutTy> CaseField::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& ck_p1 = this->ck_p1;
    const auto& i_p2 = this->i_p2;
    const auto& t_p3 = this->t_p3;
    auto ck_p1x = ck_p1;
    auto i_p2x = i_p2;
    auto lx_p0x = lx_p0;
    auto t_p3x = t_p3;
    return crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0x, t_p3x), [=](crate::lower::model::OutTy out_ty_of_f_28343) {
        return ({
            auto rt_p4 = out_ty_of_f_28343;
            (crate::lower::types::rc_field_f(lx_p0x, ck_p1x, i_p2x)
            ? prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutRc{prism_rtl::rc(rt_p4)}))
            : prism_rtl::finished(rt_p4));
        });
    });
}


/// `Start CaseField, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::OutTy> start_case_field_f(crate::lower::Lx lx_p0, Text ck_p1, Nat i_p2, crate::check::types::Ty t_p3) {
    return prism_rtl::make_rc<CaseField>(lx_p0, ck_p1, i_p2, t_p3);
}


/// TypeDoc: fn Lx, TyInfo -> Text
Text type_doc_f(const crate::lower::Lx& lx_p0, const crate::check::env::TyInfo& ti_p1) {
    auto&& _m = crate::prelude::index(prism_rtl::deref(lx_p0.g_p).srcs_p, ti_p1.file_p);
    if (prism_rtl::is_some(_m)) {
        auto&& src_p2 = prism_rtl::some_of(_m);
        return crate::syntax::lexer::chars::trim_f(crate::check::errors::line_text_f(src_p2, crate::check::errors::cline_of_f(prism_rtl::deref(src_p2).starts_p, prism_rtl::deref(ti_p1.span_p).start_p)));
    }
    if (prism_rtl::is_none(_m)) {
        return ti_p1.name_p;
    }
    prism_rtl::unreachable("no arm matched");
}


/// TagDefOf: unbounded fn Lx, TagInfo -> TagDef
crate::lower::model::TagDef tag_def_of_f(const crate::lower::Lx& lx_p0, const crate::check::env::TagInfo& tg_p1) {
    auto fields_p2 = crate::prelude::run_to_end(crate::prelude::each_job(level_fields_f(tg_p1), ({
        auto tg_p1x = tg_p1;
        auto lx_p0x = lx_p0;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, Text, crate::lower::model::OutTy>>(std::tuple<Text, crate::check::types::Ty>)>>(prism_rtl::rc([=, tg_p1x = std::move(tg_p1x), lx_p0x = std::move(lx_p0x)](std::tuple<Text, crate::check::types::Ty> p0) {
        return ({
            auto tg_p1xy = tg_p1x;
            auto lx_p0xy = lx_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, tg_p1xy = std::move(tg_p1xy), lx_p0xy = std::move(lx_p0xy)]() {
            return ({
                auto [fname_p3, ft_p4] = p0;
                (crate::prelude::call_then(crate::lower::start_field_spell_f(prism_rtl::deref(tg_p1xy).home_p, fname_p3, ft_p4), [=](Text field_spell_f_28838) { return crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0xy, crate::lower::types::peel_f(ft_p4)), [=](crate::lower::model::OutTy out_ty_of_f_28871) { return prism_rtl::finished(std::tuple{fname_p3, field_spell_f_28838, out_ty_of_f_28871}); }); }));
            });
        })));
        });
    }));
    })));
    return crate::lower::model::TagDef{.name_p = crate::lower::tag_struct_f(tg_p1.name_p), .tag_name_p = tg_p1.name_p, .fields_p = fields_p2, .doc_p = type_doc_f(lx_p0, crate::check::env::TyInfo{.name_p = tg_p1.name_p, .home_p = tg_p1.home_p, .params_p = Array<Text>{}, .body_p = crate::check::env::TyBody(crate::check::env::TyBody::BOpaque{}), .derives_p = Array<Text>{}, .file_p = tg_p1.file_p, .span_p = tg_p1.span_p}), .pod_p = crate::prelude::run_to_end(crate::prelude::fold_job(fields_p2, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, Text, crate::lower::model::OutTy>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<Text, Text, crate::lower::model::OutTy>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto ok_p5 = p0;
                auto&& _t_p6 = p1;
                auto&& t_p6 = std::get<2>(_t_p6);
                (prism_rtl::finished(std::move(ok_p5) && crate::lower::types::podable_f(t_p6)));
            });
        }));
    })))), .eq_p = crate::prelude::run_to_end(crate::prelude::fold_job(fields_p2, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, Text, crate::lower::model::OutTy>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<Text, Text, crate::lower::model::OutTy>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto ok_p7 = p0;
                auto&& _t_p8 = p1;
                auto&& t_p8 = std::get<2>(_t_p8);
                (prism_rtl::finished(std::move(ok_p7) && crate::lower::types::runtime_eq_f(t_p8)));
            });
        }));
    }))))};
}


prism_rtl::Turn<crate::lower::model::TagDef> TagDefOf::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& tg_p1 = this->tg_p1;
    auto lx_p0x = lx_p0;
    auto tg_p1x = tg_p1;
    return crate::prelude::call_value(crate::prelude::each_job(level_fields_f(tg_p1x), ({
        auto tg_p1xx = tg_p1x;
        auto lx_p0xx = lx_p0x;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, Text, crate::lower::model::OutTy>>(std::tuple<Text, crate::check::types::Ty>)>>(prism_rtl::rc([=, tg_p1xx = std::move(tg_p1xx), lx_p0xx = std::move(lx_p0xx)](std::tuple<Text, crate::check::types::Ty> p0) {
        return ({
            auto tg_p1xxy = tg_p1xx;
            auto lx_p0xxy = lx_p0xx;
            (crate::prelude::entered(crate::prelude::once_job([=, tg_p1xxy = std::move(tg_p1xxy), lx_p0xxy = std::move(lx_p0xxy)]() {
            return ({
                auto [fname_p3, ft_p4] = p0;
                (crate::prelude::call_then(crate::lower::start_field_spell_f(prism_rtl::deref(tg_p1xxy).home_p, fname_p3, ft_p4), [=](Text field_spell_f_28838) { return crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0xxy, crate::lower::types::peel_f(ft_p4)), [=](crate::lower::model::OutTy out_ty_of_f_28871) { return prism_rtl::finished(std::tuple{fname_p3, field_spell_f_28838, out_ty_of_f_28871}); }); }));
            });
        })));
        });
    }));
    })), [=](Array<std::tuple<Text, Text, crate::lower::model::OutTy>> each_28788) {
        return ({
            auto fields_p2 = each_28788;
            (crate::prelude::call_value(crate::prelude::fold_job(fields_p2, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, Text, crate::lower::model::OutTy>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<Text, Text, crate::lower::model::OutTy>> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto ok_p5 = p0;
                    auto&& _t_p6 = p1;
                    auto&& t_p6 = std::get<2>(_t_p6);
                    (prism_rtl::finished(std::move(ok_p5) && crate::lower::types::podable_f(t_p6)));
                });
            }));
        }))), [=](bool fold_29095) {
            return crate::prelude::call_value(crate::prelude::fold_job(fields_p2, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, Text, crate::lower::model::OutTy>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<Text, Text, crate::lower::model::OutTy>> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return crate::prelude::entered(crate::prelude::once_job([=]() {
                    return ({
                        auto ok_p7 = p0;
                        auto&& _t_p8 = p1;
                        auto&& t_p8 = std::get<2>(_t_p8);
                        (prism_rtl::finished(std::move(ok_p7) && crate::lower::types::runtime_eq_f(t_p8)));
                    });
                }));
            }))), [=](bool fold_29166) { return prism_rtl::finished(crate::lower::model::TagDef{.name_p = crate::lower::tag_struct_f(prism_rtl::deref(tg_p1x).name_p), .tag_name_p = prism_rtl::deref(tg_p1x).name_p, .fields_p = fields_p2, .doc_p = type_doc_f(lx_p0x, crate::check::env::TyInfo{.name_p = prism_rtl::deref(tg_p1x).name_p, .home_p = prism_rtl::deref(tg_p1x).home_p, .params_p = Array<Text>{}, .body_p = crate::check::env::TyBody(crate::check::env::TyBody::BOpaque{}), .derives_p = Array<Text>{}, .file_p = prism_rtl::deref(tg_p1x).file_p, .span_p = prism_rtl::deref(tg_p1x).span_p}), .pod_p = fold_29095, .eq_p = fold_29166}); });
        }));
        });
    });
}


/// `Start TagDefOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::TagDef> start_tag_def_of_f(crate::lower::Lx lx_p0, crate::check::env::TagInfo tg_p1) {
    return prism_rtl::make_rc<TagDefOf>(lx_p0, tg_p1);
}


/// LevelFields: fn TagInfo -> [((Text, Ty))]
Array<std::tuple<Text, crate::check::types::Ty>> level_fields_f(const crate::check::env::TagInfo& tg_p0) {
    return crate::prelude::filter(tg_p0.fields_p, [&](const std::tuple<Text, crate::check::types::Ty>& _p0) {
        auto&& ft_p1 = std::get<1>(_p0);
        return crate::lower::types::layer_of_f(ft_p1) != crate::lower::types::Layer(crate::lower::types::Layer::LyEv{});
    });
}


/// KindTags: fn Lx, Text, [Text] -> [TagInfo]
Array<crate::check::env::TagInfo> kind_tags_f(const crate::lower::Lx& lx_p0, const Text& kind_p1, const Array<Text>& mods_p2) {
    return crate::prelude::filter(crate::prelude::values(prism_rtl::deref(lx_p0.g_p).tags_p), [&](const crate::check::env::TagInfo& tg_p3) { return (prism_rtl::deref(tg_p3).kind_p == kind_p1) && crate::check::types::has_text_f(mods_p2, prism_rtl::deref(tg_p3).home_p); });
}


/// RowDefOf: unbounded fn Lx, TyInfo -> RowDef
crate::lower::model::RowDef row_def_of_f(const crate::lower::Lx& lx_p0, const crate::check::env::TyInfo& ti_p1) {
    auto tags_p2 = kind_tags_f(lx_p0, ti_p1.name_p, crate::prelude::keys(lx_p0.rs_mods_p));
    auto cases_p3 = crate::prelude::each(tags_p2, [&](const crate::check::env::TagInfo& tg_p6) { return std::tuple{crate::lower::tag_struct_f(prism_rtl::deref(tg_p6).name_p), crate::lower::path_in_f(lx_p0, prism_rtl::deref(tg_p6).home_p, crate::lower::tag_struct_f(prism_rtl::deref(tg_p6).name_p))}; });
    auto pod_p4 = crate::prelude::run_to_end(crate::prelude::fold_job(tags_p2, true, ({
        auto lx_p0x = lx_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::env::TagInfo>)>>(prism_rtl::rc([=, lx_p0x = std::move(lx_p0x)](std::tuple<bool, crate::check::env::TagInfo> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_p0xy = lx_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xy = std::move(lx_p0xy)]() {
            return ({
                auto ok_p7 = p0;
                auto tg_p8 = p1;
                (prism_rtl::finished(std::move(ok_p7) && prism_rtl::deref(tag_def_of_f(lx_p0xy, tg_p8)).pod_p));
            });
        })));
        });
    })));
    })));
    auto eq_p5 = crate::prelude::run_to_end(crate::prelude::fold_job(tags_p2, true, ({
        auto lx_p0x = lx_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::env::TagInfo>)>>(prism_rtl::rc([=, lx_p0x = std::move(lx_p0x)](std::tuple<bool, crate::check::env::TagInfo> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_p0xy = lx_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xy = std::move(lx_p0xy)]() {
            return ({
                auto ok_p9 = p0;
                auto tg_pa = p1;
                (prism_rtl::finished(std::move(ok_p9) && prism_rtl::deref(tag_def_of_f(lx_p0xy, tg_pa)).eq_p));
            });
        })));
        });
    })));
    })));
    return crate::lower::model::RowDef{.name_p = crate::lower::camel_f(crate::check::types::bare_name_f(ti_p1.name_p)), .prism_p = ti_p1.name_p, .cases_p = cases_p3, .pod_p = std::move(pod_p4), .doc_p = type_doc_f(lx_p0, ti_p1), .eq_p = std::move(eq_p5), .level_p = false, .deep_p = Array<Text>{}};
}


prism_rtl::Turn<crate::lower::model::RowDef> RowDefOf::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& ti_p1 = this->ti_p1;
    auto tags_p2 = kind_tags_f(lx_p0, prism_rtl::deref(ti_p1).name_p, crate::prelude::keys(prism_rtl::deref(lx_p0).rs_mods_p));
    auto cases_p3 = crate::prelude::each(tags_p2, [&](const crate::check::env::TagInfo& tg_p6) { return std::tuple{crate::lower::tag_struct_f(prism_rtl::deref(tg_p6).name_p), crate::lower::path_in_f(lx_p0, prism_rtl::deref(tg_p6).home_p, crate::lower::tag_struct_f(prism_rtl::deref(tg_p6).name_p))}; });
    auto lx_p0x = lx_p0;
    auto ti_p1x = ti_p1;
    return crate::prelude::call_value(crate::prelude::fold_job(tags_p2, true, ({
        auto lx_p0xx = lx_p0x;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::env::TagInfo>)>>(prism_rtl::rc([=, lx_p0xx = std::move(lx_p0xx)](std::tuple<bool, crate::check::env::TagInfo> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto lx_p0xxy = lx_p0xx;
            (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xxy = std::move(lx_p0xxy)]() {
            return ({
                auto ok_p7 = p0;
                auto tg_p8 = p1;
                (prism_rtl::finished(std::move(ok_p7) && prism_rtl::deref(tag_def_of_f(lx_p0xxy, tg_p8)).pod_p));
            });
        })));
        });
    })));
    })), [=](bool fold_29882) {
        return ({
            auto pod_p4 = fold_29882;
            (crate::prelude::call_value(crate::prelude::fold_job(tags_p2, true, ({
            auto lx_p0xx = lx_p0x;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::env::TagInfo>)>>(prism_rtl::rc([=, lx_p0xx = std::move(lx_p0xx)](std::tuple<bool, crate::check::env::TagInfo> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto lx_p0xxy = lx_p0xx;
                (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xxy = std::move(lx_p0xxy)]() {
                return ({
                    auto ok_p9 = p0;
                    auto tg_pa = p1;
                    (prism_rtl::finished(std::move(ok_p9) && prism_rtl::deref(tag_def_of_f(lx_p0xxy, tg_pa)).eq_p));
                });
            })));
            });
        })));
        })), [=, pod_p4 = std::move(pod_p4)](bool fold_29951) {
            return ({
                auto eq_p5 = fold_29951;
                (prism_rtl::finished(crate::lower::model::RowDef{.name_p = crate::lower::camel_f(crate::check::types::bare_name_f(prism_rtl::deref(ti_p1x).name_p)), .prism_p = prism_rtl::deref(ti_p1x).name_p, .cases_p = cases_p3, .pod_p = pod_p4, .doc_p = type_doc_f(lx_p0x, ti_p1x), .eq_p = std::move(eq_p5), .level_p = false, .deep_p = Array<Text>{}}));
            });
        }));
        });
    });
}

}  // namespace crate::lower::program
