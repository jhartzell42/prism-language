// The module `Syntax.Parser.Blocks`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <syntax/parser/blocks/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Syntax.Parser.Blocks`, from `target/bootstrap/cpp-src/prismc/syntax/parser/blocks.prism`.
namespace crate::syntax::parser::blocks {

/// ParseBlockAfterColon: unbounded fn Ps -> ((Block, Ps))
std::tuple<crate::syntax::Block, crate::syntax::parser::Ps> parse_block_after_colon(const crate::syntax::parser::Ps& p0) {
    auto p_ = crate::syntax::parser::expect_colon(p0);
    return crate::syntax::parser::at_open_l(p_)
        ? parse_indented_block(p_)
        : crate::syntax::parser::at_stmt_boundary(p_)
        ? std::tuple{crate::syntax::parser::decls::no_block(), crate::syntax::parser::error_here(p_, Text::lit("expected a statement after `:`"))}
        : ({
        auto start = crate::syntax::parser::here(p_);
        auto [first_, p1] = parse_stmt(p_);
        auto r = ({
            std::tuple<Array<crate::syntax::Stmt>, crate::syntax::parser::Ps> this_ = std::tuple{Array(std::vector{first_}), p1};
            Array<crate::syntax::Stmt> stmts = Array(std::vector{first_});
            crate::syntax::parser::Ps q = p1;
            while ((crate::syntax::parser::kind(q) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KSemi{})) && (!q.bad)) {
                auto [st, q2] = parse_stmt(crate::syntax::parser::adv(q));
                stmts = crate::prelude::push(stmts, st);
                q = q2;
            }
            this_ = std::tuple{stmts, q};
            this_;
        });
        auto [stmts, q] = r;
        std::tuple{crate::syntax::Block{.stmts = stmts, .inline_ = true, .span = crate::syntax::parser::to(start, crate::syntax::parser::prev(q))}, q};
    });
}


prism_rtl::Turn<std::tuple<crate::syntax::Block, crate::syntax::parser::Ps>> ParseBlockAfterColon::cycle() const {
    const auto& p0 = this->p0;
    auto p_ = crate::syntax::parser::expect_colon(p0);
    return crate::syntax::parser::at_open_l(p_)
        ? prism_rtl::more(prism_rtl::rc(ParseIndentedBlock(p_)))
        : crate::syntax::parser::at_stmt_boundary(p_)
        ? prism_rtl::finished(std::tuple{crate::syntax::parser::decls::no_block(), crate::syntax::parser::error_here(p_, Text::lit("expected a statement after `:`"))})
        : ({
        auto start = crate::syntax::parser::here(p_);
        call_then(start_parse_stmt(p_), [=](std::tuple<crate::syntax::Stmt, crate::syntax::parser::Ps> parse_stmt_1224) {
        return ({
            auto [first_, p1] = parse_stmt_1224;
            std::tuple<Array<crate::syntax::Stmt>, crate::syntax::parser::Ps> this_ = std::tuple{Array(std::vector{first_}), p1};
            Array<crate::syntax::Stmt> stmts = Array(std::vector{first_});
            crate::syntax::parser::Ps q = p1;
            auto start_1 = start;
            call_then(loop_job(std::tuple{this_, q, stmts}, [=](std::tuple<std::tuple<Array<crate::syntax::Stmt>, crate::syntax::parser::Ps>, crate::syntax::parser::Ps, Array<crate::syntax::Stmt>> _p0) {
            auto this_ = std::get<0>(_p0);
            auto q = std::get<1>(_p0);
            auto stmts = std::get<2>(_p0);
            return (crate::syntax::parser::kind(q) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KSemi{})) && (!q->bad)
                ? ({
                auto [st, q2] = parse_stmt(crate::syntax::parser::adv(q));
                stmts = crate::prelude::push(stmts, st);
                q = q2;
                Expected<std::tuple<std::tuple<Array<crate::syntax::Stmt>, crate::syntax::parser::Ps>, crate::syntax::parser::Ps, Array<crate::syntax::Stmt>>, std::tuple<std::tuple<Array<crate::syntax::Stmt>, crate::syntax::parser::Ps>, crate::syntax::parser::Ps, Array<crate::syntax::Stmt>>>(std::tuple{this_, q, stmts});
            })
                : Expected<std::tuple<std::tuple<Array<crate::syntax::Stmt>, crate::syntax::parser::Ps>, crate::syntax::parser::Ps, Array<crate::syntax::Stmt>>, std::tuple<std::tuple<Array<crate::syntax::Stmt>, crate::syntax::parser::Ps>, crate::syntax::parser::Ps, Array<crate::syntax::Stmt>>>(unexpected(std::tuple{this_, q, stmts}));
        }), [=](std::tuple<std::tuple<Array<crate::syntax::Stmt>, crate::syntax::parser::Ps>, crate::syntax::parser::Ps, Array<crate::syntax::Stmt>> _p0) {
            auto this_ = std::get<0>(_p0);
            auto q = std::get<1>(_p0);
            auto stmts = std::get<2>(_p0);
            return ({
                this_ = std::tuple{stmts, q};
                auto r = this_;
                auto [stmts, q] = r;
                (prism_rtl::finished(std::tuple{crate::syntax::Block{.stmts = stmts, .inline_ = true, .span = crate::syntax::parser::to(start_1, crate::syntax::parser::prev(q))}, q}));
            });
        });
        });
    });
    });
}


/// `Start ParseBlockAfterColon, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Block, crate::syntax::parser::Ps>> start_parse_block_after_colon(crate::syntax::parser::Ps p0) {
    return prism_rtl::make_rc<ParseBlockAfterColon>(p0);
}


/// ParseIndentedBlock: unbounded fn Ps -> ((Block, Ps))
std::tuple<crate::syntax::Block, crate::syntax::parser::Ps> parse_indented_block(const crate::syntax::parser::Ps& p0) {
    auto start = crate::syntax::parser::here(p0);
    auto [stmts, q] = stmts_until(crate::syntax::parser::adv(p0), true);
    return std::tuple{crate::syntax::Block{.stmts = stmts, .inline_ = false, .span = crate::syntax::parser::to(start, crate::syntax::parser::prev(q))}, q};
}


prism_rtl::Turn<std::tuple<crate::syntax::Block, crate::syntax::parser::Ps>> ParseIndentedBlock::cycle() const {
    const auto& p0 = this->p0;
    auto start = crate::syntax::parser::here(p0);
    auto p0_1 = p0;
    return call_then(start_stmts_until(crate::syntax::parser::adv(p0_1), true), [=](std::tuple<Array<crate::syntax::Stmt>, crate::syntax::parser::Ps> stmts_until_1826) {
        return ({
            auto [stmts, q] = stmts_until_1826;
            (prism_rtl::finished(std::tuple{crate::syntax::Block{.stmts = stmts, .inline_ = false, .span = crate::syntax::parser::to(start, crate::syntax::parser::prev(q))}, q}));
        });
    });
}


/// `Start ParseIndentedBlock, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Block, crate::syntax::parser::Ps>> start_parse_indented_block(crate::syntax::parser::Ps p0) {
    return prism_rtl::make_rc<ParseIndentedBlock>(p0);
}


/// ParseBlockUntilEof: unbounded fn Ps, Range -> ((Block, Ps))
std::tuple<crate::syntax::Block, crate::syntax::parser::Ps> parse_block_until_eof(const crate::syntax::parser::Ps& p_, const crate::syntax::Range& span) {
    auto [stmts, q] = crate::syntax::parser::at_eof(p_)
        ? std::tuple{Array<crate::syntax::Stmt>{}, p_}
        : stmts_until(p_, false);
    return std::tuple{crate::syntax::Block{.stmts = stmts, .inline_ = false, .span = span}, q};
}


prism_rtl::Turn<std::tuple<crate::syntax::Block, crate::syntax::parser::Ps>> ParseBlockUntilEof::cycle() const {
    const auto& p_ = this->p_;
    const auto& span = this->span;
    auto [stmts, q] = crate::syntax::parser::at_eof(p_)
        ? std::tuple{Array<crate::syntax::Stmt>{}, p_}
        : stmts_until(p_, false);
    return prism_rtl::finished(std::tuple{crate::syntax::Block{.stmts = stmts, .inline_ = false, .span = span}, q});
}


/// `Start ParseBlockUntilEof, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Block, crate::syntax::parser::Ps>> start_parse_block_until_eof(crate::syntax::parser::Ps p_, crate::syntax::Range span) {
    return prism_rtl::make_rc<ParseBlockUntilEof>(p_, span);
}


/// StmtsUntil: unbounded fn Ps, Bool -> (([Stmt], Ps))
std::tuple<Array<crate::syntax::Stmt>, crate::syntax::parser::Ps> stmts_until(const crate::syntax::parser::Ps& p0, const bool& indented) {
    std::tuple<Array<crate::syntax::Stmt>, crate::syntax::parser::Ps> this_ = std::tuple{Array<crate::syntax::Stmt>{}, p0};
    Array<crate::syntax::Stmt> stmts = Array<crate::syntax::Stmt>{};
    crate::syntax::parser::Ps p_ = p0;
    bool going = true;
    while (going) {
        auto [st, q] = parse_stmt(p_);
        if (!q->bad) {
            stmts = crate::prelude::push(stmts, st);
        }
        p_ = crate::syntax::parser::recovered(q);
        {
            auto&& _m = crate::syntax::parser::kind(p_);
            if (prism_rtl::is<crate::syntax::lexer::TokKind::KLaySep>(_m)) {
                p_ = crate::syntax::parser::adv(p_);
                if ((!prism_rtl::val(indented)) && crate::syntax::parser::at_eof(p_)) {
                    going = false;
                }
            } else if (prism_rtl::is<crate::syntax::lexer::TokKind::KLayClose>(_m)) {
                p_ = crate::syntax::parser::adv(p_);
                if (prism_rtl::val(indented) || crate::syntax::parser::at_eof(p_)) {
                    going = false;
                }
            } else if (prism_rtl::is<crate::syntax::lexer::TokKind::KEof>(_m)) {
                going = false;
            } else {
                p_ = crate::syntax::parser::recover(crate::syntax::parser::complain(p_, Text::lit("expected the end of the statement")));
            }
        }
    }
    this_ = std::tuple{stmts, p_};
    return this_;
}


prism_rtl::Turn<std::tuple<Array<crate::syntax::Stmt>, crate::syntax::parser::Ps>> StmtsUntil::cycle() const {
    const auto& p0 = this->p0;
    const auto& indented = this->indented;
    std::tuple<Array<crate::syntax::Stmt>, crate::syntax::parser::Ps> this_ = std::tuple{Array<crate::syntax::Stmt>{}, p0};
    Array<crate::syntax::Stmt> stmts = Array<crate::syntax::Stmt>{};
    crate::syntax::parser::Ps p_ = p0;
    bool going = true;
    return call_then(loop_job(std::tuple{this_, going, p_, stmts}, ({
        auto indented_1 = prism_rtl::val(indented);
        [=](std::tuple<std::tuple<Array<crate::syntax::Stmt>, crate::syntax::parser::Ps>, bool, crate::syntax::parser::Ps, Array<crate::syntax::Stmt>> _p0) {
        auto this_ = std::get<0>(_p0);
        auto going = std::get<1>(_p0);
        auto p_ = std::get<2>(_p0);
        auto stmts = std::get<3>(_p0);
        return going
            ? ({
            auto [st, q] = parse_stmt(p_);
            if (!q->bad) {
                stmts = crate::prelude::push(stmts, st);
            }
            p_ = crate::syntax::parser::recovered(q);
            {
                auto&& _m = crate::syntax::parser::kind(p_);
                if (prism_rtl::is<crate::syntax::lexer::TokKind::KLaySep>(_m)) {
                    p_ = crate::syntax::parser::adv(p_);
                    if ((!indented_1) && crate::syntax::parser::at_eof(p_)) {
                        going = false;
                    }
                } else if (prism_rtl::is<crate::syntax::lexer::TokKind::KLayClose>(_m)) {
                    p_ = crate::syntax::parser::adv(p_);
                    if (indented_1 || crate::syntax::parser::at_eof(p_)) {
                        going = false;
                    }
                } else if (prism_rtl::is<crate::syntax::lexer::TokKind::KEof>(_m)) {
                    going = false;
                } else {
                    p_ = crate::syntax::parser::recover(crate::syntax::parser::complain(p_, Text::lit("expected the end of the statement")));
                }
            }
            Expected<std::tuple<std::tuple<Array<crate::syntax::Stmt>, crate::syntax::parser::Ps>, bool, crate::syntax::parser::Ps, Array<crate::syntax::Stmt>>, std::tuple<std::tuple<Array<crate::syntax::Stmt>, crate::syntax::parser::Ps>, bool, crate::syntax::parser::Ps, Array<crate::syntax::Stmt>>>(std::tuple{this_, going, p_, stmts});
        })
            : Expected<std::tuple<std::tuple<Array<crate::syntax::Stmt>, crate::syntax::parser::Ps>, bool, crate::syntax::parser::Ps, Array<crate::syntax::Stmt>>, std::tuple<std::tuple<Array<crate::syntax::Stmt>, crate::syntax::parser::Ps>, bool, crate::syntax::parser::Ps, Array<crate::syntax::Stmt>>>(unexpected(std::tuple{this_, going, p_, stmts}));
    };
    })), [=](std::tuple<std::tuple<Array<crate::syntax::Stmt>, crate::syntax::parser::Ps>, bool, crate::syntax::parser::Ps, Array<crate::syntax::Stmt>> _p0) {
        auto this_ = std::get<0>(_p0);
        auto going = std::get<1>(_p0);
        auto p_ = std::get<2>(_p0);
        auto stmts = std::get<3>(_p0);
        return ({
            this_ = std::tuple{stmts, p_};
            (prism_rtl::finished(this_));
        });
    });
}


/// `Start StmtsUntil, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::syntax::Stmt>, crate::syntax::parser::Ps>> start_stmts_until(crate::syntax::parser::Ps p0, bool indented) {
    return prism_rtl::make_rc<StmtsUntil>(p0, indented);
}


/// ParseStmt: unbounded fn Ps -> ((Stmt, Ps))
std::tuple<crate::syntax::Stmt, crate::syntax::parser::Ps> parse_stmt(const crate::syntax::parser::Ps& p_) {
    auto start = crate::syntax::parser::here(p_);
    auto [kind, q] = stmt_kind_of(p_, start);
    return std::tuple{crate::syntax::Stmt{.kind = kind, .span = crate::syntax::parser::to(start, crate::syntax::parser::prev(q))}, q};
}


prism_rtl::Turn<std::tuple<crate::syntax::Stmt, crate::syntax::parser::Ps>> ParseStmt::cycle() const {
    const auto& p_ = this->p_;
    auto start = crate::syntax::parser::here(p_);
    auto p__1 = p_;
    return call_then(start_stmt_kind_of(p__1, start), [=](std::tuple<crate::syntax::StmtKind, crate::syntax::parser::Ps> stmt_kind_of_3254) {
        return ({
            auto [kind, q] = stmt_kind_of_3254;
            (prism_rtl::finished(std::tuple{crate::syntax::Stmt{.kind = kind, .span = crate::syntax::parser::to(start, crate::syntax::parser::prev(q))}, q}));
        });
    });
}


/// `Start ParseStmt, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Stmt, crate::syntax::parser::Ps>> start_parse_stmt(crate::syntax::parser::Ps p_) {
    return prism_rtl::make_rc<ParseStmt>(p_);
}


/// StmtKindOf: unbounded fn Ps, Range -> ((StmtKind, Ps))
std::tuple<crate::syntax::StmtKind, crate::syntax::parser::Ps> stmt_kind_of(const crate::syntax::parser::Ps& p_, const crate::syntax::Range& start) {
    auto&& _m = crate::syntax::parser::kind(p_);
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m3409_0_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m3409_0_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        if (m3409_0_0 == Text::lit("emit")) {
            if (m3409_0_1 == Text::lit("")) {
                auto [r, q] = crate::syntax::parser::types::parse_row(crate::syntax::parser::adv(p_));
                return std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SEmit{r}), q};
            }
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m3409_1_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m3409_1_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        if (m3409_1_0 == Text::lit("let")) {
            if (m3409_1_1 == Text::lit("")) {
                auto [pattern, p1] = crate::syntax::parser::types::parse_pattern(crate::syntax::parser::adv(p_), false);
                auto [ty_opt, p2] = crate::syntax::parser::decls::optional_annotation(p1);
                auto [value, p3] = crate::syntax::parser::expr::parse_rhs_expr(crate::syntax::parser::expect_op(p2, Text::lit("=")));
                return std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SLet{pattern, ty_opt, value}), p3};
            }
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m3409_2_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m3409_2_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        if (m3409_2_0 == Text::lit("fn")) {
            if (m3409_2_1 == Text::lit("")) {
                auto [f, q] = crate::syntax::parser::decls::parse_fn_clause(p_);
                return std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SFn{f}), q};
            }
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m3409_3_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m3409_3_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        if (m3409_3_0 == Text::lit("ignore")) {
            if (m3409_3_1 == Text::lit("")) {
                if (crate::syntax::parser::at_op(crate::syntax::parser::adv(p_), Text::lit("<-"))) {
                    auto [e, q] = crate::syntax::parser::expr::parse_rhs_expr(crate::syntax::parser::adv(crate::syntax::parser::adv(p_)));
                    return std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SIgnore{e}), q};
                }
            }
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& w = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m3409_4_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        if (m3409_4_1 == Text::lit("")) {
            if ((w == Text::lit("require")) || (w == Text::lit("forbid"))) {
                auto [c, p1] = crate::syntax::parser::expr::parse_rhs_expr(crate::syntax::parser::adv(p_));
                auto q = crate::syntax::parser::at_comma(p1)
                    ? crate::syntax::parser::error_at(p1, crate::syntax::parser::here(p1), prism_rtl::cat("`", w, "` takes its condition alone, with no error value after a comma (decisions.md D15): a failed guard under `~` raises `Prelude.Unmet` (D11), and a comma after a guard belongs to a call at the head of its condition, as in `require Clear g, from, corner`"))
                    : p1;
                return w == Text::lit("require")
                    ? std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SRequire{c}), q}
                    : std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SForbid{c}), q};
            }
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m3409_5_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m3409_5_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        if (m3409_5_0 == Text::lit("while")) {
            if (m3409_5_1 == Text::lit("")) {
                auto [cond, p1] = crate::syntax::parser::expr::parse_cond(crate::syntax::parser::adv(p_), true);
                auto [body, q] = parse_block_after_colon(p1);
                return std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SWhile{cond, body}), q};
            }
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m3409_6_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m3409_6_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        if (m3409_6_0 == Text::lit("return")) {
            if (m3409_6_1 == Text::lit("")) {
                auto p1 = crate::syntax::parser::out_of_scope(crate::syntax::parser::adv(p_), crate::syntax::parser::here(p_), Text::lit("`T monad:` blocks and `^Monad`"), Text::lit("`return` ends a monad block, which is out of this compiler"));
                auto [e, q] = crate::syntax::parser::expr::parse_rhs_expr(p1);
                return std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SReturn{e}), q};
            }
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m)) {
        if (crate::syntax::parser::kind_at(p_, Nat(1u)) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KColon{})) {
            return crate::syntax::parser::kind_at(p_, Nat(2u)) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KLayOpen{})
                ? ({
                auto [name, p1] = crate::syntax::parser::parse_sname(p_);
                auto [body, q] = parse_block_after_colon(p1);
                std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SWidget{crate::syntax::decls::WidgetDecl{.name = name, .body = body, .span = crate::syntax::parser::to(start, prism_rtl::val(body).span)}}), q};
            })
                : ({
                auto [sig, q] = crate::syntax::parser::decls::parse_signature(p_);
                std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SSignature{sig}), q};
            });
        }
    }
    {
        return other_stmt(p_);
    }
}


prism_rtl::Turn<std::tuple<crate::syntax::StmtKind, crate::syntax::parser::Ps>> StmtKindOf::cycle() const {
    const auto& p_ = this->p_;
    const auto& start = this->start;
    return ({
        auto&& _m = crate::syntax::parser::kind(p_);
        prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& m3409_0_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m3409_0_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        (m3409_0_0 == Text::lit("emit")) && (m3409_0_1 == Text::lit(""));
    }) ? ({
        auto&& m3409_0_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m3409_0_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        ({
        auto p__1 = p_;
        call_then(crate::syntax::parser::types::start_parse_row(crate::syntax::parser::adv(p__1)), [=](std::tuple<crate::syntax::Row_, crate::syntax::parser::Ps> parse_row_3466) {
        return ({
            auto [r, q] = parse_row_3466;
            (prism_rtl::finished(std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SEmit{r}), q}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& m3409_1_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m3409_1_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        (m3409_1_0 == Text::lit("let")) && (m3409_1_1 == Text::lit(""));
    }) ? ({
        auto&& m3409_1_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m3409_1_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        ({
        auto p__1 = p_;
        call_then(crate::syntax::parser::types::start_parse_pattern(crate::syntax::parser::adv(p__1), false), [=](std::tuple<crate::syntax::Pattern_, crate::syntax::parser::Ps> parse_pattern_3555) {
        return ({
            auto [pattern, p1] = parse_pattern_3555;
            call_then(crate::syntax::parser::decls::start_optional_annotation(p1), [=](std::tuple<std::optional<crate::syntax::Type>, crate::syntax::parser::Ps> optional_annotation_3609) {
            return ({
                auto [ty_opt, p2] = optional_annotation_3609;
                call_then(crate::syntax::parser::expr::start_parse_rhs_expr(crate::syntax::parser::expect_op(p2, Text::lit("="))), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_rhs_expr_3659) {
                return ({
                    auto [value, p3] = parse_rhs_expr_3659;
                    (prism_rtl::finished(std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SLet{pattern, ty_opt, value}), p3}));
                });
            });
            });
        });
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& m3409_2_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m3409_2_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        (m3409_2_0 == Text::lit("fn")) && (m3409_2_1 == Text::lit(""));
    }) ? ({
        auto&& m3409_2_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m3409_2_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        ({
        auto p__1 = p_;
        call_then(crate::syntax::parser::decls::start_parse_fn_clause(p__1), [=](std::tuple<crate::syntax::decls::FnClause, crate::syntax::parser::Ps> parse_fn_clause_3775) {
        return ({
            auto [f, q] = parse_fn_clause_3775;
            (prism_rtl::finished(std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SFn{f}), q}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& m3409_3_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m3409_3_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        (m3409_3_0 == Text::lit("ignore")) && (m3409_3_1 == Text::lit("")) && crate::syntax::parser::at_op(crate::syntax::parser::adv(p_), Text::lit("<-"));
    }) ? ({
        auto&& m3409_3_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m3409_3_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        ({
        auto p__1 = p_;
        call_then(crate::syntax::parser::expr::start_parse_rhs_expr(crate::syntax::parser::adv(crate::syntax::parser::adv(p__1))), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_rhs_expr_3881) {
        return ({
            auto [e, q] = parse_rhs_expr_3881;
            (prism_rtl::finished(std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SIgnore{e}), q}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& w = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m3409_4_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        (m3409_4_1 == Text::lit("")) && ((w == Text::lit("require")) || (w == Text::lit("forbid")));
    }) ? ({
        auto&& w = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m3409_4_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        ({
        auto p__1 = p_;
        call_then(crate::syntax::parser::expr::start_parse_rhs_expr(crate::syntax::parser::adv(p__1)), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_rhs_expr_4174) {
        return ({
            auto [c, p1] = parse_rhs_expr_4174;
            auto q = crate::syntax::parser::at_comma(p1)
                ? crate::syntax::parser::error_at(p1, crate::syntax::parser::here(p1), prism_rtl::cat("`", w, "` takes its condition alone, with no error value after a comma (decisions.md D15): a failed guard under `~` raises `Prelude.Unmet` (D11), and a comma after a guard belongs to a call at the head of its condition, as in `require Clear g, from, corner`"))
                : p1;
            w == Text::lit("require")
            ? prism_rtl::finished(std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SRequire{c}), q})
            : prism_rtl::finished(std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SForbid{c}), q});
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& m3409_5_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m3409_5_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        (m3409_5_0 == Text::lit("while")) && (m3409_5_1 == Text::lit(""));
    }) ? ({
        auto&& m3409_5_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m3409_5_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        ({
        auto p__1 = p_;
        call_then(crate::syntax::parser::expr::start_parse_cond(crate::syntax::parser::adv(p__1), true), [=](std::tuple<crate::syntax::Cond, crate::syntax::parser::Ps> parse_cond_4630) {
        return ({
            auto [cond, p1] = parse_cond_4630;
            call_then(start_parse_block_after_colon(p1), [=](std::tuple<crate::syntax::Block, crate::syntax::parser::Ps> parse_block_after_colon_4680) {
            return ({
                auto [body, q] = parse_block_after_colon_4680;
                (prism_rtl::finished(std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SWhile{cond, body}), q}));
            });
        });
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& m3409_6_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m3409_6_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        (m3409_6_0 == Text::lit("return")) && (m3409_6_1 == Text::lit(""));
    }) ? ({
        auto&& m3409_6_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m3409_6_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        ({
        auto p1 = crate::syntax::parser::out_of_scope(crate::syntax::parser::adv(p_), crate::syntax::parser::here(p_), Text::lit("`T monad:` blocks and `^Monad`"), Text::lit("`return` ends a monad block, which is out of this compiler"));
        call_then(crate::syntax::parser::expr::start_parse_rhs_expr(p1), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_rhs_expr_4926) {
        return ({
            auto [e, q] = parse_rhs_expr_4926;
            (prism_rtl::finished(std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SReturn{e}), q}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m) && ({
        (crate::syntax::parser::kind_at(p_, Nat(1u)) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KColon{}));
    }) ? crate::syntax::parser::kind_at(p_, Nat(2u)) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KLayOpen{})
        ? ({
        auto [name, p1] = crate::syntax::parser::parse_sname(p_);
        auto start_1 = start;
        call_then(start_parse_block_after_colon(p1), [=](std::tuple<crate::syntax::Block, crate::syntax::parser::Ps> parse_block_after_colon_5173) {
        return ({
            auto [body, q] = parse_block_after_colon_5173;
            (prism_rtl::finished(std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SWidget{crate::syntax::decls::WidgetDecl{.name = name, .body = body, .span = crate::syntax::parser::to(start_1, prism_rtl::val(body).span)}}), q}));
        });
    });
    })
        : ({
        auto p__1 = p_;
        call_then(crate::syntax::parser::decls::start_parse_signature(p__1), [=](std::tuple<crate::syntax::decls::Signature, crate::syntax::parser::Ps> parse_signature_5328) {
        return ({
            auto [sig, q] = parse_signature_5328;
            (prism_rtl::finished(std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SSignature{sig}), q}));
        });
    });
    })
        : prism_rtl::more(prism_rtl::rc(OtherStmt(p_)));
    });
}


/// `Start StmtKindOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::StmtKind, crate::syntax::parser::Ps>> start_stmt_kind_of(crate::syntax::parser::Ps p_, crate::syntax::Range start) {
    return prism_rtl::make_rc<StmtKindOf>(p_, start);
}


/// OtherStmt: unbounded fn Ps -> ((StmtKind, Ps))
std::tuple<crate::syntax::StmtKind, crate::syntax::parser::Ps> other_stmt(const crate::syntax::parser::Ps& p_) {
    auto [upd, u] = parse_update_stmt(p_);
    auto [pattern, b] = crate::syntax::parser::types::parse_pattern(p_, true);
    return !u->bad
        ? std::tuple{upd, u}
        : (!b->bad) && crate::syntax::parser::at_op(b, Text::lit("<-"))
        ? ({
        auto [value, p1] = crate::syntax::parser::expr::parse_rhs_expr(crate::syntax::parser::adv(b));
        auto [then_step_opt, p2] = crate::syntax::parser::at_kw(p1, Text::lit("then"))
            ? optional_rhs(crate::syntax::parser::adv(p1))
            : std::tuple{std::optional<crate::syntax::Expr>{}, p1};
        crate::syntax::parser::at_kw(p2, Text::lit("then"))
        ? std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SExpr{crate::syntax::parser::decls::no_expr()}), crate::syntax::parser::error_at(p2, crate::syntax::parser::here(p2), Text::lit("`then` does not associate: a hold has one start and one step"))}
        : std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SBind{pattern, value, then_step_opt}), p2};
    })
        : ({
        auto [e, p1] = crate::syntax::parser::expr::parse_rhs_expr(p_);
        crate::syntax::parser::at_op(p1, Text::lit("<-"))
        ? std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SExpr{e}), crate::syntax::parser::error_at(p1, crate::syntax::parser::here(p1), Text::lit("the left side of `<-` is not a pattern"))}
        : crate::syntax::parser::at_kw(p1, Text::lit("then"))
        ? std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SExpr{e}), crate::syntax::parser::error_at(p1, crate::syntax::parser::here(p1), Text::lit("`then` belongs to a hold: `$x <- start then step`"))}
        : std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SExpr{e}), p1};
    });
}


prism_rtl::Turn<std::tuple<crate::syntax::StmtKind, crate::syntax::parser::Ps>> OtherStmt::cycle() const {
    const auto& p_ = this->p_;
    auto p__1 = p_;
    return call_then(start_parse_update_stmt(p__1), [=](std::tuple<crate::syntax::StmtKind, crate::syntax::parser::Ps> parse_update_stmt_5569) {
        return ({
            auto [upd, u] = parse_update_stmt_5569;
            call_then(crate::syntax::parser::types::start_parse_pattern(p__1, true), [=](std::tuple<crate::syntax::Pattern_, crate::syntax::parser::Ps> parse_pattern_5612) {
            return ({
                auto [pattern, b] = parse_pattern_5612;
                !u->bad
                ? prism_rtl::finished(std::tuple{upd, u})
                : (!b->bad) && crate::syntax::parser::at_op(b, Text::lit("<-"))
                ? call_then(crate::syntax::parser::expr::start_parse_rhs_expr(crate::syntax::parser::adv(b)), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_rhs_expr_5733) {
                return ({
                    auto [value, p1] = parse_rhs_expr_5733;
                    auto [then_step_opt, p2] = crate::syntax::parser::at_kw(p1, Text::lit("then"))
                        ? optional_rhs(crate::syntax::parser::adv(p1))
                        : std::tuple{std::optional<crate::syntax::Expr>{}, p1};
                    (crate::syntax::parser::at_kw(p2, Text::lit("then"))
                    ? prism_rtl::finished(std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SExpr{crate::syntax::parser::decls::no_expr()}), crate::syntax::parser::error_at(p2, crate::syntax::parser::here(p2), Text::lit("`then` does not associate: a hold has one start and one step"))})
                    : prism_rtl::finished(std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SBind{pattern, value, then_step_opt}), p2}));
                });
            })
                : call_then(crate::syntax::parser::expr::start_parse_rhs_expr(p__1), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_rhs_expr_6069) {
                return ({
                    auto [e, p1] = parse_rhs_expr_6069;
                    (crate::syntax::parser::at_op(p1, Text::lit("<-"))
                    ? prism_rtl::finished(std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SExpr{e}), crate::syntax::parser::error_at(p1, crate::syntax::parser::here(p1), Text::lit("the left side of `<-` is not a pattern"))})
                    : crate::syntax::parser::at_kw(p1, Text::lit("then"))
                    ? prism_rtl::finished(std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SExpr{e}), crate::syntax::parser::error_at(p1, crate::syntax::parser::here(p1), Text::lit("`then` belongs to a hold: `$x <- start then step`"))})
                    : prism_rtl::finished(std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SExpr{e}), p1}));
                });
            });
            });
        });
        });
    });
}


/// `Start OtherStmt, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::StmtKind, crate::syntax::parser::Ps>> start_other_stmt(crate::syntax::parser::Ps p_) {
    return prism_rtl::make_rc<OtherStmt>(p_);
}


/// OptionalRhs: unbounded fn Ps -> ((?Expr, Ps))
std::tuple<std::optional<crate::syntax::Expr>, crate::syntax::parser::Ps> optional_rhs(const crate::syntax::parser::Ps& p_) {
    auto [e, q] = crate::syntax::parser::expr::parse_rhs_expr(p_);
    return std::tuple{std::optional(e), q};
}


prism_rtl::Turn<std::tuple<std::optional<crate::syntax::Expr>, crate::syntax::parser::Ps>> OptionalRhs::cycle() const {
    const auto& p_ = this->p_;
    auto p__1 = p_;
    return call_then(crate::syntax::parser::expr::start_parse_rhs_expr(p__1), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_rhs_expr_6427) {
        return ({
            auto [e, q] = parse_rhs_expr_6427;
            (prism_rtl::finished(std::tuple{std::optional(e), q}));
        });
    });
}


/// `Start OptionalRhs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<std::optional<crate::syntax::Expr>, crate::syntax::parser::Ps>> start_optional_rhs(crate::syntax::parser::Ps p_) {
    return prism_rtl::make_rc<OptionalRhs>(p_);
}


/// ParseUpdateStmt: unbounded fn Ps -> ((StmtKind, Ps))
std::tuple<crate::syntax::StmtKind, crate::syntax::parser::Ps> parse_update_stmt(const crate::syntax::parser::Ps& p_) {
    auto [target, p1] = parse_reference(p_);
    auto op = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = crate::syntax::parser::kind(p1);
        if (prism_rtl::is<crate::syntax::lexer::TokKind::KOp>(_m)) {
            auto&& o = prism_rtl::as<crate::syntax::lexer::TokKind::KOp>(_m).a0;
            _v.set(o);
            goto _done;
        }
        {
            _v.set(Text::lit(""));
            goto _done;
        }
    _done:
        _v.take();
    });
    return p1->bad || (!(((((op == Text::lit("<=")) || (op == Text::lit("+="))) || (op == Text::lit("-="))) || (op == Text::lit("*="))) || (op == Text::lit("/="))))
        ? std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SExpr{crate::syntax::parser::decls::no_expr()}), crate::syntax::parser::fail(p1)}
        : ({
        auto [value, q] = crate::syntax::parser::expr::parse_rhs_expr(crate::syntax::parser::adv(p1));
        op == Text::lit("<=")
        ? std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SSet{target, value}), q}
        : std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SAccum{target, op, value}), q};
    });
}


prism_rtl::Turn<std::tuple<crate::syntax::StmtKind, crate::syntax::parser::Ps>> ParseUpdateStmt::cycle() const {
    const auto& p_ = this->p_;
    auto p__1 = p_;
    return call_then(start_parse_reference(p__1), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_reference_6741) {
        return ({
            auto [target, p1] = parse_reference_6741;
            auto op = ({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                auto&& _m = crate::syntax::parser::kind(p1);
                if (prism_rtl::is<crate::syntax::lexer::TokKind::KOp>(_m)) {
                    auto&& o = prism_rtl::as<crate::syntax::lexer::TokKind::KOp>(_m).a0;
                    _v.set(o);
                    goto _done;
                }
                {
                    _v.set(Text::lit(""));
                    goto _done;
                }
            _done:
                _v.take();
            });
            p1->bad || (!(((((op == Text::lit("<=")) || (op == Text::lit("+="))) || (op == Text::lit("-="))) || (op == Text::lit("*="))) || (op == Text::lit("/="))))
            ? prism_rtl::finished(std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SExpr{crate::syntax::parser::decls::no_expr()}), crate::syntax::parser::fail(p1)})
            : call_then(crate::syntax::parser::expr::start_parse_rhs_expr(crate::syntax::parser::adv(p1)), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_rhs_expr_6989) {
            return ({
                auto [value, q] = parse_rhs_expr_6989;
                op == Text::lit("<=")
                ? prism_rtl::finished(std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SSet{target, value}), q})
                : prism_rtl::finished(std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SAccum{target, op, value}), q});
            });
        });
        });
    });
}


/// `Start ParseUpdateStmt, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::StmtKind, crate::syntax::parser::Ps>> start_parse_update_stmt(crate::syntax::parser::Ps p_) {
    return prism_rtl::make_rc<ParseUpdateStmt>(p_);
}


/// ParseReference: unbounded fn Ps -> ((Expr, Ps))
std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_reference(const crate::syntax::parser::Ps& p_) {
    auto&& _m = crate::syntax::parser::kind(p_);
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        if (crate::syntax::lexer::chars::has_prefix(prism_rtl::val(n).sigils, Text::lit("&"))) {
            auto start = crate::syntax::parser::here(p_);
            auto [name, p1] = crate::syntax::parser::parse_sname(p_);
            return crate::syntax::parser::is_upper_name(name)
                ? ({
                auto p2 = crate::syntax::parser::out_of_scope(p1, prism_rtl::val(name).span, Text::lit("named lenses `&Home` and `Over`"), prism_rtl::cat("the named lens `", crate::syntax::parser::name_text(name), "` is out of this compiler; write its path, `&_.score.home`"));
                auto [inner, q] = parse_reference(p2);
                auto callee = crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EName{name})), .span = start};
                std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ECall{prism_rtl::rc(callee), Array(std::vector{crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = inner, .span = prism_rtl::val(inner).span}}), false, false})), .span = crate::syntax::parser::to(start, prism_rtl::val(inner).span)}, q};
            })
                : lens_steps(crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EName{name})), .span = prism_rtl::val(name).span}, p1);
        }
    }
    {
        return std::tuple{crate::syntax::parser::decls::no_expr(), crate::syntax::parser::fail(p_)};
    }
}


prism_rtl::Turn<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> ParseReference::cycle() const {
    const auto& p_ = this->p_;
    return ({
        auto&& _m = crate::syntax::parser::kind(p_);
        prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m) && ({
        auto&& n = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        crate::syntax::lexer::chars::has_prefix(prism_rtl::val(n).sigils, Text::lit("&"));
    }) ? ({
        auto&& n = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        ({
        auto start = crate::syntax::parser::here(p_);
        auto [name, p1] = crate::syntax::parser::parse_sname(p_);
        (crate::syntax::parser::is_upper_name(name)
        ? ({
        auto p2 = crate::syntax::parser::out_of_scope(p1, prism_rtl::val(name).span, Text::lit("named lenses `&Home` and `Over`"), prism_rtl::cat("the named lens `", crate::syntax::parser::name_text(name), "` is out of this compiler; write its path, `&_.score.home`"));
        call_then(start_parse_reference(p2), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_reference_7673) {
        return ({
            auto [inner, q] = parse_reference_7673;
            auto callee = crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EName{name})), .span = start};
            (prism_rtl::finished(std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ECall{prism_rtl::rc(callee), Array(std::vector{crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = inner, .span = prism_rtl::val(inner).span}}), false, false})), .span = crate::syntax::parser::to(start, prism_rtl::val(inner).span)}, q}));
        });
    });
    })
        : prism_rtl::finished(lens_steps(crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EName{name})), .span = prism_rtl::val(name).span}, p1)));
    });
    })
        : prism_rtl::finished(std::tuple{crate::syntax::parser::decls::no_expr(), crate::syntax::parser::fail(p_)});
    });
}


/// `Start ParseReference, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> start_parse_reference(crate::syntax::parser::Ps p_) {
    return prism_rtl::make_rc<ParseReference>(p_);
}


/// LensSteps: unbounded fn Expr, Ps -> ((Expr, Ps))
std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> lens_steps(const crate::syntax::Expr& e0, const crate::syntax::parser::Ps& p0) {
    std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> this_ = std::tuple{e0, p0};
    crate::syntax::Expr e = e0;
    crate::syntax::parser::Ps p_ = p0;
    bool going = true;
    while (going && (!p_.bad)) {
        ({
            __label__ _done;
            prism_rtl::Slot<Unit> _v;
            auto&& _m = crate::syntax::parser::kind(p_);
            if (prism_rtl::is<crate::syntax::lexer::TokKind::KDot>(_m) && !prism_rtl::as<crate::syntax::lexer::TokKind::KDot>(_m).a0) {
                _v.set(({
                    auto p1 = crate::syntax::parser::adv(p_);
                    auto t = crate::syntax::parser::here(p1);
                    ({
                        __label__ _done;
                        prism_rtl::Slot<Unit> _v;
                        auto&& _m = crate::syntax::parser::kind(p1);
                        if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m)) {
                            auto&& f = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
                            if ((prism_rtl::val(f).sigils == Text::lit("")) && (prism_rtl::val(f).case_ == crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseLower{}))) {
                                _v.set(({
                                    e = crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EField{prism_rtl::rc(e), Text::lit(""), crate::syntax::Ident{.name = or_(index(f->path_, Nat(0u)), Text::lit("")), .span = t}})), .span = crate::syntax::parser::to(e.span, t)};
                                    p_ = crate::syntax::parser::adv(p1);
                                    Unit{};
                                }));
                                goto _done;
                            }
                        }
                        if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
                            auto&& u8306_1_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
                            if (u8306_1_0 == Text::lit("key")) {
                                _v.set(({
                                    e = crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EField{prism_rtl::rc(e), Text::lit(""), crate::syntax::Ident{.name = Text::lit("key"), .span = t}})), .span = crate::syntax::parser::to(e.span, t)};
                                    p_ = crate::syntax::parser::adv(p1);
                                    Unit{};
                                }));
                                goto _done;
                            }
                        }
                        {
                            _v.set(({
                                p_ = crate::syntax::parser::fail(p1);
                                Unit{};
                            }));
                            goto _done;
                        }
                    _done:
                        _v.take();
                    });
                    Unit{};
                }));
                goto _done;
            }
            if (prism_rtl::is<crate::syntax::lexer::TokKind::KOpen>(_m) && !prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(_m).a1) {
                auto&& u8187_1_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(_m).a0;
                if (u8187_1_0 == Text::lit("[")) {
                    if (prism_rtl::val(crate::syntax::parser::tk(p_)).touches) {
                        _v.set(({
                            auto [index_, p1] = crate::syntax::parser::expr::parse_expr(crate::syntax::parser::adv(p_));
                            auto p2 = crate::syntax::parser::expect_close(p1, Text::lit("["));
                            e = crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EIndex{prism_rtl::rc(e), prism_rtl::rc(index_)})), .span = crate::syntax::parser::to(e.span, crate::syntax::parser::prev(p2))};
                            p_ = p2;
                            Unit{};
                        }));
                        goto _done;
                    }
                }
            }
            {
                _v.set(({
                    going = false;
                    Unit{};
                }));
                goto _done;
            }
        _done:
            _v.take();
        });
    }
    this_ = std::tuple{e, p_};
    return this_;
}

}  // namespace crate::syntax::parser::blocks
