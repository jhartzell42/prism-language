// The modules `Lower.Types`, `Process`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <lower/types/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <syntax/module.hpp>
#include <lower/module.hpp>
#include <syntax/decls/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Lower.Types`, from `target/bootstrap/cpp-src/prismc/lower/types.prism`.
namespace crate::lower::types {





void Holding::show(Printer& p) const {
    if (auto c = std::get_if<ByRef>(&cases())) p.choice("ByRef", {});
    else if (auto c = std::get_if<Owned>(&cases())) p.choice("Owned", {});
    else if (auto c = std::get_if<RcRef>(&cases())) p.choice("RcRef", {});
    else if (auto c = std::get_if<RcOwned>(&cases())) p.choice("RcOwned", {});
}

Pod Holding::to_pod() const {
    return std::holds_alternative<ByRef>(cases()) ? Pod::choice("ByRef", {})
        : std::holds_alternative<Owned>(cases()) ? Pod::choice("Owned", {})
        : std::holds_alternative<RcRef>(cases()) ? Pod::choice("RcRef", {})
        : std::holds_alternative<RcOwned>(cases()) ? Pod::choice("RcOwned", {})
        : Pod();
}

Result<Holding> Holding::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "ByRef" && c->args.size() == 0) return Holding(ByRef{});
        if (c->ctor == "Owned" && c->args.size() == 0) return Holding(Owned{});
        if (c->ctor == "RcRef" && c->args.size() == 0) return Holding(RcRef{});
        if (c->ctor == "RcOwned" && c->args.size() == 0) return Holding(RcOwned{});
    }
    return mismatch<Holding>("a Holding", p);
}


void Layer::show(Printer& p) const {
    if (auto c = std::get_if<LyPlain>(&cases())) p.choice("LyPlain", {});
    else if (auto c = std::get_if<LyDyn>(&cases())) p.choice("LyDyn", {});
    else if (auto c = std::get_if<LyEv>(&cases())) p.choice("LyEv", {});
    else if (auto c = std::get_if<LyBlueprint>(&cases())) p.choice("LyBlueprint", {});
}

Pod Layer::to_pod() const {
    return std::holds_alternative<LyPlain>(cases()) ? Pod::choice("LyPlain", {})
        : std::holds_alternative<LyDyn>(cases()) ? Pod::choice("LyDyn", {})
        : std::holds_alternative<LyEv>(cases()) ? Pod::choice("LyEv", {})
        : std::holds_alternative<LyBlueprint>(cases()) ? Pod::choice("LyBlueprint", {})
        : Pod();
}

Result<Layer> Layer::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "LyPlain" && c->args.size() == 0) return Layer(LyPlain{});
        if (c->ctor == "LyDyn" && c->args.size() == 0) return Layer(LyDyn{});
        if (c->ctor == "LyEv" && c->args.size() == 0) return Layer(LyEv{});
        if (c->ctor == "LyBlueprint" && c->args.size() == 0) return Layer(LyBlueprint{});
    }
    return mismatch<Layer>("a Layer", p);
}


Pod Vl::to_pod() const {
    return std::holds_alternative<VlPlace>(cases()) ? Pod::choice("VlPlace", {prism_rtl::to_pod(std::get<VlPlace>(cases()).a0), prism_rtl::to_pod(std::get<VlPlace>(cases()).a1), prism_rtl::to_pod(std::get<VlPlace>(cases()).a2)})
        : std::holds_alternative<VlOwned>(cases()) ? Pod::choice("VlOwned", {prism_rtl::to_pod(std::get<VlOwned>(cases()).a0), prism_rtl::to_pod(std::get<VlOwned>(cases()).a1)})
        : Pod();
}

Result<Vl> Vl::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "VlPlace" && c->args.size() == 3) return Vl(VlPlace{TRY(prism_rtl::from_pod<crate::lower::model::Ex>(c->args[0])), TRY(prism_rtl::from_pod<Holding>(c->args[1])), TRY(prism_rtl::from_pod<crate::lower::model::OutTy>(c->args[2]))});
        if (c->ctor == "VlOwned" && c->args.size() == 2) return Vl(VlOwned{TRY(prism_rtl::from_pod<crate::lower::model::Ex>(c->args[0])), TRY(prism_rtl::from_pod<crate::lower::model::OutTy>(c->args[1]))});
    }
    return mismatch<Vl>("a Vl", p);
}


/// OutTyOf: unbounded fn Lx, Ty -> OutTy
crate::lower::model::OutTy out_ty_of(const crate::lower::Lx& lx_p0, const crate::check::types::Ty& t_p1) {
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t_p1)) {
        auto&& m1375_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a0;
        auto&& m1375_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a1;
        if (m1375_0_0 == Text::lit("Nat")) {
            if (m1375_0_1.size() == 0u) {
                return crate::lower::model::OutTy(crate::lower::model::OutTy::OutNat{});
            }
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t_p1)) {
        auto&& m1375_1_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a0;
        auto&& m1375_1_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a1;
        if (m1375_1_0 == Text::lit("Int")) {
            if (m1375_1_1.size() == 0u) {
                return crate::lower::model::OutTy(crate::lower::model::OutTy::OutInt{});
            }
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t_p1)) {
        auto&& m1375_2_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a0;
        auto&& m1375_2_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a1;
        if (m1375_2_0 == Text::lit("U8")) {
            if (m1375_2_1.size() == 0u) {
                return crate::lower::model::OutTy(crate::lower::model::OutTy::OutU8{});
            }
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t_p1)) {
        auto&& m1375_3_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a0;
        auto&& m1375_3_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a1;
        if (m1375_3_0 == Text::lit("Float")) {
            if (m1375_3_1.size() == 0u) {
                return crate::lower::model::OutTy(crate::lower::model::OutTy::OutFloat{});
            }
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t_p1)) {
        auto&& m1375_4_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a0;
        auto&& m1375_4_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a1;
        if (m1375_4_0 == Text::lit("Bool")) {
            if (m1375_4_1.size() == 0u) {
                return crate::lower::model::OutTy(crate::lower::model::OutTy::OutBool{});
            }
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t_p1)) {
        auto&& m1375_5_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a0;
        auto&& m1375_5_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a1;
        if (m1375_5_0 == Text::lit("Char")) {
            if (m1375_5_1.size() == 0u) {
                return crate::lower::model::OutTy(crate::lower::model::OutTy::OutChar{});
            }
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t_p1)) {
        auto&& m1375_6_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a0;
        auto&& m1375_6_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a1;
        if (m1375_6_0 == Text::lit("Text")) {
            if (m1375_6_1.size() == 0u) {
                return crate::lower::model::OutTy(crate::lower::model::OutTy::OutText{});
            }
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t_p1)) {
        auto&& m1375_7_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a0;
        auto&& m1375_7_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a1;
        if (m1375_7_0 == Text::lit("unit")) {
            if (m1375_7_1.size() == 0u) {
                return crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{});
            }
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t_p1)) {
        auto&& m1375_8_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a0;
        auto&& m1375_8_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a1;
        if (m1375_8_0 == Text::lit("Path")) {
            if (m1375_8_1.size() == 0u) {
                return crate::lower::model::OutTy(crate::lower::model::OutTy::OutPath{});
            }
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t_p1)) {
        auto&& m1375_9_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a0;
        auto&& m1375_9_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a1;
        if (m1375_9_0 == Text::lit("Cursor")) {
            if (m1375_9_1.size() == 0u) {
                return crate::lower::model::OutTy(crate::lower::model::OutTy::OutCursor{});
            }
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t_p1)) {
        auto&& m1375_10_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a0;
        auto&& m1375_10_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a1;
        if (m1375_10_0 == Text::lit("Regex")) {
            if (m1375_10_1.size() == 0u) {
                return crate::lower::model::OutTy(crate::lower::model::OutTy::OutRegex{});
            }
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t_p1)) {
        auto&& m1375_11_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a0;
        auto&& m1375_11_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a1;
        if (m1375_11_0 == Text::lit("RegexReplacement")) {
            if (m1375_11_1.size() == 0u) {
                return crate::lower::model::OutTy(crate::lower::model::OutTy::OutReplacement{});
            }
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t_p1)) {
        auto&& m1375_12_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a0;
        auto&& m1375_12_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a1;
        if (m1375_12_0 == Text::lit("Duration")) {
            if (m1375_12_1.size() == 0u) {
                return crate::lower::model::OutTy(crate::lower::model::OutTy::OutDuration{});
            }
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t_p1)) {
        auto&& m1375_13_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a0;
        auto&& m1375_13_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a1;
        if (m1375_13_0 == Text::lit("Prelude.Error")) {
            if (m1375_13_1.size() == 0u) {
                return crate::lower::model::OutTy(crate::lower::model::OutTy::OutError{});
            }
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t_p1)) {
        auto&& m1375_14_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a0;
        auto&& m1375_14_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a1;
        if (m1375_14_0 == Text::lit("\000Self"sv)) {
            if (m1375_14_1.size() == 0u) {
                return crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Self"), Array<crate::lower::model::OutTy>{}});
            }
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t_p1)) {
        auto&& m1375_15_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a0;
        auto&& m1375_15_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a1;
        if (m1375_15_0 == Text::lit("Buffer")) {
            if (m1375_15_1.size() == 1u) {
                {
                    auto&& _c1 = index(m1375_15_1, Nat(0u));
                    if (prism_rtl::is_some(_c1)) {
                        auto&& a_p2 = prism_rtl::some_of(_c1);
                        return crate::lower::model::OutTy(crate::lower::model::OutTy::OutArray{prism_rtl::rc(out_ty_of(lx_p0, a_p2))});
                    }
                }
            }
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t_p1)) {
        auto&& m1375_16_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a0;
        auto&& m1375_16_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a1;
        if (m1375_16_0 == Text::lit("Table")) {
            if (m1375_16_1.size() == 2u) {
                {
                    auto&& _c2 = index(m1375_16_1, Nat(0u));
                    if (prism_rtl::is_some(_c2)) {
                        auto&& k_p3 = prism_rtl::some_of(_c2);
                        {
                            auto&& _c1 = index(m1375_16_1, Nat(1u));
                            if (prism_rtl::is_some(_c1)) {
                                auto&& v_p4 = prism_rtl::some_of(_c1);
                                return crate::lower::model::OutTy(crate::lower::model::OutTy::OutArray{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutTuple{Array(std::vector{out_ty_of(lx_p0, k_p3), out_ty_of(lx_p0, v_p4)})}))});
                            }
                        }
                    }
                }
            }
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t_p1)) {
        auto&& m1375_17_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a0;
        auto&& m1375_17_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a1;
        if (m1375_17_0 == Text::lit("\000Event"sv)) {
            if (m1375_17_1.size() == 1u) {
                {
                    auto&& _c1 = index(m1375_17_1, Nat(0u));
                    if (prism_rtl::is_some(_c1)) {
                        auto&& a_p5 = prism_rtl::some_of(_c1);
                        return crate::lower::model::OutTy(crate::lower::model::OutTy::OutEvent{prism_rtl::rc(out_ty_of(lx_p0, a_p5))});
                    }
                }
            }
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t_p1)) {
        auto&& n_p6 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a0;
        auto&& args_p7 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a1;
        return named_ty(lx_p0, n_p6, run_to_end(each_job(args_p7, ({
            auto lx_p0_1 = lx_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::OutTy>(crate::check::types::Ty)>>(prism_rtl::rc([=, lx_p0_1 = std::move(lx_p0_1)](crate::check::types::Ty p0) {
            return ({
                auto lx_p0_1_2 = lx_p0_1;
                entered(once_job([=, lx_p0_1_2 = std::move(lx_p0_1_2)]() {
                return ({
                    auto a_p8 = p0;
                    (prism_rtl::more(prism_rtl::rc(OutTyOf(lx_p0_1_2, a_p8))));
                });
            }));
            });
        })));
        }))));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(t_p1)) {
        auto&& c_p9 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p1).a0;
        auto&& ps_pa = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p1).a1;
        auto&& res_pb = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p1).a2;
        auto c2_pc = crate::lower::inst_col(lx_p0, c_p9);
        return c2_pc == crate::check::types::Col(crate::check::types::Col::CBound{})
            ? crate::lower::model::OutTy(crate::lower::model::OutTy::OutFn{run_to_end(each_job(ps_pa, ({
            auto lx_p0_1 = lx_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::OutTy>(crate::check::types::Ty)>>(prism_rtl::rc([=, lx_p0_1 = std::move(lx_p0_1)](crate::check::types::Ty p0) {
            return ({
                auto lx_p0_1_2 = lx_p0_1;
                entered(once_job([=, lx_p0_1_2 = std::move(lx_p0_1_2)]() {
                return ({
                    auto p_pd = p0;
                    (prism_rtl::more(prism_rtl::rc(OutTyOf(lx_p0_1_2, p_pd))));
                });
            }));
            });
        })));
        }))), prism_rtl::rc(out_ty_of(lx_p0, prism_rtl::deref(prism_rtl::deref(res_pb))))})
            : crate::lower::is_quant_col(lx_p0, c2_pc)
            ? crate::lower::model::OutTy(crate::lower::model::OutTy::OutQuantified{or_(crate::prelude::get(lx_p0.quants, crate::lower::expr::col_name(c2_pc)), Text::lit(""))})
            : crate::lower::model::OutTy(crate::lower::model::OutTy::OutJobFn{prism_rtl::rc(rust_ty_of_params(lx_p0, each(ps_pa, [&](const crate::check::types::Ty& p_pe) { return job_param(p_pe); }))), prism_rtl::rc(out_ty_of(lx_p0, prism_rtl::deref(prism_rtl::deref(res_pb))))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t_p1)) {
        auto&& m1375_20_0 = prism_rtl::as<crate::check::types::Ty::TyTuple>(t_p1).a0;
        if (m1375_20_0.size() == 0u) {
            return crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{});
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t_p1)) {
        auto&& ts_pf = prism_rtl::as<crate::check::types::Ty::TyTuple>(t_p1).a0;
        return crate::lower::model::OutTy(crate::lower::model::OutTy::OutTuple{run_to_end(each_job(ts_pf, ({
            auto lx_p0_1 = lx_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::OutTy>(crate::check::types::Ty)>>(prism_rtl::rc([=, lx_p0_1 = std::move(lx_p0_1)](crate::check::types::Ty p0) {
            return ({
                auto lx_p0_1_2 = lx_p0_1;
                entered(once_job([=, lx_p0_1_2 = std::move(lx_p0_1_2)]() {
                return ({
                    auto a_pg = p0;
                    (prism_rtl::more(prism_rtl::rc(OutTyOf(lx_p0_1_2, a_pg))));
                });
            }));
            });
        })));
        })))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(t_p1)) {
        auto&& e_ph = prism_rtl::as<crate::check::types::Ty::TyArray>(t_p1).a0;
        return crate::lower::model::OutTy(crate::lower::model::OutTy::OutArray{prism_rtl::rc(out_ty_of(lx_p0, prism_rtl::deref(prism_rtl::deref(e_ph))))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(t_p1)) {
        auto&& k_pi = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p1).a0;
        auto&& v_pj = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p1).a1;
        return crate::lower::model::OutTy(crate::lower::model::OutTy::OutMap{prism_rtl::rc(out_ty_of(lx_p0, prism_rtl::deref(prism_rtl::deref(k_pi)))), prism_rtl::rc(out_ty_of(lx_p0, prism_rtl::deref(prism_rtl::deref(v_pj))))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t_p1)) {
        auto&& m1375_24_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a0;
        auto&& i_pk = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a1;
        if (m1375_24_0 == Text::lit("?")) {
            return crate::lower::model::OutTy(crate::lower::model::OutTy::OutOpt{prism_rtl::rc(out_ty_of(lx_p0, prism_rtl::deref(prism_rtl::deref(i_pk))))});
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t_p1)) {
        auto&& m1375_25_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a0;
        auto&& i_pl = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a1;
        if (m1375_25_0 == Text::lit("~")) {
            return crate::lower::model::OutTy(crate::lower::model::OutTy::OutRes{prism_rtl::rc(out_ty_of(lx_p0, prism_rtl::deref(prism_rtl::deref(i_pl))))});
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t_p1)) {
        auto&& m1375_26_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a0;
        auto&& i_pm = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a1;
        if (m1375_26_0 == Text::lit("!")) {
            return crate::lower::model::OutTy(crate::lower::model::OutTy::OutEvent{prism_rtl::rc(out_ty_of(lx_p0, prism_rtl::deref(prism_rtl::deref(i_pm))))});
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t_p1)) {
        auto&& m1375_27_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a0;
        auto&& i_pn = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a1;
        if (m1375_27_0 == Text::lit("$")) {
            return crate::lower::model::OutTy(crate::lower::model::OutTy::OutDyn{prism_rtl::rc(out_ty_of(lx_p0, prism_rtl::deref(prism_rtl::deref(i_pn))))});
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t_p1)) {
        auto&& m1375_28_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a0;
        auto&& i_po = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a1;
        if (m1375_28_0 == Text::lit("&")) {
            return out_ty_of(lx_p0, prism_rtl::deref(prism_rtl::deref(i_po)));
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t_p1)) {
        auto&& i_pp = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a1;
        return out_ty_of(lx_p0, prism_rtl::deref(prism_rtl::deref(i_pp)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyQ>(t_p1)) {
        auto&& n_pq = prism_rtl::as<crate::check::types::Ty::TyQ>(t_p1).a0;
        return crate::lower::model::OutTy(crate::lower::model::OutTy::OutGen{crate::lower::camel(n_pq)});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyRigid>(t_p1)) {
        auto&& n_pr = prism_rtl::as<crate::check::types::Ty::TyRigid>(t_p1).a0;
        return crate::lower::model::OutTy(crate::lower::model::OutTy::OutGen{crate::lower::camel(n_pr)});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFlex>(t_p1)) {
        auto&& n_ps = prism_rtl::as<crate::check::types::Ty::TyFlex>(t_p1).a0;
        auto&& _m = crate::prelude::get(lx_p0.subst, prism_rtl::cat("\'", n_ps));
        if (prism_rtl::is_some(_m)) {
            auto&& x_pt = prism_rtl::some_of(_m);
            return out_ty_of(lx_p0, x_pt);
        }
        if (prism_rtl::is_none(_m)) {
            auto&& _m = crate::prelude::get(lx_p0.quants, prism_rtl::cat("\'", n_ps));
            if (prism_rtl::is_some(_m)) {
                auto&& b_pu = prism_rtl::some_of(_m);
                return crate::lower::model::OutTy(crate::lower::model::OutTy::OutQuantified{b_pu});
            }
            if (prism_rtl::is_none(_m)) {
                return crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{});
            }
            prism_rtl::unreachable("no arm matched");
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAny>(t_p1)) {
        return crate::lower::model::OutTy(crate::lower::model::OutTy::OutShowAny{});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(t_p1)) {
        return crate::lower::model::OutTy(crate::lower::model::OutTy::OutLive{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("crate::Elem"), Array<crate::lower::model::OutTy>{}}))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElemAny>(t_p1)) {
        return crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("crate::Elem"), Array<crate::lower::model::OutTy>{}});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(t_p1)) {
        auto&& i_pv = prism_rtl::as<crate::check::types::Ty::TyAt>(t_p1).a0;
        return blueprint_ty();
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAssoc>(t_p1)) {
        return crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnknown{Text::lit("an associated type")});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyErr>(t_p1)) {
        return crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnknown{Text::lit("a type the checker did not find")});
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::lower::model::OutTy> OutTyOf::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& t_p1 = this->t_p1;
    return ({
        prism_rtl::is<crate::check::types::Ty::TyCon>(t_p1) && ({
        auto&& m1375_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a0;
        auto&& m1375_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a1;
        (m1375_0_0 == Text::lit("Nat")) && (m1375_0_1.size() == 0u);
    }) ? ({
        auto&& m1375_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a0;
        auto&& m1375_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a1;
        prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutNat{}));
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t_p1) && ({
        auto&& m1375_1_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a0;
        auto&& m1375_1_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a1;
        (m1375_1_0 == Text::lit("Int")) && (m1375_1_1.size() == 0u);
    }) ? ({
        auto&& m1375_1_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a0;
        auto&& m1375_1_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a1;
        prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutInt{}));
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t_p1) && ({
        auto&& m1375_2_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a0;
        auto&& m1375_2_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a1;
        (m1375_2_0 == Text::lit("U8")) && (m1375_2_1.size() == 0u);
    }) ? ({
        auto&& m1375_2_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a0;
        auto&& m1375_2_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a1;
        prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutU8{}));
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t_p1) && ({
        auto&& m1375_3_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a0;
        auto&& m1375_3_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a1;
        (m1375_3_0 == Text::lit("Float")) && (m1375_3_1.size() == 0u);
    }) ? ({
        auto&& m1375_3_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a0;
        auto&& m1375_3_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a1;
        prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutFloat{}));
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t_p1) && ({
        auto&& m1375_4_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a0;
        auto&& m1375_4_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a1;
        (m1375_4_0 == Text::lit("Bool")) && (m1375_4_1.size() == 0u);
    }) ? ({
        auto&& m1375_4_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a0;
        auto&& m1375_4_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a1;
        prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutBool{}));
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t_p1) && ({
        auto&& m1375_5_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a0;
        auto&& m1375_5_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a1;
        (m1375_5_0 == Text::lit("Char")) && (m1375_5_1.size() == 0u);
    }) ? ({
        auto&& m1375_5_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a0;
        auto&& m1375_5_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a1;
        prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutChar{}));
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t_p1) && ({
        auto&& m1375_6_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a0;
        auto&& m1375_6_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a1;
        (m1375_6_0 == Text::lit("Text")) && (m1375_6_1.size() == 0u);
    }) ? ({
        auto&& m1375_6_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a0;
        auto&& m1375_6_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a1;
        prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutText{}));
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t_p1) && ({
        auto&& m1375_7_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a0;
        auto&& m1375_7_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a1;
        (m1375_7_0 == Text::lit("unit")) && (m1375_7_1.size() == 0u);
    }) ? ({
        auto&& m1375_7_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a0;
        auto&& m1375_7_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a1;
        prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}));
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t_p1) && ({
        auto&& m1375_8_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a0;
        auto&& m1375_8_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a1;
        (m1375_8_0 == Text::lit("Path")) && (m1375_8_1.size() == 0u);
    }) ? ({
        auto&& m1375_8_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a0;
        auto&& m1375_8_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a1;
        prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutPath{}));
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t_p1) && ({
        auto&& m1375_9_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a0;
        auto&& m1375_9_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a1;
        (m1375_9_0 == Text::lit("Cursor")) && (m1375_9_1.size() == 0u);
    }) ? ({
        auto&& m1375_9_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a0;
        auto&& m1375_9_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a1;
        prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutCursor{}));
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t_p1) && ({
        auto&& m1375_10_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a0;
        auto&& m1375_10_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a1;
        (m1375_10_0 == Text::lit("Regex")) && (m1375_10_1.size() == 0u);
    }) ? ({
        auto&& m1375_10_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a0;
        auto&& m1375_10_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a1;
        prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutRegex{}));
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t_p1) && ({
        auto&& m1375_11_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a0;
        auto&& m1375_11_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a1;
        (m1375_11_0 == Text::lit("RegexReplacement")) && (m1375_11_1.size() == 0u);
    }) ? ({
        auto&& m1375_11_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a0;
        auto&& m1375_11_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a1;
        prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutReplacement{}));
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t_p1) && ({
        auto&& m1375_12_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a0;
        auto&& m1375_12_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a1;
        (m1375_12_0 == Text::lit("Duration")) && (m1375_12_1.size() == 0u);
    }) ? ({
        auto&& m1375_12_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a0;
        auto&& m1375_12_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a1;
        prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutDuration{}));
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t_p1) && ({
        auto&& m1375_13_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a0;
        auto&& m1375_13_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a1;
        (m1375_13_0 == Text::lit("Prelude.Error")) && (m1375_13_1.size() == 0u);
    }) ? ({
        auto&& m1375_13_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a0;
        auto&& m1375_13_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a1;
        prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutError{}));
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t_p1) && ({
        auto&& m1375_14_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a0;
        auto&& m1375_14_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a1;
        (m1375_14_0 == Text::lit("\000Self"sv)) && (m1375_14_1.size() == 0u);
    }) ? ({
        auto&& m1375_14_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a0;
        auto&& m1375_14_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a1;
        prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Self"), Array<crate::lower::model::OutTy>{}}));
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t_p1) && ({
        auto&& m1375_15_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a0;
        auto&& m1375_15_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a1;
        (m1375_15_0 == Text::lit("Buffer")) && (m1375_15_1.size() == 1u) && ({
        auto&& _c1 = index(m1375_15_1, Nat(0u));
        prism_rtl::is_some(_c1);
    });
    }) ? ({
        auto&& m1375_15_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a0;
        auto&& m1375_15_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a1;
        auto&& _c1 = index(m1375_15_1, Nat(0u));
        auto&& a_p2 = prism_rtl::some_of(_c1);
        ({
        auto lx_p0_1 = lx_p0;
        call_then(start_out_ty_of(lx_p0_1, a_p2), [=](crate::lower::model::OutTy out_ty_of_1957) { return prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutArray{prism_rtl::rc(out_ty_of_1957)})); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t_p1) && ({
        auto&& m1375_16_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a0;
        auto&& m1375_16_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a1;
        (m1375_16_0 == Text::lit("Table")) && (m1375_16_1.size() == 2u) && ({
        auto&& _c2 = index(m1375_16_1, Nat(0u));
        prism_rtl::is_some(_c2) && ({
        auto&& k_p3 = prism_rtl::some_of(_c2);
        ({
        auto&& _c1 = index(m1375_16_1, Nat(1u));
        prism_rtl::is_some(_c1);
    });
    });
    });
    }) ? ({
        auto&& m1375_16_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a0;
        auto&& m1375_16_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a1;
        auto&& _c2 = index(m1375_16_1, Nat(0u));
        auto&& k_p3 = prism_rtl::some_of(_c2);
        auto&& _c1 = index(m1375_16_1, Nat(1u));
        auto&& v_p4 = prism_rtl::some_of(_c1);
        ({
        auto lx_p0_1 = lx_p0;
        call_then(start_out_ty_of(lx_p0_1, k_p3), [=](crate::lower::model::OutTy out_ty_of_2023) { return call_then(start_out_ty_of(lx_p0_1, v_p4), [=](crate::lower::model::OutTy out_ty_of_2040) { return prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutArray{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutTuple{Array(std::vector{out_ty_of_2023, out_ty_of_2040})}))})); }); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t_p1) && ({
        auto&& m1375_17_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a0;
        auto&& m1375_17_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a1;
        (m1375_17_0 == Text::lit("\000Event"sv)) && (m1375_17_1.size() == 1u) && ({
        auto&& _c1 = index(m1375_17_1, Nat(0u));
        prism_rtl::is_some(_c1);
    });
    }) ? ({
        auto&& m1375_17_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a0;
        auto&& m1375_17_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a1;
        auto&& _c1 = index(m1375_17_1, Nat(0u));
        auto&& a_p5 = prism_rtl::some_of(_c1);
        ({
        auto lx_p0_1 = lx_p0;
        call_then(start_out_ty_of(lx_p0_1, a_p5), [=](crate::lower::model::OutTy out_ty_of_2099) { return prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutEvent{prism_rtl::rc(out_ty_of_2099)})); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t_p1) ? ({
        auto&& n_p6 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a0;
        auto&& args_p7 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a1;
        ({
        auto args_p7_1 = args_p7;
        auto lx_p0_2 = lx_p0;
        auto n_p6_3 = n_p6;
        call_value(each_job(args_p7_1, ({
        auto lx_p0_2_4 = lx_p0_2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::OutTy>(crate::check::types::Ty)>>(prism_rtl::rc([=, lx_p0_2_4 = std::move(lx_p0_2_4)](crate::check::types::Ty p0) {
        return ({
            auto lx_p0_2_4_4 = lx_p0_2_4;
            entered(once_job([=, lx_p0_2_4_4 = std::move(lx_p0_2_4_4)]() {
            return ({
                auto a_p8 = p0;
                (prism_rtl::more(prism_rtl::rc(OutTyOf(lx_p0_2_4_4, a_p8))));
            });
        }));
        });
    })));
    })), [=, n_p6_3 = std::move(n_p6_3)](Array<crate::lower::model::OutTy> each_2149) { return prism_rtl::more(prism_rtl::rc(NamedTy(lx_p0_2, n_p6_3, each_2149))); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyFn>(t_p1) ? ({
        auto&& c_p9 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p1).a0;
        auto&& ps_pa = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p1).a1;
        auto&& res_pb = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p1).a2;
        ({
        auto c2_pc = crate::lower::inst_col(lx_p0, c_p9);
        c2_pc == crate::check::types::Col(crate::check::types::Col::CBound{})
        ? ({
        auto lx_p0_1 = lx_p0;
        auto ps_pa_2 = ps_pa;
        auto res_pb_3 = prism_rtl::deref(prism_rtl::deref(res_pb));
        call_value(each_job(ps_pa_2, ({
        auto lx_p0_1_4 = lx_p0_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::OutTy>(crate::check::types::Ty)>>(prism_rtl::rc([=, lx_p0_1_4 = std::move(lx_p0_1_4)](crate::check::types::Ty p0) {
        return ({
            auto lx_p0_1_4_4 = lx_p0_1_4;
            entered(once_job([=, lx_p0_1_4_4 = std::move(lx_p0_1_4_4)]() {
            return ({
                auto p_pd = p0;
                (prism_rtl::more(prism_rtl::rc(OutTyOf(lx_p0_1_4_4, p_pd))));
            });
        }));
        });
    })));
    })), [=, res_pb_3 = std::move(res_pb_3)](Array<crate::lower::model::OutTy> each_2430) { return call_then(start_out_ty_of(lx_p0_1, res_pb_3), [=](crate::lower::model::OutTy out_ty_of_2461) { return prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutFn{each_2430, prism_rtl::rc(out_ty_of_2461)})); }); });
    })
        : crate::lower::is_quant_col(lx_p0, c2_pc)
        ? prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutQuantified{or_(crate::prelude::get(prism_rtl::deref(lx_p0).quants, crate::lower::expr::col_name(c2_pc)), Text::lit(""))}))
        : ({
        auto lx_p0_1 = lx_p0;
        auto ps_pa_2 = ps_pa;
        auto res_pb_3 = prism_rtl::deref(prism_rtl::deref(res_pb));
        call_then(start_rust_ty_of_params(lx_p0_1, each(ps_pa_2, [&](const crate::check::types::Ty& p_pe) { return job_param(p_pe); })), [=, res_pb_3 = std::move(res_pb_3)](crate::lower::model::OutTy rust_ty_of_params_2583) { return call_then(start_out_ty_of(lx_p0_1, res_pb_3), [=](crate::lower::model::OutTy out_ty_of_2632) { return prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutJobFn{prism_rtl::rc(rust_ty_of_params_2583), prism_rtl::rc(out_ty_of_2632)})); }); });
    });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyTuple>(t_p1) && ({
        auto&& m1375_20_0 = prism_rtl::as<crate::check::types::Ty::TyTuple>(t_p1).a0;
        (m1375_20_0.size() == 0u);
    }) ? ({
        auto&& m1375_20_0 = prism_rtl::as<crate::check::types::Ty::TyTuple>(t_p1).a0;
        prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}));
    })
        : prism_rtl::is<crate::check::types::Ty::TyTuple>(t_p1) ? ({
        auto&& ts_pf = prism_rtl::as<crate::check::types::Ty::TyTuple>(t_p1).a0;
        ({
        auto lx_p0_1 = lx_p0;
        auto ts_pf_2 = ts_pf;
        call_value(each_job(ts_pf_2, ({
        auto lx_p0_1_3 = lx_p0_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::OutTy>(crate::check::types::Ty)>>(prism_rtl::rc([=, lx_p0_1_3 = std::move(lx_p0_1_3)](crate::check::types::Ty p0) {
        return ({
            auto lx_p0_1_3_3 = lx_p0_1_3;
            entered(once_job([=, lx_p0_1_3_3 = std::move(lx_p0_1_3_3)]() {
            return ({
                auto a_pg = p0;
                (prism_rtl::more(prism_rtl::rc(OutTyOf(lx_p0_1_3_3, a_pg))));
            });
        }));
        });
    })));
    })), [=](Array<crate::lower::model::OutTy> each_2701) { return prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutTuple{each_2701})); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyArray>(t_p1) ? ({
        auto&& e_ph = prism_rtl::as<crate::check::types::Ty::TyArray>(t_p1).a0;
        ({
        auto e_ph_1 = prism_rtl::deref(prism_rtl::deref(e_ph));
        auto lx_p0_2 = lx_p0;
        call_then(start_out_ty_of(lx_p0_2, e_ph_1), [=](crate::lower::model::OutTy out_ty_of_2755) { return prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutArray{prism_rtl::rc(out_ty_of_2755)})); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyMap>(t_p1) ? ({
        auto&& k_pi = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p1).a0;
        auto&& v_pj = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p1).a1;
        ({
        auto k_pi_1 = prism_rtl::deref(prism_rtl::deref(k_pi));
        auto lx_p0_2 = lx_p0;
        auto v_pj_3 = prism_rtl::deref(prism_rtl::deref(v_pj));
        call_then(start_out_ty_of(lx_p0_2, k_pi_1), [=, v_pj_3 = std::move(v_pj_3)](crate::lower::model::OutTy out_ty_of_2794) { return call_then(start_out_ty_of(lx_p0_2, v_pj_3), [=](crate::lower::model::OutTy out_ty_of_2811) { return prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutMap{prism_rtl::rc(out_ty_of_2794), prism_rtl::rc(out_ty_of_2811)})); }); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TySig>(t_p1) && ({
        auto&& m1375_24_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a0;
        auto&& i_pk = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a1;
        (m1375_24_0 == Text::lit("?"));
    }) ? ({
        auto&& m1375_24_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a0;
        auto&& i_pk = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a1;
        ({
        auto i_pk_1 = prism_rtl::deref(prism_rtl::deref(i_pk));
        auto lx_p0_2 = lx_p0;
        call_then(start_out_ty_of(lx_p0_2, i_pk_1), [=](crate::lower::model::OutTy out_ty_of_2852) { return prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutOpt{prism_rtl::rc(out_ty_of_2852)})); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TySig>(t_p1) && ({
        auto&& m1375_25_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a0;
        auto&& i_pl = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a1;
        (m1375_25_0 == Text::lit("~"));
    }) ? ({
        auto&& m1375_25_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a0;
        auto&& i_pl = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a1;
        ({
        auto i_pl_1 = prism_rtl::deref(prism_rtl::deref(i_pl));
        auto lx_p0_2 = lx_p0;
        call_then(start_out_ty_of(lx_p0_2, i_pl_1), [=](crate::lower::model::OutTy out_ty_of_2893) { return prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutRes{prism_rtl::rc(out_ty_of_2893)})); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TySig>(t_p1) && ({
        auto&& m1375_26_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a0;
        auto&& i_pm = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a1;
        (m1375_26_0 == Text::lit("!"));
    }) ? ({
        auto&& m1375_26_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a0;
        auto&& i_pm = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a1;
        ({
        auto i_pm_1 = prism_rtl::deref(prism_rtl::deref(i_pm));
        auto lx_p0_2 = lx_p0;
        call_then(start_out_ty_of(lx_p0_2, i_pm_1), [=](crate::lower::model::OutTy out_ty_of_2936) { return prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutEvent{prism_rtl::rc(out_ty_of_2936)})); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TySig>(t_p1) && ({
        auto&& m1375_27_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a0;
        auto&& i_pn = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a1;
        (m1375_27_0 == Text::lit("$"));
    }) ? ({
        auto&& m1375_27_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a0;
        auto&& i_pn = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a1;
        ({
        auto i_pn_1 = prism_rtl::deref(prism_rtl::deref(i_pn));
        auto lx_p0_2 = lx_p0;
        call_then(start_out_ty_of(lx_p0_2, i_pn_1), [=](crate::lower::model::OutTy out_ty_of_2977) { return prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutDyn{prism_rtl::rc(out_ty_of_2977)})); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TySig>(t_p1) && ({
        auto&& m1375_28_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a0;
        auto&& i_po = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a1;
        (m1375_28_0 == Text::lit("&"));
    }) ? ({
        auto&& m1375_28_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a0;
        auto&& i_po = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a1;
        prism_rtl::more(prism_rtl::rc(OutTyOf(lx_p0, prism_rtl::deref(prism_rtl::deref(i_po)))));
    })
        : prism_rtl::is<crate::check::types::Ty::TySig>(t_p1) ? ({
        auto&& i_pp = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a1;
        prism_rtl::more(prism_rtl::rc(OutTyOf(lx_p0, prism_rtl::deref(prism_rtl::deref(i_pp)))));
    })
        : prism_rtl::is<crate::check::types::Ty::TyQ>(t_p1) ? ({
        auto&& n_pq = prism_rtl::as<crate::check::types::Ty::TyQ>(t_p1).a0;
        prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutGen{crate::lower::camel(n_pq)}));
    })
        : prism_rtl::is<crate::check::types::Ty::TyRigid>(t_p1) ? ({
        auto&& n_pr = prism_rtl::as<crate::check::types::Ty::TyRigid>(t_p1).a0;
        prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutGen{crate::lower::camel(n_pr)}));
    })
        : prism_rtl::is<crate::check::types::Ty::TyFlex>(t_p1) ? ({
        auto&& n_ps = prism_rtl::as<crate::check::types::Ty::TyFlex>(t_p1).a0;
        ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(lx_p0).subst, prism_rtl::cat("\'", n_ps));
        prism_rtl::is_some(_m) ? ({
        auto&& x_pt = prism_rtl::some_of(_m);
        prism_rtl::more(prism_rtl::rc(OutTyOf(lx_p0, x_pt)));
    })
        : prism_rtl::is_none(_m) ? ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(lx_p0).quants, prism_rtl::cat("\'", n_ps));
        prism_rtl::is_some(_m) ? ({
        auto&& b_pu = prism_rtl::some_of(_m);
        prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutQuantified{b_pu}));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}))
        : throw prism_rtl::Panic("no arm matched");
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyAny>(t_p1) ? prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutShowAny{}))
        : prism_rtl::is<crate::check::types::Ty::TyElem>(t_p1) ? prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutLive{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("crate::Elem"), Array<crate::lower::model::OutTy>{}}))}))
        : prism_rtl::is<crate::check::types::Ty::TyElemAny>(t_p1) ? prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("crate::Elem"), Array<crate::lower::model::OutTy>{}}))
        : prism_rtl::is<crate::check::types::Ty::TyAt>(t_p1) ? ({
        auto&& i_pv = prism_rtl::as<crate::check::types::Ty::TyAt>(t_p1).a0;
        prism_rtl::finished(blueprint_ty());
    })
        : prism_rtl::is<crate::check::types::Ty::TyAssoc>(t_p1) ? prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnknown{Text::lit("an associated type")}))
        : prism_rtl::is<crate::check::types::Ty::TyErr>(t_p1) ? prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnknown{Text::lit("a type the checker did not find")}))
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start OutTyOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::OutTy> start_out_ty_of(crate::lower::Lx lx_p0, crate::check::types::Ty t_p1) {
    return prism_rtl::make_rc<OutTyOf>(lx_p0, t_p1);
}


/// let blueprintTy
crate::lower::model::OutTy blueprint_ty() {
    return crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("prism_rtl::Blueprint"), Array(std::vector{crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("crate::Elem"), Array<crate::lower::model::OutTy>{}}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("crate::Answer"), Array<crate::lower::model::OutTy>{}})})});
}


/// let elemTy
crate::lower::model::OutTy elem_ty() {
    return crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("crate::Elem"), Array<crate::lower::model::OutTy>{}});
}


/// let answerTy
crate::lower::model::OutTy answer_ty() {
    return crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("crate::Answer"), Array<crate::lower::model::OutTy>{}});
}


/// let entryTy
crate::lower::model::OutTy entry_ty() {
    return crate::lower::model::OutTy(crate::lower::model::OutTy::OutRc{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("prism_rtl::Entry"), Array(std::vector{crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("crate::Elem"), Array<crate::lower::model::OutTy>{}})})}))});
}


/// let hostDocTy
crate::lower::model::OutTy host_doc_ty() {
    return crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("prism_rtl::HostDoc"), Array(std::vector{crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("crate::Elem"), Array<crate::lower::model::OutTy>{}})})});
}


/// let hostOfTy
crate::lower::model::OutTy host_of_ty() {
    return crate::lower::model::OutTy(crate::lower::model::OutTy::OutObj{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("prism_rtl::HostOf"), Array(std::vector{crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("crate::Elem"), Array<crate::lower::model::OutTy>{}}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("crate::Answer"), Array<crate::lower::model::OutTy>{}})})}))});
}


/// HasBlueprint: fn Ty -> Bool
bool has_blueprint(const crate::check::types::Ty& t_p0) {
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(t_p0)) {
        return true;
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t_p0)) {
        auto&& i_p1 = prism_rtl::as<crate::check::types::Ty::TySig>(t_p0).a1;
        return has_blueprint(prism_rtl::deref(prism_rtl::deref(i_p1)));
    }
    {
        return false;
    }
}


/// EventParam: fn Ty -> Ty
crate::check::types::Ty event_param(const crate::check::types::Ty& t_p0) {
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t_p0)) {
        auto&& m4785_0_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t_p0).a0;
        auto&& i_p1 = prism_rtl::as<crate::check::types::Ty::TySig>(t_p0).a1;
        if (m4785_0_0 == Text::lit("!")) {
            return crate::check::types::Ty(crate::check::types::Ty::TyCon{Text::lit("\000Event"sv), Array(std::vector{peel(prism_rtl::deref(prism_rtl::deref(i_p1)))})});
        }
    }
    {
        return t_p0;
    }
}


/// JobParam: fn Ty -> Ty
crate::check::types::Ty job_param(const crate::check::types::Ty& ty0) {
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(ty0)) {
        auto&& ps_p0 = prism_rtl::as<crate::check::types::Ty::TyFn>(ty0).a1;
        auto&& r_p1 = prism_rtl::as<crate::check::types::Ty::TyFn>(ty0).a2;
        return crate::check::types::Ty(crate::check::types::Ty::TyFn{crate::check::types::Col(crate::check::types::Col::CUnbound{}), ps_p0, prism_rtl::rc(prism_rtl::deref(prism_rtl::deref(r_p1)))});
    }
    {
        auto&& t_p2 = ty0;
        return t_p2;
    }
}


/// RustTyOfParams: unbounded fn Lx, [Ty] -> OutTy
crate::lower::model::OutTy rust_ty_of_params(const crate::lower::Lx& lx_p0, const Array<crate::check::types::Ty>& ps_p1) {
    {
        auto&& m5348_0 = ps_p1;
        if (m5348_0.size() == 1u) {
            {
                auto&& _c1 = index(m5348_0, Nat(0u));
                if (prism_rtl::is_some(_c1)) {
                    auto&& p_p2 = prism_rtl::some_of(_c1);
                    return out_ty_of(lx_p0, p_p2);
                }
            }
        }
    }
    {
        return crate::lower::model::OutTy(crate::lower::model::OutTy::OutTuple{run_to_end(each_job(ps_p1, ({
            auto lx_p0_1 = lx_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::OutTy>(crate::check::types::Ty)>>(prism_rtl::rc([=, lx_p0_1 = std::move(lx_p0_1)](crate::check::types::Ty p0) {
            return ({
                auto lx_p0_1_2 = lx_p0_1;
                entered(once_job([=, lx_p0_1_2 = std::move(lx_p0_1_2)]() {
                return ({
                    auto p_p3 = p0;
                    (prism_rtl::more(prism_rtl::rc(OutTyOf(lx_p0_1_2, p_p3))));
                });
            }));
            });
        })));
        })))});
    }
}


prism_rtl::Turn<crate::lower::model::OutTy> RustTyOfParams::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& ps_p1 = this->ps_p1;
    return ({
        ({
        auto&& m5348_0 = ps_p1;
        (m5348_0.size() == 1u) && ({
        auto&& _c1 = index(m5348_0, Nat(0u));
        prism_rtl::is_some(_c1);
    });
    }) ? ({
        auto&& m5348_0 = ps_p1;
        auto&& _c1 = index(m5348_0, Nat(0u));
        auto&& p_p2 = prism_rtl::some_of(_c1);
        prism_rtl::more(prism_rtl::rc(OutTyOf(lx_p0, p_p2)));
    })
        : ({
        auto lx_p0_1 = lx_p0;
        auto ps_p1_2 = ps_p1;
        call_value(each_job(ps_p1_2, ({
        auto lx_p0_1_3 = lx_p0_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::OutTy>(crate::check::types::Ty)>>(prism_rtl::rc([=, lx_p0_1_3 = std::move(lx_p0_1_3)](crate::check::types::Ty p0) {
        return ({
            auto lx_p0_1_3_3 = lx_p0_1_3;
            entered(once_job([=, lx_p0_1_3_3 = std::move(lx_p0_1_3_3)]() {
            return ({
                auto p_p3 = p0;
                (prism_rtl::more(prism_rtl::rc(OutTyOf(lx_p0_1_3_3, p_p3))));
            });
        }));
        });
    })));
    })), [=](Array<crate::lower::model::OutTy> each_5408) { return prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutTuple{each_5408})); });
    });
    });
}


/// `Start RustTyOfParams, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::OutTy> start_rust_ty_of_params(crate::lower::Lx lx_p0, Array<crate::check::types::Ty> ps_p1) {
    return prism_rtl::make_rc<RustTyOfParams>(lx_p0, ps_p1);
}


/// NamedTy: unbounded fn Lx, Text, [OutTy] -> OutTy
crate::lower::model::OutTy named_ty(const crate::lower::Lx& lx_p0, const Text& n_p1, const Array<crate::lower::model::OutTy>& args_p2) {
    auto&& _m = crate::prelude::get(prism_rtl::deref(lx_p0.g).types, n_p1);
    if (prism_rtl::is_some(_m)) {
        auto&& ti_p3 = prism_rtl::some_of(_m);
        auto&& _m = prism_rtl::deref(ti_p3).body;
        if (prism_rtl::is<crate::check::env::TyBody::BAlias>(_m)) {
            auto&& a_p4 = prism_rtl::as<crate::check::env::TyBody::BAlias>(_m).a0;
            return out_ty_of(lx_p0, a_p4);
        }
        if (prism_rtl::is<crate::check::env::TyBody::BRowKind>(_m)) {
            return n_p1 == Text::lit("Prelude.Fault")
                ? crate::lower::model::OutTy(crate::lower::model::OutTy::OutPod{})
                : crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{crate::lower::path_in(lx_p0, prism_rtl::deref(ti_p3).home, crate::lower::camel(crate::check::types::bare_name(n_p1))), Array<crate::lower::model::OutTy>{}});
        }
        {
            return crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{crate::lower::path_in(lx_p0, prism_rtl::deref(ti_p3).home, crate::lower::camel(crate::check::types::bare_name(n_p1))), args_p2});
        }
    }
    if (prism_rtl::is_none(_m)) {
        return crate::check::env::has_key(prism_rtl::deref(lx_p0.g).families, n_p1)
            ? crate::lower::model::OutTy(crate::lower::model::OutTy::OutPod{})
            : crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{crate::lower::camel(crate::check::types::bare_name(n_p1)), args_p2});
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::lower::model::OutTy> NamedTy::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& n_p1 = this->n_p1;
    const auto& args_p2 = this->args_p2;
    return ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(prism_rtl::deref(lx_p0).g).types, n_p1);
        prism_rtl::is_some(_m) ? ({
        auto&& ti_p3 = prism_rtl::some_of(_m);
        ({
        auto&& _m = prism_rtl::deref(ti_p3).body;
        prism_rtl::is<crate::check::env::TyBody::BAlias>(_m) ? ({
        auto&& a_p4 = prism_rtl::as<crate::check::env::TyBody::BAlias>(_m).a0;
        prism_rtl::more(prism_rtl::rc(OutTyOf(lx_p0, a_p4)));
    })
        : prism_rtl::is<crate::check::env::TyBody::BRowKind>(_m) ? n_p1 == Text::lit("Prelude.Fault")
        ? prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutPod{}))
        : prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{crate::lower::path_in(lx_p0, prism_rtl::deref(ti_p3).home, crate::lower::camel(crate::check::types::bare_name(n_p1))), Array<crate::lower::model::OutTy>{}}))
        : prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{crate::lower::path_in(lx_p0, prism_rtl::deref(ti_p3).home, crate::lower::camel(crate::check::types::bare_name(n_p1))), args_p2}));
    });
    })
        : prism_rtl::is_none(_m) ? crate::check::env::has_key(prism_rtl::deref(prism_rtl::deref(lx_p0).g).families, n_p1)
        ? prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutPod{}))
        : prism_rtl::finished(crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{crate::lower::camel(crate::check::types::bare_name(n_p1)), args_p2}))
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start NamedTy, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::OutTy> start_named_ty(crate::lower::Lx lx_p0, Text n_p1, Array<crate::lower::model::OutTy> args_p2) {
    return prism_rtl::make_rc<NamedTy>(lx_p0, n_p1, args_p2);
}


/// Peel: fn Ty -> Ty
crate::check::types::Ty peel(const crate::check::types::Ty& t_p0) {
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t_p0)) {
        auto&& m6146_0_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t_p0).a0;
        auto&& i_p1 = prism_rtl::as<crate::check::types::Ty::TySig>(t_p0).a1;
        if (m6146_0_0 == Text::lit("$")) {
            return peel(prism_rtl::deref(prism_rtl::deref(i_p1)));
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t_p0)) {
        auto&& m6146_1_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t_p0).a0;
        auto&& i_p2 = prism_rtl::as<crate::check::types::Ty::TySig>(t_p0).a1;
        if (m6146_1_0 == Text::lit("!")) {
            return peel(prism_rtl::deref(prism_rtl::deref(i_p2)));
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t_p0)) {
        auto&& m6146_2_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t_p0).a0;
        auto&& i_p3 = prism_rtl::as<crate::check::types::Ty::TySig>(t_p0).a1;
        if (m6146_2_0 == Text::lit("&")) {
            return peel(prism_rtl::deref(prism_rtl::deref(i_p3)));
        }
    }
    {
        return t_p0;
    }
}


/// OutOf: fn Ty -> Ty
crate::check::types::Ty out_of(const crate::check::types::Ty& t_p0) {
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(t_p0)) {
        auto&& i_p1 = prism_rtl::as<crate::check::types::Ty::TyAt>(t_p0).a0;
        return peel(prism_rtl::deref(prism_rtl::deref(i_p1)));
    }
    {
        return peel(t_p0);
    }
}


/// IsBundle: fn Ty -> Bool
bool is_bundle(const crate::check::types::Ty& t_p0) {
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t_p0)) {
        auto&& ts_p1 = prism_rtl::as<crate::check::types::Ty::TyTuple>(t_p0).a0;
        return fold(ts_p1, false, [&](const bool& found_p2, const crate::check::types::Ty& x_p3) { return ((prism_rtl::deref(found_p2) || (layer_of(x_p3) == Layer(Layer::LyEv{}))) || (layer_of(x_p3) == Layer(Layer::LyDyn{}))) || is_bundle(x_p3); });
    }
    {
        return false;
    }
}


/// LayerOf: fn Ty -> Layer
Layer layer_of(const crate::check::types::Ty& t_p0) {
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t_p0)) {
        auto&& m6991_0_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t_p0).a0;
        if (m6991_0_0 == Text::lit("$")) {
            return Layer(Layer::LyDyn{});
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t_p0)) {
        auto&& m6991_1_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t_p0).a0;
        if (m6991_1_0 == Text::lit("!")) {
            return Layer(Layer::LyEv{});
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t_p0)) {
        auto&& m6991_2_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t_p0).a0;
        auto&& i_p1 = prism_rtl::as<crate::check::types::Ty::TySig>(t_p0).a1;
        if (m6991_2_0 == Text::lit("&")) {
            return layer_of(prism_rtl::deref(prism_rtl::deref(i_p1)));
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(t_p0)) {
        return Layer(Layer::LyBlueprint{});
    }
    {
        return Layer(Layer::LyPlain{});
    }
}


/// Layouts: unbounded fn G -> (Text ==> [Bool])
Map<Text, Array<bool>> layouts(const crate::check::env::G& g_p0) {
    return run_to_end(fold_job(values(g_p0.ctors), Map<Text, Array<bool>>{}, ({
        auto g_p0_1 = g_p0;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Array<bool>>>(std::tuple<Map<Text, Array<bool>>, crate::check::env::CtorInfo>)>>(prism_rtl::rc([=, g_p0_1 = std::move(g_p0_1)](std::tuple<Map<Text, Array<bool>>, crate::check::env::CtorInfo> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_p0_1_2 = g_p0_1;
            entered(once_job([=, g_p0_1_2 = std::move(g_p0_1_2)]() {
            return ({
                auto m_p1 = p0;
                auto c_p2 = p1;
                call_value(each_job(c_p2->args, ({
                auto g_p0_1_2_2 = g_p0_1_2;
                auto c_p2_2 = c_p2;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(crate::check::types::Ty)>>(prism_rtl::rc([=, g_p0_1_2_2 = std::move(g_p0_1_2_2), c_p2_2 = std::move(c_p2_2)](crate::check::types::Ty p0) {
                return ({
                    auto g_p0_1_2_2_3 = g_p0_1_2_2;
                    auto c_p2_2_3 = c_p2_2;
                    entered(once_job([=, g_p0_1_2_2_3 = std::move(g_p0_1_2_2_3), c_p2_2_3 = std::move(c_p2_2_3)]() {
                    return ({
                        auto a_p3 = p0;
                        (prism_rtl::more(prism_rtl::rc(Reaches(g_p0_1_2_2_3, a_p3, prism_rtl::deref(c_p2_2_3).owner, Array<Text>{}))));
                    });
                }));
                });
            })));
            })), [=, m_p1 = std::move(m_p1)](Array<bool> each_7499) { return prism_rtl::finished(insert(m_p1, prism_rtl::deref(c_p2).name, each_7499)); });
            });
        }));
        });
    }));
    })));
}


prism_rtl::Turn<Map<Text, Array<bool>>> Layouts::cycle() const {
    const auto& g_p0 = this->g_p0;
    return fold_job(values(prism_rtl::deref(g_p0).ctors), Map<Text, Array<bool>>{}, ({
        auto g_p0_1 = g_p0;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Array<bool>>>(std::tuple<Map<Text, Array<bool>>, crate::check::env::CtorInfo>)>>(prism_rtl::rc([=, g_p0_1 = std::move(g_p0_1)](std::tuple<Map<Text, Array<bool>>, crate::check::env::CtorInfo> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_p0_1_2 = g_p0_1;
            entered(once_job([=, g_p0_1_2 = std::move(g_p0_1_2)]() {
            return ({
                auto m_p1 = p0;
                auto c_p2 = p1;
                call_value(each_job(c_p2->args, ({
                auto g_p0_1_2_2 = g_p0_1_2;
                auto c_p2_2 = c_p2;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(crate::check::types::Ty)>>(prism_rtl::rc([=, g_p0_1_2_2 = std::move(g_p0_1_2_2), c_p2_2 = std::move(c_p2_2)](crate::check::types::Ty p0) {
                return ({
                    auto g_p0_1_2_2_3 = g_p0_1_2_2;
                    auto c_p2_2_3 = c_p2_2;
                    entered(once_job([=, g_p0_1_2_2_3 = std::move(g_p0_1_2_2_3), c_p2_2_3 = std::move(c_p2_2_3)]() {
                    return ({
                        auto a_p3 = p0;
                        (prism_rtl::more(prism_rtl::rc(Reaches(g_p0_1_2_2_3, a_p3, prism_rtl::deref(c_p2_2_3).owner, Array<Text>{}))));
                    });
                }));
                });
            })));
            })), [=, m_p1 = std::move(m_p1)](Array<bool> each_7499) { return prism_rtl::finished(insert(m_p1, prism_rtl::deref(c_p2).name, each_7499)); });
            });
        }));
        });
    }));
    }))->cycle();
}


/// `Start Layouts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, Array<bool>>> start_layouts(crate::check::env::G g_p0) {
    return prism_rtl::make_rc<Layouts>(g_p0);
}


/// Reaches: unbounded fn G, Ty, Text, [Text] -> Bool
bool reaches(const crate::check::env::G& g_p0, const crate::check::types::Ty& t_p1, const Text& target_p2, const Array<Text>& seen_p3) {
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t_p1)) {
        auto&& n_p4 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a0;
        auto&& args_p5 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a1;
        return n_p4 == target_p2
            ? true
            : crate::check::types::has_text(seen_p3, n_p4)
            ? false
            : run_to_end(fold_job(args_p5, false, ({
            auto g_p0_1 = g_p0;
            auto target_p2_2 = target_p2;
            auto seen_p3_3 = seen_p3;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=, g_p0_1 = std::move(g_p0_1), target_p2_2 = std::move(target_p2_2), seen_p3_3 = std::move(seen_p3_3)](std::tuple<bool, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto g_p0_1_4 = g_p0_1;
                auto target_p2_2_4 = target_p2_2;
                auto seen_p3_3_4 = seen_p3_3;
                entered(once_job([=, g_p0_1_4 = std::move(g_p0_1_4), target_p2_2_4 = std::move(target_p2_2_4), seen_p3_3_4 = std::move(seen_p3_3_4)]() {
                return ({
                    auto f_p6 = p0;
                    auto a_p7 = p1;
                    (prism_rtl::finished(std::move(f_p6) || reaches(g_p0_1_4, a_p7, target_p2_2_4, seen_p3_3_4)));
                });
            }));
            });
        })));
        })))
            ? true
            : ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            auto&& _m = crate::prelude::get(g_p0.types, n_p4);
            if (prism_rtl::is_some(_m)) {
                auto&& ti_p8 = prism_rtl::some_of(_m);
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<bool> _v;
                    auto&& _m = prism_rtl::deref(ti_p8).body;
                    if (prism_rtl::is<crate::check::env::TyBody::BRecord>(_m)) {
                        auto&& fs_p9 = prism_rtl::as<crate::check::env::TyBody::BRecord>(_m).a0;
                        _v.set(run_to_end(fold_job(fs_p9, false, ({
                            auto g_p0_1 = g_p0;
                            auto target_p2_2 = target_p2;
                            auto seen_p3_3 = seen_p3;
                            auto n_p4_4 = n_p4;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, crate::check::types::Ty>>)>>(prism_rtl::rc([=, g_p0_1 = std::move(g_p0_1), target_p2_2 = std::move(target_p2_2), seen_p3_3 = std::move(seen_p3_3), n_p4_4 = std::move(n_p4_4)](std::tuple<bool, std::tuple<Text, crate::check::types::Ty>> _p0) {
                            auto&& p0 = std::get<0>(_p0);
                            auto&& p1 = std::get<1>(_p0);
                            return ({
                                auto g_p0_1_5 = g_p0_1;
                                auto target_p2_2_5 = target_p2_2;
                                auto seen_p3_3_5 = seen_p3_3;
                                auto n_p4_4_5 = n_p4_4;
                                entered(once_job([=, g_p0_1_5 = std::move(g_p0_1_5), target_p2_2_5 = std::move(target_p2_2_5), seen_p3_3_5 = std::move(seen_p3_3_5), n_p4_4_5 = std::move(n_p4_4_5)]() {
                                return ({
                                    auto f_pa = p0;
                                    auto&& _ft_pb = p1;
                                    auto&& ft_pb = std::get<1>(_ft_pb);
                                    (prism_rtl::finished(std::move(f_pa) || reaches(g_p0_1_5, ft_pb, target_p2_2_5, crate::prelude::push(seen_p3_3_5, n_p4_4_5))));
                                });
                            }));
                            });
                        })));
                        }))));
                        goto _done;
                    }
                    if (prism_rtl::is<crate::check::env::TyBody::BChoice>(_m)) {
                        auto&& cs_pc = prism_rtl::as<crate::check::env::TyBody::BChoice>(_m).a0;
                        _v.set(run_to_end(fold_job(cs_pc, false, ({
                            auto g_p0_1 = g_p0;
                            auto target_p2_2 = target_p2;
                            auto seen_p3_3 = seen_p3;
                            auto n_p4_4 = n_p4;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, Array<crate::check::types::Ty>>>)>>(prism_rtl::rc([=, g_p0_1 = std::move(g_p0_1), target_p2_2 = std::move(target_p2_2), seen_p3_3 = std::move(seen_p3_3), n_p4_4 = std::move(n_p4_4)](std::tuple<bool, std::tuple<Text, Array<crate::check::types::Ty>>> _p0) {
                            auto&& p0 = std::get<0>(_p0);
                            auto&& p1 = std::get<1>(_p0);
                            return ({
                                auto g_p0_1_5 = g_p0_1;
                                auto target_p2_2_5 = target_p2_2;
                                auto seen_p3_3_5 = seen_p3_3;
                                auto n_p4_4_5 = n_p4_4;
                                entered(once_job([=, g_p0_1_5 = std::move(g_p0_1_5), target_p2_2_5 = std::move(target_p2_2_5), seen_p3_3_5 = std::move(seen_p3_3_5), n_p4_4_5 = std::move(n_p4_4_5)]() {
                                return ({
                                    auto f_pd = p0;
                                    auto&& _ats_pe = p1;
                                    auto&& ats_pe = std::get<1>(_ats_pe);
                                    (prism_rtl::finished(std::move(f_pd) || run_to_end(fold_job(ats_pe, false, ({
                                    auto g_p0_1_5_5 = g_p0_1_5;
                                    auto target_p2_2_5_5 = target_p2_2_5;
                                    auto seen_p3_3_5_5 = seen_p3_3_5;
                                    auto n_p4_4_5_5 = n_p4_4_5;
                                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=, g_p0_1_5_5 = std::move(g_p0_1_5_5), target_p2_2_5_5 = std::move(target_p2_2_5_5), seen_p3_3_5_5 = std::move(seen_p3_3_5_5), n_p4_4_5_5 = std::move(n_p4_4_5_5)](std::tuple<bool, crate::check::types::Ty> _p0) {
                                    auto&& p0 = std::get<0>(_p0);
                                    auto&& p1 = std::get<1>(_p0);
                                    return ({
                                        auto g_p0_1_5_5_5 = g_p0_1_5_5;
                                        auto target_p2_2_5_5_5 = target_p2_2_5_5;
                                        auto seen_p3_3_5_5_5 = seen_p3_3_5_5;
                                        auto n_p4_4_5_5_5 = n_p4_4_5_5;
                                        entered(once_job([=, g_p0_1_5_5_5 = std::move(g_p0_1_5_5_5), target_p2_2_5_5_5 = std::move(target_p2_2_5_5_5), seen_p3_3_5_5_5 = std::move(seen_p3_3_5_5_5), n_p4_4_5_5_5 = std::move(n_p4_4_5_5_5)]() {
                                        return ({
                                            auto f2_pf = p0;
                                            auto at_pg = p1;
                                            (prism_rtl::finished(std::move(f2_pf) || reaches(g_p0_1_5_5_5, at_pg, target_p2_2_5_5_5, crate::prelude::push(seen_p3_3_5_5_5, n_p4_4_5_5_5))));
                                        });
                                    }));
                                    });
                                })));
                                })))));
                                });
                            }));
                            });
                        })));
                        }))));
                        goto _done;
                    }
                    if (prism_rtl::is<crate::check::env::TyBody::BAlias>(_m)) {
                        auto&& a_ph = prism_rtl::as<crate::check::env::TyBody::BAlias>(_m).a0;
                        _v.set(reaches(g_p0, a_ph, target_p2, crate::prelude::push(seen_p3, n_p4)));
                        goto _done;
                    }
                    {
                        _v.set(false);
                        goto _done;
                    }
                _done:
                    _v.take();
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(false);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t_p1)) {
        auto&& m7629_1_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a0;
        auto&& i_pi = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a1;
        if (m7629_1_0 == Text::lit("?")) {
            return reaches(g_p0, prism_rtl::deref(prism_rtl::deref(i_pi)), target_p2, seen_p3);
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t_p1)) {
        auto&& m7629_2_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a0;
        auto&& i_pj = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a1;
        if (m7629_2_0 == Text::lit("~")) {
            return reaches(g_p0, prism_rtl::deref(prism_rtl::deref(i_pj)), target_p2, seen_p3);
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t_p1)) {
        auto&& ts_pk = prism_rtl::as<crate::check::types::Ty::TyTuple>(t_p1).a0;
        return run_to_end(fold_job(ts_pk, false, ({
            auto g_p0_1 = g_p0;
            auto target_p2_2 = target_p2;
            auto seen_p3_3 = seen_p3;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=, g_p0_1 = std::move(g_p0_1), target_p2_2 = std::move(target_p2_2), seen_p3_3 = std::move(seen_p3_3)](std::tuple<bool, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto g_p0_1_4 = g_p0_1;
                auto target_p2_2_4 = target_p2_2;
                auto seen_p3_3_4 = seen_p3_3;
                entered(once_job([=, g_p0_1_4 = std::move(g_p0_1_4), target_p2_2_4 = std::move(target_p2_2_4), seen_p3_3_4 = std::move(seen_p3_3_4)]() {
                return ({
                    auto f_pl = p0;
                    auto a_pm = p1;
                    (prism_rtl::finished(std::move(f_pl) || reaches(g_p0_1_4, a_pm, target_p2_2_4, seen_p3_3_4)));
                });
            }));
            });
        })));
        })));
    }
    {
        return false;
    }
}


prism_rtl::Turn<bool> Reaches::cycle() const {
    const auto& g_p0 = this->g_p0;
    const auto& t_p1 = this->t_p1;
    const auto& target_p2 = this->target_p2;
    const auto& seen_p3 = this->seen_p3;
    return ({
        prism_rtl::is<crate::check::types::Ty::TyCon>(t_p1) ? ({
        auto&& n_p4 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a0;
        auto&& args_p5 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p1).a1;
        n_p4 == target_p2
        ? prism_rtl::finished(true)
        : crate::check::types::has_text(seen_p3, n_p4)
        ? prism_rtl::finished(false)
        : ({
        auto args_p5_1 = args_p5;
        auto g_p0_2 = g_p0;
        auto n_p4_3 = n_p4;
        auto seen_p3_4 = seen_p3;
        auto target_p2_5 = target_p2;
        call_value(fold_job(args_p5_1, false, ({
        auto g_p0_2_6 = g_p0_2;
        auto target_p2_5_6 = target_p2_5;
        auto seen_p3_4_6 = seen_p3_4;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=, g_p0_2_6 = std::move(g_p0_2_6), target_p2_5_6 = std::move(target_p2_5_6), seen_p3_4_6 = std::move(seen_p3_4_6)](std::tuple<bool, crate::check::types::Ty> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_p0_2_6_6 = g_p0_2_6;
            auto target_p2_5_6_6 = target_p2_5_6;
            auto seen_p3_4_6_6 = seen_p3_4_6;
            entered(once_job([=, g_p0_2_6_6 = std::move(g_p0_2_6_6), target_p2_5_6_6 = std::move(target_p2_5_6_6), seen_p3_4_6_6 = std::move(seen_p3_4_6_6)]() {
            return ({
                auto f_p6 = p0;
                auto a_p7 = p1;
                (prism_rtl::finished(std::move(f_p6) || reaches(g_p0_2_6_6, a_p7, target_p2_5_6_6, seen_p3_4_6_6)));
            });
        }));
        });
    })));
    })), [=, n_p4_3 = std::move(n_p4_3)](bool fold_7743) {
        return fold_7743
            ? prism_rtl::finished(true)
            : ({
            auto&& _m = crate::prelude::get(prism_rtl::deref(g_p0_2).types, n_p4_3);
            prism_rtl::is_some(_m) ? ({
            auto&& ti_p8 = prism_rtl::some_of(_m);
            ({
            auto&& _m = prism_rtl::deref(ti_p8).body;
            prism_rtl::is<crate::check::env::TyBody::BRecord>(_m) ? ({
            auto&& fs_p9 = prism_rtl::as<crate::check::env::TyBody::BRecord>(_m).a0;
            fold_job(fs_p9, false, ({
            auto g_p0_2_6 = g_p0_2;
            auto target_p2_5_6 = target_p2_5;
            auto seen_p3_4_6 = seen_p3_4;
            auto n_p4_3_6 = n_p4_3;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, crate::check::types::Ty>>)>>(prism_rtl::rc([=, g_p0_2_6 = std::move(g_p0_2_6), target_p2_5_6 = std::move(target_p2_5_6), seen_p3_4_6 = std::move(seen_p3_4_6), n_p4_3_6 = std::move(n_p4_3_6)](std::tuple<bool, std::tuple<Text, crate::check::types::Ty>> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto g_p0_2_6_6 = g_p0_2_6;
                auto target_p2_5_6_6 = target_p2_5_6;
                auto seen_p3_4_6_6 = seen_p3_4_6;
                auto n_p4_3_6_6 = n_p4_3_6;
                entered(once_job([=, g_p0_2_6_6 = std::move(g_p0_2_6_6), target_p2_5_6_6 = std::move(target_p2_5_6_6), seen_p3_4_6_6 = std::move(seen_p3_4_6_6), n_p4_3_6_6 = std::move(n_p4_3_6_6)]() {
                return ({
                    auto f_pa = p0;
                    auto&& _ft_pb = p1;
                    auto&& ft_pb = std::get<1>(_ft_pb);
                    (prism_rtl::finished(std::move(f_pa) || reaches(g_p0_2_6_6, ft_pb, target_p2_5_6_6, crate::prelude::push(seen_p3_4_6_6, n_p4_3_6_6))));
                });
            }));
            });
        })));
        }))->cycle();
        })
            : prism_rtl::is<crate::check::env::TyBody::BChoice>(_m) ? ({
            auto&& cs_pc = prism_rtl::as<crate::check::env::TyBody::BChoice>(_m).a0;
            fold_job(cs_pc, false, ({
            auto g_p0_2_6 = g_p0_2;
            auto target_p2_5_6 = target_p2_5;
            auto seen_p3_4_6 = seen_p3_4;
            auto n_p4_3_6 = n_p4_3;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, Array<crate::check::types::Ty>>>)>>(prism_rtl::rc([=, g_p0_2_6 = std::move(g_p0_2_6), target_p2_5_6 = std::move(target_p2_5_6), seen_p3_4_6 = std::move(seen_p3_4_6), n_p4_3_6 = std::move(n_p4_3_6)](std::tuple<bool, std::tuple<Text, Array<crate::check::types::Ty>>> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto g_p0_2_6_6 = g_p0_2_6;
                auto target_p2_5_6_6 = target_p2_5_6;
                auto seen_p3_4_6_6 = seen_p3_4_6;
                auto n_p4_3_6_6 = n_p4_3_6;
                entered(once_job([=, g_p0_2_6_6 = std::move(g_p0_2_6_6), target_p2_5_6_6 = std::move(target_p2_5_6_6), seen_p3_4_6_6 = std::move(seen_p3_4_6_6), n_p4_3_6_6 = std::move(n_p4_3_6_6)]() {
                return ({
                    auto f_pd = p0;
                    auto&& _ats_pe = p1;
                    auto&& ats_pe = std::get<1>(_ats_pe);
                    (prism_rtl::finished(std::move(f_pd) || run_to_end(fold_job(ats_pe, false, ({
                    auto g_p0_2_6_6_6 = g_p0_2_6_6;
                    auto target_p2_5_6_6_6 = target_p2_5_6_6;
                    auto seen_p3_4_6_6_6 = seen_p3_4_6_6;
                    auto n_p4_3_6_6_6 = n_p4_3_6_6;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=, g_p0_2_6_6_6 = std::move(g_p0_2_6_6_6), target_p2_5_6_6_6 = std::move(target_p2_5_6_6_6), seen_p3_4_6_6_6 = std::move(seen_p3_4_6_6_6), n_p4_3_6_6_6 = std::move(n_p4_3_6_6_6)](std::tuple<bool, crate::check::types::Ty> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto g_p0_2_6_6_6_6 = g_p0_2_6_6_6;
                        auto target_p2_5_6_6_6_6 = target_p2_5_6_6_6;
                        auto seen_p3_4_6_6_6_6 = seen_p3_4_6_6_6;
                        auto n_p4_3_6_6_6_6 = n_p4_3_6_6_6;
                        entered(once_job([=, g_p0_2_6_6_6_6 = std::move(g_p0_2_6_6_6_6), target_p2_5_6_6_6_6 = std::move(target_p2_5_6_6_6_6), seen_p3_4_6_6_6_6 = std::move(seen_p3_4_6_6_6_6), n_p4_3_6_6_6_6 = std::move(n_p4_3_6_6_6_6)]() {
                        return ({
                            auto f2_pf = p0;
                            auto at_pg = p1;
                            (prism_rtl::finished(std::move(f2_pf) || reaches(g_p0_2_6_6_6_6, at_pg, target_p2_5_6_6_6_6, crate::prelude::push(seen_p3_4_6_6_6_6, n_p4_3_6_6_6_6))));
                        });
                    }));
                    });
                })));
                })))));
                });
            }));
            });
        })));
        }))->cycle();
        })
            : prism_rtl::is<crate::check::env::TyBody::BAlias>(_m) ? ({
            auto&& a_ph = prism_rtl::as<crate::check::env::TyBody::BAlias>(_m).a0;
            prism_rtl::more(prism_rtl::rc(Reaches(g_p0_2, a_ph, target_p2_5, crate::prelude::push(seen_p3_4, n_p4_3))));
        })
            : prism_rtl::finished(false);
        });
        })
            : prism_rtl::is_none(_m) ? prism_rtl::finished(false)
            : throw prism_rtl::Panic("no arm matched");
        });
    });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TySig>(t_p1) && ({
        auto&& m7629_1_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a0;
        auto&& i_pi = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a1;
        (m7629_1_0 == Text::lit("?"));
    }) ? ({
        auto&& m7629_1_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a0;
        auto&& i_pi = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a1;
        prism_rtl::more(prism_rtl::rc(Reaches(g_p0, prism_rtl::deref(prism_rtl::deref(i_pi)), target_p2, seen_p3)));
    })
        : prism_rtl::is<crate::check::types::Ty::TySig>(t_p1) && ({
        auto&& m7629_2_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a0;
        auto&& i_pj = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a1;
        (m7629_2_0 == Text::lit("~"));
    }) ? ({
        auto&& m7629_2_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a0;
        auto&& i_pj = prism_rtl::as<crate::check::types::Ty::TySig>(t_p1).a1;
        prism_rtl::more(prism_rtl::rc(Reaches(g_p0, prism_rtl::deref(prism_rtl::deref(i_pj)), target_p2, seen_p3)));
    })
        : prism_rtl::is<crate::check::types::Ty::TyTuple>(t_p1) ? ({
        auto&& ts_pk = prism_rtl::as<crate::check::types::Ty::TyTuple>(t_p1).a0;
        fold_job(ts_pk, false, ({
        auto g_p0_1 = g_p0;
        auto target_p2_2 = target_p2;
        auto seen_p3_3 = seen_p3;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=, g_p0_1 = std::move(g_p0_1), target_p2_2 = std::move(target_p2_2), seen_p3_3 = std::move(seen_p3_3)](std::tuple<bool, crate::check::types::Ty> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_p0_1_4 = g_p0_1;
            auto target_p2_2_4 = target_p2_2;
            auto seen_p3_3_4 = seen_p3_3;
            entered(once_job([=, g_p0_1_4 = std::move(g_p0_1_4), target_p2_2_4 = std::move(target_p2_2_4), seen_p3_3_4 = std::move(seen_p3_3_4)]() {
            return ({
                auto f_pl = p0;
                auto a_pm = p1;
                (prism_rtl::finished(std::move(f_pl) || reaches(g_p0_1_4, a_pm, target_p2_2_4, seen_p3_3_4)));
            });
        }));
        });
    })));
    }))->cycle();
    })
        : prism_rtl::finished(false);
    });
}


/// `Start Reaches, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_reaches(crate::check::env::G g_p0, crate::check::types::Ty t_p1, Text target_p2, Array<Text> seen_p3) {
    return prism_rtl::make_rc<Reaches>(g_p0, t_p1, target_p2, seen_p3);
}


/// RcField: fn Lx, Text, Nat -> Bool
bool rc_field(const crate::lower::Lx& lx_p0, const Text& ctor_p1, const Nat& i_p2) {
    return or_(index(or_(crate::prelude::get(lx_p0.layouts, ctor_p1), Array<bool>{}), i_p2), false);
}


/// Podable: unbounded fn OutTy -> Bool
bool podable(const crate::lower::model::OutTy& t_p0) {
    if (prism_rtl::is<crate::lower::model::OutTy::OutFn>(t_p0)) {
        return false;
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(t_p0)) {
        return false;
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutJob>(t_p0)) {
        return false;
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutEvent>(t_p0)) {
        return false;
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutDyn>(t_p0)) {
        return false;
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutShowAny>(t_p0)) {
        return false;
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutLive>(t_p0)) {
        return false;
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutUnknown>(t_p0)) {
        return false;
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutGen>(t_p0)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t_p0)) {
        auto&& args_p1 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p0).a1;
        return run_to_end(fold_job(args_p1, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<bool, crate::lower::model::OutTy> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto ok_p2 = p0;
                    auto a_p3 = p1;
                    (prism_rtl::finished(std::move(ok_p2) && podable(a_p3)));
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutOpt>(t_p0)) {
        auto&& i_p4 = prism_rtl::as<crate::lower::model::OutTy::OutOpt>(t_p0).a0;
        return podable(prism_rtl::deref(prism_rtl::deref(i_p4)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutRes>(t_p0)) {
        auto&& i_p5 = prism_rtl::as<crate::lower::model::OutTy::OutRes>(t_p0).a0;
        return podable(prism_rtl::deref(prism_rtl::deref(i_p5)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutRc>(t_p0)) {
        auto&& i_p6 = prism_rtl::as<crate::lower::model::OutTy::OutRc>(t_p0).a0;
        return podable(prism_rtl::deref(prism_rtl::deref(i_p6)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutTuple>(t_p0)) {
        auto&& ts_p7 = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(t_p0).a0;
        return run_to_end(fold_job(ts_p7, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<bool, crate::lower::model::OutTy> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto ok_p8 = p0;
                    auto a_p9 = p1;
                    (prism_rtl::finished(std::move(ok_p8) && podable(a_p9)));
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutArray>(t_p0)) {
        auto&& e_pa = prism_rtl::as<crate::lower::model::OutTy::OutArray>(t_p0).a0;
        return podable(prism_rtl::deref(prism_rtl::deref(e_pa)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutMap>(t_p0)) {
        auto&& k_pb = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t_p0).a0;
        auto&& v_pc = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t_p0).a1;
        return podable(prism_rtl::deref(prism_rtl::deref(k_pb))) && podable(prism_rtl::deref(prism_rtl::deref(v_pc)));
    }
    {
        return true;
    }
}


prism_rtl::Turn<bool> Podable::cycle() const {
    const auto& t_p0 = this->t_p0;
    return ({
        prism_rtl::is<crate::lower::model::OutTy::OutFn>(t_p0) ? prism_rtl::finished(false)
        : prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(t_p0) ? prism_rtl::finished(false)
        : prism_rtl::is<crate::lower::model::OutTy::OutJob>(t_p0) ? prism_rtl::finished(false)
        : prism_rtl::is<crate::lower::model::OutTy::OutEvent>(t_p0) ? prism_rtl::finished(false)
        : prism_rtl::is<crate::lower::model::OutTy::OutDyn>(t_p0) ? prism_rtl::finished(false)
        : prism_rtl::is<crate::lower::model::OutTy::OutShowAny>(t_p0) ? prism_rtl::finished(false)
        : prism_rtl::is<crate::lower::model::OutTy::OutLive>(t_p0) ? prism_rtl::finished(false)
        : prism_rtl::is<crate::lower::model::OutTy::OutUnknown>(t_p0) ? prism_rtl::finished(false)
        : prism_rtl::is<crate::lower::model::OutTy::OutGen>(t_p0) ? prism_rtl::finished(true)
        : prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t_p0) ? ({
        auto&& args_p1 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p0).a1;
        fold_job(args_p1, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<bool, crate::lower::model::OutTy> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto ok_p2 = p0;
                auto a_p3 = p1;
                (prism_rtl::finished(std::move(ok_p2) && podable(a_p3)));
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutOpt>(t_p0) ? ({
        auto&& i_p4 = prism_rtl::as<crate::lower::model::OutTy::OutOpt>(t_p0).a0;
        prism_rtl::more(prism_rtl::rc(Podable(prism_rtl::deref(prism_rtl::deref(i_p4)))));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutRes>(t_p0) ? ({
        auto&& i_p5 = prism_rtl::as<crate::lower::model::OutTy::OutRes>(t_p0).a0;
        prism_rtl::more(prism_rtl::rc(Podable(prism_rtl::deref(prism_rtl::deref(i_p5)))));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutRc>(t_p0) ? ({
        auto&& i_p6 = prism_rtl::as<crate::lower::model::OutTy::OutRc>(t_p0).a0;
        prism_rtl::more(prism_rtl::rc(Podable(prism_rtl::deref(prism_rtl::deref(i_p6)))));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutTuple>(t_p0) ? ({
        auto&& ts_p7 = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(t_p0).a0;
        fold_job(ts_p7, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<bool, crate::lower::model::OutTy> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto ok_p8 = p0;
                auto a_p9 = p1;
                (prism_rtl::finished(std::move(ok_p8) && podable(a_p9)));
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutArray>(t_p0) ? ({
        auto&& e_pa = prism_rtl::as<crate::lower::model::OutTy::OutArray>(t_p0).a0;
        prism_rtl::more(prism_rtl::rc(Podable(prism_rtl::deref(prism_rtl::deref(e_pa)))));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutMap>(t_p0) ? ({
        auto&& k_pb = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t_p0).a0;
        auto&& v_pc = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t_p0).a1;
        ({
        auto k_pb_1 = prism_rtl::deref(prism_rtl::deref(k_pb));
        auto v_pc_2 = prism_rtl::deref(prism_rtl::deref(v_pc));
        call_then(start_podable(k_pb_1), [=, v_pc_2 = std::move(v_pc_2)](bool podable_9199) { return prism_rtl::finished(podable_9199 && podable(v_pc_2)); });
    });
    })
        : prism_rtl::finished(true);
    });
}


/// `Start Podable, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_podable(crate::lower::model::OutTy t_p0) {
    return prism_rtl::make_rc<Podable>(t_p0);
}


/// RuntimeEq: unbounded fn OutTy -> Bool
bool runtime_eq(const crate::lower::model::OutTy& t_p0) {
    if (prism_rtl::is<crate::lower::model::OutTy::OutDyn>(t_p0)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t_p0)) {
        auto&& args_p1 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p0).a1;
        return run_to_end(fold_job(args_p1, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<bool, crate::lower::model::OutTy> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto ok_p2 = p0;
                    auto a_p3 = p1;
                    (prism_rtl::finished(std::move(ok_p2) && runtime_eq(a_p3)));
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutOpt>(t_p0)) {
        auto&& i_p4 = prism_rtl::as<crate::lower::model::OutTy::OutOpt>(t_p0).a0;
        return runtime_eq(prism_rtl::deref(prism_rtl::deref(i_p4)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutRes>(t_p0)) {
        auto&& i_p5 = prism_rtl::as<crate::lower::model::OutTy::OutRes>(t_p0).a0;
        return runtime_eq(prism_rtl::deref(prism_rtl::deref(i_p5)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutRc>(t_p0)) {
        auto&& i_p6 = prism_rtl::as<crate::lower::model::OutTy::OutRc>(t_p0).a0;
        return runtime_eq(prism_rtl::deref(prism_rtl::deref(i_p6)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutTuple>(t_p0)) {
        auto&& ts_p7 = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(t_p0).a0;
        return run_to_end(fold_job(ts_p7, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<bool, crate::lower::model::OutTy> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto ok_p8 = p0;
                    auto a_p9 = p1;
                    (prism_rtl::finished(std::move(ok_p8) && runtime_eq(a_p9)));
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutArray>(t_p0)) {
        auto&& e_pa = prism_rtl::as<crate::lower::model::OutTy::OutArray>(t_p0).a0;
        return runtime_eq(prism_rtl::deref(prism_rtl::deref(e_pa)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutMap>(t_p0)) {
        auto&& k_pb = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t_p0).a0;
        auto&& v_pc = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t_p0).a1;
        return runtime_eq(prism_rtl::deref(prism_rtl::deref(k_pb))) && runtime_eq(prism_rtl::deref(prism_rtl::deref(v_pc)));
    }
    {
        auto&& other_pd = t_p0;
        return podable(other_pd);
    }
}


prism_rtl::Turn<bool> RuntimeEq::cycle() const {
    const auto& t_p0 = this->t_p0;
    return ({
        prism_rtl::is<crate::lower::model::OutTy::OutDyn>(t_p0) ? prism_rtl::finished(true)
        : prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t_p0) ? ({
        auto&& args_p1 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p0).a1;
        fold_job(args_p1, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<bool, crate::lower::model::OutTy> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto ok_p2 = p0;
                auto a_p3 = p1;
                (prism_rtl::finished(std::move(ok_p2) && runtime_eq(a_p3)));
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutOpt>(t_p0) ? ({
        auto&& i_p4 = prism_rtl::as<crate::lower::model::OutTy::OutOpt>(t_p0).a0;
        prism_rtl::more(prism_rtl::rc(RuntimeEq(prism_rtl::deref(prism_rtl::deref(i_p4)))));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutRes>(t_p0) ? ({
        auto&& i_p5 = prism_rtl::as<crate::lower::model::OutTy::OutRes>(t_p0).a0;
        prism_rtl::more(prism_rtl::rc(RuntimeEq(prism_rtl::deref(prism_rtl::deref(i_p5)))));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutRc>(t_p0) ? ({
        auto&& i_p6 = prism_rtl::as<crate::lower::model::OutTy::OutRc>(t_p0).a0;
        prism_rtl::more(prism_rtl::rc(RuntimeEq(prism_rtl::deref(prism_rtl::deref(i_p6)))));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutTuple>(t_p0) ? ({
        auto&& ts_p7 = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(t_p0).a0;
        fold_job(ts_p7, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<bool, crate::lower::model::OutTy> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto ok_p8 = p0;
                auto a_p9 = p1;
                (prism_rtl::finished(std::move(ok_p8) && runtime_eq(a_p9)));
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutArray>(t_p0) ? ({
        auto&& e_pa = prism_rtl::as<crate::lower::model::OutTy::OutArray>(t_p0).a0;
        prism_rtl::more(prism_rtl::rc(RuntimeEq(prism_rtl::deref(prism_rtl::deref(e_pa)))));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutMap>(t_p0) ? ({
        auto&& k_pb = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t_p0).a0;
        auto&& v_pc = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t_p0).a1;
        ({
        auto k_pb_1 = prism_rtl::deref(prism_rtl::deref(k_pb));
        auto v_pc_2 = prism_rtl::deref(prism_rtl::deref(v_pc));
        call_then(start_runtime_eq(k_pb_1), [=, v_pc_2 = std::move(v_pc_2)](bool runtime_eq_9831) { return prism_rtl::finished(runtime_eq_9831 && runtime_eq(v_pc_2)); });
    });
    })
        : ({
        auto&& other_pd = t_p0;
        prism_rtl::more(prism_rtl::rc(Podable(other_pd)));
    });
    });
}


/// `Start RuntimeEq, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_runtime_eq(crate::lower::model::OutTy t_p0) {
    return prism_rtl::make_rc<RuntimeEq>(t_p0);
}


/// HoldsDyn: unbounded fn OutTy -> Bool
bool holds_dyn(const crate::lower::model::OutTy& t_p0) {
    if (prism_rtl::is<crate::lower::model::OutTy::OutDyn>(t_p0)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t_p0)) {
        auto&& args_p1 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p0).a1;
        return run_to_end(fold_job(args_p1, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<bool, crate::lower::model::OutTy> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto f_p2 = p0;
                    auto a_p3 = p1;
                    (prism_rtl::finished(std::move(f_p2) || holds_dyn(a_p3)));
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutOpt>(t_p0)) {
        auto&& i_p4 = prism_rtl::as<crate::lower::model::OutTy::OutOpt>(t_p0).a0;
        return holds_dyn(prism_rtl::deref(prism_rtl::deref(i_p4)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutRes>(t_p0)) {
        auto&& i_p5 = prism_rtl::as<crate::lower::model::OutTy::OutRes>(t_p0).a0;
        return holds_dyn(prism_rtl::deref(prism_rtl::deref(i_p5)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutRc>(t_p0)) {
        auto&& i_p6 = prism_rtl::as<crate::lower::model::OutTy::OutRc>(t_p0).a0;
        return holds_dyn(prism_rtl::deref(prism_rtl::deref(i_p6)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutTuple>(t_p0)) {
        auto&& ts_p7 = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(t_p0).a0;
        return run_to_end(fold_job(ts_p7, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<bool, crate::lower::model::OutTy> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto f_p8 = p0;
                    auto a_p9 = p1;
                    (prism_rtl::finished(std::move(f_p8) || holds_dyn(a_p9)));
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutArray>(t_p0)) {
        auto&& e_pa = prism_rtl::as<crate::lower::model::OutTy::OutArray>(t_p0).a0;
        return holds_dyn(prism_rtl::deref(prism_rtl::deref(e_pa)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutMap>(t_p0)) {
        auto&& k_pb = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t_p0).a0;
        auto&& v_pc = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t_p0).a1;
        return holds_dyn(prism_rtl::deref(prism_rtl::deref(k_pb))) || holds_dyn(prism_rtl::deref(prism_rtl::deref(v_pc)));
    }
    {
        return false;
    }
}


prism_rtl::Turn<bool> HoldsDyn::cycle() const {
    const auto& t_p0 = this->t_p0;
    return ({
        prism_rtl::is<crate::lower::model::OutTy::OutDyn>(t_p0) ? prism_rtl::finished(true)
        : prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t_p0) ? ({
        auto&& args_p1 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p0).a1;
        fold_job(args_p1, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<bool, crate::lower::model::OutTy> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto f_p2 = p0;
                auto a_p3 = p1;
                (prism_rtl::finished(std::move(f_p2) || holds_dyn(a_p3)));
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutOpt>(t_p0) ? ({
        auto&& i_p4 = prism_rtl::as<crate::lower::model::OutTy::OutOpt>(t_p0).a0;
        prism_rtl::more(prism_rtl::rc(HoldsDyn(prism_rtl::deref(prism_rtl::deref(i_p4)))));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutRes>(t_p0) ? ({
        auto&& i_p5 = prism_rtl::as<crate::lower::model::OutTy::OutRes>(t_p0).a0;
        prism_rtl::more(prism_rtl::rc(HoldsDyn(prism_rtl::deref(prism_rtl::deref(i_p5)))));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutRc>(t_p0) ? ({
        auto&& i_p6 = prism_rtl::as<crate::lower::model::OutTy::OutRc>(t_p0).a0;
        prism_rtl::more(prism_rtl::rc(HoldsDyn(prism_rtl::deref(prism_rtl::deref(i_p6)))));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutTuple>(t_p0) ? ({
        auto&& ts_p7 = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(t_p0).a0;
        fold_job(ts_p7, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<bool, crate::lower::model::OutTy> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto f_p8 = p0;
                auto a_p9 = p1;
                (prism_rtl::finished(std::move(f_p8) || holds_dyn(a_p9)));
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutArray>(t_p0) ? ({
        auto&& e_pa = prism_rtl::as<crate::lower::model::OutTy::OutArray>(t_p0).a0;
        prism_rtl::more(prism_rtl::rc(HoldsDyn(prism_rtl::deref(prism_rtl::deref(e_pa)))));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutMap>(t_p0) ? ({
        auto&& k_pb = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t_p0).a0;
        auto&& v_pc = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t_p0).a1;
        ({
        auto k_pb_1 = prism_rtl::deref(prism_rtl::deref(k_pb));
        auto v_pc_2 = prism_rtl::deref(prism_rtl::deref(v_pc));
        call_then(start_holds_dyn(k_pb_1), [=, v_pc_2 = std::move(v_pc_2)](bool holds_dyn_10293) { return prism_rtl::finished(holds_dyn_10293 || holds_dyn(v_pc_2)); });
    });
    })
        : prism_rtl::finished(false);
    });
}


/// `Start HoldsDyn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_holds_dyn(crate::lower::model::OutTy t_p0) {
    return prism_rtl::make_rc<HoldsDyn>(t_p0);
}


/// let emptyEnv
Env empty_env() {
    return Env{.names = Map<Text, Bn>{}, .spans = Map<Text, Vl>{}, .uses = Map<Text, Text>{}};
}


/// NameKeyAt: fn Lx, Env, SName, Range -> Text
Text name_key_at(const crate::lower::Lx& lx_p0, const Env& env_p1, const crate::syntax::SName& n_p2, const crate::syntax::Range& span_p3) {
    auto&& _m = crate::prelude::get(lx_p0.use_insts, crate::lower::place_key(lx_p0, span_p3));
    if (prism_rtl::is_some(_m)) {
        auto&& u_p4 = prism_rtl::some_of(_m);
        return or_(crate::prelude::get(env_p1.uses, prism_rtl::cat(crate::check::env::sname_key(n_p2), "#", show_text(crate::lower::expr::inst_at(lx_p0, u_p4)))), crate::check::env::sname_key(n_p2));
    }
    if (prism_rtl::is_none(_m)) {
        return crate::check::env::sname_key(n_p2);
    }
    prism_rtl::unreachable("no arm matched");
}


/// WithInstances: fn Env, [Text] -> [Text]
Array<Text> with_instances(const Env& env_p0, const Array<Text>& names_p1) {
    return fold(names_p1, names_p1, [&](const Array<Text>& acc_p2, const Text& n_p3) { return append(acc_p2, filter(keys(env_p0.names), [&](const Text& k_p4) { return crate::syntax::lexer::chars::has_prefix(k_p4, prism_rtl::cat(n_p3, "#inst")); })); });
}


/// BindSpan: fn Env, Text, Vl -> Env
Env bind_span(const Env& env_p0, const Text& nkey_p1, const Vl& v_p2) {
    Env this_ = env_p0;
    this_.spans = insert(this_.spans, nkey_p1, v_p2);
    return this_;
}


/// Bind: fn Env, Text, Bn -> Env
Env bind(const Env& env_p0, const Text& name_p1, const Bn& b_p2) {
    Env this_ = env_p0;
    this_.names = insert(this_.names, name_p1, b_p2);
    return this_;
}


/// ValueTy: fn Vl -> OutTy
crate::lower::model::OutTy value_ty(const Vl& vl0) {
    if (prism_rtl::is<Vl::VlPlace>(vl0)) {
        auto&& t_p0 = prism_rtl::as<Vl::VlPlace>(vl0).a2;
        return t_p0;
    }
    if (prism_rtl::is<Vl::VlOwned>(vl0)) {
        auto&& t_p1 = prism_rtl::as<Vl::VlOwned>(vl0).a1;
        return t_p1;
    }
    prism_rtl::unreachable("no arm matched");
}


/// LocalPlace: fn Ex, Holding, OutTy -> Vl
Vl local_place(const crate::lower::model::Ex& x_p0, const Holding& mode_p1, const crate::lower::model::OutTy& t_p2) {
    return Vl(Vl::VlPlace{x_p0, mode_p1, t_p2});
}


/// PlaceStem: fn Ex -> Text
Text place_stem(const crate::lower::model::Ex& x_p0) {
    if (prism_rtl::is<crate::lower::model::Ex::XVar>(x_p0)) {
        auto&& n_p1 = prism_rtl::as<crate::lower::model::Ex::XVar>(x_p0).a0;
        return n_p1;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XField>(x_p0)) {
        auto&& f_p2 = prism_rtl::as<crate::lower::model::Ex::XField>(x_p0).a1;
        return f_p2;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XTarget>(x_p0)) {
        auto&& y_p3 = prism_rtl::as<crate::lower::model::Ex::XTarget>(x_p0).a0;
        return place_stem(prism_rtl::deref(prism_rtl::deref(y_p3)));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XPart>(x_p0)) {
        auto&& y_p4 = prism_rtl::as<crate::lower::model::Ex::XPart>(x_p0).a0;
        auto&& k_p5 = prism_rtl::as<crate::lower::model::Ex::XPart>(x_p0).a1;
        return prism_rtl::cat(place_stem(prism_rtl::deref(prism_rtl::deref(y_p4))), "_", k_p5);
    }
    {
        return Text::lit("place");
    }
}


/// OnSelf: fn Ex -> Bool
bool on_self(const crate::lower::model::Ex& x_p0) {
    if (prism_rtl::is<crate::lower::model::Ex::XField>(x_p0)) {
        auto&& m13782_0_0 = prism_rtl::as<crate::lower::model::Ex::XField>(x_p0).a0;
        if (prism_rtl::is<crate::lower::model::Ex::XSelf>(prism_rtl::deref(prism_rtl::deref(m13782_0_0)))) {
            return true;
        }
    }
    if (prism_rtl::is<crate::lower::model::Ex::XField>(x_p0)) {
        auto&& y_p1 = prism_rtl::as<crate::lower::model::Ex::XField>(x_p0).a0;
        return on_self(prism_rtl::deref(prism_rtl::deref(y_p1)));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XPart>(x_p0)) {
        auto&& y_p2 = prism_rtl::as<crate::lower::model::Ex::XPart>(x_p0).a0;
        return on_self(prism_rtl::deref(prism_rtl::deref(y_p2)));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XMethod>(x_p0)) {
        auto&& y_p3 = prism_rtl::as<crate::lower::model::Ex::XMethod>(x_p0).a0;
        return on_self(prism_rtl::deref(prism_rtl::deref(y_p3)));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XUpgrade>(x_p0)) {
        auto&& y_p4 = prism_rtl::as<crate::lower::model::Ex::XUpgrade>(x_p0).a0;
        return on_self(prism_rtl::deref(prism_rtl::deref(y_p4)));
    }
    {
        return false;
    }
}


/// ?ThroughParent: fn Ex -> ?Ex
std::optional<crate::lower::model::Ex> through_parent(const crate::lower::model::Ex& x_p0) {
    if (prism_rtl::is<crate::lower::model::Ex::XField>(x_p0)) {
        auto&& m14186_0_0 = prism_rtl::as<crate::lower::model::Ex::XField>(x_p0).a0;
        auto&& m14186_0_1 = prism_rtl::as<crate::lower::model::Ex::XField>(x_p0).a1;
        if (prism_rtl::is<crate::lower::model::Ex::XSelf>(prism_rtl::deref(prism_rtl::deref(m14186_0_0)))) {
            if (m14186_0_1 == Text::lit("parent")) {
                return std::optional(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("parent")}));
            }
        }
    }
    if (prism_rtl::is<crate::lower::model::Ex::XField>(x_p0)) {
        auto&& y_p1 = prism_rtl::as<crate::lower::model::Ex::XField>(x_p0).a0;
        auto&& f_p2 = prism_rtl::as<crate::lower::model::Ex::XField>(x_p0).a1;
        auto&& _m = through_parent(prism_rtl::deref(prism_rtl::deref(y_p1)));
        if (prism_rtl::is_some(_m)) {
            auto&& z_p3 = prism_rtl::some_of(_m);
            return std::optional(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(z_p3), f_p2}));
        }
        if (prism_rtl::is_none(_m)) {
            return std::optional<crate::lower::model::Ex>{};
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XPart>(x_p0)) {
        auto&& y_p4 = prism_rtl::as<crate::lower::model::Ex::XPart>(x_p0).a0;
        auto&& k_p5 = prism_rtl::as<crate::lower::model::Ex::XPart>(x_p0).a1;
        auto&& _m = through_parent(prism_rtl::deref(prism_rtl::deref(y_p4)));
        if (prism_rtl::is_some(_m)) {
            auto&& z_p6 = prism_rtl::some_of(_m);
            return std::optional(crate::lower::model::Ex(crate::lower::model::Ex::XPart{prism_rtl::rc(z_p6), k_p5}));
        }
        if (prism_rtl::is_none(_m)) {
            return std::optional<crate::lower::model::Ex>{};
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XMethod>(x_p0)) {
        auto&& y_p7 = prism_rtl::as<crate::lower::model::Ex::XMethod>(x_p0).a0;
        auto&& m_p8 = prism_rtl::as<crate::lower::model::Ex::XMethod>(x_p0).a1;
        auto&& xs_p9 = prism_rtl::as<crate::lower::model::Ex::XMethod>(x_p0).a2;
        auto&& _m = through_parent(prism_rtl::deref(prism_rtl::deref(y_p7)));
        if (prism_rtl::is_some(_m)) {
            auto&& z_pa = prism_rtl::some_of(_m);
            return std::optional(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(z_pa), m_p8, xs_p9}));
        }
        if (prism_rtl::is_none(_m)) {
            return std::optional<crate::lower::model::Ex>{};
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XUpgrade>(x_p0)) {
        auto&& y_pb = prism_rtl::as<crate::lower::model::Ex::XUpgrade>(x_p0).a0;
        auto&& _m = through_parent(prism_rtl::deref(prism_rtl::deref(y_pb)));
        if (prism_rtl::is_some(_m)) {
            auto&& z_pc = prism_rtl::some_of(_m);
            return std::optional(crate::lower::model::Ex(crate::lower::model::Ex::XUpgrade{prism_rtl::rc(z_pc)}));
        }
        if (prism_rtl::is_none(_m)) {
            return std::optional<crate::lower::model::Ex>{};
        }
        prism_rtl::unreachable("no arm matched");
    }
    {
        return std::optional<crate::lower::model::Ex>{};
    }
}


/// Own: fn Vl -> Ex
crate::lower::model::Ex own(const Vl& vl0) {
    if (prism_rtl::is<Vl::VlPlace>(vl0) && prism_rtl::is<Holding::RcRef>(prism_rtl::as<Vl::VlPlace>(vl0).a1)) {
        auto&& x_p0 = prism_rtl::as<Vl::VlPlace>(vl0).a0;
        return crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XDeref{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XDeref{prism_rtl::rc(x_p0)}))}))});
    }
    if (prism_rtl::is<Vl::VlPlace>(vl0) && prism_rtl::is<Holding::RcOwned>(prism_rtl::as<Vl::VlPlace>(vl0).a1)) {
        auto&& x_p1 = prism_rtl::as<Vl::VlPlace>(vl0).a0;
        return crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XDeref{prism_rtl::rc(x_p1)}))});
    }
    if (prism_rtl::is<Vl::VlPlace>(vl0)) {
        auto&& x_p2 = prism_rtl::as<Vl::VlPlace>(vl0).a0;
        auto&& mode_p3 = prism_rtl::as<Vl::VlPlace>(vl0).a1;
        auto&& t_p4 = prism_rtl::as<Vl::VlPlace>(vl0).a2;
        return is_copy(t_p4)
            ? crate::lower::types::copy(Vl(Vl::VlPlace{x_p2, mode_p3, t_p4}))
            : crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(x_p2)});
    }
    if (prism_rtl::is<Vl::VlOwned>(vl0)) {
        auto&& e_p5 = prism_rtl::as<Vl::VlOwned>(vl0).a0;
        return e_p5;
    }
    prism_rtl::unreachable("no arm matched");
}


/// Ref: fn Vl -> Ex
crate::lower::model::Ex ref_(const Vl& vl0) {
    if (prism_rtl::is<Vl::VlPlace>(vl0) && prism_rtl::is<Holding::ByRef>(prism_rtl::as<Vl::VlPlace>(vl0).a1)) {
        auto&& x_p0 = prism_rtl::as<Vl::VlPlace>(vl0).a0;
        return x_p0;
    }
    if (prism_rtl::is<Vl::VlPlace>(vl0) && prism_rtl::is<Holding::RcRef>(prism_rtl::as<Vl::VlPlace>(vl0).a1)) {
        auto&& x_p1 = prism_rtl::as<Vl::VlPlace>(vl0).a0;
        return crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XDeref{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XDeref{prism_rtl::rc(x_p1)}))}))});
    }
    if (prism_rtl::is<Vl::VlPlace>(vl0) && prism_rtl::is<Holding::RcOwned>(prism_rtl::as<Vl::VlPlace>(vl0).a1)) {
        auto&& x_p2 = prism_rtl::as<Vl::VlPlace>(vl0).a0;
        return crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XDeref{prism_rtl::rc(x_p2)}))});
    }
    if (prism_rtl::is<Vl::VlPlace>(vl0)) {
        auto&& x_p3 = prism_rtl::as<Vl::VlPlace>(vl0).a0;
        return crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(x_p3)});
    }
    if (prism_rtl::is<Vl::VlOwned>(vl0)) {
        auto&& e_p4 = prism_rtl::as<Vl::VlOwned>(vl0).a0;
        return crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(e_p4)});
    }
    prism_rtl::unreachable("no arm matched");
}


/// Copy: fn Vl -> Ex
crate::lower::model::Ex copy(const Vl& vl0) {
    if (prism_rtl::is<Vl::VlPlace>(vl0) && prism_rtl::is<Holding::ByRef>(prism_rtl::as<Vl::VlPlace>(vl0).a1)) {
        auto&& x_p0 = prism_rtl::as<Vl::VlPlace>(vl0).a0;
        return crate::lower::model::Ex(crate::lower::model::Ex::XDeref{prism_rtl::rc(x_p0)});
    }
    if (prism_rtl::is<Vl::VlPlace>(vl0) && prism_rtl::is<Holding::RcRef>(prism_rtl::as<Vl::VlPlace>(vl0).a1)) {
        auto&& x_p1 = prism_rtl::as<Vl::VlPlace>(vl0).a0;
        return crate::lower::model::Ex(crate::lower::model::Ex::XDeref{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XDeref{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XDeref{prism_rtl::rc(x_p1)}))}))});
    }
    if (prism_rtl::is<Vl::VlPlace>(vl0)) {
        auto&& x_p2 = prism_rtl::as<Vl::VlPlace>(vl0).a0;
        return x_p2;
    }
    if (prism_rtl::is<Vl::VlOwned>(vl0)) {
        auto&& e_p3 = prism_rtl::as<Vl::VlOwned>(vl0).a0;
        return e_p3;
    }
    prism_rtl::unreachable("no arm matched");
}


/// IsCopy: fn OutTy -> Bool
bool is_copy(const crate::lower::model::OutTy& t_p0) {
    return ((((t_p0 == crate::lower::model::OutTy(crate::lower::model::OutTy::OutBool{})) || (t_p0 == crate::lower::model::OutTy(crate::lower::model::OutTy::OutFloat{}))) || (t_p0 == crate::lower::model::OutTy(crate::lower::model::OutTy::OutU8{}))) || (t_p0 == crate::lower::model::OutTy(crate::lower::model::OutTy::OutChar{}))) || (t_p0 == crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}));
}


/// AsBool: fn Vl -> Ex
crate::lower::model::Ex as_bool(const Vl& v_p0) {
    return crate::lower::types::copy(v_p0);
}

}  // namespace crate::lower::types


// The module `Process`, from `target/bootstrap/cpp-src/prelude/process.prism`.
namespace crate::process {

Pod ProcessArgs::to_pod() const {
    return Pod::element(TAG, {});
}


void ProcessArgs::show(Printer& p) const {
    prism_rtl::to_pod(*this).structure();
    Show<Pod>::show(prism_rtl::to_pod(*this), p);
}


Result<ProcessArgs> ProcessArgs::from_pod(const Pod& p) {
    if (auto t = p.tag(); t && *t == TAG) return ProcessArgs{};
    return mismatch<ProcessArgs>("a Process.Args", p);
}


Pod ProcessEnv::to_pod() const {
    return Pod::element(TAG, {{"name", prism_rtl::to_pod(name)}});
}


void ProcessEnv::show(Printer& p) const {
    prism_rtl::to_pod(*this).structure();
    Show<Pod>::show(prism_rtl::to_pod(*this), p);
}


Result<ProcessEnv> ProcessEnv::from_pod(const Pod& p) {
    if (auto t = p.tag(); t && *t == TAG) return ProcessEnv{.name = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(p, "name"))))};
    return mismatch<ProcessEnv>("a Process.Env", p);
}


Pod ProcessExit::to_pod() const {
    return Pod::element(TAG, {});
}


void ProcessExit::show(Printer& p) const {
    prism_rtl::to_pod(*this).structure();
    Show<Pod>::show(prism_rtl::to_pod(*this), p);
}


Result<ProcessExit> ProcessExit::from_pod(const Pod& p) {
    if (auto t = p.tag(); t && *t == TAG) return ProcessExit{};
    return mismatch<ProcessExit>("a Process.Exit", p);
}

}  // namespace crate::process
