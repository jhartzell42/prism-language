// The module `Check.Regex`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <check/regex/module.hpp>

// The module `Check.Regex`, from `target/bootstrap/cpp-src/prismc/check/regex/mod.prism`.
namespace crate::check::regex {

void RxCp::show(Printer& p) const {
    if (auto c = std::get_if<RxLit>(&cases())) p.choice("RxLit", {c->a0});
    else if (auto c = std::get_if<RxNum>(&cases())) p.choice("RxNum", {c->a0});
}

Pod RxCp::to_pod() const {
    return std::holds_alternative<RxLit>(cases()) ? Pod::choice("RxLit", {prism_rtl::to_pod(std::get<RxLit>(cases()).a0)})
        : std::holds_alternative<RxNum>(cases()) ? Pod::choice("RxNum", {prism_rtl::to_pod(std::get<RxNum>(cases()).a0)})
        : Pod();
}

Result<RxCp> RxCp::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "RxLit" && c->args.size() == 1) return RxCp(RxLit{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "RxNum" && c->args.size() == 1) return RxCp(RxNum{TRY(prism_rtl::from_pod<Nat>(c->args[0]))});
    }
    return mismatch<RxCp>("a RxCp", p);
}


void RxDiag::show(Printer& p) const {
    p.record("RxDiag", {{"part", part_p}, {"at", at_p}, {"message", message_p}});
}

Pod RxDiag::to_pod() const {
    return Pod::record("RxDiag", {{"part", prism_rtl::to_pod(part_p)}, {"at", prism_rtl::to_pod(at_p)}, {"message", prism_rtl::to_pod(message_p)}});
}

Result<RxDiag> RxDiag::from_pod(const Pod& whole) {
    return RxDiag{.part_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "part")))), .at_p = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "at")))), .message_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "message"))))};
}


void RxLast::show(Printer& p) const {
    if (auto c = std::get_if<RxLastNothing>(&cases())) p.choice("RxLastNothing", {});
    else if (auto c = std::get_if<RxLastFlagGroup>(&cases())) p.choice("RxLastFlagGroup", {});
    else if (auto c = std::get_if<RxLastAssertion>(&cases())) p.choice("RxLastAssertion", {});
    else if (auto c = std::get_if<RxLastRepetition>(&cases())) p.choice("RxLastRepetition", {});
    else if (auto c = std::get_if<RxLastAtom>(&cases())) p.choice("RxLastAtom", {});
}

Pod RxLast::to_pod() const {
    return std::holds_alternative<RxLastNothing>(cases()) ? Pod::choice("RxLastNothing", {})
        : std::holds_alternative<RxLastFlagGroup>(cases()) ? Pod::choice("RxLastFlagGroup", {})
        : std::holds_alternative<RxLastAssertion>(cases()) ? Pod::choice("RxLastAssertion", {})
        : std::holds_alternative<RxLastRepetition>(cases()) ? Pod::choice("RxLastRepetition", {})
        : std::holds_alternative<RxLastAtom>(cases()) ? Pod::choice("RxLastAtom", {})
        : Pod();
}

Result<RxLast> RxLast::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "RxLastNothing" && c->args.size() == 0) return RxLast(RxLastNothing{});
        if (c->ctor == "RxLastFlagGroup" && c->args.size() == 0) return RxLast(RxLastFlagGroup{});
        if (c->ctor == "RxLastAssertion" && c->args.size() == 0) return RxLast(RxLastAssertion{});
        if (c->ctor == "RxLastRepetition" && c->args.size() == 0) return RxLast(RxLastRepetition{});
        if (c->ctor == "RxLastAtom" && c->args.size() == 0) return RxLast(RxLastAtom{});
    }
    return mismatch<RxLast>("a RxLast", p);
}


void RxMeasure::show(Printer& p) const {
    p.record("RxMeasure", {{"depth", depth_p}, {"size", size_p}, {"product", product_p}});
}

Pod RxMeasure::to_pod() const {
    return Pod::record("RxMeasure", {{"depth", prism_rtl::to_pod(depth_p)}, {"size", prism_rtl::to_pod(size_p)}, {"product", prism_rtl::to_pod(product_p)}});
}

Result<RxMeasure> RxMeasure::from_pod(const Pod& whole) {
    return RxMeasure{.depth_p = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "depth")))), .size_p = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "size")))), .product_p = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "product"))))};
}


void RxState::show(Printer& p) const {
    p.record("RxState", {{"s", s_p}, {"i", i_p}, {"open", open_p}, {"groups", groups_p}, {"names", names_p}, {"err", err_o}});
}

Pod RxState::to_pod() const {
    return Pod::record("RxState", {{"s", prism_rtl::to_pod(s_p)}, {"i", prism_rtl::to_pod(i_p)}, {"open", prism_rtl::to_pod(open_p)}, {"groups", prism_rtl::to_pod(groups_p)}, {"names", prism_rtl::to_pod(names_p)}, {"err", prism_rtl::to_pod(err_o)}});
}

Result<RxState> RxState::from_pod(const Pod& whole) {
    return RxState{.s_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "s")))), .i_p = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "i")))), .open_p = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "open")))), .groups_p = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "groups")))), .names_p = TRY(prism_rtl::from_pod<Map<Text, Nat>>(TRY(crate::prelude::field(whole, "names")))), .err_o = TRY(prism_rtl::from_pod<std::optional<RxDiag>>(TRY(crate::prelude::field(whole, "err"))))};
}


/// let rxUnknownFlag
Text rx_unknown_flag_p() {
    return Text::lit("an unknown flag: the flags are i, m and s");
}


/// let rxFlagTwice
Text rx_flag_twice_p() {
    return Text::lit("a flag written twice");
}


/// let rxStrayBracket
Text rx_stray_bracket_p() {
    return Text::lit("a ] outside a class: a literal one is \\]");
}


/// let rxStrayBrace
Text rx_stray_brace_p() {
    return Text::lit("a } outside a count: a literal one is \\}");
}


/// let rxTrailingBackslash
Text rx_trailing_backslash_p() {
    return Text::lit("a \\ at the end of the pattern");
}


/// let rxHexTwo
Text rx_hex_two_p() {
    return Text::lit("a \\x escape needs two hex digits or braces");
}


/// let rxHexBraces
Text rx_hex_braces_p() {
    return Text::lit("a \\x{...} escape needs one to six hex digits");
}


/// let rxHexNoChar
Text rx_hex_no_char_p() {
    return Text::lit("a \\x escape names no character: a surrogate or past U+10FFFF");
}


/// let rxWordBraces
Text rx_word_braces_p() {
    return Text::lit("\\b{...} is Rust\'s only: write \\b");
}


/// let rxAngle
Text rx_angle_p() {
    return Text::lit("\\< and \\> are Rust\'s only: write \\b");
}


/// let rxBackreference
Text rx_backreference_p() {
    return Text::lit("a backreference: refused so that every match is linear in its text");
}


/// let rxOctal
Text rx_octal_p() {
    return Text::lit("an octal escape is RE2\'s only: write \\x");
}


/// let rxQuote
Text rx_quote_p() {
    return Text::lit("\\Q...\\E is RE2\'s only: escape each character");
}


/// let rxOneByte
Text rx_one_byte_p() {
    return Text::lit("\\C, one byte, is RE2\'s only");
}


/// let rxUnknownEscape
Text rx_unknown_escape_p() {
    return Text::lit("an unknown escape");
}


/// let rxPropertyName
Text rx_property_name_p() {
    return Text::lit("a \\p escape needs a property name");
}


/// let rxPropertyOpen
Text rx_property_open_p() {
    return Text::lit("a \\p{ that is never closed");
}


/// let rxPropertyNegated
Text rx_property_negated_p() {
    return Text::lit("a negated property is written \\P{...}");
}


/// let rxPropertyRefused
Text rx_property_refused_p() {
    return Text::lit("the property is refused: RE2 and Rust disagree on C, Cn, Cs and LC");
}


/// let rxPropertyUnknown
Text rx_property_unknown_p() {
    return Text::lit("an unknown property: general categories by short name, scripts and Any");
}


/// let rxClassOpen
Text rx_class_open_p() {
    return Text::lit("a class opened here is never closed");
}


/// let rxClassFirstBracket
Text rx_class_first_bracket_p() {
    return Text::lit("a ] first in a class: write \\]");
}


/// let rxClassNested
Text rx_class_nested_p() {
    return Text::lit("a [ inside a class: write \\[ (nested classes are Rust\'s only)");
}


/// let rxClassAsciiUnknown
Text rx_class_ascii_unknown_p() {
    return Text::lit("an unknown ASCII class");
}


/// let rxClassSetOperation
Text rx_class_set_operation_p() {
    return Text::lit("&&, ~~ and -- in a class are Rust\'s set operations: escape them");
}


/// let rxClassDash
Text rx_class_dash_p() {
    return Text::lit("a - in a class that is neither a range nor first or last: write \\-");
}


/// let rxClassOrder
Text rx_class_order_p() {
    return Text::lit("a range whose ends are out of order");
}


/// let rxClassRangeSet
Text rx_class_range_set_p() {
    return Text::lit("a range end that is a class");
}


/// let rxClassNegatedUnderI
Text rx_class_negated_under_i_p() {
    return Text::lit("a negated class inside a class under i: write it outside the class");
}


/// let rxClassEscape
Text rx_class_escape_p() {
    return Text::lit("an escape that a class cannot hold");
}


/// let rxLookaround
Text rx_lookaround_p() {
    return Text::lit("a lookaround: refused so that every match is linear in its text");
}


/// let rxUnknownGroup
Text rx_unknown_group_p() {
    return Text::lit("an unknown group: the groups are (re), (?:re), (?<name>re), (?P<name>re) and the flag groups");
}


/// let rxNameShape
Text rx_name_shape_p() {
    return Text::lit("a group name is a lowercase value name, [a-z_][a-z0-9_]*");
}


/// let rxNameOpen
Text rx_name_open_p() {
    return Text::lit("a group name that is never closed");
}


/// let rxNameTwice
Text rx_name_twice_p() {
    return Text::lit("a group name used twice");
}


/// let rxGroupOpen
Text rx_group_open_p() {
    return Text::lit("a group opened here is never closed");
}


/// let rxGroupClose
Text rx_group_close_p() {
    return Text::lit("a ) that closes no group");
}


/// let rxFlagsEmpty
Text rx_flags_empty_p() {
    return Text::lit("an empty flag group");
}


/// let rxFlagsSecondDash
Text rx_flags_second_dash_p() {
    return Text::lit("a second - in a flag group");
}


/// let rxFlagsDash
Text rx_flags_dash_p() {
    return Text::lit("a - that turns off no flag");
}


/// let rxBrace
Text rx_brace_p() {
    return Text::lit("a brace that opens no count: a literal one is \\{");
}


/// let rxCountZero
Text rx_count_zero_p() {
    return Text::lit("a count with a leading zero");
}


/// let rxCountBound
Text rx_count_bound_p() {
    return Text::lit("a count above 1000");
}


/// let rxCountOrder
Text rx_count_order_p() {
    return Text::lit("a count whose minimum exceeds its maximum");
}


/// let rxNothingToRepeat
Text rx_nothing_to_repeat_p() {
    return Text::lit("a repetition with nothing to repeat");
}


/// let rxRepeatRepeat
Text rx_repeat_repeat_p() {
    return Text::lit("a repetition of a repetition: write (?:a*)* to say it");
}


/// let rxRepeatAssertion
Text rx_repeat_assertion_p() {
    return Text::lit("a repetition of an assertion");
}


/// let rxProduct
Text rx_product_p() {
    return Text::lit("nested counts multiplying past 1000");
}


/// let rxNesting
Text rx_nesting_p() {
    return Text::lit("groups and repetitions nested more than 100 deep");
}


/// let rxSize
Text rx_size_p() {
    return Text::lit("the pattern expands past 10,000 atoms");
}


/// let rxRZero
Text rx_rzero_p() {
    return Text::lit("a group number with a leading zero");
}


/// let rxRBraces
Text rx_rbraces_p() {
    return Text::lit("a ${...} that is neither a group number nor a group name");
}


/// let rxRDollar
Text rx_rdollar_p() {
    return Text::lit("a $ that is not $n, ${n}, ${name} or $$");
}


/// let rxRNoNumber
Text rx_rno_number_p() {
    return Text::lit("the pattern has no group of that number");
}


/// let rxRNoName
Text rx_rno_name_p() {
    return Text::lit("the pattern has no group of that name");
}


/// let rxRUnicode
Text rx_runicode_p() {
    return Text::lit("a \\u{...} escape needs one to six hex digits naming a character");
}


/// let rxREscape
Text rx_rescape_p() {
    return Text::lit("an unknown escape in a replacement: the escapes are \\\\, \\n, \\t, \\u{hex} and \\/");
}


/// let rxCategories
Array<Text> rx_categories_p() {
    return Array(std::vector{Text::lit("Cc"), Text::lit("Cf"), Text::lit("Co"), Text::lit("L"), Text::lit("Ll"), Text::lit("Lm"), Text::lit("Lo"), Text::lit("Lt"), Text::lit("Lu"), Text::lit("M"), Text::lit("Mc"), Text::lit("Me"), Text::lit("Mn"), Text::lit("N"), Text::lit("Nd"), Text::lit("Nl"), Text::lit("No"), Text::lit("P"), Text::lit("Pc"), Text::lit("Pd"), Text::lit("Pe"), Text::lit("Pf"), Text::lit("Pi"), Text::lit("Po"), Text::lit("Ps"), Text::lit("S"), Text::lit("Sc"), Text::lit("Sk"), Text::lit("Sm"), Text::lit("So"), Text::lit("Z"), Text::lit("Zl"), Text::lit("Zp"), Text::lit("Zs")});
}


/// let rxScripts
Array<Text> rx_scripts_p() {
    return Array(std::vector{Text::lit("Adlam"), Text::lit("Ahom"), Text::lit("Anatolian_Hieroglyphs"), Text::lit("Arabic"), Text::lit("Armenian"), Text::lit("Avestan"), Text::lit("Balinese"), Text::lit("Bamum"), Text::lit("Bassa_Vah"), Text::lit("Batak"), Text::lit("Bengali"), Text::lit("Bhaiksuki"), Text::lit("Bopomofo"), Text::lit("Brahmi"), Text::lit("Braille"), Text::lit("Buginese"), Text::lit("Buhid"), Text::lit("Canadian_Aboriginal"), Text::lit("Carian"), Text::lit("Caucasian_Albanian"), Text::lit("Chakma"), Text::lit("Cham"), Text::lit("Cherokee"), Text::lit("Chorasmian"), Text::lit("Common"), Text::lit("Coptic"), Text::lit("Cuneiform"), Text::lit("Cypriot"), Text::lit("Cypro_Minoan"), Text::lit("Cyrillic"), Text::lit("Deseret"), Text::lit("Devanagari"), Text::lit("Dives_Akuru"), Text::lit("Dogra"), Text::lit("Duployan"), Text::lit("Egyptian_Hieroglyphs"), Text::lit("Elbasan"), Text::lit("Elymaic"), Text::lit("Ethiopic"), Text::lit("Georgian"), Text::lit("Glagolitic"), Text::lit("Gothic"), Text::lit("Grantha"), Text::lit("Greek"), Text::lit("Gujarati"), Text::lit("Gunjala_Gondi"), Text::lit("Gurmukhi"), Text::lit("Han"), Text::lit("Hangul"), Text::lit("Hanifi_Rohingya"), Text::lit("Hanunoo"), Text::lit("Hatran"), Text::lit("Hebrew"), Text::lit("Hiragana"), Text::lit("Imperial_Aramaic"), Text::lit("Inherited"), Text::lit("Inscriptional_Pahlavi"), Text::lit("Inscriptional_Parthian"), Text::lit("Javanese"), Text::lit("Kaithi"), Text::lit("Kannada"), Text::lit("Katakana"), Text::lit("Kawi"), Text::lit("Kayah_Li"), Text::lit("Kharoshthi"), Text::lit("Khitan_Small_Script"), Text::lit("Khmer"), Text::lit("Khojki"), Text::lit("Khudawadi"), Text::lit("Lao"), Text::lit("Latin"), Text::lit("Lepcha"), Text::lit("Limbu"), Text::lit("Linear_A"), Text::lit("Linear_B"), Text::lit("Lisu"), Text::lit("Lycian"), Text::lit("Lydian"), Text::lit("Mahajani"), Text::lit("Makasar"), Text::lit("Malayalam"), Text::lit("Mandaic"), Text::lit("Manichaean"), Text::lit("Marchen"), Text::lit("Masaram_Gondi"), Text::lit("Medefaidrin"), Text::lit("Meetei_Mayek"), Text::lit("Mende_Kikakui"), Text::lit("Meroitic_Cursive"), Text::lit("Meroitic_Hieroglyphs"), Text::lit("Miao"), Text::lit("Modi"), Text::lit("Mongolian"), Text::lit("Mro"), Text::lit("Multani"), Text::lit("Myanmar"), Text::lit("Nabataean"), Text::lit("Nag_Mundari"), Text::lit("Nandinagari"), Text::lit("New_Tai_Lue"), Text::lit("Newa"), Text::lit("Nko"), Text::lit("Nushu"), Text::lit("Nyiakeng_Puachue_Hmong"), Text::lit("Ogham"), Text::lit("Ol_Chiki"), Text::lit("Old_Hungarian"), Text::lit("Old_Italic"), Text::lit("Old_North_Arabian"), Text::lit("Old_Permic"), Text::lit("Old_Persian"), Text::lit("Old_Sogdian"), Text::lit("Old_South_Arabian"), Text::lit("Old_Turkic"), Text::lit("Old_Uyghur"), Text::lit("Oriya"), Text::lit("Osage"), Text::lit("Osmanya"), Text::lit("Pahawh_Hmong"), Text::lit("Palmyrene"), Text::lit("Pau_Cin_Hau"), Text::lit("Phags_Pa"), Text::lit("Phoenician"), Text::lit("Psalter_Pahlavi"), Text::lit("Rejang"), Text::lit("Runic"), Text::lit("Samaritan"), Text::lit("Saurashtra"), Text::lit("Sharada"), Text::lit("Shavian"), Text::lit("Siddham"), Text::lit("SignWriting"), Text::lit("Sinhala"), Text::lit("Sogdian"), Text::lit("Sora_Sompeng"), Text::lit("Soyombo"), Text::lit("Sundanese"), Text::lit("Syloti_Nagri"), Text::lit("Syriac"), Text::lit("Tagalog"), Text::lit("Tagbanwa"), Text::lit("Tai_Le"), Text::lit("Tai_Tham"), Text::lit("Tai_Viet"), Text::lit("Takri"), Text::lit("Tamil"), Text::lit("Tangsa"), Text::lit("Tangut"), Text::lit("Telugu"), Text::lit("Thaana"), Text::lit("Thai"), Text::lit("Tibetan"), Text::lit("Tifinagh"), Text::lit("Tirhuta"), Text::lit("Toto"), Text::lit("Ugaritic"), Text::lit("Vai"), Text::lit("Vithkuqi"), Text::lit("Wancho"), Text::lit("Warang_Citi"), Text::lit("Yezidi"), Text::lit("Yi"), Text::lit("Zanabazar_Square")});
}


/// let rxProperties
Map<Text, bool> rx_properties_p() {
    return crate::prelude::map(crate::prelude::each(crate::prelude::push(crate::prelude::append(rx_categories_p(), rx_scripts_p()), Text::lit("Any")), [&](const Text& n_p0) { return std::tuple{n_p0, true}; }));
}


/// let rxAsciiClasses
Map<Text, bool> rx_ascii_classes_p() {
    return crate::prelude::map(crate::prelude::each(Array(std::vector{Text::lit("alnum"), Text::lit("alpha"), Text::lit("ascii"), Text::lit("blank"), Text::lit("cntrl"), Text::lit("digit"), Text::lit("graph"), Text::lit("lower"), Text::lit("print"), Text::lit("punct"), Text::lit("space"), Text::lit("upper"), Text::lit("word"), Text::lit("xdigit")}), [&](const Text& n_p0) { return std::tuple{n_p0, true}; }));
}


/// let rxAscii
Text rx_ascii_p() {
    return Text::lit("\000\t\n\r !\"#$%&\'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~"sv);
}


/// let rxPunctuation
Text rx_punctuation_p() {
    return Text::lit("!\"#$%&\'()*+,-./:;=?@[\\]^_`{|}~");
}


/// let rxNone
RxMeasure rx_none_p() {
    return RxMeasure{.depth_p = Nat(0u), .size_p = Nat(0u), .product_p = Nat(0u)};
}


/// let rxAtom
RxMeasure rx_atom_p() {
    return RxMeasure{.depth_p = Nat(0u), .size_p = Nat(1u), .product_p = Nat(1u)};
}


/// RxThen: fn RxMeasure, RxMeasure -> RxMeasure
RxMeasure rx_then_f(const RxMeasure& a_p0, const RxMeasure& b_p1) {
    return RxMeasure{.depth_p = crate::prelude::max(a_p0.depth_p, b_p1.depth_p), .size_p = a_p0.size_p + b_p1.size_p, .product_p = crate::prelude::max(a_p0.product_p, b_p1.product_p)};
}


/// RxBad: fn RxState -> Bool
bool rx_bad_f(const RxState& st_p0) {
    return st_p0.err_o != std::optional<RxDiag>{};
}


/// RxFail: fn RxState, Nat, Text -> RxState
RxState rx_fail_f(const RxState& st_p0, const Nat& at_p1, const Text& message_p2) {
    return rx_bad_f(st_p0)
        ? st_p0
        : RxState{.s_p = st_p0.s_p, .i_p = st_p0.i_p, .open_p = st_p0.open_p, .groups_p = st_p0.groups_p, .names_p = st_p0.names_p, .err_o = std::optional(RxDiag{.part_p = Text::lit("pattern"), .at_p = at_p1, .message_p = message_p2})};
}


/// RxGo: fn RxState, Nat -> RxState
RxState rx_go_f(const RxState& st_p0, const Nat& n_p1) {
    RxState this_ = st_p0;
    this_.i_p = n_p1;
    return this_;
}


/// RxPeek: fn RxState -> Text
Text rx_peek_f(const RxState& st_p0) {
    return rx_char_at_f(st_p0.s_p, st_p0.i_p);
}


/// RxCharAt: fn Text, Nat -> Text
Text rx_char_at_f(const Text& t_p0, const Nat& n_p1) {
    auto&& _m = crate::prelude::cursor_at(t_p0, n_p1);
    if (prism_rtl::is_some(_m)) {
        auto&& c_p2 = prism_rtl::some_of(_m);
        auto&& _m = crate::prelude::step(crate::prelude::front(crate::prelude::after(c_p2)));
        if (prism_rtl::is_some(_m)) {
            auto&& one_p3 = std::get<1>(prism_rtl::some_of(_m));
            return crate::prelude::before(one_p3);
        }
        if (prism_rtl::is_none(_m)) {
            return Text::lit("");
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is_none(_m)) {
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}


/// RxSlice: fn Text, Nat, Nat -> Text
Text rx_slice_f(const Text& t_p0, const Nat& a_p1, const Nat& b_p2) {
    auto&& _m = crate::prelude::cursor_at(t_p0, b_p2);
    if (prism_rtl::is_some(_m)) {
        auto&& cb_p3 = prism_rtl::some_of(_m);
        auto&& _m = crate::prelude::cursor_at(crate::prelude::before(cb_p3), a_p1);
        if (prism_rtl::is_some(_m)) {
            auto&& ca_p4 = prism_rtl::some_of(_m);
            return crate::prelude::after(ca_p4);
        }
        if (prism_rtl::is_none(_m)) {
            return Text::lit("");
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is_none(_m)) {
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}


/// ?RxFind: fn Text, Nat, Text -> ?Nat
std::optional<Nat> rx_find_o(const Text& t_p0, const Nat& from_p1, const Text& x_p2) {
    auto&& _m = crate::prelude::cursor_at(t_p0, from_p1);
    if (prism_rtl::is_none(_m)) {
        return std::optional<Nat>{};
    }
    if (prism_rtl::is_some(_m)) {
        auto&& c0_p3 = prism_rtl::some_of(_m);
        auto&& _found_o7 = ({
            std::tuple<std::optional<Nat>, Cursor> this_ = std::tuple{std::optional<Nat>{}, c0_p3};
            Cursor c_p4 = c0_p3;
            std::optional<Nat> found_o5 = std::optional<Nat>{};
            while (true) {
                auto&& _m = crate::prelude::step(c_p4);
                if (!(prism_rtl::is_some(_m))) break;
                auto&& next_p6 = std::get<1>(prism_rtl::some_of(_m));
                if (!(found_o5 == std::optional<Nat>{})) {
                    break;
                }
                if (rx_slice_f(t_p0, crate::prelude::at(c_p4), crate::prelude::at(next_p6)) == x_p2) {
                    found_o5 = std::optional(crate::prelude::at(c_p4));
                }
                c_p4 = next_p6;
            }
            this_ = std::tuple{found_o5, c_p4};
            (std::move(this_));
        });
        auto&& found_o7 = std::get<0>(_found_o7);
        return found_o7;
    }
    prism_rtl::unreachable("no arm matched");
}


/// RxIn: fn Text, Text -> Bool
bool rx_in_f(const Text& set_p0, const Text& c_p1) {
    return (c_p1 != Text::lit("")) && (rx_find_o(set_p0, Nat(0u), c_p1) != std::optional<Nat>{});
}


/// RxIsDigit: fn Text -> Bool
bool rx_is_digit_f(const Text& c_p0) {
    return ((Text::lit("0") <= c_p0) && (c_p0 <= Text::lit("9"))) && (crate::prelude::len_text(c_p0) == Nat(1u));
}


/// RxIsLetter: fn Text -> Bool
bool rx_is_letter_f(const Text& c_p0) {
    return ((Text::lit("a") <= c_p0) && (c_p0 <= Text::lit("z"))) || ((Text::lit("A") <= c_p0) && (c_p0 <= Text::lit("Z")));
}


/// RxIsHex: fn Text -> Bool
bool rx_is_hex_f(const Text& c_p0) {
    return (rx_is_digit_f(c_p0) || ((Text::lit("a") <= c_p0) && (c_p0 <= Text::lit("f")))) || ((Text::lit("A") <= c_p0) && (c_p0 <= Text::lit("F")));
}


/// RxIsName: fn Text -> Bool
bool rx_is_name_f(const Text& t_p0) {
    auto first_p1 = rx_char_at_f(t_p0, Nat(0u));
    return ((t_p0 != Text::lit("")) && (((Text::lit("a") <= first_p1) && (first_p1 <= Text::lit("z"))) || (first_p1 == Text::lit("_")))) && rx_all_f(t_p0, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>>(prism_rtl::rc([=](Text p0) {
        return crate::prelude::once_job([=]() {
            return ({
                auto c_p2 = p0;
                (prism_rtl::finished((((Text::lit("a") <= c_p2) && (c_p2 <= Text::lit("z"))) || rx_is_digit_f(c_p2)) || (c_p2 == Text::lit("_"))));
            });
        });
    })));
}


/// RxAll: fn Text, (fn Text -> Bool) -> Bool
bool rx_all_f(const Text& t_p0, const prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>& p_f1) {
    bool this_ = true;
    Cursor c_p2 = crate::prelude::front(t_p0);
    while (true) {
        auto&& _m = crate::prelude::step(c_p2);
        if (!(prism_rtl::is_some(_m))) break;
        auto&& next_p3 = std::get<1>(prism_rtl::some_of(_m));
        if (!crate::prelude::run_to_end(p_f1(rx_slice_f(t_p0, crate::prelude::at(c_p2), crate::prelude::at(next_p3))))) {
            this_ = false;
        }
        c_p2 = next_p3;
    }
    return this_;
}


prism_rtl::Turn<bool> RxAll::cycle() const {
    const auto& t_p0 = this->t_p0;
    const auto& p_f1 = this->p_f1;
    return prism_rtl::finished(({
        bool this_ = true;
        Cursor c_p2 = crate::prelude::front(t_p0);
        while (true) {
            auto&& _m = crate::prelude::step(c_p2);
            if (!(prism_rtl::is_some(_m))) break;
            auto&& next_p3 = std::get<1>(prism_rtl::some_of(_m));
            if (!crate::prelude::run_to_end(p_f1(rx_slice_f(t_p0, crate::prelude::at(c_p2), crate::prelude::at(next_p3))))) {
                this_ = false;
            }
            c_p2 = next_p3;
        }
        (std::move(this_));
    }));
}


/// `Start RxAll, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_rx_all_f(Text t_p0, prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)> p_f1) {
    return prism_rtl::make_rc<RxAll>(t_p0, p_f1);
}


/// RxSpanEnd: unbounded fn Text, Nat, (fn Text -> Bool) -> Nat
Nat rx_span_end_f(const Text& t_p0, const Nat& at_p1, const prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>& p_f2) {
    Nat this_ = at_p1;
    while (crate::prelude::run_to_end(p_f2(rx_char_at_f(t_p0, this_)))) {
        this_ = this_ + Nat(1u);
    }
    return this_;
}


prism_rtl::Turn<Nat> RxSpanEnd::cycle() const {
    const auto& t_p0 = this->t_p0;
    const auto& at_p1 = this->at_p1;
    const auto& p_f2 = this->p_f2;
    Nat this_ = at_p1;
    return crate::prelude::call_then(crate::prelude::loop_job(std::tuple{std::move(this_)}, ({
        auto p_f2x = p_f2;
        auto t_p0x = t_p0;
        [=, p_f2x = std::move(p_f2x), t_p0x = std::move(t_p0x)](std::tuple<Nat> _p0) {
        auto this_ = std::get<0>(_p0);
        return crate::prelude::run_to_end(p_f2x(rx_char_at_f(t_p0x, this_)))
            ? ({
            this_ = this_ + Nat(1u);
            Expected<std::tuple<Nat>, std::tuple<Nat>>(std::tuple{this_});
        })
            : Expected<std::tuple<Nat>, std::tuple<Nat>>(unexpected(std::tuple{this_}));
    };
    })), [=](std::tuple<Nat> _p0) {
        auto this_ = std::get<0>(_p0);
        return prism_rtl::finished(this_);
    });
}


/// `Start RxSpanEnd, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Nat> start_rx_span_end_f(Text t_p0, Nat at_p1, prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)> p_f2) {
    return prism_rtl::make_rc<RxSpanEnd>(t_p0, at_p1, p_f2);
}


/// RxHexValue: fn Text -> Nat
Nat rx_hex_value_f(const Text& t_p0) {
    Nat this_ = Nat(0u);
    Cursor c_p1 = crate::prelude::front(t_p0);
    while (true) {
        auto&& _m = crate::prelude::step(c_p1);
        if (!(prism_rtl::is_some(_m))) break;
        auto&& next_p2 = std::get<1>(prism_rtl::some_of(_m));
        auto d_p3 = rx_slice_f(t_p0, crate::prelude::at(c_p1), crate::prelude::at(next_p2));
        this_ = (this_ * Nat(16u)) + crate::prelude::or_(rx_find_o(Text::lit("0123456789abcdef"), Nat(0u), crate::prelude::lower(d_p3)), Nat(0u));
        c_p1 = next_p2;
    }
    return this_;
}


/// RxCpOf: fn Nat -> RxCp
RxCp rx_cp_of_f(const Nat& v_p0) {
    return v_p0 < Nat(128u)
        ? RxCp(RxCp::RxLit{rx_char_at_f(rx_ascii_p(), v_p0)})
        : RxCp(RxCp::RxNum{v_p0});
}


/// RxWidth: fn Nat -> Nat
Nat rx_width_f(const Nat& v_p0) {
    return v_p0 < Nat(128u)
        ? Nat(1u)
        : v_p0 < Nat(2048u) ? Nat(2u) : v_p0 < Nat(65536u) ? Nat(3u) : Nat(4u);
}


/// RxPast: fn RxCp, RxCp -> Bool
bool rx_past_f(const RxCp& rx_cp0, const RxCp& rx_cp1) {
    auto&& _m = std::tuple{rx_cp0, rx_cp1};
    if (prism_rtl::is<RxCp::RxLit>(std::get<0>(_m)) && prism_rtl::is<RxCp::RxLit>(std::get<1>(_m))) {
        auto&& a_p0 = prism_rtl::as<RxCp::RxLit>(std::get<0>(_m)).a0;
        auto&& b_p1 = prism_rtl::as<RxCp::RxLit>(std::get<1>(_m)).a0;
        return a_p0 > b_p1;
    }
    if (prism_rtl::is<RxCp::RxNum>(std::get<0>(_m)) && prism_rtl::is<RxCp::RxNum>(std::get<1>(_m))) {
        auto&& a_p2 = prism_rtl::as<RxCp::RxNum>(std::get<0>(_m)).a0;
        auto&& b_p3 = prism_rtl::as<RxCp::RxNum>(std::get<1>(_m)).a0;
        return a_p2 > b_p3;
    }
    if (prism_rtl::is<RxCp::RxLit>(std::get<0>(_m)) && prism_rtl::is<RxCp::RxNum>(std::get<1>(_m))) {
        auto&& a_p4 = prism_rtl::as<RxCp::RxLit>(std::get<0>(_m)).a0;
        auto&& b_p5 = prism_rtl::as<RxCp::RxNum>(std::get<1>(_m)).a0;
        return crate::prelude::len_text(a_p4) != rx_width_f(b_p5)
            ? crate::prelude::len_text(a_p4) > rx_width_f(b_p5)
            : !rx_in_range_f(a_p4, Nat(0u), b_p5);
    }
    if (prism_rtl::is<RxCp::RxNum>(std::get<0>(_m)) && prism_rtl::is<RxCp::RxLit>(std::get<1>(_m))) {
        auto&& a_p6 = prism_rtl::as<RxCp::RxNum>(std::get<0>(_m)).a0;
        auto&& b_p7 = prism_rtl::as<RxCp::RxLit>(std::get<1>(_m)).a0;
        return rx_width_f(a_p6) != crate::prelude::len_text(b_p7)
            ? rx_width_f(a_p6) > crate::prelude::len_text(b_p7)
            : !rx_in_range_f(b_p7, a_p6, Nat(1114111u));
    }
    prism_rtl::unreachable("no arm matched");
}


/// RxInRange: fn Text, Nat, Nat -> Bool
bool rx_in_range_f(const Text& c_p0, const Nat& lo_p1, const Nat& hi_p2) {
    auto&& _m = crate::prelude::regex(prism_rtl::cat("[\\x{", rx_hex_text_f(lo_p1), "}-\\x{", rx_hex_text_f(hi_p2), "}]"));
    if (prism_rtl::is_some(_m)) {
        auto&& r_p3 = prism_rtl::some_of(_m);
        return crate::prelude::find(r_p3, c_p0) != std::optional<crate::prelude::Match>{};
    }
    if (prism_rtl::is_none(_m)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// RxHexText: fn Nat -> Text
Text rx_hex_text_f(const Nat& n_p0) {
    Text this_ = Text::lit("");
    Nat k_p1 = n_p0;
    Nat fuel_p2 = Nat(6u);
    while (true) {
        auto&& _m = fuel_p2.checked_sub(Nat(1u));
        if (!(prism_rtl::is_some(_m))) break;
        auto&& left_p3 = prism_rtl::some_of(_m);
        fuel_p2 = left_p3;
        this_ = prism_rtl::cat(rx_char_at_f(Text::lit("0123456789abcdef"), crate::prelude::or_(crate::prelude::mod_(k_p1, Nat(16u)), Nat(0u))), this_);
        k_p1 = crate::prelude::or_(crate::prelude::div(k_p1, Nat(16u)), Nat(0u));
    }
    return this_;
}


/// ?RegexRefusal: unbounded fn Text, Text, ?Text -> ?RxDiag
std::optional<RxDiag> regex_refusal_o(const Text& pattern_p0, const Text& flags_p1, const std::optional<Text>& replacement_o2) {
    auto&& _m = rx_flags_refusal_o(flags_p1);
    if (prism_rtl::is_some(_m)) {
        auto&& d_p3 = prism_rtl::some_of(_m);
        return std::optional(d_p3);
    }
    if (prism_rtl::is_none(_m)) {
        auto st0_p4 = RxState{.s_p = pattern_p0, .i_p = Nat(0u), .open_p = Nat(0u), .groups_p = Nat(0u), .names_p = Map<Text, Nat>{}, .err_o = std::optional<RxDiag>{}};
        auto [m_p5, st_p6] = rx_alternation_f(st0_p4, rx_find_o(flags_p1, Nat(0u), Text::lit("i")) != std::optional<Nat>{});
        auto&& _m = prism_rtl::deref(st_p6).err_o;
        if (prism_rtl::is_some(_m)) {
            auto&& d_p7 = prism_rtl::some_of(_m);
            return std::optional(d_p7);
        }
        if (prism_rtl::is_none(_m)) {
            return prism_rtl::deref(st_p6).i_p < crate::prelude::len_text(pattern_p0)
                ? std::optional(RxDiag{.part_p = Text::lit("pattern"), .at_p = prism_rtl::deref(st_p6).i_p, .message_p = rx_group_close_p()})
                : prism_rtl::deref(m_p5).depth_p > Nat(100u)
                ? std::optional(RxDiag{.part_p = Text::lit("pattern"), .at_p = Nat(0u), .message_p = rx_nesting_p()})
                : prism_rtl::deref(m_p5).size_p > Nat(10000u)
                ? std::optional(RxDiag{.part_p = Text::lit("pattern"), .at_p = Nat(0u), .message_p = rx_size_p()})
                : ({
                __label__ _done;
                prism_rtl::Slot<std::optional<RxDiag>> _v;
                if (prism_rtl::is_none(replacement_o2)) {
                    _v.set(std::optional<RxDiag>{});
                    goto _done;
                }
                if (prism_rtl::is_some(replacement_o2)) {
                    auto&& r_p8 = prism_rtl::some_of(replacement_o2);
                    _v.set(rx_replacement_refusal_o(r_p8, prism_rtl::deref(st_p6).groups_p, prism_rtl::deref(st_p6).names_p));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
        }
        prism_rtl::unreachable("no arm matched");
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::optional<RxDiag>> RegexRefusal::cycle() const {
    const auto& pattern_p0 = this->pattern_p0;
    const auto& flags_p1 = this->flags_p1;
    const auto& replacement_o2 = this->replacement_o2;
    return ({
        auto&& _m = rx_flags_refusal_o(flags_p1);
        prism_rtl::is_some(_m) ? ({
        auto&& d_p3 = prism_rtl::some_of(_m);
        prism_rtl::finished(std::optional(d_p3));
    })
        : prism_rtl::is_none(_m) ? ({
        auto st0_p4 = RxState{.s_p = pattern_p0, .i_p = Nat(0u), .open_p = Nat(0u), .groups_p = Nat(0u), .names_p = Map<Text, Nat>{}, .err_o = std::optional<RxDiag>{}};
        auto replacement_o2x = replacement_o2;
        auto flags_p1x = flags_p1;
        auto pattern_p0x = pattern_p0;
        (crate::prelude::call_then(start_rx_alternation_f(st0_p4, rx_find_o(flags_p1x, Nat(0u), Text::lit("i")) != std::optional<Nat>{}), [=, replacement_o2x = std::move(replacement_o2x), pattern_p0x = std::move(pattern_p0x)](std::tuple<RxMeasure, RxState> rx_alternation_f_15542) {
        return ({
            auto [m_p5, st_p6] = rx_alternation_f_15542;
            ({
            auto&& _m = prism_rtl::deref(st_p6).err_o;
            prism_rtl::is_some(_m) ? ({
            auto&& d_p7 = prism_rtl::some_of(_m);
            prism_rtl::finished(std::optional(d_p7));
        })
            : prism_rtl::is_none(_m) ? prism_rtl::deref(st_p6).i_p < crate::prelude::len_text(pattern_p0x)
            ? prism_rtl::finished(std::optional(RxDiag{.part_p = Text::lit("pattern"), .at_p = prism_rtl::deref(st_p6).i_p, .message_p = rx_group_close_p()}))
            : prism_rtl::deref(m_p5).depth_p > Nat(100u)
            ? prism_rtl::finished(std::optional(RxDiag{.part_p = Text::lit("pattern"), .at_p = Nat(0u), .message_p = rx_nesting_p()}))
            : prism_rtl::deref(m_p5).size_p > Nat(10000u)
            ? prism_rtl::finished(std::optional(RxDiag{.part_p = Text::lit("pattern"), .at_p = Nat(0u), .message_p = rx_size_p()}))
            : ({
            prism_rtl::is_none(replacement_o2x) ? prism_rtl::finished(std::optional<RxDiag>{})
            : prism_rtl::is_some(replacement_o2x) ? ({
            auto&& r_p8 = prism_rtl::some_of(replacement_o2x);
            prism_rtl::more(prism_rtl::rc(RxReplacementRefusal(r_p8, prism_rtl::deref(st_p6).groups_p, prism_rtl::deref(st_p6).names_p)));
        })
            : throw prism_rtl::Panic("no arm matched");
        })
            : throw prism_rtl::Panic("no arm matched");
        });
        });
    }));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start RegexRefusal, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<RxDiag>> start_regex_refusal_o(Text pattern_p0, Text flags_p1, std::optional<Text> replacement_o2) {
    return prism_rtl::make_rc<RegexRefusal>(pattern_p0, flags_p1, replacement_o2);
}


/// ?RxFlagsRefusal: fn Text -> ?RxDiag
std::optional<RxDiag> rx_flags_refusal_o(const Text& flags_p0) {
    auto&& _d_o6 = ({
        std::tuple<std::optional<RxDiag>, Text> this_ = std::tuple{std::optional<RxDiag>{}, Text::lit("")};
        Cursor c_p1 = crate::prelude::front(flags_p0);
        std::optional<RxDiag> d_o2 = std::optional<RxDiag>{};
        Text seen_p3 = Text::lit("");
        while (true) {
            auto&& _m = crate::prelude::step(c_p1);
            if (!(prism_rtl::is_some(_m))) break;
            auto&& next_p4 = std::get<1>(prism_rtl::some_of(_m));
            if (!(d_o2 == std::optional<RxDiag>{})) {
                break;
            }
            auto ch_p5 = rx_slice_f(flags_p0, crate::prelude::at(c_p1), crate::prelude::at(next_p4));
            if (!(((ch_p5 == Text::lit("i")) || (ch_p5 == Text::lit("m"))) || (ch_p5 == Text::lit("s")))) {
                d_o2 = std::optional(RxDiag{.part_p = Text::lit("flags"), .at_p = crate::prelude::at(c_p1), .message_p = rx_unknown_flag_p()});
            } else if (rx_in_f(seen_p3, ch_p5)) {
                d_o2 = std::optional(RxDiag{.part_p = Text::lit("flags"), .at_p = crate::prelude::at(c_p1), .message_p = rx_flag_twice_p()});
            } else  {
                seen_p3 = prism_rtl::cat(seen_p3, ch_p5);
            }
            c_p1 = next_p4;
        }
        this_ = std::tuple{d_o2, seen_p3};
        (std::move(this_));
    });
    auto&& d_o6 = std::get<0>(_d_o6);
    return d_o6;
}


/// RxAlternation: unbounded fn RxState, Bool -> ((RxMeasure, RxState))
std::tuple<RxMeasure, RxState> rx_alternation_f(const RxState& st0_p0, const bool& fi0_p1) {
    auto [m0_p2, fi1_p3, st1_p4] = rx_sequence_f(st0_p0, fi0_p1);
    std::tuple<RxMeasure, RxState> this_ = std::tuple{m0_p2, st1_p4};
    RxMeasure m_p5 = m0_p2;
    bool fi_p6 = fi1_p3;
    RxState st_p7 = st1_p4;
    while ((!rx_bad_f(st_p7)) && (rx_peek_f(st_p7) == Text::lit("|"))) {
        auto [m2_p8, fi2_p9, st2_pa] = rx_sequence_f(rx_go_f(st_p7, st_p7.i_p + Nat(1u)), fi_p6);
        m_p5 = rx_then_f(m_p5, m2_p8);
        fi_p6 = fi2_p9;
        st_p7 = st2_pa;
    }
    this_ = std::tuple{m_p5, st_p7};
    return this_;
}


prism_rtl::Turn<std::tuple<RxMeasure, RxState>> RxAlternation::cycle() const {
    const auto& st0_p0 = this->st0_p0;
    const auto& fi0_p1 = this->fi0_p1;
    auto fi0_p1x = prism_rtl::deref(fi0_p1);
    auto st0_p0x = st0_p0;
    return crate::prelude::call_then(start_rx_sequence_f(st0_p0x, std::move(fi0_p1x)), [=](std::tuple<RxMeasure, bool, RxState> rx_sequence_f_17135) {
        return ({
            auto [m0_p2, fi1_p3, st1_p4] = rx_sequence_f_17135;
            std::tuple<RxMeasure, RxState> this_ = std::tuple{m0_p2, st1_p4};
            RxMeasure m_p5 = m0_p2;
            bool fi_p6 = fi1_p3;
            RxState st_p7 = st1_p4;
            (crate::prelude::call_then(crate::prelude::loop_job(std::tuple{std::move(this_), std::move(fi_p6), std::move(m_p5), std::move(st_p7)}, [=](std::tuple<std::tuple<RxMeasure, RxState>, bool, RxMeasure, RxState> _p0) {
            auto this_ = std::get<0>(_p0);
            auto fi_p6 = std::get<1>(_p0);
            auto m_p5 = std::get<2>(_p0);
            auto st_p7 = std::get<3>(_p0);
            return (!rx_bad_f(st_p7)) && (rx_peek_f(st_p7) == Text::lit("|"))
                ? ({
                auto [m2_p8, fi2_p9, st2_pa] = rx_sequence_f(rx_go_f(st_p7, prism_rtl::deref(st_p7).i_p + Nat(1u)), fi_p6);
                m_p5 = rx_then_f(m_p5, m2_p8);
                fi_p6 = fi2_p9;
                st_p7 = st2_pa;
                Expected<std::tuple<std::tuple<RxMeasure, RxState>, bool, RxMeasure, RxState>, std::tuple<std::tuple<RxMeasure, RxState>, bool, RxMeasure, RxState>>(std::tuple{this_, fi_p6, m_p5, st_p7});
            })
                : Expected<std::tuple<std::tuple<RxMeasure, RxState>, bool, RxMeasure, RxState>, std::tuple<std::tuple<RxMeasure, RxState>, bool, RxMeasure, RxState>>(unexpected(std::tuple{this_, fi_p6, m_p5, st_p7}));
        }), [=](std::tuple<std::tuple<RxMeasure, RxState>, bool, RxMeasure, RxState> _p0) {
            auto this_ = std::get<0>(_p0);
            auto fi_p6 = std::get<1>(_p0);
            auto m_p5 = std::get<2>(_p0);
            auto st_p7 = std::get<3>(_p0);
            return ({
                this_ = std::tuple{m_p5, st_p7};
                (prism_rtl::finished(this_));
            });
        }));
        });
    });
}


/// `Start RxAlternation, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<RxMeasure, RxState>> start_rx_alternation_f(RxState st0_p0, bool fi0_p1) {
    return prism_rtl::make_rc<RxAlternation>(st0_p0, fi0_p1);
}


/// RxSequence: unbounded fn RxState, Bool -> ((RxMeasure, Bool, RxState))
std::tuple<RxMeasure, bool, RxState> rx_sequence_f(const RxState& st0_p0, const bool& fi0_p1) {
    std::tuple<RxMeasure, bool, RxState> this_ = std::tuple{rx_none_p(), fi0_p1, st0_p0};
    RxMeasure total_p2 = rx_none_p();
    bool fi_p3 = fi0_p1;
    RxState st_p4 = st0_p0;
    RxLast last_p5 = RxLast(RxLast::RxLastNothing{});
    RxMeasure last_m_p6 = rx_none_p();
    bool going_p7 = true;
    while (std::move(going_p7) && (!rx_bad_f(st_p4))) {
        auto c_p8 = rx_peek_f(st_p4);
        auto at_p9 = st_p4.i_p;
        if (((c_p8 == Text::lit("")) || (c_p8 == Text::lit("|"))) || (c_p8 == Text::lit(")"))) {
            going_p7 = false;
        } else if ((((c_p8 == Text::lit("*")) || (c_p8 == Text::lit("+"))) || (c_p8 == Text::lit("?"))) || (c_p8 == Text::lit("{"))) {
            auto [lo_pa, hi_ob, st2_pc] = c_p8 == Text::lit("{")
                ? rx_count_f(st_p4)
                : rx_simple_repetition_f(st_p4, c_p8);
            st_p4 = st2_pc;
            if (!rx_bad_f(st_p4)) {
                st_p4 = ({
                    __label__ _done;
                    prism_rtl::Slot<RxState> _v;
                    if (prism_rtl::is<RxLast::RxLastNothing>(last_p5)) {
                        _v.set(rx_fail_f(st_p4, at_p9, rx_nothing_to_repeat_p()));
                        goto _done;
                    }
                    if (prism_rtl::is<RxLast::RxLastFlagGroup>(last_p5)) {
                        _v.set(rx_fail_f(st_p4, at_p9, rx_nothing_to_repeat_p()));
                        goto _done;
                    }
                    if (prism_rtl::is<RxLast::RxLastRepetition>(last_p5)) {
                        _v.set(rx_fail_f(st_p4, at_p9, rx_repeat_repeat_p()));
                        goto _done;
                    }
                    if (prism_rtl::is<RxLast::RxLastAssertion>(last_p5)) {
                        _v.set(rx_fail_f(st_p4, at_p9, rx_repeat_assertion_p()));
                        goto _done;
                    }
                    if (prism_rtl::is<RxLast::RxLastAtom>(last_p5)) {
                        _v.set(st_p4);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
            }
            if (!rx_bad_f(st_p4)) {
                auto counted_pd = c_p8 == Text::lit("{");
                auto factor_pe = std::move(counted_pd)
                    ? crate::prelude::max(crate::prelude::or_(hi_ob, lo_pa), Nat(1u))
                    : Nat(1u);
                auto product_pf = factor_pe * crate::prelude::max(last_m_p6.product_p, Nat(1u));
                if (std::move(counted_pd) && (product_pf > Nat(1000u))) {
                    st_p4 = rx_fail_f(st_p4, at_p9, rx_product_p());
                } else  {
                    if (rx_peek_f(st_p4) == Text::lit("?")) {
                        st_p4 = rx_go_f(st_p4, st_p4.i_p + Nat(1u));
                    }
                    auto m_pg = RxMeasure{.depth_p = last_m_p6.depth_p + Nat(1u), .size_p = last_m_p6.size_p * factor_pe, .product_p = product_pf};
                    total_p2 = RxMeasure{.depth_p = crate::prelude::max(total_p2.depth_p, prism_rtl::deref(m_pg).depth_p), .size_p = crate::prelude::or_(total_p2.size_p.checked_sub(last_m_p6.size_p), Nat(0u)) + prism_rtl::deref(m_pg).size_p, .product_p = crate::prelude::max(total_p2.product_p, prism_rtl::deref(m_pg).product_p)};
                    last_p5 = RxLast(RxLast::RxLastRepetition{});
                    last_m_p6 = m_pg;
                }
            }
        } else  {
            auto [kind_ph, m_pi, fi2_pj, st2_pk] = rx_piece_f(st_p4, fi_p3);
            st_p4 = st2_pk;
            fi_p3 = fi2_pj;
            if (kind_ph != RxLast(RxLast::RxLastFlagGroup{})) {
                total_p2 = rx_then_f(total_p2, m_pi);
            }
            last_p5 = kind_ph;
            last_m_p6 = m_pi;
        }
    }
    this_ = std::tuple{total_p2, std::move(fi_p3), st_p4};
    return this_;
}


prism_rtl::Turn<std::tuple<RxMeasure, bool, RxState>> RxSequence::cycle() const {
    const auto& st0_p0 = this->st0_p0;
    const auto& fi0_p1 = this->fi0_p1;
    std::tuple<RxMeasure, bool, RxState> this_ = std::tuple{rx_none_p(), prism_rtl::deref(fi0_p1), st0_p0};
    RxMeasure total_p2 = rx_none_p();
    bool fi_p3 = prism_rtl::deref(fi0_p1);
    RxState st_p4 = st0_p0;
    RxLast last_p5 = RxLast(RxLast::RxLastNothing{});
    RxMeasure last_m_p6 = rx_none_p();
    bool going_p7 = true;
    return crate::prelude::call_then(crate::prelude::loop_job(std::tuple{std::move(this_), std::move(fi_p3), std::move(going_p7), std::move(last_p5), std::move(last_m_p6), std::move(st_p4), std::move(total_p2)}, [=](std::tuple<std::tuple<RxMeasure, bool, RxState>, bool, bool, RxLast, RxMeasure, RxState, RxMeasure> _p0) {
        auto this_ = std::get<0>(_p0);
        auto fi_p3 = std::get<1>(_p0);
        auto going_p7 = std::get<2>(_p0);
        auto last_p5 = std::get<3>(_p0);
        auto last_m_p6 = std::get<4>(_p0);
        auto st_p4 = std::get<5>(_p0);
        auto total_p2 = std::get<6>(_p0);
        return going_p7 && (!rx_bad_f(st_p4))
            ? ({
            auto c_p8 = rx_peek_f(st_p4);
            auto at_p9 = prism_rtl::deref(st_p4).i_p;
            if (((c_p8 == Text::lit("")) || (c_p8 == Text::lit("|"))) || (c_p8 == Text::lit(")"))) {
                going_p7 = false;
            } else if ((((c_p8 == Text::lit("*")) || (c_p8 == Text::lit("+"))) || (c_p8 == Text::lit("?"))) || (c_p8 == Text::lit("{"))) {
                auto [lo_pa, hi_ob, st2_pc] = c_p8 == Text::lit("{")
                    ? rx_count_f(st_p4)
                    : rx_simple_repetition_f(st_p4, c_p8);
                st_p4 = st2_pc;
                if (!rx_bad_f(st_p4)) {
                    st_p4 = ({
                        __label__ _done;
                        prism_rtl::Slot<RxState> _v;
                        if (prism_rtl::is<RxLast::RxLastNothing>(last_p5)) {
                            _v.set(rx_fail_f(st_p4, at_p9, rx_nothing_to_repeat_p()));
                            goto _done;
                        }
                        if (prism_rtl::is<RxLast::RxLastFlagGroup>(last_p5)) {
                            _v.set(rx_fail_f(st_p4, at_p9, rx_nothing_to_repeat_p()));
                            goto _done;
                        }
                        if (prism_rtl::is<RxLast::RxLastRepetition>(last_p5)) {
                            _v.set(rx_fail_f(st_p4, at_p9, rx_repeat_repeat_p()));
                            goto _done;
                        }
                        if (prism_rtl::is<RxLast::RxLastAssertion>(last_p5)) {
                            _v.set(rx_fail_f(st_p4, at_p9, rx_repeat_assertion_p()));
                            goto _done;
                        }
                        if (prism_rtl::is<RxLast::RxLastAtom>(last_p5)) {
                            _v.set(st_p4);
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                }
                if (!rx_bad_f(st_p4)) {
                    auto counted_pd = c_p8 == Text::lit("{");
                    auto factor_pe = std::move(counted_pd)
                        ? crate::prelude::max(crate::prelude::or_(hi_ob, lo_pa), Nat(1u))
                        : Nat(1u);
                    auto product_pf = factor_pe * crate::prelude::max(prism_rtl::deref(last_m_p6).product_p, Nat(1u));
                    if (std::move(counted_pd) && (product_pf > Nat(1000u))) {
                        st_p4 = rx_fail_f(st_p4, at_p9, rx_product_p());
                    } else  {
                        if (rx_peek_f(st_p4) == Text::lit("?")) {
                            st_p4 = rx_go_f(st_p4, prism_rtl::deref(st_p4).i_p + Nat(1u));
                        }
                        auto m_pg = RxMeasure{.depth_p = prism_rtl::deref(last_m_p6).depth_p + Nat(1u), .size_p = prism_rtl::deref(last_m_p6).size_p * factor_pe, .product_p = product_pf};
                        total_p2 = RxMeasure{.depth_p = crate::prelude::max(prism_rtl::deref(total_p2).depth_p, prism_rtl::deref(m_pg).depth_p), .size_p = crate::prelude::or_(prism_rtl::deref(total_p2).size_p.checked_sub(prism_rtl::deref(last_m_p6).size_p), Nat(0u)) + prism_rtl::deref(m_pg).size_p, .product_p = crate::prelude::max(prism_rtl::deref(total_p2).product_p, prism_rtl::deref(m_pg).product_p)};
                        last_p5 = RxLast(RxLast::RxLastRepetition{});
                        last_m_p6 = m_pg;
                    }
                }
            } else  {
                auto [kind_ph, m_pi, fi2_pj, st2_pk] = rx_piece_f(st_p4, fi_p3);
                st_p4 = st2_pk;
                fi_p3 = fi2_pj;
                if (kind_ph != RxLast(RxLast::RxLastFlagGroup{})) {
                    total_p2 = rx_then_f(total_p2, m_pi);
                }
                last_p5 = kind_ph;
                last_m_p6 = m_pi;
            }
            Expected<std::tuple<std::tuple<RxMeasure, bool, RxState>, bool, bool, RxLast, RxMeasure, RxState, RxMeasure>, std::tuple<std::tuple<RxMeasure, bool, RxState>, bool, bool, RxLast, RxMeasure, RxState, RxMeasure>>(std::tuple{this_, fi_p3, going_p7, last_p5, last_m_p6, st_p4, total_p2});
        })
            : Expected<std::tuple<std::tuple<RxMeasure, bool, RxState>, bool, bool, RxLast, RxMeasure, RxState, RxMeasure>, std::tuple<std::tuple<RxMeasure, bool, RxState>, bool, bool, RxLast, RxMeasure, RxState, RxMeasure>>(unexpected(std::tuple{this_, fi_p3, going_p7, last_p5, last_m_p6, st_p4, total_p2}));
    }), [=](std::tuple<std::tuple<RxMeasure, bool, RxState>, bool, bool, RxLast, RxMeasure, RxState, RxMeasure> _p0) {
        auto this_ = std::get<0>(_p0);
        auto fi_p3 = std::get<1>(_p0);
        auto going_p7 = std::get<2>(_p0);
        auto last_p5 = std::get<3>(_p0);
        auto last_m_p6 = std::get<4>(_p0);
        auto st_p4 = std::get<5>(_p0);
        auto total_p2 = std::get<6>(_p0);
        return ({
            this_ = std::tuple{total_p2, fi_p3, st_p4};
            (prism_rtl::finished(this_));
        });
    });
}


/// `Start RxSequence, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<RxMeasure, bool, RxState>> start_rx_sequence_f(RxState st0_p0, bool fi0_p1) {
    return prism_rtl::make_rc<RxSequence>(st0_p0, fi0_p1);
}


/// RxSimpleRepetition: fn RxState, Text -> ((Nat, ?Nat, RxState))
std::tuple<Nat, std::optional<Nat>, RxState> rx_simple_repetition_f(const RxState& st_p0, const Text& c_p1) {
    auto st2_p2 = rx_go_f(st_p0, st_p0.i_p + Nat(1u));
    return c_p1 == Text::lit("*")
        ? std::tuple{Nat(0u), std::optional<Nat>{}, st2_p2}
        : c_p1 == Text::lit("+")
        ? std::tuple{Nat(1u), std::optional<Nat>{}, st2_p2}
        : std::tuple{Nat(0u), std::optional(Nat(1u)), st2_p2};
}


/// RxCount: unbounded fn RxState -> ((Nat, ?Nat, RxState))
std::tuple<Nat, std::optional<Nat>, RxState> rx_count_f(const RxState& st_p0) {
    auto at_p1 = st_p0.i_p;
    auto s_p2 = st_p0.s_p;
    auto j1_p3 = rx_span_end_f(s_p2, at_p1 + Nat(1u), ({
        auto f = prism_rtl::rc(rx_is_digit_f);
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>>(prism_rtl::rc([=, f = std::move(f)](Text a0) {
        return ({
            auto fy = f;
            (crate::prelude::once_job([=, fy = std::move(fy)]() { return prism_rtl::finished(fy(a0)); }));
        });
    })));
    }));
    auto first_p4 = rx_slice_f(s_p2, at_p1 + Nat(1u), j1_p3);
    auto c_p5 = rx_char_at_f(s_p2, j1_p3);
    return first_p4 == Text::lit("")
        ? std::tuple{Nat(0u), std::optional<Nat>{}, rx_fail_f(st_p0, at_p1, rx_brace_p())}
        : c_p5 == Text::lit("}")
        ? rx_count_checked_f(st_p0, at_p1, first_p4, std::optional<Text>{}, j1_p3 + Nat(1u))
        : c_p5 == Text::lit(",")
        ? ({
        auto j2_p6 = rx_span_end_f(s_p2, j1_p3 + Nat(1u), ({
            auto f = prism_rtl::rc(rx_is_digit_f);
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>>(prism_rtl::rc([=, f = std::move(f)](Text a0) {
            return ({
                auto fy = f;
                (crate::prelude::once_job([=, fy = std::move(fy)]() { return prism_rtl::finished(fy(a0)); }));
            });
        })));
        }));
        rx_char_at_f(s_p2, j2_p6) != Text::lit("}")
        ? std::tuple{Nat(0u), std::optional<Nat>{}, rx_fail_f(st_p0, at_p1, rx_brace_p())}
        : rx_count_checked_f(st_p0, at_p1, first_p4, std::optional(rx_slice_f(s_p2, j1_p3 + Nat(1u), j2_p6)), j2_p6 + Nat(1u));
    })
        : std::tuple{Nat(0u), std::optional<Nat>{}, rx_fail_f(st_p0, at_p1, rx_brace_p())};
}


/// RxCountChecked: fn RxState, Nat, Text, ?Text, Nat -> ((Nat, ?Nat, RxState))
std::tuple<Nat, std::optional<Nat>, RxState> rx_count_checked_f(const RxState& st_p0, const Nat& at_p1, const Text& first_p2, const std::optional<Text>& second_o3, const Nat& next_p4) {
    auto st1_p5 = rx_go_f(st_p0, next_p4);
    auto lo_p6 = crate::prelude::or_(crate::prelude::parse_nat_opt(first_p2), Nat(0u));
    auto hi_o7 = ({
        __label__ _done;
        prism_rtl::Slot<std::optional<Nat>> _v;
        if (prism_rtl::is_none(second_o3)) {
            _v.set(std::optional(lo_p6));
            goto _done;
        }
        if (prism_rtl::is_some(second_o3)) {
            auto&& m20974_1 = prism_rtl::some_of(second_o3);
            if (m20974_1 == Text::lit("")) {
                _v.set(std::optional<Nat>{});
                goto _done;
            }
        }
        if (prism_rtl::is_some(second_o3)) {
            auto&& d_p9 = prism_rtl::some_of(second_o3);
            _v.set(crate::prelude::parse_nat_opt(d_p9));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto zero_p8 = rx_leading_zero_f(first_p2) || rx_leading_zero_f(crate::prelude::or_(second_o3, Text::lit("")));
    return std::move(zero_p8)
        ? std::tuple{Nat(0u), std::optional<Nat>{}, rx_fail_f(st1_p5, at_p1, rx_count_zero_p())}
        : (lo_p6 > Nat(1000u)) || (crate::prelude::or_(hi_o7, Nat(0u)) > Nat(1000u))
        ? std::tuple{Nat(0u), std::optional<Nat>{}, rx_fail_f(st1_p5, at_p1, rx_count_bound_p())}
        : lo_p6 > crate::prelude::or_(hi_o7, lo_p6)
        ? std::tuple{Nat(0u), std::optional<Nat>{}, rx_fail_f(st1_p5, at_p1, rx_count_order_p())}
        : std::tuple{lo_p6, hi_o7, st1_p5};
}


/// RxLeadingZero: fn Text -> Bool
bool rx_leading_zero_f(const Text& d_p0) {
    return (crate::prelude::len_text(d_p0) > Nat(1u)) && (rx_char_at_f(d_p0, Nat(0u)) == Text::lit("0"));
}


/// RxPiece: unbounded fn RxState, Bool -> ((RxLast, RxMeasure, Bool, RxState))
std::tuple<RxLast, RxMeasure, bool, RxState> rx_piece_f(const RxState& st_p0, const bool& fi_p1) {
    auto at_p2 = st_p0.i_p;
    auto c_p3 = rx_peek_f(st_p0);
    {
        auto&& m21753_0 = c_p3;
        if (m21753_0 == Text::lit("(")) {
            return rx_group_f(st_p0, fi_p1);
        }
    }
    {
        auto&& m21753_1 = c_p3;
        if (m21753_1 == Text::lit("[")) {
            return std::tuple{RxLast(RxLast::RxLastAtom{}), rx_atom_p(), fi_p1, rx_class_f(st_p0, fi_p1)};
        }
    }
    {
        auto&& m21753_2 = c_p3;
        if (m21753_2 == Text::lit("]")) {
            return std::tuple{RxLast(RxLast::RxLastAtom{}), rx_atom_p(), fi_p1, rx_fail_f(st_p0, at_p2, rx_stray_bracket_p())};
        }
    }
    {
        auto&& m21753_3 = c_p3;
        if (m21753_3 == Text::lit("}")) {
            return std::tuple{RxLast(RxLast::RxLastAtom{}), rx_atom_p(), fi_p1, rx_fail_f(st_p0, at_p2, rx_stray_brace_p())};
        }
    }
    {
        auto&& m21753_4 = c_p3;
        if (m21753_4 == Text::lit("^")) {
            return std::tuple{RxLast(RxLast::RxLastAssertion{}), rx_atom_p(), fi_p1, rx_go_f(st_p0, at_p2 + Nat(1u))};
        }
    }
    {
        auto&& m21753_5 = c_p3;
        if (m21753_5 == Text::lit("$")) {
            return std::tuple{RxLast(RxLast::RxLastAssertion{}), rx_atom_p(), fi_p1, rx_go_f(st_p0, at_p2 + Nat(1u))};
        }
    }
    {
        auto&& m21753_6 = c_p3;
        if (m21753_6 == Text::lit("\\")) {
            return rx_escape_f(st_p0, fi_p1);
        }
    }
    {
        return std::tuple{RxLast(RxLast::RxLastAtom{}), rx_atom_p(), fi_p1, rx_go_f(st_p0, at_p2 + crate::prelude::len_text(c_p3))};
    }
}


/// RxEscape: unbounded fn RxState, Bool -> ((RxLast, RxMeasure, Bool, RxState))
std::tuple<RxLast, RxMeasure, bool, RxState> rx_escape_f(const RxState& st_p0, const bool& fi_p1) {
    auto at_p2 = st_p0.i_p;
    auto s_p3 = st_p0.s_p;
    auto c_p4 = rx_char_at_f(s_p3, at_p2 + Nat(1u));
    auto atom_f5 = ({
        auto fi_p1x = fi_p1;
        static_cast<Fn<std::tuple<RxLast, RxMeasure, bool, RxState>(const RxState&)>>(prism_rtl::rc([=, fi_p1x = std::move(fi_p1x)](const RxState& next_p6) { return std::tuple{RxLast(RxLast::RxLastAtom{}), rx_atom_p(), fi_p1x, next_p6}; }));
    });
    return c_p4 == Text::lit("")
        ? atom_f5(rx_fail_f(st_p0, at_p2, rx_trailing_backslash_p()))
        : (c_p4 == Text::lit("<")) || (c_p4 == Text::lit(">"))
        ? atom_f5(rx_fail_f(st_p0, at_p2, rx_angle_p()))
        : rx_in_f(rx_punctuation_p(), c_p4)
        ? atom_f5(rx_go_f(st_p0, at_p2 + Nat(2u)))
        : rx_in_f(Text::lit("tnrfva"), c_p4)
        ? atom_f5(rx_go_f(st_p0, at_p2 + Nat(2u)))
        : c_p4 == Text::lit("x")
        ? ({
        auto&& _st2_p7 = rx_hex_f(st_p0, at_p2);
        auto&& st2_p7 = std::get<1>(_st2_p7);
        atom_f5(st2_p7);
    })
        : rx_in_f(Text::lit("dwsDWS"), c_p4)
        ? atom_f5(rx_go_f(st_p0, at_p2 + Nat(2u)))
        : (c_p4 == Text::lit("p")) || (c_p4 == Text::lit("P"))
        ? ({
        auto&& _st2_p8 = rx_property_f(st_p0, at_p2);
        auto&& st2_p8 = std::get<1>(_st2_p8);
        atom_f5(st2_p8);
    })
        : rx_in_f(Text::lit("AzbB"), c_p4)
        ? (c_p4 == Text::lit("b")) && (rx_char_at_f(s_p3, at_p2 + Nat(2u)) == Text::lit("{"))
        ? atom_f5(rx_fail_f(st_p0, at_p2, rx_word_braces_p()))
        : std::tuple{RxLast(RxLast::RxLastAssertion{}), rx_atom_p(), fi_p1, rx_go_f(st_p0, at_p2 + Nat(2u))}
        : rx_in_f(Text::lit("123456789"), c_p4)
        ? atom_f5(rx_fail_f(st_p0, at_p2, rx_backreference_p()))
        : c_p4 == Text::lit("0")
        ? atom_f5(rx_fail_f(st_p0, at_p2, rx_octal_p()))
        : (c_p4 == Text::lit("Q")) || (c_p4 == Text::lit("E"))
        ? atom_f5(rx_fail_f(st_p0, at_p2, rx_quote_p()))
        : c_p4 == Text::lit("C")
        ? atom_f5(rx_fail_f(st_p0, at_p2, rx_one_byte_p()))
        : atom_f5(rx_fail_f(st_p0, at_p2, rx_unknown_escape_p()));
}


/// RxHex: unbounded fn RxState, Nat -> ((Nat, RxState))
std::tuple<Nat, RxState> rx_hex_f(const RxState& st_p0, const Nat& at_p1) {
    auto s_p2 = st_p0.s_p;
    auto x_p3 = at_p1 + Nat(1u);
    return rx_char_at_f(s_p2, x_p3 + Nat(1u)) == Text::lit("{")
        ? ({
        auto start_p4 = x_p3 + Nat(2u);
        auto j_p5 = rx_span_end_f(s_p2, start_p4, ({
            auto f = prism_rtl::rc(rx_is_hex_f);
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>>(prism_rtl::rc([=, f = std::move(f)](Text a0) {
            return ({
                auto fy = f;
                (crate::prelude::once_job([=, fy = std::move(fy)]() { return prism_rtl::finished(fy(a0)); }));
            });
        })));
        }));
        auto digits_p6 = rx_slice_f(s_p2, start_p4, j_p5);
        ((rx_char_at_f(s_p2, j_p5) != Text::lit("}")) || (digits_p6 == Text::lit(""))) || (crate::prelude::len_text(digits_p6) > Nat(6u))
        ? std::tuple{Nat(0u), rx_fail_f(st_p0, at_p1, rx_hex_braces_p())}
        : rx_hex_checked_f(rx_go_f(st_p0, j_p5 + Nat(1u)), at_p1, rx_hex_value_f(digits_p6));
    })
        : ({
        auto a_p7 = rx_char_at_f(s_p2, x_p3 + Nat(1u));
        auto b_p8 = rx_char_at_f(s_p2, x_p3 + Nat(2u));
        rx_is_hex_f(a_p7) && rx_is_hex_f(b_p8)
        ? rx_hex_checked_f(rx_go_f(st_p0, x_p3 + Nat(3u)), at_p1, rx_hex_value_f(prism_rtl::cat(a_p7, b_p8)))
        : std::tuple{Nat(0u), rx_fail_f(st_p0, at_p1, rx_hex_two_p())};
    });
}


/// RxHexChecked: fn RxState, Nat, Nat -> ((Nat, RxState))
std::tuple<Nat, RxState> rx_hex_checked_f(const RxState& st_p0, const Nat& at_p1, const Nat& v_p2) {
    return ((Nat(55296u) <= v_p2) && (v_p2 <= Nat(57343u))) || (v_p2 > Nat(1114111u))
        ? std::tuple{v_p2, rx_fail_f(st_p0, at_p1, rx_hex_no_char_p())}
        : std::tuple{v_p2, st_p0};
}


/// RxProperty: unbounded fn RxState, Nat -> ((Text, RxState))
std::tuple<Text, RxState> rx_property_f(const RxState& st_p0, const Nat& at_p1) {
    auto s_p2 = st_p0.s_p;
    auto c_p3 = rx_char_at_f(s_p2, at_p1 + Nat(2u));
    return c_p3 == Text::lit("{")
        ? ({
        auto start_p4 = at_p1 + Nat(3u);
        ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Text, RxState>> _v;
        auto&& _m = rx_find_o(s_p2, start_p4, Text::lit("}"));
        if (prism_rtl::is_none(_m)) {
            _v.set(std::tuple{Text::lit(""), rx_fail_f(st_p0, at_p1, rx_property_open_p())});
            goto _done;
        }
        if (prism_rtl::is_some(_m)) {
            auto&& close_p5 = prism_rtl::some_of(_m);
            _v.set(({
                auto name_p6 = rx_slice_f(s_p2, start_p4, close_p5);
                rx_char_at_f(name_p6, Nat(0u)) == Text::lit("^")
                ? std::tuple{name_p6, rx_fail_f(st_p0, at_p1, rx_property_negated_p())}
                : rx_property_named_f(rx_go_f(st_p0, close_p5 + Nat(1u)), at_p1, name_p6);
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    })
        : rx_is_letter_f(c_p3)
        ? rx_property_named_f(rx_go_f(st_p0, at_p1 + Nat(3u)), at_p1, c_p3)
        : std::tuple{Text::lit(""), rx_fail_f(st_p0, at_p1, rx_property_name_p())};
}


/// RxPropertyNamed: fn RxState, Nat, Text -> ((Text, RxState))
std::tuple<Text, RxState> rx_property_named_f(const RxState& st_p0, const Nat& at_p1, const Text& name_p2) {
    return (((name_p2 == Text::lit("C")) || (name_p2 == Text::lit("Cn"))) || (name_p2 == Text::lit("Cs"))) || (name_p2 == Text::lit("LC"))
        ? std::tuple{name_p2, rx_fail_f(st_p0, at_p1, rx_property_refused_p())}
        : crate::prelude::get(rx_properties_p(), name_p2) != std::optional<bool>{}
        ? std::tuple{name_p2, st_p0}
        : std::tuple{name_p2, rx_fail_f(st_p0, at_p1, rx_property_unknown_p())};
}


/// RxClass: unbounded fn RxState, Bool -> RxState
RxState rx_class_f(const RxState& st0_p0, const bool& fi_p1) {
    auto open_p2 = st0_p0.i_p;
    auto start_p3 = rx_char_at_f(st0_p0.s_p, open_p2 + Nat(1u)) == Text::lit("^")
        ? open_p2 + Nat(2u)
        : open_p2 + Nat(1u);
    RxState this_ = rx_go_f(st0_p0, start_p3);
    bool first_p4 = true;
    bool done_p5 = false;
    while (!std::move(done_p5)) {
        auto [closed_p6, st2_p7] = rx_class_item_f(this_, open_p2, start_p3, first_p4, fi_p1);
        this_ = st2_p7;
        first_p4 = false;
        done_p5 = closed_p6 || rx_bad_f(st2_p7);
    }
    return this_;
}


/// RxAtSetOperation: fn RxState -> Bool
bool rx_at_set_operation_f(const RxState& st_p0) {
    auto c_p1 = rx_peek_f(st_p0);
    return (((c_p1 == Text::lit("&")) || (c_p1 == Text::lit("~"))) || (c_p1 == Text::lit("-"))) && (rx_char_at_f(st_p0.s_p, st_p0.i_p + Nat(1u)) == c_p1);
}


/// RxClassItem: unbounded fn RxState, Nat, Nat, Bool, Bool -> ((Bool, RxState))
std::tuple<bool, RxState> rx_class_item_f(const RxState& st_p0, const Nat& open_p1, const Nat& start_p2, const bool& first_p3, const bool& fi_p4) {
    auto at_p5 = st_p0.i_p;
    auto c_p6 = rx_peek_f(st_p0);
    auto next_p7 = rx_char_at_f(st_p0.s_p, at_p5 + Nat(1u));
    return c_p6 == Text::lit("")
        ? std::tuple{true, rx_fail_f(st_p0, open_p1, rx_class_open_p())}
        : (c_p6 == Text::lit("]")) && first_p3
        ? std::tuple{true, rx_fail_f(st_p0, at_p5, rx_class_first_bracket_p())}
        : c_p6 == Text::lit("]")
        ? std::tuple{true, rx_go_f(st_p0, at_p5 + Nat(1u))}
        : rx_at_set_operation_f(st_p0)
        ? std::tuple{true, rx_fail_f(st_p0, at_p5, rx_class_set_operation_p())}
        : c_p6 == Text::lit("[")
        ? std::tuple{false, rx_ascii_item_f(st_p0, fi_p4)}
        : (c_p6 == Text::lit("-")) && (next_p7 == Text::lit(""))
        ? std::tuple{true, rx_fail_f(st_p0, open_p1, rx_class_open_p())}
        : (c_p6 == Text::lit("-")) && ((at_p5 == start_p2) || (next_p7 == Text::lit("]")))
        ? std::tuple{false, rx_go_f(st_p0, at_p5 + Nat(1u))}
        : c_p6 == Text::lit("-")
        ? std::tuple{true, rx_fail_f(st_p0, at_p5, rx_class_dash_p())}
        : std::tuple{false, rx_class_range_f(st_p0, open_p1, fi_p4)};
}


/// RxClassRange: unbounded fn RxState, Nat, Bool -> RxState
RxState rx_class_range_f(const RxState& st_p0, const Nat& open_p1, const bool& fi_p2) {
    auto at_p3 = st_p0.i_p;
    auto [lo_o4, st1_p5] = rx_class_atom_f(st_p0, fi_p2);
    if (prism_rtl::is_none(lo_o4)) {
        return st1_p5;
    }
    if (prism_rtl::is_some(lo_o4)) {
        auto&& lo_p6 = prism_rtl::some_of(lo_o4);
        auto s_p7 = prism_rtl::deref(st1_p5).s_p;
        auto ranged_p8 = (rx_peek_f(st1_p5) == Text::lit("-")) && (rx_char_at_f(s_p7, prism_rtl::deref(st1_p5).i_p + Nat(1u)) != Text::lit("]"));
        return rx_bad_f(st1_p5) || (!std::move(ranged_p8))
            ? st1_p5
            : rx_at_set_operation_f(st1_p5)
            ? rx_fail_f(st1_p5, prism_rtl::deref(st1_p5).i_p, rx_class_set_operation_p())
            : ({
            auto right_p9 = prism_rtl::deref(st1_p5).i_p + Nat(1u);
            auto st2_pa = rx_go_f(st1_p5, right_p9);
            auto rc_pb = rx_peek_f(st2_pa);
            rc_pb == Text::lit("")
            ? rx_fail_f(st2_pa, open_p1, rx_class_open_p())
            : rc_pb == Text::lit("[")
            ? rx_fail_f(st2_pa, right_p9, rx_class_nested_p())
            : rx_at_set_operation_f(st2_pa)
            ? rx_fail_f(st2_pa, right_p9, rx_class_set_operation_p())
            : ({
            auto [hi_oc, st3_pd] = rx_class_atom_f(st2_pa, fi_p2);
            rx_bad_f(st3_pd)
            ? st3_pd
            : ({
            __label__ _done;
            prism_rtl::Slot<RxState> _v;
            if (prism_rtl::is_none(hi_oc)) {
                _v.set(rx_fail_f(st3_pd, right_p9, rx_class_range_set_p()));
                goto _done;
            }
            if (prism_rtl::is_some(hi_oc)) {
                auto&& hi_pe = prism_rtl::some_of(hi_oc);
                _v.set(rx_past_f(lo_p6, hi_pe)
                    ? rx_fail_f(st3_pd, at_p3, rx_class_order_p())
                    : st3_pd);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        });
        });
    }
    prism_rtl::unreachable("no arm matched");
}


/// RxClassAtom: unbounded fn RxState, Bool -> ((?RxCp, RxState))
std::tuple<std::optional<RxCp>, RxState> rx_class_atom_f(const RxState& st_p0, const bool& fi_p1) {
    auto at_p2 = st_p0.i_p;
    auto s_p3 = st_p0.s_p;
    auto c_p4 = rx_peek_f(st_p0);
    return c_p4 != Text::lit("\\")
        ? std::tuple{std::optional(RxCp(RxCp::RxLit{c_p4})), rx_go_f(st_p0, at_p2 + crate::prelude::len_text(c_p4))}
        : ({
        auto e_p5 = rx_char_at_f(s_p3, at_p2 + Nat(1u));
        e_p5 == Text::lit("")
        ? std::tuple{std::optional<RxCp>{}, rx_fail_f(st_p0, at_p2, rx_trailing_backslash_p())}
        : (e_p5 == Text::lit("<")) || (e_p5 == Text::lit(">"))
        ? std::tuple{std::optional<RxCp>{}, rx_fail_f(st_p0, at_p2, rx_class_escape_p())}
        : rx_in_f(rx_punctuation_p(), e_p5)
        ? std::tuple{std::optional(RxCp(RxCp::RxLit{e_p5})), rx_go_f(st_p0, at_p2 + Nat(2u))}
        : rx_in_f(Text::lit("tnrfva"), e_p5)
        ? std::tuple{std::optional(RxCp(RxCp::RxLit{rx_control_f(e_p5)})), rx_go_f(st_p0, at_p2 + Nat(2u))}
        : e_p5 == Text::lit("x")
        ? ({
        auto [v_p6, st2_p7] = rx_hex_f(st_p0, at_p2);
        std::tuple{std::optional(rx_cp_of_f(v_p6)), st2_p7};
    })
        : rx_in_f(Text::lit("dws"), e_p5)
        ? std::tuple{std::optional<RxCp>{}, rx_go_f(st_p0, at_p2 + Nat(2u))}
        : rx_in_f(Text::lit("DWS"), e_p5)
        ? fi_p1
        ? std::tuple{std::optional<RxCp>{}, rx_fail_f(st_p0, at_p2, rx_class_negated_under_i_p())}
        : std::tuple{std::optional<RxCp>{}, rx_go_f(st_p0, at_p2 + Nat(2u))}
        : (e_p5 == Text::lit("p")) || (e_p5 == Text::lit("P"))
        ? ({
        auto&& _st2_p8 = rx_property_f(st_p0, at_p2);
        auto&& st2_p8 = std::get<1>(_st2_p8);
        ((e_p5 == Text::lit("P")) && fi_p1) && (!rx_bad_f(st2_p8))
        ? std::tuple{std::optional<RxCp>{}, rx_fail_f(st2_p8, at_p2, rx_class_negated_under_i_p())}
        : std::tuple{std::optional<RxCp>{}, st2_p8};
    })
        : std::tuple{std::optional<RxCp>{}, rx_fail_f(st_p0, at_p2, rx_class_escape_p())};
    });
}


/// RxControl: fn Text -> Text
Text rx_control_f(const Text& text0) {
    {
        auto&& c0_0 = text0;
        if (c0_0 == Text::lit("t")) {
            return Text::lit("\t");
        }
    }
    {
        auto&& c1_0 = text0;
        if (c1_0 == Text::lit("n")) {
            return Text::lit("\n");
        }
    }
    {
        auto&& c2_0 = text0;
        if (c2_0 == Text::lit("r")) {
            return Text::lit("\r");
        }
    }
    {
        auto&& c3_0 = text0;
        if (c3_0 == Text::lit("f")) {
            return Text::lit("");
        }
    }
    {
        auto&& c4_0 = text0;
        if (c4_0 == Text::lit("v")) {
            return Text::lit("");
        }
    }
    {
        return Text::lit("");
    }
}


/// RxAsciiItem: unbounded fn RxState, Bool -> RxState
RxState rx_ascii_item_f(const RxState& st_p0, const bool& fi_p1) {
    auto at_p2 = st_p0.i_p;
    auto s_p3 = st_p0.s_p;
    auto negated_p4 = rx_char_at_f(s_p3, at_p2 + Nat(2u)) == Text::lit("^");
    auto start_p5 = std::move(negated_p4) ? at_p2 + Nat(3u) : at_p2 + Nat(2u);
    auto j_p6 = rx_span_end_f(s_p3, start_p5, ({
        auto f = prism_rtl::rc(rx_is_letter_f);
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>>(prism_rtl::rc([=, f = std::move(f)](Text a0) {
        return ({
            auto fy = f;
            (crate::prelude::once_job([=, fy = std::move(fy)]() { return prism_rtl::finished(fy(a0)); }));
        });
    })));
    }));
    auto shaped_p7 = (((rx_char_at_f(s_p3, at_p2 + Nat(1u)) == Text::lit(":")) && (j_p6 > start_p5)) && (rx_char_at_f(s_p3, j_p6) == Text::lit(":"))) && (rx_char_at_f(s_p3, j_p6 + Nat(1u)) == Text::lit("]"));
    return !std::move(shaped_p7)
        ? rx_fail_f(st_p0, at_p2, rx_class_nested_p())
        : crate::prelude::get(rx_ascii_classes_p(), rx_slice_f(s_p3, start_p5, j_p6)) == std::optional<bool>{}
        ? rx_fail_f(st_p0, at_p2, rx_class_ascii_unknown_p())
        : std::move(negated_p4) && fi_p1
        ? rx_fail_f(st_p0, at_p2, rx_class_negated_under_i_p())
        : rx_go_f(st_p0, j_p6 + Nat(2u));
}


/// RxGroup: unbounded fn RxState, Bool -> ((RxLast, RxMeasure, Bool, RxState))
std::tuple<RxLast, RxMeasure, bool, RxState> rx_group_f(const RxState& st_p0, const bool& fi_p1) {
    auto open_p2 = st_p0.i_p;
    auto s_p3 = st_p0.s_p;
    auto c_p4 = rx_char_at_f(s_p3, open_p2 + Nat(1u));
    auto d_p5 = rx_char_at_f(s_p3, open_p2 + Nat(2u));
    auto e_p6 = rx_char_at_f(s_p3, open_p2 + Nat(3u));
    auto fail_f7 = ({
        auto fi_p1x = fi_p1;
        auto st_p0x = st_p0;
        auto open_p2x = open_p2;
        static_cast<Fn<std::tuple<RxLast, RxMeasure, bool, RxState>(const Text&)>>(prism_rtl::rc([=, fi_p1x = std::move(fi_p1x), st_p0x = std::move(st_p0x), open_p2x = std::move(open_p2x)](const Text& message_p8) { return std::tuple{RxLast(RxLast::RxLastAtom{}), rx_atom_p(), fi_p1x, rx_fail_f(st_p0x, open_p2x, message_p8)}; }));
    });
    return c_p4 != Text::lit("?")
        ? rx_group_body_f(rx_go_f(st_p0, open_p2 + Nat(1u)), open_p2, fi_p1, fi_p1, true, std::optional<Text>{})
        : d_p5 == Text::lit("")
        ? fail_f7(rx_group_open_p())
        : d_p5 == Text::lit(":")
        ? rx_group_body_f(rx_go_f(st_p0, open_p2 + Nat(3u)), open_p2, fi_p1, fi_p1, false, std::optional<Text>{})
        : (d_p5 == Text::lit("=")) || (d_p5 == Text::lit("!"))
        ? fail_f7(rx_lookaround_p())
        : (d_p5 == Text::lit("<")) && ((e_p6 == Text::lit("=")) || (e_p6 == Text::lit("!")))
        ? fail_f7(rx_lookaround_p())
        : d_p5 == Text::lit("<")
        ? rx_named_f(st_p0, open_p2, open_p2 + Nat(3u), fi_p1)
        : (d_p5 == Text::lit("P")) && (e_p6 == Text::lit(""))
        ? fail_f7(rx_group_open_p())
        : (d_p5 == Text::lit("P")) && (e_p6 == Text::lit("<"))
        ? rx_named_f(st_p0, open_p2, open_p2 + Nat(4u), fi_p1)
        : (d_p5 == Text::lit("P")) && ((e_p6 == Text::lit("=")) || (e_p6 == Text::lit(">")))
        ? fail_f7(rx_backreference_p())
        : d_p5 == Text::lit("P")
        ? fail_f7(rx_unknown_group_p())
        : (rx_is_letter_f(d_p5) || (d_p5 == Text::lit("-"))) || (d_p5 == Text::lit(")"))
        ? rx_flag_group_f(st_p0, open_p2, fi_p1)
        : fail_f7(rx_unknown_group_p());
}


/// RxNamed: unbounded fn RxState, Nat, Nat, Bool -> ((RxLast, RxMeasure, Bool, RxState))
std::tuple<RxLast, RxMeasure, bool, RxState> rx_named_f(const RxState& st_p0, const Nat& open_p1, const Nat& start_p2, const bool& fi_p3) {
    auto&& _m = rx_find_o(st_p0.s_p, start_p2, Text::lit(">"));
    if (prism_rtl::is_none(_m)) {
        return std::tuple{RxLast(RxLast::RxLastAtom{}), rx_atom_p(), fi_p3, rx_fail_f(st_p0, open_p1, rx_name_open_p())};
    }
    if (prism_rtl::is_some(_m)) {
        auto&& close_p4 = prism_rtl::some_of(_m);
        auto name_p5 = rx_slice_f(st_p0.s_p, start_p2, close_p4);
        return !rx_is_name_f(name_p5)
            ? std::tuple{RxLast(RxLast::RxLastAtom{}), rx_atom_p(), fi_p3, rx_fail_f(st_p0, start_p2, rx_name_shape_p())}
            : crate::prelude::get(st_p0.names_p, name_p5) != std::optional<Nat>{}
            ? std::tuple{RxLast(RxLast::RxLastAtom{}), rx_atom_p(), fi_p3, rx_fail_f(st_p0, open_p1, rx_name_twice_p())}
            : rx_group_body_f(rx_go_f(st_p0, close_p4 + Nat(1u)), open_p1, fi_p3, fi_p3, true, std::optional(name_p5));
    }
    prism_rtl::unreachable("no arm matched");
}


/// RxFlagGroup: unbounded fn RxState, Nat, Bool -> ((RxLast, RxMeasure, Bool, RxState))
std::tuple<RxLast, RxMeasure, bool, RxState> rx_flag_group_f(const RxState& st_p0, const Nat& open_p1, const bool& fi_p2) {
    auto [bare_p3, inner_p4, st2_p5] = rx_flag_letters_f(st_p0, open_p1, fi_p2);
    return rx_bad_f(st2_p5)
        ? std::tuple{RxLast(RxLast::RxLastAtom{}), rx_atom_p(), fi_p2, st2_p5}
        : bare_p3
        ? std::tuple{RxLast(RxLast::RxLastFlagGroup{}), rx_none_p(), inner_p4, st2_p5}
        : rx_group_body_f(st2_p5, open_p1, inner_p4, fi_p2, false, std::optional<Text>{});
}


/// RxFlagLetters: unbounded fn RxState, Nat, Bool -> ((Bool, Bool, RxState))
std::tuple<bool, bool, RxState> rx_flag_letters_f(const RxState& st0_p0, const Nat& open_p1, const bool& fi0_p2) {
    std::tuple<bool, bool, RxState> this_ = std::tuple{false, fi0_p2, st0_p0};
    RxState st_p3 = rx_go_f(st0_p0, open_p1 + Nat(2u));
    bool fi_p4 = fi0_p2;
    Text seen_p5 = Text::lit("");
    std::optional<Nat> dash_o6 = std::optional<Nat>{};
    bool after_dash_p7 = false;
    bool named_p8 = false;
    bool bare_p9 = false;
    bool going_pa = true;
    while (std::move(going_pa) && (!rx_bad_f(st_p3))) {
        auto at_pb = st_p3.i_p;
        auto c_pc = rx_peek_f(st_p3);
        if (c_pc == Text::lit("")) {
            st_p3 = rx_fail_f(st_p3, open_p1, rx_group_open_p());
        } else if ((c_pc == Text::lit(")")) || (c_pc == Text::lit(":"))) {
            if ((!std::move(named_p8)) && (dash_o6 == std::optional<Nat>{})) {
                st_p3 = rx_fail_f(st_p3, open_p1, rx_flags_empty_p());
            } else  {
                ({
                    __label__ _done;
                    prism_rtl::Slot<Unit> _v;
                    if (prism_rtl::is_some(dash_o6)) {
                        auto&& d_pd = prism_rtl::some_of(dash_o6);
                        if (!std::move(after_dash_p7)) {
                            _v.set(({
                                st_p3 = rx_fail_f(st_p3, d_pd, rx_flags_dash_p());
                                Unit{};
                            }));
                            goto _done;
                        }
                    }
                    {
                        _v.set(({
                            st_p3 = rx_go_f(st_p3, at_pb + Nat(1u));
                            bare_p9 = c_pc == Text::lit(")");
                            going_pa = false;
                            Unit{};
                        }));
                        goto _done;
                    }
                _done:
                    _v.take();
                });
            }
        } else if (c_pc == Text::lit("-")) {
            if (dash_o6 != std::optional<Nat>{}) {
                st_p3 = rx_fail_f(st_p3, at_pb, rx_flags_second_dash_p());
            } else  {
                dash_o6 = std::optional(at_pb);
                st_p3 = rx_go_f(st_p3, at_pb + Nat(1u));
            }
        } else if (rx_is_letter_f(c_pc)) {
            if (!(((c_pc == Text::lit("i")) || (c_pc == Text::lit("m"))) || (c_pc == Text::lit("s")))) {
                st_p3 = rx_fail_f(st_p3, at_pb, rx_unknown_flag_p());
            } else if (rx_in_f(seen_p5, c_pc)) {
                st_p3 = rx_fail_f(st_p3, at_pb, rx_flag_twice_p());
            } else  {
                seen_p5 = prism_rtl::cat(seen_p5, c_pc);
                named_p8 = true;
                if (dash_o6 != std::optional<Nat>{}) {
                    after_dash_p7 = true;
                }
                if (c_pc == Text::lit("i")) {
                    fi_p4 = dash_o6 == std::optional<Nat>{};
                }
                st_p3 = rx_go_f(st_p3, at_pb + Nat(1u));
            }
        } else  {
            st_p3 = rx_fail_f(st_p3, open_p1, rx_unknown_group_p());
        }
    }
    this_ = std::tuple{std::move(bare_p9), std::move(fi_p4), st_p3};
    return this_;
}


/// RxGroupBody: unbounded fn RxState, Nat, Bool, Bool, Bool, ?Text -> ((RxLast, RxMeasure, Bool, RxState))
std::tuple<RxLast, RxMeasure, bool, RxState> rx_group_body_f(const RxState& st0_p0, const Nat& open_p1, const bool& inner_p2, const bool& outer_p3, const bool& capture_p4, const std::optional<Text>& name_o5) {
    auto counted_p6 = capture_p4 ? rx_capture_f(st0_p0, name_o5) : st0_p0;
    return prism_rtl::deref(counted_p6).open_p == Nat(100u)
        ? std::tuple{RxLast(RxLast::RxLastAtom{}), rx_atom_p(), outer_p3, rx_fail_f(counted_p6, Nat(0u), rx_nesting_p())}
        : ({
        auto deeper_p7 = ({
            RxState this_ = counted_p6;
            this_.open_p = this_.open_p + Nat(1u);
            (std::move(this_));
        });
        auto [m_p8, st2_p9] = rx_alternation_f(deeper_p7, inner_p2);
        rx_bad_f(st2_p9)
        ? std::tuple{RxLast(RxLast::RxLastAtom{}), rx_atom_p(), outer_p3, st2_p9}
        : rx_peek_f(st2_p9) != Text::lit(")")
        ? std::tuple{RxLast(RxLast::RxLastAtom{}), rx_atom_p(), outer_p3, rx_fail_f(st2_p9, open_p1, rx_group_open_p())}
        : ({
        auto closed_pa = ({
            RxState this_ = st2_p9;
            this_.i_p = this_.i_p + Nat(1u);
            this_.open_p = crate::prelude::or_(this_.open_p.checked_sub(Nat(1u)), Nat(0u));
            (std::move(this_));
        });
        std::tuple{RxLast(RxLast::RxLastAtom{}), RxMeasure{.depth_p = prism_rtl::deref(m_p8).depth_p + Nat(1u), .size_p = prism_rtl::deref(m_p8).size_p, .product_p = prism_rtl::deref(m_p8).product_p}, outer_p3, closed_pa};
    });
    });
}


/// RxCapture: fn RxState, ?Text -> RxState
RxState rx_capture_f(const RxState& st_p0, const std::optional<Text>& name_o1) {
    auto n_p2 = st_p0.groups_p + Nat(1u);
    auto names_p3 = ({
        __label__ _done;
        prism_rtl::Slot<Map<Text, Nat>> _v;
        if (prism_rtl::is_some(name_o1)) {
            auto&& x_p4 = prism_rtl::some_of(name_o1);
            _v.set(crate::prelude::insert(st_p0.names_p, x_p4, n_p2));
            goto _done;
        }
        if (prism_rtl::is_none(name_o1)) {
            _v.set(st_p0.names_p);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return RxState{.s_p = st_p0.s_p, .i_p = st_p0.i_p, .open_p = st_p0.open_p, .groups_p = n_p2, .names_p = names_p3, .err_o = st_p0.err_o};
}


/// ?RxReplacementRefusal: unbounded fn Text, Nat, (Text ==> Nat) -> ?RxDiag
std::optional<RxDiag> rx_replacement_refusal_o(const Text& r_p0, const Nat& groups_p1, const Map<Text, Nat>& names_p2) {
    auto&& _d_of = ({
        std::tuple<std::optional<RxDiag>, Nat> this_ = std::tuple{std::optional<RxDiag>{}, Nat(0u)};
        Nat i_p3 = Nat(0u);
        std::optional<RxDiag> d_o4 = std::optional<RxDiag>{};
        while ((d_o4 == std::optional<RxDiag>{}) && (rx_char_at_f(r_p0, i_p3) != Text::lit(""))) {
            auto at_p5 = i_p3;
            auto c_p6 = rx_char_at_f(r_p0, at_p5);
            auto next_p7 = rx_char_at_f(r_p0, at_p5 + Nat(1u));
            if (c_p6 == Text::lit("$")) {
                if (next_p7 == Text::lit("$")) {
                    i_p3 = at_p5 + Nat(2u);
                } else if (rx_is_digit_f(next_p7)) {
                    auto j_p8 = rx_span_end_f(r_p0, at_p5 + Nat(1u), ({
                        auto f = prism_rtl::rc(rx_is_digit_f);
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>>(prism_rtl::rc([=, f = std::move(f)](Text a0) {
                        return ({
                            auto fy = f;
                            (crate::prelude::once_job([=, fy = std::move(fy)]() { return prism_rtl::finished(fy(a0)); }));
                        });
                    })));
                    }));
                    d_o4 = rx_group_number_o(rx_slice_f(r_p0, at_p5 + Nat(1u), j_p8), groups_p1, at_p5);
                    i_p3 = j_p8;
                } else if (next_p7 == Text::lit("{")) {
                    {
                        auto&& _m = rx_find_o(r_p0, at_p5 + Nat(2u), Text::lit("}"));
                        if (prism_rtl::is_none(_m)) {
                            d_o4 = rx_replacement_at_o(at_p5, rx_rbraces_p());
                        } else if (prism_rtl::is_some(_m)) {
                            auto&& close_p9 = prism_rtl::some_of(_m);
                            auto inner_pa = rx_slice_f(r_p0, at_p5 + Nat(2u), close_p9);
                            if ((inner_pa != Text::lit("")) && rx_all_f(inner_pa, ({
                                auto f = prism_rtl::rc(rx_is_digit_f);
                                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>>(prism_rtl::rc([=, f = std::move(f)](Text a0) {
                                return ({
                                    auto fy = f;
                                    (crate::prelude::once_job([=, fy = std::move(fy)]() { return prism_rtl::finished(fy(a0)); }));
                                });
                            })));
                            }))) {
                                d_o4 = rx_group_number_o(inner_pa, groups_p1, at_p5);
                            } else if (rx_is_name_f(inner_pa)) {
                                if (crate::prelude::get(names_p2, inner_pa) == std::optional<Nat>{}) {
                                    d_o4 = rx_replacement_at_o(at_p5, rx_rno_name_p());
                                }
                            } else  {
                                d_o4 = rx_replacement_at_o(at_p5, rx_rbraces_p());
                            }
                            i_p3 = close_p9 + Nat(1u);
                        }
                    }
                } else  {
                    d_o4 = rx_replacement_at_o(at_p5, rx_rdollar_p());
                }
            } else if (c_p6 == Text::lit("\\")) {
                if ((((next_p7 == Text::lit("\\")) || (next_p7 == Text::lit("n"))) || (next_p7 == Text::lit("t"))) || (next_p7 == Text::lit("/"))) {
                    i_p3 = at_p5 + Nat(2u);
                } else if (next_p7 == Text::lit("u")) {
                    auto j_pb = rx_span_end_f(r_p0, at_p5 + Nat(3u), ({
                        auto f = prism_rtl::rc(rx_is_hex_f);
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>>(prism_rtl::rc([=, f = std::move(f)](Text a0) {
                        return ({
                            auto fy = f;
                            (crate::prelude::once_job([=, fy = std::move(fy)]() { return prism_rtl::finished(fy(a0)); }));
                        });
                    })));
                    }));
                    auto digits_pc = rx_slice_f(r_p0, at_p5 + Nat(3u), j_pb);
                    auto v_pd = rx_hex_value_f(digits_pc);
                    auto named_pe = ((((rx_char_at_f(r_p0, at_p5 + Nat(2u)) == Text::lit("{")) && (rx_char_at_f(r_p0, j_pb) == Text::lit("}"))) && (digits_pc != Text::lit(""))) && (crate::prelude::len_text(digits_pc) <= Nat(6u))) && (!(((Nat(55296u) <= v_pd) && (v_pd <= Nat(57343u))) || (v_pd > Nat(1114111u))));
                    if (std::move(named_pe)) {
                        i_p3 = j_pb + Nat(1u);
                    } else  {
                        d_o4 = rx_replacement_at_o(at_p5, rx_runicode_p());
                    }
                } else  {
                    d_o4 = rx_replacement_at_o(at_p5, rx_rescape_p());
                }
            } else  {
                i_p3 = at_p5 + crate::prelude::len_text(c_p6);
            }
        }
        this_ = std::tuple{d_o4, i_p3};
        (std::move(this_));
    });
    auto&& d_of = std::get<0>(_d_of);
    return d_of;
}


prism_rtl::Turn<std::optional<RxDiag>> RxReplacementRefusal::cycle() const {
    const auto& r_p0 = this->r_p0;
    const auto& groups_p1 = this->groups_p1;
    const auto& names_p2 = this->names_p2;
    std::tuple<std::optional<RxDiag>, Nat> this_ = std::tuple{std::optional<RxDiag>{}, Nat(0u)};
    Nat i_p3 = Nat(0u);
    std::optional<RxDiag> d_o4 = std::optional<RxDiag>{};
    return crate::prelude::call_then(crate::prelude::loop_job(std::tuple{std::move(d_o4), std::move(this_), std::move(i_p3)}, ({
        auto groups_p1x = groups_p1;
        auto names_p2x = names_p2;
        auto r_p0x = r_p0;
        [=, groups_p1x = std::move(groups_p1x), names_p2x = std::move(names_p2x), r_p0x = std::move(r_p0x)](std::tuple<std::optional<RxDiag>, std::tuple<std::optional<RxDiag>, Nat>, Nat> _p0) {
        auto d_o4 = std::get<0>(_p0);
        auto this_ = std::get<1>(_p0);
        auto i_p3 = std::get<2>(_p0);
        return (d_o4 == std::optional<RxDiag>{}) && (rx_char_at_f(r_p0x, i_p3) != Text::lit(""))
            ? ({
            auto at_p5 = i_p3;
            auto c_p6 = rx_char_at_f(r_p0x, at_p5);
            auto next_p7 = rx_char_at_f(r_p0x, at_p5 + Nat(1u));
            if (c_p6 == Text::lit("$")) {
                if (next_p7 == Text::lit("$")) {
                    i_p3 = at_p5 + Nat(2u);
                } else if (rx_is_digit_f(next_p7)) {
                    auto j_p8 = rx_span_end_f(r_p0x, at_p5 + Nat(1u), ({
                        auto f = prism_rtl::rc(rx_is_digit_f);
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>>(prism_rtl::rc([=, f = std::move(f)](Text a0) {
                        return ({
                            auto fy = f;
                            (crate::prelude::once_job([=, fy = std::move(fy)]() { return prism_rtl::finished(fy(a0)); }));
                        });
                    })));
                    }));
                    d_o4 = rx_group_number_o(rx_slice_f(r_p0x, at_p5 + Nat(1u), j_p8), groups_p1x, at_p5);
                    i_p3 = j_p8;
                } else if (next_p7 == Text::lit("{")) {
                    {
                        auto&& _m = rx_find_o(r_p0x, at_p5 + Nat(2u), Text::lit("}"));
                        if (prism_rtl::is_none(_m)) {
                            d_o4 = rx_replacement_at_o(at_p5, rx_rbraces_p());
                        } else if (prism_rtl::is_some(_m)) {
                            auto&& close_p9 = prism_rtl::some_of(_m);
                            auto inner_pa = rx_slice_f(r_p0x, at_p5 + Nat(2u), close_p9);
                            if ((inner_pa != Text::lit("")) && rx_all_f(inner_pa, ({
                                auto f = prism_rtl::rc(rx_is_digit_f);
                                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>>(prism_rtl::rc([=, f = std::move(f)](Text a0) {
                                return ({
                                    auto fy = f;
                                    (crate::prelude::once_job([=, fy = std::move(fy)]() { return prism_rtl::finished(fy(a0)); }));
                                });
                            })));
                            }))) {
                                d_o4 = rx_group_number_o(inner_pa, groups_p1x, at_p5);
                            } else if (rx_is_name_f(inner_pa)) {
                                if (crate::prelude::get(names_p2x, inner_pa) == std::optional<Nat>{}) {
                                    d_o4 = rx_replacement_at_o(at_p5, rx_rno_name_p());
                                }
                            } else  {
                                d_o4 = rx_replacement_at_o(at_p5, rx_rbraces_p());
                            }
                            i_p3 = close_p9 + Nat(1u);
                        }
                    }
                } else  {
                    d_o4 = rx_replacement_at_o(at_p5, rx_rdollar_p());
                }
            } else if (c_p6 == Text::lit("\\")) {
                if ((((next_p7 == Text::lit("\\")) || (next_p7 == Text::lit("n"))) || (next_p7 == Text::lit("t"))) || (next_p7 == Text::lit("/"))) {
                    i_p3 = at_p5 + Nat(2u);
                } else if (next_p7 == Text::lit("u")) {
                    auto j_pb = rx_span_end_f(r_p0x, at_p5 + Nat(3u), ({
                        auto f = prism_rtl::rc(rx_is_hex_f);
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>>(prism_rtl::rc([=, f = std::move(f)](Text a0) {
                        return ({
                            auto fy = f;
                            (crate::prelude::once_job([=, fy = std::move(fy)]() { return prism_rtl::finished(fy(a0)); }));
                        });
                    })));
                    }));
                    auto digits_pc = rx_slice_f(r_p0x, at_p5 + Nat(3u), j_pb);
                    auto v_pd = rx_hex_value_f(digits_pc);
                    auto named_pe = ((((rx_char_at_f(r_p0x, at_p5 + Nat(2u)) == Text::lit("{")) && (rx_char_at_f(r_p0x, j_pb) == Text::lit("}"))) && (digits_pc != Text::lit(""))) && (crate::prelude::len_text(digits_pc) <= Nat(6u))) && (!(((Nat(55296u) <= v_pd) && (v_pd <= Nat(57343u))) || (v_pd > Nat(1114111u))));
                    if (std::move(named_pe)) {
                        i_p3 = j_pb + Nat(1u);
                    } else  {
                        d_o4 = rx_replacement_at_o(at_p5, rx_runicode_p());
                    }
                } else  {
                    d_o4 = rx_replacement_at_o(at_p5, rx_rescape_p());
                }
            } else  {
                i_p3 = at_p5 + crate::prelude::len_text(c_p6);
            }
            Expected<std::tuple<std::optional<RxDiag>, std::tuple<std::optional<RxDiag>, Nat>, Nat>, std::tuple<std::optional<RxDiag>, std::tuple<std::optional<RxDiag>, Nat>, Nat>>(std::tuple{d_o4, this_, i_p3});
        })
            : Expected<std::tuple<std::optional<RxDiag>, std::tuple<std::optional<RxDiag>, Nat>, Nat>, std::tuple<std::optional<RxDiag>, std::tuple<std::optional<RxDiag>, Nat>, Nat>>(unexpected(std::tuple{d_o4, this_, i_p3}));
    };
    })), [=](std::tuple<std::optional<RxDiag>, std::tuple<std::optional<RxDiag>, Nat>, Nat> _p0) {
        auto d_o4 = std::get<0>(_p0);
        auto this_ = std::get<1>(_p0);
        auto i_p3 = std::get<2>(_p0);
        return ({
            this_ = std::tuple{d_o4, i_p3};
            auto&& _d_of = this_;
            auto&& d_of = std::get<0>(_d_of);
            (prism_rtl::finished(d_of));
        });
    });
}


/// `Start RxReplacementRefusal, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<RxDiag>> start_rx_replacement_refusal_o(Text r_p0, Nat groups_p1, Map<Text, Nat> names_p2) {
    return prism_rtl::make_rc<RxReplacementRefusal>(r_p0, groups_p1, names_p2);
}


/// ?RxReplacementAt: fn Nat, Text -> ?RxDiag
std::optional<RxDiag> rx_replacement_at_o(const Nat& at_p0, const Text& message_p1) {
    return std::optional(RxDiag{.part_p = Text::lit("replacement"), .at_p = at_p0, .message_p = message_p1});
}


/// ?RxGroupNumber: fn Text, Nat, Nat -> ?RxDiag
std::optional<RxDiag> rx_group_number_o(const Text& digits_p0, const Nat& groups_p1, const Nat& at_p2) {
    return rx_leading_zero_f(digits_p0)
        ? rx_replacement_at_o(at_p2, rx_rzero_p())
        : crate::prelude::or_(crate::prelude::parse_nat_opt(digits_p0), Nat(0u)) > groups_p1
        ? rx_replacement_at_o(at_p2, rx_rno_number_p())
        : std::optional<RxDiag>{};
}

}  // namespace crate::check::regex
