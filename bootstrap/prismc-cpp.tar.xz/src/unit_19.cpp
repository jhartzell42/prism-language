// The modules `Check.Regex`, `Check.Shrink`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <syntax/module.hpp>
#include <check/env/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Check.Regex`, from `target/bootstrap/cpp-src/prismc/check/regex/mod.prism`.
namespace crate::check::regex {

void RxCp::show(Printer& p) const {
    if (auto c = std::get_if<RxLit>(&cases())) p.choice("RxLit", {c->a0});
    else if (auto c = std::get_if<RxNum>(&cases())) p.choice("RxNum", {c->a0});
}

Pod RxCp::to_pod() const {
    return std::holds_alternative<RxLit>(cases()) ? Pod::choice("RxLit", {prism_rtl::to_pod(std::get<RxLit>(cases()).a0)})
        : std::holds_alternative<RxNum>(cases()) ? Pod::choice("RxNum", {prism_rtl::to_pod(std::get<RxNum>(cases()).a0)})
        : Pod();
}

Result<RxCp> RxCp::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "RxLit" && c->args.size() == 1) return RxCp(RxLit{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "RxNum" && c->args.size() == 1) return RxCp(RxNum{TRY(prism_rtl::from_pod<Nat>(c->args[0]))});
    }
    return mismatch<RxCp>("a RxCp", p);
}


void RxDiag::show(Printer& p) const {
    p.record("RxDiag", {{"part", part}, {"at", at}, {"message", message}});
}

Pod RxDiag::to_pod() const {
    return Pod::record("RxDiag", {{"part", prism_rtl::to_pod(part)}, {"at", prism_rtl::to_pod(at)}, {"message", prism_rtl::to_pod(message)}});
}

Result<RxDiag> RxDiag::from_pod(const Pod& whole) {
    return RxDiag{.part = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "part")))), .at = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "at")))), .message = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "message"))))};
}


void RxLast::show(Printer& p) const {
    if (auto c = std::get_if<RxLastNothing>(&cases())) p.choice("RxLastNothing", {});
    else if (auto c = std::get_if<RxLastFlagGroup>(&cases())) p.choice("RxLastFlagGroup", {});
    else if (auto c = std::get_if<RxLastAssertion>(&cases())) p.choice("RxLastAssertion", {});
    else if (auto c = std::get_if<RxLastRepetition>(&cases())) p.choice("RxLastRepetition", {});
    else if (auto c = std::get_if<RxLastAtom>(&cases())) p.choice("RxLastAtom", {});
}

Pod RxLast::to_pod() const {
    return std::holds_alternative<RxLastNothing>(cases()) ? Pod::choice("RxLastNothing", {})
        : std::holds_alternative<RxLastFlagGroup>(cases()) ? Pod::choice("RxLastFlagGroup", {})
        : std::holds_alternative<RxLastAssertion>(cases()) ? Pod::choice("RxLastAssertion", {})
        : std::holds_alternative<RxLastRepetition>(cases()) ? Pod::choice("RxLastRepetition", {})
        : std::holds_alternative<RxLastAtom>(cases()) ? Pod::choice("RxLastAtom", {})
        : Pod();
}

Result<RxLast> RxLast::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "RxLastNothing" && c->args.size() == 0) return RxLast(RxLastNothing{});
        if (c->ctor == "RxLastFlagGroup" && c->args.size() == 0) return RxLast(RxLastFlagGroup{});
        if (c->ctor == "RxLastAssertion" && c->args.size() == 0) return RxLast(RxLastAssertion{});
        if (c->ctor == "RxLastRepetition" && c->args.size() == 0) return RxLast(RxLastRepetition{});
        if (c->ctor == "RxLastAtom" && c->args.size() == 0) return RxLast(RxLastAtom{});
    }
    return mismatch<RxLast>("a RxLast", p);
}


void RxMeasure::show(Printer& p) const {
    p.record("RxMeasure", {{"depth", depth}, {"size", size}, {"product", product}});
}

Pod RxMeasure::to_pod() const {
    return Pod::record("RxMeasure", {{"depth", prism_rtl::to_pod(depth)}, {"size", prism_rtl::to_pod(size)}, {"product", prism_rtl::to_pod(product)}});
}

Result<RxMeasure> RxMeasure::from_pod(const Pod& whole) {
    return RxMeasure{.depth = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "depth")))), .size = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "size")))), .product = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "product"))))};
}


void RxState::show(Printer& p) const {
    p.record("RxState", {{"s", s}, {"i", i}, {"open", open}, {"groups", groups}, {"names", names}, {"err", err}});
}

Pod RxState::to_pod() const {
    return Pod::record("RxState", {{"s", prism_rtl::to_pod(s)}, {"i", prism_rtl::to_pod(i)}, {"open", prism_rtl::to_pod(open)}, {"groups", prism_rtl::to_pod(groups)}, {"names", prism_rtl::to_pod(names)}, {"err", prism_rtl::to_pod(err)}});
}

Result<RxState> RxState::from_pod(const Pod& whole) {
    return RxState{.s = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "s")))), .i = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "i")))), .open = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "open")))), .groups = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "groups")))), .names = TRY(prism_rtl::from_pod<Map<Text, Nat>>(TRY(crate::prelude::field(whole, "names")))), .err = TRY(prism_rtl::from_pod<std::optional<RxDiag>>(TRY(crate::prelude::field(whole, "err"))))};
}


/// let rxUnknownFlag
Text rx_unknown_flag() {
    return Text::lit("an unknown flag: the flags are i, m and s");
}


/// let rxFlagTwice
Text rx_flag_twice() {
    return Text::lit("a flag written twice");
}


/// let rxStrayBracket
Text rx_stray_bracket() {
    return Text::lit("a ] outside a class: a literal one is \\]");
}


/// let rxStrayBrace
Text rx_stray_brace() {
    return Text::lit("a } outside a count: a literal one is \\}");
}


/// let rxTrailingBackslash
Text rx_trailing_backslash() {
    return Text::lit("a \\ at the end of the pattern");
}


/// let rxHexTwo
Text rx_hex_two() {
    return Text::lit("a \\x escape needs two hex digits or braces");
}


/// let rxHexBraces
Text rx_hex_braces() {
    return Text::lit("a \\x{...} escape needs one to six hex digits");
}


/// let rxHexNoChar
Text rx_hex_no_char() {
    return Text::lit("a \\x escape names no character: a surrogate or past U+10FFFF");
}


/// let rxWordBraces
Text rx_word_braces() {
    return Text::lit("\\b{...} is Rust\'s only: write \\b");
}


/// let rxAngle
Text rx_angle() {
    return Text::lit("\\< and \\> are Rust\'s only: write \\b");
}


/// let rxBackreference
Text rx_backreference() {
    return Text::lit("a backreference: refused so that every match is linear in its text");
}


/// let rxOctal
Text rx_octal() {
    return Text::lit("an octal escape is RE2\'s only: write \\x");
}


/// let rxQuote
Text rx_quote() {
    return Text::lit("\\Q...\\E is RE2\'s only: escape each character");
}


/// let rxOneByte
Text rx_one_byte() {
    return Text::lit("\\C, one byte, is RE2\'s only");
}


/// let rxUnknownEscape
Text rx_unknown_escape() {
    return Text::lit("an unknown escape");
}


/// let rxPropertyName
Text rx_property_name() {
    return Text::lit("a \\p escape needs a property name");
}


/// let rxPropertyOpen
Text rx_property_open() {
    return Text::lit("a \\p{ that is never closed");
}


/// let rxPropertyNegated
Text rx_property_negated() {
    return Text::lit("a negated property is written \\P{...}");
}


/// let rxPropertyRefused
Text rx_property_refused() {
    return Text::lit("the property is refused: RE2 and Rust disagree on C, Cn, Cs and LC");
}


/// let rxPropertyUnknown
Text rx_property_unknown() {
    return Text::lit("an unknown property: general categories by short name, scripts and Any");
}


/// let rxClassOpen
Text rx_class_open() {
    return Text::lit("a class opened here is never closed");
}


/// let rxClassFirstBracket
Text rx_class_first_bracket() {
    return Text::lit("a ] first in a class: write \\]");
}


/// let rxClassNested
Text rx_class_nested() {
    return Text::lit("a [ inside a class: write \\[ (nested classes are Rust\'s only)");
}


/// let rxClassAsciiUnknown
Text rx_class_ascii_unknown() {
    return Text::lit("an unknown ASCII class");
}


/// let rxClassSetOperation
Text rx_class_set_operation() {
    return Text::lit("&&, ~~ and -- in a class are Rust\'s set operations: escape them");
}


/// let rxClassDash
Text rx_class_dash() {
    return Text::lit("a - in a class that is neither a range nor first or last: write \\-");
}


/// let rxClassOrder
Text rx_class_order() {
    return Text::lit("a range whose ends are out of order");
}


/// let rxClassRangeSet
Text rx_class_range_set() {
    return Text::lit("a range end that is a class");
}


/// let rxClassNegatedUnderI
Text rx_class_negated_under_i() {
    return Text::lit("a negated class inside a class under i: write it outside the class");
}


/// let rxClassEscape
Text rx_class_escape() {
    return Text::lit("an escape that a class cannot hold");
}


/// let rxLookaround
Text rx_lookaround() {
    return Text::lit("a lookaround: refused so that every match is linear in its text");
}


/// let rxUnknownGroup
Text rx_unknown_group() {
    return Text::lit("an unknown group: the groups are (re), (?:re), (?<name>re), (?P<name>re) and the flag groups");
}


/// let rxNameShape
Text rx_name_shape() {
    return Text::lit("a group name is a lowercase value name, [a-z_][a-z0-9_]*");
}


/// let rxNameOpen
Text rx_name_open() {
    return Text::lit("a group name that is never closed");
}


/// let rxNameTwice
Text rx_name_twice() {
    return Text::lit("a group name used twice");
}


/// let rxGroupOpen
Text rx_group_open() {
    return Text::lit("a group opened here is never closed");
}


/// let rxGroupClose
Text rx_group_close() {
    return Text::lit("a ) that closes no group");
}


/// let rxFlagsEmpty
Text rx_flags_empty() {
    return Text::lit("an empty flag group");
}


/// let rxFlagsSecondDash
Text rx_flags_second_dash() {
    return Text::lit("a second - in a flag group");
}


/// let rxFlagsDash
Text rx_flags_dash() {
    return Text::lit("a - that turns off no flag");
}


/// let rxBrace
Text rx_brace() {
    return Text::lit("a brace that opens no count: a literal one is \\{");
}


/// let rxCountZero
Text rx_count_zero() {
    return Text::lit("a count with a leading zero");
}


/// let rxCountBound
Text rx_count_bound() {
    return Text::lit("a count above 1000");
}


/// let rxCountOrder
Text rx_count_order() {
    return Text::lit("a count whose minimum exceeds its maximum");
}


/// let rxNothingToRepeat
Text rx_nothing_to_repeat() {
    return Text::lit("a repetition with nothing to repeat");
}


/// let rxRepeatRepeat
Text rx_repeat_repeat() {
    return Text::lit("a repetition of a repetition: write (?:a*)* to say it");
}


/// let rxRepeatAssertion
Text rx_repeat_assertion() {
    return Text::lit("a repetition of an assertion");
}


/// let rxProduct
Text rx_product() {
    return Text::lit("nested counts multiplying past 1000");
}


/// let rxNesting
Text rx_nesting() {
    return Text::lit("groups and repetitions nested more than 100 deep");
}


/// let rxSize
Text rx_size() {
    return Text::lit("the pattern expands past 10,000 atoms");
}


/// let rxRZero
Text rx_rzero() {
    return Text::lit("a group number with a leading zero");
}


/// let rxRBraces
Text rx_rbraces() {
    return Text::lit("a ${...} that is neither a group number nor a group name");
}


/// let rxRDollar
Text rx_rdollar() {
    return Text::lit("a $ that is not $n, ${n}, ${name} or $$");
}


/// let rxRNoNumber
Text rx_rno_number() {
    return Text::lit("the pattern has no group of that number");
}


/// let rxRNoName
Text rx_rno_name() {
    return Text::lit("the pattern has no group of that name");
}


/// let rxRUnicode
Text rx_runicode() {
    return Text::lit("a \\u{...} escape needs one to six hex digits naming a character");
}


/// let rxREscape
Text rx_rescape() {
    return Text::lit("an unknown escape in a replacement: the escapes are \\\\, \\n, \\t, \\u{hex} and \\/");
}


/// let rxCategories
Array<Text> rx_categories() {
    return Array(std::vector{Text::lit("Cc"), Text::lit("Cf"), Text::lit("Co"), Text::lit("L"), Text::lit("Ll"), Text::lit("Lm"), Text::lit("Lo"), Text::lit("Lt"), Text::lit("Lu"), Text::lit("M"), Text::lit("Mc"), Text::lit("Me"), Text::lit("Mn"), Text::lit("N"), Text::lit("Nd"), Text::lit("Nl"), Text::lit("No"), Text::lit("P"), Text::lit("Pc"), Text::lit("Pd"), Text::lit("Pe"), Text::lit("Pf"), Text::lit("Pi"), Text::lit("Po"), Text::lit("Ps"), Text::lit("S"), Text::lit("Sc"), Text::lit("Sk"), Text::lit("Sm"), Text::lit("So"), Text::lit("Z"), Text::lit("Zl"), Text::lit("Zp"), Text::lit("Zs")});
}


/// let rxScripts
Array<Text> rx_scripts() {
    return Array(std::vector{Text::lit("Adlam"), Text::lit("Ahom"), Text::lit("Anatolian_Hieroglyphs"), Text::lit("Arabic"), Text::lit("Armenian"), Text::lit("Avestan"), Text::lit("Balinese"), Text::lit("Bamum"), Text::lit("Bassa_Vah"), Text::lit("Batak"), Text::lit("Bengali"), Text::lit("Bhaiksuki"), Text::lit("Bopomofo"), Text::lit("Brahmi"), Text::lit("Braille"), Text::lit("Buginese"), Text::lit("Buhid"), Text::lit("Canadian_Aboriginal"), Text::lit("Carian"), Text::lit("Caucasian_Albanian"), Text::lit("Chakma"), Text::lit("Cham"), Text::lit("Cherokee"), Text::lit("Chorasmian"), Text::lit("Common"), Text::lit("Coptic"), Text::lit("Cuneiform"), Text::lit("Cypriot"), Text::lit("Cypro_Minoan"), Text::lit("Cyrillic"), Text::lit("Deseret"), Text::lit("Devanagari"), Text::lit("Dives_Akuru"), Text::lit("Dogra"), Text::lit("Duployan"), Text::lit("Egyptian_Hieroglyphs"), Text::lit("Elbasan"), Text::lit("Elymaic"), Text::lit("Ethiopic"), Text::lit("Georgian"), Text::lit("Glagolitic"), Text::lit("Gothic"), Text::lit("Grantha"), Text::lit("Greek"), Text::lit("Gujarati"), Text::lit("Gunjala_Gondi"), Text::lit("Gurmukhi"), Text::lit("Han"), Text::lit("Hangul"), Text::lit("Hanifi_Rohingya"), Text::lit("Hanunoo"), Text::lit("Hatran"), Text::lit("Hebrew"), Text::lit("Hiragana"), Text::lit("Imperial_Aramaic"), Text::lit("Inherited"), Text::lit("Inscriptional_Pahlavi"), Text::lit("Inscriptional_Parthian"), Text::lit("Javanese"), Text::lit("Kaithi"), Text::lit("Kannada"), Text::lit("Katakana"), Text::lit("Kawi"), Text::lit("Kayah_Li"), Text::lit("Kharoshthi"), Text::lit("Khitan_Small_Script"), Text::lit("Khmer"), Text::lit("Khojki"), Text::lit("Khudawadi"), Text::lit("Lao"), Text::lit("Latin"), Text::lit("Lepcha"), Text::lit("Limbu"), Text::lit("Linear_A"), Text::lit("Linear_B"), Text::lit("Lisu"), Text::lit("Lycian"), Text::lit("Lydian"), Text::lit("Mahajani"), Text::lit("Makasar"), Text::lit("Malayalam"), Text::lit("Mandaic"), Text::lit("Manichaean"), Text::lit("Marchen"), Text::lit("Masaram_Gondi"), Text::lit("Medefaidrin"), Text::lit("Meetei_Mayek"), Text::lit("Mende_Kikakui"), Text::lit("Meroitic_Cursive"), Text::lit("Meroitic_Hieroglyphs"), Text::lit("Miao"), Text::lit("Modi"), Text::lit("Mongolian"), Text::lit("Mro"), Text::lit("Multani"), Text::lit("Myanmar"), Text::lit("Nabataean"), Text::lit("Nag_Mundari"), Text::lit("Nandinagari"), Text::lit("New_Tai_Lue"), Text::lit("Newa"), Text::lit("Nko"), Text::lit("Nushu"), Text::lit("Nyiakeng_Puachue_Hmong"), Text::lit("Ogham"), Text::lit("Ol_Chiki"), Text::lit("Old_Hungarian"), Text::lit("Old_Italic"), Text::lit("Old_North_Arabian"), Text::lit("Old_Permic"), Text::lit("Old_Persian"), Text::lit("Old_Sogdian"), Text::lit("Old_South_Arabian"), Text::lit("Old_Turkic"), Text::lit("Old_Uyghur"), Text::lit("Oriya"), Text::lit("Osage"), Text::lit("Osmanya"), Text::lit("Pahawh_Hmong"), Text::lit("Palmyrene"), Text::lit("Pau_Cin_Hau"), Text::lit("Phags_Pa"), Text::lit("Phoenician"), Text::lit("Psalter_Pahlavi"), Text::lit("Rejang"), Text::lit("Runic"), Text::lit("Samaritan"), Text::lit("Saurashtra"), Text::lit("Sharada"), Text::lit("Shavian"), Text::lit("Siddham"), Text::lit("SignWriting"), Text::lit("Sinhala"), Text::lit("Sogdian"), Text::lit("Sora_Sompeng"), Text::lit("Soyombo"), Text::lit("Sundanese"), Text::lit("Syloti_Nagri"), Text::lit("Syriac"), Text::lit("Tagalog"), Text::lit("Tagbanwa"), Text::lit("Tai_Le"), Text::lit("Tai_Tham"), Text::lit("Tai_Viet"), Text::lit("Takri"), Text::lit("Tamil"), Text::lit("Tangsa"), Text::lit("Tangut"), Text::lit("Telugu"), Text::lit("Thaana"), Text::lit("Thai"), Text::lit("Tibetan"), Text::lit("Tifinagh"), Text::lit("Tirhuta"), Text::lit("Toto"), Text::lit("Ugaritic"), Text::lit("Vai"), Text::lit("Vithkuqi"), Text::lit("Wancho"), Text::lit("Warang_Citi"), Text::lit("Yezidi"), Text::lit("Yi"), Text::lit("Zanabazar_Square")});
}


/// let rxProperties
Map<Text, bool> rx_properties() {
    return map(each(crate::prelude::push(append(rx_categories(), rx_scripts()), Text::lit("Any")), [&](const Text& n_p0) { return std::tuple{n_p0, true}; }));
}


/// let rxAsciiClasses
Map<Text, bool> rx_ascii_classes() {
    return map(each(Array(std::vector{Text::lit("alnum"), Text::lit("alpha"), Text::lit("ascii"), Text::lit("blank"), Text::lit("cntrl"), Text::lit("digit"), Text::lit("graph"), Text::lit("lower"), Text::lit("print"), Text::lit("punct"), Text::lit("space"), Text::lit("upper"), Text::lit("word"), Text::lit("xdigit")}), [&](const Text& n_p0) { return std::tuple{n_p0, true}; }));
}


/// let rxAscii
Text rx_ascii() {
    return Text::lit("\000\t\n\r !\"#$%&\'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~"sv);
}


/// let rxPunctuation
Text rx_punctuation() {
    return Text::lit("!\"#$%&\'()*+,-./:;=?@[\\]^_`{|}~");
}


/// let rxNone
RxMeasure rx_none() {
    return RxMeasure{.depth = Nat(0u), .size = Nat(0u), .product = Nat(0u)};
}


/// let rxAtom
RxMeasure rx_atom() {
    return RxMeasure{.depth = Nat(0u), .size = Nat(1u), .product = Nat(1u)};
}


/// RxThen: fn RxMeasure, RxMeasure -> RxMeasure
RxMeasure rx_then(const RxMeasure& a_p0, const RxMeasure& b_p1) {
    return RxMeasure{.depth = crate::prelude::max(a_p0.depth, b_p1.depth), .size = a_p0.size + b_p1.size, .product = crate::prelude::max(a_p0.product, b_p1.product)};
}


/// RxBad: fn RxState -> Bool
bool rx_bad(const RxState& st_p0) {
    return st_p0.err != std::optional<RxDiag>{};
}


/// RxFail: fn RxState, Nat, Text -> RxState
RxState rx_fail(const RxState& st_p0, const Nat& at_p1, const Text& message_p2) {
    return rx_bad(st_p0)
        ? st_p0
        : RxState{.s = st_p0.s, .i = st_p0.i, .open = st_p0.open, .groups = st_p0.groups, .names = st_p0.names, .err = std::optional(RxDiag{.part = Text::lit("pattern"), .at = at_p1, .message = message_p2})};
}


/// RxGo: fn RxState, Nat -> RxState
RxState rx_go(const RxState& st_p0, const Nat& n_p1) {
    RxState this_ = st_p0;
    this_.i = n_p1;
    return this_;
}


/// RxPeek: fn RxState -> Text
Text rx_peek(const RxState& st_p0) {
    return rx_char_at(st_p0.s, st_p0.i);
}


/// RxCharAt: fn Text, Nat -> Text
Text rx_char_at(const Text& t_p0, const Nat& n_p1) {
    auto&& _m = cursor_at(t_p0, n_p1);
    if (prism_rtl::is_some(_m)) {
        auto&& c_p2 = prism_rtl::some_of(_m);
        auto&& _m = step(front(after(c_p2)));
        if (prism_rtl::is_some(_m)) {
            auto&& one_p3 = std::get<1>(prism_rtl::some_of(_m));
            return before(one_p3);
        }
        if (prism_rtl::is_none(_m)) {
            return Text::lit("");
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is_none(_m)) {
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}


/// RxSlice: fn Text, Nat, Nat -> Text
Text rx_slice(const Text& t_p0, const Nat& a_p1, const Nat& b_p2) {
    auto&& _m = cursor_at(t_p0, b_p2);
    if (prism_rtl::is_some(_m)) {
        auto&& cb_p3 = prism_rtl::some_of(_m);
        auto&& _m = cursor_at(before(cb_p3), a_p1);
        if (prism_rtl::is_some(_m)) {
            auto&& ca_p4 = prism_rtl::some_of(_m);
            return after(ca_p4);
        }
        if (prism_rtl::is_none(_m)) {
            return Text::lit("");
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is_none(_m)) {
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}


/// ?RxFind: fn Text, Nat, Text -> ?Nat
std::optional<Nat> rx_find(const Text& t_p0, const Nat& from_p1, const Text& x_p2) {
    auto&& _m = cursor_at(t_p0, from_p1);
    if (prism_rtl::is_none(_m)) {
        return std::optional<Nat>{};
    }
    if (prism_rtl::is_some(_m)) {
        auto&& c0_p3 = prism_rtl::some_of(_m);
        auto&& _found_o7 = ({
            std::tuple<std::optional<Nat>, Cursor> this_ = std::tuple{std::optional<Nat>{}, c0_p3};
            Cursor c_p4 = c0_p3;
            std::optional<Nat> found_o5 = std::optional<Nat>{};
            while (true) {
                auto&& _m = step(c_p4);
                if (!(prism_rtl::is_some(_m))) break;
                auto&& next_p6 = std::get<1>(prism_rtl::some_of(_m));
                if (!(found_o5 == std::optional<Nat>{})) {
                    break;
                }
                if (rx_slice(t_p0, at(c_p4), at(next_p6)) == x_p2) {
                    found_o5 = std::optional(at(c_p4));
                }
                c_p4 = next_p6;
            }
            this_ = std::tuple{found_o5, c_p4};
            (std::move(this_));
        });
        auto&& found_o7 = std::get<0>(_found_o7);
        return found_o7;
    }
    prism_rtl::unreachable("no arm matched");
}


/// RxIn: fn Text, Text -> Bool
bool rx_in(const Text& set_p0, const Text& c_p1) {
    return (c_p1 != Text::lit("")) && (rx_find(set_p0, Nat(0u), c_p1) != std::optional<Nat>{});
}


/// RxIsDigit: fn Text -> Bool
bool rx_is_digit(const Text& c_p0) {
    return ((Text::lit("0") <= c_p0) && (c_p0 <= Text::lit("9"))) && (len_text(c_p0) == Nat(1u));
}


/// RxIsLetter: fn Text -> Bool
bool rx_is_letter(const Text& c_p0) {
    return ((Text::lit("a") <= c_p0) && (c_p0 <= Text::lit("z"))) || ((Text::lit("A") <= c_p0) && (c_p0 <= Text::lit("Z")));
}


/// RxIsHex: fn Text -> Bool
bool rx_is_hex(const Text& c_p0) {
    return (rx_is_digit(c_p0) || ((Text::lit("a") <= c_p0) && (c_p0 <= Text::lit("f")))) || ((Text::lit("A") <= c_p0) && (c_p0 <= Text::lit("F")));
}


/// RxIsName: fn Text -> Bool
bool rx_is_name(const Text& t_p0) {
    auto first_p1 = rx_char_at(t_p0, Nat(0u));
    return ((t_p0 != Text::lit("")) && (((Text::lit("a") <= first_p1) && (first_p1 <= Text::lit("z"))) || (first_p1 == Text::lit("_")))) && rx_all(t_p0, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>>(prism_rtl::rc([=](Text p0) {
        return once_job([=]() {
            return ({
                auto c_p2 = p0;
                (prism_rtl::finished((((Text::lit("a") <= c_p2) && (c_p2 <= Text::lit("z"))) || rx_is_digit(c_p2)) || (c_p2 == Text::lit("_"))));
            });
        });
    })));
}


/// RxAll: fn Text, (fn Text -> Bool) -> Bool
bool rx_all(const Text& t_p0, const prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>& p_f1) {
    bool this_ = true;
    Cursor c_p2 = front(t_p0);
    while (true) {
        auto&& _m = step(c_p2);
        if (!(prism_rtl::is_some(_m))) break;
        auto&& next_p3 = std::get<1>(prism_rtl::some_of(_m));
        if (!run_to_end(p_f1(rx_slice(t_p0, at(c_p2), at(next_p3))))) {
            this_ = false;
        }
        c_p2 = next_p3;
    }
    return this_;
}


prism_rtl::Turn<bool> RxAll::cycle() const {
    const auto& t_p0 = this->t_p0;
    const auto& p_f1 = this->p_f1;
    return prism_rtl::finished(({
        bool this_ = true;
        Cursor c_p2 = front(t_p0);
        while (true) {
            auto&& _m = step(c_p2);
            if (!(prism_rtl::is_some(_m))) break;
            auto&& next_p3 = std::get<1>(prism_rtl::some_of(_m));
            if (!run_to_end(p_f1(rx_slice(t_p0, at(c_p2), at(next_p3))))) {
                this_ = false;
            }
            c_p2 = next_p3;
        }
        (std::move(this_));
    }));
}


/// `Start RxAll, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_rx_all(Text t_p0, prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)> p_f1) {
    return prism_rtl::make_rc<RxAll>(t_p0, p_f1);
}


/// RxSpanEnd: unbounded fn Text, Nat, (fn Text -> Bool) -> Nat
Nat rx_span_end(const Text& t_p0, const Nat& at_p1, const prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>& p_f2) {
    Nat this_ = at_p1;
    while (run_to_end(p_f2(rx_char_at(t_p0, this_)))) {
        this_ = this_ + Nat(1u);
    }
    return this_;
}


prism_rtl::Turn<Nat> RxSpanEnd::cycle() const {
    const auto& t_p0 = this->t_p0;
    const auto& at_p1 = this->at_p1;
    const auto& p_f2 = this->p_f2;
    Nat this_ = at_p1;
    return call_then(loop_job(std::tuple{std::move(this_)}, ({
        auto p_f2_1 = p_f2;
        auto t_p0_2 = t_p0;
        [=, p_f2_1 = std::move(p_f2_1), t_p0_2 = std::move(t_p0_2)](std::tuple<Nat> _p0) {
        auto this_ = std::get<0>(_p0);
        return run_to_end(p_f2_1(rx_char_at(t_p0_2, this_)))
            ? ({
            this_ = this_ + Nat(1u);
            Expected<std::tuple<Nat>, std::tuple<Nat>>(std::tuple{this_});
        })
            : Expected<std::tuple<Nat>, std::tuple<Nat>>(unexpected(std::tuple{this_}));
    };
    })), [=](std::tuple<Nat> _p0) {
        auto this_ = std::get<0>(_p0);
        return prism_rtl::finished(this_);
    });
}


/// `Start RxSpanEnd, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Nat> start_rx_span_end(Text t_p0, Nat at_p1, prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)> p_f2) {
    return prism_rtl::make_rc<RxSpanEnd>(t_p0, at_p1, p_f2);
}


/// RxHexValue: fn Text -> Nat
Nat rx_hex_value(const Text& t_p0) {
    Nat this_ = Nat(0u);
    Cursor c_p1 = front(t_p0);
    while (true) {
        auto&& _m = step(c_p1);
        if (!(prism_rtl::is_some(_m))) break;
        auto&& next_p2 = std::get<1>(prism_rtl::some_of(_m));
        auto d_p3 = rx_slice(t_p0, at(c_p1), at(next_p2));
        this_ = (this_ * Nat(16u)) + or_(rx_find(Text::lit("0123456789abcdef"), Nat(0u), crate::prelude::lower(d_p3)), Nat(0u));
        c_p1 = next_p2;
    }
    return this_;
}


/// RxCpOf: fn Nat -> RxCp
RxCp rx_cp_of(const Nat& v_p0) {
    return v_p0 < Nat(128u)
        ? RxCp(RxCp::RxLit{rx_char_at(rx_ascii(), v_p0)})
        : RxCp(RxCp::RxNum{v_p0});
}


/// RxWidth: fn Nat -> Nat
Nat rx_width(const Nat& v_p0) {
    return v_p0 < Nat(128u)
        ? Nat(1u)
        : v_p0 < Nat(2048u) ? Nat(2u) : v_p0 < Nat(65536u) ? Nat(3u) : Nat(4u);
}


/// RxPast: fn RxCp, RxCp -> Bool
bool rx_past(const RxCp& rx_cp0, const RxCp& rx_cp1) {
    auto&& _m = std::tuple{rx_cp0, rx_cp1};
    if (prism_rtl::is<RxCp::RxLit>(std::get<0>(_m)) && prism_rtl::is<RxCp::RxLit>(std::get<1>(_m))) {
        auto&& a_p0 = prism_rtl::as<RxCp::RxLit>(std::get<0>(_m)).a0;
        auto&& b_p1 = prism_rtl::as<RxCp::RxLit>(std::get<1>(_m)).a0;
        return a_p0 > b_p1;
    }
    if (prism_rtl::is<RxCp::RxNum>(std::get<0>(_m)) && prism_rtl::is<RxCp::RxNum>(std::get<1>(_m))) {
        auto&& a_p2 = prism_rtl::as<RxCp::RxNum>(std::get<0>(_m)).a0;
        auto&& b_p3 = prism_rtl::as<RxCp::RxNum>(std::get<1>(_m)).a0;
        return a_p2 > b_p3;
    }
    if (prism_rtl::is<RxCp::RxLit>(std::get<0>(_m)) && prism_rtl::is<RxCp::RxNum>(std::get<1>(_m))) {
        auto&& a_p4 = prism_rtl::as<RxCp::RxLit>(std::get<0>(_m)).a0;
        auto&& b_p5 = prism_rtl::as<RxCp::RxNum>(std::get<1>(_m)).a0;
        return len_text(a_p4) != rx_width(b_p5)
            ? len_text(a_p4) > rx_width(b_p5)
            : !rx_in_range(a_p4, Nat(0u), b_p5);
    }
    if (prism_rtl::is<RxCp::RxNum>(std::get<0>(_m)) && prism_rtl::is<RxCp::RxLit>(std::get<1>(_m))) {
        auto&& a_p6 = prism_rtl::as<RxCp::RxNum>(std::get<0>(_m)).a0;
        auto&& b_p7 = prism_rtl::as<RxCp::RxLit>(std::get<1>(_m)).a0;
        return rx_width(a_p6) != len_text(b_p7)
            ? rx_width(a_p6) > len_text(b_p7)
            : !rx_in_range(b_p7, a_p6, Nat(1114111u));
    }
    prism_rtl::unreachable("no arm matched");
}


/// RxInRange: fn Text, Nat, Nat -> Bool
bool rx_in_range(const Text& c_p0, const Nat& lo_p1, const Nat& hi_p2) {
    auto&& _m = crate::prelude::regex(prism_rtl::cat("[\\x{", rx_hex_text(lo_p1), "}-\\x{", rx_hex_text(hi_p2), "}]"));
    if (prism_rtl::is_some(_m)) {
        auto&& r_p3 = prism_rtl::some_of(_m);
        return crate::prelude::find(r_p3, c_p0) != std::optional<Match>{};
    }
    if (prism_rtl::is_none(_m)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// RxHexText: fn Nat -> Text
Text rx_hex_text(const Nat& n_p0) {
    Text this_ = Text::lit("");
    Nat k_p1 = n_p0;
    Nat fuel_p2 = Nat(6u);
    while (true) {
        auto&& _m = fuel_p2.checked_sub(Nat(1u));
        if (!(prism_rtl::is_some(_m))) break;
        auto&& left_p3 = prism_rtl::some_of(_m);
        fuel_p2 = left_p3;
        this_ = prism_rtl::cat(rx_char_at(Text::lit("0123456789abcdef"), or_(mod_(k_p1, Nat(16u)), Nat(0u))), this_);
        k_p1 = or_(div(k_p1, Nat(16u)), Nat(0u));
    }
    return this_;
}


/// ?RegexRefusal: unbounded fn Text, Text, ?Text -> ?RxDiag
std::optional<RxDiag> regex_refusal(const Text& pattern_p0, const Text& flags_p1, const std::optional<Text>& replacement_o2) {
    auto&& _m = rx_flags_refusal(flags_p1);
    if (prism_rtl::is_some(_m)) {
        auto&& d_p3 = prism_rtl::some_of(_m);
        return std::optional(d_p3);
    }
    if (prism_rtl::is_none(_m)) {
        auto st0_p4 = RxState{.s = pattern_p0, .i = Nat(0u), .open = Nat(0u), .groups = Nat(0u), .names = Map<Text, Nat>{}, .err = std::optional<RxDiag>{}};
        auto [m_p5, st_p6] = rx_alternation(st0_p4, rx_find(flags_p1, Nat(0u), Text::lit("i")) != std::optional<Nat>{});
        auto&& _m = prism_rtl::deref(st_p6).err;
        if (prism_rtl::is_some(_m)) {
            auto&& d_p7 = prism_rtl::some_of(_m);
            return std::optional(d_p7);
        }
        if (prism_rtl::is_none(_m)) {
            return prism_rtl::deref(st_p6).i < len_text(pattern_p0)
                ? std::optional(RxDiag{.part = Text::lit("pattern"), .at = prism_rtl::deref(st_p6).i, .message = rx_group_close()})
                : prism_rtl::deref(m_p5).depth > Nat(100u)
                ? std::optional(RxDiag{.part = Text::lit("pattern"), .at = Nat(0u), .message = rx_nesting()})
                : prism_rtl::deref(m_p5).size > Nat(10000u)
                ? std::optional(RxDiag{.part = Text::lit("pattern"), .at = Nat(0u), .message = rx_size()})
                : ({
                __label__ _done;
                prism_rtl::Slot<std::optional<RxDiag>> _v;
                if (prism_rtl::is_none(replacement_o2)) {
                    _v.set(std::optional<RxDiag>{});
                    goto _done;
                }
                if (prism_rtl::is_some(replacement_o2)) {
                    auto&& r_p8 = prism_rtl::some_of(replacement_o2);
                    _v.set(rx_replacement_refusal(r_p8, prism_rtl::deref(st_p6).groups, st_p6->names));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
        }
        prism_rtl::unreachable("no arm matched");
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::optional<RxDiag>> RegexRefusal::cycle() const {
    const auto& pattern_p0 = this->pattern_p0;
    const auto& flags_p1 = this->flags_p1;
    const auto& replacement_o2 = this->replacement_o2;
    return ({
        auto&& _m = rx_flags_refusal(flags_p1);
        prism_rtl::is_some(_m) ? ({
        auto&& d_p3 = prism_rtl::some_of(_m);
        prism_rtl::finished(std::optional(d_p3));
    })
        : prism_rtl::is_none(_m) ? ({
        auto st0_p4 = RxState{.s = pattern_p0, .i = Nat(0u), .open = Nat(0u), .groups = Nat(0u), .names = Map<Text, Nat>{}, .err = std::optional<RxDiag>{}};
        auto replacement_o2_1 = replacement_o2;
        auto flags_p1_2 = flags_p1;
        auto pattern_p0_3 = pattern_p0;
        call_then(start_rx_alternation(st0_p4, rx_find(flags_p1_2, Nat(0u), Text::lit("i")) != std::optional<Nat>{}), [=, replacement_o2_1 = std::move(replacement_o2_1), pattern_p0_3 = std::move(pattern_p0_3)](std::tuple<RxMeasure, RxState> rx_alternation_15542) {
        return ({
            auto [m_p5, st_p6] = rx_alternation_15542;
            ({
            auto&& _m = prism_rtl::deref(st_p6).err;
            prism_rtl::is_some(_m) ? ({
            auto&& d_p7 = prism_rtl::some_of(_m);
            prism_rtl::finished(std::optional(d_p7));
        })
            : prism_rtl::is_none(_m) ? prism_rtl::deref(st_p6).i < len_text(pattern_p0_3)
            ? prism_rtl::finished(std::optional(RxDiag{.part = Text::lit("pattern"), .at = prism_rtl::deref(st_p6).i, .message = rx_group_close()}))
            : prism_rtl::deref(m_p5).depth > Nat(100u)
            ? prism_rtl::finished(std::optional(RxDiag{.part = Text::lit("pattern"), .at = Nat(0u), .message = rx_nesting()}))
            : prism_rtl::deref(m_p5).size > Nat(10000u)
            ? prism_rtl::finished(std::optional(RxDiag{.part = Text::lit("pattern"), .at = Nat(0u), .message = rx_size()}))
            : ({
            prism_rtl::is_none(replacement_o2_1) ? prism_rtl::finished(std::optional<RxDiag>{})
            : prism_rtl::is_some(replacement_o2_1) ? ({
            auto&& r_p8 = prism_rtl::some_of(replacement_o2_1);
            prism_rtl::more(prism_rtl::rc(RxReplacementRefusal(r_p8, prism_rtl::deref(st_p6).groups, st_p6->names)));
        })
            : throw prism_rtl::Panic("no arm matched");
        })
            : throw prism_rtl::Panic("no arm matched");
        });
        });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start RegexRefusal, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<RxDiag>> start_regex_refusal(Text pattern_p0, Text flags_p1, std::optional<Text> replacement_o2) {
    return prism_rtl::make_rc<RegexRefusal>(pattern_p0, flags_p1, replacement_o2);
}


/// ?RxFlagsRefusal: fn Text -> ?RxDiag
std::optional<RxDiag> rx_flags_refusal(const Text& flags_p0) {
    auto&& _d_o6 = ({
        std::tuple<std::optional<RxDiag>, Text> this_ = std::tuple{std::optional<RxDiag>{}, Text::lit("")};
        Cursor c_p1 = front(flags_p0);
        std::optional<RxDiag> d_o2 = std::optional<RxDiag>{};
        Text seen_p3 = Text::lit("");
        while (true) {
            auto&& _m = step(c_p1);
            if (!(prism_rtl::is_some(_m))) break;
            auto&& next_p4 = std::get<1>(prism_rtl::some_of(_m));
            if (!(d_o2 == std::optional<RxDiag>{})) {
                break;
            }
            auto ch_p5 = rx_slice(flags_p0, at(c_p1), at(next_p4));
            if (!(((ch_p5 == Text::lit("i")) || (ch_p5 == Text::lit("m"))) || (ch_p5 == Text::lit("s")))) {
                d_o2 = std::optional(RxDiag{.part = Text::lit("flags"), .at = at(c_p1), .message = rx_unknown_flag()});
            } else if (rx_in(seen_p3, ch_p5)) {
                d_o2 = std::optional(RxDiag{.part = Text::lit("flags"), .at = at(c_p1), .message = rx_flag_twice()});
            } else  {
                seen_p3 = prism_rtl::cat(seen_p3, ch_p5);
            }
            c_p1 = next_p4;
        }
        this_ = std::tuple{d_o2, seen_p3};
        (std::move(this_));
    });
    auto&& d_o6 = std::get<0>(_d_o6);
    return d_o6;
}


/// RxAlternation: unbounded fn RxState, Bool -> ((RxMeasure, RxState))
std::tuple<RxMeasure, RxState> rx_alternation(const RxState& st0_p0, const bool& fi0_p1) {
    auto [m0_p2, fi1_p3, st1_p4] = rx_sequence(st0_p0, fi0_p1);
    std::tuple<RxMeasure, RxState> this_ = std::tuple{m0_p2, st1_p4};
    RxMeasure m_p5 = m0_p2;
    bool fi_p6 = fi1_p3;
    RxState st_p7 = st1_p4;
    while ((!rx_bad(st_p7)) && (rx_peek(st_p7) == Text::lit("|"))) {
        auto [m2_p8, fi2_p9, st2_pa] = rx_sequence(rx_go(st_p7, st_p7.i + Nat(1u)), fi_p6);
        m_p5 = rx_then(m_p5, m2_p8);
        fi_p6 = fi2_p9;
        st_p7 = st2_pa;
    }
    this_ = std::tuple{m_p5, st_p7};
    return this_;
}


prism_rtl::Turn<std::tuple<RxMeasure, RxState>> RxAlternation::cycle() const {
    const auto& st0_p0 = this->st0_p0;
    const auto& fi0_p1 = this->fi0_p1;
    auto fi0_p1_1 = prism_rtl::deref(fi0_p1);
    auto st0_p0_2 = st0_p0;
    return call_then(start_rx_sequence(st0_p0_2, std::move(fi0_p1_1)), [=](std::tuple<RxMeasure, bool, RxState> rx_sequence_17135) {
        return ({
            auto [m0_p2, fi1_p3, st1_p4] = rx_sequence_17135;
            std::tuple<RxMeasure, RxState> this_ = std::tuple{m0_p2, st1_p4};
            RxMeasure m_p5 = m0_p2;
            bool fi_p6 = fi1_p3;
            RxState st_p7 = st1_p4;
            call_then(loop_job(std::tuple{std::move(this_), std::move(fi_p6), std::move(m_p5), std::move(st_p7)}, [=](std::tuple<std::tuple<RxMeasure, RxState>, bool, RxMeasure, RxState> _p0) {
            auto this_ = std::get<0>(_p0);
            auto fi_p6 = std::get<1>(_p0);
            auto m_p5 = std::get<2>(_p0);
            auto st_p7 = std::get<3>(_p0);
            return (!rx_bad(st_p7)) && (rx_peek(st_p7) == Text::lit("|"))
                ? ({
                auto [m2_p8, fi2_p9, st2_pa] = rx_sequence(rx_go(st_p7, prism_rtl::deref(st_p7).i + Nat(1u)), fi_p6);
                m_p5 = rx_then(m_p5, m2_p8);
                fi_p6 = fi2_p9;
                st_p7 = st2_pa;
                Expected<std::tuple<std::tuple<RxMeasure, RxState>, bool, RxMeasure, RxState>, std::tuple<std::tuple<RxMeasure, RxState>, bool, RxMeasure, RxState>>(std::tuple{this_, fi_p6, m_p5, st_p7});
            })
                : Expected<std::tuple<std::tuple<RxMeasure, RxState>, bool, RxMeasure, RxState>, std::tuple<std::tuple<RxMeasure, RxState>, bool, RxMeasure, RxState>>(unexpected(std::tuple{this_, fi_p6, m_p5, st_p7}));
        }), [=](std::tuple<std::tuple<RxMeasure, RxState>, bool, RxMeasure, RxState> _p0) {
            auto this_ = std::get<0>(_p0);
            auto fi_p6 = std::get<1>(_p0);
            auto m_p5 = std::get<2>(_p0);
            auto st_p7 = std::get<3>(_p0);
            return ({
                this_ = std::tuple{m_p5, st_p7};
                (prism_rtl::finished(this_));
            });
        });
        });
    });
}


/// `Start RxAlternation, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<RxMeasure, RxState>> start_rx_alternation(RxState st0_p0, bool fi0_p1) {
    return prism_rtl::make_rc<RxAlternation>(st0_p0, fi0_p1);
}


/// RxSequence: unbounded fn RxState, Bool -> ((RxMeasure, Bool, RxState))
std::tuple<RxMeasure, bool, RxState> rx_sequence(const RxState& st0_p0, const bool& fi0_p1) {
    std::tuple<RxMeasure, bool, RxState> this_ = std::tuple{rx_none(), fi0_p1, st0_p0};
    RxMeasure total_p2 = rx_none();
    bool fi_p3 = fi0_p1;
    RxState st_p4 = st0_p0;
    RxLast last_p5 = RxLast(RxLast::RxLastNothing{});
    RxMeasure last_m_p6 = rx_none();
    bool going_p7 = true;
    while (std::move(going_p7) && (!rx_bad(st_p4))) {
        auto c_p8 = rx_peek(st_p4);
        auto at_p9 = st_p4.i;
        if (((c_p8 == Text::lit("")) || (c_p8 == Text::lit("|"))) || (c_p8 == Text::lit(")"))) {
            going_p7 = false;
        } else if ((((c_p8 == Text::lit("*")) || (c_p8 == Text::lit("+"))) || (c_p8 == Text::lit("?"))) || (c_p8 == Text::lit("{"))) {
            auto [lo_pa, hi_ob, st2_pc] = c_p8 == Text::lit("{")
                ? rx_count(st_p4)
                : rx_simple_repetition(st_p4, c_p8);
            st_p4 = st2_pc;
            if (!rx_bad(st_p4)) {
                st_p4 = ({
                    __label__ _done;
                    prism_rtl::Slot<RxState> _v;
                    if (prism_rtl::is<RxLast::RxLastNothing>(last_p5)) {
                        _v.set(rx_fail(st_p4, at_p9, rx_nothing_to_repeat()));
                        goto _done;
                    }
                    if (prism_rtl::is<RxLast::RxLastFlagGroup>(last_p5)) {
                        _v.set(rx_fail(st_p4, at_p9, rx_nothing_to_repeat()));
                        goto _done;
                    }
                    if (prism_rtl::is<RxLast::RxLastRepetition>(last_p5)) {
                        _v.set(rx_fail(st_p4, at_p9, rx_repeat_repeat()));
                        goto _done;
                    }
                    if (prism_rtl::is<RxLast::RxLastAssertion>(last_p5)) {
                        _v.set(rx_fail(st_p4, at_p9, rx_repeat_assertion()));
                        goto _done;
                    }
                    if (prism_rtl::is<RxLast::RxLastAtom>(last_p5)) {
                        _v.set(st_p4);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
            }
            if (!rx_bad(st_p4)) {
                auto counted_pd = c_p8 == Text::lit("{");
                auto factor_pe = std::move(counted_pd)
                    ? crate::prelude::max(or_(hi_ob, lo_pa), Nat(1u))
                    : Nat(1u);
                auto product_pf = factor_pe * crate::prelude::max(last_m_p6.product, Nat(1u));
                if (std::move(counted_pd) && (product_pf > Nat(1000u))) {
                    st_p4 = rx_fail(st_p4, at_p9, rx_product());
                } else  {
                    if (rx_peek(st_p4) == Text::lit("?")) {
                        st_p4 = rx_go(st_p4, st_p4.i + Nat(1u));
                    }
                    auto m_pg = RxMeasure{.depth = last_m_p6.depth + Nat(1u), .size = last_m_p6.size * factor_pe, .product = product_pf};
                    total_p2 = RxMeasure{.depth = crate::prelude::max(total_p2.depth, prism_rtl::deref(m_pg).depth), .size = or_(total_p2.size.checked_sub(last_m_p6.size), Nat(0u)) + prism_rtl::deref(m_pg).size, .product = crate::prelude::max(total_p2.product, prism_rtl::deref(m_pg).product)};
                    last_p5 = RxLast(RxLast::RxLastRepetition{});
                    last_m_p6 = m_pg;
                }
            }
        } else  {
            auto [kind_ph, m_pi, fi2_pj, st2_pk] = rx_piece(st_p4, fi_p3);
            st_p4 = st2_pk;
            fi_p3 = fi2_pj;
            if (kind_ph != RxLast(RxLast::RxLastFlagGroup{})) {
                total_p2 = rx_then(total_p2, m_pi);
            }
            last_p5 = kind_ph;
            last_m_p6 = m_pi;
        }
    }
    this_ = std::tuple{total_p2, std::move(fi_p3), st_p4};
    return this_;
}


prism_rtl::Turn<std::tuple<RxMeasure, bool, RxState>> RxSequence::cycle() const {
    const auto& st0_p0 = this->st0_p0;
    const auto& fi0_p1 = this->fi0_p1;
    std::tuple<RxMeasure, bool, RxState> this_ = std::tuple{rx_none(), prism_rtl::deref(fi0_p1), st0_p0};
    RxMeasure total_p2 = rx_none();
    bool fi_p3 = prism_rtl::deref(fi0_p1);
    RxState st_p4 = st0_p0;
    RxLast last_p5 = RxLast(RxLast::RxLastNothing{});
    RxMeasure last_m_p6 = rx_none();
    bool going_p7 = true;
    return call_then(loop_job(std::tuple{std::move(this_), std::move(fi_p3), std::move(going_p7), std::move(last_p5), std::move(last_m_p6), std::move(st_p4), std::move(total_p2)}, [=](std::tuple<std::tuple<RxMeasure, bool, RxState>, bool, bool, RxLast, RxMeasure, RxState, RxMeasure> _p0) {
        auto this_ = std::get<0>(_p0);
        auto fi_p3 = std::get<1>(_p0);
        auto going_p7 = std::get<2>(_p0);
        auto last_p5 = std::get<3>(_p0);
        auto last_m_p6 = std::get<4>(_p0);
        auto st_p4 = std::get<5>(_p0);
        auto total_p2 = std::get<6>(_p0);
        return going_p7 && (!rx_bad(st_p4))
            ? ({
            auto c_p8 = rx_peek(st_p4);
            auto at_p9 = prism_rtl::deref(st_p4).i;
            if (((c_p8 == Text::lit("")) || (c_p8 == Text::lit("|"))) || (c_p8 == Text::lit(")"))) {
                going_p7 = false;
            } else if ((((c_p8 == Text::lit("*")) || (c_p8 == Text::lit("+"))) || (c_p8 == Text::lit("?"))) || (c_p8 == Text::lit("{"))) {
                auto [lo_pa, hi_ob, st2_pc] = c_p8 == Text::lit("{")
                    ? rx_count(st_p4)
                    : rx_simple_repetition(st_p4, c_p8);
                st_p4 = st2_pc;
                if (!rx_bad(st_p4)) {
                    st_p4 = ({
                        __label__ _done;
                        prism_rtl::Slot<RxState> _v;
                        if (prism_rtl::is<RxLast::RxLastNothing>(last_p5)) {
                            _v.set(rx_fail(st_p4, at_p9, rx_nothing_to_repeat()));
                            goto _done;
                        }
                        if (prism_rtl::is<RxLast::RxLastFlagGroup>(last_p5)) {
                            _v.set(rx_fail(st_p4, at_p9, rx_nothing_to_repeat()));
                            goto _done;
                        }
                        if (prism_rtl::is<RxLast::RxLastRepetition>(last_p5)) {
                            _v.set(rx_fail(st_p4, at_p9, rx_repeat_repeat()));
                            goto _done;
                        }
                        if (prism_rtl::is<RxLast::RxLastAssertion>(last_p5)) {
                            _v.set(rx_fail(st_p4, at_p9, rx_repeat_assertion()));
                            goto _done;
                        }
                        if (prism_rtl::is<RxLast::RxLastAtom>(last_p5)) {
                            _v.set(st_p4);
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                }
                if (!rx_bad(st_p4)) {
                    auto counted_pd = c_p8 == Text::lit("{");
                    auto factor_pe = std::move(counted_pd)
                        ? crate::prelude::max(or_(hi_ob, lo_pa), Nat(1u))
                        : Nat(1u);
                    auto product_pf = factor_pe * crate::prelude::max(prism_rtl::deref(last_m_p6).product, Nat(1u));
                    if (std::move(counted_pd) && (product_pf > Nat(1000u))) {
                        st_p4 = rx_fail(st_p4, at_p9, rx_product());
                    } else  {
                        if (rx_peek(st_p4) == Text::lit("?")) {
                            st_p4 = rx_go(st_p4, prism_rtl::deref(st_p4).i + Nat(1u));
                        }
                        auto m_pg = RxMeasure{.depth = prism_rtl::deref(last_m_p6).depth + Nat(1u), .size = prism_rtl::deref(last_m_p6).size * factor_pe, .product = product_pf};
                        total_p2 = RxMeasure{.depth = crate::prelude::max(prism_rtl::deref(total_p2).depth, prism_rtl::deref(m_pg).depth), .size = or_(prism_rtl::deref(total_p2).size.checked_sub(prism_rtl::deref(last_m_p6).size), Nat(0u)) + prism_rtl::deref(m_pg).size, .product = crate::prelude::max(prism_rtl::deref(total_p2).product, prism_rtl::deref(m_pg).product)};
                        last_p5 = RxLast(RxLast::RxLastRepetition{});
                        last_m_p6 = m_pg;
                    }
                }
            } else  {
                auto [kind_ph, m_pi, fi2_pj, st2_pk] = rx_piece(st_p4, fi_p3);
                st_p4 = st2_pk;
                fi_p3 = fi2_pj;
                if (kind_ph != RxLast(RxLast::RxLastFlagGroup{})) {
                    total_p2 = rx_then(total_p2, m_pi);
                }
                last_p5 = kind_ph;
                last_m_p6 = m_pi;
            }
            Expected<std::tuple<std::tuple<RxMeasure, bool, RxState>, bool, bool, RxLast, RxMeasure, RxState, RxMeasure>, std::tuple<std::tuple<RxMeasure, bool, RxState>, bool, bool, RxLast, RxMeasure, RxState, RxMeasure>>(std::tuple{this_, fi_p3, going_p7, last_p5, last_m_p6, st_p4, total_p2});
        })
            : Expected<std::tuple<std::tuple<RxMeasure, bool, RxState>, bool, bool, RxLast, RxMeasure, RxState, RxMeasure>, std::tuple<std::tuple<RxMeasure, bool, RxState>, bool, bool, RxLast, RxMeasure, RxState, RxMeasure>>(unexpected(std::tuple{this_, fi_p3, going_p7, last_p5, last_m_p6, st_p4, total_p2}));
    }), [=](std::tuple<std::tuple<RxMeasure, bool, RxState>, bool, bool, RxLast, RxMeasure, RxState, RxMeasure> _p0) {
        auto this_ = std::get<0>(_p0);
        auto fi_p3 = std::get<1>(_p0);
        auto going_p7 = std::get<2>(_p0);
        auto last_p5 = std::get<3>(_p0);
        auto last_m_p6 = std::get<4>(_p0);
        auto st_p4 = std::get<5>(_p0);
        auto total_p2 = std::get<6>(_p0);
        return ({
            this_ = std::tuple{total_p2, fi_p3, st_p4};
            (prism_rtl::finished(this_));
        });
    });
}


/// `Start RxSequence, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<RxMeasure, bool, RxState>> start_rx_sequence(RxState st0_p0, bool fi0_p1) {
    return prism_rtl::make_rc<RxSequence>(st0_p0, fi0_p1);
}


/// RxSimpleRepetition: fn RxState, Text -> ((Nat, ?Nat, RxState))
std::tuple<Nat, std::optional<Nat>, RxState> rx_simple_repetition(const RxState& st_p0, const Text& c_p1) {
    auto st2_p2 = rx_go(st_p0, st_p0.i + Nat(1u));
    return c_p1 == Text::lit("*")
        ? std::tuple{Nat(0u), std::optional<Nat>{}, st2_p2}
        : c_p1 == Text::lit("+")
        ? std::tuple{Nat(1u), std::optional<Nat>{}, st2_p2}
        : std::tuple{Nat(0u), std::optional(Nat(1u)), st2_p2};
}


/// RxCount: unbounded fn RxState -> ((Nat, ?Nat, RxState))
std::tuple<Nat, std::optional<Nat>, RxState> rx_count(const RxState& st_p0) {
    auto at_p1 = st_p0.i;
    auto s_p2 = st_p0.s;
    auto j1_p3 = rx_span_end(s_p2, at_p1 + Nat(1u), ({
        auto f = prism_rtl::rc(rx_is_digit);
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>>(prism_rtl::rc([=, f = std::move(f)](Text a0) {
        return ({
            auto f_1 = f;
            once_job([=, f_1 = std::move(f_1)]() { return prism_rtl::finished(f_1(a0)); });
        });
    })));
    }));
    auto first_p4 = rx_slice(s_p2, at_p1 + Nat(1u), j1_p3);
    auto c_p5 = rx_char_at(s_p2, j1_p3);
    return first_p4 == Text::lit("")
        ? std::tuple{Nat(0u), std::optional<Nat>{}, rx_fail(st_p0, at_p1, rx_brace())}
        : c_p5 == Text::lit("}")
        ? rx_count_checked(st_p0, at_p1, first_p4, std::optional<Text>{}, j1_p3 + Nat(1u))
        : c_p5 == Text::lit(",")
        ? ({
        auto j2_p6 = rx_span_end(s_p2, j1_p3 + Nat(1u), ({
            auto f = prism_rtl::rc(rx_is_digit);
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>>(prism_rtl::rc([=, f = std::move(f)](Text a0) {
            return ({
                auto f_1 = f;
                once_job([=, f_1 = std::move(f_1)]() { return prism_rtl::finished(f_1(a0)); });
            });
        })));
        }));
        rx_char_at(s_p2, j2_p6) != Text::lit("}")
        ? std::tuple{Nat(0u), std::optional<Nat>{}, rx_fail(st_p0, at_p1, rx_brace())}
        : rx_count_checked(st_p0, at_p1, first_p4, std::optional(rx_slice(s_p2, j1_p3 + Nat(1u), j2_p6)), j2_p6 + Nat(1u));
    })
        : std::tuple{Nat(0u), std::optional<Nat>{}, rx_fail(st_p0, at_p1, rx_brace())};
}


/// RxCountChecked: fn RxState, Nat, Text, ?Text, Nat -> ((Nat, ?Nat, RxState))
std::tuple<Nat, std::optional<Nat>, RxState> rx_count_checked(const RxState& st_p0, const Nat& at_p1, const Text& first_p2, const std::optional<Text>& second_o3, const Nat& next_p4) {
    auto st1_p5 = rx_go(st_p0, next_p4);
    auto lo_p6 = or_(parse_nat_opt(first_p2), Nat(0u));
    auto hi_o7 = ({
        __label__ _done;
        prism_rtl::Slot<std::optional<Nat>> _v;
        if (prism_rtl::is_none(second_o3)) {
            _v.set(std::optional(lo_p6));
            goto _done;
        }
        if (prism_rtl::is_some(second_o3)) {
            auto&& m20974_1 = prism_rtl::some_of(second_o3);
            if (m20974_1 == Text::lit("")) {
                _v.set(std::optional<Nat>{});
                goto _done;
            }
        }
        if (prism_rtl::is_some(second_o3)) {
            auto&& d_p9 = prism_rtl::some_of(second_o3);
            _v.set(parse_nat_opt(d_p9));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto zero_p8 = rx_leading_zero(first_p2) || rx_leading_zero(or_(second_o3, Text::lit("")));
    return std::move(zero_p8)
        ? std::tuple{Nat(0u), std::optional<Nat>{}, rx_fail(st1_p5, at_p1, rx_count_zero())}
        : (lo_p6 > Nat(1000u)) || (or_(hi_o7, Nat(0u)) > Nat(1000u))
        ? std::tuple{Nat(0u), std::optional<Nat>{}, rx_fail(st1_p5, at_p1, rx_count_bound())}
        : lo_p6 > or_(hi_o7, lo_p6)
        ? std::tuple{Nat(0u), std::optional<Nat>{}, rx_fail(st1_p5, at_p1, rx_count_order())}
        : std::tuple{lo_p6, hi_o7, st1_p5};
}


/// RxLeadingZero: fn Text -> Bool
bool rx_leading_zero(const Text& d_p0) {
    return (len_text(d_p0) > Nat(1u)) && (rx_char_at(d_p0, Nat(0u)) == Text::lit("0"));
}


/// RxPiece: unbounded fn RxState, Bool -> ((RxLast, RxMeasure, Bool, RxState))
std::tuple<RxLast, RxMeasure, bool, RxState> rx_piece(const RxState& st_p0, const bool& fi_p1) {
    auto at_p2 = st_p0.i;
    auto c_p3 = rx_peek(st_p0);
    {
        auto&& m21753_0 = c_p3;
        if (m21753_0 == Text::lit("(")) {
            return rx_group(st_p0, fi_p1);
        }
    }
    {
        auto&& m21753_1 = c_p3;
        if (m21753_1 == Text::lit("[")) {
            return std::tuple{RxLast(RxLast::RxLastAtom{}), rx_atom(), fi_p1, rx_class(st_p0, fi_p1)};
        }
    }
    {
        auto&& m21753_2 = c_p3;
        if (m21753_2 == Text::lit("]")) {
            return std::tuple{RxLast(RxLast::RxLastAtom{}), rx_atom(), fi_p1, rx_fail(st_p0, at_p2, rx_stray_bracket())};
        }
    }
    {
        auto&& m21753_3 = c_p3;
        if (m21753_3 == Text::lit("}")) {
            return std::tuple{RxLast(RxLast::RxLastAtom{}), rx_atom(), fi_p1, rx_fail(st_p0, at_p2, rx_stray_brace())};
        }
    }
    {
        auto&& m21753_4 = c_p3;
        if (m21753_4 == Text::lit("^")) {
            return std::tuple{RxLast(RxLast::RxLastAssertion{}), rx_atom(), fi_p1, rx_go(st_p0, at_p2 + Nat(1u))};
        }
    }
    {
        auto&& m21753_5 = c_p3;
        if (m21753_5 == Text::lit("$")) {
            return std::tuple{RxLast(RxLast::RxLastAssertion{}), rx_atom(), fi_p1, rx_go(st_p0, at_p2 + Nat(1u))};
        }
    }
    {
        auto&& m21753_6 = c_p3;
        if (m21753_6 == Text::lit("\\")) {
            return rx_escape(st_p0, fi_p1);
        }
    }
    {
        return std::tuple{RxLast(RxLast::RxLastAtom{}), rx_atom(), fi_p1, rx_go(st_p0, at_p2 + len_text(c_p3))};
    }
}


/// RxEscape: unbounded fn RxState, Bool -> ((RxLast, RxMeasure, Bool, RxState))
std::tuple<RxLast, RxMeasure, bool, RxState> rx_escape(const RxState& st_p0, const bool& fi_p1) {
    auto at_p2 = st_p0.i;
    auto s_p3 = st_p0.s;
    auto c_p4 = rx_char_at(s_p3, at_p2 + Nat(1u));
    auto atom_f5 = ({
        auto fi_p1_1 = fi_p1;
        static_cast<Fn<std::tuple<RxLast, RxMeasure, bool, RxState>(const RxState&)>>(prism_rtl::rc([=, fi_p1_1 = std::move(fi_p1_1)](const RxState& next_p6) { return std::tuple{RxLast(RxLast::RxLastAtom{}), rx_atom(), fi_p1_1, next_p6}; }));
    });
    return c_p4 == Text::lit("")
        ? atom_f5(rx_fail(st_p0, at_p2, rx_trailing_backslash()))
        : (c_p4 == Text::lit("<")) || (c_p4 == Text::lit(">"))
        ? atom_f5(rx_fail(st_p0, at_p2, rx_angle()))
        : rx_in(rx_punctuation(), c_p4)
        ? atom_f5(rx_go(st_p0, at_p2 + Nat(2u)))
        : rx_in(Text::lit("tnrfva"), c_p4)
        ? atom_f5(rx_go(st_p0, at_p2 + Nat(2u)))
        : c_p4 == Text::lit("x")
        ? ({
        auto&& _st2_p7 = rx_hex(st_p0, at_p2);
        auto&& st2_p7 = std::get<1>(_st2_p7);
        atom_f5(st2_p7);
    })
        : rx_in(Text::lit("dwsDWS"), c_p4)
        ? atom_f5(rx_go(st_p0, at_p2 + Nat(2u)))
        : (c_p4 == Text::lit("p")) || (c_p4 == Text::lit("P"))
        ? ({
        auto&& _st2_p8 = rx_property(st_p0, at_p2);
        auto&& st2_p8 = std::get<1>(_st2_p8);
        atom_f5(st2_p8);
    })
        : rx_in(Text::lit("AzbB"), c_p4)
        ? (c_p4 == Text::lit("b")) && (rx_char_at(s_p3, at_p2 + Nat(2u)) == Text::lit("{"))
        ? atom_f5(rx_fail(st_p0, at_p2, rx_word_braces()))
        : std::tuple{RxLast(RxLast::RxLastAssertion{}), rx_atom(), fi_p1, rx_go(st_p0, at_p2 + Nat(2u))}
        : rx_in(Text::lit("123456789"), c_p4)
        ? atom_f5(rx_fail(st_p0, at_p2, rx_backreference()))
        : c_p4 == Text::lit("0")
        ? atom_f5(rx_fail(st_p0, at_p2, rx_octal()))
        : (c_p4 == Text::lit("Q")) || (c_p4 == Text::lit("E"))
        ? atom_f5(rx_fail(st_p0, at_p2, rx_quote()))
        : c_p4 == Text::lit("C")
        ? atom_f5(rx_fail(st_p0, at_p2, rx_one_byte()))
        : atom_f5(rx_fail(st_p0, at_p2, rx_unknown_escape()));
}


/// RxHex: unbounded fn RxState, Nat -> ((Nat, RxState))
std::tuple<Nat, RxState> rx_hex(const RxState& st_p0, const Nat& at_p1) {
    auto s_p2 = st_p0.s;
    auto x_p3 = at_p1 + Nat(1u);
    return rx_char_at(s_p2, x_p3 + Nat(1u)) == Text::lit("{")
        ? ({
        auto start_p4 = x_p3 + Nat(2u);
        auto j_p5 = rx_span_end(s_p2, start_p4, ({
            auto f = prism_rtl::rc(rx_is_hex);
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>>(prism_rtl::rc([=, f = std::move(f)](Text a0) {
            return ({
                auto f_1 = f;
                once_job([=, f_1 = std::move(f_1)]() { return prism_rtl::finished(f_1(a0)); });
            });
        })));
        }));
        auto digits_p6 = rx_slice(s_p2, start_p4, j_p5);
        ((rx_char_at(s_p2, j_p5) != Text::lit("}")) || (digits_p6 == Text::lit(""))) || (len_text(digits_p6) > Nat(6u))
        ? std::tuple{Nat(0u), rx_fail(st_p0, at_p1, rx_hex_braces())}
        : rx_hex_checked(rx_go(st_p0, j_p5 + Nat(1u)), at_p1, rx_hex_value(digits_p6));
    })
        : ({
        auto a_p7 = rx_char_at(s_p2, x_p3 + Nat(1u));
        auto b_p8 = rx_char_at(s_p2, x_p3 + Nat(2u));
        rx_is_hex(a_p7) && rx_is_hex(b_p8)
        ? rx_hex_checked(rx_go(st_p0, x_p3 + Nat(3u)), at_p1, rx_hex_value(prism_rtl::cat(a_p7, b_p8)))
        : std::tuple{Nat(0u), rx_fail(st_p0, at_p1, rx_hex_two())};
    });
}


/// RxHexChecked: fn RxState, Nat, Nat -> ((Nat, RxState))
std::tuple<Nat, RxState> rx_hex_checked(const RxState& st_p0, const Nat& at_p1, const Nat& v_p2) {
    return ((Nat(55296u) <= v_p2) && (v_p2 <= Nat(57343u))) || (v_p2 > Nat(1114111u))
        ? std::tuple{v_p2, rx_fail(st_p0, at_p1, rx_hex_no_char())}
        : std::tuple{v_p2, st_p0};
}


/// RxProperty: unbounded fn RxState, Nat -> ((Text, RxState))
std::tuple<Text, RxState> rx_property(const RxState& st_p0, const Nat& at_p1) {
    auto s_p2 = st_p0.s;
    auto c_p3 = rx_char_at(s_p2, at_p1 + Nat(2u));
    return c_p3 == Text::lit("{")
        ? ({
        auto start_p4 = at_p1 + Nat(3u);
        ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Text, RxState>> _v;
        auto&& _m = rx_find(s_p2, start_p4, Text::lit("}"));
        if (prism_rtl::is_none(_m)) {
            _v.set(std::tuple{Text::lit(""), rx_fail(st_p0, at_p1, rx_property_open())});
            goto _done;
        }
        if (prism_rtl::is_some(_m)) {
            auto&& close_p5 = prism_rtl::some_of(_m);
            _v.set(({
                auto name_p6 = rx_slice(s_p2, start_p4, close_p5);
                rx_char_at(name_p6, Nat(0u)) == Text::lit("^")
                ? std::tuple{name_p6, rx_fail(st_p0, at_p1, rx_property_negated())}
                : rx_property_named(rx_go(st_p0, close_p5 + Nat(1u)), at_p1, name_p6);
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    })
        : rx_is_letter(c_p3)
        ? rx_property_named(rx_go(st_p0, at_p1 + Nat(3u)), at_p1, c_p3)
        : std::tuple{Text::lit(""), rx_fail(st_p0, at_p1, rx_property_name())};
}


/// RxPropertyNamed: fn RxState, Nat, Text -> ((Text, RxState))
std::tuple<Text, RxState> rx_property_named(const RxState& st_p0, const Nat& at_p1, const Text& name_p2) {
    return (((name_p2 == Text::lit("C")) || (name_p2 == Text::lit("Cn"))) || (name_p2 == Text::lit("Cs"))) || (name_p2 == Text::lit("LC"))
        ? std::tuple{name_p2, rx_fail(st_p0, at_p1, rx_property_refused())}
        : crate::prelude::get(rx_properties(), name_p2) != std::optional<bool>{}
        ? std::tuple{name_p2, st_p0}
        : std::tuple{name_p2, rx_fail(st_p0, at_p1, rx_property_unknown())};
}


/// RxClass: unbounded fn RxState, Bool -> RxState
RxState rx_class(const RxState& st0_p0, const bool& fi_p1) {
    auto open_p2 = st0_p0.i;
    auto start_p3 = rx_char_at(st0_p0.s, open_p2 + Nat(1u)) == Text::lit("^")
        ? open_p2 + Nat(2u)
        : open_p2 + Nat(1u);
    RxState this_ = rx_go(st0_p0, start_p3);
    bool first_p4 = true;
    bool done_p5 = false;
    while (!std::move(done_p5)) {
        auto [closed_p6, st2_p7] = rx_class_item(this_, open_p2, start_p3, first_p4, fi_p1);
        this_ = st2_p7;
        first_p4 = false;
        done_p5 = closed_p6 || rx_bad(st2_p7);
    }
    return this_;
}


/// RxAtSetOperation: fn RxState -> Bool
bool rx_at_set_operation(const RxState& st_p0) {
    auto c_p1 = rx_peek(st_p0);
    return (((c_p1 == Text::lit("&")) || (c_p1 == Text::lit("~"))) || (c_p1 == Text::lit("-"))) && (rx_char_at(st_p0.s, st_p0.i + Nat(1u)) == c_p1);
}


/// RxClassItem: unbounded fn RxState, Nat, Nat, Bool, Bool -> ((Bool, RxState))
std::tuple<bool, RxState> rx_class_item(const RxState& st_p0, const Nat& open_p1, const Nat& start_p2, const bool& first_p3, const bool& fi_p4) {
    auto at_p5 = st_p0.i;
    auto c_p6 = rx_peek(st_p0);
    auto next_p7 = rx_char_at(st_p0.s, at_p5 + Nat(1u));
    return c_p6 == Text::lit("")
        ? std::tuple{true, rx_fail(st_p0, open_p1, rx_class_open())}
        : (c_p6 == Text::lit("]")) && first_p3
        ? std::tuple{true, rx_fail(st_p0, at_p5, rx_class_first_bracket())}
        : c_p6 == Text::lit("]")
        ? std::tuple{true, rx_go(st_p0, at_p5 + Nat(1u))}
        : rx_at_set_operation(st_p0)
        ? std::tuple{true, rx_fail(st_p0, at_p5, rx_class_set_operation())}
        : c_p6 == Text::lit("[")
        ? std::tuple{false, rx_ascii_item(st_p0, fi_p4)}
        : (c_p6 == Text::lit("-")) && (next_p7 == Text::lit(""))
        ? std::tuple{true, rx_fail(st_p0, open_p1, rx_class_open())}
        : (c_p6 == Text::lit("-")) && ((at_p5 == start_p2) || (next_p7 == Text::lit("]")))
        ? std::tuple{false, rx_go(st_p0, at_p5 + Nat(1u))}
        : c_p6 == Text::lit("-")
        ? std::tuple{true, rx_fail(st_p0, at_p5, rx_class_dash())}
        : std::tuple{false, rx_class_range(st_p0, open_p1, fi_p4)};
}


/// RxClassRange: unbounded fn RxState, Nat, Bool -> RxState
RxState rx_class_range(const RxState& st_p0, const Nat& open_p1, const bool& fi_p2) {
    auto at_p3 = st_p0.i;
    auto [lo_o4, st1_p5] = rx_class_atom(st_p0, fi_p2);
    if (prism_rtl::is_none(lo_o4)) {
        return st1_p5;
    }
    if (prism_rtl::is_some(lo_o4)) {
        auto&& lo_p6 = prism_rtl::some_of(lo_o4);
        auto s_p7 = st1_p5->s;
        auto ranged_p8 = (rx_peek(st1_p5) == Text::lit("-")) && (rx_char_at(s_p7, prism_rtl::deref(st1_p5).i + Nat(1u)) != Text::lit("]"));
        return rx_bad(st1_p5) || (!std::move(ranged_p8))
            ? st1_p5
            : rx_at_set_operation(st1_p5)
            ? rx_fail(st1_p5, prism_rtl::deref(st1_p5).i, rx_class_set_operation())
            : ({
            auto right_p9 = prism_rtl::deref(st1_p5).i + Nat(1u);
            auto st2_pa = rx_go(st1_p5, right_p9);
            auto rc_pb = rx_peek(st2_pa);
            rc_pb == Text::lit("")
            ? rx_fail(st2_pa, open_p1, rx_class_open())
            : rc_pb == Text::lit("[")
            ? rx_fail(st2_pa, right_p9, rx_class_nested())
            : rx_at_set_operation(st2_pa)
            ? rx_fail(st2_pa, right_p9, rx_class_set_operation())
            : ({
            auto [hi_oc, st3_pd] = rx_class_atom(st2_pa, fi_p2);
            rx_bad(st3_pd)
            ? st3_pd
            : ({
            __label__ _done;
            prism_rtl::Slot<RxState> _v;
            if (prism_rtl::is_none(hi_oc)) {
                _v.set(rx_fail(st3_pd, right_p9, rx_class_range_set()));
                goto _done;
            }
            if (prism_rtl::is_some(hi_oc)) {
                auto&& hi_pe = prism_rtl::some_of(hi_oc);
                _v.set(rx_past(lo_p6, hi_pe) ? rx_fail(st3_pd, at_p3, rx_class_order()) : st3_pd);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        });
        });
    }
    prism_rtl::unreachable("no arm matched");
}


/// RxClassAtom: unbounded fn RxState, Bool -> ((?RxCp, RxState))
std::tuple<std::optional<RxCp>, RxState> rx_class_atom(const RxState& st_p0, const bool& fi_p1) {
    auto at_p2 = st_p0.i;
    auto s_p3 = st_p0.s;
    auto c_p4 = rx_peek(st_p0);
    return c_p4 != Text::lit("\\")
        ? std::tuple{std::optional(RxCp(RxCp::RxLit{c_p4})), rx_go(st_p0, at_p2 + len_text(c_p4))}
        : ({
        auto e_p5 = rx_char_at(s_p3, at_p2 + Nat(1u));
        e_p5 == Text::lit("")
        ? std::tuple{std::optional<RxCp>{}, rx_fail(st_p0, at_p2, rx_trailing_backslash())}
        : (e_p5 == Text::lit("<")) || (e_p5 == Text::lit(">"))
        ? std::tuple{std::optional<RxCp>{}, rx_fail(st_p0, at_p2, rx_class_escape())}
        : rx_in(rx_punctuation(), e_p5)
        ? std::tuple{std::optional(RxCp(RxCp::RxLit{e_p5})), rx_go(st_p0, at_p2 + Nat(2u))}
        : rx_in(Text::lit("tnrfva"), e_p5)
        ? std::tuple{std::optional(RxCp(RxCp::RxLit{rx_control(e_p5)})), rx_go(st_p0, at_p2 + Nat(2u))}
        : e_p5 == Text::lit("x")
        ? ({
        auto [v_p6, st2_p7] = rx_hex(st_p0, at_p2);
        std::tuple{std::optional(rx_cp_of(v_p6)), st2_p7};
    })
        : rx_in(Text::lit("dws"), e_p5)
        ? std::tuple{std::optional<RxCp>{}, rx_go(st_p0, at_p2 + Nat(2u))}
        : rx_in(Text::lit("DWS"), e_p5)
        ? fi_p1
        ? std::tuple{std::optional<RxCp>{}, rx_fail(st_p0, at_p2, rx_class_negated_under_i())}
        : std::tuple{std::optional<RxCp>{}, rx_go(st_p0, at_p2 + Nat(2u))}
        : (e_p5 == Text::lit("p")) || (e_p5 == Text::lit("P"))
        ? ({
        auto&& _st2_p8 = rx_property(st_p0, at_p2);
        auto&& st2_p8 = std::get<1>(_st2_p8);
        ((e_p5 == Text::lit("P")) && fi_p1) && (!rx_bad(st2_p8))
        ? std::tuple{std::optional<RxCp>{}, rx_fail(st2_p8, at_p2, rx_class_negated_under_i())}
        : std::tuple{std::optional<RxCp>{}, st2_p8};
    })
        : std::tuple{std::optional<RxCp>{}, rx_fail(st_p0, at_p2, rx_class_escape())};
    });
}


/// RxControl: fn Text -> Text
Text rx_control(const Text& text0) {
    {
        auto&& c0_0 = text0;
        if (c0_0 == Text::lit("t")) {
            return Text::lit("\t");
        }
    }
    {
        auto&& c1_0 = text0;
        if (c1_0 == Text::lit("n")) {
            return Text::lit("\n");
        }
    }
    {
        auto&& c2_0 = text0;
        if (c2_0 == Text::lit("r")) {
            return Text::lit("\r");
        }
    }
    {
        auto&& c3_0 = text0;
        if (c3_0 == Text::lit("f")) {
            return Text::lit("");
        }
    }
    {
        auto&& c4_0 = text0;
        if (c4_0 == Text::lit("v")) {
            return Text::lit("");
        }
    }
    {
        return Text::lit("");
    }
}


/// RxAsciiItem: unbounded fn RxState, Bool -> RxState
RxState rx_ascii_item(const RxState& st_p0, const bool& fi_p1) {
    auto at_p2 = st_p0.i;
    auto s_p3 = st_p0.s;
    auto negated_p4 = rx_char_at(s_p3, at_p2 + Nat(2u)) == Text::lit("^");
    auto start_p5 = std::move(negated_p4) ? at_p2 + Nat(3u) : at_p2 + Nat(2u);
    auto j_p6 = rx_span_end(s_p3, start_p5, ({
        auto f = prism_rtl::rc(rx_is_letter);
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>>(prism_rtl::rc([=, f = std::move(f)](Text a0) {
        return ({
            auto f_1 = f;
            once_job([=, f_1 = std::move(f_1)]() { return prism_rtl::finished(f_1(a0)); });
        });
    })));
    }));
    auto shaped_p7 = (((rx_char_at(s_p3, at_p2 + Nat(1u)) == Text::lit(":")) && (j_p6 > start_p5)) && (rx_char_at(s_p3, j_p6) == Text::lit(":"))) && (rx_char_at(s_p3, j_p6 + Nat(1u)) == Text::lit("]"));
    return !std::move(shaped_p7)
        ? rx_fail(st_p0, at_p2, rx_class_nested())
        : crate::prelude::get(rx_ascii_classes(), rx_slice(s_p3, start_p5, j_p6)) == std::optional<bool>{}
        ? rx_fail(st_p0, at_p2, rx_class_ascii_unknown())
        : std::move(negated_p4) && fi_p1
        ? rx_fail(st_p0, at_p2, rx_class_negated_under_i())
        : rx_go(st_p0, j_p6 + Nat(2u));
}


/// RxGroup: unbounded fn RxState, Bool -> ((RxLast, RxMeasure, Bool, RxState))
std::tuple<RxLast, RxMeasure, bool, RxState> rx_group(const RxState& st_p0, const bool& fi_p1) {
    auto open_p2 = st_p0.i;
    auto s_p3 = st_p0.s;
    auto c_p4 = rx_char_at(s_p3, open_p2 + Nat(1u));
    auto d_p5 = rx_char_at(s_p3, open_p2 + Nat(2u));
    auto e_p6 = rx_char_at(s_p3, open_p2 + Nat(3u));
    auto fail_f7 = ({
        auto fi_p1_1 = fi_p1;
        auto st_p0_2 = st_p0;
        auto open_p2_3 = open_p2;
        static_cast<Fn<std::tuple<RxLast, RxMeasure, bool, RxState>(const Text&)>>(prism_rtl::rc([=, fi_p1_1 = std::move(fi_p1_1), st_p0_2 = std::move(st_p0_2), open_p2_3 = std::move(open_p2_3)](const Text& message_p8) { return std::tuple{RxLast(RxLast::RxLastAtom{}), rx_atom(), fi_p1_1, rx_fail(st_p0_2, open_p2_3, message_p8)}; }));
    });
    return c_p4 != Text::lit("?")
        ? rx_group_body(rx_go(st_p0, open_p2 + Nat(1u)), open_p2, fi_p1, fi_p1, true, std::optional<Text>{})
        : d_p5 == Text::lit("")
        ? fail_f7(rx_group_open())
        : d_p5 == Text::lit(":")
        ? rx_group_body(rx_go(st_p0, open_p2 + Nat(3u)), open_p2, fi_p1, fi_p1, false, std::optional<Text>{})
        : (d_p5 == Text::lit("=")) || (d_p5 == Text::lit("!"))
        ? fail_f7(rx_lookaround())
        : (d_p5 == Text::lit("<")) && ((e_p6 == Text::lit("=")) || (e_p6 == Text::lit("!")))
        ? fail_f7(rx_lookaround())
        : d_p5 == Text::lit("<")
        ? rx_named(st_p0, open_p2, open_p2 + Nat(3u), fi_p1)
        : (d_p5 == Text::lit("P")) && (e_p6 == Text::lit(""))
        ? fail_f7(rx_group_open())
        : (d_p5 == Text::lit("P")) && (e_p6 == Text::lit("<"))
        ? rx_named(st_p0, open_p2, open_p2 + Nat(4u), fi_p1)
        : (d_p5 == Text::lit("P")) && ((e_p6 == Text::lit("=")) || (e_p6 == Text::lit(">")))
        ? fail_f7(rx_backreference())
        : d_p5 == Text::lit("P")
        ? fail_f7(rx_unknown_group())
        : (rx_is_letter(d_p5) || (d_p5 == Text::lit("-"))) || (d_p5 == Text::lit(")"))
        ? rx_flag_group(st_p0, open_p2, fi_p1)
        : fail_f7(rx_unknown_group());
}


/// RxNamed: unbounded fn RxState, Nat, Nat, Bool -> ((RxLast, RxMeasure, Bool, RxState))
std::tuple<RxLast, RxMeasure, bool, RxState> rx_named(const RxState& st_p0, const Nat& open_p1, const Nat& start_p2, const bool& fi_p3) {
    auto&& _m = rx_find(st_p0.s, start_p2, Text::lit(">"));
    if (prism_rtl::is_none(_m)) {
        return std::tuple{RxLast(RxLast::RxLastAtom{}), rx_atom(), fi_p3, rx_fail(st_p0, open_p1, rx_name_open())};
    }
    if (prism_rtl::is_some(_m)) {
        auto&& close_p4 = prism_rtl::some_of(_m);
        auto name_p5 = rx_slice(st_p0.s, start_p2, close_p4);
        return !rx_is_name(name_p5)
            ? std::tuple{RxLast(RxLast::RxLastAtom{}), rx_atom(), fi_p3, rx_fail(st_p0, start_p2, rx_name_shape())}
            : crate::prelude::get(st_p0.names, name_p5) != std::optional<Nat>{}
            ? std::tuple{RxLast(RxLast::RxLastAtom{}), rx_atom(), fi_p3, rx_fail(st_p0, open_p1, rx_name_twice())}
            : rx_group_body(rx_go(st_p0, close_p4 + Nat(1u)), open_p1, fi_p3, fi_p3, true, std::optional(name_p5));
    }
    prism_rtl::unreachable("no arm matched");
}


/// RxFlagGroup: unbounded fn RxState, Nat, Bool -> ((RxLast, RxMeasure, Bool, RxState))
std::tuple<RxLast, RxMeasure, bool, RxState> rx_flag_group(const RxState& st_p0, const Nat& open_p1, const bool& fi_p2) {
    auto [bare_p3, inner_p4, st2_p5] = rx_flag_letters(st_p0, open_p1, fi_p2);
    return rx_bad(st2_p5)
        ? std::tuple{RxLast(RxLast::RxLastAtom{}), rx_atom(), fi_p2, st2_p5}
        : bare_p3
        ? std::tuple{RxLast(RxLast::RxLastFlagGroup{}), rx_none(), inner_p4, st2_p5}
        : rx_group_body(st2_p5, open_p1, inner_p4, fi_p2, false, std::optional<Text>{});
}


/// RxFlagLetters: unbounded fn RxState, Nat, Bool -> ((Bool, Bool, RxState))
std::tuple<bool, bool, RxState> rx_flag_letters(const RxState& st0_p0, const Nat& open_p1, const bool& fi0_p2) {
    std::tuple<bool, bool, RxState> this_ = std::tuple{false, fi0_p2, st0_p0};
    RxState st_p3 = rx_go(st0_p0, open_p1 + Nat(2u));
    bool fi_p4 = fi0_p2;
    Text seen_p5 = Text::lit("");
    std::optional<Nat> dash_o6 = std::optional<Nat>{};
    bool after_dash_p7 = false;
    bool named_p8 = false;
    bool bare_p9 = false;
    bool going_pa = true;
    while (std::move(going_pa) && (!rx_bad(st_p3))) {
        auto at_pb = st_p3.i;
        auto c_pc = rx_peek(st_p3);
        if (c_pc == Text::lit("")) {
            st_p3 = rx_fail(st_p3, open_p1, rx_group_open());
        } else if ((c_pc == Text::lit(")")) || (c_pc == Text::lit(":"))) {
            if ((!std::move(named_p8)) && (dash_o6 == std::optional<Nat>{})) {
                st_p3 = rx_fail(st_p3, open_p1, rx_flags_empty());
            } else  {
                ({
                    __label__ _done;
                    prism_rtl::Slot<Unit> _v;
                    if (prism_rtl::is_some(dash_o6)) {
                        auto&& d_pd = prism_rtl::some_of(dash_o6);
                        if (!std::move(after_dash_p7)) {
                            _v.set(({
                                st_p3 = rx_fail(st_p3, d_pd, rx_flags_dash());
                                Unit{};
                            }));
                            goto _done;
                        }
                    }
                    {
                        _v.set(({
                            st_p3 = rx_go(st_p3, at_pb + Nat(1u));
                            bare_p9 = c_pc == Text::lit(")");
                            going_pa = false;
                            Unit{};
                        }));
                        goto _done;
                    }
                _done:
                    _v.take();
                });
            }
        } else if (c_pc == Text::lit("-")) {
            if (dash_o6 != std::optional<Nat>{}) {
                st_p3 = rx_fail(st_p3, at_pb, rx_flags_second_dash());
            } else  {
                dash_o6 = std::optional(at_pb);
                st_p3 = rx_go(st_p3, at_pb + Nat(1u));
            }
        } else if (rx_is_letter(c_pc)) {
            if (!(((c_pc == Text::lit("i")) || (c_pc == Text::lit("m"))) || (c_pc == Text::lit("s")))) {
                st_p3 = rx_fail(st_p3, at_pb, rx_unknown_flag());
            } else if (rx_in(seen_p5, c_pc)) {
                st_p3 = rx_fail(st_p3, at_pb, rx_flag_twice());
            } else  {
                seen_p5 = prism_rtl::cat(seen_p5, c_pc);
                named_p8 = true;
                if (dash_o6 != std::optional<Nat>{}) {
                    after_dash_p7 = true;
                }
                if (c_pc == Text::lit("i")) {
                    fi_p4 = dash_o6 == std::optional<Nat>{};
                }
                st_p3 = rx_go(st_p3, at_pb + Nat(1u));
            }
        } else  {
            st_p3 = rx_fail(st_p3, open_p1, rx_unknown_group());
        }
    }
    this_ = std::tuple{std::move(bare_p9), std::move(fi_p4), st_p3};
    return this_;
}


/// RxGroupBody: unbounded fn RxState, Nat, Bool, Bool, Bool, ?Text -> ((RxLast, RxMeasure, Bool, RxState))
std::tuple<RxLast, RxMeasure, bool, RxState> rx_group_body(const RxState& st0_p0, const Nat& open_p1, const bool& inner_p2, const bool& outer_p3, const bool& capture_p4, const std::optional<Text>& name_o5) {
    auto counted_p6 = capture_p4 ? rx_capture(st0_p0, name_o5) : st0_p0;
    return prism_rtl::deref(counted_p6).open == Nat(100u)
        ? std::tuple{RxLast(RxLast::RxLastAtom{}), rx_atom(), outer_p3, rx_fail(counted_p6, Nat(0u), rx_nesting())}
        : ({
        auto deeper_p7 = ({
            RxState this_ = counted_p6;
            this_.open = this_.open + Nat(1u);
            (std::move(this_));
        });
        auto [m_p8, st2_p9] = rx_alternation(deeper_p7, inner_p2);
        rx_bad(st2_p9)
        ? std::tuple{RxLast(RxLast::RxLastAtom{}), rx_atom(), outer_p3, st2_p9}
        : rx_peek(st2_p9) != Text::lit(")")
        ? std::tuple{RxLast(RxLast::RxLastAtom{}), rx_atom(), outer_p3, rx_fail(st2_p9, open_p1, rx_group_open())}
        : ({
        auto closed_pa = ({
            RxState this_ = st2_p9;
            this_.i = this_.i + Nat(1u);
            this_.open = or_(this_.open.checked_sub(Nat(1u)), Nat(0u));
            (std::move(this_));
        });
        std::tuple{RxLast(RxLast::RxLastAtom{}), RxMeasure{.depth = prism_rtl::deref(m_p8).depth + Nat(1u), .size = prism_rtl::deref(m_p8).size, .product = prism_rtl::deref(m_p8).product}, outer_p3, closed_pa};
    });
    });
}


/// RxCapture: fn RxState, ?Text -> RxState
RxState rx_capture(const RxState& st_p0, const std::optional<Text>& name_o1) {
    auto n_p2 = st_p0.groups + Nat(1u);
    auto names_p3 = ({
        __label__ _done;
        prism_rtl::Slot<Map<Text, Nat>> _v;
        if (prism_rtl::is_some(name_o1)) {
            auto&& x_p4 = prism_rtl::some_of(name_o1);
            _v.set(insert(st_p0.names, x_p4, n_p2));
            goto _done;
        }
        if (prism_rtl::is_none(name_o1)) {
            _v.set(st_p0.names);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return RxState{.s = st_p0.s, .i = st_p0.i, .open = st_p0.open, .groups = n_p2, .names = names_p3, .err = st_p0.err};
}


/// ?RxReplacementRefusal: unbounded fn Text, Nat, (Text ==> Nat) -> ?RxDiag
std::optional<RxDiag> rx_replacement_refusal(const Text& r_p0, const Nat& groups_p1, const Map<Text, Nat>& names_p2) {
    auto&& _d_of = ({
        std::tuple<std::optional<RxDiag>, Nat> this_ = std::tuple{std::optional<RxDiag>{}, Nat(0u)};
        Nat i_p3 = Nat(0u);
        std::optional<RxDiag> d_o4 = std::optional<RxDiag>{};
        while ((d_o4 == std::optional<RxDiag>{}) && (rx_char_at(r_p0, i_p3) != Text::lit(""))) {
            auto at_p5 = i_p3;
            auto c_p6 = rx_char_at(r_p0, at_p5);
            auto next_p7 = rx_char_at(r_p0, at_p5 + Nat(1u));
            if (c_p6 == Text::lit("$")) {
                if (next_p7 == Text::lit("$")) {
                    i_p3 = at_p5 + Nat(2u);
                } else if (rx_is_digit(next_p7)) {
                    auto j_p8 = rx_span_end(r_p0, at_p5 + Nat(1u), ({
                        auto f = prism_rtl::rc(rx_is_digit);
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>>(prism_rtl::rc([=, f = std::move(f)](Text a0) {
                        return ({
                            auto f_1 = f;
                            once_job([=, f_1 = std::move(f_1)]() { return prism_rtl::finished(f_1(a0)); });
                        });
                    })));
                    }));
                    d_o4 = rx_group_number(rx_slice(r_p0, at_p5 + Nat(1u), j_p8), groups_p1, at_p5);
                    i_p3 = j_p8;
                } else if (next_p7 == Text::lit("{")) {
                    {
                        auto&& _m = rx_find(r_p0, at_p5 + Nat(2u), Text::lit("}"));
                        if (prism_rtl::is_none(_m)) {
                            d_o4 = rx_replacement_at(at_p5, rx_rbraces());
                        } else if (prism_rtl::is_some(_m)) {
                            auto&& close_p9 = prism_rtl::some_of(_m);
                            auto inner_pa = rx_slice(r_p0, at_p5 + Nat(2u), close_p9);
                            if ((inner_pa != Text::lit("")) && rx_all(inner_pa, ({
                                auto f = prism_rtl::rc(rx_is_digit);
                                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>>(prism_rtl::rc([=, f = std::move(f)](Text a0) {
                                return ({
                                    auto f_1 = f;
                                    once_job([=, f_1 = std::move(f_1)]() { return prism_rtl::finished(f_1(a0)); });
                                });
                            })));
                            }))) {
                                d_o4 = rx_group_number(inner_pa, groups_p1, at_p5);
                            } else if (rx_is_name(inner_pa)) {
                                if (crate::prelude::get(names_p2, inner_pa) == std::optional<Nat>{}) {
                                    d_o4 = rx_replacement_at(at_p5, rx_rno_name());
                                }
                            } else  {
                                d_o4 = rx_replacement_at(at_p5, rx_rbraces());
                            }
                            i_p3 = close_p9 + Nat(1u);
                        }
                    }
                } else  {
                    d_o4 = rx_replacement_at(at_p5, rx_rdollar());
                }
            } else if (c_p6 == Text::lit("\\")) {
                if ((((next_p7 == Text::lit("\\")) || (next_p7 == Text::lit("n"))) || (next_p7 == Text::lit("t"))) || (next_p7 == Text::lit("/"))) {
                    i_p3 = at_p5 + Nat(2u);
                } else if (next_p7 == Text::lit("u")) {
                    auto j_pb = rx_span_end(r_p0, at_p5 + Nat(3u), ({
                        auto f = prism_rtl::rc(rx_is_hex);
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>>(prism_rtl::rc([=, f = std::move(f)](Text a0) {
                        return ({
                            auto f_1 = f;
                            once_job([=, f_1 = std::move(f_1)]() { return prism_rtl::finished(f_1(a0)); });
                        });
                    })));
                    }));
                    auto digits_pc = rx_slice(r_p0, at_p5 + Nat(3u), j_pb);
                    auto v_pd = rx_hex_value(digits_pc);
                    auto named_pe = ((((rx_char_at(r_p0, at_p5 + Nat(2u)) == Text::lit("{")) && (rx_char_at(r_p0, j_pb) == Text::lit("}"))) && (digits_pc != Text::lit(""))) && (len_text(digits_pc) <= Nat(6u))) && (!(((Nat(55296u) <= v_pd) && (v_pd <= Nat(57343u))) || (v_pd > Nat(1114111u))));
                    if (std::move(named_pe)) {
                        i_p3 = j_pb + Nat(1u);
                    } else  {
                        d_o4 = rx_replacement_at(at_p5, rx_runicode());
                    }
                } else  {
                    d_o4 = rx_replacement_at(at_p5, rx_rescape());
                }
            } else  {
                i_p3 = at_p5 + len_text(c_p6);
            }
        }
        this_ = std::tuple{d_o4, i_p3};
        (std::move(this_));
    });
    auto&& d_of = std::get<0>(_d_of);
    return d_of;
}


prism_rtl::Turn<std::optional<RxDiag>> RxReplacementRefusal::cycle() const {
    const auto& r_p0 = this->r_p0;
    const auto& groups_p1 = this->groups_p1;
    const auto& names_p2 = this->names_p2;
    std::tuple<std::optional<RxDiag>, Nat> this_ = std::tuple{std::optional<RxDiag>{}, Nat(0u)};
    Nat i_p3 = Nat(0u);
    std::optional<RxDiag> d_o4 = std::optional<RxDiag>{};
    return call_then(loop_job(std::tuple{std::move(d_o4), std::move(this_), std::move(i_p3)}, ({
        auto groups_p1_1 = groups_p1;
        auto names_p2_2 = names_p2;
        auto r_p0_3 = r_p0;
        [=, groups_p1_1 = std::move(groups_p1_1), names_p2_2 = std::move(names_p2_2), r_p0_3 = std::move(r_p0_3)](std::tuple<std::optional<RxDiag>, std::tuple<std::optional<RxDiag>, Nat>, Nat> _p0) {
        auto d_o4 = std::get<0>(_p0);
        auto this_ = std::get<1>(_p0);
        auto i_p3 = std::get<2>(_p0);
        return (d_o4 == std::optional<RxDiag>{}) && (rx_char_at(r_p0_3, i_p3) != Text::lit(""))
            ? ({
            auto at_p5 = i_p3;
            auto c_p6 = rx_char_at(r_p0_3, at_p5);
            auto next_p7 = rx_char_at(r_p0_3, at_p5 + Nat(1u));
            if (c_p6 == Text::lit("$")) {
                if (next_p7 == Text::lit("$")) {
                    i_p3 = at_p5 + Nat(2u);
                } else if (rx_is_digit(next_p7)) {
                    auto j_p8 = rx_span_end(r_p0_3, at_p5 + Nat(1u), ({
                        auto f = prism_rtl::rc(rx_is_digit);
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>>(prism_rtl::rc([=, f = std::move(f)](Text a0) {
                        return ({
                            auto f_4 = f;
                            once_job([=, f_4 = std::move(f_4)]() { return prism_rtl::finished(f_4(a0)); });
                        });
                    })));
                    }));
                    d_o4 = rx_group_number(rx_slice(r_p0_3, at_p5 + Nat(1u), j_p8), groups_p1_1, at_p5);
                    i_p3 = j_p8;
                } else if (next_p7 == Text::lit("{")) {
                    {
                        auto&& _m = rx_find(r_p0_3, at_p5 + Nat(2u), Text::lit("}"));
                        if (prism_rtl::is_none(_m)) {
                            d_o4 = rx_replacement_at(at_p5, rx_rbraces());
                        } else if (prism_rtl::is_some(_m)) {
                            auto&& close_p9 = prism_rtl::some_of(_m);
                            auto inner_pa = rx_slice(r_p0_3, at_p5 + Nat(2u), close_p9);
                            if ((inner_pa != Text::lit("")) && rx_all(inner_pa, ({
                                auto f = prism_rtl::rc(rx_is_digit);
                                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>>(prism_rtl::rc([=, f = std::move(f)](Text a0) {
                                return ({
                                    auto f_4 = f;
                                    once_job([=, f_4 = std::move(f_4)]() { return prism_rtl::finished(f_4(a0)); });
                                });
                            })));
                            }))) {
                                d_o4 = rx_group_number(inner_pa, groups_p1_1, at_p5);
                            } else if (rx_is_name(inner_pa)) {
                                if (crate::prelude::get(names_p2_2, inner_pa) == std::optional<Nat>{}) {
                                    d_o4 = rx_replacement_at(at_p5, rx_rno_name());
                                }
                            } else  {
                                d_o4 = rx_replacement_at(at_p5, rx_rbraces());
                            }
                            i_p3 = close_p9 + Nat(1u);
                        }
                    }
                } else  {
                    d_o4 = rx_replacement_at(at_p5, rx_rdollar());
                }
            } else if (c_p6 == Text::lit("\\")) {
                if ((((next_p7 == Text::lit("\\")) || (next_p7 == Text::lit("n"))) || (next_p7 == Text::lit("t"))) || (next_p7 == Text::lit("/"))) {
                    i_p3 = at_p5 + Nat(2u);
                } else if (next_p7 == Text::lit("u")) {
                    auto j_pb = rx_span_end(r_p0_3, at_p5 + Nat(3u), ({
                        auto f = prism_rtl::rc(rx_is_hex);
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>>(prism_rtl::rc([=, f = std::move(f)](Text a0) {
                        return ({
                            auto f_4 = f;
                            once_job([=, f_4 = std::move(f_4)]() { return prism_rtl::finished(f_4(a0)); });
                        });
                    })));
                    }));
                    auto digits_pc = rx_slice(r_p0_3, at_p5 + Nat(3u), j_pb);
                    auto v_pd = rx_hex_value(digits_pc);
                    auto named_pe = ((((rx_char_at(r_p0_3, at_p5 + Nat(2u)) == Text::lit("{")) && (rx_char_at(r_p0_3, j_pb) == Text::lit("}"))) && (digits_pc != Text::lit(""))) && (len_text(digits_pc) <= Nat(6u))) && (!(((Nat(55296u) <= v_pd) && (v_pd <= Nat(57343u))) || (v_pd > Nat(1114111u))));
                    if (std::move(named_pe)) {
                        i_p3 = j_pb + Nat(1u);
                    } else  {
                        d_o4 = rx_replacement_at(at_p5, rx_runicode());
                    }
                } else  {
                    d_o4 = rx_replacement_at(at_p5, rx_rescape());
                }
            } else  {
                i_p3 = at_p5 + len_text(c_p6);
            }
            Expected<std::tuple<std::optional<RxDiag>, std::tuple<std::optional<RxDiag>, Nat>, Nat>, std::tuple<std::optional<RxDiag>, std::tuple<std::optional<RxDiag>, Nat>, Nat>>(std::tuple{d_o4, this_, i_p3});
        })
            : Expected<std::tuple<std::optional<RxDiag>, std::tuple<std::optional<RxDiag>, Nat>, Nat>, std::tuple<std::optional<RxDiag>, std::tuple<std::optional<RxDiag>, Nat>, Nat>>(unexpected(std::tuple{d_o4, this_, i_p3}));
    };
    })), [=](std::tuple<std::optional<RxDiag>, std::tuple<std::optional<RxDiag>, Nat>, Nat> _p0) {
        auto d_o4 = std::get<0>(_p0);
        auto this_ = std::get<1>(_p0);
        auto i_p3 = std::get<2>(_p0);
        return ({
            this_ = std::tuple{d_o4, i_p3};
            auto&& _d_of = this_;
            auto&& d_of = std::get<0>(_d_of);
            (prism_rtl::finished(d_of));
        });
    });
}


/// `Start RxReplacementRefusal, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<RxDiag>> start_rx_replacement_refusal(Text r_p0, Nat groups_p1, Map<Text, Nat> names_p2) {
    return prism_rtl::make_rc<RxReplacementRefusal>(r_p0, groups_p1, names_p2);
}


/// ?RxReplacementAt: fn Nat, Text -> ?RxDiag
std::optional<RxDiag> rx_replacement_at(const Nat& at_p0, const Text& message_p1) {
    return std::optional(RxDiag{.part = Text::lit("replacement"), .at = at_p0, .message = message_p1});
}


/// ?RxGroupNumber: fn Text, Nat, Nat -> ?RxDiag
std::optional<RxDiag> rx_group_number(const Text& digits_p0, const Nat& groups_p1, const Nat& at_p2) {
    return rx_leading_zero(digits_p0)
        ? rx_replacement_at(at_p2, rx_rzero())
        : or_(parse_nat_opt(digits_p0), Nat(0u)) > groups_p1
        ? rx_replacement_at(at_p2, rx_rno_number())
        : std::optional<RxDiag>{};
}

}  // namespace crate::check::regex


// The module `Check.Shrink`, from `target/bootstrap/cpp-src/prismc/check/shrink/mod.prism`.
namespace crate::check::shrink {

void Rel::show(Printer& p) const {
    p.record("Rel", {{"param", param}, {"strict", strict}});
}

Pod Rel::to_pod() const {
    return Pod::record("Rel", {{"param", prism_rtl::to_pod(param)}, {"strict", prism_rtl::to_pod(strict)}});
}

Result<Rel> Rel::from_pod(const Pod& whole) {
    return Rel{.param = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "param")))), .strict = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "strict"))))};
}


void Sc::show(Printer& p) const {
    p.record("Sc", {{"caller", caller}, {"callee", callee}, {"edges", edges}, {"span", span}, {"file", file}, {"arg", arg}});
}

Pod Sc::to_pod() const {
    return Pod::record("Sc", {{"caller", prism_rtl::to_pod(caller)}, {"callee", prism_rtl::to_pod(callee)}, {"edges", prism_rtl::to_pod(edges)}, {"span", prism_rtl::to_pod(span)}, {"file", prism_rtl::to_pod(file)}, {"arg", prism_rtl::to_pod(arg)}});
}

Result<Sc> Sc::from_pod(const Pod& whole) {
    return Sc{.caller = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "caller")))), .callee = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "callee")))), .edges = TRY(prism_rtl::from_pod<Array<std::tuple<Nat, Nat, bool>>>(TRY(crate::prelude::field(whole, "edges")))), .span = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span")))), .file = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "file")))), .arg = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "arg"))))};
}


bool Shrink::operator==(const Shrink& o) const { return g == o.g && fns == o.fns && by_key == o.by_key && targets == o.targets && impl_defs == o.impl_defs && choices == o.choices && sums == o.sums && seeds == o.seeds && local_of == o.local_of && local_base == o.local_base; }

void Shrink::show(Printer& p) const {
    p.record("Shrink", {{"g", g}, {"fns", fns}, {"by_key", by_key}, {"targets", targets}, {"impl_defs", impl_defs}, {"choices", choices}, {"sums", sums}, {"seeds", seeds}, {"local_of", local_of}, {"local_base", local_base}});
}

Pod Shrink::to_pod() const {
    return Pod::record("Shrink", {{"g", prism_rtl::to_pod(g)}, {"fns", prism_rtl::to_pod(fns)}, {"by_key", prism_rtl::to_pod(by_key)}, {"targets", prism_rtl::to_pod(targets)}, {"impl_defs", prism_rtl::to_pod(impl_defs)}, {"choices", prism_rtl::to_pod(choices)}, {"sums", prism_rtl::to_pod(sums)}, {"seeds", prism_rtl::to_pod(seeds)}, {"local_of", prism_rtl::to_pod(local_of)}, {"local_base", prism_rtl::to_pod(local_base)}});
}

Result<Shrink> Shrink::from_pod(const Pod& whole) {
    return Shrink{.g = TRY(prism_rtl::from_pod<crate::check::env::G>(TRY(crate::prelude::field(whole, "g")))), .fns = TRY(prism_rtl::from_pod<Array<crate::check::env::Def>>(TRY(crate::prelude::field(whole, "fns")))), .by_key = TRY(prism_rtl::from_pod<Map<Text, crate::check::env::Def>>(TRY(crate::prelude::field(whole, "by_key")))), .targets = TRY(prism_rtl::from_pod<Map<Text, Array<Text>>>(TRY(crate::prelude::field(whole, "targets")))), .impl_defs = TRY(prism_rtl::from_pod<Map<Text, Text>>(TRY(crate::prelude::field(whole, "impl_defs")))), .choices = TRY(prism_rtl::from_pod<Map<Text, Array<Text>>>(TRY(crate::prelude::field(whole, "choices")))), .sums = TRY(prism_rtl::from_pod<Map<Text, Nat>>(TRY(crate::prelude::field(whole, "sums")))), .seeds = TRY(prism_rtl::from_pod<Map<Text, Map<Text, Rel>>>(TRY(crate::prelude::field(whole, "seeds")))), .local_of = TRY(prism_rtl::from_pod<Map<Text, Text>>(TRY(crate::prelude::field(whole, "local_of")))), .local_base = TRY(prism_rtl::from_pod<Map<Text, Map<Text, Rel>>>(TRY(crate::prelude::field(whole, "local_base"))))};
}


/// ShrinkCheck: unbounded fn G, St, [Def] -> ((St, [((Text, [Text]))]))
std::tuple<crate::check::types::St, Array<std::tuple<Text, Array<Text>>>> shrink_check(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const Array<crate::check::env::Def>& defs_p2) {
    auto fns_p3 = each(filter(defs_p2, [&](const crate::check::env::Def& d_pi) { return len(crate::check::shrink::types::def_clauses(d_pi)) > Nat(0u); }), [&](const crate::check::env::Def& d_pj) { return crate::check::shrink::types::own_key(d_pj); });
    auto by_key_p4 = fold(fns_p3, Map<Text, crate::check::env::Def>{}, [&](const Map<Text, crate::check::env::Def>& m_pk, const crate::check::env::Def& d_pl) { return insert(m_pk, prism_rtl::deref(d_pl).qk, d_pl); });
    auto homes_p5 = fold(fns_p3, Array<Text>{}, [&](const Array<Text>& acc_pm, const crate::check::env::Def& d_pn) { return crate::check::types::add_text(acc_pm, prism_rtl::deref(d_pn).home); });
    auto nats_p6 = crate::check::shrink::types::nat_minus_seeds(st_p1);
    auto pre_p7 = fold(homes_p5, Map<Text, Map<Text, Rel>>{}, [&](const Map<Text, Map<Text, Rel>>& m_po, const Text& h_pp) { return insert(m_po, h_pp, fold(keys(nats_p6), crate::check::shrink::relations::prelude_seeds(g_p0, h_pp), [&](const Map<Text, Rel>& m2_pq, const Text& k_pr) { return insert(m2_pq, k_pr, crate::check::shrink::relations::no_rel()); })); });
    auto sk0_p8 = Shrink{.g = g_p0, .fns = fns_p3, .by_key = by_key_p4, .targets = crate::check::shrink::types::method_targets(g_p0, fns_p3), .impl_defs = crate::check::shrink::types::impl_defs(g_p0, fns_p3), .choices = st_p1.choices, .sums = Map<Text, Nat>{}, .seeds = pre_p7, .local_of = Map<Text, Text>{}, .local_base = Map<Text, Map<Text, Rel>>{}};
    auto sk1_p9 = ({
        Shrink this_ = sk0_p8;
        this_.sums = crate::check::shrink::summaries::parts_summaries(sk0_p8, fns_p3);
        (std::move(this_));
    });
    auto skg_pa = ({
        Shrink this_ = sk1_p9;
        this_.seeds = crate::check::shrink::calls::hof_seeds(sk1_p9, homes_p5);
        (std::move(this_));
    });
    auto walked_pb = run_to_end(each_job(fns_p3, ({
        auto skg_pa_1 = skg_pa;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, Array<Text>, Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>>>(crate::check::env::Def)>>(prism_rtl::rc([=, skg_pa_1 = std::move(skg_pa_1)](crate::check::env::Def p0) {
        return ({
            auto skg_pa_1_2 = skg_pa_1;
            entered(once_job([=, skg_pa_1_2 = std::move(skg_pa_1_2)]() {
            return ({
                auto d_ps = p0;
                (prism_rtl::more(prism_rtl::rc(crate::check::shrink::locals::DefWalk(skg_pa_1_2, d_ps))));
            });
        }));
        });
    }));
    })));
    auto sk_pc = crate::check::shrink::locals::with_locals(skg_pa, fold(walked_pb, Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>{}, [&](const Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>& acc_pt, const std::tuple<Text, Array<Text>, Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>>& _p1) {
        auto&& ls_pu = std::get<2>(_p1);
        return append(acc_pt, ls_pu);
    }));
    auto refs_pd = append(each(walked_pb, [&](const std::tuple<Text, Array<Text>, Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>>& _p0) {
        auto&& k_pv = std::get<0>(_p0);
        auto&& rs_p10 = std::get<1>(_p0);
        return std::tuple{k_pv, rs_p10};
    }), run_to_end(each_job(drop(prism_rtl::deref(sk_pc).fns, len(fns_p3)), ({
        auto sk_pc_1 = sk_pc;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, Array<Text>>>(crate::check::env::Def)>>(prism_rtl::rc([=, sk_pc_1 = std::move(sk_pc_1)](crate::check::env::Def p0) {
        return ({
            auto sk_pc_1_2 = sk_pc_1;
            entered(once_job([=, sk_pc_1_2 = std::move(sk_pc_1_2)]() {
            return ({
                auto d_p11 = p0;
                call_then(crate::check::shrink::calls::start_def_refs(sk_pc_1_2, d_p11), [=](Array<Text> def_refs_3915) { return prism_rtl::finished(std::tuple{prism_rtl::deref(d_p11).qk, def_refs_3915}); });
            });
        }));
        });
    }));
    }))));
    auto keys_pe = each(prism_rtl::deref(sk_pc).fns, [&](const crate::check::env::Def& d_p12) { return prism_rtl::deref(d_p12).qk; });
    auto sccs_pf = crate::check::shrink::locals::sccs(keys_pe, refs_pd);
    auto st2_pg = run_to_end(fold_job(sccs_pf, crate::check::shrink::types::negative_types(g_p0, st_p1), ({
        auto sk_pc_1 = sk_pc;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, Array<Text>>)>>(prism_rtl::rc([=, sk_pc_1 = std::move(sk_pc_1)](std::tuple<crate::check::types::St, Array<Text>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sk_pc_1_2 = sk_pc_1;
            entered(once_job([=, sk_pc_1_2 = std::move(sk_pc_1_2)]() {
            return ({
                auto s_p13 = p0;
                auto comp_p14 = p1;
                (prism_rtl::more(prism_rtl::rc(crate::check::shrink::locals::ShrinkComponent(sk_pc_1_2, s_p13, comp_p14))));
            });
        }));
        });
    })));
    })));
    auto st3_ph = run_to_end(fold_job(fns_p3, st2_pg, ({
        auto sk_pc_1 = sk_pc;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::check::env::Def>)>>(prism_rtl::rc([=, sk_pc_1 = std::move(sk_pc_1)](std::tuple<crate::check::types::St, crate::check::env::Def> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sk_pc_1_2 = sk_pc_1;
            entered(once_job([=, sk_pc_1_2 = std::move(sk_pc_1_2)]() {
            return ({
                auto s_p15 = p0;
                auto d_p16 = p1;
                (prism_rtl::more(prism_rtl::rc(crate::check::shrink::summaries::LoopsOf(sk_pc_1_2, s_p15, d_p16))));
            });
        }));
        });
    })));
    })));
    return std::tuple{st3_ph, refs_pd};
}


prism_rtl::Turn<std::tuple<crate::check::types::St, Array<std::tuple<Text, Array<Text>>>>> ShrinkCheck::cycle() const {
    const auto& g_p0 = this->g_p0;
    const auto& st_p1 = this->st_p1;
    const auto& defs_p2 = this->defs_p2;
    auto fns_p3 = each(filter(defs_p2, [&](const crate::check::env::Def& d_pi) { return len(crate::check::shrink::types::def_clauses(d_pi)) > Nat(0u); }), [&](const crate::check::env::Def& d_pj) { return crate::check::shrink::types::own_key(d_pj); });
    auto by_key_p4 = fold(fns_p3, Map<Text, crate::check::env::Def>{}, [&](const Map<Text, crate::check::env::Def>& m_pk, const crate::check::env::Def& d_pl) { return insert(m_pk, prism_rtl::deref(d_pl).qk, d_pl); });
    auto homes_p5 = fold(fns_p3, Array<Text>{}, [&](const Array<Text>& acc_pm, const crate::check::env::Def& d_pn) { return crate::check::types::add_text(acc_pm, prism_rtl::deref(d_pn).home); });
    auto g_p0_1 = g_p0;
    auto st_p1_2 = st_p1;
    return call_then(crate::check::shrink::types::start_nat_minus_seeds(st_p1_2), [=](Map<Text, Rel> nat_minus_seeds_3210) {
        return ({
            auto nats_p6 = nat_minus_seeds_3210;
            auto pre_p7 = fold(homes_p5, Map<Text, Map<Text, Rel>>{}, [&](const Map<Text, Map<Text, Rel>>& m_po, const Text& h_pp) { return insert(m_po, h_pp, fold(keys(nats_p6), crate::check::shrink::relations::prelude_seeds(g_p0_1, h_pp), [&](const Map<Text, Rel>& m2_pq, const Text& k_pr) { return insert(m2_pq, k_pr, crate::check::shrink::relations::no_rel()); })); });
            auto sk0_p8 = Shrink{.g = g_p0_1, .fns = fns_p3, .by_key = by_key_p4, .targets = crate::check::shrink::types::method_targets(g_p0_1, fns_p3), .impl_defs = crate::check::shrink::types::impl_defs(g_p0_1, fns_p3), .choices = prism_rtl::deref(st_p1_2).choices, .sums = Map<Text, Nat>{}, .seeds = pre_p7, .local_of = Map<Text, Text>{}, .local_base = Map<Text, Map<Text, Rel>>{}};
            auto sk1_p9 = ({
                Shrink this_ = sk0_p8;
                this_.sums = crate::check::shrink::summaries::parts_summaries(sk0_p8, fns_p3);
                (std::move(this_));
            });
            auto skg_pa = ({
                Shrink this_ = sk1_p9;
                this_.seeds = crate::check::shrink::calls::hof_seeds(sk1_p9, homes_p5);
                (std::move(this_));
            });
            call_value(each_job(fns_p3, ({
            auto skg_pa_3 = skg_pa;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, Array<Text>, Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>>>(crate::check::env::Def)>>(prism_rtl::rc([=, skg_pa_3 = std::move(skg_pa_3)](crate::check::env::Def p0) {
            return ({
                auto skg_pa_3_4 = skg_pa_3;
                entered(once_job([=, skg_pa_3_4 = std::move(skg_pa_3_4)]() {
                return ({
                    auto d_ps = p0;
                    (prism_rtl::more(prism_rtl::rc(crate::check::shrink::locals::DefWalk(skg_pa_3_4, d_ps))));
                });
            }));
            });
        }));
        })), [=](Array<std::tuple<Text, Array<Text>, Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>>> each_3674) {
            return ({
                auto walked_pb = each_3674;
                call_then(crate::check::shrink::locals::start_with_locals(skg_pa, fold(walked_pb, Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>{}, [&](const Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>& acc_pt, const std::tuple<Text, Array<Text>, Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>>& _p1) {
                auto&& ls_pu = std::get<2>(_p1);
                return append(acc_pt, ls_pu);
            })), [=](Shrink with_locals_3717) {
                return ({
                    auto sk_pc = with_locals_3717;
                    call_value(each_job(drop(prism_rtl::deref(sk_pc).fns, len(fns_p3)), ({
                    auto sk_pc_3 = sk_pc;
                    static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, Array<Text>>>(crate::check::env::Def)>>(prism_rtl::rc([=, sk_pc_3 = std::move(sk_pc_3)](crate::check::env::Def p0) {
                    return ({
                        auto sk_pc_3_4 = sk_pc_3;
                        entered(once_job([=, sk_pc_3_4 = std::move(sk_pc_3_4)]() {
                        return ({
                            auto d_p11 = p0;
                            call_then(crate::check::shrink::calls::start_def_refs(sk_pc_3_4, d_p11), [=](Array<Text> def_refs_3915) { return prism_rtl::finished(std::tuple{prism_rtl::deref(d_p11).qk, def_refs_3915}); });
                        });
                    }));
                    });
                }));
                })), [=](Array<std::tuple<Text, Array<Text>>> each_3870) {
                    return ({
                        auto refs_pd = append(each(walked_pb, [&](const std::tuple<Text, Array<Text>, Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>>& _p0) {
                            auto&& k_pv = std::get<0>(_p0);
                            auto&& rs_p10 = std::get<1>(_p0);
                            return std::tuple{k_pv, rs_p10};
                        }), each_3870);
                        auto keys_pe = each(prism_rtl::deref(sk_pc).fns, [&](const crate::check::env::Def& d_p12) { return prism_rtl::deref(d_p12).qk; });
                        call_then(crate::check::shrink::locals::start_sccs(keys_pe, refs_pd), [=](Array<Array<Text>> sccs_3986) {
                        return ({
                            auto sccs_pf = sccs_3986;
                            call_then(crate::check::shrink::types::start_negative_types(g_p0_1, st_p1_2), [=, sccs_pf = std::move(sccs_pf)](crate::check::types::St negative_types_4028) {
                            return call_value(fold_job(sccs_pf, negative_types_4028, ({
                                auto sk_pc_3 = sk_pc;
                                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, Array<Text>>)>>(prism_rtl::rc([=, sk_pc_3 = std::move(sk_pc_3)](std::tuple<crate::check::types::St, Array<Text>> _p0) {
                                auto&& p0 = std::get<0>(_p0);
                                auto&& p1 = std::get<1>(_p0);
                                return ({
                                    auto sk_pc_3_4 = sk_pc_3;
                                    entered(once_job([=, sk_pc_3_4 = std::move(sk_pc_3_4)]() {
                                    return ({
                                        auto s_p13 = p0;
                                        auto comp_p14 = p1;
                                        (prism_rtl::more(prism_rtl::rc(crate::check::shrink::locals::ShrinkComponent(sk_pc_3_4, s_p13, comp_p14))));
                                    });
                                }));
                                });
                            })));
                            })), [=](crate::check::types::St fold_4016) {
                                return ({
                                    auto st2_pg = fold_4016;
                                    call_value(fold_job(fns_p3, st2_pg, ({
                                    auto sk_pc_3 = sk_pc;
                                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::check::env::Def>)>>(prism_rtl::rc([=, sk_pc_3 = std::move(sk_pc_3)](std::tuple<crate::check::types::St, crate::check::env::Def> _p0) {
                                    auto&& p0 = std::get<0>(_p0);
                                    auto&& p1 = std::get<1>(_p0);
                                    return ({
                                        auto sk_pc_3_4 = sk_pc_3;
                                        entered(once_job([=, sk_pc_3_4 = std::move(sk_pc_3_4)]() {
                                        return ({
                                            auto s_p15 = p0;
                                            auto d_p16 = p1;
                                            (prism_rtl::more(prism_rtl::rc(crate::check::shrink::summaries::LoopsOf(sk_pc_3_4, s_p15, d_p16))));
                                        });
                                    }));
                                    });
                                })));
                                })), [=](crate::check::types::St fold_4103) {
                                    return ({
                                        auto st3_ph = fold_4103;
                                        (prism_rtl::finished(std::tuple{st3_ph, refs_pd}));
                                    });
                                });
                                });
                            });
                        });
                        });
                    });
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start ShrinkCheck, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::St, Array<std::tuple<Text, Array<Text>>>>> start_shrink_check(crate::check::env::G g_p0, crate::check::types::St st_p1, Array<crate::check::env::Def> defs_p2) {
    return prism_rtl::make_rc<ShrinkCheck>(g_p0, st_p1, defs_p2);
}


/// UnusedDefs: unbounded fn [Def], [((Text, [Text]))], Nat -> [CDiag]
Array<crate::check::errors::CDiag> unused_defs(const Array<crate::check::env::Def>& defs_p0, const Array<std::tuple<Text, Array<Text>>>& refs_p1, const Nat& shown_p2) {
    auto used0_p3 = fold(refs_p1, Map<Text, Unit>{}, [&](const Map<Text, Unit>& m_p6, const std::tuple<Text, Array<Text>>& _p1) {
        auto&& k_p7 = std::get<0>(_p1);
        auto&& rs_p8 = std::get<1>(_p1);
        return fold(rs_p8, m_p6, [&](const Map<Text, Unit>& m2_p9, const Text& r_pa) { return r_pa == k_p7 ? m2_p9 : insert(m2_p9, r_pa, Unit{}); });
    });
    auto used_p4 = run_to_end(fold_job(defs_p0, used0_p3, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Unit>>(std::tuple<Map<Text, Unit>, crate::check::env::Def>)>>(prism_rtl::rc([=](std::tuple<Map<Text, Unit>, crate::check::env::Def> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto m_pb = p0;
                auto d_pc = p1;
                ({
                auto&& _m = prism_rtl::deref(d_pc).body;
                prism_rtl::is<crate::check::env::DefBody::DbCheck>(_m) ? ({
                auto&& c_pd = prism_rtl::as<crate::check::env::DefBody::DbCheck>(_m).a0;
                fold_job(prism_rtl::deref(c_pd).lines, m_pb, ({
                auto d_pc_1 = d_pc;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Unit>>(std::tuple<Map<Text, Unit>, crate::syntax::decls::CheckLine>)>>(prism_rtl::rc([=, d_pc_1 = std::move(d_pc_1)](std::tuple<Map<Text, Unit>, crate::syntax::decls::CheckLine> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto d_pc_1_2 = d_pc_1;
                    entered(once_job([=, d_pc_1_2 = std::move(d_pc_1_2)]() {
                    return ({
                        auto m2_pe = p0;
                        auto l_pf = p1;
                        call_then(crate::check::typed::print::start_exprs_in(prism_rtl::deref(l_pf).expr), [=, m2_pe = std::move(m2_pe)](Array<crate::syntax::Expr> exprs_in_4836) {
                        return prism_rtl::finished(fold(exprs_in_4836, m2_pe, [&](const Map<Text, Unit>& m3_pg, const crate::syntax::Expr& e_ph) {
                            return ({
                                __label__ _done;
                                prism_rtl::Slot<Map<Text, Unit>> _v;
                                auto&& _m = prism_rtl::deref(prism_rtl::deref(e_ph).kind);
                                if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
                                    auto&& n_pi = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
                                    _v.set(insert(insert(m3_pg, crate::check::env::sname_key(n_pi), Unit{}), crate::check::env::qual_key(prism_rtl::deref(d_pc_1_2).home, crate::check::env::sname_key(n_pi)), Unit{}));
                                    goto _done;
                                }
                                {
                                    _v.set(m3_pg);
                                    goto _done;
                                }
                            _done:
                                _v.take();
                            });
                        }));
                    });
                    });
                }));
                });
            }));
            }))->cycle();
            })
                : prism_rtl::finished(m_pb);
            });
            });
        }));
    }))));
    auto own_p5 = filter(defs_p0, [&](const crate::check::env::Def& d_pj) { return ((((d_pj->file < shown_p2) && (!crate::check::env::has_key(used_p4, prism_rtl::deref(d_pj).qk))) && (prism_rtl::deref(d_pj).name != Text::lit("@main"))) && (!is_method_def(d_pj))) && (!is_testing_def(d_pj)); });
    return each(own_p5, [&](const crate::check::env::Def& d_pk) { return crate::check::errors::CDiag{.code = Text::lit("unused"), .file = d_pk->file, .span = prism_rtl::deref(d_pk).span, .message = prism_rtl::cat("nothing uses `", prism_rtl::deref(d_pk).name, "`"), .fix = Text::lit("delete it, or use it")}; });
}


prism_rtl::Turn<Array<crate::check::errors::CDiag>> UnusedDefs::cycle() const {
    const auto& defs_p0 = this->defs_p0;
    const auto& refs_p1 = this->refs_p1;
    const auto& shown_p2 = this->shown_p2;
    auto used0_p3 = fold(refs_p1, Map<Text, Unit>{}, [&](const Map<Text, Unit>& m_p6, const std::tuple<Text, Array<Text>>& _p1) {
        auto&& k_p7 = std::get<0>(_p1);
        auto&& rs_p8 = std::get<1>(_p1);
        return fold(rs_p8, m_p6, [&](const Map<Text, Unit>& m2_p9, const Text& r_pa) { return r_pa == k_p7 ? m2_p9 : insert(m2_p9, r_pa, Unit{}); });
    });
    auto defs_p0_1 = defs_p0;
    auto shown_p2_2 = shown_p2;
    return call_value(fold_job(defs_p0_1, used0_p3, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Unit>>(std::tuple<Map<Text, Unit>, crate::check::env::Def>)>>(prism_rtl::rc([=](std::tuple<Map<Text, Unit>, crate::check::env::Def> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto m_pb = p0;
                auto d_pc = p1;
                ({
                auto&& _m = prism_rtl::deref(d_pc).body;
                prism_rtl::is<crate::check::env::DefBody::DbCheck>(_m) ? ({
                auto&& c_pd = prism_rtl::as<crate::check::env::DefBody::DbCheck>(_m).a0;
                fold_job(prism_rtl::deref(c_pd).lines, m_pb, ({
                auto d_pc_3 = d_pc;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Unit>>(std::tuple<Map<Text, Unit>, crate::syntax::decls::CheckLine>)>>(prism_rtl::rc([=, d_pc_3 = std::move(d_pc_3)](std::tuple<Map<Text, Unit>, crate::syntax::decls::CheckLine> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto d_pc_3_4 = d_pc_3;
                    entered(once_job([=, d_pc_3_4 = std::move(d_pc_3_4)]() {
                    return ({
                        auto m2_pe = p0;
                        auto l_pf = p1;
                        call_then(crate::check::typed::print::start_exprs_in(prism_rtl::deref(l_pf).expr), [=, m2_pe = std::move(m2_pe)](Array<crate::syntax::Expr> exprs_in_4836) {
                        return prism_rtl::finished(fold(exprs_in_4836, m2_pe, [&](const Map<Text, Unit>& m3_pg, const crate::syntax::Expr& e_ph) {
                            return ({
                                __label__ _done;
                                prism_rtl::Slot<Map<Text, Unit>> _v;
                                auto&& _m = prism_rtl::deref(prism_rtl::deref(e_ph).kind);
                                if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
                                    auto&& n_pi = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
                                    _v.set(insert(insert(m3_pg, crate::check::env::sname_key(n_pi), Unit{}), crate::check::env::qual_key(prism_rtl::deref(d_pc_3_4).home, crate::check::env::sname_key(n_pi)), Unit{}));
                                    goto _done;
                                }
                                {
                                    _v.set(m3_pg);
                                    goto _done;
                                }
                            _done:
                                _v.take();
                            });
                        }));
                    });
                    });
                }));
                });
            }));
            }))->cycle();
            })
                : prism_rtl::finished(m_pb);
            });
            });
        }));
    }))), [=](Map<Text, Unit> fold_4745) {
        return ({
            auto used_p4 = fold_4745;
            auto own_p5 = filter(defs_p0_1, [&](const crate::check::env::Def& d_pj) { return ((((d_pj->file < shown_p2_2) && (!crate::check::env::has_key(used_p4, prism_rtl::deref(d_pj).qk))) && (prism_rtl::deref(d_pj).name != Text::lit("@main"))) && (!is_method_def(d_pj))) && (!is_testing_def(d_pj)); });
            (prism_rtl::finished(each(own_p5, [&](const crate::check::env::Def& d_pk) { return crate::check::errors::CDiag{.code = Text::lit("unused"), .file = d_pk->file, .span = prism_rtl::deref(d_pk).span, .message = prism_rtl::cat("nothing uses `", prism_rtl::deref(d_pk).name, "`"), .fix = Text::lit("delete it, or use it")}; })));
        });
    });
}


/// `Start UnusedDefs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::check::errors::CDiag>> start_unused_defs(Array<crate::check::env::Def> defs_p0, Array<std::tuple<Text, Array<Text>>> refs_p1, Nat shown_p2) {
    return prism_rtl::make_rc<UnusedDefs>(defs_p0, refs_p1, shown_p2);
}


/// TestOnlyReached: fn [Src], [Def], [((Text, [Text]))] -> [CDiag]
Array<crate::check::errors::CDiag> test_only_reached(const Array<crate::check::errors::Src>& srcs_p0, const Array<crate::check::env::Def>& defs_p1, const Array<std::tuple<Text, Array<Text>>>& refs_p2) {
    auto in_test_p3 = fold(defs_p1, Map<Text, crate::check::env::Def>{}, [&](const Map<Text, crate::check::env::Def>& m_p4, const crate::check::env::Def& d_p5) {
        return def_role(srcs_p0, d_p5) == Text::lit("test")
            ? insert(m_p4, prism_rtl::deref(d_p5).qk, d_p5)
            : m_p4;
    });
    return crate::prelude::size(in_test_p3) == Nat(0u)
        ? Array<crate::check::errors::CDiag>{}
        : ({
        auto by_key_p6 = fold(defs_p1, Map<Text, crate::check::env::Def>{}, [&](const Map<Text, crate::check::env::Def>& m_p7, const crate::check::env::Def& d_p8) { return insert(m_p7, prism_rtl::deref(d_p8).qk, d_p8); });
        fold(refs_p2, Array<crate::check::errors::CDiag>{}, [&](const Array<crate::check::errors::CDiag>& acc_p9, const std::tuple<Text, Array<Text>>& _p1) {
        auto&& k_pa = std::get<0>(_p1);
        auto&& rs_pb = std::get<1>(_p1);
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::check::errors::CDiag>> _v;
            auto&& _m = crate::prelude::get(by_key_p6, k_pa);
            if (prism_rtl::is_some(_m)) {
                auto&& d_pc = prism_rtl::some_of(_m);
                _v.set(def_role(srcs_p0, d_pc) == Text::lit("test")
                    ? acc_p9
                    : fold(rs_pb, acc_p9, [&](const Array<crate::check::errors::CDiag>& a_pd, const Text& r_pe) {
                    return ({
                        __label__ _done;
                        prism_rtl::Slot<Array<crate::check::errors::CDiag>> _v;
                        auto&& _m = crate::prelude::get(in_test_p3, r_pe);
                        if (prism_rtl::is_some(_m)) {
                            auto&& t_pf = prism_rtl::some_of(_m);
                            _v.set(crate::prelude::push(a_pd, crate::check::errors::CDiag{.code = Text::lit("test-only-reached"), .file = d_pc->file, .span = prism_rtl::deref(d_pc).span, .message = prism_rtl::cat("`", prism_rtl::deref(d_pc).name, "` names `", prism_rtl::deref(t_pf).qk, "`, which a test module declares (", last_path_part(crate::check::errors::seg_at(or_(index(srcs_p0, t_pf->file), crate::check::errors::mk_src(Text::lit(""), Text::lit(""))), prism_rtl::deref(prism_rtl::deref(t_pf).span).start)->path_), "): only test modules name it"), .fix = prism_rtl::cat("move `", prism_rtl::deref(t_pf).qk, "` out of the test module, or `", prism_rtl::deref(d_pc).name, "` into one")}));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(a_pd);
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(acc_p9);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
    });
}


/// DefRole: fn [Src], Def -> Text
Text def_role(const Array<crate::check::errors::Src>& srcs_p0, const crate::check::env::Def& d_p1) {
    return prism_rtl::deref(crate::check::errors::seg_at(or_(index(srcs_p0, d_p1.file), crate::check::errors::mk_src(Text::lit(""), Text::lit(""))), prism_rtl::deref(d_p1.span).start)).role;
}


/// LastPathPart: fn Text -> Text
Text last_path_part(const Text& p_p0) {
    return or_(crate::syntax::lexer::chars::last(split_on(p_p0, Text::lit("/"))), p_p0);
}


/// IsTestingDef: fn Def -> Bool
bool is_testing_def(const crate::check::env::Def& d_p0) {
    auto&& _m = d_p0.body;
    if (prism_rtl::is<crate::check::env::DefBody::DbCheck>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::check::env::DefBody::DbTest>(_m)) {
        return true;
    }
    {
        return false;
    }
}


/// IsMethodDef: fn Def -> Bool
bool is_method_def(const crate::check::env::Def& d_p0) {
    auto&& _m = d_p0.body;
    if (prism_rtl::is<crate::check::env::DefBody::DbMethod>(_m)) {
        return true;
    }
    {
        return false;
    }
}

}  // namespace crate::check::shrink
