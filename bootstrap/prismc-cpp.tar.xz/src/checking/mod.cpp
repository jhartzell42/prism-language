// The module `Checking`, from `target/bootstrap/cpp-src/prismc/checking.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (claude/backend.md). Edit the Prism source, not this file.
#include <checking/module.hpp>
#include <reading/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

namespace crate::checking {

void CheckJob::show(Printer& p) const {
    p.record("CheckJob", {{"read", read}, {"world", world}, {"typed", typed}, {"unused", unused}});
}

Pod CheckJob::to_pod() const {
    return Pod::record("CheckJob", {{"read", prism_rtl::to_pod(read)}, {"world", prism_rtl::to_pod(world)}, {"typed", prism_rtl::to_pod(typed)}, {"unused", prism_rtl::to_pod(unused)}});
}

Result<CheckJob> CheckJob::from_pod(const Pod& whole) {
    return CheckJob{.read = TRY(prism_rtl::from_pod<crate::reading::ReadInput>(TRY(crate::prelude::field(whole, "read")))), .world = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "world")))), .typed = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "typed")))), .unused = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "unused"))))};
}


/// CheckFiles: unbounded fn CheckJob -> Outcome
crate::program::Outcome_ check_files(const CheckJob& job) {
    auto read = crate::reading::assemble(job.read);
    return len(read.errors) > Nat(0u)
        ? ({
        auto report = crate::reading::tree_report(job.read, read.errors);
        crate::program::Outcome_{.text = prism_rtl::cat(report, "\n"), .failed = true, .report = report};
    })
        : ({
        auto pp = crate::reading::parse_program(read);
        pp.errors != Text::lit("")
        ? crate::program::Outcome_{.text = prism_rtl::cat(pp.errors, "parse errors\n"), .failed = true, .report = prism_rtl::cat(pp.errors, "parse errors")}
        : ({
        auto pre = crate::reading::tree_decl_diags(pp);
        auto checked = each(pp.trees, [&](const crate::syntax::Module& t) { return crate::compile::without_tests(t); });
        auto report = crate::check::check_program(pp.srcs, checked, job->world, pp.shown, job.typed, job.unused, pre);
        auto summary = report.errors == Nat(0u)
            ? Text::lit("no errors\n")
            : prism_rtl::cat(report.errors, " error", report.errors == Nat(1u) ? Text::lit("") : Text::lit("s"), "\n");
        auto shown = job.typed
            ? prism_rtl::cat(crate::check::typed::print::typed_sexp(pp.srcs, checked, pp.shown, report.typed), commented(prism_rtl::cat(report->text, summary)))
            : prism_rtl::cat(report->text, summary);
        crate::program::Outcome_{.text = shown, .failed = report.errors > Nat(0u), .report = prism_rtl::cat(report->text, summary)};
    });
    });
}


prism_rtl::Turn<crate::program::Outcome_> CheckFiles::cycle() const {
    const auto& job = this->job;
    auto job_1 = job;
    return call_then(crate::reading::start_assemble(job_1.read), [=](crate::reading::Assembled assemble_1698) {
        return ({
            auto read = assemble_1698;
            len(read.errors) > Nat(0u)
            ? ({
            auto report = crate::reading::tree_report(job_1.read, read.errors);
            (prism_rtl::finished(crate::program::Outcome_{.text = prism_rtl::cat(report, "\n"), .failed = true, .report = report}));
        })
            : call_then(crate::reading::start_parse_program(read), [=](crate::reading::ParsedProgram parse_program_1890) {
            return ({
                auto pp = parse_program_1890;
                pp.errors != Text::lit("")
                ? prism_rtl::finished(crate::program::Outcome_{.text = prism_rtl::cat(pp.errors, "parse errors\n"), .failed = true, .report = prism_rtl::cat(pp.errors, "parse errors")})
                : ({
                auto pre = crate::reading::tree_decl_diags(pp);
                auto checked = each(pp.trees, [&](const crate::syntax::Module& t) { return crate::compile::without_tests(t); });
                call_then(crate::check::start_check_program(pp.srcs, checked, job_1->world, pp.shown, job_1.typed, job_1.unused, pre), [=](crate::check::Report_ check_program_2311) {
                return ({
                    auto report = check_program_2311;
                    auto summary = report.errors == Nat(0u)
                        ? Text::lit("no errors\n")
                        : prism_rtl::cat(report.errors, " error", report.errors == Nat(1u) ? Text::lit("") : Text::lit("s"), "\n");
                    auto shown = job_1.typed
                        ? prism_rtl::cat(crate::check::typed::print::typed_sexp(pp.srcs, checked, pp.shown, report.typed), commented(prism_rtl::cat(report->text, summary)))
                        : prism_rtl::cat(report->text, summary);
                    (prism_rtl::finished(crate::program::Outcome_{.text = shown, .failed = report.errors > Nat(0u), .report = prism_rtl::cat(report->text, summary)}));
                });
            });
            });
            });
        });
        });
    });
}


/// `Start CheckFiles, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::program::Outcome_> start_check_files(CheckJob job) {
    return prism_rtl::make_rc<CheckFiles>(job);
}


/// Commented: fn Text -> Text
Text commented(const Text& t) {
    return concat(each(filter(split(t, Text::lit("\n")), [&](const Text& l) { return l != Text::lit(""); }), [&](const Text& l) { return prism_rtl::cat("; ", l, "\n"); }));
}


// `@CheckMain` is inlined where it is applied.

/// let checkValued
Array<Text> check_valued() {
    return Array(std::vector{Text::lit("--prelude"), Text::lit("--out"), Text::lit("--world")});
}


// `@FinishCheck` is inlined where it is applied.

// `@WriteOut` is inlined where it is applied.

}  // namespace crate::checking
