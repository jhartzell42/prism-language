// The module `Check.Expr.Lifting`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <check/expr/lifting/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>

// The module `Check.Expr.Lifting`, from `target/bootstrap/cpp-src/prismc/check/expr/lifting.prism`.
namespace crate::check::expr::lifting {

/// InferMatch: unbounded fn Env, St, Expr, [Arm], Range, ?Ty -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_match_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Expr& scrut_p2, const Array<crate::syntax::Arm>& arms_p3, const crate::syntax::Range& span_p4, const std::optional<crate::check::types::Ty>& expected_o5) {
    auto [st_ty_pd, st1_pe] = crate::check::expr::infer_f(env_p0, st_p1, scrut_p2);
    auto sh_p6 = crate::check::types::head_sigil_f(st1_pe, st_ty_pd);
    auto plain_scrut_p7 = crate::check::expr::is_time_sigil_f(sh_p6)
        ? crate::check::expr::inner_of_f(st1_pe, st_ty_pd)
        : st_ty_pd;
    auto st2_p8 = sh_p6 == Text::lit("@")
        ? crate::check::types::recording::err_f(st1_pe, Text::lit("blueprint-operand"), scrut_p2.span_p, Text::lit("`match` over a blueprint; bind it first"))
        : st1_pe;
    auto rigid_out_o9 = ({
        __label__ _done;
        prism_rtl::Slot<std::optional<Text>> _v;
        auto&& _m = crate::check::types::recording::walk_f(st2_p8, plain_scrut_p7);
        if (prism_rtl::is<crate::check::types::Ty::TyElem>(_m)) {
            auto&& o_pf = prism_rtl::as<crate::check::types::Ty::TyElem>(_m).a1;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::optional<Text>> _v;
                auto&& _m = crate::check::types::recording::walk_f(st2_p8, prism_rtl::deref(o_pf));
                if (prism_rtl::is<crate::check::types::Ty::TyRigid>(_m)) {
                    auto&& name_pg = prism_rtl::as<crate::check::types::Ty::TyRigid>(_m).a0;
                    _v.set(std::optional(name_pg));
                    goto _done;
                }
                {
                    _v.set(std::optional<Text>{});
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        {
            _v.set(std::optional<Text>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto [res_ph, st3_pi] = crate::check::types::fresh_var_f(st2_p8, false, Text::lit(""));
    auto checking_pa = (expected_o5 != std::optional<crate::check::types::Ty>{}) && (!crate::check::expr::is_time_sigil_f(sh_p6));
    auto scrut_name_pb = crate::check::shrink::locals::expr_name_f(scrut_p2);
    auto&& _layers_pq = crate::prelude::run_to_end(crate::prelude::fold_job(arms_p3, std::tuple{Array<std::tuple<Text, crate::syntax::Range>>{}, st3_pi, Array<Text>{}}, ({
        auto env_p0x = env_p0;
        auto scrut_name_pbx = scrut_name_pb;
        auto plain_scrut_p7x = plain_scrut_p7;
        auto res_phx = res_ph;
        auto checking_pax = std::move(checking_pa);
        auto expected_o5x = expected_o5;
        auto rigid_out_o9x = rigid_out_o9;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::check::types::St, Array<Text>>>(std::tuple<std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::check::types::St, Array<Text>>, crate::syntax::Arm>)>>(prism_rtl::rc([=, env_p0x = std::move(env_p0x), scrut_name_pbx = std::move(scrut_name_pbx), plain_scrut_p7x = std::move(plain_scrut_p7x), res_phx = std::move(res_phx), checking_pax = std::move(checking_pax), expected_o5x = std::move(expected_o5x), rigid_out_o9x = std::move(rigid_out_o9x)](std::tuple<std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::check::types::St, Array<Text>>, crate::syntax::Arm> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_p0xy = env_p0x;
            auto scrut_name_pbxy = scrut_name_pbx;
            auto plain_scrut_p7xy = plain_scrut_p7x;
            auto res_phxy = res_phx;
            auto checking_paxy = checking_pax;
            auto expected_o5xy = expected_o5x;
            auto rigid_out_o9xy = rigid_out_o9x;
            (crate::prelude::entered(crate::prelude::once_job([=, env_p0xy = std::move(env_p0xy), scrut_name_pbxy = std::move(scrut_name_pbxy), plain_scrut_p7xy = std::move(plain_scrut_p7xy), res_phxy = std::move(res_phxy), checking_paxy = std::move(checking_paxy), expected_o5xy = std::move(expected_o5xy), rigid_out_o9xy = std::move(rigid_out_o9xy)]() {
            return ({
                auto [acc_pj, s_pk, taken_pl] = p0;
                auto arm_pm = p1;
                (crate::prelude::call_then(start_narrowed_f(env_p0xy, s_pk, arm_pm, scrut_name_pbxy, plain_scrut_p7xy, taken_pl), [=](crate::check::expr::Env narrowed_f_2375) {
                return ({
                    auto env_arm_pn = narrowed_f_2375;
                    (crate::prelude::call_then(start_infer_arm_f(env_arm_pn, s_pk, arm_pm, plain_scrut_p7xy, res_phxy, checking_paxy ? expected_o5xy : std::optional<crate::check::types::Ty>{}, rigid_out_o9xy, acc_pj), [=](std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::check::types::St> infer_arm_f_2453) {
                    return ({
                        auto [acc2_po, s2_pp] = infer_arm_f_2453;
                        (prism_rtl::finished(std::tuple{acc2_po, s2_pp, taken_by_f(env_p0xy, arm_pm, taken_pl)}));
                    });
                }));
                });
            }));
            });
        })));
        });
    }));
    })));
    auto&& layers_pq = std::get<0>(_layers_pq);
    auto&& st4_pr = std::get<1>(_layers_pq);
    auto st5_pc = crate::check::passes::match_coverage_f(env_p0, st4_pr, plain_scrut_p7, arms_p3, span_p4);
    if (prism_rtl::is_some(expected_o5)) {
        auto&& want_ps = prism_rtl::some_of(expected_o5);
        return std::move(checking_pa)
            ? std::tuple{want_ps, st5_pc}
            : match_result_f(env_p0, st5_pc, sh_p6, layers_pq, res_ph, span_p4);
    }
    if (prism_rtl::is_none(expected_o5)) {
        return match_result_f(env_p0, st5_pc, sh_p6, layers_pq, res_ph, span_p4);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InferMatch::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& scrut_p2 = this->scrut_p2;
    const auto& arms_p3 = this->arms_p3;
    const auto& span_p4 = this->span_p4;
    const auto& expected_o5 = this->expected_o5;
    auto expected_o5x = expected_o5;
    auto arms_p3x = arms_p3;
    auto env_p0x = env_p0;
    auto scrut_p2x = scrut_p2;
    auto span_p4x = span_p4;
    auto st_p1x = st_p1;
    return crate::prelude::call_then(crate::check::expr::start_infer_f(env_p0x, st_p1x, scrut_p2x), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_f_1698) {
        return ({
            auto [st_ty_pd, st1_pe] = infer_f_1698;
            (crate::prelude::call_then(crate::check::types::start_head_sigil_f(st1_pe, st_ty_pd), [=](Text head_sigil_f_1732) {
            return ({
                auto sh_p6 = head_sigil_f_1732;
                auto plain_scrut_p7 = crate::check::expr::is_time_sigil_f(sh_p6)
                    ? crate::check::expr::inner_of_f(st1_pe, st_ty_pd)
                    : st_ty_pd;
                auto st2_p8 = sh_p6 == Text::lit("@")
                    ? crate::check::types::recording::err_f(st1_pe, Text::lit("blueprint-operand"), prism_rtl::deref(scrut_p2x).span_p, Text::lit("`match` over a blueprint; bind it first"))
                    : st1_pe;
                (crate::prelude::call_then(crate::check::types::recording::start_walk_f(st2_p8, plain_scrut_p7), [=, sh_p6 = std::move(sh_p6)](crate::check::types::Ty walk_f_1969) {
                return ({
                    auto rigid_out_o9 = ({
                        __label__ _done;
                        prism_rtl::Slot<std::optional<Text>> _v;
                        if (prism_rtl::is<crate::check::types::Ty::TyElem>(walk_f_1969)) {
                            auto&& o_pf = prism_rtl::as<crate::check::types::Ty::TyElem>(walk_f_1969).a1;
                            _v.set(({
                                __label__ _done;
                                prism_rtl::Slot<std::optional<Text>> _v;
                                auto&& _m = crate::check::types::recording::walk_f(st2_p8, prism_rtl::deref(o_pf));
                                if (prism_rtl::is<crate::check::types::Ty::TyRigid>(_m)) {
                                    auto&& name_pg = prism_rtl::as<crate::check::types::Ty::TyRigid>(_m).a0;
                                    _v.set(std::optional(name_pg));
                                    goto _done;
                                }
                                {
                                    _v.set(std::optional<Text>{});
                                    goto _done;
                                }
                            _done:
                                _v.take();
                            }));
                            goto _done;
                        }
                        {
                            _v.set(std::optional<Text>{});
                            goto _done;
                        }
                    _done:
                        _v.take();
                    });
                    auto [res_ph, st3_pi] = crate::check::types::fresh_var_f(st2_p8, false, Text::lit(""));
                    auto checking_pa = (expected_o5x != std::optional<crate::check::types::Ty>{}) && (!crate::check::expr::is_time_sigil_f(sh_p6));
                    auto scrut_name_pb = crate::check::shrink::locals::expr_name_f(scrut_p2x);
                    (crate::prelude::call_value(crate::prelude::fold_job(arms_p3x, std::tuple{Array<std::tuple<Text, crate::syntax::Range>>{}, st3_pi, Array<Text>{}}, ({
                    auto env_p0xx = env_p0x;
                    auto scrut_name_pbx = scrut_name_pb;
                    auto plain_scrut_p7x = plain_scrut_p7;
                    auto res_phx = res_ph;
                    auto checking_pax = std::move(checking_pa);
                    auto expected_o5xx = expected_o5x;
                    auto rigid_out_o9x = rigid_out_o9;
                    static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::check::types::St, Array<Text>>>(std::tuple<std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::check::types::St, Array<Text>>, crate::syntax::Arm>)>>(prism_rtl::rc([=, env_p0xx = std::move(env_p0xx), scrut_name_pbx = std::move(scrut_name_pbx), plain_scrut_p7x = std::move(plain_scrut_p7x), res_phx = std::move(res_phx), checking_pax = std::move(checking_pax), expected_o5xx = std::move(expected_o5xx), rigid_out_o9x = std::move(rigid_out_o9x)](std::tuple<std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::check::types::St, Array<Text>>, crate::syntax::Arm> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto env_p0xxy = env_p0xx;
                        auto scrut_name_pbxy = scrut_name_pbx;
                        auto plain_scrut_p7xy = plain_scrut_p7x;
                        auto res_phxy = res_phx;
                        auto checking_paxy = checking_pax;
                        auto expected_o5xxy = expected_o5xx;
                        auto rigid_out_o9xy = rigid_out_o9x;
                        (crate::prelude::entered(crate::prelude::once_job([=, env_p0xxy = std::move(env_p0xxy), scrut_name_pbxy = std::move(scrut_name_pbxy), plain_scrut_p7xy = std::move(plain_scrut_p7xy), res_phxy = std::move(res_phxy), checking_paxy = std::move(checking_paxy), expected_o5xxy = std::move(expected_o5xxy), rigid_out_o9xy = std::move(rigid_out_o9xy)]() {
                        return ({
                            auto [acc_pj, s_pk, taken_pl] = p0;
                            auto arm_pm = p1;
                            (crate::prelude::call_then(start_narrowed_f(env_p0xxy, s_pk, arm_pm, scrut_name_pbxy, plain_scrut_p7xy, taken_pl), [=](crate::check::expr::Env narrowed_f_2375) {
                            return ({
                                auto env_arm_pn = narrowed_f_2375;
                                (crate::prelude::call_then(start_infer_arm_f(env_arm_pn, s_pk, arm_pm, plain_scrut_p7xy, res_phxy, checking_paxy ? expected_o5xxy : std::optional<crate::check::types::Ty>{}, rigid_out_o9xy, acc_pj), [=](std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::check::types::St> infer_arm_f_2453) {
                                return ({
                                    auto [acc2_po, s2_pp] = infer_arm_f_2453;
                                    (prism_rtl::finished(std::tuple{acc2_po, s2_pp, taken_by_f(env_p0xxy, arm_pm, taken_pl)}));
                                });
                            }));
                            });
                        }));
                        });
                    })));
                    });
                }));
                })), [=](std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::check::types::St, Array<Text>> fold_2296) {
                    return ({
                        auto&& _layers_pq = fold_2296;
                        auto&& layers_pq = std::get<0>(_layers_pq);
                        auto&& st4_pr = std::get<1>(_layers_pq);
                        (crate::prelude::call_then(crate::check::passes::start_match_coverage_f(env_p0x, st4_pr, plain_scrut_p7, arms_p3x, span_p4x), [=](crate::check::types::St match_coverage_f_2608) {
                        return ({
                            auto st5_pc = match_coverage_f_2608;
                            ({
                            prism_rtl::is_some(expected_o5x) ? ({
                            auto&& want_ps = prism_rtl::some_of(expected_o5x);
                            checking_pa
                            ? prism_rtl::finished(std::tuple{want_ps, st5_pc})
                            : prism_rtl::more(prism_rtl::rc(MatchResult(env_p0x, st5_pc, sh_p6, layers_pq, res_ph, span_p4x)));
                        })
                            : prism_rtl::is_none(expected_o5x) ? prism_rtl::more(prism_rtl::rc(MatchResult(env_p0x, st5_pc, sh_p6, layers_pq, res_ph, span_p4x)))
                            : throw prism_rtl::Panic("no arm matched");
                        });
                        });
                    }));
                    });
                }));
                });
            }));
            });
        }));
        });
    });
}


/// `Start InferMatch, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_match_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Expr scrut_p2, Array<crate::syntax::Arm> arms_p3, crate::syntax::Range span_p4, std::optional<crate::check::types::Ty> expected_o5) {
    return prism_rtl::make_rc<InferMatch>(env_p0, st_p1, scrut_p2, arms_p3, span_p4, expected_o5);
}


/// TakenBy: fn Env, Arm, [Text] -> [Text]
Array<Text> taken_by_f(const crate::check::expr::Env& env_p0, const crate::syntax::Arm& arm_p1, const Array<Text>& taken_p2) {
    return arm_p1.guard_o != std::optional<crate::syntax::Expr>{}
        ? taken_p2
        : ({
        __label__ _done;
        prism_rtl::Slot<Array<Text>> _v;
        auto&& _m = arm_p1.pattern_o;
        if (prism_rtl::is_some(_m)) {
            auto&& p_p3 = prism_rtl::some_of(_m);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<Array<Text>> _v;
                auto&& _m = prism_rtl::deref(prism_rtl::deref(p_p3).kind_p);
                if (prism_rtl::is<crate::syntax::PatternKind::PFamily>(_m)) {
                    auto&& q_p4 = prism_rtl::as<crate::syntax::PatternKind::PFamily>(_m).a0;
                    _v.set(crate::check::types::union_texts_f(taken_p2, crate::prelude::or_(crate::prelude::get(prism_rtl::deref(env_p0.g_p).families_p, crate::check::env::dotted_f(prism_rtl::deref(q_p4).path_p)), Array<Text>{})));
                    goto _done;
                }
                {
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<Array<Text>> _v;
                        auto&& _m = tag_of_pattern_o(env_p0, p_p3);
                        if (prism_rtl::is_some(_m)) {
                            auto&& tg_p5 = prism_rtl::some_of(_m);
                            _v.set(crate::check::types::add_text_f(taken_p2, prism_rtl::deref(tg_p5).name_p));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(taken_p2);
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(taken_p2);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// Narrowed: unbounded fn Env, St, Arm, Text, Ty, [Text] -> Env
crate::check::expr::Env narrowed_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Arm& arm_p2, const Text& name_p3, const crate::check::types::Ty& t_p4, const Array<Text>& taken_p5) {
    auto forwards_p6 = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = arm_p2.pattern_o;
        if (prism_rtl::is_some(_m)) {
            auto&& p_p7 = prism_rtl::some_of(_m);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<bool> _v;
                auto&& _m = prism_rtl::deref(prism_rtl::deref(p_p7).kind_p);
                if (prism_rtl::is<crate::syntax::PatternKind::PFamily>(_m)) {
                    _v.set(true);
                    goto _done;
                }
                {
                    _v.set(false);
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(true);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return ((!std::move(forwards_p6)) || (name_p3 == Text::lit(""))) || (crate::prelude::len(taken_p5) == Nat(0u))
        ? env_p0
        : ({
        __label__ _done;
        prism_rtl::Slot<crate::check::expr::Env> _v;
        auto&& _m = crate::check::types::recording::walk_f(st_p1, t_p4);
        if (prism_rtl::is<crate::check::types::Ty::TyElem>(_m)) {
            auto&& rw_p8 = prism_rtl::as<crate::check::types::Ty::TyElem>(_m).a0;
            auto&& o_p9 = prism_rtl::as<crate::check::types::Ty::TyElem>(_m).a1;
            _v.set(({
                auto w_pa = crate::check::types::recording::walk_row_f(st_p1, rw_p8);
                (crate::check::expr::with_local_f(env_p0, name_p3, crate::check::types::schemes::mono_f(crate::check::types::Ty(crate::check::types::Ty::TyElem{crate::check::types::Rw{.fams_p = prism_rtl::deref(w_pa).fams_p, .minus_p = crate::check::types::union_texts_f(prism_rtl::deref(w_pa).minus_p, taken_p5), .tail_p = prism_rtl::deref(w_pa).tail_p}, prism_rtl::rc(prism_rtl::deref(o_p9))}))));
            }));
            goto _done;
        }
        {
            _v.set(env_p0);
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<crate::check::expr::Env> Narrowed::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& arm_p2 = this->arm_p2;
    const auto& name_p3 = this->name_p3;
    const auto& t_p4 = this->t_p4;
    const auto& taken_p5 = this->taken_p5;
    auto forwards_p6 = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = prism_rtl::deref(arm_p2).pattern_o;
        if (prism_rtl::is_some(_m)) {
            auto&& p_p7 = prism_rtl::some_of(_m);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<bool> _v;
                auto&& _m = prism_rtl::deref(prism_rtl::deref(p_p7).kind_p);
                if (prism_rtl::is<crate::syntax::PatternKind::PFamily>(_m)) {
                    _v.set(true);
                    goto _done;
                }
                {
                    _v.set(false);
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(true);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return ((!std::move(forwards_p6)) || (name_p3 == Text::lit(""))) || (crate::prelude::len(taken_p5) == Nat(0u))
        ? prism_rtl::finished(env_p0)
        : ({
        auto arm_p2x = arm_p2;
        auto env_p0x = env_p0;
        auto name_p3x = name_p3;
        auto st_p1x = st_p1;
        auto t_p4x = t_p4;
        auto taken_p5x = taken_p5;
        (crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p1x, t_p4x), [=, env_p0x = std::move(env_p0x), name_p3x = std::move(name_p3x), taken_p5x = std::move(taken_p5x)](crate::check::types::Ty walk_f_3793) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TyElem>(walk_f_3793) ? ({
            auto&& rw_p8 = prism_rtl::as<crate::check::types::Ty::TyElem>(walk_f_3793).a0;
            auto&& o_p9 = prism_rtl::as<crate::check::types::Ty::TyElem>(walk_f_3793).a1;
            crate::prelude::call_then(crate::check::types::recording::start_walk_row_f(st_p1x, rw_p8), [=](crate::check::types::Rw walk_row_f_3847) {
            return ({
                auto w_pa = walk_row_f_3847;
                (prism_rtl::finished(crate::check::expr::with_local_f(env_p0x, name_p3x, crate::check::types::schemes::mono_f(crate::check::types::Ty(crate::check::types::Ty::TyElem{crate::check::types::Rw{.fams_p = prism_rtl::deref(w_pa).fams_p, .minus_p = crate::check::types::union_texts_f(prism_rtl::deref(w_pa).minus_p, taken_p5x), .tail_p = prism_rtl::deref(w_pa).tail_p}, prism_rtl::rc(prism_rtl::deref(o_p9))})))));
            });
        });
        })
            : prism_rtl::finished(env_p0x);
        });
    }));
    });
}


/// `Start Narrowed, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::expr::Env> start_narrowed_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Arm arm_p2, Text name_p3, crate::check::types::Ty t_p4, Array<Text> taken_p5) {
    return prism_rtl::make_rc<Narrowed>(env_p0, st_p1, arm_p2, name_p3, t_p4, taken_p5);
}


/// InferArm: unbounded fn Env, St, Arm, Ty, Ty, ?Ty, ?Text, [((Text, Range))] -> (([((Text, Range))], St))
std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::check::types::St> infer_arm_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Arm& arm_p2, const crate::check::types::Ty& scrut_ty_p3, const crate::check::types::Ty& res_p4, const std::optional<crate::check::types::Ty>& expected_o5, const std::optional<Text>& rigid_out_o6, const Array<std::tuple<Text, crate::syntax::Range>>& acc_p7) {
    auto [env2_pb, st1_pc] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::check::expr::Env, crate::check::types::St>> _v;
        auto&& _m = arm_p2.pattern_o;
        if (prism_rtl::is_some(_m)) {
            auto&& p_pa = prism_rtl::some_of(_m);
            _v.set(crate::check::expr::patterns::bind_pattern_f(env_p0, st_p1, p_pa, scrut_ty_p3, true));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(std::tuple{env_p0, st_p1});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto refined_out_o8 = ({
        __label__ _done;
        prism_rtl::Slot<std::optional<std::tuple<Text, crate::check::types::Ty>>> _v;
        if (prism_rtl::is_some(rigid_out_o6)) {
            auto&& o_pd = prism_rtl::some_of(rigid_out_o6);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::optional<std::tuple<Text, crate::check::types::Ty>>> _v;
                auto&& _m = arm_p2.pattern_o;
                if (prism_rtl::is_some(_m)) {
                    auto&& p_pe = prism_rtl::some_of(_m);
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<std::optional<std::tuple<Text, crate::check::types::Ty>>> _v;
                        auto&& _m = tag_of_pattern_o(env_p0, p_pe);
                        if (prism_rtl::is_some(_m)) {
                            auto&& tg_pf = prism_rtl::some_of(_m);
                            _v.set(std::optional(std::tuple{o_pd, prism_rtl::deref(tg_pf).out_p}));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(std::optional<std::tuple<Text, crate::check::types::Ty>>{});
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(std::optional<std::tuple<Text, crate::check::types::Ty>>{});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_none(rigid_out_o6)) {
            _v.set(std::optional<std::tuple<Text, crate::check::types::Ty>>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto st2_p9 = ({
        __label__ _done;
        prism_rtl::Slot<crate::check::types::St> _v;
        auto&& _m = arm_p2.guard_o;
        if (prism_rtl::is_some(_m)) {
            auto&& gd_pg = prism_rtl::some_of(_m);
            _v.set(check_cond_f(env2_pb, st1_pc, gd_pg));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(st1_pc);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    if (prism_rtl::is_some(expected_o5)) {
        auto&& want_ph = prism_rtl::some_of(expected_o5);
        auto refined_pi = ({
            __label__ _done;
            prism_rtl::Slot<crate::check::types::Ty> _v;
            if (prism_rtl::is_some(refined_out_o8)) {
                auto&& o_pj = std::get<0>(prism_rtl::some_of(refined_out_o8));
                auto&& out_pk = std::get<1>(prism_rtl::some_of(refined_out_o8));
                _v.set(subst_rigid_f(o_pj, out_pk, crate::check::types::recording::zonk_f(st2_p9, want_ph)));
                goto _done;
            }
            if (prism_rtl::is_none(refined_out_o8)) {
                _v.set(want_ph);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto [bt_pl, st3_pm] = crate::check::expr::lets::infer_expr_block_f(env2_pb, st2_p9, arm_p2.body_p);
        return std::tuple{acc_p7, arm_against_f(st3_pm, refined_pi, bt_pl, prism_rtl::deref(arm_p2.body_p).span_p, (arm_p2.pattern_o == std::optional<crate::syntax::Pattern_>{}) || is_family_arm_f(arm_p2))};
    }
    if (prism_rtl::is_none(expected_o5)) {
        auto [bt_ps, st3_pt] = crate::check::expr::lets::infer_expr_block_f(env2_pb, st2_p9, arm_p2.body_p);
        auto head_pn = crate::check::types::head_sigil_f(st3_pt, bt_ps);
        auto plain_bt_po = crate::check::expr::is_time_sigil_f(head_pn)
            ? crate::check::expr::inner_of_f(st3_pt, bt_ps)
            : bt_ps;
        auto st4_pp = unify_arm_f(st3_pt, res_p4, plain_bt_po, prism_rtl::deref(arm_p2.body_p).span_p);
        auto acc2_pq = crate::check::expr::is_time_sigil_f(head_pn)
            ? crate::prelude::push(acc_p7, std::tuple{head_pn, prism_rtl::deref(arm_p2.body_p).span_p})
            : crate::prelude::push(acc_p7, std::tuple{Text::lit(""), prism_rtl::deref(arm_p2.body_p).span_p});
        auto acc3_pr = head_pn == Text::lit("@")
            ? crate::prelude::push(acc2_pq, std::tuple{Text::lit("@"), prism_rtl::deref(arm_p2.body_p).span_p})
            : acc2_pq;
        return std::tuple{acc3_pr, st4_pp};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::check::types::St>> InferArm::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& arm_p2 = this->arm_p2;
    const auto& scrut_ty_p3 = this->scrut_ty_p3;
    const auto& res_p4 = this->res_p4;
    const auto& expected_o5 = this->expected_o5;
    const auto& rigid_out_o6 = this->rigid_out_o6;
    const auto& acc_p7 = this->acc_p7;
    auto [env2_pb, st1_pc] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::check::expr::Env, crate::check::types::St>> _v;
        auto&& _m = prism_rtl::deref(arm_p2).pattern_o;
        if (prism_rtl::is_some(_m)) {
            auto&& p_pa = prism_rtl::some_of(_m);
            _v.set(crate::check::expr::patterns::bind_pattern_f(env_p0, st_p1, p_pa, scrut_ty_p3, true));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(std::tuple{env_p0, st_p1});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto refined_out_o8 = ({
        __label__ _done;
        prism_rtl::Slot<std::optional<std::tuple<Text, crate::check::types::Ty>>> _v;
        if (prism_rtl::is_some(rigid_out_o6)) {
            auto&& o_pd = prism_rtl::some_of(rigid_out_o6);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::optional<std::tuple<Text, crate::check::types::Ty>>> _v;
                auto&& _m = prism_rtl::deref(arm_p2).pattern_o;
                if (prism_rtl::is_some(_m)) {
                    auto&& p_pe = prism_rtl::some_of(_m);
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<std::optional<std::tuple<Text, crate::check::types::Ty>>> _v;
                        auto&& _m = tag_of_pattern_o(env_p0, p_pe);
                        if (prism_rtl::is_some(_m)) {
                            auto&& tg_pf = prism_rtl::some_of(_m);
                            _v.set(std::optional(std::tuple{o_pd, prism_rtl::deref(tg_pf).out_p}));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(std::optional<std::tuple<Text, crate::check::types::Ty>>{});
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(std::optional<std::tuple<Text, crate::check::types::Ty>>{});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_none(rigid_out_o6)) {
            _v.set(std::optional<std::tuple<Text, crate::check::types::Ty>>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto st2_p9 = ({
        __label__ _done;
        prism_rtl::Slot<crate::check::types::St> _v;
        auto&& _m = prism_rtl::deref(arm_p2).guard_o;
        if (prism_rtl::is_some(_m)) {
            auto&& gd_pg = prism_rtl::some_of(_m);
            _v.set(check_cond_f(env2_pb, st1_pc, gd_pg));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(st1_pc);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return ({
        prism_rtl::is_some(expected_o5) ? ({
        auto&& want_ph = prism_rtl::some_of(expected_o5);
        ({
        auto refined_pi = ({
            __label__ _done;
            prism_rtl::Slot<crate::check::types::Ty> _v;
            if (prism_rtl::is_some(refined_out_o8)) {
                auto&& o_pj = std::get<0>(prism_rtl::some_of(refined_out_o8));
                auto&& out_pk = std::get<1>(prism_rtl::some_of(refined_out_o8));
                _v.set(subst_rigid_f(o_pj, out_pk, crate::check::types::recording::zonk_f(st2_p9, want_ph)));
                goto _done;
            }
            if (prism_rtl::is_none(refined_out_o8)) {
                _v.set(want_ph);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto acc_p7x = acc_p7;
        auto arm_p2x = arm_p2;
        (crate::prelude::call_then(crate::check::expr::lets::start_infer_expr_block_f(env2_pb, st2_p9, prism_rtl::deref(arm_p2x).body_p), [=, refined_pi = std::move(refined_pi), acc_p7x = std::move(acc_p7x)](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_expr_block_f_4943) {
        return ({
            auto [bt_pl, st3_pm] = infer_expr_block_f_4943;
            (crate::prelude::call_then(start_arm_against_f(st3_pm, refined_pi, bt_pl, prism_rtl::deref(prism_rtl::deref(arm_p2x).body_p).span_p, (prism_rtl::deref(arm_p2x).pattern_o == std::optional<crate::syntax::Pattern_>{}) || is_family_arm_f(arm_p2x)), [=](crate::check::types::St arm_against_f_4998) { return prism_rtl::finished(std::tuple{acc_p7x, arm_against_f_4998}); }));
        });
    }));
    });
    })
        : prism_rtl::is_none(expected_o5) ? ({
        auto acc_p7x = acc_p7;
        auto arm_p2x = arm_p2;
        auto res_p4x = res_p4;
        (crate::prelude::call_then(crate::check::expr::lets::start_infer_expr_block_f(env2_pb, st2_p9, prism_rtl::deref(arm_p2x).body_p), [=, acc_p7x = std::move(acc_p7x), res_p4x = std::move(res_p4x)](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_expr_block_f_5131) {
        return ({
            auto [bt_ps, st3_pt] = infer_expr_block_f_5131;
            (crate::prelude::call_then(crate::check::types::start_head_sigil_f(st3_pt, bt_ps), [=](Text head_sigil_f_5189) {
            return ({
                auto head_pn = head_sigil_f_5189;
                auto plain_bt_po = crate::check::expr::is_time_sigil_f(head_pn)
                    ? crate::check::expr::inner_of_f(st3_pt, bt_ps)
                    : bt_ps;
                (crate::prelude::call_then(start_unify_arm_f(st3_pt, res_p4x, plain_bt_po, prism_rtl::deref(prism_rtl::deref(arm_p2x).body_p).span_p), [=, head_pn = std::move(head_pn)](crate::check::types::St unify_arm_f_5301) {
                return ({
                    auto st4_pp = unify_arm_f_5301;
                    auto acc2_pq = crate::check::expr::is_time_sigil_f(head_pn)
                        ? crate::prelude::push(acc_p7x, std::tuple{head_pn, prism_rtl::deref(prism_rtl::deref(arm_p2x).body_p).span_p})
                        : crate::prelude::push(acc_p7x, std::tuple{Text::lit(""), prism_rtl::deref(prism_rtl::deref(arm_p2x).body_p).span_p});
                    auto acc3_pr = head_pn == Text::lit("@")
                        ? crate::prelude::push(acc2_pq, std::tuple{Text::lit("@"), prism_rtl::deref(prism_rtl::deref(arm_p2x).body_p).span_p})
                        : acc2_pq;
                    (prism_rtl::finished(std::tuple{acc3_pr, st4_pp}));
                });
            }));
            });
        }));
        });
    }));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start InferArm, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::check::types::St>> start_infer_arm_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Arm arm_p2, crate::check::types::Ty scrut_ty_p3, crate::check::types::Ty res_p4, std::optional<crate::check::types::Ty> expected_o5, std::optional<Text> rigid_out_o6, Array<std::tuple<Text, crate::syntax::Range>> acc_p7) {
    return prism_rtl::make_rc<InferArm>(env_p0, st_p1, arm_p2, scrut_ty_p3, res_p4, expected_o5, rigid_out_o6, acc_p7);
}


/// ArmAgainst: unbounded fn St, Ty, Ty, Range, Bool -> St
crate::check::types::St arm_against_f(const crate::check::types::St& st_p0, const crate::check::types::Ty& want_p1, const crate::check::types::Ty& bt_p2, const crate::syntax::Range& span_p3, const bool& forwards_p4) {
    auto&& _m = std::tuple{crate::check::types::recording::walk_f(st_p0, want_p1), crate::check::types::recording::walk_f(st_p0, bt_p2)};
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyAt>(std::get<1>(_m))) {
        auto&& w1_p5 = prism_rtl::as<crate::check::types::Ty::TyAt>(std::get<0>(_m)).a0;
        auto&& r1_p6 = prism_rtl::as<crate::check::types::Ty::TyAt>(std::get<0>(_m)).a1;
        auto&& b1_p7 = prism_rtl::as<crate::check::types::Ty::TyAt>(std::get<1>(_m)).a0;
        auto&& r2_p8 = prism_rtl::as<crate::check::types::Ty::TyAt>(std::get<1>(_m)).a1;
        auto st2_p9 = crate::check::types::unify::unify_f(st_p0, prism_rtl::deref(w1_p5), prism_rtl::deref(b1_p7), span_p3);
        crate::check::types::St this_ = st2_p9;
        this_.incls_p = crate::prelude::push(this_.incls_p, crate::check::types::Incl{.sub_p = r2_p8, .sup_p = r1_p6, .file_p = this_.file_p, .span_p = span_p3, .what_p = Text::lit("arm"), .forward_p = forwards_p4});
        return this_;
    }
    {
        return crate::check::types::unify::unify_f(st_p0, want_p1, bt_p2, span_p3);
    }
}


prism_rtl::Turn<crate::check::types::St> ArmAgainst::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& want_p1 = this->want_p1;
    const auto& bt_p2 = this->bt_p2;
    const auto& span_p3 = this->span_p3;
    const auto& forwards_p4 = this->forwards_p4;
    auto bt_p2x = bt_p2;
    auto forwards_p4x = prism_rtl::deref(forwards_p4);
    auto span_p3x = span_p3;
    auto st_p0x = st_p0;
    auto want_p1x = want_p1;
    return crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p0x, want_p1x), [=](crate::check::types::Ty walk_f_5855) {
        return crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p0x, bt_p2x), [=](crate::check::types::Ty walk_f_5872) {
            return ({
                auto&& _m = std::tuple{walk_f_5855, walk_f_5872};
                prism_rtl::is<crate::check::types::Ty::TyAt>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyAt>(std::get<1>(_m)) ? ({
                auto&& w1_p5 = prism_rtl::as<crate::check::types::Ty::TyAt>(std::get<0>(_m)).a0;
                auto&& r1_p6 = prism_rtl::as<crate::check::types::Ty::TyAt>(std::get<0>(_m)).a1;
                auto&& b1_p7 = prism_rtl::as<crate::check::types::Ty::TyAt>(std::get<1>(_m)).a0;
                auto&& r2_p8 = prism_rtl::as<crate::check::types::Ty::TyAt>(std::get<1>(_m)).a1;
                crate::prelude::call_then(crate::check::types::unify::start_unify_f(st_p0x, prism_rtl::deref(w1_p5), prism_rtl::deref(b1_p7), span_p3x), [=](crate::check::types::St unify_f_5944) {
                return ({
                    auto st2_p9 = unify_f_5944;
                    (prism_rtl::finished(({
                    crate::check::types::St this_ = st2_p9;
                    this_.incls_p = crate::prelude::push(this_.incls_p, crate::check::types::Incl{.sub_p = r2_p8, .sup_p = r1_p6, .file_p = this_.file_p, .span_p = span_p3x, .what_p = Text::lit("arm"), .forward_p = forwards_p4x});
                    (std::move(this_));
                })));
                });
            });
            })
                : prism_rtl::more(prism_rtl::rc(crate::check::types::unify::Unify(st_p0x, want_p1x, bt_p2x, span_p3x)));
            });
        });
    });
}


/// `Start ArmAgainst, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_arm_against_f(crate::check::types::St st_p0, crate::check::types::Ty want_p1, crate::check::types::Ty bt_p2, crate::syntax::Range span_p3, bool forwards_p4) {
    return prism_rtl::make_rc<ArmAgainst>(st_p0, want_p1, bt_p2, span_p3, forwards_p4);
}


/// IsFamilyArm: fn Arm -> Bool
bool is_family_arm_f(const crate::syntax::Arm& arm_p0) {
    auto&& _m = arm_p0.pattern_o;
    if (prism_rtl::is_some(_m)) {
        auto&& p_p1 = prism_rtl::some_of(_m);
        auto&& _m = prism_rtl::deref(prism_rtl::deref(p_p1).kind_p);
        if (prism_rtl::is<crate::syntax::PatternKind::PFamily>(_m)) {
            return true;
        }
        {
            return false;
        }
    }
    if (prism_rtl::is_none(_m)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// CheckCond: unbounded fn Env, St, Expr -> St
crate::check::types::St check_cond_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Expr& e_p2) {
    auto [t_p4, st2_p5] = crate::check::expr::infer_f(env_p0, st_p1, e_p2);
    auto inner_p3 = crate::check::expr::is_time_sigil_f(crate::check::types::head_sigil_f(st2_p5, t_p4))
        ? crate::check::expr::inner_of_f(st2_p5, t_p4)
        : t_p4;
    return crate::check::types::unify::unify_f(st2_p5, crate::check::types::t_bool_p(), inner_p3, e_p2.span_p);
}


prism_rtl::Turn<crate::check::types::St> CheckCond::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& e_p2 = this->e_p2;
    auto e_p2x = e_p2;
    auto env_p0x = env_p0;
    auto st_p1x = st_p1;
    return crate::prelude::call_then(crate::check::expr::start_infer_f(env_p0x, st_p1x, e_p2x), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_f_6481) {
        return ({
            auto [t_p4, st2_p5] = infer_f_6481;
            (crate::prelude::call_then(crate::check::types::start_head_sigil_f(st2_p5, t_p4), [=](Text head_sigil_f_6530) {
            return ({
                auto inner_p3 = crate::check::expr::is_time_sigil_f(head_sigil_f_6530)
                    ? crate::check::expr::inner_of_f(st2_p5, t_p4)
                    : t_p4;
                (prism_rtl::more(prism_rtl::rc(crate::check::types::unify::Unify(st2_p5, crate::check::types::t_bool_p(), inner_p3, prism_rtl::deref(e_p2x).span_p))));
            });
        }));
        });
    });
}


/// `Start CheckCond, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_check_cond_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Expr e_p2) {
    return prism_rtl::make_rc<CheckCond>(env_p0, st_p1, e_p2);
}


/// ?TagOfPattern: fn Env, Pattern -> ?TagInfo
std::optional<crate::check::env::TagInfo> tag_of_pattern_o(const crate::check::expr::Env& env_p0, const crate::syntax::Pattern_& p_p1) {
    auto&& _m = prism_rtl::deref(p_p1.kind_p);
    if (prism_rtl::is<crate::syntax::PatternKind::PRecord>(_m)) {
        auto&& n_p2 = prism_rtl::as<crate::syntax::PatternKind::PRecord>(_m).a0;
        return crate::prelude::get(prism_rtl::deref(env_p0.g_p).tags_p, crate::check::env::dotted_f(prism_rtl::deref(n_p2).path_p));
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PCtor>(_m)) {
        auto&& n_p3 = prism_rtl::as<crate::syntax::PatternKind::PCtor>(_m).a0;
        return crate::prelude::get(prism_rtl::deref(env_p0.g_p).tags_p, crate::check::env::dotted_f(prism_rtl::deref(n_p3).path_p));
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
        auto&& n_p4 = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        return crate::prelude::get(prism_rtl::deref(env_p0.g_p).tags_p, crate::check::env::dotted_f(prism_rtl::deref(n_p4).path_p));
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PGroup>(_m)) {
        auto&& q_p5 = prism_rtl::as<crate::syntax::PatternKind::PGroup>(_m).a0;
        return tag_of_pattern_o(env_p0, prism_rtl::deref(prism_rtl::deref(q_p5)));
    }
    {
        return std::optional<crate::check::env::TagInfo>{};
    }
}


/// SubstRigid: unbounded fn Text, Ty, Ty -> Ty
crate::check::types::Ty subst_rigid_f(const Text& name_p0, const crate::check::types::Ty& by_p1, const crate::check::types::Ty& t_p2) {
    if (prism_rtl::is<crate::check::types::Ty::TyRigid>(t_p2)) {
        auto&& n_p3 = prism_rtl::as<crate::check::types::Ty::TyRigid>(t_p2).a0;
        return n_p3 == name_p0 ? by_p1 : t_p2;
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t_p2)) {
        auto&& n_p4 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p2).a0;
        auto&& args_p5 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p2).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyCon{n_p4, crate::prelude::run_to_end(crate::prelude::each_job(args_p5, ({
            auto name_p0x = name_p0;
            auto by_p1x = by_p1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, name_p0x = std::move(name_p0x), by_p1x = std::move(by_p1x)](crate::check::types::Ty p0) {
            return ({
                auto name_p0xy = name_p0x;
                auto by_p1xy = by_p1x;
                (crate::prelude::entered(crate::prelude::once_job([=, name_p0xy = std::move(name_p0xy), by_p1xy = std::move(by_p1xy)]() {
                return ({
                    auto a_p6 = p0;
                    (prism_rtl::more(prism_rtl::rc(SubstRigid(name_p0xy, by_p1xy, a_p6))));
                });
            })));
            });
        })));
        })))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(t_p2)) {
        auto&& c_p7 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p2).a0;
        auto&& ps_p8 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p2).a1;
        auto&& r_p9 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p2).a2;
        return crate::check::types::Ty(crate::check::types::Ty::TyFn{c_p7, crate::prelude::run_to_end(crate::prelude::each_job(ps_p8, ({
            auto name_p0x = name_p0;
            auto by_p1x = by_p1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, name_p0x = std::move(name_p0x), by_p1x = std::move(by_p1x)](crate::check::types::Ty p0) {
            return ({
                auto name_p0xy = name_p0x;
                auto by_p1xy = by_p1x;
                (crate::prelude::entered(crate::prelude::once_job([=, name_p0xy = std::move(name_p0xy), by_p1xy = std::move(by_p1xy)]() {
                return ({
                    auto a_pa = p0;
                    (prism_rtl::more(prism_rtl::rc(SubstRigid(name_p0xy, by_p1xy, a_pa))));
                });
            })));
            });
        })));
        }))), prism_rtl::rc(subst_rigid_f(name_p0, by_p1, prism_rtl::deref(prism_rtl::deref(r_p9))))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t_p2)) {
        auto&& ts_pb = prism_rtl::as<crate::check::types::Ty::TyTuple>(t_p2).a0;
        return crate::check::types::Ty(crate::check::types::Ty::TyTuple{crate::prelude::run_to_end(crate::prelude::each_job(ts_pb, ({
            auto name_p0x = name_p0;
            auto by_p1x = by_p1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, name_p0x = std::move(name_p0x), by_p1x = std::move(by_p1x)](crate::check::types::Ty p0) {
            return ({
                auto name_p0xy = name_p0x;
                auto by_p1xy = by_p1x;
                (crate::prelude::entered(crate::prelude::once_job([=, name_p0xy = std::move(name_p0xy), by_p1xy = std::move(by_p1xy)]() {
                return ({
                    auto a_pc = p0;
                    (prism_rtl::more(prism_rtl::rc(SubstRigid(name_p0xy, by_p1xy, a_pc))));
                });
            })));
            });
        })));
        })))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(t_p2)) {
        auto&& e_pd = prism_rtl::as<crate::check::types::Ty::TyArray>(t_p2).a0;
        return crate::check::types::Ty(crate::check::types::Ty::TyArray{prism_rtl::rc(subst_rigid_f(name_p0, by_p1, prism_rtl::deref(prism_rtl::deref(e_pd))))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(t_p2)) {
        auto&& k_pe = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p2).a0;
        auto&& v_pf = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p2).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyMap{prism_rtl::rc(subst_rigid_f(name_p0, by_p1, prism_rtl::deref(prism_rtl::deref(k_pe)))), prism_rtl::rc(subst_rigid_f(name_p0, by_p1, prism_rtl::deref(prism_rtl::deref(v_pf))))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t_p2)) {
        auto&& s_pg = prism_rtl::as<crate::check::types::Ty::TySig>(t_p2).a0;
        auto&& i_ph = prism_rtl::as<crate::check::types::Ty::TySig>(t_p2).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TySig{s_pg, prism_rtl::rc(subst_rigid_f(name_p0, by_p1, prism_rtl::deref(prism_rtl::deref(i_ph))))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(t_p2)) {
        auto&& i_pi = prism_rtl::as<crate::check::types::Ty::TyAt>(t_p2).a0;
        auto&& rw_pj = prism_rtl::as<crate::check::types::Ty::TyAt>(t_p2).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyAt{prism_rtl::rc(subst_rigid_f(name_p0, by_p1, prism_rtl::deref(prism_rtl::deref(i_pi)))), rw_pj});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(t_p2)) {
        auto&& rw_pk = prism_rtl::as<crate::check::types::Ty::TyElem>(t_p2).a0;
        auto&& o_pl = prism_rtl::as<crate::check::types::Ty::TyElem>(t_p2).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyElem{rw_pk, prism_rtl::rc(subst_rigid_f(name_p0, by_p1, prism_rtl::deref(prism_rtl::deref(o_pl))))});
    }
    {
        auto&& other_pm = t_p2;
        return other_pm;
    }
}


prism_rtl::Turn<crate::check::types::Ty> SubstRigid::cycle() const {
    const auto& name_p0 = this->name_p0;
    const auto& by_p1 = this->by_p1;
    const auto& t_p2 = this->t_p2;
    return ({
        prism_rtl::is<crate::check::types::Ty::TyRigid>(t_p2) ? ({
        auto&& n_p3 = prism_rtl::as<crate::check::types::Ty::TyRigid>(t_p2).a0;
        n_p3 == name_p0 ? prism_rtl::finished(by_p1) : prism_rtl::finished(t_p2);
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t_p2) ? ({
        auto&& n_p4 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p2).a0;
        auto&& args_p5 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p2).a1;
        ({
        auto args_p5x = args_p5;
        auto by_p1x = by_p1;
        auto n_p4x = n_p4;
        auto name_p0x = name_p0;
        (crate::prelude::call_value(crate::prelude::each_job(args_p5x, ({
        auto name_p0xx = name_p0x;
        auto by_p1xx = by_p1x;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, name_p0xx = std::move(name_p0xx), by_p1xx = std::move(by_p1xx)](crate::check::types::Ty p0) {
        return ({
            auto name_p0xxy = name_p0xx;
            auto by_p1xxy = by_p1xx;
            (crate::prelude::entered(crate::prelude::once_job([=, name_p0xxy = std::move(name_p0xxy), by_p1xxy = std::move(by_p1xxy)]() {
            return ({
                auto a_p6 = p0;
                (prism_rtl::more(prism_rtl::rc(SubstRigid(name_p0xxy, by_p1xxy, a_p6))));
            });
        })));
        });
    })));
    })), [=, n_p4x = std::move(n_p4x)](Array<crate::check::types::Ty> each_7117) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyCon{n_p4x, each_7117})); }));
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyFn>(t_p2) ? ({
        auto&& c_p7 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p2).a0;
        auto&& ps_p8 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p2).a1;
        auto&& r_p9 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p2).a2;
        ({
        auto by_p1x = by_p1;
        auto c_p7x = c_p7;
        auto name_p0x = name_p0;
        auto ps_p8x = ps_p8;
        auto r_p9x = prism_rtl::deref(prism_rtl::deref(r_p9));
        (crate::prelude::call_value(crate::prelude::each_job(ps_p8x, ({
        auto name_p0xx = name_p0x;
        auto by_p1xx = by_p1x;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, name_p0xx = std::move(name_p0xx), by_p1xx = std::move(by_p1xx)](crate::check::types::Ty p0) {
        return ({
            auto name_p0xxy = name_p0xx;
            auto by_p1xxy = by_p1xx;
            (crate::prelude::entered(crate::prelude::once_job([=, name_p0xxy = std::move(name_p0xxy), by_p1xxy = std::move(by_p1xxy)]() {
            return ({
                auto a_pa = p0;
                (prism_rtl::more(prism_rtl::rc(SubstRigid(name_p0xxy, by_p1xxy, a_pa))));
            });
        })));
        });
    })));
    })), [=, c_p7x = std::move(c_p7x), r_p9x = std::move(r_p9x)](Array<crate::check::types::Ty> each_7185) { return crate::prelude::call_then(start_subst_rigid_f(name_p0x, by_p1x, r_p9x), [=](crate::check::types::Ty subst_rigid_f_7225) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyFn{c_p7x, each_7185, prism_rtl::rc(subst_rigid_f_7225)})); }); }));
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyTuple>(t_p2) ? ({
        auto&& ts_pb = prism_rtl::as<crate::check::types::Ty::TyTuple>(t_p2).a0;
        ({
        auto by_p1x = by_p1;
        auto name_p0x = name_p0;
        auto ts_pbx = ts_pb;
        (crate::prelude::call_value(crate::prelude::each_job(ts_pbx, ({
        auto name_p0xx = name_p0x;
        auto by_p1xx = by_p1x;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, name_p0xx = std::move(name_p0xx), by_p1xx = std::move(by_p1xx)](crate::check::types::Ty p0) {
        return ({
            auto name_p0xxy = name_p0xx;
            auto by_p1xxy = by_p1xx;
            (crate::prelude::entered(crate::prelude::once_job([=, name_p0xxy = std::move(name_p0xxy), by_p1xxy = std::move(by_p1xxy)]() {
            return ({
                auto a_pc = p0;
                (prism_rtl::more(prism_rtl::rc(SubstRigid(name_p0xxy, by_p1xxy, a_pc))));
            });
        })));
        });
    })));
    })), [=](Array<crate::check::types::Ty> each_7274) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyTuple{each_7274})); }));
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyArray>(t_p2) ? ({
        auto&& e_pd = prism_rtl::as<crate::check::types::Ty::TyArray>(t_p2).a0;
        ({
        auto by_p1x = by_p1;
        auto e_pdx = prism_rtl::deref(prism_rtl::deref(e_pd));
        auto name_p0x = name_p0;
        (crate::prelude::call_then(start_subst_rigid_f(name_p0x, by_p1x, e_pdx), [=](crate::check::types::Ty subst_rigid_f_7336) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyArray{prism_rtl::rc(subst_rigid_f_7336)})); }));
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyMap>(t_p2) ? ({
        auto&& k_pe = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p2).a0;
        auto&& v_pf = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p2).a1;
        ({
        auto by_p1x = by_p1;
        auto k_pex = prism_rtl::deref(prism_rtl::deref(k_pe));
        auto name_p0x = name_p0;
        auto v_pfx = prism_rtl::deref(prism_rtl::deref(v_pf));
        (crate::prelude::call_then(start_subst_rigid_f(name_p0x, by_p1x, k_pex), [=, v_pfx = std::move(v_pfx)](crate::check::types::Ty subst_rigid_f_7383) { return crate::prelude::call_then(start_subst_rigid_f(name_p0x, by_p1x, v_pfx), [=](crate::check::types::Ty subst_rigid_f_7409) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyMap{prism_rtl::rc(subst_rigid_f_7383), prism_rtl::rc(subst_rigid_f_7409)})); }); }));
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TySig>(t_p2) ? ({
        auto&& s_pg = prism_rtl::as<crate::check::types::Ty::TySig>(t_p2).a0;
        auto&& i_ph = prism_rtl::as<crate::check::types::Ty::TySig>(t_p2).a1;
        ({
        auto by_p1x = by_p1;
        auto i_phx = prism_rtl::deref(prism_rtl::deref(i_ph));
        auto name_p0x = name_p0;
        auto s_pgx = s_pg;
        (crate::prelude::call_then(start_subst_rigid_f(name_p0x, by_p1x, i_phx), [=, s_pgx = std::move(s_pgx)](crate::check::types::Ty subst_rigid_f_7459) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TySig{s_pgx, prism_rtl::rc(subst_rigid_f_7459)})); }));
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyAt>(t_p2) ? ({
        auto&& i_pi = prism_rtl::as<crate::check::types::Ty::TyAt>(t_p2).a0;
        auto&& rw_pj = prism_rtl::as<crate::check::types::Ty::TyAt>(t_p2).a1;
        ({
        auto by_p1x = by_p1;
        auto i_pix = prism_rtl::deref(prism_rtl::deref(i_pi));
        auto name_p0x = name_p0;
        auto rw_pjx = rw_pj;
        (crate::prelude::call_then(start_subst_rigid_f(name_p0x, by_p1x, i_pix), [=, rw_pjx = std::move(rw_pjx)](crate::check::types::Ty subst_rigid_f_7505) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyAt{prism_rtl::rc(subst_rigid_f_7505), rw_pjx})); }));
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyElem>(t_p2) ? ({
        auto&& rw_pk = prism_rtl::as<crate::check::types::Ty::TyElem>(t_p2).a0;
        auto&& o_pl = prism_rtl::as<crate::check::types::Ty::TyElem>(t_p2).a1;
        ({
        auto by_p1x = by_p1;
        auto name_p0x = name_p0;
        auto o_plx = prism_rtl::deref(prism_rtl::deref(o_pl));
        auto rw_pkx = rw_pk;
        (crate::prelude::call_then(start_subst_rigid_f(name_p0x, by_p1x, o_plx), [=, rw_pkx = std::move(rw_pkx)](crate::check::types::Ty subst_rigid_f_7563) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyElem{rw_pkx, prism_rtl::rc(subst_rigid_f_7563)})); }));
    });
    })
        : ({
        auto&& other_pm = t_p2;
        prism_rtl::finished(other_pm);
    });
    });
}


/// `Start SubstRigid, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::Ty> start_subst_rigid_f(Text name_p0, crate::check::types::Ty by_p1, crate::check::types::Ty t_p2) {
    return prism_rtl::make_rc<SubstRigid>(name_p0, by_p1, t_p2);
}


/// MatchResult: unbounded fn Env, St, Text, [((Text, Range))], Ty, Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> match_result_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const Text& sh_p2, const Array<std::tuple<Text, crate::syntax::Range>>& layers_p3, const crate::check::types::Ty& res_p4, const crate::syntax::Range& span_p5) {
    auto events_p6 = crate::prelude::filter(layers_p3, [&](const std::tuple<Text, crate::syntax::Range>& _p0) {
        auto&& h_pb = std::get<0>(_p0);
        return h_pb == Text::lit("!");
    });
    auto dyns_p7 = crate::prelude::filter(layers_p3, [&](const std::tuple<Text, crate::syntax::Range>& _p0) {
        auto&& h_pc = std::get<0>(_p0);
        return h_pc == Text::lit("$");
    });
    auto blue_p8 = crate::prelude::filter(layers_p3, [&](const std::tuple<Text, crate::syntax::Range>& _p0) {
        auto&& h_pd = std::get<0>(_p0);
        return h_pd == Text::lit("@");
    });
    auto st2_p9 = (crate::prelude::len(blue_p8) > Nat(0u)) && crate::check::expr::is_time_sigil_f(sh_p2)
        ? crate::check::types::recording::err_fix_f(st_p1, Text::lit("building-match"), span_p5, Text::lit("a blueprint in a match over a dynamic; use `rebuild`"), Text::lit("write `rebuild` over the scrutinee, with `match _:` inside"))
        : st_p1;
    auto st3_pa = (sh_p2 == Text::lit("!")) && (crate::prelude::len(events_p6) > Nat(0u))
        ? crate::check::types::recording::err_fix_f(st2_p9, Text::lit("two-events"), span_p5, Text::lit("two events in one operation"), Text::lit("an arm over an event\'s scrutinee fires with the scrutinee; read a dynamic in the arm, not an event"))
        : st2_p9;
    return crate::prelude::len(events_p6) > Nat(0u)
        ? std::tuple{crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("!"), prism_rtl::rc(res_p4)}), crate::check::expr::calls::elab_f(st3_pa, span_p5, Text::lit("match"), Text::lit("gate"), Text::lit("!"))}
        : (sh_p2 == Text::lit("$")) || (crate::prelude::len(dyns_p7) > Nat(0u))
        ? std::tuple{crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("$"), prism_rtl::rc(res_p4)}), crate::check::expr::calls::elab_f(st3_pa, span_p5, Text::lit("match"), Text::lit("map"), Text::lit("$"))}
        : sh_p2 == Text::lit("!")
        ? std::tuple{crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("!"), prism_rtl::rc(res_p4)}), crate::check::expr::calls::elab_f(st3_pa, span_p5, Text::lit("match"), Text::lit("map"), Text::lit("!"))}
        : std::tuple{res_p4, st3_pa};
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> MatchResult::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& sh_p2 = this->sh_p2;
    const auto& layers_p3 = this->layers_p3;
    const auto& res_p4 = this->res_p4;
    const auto& span_p5 = this->span_p5;
    auto events_p6 = crate::prelude::filter(layers_p3, [&](const std::tuple<Text, crate::syntax::Range>& _p0) {
        auto&& h_pb = std::get<0>(_p0);
        return h_pb == Text::lit("!");
    });
    auto dyns_p7 = crate::prelude::filter(layers_p3, [&](const std::tuple<Text, crate::syntax::Range>& _p0) {
        auto&& h_pc = std::get<0>(_p0);
        return h_pc == Text::lit("$");
    });
    auto blue_p8 = crate::prelude::filter(layers_p3, [&](const std::tuple<Text, crate::syntax::Range>& _p0) {
        auto&& h_pd = std::get<0>(_p0);
        return h_pd == Text::lit("@");
    });
    auto st2_p9 = (crate::prelude::len(blue_p8) > Nat(0u)) && crate::check::expr::is_time_sigil_f(sh_p2)
        ? crate::check::types::recording::err_fix_f(st_p1, Text::lit("building-match"), span_p5, Text::lit("a blueprint in a match over a dynamic; use `rebuild`"), Text::lit("write `rebuild` over the scrutinee, with `match _:` inside"))
        : st_p1;
    auto st3_pa = (sh_p2 == Text::lit("!")) && (crate::prelude::len(events_p6) > Nat(0u))
        ? crate::check::types::recording::err_fix_f(st2_p9, Text::lit("two-events"), span_p5, Text::lit("two events in one operation"), Text::lit("an arm over an event\'s scrutinee fires with the scrutinee; read a dynamic in the arm, not an event"))
        : st2_p9;
    return crate::prelude::len(events_p6) > Nat(0u)
        ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("!"), prism_rtl::rc(res_p4)}), crate::check::expr::calls::elab_f(st3_pa, span_p5, Text::lit("match"), Text::lit("gate"), Text::lit("!"))})
        : (sh_p2 == Text::lit("$")) || (crate::prelude::len(dyns_p7) > Nat(0u))
        ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("$"), prism_rtl::rc(res_p4)}), crate::check::expr::calls::elab_f(st3_pa, span_p5, Text::lit("match"), Text::lit("map"), Text::lit("$"))})
        : sh_p2 == Text::lit("!")
        ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("!"), prism_rtl::rc(res_p4)}), crate::check::expr::calls::elab_f(st3_pa, span_p5, Text::lit("match"), Text::lit("map"), Text::lit("!"))})
        : prism_rtl::finished(std::tuple{res_p4, st3_pa});
}


/// `Start MatchResult, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_match_result_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Text sh_p2, Array<std::tuple<Text, crate::syntax::Range>> layers_p3, crate::check::types::Ty res_p4, crate::syntax::Range span_p5) {
    return prism_rtl::make_rc<MatchResult>(env_p0, st_p1, sh_p2, layers_p3, res_p4, span_p5);
}


/// InferIf: unbounded fn Env, St, Cond, Block, ?Block, Range, ?Ty -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_if_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Cond& c_p2, const crate::syntax::Block& then_b_p3, const std::optional<crate::syntax::Block>& else_b_o4, const crate::syntax::Range& span_p5, const std::optional<crate::check::types::Ty>& expected_o6) {
    if (prism_rtl::is<crate::syntax::Cond::CondExpr>(c_p2)) {
        auto&& e_p7 = prism_rtl::as<crate::syntax::Cond::CondExpr>(c_p2).a0;
        auto [ct_pb, st1_pc] = crate::check::expr::infer_f(env_p0, st_p1, prism_rtl::deref(prism_rtl::deref(e_p7)));
        auto sh_p8 = crate::check::types::head_sigil_f(st1_pc, ct_pb);
        auto inner_p9 = crate::check::expr::is_time_sigil_f(sh_p8)
            ? crate::check::expr::inner_of_f(st1_pc, ct_pb)
            : ct_pb;
        auto st2_pa = crate::check::types::unify::unify_f(st1_pc, crate::check::types::t_bool_p(), inner_p9, prism_rtl::deref(e_p7).span_p);
        auto [res_pd, st3_pe] = crate::check::types::fresh_var_f(st2_pa, false, Text::lit(""));
        auto [layers_pf, st4_pg] = if_branches_f(env_p0, st3_pe, env_p0, then_b_p3, else_b_o4, res_pd);
        return match_result_f(env_p0, st4_pg, sh_p8, layers_pf, res_pd, span_p5);
    }
    if (prism_rtl::is<crate::syntax::Cond::CondBind>(c_p2)) {
        auto&& p_ph = prism_rtl::as<crate::syntax::Cond::CondBind>(c_p2).a0;
        auto&& e_pi = prism_rtl::as<crate::syntax::Cond::CondBind>(c_p2).a1;
        auto&& gd_oj = prism_rtl::as<crate::syntax::Cond::CondBind>(c_p2).a2;
        auto [et_pl, st1_pm] = crate::check::expr::infer_f(env_p0, st_p1, prism_rtl::deref(prism_rtl::deref(e_pi)));
        auto [env2_pn, st2_po] = crate::check::expr::patterns::bind_pattern_f(env_p0, st1_pm, p_ph, et_pl, true);
        auto st3_pk = ({
            __label__ _done;
            prism_rtl::Slot<crate::check::types::St> _v;
            auto&& _m = prism_rtl::deref(prism_rtl::deref(gd_oj));
            if (prism_rtl::is_some(_m)) {
                auto&& g_pp = prism_rtl::some_of(_m);
                _v.set(check_cond_f(env2_pn, st2_po, g_pp));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(st2_po);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto [res_pq, st4_pr] = crate::check::types::fresh_var_f(st3_pk, false, Text::lit(""));
        auto [layers_ps, st5_pt] = if_branches_f(env2_pn, st4_pr, env_p0, then_b_p3, else_b_o4, res_pq);
        return match_result_f(env_p0, st5_pt, Text::lit(""), layers_ps, res_pq, span_p5);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InferIf::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& c_p2 = this->c_p2;
    const auto& then_b_p3 = this->then_b_p3;
    const auto& else_b_o4 = this->else_b_o4;
    const auto& span_p5 = this->span_p5;
    const auto& expected_o6 = this->expected_o6;
    return ({
        prism_rtl::is<crate::syntax::Cond::CondExpr>(c_p2) ? ({
        auto&& e_p7 = prism_rtl::as<crate::syntax::Cond::CondExpr>(c_p2).a0;
        ({
        auto else_b_o4x = else_b_o4;
        auto e_p7x = prism_rtl::deref(prism_rtl::deref(e_p7));
        auto env_p0x = env_p0;
        auto span_p5x = span_p5;
        auto st_p1x = st_p1;
        auto then_b_p3x = then_b_p3;
        (crate::prelude::call_then(crate::check::expr::start_infer_f(env_p0x, st_p1x, e_p7x), [=, else_b_o4x = std::move(else_b_o4x), span_p5x = std::move(span_p5x), then_b_p3x = std::move(then_b_p3x)](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_f_8896) {
        return ({
            auto [ct_pb, st1_pc] = infer_f_8896;
            (crate::prelude::call_then(crate::check::types::start_head_sigil_f(st1_pc, ct_pb), [=](Text head_sigil_f_8930) {
            return ({
                auto sh_p8 = head_sigil_f_8930;
                auto inner_p9 = crate::check::expr::is_time_sigil_f(sh_p8)
                    ? crate::check::expr::inner_of_f(st1_pc, ct_pb)
                    : ct_pb;
                (crate::prelude::call_then(crate::check::types::unify::start_unify_f(st1_pc, crate::check::types::t_bool_p(), inner_p9, prism_rtl::deref(e_p7x).span_p), [=, sh_p8 = std::move(sh_p8)](crate::check::types::St unify_f_9030) {
                return ({
                    auto st2_pa = unify_f_9030;
                    auto [res_pd, st3_pe] = crate::check::types::fresh_var_f(st2_pa, false, Text::lit(""));
                    (crate::prelude::call_then(start_if_branches_f(env_p0x, st3_pe, env_p0x, then_b_p3x, else_b_o4x, res_pd), [=](std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::check::types::St> if_branches_f_9143) {
                    return ({
                        auto [layers_pf, st4_pg] = if_branches_f_9143;
                        (prism_rtl::more(prism_rtl::rc(MatchResult(env_p0x, st4_pg, sh_p8, layers_pf, res_pd, span_p5x))));
                    });
                }));
                });
            }));
            });
        }));
        });
    }));
    });
    })
        : prism_rtl::is<crate::syntax::Cond::CondBind>(c_p2) ? ({
        auto&& p_ph = prism_rtl::as<crate::syntax::Cond::CondBind>(c_p2).a0;
        auto&& e_pi = prism_rtl::as<crate::syntax::Cond::CondBind>(c_p2).a1;
        auto&& gd_oj = prism_rtl::as<crate::syntax::Cond::CondBind>(c_p2).a2;
        ({
        auto else_b_o4x = else_b_o4;
        auto gd_ojx = prism_rtl::deref(prism_rtl::deref(gd_oj));
        auto c_p2x = c_p2;
        auto e_pix = prism_rtl::deref(prism_rtl::deref(e_pi));
        auto env_p0x = env_p0;
        auto p_phx = p_ph;
        auto span_p5x = span_p5;
        auto st_p1x = st_p1;
        auto then_b_p3x = then_b_p3;
        (crate::prelude::call_then(crate::check::expr::start_infer_f(env_p0x, st_p1x, e_pix), [=, else_b_o4x = std::move(else_b_o4x), gd_ojx = std::move(gd_ojx), p_phx = std::move(p_phx), span_p5x = std::move(span_p5x), then_b_p3x = std::move(then_b_p3x)](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_f_9290) {
        return ({
            auto [et_pl, st1_pm] = infer_f_9290;
            (crate::prelude::call_then(crate::check::expr::patterns::start_bind_pattern_f(env_p0x, st1_pm, p_phx, et_pl, true), [=](std::tuple<crate::check::expr::Env, crate::check::types::St> bind_pattern_f_9335) {
            return ({
                auto [env2_pn, st2_po] = bind_pattern_f_9335;
                auto st3_pk = ({
                    __label__ _done;
                    prism_rtl::Slot<crate::check::types::St> _v;
                    if (prism_rtl::is_some(gd_ojx)) {
                        auto&& g_pp = prism_rtl::some_of(gd_ojx);
                        _v.set(check_cond_f(env2_pn, st2_po, g_pp));
                        goto _done;
                    }
                    if (prism_rtl::is_none(gd_ojx)) {
                        _v.set(st2_po);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                auto [res_pq, st4_pr] = crate::check::types::fresh_var_f(st3_pk, false, Text::lit(""));
                (crate::prelude::call_then(start_if_branches_f(env2_pn, st4_pr, env_p0x, then_b_p3x, else_b_o4x, res_pq), [=](std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::check::types::St> if_branches_f_9540) {
                return ({
                    auto [layers_ps, st5_pt] = if_branches_f_9540;
                    (prism_rtl::more(prism_rtl::rc(MatchResult(env_p0x, st5_pt, Text::lit(""), layers_ps, res_pq, span_p5x))));
                });
            }));
            });
        }));
        });
    }));
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start InferIf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_if_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Cond c_p2, crate::syntax::Block then_b_p3, std::optional<crate::syntax::Block> else_b_o4, crate::syntax::Range span_p5, std::optional<crate::check::types::Ty> expected_o6) {
    return prism_rtl::make_rc<InferIf>(env_p0, st_p1, c_p2, then_b_p3, else_b_o4, span_p5, expected_o6);
}


/// UnifyArm: unbounded fn St, Ty, Ty, Range -> St
crate::check::types::St unify_arm_f(const crate::check::types::St& st_p0, const crate::check::types::Ty& res_p1, const crate::check::types::Ty& t_p2, const crate::syntax::Range& span_p3) {
    return crate::check::types::is_flex_var_f(st_p0, res_p1) && (crate::check::types::recording::walk_f(st_p0, t_p2) == crate::check::types::Ty(crate::check::types::Ty::TyCon{Text::lit("Prelude.Error"), Array<crate::check::types::Ty>{}}))
        ? crate::check::types::unify::defer_f(st_p0, res_p1, t_p2, span_p3)
        : crate::check::types::unify::unify_f(st_p0, res_p1, t_p2, span_p3);
}


prism_rtl::Turn<crate::check::types::St> UnifyArm::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& res_p1 = this->res_p1;
    const auto& t_p2 = this->t_p2;
    const auto& span_p3 = this->span_p3;
    auto res_p1x = res_p1;
    auto span_p3x = span_p3;
    auto st_p0x = st_p0;
    auto t_p2x = t_p2;
    return crate::prelude::call_then(crate::check::types::start_is_flex_var_f(st_p0x, res_p1x), [=](bool is_flex_var_f_9877) {
        return is_flex_var_f_9877 && (crate::check::types::recording::walk_f(st_p0x, t_p2x) == crate::check::types::Ty(crate::check::types::Ty::TyCon{Text::lit("Prelude.Error"), Array<crate::check::types::Ty>{}}))
            ? prism_rtl::finished(crate::check::types::unify::defer_f(st_p0x, res_p1x, t_p2x, span_p3x))
            : prism_rtl::more(prism_rtl::rc(crate::check::types::unify::Unify(st_p0x, res_p1x, t_p2x, span_p3x)));
    });
}


/// `Start UnifyArm, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_unify_arm_f(crate::check::types::St st_p0, crate::check::types::Ty res_p1, crate::check::types::Ty t_p2, crate::syntax::Range span_p3) {
    return prism_rtl::make_rc<UnifyArm>(st_p0, res_p1, t_p2, span_p3);
}


/// LayerHead: fn Text -> Text
Text layer_head_f(const Text& h_p0) {
    return crate::check::expr::is_time_sigil_f(h_p0)
        ? h_p0
        : h_p0 == Text::lit("@") ? Text::lit("@") : Text::lit("");
}


/// IfBranches: unbounded fn Env, St, Env, Block, ?Block, Ty -> (([((Text, Range))], St))
std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::check::types::St> if_branches_f(const crate::check::expr::Env& then_env_p0, const crate::check::types::St& st_p1, const crate::check::expr::Env& else_env_p2, const crate::syntax::Block& then_b_p3, const std::optional<crate::syntax::Block>& else_b_o4, const crate::check::types::Ty& res_p5) {
    auto [t1_p9, st1_pa] = crate::check::expr::lets::infer_expr_block_f(then_env_p0, st_p1, then_b_p3);
    auto h1_p6 = crate::check::types::head_sigil_f(st1_pa, t1_p9);
    auto st2_p7 = unify_arm_f(st1_pa, res_p5, crate::check::expr::is_time_sigil_f(h1_p6)
        ? crate::check::expr::inner_of_f(st1_pa, t1_p9)
        : t1_p9, then_b_p3.span_p);
    auto l1_p8 = Array(std::vector{std::tuple{layer_head_f(h1_p6), then_b_p3.span_p}});
    if (prism_rtl::is_some(else_b_o4)) {
        auto&& b_pb = prism_rtl::some_of(else_b_o4);
        auto [t2_pe, st3_pf] = crate::check::expr::lets::infer_expr_block_f(else_env_p2, st2_p7, b_pb);
        auto h2_pc = crate::check::types::head_sigil_f(st3_pf, t2_pe);
        auto st4_pd = unify_arm_f(st3_pf, res_p5, crate::check::expr::is_time_sigil_f(h2_pc)
            ? crate::check::expr::inner_of_f(st3_pf, t2_pe)
            : t2_pe, prism_rtl::deref(b_pb).span_p);
        return std::tuple{crate::prelude::push(l1_p8, std::tuple{layer_head_f(h2_pc), prism_rtl::deref(b_pb).span_p}), st4_pd};
    }
    if (prism_rtl::is_none(else_b_o4)) {
        return std::tuple{l1_p8, crate::check::types::unify::unify_f(st2_p7, res_p5, crate::check::types::t_unit_p(), then_b_p3.span_p)};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::check::types::St>> IfBranches::cycle() const {
    const auto& then_env_p0 = this->then_env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& else_env_p2 = this->else_env_p2;
    const auto& then_b_p3 = this->then_b_p3;
    const auto& else_b_o4 = this->else_b_o4;
    const auto& res_p5 = this->res_p5;
    auto else_b_o4x = else_b_o4;
    auto else_env_p2x = else_env_p2;
    auto res_p5x = res_p5;
    auto st_p1x = st_p1;
    auto then_b_p3x = then_b_p3;
    auto then_env_p0x = then_env_p0;
    return crate::prelude::call_then(crate::check::expr::lets::start_infer_expr_block_f(then_env_p0x, st_p1x, then_b_p3x), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_expr_block_f_10261) {
        return ({
            auto [t1_p9, st1_pa] = infer_expr_block_f_10261;
            (crate::prelude::call_then(crate::check::types::start_head_sigil_f(st1_pa, t1_p9), [=](Text head_sigil_f_10308) {
            return ({
                auto h1_p6 = head_sigil_f_10308;
                (crate::prelude::call_then(start_unify_arm_f(st1_pa, res_p5x, crate::check::expr::is_time_sigil_f(h1_p6)
                ? crate::check::expr::inner_of_f(st1_pa, t1_p9)
                : t1_p9, prism_rtl::deref(then_b_p3x).span_p), [=](crate::check::types::St unify_arm_f_10340) {
                return ({
                    auto st2_p7 = unify_arm_f_10340;
                    auto l1_p8 = Array(std::vector{std::tuple{layer_head_f(h1_p6), prism_rtl::deref(then_b_p3x).span_p}});
                    ({
                    prism_rtl::is_some(else_b_o4x) ? ({
                    auto&& b_pb = prism_rtl::some_of(else_b_o4x);
                    ({
                    auto b_pbx = b_pb;
                    (crate::prelude::call_then(crate::check::expr::lets::start_infer_expr_block_f(else_env_p2x, st2_p7, b_pbx), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_expr_block_f_10526) {
                    return ({
                        auto [t2_pe, st3_pf] = infer_expr_block_f_10526;
                        (crate::prelude::call_then(crate::check::types::start_head_sigil_f(st3_pf, t2_pe), [=](Text head_sigil_f_10578) {
                        return ({
                            auto h2_pc = head_sigil_f_10578;
                            (crate::prelude::call_then(start_unify_arm_f(st3_pf, res_p5x, crate::check::expr::is_time_sigil_f(h2_pc)
                            ? crate::check::expr::inner_of_f(st3_pf, t2_pe)
                            : t2_pe, prism_rtl::deref(b_pbx).span_p), [=](crate::check::types::St unify_arm_f_10618) {
                            return ({
                                auto st4_pd = unify_arm_f_10618;
                                (prism_rtl::finished(std::tuple{crate::prelude::push(l1_p8, std::tuple{layer_head_f(h2_pc), prism_rtl::deref(b_pbx).span_p}), st4_pd}));
                            });
                        }));
                        });
                    }));
                    });
                }));
                });
                })
                    : prism_rtl::is_none(else_b_o4x) ? crate::prelude::call_then(crate::check::types::unify::start_unify_f(st2_p7, res_p5x, crate::check::types::t_unit_p(), prism_rtl::deref(then_b_p3x).span_p), [=, l1_p8 = std::move(l1_p8)](crate::check::types::St unify_f_10770) { return prism_rtl::finished(std::tuple{l1_p8, unify_f_10770}); })
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            }));
            });
        }));
        });
    });
}


/// `Start IfBranches, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::check::types::St>> start_if_branches_f(crate::check::expr::Env then_env_p0, crate::check::types::St st_p1, crate::check::expr::Env else_env_p2, crate::syntax::Block then_b_p3, std::optional<crate::syntax::Block> else_b_o4, crate::check::types::Ty res_p5) {
    return prism_rtl::make_rc<IfBranches>(then_env_p0, st_p1, else_env_p2, then_b_p3, else_b_o4, res_p5);
}

}  // namespace crate::check::expr::lifting
