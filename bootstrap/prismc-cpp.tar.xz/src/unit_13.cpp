// The module `Check.Expr.Lifting`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <check/expr/lifting/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Check.Expr.Lifting`, from `target/bootstrap/cpp-src/prismc/check/expr/lifting.prism`.
namespace crate::check::expr::lifting {

/// InferMatch: unbounded fn Env, St, Expr, [Arm], Range, ?Ty -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_match(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Expr& scrut, const Array<crate::syntax::Arm>& arms, const crate::syntax::Range& span, const std::optional<crate::check::types::Ty>& expected_opt) {
    auto [st_ty, st1] = crate::check::expr::infer(env, st, scrut);
    auto sh = crate::check::types::head_sigil(st1, st_ty);
    auto plain_scrut = crate::check::expr::is_time_sigil(sh)
        ? crate::check::expr::inner_of(st1, st_ty)
        : st_ty;
    auto st2 = sh == Text::lit("@")
        ? crate::check::types::recording::err(st1, Text::lit("blueprint-operand"), scrut.span, Text::lit("`match` over a blueprint; bind it first"))
        : st1;
    auto rigid_out_opt = ({
        __label__ _done;
        prism_rtl::Slot<std::optional<Text>> _v;
        auto&& _m = crate::check::types::recording::walk(st2, plain_scrut);
        if (prism_rtl::is<crate::check::types::Ty::TyElem>(_m)) {
            auto&& o = prism_rtl::as<crate::check::types::Ty::TyElem>(_m).a1;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::optional<Text>> _v;
                auto&& _m = crate::check::types::recording::walk(st2, prism_rtl::val(o));
                if (prism_rtl::is<crate::check::types::Ty::TyRigid>(_m)) {
                    auto&& name = prism_rtl::as<crate::check::types::Ty::TyRigid>(_m).a0;
                    _v.set(std::optional(name));
                    goto _done;
                }
                {
                    _v.set(std::optional<Text>{});
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        {
            _v.set(std::optional<Text>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto [res, st3] = crate::check::types::fresh_var(st2, false, Text::lit(""));
    auto checking = (expected_opt != std::optional<crate::check::types::Ty>{}) && (!crate::check::expr::is_time_sigil(sh));
    auto scrut_name = crate::check::shrink::locals::expr_name(scrut);
    auto&& _layers = run_to_end(fold_job(arms, std::tuple{Array<std::tuple<Text, crate::syntax::Range>>{}, st3, Array<Text>{}}, ({
        auto env_1 = env;
        auto scrut_name_2 = scrut_name;
        auto plain_scrut_3 = plain_scrut;
        auto res_4 = res;
        auto checking_5 = checking;
        auto expected_opt_6 = expected_opt;
        auto rigid_out_opt_7 = rigid_out_opt;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::check::types::St, Array<Text>>>(std::tuple<std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::check::types::St, Array<Text>>, crate::syntax::Arm>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::check::types::St, Array<Text>>, crate::syntax::Arm> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_1_8 = env_1;
            auto scrut_name_2_8 = scrut_name_2;
            auto plain_scrut_3_8 = plain_scrut_3;
            auto res_4_8 = res_4;
            auto checking_5_8 = checking_5;
            auto expected_opt_6_8 = expected_opt_6;
            auto rigid_out_opt_7_8 = rigid_out_opt_7;
            entered(once_job([=]() {
            return ({
                auto [acc, s, taken] = p0;
                auto arm = p1;
                call_then(start_narrowed(env_1_8, s, arm, scrut_name_2_8, plain_scrut_3_8, taken), [=](crate::check::expr::Env narrowed_2375) {
                return ({
                    auto env_arm = narrowed_2375;
                    call_then(start_infer_arm(env_arm, s, arm, plain_scrut_3_8, res_4_8, checking_5_8 ? expected_opt_6_8 : std::optional<crate::check::types::Ty>{}, rigid_out_opt_7_8, acc), [=](std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::check::types::St> infer_arm_2453) {
                    return ({
                        auto [acc2, s2] = infer_arm_2453;
                        (prism_rtl::finished(std::tuple{acc2, s2, taken_by(env_1_8, arm, taken)}));
                    });
                });
                });
            });
            });
        }));
        });
    }));
    })));
    auto&& layers = std::get<0>(_layers);
    auto&& st4 = std::get<1>(_layers);
    auto st5 = crate::check::passes::match_coverage(env, st4, plain_scrut, arms, span);
    if (prism_rtl::is_some(expected_opt)) {
        auto&& want = prism_rtl::some_of(expected_opt);
        return checking
            ? std::tuple{want, st5}
            : match_result(env, st5, sh, layers, res, span);
    }
    if (prism_rtl::is_none(expected_opt)) {
        return match_result(env, st5, sh, layers, res, span);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InferMatch::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& scrut = this->scrut;
    const auto& arms = this->arms;
    const auto& span = this->span;
    const auto& expected_opt = this->expected_opt;
    auto expected_opt_1 = expected_opt;
    auto arms_2 = arms;
    auto env_3 = env;
    auto scrut_4 = scrut;
    auto span_5 = span;
    auto st_6 = st;
    return call_then(crate::check::expr::start_infer(env_3, st_6, scrut_4), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_1698) {
        return ({
            auto [st_ty, st1] = infer_1698;
            call_then(crate::check::types::start_head_sigil(st1, st_ty), [=](Text head_sigil_1732) {
            return ({
                auto sh = head_sigil_1732;
                auto plain_scrut = crate::check::expr::is_time_sigil(sh)
                    ? crate::check::expr::inner_of(st1, st_ty)
                    : st_ty;
                auto st2 = sh == Text::lit("@")
                    ? crate::check::types::recording::err(st1, Text::lit("blueprint-operand"), prism_rtl::val(scrut_4).span, Text::lit("`match` over a blueprint; bind it first"))
                    : st1;
                call_then(crate::check::types::recording::start_walk(st2, plain_scrut), [=](crate::check::types::Ty walk_1969) {
                return ({
                    auto rigid_out_opt = ({
                        __label__ _done;
                        prism_rtl::Slot<std::optional<Text>> _v;
                        if (prism_rtl::is<crate::check::types::Ty::TyElem>(walk_1969)) {
                            auto&& o = prism_rtl::as<crate::check::types::Ty::TyElem>(walk_1969).a1;
                            _v.set(({
                                __label__ _done;
                                prism_rtl::Slot<std::optional<Text>> _v;
                                auto&& _m = crate::check::types::recording::walk(st2, prism_rtl::val(o));
                                if (prism_rtl::is<crate::check::types::Ty::TyRigid>(_m)) {
                                    auto&& name = prism_rtl::as<crate::check::types::Ty::TyRigid>(_m).a0;
                                    _v.set(std::optional(name));
                                    goto _done;
                                }
                                {
                                    _v.set(std::optional<Text>{});
                                    goto _done;
                                }
                            _done:
                                _v.take();
                            }));
                            goto _done;
                        }
                        {
                            _v.set(std::optional<Text>{});
                            goto _done;
                        }
                    _done:
                        _v.take();
                    });
                    auto [res, st3] = crate::check::types::fresh_var(st2, false, Text::lit(""));
                    auto checking = (expected_opt_1 != std::optional<crate::check::types::Ty>{}) && (!crate::check::expr::is_time_sigil(sh));
                    auto scrut_name = crate::check::shrink::locals::expr_name(scrut_4);
                    call_value(fold_job(arms_2, std::tuple{Array<std::tuple<Text, crate::syntax::Range>>{}, st3, Array<Text>{}}, ({
                    auto env_3_7 = env_3;
                    auto scrut_name_7 = scrut_name;
                    auto plain_scrut_8 = plain_scrut;
                    auto res_9 = res;
                    auto checking_10 = checking;
                    auto expected_opt_1_11 = expected_opt_1;
                    auto rigid_out_opt_11 = rigid_out_opt;
                    static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::check::types::St, Array<Text>>>(std::tuple<std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::check::types::St, Array<Text>>, crate::syntax::Arm>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::check::types::St, Array<Text>>, crate::syntax::Arm> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto env_3_7_12 = env_3_7;
                        auto scrut_name_7_12 = scrut_name_7;
                        auto plain_scrut_8_12 = plain_scrut_8;
                        auto res_9_12 = res_9;
                        auto checking_10_12 = checking_10;
                        auto expected_opt_1_11_12 = expected_opt_1_11;
                        auto rigid_out_opt_11_12 = rigid_out_opt_11;
                        entered(once_job([=]() {
                        return ({
                            auto [acc, s, taken] = p0;
                            auto arm = p1;
                            call_then(start_narrowed(env_3_7_12, s, arm, scrut_name_7_12, plain_scrut_8_12, taken), [=](crate::check::expr::Env narrowed_2375) {
                            return ({
                                auto env_arm = narrowed_2375;
                                call_then(start_infer_arm(env_arm, s, arm, plain_scrut_8_12, res_9_12, checking_10_12
                                ? expected_opt_1_11_12
                                : std::optional<crate::check::types::Ty>{}, rigid_out_opt_11_12, acc), [=](std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::check::types::St> infer_arm_2453) {
                                return ({
                                    auto [acc2, s2] = infer_arm_2453;
                                    (prism_rtl::finished(std::tuple{acc2, s2, taken_by(env_3_7_12, arm, taken)}));
                                });
                            });
                            });
                        });
                        });
                    }));
                    });
                }));
                })), [=](std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::check::types::St, Array<Text>> fold_2296) {
                    return ({
                        auto&& _layers = fold_2296;
                        auto&& layers = std::get<0>(_layers);
                        auto&& st4 = std::get<1>(_layers);
                        call_then(crate::check::passes::start_match_coverage(env_3, st4, plain_scrut, arms_2, span_5), [=](crate::check::types::St match_coverage_2608) {
                        return ({
                            auto st5 = match_coverage_2608;
                            ({
                            prism_rtl::is_some(expected_opt_1) ? ({
                            auto&& want = prism_rtl::some_of(expected_opt_1);
                            checking
                            ? prism_rtl::finished(std::tuple{want, st5})
                            : prism_rtl::more(prism_rtl::rc(MatchResult(env_3, st5, sh, layers, res, span_5)));
                        })
                            : prism_rtl::is_none(expected_opt_1) ? prism_rtl::more(prism_rtl::rc(MatchResult(env_3, st5, sh, layers, res, span_5)))
                            : throw prism_rtl::Panic("no arm matched");
                        });
                        });
                    });
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start InferMatch, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_match(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Expr scrut, Array<crate::syntax::Arm> arms, crate::syntax::Range span, std::optional<crate::check::types::Ty> expected_opt) {
    return prism_rtl::make_rc<InferMatch>(env, st, scrut, arms, span, expected_opt);
}


/// TakenBy: fn Env, Arm, [Text] -> [Text]
Array<Text> taken_by(const crate::check::expr::Env& env, const crate::syntax::Arm& arm, const Array<Text>& taken) {
    return arm.guard != std::optional<crate::syntax::Expr>{}
        ? taken
        : ({
        __label__ _done;
        prism_rtl::Slot<Array<Text>> _v;
        auto&& _m = arm.pattern;
        if (prism_rtl::is_some(_m)) {
            auto&& p_ = prism_rtl::some_of(_m);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<Array<Text>> _v;
                auto&& _m = prism_rtl::val(prism_rtl::val(p_).kind);
                if (prism_rtl::is<crate::syntax::PatternKind::PFamily>(_m)) {
                    auto&& q = prism_rtl::as<crate::syntax::PatternKind::PFamily>(_m).a0;
                    _v.set(crate::check::types::union_texts(taken, or_(crate::prelude::get(prism_rtl::val(env.g).families, crate::check::env::dotted(q->path_)), Array<Text>{})));
                    goto _done;
                }
                {
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<Array<Text>> _v;
                        auto&& _m = tag_of_pattern(env, p_);
                        if (prism_rtl::is_some(_m)) {
                            auto&& tg = prism_rtl::some_of(_m);
                            _v.set(crate::check::types::add_text(taken, prism_rtl::val(tg).name));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(taken);
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(taken);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// Narrowed: unbounded fn Env, St, Arm, Text, Ty, [Text] -> Env
crate::check::expr::Env narrowed(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Arm& arm, const Text& name, const crate::check::types::Ty& t, const Array<Text>& taken) {
    auto forwards = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = arm.pattern;
        if (prism_rtl::is_some(_m)) {
            auto&& p_ = prism_rtl::some_of(_m);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<bool> _v;
                auto&& _m = prism_rtl::val(prism_rtl::val(p_).kind);
                if (prism_rtl::is<crate::syntax::PatternKind::PFamily>(_m)) {
                    _v.set(true);
                    goto _done;
                }
                {
                    _v.set(false);
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(true);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return ((!forwards) || (name == Text::lit(""))) || (len(taken) == Nat(0u))
        ? env
        : ({
        __label__ _done;
        prism_rtl::Slot<crate::check::expr::Env> _v;
        auto&& _m = crate::check::types::recording::walk(st, t);
        if (prism_rtl::is<crate::check::types::Ty::TyElem>(_m)) {
            auto&& rw = prism_rtl::as<crate::check::types::Ty::TyElem>(_m).a0;
            auto&& o = prism_rtl::as<crate::check::types::Ty::TyElem>(_m).a1;
            _v.set(({
                auto w = crate::check::types::recording::walk_row(st, rw);
                (crate::check::expr::with_local(env, name, crate::check::types::schemes::mono(crate::check::types::Ty(crate::check::types::Ty::TyElem{crate::check::types::Rw{.fams = prism_rtl::val(w).fams, .minus = crate::check::types::union_texts(prism_rtl::val(w).minus, taken), .tail = prism_rtl::val(w).tail}, prism_rtl::rc(prism_rtl::val(o))}))));
            }));
            goto _done;
        }
        {
            _v.set(env);
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<crate::check::expr::Env> Narrowed::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& arm = this->arm;
    const auto& name = this->name;
    const auto& t = this->t;
    const auto& taken = this->taken;
    auto forwards = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = prism_rtl::val(arm).pattern;
        if (prism_rtl::is_some(_m)) {
            auto&& p_ = prism_rtl::some_of(_m);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<bool> _v;
                auto&& _m = prism_rtl::val(prism_rtl::val(p_).kind);
                if (prism_rtl::is<crate::syntax::PatternKind::PFamily>(_m)) {
                    _v.set(true);
                    goto _done;
                }
                {
                    _v.set(false);
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(true);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return ((!forwards) || (name == Text::lit(""))) || (len(taken) == Nat(0u))
        ? prism_rtl::finished(env)
        : ({
        auto arm_1 = arm;
        auto env_2 = env;
        auto name_3 = name;
        auto st_4 = st;
        auto t_5 = t;
        auto taken_6 = taken;
        call_then(crate::check::types::recording::start_walk(st_4, t_5), [=](crate::check::types::Ty walk_3793) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TyElem>(walk_3793) ? ({
            auto&& rw = prism_rtl::as<crate::check::types::Ty::TyElem>(walk_3793).a0;
            auto&& o = prism_rtl::as<crate::check::types::Ty::TyElem>(walk_3793).a1;
            call_then(crate::check::types::recording::start_walk_row(st_4, rw), [=](crate::check::types::Rw walk_row_3847) {
            return ({
                auto w = walk_row_3847;
                (prism_rtl::finished(crate::check::expr::with_local(env_2, name_3, crate::check::types::schemes::mono(crate::check::types::Ty(crate::check::types::Ty::TyElem{crate::check::types::Rw{.fams = prism_rtl::val(w).fams, .minus = crate::check::types::union_texts(prism_rtl::val(w).minus, taken_6), .tail = prism_rtl::val(w).tail}, prism_rtl::rc(prism_rtl::val(o))})))));
            });
        });
        })
            : prism_rtl::finished(env_2);
        });
    });
    });
}


/// `Start Narrowed, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::expr::Env> start_narrowed(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Arm arm, Text name, crate::check::types::Ty t, Array<Text> taken) {
    return prism_rtl::make_rc<Narrowed>(env, st, arm, name, t, taken);
}


/// InferArm: unbounded fn Env, St, Arm, Ty, Ty, ?Ty, ?Text, [((Text, Range))] -> (([((Text, Range))], St))
std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::check::types::St> infer_arm(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Arm& arm, const crate::check::types::Ty& scrut_ty, const crate::check::types::Ty& res, const std::optional<crate::check::types::Ty>& expected_opt, const std::optional<Text>& rigid_out_opt, const Array<std::tuple<Text, crate::syntax::Range>>& acc) {
    auto [env2, st1] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::check::expr::Env, crate::check::types::St>> _v;
        auto&& _m = arm.pattern;
        if (prism_rtl::is_some(_m)) {
            auto&& p_ = prism_rtl::some_of(_m);
            _v.set(crate::check::expr::patterns::bind_pattern(env, st, p_, scrut_ty, true));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(std::tuple{env, st});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto refined_out_opt = ({
        __label__ _done;
        prism_rtl::Slot<std::optional<std::tuple<Text, crate::check::types::Ty>>> _v;
        if (prism_rtl::is_some(rigid_out_opt)) {
            auto&& o = prism_rtl::some_of(rigid_out_opt);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::optional<std::tuple<Text, crate::check::types::Ty>>> _v;
                auto&& _m = arm.pattern;
                if (prism_rtl::is_some(_m)) {
                    auto&& p_ = prism_rtl::some_of(_m);
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<std::optional<std::tuple<Text, crate::check::types::Ty>>> _v;
                        auto&& _m = tag_of_pattern(env, p_);
                        if (prism_rtl::is_some(_m)) {
                            auto&& tg = prism_rtl::some_of(_m);
                            _v.set(std::optional(std::tuple{o, tg->out}));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(std::optional<std::tuple<Text, crate::check::types::Ty>>{});
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(std::optional<std::tuple<Text, crate::check::types::Ty>>{});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_none(rigid_out_opt)) {
            _v.set(std::optional<std::tuple<Text, crate::check::types::Ty>>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto st2 = ({
        __label__ _done;
        prism_rtl::Slot<crate::check::types::St> _v;
        auto&& _m = arm.guard;
        if (prism_rtl::is_some(_m)) {
            auto&& gd = prism_rtl::some_of(_m);
            _v.set(check_cond(env2, st1, gd));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(st1);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    if (prism_rtl::is_some(expected_opt)) {
        auto&& want = prism_rtl::some_of(expected_opt);
        auto refined = ({
            __label__ _done;
            prism_rtl::Slot<crate::check::types::Ty> _v;
            if (prism_rtl::is_some(refined_out_opt)) {
                auto&& o = std::get<0>(prism_rtl::some_of(refined_out_opt));
                auto&& out = std::get<1>(prism_rtl::some_of(refined_out_opt));
                _v.set(subst_rigid(o, out, crate::check::types::recording::zonk(st2, want)));
                goto _done;
            }
            if (prism_rtl::is_none(refined_out_opt)) {
                _v.set(want);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto [bt, st3] = crate::check::expr::lets::infer_expr_block(env2, st2, arm.body);
        return std::tuple{acc, arm_against(st3, refined, bt, prism_rtl::val(arm.body).span, (arm.pattern == std::optional<crate::syntax::Pattern_>{}) || is_family_arm(arm))};
    }
    if (prism_rtl::is_none(expected_opt)) {
        auto [bt, st3] = crate::check::expr::lets::infer_expr_block(env2, st2, arm.body);
        auto head = crate::check::types::head_sigil(st3, bt);
        auto plain_bt = crate::check::expr::is_time_sigil(head)
            ? crate::check::expr::inner_of(st3, bt)
            : bt;
        auto st4 = unify_arm(st3, res, plain_bt, prism_rtl::val(arm.body).span);
        auto acc2 = crate::check::expr::is_time_sigil(head)
            ? crate::prelude::push(acc, std::tuple{head, prism_rtl::val(arm.body).span})
            : crate::prelude::push(acc, std::tuple{Text::lit(""), prism_rtl::val(arm.body).span});
        auto acc3 = head == Text::lit("@")
            ? crate::prelude::push(acc2, std::tuple{Text::lit("@"), prism_rtl::val(arm.body).span})
            : acc2;
        return std::tuple{acc3, st4};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::check::types::St>> InferArm::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& arm = this->arm;
    const auto& scrut_ty = this->scrut_ty;
    const auto& res = this->res;
    const auto& expected_opt = this->expected_opt;
    const auto& rigid_out_opt = this->rigid_out_opt;
    const auto& acc = this->acc;
    auto [env2, st1] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::check::expr::Env, crate::check::types::St>> _v;
        auto&& _m = prism_rtl::val(arm).pattern;
        if (prism_rtl::is_some(_m)) {
            auto&& p_ = prism_rtl::some_of(_m);
            _v.set(crate::check::expr::patterns::bind_pattern(env, st, p_, scrut_ty, true));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(std::tuple{env, st});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto refined_out_opt = ({
        __label__ _done;
        prism_rtl::Slot<std::optional<std::tuple<Text, crate::check::types::Ty>>> _v;
        if (prism_rtl::is_some(rigid_out_opt)) {
            auto&& o = prism_rtl::some_of(rigid_out_opt);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::optional<std::tuple<Text, crate::check::types::Ty>>> _v;
                auto&& _m = prism_rtl::val(arm).pattern;
                if (prism_rtl::is_some(_m)) {
                    auto&& p_ = prism_rtl::some_of(_m);
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<std::optional<std::tuple<Text, crate::check::types::Ty>>> _v;
                        auto&& _m = tag_of_pattern(env, p_);
                        if (prism_rtl::is_some(_m)) {
                            auto&& tg = prism_rtl::some_of(_m);
                            _v.set(std::optional(std::tuple{o, tg->out}));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(std::optional<std::tuple<Text, crate::check::types::Ty>>{});
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(std::optional<std::tuple<Text, crate::check::types::Ty>>{});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_none(rigid_out_opt)) {
            _v.set(std::optional<std::tuple<Text, crate::check::types::Ty>>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto st2 = ({
        __label__ _done;
        prism_rtl::Slot<crate::check::types::St> _v;
        auto&& _m = prism_rtl::val(arm).guard;
        if (prism_rtl::is_some(_m)) {
            auto&& gd = prism_rtl::some_of(_m);
            _v.set(check_cond(env2, st1, gd));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(st1);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return ({
        prism_rtl::is_some(expected_opt) ? ({
        auto&& want = prism_rtl::some_of(expected_opt);
        ({
        auto refined = ({
            __label__ _done;
            prism_rtl::Slot<crate::check::types::Ty> _v;
            if (prism_rtl::is_some(refined_out_opt)) {
                auto&& o = std::get<0>(prism_rtl::some_of(refined_out_opt));
                auto&& out = std::get<1>(prism_rtl::some_of(refined_out_opt));
                _v.set(subst_rigid(o, out, crate::check::types::recording::zonk(st2, want)));
                goto _done;
            }
            if (prism_rtl::is_none(refined_out_opt)) {
                _v.set(want);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto acc_1 = acc;
        auto arm_2 = arm;
        call_then(crate::check::expr::lets::start_infer_expr_block(env2, st2, prism_rtl::val(arm_2).body), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_expr_block_4943) {
        return ({
            auto [bt, st3] = infer_expr_block_4943;
            call_then(start_arm_against(st3, refined, bt, prism_rtl::val(prism_rtl::val(arm_2).body).span, (prism_rtl::val(arm_2).pattern == std::optional<crate::syntax::Pattern_>{}) || is_family_arm(arm_2)), [=](crate::check::types::St arm_against_4998) { return prism_rtl::finished(std::tuple{acc_1, arm_against_4998}); });
        });
    });
    });
    })
        : prism_rtl::is_none(expected_opt) ? ({
        auto acc_1 = acc;
        auto arm_2 = arm;
        auto res_3 = res;
        call_then(crate::check::expr::lets::start_infer_expr_block(env2, st2, prism_rtl::val(arm_2).body), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_expr_block_5131) {
        return ({
            auto [bt, st3] = infer_expr_block_5131;
            call_then(crate::check::types::start_head_sigil(st3, bt), [=](Text head_sigil_5189) {
            return ({
                auto head = head_sigil_5189;
                auto plain_bt = crate::check::expr::is_time_sigil(head)
                    ? crate::check::expr::inner_of(st3, bt)
                    : bt;
                call_then(start_unify_arm(st3, res_3, plain_bt, prism_rtl::val(prism_rtl::val(arm_2).body).span), [=](crate::check::types::St unify_arm_5301) {
                return ({
                    auto st4 = unify_arm_5301;
                    auto acc2 = crate::check::expr::is_time_sigil(head)
                        ? crate::prelude::push(acc_1, std::tuple{head, prism_rtl::val(prism_rtl::val(arm_2).body).span})
                        : crate::prelude::push(acc_1, std::tuple{Text::lit(""), prism_rtl::val(prism_rtl::val(arm_2).body).span});
                    auto acc3 = head == Text::lit("@")
                        ? crate::prelude::push(acc2, std::tuple{Text::lit("@"), prism_rtl::val(prism_rtl::val(arm_2).body).span})
                        : acc2;
                    (prism_rtl::finished(std::tuple{acc3, st4}));
                });
            });
            });
        });
        });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start InferArm, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::check::types::St>> start_infer_arm(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Arm arm, crate::check::types::Ty scrut_ty, crate::check::types::Ty res, std::optional<crate::check::types::Ty> expected_opt, std::optional<Text> rigid_out_opt, Array<std::tuple<Text, crate::syntax::Range>> acc) {
    return prism_rtl::make_rc<InferArm>(env, st, arm, scrut_ty, res, expected_opt, rigid_out_opt, acc);
}


/// ArmAgainst: unbounded fn St, Ty, Ty, Range, Bool -> St
crate::check::types::St arm_against(const crate::check::types::St& st, const crate::check::types::Ty& want, const crate::check::types::Ty& bt, const crate::syntax::Range& span, const bool& forwards) {
    auto&& _m = std::tuple{crate::check::types::recording::walk(st, want), crate::check::types::recording::walk(st, bt)};
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyAt>(std::get<1>(_m))) {
        auto&& w1 = prism_rtl::as<crate::check::types::Ty::TyAt>(std::get<0>(_m)).a0;
        auto&& r1 = prism_rtl::as<crate::check::types::Ty::TyAt>(std::get<0>(_m)).a1;
        auto&& b1 = prism_rtl::as<crate::check::types::Ty::TyAt>(std::get<1>(_m)).a0;
        auto&& r2 = prism_rtl::as<crate::check::types::Ty::TyAt>(std::get<1>(_m)).a1;
        auto st2 = crate::check::types::unify::unify(st, prism_rtl::val(w1), prism_rtl::val(b1), span);
        crate::check::types::St this_ = st2;
        this_.incls = crate::prelude::push(this_.incls, crate::check::types::Incl{.sub = r2, .sup = r1, .file = this_.file, .span = span, .what = Text::lit("arm"), .forward = prism_rtl::val(forwards)});
        return this_;
    }
    {
        return crate::check::types::unify::unify(st, want, bt, span);
    }
}


prism_rtl::Turn<crate::check::types::St> ArmAgainst::cycle() const {
    const auto& st = this->st;
    const auto& want = this->want;
    const auto& bt = this->bt;
    const auto& span = this->span;
    const auto& forwards = this->forwards;
    auto bt_1 = bt;
    auto forwards_2 = prism_rtl::val(forwards);
    auto span_3 = span;
    auto st_4 = st;
    auto want_5 = want;
    return call_then(crate::check::types::recording::start_walk(st_4, want_5), [=](crate::check::types::Ty walk_5855) {
        return call_then(crate::check::types::recording::start_walk(st_4, bt_1), [=](crate::check::types::Ty walk_5872) {
            return ({
                auto&& _m = std::tuple{walk_5855, walk_5872};
                prism_rtl::is<crate::check::types::Ty::TyAt>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyAt>(std::get<1>(_m)) ? ({
                auto&& w1 = prism_rtl::as<crate::check::types::Ty::TyAt>(std::get<0>(_m)).a0;
                auto&& r1 = prism_rtl::as<crate::check::types::Ty::TyAt>(std::get<0>(_m)).a1;
                auto&& b1 = prism_rtl::as<crate::check::types::Ty::TyAt>(std::get<1>(_m)).a0;
                auto&& r2 = prism_rtl::as<crate::check::types::Ty::TyAt>(std::get<1>(_m)).a1;
                call_then(crate::check::types::unify::start_unify(st_4, prism_rtl::val(w1), prism_rtl::val(b1), span_3), [=](crate::check::types::St unify_5944) {
                return ({
                    auto st2 = unify_5944;
                    (prism_rtl::finished(({
                    crate::check::types::St this_ = st2;
                    this_.incls = crate::prelude::push(this_.incls, crate::check::types::Incl{.sub = r2, .sup = r1, .file = this_.file, .span = span_3, .what = Text::lit("arm"), .forward = forwards_2});
                    this_;
                })));
                });
            });
            })
                : prism_rtl::more(prism_rtl::rc(crate::check::types::unify::Unify(st_4, want_5, bt_1, span_3)));
            });
        });
    });
}


/// `Start ArmAgainst, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_arm_against(crate::check::types::St st, crate::check::types::Ty want, crate::check::types::Ty bt, crate::syntax::Range span, bool forwards) {
    return prism_rtl::make_rc<ArmAgainst>(st, want, bt, span, forwards);
}


/// IsFamilyArm: fn Arm -> Bool
bool is_family_arm(const crate::syntax::Arm& arm) {
    auto&& _m = arm.pattern;
    if (prism_rtl::is_some(_m)) {
        auto&& p_ = prism_rtl::some_of(_m);
        auto&& _m = prism_rtl::val(prism_rtl::val(p_).kind);
        if (prism_rtl::is<crate::syntax::PatternKind::PFamily>(_m)) {
            return true;
        }
        {
            return false;
        }
    }
    if (prism_rtl::is_none(_m)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// CheckCond: unbounded fn Env, St, Expr -> St
crate::check::types::St check_cond(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Expr& e) {
    auto [t, st2] = crate::check::expr::infer(env, st, e);
    auto inner = crate::check::expr::is_time_sigil(crate::check::types::head_sigil(st2, t))
        ? crate::check::expr::inner_of(st2, t)
        : t;
    return crate::check::types::unify::unify(st2, crate::check::types::t_bool(), inner, e.span);
}


prism_rtl::Turn<crate::check::types::St> CheckCond::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& e = this->e;
    auto e_1 = e;
    auto env_2 = env;
    auto st_3 = st;
    return call_then(crate::check::expr::start_infer(env_2, st_3, e_1), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_6481) {
        return ({
            auto [t, st2] = infer_6481;
            call_then(crate::check::types::start_head_sigil(st2, t), [=](Text head_sigil_6530) {
            return ({
                auto inner = crate::check::expr::is_time_sigil(head_sigil_6530)
                    ? crate::check::expr::inner_of(st2, t)
                    : t;
                (prism_rtl::more(prism_rtl::rc(crate::check::types::unify::Unify(st2, crate::check::types::t_bool(), inner, prism_rtl::val(e_1).span))));
            });
        });
        });
    });
}


/// `Start CheckCond, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_check_cond(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Expr e) {
    return prism_rtl::make_rc<CheckCond>(env, st, e);
}


/// ?TagOfPattern: fn Env, Pattern -> ?TagInfo
std::optional<crate::check::env::TagInfo> tag_of_pattern(const crate::check::expr::Env& env, const crate::syntax::Pattern_& p_) {
    auto&& _m = prism_rtl::val(p_.kind);
    if (prism_rtl::is<crate::syntax::PatternKind::PRecord>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::PatternKind::PRecord>(_m).a0;
        return crate::prelude::get(prism_rtl::val(env.g).tags, crate::check::env::dotted(n->path_));
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PCtor>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::PatternKind::PCtor>(_m).a0;
        return crate::prelude::get(prism_rtl::val(env.g).tags, crate::check::env::dotted(n->path_));
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        return crate::prelude::get(prism_rtl::val(env.g).tags, crate::check::env::dotted(n->path_));
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PGroup>(_m)) {
        auto&& q = prism_rtl::as<crate::syntax::PatternKind::PGroup>(_m).a0;
        return tag_of_pattern(env, prism_rtl::val(prism_rtl::val(q)));
    }
    {
        return std::optional<crate::check::env::TagInfo>{};
    }
}


/// SubstRigid: unbounded fn Text, Ty, Ty -> Ty
crate::check::types::Ty subst_rigid(const Text& name, const crate::check::types::Ty& by, const crate::check::types::Ty& t) {
    if (prism_rtl::is<crate::check::types::Ty::TyRigid>(t)) {
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyRigid>(t).a0;
        return n == name ? by : t;
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t)) {
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& args = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyCon{n, run_to_end(each_job(args, ({
            auto name_1 = name;
            auto by_2 = by;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=](crate::check::types::Ty p0) {
            return ({
                auto name_1_3 = name_1;
                auto by_2_3 = by_2;
                entered(once_job([=]() {
                return ({
                    auto a = p0;
                    (prism_rtl::more(prism_rtl::rc(SubstRigid(name_1_3, by_2_3, a))));
                });
            }));
            });
        })));
        })))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(t)) {
        auto&& c = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a0;
        auto&& ps = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a1;
        auto&& r = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a2;
        return crate::check::types::Ty(crate::check::types::Ty::TyFn{c, run_to_end(each_job(ps, ({
            auto name_1 = name;
            auto by_2 = by;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=](crate::check::types::Ty p0) {
            return ({
                auto name_1_3 = name_1;
                auto by_2_3 = by_2;
                entered(once_job([=]() {
                return ({
                    auto a = p0;
                    (prism_rtl::more(prism_rtl::rc(SubstRigid(name_1_3, by_2_3, a))));
                });
            }));
            });
        })));
        }))), prism_rtl::rc(subst_rigid(name, by, prism_rtl::val(prism_rtl::val(r))))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t)) {
        auto&& ts = prism_rtl::as<crate::check::types::Ty::TyTuple>(t).a0;
        return crate::check::types::Ty(crate::check::types::Ty::TyTuple{run_to_end(each_job(ts, ({
            auto name_1 = name;
            auto by_2 = by;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=](crate::check::types::Ty p0) {
            return ({
                auto name_1_3 = name_1;
                auto by_2_3 = by_2;
                entered(once_job([=]() {
                return ({
                    auto a = p0;
                    (prism_rtl::more(prism_rtl::rc(SubstRigid(name_1_3, by_2_3, a))));
                });
            }));
            });
        })));
        })))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(t)) {
        auto&& e = prism_rtl::as<crate::check::types::Ty::TyArray>(t).a0;
        return crate::check::types::Ty(crate::check::types::Ty::TyArray{prism_rtl::rc(subst_rigid(name, by, prism_rtl::val(prism_rtl::val(e))))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(t)) {
        auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a0;
        auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyMap{prism_rtl::rc(subst_rigid(name, by, prism_rtl::val(prism_rtl::val(k)))), prism_rtl::rc(subst_rigid(name, by, prism_rtl::val(prism_rtl::val(v_))))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t)) {
        auto&& s = prism_rtl::as<crate::check::types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TySig{s, prism_rtl::rc(subst_rigid(name, by, prism_rtl::val(prism_rtl::val(i))))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(t)) {
        auto&& i = prism_rtl::as<crate::check::types::Ty::TyAt>(t).a0;
        auto&& rw = prism_rtl::as<crate::check::types::Ty::TyAt>(t).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyAt{prism_rtl::rc(subst_rigid(name, by, prism_rtl::val(prism_rtl::val(i)))), rw});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(t)) {
        auto&& rw = prism_rtl::as<crate::check::types::Ty::TyElem>(t).a0;
        auto&& o = prism_rtl::as<crate::check::types::Ty::TyElem>(t).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyElem{rw, prism_rtl::rc(subst_rigid(name, by, prism_rtl::val(prism_rtl::val(o))))});
    }
    {
        auto&& other = t;
        return other;
    }
}


prism_rtl::Turn<crate::check::types::Ty> SubstRigid::cycle() const {
    const auto& name = this->name;
    const auto& by = this->by;
    const auto& t = this->t;
    return ({
        prism_rtl::is<crate::check::types::Ty::TyRigid>(t) ? ({
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyRigid>(t).a0;
        n == name ? prism_rtl::finished(by) : prism_rtl::finished(t);
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t) ? ({
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& args = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        ({
        auto args_1 = args;
        auto by_2 = by;
        auto n_3 = n;
        auto name_4 = name;
        call_value(each_job(args_1, ({
        auto name_4_5 = name_4;
        auto by_2_5 = by_2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=](crate::check::types::Ty p0) {
        return ({
            auto name_4_5_5 = name_4_5;
            auto by_2_5_5 = by_2_5;
            entered(once_job([=]() {
            return ({
                auto a = p0;
                (prism_rtl::more(prism_rtl::rc(SubstRigid(name_4_5_5, by_2_5_5, a))));
            });
        }));
        });
    })));
    })), [=](Array<crate::check::types::Ty> each_7117) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyCon{n_3, each_7117})); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyFn>(t) ? ({
        auto&& c = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a0;
        auto&& ps = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a1;
        auto&& r = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a2;
        ({
        auto by_1 = by;
        auto c_2 = c;
        auto name_3 = name;
        auto ps_4 = ps;
        auto r_5 = prism_rtl::val(prism_rtl::val(r));
        call_value(each_job(ps_4, ({
        auto name_3_6 = name_3;
        auto by_1_6 = by_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=](crate::check::types::Ty p0) {
        return ({
            auto name_3_6_6 = name_3_6;
            auto by_1_6_6 = by_1_6;
            entered(once_job([=]() {
            return ({
                auto a = p0;
                (prism_rtl::more(prism_rtl::rc(SubstRigid(name_3_6_6, by_1_6_6, a))));
            });
        }));
        });
    })));
    })), [=](Array<crate::check::types::Ty> each_7185) { return call_then(start_subst_rigid(name_3, by_1, r_5), [=](crate::check::types::Ty subst_rigid_7225) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyFn{c_2, each_7185, prism_rtl::rc(subst_rigid_7225)})); }); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyTuple>(t) ? ({
        auto&& ts = prism_rtl::as<crate::check::types::Ty::TyTuple>(t).a0;
        ({
        auto by_1 = by;
        auto name_2 = name;
        auto ts_3 = ts;
        call_value(each_job(ts_3, ({
        auto name_2_4 = name_2;
        auto by_1_4 = by_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=](crate::check::types::Ty p0) {
        return ({
            auto name_2_4_4 = name_2_4;
            auto by_1_4_4 = by_1_4;
            entered(once_job([=]() {
            return ({
                auto a = p0;
                (prism_rtl::more(prism_rtl::rc(SubstRigid(name_2_4_4, by_1_4_4, a))));
            });
        }));
        });
    })));
    })), [=](Array<crate::check::types::Ty> each_7274) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyTuple{each_7274})); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyArray>(t) ? ({
        auto&& e = prism_rtl::as<crate::check::types::Ty::TyArray>(t).a0;
        ({
        auto by_1 = by;
        auto e_2 = prism_rtl::val(prism_rtl::val(e));
        auto name_3 = name;
        call_then(start_subst_rigid(name_3, by_1, e_2), [=](crate::check::types::Ty subst_rigid_7336) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyArray{prism_rtl::rc(subst_rigid_7336)})); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyMap>(t) ? ({
        auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a0;
        auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a1;
        ({
        auto by_1 = by;
        auto k_2 = prism_rtl::val(prism_rtl::val(k));
        auto name_3 = name;
        auto v__4 = prism_rtl::val(prism_rtl::val(v_));
        call_then(start_subst_rigid(name_3, by_1, k_2), [=](crate::check::types::Ty subst_rigid_7383) { return call_then(start_subst_rigid(name_3, by_1, v__4), [=](crate::check::types::Ty subst_rigid_7409) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyMap{prism_rtl::rc(subst_rigid_7383), prism_rtl::rc(subst_rigid_7409)})); }); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TySig>(t) ? ({
        auto&& s = prism_rtl::as<crate::check::types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        ({
        auto by_1 = by;
        auto i_2 = prism_rtl::val(prism_rtl::val(i));
        auto name_3 = name;
        auto s_4 = s;
        call_then(start_subst_rigid(name_3, by_1, i_2), [=](crate::check::types::Ty subst_rigid_7459) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TySig{s_4, prism_rtl::rc(subst_rigid_7459)})); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyAt>(t) ? ({
        auto&& i = prism_rtl::as<crate::check::types::Ty::TyAt>(t).a0;
        auto&& rw = prism_rtl::as<crate::check::types::Ty::TyAt>(t).a1;
        ({
        auto by_1 = by;
        auto i_2 = prism_rtl::val(prism_rtl::val(i));
        auto name_3 = name;
        auto rw_4 = rw;
        call_then(start_subst_rigid(name_3, by_1, i_2), [=](crate::check::types::Ty subst_rigid_7505) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyAt{prism_rtl::rc(subst_rigid_7505), rw_4})); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyElem>(t) ? ({
        auto&& rw = prism_rtl::as<crate::check::types::Ty::TyElem>(t).a0;
        auto&& o = prism_rtl::as<crate::check::types::Ty::TyElem>(t).a1;
        ({
        auto by_1 = by;
        auto name_2 = name;
        auto o_3 = prism_rtl::val(prism_rtl::val(o));
        auto rw_4 = rw;
        call_then(start_subst_rigid(name_2, by_1, o_3), [=](crate::check::types::Ty subst_rigid_7563) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyElem{rw_4, prism_rtl::rc(subst_rigid_7563)})); });
    });
    })
        : ({
        auto&& other = t;
        prism_rtl::finished(other);
    });
    });
}


/// `Start SubstRigid, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::Ty> start_subst_rigid(Text name, crate::check::types::Ty by, crate::check::types::Ty t) {
    return prism_rtl::make_rc<SubstRigid>(name, by, t);
}


/// MatchResult: unbounded fn Env, St, Text, [((Text, Range))], Ty, Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> match_result(const crate::check::expr::Env& env, const crate::check::types::St& st, const Text& sh, const Array<std::tuple<Text, crate::syntax::Range>>& layers, const crate::check::types::Ty& res, const crate::syntax::Range& span) {
    auto events = filter(layers, [&](const std::tuple<Text, crate::syntax::Range>& _p0) {
        auto&& h = std::get<0>(_p0);
        return h == Text::lit("!");
    });
    auto dyns = filter(layers, [&](const std::tuple<Text, crate::syntax::Range>& _p0) {
        auto&& h = std::get<0>(_p0);
        return h == Text::lit("$");
    });
    auto blue = filter(layers, [&](const std::tuple<Text, crate::syntax::Range>& _p0) {
        auto&& h = std::get<0>(_p0);
        return h == Text::lit("@");
    });
    auto st2 = (len(blue) > Nat(0u)) && crate::check::expr::is_time_sigil(sh)
        ? crate::check::types::recording::err_fix(st, Text::lit("building-match"), span, Text::lit("a blueprint in a match over a dynamic; use `rebuild`"), Text::lit("write `rebuild` over the scrutinee, with `match _:` inside"))
        : st;
    auto st3 = (sh == Text::lit("!")) && (len(events) > Nat(0u))
        ? crate::check::types::recording::err_fix(st2, Text::lit("two-events"), span, Text::lit("two events in one operation"), Text::lit("an arm over an event\'s scrutinee fires with the scrutinee; read a dynamic in the arm, not an event"))
        : st2;
    return len(events) > Nat(0u)
        ? std::tuple{crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("!"), prism_rtl::rc(res)}), crate::check::expr::calls::elab(st3, span, Text::lit("match"), Text::lit("gate"), Text::lit("!"))}
        : (sh == Text::lit("$")) || (len(dyns) > Nat(0u))
        ? std::tuple{crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("$"), prism_rtl::rc(res)}), crate::check::expr::calls::elab(st3, span, Text::lit("match"), Text::lit("map"), Text::lit("$"))}
        : sh == Text::lit("!")
        ? std::tuple{crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("!"), prism_rtl::rc(res)}), crate::check::expr::calls::elab(st3, span, Text::lit("match"), Text::lit("map"), Text::lit("!"))}
        : std::tuple{res, st3};
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> MatchResult::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& sh = this->sh;
    const auto& layers = this->layers;
    const auto& res = this->res;
    const auto& span = this->span;
    auto events = filter(layers, [&](const std::tuple<Text, crate::syntax::Range>& _p0) {
        auto&& h = std::get<0>(_p0);
        return h == Text::lit("!");
    });
    auto dyns = filter(layers, [&](const std::tuple<Text, crate::syntax::Range>& _p0) {
        auto&& h = std::get<0>(_p0);
        return h == Text::lit("$");
    });
    auto blue = filter(layers, [&](const std::tuple<Text, crate::syntax::Range>& _p0) {
        auto&& h = std::get<0>(_p0);
        return h == Text::lit("@");
    });
    auto st2 = (len(blue) > Nat(0u)) && crate::check::expr::is_time_sigil(sh)
        ? crate::check::types::recording::err_fix(st, Text::lit("building-match"), span, Text::lit("a blueprint in a match over a dynamic; use `rebuild`"), Text::lit("write `rebuild` over the scrutinee, with `match _:` inside"))
        : st;
    auto st3 = (sh == Text::lit("!")) && (len(events) > Nat(0u))
        ? crate::check::types::recording::err_fix(st2, Text::lit("two-events"), span, Text::lit("two events in one operation"), Text::lit("an arm over an event\'s scrutinee fires with the scrutinee; read a dynamic in the arm, not an event"))
        : st2;
    return len(events) > Nat(0u)
        ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("!"), prism_rtl::rc(res)}), crate::check::expr::calls::elab(st3, span, Text::lit("match"), Text::lit("gate"), Text::lit("!"))})
        : (sh == Text::lit("$")) || (len(dyns) > Nat(0u))
        ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("$"), prism_rtl::rc(res)}), crate::check::expr::calls::elab(st3, span, Text::lit("match"), Text::lit("map"), Text::lit("$"))})
        : sh == Text::lit("!")
        ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("!"), prism_rtl::rc(res)}), crate::check::expr::calls::elab(st3, span, Text::lit("match"), Text::lit("map"), Text::lit("!"))})
        : prism_rtl::finished(std::tuple{res, st3});
}


/// `Start MatchResult, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_match_result(crate::check::expr::Env env, crate::check::types::St st, Text sh, Array<std::tuple<Text, crate::syntax::Range>> layers, crate::check::types::Ty res, crate::syntax::Range span) {
    return prism_rtl::make_rc<MatchResult>(env, st, sh, layers, res, span);
}


/// InferIf: unbounded fn Env, St, Cond, Block, ?Block, Range, ?Ty -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_if(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Cond& c, const crate::syntax::Block& then_b, const std::optional<crate::syntax::Block>& else_b_opt, const crate::syntax::Range& span, const std::optional<crate::check::types::Ty>& expected_opt) {
    if (prism_rtl::is<crate::syntax::Cond::CondExpr>(c)) {
        auto&& e = prism_rtl::as<crate::syntax::Cond::CondExpr>(c).a0;
        auto [ct, st1] = crate::check::expr::infer(env, st, prism_rtl::val(prism_rtl::val(e)));
        auto sh = crate::check::types::head_sigil(st1, ct);
        auto inner = crate::check::expr::is_time_sigil(sh)
            ? crate::check::expr::inner_of(st1, ct)
            : ct;
        auto st2 = crate::check::types::unify::unify(st1, crate::check::types::t_bool(), inner, prism_rtl::val(e).span);
        auto [res, st3] = crate::check::types::fresh_var(st2, false, Text::lit(""));
        auto [layers, st4] = if_branches(env, st3, env, then_b, else_b_opt, res);
        return match_result(env, st4, sh, layers, res, span);
    }
    if (prism_rtl::is<crate::syntax::Cond::CondBind>(c)) {
        auto&& p_ = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a0;
        auto&& e = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a1;
        auto&& gd_opt = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a2;
        auto [et, st1] = crate::check::expr::infer(env, st, prism_rtl::val(prism_rtl::val(e)));
        auto [env2, st2] = crate::check::expr::patterns::bind_pattern(env, st1, p_, et, true);
        auto st3 = ({
            __label__ _done;
            prism_rtl::Slot<crate::check::types::St> _v;
            auto&& _m = prism_rtl::val(prism_rtl::val(gd_opt));
            if (prism_rtl::is_some(_m)) {
                auto&& g = prism_rtl::some_of(_m);
                _v.set(check_cond(env2, st2, g));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(st2);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto [res, st4] = crate::check::types::fresh_var(st3, false, Text::lit(""));
        auto [layers, st5] = if_branches(env2, st4, env, then_b, else_b_opt, res);
        return match_result(env, st5, Text::lit(""), layers, res, span);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InferIf::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& c = this->c;
    const auto& then_b = this->then_b;
    const auto& else_b_opt = this->else_b_opt;
    const auto& span = this->span;
    const auto& expected_opt = this->expected_opt;
    return ({
        prism_rtl::is<crate::syntax::Cond::CondExpr>(c) ? ({
        auto&& e = prism_rtl::as<crate::syntax::Cond::CondExpr>(c).a0;
        ({
        auto else_b_opt_1 = else_b_opt;
        auto e_2 = prism_rtl::val(prism_rtl::val(e));
        auto env_3 = env;
        auto span_4 = span;
        auto st_5 = st;
        auto then_b_6 = then_b;
        call_then(crate::check::expr::start_infer(env_3, st_5, e_2), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_8896) {
        return ({
            auto [ct, st1] = infer_8896;
            call_then(crate::check::types::start_head_sigil(st1, ct), [=](Text head_sigil_8930) {
            return ({
                auto sh = head_sigil_8930;
                auto inner = crate::check::expr::is_time_sigil(sh)
                    ? crate::check::expr::inner_of(st1, ct)
                    : ct;
                call_then(crate::check::types::unify::start_unify(st1, crate::check::types::t_bool(), inner, prism_rtl::val(e_2).span), [=](crate::check::types::St unify_9030) {
                return ({
                    auto st2 = unify_9030;
                    auto [res, st3] = crate::check::types::fresh_var(st2, false, Text::lit(""));
                    call_then(start_if_branches(env_3, st3, env_3, then_b_6, else_b_opt_1, res), [=](std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::check::types::St> if_branches_9143) {
                    return ({
                        auto [layers, st4] = if_branches_9143;
                        (prism_rtl::more(prism_rtl::rc(MatchResult(env_3, st4, sh, layers, res, span_4))));
                    });
                });
                });
            });
            });
        });
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::Cond::CondBind>(c) ? ({
        auto&& p_ = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a0;
        auto&& e = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a1;
        auto&& gd_opt = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a2;
        ({
        auto else_b_opt_1 = else_b_opt;
        auto gd_opt_2 = prism_rtl::val(prism_rtl::val(gd_opt));
        auto c_3 = c;
        auto e_4 = prism_rtl::val(prism_rtl::val(e));
        auto env_5 = env;
        auto p__6 = p_;
        auto span_7 = span;
        auto st_8 = st;
        auto then_b_9 = then_b;
        call_then(crate::check::expr::start_infer(env_5, st_8, e_4), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_9290) {
        return ({
            auto [et, st1] = infer_9290;
            call_then(crate::check::expr::patterns::start_bind_pattern(env_5, st1, p__6, et, true), [=](std::tuple<crate::check::expr::Env, crate::check::types::St> bind_pattern_9335) {
            return ({
                auto [env2, st2] = bind_pattern_9335;
                auto st3 = ({
                    __label__ _done;
                    prism_rtl::Slot<crate::check::types::St> _v;
                    if (prism_rtl::is_some(gd_opt_2)) {
                        auto&& g = prism_rtl::some_of(gd_opt_2);
                        _v.set(check_cond(env2, st2, g));
                        goto _done;
                    }
                    if (prism_rtl::is_none(gd_opt_2)) {
                        _v.set(st2);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                auto [res, st4] = crate::check::types::fresh_var(st3, false, Text::lit(""));
                call_then(start_if_branches(env2, st4, env_5, then_b_9, else_b_opt_1, res), [=](std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::check::types::St> if_branches_9540) {
                return ({
                    auto [layers, st5] = if_branches_9540;
                    (prism_rtl::more(prism_rtl::rc(MatchResult(env_5, st5, Text::lit(""), layers, res, span_7))));
                });
            });
            });
        });
        });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start InferIf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_if(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Cond c, crate::syntax::Block then_b, std::optional<crate::syntax::Block> else_b_opt, crate::syntax::Range span, std::optional<crate::check::types::Ty> expected_opt) {
    return prism_rtl::make_rc<InferIf>(env, st, c, then_b, else_b_opt, span, expected_opt);
}


/// UnifyArm: unbounded fn St, Ty, Ty, Range -> St
crate::check::types::St unify_arm(const crate::check::types::St& st, const crate::check::types::Ty& res, const crate::check::types::Ty& t, const crate::syntax::Range& span) {
    return crate::check::types::is_flex_var(st, res) && (crate::check::types::recording::walk(st, t) == crate::check::types::Ty(crate::check::types::Ty::TyCon{Text::lit("Prelude.Error"), Array<crate::check::types::Ty>{}}))
        ? crate::check::types::unify::defer(st, res, t, span)
        : crate::check::types::unify::unify(st, res, t, span);
}


prism_rtl::Turn<crate::check::types::St> UnifyArm::cycle() const {
    const auto& st = this->st;
    const auto& res = this->res;
    const auto& t = this->t;
    const auto& span = this->span;
    auto res_1 = res;
    auto span_2 = span;
    auto st_3 = st;
    auto t_4 = t;
    return call_then(crate::check::types::start_is_flex_var(st_3, res_1), [=](bool is_flex_var_9877) {
        return is_flex_var_9877 && (crate::check::types::recording::walk(st_3, t_4) == crate::check::types::Ty(crate::check::types::Ty::TyCon{Text::lit("Prelude.Error"), Array<crate::check::types::Ty>{}}))
            ? prism_rtl::finished(crate::check::types::unify::defer(st_3, res_1, t_4, span_2))
            : prism_rtl::more(prism_rtl::rc(crate::check::types::unify::Unify(st_3, res_1, t_4, span_2)));
    });
}


/// `Start UnifyArm, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_unify_arm(crate::check::types::St st, crate::check::types::Ty res, crate::check::types::Ty t, crate::syntax::Range span) {
    return prism_rtl::make_rc<UnifyArm>(st, res, t, span);
}


/// LayerHead: fn Text -> Text
Text layer_head(const Text& h) {
    return crate::check::expr::is_time_sigil(h)
        ? h
        : h == Text::lit("@") ? Text::lit("@") : Text::lit("");
}


/// IfBranches: unbounded fn Env, St, Env, Block, ?Block, Ty -> (([((Text, Range))], St))
std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::check::types::St> if_branches(const crate::check::expr::Env& then_env, const crate::check::types::St& st, const crate::check::expr::Env& else_env, const crate::syntax::Block& then_b, const std::optional<crate::syntax::Block>& else_b_opt, const crate::check::types::Ty& res) {
    auto [t1, st1] = crate::check::expr::lets::infer_expr_block(then_env, st, then_b);
    auto h1 = crate::check::types::head_sigil(st1, t1);
    auto st2 = unify_arm(st1, res, crate::check::expr::is_time_sigil(h1)
        ? crate::check::expr::inner_of(st1, t1)
        : t1, then_b.span);
    auto l1 = Array(std::vector{std::tuple{layer_head(h1), then_b.span}});
    if (prism_rtl::is_some(else_b_opt)) {
        auto&& b = prism_rtl::some_of(else_b_opt);
        auto [t2, st3] = crate::check::expr::lets::infer_expr_block(else_env, st2, b);
        auto h2 = crate::check::types::head_sigil(st3, t2);
        auto st4 = unify_arm(st3, res, crate::check::expr::is_time_sigil(h2)
            ? crate::check::expr::inner_of(st3, t2)
            : t2, prism_rtl::val(b).span);
        return std::tuple{crate::prelude::push(l1, std::tuple{layer_head(h2), prism_rtl::val(b).span}), st4};
    }
    if (prism_rtl::is_none(else_b_opt)) {
        return std::tuple{l1, crate::check::types::unify::unify(st2, res, crate::check::types::t_unit(), then_b.span)};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::check::types::St>> IfBranches::cycle() const {
    const auto& then_env = this->then_env;
    const auto& st = this->st;
    const auto& else_env = this->else_env;
    const auto& then_b = this->then_b;
    const auto& else_b_opt = this->else_b_opt;
    const auto& res = this->res;
    auto else_b_opt_1 = else_b_opt;
    auto else_env_2 = else_env;
    auto res_3 = res;
    auto st_4 = st;
    auto then_b_5 = then_b;
    auto then_env_6 = then_env;
    return call_then(crate::check::expr::lets::start_infer_expr_block(then_env_6, st_4, then_b_5), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_expr_block_10261) {
        return ({
            auto [t1, st1] = infer_expr_block_10261;
            call_then(crate::check::types::start_head_sigil(st1, t1), [=](Text head_sigil_10308) {
            return ({
                auto h1 = head_sigil_10308;
                call_then(start_unify_arm(st1, res_3, crate::check::expr::is_time_sigil(h1)
                ? crate::check::expr::inner_of(st1, t1)
                : t1, prism_rtl::val(then_b_5).span), [=](crate::check::types::St unify_arm_10340) {
                return ({
                    auto st2 = unify_arm_10340;
                    auto l1 = Array(std::vector{std::tuple{layer_head(h1), prism_rtl::val(then_b_5).span}});
                    ({
                    prism_rtl::is_some(else_b_opt_1) ? ({
                    auto&& b = prism_rtl::some_of(else_b_opt_1);
                    ({
                    auto b_7 = b;
                    call_then(crate::check::expr::lets::start_infer_expr_block(else_env_2, st2, b_7), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_expr_block_10526) {
                    return ({
                        auto [t2, st3] = infer_expr_block_10526;
                        call_then(crate::check::types::start_head_sigil(st3, t2), [=](Text head_sigil_10578) {
                        return ({
                            auto h2 = head_sigil_10578;
                            call_then(start_unify_arm(st3, res_3, crate::check::expr::is_time_sigil(h2)
                            ? crate::check::expr::inner_of(st3, t2)
                            : t2, prism_rtl::val(b_7).span), [=](crate::check::types::St unify_arm_10618) {
                            return ({
                                auto st4 = unify_arm_10618;
                                (prism_rtl::finished(std::tuple{crate::prelude::push(l1, std::tuple{layer_head(h2), prism_rtl::val(b_7).span}), st4}));
                            });
                        });
                        });
                    });
                    });
                });
                });
                })
                    : prism_rtl::is_none(else_b_opt_1) ? call_then(crate::check::types::unify::start_unify(st2, res_3, crate::check::types::t_unit(), prism_rtl::val(then_b_5).span), [=](crate::check::types::St unify_10770) { return prism_rtl::finished(std::tuple{l1, unify_10770}); })
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            });
            });
        });
        });
    });
}


/// `Start IfBranches, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::check::types::St>> start_if_branches(crate::check::expr::Env then_env, crate::check::types::St st, crate::check::expr::Env else_env, crate::syntax::Block then_b, std::optional<crate::syntax::Block> else_b_opt, crate::check::types::Ty res) {
    return prism_rtl::make_rc<IfBranches>(then_env, st, else_env, then_b, else_b_opt, res);
}

}  // namespace crate::check::expr::lifting
