// The module `Check.Expr.Lifting`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <check/expr/lifting/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Check.Expr.Lifting`, from `target/bootstrap/cpp-src/prismc/check/expr/lifting.prism`.
namespace crate::check::expr::lifting {

/// InferMatch: unbounded fn Env, St, Expr, [Arm], Range, ?Ty -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_match(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Expr& scrut_p2, const Array<crate::syntax::Arm>& arms_p3, const crate::syntax::Range& span_p4, const std::optional<crate::check::types::Ty>& expected_o5) {
    auto [st_ty_pd, st1_pe] = crate::check::expr::infer(env_p0, st_p1, scrut_p2);
    auto sh_p6 = crate::check::types::head_sigil(st1_pe, st_ty_pd);
    auto plain_scrut_p7 = crate::check::expr::is_time_sigil(sh_p6)
        ? crate::check::expr::inner_of(st1_pe, st_ty_pd)
        : st_ty_pd;
    auto st2_p8 = sh_p6 == Text::lit("@")
        ? crate::check::types::recording::err(st1_pe, Text::lit("blueprint-operand"), scrut_p2.span, Text::lit("`match` over a blueprint; bind it first"))
        : st1_pe;
    auto rigid_out_o9 = ({
        __label__ _done;
        prism_rtl::Slot<std::optional<Text>> _v;
        auto&& _m = crate::check::types::recording::walk(st2_p8, plain_scrut_p7);
        if (prism_rtl::is<crate::check::types::Ty::TyElem>(_m)) {
            auto&& o_pf = prism_rtl::as<crate::check::types::Ty::TyElem>(_m).a1;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::optional<Text>> _v;
                auto&& _m = crate::check::types::recording::walk(st2_p8, prism_rtl::deref(o_pf));
                if (prism_rtl::is<crate::check::types::Ty::TyRigid>(_m)) {
                    auto&& name_pg = prism_rtl::as<crate::check::types::Ty::TyRigid>(_m).a0;
                    _v.set(std::optional(name_pg));
                    goto _done;
                }
                {
                    _v.set(std::optional<Text>{});
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        {
            _v.set(std::optional<Text>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto [res_ph, st3_pi] = crate::check::types::fresh_var(st2_p8, false, Text::lit(""));
    auto checking_pa = (expected_o5 != std::optional<crate::check::types::Ty>{}) && (!crate::check::expr::is_time_sigil(sh_p6));
    auto scrut_name_pb = crate::check::shrink::locals::expr_name(scrut_p2);
    auto&& _layers_pq = run_to_end(fold_job(arms_p3, std::tuple{Array<std::tuple<Text, crate::syntax::Range>>{}, st3_pi, Array<Text>{}}, ({
        auto env_p0_1 = env_p0;
        auto scrut_name_pb_2 = scrut_name_pb;
        auto plain_scrut_p7_3 = plain_scrut_p7;
        auto res_ph_4 = res_ph;
        auto checking_pa_5 = std::move(checking_pa);
        auto expected_o5_6 = expected_o5;
        auto rigid_out_o9_7 = rigid_out_o9;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::check::types::St, Array<Text>>>(std::tuple<std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::check::types::St, Array<Text>>, crate::syntax::Arm>)>>(prism_rtl::rc([=, env_p0_1 = std::move(env_p0_1), scrut_name_pb_2 = std::move(scrut_name_pb_2), plain_scrut_p7_3 = std::move(plain_scrut_p7_3), res_ph_4 = std::move(res_ph_4), checking_pa_5 = std::move(checking_pa_5), expected_o5_6 = std::move(expected_o5_6), rigid_out_o9_7 = std::move(rigid_out_o9_7)](std::tuple<std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::check::types::St, Array<Text>>, crate::syntax::Arm> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_p0_1_8 = env_p0_1;
            auto scrut_name_pb_2_8 = scrut_name_pb_2;
            auto plain_scrut_p7_3_8 = plain_scrut_p7_3;
            auto res_ph_4_8 = res_ph_4;
            auto checking_pa_5_8 = checking_pa_5;
            auto expected_o5_6_8 = expected_o5_6;
            auto rigid_out_o9_7_8 = rigid_out_o9_7;
            entered(once_job([=, env_p0_1_8 = std::move(env_p0_1_8), scrut_name_pb_2_8 = std::move(scrut_name_pb_2_8), plain_scrut_p7_3_8 = std::move(plain_scrut_p7_3_8), res_ph_4_8 = std::move(res_ph_4_8), checking_pa_5_8 = std::move(checking_pa_5_8), expected_o5_6_8 = std::move(expected_o5_6_8), rigid_out_o9_7_8 = std::move(rigid_out_o9_7_8)]() {
            return ({
                auto [acc_pj, s_pk, taken_pl] = p0;
                auto arm_pm = p1;
                call_then(start_narrowed(env_p0_1_8, s_pk, arm_pm, scrut_name_pb_2_8, plain_scrut_p7_3_8, taken_pl), [=](crate::check::expr::Env narrowed_2375) {
                return ({
                    auto env_arm_pn = narrowed_2375;
                    call_then(start_infer_arm(env_arm_pn, s_pk, arm_pm, plain_scrut_p7_3_8, res_ph_4_8, checking_pa_5_8
                    ? expected_o5_6_8
                    : std::optional<crate::check::types::Ty>{}, rigid_out_o9_7_8, acc_pj), [=](std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::check::types::St> infer_arm_2453) {
                    return ({
                        auto [acc2_po, s2_pp] = infer_arm_2453;
                        (prism_rtl::finished(std::tuple{acc2_po, s2_pp, taken_by(env_p0_1_8, arm_pm, taken_pl)}));
                    });
                });
                });
            });
            });
        }));
        });
    }));
    })));
    auto&& layers_pq = std::get<0>(_layers_pq);
    auto&& st4_pr = std::get<1>(_layers_pq);
    auto st5_pc = crate::check::passes::match_coverage(env_p0, st4_pr, plain_scrut_p7, arms_p3, span_p4);
    if (prism_rtl::is_some(expected_o5)) {
        auto&& want_ps = prism_rtl::some_of(expected_o5);
        return std::move(checking_pa)
            ? std::tuple{want_ps, st5_pc}
            : match_result(env_p0, st5_pc, sh_p6, layers_pq, res_ph, span_p4);
    }
    if (prism_rtl::is_none(expected_o5)) {
        return match_result(env_p0, st5_pc, sh_p6, layers_pq, res_ph, span_p4);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InferMatch::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& scrut_p2 = this->scrut_p2;
    const auto& arms_p3 = this->arms_p3;
    const auto& span_p4 = this->span_p4;
    const auto& expected_o5 = this->expected_o5;
    auto expected_o5_1 = expected_o5;
    auto arms_p3_2 = arms_p3;
    auto env_p0_3 = env_p0;
    auto scrut_p2_4 = scrut_p2;
    auto span_p4_5 = span_p4;
    auto st_p1_6 = st_p1;
    return call_then(crate::check::expr::start_infer(env_p0_3, st_p1_6, scrut_p2_4), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_1698) {
        return ({
            auto [st_ty_pd, st1_pe] = infer_1698;
            call_then(crate::check::types::start_head_sigil(st1_pe, st_ty_pd), [=](Text head_sigil_1732) {
            return ({
                auto sh_p6 = head_sigil_1732;
                auto plain_scrut_p7 = crate::check::expr::is_time_sigil(sh_p6)
                    ? crate::check::expr::inner_of(st1_pe, st_ty_pd)
                    : st_ty_pd;
                auto st2_p8 = sh_p6 == Text::lit("@")
                    ? crate::check::types::recording::err(st1_pe, Text::lit("blueprint-operand"), prism_rtl::deref(scrut_p2_4).span, Text::lit("`match` over a blueprint; bind it first"))
                    : st1_pe;
                call_then(crate::check::types::recording::start_walk(st2_p8, plain_scrut_p7), [=, sh_p6 = std::move(sh_p6)](crate::check::types::Ty walk_1969) {
                return ({
                    auto rigid_out_o9 = ({
                        __label__ _done;
                        prism_rtl::Slot<std::optional<Text>> _v;
                        if (prism_rtl::is<crate::check::types::Ty::TyElem>(walk_1969)) {
                            auto&& o_pf = prism_rtl::as<crate::check::types::Ty::TyElem>(walk_1969).a1;
                            _v.set(({
                                __label__ _done;
                                prism_rtl::Slot<std::optional<Text>> _v;
                                auto&& _m = crate::check::types::recording::walk(st2_p8, prism_rtl::deref(o_pf));
                                if (prism_rtl::is<crate::check::types::Ty::TyRigid>(_m)) {
                                    auto&& name_pg = prism_rtl::as<crate::check::types::Ty::TyRigid>(_m).a0;
                                    _v.set(std::optional(name_pg));
                                    goto _done;
                                }
                                {
                                    _v.set(std::optional<Text>{});
                                    goto _done;
                                }
                            _done:
                                _v.take();
                            }));
                            goto _done;
                        }
                        {
                            _v.set(std::optional<Text>{});
                            goto _done;
                        }
                    _done:
                        _v.take();
                    });
                    auto [res_ph, st3_pi] = crate::check::types::fresh_var(st2_p8, false, Text::lit(""));
                    auto checking_pa = (expected_o5_1 != std::optional<crate::check::types::Ty>{}) && (!crate::check::expr::is_time_sigil(sh_p6));
                    auto scrut_name_pb = crate::check::shrink::locals::expr_name(scrut_p2_4);
                    call_value(fold_job(arms_p3_2, std::tuple{Array<std::tuple<Text, crate::syntax::Range>>{}, st3_pi, Array<Text>{}}, ({
                    auto env_p0_3_7 = env_p0_3;
                    auto scrut_name_pb_7 = scrut_name_pb;
                    auto plain_scrut_p7_8 = plain_scrut_p7;
                    auto res_ph_9 = res_ph;
                    auto checking_pa_10 = std::move(checking_pa);
                    auto expected_o5_1_11 = expected_o5_1;
                    auto rigid_out_o9_11 = rigid_out_o9;
                    static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::check::types::St, Array<Text>>>(std::tuple<std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::check::types::St, Array<Text>>, crate::syntax::Arm>)>>(prism_rtl::rc([=, env_p0_3_7 = std::move(env_p0_3_7), scrut_name_pb_7 = std::move(scrut_name_pb_7), plain_scrut_p7_8 = std::move(plain_scrut_p7_8), res_ph_9 = std::move(res_ph_9), checking_pa_10 = std::move(checking_pa_10), expected_o5_1_11 = std::move(expected_o5_1_11), rigid_out_o9_11 = std::move(rigid_out_o9_11)](std::tuple<std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::check::types::St, Array<Text>>, crate::syntax::Arm> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto env_p0_3_7_12 = env_p0_3_7;
                        auto scrut_name_pb_7_12 = scrut_name_pb_7;
                        auto plain_scrut_p7_8_12 = plain_scrut_p7_8;
                        auto res_ph_9_12 = res_ph_9;
                        auto checking_pa_10_12 = checking_pa_10;
                        auto expected_o5_1_11_12 = expected_o5_1_11;
                        auto rigid_out_o9_11_12 = rigid_out_o9_11;
                        entered(once_job([=, env_p0_3_7_12 = std::move(env_p0_3_7_12), scrut_name_pb_7_12 = std::move(scrut_name_pb_7_12), plain_scrut_p7_8_12 = std::move(plain_scrut_p7_8_12), res_ph_9_12 = std::move(res_ph_9_12), checking_pa_10_12 = std::move(checking_pa_10_12), expected_o5_1_11_12 = std::move(expected_o5_1_11_12), rigid_out_o9_11_12 = std::move(rigid_out_o9_11_12)]() {
                        return ({
                            auto [acc_pj, s_pk, taken_pl] = p0;
                            auto arm_pm = p1;
                            call_then(start_narrowed(env_p0_3_7_12, s_pk, arm_pm, scrut_name_pb_7_12, plain_scrut_p7_8_12, taken_pl), [=](crate::check::expr::Env narrowed_2375) {
                            return ({
                                auto env_arm_pn = narrowed_2375;
                                call_then(start_infer_arm(env_arm_pn, s_pk, arm_pm, plain_scrut_p7_8_12, res_ph_9_12, checking_pa_10_12
                                ? expected_o5_1_11_12
                                : std::optional<crate::check::types::Ty>{}, rigid_out_o9_11_12, acc_pj), [=](std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::check::types::St> infer_arm_2453) {
                                return ({
                                    auto [acc2_po, s2_pp] = infer_arm_2453;
                                    (prism_rtl::finished(std::tuple{acc2_po, s2_pp, taken_by(env_p0_3_7_12, arm_pm, taken_pl)}));
                                });
                            });
                            });
                        });
                        });
                    }));
                    });
                }));
                })), [=](std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::check::types::St, Array<Text>> fold_2296) {
                    return ({
                        auto&& _layers_pq = fold_2296;
                        auto&& layers_pq = std::get<0>(_layers_pq);
                        auto&& st4_pr = std::get<1>(_layers_pq);
                        call_then(crate::check::passes::start_match_coverage(env_p0_3, st4_pr, plain_scrut_p7, arms_p3_2, span_p4_5), [=](crate::check::types::St match_coverage_2608) {
                        return ({
                            auto st5_pc = match_coverage_2608;
                            ({
                            prism_rtl::is_some(expected_o5_1) ? ({
                            auto&& want_ps = prism_rtl::some_of(expected_o5_1);
                            checking_pa
                            ? prism_rtl::finished(std::tuple{want_ps, st5_pc})
                            : prism_rtl::more(prism_rtl::rc(MatchResult(env_p0_3, st5_pc, sh_p6, layers_pq, res_ph, span_p4_5)));
                        })
                            : prism_rtl::is_none(expected_o5_1) ? prism_rtl::more(prism_rtl::rc(MatchResult(env_p0_3, st5_pc, sh_p6, layers_pq, res_ph, span_p4_5)))
                            : throw prism_rtl::Panic("no arm matched");
                        });
                        });
                    });
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start InferMatch, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_match(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Expr scrut_p2, Array<crate::syntax::Arm> arms_p3, crate::syntax::Range span_p4, std::optional<crate::check::types::Ty> expected_o5) {
    return prism_rtl::make_rc<InferMatch>(env_p0, st_p1, scrut_p2, arms_p3, span_p4, expected_o5);
}


/// TakenBy: fn Env, Arm, [Text] -> [Text]
Array<Text> taken_by(const crate::check::expr::Env& env_p0, const crate::syntax::Arm& arm_p1, const Array<Text>& taken_p2) {
    return arm_p1.guard != std::optional<crate::syntax::Expr>{}
        ? taken_p2
        : ({
        __label__ _done;
        prism_rtl::Slot<Array<Text>> _v;
        auto&& _m = arm_p1.pattern;
        if (prism_rtl::is_some(_m)) {
            auto&& p_p3 = prism_rtl::some_of(_m);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<Array<Text>> _v;
                auto&& _m = prism_rtl::deref(prism_rtl::deref(p_p3).kind);
                if (prism_rtl::is<crate::syntax::PatternKind::PFamily>(_m)) {
                    auto&& q_p4 = prism_rtl::as<crate::syntax::PatternKind::PFamily>(_m).a0;
                    _v.set(crate::check::types::union_texts(taken_p2, or_(crate::prelude::get(prism_rtl::deref(env_p0.g).families, crate::check::env::dotted(q_p4->path_)), Array<Text>{})));
                    goto _done;
                }
                {
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<Array<Text>> _v;
                        auto&& _m = tag_of_pattern(env_p0, p_p3);
                        if (prism_rtl::is_some(_m)) {
                            auto&& tg_p5 = prism_rtl::some_of(_m);
                            _v.set(crate::check::types::add_text(taken_p2, prism_rtl::deref(tg_p5).name));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(taken_p2);
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(taken_p2);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// Narrowed: unbounded fn Env, St, Arm, Text, Ty, [Text] -> Env
crate::check::expr::Env narrowed(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Arm& arm_p2, const Text& name_p3, const crate::check::types::Ty& t_p4, const Array<Text>& taken_p5) {
    auto forwards_p6 = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = arm_p2.pattern;
        if (prism_rtl::is_some(_m)) {
            auto&& p_p7 = prism_rtl::some_of(_m);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<bool> _v;
                auto&& _m = prism_rtl::deref(prism_rtl::deref(p_p7).kind);
                if (prism_rtl::is<crate::syntax::PatternKind::PFamily>(_m)) {
                    _v.set(true);
                    goto _done;
                }
                {
                    _v.set(false);
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(true);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return ((!std::move(forwards_p6)) || (name_p3 == Text::lit(""))) || (len(taken_p5) == Nat(0u))
        ? env_p0
        : ({
        __label__ _done;
        prism_rtl::Slot<crate::check::expr::Env> _v;
        auto&& _m = crate::check::types::recording::walk(st_p1, t_p4);
        if (prism_rtl::is<crate::check::types::Ty::TyElem>(_m)) {
            auto&& rw_p8 = prism_rtl::as<crate::check::types::Ty::TyElem>(_m).a0;
            auto&& o_p9 = prism_rtl::as<crate::check::types::Ty::TyElem>(_m).a1;
            _v.set(({
                auto w_pa = crate::check::types::recording::walk_row(st_p1, rw_p8);
                (crate::check::expr::with_local(env_p0, name_p3, crate::check::types::schemes::mono(crate::check::types::Ty(crate::check::types::Ty::TyElem{crate::check::types::Rw{.fams = prism_rtl::deref(w_pa).fams, .minus = crate::check::types::union_texts(prism_rtl::deref(w_pa).minus, taken_p5), .tail = prism_rtl::deref(w_pa).tail}, prism_rtl::rc(prism_rtl::deref(o_p9))}))));
            }));
            goto _done;
        }
        {
            _v.set(env_p0);
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<crate::check::expr::Env> Narrowed::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& arm_p2 = this->arm_p2;
    const auto& name_p3 = this->name_p3;
    const auto& t_p4 = this->t_p4;
    const auto& taken_p5 = this->taken_p5;
    auto forwards_p6 = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = prism_rtl::deref(arm_p2).pattern;
        if (prism_rtl::is_some(_m)) {
            auto&& p_p7 = prism_rtl::some_of(_m);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<bool> _v;
                auto&& _m = prism_rtl::deref(prism_rtl::deref(p_p7).kind);
                if (prism_rtl::is<crate::syntax::PatternKind::PFamily>(_m)) {
                    _v.set(true);
                    goto _done;
                }
                {
                    _v.set(false);
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(true);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return ((!std::move(forwards_p6)) || (name_p3 == Text::lit(""))) || (len(taken_p5) == Nat(0u))
        ? prism_rtl::finished(env_p0)
        : ({
        auto arm_p2_1 = arm_p2;
        auto env_p0_2 = env_p0;
        auto name_p3_3 = name_p3;
        auto st_p1_4 = st_p1;
        auto t_p4_5 = t_p4;
        auto taken_p5_6 = taken_p5;
        call_then(crate::check::types::recording::start_walk(st_p1_4, t_p4_5), [=, env_p0_2 = std::move(env_p0_2), name_p3_3 = std::move(name_p3_3), taken_p5_6 = std::move(taken_p5_6)](crate::check::types::Ty walk_3793) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TyElem>(walk_3793) ? ({
            auto&& rw_p8 = prism_rtl::as<crate::check::types::Ty::TyElem>(walk_3793).a0;
            auto&& o_p9 = prism_rtl::as<crate::check::types::Ty::TyElem>(walk_3793).a1;
            call_then(crate::check::types::recording::start_walk_row(st_p1_4, rw_p8), [=](crate::check::types::Rw walk_row_3847) {
            return ({
                auto w_pa = walk_row_3847;
                (prism_rtl::finished(crate::check::expr::with_local(env_p0_2, name_p3_3, crate::check::types::schemes::mono(crate::check::types::Ty(crate::check::types::Ty::TyElem{crate::check::types::Rw{.fams = prism_rtl::deref(w_pa).fams, .minus = crate::check::types::union_texts(prism_rtl::deref(w_pa).minus, taken_p5_6), .tail = prism_rtl::deref(w_pa).tail}, prism_rtl::rc(prism_rtl::deref(o_p9))})))));
            });
        });
        })
            : prism_rtl::finished(env_p0_2);
        });
    });
    });
}


/// `Start Narrowed, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::expr::Env> start_narrowed(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Arm arm_p2, Text name_p3, crate::check::types::Ty t_p4, Array<Text> taken_p5) {
    return prism_rtl::make_rc<Narrowed>(env_p0, st_p1, arm_p2, name_p3, t_p4, taken_p5);
}


/// InferArm: unbounded fn Env, St, Arm, Ty, Ty, ?Ty, ?Text, [((Text, Range))] -> (([((Text, Range))], St))
std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::check::types::St> infer_arm(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Arm& arm_p2, const crate::check::types::Ty& scrut_ty_p3, const crate::check::types::Ty& res_p4, const std::optional<crate::check::types::Ty>& expected_o5, const std::optional<Text>& rigid_out_o6, const Array<std::tuple<Text, crate::syntax::Range>>& acc_p7) {
    auto [env2_pb, st1_pc] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::check::expr::Env, crate::check::types::St>> _v;
        auto&& _m = arm_p2.pattern;
        if (prism_rtl::is_some(_m)) {
            auto&& p_pa = prism_rtl::some_of(_m);
            _v.set(crate::check::expr::patterns::bind_pattern(env_p0, st_p1, p_pa, scrut_ty_p3, true));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(std::tuple{env_p0, st_p1});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto refined_out_o8 = ({
        __label__ _done;
        prism_rtl::Slot<std::optional<std::tuple<Text, crate::check::types::Ty>>> _v;
        if (prism_rtl::is_some(rigid_out_o6)) {
            auto&& o_pd = prism_rtl::some_of(rigid_out_o6);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::optional<std::tuple<Text, crate::check::types::Ty>>> _v;
                auto&& _m = arm_p2.pattern;
                if (prism_rtl::is_some(_m)) {
                    auto&& p_pe = prism_rtl::some_of(_m);
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<std::optional<std::tuple<Text, crate::check::types::Ty>>> _v;
                        auto&& _m = tag_of_pattern(env_p0, p_pe);
                        if (prism_rtl::is_some(_m)) {
                            auto&& tg_pf = prism_rtl::some_of(_m);
                            _v.set(std::optional(std::tuple{o_pd, tg_pf->out}));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(std::optional<std::tuple<Text, crate::check::types::Ty>>{});
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(std::optional<std::tuple<Text, crate::check::types::Ty>>{});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_none(rigid_out_o6)) {
            _v.set(std::optional<std::tuple<Text, crate::check::types::Ty>>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto st2_p9 = ({
        __label__ _done;
        prism_rtl::Slot<crate::check::types::St> _v;
        auto&& _m = arm_p2.guard;
        if (prism_rtl::is_some(_m)) {
            auto&& gd_pg = prism_rtl::some_of(_m);
            _v.set(check_cond(env2_pb, st1_pc, gd_pg));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(st1_pc);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    if (prism_rtl::is_some(expected_o5)) {
        auto&& want_ph = prism_rtl::some_of(expected_o5);
        auto refined_pi = ({
            __label__ _done;
            prism_rtl::Slot<crate::check::types::Ty> _v;
            if (prism_rtl::is_some(refined_out_o8)) {
                auto&& o_pj = std::get<0>(prism_rtl::some_of(refined_out_o8));
                auto&& out_pk = std::get<1>(prism_rtl::some_of(refined_out_o8));
                _v.set(subst_rigid(o_pj, out_pk, crate::check::types::recording::zonk(st2_p9, want_ph)));
                goto _done;
            }
            if (prism_rtl::is_none(refined_out_o8)) {
                _v.set(want_ph);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto [bt_pl, st3_pm] = crate::check::expr::lets::infer_expr_block(env2_pb, st2_p9, arm_p2.body);
        return std::tuple{acc_p7, arm_against(st3_pm, refined_pi, bt_pl, prism_rtl::deref(arm_p2.body).span, (arm_p2.pattern == std::optional<crate::syntax::Pattern_>{}) || is_family_arm(arm_p2))};
    }
    if (prism_rtl::is_none(expected_o5)) {
        auto [bt_ps, st3_pt] = crate::check::expr::lets::infer_expr_block(env2_pb, st2_p9, arm_p2.body);
        auto head_pn = crate::check::types::head_sigil(st3_pt, bt_ps);
        auto plain_bt_po = crate::check::expr::is_time_sigil(head_pn)
            ? crate::check::expr::inner_of(st3_pt, bt_ps)
            : bt_ps;
        auto st4_pp = unify_arm(st3_pt, res_p4, plain_bt_po, prism_rtl::deref(arm_p2.body).span);
        auto acc2_pq = crate::check::expr::is_time_sigil(head_pn)
            ? crate::prelude::push(acc_p7, std::tuple{head_pn, prism_rtl::deref(arm_p2.body).span})
            : crate::prelude::push(acc_p7, std::tuple{Text::lit(""), prism_rtl::deref(arm_p2.body).span});
        auto acc3_pr = head_pn == Text::lit("@")
            ? crate::prelude::push(acc2_pq, std::tuple{Text::lit("@"), prism_rtl::deref(arm_p2.body).span})
            : acc2_pq;
        return std::tuple{acc3_pr, st4_pp};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::check::types::St>> InferArm::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& arm_p2 = this->arm_p2;
    const auto& scrut_ty_p3 = this->scrut_ty_p3;
    const auto& res_p4 = this->res_p4;
    const auto& expected_o5 = this->expected_o5;
    const auto& rigid_out_o6 = this->rigid_out_o6;
    const auto& acc_p7 = this->acc_p7;
    auto [env2_pb, st1_pc] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::check::expr::Env, crate::check::types::St>> _v;
        auto&& _m = prism_rtl::deref(arm_p2).pattern;
        if (prism_rtl::is_some(_m)) {
            auto&& p_pa = prism_rtl::some_of(_m);
            _v.set(crate::check::expr::patterns::bind_pattern(env_p0, st_p1, p_pa, scrut_ty_p3, true));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(std::tuple{env_p0, st_p1});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto refined_out_o8 = ({
        __label__ _done;
        prism_rtl::Slot<std::optional<std::tuple<Text, crate::check::types::Ty>>> _v;
        if (prism_rtl::is_some(rigid_out_o6)) {
            auto&& o_pd = prism_rtl::some_of(rigid_out_o6);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::optional<std::tuple<Text, crate::check::types::Ty>>> _v;
                auto&& _m = prism_rtl::deref(arm_p2).pattern;
                if (prism_rtl::is_some(_m)) {
                    auto&& p_pe = prism_rtl::some_of(_m);
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<std::optional<std::tuple<Text, crate::check::types::Ty>>> _v;
                        auto&& _m = tag_of_pattern(env_p0, p_pe);
                        if (prism_rtl::is_some(_m)) {
                            auto&& tg_pf = prism_rtl::some_of(_m);
                            _v.set(std::optional(std::tuple{o_pd, tg_pf->out}));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(std::optional<std::tuple<Text, crate::check::types::Ty>>{});
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(std::optional<std::tuple<Text, crate::check::types::Ty>>{});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_none(rigid_out_o6)) {
            _v.set(std::optional<std::tuple<Text, crate::check::types::Ty>>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto st2_p9 = ({
        __label__ _done;
        prism_rtl::Slot<crate::check::types::St> _v;
        auto&& _m = prism_rtl::deref(arm_p2).guard;
        if (prism_rtl::is_some(_m)) {
            auto&& gd_pg = prism_rtl::some_of(_m);
            _v.set(check_cond(env2_pb, st1_pc, gd_pg));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(st1_pc);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return ({
        prism_rtl::is_some(expected_o5) ? ({
        auto&& want_ph = prism_rtl::some_of(expected_o5);
        ({
        auto refined_pi = ({
            __label__ _done;
            prism_rtl::Slot<crate::check::types::Ty> _v;
            if (prism_rtl::is_some(refined_out_o8)) {
                auto&& o_pj = std::get<0>(prism_rtl::some_of(refined_out_o8));
                auto&& out_pk = std::get<1>(prism_rtl::some_of(refined_out_o8));
                _v.set(subst_rigid(o_pj, out_pk, crate::check::types::recording::zonk(st2_p9, want_ph)));
                goto _done;
            }
            if (prism_rtl::is_none(refined_out_o8)) {
                _v.set(want_ph);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto acc_p7_1 = acc_p7;
        auto arm_p2_2 = arm_p2;
        call_then(crate::check::expr::lets::start_infer_expr_block(env2_pb, st2_p9, prism_rtl::deref(arm_p2_2).body), [=, refined_pi = std::move(refined_pi), acc_p7_1 = std::move(acc_p7_1)](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_expr_block_4943) {
        return ({
            auto [bt_pl, st3_pm] = infer_expr_block_4943;
            call_then(start_arm_against(st3_pm, refined_pi, bt_pl, prism_rtl::deref(prism_rtl::deref(arm_p2_2).body).span, (prism_rtl::deref(arm_p2_2).pattern == std::optional<crate::syntax::Pattern_>{}) || is_family_arm(arm_p2_2)), [=](crate::check::types::St arm_against_4998) { return prism_rtl::finished(std::tuple{acc_p7_1, arm_against_4998}); });
        });
    });
    });
    })
        : prism_rtl::is_none(expected_o5) ? ({
        auto acc_p7_1 = acc_p7;
        auto arm_p2_2 = arm_p2;
        auto res_p4_3 = res_p4;
        call_then(crate::check::expr::lets::start_infer_expr_block(env2_pb, st2_p9, prism_rtl::deref(arm_p2_2).body), [=, acc_p7_1 = std::move(acc_p7_1), res_p4_3 = std::move(res_p4_3)](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_expr_block_5131) {
        return ({
            auto [bt_ps, st3_pt] = infer_expr_block_5131;
            call_then(crate::check::types::start_head_sigil(st3_pt, bt_ps), [=](Text head_sigil_5189) {
            return ({
                auto head_pn = head_sigil_5189;
                auto plain_bt_po = crate::check::expr::is_time_sigil(head_pn)
                    ? crate::check::expr::inner_of(st3_pt, bt_ps)
                    : bt_ps;
                call_then(start_unify_arm(st3_pt, res_p4_3, plain_bt_po, prism_rtl::deref(prism_rtl::deref(arm_p2_2).body).span), [=, head_pn = std::move(head_pn)](crate::check::types::St unify_arm_5301) {
                return ({
                    auto st4_pp = unify_arm_5301;
                    auto acc2_pq = crate::check::expr::is_time_sigil(head_pn)
                        ? crate::prelude::push(acc_p7_1, std::tuple{head_pn, prism_rtl::deref(prism_rtl::deref(arm_p2_2).body).span})
                        : crate::prelude::push(acc_p7_1, std::tuple{Text::lit(""), prism_rtl::deref(prism_rtl::deref(arm_p2_2).body).span});
                    auto acc3_pr = head_pn == Text::lit("@")
                        ? crate::prelude::push(acc2_pq, std::tuple{Text::lit("@"), prism_rtl::deref(prism_rtl::deref(arm_p2_2).body).span})
                        : acc2_pq;
                    (prism_rtl::finished(std::tuple{acc3_pr, st4_pp}));
                });
            });
            });
        });
        });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start InferArm, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::check::types::St>> start_infer_arm(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Arm arm_p2, crate::check::types::Ty scrut_ty_p3, crate::check::types::Ty res_p4, std::optional<crate::check::types::Ty> expected_o5, std::optional<Text> rigid_out_o6, Array<std::tuple<Text, crate::syntax::Range>> acc_p7) {
    return prism_rtl::make_rc<InferArm>(env_p0, st_p1, arm_p2, scrut_ty_p3, res_p4, expected_o5, rigid_out_o6, acc_p7);
}


/// ArmAgainst: unbounded fn St, Ty, Ty, Range, Bool -> St
crate::check::types::St arm_against(const crate::check::types::St& st_p0, const crate::check::types::Ty& want_p1, const crate::check::types::Ty& bt_p2, const crate::syntax::Range& span_p3, const bool& forwards_p4) {
    auto&& _m = std::tuple{crate::check::types::recording::walk(st_p0, want_p1), crate::check::types::recording::walk(st_p0, bt_p2)};
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyAt>(std::get<1>(_m))) {
        auto&& w1_p5 = prism_rtl::as<crate::check::types::Ty::TyAt>(std::get<0>(_m)).a0;
        auto&& r1_p6 = prism_rtl::as<crate::check::types::Ty::TyAt>(std::get<0>(_m)).a1;
        auto&& b1_p7 = prism_rtl::as<crate::check::types::Ty::TyAt>(std::get<1>(_m)).a0;
        auto&& r2_p8 = prism_rtl::as<crate::check::types::Ty::TyAt>(std::get<1>(_m)).a1;
        auto st2_p9 = crate::check::types::unify::unify(st_p0, prism_rtl::deref(w1_p5), prism_rtl::deref(b1_p7), span_p3);
        crate::check::types::St this_ = st2_p9;
        this_.incls = crate::prelude::push(this_.incls, crate::check::types::Incl{.sub = r2_p8, .sup = r1_p6, .file = this_.file, .span = span_p3, .what = Text::lit("arm"), .forward = forwards_p4});
        return this_;
    }
    {
        return crate::check::types::unify::unify(st_p0, want_p1, bt_p2, span_p3);
    }
}


prism_rtl::Turn<crate::check::types::St> ArmAgainst::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& want_p1 = this->want_p1;
    const auto& bt_p2 = this->bt_p2;
    const auto& span_p3 = this->span_p3;
    const auto& forwards_p4 = this->forwards_p4;
    auto bt_p2_1 = bt_p2;
    auto forwards_p4_2 = prism_rtl::deref(forwards_p4);
    auto span_p3_3 = span_p3;
    auto st_p0_4 = st_p0;
    auto want_p1_5 = want_p1;
    return call_then(crate::check::types::recording::start_walk(st_p0_4, want_p1_5), [=](crate::check::types::Ty walk_5855) {
        return call_then(crate::check::types::recording::start_walk(st_p0_4, bt_p2_1), [=](crate::check::types::Ty walk_5872) {
            return ({
                auto&& _m = std::tuple{walk_5855, walk_5872};
                prism_rtl::is<crate::check::types::Ty::TyAt>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyAt>(std::get<1>(_m)) ? ({
                auto&& w1_p5 = prism_rtl::as<crate::check::types::Ty::TyAt>(std::get<0>(_m)).a0;
                auto&& r1_p6 = prism_rtl::as<crate::check::types::Ty::TyAt>(std::get<0>(_m)).a1;
                auto&& b1_p7 = prism_rtl::as<crate::check::types::Ty::TyAt>(std::get<1>(_m)).a0;
                auto&& r2_p8 = prism_rtl::as<crate::check::types::Ty::TyAt>(std::get<1>(_m)).a1;
                call_then(crate::check::types::unify::start_unify(st_p0_4, prism_rtl::deref(w1_p5), prism_rtl::deref(b1_p7), span_p3_3), [=](crate::check::types::St unify_5944) {
                return ({
                    auto st2_p9 = unify_5944;
                    (prism_rtl::finished(({
                    crate::check::types::St this_ = st2_p9;
                    this_.incls = crate::prelude::push(this_.incls, crate::check::types::Incl{.sub = r2_p8, .sup = r1_p6, .file = this_.file, .span = span_p3_3, .what = Text::lit("arm"), .forward = forwards_p4_2});
                    (std::move(this_));
                })));
                });
            });
            })
                : prism_rtl::more(prism_rtl::rc(crate::check::types::unify::Unify(st_p0_4, want_p1_5, bt_p2_1, span_p3_3)));
            });
        });
    });
}


/// `Start ArmAgainst, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_arm_against(crate::check::types::St st_p0, crate::check::types::Ty want_p1, crate::check::types::Ty bt_p2, crate::syntax::Range span_p3, bool forwards_p4) {
    return prism_rtl::make_rc<ArmAgainst>(st_p0, want_p1, bt_p2, span_p3, forwards_p4);
}


/// IsFamilyArm: fn Arm -> Bool
bool is_family_arm(const crate::syntax::Arm& arm_p0) {
    auto&& _m = arm_p0.pattern;
    if (prism_rtl::is_some(_m)) {
        auto&& p_p1 = prism_rtl::some_of(_m);
        auto&& _m = prism_rtl::deref(prism_rtl::deref(p_p1).kind);
        if (prism_rtl::is<crate::syntax::PatternKind::PFamily>(_m)) {
            return true;
        }
        {
            return false;
        }
    }
    if (prism_rtl::is_none(_m)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// CheckCond: unbounded fn Env, St, Expr -> St
crate::check::types::St check_cond(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Expr& e_p2) {
    auto [t_p4, st2_p5] = crate::check::expr::infer(env_p0, st_p1, e_p2);
    auto inner_p3 = crate::check::expr::is_time_sigil(crate::check::types::head_sigil(st2_p5, t_p4))
        ? crate::check::expr::inner_of(st2_p5, t_p4)
        : t_p4;
    return crate::check::types::unify::unify(st2_p5, crate::check::types::t_bool(), inner_p3, e_p2.span);
}


prism_rtl::Turn<crate::check::types::St> CheckCond::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& e_p2 = this->e_p2;
    auto e_p2_1 = e_p2;
    auto env_p0_2 = env_p0;
    auto st_p1_3 = st_p1;
    return call_then(crate::check::expr::start_infer(env_p0_2, st_p1_3, e_p2_1), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_6481) {
        return ({
            auto [t_p4, st2_p5] = infer_6481;
            call_then(crate::check::types::start_head_sigil(st2_p5, t_p4), [=](Text head_sigil_6530) {
            return ({
                auto inner_p3 = crate::check::expr::is_time_sigil(head_sigil_6530)
                    ? crate::check::expr::inner_of(st2_p5, t_p4)
                    : t_p4;
                (prism_rtl::more(prism_rtl::rc(crate::check::types::unify::Unify(st2_p5, crate::check::types::t_bool(), inner_p3, prism_rtl::deref(e_p2_1).span))));
            });
        });
        });
    });
}


/// `Start CheckCond, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_check_cond(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Expr e_p2) {
    return prism_rtl::make_rc<CheckCond>(env_p0, st_p1, e_p2);
}


/// ?TagOfPattern: fn Env, Pattern -> ?TagInfo
std::optional<crate::check::env::TagInfo> tag_of_pattern(const crate::check::expr::Env& env_p0, const crate::syntax::Pattern_& p_p1) {
    auto&& _m = prism_rtl::deref(p_p1.kind);
    if (prism_rtl::is<crate::syntax::PatternKind::PRecord>(_m)) {
        auto&& n_p2 = prism_rtl::as<crate::syntax::PatternKind::PRecord>(_m).a0;
        return crate::prelude::get(prism_rtl::deref(env_p0.g).tags, crate::check::env::dotted(n_p2->path_));
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PCtor>(_m)) {
        auto&& n_p3 = prism_rtl::as<crate::syntax::PatternKind::PCtor>(_m).a0;
        return crate::prelude::get(prism_rtl::deref(env_p0.g).tags, crate::check::env::dotted(n_p3->path_));
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
        auto&& n_p4 = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        return crate::prelude::get(prism_rtl::deref(env_p0.g).tags, crate::check::env::dotted(n_p4->path_));
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PGroup>(_m)) {
        auto&& q_p5 = prism_rtl::as<crate::syntax::PatternKind::PGroup>(_m).a0;
        return tag_of_pattern(env_p0, prism_rtl::deref(prism_rtl::deref(q_p5)));
    }
    {
        return std::optional<crate::check::env::TagInfo>{};
    }
}


/// SubstRigid: unbounded fn Text, Ty, Ty -> Ty
crate::check::types::Ty subst_rigid(const Text& name_p0, const crate::check::types::Ty& by_p1, const crate::check::types::Ty& t_p2) {
    if (prism_rtl::is<crate::check::types::Ty::TyRigid>(t_p2)) {
        auto&& n_p3 = prism_rtl::as<crate::check::types::Ty::TyRigid>(t_p2).a0;
        return n_p3 == name_p0 ? by_p1 : t_p2;
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t_p2)) {
        auto&& n_p4 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p2).a0;
        auto&& args_p5 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p2).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyCon{n_p4, run_to_end(each_job(args_p5, ({
            auto name_p0_1 = name_p0;
            auto by_p1_2 = by_p1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, name_p0_1 = std::move(name_p0_1), by_p1_2 = std::move(by_p1_2)](crate::check::types::Ty p0) {
            return ({
                auto name_p0_1_3 = name_p0_1;
                auto by_p1_2_3 = by_p1_2;
                entered(once_job([=, name_p0_1_3 = std::move(name_p0_1_3), by_p1_2_3 = std::move(by_p1_2_3)]() {
                return ({
                    auto a_p6 = p0;
                    (prism_rtl::more(prism_rtl::rc(SubstRigid(name_p0_1_3, by_p1_2_3, a_p6))));
                });
            }));
            });
        })));
        })))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(t_p2)) {
        auto&& c_p7 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p2).a0;
        auto&& ps_p8 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p2).a1;
        auto&& r_p9 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p2).a2;
        return crate::check::types::Ty(crate::check::types::Ty::TyFn{c_p7, run_to_end(each_job(ps_p8, ({
            auto name_p0_1 = name_p0;
            auto by_p1_2 = by_p1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, name_p0_1 = std::move(name_p0_1), by_p1_2 = std::move(by_p1_2)](crate::check::types::Ty p0) {
            return ({
                auto name_p0_1_3 = name_p0_1;
                auto by_p1_2_3 = by_p1_2;
                entered(once_job([=, name_p0_1_3 = std::move(name_p0_1_3), by_p1_2_3 = std::move(by_p1_2_3)]() {
                return ({
                    auto a_pa = p0;
                    (prism_rtl::more(prism_rtl::rc(SubstRigid(name_p0_1_3, by_p1_2_3, a_pa))));
                });
            }));
            });
        })));
        }))), prism_rtl::rc(subst_rigid(name_p0, by_p1, prism_rtl::deref(prism_rtl::deref(r_p9))))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t_p2)) {
        auto&& ts_pb = prism_rtl::as<crate::check::types::Ty::TyTuple>(t_p2).a0;
        return crate::check::types::Ty(crate::check::types::Ty::TyTuple{run_to_end(each_job(ts_pb, ({
            auto name_p0_1 = name_p0;
            auto by_p1_2 = by_p1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, name_p0_1 = std::move(name_p0_1), by_p1_2 = std::move(by_p1_2)](crate::check::types::Ty p0) {
            return ({
                auto name_p0_1_3 = name_p0_1;
                auto by_p1_2_3 = by_p1_2;
                entered(once_job([=, name_p0_1_3 = std::move(name_p0_1_3), by_p1_2_3 = std::move(by_p1_2_3)]() {
                return ({
                    auto a_pc = p0;
                    (prism_rtl::more(prism_rtl::rc(SubstRigid(name_p0_1_3, by_p1_2_3, a_pc))));
                });
            }));
            });
        })));
        })))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(t_p2)) {
        auto&& e_pd = prism_rtl::as<crate::check::types::Ty::TyArray>(t_p2).a0;
        return crate::check::types::Ty(crate::check::types::Ty::TyArray{prism_rtl::rc(subst_rigid(name_p0, by_p1, prism_rtl::deref(prism_rtl::deref(e_pd))))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(t_p2)) {
        auto&& k_pe = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p2).a0;
        auto&& v_pf = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p2).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyMap{prism_rtl::rc(subst_rigid(name_p0, by_p1, prism_rtl::deref(prism_rtl::deref(k_pe)))), prism_rtl::rc(subst_rigid(name_p0, by_p1, prism_rtl::deref(prism_rtl::deref(v_pf))))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t_p2)) {
        auto&& s_pg = prism_rtl::as<crate::check::types::Ty::TySig>(t_p2).a0;
        auto&& i_ph = prism_rtl::as<crate::check::types::Ty::TySig>(t_p2).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TySig{s_pg, prism_rtl::rc(subst_rigid(name_p0, by_p1, prism_rtl::deref(prism_rtl::deref(i_ph))))});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(t_p2)) {
        auto&& i_pi = prism_rtl::as<crate::check::types::Ty::TyAt>(t_p2).a0;
        auto&& rw_pj = prism_rtl::as<crate::check::types::Ty::TyAt>(t_p2).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyAt{prism_rtl::rc(subst_rigid(name_p0, by_p1, prism_rtl::deref(prism_rtl::deref(i_pi)))), rw_pj});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(t_p2)) {
        auto&& rw_pk = prism_rtl::as<crate::check::types::Ty::TyElem>(t_p2).a0;
        auto&& o_pl = prism_rtl::as<crate::check::types::Ty::TyElem>(t_p2).a1;
        return crate::check::types::Ty(crate::check::types::Ty::TyElem{rw_pk, prism_rtl::rc(subst_rigid(name_p0, by_p1, prism_rtl::deref(prism_rtl::deref(o_pl))))});
    }
    {
        auto&& other_pm = t_p2;
        return other_pm;
    }
}


prism_rtl::Turn<crate::check::types::Ty> SubstRigid::cycle() const {
    const auto& name_p0 = this->name_p0;
    const auto& by_p1 = this->by_p1;
    const auto& t_p2 = this->t_p2;
    return ({
        prism_rtl::is<crate::check::types::Ty::TyRigid>(t_p2) ? ({
        auto&& n_p3 = prism_rtl::as<crate::check::types::Ty::TyRigid>(t_p2).a0;
        n_p3 == name_p0 ? prism_rtl::finished(by_p1) : prism_rtl::finished(t_p2);
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t_p2) ? ({
        auto&& n_p4 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p2).a0;
        auto&& args_p5 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p2).a1;
        ({
        auto args_p5_1 = args_p5;
        auto by_p1_2 = by_p1;
        auto n_p4_3 = n_p4;
        auto name_p0_4 = name_p0;
        call_value(each_job(args_p5_1, ({
        auto name_p0_4_5 = name_p0_4;
        auto by_p1_2_5 = by_p1_2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, name_p0_4_5 = std::move(name_p0_4_5), by_p1_2_5 = std::move(by_p1_2_5)](crate::check::types::Ty p0) {
        return ({
            auto name_p0_4_5_5 = name_p0_4_5;
            auto by_p1_2_5_5 = by_p1_2_5;
            entered(once_job([=, name_p0_4_5_5 = std::move(name_p0_4_5_5), by_p1_2_5_5 = std::move(by_p1_2_5_5)]() {
            return ({
                auto a_p6 = p0;
                (prism_rtl::more(prism_rtl::rc(SubstRigid(name_p0_4_5_5, by_p1_2_5_5, a_p6))));
            });
        }));
        });
    })));
    })), [=, n_p4_3 = std::move(n_p4_3)](Array<crate::check::types::Ty> each_7117) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyCon{n_p4_3, each_7117})); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyFn>(t_p2) ? ({
        auto&& c_p7 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p2).a0;
        auto&& ps_p8 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p2).a1;
        auto&& r_p9 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p2).a2;
        ({
        auto by_p1_1 = by_p1;
        auto c_p7_2 = c_p7;
        auto name_p0_3 = name_p0;
        auto ps_p8_4 = ps_p8;
        auto r_p9_5 = prism_rtl::deref(prism_rtl::deref(r_p9));
        call_value(each_job(ps_p8_4, ({
        auto name_p0_3_6 = name_p0_3;
        auto by_p1_1_6 = by_p1_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, name_p0_3_6 = std::move(name_p0_3_6), by_p1_1_6 = std::move(by_p1_1_6)](crate::check::types::Ty p0) {
        return ({
            auto name_p0_3_6_6 = name_p0_3_6;
            auto by_p1_1_6_6 = by_p1_1_6;
            entered(once_job([=, name_p0_3_6_6 = std::move(name_p0_3_6_6), by_p1_1_6_6 = std::move(by_p1_1_6_6)]() {
            return ({
                auto a_pa = p0;
                (prism_rtl::more(prism_rtl::rc(SubstRigid(name_p0_3_6_6, by_p1_1_6_6, a_pa))));
            });
        }));
        });
    })));
    })), [=, c_p7_2 = std::move(c_p7_2), r_p9_5 = std::move(r_p9_5)](Array<crate::check::types::Ty> each_7185) { return call_then(start_subst_rigid(name_p0_3, by_p1_1, r_p9_5), [=](crate::check::types::Ty subst_rigid_7225) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyFn{c_p7_2, each_7185, prism_rtl::rc(subst_rigid_7225)})); }); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyTuple>(t_p2) ? ({
        auto&& ts_pb = prism_rtl::as<crate::check::types::Ty::TyTuple>(t_p2).a0;
        ({
        auto by_p1_1 = by_p1;
        auto name_p0_2 = name_p0;
        auto ts_pb_3 = ts_pb;
        call_value(each_job(ts_pb_3, ({
        auto name_p0_2_4 = name_p0_2;
        auto by_p1_1_4 = by_p1_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=, name_p0_2_4 = std::move(name_p0_2_4), by_p1_1_4 = std::move(by_p1_1_4)](crate::check::types::Ty p0) {
        return ({
            auto name_p0_2_4_4 = name_p0_2_4;
            auto by_p1_1_4_4 = by_p1_1_4;
            entered(once_job([=, name_p0_2_4_4 = std::move(name_p0_2_4_4), by_p1_1_4_4 = std::move(by_p1_1_4_4)]() {
            return ({
                auto a_pc = p0;
                (prism_rtl::more(prism_rtl::rc(SubstRigid(name_p0_2_4_4, by_p1_1_4_4, a_pc))));
            });
        }));
        });
    })));
    })), [=](Array<crate::check::types::Ty> each_7274) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyTuple{each_7274})); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyArray>(t_p2) ? ({
        auto&& e_pd = prism_rtl::as<crate::check::types::Ty::TyArray>(t_p2).a0;
        ({
        auto by_p1_1 = by_p1;
        auto e_pd_2 = prism_rtl::deref(prism_rtl::deref(e_pd));
        auto name_p0_3 = name_p0;
        call_then(start_subst_rigid(name_p0_3, by_p1_1, e_pd_2), [=](crate::check::types::Ty subst_rigid_7336) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyArray{prism_rtl::rc(subst_rigid_7336)})); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyMap>(t_p2) ? ({
        auto&& k_pe = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p2).a0;
        auto&& v_pf = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p2).a1;
        ({
        auto by_p1_1 = by_p1;
        auto k_pe_2 = prism_rtl::deref(prism_rtl::deref(k_pe));
        auto name_p0_3 = name_p0;
        auto v_pf_4 = prism_rtl::deref(prism_rtl::deref(v_pf));
        call_then(start_subst_rigid(name_p0_3, by_p1_1, k_pe_2), [=, v_pf_4 = std::move(v_pf_4)](crate::check::types::Ty subst_rigid_7383) { return call_then(start_subst_rigid(name_p0_3, by_p1_1, v_pf_4), [=](crate::check::types::Ty subst_rigid_7409) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyMap{prism_rtl::rc(subst_rigid_7383), prism_rtl::rc(subst_rigid_7409)})); }); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TySig>(t_p2) ? ({
        auto&& s_pg = prism_rtl::as<crate::check::types::Ty::TySig>(t_p2).a0;
        auto&& i_ph = prism_rtl::as<crate::check::types::Ty::TySig>(t_p2).a1;
        ({
        auto by_p1_1 = by_p1;
        auto i_ph_2 = prism_rtl::deref(prism_rtl::deref(i_ph));
        auto name_p0_3 = name_p0;
        auto s_pg_4 = s_pg;
        call_then(start_subst_rigid(name_p0_3, by_p1_1, i_ph_2), [=, s_pg_4 = std::move(s_pg_4)](crate::check::types::Ty subst_rigid_7459) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TySig{s_pg_4, prism_rtl::rc(subst_rigid_7459)})); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyAt>(t_p2) ? ({
        auto&& i_pi = prism_rtl::as<crate::check::types::Ty::TyAt>(t_p2).a0;
        auto&& rw_pj = prism_rtl::as<crate::check::types::Ty::TyAt>(t_p2).a1;
        ({
        auto by_p1_1 = by_p1;
        auto i_pi_2 = prism_rtl::deref(prism_rtl::deref(i_pi));
        auto name_p0_3 = name_p0;
        auto rw_pj_4 = rw_pj;
        call_then(start_subst_rigid(name_p0_3, by_p1_1, i_pi_2), [=, rw_pj_4 = std::move(rw_pj_4)](crate::check::types::Ty subst_rigid_7505) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyAt{prism_rtl::rc(subst_rigid_7505), rw_pj_4})); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyElem>(t_p2) ? ({
        auto&& rw_pk = prism_rtl::as<crate::check::types::Ty::TyElem>(t_p2).a0;
        auto&& o_pl = prism_rtl::as<crate::check::types::Ty::TyElem>(t_p2).a1;
        ({
        auto by_p1_1 = by_p1;
        auto name_p0_2 = name_p0;
        auto o_pl_3 = prism_rtl::deref(prism_rtl::deref(o_pl));
        auto rw_pk_4 = rw_pk;
        call_then(start_subst_rigid(name_p0_2, by_p1_1, o_pl_3), [=, rw_pk_4 = std::move(rw_pk_4)](crate::check::types::Ty subst_rigid_7563) { return prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyElem{rw_pk_4, prism_rtl::rc(subst_rigid_7563)})); });
    });
    })
        : ({
        auto&& other_pm = t_p2;
        prism_rtl::finished(other_pm);
    });
    });
}


/// `Start SubstRigid, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::Ty> start_subst_rigid(Text name_p0, crate::check::types::Ty by_p1, crate::check::types::Ty t_p2) {
    return prism_rtl::make_rc<SubstRigid>(name_p0, by_p1, t_p2);
}


/// MatchResult: unbounded fn Env, St, Text, [((Text, Range))], Ty, Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> match_result(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const Text& sh_p2, const Array<std::tuple<Text, crate::syntax::Range>>& layers_p3, const crate::check::types::Ty& res_p4, const crate::syntax::Range& span_p5) {
    auto events_p6 = filter(layers_p3, [&](const std::tuple<Text, crate::syntax::Range>& _p0) {
        auto&& h_pb = std::get<0>(_p0);
        return h_pb == Text::lit("!");
    });
    auto dyns_p7 = filter(layers_p3, [&](const std::tuple<Text, crate::syntax::Range>& _p0) {
        auto&& h_pc = std::get<0>(_p0);
        return h_pc == Text::lit("$");
    });
    auto blue_p8 = filter(layers_p3, [&](const std::tuple<Text, crate::syntax::Range>& _p0) {
        auto&& h_pd = std::get<0>(_p0);
        return h_pd == Text::lit("@");
    });
    auto st2_p9 = (len(blue_p8) > Nat(0u)) && crate::check::expr::is_time_sigil(sh_p2)
        ? crate::check::types::recording::err_fix(st_p1, Text::lit("building-match"), span_p5, Text::lit("a blueprint in a match over a dynamic; use `rebuild`"), Text::lit("write `rebuild` over the scrutinee, with `match _:` inside"))
        : st_p1;
    auto st3_pa = (sh_p2 == Text::lit("!")) && (len(events_p6) > Nat(0u))
        ? crate::check::types::recording::err_fix(st2_p9, Text::lit("two-events"), span_p5, Text::lit("two events in one operation"), Text::lit("an arm over an event\'s scrutinee fires with the scrutinee; read a dynamic in the arm, not an event"))
        : st2_p9;
    return len(events_p6) > Nat(0u)
        ? std::tuple{crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("!"), prism_rtl::rc(res_p4)}), crate::check::expr::calls::elab(st3_pa, span_p5, Text::lit("match"), Text::lit("gate"), Text::lit("!"))}
        : (sh_p2 == Text::lit("$")) || (len(dyns_p7) > Nat(0u))
        ? std::tuple{crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("$"), prism_rtl::rc(res_p4)}), crate::check::expr::calls::elab(st3_pa, span_p5, Text::lit("match"), Text::lit("map"), Text::lit("$"))}
        : sh_p2 == Text::lit("!")
        ? std::tuple{crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("!"), prism_rtl::rc(res_p4)}), crate::check::expr::calls::elab(st3_pa, span_p5, Text::lit("match"), Text::lit("map"), Text::lit("!"))}
        : std::tuple{res_p4, st3_pa};
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> MatchResult::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& sh_p2 = this->sh_p2;
    const auto& layers_p3 = this->layers_p3;
    const auto& res_p4 = this->res_p4;
    const auto& span_p5 = this->span_p5;
    auto events_p6 = filter(layers_p3, [&](const std::tuple<Text, crate::syntax::Range>& _p0) {
        auto&& h_pb = std::get<0>(_p0);
        return h_pb == Text::lit("!");
    });
    auto dyns_p7 = filter(layers_p3, [&](const std::tuple<Text, crate::syntax::Range>& _p0) {
        auto&& h_pc = std::get<0>(_p0);
        return h_pc == Text::lit("$");
    });
    auto blue_p8 = filter(layers_p3, [&](const std::tuple<Text, crate::syntax::Range>& _p0) {
        auto&& h_pd = std::get<0>(_p0);
        return h_pd == Text::lit("@");
    });
    auto st2_p9 = (len(blue_p8) > Nat(0u)) && crate::check::expr::is_time_sigil(sh_p2)
        ? crate::check::types::recording::err_fix(st_p1, Text::lit("building-match"), span_p5, Text::lit("a blueprint in a match over a dynamic; use `rebuild`"), Text::lit("write `rebuild` over the scrutinee, with `match _:` inside"))
        : st_p1;
    auto st3_pa = (sh_p2 == Text::lit("!")) && (len(events_p6) > Nat(0u))
        ? crate::check::types::recording::err_fix(st2_p9, Text::lit("two-events"), span_p5, Text::lit("two events in one operation"), Text::lit("an arm over an event\'s scrutinee fires with the scrutinee; read a dynamic in the arm, not an event"))
        : st2_p9;
    return len(events_p6) > Nat(0u)
        ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("!"), prism_rtl::rc(res_p4)}), crate::check::expr::calls::elab(st3_pa, span_p5, Text::lit("match"), Text::lit("gate"), Text::lit("!"))})
        : (sh_p2 == Text::lit("$")) || (len(dyns_p7) > Nat(0u))
        ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("$"), prism_rtl::rc(res_p4)}), crate::check::expr::calls::elab(st3_pa, span_p5, Text::lit("match"), Text::lit("map"), Text::lit("$"))})
        : sh_p2 == Text::lit("!")
        ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("!"), prism_rtl::rc(res_p4)}), crate::check::expr::calls::elab(st3_pa, span_p5, Text::lit("match"), Text::lit("map"), Text::lit("!"))})
        : prism_rtl::finished(std::tuple{res_p4, st3_pa});
}


/// `Start MatchResult, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_match_result(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Text sh_p2, Array<std::tuple<Text, crate::syntax::Range>> layers_p3, crate::check::types::Ty res_p4, crate::syntax::Range span_p5) {
    return prism_rtl::make_rc<MatchResult>(env_p0, st_p1, sh_p2, layers_p3, res_p4, span_p5);
}


/// InferIf: unbounded fn Env, St, Cond, Block, ?Block, Range, ?Ty -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_if(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Cond& c_p2, const crate::syntax::Block& then_b_p3, const std::optional<crate::syntax::Block>& else_b_o4, const crate::syntax::Range& span_p5, const std::optional<crate::check::types::Ty>& expected_o6) {
    if (prism_rtl::is<crate::syntax::Cond::CondExpr>(c_p2)) {
        auto&& e_p7 = prism_rtl::as<crate::syntax::Cond::CondExpr>(c_p2).a0;
        auto [ct_pb, st1_pc] = crate::check::expr::infer(env_p0, st_p1, prism_rtl::deref(prism_rtl::deref(e_p7)));
        auto sh_p8 = crate::check::types::head_sigil(st1_pc, ct_pb);
        auto inner_p9 = crate::check::expr::is_time_sigil(sh_p8)
            ? crate::check::expr::inner_of(st1_pc, ct_pb)
            : ct_pb;
        auto st2_pa = crate::check::types::unify::unify(st1_pc, crate::check::types::t_bool(), inner_p9, prism_rtl::deref(e_p7).span);
        auto [res_pd, st3_pe] = crate::check::types::fresh_var(st2_pa, false, Text::lit(""));
        auto [layers_pf, st4_pg] = if_branches(env_p0, st3_pe, env_p0, then_b_p3, else_b_o4, res_pd);
        return match_result(env_p0, st4_pg, sh_p8, layers_pf, res_pd, span_p5);
    }
    if (prism_rtl::is<crate::syntax::Cond::CondBind>(c_p2)) {
        auto&& p_ph = prism_rtl::as<crate::syntax::Cond::CondBind>(c_p2).a0;
        auto&& e_pi = prism_rtl::as<crate::syntax::Cond::CondBind>(c_p2).a1;
        auto&& gd_oj = prism_rtl::as<crate::syntax::Cond::CondBind>(c_p2).a2;
        auto [et_pl, st1_pm] = crate::check::expr::infer(env_p0, st_p1, prism_rtl::deref(prism_rtl::deref(e_pi)));
        auto [env2_pn, st2_po] = crate::check::expr::patterns::bind_pattern(env_p0, st1_pm, p_ph, et_pl, true);
        auto st3_pk = ({
            __label__ _done;
            prism_rtl::Slot<crate::check::types::St> _v;
            auto&& _m = prism_rtl::deref(prism_rtl::deref(gd_oj));
            if (prism_rtl::is_some(_m)) {
                auto&& g_pp = prism_rtl::some_of(_m);
                _v.set(check_cond(env2_pn, st2_po, g_pp));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(st2_po);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto [res_pq, st4_pr] = crate::check::types::fresh_var(st3_pk, false, Text::lit(""));
        auto [layers_ps, st5_pt] = if_branches(env2_pn, st4_pr, env_p0, then_b_p3, else_b_o4, res_pq);
        return match_result(env_p0, st5_pt, Text::lit(""), layers_ps, res_pq, span_p5);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InferIf::cycle() const {
    const auto& env_p0 = this->env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& c_p2 = this->c_p2;
    const auto& then_b_p3 = this->then_b_p3;
    const auto& else_b_o4 = this->else_b_o4;
    const auto& span_p5 = this->span_p5;
    const auto& expected_o6 = this->expected_o6;
    return ({
        prism_rtl::is<crate::syntax::Cond::CondExpr>(c_p2) ? ({
        auto&& e_p7 = prism_rtl::as<crate::syntax::Cond::CondExpr>(c_p2).a0;
        ({
        auto else_b_o4_1 = else_b_o4;
        auto e_p7_2 = prism_rtl::deref(prism_rtl::deref(e_p7));
        auto env_p0_3 = env_p0;
        auto span_p5_4 = span_p5;
        auto st_p1_5 = st_p1;
        auto then_b_p3_6 = then_b_p3;
        call_then(crate::check::expr::start_infer(env_p0_3, st_p1_5, e_p7_2), [=, else_b_o4_1 = std::move(else_b_o4_1), span_p5_4 = std::move(span_p5_4), then_b_p3_6 = std::move(then_b_p3_6)](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_8896) {
        return ({
            auto [ct_pb, st1_pc] = infer_8896;
            call_then(crate::check::types::start_head_sigil(st1_pc, ct_pb), [=](Text head_sigil_8930) {
            return ({
                auto sh_p8 = head_sigil_8930;
                auto inner_p9 = crate::check::expr::is_time_sigil(sh_p8)
                    ? crate::check::expr::inner_of(st1_pc, ct_pb)
                    : ct_pb;
                call_then(crate::check::types::unify::start_unify(st1_pc, crate::check::types::t_bool(), inner_p9, prism_rtl::deref(e_p7_2).span), [=, sh_p8 = std::move(sh_p8)](crate::check::types::St unify_9030) {
                return ({
                    auto st2_pa = unify_9030;
                    auto [res_pd, st3_pe] = crate::check::types::fresh_var(st2_pa, false, Text::lit(""));
                    call_then(start_if_branches(env_p0_3, st3_pe, env_p0_3, then_b_p3_6, else_b_o4_1, res_pd), [=](std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::check::types::St> if_branches_9143) {
                    return ({
                        auto [layers_pf, st4_pg] = if_branches_9143;
                        (prism_rtl::more(prism_rtl::rc(MatchResult(env_p0_3, st4_pg, sh_p8, layers_pf, res_pd, span_p5_4))));
                    });
                });
                });
            });
            });
        });
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::Cond::CondBind>(c_p2) ? ({
        auto&& p_ph = prism_rtl::as<crate::syntax::Cond::CondBind>(c_p2).a0;
        auto&& e_pi = prism_rtl::as<crate::syntax::Cond::CondBind>(c_p2).a1;
        auto&& gd_oj = prism_rtl::as<crate::syntax::Cond::CondBind>(c_p2).a2;
        ({
        auto else_b_o4_1 = else_b_o4;
        auto gd_oj_2 = prism_rtl::deref(prism_rtl::deref(gd_oj));
        auto c_p2_3 = c_p2;
        auto e_pi_4 = prism_rtl::deref(prism_rtl::deref(e_pi));
        auto env_p0_5 = env_p0;
        auto p_ph_6 = p_ph;
        auto span_p5_7 = span_p5;
        auto st_p1_8 = st_p1;
        auto then_b_p3_9 = then_b_p3;
        call_then(crate::check::expr::start_infer(env_p0_5, st_p1_8, e_pi_4), [=, else_b_o4_1 = std::move(else_b_o4_1), gd_oj_2 = std::move(gd_oj_2), p_ph_6 = std::move(p_ph_6), span_p5_7 = std::move(span_p5_7), then_b_p3_9 = std::move(then_b_p3_9)](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_9290) {
        return ({
            auto [et_pl, st1_pm] = infer_9290;
            call_then(crate::check::expr::patterns::start_bind_pattern(env_p0_5, st1_pm, p_ph_6, et_pl, true), [=](std::tuple<crate::check::expr::Env, crate::check::types::St> bind_pattern_9335) {
            return ({
                auto [env2_pn, st2_po] = bind_pattern_9335;
                auto st3_pk = ({
                    __label__ _done;
                    prism_rtl::Slot<crate::check::types::St> _v;
                    if (prism_rtl::is_some(gd_oj_2)) {
                        auto&& g_pp = prism_rtl::some_of(gd_oj_2);
                        _v.set(check_cond(env2_pn, st2_po, g_pp));
                        goto _done;
                    }
                    if (prism_rtl::is_none(gd_oj_2)) {
                        _v.set(st2_po);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                auto [res_pq, st4_pr] = crate::check::types::fresh_var(st3_pk, false, Text::lit(""));
                call_then(start_if_branches(env2_pn, st4_pr, env_p0_5, then_b_p3_9, else_b_o4_1, res_pq), [=](std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::check::types::St> if_branches_9540) {
                return ({
                    auto [layers_ps, st5_pt] = if_branches_9540;
                    (prism_rtl::more(prism_rtl::rc(MatchResult(env_p0_5, st5_pt, Text::lit(""), layers_ps, res_pq, span_p5_7))));
                });
            });
            });
        });
        });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start InferIf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_if(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Cond c_p2, crate::syntax::Block then_b_p3, std::optional<crate::syntax::Block> else_b_o4, crate::syntax::Range span_p5, std::optional<crate::check::types::Ty> expected_o6) {
    return prism_rtl::make_rc<InferIf>(env_p0, st_p1, c_p2, then_b_p3, else_b_o4, span_p5, expected_o6);
}


/// UnifyArm: unbounded fn St, Ty, Ty, Range -> St
crate::check::types::St unify_arm(const crate::check::types::St& st_p0, const crate::check::types::Ty& res_p1, const crate::check::types::Ty& t_p2, const crate::syntax::Range& span_p3) {
    return crate::check::types::is_flex_var(st_p0, res_p1) && (crate::check::types::recording::walk(st_p0, t_p2) == crate::check::types::Ty(crate::check::types::Ty::TyCon{Text::lit("Prelude.Error"), Array<crate::check::types::Ty>{}}))
        ? crate::check::types::unify::defer(st_p0, res_p1, t_p2, span_p3)
        : crate::check::types::unify::unify(st_p0, res_p1, t_p2, span_p3);
}


prism_rtl::Turn<crate::check::types::St> UnifyArm::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& res_p1 = this->res_p1;
    const auto& t_p2 = this->t_p2;
    const auto& span_p3 = this->span_p3;
    auto res_p1_1 = res_p1;
    auto span_p3_2 = span_p3;
    auto st_p0_3 = st_p0;
    auto t_p2_4 = t_p2;
    return call_then(crate::check::types::start_is_flex_var(st_p0_3, res_p1_1), [=](bool is_flex_var_9877) {
        return is_flex_var_9877 && (crate::check::types::recording::walk(st_p0_3, t_p2_4) == crate::check::types::Ty(crate::check::types::Ty::TyCon{Text::lit("Prelude.Error"), Array<crate::check::types::Ty>{}}))
            ? prism_rtl::finished(crate::check::types::unify::defer(st_p0_3, res_p1_1, t_p2_4, span_p3_2))
            : prism_rtl::more(prism_rtl::rc(crate::check::types::unify::Unify(st_p0_3, res_p1_1, t_p2_4, span_p3_2)));
    });
}


/// `Start UnifyArm, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_unify_arm(crate::check::types::St st_p0, crate::check::types::Ty res_p1, crate::check::types::Ty t_p2, crate::syntax::Range span_p3) {
    return prism_rtl::make_rc<UnifyArm>(st_p0, res_p1, t_p2, span_p3);
}


/// LayerHead: fn Text -> Text
Text layer_head(const Text& h_p0) {
    return crate::check::expr::is_time_sigil(h_p0)
        ? h_p0
        : h_p0 == Text::lit("@") ? Text::lit("@") : Text::lit("");
}


/// IfBranches: unbounded fn Env, St, Env, Block, ?Block, Ty -> (([((Text, Range))], St))
std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::check::types::St> if_branches(const crate::check::expr::Env& then_env_p0, const crate::check::types::St& st_p1, const crate::check::expr::Env& else_env_p2, const crate::syntax::Block& then_b_p3, const std::optional<crate::syntax::Block>& else_b_o4, const crate::check::types::Ty& res_p5) {
    auto [t1_p9, st1_pa] = crate::check::expr::lets::infer_expr_block(then_env_p0, st_p1, then_b_p3);
    auto h1_p6 = crate::check::types::head_sigil(st1_pa, t1_p9);
    auto st2_p7 = unify_arm(st1_pa, res_p5, crate::check::expr::is_time_sigil(h1_p6)
        ? crate::check::expr::inner_of(st1_pa, t1_p9)
        : t1_p9, then_b_p3.span);
    auto l1_p8 = Array(std::vector{std::tuple{layer_head(h1_p6), then_b_p3.span}});
    if (prism_rtl::is_some(else_b_o4)) {
        auto&& b_pb = prism_rtl::some_of(else_b_o4);
        auto [t2_pe, st3_pf] = crate::check::expr::lets::infer_expr_block(else_env_p2, st2_p7, b_pb);
        auto h2_pc = crate::check::types::head_sigil(st3_pf, t2_pe);
        auto st4_pd = unify_arm(st3_pf, res_p5, crate::check::expr::is_time_sigil(h2_pc)
            ? crate::check::expr::inner_of(st3_pf, t2_pe)
            : t2_pe, prism_rtl::deref(b_pb).span);
        return std::tuple{crate::prelude::push(l1_p8, std::tuple{layer_head(h2_pc), prism_rtl::deref(b_pb).span}), st4_pd};
    }
    if (prism_rtl::is_none(else_b_o4)) {
        return std::tuple{l1_p8, crate::check::types::unify::unify(st2_p7, res_p5, crate::check::types::t_unit(), then_b_p3.span)};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::check::types::St>> IfBranches::cycle() const {
    const auto& then_env_p0 = this->then_env_p0;
    const auto& st_p1 = this->st_p1;
    const auto& else_env_p2 = this->else_env_p2;
    const auto& then_b_p3 = this->then_b_p3;
    const auto& else_b_o4 = this->else_b_o4;
    const auto& res_p5 = this->res_p5;
    auto else_b_o4_1 = else_b_o4;
    auto else_env_p2_2 = else_env_p2;
    auto res_p5_3 = res_p5;
    auto st_p1_4 = st_p1;
    auto then_b_p3_5 = then_b_p3;
    auto then_env_p0_6 = then_env_p0;
    return call_then(crate::check::expr::lets::start_infer_expr_block(then_env_p0_6, st_p1_4, then_b_p3_5), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_expr_block_10261) {
        return ({
            auto [t1_p9, st1_pa] = infer_expr_block_10261;
            call_then(crate::check::types::start_head_sigil(st1_pa, t1_p9), [=](Text head_sigil_10308) {
            return ({
                auto h1_p6 = head_sigil_10308;
                call_then(start_unify_arm(st1_pa, res_p5_3, crate::check::expr::is_time_sigil(h1_p6)
                ? crate::check::expr::inner_of(st1_pa, t1_p9)
                : t1_p9, prism_rtl::deref(then_b_p3_5).span), [=](crate::check::types::St unify_arm_10340) {
                return ({
                    auto st2_p7 = unify_arm_10340;
                    auto l1_p8 = Array(std::vector{std::tuple{layer_head(h1_p6), prism_rtl::deref(then_b_p3_5).span}});
                    ({
                    prism_rtl::is_some(else_b_o4_1) ? ({
                    auto&& b_pb = prism_rtl::some_of(else_b_o4_1);
                    ({
                    auto b_pb_7 = b_pb;
                    call_then(crate::check::expr::lets::start_infer_expr_block(else_env_p2_2, st2_p7, b_pb_7), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_expr_block_10526) {
                    return ({
                        auto [t2_pe, st3_pf] = infer_expr_block_10526;
                        call_then(crate::check::types::start_head_sigil(st3_pf, t2_pe), [=](Text head_sigil_10578) {
                        return ({
                            auto h2_pc = head_sigil_10578;
                            call_then(start_unify_arm(st3_pf, res_p5_3, crate::check::expr::is_time_sigil(h2_pc)
                            ? crate::check::expr::inner_of(st3_pf, t2_pe)
                            : t2_pe, prism_rtl::deref(b_pb_7).span), [=](crate::check::types::St unify_arm_10618) {
                            return ({
                                auto st4_pd = unify_arm_10618;
                                (prism_rtl::finished(std::tuple{crate::prelude::push(l1_p8, std::tuple{layer_head(h2_pc), prism_rtl::deref(b_pb_7).span}), st4_pd}));
                            });
                        });
                        });
                    });
                    });
                });
                });
                })
                    : prism_rtl::is_none(else_b_o4_1) ? call_then(crate::check::types::unify::start_unify(st2_p7, res_p5_3, crate::check::types::t_unit(), prism_rtl::deref(then_b_p3_5).span), [=, l1_p8 = std::move(l1_p8)](crate::check::types::St unify_10770) { return prism_rtl::finished(std::tuple{l1_p8, unify_10770}); })
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            });
            });
        });
        });
    });
}


/// `Start IfBranches, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::check::types::St>> start_if_branches(crate::check::expr::Env then_env_p0, crate::check::types::St st_p1, crate::check::expr::Env else_env_p2, crate::syntax::Block then_b_p3, std::optional<crate::syntax::Block> else_b_o4, crate::check::types::Ty res_p5) {
    return prism_rtl::make_rc<IfBranches>(then_env_p0, st_p1, else_env_p2, then_b_p3, else_b_o4, res_p5);
}

}  // namespace crate::check::expr::lifting
