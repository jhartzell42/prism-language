// The modules `Syntax.Lexer`, `Syntax.Lexer.Chars`, `Syntax.Lexer.Corpus`, `Syntax.Lexer.Layout`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <syntax/lexer/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/lexer/chars/generic.hpp>

// The module `Syntax.Lexer`, from `target/bootstrap/cpp-src/prismc/syntax/lexer/mod.prism`.
namespace crate::syntax::lexer {

bool AttrTok::operator==(const AttrTok& o) const { return name_p == o.name_p && tokens_p == o.tokens_p && span_p == o.span_p; }

void AttrTok::show(Printer& p) const {
    p.record("AttrTok", {{"name", name_p}, {"tokens", tokens_p}, {"span", span_p}});
}

Pod AttrTok::to_pod() const {
    return Pod::record("AttrTok", {{"name", prism_rtl::to_pod(name_p)}, {"tokens", prism_rtl::to_pod(tokens_p)}, {"span", prism_rtl::to_pod(span_p)}});
}

Result<AttrTok> AttrTok::from_pod(const Pod& whole) {
    return AttrTok{.name_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .tokens_p = TRY(prism_rtl::from_pod<Array<Tok>>(TRY(crate::prelude::field(whole, "tokens")))), .span_p = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span"))))};
}


bool Lex::operator==(const Lex& o) const { return src_p == o.src_p && pos_p == o.pos_p && diags_p == o.diags_p && mode_p == o.mode_p && tokens_p == o.tokens_p && layout_p == o.layout_p && frames_p == o.frames_p && last_ws_p == o.last_ws_p && lambda_open_p == o.lambda_open_p && pending_open_p == o.pending_open_p && pending_span_p == o.pending_span_p && line_first_p == o.line_first_p && mark_line_start_p == o.mark_line_start_p && first_line_p == o.first_line_p && test_pending_p == o.test_pending_p && test_depth_o == o.test_depth_o && check_depth_o == o.check_depth_o && path_next_p == o.path_next_p; }

void Lex::show(Printer& p) const {
    p.record("Lex", {{"src", src_p}, {"pos", pos_p}, {"diags", diags_p}, {"mode", mode_p}, {"tokens", tokens_p}, {"layout", layout_p}, {"frames", frames_p}, {"lastWs", last_ws_p}, {"lambdaOpen", lambda_open_p}, {"pendingOpen", pending_open_p}, {"pendingSpan", pending_span_p}, {"lineFirst", line_first_p}, {"markLineStart", mark_line_start_p}, {"firstLine", first_line_p}, {"testPending", test_pending_p}, {"testDepth", test_depth_o}, {"checkDepth", check_depth_o}, {"pathNext", path_next_p}});
}

Pod Lex::to_pod() const {
    return Pod::record("Lex", {{"src", prism_rtl::to_pod(src_p)}, {"pos", prism_rtl::to_pod(pos_p)}, {"diags", prism_rtl::to_pod(diags_p)}, {"mode", prism_rtl::to_pod(mode_p)}, {"tokens", prism_rtl::to_pod(tokens_p)}, {"layout", prism_rtl::to_pod(layout_p)}, {"frames", prism_rtl::to_pod(frames_p)}, {"lastWs", prism_rtl::to_pod(last_ws_p)}, {"lambdaOpen", prism_rtl::to_pod(lambda_open_p)}, {"pendingOpen", prism_rtl::to_pod(pending_open_p)}, {"pendingSpan", prism_rtl::to_pod(pending_span_p)}, {"lineFirst", prism_rtl::to_pod(line_first_p)}, {"markLineStart", prism_rtl::to_pod(mark_line_start_p)}, {"firstLine", prism_rtl::to_pod(first_line_p)}, {"testPending", prism_rtl::to_pod(test_pending_p)}, {"testDepth", prism_rtl::to_pod(test_depth_o)}, {"checkDepth", prism_rtl::to_pod(check_depth_o)}, {"pathNext", prism_rtl::to_pod(path_next_p)}});
}

Result<Lex> Lex::from_pod(const Pod& whole) {
    return Lex{.src_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "src")))), .pos_p = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "pos")))), .diags_p = TRY(prism_rtl::from_pod<Array<crate::syntax::Diag>>(TRY(crate::prelude::field(whole, "diags")))), .mode_p = TRY(prism_rtl::from_pod<Mode>(TRY(crate::prelude::field(whole, "mode")))), .tokens_p = TRY(prism_rtl::from_pod<Array<Tok>>(TRY(crate::prelude::field(whole, "tokens")))), .layout_p = TRY(prism_rtl::from_pod<Array<Nat>>(TRY(crate::prelude::field(whole, "layout")))), .frames_p = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "frames")))), .last_ws_p = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "lastWs")))), .lambda_open_p = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "lambdaOpen")))), .pending_open_p = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "pendingOpen")))), .pending_span_p = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "pendingSpan")))), .line_first_p = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "lineFirst")))), .mark_line_start_p = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "markLineStart")))), .first_line_p = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "firstLine")))), .test_pending_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "testPending")))), .test_depth_o = TRY(prism_rtl::from_pod<std::optional<Nat>>(TRY(crate::prelude::field(whole, "testDepth")))), .check_depth_o = TRY(prism_rtl::from_pod<std::optional<Nat>>(TRY(crate::prelude::field(whole, "checkDepth")))), .path_next_p = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "pathNext"))))};
}


bool Lexed::operator==(const Lexed& o) const { return tokens_p == o.tokens_p && diags_p == o.diags_p; }

void Lexed::show(Printer& p) const {
    p.record("Lexed", {{"tokens", tokens_p}, {"diags", diags_p}});
}

Pod Lexed::to_pod() const {
    return Pod::record("Lexed", {{"tokens", prism_rtl::to_pod(tokens_p)}, {"diags", prism_rtl::to_pod(diags_p)}});
}

Result<Lexed> Lexed::from_pod(const Pod& whole) {
    return Lexed{.tokens_p = TRY(prism_rtl::from_pod<Array<Tok>>(TRY(crate::prelude::field(whole, "tokens")))), .diags_p = TRY(prism_rtl::from_pod<Array<crate::syntax::Diag>>(TRY(crate::prelude::field(whole, "diags"))))};
}


void Mode::show(Printer& p) const {
    if (auto c = std::get_if<MFile>(&cases())) p.choice("MFile", {});
    else if (auto c = std::get_if<MBrace>(&cases())) p.choice("MBrace", {c->a0});
    else if (auto c = std::get_if<MPlaceholder>(&cases())) p.choice("MPlaceholder", {c->a0});
    else if (auto c = std::get_if<MPathKey>(&cases())) p.choice("MPathKey", {});
}

Pod Mode::to_pod() const {
    return std::holds_alternative<MFile>(cases()) ? Pod::choice("MFile", {})
        : std::holds_alternative<MBrace>(cases()) ? Pod::choice("MBrace", {prism_rtl::to_pod(std::get<MBrace>(cases()).a0)})
        : std::holds_alternative<MPlaceholder>(cases()) ? Pod::choice("MPlaceholder", {prism_rtl::to_pod(std::get<MPlaceholder>(cases()).a0)})
        : std::holds_alternative<MPathKey>(cases()) ? Pod::choice("MPathKey", {})
        : Pod();
}

Result<Mode> Mode::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "MFile" && c->args.size() == 0) return Mode(MFile{});
        if (c->ctor == "MBrace" && c->args.size() == 1) return Mode(MBrace{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "MPlaceholder" && c->args.size() == 1) return Mode(MPlaceholder{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "MPathKey" && c->args.size() == 0) return Mode(MPathKey{});
    }
    return mismatch<Mode>("a Mode", p);
}


void NameCase::show(Printer& p) const {
    if (auto c = std::get_if<CaseLower>(&cases())) p.choice("CaseLower", {});
    else if (auto c = std::get_if<CaseUpper>(&cases())) p.choice("CaseUpper", {});
    else if (auto c = std::get_if<CaseTopic>(&cases())) p.choice("CaseTopic", {});
    else if (auto c = std::get_if<CaseHole>(&cases())) p.choice("CaseHole", {});
    else if (auto c = std::get_if<CaseReserved>(&cases())) p.choice("CaseReserved", {});
}

Pod NameCase::to_pod() const {
    return std::holds_alternative<CaseLower>(cases()) ? Pod::choice("CaseLower", {})
        : std::holds_alternative<CaseUpper>(cases()) ? Pod::choice("CaseUpper", {})
        : std::holds_alternative<CaseTopic>(cases()) ? Pod::choice("CaseTopic", {})
        : std::holds_alternative<CaseHole>(cases()) ? Pod::choice("CaseHole", {})
        : std::holds_alternative<CaseReserved>(cases()) ? Pod::choice("CaseReserved", {})
        : Pod();
}

Result<NameCase> NameCase::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "CaseLower" && c->args.size() == 0) return NameCase(CaseLower{});
        if (c->ctor == "CaseUpper" && c->args.size() == 0) return NameCase(CaseUpper{});
        if (c->ctor == "CaseTopic" && c->args.size() == 0) return NameCase(CaseTopic{});
        if (c->ctor == "CaseHole" && c->args.size() == 0) return NameCase(CaseHole{});
        if (c->ctor == "CaseReserved" && c->args.size() == 0) return NameCase(CaseReserved{});
    }
    return mismatch<NameCase>("a NameCase", p);
}


void NameTok::show(Printer& p) const {
    p.record("NameTok", {{"sigils", sigils_p}, {"path", path_p}, {"case", case_p}});
}

Pod NameTok::to_pod() const {
    return Pod::record("NameTok", {{"sigils", prism_rtl::to_pod(sigils_p)}, {"path", prism_rtl::to_pod(path_p)}, {"case", prism_rtl::to_pod(case_p)}});
}

Result<NameTok> NameTok::from_pod(const Pod& whole) {
    return NameTok{.sigils_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "sigils")))), .path_p = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "path")))), .case_p = TRY(prism_rtl::from_pod<NameCase>(TRY(crate::prelude::field(whole, "case"))))};
}


bool PathSegTok::PstKey::operator==(const PstKey& o) const { return a0 == o.a0; }

void PathSegTok::show(Printer& p) const {
    if (auto c = std::get_if<PstNum>(&cases())) p.choice("PstNum", {c->a0});
    else if (auto c = std::get_if<PstGen>(&cases())) p.choice("PstGen", {c->a0});
    else if (auto c = std::get_if<PstKey>(&cases())) p.choice("PstKey", {c->a0});
}

Pod PathSegTok::to_pod() const {
    return std::holds_alternative<PstNum>(cases()) ? Pod::choice("PstNum", {prism_rtl::to_pod(std::get<PstNum>(cases()).a0)})
        : std::holds_alternative<PstGen>(cases()) ? Pod::choice("PstGen", {prism_rtl::to_pod(std::get<PstGen>(cases()).a0)})
        : std::holds_alternative<PstKey>(cases()) ? Pod::choice("PstKey", {prism_rtl::to_pod(std::get<PstKey>(cases()).a0)})
        : Pod();
}

Result<PathSegTok> PathSegTok::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "PstNum" && c->args.size() == 1) return PathSegTok(PstNum{TRY(prism_rtl::from_pod<Nat>(c->args[0]))});
        if (c->ctor == "PstGen" && c->args.size() == 1) return PathSegTok(PstGen{TRY(prism_rtl::from_pod<Nat>(c->args[0]))});
        if (c->ctor == "PstKey" && c->args.size() == 1) return PathSegTok(PstKey{TRY(prism_rtl::from_pod<Array<Tok>>(c->args[0]))});
    }
    return mismatch<PathSegTok>("a PathSegTok", p);
}


bool TPartTok::TptPlaceholder::operator==(const TptPlaceholder& o) const { return a0 == o.a0 && a1 == o.a1 && a2 == o.a2; }

bool TPartTok::TptBlock::operator==(const TptBlock& o) const { return a0 == o.a0 && a1 == o.a1; }

bool TPartTok::TptCall::operator==(const TptCall& o) const { return a0 == o.a0 && a1 == o.a1 && a2 == o.a2 && a3 == o.a3; }

void TPartTok::show(Printer& p) const {
    if (auto c = std::get_if<TptText>(&cases())) p.choice("TptText", {c->a0});
    else if (auto c = std::get_if<TptPlaceholder>(&cases())) p.choice("TptPlaceholder", {c->a0, c->a1, c->a2});
    else if (auto c = std::get_if<TptBlock>(&cases())) p.choice("TptBlock", {c->a0, c->a1});
    else if (auto c = std::get_if<TptCall>(&cases())) p.choice("TptCall", {c->a0, c->a1, c->a2, c->a3});
}

Pod TPartTok::to_pod() const {
    return std::holds_alternative<TptText>(cases()) ? Pod::choice("TptText", {prism_rtl::to_pod(std::get<TptText>(cases()).a0)})
        : std::holds_alternative<TptPlaceholder>(cases()) ? Pod::choice("TptPlaceholder", {prism_rtl::to_pod(std::get<TptPlaceholder>(cases()).a0), prism_rtl::to_pod(std::get<TptPlaceholder>(cases()).a1), prism_rtl::to_pod(std::get<TptPlaceholder>(cases()).a2)})
        : std::holds_alternative<TptBlock>(cases()) ? Pod::choice("TptBlock", {prism_rtl::to_pod(std::get<TptBlock>(cases()).a0), prism_rtl::to_pod(std::get<TptBlock>(cases()).a1)})
        : std::holds_alternative<TptCall>(cases()) ? Pod::choice("TptCall", {prism_rtl::to_pod(std::get<TptCall>(cases()).a0), prism_rtl::to_pod(std::get<TptCall>(cases()).a1), prism_rtl::to_pod(std::get<TptCall>(cases()).a2), prism_rtl::to_pod(std::get<TptCall>(cases()).a3)})
        : Pod();
}

Result<TPartTok> TPartTok::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "TptText" && c->args.size() == 1) return TPartTok(TptText{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "TptPlaceholder" && c->args.size() == 3) return TPartTok(TptPlaceholder{TRY(prism_rtl::from_pod<Array<Tok>>(c->args[0])), TRY(prism_rtl::from_pod<std::optional<Nat>>(c->args[1])), TRY(prism_rtl::from_pod<crate::syntax::Range>(c->args[2]))});
        if (c->ctor == "TptBlock" && c->args.size() == 2) return TPartTok(TptBlock{TRY(prism_rtl::from_pod<Array<Tok>>(c->args[0])), TRY(prism_rtl::from_pod<crate::syntax::Range>(c->args[1]))});
        if (c->ctor == "TptCall" && c->args.size() == 4) return TPartTok(TptCall{TRY(prism_rtl::from_pod<NameTok>(c->args[0])), TRY(prism_rtl::from_pod<Array<AttrTok>>(c->args[1])), TRY(prism_rtl::from_pod<std::optional<Array<TPartTok>>>(c->args[2])), TRY(prism_rtl::from_pod<crate::syntax::Range>(c->args[3]))});
    }
    return mismatch<TPartTok>("a TPartTok", p);
}


bool TemplateTok::operator==(const TemplateTok& o) const { return keyword_p == o.keyword_p && lang_p == o.lang_p && delims_p == o.delims_p && parts_p == o.parts_p; }

void TemplateTok::show(Printer& p) const {
    p.record("TemplateTok", {{"keyword", keyword_p}, {"lang", lang_p}, {"delims", delims_p}, {"parts", parts_p}});
}

Pod TemplateTok::to_pod() const {
    return Pod::record("TemplateTok", {{"keyword", prism_rtl::to_pod(keyword_p)}, {"lang", prism_rtl::to_pod(lang_p)}, {"delims", prism_rtl::to_pod(delims_p)}, {"parts", prism_rtl::to_pod(parts_p)}});
}

Result<TemplateTok> TemplateTok::from_pod(const Pod& whole) {
    return TemplateTok{.keyword_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "keyword")))), .lang_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "lang")))), .delims_p = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "delims")))), .parts_p = TRY(prism_rtl::from_pod<Array<TPartTok>>(TRY(crate::prelude::field(whole, "parts"))))};
}


bool TextSegTok::TsPlaceholder::operator==(const TsPlaceholder& o) const { return a0 == o.a0 && a1 == o.a1; }

void TextSegTok::show(Printer& p) const {
    if (auto c = std::get_if<TsPlain>(&cases())) p.choice("TsPlain", {c->a0});
    else if (auto c = std::get_if<TsPlaceholder>(&cases())) p.choice("TsPlaceholder", {c->a0, c->a1});
}

Pod TextSegTok::to_pod() const {
    return std::holds_alternative<TsPlain>(cases()) ? Pod::choice("TsPlain", {prism_rtl::to_pod(std::get<TsPlain>(cases()).a0)})
        : std::holds_alternative<TsPlaceholder>(cases()) ? Pod::choice("TsPlaceholder", {prism_rtl::to_pod(std::get<TsPlaceholder>(cases()).a0), prism_rtl::to_pod(std::get<TsPlaceholder>(cases()).a1)})
        : Pod();
}

Result<TextSegTok> TextSegTok::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "TsPlain" && c->args.size() == 1) return TextSegTok(TsPlain{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "TsPlaceholder" && c->args.size() == 2) return TextSegTok(TsPlaceholder{TRY(prism_rtl::from_pod<Array<Tok>>(c->args[0])), TRY(prism_rtl::from_pod<crate::syntax::Range>(c->args[1]))});
    }
    return mismatch<TextSegTok>("a TextSegTok", p);
}


void Tok::show(Printer& p) const {
    p.record("Tok", {{"kind", kind_p}, {"span", span_p}, {"touches", touches_p}, {"lineStart", line_start_p}});
}

Pod Tok::to_pod() const {
    return Pod::record("Tok", {{"kind", prism_rtl::to_pod(kind_p)}, {"span", prism_rtl::to_pod(span_p)}, {"touches", prism_rtl::to_pod(touches_p)}, {"lineStart", prism_rtl::to_pod(line_start_p)}});
}

Result<Tok> Tok::from_pod(const Pod& whole) {
    return Tok{.kind_p = TRY(prism_rtl::from_pod<TokKind>(TRY(crate::prelude::field(whole, "kind")))), .span_p = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span")))), .touches_p = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "touches")))), .line_start_p = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "lineStart"))))};
}


bool TokKind::KText::operator==(const KText& o) const { return a0 == o.a0 && a1 == o.a1; }

bool TokKind::KPath::operator==(const KPath& o) const { return a0 == o.a0; }

void TokKind::show(Printer& p) const {
    if (auto c = std::get_if<KName>(&cases())) p.choice("KName", {c->a0});
    else if (auto c = std::get_if<KFamily>(&cases())) p.choice("KFamily", {c->a0});
    else if (auto c = std::get_if<KTrait>(&cases())) p.choice("KTrait", {c->a0});
    else if (auto c = std::get_if<KKw>(&cases())) p.choice("KKw", {c->a0, c->a1});
    else if (auto c = std::get_if<KFree>(&cases())) p.choice("KFree", {c->a0});
    else if (auto c = std::get_if<KLensDot>(&cases())) p.choice("KLensDot", {});
    else if (auto c = std::get_if<KInt>(&cases())) p.choice("KInt", {c->a0, c->a1});
    else if (auto c = std::get_if<KFloat>(&cases())) p.choice("KFloat", {c->a0, c->a1});
    else if (auto c = std::get_if<KDuration>(&cases())) p.choice("KDuration", {c->a0, c->a1, c->a2});
    else if (auto c = std::get_if<KChar>(&cases())) p.choice("KChar", {c->a0, c->a1});
    else if (auto c = std::get_if<KText>(&cases())) p.choice("KText", {c->a0, c->a1});
    else if (auto c = std::get_if<KRegex>(&cases())) p.choice("KRegex", {c->a0, c->a1});
    else if (auto c = std::get_if<KTemplate>(&cases())) p.choice("KTemplate", {c->a0});
    else if (auto c = std::get_if<KOp>(&cases())) p.choice("KOp", {c->a0, c->a1});
    else if (auto c = std::get_if<KSuffixed>(&cases())) p.choice("KSuffixed", {c->a0, c->a1});
    else if (auto c = std::get_if<KDot>(&cases())) p.choice("KDot", {c->a0});
    else if (auto c = std::get_if<KDotDot>(&cases())) p.choice("KDotDot", {});
    else if (auto c = std::get_if<KComma>(&cases())) p.choice("KComma", {});
    else if (auto c = std::get_if<KColon>(&cases())) p.choice("KColon", {});
    else if (auto c = std::get_if<KSemi>(&cases())) p.choice("KSemi", {});
    else if (auto c = std::get_if<KBackslash>(&cases())) p.choice("KBackslash", {});
    else if (auto c = std::get_if<KLambdaBar>(&cases())) p.choice("KLambdaBar", {c->a0});
    else if (auto c = std::get_if<KBar>(&cases())) p.choice("KBar", {});
    else if (auto c = std::get_if<KLtLt>(&cases())) p.choice("KLtLt", {});
    else if (auto c = std::get_if<KGtGt>(&cases())) p.choice("KGtGt", {});
    else if (auto c = std::get_if<KOpen>(&cases())) p.choice("KOpen", {c->a0, c->a1});
    else if (auto c = std::get_if<KClose>(&cases())) p.choice("KClose", {c->a0});
    else if (auto c = std::get_if<KAbsent>(&cases())) p.choice("KAbsent", {});
    else if (auto c = std::get_if<KNonEmpty>(&cases())) p.choice("KNonEmpty", {});
    else if (auto c = std::get_if<KPath>(&cases())) p.choice("KPath", {c->a0});
    else if (auto c = std::get_if<KLayOpen>(&cases())) p.choice("KLayOpen", {});
    else if (auto c = std::get_if<KLaySep>(&cases())) p.choice("KLaySep", {});
    else if (auto c = std::get_if<KLayClose>(&cases())) p.choice("KLayClose", {});
    else if (auto c = std::get_if<KEof>(&cases())) p.choice("KEof", {});
}

Pod TokKind::to_pod() const {
    return std::holds_alternative<KName>(cases()) ? Pod::choice("KName", {prism_rtl::to_pod(std::get<KName>(cases()).a0)})
        : std::holds_alternative<KFamily>(cases()) ? Pod::choice("KFamily", {prism_rtl::to_pod(std::get<KFamily>(cases()).a0)})
        : std::holds_alternative<KTrait>(cases()) ? Pod::choice("KTrait", {prism_rtl::to_pod(std::get<KTrait>(cases()).a0)})
        : std::holds_alternative<KKw>(cases()) ? Pod::choice("KKw", {prism_rtl::to_pod(std::get<KKw>(cases()).a0), prism_rtl::to_pod(std::get<KKw>(cases()).a1)})
        : std::holds_alternative<KFree>(cases()) ? Pod::choice("KFree", {prism_rtl::to_pod(std::get<KFree>(cases()).a0)})
        : std::holds_alternative<KLensDot>(cases()) ? Pod::choice("KLensDot", {})
        : std::holds_alternative<KInt>(cases()) ? Pod::choice("KInt", {prism_rtl::to_pod(std::get<KInt>(cases()).a0), prism_rtl::to_pod(std::get<KInt>(cases()).a1)})
        : std::holds_alternative<KFloat>(cases()) ? Pod::choice("KFloat", {prism_rtl::to_pod(std::get<KFloat>(cases()).a0), prism_rtl::to_pod(std::get<KFloat>(cases()).a1)})
        : std::holds_alternative<KDuration>(cases()) ? Pod::choice("KDuration", {prism_rtl::to_pod(std::get<KDuration>(cases()).a0), prism_rtl::to_pod(std::get<KDuration>(cases()).a1), prism_rtl::to_pod(std::get<KDuration>(cases()).a2)})
        : std::holds_alternative<KChar>(cases()) ? Pod::choice("KChar", {prism_rtl::to_pod(std::get<KChar>(cases()).a0), prism_rtl::to_pod(std::get<KChar>(cases()).a1)})
        : std::holds_alternative<KText>(cases()) ? Pod::choice("KText", {prism_rtl::to_pod(std::get<KText>(cases()).a0), prism_rtl::to_pod(std::get<KText>(cases()).a1)})
        : std::holds_alternative<KRegex>(cases()) ? Pod::choice("KRegex", {prism_rtl::to_pod(std::get<KRegex>(cases()).a0), prism_rtl::to_pod(std::get<KRegex>(cases()).a1)})
        : std::holds_alternative<KTemplate>(cases()) ? Pod::choice("KTemplate", {prism_rtl::to_pod(std::get<KTemplate>(cases()).a0)})
        : std::holds_alternative<KOp>(cases()) ? Pod::choice("KOp", {prism_rtl::to_pod(std::get<KOp>(cases()).a0), prism_rtl::to_pod(std::get<KOp>(cases()).a1)})
        : std::holds_alternative<KSuffixed>(cases()) ? Pod::choice("KSuffixed", {prism_rtl::to_pod(std::get<KSuffixed>(cases()).a0), prism_rtl::to_pod(std::get<KSuffixed>(cases()).a1)})
        : std::holds_alternative<KDot>(cases()) ? Pod::choice("KDot", {prism_rtl::to_pod(std::get<KDot>(cases()).a0)})
        : std::holds_alternative<KDotDot>(cases()) ? Pod::choice("KDotDot", {})
        : std::holds_alternative<KComma>(cases()) ? Pod::choice("KComma", {})
        : std::holds_alternative<KColon>(cases()) ? Pod::choice("KColon", {})
        : std::holds_alternative<KSemi>(cases()) ? Pod::choice("KSemi", {})
        : std::holds_alternative<KBackslash>(cases()) ? Pod::choice("KBackslash", {})
        : std::holds_alternative<KLambdaBar>(cases()) ? Pod::choice("KLambdaBar", {prism_rtl::to_pod(std::get<KLambdaBar>(cases()).a0)})
        : std::holds_alternative<KBar>(cases()) ? Pod::choice("KBar", {})
        : std::holds_alternative<KLtLt>(cases()) ? Pod::choice("KLtLt", {})
        : std::holds_alternative<KGtGt>(cases()) ? Pod::choice("KGtGt", {})
        : std::holds_alternative<KOpen>(cases()) ? Pod::choice("KOpen", {prism_rtl::to_pod(std::get<KOpen>(cases()).a0), prism_rtl::to_pod(std::get<KOpen>(cases()).a1)})
        : std::holds_alternative<KClose>(cases()) ? Pod::choice("KClose", {prism_rtl::to_pod(std::get<KClose>(cases()).a0)})
        : std::holds_alternative<KAbsent>(cases()) ? Pod::choice("KAbsent", {})
        : std::holds_alternative<KNonEmpty>(cases()) ? Pod::choice("KNonEmpty", {})
        : std::holds_alternative<KPath>(cases()) ? Pod::choice("KPath", {prism_rtl::to_pod(std::get<KPath>(cases()).a0)})
        : std::holds_alternative<KLayOpen>(cases()) ? Pod::choice("KLayOpen", {})
        : std::holds_alternative<KLaySep>(cases()) ? Pod::choice("KLaySep", {})
        : std::holds_alternative<KLayClose>(cases()) ? Pod::choice("KLayClose", {})
        : std::holds_alternative<KEof>(cases()) ? Pod::choice("KEof", {})
        : Pod();
}

Result<TokKind> TokKind::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "KName" && c->args.size() == 1) return TokKind(KName{TRY(prism_rtl::from_pod<NameTok>(c->args[0]))});
        if (c->ctor == "KFamily" && c->args.size() == 1) return TokKind(KFamily{TRY(prism_rtl::from_pod<Array<Text>>(c->args[0]))});
        if (c->ctor == "KTrait" && c->args.size() == 1) return TokKind(KTrait{TRY(prism_rtl::from_pod<Array<Text>>(c->args[0]))});
        if (c->ctor == "KKw" && c->args.size() == 2) return TokKind(KKw{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Text>(c->args[1]))});
        if (c->ctor == "KFree" && c->args.size() == 1) return TokKind(KFree{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "KLensDot" && c->args.size() == 0) return TokKind(KLensDot{});
        if (c->ctor == "KInt" && c->args.size() == 2) return TokKind(KInt{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Text>(c->args[1]))});
        if (c->ctor == "KFloat" && c->args.size() == 2) return TokKind(KFloat{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Text>(c->args[1]))});
        if (c->ctor == "KDuration" && c->args.size() == 3) return TokKind(KDuration{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Text>(c->args[1])), TRY(prism_rtl::from_pod<Text>(c->args[2]))});
        if (c->ctor == "KChar" && c->args.size() == 2) return TokKind(KChar{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Text>(c->args[1]))});
        if (c->ctor == "KText" && c->args.size() == 2) return TokKind(KText{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Array<TextSegTok>>(c->args[1]))});
        if (c->ctor == "KRegex" && c->args.size() == 2) return TokKind(KRegex{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<crate::syntax::RegexLit>(c->args[1]))});
        if (c->ctor == "KTemplate" && c->args.size() == 1) return TokKind(KTemplate{TRY(prism_rtl::from_pod<TemplateTok>(c->args[0]))});
        if (c->ctor == "KOp" && c->args.size() == 2) return TokKind(KOp{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<bool>(c->args[1]))});
        if (c->ctor == "KSuffixed" && c->args.size() == 2) return TokKind(KSuffixed{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Array<Text>>(c->args[1]))});
        if (c->ctor == "KDot" && c->args.size() == 1) return TokKind(KDot{TRY(prism_rtl::from_pod<bool>(c->args[0]))});
        if (c->ctor == "KDotDot" && c->args.size() == 0) return TokKind(KDotDot{});
        if (c->ctor == "KComma" && c->args.size() == 0) return TokKind(KComma{});
        if (c->ctor == "KColon" && c->args.size() == 0) return TokKind(KColon{});
        if (c->ctor == "KSemi" && c->args.size() == 0) return TokKind(KSemi{});
        if (c->ctor == "KBackslash" && c->args.size() == 0) return TokKind(KBackslash{});
        if (c->ctor == "KLambdaBar" && c->args.size() == 1) return TokKind(KLambdaBar{TRY(prism_rtl::from_pod<bool>(c->args[0]))});
        if (c->ctor == "KBar" && c->args.size() == 0) return TokKind(KBar{});
        if (c->ctor == "KLtLt" && c->args.size() == 0) return TokKind(KLtLt{});
        if (c->ctor == "KGtGt" && c->args.size() == 0) return TokKind(KGtGt{});
        if (c->ctor == "KOpen" && c->args.size() == 2) return TokKind(KOpen{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<bool>(c->args[1]))});
        if (c->ctor == "KClose" && c->args.size() == 1) return TokKind(KClose{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "KAbsent" && c->args.size() == 0) return TokKind(KAbsent{});
        if (c->ctor == "KNonEmpty" && c->args.size() == 0) return TokKind(KNonEmpty{});
        if (c->ctor == "KPath" && c->args.size() == 1) return TokKind(KPath{TRY(prism_rtl::from_pod<Array<PathSegTok>>(c->args[0]))});
        if (c->ctor == "KLayOpen" && c->args.size() == 0) return TokKind(KLayOpen{});
        if (c->ctor == "KLaySep" && c->args.size() == 0) return TokKind(KLaySep{});
        if (c->ctor == "KLayClose" && c->args.size() == 0) return TokKind(KLayClose{});
        if (c->ctor == "KEof" && c->args.size() == 0) return TokKind(KEof{});
    }
    return mismatch<TokKind>("a TokKind", p);
}


/// Fresh: fn Lex, Mode -> Lex
Lex fresh_f(const Lex& l_p0, const Mode& mode_p1) {
    return Lex{.src_p = l_p0.src_p, .pos_p = l_p0.pos_p, .diags_p = l_p0.diags_p, .mode_p = mode_p1, .tokens_p = Array<Tok>{}, .layout_p = Array<Nat>{}, .frames_p = Array<Text>{}, .last_ws_p = true, .lambda_open_p = false, .pending_open_p = false, .pending_span_p = crate::syntax::Range{.start_p = Nat(0u), .end_p = Nat(0u)}, .line_first_p = Nat(0u), .mark_line_start_p = false, .first_line_p = true, .test_pending_p = Text::lit(""), .test_depth_o = std::optional<Nat>{}, .check_depth_o = std::optional<Nat>{}, .path_next_p = false};
}


/// IsLayoutOrEof: fn TokKind -> Bool
bool is_layout_or_eof_f(const TokKind& tok_kind0) {
    if (prism_rtl::is<TokKind::KLayOpen>(tok_kind0)) {
        return true;
    }
    if (prism_rtl::is<TokKind::KLaySep>(tok_kind0)) {
        return true;
    }
    if (prism_rtl::is<TokKind::KLayClose>(tok_kind0)) {
        return true;
    }
    if (prism_rtl::is<TokKind::KEof>(tok_kind0)) {
        return true;
    }
    {
        return false;
    }
}


/// IsLayout: fn TokKind -> Bool
bool is_layout_f(const TokKind& tok_kind0) {
    if (prism_rtl::is<TokKind::KLayOpen>(tok_kind0)) {
        return true;
    }
    if (prism_rtl::is<TokKind::KLaySep>(tok_kind0)) {
        return true;
    }
    if (prism_rtl::is<TokKind::KLayClose>(tok_kind0)) {
        return true;
    }
    {
        return false;
    }
}


/// EndsOperand: fn TokKind -> Bool
bool ends_operand_f(const TokKind& tok_kind0) {
    if (prism_rtl::is<TokKind::KName>(tok_kind0)) {
        return true;
    }
    if (prism_rtl::is<TokKind::KFamily>(tok_kind0)) {
        return true;
    }
    if (prism_rtl::is<TokKind::KInt>(tok_kind0)) {
        return true;
    }
    if (prism_rtl::is<TokKind::KFloat>(tok_kind0)) {
        return true;
    }
    if (prism_rtl::is<TokKind::KDuration>(tok_kind0)) {
        return true;
    }
    if (prism_rtl::is<TokKind::KChar>(tok_kind0)) {
        return true;
    }
    if (prism_rtl::is<TokKind::KText>(tok_kind0)) {
        return true;
    }
    if (prism_rtl::is<TokKind::KRegex>(tok_kind0)) {
        return true;
    }
    if (prism_rtl::is<TokKind::KTemplate>(tok_kind0)) {
        return true;
    }
    if (prism_rtl::is<TokKind::KClose>(tok_kind0)) {
        return true;
    }
    if (prism_rtl::is<TokKind::KGtGt>(tok_kind0)) {
        return true;
    }
    if (prism_rtl::is<TokKind::KNonEmpty>(tok_kind0)) {
        return true;
    }
    if (prism_rtl::is<TokKind::KAbsent>(tok_kind0)) {
        return true;
    }
    if (prism_rtl::is<TokKind::KKw>(tok_kind0)) {
        auto&& w_p0 = prism_rtl::as<TokKind::KKw>(tok_kind0).a0;
        return is_value_word_f(w_p0);
    }
    {
        return false;
    }
}


/// IsValueWord: fn Text -> Bool
bool is_value_word_f(const Text& w_p0) {
    return ((w_p0 == Text::lit("unit")) || (w_p0 == Text::lit("nil"))) || is_bound_word_f(w_p0);
}


/// IsBoundWord: fn Text -> Bool
bool is_bound_word_f(const Text& w_p0) {
    return (((w_p0 == Text::lit("key")) || (w_p0 == Text::lit("ix"))) || (w_p0 == Text::lit("jx"))) || (w_p0 == Text::lit("kx"));
}


/// let keywordList
Array<Text> keyword_list_p() {
    return Array(std::vector{Text::lit("module"), Text::lit("emit"), Text::lit("use"), Text::lit("type"), Text::lit("record"), Text::lit("choice"), Text::lit("row"), Text::lit("tag"), Text::lit("of"), Text::lit("derive"), Text::lit("trait"), Text::lit("impl"), Text::lit("where"), Text::lit("any"), Text::lit("let"), Text::lit("fn"), Text::lit("test"), Text::lit("check"), Text::lit("widget"), Text::lit("rebuild"), Text::lit("for"), Text::lit("given"), Text::lit("monad"), Text::lit("update"), Text::lit("while"), Text::lit("match"), Text::lit("if"), Text::lit("else"), Text::lit("otherwise"), Text::lit("require"), Text::lit("forbid"), Text::lit("return"), Text::lit("ignore"), Text::lit("then"), Text::lit("on"), Text::lit("not"), Text::lit("and"), Text::lit("or"), Text::lit("mod"), Text::lit("as"), Text::lit("output"), Text::lit("inline_text"), Text::lit("raw"), Text::lit("unbounded"), Text::lit("unit"), Text::lit("nil"), Text::lit("key"), Text::lit("ix"), Text::lit("jx"), Text::lit("kx")});
}


/// let keywordSet
Map<Text, bool> keyword_set_p() {
    return crate::prelude::map(crate::prelude::each(keyword_list_p(), [&](const Text& w_p0) { return std::tuple{w_p0, true}; }));
}


/// IsKeyword: fn Text -> Bool
bool is_keyword_f(const Text& w_p0) {
    return crate::prelude::get(keyword_set_p(), w_p0) != std::optional<bool>{};
}


/// TakesSuffix: fn Text -> Bool
bool takes_suffix_f(const Text& op_p0) {
    return crate::prelude::fold(Array(std::vector{Text::lit("<="), Text::lit("=="), Text::lit("!="), Text::lit("<"), Text::lit(">"), Text::lit(">="), Text::lit("+"), Text::lit("-"), Text::lit("*"), Text::lit("/"), Text::lit("+?"), Text::lit("-?"), Text::lit("*?")}), false, [&](const bool& seen_p1, const Text& o_p2) { return prism_rtl::deref(seen_p1) || (o_p2 == op_p0); });
}


/// CloseChar: fn Text -> Text
Text close_char_f(const Text& text0) {
    {
        auto&& c0_0 = text0;
        if (c0_0 == Text::lit("(")) {
            return Text::lit(")");
        }
    }
    {
        auto&& c1_0 = text0;
        if (c1_0 == Text::lit("[")) {
            return Text::lit("]");
        }
    }
    {
        return Text::lit("}");
    }
}


/// OpenOf: fn Text -> Text
Text open_of_f(const Text& text0) {
    {
        auto&& c0_0 = text0;
        if (c0_0 == Text::lit(")")) {
            return Text::lit("(");
        }
    }
    {
        auto&& c1_0 = text0;
        if (c1_0 == Text::lit("]")) {
            return Text::lit("[");
        }
    }
    {
        return Text::lit("{");
    }
}


/// PrefixPosition: fn Lex -> Bool
bool prefix_position_f(const Lex& l_p0) {
    return l_p0.last_ws_p || no_operand_before_f(crate::syntax::lexer::chars::last_o(l_p0.tokens_p));
}


/// NoOperandBefore: fn ?Tok -> Bool
bool no_operand_before_f(const std::optional<Tok>& opt0) {
    if (prism_rtl::is_none(opt0)) {
        return true;
    }
    if (prism_rtl::is_some(opt0)) {
        auto&& t_p0 = prism_rtl::some_of(opt0);
        return !ends_operand_f(prism_rtl::deref(t_p0).kind_p);
    }
    prism_rtl::unreachable("no arm matched");
}


/// TestWordOf: fn TokKind -> Text
Text test_word_of_f(const TokKind& tok_kind0) {
    if (prism_rtl::is<TokKind::KKw>(tok_kind0)) {
        auto&& c0_0_0 = prism_rtl::as<TokKind::KKw>(tok_kind0).a0;
        if (c0_0_0 == Text::lit("test")) {
            return Text::lit("test");
        }
    }
    if (prism_rtl::is<TokKind::KKw>(tok_kind0)) {
        auto&& c1_0_0 = prism_rtl::as<TokKind::KKw>(tok_kind0).a0;
        if (c1_0_0 == Text::lit("check")) {
            return Text::lit("check");
        }
    }
    {
        return Text::lit("");
    }
}


/// AllLayout: fn [Tok] -> Bool
bool all_layout_f(const Array<Tok>& ts_p0) {
    return crate::prelude::fold(ts_p0, true, [&](const bool& ok_p1, const Tok& t_p2) { return prism_rtl::deref(ok_p1) && is_layout_f(prism_rtl::deref(t_p2).kind_p); });
}


/// PushTok: fn Lex, TokKind, Nat, Nat -> Lex
Lex push_tok_f(const Lex& l_p0, const TokKind& kind_p1, const Nat& start_p2, const Nat& end_p3) {
    Lex this_ = l_p0;
    auto layout_p4 = is_layout_or_eof_f(kind_p1);
    auto touches_p5 = ((!this_.last_ws_p) && (crate::prelude::len(this_.tokens_p) > Nat(0u))) && (!std::move(layout_p4));
    auto line_start_p6 = (!std::move(layout_p4)) && this_.mark_line_start_p;
    if (!std::move(layout_p4)) {
        this_.mark_line_start_p = false;
    }
    auto word_p7 = test_word_of_f(kind_p1);
    if ((((word_p7 != Text::lit("")) && (this_.mode_p == Mode(Mode::MFile{}))) && (crate::prelude::len(this_.layout_p) == Nat(1u))) && all_layout_f(crate::prelude::drop(this_.tokens_p, this_.line_first_p))) {
        this_.test_pending_p = word_p7;
    }
    this_.tokens_p = crate::prelude::push(this_.tokens_p, Tok{.kind_p = kind_p1, .span_p = crate::syntax::Range{.start_p = start_p2, .end_p = end_p3}, .touches_p = std::move(touches_p5), .line_start_p = std::move(line_start_p6)});
    this_.last_ws_p = false;
    return this_;
}


/// LayoutOn: fn Mode -> Bool
bool layout_on_f(const Mode& mode0) {
    if (prism_rtl::is<Mode::MFile>(mode0)) {
        return true;
    }
    if (prism_rtl::is<Mode::MBrace>(mode0)) {
        return true;
    }
    {
        return false;
    }
}


/// LayoutActive: fn Lex -> Bool
bool layout_active_f(const Lex& l_p0) {
    return layout_on_f(l_p0.mode_p) && (crate::prelude::len(l_p0.frames_p) == Nat(0u));
}


/// FatArrowOn: fn Lex -> Bool
bool fat_arrow_on_f(const Lex& l_p0) {
    return (l_p0.test_depth_o != std::optional<Nat>{}) || (l_p0.check_depth_o != std::optional<Nat>{});
}

}  // namespace crate::syntax::lexer


// The module `Syntax.Lexer.Chars`, from `target/bootstrap/cpp-src/prismc/syntax/lexer/chars.prism`.
namespace crate::syntax::lexer::chars {

/// Dec: fn Nat -> Nat
Nat dec_f(const Nat& n_p0) {
    return crate::prelude::or_(n_p0.checked_sub(Nat(1u)), Nat(0u));
}


/// Join: fn [Text], Text -> Text
Text join_f(const Array<Text>& xs_p0, const Text& sep_p1) {
    auto&& _m = crate::prelude::index(xs_p0, Nat(0u));
    if (prism_rtl::is_some(_m)) {
        auto&& first_p2 = prism_rtl::some_of(_m);
        return crate::prelude::concat(crate::prelude::fold(crate::prelude::drop(xs_p0, Nat(1u)), Array(std::vector{first_p2}), [&](const Array<Text>& acc_p3, const Text& x_p4) { return crate::prelude::push(crate::prelude::push(acc_p3, sep_p1), x_p4); }));
    }
    if (prism_rtl::is_none(_m)) {
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}


/// CharAt: fn Cursor -> Text
Text char_at_f(const Cursor& c_p0) {
    auto&& _m = crate::prelude::step(crate::prelude::front(crate::prelude::after(c_p0)));
    if (prism_rtl::is_some(_m)) {
        auto&& one_p1 = std::get<1>(prism_rtl::some_of(_m));
        return crate::prelude::before(one_p1);
    }
    if (prism_rtl::is_none(_m)) {
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}


/// Head: fn Text -> Text
Text head_f(const Text& t_p0) {
    return char_at_f(crate::prelude::front(t_p0));
}


/// AfterFirst: fn Text -> Text
Text after_first_f(const Text& t_p0) {
    auto&& _m = crate::prelude::step(crate::prelude::front(t_p0));
    if (prism_rtl::is_some(_m)) {
        auto&& c_p1 = std::get<1>(prism_rtl::some_of(_m));
        return crate::prelude::after(c_p1);
    }
    if (prism_rtl::is_none(_m)) {
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}


/// LastChar: fn Text -> Text
Text last_char_f(const Text& t_p0) {
    auto&& _m = crate::prelude::step_back(crate::prelude::back(t_p0));
    if (prism_rtl::is_some(_m)) {
        auto&& c_p1 = std::get<1>(prism_rtl::some_of(_m));
        return crate::prelude::after(c_p1);
    }
    if (prism_rtl::is_none(_m)) {
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}


/// BeforeLast: fn Text -> Text
Text before_last_f(const Text& t_p0) {
    auto&& _m = crate::prelude::step_back(crate::prelude::back(t_p0));
    if (prism_rtl::is_some(_m)) {
        auto&& c_p1 = std::get<1>(prism_rtl::some_of(_m));
        return crate::prelude::before(c_p1);
    }
    if (prism_rtl::is_none(_m)) {
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}


/// Between: fn Text, Nat, Nat -> Text
Text between_f(const Text& t_p0, const Nat& a_p1, const Nat& b_p2) {
    auto&& _m = crate::prelude::cursor_at(t_p0, b_p2);
    if (prism_rtl::is_some(_m)) {
        auto&& cb_p3 = prism_rtl::some_of(_m);
        auto&& _m = crate::prelude::cursor_at(crate::prelude::before(cb_p3), a_p1);
        if (prism_rtl::is_some(_m)) {
            auto&& ca_p4 = prism_rtl::some_of(_m);
            return crate::prelude::after(ca_p4);
        }
        if (prism_rtl::is_none(_m)) {
            return Text::lit("");
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is_none(_m)) {
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}


/// ?AfterPrefix: fn Text, Text -> ?Text
std::optional<Text> after_prefix_o(const Text& t_p0, const Text& p_p1) {
    auto&& _m = crate::prelude::cursor_at(t_p0, crate::prelude::len_text(p_p1));
    if (prism_rtl::is_some(_m)) {
        auto&& c_p2 = prism_rtl::some_of(_m);
        return crate::prelude::before(c_p2) == p_p1
            ? std::optional(crate::prelude::after(c_p2))
            : std::optional<Text>{};
    }
    if (prism_rtl::is_none(_m)) {
        return std::optional<Text>{};
    }
    prism_rtl::unreachable("no arm matched");
}


/// HasPrefix: fn Text, Text -> Bool
bool has_prefix_f(const Text& t_p0, const Text& p_p1) {
    return after_prefix_o(t_p0, p_p1) != std::optional<Text>{};
}


/// DropPrefix: fn Text, Text -> Text
Text drop_prefix_f(const Text& t_p0, const Text& p_p1) {
    return crate::prelude::or_(after_prefix_o(t_p0, p_p1), t_p0);
}


/// ?BeforeSuffix: fn Text, Text -> ?Text
std::optional<Text> before_suffix_o(const Text& t_p0, const Text& s_p1) {
    auto&& _m = crate::prelude::len_text(t_p0).checked_sub(crate::prelude::len_text(s_p1));
    if (prism_rtl::is_some(_m)) {
        auto&& n_p2 = prism_rtl::some_of(_m);
        auto&& _m = crate::prelude::cursor_at(t_p0, n_p2);
        if (prism_rtl::is_some(_m)) {
            auto&& c_p3 = prism_rtl::some_of(_m);
            return crate::prelude::after(c_p3) == s_p1
                ? std::optional(crate::prelude::before(c_p3))
                : std::optional<Text>{};
        }
        if (prism_rtl::is_none(_m)) {
            return std::optional<Text>{};
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is_none(_m)) {
        return std::optional<Text>{};
    }
    prism_rtl::unreachable("no arm matched");
}


/// HasSuffix: fn Text, Text -> Bool
bool has_suffix_f(const Text& t_p0, const Text& s_p1) {
    return before_suffix_o(t_p0, s_p1) != std::optional<Text>{};
}


/// MapChars: fn Text, (fn Text -> Text) -> Text
Text map_chars_f(const Text& t_p0, const prism_rtl::Fn<prism_rtl::JobRef<Text>(Text)>& f_f1) {
    return crate::prelude::concat(fold_chars_f(t_p0, Array<Text>{}, ({
        auto f_f1x = f_f1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Text>)>>(prism_rtl::rc([=, f_f1x = std::move(f_f1x)](std::tuple<Array<Text>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto f_f1xy = f_f1x;
            (crate::prelude::entered(crate::prelude::once_job([=, f_f1xy = std::move(f_f1xy)]() {
            return ({
                auto acc_p2 = p0;
                auto c_p3 = p1;
                (crate::prelude::call_value(f_f1xy(c_p3), [=, acc_p2 = std::move(acc_p2)](Text f_3224) { return prism_rtl::finished(crate::prelude::push(acc_p2, f_3224)); }));
            });
        })));
        });
    })));
    })));
}


/// CountChars: fn Text -> Nat
Nat count_chars_f(const Text& t_p0) {
    return fold_chars_f(t_p0, Nat(0u), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Nat>(std::tuple<Nat, Text>)>>(prism_rtl::rc([=](std::tuple<Nat, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::once_job([=]() {
            return ({
                auto n_p1 = p0;
                static_cast<void>(p1);
                (prism_rtl::finished(n_p1 + Nat(1u)));
            });
        });
    })));
}


/// ColumnOf: fn Text, Nat, Nat -> Nat
Nat column_of_f(const Text& text_p0, const Nat& from_p1, const Nat& offset_p2) {
    return count_chars_f(between_f(text_p0, from_p1, offset_p2));
}


/// AllChars: fn Text, (fn Text -> Bool) -> Bool
bool all_chars_f(const Text& t_p0, const prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>& p_f1) {
    return fold_chars_f(t_p0, true, ({
        auto p_f1x = p_f1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, Text>)>>(prism_rtl::rc([=, p_f1x = std::move(p_f1x)](std::tuple<bool, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto p_f1xy = p_f1x;
            (crate::prelude::entered(crate::prelude::once_job([=, p_f1xy = std::move(p_f1xy)]() {
            return ({
                auto ok_p2 = p0;
                auto c_p3 = p1;
                (prism_rtl::finished(std::move(ok_p2) && crate::prelude::run_to_end(p_f1xy(c_p3))));
            });
        })));
        });
    })));
    }));
}


/// TrimLeading: fn Text, Text -> Text
Text trim_leading_f(const Text& t_p0, const Text& set_p1) {
    auto c_p2 = ({
        Cursor this_ = crate::prelude::front(t_p0);
        while (true) {
            auto&& _m = crate::prelude::step(this_);
            if (!(prism_rtl::is_some(_m))) break;
            auto&& next_p3 = std::get<1>(prism_rtl::some_of(_m));
            if (!contains_f(set_p1, char_at_f(this_))) {
                break;
            }
            this_ = next_p3;
        }
        (std::move(this_));
    });
    return crate::prelude::after(c_p2);
}


/// TrimTrailing: fn Text, Text -> Text
Text trim_trailing_f(const Text& t_p0, const Text& set_p1) {
    auto c_p2 = ({
        Cursor this_ = crate::prelude::back(t_p0);
        Nat fuel_p3 = crate::prelude::len_text(t_p0);
        while (true) {
            auto&& _m = fuel_p3.checked_sub(Nat(1u));
            if (!(prism_rtl::is_some(_m))) break;
            auto&& left_p4 = prism_rtl::some_of(_m);
            fuel_p3 = left_p4;
            ({
                __label__ _done;
                prism_rtl::Slot<Unit> _v;
                auto&& _m = crate::prelude::step_back(this_);
                if (prism_rtl::is_some(_m)) {
                    auto&& prev_p5 = std::get<1>(prism_rtl::some_of(_m));
                    if (contains_f(set_p1, char_at_f(prev_p5))) {
                        _v.set(({
                            this_ = prev_p5;
                            Unit{};
                        }));
                        goto _done;
                    }
                }
                {
                    _v.set(({
                        fuel_p3 = Nat(0u);
                        Unit{};
                    }));
                    goto _done;
                }
            _done:
                _v.take();
            });
        }
        (std::move(this_));
    });
    return crate::prelude::before(c_p2);
}


/// TrimStart: fn Text -> Text
Text trim_start_f(const Text& t_p0) {
    return trim_leading_f(t_p0, Text::lit(" \r"));
}


/// TrimEnd: fn Text -> Text
Text trim_end_f(const Text& t_p0) {
    return trim_trailing_f(t_p0, Text::lit(" \r"));
}


/// Trim: fn Text -> Text
Text trim_f(const Text& t_p0) {
    return trim_end_f(trim_start_f(t_p0));
}


/// LeadingIn: fn Text, Text -> Nat
Nat leading_in_f(const Text& t_p0, const Text& set_p1) {
    return crate::prelude::or_(crate::prelude::len_text(t_p0).checked_sub(crate::prelude::len_text(trim_leading_f(t_p0, set_p1))), Nat(0u));
}


/// Contains: fn Text, Text -> Bool
bool contains_f(const Text& set_p0, const Text& c_p1) {
    return (c_p1 != Text::lit("")) && (crate::prelude::len(crate::prelude::split_on(set_p0, c_p1)) > Nat(1u));
}


/// IsDigit: fn Text -> Bool
bool is_digit_f(const Text& c_p0) {
    return (Text::lit("0") <= c_p0) && (c_p0 <= Text::lit("9"));
}


/// IsUpper: fn Text -> Bool
bool is_upper_f(const Text& c_p0) {
    return (Text::lit("A") <= c_p0) && (c_p0 <= Text::lit("Z"));
}


/// IsLower: fn Text -> Bool
bool is_lower_f(const Text& c_p0) {
    return (Text::lit("a") <= c_p0) && (c_p0 <= Text::lit("z"));
}


/// IsIdentStart: fn Text -> Bool
bool is_ident_start_f(const Text& c_p0) {
    return (is_lower_f(c_p0) || is_upper_f(c_p0)) || (c_p0 == Text::lit("_"));
}


/// IsIdentChar: fn Text -> Bool
bool is_ident_char_f(const Text& c_p0) {
    return is_ident_start_f(c_p0) || is_digit_f(c_p0);
}


/// IsHexDigit: fn Text -> Bool
bool is_hex_digit_f(const Text& c_p0) {
    return (is_digit_f(c_p0) || ((Text::lit("a") <= c_p0) && (c_p0 <= Text::lit("f")))) || ((Text::lit("A") <= c_p0) && (c_p0 <= Text::lit("F")));
}


/// IsNonAscii: fn Text -> Bool
bool is_non_ascii_f(const Text& c_p0) {
    return c_p0 > Text::lit("");
}


/// IsSigilChar: fn Text -> Bool
bool is_sigil_char_f(const Text& c_p0) {
    return contains_f(Text::lit("$!@?~&"), c_p0);
}


/// IsSpaceChar: fn Text -> Bool
bool is_space_char_f(const Text& c_p0) {
    return (((c_p0 == Text::lit(" ")) || (c_p0 == Text::lit("\n"))) || (c_p0 == Text::lit("\r"))) || (c_p0 == Text::lit("\t"));
}


/// IsReservedCtor: fn Text -> Bool
bool is_reserved_ctor_f(const Text& w_p0) {
    return (w_p0 == Text::lit("templatetext")) || (w_p0 == Text::lit("templateplaceholder"));
}


/// let asciiText
Text ascii_text_p() {
    return Text::lit("\000\t\n\r !\"#$%&\'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~"sv);
}


/// let hexDigits
Text hex_digits_p() {
    return Text::lit("0123456789abcdef");
}


/// CharAtByte: fn Text, Nat -> Text
Text char_at_byte_f(const Text& t_p0, const Nat& n_p1) {
    auto&& _m = crate::prelude::cursor_at(t_p0, n_p1);
    if (prism_rtl::is_some(_m)) {
        auto&& c_p2 = prism_rtl::some_of(_m);
        return char_at_f(c_p2);
    }
    if (prism_rtl::is_none(_m)) {
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}


/// HexValue: fn Text -> Nat
Nat hex_value_f(const Text& c_p0) {
    auto l_p1 = crate::prelude::lower(c_p0);
    return l_p1 == Text::lit("")
        ? Nat(16u)
        : crate::prelude::len_text(crate::prelude::or_(crate::prelude::index(crate::prelude::split_on(hex_digits_p(), l_p1), Nat(0u)), hex_digits_p()));
}


/// ?ParseHex: fn Text -> ?Nat
std::optional<Nat> parse_hex_o(const Text& t_p0) {
    return ({
        __label__ g7251;
        prism_rtl::Slot<std::optional<Nat>> g7251_v;
        {
            if (!((t_p0 != Text::lit("")) && all_chars_f(t_p0, ({
                auto f = prism_rtl::rc(is_hex_digit_f);
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>>(prism_rtl::rc([=, f = std::move(f)](Text a0) {
                return ({
                    auto fy = f;
                    (crate::prelude::once_job([=, fy = std::move(fy)]() { return prism_rtl::finished(fy(a0)); }));
                });
            })));
            })))) {
                { g7251_v.set(std::nullopt); goto g7251; }
            }
            g7251_v.set(std::optional(fold_chars_f(t_p0, Nat(0u), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Nat>(std::tuple<Nat, Text>)>>(prism_rtl::rc([=](std::tuple<Nat, Text> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return crate::prelude::once_job([=]() {
                    return ({
                        auto n_p1 = p0;
                        auto c_p2 = p1;
                        (prism_rtl::finished((n_p1 * Nat(16u)) + hex_value_f(c_p2)));
                    });
                });
            })))));
        }
    g7251:
        g7251_v.take();
    });
}


/// Rest: fn Lex -> Text
Text rest_f(const crate::syntax::lexer::Lex& l_p0) {
    auto&& _m = crate::prelude::cursor_at(l_p0.src_p, l_p0.pos_p);
    if (prism_rtl::is_some(_m)) {
        auto&& c_p1 = prism_rtl::some_of(_m);
        return crate::prelude::after(c_p1);
    }
    if (prism_rtl::is_none(_m)) {
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}


/// Peek: fn Lex -> Text
Text peek_f(const crate::syntax::lexer::Lex& l_p0) {
    return char_at_byte_f(l_p0.src_p, l_p0.pos_p);
}


/// PeekAt: fn Lex, Nat -> Text
Text peek_at_f(const crate::syntax::lexer::Lex& l_p0, const Nat& n_p1) {
    auto rest_p2 = ({
        Text this_ = rest_f(l_p0);
        Nat k_p3 = n_p1;
        while (true) {
            auto&& _m = k_p3.checked_sub(Nat(1u));
            if (!(prism_rtl::is_some(_m))) break;
            auto&& left_p4 = prism_rtl::some_of(_m);
            k_p3 = left_p4;
            this_ = after_first_f(this_);
        }
        (std::move(this_));
    });
    return head_f(rest_p2);
}


/// StartsWith: fn Lex, Text -> Bool
bool starts_with_f(const crate::syntax::lexer::Lex& l_p0, const Text& s_p1) {
    return has_prefix_f(rest_f(l_p0), s_p1);
}


/// Slice: fn Lex, Nat, Nat -> Text
Text slice_f(const crate::syntax::lexer::Lex& l_p0, const Nat& a_p1, const Nat& b_p2) {
    return between_f(l_p0.src_p, a_p1, b_p2);
}


/// Bump: fn Lex -> Lex
crate::syntax::lexer::Lex bump_f(const crate::syntax::lexer::Lex& l_p0) {
    crate::syntax::lexer::Lex this_ = l_p0;
    this_.pos_p = this_.pos_p + crate::prelude::len_text(peek_f(this_));
    return this_;
}


/// Forward: fn Lex, Nat -> Lex
crate::syntax::lexer::Lex forward_f(const crate::syntax::lexer::Lex& l_p0, const Nat& n_p1) {
    crate::syntax::lexer::Lex this_ = l_p0;
    Nat k_p2 = n_p1;
    while (true) {
        auto&& _m = k_p2.checked_sub(Nat(1u));
        if (!(prism_rtl::is_some(_m))) break;
        auto&& left_p3 = prism_rtl::some_of(_m);
        k_p2 = left_p3;
        this_.pos_p = this_.pos_p + crate::prelude::len_text(peek_f(this_));
    }
    return this_;
}


/// NextIsSpace: fn Lex, Nat -> Bool
bool next_is_space_f(const crate::syntax::lexer::Lex& l_p0, const Nat& n_p1) {
    auto c_p2 = peek_at_f(l_p0, n_p1);
    return (c_p2 == Text::lit("")) || is_space_char_f(c_p2);
}


/// MatchEnd: fn Regex, Text, Nat -> Nat
Nat match_end_f(const Regex& r_p0, const Text& src_p1, const Nat& at_p2) {
    auto&& _m = crate::prelude::cursor_at(src_p1, at_p2);
    if (prism_rtl::is_some(_m)) {
        auto&& c_p3 = prism_rtl::some_of(_m);
        auto&& _m = crate::prelude::match_(r_p0, c_p3);
        if (prism_rtl::is_some(_m)) {
            auto&& m_p4 = prism_rtl::some_of(_m);
            return crate::prelude::at(prism_rtl::deref(m_p4).back_p);
        }
        if (prism_rtl::is_none(_m)) {
            return at_p2;
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is_none(_m)) {
        return at_p2;
    }
    prism_rtl::unreachable("no arm matched");
}


/// MatchHere: fn Regex, Lex -> Text
Text match_here_f(const Regex& r_p0, const crate::syntax::lexer::Lex& l_p1) {
    return between_f(l_p1.src_p, l_p1.pos_p, match_end_f(r_p0, l_p1.src_p, l_p1.pos_p));
}


/// LineEnd: fn Lex -> Nat
Nat line_end_f(const crate::syntax::lexer::Lex& l_p0) {
    return match_end_f(([]() -> const Regex& { static const Regex r = Regex::lit("[^\\n]*", ""); return r; }()), l_p0.src_p, l_p0.pos_p);
}


/// RestOfLine: unbounded fn Lex -> Text
Text rest_of_line_f(const crate::syntax::lexer::Lex& l_p0) {
    return slice_f(l_p0, l_p0.pos_p, line_end_f(l_p0));
}


prism_rtl::Turn<Text> RestOfLine::cycle() const {
    const auto& l_p0 = this->l_p0;
    return prism_rtl::finished(slice_f(l_p0, prism_rtl::deref(l_p0).pos_p, line_end_f(l_p0)));
}


/// `Start RestOfLine, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_rest_of_line_f(crate::syntax::lexer::Lex l_p0) {
    return prism_rtl::make_rc<RestOfLine>(l_p0);
}


/// LexErr: fn Lex, Nat, Nat, Text -> Lex
crate::syntax::lexer::Lex lex_err_f(const crate::syntax::lexer::Lex& l_p0, const Nat& start_p1, const Nat& end_p2, const Text& message_p3) {
    crate::syntax::lexer::Lex this_ = l_p0;
    this_.diags_p = crate::prelude::push(this_.diags_p, lex_diag_f(crate::syntax::Range{.start_p = start_p1, .end_p = crate::prelude::max(end_p2, start_p1)}, message_p3));
    return this_;
}


/// LexDiag: fn Range, Text -> Diag
crate::syntax::Diag lex_diag_f(const crate::syntax::Range& span_p0, const Text& message_p1) {
    return crate::syntax::Diag{.stage_p = Text::lit("lex"), .span_p = span_p0, .message_p = message_p1, .feature_o = std::optional<Text>{}};
}

}  // namespace crate::syntax::lexer::chars


// The module `Syntax.Lexer.Corpus`, from `target/bootstrap/cpp-src/prismc/syntax/lexer/corpus.prism`.
namespace crate::syntax::lexer::corpus {

/// RenderTokens: fn [Tok] -> Text
Text render_tokens_f(const Array<crate::syntax::lexer::Tok>& tokens_p0) {
    auto&& _out_p4 = crate::prelude::fold(tokens_p0, std::tuple{Text::lit(""), std::optional<crate::syntax::lexer::Tok>{}}, [&](const std::tuple<Text, std::optional<crate::syntax::lexer::Tok>>& _p0, const crate::syntax::lexer::Tok& t_p3) {
        auto&& acc_p1 = std::get<0>(_p0);
        auto&& prev_o2 = std::get<1>(_p0);
        return render_step_f(acc_p1, prev_o2, t_p3);
    });
    auto&& out_p4 = std::get<0>(_out_p4);
    return prism_rtl::cat(out_p4, "\n");
}


/// RenderStep: fn Text, ?Tok, Tok -> ((Text, ?Tok))
std::tuple<Text, std::optional<crate::syntax::lexer::Tok>> render_step_f(const Text& acc_p0, const std::optional<crate::syntax::lexer::Tok>& prev_o1, const crate::syntax::lexer::Tok& t_p2) {
    auto gap_p3 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        if (prism_rtl::is_none(prev_o1)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        if (prism_rtl::is_some(prev_o1)) {
            auto&& p_p4 = prism_rtl::some_of(prev_o1);
            _v.set(crate::syntax::lexer::is_layout_f(t_p2.kind_p)
                ? Text::lit("\n")
                : (is_bracket_f(prism_rtl::deref(p_p4).kind_p) && is_bracket_f(t_p2.kind_p)) && t_p2.touches_p
                ? Text::lit("·")
                : Text::lit(" "));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return t_p2.kind_p == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KEof{})
        ? std::tuple{acc_p0, std::optional(t_p2)}
        : std::tuple{prism_rtl::cat(acc_p0, gap_p3, token_text_f(t_p2.kind_p)), std::optional(t_p2)};
}


/// IsBracket: fn TokKind -> Bool
bool is_bracket_f(const crate::syntax::lexer::TokKind& tok_kind0) {
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KOpen>(tok_kind0)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KClose>(tok_kind0)) {
        return true;
    }
    {
        return false;
    }
}


/// RenderInner: fn [Tok] -> Text
Text render_inner_f(const Array<crate::syntax::lexer::Tok>& tokens_p0) {
    return crate::syntax::lexer::chars::join_f(crate::prelude::split_on(crate::syntax::lexer::chars::trim_end_f(trim_newlines_f(render_tokens_f(tokens_p0))), Text::lit("\n")), Text::lit(" "));
}


/// TrimNewlines: fn Text -> Text
Text trim_newlines_f(const Text& t_p0) {
    return crate::syntax::lexer::chars::trim_trailing_f(t_p0, Text::lit("\n \t"));
}


/// TokenText: fn TokKind -> Text
Text token_text_f(const crate::syntax::lexer::TokKind& tok_kind0) {
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(tok_kind0)) {
        auto&& n_p0 = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(tok_kind0).a0;
        return prism_rtl::cat(prism_rtl::deref(n_p0).sigils_p, crate::syntax::lexer::chars::join_f(prism_rtl::deref(n_p0).path_p, Text::lit(".")));
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KFamily>(tok_kind0)) {
        auto&& p_p1 = prism_rtl::as<crate::syntax::lexer::TokKind::KFamily>(tok_kind0).a0;
        return prism_rtl::cat(crate::syntax::lexer::chars::join_f(p_p1, Text::lit(".")), ".*");
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KTrait>(tok_kind0)) {
        auto&& p_p2 = prism_rtl::as<crate::syntax::lexer::TokKind::KTrait>(tok_kind0).a0;
        return prism_rtl::cat("^", crate::syntax::lexer::chars::join_f(p_p2, Text::lit(".")));
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(tok_kind0)) {
        auto&& w_p3 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(tok_kind0).a0;
        auto&& s_p4 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(tok_kind0).a1;
        return prism_rtl::cat(s_p4, w_p3);
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KFree>(tok_kind0)) {
        auto&& s_p5 = prism_rtl::as<crate::syntax::lexer::TokKind::KFree>(tok_kind0).a0;
        return prism_rtl::cat("free", s_p5);
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KLensDot>(tok_kind0)) {
        return Text::lit("&.");
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KInt>(tok_kind0)) {
        auto&& s_p6 = prism_rtl::as<crate::syntax::lexer::TokKind::KInt>(tok_kind0).a0;
        auto&& t_p7 = prism_rtl::as<crate::syntax::lexer::TokKind::KInt>(tok_kind0).a1;
        return prism_rtl::cat(s_p6, t_p7);
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KFloat>(tok_kind0)) {
        auto&& s_p8 = prism_rtl::as<crate::syntax::lexer::TokKind::KFloat>(tok_kind0).a0;
        auto&& t_p9 = prism_rtl::as<crate::syntax::lexer::TokKind::KFloat>(tok_kind0).a1;
        return prism_rtl::cat(s_p8, t_p9);
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KDuration>(tok_kind0)) {
        auto&& s_pa = prism_rtl::as<crate::syntax::lexer::TokKind::KDuration>(tok_kind0).a0;
        auto&& t_pb = prism_rtl::as<crate::syntax::lexer::TokKind::KDuration>(tok_kind0).a1;
        auto&& u_pc = prism_rtl::as<crate::syntax::lexer::TokKind::KDuration>(tok_kind0).a2;
        return prism_rtl::cat(s_pa, t_pb, u_pc);
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KChar>(tok_kind0)) {
        auto&& s_pd = prism_rtl::as<crate::syntax::lexer::TokKind::KChar>(tok_kind0).a0;
        auto&& c_pe = prism_rtl::as<crate::syntax::lexer::TokKind::KChar>(tok_kind0).a1;
        return prism_rtl::cat(s_pd, debug_char_f(c_pe));
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KText>(tok_kind0)) {
        auto&& s_pf = prism_rtl::as<crate::syntax::lexer::TokKind::KText>(tok_kind0).a0;
        auto&& segs_pg = prism_rtl::as<crate::syntax::lexer::TokKind::KText>(tok_kind0).a1;
        return prism_rtl::cat(s_pf, "TEXT(", crate::prelude::concat(crate::prelude::each(segs_pg, seg_text_f)), ")");
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KRegex>(tok_kind0)) {
        auto&& s_ph = prism_rtl::as<crate::syntax::lexer::TokKind::KRegex>(tok_kind0).a0;
        auto&& r_pi = prism_rtl::as<crate::syntax::lexer::TokKind::KRegex>(tok_kind0).a1;
        return prism_rtl::cat(s_ph, "REGEX(", debug_text_f(prism_rtl::deref(r_pi).pattern_p), "/", replacement_text_f(prism_rtl::deref(r_pi).replacement_o), prism_rtl::deref(r_pi).flags_p, ")");
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KTemplate>(tok_kind0)) {
        auto&& t_pj = prism_rtl::as<crate::syntax::lexer::TokKind::KTemplate>(tok_kind0).a0;
        return prism_rtl::cat("TEMPLATE<", prism_rtl::deref(t_pj).lang_p, ">(", crate::prelude::concat(crate::prelude::each(prism_rtl::deref(t_pj).parts_p, part_text_f)), ")");
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KOp>(tok_kind0) && prism_rtl::as<crate::syntax::lexer::TokKind::KOp>(tok_kind0).a1) {
        auto&& op_pk = prism_rtl::as<crate::syntax::lexer::TokKind::KOp>(tok_kind0).a0;
        return prism_rtl::cat(op_pk, "pre");
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KOp>(tok_kind0) && !prism_rtl::as<crate::syntax::lexer::TokKind::KOp>(tok_kind0).a1) {
        auto&& op_pl = prism_rtl::as<crate::syntax::lexer::TokKind::KOp>(tok_kind0).a0;
        return op_pl;
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KSuffixed>(tok_kind0)) {
        auto&& op_pm = prism_rtl::as<crate::syntax::lexer::TokKind::KSuffixed>(tok_kind0).a0;
        auto&& ty_pn = prism_rtl::as<crate::syntax::lexer::TokKind::KSuffixed>(tok_kind0).a1;
        return prism_rtl::cat(op_pm, crate::syntax::lexer::chars::join_f(ty_pn, Text::lit(".")));
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KDot>(tok_kind0) && prism_rtl::as<crate::syntax::lexer::TokKind::KDot>(tok_kind0).a0) {
        return Text::lit(".pre");
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KDot>(tok_kind0) && !prism_rtl::as<crate::syntax::lexer::TokKind::KDot>(tok_kind0).a0) {
        return Text::lit(".");
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KDotDot>(tok_kind0)) {
        return Text::lit("..");
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KComma>(tok_kind0)) {
        return Text::lit(",");
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KColon>(tok_kind0)) {
        return Text::lit(":");
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KSemi>(tok_kind0)) {
        return Text::lit(";");
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KBackslash>(tok_kind0)) {
        return Text::lit("\\");
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KLambdaBar>(tok_kind0)) {
        return Text::lit("|");
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KBar>(tok_kind0)) {
        return Text::lit("|");
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KLtLt>(tok_kind0)) {
        return Text::lit("<<");
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KGtGt>(tok_kind0)) {
        return Text::lit(">>");
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KOpen>(tok_kind0)) {
        auto&& k_po = prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(tok_kind0).a0;
        return k_po;
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KClose>(tok_kind0)) {
        auto&& k_pp = prism_rtl::as<crate::syntax::lexer::TokKind::KClose>(tok_kind0).a0;
        return crate::syntax::lexer::close_char_f(k_pp);
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KAbsent>(tok_kind0)) {
        return Text::lit("absent");
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KNonEmpty>(tok_kind0)) {
        return Text::lit("nonempty");
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KPath>(tok_kind0)) {
        auto&& segs_pq = prism_rtl::as<crate::syntax::lexer::TokKind::KPath>(tok_kind0).a0;
        return prism_rtl::cat("PATH(", crate::syntax::lexer::chars::join_f(crate::prelude::each(segs_pq, path_seg_text_f), Text::lit("/")), ")");
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KLayOpen>(tok_kind0)) {
        return Text::lit("open");
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KLaySep>(tok_kind0)) {
        return Text::lit("sep");
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KLayClose>(tok_kind0)) {
        return Text::lit("close");
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KEof>(tok_kind0)) {
        return Text::lit("eof");
    }
    prism_rtl::unreachable("no arm matched");
}


/// ReplacementText: fn ?Text -> Text
Text replacement_text_f(const std::optional<Text>& opt0) {
    if (prism_rtl::is_none(opt0)) {
        return Text::lit("");
    }
    if (prism_rtl::is_some(opt0)) {
        auto&& t_p0 = prism_rtl::some_of(opt0);
        return prism_rtl::cat(debug_text_f(t_p0), "/");
    }
    prism_rtl::unreachable("no arm matched");
}


/// SegText: fn TextSegTok -> Text
Text seg_text_f(const crate::syntax::lexer::TextSegTok& text_seg_tok0) {
    if (prism_rtl::is<crate::syntax::lexer::TextSegTok::TsPlain>(text_seg_tok0)) {
        auto&& p_p0 = prism_rtl::as<crate::syntax::lexer::TextSegTok::TsPlain>(text_seg_tok0).a0;
        return escape_braces_f(escape_debug_f(p_p0, true, true));
    }
    if (prism_rtl::is<crate::syntax::lexer::TextSegTok::TsPlaceholder>(text_seg_tok0)) {
        auto&& toks_p1 = prism_rtl::as<crate::syntax::lexer::TextSegTok::TsPlaceholder>(text_seg_tok0).a0;
        return prism_rtl::cat("{", render_inner_f(toks_p1), "}");
    }
    prism_rtl::unreachable("no arm matched");
}


/// EscapeBraces: fn Text -> Text
Text escape_braces_f(const Text& t_p0) {
    return crate::syntax::lexer::chars::map_chars_f(t_p0, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Text)>>(prism_rtl::rc([=](Text p0) {
        return crate::prelude::once_job([=]() {
            return ({
                auto c_p1 = p0;
                (c_p1 == Text::lit("{")) || (c_p1 == Text::lit("}"))
                ? prism_rtl::finished(prism_rtl::cat("\\", c_p1))
                : prism_rtl::finished(c_p1);
            });
        });
    })));
}


/// PathSegText: fn PathSegTok -> Text
Text path_seg_text_f(const crate::syntax::lexer::PathSegTok& path_seg_tok0) {
    if (prism_rtl::is<crate::syntax::lexer::PathSegTok::PstNum>(path_seg_tok0)) {
        auto&& n_p0 = prism_rtl::as<crate::syntax::lexer::PathSegTok::PstNum>(path_seg_tok0).a0;
        return prism_rtl::cat(n_p0);
    }
    if (prism_rtl::is<crate::syntax::lexer::PathSegTok::PstGen>(path_seg_tok0)) {
        auto&& n_p1 = prism_rtl::as<crate::syntax::lexer::PathSegTok::PstGen>(path_seg_tok0).a0;
        return prism_rtl::cat("#", n_p1);
    }
    if (prism_rtl::is<crate::syntax::lexer::PathSegTok::PstKey>(path_seg_tok0)) {
        auto&& toks_p2 = prism_rtl::as<crate::syntax::lexer::PathSegTok::PstKey>(path_seg_tok0).a0;
        return prism_rtl::cat("[", render_inner_f(toks_p2), "]");
    }
    prism_rtl::unreachable("no arm matched");
}


/// PartText: fn TPartTok -> Text
Text part_text_f(const crate::syntax::lexer::TPartTok& tpart_tok0) {
    if (prism_rtl::is<crate::syntax::lexer::TPartTok::TptText>(tpart_tok0)) {
        auto&& t_p0 = prism_rtl::as<crate::syntax::lexer::TPartTok::TptText>(tpart_tok0).a0;
        return debug_text_f(t_p0);
    }
    if (prism_rtl::is<crate::syntax::lexer::TPartTok::TptPlaceholder>(tpart_tok0)) {
        auto&& toks_p1 = prism_rtl::as<crate::syntax::lexer::TPartTok::TptPlaceholder>(tpart_tok0).a0;
        auto&& col_o2 = prism_rtl::as<crate::syntax::lexer::TPartTok::TptPlaceholder>(tpart_tok0).a1;
        return prism_rtl::cat("{{", render_inner_f(toks_p1), "}}", col_text_f(col_o2));
    }
    if (prism_rtl::is<crate::syntax::lexer::TPartTok::TptBlock>(tpart_tok0)) {
        auto&& toks_p3 = prism_rtl::as<crate::syntax::lexer::TPartTok::TptBlock>(tpart_tok0).a0;
        return prism_rtl::cat("BLOCK{ ", render_inner_f(toks_p3), " }");
    }
    if (prism_rtl::is<crate::syntax::lexer::TPartTok::TptCall>(tpart_tok0)) {
        auto&& name_p4 = prism_rtl::as<crate::syntax::lexer::TPartTok::TptCall>(tpart_tok0).a0;
        auto&& attrs_p5 = prism_rtl::as<crate::syntax::lexer::TPartTok::TptCall>(tpart_tok0).a1;
        auto&& body_o6 = prism_rtl::as<crate::syntax::lexer::TPartTok::TptCall>(tpart_tok0).a2;
        return prism_rtl::cat("<", prism_rtl::deref(name_p4).sigils_p, crate::syntax::lexer::chars::join_f(prism_rtl::deref(name_p4).path_p, Text::lit(".")), crate::prelude::concat(crate::prelude::each(attrs_p5, attr_text_f)), call_body_f(name_p4, body_o6));
    }
    prism_rtl::unreachable("no arm matched");
}


/// ColText: fn ?Nat -> Text
Text col_text_f(const std::optional<Nat>& opt0) {
    if (prism_rtl::is_none(opt0)) {
        return Text::lit("");
    }
    if (prism_rtl::is_some(opt0)) {
        auto&& c_p0 = prism_rtl::some_of(opt0);
        return prism_rtl::cat("@col", c_p0);
    }
    prism_rtl::unreachable("no arm matched");
}


/// AttrText: fn AttrTok -> Text
Text attr_text_f(const crate::syntax::lexer::AttrTok& a_p0) {
    return prism_rtl::cat(" ", a_p0.name_p, "={", render_inner_f(a_p0.tokens_p), "}");
}


/// CallBody: fn NameTok, ?[TPartTok] -> Text
Text call_body_f(const crate::syntax::lexer::NameTok& name_tok0, const std::optional<Array<crate::syntax::lexer::TPartTok>>& opt1) {
    auto&& _m = std::tuple{name_tok0, opt1};
    if (prism_rtl::is_none(std::get<1>(_m))) {
        return Text::lit("/>");
    }
    if (prism_rtl::is_some(std::get<1>(_m))) {
        auto&& name_p0 = std::get<0>(_m);
        auto&& parts_p1 = prism_rtl::some_of(std::get<1>(_m));
        return prism_rtl::cat(">", crate::prelude::concat(crate::prelude::each(parts_p1, part_text_f)), "</", prism_rtl::deref(name_p0).sigils_p, crate::syntax::lexer::chars::join_f(prism_rtl::deref(name_p0).path_p, Text::lit(".")), ">");
    }
    prism_rtl::unreachable("no arm matched");
}


/// DebugText: fn Text -> Text
Text debug_text_f(const Text& t_p0) {
    return prism_rtl::cat("\"", escape_debug_f(t_p0, false, true), "\"");
}


/// DebugChar: fn Text -> Text
Text debug_char_f(const Text& c_p0) {
    return prism_rtl::cat("\'", escape_debug_f(c_p0, true, false), "\'");
}


/// EscapeDebug: fn Text, Bool, Bool -> Text
Text escape_debug_f(const Text& t_p0, const bool& single_p1, const bool& double_p2) {
    return crate::syntax::lexer::chars::map_chars_f(t_p0, ({
        auto single_p1x = single_p1;
        auto double_p2x = double_p2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Text)>>(prism_rtl::rc([=, single_p1x = std::move(single_p1x), double_p2x = std::move(double_p2x)](Text p0) {
        return ({
            auto single_p1xy = single_p1x;
            auto double_p2xy = double_p2x;
            (crate::prelude::once_job([=, single_p1xy = std::move(single_p1xy), double_p2xy = std::move(double_p2xy)]() {
            return ({
                auto c_p3 = p0;
                (prism_rtl::finished(escape_char_f(c_p3, single_p1xy, double_p2xy)));
            });
        }));
        });
    })));
    }));
}


/// EscapeChar: fn Text, Bool, Bool -> Text
Text escape_char_f(const Text& c_p0, const bool& single_p1, const bool& double_p2) {
    {
        auto&& m4966_0 = c_p0;
        if (m4966_0 == Text::lit("\000"sv)) {
            return Text::lit("\\0");
        }
    }
    {
        auto&& m4966_1 = c_p0;
        if (m4966_1 == Text::lit("\t")) {
            return Text::lit("\\t");
        }
    }
    {
        auto&& m4966_2 = c_p0;
        if (m4966_2 == Text::lit("\r")) {
            return Text::lit("\\r");
        }
    }
    {
        auto&& m4966_3 = c_p0;
        if (m4966_3 == Text::lit("\n")) {
            return Text::lit("\\n");
        }
    }
    {
        auto&& m4966_4 = c_p0;
        if (m4966_4 == Text::lit("\\")) {
            return Text::lit("\\\\");
        }
    }
    {
        auto&& m4966_5 = c_p0;
        if (m4966_5 == Text::lit("\'")) {
            if (single_p1) {
                return Text::lit("\\\'");
            }
        }
    }
    {
        auto&& m4966_6 = c_p0;
        if (m4966_6 == Text::lit("\"")) {
            if (double_p2) {
                return Text::lit("\\\"");
            }
        }
    }
    {
        if ((c_p0 < Text::lit(" ")) || (c_p0 == Text::lit(""))) {
            return prism_rtl::cat("\\u{", hex_of_f(code_of_f(c_p0)), "}");
        }
    }
    {
        return c_p0;
    }
}


/// CodeOf: fn Text -> Nat
Nat code_of_f(const Text& c_p0) {
    return c_p0 == Text::lit("")
        ? Nat(128u)
        : crate::prelude::len_text(crate::prelude::or_(crate::prelude::index(crate::prelude::split_on(crate::syntax::lexer::chars::ascii_text_p(), c_p0), Nat(0u)), crate::syntax::lexer::chars::ascii_text_p()));
}


/// HexOf: fn Nat -> Text
Text hex_of_f(const Nat& n_p0) {
    return hex_digits_f(n_p0, n_p0);
}


/// HexDigits: fn Nat, Nat -> Text
Text hex_digits_f(const Nat& n_p0, const Nat& fuel_p1) {
    auto&& _m = fuel_p1.checked_sub(Nat(1u));
    if (prism_rtl::is_some(_m)) {
        auto&& left_p2 = prism_rtl::some_of(_m);
        if (n_p0 >= Nat(16u)) {
            return prism_rtl::cat(hex_digits_f(crate::prelude::or_(crate::prelude::div(n_p0, Nat(16u)), Nat(0u)), left_p2), crate::syntax::lexer::chars::char_at_byte_f(crate::syntax::lexer::chars::hex_digits_p(), crate::prelude::or_(crate::prelude::mod_(n_p0, Nat(16u)), Nat(0u))));
        }
    }
    {
        return n_p0 < Nat(16u)
            ? crate::syntax::lexer::chars::char_at_byte_f(crate::syntax::lexer::chars::hex_digits_p(), n_p0)
            : Text::lit("0");
    }
}

}  // namespace crate::syntax::lexer::corpus


// The module `Syntax.Lexer.Layout`, from `target/bootstrap/cpp-src/prismc/syntax/lexer/layout.prism`.
namespace crate::syntax::lexer::layout {

/// LexFile: unbounded fn Text -> Lexed
crate::syntax::lexer::Lexed lex_file_f(const Text& src_p0) {
    auto start_p1 = crate::syntax::lexer::Lex{.src_p = src_p0, .pos_p = Nat(0u), .diags_p = Array<crate::syntax::Diag>{}, .mode_p = crate::syntax::lexer::Mode(crate::syntax::lexer::Mode::MFile{}), .tokens_p = Array<crate::syntax::lexer::Tok>{}, .layout_p = Array<Nat>{}, .frames_p = Array<Text>{}, .last_ws_p = true, .lambda_open_p = false, .pending_open_p = false, .pending_span_p = crate::syntax::Range{.start_p = Nat(0u), .end_p = Nat(0u)}, .line_first_p = Nat(0u), .mark_line_start_p = false, .first_line_p = true, .test_pending_p = Text::lit(""), .test_depth_o = std::optional<Nat>{}, .check_depth_o = std::optional<Nat>{}, .path_next_p = false};
    auto skipped_p2 = skip_blank_and_comment_lines_f(start_p1);
    auto opened_p3 = (crate::syntax::lexer::chars::peek_f(skipped_p2) == Text::lit("<")) && (crate::syntax::lexer::templates::template_tag_ahead_f(skipped_p2) != Text::lit(""));
    auto [head_p5, l_p6] = std::move(opened_p3)
        ? template_head_f(skipped_p2)
        : std::tuple{Array<crate::syntax::lexer::Tok>{}, start_p1};
    auto body_p4 = lex_stream_f(crate::syntax::lexer::fresh_f(l_p6, crate::syntax::lexer::Mode(crate::syntax::lexer::Mode::MFile{})));
    return crate::syntax::lexer::Lexed{.tokens_p = crate::prelude::append(head_p5, prism_rtl::deref(body_p4).tokens_p), .diags_p = prism_rtl::deref(body_p4).diags_p};
}


prism_rtl::Turn<crate::syntax::lexer::Lexed> LexFile::cycle() const {
    const auto& src_p0 = this->src_p0;
    auto start_p1 = crate::syntax::lexer::Lex{.src_p = src_p0, .pos_p = Nat(0u), .diags_p = Array<crate::syntax::Diag>{}, .mode_p = crate::syntax::lexer::Mode(crate::syntax::lexer::Mode::MFile{}), .tokens_p = Array<crate::syntax::lexer::Tok>{}, .layout_p = Array<Nat>{}, .frames_p = Array<Text>{}, .last_ws_p = true, .lambda_open_p = false, .pending_open_p = false, .pending_span_p = crate::syntax::Range{.start_p = Nat(0u), .end_p = Nat(0u)}, .line_first_p = Nat(0u), .mark_line_start_p = false, .first_line_p = true, .test_pending_p = Text::lit(""), .test_depth_o = std::optional<Nat>{}, .check_depth_o = std::optional<Nat>{}, .path_next_p = false};
    return crate::prelude::call_then(start_skip_blank_and_comment_lines_f(start_p1), [=](crate::syntax::lexer::Lex skip_blank_and_comment_lines_f_1051) {
        return ({
            auto skipped_p2 = skip_blank_and_comment_lines_f_1051;
            auto opened_p3 = (crate::syntax::lexer::chars::peek_f(skipped_p2) == Text::lit("<")) && (crate::syntax::lexer::templates::template_tag_ahead_f(skipped_p2) != Text::lit(""));
            auto [head_p5, l_p6] = std::move(opened_p3)
                ? template_head_f(skipped_p2)
                : std::tuple{Array<crate::syntax::lexer::Tok>{}, start_p1};
            (crate::prelude::call_then(start_lex_stream_f(crate::syntax::lexer::fresh_f(l_p6, crate::syntax::lexer::Mode(crate::syntax::lexer::Mode::MFile{}))), [=](crate::syntax::lexer::Lex lex_stream_f_1249) {
            return ({
                auto body_p4 = lex_stream_f_1249;
                (prism_rtl::finished(crate::syntax::lexer::Lexed{.tokens_p = crate::prelude::append(head_p5, prism_rtl::deref(body_p4).tokens_p), .diags_p = prism_rtl::deref(body_p4).diags_p}));
            });
        }));
        });
    });
}


/// `Start LexFile, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lexed> start_lex_file_f(Text src_p0) {
    return prism_rtl::make_rc<LexFile>(src_p0);
}


/// TemplateHead: unbounded fn Lex -> (([Tok], Lex))
std::tuple<Array<crate::syntax::lexer::Tok>, crate::syntax::lexer::Lex> template_head_f(const crate::syntax::lexer::Lex& l0_p0) {
    auto [kind_p2, l_p3] = crate::syntax::lexer::templates::lex_template_f(l0_p0, Text::lit("File"), l0_p0.pos_p);
    auto tok_p1 = crate::syntax::lexer::Tok{.kind_p = kind_p2, .span_p = crate::syntax::Range{.start_p = l0_p0.pos_p, .end_p = prism_rtl::deref(l_p3).pos_p}, .touches_p = false, .line_start_p = false};
    return std::tuple{Array(std::vector{tok_p1}), l_p3};
}


prism_rtl::Turn<std::tuple<Array<crate::syntax::lexer::Tok>, crate::syntax::lexer::Lex>> TemplateHead::cycle() const {
    const auto& l0_p0 = this->l0_p0;
    auto l0_p0x = l0_p0;
    return crate::prelude::call_then(crate::syntax::lexer::templates::start_lex_template_f(l0_p0x, Text::lit("File"), prism_rtl::deref(l0_p0x).pos_p), [=](std::tuple<crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex> lex_template_f_1501) {
        return ({
            auto [kind_p2, l_p3] = lex_template_f_1501;
            auto tok_p1 = crate::syntax::lexer::Tok{.kind_p = kind_p2, .span_p = crate::syntax::Range{.start_p = prism_rtl::deref(l0_p0x).pos_p, .end_p = prism_rtl::deref(l_p3).pos_p}, .touches_p = false, .line_start_p = false};
            (prism_rtl::finished(std::tuple{Array(std::vector{tok_p1}), l_p3}));
        });
    });
}


/// `Start TemplateHead, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::syntax::lexer::Tok>, crate::syntax::lexer::Lex>> start_template_head_f(crate::syntax::lexer::Lex l0_p0) {
    return prism_rtl::make_rc<TemplateHead>(l0_p0);
}


/// SkipBlankAndCommentLines: unbounded fn Lex -> Lex
crate::syntax::lexer::Lex skip_blank_and_comment_lines_f(const crate::syntax::lexer::Lex& l_p0) {
    crate::syntax::lexer::Lex this_ = l_p0;
    bool going_p1 = true;
    while (std::move(going_p1)) {
        auto line_p2 = crate::syntax::lexer::chars::rest_of_line_f(this_);
        auto t_p3 = crate::syntax::lexer::chars::trim_start_f(line_p2);
        if (((t_p3 == Text::lit("")) || (crate::syntax::lexer::chars::head_f(t_p3) == Text::lit("#"))) && ((this_.pos_p + crate::prelude::len_text(line_p2)) < crate::prelude::len_text(this_.src_p))) {
            this_.pos_p = this_.pos_p + (crate::prelude::len_text(line_p2) + Nat(1u));
        } else  {
            going_p1 = false;
        }
    }
    return this_;
}


prism_rtl::Turn<crate::syntax::lexer::Lex> SkipBlankAndCommentLines::cycle() const {
    const auto& l_p0 = this->l_p0;
    crate::syntax::lexer::Lex this_ = l_p0;
    bool going_p1 = true;
    return crate::prelude::call_then(crate::prelude::loop_job(std::tuple{std::move(this_), std::move(going_p1)}, [=](std::tuple<crate::syntax::lexer::Lex, bool> _p0) {
        auto this_ = std::get<0>(_p0);
        auto going_p1 = std::get<1>(_p0);
        return going_p1
            ? ({
            auto line_p2 = crate::syntax::lexer::chars::rest_of_line_f(this_);
            auto t_p3 = crate::syntax::lexer::chars::trim_start_f(line_p2);
            if (((t_p3 == Text::lit("")) || (crate::syntax::lexer::chars::head_f(t_p3) == Text::lit("#"))) && ((prism_rtl::deref(this_).pos_p + crate::prelude::len_text(line_p2)) < crate::prelude::len_text(prism_rtl::deref(this_).src_p))) {
                prism_rtl::deref(this_).pos_p = prism_rtl::deref(this_).pos_p + (crate::prelude::len_text(line_p2) + Nat(1u));
            } else  {
                going_p1 = false;
            }
            Expected<std::tuple<crate::syntax::lexer::Lex, bool>, std::tuple<crate::syntax::lexer::Lex, bool>>(std::tuple{this_, going_p1});
        })
            : Expected<std::tuple<crate::syntax::lexer::Lex, bool>, std::tuple<crate::syntax::lexer::Lex, bool>>(unexpected(std::tuple{this_, going_p1}));
    }), [=](std::tuple<crate::syntax::lexer::Lex, bool> _p0) {
        auto this_ = std::get<0>(_p0);
        auto going_p1 = std::get<1>(_p0);
        return prism_rtl::finished(this_);
    });
}


/// `Start SkipBlankAndCommentLines, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_skip_blank_and_comment_lines_f(crate::syntax::lexer::Lex l_p0) {
    return prism_rtl::make_rc<SkipBlankAndCommentLines>(l_p0);
}


/// Nested: unbounded fn Lex, Mode -> (([Tok], Lex))
std::tuple<Array<crate::syntax::lexer::Tok>, crate::syntax::lexer::Lex> nested_f(const crate::syntax::lexer::Lex& l_p0, const crate::syntax::lexer::Mode& mode_p1) {
    auto inner_p2 = lex_stream_f(crate::syntax::lexer::fresh_f(l_p0, mode_p1));
    auto back_p3 = ({
        crate::syntax::lexer::Lex this_ = l_p0;
        this_.pos_p = prism_rtl::deref(inner_p2).pos_p;
        this_.diags_p = prism_rtl::deref(inner_p2).diags_p;
        (std::move(this_));
    });
    return std::tuple{prism_rtl::deref(inner_p2).tokens_p, back_p3};
}


prism_rtl::Turn<std::tuple<Array<crate::syntax::lexer::Tok>, crate::syntax::lexer::Lex>> Nested::cycle() const {
    const auto& l_p0 = this->l_p0;
    const auto& mode_p1 = this->mode_p1;
    auto l_p0x = l_p0;
    auto mode_p1x = mode_p1;
    return crate::prelude::call_then(start_lex_stream_f(crate::syntax::lexer::fresh_f(l_p0x, mode_p1x)), [=](crate::syntax::lexer::Lex lex_stream_f_2224) {
        return ({
            auto inner_p2 = lex_stream_f_2224;
            auto back_p3 = ({
                crate::syntax::lexer::Lex this_ = l_p0x;
                this_.pos_p = prism_rtl::deref(inner_p2).pos_p;
                this_.diags_p = prism_rtl::deref(inner_p2).diags_p;
                (std::move(this_));
            });
            (prism_rtl::finished(std::tuple{prism_rtl::deref(inner_p2).tokens_p, back_p3}));
        });
    });
}


/// `Start Nested, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::syntax::lexer::Tok>, crate::syntax::lexer::Lex>> start_nested_f(crate::syntax::lexer::Lex l_p0, crate::syntax::lexer::Mode mode_p1) {
    return prism_rtl::make_rc<Nested>(l_p0, mode_p1);
}


/// LexStream: unbounded fn Lex -> Lex
crate::syntax::lexer::Lex lex_stream_f(const crate::syntax::lexer::Lex& l0_p0) {
    crate::syntax::lexer::Lex this_ = l0_p0;
    bool at_line_start_p1 = crate::syntax::lexer::layout_on_f(this_.mode_p);
    bool done_p2 = false;
    while (!std::move(done_p2)) {
        bool go_p3 = true;
        if (std::move(at_line_start_p1) && crate::syntax::lexer::layout_active_f(this_)) {
            at_line_start_p1 = false;
            auto [l_p4, verdict_p5] = begin_line_f(this_);
            this_ = l_p4;
            if (verdict_p5 == Text::lit("skip")) {
                at_line_start_p1 = true;
                go_p3 = false;
            }
            if (verdict_p5 == Text::lit("end")) {
                done_p2 = true;
                go_p3 = false;
            }
        }
        if (std::move(go_p3)) {
            auto c_p6 = crate::syntax::lexer::chars::peek_f(this_);
            ({
                __label__ _done;
                prism_rtl::Slot<Unit> _v;
                {
                    auto&& u3052_0 = c_p6;
                    if (u3052_0 == Text::lit("")) {
                        _v.set(({
                            this_ = unclosed_stream_f(this_);
                            done_p2 = true;
                            Unit{};
                        }));
                        goto _done;
                    }
                }
                {
                    auto&& u3052_1 = c_p6;
                    if (u3052_1 == Text::lit("\n")) {
                        _v.set(({
                            this_.pos_p = this_.pos_p + Nat(1u);
                            this_.last_ws_p = true;
                            if (this_.lambda_open_p) {
                                this_ = crate::syntax::lexer::chars::lex_err_f(this_, crate::syntax::lexer::chars::dec_f(this_.pos_p), this_.pos_p, Text::lit("a lambda\'s parameter list closes with `|` on its own line"));
                                this_.lambda_open_p = false;
                            }
                            if (crate::syntax::lexer::layout_active_f(this_)) {
                                this_ = end_line_f(this_);
                                at_line_start_p1 = true;
                            }
                            Unit{};
                        }));
                        goto _done;
                    }
                }
                {
                    auto&& u3052_2 = c_p6;
                    if (u3052_2 == Text::lit(" ")) {
                        _v.set(({
                            this_.pos_p = this_.pos_p + Nat(1u);
                            this_.last_ws_p = true;
                            Unit{};
                        }));
                        goto _done;
                    }
                }
                {
                    auto&& u3052_3 = c_p6;
                    if (u3052_3 == Text::lit("\r")) {
                        _v.set(({
                            this_.pos_p = this_.pos_p + Nat(1u);
                            this_.last_ws_p = true;
                            Unit{};
                        }));
                        goto _done;
                    }
                }
                {
                    auto&& u3052_4 = c_p6;
                    if (u3052_4 == Text::lit("\t")) {
                        _v.set(({
                            this_.pos_p = this_.pos_p + Nat(1u);
                            this_.last_ws_p = true;
                            Unit{};
                        }));
                        goto _done;
                    }
                }
                {
                    auto&& u3052_5 = c_p6;
                    if (u3052_5 == Text::lit("#")) {
                        _v.set(({
                            this_.pos_p = crate::syntax::lexer::chars::line_end_f(this_);
                            this_.last_ws_p = true;
                            Unit{};
                        }));
                        goto _done;
                    }
                }
                {
                    _v.set(({
                        auto [ends_p7, l_p8] = stream_ends_here_f(this_);
                        this_ = l_p8;
                        if (ends_p7) {
                            done_p2 = true;
                        } else  {
                            this_ = crate::syntax::lexer::words::lex_token_f(this_);
                        }
                        Unit{};
                    }));
                    goto _done;
                }
            _done:
                _v.take();
            });
        }
    }
    if (crate::syntax::lexer::layout_on_f(this_.mode_p)) {
        while (crate::prelude::len(this_.layout_p) > Nat(1u)) {
            this_.layout_p = crate::syntax::lexer::chars::pop_f(this_.layout_p);
            this_ = crate::syntax::lexer::push_tok_f(this_, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KLayClose{}), this_.pos_p, this_.pos_p);
        }
    }
    if (this_.mode_p == crate::syntax::lexer::Mode(crate::syntax::lexer::Mode::MFile{})) {
        this_ = crate::syntax::lexer::push_tok_f(this_, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KEof{}), this_.pos_p, this_.pos_p);
    }
    return this_;
}


prism_rtl::Turn<crate::syntax::lexer::Lex> LexStream::cycle() const {
    const auto& l0_p0 = this->l0_p0;
    crate::syntax::lexer::Lex this_ = l0_p0;
    bool at_line_start_p1 = crate::syntax::lexer::layout_on_f(this_.mode_p);
    bool done_p2 = false;
    return crate::prelude::call_then(crate::prelude::loop_job(std::tuple{std::move(this_), std::move(at_line_start_p1), std::move(done_p2)}, [=](std::tuple<crate::syntax::lexer::Lex, bool, bool> _p0) {
        auto this_ = std::get<0>(_p0);
        auto at_line_start_p1 = std::get<1>(_p0);
        auto done_p2 = std::get<2>(_p0);
        return !done_p2
            ? ({
            bool go_p3 = true;
            if (at_line_start_p1 && crate::syntax::lexer::layout_active_f(this_)) {
                at_line_start_p1 = false;
                auto [l_p4, verdict_p5] = begin_line_f(this_);
                this_ = l_p4;
                if (verdict_p5 == Text::lit("skip")) {
                    at_line_start_p1 = true;
                    go_p3 = false;
                }
                if (verdict_p5 == Text::lit("end")) {
                    done_p2 = true;
                    go_p3 = false;
                }
            }
            if (std::move(go_p3)) {
                auto c_p6 = crate::syntax::lexer::chars::peek_f(this_);
                ({
                    __label__ _done;
                    prism_rtl::Slot<Unit> _v;
                    {
                        auto&& u3052_0 = c_p6;
                        if (u3052_0 == Text::lit("")) {
                            _v.set(({
                                this_ = unclosed_stream_f(this_);
                                done_p2 = true;
                                Unit{};
                            }));
                            goto _done;
                        }
                    }
                    {
                        auto&& u3052_1 = c_p6;
                        if (u3052_1 == Text::lit("\n")) {
                            _v.set(({
                                prism_rtl::deref(this_).pos_p = prism_rtl::deref(this_).pos_p + Nat(1u);
                                prism_rtl::deref(this_).last_ws_p = true;
                                if (prism_rtl::deref(this_).lambda_open_p) {
                                    this_ = crate::syntax::lexer::chars::lex_err_f(this_, crate::syntax::lexer::chars::dec_f(prism_rtl::deref(this_).pos_p), prism_rtl::deref(this_).pos_p, Text::lit("a lambda\'s parameter list closes with `|` on its own line"));
                                    prism_rtl::deref(this_).lambda_open_p = false;
                                }
                                if (crate::syntax::lexer::layout_active_f(this_)) {
                                    this_ = end_line_f(this_);
                                    at_line_start_p1 = true;
                                }
                                Unit{};
                            }));
                            goto _done;
                        }
                    }
                    {
                        auto&& u3052_2 = c_p6;
                        if (u3052_2 == Text::lit(" ")) {
                            _v.set(({
                                prism_rtl::deref(this_).pos_p = prism_rtl::deref(this_).pos_p + Nat(1u);
                                prism_rtl::deref(this_).last_ws_p = true;
                                Unit{};
                            }));
                            goto _done;
                        }
                    }
                    {
                        auto&& u3052_3 = c_p6;
                        if (u3052_3 == Text::lit("\r")) {
                            _v.set(({
                                prism_rtl::deref(this_).pos_p = prism_rtl::deref(this_).pos_p + Nat(1u);
                                prism_rtl::deref(this_).last_ws_p = true;
                                Unit{};
                            }));
                            goto _done;
                        }
                    }
                    {
                        auto&& u3052_4 = c_p6;
                        if (u3052_4 == Text::lit("\t")) {
                            _v.set(({
                                prism_rtl::deref(this_).pos_p = prism_rtl::deref(this_).pos_p + Nat(1u);
                                prism_rtl::deref(this_).last_ws_p = true;
                                Unit{};
                            }));
                            goto _done;
                        }
                    }
                    {
                        auto&& u3052_5 = c_p6;
                        if (u3052_5 == Text::lit("#")) {
                            _v.set(({
                                prism_rtl::deref(this_).pos_p = crate::syntax::lexer::chars::line_end_f(this_);
                                prism_rtl::deref(this_).last_ws_p = true;
                                Unit{};
                            }));
                            goto _done;
                        }
                    }
                    {
                        _v.set(({
                            auto [ends_p7, l_p8] = stream_ends_here_f(this_);
                            this_ = l_p8;
                            if (ends_p7) {
                                done_p2 = true;
                            } else  {
                                this_ = crate::syntax::lexer::words::lex_token_f(this_);
                            }
                            Unit{};
                        }));
                        goto _done;
                    }
                _done:
                    _v.take();
                });
            }
            Expected<std::tuple<crate::syntax::lexer::Lex, bool, bool>, std::tuple<crate::syntax::lexer::Lex, bool, bool>>(std::tuple{this_, at_line_start_p1, done_p2});
        })
            : Expected<std::tuple<crate::syntax::lexer::Lex, bool, bool>, std::tuple<crate::syntax::lexer::Lex, bool, bool>>(unexpected(std::tuple{this_, at_line_start_p1, done_p2}));
    }), [=](std::tuple<crate::syntax::lexer::Lex, bool, bool> _p0) {
        auto this_ = std::get<0>(_p0);
        auto at_line_start_p1 = std::get<1>(_p0);
        auto done_p2 = std::get<2>(_p0);
        return ({
            auto k_if4442 = [=](std::tuple<crate::syntax::lexer::Lex, bool, bool> _p0) {
                auto this_ = std::get<0>(_p0);
                auto at_line_start_p1 = std::get<1>(_p0);
                auto done_p2 = std::get<2>(_p0);
                return ({
                    if (prism_rtl::deref(this_).mode_p == crate::syntax::lexer::Mode(crate::syntax::lexer::Mode::MFile{})) {
                        this_ = crate::syntax::lexer::push_tok_f(this_, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KEof{}), prism_rtl::deref(this_).pos_p, prism_rtl::deref(this_).pos_p);
                    }
                    (prism_rtl::finished(this_));
                });
            };
            (crate::syntax::lexer::layout_on_f(prism_rtl::deref(this_).mode_p)
            ? crate::prelude::call_then(crate::prelude::loop_job(std::tuple{this_, at_line_start_p1, done_p2}, [=](std::tuple<crate::syntax::lexer::Lex, bool, bool> _p0) {
            auto this_ = std::get<0>(_p0);
            auto at_line_start_p1 = std::get<1>(_p0);
            auto done_p2 = std::get<2>(_p0);
            return crate::prelude::len(prism_rtl::deref(this_).layout_p) > Nat(1u)
                ? ({
                prism_rtl::deref(this_).layout_p = crate::syntax::lexer::chars::pop_f(prism_rtl::deref(this_).layout_p);
                this_ = crate::syntax::lexer::push_tok_f(this_, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KLayClose{}), prism_rtl::deref(this_).pos_p, prism_rtl::deref(this_).pos_p);
                Expected<std::tuple<crate::syntax::lexer::Lex, bool, bool>, std::tuple<crate::syntax::lexer::Lex, bool, bool>>(std::tuple{this_, at_line_start_p1, done_p2});
            })
                : Expected<std::tuple<crate::syntax::lexer::Lex, bool, bool>, std::tuple<crate::syntax::lexer::Lex, bool, bool>>(unexpected(std::tuple{this_, at_line_start_p1, done_p2}));
        }), [=](std::tuple<crate::syntax::lexer::Lex, bool, bool> _p0) {
            auto this_ = std::get<0>(_p0);
            auto at_line_start_p1 = std::get<1>(_p0);
            auto done_p2 = std::get<2>(_p0);
            return k_if4442(std::tuple{this_, at_line_start_p1, done_p2});
        })
            : k_if4442(std::tuple{this_, at_line_start_p1, done_p2}));
        });
    });
}


/// `Start LexStream, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_lex_stream_f(crate::syntax::lexer::Lex l0_p0) {
    return prism_rtl::make_rc<LexStream>(l0_p0);
}


/// UnclosedStream: fn Lex -> Lex
crate::syntax::lexer::Lex unclosed_stream_f(const crate::syntax::lexer::Lex& l_p0) {
    auto&& _m = l_p0.mode_p;
    if (prism_rtl::is<crate::syntax::lexer::Mode::MFile>(_m)) {
        return l_p0;
    }
    if (prism_rtl::is<crate::syntax::lexer::Mode::MBrace>(_m)) {
        return crate::syntax::lexer::chars::lex_err_f(l_p0, l_p0.pos_p, l_p0.pos_p, Text::lit("a brace block never closes: expected its closing delimiter alone on a line"));
    }
    if (prism_rtl::is<crate::syntax::lexer::Mode::MPlaceholder>(_m)) {
        auto&& m4718_2_0 = prism_rtl::as<crate::syntax::lexer::Mode::MPlaceholder>(_m).a0;
        if (m4718_2_0 == Text::lit("single")) {
            return crate::syntax::lexer::chars::lex_err_f(l_p0, l_p0.pos_p, l_p0.pos_p, Text::lit("a placeholder never closes: expected `}`"));
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::Mode::MPlaceholder>(_m)) {
        return crate::syntax::lexer::chars::lex_err_f(l_p0, l_p0.pos_p, l_p0.pos_p, Text::lit("a placeholder never closes: expected `}}`"));
    }
    if (prism_rtl::is<crate::syntax::lexer::Mode::MPathKey>(_m)) {
        return crate::syntax::lexer::chars::lex_err_f(l_p0, l_p0.pos_p, l_p0.pos_p, Text::lit("a path key never closes: expected `]`"));
    }
    prism_rtl::unreachable("no arm matched");
}


/// StreamEndsHere: fn Lex -> ((Bool, Lex))
std::tuple<bool, crate::syntax::lexer::Lex> stream_ends_here_f(const crate::syntax::lexer::Lex& l_p0) {
    auto c_p1 = crate::syntax::lexer::chars::peek_f(l_p0);
    auto closes_p2 = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = l_p0.mode_p;
        if (prism_rtl::is<crate::syntax::lexer::Mode::MPlaceholder>(_m)) {
            auto&& m5318_0_0 = prism_rtl::as<crate::syntax::lexer::Mode::MPlaceholder>(_m).a0;
            if (m5318_0_0 == Text::lit("single")) {
                _v.set(c_p1 == Text::lit("}"));
                goto _done;
            }
        }
        if (prism_rtl::is<crate::syntax::lexer::Mode::MPlaceholder>(_m)) {
            auto&& m5318_1_0 = prism_rtl::as<crate::syntax::lexer::Mode::MPlaceholder>(_m).a0;
            if (m5318_1_0 == Text::lit("double")) {
                _v.set(crate::syntax::lexer::chars::starts_with_f(l_p0, Text::lit("}}")));
                goto _done;
            }
        }
        if (prism_rtl::is<crate::syntax::lexer::Mode::MPathKey>(_m)) {
            _v.set(c_p1 == Text::lit("]"));
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
    auto width_p3 = l_p0.mode_p == crate::syntax::lexer::Mode(crate::syntax::lexer::Mode::MPlaceholder{Text::lit("double")})
        ? Nat(2u)
        : Nat(1u);
    return (crate::prelude::len(l_p0.frames_p) == Nat(0u)) && std::move(closes_p2)
        ? std::tuple{true, crate::syntax::lexer::chars::forward_f(l_p0, width_p3)}
        : std::tuple{false, l_p0};
}


/// EndLine: fn Lex -> Lex
crate::syntax::lexer::Lex end_line_f(const crate::syntax::lexer::Lex& l_p0) {
    auto&& _m = crate::syntax::lexer::chars::last_o(l_p0.tokens_p);
    if (prism_rtl::is_some(_m)) {
        auto&& t_p1 = prism_rtl::some_of(_m);
        if ((crate::prelude::len(l_p0.tokens_p) > l_p0.line_first_p) && opens_block_f(prism_rtl::deref(t_p1).kind_p)) {
            crate::syntax::lexer::Lex this_ = l_p0;
            this_.pending_open_p = true;
            this_.pending_span_p = prism_rtl::deref(t_p1).span_p;
            return this_;
        }
    }
    {
        return l_p0;
    }
}


/// OpensBlock: fn TokKind -> Bool
bool opens_block_f(const crate::syntax::lexer::TokKind& tok_kind0) {
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KColon>(tok_kind0)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KLambdaBar>(tok_kind0) && !prism_rtl::as<crate::syntax::lexer::TokKind::KLambdaBar>(tok_kind0).a0) {
        return true;
    }
    {
        return false;
    }
}


/// BeginLine: unbounded fn Lex -> ((Lex, Text))
std::tuple<crate::syntax::lexer::Lex, Text> begin_line_f(const crate::syntax::lexer::Lex& l0_p0) {
    auto line_begin_p1 = l0_p0.pos_p;
    auto [l1_p2, col_p3] = indentation_f(l0_p0);
    auto&& _m = crate::syntax::lexer::chars::peek_f(l1_p2);
    {
        auto&& m6669_0 = _m;
        if (m6669_0 == Text::lit("")) {
            return std::tuple{l1_p2, Text::lit("end")};
        }
    }
    {
        auto&& m6669_1 = _m;
        if (m6669_1 == Text::lit("\n")) {
            return std::tuple{crate::syntax::lexer::chars::bump_f(l1_p2), Text::lit("skip")};
        }
    }
    {
        auto&& m6669_2 = _m;
        if (m6669_2 == Text::lit("#")) {
            auto l2_p4 = ({
                crate::syntax::lexer::Lex this_ = l1_p2;
                this_.pos_p = crate::syntax::lexer::chars::line_end_f(this_);
                (std::move(this_));
            });
            return crate::syntax::lexer::chars::peek_f(l2_p4) == Text::lit("\n")
                ? std::tuple{crate::syntax::lexer::chars::bump_f(l2_p4), Text::lit("skip")}
                : std::tuple{l2_p4, Text::lit("end")};
        }
    }
    {
        return closes_brace_block_f(l1_p2)
            ? std::tuple{skip_line_f(l1_p2), Text::lit("end")}
            : ({
            auto l2_p5 = indented_line_f(l1_p2, col_p3, line_begin_p1);
            std::tuple{l2_p5, Text::lit("tokens")};
        });
    }
}


prism_rtl::Turn<std::tuple<crate::syntax::lexer::Lex, Text>> BeginLine::cycle() const {
    const auto& l0_p0 = this->l0_p0;
    auto line_begin_p1 = prism_rtl::deref(l0_p0).pos_p;
    auto l0_p0x = l0_p0;
    return crate::prelude::call_then(start_indentation_f(l0_p0x), [=](std::tuple<crate::syntax::lexer::Lex, Nat> indentation_f_6650) {
        return ({
            auto [l1_p2, col_p3] = indentation_f_6650;
            ({
            auto&& _m = crate::syntax::lexer::chars::peek_f(l1_p2);
            ({
            auto&& m6669_0 = _m;
            (m6669_0 == Text::lit(""));
        }) ? ({
            auto&& m6669_0 = _m;
            prism_rtl::finished(std::tuple{l1_p2, Text::lit("end")});
        })
            : ({
            auto&& m6669_1 = _m;
            (m6669_1 == Text::lit("\n"));
        }) ? ({
            auto&& m6669_1 = _m;
            prism_rtl::finished(std::tuple{crate::syntax::lexer::chars::bump_f(l1_p2), Text::lit("skip")});
        })
            : ({
            auto&& m6669_2 = _m;
            (m6669_2 == Text::lit("#"));
        }) ? ({
            auto&& m6669_2 = _m;
            ({
            auto l2_p4 = ({
                crate::syntax::lexer::Lex this_ = l1_p2;
                this_.pos_p = crate::syntax::lexer::chars::line_end_f(this_);
                (std::move(this_));
            });
            (crate::syntax::lexer::chars::peek_f(l2_p4) == Text::lit("\n")
            ? prism_rtl::finished(std::tuple{crate::syntax::lexer::chars::bump_f(l2_p4), Text::lit("skip")})
            : prism_rtl::finished(std::tuple{l2_p4, Text::lit("end")}));
        });
        })
            : crate::prelude::call_then(start_closes_brace_block_f(l1_p2), [=](bool closes_brace_block_f_7024) {
            return closes_brace_block_f_7024
                ? crate::prelude::call_then(start_skip_line_f(l1_p2), [=](crate::syntax::lexer::Lex skip_line_f_7047) { return prism_rtl::finished(std::tuple{skip_line_f_7047, Text::lit("end")}); })
                : crate::prelude::call_then(start_indented_line_f(l1_p2, col_p3, line_begin_p1), [=](crate::syntax::lexer::Lex indented_line_f_7111) {
                return ({
                    auto l2_p5 = indented_line_f_7111;
                    (prism_rtl::finished(std::tuple{l2_p5, Text::lit("tokens")}));
                });
            });
        });
        });
        });
    });
}


/// `Start BeginLine, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::lexer::Lex, Text>> start_begin_line_f(crate::syntax::lexer::Lex l0_p0) {
    return prism_rtl::make_rc<BeginLine>(l0_p0);
}


/// Indentation: unbounded fn Lex -> ((Lex, Nat))
std::tuple<crate::syntax::lexer::Lex, Nat> indentation_f(const crate::syntax::lexer::Lex& l0_p0) {
    std::tuple<crate::syntax::lexer::Lex, Nat> this_ = std::tuple{l0_p0, Nat(0u)};
    crate::syntax::lexer::Lex l_p1 = l0_p0;
    Nat col_p2 = Nat(0u);
    bool going_p3 = true;
    while (std::move(going_p3)) {
        ({
            __label__ _done;
            prism_rtl::Slot<Unit> _v;
            auto&& _m = crate::syntax::lexer::chars::peek_f(l_p1);
            {
                auto&& u7432_0 = _m;
                if (u7432_0 == Text::lit(" ")) {
                    _v.set(({
                        l_p1 = crate::syntax::lexer::chars::bump_f(l_p1);
                        col_p2 = col_p2 + Nat(1u);
                        Unit{};
                    }));
                    goto _done;
                }
            }
            {
                auto&& u7432_1 = _m;
                if (u7432_1 == Text::lit("\t")) {
                    _v.set(({
                        l_p1 = crate::syntax::lexer::chars::lex_err_f(crate::syntax::lexer::chars::bump_f(l_p1), l_p1.pos_p, l_p1.pos_p + Nat(1u), Text::lit("a tab in leading whitespace is an error: indent with spaces"));
                        col_p2 = col_p2 + Nat(1u);
                        Unit{};
                    }));
                    goto _done;
                }
            }
            {
                auto&& u7432_2 = _m;
                if (u7432_2 == Text::lit("\r")) {
                    _v.set(({
                        l_p1 = crate::syntax::lexer::chars::bump_f(l_p1);
                        Unit{};
                    }));
                    goto _done;
                }
            }
            {
                _v.set(({
                    going_p3 = false;
                    Unit{};
                }));
                goto _done;
            }
        _done:
            _v.take();
        });
    }
    this_ = std::tuple{l_p1, col_p2};
    return this_;
}


prism_rtl::Turn<std::tuple<crate::syntax::lexer::Lex, Nat>> Indentation::cycle() const {
    const auto& l0_p0 = this->l0_p0;
    std::tuple<crate::syntax::lexer::Lex, Nat> this_ = std::tuple{l0_p0, Nat(0u)};
    crate::syntax::lexer::Lex l_p1 = l0_p0;
    Nat col_p2 = Nat(0u);
    bool going_p3 = true;
    return crate::prelude::call_then(crate::prelude::loop_job(std::tuple{std::move(this_), std::move(col_p2), std::move(going_p3), std::move(l_p1)}, [=](std::tuple<std::tuple<crate::syntax::lexer::Lex, Nat>, Nat, bool, crate::syntax::lexer::Lex> _p0) {
        auto this_ = std::get<0>(_p0);
        auto col_p2 = std::get<1>(_p0);
        auto going_p3 = std::get<2>(_p0);
        auto l_p1 = std::get<3>(_p0);
        return going_p3
            ? ({
            ({
                __label__ _done;
                prism_rtl::Slot<Unit> _v;
                auto&& _m = crate::syntax::lexer::chars::peek_f(l_p1);
                {
                    auto&& u7432_0 = _m;
                    if (u7432_0 == Text::lit(" ")) {
                        _v.set(({
                            l_p1 = crate::syntax::lexer::chars::bump_f(l_p1);
                            col_p2 = col_p2 + Nat(1u);
                            Unit{};
                        }));
                        goto _done;
                    }
                }
                {
                    auto&& u7432_1 = _m;
                    if (u7432_1 == Text::lit("\t")) {
                        _v.set(({
                            l_p1 = crate::syntax::lexer::chars::lex_err_f(crate::syntax::lexer::chars::bump_f(l_p1), prism_rtl::deref(l_p1).pos_p, prism_rtl::deref(l_p1).pos_p + Nat(1u), Text::lit("a tab in leading whitespace is an error: indent with spaces"));
                            col_p2 = col_p2 + Nat(1u);
                            Unit{};
                        }));
                        goto _done;
                    }
                }
                {
                    auto&& u7432_2 = _m;
                    if (u7432_2 == Text::lit("\r")) {
                        _v.set(({
                            l_p1 = crate::syntax::lexer::chars::bump_f(l_p1);
                            Unit{};
                        }));
                        goto _done;
                    }
                }
                {
                    _v.set(({
                        going_p3 = false;
                        Unit{};
                    }));
                    goto _done;
                }
            _done:
                _v.take();
            });
            Expected<std::tuple<std::tuple<crate::syntax::lexer::Lex, Nat>, Nat, bool, crate::syntax::lexer::Lex>, std::tuple<std::tuple<crate::syntax::lexer::Lex, Nat>, Nat, bool, crate::syntax::lexer::Lex>>(std::tuple{this_, col_p2, going_p3, l_p1});
        })
            : Expected<std::tuple<std::tuple<crate::syntax::lexer::Lex, Nat>, Nat, bool, crate::syntax::lexer::Lex>, std::tuple<std::tuple<crate::syntax::lexer::Lex, Nat>, Nat, bool, crate::syntax::lexer::Lex>>(unexpected(std::tuple{this_, col_p2, going_p3, l_p1}));
    }), [=](std::tuple<std::tuple<crate::syntax::lexer::Lex, Nat>, Nat, bool, crate::syntax::lexer::Lex> _p0) {
        auto this_ = std::get<0>(_p0);
        auto col_p2 = std::get<1>(_p0);
        auto going_p3 = std::get<2>(_p0);
        auto l_p1 = std::get<3>(_p0);
        return ({
            this_ = std::tuple{l_p1, col_p2};
            (prism_rtl::finished(this_));
        });
    });
}


/// `Start Indentation, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::lexer::Lex, Nat>> start_indentation_f(crate::syntax::lexer::Lex l0_p0) {
    return prism_rtl::make_rc<Indentation>(l0_p0);
}


/// ClosesBraceBlock: unbounded fn Lex -> Bool
bool closes_brace_block_f(const crate::syntax::lexer::Lex& l_p0) {
    auto&& _m = l_p0.mode_p;
    if (prism_rtl::is<crate::syntax::lexer::Mode::MBrace>(_m)) {
        auto&& m7910_0_0 = prism_rtl::as<crate::syntax::lexer::Mode::MBrace>(_m).a0;
        if (m7910_0_0 == Text::lit("double")) {
            return crate::syntax::lexer::chars::trim_end_f(crate::syntax::lexer::chars::rest_of_line_f(l_p0)) == Text::lit("}}");
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::Mode::MBrace>(_m)) {
        return crate::syntax::lexer::chars::trim_end_f(crate::syntax::lexer::chars::rest_of_line_f(l_p0)) == Text::lit("}");
    }
    {
        return false;
    }
}


prism_rtl::Turn<bool> ClosesBraceBlock::cycle() const {
    const auto& l_p0 = this->l_p0;
    return ({
        auto&& _m = prism_rtl::deref(l_p0).mode_p;
        prism_rtl::is<crate::syntax::lexer::Mode::MBrace>(_m) && ({
        auto&& m7910_0_0 = prism_rtl::as<crate::syntax::lexer::Mode::MBrace>(_m).a0;
        (m7910_0_0 == Text::lit("double"));
    }) ? ({
        auto&& m7910_0_0 = prism_rtl::as<crate::syntax::lexer::Mode::MBrace>(_m).a0;
        ({
        auto l_p0x = l_p0;
        (crate::prelude::call_then(crate::syntax::lexer::chars::start_rest_of_line_f(l_p0x), [=](Text rest_of_line_f_7955) { return prism_rtl::finished(crate::syntax::lexer::chars::trim_end_f(rest_of_line_f_7955) == Text::lit("}}")); }));
    });
    })
        : prism_rtl::is<crate::syntax::lexer::Mode::MBrace>(_m) ? ({
        auto l_p0x = l_p0;
        (crate::prelude::call_then(crate::syntax::lexer::chars::start_rest_of_line_f(l_p0x), [=](Text rest_of_line_f_8009) { return prism_rtl::finished(crate::syntax::lexer::chars::trim_end_f(rest_of_line_f_8009) == Text::lit("}")); }));
    })
        : prism_rtl::finished(false);
    });
}


/// `Start ClosesBraceBlock, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_closes_brace_block_f(crate::syntax::lexer::Lex l_p0) {
    return prism_rtl::make_rc<ClosesBraceBlock>(l_p0);
}


/// SkipLine: unbounded fn Lex -> Lex
crate::syntax::lexer::Lex skip_line_f(const crate::syntax::lexer::Lex& l0_p0) {
    auto l_p1 = ({
        crate::syntax::lexer::Lex this_ = l0_p0;
        this_.pos_p = crate::syntax::lexer::chars::line_end_f(this_);
        (std::move(this_));
    });
    return crate::syntax::lexer::chars::peek_f(l_p1) == Text::lit("\n")
        ? crate::syntax::lexer::chars::bump_f(l_p1)
        : l_p1;
}


prism_rtl::Turn<crate::syntax::lexer::Lex> SkipLine::cycle() const {
    const auto& l0_p0 = this->l0_p0;
    auto l_p1 = ({
        crate::syntax::lexer::Lex this_ = l0_p0;
        this_.pos_p = crate::syntax::lexer::chars::line_end_f(this_);
        (std::move(this_));
    });
    return crate::syntax::lexer::chars::peek_f(l_p1) == Text::lit("\n")
        ? prism_rtl::finished(crate::syntax::lexer::chars::bump_f(l_p1))
        : prism_rtl::finished(l_p1);
}


/// `Start SkipLine, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_skip_line_f(crate::syntax::lexer::Lex l0_p0) {
    return prism_rtl::make_rc<SkipLine>(l0_p0);
}


/// IndentedLine: unbounded fn Lex, Nat, Nat -> Lex
crate::syntax::lexer::Lex indented_line_f(const crate::syntax::lexer::Lex& l0_p0, const Nat& col_p1, const Nat& line_begin_p2) {
    auto here_p3 = l0_p0.pos_p;
    auto l_p4 = ({
        crate::syntax::lexer::Lex this_ = l0_p0;
        this_.line_first_p = crate::prelude::len(this_.tokens_p);
        this_.last_ws_p = true;
        (std::move(this_));
    });
    return prism_rtl::deref(l_p4).first_line_p
        ? first_line_f(l_p4, col_p1, line_begin_p2, here_p3)
        : layout_line_f(l_p4, col_p1, line_begin_p2, here_p3);
}


prism_rtl::Turn<crate::syntax::lexer::Lex> IndentedLine::cycle() const {
    const auto& l0_p0 = this->l0_p0;
    const auto& col_p1 = this->col_p1;
    const auto& line_begin_p2 = this->line_begin_p2;
    auto here_p3 = prism_rtl::deref(l0_p0).pos_p;
    auto l_p4 = ({
        crate::syntax::lexer::Lex this_ = l0_p0;
        this_.line_first_p = crate::prelude::len(this_.tokens_p);
        this_.last_ws_p = true;
        (std::move(this_));
    });
    return prism_rtl::deref(l_p4).first_line_p
        ? prism_rtl::finished(first_line_f(l_p4, col_p1, line_begin_p2, here_p3))
        : prism_rtl::finished(layout_line_f(l_p4, col_p1, line_begin_p2, here_p3));
}


/// `Start IndentedLine, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::lexer::Lex> start_indented_line_f(crate::syntax::lexer::Lex l0_p0, Nat col_p1, Nat line_begin_p2) {
    return prism_rtl::make_rc<IndentedLine>(l0_p0, col_p1, line_begin_p2);
}


/// FirstLine: fn Lex, Nat, Nat, Nat -> Lex
crate::syntax::lexer::Lex first_line_f(const crate::syntax::lexer::Lex& l0_p0, const Nat& col_p1, const Nat& line_begin_p2, const Nat& here_p3) {
    crate::syntax::lexer::Lex this_ = l0_p0;
    this_.first_line_p = false;
    if (this_.mode_p == crate::syntax::lexer::Mode(crate::syntax::lexer::Mode::MFile{})) {
        this_.layout_p = Array(std::vector{Nat(0u)});
        if (col_p1 != Nat(0u)) {
            this_ = crate::syntax::lexer::chars::lex_err_f(this_, line_begin_p2, here_p3, Text::lit("the first line of a file starts at column 0"));
            this_.layout_p = Array(std::vector{col_p1});
        }
    } else  {
        this_.layout_p = crate::prelude::push(this_.layout_p, col_p1);
    }
    return this_;
}


/// Below: fn ?Nat, Nat -> Bool
bool below_f(const std::optional<Nat>& opt0, const Nat& n1) {
    auto&& _m = std::tuple{opt0, n1};
    if (prism_rtl::is_none(std::get<0>(_m))) {
        return false;
    }
    if (prism_rtl::is_some(std::get<0>(_m))) {
        auto&& d_p0 = prism_rtl::some_of(std::get<0>(_m));
        auto&& depth_p1 = std::get<1>(_m);
        return depth_p1 < d_p0;
    }
    prism_rtl::unreachable("no arm matched");
}


/// LayoutLine: fn Lex, Nat, Nat, Nat -> Lex
crate::syntax::lexer::Lex layout_line_f(const crate::syntax::lexer::Lex& l0_p0, const Nat& col_p1, const Nat& line_begin_p2, const Nat& here_p3) {
    crate::syntax::lexer::Lex this_ = l0_p0;
    auto top_p4 = crate::prelude::or_(crate::syntax::lexer::chars::last_o(this_.layout_p), Nat(0u));
    auto fat_p5 = crate::syntax::lexer::chars::starts_with_f(this_, Text::lit("=>"));
    bool opened_p6 = false;
    Nat fuel_p7 = crate::prelude::len(this_.layout_p);
    if (this_.pending_open_p) {
        this_.pending_open_p = false;
        if (col_p1 > top_p4) {
            this_.layout_p = crate::prelude::push(this_.layout_p, col_p1);
            this_ = crate::syntax::lexer::push_tok_f(this_, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KLayOpen{}), here_p3, here_p3);
            if (this_.test_pending_p == Text::lit("test")) {
                this_.test_depth_o = std::optional(crate::prelude::len(this_.layout_p));
            }
            if (this_.test_pending_p == Text::lit("check")) {
                this_.check_depth_o = std::optional(crate::prelude::len(this_.layout_p));
            }
            this_.test_pending_p = Text::lit("");
            opened_p6 = true;
        } else  {
            this_.diags_p = crate::prelude::push(this_.diags_p, crate::syntax::lexer::chars::lex_diag_f(this_.pending_span_p, Text::lit("expected an indented block after `:`")));
        }
    }
    if (!std::move(opened_p6)) {
        if (((col_p1 > top_p4) && std::move(fat_p5)) && (this_.test_depth_o == std::optional(crate::prelude::len(this_.layout_p)))) {
            this_.layout_p = crate::prelude::push(this_.layout_p, col_p1);
            this_ = crate::syntax::lexer::push_tok_f(this_, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KLayOpen{}), here_p3, here_p3);
        } else if (col_p1 == top_p4) {
            this_ = crate::syntax::lexer::push_tok_f(this_, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KLaySep{}), here_p3, here_p3);
            if (crate::prelude::len(this_.layout_p) == Nat(1u)) {
                this_.test_pending_p = Text::lit("");
            }
        } else if (col_p1 > top_p4) {
            this_.mark_line_start_p = true;
        } else  {
            while (true) {
                auto&& _m = fuel_p7.checked_sub(Nat(1u));
                if (!(prism_rtl::is_some(_m))) break;
                auto&& left_p8 = prism_rtl::some_of(_m);
                if (!((crate::prelude::len(this_.layout_p) > Nat(1u)) && (col_p1 < crate::prelude::or_(crate::syntax::lexer::chars::last_o(this_.layout_p), Nat(0u))))) {
                    break;
                }
                fuel_p7 = left_p8;
                this_.layout_p = crate::syntax::lexer::chars::pop_f(this_.layout_p);
                this_ = crate::syntax::lexer::push_tok_f(this_, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KLayClose{}), here_p3, here_p3);
                auto depth_p9 = crate::prelude::len(this_.layout_p);
                if (below_f(this_.test_depth_o, depth_p9)) {
                    this_.test_depth_o = std::optional<Nat>{};
                }
                if (below_f(this_.check_depth_o, depth_p9)) {
                    this_.check_depth_o = std::optional<Nat>{};
                }
            }
            if (col_p1 != crate::prelude::or_(crate::syntax::lexer::chars::last_o(this_.layout_p), Nat(0u))) {
                this_ = crate::syntax::lexer::chars::lex_err_f(this_, line_begin_p2, here_p3, Text::lit("unindent does not match any open block"));
            }
            this_ = crate::syntax::lexer::push_tok_f(this_, crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KLaySep{}), here_p3, here_p3);
            if (crate::prelude::len(this_.layout_p) == Nat(1u)) {
                this_.test_pending_p = Text::lit("");
            }
        }
    }
    return this_;
}

}  // namespace crate::syntax::lexer::layout
