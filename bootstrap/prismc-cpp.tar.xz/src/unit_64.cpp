// The modules `Syntax.Parser`, `Syntax.Parser.Blocks`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <syntax/parser/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Syntax.Parser`, from `target/bootstrap/cpp-src/prismc/syntax/parser/mod.prism`.
namespace crate::syntax::parser {

void Pair::show(Printer& p) const {
    p.record("Pair", {{"partner", partner}, {"outer", outer}, {"inner", inner}});
}

Pod Pair::to_pod() const {
    return Pod::record("Pair", {{"partner", prism_rtl::to_pod(partner)}, {"outer", prism_rtl::to_pod(outer)}, {"inner", prism_rtl::to_pod(inner)}});
}

Result<Pair> Pair::from_pod(const Pod& whole) {
    return Pair{.partner = TRY(prism_rtl::from_pod<std::optional<Nat>>(TRY(crate::prelude::field(whole, "partner")))), .outer = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "outer")))), .inner = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "inner"))))};
}


bool Parsed::operator==(const Parsed& o) const { return tree == o.tree && diags == o.diags; }

void Parsed::show(Printer& p) const {
    p.record("Parsed", {{"tree", tree}, {"diags", diags}});
}

Pod Parsed::to_pod() const {
    return Pod::record("Parsed", {{"tree", prism_rtl::to_pod(tree)}, {"diags", prism_rtl::to_pod(diags)}});
}

Result<Parsed> Parsed::from_pod(const Pod& whole) {
    return Parsed{.tree = TRY(prism_rtl::from_pod<crate::syntax::Module>(TRY(crate::prelude::field(whole, "tree")))), .diags = TRY(prism_rtl::from_pod<Array<crate::syntax::Diag>>(TRY(crate::prelude::field(whole, "diags"))))};
}


bool Ps::operator==(const Ps& o) const { return toks == o.toks && pairs == o.pairs && pos == o.pos && diags == o.diags && out == o.out && step_mode == o.step_mode && in_trait == o.in_trait && bad == o.bad; }

void Ps::show(Printer& p) const {
    p.record("Ps", {{"toks", toks}, {"pairs", pairs}, {"pos", pos}, {"diags", diags}, {"out", out}, {"step_mode", step_mode}, {"in_trait", in_trait}, {"bad", bad}});
}

Pod Ps::to_pod() const {
    return Pod::record("Ps", {{"toks", prism_rtl::to_pod(toks)}, {"pairs", prism_rtl::to_pod(pairs)}, {"pos", prism_rtl::to_pod(pos)}, {"diags", prism_rtl::to_pod(diags)}, {"out", prism_rtl::to_pod(out)}, {"step_mode", prism_rtl::to_pod(step_mode)}, {"in_trait", prism_rtl::to_pod(in_trait)}, {"bad", prism_rtl::to_pod(bad)}});
}

Result<Ps> Ps::from_pod(const Pod& whole) {
    return Ps{.toks = TRY(prism_rtl::from_pod<Array<crate::syntax::lexer::Tok>>(TRY(crate::prelude::field(whole, "toks")))), .pairs = TRY(prism_rtl::from_pod<Array<Pair>>(TRY(crate::prelude::field(whole, "pairs")))), .pos = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "pos")))), .diags = TRY(prism_rtl::from_pod<Array<crate::syntax::Diag>>(TRY(crate::prelude::field(whole, "diags")))), .out = TRY(prism_rtl::from_pod<Array<crate::syntax::Diag>>(TRY(crate::prelude::field(whole, "out")))), .step_mode = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "step_mode")))), .in_trait = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "in_trait")))), .bad = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "bad"))))};
}


/// let noRange
crate::syntax::Range no_range() {
    return crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)};
}


/// let eofTok
crate::syntax::lexer::Tok eof_tok() {
    return crate::syntax::lexer::Tok{.kind = crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KEof{}), .span = no_range(), .touches = false, .line_start = false};
}


/// let noPair
Pair no_pair() {
    return Pair{.partner = std::optional<Nat>{}, .outer = false, .inner = false};
}


/// ParseFile: unbounded fn Text -> Parsed
Parsed parse_file(const Text& src_p0) {
    auto lexed_p1 = crate::syntax::lexer::layout::lex_file(src_p0);
    auto [m_p2, p_p3] = crate::syntax::parser::decls::parse_module(new_ps(lexed_p1->tokens), false);
    return Parsed{.tree = m_p2, .diags = finish_diags(append(append(prism_rtl::deref(lexed_p1).diags, prism_rtl::deref(p_p3).diags), p_p3->out))};
}


prism_rtl::Turn<Parsed> ParseFile::cycle() const {
    const auto& src_p0 = this->src_p0;
    auto src_p0_1 = src_p0;
    return call_then(crate::syntax::lexer::layout::start_lex_file(src_p0_1), [=](crate::syntax::lexer::Lexed lex_file_3387) {
        return ({
            auto lexed_p1 = lex_file_3387;
            call_then(start_new_ps(lexed_p1->tokens), [=](Ps new_ps_3431) {
            return call_then(crate::syntax::parser::decls::start_parse_module(new_ps_3431, false), [=](std::tuple<crate::syntax::Module, Ps> parse_module_3418) {
                return ({
                    auto [m_p2, p_p3] = parse_module_3418;
                    (prism_rtl::finished(Parsed{.tree = m_p2, .diags = finish_diags(append(append(prism_rtl::deref(lexed_p1).diags, prism_rtl::deref(p_p3).diags), p_p3->out))}));
                });
            });
        });
        });
    });
}


/// `Start ParseFile, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Parsed> start_parse_file(Text src_p0) {
    return prism_rtl::make_rc<ParseFile>(src_p0);
}


/// ParseFragment: unbounded fn Text -> Parsed
Parsed parse_fragment(const Text& src_p0) {
    auto lexed_p1 = crate::syntax::lexer::layout::lex_file(src_p0);
    auto [m_p2, p_p3] = crate::syntax::parser::decls::parse_module(new_ps(lexed_p1->tokens), true);
    return Parsed{.tree = m_p2, .diags = finish_diags(append(append(prism_rtl::deref(lexed_p1).diags, prism_rtl::deref(p_p3).diags), p_p3->out))};
}


prism_rtl::Turn<Parsed> ParseFragment::cycle() const {
    const auto& src_p0 = this->src_p0;
    auto src_p0_1 = src_p0;
    return call_then(crate::syntax::lexer::layout::start_lex_file(src_p0_1), [=](crate::syntax::lexer::Lexed lex_file_3780) {
        return ({
            auto lexed_p1 = lex_file_3780;
            call_then(start_new_ps(lexed_p1->tokens), [=](Ps new_ps_3824) {
            return call_then(crate::syntax::parser::decls::start_parse_module(new_ps_3824, true), [=](std::tuple<crate::syntax::Module, Ps> parse_module_3811) {
                return ({
                    auto [m_p2, p_p3] = parse_module_3811;
                    (prism_rtl::finished(Parsed{.tree = m_p2, .diags = finish_diags(append(append(prism_rtl::deref(lexed_p1).diags, prism_rtl::deref(p_p3).diags), p_p3->out))}));
                });
            });
        });
        });
    });
}


/// `Start ParseFragment, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Parsed> start_parse_fragment(Text src_p0) {
    return prism_rtl::make_rc<ParseFragment>(src_p0);
}


/// NewPs: unbounded fn [Tok] -> Ps
Ps new_ps(const Array<crate::syntax::lexer::Tok>& toks0_p0) {
    auto ends_p1 = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = crate::syntax::lexer::chars::last(toks0_p0);
        if (prism_rtl::is_some(_m)) {
            auto&& t_p4 = prism_rtl::some_of(_m);
            _v.set(prism_rtl::deref(t_p4).kind == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KEof{}));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(false);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto end_p2 = ({
        __label__ _done;
        prism_rtl::Slot<crate::syntax::Range> _v;
        auto&& _m = crate::syntax::lexer::chars::last(toks0_p0);
        if (prism_rtl::is_some(_m)) {
            auto&& t_p5 = prism_rtl::some_of(_m);
            _v.set(crate::syntax::Range{.start = prism_rtl::deref(prism_rtl::deref(t_p5).span).end, .end = prism_rtl::deref(prism_rtl::deref(t_p5).span).end});
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(no_range());
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto toks_p3 = std::move(ends_p1)
        ? toks0_p0
        : crate::prelude::push(toks0_p0, crate::syntax::lexer::Tok{.kind = crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KEof{}), .span = end_p2, .touches = false, .line_start = false});
    return Ps{.toks = toks_p3, .pairs = pair_brackets(toks_p3), .pos = Nat(0u), .diags = Array<crate::syntax::Diag>{}, .out = Array<crate::syntax::Diag>{}, .step_mode = false, .in_trait = false, .bad = false};
}


prism_rtl::Turn<Ps> NewPs::cycle() const {
    const auto& toks0_p0 = this->toks0_p0;
    auto ends_p1 = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = crate::syntax::lexer::chars::last(toks0_p0);
        if (prism_rtl::is_some(_m)) {
            auto&& t_p4 = prism_rtl::some_of(_m);
            _v.set(prism_rtl::deref(t_p4).kind == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KEof{}));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(false);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto end_p2 = ({
        __label__ _done;
        prism_rtl::Slot<crate::syntax::Range> _v;
        auto&& _m = crate::syntax::lexer::chars::last(toks0_p0);
        if (prism_rtl::is_some(_m)) {
            auto&& t_p5 = prism_rtl::some_of(_m);
            _v.set(crate::syntax::Range{.start = prism_rtl::deref(prism_rtl::deref(t_p5).span).end, .end = prism_rtl::deref(prism_rtl::deref(t_p5).span).end});
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(no_range());
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto toks_p3 = std::move(ends_p1)
        ? toks0_p0
        : crate::prelude::push(toks0_p0, crate::syntax::lexer::Tok{.kind = crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KEof{}), .span = end_p2, .touches = false, .line_start = false});
    return call_then(start_pair_brackets(toks_p3), [=](Array<Pair> pair_brackets_4303) { return prism_rtl::finished(Ps{.toks = toks_p3, .pairs = pair_brackets_4303, .pos = Nat(0u), .diags = Array<crate::syntax::Diag>{}, .out = Array<crate::syntax::Diag>{}, .step_mode = false, .in_trait = false, .bad = false}); });
}


/// `Start NewPs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Ps> start_new_ps(Array<crate::syntax::lexer::Tok> toks0_p0) {
    return prism_rtl::make_rc<NewPs>(toks0_p0);
}


/// Sub: unbounded fn Ps, [Tok], Range -> Ps
Ps sub(const Ps& p_p0, const Array<crate::syntax::lexer::Tok>& toks_p1, const crate::syntax::Range& end_p2) {
    auto q_p3 = new_ps(crate::prelude::push(toks_p1, crate::syntax::lexer::Tok{.kind = crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KEof{}), .span = end_p2, .touches = false, .line_start = false}));
    Ps this_ = q_p3;
    this_.step_mode = p_p0.step_mode;
    return this_;
}


prism_rtl::Turn<Ps> Sub::cycle() const {
    const auto& p_p0 = this->p_p0;
    const auto& toks_p1 = this->toks_p1;
    const auto& end_p2 = this->end_p2;
    auto end_p2_1 = end_p2;
    auto p_p0_2 = p_p0;
    auto toks_p1_3 = toks_p1;
    return call_then(start_new_ps(crate::prelude::push(toks_p1_3, crate::syntax::lexer::Tok{.kind = crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KEof{}), .span = end_p2_1, .touches = false, .line_start = false})), [=](Ps new_ps_4612) {
        return ({
            auto q_p3 = new_ps_4612;
            (prism_rtl::finished(({
            Ps this_ = q_p3;
            this_.step_mode = prism_rtl::deref(p_p0_2).step_mode;
            (std::move(this_));
        })));
        });
    });
}


/// `Start Sub, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Ps> start_sub(Ps p_p0, Array<crate::syntax::lexer::Tok> toks_p1, crate::syntax::Range end_p2) {
    return prism_rtl::make_rc<Sub>(p_p0, toks_p1, end_p2);
}


/// Absorb: fn Ps, Ps -> Ps
Ps absorb(const Ps& p_p0, const Ps& sub_p1) {
    Ps this_ = p_p0;
    this_.diags = append(this_.diags, sub_p1.diags);
    this_.out = append(this_.out, sub_p1.out);
    return this_;
}


/// FinishDiags: fn [Diag] -> [Diag]
Array<crate::syntax::Diag> finish_diags(const Array<crate::syntax::Diag>& ds_p0) {
    auto sorted_p1 = fold(ds_p0, Array<crate::syntax::Diag>{}, insert_diag);
    return fold(sorted_p1, Array<crate::syntax::Diag>{}, [&](const Array<crate::syntax::Diag>& acc_p2, const crate::syntax::Diag& d_p3) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::syntax::Diag>> _v;
            auto&& _m = crate::syntax::lexer::chars::last(acc_p2);
            if (prism_rtl::is_some(_m)) {
                auto&& e_p4 = prism_rtl::some_of(_m);
                if ((prism_rtl::deref(e_p4).span == prism_rtl::deref(d_p3).span) && (prism_rtl::deref(e_p4).message == prism_rtl::deref(d_p3).message)) {
                    _v.set(acc_p2);
                    goto _done;
                }
            }
            {
                _v.set(crate::prelude::push(acc_p2, d_p3));
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


/// StageRank: fn Text -> Nat
Nat stage_rank(const Text& text0) {
    {
        auto&& c0_0 = text0;
        if (c0_0 == Text::lit("lex")) {
            return Nat(0u);
        }
    }
    {
        auto&& c1_0 = text0;
        if (c1_0 == Text::lit("parse")) {
            return Nat(1u);
        }
    }
    {
        return Nat(2u);
    }
}


/// DiagBefore: fn Diag, Diag -> Bool
bool diag_before(const crate::syntax::Diag& a_p0, const crate::syntax::Diag& b_p1) {
    return (prism_rtl::deref(a_p0.span).start < prism_rtl::deref(b_p1.span).start) || ((prism_rtl::deref(a_p0.span).start == prism_rtl::deref(b_p1.span).start) && (stage_rank(a_p0.stage) < stage_rank(b_p1.stage)));
}


/// InsertDiag: fn [Diag], Diag -> [Diag]
Array<crate::syntax::Diag> insert_diag(const Array<crate::syntax::Diag>& sorted_p0, const crate::syntax::Diag& d_p1) {
    auto before_p2 = fold(sorted_p0, Array<crate::syntax::Diag>{}, [&](const Array<crate::syntax::Diag>& acc_p4, const crate::syntax::Diag& e_p5) { return diag_before(d_p1, e_p5) ? acc_p4 : crate::prelude::push(acc_p4, e_p5); });
    auto after_p3 = fold(sorted_p0, Array<crate::syntax::Diag>{}, [&](const Array<crate::syntax::Diag>& acc_p6, const crate::syntax::Diag& e_p7) { return diag_before(d_p1, e_p7) ? crate::prelude::push(acc_p6, e_p7) : acc_p6; });
    return append(crate::prelude::push(before_p2, d_p1), after_p3);
}


/// PairBrackets: unbounded fn [Tok] -> [Pair]
Array<Pair> pair_brackets(const Array<crate::syntax::lexer::Tok>& toks_p0) {
    Array<Pair> this_ = each(toks_p0, [&](const crate::syntax::lexer::Tok& t_p1) { return no_pair(); });
    Array<std::tuple<Nat, Text>> stack_p2 = Array<std::tuple<Nat, Text>>{};
    for (auto&& [i6364, v6364] : prism_rtl::enumerate(toks_p0)) {
        auto k6364 = nat_of(i6364);
        auto t_p3 = v6364;
        if (auto&& _m = open_kind_of(prism_rtl::deref(t_p3).kind); prism_rtl::is_some(_m)) {
            auto&& k_p4 = prism_rtl::some_of(_m);
            stack_p2 = crate::prelude::push(stack_p2, std::tuple{k6364, k_p4});
        }
        if (auto&& _m = close_kind_of(prism_rtl::deref(t_p3).kind); prism_rtl::is_some(_m)) {
            auto&& k_p5 = prism_rtl::some_of(_m);
            if (auto&& _m = crate::syntax::lexer::chars::last(stack_p2); prism_rtl::is_some(_m)) {
                auto&& j_p6 = std::get<0>(prism_rtl::some_of(_m));
                auto&& k2_p7 = std::get<1>(prism_rtl::some_of(_m));
                if (k2_p7 == k_p5) {
                    stack_p2 = crate::syntax::lexer::chars::pop(stack_p2);
                    prism_rtl::deref(prism_rtl::deref(at_mut(this_, k6364))).partner = std::optional(j_p6);
                    prism_rtl::deref(prism_rtl::deref(at_mut(this_, j_p6))).partner = std::optional(k6364);
                }
            }
        }
    }
    for (auto&& [i6825, v6825] : prism_rtl::enumerate(toks_p0)) {
        auto k6825 = nat_of(i6825);
        auto t_p8 = v6825;
        auto i_p9 = k6825;
        if (auto&& _m = open_kind_of(prism_rtl::deref(t_p8).kind); prism_rtl::is_some(_m)) {
            auto&& kind_pa = prism_rtl::some_of(_m);
            if ((kind_pa != Text::lit("{")) && (!prism_rtl::deref(or_(index(this_, i_p9), no_pair())).inner)) {
                if (auto&& _m = prism_rtl::deref(or_(index(this_, i_p9), no_pair())).partner; prism_rtl::is_some(_m)) {
                    auto&& j_pb = prism_rtl::some_of(_m);
                    if (double_at(this_, toks_p0, i_p9, j_pb, kind_pa)) {
                        prism_rtl::deref(prism_rtl::deref(at_mut(this_, i_p9))).outer = true;
                        prism_rtl::deref(prism_rtl::deref(at_mut(this_, j_pb))).outer = true;
                        prism_rtl::deref(prism_rtl::deref(at_mut(this_, i_p9 + Nat(1u)))).inner = true;
                        prism_rtl::deref(prism_rtl::deref(at_mut(this_, crate::syntax::lexer::chars::dec(j_pb)))).inner = true;
                    }
                }
            }
        }
    }
    return this_;
}


prism_rtl::Turn<Array<Pair>> PairBrackets::cycle() const {
    const auto& toks_p0 = this->toks_p0;
    return prism_rtl::finished(({
        Array<Pair> this_ = each(toks_p0, [&](const crate::syntax::lexer::Tok& t_p1) { return no_pair(); });
        Array<std::tuple<Nat, Text>> stack_p2 = Array<std::tuple<Nat, Text>>{};
        for (auto&& [i6364, v6364] : prism_rtl::enumerate(toks_p0)) {
            auto k6364 = nat_of(i6364);
            auto t_p3 = v6364;
            if (auto&& _m = open_kind_of(prism_rtl::deref(t_p3).kind); prism_rtl::is_some(_m)) {
                auto&& k_p4 = prism_rtl::some_of(_m);
                stack_p2 = crate::prelude::push(stack_p2, std::tuple{k6364, k_p4});
            }
            if (auto&& _m = close_kind_of(prism_rtl::deref(t_p3).kind); prism_rtl::is_some(_m)) {
                auto&& k_p5 = prism_rtl::some_of(_m);
                if (auto&& _m = crate::syntax::lexer::chars::last(stack_p2); prism_rtl::is_some(_m)) {
                    auto&& j_p6 = std::get<0>(prism_rtl::some_of(_m));
                    auto&& k2_p7 = std::get<1>(prism_rtl::some_of(_m));
                    if (k2_p7 == k_p5) {
                        stack_p2 = crate::syntax::lexer::chars::pop(stack_p2);
                        prism_rtl::deref(prism_rtl::deref(at_mut(this_, k6364))).partner = std::optional(j_p6);
                        prism_rtl::deref(prism_rtl::deref(at_mut(this_, j_p6))).partner = std::optional(k6364);
                    }
                }
            }
        }
        for (auto&& [i6825, v6825] : prism_rtl::enumerate(toks_p0)) {
            auto k6825 = nat_of(i6825);
            auto t_p8 = v6825;
            auto i_p9 = k6825;
            if (auto&& _m = open_kind_of(prism_rtl::deref(t_p8).kind); prism_rtl::is_some(_m)) {
                auto&& kind_pa = prism_rtl::some_of(_m);
                if ((kind_pa != Text::lit("{")) && (!prism_rtl::deref(or_(index(this_, i_p9), no_pair())).inner)) {
                    if (auto&& _m = prism_rtl::deref(or_(index(this_, i_p9), no_pair())).partner; prism_rtl::is_some(_m)) {
                        auto&& j_pb = prism_rtl::some_of(_m);
                        if (double_at(this_, toks_p0, i_p9, j_pb, kind_pa)) {
                            prism_rtl::deref(prism_rtl::deref(at_mut(this_, i_p9))).outer = true;
                            prism_rtl::deref(prism_rtl::deref(at_mut(this_, j_pb))).outer = true;
                            prism_rtl::deref(prism_rtl::deref(at_mut(this_, i_p9 + Nat(1u)))).inner = true;
                            prism_rtl::deref(prism_rtl::deref(at_mut(this_, crate::syntax::lexer::chars::dec(j_pb)))).inner = true;
                        }
                    }
                }
            }
        }
        (std::move(this_));
    }));
}


/// `Start PairBrackets, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Pair>> start_pair_brackets(Array<crate::syntax::lexer::Tok> toks_p0) {
    return prism_rtl::make_rc<PairBrackets>(toks_p0);
}


/// DoubleAt: fn [Pair], [Tok], Nat, Nat, Text -> Bool
bool double_at(const Array<Pair>& pairs_p0, const Array<crate::syntax::lexer::Tok>& toks_p1, const Nat& i_p2, const Nat& j_p3, const Text& kind_p4) {
    auto next_p5 = or_(index(toks_p1, i_p2 + Nat(1u)), eof_tok());
    auto inner_close_o6 = prism_rtl::deref(or_(index(pairs_p0, i_p2 + Nat(1u)), no_pair())).partner;
    return ((is_open_of(prism_rtl::deref(next_p5).kind, kind_p4) && prism_rtl::deref(next_p5).touches) && (inner_close_o6 == std::optional(crate::syntax::lexer::chars::dec(j_p3)))) && prism_rtl::deref(or_(index(toks_p1, j_p3), eof_tok())).touches;
}


/// ?OpenKindOf: fn TokKind -> ?Text
std::optional<Text> open_kind_of(const crate::syntax::lexer::TokKind& tok_kind0) {
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KOpen>(tok_kind0)) {
        auto&& k_p0 = prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(tok_kind0).a0;
        return std::optional(k_p0);
    }
    {
        return std::optional<Text>{};
    }
}


/// ?CloseKindOf: fn TokKind -> ?Text
std::optional<Text> close_kind_of(const crate::syntax::lexer::TokKind& tok_kind0) {
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KClose>(tok_kind0)) {
        auto&& k_p0 = prism_rtl::as<crate::syntax::lexer::TokKind::KClose>(tok_kind0).a0;
        return std::optional(k_p0);
    }
    {
        return std::optional<Text>{};
    }
}


/// IsOpenOf: fn TokKind, Text -> Bool
bool is_open_of(const crate::syntax::lexer::TokKind& tok_kind0, const Text& text1) {
    auto&& _m = std::tuple{tok_kind0, text1};
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KOpen>(std::get<0>(_m))) {
        auto&& k_p0 = prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(std::get<0>(_m)).a0;
        auto&& kind_p1 = std::get<1>(_m);
        return k_p0 == kind_p1;
    }
    {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// Tk: fn Ps -> Tok
crate::syntax::lexer::Tok tk(const Ps& p_p0) {
    return p_p0.bad
        ? eof_tok()
        : or_(index(p_p0.toks, crate::prelude::min(p_p0.pos, crate::syntax::lexer::chars::dec(len(p_p0.toks)))), eof_tok());
}


/// TkAt: fn Ps, Nat -> Tok
crate::syntax::lexer::Tok tk_at(const Ps& p_p0, const Nat& n_p1) {
    return p_p0.bad
        ? eof_tok()
        : or_(index(p_p0.toks, crate::prelude::min(p_p0.pos + n_p1, crate::syntax::lexer::chars::dec(len(p_p0.toks)))), eof_tok());
}


/// Kind: fn Ps -> TokKind
crate::syntax::lexer::TokKind kind(const Ps& p_p0) {
    return prism_rtl::deref(tk(p_p0)).kind;
}


/// KindAt: fn Ps, Nat -> TokKind
crate::syntax::lexer::TokKind kind_at(const Ps& p_p0, const Nat& n_p1) {
    return prism_rtl::deref(tk_at(p_p0, n_p1)).kind;
}


/// Here: fn Ps -> Range
crate::syntax::Range here(const Ps& p_p0) {
    return prism_rtl::deref(tk(p_p0)).span;
}


/// Prev: fn Ps -> Range
crate::syntax::Range prev(const Ps& p_p0) {
    return prism_rtl::deref(or_(index(p_p0.toks, crate::syntax::lexer::chars::dec(p_p0.pos)), eof_tok())).span;
}


/// To: fn Range, Range -> Range
crate::syntax::Range to(const crate::syntax::Range& a_p0, const crate::syntax::Range& b_p1) {
    return crate::syntax::Range{.start = crate::prelude::min(a_p0.start, b_p1.start), .end = crate::prelude::max(a_p0.end, b_p1.end)};
}


/// AtEnd: fn Range -> Range
crate::syntax::Range at_end(const crate::syntax::Range& r_p0) {
    return crate::syntax::Range{.start = r_p0.end, .end = r_p0.end};
}


/// Adv: fn Ps -> Ps
Ps adv(const Ps& p_p0) {
    return p_p0.bad || ((p_p0.pos + Nat(1u)) >= len(p_p0.toks))
        ? p_p0
        : ({
        Ps this_ = p_p0;
        this_.pos = this_.pos + Nat(1u);
        (std::move(this_));
    });
}


/// PairAt: fn Ps -> Pair
Pair pair_at(const Ps& p_p0) {
    return or_(index(p_p0.pairs, crate::prelude::min(p_p0.pos, crate::syntax::lexer::chars::dec(len(p_p0.pairs)))), no_pair());
}


/// AtEof: fn Ps -> Bool
bool at_eof(const Ps& p_p0) {
    return kind(p_p0) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KEof{});
}


/// AtKw: fn Ps, Text -> Bool
bool at_kw(const Ps& p_p0, const Text& w_p1) {
    return kind(p_p0) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KKw{w_p1, Text::lit("")});
}


/// AtOp: fn Ps, Text -> Bool
bool at_op(const Ps& p_p0, const Text& op_p1) {
    auto&& _m = kind(p_p0);
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KOp>(_m)) {
        auto&& o_p2 = prism_rtl::as<crate::syntax::lexer::TokKind::KOp>(_m).a0;
        return o_p2 == op_p1;
    }
    {
        return false;
    }
}


/// AtSep: fn Ps -> Bool
bool at_sep(const Ps& p_p0) {
    return kind(p_p0) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KLaySep{});
}


/// AtOpenL: fn Ps -> Bool
bool at_open_l(const Ps& p_p0) {
    return kind(p_p0) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KLayOpen{});
}


/// AtCloseL: fn Ps -> Bool
bool at_close_l(const Ps& p_p0) {
    return kind(p_p0) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KLayClose{});
}


/// AtComma: fn Ps -> Bool
bool at_comma(const Ps& p_p0) {
    return kind(p_p0) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KComma{});
}


/// AtColon: fn Ps -> Bool
bool at_colon(const Ps& p_p0) {
    return kind(p_p0) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KColon{});
}


/// IsOpenKind: fn TokKind, Text -> Bool
bool is_open_kind(const crate::syntax::lexer::TokKind& tok_kind0, const Text& text1) {
    auto&& _m = std::tuple{tok_kind0, text1};
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KOpen>(std::get<0>(_m))) {
        auto&& k_p0 = prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(std::get<0>(_m)).a0;
        auto&& kind_p1 = std::get<1>(_m);
        return k_p0 == kind_p1;
    }
    {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// AtDoubleOpen: fn Ps, Text -> Bool
bool at_double_open(const Ps& p_p0, const Text& kind_p1) {
    return is_open_kind(kind(p_p0), kind_p1) && prism_rtl::deref(pair_at(p_p0)).outer;
}


/// AtSingleOpen: fn Ps, Text -> Bool
bool at_single_open(const Ps& p_p0, const Text& kind_p1) {
    return is_open_kind(kind(p_p0), kind_p1) && (!prism_rtl::deref(pair_at(p_p0)).outer);
}


/// AtClose: fn Ps, Text -> Bool
bool at_close(const Ps& p_p0, const Text& kind_p1) {
    return kind(p_p0) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KClose{kind_p1});
}


/// OpenDouble: fn Ps -> Ps
Ps open_double(const Ps& p_p0) {
    return adv(adv(p_p0));
}


/// CloseDouble: fn Ps, Text -> Ps
Ps close_double(const Ps& p_p0, const Text& kind_p1) {
    auto c_p2 = crate::syntax::lexer::close_char(kind_p1);
    auto p1_p3 = adv(p_p0);
    return ((at_close(p_p0, kind_p1) && prism_rtl::deref(pair_at(p_p0)).inner) && at_close(p1_p3, kind_p1)) && prism_rtl::deref(pair_at(p1_p3)).outer
        ? adv(p1_p3)
        : at_close(p_p0, kind_p1) && prism_rtl::deref(pair_at(p_p0)).inner
        ? error_here(p1_p3, prism_rtl::cat("expected `", c_p2, c_p2, "` to close the double bracket"))
        : error_here(p_p0, prism_rtl::cat("expected `", c_p2, c_p2, "` to close the double bracket"));
}


/// ExpectClose: fn Ps, Text -> Ps
Ps expect_close(const Ps& p_p0, const Text& kind_p1) {
    return at_close(p_p0, kind_p1)
        ? adv(p_p0)
        : error_here(p_p0, prism_rtl::cat("expected `", crate::syntax::lexer::close_char(kind_p1), "`"));
}


/// ParseDiag: fn Range, Text -> Diag
crate::syntax::Diag parse_diag(const crate::syntax::Range& span_p0, const Text& message_p1) {
    return crate::syntax::Diag{.stage = Text::lit("parse"), .span = span_p0, .message = message_p1, .feature = std::optional<Text>{}};
}


/// ErrorAt: fn Ps, Range, Text -> Ps
Ps error_at(const Ps& p_p0, const crate::syntax::Range& span_p1, const Text& message_p2) {
    return p_p0.bad
        ? p_p0
        : ({
        Ps this_ = p_p0;
        this_.diags = crate::prelude::push(this_.diags, parse_diag(span_p1, message_p2));
        this_.bad = true;
        (std::move(this_));
    });
}


/// ErrorHere: fn Ps, Text -> Ps
Ps error_here(const Ps& p_p0, const Text& message_p1) {
    return error_at(p_p0, here(p_p0), prism_rtl::cat(message_p1, ", found ", describe(kind(p_p0))));
}


/// Fail: fn Ps -> Ps
Ps fail(const Ps& p_p0) {
    Ps this_ = p_p0;
    this_.bad = true;
    return this_;
}


/// Unbad: fn Ps -> Ps
Ps unbad(const Ps& p_p0) {
    Ps this_ = p_p0;
    this_.bad = false;
    return this_;
}


/// NoteError: fn Ps, Range, Text -> Ps
Ps note_error(const Ps& p_p0, const crate::syntax::Range& span_p1, const Text& message_p2) {
    return p_p0.bad
        ? p_p0
        : ({
        Ps this_ = p_p0;
        this_.diags = crate::prelude::push(this_.diags, parse_diag(span_p1, message_p2));
        (std::move(this_));
    });
}


/// Complain: fn Ps, Text -> Ps
Ps complain(const Ps& p_p0, const Text& message_p1) {
    return unbad(error_here(p_p0, message_p1));
}


/// OutOfScope: fn Ps, Range, Text, Text -> Ps
Ps out_of_scope(const Ps& p_p0, const crate::syntax::Range& span_p1, const Text& feature_p2, const Text& message_p3) {
    return p_p0.bad
        ? p_p0
        : ({
        Ps this_ = p_p0;
        this_.out = crate::prelude::push(this_.out, crate::syntax::Diag{.stage = Text::lit("out"), .span = span_p1, .message = message_p3, .feature = std::optional(feature_p2)});
        (std::move(this_));
    });
}


/// ExpectColon: fn Ps -> Ps
Ps expect_colon(const Ps& p_p0) {
    return at_colon(p_p0) ? adv(p_p0) : error_here(p_p0, Text::lit("expected `:`"));
}


/// ExpectOp: fn Ps, Text -> Ps
Ps expect_op(const Ps& p_p0, const Text& op_p1) {
    return at_op(p_p0, op_p1)
        ? adv(p_p0)
        : error_here(p_p0, prism_rtl::cat("expected `", op_p1, "`"));
}


/// ExpectKw: fn Ps, Text -> Ps
Ps expect_kw(const Ps& p_p0, const Text& w_p1) {
    return at_kw(p_p0, w_p1)
        ? adv(p_p0)
        : error_here(p_p0, prism_rtl::cat("expected `", w_p1, "`"));
}


/// Recover: unbounded fn Ps -> Ps
Ps recover(const Ps& p0_p0) {
    Ps this_ = unbad(p0_p0);
    Nat depth_p1 = Nat(0u);
    bool going_p2 = true;
    while (std::move(going_p2)) {
        ({
            __label__ _done;
            prism_rtl::Slot<Unit> _v;
            auto&& _m = kind(this_);
            if (prism_rtl::is<crate::syntax::lexer::TokKind::KEof>(_m)) {
                _v.set(({
                    going_p2 = false;
                    Unit{};
                }));
                goto _done;
            }
            if (prism_rtl::is<crate::syntax::lexer::TokKind::KLayOpen>(_m)) {
                _v.set(({
                    depth_p1 = depth_p1 + Nat(1u);
                    this_ = adv(this_);
                    Unit{};
                }));
                goto _done;
            }
            if (prism_rtl::is<crate::syntax::lexer::TokKind::KLayClose>(_m)) {
                _v.set(({
                    if (depth_p1 == Nat(0u)) {
                        going_p2 = false;
                    } else  {
                        depth_p1 = crate::syntax::lexer::chars::dec(depth_p1);
                        this_ = adv(this_);
                    }
                    Unit{};
                }));
                goto _done;
            }
            if (prism_rtl::is<crate::syntax::lexer::TokKind::KLaySep>(_m)) {
                if (depth_p1 == Nat(0u)) {
                    _v.set(({
                        going_p2 = false;
                        Unit{};
                    }));
                    goto _done;
                }
            }
            {
                _v.set(({
                    this_ = adv(this_);
                    Unit{};
                }));
                goto _done;
            }
        _done:
            _v.take();
        });
    }
    return this_;
}


prism_rtl::Turn<Ps> Recover::cycle() const {
    const auto& p0_p0 = this->p0_p0;
    Ps this_ = unbad(p0_p0);
    Nat depth_p1 = Nat(0u);
    bool going_p2 = true;
    return call_then(loop_job(std::tuple{std::move(this_), std::move(depth_p1), std::move(going_p2)}, [=](std::tuple<Ps, Nat, bool> _p0) {
        auto this_ = std::get<0>(_p0);
        auto depth_p1 = std::get<1>(_p0);
        auto going_p2 = std::get<2>(_p0);
        return going_p2
            ? ({
            ({
                __label__ _done;
                prism_rtl::Slot<Unit> _v;
                auto&& _m = kind(this_);
                if (prism_rtl::is<crate::syntax::lexer::TokKind::KEof>(_m)) {
                    _v.set(({
                        going_p2 = false;
                        Unit{};
                    }));
                    goto _done;
                }
                if (prism_rtl::is<crate::syntax::lexer::TokKind::KLayOpen>(_m)) {
                    _v.set(({
                        depth_p1 = depth_p1 + Nat(1u);
                        this_ = adv(this_);
                        Unit{};
                    }));
                    goto _done;
                }
                if (prism_rtl::is<crate::syntax::lexer::TokKind::KLayClose>(_m)) {
                    _v.set(({
                        if (depth_p1 == Nat(0u)) {
                            going_p2 = false;
                        } else  {
                            depth_p1 = crate::syntax::lexer::chars::dec(depth_p1);
                            this_ = adv(this_);
                        }
                        Unit{};
                    }));
                    goto _done;
                }
                if (prism_rtl::is<crate::syntax::lexer::TokKind::KLaySep>(_m)) {
                    if (depth_p1 == Nat(0u)) {
                        _v.set(({
                            going_p2 = false;
                            Unit{};
                        }));
                        goto _done;
                    }
                }
                {
                    _v.set(({
                        this_ = adv(this_);
                        Unit{};
                    }));
                    goto _done;
                }
            _done:
                _v.take();
            });
            Expected<std::tuple<Ps, Nat, bool>, std::tuple<Ps, Nat, bool>>(std::tuple{this_, depth_p1, going_p2});
        })
            : Expected<std::tuple<Ps, Nat, bool>, std::tuple<Ps, Nat, bool>>(unexpected(std::tuple{this_, depth_p1, going_p2}));
    }), [=](std::tuple<Ps, Nat, bool> _p0) {
        auto this_ = std::get<0>(_p0);
        auto depth_p1 = std::get<1>(_p0);
        auto going_p2 = std::get<2>(_p0);
        return prism_rtl::finished(this_);
    });
}


/// `Start Recover, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Ps> start_recover(Ps p0_p0) {
    return prism_rtl::make_rc<Recover>(p0_p0);
}


/// Recovered: unbounded fn Ps -> Ps
Ps recovered(const Ps& p_p0) {
    return p_p0.bad ? recover(p_p0) : p_p0;
}


prism_rtl::Turn<Ps> Recovered::cycle() const {
    const auto& p_p0 = this->p_p0;
    return p_p0->bad
        ? prism_rtl::more(prism_rtl::rc(Recover(p_p0)))
        : prism_rtl::finished(p_p0);
}


/// `Start Recovered, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Ps> start_recovered(Ps p_p0) {
    return prism_rtl::make_rc<Recovered>(p_p0);
}


/// AtStmtBoundary: fn Ps -> Bool
bool at_stmt_boundary(const Ps& p_p0) {
    auto&& _m = kind(p_p0);
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KLaySep>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KLayClose>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KEof>(_m)) {
        return true;
    }
    {
        return false;
    }
}


/// ExpectStmtEnd: unbounded fn Ps, Text -> Ps
Ps expect_stmt_end(const Ps& p_p0, const Text& what_p1) {
    return at_stmt_boundary(p_p0)
        ? p_p0
        : recover(note_error(p_p0, here(p_p0), prism_rtl::cat("expected the end of the ", what_p1, ", found ", describe(kind(p_p0)))));
}


prism_rtl::Turn<Ps> ExpectStmtEnd::cycle() const {
    const auto& p_p0 = this->p_p0;
    const auto& what_p1 = this->what_p1;
    return at_stmt_boundary(p_p0)
        ? prism_rtl::finished(p_p0)
        : prism_rtl::more(prism_rtl::rc(Recover(note_error(p_p0, here(p_p0), prism_rtl::cat("expected the end of the ", what_p1, ", found ", describe(kind(p_p0)))))));
}


/// `Start ExpectStmtEnd, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Ps> start_expect_stmt_end(Ps p_p0, Text what_p1) {
    return prism_rtl::make_rc<ExpectStmtEnd>(p_p0, what_p1);
}


/// Describe: fn TokKind -> Text
Text describe(const crate::syntax::lexer::TokKind& tok_kind0) {
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KLayOpen>(tok_kind0)) {
        return Text::lit("an indented block");
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KLaySep>(tok_kind0)) {
        return Text::lit("the end of the line");
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KLayClose>(tok_kind0)) {
        return Text::lit("the end of the block");
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KEof>(tok_kind0)) {
        return Text::lit("the end of the input");
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KText>(tok_kind0)) {
        return Text::lit("a text literal");
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KRegex>(tok_kind0)) {
        return Text::lit("a regular expression");
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KTemplate>(tok_kind0)) {
        return Text::lit("a template");
    }
    {
        auto&& k_p0 = tok_kind0;
        return prism_rtl::cat("`", crate::syntax::lexer::corpus::token_text(k_p0), "`");
    }
}


/// WithStepMode: fn Ps, Bool -> Ps
Ps with_step_mode(const Ps& p_p0, const bool& flag_p1) {
    Ps this_ = p_p0;
    this_.step_mode = flag_p1;
    return this_;
}


/// let noSName
crate::syntax::SName no_sname() {
    return crate::syntax::SName{.sigils = Text::lit(""), .path_ = Array<Text>{}, .span = no_range()};
}


/// let noIdent
crate::syntax::Ident no_ident() {
    return crate::syntax::Ident{.name = Text::lit(""), .span = no_range()};
}


/// IsUpperName: fn SName -> Bool
bool is_upper_name(const crate::syntax::SName& n_p0) {
    return crate::syntax::lexer::chars::is_upper(crate::syntax::lexer::chars::head(or_(crate::syntax::lexer::chars::last(n_p0.path_), Text::lit(""))));
}


/// IsCallee: fn SName -> Bool
bool is_callee(const crate::syntax::SName& n_p0) {
    return is_upper_name(n_p0) || crate::syntax::lexer::chars::is_reserved_ctor(or_(crate::syntax::lexer::chars::last(n_p0.path_), Text::lit("")));
}


/// IsTopic: fn SName -> Bool
bool is_topic(const crate::syntax::SName& n_p0) {
    return n_p0.path_ == Array(std::vector{Text::lit("_")});
}


/// NameText: fn SName -> Text
Text name_text(const crate::syntax::SName& n_p0) {
    return prism_rtl::cat(n_p0.sigils, crate::syntax::lexer::chars::join(n_p0.path_, Text::lit(".")));
}


/// ParseSName: fn Ps -> ((SName, Ps))
std::tuple<crate::syntax::SName, Ps> parse_sname(const Ps& p_p0) {
    auto&& _m = kind(p_p0);
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m)) {
        auto&& n_p1 = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        return std::tuple{crate::syntax::SName{.sigils = prism_rtl::deref(n_p1).sigils, .path_ = n_p1->path_, .span = here(p_p0)}, adv(p_p0)};
    }
    {
        return std::tuple{no_sname(), error_here(p_p0, Text::lit("expected a name"))};
    }
}


/// ParseIdent: fn Ps -> ((Ident, Ps))
std::tuple<crate::syntax::Ident, Ps> parse_ident(const Ps& p_p0) {
    auto&& _m = kind(p_p0);
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m)) {
        auto&& n_p1 = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        if (((prism_rtl::deref(n_p1).sigils == Text::lit("")) && (len(n_p1->path_) == Nat(1u))) && (prism_rtl::deref(n_p1).case_ == crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseLower{}))) {
            return std::tuple{crate::syntax::Ident{.name = or_(index(n_p1->path_, Nat(0u)), Text::lit("")), .span = here(p_p0)}, adv(p_p0)};
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m16443_1_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m16443_1_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        if (m16443_1_0 == Text::lit("key")) {
            if (m16443_1_1 == Text::lit("")) {
                return std::tuple{crate::syntax::Ident{.name = Text::lit("key"), .span = here(p_p0)}, adv(p_p0)};
            }
        }
    }
    {
        return std::tuple{no_ident(), error_here(p_p0, Text::lit("expected a lowercase name"))};
    }
}


/// ParseQualName: fn Ps -> ((QualName, Ps))
std::tuple<crate::syntax::QualName, Ps> parse_qual_name(const Ps& p_p0) {
    auto&& _m = kind(p_p0);
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m)) {
        auto&& n_p1 = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        if ((prism_rtl::deref(n_p1).sigils == Text::lit("")) && (prism_rtl::deref(n_p1).case_ == crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseUpper{}))) {
            return std::tuple{crate::syntax::QualName{.path_ = n_p1->path_, .span = here(p_p0)}, adv(p_p0)};
        }
    }
    {
        return std::tuple{crate::syntax::QualName{.path_ = Array<Text>{}, .span = no_range()}, error_here(p_p0, Text::lit("expected an uppercase name"))};
    }
}


/// ParseTraitRef: fn Ps -> ((TraitRef, Ps))
std::tuple<crate::syntax::TraitRef, Ps> parse_trait_ref(const Ps& p_p0) {
    auto&& _m = kind(p_p0);
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KTrait>(_m)) {
        auto&& path_p1 = prism_rtl::as<crate::syntax::lexer::TokKind::KTrait>(_m).a0;
        auto span_p2 = here(p_p0);
        auto q_p3 = path_p1 == Array(std::vector{Text::lit("Monad")})
            ? out_of_scope(p_p0, span_p2, Text::lit("`T monad:` blocks and `^Monad`"), Text::lit("`^Monad` is out of this compiler"))
            : p_p0;
        return std::tuple{crate::syntax::TraitRef{.path_ = path_p1, .span = span_p2}, adv(q_p3)};
    }
    {
        return std::tuple{crate::syntax::TraitRef{.path_ = Array<Text>{}, .span = no_range()}, error_here(p_p0, Text::lit("expected a trait, `^Name`"))};
    }
}


/// CheckNameScope: fn Ps, SName -> Ps
Ps check_name_scope(const Ps& p_p0, const crate::syntax::SName& name_p1) {
    auto text_p2 = name_text(name_p1);
    auto feature_p3 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        {
            auto&& m17606_0 = text_p2;
            if (m17606_0 == Text::lit("!Align")) {
                _v.set(Text::lit("`!Align`"));
                goto _done;
            }
        }
        {
            auto&& m17606_1 = text_p2;
            if (m17606_1 == Text::lit("@Collect")) {
                _v.set(Text::lit("POD hosting (`@Collect`, `@View`, `@Edit`, `@Translate`)"));
                goto _done;
            }
        }
        {
            auto&& m17606_2 = text_p2;
            if (m17606_2 == Text::lit("@View")) {
                _v.set(Text::lit("POD hosting (`@Collect`, `@View`, `@Edit`, `@Translate`)"));
                goto _done;
            }
        }
        {
            auto&& m17606_3 = text_p2;
            if (m17606_3 == Text::lit("@Edit")) {
                _v.set(Text::lit("POD hosting (`@Collect`, `@View`, `@Edit`, `@Translate`)"));
                goto _done;
            }
        }
        {
            auto&& m17606_4 = text_p2;
            if (m17606_4 == Text::lit("@Translate")) {
                _v.set(Text::lit("POD hosting (`@Collect`, `@View`, `@Edit`, `@Translate`)"));
                goto _done;
            }
        }
        {
            auto&& m17606_5 = text_p2;
            if (m17606_5 == Text::lit("Over")) {
                _v.set(Text::lit("named lenses `&Home` and `Over`"));
                goto _done;
            }
        }
        {
            _v.set(Text::lit(""));
            goto _done;
        }
    _done:
        _v.take();
    });
    return feature_p3 == Text::lit("")
        ? p_p0
        : out_of_scope(p_p0, name_p1.span, feature_p3, prism_rtl::cat("`", text_p2, "` is out of this compiler"));
}


/// CheckTypeNameScope: fn Ps, SName -> Ps
Ps check_type_name_scope(const Ps& p_p0, const crate::syntax::SName& name_p1) {
    auto b_p2 = or_(crate::syntax::lexer::chars::last(name_p1.path_), Text::lit(""));
    auto sized_p3 = fold(Array(std::vector{Text::lit("U16"), Text::lit("U32"), Text::lit("U64"), Text::lit("U128"), Text::lit("I8"), Text::lit("I16"), Text::lit("I32"), Text::lit("I64"), Text::lit("I128")}), false, [&](const bool& seen_p4, const Text& s_p5) { return prism_rtl::deref(seen_p4) || (s_p5 == b_p2); });
    return len(name_p1.path_) != Nat(1u)
        ? p_p0
        : std::move(sized_p3)
        ? out_of_scope(p_p0, name_p1.span, Text::lit("sized ints other than `U8`"), prism_rtl::cat("`", b_p2, "` is out of this compiler: the sized integer it has is `U8`"))
        : b_p2 == Text::lit("Instant")
        ? out_of_scope(p_p0, name_p1.span, Text::lit("`Instant`"), Text::lit("`Instant` is out of this compiler"))
        : p_p0;
}

}  // namespace crate::syntax::parser


// The module `Syntax.Parser.Blocks`, from `target/bootstrap/cpp-src/prismc/syntax/parser/blocks.prism`.
namespace crate::syntax::parser::blocks {

/// ParseBlockAfterColon: unbounded fn Ps -> ((Block, Ps))
std::tuple<crate::syntax::Block, crate::syntax::parser::Ps> parse_block_after_colon(const crate::syntax::parser::Ps& p0_p0) {
    auto p_p1 = crate::syntax::parser::expect_colon(p0_p0);
    return crate::syntax::parser::at_open_l(p_p1)
        ? parse_indented_block(p_p1)
        : crate::syntax::parser::at_stmt_boundary(p_p1)
        ? std::tuple{crate::syntax::parser::decls::no_block(), crate::syntax::parser::error_here(p_p1, Text::lit("expected a statement after `:`"))}
        : ({
        auto start_p2 = crate::syntax::parser::here(p_p1);
        auto [first_p4, p1_p5] = parse_stmt(p_p1);
        auto r_p3 = ({
            std::tuple<Array<crate::syntax::Stmt>, crate::syntax::parser::Ps> this_ = std::tuple{Array(std::vector{first_p4}), p1_p5};
            Array<crate::syntax::Stmt> stmts_p6 = Array(std::vector{first_p4});
            crate::syntax::parser::Ps q_p7 = p1_p5;
            while ((crate::syntax::parser::kind(q_p7) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KSemi{})) && (!q_p7.bad)) {
                auto [st_p8, q2_p9] = parse_stmt(crate::syntax::parser::adv(q_p7));
                stmts_p6 = crate::prelude::push(stmts_p6, st_p8);
                q_p7 = q2_p9;
            }
            this_ = std::tuple{stmts_p6, q_p7};
            (std::move(this_));
        });
        auto [stmts_pa, q_pb] = r_p3;
        std::tuple{crate::syntax::Block{.stmts = stmts_pa, .inline_ = true, .span = crate::syntax::parser::to(start_p2, crate::syntax::parser::prev(q_pb))}, q_pb};
    });
}


prism_rtl::Turn<std::tuple<crate::syntax::Block, crate::syntax::parser::Ps>> ParseBlockAfterColon::cycle() const {
    const auto& p0_p0 = this->p0_p0;
    auto p_p1 = crate::syntax::parser::expect_colon(p0_p0);
    return crate::syntax::parser::at_open_l(p_p1)
        ? prism_rtl::more(prism_rtl::rc(ParseIndentedBlock(p_p1)))
        : crate::syntax::parser::at_stmt_boundary(p_p1)
        ? prism_rtl::finished(std::tuple{crate::syntax::parser::decls::no_block(), crate::syntax::parser::error_here(p_p1, Text::lit("expected a statement after `:`"))})
        : ({
        auto start_p2 = crate::syntax::parser::here(p_p1);
        call_then(start_parse_stmt(p_p1), [=, start_p2 = std::move(start_p2)](std::tuple<crate::syntax::Stmt, crate::syntax::parser::Ps> parse_stmt_1224) {
        return ({
            auto [first_p4, p1_p5] = parse_stmt_1224;
            std::tuple<Array<crate::syntax::Stmt>, crate::syntax::parser::Ps> this_ = std::tuple{Array(std::vector{first_p4}), p1_p5};
            Array<crate::syntax::Stmt> stmts_p6 = Array(std::vector{first_p4});
            crate::syntax::parser::Ps q_p7 = p1_p5;
            auto start_p2_1 = start_p2;
            call_then(loop_job(std::tuple{std::move(this_), std::move(q_p7), std::move(stmts_p6)}, [=](std::tuple<std::tuple<Array<crate::syntax::Stmt>, crate::syntax::parser::Ps>, crate::syntax::parser::Ps, Array<crate::syntax::Stmt>> _p0) {
            auto this_ = std::get<0>(_p0);
            auto q_p7 = std::get<1>(_p0);
            auto stmts_p6 = std::get<2>(_p0);
            return (crate::syntax::parser::kind(q_p7) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KSemi{})) && (!q_p7->bad)
                ? ({
                auto [st_p8, q2_p9] = parse_stmt(crate::syntax::parser::adv(q_p7));
                stmts_p6 = crate::prelude::push(stmts_p6, st_p8);
                q_p7 = q2_p9;
                Expected<std::tuple<std::tuple<Array<crate::syntax::Stmt>, crate::syntax::parser::Ps>, crate::syntax::parser::Ps, Array<crate::syntax::Stmt>>, std::tuple<std::tuple<Array<crate::syntax::Stmt>, crate::syntax::parser::Ps>, crate::syntax::parser::Ps, Array<crate::syntax::Stmt>>>(std::tuple{this_, q_p7, stmts_p6});
            })
                : Expected<std::tuple<std::tuple<Array<crate::syntax::Stmt>, crate::syntax::parser::Ps>, crate::syntax::parser::Ps, Array<crate::syntax::Stmt>>, std::tuple<std::tuple<Array<crate::syntax::Stmt>, crate::syntax::parser::Ps>, crate::syntax::parser::Ps, Array<crate::syntax::Stmt>>>(unexpected(std::tuple{this_, q_p7, stmts_p6}));
        }), [=, start_p2_1 = std::move(start_p2_1)](std::tuple<std::tuple<Array<crate::syntax::Stmt>, crate::syntax::parser::Ps>, crate::syntax::parser::Ps, Array<crate::syntax::Stmt>> _p0) {
            auto this_ = std::get<0>(_p0);
            auto q_p7 = std::get<1>(_p0);
            auto stmts_p6 = std::get<2>(_p0);
            return ({
                this_ = std::tuple{stmts_p6, q_p7};
                auto r_p3 = this_;
                auto [stmts_pa, q_pb] = r_p3;
                (prism_rtl::finished(std::tuple{crate::syntax::Block{.stmts = stmts_pa, .inline_ = true, .span = crate::syntax::parser::to(start_p2_1, crate::syntax::parser::prev(q_pb))}, q_pb}));
            });
        });
        });
    });
    });
}


/// `Start ParseBlockAfterColon, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Block, crate::syntax::parser::Ps>> start_parse_block_after_colon(crate::syntax::parser::Ps p0_p0) {
    return prism_rtl::make_rc<ParseBlockAfterColon>(p0_p0);
}


/// ParseIndentedBlock: unbounded fn Ps -> ((Block, Ps))
std::tuple<crate::syntax::Block, crate::syntax::parser::Ps> parse_indented_block(const crate::syntax::parser::Ps& p0_p0) {
    auto start_p1 = crate::syntax::parser::here(p0_p0);
    auto [stmts_p2, q_p3] = stmts_until(crate::syntax::parser::adv(p0_p0), true);
    return std::tuple{crate::syntax::Block{.stmts = stmts_p2, .inline_ = false, .span = crate::syntax::parser::to(start_p1, crate::syntax::parser::prev(q_p3))}, q_p3};
}


prism_rtl::Turn<std::tuple<crate::syntax::Block, crate::syntax::parser::Ps>> ParseIndentedBlock::cycle() const {
    const auto& p0_p0 = this->p0_p0;
    auto start_p1 = crate::syntax::parser::here(p0_p0);
    auto p0_p0_1 = p0_p0;
    return call_then(start_stmts_until(crate::syntax::parser::adv(p0_p0_1), true), [=](std::tuple<Array<crate::syntax::Stmt>, crate::syntax::parser::Ps> stmts_until_1826) {
        return ({
            auto [stmts_p2, q_p3] = stmts_until_1826;
            (prism_rtl::finished(std::tuple{crate::syntax::Block{.stmts = stmts_p2, .inline_ = false, .span = crate::syntax::parser::to(start_p1, crate::syntax::parser::prev(q_p3))}, q_p3}));
        });
    });
}


/// `Start ParseIndentedBlock, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Block, crate::syntax::parser::Ps>> start_parse_indented_block(crate::syntax::parser::Ps p0_p0) {
    return prism_rtl::make_rc<ParseIndentedBlock>(p0_p0);
}


/// ParseBlockUntilEof: unbounded fn Ps, Range -> ((Block, Ps))
std::tuple<crate::syntax::Block, crate::syntax::parser::Ps> parse_block_until_eof(const crate::syntax::parser::Ps& p_p0, const crate::syntax::Range& span_p1) {
    auto [stmts_p2, q_p3] = crate::syntax::parser::at_eof(p_p0)
        ? std::tuple{Array<crate::syntax::Stmt>{}, p_p0}
        : stmts_until(p_p0, false);
    return std::tuple{crate::syntax::Block{.stmts = stmts_p2, .inline_ = false, .span = span_p1}, q_p3};
}


prism_rtl::Turn<std::tuple<crate::syntax::Block, crate::syntax::parser::Ps>> ParseBlockUntilEof::cycle() const {
    const auto& p_p0 = this->p_p0;
    const auto& span_p1 = this->span_p1;
    auto [stmts_p2, q_p3] = crate::syntax::parser::at_eof(p_p0)
        ? std::tuple{Array<crate::syntax::Stmt>{}, p_p0}
        : stmts_until(p_p0, false);
    return prism_rtl::finished(std::tuple{crate::syntax::Block{.stmts = stmts_p2, .inline_ = false, .span = span_p1}, q_p3});
}


/// `Start ParseBlockUntilEof, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Block, crate::syntax::parser::Ps>> start_parse_block_until_eof(crate::syntax::parser::Ps p_p0, crate::syntax::Range span_p1) {
    return prism_rtl::make_rc<ParseBlockUntilEof>(p_p0, span_p1);
}


/// StmtsUntil: unbounded fn Ps, Bool -> (([Stmt], Ps))
std::tuple<Array<crate::syntax::Stmt>, crate::syntax::parser::Ps> stmts_until(const crate::syntax::parser::Ps& p0_p0, const bool& indented_p1) {
    std::tuple<Array<crate::syntax::Stmt>, crate::syntax::parser::Ps> this_ = std::tuple{Array<crate::syntax::Stmt>{}, p0_p0};
    Array<crate::syntax::Stmt> stmts_p2 = Array<crate::syntax::Stmt>{};
    crate::syntax::parser::Ps p_p3 = p0_p0;
    bool going_p4 = true;
    while (std::move(going_p4)) {
        auto [st_p5, q_p6] = parse_stmt(p_p3);
        if (!q_p6->bad) {
            stmts_p2 = crate::prelude::push(stmts_p2, st_p5);
        }
        p_p3 = crate::syntax::parser::recovered(q_p6);
        {
            auto&& _m = crate::syntax::parser::kind(p_p3);
            if (prism_rtl::is<crate::syntax::lexer::TokKind::KLaySep>(_m)) {
                p_p3 = crate::syntax::parser::adv(p_p3);
                if ((!indented_p1) && crate::syntax::parser::at_eof(p_p3)) {
                    going_p4 = false;
                }
            } else if (prism_rtl::is<crate::syntax::lexer::TokKind::KLayClose>(_m)) {
                p_p3 = crate::syntax::parser::adv(p_p3);
                if (indented_p1 || crate::syntax::parser::at_eof(p_p3)) {
                    going_p4 = false;
                }
            } else if (prism_rtl::is<crate::syntax::lexer::TokKind::KEof>(_m)) {
                going_p4 = false;
            } else {
                p_p3 = crate::syntax::parser::recover(crate::syntax::parser::complain(p_p3, Text::lit("expected the end of the statement")));
            }
        }
    }
    this_ = std::tuple{stmts_p2, p_p3};
    return this_;
}


prism_rtl::Turn<std::tuple<Array<crate::syntax::Stmt>, crate::syntax::parser::Ps>> StmtsUntil::cycle() const {
    const auto& p0_p0 = this->p0_p0;
    const auto& indented_p1 = this->indented_p1;
    std::tuple<Array<crate::syntax::Stmt>, crate::syntax::parser::Ps> this_ = std::tuple{Array<crate::syntax::Stmt>{}, p0_p0};
    Array<crate::syntax::Stmt> stmts_p2 = Array<crate::syntax::Stmt>{};
    crate::syntax::parser::Ps p_p3 = p0_p0;
    bool going_p4 = true;
    return call_then(loop_job(std::tuple{std::move(this_), std::move(going_p4), std::move(p_p3), std::move(stmts_p2)}, ({
        auto indented_p1_1 = prism_rtl::deref(indented_p1);
        [=, indented_p1_1 = std::move(indented_p1_1)](std::tuple<std::tuple<Array<crate::syntax::Stmt>, crate::syntax::parser::Ps>, bool, crate::syntax::parser::Ps, Array<crate::syntax::Stmt>> _p0) {
        auto this_ = std::get<0>(_p0);
        auto going_p4 = std::get<1>(_p0);
        auto p_p3 = std::get<2>(_p0);
        auto stmts_p2 = std::get<3>(_p0);
        return going_p4
            ? ({
            auto [st_p5, q_p6] = parse_stmt(p_p3);
            if (!q_p6->bad) {
                stmts_p2 = crate::prelude::push(stmts_p2, st_p5);
            }
            p_p3 = crate::syntax::parser::recovered(q_p6);
            {
                auto&& _m = crate::syntax::parser::kind(p_p3);
                if (prism_rtl::is<crate::syntax::lexer::TokKind::KLaySep>(_m)) {
                    p_p3 = crate::syntax::parser::adv(p_p3);
                    if ((!indented_p1_1) && crate::syntax::parser::at_eof(p_p3)) {
                        going_p4 = false;
                    }
                } else if (prism_rtl::is<crate::syntax::lexer::TokKind::KLayClose>(_m)) {
                    p_p3 = crate::syntax::parser::adv(p_p3);
                    if (indented_p1_1 || crate::syntax::parser::at_eof(p_p3)) {
                        going_p4 = false;
                    }
                } else if (prism_rtl::is<crate::syntax::lexer::TokKind::KEof>(_m)) {
                    going_p4 = false;
                } else {
                    p_p3 = crate::syntax::parser::recover(crate::syntax::parser::complain(p_p3, Text::lit("expected the end of the statement")));
                }
            }
            Expected<std::tuple<std::tuple<Array<crate::syntax::Stmt>, crate::syntax::parser::Ps>, bool, crate::syntax::parser::Ps, Array<crate::syntax::Stmt>>, std::tuple<std::tuple<Array<crate::syntax::Stmt>, crate::syntax::parser::Ps>, bool, crate::syntax::parser::Ps, Array<crate::syntax::Stmt>>>(std::tuple{this_, going_p4, p_p3, stmts_p2});
        })
            : Expected<std::tuple<std::tuple<Array<crate::syntax::Stmt>, crate::syntax::parser::Ps>, bool, crate::syntax::parser::Ps, Array<crate::syntax::Stmt>>, std::tuple<std::tuple<Array<crate::syntax::Stmt>, crate::syntax::parser::Ps>, bool, crate::syntax::parser::Ps, Array<crate::syntax::Stmt>>>(unexpected(std::tuple{this_, going_p4, p_p3, stmts_p2}));
    };
    })), [=](std::tuple<std::tuple<Array<crate::syntax::Stmt>, crate::syntax::parser::Ps>, bool, crate::syntax::parser::Ps, Array<crate::syntax::Stmt>> _p0) {
        auto this_ = std::get<0>(_p0);
        auto going_p4 = std::get<1>(_p0);
        auto p_p3 = std::get<2>(_p0);
        auto stmts_p2 = std::get<3>(_p0);
        return ({
            this_ = std::tuple{stmts_p2, p_p3};
            (prism_rtl::finished(this_));
        });
    });
}


/// `Start StmtsUntil, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::syntax::Stmt>, crate::syntax::parser::Ps>> start_stmts_until(crate::syntax::parser::Ps p0_p0, bool indented_p1) {
    return prism_rtl::make_rc<StmtsUntil>(p0_p0, indented_p1);
}


/// ParseStmt: unbounded fn Ps -> ((Stmt, Ps))
std::tuple<crate::syntax::Stmt, crate::syntax::parser::Ps> parse_stmt(const crate::syntax::parser::Ps& p_p0) {
    auto start_p1 = crate::syntax::parser::here(p_p0);
    auto [kind_p2, q_p3] = stmt_kind_of(p_p0, start_p1);
    return std::tuple{crate::syntax::Stmt{.kind = kind_p2, .span = crate::syntax::parser::to(start_p1, crate::syntax::parser::prev(q_p3))}, q_p3};
}


prism_rtl::Turn<std::tuple<crate::syntax::Stmt, crate::syntax::parser::Ps>> ParseStmt::cycle() const {
    const auto& p_p0 = this->p_p0;
    auto start_p1 = crate::syntax::parser::here(p_p0);
    auto p_p0_1 = p_p0;
    return call_then(start_stmt_kind_of(p_p0_1, start_p1), [=](std::tuple<crate::syntax::StmtKind, crate::syntax::parser::Ps> stmt_kind_of_3254) {
        return ({
            auto [kind_p2, q_p3] = stmt_kind_of_3254;
            (prism_rtl::finished(std::tuple{crate::syntax::Stmt{.kind = kind_p2, .span = crate::syntax::parser::to(start_p1, crate::syntax::parser::prev(q_p3))}, q_p3}));
        });
    });
}


/// `Start ParseStmt, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Stmt, crate::syntax::parser::Ps>> start_parse_stmt(crate::syntax::parser::Ps p_p0) {
    return prism_rtl::make_rc<ParseStmt>(p_p0);
}


/// StmtKindOf: unbounded fn Ps, Range -> ((StmtKind, Ps))
std::tuple<crate::syntax::StmtKind, crate::syntax::parser::Ps> stmt_kind_of(const crate::syntax::parser::Ps& p_p0, const crate::syntax::Range& start_p1) {
    auto&& _m = crate::syntax::parser::kind(p_p0);
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m3409_0_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m3409_0_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        if (m3409_0_0 == Text::lit("emit")) {
            if (m3409_0_1 == Text::lit("")) {
                auto [r_p2, q_p3] = crate::syntax::parser::types::parse_row(crate::syntax::parser::adv(p_p0));
                return std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SEmit{r_p2}), q_p3};
            }
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m3409_1_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m3409_1_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        if (m3409_1_0 == Text::lit("let")) {
            if (m3409_1_1 == Text::lit("")) {
                auto [pattern_p4, p1_p5] = crate::syntax::parser::types::parse_pattern(crate::syntax::parser::adv(p_p0), false);
                auto [ty_o6, p2_p7] = crate::syntax::parser::decls::optional_annotation(p1_p5);
                auto [value_p8, p3_p9] = crate::syntax::parser::expr::parse_rhs_expr(crate::syntax::parser::expect_op(p2_p7, Text::lit("=")));
                return std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SLet{pattern_p4, ty_o6, value_p8}), p3_p9};
            }
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m3409_2_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m3409_2_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        if (m3409_2_0 == Text::lit("fn")) {
            if (m3409_2_1 == Text::lit("")) {
                auto [f_pa, q_pb] = crate::syntax::parser::decls::parse_fn_clause(p_p0);
                return std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SFn{f_pa}), q_pb};
            }
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m3409_3_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m3409_3_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        if (m3409_3_0 == Text::lit("ignore")) {
            if (m3409_3_1 == Text::lit("")) {
                if (crate::syntax::parser::at_op(crate::syntax::parser::adv(p_p0), Text::lit("<-"))) {
                    auto [e_pc, q_pd] = crate::syntax::parser::expr::parse_rhs_expr(crate::syntax::parser::adv(crate::syntax::parser::adv(p_p0)));
                    return std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SIgnore{e_pc}), q_pd};
                }
            }
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& w_pe = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m3409_4_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        if (m3409_4_1 == Text::lit("")) {
            if ((w_pe == Text::lit("require")) || (w_pe == Text::lit("forbid"))) {
                auto [c_pg, p1_ph] = crate::syntax::parser::expr::parse_rhs_expr(crate::syntax::parser::adv(p_p0));
                auto q_pf = crate::syntax::parser::at_comma(p1_ph)
                    ? crate::syntax::parser::error_at(p1_ph, crate::syntax::parser::here(p1_ph), prism_rtl::cat("`", w_pe, "` takes its condition alone, with no error value after a comma (decisions.md D15): a failed guard under `~` raises `Prelude.Unmet` (D11), and a comma after a guard belongs to a call at the head of its condition, as in `require Clear g, from, corner`"))
                    : p1_ph;
                return w_pe == Text::lit("require")
                    ? std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SRequire{c_pg}), q_pf}
                    : std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SForbid{c_pg}), q_pf};
            }
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m3409_5_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m3409_5_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        if (m3409_5_0 == Text::lit("while")) {
            if (m3409_5_1 == Text::lit("")) {
                auto [cond_pi, p1_pj] = crate::syntax::parser::expr::parse_cond(crate::syntax::parser::adv(p_p0), true);
                auto [body_pk, q_pl] = parse_block_after_colon(p1_pj);
                return std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SWhile{cond_pi, body_pk}), q_pl};
            }
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
        auto&& m3409_6_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m3409_6_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        if (m3409_6_0 == Text::lit("return")) {
            if (m3409_6_1 == Text::lit("")) {
                auto p1_pm = crate::syntax::parser::out_of_scope(crate::syntax::parser::adv(p_p0), crate::syntax::parser::here(p_p0), Text::lit("`T monad:` blocks and `^Monad`"), Text::lit("`return` ends a monad block, which is out of this compiler"));
                auto [e_pn, q_po] = crate::syntax::parser::expr::parse_rhs_expr(p1_pm);
                return std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SReturn{e_pn}), q_po};
            }
        }
    }
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m)) {
        if (crate::syntax::parser::kind_at(p_p0, Nat(1u)) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KColon{})) {
            return crate::syntax::parser::kind_at(p_p0, Nat(2u)) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KLayOpen{})
                ? ({
                auto [name_pp, p1_pq] = crate::syntax::parser::parse_sname(p_p0);
                auto [body_pr, q_ps] = parse_block_after_colon(p1_pq);
                std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SWidget{crate::syntax::decls::WidgetDecl{.name = name_pp, .body = body_pr, .span = crate::syntax::parser::to(start_p1, prism_rtl::deref(body_pr).span)}}), q_ps};
            })
                : ({
                auto [sig_pt, q_pu] = crate::syntax::parser::decls::parse_signature(p_p0);
                std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SSignature{sig_pt}), q_pu};
            });
        }
    }
    {
        return other_stmt(p_p0);
    }
}


prism_rtl::Turn<std::tuple<crate::syntax::StmtKind, crate::syntax::parser::Ps>> StmtKindOf::cycle() const {
    const auto& p_p0 = this->p_p0;
    const auto& start_p1 = this->start_p1;
    return ({
        auto&& _m = crate::syntax::parser::kind(p_p0);
        prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& m3409_0_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m3409_0_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        (m3409_0_0 == Text::lit("emit")) && (m3409_0_1 == Text::lit(""));
    }) ? ({
        auto&& m3409_0_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m3409_0_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        ({
        auto p_p0_1 = p_p0;
        call_then(crate::syntax::parser::types::start_parse_row(crate::syntax::parser::adv(p_p0_1)), [=](std::tuple<crate::syntax::Row_, crate::syntax::parser::Ps> parse_row_3466) {
        return ({
            auto [r_p2, q_p3] = parse_row_3466;
            (prism_rtl::finished(std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SEmit{r_p2}), q_p3}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& m3409_1_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m3409_1_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        (m3409_1_0 == Text::lit("let")) && (m3409_1_1 == Text::lit(""));
    }) ? ({
        auto&& m3409_1_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m3409_1_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        ({
        auto p_p0_1 = p_p0;
        call_then(crate::syntax::parser::types::start_parse_pattern(crate::syntax::parser::adv(p_p0_1), false), [=](std::tuple<crate::syntax::Pattern_, crate::syntax::parser::Ps> parse_pattern_3555) {
        return ({
            auto [pattern_p4, p1_p5] = parse_pattern_3555;
            call_then(crate::syntax::parser::decls::start_optional_annotation(p1_p5), [=](std::tuple<std::optional<crate::syntax::Type>, crate::syntax::parser::Ps> optional_annotation_3609) {
            return ({
                auto [ty_o6, p2_p7] = optional_annotation_3609;
                call_then(crate::syntax::parser::expr::start_parse_rhs_expr(crate::syntax::parser::expect_op(p2_p7, Text::lit("="))), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_rhs_expr_3659) {
                return ({
                    auto [value_p8, p3_p9] = parse_rhs_expr_3659;
                    (prism_rtl::finished(std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SLet{pattern_p4, ty_o6, value_p8}), p3_p9}));
                });
            });
            });
        });
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& m3409_2_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m3409_2_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        (m3409_2_0 == Text::lit("fn")) && (m3409_2_1 == Text::lit(""));
    }) ? ({
        auto&& m3409_2_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m3409_2_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        ({
        auto p_p0_1 = p_p0;
        call_then(crate::syntax::parser::decls::start_parse_fn_clause(p_p0_1), [=](std::tuple<crate::syntax::decls::FnClause, crate::syntax::parser::Ps> parse_fn_clause_3775) {
        return ({
            auto [f_pa, q_pb] = parse_fn_clause_3775;
            (prism_rtl::finished(std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SFn{f_pa}), q_pb}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& m3409_3_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m3409_3_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        (m3409_3_0 == Text::lit("ignore")) && (m3409_3_1 == Text::lit("")) && crate::syntax::parser::at_op(crate::syntax::parser::adv(p_p0), Text::lit("<-"));
    }) ? ({
        auto&& m3409_3_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m3409_3_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        ({
        auto p_p0_1 = p_p0;
        call_then(crate::syntax::parser::expr::start_parse_rhs_expr(crate::syntax::parser::adv(crate::syntax::parser::adv(p_p0_1))), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_rhs_expr_3881) {
        return ({
            auto [e_pc, q_pd] = parse_rhs_expr_3881;
            (prism_rtl::finished(std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SIgnore{e_pc}), q_pd}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& w_pe = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m3409_4_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        (m3409_4_1 == Text::lit("")) && ((w_pe == Text::lit("require")) || (w_pe == Text::lit("forbid")));
    }) ? ({
        auto&& w_pe = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m3409_4_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        ({
        auto p_p0_1 = p_p0;
        call_then(crate::syntax::parser::expr::start_parse_rhs_expr(crate::syntax::parser::adv(p_p0_1)), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_rhs_expr_4174) {
        return ({
            auto [c_pg, p1_ph] = parse_rhs_expr_4174;
            auto q_pf = crate::syntax::parser::at_comma(p1_ph)
                ? crate::syntax::parser::error_at(p1_ph, crate::syntax::parser::here(p1_ph), prism_rtl::cat("`", w_pe, "` takes its condition alone, with no error value after a comma (decisions.md D15): a failed guard under `~` raises `Prelude.Unmet` (D11), and a comma after a guard belongs to a call at the head of its condition, as in `require Clear g, from, corner`"))
                : p1_ph;
            w_pe == Text::lit("require")
            ? prism_rtl::finished(std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SRequire{c_pg}), q_pf})
            : prism_rtl::finished(std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SForbid{c_pg}), q_pf});
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& m3409_5_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m3409_5_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        (m3409_5_0 == Text::lit("while")) && (m3409_5_1 == Text::lit(""));
    }) ? ({
        auto&& m3409_5_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m3409_5_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        ({
        auto p_p0_1 = p_p0;
        call_then(crate::syntax::parser::expr::start_parse_cond(crate::syntax::parser::adv(p_p0_1), true), [=](std::tuple<crate::syntax::Cond, crate::syntax::parser::Ps> parse_cond_4630) {
        return ({
            auto [cond_pi, p1_pj] = parse_cond_4630;
            call_then(start_parse_block_after_colon(p1_pj), [=](std::tuple<crate::syntax::Block, crate::syntax::parser::Ps> parse_block_after_colon_4680) {
            return ({
                auto [body_pk, q_pl] = parse_block_after_colon_4680;
                (prism_rtl::finished(std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SWhile{cond_pi, body_pk}), q_pl}));
            });
        });
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m) && ({
        auto&& m3409_6_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m3409_6_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        (m3409_6_0 == Text::lit("return")) && (m3409_6_1 == Text::lit(""));
    }) ? ({
        auto&& m3409_6_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
        auto&& m3409_6_1 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a1;
        ({
        auto p1_pm = crate::syntax::parser::out_of_scope(crate::syntax::parser::adv(p_p0), crate::syntax::parser::here(p_p0), Text::lit("`T monad:` blocks and `^Monad`"), Text::lit("`return` ends a monad block, which is out of this compiler"));
        call_then(crate::syntax::parser::expr::start_parse_rhs_expr(p1_pm), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_rhs_expr_4926) {
        return ({
            auto [e_pn, q_po] = parse_rhs_expr_4926;
            (prism_rtl::finished(std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SReturn{e_pn}), q_po}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m) && ({
        (crate::syntax::parser::kind_at(p_p0, Nat(1u)) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KColon{}));
    }) ? crate::syntax::parser::kind_at(p_p0, Nat(2u)) == crate::syntax::lexer::TokKind(crate::syntax::lexer::TokKind::KLayOpen{})
        ? ({
        auto [name_pp, p1_pq] = crate::syntax::parser::parse_sname(p_p0);
        auto start_p1_1 = start_p1;
        call_then(start_parse_block_after_colon(p1_pq), [=, start_p1_1 = std::move(start_p1_1)](std::tuple<crate::syntax::Block, crate::syntax::parser::Ps> parse_block_after_colon_5173) {
        return ({
            auto [body_pr, q_ps] = parse_block_after_colon_5173;
            (prism_rtl::finished(std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SWidget{crate::syntax::decls::WidgetDecl{.name = name_pp, .body = body_pr, .span = crate::syntax::parser::to(start_p1_1, prism_rtl::deref(body_pr).span)}}), q_ps}));
        });
    });
    })
        : ({
        auto p_p0_1 = p_p0;
        call_then(crate::syntax::parser::decls::start_parse_signature(p_p0_1), [=](std::tuple<crate::syntax::decls::Signature, crate::syntax::parser::Ps> parse_signature_5328) {
        return ({
            auto [sig_pt, q_pu] = parse_signature_5328;
            (prism_rtl::finished(std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SSignature{sig_pt}), q_pu}));
        });
    });
    })
        : prism_rtl::more(prism_rtl::rc(OtherStmt(p_p0)));
    });
}


/// `Start StmtKindOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::StmtKind, crate::syntax::parser::Ps>> start_stmt_kind_of(crate::syntax::parser::Ps p_p0, crate::syntax::Range start_p1) {
    return prism_rtl::make_rc<StmtKindOf>(p_p0, start_p1);
}


/// OtherStmt: unbounded fn Ps -> ((StmtKind, Ps))
std::tuple<crate::syntax::StmtKind, crate::syntax::parser::Ps> other_stmt(const crate::syntax::parser::Ps& p_p0) {
    auto [upd_p1, u_p2] = parse_update_stmt(p_p0);
    auto [pattern_p3, b_p4] = crate::syntax::parser::types::parse_pattern(p_p0, true);
    return !u_p2->bad
        ? std::tuple{upd_p1, u_p2}
        : (!b_p4->bad) && crate::syntax::parser::at_op(b_p4, Text::lit("<-"))
        ? ({
        auto [value_p5, p1_p6] = crate::syntax::parser::expr::parse_rhs_expr(crate::syntax::parser::adv(b_p4));
        auto [then_step_o7, p2_p8] = crate::syntax::parser::at_kw(p1_p6, Text::lit("then"))
            ? optional_rhs(crate::syntax::parser::adv(p1_p6))
            : std::tuple{std::optional<crate::syntax::Expr>{}, p1_p6};
        crate::syntax::parser::at_kw(p2_p8, Text::lit("then"))
        ? std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SExpr{crate::syntax::parser::decls::no_expr()}), crate::syntax::parser::error_at(p2_p8, crate::syntax::parser::here(p2_p8), Text::lit("`then` does not associate: a hold has one start and one step"))}
        : std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SBind{pattern_p3, value_p5, then_step_o7}), p2_p8};
    })
        : ({
        auto [e_p9, p1_pa] = crate::syntax::parser::expr::parse_rhs_expr(p_p0);
        crate::syntax::parser::at_op(p1_pa, Text::lit("<-"))
        ? std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SExpr{e_p9}), crate::syntax::parser::error_at(p1_pa, crate::syntax::parser::here(p1_pa), Text::lit("the left side of `<-` is not a pattern"))}
        : crate::syntax::parser::at_kw(p1_pa, Text::lit("then"))
        ? std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SExpr{e_p9}), crate::syntax::parser::error_at(p1_pa, crate::syntax::parser::here(p1_pa), Text::lit("`then` belongs to a hold: `$x <- start then step`"))}
        : std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SExpr{e_p9}), p1_pa};
    });
}


prism_rtl::Turn<std::tuple<crate::syntax::StmtKind, crate::syntax::parser::Ps>> OtherStmt::cycle() const {
    const auto& p_p0 = this->p_p0;
    auto p_p0_1 = p_p0;
    return call_then(start_parse_update_stmt(p_p0_1), [=](std::tuple<crate::syntax::StmtKind, crate::syntax::parser::Ps> parse_update_stmt_5569) {
        return ({
            auto [upd_p1, u_p2] = parse_update_stmt_5569;
            call_then(crate::syntax::parser::types::start_parse_pattern(p_p0_1, true), [=](std::tuple<crate::syntax::Pattern_, crate::syntax::parser::Ps> parse_pattern_5612) {
            return ({
                auto [pattern_p3, b_p4] = parse_pattern_5612;
                !u_p2->bad
                ? prism_rtl::finished(std::tuple{upd_p1, u_p2})
                : (!b_p4->bad) && crate::syntax::parser::at_op(b_p4, Text::lit("<-"))
                ? call_then(crate::syntax::parser::expr::start_parse_rhs_expr(crate::syntax::parser::adv(b_p4)), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_rhs_expr_5733) {
                return ({
                    auto [value_p5, p1_p6] = parse_rhs_expr_5733;
                    auto [then_step_o7, p2_p8] = crate::syntax::parser::at_kw(p1_p6, Text::lit("then"))
                        ? optional_rhs(crate::syntax::parser::adv(p1_p6))
                        : std::tuple{std::optional<crate::syntax::Expr>{}, p1_p6};
                    (crate::syntax::parser::at_kw(p2_p8, Text::lit("then"))
                    ? prism_rtl::finished(std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SExpr{crate::syntax::parser::decls::no_expr()}), crate::syntax::parser::error_at(p2_p8, crate::syntax::parser::here(p2_p8), Text::lit("`then` does not associate: a hold has one start and one step"))})
                    : prism_rtl::finished(std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SBind{pattern_p3, value_p5, then_step_o7}), p2_p8}));
                });
            })
                : call_then(crate::syntax::parser::expr::start_parse_rhs_expr(p_p0_1), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_rhs_expr_6069) {
                return ({
                    auto [e_p9, p1_pa] = parse_rhs_expr_6069;
                    (crate::syntax::parser::at_op(p1_pa, Text::lit("<-"))
                    ? prism_rtl::finished(std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SExpr{e_p9}), crate::syntax::parser::error_at(p1_pa, crate::syntax::parser::here(p1_pa), Text::lit("the left side of `<-` is not a pattern"))})
                    : crate::syntax::parser::at_kw(p1_pa, Text::lit("then"))
                    ? prism_rtl::finished(std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SExpr{e_p9}), crate::syntax::parser::error_at(p1_pa, crate::syntax::parser::here(p1_pa), Text::lit("`then` belongs to a hold: `$x <- start then step`"))})
                    : prism_rtl::finished(std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SExpr{e_p9}), p1_pa}));
                });
            });
            });
        });
        });
    });
}


/// `Start OtherStmt, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::StmtKind, crate::syntax::parser::Ps>> start_other_stmt(crate::syntax::parser::Ps p_p0) {
    return prism_rtl::make_rc<OtherStmt>(p_p0);
}


/// OptionalRhs: unbounded fn Ps -> ((?Expr, Ps))
std::tuple<std::optional<crate::syntax::Expr>, crate::syntax::parser::Ps> optional_rhs(const crate::syntax::parser::Ps& p_p0) {
    auto [e_p1, q_p2] = crate::syntax::parser::expr::parse_rhs_expr(p_p0);
    return std::tuple{std::optional(e_p1), q_p2};
}


prism_rtl::Turn<std::tuple<std::optional<crate::syntax::Expr>, crate::syntax::parser::Ps>> OptionalRhs::cycle() const {
    const auto& p_p0 = this->p_p0;
    auto p_p0_1 = p_p0;
    return call_then(crate::syntax::parser::expr::start_parse_rhs_expr(p_p0_1), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_rhs_expr_6427) {
        return ({
            auto [e_p1, q_p2] = parse_rhs_expr_6427;
            (prism_rtl::finished(std::tuple{std::optional(e_p1), q_p2}));
        });
    });
}


/// `Start OptionalRhs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<std::optional<crate::syntax::Expr>, crate::syntax::parser::Ps>> start_optional_rhs(crate::syntax::parser::Ps p_p0) {
    return prism_rtl::make_rc<OptionalRhs>(p_p0);
}


/// ParseUpdateStmt: unbounded fn Ps -> ((StmtKind, Ps))
std::tuple<crate::syntax::StmtKind, crate::syntax::parser::Ps> parse_update_stmt(const crate::syntax::parser::Ps& p_p0) {
    auto [target_p2, p1_p3] = parse_reference(p_p0);
    auto op_p1 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = crate::syntax::parser::kind(p1_p3);
        if (prism_rtl::is<crate::syntax::lexer::TokKind::KOp>(_m)) {
            auto&& o_p4 = prism_rtl::as<crate::syntax::lexer::TokKind::KOp>(_m).a0;
            _v.set(o_p4);
            goto _done;
        }
        {
            _v.set(Text::lit(""));
            goto _done;
        }
    _done:
        _v.take();
    });
    return p1_p3->bad || (!(((((op_p1 == Text::lit("<=")) || (op_p1 == Text::lit("+="))) || (op_p1 == Text::lit("-="))) || (op_p1 == Text::lit("*="))) || (op_p1 == Text::lit("/="))))
        ? std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SExpr{crate::syntax::parser::decls::no_expr()}), crate::syntax::parser::fail(p1_p3)}
        : ({
        auto [value_p5, q_p6] = crate::syntax::parser::expr::parse_rhs_expr(crate::syntax::parser::adv(p1_p3));
        op_p1 == Text::lit("<=")
        ? std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SSet{target_p2, value_p5}), q_p6}
        : std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SAccum{target_p2, op_p1, value_p5}), q_p6};
    });
}


prism_rtl::Turn<std::tuple<crate::syntax::StmtKind, crate::syntax::parser::Ps>> ParseUpdateStmt::cycle() const {
    const auto& p_p0 = this->p_p0;
    auto p_p0_1 = p_p0;
    return call_then(start_parse_reference(p_p0_1), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_reference_6741) {
        return ({
            auto [target_p2, p1_p3] = parse_reference_6741;
            auto op_p1 = ({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                auto&& _m = crate::syntax::parser::kind(p1_p3);
                if (prism_rtl::is<crate::syntax::lexer::TokKind::KOp>(_m)) {
                    auto&& o_p4 = prism_rtl::as<crate::syntax::lexer::TokKind::KOp>(_m).a0;
                    _v.set(o_p4);
                    goto _done;
                }
                {
                    _v.set(Text::lit(""));
                    goto _done;
                }
            _done:
                _v.take();
            });
            p1_p3->bad || (!(((((op_p1 == Text::lit("<=")) || (op_p1 == Text::lit("+="))) || (op_p1 == Text::lit("-="))) || (op_p1 == Text::lit("*="))) || (op_p1 == Text::lit("/="))))
            ? prism_rtl::finished(std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SExpr{crate::syntax::parser::decls::no_expr()}), crate::syntax::parser::fail(p1_p3)})
            : call_then(crate::syntax::parser::expr::start_parse_rhs_expr(crate::syntax::parser::adv(p1_p3)), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_rhs_expr_6989) {
            return ({
                auto [value_p5, q_p6] = parse_rhs_expr_6989;
                op_p1 == Text::lit("<=")
                ? prism_rtl::finished(std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SSet{target_p2, value_p5}), q_p6})
                : prism_rtl::finished(std::tuple{crate::syntax::StmtKind(crate::syntax::StmtKind::SAccum{target_p2, op_p1, value_p5}), q_p6});
            });
        });
        });
    });
}


/// `Start ParseUpdateStmt, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::StmtKind, crate::syntax::parser::Ps>> start_parse_update_stmt(crate::syntax::parser::Ps p_p0) {
    return prism_rtl::make_rc<ParseUpdateStmt>(p_p0);
}


/// ParseReference: unbounded fn Ps -> ((Expr, Ps))
std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_reference(const crate::syntax::parser::Ps& p_p0) {
    auto&& _m = crate::syntax::parser::kind(p_p0);
    if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m)) {
        auto&& n_p1 = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        if (crate::syntax::lexer::chars::has_prefix(prism_rtl::deref(n_p1).sigils, Text::lit("&"))) {
            auto start_p2 = crate::syntax::parser::here(p_p0);
            auto [name_p3, p1_p4] = crate::syntax::parser::parse_sname(p_p0);
            return crate::syntax::parser::is_upper_name(name_p3)
                ? ({
                auto p2_p5 = crate::syntax::parser::out_of_scope(p1_p4, prism_rtl::deref(name_p3).span, Text::lit("named lenses `&Home` and `Over`"), prism_rtl::cat("the named lens `", crate::syntax::parser::name_text(name_p3), "` is out of this compiler; write its path, `&_.score.home`"));
                auto [inner_p7, q_p8] = parse_reference(p2_p5);
                auto callee_p6 = crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EName{name_p3})), .span = start_p2};
                std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ECall{prism_rtl::rc(callee_p6), Array(std::vector{crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = inner_p7, .span = prism_rtl::deref(inner_p7).span}}), false, false})), .span = crate::syntax::parser::to(start_p2, prism_rtl::deref(inner_p7).span)}, q_p8};
            })
                : lens_steps(crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EName{name_p3})), .span = prism_rtl::deref(name_p3).span}, p1_p4);
        }
    }
    {
        return std::tuple{crate::syntax::parser::decls::no_expr(), crate::syntax::parser::fail(p_p0)};
    }
}


prism_rtl::Turn<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> ParseReference::cycle() const {
    const auto& p_p0 = this->p_p0;
    return ({
        auto&& _m = crate::syntax::parser::kind(p_p0);
        prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m) && ({
        auto&& n_p1 = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        crate::syntax::lexer::chars::has_prefix(prism_rtl::deref(n_p1).sigils, Text::lit("&"));
    }) ? ({
        auto&& n_p1 = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
        ({
        auto start_p2 = crate::syntax::parser::here(p_p0);
        auto [name_p3, p1_p4] = crate::syntax::parser::parse_sname(p_p0);
        (crate::syntax::parser::is_upper_name(name_p3)
        ? ({
        auto p2_p5 = crate::syntax::parser::out_of_scope(p1_p4, prism_rtl::deref(name_p3).span, Text::lit("named lenses `&Home` and `Over`"), prism_rtl::cat("the named lens `", crate::syntax::parser::name_text(name_p3), "` is out of this compiler; write its path, `&_.score.home`"));
        call_then(start_parse_reference(p2_p5), [=](std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> parse_reference_7673) {
        return ({
            auto [inner_p7, q_p8] = parse_reference_7673;
            auto callee_p6 = crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EName{name_p3})), .span = start_p2};
            (prism_rtl::finished(std::tuple{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ECall{prism_rtl::rc(callee_p6), Array(std::vector{crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = inner_p7, .span = prism_rtl::deref(inner_p7).span}}), false, false})), .span = crate::syntax::parser::to(start_p2, prism_rtl::deref(inner_p7).span)}, q_p8}));
        });
    });
    })
        : prism_rtl::finished(lens_steps(crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EName{name_p3})), .span = prism_rtl::deref(name_p3).span}, p1_p4)));
    });
    })
        : prism_rtl::finished(std::tuple{crate::syntax::parser::decls::no_expr(), crate::syntax::parser::fail(p_p0)});
    });
}


/// `Start ParseReference, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps>> start_parse_reference(crate::syntax::parser::Ps p_p0) {
    return prism_rtl::make_rc<ParseReference>(p_p0);
}


/// LensSteps: unbounded fn Expr, Ps -> ((Expr, Ps))
std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> lens_steps(const crate::syntax::Expr& e0_p0, const crate::syntax::parser::Ps& p0_p1) {
    std::tuple<crate::syntax::Expr, crate::syntax::parser::Ps> this_ = std::tuple{e0_p0, p0_p1};
    crate::syntax::Expr e_p2 = e0_p0;
    crate::syntax::parser::Ps p_p3 = p0_p1;
    bool going_p4 = true;
    while (std::move(going_p4) && (!p_p3.bad)) {
        ({
            __label__ _done;
            prism_rtl::Slot<Unit> _v;
            auto&& _m = crate::syntax::parser::kind(p_p3);
            if (prism_rtl::is<crate::syntax::lexer::TokKind::KDot>(_m) && !prism_rtl::as<crate::syntax::lexer::TokKind::KDot>(_m).a0) {
                _v.set(({
                    auto p1_p5 = crate::syntax::parser::adv(p_p3);
                    auto t_p6 = crate::syntax::parser::here(p1_p5);
                    ({
                        __label__ _done;
                        prism_rtl::Slot<Unit> _v;
                        auto&& _m = crate::syntax::parser::kind(p1_p5);
                        if (prism_rtl::is<crate::syntax::lexer::TokKind::KName>(_m)) {
                            auto&& f_p7 = prism_rtl::as<crate::syntax::lexer::TokKind::KName>(_m).a0;
                            if ((prism_rtl::deref(f_p7).sigils == Text::lit("")) && (prism_rtl::deref(f_p7).case_ == crate::syntax::lexer::NameCase(crate::syntax::lexer::NameCase::CaseLower{}))) {
                                _v.set(({
                                    e_p2 = crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EField{prism_rtl::rc(e_p2), Text::lit(""), crate::syntax::Ident{.name = or_(index(f_p7->path_, Nat(0u)), Text::lit("")), .span = t_p6}})), .span = crate::syntax::parser::to(e_p2.span, t_p6)};
                                    p_p3 = crate::syntax::parser::adv(p1_p5);
                                    Unit{};
                                }));
                                goto _done;
                            }
                        }
                        if (prism_rtl::is<crate::syntax::lexer::TokKind::KKw>(_m)) {
                            auto&& u8306_1_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KKw>(_m).a0;
                            if (u8306_1_0 == Text::lit("key")) {
                                _v.set(({
                                    e_p2 = crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EField{prism_rtl::rc(e_p2), Text::lit(""), crate::syntax::Ident{.name = Text::lit("key"), .span = t_p6}})), .span = crate::syntax::parser::to(e_p2.span, t_p6)};
                                    p_p3 = crate::syntax::parser::adv(p1_p5);
                                    Unit{};
                                }));
                                goto _done;
                            }
                        }
                        {
                            _v.set(({
                                p_p3 = crate::syntax::parser::fail(p1_p5);
                                Unit{};
                            }));
                            goto _done;
                        }
                    _done:
                        _v.take();
                    });
                    Unit{};
                }));
                goto _done;
            }
            if (prism_rtl::is<crate::syntax::lexer::TokKind::KOpen>(_m) && !prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(_m).a1) {
                auto&& u8187_1_0 = prism_rtl::as<crate::syntax::lexer::TokKind::KOpen>(_m).a0;
                if (u8187_1_0 == Text::lit("[")) {
                    if (prism_rtl::deref(crate::syntax::parser::tk(p_p3)).touches) {
                        _v.set(({
                            auto [index_p8, p1_p9] = crate::syntax::parser::expr::parse_expr(crate::syntax::parser::adv(p_p3));
                            auto p2_pa = crate::syntax::parser::expect_close(p1_p9, Text::lit("["));
                            e_p2 = crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EIndex{prism_rtl::rc(e_p2), prism_rtl::rc(index_p8)})), .span = crate::syntax::parser::to(e_p2.span, crate::syntax::parser::prev(p2_pa))};
                            p_p3 = p2_pa;
                            Unit{};
                        }));
                        goto _done;
                    }
                }
            }
            {
                _v.set(({
                    going_p4 = false;
                    Unit{};
                }));
                goto _done;
            }
        _done:
            _v.take();
        });
    }
    this_ = std::tuple{e_p2, p_p3};
    return this_;
}

}  // namespace crate::syntax::parser::blocks
