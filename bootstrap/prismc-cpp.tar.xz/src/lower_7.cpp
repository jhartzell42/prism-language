// The module `Lower`, from `target/bootstrap/cpp-src/prismc/lower.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (docs/backend.md). Edit the Prism source, not this file.
#include "lower.hpp"
#include "ast.hpp"
#include "check_env.hpp"
#include "check_errors.hpp"
#include "check_types.hpp"
#include "lexer.hpp"
#include "typed.hpp"
#include "lower.generic.hpp"
#include "check_env.generic.hpp"
#include "lexer.generic.hpp"

namespace crate::lower {

/// BlockReads: fn [Read] -> [Read]
Array<Read> block_reads(const Array<Read>& reads) {
    return fold(reads, Array<Read>{}, [&](const Array<Read>& acc, const Read& r) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Read>> _v;
            if (prism_rtl::is<Read::ParentRead>(r)) {
                auto&& f = prism_rtl::as<Read::ParentRead>(r).a0;
                _v.set(add_read(acc, Read(Read::OwnRead{f})));
                goto _done;
            }
            if (prism_rtl::is<Read::OwnRead>(r)) {
                _v.set(acc);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
}


/// RowLocals: unbounded fn Env, Env, Block -> [RowLocal]
Array<RowLocal> row_locals(const Env& benv, const Env& menv, const ast::Block& body) {
    return fold(read_names(typed::block_exprs(body)), Array<RowLocal>{}, [&](const Array<RowLocal>& acc, const Text& n) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<RowLocal>> _v;
            auto&& _m = prelude::get(menv->names, n);
            if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m))) {
                auto&& rs = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                auto&& mode = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a1;
                auto&& t = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                _v.set(({
                    auto field = snake(n);
                    (((field == Text::lit("key")) || (field == Text::lit("value"))) || (field == Text::lit("parent"))) || (field == Text::lit("path"))
                    ? acc
                    : prelude::push(acc, RowLocal{.name = n, .field = field, .ty = t, .passed = own(Vl(Vl::VlPlace{rs, mode, t}))});
                }));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


/// ForEnvs: unbounded fn Env, Env, ?ForBinders, Bn, Bn, Bn, Bn, OutTy -> ((Env, Env))
std::tuple<Env, Env> for_envs(const Env& benv, const Env& menv, const std::optional<ast::ForBinders>& binders_opt, const Bn& key_b, const Bn& key_m, const Bn& val_b, const Bn& val_m, const OutTy& vt) {
    auto be0 = bind(bind(benv, Text::lit("key"), key_b), Text::lit("$_"), val_b);
    auto me0 = bind(bind(menv, Text::lit("key"), key_m), Text::lit("$_"), val_m);
    if (prism_rtl::is_none(binders_opt)) {
        return std::tuple{be0, me0};
    }
    if (prism_rtl::is_some(binders_opt)) {
        auto&& fb = prism_rtl::some_of(binders_opt);
        auto&& _m = fb.second;
        if (prism_rtl::is_some(_m)) {
            auto&& second = prism_rtl::some_of(_m);
            auto be1 = bind_pat(be0, fb.first, key_b, Ex(Ex::XVar{Text::lit("key")}), kt0());
            auto me1 = bind_pat(me0, fb.first, key_m, Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), Text::lit("key")}), kt0());
            return std::tuple{bind_pat(be1, second, val_b, Ex(Ex::XVar{Text::lit("value")}), vt), bind_pat(me1, second, val_m, Ex(Ex::XUnit{}), vt)};
        }
        if (prism_rtl::is_none(_m)) {
            return std::tuple{bind_pat(be0, fb.first, val_b, Ex(Ex::XVar{Text::lit("value")}), vt), bind_pat(me0, fb.first, val_m, Ex(Ex::XUnit{}), vt)};
        }
        prism_rtl::unreachable("no arm matched");
    }
    prism_rtl::unreachable("no arm matched");
}


/// let kt0
OutTy kt0() {
    return OutTy(OutTy::OutUnit{});
}


/// BindPat: fn Env, Pattern, Bn, Ex, OutTy -> Env
Env bind_pat(const Env& env, const ast::Pattern_& p_, const Bn& b, const Ex& whole, const OutTy& t) {
    auto&& _m = p_.kind;
    if (prism_rtl::is<ast::PatternKind::PName>(_m)) {
        auto&& n = prism_rtl::as<ast::PatternKind::PName>(_m).a0;
        return bind(env, check_env::sname_key(n), b);
    }
    if (prism_rtl::is<ast::PatternKind::PGroup>(_m)) {
        auto&& q = prism_rtl::as<ast::PatternKind::PGroup>(_m).a0;
        return bind_pat(env, q, b, whole, t);
    }
    if (prism_rtl::is<ast::PatternKind::PTuple>(_m)) {
        auto&& ps = prism_rtl::as<ast::PatternKind::PTuple>(_m).a0;
        auto ts = ({
            __label__ _done;
            prism_rtl::Slot<Array<OutTy>> _v;
            if (prism_rtl::is<OutTy::OutTuple>(t)) {
                auto&& xs = prism_rtl::as<OutTy::OutTuple>(t).a0;
                _v.set(xs);
                goto _done;
            }
            {
                _v.set(Array<OutTy>{});
                goto _done;
            }
        _done:
            _v.take();
        });
        return fold(check_errors::range0(len(ps)), env, [&](const Env& en, const Nat& i) {
            return ({
                __label__ _done;
                prism_rtl::Slot<Env> _v;
                auto&& _m = index(ps, i);
                if (prism_rtl::is_some(_m)) {
                    auto&& q = prism_rtl::some_of(_m);
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<Env> _v;
                        auto&& _m = q.kind;
                        if (prism_rtl::is<ast::PatternKind::PName>(_m)) {
                            auto&& n = prism_rtl::as<ast::PatternKind::PName>(_m).a0;
                            _v.set(bind(en, check_env::sname_key(n), part_bn(b, whole, i, or_(index(ts, i), OutTy(OutTy::OutUnit{})))));
                            goto _done;
                        }
                        {
                            _v.set(en);
                            goto _done;
                        }
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(en);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
        });
    }
    {
        return env;
    }
}


/// PartBn: fn Bn, Ex, Nat, OutTy -> Bn
Bn part_bn(const Bn& bn0, const Ex& whole, const Nat& i, const OutTy& t) {
    if (prism_rtl::is<Bn::BnDyn>(bn0)) {
        auto&& x = prism_rtl::as<Bn::BnDyn>(bn0).a0;
        auto&& rds = prism_rtl::as<Bn::BnDyn>(bn0).a1;
        return Bn(Bn::BnDyn{Ex(Ex::XPart{prism_rtl::rc(x), i}), rds, t});
    }
    {
        auto&& other = bn0;
        return Bn(Bn::BnLocal{Ex(Ex::XPart{prism_rtl::rc(whole), i}), Holding(Holding::Owned{}), t});
    }
}


/// RowSuffix: fn Wx -> Text
Text row_suffix(const Wx& wx) {
    auto n = len(wx->rows) + len(wx.pending);
    return n == Nat(0u) ? Text::lit("") : prism_rtl::cat(n);
}


/// GnTyNamed: fn Wx, Text -> OutTy
OutTy gn_ty_named(const Wx& wx, const Text& n) {
    return fold(wx.gns, OutTy(OutTy::OutUnit{}), [&](const OutTy& acc, const Gn& g) { return g.name == n ? g.ty : acc; });
}


/// RowEnv: unbounded fn Wx, Wx, Env, Block -> ((Wx, Wx, Env))
std::tuple<Wx, Wx, Env> row_env(const Wx& parent, const Wx& row_wx, const Env& menv, const ast::Block& body) {
    auto names = read_names(typed::block_exprs(body));
    return fold(names, std::tuple{parent, row_wx, empty_env()}, [&](const std::tuple<Wx, Wx, Env>& _p0, const Text& n) {
        auto&& p_ = std::get<0>(_p0);
        auto&& r = std::get<1>(_p0);
        auto&& env = std::get<2>(_p0);
        return ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<Wx, Wx, Env>> _v;
            auto&& _m = prelude::get(menv->names, n);
            if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m))) {
                auto&& rs = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                auto&& mode = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a1;
                auto&& t = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                _v.set(std::tuple{p_, r, bind(env, n, Bn(Bn::BnLocal{over_parent(rs), Holding(Holding::Owned{}), t}))});
                goto _done;
            }
            if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnEv>(prism_rtl::some_of(_m))) {
                auto&& er = prism_rtl::as<Bn::BnEv>(prism_rtl::some_of(_m)).a0;
                auto&& t = prism_rtl::as<Bn::BnEv>(prism_rtl::some_of(_m)).a1;
                _v.set(({
                    auto pname = gn_of(p_, er.node_).name;
                    auto [rs, r1] = fresh_name(r, snake(n));
                    auto [id, r2] = add_gn(r1, rs, t, GnKind(GnKind::GnPort{}), Nat(0u));
                    auto r3 = ({
                        Wx this_ = r2;
                        this_.subs = prelude::push(this_.subs, std::tuple{pname, rs, t});
                        this_;
                    });
                    auto p2 = check_types::has_text(p_.ports, pname)
                        ? p_
                        : connect(with_port(p_, pname), ev_ref_of(p_, er.node_), Sk(Sk::SkPort{pname}));
                    std::tuple{p2, r3, bind(env, n, Bn(Bn::BnEv{ev_ref_of(r3, id), t}))};
                }));
                goto _done;
            }
            if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnDyn>(prism_rtl::some_of(_m)) && prism_rtl::is<Ex::XMethod>(prism_rtl::as<Bn::BnDyn>(prism_rtl::some_of(_m)).a0)) {
                auto&& recv = prism_rtl::as<Ex::XMethod>(prism_rtl::as<Bn::BnDyn>(prism_rtl::some_of(_m)).a0).a0;
                auto&& m = prism_rtl::as<Ex::XMethod>(prism_rtl::as<Bn::BnDyn>(prism_rtl::some_of(_m)).a0).a1;
                auto&& xs = prism_rtl::as<Ex::XMethod>(prism_rtl::as<Bn::BnDyn>(prism_rtl::some_of(_m)).a0).a2;
                auto&& t = prism_rtl::as<Bn::BnDyn>(prism_rtl::some_of(_m)).a2;
                _v.set(recv == Ex(Ex::XSelf{})
                    ? std::tuple{p_, r, bind(env, n, Bn(Bn::BnDyn{Ex(Ex::XMethod{prism_rtl::rc(parent_ref()), m, xs}), Array(std::vector{Read(Read::ParentRead{m})}), t}))}
                    : std::tuple{p_, r, env});
                goto _done;
            }
            if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnHold>(prism_rtl::some_of(_m))) {
                auto&& f = prism_rtl::as<Bn::BnHold>(prism_rtl::some_of(_m)).a0;
                auto&& t = prism_rtl::as<Bn::BnHold>(prism_rtl::some_of(_m)).a1;
                _v.set(std::tuple{p_, r, bind(env, n, Bn(Bn::BnDyn{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(parent_ref()), f})), Text::lit("get"), Array(std::vector{Ex(Ex::XCx{})})}), Array(std::vector{Read(Read::ParentRead{f})}), t}))});
                goto _done;
            }
            {
                _v.set(std::tuple{p_, r, env});
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


/// OverParent: fn Ex -> Ex
Ex over_parent(const Ex& x) {
    if (prism_rtl::is<Ex::XSelf>(x)) {
        return parent_ref();
    }
    if (prism_rtl::is<Ex::XField>(x)) {
        auto&& y = prism_rtl::as<Ex::XField>(x).a0;
        auto&& f = prism_rtl::as<Ex::XField>(x).a1;
        return Ex(Ex::XField{prism_rtl::rc(over_parent(y)), f});
    }
    if (prism_rtl::is<Ex::XPart>(x)) {
        auto&& y = prism_rtl::as<Ex::XPart>(x).a0;
        auto&& k = prism_rtl::as<Ex::XPart>(x).a1;
        return Ex(Ex::XPart{prism_rtl::rc(over_parent(y)), k});
    }
    if (prism_rtl::is<Ex::XMethod>(x)) {
        auto&& y = prism_rtl::as<Ex::XMethod>(x).a0;
        auto&& m = prism_rtl::as<Ex::XMethod>(x).a1;
        auto&& xs = prism_rtl::as<Ex::XMethod>(x).a2;
        return Ex(Ex::XMethod{prism_rtl::rc(over_parent(y)), m, xs});
    }
    if (prism_rtl::is<Ex::XUpgrade>(x)) {
        auto&& y = prism_rtl::as<Ex::XUpgrade>(x).a0;
        return Ex(Ex::XUpgrade{prism_rtl::rc(over_parent(y))});
    }
    {
        return Ex(Ex::XField{prism_rtl::rc(parent_ref()), place_stem(x)});
    }
}


/// let parentRef
Ex parent_ref() {
    return Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XUpgrade{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), Text::lit("parent")}))})), Text::lit("expect"), Array(std::vector{Ex(Ex::XStr{Text::lit("the block outlives its rows")})})});
}


/// let parentArg
Ex parent_arg() {
    return Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XUpgrade{prism_rtl::rc(Ex(Ex::XVar{Text::lit("parent")}))})), Text::lit("expect"), Array(std::vector{Ex(Ex::XStr{Text::lit("the block outlives its rows")})})});
}


/// WithPort: fn Wx, Text -> Wx
Wx with_port(const Wx& wx, const Text& pname) {
    Wx this_ = wx;
    this_.ports = prelude::push(this_.ports, pname);
    return this_;
}


/// RebuildLine: unbounded fn Wx, Env, Env, Expr, Block, Expr, ?Bn -> ((Wx, Wres))
std::tuple<Wx, Wres> rebuild_line(const Wx& wx, const Env& benv, const Env& menv, const ast::Expr& scrut, const ast::Block& body, const ast::Expr& e, const std::optional<Bn>& bound_opt) {
    auto lx = wx.lx;
    auto pos = wx.pos;
    auto wx1 = ({
        Wx this_ = wx;
        this_.pos = next_pos(this_.pos);
        this_;
    });
    auto [src_ex, reads] = dynamic_expr(wx1, menv, scrut);
    auto vt = out_ty_of(lx, peel(type_at(lx, scrut.span)));
    auto [name, wx2] = fresh_name(wx1, Text::lit("generation"));
    return gives_dynamic(type_at(lx, e.span))
        ? rebuild_dynamic(wx2, menv, body, src_ex, reads, vt, name, pos)
        : ({
        auto [up_id, wx3] = ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<Nat, Wx>> _v;
            if (prism_rtl::is_some(bound_opt) && prism_rtl::is<Bn::BnEv>(prism_rtl::some_of(bound_opt))) {
                auto&& er = prism_rtl::as<Bn::BnEv>(prism_rtl::some_of(bound_opt)).a0;
                _v.set(std::tuple{er.node_, wx2});
                goto _done;
            }
            {
                _v.set(add_gn(wx2, prism_rtl::cat(name, "_fired"), out_ty_of(lx, peel(type_at(lx, e.span))), GnKind(GnKind::GnNamed{}), Nat(0u)));
                goto _done;
            }
        _done:
            _v.take();
        });
        auto [cases, wx4] = gen_cases(wx3, menv, body, vt, name);
        auto row_defs = each(cases, [&](const GenCase& c) { return c.node_; });
        auto select = gen_select(wx4, menv, body, cases, pos);
        auto wx5 = ({
            Wx this_ = wx4;
            this_.gens = prelude::push(this_.gens, GenDef{.name = name, .pos = pos, .at = place_at(wx, Text::lit("self"), pos), .source = src_ex, .value_ty = vt, .select = select, .transparent = false, .width = Nat(0u)});
            this_.gen_holds = prelude::push(this_.gen_holds, std::tuple{name, reads});
            this_.rows = fold(row_defs, this_.rows, [&](const Array<NodeDef>& acc, const NodeDef& rd) { return append(prelude::push(acc, rd), rd.children); });
            this_.getters = prelude::push(this_.getters, gen_up(name, gn_of(wx4, up_id).name, gn_of(wx4, up_id).ty));
            this_;
        });
        std::tuple{wx5, Wres(Wres::WrEv{ev_ref_of(wx5, up_id)})};
    });
}


prism_rtl::Turn<std::tuple<Wx, Wres>> RebuildLine::cycle() const {
    const auto& wx = this->wx;
    const auto& benv = this->benv;
    const auto& menv = this->menv;
    const auto& scrut = this->scrut;
    const auto& body = this->body;
    const auto& e = this->e;
    const auto& bound_opt = this->bound_opt;
    auto lx = wx.lx;
    auto pos = wx.pos;
    auto wx1 = ({
        Wx this_ = wx;
        this_.pos = next_pos(this_.pos);
        this_;
    });
    auto bound_opt_1 = bound_opt;
    auto body_2 = body;
    auto e_3 = e;
    auto menv_4 = menv;
    auto scrut_5 = scrut;
    auto wx_6 = wx;
    return call_then(start_dynamic_expr(wx1, menv_4, scrut_5), [=](std::tuple<Ex, Array<Read>> dynamic_expr_364110) {
        return ({
            auto [src_ex, reads] = dynamic_expr_364110;
            call_then(start_out_ty_of(lx, peel(type_at(lx, scrut_5.span))), [=](OutTy out_ty_of_364152) {
            return ({
                auto vt = out_ty_of_364152;
                auto [name, wx2] = fresh_name(wx1, Text::lit("generation"));
                gives_dynamic(type_at(lx, e_3.span))
                ? prism_rtl::finished(rebuild_dynamic(wx2, menv_4, body_2, src_ex, reads, vt, name, pos))
                : ({
                auto [up_id, wx3] = ({
                    __label__ _done;
                    prism_rtl::Slot<std::tuple<Nat, Wx>> _v;
                    if (prism_rtl::is_some(bound_opt) && prism_rtl::is<Bn::BnEv>(prism_rtl::some_of(bound_opt))) {
                        auto&& er = prism_rtl::as<Bn::BnEv>(prism_rtl::some_of(bound_opt)).a0;
                        _v.set(std::tuple{er.node_, wx2});
                        goto _done;
                    }
                    {
                        _v.set(add_gn(wx2, prism_rtl::cat(name, "_fired"), out_ty_of(lx, peel(type_at(lx, e_3.span))), GnKind(GnKind::GnNamed{}), Nat(0u)));
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                auto [cases, wx4] = gen_cases(wx3, menv_4, body_2, vt, name);
                auto row_defs = each(cases, [&](const GenCase& c) { return c.node_; });
                auto select = gen_select(wx4, menv_4, body_2, cases, pos);
                auto wx5 = ({
                    Wx this_ = wx4;
                    this_.gens = prelude::push(this_.gens, GenDef{.name = name, .pos = pos, .at = place_at(wx_6, Text::lit("self"), pos), .source = src_ex, .value_ty = vt, .select = select, .transparent = false, .width = Nat(0u)});
                    this_.gen_holds = prelude::push(this_.gen_holds, std::tuple{name, reads});
                    this_.rows = fold(row_defs, this_.rows, [&](const Array<NodeDef>& acc, const NodeDef& rd) { return append(prelude::push(acc, rd), rd.children); });
                    this_.getters = prelude::push(this_.getters, gen_up(name, gn_of(wx4, up_id).name, gn_of(wx4, up_id).ty));
                    this_;
                });
                (prism_rtl::finished(std::tuple{wx5, Wres(Wres::WrEv{ev_ref_of(wx5, up_id)})}));
            });
            });
        });
        });
    });
}


/// `Start RebuildLine, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Wx, Wres>> start_rebuild_line(Wx wx, Env benv, Env menv, ast::Expr scrut, ast::Block body, ast::Expr e, std::optional<Bn> bound_opt) {
    return prism_rtl::make_rc<RebuildLine>(wx, benv, menv, scrut, body, e, bound_opt);
}


/// GivesDynamic: fn Ty -> Bool
bool gives_dynamic(const check_types::Ty& t) {
    if (prism_rtl::is<check_types::Ty::TySig>(t)) {
        auto&& m365371_0_0 = prism_rtl::as<check_types::Ty::TySig>(t).a0;
        auto&& m365371_0_1 = prism_rtl::as<check_types::Ty::TySig>(t).a1;
        if (m365371_0_0 == Text::lit("$")) {
            if (prism_rtl::is<check_types::Ty::TySig>(m365371_0_1)) {
                auto&& m365371_0_1_r_0 = prism_rtl::as<check_types::Ty::TySig>(m365371_0_1).a0;
                if (m365371_0_1_r_0 == Text::lit("$")) {
                    return true;
                }
            }
        }
    }
    if (prism_rtl::is<check_types::Ty::TyAt>(t)) {
        auto&& i = prism_rtl::as<check_types::Ty::TyAt>(t).a0;
        return gives_dynamic(i);
    }
    {
        return false;
    }
}


/// RebuildDynamic: unbounded fn Wx, Env, Block, Ex, [Read], OutTy, Text, Pos -> ((Wx, Wres))
std::tuple<Wx, Wres> rebuild_dynamic(const Wx& wx, const Env& menv, const ast::Block& body, const Ex& src_ex, const Array<Read>& reads, const OutTy& vt, const Text& name, const Pos_& pos) {
    auto row_name = prism_rtl::cat(wx.node_, "Gen", row_suffix(wx));
    auto whole = gen_row_of(wx, menv, body, vt, row_name, name);
    auto&& _m = whole.dyn_result;
    if (prism_rtl::is_none(_m)) {
        auto wx2 = ({
            Wx this_ = whole->parent;
            this_.build = prelude::push(this_.build, refusal_do(Text::lit("a `rebuild` whose generation gives a dynamic it does not lower")));
            this_;
        });
        return std::tuple{wx2, Wres(Wres::WrUnit{})};
    }
    if (prism_rtl::is_some(_m)) {
        auto&& rt = prism_rtl::some_of(_m);
        auto dyn_ty = OutTy(OutTy::OutDyn{prism_rtl::rc(rt)});
        auto result = prism_rtl::cat(name, "_result");
        auto live = prism_rtl::cat(result, "_live");
        auto what = prism_rtl::cat("the dynamic of the `rebuild` at place ", place_text(pos));
        auto tail_ = append(append(Array(std::vector{Ex(Ex::XWeak{prism_rtl::rc(Ex(Ex::XSelf{}))})}), hosted_passed(wx)), Array(std::vector{Ex(Ex::XCx{})}));
        auto built = try_of(Ex(Ex::XCall{prism_rtl::cat(whole.node_.name, "::build"), append(Array(std::vector{Ex(Ex::XVar{Text::lit("path")}), Ex(Ex::XVar{Text::lit("value")})}), tail_)}));
        auto kept = Do(Do::DoAssign{Ex(Ex::XDeref{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), live})), Text::lit("borrow_mut"), Array<Ex>{}}))}), Ex(Ex::XCtor{Text::lit("Some"), Array(std::vector{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text::lit("row")})), Text::lit("result_dynamic"), Array<Ex>{}})})})});
        auto marked = Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(result, "_snap")})), Text::lit("mark"), Array(std::vector{Ex(Ex::XCx{})})})});
        auto select = Ex(Ex::XBlock{Array(std::vector{Do(Do::DoLet{Pa(Pa::PaBind{Text::lit("row")}), built}), kept, marked}), prism_rtl::rc(Ex(Ex::XVar{Text::lit("row")}))});
        auto current = Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(live)})), Text::lit("borrow"), Array<Ex>{}}))})), Text::lit("expect"), Array(std::vector{Ex(Ex::XStr{Text::lit("a `rebuild` has a generation from its build on")})})});
        auto wx2 = ({
            Wx this_ = whole->parent;
            this_.gens = prelude::push(this_.gens, GenDef{.name = name, .pos = pos, .at = place_at(wx, Text::lit("self"), pos), .source = src_ex, .value_ty = vt, .select = select, .transparent = false, .width = Nat(0u)});
            this_.gen_holds = prelude::push(this_.gen_holds, std::tuple{name, reads});
            this_.rows = append(prelude::push(this_.rows, whole.node_), whole.node_.children);
            this_.taken = append(this_.taken, Array(std::vector{result, live, prism_rtl::cat(result, "_now"), prism_rtl::cat(result, "_snap"), prism_rtl::cat(result, "_publish"), prism_rtl::cat(result, "_moved")}));
            this_.fields = append(this_.fields, Array(std::vector{std::tuple{live, OutTy(OutTy::OutCell{prism_rtl::rc(OutTy(OutTy::OutOpt{prism_rtl::rc(dyn_ty)}))}), Text::lit("the current generation's result, which the snapshot of the `rebuild`'s dynamic is taken from")}, std::tuple{prism_rtl::cat(result, "_snap"), OutTy(OutTy::OutSnapshot{prism_rtl::rc(dyn_ty)}), prism_rtl::cat("the `rebuild` at place ", place_text(pos), "'s dynamic, structural: its snapshots, the generations' results and the lagged dynamic (pick ST)")}}));
            this_.moves = prelude::push(this_.moves, std::tuple{live, Ex(Ex::XCall{Text::lit("RefCell::new"), Array(std::vector{Ex(Ex::XNone{})})})});
            this_.inits = prelude::push(this_.inits, std::tuple{prism_rtl::cat(result, "_snap"), Ex(Ex::XCall{Text::lit("Snapshot::new"), Array(std::vector{Ex(Ex::XStr{what})})})});
            this_.getters = append(this_.getters, Array(std::vector{MethDef{.name = prism_rtl::cat(result, "_now"), .recv = Recv(Recv::RecvRef{}), .params = Array<std::tuple<Text, OutTy>>{}, .cx_ = CxArg(CxArg::CxRef{}), .ret = dyn_ty, .body = Array<Do>{}, .tail = current, .doc = Text::lit("The current generation's result: what the snapshot of the `rebuild`'s dynamic is taken from (pick ST).")}, snap_getter(result, dyn_ty, Text::lit("The `rebuild`'s dynamic, its generation's result, a structural dynamic (pick ST): one tick behind the generations, the snapshot of the tick before the tick the read point is after."))}));
            this_.snaps = prelude::push(this_.snaps, SnapDef{.name = result, .live = prism_rtl::cat(result, "_now"), .ty = dyn_ty, .eq = false, .builder = name, .before = false, .what = what});
            this_;
        });
        return std::tuple{wx2, Wres(Wres::WrDyn{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XSelf{})), result, Array(std::vector{Ex(Ex::XCx{})})}), Array(std::vector{Read(Read::OwnRead{result})}), dyn_ty})};
    }
    prism_rtl::unreachable("no arm matched");
}


/// ClauseWidgetLine: unbounded fn Wx, Env, Expr, Block, Text, ValInfo, Expr -> ((Wx, Wres))
std::tuple<Wx, Wres> clause_widget_line(const Wx& wx, const Env& menv, const ast::Expr& scrut, const ast::Block& call, const Text& qk, const check_env::ValInfo& v_, const ast::Expr& e) {
    auto lx = wx.lx;
    auto pos = wx.pos;
    auto [src_ex, reads] = dynamic_expr(wx, menv, scrut);
    auto vt = out_ty_of(lx, peel(type_at(lx, scrut.span)));
    auto [name, wx1] = fresh_name(wx, Text::lit("generation"));
    auto [up_id, wx2] = add_gn(wx1, prism_rtl::cat(name, "_fired"), out_ty_of(lx, peel(type_at(lx, e.span))), GnKind(GnKind::GnNamed{}), Nat(0u));
    auto clauses = clauses_of(lx.g, qk);
    auto row_name = prism_rtl::cat(wx.node_, "Gen", row_suffix(wx));
    auto [rows, wx3] = run_to_end(fold_job(check_errors::range0(len(clauses)), std::tuple{Array<ClauseRow>{}, wx2}, ({
        auto clauses_1 = clauses;
        auto menv_2 = menv;
        auto v__3 = v_;
        auto row_name_4 = row_name;
        auto name_5 = name;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<ClauseRow>, Wx>>(std::tuple<std::tuple<Array<ClauseRow>, Wx>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<ClauseRow>, Wx>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto clauses_1_6 = clauses_1;
            auto menv_2_6 = menv_2;
            auto v__3_6 = v__3;
            auto row_name_4_6 = row_name_4;
            auto name_5_6 = name_5;
            entered(once_job([=]() {
            return ({
                auto [acc, w] = p0;
                auto i = p1;
                ({
                auto c = or_(index(clauses_1_6, i), dummy_clause());
                auto cr = clause_row_of(w, menv_2_6, c, v__3_6, prism_rtl::cat(row_name_4_6, i), name_5_6, true);
                (prism_rtl::finished(std::tuple{prelude::push(acc, cr), cr->parent}));
            });
            });
        }));
        });
    }));
    })));
    auto width = fold(rows, Nat(0u), [&](const Nat& acc, const ClauseRow& cr) { return prelude::max(acc, cr.width); });
    auto cases = each(rows, [&](const ClauseRow& cr) { return cr.case_; });
    return is_hosted_scope(wx)
        ? ({
        auto wx4 = ({
            Wx this_ = wx3;
            this_.build = prelude::push(this_.build, refusal_do(Text::lit("a widget of several clauses in a static position of a hosted scope")));
            this_;
        });
        std::tuple{wx4, Wres(Wres::WrUnit{})};
    })
        : ({
        auto select = gen_select(wx3, menv, call, cases, pos);
        auto wx4 = ({
            Wx this_ = wx3;
            this_.pos = Pos_{.scope = pos.scope, .at = pos.at + width};
            this_.gens = prelude::push(this_.gens, GenDef{.name = name, .pos = pos, .at = place_at(wx, Text::lit("self"), pos), .source = src_ex, .value_ty = vt, .select = select, .transparent = true, .width = width});
            this_.gen_holds = prelude::push(this_.gen_holds, std::tuple{name, reads});
            this_.rows = fold(cases, this_.rows, [&](const Array<NodeDef>& acc, const GenCase& gc) { return append(prelude::push(acc, gc.node_), gc.node_.children); });
            this_.getters = prelude::push(this_.getters, gen_up(name, gn_of(wx3, up_id).name, gn_of(wx3, up_id).ty));
            this_;
        });
        std::tuple{wx4, Wres(Wres::WrEv{ev_ref_of(wx4, up_id)})};
    });
}


/// IsHostedScope: fn Wx -> Bool
bool is_hosted_scope(const Wx& wx) {
    return (wx.pos.scope > Nat(0u)) || prism_rtl::is_some(wx.hosted_by);
}


/// GenCases: unbounded fn Wx, Env, Block, OutTy, Text -> (([GenCase], Wx))
std::tuple<Array<GenCase>, Wx> gen_cases(const Wx& wx, const Env& menv, const ast::Block& body, const OutTy& vt, const Text& name) {
    auto lx = wx.lx;
    auto row_name = prism_rtl::cat(wx.node_, "Gen", row_suffix(wx));
    auto&& _m = clause_call(lx, body);
    if (prism_rtl::is_some(_m)) {
        auto&& qk = std::get<0>(prism_rtl::some_of(_m));
        auto&& args = std::get<1>(prism_rtl::some_of(_m));
        auto clauses = clauses_of(lx.g, qk);
        auto v_ = val_of(lx, qk);
        return run_to_end(fold_job(check_errors::range0(len(clauses)), std::tuple{Array<GenCase>{}, wx}, ({
            auto clauses_1 = clauses;
            auto menv_2 = menv;
            auto v__3 = v_;
            auto row_name_4 = row_name;
            auto name_5 = name;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<GenCase>, Wx>>(std::tuple<std::tuple<Array<GenCase>, Wx>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<GenCase>, Wx>, Nat> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto clauses_1_6 = clauses_1;
                auto menv_2_6 = menv_2;
                auto v__3_6 = v__3;
                auto row_name_4_6 = row_name_4;
                auto name_5_6 = name_5;
                entered(once_job([=]() {
                return ({
                    auto [acc, w] = p0;
                    auto i = p1;
                    ({
                    auto c = or_(index(clauses_1_6, i), dummy_clause());
                    auto cr = clause_row_of(w, menv_2_6, c, v__3_6, prism_rtl::cat(row_name_4_6, i), name_5_6, false);
                    (prism_rtl::finished(std::tuple{prelude::push(acc, cr.case_), cr->parent}));
                });
                });
            }));
            });
        }));
        })));
    }
    if (prism_rtl::is_none(_m)) {
        auto whole = gen_row_of(wx, menv, body, vt, row_name, name);
        return std::tuple{Array(std::vector{GenCase{.node_ = whole.node_, .params = Array(std::vector{std::tuple{Text::lit("value"), vt}}), .pat = Pa(Pa::PaWild{}), .conds = Array<Cc>{}, .passed = Array(std::vector{Ex(Ex::XVar{Text::lit("value")})})}}), whole->parent};
    }
    prism_rtl::unreachable("no arm matched");
}


/// ?ClauseCall: fn Lx, Block -> ?((Text, [Arg]))
std::optional<std::tuple<Text, Array<ast::Arg>>> clause_call(const Lx& lx, const ast::Block& body) {
    auto&& _m = body.stmts;
    {
        auto&& m373159_0 = _m;
        if (m373159_0.size() == 1u) {
            {
                auto&& _c1 = index(m373159_0, Nat(0u));
                if (prism_rtl::is_some(_c1)) {
                    auto&& st = prism_rtl::some_of(_c1);
                    auto&& _m = st.kind;
                    if (prism_rtl::is<ast::StmtKind::SExpr>(_m)) {
                        auto&& x = prism_rtl::as<ast::StmtKind::SExpr>(_m).a0;
                        return clause_call_x(lx, x);
                    }
                    if (prism_rtl::is<ast::StmtKind::SIgnore>(_m)) {
                        auto&& x = prism_rtl::as<ast::StmtKind::SIgnore>(_m).a0;
                        return clause_call_x(lx, x);
                    }
                    {
                        return std::optional<std::tuple<Text, Array<ast::Arg>>>{};
                    }
                }
            }
        }
    }
    {
        return std::optional<std::tuple<Text, Array<ast::Arg>>>{};
    }
}


/// ?ClauseCallX: fn Lx, Expr -> ?((Text, [Arg]))
std::optional<std::tuple<Text, Array<ast::Arg>>> clause_call_x(const Lx& lx, const ast::Expr& x) {
    auto&& _m = x.kind;
    if (prism_rtl::is<ast::ExprKind::ECall>(_m)) {
        auto&& c = prism_rtl::as<ast::ExprKind::ECall>(_m).a0;
        auto&& args = prism_rtl::as<ast::ExprKind::ECall>(_m).a1;
        auto qk = blueprint_qk(lx, c);
        return len(clauses_of(lx.g, qk)) > Nat(1u)
            ? std::optional(std::tuple{qk, args})
            : std::optional<std::tuple<Text, Array<ast::Arg>>>{};
    }
    {
        return std::optional<std::tuple<Text, Array<ast::Arg>>>{};
    }
}


/// ClauseRowOf: unbounded fn Wx, Env, FnClause, ValInfo, Text, Text, Bool -> ClauseRow
ClauseRow clause_row_of(const Wx& wx, const Env& menv, const ast::FnClause& c, const check_env::ValInfo& v_, const Text& row_name, const Text& gen_name, const bool& transparent) {
    auto up_name = prism_rtl::cat(gen_name, "_up");
    auto lx = wx.lx;
    auto lxc = in_module_at(lx, v_->file, v_.home, lx.site);
    auto ptys = ({
        __label__ _done;
        prism_rtl::Slot<Array<check_types::Ty>> _v;
        auto&& _m = v_.scheme.ty;
        if (prism_rtl::is<check_types::Ty::TyFn>(_m)) {
            auto&& ps = prism_rtl::as<check_types::Ty::TyFn>(_m).a1;
            _v.set(ps);
            goto _done;
        }
        {
            _v.set(Array<check_types::Ty>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto binders = run_to_end(fold_job(c.params, Array<std::tuple<Text, ast::Range>>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Text, ast::Range>>>(std::tuple<Array<std::tuple<Text, ast::Range>>, ast::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Array<std::tuple<Text, ast::Range>>, ast::Pattern_> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto p_ = p1;
                call_then(check_env::start_pattern_binders(p_), [=](Array<std::tuple<Text, ast::Range>> pattern_binders_374315) { return prism_rtl::finished(append(acc, pattern_binders_374315)); });
            });
        }));
    }))));
    auto fields = run_to_end(each_job(binders, ({
        auto lxc_1 = lxc;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, OutTy, Text>>(std::tuple<Text, ast::Range>)>>(prism_rtl::rc([=](std::tuple<Text, ast::Range> p0) {
        return ({
            auto lxc_1_2 = lxc_1;
            entered(once_job([=]() {
            return ({
                auto [bn, r] = p0;
                call_then(start_out_ty_of(lxc_1_2, peel(binder_ty(lxc_1_2, r))), [=](OutTy out_ty_of_374392) { return prism_rtl::finished(std::tuple{snake(bn), out_ty_of_374392, bn}); });
            });
        }));
        });
    }));
    })));
    auto row_fields = prelude::push(each(fields, [&](const std::tuple<Text, OutTy, Text>& _p0) {
        auto&& f = std::get<0>(_p0);
        auto&& t = std::get<1>(_p0);
        auto&& bn = std::get<2>(_p0);
        return std::tuple{f, t, prism_rtl::cat("`", bn, "`")};
    }), std::tuple{Text::lit("parent"), OutTy(OutTy::OutWeak{wx.node_}), Text::lit("the node of the `rebuild`")});
    auto row_inits = each(fields, [&](const std::tuple<Text, OutTy, Text>& _p0) {
        auto&& f = std::get<0>(_p0);
        return std::tuple{f, Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{f}))})};
    });
    auto row_taken = append(node_hooks(), prelude::push(each(fields, [&](const std::tuple<Text, OutTy, Text>& _p0) {
        auto&& f = std::get<0>(_p0);
        return f;
    }), Text::lit("parent")));
    auto r00 = new_wx(lxc, row_name, row_fields, row_inits, Array(std::vector{std::tuple{Text::lit("parent"), Ex(Ex::XVar{Text::lit("parent")})}}), Array<MethDef>{}, Map<Text, Array<Read>>{}, row_taken, wx.depth, hosted_rows(wx));
    auto r0 = transparent
        ? ({
        Wx this_ = r00;
        this_.pos = wx.pos;
        this_;
    })
        : r00;
    auto body = ({
        __label__ _done;
        prism_rtl::Slot<ast::Block> _v;
        auto&& _m = c.body;
        if (prism_rtl::is<ast::FnBody::BodyBlock>(_m)) {
            auto&& b = prism_rtl::as<ast::FnBody::BodyBlock>(_m).a0;
            _v.set(b);
            goto _done;
        }
        if (prism_rtl::is<ast::FnBody::BodyExpr>(_m)) {
            auto&& x = prism_rtl::as<ast::FnBody::BodyExpr>(_m).a0;
            _v.set(ast::Block{.stmts = Array(std::vector{ast::Stmt{.kind = ast::StmtKind(ast::StmtKind::SExpr{x}), .span = x.span}}), .inline_ = true, .span = x.span});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto [p1, r1, ports] = row_env(wx, r0, menv, body);
    auto [be, me] = fold(fields, std::tuple{empty_env(), empty_env()}, [&](const std::tuple<Env, Env>& _p0, const std::tuple<Text, OutTy, Text>& _p1) {
        auto&& b = std::get<0>(_p0);
        auto&& m = std::get<1>(_p0);
        auto&& f = std::get<0>(_p1);
        auto&& t = std::get<1>(_p1);
        auto&& bn = std::get<2>(_p1);
        return bind_plain(b, m, bn, f, t);
    });
    auto r2 = block_into(r1, be, me, body);
    auto r3 = ({
        __label__ _done;
        prism_rtl::Slot<Wx> _v;
        auto&& _m = r2->result;
        if (prism_rtl::is<Wres::WrEv>(_m)) {
            auto&& r = prism_rtl::as<Wres::WrEv>(_m).a0;
            _v.set(connect(r2, r, Sk(Sk::SkUp{up_name})));
            goto _done;
        }
        {
            _v.set(r2);
            goto _done;
        }
    _done:
        _v.take();
    });
    auto node_ = finish_node(r3, row_name, append(prelude::push(each(fields, [&](const std::tuple<Text, OutTy, Text>& _p0) {
        auto&& f = std::get<0>(_p0);
        auto&& t = std::get<1>(_p0);
        return std::tuple{f, t};
    }), std::tuple{Text::lit("parent"), OutTy(OutTy::OutWeak{wx.node_})}), hosted_params(wx)), true);
    auto p2 = gen_marked(p1, gen_name, r3);
    auto pos = run_to_end(each_job(check_errors::range0(len(c.params)), ({
        auto lxc_1 = lxc;
        auto c_2 = c;
        auto ptys_3 = ptys;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<PatOut>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto lxc_1_4 = lxc_1;
            auto c_2_4 = c_2;
            auto ptys_3_4 = ptys_3;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                (prism_rtl::more(prism_rtl::rc(RustPat(lxc_1_4, or_(index(c_2_4.params, i), dummy_pat()), or_(index(ptys_3_4, i), check_types::Ty(check_types::Ty::TyErr{})), Holding(Holding::ByRef{}), prism_rtl::cat("c", i)))));
            });
        }));
        });
    })));
    })));
    auto pa = Pa(Pa::PaTuple{each(pos, [&](const PatOut& o) { return o.pa; })});
    auto binds = fold(pos, Map<Text, Bn>{}, [&](const Map<Text, Bn>& m, const PatOut& o) {
        return fold(o.binds, m, [&](const Map<Text, Bn>& m2, const std::tuple<Text, Bn>& _p1) {
            auto&& n = std::get<0>(_p1);
            auto&& b = std::get<1>(_p1);
            return insert(m2, n, b);
        });
    });
    auto passed = each(fields, [&](const std::tuple<Text, OutTy, Text>& _p0) {
        auto&& f = std::get<0>(_p0);
        auto&& t = std::get<1>(_p0);
        auto&& bn = std::get<2>(_p0);
        return ({
            __label__ _done;
            prism_rtl::Slot<Ex> _v;
            auto&& _m = prelude::get(binds, bn);
            if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m))) {
                auto&& rs = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                auto&& mode = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a1;
                auto&& bt = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                _v.set(own(Vl(Vl::VlPlace{rs, mode, bt})));
                goto _done;
            }
            {
                _v.set(Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{f}))}));
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    return ClauseRow{.case_ = GenCase{.node_ = node_, .params = each(fields, [&](const std::tuple<Text, OutTy, Text>& _p0) {
        auto&& f = std::get<0>(_p0);
        auto&& t = std::get<1>(_p0);
        return std::tuple{f, t};
    }), .pat = pa, .conds = fold(pos, Array<Cc>{}, [&](const Array<Cc>& acc, const PatOut& o) { return append(acc, o.conds); }), .passed = passed}, .parent = p2, .width = or_(r2.pos.at.checked_sub(r0.pos.at), Nat(0u))};
}


/// GenRowOf: unbounded fn Wx, Env, Block, OutTy, Text, Text -> GenRow
GenRow gen_row_of(const Wx& wx, const Env& menv, const ast::Block& body, const OutTy& vt, const Text& row_name, const Text& gen_name) {
    auto lx = wx.lx;
    auto up_name = prism_rtl::cat(gen_name, "_up");
    auto r0 = new_wx(lx, row_name, Array(std::vector{std::tuple{Text::lit("value"), vt, Text::lit("the generation's value, `_`")}, std::tuple{Text::lit("parent"), OutTy(OutTy::OutWeak{wx.node_}), Text::lit("the node of the `rebuild`")}}), Array(std::vector{std::tuple{Text::lit("value"), Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{Text::lit("value")}))})}}), Array(std::vector{std::tuple{Text::lit("parent"), Ex(Ex::XVar{Text::lit("parent")})}}), Array<MethDef>{}, Map<Text, Array<Read>>{}, append(node_hooks(), Array(std::vector{Text::lit("value"), Text::lit("parent"), Text::lit("result"), Text::lit("result_dynamic")})), wx.depth, hosted_rows(wx));
    auto [p1, r1, ports] = row_env(wx, r0, menv, body);
    auto be = bind(build_spelling(ports), Text::lit("_"), Bn(Bn::BnLocal{Ex(Ex::XVar{Text::lit("value")}), Holding(Holding::Owned{}), vt}));
    auto me = bind(ports, Text::lit("_"), Bn(Bn::BnLocal{Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), Text::lit("value")}), Holding(Holding::Owned{}), vt}));
    auto r2 = block_into(r1, be, me, body);
    auto [r3, dyn_result_opt] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Wx, std::optional<OutTy>>> _v;
        auto&& _m = r2->result;
        if (prism_rtl::is<Wres::WrEv>(_m)) {
            auto&& r = prism_rtl::as<Wres::WrEv>(_m).a0;
            _v.set(std::tuple{connect(r2, r, Sk(Sk::SkUp{up_name})), std::optional<OutTy>{}});
            goto _done;
        }
        if (prism_rtl::is<Wres::WrDyn>(_m)) {
            auto&& ex = prism_rtl::as<Wres::WrDyn>(_m).a0;
            auto&& result_reads = prism_rtl::as<Wres::WrDyn>(_m).a1;
            auto&& rt = prism_rtl::as<Wres::WrDyn>(_m).a2;
            _v.set(std::tuple{gen_result(r2, gen_name, ex, result_reads, rt), std::optional(rt)});
            goto _done;
        }
        {
            _v.set(std::tuple{r2, std::optional<OutTy>{}});
            goto _done;
        }
    _done:
        _v.take();
    });
    return GenRow{.node_ = finish_node(r3, row_name, append(Array(std::vector{std::tuple{Text::lit("value"), vt}, std::tuple{Text::lit("parent"), OutTy(OutTy::OutWeak{wx.node_})}}), hosted_params(wx)), true), .parent = gen_marked(p1, gen_name, r3), .dyn_result = dyn_result_opt};
}


/// GenResult: fn Wx, Text, Ex, [Read], OutTy -> Wx
Wx gen_result(const Wx& r, const Text& gen_name, const Ex& ex, const Array<Read>& result_reads, const OutTy& rt) {
    auto own_behind = filter(reads_closed(r.dyn_reads, result_reads), [&](const Read& rd) {
        return ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            if (prism_rtl::is<Read::OwnRead>(rd)) {
                _v.set(true);
                goto _done;
            }
            if (prism_rtl::is<Read::ParentRead>(rd)) {
                _v.set(false);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
    auto made = Ex(Ex::XCall{Text::lit("Dynamic::of"), Array(std::vector{Ex(Ex::XClosure{true, Array(std::vector{Pa(Pa::PaBind{Text::lit("cx")})}), prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text::lit("me")})), Text::lit("result"), Array(std::vector{Ex(Ex::XCx{})})}))}), Ex(Ex::XRef{prism_rtl::rc(Ex(Ex::XCall{Text::lit("Rc::new"), Array(std::vector{Ex(Ex::XCall{Text::lit("Port::new"), Array<Ex>{}})})}))})})});
    auto doc = prism_rtl::cat("The generation's result as a dynamic, which the block keeps while the generation is current; the block hears it move through `", gen_name, "_result_moved`, not through the dynamic's port.");
    Wx this_ = r;
    this_.getters = append(this_.getters, Array(std::vector{MethDef{.name = Text::lit("result"), .recv = Recv(Recv::RecvRef{}), .params = Array<std::tuple<Text, OutTy>>{}, .cx_ = CxArg(CxArg::CxRef{}), .ret = rt, .body = Array<Do>{}, .tail = ex, .doc = Text::lit("The generation's result, which the `rebuild` hands back.")}, MethDef{.name = Text::lit("result_dynamic"), .recv = Recv(Recv::RecvRc{}), .params = Array<std::tuple<Text, OutTy>>{}, .cx_ = CxArg(CxArg::CxNone{}), .ret = OutTy(OutTy::OutDyn{prism_rtl::rc(rt)}), .body = Array(std::vector{Do(Do::DoLet{Pa(Pa::PaBind{Text::lit("me")}), Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XSelf{}))})})}), .tail = made, .doc = doc}}));
    this_.result_moved = len(own_behind) > Nat(0u)
        ? std::optional(std::tuple{prism_rtl::cat(gen_name, "_result_moved"), own_behind})
        : std::optional<std::tuple<Text, Array<Read>>>{};
    return this_;
}


/// GenMarked: fn Wx, Text, Wx -> Wx
Wx gen_marked(const Wx& parent, const Text& gen_name, const Wx& row_wx) {
    auto reads = row_place_reads(row_wx);
    return len(reads) == Nat(0u)
        ? parent
        : ({
        Wx this_ = parent;
        this_.row_marks = prelude::push(this_.row_marks, RowMarks{.builder = gen_name, .reads = reads, .wrote = Array<Text>{}, .kind = RowKind(RowKind::GenerationRow{})});
        this_;
    });
}


/// BuildSpelling: fn Env -> Env
Env build_spelling(const Env& env) {
    return fold(keys(env->names), env, [&](const Env& en, const Text& k) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Env> _v;
            auto&& _m = prelude::get(env->names, k);
            if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m))) {
                auto&& rs = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                auto&& mode = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a1;
                auto&& t = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Env> _v;
                    auto&& _m = through_parent(rs);
                    if (prism_rtl::is_some(_m)) {
                        auto&& x = prism_rtl::some_of(_m);
                        _v.set(bind(en, k, Bn(Bn::BnLocal{x, mode, t})));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(en);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnDyn>(prism_rtl::some_of(_m)) && prism_rtl::is<Ex::XMethod>(prism_rtl::as<Bn::BnDyn>(prism_rtl::some_of(_m)).a0)) {
                auto&& rs = prism_rtl::as<Ex::XMethod>(prism_rtl::as<Bn::BnDyn>(prism_rtl::some_of(_m)).a0).a0;
                auto&& m = prism_rtl::as<Ex::XMethod>(prism_rtl::as<Bn::BnDyn>(prism_rtl::some_of(_m)).a0).a1;
                auto&& xs = prism_rtl::as<Ex::XMethod>(prism_rtl::as<Bn::BnDyn>(prism_rtl::some_of(_m)).a0).a2;
                auto&& ds = prism_rtl::as<Bn::BnDyn>(prism_rtl::some_of(_m)).a1;
                auto&& t = prism_rtl::as<Bn::BnDyn>(prism_rtl::some_of(_m)).a2;
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Env> _v;
                    auto&& _m = through_parent(rs);
                    if (prism_rtl::is_some(_m)) {
                        auto&& x = prism_rtl::some_of(_m);
                        _v.set(bind(en, k, Bn(Bn::BnDyn{Ex(Ex::XMethod{prism_rtl::rc(x), m, xs}), ds, t})));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(en);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            {
                _v.set(en);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


/// GenSelect: unbounded fn Wx, Env, Block, [GenCase], Pos -> Ex
Ex gen_select(const Wx& wx, const Env& menv, const ast::Block& body, const Array<GenCase>& cases, const Pos_& pos) {
    auto tail_ = append(append(Array(std::vector{Ex(Ex::XWeak{prism_rtl::rc(Ex(Ex::XSelf{}))})}), hosted_passed(wx)), Array(std::vector{Ex(Ex::XCx{})}));
    auto&& _m = clause_call(wx.lx, body);
    if (prism_rtl::is_none(_m)) {
        auto&& _m = index(cases, Nat(0u));
        if (prism_rtl::is_some(_m)) {
            auto&& c = prism_rtl::some_of(_m);
            return try_of(Ex(Ex::XCall{prism_rtl::cat(c.node_.name, "::build"), append(Array(std::vector{Ex(Ex::XVar{Text::lit("path")}), Ex(Ex::XVar{Text::lit("value")})}), tail_)}));
        }
        if (prism_rtl::is_none(_m)) {
            return refusal(Text::lit("a `rebuild` with no generation"));
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is_some(_m)) {
        auto&& qk = std::get<0>(prism_rtl::some_of(_m));
        auto&& args = std::get<1>(prism_rtl::some_of(_m));
        auto env = bind(menv, Text::lit("_"), Bn(Bn::BnLocal{Ex(Ex::XVar{Text::lit("value")}), Holding(Holding::Owned{}), OutTy(OutTy::OutUnit{})}));
        auto scrut = Ex(Ex::XTuple{run_to_end(each_job(args, ({
            auto wx_1 = wx;
            auto env_2 = env;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(ast::Arg)>>(prism_rtl::rc([=](ast::Arg p0) {
            return ({
                auto wx_1_3 = wx_1;
                auto env_2_3 = env_2;
                entered(once_job([=]() {
                return ({
                    auto a = p0;
                    (prism_rtl::more(prism_rtl::rc(Argument(wx_1_3.lx, env_2_3, a->value))));
                });
            }));
            });
        })));
        })))});
        auto arms = each(cases, [&](const GenCase& c) {
            return ({
                auto made = try_of(Ex(Ex::XCall{prism_rtl::cat(c.node_.name, "::build"), append(append(Array(std::vector{Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{Text::lit("path")}))})}), c.passed), tail_)}));
                XArm{.pat = c.pat, .conds = c.conds, .body = Ex(Ex::XCast{prism_rtl::rc(made), OutTy(OutTy::OutObj{prism_rtl::rc(OutTy(OutTy::OutNamed{Text::lit("Row"), Array<OutTy>{}}))})})};
            });
        });
        return own(arms_value(scrut, arms, Text::lit("'select"), OutTy(OutTy::OutObj{prism_rtl::rc(OutTy(OutTy::OutNamed{Text::lit("Row"), Array<OutTy>{}}))})));
    }
    prism_rtl::unreachable("no arm matched");
}


/// GenUp: fn Text, Text, OutTy -> MethDef
MethDef gen_up(const Text& name, const Text& up_name, const OutTy& t) {
    return MethDef{.name = prism_rtl::cat(name, "_up"), .recv = Recv(Recv::RecvRc{}), .params = Array(std::vector{std::tuple{Text::lit("v"), t}}), .cx_ = CxArg(CxArg::CxMut{}), .ret = OutTy(OutTy::OutUnit{}), .body = Array(std::vector{self_call(up_name, Array(std::vector{Ex(Ex::XVar{Text::lit("v")})}))}), .tail = Ex(Ex::XUnit{}), .doc = Text::lit("The current generation's result fires the `rebuild`'s.")};
}


/// GenForwards: fn GenDef -> [((Pa, Ex))]
Array<std::tuple<Pa, Ex>> gen_forwards(const GenDef& gd) {
    return gd.transparent
        ? each(check_errors::range0(gd.width), [&](const Nat& i) {
        return ({
            auto current = Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(gd.name)})), Text::lit("borrow"), Array<Ex>{}}))});
            auto body = Ex(Ex::XBlock{Array(std::vector{Do(Do::DoLet{Pa(Pa::PaBind{Text::lit("row")}), current}), Do(Do::DoIfLet{Pa(Pa::PaCtor{Text::lit("Some"), Array(std::vector{Pa(Pa::PaBind{Text::lit("row")})})}), Ex(Ex::XVar{Text::lit("row")}), Array(std::vector{Do(Do::DoExpr{try_of(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text::lit("row")})), Text::lit("answer"), Array(std::vector{Ex(Ex::XVar{Text::lit("at")}), Ex(Ex::XVar{Text::lit("v")}), Ex(Ex::XCx{})})}))})}), Array<Do>{}})}), prism_rtl::rc(Ex(Ex::XUnit{}))});
            std::tuple{pos_pat(Pos_{.scope = gd.pos.scope, .at = gd.pos.at + i}, Array(std::vector{Pa(Pa::PaRest{Text::lit("")})})), body};
        });
    })
        : Array(std::vector{std::tuple{pos_pat(gd.pos, gen_tail()), forward_gen(gd)}});
}


/// ForwardGen: fn GenDef -> Ex
Ex forward_gen(const GenDef& gd) {
    auto current = Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(gd.name)})), Text::lit("borrow"), Array<Ex>{}}))});
    auto is_current = Ex(Ex::XBin{Text::lit("=="), prism_rtl::rc(Ex(Ex::XBin{Text::lit("+"), prism_rtl::rc(Ex(Ex::XDeref{prism_rtl::rc(Ex(Ex::XVar{Text::lit("g")}))})), prism_rtl::rc(Ex(Ex::XIndex{Nat(1u)}))})), prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(gd.name, "_count")})), Text::lit("get"), Array<Ex>{}}))});
    return Ex(Ex::XBlock{Array(std::vector{Do(Do::DoLet{Pa(Pa::PaBind{Text::lit("row")}), current}), Do(Do::DoIfLet{Pa(Pa::PaCtor{Text::lit("Some"), Array(std::vector{Pa(Pa::PaBind{Text::lit("row")})})}), Ex(Ex::XVar{Text::lit("row")}), Array(std::vector{Do(Do::DoIf{is_current, Array(std::vector{Do(Do::DoExpr{try_of(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text::lit("row")})), Text::lit("answer"), Array(std::vector{Ex(Ex::XVar{Text::lit("rest")}), Ex(Ex::XVar{Text::lit("v")}), Ex(Ex::XCx{})})}))})}), Array<Do>{}})}), Array<Do>{}})}), prism_rtl::rc(Ex(Ex::XUnit{}))});
}


/// FlattenLine: unbounded fn Wx, Env, [Arg], ?Bn -> ((Wx, Wres))
std::tuple<Wx, Wres> flatten_line(const Wx& wx, const Env& menv, const Array<ast::Arg>& args, const std::optional<Bn>& bound_opt) {
    auto outer_opt = ({
        __label__ _done;
        prism_rtl::Slot<std::optional<std::tuple<Text, Text, OutTy>>> _v;
        auto&& _m = index(args, Nat(0u));
        if (prism_rtl::is_some(_m)) {
            auto&& a = prism_rtl::some_of(_m);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::optional<std::tuple<Text, Text, OutTy>>> _v;
                auto&& _m = a->value.kind;
                if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
                    auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<std::optional<std::tuple<Text, Text, OutTy>>> _v;
                        auto&& _m = prelude::get(menv->names, check_env::sname_key(n));
                        if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnDyn>(prism_rtl::some_of(_m)) && prism_rtl::is<Ex::XMethod>(prism_rtl::as<Bn::BnDyn>(prism_rtl::some_of(_m)).a0) && prism_rtl::is<OutTy::OutDyn>(prism_rtl::as<Bn::BnDyn>(prism_rtl::some_of(_m)).a2)) {
                            auto&& m383330_0_0_0 = prism_rtl::as<Ex::XMethod>(prism_rtl::as<Bn::BnDyn>(prism_rtl::some_of(_m)).a0).a0;
                            auto&& m = prism_rtl::as<Ex::XMethod>(prism_rtl::as<Bn::BnDyn>(prism_rtl::some_of(_m)).a0).a1;
                            auto&& t = prism_rtl::as<OutTy::OutDyn>(prism_rtl::as<Bn::BnDyn>(prism_rtl::some_of(_m)).a2).a0;
                            if (prism_rtl::is<Ex::XSelf>(m383330_0_0_0)) {
                                _v.set(fold(wx.gens, std::optional<std::tuple<Text, Text, OutTy>>{}, [&](const std::optional<std::tuple<Text, Text, OutTy>>& acc_opt, const GenDef& gd) {
                                    return prism_rtl::cat(gd.name, "_result") == m
                                        ? std::optional(std::tuple{m, gd.name, t})
                                        : acc_opt;
                                }));
                                goto _done;
                            }
                        }
                        {
                            _v.set(std::optional<std::tuple<Text, Text, OutTy>>{});
                            goto _done;
                        }
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                {
                    _v.set(std::optional<std::tuple<Text, Text, OutTy>>{});
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(std::optional<std::tuple<Text, Text, OutTy>>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    if (prism_rtl::is_none(outer_opt)) {
        auto wx2 = ({
            Wx this_ = wx;
            this_.build = prelude::push(this_.build, refusal_do(Text::lit("`@Flatten` of a dynamic that is not a `rebuild`'s")));
            this_;
        });
        return std::tuple{wx2, Wres(Wres::WrUnit{})};
    }
    if (prism_rtl::is_some(outer_opt)) {
        auto&& m = std::get<0>(prism_rtl::some_of(outer_opt));
        auto&& gen_ = std::get<1>(prism_rtl::some_of(outer_opt));
        auto&& t = std::get<2>(prism_rtl::some_of(outer_opt));
        auto [name, wx1] = ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<Text, Wx>> _v;
            if (prism_rtl::is_some(bound_opt) && prism_rtl::is<Bn::BnHold>(prism_rtl::some_of(bound_opt))) {
                auto&& f = prism_rtl::as<Bn::BnHold>(prism_rtl::some_of(bound_opt)).a0;
                _v.set(std::tuple{f, wx});
                goto _done;
            }
            {
                _v.set(fresh_name(wx, Text::lit("flatten")));
                goto _done;
            }
        _done:
            _v.take();
        });
        auto inner = prism_rtl::cat(name, "_inner");
        auto first_ = Do(Do::DoExpr{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XVar{Text::lit("node")})), prism_rtl::cat(inner)})), Text::lit("set"), Array(std::vector{Ex(Ex::XCtor{Text::lit("Some"), Array(std::vector{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text::lit("node")})), m, Array(std::vector{Ex(Ex::XCx{})})})})}), Ex(Ex::XCx{})})})});
        auto sample_1 = Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(inner)})), Text::lit("get"), Array(std::vector{Ex(Ex::XCx{})})})), Text::lit("expect"), Array(std::vector{Ex(Ex::XStr{Text::lit("`@Flatten` adopts its first inner at the build")})})})), Text::lit("sample"), Array(std::vector{Ex(Ex::XCx{})})});
        auto wx2 = ({
            Wx this_ = wx1;
            this_.taken = append(this_.taken, Array(std::vector{inner, prism_rtl::cat(name, "_adopt")}));
            this_.fields = prelude::push(this_.fields, std::tuple{inner, OutTy(OutTy::OutHold{prism_rtl::rc(OutTy(OutTy::OutOpt{prism_rtl::rc(OutTy(OutTy::OutDyn{prism_rtl::rc(t)}))}))}), Text::lit("`@Flatten`'s current inner: the dynamic of the generation it adopted")});
            this_.moves = prelude::push(this_.moves, std::tuple{inner, Ex(Ex::XCall{Text::lit("Hold::new"), Array(std::vector{Ex(Ex::XNone{}), Ex(Ex::XCx{})})})});
            this_.build = prelude::push(this_.build, first_);
            this_.getters = prelude::push(this_.getters, MethDef{.name = name, .recv = Recv(Recv::RecvRef{}), .params = Array<std::tuple<Text, OutTy>>{}, .cx_ = CxArg(CxArg::CxRef{}), .ret = t, .body = Array<Do>{}, .tail = sample_1, .doc = Text::lit("`@Flatten`'s dynamic: its current inner at the read point.")});
            this_.dyn_reads = insert(this_.dyn_reads, name, Array(std::vector{Read(Read::OwnRead{inner})}));
            this_.flattens = prelude::push(this_.flattens, FlatDef{.name = name, .outer = m, .generation = gen_, .ty = t});
            this_;
        });
        return std::tuple{wx2, Wres(Wres::WrDyn{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XSelf{})), name, Array(std::vector{Ex(Ex::XCx{})})}), Array(std::vector{Read(Read::OwnRead{inner})}), t})};
    }
    prism_rtl::unreachable("no arm matched");
}


/// SwitchLine: unbounded fn Wx, Env, [Arg] -> ((Wx, Wres))
std::tuple<Wx, Wres> switch_line(const Wx& wx, const Env& menv, const Array<ast::Arg>& args) {
    auto&& _m = index(args, Nat(0u));
    if (prism_rtl::is_some(_m)) {
        auto&& a = prism_rtl::some_of(_m);
        auto [r, wx2] = event_ref(wx, menv, a->value);
        return std::tuple{wx2, Wres(Wres::WrEv{r})};
    }
    if (prism_rtl::is_none(_m)) {
        return std::tuple{wx, Wres(Wres::WrUnit{})};
    }
    prism_rtl::unreachable("no arm matched");
}


/// HasOwnShow: fn Lx, Text -> Bool
bool has_own_show(const Lx& lx, const Text& tn) {
    return fold(or_(prelude::get(lx.g.impls, Text::lit("Prelude.Show")), Array<check_env::ImplInfo>{}), false, [&](const bool& f, const check_env::ImplInfo& im) { return f || ((!im.derived) && (head_name(im.head) == tn)); });
}


/// HeadName: fn Ty -> Text
Text head_name(const check_types::Ty& ty0) {
    if (prism_rtl::is<check_types::Ty::TyCon>(ty0)) {
        auto&& n = prism_rtl::as<check_types::Ty::TyCon>(ty0).a0;
        return n;
    }
    {
        auto&& other = ty0;
        return Text::lit("");
    }
}


/// SelfIn: unbounded fn Ty, Text -> Ty
check_types::Ty self_in(const check_types::Ty& t, const Text& param) {
    return instantiated(t, Array(std::vector{param}), Array(std::vector{check_types::Ty(check_types::Ty::TyCon{Text::lit("\000Self"sv), Array<check_types::Ty>{}})}));
}


prism_rtl::Turn<check_types::Ty> SelfIn::cycle() const {
    const auto& t = this->t;
    const auto& param = this->param;
    return prism_rtl::more(prism_rtl::rc(Instantiated(t, Array(std::vector{param}), Array(std::vector{check_types::Ty(check_types::Ty::TyCon{Text::lit("\000Self"sv), Array<check_types::Ty>{}})}))));
}


/// `Start SelfIn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<check_types::Ty> start_self_in(check_types::Ty t, Text param) {
    return prism_rtl::make_rc<SelfIn>(t, param);
}


/// TraitDefOf: unbounded fn Lx, TraitInfo -> TraitDef
TraitDef trait_def_of(const Lx& lx0, const check_env::TraitInfo& tr) {
    auto lx = in_module(lx0, tr->file, tr.home);
    auto methods = run_to_end(each_job(tr.methods, ({
        auto lx_1 = lx;
        auto tr_2 = tr;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<FnDef>(Text)>>(prism_rtl::rc([=](Text p0) {
        return ({
            auto lx_1_3 = lx_1;
            auto tr_2_3 = tr_2;
            entered(once_job([=]() {
            return ({
                auto mq = p0;
                ({
                auto v_ = or_(prelude::get(lx_1_3.g.vals, mq), check_env::builtin(mq, check_types::mono(check_types::Ty(check_types::Ty::TyErr{}))));
                auto sc = ({
                    check_types::Scheme this_ = v_.scheme;
                    this_.ty = self_in(this_.ty, tr_2_3.param);
                    this_.qs = filter(this_.qs, [&](const Text& q) { return q != tr_2_3.param; });
                    this_.bounds = filter(this_.bounds, [&](const std::tuple<Text, Text>& _p0) {
                        auto&& q = std::get<0>(_p0);
                        return q != tr_2_3.param;
                    });
                    this_;
                });
                auto default_qk = fold(tr_2_3.defaults, Text::lit(""), [&](const Text& f, const Text& dq) { return check_types::bare_name(dq) == check_types::bare_name(mq) ? dq : f; });
                auto clauses = default_qk == Text::lit("")
                    ? Array<ast::FnClause>{}
                    : default_clauses(lx_1_3.g, default_qk);
                call_then(start_fn_def_of(lx_1_3, mq, len(clauses) == Nat(0u) ? Array(std::vector{dummy_clause()}) : clauses, sc), [=](FnDef fn_def_of_386828) {
                return ({
                    auto fd = fn_def_of_386828;
                    (prism_rtl::finished(({
                    FnDef this_ = fd;
                    this_.public_ = len(clauses) > Nat(0u);
                    this_;
                })));
                });
            });
            });
            });
        }));
        });
    })));
    })));
    return TraitDef{.name = camel(check_types::bare_name(tr.name)), .methods = methods, .defaults = tr.defaults, .doc = type_doc(lx, check_env::TyInfo{.name = tr.name, .home = tr.home, .params = Array<Text>{}, .body = check_env::TyBody(check_env::TyBody::BOpaque{}), .derives = Array<Text>{}, .file = tr->file, .span = tr.span})};
}


prism_rtl::Turn<TraitDef> TraitDefOf::cycle() const {
    const auto& lx0 = this->lx0;
    const auto& tr = this->tr;
    auto lx = in_module(lx0, tr->file, tr.home);
    auto tr_1 = tr;
    return call_value(each_job(tr_1.methods, ({
        auto lx_2 = lx;
        auto tr_1_3 = tr_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<FnDef>(Text)>>(prism_rtl::rc([=](Text p0) {
        return ({
            auto lx_2_3 = lx_2;
            auto tr_1_3_3 = tr_1_3;
            entered(once_job([=]() {
            return ({
                auto mq = p0;
                ({
                auto v_ = or_(prelude::get(lx_2_3.g.vals, mq), check_env::builtin(mq, check_types::mono(check_types::Ty(check_types::Ty::TyErr{}))));
                auto sc = ({
                    check_types::Scheme this_ = v_.scheme;
                    this_.ty = self_in(this_.ty, tr_1_3_3.param);
                    this_.qs = filter(this_.qs, [&](const Text& q) { return q != tr_1_3_3.param; });
                    this_.bounds = filter(this_.bounds, [&](const std::tuple<Text, Text>& _p0) {
                        auto&& q = std::get<0>(_p0);
                        return q != tr_1_3_3.param;
                    });
                    this_;
                });
                auto default_qk = fold(tr_1_3_3.defaults, Text::lit(""), [&](const Text& f, const Text& dq) { return check_types::bare_name(dq) == check_types::bare_name(mq) ? dq : f; });
                auto clauses = default_qk == Text::lit("")
                    ? Array<ast::FnClause>{}
                    : default_clauses(lx_2_3.g, default_qk);
                call_then(start_fn_def_of(lx_2_3, mq, len(clauses) == Nat(0u) ? Array(std::vector{dummy_clause()}) : clauses, sc), [=](FnDef fn_def_of_386828) {
                return ({
                    auto fd = fn_def_of_386828;
                    (prism_rtl::finished(({
                    FnDef this_ = fd;
                    this_.public_ = len(clauses) > Nat(0u);
                    this_;
                })));
                });
            });
            });
            });
        }));
        });
    })));
    })), [=](Array<FnDef> each_386336) {
        return ({
            auto methods = each_386336;
            (prism_rtl::finished(TraitDef{.name = camel(check_types::bare_name(tr_1.name)), .methods = methods, .defaults = tr_1.defaults, .doc = type_doc(lx, check_env::TyInfo{.name = tr_1.name, .home = tr_1.home, .params = Array<Text>{}, .body = check_env::TyBody(check_env::TyBody::BOpaque{}), .derives = Array<Text>{}, .file = tr_1->file, .span = tr_1.span})}));
        });
    });
}


/// `Start TraitDefOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<TraitDef> start_trait_def_of(Lx lx0, check_env::TraitInfo tr) {
    return prism_rtl::make_rc<TraitDefOf>(lx0, tr);
}


/// DefaultClauses: fn G, Text -> [FnClause]
Array<ast::FnClause> default_clauses(const check_env::G& g, const Text& qk) {
    return fold(g.defs, Array<ast::FnClause>{}, [&](const Array<ast::FnClause>& acc, const check_env::Def& d) { return d.qk == qk ? default_of(d, acc) : acc; });
}


/// DefaultOf: fn Def, [FnClause] -> [FnClause]
Array<ast::FnClause> default_of(const check_env::Def& d, const Array<ast::FnClause>& other) {
    auto&& _m = d.body;
    if (prism_rtl::is<check_env::DefBody::DbDefault>(_m)) {
        auto&& cs = prism_rtl::as<check_env::DefBody::DbDefault>(_m).a0;
        return cs;
    }
    {
        return other;
    }
}


/// ImplDefOf: unbounded fn Lx, ImplInfo -> ImplDef
ImplDef impl_def_of(const Lx& lx, const check_env::ImplInfo& im) {
    auto tr = or_(prelude::get(lx.g.traits, im.cls), dummy_trait_info());
    auto head = out_ty_of(lx, im.head);
    auto defs = filter(lx.g.defs, [&](const check_env::Def& d) { return is_method_of(d, im); });
    auto methods = run_to_end(each_job(defs, ({
        auto tr_1 = tr;
        auto lx_2 = lx;
        auto im_3 = im;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<FnDef>(check_env::Def)>>(prism_rtl::rc([=](check_env::Def p0) {
        return ({
            auto tr_1_4 = tr_1;
            auto lx_2_4 = lx_2;
            auto im_3_4 = im_3;
            entered(once_job([=]() {
            return ({
                auto d = p0;
                ({
                auto mq = fold(tr_1_4.methods, Text::lit(""), [&](const Text& found, const Text& q) { return check_types::bare_name(q) == d.name ? q : found; });
                auto v_ = or_(prelude::get(lx_2_4.g.vals, mq), check_env::builtin(mq, check_types::mono(check_types::Ty(check_types::Ty::TyErr{}))));
                auto sc = ({
                    check_types::Scheme this_ = v_.scheme;
                    this_.ty = instantiated(this_.ty, Array(std::vector{tr_1_4.param}), Array(std::vector{im_3_4.head}));
                    this_.qs = filter(this_.qs, [&](const Text& q) { return q != tr_1_4.param; });
                    this_.bounds = filter(this_.bounds, [&](const std::tuple<Text, Text>& _p0) {
                        auto&& q = std::get<0>(_p0);
                        return q != tr_1_4.param;
                    });
                    this_;
                });
                call_then(start_fn_def_of(lx_2_4, mq, method_clauses(d), sc), [=](FnDef fn_def_of_388161) {
                return ({
                    auto fd = fn_def_of_388161;
                    (lexer::has_prefix(im_3_4.cls, Text::lit("Prelude."))
                    ? prism_rtl::finished(renamed(fd, prism_rtl::cat(snake(d.name), "_", snake(check_types::bare_name(head_name(im_3_4.head))))))
                    : prism_rtl::finished(fd));
                });
            });
            });
            });
        }));
        });
    })));
    })));
    auto generics = each(im.qs, [&](const Text& q) { return std::tuple{camel(q), Array(std::vector{Text::lit("Clone")})}; });
    return ImplDef{.cls = im.cls, .tr = path_in(lx, tr.home, camel(check_types::bare_name(im.cls))), .head = head, .generics = generics, .methods = methods, .doc = Text::lit("")};
}


prism_rtl::Turn<ImplDef> ImplDefOf::cycle() const {
    const auto& lx = this->lx;
    const auto& im = this->im;
    auto tr = or_(prelude::get(lx.g.traits, im.cls), dummy_trait_info());
    auto im_1 = im;
    auto lx_2 = lx;
    return call_then(start_out_ty_of(lx_2, im_1.head), [=](OutTy out_ty_of_387654) {
        return ({
            auto head = out_ty_of_387654;
            auto defs = filter(lx_2.g.defs, [&](const check_env::Def& d) { return is_method_of(d, im_1); });
            call_value(each_job(defs, ({
            auto tr_3 = tr;
            auto lx_2_4 = lx_2;
            auto im_1_4 = im_1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<FnDef>(check_env::Def)>>(prism_rtl::rc([=](check_env::Def p0) {
            return ({
                auto tr_3_4 = tr_3;
                auto lx_2_4_4 = lx_2_4;
                auto im_1_4_4 = im_1_4;
                entered(once_job([=]() {
                return ({
                    auto d = p0;
                    ({
                    auto mq = fold(tr_3_4.methods, Text::lit(""), [&](const Text& found, const Text& q) { return check_types::bare_name(q) == d.name ? q : found; });
                    auto v_ = or_(prelude::get(lx_2_4_4.g.vals, mq), check_env::builtin(mq, check_types::mono(check_types::Ty(check_types::Ty::TyErr{}))));
                    auto sc = ({
                        check_types::Scheme this_ = v_.scheme;
                        this_.ty = instantiated(this_.ty, Array(std::vector{tr_3_4.param}), Array(std::vector{im_1_4_4.head}));
                        this_.qs = filter(this_.qs, [&](const Text& q) { return q != tr_3_4.param; });
                        this_.bounds = filter(this_.bounds, [&](const std::tuple<Text, Text>& _p0) {
                            auto&& q = std::get<0>(_p0);
                            return q != tr_3_4.param;
                        });
                        this_;
                    });
                    call_then(start_fn_def_of(lx_2_4_4, mq, method_clauses(d), sc), [=](FnDef fn_def_of_388161) {
                    return ({
                        auto fd = fn_def_of_388161;
                        (lexer::has_prefix(im_1_4_4.cls, Text::lit("Prelude."))
                        ? prism_rtl::finished(renamed(fd, prism_rtl::cat(snake(d.name), "_", snake(check_types::bare_name(head_name(im_1_4_4.head))))))
                        : prism_rtl::finished(fd));
                    });
                });
                });
                });
            }));
            });
        })));
        })), [=](Array<FnDef> each_387747) {
            return ({
                auto methods = each_387747;
                auto generics = each(im_1.qs, [&](const Text& q) { return std::tuple{camel(q), Array(std::vector{Text::lit("Clone")})}; });
                (prism_rtl::finished(ImplDef{.cls = im_1.cls, .tr = path_in(lx_2, tr.home, camel(check_types::bare_name(im_1.cls))), .head = head, .generics = generics, .methods = methods, .doc = Text::lit("")}));
            });
        });
        });
    });
}


/// `Start ImplDefOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<ImplDef> start_impl_def_of(Lx lx, check_env::ImplInfo im) {
    return prism_rtl::make_rc<ImplDefOf>(lx, im);
}


/// Renamed: fn FnDef, Text -> FnDef
FnDef renamed(const FnDef& fd, const Text& n) {
    FnDef this_ = fd;
    this_.name = n;
    return this_;
}


/// IsMethodOf: fn Def, ImplInfo -> Bool
bool is_method_of(const check_env::Def& d, const check_env::ImplInfo& im) {
    auto&& _m = d.body;
    if (prism_rtl::is<check_env::DefBody::DbMethod>(_m)) {
        auto&& cls = prism_rtl::as<check_env::DefBody::DbMethod>(_m).a1;
        auto&& other = prism_rtl::as<check_env::DefBody::DbMethod>(_m).a2;
        return ((cls == im.cls) && (other.span == im.span)) && (other->file == im->file);
    }
    {
        return false;
    }
}


/// MethodClauses: fn Def -> [FnClause]
Array<ast::FnClause> method_clauses(const check_env::Def& d) {
    auto&& _m = d.body;
    if (prism_rtl::is<check_env::DefBody::DbMethod>(_m)) {
        auto&& cs = prism_rtl::as<check_env::DefBody::DbMethod>(_m).a0;
        return cs;
    }
    {
        return Array<ast::FnClause>{};
    }
}


/// IfGenLine: unbounded fn Wx, Env, Expr, Block, Block, Expr -> ((Wx, Wres))
std::tuple<Wx, Wres> if_gen_line(const Wx& wx, const Env& menv, const ast::Expr& c, const ast::Block& then_b, const ast::Block& else_b, const ast::Expr& e) {
    auto lx = wx.lx;
    auto pos = wx.pos;
    auto wx1 = ({
        Wx this_ = wx;
        this_.pos = next_pos(this_.pos);
        this_;
    });
    auto [name, wx2] = fresh_name(wx1, Text::lit("arm"));
    auto base_ = prism_rtl::cat(wx.node_, camel(name), row_suffix(wx));
    auto yes = gen_row_of(wx2, menv, then_b, OutTy(OutTy::OutUnit{}), prism_rtl::cat(base_, "Then"), name);
    auto no = gen_row_of(yes->parent, menv, else_b, OutTy(OutTy::OutUnit{}), prism_rtl::cat(base_, "Else"), name);
    auto cond = as_bool(value_of(lx, menv, c));
    auto tail_ = append(append(Array(std::vector{Ex(Ex::XWeak{prism_rtl::rc(Ex(Ex::XSelf{}))})}), hosted_passed(wx)), Array(std::vector{Ex(Ex::XCx{})}));
    auto mk_fn = ({
        auto tail__1 = tail_;
        (prism_rtl::rc([=](const NodeDef& n) { return Ex(Ex::XCast{prism_rtl::rc(try_of(Ex(Ex::XCall{prism_rtl::cat(n.name, "::build"), append(Array(std::vector{Ex(Ex::XVar{Text::lit("path")}), Ex(Ex::XVar{Text::lit("value")})}), tail__1)}))), OutTy(OutTy::OutObj{prism_rtl::rc(OutTy(OutTy::OutNamed{Text::lit("Row"), Array<OutTy>{}}))})}); }));
    });
    auto select = Ex(Ex::XIf{prism_rtl::rc(cond), prism_rtl::rc(mk_fn(yes.node_)), prism_rtl::rc(mk_fn(no.node_))});
    auto wx3 = ({
        Wx this_ = no->parent;
        this_.gens = prelude::push(this_.gens, GenDef{.name = name, .pos = pos, .at = place_at(wx, Text::lit("self"), pos), .source = Ex(Ex::XUnit{}), .value_ty = OutTy(OutTy::OutUnit{}), .select = select, .transparent = false, .width = Nat(0u)});
        this_.gen_holds = prelude::push(this_.gen_holds, std::tuple{name, Array<Read>{}});
        this_.rows = append(append(append(prelude::push(this_.rows, yes.node_), yes.node_.children), Array(std::vector{no.node_})), no.node_.children);
        this_.getters = prelude::push(this_.getters, MethDef{.name = prism_rtl::cat(name, "_up"), .recv = Recv(Recv::RecvRc{}), .params = Array(std::vector{std::tuple{Text::lit("v"), OutTy(OutTy::OutUnit{})}}), .cx_ = CxArg(CxArg::CxMut{}), .ret = OutTy(OutTy::OutUnit{}), .body = Array<Do>{}, .tail = Ex(Ex::XUnit{}), .doc = Text::lit("An arm's result, which a building `if` of widgets drops.")});
        this_;
    });
    return std::tuple{wx3, Wres(Wres::WrUnit{})};
}


prism_rtl::Turn<std::tuple<Wx, Wres>> IfGenLine::cycle() const {
    const auto& wx = this->wx;
    const auto& menv = this->menv;
    const auto& c = this->c;
    const auto& then_b = this->then_b;
    const auto& else_b = this->else_b;
    const auto& e = this->e;
    auto lx = wx.lx;
    auto pos = wx.pos;
    auto wx1 = ({
        Wx this_ = wx;
        this_.pos = next_pos(this_.pos);
        this_;
    });
    auto [name, wx2] = fresh_name(wx1, Text::lit("arm"));
    auto base_ = prism_rtl::cat(wx.node_, camel(name), row_suffix(wx));
    auto yes = gen_row_of(wx2, menv, then_b, OutTy(OutTy::OutUnit{}), prism_rtl::cat(base_, "Then"), name);
    auto no = gen_row_of(yes->parent, menv, else_b, OutTy(OutTy::OutUnit{}), prism_rtl::cat(base_, "Else"), name);
    auto c_1 = c;
    auto menv_2 = menv;
    auto wx_3 = wx;
    return call_then(start_value_of(lx, menv_2, c_1), [=](Vl value_of_389627) {
        return ({
            auto cond = as_bool(value_of_389627);
            auto tail_ = append(append(Array(std::vector{Ex(Ex::XWeak{prism_rtl::rc(Ex(Ex::XSelf{}))})}), hosted_passed(wx_3)), Array(std::vector{Ex(Ex::XCx{})}));
            auto mk_fn = ({
                auto tail__4 = tail_;
                (prism_rtl::rc([=](const NodeDef& n) { return Ex(Ex::XCast{prism_rtl::rc(try_of(Ex(Ex::XCall{prism_rtl::cat(n.name, "::build"), append(Array(std::vector{Ex(Ex::XVar{Text::lit("path")}), Ex(Ex::XVar{Text::lit("value")})}), tail__4)}))), OutTy(OutTy::OutObj{prism_rtl::rc(OutTy(OutTy::OutNamed{Text::lit("Row"), Array<OutTy>{}}))})}); }));
            });
            auto select = Ex(Ex::XIf{prism_rtl::rc(cond), prism_rtl::rc(mk_fn(yes.node_)), prism_rtl::rc(mk_fn(no.node_))});
            auto wx3 = ({
                Wx this_ = no->parent;
                this_.gens = prelude::push(this_.gens, GenDef{.name = name, .pos = pos, .at = place_at(wx_3, Text::lit("self"), pos), .source = Ex(Ex::XUnit{}), .value_ty = OutTy(OutTy::OutUnit{}), .select = select, .transparent = false, .width = Nat(0u)});
                this_.gen_holds = prelude::push(this_.gen_holds, std::tuple{name, Array<Read>{}});
                this_.rows = append(append(append(prelude::push(this_.rows, yes.node_), yes.node_.children), Array(std::vector{no.node_})), no.node_.children);
                this_.getters = prelude::push(this_.getters, MethDef{.name = prism_rtl::cat(name, "_up"), .recv = Recv(Recv::RecvRc{}), .params = Array(std::vector{std::tuple{Text::lit("v"), OutTy(OutTy::OutUnit{})}}), .cx_ = CxArg(CxArg::CxMut{}), .ret = OutTy(OutTy::OutUnit{}), .body = Array<Do>{}, .tail = Ex(Ex::XUnit{}), .doc = Text::lit("An arm's result, which a building `if` of widgets drops.")});
                this_;
            });
            (prism_rtl::finished(std::tuple{wx3, Wres(Wres::WrUnit{})}));
        });
    });
}


/// `Start IfGenLine, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Wx, Wres>> start_if_gen_line(Wx wx, Env menv, ast::Expr c, ast::Block then_b, ast::Block else_b, ast::Expr e) {
    return prism_rtl::make_rc<IfGenLine>(wx, menv, c, then_b, else_b, e);
}

}  // namespace crate::lower
