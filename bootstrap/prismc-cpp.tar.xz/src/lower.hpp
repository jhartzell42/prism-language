// The module `Lower`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include "lower.types.hpp"
#include "elem.types.hpp"
#include "ast.types.hpp"
#include "check_env.types.hpp"
#include "check_errors.types.hpp"
#include "check_types.types.hpp"
#include "lexer.types.hpp"
#include "typed.types.hpp"

namespace crate {

using namespace prelude;

namespace lower {

Pos_ pos0();

Pos_ next_pos(const Pos_& p_);

Pos_ scope_pos(const Nat& k);

Text place_text(const Pos_& p_);

Text place_key(const Lx& lx, const ast::Range& r);

check_types::Ty type_at(const Lx& lx, const ast::Range& r);

check_types::Ty binder_ty(const Lx& lx, const ast::Range& r);

check_types::Ty subst_ty(const Lx& lx, const check_types::Ty& t);

check_types::Ty subst_ty_in(const Lx& lx, const check_types::Ty& t);

check_types::Col inst_col(const Lx& lx, const check_types::Col& col1);

bool is_quant_col(const Lx& lx, const check_types::Col& col1);

std::tuple<Map<Text, check_types::Ty>, Map<Text, typed::AppNote>, Map<Text, check_types::Ty>, Map<Text, Array<typed::ImplNote>>> typed_tables(const typed::TProgram& tp);

Array<Text> rust_keywords();

Text base(const Text& name);

Text snake(const Text& name);

Text lower_char(const Text& c);

Text camel(const Text& name);

Array<Text> runtime_names();

Text rust_mod_name(const Text& m);

Text path_in(const Lx& lx, const Text& owner, const Text& name);

Text prelude_path(const Lx& lx, const Text& name);

Map<Text, Text> value_names(const check_env::G& g);

Map<Text, bool> global_names(const check_env::G& g);

Text local_name(const Lx& lx, const Text& nkey);

Text base_key(const Text& k);

Text value_name(const Text& k, const Nat& count);

Text sigil_word(const Text& text0);

Text value_path(const Lx& lx, const Text& qk);

Text owner_of(const Text& qk);

Text tag_struct(const Text& tn);

OutTy out_ty_of(const Lx& lx, const check_types::Ty& t);

prism_rtl::JobRef<OutTy> start_out_ty_of(Lx lx, check_types::Ty t);

OutTy blueprint_ty();

OutTy elem_ty();

OutTy answer_ty_value();

OutTy host_of_ty();

bool has_blueprint(const check_types::Ty& t);

check_types::Ty event_param(const check_types::Ty& t);

check_types::Ty job_param(const check_types::Ty& ty0);

OutTy rust_ty_of_params(const Lx& lx, const Array<check_types::Ty>& ps);

prism_rtl::JobRef<OutTy> start_rust_ty_of_params(Lx lx, Array<check_types::Ty> ps);

OutTy named_ty(const Lx& lx, const Text& n, const Array<OutTy>& args);

prism_rtl::JobRef<OutTy> start_named_ty(Lx lx, Text n, Array<OutTy> args);

check_types::Ty peel(const check_types::Ty& t);

check_types::Ty out_of(const check_types::Ty& t);

Layer layer_of(const check_types::Ty& t);

Map<Text, Array<bool>> layouts(const check_env::G& g);

prism_rtl::JobRef<Map<Text, Array<bool>>> start_layouts(check_env::G g);

bool reaches(const check_env::G& g, const check_types::Ty& t, const Text& target, const Array<Text>& seen);

prism_rtl::JobRef<bool> start_reaches(check_env::G g, check_types::Ty t, Text target, Array<Text> seen);

bool rc_field(const Lx& lx, const Text& ctor, const Nat& i);

bool floaty(const check_env::G& g, const check_types::Ty& t, const Array<Text>& seen);

prism_rtl::JobRef<bool> start_floaty(check_env::G g, check_types::Ty t, Array<Text> seen);

bool podable(const OutTy& t);

prism_rtl::JobRef<bool> start_podable(OutTy t);

Env empty_env();

Text name_key_at(const Lx& lx, const Env& env, const ast::SName& n, const ast::Range& span);

Array<Text> with_instances(const Env& env, const Array<Text>& names);

Env bind_span(const Env& env, const Text& nkey, const Vl& v_);

Env bind(const Env& env, const Text& name, const Bn& b);

OutTy value_ty(const Vl& vl0);

Vl local_place(const Ex& x, const Holding& mode, const OutTy& t);

Text place_stem(const Ex& x);

bool on_self(const Ex& x);

std::optional<Ex> through_parent(const Ex& x);

Ex own(const Vl& vl0);

Ex ref_(const Vl& vl0);

Ex copy(const Vl& vl0);

bool is_copy(const OutTy& t);

Ex as_bool(const Vl& v_);

Text escape(const Text& t);

Text char_escape(const Text& text0);

Ex number(const OutTy& t, const Text& digits, const bool& neg);

Text decimal_digits(const Text& d);

Vl literal_value(const Lx& lx, const Env& env, const ast::Literal& l, const ast::Range& span, const bool& neg);

prism_rtl::JobRef<Vl> start_literal_value(Lx lx, Env env, ast::Literal l, ast::Range span, bool neg);

Vl text_value(const Lx& lx, const Env& env, const Array<ast::TextSeg>& segs);

prism_rtl::JobRef<Vl> start_text_value(Lx lx, Env env, Array<ast::TextSeg> segs);

bool is_plain_seg(const ast::TextSeg& text_seg0);

Text plain_text(const ast::TextSeg& text_seg0);

Ex seg_ex(const Lx& lx, const Env& env, const ast::TextSeg& text_seg2);

prism_rtl::JobRef<Ex> start_seg_ex(Lx lx, Env env, ast::TextSeg text_seg2);

Ex shown_part(const Vl& v_);

Ex refusal(const Text& what);

Ex try_of(const Ex& x);

bool is_named_place(const Ex& x);

Text lowering_refusal();

Do refusal_do(const Text& what);

Vl value_of(const Lx& lx, const Env& env, const ast::Expr& e);

prism_rtl::JobRef<Vl> start_value_of(Lx lx, Env env, ast::Expr e);

Vl unbound_value_of(const Lx& lx, const Env& env, const ast::Expr& e);

prism_rtl::JobRef<Vl> start_unbound_value_of(Lx lx, Env env, ast::Expr e);

bool is_event_value(const Lx& lx, const Env& env, const ast::Expr& e);

prism_rtl::JobRef<bool> start_is_event_value(Lx lx, Env env, ast::Expr e);

bool has_event_source(const Lx& lx, const Env& env, const ast::Expr& e);

prism_rtl::JobRef<bool> start_has_event_source(Lx lx, Env env, ast::Expr e);

bool is_event_source(const Lx& lx, const Env& env, const ast::Expr& c);

prism_rtl::JobRef<bool> start_is_event_source(Lx lx, Env env, ast::Expr c);

Vl event_value_of(const Lx& lx, const Env& env, const ast::Expr& e);

prism_rtl::JobRef<Vl> start_event_value_of(Lx lx, Env env, ast::Expr e);

Vl value_by_kind(const Lx& lx, const Env& env, const ast::Expr& e);

prism_rtl::JobRef<Vl> start_value_by_kind(Lx lx, Env env, ast::Expr e);

Vl pure_blueprint(const Lx& lx, const Env& env, const ast::Expr& x, const OutTy& t);

prism_rtl::JobRef<Vl> start_pure_blueprint(Lx lx, Env env, ast::Expr x, OutTy t);

Vl plain_blueprint(const Lx& lx, const Env& env, const ast::Expr& x, const Text& variant, const OutTy& t);

prism_rtl::JobRef<Vl> start_plain_blueprint(Lx lx, Env env, ast::Expr x, Text variant, OutTy t);

Vl dynamic_blueprint(const Lx& lx, const Env& env, const ast::Expr& x, const ast::Expr& d, const Text& variant, const OutTy& t);

prism_rtl::JobRef<Vl> start_dynamic_blueprint(Lx lx, Env env, ast::Expr x, ast::Expr d, Text variant, OutTy t);

Vl element_blueprint(const Lx& lx, const Env& env, const Array<ast::Arg>& args, const OutTy& t);

prism_rtl::JobRef<Vl> start_element_blueprint(Lx lx, Env env, Array<ast::Arg> args, OutTy t);

Text kind_words(const ast::ExprKind& k);

Vl name_value(const Lx& lx, const Env& env, const ast::SName& n, const ast::Range& span);

prism_rtl::JobRef<Vl> start_name_value(Lx lx, Env env, ast::SName n, ast::Range span);

Vl global_value(const Lx& lx, const Text& qk, const ast::Range& span, const OutTy& t);

prism_rtl::JobRef<Vl> start_global_value(Lx lx, Text qk, ast::Range span, OutTy t);

bool is_let_def(const check_env::Def& d);

Text start_path(const Lx& lx, const Text& qk);

Vl application(const Lx& lx, const Env& env, const ast::Expr& callee, const Array<ast::Arg>& args, const ast::Range& span);

prism_rtl::JobRef<Vl> start_application(Lx lx, Env env, ast::Expr callee, Array<ast::Arg> args, ast::Range span);

Vl inline_local_fn(const Lx& lx, const Env& env, const ast::FnClause& c, const Array<ast::Arg>& args, const OutTy& t);

prism_rtl::JobRef<Vl> start_inline_local_fn(Lx lx, Env env, ast::FnClause c, Array<ast::Arg> args, OutTy t);

Ex argument(const Lx& lx, const Env& env, const ast::Expr& e);

prism_rtl::JobRef<Ex> start_argument(Lx lx, Env env, ast::Expr e);

Ex argument_by_kind(const Lx& lx, const Env& env, const ast::Expr& e);

prism_rtl::JobRef<Ex> start_argument_by_kind(Lx lx, Env env, ast::Expr e);

Ex closure_ref(const Vl& vl0);

Vl tag_value(const Lx& lx, const Env& env, const check_env::TagInfo& tg, const Array<ast::Arg>& args);

prism_rtl::JobRef<Vl> start_tag_value(Lx lx, Env env, check_env::TagInfo tg, Array<ast::Arg> args);

Vl global_call(const Lx& lx, const Env& env, const Text& qk, const Array<ast::Arg>& args, const ast::Range& span, const OutTy& t);

prism_rtl::JobRef<Vl> start_global_call(Lx lx, Env env, Text qk, Array<ast::Arg> args, ast::Range span, OutTy t);

Array<Ex> args_for(const Lx& lx, const Env& env, const check_env::ValInfo& v_, const Array<ast::Arg>& args);

prism_rtl::JobRef<Array<Ex>> start_args_for(Lx lx, Env env, check_env::ValInfo v_, Array<ast::Arg> args);

ast::Expr dummy_expr();

Vl ctor_app(const Lx& lx, const Env& env, const check_env::CtorInfo& c, const Array<ast::Arg>& args, const ast::Range& span);

prism_rtl::JobRef<Vl> start_ctor_app(Lx lx, Env env, check_env::CtorInfo c, Array<ast::Arg> args, ast::Range span);

Vl ctor_fn(const Lx& lx, const check_env::CtorInfo& c, const Array<OutTy>& pts, const ast::Range& span, const OutTy& t, const bool& job);

prism_rtl::JobRef<Vl> start_ctor_fn(Lx lx, check_env::CtorInfo c, Array<OutTy> pts, ast::Range span, OutTy t, bool job);

bool is_named_arg(const ast::Arg& a);

Array<Ex> ctor_args(const Lx& lx, const Env& env, const check_env::CtorInfo& c, const Array<ast::Arg>& args);

prism_rtl::JobRef<Array<Ex>> start_ctor_args(Lx lx, Env env, check_env::CtorInfo c, Array<ast::Arg> args);

Vl method_call(const Lx& lx, const Env& env, const check_env::ValInfo& v_, const Array<ast::Arg>& args, const ast::Range& span, const OutTy& t);

prism_rtl::JobRef<Vl> start_method_call(Lx lx, Env env, check_env::ValInfo v_, Array<ast::Arg> args, ast::Range span, OutTy t);

check_env::TraitInfo dummy_trait_info();

Vl prelude_method(const Lx& lx, const Text& cls, const Text& m, const Array<Vl>& vals, const ast::Range& span, const OutTy& t);

prism_rtl::JobRef<Vl> start_prelude_method(Lx lx, Text cls, Text m, Array<Vl> vals, ast::Range span, OutTy t);

Vl binary_value(const Lx& lx, const Env& env, const Text& op, const ast::Expr& l, const ast::Expr& r, const ast::Range& span);

prism_rtl::JobRef<Vl> start_binary_value(Lx lx, Env env, Text op, ast::Expr l, ast::Expr r, ast::Range span);

Vl op_value(const Lx& lx, const Text& op, const Vl& a, const Vl& b, const ast::Range& span, const OutTy& t);

Text num_method(const Text& text0);

Vl prelude_call(const Lx& lx, const Env& env, const Text& qk, const Array<ast::Arg>& args, const ast::Range& span, const OutTy& t);

prism_rtl::JobRef<Vl> start_prelude_call(Lx lx, Env env, Text qk, Array<ast::Arg> args, ast::Range span, OutTy t);

std::optional<Ex> prelude_job(const Lx& lx, const Env& env, const Text& variant, const Array<ast::Arg>& args);

prism_rtl::JobRef<std::optional<Ex>> start_prelude_job(Lx lx, Env env, Text variant, Array<ast::Arg> args);

std::optional<Ex> prelude_job_call(const Lx& lx, const Env& env, const ast::Expr& e);

prism_rtl::JobRef<std::optional<Ex>> start_prelude_job_call(Lx lx, Env env, ast::Expr e);

Ex as_job_value(const Lx& lx, const Env& env, const ast::Expr& e);

prism_rtl::JobRef<Ex> start_as_job_value(Lx lx, Env env, ast::Expr e);

Ex wrap_as_job(const Ex& f, const Array<OutTy>& pts, const OutTy& target, const OutTy& a);

Array<Ex> named_args_owned(const Lx& lx, const Env& env, const Text& qk, const Array<ast::Arg>& args);

prism_rtl::JobRef<Array<Ex>> start_named_args_owned(Lx lx, Env env, Text qk, Array<ast::Arg> args);

Array<Ex> start_args(const Lx& lx, const Env& env, const Vl& f, const Array<ast::Arg>& args);

prism_rtl::JobRef<Array<Ex>> start_start_args(Lx lx, Env env, Vl f, Array<ast::Arg> args);

Text prelude_variant(const Text& name, const OutTy& first_);

Vl field_value(const Lx& lx, const Env& env, const ast::Expr& r, const Text& name);

prism_rtl::JobRef<Vl> start_field_value(Lx lx, Env env, ast::Expr r, Text name);

std::tuple<OutTy, bool> field_info(const Lx& lx, const check_types::Ty& rty, const Text& name);

prism_rtl::JobRef<std::tuple<OutTy, bool>> start_field_info(Lx lx, check_types::Ty rty, Text name);

check_types::Ty instantiated(const check_types::Ty& t, const Array<Text>& params, const Array<check_types::Ty>& args);

prism_rtl::JobRef<check_types::Ty> start_instantiated(check_types::Ty t, Array<Text> params, Array<check_types::Ty> args);

Vl index_value(const Lx& lx, const Env& env, const ast::Expr& r, const ast::Expr& i, const OutTy& t);

prism_rtl::JobRef<Vl> start_index_value(Lx lx, Env env, ast::Expr r, ast::Expr i, OutTy t);

Array<Text> read_names(const Array<ast::Expr>& es);

prism_rtl::JobRef<Array<Text>> start_read_names(Array<ast::Expr> es);

Array<ast::Expr> lambda_exprs(const ast::LambdaBody& lambda_body0);

prism_rtl::JobRef<Array<ast::Expr>> start_lambda_exprs(ast::LambdaBody lambda_body0);

Vl lambda_value(const Lx& lx, const Env& env, const ast::Expr& e, const Array<ast::Pattern_>& ps, const ast::LambdaBody& body);

prism_rtl::JobRef<Vl> start_lambda_value(Lx lx, Env env, ast::Expr e, Array<ast::Pattern_> ps, ast::LambdaBody body);

Vl plain_lambda(const Lx& lx, const Env& env, const Array<ast::Pattern_>& ps, const ast::LambdaBody& body, const OutTy& ft);

prism_rtl::JobRef<Vl> start_plain_lambda(Lx lx, Env env, Array<ast::Pattern_> ps, ast::LambdaBody body, OutTy ft);

Array<OutTy> lambda_param_tys(const Lx& lx, const ast::Expr& e, const Nat& n);

prism_rtl::JobRef<Array<OutTy>> start_lambda_param_tys(Lx lx, ast::Expr e, Nat n);

bool is_known_ty(const OutTy& t);

prism_rtl::JobRef<bool> start_is_known_ty(OutTy t);

Vl job_lambda(const Lx& lx, const Env& env, const Array<ast::Pattern_>& ps, const ast::LambdaBody& body, const OutTy& ft, const OutTy& a, const bool& enter);

prism_rtl::JobRef<Vl> start_job_lambda(Lx lx, Env env, Array<ast::Pattern_> ps, ast::LambdaBody body, OutTy ft, OutTy a, bool enter);

bool enters_lambda(const Lx& lx, const ast::Expr& e);

Env only_captured(const Env& env, const Array<Text>& caps);

Do cond_as_let(const Cc& cc0);

Ex lambda_arg(const Lx& lx, const Env& env, const Array<ast::Pattern_>& ps, const ast::LambdaBody& body, const Array<OutTy>& pts);

prism_rtl::JobRef<Ex> start_lambda_arg(Lx lx, Env env, Array<ast::Pattern_> ps, ast::LambdaBody body, Array<OutTy> pts);

Vl lambda_body_value(const Lx& lx, const Env& env, const ast::LambdaBody& lambda_body2);

prism_rtl::JobRef<Vl> start_lambda_body_value(Lx lx, Env env, ast::LambdaBody lambda_body2);

std::tuple<Array<Pa>, Env> closure_params(const Lx& lx, const Env& env, const Array<ast::Pattern_>& ps, const Array<OutTy>& pts, const bool& typed);

prism_rtl::JobRef<std::tuple<Array<Pa>, Env>> start_closure_params(Lx lx, Env env, Array<ast::Pattern_> ps, Array<OutTy> pts, bool typed);

Env bind_all(const Env& env, const Array<std::tuple<Text, Bn>>& bs);

check_types::Ty binder_ty_of_pattern(const Lx& lx, const ast::Pattern_& p_);

Vl if_value(const Lx& lx, const Env& env, const ast::Cond& c, const ast::Block& then_b, const std::optional<ast::Block>& else_b_opt, const OutTy& t);

prism_rtl::JobRef<Vl> start_if_value(Lx lx, Env env, ast::Cond c, ast::Block then_b, std::optional<ast::Block> else_b_opt, OutTy t);

Vl arms_value(const Ex& scrut, const Array<XArm>& arms, const Text& label, const OutTy& t);

bool is_let_cond(const Cc& cc0);

Vl match_value(const Lx& lx, const Env& env, const ast::Expr& s, const Array<ast::Arm>& arms, const OutTy& t, const ast::Range& span);

prism_rtl::JobRef<Vl> start_match_value(Lx lx, Env env, ast::Expr s, Array<ast::Arm> arms, OutTy t, ast::Range span);

ast::Arm dummy_arm();

PatOut arm_pat(const Lx& lx, const std::optional<ast::Pattern_>& opt1, const check_types::Ty& ty, const Holding& mode, const Text& fresh);

prism_rtl::JobRef<PatOut> start_arm_pat(Lx lx, std::optional<ast::Pattern_> opt1, check_types::Ty ty, Holding mode, Text fresh);

Vl block_value(const Lx& lx, const Env& env, const ast::Block& b);

prism_rtl::JobRef<Vl> start_block_value(Lx lx, Env env, ast::Block b);

bool is_given_block(const Array<ast::Stmt>& stmts);

bool is_guardish(const ast::Stmt& s);

OutTy block_ty(const Lx& lx, const ast::Block& b);

prism_rtl::JobRef<OutTy> start_block_ty(Lx lx, ast::Block b);

Vl plain_block_value(const Lx& lx, const Env& env, const ast::Block& b);

prism_rtl::JobRef<Vl> start_plain_block_value(Lx lx, Env env, ast::Block b);

ast::Stmt dummy_stmt_l();

std::tuple<Array<Do>, Env> block_stmt(const Lx& lx, const Env& env, const ast::Stmt& s);

prism_rtl::JobRef<std::tuple<Array<Do>, Env>> start_block_stmt(Lx lx, Env env, ast::Stmt s);

std::tuple<Array<Do>, Env> generic_let(const Lx& lx, const Env& env, const ast::SName& n, const typed::GenNote& gn, const ast::Expr& x);

prism_rtl::JobRef<std::tuple<Array<Do>, Env>> start_generic_let(Lx lx, Env env, ast::SName n, typed::GenNote gn, ast::Expr x);

Array<std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>>> instantiations(const Lx& lx, const typed::GenNote& gn);

prism_rtl::JobRef<Array<std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>>>> start_instantiations(Lx lx, typed::GenNote gn);

Array<std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>>> expanded(const Lx& lx, const std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>>& i);

prism_rtl::JobRef<Array<std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>>>> start_expanded(Lx lx, std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>> i);

std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>> subst_inst(const Lx& lx, const std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>>& arg1);

std::optional<Text> open_q(const Lx& lx, const std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>>& arg1);

prism_rtl::JobRef<std::optional<Text>> start_open_q(Lx lx, std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>> arg1);

Array<Text> open_cols(const Lx& lx, const check_types::Col& col1);

Array<Text> open_ty_qs(const Lx& lx, const check_types::Ty& t);

prism_rtl::JobRef<Array<Text>> start_open_ty_qs(Lx lx, check_types::Ty t);

Lx at_instance(const Lx& lx, const std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>>& arg1);

Lx widget_let_lx(const Lx& lx, const ast::Range& span);

prism_rtl::JobRef<Lx> start_widget_let_lx(Lx lx, ast::Range span);

std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>> inst_at(const Lx& lx, const typed::InstNote& u);

Text gen_key(const typed::GenNote& gn);

Text inst_key(const typed::InstNote& u);

Text col_name(const check_types::Col& col0);

std::tuple<Array<Do>, Env> plain_let(const Lx& lx, const Env& env, const ast::Stmt& s, const ast::Pattern_& p_, const ast::Expr& x);

prism_rtl::JobRef<std::tuple<Array<Do>, Env>> start_plain_let(Lx lx, Env env, ast::Stmt s, ast::Pattern_ p_, ast::Expr x);

PatOut pat_only(const Pa& pa);

PatOut rust_pat(const Lx& lx, const ast::Pattern_& p_, const check_types::Ty& ty, const Holding& mode, const Text& fresh);

prism_rtl::JobRef<PatOut> start_rust_pat(Lx lx, ast::Pattern_ p_, check_types::Ty ty, Holding mode, Text fresh);

ast::Pattern_ dummy_pat();

check_types::Ty inner_ty(const check_types::Ty& t);

bool is_unit_ctor(const Lx& lx, const Text& qk);

PatOut wrap_pat(const Lx& lx, const Text& ctor, const ast::Pattern_& q, const check_types::Ty& inner, const Holding& mode, const Text& fresh);

prism_rtl::JobRef<PatOut> start_wrap_pat(Lx lx, Text ctor, ast::Pattern_ q, check_types::Ty inner, Holding mode, Text fresh);

PatOut lit_pat(const Lx& lx, const ast::Literal& l, const check_types::Ty& ty, const Holding& mode, const Text& fresh, const bool& neg);

prism_rtl::JobRef<PatOut> start_lit_pat(Lx lx, ast::Literal l, check_types::Ty ty, Holding mode, Text fresh, bool neg);

PatOut ctor_pat(const Lx& lx, const ast::SName& n, const Array<ast::Pattern_>& ps, const check_types::Ty& ty, const Holding& mode, const Text& fresh);

prism_rtl::JobRef<PatOut> start_ctor_pat(Lx lx, ast::SName n, Array<ast::Pattern_> ps, check_types::Ty ty, Holding mode, Text fresh);

PatOut sub_pat(const Lx& lx, const check_env::CtorInfo& c, const Nat& i, const ast::Pattern_& p_, const check_types::Ty& ty, const Holding& mode, const Text& fresh);

prism_rtl::JobRef<PatOut> start_sub_pat(Lx lx, check_env::CtorInfo c, Nat i, ast::Pattern_ p_, check_types::Ty ty, Holding mode, Text fresh);

PatOut behind_rc(const Lx& lx, const ast::Pattern_& p_, const check_types::Ty& ty, const Holding& rc_mode, const Text& fresh);

prism_rtl::JobRef<PatOut> start_behind_rc(Lx lx, ast::Pattern_ p_, check_types::Ty ty, Holding rc_mode, Text fresh);

PatOut record_pat(const Lx& lx, const ast::SName& n, const Array<ast::FieldPat>& fps, const bool& rest, const check_types::Ty& ty, const Holding& mode, const Text& fresh);

prism_rtl::JobRef<PatOut> start_record_pat(Lx lx, ast::SName n, Array<ast::FieldPat> fps, bool rest, check_types::Ty ty, Holding mode, Text fresh);

PatOut rest_case_pat(const check_env::CtorInfo& c, const Array<std::tuple<Text, Array<check_types::Ty>>>& cases, const Text& ty_path);

PatOut fields_pat(const Lx& lx, const check_env::CtorInfo& c, const Array<ast::FieldPat>& fps, const bool& rest, const check_types::Ty& ty, const Holding& mode, const Text& fresh, const Text& ty_path);

prism_rtl::JobRef<PatOut> start_fields_pat(Lx lx, check_env::CtorInfo c, Array<ast::FieldPat> fps, bool rest, check_types::Ty ty, Holding mode, Text fresh, Text ty_path);

ast::FieldPat dummy_field_pat();

check_env::TagInfo dummy_tag_info();

bool is_live(const check_types::Ty& t);

Text tag_field_name(const ast::FieldPat& fp, const Array<Text>& names, const Nat& i);

PatOut tag_pat(const Lx& lx, const check_env::TagInfo& tg, const Array<ast::FieldPat>& fps, const bool& rest, const check_types::Ty& ty, const Holding& mode, const Text& fresh);

prism_rtl::JobRef<PatOut> start_tag_pat(Lx lx, check_env::TagInfo tg, Array<ast::FieldPat> fps, bool rest, check_types::Ty ty, Holding mode, Text fresh);

PatOut live_field_pat(const Lx& lx, const ast::Pattern_& p_, const Text& variant, const Text& fname, const check_types::Ty& ft, const Text& fresh);

prism_rtl::JobRef<PatOut> start_live_field_pat(Lx lx, ast::Pattern_ p_, Text variant, Text fname, check_types::Ty ft, Text fresh);

Ex live_projection(const Text& fresh, const Text& variant, const Text& fname, const OutTy& ft);

PatOut family_pat(const Lx& lx, const ast::QualName& q, const check_types::Ty& ty, const Text& fresh);

prism_rtl::JobRef<PatOut> start_family_pat(Lx lx, ast::QualName q, check_types::Ty ty, Text fresh);

PatOut error_pat(const Lx& lx, const Array<ast::FieldPat>& fps, const check_types::Ty& ty, const Holding& mode, const Text& fresh);

prism_rtl::JobRef<PatOut> start_error_pat(Lx lx, Array<ast::FieldPat> fps, check_types::Ty ty, Holding mode, Text fresh);

PatOut array_pat(const Lx& lx, const Array<ast::Pattern_>& ps, const check_types::Ty& ty, const Holding& mode, const Text& fresh);

prism_rtl::JobRef<PatOut> start_array_pat(Lx lx, Array<ast::Pattern_> ps, check_types::Ty ty, Holding mode, Text fresh);

Vl template_value(const Lx& lx, const Env& env, const ast::Template& tp);

prism_rtl::JobRef<Vl> start_template_value(Lx lx, Env env, ast::Template tp);

Array<Do> template_part_dos(const Lx& lx, const Env& env, const ast::TemplatePart& part);

prism_rtl::JobRef<Array<Do>> start_template_part_dos(Lx lx, Env env, ast::TemplatePart part);

Array<Ex> template_args(const Lx& lx, const Env& env, const Text& qk, const Array<ast::Arg>& args, const Array<Ex>& body);

prism_rtl::JobRef<Array<Ex>> start_template_args(Lx lx, Env env, Text qk, Array<ast::Arg> args, Array<Ex> body);

std::optional<ast::Arg> attr_at(const Array<ast::FnClause>& clauses, const Nat& j, const Array<ast::Arg>& args);

std::optional<Text> place_name(const ast::Pattern_& p_);

Ex shown_text(const Vl& v_);

Vl given_value(const Lx& lx, const Env& env, const ast::Block& b, const OutTy& t, const ast::Range& span);

prism_rtl::JobRef<Vl> start_given_value(Lx lx, Env env, ast::Block b, OutTy t, ast::Range span);

Do given_bind(const bool& is_try, const Pa& pa, const Ex& x, const Text& label, const OutTy& t);

Text source_text(const Lx& lx, const ast::Range& r);

Vl update_value(const Lx& lx, const Env& env, const ast::Expr& target, const ast::Block& b, const OutTy& t, const ast::Range& span);

prism_rtl::JobRef<Vl> start_update_value(Lx lx, Env env, ast::Expr target, ast::Block b, OutTy t, ast::Range span);

std::tuple<Array<Do>, Env> upd_stmts(const Lx& lx, const Env& env, const Array<ast::Stmt>& stmts);

prism_rtl::JobRef<std::tuple<Array<Do>, Env>> start_upd_stmts(Lx lx, Env env, Array<ast::Stmt> stmts);

std::tuple<Array<Do>, Env> upd_stmt(const Lx& lx, const Env& env, const ast::Stmt& s);

prism_rtl::JobRef<std::tuple<Array<Do>, Env>> start_upd_stmt(Lx lx, Env env, ast::Stmt s);

Do upd_for(const Lx& lx, const Env& env, const std::optional<ast::ForBinders>& binders_opt, const ast::Expr& source, const ast::Block& body, const ast::Range& span);

prism_rtl::JobRef<Do> start_upd_for(Lx lx, Env env, std::optional<ast::ForBinders> binders_opt, ast::Expr source, ast::Block body, ast::Range span);

Do upd_for_refs(const Lx& lx, const Env& env, const ast::SName& n, const ast::Expr& source, const ast::Block& body, const ast::Range& span, const check_types::Ty& sty);

prism_rtl::JobRef<Do> start_upd_for_refs(Lx lx, Env env, ast::SName n, ast::Expr source, ast::Block body, ast::Range span, check_types::Ty sty);

std::optional<ast::SName> ref_binder(const std::optional<ast::ForBinders>& opt0);

bool is_ref_path(const ast::Expr& e);

Do upd_for_values(const Lx& lx, const Env& env, const std::optional<ast::ForBinders>& binders_opt, const ast::Expr& source, const ast::Block& body, const ast::Range& span, const check_types::Ty& sty);

prism_rtl::JobRef<Do> start_upd_for_values(Lx lx, Env env, std::optional<ast::ForBinders> binders_opt, ast::Expr source, ast::Block body, ast::Range span, check_types::Ty sty);

Do upd_if(const Lx& lx, const Env& env, const ast::Cond& c, const ast::Block& then_b, const std::optional<ast::Block>& else_b_opt);

prism_rtl::JobRef<Do> start_upd_if(Lx lx, Env env, ast::Cond c, ast::Block then_b, std::optional<ast::Block> else_b_opt);

Do upd_match(const Lx& lx, const Env& env, const ast::Expr& scrut, const Array<ast::Arm>& arms);

prism_rtl::JobRef<Do> start_upd_match(Lx lx, Env env, ast::Expr scrut, Array<ast::Arm> arms);

Ex all_of(const Array<Ex>& xs0);

Array<Do> arm_dos(const Ex& ex0);

Array<Cc> guard_conds(const Lx& lx, const Env& env, const std::optional<ast::Expr>& opt2);

prism_rtl::JobRef<Array<Cc>> start_guard_conds(Lx lx, Env env, std::optional<ast::Expr> opt2);

Ex place_of(const Lx& lx, const Env& env, const ast::Expr& e);

prism_rtl::JobRef<Ex> start_place_of(Lx lx, Env env, ast::Expr e);

Do assign(const Lx& lx, const Env& env, const ast::Expr& target, const Ex& v_);

prism_rtl::JobRef<Do> start_assign(Lx lx, Env env, ast::Expr target, Ex v_);

Array<Text> bound_of(const Lx& lx, const Text& text1);

Array<std::tuple<Text, Array<Text>>> scheme_generics(const Lx& lx, const check_types::Scheme& sc);

Array<std::tuple<Text, bool>> param_names(const Lx& lx, const Array<ast::FnClause>& clauses, const Array<OutTy>& pts);

Text plain_binder(const Lx& lx, const ast::Pattern_& p_);

Text param_word(const OutTy& t, const Nat& i);

Ex clauses_body(const Lx& lx, const Env& env, const Array<ast::FnClause>& clauses, const Array<std::tuple<Text, bool>>& names, const Array<check_types::Ty>& ptys, const prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Lx, Env, ast::FnBody>)>& body_fn, const Text& label, const OutTy& t);

prism_rtl::JobRef<Ex> start_clauses_body(Lx lx, Env env, Array<ast::FnClause> clauses, Array<std::tuple<Text, bool>> names, Array<check_types::Ty> ptys, prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Lx, Env, ast::FnBody>)> body_fn, Text label, OutTy t);

ast::FnClause dummy_clause();

Ex fn_body_value(const Lx& lx, const Env& env, const ast::FnBody& fn_body2);

prism_rtl::JobRef<Ex> start_fn_body_value(Lx lx, Env env, ast::FnBody fn_body2);

FnDef fn_def_of(const Lx& lx, const Text& qk, const Array<ast::FnClause>& clauses, const check_types::Scheme& sc);

prism_rtl::JobRef<FnDef> start_fn_def_of(Lx lx, Text qk, Array<ast::FnClause> clauses, check_types::Scheme sc);

Array<Text> ty_params_in(const OutTy& t);

Text signature_text(const Lx& lx, const Text& qk);

Text definition_text(const Lx& lx, const Text& qk);

Text src_text(const Lx& lx, const Nat& f, const ast::Range& r);

Text drop_trailing_comments(const Text& t);

bool is_code_line(const Text& l);

FnDef let_getter(const Lx& lx, const Text& qk, const ast::LetDecl& l);

prism_rtl::JobRef<FnDef> start_let_getter(Lx lx, Text qk, ast::LetDecl l);

Ex tail(const Lx& lx, const Env& env, const ast::Expr& e);

prism_rtl::JobRef<Ex> start_tail(Lx lx, Env env, ast::Expr e);

Ex tail_here(const Lx& lx, const Env& env, const ast::Expr& e);

prism_rtl::JobRef<Ex> start_tail_here(Lx lx, Env env, ast::Expr e);

Ex tail_block(const Lx& lx, const Env& env, const ast::Block& b);

prism_rtl::JobRef<Ex> start_tail_block(Lx lx, Env env, ast::Block b);

Ex tail_from(const Lx& lx, const Env& env, const ast::Block& b, const Nat& i);

prism_rtl::JobRef<Ex> start_tail_from(Lx lx, Env env, ast::Block b, Nat i);

bool has_top_while(const Lx& lx, const ast::Block& b);

bool is_cycle_while(const Lx& lx, const ast::Stmt& st);

bool else_has_top_while(const Lx& lx, const std::optional<ast::Block>& opt1);

bool holds_cycle_while(const Lx& lx, const ast::Stmt& st);

Ex upd_tail(const Lx& lx, const Env& env, const ast::Expr& target, const ast::Block& b, const ast::Range& to, const prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Env, Ex>)>& cont_fn);

prism_rtl::JobRef<Ex> start_upd_tail(Lx lx, Env env, ast::Expr target, ast::Block b, ast::Range to, prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Env, Ex>)> cont_fn);

Ex upd_tail_from(const Lx& lx, const Env& outer, const Env& env, const ast::Block& b, const Nat& i, const ast::Range& to, const prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Env, Ex>)>& cont_fn);

prism_rtl::JobRef<Ex> start_upd_tail_from(Lx lx, Env outer, Env env, ast::Block b, Nat i, ast::Range to, prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Env, Ex>)> cont_fn);

Ex stmt_job(const Lx& lx, const Env& outer, const Env& env, const ast::Stmt& s, const Text& rest, const prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Env, Env>)>& cont_fn);

prism_rtl::JobRef<Ex> start_stmt_job(Lx lx, Env outer, Env env, ast::Stmt s, Text rest, prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Env, Env>)> cont_fn);

Ex prepend(const Array<Do>& dos, const Ex& ex1);

Ex while_job(const Lx& lx, const Env& outer, const Env& env, const ast::Cond& c, const ast::Block& wb, const ast::Range& span, const Text& rest_text_, const prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Env, Env>)>& cont_fn);

prism_rtl::JobRef<Ex> start_while_job(Lx lx, Env outer, Env env, ast::Cond c, ast::Block wb, ast::Range span, Text rest_text_, prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Env, Env>)> cont_fn);

Ex stmts_then(const Lx& lx, const Env& env, const ast::Block& b, const Ex& last);

prism_rtl::JobRef<Ex> start_stmts_then(Lx lx, Env env, ast::Block b, Ex last);

Ex if_job(const Lx& lx, const Env& outer, const Env& env, const ast::Cond& c, const ast::Block& then_b, const std::optional<ast::Block>& else_b_opt, const ast::Range& span, const Text& rest_text_, const prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Env, Env>)>& cont_fn);

prism_rtl::JobRef<Ex> start_if_job(Lx lx, Env outer, Env env, ast::Cond c, ast::Block then_b, std::optional<ast::Block> else_b_opt, ast::Range span, Text rest_text_, prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Env, Env>)> cont_fn);

Ex match_job(const Lx& lx, const Env& outer, const Env& env, const ast::Expr& scrut, const Array<ast::Arm>& arms, const ast::Range& span, const Text& rest_text_, const prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Env, Env>)>& cont_fn);

prism_rtl::JobRef<Ex> start_match_job(Lx lx, Env outer, Env env, ast::Expr scrut, Array<ast::Arm> arms, ast::Range span, Text rest_text_, prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Env, Env>)> cont_fn);

Ex for_job(const Lx& lx, const Env& outer, const Env& env, const std::optional<ast::ForBinders>& binders_opt, const ast::Expr& source, const ast::Block& body, const ast::Range& span, const Text& rest_text_, const prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Env, Env>)>& cont_fn);

prism_rtl::JobRef<Ex> start_for_job(Lx lx, Env outer, Env env, std::optional<ast::ForBinders> binders_opt, ast::Expr source, ast::Block body, ast::Range span, Text rest_text_, prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Env, Env>)> cont_fn);

Text instance_of(const Text& k);

Array<std::tuple<Text, Ex, Holding, OutTy>> caps_in(const Env& env, const Text& text, const Array<Text>& skip);

std::optional<ast::Expr> frame_call(const Lx& lx, const Env& env, const ast::Expr& e, const bool& top);

prism_rtl::JobRef<std::optional<ast::Expr>> start_frame_call(Lx lx, Env env, ast::Expr e, bool top);

Array<ast::Expr> placeholders(const Array<ast::TextSeg>& segs);

std::optional<ast::Expr> first_frame(const Lx& lx, const Env& env, const Array<ast::Expr>& es);

prism_rtl::JobRef<std::optional<ast::Expr>> start_first_frame(Lx lx, Env env, Array<ast::Expr> es);

Ex frame(const Lx& lx, const Env& env, const ast::Expr& call, const Text& rest_text_, const prism_rtl::Fn<prism_rtl::JobRef<Ex>(Env)>& cont_fn);

prism_rtl::JobRef<Ex> start_frame(Lx lx, Env env, ast::Expr call, Text rest_text_, prism_rtl::Fn<prism_rtl::JobRef<Ex>(Env)> cont_fn);

std::optional<Vl> local_job_fn(const Lx& lx, const Env& env, const ast::Expr& c);

prism_rtl::JobRef<std::optional<Vl>> start_local_job_fn(Lx lx, Env env, ast::Expr c);

std::optional<Vl> job_value(const Vl& f);

Ex start_call(const Vl& f, const Array<Ex>& vals);

Ex one_or_tuple(const Array<Ex>& xs0);

Text callee_text(const ast::Expr& c);

Text rest_text(const Lx& lx, const ast::Range& from, const ast::Range& call, const ast::Range& to);

bool mentions(const Text& text, const Text& name);

bool ends_ident(const Text& t);

bool starts_ident(const Text& t);

Ex tail_body(const Lx& lx, const Env& env, const ast::FnBody& fn_body2);

prism_rtl::JobRef<Ex> start_tail_body(Lx lx, Env env, ast::FnBody fn_body2);

Ex tail_match(const Lx& lx, const Env& env, const ast::Expr& s, const Array<ast::Arm>& arms, const ast::Range& span);

prism_rtl::JobRef<Ex> start_tail_match(Lx lx, Env env, ast::Expr s, Array<ast::Arm> arms, ast::Range span);

std::optional<Text> tail_callee(const Lx& lx, const Env& env, const ast::Expr& callee);

std::tuple<Array<check_types::Ty>, check_types::Ty> scheme_parts(const Lx& lx, const Text& qk);

Array<Text> job_field_names(const Lx& lx, const Text& qk);

prism_rtl::JobRef<Array<Text>> start_job_field_names(Lx lx, Text qk);

Array<ast::FnClause> clauses_of(const check_env::G& g, const Text& qk);

Array<ast::FnClause> def_clauses(const check_env::Def& d, const Array<ast::FnClause>& other);

JobDef job_def_of(const Lx& lx, const Text& qk, const Array<ast::FnClause>& clauses, const check_types::Scheme& sc);

prism_rtl::JobRef<JobDef> start_job_def_of(Lx lx, Text qk, Array<ast::FnClause> clauses, check_types::Scheme sc);

Ex job_clauses(const Lx& lx, const Array<ast::FnClause>& clauses, const Array<std::tuple<Text, bool>>& names, const Array<check_types::Ty>& ptys, const Array<OutTy>& pts);

prism_rtl::JobRef<Ex> start_job_clauses(Lx lx, Array<ast::FnClause> clauses, Array<std::tuple<Text, bool>> names, Array<check_types::Ty> ptys, Array<OutTy> pts);

Array<Do> id_pipe(const Ex& x, const prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(Ex)>& k_fn);

prism_rtl::JobRef<Array<Do>> start_id_pipe(Ex x, prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(Ex)> k_fn);

EvRef ev_ref_of(const Wx& wx, const Nat& n);

Text kind_word(const GnKind& k);

bool has_read(const Array<Read>& rs, const Read& r);

Array<Read> add_read(const Array<Read>& rs, const Read& r);

Array<Read> union_reads(const Array<Read>& xs, const Array<Read>& ys);

Array<Text> node_hooks();

Wx new_wx(const Lx& lx, const Text& name, const Array<std::tuple<Text, OutTy, Text>>& fields, const Array<std::tuple<Text, Ex>>& inits, const Array<std::tuple<Text, Ex>>& moves_, const Array<MethDef>& getters, const Map<Text, Array<Read>>& dyn_reads, const Array<Text>& taken, const Nat& depth, const std::optional<Text>& hosted_by_opt);

std::tuple<Text, Wx> fresh_name(const Wx& wx, const Text& base_);

Nat first_free(const Array<Text>& taken, const Text& base_, const Nat& from);

std::tuple<Nat, Wx> add_gn(const Wx& wx, const Text& name, const OutTy& ty, const GnKind& kind, const Nat& height);

Wx connect(const Wx& wx, const EvRef& r, const Sk& sink);

Wx crossed(const Wx& wx, const Text& what);

Gn add_out(const Gn& n, const Out& o);

Wx add_field(const Wx& wx, const Text& name, const OutTy& t, const Text& doc, const Ex& init);

Wx add_field_last(const Wx& wx, const Text& name, const OutTy& t, const Text& doc, const Ex& init);

Gn gn_of(const Wx& wx, const Nat& n);

std::tuple<Env, Env> bind_plain(const Env& benv, const Env& menv, const Text& nkey, const Text& rs, const OutTy& t);

NodeDef node_def_of(const Lx& lx, const Text& qk, const Array<ast::Pattern_>& params, const ast::Block& body, const check_types::Scheme& sc, const bool& is_root);

prism_rtl::JobRef<NodeDef> start_node_def_of(Lx lx, Text qk, Array<ast::Pattern_> params, ast::Block body, check_types::Scheme sc, bool is_root);

Wx root_result(const Wx& wx);

Wx block_into(const Wx& wx, const Env& benv, const Env& menv, const ast::Block& b);

prism_rtl::JobRef<Wx> start_block_into(Wx wx, Env benv, Env menv, ast::Block b);

std::tuple<Wx, Env, Env> pre_bind(const Wx& wx, const Env& benv, const Env& menv, const ast::Stmt& s);

prism_rtl::JobRef<std::tuple<Wx, Env, Env>> start_pre_bind(Wx wx, Env benv, Env menv, ast::Stmt s);

HowBound how_bound(const std::optional<ast::Expr>& opt0);

std::tuple<Wx, Env, Env> pre_bind_name(const Wx& wx, const Env& benv, const Env& menv, const ast::SName& n, const HowBound& how);

prism_rtl::JobRef<std::tuple<Wx, Env, Env>> start_pre_bind_name(Wx wx, Env benv, Env menv, ast::SName n, HowBound how);

Env with_use(const Env& env, const Text& ukey, const Text& bkey);

std::optional<Array<std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>>>> many_instances(const Lx& lx, const ast::Range& span);

prism_rtl::JobRef<std::optional<Array<std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>>>>> start_many_instances(Lx lx, ast::Range span);

bool is_switched(const check_types::Ty& t);

std::optional<Bn> binding_of(const Env& env, const ast::Pattern_& p_);

std::optional<Bn> binding_of_name(const Env& env, const ast::Pattern_& p_);

std::tuple<Wx, Env, Env> widget_stmt(const Wx& wx, const Env& benv, const Env& menv, const ast::Stmt& s, const bool& last);

prism_rtl::JobRef<std::tuple<Wx, Env, Env>> start_widget_stmt(Wx wx, Env benv, Env menv, ast::Stmt s, bool last);

std::tuple<Wx, Env, Env> bind_hosted(const Wx& wx, const Env& benv, const Env& menv, const Wres& res, const Bn& doc, const Array<ast::Pattern_>& ps);

std::tuple<Env, Env> bind_part(const Env& benv, const Env& menv, const std::optional<ast::Pattern_>& p__opt, const std::optional<Bn>& b_opt);

std::tuple<Wx, Env, Env> bind_part2(const Wx& wx, const Env& benv, const Env& menv, const std::optional<ast::Pattern_>& p__opt, const std::optional<Bn>& b_opt);

Wx set_result(const Wx& wx, const Wres& res);

std::tuple<Wres, Wx> result_of(const Wx& wx, const Env& benv, const Env& menv, const ast::Expr& x);

prism_rtl::JobRef<std::tuple<Wres, Wx>> start_result_of(Wx wx, Env benv, Env menv, ast::Expr x);

std::tuple<Wres, Wx> result_of_typed(const Wx& wx, const Env& benv, const Env& menv, const ast::Expr& x, const check_types::Ty& full, const OutTy& t);

prism_rtl::JobRef<std::tuple<Wres, Wx>> start_result_of_typed(Wx wx, Env benv, Env menv, ast::Expr x, check_types::Ty full, OutTy t);

std::tuple<Wx, Env> hold_line(const Wx& wx, const Env& benv, const Env& menv, const ast::Pattern_& p_, const ast::Expr& init, const ast::Expr& step_);

prism_rtl::JobRef<std::tuple<Wx, Env>> start_hold_line(Wx wx, Env benv, Env menv, ast::Pattern_ p_, ast::Expr init, ast::Expr step_);

Env init_env(const Env& env);

bool all_inited(const Wx& wx, const Array<Read>& reads);

Text pat_text(const ast::Pattern_& p_);

std::tuple<Wx, Env> let_line(const Wx& wx, const Env& benv, const Env& menv, const ast::Pattern_& p_, const ast::Expr& e);

prism_rtl::JobRef<std::tuple<Wx, Env>> start_let_line(Wx wx, Env benv, Env menv, ast::Pattern_ p_, ast::Expr e);

Wx widget_let_field(const Wx& wx, const Text& f, const OutTy& t, const Ex& v_, const Text& doc);

EvRef err_pipe(const EvRef& r);

Ex own_as(const OutTy& t, const Vl& v_);

Wx bind_res(const Wx& wx2, const Env& menv, const ast::Pattern_& p_, const Wres& res);

std::tuple<Wx, Wres> build_line(const Wx& wx, const Env& benv, const Env& menv, const ast::Expr& e, const std::optional<Bn>& bound_opt);

prism_rtl::JobRef<std::tuple<Wx, Wres>> start_build_line(Wx wx, Env benv, Env menv, ast::Expr e, std::optional<Bn> bound_opt);

std::tuple<Wx, Wres> element_line(const Wx& wx, const Env& benv, const Env& menv, const ast::Expr& e, const std::optional<Bn>& bound_opt);

prism_rtl::JobRef<std::tuple<Wx, Wres>> start_element_line(Wx wx, Env benv, Env menv, ast::Expr e, std::optional<Bn> bound_opt);

OutTy element_out(const Lx& lx, const check_env::TagInfo& tg, const check_types::Ty& full);

Text tag_name_of(const Lx& lx, const ast::Expr& c);

std::optional<ast::Expr> tag_arg(const Array<ast::Arg>& args, const Text& fname);

Text request_field(const check_env::TagInfo& tg, const Text& fname);

std::tuple<Wx, Wres> element_output(const Wx& wx, const Env& menv, const check_env::TagInfo& tg, const OutTy& out, const Pos_& pos, const std::optional<Bn>& bound_opt, const Ex& level);

std::tuple<Wx, Wres> bundle_output(const Wx& wx, const check_env::TagInfo& tg, const OutTy& out, const Pos_& pos, const Array<std::optional<Bn>>& parts, const Ex& level);

std::tuple<Wx, Wres> bundle_output_of(const Wx& wx, const check_env::TagInfo& tg, const OutTy& out, const Pos_& pos, const Array<std::optional<Bn>>& parts, const Ex& level);

Wx bundle_first(const Wx& wx, const check_env::TagInfo& tg, const Pos_& pos, const Array<Nat>& plain_ix, const Array<OutTy>& tys, const Array<std::optional<Bn>>& parts, const Ex& level);

Wx bundle_answer(const Wx& wx, const Pos_& pos, const OutTy& et, const std::optional<Bn>& b_opt);

Do first_value_let(const Wx& wx, const Pos_& pos, const check_env::TagInfo& tg, const Ex& level);

Text host_local(const Wx& wx, const Pos_& pos);

Text answer_variant(const check_env::TagInfo& tg);

Text answer_accessor(const check_env::TagInfo& tg);

std::tuple<Wx, Wres> element_output_of(const Wx& wx, const Env& menv, const check_env::TagInfo& tg, const OutTy& out, const Pos_& pos, const std::optional<Bn>& bound_opt, const Ex& level);

std::tuple<Wx, Wres> widget_line(const Wx& wx, const Env& benv, const Env& menv, const ast::Expr& e, const std::optional<Bn>& bound_opt);

prism_rtl::JobRef<std::tuple<Wx, Wres>> start_widget_line(Wx wx, Env benv, Env menv, ast::Expr e, std::optional<Bn> bound_opt);

std::tuple<Wx, Wres> apply_widget_param(const Wx& wx, const ast::Expr& x, const Env& cbenv, const Env& cmenv, const Lx& clx, const Nat& nargs);

std::tuple<Wx, Wres> inline_block(const Wx& wx, const Env& benv, const Env& menv, const ast::Block& b, const Lx& lx);

prism_rtl::JobRef<std::tuple<Wx, Wres>> start_inline_block(Wx wx, Env benv, Env menv, ast::Block b, Lx lx);

std::tuple<Wx, Wres> widget_call(const Wx& wx, const Env& benv, const Env& menv, const ast::Expr& e, const std::optional<Bn>& bound_opt, const Text& qk, const Array<ast::Arg>& args, const std::optional<Nat>& target_opt);

std::tuple<Wx, Wres> host_line(const Wx& wx, const Env& benv, const Env& menv, const HostForm& form, const Array<ast::Arg>& args, const std::optional<Bn>& bound_opt);

bool is_widget_name(const ast::Expr& e);

std::tuple<Wx, Env, Array<Do>> dynamic_answers(const Wx& wx, const Env& benv, const Env& menv, const Text& hf, const ast::Expr& sup);

std::optional<ast::Expr> dynamic_answer(const Lx& lx, const ast::Expr& x);

Text dyn_key(const ast::Expr& x);

MethDef host_doc_getter(const Text& name, const Pos_& pos, const Array<Place>& places, const Array<ForDef>& builders, const Array<GenDef>& gens);

MethDef snap_getter(const Text& name, const OutTy& t, const Text& doc);

std::tuple<Wx, Wres> started_line(const Wx& wx, const std::optional<Bn>& bound_opt);

std::tuple<Wx, Wres> defer_line(const Wx& wx, const Env& menv, const Array<ast::Arg>& args, const ast::Expr& e, const std::optional<Nat>& target_opt);

std::tuple<Wx, Wres> run_line(const Wx& wx, const Env& benv, const Array<ast::Arg>& args, const ast::Expr& e, const std::optional<Nat>& target_opt);

std::tuple<Wx, Wres> machine_line(const Wx& wx, const Env& benv, const Env& menv, const Array<ast::Arg>& args, const ast::Expr& e, const std::optional<Nat>& target_opt);

std::tuple<Wx, Wres> inline_widget(const Wx& wx, const Env& benv, const Env& menv, const Text& qk, const check_env::ValInfo& v_, const Array<ast::Arg>& args, const ast::Expr& e);

std::optional<ast::WidgetDecl> widget_decl_of(const check_env::G& g, const Text& qk);

std::optional<ast::WidgetDecl> def_widget(const check_env::Def& d, const std::optional<ast::WidgetDecl>& other_opt);

std::tuple<Wx, Env, Env> bind_param(const Wx& wx, const Env& cbenv, const Env& cmenv, const Env& be, const Env& me, const Text& nkey, const check_types::Ty& pty, const ast::Expr& arg);

std::tuple<Ex, Array<Read>> dynamic_expr(const Wx& wx, const Env& menv, const ast::Expr& e);

prism_rtl::JobRef<std::tuple<Ex, Array<Read>>> start_dynamic_expr(Wx wx, Env menv, ast::Expr e);

std::tuple<EvRef, Wx> never_event(const Wx& wx, const OutTy& t);

std::tuple<EvRef, Wx> event_ref(const Wx& wx, const Env& menv, const ast::Expr& e);

prism_rtl::JobRef<std::tuple<EvRef, Wx>> start_event_ref(Wx wx, Env menv, ast::Expr e);

std::tuple<EvRef, Wx> event_if(const Wx& wx, const Env& menv, const ast::Expr& c, const ast::Expr& a, const ast::Expr& b, const OutTy& t);

std::optional<ast::Expr> block_expr(const ast::Block& b);

Text callee_key(const Lx& lx, const ast::Expr& c);

std::tuple<EvRef, Wx> pair_event(const Wx& wx, const Env& menv, const Array<ast::Arg>& args, const GnKind& kind, const OutTy& t);

std::tuple<EvRef, Wx> merge_all_event(const Wx& wx, const Env& menv, const Array<ast::Arg>& args, const OutTy& t);

std::tuple<EvRef, Wx> updated_event(const Wx& wx, const Env& menv, const Array<ast::Arg>& args, const OutTy& t);

std::tuple<EvRef, Wx> filter_event(const Wx& wx, const Env& menv, const Array<ast::Arg>& args, const bool& is_unit);

std::tuple<EvRef, Wx> gate_event(const Wx& wx, const Env& menv, const Array<ast::Arg>& args);

std::tuple<EvRef, Wx> event_map(const Wx& wx, const Env& menv, const ast::Expr& e);

Vl firing_value(const Ex& ex0, const OutTy& t);

Array<ast::Expr> operands(const ast::Expr& e);

std::tuple<Nat, Wx> merge(const Wx& wx, const Text& name, const OutTy& t, const EvRef& l, const EvRef& r);

std::tuple<Nat, Wx> combinator(const Wx& wx, const Text& name, const OutTy& t, const GnKind& kind, const EvRef& l, const EvRef& r, const OutTy& lt, const OutTy& rt);

Gn with_inputs(const Gn& n, const Array<Text>& ins);

Gn with_reads(const Gn& n, const Array<Read>& reads);

Array<Gn> heights(const Array<Gn>& gns);

Gn height_step(const Array<Gn>& gns, const Gn& n);

bool is_comb(const GnKind& k);

bool feeds(const Sk& sk0, const Gn& n);

bool writes(const Text& f, const Gn& n);

bool moves(const Read& r, const Gn& n);

Array<Read> reads_closed(const Map<Text, Array<Read>>& dyn_, const Array<Read>& reads);

Array<Read> getter_reads(const Map<Text, Array<Read>>& dyn_, const Read& read1);

bool reaches_snap(const Array<Text>& roots, const Array<Read>& reads);

Array<Text> snap_names(const Wx& wx);

Text wake_const(const Array<Nat>& heights_, const Nat& h);

Do self_call(const Text& m, const Array<Ex>& args);

Array<Do> sink_code(const Sinks& sk, const Sk& target, const Ex& y);

Array<Do> hold_written(const Sinks& sk, const Text& f);

Ex host_field_ex(const Wx& wx, const Pos_& pos);

Array<Do> moved_marks(const Sinks& sk, const Text& f);

Array<Do> moved_by(const Sinks& sk, const Read& r);

Array<Do> source_marks(const Wx& wx, const Read& r);

Array<SnapDef> snaps_behind(const Wx& wx, const Read& r);

bool lists_build(const Sinks& sk, const Read& r);

Array<Do> firing_code(const Sinks& sk, const Gn& g, const Ex& x);

prism_rtl::JobRef<Array<Do>> start_firing_code(Sinks sk, Gn g, Ex x);

NodeDef finish_node(const Wx& wx0, const Text& qk, const Array<std::tuple<Text, OutTy>>& params, const bool& is_row);

prism_rtl::JobRef<NodeDef> start_finish_node(Wx wx0, Text qk, Array<std::tuple<Text, OutTy>> params, bool is_row);

bool is_generation(const Wx& wx, const Text& name);

Array<MethDef> flatten_methods(const Sinks& sk);

MethDef host_moved(const Sinks& sk, const HostDef& h);

Array<Do> build_steps(const Sinks& sk, const bool& at_build);

Do snap_take_at_build(const SnapDef& sn);

Do snap_take(const Sinks& sk, const SnapDef& sn);

MethDef snap_publish(const Sinks& sk, const SnapDef& sn);

MethDef gathered_moved(const SnapDef& sn);

MethDef document_getter(const Wx& wx);

MethDef document_moved(const Text& m);

Array<Do> document_body(const prism_rtl::Fn<prism_rtl::JobRef<Do>(std::tuple<Ex, Ex>)>& add_fn, const Array<Place>& places, const Array<ForDef>& builders, const Array<GenDef>& gens);

Do map_insert(const Ex& path_, const Ex& e);

Do vec_push(const Ex& path_, const Ex& e);

std::tuple<Pa, Ex> dyn_answer_arm(const Sinks& sk, const Pos_& pos, const Text& f, const OutTy& t);

Array<Do> dyn_place_write(const Sinks& sk, const Text& f, const Ex& value);

Array<Do> updated_gaps(const Wx& wx, const Array<Gn>& gns, const bool& is_gen);

std::tuple<Array<NodeDef>, Array<Gn>> finish_pending(const Wx& wx, const Array<Gn>& gns);

prism_rtl::JobRef<std::tuple<Array<NodeDef>, Array<Gn>>> start_finish_pending(Wx wx, Array<Gn> gns);

Nat parent_floor(const Wx& wx, const Array<Gn>& gns, const Array<Read>& reads);

bool writes_hold(const Gn& g, const Text& f);

bool sink_writes_hold(const Sk& sk0, const Text& f);

Gn with_floor(const Gn& g, const Nat& h);

Gn with_height(const Gn& g, const Nat& h);

Array<Text> row_hears(const Wx& wx);

Array<Do> row_written(const Wx& wx, const RowMarks& rm, const Read& r);

Array<Do> patch_place(const Wx& wx, const Place& p_);

bool emits(const Wx& wx, const Pos_& pos);

Array<Do> result_told(const Ex& node_);

Array<Do> result_moved(const Ex& node_);

Do result_kept(const Ex& node_);

Do result_tell();

Array<Do> adoption(const FlatDef& fl);

Ex place_at(const Wx& wx, const Text& recv, const Pos_& pos);

Pa pos_pat(const Pos_& pos, const Array<Pa>& tail_);

Array<Pa> key_tail();

Array<Pa> gen_tail();

std::optional<Text> hosted_rows(const Wx& wx);

Array<Do> root_dyn_patch(const Wx& wx);

std::tuple<Pa, Ex> answer_arm(const Wx& wx, const Pos_& pos, const Nat& id, const OutTy& t);

std::tuple<Pa, Array<Do>> typed_answer_arm(const Wx& wx, const Pos_& pos, const Nat& id, const Text& acc);

std::tuple<Pa, Array<Do>> typed_dyn_arm(const Sinks& sk, const Pos_& pos, const Text& f, const Text& acc);

std::tuple<Pa, Array<Do>> typed_forward_arm(const ForDef& b, const Ex& segs);

std::tuple<Pa, Array<Do>> typed_gen_arm(const GenDef& gd);

MethDef typed_dispatch(const Sinks& sk, const Text& name, const Nat& scope);

HostDef dummy_host();

Array<Nat> sort_nats(const Array<Nat>& xs);

Array<Do> ask_wake(const Sinks& sk, const Nat& h);

MethDef gather_in(const Sinks& sk, const Gn& g);

Do decide(const Gn& g);

Do updated_decide(const Gn& g);

Do pair_decide(const Gn& g, const GnKind& kind);

Do wake_by_height(const Array<Gn>& combs, const Array<Nat>& heights_);

Ex forward_answer(const ForDef& b);

bool is_hold(const OutTy& out_ty0);

Array<MethDef> row_methods(const Wx& wx);

Text gn_doc(const Gn& g);

Do merge_decide(const Gn& g);

Lx in_module(const Lx& lx, const Nat& file, const Text& home);

Lx in_module_at(const Lx& lx, const Nat& file, const Text& home, const Text& site);

Model lower_program(const Array<check_errors::Src>& srcs, const Array<ast::Module>& trees, const Nat& shown, const typed::TProgram& tp, const Text& name);

prism_rtl::JobRef<Model> start_lower_program(Array<check_errors::Src> srcs, Array<ast::Module> trees, Nat shown, typed::TProgram tp, Text name);

Array<ModDef> with_needs(const check_env::G& g, const Array<check_errors::Src>& srcs, const typed::TProgram& tp, const Array<ModDef>& defs);

prism_rtl::JobRef<Array<ModDef>> start_with_needs(check_env::G g, Array<check_errors::Src> srcs, typed::TProgram tp, Array<ModDef> defs);

Map<Text, Array<Text>> named_mods(const check_env::G& g, const Array<check_errors::Src>& srcs, const typed::TProgram& tp, const Array<Text>& ms);

prism_rtl::JobRef<Map<Text, Array<Text>>> start_named_mods(check_env::G g, Array<check_errors::Src> srcs, typed::TProgram tp, Array<Text> ms);

Text impl_path(const Text& how);

Map<Text, bool> value_types(const Array<ModDef>& defs);

Array<Text> item_held(const Array<Text>& names, const Map<Text, bool>& value_tys, const Text& home, const Item& it);

Array<Text> held_in(const Array<Text>& names, const Map<Text, bool>& value_tys, const Text& home, const OutTy& t);

Array<Text> named_in(const Array<Text>& names, const Text& home, const OutTy& t);

Text path_from(const Array<Text>& names, const Text& home, const Text& n);

Text parent_of(const Text& p_);

Array<ModDef> with_groups(const Array<ModDef>& defs);

prism_rtl::JobRef<Array<ModDef>> start_with_groups(Array<ModDef> defs);

Array<Text> reached_by(const Map<Text, Array<Text>>& edges, const Array<Text>& todo, const Array<Text>& seen);

prism_rtl::JobRef<Array<Text>> start_reached_by(Map<Text, Array<Text>> edges, Array<Text> todo, Array<Text> seen);

Array<Text> needed_mods(const check_env::G& g, const Nat& shown);

prism_rtl::JobRef<Array<Text>> start_needed_mods(check_env::G g, Nat shown);

Array<Text> mod_refs(const check_env::G& g, const Text& m);

prism_rtl::JobRef<Array<Text>> start_mod_refs(check_env::G g, Text m);

Array<std::tuple<Text, bool>> root_widgets(const Lx& lx);

bool is_main(const Text& qk);

Text blueprint_qk(const Lx& lx, const ast::Expr& e);

check_env::ValInfo val_of(const Lx& lx, const Text& qk);

ProgDef prog_def_of(const Lx& lx, const Text& qk);

prism_rtl::JobRef<ProgDef> start_prog_def_of(Lx lx, Text qk);

Array<Text> job_roots(const Lx& lx);

prism_rtl::JobRef<Array<Text>> start_job_roots(Lx lx);

Array<Text> unbounded_values(const Lx& lx, const check_env::Def& d);

prism_rtl::JobRef<Array<Text>> start_unbounded_values(Lx lx, check_env::Def d);

bool in_prelude(const Lx& lx, const Text& q);

bool is_color_poly(const Lx& lx, const Text& q);

bool enters_at_once(const Lx& lx, const Text& q, const Array<ast::Arg>& args);

bool is_unbounded_arg(const Lx& lx, const ast::Arg& a);

bool is_unbounded(const Lx& lx, const Text& q);

Array<Text> run_targets(const Lx& lx, const check_env::Def& d);

prism_rtl::JobRef<Array<Text>> start_run_targets(Lx lx, check_env::Def d);

Array<Text> tail_targets(const Lx& lx, const Text& qk);

prism_rtl::JobRef<Array<Text>> start_tail_targets(Lx lx, Text qk);

Array<Text> tails_of_body(const Lx& lx, const ast::FnBody& body);

prism_rtl::JobRef<Array<Text>> start_tails_of_body(Lx lx, ast::FnBody body);

ModDef mod_def_of(const Lx& lx0, const Text& m, const Array<std::tuple<Text, bool>>& roots, const check_env::ModInfo& info, const Array<Text>& mods);

prism_rtl::JobRef<ModDef> start_mod_def_of(Lx lx0, Text m, Array<std::tuple<Text, bool>> roots, check_env::ModInfo info, Array<Text> mods);

Array<Item> def_items(const Lx& lx, const check_env::Def& d, const Array<std::tuple<Text, bool>>& roots);

prism_rtl::JobRef<Array<Item>> start_def_items(Lx lx, check_env::Def d, Array<std::tuple<Text, bool>> roots);

Array<Item> node_items(const NodeDef& n);

Array<Item> ty_defs(const Lx& lx, const check_env::TyInfo& ti);

prism_rtl::JobRef<Array<Item>> start_ty_defs(Lx lx, check_env::TyInfo ti);

bool ty_podable(const Lx& lx, const check_types::Ty& t, const Array<Text>& seen);

prism_rtl::JobRef<bool> start_ty_podable(Lx lx, check_types::Ty t, Array<Text> seen);

bool ty_has_eq(const Lx& lx, const check_types::Ty& t, const Array<Text>& seen);

bool has_own_eq(const Lx& lx, const Text& tn);

OutTy case_field(const Lx& lx, const Text& ck, const Nat& i, const check_types::Ty& t);

prism_rtl::JobRef<OutTy> start_case_field(Lx lx, Text ck, Nat i, check_types::Ty t);

Text type_doc(const Lx& lx, const check_env::TyInfo& ti);

TagDef tag_def_of(const Lx& lx, const check_env::TagInfo& tg);

prism_rtl::JobRef<TagDef> start_tag_def_of(Lx lx, check_env::TagInfo tg);

Array<std::tuple<Text, check_types::Ty>> level_fields(const check_env::TagInfo& tg);

Array<check_env::TagInfo> kind_tags(const Lx& lx, const Text& kind, const Array<Text>& mods);

RowDef row_def_of(const Lx& lx, const check_env::TyInfo& ti);

prism_rtl::JobRef<RowDef> start_row_def_of(Lx lx, check_env::TyInfo ti);

RowDef elem_row(const Lx& lx, const Array<Text>& mods);

prism_rtl::JobRef<RowDef> start_elem_row(Lx lx, Array<Text> mods);

AnswerDef answer_enum(const Lx& lx, const Array<Text>& mods);

prism_rtl::JobRef<AnswerDef> start_answer_enum(Lx lx, Array<Text> mods);

OutTy answer_ty(const Lx& lx, const check_env::TagInfo& tg);

prism_rtl::JobRef<OutTy> start_answer_ty(Lx lx, check_env::TagInfo tg);

std::tuple<Text, Text> tag_paths(const Lx& lx, const check_env::TagInfo& tg);

Text variant_of(const Lx& lx, const check_env::TagInfo& tg);

Text kind_path(const Lx& lx, const Text& kind);

CheckDef check_def_of(const Lx& lx, const ast::CheckDecl& c);

prism_rtl::JobRef<CheckDef> start_check_def_of(Lx lx, ast::CheckDecl c);

std::tuple<Wx, Wres> for_line(const Wx& wx, const Env& benv, const Env& menv, const std::optional<ast::ForBinders>& binders_opt, const ast::Expr& source, const ast::Block& body, const ast::Expr& e, const std::optional<Bn>& bound_opt);

prism_rtl::JobRef<std::tuple<Wx, Wres>> start_for_line(Wx wx, Env benv, Env menv, std::optional<ast::ForBinders> binders_opt, ast::Expr source, ast::Block body, ast::Expr e, std::optional<Bn> bound_opt);

MethDef entry_getter(const Text& src_getter, const OutTy& vt);

Wx add_builder(const Wx& wx, const Text& name, const Pos_& pos, const OutTy& kt, const OutTy& vt, const Text& row_name, const bool& keyed, const Array<Read>& reads, const PendingRow& waiting, const Array<Ex>& passed);

Array<Read> row_place_reads(const Wx& row_wx);

Array<std::tuple<Text, OutTy>> hosted_params(const Wx& wx);

Array<Ex> hosted_passed(const Wx& wx);

Env row_reads(const Env& env, const Ex& pref);

Env events_of(const Env& ports, const Env& env);

Array<Read> block_reads(const Array<Read>& reads);

Array<RowLocal> row_locals(const Env& benv, const Env& menv, const ast::Block& body);

std::tuple<Env, Env> for_envs(const Env& benv, const Env& menv, const std::optional<ast::ForBinders>& binders_opt, const Bn& key_b, const Bn& key_m, const Bn& val_b, const Bn& val_m, const OutTy& vt);

OutTy kt0();

Env bind_pat(const Env& env, const ast::Pattern_& p_, const Bn& b, const Ex& whole, const OutTy& t);

Bn part_bn(const Bn& bn0, const Ex& whole, const Nat& i, const OutTy& t);

Text row_suffix(const Wx& wx);

OutTy gn_ty_named(const Wx& wx, const Text& n);

std::tuple<Wx, Wx, Env> row_env(const Wx& parent, const Wx& row_wx, const Env& menv, const ast::Block& body);

Ex over_parent(const Ex& x);

Ex parent_ref();

Ex parent_arg();

Wx with_port(const Wx& wx, const Text& pname);

std::tuple<Wx, Wres> rebuild_line(const Wx& wx, const Env& benv, const Env& menv, const ast::Expr& scrut, const ast::Block& body, const ast::Expr& e, const std::optional<Bn>& bound_opt);

prism_rtl::JobRef<std::tuple<Wx, Wres>> start_rebuild_line(Wx wx, Env benv, Env menv, ast::Expr scrut, ast::Block body, ast::Expr e, std::optional<Bn> bound_opt);

bool gives_dynamic(const check_types::Ty& t);

std::tuple<Wx, Wres> rebuild_dynamic(const Wx& wx, const Env& menv, const ast::Block& body, const Ex& src_ex, const Array<Read>& reads, const OutTy& vt, const Text& name, const Pos_& pos);

std::tuple<Wx, Wres> clause_widget_line(const Wx& wx, const Env& menv, const ast::Expr& scrut, const ast::Block& call, const Text& qk, const check_env::ValInfo& v_, const ast::Expr& e);

bool is_hosted_scope(const Wx& wx);

template <class A>
bool is_some(const std::optional<A>& opt0);

std::tuple<Array<GenCase>, Wx> gen_cases(const Wx& wx, const Env& menv, const ast::Block& body, const OutTy& vt, const Text& name);

std::optional<std::tuple<Text, Array<ast::Arg>>> clause_call(const Lx& lx, const ast::Block& body);

std::optional<std::tuple<Text, Array<ast::Arg>>> clause_call_x(const Lx& lx, const ast::Expr& x);

ClauseRow clause_row_of(const Wx& wx, const Env& menv, const ast::FnClause& c, const check_env::ValInfo& v_, const Text& row_name, const Text& gen_name, const bool& transparent);

GenRow gen_row_of(const Wx& wx, const Env& menv, const ast::Block& body, const OutTy& vt, const Text& row_name, const Text& gen_name);

Wx gen_result(const Wx& r, const Text& gen_name, const Ex& ex, const Array<Read>& result_reads, const OutTy& rt);

Wx gen_marked(const Wx& parent, const Text& gen_name, const Wx& row_wx);

Env build_spelling(const Env& env);

Ex gen_select(const Wx& wx, const Env& menv, const ast::Block& body, const Array<GenCase>& cases, const Pos_& pos);

MethDef gen_up(const Text& name, const Text& up_name, const OutTy& t);

Array<std::tuple<Pa, Ex>> gen_forwards(const GenDef& gd);

Ex forward_gen(const GenDef& gd);

std::tuple<Wx, Wres> flatten_line(const Wx& wx, const Env& menv, const Array<ast::Arg>& args, const std::optional<Bn>& bound_opt);

std::tuple<Wx, Wres> switch_line(const Wx& wx, const Env& menv, const Array<ast::Arg>& args);

bool has_own_show(const Lx& lx, const Text& tn);

Text head_name(const check_types::Ty& ty0);

check_types::Ty self_in(const check_types::Ty& t, const Text& param);

prism_rtl::JobRef<check_types::Ty> start_self_in(check_types::Ty t, Text param);

TraitDef trait_def_of(const Lx& lx0, const check_env::TraitInfo& tr);

prism_rtl::JobRef<TraitDef> start_trait_def_of(Lx lx0, check_env::TraitInfo tr);

Array<ast::FnClause> default_clauses(const check_env::G& g, const Text& qk);

Array<ast::FnClause> default_of(const check_env::Def& d, const Array<ast::FnClause>& other);

ImplDef impl_def_of(const Lx& lx, const check_env::ImplInfo& im);

prism_rtl::JobRef<ImplDef> start_impl_def_of(Lx lx, check_env::ImplInfo im);

FnDef renamed(const FnDef& fd, const Text& n);

bool is_method_of(const check_env::Def& d, const check_env::ImplInfo& im);

Array<ast::FnClause> method_clauses(const check_env::Def& d);

std::tuple<Wx, Wres> if_gen_line(const Wx& wx, const Env& menv, const ast::Expr& c, const ast::Block& then_b, const ast::Block& else_b, const ast::Expr& e);

prism_rtl::JobRef<std::tuple<Wx, Wres>> start_if_gen_line(Wx wx, Env menv, ast::Expr c, ast::Block then_b, ast::Block else_b, ast::Expr e);

}  // namespace lower


namespace lower {

/// The step machine of `OutTyOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// OutTyOf: unbounded fn Lx, Ty -> OutTy
struct OutTyOf : prism_rtl::Job<OutTy> {
    Lx lx;
    check_types::Ty t;
    OutTyOf(Lx lx, check_types::Ty t) : lx(std::move(lx)), t(std::move(t)) {}
    prism_rtl::Turn<OutTy> cycle() const override;
};


/// The step machine of `RustTyOfParams`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RustTyOfParams: unbounded fn Lx, [Ty] -> OutTy
struct RustTyOfParams : prism_rtl::Job<OutTy> {
    Lx lx;
    Array<check_types::Ty> ps;
    RustTyOfParams(Lx lx, Array<check_types::Ty> ps) : lx(std::move(lx)), ps(std::move(ps)) {}
    prism_rtl::Turn<OutTy> cycle() const override;
};


/// The step machine of `NamedTy`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// NamedTy: unbounded fn Lx, Text, [OutTy] -> OutTy
struct NamedTy : prism_rtl::Job<OutTy> {
    Lx lx;
    Text n;
    Array<OutTy> args;
    NamedTy(Lx lx, Text n, Array<OutTy> args) : lx(std::move(lx)), n(std::move(n)), args(std::move(args)) {}
    prism_rtl::Turn<OutTy> cycle() const override;
};


/// The step machine of `Layouts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Layouts: unbounded fn G -> (Text ==> [Bool])
struct Layouts : prism_rtl::Job<Map<Text, Array<bool>>> {
    check_env::G g;
    Layouts(check_env::G g) : g(std::move(g)) {}
    prism_rtl::Turn<Map<Text, Array<bool>>> cycle() const override;
};


/// The step machine of `Reaches`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Reaches: unbounded fn G, Ty, Text, [Text] -> Bool
struct Reaches : prism_rtl::Job<bool> {
    check_env::G g;
    check_types::Ty t;
    Text target;
    Array<Text> seen;
    Reaches(check_env::G g, check_types::Ty t, Text target, Array<Text> seen) : g(std::move(g)), t(std::move(t)), target(std::move(target)), seen(std::move(seen)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `Floaty`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Floaty: unbounded fn G, Ty, [Text] -> Bool
struct Floaty : prism_rtl::Job<bool> {
    check_env::G g;
    check_types::Ty t;
    Array<Text> seen;
    Floaty(check_env::G g, check_types::Ty t, Array<Text> seen) : g(std::move(g)), t(std::move(t)), seen(std::move(seen)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `Podable`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Podable: unbounded fn OutTy -> Bool
struct Podable : prism_rtl::Job<bool> {
    OutTy t;
    Podable(OutTy t) : t(std::move(t)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `LiteralValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LiteralValue: unbounded fn Lx, Env, Literal, Range, Bool -> Vl
struct LiteralValue : prism_rtl::Job<Vl> {
    Lx lx;
    Env env;
    ast::Literal l;
    ast::Range span;
    bool neg;
    LiteralValue(Lx lx, Env env, ast::Literal l, ast::Range span, bool neg) : lx(std::move(lx)), env(std::move(env)), l(std::move(l)), span(std::move(span)), neg(std::move(neg)) {}
    prism_rtl::Turn<Vl> cycle() const override;
};


/// The step machine of `TextValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TextValue: unbounded fn Lx, Env, [TextSeg] -> Vl
struct TextValue : prism_rtl::Job<Vl> {
    Lx lx;
    Env env;
    Array<ast::TextSeg> segs;
    TextValue(Lx lx, Env env, Array<ast::TextSeg> segs) : lx(std::move(lx)), env(std::move(env)), segs(std::move(segs)) {}
    prism_rtl::Turn<Vl> cycle() const override;
};


/// The step machine of `SegEx`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SegEx: unbounded fn Lx, Env, TextSeg -> Ex
struct SegEx : prism_rtl::Job<Ex> {
    Lx lx;
    Env env;
    ast::TextSeg text_seg2;
    SegEx(Lx lx, Env env, ast::TextSeg text_seg2) : lx(std::move(lx)), env(std::move(env)), text_seg2(std::move(text_seg2)) {}
    prism_rtl::Turn<Ex> cycle() const override;
};


/// The step machine of `ValueOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ValueOf: unbounded fn Lx, Env, Expr -> Vl
struct ValueOf : prism_rtl::Job<Vl> {
    Lx lx;
    Env env;
    ast::Expr e;
    ValueOf(Lx lx, Env env, ast::Expr e) : lx(std::move(lx)), env(std::move(env)), e(std::move(e)) {}
    prism_rtl::Turn<Vl> cycle() const override;
};


/// The step machine of `UnboundValueOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// UnboundValueOf: unbounded fn Lx, Env, Expr -> Vl
struct UnboundValueOf : prism_rtl::Job<Vl> {
    Lx lx;
    Env env;
    ast::Expr e;
    UnboundValueOf(Lx lx, Env env, ast::Expr e) : lx(std::move(lx)), env(std::move(env)), e(std::move(e)) {}
    prism_rtl::Turn<Vl> cycle() const override;
};


/// The step machine of `IsEventValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// IsEventValue: unbounded fn Lx, Env, Expr -> Bool
struct IsEventValue : prism_rtl::Job<bool> {
    Lx lx;
    Env env;
    ast::Expr e;
    IsEventValue(Lx lx, Env env, ast::Expr e) : lx(std::move(lx)), env(std::move(env)), e(std::move(e)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `HasEventSource`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// HasEventSource: unbounded fn Lx, Env, Expr -> Bool
struct HasEventSource : prism_rtl::Job<bool> {
    Lx lx;
    Env env;
    ast::Expr e;
    HasEventSource(Lx lx, Env env, ast::Expr e) : lx(std::move(lx)), env(std::move(env)), e(std::move(e)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `IsEventSource`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// IsEventSource: unbounded fn Lx, Env, Expr -> Bool
struct IsEventSource : prism_rtl::Job<bool> {
    Lx lx;
    Env env;
    ast::Expr c;
    IsEventSource(Lx lx, Env env, ast::Expr c) : lx(std::move(lx)), env(std::move(env)), c(std::move(c)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `EventValueOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// EventValueOf: unbounded fn Lx, Env, Expr -> Vl
struct EventValueOf : prism_rtl::Job<Vl> {
    Lx lx;
    Env env;
    ast::Expr e;
    EventValueOf(Lx lx, Env env, ast::Expr e) : lx(std::move(lx)), env(std::move(env)), e(std::move(e)) {}
    prism_rtl::Turn<Vl> cycle() const override;
};


/// The step machine of `ValueByKind`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ValueByKind: unbounded fn Lx, Env, Expr -> Vl
struct ValueByKind : prism_rtl::Job<Vl> {
    Lx lx;
    Env env;
    ast::Expr e;
    ValueByKind(Lx lx, Env env, ast::Expr e) : lx(std::move(lx)), env(std::move(env)), e(std::move(e)) {}
    prism_rtl::Turn<Vl> cycle() const override;
};


/// The step machine of `PureBlueprint`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PureBlueprint: unbounded fn Lx, Env, Expr, OutTy -> Vl
struct PureBlueprint : prism_rtl::Job<Vl> {
    Lx lx;
    Env env;
    ast::Expr x;
    OutTy t;
    PureBlueprint(Lx lx, Env env, ast::Expr x, OutTy t) : lx(std::move(lx)), env(std::move(env)), x(std::move(x)), t(std::move(t)) {}
    prism_rtl::Turn<Vl> cycle() const override;
};


/// The step machine of `PlainBlueprint`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PlainBlueprint: unbounded fn Lx, Env, Expr, Text, OutTy -> Vl
struct PlainBlueprint : prism_rtl::Job<Vl> {
    Lx lx;
    Env env;
    ast::Expr x;
    Text variant;
    OutTy t;
    PlainBlueprint(Lx lx, Env env, ast::Expr x, Text variant, OutTy t) : lx(std::move(lx)), env(std::move(env)), x(std::move(x)), variant(std::move(variant)), t(std::move(t)) {}
    prism_rtl::Turn<Vl> cycle() const override;
};


/// The step machine of `DynamicBlueprint`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// DynamicBlueprint: unbounded fn Lx, Env, Expr, Expr, Text, OutTy -> Vl
struct DynamicBlueprint : prism_rtl::Job<Vl> {
    Lx lx;
    Env env;
    ast::Expr x;
    ast::Expr d;
    Text variant;
    OutTy t;
    DynamicBlueprint(Lx lx, Env env, ast::Expr x, ast::Expr d, Text variant, OutTy t) : lx(std::move(lx)), env(std::move(env)), x(std::move(x)), d(std::move(d)), variant(std::move(variant)), t(std::move(t)) {}
    prism_rtl::Turn<Vl> cycle() const override;
};


/// The step machine of `ElementBlueprint`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ElementBlueprint: unbounded fn Lx, Env, [Arg], OutTy -> Vl
struct ElementBlueprint : prism_rtl::Job<Vl> {
    Lx lx;
    Env env;
    Array<ast::Arg> args;
    OutTy t;
    ElementBlueprint(Lx lx, Env env, Array<ast::Arg> args, OutTy t) : lx(std::move(lx)), env(std::move(env)), args(std::move(args)), t(std::move(t)) {}
    prism_rtl::Turn<Vl> cycle() const override;
};


/// The step machine of `NameValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// NameValue: unbounded fn Lx, Env, SName, Range -> Vl
struct NameValue : prism_rtl::Job<Vl> {
    Lx lx;
    Env env;
    ast::SName n;
    ast::Range span;
    NameValue(Lx lx, Env env, ast::SName n, ast::Range span) : lx(std::move(lx)), env(std::move(env)), n(std::move(n)), span(std::move(span)) {}
    prism_rtl::Turn<Vl> cycle() const override;
};


/// The step machine of `GlobalValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// GlobalValue: unbounded fn Lx, Text, Range, OutTy -> Vl
struct GlobalValue : prism_rtl::Job<Vl> {
    Lx lx;
    Text qk;
    ast::Range span;
    OutTy t;
    GlobalValue(Lx lx, Text qk, ast::Range span, OutTy t) : lx(std::move(lx)), qk(std::move(qk)), span(std::move(span)), t(std::move(t)) {}
    prism_rtl::Turn<Vl> cycle() const override;
};


/// The step machine of `Application`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Application: unbounded fn Lx, Env, Expr, [Arg], Range -> Vl
struct Application : prism_rtl::Job<Vl> {
    Lx lx;
    Env env;
    ast::Expr callee;
    Array<ast::Arg> args;
    ast::Range span;
    Application(Lx lx, Env env, ast::Expr callee, Array<ast::Arg> args, ast::Range span) : lx(std::move(lx)), env(std::move(env)), callee(std::move(callee)), args(std::move(args)), span(std::move(span)) {}
    prism_rtl::Turn<Vl> cycle() const override;
};


/// The step machine of `InlineLocalFn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InlineLocalFn: unbounded fn Lx, Env, FnClause, [Arg], OutTy -> Vl
struct InlineLocalFn : prism_rtl::Job<Vl> {
    Lx lx;
    Env env;
    ast::FnClause c;
    Array<ast::Arg> args;
    OutTy t;
    InlineLocalFn(Lx lx, Env env, ast::FnClause c, Array<ast::Arg> args, OutTy t) : lx(std::move(lx)), env(std::move(env)), c(std::move(c)), args(std::move(args)), t(std::move(t)) {}
    prism_rtl::Turn<Vl> cycle() const override;
};


/// The step machine of `Argument`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Argument: unbounded fn Lx, Env, Expr -> Ex
struct Argument : prism_rtl::Job<Ex> {
    Lx lx;
    Env env;
    ast::Expr e;
    Argument(Lx lx, Env env, ast::Expr e) : lx(std::move(lx)), env(std::move(env)), e(std::move(e)) {}
    prism_rtl::Turn<Ex> cycle() const override;
};


/// The step machine of `ArgumentByKind`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ArgumentByKind: unbounded fn Lx, Env, Expr -> Ex
struct ArgumentByKind : prism_rtl::Job<Ex> {
    Lx lx;
    Env env;
    ast::Expr e;
    ArgumentByKind(Lx lx, Env env, ast::Expr e) : lx(std::move(lx)), env(std::move(env)), e(std::move(e)) {}
    prism_rtl::Turn<Ex> cycle() const override;
};


/// The step machine of `TagValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TagValue: unbounded fn Lx, Env, TagInfo, [Arg] -> Vl
struct TagValue : prism_rtl::Job<Vl> {
    Lx lx;
    Env env;
    check_env::TagInfo tg;
    Array<ast::Arg> args;
    TagValue(Lx lx, Env env, check_env::TagInfo tg, Array<ast::Arg> args) : lx(std::move(lx)), env(std::move(env)), tg(std::move(tg)), args(std::move(args)) {}
    prism_rtl::Turn<Vl> cycle() const override;
};


/// The step machine of `GlobalCall`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// GlobalCall: unbounded fn Lx, Env, Text, [Arg], Range, OutTy -> Vl
struct GlobalCall : prism_rtl::Job<Vl> {
    Lx lx;
    Env env;
    Text qk;
    Array<ast::Arg> args;
    ast::Range span;
    OutTy t;
    GlobalCall(Lx lx, Env env, Text qk, Array<ast::Arg> args, ast::Range span, OutTy t) : lx(std::move(lx)), env(std::move(env)), qk(std::move(qk)), args(std::move(args)), span(std::move(span)), t(std::move(t)) {}
    prism_rtl::Turn<Vl> cycle() const override;
};


/// The step machine of `ArgsFor`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ArgsFor: unbounded fn Lx, Env, ValInfo, [Arg] -> [Ex]
struct ArgsFor : prism_rtl::Job<Array<Ex>> {
    Lx lx;
    Env env;
    check_env::ValInfo v_;
    Array<ast::Arg> args;
    ArgsFor(Lx lx, Env env, check_env::ValInfo v_, Array<ast::Arg> args) : lx(std::move(lx)), env(std::move(env)), v_(std::move(v_)), args(std::move(args)) {}
    prism_rtl::Turn<Array<Ex>> cycle() const override;
};


/// The step machine of `CtorApp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CtorApp: unbounded fn Lx, Env, CtorInfo, [Arg], Range -> Vl
struct CtorApp : prism_rtl::Job<Vl> {
    Lx lx;
    Env env;
    check_env::CtorInfo c;
    Array<ast::Arg> args;
    ast::Range span;
    CtorApp(Lx lx, Env env, check_env::CtorInfo c, Array<ast::Arg> args, ast::Range span) : lx(std::move(lx)), env(std::move(env)), c(std::move(c)), args(std::move(args)), span(std::move(span)) {}
    prism_rtl::Turn<Vl> cycle() const override;
};


/// The step machine of `CtorFn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CtorFn: unbounded fn Lx, CtorInfo, [OutTy], Range, OutTy, Bool -> Vl
struct CtorFn : prism_rtl::Job<Vl> {
    Lx lx;
    check_env::CtorInfo c;
    Array<OutTy> pts;
    ast::Range span;
    OutTy t;
    bool job;
    CtorFn(Lx lx, check_env::CtorInfo c, Array<OutTy> pts, ast::Range span, OutTy t, bool job) : lx(std::move(lx)), c(std::move(c)), pts(std::move(pts)), span(std::move(span)), t(std::move(t)), job(std::move(job)) {}
    prism_rtl::Turn<Vl> cycle() const override;
};


/// The step machine of `CtorArgs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CtorArgs: unbounded fn Lx, Env, CtorInfo, [Arg] -> [Ex]
struct CtorArgs : prism_rtl::Job<Array<Ex>> {
    Lx lx;
    Env env;
    check_env::CtorInfo c;
    Array<ast::Arg> args;
    CtorArgs(Lx lx, Env env, check_env::CtorInfo c, Array<ast::Arg> args) : lx(std::move(lx)), env(std::move(env)), c(std::move(c)), args(std::move(args)) {}
    prism_rtl::Turn<Array<Ex>> cycle() const override;
};


/// The step machine of `MethodCall`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// MethodCall: unbounded fn Lx, Env, ValInfo, [Arg], Range, OutTy -> Vl
struct MethodCall : prism_rtl::Job<Vl> {
    Lx lx;
    Env env;
    check_env::ValInfo v_;
    Array<ast::Arg> args;
    ast::Range span;
    OutTy t;
    MethodCall(Lx lx, Env env, check_env::ValInfo v_, Array<ast::Arg> args, ast::Range span, OutTy t) : lx(std::move(lx)), env(std::move(env)), v_(std::move(v_)), args(std::move(args)), span(std::move(span)), t(std::move(t)) {}
    prism_rtl::Turn<Vl> cycle() const override;
};


/// The step machine of `PreludeMethod`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PreludeMethod: unbounded fn Lx, Text, Text, [Vl], Range, OutTy -> Vl
struct PreludeMethod : prism_rtl::Job<Vl> {
    Lx lx;
    Text cls;
    Text m;
    Array<Vl> vals;
    ast::Range span;
    OutTy t;
    PreludeMethod(Lx lx, Text cls, Text m, Array<Vl> vals, ast::Range span, OutTy t) : lx(std::move(lx)), cls(std::move(cls)), m(std::move(m)), vals(std::move(vals)), span(std::move(span)), t(std::move(t)) {}
    prism_rtl::Turn<Vl> cycle() const override;
};


/// The step machine of `BinaryValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BinaryValue: unbounded fn Lx, Env, Text, Expr, Expr, Range -> Vl
struct BinaryValue : prism_rtl::Job<Vl> {
    Lx lx;
    Env env;
    Text op;
    ast::Expr l;
    ast::Expr r;
    ast::Range span;
    BinaryValue(Lx lx, Env env, Text op, ast::Expr l, ast::Expr r, ast::Range span) : lx(std::move(lx)), env(std::move(env)), op(std::move(op)), l(std::move(l)), r(std::move(r)), span(std::move(span)) {}
    prism_rtl::Turn<Vl> cycle() const override;
};


/// The step machine of `PreludeCall`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PreludeCall: unbounded fn Lx, Env, Text, [Arg], Range, OutTy -> Vl
struct PreludeCall : prism_rtl::Job<Vl> {
    Lx lx;
    Env env;
    Text qk;
    Array<ast::Arg> args;
    ast::Range span;
    OutTy t;
    PreludeCall(Lx lx, Env env, Text qk, Array<ast::Arg> args, ast::Range span, OutTy t) : lx(std::move(lx)), env(std::move(env)), qk(std::move(qk)), args(std::move(args)), span(std::move(span)), t(std::move(t)) {}
    prism_rtl::Turn<Vl> cycle() const override;
};


/// The step machine of `PreludeJob`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ?PreludeJob: unbounded fn Lx, Env, Text, [Arg] -> ?Ex
struct PreludeJob : prism_rtl::Job<std::optional<Ex>> {
    Lx lx;
    Env env;
    Text variant;
    Array<ast::Arg> args;
    PreludeJob(Lx lx, Env env, Text variant, Array<ast::Arg> args) : lx(std::move(lx)), env(std::move(env)), variant(std::move(variant)), args(std::move(args)) {}
    prism_rtl::Turn<std::optional<Ex>> cycle() const override;
};


/// The step machine of `PreludeJobCall`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ?PreludeJobCall: unbounded fn Lx, Env, Expr -> ?Ex
struct PreludeJobCall : prism_rtl::Job<std::optional<Ex>> {
    Lx lx;
    Env env;
    ast::Expr e;
    PreludeJobCall(Lx lx, Env env, ast::Expr e) : lx(std::move(lx)), env(std::move(env)), e(std::move(e)) {}
    prism_rtl::Turn<std::optional<Ex>> cycle() const override;
};


/// The step machine of `AsJobValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// AsJobValue: unbounded fn Lx, Env, Expr -> Ex
struct AsJobValue : prism_rtl::Job<Ex> {
    Lx lx;
    Env env;
    ast::Expr e;
    AsJobValue(Lx lx, Env env, ast::Expr e) : lx(std::move(lx)), env(std::move(env)), e(std::move(e)) {}
    prism_rtl::Turn<Ex> cycle() const override;
};


/// The step machine of `NamedArgsOwned`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// NamedArgsOwned: unbounded fn Lx, Env, Text, [Arg] -> [Ex]
struct NamedArgsOwned : prism_rtl::Job<Array<Ex>> {
    Lx lx;
    Env env;
    Text qk;
    Array<ast::Arg> args;
    NamedArgsOwned(Lx lx, Env env, Text qk, Array<ast::Arg> args) : lx(std::move(lx)), env(std::move(env)), qk(std::move(qk)), args(std::move(args)) {}
    prism_rtl::Turn<Array<Ex>> cycle() const override;
};


/// The step machine of `StartArgs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// StartArgs: unbounded fn Lx, Env, Vl, [Arg] -> [Ex]
struct StartArgs : prism_rtl::Job<Array<Ex>> {
    Lx lx;
    Env env;
    Vl f;
    Array<ast::Arg> args;
    StartArgs(Lx lx, Env env, Vl f, Array<ast::Arg> args) : lx(std::move(lx)), env(std::move(env)), f(std::move(f)), args(std::move(args)) {}
    prism_rtl::Turn<Array<Ex>> cycle() const override;
};


/// The step machine of `FieldValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FieldValue: unbounded fn Lx, Env, Expr, Text -> Vl
struct FieldValue : prism_rtl::Job<Vl> {
    Lx lx;
    Env env;
    ast::Expr r;
    Text name;
    FieldValue(Lx lx, Env env, ast::Expr r, Text name) : lx(std::move(lx)), env(std::move(env)), r(std::move(r)), name(std::move(name)) {}
    prism_rtl::Turn<Vl> cycle() const override;
};


/// The step machine of `FieldInfo`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FieldInfo: unbounded fn Lx, Ty, Text -> ((OutTy, Bool))
struct FieldInfo : prism_rtl::Job<std::tuple<OutTy, bool>> {
    Lx lx;
    check_types::Ty rty;
    Text name;
    FieldInfo(Lx lx, check_types::Ty rty, Text name) : lx(std::move(lx)), rty(std::move(rty)), name(std::move(name)) {}
    prism_rtl::Turn<std::tuple<OutTy, bool>> cycle() const override;
};


/// The step machine of `Instantiated`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Instantiated: unbounded fn Ty, [Text], [Ty] -> Ty
struct Instantiated : prism_rtl::Job<check_types::Ty> {
    check_types::Ty t;
    Array<Text> params;
    Array<check_types::Ty> args;
    Instantiated(check_types::Ty t, Array<Text> params, Array<check_types::Ty> args) : t(std::move(t)), params(std::move(params)), args(std::move(args)) {}
    prism_rtl::Turn<check_types::Ty> cycle() const override;
};


/// The step machine of `IndexValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// IndexValue: unbounded fn Lx, Env, Expr, Expr, OutTy -> Vl
struct IndexValue : prism_rtl::Job<Vl> {
    Lx lx;
    Env env;
    ast::Expr r;
    ast::Expr i;
    OutTy t;
    IndexValue(Lx lx, Env env, ast::Expr r, ast::Expr i, OutTy t) : lx(std::move(lx)), env(std::move(env)), r(std::move(r)), i(std::move(i)), t(std::move(t)) {}
    prism_rtl::Turn<Vl> cycle() const override;
};


/// The step machine of `ReadNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ReadNames: unbounded fn [Expr] -> [Text]
struct ReadNames : prism_rtl::Job<Array<Text>> {
    Array<ast::Expr> es;
    ReadNames(Array<ast::Expr> es) : es(std::move(es)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `LambdaExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LambdaExprs: unbounded fn LambdaBody -> [Expr]
struct LambdaExprs : prism_rtl::Job<Array<ast::Expr>> {
    ast::LambdaBody lambda_body0;
    LambdaExprs(ast::LambdaBody lambda_body0) : lambda_body0(std::move(lambda_body0)) {}
    prism_rtl::Turn<Array<ast::Expr>> cycle() const override;
};


/// The step machine of `LambdaValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LambdaValue: unbounded fn Lx, Env, Expr, [Pattern], LambdaBody -> Vl
struct LambdaValue : prism_rtl::Job<Vl> {
    Lx lx;
    Env env;
    ast::Expr e;
    Array<ast::Pattern_> ps;
    ast::LambdaBody body;
    LambdaValue(Lx lx, Env env, ast::Expr e, Array<ast::Pattern_> ps, ast::LambdaBody body) : lx(std::move(lx)), env(std::move(env)), e(std::move(e)), ps(std::move(ps)), body(std::move(body)) {}
    prism_rtl::Turn<Vl> cycle() const override;
};


/// The step machine of `PlainLambda`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PlainLambda: unbounded fn Lx, Env, [Pattern], LambdaBody, OutTy -> Vl
struct PlainLambda : prism_rtl::Job<Vl> {
    Lx lx;
    Env env;
    Array<ast::Pattern_> ps;
    ast::LambdaBody body;
    OutTy ft;
    PlainLambda(Lx lx, Env env, Array<ast::Pattern_> ps, ast::LambdaBody body, OutTy ft) : lx(std::move(lx)), env(std::move(env)), ps(std::move(ps)), body(std::move(body)), ft(std::move(ft)) {}
    prism_rtl::Turn<Vl> cycle() const override;
};


/// The step machine of `LambdaParamTys`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LambdaParamTys: unbounded fn Lx, Expr, Nat -> [OutTy]
struct LambdaParamTys : prism_rtl::Job<Array<OutTy>> {
    Lx lx;
    ast::Expr e;
    Nat n;
    LambdaParamTys(Lx lx, ast::Expr e, Nat n) : lx(std::move(lx)), e(std::move(e)), n(std::move(n)) {}
    prism_rtl::Turn<Array<OutTy>> cycle() const override;
};


/// The step machine of `IsKnownTy`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// IsKnownTy: unbounded fn OutTy -> Bool
struct IsKnownTy : prism_rtl::Job<bool> {
    OutTy t;
    IsKnownTy(OutTy t) : t(std::move(t)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `JobLambda`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// JobLambda: unbounded fn Lx, Env, [Pattern], LambdaBody, OutTy, OutTy, Bool -> Vl
struct JobLambda : prism_rtl::Job<Vl> {
    Lx lx;
    Env env;
    Array<ast::Pattern_> ps;
    ast::LambdaBody body;
    OutTy ft;
    OutTy a;
    bool enter;
    JobLambda(Lx lx, Env env, Array<ast::Pattern_> ps, ast::LambdaBody body, OutTy ft, OutTy a, bool enter) : lx(std::move(lx)), env(std::move(env)), ps(std::move(ps)), body(std::move(body)), ft(std::move(ft)), a(std::move(a)), enter(std::move(enter)) {}
    prism_rtl::Turn<Vl> cycle() const override;
};


/// The step machine of `LambdaArg`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LambdaArg: unbounded fn Lx, Env, [Pattern], LambdaBody, [OutTy] -> Ex
struct LambdaArg : prism_rtl::Job<Ex> {
    Lx lx;
    Env env;
    Array<ast::Pattern_> ps;
    ast::LambdaBody body;
    Array<OutTy> pts;
    LambdaArg(Lx lx, Env env, Array<ast::Pattern_> ps, ast::LambdaBody body, Array<OutTy> pts) : lx(std::move(lx)), env(std::move(env)), ps(std::move(ps)), body(std::move(body)), pts(std::move(pts)) {}
    prism_rtl::Turn<Ex> cycle() const override;
};


/// The step machine of `LambdaBodyValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LambdaBodyValue: unbounded fn Lx, Env, LambdaBody -> Vl
struct LambdaBodyValue : prism_rtl::Job<Vl> {
    Lx lx;
    Env env;
    ast::LambdaBody lambda_body2;
    LambdaBodyValue(Lx lx, Env env, ast::LambdaBody lambda_body2) : lx(std::move(lx)), env(std::move(env)), lambda_body2(std::move(lambda_body2)) {}
    prism_rtl::Turn<Vl> cycle() const override;
};


/// The step machine of `ClosureParams`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ClosureParams: unbounded fn Lx, Env, [Pattern], [OutTy], Bool -> (([Pa], Env))
struct ClosureParams : prism_rtl::Job<std::tuple<Array<Pa>, Env>> {
    Lx lx;
    Env env;
    Array<ast::Pattern_> ps;
    Array<OutTy> pts;
    bool typed;
    ClosureParams(Lx lx, Env env, Array<ast::Pattern_> ps, Array<OutTy> pts, bool typed) : lx(std::move(lx)), env(std::move(env)), ps(std::move(ps)), pts(std::move(pts)), typed(std::move(typed)) {}
    prism_rtl::Turn<std::tuple<Array<Pa>, Env>> cycle() const override;
};


/// The step machine of `IfValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// IfValue: unbounded fn Lx, Env, Cond, Block, ?Block, OutTy -> Vl
struct IfValue : prism_rtl::Job<Vl> {
    Lx lx;
    Env env;
    ast::Cond c;
    ast::Block then_b;
    std::optional<ast::Block> else_b_opt;
    OutTy t;
    IfValue(Lx lx, Env env, ast::Cond c, ast::Block then_b, std::optional<ast::Block> else_b_opt, OutTy t) : lx(std::move(lx)), env(std::move(env)), c(std::move(c)), then_b(std::move(then_b)), else_b_opt(std::move(else_b_opt)), t(std::move(t)) {}
    prism_rtl::Turn<Vl> cycle() const override;
};


/// The step machine of `MatchValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// MatchValue: unbounded fn Lx, Env, Expr, [Arm], OutTy, Range -> Vl
struct MatchValue : prism_rtl::Job<Vl> {
    Lx lx;
    Env env;
    ast::Expr s;
    Array<ast::Arm> arms;
    OutTy t;
    ast::Range span;
    MatchValue(Lx lx, Env env, ast::Expr s, Array<ast::Arm> arms, OutTy t, ast::Range span) : lx(std::move(lx)), env(std::move(env)), s(std::move(s)), arms(std::move(arms)), t(std::move(t)), span(std::move(span)) {}
    prism_rtl::Turn<Vl> cycle() const override;
};


/// The step machine of `ArmPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ArmPat: unbounded fn Lx, ?Pattern, Ty, Holding, Text -> PatOut
struct ArmPat : prism_rtl::Job<PatOut> {
    Lx lx;
    std::optional<ast::Pattern_> opt1;
    check_types::Ty ty;
    Holding mode;
    Text fresh;
    ArmPat(Lx lx, std::optional<ast::Pattern_> opt1, check_types::Ty ty, Holding mode, Text fresh) : lx(std::move(lx)), opt1(std::move(opt1)), ty(std::move(ty)), mode(std::move(mode)), fresh(std::move(fresh)) {}
    prism_rtl::Turn<PatOut> cycle() const override;
};


/// The step machine of `BlockValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BlockValue: unbounded fn Lx, Env, Block -> Vl
struct BlockValue : prism_rtl::Job<Vl> {
    Lx lx;
    Env env;
    ast::Block b;
    BlockValue(Lx lx, Env env, ast::Block b) : lx(std::move(lx)), env(std::move(env)), b(std::move(b)) {}
    prism_rtl::Turn<Vl> cycle() const override;
};


/// The step machine of `BlockTy`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BlockTy: unbounded fn Lx, Block -> OutTy
struct BlockTy : prism_rtl::Job<OutTy> {
    Lx lx;
    ast::Block b;
    BlockTy(Lx lx, ast::Block b) : lx(std::move(lx)), b(std::move(b)) {}
    prism_rtl::Turn<OutTy> cycle() const override;
};


/// The step machine of `PlainBlockValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PlainBlockValue: unbounded fn Lx, Env, Block -> Vl
struct PlainBlockValue : prism_rtl::Job<Vl> {
    Lx lx;
    Env env;
    ast::Block b;
    PlainBlockValue(Lx lx, Env env, ast::Block b) : lx(std::move(lx)), env(std::move(env)), b(std::move(b)) {}
    prism_rtl::Turn<Vl> cycle() const override;
};


/// The step machine of `BlockStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BlockStmt: unbounded fn Lx, Env, Stmt -> (([Do], Env))
struct BlockStmt : prism_rtl::Job<std::tuple<Array<Do>, Env>> {
    Lx lx;
    Env env;
    ast::Stmt s;
    BlockStmt(Lx lx, Env env, ast::Stmt s) : lx(std::move(lx)), env(std::move(env)), s(std::move(s)) {}
    prism_rtl::Turn<std::tuple<Array<Do>, Env>> cycle() const override;
};


/// The step machine of `GenericLet`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// GenericLet: unbounded fn Lx, Env, SName, GenNote, Expr -> (([Do], Env))
struct GenericLet : prism_rtl::Job<std::tuple<Array<Do>, Env>> {
    Lx lx;
    Env env;
    ast::SName n;
    typed::GenNote gn;
    ast::Expr x;
    GenericLet(Lx lx, Env env, ast::SName n, typed::GenNote gn, ast::Expr x) : lx(std::move(lx)), env(std::move(env)), n(std::move(n)), gn(std::move(gn)), x(std::move(x)) {}
    prism_rtl::Turn<std::tuple<Array<Do>, Env>> cycle() const override;
};


/// The step machine of `Instantiations`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Instantiations: unbounded fn Lx, GenNote -> [(([((Text, Ty))], [((Text, Col))]))]
struct Instantiations : prism_rtl::Job<Array<std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>>>> {
    Lx lx;
    typed::GenNote gn;
    Instantiations(Lx lx, typed::GenNote gn) : lx(std::move(lx)), gn(std::move(gn)) {}
    prism_rtl::Turn<Array<std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>>>> cycle() const override;
};


/// The step machine of `Expanded`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Expanded: unbounded fn Lx, (([((Text, Ty))], [((Text, Col))])) -> [(([((Text, Ty))], [((Text, Col))]))]
struct Expanded : prism_rtl::Job<Array<std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>>>> {
    Lx lx;
    std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>> i;
    Expanded(Lx lx, std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>> i) : lx(std::move(lx)), i(std::move(i)) {}
    prism_rtl::Turn<Array<std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>>>> cycle() const override;
};


/// The step machine of `OpenQ`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ?OpenQ: unbounded fn Lx, (([((Text, Ty))], [((Text, Col))])) -> ?Text
struct OpenQ : prism_rtl::Job<std::optional<Text>> {
    Lx lx;
    std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>> arg1;
    OpenQ(Lx lx, std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>> arg1) : lx(std::move(lx)), arg1(std::move(arg1)) {}
    prism_rtl::Turn<std::optional<Text>> cycle() const override;
};


/// The step machine of `OpenTyQs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// OpenTyQs: unbounded fn Lx, Ty -> [Text]
struct OpenTyQs : prism_rtl::Job<Array<Text>> {
    Lx lx;
    check_types::Ty t;
    OpenTyQs(Lx lx, check_types::Ty t) : lx(std::move(lx)), t(std::move(t)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `WidgetLetLx`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// WidgetLetLx: unbounded fn Lx, Range -> Lx
struct WidgetLetLx : prism_rtl::Job<Lx> {
    Lx lx;
    ast::Range span;
    WidgetLetLx(Lx lx, ast::Range span) : lx(std::move(lx)), span(std::move(span)) {}
    prism_rtl::Turn<Lx> cycle() const override;
};


/// The step machine of `PlainLet`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PlainLet: unbounded fn Lx, Env, Stmt, Pattern, Expr -> (([Do], Env))
struct PlainLet : prism_rtl::Job<std::tuple<Array<Do>, Env>> {
    Lx lx;
    Env env;
    ast::Stmt s;
    ast::Pattern_ p_;
    ast::Expr x;
    PlainLet(Lx lx, Env env, ast::Stmt s, ast::Pattern_ p_, ast::Expr x) : lx(std::move(lx)), env(std::move(env)), s(std::move(s)), p_(std::move(p_)), x(std::move(x)) {}
    prism_rtl::Turn<std::tuple<Array<Do>, Env>> cycle() const override;
};


/// The step machine of `RustPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RustPat: unbounded fn Lx, Pattern, Ty, Holding, Text -> PatOut
struct RustPat : prism_rtl::Job<PatOut> {
    Lx lx;
    ast::Pattern_ p_;
    check_types::Ty ty;
    Holding mode;
    Text fresh;
    RustPat(Lx lx, ast::Pattern_ p_, check_types::Ty ty, Holding mode, Text fresh) : lx(std::move(lx)), p_(std::move(p_)), ty(std::move(ty)), mode(std::move(mode)), fresh(std::move(fresh)) {}
    prism_rtl::Turn<PatOut> cycle() const override;
};


/// The step machine of `WrapPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// WrapPat: unbounded fn Lx, Text, Pattern, Ty, Holding, Text -> PatOut
struct WrapPat : prism_rtl::Job<PatOut> {
    Lx lx;
    Text ctor;
    ast::Pattern_ q;
    check_types::Ty inner;
    Holding mode;
    Text fresh;
    WrapPat(Lx lx, Text ctor, ast::Pattern_ q, check_types::Ty inner, Holding mode, Text fresh) : lx(std::move(lx)), ctor(std::move(ctor)), q(std::move(q)), inner(std::move(inner)), mode(std::move(mode)), fresh(std::move(fresh)) {}
    prism_rtl::Turn<PatOut> cycle() const override;
};


/// The step machine of `LitPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LitPat: unbounded fn Lx, Literal, Ty, Holding, Text, Bool -> PatOut
struct LitPat : prism_rtl::Job<PatOut> {
    Lx lx;
    ast::Literal l;
    check_types::Ty ty;
    Holding mode;
    Text fresh;
    bool neg;
    LitPat(Lx lx, ast::Literal l, check_types::Ty ty, Holding mode, Text fresh, bool neg) : lx(std::move(lx)), l(std::move(l)), ty(std::move(ty)), mode(std::move(mode)), fresh(std::move(fresh)), neg(std::move(neg)) {}
    prism_rtl::Turn<PatOut> cycle() const override;
};


/// The step machine of `CtorPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CtorPat: unbounded fn Lx, SName, [Pattern], Ty, Holding, Text -> PatOut
struct CtorPat : prism_rtl::Job<PatOut> {
    Lx lx;
    ast::SName n;
    Array<ast::Pattern_> ps;
    check_types::Ty ty;
    Holding mode;
    Text fresh;
    CtorPat(Lx lx, ast::SName n, Array<ast::Pattern_> ps, check_types::Ty ty, Holding mode, Text fresh) : lx(std::move(lx)), n(std::move(n)), ps(std::move(ps)), ty(std::move(ty)), mode(std::move(mode)), fresh(std::move(fresh)) {}
    prism_rtl::Turn<PatOut> cycle() const override;
};


/// The step machine of `SubPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SubPat: unbounded fn Lx, CtorInfo, Nat, Pattern, Ty, Holding, Text -> PatOut
struct SubPat : prism_rtl::Job<PatOut> {
    Lx lx;
    check_env::CtorInfo c;
    Nat i;
    ast::Pattern_ p_;
    check_types::Ty ty;
    Holding mode;
    Text fresh;
    SubPat(Lx lx, check_env::CtorInfo c, Nat i, ast::Pattern_ p_, check_types::Ty ty, Holding mode, Text fresh) : lx(std::move(lx)), c(std::move(c)), i(std::move(i)), p_(std::move(p_)), ty(std::move(ty)), mode(std::move(mode)), fresh(std::move(fresh)) {}
    prism_rtl::Turn<PatOut> cycle() const override;
};


/// The step machine of `BehindRc`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BehindRc: unbounded fn Lx, Pattern, Ty, Holding, Text -> PatOut
struct BehindRc : prism_rtl::Job<PatOut> {
    Lx lx;
    ast::Pattern_ p_;
    check_types::Ty ty;
    Holding rc_mode;
    Text fresh;
    BehindRc(Lx lx, ast::Pattern_ p_, check_types::Ty ty, Holding rc_mode, Text fresh) : lx(std::move(lx)), p_(std::move(p_)), ty(std::move(ty)), rc_mode(std::move(rc_mode)), fresh(std::move(fresh)) {}
    prism_rtl::Turn<PatOut> cycle() const override;
};


/// The step machine of `RecordPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RecordPat: unbounded fn Lx, SName, [FieldPat], Bool, Ty, Holding, Text -> PatOut
struct RecordPat : prism_rtl::Job<PatOut> {
    Lx lx;
    ast::SName n;
    Array<ast::FieldPat> fps;
    bool rest;
    check_types::Ty ty;
    Holding mode;
    Text fresh;
    RecordPat(Lx lx, ast::SName n, Array<ast::FieldPat> fps, bool rest, check_types::Ty ty, Holding mode, Text fresh) : lx(std::move(lx)), n(std::move(n)), fps(std::move(fps)), rest(std::move(rest)), ty(std::move(ty)), mode(std::move(mode)), fresh(std::move(fresh)) {}
    prism_rtl::Turn<PatOut> cycle() const override;
};


/// The step machine of `FieldsPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FieldsPat: unbounded fn Lx, CtorInfo, [FieldPat], Bool, Ty, Holding, Text, Text -> PatOut
struct FieldsPat : prism_rtl::Job<PatOut> {
    Lx lx;
    check_env::CtorInfo c;
    Array<ast::FieldPat> fps;
    bool rest;
    check_types::Ty ty;
    Holding mode;
    Text fresh;
    Text ty_path;
    FieldsPat(Lx lx, check_env::CtorInfo c, Array<ast::FieldPat> fps, bool rest, check_types::Ty ty, Holding mode, Text fresh, Text ty_path) : lx(std::move(lx)), c(std::move(c)), fps(std::move(fps)), rest(std::move(rest)), ty(std::move(ty)), mode(std::move(mode)), fresh(std::move(fresh)), ty_path(std::move(ty_path)) {}
    prism_rtl::Turn<PatOut> cycle() const override;
};


/// The step machine of `TagPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TagPat: unbounded fn Lx, TagInfo, [FieldPat], Bool, Ty, Holding, Text -> PatOut
struct TagPat : prism_rtl::Job<PatOut> {
    Lx lx;
    check_env::TagInfo tg;
    Array<ast::FieldPat> fps;
    bool rest;
    check_types::Ty ty;
    Holding mode;
    Text fresh;
    TagPat(Lx lx, check_env::TagInfo tg, Array<ast::FieldPat> fps, bool rest, check_types::Ty ty, Holding mode, Text fresh) : lx(std::move(lx)), tg(std::move(tg)), fps(std::move(fps)), rest(std::move(rest)), ty(std::move(ty)), mode(std::move(mode)), fresh(std::move(fresh)) {}
    prism_rtl::Turn<PatOut> cycle() const override;
};


/// The step machine of `LiveFieldPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LiveFieldPat: unbounded fn Lx, Pattern, Text, Text, Ty, Text -> PatOut
struct LiveFieldPat : prism_rtl::Job<PatOut> {
    Lx lx;
    ast::Pattern_ p_;
    Text variant;
    Text fname;
    check_types::Ty ft;
    Text fresh;
    LiveFieldPat(Lx lx, ast::Pattern_ p_, Text variant, Text fname, check_types::Ty ft, Text fresh) : lx(std::move(lx)), p_(std::move(p_)), variant(std::move(variant)), fname(std::move(fname)), ft(std::move(ft)), fresh(std::move(fresh)) {}
    prism_rtl::Turn<PatOut> cycle() const override;
};


/// The step machine of `FamilyPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FamilyPat: unbounded fn Lx, QualName, Ty, Text -> PatOut
struct FamilyPat : prism_rtl::Job<PatOut> {
    Lx lx;
    ast::QualName q;
    check_types::Ty ty;
    Text fresh;
    FamilyPat(Lx lx, ast::QualName q, check_types::Ty ty, Text fresh) : lx(std::move(lx)), q(std::move(q)), ty(std::move(ty)), fresh(std::move(fresh)) {}
    prism_rtl::Turn<PatOut> cycle() const override;
};


/// The step machine of `ErrorPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ErrorPat: unbounded fn Lx, [FieldPat], Ty, Holding, Text -> PatOut
struct ErrorPat : prism_rtl::Job<PatOut> {
    Lx lx;
    Array<ast::FieldPat> fps;
    check_types::Ty ty;
    Holding mode;
    Text fresh;
    ErrorPat(Lx lx, Array<ast::FieldPat> fps, check_types::Ty ty, Holding mode, Text fresh) : lx(std::move(lx)), fps(std::move(fps)), ty(std::move(ty)), mode(std::move(mode)), fresh(std::move(fresh)) {}
    prism_rtl::Turn<PatOut> cycle() const override;
};


/// The step machine of `ArrayPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ArrayPat: unbounded fn Lx, [Pattern], Ty, Holding, Text -> PatOut
struct ArrayPat : prism_rtl::Job<PatOut> {
    Lx lx;
    Array<ast::Pattern_> ps;
    check_types::Ty ty;
    Holding mode;
    Text fresh;
    ArrayPat(Lx lx, Array<ast::Pattern_> ps, check_types::Ty ty, Holding mode, Text fresh) : lx(std::move(lx)), ps(std::move(ps)), ty(std::move(ty)), mode(std::move(mode)), fresh(std::move(fresh)) {}
    prism_rtl::Turn<PatOut> cycle() const override;
};


/// The step machine of `TemplateValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TemplateValue: unbounded fn Lx, Env, Template -> Vl
struct TemplateValue : prism_rtl::Job<Vl> {
    Lx lx;
    Env env;
    ast::Template tp;
    TemplateValue(Lx lx, Env env, ast::Template tp) : lx(std::move(lx)), env(std::move(env)), tp(std::move(tp)) {}
    prism_rtl::Turn<Vl> cycle() const override;
};


/// The step machine of `TemplatePartDos`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TemplatePartDos: unbounded fn Lx, Env, TemplatePart -> [Do]
struct TemplatePartDos : prism_rtl::Job<Array<Do>> {
    Lx lx;
    Env env;
    ast::TemplatePart part;
    TemplatePartDos(Lx lx, Env env, ast::TemplatePart part) : lx(std::move(lx)), env(std::move(env)), part(std::move(part)) {}
    prism_rtl::Turn<Array<Do>> cycle() const override;
};


/// The step machine of `TemplateArgs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TemplateArgs: unbounded fn Lx, Env, Text, [Arg], [Ex] -> [Ex]
struct TemplateArgs : prism_rtl::Job<Array<Ex>> {
    Lx lx;
    Env env;
    Text qk;
    Array<ast::Arg> args;
    Array<Ex> body;
    TemplateArgs(Lx lx, Env env, Text qk, Array<ast::Arg> args, Array<Ex> body) : lx(std::move(lx)), env(std::move(env)), qk(std::move(qk)), args(std::move(args)), body(std::move(body)) {}
    prism_rtl::Turn<Array<Ex>> cycle() const override;
};


/// The step machine of `GivenValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// GivenValue: unbounded fn Lx, Env, Block, OutTy, Range -> Vl
struct GivenValue : prism_rtl::Job<Vl> {
    Lx lx;
    Env env;
    ast::Block b;
    OutTy t;
    ast::Range span;
    GivenValue(Lx lx, Env env, ast::Block b, OutTy t, ast::Range span) : lx(std::move(lx)), env(std::move(env)), b(std::move(b)), t(std::move(t)), span(std::move(span)) {}
    prism_rtl::Turn<Vl> cycle() const override;
};


/// The step machine of `UpdateValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// UpdateValue: unbounded fn Lx, Env, Expr, Block, OutTy, Range -> Vl
struct UpdateValue : prism_rtl::Job<Vl> {
    Lx lx;
    Env env;
    ast::Expr target;
    ast::Block b;
    OutTy t;
    ast::Range span;
    UpdateValue(Lx lx, Env env, ast::Expr target, ast::Block b, OutTy t, ast::Range span) : lx(std::move(lx)), env(std::move(env)), target(std::move(target)), b(std::move(b)), t(std::move(t)), span(std::move(span)) {}
    prism_rtl::Turn<Vl> cycle() const override;
};


/// The step machine of `UpdStmts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// UpdStmts: unbounded fn Lx, Env, [Stmt] -> (([Do], Env))
struct UpdStmts : prism_rtl::Job<std::tuple<Array<Do>, Env>> {
    Lx lx;
    Env env;
    Array<ast::Stmt> stmts;
    UpdStmts(Lx lx, Env env, Array<ast::Stmt> stmts) : lx(std::move(lx)), env(std::move(env)), stmts(std::move(stmts)) {}
    prism_rtl::Turn<std::tuple<Array<Do>, Env>> cycle() const override;
};


/// The step machine of `UpdStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// UpdStmt: unbounded fn Lx, Env, Stmt -> (([Do], Env))
struct UpdStmt : prism_rtl::Job<std::tuple<Array<Do>, Env>> {
    Lx lx;
    Env env;
    ast::Stmt s;
    UpdStmt(Lx lx, Env env, ast::Stmt s) : lx(std::move(lx)), env(std::move(env)), s(std::move(s)) {}
    prism_rtl::Turn<std::tuple<Array<Do>, Env>> cycle() const override;
};


/// The step machine of `UpdFor`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// UpdFor: unbounded fn Lx, Env, ?ForBinders, Expr, Block, Range -> Do
struct UpdFor : prism_rtl::Job<Do> {
    Lx lx;
    Env env;
    std::optional<ast::ForBinders> binders_opt;
    ast::Expr source;
    ast::Block body;
    ast::Range span;
    UpdFor(Lx lx, Env env, std::optional<ast::ForBinders> binders_opt, ast::Expr source, ast::Block body, ast::Range span) : lx(std::move(lx)), env(std::move(env)), binders_opt(std::move(binders_opt)), source(std::move(source)), body(std::move(body)), span(std::move(span)) {}
    prism_rtl::Turn<Do> cycle() const override;
};


/// The step machine of `UpdForRefs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// UpdForRefs: unbounded fn Lx, Env, SName, Expr, Block, Range, Ty -> Do
struct UpdForRefs : prism_rtl::Job<Do> {
    Lx lx;
    Env env;
    ast::SName n;
    ast::Expr source;
    ast::Block body;
    ast::Range span;
    check_types::Ty sty;
    UpdForRefs(Lx lx, Env env, ast::SName n, ast::Expr source, ast::Block body, ast::Range span, check_types::Ty sty) : lx(std::move(lx)), env(std::move(env)), n(std::move(n)), source(std::move(source)), body(std::move(body)), span(std::move(span)), sty(std::move(sty)) {}
    prism_rtl::Turn<Do> cycle() const override;
};


/// The step machine of `UpdForValues`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// UpdForValues: unbounded fn Lx, Env, ?ForBinders, Expr, Block, Range, Ty -> Do
struct UpdForValues : prism_rtl::Job<Do> {
    Lx lx;
    Env env;
    std::optional<ast::ForBinders> binders_opt;
    ast::Expr source;
    ast::Block body;
    ast::Range span;
    check_types::Ty sty;
    UpdForValues(Lx lx, Env env, std::optional<ast::ForBinders> binders_opt, ast::Expr source, ast::Block body, ast::Range span, check_types::Ty sty) : lx(std::move(lx)), env(std::move(env)), binders_opt(std::move(binders_opt)), source(std::move(source)), body(std::move(body)), span(std::move(span)), sty(std::move(sty)) {}
    prism_rtl::Turn<Do> cycle() const override;
};


/// The step machine of `UpdIf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// UpdIf: unbounded fn Lx, Env, Cond, Block, ?Block -> Do
struct UpdIf : prism_rtl::Job<Do> {
    Lx lx;
    Env env;
    ast::Cond c;
    ast::Block then_b;
    std::optional<ast::Block> else_b_opt;
    UpdIf(Lx lx, Env env, ast::Cond c, ast::Block then_b, std::optional<ast::Block> else_b_opt) : lx(std::move(lx)), env(std::move(env)), c(std::move(c)), then_b(std::move(then_b)), else_b_opt(std::move(else_b_opt)) {}
    prism_rtl::Turn<Do> cycle() const override;
};


/// The step machine of `UpdMatch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// UpdMatch: unbounded fn Lx, Env, Expr, [Arm] -> Do
struct UpdMatch : prism_rtl::Job<Do> {
    Lx lx;
    Env env;
    ast::Expr scrut;
    Array<ast::Arm> arms;
    UpdMatch(Lx lx, Env env, ast::Expr scrut, Array<ast::Arm> arms) : lx(std::move(lx)), env(std::move(env)), scrut(std::move(scrut)), arms(std::move(arms)) {}
    prism_rtl::Turn<Do> cycle() const override;
};


/// The step machine of `GuardConds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// GuardConds: unbounded fn Lx, Env, ?Expr -> [Cc]
struct GuardConds : prism_rtl::Job<Array<Cc>> {
    Lx lx;
    Env env;
    std::optional<ast::Expr> opt2;
    GuardConds(Lx lx, Env env, std::optional<ast::Expr> opt2) : lx(std::move(lx)), env(std::move(env)), opt2(std::move(opt2)) {}
    prism_rtl::Turn<Array<Cc>> cycle() const override;
};


/// The step machine of `PlaceOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PlaceOf: unbounded fn Lx, Env, Expr -> Ex
struct PlaceOf : prism_rtl::Job<Ex> {
    Lx lx;
    Env env;
    ast::Expr e;
    PlaceOf(Lx lx, Env env, ast::Expr e) : lx(std::move(lx)), env(std::move(env)), e(std::move(e)) {}
    prism_rtl::Turn<Ex> cycle() const override;
};


/// The step machine of `Assign`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Assign: unbounded fn Lx, Env, Expr, Ex -> Do
struct Assign : prism_rtl::Job<Do> {
    Lx lx;
    Env env;
    ast::Expr target;
    Ex v_;
    Assign(Lx lx, Env env, ast::Expr target, Ex v_) : lx(std::move(lx)), env(std::move(env)), target(std::move(target)), v_(std::move(v_)) {}
    prism_rtl::Turn<Do> cycle() const override;
};


/// The step machine of `ClausesBody`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ClausesBody: unbounded fn Lx, Env, [FnClause], [((Text, Bool))], [Ty], (fn Lx, Env, FnBody -> Ex), Text, OutTy -> Ex
struct ClausesBody : prism_rtl::Job<Ex> {
    Lx lx;
    Env env;
    Array<ast::FnClause> clauses;
    Array<std::tuple<Text, bool>> names;
    Array<check_types::Ty> ptys;
    prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Lx, Env, ast::FnBody>)> body_fn;
    Text label;
    OutTy t;
    ClausesBody(Lx lx, Env env, Array<ast::FnClause> clauses, Array<std::tuple<Text, bool>> names, Array<check_types::Ty> ptys, prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Lx, Env, ast::FnBody>)> body_fn, Text label, OutTy t) : lx(std::move(lx)), env(std::move(env)), clauses(std::move(clauses)), names(std::move(names)), ptys(std::move(ptys)), body_fn(std::move(body_fn)), label(std::move(label)), t(std::move(t)) {}
    prism_rtl::Turn<Ex> cycle() const override;
};


/// The step machine of `FnBodyValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FnBodyValue: unbounded fn Lx, Env, FnBody -> Ex
struct FnBodyValue : prism_rtl::Job<Ex> {
    Lx lx;
    Env env;
    ast::FnBody fn_body2;
    FnBodyValue(Lx lx, Env env, ast::FnBody fn_body2) : lx(std::move(lx)), env(std::move(env)), fn_body2(std::move(fn_body2)) {}
    prism_rtl::Turn<Ex> cycle() const override;
};


/// The step machine of `FnDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FnDefOf: unbounded fn Lx, Text, [FnClause], Scheme -> FnDef
struct FnDefOf : prism_rtl::Job<FnDef> {
    Lx lx;
    Text qk;
    Array<ast::FnClause> clauses;
    check_types::Scheme sc;
    FnDefOf(Lx lx, Text qk, Array<ast::FnClause> clauses, check_types::Scheme sc) : lx(std::move(lx)), qk(std::move(qk)), clauses(std::move(clauses)), sc(std::move(sc)) {}
    prism_rtl::Turn<FnDef> cycle() const override;
};


/// The step machine of `LetGetter`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LetGetter: unbounded fn Lx, Text, LetDecl -> FnDef
struct LetGetter : prism_rtl::Job<FnDef> {
    Lx lx;
    Text qk;
    ast::LetDecl l;
    LetGetter(Lx lx, Text qk, ast::LetDecl l) : lx(std::move(lx)), qk(std::move(qk)), l(std::move(l)) {}
    prism_rtl::Turn<FnDef> cycle() const override;
};


/// The step machine of `Tail`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Tail: unbounded fn Lx, Env, Expr -> Ex
struct Tail : prism_rtl::Job<Ex> {
    Lx lx;
    Env env;
    ast::Expr e;
    Tail(Lx lx, Env env, ast::Expr e) : lx(std::move(lx)), env(std::move(env)), e(std::move(e)) {}
    prism_rtl::Turn<Ex> cycle() const override;
};


/// The step machine of `TailHere`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TailHere: unbounded fn Lx, Env, Expr -> Ex
struct TailHere : prism_rtl::Job<Ex> {
    Lx lx;
    Env env;
    ast::Expr e;
    TailHere(Lx lx, Env env, ast::Expr e) : lx(std::move(lx)), env(std::move(env)), e(std::move(e)) {}
    prism_rtl::Turn<Ex> cycle() const override;
};


/// The step machine of `TailBlock`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TailBlock: unbounded fn Lx, Env, Block -> Ex
struct TailBlock : prism_rtl::Job<Ex> {
    Lx lx;
    Env env;
    ast::Block b;
    TailBlock(Lx lx, Env env, ast::Block b) : lx(std::move(lx)), env(std::move(env)), b(std::move(b)) {}
    prism_rtl::Turn<Ex> cycle() const override;
};


/// The step machine of `TailFrom`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TailFrom: unbounded fn Lx, Env, Block, Nat -> Ex
struct TailFrom : prism_rtl::Job<Ex> {
    Lx lx;
    Env env;
    ast::Block b;
    Nat i;
    TailFrom(Lx lx, Env env, ast::Block b, Nat i) : lx(std::move(lx)), env(std::move(env)), b(std::move(b)), i(std::move(i)) {}
    prism_rtl::Turn<Ex> cycle() const override;
};


/// The step machine of `UpdTail`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// UpdTail: unbounded fn Lx, Env, Expr, Block, Range, (unbounded fn Env, Ex -> Ex) -> Ex
struct UpdTail : prism_rtl::Job<Ex> {
    Lx lx;
    Env env;
    ast::Expr target;
    ast::Block b;
    ast::Range to;
    prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Env, Ex>)> cont_fn;
    UpdTail(Lx lx, Env env, ast::Expr target, ast::Block b, ast::Range to, prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Env, Ex>)> cont_fn) : lx(std::move(lx)), env(std::move(env)), target(std::move(target)), b(std::move(b)), to(std::move(to)), cont_fn(std::move(cont_fn)) {}
    prism_rtl::Turn<Ex> cycle() const override;
};


/// The step machine of `UpdTailFrom`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// UpdTailFrom: unbounded fn Lx, Env, Env, Block, Nat, Range, (unbounded fn Env, Ex -> Ex) -> Ex
struct UpdTailFrom : prism_rtl::Job<Ex> {
    Lx lx;
    Env outer;
    Env env;
    ast::Block b;
    Nat i;
    ast::Range to;
    prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Env, Ex>)> cont_fn;
    UpdTailFrom(Lx lx, Env outer, Env env, ast::Block b, Nat i, ast::Range to, prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Env, Ex>)> cont_fn) : lx(std::move(lx)), outer(std::move(outer)), env(std::move(env)), b(std::move(b)), i(std::move(i)), to(std::move(to)), cont_fn(std::move(cont_fn)) {}
    prism_rtl::Turn<Ex> cycle() const override;
};


/// The step machine of `StmtJob`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// StmtJob: unbounded fn Lx, Env, Env, Stmt, Text, (unbounded fn Env, Env -> Ex) -> Ex
struct StmtJob : prism_rtl::Job<Ex> {
    Lx lx;
    Env outer;
    Env env;
    ast::Stmt s;
    Text rest;
    prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Env, Env>)> cont_fn;
    StmtJob(Lx lx, Env outer, Env env, ast::Stmt s, Text rest, prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Env, Env>)> cont_fn) : lx(std::move(lx)), outer(std::move(outer)), env(std::move(env)), s(std::move(s)), rest(std::move(rest)), cont_fn(std::move(cont_fn)) {}
    prism_rtl::Turn<Ex> cycle() const override;
};


/// The step machine of `WhileJob`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// WhileJob: unbounded fn Lx, Env, Env, Cond, Block, Range, Text, (unbounded fn Env, Env -> Ex) -> Ex
struct WhileJob : prism_rtl::Job<Ex> {
    Lx lx;
    Env outer;
    Env env;
    ast::Cond c;
    ast::Block wb;
    ast::Range span;
    Text rest_text_;
    prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Env, Env>)> cont_fn;
    WhileJob(Lx lx, Env outer, Env env, ast::Cond c, ast::Block wb, ast::Range span, Text rest_text_, prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Env, Env>)> cont_fn) : lx(std::move(lx)), outer(std::move(outer)), env(std::move(env)), c(std::move(c)), wb(std::move(wb)), span(std::move(span)), rest_text_(std::move(rest_text_)), cont_fn(std::move(cont_fn)) {}
    prism_rtl::Turn<Ex> cycle() const override;
};


/// The step machine of `StmtsThen`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// StmtsThen: unbounded fn Lx, Env, Block, Ex -> Ex
struct StmtsThen : prism_rtl::Job<Ex> {
    Lx lx;
    Env env;
    ast::Block b;
    Ex last;
    StmtsThen(Lx lx, Env env, ast::Block b, Ex last) : lx(std::move(lx)), env(std::move(env)), b(std::move(b)), last(std::move(last)) {}
    prism_rtl::Turn<Ex> cycle() const override;
};


/// The step machine of `IfJob`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// IfJob: unbounded fn Lx, Env, Env, Cond, Block, ?Block, Range, Text, (unbounded fn Env, Env -> Ex) -> Ex
struct IfJob : prism_rtl::Job<Ex> {
    Lx lx;
    Env outer;
    Env env;
    ast::Cond c;
    ast::Block then_b;
    std::optional<ast::Block> else_b_opt;
    ast::Range span;
    Text rest_text_;
    prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Env, Env>)> cont_fn;
    IfJob(Lx lx, Env outer, Env env, ast::Cond c, ast::Block then_b, std::optional<ast::Block> else_b_opt, ast::Range span, Text rest_text_, prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Env, Env>)> cont_fn) : lx(std::move(lx)), outer(std::move(outer)), env(std::move(env)), c(std::move(c)), then_b(std::move(then_b)), else_b_opt(std::move(else_b_opt)), span(std::move(span)), rest_text_(std::move(rest_text_)), cont_fn(std::move(cont_fn)) {}
    prism_rtl::Turn<Ex> cycle() const override;
};


/// The step machine of `MatchJob`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// MatchJob: unbounded fn Lx, Env, Env, Expr, [Arm], Range, Text, (unbounded fn Env, Env -> Ex) -> Ex
struct MatchJob : prism_rtl::Job<Ex> {
    Lx lx;
    Env outer;
    Env env;
    ast::Expr scrut;
    Array<ast::Arm> arms;
    ast::Range span;
    Text rest_text_;
    prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Env, Env>)> cont_fn;
    MatchJob(Lx lx, Env outer, Env env, ast::Expr scrut, Array<ast::Arm> arms, ast::Range span, Text rest_text_, prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Env, Env>)> cont_fn) : lx(std::move(lx)), outer(std::move(outer)), env(std::move(env)), scrut(std::move(scrut)), arms(std::move(arms)), span(std::move(span)), rest_text_(std::move(rest_text_)), cont_fn(std::move(cont_fn)) {}
    prism_rtl::Turn<Ex> cycle() const override;
};


/// The step machine of `ForJob`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ForJob: unbounded fn Lx, Env, Env, ?ForBinders, Expr, Block, Range, Text, (unbounded fn Env, Env -> Ex) -> Ex
struct ForJob : prism_rtl::Job<Ex> {
    Lx lx;
    Env outer;
    Env env;
    std::optional<ast::ForBinders> binders_opt;
    ast::Expr source;
    ast::Block body;
    ast::Range span;
    Text rest_text_;
    prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Env, Env>)> cont_fn;
    ForJob(Lx lx, Env outer, Env env, std::optional<ast::ForBinders> binders_opt, ast::Expr source, ast::Block body, ast::Range span, Text rest_text_, prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<Env, Env>)> cont_fn) : lx(std::move(lx)), outer(std::move(outer)), env(std::move(env)), binders_opt(std::move(binders_opt)), source(std::move(source)), body(std::move(body)), span(std::move(span)), rest_text_(std::move(rest_text_)), cont_fn(std::move(cont_fn)) {}
    prism_rtl::Turn<Ex> cycle() const override;
};


/// The step machine of `FrameCall`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ?FrameCall: unbounded fn Lx, Env, Expr, Bool -> ?Expr
struct FrameCall : prism_rtl::Job<std::optional<ast::Expr>> {
    Lx lx;
    Env env;
    ast::Expr e;
    bool top;
    FrameCall(Lx lx, Env env, ast::Expr e, bool top) : lx(std::move(lx)), env(std::move(env)), e(std::move(e)), top(std::move(top)) {}
    prism_rtl::Turn<std::optional<ast::Expr>> cycle() const override;
};


/// The step machine of `FirstFrame`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ?FirstFrame: unbounded fn Lx, Env, [Expr] -> ?Expr
struct FirstFrame : prism_rtl::Job<std::optional<ast::Expr>> {
    Lx lx;
    Env env;
    Array<ast::Expr> es;
    FirstFrame(Lx lx, Env env, Array<ast::Expr> es) : lx(std::move(lx)), env(std::move(env)), es(std::move(es)) {}
    prism_rtl::Turn<std::optional<ast::Expr>> cycle() const override;
};


/// The step machine of `Frame`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Frame: unbounded fn Lx, Env, Expr, Text, (unbounded fn Env -> Ex) -> Ex
struct Frame : prism_rtl::Job<Ex> {
    Lx lx;
    Env env;
    ast::Expr call;
    Text rest_text_;
    prism_rtl::Fn<prism_rtl::JobRef<Ex>(Env)> cont_fn;
    Frame(Lx lx, Env env, ast::Expr call, Text rest_text_, prism_rtl::Fn<prism_rtl::JobRef<Ex>(Env)> cont_fn) : lx(std::move(lx)), env(std::move(env)), call(std::move(call)), rest_text_(std::move(rest_text_)), cont_fn(std::move(cont_fn)) {}
    prism_rtl::Turn<Ex> cycle() const override;
};


/// The step machine of `LocalJobFn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ?LocalJobFn: unbounded fn Lx, Env, Expr -> ?Vl
struct LocalJobFn : prism_rtl::Job<std::optional<Vl>> {
    Lx lx;
    Env env;
    ast::Expr c;
    LocalJobFn(Lx lx, Env env, ast::Expr c) : lx(std::move(lx)), env(std::move(env)), c(std::move(c)) {}
    prism_rtl::Turn<std::optional<Vl>> cycle() const override;
};


/// The step machine of `TailBody`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TailBody: unbounded fn Lx, Env, FnBody -> Ex
struct TailBody : prism_rtl::Job<Ex> {
    Lx lx;
    Env env;
    ast::FnBody fn_body2;
    TailBody(Lx lx, Env env, ast::FnBody fn_body2) : lx(std::move(lx)), env(std::move(env)), fn_body2(std::move(fn_body2)) {}
    prism_rtl::Turn<Ex> cycle() const override;
};


/// The step machine of `TailMatch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TailMatch: unbounded fn Lx, Env, Expr, [Arm], Range -> Ex
struct TailMatch : prism_rtl::Job<Ex> {
    Lx lx;
    Env env;
    ast::Expr s;
    Array<ast::Arm> arms;
    ast::Range span;
    TailMatch(Lx lx, Env env, ast::Expr s, Array<ast::Arm> arms, ast::Range span) : lx(std::move(lx)), env(std::move(env)), s(std::move(s)), arms(std::move(arms)), span(std::move(span)) {}
    prism_rtl::Turn<Ex> cycle() const override;
};


/// The step machine of `JobFieldNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// JobFieldNames: unbounded fn Lx, Text -> [Text]
struct JobFieldNames : prism_rtl::Job<Array<Text>> {
    Lx lx;
    Text qk;
    JobFieldNames(Lx lx, Text qk) : lx(std::move(lx)), qk(std::move(qk)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `JobDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// JobDefOf: unbounded fn Lx, Text, [FnClause], Scheme -> JobDef
struct JobDefOf : prism_rtl::Job<JobDef> {
    Lx lx;
    Text qk;
    Array<ast::FnClause> clauses;
    check_types::Scheme sc;
    JobDefOf(Lx lx, Text qk, Array<ast::FnClause> clauses, check_types::Scheme sc) : lx(std::move(lx)), qk(std::move(qk)), clauses(std::move(clauses)), sc(std::move(sc)) {}
    prism_rtl::Turn<JobDef> cycle() const override;
};


/// The step machine of `JobClauses`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// JobClauses: unbounded fn Lx, [FnClause], [((Text, Bool))], [Ty], [OutTy] -> Ex
struct JobClauses : prism_rtl::Job<Ex> {
    Lx lx;
    Array<ast::FnClause> clauses;
    Array<std::tuple<Text, bool>> names;
    Array<check_types::Ty> ptys;
    Array<OutTy> pts;
    JobClauses(Lx lx, Array<ast::FnClause> clauses, Array<std::tuple<Text, bool>> names, Array<check_types::Ty> ptys, Array<OutTy> pts) : lx(std::move(lx)), clauses(std::move(clauses)), names(std::move(names)), ptys(std::move(ptys)), pts(std::move(pts)) {}
    prism_rtl::Turn<Ex> cycle() const override;
};


/// The step machine of `IdPipe`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// IdPipe: unbounded fn Ex, (unbounded fn Ex -> [Do]) -> [Do]
struct IdPipe : prism_rtl::Job<Array<Do>> {
    Ex x;
    prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(Ex)> k_fn;
    IdPipe(Ex x, prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(Ex)> k_fn) : x(std::move(x)), k_fn(std::move(k_fn)) {}
    prism_rtl::Turn<Array<Do>> cycle() const override;
};


/// The step machine of `NodeDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// NodeDefOf: unbounded fn Lx, Text, [Pattern], Block, Scheme, Bool -> NodeDef
struct NodeDefOf : prism_rtl::Job<NodeDef> {
    Lx lx;
    Text qk;
    Array<ast::Pattern_> params;
    ast::Block body;
    check_types::Scheme sc;
    bool is_root;
    NodeDefOf(Lx lx, Text qk, Array<ast::Pattern_> params, ast::Block body, check_types::Scheme sc, bool is_root) : lx(std::move(lx)), qk(std::move(qk)), params(std::move(params)), body(std::move(body)), sc(std::move(sc)), is_root(std::move(is_root)) {}
    prism_rtl::Turn<NodeDef> cycle() const override;
};


/// The step machine of `BlockInto`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BlockInto: unbounded fn Wx, Env, Env, Block -> Wx
struct BlockInto : prism_rtl::Job<Wx> {
    Wx wx;
    Env benv;
    Env menv;
    ast::Block b;
    BlockInto(Wx wx, Env benv, Env menv, ast::Block b) : wx(std::move(wx)), benv(std::move(benv)), menv(std::move(menv)), b(std::move(b)) {}
    prism_rtl::Turn<Wx> cycle() const override;
};


/// The step machine of `PreBind`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PreBind: unbounded fn Wx, Env, Env, Stmt -> ((Wx, Env, Env))
struct PreBind : prism_rtl::Job<std::tuple<Wx, Env, Env>> {
    Wx wx;
    Env benv;
    Env menv;
    ast::Stmt s;
    PreBind(Wx wx, Env benv, Env menv, ast::Stmt s) : wx(std::move(wx)), benv(std::move(benv)), menv(std::move(menv)), s(std::move(s)) {}
    prism_rtl::Turn<std::tuple<Wx, Env, Env>> cycle() const override;
};


/// The step machine of `PreBindName`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PreBindName: unbounded fn Wx, Env, Env, SName, HowBound -> ((Wx, Env, Env))
struct PreBindName : prism_rtl::Job<std::tuple<Wx, Env, Env>> {
    Wx wx;
    Env benv;
    Env menv;
    ast::SName n;
    HowBound how;
    PreBindName(Wx wx, Env benv, Env menv, ast::SName n, HowBound how) : wx(std::move(wx)), benv(std::move(benv)), menv(std::move(menv)), n(std::move(n)), how(std::move(how)) {}
    prism_rtl::Turn<std::tuple<Wx, Env, Env>> cycle() const override;
};


/// The step machine of `ManyInstances`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ?ManyInstances: unbounded fn Lx, Range -> ?[(([((Text, Ty))], [((Text, Col))]))]
struct ManyInstances : prism_rtl::Job<std::optional<Array<std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>>>>> {
    Lx lx;
    ast::Range span;
    ManyInstances(Lx lx, ast::Range span) : lx(std::move(lx)), span(std::move(span)) {}
    prism_rtl::Turn<std::optional<Array<std::tuple<Array<std::tuple<Text, check_types::Ty>>, Array<std::tuple<Text, check_types::Col>>>>>> cycle() const override;
};


/// The step machine of `WidgetStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// WidgetStmt: unbounded fn Wx, Env, Env, Stmt, Bool -> ((Wx, Env, Env))
struct WidgetStmt : prism_rtl::Job<std::tuple<Wx, Env, Env>> {
    Wx wx;
    Env benv;
    Env menv;
    ast::Stmt s;
    bool last;
    WidgetStmt(Wx wx, Env benv, Env menv, ast::Stmt s, bool last) : wx(std::move(wx)), benv(std::move(benv)), menv(std::move(menv)), s(std::move(s)), last(std::move(last)) {}
    prism_rtl::Turn<std::tuple<Wx, Env, Env>> cycle() const override;
};


/// The step machine of `ResultOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ResultOf: unbounded fn Wx, Env, Env, Expr -> ((Wres, Wx))
struct ResultOf : prism_rtl::Job<std::tuple<Wres, Wx>> {
    Wx wx;
    Env benv;
    Env menv;
    ast::Expr x;
    ResultOf(Wx wx, Env benv, Env menv, ast::Expr x) : wx(std::move(wx)), benv(std::move(benv)), menv(std::move(menv)), x(std::move(x)) {}
    prism_rtl::Turn<std::tuple<Wres, Wx>> cycle() const override;
};


/// The step machine of `ResultOfTyped`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ResultOfTyped: unbounded fn Wx, Env, Env, Expr, Ty, OutTy -> ((Wres, Wx))
struct ResultOfTyped : prism_rtl::Job<std::tuple<Wres, Wx>> {
    Wx wx;
    Env benv;
    Env menv;
    ast::Expr x;
    check_types::Ty full;
    OutTy t;
    ResultOfTyped(Wx wx, Env benv, Env menv, ast::Expr x, check_types::Ty full, OutTy t) : wx(std::move(wx)), benv(std::move(benv)), menv(std::move(menv)), x(std::move(x)), full(std::move(full)), t(std::move(t)) {}
    prism_rtl::Turn<std::tuple<Wres, Wx>> cycle() const override;
};


/// The step machine of `HoldLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// HoldLine: unbounded fn Wx, Env, Env, Pattern, Expr, Expr -> ((Wx, Env))
struct HoldLine : prism_rtl::Job<std::tuple<Wx, Env>> {
    Wx wx;
    Env benv;
    Env menv;
    ast::Pattern_ p_;
    ast::Expr init;
    ast::Expr step_;
    HoldLine(Wx wx, Env benv, Env menv, ast::Pattern_ p_, ast::Expr init, ast::Expr step_) : wx(std::move(wx)), benv(std::move(benv)), menv(std::move(menv)), p_(std::move(p_)), init(std::move(init)), step_(std::move(step_)) {}
    prism_rtl::Turn<std::tuple<Wx, Env>> cycle() const override;
};


/// The step machine of `LetLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LetLine: unbounded fn Wx, Env, Env, Pattern, Expr -> ((Wx, Env))
struct LetLine : prism_rtl::Job<std::tuple<Wx, Env>> {
    Wx wx;
    Env benv;
    Env menv;
    ast::Pattern_ p_;
    ast::Expr e;
    LetLine(Wx wx, Env benv, Env menv, ast::Pattern_ p_, ast::Expr e) : wx(std::move(wx)), benv(std::move(benv)), menv(std::move(menv)), p_(std::move(p_)), e(std::move(e)) {}
    prism_rtl::Turn<std::tuple<Wx, Env>> cycle() const override;
};


/// The step machine of `BuildLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BuildLine: unbounded fn Wx, Env, Env, Expr, ?Bn -> ((Wx, Wres))
struct BuildLine : prism_rtl::Job<std::tuple<Wx, Wres>> {
    Wx wx;
    Env benv;
    Env menv;
    ast::Expr e;
    std::optional<Bn> bound_opt;
    BuildLine(Wx wx, Env benv, Env menv, ast::Expr e, std::optional<Bn> bound_opt) : wx(std::move(wx)), benv(std::move(benv)), menv(std::move(menv)), e(std::move(e)), bound_opt(std::move(bound_opt)) {}
    prism_rtl::Turn<std::tuple<Wx, Wres>> cycle() const override;
};


/// The step machine of `ElementLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ElementLine: unbounded fn Wx, Env, Env, Expr, ?Bn -> ((Wx, Wres))
struct ElementLine : prism_rtl::Job<std::tuple<Wx, Wres>> {
    Wx wx;
    Env benv;
    Env menv;
    ast::Expr e;
    std::optional<Bn> bound_opt;
    ElementLine(Wx wx, Env benv, Env menv, ast::Expr e, std::optional<Bn> bound_opt) : wx(std::move(wx)), benv(std::move(benv)), menv(std::move(menv)), e(std::move(e)), bound_opt(std::move(bound_opt)) {}
    prism_rtl::Turn<std::tuple<Wx, Wres>> cycle() const override;
};


/// The step machine of `WidgetLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// WidgetLine: unbounded fn Wx, Env, Env, Expr, ?Bn -> ((Wx, Wres))
struct WidgetLine : prism_rtl::Job<std::tuple<Wx, Wres>> {
    Wx wx;
    Env benv;
    Env menv;
    ast::Expr e;
    std::optional<Bn> bound_opt;
    WidgetLine(Wx wx, Env benv, Env menv, ast::Expr e, std::optional<Bn> bound_opt) : wx(std::move(wx)), benv(std::move(benv)), menv(std::move(menv)), e(std::move(e)), bound_opt(std::move(bound_opt)) {}
    prism_rtl::Turn<std::tuple<Wx, Wres>> cycle() const override;
};


/// The step machine of `InlineBlock`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InlineBlock: unbounded fn Wx, Env, Env, Block, Lx -> ((Wx, Wres))
struct InlineBlock : prism_rtl::Job<std::tuple<Wx, Wres>> {
    Wx wx;
    Env benv;
    Env menv;
    ast::Block b;
    Lx lx;
    InlineBlock(Wx wx, Env benv, Env menv, ast::Block b, Lx lx) : wx(std::move(wx)), benv(std::move(benv)), menv(std::move(menv)), b(std::move(b)), lx(std::move(lx)) {}
    prism_rtl::Turn<std::tuple<Wx, Wres>> cycle() const override;
};


/// The step machine of `DynamicExpr`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// DynamicExpr: unbounded fn Wx, Env, Expr -> ((Ex, [Read]))
struct DynamicExpr : prism_rtl::Job<std::tuple<Ex, Array<Read>>> {
    Wx wx;
    Env menv;
    ast::Expr e;
    DynamicExpr(Wx wx, Env menv, ast::Expr e) : wx(std::move(wx)), menv(std::move(menv)), e(std::move(e)) {}
    prism_rtl::Turn<std::tuple<Ex, Array<Read>>> cycle() const override;
};


/// The step machine of `EventRef`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// EventRef: unbounded fn Wx, Env, Expr -> ((EvRef, Wx))
struct EventRef : prism_rtl::Job<std::tuple<EvRef, Wx>> {
    Wx wx;
    Env menv;
    ast::Expr e;
    EventRef(Wx wx, Env menv, ast::Expr e) : wx(std::move(wx)), menv(std::move(menv)), e(std::move(e)) {}
    prism_rtl::Turn<std::tuple<EvRef, Wx>> cycle() const override;
};


/// The step machine of `FiringCode`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FiringCode: unbounded fn Sinks, Gn, Ex -> [Do]
struct FiringCode : prism_rtl::Job<Array<Do>> {
    Sinks sk;
    Gn g;
    Ex x;
    FiringCode(Sinks sk, Gn g, Ex x) : sk(std::move(sk)), g(std::move(g)), x(std::move(x)) {}
    prism_rtl::Turn<Array<Do>> cycle() const override;
};


/// The step machine of `FinishNode`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FinishNode: unbounded fn Wx, Text, [((Text, OutTy))], Bool -> NodeDef
struct FinishNode : prism_rtl::Job<NodeDef> {
    Wx wx0;
    Text qk;
    Array<std::tuple<Text, OutTy>> params;
    bool is_row;
    FinishNode(Wx wx0, Text qk, Array<std::tuple<Text, OutTy>> params, bool is_row) : wx0(std::move(wx0)), qk(std::move(qk)), params(std::move(params)), is_row(std::move(is_row)) {}
    prism_rtl::Turn<NodeDef> cycle() const override;
};


/// The step machine of `FinishPending`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FinishPending: unbounded fn Wx, [Gn] -> (([NodeDef], [Gn]))
struct FinishPending : prism_rtl::Job<std::tuple<Array<NodeDef>, Array<Gn>>> {
    Wx wx;
    Array<Gn> gns;
    FinishPending(Wx wx, Array<Gn> gns) : wx(std::move(wx)), gns(std::move(gns)) {}
    prism_rtl::Turn<std::tuple<Array<NodeDef>, Array<Gn>>> cycle() const override;
};


/// The step machine of `LowerProgram`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LowerProgram: unbounded fn [Src], [Module], Nat, TProgram, Text -> Model
struct LowerProgram : prism_rtl::Job<Model> {
    Array<check_errors::Src> srcs;
    Array<ast::Module> trees;
    Nat shown;
    typed::TProgram tp;
    Text name;
    LowerProgram(Array<check_errors::Src> srcs, Array<ast::Module> trees, Nat shown, typed::TProgram tp, Text name) : srcs(std::move(srcs)), trees(std::move(trees)), shown(std::move(shown)), tp(std::move(tp)), name(std::move(name)) {}
    prism_rtl::Turn<Model> cycle() const override;
};


/// The step machine of `WithNeeds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// WithNeeds: unbounded fn G, [Src], TProgram, [ModDef] -> [ModDef]
struct WithNeeds : prism_rtl::Job<Array<ModDef>> {
    check_env::G g;
    Array<check_errors::Src> srcs;
    typed::TProgram tp;
    Array<ModDef> defs;
    WithNeeds(check_env::G g, Array<check_errors::Src> srcs, typed::TProgram tp, Array<ModDef> defs) : g(std::move(g)), srcs(std::move(srcs)), tp(std::move(tp)), defs(std::move(defs)) {}
    prism_rtl::Turn<Array<ModDef>> cycle() const override;
};


/// The step machine of `NamedMods`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// NamedMods: unbounded fn G, [Src], TProgram, [Text] -> (Text ==> [Text])
struct NamedMods : prism_rtl::Job<Map<Text, Array<Text>>> {
    check_env::G g;
    Array<check_errors::Src> srcs;
    typed::TProgram tp;
    Array<Text> ms;
    NamedMods(check_env::G g, Array<check_errors::Src> srcs, typed::TProgram tp, Array<Text> ms) : g(std::move(g)), srcs(std::move(srcs)), tp(std::move(tp)), ms(std::move(ms)) {}
    prism_rtl::Turn<Map<Text, Array<Text>>> cycle() const override;
};


/// The step machine of `WithGroups`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// WithGroups: unbounded fn [ModDef] -> [ModDef]
struct WithGroups : prism_rtl::Job<Array<ModDef>> {
    Array<ModDef> defs;
    WithGroups(Array<ModDef> defs) : defs(std::move(defs)) {}
    prism_rtl::Turn<Array<ModDef>> cycle() const override;
};


/// The step machine of `ReachedBy`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ReachedBy: unbounded fn (Text ==> [Text]), [Text], [Text] -> [Text]
struct ReachedBy : prism_rtl::Job<Array<Text>> {
    Map<Text, Array<Text>> edges;
    Array<Text> todo;
    Array<Text> seen;
    ReachedBy(Map<Text, Array<Text>> edges, Array<Text> todo, Array<Text> seen) : edges(std::move(edges)), todo(std::move(todo)), seen(std::move(seen)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `NeededMods`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// NeededMods: unbounded fn G, Nat -> [Text]
struct NeededMods : prism_rtl::Job<Array<Text>> {
    check_env::G g;
    Nat shown;
    NeededMods(check_env::G g, Nat shown) : g(std::move(g)), shown(std::move(shown)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `ModRefs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ModRefs: unbounded fn G, Text -> [Text]
struct ModRefs : prism_rtl::Job<Array<Text>> {
    check_env::G g;
    Text m;
    ModRefs(check_env::G g, Text m) : g(std::move(g)), m(std::move(m)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `ProgDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ProgDefOf: unbounded fn Lx, Text -> ProgDef
struct ProgDefOf : prism_rtl::Job<ProgDef> {
    Lx lx;
    Text qk;
    ProgDefOf(Lx lx, Text qk) : lx(std::move(lx)), qk(std::move(qk)) {}
    prism_rtl::Turn<ProgDef> cycle() const override;
};


/// The step machine of `JobRoots`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// JobRoots: unbounded fn Lx -> [Text]
struct JobRoots : prism_rtl::Job<Array<Text>> {
    Lx lx;
    JobRoots(Lx lx) : lx(std::move(lx)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `UnboundedValues`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// UnboundedValues: unbounded fn Lx, Def -> [Text]
struct UnboundedValues : prism_rtl::Job<Array<Text>> {
    Lx lx;
    check_env::Def d;
    UnboundedValues(Lx lx, check_env::Def d) : lx(std::move(lx)), d(std::move(d)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `RunTargets`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RunTargets: unbounded fn Lx, Def -> [Text]
struct RunTargets : prism_rtl::Job<Array<Text>> {
    Lx lx;
    check_env::Def d;
    RunTargets(Lx lx, check_env::Def d) : lx(std::move(lx)), d(std::move(d)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `TailTargets`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TailTargets: unbounded fn Lx, Text -> [Text]
struct TailTargets : prism_rtl::Job<Array<Text>> {
    Lx lx;
    Text qk;
    TailTargets(Lx lx, Text qk) : lx(std::move(lx)), qk(std::move(qk)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `TailsOfBody`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TailsOfBody: unbounded fn Lx, FnBody -> [Text]
struct TailsOfBody : prism_rtl::Job<Array<Text>> {
    Lx lx;
    ast::FnBody body;
    TailsOfBody(Lx lx, ast::FnBody body) : lx(std::move(lx)), body(std::move(body)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `ModDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ModDefOf: unbounded fn Lx, Text, [((Text, Bool))], ModInfo, [Text] -> ModDef
struct ModDefOf : prism_rtl::Job<ModDef> {
    Lx lx0;
    Text m;
    Array<std::tuple<Text, bool>> roots;
    check_env::ModInfo info;
    Array<Text> mods;
    ModDefOf(Lx lx0, Text m, Array<std::tuple<Text, bool>> roots, check_env::ModInfo info, Array<Text> mods) : lx0(std::move(lx0)), m(std::move(m)), roots(std::move(roots)), info(std::move(info)), mods(std::move(mods)) {}
    prism_rtl::Turn<ModDef> cycle() const override;
};


/// The step machine of `DefItems`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// DefItems: unbounded fn Lx, Def, [((Text, Bool))] -> [Item]
struct DefItems : prism_rtl::Job<Array<Item>> {
    Lx lx;
    check_env::Def d;
    Array<std::tuple<Text, bool>> roots;
    DefItems(Lx lx, check_env::Def d, Array<std::tuple<Text, bool>> roots) : lx(std::move(lx)), d(std::move(d)), roots(std::move(roots)) {}
    prism_rtl::Turn<Array<Item>> cycle() const override;
};


/// The step machine of `TyDefs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TyDefs: unbounded fn Lx, TyInfo -> [Item]
struct TyDefs : prism_rtl::Job<Array<Item>> {
    Lx lx;
    check_env::TyInfo ti;
    TyDefs(Lx lx, check_env::TyInfo ti) : lx(std::move(lx)), ti(std::move(ti)) {}
    prism_rtl::Turn<Array<Item>> cycle() const override;
};


/// The step machine of `TyPodable`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TyPodable: unbounded fn Lx, Ty, [Text] -> Bool
struct TyPodable : prism_rtl::Job<bool> {
    Lx lx;
    check_types::Ty t;
    Array<Text> seen;
    TyPodable(Lx lx, check_types::Ty t, Array<Text> seen) : lx(std::move(lx)), t(std::move(t)), seen(std::move(seen)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `CaseField`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CaseField: unbounded fn Lx, Text, Nat, Ty -> OutTy
struct CaseField : prism_rtl::Job<OutTy> {
    Lx lx;
    Text ck;
    Nat i;
    check_types::Ty t;
    CaseField(Lx lx, Text ck, Nat i, check_types::Ty t) : lx(std::move(lx)), ck(std::move(ck)), i(std::move(i)), t(std::move(t)) {}
    prism_rtl::Turn<OutTy> cycle() const override;
};


/// The step machine of `TagDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TagDefOf: unbounded fn Lx, TagInfo -> TagDef
struct TagDefOf : prism_rtl::Job<TagDef> {
    Lx lx;
    check_env::TagInfo tg;
    TagDefOf(Lx lx, check_env::TagInfo tg) : lx(std::move(lx)), tg(std::move(tg)) {}
    prism_rtl::Turn<TagDef> cycle() const override;
};


/// The step machine of `RowDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RowDefOf: unbounded fn Lx, TyInfo -> RowDef
struct RowDefOf : prism_rtl::Job<RowDef> {
    Lx lx;
    check_env::TyInfo ti;
    RowDefOf(Lx lx, check_env::TyInfo ti) : lx(std::move(lx)), ti(std::move(ti)) {}
    prism_rtl::Turn<RowDef> cycle() const override;
};


/// The step machine of `ElemRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ElemRow: unbounded fn Lx, [Text] -> RowDef
struct ElemRow : prism_rtl::Job<RowDef> {
    Lx lx;
    Array<Text> mods;
    ElemRow(Lx lx, Array<Text> mods) : lx(std::move(lx)), mods(std::move(mods)) {}
    prism_rtl::Turn<RowDef> cycle() const override;
};


/// The step machine of `AnswerEnum`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// AnswerEnum: unbounded fn Lx, [Text] -> AnswerDef
struct AnswerEnum : prism_rtl::Job<AnswerDef> {
    Lx lx;
    Array<Text> mods;
    AnswerEnum(Lx lx, Array<Text> mods) : lx(std::move(lx)), mods(std::move(mods)) {}
    prism_rtl::Turn<AnswerDef> cycle() const override;
};


/// The step machine of `AnswerTy`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// AnswerTy: unbounded fn Lx, TagInfo -> OutTy
struct AnswerTy : prism_rtl::Job<OutTy> {
    Lx lx;
    check_env::TagInfo tg;
    AnswerTy(Lx lx, check_env::TagInfo tg) : lx(std::move(lx)), tg(std::move(tg)) {}
    prism_rtl::Turn<OutTy> cycle() const override;
};


/// The step machine of `CheckDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CheckDefOf: unbounded fn Lx, CheckDecl -> CheckDef
struct CheckDefOf : prism_rtl::Job<CheckDef> {
    Lx lx;
    ast::CheckDecl c;
    CheckDefOf(Lx lx, ast::CheckDecl c) : lx(std::move(lx)), c(std::move(c)) {}
    prism_rtl::Turn<CheckDef> cycle() const override;
};


/// The step machine of `ForLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ForLine: unbounded fn Wx, Env, Env, ?ForBinders, Expr, Block, Expr, ?Bn -> ((Wx, Wres))
struct ForLine : prism_rtl::Job<std::tuple<Wx, Wres>> {
    Wx wx;
    Env benv;
    Env menv;
    std::optional<ast::ForBinders> binders_opt;
    ast::Expr source;
    ast::Block body;
    ast::Expr e;
    std::optional<Bn> bound_opt;
    ForLine(Wx wx, Env benv, Env menv, std::optional<ast::ForBinders> binders_opt, ast::Expr source, ast::Block body, ast::Expr e, std::optional<Bn> bound_opt) : wx(std::move(wx)), benv(std::move(benv)), menv(std::move(menv)), binders_opt(std::move(binders_opt)), source(std::move(source)), body(std::move(body)), e(std::move(e)), bound_opt(std::move(bound_opt)) {}
    prism_rtl::Turn<std::tuple<Wx, Wres>> cycle() const override;
};


/// The step machine of `RebuildLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RebuildLine: unbounded fn Wx, Env, Env, Expr, Block, Expr, ?Bn -> ((Wx, Wres))
struct RebuildLine : prism_rtl::Job<std::tuple<Wx, Wres>> {
    Wx wx;
    Env benv;
    Env menv;
    ast::Expr scrut;
    ast::Block body;
    ast::Expr e;
    std::optional<Bn> bound_opt;
    RebuildLine(Wx wx, Env benv, Env menv, ast::Expr scrut, ast::Block body, ast::Expr e, std::optional<Bn> bound_opt) : wx(std::move(wx)), benv(std::move(benv)), menv(std::move(menv)), scrut(std::move(scrut)), body(std::move(body)), e(std::move(e)), bound_opt(std::move(bound_opt)) {}
    prism_rtl::Turn<std::tuple<Wx, Wres>> cycle() const override;
};


/// The step machine of `SelfIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SelfIn: unbounded fn Ty, Text -> Ty
struct SelfIn : prism_rtl::Job<check_types::Ty> {
    check_types::Ty t;
    Text param;
    SelfIn(check_types::Ty t, Text param) : t(std::move(t)), param(std::move(param)) {}
    prism_rtl::Turn<check_types::Ty> cycle() const override;
};


/// The step machine of `TraitDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TraitDefOf: unbounded fn Lx, TraitInfo -> TraitDef
struct TraitDefOf : prism_rtl::Job<TraitDef> {
    Lx lx0;
    check_env::TraitInfo tr;
    TraitDefOf(Lx lx0, check_env::TraitInfo tr) : lx0(std::move(lx0)), tr(std::move(tr)) {}
    prism_rtl::Turn<TraitDef> cycle() const override;
};


/// The step machine of `ImplDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ImplDefOf: unbounded fn Lx, ImplInfo -> ImplDef
struct ImplDefOf : prism_rtl::Job<ImplDef> {
    Lx lx;
    check_env::ImplInfo im;
    ImplDefOf(Lx lx, check_env::ImplInfo im) : lx(std::move(lx)), im(std::move(im)) {}
    prism_rtl::Turn<ImplDef> cycle() const override;
};


/// The step machine of `IfGenLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// IfGenLine: unbounded fn Wx, Env, Expr, Block, Block, Expr -> ((Wx, Wres))
struct IfGenLine : prism_rtl::Job<std::tuple<Wx, Wres>> {
    Wx wx;
    Env menv;
    ast::Expr c;
    ast::Block then_b;
    ast::Block else_b;
    ast::Expr e;
    IfGenLine(Wx wx, Env menv, ast::Expr c, ast::Block then_b, ast::Block else_b, ast::Expr e) : wx(std::move(wx)), menv(std::move(menv)), c(std::move(c)), then_b(std::move(then_b)), else_b(std::move(else_b)), e(std::move(e)) {}
    prism_rtl::Turn<std::tuple<Wx, Wres>> cycle() const override;
};


}  // namespace lower

}  // namespace crate
