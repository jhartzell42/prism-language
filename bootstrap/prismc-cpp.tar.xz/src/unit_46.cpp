// The module `Lower.Functions`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <lower/functions/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>

// The module `Lower.Functions`, from `target/bootstrap/cpp-src/prismc/lower/functions.prism`.
namespace crate::lower::functions {

/// BoundOf: fn Lx, Text -> [Text]
Array<Text> bound_of_f(const crate::lower::Lx& lx_p0, const Text& text1) {
    {
        auto&& c0_1 = text1;
        if (c0_1 == Text::lit("Prelude.Eq")) {
            return Array(std::vector{Text::lit("Eq")});
        }
    }
    {
        auto&& c1_1 = text1;
        if (c1_1 == Text::lit("Prelude.Ord")) {
            return Array(std::vector{Text::lit("Ord")});
        }
    }
    {
        auto&& c2_1 = text1;
        if (c2_1 == Text::lit("Prelude.Show")) {
            return Array(std::vector{Text::lit("Show")});
        }
    }
    {
        auto&& c3_1 = text1;
        if (c3_1 == Text::lit("Prelude.Num")) {
            return Array(std::vector{Text::lit("Num")});
        }
    }
    {
        auto&& c4_1 = text1;
        if (c4_1 == Text::lit("Prelude.Pod")) {
            return Array(std::vector{Text::lit("ToPod"), Text::lit("FromPod")});
        }
    }
    {
        auto&& cls_p6 = text1;
        auto&& _m = crate::prelude::get(prism_rtl::deref(lx_p0.g_p).traits_p, cls_p6);
        if (prism_rtl::is_some(_m)) {
            auto&& tr_p7 = prism_rtl::some_of(_m);
            return Array(std::vector{crate::lower::path_in_f(lx_p0, prism_rtl::deref(tr_p7).home_p, crate::lower::camel_f(crate::check::types::bare_name_f(cls_p6)))});
        }
        if (prism_rtl::is_none(_m)) {
            return Array<Text>{};
        }
        prism_rtl::unreachable("no arm matched");
    }
}


/// SchemeGenerics: fn Lx, Scheme -> [((Text, [Text]))]
Array<std::tuple<Text, Array<Text>>> scheme_generics_f(const crate::lower::Lx& lx_p0, const crate::check::types::Scheme& sc_p1) {
    return crate::prelude::each(sc_p1.qs_p, [&](const Text& q_p2) {
        return ({
            auto bs_p3 = crate::prelude::fold(sc_p1.bounds_p, Array(std::vector{Text::lit("Clone")}), [&](const Array<Text>& acc_p5, const std::tuple<Text, Text>& _p1) {
                auto&& v_p6 = std::get<0>(_p1);
                auto&& cls_p7 = std::get<1>(_p1);
                return v_p6 == q_p2
                    ? crate::check::types::union_texts_f(acc_p5, bound_of_f(lx_p0, cls_p7))
                    : acc_p5;
            });
            auto keyed_p4 = keys_by_f(sc_p1.ty_p, q_p2)
                ? crate::check::types::union_texts_f(bs_p3, Array(std::vector{Text::lit("Ord")}))
                : bs_p3;
            std::tuple{crate::lower::camel_f(q_p2), keyed_p4};
        });
    });
}


/// KeysBy: fn Ty, Text -> Bool
bool keys_by_f(const crate::check::types::Ty& t_p0, const Text& q_p1) {
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(t_p0)) {
        auto&& k_p2 = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p0).a0;
        auto&& v_p3 = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p0).a1;
        return ((prism_rtl::deref(prism_rtl::deref(k_p2)) == crate::check::types::Ty(crate::check::types::Ty::TyQ{q_p1})) || keys_by_f(prism_rtl::deref(prism_rtl::deref(k_p2)), q_p1)) || keys_by_f(prism_rtl::deref(prism_rtl::deref(v_p3)), q_p1);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t_p0)) {
        auto&& ts_p4 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p0).a1;
        return crate::prelude::fold(ts_p4, false, [&](const bool& found_p5, const crate::check::types::Ty& x_p6) { return prism_rtl::deref(found_p5) || keys_by_f(x_p6, q_p1); });
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(t_p0)) {
        auto&& ps_p7 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p0).a1;
        auto&& r_p8 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p0).a2;
        return crate::prelude::fold(ps_p7, false, [&](const bool& found_p9, const crate::check::types::Ty& x_pa) { return prism_rtl::deref(found_p9) || keys_by_f(x_pa, q_p1); }) || keys_by_f(prism_rtl::deref(prism_rtl::deref(r_p8)), q_p1);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t_p0)) {
        auto&& ts_pb = prism_rtl::as<crate::check::types::Ty::TyTuple>(t_p0).a0;
        return crate::prelude::fold(ts_pb, false, [&](const bool& found_pc, const crate::check::types::Ty& x_pd) { return prism_rtl::deref(found_pc) || keys_by_f(x_pd, q_p1); });
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(t_p0)) {
        auto&& x_pe = prism_rtl::as<crate::check::types::Ty::TyArray>(t_p0).a0;
        return keys_by_f(prism_rtl::deref(prism_rtl::deref(x_pe)), q_p1);
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t_p0)) {
        auto&& x_pf = prism_rtl::as<crate::check::types::Ty::TySig>(t_p0).a1;
        return keys_by_f(prism_rtl::deref(prism_rtl::deref(x_pf)), q_p1);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(t_p0)) {
        auto&& x_pg = prism_rtl::as<crate::check::types::Ty::TyAt>(t_p0).a0;
        return keys_by_f(prism_rtl::deref(prism_rtl::deref(x_pg)), q_p1);
    }
    {
        return false;
    }
}


/// ParamNames: unbounded fn Lx, [FnClause], [OutTy] -> [((Text, Bool))]
Array<std::tuple<Text, bool>> param_names_f(const crate::lower::Lx& lx_p0, const Array<crate::syntax::decls::FnClause>& clauses_p1, const Array<crate::lower::model::OutTy>& pts_p2) {
    return crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(crate::prelude::len(pts_p2)), ({
        auto clauses_p1x = clauses_p1;
        auto lx_p0x = lx_p0;
        auto pts_p2x = pts_p2;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, bool>>(Nat)>>(prism_rtl::rc([=, clauses_p1x = std::move(clauses_p1x), lx_p0x = std::move(lx_p0x), pts_p2x = std::move(pts_p2x)](Nat p0) {
        return ({
            auto clauses_p1xy = clauses_p1x;
            auto lx_p0xy = lx_p0x;
            auto pts_p2xy = pts_p2x;
            (crate::prelude::entered(crate::prelude::once_job([=, clauses_p1xy = std::move(clauses_p1xy), lx_p0xy = std::move(lx_p0xy), pts_p2xy = std::move(pts_p2xy)]() {
            return ({
                auto i_p3 = p0;
                ({
                auto names_p4 = crate::prelude::each(clauses_p1xy, [&](const crate::syntax::decls::FnClause& c_p8) { return plain_binder_f(lx_p0xy, crate::prelude::or_(crate::prelude::index(prism_rtl::deref(c_p8).params_p, i_p3), crate::lower::patterns::dummy_pat_p())); });
                auto first_p5 = crate::prelude::or_(crate::prelude::index(names_p4, Nat(0u)), Text::lit(""));
                auto same_p6 = (first_p5 != Text::lit("")) && crate::prelude::fold(names_p4, true, [&](const bool& ok_p9, const Text& n_pa) { return prism_rtl::deref(ok_p9) && (n_pa == first_p5); });
                auto span_p7 = ({
                    __label__ _done;
                    prism_rtl::Slot<crate::syntax::Range> _v;
                    auto&& _m = prism_rtl::deref(prism_rtl::deref(crate::prelude::or_(crate::prelude::index(prism_rtl::deref(crate::prelude::or_(crate::prelude::index(clauses_p1xy, Nat(0u)), dummy_clause_p())).params_p, i_p3), crate::lower::patterns::dummy_pat_p())).kind_p);
                    if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
                        auto&& n_pb = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
                        _v.set(prism_rtl::deref(n_pb).span_p);
                        goto _done;
                    }
                    {
                        _v.set(crate::syntax::Range{.start_p = Nat(0u), .end_p = Nat(0u)});
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                (std::move(same_p6)
                ? crate::prelude::call_then(crate::lower::start_local_name_at_f(lx_p0xy, first_p5, span_p7), [=](Text local_name_at_f_3553) { return prism_rtl::finished(std::tuple{local_name_at_f_3553, false}); })
                : prism_rtl::finished(std::tuple{param_word_f(crate::prelude::or_(crate::prelude::index(pts_p2xy, i_p3), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})), i_p3), true}));
            });
            });
        })));
        });
    }));
    })));
}


prism_rtl::Turn<Array<std::tuple<Text, bool>>> ParamNames::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& clauses_p1 = this->clauses_p1;
    const auto& pts_p2 = this->pts_p2;
    return crate::prelude::each_job(crate::check::errors::range0_f(crate::prelude::len(pts_p2)), ({
        auto clauses_p1x = clauses_p1;
        auto lx_p0x = lx_p0;
        auto pts_p2x = pts_p2;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, bool>>(Nat)>>(prism_rtl::rc([=, clauses_p1x = std::move(clauses_p1x), lx_p0x = std::move(lx_p0x), pts_p2x = std::move(pts_p2x)](Nat p0) {
        return ({
            auto clauses_p1xy = clauses_p1x;
            auto lx_p0xy = lx_p0x;
            auto pts_p2xy = pts_p2x;
            (crate::prelude::entered(crate::prelude::once_job([=, clauses_p1xy = std::move(clauses_p1xy), lx_p0xy = std::move(lx_p0xy), pts_p2xy = std::move(pts_p2xy)]() {
            return ({
                auto i_p3 = p0;
                ({
                auto names_p4 = crate::prelude::each(clauses_p1xy, [&](const crate::syntax::decls::FnClause& c_p8) { return plain_binder_f(lx_p0xy, crate::prelude::or_(crate::prelude::index(prism_rtl::deref(c_p8).params_p, i_p3), crate::lower::patterns::dummy_pat_p())); });
                auto first_p5 = crate::prelude::or_(crate::prelude::index(names_p4, Nat(0u)), Text::lit(""));
                auto same_p6 = (first_p5 != Text::lit("")) && crate::prelude::fold(names_p4, true, [&](const bool& ok_p9, const Text& n_pa) { return prism_rtl::deref(ok_p9) && (n_pa == first_p5); });
                auto span_p7 = ({
                    __label__ _done;
                    prism_rtl::Slot<crate::syntax::Range> _v;
                    auto&& _m = prism_rtl::deref(prism_rtl::deref(crate::prelude::or_(crate::prelude::index(prism_rtl::deref(crate::prelude::or_(crate::prelude::index(clauses_p1xy, Nat(0u)), dummy_clause_p())).params_p, i_p3), crate::lower::patterns::dummy_pat_p())).kind_p);
                    if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
                        auto&& n_pb = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
                        _v.set(prism_rtl::deref(n_pb).span_p);
                        goto _done;
                    }
                    {
                        _v.set(crate::syntax::Range{.start_p = Nat(0u), .end_p = Nat(0u)});
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                (std::move(same_p6)
                ? crate::prelude::call_then(crate::lower::start_local_name_at_f(lx_p0xy, first_p5, span_p7), [=](Text local_name_at_f_3553) { return prism_rtl::finished(std::tuple{local_name_at_f_3553, false}); })
                : prism_rtl::finished(std::tuple{param_word_f(crate::prelude::or_(crate::prelude::index(pts_p2xy, i_p3), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})), i_p3), true}));
            });
            });
        })));
        });
    }));
    }))->cycle();
}


/// `Start ParamNames, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<std::tuple<Text, bool>>> start_param_names_f(crate::lower::Lx lx_p0, Array<crate::syntax::decls::FnClause> clauses_p1, Array<crate::lower::model::OutTy> pts_p2) {
    return prism_rtl::make_rc<ParamNames>(lx_p0, clauses_p1, pts_p2);
}


/// PlainBinder: fn Lx, Pattern -> Text
Text plain_binder_f(const crate::lower::Lx& lx_p0, const crate::syntax::Pattern_& p_p1) {
    auto&& _m = prism_rtl::deref(p_p1.kind_p);
    if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
        auto&& n_p2 = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        auto [qk_o4, why_p5] = crate::check::env::names::resolve_value_f(lx_p0.g_p, lx_p0.home_p, n_p2);
        auto is_ctor_p3 = ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            if (prism_rtl::is_some(qk_o4)) {
                auto&& qk_p6 = prism_rtl::some_of(qk_o4);
                _v.set(crate::check::env::has_key_f(prism_rtl::deref(lx_p0.g_p).ctors_p, qk_p6) && (crate::check::env::is_upper_text_f(crate::lower::base_f(crate::check::env::sname_key_f(n_p2))) || crate::lower::patterns::is_unit_ctor_f(lx_p0, qk_p6)));
                goto _done;
            }
            if (prism_rtl::is_none(qk_o4)) {
                _v.set(false);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        return std::move(is_ctor_p3)
            ? Text::lit("")
            : crate::check::env::sname_key_f(n_p2);
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PGroup>(_m)) {
        auto&& q_p7 = prism_rtl::as<crate::syntax::PatternKind::PGroup>(_m).a0;
        return plain_binder_f(lx_p0, prism_rtl::deref(prism_rtl::deref(q_p7)));
    }
    {
        return Text::lit("");
    }
}


/// ParamWord: fn OutTy, Nat -> Text
Text param_word_f(const crate::lower::model::OutTy& t_p0, const Nat& i_p1) {
    auto base_p2 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t_p0)) {
            auto&& n_p3 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p0).a0;
            _v.set(crate::lower::snake_f(crate::prelude::or_(crate::syntax::lexer::chars::last_o(crate::prelude::split_on(n_p3, Text::lit("::"))), Text::lit("arg"))));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::OutTy::OutText>(t_p0)) {
            _v.set(Text::lit("text"));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::OutTy::OutNat>(t_p0)) {
            _v.set(Text::lit("n"));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::OutTy::OutInt>(t_p0)) {
            _v.set(Text::lit("i"));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::OutTy::OutArray>(t_p0)) {
            _v.set(Text::lit("xs"));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::OutTy::OutMap>(t_p0)) {
            _v.set(Text::lit("map"));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::OutTy::OutOpt>(t_p0)) {
            _v.set(Text::lit("opt"));
            goto _done;
        }
        {
            _v.set(Text::lit("arg"));
            goto _done;
        }
    _done:
        _v.take();
    });
    return prism_rtl::cat(base_p2, i_p1);
}


/// ClausesBody: unbounded fn Lx, Env, [FnClause], [((Text, Bool))], [Ty], (fn Lx, Env, FnBody -> Ex), Text, OutTy -> Ex
crate::lower::model::Ex clauses_body_f(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const Array<crate::syntax::decls::FnClause>& clauses_p2, const Array<std::tuple<Text, bool>>& names_p3, const Array<crate::check::types::Ty>& ptys_p4, const prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::Lx, crate::lower::types::Env, crate::syntax::decls::FnBody>)>& body_f5, const Text& label_p6, const crate::lower::model::OutTy& t_p7) {
    auto env1_p8 = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(crate::prelude::len(names_p3)), env_p1, ({
        auto names_p3x = names_p3;
        auto lx_p0x = lx_p0;
        auto clauses_p2x = clauses_p2;
        auto ptys_p4x = ptys_p4;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::types::Env>(std::tuple<crate::lower::types::Env, Nat>)>>(prism_rtl::rc([=, names_p3x = std::move(names_p3x), lx_p0x = std::move(lx_p0x), clauses_p2x = std::move(clauses_p2x), ptys_p4x = std::move(ptys_p4x)](std::tuple<crate::lower::types::Env, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto names_p3xy = names_p3x;
            auto lx_p0xy = lx_p0x;
            auto clauses_p2xy = clauses_p2x;
            auto ptys_p4xy = ptys_p4x;
            (crate::prelude::entered(crate::prelude::once_job([=, names_p3xy = std::move(names_p3xy), lx_p0xy = std::move(lx_p0xy), clauses_p2xy = std::move(clauses_p2xy), ptys_p4xy = std::move(ptys_p4xy)]() {
            return ({
                auto en_pa = p0;
                auto i_pb = p1;
                ({
                auto [rs_pc, matched_pd] = crate::prelude::or_(crate::prelude::index(names_p3xy, i_pb), std::tuple{Text::lit(""), true});
                matched_pd
                ? prism_rtl::finished(en_pa)
                : crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0xy, crate::lower::types::peel_f(crate::prelude::or_(crate::prelude::index(ptys_p4xy, i_pb), crate::check::types::Ty(crate::check::types::Ty::TyErr{})))), [=](crate::lower::model::OutTy out_ty_of_f_5056) { return prism_rtl::finished(crate::lower::types::bind_f(en_pa, plain_binder_f(lx_p0xy, crate::prelude::or_(crate::prelude::index(prism_rtl::deref(crate::prelude::or_(crate::prelude::index(clauses_p2xy, Nat(0u)), dummy_clause_p())).params_p, i_pb), crate::lower::patterns::dummy_pat_p())), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{rs_pc}), crate::lower::types::Holding(crate::lower::types::Holding::ByRef{}), out_ty_of_f_5056}))); });
            });
            });
        })));
        });
    })));
    })));
    auto scrut_ix_p9 = crate::prelude::filter(crate::check::errors::range0_f(crate::prelude::len(names_p3)), [&](const Nat& i_pe) {
        return ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            auto&& _m = crate::prelude::index(names_p3, i_pe);
            if (prism_rtl::is_some(_m) && std::get<1>(prism_rtl::some_of(_m))) {
                _v.set(true);
                goto _done;
            }
            {
                _v.set(false);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    return crate::prelude::len(scrut_ix_p9) == Nat(0u)
        ? ({
        auto c_pf = crate::prelude::or_(crate::prelude::index(clauses_p2, Nat(0u)), dummy_clause_p());
        (crate::prelude::run_to_end(body_f5(std::tuple{lx_p0, env1_p8, prism_rtl::deref(c_pf).body_p})));
    })
        : ({
        auto scrut_pg = ({
            __label__ _done;
            prism_rtl::Slot<crate::lower::model::Ex> _v;
            {
                auto&& m5353_0 = scrut_ix_p9;
                if (m5353_0.size() == 1u) {
                    {
                        auto&& _c1 = crate::prelude::index(m5353_0, Nat(0u));
                        if (prism_rtl::is_some(_c1)) {
                            auto&& i_pi = prism_rtl::some_of(_c1);
                            _v.set(crate::lower::model::Ex(crate::lower::model::Ex::XVar{crate::prelude::or_(crate::prelude::index(crate::prelude::each(names_p3, [&](const std::tuple<Text, bool>& _p0) {
                                auto&& n_pj = std::get<0>(_p0);
                                return n_pj;
                            }), i_pi), Text::lit("arg"))}));
                            goto _done;
                        }
                    }
                }
            }
            {
                _v.set(crate::lower::model::Ex(crate::lower::model::Ex::XTuple{crate::prelude::each(scrut_ix_p9, [&](const Nat& i_pk) {
                    return crate::lower::model::Ex(crate::lower::model::Ex::XVar{crate::prelude::or_(crate::prelude::index(crate::prelude::each(names_p3, [&](const std::tuple<Text, bool>& _p0) {
                        auto&& n_pl = std::get<0>(_p0);
                        return n_pl;
                    }), i_pk), Text::lit("arg"))});
                })}));
                goto _done;
            }
        _done:
            _v.take();
        });
        auto arms_ph = crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(crate::prelude::len(clauses_p2)), ({
            auto clauses_p2x = clauses_p2;
            auto scrut_ix_p9x = scrut_ix_p9;
            auto lx_p0x = lx_p0;
            auto ptys_p4x = ptys_p4;
            auto label_p6x = label_p6;
            auto body_f5x = body_f5;
            auto env1_p8x = env1_p8;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::XArm>(Nat)>>(prism_rtl::rc([=, clauses_p2x = std::move(clauses_p2x), scrut_ix_p9x = std::move(scrut_ix_p9x), lx_p0x = std::move(lx_p0x), ptys_p4x = std::move(ptys_p4x), label_p6x = std::move(label_p6x), body_f5x = std::move(body_f5x), env1_p8x = std::move(env1_p8x)](Nat p0) {
            return ({
                auto clauses_p2xy = clauses_p2x;
                auto scrut_ix_p9xy = scrut_ix_p9x;
                auto lx_p0xy = lx_p0x;
                auto ptys_p4xy = ptys_p4x;
                auto label_p6xy = label_p6x;
                auto body_f5xy = body_f5x;
                auto env1_p8xy = env1_p8x;
                (crate::prelude::entered(crate::prelude::once_job([=, clauses_p2xy = std::move(clauses_p2xy), scrut_ix_p9xy = std::move(scrut_ix_p9xy), lx_p0xy = std::move(lx_p0xy), ptys_p4xy = std::move(ptys_p4xy), label_p6xy = std::move(label_p6xy), body_f5xy = std::move(body_f5xy), env1_p8xy = std::move(env1_p8xy)]() {
                return ({
                    auto ci_pm = p0;
                    ({
                    auto c_pn = crate::prelude::or_(crate::prelude::index(clauses_p2xy, ci_pm), dummy_clause_p());
                    (crate::prelude::call_value(crate::prelude::each_job(scrut_ix_p9xy, ({
                    auto lx_p0xyx = lx_p0xy;
                    auto c_pnx = c_pn;
                    auto ptys_p4xyx = ptys_p4xy;
                    auto label_p6xyx = label_p6xy;
                    auto ci_pmx = ci_pm;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::patterns::PatOut>(Nat)>>(prism_rtl::rc([=, lx_p0xyx = std::move(lx_p0xyx), c_pnx = std::move(c_pnx), ptys_p4xyx = std::move(ptys_p4xyx), label_p6xyx = std::move(label_p6xyx), ci_pmx = std::move(ci_pmx)](Nat p0) {
                    return ({
                        auto lx_p0xyxy = lx_p0xyx;
                        auto c_pnxy = c_pnx;
                        auto ptys_p4xyxy = ptys_p4xyx;
                        auto label_p6xyxy = label_p6xyx;
                        auto ci_pmxy = ci_pmx;
                        (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xyxy = std::move(lx_p0xyxy), c_pnxy = std::move(c_pnxy), ptys_p4xyxy = std::move(ptys_p4xyxy), label_p6xyxy = std::move(label_p6xyxy), ci_pmxy = std::move(ci_pmxy)]() {
                        return ({
                            auto i_ps = p0;
                            (prism_rtl::more(prism_rtl::rc(crate::lower::patterns::RustPat(lx_p0xyxy, crate::prelude::or_(crate::prelude::index(prism_rtl::deref(c_pnxy).params_p, i_ps), crate::lower::patterns::dummy_pat_p()), crate::prelude::or_(crate::prelude::index(ptys_p4xyxy, i_ps), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), crate::lower::types::Holding(crate::lower::types::Holding::ByRef{}), prism_rtl::cat(label_p6xyxy, ci_pmxy, "_", i_ps)))));
                        });
                    })));
                    });
                })));
                })), [=](Array<crate::lower::patterns::PatOut> each_5668) {
                    return ({
                        auto pos_po = each_5668;
                        auto pa_pp = ({
                            __label__ _done;
                            prism_rtl::Slot<crate::lower::model::Pa> _v;
                            {
                                auto&& m5794_0 = pos_po;
                                if (m5794_0.size() == 1u) {
                                    {
                                        auto&& _c1 = crate::prelude::index(m5794_0, Nat(0u));
                                        if (prism_rtl::is_some(_c1)) {
                                            auto&& o_pt = prism_rtl::some_of(_c1);
                                            _v.set(prism_rtl::deref(o_pt).pa_p);
                                            goto _done;
                                        }
                                    }
                                }
                            }
                            {
                                _v.set(crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{crate::prelude::each(pos_po, [&](const crate::lower::patterns::PatOut& o_pu) { return prism_rtl::deref(o_pu).pa_p; })}));
                                goto _done;
                            }
                        _done:
                            _v.take();
                        });
                        auto conds_pq = crate::prelude::fold(pos_po, Array<crate::lower::model::Cc>{}, [&](const Array<crate::lower::model::Cc>& acc_pv, const crate::lower::patterns::PatOut& o_p10) { return crate::prelude::append(acc_pv, prism_rtl::deref(o_p10).conds_p); });
                        auto binds_pr = crate::prelude::fold(pos_po, Array<std::tuple<Text, crate::lower::types::Bn>>{}, [&](const Array<std::tuple<Text, crate::lower::types::Bn>>& acc_p11, const crate::lower::patterns::PatOut& o_p12) { return crate::prelude::append(acc_p11, prism_rtl::deref(o_p12).binds_p); });
                        (crate::prelude::call_value(body_f5xy(std::tuple{lx_p0xy, crate::lower::expr::bind_all_f(env1_p8xy, binds_pr), prism_rtl::deref(c_pn).body_p}), [=, pa_pp = std::move(pa_pp), conds_pq = std::move(conds_pq)](crate::lower::model::Ex body_6074) { return prism_rtl::finished(crate::lower::model::XArm{.pat_p = pa_pp, .conds_p = conds_pq, .body_p = body_6074}); }));
                    });
                }));
                });
                });
            })));
            });
        })));
        })));
        (crate::lower::types::own_f(crate::lower::expr::arms_value_f(scrut_pg, arms_ph, prism_rtl::cat("\'", label_p6), t_p7)));
    });
}


prism_rtl::Turn<crate::lower::model::Ex> ClausesBody::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& clauses_p2 = this->clauses_p2;
    const auto& names_p3 = this->names_p3;
    const auto& ptys_p4 = this->ptys_p4;
    const auto& body_f5 = this->body_f5;
    const auto& label_p6 = this->label_p6;
    const auto& t_p7 = this->t_p7;
    auto body_f5x = body_f5;
    auto clauses_p2x = clauses_p2;
    auto env_p1x = env_p1;
    auto label_p6x = label_p6;
    auto lx_p0x = lx_p0;
    auto names_p3x = names_p3;
    auto ptys_p4x = ptys_p4;
    auto t_p7x = t_p7;
    return crate::prelude::call_value(crate::prelude::fold_job(crate::check::errors::range0_f(crate::prelude::len(names_p3x)), env_p1x, ({
        auto names_p3xx = names_p3x;
        auto lx_p0xx = lx_p0x;
        auto clauses_p2xx = clauses_p2x;
        auto ptys_p4xx = ptys_p4x;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::types::Env>(std::tuple<crate::lower::types::Env, Nat>)>>(prism_rtl::rc([=, names_p3xx = std::move(names_p3xx), lx_p0xx = std::move(lx_p0xx), clauses_p2xx = std::move(clauses_p2xx), ptys_p4xx = std::move(ptys_p4xx)](std::tuple<crate::lower::types::Env, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto names_p3xxy = names_p3xx;
            auto lx_p0xxy = lx_p0xx;
            auto clauses_p2xxy = clauses_p2xx;
            auto ptys_p4xxy = ptys_p4xx;
            (crate::prelude::entered(crate::prelude::once_job([=, names_p3xxy = std::move(names_p3xxy), lx_p0xxy = std::move(lx_p0xxy), clauses_p2xxy = std::move(clauses_p2xxy), ptys_p4xxy = std::move(ptys_p4xxy)]() {
            return ({
                auto en_pa = p0;
                auto i_pb = p1;
                ({
                auto [rs_pc, matched_pd] = crate::prelude::or_(crate::prelude::index(names_p3xxy, i_pb), std::tuple{Text::lit(""), true});
                matched_pd
                ? prism_rtl::finished(en_pa)
                : crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0xxy, crate::lower::types::peel_f(crate::prelude::or_(crate::prelude::index(ptys_p4xxy, i_pb), crate::check::types::Ty(crate::check::types::Ty::TyErr{})))), [=](crate::lower::model::OutTy out_ty_of_f_5056) { return prism_rtl::finished(crate::lower::types::bind_f(en_pa, plain_binder_f(lx_p0xxy, crate::prelude::or_(crate::prelude::index(prism_rtl::deref(crate::prelude::or_(crate::prelude::index(clauses_p2xxy, Nat(0u)), dummy_clause_p())).params_p, i_pb), crate::lower::patterns::dummy_pat_p())), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{rs_pc}), crate::lower::types::Holding(crate::lower::types::Holding::ByRef{}), out_ty_of_f_5056}))); });
            });
            });
        })));
        });
    })));
    })), [=](crate::lower::types::Env fold_4812) {
        return ({
            auto env1_p8 = fold_4812;
            auto scrut_ix_p9 = crate::prelude::filter(crate::check::errors::range0_f(crate::prelude::len(names_p3x)), [&](const Nat& i_pe) {
                return ({
                    __label__ _done;
                    prism_rtl::Slot<bool> _v;
                    auto&& _m = crate::prelude::index(names_p3x, i_pe);
                    if (prism_rtl::is_some(_m) && std::get<1>(prism_rtl::some_of(_m))) {
                        _v.set(true);
                        goto _done;
                    }
                    {
                        _v.set(false);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
            });
            (crate::prelude::len(scrut_ix_p9) == Nat(0u)
            ? ({
            auto c_pf = crate::prelude::or_(crate::prelude::index(clauses_p2x, Nat(0u)), dummy_clause_p());
            body_f5x(std::tuple{lx_p0x, env1_p8, prism_rtl::deref(c_pf).body_p})->cycle();
        })
            : ({
            auto scrut_pg = ({
                __label__ _done;
                prism_rtl::Slot<crate::lower::model::Ex> _v;
                {
                    auto&& m5353_0 = scrut_ix_p9;
                    if (m5353_0.size() == 1u) {
                        {
                            auto&& _c1 = crate::prelude::index(m5353_0, Nat(0u));
                            if (prism_rtl::is_some(_c1)) {
                                auto&& i_pi = prism_rtl::some_of(_c1);
                                _v.set(crate::lower::model::Ex(crate::lower::model::Ex::XVar{crate::prelude::or_(crate::prelude::index(crate::prelude::each(names_p3x, [&](const std::tuple<Text, bool>& _p0) {
                                    auto&& n_pj = std::get<0>(_p0);
                                    return n_pj;
                                }), i_pi), Text::lit("arg"))}));
                                goto _done;
                            }
                        }
                    }
                }
                {
                    _v.set(crate::lower::model::Ex(crate::lower::model::Ex::XTuple{crate::prelude::each(scrut_ix_p9, [&](const Nat& i_pk) {
                        return crate::lower::model::Ex(crate::lower::model::Ex::XVar{crate::prelude::or_(crate::prelude::index(crate::prelude::each(names_p3x, [&](const std::tuple<Text, bool>& _p0) {
                            auto&& n_pl = std::get<0>(_p0);
                            return n_pl;
                        }), i_pk), Text::lit("arg"))});
                    })}));
                    goto _done;
                }
            _done:
                _v.take();
            });
            (crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(crate::prelude::len(clauses_p2x)), ({
            auto clauses_p2xx = clauses_p2x;
            auto scrut_ix_p9x = scrut_ix_p9;
            auto lx_p0xx = lx_p0x;
            auto ptys_p4xx = ptys_p4x;
            auto label_p6xx = label_p6x;
            auto body_f5xx = body_f5x;
            auto env1_p8x = env1_p8;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::XArm>(Nat)>>(prism_rtl::rc([=, clauses_p2xx = std::move(clauses_p2xx), scrut_ix_p9x = std::move(scrut_ix_p9x), lx_p0xx = std::move(lx_p0xx), ptys_p4xx = std::move(ptys_p4xx), label_p6xx = std::move(label_p6xx), body_f5xx = std::move(body_f5xx), env1_p8x = std::move(env1_p8x)](Nat p0) {
            return ({
                auto clauses_p2xxy = clauses_p2xx;
                auto scrut_ix_p9xy = scrut_ix_p9x;
                auto lx_p0xxy = lx_p0xx;
                auto ptys_p4xxy = ptys_p4xx;
                auto label_p6xxy = label_p6xx;
                auto body_f5xxy = body_f5xx;
                auto env1_p8xy = env1_p8x;
                (crate::prelude::entered(crate::prelude::once_job([=, clauses_p2xxy = std::move(clauses_p2xxy), scrut_ix_p9xy = std::move(scrut_ix_p9xy), lx_p0xxy = std::move(lx_p0xxy), ptys_p4xxy = std::move(ptys_p4xxy), label_p6xxy = std::move(label_p6xxy), body_f5xxy = std::move(body_f5xxy), env1_p8xy = std::move(env1_p8xy)]() {
                return ({
                    auto ci_pm = p0;
                    ({
                    auto c_pn = crate::prelude::or_(crate::prelude::index(clauses_p2xxy, ci_pm), dummy_clause_p());
                    (crate::prelude::call_value(crate::prelude::each_job(scrut_ix_p9xy, ({
                    auto lx_p0xxyx = lx_p0xxy;
                    auto c_pnx = c_pn;
                    auto ptys_p4xxyx = ptys_p4xxy;
                    auto label_p6xxyx = label_p6xxy;
                    auto ci_pmx = ci_pm;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::patterns::PatOut>(Nat)>>(prism_rtl::rc([=, lx_p0xxyx = std::move(lx_p0xxyx), c_pnx = std::move(c_pnx), ptys_p4xxyx = std::move(ptys_p4xxyx), label_p6xxyx = std::move(label_p6xxyx), ci_pmx = std::move(ci_pmx)](Nat p0) {
                    return ({
                        auto lx_p0xxyxy = lx_p0xxyx;
                        auto c_pnxy = c_pnx;
                        auto ptys_p4xxyxy = ptys_p4xxyx;
                        auto label_p6xxyxy = label_p6xxyx;
                        auto ci_pmxy = ci_pmx;
                        (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xxyxy = std::move(lx_p0xxyxy), c_pnxy = std::move(c_pnxy), ptys_p4xxyxy = std::move(ptys_p4xxyxy), label_p6xxyxy = std::move(label_p6xxyxy), ci_pmxy = std::move(ci_pmxy)]() {
                        return ({
                            auto i_ps = p0;
                            (prism_rtl::more(prism_rtl::rc(crate::lower::patterns::RustPat(lx_p0xxyxy, crate::prelude::or_(crate::prelude::index(prism_rtl::deref(c_pnxy).params_p, i_ps), crate::lower::patterns::dummy_pat_p()), crate::prelude::or_(crate::prelude::index(ptys_p4xxyxy, i_ps), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), crate::lower::types::Holding(crate::lower::types::Holding::ByRef{}), prism_rtl::cat(label_p6xxyxy, ci_pmxy, "_", i_ps)))));
                        });
                    })));
                    });
                })));
                })), [=](Array<crate::lower::patterns::PatOut> each_5668) {
                    return ({
                        auto pos_po = each_5668;
                        auto pa_pp = ({
                            __label__ _done;
                            prism_rtl::Slot<crate::lower::model::Pa> _v;
                            {
                                auto&& m5794_0 = pos_po;
                                if (m5794_0.size() == 1u) {
                                    {
                                        auto&& _c1 = crate::prelude::index(m5794_0, Nat(0u));
                                        if (prism_rtl::is_some(_c1)) {
                                            auto&& o_pt = prism_rtl::some_of(_c1);
                                            _v.set(prism_rtl::deref(o_pt).pa_p);
                                            goto _done;
                                        }
                                    }
                                }
                            }
                            {
                                _v.set(crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{crate::prelude::each(pos_po, [&](const crate::lower::patterns::PatOut& o_pu) { return prism_rtl::deref(o_pu).pa_p; })}));
                                goto _done;
                            }
                        _done:
                            _v.take();
                        });
                        auto conds_pq = crate::prelude::fold(pos_po, Array<crate::lower::model::Cc>{}, [&](const Array<crate::lower::model::Cc>& acc_pv, const crate::lower::patterns::PatOut& o_p10) { return crate::prelude::append(acc_pv, prism_rtl::deref(o_p10).conds_p); });
                        auto binds_pr = crate::prelude::fold(pos_po, Array<std::tuple<Text, crate::lower::types::Bn>>{}, [&](const Array<std::tuple<Text, crate::lower::types::Bn>>& acc_p11, const crate::lower::patterns::PatOut& o_p12) { return crate::prelude::append(acc_p11, prism_rtl::deref(o_p12).binds_p); });
                        (crate::prelude::call_value(body_f5xxy(std::tuple{lx_p0xxy, crate::lower::expr::bind_all_f(env1_p8xy, binds_pr), prism_rtl::deref(c_pn).body_p}), [=, pa_pp = std::move(pa_pp), conds_pq = std::move(conds_pq)](crate::lower::model::Ex body_6074) { return prism_rtl::finished(crate::lower::model::XArm{.pat_p = pa_pp, .conds_p = conds_pq, .body_p = body_6074}); }));
                    });
                }));
                });
                });
            })));
            });
        })));
        })), [=, scrut_pg = std::move(scrut_pg)](Array<crate::lower::model::XArm> each_5563) {
            return ({
                auto arms_ph = each_5563;
                (prism_rtl::finished(crate::lower::types::own_f(crate::lower::expr::arms_value_f(scrut_pg, arms_ph, prism_rtl::cat("\'", label_p6x), t_p7x))));
            });
        }));
        }));
        });
    });
}


/// `Start ClausesBody, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Ex> start_clauses_body_f(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, Array<crate::syntax::decls::FnClause> clauses_p2, Array<std::tuple<Text, bool>> names_p3, Array<crate::check::types::Ty> ptys_p4, prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::Lx, crate::lower::types::Env, crate::syntax::decls::FnBody>)> body_f5, Text label_p6, crate::lower::model::OutTy t_p7) {
    return prism_rtl::make_rc<ClausesBody>(lx_p0, env_p1, clauses_p2, names_p3, ptys_p4, body_f5, label_p6, t_p7);
}


/// let dummyClause
crate::syntax::decls::FnClause dummy_clause_p() {
    return crate::syntax::decls::FnClause{.name_p = crate::syntax::decls::DefName(crate::syntax::decls::DefName::DefOp{Text::lit(""), crate::syntax::Range{.start_p = Nat(0u), .end_p = Nat(0u)}}), .params_p = Array<crate::syntax::Pattern_>{}, .body_p = crate::syntax::decls::FnBody(crate::syntax::decls::FnBody::BodyExpr{crate::syntax::Expr{.kind_p = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EError{})), .span_p = crate::syntax::Range{.start_p = Nat(0u), .end_p = Nat(0u)}}}), .span_p = crate::syntax::Range{.start_p = Nat(0u), .end_p = Nat(0u)}};
}


/// FnBodyValue: unbounded fn Lx, Env, FnBody -> Ex
crate::lower::model::Ex fn_body_value_f(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::decls::FnBody& fn_body2) {
    if (prism_rtl::is<crate::syntax::decls::FnBody::BodyExpr>(fn_body2)) {
        auto&& x_p2 = prism_rtl::as<crate::syntax::decls::FnBody::BodyExpr>(fn_body2).a0;
        return crate::lower::types::own_f(crate::lower::expr::value_of_f(lx_p0, env_p1, x_p2));
    }
    if (prism_rtl::is<crate::syntax::decls::FnBody::BodyBlock>(fn_body2)) {
        auto&& b_p5 = prism_rtl::as<crate::syntax::decls::FnBody::BodyBlock>(fn_body2).a0;
        return crate::lower::types::own_f(crate::lower::expr::block_value_f(lx_p0, env_p1, b_p5));
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::lower::model::Ex> FnBodyValue::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& fn_body2 = this->fn_body2;
    return ({
        prism_rtl::is<crate::syntax::decls::FnBody::BodyExpr>(fn_body2) ? ({
        auto&& x_p2 = prism_rtl::as<crate::syntax::decls::FnBody::BodyExpr>(fn_body2).a0;
        ({
        auto env_p1x = env_p1;
        auto lx_p0x = lx_p0;
        auto x_p2x = x_p2;
        (crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0x, env_p1x, x_p2x), [=](crate::lower::types::Vl value_of_f_6433) { return prism_rtl::finished(crate::lower::types::own_f(value_of_f_6433)); }));
    });
    })
        : prism_rtl::is<crate::syntax::decls::FnBody::BodyBlock>(fn_body2) ? ({
        auto&& b_p5 = prism_rtl::as<crate::syntax::decls::FnBody::BodyBlock>(fn_body2).a0;
        ({
        auto b_p5x = b_p5;
        auto env_p1x = env_p1;
        auto lx_p0x = lx_p0;
        (crate::prelude::call_then(crate::lower::expr::start_block_value_f(lx_p0x, env_p1x, b_p5x), [=](crate::lower::types::Vl block_value_f_6498) { return prism_rtl::finished(crate::lower::types::own_f(block_value_f_6498)); }));
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start FnBodyValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Ex> start_fn_body_value_f(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::decls::FnBody fn_body2) {
    return prism_rtl::make_rc<FnBodyValue>(lx_p0, env_p1, fn_body2);
}


/// FnDefOf: unbounded fn Lx, Text, [FnClause], Scheme -> FnDef
crate::lower::model::FnDef fn_def_of_f(const crate::lower::Lx& lx_p0, const Text& qk_p1, const Array<crate::syntax::decls::FnClause>& clauses_p2, const crate::check::types::Scheme& sc_p3) {
    auto [ptys0_pf, res_pg] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Array<crate::check::types::Ty>, crate::check::types::Ty>> _v;
        auto&& _m = sc_p3.ty_p;
        if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
            auto&& ps_pc = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a1;
            auto&& r_pd = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a2;
            _v.set(std::tuple{ps_pc, prism_rtl::deref(prism_rtl::deref(r_pd))});
            goto _done;
        }
        {
            auto&& other_pe = _m;
            _v.set(std::tuple{Array<crate::check::types::Ty>{}, other_pe});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto ptys_p4 = crate::lower::types::has_blueprint_f(res_pg)
        ? crate::prelude::each(ptys0_pf, [&](const crate::check::types::Ty& p_ph) { return crate::lower::types::event_param_f(p_ph); })
        : ptys0_pf;
    auto pts_p5 = crate::prelude::run_to_end(crate::prelude::each_job(ptys_p4, ({
        auto lx_p0x = lx_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::OutTy>(crate::check::types::Ty)>>(prism_rtl::rc([=, lx_p0x = std::move(lx_p0x)](crate::check::types::Ty p0) {
        return ({
            auto lx_p0xy = lx_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xy = std::move(lx_p0xy)]() {
            return ({
                auto p_pi = p0;
                (prism_rtl::more(prism_rtl::rc(crate::lower::types::OutTyOf(lx_p0xy, crate::lower::types::peel_f(p_pi)))));
            });
        })));
        });
    })));
    })));
    auto names_p6 = param_names_f(lx_p0, clauses_p2, pts_p5);
    auto body_p7 = clauses_body_f(lx_p0, crate::lower::types::empty_env_p(), clauses_p2, names_p6, ptys_p4, static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::Lx, crate::lower::types::Env, crate::syntax::decls::FnBody>)>>(prism_rtl::rc([&](std::tuple<crate::lower::Lx, crate::lower::types::Env, crate::syntax::decls::FnBody> _p0) {
        auto&& a0 = std::get<0>(_p0);
        auto&& a1 = std::get<1>(_p0);
        auto&& a2 = std::get<2>(_p0);
        return crate::prelude::entered(start_fn_body_value_f(a0, a1, a2));
    })), Text::lit("c"), crate::lower::types::out_ty_of_f(lx_p0, crate::lower::types::peel_f(res_pg)));
    auto params_p8 = crate::prelude::each(crate::check::errors::range0_f(crate::prelude::len(pts_p5)), [&](const Nat& i_pj) {
        return std::tuple{crate::prelude::or_(crate::prelude::index(crate::prelude::each(names_p6, [&](const std::tuple<Text, bool>& _p0) {
            auto&& n_pk = std::get<0>(_p0);
            return n_pk;
        }), i_pj), Text::lit("arg")), crate::lower::model::OutTy(crate::lower::model::OutTy::OutRef{prism_rtl::rc(crate::prelude::or_(crate::prelude::index(pts_p5, i_pj), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})))})};
    });
    auto ret_p9 = crate::lower::types::out_ty_of_f(lx_p0, crate::lower::types::peel_f(res_pg));
    auto used_pa = crate::prelude::fold(crate::prelude::push(pts_p5, ret_p9), Array<Text>{}, [&](const Array<Text>& acc_pl, const crate::lower::model::OutTy& t_pm) { return crate::check::types::union_texts_f(acc_pl, ty_params_in_f(t_pm)); });
    auto generics_pb = crate::prelude::filter(scheme_generics_f(lx_p0, sc_p3), [&](const std::tuple<Text, Array<Text>>& _p0) {
        auto&& g_pn = std::get<0>(_p0);
        return crate::check::types::has_text_f(used_pa, g_pn);
    });
    return crate::lower::model::FnDef{.name_p = crate::prelude::or_(crate::prelude::get(lx_p0.rs_names_p, qk_p1), crate::lower::snake_f(crate::check::types::bare_name_f(qk_p1))), .generics_p = generics_pb, .params_p = params_p8, .ret_p = ret_p9, .body_p = body_p7, .doc_p = signature_text_f(lx_p0, qk_p1), .public_p = true};
}


prism_rtl::Turn<crate::lower::model::FnDef> FnDefOf::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& qk_p1 = this->qk_p1;
    const auto& clauses_p2 = this->clauses_p2;
    const auto& sc_p3 = this->sc_p3;
    auto [ptys0_pf, res_pg] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Array<crate::check::types::Ty>, crate::check::types::Ty>> _v;
        auto&& _m = prism_rtl::deref(sc_p3).ty_p;
        if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
            auto&& ps_pc = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a1;
            auto&& r_pd = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a2;
            _v.set(std::tuple{ps_pc, prism_rtl::deref(prism_rtl::deref(r_pd))});
            goto _done;
        }
        {
            auto&& other_pe = _m;
            _v.set(std::tuple{Array<crate::check::types::Ty>{}, other_pe});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto ptys_p4 = crate::lower::types::has_blueprint_f(res_pg)
        ? crate::prelude::each(ptys0_pf, [&](const crate::check::types::Ty& p_ph) { return crate::lower::types::event_param_f(p_ph); })
        : ptys0_pf;
    auto clauses_p2x = clauses_p2;
    auto lx_p0x = lx_p0;
    auto qk_p1x = qk_p1;
    auto sc_p3x = sc_p3;
    return crate::prelude::call_value(crate::prelude::each_job(ptys_p4, ({
        auto lx_p0xx = lx_p0x;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::OutTy>(crate::check::types::Ty)>>(prism_rtl::rc([=, lx_p0xx = std::move(lx_p0xx)](crate::check::types::Ty p0) {
        return ({
            auto lx_p0xxy = lx_p0xx;
            (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xxy = std::move(lx_p0xxy)]() {
            return ({
                auto p_pi = p0;
                (prism_rtl::more(prism_rtl::rc(crate::lower::types::OutTyOf(lx_p0xxy, crate::lower::types::peel_f(p_pi)))));
            });
        })));
        });
    })));
    })), [=](Array<crate::lower::model::OutTy> each_7055) {
        return ({
            auto pts_p5 = each_7055;
            (crate::prelude::call_then(start_param_names_f(lx_p0x, clauses_p2x, pts_p5), [=](Array<std::tuple<Text, bool>> param_names_f_7108) {
            return ({
                auto names_p6 = param_names_f_7108;
                (crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0x, crate::lower::types::peel_f(res_pg)), [=, names_p6 = std::move(names_p6)](crate::lower::model::OutTy out_ty_of_f_7218) {
                return crate::prelude::call_then(start_clauses_body_f(lx_p0x, crate::lower::types::empty_env_p(), clauses_p2x, names_p6, ptys_p4, static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::Lx, crate::lower::types::Env, crate::syntax::decls::FnBody>)>>(prism_rtl::rc([&](std::tuple<crate::lower::Lx, crate::lower::types::Env, crate::syntax::decls::FnBody> _p0) {
                    auto&& a0 = std::get<0>(_p0);
                    auto&& a1 = std::get<1>(_p0);
                    auto&& a2 = std::get<2>(_p0);
                    return crate::prelude::entered(start_fn_body_value_f(a0, a1, a2));
                })), Text::lit("c"), out_ty_of_f_7218), [=](crate::lower::model::Ex clauses_body_f_7151) {
                    return ({
                        auto body_p7 = clauses_body_f_7151;
                        auto params_p8 = crate::prelude::each(crate::check::errors::range0_f(crate::prelude::len(pts_p5)), [&](const Nat& i_pj) {
                            return std::tuple{crate::prelude::or_(crate::prelude::index(crate::prelude::each(names_p6, [&](const std::tuple<Text, bool>& _p0) {
                                auto&& n_pk = std::get<0>(_p0);
                                return n_pk;
                            }), i_pj), Text::lit("arg")), crate::lower::model::OutTy(crate::lower::model::OutTy::OutRef{prism_rtl::rc(crate::prelude::or_(crate::prelude::index(pts_p5, i_pj), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})))})};
                        });
                        (crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0x, crate::lower::types::peel_f(res_pg)), [=, body_p7 = std::move(body_p7), params_p8 = std::move(params_p8)](crate::lower::model::OutTy out_ty_of_f_7386) {
                        return ({
                            auto ret_p9 = out_ty_of_f_7386;
                            auto used_pa = crate::prelude::fold(crate::prelude::push(pts_p5, ret_p9), Array<Text>{}, [&](const Array<Text>& acc_pl, const crate::lower::model::OutTy& t_pm) { return crate::check::types::union_texts_f(acc_pl, ty_params_in_f(t_pm)); });
                            auto generics_pb = crate::prelude::filter(scheme_generics_f(lx_p0x, sc_p3x), [&](const std::tuple<Text, Array<Text>>& _p0) {
                                auto&& g_pn = std::get<0>(_p0);
                                return crate::check::types::has_text_f(used_pa, g_pn);
                            });
                            (prism_rtl::finished(crate::lower::model::FnDef{.name_p = crate::prelude::or_(crate::prelude::get(prism_rtl::deref(lx_p0x).rs_names_p, qk_p1x), crate::lower::snake_f(crate::check::types::bare_name_f(qk_p1x))), .generics_p = generics_pb, .params_p = params_p8, .ret_p = ret_p9, .body_p = body_p7, .doc_p = signature_text_f(lx_p0x, qk_p1x), .public_p = true}));
                        });
                    }));
                    });
                });
            }));
            });
        }));
        });
    });
}


/// `Start FnDefOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::FnDef> start_fn_def_of_f(crate::lower::Lx lx_p0, Text qk_p1, Array<crate::syntax::decls::FnClause> clauses_p2, crate::check::types::Scheme sc_p3) {
    return prism_rtl::make_rc<FnDefOf>(lx_p0, qk_p1, clauses_p2, sc_p3);
}


/// TyParamsIn: fn OutTy -> [Text]
Array<Text> ty_params_in_f(const crate::lower::model::OutTy& t_p0) {
    if (prism_rtl::is<crate::lower::model::OutTy::OutGen>(t_p0)) {
        auto&& n_p1 = prism_rtl::as<crate::lower::model::OutTy::OutGen>(t_p0).a0;
        return Array(std::vector{n_p1});
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t_p0)) {
        auto&& ts_p2 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p0).a1;
        return crate::prelude::fold(ts_p2, Array<Text>{}, [&](const Array<Text>& acc_p3, const crate::lower::model::OutTy& x_p4) { return crate::check::types::union_texts_f(acc_p3, ty_params_in_f(x_p4)); });
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutTuple>(t_p0)) {
        auto&& ts_p5 = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(t_p0).a0;
        return crate::prelude::fold(ts_p5, Array<Text>{}, [&](const Array<Text>& acc_p6, const crate::lower::model::OutTy& x_p7) { return crate::check::types::union_texts_f(acc_p6, ty_params_in_f(x_p7)); });
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutFn>(t_p0)) {
        auto&& ts_p8 = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t_p0).a0;
        auto&& r_p9 = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t_p0).a1;
        return crate::prelude::fold(ts_p8, ty_params_in_f(prism_rtl::deref(prism_rtl::deref(r_p9))), [&](const Array<Text>& acc_pa, const crate::lower::model::OutTy& x_pb) { return crate::check::types::union_texts_f(acc_pa, ty_params_in_f(x_pb)); });
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(t_p0)) {
        auto&& a_pc = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(t_p0).a0;
        auto&& r_pd = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(t_p0).a1;
        return crate::check::types::union_texts_f(ty_params_in_f(prism_rtl::deref(prism_rtl::deref(a_pc))), ty_params_in_f(prism_rtl::deref(prism_rtl::deref(r_pd))));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutMap>(t_p0)) {
        auto&& k_pe = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t_p0).a0;
        auto&& v_pf = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t_p0).a1;
        return crate::check::types::union_texts_f(ty_params_in_f(prism_rtl::deref(prism_rtl::deref(k_pe))), ty_params_in_f(prism_rtl::deref(prism_rtl::deref(v_pf))));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutOpt>(t_p0)) {
        auto&& x_pg = prism_rtl::as<crate::lower::model::OutTy::OutOpt>(t_p0).a0;
        return ty_params_in_f(prism_rtl::deref(prism_rtl::deref(x_pg)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutRes>(t_p0)) {
        auto&& x_ph = prism_rtl::as<crate::lower::model::OutTy::OutRes>(t_p0).a0;
        return ty_params_in_f(prism_rtl::deref(prism_rtl::deref(x_ph)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutArray>(t_p0)) {
        auto&& x_pi = prism_rtl::as<crate::lower::model::OutTy::OutArray>(t_p0).a0;
        return ty_params_in_f(prism_rtl::deref(prism_rtl::deref(x_pi)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutJob>(t_p0)) {
        auto&& x_pj = prism_rtl::as<crate::lower::model::OutTy::OutJob>(t_p0).a0;
        return ty_params_in_f(prism_rtl::deref(prism_rtl::deref(x_pj)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutEvent>(t_p0)) {
        auto&& x_pk = prism_rtl::as<crate::lower::model::OutTy::OutEvent>(t_p0).a0;
        return ty_params_in_f(prism_rtl::deref(prism_rtl::deref(x_pk)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutDyn>(t_p0)) {
        auto&& x_pl = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(t_p0).a0;
        return ty_params_in_f(prism_rtl::deref(prism_rtl::deref(x_pl)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutRc>(t_p0)) {
        auto&& x_pm = prism_rtl::as<crate::lower::model::OutTy::OutRc>(t_p0).a0;
        return ty_params_in_f(prism_rtl::deref(prism_rtl::deref(x_pm)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutRef>(t_p0)) {
        auto&& x_pn = prism_rtl::as<crate::lower::model::OutTy::OutRef>(t_p0).a0;
        return ty_params_in_f(prism_rtl::deref(prism_rtl::deref(x_pn)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutHold>(t_p0)) {
        auto&& x_po = prism_rtl::as<crate::lower::model::OutTy::OutHold>(t_p0).a0;
        return ty_params_in_f(prism_rtl::deref(prism_rtl::deref(x_po)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutCell>(t_p0)) {
        auto&& x_pp = prism_rtl::as<crate::lower::model::OutTy::OutCell>(t_p0).a0;
        return ty_params_in_f(prism_rtl::deref(prism_rtl::deref(x_pp)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutLive>(t_p0)) {
        auto&& x_pq = prism_rtl::as<crate::lower::model::OutTy::OutLive>(t_p0).a0;
        return ty_params_in_f(prism_rtl::deref(prism_rtl::deref(x_pq)));
    }
    {
        return Array<Text>{};
    }
}


/// SignatureText: fn Lx, Text -> Text
Text signature_text_f(const crate::lower::Lx& lx_p0, const Text& qk_p1) {
    auto&& _m = crate::prelude::get(prism_rtl::deref(lx_p0.g_p).vals_p, qk_p1);
    if (prism_rtl::is_some(_m)) {
        auto&& v_p2 = prism_rtl::some_of(_m);
        auto&& _m = crate::prelude::index(prism_rtl::deref(lx_p0.g_p).srcs_p, prism_rtl::deref(v_p2).file_p);
        if (prism_rtl::is_some(_m)) {
            auto&& src_p3 = prism_rtl::some_of(_m);
            return crate::syntax::lexer::chars::trim_f(crate::check::errors::span_text_f(src_p3, prism_rtl::deref(v_p2).span_p));
        }
        if (prism_rtl::is_none(_m)) {
            return crate::check::types::bare_name_f(qk_p1);
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is_none(_m)) {
        return crate::check::types::bare_name_f(qk_p1);
    }
    prism_rtl::unreachable("no arm matched");
}


/// DefinitionText: fn Lx, Text -> Text
Text definition_text_f(const crate::lower::Lx& lx_p0, const Text& qk_p1) {
    auto spans_p2 = crate::prelude::fold(prism_rtl::deref(lx_p0.g_p).defs_p, Array<std::tuple<Nat, crate::syntax::Range>>{}, [&](const Array<std::tuple<Nat, crate::syntax::Range>>& acc_p4, const crate::check::env::Def& d_p5) {
        return prism_rtl::deref(d_p5).qk_p == qk_p1
            ? crate::prelude::push(acc_p4, std::tuple{prism_rtl::deref(d_p5).file_p, prism_rtl::deref(d_p5).span_p})
            : acc_p4;
    });
    auto sig_p3 = ({
        __label__ _done;
        prism_rtl::Slot<Array<std::tuple<Nat, crate::syntax::Range>>> _v;
        auto&& _m = crate::prelude::get(prism_rtl::deref(lx_p0.g_p).vals_p, qk_p1);
        if (prism_rtl::is_some(_m)) {
            auto&& v_p6 = prism_rtl::some_of(_m);
            _v.set(prism_rtl::deref(prism_rtl::deref(v_p6).span_p).start_p < crate::prelude::or_(crate::prelude::index(crate::prelude::each(spans_p2, [&](const std::tuple<Nat, crate::syntax::Range>& _p0) {
                auto&& r_p7 = std::get<1>(_p0);
                return prism_rtl::deref(r_p7).start_p;
            }), Nat(0u)), Nat(0u))
                ? Array(std::vector{std::tuple{prism_rtl::deref(v_p6).file_p, prism_rtl::deref(v_p6).span_p}})
                : Array<std::tuple<Nat, crate::syntax::Range>>{});
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Array<std::tuple<Nat, crate::syntax::Range>>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return crate::syntax::lexer::chars::join_f(crate::prelude::each(crate::prelude::append(sig_p3, spans_p2), [&](const std::tuple<Nat, crate::syntax::Range>& _p0) {
        auto&& f_p8 = std::get<0>(_p0);
        auto&& r_p9 = std::get<1>(_p0);
        return src_text_f(lx_p0, f_p8, r_p9);
    }), Text::lit("\n"));
}


/// SrcText: fn Lx, Nat, Range -> Text
Text src_text_f(const crate::lower::Lx& lx_p0, const Nat& f_p1, const crate::syntax::Range& r_p2) {
    auto&& _m = crate::prelude::index(prism_rtl::deref(lx_p0.g_p).srcs_p, f_p1);
    if (prism_rtl::is_some(_m)) {
        auto&& src_p3 = prism_rtl::some_of(_m);
        return drop_trailing_comments_f(crate::check::errors::span_text_f(src_p3, r_p2));
    }
    if (prism_rtl::is_none(_m)) {
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}


/// DropTrailingComments: fn Text -> Text
Text drop_trailing_comments_f(const Text& t_p0) {
    auto lines_p1 = crate::prelude::split_on(t_p0, Text::lit("\n"));
    auto keep_p2 = crate::prelude::fold(crate::check::errors::range0_f(crate::prelude::len(lines_p1)), Nat(0u), [&](const Nat& k_p3, const Nat& i_p4) {
        return is_code_line_f(crate::prelude::or_(crate::prelude::index(lines_p1, i_p4), Text::lit("")))
            ? i_p4 + Nat(1u)
            : k_p3;
    });
    return crate::syntax::lexer::chars::trim_end_f(crate::syntax::lexer::chars::join_f(crate::prelude::take(lines_p1, keep_p2), Text::lit("\n")));
}


/// IsCodeLine: fn Text -> Bool
bool is_code_line_f(const Text& l_p0) {
    auto s_p1 = crate::syntax::lexer::chars::trim_f(l_p0);
    return (s_p1 != Text::lit("")) && (!crate::syntax::lexer::chars::has_prefix_f(s_p1, Text::lit("#")));
}


/// LetGetter: unbounded fn Lx, Text, LetDecl -> FnDef
crate::lower::model::FnDef let_getter_f(const crate::lower::Lx& lx_p0, const Text& qk_p1, const crate::syntax::decls::LetDecl& l_p2) {
    auto t_p3 = crate::lower::types::out_ty_of_f(lx_p0, crate::lower::types::peel_f(crate::lower::type_at_f(lx_p0, prism_rtl::deref(l_p2.value_p).span_p)));
    auto v_p4 = crate::lower::expr::value_of_f(lx_p0, crate::lower::types::empty_env_p(), l_p2.value_p);
    return crate::lower::model::FnDef{.name_p = crate::prelude::or_(crate::prelude::get(lx_p0.rs_names_p, qk_p1), crate::lower::snake_f(crate::check::types::bare_name_f(qk_p1))), .generics_p = Array<std::tuple<Text, Array<Text>>>{}, .params_p = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .ret_p = t_p3, .body_p = crate::lower::types::own_f(v_p4), .doc_p = prism_rtl::cat("let ", crate::check::types::bare_name_f(qk_p1)), .public_p = true};
}


prism_rtl::Turn<crate::lower::model::FnDef> LetGetter::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& qk_p1 = this->qk_p1;
    const auto& l_p2 = this->l_p2;
    auto l_p2x = l_p2;
    auto lx_p0x = lx_p0;
    auto qk_p1x = qk_p1;
    return crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0x, crate::lower::types::peel_f(crate::lower::type_at_f(lx_p0x, prism_rtl::deref(prism_rtl::deref(l_p2x).value_p).span_p))), [=](crate::lower::model::OutTy out_ty_of_f_10237) {
        return ({
            auto t_p3 = out_ty_of_f_10237;
            (crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p0x, crate::lower::types::empty_env_p(), prism_rtl::deref(l_p2x).value_p), [=, t_p3 = std::move(t_p3)](crate::lower::types::Vl value_of_f_10294) {
            return ({
                auto v_p4 = value_of_f_10294;
                (prism_rtl::finished(crate::lower::model::FnDef{.name_p = crate::prelude::or_(crate::prelude::get(prism_rtl::deref(lx_p0x).rs_names_p, qk_p1x), crate::lower::snake_f(crate::check::types::bare_name_f(qk_p1x))), .generics_p = Array<std::tuple<Text, Array<Text>>>{}, .params_p = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .ret_p = t_p3, .body_p = crate::lower::types::own_f(v_p4), .doc_p = prism_rtl::cat("let ", crate::check::types::bare_name_f(qk_p1x)), .public_p = true}));
            });
        }));
        });
    });
}


/// `Start LetGetter, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::FnDef> start_let_getter_f(crate::lower::Lx lx_p0, Text qk_p1, crate::syntax::decls::LetDecl l_p2) {
    return prism_rtl::make_rc<LetGetter>(lx_p0, qk_p1, l_p2);
}


/// HasOwnShow: fn Lx, Text -> Bool
bool has_own_show_f(const crate::lower::Lx& lx_p0, const Text& tn_p1) {
    return crate::prelude::fold(crate::prelude::or_(crate::prelude::get(prism_rtl::deref(lx_p0.g_p).impls_p, Text::lit("Prelude.Show")), Array<crate::check::env::ImplInfo>{}), false, [&](const bool& f_p2, const crate::check::env::ImplInfo& im_p3) { return prism_rtl::deref(f_p2) || ((!prism_rtl::deref(im_p3).derived_p) && (head_name_f(prism_rtl::deref(im_p3).head_p) == tn_p1)); });
}


/// HeadName: fn Ty -> Text
Text head_name_f(const crate::check::types::Ty& ty0) {
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(ty0)) {
        auto&& n_p0 = prism_rtl::as<crate::check::types::Ty::TyCon>(ty0).a0;
        return n_p0;
    }
    {
        auto&& other_p1 = ty0;
        return Text::lit("");
    }
}


/// SelfIn: unbounded fn Ty, Text -> Ty
crate::check::types::Ty self_in_f(const crate::check::types::Ty& t_p0, const Text& param_p1) {
    return crate::lower::expr::instantiated_f(t_p0, Array(std::vector{param_p1}), Array(std::vector{crate::check::types::Ty(crate::check::types::Ty::TyCon{Text::lit("\000Self"sv), Array<crate::check::types::Ty>{}})}));
}


prism_rtl::Turn<crate::check::types::Ty> SelfIn::cycle() const {
    const auto& t_p0 = this->t_p0;
    const auto& param_p1 = this->param_p1;
    return prism_rtl::more(prism_rtl::rc(crate::lower::expr::Instantiated(t_p0, Array(std::vector{param_p1}), Array(std::vector{crate::check::types::Ty(crate::check::types::Ty::TyCon{Text::lit("\000Self"sv), Array<crate::check::types::Ty>{}})}))));
}


/// `Start SelfIn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::Ty> start_self_in_f(crate::check::types::Ty t_p0, Text param_p1) {
    return prism_rtl::make_rc<SelfIn>(t_p0, param_p1);
}


/// TraitDefOf: unbounded fn Lx, TraitInfo -> TraitDef
crate::lower::model::TraitDef trait_def_of_f(const crate::lower::Lx& lx0_p0, const crate::check::env::TraitInfo& tr_p1) {
    auto lx_p2 = crate::lower::program::in_module_f(lx0_p0, tr_p1.file_p, tr_p1.home_p);
    auto methods_p3 = crate::prelude::run_to_end(crate::prelude::each_job(tr_p1.methods_p, ({
        auto lx_p2x = lx_p2;
        auto tr_p1x = tr_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::FnDef>(Text)>>(prism_rtl::rc([=, lx_p2x = std::move(lx_p2x), tr_p1x = std::move(tr_p1x)](Text p0) {
        return ({
            auto lx_p2xy = lx_p2x;
            auto tr_p1xy = tr_p1x;
            (crate::prelude::entered(crate::prelude::once_job([=, lx_p2xy = std::move(lx_p2xy), tr_p1xy = std::move(tr_p1xy)]() {
            return ({
                auto mq_p4 = p0;
                ({
                auto v_p5 = crate::prelude::or_(crate::prelude::get(prism_rtl::deref(prism_rtl::deref(lx_p2xy).g_p).vals_p, mq_p4), crate::check::env::builtin_f(mq_p4, crate::check::types::schemes::mono_f(crate::check::types::Ty(crate::check::types::Ty::TyErr{}))));
                auto sc_p6 = ({
                    crate::check::types::Scheme this_ = prism_rtl::deref(v_p5).scheme_p;
                    this_.ty_p = self_in_f(this_.ty_p, prism_rtl::deref(tr_p1xy).param_p);
                    this_.qs_p = crate::prelude::filter(this_.qs_p, [&](const Text& q_pa) { return q_pa != prism_rtl::deref(tr_p1xy).param_p; });
                    this_.bounds_p = crate::prelude::filter(this_.bounds_p, [&](const std::tuple<Text, Text>& _p0) {
                        auto&& q_pb = std::get<0>(_p0);
                        return q_pb != prism_rtl::deref(tr_p1xy).param_p;
                    });
                    (std::move(this_));
                });
                auto default_qk_p7 = crate::prelude::fold(prism_rtl::deref(tr_p1xy).defaults_p, Text::lit(""), [&](const Text& f_pc, const Text& dq_pd) {
                    return crate::check::types::bare_name_f(dq_pd) == crate::check::types::bare_name_f(mq_p4)
                        ? dq_pd
                        : f_pc;
                });
                auto clauses_p8 = default_qk_p7 == Text::lit("")
                    ? Array<crate::syntax::decls::FnClause>{}
                    : default_clauses_f(prism_rtl::deref(lx_p2xy).g_p, default_qk_p7);
                (crate::prelude::call_then(start_fn_def_of_f(lx_p2xy, mq_p4, crate::prelude::len(clauses_p8) == Nat(0u)
                ? Array(std::vector{dummy_clause_p()})
                : clauses_p8, sc_p6), [=](crate::lower::model::FnDef fn_def_of_f_11831) {
                return ({
                    auto fd_p9 = fn_def_of_f_11831;
                    (prism_rtl::finished(({
                    crate::lower::model::FnDef this_ = fd_p9;
                    this_.public_p = crate::prelude::len(clauses_p8) > Nat(0u);
                    (std::move(this_));
                })));
                });
            }));
            });
            });
        })));
        });
    })));
    })));
    return crate::lower::model::TraitDef{.name_p = crate::lower::camel_f(crate::check::types::bare_name_f(tr_p1.name_p)), .methods_p = methods_p3, .defaults_p = tr_p1.defaults_p, .doc_p = crate::lower::program::type_doc_f(lx_p2, crate::check::env::TyInfo{.name_p = tr_p1.name_p, .home_p = tr_p1.home_p, .params_p = Array<Text>{}, .body_p = crate::check::env::TyBody(crate::check::env::TyBody::BOpaque{}), .derives_p = Array<Text>{}, .file_p = tr_p1.file_p, .span_p = tr_p1.span_p})};
}


prism_rtl::Turn<crate::lower::model::TraitDef> TraitDefOf::cycle() const {
    const auto& lx0_p0 = this->lx0_p0;
    const auto& tr_p1 = this->tr_p1;
    auto lx_p2 = crate::lower::program::in_module_f(lx0_p0, prism_rtl::deref(tr_p1).file_p, prism_rtl::deref(tr_p1).home_p);
    auto tr_p1x = tr_p1;
    return crate::prelude::call_value(crate::prelude::each_job(prism_rtl::deref(tr_p1x).methods_p, ({
        auto lx_p2x = lx_p2;
        auto tr_p1xx = tr_p1x;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::FnDef>(Text)>>(prism_rtl::rc([=, lx_p2x = std::move(lx_p2x), tr_p1xx = std::move(tr_p1xx)](Text p0) {
        return ({
            auto lx_p2xy = lx_p2x;
            auto tr_p1xxy = tr_p1xx;
            (crate::prelude::entered(crate::prelude::once_job([=, lx_p2xy = std::move(lx_p2xy), tr_p1xxy = std::move(tr_p1xxy)]() {
            return ({
                auto mq_p4 = p0;
                ({
                auto v_p5 = crate::prelude::or_(crate::prelude::get(prism_rtl::deref(prism_rtl::deref(lx_p2xy).g_p).vals_p, mq_p4), crate::check::env::builtin_f(mq_p4, crate::check::types::schemes::mono_f(crate::check::types::Ty(crate::check::types::Ty::TyErr{}))));
                auto sc_p6 = ({
                    crate::check::types::Scheme this_ = prism_rtl::deref(v_p5).scheme_p;
                    this_.ty_p = self_in_f(this_.ty_p, prism_rtl::deref(tr_p1xxy).param_p);
                    this_.qs_p = crate::prelude::filter(this_.qs_p, [&](const Text& q_pa) { return q_pa != prism_rtl::deref(tr_p1xxy).param_p; });
                    this_.bounds_p = crate::prelude::filter(this_.bounds_p, [&](const std::tuple<Text, Text>& _p0) {
                        auto&& q_pb = std::get<0>(_p0);
                        return q_pb != prism_rtl::deref(tr_p1xxy).param_p;
                    });
                    (std::move(this_));
                });
                auto default_qk_p7 = crate::prelude::fold(prism_rtl::deref(tr_p1xxy).defaults_p, Text::lit(""), [&](const Text& f_pc, const Text& dq_pd) {
                    return crate::check::types::bare_name_f(dq_pd) == crate::check::types::bare_name_f(mq_p4)
                        ? dq_pd
                        : f_pc;
                });
                auto clauses_p8 = default_qk_p7 == Text::lit("")
                    ? Array<crate::syntax::decls::FnClause>{}
                    : default_clauses_f(prism_rtl::deref(lx_p2xy).g_p, default_qk_p7);
                (crate::prelude::call_then(start_fn_def_of_f(lx_p2xy, mq_p4, crate::prelude::len(clauses_p8) == Nat(0u)
                ? Array(std::vector{dummy_clause_p()})
                : clauses_p8, sc_p6), [=](crate::lower::model::FnDef fn_def_of_f_11831) {
                return ({
                    auto fd_p9 = fn_def_of_f_11831;
                    (prism_rtl::finished(({
                    crate::lower::model::FnDef this_ = fd_p9;
                    this_.public_p = crate::prelude::len(clauses_p8) > Nat(0u);
                    (std::move(this_));
                })));
                });
            }));
            });
            });
        })));
        });
    })));
    })), [=](Array<crate::lower::model::FnDef> each_11339) {
        return ({
            auto methods_p3 = each_11339;
            (prism_rtl::finished(crate::lower::model::TraitDef{.name_p = crate::lower::camel_f(crate::check::types::bare_name_f(prism_rtl::deref(tr_p1x).name_p)), .methods_p = methods_p3, .defaults_p = prism_rtl::deref(tr_p1x).defaults_p, .doc_p = crate::lower::program::type_doc_f(lx_p2, crate::check::env::TyInfo{.name_p = prism_rtl::deref(tr_p1x).name_p, .home_p = prism_rtl::deref(tr_p1x).home_p, .params_p = Array<Text>{}, .body_p = crate::check::env::TyBody(crate::check::env::TyBody::BOpaque{}), .derives_p = Array<Text>{}, .file_p = prism_rtl::deref(tr_p1x).file_p, .span_p = prism_rtl::deref(tr_p1x).span_p})}));
        });
    });
}


/// `Start TraitDefOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::TraitDef> start_trait_def_of_f(crate::lower::Lx lx0_p0, crate::check::env::TraitInfo tr_p1) {
    return prism_rtl::make_rc<TraitDefOf>(lx0_p0, tr_p1);
}


/// DefaultClauses: fn G, Text -> [FnClause]
Array<crate::syntax::decls::FnClause> default_clauses_f(const crate::check::env::G& g_p0, const Text& qk_p1) {
    return crate::prelude::fold(g_p0.defs_p, Array<crate::syntax::decls::FnClause>{}, [&](const Array<crate::syntax::decls::FnClause>& acc_p2, const crate::check::env::Def& d_p3) { return prism_rtl::deref(d_p3).qk_p == qk_p1 ? default_of_f(d_p3, acc_p2) : acc_p2; });
}


/// DefaultOf: fn Def, [FnClause] -> [FnClause]
Array<crate::syntax::decls::FnClause> default_of_f(const crate::check::env::Def& d_p0, const Array<crate::syntax::decls::FnClause>& other_p1) {
    auto&& _m = d_p0.body_p;
    if (prism_rtl::is<crate::check::env::DefBody::DbDefault>(_m)) {
        auto&& cs_p2 = prism_rtl::as<crate::check::env::DefBody::DbDefault>(_m).a0;
        return cs_p2;
    }
    {
        return other_p1;
    }
}


/// ImplDefOf: unbounded fn Lx, ImplInfo -> ImplDef
crate::lower::model::ImplDef impl_def_of_f(const crate::lower::Lx& lx_p0, const crate::check::env::ImplInfo& im_p1) {
    auto tr_p2 = crate::prelude::or_(crate::prelude::get(prism_rtl::deref(lx_p0.g_p).traits_p, im_p1.cls_p), crate::lower::expr::dummy_trait_info_p());
    auto head_p3 = crate::lower::types::out_ty_of_f(lx_p0, im_p1.head_p);
    auto defs_p4 = crate::prelude::filter(prism_rtl::deref(lx_p0.g_p).defs_p, [&](const crate::check::env::Def& d_p7) { return is_method_of_f(d_p7, im_p1); });
    auto methods_p5 = crate::prelude::run_to_end(crate::prelude::each_job(defs_p4, ({
        auto tr_p2x = tr_p2;
        auto lx_p0x = lx_p0;
        auto im_p1x = im_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::FnDef>(crate::check::env::Def)>>(prism_rtl::rc([=, tr_p2x = std::move(tr_p2x), lx_p0x = std::move(lx_p0x), im_p1x = std::move(im_p1x)](crate::check::env::Def p0) {
        return ({
            auto tr_p2xy = tr_p2x;
            auto lx_p0xy = lx_p0x;
            auto im_p1xy = im_p1x;
            (crate::prelude::entered(crate::prelude::once_job([=, tr_p2xy = std::move(tr_p2xy), lx_p0xy = std::move(lx_p0xy), im_p1xy = std::move(im_p1xy)]() {
            return ({
                auto d_p8 = p0;
                ({
                auto mq_p9 = crate::prelude::fold(prism_rtl::deref(tr_p2xy).methods_p, Text::lit(""), [&](const Text& found_pd, const Text& q_pe) {
                    return crate::check::types::bare_name_f(q_pe) == prism_rtl::deref(d_p8).name_p
                        ? q_pe
                        : found_pd;
                });
                auto v_pa = crate::prelude::or_(crate::prelude::get(prism_rtl::deref(prism_rtl::deref(lx_p0xy).g_p).vals_p, mq_p9), crate::check::env::builtin_f(mq_p9, crate::check::types::schemes::mono_f(crate::check::types::Ty(crate::check::types::Ty::TyErr{}))));
                auto sc_pb = ({
                    crate::check::types::Scheme this_ = prism_rtl::deref(v_pa).scheme_p;
                    this_.ty_p = crate::lower::expr::instantiated_f(this_.ty_p, Array(std::vector{prism_rtl::deref(tr_p2xy).param_p}), Array(std::vector{prism_rtl::deref(im_p1xy).head_p}));
                    this_.qs_p = crate::prelude::filter(this_.qs_p, [&](const Text& q_pf) { return q_pf != prism_rtl::deref(tr_p2xy).param_p; });
                    this_.bounds_p = crate::prelude::filter(this_.bounds_p, [&](const std::tuple<Text, Text>& _p0) {
                        auto&& q_pg = std::get<0>(_p0);
                        return q_pg != prism_rtl::deref(tr_p2xy).param_p;
                    });
                    (std::move(this_));
                });
                (crate::prelude::call_then(start_fn_def_of_f(lx_p0xy, mq_p9, method_clauses_f(d_p8), sc_pb), [=](crate::lower::model::FnDef fn_def_of_f_13164) {
                return ({
                    auto fd_pc = fn_def_of_f_13164;
                    (crate::syntax::lexer::chars::has_prefix_f(prism_rtl::deref(im_p1xy).cls_p, Text::lit("Prelude."))
                    ? prism_rtl::finished(renamed_f(fd_pc, prism_rtl::cat(crate::lower::snake_f(prism_rtl::deref(d_p8).name_p), "_", crate::lower::snake_f(crate::check::types::bare_name_f(head_name_f(prism_rtl::deref(im_p1xy).head_p))))))
                    : prism_rtl::finished(fd_pc));
                });
            }));
            });
            });
        })));
        });
    })));
    })));
    auto generics_p6 = crate::prelude::run_to_end(crate::prelude::each_job(im_p1.qs_p, ({
        auto lx_p0x = lx_p0;
        auto im_p1x = im_p1;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, Array<Text>>>(Text)>>(prism_rtl::rc([=, lx_p0x = std::move(lx_p0x), im_p1x = std::move(im_p1x)](Text p0) {
        return ({
            auto lx_p0xy = lx_p0x;
            auto im_p1xy = im_p1x;
            (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xy = std::move(lx_p0xy), im_p1xy = std::move(im_p1xy)]() {
            return ({
                auto q_ph = p0;
                (crate::prelude::call_then(start_impl_bounds_f(lx_p0xy, im_p1xy, q_ph), [=](Array<Text> impl_bounds_f_13447) { return prism_rtl::finished(std::tuple{crate::lower::camel_f(q_ph), impl_bounds_f_13447}); }));
            });
        })));
        });
    }));
    })));
    return crate::lower::model::ImplDef{.cls_p = im_p1.cls_p, .tr_p = crate::lower::path_in_f(lx_p0, prism_rtl::deref(tr_p2).home_p, crate::lower::camel_f(crate::check::types::bare_name_f(im_p1.cls_p))), .head_p = head_p3, .generics_p = generics_p6, .methods_p = methods_p5, .doc_p = Text::lit("")};
}


prism_rtl::Turn<crate::lower::model::ImplDef> ImplDefOf::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& im_p1 = this->im_p1;
    auto tr_p2 = crate::prelude::or_(crate::prelude::get(prism_rtl::deref(prism_rtl::deref(lx_p0).g_p).traits_p, prism_rtl::deref(im_p1).cls_p), crate::lower::expr::dummy_trait_info_p());
    auto im_p1x = im_p1;
    auto lx_p0x = lx_p0;
    return crate::prelude::call_then(crate::lower::types::start_out_ty_of_f(lx_p0x, prism_rtl::deref(im_p1x).head_p), [=](crate::lower::model::OutTy out_ty_of_f_12657) {
        return ({
            auto head_p3 = out_ty_of_f_12657;
            auto defs_p4 = crate::prelude::filter(prism_rtl::deref(prism_rtl::deref(lx_p0x).g_p).defs_p, [&](const crate::check::env::Def& d_p7) { return is_method_of_f(d_p7, im_p1x); });
            (crate::prelude::call_value(crate::prelude::each_job(defs_p4, ({
            auto tr_p2x = tr_p2;
            auto lx_p0xx = lx_p0x;
            auto im_p1xx = im_p1x;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::FnDef>(crate::check::env::Def)>>(prism_rtl::rc([=, tr_p2x = std::move(tr_p2x), lx_p0xx = std::move(lx_p0xx), im_p1xx = std::move(im_p1xx)](crate::check::env::Def p0) {
            return ({
                auto tr_p2xy = tr_p2x;
                auto lx_p0xxy = lx_p0xx;
                auto im_p1xxy = im_p1xx;
                (crate::prelude::entered(crate::prelude::once_job([=, tr_p2xy = std::move(tr_p2xy), lx_p0xxy = std::move(lx_p0xxy), im_p1xxy = std::move(im_p1xxy)]() {
                return ({
                    auto d_p8 = p0;
                    ({
                    auto mq_p9 = crate::prelude::fold(prism_rtl::deref(tr_p2xy).methods_p, Text::lit(""), [&](const Text& found_pd, const Text& q_pe) {
                        return crate::check::types::bare_name_f(q_pe) == prism_rtl::deref(d_p8).name_p
                            ? q_pe
                            : found_pd;
                    });
                    auto v_pa = crate::prelude::or_(crate::prelude::get(prism_rtl::deref(prism_rtl::deref(lx_p0xxy).g_p).vals_p, mq_p9), crate::check::env::builtin_f(mq_p9, crate::check::types::schemes::mono_f(crate::check::types::Ty(crate::check::types::Ty::TyErr{}))));
                    auto sc_pb = ({
                        crate::check::types::Scheme this_ = prism_rtl::deref(v_pa).scheme_p;
                        this_.ty_p = crate::lower::expr::instantiated_f(this_.ty_p, Array(std::vector{prism_rtl::deref(tr_p2xy).param_p}), Array(std::vector{prism_rtl::deref(im_p1xxy).head_p}));
                        this_.qs_p = crate::prelude::filter(this_.qs_p, [&](const Text& q_pf) { return q_pf != prism_rtl::deref(tr_p2xy).param_p; });
                        this_.bounds_p = crate::prelude::filter(this_.bounds_p, [&](const std::tuple<Text, Text>& _p0) {
                            auto&& q_pg = std::get<0>(_p0);
                            return q_pg != prism_rtl::deref(tr_p2xy).param_p;
                        });
                        (std::move(this_));
                    });
                    (crate::prelude::call_then(start_fn_def_of_f(lx_p0xxy, mq_p9, method_clauses_f(d_p8), sc_pb), [=](crate::lower::model::FnDef fn_def_of_f_13164) {
                    return ({
                        auto fd_pc = fn_def_of_f_13164;
                        (crate::syntax::lexer::chars::has_prefix_f(prism_rtl::deref(im_p1xxy).cls_p, Text::lit("Prelude."))
                        ? prism_rtl::finished(renamed_f(fd_pc, prism_rtl::cat(crate::lower::snake_f(prism_rtl::deref(d_p8).name_p), "_", crate::lower::snake_f(crate::check::types::bare_name_f(head_name_f(prism_rtl::deref(im_p1xxy).head_p))))))
                        : prism_rtl::finished(fd_pc));
                    });
                }));
                });
                });
            })));
            });
        })));
        })), [=, head_p3 = std::move(head_p3)](Array<crate::lower::model::FnDef> each_12750) {
            return ({
                auto methods_p5 = each_12750;
                (crate::prelude::call_value(crate::prelude::each_job(prism_rtl::deref(im_p1x).qs_p, ({
                auto lx_p0xx = lx_p0x;
                auto im_p1xx = im_p1x;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, Array<Text>>>(Text)>>(prism_rtl::rc([=, lx_p0xx = std::move(lx_p0xx), im_p1xx = std::move(im_p1xx)](Text p0) {
                return ({
                    auto lx_p0xxy = lx_p0xx;
                    auto im_p1xxy = im_p1xx;
                    (crate::prelude::entered(crate::prelude::once_job([=, lx_p0xxy = std::move(lx_p0xxy), im_p1xxy = std::move(im_p1xxy)]() {
                    return ({
                        auto q_ph = p0;
                        (crate::prelude::call_then(start_impl_bounds_f(lx_p0xxy, im_p1xxy, q_ph), [=](Array<Text> impl_bounds_f_13447) { return prism_rtl::finished(std::tuple{crate::lower::camel_f(q_ph), impl_bounds_f_13447}); }));
                    });
                })));
                });
            }));
            })), [=, methods_p5 = std::move(methods_p5)](Array<std::tuple<Text, Array<Text>>> each_13418) {
                return ({
                    auto generics_p6 = each_13418;
                    (prism_rtl::finished(crate::lower::model::ImplDef{.cls_p = prism_rtl::deref(im_p1x).cls_p, .tr_p = crate::lower::path_in_f(lx_p0x, prism_rtl::deref(tr_p2).home_p, crate::lower::camel_f(crate::check::types::bare_name_f(prism_rtl::deref(im_p1x).cls_p))), .head_p = head_p3, .generics_p = generics_p6, .methods_p = methods_p5, .doc_p = Text::lit("")}));
                });
            }));
            });
        }));
        });
    });
}


/// `Start ImplDefOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::ImplDef> start_impl_def_of_f(crate::lower::Lx lx_p0, crate::check::env::ImplInfo im_p1) {
    return prism_rtl::make_rc<ImplDefOf>(lx_p0, im_p1);
}


/// ImplBounds: unbounded fn Lx, ImplInfo, Text -> [Text]
Array<Text> impl_bounds_f(const crate::lower::Lx& lx_p0, const crate::check::env::ImplInfo& im_p1, const Text& q_p2) {
    return crate::prelude::fold(im_p1.bounds_p, Array(std::vector{Text::lit("Clone")}), [&](const Array<Text>& acc_p3, const std::tuple<Text, Text>& _p1) {
        auto&& v_p4 = std::get<0>(_p1);
        auto&& cls_p5 = std::get<1>(_p1);
        return v_p4 == q_p2
            ? crate::check::types::union_texts_f(acc_p3, bound_of_f(lx_p0, cls_p5))
            : acc_p3;
    });
}


prism_rtl::Turn<Array<Text>> ImplBounds::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& im_p1 = this->im_p1;
    const auto& q_p2 = this->q_p2;
    return prism_rtl::finished(crate::prelude::fold(prism_rtl::deref(im_p1).bounds_p, Array(std::vector{Text::lit("Clone")}), [&](const Array<Text>& acc_p3, const std::tuple<Text, Text>& _p1) {
        auto&& v_p4 = std::get<0>(_p1);
        auto&& cls_p5 = std::get<1>(_p1);
        return v_p4 == q_p2
            ? crate::check::types::union_texts_f(acc_p3, bound_of_f(lx_p0, cls_p5))
            : acc_p3;
    }));
}


/// `Start ImplBounds, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_impl_bounds_f(crate::lower::Lx lx_p0, crate::check::env::ImplInfo im_p1, Text q_p2) {
    return prism_rtl::make_rc<ImplBounds>(lx_p0, im_p1, q_p2);
}


/// Renamed: fn FnDef, Text -> FnDef
crate::lower::model::FnDef renamed_f(const crate::lower::model::FnDef& fd_p0, const Text& n_p1) {
    crate::lower::model::FnDef this_ = fd_p0;
    this_.name_p = n_p1;
    return this_;
}


/// IsMethodOf: fn Def, ImplInfo -> Bool
bool is_method_of_f(const crate::check::env::Def& d_p0, const crate::check::env::ImplInfo& im_p1) {
    auto&& _m = d_p0.body_p;
    if (prism_rtl::is<crate::check::env::DefBody::DbMethod>(_m)) {
        auto&& cls_p2 = prism_rtl::as<crate::check::env::DefBody::DbMethod>(_m).a1;
        auto&& other_p3 = prism_rtl::as<crate::check::env::DefBody::DbMethod>(_m).a2;
        return ((cls_p2 == im_p1.cls_p) && (prism_rtl::deref(other_p3).span_p == im_p1.span_p)) && (prism_rtl::deref(other_p3).file_p == im_p1.file_p);
    }
    {
        return false;
    }
}


/// MethodClauses: fn Def -> [FnClause]
Array<crate::syntax::decls::FnClause> method_clauses_f(const crate::check::env::Def& d_p0) {
    auto&& _m = d_p0.body_p;
    if (prism_rtl::is<crate::check::env::DefBody::DbMethod>(_m)) {
        auto&& cs_p1 = prism_rtl::as<crate::check::env::DefBody::DbMethod>(_m).a0;
        return cs_p1;
    }
    {
        return Array<crate::syntax::decls::FnClause>{};
    }
}


/// IfGenLine: unbounded fn Wx, Env, Expr, Block, Block, Expr -> ((Wx, Wres))
std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> if_gen_line_f(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& menv_p1, const crate::syntax::Expr& c_p2, const crate::syntax::Block& then_b_p3, const crate::syntax::Block& else_b_p4, const crate::syntax::Expr& e_p5) {
    auto lx_p6 = wx_p0.lx_p;
    auto pos_p7 = wx_p0.pos_p;
    auto wx1_p8 = ({
        crate::lower::node_::Wx this_ = wx_p0;
        this_.pos_p = crate::lower::model::next_pos_f(this_.pos_p);
        (std::move(this_));
    });
    auto [name_ph, wx2_pi] = crate::lower::node_::fresh_name_f(wx1_p8, Text::lit("arm"));
    auto base_p9 = prism_rtl::cat(wx_p0.node_p, crate::lower::camel_f(name_ph), crate::lower::node_::keyed::row_suffix_f(wx_p0));
    auto yes_pa = crate::lower::node_::switch_::gen_row_of_f(wx2_pi, menv_p1, then_b_p3, crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), prism_rtl::cat(base_p9, "Then"), name_ph);
    auto no_pb = crate::lower::node_::switch_::gen_row_of_f(prism_rtl::deref(yes_pa).parent_p, menv_p1, else_b_p4, crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), prism_rtl::cat(base_p9, "Else"), name_ph);
    auto cond_pc = crate::lower::types::as_bool_f(crate::lower::expr::value_of_f(lx_p6, menv_p1, c_p2));
    auto tail_pd = crate::prelude::append(crate::prelude::append(Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XWeak{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{}))})}), crate::lower::node_::keyed::hosted_passed_f(wx_p0)), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})}));
    auto mk_fe = ({
        auto tail_pdx = tail_pd;
        (static_cast<Fn<crate::lower::model::Ex(const crate::lower::model::NodeDef&)>>(prism_rtl::rc([=, tail_pdx = std::move(tail_pdx)](const crate::lower::model::NodeDef& n_pj) { return crate::lower::model::Ex(crate::lower::model::Ex::XCast{prism_rtl::rc(crate::lower::expr::try_of_f(crate::lower::model::Ex(crate::lower::model::Ex::XCall{prism_rtl::cat(prism_rtl::deref(n_pj).name_p, "::build"), crate::prelude::append(Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("path")}), crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("value")})}), tail_pdx)}))), crate::lower::model::OutTy(crate::lower::model::OutTy::OutObj{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Row"), Array<crate::lower::model::OutTy>{}}))})}); })));
    });
    auto select_pf = crate::lower::model::Ex(crate::lower::model::Ex::XIf{prism_rtl::rc(cond_pc), prism_rtl::rc(mk_fe(prism_rtl::deref(yes_pa).node_p)), prism_rtl::rc(mk_fe(prism_rtl::deref(no_pb).node_p))});
    auto wx3_pg = ({
        crate::lower::node_::Wx this_ = prism_rtl::deref(no_pb).parent_p;
        this_.gens_p = crate::prelude::push(this_.gens_p, crate::lower::model::GenDef{.name_p = name_ph, .pos_p = pos_p7, .at_p = crate::lower::node_::finish::place_at_f(wx_p0, Text::lit("self"), pos_p7), .source_p = crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), .value_ty_p = crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), .select_p = select_pf, .transparent_p = false, .width_p = Nat(0u), .moved_p = crate::prelude::or_(crate::lower::node_::finish::hosted_rows_o(wx_p0), Text::lit(""))});
        this_.gen_holds_p = crate::prelude::push(this_.gen_holds_p, std::tuple{name_ph, Array<crate::lower::node_::Read>{}});
        this_.rows_p = crate::prelude::append(crate::prelude::append(crate::prelude::append(crate::prelude::push(this_.rows_p, prism_rtl::deref(yes_pa).node_p), prism_rtl::deref(prism_rtl::deref(yes_pa).node_p).children_p), Array(std::vector{prism_rtl::deref(no_pb).node_p})), prism_rtl::deref(prism_rtl::deref(no_pb).node_p).children_p);
        this_.getters_p = crate::prelude::push(this_.getters_p, crate::lower::model::MethDef{.name_p = prism_rtl::cat(name_ph, "_up"), .recv_p = crate::lower::model::Recv(crate::lower::model::Recv::RecvRc{}), .params_p = Array(std::vector{std::tuple{Text::lit("v"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})}}), .cx_p = crate::lower::model::CxArg(crate::lower::model::CxArg::CxMut{}), .ret_p = crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), .body_p = Array<crate::lower::model::Do>{}, .tail_p = crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), .doc_p = Text::lit("An arm\'s result, which a building `if` of widgets drops.")});
        (std::move(this_));
    });
    return std::tuple{wx3_pg, crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{})};
}


prism_rtl::Turn<std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres>> IfGenLine::cycle() const {
    const auto& wx_p0 = this->wx_p0;
    const auto& menv_p1 = this->menv_p1;
    const auto& c_p2 = this->c_p2;
    const auto& then_b_p3 = this->then_b_p3;
    const auto& else_b_p4 = this->else_b_p4;
    const auto& e_p5 = this->e_p5;
    auto lx_p6 = prism_rtl::deref(wx_p0).lx_p;
    auto pos_p7 = prism_rtl::deref(wx_p0).pos_p;
    auto wx1_p8 = ({
        crate::lower::node_::Wx this_ = wx_p0;
        this_.pos_p = crate::lower::model::next_pos_f(this_.pos_p);
        (std::move(this_));
    });
    auto [name_ph, wx2_pi] = crate::lower::node_::fresh_name_f(wx1_p8, Text::lit("arm"));
    auto base_p9 = prism_rtl::cat(prism_rtl::deref(wx_p0).node_p, crate::lower::camel_f(name_ph), crate::lower::node_::keyed::row_suffix_f(wx_p0));
    auto yes_pa = crate::lower::node_::switch_::gen_row_of_f(wx2_pi, menv_p1, then_b_p3, crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), prism_rtl::cat(base_p9, "Then"), name_ph);
    auto no_pb = crate::lower::node_::switch_::gen_row_of_f(prism_rtl::deref(yes_pa).parent_p, menv_p1, else_b_p4, crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), prism_rtl::cat(base_p9, "Else"), name_ph);
    auto c_p2x = c_p2;
    auto menv_p1x = menv_p1;
    auto wx_p0x = wx_p0;
    return crate::prelude::call_then(crate::lower::expr::start_value_of_f(lx_p6, menv_p1x, c_p2x), [=](crate::lower::types::Vl value_of_f_14903) {
        return ({
            auto cond_pc = crate::lower::types::as_bool_f(value_of_f_14903);
            auto tail_pd = crate::prelude::append(crate::prelude::append(Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XWeak{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{}))})}), crate::lower::node_::keyed::hosted_passed_f(wx_p0x)), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})}));
            auto mk_fe = ({
                auto tail_pdx = tail_pd;
                (static_cast<Fn<crate::lower::model::Ex(const crate::lower::model::NodeDef&)>>(prism_rtl::rc([=, tail_pdx = std::move(tail_pdx)](const crate::lower::model::NodeDef& n_pj) { return crate::lower::model::Ex(crate::lower::model::Ex::XCast{prism_rtl::rc(crate::lower::expr::try_of_f(crate::lower::model::Ex(crate::lower::model::Ex::XCall{prism_rtl::cat(prism_rtl::deref(n_pj).name_p, "::build"), crate::prelude::append(Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("path")}), crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("value")})}), tail_pdx)}))), crate::lower::model::OutTy(crate::lower::model::OutTy::OutObj{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Row"), Array<crate::lower::model::OutTy>{}}))})}); })));
            });
            auto select_pf = crate::lower::model::Ex(crate::lower::model::Ex::XIf{prism_rtl::rc(cond_pc), prism_rtl::rc(mk_fe(prism_rtl::deref(yes_pa).node_p)), prism_rtl::rc(mk_fe(prism_rtl::deref(no_pb).node_p))});
            auto wx3_pg = ({
                crate::lower::node_::Wx this_ = prism_rtl::deref(no_pb).parent_p;
                this_.gens_p = crate::prelude::push(this_.gens_p, crate::lower::model::GenDef{.name_p = name_ph, .pos_p = pos_p7, .at_p = crate::lower::node_::finish::place_at_f(wx_p0x, Text::lit("self"), pos_p7), .source_p = crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), .value_ty_p = crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), .select_p = select_pf, .transparent_p = false, .width_p = Nat(0u), .moved_p = crate::prelude::or_(crate::lower::node_::finish::hosted_rows_o(wx_p0x), Text::lit(""))});
                this_.gen_holds_p = crate::prelude::push(this_.gen_holds_p, std::tuple{name_ph, Array<crate::lower::node_::Read>{}});
                this_.rows_p = crate::prelude::append(crate::prelude::append(crate::prelude::append(crate::prelude::push(this_.rows_p, prism_rtl::deref(yes_pa).node_p), prism_rtl::deref(prism_rtl::deref(yes_pa).node_p).children_p), Array(std::vector{prism_rtl::deref(no_pb).node_p})), prism_rtl::deref(prism_rtl::deref(no_pb).node_p).children_p);
                this_.getters_p = crate::prelude::push(this_.getters_p, crate::lower::model::MethDef{.name_p = prism_rtl::cat(name_ph, "_up"), .recv_p = crate::lower::model::Recv(crate::lower::model::Recv::RecvRc{}), .params_p = Array(std::vector{std::tuple{Text::lit("v"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})}}), .cx_p = crate::lower::model::CxArg(crate::lower::model::CxArg::CxMut{}), .ret_p = crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), .body_p = Array<crate::lower::model::Do>{}, .tail_p = crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), .doc_p = Text::lit("An arm\'s result, which a building `if` of widgets drops.")});
                (std::move(this_));
            });
            (prism_rtl::finished(std::tuple{wx3_pg, crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{})}));
        });
    });
}


/// `Start IfGenLine, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres>> start_if_gen_line_f(crate::lower::node_::Wx wx_p0, crate::lower::types::Env menv_p1, crate::syntax::Expr c_p2, crate::syntax::Block then_b_p3, crate::syntax::Block else_b_p4, crate::syntax::Expr e_p5) {
    return prism_rtl::make_rc<IfGenLine>(wx_p0, menv_p1, c_p2, then_b_p3, else_b_p4, e_p5);
}

}  // namespace crate::lower::functions
