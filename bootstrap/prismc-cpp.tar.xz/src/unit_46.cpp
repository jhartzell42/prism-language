// The module `Lower.Functions`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <lower/functions/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Lower.Functions`, from `target/bootstrap/cpp-src/prismc/lower/functions.prism`.
namespace crate::lower::functions {

/// BoundOf: fn Lx, Text -> [Text]
Array<Text> bound_of(const crate::lower::Lx& lx_p0, const Text& text1) {
    {
        auto&& c0_1 = text1;
        if (c0_1 == Text::lit("Prelude.Eq")) {
            return Array(std::vector{Text::lit("Eq")});
        }
    }
    {
        auto&& c1_1 = text1;
        if (c1_1 == Text::lit("Prelude.Ord")) {
            return Array(std::vector{Text::lit("Ord")});
        }
    }
    {
        auto&& c2_1 = text1;
        if (c2_1 == Text::lit("Prelude.Show")) {
            return Array(std::vector{Text::lit("Show")});
        }
    }
    {
        auto&& c3_1 = text1;
        if (c3_1 == Text::lit("Prelude.Num")) {
            return Array(std::vector{Text::lit("Num")});
        }
    }
    {
        auto&& c4_1 = text1;
        if (c4_1 == Text::lit("Prelude.Pod")) {
            return Array(std::vector{Text::lit("ToPod"), Text::lit("FromPod")});
        }
    }
    {
        auto&& cls_p6 = text1;
        auto&& _m = crate::prelude::get(prism_rtl::deref(lx_p0.g).traits, cls_p6);
        if (prism_rtl::is_some(_m)) {
            auto&& tr_p7 = prism_rtl::some_of(_m);
            return Array(std::vector{crate::lower::path_in(lx_p0, prism_rtl::deref(tr_p7).home, crate::lower::camel(crate::check::types::bare_name(cls_p6)))});
        }
        if (prism_rtl::is_none(_m)) {
            return Array<Text>{};
        }
        prism_rtl::unreachable("no arm matched");
    }
}


/// SchemeGenerics: fn Lx, Scheme -> [((Text, [Text]))]
Array<std::tuple<Text, Array<Text>>> scheme_generics(const crate::lower::Lx& lx_p0, const crate::check::types::Scheme& sc_p1) {
    return each(sc_p1.qs, [&](const Text& q_p2) {
        return ({
            auto bs_p3 = fold(sc_p1.bounds, Array(std::vector{Text::lit("Clone")}), [&](const Array<Text>& acc_p5, const std::tuple<Text, Text>& _p1) {
                auto&& v_p6 = std::get<0>(_p1);
                auto&& cls_p7 = std::get<1>(_p1);
                return v_p6 == q_p2
                    ? crate::check::types::union_texts(acc_p5, bound_of(lx_p0, cls_p7))
                    : acc_p5;
            });
            auto keyed_p4 = keys_by(sc_p1.ty, q_p2)
                ? crate::check::types::union_texts(bs_p3, Array(std::vector{Text::lit("Ord")}))
                : bs_p3;
            std::tuple{crate::lower::camel(q_p2), keyed_p4};
        });
    });
}


/// KeysBy: fn Ty, Text -> Bool
bool keys_by(const crate::check::types::Ty& t_p0, const Text& q_p1) {
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(t_p0)) {
        auto&& k_p2 = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p0).a0;
        auto&& v_p3 = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p0).a1;
        return ((prism_rtl::deref(prism_rtl::deref(k_p2)) == crate::check::types::Ty(crate::check::types::Ty::TyQ{q_p1})) || keys_by(prism_rtl::deref(prism_rtl::deref(k_p2)), q_p1)) || keys_by(prism_rtl::deref(prism_rtl::deref(v_p3)), q_p1);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t_p0)) {
        auto&& ts_p4 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p0).a1;
        return fold(ts_p4, false, [&](const bool& found_p5, const crate::check::types::Ty& x_p6) { return prism_rtl::deref(found_p5) || keys_by(x_p6, q_p1); });
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(t_p0)) {
        auto&& ps_p7 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p0).a1;
        auto&& r_p8 = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p0).a2;
        return fold(ps_p7, false, [&](const bool& found_p9, const crate::check::types::Ty& x_pa) { return prism_rtl::deref(found_p9) || keys_by(x_pa, q_p1); }) || keys_by(prism_rtl::deref(prism_rtl::deref(r_p8)), q_p1);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t_p0)) {
        auto&& ts_pb = prism_rtl::as<crate::check::types::Ty::TyTuple>(t_p0).a0;
        return fold(ts_pb, false, [&](const bool& found_pc, const crate::check::types::Ty& x_pd) { return prism_rtl::deref(found_pc) || keys_by(x_pd, q_p1); });
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(t_p0)) {
        auto&& x_pe = prism_rtl::as<crate::check::types::Ty::TyArray>(t_p0).a0;
        return keys_by(prism_rtl::deref(prism_rtl::deref(x_pe)), q_p1);
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t_p0)) {
        auto&& x_pf = prism_rtl::as<crate::check::types::Ty::TySig>(t_p0).a1;
        return keys_by(prism_rtl::deref(prism_rtl::deref(x_pf)), q_p1);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(t_p0)) {
        auto&& x_pg = prism_rtl::as<crate::check::types::Ty::TyAt>(t_p0).a0;
        return keys_by(prism_rtl::deref(prism_rtl::deref(x_pg)), q_p1);
    }
    {
        return false;
    }
}


/// ParamNames: unbounded fn Lx, [FnClause], [OutTy] -> [((Text, Bool))]
Array<std::tuple<Text, bool>> param_names(const crate::lower::Lx& lx_p0, const Array<crate::syntax::decls::FnClause>& clauses_p1, const Array<crate::lower::model::OutTy>& pts_p2) {
    return run_to_end(each_job(crate::check::errors::range0(len(pts_p2)), ({
        auto clauses_p1_1 = clauses_p1;
        auto lx_p0_2 = lx_p0;
        auto pts_p2_3 = pts_p2;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, bool>>(Nat)>>(prism_rtl::rc([=, clauses_p1_1 = std::move(clauses_p1_1), lx_p0_2 = std::move(lx_p0_2), pts_p2_3 = std::move(pts_p2_3)](Nat p0) {
        return ({
            auto clauses_p1_1_4 = clauses_p1_1;
            auto lx_p0_2_4 = lx_p0_2;
            auto pts_p2_3_4 = pts_p2_3;
            entered(once_job([=, clauses_p1_1_4 = std::move(clauses_p1_1_4), lx_p0_2_4 = std::move(lx_p0_2_4), pts_p2_3_4 = std::move(pts_p2_3_4)]() {
            return ({
                auto i_p3 = p0;
                ({
                auto names_p4 = each(clauses_p1_1_4, [&](const crate::syntax::decls::FnClause& c_p8) { return plain_binder(lx_p0_2_4, or_(index(prism_rtl::deref(c_p8).params, i_p3), crate::lower::patterns::dummy_pat())); });
                auto first_p5 = or_(index(names_p4, Nat(0u)), Text::lit(""));
                auto same_p6 = (first_p5 != Text::lit("")) && fold(names_p4, true, [&](const bool& ok_p9, const Text& n_pa) { return prism_rtl::deref(ok_p9) && (n_pa == first_p5); });
                auto span_p7 = ({
                    __label__ _done;
                    prism_rtl::Slot<crate::syntax::Range> _v;
                    auto&& _m = prism_rtl::deref(prism_rtl::deref(or_(index(prism_rtl::deref(or_(index(clauses_p1_1_4, Nat(0u)), dummy_clause())).params, i_p3), crate::lower::patterns::dummy_pat())).kind);
                    if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
                        auto&& n_pb = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
                        _v.set(prism_rtl::deref(n_pb).span);
                        goto _done;
                    }
                    {
                        _v.set(crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)});
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                (std::move(same_p6)
                ? call_then(crate::lower::start_local_name_at(lx_p0_2_4, first_p5, span_p7), [=](Text local_name_at_3553) { return prism_rtl::finished(std::tuple{local_name_at_3553, false}); })
                : prism_rtl::finished(std::tuple{param_word(or_(index(pts_p2_3_4, i_p3), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})), i_p3), true}));
            });
            });
        }));
        });
    }));
    })));
}


prism_rtl::Turn<Array<std::tuple<Text, bool>>> ParamNames::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& clauses_p1 = this->clauses_p1;
    const auto& pts_p2 = this->pts_p2;
    return each_job(crate::check::errors::range0(len(pts_p2)), ({
        auto clauses_p1_1 = clauses_p1;
        auto lx_p0_2 = lx_p0;
        auto pts_p2_3 = pts_p2;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, bool>>(Nat)>>(prism_rtl::rc([=, clauses_p1_1 = std::move(clauses_p1_1), lx_p0_2 = std::move(lx_p0_2), pts_p2_3 = std::move(pts_p2_3)](Nat p0) {
        return ({
            auto clauses_p1_1_4 = clauses_p1_1;
            auto lx_p0_2_4 = lx_p0_2;
            auto pts_p2_3_4 = pts_p2_3;
            entered(once_job([=, clauses_p1_1_4 = std::move(clauses_p1_1_4), lx_p0_2_4 = std::move(lx_p0_2_4), pts_p2_3_4 = std::move(pts_p2_3_4)]() {
            return ({
                auto i_p3 = p0;
                ({
                auto names_p4 = each(clauses_p1_1_4, [&](const crate::syntax::decls::FnClause& c_p8) { return plain_binder(lx_p0_2_4, or_(index(prism_rtl::deref(c_p8).params, i_p3), crate::lower::patterns::dummy_pat())); });
                auto first_p5 = or_(index(names_p4, Nat(0u)), Text::lit(""));
                auto same_p6 = (first_p5 != Text::lit("")) && fold(names_p4, true, [&](const bool& ok_p9, const Text& n_pa) { return prism_rtl::deref(ok_p9) && (n_pa == first_p5); });
                auto span_p7 = ({
                    __label__ _done;
                    prism_rtl::Slot<crate::syntax::Range> _v;
                    auto&& _m = prism_rtl::deref(prism_rtl::deref(or_(index(prism_rtl::deref(or_(index(clauses_p1_1_4, Nat(0u)), dummy_clause())).params, i_p3), crate::lower::patterns::dummy_pat())).kind);
                    if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
                        auto&& n_pb = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
                        _v.set(prism_rtl::deref(n_pb).span);
                        goto _done;
                    }
                    {
                        _v.set(crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)});
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                (std::move(same_p6)
                ? call_then(crate::lower::start_local_name_at(lx_p0_2_4, first_p5, span_p7), [=](Text local_name_at_3553) { return prism_rtl::finished(std::tuple{local_name_at_3553, false}); })
                : prism_rtl::finished(std::tuple{param_word(or_(index(pts_p2_3_4, i_p3), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})), i_p3), true}));
            });
            });
        }));
        });
    }));
    }))->cycle();
}


/// `Start ParamNames, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<std::tuple<Text, bool>>> start_param_names(crate::lower::Lx lx_p0, Array<crate::syntax::decls::FnClause> clauses_p1, Array<crate::lower::model::OutTy> pts_p2) {
    return prism_rtl::make_rc<ParamNames>(lx_p0, clauses_p1, pts_p2);
}


/// PlainBinder: fn Lx, Pattern -> Text
Text plain_binder(const crate::lower::Lx& lx_p0, const crate::syntax::Pattern_& p_p1) {
    auto&& _m = prism_rtl::deref(p_p1.kind);
    if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
        auto&& n_p2 = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        auto [qk_o4, why_p5] = crate::check::env::names::resolve_value(lx_p0.g, lx_p0.home, n_p2);
        auto is_ctor_p3 = ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            if (prism_rtl::is_some(qk_o4)) {
                auto&& qk_p6 = prism_rtl::some_of(qk_o4);
                _v.set(crate::check::env::has_key(prism_rtl::deref(lx_p0.g).ctors, qk_p6) && (crate::check::env::is_upper_text(crate::lower::base(crate::check::env::sname_key(n_p2))) || crate::lower::patterns::is_unit_ctor(lx_p0, qk_p6)));
                goto _done;
            }
            if (prism_rtl::is_none(qk_o4)) {
                _v.set(false);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        return std::move(is_ctor_p3) ? Text::lit("") : crate::check::env::sname_key(n_p2);
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PGroup>(_m)) {
        auto&& q_p7 = prism_rtl::as<crate::syntax::PatternKind::PGroup>(_m).a0;
        return plain_binder(lx_p0, prism_rtl::deref(prism_rtl::deref(q_p7)));
    }
    {
        return Text::lit("");
    }
}


/// ParamWord: fn OutTy, Nat -> Text
Text param_word(const crate::lower::model::OutTy& t_p0, const Nat& i_p1) {
    auto base_p2 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t_p0)) {
            auto&& n_p3 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p0).a0;
            _v.set(crate::lower::snake(or_(crate::syntax::lexer::chars::last(split_on(n_p3, Text::lit("::"))), Text::lit("arg"))));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::OutTy::OutText>(t_p0)) {
            _v.set(Text::lit("text"));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::OutTy::OutNat>(t_p0)) {
            _v.set(Text::lit("n"));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::OutTy::OutInt>(t_p0)) {
            _v.set(Text::lit("i"));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::OutTy::OutArray>(t_p0)) {
            _v.set(Text::lit("xs"));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::OutTy::OutMap>(t_p0)) {
            _v.set(Text::lit("map"));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::OutTy::OutOpt>(t_p0)) {
            _v.set(Text::lit("opt"));
            goto _done;
        }
        {
            _v.set(Text::lit("arg"));
            goto _done;
        }
    _done:
        _v.take();
    });
    return prism_rtl::cat(base_p2, i_p1);
}


/// ClausesBody: unbounded fn Lx, Env, [FnClause], [((Text, Bool))], [Ty], (fn Lx, Env, FnBody -> Ex), Text, OutTy -> Ex
crate::lower::model::Ex clauses_body(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const Array<crate::syntax::decls::FnClause>& clauses_p2, const Array<std::tuple<Text, bool>>& names_p3, const Array<crate::check::types::Ty>& ptys_p4, const prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::Lx, crate::lower::types::Env, crate::syntax::decls::FnBody>)>& body_f5, const Text& label_p6, const crate::lower::model::OutTy& t_p7) {
    auto env1_p8 = run_to_end(fold_job(crate::check::errors::range0(len(names_p3)), env_p1, ({
        auto names_p3_1 = names_p3;
        auto lx_p0_2 = lx_p0;
        auto clauses_p2_3 = clauses_p2;
        auto ptys_p4_4 = ptys_p4;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::types::Env>(std::tuple<crate::lower::types::Env, Nat>)>>(prism_rtl::rc([=, names_p3_1 = std::move(names_p3_1), lx_p0_2 = std::move(lx_p0_2), clauses_p2_3 = std::move(clauses_p2_3), ptys_p4_4 = std::move(ptys_p4_4)](std::tuple<crate::lower::types::Env, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto names_p3_1_5 = names_p3_1;
            auto lx_p0_2_5 = lx_p0_2;
            auto clauses_p2_3_5 = clauses_p2_3;
            auto ptys_p4_4_5 = ptys_p4_4;
            entered(once_job([=, names_p3_1_5 = std::move(names_p3_1_5), lx_p0_2_5 = std::move(lx_p0_2_5), clauses_p2_3_5 = std::move(clauses_p2_3_5), ptys_p4_4_5 = std::move(ptys_p4_4_5)]() {
            return ({
                auto en_pa = p0;
                auto i_pb = p1;
                ({
                auto [rs_pc, matched_pd] = or_(index(names_p3_1_5, i_pb), std::tuple{Text::lit(""), true});
                matched_pd
                ? prism_rtl::finished(en_pa)
                : call_then(crate::lower::types::start_out_ty_of(lx_p0_2_5, crate::lower::types::peel(or_(index(ptys_p4_4_5, i_pb), crate::check::types::Ty(crate::check::types::Ty::TyErr{})))), [=](crate::lower::model::OutTy out_ty_of_5056) { return prism_rtl::finished(crate::lower::types::bind(en_pa, plain_binder(lx_p0_2_5, or_(index(prism_rtl::deref(or_(index(clauses_p2_3_5, Nat(0u)), dummy_clause())).params, i_pb), crate::lower::patterns::dummy_pat())), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{rs_pc}), crate::lower::types::Holding(crate::lower::types::Holding::ByRef{}), out_ty_of_5056}))); });
            });
            });
        }));
        });
    })));
    })));
    auto scrut_ix_p9 = filter(crate::check::errors::range0(len(names_p3)), [&](const Nat& i_pe) {
        return ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            auto&& _m = index(names_p3, i_pe);
            if (prism_rtl::is_some(_m) && std::get<1>(prism_rtl::some_of(_m))) {
                _v.set(true);
                goto _done;
            }
            {
                _v.set(false);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    return len(scrut_ix_p9) == Nat(0u)
        ? ({
        auto c_pf = or_(index(clauses_p2, Nat(0u)), dummy_clause());
        run_to_end(body_f5(std::tuple{lx_p0, env1_p8, prism_rtl::deref(c_pf).body}));
    })
        : ({
        auto scrut_pg = ({
            __label__ _done;
            prism_rtl::Slot<crate::lower::model::Ex> _v;
            {
                auto&& m5353_0 = scrut_ix_p9;
                if (m5353_0.size() == 1u) {
                    {
                        auto&& _c1 = index(m5353_0, Nat(0u));
                        if (prism_rtl::is_some(_c1)) {
                            auto&& i_pi = prism_rtl::some_of(_c1);
                            _v.set(crate::lower::model::Ex(crate::lower::model::Ex::XVar{or_(index(each(names_p3, [&](const std::tuple<Text, bool>& _p0) {
                                auto&& n_pj = std::get<0>(_p0);
                                return n_pj;
                            }), i_pi), Text::lit("arg"))}));
                            goto _done;
                        }
                    }
                }
            }
            {
                _v.set(crate::lower::model::Ex(crate::lower::model::Ex::XTuple{each(scrut_ix_p9, [&](const Nat& i_pk) {
                    return crate::lower::model::Ex(crate::lower::model::Ex::XVar{or_(index(each(names_p3, [&](const std::tuple<Text, bool>& _p0) {
                        auto&& n_pl = std::get<0>(_p0);
                        return n_pl;
                    }), i_pk), Text::lit("arg"))});
                })}));
                goto _done;
            }
        _done:
            _v.take();
        });
        auto arms_ph = run_to_end(each_job(crate::check::errors::range0(len(clauses_p2)), ({
            auto clauses_p2_1 = clauses_p2;
            auto scrut_ix_p9_2 = scrut_ix_p9;
            auto lx_p0_3 = lx_p0;
            auto ptys_p4_4 = ptys_p4;
            auto label_p6_5 = label_p6;
            auto body_f5_6 = body_f5;
            auto env1_p8_7 = env1_p8;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::XArm>(Nat)>>(prism_rtl::rc([=, clauses_p2_1 = std::move(clauses_p2_1), scrut_ix_p9_2 = std::move(scrut_ix_p9_2), lx_p0_3 = std::move(lx_p0_3), ptys_p4_4 = std::move(ptys_p4_4), label_p6_5 = std::move(label_p6_5), body_f5_6 = std::move(body_f5_6), env1_p8_7 = std::move(env1_p8_7)](Nat p0) {
            return ({
                auto clauses_p2_1_8 = clauses_p2_1;
                auto scrut_ix_p9_2_8 = scrut_ix_p9_2;
                auto lx_p0_3_8 = lx_p0_3;
                auto ptys_p4_4_8 = ptys_p4_4;
                auto label_p6_5_8 = label_p6_5;
                auto body_f5_6_8 = body_f5_6;
                auto env1_p8_7_8 = env1_p8_7;
                entered(once_job([=, clauses_p2_1_8 = std::move(clauses_p2_1_8), scrut_ix_p9_2_8 = std::move(scrut_ix_p9_2_8), lx_p0_3_8 = std::move(lx_p0_3_8), ptys_p4_4_8 = std::move(ptys_p4_4_8), label_p6_5_8 = std::move(label_p6_5_8), body_f5_6_8 = std::move(body_f5_6_8), env1_p8_7_8 = std::move(env1_p8_7_8)]() {
                return ({
                    auto ci_pm = p0;
                    ({
                    auto c_pn = or_(index(clauses_p2_1_8, ci_pm), dummy_clause());
                    call_value(each_job(scrut_ix_p9_2_8, ({
                    auto lx_p0_3_8_8 = lx_p0_3_8;
                    auto c_pn_8 = c_pn;
                    auto ptys_p4_4_8_9 = ptys_p4_4_8;
                    auto label_p6_5_8_9 = label_p6_5_8;
                    auto ci_pm_9 = ci_pm;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::patterns::PatOut>(Nat)>>(prism_rtl::rc([=, lx_p0_3_8_8 = std::move(lx_p0_3_8_8), c_pn_8 = std::move(c_pn_8), ptys_p4_4_8_9 = std::move(ptys_p4_4_8_9), label_p6_5_8_9 = std::move(label_p6_5_8_9), ci_pm_9 = std::move(ci_pm_9)](Nat p0) {
                    return ({
                        auto lx_p0_3_8_8_10 = lx_p0_3_8_8;
                        auto c_pn_8_10 = c_pn_8;
                        auto ptys_p4_4_8_9_10 = ptys_p4_4_8_9;
                        auto label_p6_5_8_9_10 = label_p6_5_8_9;
                        auto ci_pm_9_10 = ci_pm_9;
                        entered(once_job([=, lx_p0_3_8_8_10 = std::move(lx_p0_3_8_8_10), c_pn_8_10 = std::move(c_pn_8_10), ptys_p4_4_8_9_10 = std::move(ptys_p4_4_8_9_10), label_p6_5_8_9_10 = std::move(label_p6_5_8_9_10), ci_pm_9_10 = std::move(ci_pm_9_10)]() {
                        return ({
                            auto i_ps = p0;
                            (prism_rtl::more(prism_rtl::rc(crate::lower::patterns::RustPat(lx_p0_3_8_8_10, or_(index(prism_rtl::deref(c_pn_8_10).params, i_ps), crate::lower::patterns::dummy_pat()), or_(index(ptys_p4_4_8_9_10, i_ps), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), crate::lower::types::Holding(crate::lower::types::Holding::ByRef{}), prism_rtl::cat(label_p6_5_8_9_10, ci_pm_9_10, "_", i_ps)))));
                        });
                    }));
                    });
                })));
                })), [=](Array<crate::lower::patterns::PatOut> each_5668) {
                    return ({
                        auto pos_po = each_5668;
                        auto pa_pp = ({
                            __label__ _done;
                            prism_rtl::Slot<crate::lower::model::Pa> _v;
                            {
                                auto&& m5794_0 = pos_po;
                                if (m5794_0.size() == 1u) {
                                    {
                                        auto&& _c1 = index(m5794_0, Nat(0u));
                                        if (prism_rtl::is_some(_c1)) {
                                            auto&& o_pt = prism_rtl::some_of(_c1);
                                            _v.set(prism_rtl::deref(o_pt).pa);
                                            goto _done;
                                        }
                                    }
                                }
                            }
                            {
                                _v.set(crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{each(pos_po, [&](const crate::lower::patterns::PatOut& o_pu) { return prism_rtl::deref(o_pu).pa; })}));
                                goto _done;
                            }
                        _done:
                            _v.take();
                        });
                        auto conds_pq = fold(pos_po, Array<crate::lower::model::Cc>{}, [&](const Array<crate::lower::model::Cc>& acc_pv, const crate::lower::patterns::PatOut& o_p10) { return append(acc_pv, prism_rtl::deref(o_p10).conds); });
                        auto binds_pr = fold(pos_po, Array<std::tuple<Text, crate::lower::types::Bn>>{}, [&](const Array<std::tuple<Text, crate::lower::types::Bn>>& acc_p11, const crate::lower::patterns::PatOut& o_p12) { return append(acc_p11, prism_rtl::deref(o_p12).binds); });
                        call_value(body_f5_6_8(std::tuple{lx_p0_3_8, crate::lower::expr::bind_all(env1_p8_7_8, binds_pr), prism_rtl::deref(c_pn).body}), [=, pa_pp = std::move(pa_pp), conds_pq = std::move(conds_pq)](crate::lower::model::Ex body_6074) { return prism_rtl::finished(crate::lower::model::XArm{.pat = pa_pp, .conds = conds_pq, .body = body_6074}); });
                    });
                });
                });
                });
            }));
            });
        })));
        })));
        (crate::lower::types::own(crate::lower::expr::arms_value(scrut_pg, arms_ph, prism_rtl::cat("\'", label_p6), t_p7)));
    });
}


prism_rtl::Turn<crate::lower::model::Ex> ClausesBody::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& clauses_p2 = this->clauses_p2;
    const auto& names_p3 = this->names_p3;
    const auto& ptys_p4 = this->ptys_p4;
    const auto& body_f5 = this->body_f5;
    const auto& label_p6 = this->label_p6;
    const auto& t_p7 = this->t_p7;
    auto body_f5_1 = body_f5;
    auto clauses_p2_2 = clauses_p2;
    auto env_p1_3 = env_p1;
    auto label_p6_4 = label_p6;
    auto lx_p0_5 = lx_p0;
    auto names_p3_6 = names_p3;
    auto ptys_p4_7 = ptys_p4;
    auto t_p7_8 = t_p7;
    return call_value(fold_job(crate::check::errors::range0(len(names_p3_6)), env_p1_3, ({
        auto names_p3_6_9 = names_p3_6;
        auto lx_p0_5_9 = lx_p0_5;
        auto clauses_p2_2_9 = clauses_p2_2;
        auto ptys_p4_7_9 = ptys_p4_7;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::types::Env>(std::tuple<crate::lower::types::Env, Nat>)>>(prism_rtl::rc([=, names_p3_6_9 = std::move(names_p3_6_9), lx_p0_5_9 = std::move(lx_p0_5_9), clauses_p2_2_9 = std::move(clauses_p2_2_9), ptys_p4_7_9 = std::move(ptys_p4_7_9)](std::tuple<crate::lower::types::Env, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto names_p3_6_9_9 = names_p3_6_9;
            auto lx_p0_5_9_9 = lx_p0_5_9;
            auto clauses_p2_2_9_9 = clauses_p2_2_9;
            auto ptys_p4_7_9_9 = ptys_p4_7_9;
            entered(once_job([=, names_p3_6_9_9 = std::move(names_p3_6_9_9), lx_p0_5_9_9 = std::move(lx_p0_5_9_9), clauses_p2_2_9_9 = std::move(clauses_p2_2_9_9), ptys_p4_7_9_9 = std::move(ptys_p4_7_9_9)]() {
            return ({
                auto en_pa = p0;
                auto i_pb = p1;
                ({
                auto [rs_pc, matched_pd] = or_(index(names_p3_6_9_9, i_pb), std::tuple{Text::lit(""), true});
                matched_pd
                ? prism_rtl::finished(en_pa)
                : call_then(crate::lower::types::start_out_ty_of(lx_p0_5_9_9, crate::lower::types::peel(or_(index(ptys_p4_7_9_9, i_pb), crate::check::types::Ty(crate::check::types::Ty::TyErr{})))), [=](crate::lower::model::OutTy out_ty_of_5056) { return prism_rtl::finished(crate::lower::types::bind(en_pa, plain_binder(lx_p0_5_9_9, or_(index(prism_rtl::deref(or_(index(clauses_p2_2_9_9, Nat(0u)), dummy_clause())).params, i_pb), crate::lower::patterns::dummy_pat())), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{rs_pc}), crate::lower::types::Holding(crate::lower::types::Holding::ByRef{}), out_ty_of_5056}))); });
            });
            });
        }));
        });
    })));
    })), [=](crate::lower::types::Env fold_4812) {
        return ({
            auto env1_p8 = fold_4812;
            auto scrut_ix_p9 = filter(crate::check::errors::range0(len(names_p3_6)), [&](const Nat& i_pe) {
                return ({
                    __label__ _done;
                    prism_rtl::Slot<bool> _v;
                    auto&& _m = index(names_p3_6, i_pe);
                    if (prism_rtl::is_some(_m) && std::get<1>(prism_rtl::some_of(_m))) {
                        _v.set(true);
                        goto _done;
                    }
                    {
                        _v.set(false);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
            });
            len(scrut_ix_p9) == Nat(0u)
            ? ({
            auto c_pf = or_(index(clauses_p2_2, Nat(0u)), dummy_clause());
            body_f5_1(std::tuple{lx_p0_5, env1_p8, prism_rtl::deref(c_pf).body})->cycle();
        })
            : ({
            auto scrut_pg = ({
                __label__ _done;
                prism_rtl::Slot<crate::lower::model::Ex> _v;
                {
                    auto&& m5353_0 = scrut_ix_p9;
                    if (m5353_0.size() == 1u) {
                        {
                            auto&& _c1 = index(m5353_0, Nat(0u));
                            if (prism_rtl::is_some(_c1)) {
                                auto&& i_pi = prism_rtl::some_of(_c1);
                                _v.set(crate::lower::model::Ex(crate::lower::model::Ex::XVar{or_(index(each(names_p3_6, [&](const std::tuple<Text, bool>& _p0) {
                                    auto&& n_pj = std::get<0>(_p0);
                                    return n_pj;
                                }), i_pi), Text::lit("arg"))}));
                                goto _done;
                            }
                        }
                    }
                }
                {
                    _v.set(crate::lower::model::Ex(crate::lower::model::Ex::XTuple{each(scrut_ix_p9, [&](const Nat& i_pk) {
                        return crate::lower::model::Ex(crate::lower::model::Ex::XVar{or_(index(each(names_p3_6, [&](const std::tuple<Text, bool>& _p0) {
                            auto&& n_pl = std::get<0>(_p0);
                            return n_pl;
                        }), i_pk), Text::lit("arg"))});
                    })}));
                    goto _done;
                }
            _done:
                _v.take();
            });
            call_value(each_job(crate::check::errors::range0(len(clauses_p2_2)), ({
            auto clauses_p2_2_9 = clauses_p2_2;
            auto scrut_ix_p9_9 = scrut_ix_p9;
            auto lx_p0_5_10 = lx_p0_5;
            auto ptys_p4_7_10 = ptys_p4_7;
            auto label_p6_4_10 = label_p6_4;
            auto body_f5_1_10 = body_f5_1;
            auto env1_p8_10 = env1_p8;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::XArm>(Nat)>>(prism_rtl::rc([=, clauses_p2_2_9 = std::move(clauses_p2_2_9), scrut_ix_p9_9 = std::move(scrut_ix_p9_9), lx_p0_5_10 = std::move(lx_p0_5_10), ptys_p4_7_10 = std::move(ptys_p4_7_10), label_p6_4_10 = std::move(label_p6_4_10), body_f5_1_10 = std::move(body_f5_1_10), env1_p8_10 = std::move(env1_p8_10)](Nat p0) {
            return ({
                auto clauses_p2_2_9_11 = clauses_p2_2_9;
                auto scrut_ix_p9_9_11 = scrut_ix_p9_9;
                auto lx_p0_5_10_11 = lx_p0_5_10;
                auto ptys_p4_7_10_11 = ptys_p4_7_10;
                auto label_p6_4_10_11 = label_p6_4_10;
                auto body_f5_1_10_11 = body_f5_1_10;
                auto env1_p8_10_11 = env1_p8_10;
                entered(once_job([=, clauses_p2_2_9_11 = std::move(clauses_p2_2_9_11), scrut_ix_p9_9_11 = std::move(scrut_ix_p9_9_11), lx_p0_5_10_11 = std::move(lx_p0_5_10_11), ptys_p4_7_10_11 = std::move(ptys_p4_7_10_11), label_p6_4_10_11 = std::move(label_p6_4_10_11), body_f5_1_10_11 = std::move(body_f5_1_10_11), env1_p8_10_11 = std::move(env1_p8_10_11)]() {
                return ({
                    auto ci_pm = p0;
                    ({
                    auto c_pn = or_(index(clauses_p2_2_9_11, ci_pm), dummy_clause());
                    call_value(each_job(scrut_ix_p9_9_11, ({
                    auto lx_p0_5_10_11_11 = lx_p0_5_10_11;
                    auto c_pn_11 = c_pn;
                    auto ptys_p4_7_10_11_12 = ptys_p4_7_10_11;
                    auto label_p6_4_10_11_12 = label_p6_4_10_11;
                    auto ci_pm_12 = ci_pm;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::patterns::PatOut>(Nat)>>(prism_rtl::rc([=, lx_p0_5_10_11_11 = std::move(lx_p0_5_10_11_11), c_pn_11 = std::move(c_pn_11), ptys_p4_7_10_11_12 = std::move(ptys_p4_7_10_11_12), label_p6_4_10_11_12 = std::move(label_p6_4_10_11_12), ci_pm_12 = std::move(ci_pm_12)](Nat p0) {
                    return ({
                        auto lx_p0_5_10_11_11_13 = lx_p0_5_10_11_11;
                        auto c_pn_11_13 = c_pn_11;
                        auto ptys_p4_7_10_11_12_13 = ptys_p4_7_10_11_12;
                        auto label_p6_4_10_11_12_13 = label_p6_4_10_11_12;
                        auto ci_pm_12_13 = ci_pm_12;
                        entered(once_job([=, lx_p0_5_10_11_11_13 = std::move(lx_p0_5_10_11_11_13), c_pn_11_13 = std::move(c_pn_11_13), ptys_p4_7_10_11_12_13 = std::move(ptys_p4_7_10_11_12_13), label_p6_4_10_11_12_13 = std::move(label_p6_4_10_11_12_13), ci_pm_12_13 = std::move(ci_pm_12_13)]() {
                        return ({
                            auto i_ps = p0;
                            (prism_rtl::more(prism_rtl::rc(crate::lower::patterns::RustPat(lx_p0_5_10_11_11_13, or_(index(prism_rtl::deref(c_pn_11_13).params, i_ps), crate::lower::patterns::dummy_pat()), or_(index(ptys_p4_7_10_11_12_13, i_ps), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), crate::lower::types::Holding(crate::lower::types::Holding::ByRef{}), prism_rtl::cat(label_p6_4_10_11_12_13, ci_pm_12_13, "_", i_ps)))));
                        });
                    }));
                    });
                })));
                })), [=](Array<crate::lower::patterns::PatOut> each_5668) {
                    return ({
                        auto pos_po = each_5668;
                        auto pa_pp = ({
                            __label__ _done;
                            prism_rtl::Slot<crate::lower::model::Pa> _v;
                            {
                                auto&& m5794_0 = pos_po;
                                if (m5794_0.size() == 1u) {
                                    {
                                        auto&& _c1 = index(m5794_0, Nat(0u));
                                        if (prism_rtl::is_some(_c1)) {
                                            auto&& o_pt = prism_rtl::some_of(_c1);
                                            _v.set(prism_rtl::deref(o_pt).pa);
                                            goto _done;
                                        }
                                    }
                                }
                            }
                            {
                                _v.set(crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{each(pos_po, [&](const crate::lower::patterns::PatOut& o_pu) { return prism_rtl::deref(o_pu).pa; })}));
                                goto _done;
                            }
                        _done:
                            _v.take();
                        });
                        auto conds_pq = fold(pos_po, Array<crate::lower::model::Cc>{}, [&](const Array<crate::lower::model::Cc>& acc_pv, const crate::lower::patterns::PatOut& o_p10) { return append(acc_pv, prism_rtl::deref(o_p10).conds); });
                        auto binds_pr = fold(pos_po, Array<std::tuple<Text, crate::lower::types::Bn>>{}, [&](const Array<std::tuple<Text, crate::lower::types::Bn>>& acc_p11, const crate::lower::patterns::PatOut& o_p12) { return append(acc_p11, prism_rtl::deref(o_p12).binds); });
                        call_value(body_f5_1_10_11(std::tuple{lx_p0_5_10_11, crate::lower::expr::bind_all(env1_p8_10_11, binds_pr), prism_rtl::deref(c_pn).body}), [=, pa_pp = std::move(pa_pp), conds_pq = std::move(conds_pq)](crate::lower::model::Ex body_6074) { return prism_rtl::finished(crate::lower::model::XArm{.pat = pa_pp, .conds = conds_pq, .body = body_6074}); });
                    });
                });
                });
                });
            }));
            });
        })));
        })), [=, scrut_pg = std::move(scrut_pg)](Array<crate::lower::model::XArm> each_5563) {
            return ({
                auto arms_ph = each_5563;
                (prism_rtl::finished(crate::lower::types::own(crate::lower::expr::arms_value(scrut_pg, arms_ph, prism_rtl::cat("\'", label_p6_4), t_p7_8))));
            });
        });
        });
        });
    });
}


/// `Start ClausesBody, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Ex> start_clauses_body(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, Array<crate::syntax::decls::FnClause> clauses_p2, Array<std::tuple<Text, bool>> names_p3, Array<crate::check::types::Ty> ptys_p4, prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::Lx, crate::lower::types::Env, crate::syntax::decls::FnBody>)> body_f5, Text label_p6, crate::lower::model::OutTy t_p7) {
    return prism_rtl::make_rc<ClausesBody>(lx_p0, env_p1, clauses_p2, names_p3, ptys_p4, body_f5, label_p6, t_p7);
}


/// let dummyClause
crate::syntax::decls::FnClause dummy_clause() {
    return crate::syntax::decls::FnClause{.name = crate::syntax::decls::DefName(crate::syntax::decls::DefName::DefOp{Text::lit(""), crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}}), .params = Array<crate::syntax::Pattern_>{}, .body = crate::syntax::decls::FnBody(crate::syntax::decls::FnBody::BodyExpr{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EError{})), .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}}}), .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}};
}


/// FnBodyValue: unbounded fn Lx, Env, FnBody -> Ex
crate::lower::model::Ex fn_body_value(const crate::lower::Lx& lx_p0, const crate::lower::types::Env& env_p1, const crate::syntax::decls::FnBody& fn_body2) {
    if (prism_rtl::is<crate::syntax::decls::FnBody::BodyExpr>(fn_body2)) {
        auto&& x_p2 = prism_rtl::as<crate::syntax::decls::FnBody::BodyExpr>(fn_body2).a0;
        return crate::lower::types::own(crate::lower::expr::value_of(lx_p0, env_p1, x_p2));
    }
    if (prism_rtl::is<crate::syntax::decls::FnBody::BodyBlock>(fn_body2)) {
        auto&& b_p5 = prism_rtl::as<crate::syntax::decls::FnBody::BodyBlock>(fn_body2).a0;
        return crate::lower::types::own(crate::lower::expr::block_value(lx_p0, env_p1, b_p5));
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::lower::model::Ex> FnBodyValue::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& env_p1 = this->env_p1;
    const auto& fn_body2 = this->fn_body2;
    return ({
        prism_rtl::is<crate::syntax::decls::FnBody::BodyExpr>(fn_body2) ? ({
        auto&& x_p2 = prism_rtl::as<crate::syntax::decls::FnBody::BodyExpr>(fn_body2).a0;
        ({
        auto env_p1_1 = env_p1;
        auto lx_p0_2 = lx_p0;
        auto x_p2_3 = x_p2;
        call_then(crate::lower::expr::start_value_of(lx_p0_2, env_p1_1, x_p2_3), [=](crate::lower::types::Vl value_of_6433) { return prism_rtl::finished(crate::lower::types::own(value_of_6433)); });
    });
    })
        : prism_rtl::is<crate::syntax::decls::FnBody::BodyBlock>(fn_body2) ? ({
        auto&& b_p5 = prism_rtl::as<crate::syntax::decls::FnBody::BodyBlock>(fn_body2).a0;
        ({
        auto b_p5_1 = b_p5;
        auto env_p1_2 = env_p1;
        auto lx_p0_3 = lx_p0;
        call_then(crate::lower::expr::start_block_value(lx_p0_3, env_p1_2, b_p5_1), [=](crate::lower::types::Vl block_value_6498) { return prism_rtl::finished(crate::lower::types::own(block_value_6498)); });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start FnBodyValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::Ex> start_fn_body_value(crate::lower::Lx lx_p0, crate::lower::types::Env env_p1, crate::syntax::decls::FnBody fn_body2) {
    return prism_rtl::make_rc<FnBodyValue>(lx_p0, env_p1, fn_body2);
}


/// FnDefOf: unbounded fn Lx, Text, [FnClause], Scheme -> FnDef
crate::lower::model::FnDef fn_def_of(const crate::lower::Lx& lx_p0, const Text& qk_p1, const Array<crate::syntax::decls::FnClause>& clauses_p2, const crate::check::types::Scheme& sc_p3) {
    auto [ptys0_pf, res_pg] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Array<crate::check::types::Ty>, crate::check::types::Ty>> _v;
        auto&& _m = sc_p3.ty;
        if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
            auto&& ps_pc = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a1;
            auto&& r_pd = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a2;
            _v.set(std::tuple{ps_pc, prism_rtl::deref(prism_rtl::deref(r_pd))});
            goto _done;
        }
        {
            auto&& other_pe = _m;
            _v.set(std::tuple{Array<crate::check::types::Ty>{}, other_pe});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto ptys_p4 = crate::lower::types::has_blueprint(res_pg)
        ? each(ptys0_pf, [&](const crate::check::types::Ty& p_ph) { return crate::lower::types::event_param(p_ph); })
        : ptys0_pf;
    auto pts_p5 = run_to_end(each_job(ptys_p4, ({
        auto lx_p0_1 = lx_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::OutTy>(crate::check::types::Ty)>>(prism_rtl::rc([=, lx_p0_1 = std::move(lx_p0_1)](crate::check::types::Ty p0) {
        return ({
            auto lx_p0_1_2 = lx_p0_1;
            entered(once_job([=, lx_p0_1_2 = std::move(lx_p0_1_2)]() {
            return ({
                auto p_pi = p0;
                (prism_rtl::more(prism_rtl::rc(crate::lower::types::OutTyOf(lx_p0_1_2, crate::lower::types::peel(p_pi)))));
            });
        }));
        });
    })));
    })));
    auto names_p6 = param_names(lx_p0, clauses_p2, pts_p5);
    auto body_p7 = clauses_body(lx_p0, crate::lower::types::empty_env(), clauses_p2, names_p6, ptys_p4, static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::Lx, crate::lower::types::Env, crate::syntax::decls::FnBody>)>>(prism_rtl::rc([&](std::tuple<crate::lower::Lx, crate::lower::types::Env, crate::syntax::decls::FnBody> _p0) {
        auto&& a0 = std::get<0>(_p0);
        auto&& a1 = std::get<1>(_p0);
        auto&& a2 = std::get<2>(_p0);
        return entered(start_fn_body_value(a0, a1, a2));
    })), Text::lit("c"), crate::lower::types::out_ty_of(lx_p0, crate::lower::types::peel(res_pg)));
    auto params_p8 = each(crate::check::errors::range0(len(pts_p5)), [&](const Nat& i_pj) {
        return std::tuple{or_(index(each(names_p6, [&](const std::tuple<Text, bool>& _p0) {
            auto&& n_pk = std::get<0>(_p0);
            return n_pk;
        }), i_pj), Text::lit("arg")), crate::lower::model::OutTy(crate::lower::model::OutTy::OutRef{prism_rtl::rc(or_(index(pts_p5, i_pj), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})))})};
    });
    auto ret_p9 = crate::lower::types::out_ty_of(lx_p0, crate::lower::types::peel(res_pg));
    auto used_pa = fold(crate::prelude::push(pts_p5, ret_p9), Array<Text>{}, [&](const Array<Text>& acc_pl, const crate::lower::model::OutTy& t_pm) { return crate::check::types::union_texts(acc_pl, ty_params_in(t_pm)); });
    auto generics_pb = filter(scheme_generics(lx_p0, sc_p3), [&](const std::tuple<Text, Array<Text>>& _p0) {
        auto&& g_pn = std::get<0>(_p0);
        return crate::check::types::has_text(used_pa, g_pn);
    });
    return crate::lower::model::FnDef{.name = or_(crate::prelude::get(lx_p0.rs_names, qk_p1), crate::lower::snake(crate::check::types::bare_name(qk_p1))), .generics = generics_pb, .params = params_p8, .ret = ret_p9, .body = body_p7, .doc = signature_text(lx_p0, qk_p1), .public_ = true};
}


prism_rtl::Turn<crate::lower::model::FnDef> FnDefOf::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& qk_p1 = this->qk_p1;
    const auto& clauses_p2 = this->clauses_p2;
    const auto& sc_p3 = this->sc_p3;
    auto [ptys0_pf, res_pg] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Array<crate::check::types::Ty>, crate::check::types::Ty>> _v;
        auto&& _m = prism_rtl::deref(sc_p3).ty;
        if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
            auto&& ps_pc = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a1;
            auto&& r_pd = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a2;
            _v.set(std::tuple{ps_pc, prism_rtl::deref(prism_rtl::deref(r_pd))});
            goto _done;
        }
        {
            auto&& other_pe = _m;
            _v.set(std::tuple{Array<crate::check::types::Ty>{}, other_pe});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto ptys_p4 = crate::lower::types::has_blueprint(res_pg)
        ? each(ptys0_pf, [&](const crate::check::types::Ty& p_ph) { return crate::lower::types::event_param(p_ph); })
        : ptys0_pf;
    auto clauses_p2_1 = clauses_p2;
    auto lx_p0_2 = lx_p0;
    auto qk_p1_3 = qk_p1;
    auto sc_p3_4 = sc_p3;
    return call_value(each_job(ptys_p4, ({
        auto lx_p0_2_5 = lx_p0_2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::OutTy>(crate::check::types::Ty)>>(prism_rtl::rc([=, lx_p0_2_5 = std::move(lx_p0_2_5)](crate::check::types::Ty p0) {
        return ({
            auto lx_p0_2_5_5 = lx_p0_2_5;
            entered(once_job([=, lx_p0_2_5_5 = std::move(lx_p0_2_5_5)]() {
            return ({
                auto p_pi = p0;
                (prism_rtl::more(prism_rtl::rc(crate::lower::types::OutTyOf(lx_p0_2_5_5, crate::lower::types::peel(p_pi)))));
            });
        }));
        });
    })));
    })), [=](Array<crate::lower::model::OutTy> each_7055) {
        return ({
            auto pts_p5 = each_7055;
            call_then(start_param_names(lx_p0_2, clauses_p2_1, pts_p5), [=](Array<std::tuple<Text, bool>> param_names_7108) {
            return ({
                auto names_p6 = param_names_7108;
                call_then(crate::lower::types::start_out_ty_of(lx_p0_2, crate::lower::types::peel(res_pg)), [=, names_p6 = std::move(names_p6)](crate::lower::model::OutTy out_ty_of_7218) {
                return call_then(start_clauses_body(lx_p0_2, crate::lower::types::empty_env(), clauses_p2_1, names_p6, ptys_p4, static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Ex>(std::tuple<crate::lower::Lx, crate::lower::types::Env, crate::syntax::decls::FnBody>)>>(prism_rtl::rc([&](std::tuple<crate::lower::Lx, crate::lower::types::Env, crate::syntax::decls::FnBody> _p0) {
                    auto&& a0 = std::get<0>(_p0);
                    auto&& a1 = std::get<1>(_p0);
                    auto&& a2 = std::get<2>(_p0);
                    return entered(start_fn_body_value(a0, a1, a2));
                })), Text::lit("c"), out_ty_of_7218), [=](crate::lower::model::Ex clauses_body_7151) {
                    return ({
                        auto body_p7 = clauses_body_7151;
                        auto params_p8 = each(crate::check::errors::range0(len(pts_p5)), [&](const Nat& i_pj) {
                            return std::tuple{or_(index(each(names_p6, [&](const std::tuple<Text, bool>& _p0) {
                                auto&& n_pk = std::get<0>(_p0);
                                return n_pk;
                            }), i_pj), Text::lit("arg")), crate::lower::model::OutTy(crate::lower::model::OutTy::OutRef{prism_rtl::rc(or_(index(pts_p5, i_pj), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})))})};
                        });
                        call_then(crate::lower::types::start_out_ty_of(lx_p0_2, crate::lower::types::peel(res_pg)), [=, body_p7 = std::move(body_p7), params_p8 = std::move(params_p8)](crate::lower::model::OutTy out_ty_of_7386) {
                        return ({
                            auto ret_p9 = out_ty_of_7386;
                            auto used_pa = fold(crate::prelude::push(pts_p5, ret_p9), Array<Text>{}, [&](const Array<Text>& acc_pl, const crate::lower::model::OutTy& t_pm) { return crate::check::types::union_texts(acc_pl, ty_params_in(t_pm)); });
                            auto generics_pb = filter(scheme_generics(lx_p0_2, sc_p3_4), [&](const std::tuple<Text, Array<Text>>& _p0) {
                                auto&& g_pn = std::get<0>(_p0);
                                return crate::check::types::has_text(used_pa, g_pn);
                            });
                            (prism_rtl::finished(crate::lower::model::FnDef{.name = or_(crate::prelude::get(prism_rtl::deref(lx_p0_2).rs_names, qk_p1_3), crate::lower::snake(crate::check::types::bare_name(qk_p1_3))), .generics = generics_pb, .params = params_p8, .ret = ret_p9, .body = body_p7, .doc = signature_text(lx_p0_2, qk_p1_3), .public_ = true}));
                        });
                    });
                    });
                });
            });
            });
        });
        });
    });
}


/// `Start FnDefOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::FnDef> start_fn_def_of(crate::lower::Lx lx_p0, Text qk_p1, Array<crate::syntax::decls::FnClause> clauses_p2, crate::check::types::Scheme sc_p3) {
    return prism_rtl::make_rc<FnDefOf>(lx_p0, qk_p1, clauses_p2, sc_p3);
}


/// TyParamsIn: fn OutTy -> [Text]
Array<Text> ty_params_in(const crate::lower::model::OutTy& t_p0) {
    if (prism_rtl::is<crate::lower::model::OutTy::OutGen>(t_p0)) {
        auto&& n_p1 = prism_rtl::as<crate::lower::model::OutTy::OutGen>(t_p0).a0;
        return Array(std::vector{n_p1});
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t_p0)) {
        auto&& ts_p2 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t_p0).a1;
        return fold(ts_p2, Array<Text>{}, [&](const Array<Text>& acc_p3, const crate::lower::model::OutTy& x_p4) { return crate::check::types::union_texts(acc_p3, ty_params_in(x_p4)); });
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutTuple>(t_p0)) {
        auto&& ts_p5 = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(t_p0).a0;
        return fold(ts_p5, Array<Text>{}, [&](const Array<Text>& acc_p6, const crate::lower::model::OutTy& x_p7) { return crate::check::types::union_texts(acc_p6, ty_params_in(x_p7)); });
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutFn>(t_p0)) {
        auto&& ts_p8 = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t_p0).a0;
        auto&& r_p9 = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t_p0).a1;
        return fold(ts_p8, ty_params_in(prism_rtl::deref(prism_rtl::deref(r_p9))), [&](const Array<Text>& acc_pa, const crate::lower::model::OutTy& x_pb) { return crate::check::types::union_texts(acc_pa, ty_params_in(x_pb)); });
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(t_p0)) {
        auto&& a_pc = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(t_p0).a0;
        auto&& r_pd = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(t_p0).a1;
        return crate::check::types::union_texts(ty_params_in(prism_rtl::deref(prism_rtl::deref(a_pc))), ty_params_in(prism_rtl::deref(prism_rtl::deref(r_pd))));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutMap>(t_p0)) {
        auto&& k_pe = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t_p0).a0;
        auto&& v_pf = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t_p0).a1;
        return crate::check::types::union_texts(ty_params_in(prism_rtl::deref(prism_rtl::deref(k_pe))), ty_params_in(prism_rtl::deref(prism_rtl::deref(v_pf))));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutOpt>(t_p0)) {
        auto&& x_pg = prism_rtl::as<crate::lower::model::OutTy::OutOpt>(t_p0).a0;
        return ty_params_in(prism_rtl::deref(prism_rtl::deref(x_pg)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutRes>(t_p0)) {
        auto&& x_ph = prism_rtl::as<crate::lower::model::OutTy::OutRes>(t_p0).a0;
        return ty_params_in(prism_rtl::deref(prism_rtl::deref(x_ph)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutArray>(t_p0)) {
        auto&& x_pi = prism_rtl::as<crate::lower::model::OutTy::OutArray>(t_p0).a0;
        return ty_params_in(prism_rtl::deref(prism_rtl::deref(x_pi)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutJob>(t_p0)) {
        auto&& x_pj = prism_rtl::as<crate::lower::model::OutTy::OutJob>(t_p0).a0;
        return ty_params_in(prism_rtl::deref(prism_rtl::deref(x_pj)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutEvent>(t_p0)) {
        auto&& x_pk = prism_rtl::as<crate::lower::model::OutTy::OutEvent>(t_p0).a0;
        return ty_params_in(prism_rtl::deref(prism_rtl::deref(x_pk)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutDyn>(t_p0)) {
        auto&& x_pl = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(t_p0).a0;
        return ty_params_in(prism_rtl::deref(prism_rtl::deref(x_pl)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutRc>(t_p0)) {
        auto&& x_pm = prism_rtl::as<crate::lower::model::OutTy::OutRc>(t_p0).a0;
        return ty_params_in(prism_rtl::deref(prism_rtl::deref(x_pm)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutRef>(t_p0)) {
        auto&& x_pn = prism_rtl::as<crate::lower::model::OutTy::OutRef>(t_p0).a0;
        return ty_params_in(prism_rtl::deref(prism_rtl::deref(x_pn)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutHold>(t_p0)) {
        auto&& x_po = prism_rtl::as<crate::lower::model::OutTy::OutHold>(t_p0).a0;
        return ty_params_in(prism_rtl::deref(prism_rtl::deref(x_po)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutCell>(t_p0)) {
        auto&& x_pp = prism_rtl::as<crate::lower::model::OutTy::OutCell>(t_p0).a0;
        return ty_params_in(prism_rtl::deref(prism_rtl::deref(x_pp)));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutLive>(t_p0)) {
        auto&& x_pq = prism_rtl::as<crate::lower::model::OutTy::OutLive>(t_p0).a0;
        return ty_params_in(prism_rtl::deref(prism_rtl::deref(x_pq)));
    }
    {
        return Array<Text>{};
    }
}


/// SignatureText: fn Lx, Text -> Text
Text signature_text(const crate::lower::Lx& lx_p0, const Text& qk_p1) {
    auto&& _m = crate::prelude::get(prism_rtl::deref(lx_p0.g).vals, qk_p1);
    if (prism_rtl::is_some(_m)) {
        auto&& v_p2 = prism_rtl::some_of(_m);
        auto&& _m = index(prism_rtl::deref(lx_p0.g).srcs, v_p2->file);
        if (prism_rtl::is_some(_m)) {
            auto&& src_p3 = prism_rtl::some_of(_m);
            return crate::syntax::lexer::chars::trim(crate::check::errors::span_text(src_p3, prism_rtl::deref(v_p2).span));
        }
        if (prism_rtl::is_none(_m)) {
            return crate::check::types::bare_name(qk_p1);
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is_none(_m)) {
        return crate::check::types::bare_name(qk_p1);
    }
    prism_rtl::unreachable("no arm matched");
}


/// DefinitionText: fn Lx, Text -> Text
Text definition_text(const crate::lower::Lx& lx_p0, const Text& qk_p1) {
    auto spans_p2 = fold(prism_rtl::deref(lx_p0.g).defs, Array<std::tuple<Nat, crate::syntax::Range>>{}, [&](const Array<std::tuple<Nat, crate::syntax::Range>>& acc_p4, const crate::check::env::Def& d_p5) {
        return prism_rtl::deref(d_p5).qk == qk_p1
            ? crate::prelude::push(acc_p4, std::tuple{d_p5->file, prism_rtl::deref(d_p5).span})
            : acc_p4;
    });
    auto sig_p3 = ({
        __label__ _done;
        prism_rtl::Slot<Array<std::tuple<Nat, crate::syntax::Range>>> _v;
        auto&& _m = crate::prelude::get(prism_rtl::deref(lx_p0.g).vals, qk_p1);
        if (prism_rtl::is_some(_m)) {
            auto&& v_p6 = prism_rtl::some_of(_m);
            _v.set(prism_rtl::deref(prism_rtl::deref(v_p6).span).start < or_(index(each(spans_p2, [&](const std::tuple<Nat, crate::syntax::Range>& _p0) {
                auto&& r_p7 = std::get<1>(_p0);
                return prism_rtl::deref(r_p7).start;
            }), Nat(0u)), Nat(0u))
                ? Array(std::vector{std::tuple{v_p6->file, prism_rtl::deref(v_p6).span}})
                : Array<std::tuple<Nat, crate::syntax::Range>>{});
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Array<std::tuple<Nat, crate::syntax::Range>>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return crate::syntax::lexer::chars::join(each(append(sig_p3, spans_p2), [&](const std::tuple<Nat, crate::syntax::Range>& _p0) {
        auto&& f_p8 = std::get<0>(_p0);
        auto&& r_p9 = std::get<1>(_p0);
        return src_text(lx_p0, f_p8, r_p9);
    }), Text::lit("\n"));
}


/// SrcText: fn Lx, Nat, Range -> Text
Text src_text(const crate::lower::Lx& lx_p0, const Nat& f_p1, const crate::syntax::Range& r_p2) {
    auto&& _m = index(prism_rtl::deref(lx_p0.g).srcs, f_p1);
    if (prism_rtl::is_some(_m)) {
        auto&& src_p3 = prism_rtl::some_of(_m);
        return drop_trailing_comments(crate::check::errors::span_text(src_p3, r_p2));
    }
    if (prism_rtl::is_none(_m)) {
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}


/// DropTrailingComments: fn Text -> Text
Text drop_trailing_comments(const Text& t_p0) {
    auto lines_p1 = split_on(t_p0, Text::lit("\n"));
    auto keep_p2 = fold(crate::check::errors::range0(len(lines_p1)), Nat(0u), [&](const Nat& k_p3, const Nat& i_p4) {
        return is_code_line(or_(index(lines_p1, i_p4), Text::lit("")))
            ? i_p4 + Nat(1u)
            : k_p3;
    });
    return crate::syntax::lexer::chars::trim_end(crate::syntax::lexer::chars::join(take(lines_p1, keep_p2), Text::lit("\n")));
}


/// IsCodeLine: fn Text -> Bool
bool is_code_line(const Text& l_p0) {
    auto s_p1 = crate::syntax::lexer::chars::trim(l_p0);
    return (s_p1 != Text::lit("")) && (!crate::syntax::lexer::chars::has_prefix(s_p1, Text::lit("#")));
}


/// LetGetter: unbounded fn Lx, Text, LetDecl -> FnDef
crate::lower::model::FnDef let_getter(const crate::lower::Lx& lx_p0, const Text& qk_p1, const crate::syntax::decls::LetDecl& l_p2) {
    auto t_p3 = crate::lower::types::out_ty_of(lx_p0, crate::lower::types::peel(crate::lower::type_at(lx_p0, prism_rtl::deref(l_p2.value).span)));
    auto v_p4 = crate::lower::expr::value_of(lx_p0, crate::lower::types::empty_env(), l_p2.value);
    return crate::lower::model::FnDef{.name = or_(crate::prelude::get(lx_p0.rs_names, qk_p1), crate::lower::snake(crate::check::types::bare_name(qk_p1))), .generics = Array<std::tuple<Text, Array<Text>>>{}, .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .ret = t_p3, .body = crate::lower::types::own(v_p4), .doc = prism_rtl::cat("let ", crate::check::types::bare_name(qk_p1)), .public_ = true};
}


prism_rtl::Turn<crate::lower::model::FnDef> LetGetter::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& qk_p1 = this->qk_p1;
    const auto& l_p2 = this->l_p2;
    auto l_p2_1 = l_p2;
    auto lx_p0_2 = lx_p0;
    auto qk_p1_3 = qk_p1;
    return call_then(crate::lower::types::start_out_ty_of(lx_p0_2, crate::lower::types::peel(crate::lower::type_at(lx_p0_2, prism_rtl::deref(l_p2_1->value).span))), [=](crate::lower::model::OutTy out_ty_of_10237) {
        return ({
            auto t_p3 = out_ty_of_10237;
            call_then(crate::lower::expr::start_value_of(lx_p0_2, crate::lower::types::empty_env(), l_p2_1->value), [=, t_p3 = std::move(t_p3)](crate::lower::types::Vl value_of_10294) {
            return ({
                auto v_p4 = value_of_10294;
                (prism_rtl::finished(crate::lower::model::FnDef{.name = or_(crate::prelude::get(prism_rtl::deref(lx_p0_2).rs_names, qk_p1_3), crate::lower::snake(crate::check::types::bare_name(qk_p1_3))), .generics = Array<std::tuple<Text, Array<Text>>>{}, .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .ret = t_p3, .body = crate::lower::types::own(v_p4), .doc = prism_rtl::cat("let ", crate::check::types::bare_name(qk_p1_3)), .public_ = true}));
            });
        });
        });
    });
}


/// `Start LetGetter, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::FnDef> start_let_getter(crate::lower::Lx lx_p0, Text qk_p1, crate::syntax::decls::LetDecl l_p2) {
    return prism_rtl::make_rc<LetGetter>(lx_p0, qk_p1, l_p2);
}


/// HasOwnShow: fn Lx, Text -> Bool
bool has_own_show(const crate::lower::Lx& lx_p0, const Text& tn_p1) {
    return fold(or_(crate::prelude::get(prism_rtl::deref(lx_p0.g).impls, Text::lit("Prelude.Show")), Array<crate::check::env::ImplInfo>{}), false, [&](const bool& f_p2, const crate::check::env::ImplInfo& im_p3) { return prism_rtl::deref(f_p2) || ((!prism_rtl::deref(im_p3).derived) && (head_name(prism_rtl::deref(im_p3).head) == tn_p1)); });
}


/// HeadName: fn Ty -> Text
Text head_name(const crate::check::types::Ty& ty0) {
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(ty0)) {
        auto&& n_p0 = prism_rtl::as<crate::check::types::Ty::TyCon>(ty0).a0;
        return n_p0;
    }
    {
        auto&& other_p1 = ty0;
        return Text::lit("");
    }
}


/// SelfIn: unbounded fn Ty, Text -> Ty
crate::check::types::Ty self_in(const crate::check::types::Ty& t_p0, const Text& param_p1) {
    return crate::lower::expr::instantiated(t_p0, Array(std::vector{param_p1}), Array(std::vector{crate::check::types::Ty(crate::check::types::Ty::TyCon{Text::lit("\000Self"sv), Array<crate::check::types::Ty>{}})}));
}


prism_rtl::Turn<crate::check::types::Ty> SelfIn::cycle() const {
    const auto& t_p0 = this->t_p0;
    const auto& param_p1 = this->param_p1;
    return prism_rtl::more(prism_rtl::rc(crate::lower::expr::Instantiated(t_p0, Array(std::vector{param_p1}), Array(std::vector{crate::check::types::Ty(crate::check::types::Ty::TyCon{Text::lit("\000Self"sv), Array<crate::check::types::Ty>{}})}))));
}


/// `Start SelfIn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::Ty> start_self_in(crate::check::types::Ty t_p0, Text param_p1) {
    return prism_rtl::make_rc<SelfIn>(t_p0, param_p1);
}


/// TraitDefOf: unbounded fn Lx, TraitInfo -> TraitDef
crate::lower::model::TraitDef trait_def_of(const crate::lower::Lx& lx0_p0, const crate::check::env::TraitInfo& tr_p1) {
    auto lx_p2 = crate::lower::program::in_module(lx0_p0, tr_p1.file, tr_p1.home);
    auto methods_p3 = run_to_end(each_job(tr_p1.methods, ({
        auto lx_p2_1 = lx_p2;
        auto tr_p1_2 = tr_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::FnDef>(Text)>>(prism_rtl::rc([=, lx_p2_1 = std::move(lx_p2_1), tr_p1_2 = std::move(tr_p1_2)](Text p0) {
        return ({
            auto lx_p2_1_3 = lx_p2_1;
            auto tr_p1_2_3 = tr_p1_2;
            entered(once_job([=, lx_p2_1_3 = std::move(lx_p2_1_3), tr_p1_2_3 = std::move(tr_p1_2_3)]() {
            return ({
                auto mq_p4 = p0;
                ({
                auto v_p5 = or_(crate::prelude::get(prism_rtl::deref(prism_rtl::deref(lx_p2_1_3).g).vals, mq_p4), crate::check::env::builtin(mq_p4, crate::check::types::schemes::mono(crate::check::types::Ty(crate::check::types::Ty::TyErr{}))));
                auto sc_p6 = ({
                    crate::check::types::Scheme this_ = prism_rtl::deref(v_p5).scheme;
                    this_.ty = self_in(this_.ty, tr_p1_2_3.param);
                    this_.qs = filter(this_.qs, [&](const Text& q_pa) { return q_pa != tr_p1_2_3.param; });
                    this_.bounds = filter(this_.bounds, [&](const std::tuple<Text, Text>& _p0) {
                        auto&& q_pb = std::get<0>(_p0);
                        return q_pb != tr_p1_2_3.param;
                    });
                    (std::move(this_));
                });
                auto default_qk_p7 = fold(tr_p1_2_3.defaults, Text::lit(""), [&](const Text& f_pc, const Text& dq_pd) {
                    return crate::check::types::bare_name(dq_pd) == crate::check::types::bare_name(mq_p4)
                        ? dq_pd
                        : f_pc;
                });
                auto clauses_p8 = default_qk_p7 == Text::lit("")
                    ? Array<crate::syntax::decls::FnClause>{}
                    : default_clauses(prism_rtl::deref(lx_p2_1_3).g, default_qk_p7);
                call_then(start_fn_def_of(lx_p2_1_3, mq_p4, len(clauses_p8) == Nat(0u)
                ? Array(std::vector{dummy_clause()})
                : clauses_p8, sc_p6), [=](crate::lower::model::FnDef fn_def_of_11831) {
                return ({
                    auto fd_p9 = fn_def_of_11831;
                    (prism_rtl::finished(({
                    crate::lower::model::FnDef this_ = fd_p9;
                    this_.public_ = len(clauses_p8) > Nat(0u);
                    (std::move(this_));
                })));
                });
            });
            });
            });
        }));
        });
    })));
    })));
    return crate::lower::model::TraitDef{.name = crate::lower::camel(crate::check::types::bare_name(tr_p1.name)), .methods = methods_p3, .defaults = tr_p1.defaults, .doc = crate::lower::program::type_doc(lx_p2, crate::check::env::TyInfo{.name = tr_p1.name, .home = tr_p1.home, .params = Array<Text>{}, .body = crate::check::env::TyBody(crate::check::env::TyBody::BOpaque{}), .derives = Array<Text>{}, .file = tr_p1.file, .span = tr_p1.span})};
}


prism_rtl::Turn<crate::lower::model::TraitDef> TraitDefOf::cycle() const {
    const auto& lx0_p0 = this->lx0_p0;
    const auto& tr_p1 = this->tr_p1;
    auto lx_p2 = crate::lower::program::in_module(lx0_p0, tr_p1->file, prism_rtl::deref(tr_p1).home);
    auto tr_p1_1 = tr_p1;
    return call_value(each_job(prism_rtl::deref(tr_p1_1).methods, ({
        auto lx_p2_2 = lx_p2;
        auto tr_p1_1_3 = tr_p1_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::FnDef>(Text)>>(prism_rtl::rc([=, lx_p2_2 = std::move(lx_p2_2), tr_p1_1_3 = std::move(tr_p1_1_3)](Text p0) {
        return ({
            auto lx_p2_2_3 = lx_p2_2;
            auto tr_p1_1_3_3 = tr_p1_1_3;
            entered(once_job([=, lx_p2_2_3 = std::move(lx_p2_2_3), tr_p1_1_3_3 = std::move(tr_p1_1_3_3)]() {
            return ({
                auto mq_p4 = p0;
                ({
                auto v_p5 = or_(crate::prelude::get(prism_rtl::deref(prism_rtl::deref(lx_p2_2_3).g).vals, mq_p4), crate::check::env::builtin(mq_p4, crate::check::types::schemes::mono(crate::check::types::Ty(crate::check::types::Ty::TyErr{}))));
                auto sc_p6 = ({
                    crate::check::types::Scheme this_ = prism_rtl::deref(v_p5).scheme;
                    this_.ty = self_in(this_.ty, prism_rtl::deref(tr_p1_1_3_3).param);
                    this_.qs = filter(this_.qs, [&](const Text& q_pa) { return q_pa != prism_rtl::deref(tr_p1_1_3_3).param; });
                    this_.bounds = filter(this_.bounds, [&](const std::tuple<Text, Text>& _p0) {
                        auto&& q_pb = std::get<0>(_p0);
                        return q_pb != prism_rtl::deref(tr_p1_1_3_3).param;
                    });
                    (std::move(this_));
                });
                auto default_qk_p7 = fold(prism_rtl::deref(tr_p1_1_3_3).defaults, Text::lit(""), [&](const Text& f_pc, const Text& dq_pd) {
                    return crate::check::types::bare_name(dq_pd) == crate::check::types::bare_name(mq_p4)
                        ? dq_pd
                        : f_pc;
                });
                auto clauses_p8 = default_qk_p7 == Text::lit("")
                    ? Array<crate::syntax::decls::FnClause>{}
                    : default_clauses(prism_rtl::deref(lx_p2_2_3).g, default_qk_p7);
                call_then(start_fn_def_of(lx_p2_2_3, mq_p4, len(clauses_p8) == Nat(0u)
                ? Array(std::vector{dummy_clause()})
                : clauses_p8, sc_p6), [=](crate::lower::model::FnDef fn_def_of_11831) {
                return ({
                    auto fd_p9 = fn_def_of_11831;
                    (prism_rtl::finished(({
                    crate::lower::model::FnDef this_ = fd_p9;
                    this_.public_ = len(clauses_p8) > Nat(0u);
                    (std::move(this_));
                })));
                });
            });
            });
            });
        }));
        });
    })));
    })), [=](Array<crate::lower::model::FnDef> each_11339) {
        return ({
            auto methods_p3 = each_11339;
            (prism_rtl::finished(crate::lower::model::TraitDef{.name = crate::lower::camel(crate::check::types::bare_name(prism_rtl::deref(tr_p1_1).name)), .methods = methods_p3, .defaults = prism_rtl::deref(tr_p1_1).defaults, .doc = crate::lower::program::type_doc(lx_p2, crate::check::env::TyInfo{.name = prism_rtl::deref(tr_p1_1).name, .home = prism_rtl::deref(tr_p1_1).home, .params = Array<Text>{}, .body = crate::check::env::TyBody(crate::check::env::TyBody::BOpaque{}), .derives = Array<Text>{}, .file = tr_p1_1->file, .span = prism_rtl::deref(tr_p1_1).span})}));
        });
    });
}


/// `Start TraitDefOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::TraitDef> start_trait_def_of(crate::lower::Lx lx0_p0, crate::check::env::TraitInfo tr_p1) {
    return prism_rtl::make_rc<TraitDefOf>(lx0_p0, tr_p1);
}


/// DefaultClauses: fn G, Text -> [FnClause]
Array<crate::syntax::decls::FnClause> default_clauses(const crate::check::env::G& g_p0, const Text& qk_p1) {
    return fold(g_p0.defs, Array<crate::syntax::decls::FnClause>{}, [&](const Array<crate::syntax::decls::FnClause>& acc_p2, const crate::check::env::Def& d_p3) { return prism_rtl::deref(d_p3).qk == qk_p1 ? default_of(d_p3, acc_p2) : acc_p2; });
}


/// DefaultOf: fn Def, [FnClause] -> [FnClause]
Array<crate::syntax::decls::FnClause> default_of(const crate::check::env::Def& d_p0, const Array<crate::syntax::decls::FnClause>& other_p1) {
    auto&& _m = d_p0.body;
    if (prism_rtl::is<crate::check::env::DefBody::DbDefault>(_m)) {
        auto&& cs_p2 = prism_rtl::as<crate::check::env::DefBody::DbDefault>(_m).a0;
        return cs_p2;
    }
    {
        return other_p1;
    }
}


/// ImplDefOf: unbounded fn Lx, ImplInfo -> ImplDef
crate::lower::model::ImplDef impl_def_of(const crate::lower::Lx& lx_p0, const crate::check::env::ImplInfo& im_p1) {
    auto tr_p2 = or_(crate::prelude::get(prism_rtl::deref(lx_p0.g).traits, im_p1.cls), crate::lower::expr::dummy_trait_info());
    auto head_p3 = crate::lower::types::out_ty_of(lx_p0, im_p1.head);
    auto defs_p4 = filter(prism_rtl::deref(lx_p0.g).defs, [&](const crate::check::env::Def& d_p7) { return is_method_of(d_p7, im_p1); });
    auto methods_p5 = run_to_end(each_job(defs_p4, ({
        auto tr_p2_1 = tr_p2;
        auto lx_p0_2 = lx_p0;
        auto im_p1_3 = im_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::FnDef>(crate::check::env::Def)>>(prism_rtl::rc([=, tr_p2_1 = std::move(tr_p2_1), lx_p0_2 = std::move(lx_p0_2), im_p1_3 = std::move(im_p1_3)](crate::check::env::Def p0) {
        return ({
            auto tr_p2_1_4 = tr_p2_1;
            auto lx_p0_2_4 = lx_p0_2;
            auto im_p1_3_4 = im_p1_3;
            entered(once_job([=, tr_p2_1_4 = std::move(tr_p2_1_4), lx_p0_2_4 = std::move(lx_p0_2_4), im_p1_3_4 = std::move(im_p1_3_4)]() {
            return ({
                auto d_p8 = p0;
                ({
                auto mq_p9 = fold(prism_rtl::deref(tr_p2_1_4).methods, Text::lit(""), [&](const Text& found_pd, const Text& q_pe) {
                    return crate::check::types::bare_name(q_pe) == prism_rtl::deref(d_p8).name
                        ? q_pe
                        : found_pd;
                });
                auto v_pa = or_(crate::prelude::get(prism_rtl::deref(lx_p0_2_4.g).vals, mq_p9), crate::check::env::builtin(mq_p9, crate::check::types::schemes::mono(crate::check::types::Ty(crate::check::types::Ty::TyErr{}))));
                auto sc_pb = ({
                    crate::check::types::Scheme this_ = prism_rtl::deref(v_pa).scheme;
                    this_.ty = crate::lower::expr::instantiated(this_.ty, Array(std::vector{prism_rtl::deref(tr_p2_1_4).param}), Array(std::vector{im_p1_3_4.head}));
                    this_.qs = filter(this_.qs, [&](const Text& q_pf) { return q_pf != prism_rtl::deref(tr_p2_1_4).param; });
                    this_.bounds = filter(this_.bounds, [&](const std::tuple<Text, Text>& _p0) {
                        auto&& q_pg = std::get<0>(_p0);
                        return q_pg != prism_rtl::deref(tr_p2_1_4).param;
                    });
                    (std::move(this_));
                });
                call_then(start_fn_def_of(lx_p0_2_4, mq_p9, method_clauses(d_p8), sc_pb), [=](crate::lower::model::FnDef fn_def_of_13164) {
                return ({
                    auto fd_pc = fn_def_of_13164;
                    (crate::syntax::lexer::chars::has_prefix(im_p1_3_4.cls, Text::lit("Prelude."))
                    ? prism_rtl::finished(renamed(fd_pc, prism_rtl::cat(crate::lower::snake(prism_rtl::deref(d_p8).name), "_", crate::lower::snake(crate::check::types::bare_name(head_name(im_p1_3_4.head))))))
                    : prism_rtl::finished(fd_pc));
                });
            });
            });
            });
        }));
        });
    })));
    })));
    auto generics_p6 = each(im_p1.qs, [&](const Text& q_ph) { return std::tuple{crate::lower::camel(q_ph), Array(std::vector{Text::lit("Clone")})}; });
    return crate::lower::model::ImplDef{.cls = im_p1.cls, .tr = crate::lower::path_in(lx_p0, prism_rtl::deref(tr_p2).home, crate::lower::camel(crate::check::types::bare_name(im_p1.cls))), .head = head_p3, .generics = generics_p6, .methods = methods_p5, .doc = Text::lit("")};
}


prism_rtl::Turn<crate::lower::model::ImplDef> ImplDefOf::cycle() const {
    const auto& lx_p0 = this->lx_p0;
    const auto& im_p1 = this->im_p1;
    auto tr_p2 = or_(crate::prelude::get(prism_rtl::deref(prism_rtl::deref(lx_p0).g).traits, prism_rtl::deref(im_p1).cls), crate::lower::expr::dummy_trait_info());
    auto im_p1_1 = im_p1;
    auto lx_p0_2 = lx_p0;
    return call_then(crate::lower::types::start_out_ty_of(lx_p0_2, prism_rtl::deref(im_p1_1).head), [=](crate::lower::model::OutTy out_ty_of_12657) {
        return ({
            auto head_p3 = out_ty_of_12657;
            auto defs_p4 = filter(prism_rtl::deref(prism_rtl::deref(lx_p0_2).g).defs, [&](const crate::check::env::Def& d_p7) { return is_method_of(d_p7, im_p1_1); });
            call_value(each_job(defs_p4, ({
            auto tr_p2_3 = tr_p2;
            auto lx_p0_2_4 = lx_p0_2;
            auto im_p1_1_4 = im_p1_1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::FnDef>(crate::check::env::Def)>>(prism_rtl::rc([=, tr_p2_3 = std::move(tr_p2_3), lx_p0_2_4 = std::move(lx_p0_2_4), im_p1_1_4 = std::move(im_p1_1_4)](crate::check::env::Def p0) {
            return ({
                auto tr_p2_3_4 = tr_p2_3;
                auto lx_p0_2_4_4 = lx_p0_2_4;
                auto im_p1_1_4_4 = im_p1_1_4;
                entered(once_job([=, tr_p2_3_4 = std::move(tr_p2_3_4), lx_p0_2_4_4 = std::move(lx_p0_2_4_4), im_p1_1_4_4 = std::move(im_p1_1_4_4)]() {
                return ({
                    auto d_p8 = p0;
                    ({
                    auto mq_p9 = fold(prism_rtl::deref(tr_p2_3_4).methods, Text::lit(""), [&](const Text& found_pd, const Text& q_pe) {
                        return crate::check::types::bare_name(q_pe) == prism_rtl::deref(d_p8).name
                            ? q_pe
                            : found_pd;
                    });
                    auto v_pa = or_(crate::prelude::get(prism_rtl::deref(prism_rtl::deref(lx_p0_2_4_4).g).vals, mq_p9), crate::check::env::builtin(mq_p9, crate::check::types::schemes::mono(crate::check::types::Ty(crate::check::types::Ty::TyErr{}))));
                    auto sc_pb = ({
                        crate::check::types::Scheme this_ = prism_rtl::deref(v_pa).scheme;
                        this_.ty = crate::lower::expr::instantiated(this_.ty, Array(std::vector{prism_rtl::deref(tr_p2_3_4).param}), Array(std::vector{prism_rtl::deref(im_p1_1_4_4).head}));
                        this_.qs = filter(this_.qs, [&](const Text& q_pf) { return q_pf != prism_rtl::deref(tr_p2_3_4).param; });
                        this_.bounds = filter(this_.bounds, [&](const std::tuple<Text, Text>& _p0) {
                            auto&& q_pg = std::get<0>(_p0);
                            return q_pg != prism_rtl::deref(tr_p2_3_4).param;
                        });
                        (std::move(this_));
                    });
                    call_then(start_fn_def_of(lx_p0_2_4_4, mq_p9, method_clauses(d_p8), sc_pb), [=](crate::lower::model::FnDef fn_def_of_13164) {
                    return ({
                        auto fd_pc = fn_def_of_13164;
                        (crate::syntax::lexer::chars::has_prefix(prism_rtl::deref(im_p1_1_4_4).cls, Text::lit("Prelude."))
                        ? prism_rtl::finished(renamed(fd_pc, prism_rtl::cat(crate::lower::snake(prism_rtl::deref(d_p8).name), "_", crate::lower::snake(crate::check::types::bare_name(head_name(prism_rtl::deref(im_p1_1_4_4).head))))))
                        : prism_rtl::finished(fd_pc));
                    });
                });
                });
                });
            }));
            });
        })));
        })), [=, head_p3 = std::move(head_p3)](Array<crate::lower::model::FnDef> each_12750) {
            return ({
                auto methods_p5 = each_12750;
                auto generics_p6 = each(prism_rtl::deref(im_p1_1).qs, [&](const Text& q_ph) { return std::tuple{crate::lower::camel(q_ph), Array(std::vector{Text::lit("Clone")})}; });
                (prism_rtl::finished(crate::lower::model::ImplDef{.cls = prism_rtl::deref(im_p1_1).cls, .tr = crate::lower::path_in(lx_p0_2, prism_rtl::deref(tr_p2).home, crate::lower::camel(crate::check::types::bare_name(prism_rtl::deref(im_p1_1).cls))), .head = head_p3, .generics = generics_p6, .methods = methods_p5, .doc = Text::lit("")}));
            });
        });
        });
    });
}


/// `Start ImplDefOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::lower::model::ImplDef> start_impl_def_of(crate::lower::Lx lx_p0, crate::check::env::ImplInfo im_p1) {
    return prism_rtl::make_rc<ImplDefOf>(lx_p0, im_p1);
}


/// Renamed: fn FnDef, Text -> FnDef
crate::lower::model::FnDef renamed(const crate::lower::model::FnDef& fd_p0, const Text& n_p1) {
    crate::lower::model::FnDef this_ = fd_p0;
    this_.name = n_p1;
    return this_;
}


/// IsMethodOf: fn Def, ImplInfo -> Bool
bool is_method_of(const crate::check::env::Def& d_p0, const crate::check::env::ImplInfo& im_p1) {
    auto&& _m = d_p0.body;
    if (prism_rtl::is<crate::check::env::DefBody::DbMethod>(_m)) {
        auto&& cls_p2 = prism_rtl::as<crate::check::env::DefBody::DbMethod>(_m).a1;
        auto&& other_p3 = prism_rtl::as<crate::check::env::DefBody::DbMethod>(_m).a2;
        return ((cls_p2 == im_p1.cls) && (prism_rtl::deref(other_p3).span == im_p1.span)) && (other_p3->file == im_p1.file);
    }
    {
        return false;
    }
}


/// MethodClauses: fn Def -> [FnClause]
Array<crate::syntax::decls::FnClause> method_clauses(const crate::check::env::Def& d_p0) {
    auto&& _m = d_p0.body;
    if (prism_rtl::is<crate::check::env::DefBody::DbMethod>(_m)) {
        auto&& cs_p1 = prism_rtl::as<crate::check::env::DefBody::DbMethod>(_m).a0;
        return cs_p1;
    }
    {
        return Array<crate::syntax::decls::FnClause>{};
    }
}


/// IfGenLine: unbounded fn Wx, Env, Expr, Block, Block, Expr -> ((Wx, Wres))
std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> if_gen_line(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& menv_p1, const crate::syntax::Expr& c_p2, const crate::syntax::Block& then_b_p3, const crate::syntax::Block& else_b_p4, const crate::syntax::Expr& e_p5) {
    auto lx_p6 = wx_p0.lx;
    auto pos_p7 = wx_p0.pos;
    auto wx1_p8 = ({
        crate::lower::node_::Wx this_ = wx_p0;
        this_.pos = crate::lower::model::next_pos(this_.pos);
        (std::move(this_));
    });
    auto [name_ph, wx2_pi] = crate::lower::node_::fresh_name(wx1_p8, Text::lit("arm"));
    auto base_p9 = prism_rtl::cat(wx_p0.node_, crate::lower::camel(name_ph), crate::lower::node_::keyed::row_suffix(wx_p0));
    auto yes_pa = crate::lower::node_::switch_::gen_row_of(wx2_pi, menv_p1, then_b_p3, crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), prism_rtl::cat(base_p9, "Then"), name_ph);
    auto no_pb = crate::lower::node_::switch_::gen_row_of(yes_pa->parent, menv_p1, else_b_p4, crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), prism_rtl::cat(base_p9, "Else"), name_ph);
    auto cond_pc = crate::lower::types::as_bool(crate::lower::expr::value_of(lx_p6, menv_p1, c_p2));
    auto tail_pd = append(append(Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XWeak{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{}))})}), crate::lower::node_::keyed::hosted_passed(wx_p0)), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})}));
    auto mk_fe = ({
        auto tail_pd_1 = tail_pd;
        (static_cast<Fn<crate::lower::model::Ex(const crate::lower::model::NodeDef&)>>(prism_rtl::rc([=, tail_pd_1 = std::move(tail_pd_1)](const crate::lower::model::NodeDef& n_pj) { return crate::lower::model::Ex(crate::lower::model::Ex::XCast{prism_rtl::rc(crate::lower::expr::try_of(crate::lower::model::Ex(crate::lower::model::Ex::XCall{prism_rtl::cat(prism_rtl::deref(n_pj).name, "::build"), append(Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("path")}), crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("value")})}), tail_pd_1)}))), crate::lower::model::OutTy(crate::lower::model::OutTy::OutObj{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Row"), Array<crate::lower::model::OutTy>{}}))})}); })));
    });
    auto select_pf = crate::lower::model::Ex(crate::lower::model::Ex::XIf{prism_rtl::rc(cond_pc), prism_rtl::rc(mk_fe(prism_rtl::deref(yes_pa).node_)), prism_rtl::rc(mk_fe(prism_rtl::deref(no_pb).node_))});
    auto wx3_pg = ({
        crate::lower::node_::Wx this_ = no_pb->parent;
        this_.gens = crate::prelude::push(this_.gens, crate::lower::model::GenDef{.name = name_ph, .pos = pos_p7, .at = crate::lower::node_::finish::place_at(wx_p0, Text::lit("self"), pos_p7), .source = crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), .value_ty = crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), .select = select_pf, .transparent = false, .width = Nat(0u), .moved = or_(crate::lower::node_::finish::hosted_rows(wx_p0), Text::lit(""))});
        this_.gen_holds = crate::prelude::push(this_.gen_holds, std::tuple{name_ph, Array<crate::lower::node_::Read>{}});
        this_.rows = append(append(append(crate::prelude::push(this_.rows, prism_rtl::deref(yes_pa).node_), prism_rtl::deref(prism_rtl::deref(yes_pa).node_).children), Array(std::vector{prism_rtl::deref(no_pb).node_})), prism_rtl::deref(prism_rtl::deref(no_pb).node_).children);
        this_.getters = crate::prelude::push(this_.getters, crate::lower::model::MethDef{.name = prism_rtl::cat(name_ph, "_up"), .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRc{}), .params = Array(std::vector{std::tuple{Text::lit("v"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})}}), .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxMut{}), .ret = crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), .body = Array<crate::lower::model::Do>{}, .tail = crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), .doc = Text::lit("An arm\'s result, which a building `if` of widgets drops.")});
        (std::move(this_));
    });
    return std::tuple{wx3_pg, crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{})};
}


prism_rtl::Turn<std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres>> IfGenLine::cycle() const {
    const auto& wx_p0 = this->wx_p0;
    const auto& menv_p1 = this->menv_p1;
    const auto& c_p2 = this->c_p2;
    const auto& then_b_p3 = this->then_b_p3;
    const auto& else_b_p4 = this->else_b_p4;
    const auto& e_p5 = this->e_p5;
    auto lx_p6 = prism_rtl::deref(wx_p0).lx;
    auto pos_p7 = prism_rtl::deref(wx_p0).pos;
    auto wx1_p8 = ({
        crate::lower::node_::Wx this_ = wx_p0;
        this_.pos = crate::lower::model::next_pos(this_.pos);
        (std::move(this_));
    });
    auto [name_ph, wx2_pi] = crate::lower::node_::fresh_name(wx1_p8, Text::lit("arm"));
    auto base_p9 = prism_rtl::cat(prism_rtl::deref(wx_p0).node_, crate::lower::camel(name_ph), crate::lower::node_::keyed::row_suffix(wx_p0));
    auto yes_pa = crate::lower::node_::switch_::gen_row_of(wx2_pi, menv_p1, then_b_p3, crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), prism_rtl::cat(base_p9, "Then"), name_ph);
    auto no_pb = crate::lower::node_::switch_::gen_row_of(yes_pa->parent, menv_p1, else_b_p4, crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), prism_rtl::cat(base_p9, "Else"), name_ph);
    auto c_p2_1 = c_p2;
    auto menv_p1_2 = menv_p1;
    auto wx_p0_3 = wx_p0;
    return call_then(crate::lower::expr::start_value_of(lx_p6, menv_p1_2, c_p2_1), [=](crate::lower::types::Vl value_of_14630) {
        return ({
            auto cond_pc = crate::lower::types::as_bool(value_of_14630);
            auto tail_pd = append(append(Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XWeak{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{}))})}), crate::lower::node_::keyed::hosted_passed(wx_p0_3)), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})}));
            auto mk_fe = ({
                auto tail_pd_4 = tail_pd;
                (static_cast<Fn<crate::lower::model::Ex(const crate::lower::model::NodeDef&)>>(prism_rtl::rc([=, tail_pd_4 = std::move(tail_pd_4)](const crate::lower::model::NodeDef& n_pj) { return crate::lower::model::Ex(crate::lower::model::Ex::XCast{prism_rtl::rc(crate::lower::expr::try_of(crate::lower::model::Ex(crate::lower::model::Ex::XCall{prism_rtl::cat(prism_rtl::deref(n_pj).name, "::build"), append(Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("path")}), crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("value")})}), tail_pd_4)}))), crate::lower::model::OutTy(crate::lower::model::OutTy::OutObj{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Row"), Array<crate::lower::model::OutTy>{}}))})}); })));
            });
            auto select_pf = crate::lower::model::Ex(crate::lower::model::Ex::XIf{prism_rtl::rc(cond_pc), prism_rtl::rc(mk_fe(prism_rtl::deref(yes_pa).node_)), prism_rtl::rc(mk_fe(prism_rtl::deref(no_pb).node_))});
            auto wx3_pg = ({
                crate::lower::node_::Wx this_ = no_pb->parent;
                this_.gens = crate::prelude::push(this_.gens, crate::lower::model::GenDef{.name = name_ph, .pos = pos_p7, .at = crate::lower::node_::finish::place_at(wx_p0_3, Text::lit("self"), pos_p7), .source = crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), .value_ty = crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), .select = select_pf, .transparent = false, .width = Nat(0u), .moved = or_(crate::lower::node_::finish::hosted_rows(wx_p0_3), Text::lit(""))});
                this_.gen_holds = crate::prelude::push(this_.gen_holds, std::tuple{name_ph, Array<crate::lower::node_::Read>{}});
                this_.rows = append(append(append(crate::prelude::push(this_.rows, prism_rtl::deref(yes_pa).node_), prism_rtl::deref(prism_rtl::deref(yes_pa).node_).children), Array(std::vector{prism_rtl::deref(no_pb).node_})), prism_rtl::deref(prism_rtl::deref(no_pb).node_).children);
                this_.getters = crate::prelude::push(this_.getters, crate::lower::model::MethDef{.name = prism_rtl::cat(name_ph, "_up"), .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRc{}), .params = Array(std::vector{std::tuple{Text::lit("v"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})}}), .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxMut{}), .ret = crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), .body = Array<crate::lower::model::Do>{}, .tail = crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), .doc = Text::lit("An arm\'s result, which a building `if` of widgets drops.")});
                (std::move(this_));
            });
            (prism_rtl::finished(std::tuple{wx3_pg, crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{})}));
        });
    });
}


/// `Start IfGenLine, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres>> start_if_gen_line(crate::lower::node_::Wx wx_p0, crate::lower::types::Env menv_p1, crate::syntax::Expr c_p2, crate::syntax::Block then_b_p3, crate::syntax::Block else_b_p4, crate::syntax::Expr e_p5) {
    return prism_rtl::make_rc<IfGenLine>(wx_p0, menv_p1, c_p2, then_b_p3, else_b_p4, e_p5);
}

}  // namespace crate::lower::functions
