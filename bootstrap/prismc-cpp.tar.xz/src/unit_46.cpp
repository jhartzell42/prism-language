// The module `Lower.Node.Keyed`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <lower/node_/keyed/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Lower.Node.Keyed`, from `target/bootstrap/cpp-src/prismc/lower/node/keyed.prism`.
namespace crate::lower::node_::keyed {

Pod RowLocal::to_pod() const {
    return Pod::record("RowLocal", {{"name", prism_rtl::to_pod(name)}, {"field", prism_rtl::to_pod(field)}, {"ty", prism_rtl::to_pod(ty)}, {"passed", prism_rtl::to_pod(passed)}});
}

Result<RowLocal> RowLocal::from_pod(const Pod& whole) {
    return RowLocal{.name = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .field = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "field")))), .ty = TRY(prism_rtl::from_pod<crate::lower::model::OutTy>(TRY(crate::prelude::field(whole, "ty")))), .passed = TRY(prism_rtl::from_pod<crate::lower::model::Ex>(TRY(crate::prelude::field(whole, "passed"))))};
}


/// ForLine: unbounded fn Wx, Env, Env, ?ForBinders, Expr, Block, Expr, ?Bn -> ((Wx, Wres))
std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> for_line(const crate::lower::node_::Wx& wx, const crate::lower::types::Env& benv, const crate::lower::types::Env& menv, const std::optional<crate::syntax::ForBinders>& binders_opt, const crate::syntax::Expr& source, const crate::syntax::Block& body, const crate::syntax::Expr& e, const std::optional<crate::lower::types::Bn>& bound_opt) {
    auto lx = wx.lx;
    auto pos = wx.pos;
    auto wx1 = ({
        crate::lower::node_::Wx this_ = wx;
        this_.pos = crate::lower::model::next_pos(this_.pos);
        this_;
    });
    auto [src_ex, reads] = crate::lower::node_::dynamics::dynamic_expr(wx1, menv, source);
    auto src_ty = crate::lower::types::peel(crate::lower::type_at(lx, source.span));
    auto [kt, vt, keyed] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::lower::model::OutTy, crate::lower::model::OutTy, bool>> _v;
        if (prism_rtl::is<crate::check::types::Ty::TyMap>(src_ty)) {
            auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(src_ty).a0;
            auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(src_ty).a1;
            _v.set(std::tuple{crate::lower::types::out_ty_of(lx, k), crate::lower::types::out_ty_of(lx, v_), true});
            goto _done;
        }
        if (prism_rtl::is<crate::check::types::Ty::TyArray>(src_ty)) {
            auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyArray>(src_ty).a0;
            _v.set(std::tuple{crate::lower::model::OutTy(crate::lower::model::OutTy::OutNat{}), crate::lower::types::out_ty_of(lx, v_), false});
            goto _done;
        }
        {
            _v.set(std::tuple{crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), true});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto src = keyed
        ? src_ex
        : crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("indexed"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(src_ex)})})});
    auto base = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        if (prism_rtl::is_some(bound_opt) && prism_rtl::is<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(bound_opt))) {
            auto&& er = prism_rtl::as<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(bound_opt)).a0;
            _v.set(crate::lower::node_::gn_of(wx1, er.node_).name);
            goto _done;
        }
        {
            _v.set(Text::lit("rows"));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto [name, wx2a] = crate::lower::node_::fresh_name(wx1, base);
    auto src_getter = prism_rtl::cat(name, "_source");
    auto src_cached = crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(src_getter, "_cache")})), Text::lit("get"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{}), crate::lower::model::Ex(crate::lower::model::Ex::XClosure{false, Array<crate::lower::model::Pa>{}, prism_rtl::rc(src)})})});
    auto src_def = crate::lower::model::MethDef{.name = src_getter, .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxRef{}), .ret = crate::lower::model::OutTy(crate::lower::model::OutTy::OutMap{prism_rtl::rc(kt), prism_rtl::rc(vt)}), .body = Array<crate::lower::model::Do>{}, .tail = src_cached, .doc = prism_rtl::cat("The source of the `for` at place ", crate::lower::model::place_text(pos), " by key, at the read point: what its builder and its rows\' entries read, computed once per write behind it.")};
    auto row_name = prism_rtl::cat(wx.node_, row_suffix(wx), "Row");
    auto locals = row_locals(benv, menv, body);
    auto row_fields = append(Array(std::vector{std::tuple{Text::lit("key"), kt, Text::lit("the row\'s key")}, std::tuple{Text::lit("left_entry"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutCell{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutOpt{prism_rtl::rc(vt)}))}), Text::lit("the entry as the tick its key left opened, kept from the row\'s leaving on (R8)")}, std::tuple{Text::lit("parent"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutWeak{wx.node_}), Text::lit("the node of the `for`")}}), each(locals, [&](const RowLocal& l) { return std::tuple{l.field, l.ty, prism_rtl::cat("`", l.name, "`, the block\'s")}; }));
    auto row_moves = append(Array(std::vector{std::tuple{Text::lit("key"), crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("key")}))})}, std::tuple{Text::lit("left_entry"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("RefCell::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XNone{})})})}, std::tuple{Text::lit("parent"), crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("parent")})}}), each(locals, [&](const RowLocal& l) { return std::tuple{l.field, crate::lower::model::Ex(crate::lower::model::Ex::XVar{l.field})}; }));
    auto row_taken = append(append(crate::lower::node_::node_hooks(), Array(std::vector{Text::lit("key"), Text::lit("value"), Text::lit("parent"), Text::lit("entry"), Text::lit("left_entry")})), each(locals, [&](const RowLocal& l) { return l.field; }));
    auto row_wx0 = crate::lower::node_::new_wx(lx, row_name, row_fields, Array<std::tuple<Text, crate::lower::model::Ex>>{}, row_moves, Array(std::vector{entry_getter(src_getter, vt)}), map_of(std::vector{std::tuple{Text::lit("entry"), Array(std::vector{crate::lower::node_::Read(crate::lower::node_::Read::ParentRead{src_getter})})}}), row_taken, wx.inlining, crate::lower::node_::finish::hosted_rows(wx));
    auto [wx2p, row_wx0p, ports] = crate::lower::node_::switch_::row_env(wx2a, row_wx0, menv, body);
    auto wx2 = ({
        crate::lower::node_::Wx this_ = crate::lower::node_::add_field(wx2p, prism_rtl::cat(src_getter, "_cache"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Cache"), Array(std::vector{crate::lower::model::OutTy(crate::lower::model::OutTy::OutMap{prism_rtl::rc(kt), prism_rtl::rc(vt)})})}), prism_rtl::cat("the source of the `for` at place ", crate::lower::model::place_text(pos), ", cached (gap SR)"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Cache::new"), Array<crate::lower::model::Ex>{}}));
        this_.taken = append(this_.taken, Array(std::vector{src_getter, prism_rtl::cat(src_getter, "_cache")}));
        this_.getters = crate::prelude::push(this_.getters, src_def);
        this_.dyn_reads = insert(this_.dyn_reads, src_getter, reads);
        this_;
    });
    auto key_b = crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("key")}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), kt});
    auto key_m = crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), Text::lit("key")}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), kt});
    auto benv_l = events_of(ports, fold(locals, row_reads(benv, crate::lower::node_::switch_::parent_arg()), [&](const crate::lower::types::Env& en, const RowLocal& l) { return crate::lower::types::bind(en, l.name, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{l.field}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), l.ty})); }));
    auto menv_l = events_of(ports, fold(locals, row_reads(menv, crate::lower::node_::switch_::parent_ref()), [&](const crate::lower::types::Env& en, const RowLocal& l) { return crate::lower::types::bind(en, l.name, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), l.field}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), l.ty})); }));
    auto passed = append(hosted_passed(wx), each(locals, [&](const RowLocal& l) { return l.passed; }));
    auto row_params = append(append(Array(std::vector{std::tuple{Text::lit("key"), kt}, std::tuple{Text::lit("value"), vt}, std::tuple{Text::lit("parent"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutWeak{wx.node_})}}), hosted_params(wx)), each(locals, [&](const RowLocal& l) { return std::tuple{l.field, l.ty}; }));
    auto [row_wx0f, val_b, val_m, inner] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::lower::node_::Wx, crate::lower::types::Bn, crate::lower::types::Bn, crate::lower::model::OutTy>> _v;
        if (prism_rtl::is<crate::lower::model::OutTy::OutDyn>(vt)) {
            auto&& t = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(vt).a0;
            _v.set(({
                auto [fname, row_wx_n] = crate::lower::node_::fresh_name(row_wx0p, crate::lower::snake(for_value_name(binders_opt)));
                auto [row_wx_f, fres] = crate::lower::node_::switch_::entry_flatten(row_wx_n, t, std::optional(crate::lower::types::Bn(crate::lower::types::Bn::BnHold{fname, t})));
                auto fb = crate::lower::node_::def::bundle_bn(fres);
                std::tuple{row_wx_f, fb, fb, t};
            }));
            goto _done;
        }
        {
            _v.set(({
                auto entry_m = crate::lower::types::Bn(crate::lower::types::Bn::BnDyn{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), Text::lit("entry"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), Array(std::vector{crate::lower::node_::Read(crate::lower::node_::Read::ParentRead{src_getter})}), vt});
                std::tuple{row_wx0p, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("value")}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), vt}), entry_m, vt};
            }));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto [rbe, rme] = for_envs(benv_l, menv_l, binders_opt, key_b, key_m, val_b, val_m, inner);
    auto row_wx = crate::lower::node_::def::block_into(row_wx0f, rbe, rme, body);
    auto wx3 = ({
        crate::lower::node_::Wx this_ = wx2;
        this_.row_marks = crate::prelude::push(this_.row_marks, crate::lower::node_::RowMarks{.builder = name, .reads = row_place_reads(row_wx), .wrote = crate::lower::node_::finish::row_hears(row_wx), .kind = crate::lower::model::RowKind(crate::lower::model::RowKind::ForRow{})});
        this_;
    });
    auto full = crate::lower::type_at(lx, e.span);
    auto out_ty = crate::lower::types::out_ty_of(lx, crate::lower::types::peel(full));
    auto&& _m = row_wx->result;
    if (prism_rtl::is<crate::lower::node_::Wres::WrEv>(_m)) {
        auto&& r = prism_rtl::as<crate::lower::node_::Wres::WrEv>(_m).a0;
        auto [gid, wx4] = crate::lower::node_::add_gn(wx3, prism_rtl::cat(name, "_all"), out_ty, crate::lower::node_::GnKind(crate::lower::node_::GnKind::GnGather{}), Nat(1u));
        auto wx5 = crate::lower::node_::add_field_last(wx4, prism_rtl::cat(name, "_gathered"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutStamped{prism_rtl::rc(out_ty)}), Text::lit("the rows\' firings this tick, by key"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Stamped::new"), Array<crate::lower::model::Ex>{}}));
        auto wx6 = ({
            crate::lower::node_::Wx this_ = wx5;
            this_.gns = each(this_.gns, [&](const crate::lower::node_::Gn& n) {
                return n.id == gid
                    ? crate::lower::node_::dynamics::with_inputs(n, Array(std::vector{prism_rtl::cat(name, "_gathered")}))
                    : n;
            });
            this_;
        });
        auto row_done = crate::lower::node_::connect(row_wx, r, crate::lower::node_::Sk(crate::lower::node_::Sk::SkUp{prism_rtl::cat(name, "_all_in")}));
        auto wx7 = add_builder(wx6, name, pos, kt, vt, row_name, keyed, reads, crate::lower::node_::PendingRow{.wx = row_done, .qk = row_name, .params = row_params, .gather = std::optional(gid)}, passed);
        return std::tuple{wx7, crate::lower::node_::Wres(crate::lower::node_::Wres::WrEv{crate::lower::node_::ev_ref_of(wx7, gid)})};
    }
    if (prism_rtl::is<crate::lower::node_::Wres::WrDyn>(_m)) {
        auto&& ex = prism_rtl::as<crate::lower::node_::Wres::WrDyn>(_m).a0;
        auto&& result_reads = prism_rtl::as<crate::lower::node_::Wres::WrDyn>(_m).a1;
        auto&& rt = prism_rtl::as<crate::lower::node_::Wres::WrDyn>(_m).a2;
        auto gathered = prism_rtl::cat(name, "_all");
        auto gathered_ty = crate::lower::model::OutTy(crate::lower::model::OutTy::OutMap{prism_rtl::rc(kt), prism_rtl::rc(rt)});
        auto own_behind = filter(crate::lower::node_::finish::reads_closed(row_wx.dyn_reads, result_reads), [&](const crate::lower::node_::Read& r) {
            return ({
                __label__ _done;
                prism_rtl::Slot<bool> _v;
                if (prism_rtl::is<crate::lower::node_::Read::OwnRead>(r)) {
                    _v.set(true);
                    goto _done;
                }
                if (prism_rtl::is<crate::lower::node_::Read::ParentRead>(r)) {
                    _v.set(false);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
        });
        auto row_done = ({
            crate::lower::node_::Wx this_ = row_wx;
            this_.getters = crate::prelude::push(this_.getters, crate::lower::model::MethDef{.name = Text::lit("result"), .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxRef{}), .ret = rt, .body = Array<crate::lower::model::Do>{}, .tail = ex, .doc = Text::lit("The row\'s result, which the block gathers by key.")});
            this_.result_moved = len(own_behind) > Nat(0u)
                ? std::optional(std::tuple{prism_rtl::cat(gathered, "_moved"), own_behind})
                : std::optional<std::tuple<Text, Array<crate::lower::node_::Read>>>{};
            this_;
        });
        auto wx4 = add_builder(wx3, name, pos, kt, vt, row_name, keyed, reads, crate::lower::node_::PendingRow{.wx = row_done, .qk = row_name, .params = row_params, .gather = std::optional<Nat>{}}, passed);
        auto all = crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), name})), Text::lit("borrow"), Array<crate::lower::model::Ex>{}})), Text::lit("iter"), Array<crate::lower::model::Ex>{}})), Text::lit("map"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{false, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("k")}), crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("row")})})})}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XTuple{Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("k")}))}), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("row")})), Text::lit("result"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})})}))})})})), Text::lit("collect"), Array<crate::lower::model::Ex>{}});
        auto what = prism_rtl::cat("the dynamic gathered by the `for` at place ", crate::lower::model::place_text(pos));
        auto wx5 = ({
            crate::lower::node_::Wx this_ = wx4;
            this_.taken = append(this_.taken, Array(std::vector{gathered, prism_rtl::cat(gathered, "_now"), prism_rtl::cat(gathered, "_snap"), prism_rtl::cat(gathered, "_moved"), prism_rtl::cat(gathered, "_publish")}));
            this_.getters = append(this_.getters, Array(std::vector{crate::lower::model::MethDef{.name = prism_rtl::cat(gathered, "_now"), .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxRef{}), .ret = gathered_ty, .body = Array<crate::lower::model::Do>{}, .tail = all, .doc = Text::lit("The rows\' results by key, computed live: what the snapshot of the `for`\'s dynamic is taken from (pick ST).")}, crate::lower::node_::static_::snap_getter(gathered, gathered_ty, Text::lit("The `for`\'s dynamic, the rows\' results by key, a structural dynamic (pick ST): one tick behind the rows, the snapshot of the tick before the tick the read point is after."))}));
            this_.fields = crate::prelude::push(this_.fields, std::tuple{prism_rtl::cat(gathered, "_snap"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutSnapshot{prism_rtl::rc(gathered_ty)}), prism_rtl::cat("the `for` at place ", crate::lower::model::place_text(pos), "\'s gathered dynamic, structural: its snapshots, the rows\' results and the lagged dynamic (pick ST)")});
            this_.inits = crate::prelude::push(this_.inits, std::tuple{prism_rtl::cat(gathered, "_snap"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Snapshot::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XStr{what})})})});
            this_.snaps = crate::prelude::push(this_.snaps, crate::lower::node_::SnapDef{.name = gathered, .live = prism_rtl::cat(gathered, "_now"), .ty = gathered_ty, .eq = crate::lower::program::ty_has_eq(lx, crate::lower::types::peel(full), Array<Text>{}), .builder = name, .before = false, .what = what});
            this_.dyn_reads = insert(this_.dyn_reads, prism_rtl::cat(gathered, "_now"), crate::lower::node_::union_reads(reads, block_reads(crate::lower::node_::finish::reads_closed(row_wx.dyn_reads, result_reads))));
            this_;
        });
        return std::tuple{wx5, crate::lower::node_::Wres(crate::lower::node_::Wres::WrDyn{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), gathered, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), Array(std::vector{crate::lower::node_::Read(crate::lower::node_::Read::OwnRead{gathered})}), gathered_ty})};
    }
    if (prism_rtl::is<crate::lower::node_::Wres::WrParts>(_m)) {
        auto wx4 = ({
            crate::lower::node_::Wx this_ = wx3;
            this_.build = crate::prelude::push(this_.build, crate::lower::expr::refusal_do(Text::lit("a `for` whose rows end on a bundle (Semantics ch. 4: gathered part by part)")));
            this_;
        });
        return std::tuple{wx4, crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{})};
    }
    {
        auto wx4 = add_builder(wx3, name, pos, kt, vt, row_name, keyed, reads, crate::lower::node_::PendingRow{.wx = row_wx, .qk = row_name, .params = row_params, .gather = std::optional<Nat>{}}, passed);
        return std::tuple{wx4, crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{})};
    }
}


prism_rtl::Turn<std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres>> ForLine::cycle() const {
    const auto& wx = this->wx;
    const auto& benv = this->benv;
    const auto& menv = this->menv;
    const auto& binders_opt = this->binders_opt;
    const auto& source = this->source;
    const auto& body = this->body;
    const auto& e = this->e;
    const auto& bound_opt = this->bound_opt;
    auto lx = wx.lx;
    auto pos = wx.pos;
    auto wx1 = ({
        crate::lower::node_::Wx this_ = wx;
        this_.pos = crate::lower::model::next_pos(this_.pos);
        this_;
    });
    auto binders_opt_1 = binders_opt;
    auto bound_opt_2 = bound_opt;
    auto benv_3 = benv;
    auto body_4 = body;
    auto e_5 = e;
    auto menv_6 = menv;
    auto source_7 = source;
    auto wx_8 = wx;
    return call_then(crate::lower::node_::dynamics::start_dynamic_expr(wx1, menv_6, source_7), [=](std::tuple<crate::lower::model::Ex, Array<crate::lower::node_::Read>> dynamic_expr_1801) {
        return ({
            auto [src_ex, reads] = dynamic_expr_1801;
            auto src_ty = crate::lower::types::peel(crate::lower::type_at(lx, source_7.span));
            auto [kt, vt, keyed] = ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<crate::lower::model::OutTy, crate::lower::model::OutTy, bool>> _v;
                if (prism_rtl::is<crate::check::types::Ty::TyMap>(src_ty)) {
                    auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(src_ty).a0;
                    auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(src_ty).a1;
                    _v.set(std::tuple{crate::lower::types::out_ty_of(lx, k), crate::lower::types::out_ty_of(lx, v_), true});
                    goto _done;
                }
                if (prism_rtl::is<crate::check::types::Ty::TyArray>(src_ty)) {
                    auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyArray>(src_ty).a0;
                    _v.set(std::tuple{crate::lower::model::OutTy(crate::lower::model::OutTy::OutNat{}), crate::lower::types::out_ty_of(lx, v_), false});
                    goto _done;
                }
                {
                    _v.set(std::tuple{crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), true});
                    goto _done;
                }
            _done:
                _v.take();
            });
            auto src = keyed
                ? src_ex
                : crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("indexed"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(src_ex)})})});
            auto base = ({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                if (prism_rtl::is_some(bound_opt) && prism_rtl::is<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(bound_opt))) {
                    auto&& er = prism_rtl::as<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(bound_opt)).a0;
                    _v.set(crate::lower::node_::gn_of(wx1, er.node_).name);
                    goto _done;
                }
                {
                    _v.set(Text::lit("rows"));
                    goto _done;
                }
            _done:
                _v.take();
            });
            auto [name, wx2a] = crate::lower::node_::fresh_name(wx1, base);
            auto src_getter = prism_rtl::cat(name, "_source");
            auto src_cached = crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(src_getter, "_cache")})), Text::lit("get"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{}), crate::lower::model::Ex(crate::lower::model::Ex::XClosure{false, Array<crate::lower::model::Pa>{}, prism_rtl::rc(src)})})});
            auto src_def = crate::lower::model::MethDef{.name = src_getter, .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxRef{}), .ret = crate::lower::model::OutTy(crate::lower::model::OutTy::OutMap{prism_rtl::rc(kt), prism_rtl::rc(vt)}), .body = Array<crate::lower::model::Do>{}, .tail = src_cached, .doc = prism_rtl::cat("The source of the `for` at place ", crate::lower::model::place_text(pos), " by key, at the read point: what its builder and its rows\' entries read, computed once per write behind it.")};
            auto row_name = prism_rtl::cat(wx_8.node_, row_suffix(wx_8), "Row");
            auto locals = row_locals(benv_3, menv_6, body_4);
            auto row_fields = append(Array(std::vector{std::tuple{Text::lit("key"), kt, Text::lit("the row\'s key")}, std::tuple{Text::lit("left_entry"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutCell{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutOpt{prism_rtl::rc(vt)}))}), Text::lit("the entry as the tick its key left opened, kept from the row\'s leaving on (R8)")}, std::tuple{Text::lit("parent"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutWeak{wx_8.node_}), Text::lit("the node of the `for`")}}), each(locals, [&](const RowLocal& l) { return std::tuple{l.field, l.ty, prism_rtl::cat("`", l.name, "`, the block\'s")}; }));
            auto row_moves = append(Array(std::vector{std::tuple{Text::lit("key"), crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("key")}))})}, std::tuple{Text::lit("left_entry"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("RefCell::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XNone{})})})}, std::tuple{Text::lit("parent"), crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("parent")})}}), each(locals, [&](const RowLocal& l) { return std::tuple{l.field, crate::lower::model::Ex(crate::lower::model::Ex::XVar{l.field})}; }));
            auto row_taken = append(append(crate::lower::node_::node_hooks(), Array(std::vector{Text::lit("key"), Text::lit("value"), Text::lit("parent"), Text::lit("entry"), Text::lit("left_entry")})), each(locals, [&](const RowLocal& l) { return l.field; }));
            auto row_wx0 = crate::lower::node_::new_wx(lx, row_name, row_fields, Array<std::tuple<Text, crate::lower::model::Ex>>{}, row_moves, Array(std::vector{entry_getter(src_getter, vt)}), map_of(std::vector{std::tuple{Text::lit("entry"), Array(std::vector{crate::lower::node_::Read(crate::lower::node_::Read::ParentRead{src_getter})})}}), row_taken, wx_8.inlining, crate::lower::node_::finish::hosted_rows(wx_8));
            auto [wx2p, row_wx0p, ports] = crate::lower::node_::switch_::row_env(wx2a, row_wx0, menv_6, body_4);
            auto wx2 = ({
                crate::lower::node_::Wx this_ = crate::lower::node_::add_field(wx2p, prism_rtl::cat(src_getter, "_cache"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("Cache"), Array(std::vector{crate::lower::model::OutTy(crate::lower::model::OutTy::OutMap{prism_rtl::rc(kt), prism_rtl::rc(vt)})})}), prism_rtl::cat("the source of the `for` at place ", crate::lower::model::place_text(pos), ", cached (gap SR)"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Cache::new"), Array<crate::lower::model::Ex>{}}));
                this_.taken = append(this_.taken, Array(std::vector{src_getter, prism_rtl::cat(src_getter, "_cache")}));
                this_.getters = crate::prelude::push(this_.getters, src_def);
                this_.dyn_reads = insert(this_.dyn_reads, src_getter, reads);
                this_;
            });
            auto key_b = crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("key")}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), kt});
            auto key_m = crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), Text::lit("key")}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), kt});
            auto benv_l = events_of(ports, fold(locals, row_reads(benv_3, crate::lower::node_::switch_::parent_arg()), [&](const crate::lower::types::Env& en, const RowLocal& l) { return crate::lower::types::bind(en, l.name, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{l.field}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), l.ty})); }));
            auto menv_l = events_of(ports, fold(locals, row_reads(menv_6, crate::lower::node_::switch_::parent_ref()), [&](const crate::lower::types::Env& en, const RowLocal& l) { return crate::lower::types::bind(en, l.name, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), l.field}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), l.ty})); }));
            auto passed = append(hosted_passed(wx_8), each(locals, [&](const RowLocal& l) { return l.passed; }));
            auto row_params = append(append(Array(std::vector{std::tuple{Text::lit("key"), kt}, std::tuple{Text::lit("value"), vt}, std::tuple{Text::lit("parent"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutWeak{wx_8.node_})}}), hosted_params(wx_8)), each(locals, [&](const RowLocal& l) { return std::tuple{l.field, l.ty}; }));
            auto [row_wx0f, val_b, val_m, inner] = ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<crate::lower::node_::Wx, crate::lower::types::Bn, crate::lower::types::Bn, crate::lower::model::OutTy>> _v;
                if (prism_rtl::is<crate::lower::model::OutTy::OutDyn>(vt)) {
                    auto&& t = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(vt).a0;
                    _v.set(({
                        auto [fname, row_wx_n] = crate::lower::node_::fresh_name(row_wx0p, crate::lower::snake(for_value_name(binders_opt_1)));
                        auto [row_wx_f, fres] = crate::lower::node_::switch_::entry_flatten(row_wx_n, t, std::optional(crate::lower::types::Bn(crate::lower::types::Bn::BnHold{fname, t})));
                        auto fb = crate::lower::node_::def::bundle_bn(fres);
                        std::tuple{row_wx_f, fb, fb, t};
                    }));
                    goto _done;
                }
                {
                    _v.set(({
                        auto entry_m = crate::lower::types::Bn(crate::lower::types::Bn::BnDyn{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), Text::lit("entry"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), Array(std::vector{crate::lower::node_::Read(crate::lower::node_::Read::ParentRead{src_getter})}), vt});
                        std::tuple{row_wx0p, crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("value")}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), vt}), entry_m, vt};
                    }));
                    goto _done;
                }
            _done:
                _v.take();
            });
            auto [rbe, rme] = for_envs(benv_l, menv_l, binders_opt_1, key_b, key_m, val_b, val_m, inner);
            call_then(crate::lower::node_::def::start_block_into(row_wx0f, rbe, rme, body_4), [=](crate::lower::node_::Wx block_into_6193) {
            return ({
                auto row_wx = block_into_6193;
                auto wx3 = ({
                    crate::lower::node_::Wx this_ = wx2;
                    this_.row_marks = crate::prelude::push(this_.row_marks, crate::lower::node_::RowMarks{.builder = name, .reads = row_place_reads(row_wx), .wrote = crate::lower::node_::finish::row_hears(row_wx), .kind = crate::lower::model::RowKind(crate::lower::model::RowKind::ForRow{})});
                    this_;
                });
                auto full = crate::lower::type_at(lx, e_5.span);
                call_then(crate::lower::types::start_out_ty_of(lx, crate::lower::types::peel(full)), [=](crate::lower::model::OutTy out_ty_of_6432) {
                return ({
                    auto out_ty = out_ty_of_6432;
                    ({
                    auto&& _m = row_wx->result;
                    prism_rtl::is<crate::lower::node_::Wres::WrEv>(_m) ? ({
                    auto&& r = prism_rtl::as<crate::lower::node_::Wres::WrEv>(_m).a0;
                    ({
                    auto [gid, wx4] = crate::lower::node_::add_gn(wx3, prism_rtl::cat(name, "_all"), out_ty, crate::lower::node_::GnKind(crate::lower::node_::GnKind::GnGather{}), Nat(1u));
                    auto wx5 = crate::lower::node_::add_field_last(wx4, prism_rtl::cat(name, "_gathered"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutStamped{prism_rtl::rc(out_ty)}), Text::lit("the rows\' firings this tick, by key"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Stamped::new"), Array<crate::lower::model::Ex>{}}));
                    auto wx6 = ({
                        crate::lower::node_::Wx this_ = wx5;
                        this_.gns = each(this_.gns, [&](const crate::lower::node_::Gn& n) {
                            return n.id == gid
                                ? crate::lower::node_::dynamics::with_inputs(n, Array(std::vector{prism_rtl::cat(name, "_gathered")}))
                                : n;
                        });
                        this_;
                    });
                    auto row_done = crate::lower::node_::connect(row_wx, r, crate::lower::node_::Sk(crate::lower::node_::Sk::SkUp{prism_rtl::cat(name, "_all_in")}));
                    auto wx7 = add_builder(wx6, name, pos, kt, vt, row_name, keyed, reads, crate::lower::node_::PendingRow{.wx = row_done, .qk = row_name, .params = row_params, .gather = std::optional(gid)}, passed);
                    (prism_rtl::finished(std::tuple{wx7, crate::lower::node_::Wres(crate::lower::node_::Wres::WrEv{crate::lower::node_::ev_ref_of(wx7, gid)})}));
                });
                })
                    : prism_rtl::is<crate::lower::node_::Wres::WrDyn>(_m) ? ({
                    auto&& ex = prism_rtl::as<crate::lower::node_::Wres::WrDyn>(_m).a0;
                    auto&& result_reads = prism_rtl::as<crate::lower::node_::Wres::WrDyn>(_m).a1;
                    auto&& rt = prism_rtl::as<crate::lower::node_::Wres::WrDyn>(_m).a2;
                    ({
                    auto gathered = prism_rtl::cat(name, "_all");
                    auto gathered_ty = crate::lower::model::OutTy(crate::lower::model::OutTy::OutMap{prism_rtl::rc(kt), prism_rtl::rc(rt)});
                    auto own_behind = filter(crate::lower::node_::finish::reads_closed(row_wx.dyn_reads, result_reads), [&](const crate::lower::node_::Read& r) {
                        return ({
                            __label__ _done;
                            prism_rtl::Slot<bool> _v;
                            if (prism_rtl::is<crate::lower::node_::Read::OwnRead>(r)) {
                                _v.set(true);
                                goto _done;
                            }
                            if (prism_rtl::is<crate::lower::node_::Read::ParentRead>(r)) {
                                _v.set(false);
                                goto _done;
                            }
                            prism_rtl::unreachable("no arm matched");
                        _done:
                            _v.take();
                        });
                    });
                    auto row_done = ({
                        crate::lower::node_::Wx this_ = row_wx;
                        this_.getters = crate::prelude::push(this_.getters, crate::lower::model::MethDef{.name = Text::lit("result"), .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxRef{}), .ret = rt, .body = Array<crate::lower::model::Do>{}, .tail = ex, .doc = Text::lit("The row\'s result, which the block gathers by key.")});
                        this_.result_moved = len(own_behind) > Nat(0u)
                            ? std::optional(std::tuple{prism_rtl::cat(gathered, "_moved"), own_behind})
                            : std::optional<std::tuple<Text, Array<crate::lower::node_::Read>>>{};
                        this_;
                    });
                    auto wx4 = add_builder(wx3, name, pos, kt, vt, row_name, keyed, reads, crate::lower::node_::PendingRow{.wx = row_done, .qk = row_name, .params = row_params, .gather = std::optional<Nat>{}}, passed);
                    auto all = crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), name})), Text::lit("borrow"), Array<crate::lower::model::Ex>{}})), Text::lit("iter"), Array<crate::lower::model::Ex>{}})), Text::lit("map"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{false, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("k")}), crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("row")})})})}), prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XTuple{Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("k")}))}), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("row")})), Text::lit("result"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})})}))})})})), Text::lit("collect"), Array<crate::lower::model::Ex>{}});
                    auto what = prism_rtl::cat("the dynamic gathered by the `for` at place ", crate::lower::model::place_text(pos));
                    auto wx5 = ({
                        crate::lower::node_::Wx this_ = wx4;
                        this_.taken = append(this_.taken, Array(std::vector{gathered, prism_rtl::cat(gathered, "_now"), prism_rtl::cat(gathered, "_snap"), prism_rtl::cat(gathered, "_moved"), prism_rtl::cat(gathered, "_publish")}));
                        this_.getters = append(this_.getters, Array(std::vector{crate::lower::model::MethDef{.name = prism_rtl::cat(gathered, "_now"), .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxRef{}), .ret = gathered_ty, .body = Array<crate::lower::model::Do>{}, .tail = all, .doc = Text::lit("The rows\' results by key, computed live: what the snapshot of the `for`\'s dynamic is taken from (pick ST).")}, crate::lower::node_::static_::snap_getter(gathered, gathered_ty, Text::lit("The `for`\'s dynamic, the rows\' results by key, a structural dynamic (pick ST): one tick behind the rows, the snapshot of the tick before the tick the read point is after."))}));
                        this_.fields = crate::prelude::push(this_.fields, std::tuple{prism_rtl::cat(gathered, "_snap"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutSnapshot{prism_rtl::rc(gathered_ty)}), prism_rtl::cat("the `for` at place ", crate::lower::model::place_text(pos), "\'s gathered dynamic, structural: its snapshots, the rows\' results and the lagged dynamic (pick ST)")});
                        this_.inits = crate::prelude::push(this_.inits, std::tuple{prism_rtl::cat(gathered, "_snap"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Snapshot::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XStr{what})})})});
                        this_.snaps = crate::prelude::push(this_.snaps, crate::lower::node_::SnapDef{.name = gathered, .live = prism_rtl::cat(gathered, "_now"), .ty = gathered_ty, .eq = crate::lower::program::ty_has_eq(lx, crate::lower::types::peel(full), Array<Text>{}), .builder = name, .before = false, .what = what});
                        this_.dyn_reads = insert(this_.dyn_reads, prism_rtl::cat(gathered, "_now"), crate::lower::node_::union_reads(reads, block_reads(crate::lower::node_::finish::reads_closed(row_wx.dyn_reads, result_reads))));
                        this_;
                    });
                    (prism_rtl::finished(std::tuple{wx5, crate::lower::node_::Wres(crate::lower::node_::Wres::WrDyn{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), gathered, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), Array(std::vector{crate::lower::node_::Read(crate::lower::node_::Read::OwnRead{gathered})}), gathered_ty})}));
                });
                })
                    : prism_rtl::is<crate::lower::node_::Wres::WrParts>(_m) ? ({
                    auto wx4 = ({
                        crate::lower::node_::Wx this_ = wx3;
                        this_.build = crate::prelude::push(this_.build, crate::lower::expr::refusal_do(Text::lit("a `for` whose rows end on a bundle (Semantics ch. 4: gathered part by part)")));
                        this_;
                    });
                    (prism_rtl::finished(std::tuple{wx4, crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{})}));
                })
                    : ({
                    auto wx4 = add_builder(wx3, name, pos, kt, vt, row_name, keyed, reads, crate::lower::node_::PendingRow{.wx = row_wx, .qk = row_name, .params = row_params, .gather = std::optional<Nat>{}}, passed);
                    (prism_rtl::finished(std::tuple{wx4, crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{})}));
                });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start ForLine, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres>> start_for_line(crate::lower::node_::Wx wx, crate::lower::types::Env benv, crate::lower::types::Env menv, std::optional<crate::syntax::ForBinders> binders_opt, crate::syntax::Expr source, crate::syntax::Block body, crate::syntax::Expr e, std::optional<crate::lower::types::Bn> bound_opt) {
    return prism_rtl::make_rc<ForLine>(wx, benv, menv, binders_opt, source, body, e, bound_opt);
}


/// EntryGetter: fn Text, OutTy -> MethDef
crate::lower::model::MethDef entry_getter(const Text& src_getter, const crate::lower::model::OutTy& vt) {
    auto found = crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("parent")})), src_getter, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})), Text::lit("get"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), Text::lit("key")}))})})})), Text::lit("cloned"), Array<crate::lower::model::Ex>{}});
    auto opened_1 = crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XCx{})), Text::lit("before"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClosure{false, Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("cx")})}), prism_rtl::rc(found)})})})), Text::lit("expect"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XStr{Text::lit("a row\'s key is in its source as its tick opened")})})});
    auto body = Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoIfLet{crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("v")})})}), crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), Text::lit("left_entry")})), Text::lit("borrow"), Array<crate::lower::model::Ex>{}})), Text::lit("as_ref"), Array<crate::lower::model::Ex>{}}), Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoReturn{crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("v")}))})})}), Array<crate::lower::model::Do>{}}), crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("parent")}), crate::lower::node_::switch_::parent_ref()})});
    auto tail = crate::lower::model::Ex(crate::lower::model::Ex::XMatch{prism_rtl::rc(found), Array(std::vector{crate::lower::model::XArm{.pat = crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("v")})})}), .conds = Array<crate::lower::model::Cc>{}, .body = crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("v")})}, crate::lower::model::XArm{.pat = crate::lower::model::Pa(crate::lower::model::Pa::PaUnit{Text::lit("None")}), .conds = Array<crate::lower::model::Cc>{}, .body = opened_1}}), false, vt});
    return crate::lower::model::MethDef{.name = Text::lit("entry"), .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxRef{}), .ret = vt, .body = body, .tail = tail, .doc = Text::lit("The row\'s entry, `$_`: the block\'s source at this key, at the read point; from the row\'s leaving on, the value as the leaving tick opened.")};
}


/// AddBuilder: fn Wx, Text, Pos, OutTy, OutTy, Text, Bool, [Read], PendingRow, [Ex] -> Wx
crate::lower::node_::Wx add_builder(const crate::lower::node_::Wx& wx, const Text& name, const crate::lower::model::Pos_& pos, const crate::lower::model::OutTy& kt, const crate::lower::model::OutTy& vt, const Text& row_name, const bool& keyed, const Array<crate::lower::node_::Read>& reads, const crate::lower::node_::PendingRow& waiting, const Array<crate::lower::model::Ex>& passed) {
    auto wx0 = crate::lower::node_::add_field_last(wx, name, crate::lower::model::OutTy(crate::lower::model::OutTy::OutCell{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutMap{prism_rtl::rc(kt), prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutRc{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{row_name, Array<crate::lower::model::OutTy>{}}))}))}))}), prism_rtl::cat("the rows of the `for` at place ", crate::lower::model::place_text(pos)), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("RefCell::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Map::new"), Array<crate::lower::model::Ex>{}})})}));
    auto wx1 = crate::lower::node_::add_field_last(wx0, prism_rtl::cat(name, "_from"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutCell{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutMap{prism_rtl::rc(kt), prism_rtl::rc(vt)}))}), prism_rtl::cat("the source the rows of the `for` at place ", crate::lower::model::place_text(pos), " were last built from"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("RefCell::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Map::new"), Array<crate::lower::model::Ex>{}})})}));
    auto replaced = each(filter(waiting.wx.flattens, [&](const crate::lower::node_::FlatDef& fl) { return fl->generation == Text::lit(""); }), [&](const crate::lower::node_::FlatDef& fl) { return prism_rtl::cat(fl.name, "_replaced"); });
    crate::lower::node_::Wx this_ = wx1;
    this_.builders = crate::prelude::push(this_.builders, crate::lower::model::ForDef{.name = name, .pos = pos, .at = crate::lower::node_::finish::place_at(wx, Text::lit("self"), pos), .key_ty = kt, .value_ty = vt, .row_node = row_name, .keyed = keyed, .source = prism_rtl::cat(name, "_source"), .parent = crate::lower::model::Ex(crate::lower::model::Ex::XWeak{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{}))}), .passed = passed, .moved = or_(crate::lower::node_::finish::hosted_rows(wx), Text::lit("")), .replaced = replaced});
    this_.build_holds = crate::lower::node_::union_reads(this_.build_holds, reads);
    this_.pending = crate::prelude::push(this_.pending, waiting);
    return this_;
}


/// ForValueName: fn ?ForBinders -> Text
Text for_value_name(const std::optional<crate::syntax::ForBinders>& binders_opt) {
    if (prism_rtl::is_some(binders_opt)) {
        auto&& fb = prism_rtl::some_of(binders_opt);
        auto&& _m = fb.second;
        if (prism_rtl::is_some(_m)) {
            auto&& p_ = prism_rtl::some_of(_m);
            return pattern_name_or(p_, Text::lit("flatten"));
        }
        if (prism_rtl::is_none(_m)) {
            return pattern_name_or(fb.first, Text::lit("flatten"));
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is_none(binders_opt)) {
        return Text::lit("flatten");
    }
    prism_rtl::unreachable("no arm matched");
}


/// PatternNameOr: fn Pattern, Text -> Text
Text pattern_name_or(const crate::syntax::Pattern_& p_, const Text& other) {
    auto&& _m = p_.kind;
    if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        return crate::check::env::sname_key(n);
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PGroup>(_m)) {
        auto&& q = prism_rtl::as<crate::syntax::PatternKind::PGroup>(_m).a0;
        return pattern_name_or(q, other);
    }
    {
        return other;
    }
}


/// RowPlaceReads: fn Wx -> [Read]
Array<crate::lower::node_::Read> row_place_reads(const crate::lower::node_::Wx& row_wx) {
    return fold(row_wx.places, Array<crate::lower::node_::Read>{}, [&](const Array<crate::lower::node_::Read>& acc, const crate::lower::node_::Place& pl) { return crate::lower::node_::union_reads(acc, block_reads(crate::lower::node_::finish::reads_closed(row_wx.dyn_reads, pl.reads))); });
}


/// HostedParams: fn Wx -> [((Text, OutTy))]
Array<std::tuple<Text, crate::lower::model::OutTy>> hosted_params(const crate::lower::node_::Wx& wx) {
    auto&& _m = crate::lower::node_::finish::hosted_rows(wx);
    if (prism_rtl::is_some(_m)) {
        return Array(std::vector{std::tuple{Text::lit("enclosing"), crate::lower::types::host_of_ty()}});
    }
    if (prism_rtl::is_none(_m)) {
        return Array<std::tuple<Text, crate::lower::model::OutTy>>{};
    }
    prism_rtl::unreachable("no arm matched");
}


/// HostedPassed: fn Wx -> [Ex]
Array<crate::lower::model::Ex> hosted_passed(const crate::lower::node_::Wx& wx) {
    auto&& _m = crate::lower::node_::finish::hosted_rows(wx);
    if (prism_rtl::is_some(_m)) {
        return Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::node_::finish::host_field_ex(wx, wx.pos))})});
    }
    if (prism_rtl::is_none(_m)) {
        return Array<crate::lower::model::Ex>{};
    }
    prism_rtl::unreachable("no arm matched");
}


/// RowReads: fn Env, Ex -> Env
crate::lower::types::Env row_reads(const crate::lower::types::Env& env, const crate::lower::model::Ex& pref) {
    return fold(keys(env->names), env, [&](const crate::lower::types::Env& en, const Text& k) {
        return ({
            __label__ _done;
            prism_rtl::Slot<crate::lower::types::Env> _v;
            auto&& _m = crate::prelude::get(env->names, k);
            if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnHold>(prism_rtl::some_of(_m))) {
                auto&& f = prism_rtl::as<crate::lower::types::Bn::BnHold>(prism_rtl::some_of(_m)).a0;
                auto&& t = prism_rtl::as<crate::lower::types::Bn::BnHold>(prism_rtl::some_of(_m)).a1;
                _v.set(crate::lower::types::bind(en, k, crate::lower::types::Bn(crate::lower::types::Bn::BnDyn{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(pref), f})), Text::lit("get"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), Array(std::vector{crate::lower::node_::Read(crate::lower::node_::Read::ParentRead{f})}), t})));
                goto _done;
            }
            if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)) && prism_rtl::is<crate::lower::model::Ex::XMethod>(prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)).a0)) {
                auto&& m15224_1_0_0 = prism_rtl::as<crate::lower::model::Ex::XMethod>(prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)).a0).a0;
                auto&& m = prism_rtl::as<crate::lower::model::Ex::XMethod>(prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)).a0).a1;
                auto&& xs = prism_rtl::as<crate::lower::model::Ex::XMethod>(prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)).a0).a2;
                auto&& t = prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)).a2;
                if (prism_rtl::is<crate::lower::model::Ex::XSelf>(m15224_1_0_0)) {
                    _v.set(crate::lower::types::bind(en, k, crate::lower::types::Bn(crate::lower::types::Bn::BnDyn{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(pref), m, xs}), Array(std::vector{crate::lower::node_::Read(crate::lower::node_::Read::ParentRead{m})}), t})));
                    goto _done;
                }
            }
            if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m))) {
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<crate::lower::types::Env> _v;
                    auto&& _m = crate::prelude::get(env->names, prism_rtl::cat(k, "#row"));
                    if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)) && prism_rtl::is<crate::lower::model::Ex::XMethod>(prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)).a0)) {
                        auto&& m = prism_rtl::as<crate::lower::model::Ex::XMethod>(prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)).a0).a1;
                        auto&& xs = prism_rtl::as<crate::lower::model::Ex::XMethod>(prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)).a0).a2;
                        auto&& t = prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(_m)).a2;
                        _v.set(crate::lower::types::bind(en, k, crate::lower::types::Bn(crate::lower::types::Bn::BnDyn{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(pref), m, xs}), Array(std::vector{crate::lower::node_::Read(crate::lower::node_::Read::ParentRead{m})}), t})));
                        goto _done;
                    }
                    {
                        _v.set(en);
                        goto _done;
                    }
                _done:
                    _v.take();
                }));
                goto _done;
            }
            {
                _v.set(en);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


/// EventsOf: fn Env, Env -> Env
crate::lower::types::Env events_of(const crate::lower::types::Env& ports, const crate::lower::types::Env& env) {
    return fold(keys(ports->names), env, [&](const crate::lower::types::Env& en, const Text& k) {
        return ({
            __label__ _done;
            prism_rtl::Slot<crate::lower::types::Env> _v;
            auto&& _m = crate::prelude::get(ports->names, k);
            if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(_m))) {
                auto&& er = prism_rtl::as<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(_m)).a0;
                auto&& t = prism_rtl::as<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(_m)).a1;
                _v.set(crate::lower::types::bind(en, k, crate::lower::types::Bn(crate::lower::types::Bn::BnEv{er, t})));
                goto _done;
            }
            {
                _v.set(en);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


/// BlockReads: fn [Read] -> [Read]
Array<crate::lower::node_::Read> block_reads(const Array<crate::lower::node_::Read>& reads) {
    return fold(reads, Array<crate::lower::node_::Read>{}, [&](const Array<crate::lower::node_::Read>& acc, const crate::lower::node_::Read& r) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::lower::node_::Read>> _v;
            if (prism_rtl::is<crate::lower::node_::Read::ParentRead>(r)) {
                auto&& f = prism_rtl::as<crate::lower::node_::Read::ParentRead>(r).a0;
                _v.set(crate::lower::node_::add_read(acc, crate::lower::node_::Read(crate::lower::node_::Read::OwnRead{f})));
                goto _done;
            }
            if (prism_rtl::is<crate::lower::node_::Read::OwnRead>(r)) {
                _v.set(acc);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
}


/// RowLocals: unbounded fn Env, Env, Block -> [RowLocal]
Array<RowLocal> row_locals(const crate::lower::types::Env& benv, const crate::lower::types::Env& menv, const crate::syntax::Block& body) {
    return fold(crate::lower::expr::read_names(crate::check::typed::print::block_exprs(body)), Array<RowLocal>{}, [&](const Array<RowLocal>& acc, const Text& n) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<RowLocal>> _v;
            auto&& _m = crate::prelude::get(menv->names, n);
            if (prism_rtl::is_some(_m) && prism_rtl::is<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m))) {
                auto&& rs = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                auto&& mode = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a1;
                auto&& t = prism_rtl::as<crate::lower::types::Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                _v.set(({
                    auto field_ = crate::lower::snake(n);
                    (((field_ == Text::lit("key")) || (field_ == Text::lit("value"))) || (field_ == Text::lit("parent"))) || (field_ == Text::lit("path"))
                    ? acc
                    : crate::prelude::push(acc, RowLocal{.name = n, .field = field_, .ty = t, .passed = crate::lower::types::own(crate::lower::types::Vl(crate::lower::types::Vl::VlPlace{rs, mode, t}))});
                }));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


/// ForEnvs: unbounded fn Env, Env, ?ForBinders, Bn, Bn, Bn, Bn, OutTy -> ((Env, Env))
std::tuple<crate::lower::types::Env, crate::lower::types::Env> for_envs(const crate::lower::types::Env& benv, const crate::lower::types::Env& menv, const std::optional<crate::syntax::ForBinders>& binders_opt, const crate::lower::types::Bn& key_b, const crate::lower::types::Bn& key_m, const crate::lower::types::Bn& val_b, const crate::lower::types::Bn& val_m, const crate::lower::model::OutTy& vt) {
    auto be0 = crate::lower::types::bind(crate::lower::types::bind(benv, Text::lit("key"), key_b), Text::lit("$_"), val_b);
    auto me0 = crate::lower::types::bind(crate::lower::types::bind(menv, Text::lit("key"), key_m), Text::lit("$_"), val_m);
    if (prism_rtl::is_none(binders_opt)) {
        return std::tuple{be0, me0};
    }
    if (prism_rtl::is_some(binders_opt)) {
        auto&& fb = prism_rtl::some_of(binders_opt);
        auto&& _m = fb.second;
        if (prism_rtl::is_some(_m)) {
            auto&& second = prism_rtl::some_of(_m);
            auto be1 = bind_pat(be0, fb.first, key_b, crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("key")}), kt0());
            auto me1 = bind_pat(me0, fb.first, key_m, crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), Text::lit("key")}), kt0());
            return std::tuple{bind_pat(be1, second, val_b, crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("value")}), vt), bind_pat(me1, second, val_m, crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), vt)};
        }
        if (prism_rtl::is_none(_m)) {
            return std::tuple{bind_pat(be0, fb.first, val_b, crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("value")}), vt), bind_pat(me0, fb.first, val_m, crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), vt)};
        }
        prism_rtl::unreachable("no arm matched");
    }
    prism_rtl::unreachable("no arm matched");
}


/// let kt0
crate::lower::model::OutTy kt0() {
    return crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{});
}


/// BindPat: fn Env, Pattern, Bn, Ex, OutTy -> Env
crate::lower::types::Env bind_pat(const crate::lower::types::Env& env, const crate::syntax::Pattern_& p_, const crate::lower::types::Bn& b, const crate::lower::model::Ex& whole, const crate::lower::model::OutTy& t) {
    auto&& _m = p_.kind;
    if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        return crate::lower::types::bind(env, crate::check::env::sname_key(n), b);
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PGroup>(_m)) {
        auto&& q = prism_rtl::as<crate::syntax::PatternKind::PGroup>(_m).a0;
        return bind_pat(env, q, b, whole, t);
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PTuple>(_m)) {
        auto&& ps = prism_rtl::as<crate::syntax::PatternKind::PTuple>(_m).a0;
        auto ts = ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::lower::model::OutTy>> _v;
            if (prism_rtl::is<crate::lower::model::OutTy::OutTuple>(t)) {
                auto&& xs = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(t).a0;
                _v.set(xs);
                goto _done;
            }
            {
                _v.set(Array<crate::lower::model::OutTy>{});
                goto _done;
            }
        _done:
            _v.take();
        });
        return fold(crate::check::errors::range0(len(ps)), env, [&](const crate::lower::types::Env& en, const Nat& i) {
            return ({
                __label__ _done;
                prism_rtl::Slot<crate::lower::types::Env> _v;
                auto&& _m = index(ps, i);
                if (prism_rtl::is_some(_m)) {
                    auto&& q = prism_rtl::some_of(_m);
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<crate::lower::types::Env> _v;
                        auto&& _m = q.kind;
                        if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
                            auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
                            _v.set(crate::lower::types::bind(en, crate::check::env::sname_key(n), part_bn(b, whole, i, or_(index(ts, i), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})))));
                            goto _done;
                        }
                        {
                            _v.set(en);
                            goto _done;
                        }
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(en);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
        });
    }
    {
        return env;
    }
}


/// PartBn: fn Bn, Ex, Nat, OutTy -> Bn
crate::lower::types::Bn part_bn(const crate::lower::types::Bn& bn0, const crate::lower::model::Ex& whole, const Nat& i, const crate::lower::model::OutTy& t) {
    if (prism_rtl::is<crate::lower::types::Bn::BnDyn>(bn0)) {
        auto&& x = prism_rtl::as<crate::lower::types::Bn::BnDyn>(bn0).a0;
        auto&& rds = prism_rtl::as<crate::lower::types::Bn::BnDyn>(bn0).a1;
        return crate::lower::types::Bn(crate::lower::types::Bn::BnDyn{crate::lower::model::Ex(crate::lower::model::Ex::XPart{prism_rtl::rc(x), i}), rds, t});
    }
    {
        auto&& other = bn0;
        return crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XPart{prism_rtl::rc(whole), i}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), t});
    }
}


/// RowSuffix: fn Wx -> Text
Text row_suffix(const crate::lower::node_::Wx& wx) {
    auto n = len(wx->rows) + len(wx.pending);
    return n == Nat(0u) ? Text::lit("") : prism_rtl::cat(n);
}


/// GnTyNamed: fn Wx, Text -> OutTy
crate::lower::model::OutTy gn_ty_named(const crate::lower::node_::Wx& wx, const Text& n) {
    return fold(wx.gns, crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), [&](const crate::lower::model::OutTy& acc, const crate::lower::node_::Gn& g) { return g.name == n ? g.ty : acc; });
}

}  // namespace crate::lower::node_::keyed
