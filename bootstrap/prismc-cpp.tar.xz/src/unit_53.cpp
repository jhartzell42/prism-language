// The module `Lower.Node.Static`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <lower/node_/static_/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Lower.Node.Static`, from `target/bootstrap/cpp-src/prismc/lower/node/static.prism`.
namespace crate::lower::node_::static_ {

void HostForm::show(Printer& p) const {
    if (auto c = std::get_if<HostEach>(&cases())) p.choice("HostEach", {});
    else if (auto c = std::get_if<HostSome>(&cases())) p.choice("HostSome", {});
}

Pod HostForm::to_pod() const {
    return std::holds_alternative<HostEach>(cases()) ? Pod::choice("HostEach", {})
        : std::holds_alternative<HostSome>(cases()) ? Pod::choice("HostSome", {})
        : Pod();
}

Result<HostForm> HostForm::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "HostEach" && c->args.size() == 0) return HostForm(HostEach{});
        if (c->ctor == "HostSome" && c->args.size() == 0) return HostForm(HostSome{});
    }
    return mismatch<HostForm>("a HostForm", p);
}


/// WidgetLine: unbounded fn Wx, Env, Env, Expr, ?Bn -> ((Wx, Wres))
std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> widget_line(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& benv_p1, const crate::lower::types::Env& menv_p2, const crate::syntax::Expr& e_p3, const std::optional<crate::lower::types::Bn>& bound_o4) {
    auto lx_p5 = wx_p0.lx;
    auto [callee_pb, args_pc] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::syntax::Expr, Array<crate::syntax::Arg>>> _v;
        auto&& _m = prism_rtl::deref(e_p3.kind);
        if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
            auto&& c_p9 = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
            auto&& xs_pa = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
            _v.set(std::tuple{prism_rtl::deref(prism_rtl::deref(c_p9)), xs_pa});
            goto _done;
        }
        {
            _v.set(std::tuple{e_p3, Array<crate::syntax::Arg>{}});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto qk_p6 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = prism_rtl::deref(prism_rtl::deref(callee_pb).kind);
        if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
            auto&& n_pd = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
            _v.set(({
                auto&& _q_oe = crate::check::env::names::resolve_value(prism_rtl::deref(lx_p5).g, prism_rtl::deref(lx_p5).home, n_pd);
                auto&& q_oe = std::get<0>(_q_oe);
                or_(q_oe, Text::lit(""));
            }));
            goto _done;
        }
        {
            _v.set(Text::lit(""));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto target_o7 = ({
        __label__ _done;
        prism_rtl::Slot<std::optional<Nat>> _v;
        if (prism_rtl::is_some(bound_o4) && prism_rtl::is<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(bound_o4))) {
            auto&& er_pf = prism_rtl::as<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(bound_o4)).a0;
            _v.set(std::optional(prism_rtl::deref(er_pf).node_));
            goto _done;
        }
        {
            _v.set(std::optional<Nat>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto param_o8 = ({
        __label__ _done;
        prism_rtl::Slot<std::optional<crate::lower::types::Bn>> _v;
        auto&& _m = prism_rtl::deref(prism_rtl::deref(callee_pb).kind);
        if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
            auto&& n_pg = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
            _v.set(len(n_pg->path_) == Nat(1u)
                ? crate::prelude::get(menv_p2.names, crate::check::env::sname_key(n_pg))
                : std::optional<crate::lower::types::Bn>{});
            goto _done;
        }
        {
            _v.set(std::optional<crate::lower::types::Bn>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    if (prism_rtl::is_some(param_o8) && prism_rtl::is<crate::lower::types::Bn::BnWidget>(prism_rtl::some_of(param_o8))) {
        auto&& x_ph = prism_rtl::as<crate::lower::types::Bn::BnWidget>(prism_rtl::some_of(param_o8)).a0;
        auto&& cbenv_pi = prism_rtl::as<crate::lower::types::Bn::BnWidget>(prism_rtl::some_of(param_o8)).a1;
        auto&& cmenv_pj = prism_rtl::as<crate::lower::types::Bn::BnWidget>(prism_rtl::some_of(param_o8)).a2;
        auto&& clx_pk = prism_rtl::as<crate::lower::types::Bn::BnWidget>(prism_rtl::some_of(param_o8)).a3;
        return apply_widget_param(wx_p0, x_ph, cbenv_pi, cmenv_pj, clx_pk, len(args_pc));
    }
    {
        return widget_call(wx_p0, benv_p1, menv_p2, e_p3, bound_o4, qk_p6, args_pc, target_o7);
    }
}


prism_rtl::Turn<std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres>> WidgetLine::cycle() const {
    const auto& wx_p0 = this->wx_p0;
    const auto& benv_p1 = this->benv_p1;
    const auto& menv_p2 = this->menv_p2;
    const auto& e_p3 = this->e_p3;
    const auto& bound_o4 = this->bound_o4;
    auto lx_p5 = prism_rtl::deref(wx_p0).lx;
    auto [callee_pb, args_pc] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::syntax::Expr, Array<crate::syntax::Arg>>> _v;
        auto&& _m = prism_rtl::deref(prism_rtl::deref(e_p3).kind);
        if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
            auto&& c_p9 = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
            auto&& xs_pa = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
            _v.set(std::tuple{prism_rtl::deref(prism_rtl::deref(c_p9)), xs_pa});
            goto _done;
        }
        {
            _v.set(std::tuple{e_p3, Array<crate::syntax::Arg>{}});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto qk_p6 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = prism_rtl::deref(prism_rtl::deref(callee_pb).kind);
        if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
            auto&& n_pd = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
            _v.set(({
                auto&& _q_oe = crate::check::env::names::resolve_value(prism_rtl::deref(lx_p5).g, prism_rtl::deref(lx_p5).home, n_pd);
                auto&& q_oe = std::get<0>(_q_oe);
                or_(q_oe, Text::lit(""));
            }));
            goto _done;
        }
        {
            _v.set(Text::lit(""));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto target_o7 = ({
        __label__ _done;
        prism_rtl::Slot<std::optional<Nat>> _v;
        if (prism_rtl::is_some(bound_o4) && prism_rtl::is<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(bound_o4))) {
            auto&& er_pf = prism_rtl::as<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(bound_o4)).a0;
            _v.set(std::optional(prism_rtl::deref(er_pf).node_));
            goto _done;
        }
        {
            _v.set(std::optional<Nat>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto param_o8 = ({
        __label__ _done;
        prism_rtl::Slot<std::optional<crate::lower::types::Bn>> _v;
        auto&& _m = prism_rtl::deref(prism_rtl::deref(callee_pb).kind);
        if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
            auto&& n_pg = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
            _v.set(len(n_pg->path_) == Nat(1u)
                ? crate::prelude::get(menv_p2->names, crate::check::env::sname_key(n_pg))
                : std::optional<crate::lower::types::Bn>{});
            goto _done;
        }
        {
            _v.set(std::optional<crate::lower::types::Bn>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    return ({
        prism_rtl::is_some(param_o8) && prism_rtl::is<crate::lower::types::Bn::BnWidget>(prism_rtl::some_of(param_o8)) ? ({
        auto&& x_ph = prism_rtl::as<crate::lower::types::Bn::BnWidget>(prism_rtl::some_of(param_o8)).a0;
        auto&& cbenv_pi = prism_rtl::as<crate::lower::types::Bn::BnWidget>(prism_rtl::some_of(param_o8)).a1;
        auto&& cmenv_pj = prism_rtl::as<crate::lower::types::Bn::BnWidget>(prism_rtl::some_of(param_o8)).a2;
        auto&& clx_pk = prism_rtl::as<crate::lower::types::Bn::BnWidget>(prism_rtl::some_of(param_o8)).a3;
        prism_rtl::finished(apply_widget_param(wx_p0, x_ph, cbenv_pi, cmenv_pj, clx_pk, len(args_pc)));
    })
        : prism_rtl::finished(widget_call(wx_p0, benv_p1, menv_p2, e_p3, bound_o4, qk_p6, args_pc, target_o7));
    });
}


/// `Start WidgetLine, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres>> start_widget_line(crate::lower::node_::Wx wx_p0, crate::lower::types::Env benv_p1, crate::lower::types::Env menv_p2, crate::syntax::Expr e_p3, std::optional<crate::lower::types::Bn> bound_o4) {
    return prism_rtl::make_rc<WidgetLine>(wx_p0, benv_p1, menv_p2, e_p3, bound_o4);
}


/// ApplyWidgetParam: unbounded fn Wx, Expr, Env, Env, Lx, Nat -> ((Wx, Wres))
std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> apply_widget_param(const crate::lower::node_::Wx& wx_p0, const crate::syntax::Expr& x_p1, const crate::lower::types::Env& cbenv_p2, const crate::lower::types::Env& cmenv_p3, const crate::lower::Lx& clx_p4, const Nat& nargs_p5) {
    return nargs_p5 > Nat(0u)
        ? ({
        auto wx2_p6 = ({
            crate::lower::node_::Wx this_ = wx_p0;
            this_.build = crate::prelude::push(this_.build, crate::lower::expr::refusal_do(Text::lit("a widget parameter applied to arguments")));
            (std::move(this_));
        });
        std::tuple{wx2_p6, crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{})};
    })
        : ({
        auto lx_p7 = wx_p0.lx;
        auto inner_p8 = ({
            crate::lower::node_::Wx this_ = wx_p0;
            this_.lx = clx_p4;
            (std::move(this_));
        });
        auto [done_pa, res_pb] = crate::lower::node_::def::build_line(inner_p8, cbenv_p2, cmenv_p3, x_p1, std::optional<crate::lower::types::Bn>{});
        auto back_p9 = ({
            crate::lower::node_::Wx this_ = done_pa;
            this_.lx = lx_p7;
            (std::move(this_));
        });
        std::tuple{back_p9, res_pb};
    });
}


/// InlineBlock: unbounded fn Wx, Env, Env, Block, Lx -> ((Wx, Wres))
std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> inline_block(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& benv_p1, const crate::lower::types::Env& menv_p2, const crate::syntax::Block& b_p3, const crate::lower::Lx& lx_p4) {
    auto inner_p5 = ({
        crate::lower::node_::Wx this_ = wx_p0;
        this_.result = crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{});
        (std::move(this_));
    });
    auto done_p6 = crate::lower::node_::def::block_into(inner_p5, benv_p1, menv_p2, b_p3);
    auto back_p7 = ({
        crate::lower::node_::Wx this_ = done_p6;
        this_.result = wx_p0.result;
        (std::move(this_));
    });
    return std::tuple{back_p7, done_p6->result};
}


prism_rtl::Turn<std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres>> InlineBlock::cycle() const {
    const auto& wx_p0 = this->wx_p0;
    const auto& benv_p1 = this->benv_p1;
    const auto& menv_p2 = this->menv_p2;
    const auto& b_p3 = this->b_p3;
    const auto& lx_p4 = this->lx_p4;
    auto inner_p5 = ({
        crate::lower::node_::Wx this_ = wx_p0;
        this_.result = crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{});
        (std::move(this_));
    });
    auto b_p3_1 = b_p3;
    auto benv_p1_2 = benv_p1;
    auto menv_p2_3 = menv_p2;
    auto wx_p0_4 = wx_p0;
    return call_then(crate::lower::node_::def::start_block_into(inner_p5, benv_p1_2, menv_p2_3, b_p3_1), [=](crate::lower::node_::Wx block_into_3395) {
        return ({
            auto done_p6 = block_into_3395;
            auto back_p7 = ({
                crate::lower::node_::Wx this_ = done_p6;
                this_.result = wx_p0_4->result;
                (std::move(this_));
            });
            (prism_rtl::finished(std::tuple{back_p7, done_p6->result}));
        });
    });
}


/// `Start InlineBlock, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres>> start_inline_block(crate::lower::node_::Wx wx_p0, crate::lower::types::Env benv_p1, crate::lower::types::Env menv_p2, crate::syntax::Block b_p3, crate::lower::Lx lx_p4) {
    return prism_rtl::make_rc<InlineBlock>(wx_p0, benv_p1, menv_p2, b_p3, lx_p4);
}


/// WidgetCall: unbounded fn Wx, Env, Env, Expr, ?Bn, Text, [Arg], ?Nat -> ((Wx, Wres))
std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> widget_call(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& benv_p1, const crate::lower::types::Env& menv_p2, const crate::syntax::Expr& e_p3, const std::optional<crate::lower::types::Bn>& bound_o4, const Text& qk_p5, const Array<crate::syntax::Arg>& args_p6, const std::optional<Nat>& target_o7) {
    auto lx_p8 = wx_p0.lx;
    {
        auto&& m3679_0 = qk_p5;
        if (m3679_0 == Text::lit("Prelude.@started")) {
            return started_line(wx_p0, bound_o4);
        }
    }
    {
        auto&& m3679_1 = qk_p5;
        if (m3679_1 == Text::lit("Prelude.@Switch")) {
            return crate::lower::node_::switch_::switch_line(wx_p0, menv_p2, args_p6);
        }
    }
    {
        auto&& m3679_2 = qk_p5;
        if (m3679_2 == Text::lit("Prelude.@Flatten")) {
            return crate::lower::node_::switch_::flatten_line(wx_p0, menv_p2, args_p6, bound_o4);
        }
    }
    {
        auto&& m3679_3 = qk_p5;
        if (m3679_3 == Text::lit("Prelude.@Defer")) {
            return defer_line(wx_p0, menv_p2, args_p6, e_p3, target_o7);
        }
    }
    {
        auto&& m3679_4 = qk_p5;
        if (m3679_4 == Text::lit("Prelude.@Distinct")) {
            return distinct_line(wx_p0, menv_p2, args_p6, e_p3, bound_o4);
        }
    }
    {
        auto&& m3679_5 = qk_p5;
        if (m3679_5 == Text::lit("Prelude.@PerKey")) {
            return per_key_line(wx_p0, menv_p2, args_p6, bound_o4);
        }
    }
    {
        auto&& m3679_6 = qk_p5;
        if (m3679_6 == Text::lit("Prelude.@Run")) {
            return run_line(wx_p0, benv_p1, args_p6, e_p3, target_o7);
        }
    }
    {
        auto&& m3679_7 = qk_p5;
        if (m3679_7 == Text::lit("Prelude.@Machine")) {
            return machine_line(wx_p0, benv_p1, menv_p2, args_p6, e_p3, target_o7);
        }
    }
    {
        auto&& m3679_8 = qk_p5;
        if (m3679_8 == Text::lit("Prelude.@HostDocument")) {
            return host_line(wx_p0, benv_p1, menv_p2, HostForm(HostForm::HostEach{}), args_p6, bound_o4);
        }
    }
    {
        auto&& m3679_9 = qk_p5;
        if (m3679_9 == Text::lit("Prelude.@HostSome")) {
            return host_line(wx_p0, benv_p1, menv_p2, HostForm(HostForm::HostSome{}), args_p6, bound_o4);
        }
    }
    {
        auto&& _m = crate::prelude::get(prism_rtl::deref(prism_rtl::deref(lx_p8).g).vals, qk_p5);
        if (prism_rtl::is_some(_m)) {
            auto&& v_p9 = prism_rtl::some_of(_m);
            return inline_widget(wx_p0, benv_p1, menv_p2, qk_p5, v_p9, args_p6, e_p3);
        }
        if (prism_rtl::is_none(_m)) {
            auto wx2_pa = ({
                crate::lower::node_::Wx this_ = wx_p0;
                this_.build = crate::prelude::push(this_.build, crate::lower::expr::refusal_do(Text::lit("a widget this back end does not lower yet")));
                (std::move(this_));
            });
            return std::tuple{wx2_pa, crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{})};
        }
        prism_rtl::unreachable("no arm matched");
    }
}


/// HostLine: unbounded fn Wx, Env, Env, HostForm, [Arg], ?Bn -> ((Wx, Wres))
std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> host_line(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& benv_p1, const crate::lower::types::Env& menv_p2, const HostForm& form_p3, const Array<crate::syntax::Arg>& args_p4, const std::optional<crate::lower::types::Bn>& bound_o5) {
    auto lx_p6 = wx_p0.lx;
    auto pos_p7 = wx_p0.pos;
    auto k_p8 = len(wx_p0.scopes) + Nat(1u);
    auto hf_p9 = prism_rtl::cat("host_", k_p8);
    auto rows_name_pa = prism_rtl::cat(hf_p9, "_rows");
    auto doc_getter_pb = prism_rtl::cat(hf_p9, "_doc");
    auto wx1_pc = ({
        crate::lower::node_::Wx this_ = wx_p0;
        this_.taken = append(this_.taken, Array(std::vector{hf_p9, rows_name_pa, doc_getter_pb, prism_rtl::cat(doc_getter_pb, "_now"), prism_rtl::cat(doc_getter_pb, "_snap"), prism_rtl::cat(doc_getter_pb, "_direct"), prism_rtl::cat(doc_getter_pb, "_publish"), prism_rtl::cat(hf_p9, "_answer"), prism_rtl::cat(hf_p9, "_moved")}));
        (std::move(this_));
    });
    auto named_pd = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = index(args_p4, Nat(1u));
        if (prism_rtl::is_some(_m)) {
            auto&& sup_pe = prism_rtl::some_of(_m);
            _v.set(is_widget_name(sup_pe->value));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(false);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto&& _m = std::tuple{index(args_p4, Nat(0u)), index(args_p4, Nat(1u))};
    if (prism_rtl::is_some(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m))) {
        if (std::move(named_pd)) {
            auto wx2_pf = ({
                crate::lower::node_::Wx this_ = wx1_pc;
                this_.pos = crate::lower::model::next_pos(this_.pos);
                this_.build = crate::prelude::push(this_.build, crate::lower::expr::refusal_do(Text::lit("a named widget function as a host\'s supplier (gap NS): a lambda supplier is lowered, a widget function is not a value")));
                (std::move(this_));
            });
            return std::tuple{wx2_pf, crate::lower::node_::Wres(crate::lower::node_::Wres::WrHosted{prism_rtl::rc(crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{})), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})})})};
        }
    }
    if (prism_rtl::is_some(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m))) {
        auto&& child_pg = prism_rtl::some_of(std::get<0>(_m));
        auto&& sup_ph = prism_rtl::some_of(std::get<1>(_m));
        auto [wxd_p13, dyn_env_p14, dyn_lets_p15] = dynamic_answers(wx1_pc, benv_p1, menv_p2, hf_p9, sup_ph->value);
        auto offered_pi = crate::lower::types::own(crate::lower::expr::value_of(lx_p6, dyn_env_p14, sup_ph->value));
        auto supplier0_pj = ({
            __label__ _done;
            prism_rtl::Slot<crate::lower::model::Ex> _v;
            if (prism_rtl::is<HostForm::HostEach>(form_p3)) {
                _v.set(offered_pi);
                goto _done;
            }
            if (prism_rtl::is<HostForm::HostSome>(form_p3)) {
                _v.set(crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("prism_rtl::forward_on_none"), Array(std::vector{offered_pi})}));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto supplier_pk = len(dyn_lets_p15) == Nat(0u)
            ? supplier0_pj
            : crate::lower::model::Ex(crate::lower::model::Ex::XBlock{dyn_lets_p15, prism_rtl::rc(supplier0_pj)});
        auto enclosing_pl = crate::lower::node_::finish::emits(wx_p0, pos_p7)
            ? crate::lower::model::Ex(crate::lower::model::Ex::XNone{})
            : crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCast{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{crate::lower::node_::elements::host_local(wx_p0, pos_p7)}))})), crate::lower::types::host_of_ty()})})});
        auto made_pm = crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("prism_rtl::Host::new"), Array(std::vector{crate::lower::node_::finish::place_at(wx_p0, Text::lit(""), pos_p7), crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{rows_name_pa}))}), supplier_pk, enclosing_pl, crate::lower::model::Ex(crate::lower::model::Ex::XPath{prism_rtl::cat(wx_p0.node_, "::", hf_p9, "_answer")})})});
        auto host_ty_pn = crate::lower::model::OutTy(crate::lower::model::OutTy::OutRc{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("prism_rtl::Host"), Array(std::vector{crate::lower::types::elem_ty(), crate::lower::types::answer_ty(), crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{wx_p0.node_, Array<crate::lower::model::OutTy>{}})})}))});
        auto rows_ty_po = crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("prism_rtl::Rows"), Array(std::vector{crate::lower::types::elem_ty(), crate::lower::types::answer_ty()})});
        auto doc_ty_pp = crate::lower::model::OutTy(crate::lower::model::OutTy::OutMap{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutPath{})), prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutDyn{prism_rtl::rc(crate::lower::types::elem_ty())}))});
        auto direct_ty_pq = crate::lower::model::OutTy(crate::lower::model::OutTy::OutMap{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutPath{})), prism_rtl::rc(crate::lower::types::entry_ty())});
        auto what_pr = prism_rtl::cat("the document of the child hosted at place ", crate::lower::model::place_text(pos_p7));
        auto wx2_ps = ({
            crate::lower::node_::Wx this_ = wxd_p13;
            this_.pos = crate::lower::model::next_pos(this_.pos);
            this_.lets = append(this_.lets, Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{rows_name_pa})), rows_ty_po}), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("RefCell::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Map::new"), Array<crate::lower::model::Ex>{}})})})})})}), crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{hf_p9}), made_pm})}));
            this_.fields = append(this_.fields, Array(std::vector{std::tuple{hf_p9, host_ty_pn, prism_rtl::cat("the host at place ", crate::lower::model::place_text(pos_p7), ": its supplier, its rows, and the way back into its child (pick HO)")}, std::tuple{rows_name_pa, rows_ty_po, prism_rtl::cat("the rows of the host at place ", crate::lower::model::place_text(pos_p7), ": `for p, e <- $doc`, one supplier blueprint per child place")}, std::tuple{prism_rtl::cat(rows_name_pa, "_from"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutCell{prism_rtl::rc(direct_ty_pq)}), prism_rtl::cat("the places the rows of the host at place ", crate::lower::model::place_text(pos_p7), " were last built from")}, std::tuple{prism_rtl::cat(doc_getter_pb, "_snap"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutSnapshot{prism_rtl::rc(crate::lower::types::host_doc_ty())}), prism_rtl::cat("`$doc` of the host at place ", crate::lower::model::place_text(pos_p7), ", its outer, a structural dynamic: its snapshots, the places and the lagged dynamic (pick ST)")}}));
            this_.moves = append(this_.moves, Array(std::vector{std::tuple{hf_p9, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{hf_p9}))})}, std::tuple{rows_name_pa, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{rows_name_pa}))})}}));
            this_.inits = append(this_.inits, Array(std::vector{std::tuple{prism_rtl::cat(doc_getter_pb, "_snap"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Snapshot::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XStr{what_pr})})})}, std::tuple{prism_rtl::cat(rows_name_pa, "_from"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("RefCell::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Map::new"), Array<crate::lower::model::Ex>{}})})})}}));
            this_.hosts = crate::prelude::push(this_.hosts, crate::lower::node_::HostDef{.pos = pos_p7, .name = hf_p9, .scope = k_p8});
            this_.snaps = crate::prelude::push(this_.snaps, crate::lower::node_::SnapDef{.name = doc_getter_pb, .live = prism_rtl::cat(doc_getter_pb, "_now"), .ty = crate::lower::types::host_doc_ty(), .eq = true, .builder = rows_name_pa, .before = true, .what = what_pr});
            this_.getters = append(this_.getters, Array(std::vector{crate::lower::model::MethDef{.name = doc_getter_pb, .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxRef{}), .ret = doc_ty_pp, .body = Array<crate::lower::model::Do>{}, .tail = crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(doc_getter_pb, "_snap")})), Text::lit("get"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})), Text::lit("doc")}), .doc = prism_rtl::cat("The document of the child hosted at place ", crate::lower::model::place_text(pos_p7), ", `$doc`, its outer a structural dynamic (pick ST): one tick behind the child\'s places, the snapshot of the tick before the tick the read point is after; each entry the place\'s own dynamic.")}, crate::lower::model::MethDef{.name = prism_rtl::cat(doc_getter_pb, "_direct"), .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxRef{}), .ret = direct_ty_pq, .body = Array<crate::lower::model::Do>{}, .tail = crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(doc_getter_pb, "_snap")})), Text::lit("current"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})), Text::lit("places")}), .doc = prism_rtl::cat("The places of the child hosted at place ", crate::lower::model::place_text(pos_p7), ", not the lagged `$doc`: the snapshot taken in this tick\'s construction step, the places as the tick opened during propagation. The host\'s own `for` reads it, so a newborn child place gets its row in the tick it is born (pick ST).")}}));
            this_.scopes = crate::prelude::push(this_.scopes, hf_p9);
            this_.builders = crate::prelude::push(this_.builders, crate::lower::model::ForDef{.name = rows_name_pa, .pos = pos_p7, .at = crate::lower::node_::finish::place_at(wx_p0, Text::lit("self"), pos_p7), .key_ty = crate::lower::model::OutTy(crate::lower::model::OutTy::OutPath{}), .value_ty = crate::lower::types::entry_ty(), .row_node = Text::lit("prism_rtl::HostRow::<crate::Elem, crate::Answer>"), .keyed = true, .source = prism_rtl::cat(doc_getter_pb, "_direct"), .parent = crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), hf_p9}))}), .passed = Array<crate::lower::model::Ex>{}, .moved = or_(crate::lower::node_::finish::hosted_rows(wx_p0), Text::lit("")), .replaced = Array<Text>{}});
            this_.build_holds = crate::lower::node_::add_read(this_.build_holds, crate::lower::node_::Read(crate::lower::node_::Read::OwnRead{prism_rtl::cat(doc_getter_pb, "_now")}));
            this_.fallible = true;
            (std::move(this_));
        });
        auto inner_pt = ({
            crate::lower::node_::Wx this_ = wx2_ps;
            this_.pos = crate::lower::model::scope_pos(k_p8);
            this_.result = crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{});
            (std::move(this_));
        });
        auto [done_p16, res_p17] = crate::lower::node_::def::build_line(inner_pt, benv_p1, menv_p2, child_pg->value, std::optional<crate::lower::types::Bn>{});
        auto child_places_pu = drop(prism_rtl::deref(done_p16).places, len(prism_rtl::deref(wx2_ps).places));
        auto in_scope_fv = ({
            auto k_p8_1 = k_p8;
            static_cast<Fn<bool(const crate::lower::model::Pos_&)>>(prism_rtl::rc([=, k_p8_1 = std::move(k_p8_1)](const crate::lower::model::Pos_& p_p18) { return prism_rtl::deref(p_p18).scope == k_p8_1; }));
        });
        auto getter_p10 = host_doc_getter(prism_rtl::cat(doc_getter_pb, "_now"), pos_p7, filter(child_places_pu, [&](const crate::lower::node_::Place& pl_p19) { return in_scope_fv(prism_rtl::deref(pl_p19).pos); }), filter(drop(prism_rtl::deref(done_p16).builders, len(prism_rtl::deref(wx2_ps).builders)), [&](const crate::lower::model::ForDef& b_p1a) { return in_scope_fv(prism_rtl::deref(b_p1a).pos); }), filter(drop(prism_rtl::deref(done_p16).gens, len(prism_rtl::deref(wx2_ps).gens)), [&](const crate::lower::model::GenDef& gd_p1b) { return in_scope_fv(prism_rtl::deref(gd_p1b).pos); }));
        auto back_p11 = ({
            crate::lower::node_::Wx this_ = done_p16;
            this_.pos = prism_rtl::deref(wx2_ps).pos;
            this_.result = wx_p0.result;
            this_.getters = crate::prelude::push(this_.getters, getter_p10);
            this_.dyn_reads = insert(this_.dyn_reads, prism_rtl::cat(doc_getter_pb, "_now"), Array<crate::lower::node_::Read>{});
            (std::move(this_));
        });
        auto doc_bn_p12 = crate::lower::types::Bn(crate::lower::types::Bn::BnDyn{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), doc_getter_pb, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), Array(std::vector{crate::lower::node_::Read(crate::lower::node_::Read::OwnRead{doc_getter_pb})}), doc_ty_pp});
        return std::tuple{back_p11, crate::lower::node_::Wres(crate::lower::node_::Wres::WrHosted{prism_rtl::rc(res_p17), doc_bn_p12})};
    }
    {
        auto wx2_p1c = ({
            crate::lower::node_::Wx this_ = wx1_pc;
            this_.pos = crate::lower::model::next_pos(this_.pos);
            this_.build = crate::prelude::push(this_.build, crate::lower::expr::refusal_do(Text::lit("a host without its child or its supplier")));
            (std::move(this_));
        });
        return std::tuple{wx2_p1c, crate::lower::node_::Wres(crate::lower::node_::Wres::WrHosted{prism_rtl::rc(crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{})), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})})})};
    }
}


/// IsWidgetName: fn Expr -> Bool
bool is_widget_name(const crate::syntax::Expr& e_p0) {
    auto&& _m = prism_rtl::deref(e_p0.kind);
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n_p1 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        return crate::syntax::lexer::chars::has_prefix(crate::check::env::sname_key(n_p1), Text::lit("@"));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x_p2 = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return is_widget_name(prism_rtl::deref(prism_rtl::deref(x_p2)));
    }
    {
        return false;
    }
}


/// DynamicAnswers: unbounded fn Wx, Env, Env, Text, Expr -> ((Wx, Env, [Do]))
std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, Array<crate::lower::model::Do>> dynamic_answers(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& benv_p1, const crate::lower::types::Env& menv_p2, const Text& hf_p3, const crate::syntax::Expr& sup_p4) {
    auto lx_p5 = wx_p0.lx;
    auto dyns_p6 = fold(crate::check::typed::print::exprs_in(sup_p4), Array<std::tuple<crate::syntax::Expr, crate::syntax::Expr>>{}, [&](const Array<std::tuple<crate::syntax::Expr, crate::syntax::Expr>>& acc_p7, const crate::syntax::Expr& x_p8) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<std::tuple<crate::syntax::Expr, crate::syntax::Expr>>> _v;
            auto&& _m = prism_rtl::deref(prism_rtl::deref(x_p8).kind);
            if (prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m)) {
                auto&& m14204_0_0 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
                auto&& y_p9 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
                if (m14204_0_0 == Text::lit("@")) {
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<Array<std::tuple<crate::syntax::Expr, crate::syntax::Expr>>> _v;
                        auto&& _m = dynamic_answer(lx_p5, prism_rtl::deref(prism_rtl::deref(y_p9)));
                        if (prism_rtl::is_some(_m)) {
                            auto&& d_pa = prism_rtl::some_of(_m);
                            _v.set(crate::prelude::push(acc_p7, std::tuple{prism_rtl::deref(prism_rtl::deref(y_p9)), d_pa}));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(acc_p7);
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
            }
            {
                _v.set(acc_p7);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    return len(dyns_p6) == Nat(0u)
        ? std::tuple{wx_p0, benv_p1, Array<crate::lower::model::Do>{}}
        : ({
        auto owner_pb = prism_rtl::cat(hf_p3, "_owner");
        auto wx1_pc = ({
            crate::lower::node_::Wx this_ = wx_p0;
            this_.taken = crate::prelude::push(this_.taken, owner_pb);
            this_.lets = crate::prelude::push(this_.lets, crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{owner_pb}), crate::lower::model::Ex(crate::lower::model::Ex::XCall{prism_rtl::cat("prism_rtl::Link::<", wx_p0.node_, ">::new"), Array<crate::lower::model::Ex>{}})}));
            this_.build = crate::prelude::push(this_.build, crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{owner_pb})), Text::lit("link"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XRef{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")}))})})})}));
            (std::move(this_));
        });
        auto env0_pd = crate::lower::types::bind(benv_p1, Text::lit("#owner"), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{owner_pb}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})}));
        auto lets0_pe = Array(std::vector{crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{owner_pb}), crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{owner_pb}))})})});
        run_to_end(fold_job(crate::check::errors::range0(len(dyns_p6)), std::tuple{wx1_pc, env0_pd, lets0_pe}, ({
        auto dyns_p6_1 = dyns_p6;
        auto hf_p3_2 = hf_p3;
        auto menv_p2_3 = menv_p2;
        auto lx_p5_4 = lx_p5;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, Array<crate::lower::model::Do>>>(std::tuple<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, Array<crate::lower::model::Do>>, Nat>)>>(prism_rtl::rc([=, dyns_p6_1 = std::move(dyns_p6_1), hf_p3_2 = std::move(hf_p3_2), menv_p2_3 = std::move(menv_p2_3), lx_p5_4 = std::move(lx_p5_4)](std::tuple<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, Array<crate::lower::model::Do>>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto dyns_p6_1_5 = dyns_p6_1;
            auto hf_p3_2_5 = hf_p3_2;
            auto menv_p2_3_5 = menv_p2_3;
            auto lx_p5_4_5 = lx_p5_4;
            entered(once_job([=, dyns_p6_1_5 = std::move(dyns_p6_1_5), hf_p3_2_5 = std::move(hf_p3_2_5), menv_p2_3_5 = std::move(menv_p2_3_5), lx_p5_4_5 = std::move(lx_p5_4_5)]() {
            return ({
                auto [w_pf, en_pg, ls_ph] = p0;
                auto j_pi = p1;
                ({
                auto&& _m = index(dyns_p6_1_5, j_pi);
                prism_rtl::is_some(_m) ? ({
                auto&& y_pj = std::get<0>(prism_rtl::some_of(_m));
                auto&& d_pk = std::get<1>(prism_rtl::some_of(_m));
                ({
                auto name_pl = prism_rtl::cat(hf_p3_2_5, "_dyn_", j_pi + Nat(1u));
                auto port_pm = prism_rtl::cat(name_pl, "_port");
                call_then(crate::lower::node_::dynamics::start_dynamic_expr(w_pf, menv_p2_3_5, d_pk), [=, name_pl = std::move(name_pl), port_pm = std::move(port_pm)](std::tuple<crate::lower::model::Ex, Array<crate::lower::node_::Read>> dynamic_expr_15116) {
                return ({
                    auto [ex_po, reads_pp] = dynamic_expr_15116;
                    call_then(crate::lower::types::start_out_ty_of(lx_p5_4_5, crate::lower::types::peel(crate::lower::type_at(lx_p5_4_5, prism_rtl::deref(d_pk).span))), [=](crate::lower::model::OutTy out_ty_of_15163) {
                    return ({
                        auto t_pn = out_ty_of_15163;
                        (!crate::lower::node_::def::all_inited(w_pf, reads_pp)
                        ? prism_rtl::finished(std::tuple{w_pf, en_pg, ls_ph})
                        : ({
                        auto w2_pq = ({
                            crate::lower::node_::Wx this_ = w_pf;
                            this_.taken = append(this_.taken, Array(std::vector{name_pl, port_pm}));
                            this_.getters = crate::prelude::push(this_.getters, crate::lower::model::MethDef{.name = name_pl, .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxRef{}), .ret = t_pn, .body = Array<crate::lower::model::Do>{}, .tail = ex_po, .doc = prism_rtl::cat("The host at `", hf_p3_2_5, "`\'s dynamic answer `", crate::lower::functions::src_text(lx_p5_4_5, lx_p5_4_5->file, prism_rtl::deref(y_pj).span), "`, read at the read point (round 3 DY).")});
                            this_.lets = crate::prelude::push(this_.lets, crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{port_pm})), crate::lower::model::OutTy(crate::lower::model::OutTy::OutRc{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutPort{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}))}))})}), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Rc::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Port::new"), Array<crate::lower::model::Ex>{}})})})}));
                            this_.fields = crate::prelude::push(this_.fields, std::tuple{port_pm, crate::lower::model::OutTy(crate::lower::model::OutTy::OutRc{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutPort{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}))}))}), prism_rtl::cat("the dynamic answer `", name_pl, "` moved: its blueprints push the child\'s place next tick")});
                            this_.moves = crate::prelude::push(this_.moves, std::tuple{port_pm, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{port_pm}))})});
                            this_.dyn_answers = crate::prelude::push(this_.dyn_answers, std::tuple{name_pl, reads_pp});
                            (std::move(this_));
                        });
                        (prism_rtl::finished(std::tuple{w2_pq, crate::lower::types::bind(en_pg, prism_rtl::cat("#dyn", dyn_key(y_pj)), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{name_pl}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), t_pn})), crate::prelude::push(ls_ph, crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{port_pm}), crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{port_pm}))})}))}));
                    }));
                    });
                });
                });
            });
            });
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{w_pf, en_pg, ls_ph})
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    }));
    })));
    });
}


/// ?DynamicAnswer: fn Lx, Expr -> ?Expr
std::optional<crate::syntax::Expr> dynamic_answer(const crate::lower::Lx& lx_p0, const crate::syntax::Expr& x_p1) {
    return crate::lower::types::layer_of(crate::lower::type_at(lx_p0, x_p1.span)) != crate::lower::types::Layer(crate::lower::types::Layer::LyDyn{})
        ? std::optional<crate::syntax::Expr>{}
        : ({
        __label__ _done;
        prism_rtl::Slot<std::optional<crate::syntax::Expr>> _v;
        auto&& _m = prism_rtl::deref(x_p1.kind);
        if (prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m)) {
            auto&& m16593_0_0 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
            auto&& inner_p2 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
            if (m16593_0_0 == Text::lit("$")) {
                _v.set(crate::lower::types::layer_of(crate::lower::type_at(lx_p0, prism_rtl::deref(inner_p2).span)) == crate::lower::types::Layer(crate::lower::types::Layer::LyDyn{})
                    ? std::optional(prism_rtl::deref(prism_rtl::deref(inner_p2)))
                    : std::optional<crate::syntax::Expr>{});
                goto _done;
            }
        }
        {
            _v.set(std::optional(x_p1));
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// DynKey: fn Expr -> Text
Text dyn_key(const crate::syntax::Expr& x_p0) {
    return prism_rtl::cat(prism_rtl::deref(x_p0.span).start, ":", prism_rtl::deref(x_p0.span).end);
}


/// HostDocGetter: fn Text, Pos, [Place], [ForDef], [GenDef] -> MethDef
crate::lower::model::MethDef host_doc_getter(const Text& name_p0, const crate::lower::model::Pos_& pos_p1, const Array<crate::lower::node_::Place>& places_p2, const Array<crate::lower::model::ForDef>& builders_p3, const Array<crate::lower::model::GenDef>& gens_p4) {
    auto start_p5 = crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaMut{Text::lit("doc")})), crate::lower::types::host_doc_ty()}), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("prism_rtl::HostDoc::new"), Array<crate::lower::model::Ex>{}})});
    auto body_p6 = crate::lower::node_::finish::document_body(({
        auto f = prism_rtl::rc(crate::lower::node_::finish::map_insert);
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::lower::model::Do>(std::tuple<crate::lower::model::Ex, crate::lower::model::Ex>)>>(prism_rtl::rc([=, f = std::move(f)](std::tuple<crate::lower::model::Ex, crate::lower::model::Ex> _p0) {
        auto&& a0 = std::get<0>(_p0);
        auto&& a1 = std::get<1>(_p0);
        return ({
            auto f_1 = f;
            once_job([=, f_1 = std::move(f_1)]() { return prism_rtl::finished(f_1(a0, a1)); });
        });
    })));
    }), places_p2, builders_p3, gens_p4);
    return crate::lower::model::MethDef{.name = name_p0, .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxRef{}), .ret = crate::lower::types::host_doc_ty(), .body = append(Array(std::vector{start_p5}), body_p6), .tail = crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("doc")}), .doc = prism_rtl::cat("The places of the child hosted at place ", crate::lower::model::place_text(pos_p1), ": each place\'s entry by its path relative to the child (pick HO). Read only by the snapshot of `$doc`\'s outer (pick ST).")};
}


/// SnapGetter: fn Text, OutTy, Text -> MethDef
crate::lower::model::MethDef snap_getter(const Text& name_p0, const crate::lower::model::OutTy& t_p1, const Text& doc_p2) {
    return crate::lower::model::MethDef{.name = name_p0, .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxRef{}), .ret = t_p1, .body = Array<crate::lower::model::Do>{}, .tail = crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), prism_rtl::cat(name_p0, "_snap")})), Text::lit("get"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), .doc = doc_p2};
}


/// StartedLine: fn Wx, ?Bn -> ((Wx, Wres))
std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> started_line(const crate::lower::node_::Wx& wx_p0, const std::optional<crate::lower::types::Bn>& bound_o1) {
    auto wx1_p2 = ({
        crate::lower::node_::Wx this_ = wx_p0;
        this_.pos = crate::lower::model::next_pos(this_.pos);
        (std::move(this_));
    });
    auto [id_p7, wx2_p8] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Nat, crate::lower::node_::Wx>> _v;
        if (prism_rtl::is_some(bound_o1) && prism_rtl::is<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(bound_o1))) {
            auto&& er_p4 = prism_rtl::as<crate::lower::types::Bn::BnEv>(prism_rtl::some_of(bound_o1)).a0;
            _v.set(std::tuple{prism_rtl::deref(er_p4).node_, wx1_p2});
            goto _done;
        }
        {
            _v.set(({
                auto [nm_p5, w_p6] = crate::lower::node_::fresh_name(wx1_p2, Text::lit("started"));
                (crate::lower::node_::add_gn(w_p6, nm_p5, crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), crate::lower::node_::GnKind(crate::lower::node_::GnKind::GnStarted{}), Nat(0u)));
            }));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto wx3_p3 = ({
        crate::lower::node_::Wx this_ = wx2_p8;
        this_.started = crate::prelude::push(this_.started, id_p7);
        (std::move(this_));
    });
    return std::tuple{wx3_p3, crate::lower::node_::Wres(crate::lower::node_::Wres::WrEv{crate::lower::node_::ev_ref_of(wx3_p3, id_p7)})};
}


/// DeferLine: unbounded fn Wx, Env, [Arg], Expr, ?Nat -> ((Wx, Wres))
std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> defer_line(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& menv_p1, const Array<crate::syntax::Arg>& args_p2, const crate::syntax::Expr& e_p3, const std::optional<Nat>& target_o4) {
    auto lx_p5 = wx_p0.lx;
    auto t_p6 = crate::lower::types::out_ty_of(lx_p5, crate::lower::types::out_of(crate::lower::type_at(lx_p5, e_p3.span)));
    auto [field_p9, wx1_pa] = crate::lower::node_::fresh_name(wx_p0, Text::lit("deferred"));
    auto [id_pc, wx2_pd] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Nat, crate::lower::node_::Wx>> _v;
        if (prism_rtl::is_some(target_o4)) {
            auto&& n_pb = prism_rtl::some_of(target_o4);
            _v.set(std::tuple{n_pb, wx1_pa});
            goto _done;
        }
        if (prism_rtl::is_none(target_o4)) {
            _v.set(crate::lower::node_::add_gn(wx1_pa, prism_rtl::cat(field_p9, "_fired"), t_p6, crate::lower::node_::GnKind(crate::lower::node_::GnKind::GnDeferred{}), Nat(0u)));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto wx3_p7 = crate::lower::node_::add_field_last(wx2_pd, field_p9, crate::lower::model::OutTy(crate::lower::model::OutTy::OutDefer{prism_rtl::rc(t_p6)}), Text::lit("`@Defer`"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Defer::new"), Array<crate::lower::model::Ex>{}}));
    auto wx4_p8 = ({
        crate::lower::node_::Wx this_ = wx3_p7;
        this_.defers = crate::prelude::push(this_.defers, std::tuple{field_p9, id_pc});
        (std::move(this_));
    });
    auto&& _m = index(args_p2, Nat(0u));
    if (prism_rtl::is_some(_m)) {
        auto&& a_pe = prism_rtl::some_of(_m);
        auto [r_pf, wx5_pg] = crate::lower::node_::dynamics::event_ref(wx4_p8, menv_p1, a_pe->value);
        return std::tuple{crate::lower::node_::connect(wx5_pg, r_pf, crate::lower::node_::Sk(crate::lower::node_::Sk::SkArm{field_p9})), crate::lower::node_::Wres(crate::lower::node_::Wres::WrEv{crate::lower::node_::ev_ref_of(wx5_pg, id_pc)})};
    }
    if (prism_rtl::is_none(_m)) {
        return std::tuple{wx4_p8, crate::lower::node_::Wres(crate::lower::node_::Wres::WrEv{crate::lower::node_::ev_ref_of(wx4_p8, id_pc)})};
    }
    prism_rtl::unreachable("no arm matched");
}


/// DistinctLine: unbounded fn Wx, Env, [Arg], Expr, ?Bn -> ((Wx, Wres))
std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> distinct_line(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& menv_p1, const Array<crate::syntax::Arg>& args_p2, const crate::syntax::Expr& e_p3, const std::optional<crate::lower::types::Bn>& bound_o4) {
    auto lx_p5 = wx_p0.lx;
    auto&& _m = index(args_p2, Nat(0u));
    if (prism_rtl::is_none(_m)) {
        auto wx2_p6 = ({
            crate::lower::node_::Wx this_ = wx_p0;
            this_.build = crate::prelude::push(this_.build, crate::lower::expr::refusal_do(Text::lit("an `@Distinct` without its dynamic")));
            (std::move(this_));
        });
        return std::tuple{wx2_p6, crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{})};
    }
    if (prism_rtl::is_some(_m)) {
        auto&& a_p7 = prism_rtl::some_of(_m);
        auto t_p8 = crate::lower::types::out_ty_of(lx_p5, crate::lower::types::peel(crate::lower::type_at(lx_p5, prism_rtl::deref(a_p7->value).span)));
        auto [name_pg, wx1_ph] = ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<Text, crate::lower::node_::Wx>> _v;
            if (prism_rtl::is_some(bound_o4) && prism_rtl::is<crate::lower::types::Bn::BnHold>(prism_rtl::some_of(bound_o4))) {
                auto&& f_pe = prism_rtl::as<crate::lower::types::Bn::BnHold>(prism_rtl::some_of(bound_o4)).a0;
                _v.set(std::tuple{f_pe, wx_p0});
                goto _done;
            }
            if (prism_rtl::is_some(bound_o4) && prism_rtl::is<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(bound_o4)) && prism_rtl::is<crate::lower::model::Ex::XMethod>(prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(bound_o4)).a0)) {
                auto&& m20396_1_0_0 = prism_rtl::as<crate::lower::model::Ex::XMethod>(prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(bound_o4)).a0).a0;
                auto&& f_pf = prism_rtl::as<crate::lower::model::Ex::XMethod>(prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(bound_o4)).a0).a1;
                if (prism_rtl::is<crate::lower::model::Ex::XSelf>(prism_rtl::deref(prism_rtl::deref(m20396_1_0_0)))) {
                    _v.set(std::tuple{f_pf, wx_p0});
                    goto _done;
                }
            }
            {
                _v.set(crate::lower::node_::fresh_name(wx_p0, Text::lit("distinct")));
                goto _done;
            }
        _done:
            _v.take();
        });
        auto kept_p9 = prism_rtl::cat(name_pg, "_kept");
        auto source_pa = prism_rtl::cat(name_pg, "_source");
        auto [ex_pi, reads_pj] = crate::lower::node_::dynamics::dynamic_expr(wx1_ph, menv_p1, a_p7->value);
        auto first_pb = crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")})), kept_p9})), Text::lit("set"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")})), source_pa, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})})}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})});
        auto sample_pc = crate::lower::model::Ex(crate::lower::model::Ex::XMatch{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), kept_p9})), Text::lit("get"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})), Array(std::vector{crate::lower::model::XArm{.pat = crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{Text::lit("Some"), Array(std::vector{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{Text::lit("v")})})}), .conds = Array<crate::lower::model::Cc>{}, .body = crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("v")})}, crate::lower::model::XArm{.pat = crate::lower::model::Pa(crate::lower::model::Pa::PaUnit{Text::lit("None")}), .conds = Array<crate::lower::model::Cc>{}, .body = crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), source_pa, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})}}), false, t_p8});
        auto wx2_pd = ({
            crate::lower::node_::Wx this_ = wx1_ph;
            this_.taken = append(this_.taken, Array(std::vector{kept_p9, source_pa}));
            this_.fields = crate::prelude::push(this_.fields, std::tuple{kept_p9, crate::lower::model::OutTy(crate::lower::model::OutTy::OutHold{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutOpt{prism_rtl::rc(t_p8)}))}), Text::lit("`@Distinct`\'s value: its source\'s, written only when it changes")});
            this_.moves = crate::prelude::push(this_.moves, std::tuple{kept_p9, crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Hold::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XNone{}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})});
            this_.build = crate::prelude::push(this_.build, first_pb);
            this_.getters = append(this_.getters, Array(std::vector{crate::lower::model::MethDef{.name = source_pa, .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxRef{}), .ret = t_p8, .body = Array<crate::lower::model::Do>{}, .tail = ex_pi, .doc = Text::lit("`@Distinct`\'s source, read at the build.")}, crate::lower::model::MethDef{.name = name_pg, .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxRef{}), .ret = t_p8, .body = Array<crate::lower::model::Do>{}, .tail = sample_pc, .doc = Text::lit("`@Distinct`\'s dynamic: the value it holds at the read point.")}}));
            this_.dyn_reads = insert(insert(this_.dyn_reads, name_pg, Array(std::vector{crate::lower::node_::Read(crate::lower::node_::Read::OwnRead{kept_p9})})), source_pa, reads_pj);
            (std::move(this_));
        });
        auto [r_pk, wx3_pl] = crate::lower::node_::dynamics::updated_event(wx2_pd, menv_p1, args_p2, t_p8);
        return std::tuple{crate::lower::node_::connect(wx3_pl, r_pk, crate::lower::node_::Sk(crate::lower::node_::Sk::SkDistinct{kept_p9})), crate::lower::node_::Wres(crate::lower::node_::Wres::WrDyn{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), name_pg, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), Array(std::vector{crate::lower::node_::Read(crate::lower::node_::Read::OwnRead{kept_p9})}), t_p8})};
    }
    prism_rtl::unreachable("no arm matched");
}


/// PerKeyLine: unbounded fn Wx, Env, [Arg], ?Bn -> ((Wx, Wres))
std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> per_key_line(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& menv_p1, const Array<crate::syntax::Arg>& args_p2, const std::optional<crate::lower::types::Bn>& bound_o3) {
    auto lx_p4 = wx_p0.lx;
    auto&& _m = index(args_p2, Nat(0u));
    if (prism_rtl::is_none(_m)) {
        auto wx2_p5 = ({
            crate::lower::node_::Wx this_ = wx_p0;
            this_.build = crate::prelude::push(this_.build, crate::lower::expr::refusal_do(Text::lit("an `@PerKey` without its dynamic")));
            (std::move(this_));
        });
        return std::tuple{wx2_p5, crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{})};
    }
    if (prism_rtl::is_some(_m)) {
        auto&& a_p6 = prism_rtl::some_of(_m);
        auto [kt_pg, vt_ph] = ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<crate::lower::model::OutTy, crate::lower::model::OutTy>> _v;
            auto&& _m = crate::lower::types::peel(crate::lower::type_at(lx_p4, prism_rtl::deref(a_p6->value).span));
            if (prism_rtl::is<crate::check::types::Ty::TyMap>(_m)) {
                auto&& k_pe = prism_rtl::as<crate::check::types::Ty::TyMap>(_m).a0;
                auto&& v_pf = prism_rtl::as<crate::check::types::Ty::TyMap>(_m).a1;
                _v.set(std::tuple{crate::lower::types::out_ty_of(lx_p4, prism_rtl::deref(k_pe)), crate::lower::types::out_ty_of(lx_p4, prism_rtl::deref(v_pf))});
                goto _done;
            }
            {
                _v.set(std::tuple{crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})});
                goto _done;
            }
        _done:
            _v.take();
        });
        auto src_ty_p7 = crate::lower::model::OutTy(crate::lower::model::OutTy::OutMap{prism_rtl::rc(kt_pg), prism_rtl::rc(vt_ph)});
        auto t_p8 = crate::lower::model::OutTy(crate::lower::model::OutTy::OutMap{prism_rtl::rc(kt_pg), prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutDyn{prism_rtl::rc(vt_ph)}))});
        auto [name_pk, wx1_pl] = ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<Text, crate::lower::node_::Wx>> _v;
            if (prism_rtl::is_some(bound_o3) && prism_rtl::is<crate::lower::types::Bn::BnHold>(prism_rtl::some_of(bound_o3))) {
                auto&& f_pi = prism_rtl::as<crate::lower::types::Bn::BnHold>(prism_rtl::some_of(bound_o3)).a0;
                _v.set(std::tuple{f_pi, wx_p0});
                goto _done;
            }
            if (prism_rtl::is_some(bound_o3) && prism_rtl::is<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(bound_o3)) && prism_rtl::is<crate::lower::model::Ex::XMethod>(prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(bound_o3)).a0)) {
                auto&& m23708_1_0_0 = prism_rtl::as<crate::lower::model::Ex::XMethod>(prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(bound_o3)).a0).a0;
                auto&& f_pj = prism_rtl::as<crate::lower::model::Ex::XMethod>(prism_rtl::as<crate::lower::types::Bn::BnDyn>(prism_rtl::some_of(bound_o3)).a0).a1;
                if (prism_rtl::is<crate::lower::model::Ex::XSelf>(prism_rtl::deref(prism_rtl::deref(m23708_1_0_0)))) {
                    _v.set(std::tuple{f_pj, wx_p0});
                    goto _done;
                }
            }
            {
                _v.set(crate::lower::node_::fresh_name(wx_p0, Text::lit("per_key")));
                goto _done;
            }
        _done:
            _v.take();
        });
        auto kept_p9 = prism_rtl::cat(name_pk, "_kept");
        auto source_pa = prism_rtl::cat(name_pk, "_source");
        auto [ex_pm, reads_pn] = crate::lower::node_::dynamics::dynamic_expr(wx1_pl, menv_p1, a_p6->value);
        auto first_pb = crate::lower::model::Do(crate::lower::model::Do::DoExpr{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")})), kept_p9})), Text::lit("start"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{Text::lit("node")})), source_pa, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})})});
        auto sample_pc = crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XField{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), kept_p9})), Text::lit("outer"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{}), crate::lower::model::Ex(crate::lower::model::Ex::XClosure{false, Array<crate::lower::model::Pa>{}, prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), source_pa, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}))})})});
        auto wx2_pd = ({
            crate::lower::node_::Wx this_ = wx1_pl;
            this_.taken = append(this_.taken, Array(std::vector{kept_p9, source_pa}));
            this_.fields = crate::prelude::push(this_.fields, std::tuple{kept_p9, crate::lower::model::OutTy(crate::lower::model::OutTy::OutNamed{Text::lit("prism_rtl::PerKey"), Array(std::vector{kt_pg, vt_ph})}), Text::lit("`@PerKey`\'s outer and each key\'s inner")});
            this_.moves = crate::prelude::push(this_.moves, std::tuple{kept_p9, crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("prism_rtl::PerKey::new"), Array<crate::lower::model::Ex>{}})});
            this_.build = crate::prelude::push(this_.build, first_pb);
            this_.getters = append(this_.getters, Array(std::vector{crate::lower::model::MethDef{.name = source_pa, .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxRef{}), .ret = src_ty_p7, .body = Array<crate::lower::model::Do>{}, .tail = ex_pm, .doc = Text::lit("`@PerKey`\'s source, read at the build.")}, crate::lower::model::MethDef{.name = name_pk, .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxRef{}), .ret = t_p8, .body = Array<crate::lower::model::Do>{}, .tail = sample_pc, .doc = Text::lit("`@PerKey`\'s outer: each key\'s inner by key, at the read point.")}}));
            this_.dyn_reads = insert(insert(this_.dyn_reads, name_pk, Array(std::vector{crate::lower::node_::Read(crate::lower::node_::Read::OwnRead{kept_p9})})), source_pa, reads_pn);
            (std::move(this_));
        });
        auto [r_po, wx3_pp] = crate::lower::node_::dynamics::updated_event(wx2_pd, menv_p1, args_p2, src_ty_p7);
        return std::tuple{crate::lower::node_::connect(wx3_pp, r_po, crate::lower::node_::Sk(crate::lower::node_::Sk::SkPerKey{kept_p9})), crate::lower::node_::Wres(crate::lower::node_::Wres::WrDyn{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), name_pk, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), Array(std::vector{crate::lower::node_::Read(crate::lower::node_::Read::OwnRead{kept_p9})}), t_p8})};
    }
    prism_rtl::unreachable("no arm matched");
}


/// RunLine: unbounded fn Wx, Env, [Arg], Expr, ?Nat -> ((Wx, Wres))
std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> run_line(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& benv_p1, const Array<crate::syntax::Arg>& args_p2, const crate::syntax::Expr& e_p3, const std::optional<Nat>& target_o4) {
    auto lx_p5 = wx_p0.lx;
    auto t_p6 = crate::lower::types::out_ty_of(lx_p5, crate::lower::types::out_of(crate::lower::type_at(lx_p5, e_p3.span)));
    auto [p_pd, wx1_pe] = crate::lower::node_::fresh_name(wx_p0, Text::lit("run"));
    auto wx2_p7 = ({
        crate::lower::node_::Wx this_ = wx1_pe;
        this_.pos = crate::lower::model::next_pos(this_.pos);
        this_.taken = append(this_.taken, Array(std::vector{prism_rtl::cat(p_pd, "_job"), prism_rtl::cat(p_pd, "_again"), prism_rtl::cat(p_pd, "_started"), prism_rtl::cat(p_pd, "_turn")}));
        (std::move(this_));
    });
    auto start_p8 = ({
        __label__ _done;
        prism_rtl::Slot<crate::lower::model::Ex> _v;
        auto&& _m = index(args_p2, Nat(0u));
        if (prism_rtl::is_some(_m)) {
            auto&& a_pf = prism_rtl::some_of(_m);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<crate::lower::model::Ex> _v;
                auto&& _m = prism_rtl::deref(prism_rtl::deref(a_pf->value).kind);
                if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
                    auto&& n_pg = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
                    _v.set(({
                        auto&& _q_oh = crate::check::env::names::resolve_value(prism_rtl::deref(lx_p5).g, prism_rtl::deref(lx_p5).home, n_pg);
                        auto&& q_oh = std::get<0>(_q_oh);
                        (crate::lower::model::Ex(crate::lower::model::Ex::XPath{crate::lower::expr::start_path(lx_p5, or_(q_oh, Text::lit("")))}));
                    }));
                    goto _done;
                }
                {
                    _v.set(crate::lower::expr::refusal(Text::lit("an `@Run` of a function value that is not a name")));
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(crate::lower::expr::refusal(Text::lit("an `@Run` without its function")));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto x_p9 = ({
        __label__ _done;
        prism_rtl::Slot<crate::lower::model::Ex> _v;
        auto&& _m = index(args_p2, Nat(1u));
        if (prism_rtl::is_some(_m)) {
            auto&& a_pi = prism_rtl::some_of(_m);
            _v.set(crate::lower::types::own(crate::lower::expr::value_of(lx_p5, benv_p1, a_pi->value)));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto wx3_pa = crate::lower::node_::add_field(wx2_p7, prism_rtl::cat(p_pd, "_job"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutHold{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutJob{prism_rtl::rc(t_p6)}))}), Text::lit("`@Run`\'s job (`@Machine`\'s state)"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Hold::new"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XApply{prism_rtl::rc(start_p8), Array(std::vector{x_p9})}), crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}));
    auto wx4_pb = crate::lower::node_::add_field_last(wx3_pa, prism_rtl::cat(p_pd, "_again"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutDefer{prism_rtl::rc(crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}))}), Text::lit("`@Run`\'s `!again`"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Defer::new"), Array<crate::lower::model::Ex>{}}));
    auto [s_pj, wx5_pk] = crate::lower::node_::add_gn(wx4_pb, prism_rtl::cat(p_pd, "_started"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), crate::lower::node_::GnKind(crate::lower::node_::GnKind::GnStarted{}), Nat(0u));
    auto [a_pl, wx6_pm] = crate::lower::node_::add_gn(wx5_pk, prism_rtl::cat(p_pd, "_again"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), crate::lower::node_::GnKind(crate::lower::node_::GnKind::GnDeferred{}), Nat(0u));
    auto [m_pn, wx7_po] = crate::lower::node_::dynamics::merge(wx6_pm, prism_rtl::cat(p_pd, "_turn"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}), crate::lower::node_::ev_ref_of(wx6_pm, s_pj), crate::lower::node_::ev_ref_of(wx6_pm, a_pl));
    auto [res_pq, wx8_pr] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Nat, crate::lower::node_::Wx>> _v;
        if (prism_rtl::is_some(target_o4)) {
            auto&& n_pp = prism_rtl::some_of(target_o4);
            _v.set(std::tuple{n_pp, wx7_po});
            goto _done;
        }
        if (prism_rtl::is_none(target_o4)) {
            _v.set(crate::lower::node_::add_gn(wx7_po, prism_rtl::cat(p_pd, "_done"), t_p6, crate::lower::node_::GnKind(crate::lower::node_::GnKind::GnNamed{}), Nat(0u)));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto wx9_pc = ({
        crate::lower::node_::Wx this_ = crate::lower::node_::connect(wx8_pr, crate::lower::node_::ev_ref_of(wx8_pr, m_pn), crate::lower::node_::Sk(crate::lower::node_::Sk::SkCycle{prism_rtl::cat(p_pd, "_job"), prism_rtl::cat(p_pd, "_again"), res_pq}));
        this_.started = crate::prelude::push(this_.started, s_pj);
        this_.defers = crate::prelude::push(this_.defers, std::tuple{prism_rtl::cat(p_pd, "_again"), a_pl});
        (std::move(this_));
    });
    return std::tuple{wx9_pc, crate::lower::node_::Wres(crate::lower::node_::Wres::WrEv{crate::lower::node_::ev_ref_of(wx9_pc, res_pq)})};
}


/// MachineLine: unbounded fn Wx, Env, Env, [Arg], Expr, ?Nat -> ((Wx, Wres))
std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> machine_line(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& benv_p1, const crate::lower::types::Env& menv_p2, const Array<crate::syntax::Arg>& args_p3, const crate::syntax::Expr& e_p4, const std::optional<Nat>& target_o5) {
    auto lx_p6 = wx_p0.lx;
    auto t_p7 = crate::lower::types::out_ty_of(lx_p6, crate::lower::types::out_of(crate::lower::type_at(lx_p6, e_p4.span)));
    auto [f_p9, wx1_pa] = crate::lower::node_::fresh_name(wx_p0, Text::lit("machine"));
    auto step_p8 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = index(args_p3, Nat(0u));
        if (prism_rtl::is_some(_m)) {
            auto&& a_pb = prism_rtl::some_of(_m);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                auto&& _m = prism_rtl::deref(prism_rtl::deref(a_pb->value).kind);
                if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
                    auto&& n_pc = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
                    _v.set(({
                        auto&& _q_od = crate::check::env::names::resolve_value(prism_rtl::deref(lx_p6).g, prism_rtl::deref(lx_p6).home, n_pc);
                        auto&& q_od = std::get<0>(_q_od);
                        ({
                        __label__ _done;
                        prism_rtl::Slot<Text> _v;
                        if (prism_rtl::is_some(q_od)) {
                            auto&& q_pe = prism_rtl::some_of(q_od);
                            _v.set(crate::lower::value_path(lx_p6, q_pe));
                            goto _done;
                        }
                        if (prism_rtl::is_none(q_od)) {
                            _v.set(Text::lit(""));
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                    }));
                    goto _done;
                }
                {
                    _v.set(Text::lit(""));
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto&& _m = std::tuple{step_p8, index(args_p3, Nat(1u)), index(args_p3, Nat(2u))};
    if (prism_rtl::is_some(std::get<1>(_m)) && prism_rtl::is_some(std::get<2>(_m))) {
        auto&& sp_pf = std::get<0>(_m);
        auto&& init_pg = prism_rtl::some_of(std::get<1>(_m));
        auto&& ev_ph = prism_rtl::some_of(std::get<2>(_m));
        if (sp_pf != Text::lit("")) {
            auto st_pi = crate::lower::types::out_ty_of(lx_p6, crate::lower::types::peel(crate::lower::type_at(lx_p6, prism_rtl::deref(init_pg->value).span)));
            auto x_pj = crate::lower::types::own(crate::lower::expr::value_of(lx_p6, benv_p1, init_pg->value));
            auto wx2_pk = crate::lower::node_::add_field(wx1_pa, prism_rtl::cat(f_p9, "_state"), crate::lower::model::OutTy(crate::lower::model::OutTy::OutHold{prism_rtl::rc(st_pi)}), Text::lit("`@Machine`\'s state"), crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Hold::new"), Array(std::vector{x_pj, crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}));
            auto [out_pm, wx3_pn] = ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<Nat, crate::lower::node_::Wx>> _v;
                if (prism_rtl::is_some(target_o5)) {
                    auto&& n_pl = prism_rtl::some_of(target_o5);
                    _v.set(std::tuple{n_pl, wx2_pk});
                    goto _done;
                }
                if (prism_rtl::is_none(target_o5)) {
                    _v.set(crate::lower::node_::add_gn(wx2_pk, prism_rtl::cat(f_p9, "_fired"), t_p7, crate::lower::node_::GnKind(crate::lower::node_::GnKind::GnNamed{}), Nat(0u)));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            auto [r_po, wx4_pp] = crate::lower::node_::dynamics::event_ref(wx3_pn, menv_p2, ev_ph->value);
            return std::tuple{crate::lower::node_::connect(wx4_pp, r_po, crate::lower::node_::Sk(crate::lower::node_::Sk::SkMachine{prism_rtl::cat(f_p9, "_state"), sp_pf, out_pm})), crate::lower::node_::Wres(crate::lower::node_::Wres::WrEv{crate::lower::node_::ev_ref_of(wx4_pp, out_pm)})};
        }
    }
    {
        auto wx2_pq = ({
            crate::lower::node_::Wx this_ = wx1_pa;
            this_.build = crate::prelude::push(this_.build, crate::lower::expr::refusal_do(Text::lit("an `@Machine` whose step is not a named function")));
            (std::move(this_));
        });
        return std::tuple{wx2_pq, crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{})};
    }
}


/// InlineWidget: unbounded fn Wx, Env, Env, Text, ValInfo, [Arg], Expr -> ((Wx, Wres))
std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> inline_widget(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& benv_p1, const crate::lower::types::Env& menv_p2, const Text& qk_p3, const crate::check::env::ValInfo& v_p4, const Array<crate::syntax::Arg>& args_p5, const crate::syntax::Expr& e_p6) {
    auto lx_p7 = wx_p0.lx;
    auto clauses_p8 = crate::lower::jobs::clauses_of(prism_rtl::deref(lx_p7).g, qk_p3);
    auto w_o9 = widget_decl_of(prism_rtl::deref(lx_p7).g, qk_p3);
    auto [params_pe, body_of] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Array<crate::syntax::Pattern_>, std::optional<crate::syntax::Block>>> _v;
        if (prism_rtl::is_some(w_o9)) {
            auto&& wd_pa = prism_rtl::some_of(w_o9);
            _v.set(std::tuple{Array<crate::syntax::Pattern_>{}, std::optional(prism_rtl::deref(wd_pa).body)});
            goto _done;
        }
        if (prism_rtl::is_none(w_o9)) {
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::tuple<Array<crate::syntax::Pattern_>, std::optional<crate::syntax::Block>>> _v;
                {
                    auto&& m29415_0 = clauses_p8;
                    if (m29415_0.size() == 1u) {
                        {
                            auto&& _c1 = index(m29415_0, Nat(0u));
                            if (prism_rtl::is_some(_c1)) {
                                auto&& c_pb = prism_rtl::some_of(_c1);
                                _v.set(({
                                    __label__ _done;
                                    prism_rtl::Slot<std::tuple<Array<crate::syntax::Pattern_>, std::optional<crate::syntax::Block>>> _v;
                                    auto&& _m = prism_rtl::deref(c_pb).body;
                                    if (prism_rtl::is<crate::syntax::decls::FnBody::BodyBlock>(_m)) {
                                        auto&& b_pc = prism_rtl::as<crate::syntax::decls::FnBody::BodyBlock>(_m).a0;
                                        _v.set(std::tuple{prism_rtl::deref(c_pb).params, std::optional(b_pc)});
                                        goto _done;
                                    }
                                    if (prism_rtl::is<crate::syntax::decls::FnBody::BodyExpr>(_m)) {
                                        auto&& x_pd = prism_rtl::as<crate::syntax::decls::FnBody::BodyExpr>(_m).a0;
                                        _v.set(std::tuple{prism_rtl::deref(c_pb).params, std::optional(crate::syntax::Block{.stmts = Array(std::vector{crate::syntax::Stmt{.kind = crate::syntax::StmtKind(crate::syntax::StmtKind::SExpr{x_pd}), .span = prism_rtl::deref(x_pd).span}}), .inline_ = true, .span = prism_rtl::deref(x_pd).span})});
                                        goto _done;
                                    }
                                    prism_rtl::unreachable("no arm matched");
                                _done:
                                    _v.take();
                                }));
                                goto _done;
                            }
                        }
                    }
                }
                {
                    _v.set(std::tuple{Array<crate::syntax::Pattern_>{}, std::optional<crate::syntax::Block>{}});
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    if (prism_rtl::is_none(body_of)) {
        return len(clauses_p8) == Nat(0u)
            ? ({
            auto wx2_pg = ({
                crate::lower::node_::Wx this_ = wx_p0;
                this_.build = crate::prelude::push(this_.build, crate::lower::expr::refusal_do(prism_rtl::cat("the builtin widget ", crate::check::types::bare_name(qk_p3))));
                (std::move(this_));
            });
            std::tuple{wx2_pg, crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{})};
        })
            : ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres>> _v;
            auto&& _m = index(args_p5, Nat(0u));
            if (prism_rtl::is_some(_m)) {
                auto&& a_ph = prism_rtl::some_of(_m);
                _v.set(({
                    auto call_pi = crate::syntax::Block{.stmts = Array(std::vector{crate::syntax::Stmt{.kind = crate::syntax::StmtKind(crate::syntax::StmtKind::SExpr{e_p6}), .span = e_p6.span}}), .inline_ = true, .span = e_p6.span};
                    (crate::lower::node_::switch_::clause_widget_line(wx_p0, menv_p2, a_ph->value, call_pi, qk_p3, v_p4, e_p6));
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(({
                    auto wx2_pj = ({
                        crate::lower::node_::Wx this_ = wx_p0;
                        this_.build = crate::prelude::push(this_.build, crate::lower::expr::refusal_do(Text::lit("a widget of several clauses that takes no arguments")));
                        (std::move(this_));
                    });
                    std::tuple{wx2_pj, crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{})};
                }));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    }
    if (prism_rtl::is_some(body_of)) {
        auto&& body_pk = prism_rtl::some_of(body_of);
        return recursion(wx_p0.inlining, qk_p3) > Nat(16u)
            ? too_deep(wx_p0, qk_p3, e_p6)
            : ({
            auto lxc_pl = crate::lower::program::in_module_at(lx_p7, v_p4.file, v_p4.home, prism_rtl::deref(lx_p7).site);
            auto ptys_pm = ({
                __label__ _done;
                prism_rtl::Slot<Array<crate::check::types::Ty>> _v;
                auto&& _m = prism_rtl::deref(v_p4.scheme).ty;
                if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
                    auto&& ps_pq = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a1;
                    _v.set(ps_pq);
                    goto _done;
                }
                {
                    _v.set(Array<crate::check::types::Ty>{});
                    goto _done;
                }
            _done:
                _v.take();
            });
            auto [wx1_p13, be1_p14, me1_p15] = run_to_end(fold_job(crate::check::errors::range0(len(params_pe)), std::tuple{wx_p0, crate::lower::types::empty_env(), crate::lower::types::empty_env()}, ({
                auto params_pe_1 = params_pe;
                auto lxc_pl_2 = lxc_pl;
                auto ptys_pm_3 = ptys_pm;
                auto args_p5_4 = args_p5;
                auto benv_p1_5 = benv_p1;
                auto menv_p2_6 = menv_p2;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>>(std::tuple<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>, Nat>)>>(prism_rtl::rc([=, params_pe_1 = std::move(params_pe_1), lxc_pl_2 = std::move(lxc_pl_2), ptys_pm_3 = std::move(ptys_pm_3), args_p5_4 = std::move(args_p5_4), benv_p1_5 = std::move(benv_p1_5), menv_p2_6 = std::move(menv_p2_6)](std::tuple<std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env>, Nat> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto params_pe_1_7 = params_pe_1;
                    auto lxc_pl_2_7 = lxc_pl_2;
                    auto ptys_pm_3_7 = ptys_pm_3;
                    auto args_p5_4_7 = args_p5_4;
                    auto benv_p1_5_7 = benv_p1_5;
                    auto menv_p2_6_7 = menv_p2_6;
                    entered(once_job([=, params_pe_1_7 = std::move(params_pe_1_7), lxc_pl_2_7 = std::move(lxc_pl_2_7), ptys_pm_3_7 = std::move(ptys_pm_3_7), args_p5_4_7 = std::move(args_p5_4_7), benv_p1_5_7 = std::move(benv_p1_5_7), menv_p2_6_7 = std::move(menv_p2_6_7)]() {
                    return ({
                        auto [w_pr, be_ps, me_pt] = p0;
                        auto i_pu = p1;
                        ({
                        auto p_pv = or_(index(params_pe_1_7, i_pu), crate::lower::patterns::dummy_pat());
                        auto nkey_p10 = crate::lower::functions::plain_binder(lxc_pl_2_7, p_pv);
                        auto pty_p11 = or_(index(ptys_pm_3_7, i_pu), crate::check::types::Ty(crate::check::types::Ty::TyErr{}));
                        ({
                        auto&& _m = index(args_p5_4_7, i_pu);
                        prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{w_pr, be_ps, me_pt})
                        : prism_rtl::is_some(_m) ? ({
                        auto&& a_p12 = prism_rtl::some_of(_m);
                        prism_rtl::finished(bind_param(w_pr, benv_p1_5_7, menv_p2_6_7, be_ps, me_pt, nkey_p10, pty_p11, a_p12->value));
                    })
                        : throw prism_rtl::Panic("no arm matched");
                    });
                    });
                    });
                }));
                });
            }));
            })));
            auto inner_pn = ({
                crate::lower::node_::Wx this_ = wx1_p13;
                this_.lx = lxc_pl;
                this_.inlining = crate::prelude::push(this_.inlining, qk_p3);
                this_.result = crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{});
                (std::move(this_));
            });
            auto done_po = crate::lower::node_::def::block_into(inner_pn, be1_p14, me1_p15, body_pk);
            auto back_pp = ({
                crate::lower::node_::Wx this_ = done_po;
                this_.lx = lx_p7;
                this_.inlining = wx_p0.inlining;
                this_.result = wx_p0.result;
                (std::move(this_));
            });
            std::tuple{back_pp, done_po->result};
        });
    }
    prism_rtl::unreachable("no arm matched");
}


/// Recursion: fn [Text], Text -> Nat
Nat recursion(const Array<Text>& inlining_p0, const Text& qk_p1) {
    return fold(inlining_p0, Nat(0u), [&](const Nat& n_p2, const Text& k_p3) { return k_p3 == qk_p1 ? n_p2 + Nat(1u) : n_p2; });
}


/// TooDeep: unbounded fn Wx, Text, Expr -> ((Wx, Wres))
std::tuple<crate::lower::node_::Wx, crate::lower::node_::Wres> too_deep(const crate::lower::node_::Wx& wx_p0, const Text& qk_p1, const crate::syntax::Expr& e_p2) {
    auto lx_p3 = wx_p0.lx;
    auto what_p4 = prism_rtl::cat("`", crate::check::types::bare_name(qk_p1), "` recurses deeper than the compiler inlines it (16 levels)");
    auto wx1_p5 = ({
        crate::lower::node_::Wx this_ = wx_p0;
        this_.build = crate::prelude::push(this_.build, crate::lower::model::Do(crate::lower::model::Do::DoReturn{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Err"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Fault::too_deep"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XStr{what_p4})})})})})}));
        this_.fallible = true;
        (std::move(this_));
    });
    auto t_p6 = crate::lower::types::out_ty_of(lx_p3, crate::lower::types::out_of(crate::lower::type_at(lx_p3, e_p2.span)));
    auto called_p7 = ({
        __label__ _done;
        prism_rtl::Slot<crate::check::types::Ty> _v;
        auto&& _m = crate::lower::type_at(lx_p3, e_p2.span);
        if (prism_rtl::is<crate::check::types::Ty::TyAt>(_m)) {
            auto&& i_p8 = prism_rtl::as<crate::check::types::Ty::TyAt>(_m).a0;
            _v.set(prism_rtl::deref(i_p8));
            goto _done;
        }
        {
            auto&& other_p9 = _m;
            _v.set(other_p9);
            goto _done;
        }
    _done:
        _v.take();
    });
    auto&& _m = crate::lower::types::layer_of(called_p7);
    if (prism_rtl::is<crate::lower::types::Layer::LyDyn>(_m)) {
        return std::tuple{wx1_p5, crate::lower::node_::Wres(crate::lower::node_::Wres::WrDyn{crate::lower::model::Ex(crate::lower::model::Ex::XUnreachable{}), Array<crate::lower::node_::Read>{}, t_p6})};
    }
    if (prism_rtl::is<crate::lower::types::Layer::LyEv>(_m)) {
        auto [id_pa, wx2_pb] = crate::lower::node_::add_gn(wx1_p5, Text::lit("too_deep"), t_p6, crate::lower::node_::GnKind(crate::lower::node_::GnKind::GnNever{}), Nat(0u));
        return std::tuple{wx2_pb, crate::lower::node_::Wres(crate::lower::node_::Wres::WrEv{crate::lower::node_::ev_ref_of(wx2_pb, id_pa)})};
    }
    {
        return t_p6 == crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})
            ? std::tuple{wx1_p5, crate::lower::node_::Wres(crate::lower::node_::Wres::WrUnit{})}
            : ({
            auto wx2_pc = ({
                crate::lower::node_::Wx this_ = wx1_p5;
                this_.lets = crate::prelude::push(this_.lets, crate::lower::model::Do(crate::lower::model::Do::DoReturn{crate::lower::model::Ex(crate::lower::model::Ex::XCtor{Text::lit("Err"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCall{Text::lit("Fault::too_deep"), Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XStr{what_p4})})})})})}));
                (std::move(this_));
            });
            std::tuple{wx2_pc, crate::lower::node_::Wres(crate::lower::node_::Wres::WrPlain{crate::lower::model::Ex(crate::lower::model::Ex::XUnreachable{}), t_p6})};
        });
    }
}


/// ?WidgetDeclOf: fn G, Text -> ?WidgetDecl
std::optional<crate::syntax::decls::WidgetDecl> widget_decl_of(const crate::check::env::G& g_p0, const Text& qk_p1) {
    return fold(g_p0.defs, std::optional<crate::syntax::decls::WidgetDecl>{}, [&](const std::optional<crate::syntax::decls::WidgetDecl>& found_o2, const crate::check::env::Def& d_p3) { return prism_rtl::deref(d_p3).qk == qk_p1 ? def_widget(d_p3, found_o2) : found_o2; });
}


/// ?DefWidget: fn Def, ?WidgetDecl -> ?WidgetDecl
std::optional<crate::syntax::decls::WidgetDecl> def_widget(const crate::check::env::Def& d_p0, const std::optional<crate::syntax::decls::WidgetDecl>& other_o1) {
    auto&& _m = d_p0.body;
    if (prism_rtl::is<crate::check::env::DefBody::DbWidget>(_m)) {
        auto&& w_p2 = prism_rtl::as<crate::check::env::DefBody::DbWidget>(_m).a0;
        return std::optional(w_p2);
    }
    {
        return other_o1;
    }
}


/// BindParam: unbounded fn Wx, Env, Env, Env, Env, Text, Ty, Expr -> ((Wx, Env, Env))
std::tuple<crate::lower::node_::Wx, crate::lower::types::Env, crate::lower::types::Env> bind_param(const crate::lower::node_::Wx& wx_p0, const crate::lower::types::Env& cbenv_p1, const crate::lower::types::Env& cmenv_p2, const crate::lower::types::Env& be_p3, const crate::lower::types::Env& me_p4, const Text& nkey_p5, const crate::check::types::Ty& pty_p6, const crate::syntax::Expr& arg_p7) {
    auto lx_p8 = wx_p0.lx;
    auto t_p9 = crate::lower::types::out_ty_of(lx_p8, crate::lower::types::peel(pty_p6));
    auto&& _m = crate::lower::types::layer_of(pty_p6);
    if (prism_rtl::is<crate::lower::types::Layer::LyBlueprint>(_m)) {
        auto b_pa = crate::lower::types::Bn(crate::lower::types::Bn::BnWidget{arg_p7, cbenv_p1, cmenv_p2, lx_p8});
        return std::tuple{wx_p0, crate::lower::types::bind(be_p3, nkey_p5, b_pa), crate::lower::types::bind(me_p4, nkey_p5, b_pa)};
    }
    if (prism_rtl::is<crate::lower::types::Layer::LyEv>(_m)) {
        auto [r_pc, wx2_pd] = crate::lower::node_::dynamics::event_ref(wx_p0, cmenv_p2, arg_p7);
        auto b_pb = crate::lower::types::Bn(crate::lower::types::Bn::BnEv{r_pc, t_p9});
        return std::tuple{wx2_pd, crate::lower::types::bind(be_p3, nkey_p5, b_pb), crate::lower::types::bind(me_p4, nkey_p5, b_pb)};
    }
    if (prism_rtl::is<crate::lower::types::Layer::LyDyn>(_m)) {
        auto [ex_pf, reads_pg] = crate::lower::node_::dynamics::dynamic_expr(wx_p0, cmenv_p2, arg_p7);
        auto b_pe = crate::lower::types::Bn(crate::lower::types::Bn::BnDyn{ex_pf, reads_pg, t_p9});
        auto [wx0_pk, be0_pl] = crate::lower::node_::def::all_inited(wx_p0, reads_pg) && crate::lower::node_::def::names_inited(cbenv_p1, arg_p7)
            ? ({
            auto [rsi_pi, wxi_pj] = crate::lower::node_::fresh_name(wx_p0, prism_rtl::cat(crate::lower::snake(nkey_p5), "_arg"));
            auto wxj_ph = ({
                crate::lower::node_::Wx this_ = wxi_pj;
                this_.lets = crate::prelude::push(this_.lets, crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaTyped{prism_rtl::rc(crate::lower::model::Pa(crate::lower::model::Pa::PaBind{prism_rtl::cat(rsi_pi, "_init")})), t_p9}), crate::lower::types::own(crate::lower::expr::value_of(lx_p8, crate::lower::node_::def::init_env(cbenv_p1), arg_p7))}));
                this_.inited = crate::prelude::push(this_.inited, rsi_pi);
                (std::move(this_));
            });
            std::tuple{wxj_ph, crate::lower::types::bind(be_p3, prism_rtl::cat(nkey_p5, "#init"), crate::lower::types::Bn(crate::lower::types::Bn::BnLocal{crate::lower::model::Ex(crate::lower::model::Ex::XVar{prism_rtl::cat(rsi_pi, "_init")}), crate::lower::types::Holding(crate::lower::types::Holding::Owned{}), t_p9}))};
        })
            : std::tuple{wx_p0, be_p3};
        if (prism_rtl::is<crate::lower::model::Ex::XMethod>(ex_pf)) {
            auto&& m35769_0_0 = prism_rtl::as<crate::lower::model::Ex::XMethod>(ex_pf).a0;
            if (prism_rtl::is<crate::lower::model::Ex::XSelf>(prism_rtl::deref(prism_rtl::deref(m35769_0_0)))) {
                return std::tuple{wx0_pk, crate::lower::types::bind(be0_pl, nkey_p5, b_pe), crate::lower::types::bind(me_p4, nkey_p5, b_pe)};
            }
        }
        {
            auto [rs_pp, wx2_pq] = crate::lower::node_::fresh_name(wx0_pk, crate::lower::snake(nkey_p5));
            auto getter_pm = crate::lower::model::MethDef{.name = rs_pp, .recv = crate::lower::model::Recv(crate::lower::model::Recv::RecvRef{}), .params = Array<std::tuple<Text, crate::lower::model::OutTy>>{}, .cx_ = crate::lower::model::CxArg(crate::lower::model::CxArg::CxRef{}), .ret = t_p9, .body = Array<crate::lower::model::Do>{}, .tail = ex_pf, .doc = prism_rtl::cat("`", nkey_p5, "`, a widget\'s parameter, as its rows read it")};
            auto wx3_pn = ({
                crate::lower::node_::Wx this_ = wx2_pq;
                this_.getters = crate::prelude::push(this_.getters, getter_pm);
                this_.dyn_reads = insert(this_.dyn_reads, rs_pp, reads_pg);
                (std::move(this_));
            });
            auto rb_po = crate::lower::types::Bn(crate::lower::types::Bn::BnDyn{crate::lower::model::Ex(crate::lower::model::Ex::XMethod{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})), rs_pp, Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XCx{})})}), Array(std::vector{crate::lower::node_::Read(crate::lower::node_::Read::OwnRead{rs_pp})}), t_p9});
            return std::tuple{wx3_pn, crate::lower::types::bind(crate::lower::types::bind(be0_pl, nkey_p5, b_pe), prism_rtl::cat(nkey_p5, "#row"), rb_po), crate::lower::types::bind(crate::lower::types::bind(me_p4, nkey_p5, b_pe), prism_rtl::cat(nkey_p5, "#row"), rb_po)};
        }
    }
    {
        auto [rs_pt, wx2_pu] = crate::lower::node_::fresh_name(wx_p0, crate::lower::snake(nkey_p5));
        auto v_pr = crate::lower::types::own(crate::lower::expr::value_of(lx_p8, cbenv_p1, arg_p7));
        auto wx3_ps = ({
            crate::lower::node_::Wx this_ = wx2_pu;
            this_.lets = crate::prelude::push(this_.lets, crate::lower::model::Do(crate::lower::model::Do::DoLet{crate::lower::model::Pa(crate::lower::model::Pa::PaBind{rs_pt}), v_pr}));
            this_.fields = crate::prelude::push(this_.fields, std::tuple{rs_pt, t_p9, prism_rtl::cat("`", nkey_p5, "`")});
            this_.inits = crate::prelude::push(this_.inits, std::tuple{rs_pt, crate::lower::model::Ex(crate::lower::model::Ex::XClone{prism_rtl::rc(crate::lower::model::Ex(crate::lower::model::Ex::XVar{rs_pt}))})});
            (std::move(this_));
        });
        auto [be2_pv, me2_p10] = crate::lower::node_::bind_plain(be_p3, me_p4, nkey_p5, rs_pt, t_p9);
        return std::tuple{wx3_ps, be2_pv, me2_p10};
    }
}

}  // namespace crate::lower::node_::static_
