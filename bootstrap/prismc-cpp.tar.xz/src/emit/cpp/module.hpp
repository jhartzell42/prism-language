// The module `Emit.Cpp`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (docs/backend.md). Edit the Prism source, not this file.
#pragma once

#include <emit/cpp/types.hpp>
#include "elem.types.hpp"
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/env/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/passes/types.hpp>
#include <check/shrink/types.hpp>
#include <check/typed/types.hpp>
#include <check/types/types.hpp>
#include <emit/types.hpp>
#include <emit/cpp/prelude/types.hpp>
#include <emit/cpp/templates/types.hpp>
#include <lower/types.hpp>
#include <lower/model/types.hpp>
#include <lower/node_/types.hpp>
#include <syntax/types.hpp>
#include <syntax/lexer/types.hpp>

namespace crate {

using namespace prelude;

namespace emit::cpp {

Text cpp_id(const Text& n);

Array<Text> cpp_keywords();

Text field_id(const Text& f);

Text cpp_path_id(const Text& p_);

bool in_list(const Array<Text>& xs, const Text& x);

Text absolute(const Cp& cp, const Text& p_);

std::optional<TyInfo> type_of(const Cp& cp, const Text& p_);

std::optional<Text> case_of(const Cp& cp, const Text& p_);

Text parent_path(const Text& p_);

Text last_segment(const Text& p_);

Cp context(const crate::lower::model::Model& model);

Map<Text, TyInfo> prelude_types();

Map<Text, Text> prelude_ctors();

Map<Text, bool> node_base();

Cp add_model_item(const Cp& cp, const Text& m, const crate::lower::model::Item& it);

Cp add_ty(const Cp& cp, const Text& path_, const TyInfo& info);

Cp add_ctor(const Cp& cp, const Text& path_, const Text& kind);

Cp add_member(const Cp& cp, const Text& name);

Cp add_type(const Cp& cp, const Text& m, const crate::lower::model::TyDef& t);

Cp add_row(const Cp& cp, const Text& m, const crate::lower::model::RowDef& r);

Cp add_answer(const Cp& cp, const crate::lower::model::AnswerDef& a);

Cp add_node(const Cp& cp, const Text& m, const crate::lower::model::NodeDef& n);

Cp in_home(const Cp& cp, const Text& m);

Cp with_fields(const Cp& cp, const Array<std::tuple<Text, crate::lower::model::OutTy>>& fs);

Text cpp_type(const Cp& cp, const crate::lower::model::OutTy& t);

prism_rtl::JobRef<Text> start_cpp_type(Cp cp, crate::lower::model::OutTy t);

Text cpp_types(const Cp& cp, const Array<crate::lower::model::OutTy>& ts);

prism_rtl::JobRef<Text> start_cpp_types(Cp cp, Array<crate::lower::model::OutTy> ts);

Text param_types(const Cp& cp, const Array<crate::lower::model::OutTy>& ts);

prism_rtl::JobRef<Text> start_param_types(Cp cp, Array<crate::lower::model::OutTy> ts);

Text own_type_path(const Cp& cp, const Text& n);

Text type_path(const Text& p_);

bool is_value_ty(const Cp& cp, const crate::lower::model::OutTy& t);

bool cpp_loose(const crate::lower::model::Ex& x);

Text cpp_tight(const Cp& cp, const crate::lower::model::Ex& x);

prism_rtl::JobRef<Text> start_cpp_tight(Cp cp, crate::lower::model::Ex x);

Text cpp_args(const Cp& cp, const Array<crate::lower::model::Ex>& xs);

prism_rtl::JobRef<Text> start_cpp_args(Cp cp, Array<crate::lower::model::Ex> xs);

Text cpp_expr(const Cp& cp, const crate::lower::model::Ex& x);

prism_rtl::JobRef<Text> start_cpp_expr(Cp cp, crate::lower::model::Ex x);

Text cpp_string(const Text& t);

Text cpp_escape(const Text& t);

bool is_text_piece(const crate::lower::model::Ex& ex0);

Text text_piece(const crate::lower::model::Ex& ex0);

Text cpp_format(const Cp& cp, const Array<crate::lower::model::Ex>& parts, const Text& how);

prism_rtl::JobRef<Text> start_cpp_format(Cp cp, Array<crate::lower::model::Ex> parts, Text how);

Text format_arg(const Cp& cp, const crate::lower::model::Ex& ex1);

prism_rtl::JobRef<Text> start_format_arg(Cp cp, crate::lower::model::Ex ex1);

Text cpp_char_escape(const Text& text0);

Text path_value(const Cp& cp, const Text& p_);

bool is_node_method(const Cp& cp, const Text& p_);

bool is_node_type(const Cp& cp, const Text& p_);

Text cpp_field(const Cp& cp, const crate::lower::model::Ex& ex1, const Text& f);

prism_rtl::JobRef<Text> start_cpp_field(Cp cp, crate::lower::model::Ex ex1, Text f);

bool is_digits(const Text& t);

Text cpp_ctor(const Cp& cp, const Text& p_, const Array<crate::lower::model::Ex>& args);

prism_rtl::JobRef<Text> start_cpp_ctor(Cp cp, Text p_, Array<crate::lower::model::Ex> args);

Text cpp_record(const Cp& cp, const Text& p_, const Array<std::tuple<Text, crate::lower::model::Ex>>& fs);

prism_rtl::JobRef<Text> start_cpp_record(Cp cp, Text p_, Array<std::tuple<Text, crate::lower::model::Ex>> fs);

Text cpp_call(const Cp& cp, const Text& f, const Array<crate::lower::model::Ex>& args);

prism_rtl::JobRef<Text> start_cpp_call(Cp cp, Text f, Array<crate::lower::model::Ex> args);

Text free_call_path(const Cp& cp, const Text& f);

Text qualified_call(const Cp& cp, const Text& f, const Text& p_);

Array<Text> std_names();

bool is_fresh(const Text& f);

Text call_path(const Text& f);

Text cpp_method(const Cp& cp, const crate::lower::model::Ex& r, const Text& m, const Array<crate::lower::model::Ex>& args);

prism_rtl::JobRef<Text> start_cpp_method(Cp cp, crate::lower::model::Ex r, Text m, Array<crate::lower::model::Ex> args);

Text node_method_name(const Cp& cp, const Text& m);

std::optional<bool> pointer(const Cp& cp, const crate::lower::model::Ex& r);

bool is_pointer_ty(const Cp& cp, const crate::lower::model::OutTy& t);

Text method_form(const Text& m, const Nat& n);

Text free_name(const Text& m);

Text member_name(const Text& m);

Text case_test(const Cp& cp, const Text& c, const Text& v_);

Text case_type(const Text& c);

Text payload(const Cp& cp, const Text& c, const Text& v_, const Nat& i);

bool is_runtime_case(const Text& c);

Text cpp_if(const Cp& cp, const crate::lower::model::Ex& c, const crate::lower::model::Ex& t, const crate::lower::model::Ex& e);

prism_rtl::JobRef<Text> start_cpp_if(Cp cp, crate::lower::model::Ex c, crate::lower::model::Ex t, crate::lower::model::Ex e);

bool is_ctor(const crate::lower::model::Ex& ex0, const Text& c);

std::optional<crate::lower::model::Ex> err_of(const crate::lower::model::Ex& x);

Text ok_branch(const Cp& cp, const crate::lower::model::Ex& x, const crate::lower::model::Ex& y);

prism_rtl::JobRef<Text> start_ok_branch(Cp cp, crate::lower::model::Ex x, crate::lower::model::Ex y);

Text cpp_closure(const Cp& cp0, const bool& mv, const Array<crate::lower::model::Pa>& ps, const crate::lower::model::Ex& body);

prism_rtl::JobRef<Text> start_cpp_closure(Cp cp0, bool mv, Array<crate::lower::model::Pa> ps, crate::lower::model::Ex body);

Text closure_param(const Cp& cp, const crate::lower::model::Pa& pa1, const Nat& i);

prism_rtl::JobRef<Text> start_closure_param(Cp cp, crate::lower::model::Pa pa1, Nat i);

Text closure_binds(const Cp& cp, const crate::lower::model::Pa& pa1, const Nat& i);

prism_rtl::JobRef<Text> start_closure_binds(Cp cp, crate::lower::model::Pa pa1, Nat i);

crate::lower::model::OutTy unref(const crate::lower::model::OutTy& out_ty0);

Text param_type(const Cp& cp, const crate::lower::model::OutTy& t);

prism_rtl::JobRef<Text> start_param_type(Cp cp, crate::lower::model::OutTy t);

Array<Text> pat_conds(const Cp& cp, const crate::lower::model::Pa& p_, const Text& v_);

prism_rtl::JobRef<Array<Text>> start_pat_conds(Cp cp, crate::lower::model::Pa p_, Text v_);

Array<Text> pat_binds(const Cp& cp, const crate::lower::model::Pa& p_, const Text& v_);

prism_rtl::JobRef<Array<Text>> start_pat_binds(Cp cp, crate::lower::model::Pa p_, Text v_);

Array<Text> slice_binds(const Cp& cp, const crate::lower::model::Pa& pa1, const Text& v_, const Nat& i);

prism_rtl::JobRef<Array<Text>> start_slice_binds(Cp cp, crate::lower::model::Pa pa1, Text v_, Nat i);

bool is_rest(const crate::lower::model::Pa& pa0);

Array<Text> concat2(const Array<Array<Text>>& xss);

Text conds(const Array<Text>& xs0);

bool is_catch_all(const crate::lower::model::Pa& p_);

bool leaves(const crate::lower::model::Ex& x);

Text cpp_match(const Cp& cp, const crate::lower::model::Ex& s, const Array<crate::lower::model::XArm>& arms, const crate::lower::model::OutTy& out_ty3);

prism_rtl::JobRef<Text> start_cpp_match(Cp cp, crate::lower::model::Ex s, Array<crate::lower::model::XArm> arms, crate::lower::model::OutTy out_ty3);

Text return_match(const Cp& cp, const crate::lower::model::Ex& s, const Array<crate::lower::model::XArm>& arms, const crate::lower::model::OutTy& out_ty3);

prism_rtl::JobRef<Text> start_return_match(Cp cp, crate::lower::model::Ex s, Array<crate::lower::model::XArm> arms, crate::lower::model::OutTy out_ty3);

Text match_tail(const Array<crate::lower::model::XArm>& arms);

Text ternary_match(const Cp& cp, const crate::lower::model::Ex& s, const Array<crate::lower::model::XArm>& arms);

prism_rtl::JobRef<Text> start_ternary_match(Cp cp, crate::lower::model::Ex s, Array<crate::lower::model::XArm> arms);

Text ternary_arm(const Cp& cp0, const Text& subject, const crate::lower::model::XArm& a);

prism_rtl::JobRef<Text> start_ternary_arm(Cp cp0, Text subject, crate::lower::model::XArm a);

Array<Text> cond_binds(const Cp& cp, const crate::lower::model::Cc& cc1, const Nat& k);

prism_rtl::JobRef<Array<Text>> start_cond_binds(Cp cp, crate::lower::model::Cc cc1, Nat k);

std::tuple<Text, Array<Text>> cond_subject(const Cp& cp, const crate::lower::model::Ex& x, const Nat& k);

prism_rtl::JobRef<std::tuple<Text, Array<Text>>> start_cond_subject(Cp cp, crate::lower::model::Ex x, Nat k);

bool is_place_ex(const crate::lower::model::Ex& x);

Text guard_test(const Cp& cp, const Array<crate::lower::model::Cc>& xs1);

prism_rtl::JobRef<Text> start_guard_test(Cp cp, Array<crate::lower::model::Cc> xs1);

Text match_arm(const Cp& cp0, const Text& subject, const crate::lower::model::XArm& a, const bool& returns);

prism_rtl::JobRef<Text> start_match_arm(Cp cp0, Text subject, crate::lower::model::XArm a, bool returns);

Text guarded_arm(const Cp& cp, const Array<crate::lower::model::Cc>& xs1, const Text& body);

prism_rtl::JobRef<Text> start_guarded_arm(Cp cp, Array<crate::lower::model::Cc> xs1, Text body);

Text cpp_labeled(const Cp& cp, const Text& label, const Array<crate::lower::model::Do>& dos, const crate::lower::model::Ex& e, const crate::lower::model::OutTy& t);

prism_rtl::JobRef<Text> start_cpp_labeled(Cp cp, Text label, Array<crate::lower::model::Do> dos, crate::lower::model::Ex e, crate::lower::model::OutTy t);

Text cpp_label(const Text& l);

Text cpp_break(const Cp& cp, const Text& l, const crate::lower::model::Ex& y);

prism_rtl::JobRef<Text> start_cpp_break(Cp cp, Text l, crate::lower::model::Ex y);

Text cpp_statements(const Cp& cp, const Array<crate::lower::model::Do>& dos);

prism_rtl::JobRef<Text> start_cpp_statements(Cp cp, Array<crate::lower::model::Do> dos);

std::tuple<Text, Cp> cpp_statements_cp(const Cp& cp, const Array<crate::lower::model::Do>& dos);

prism_rtl::JobRef<std::tuple<Text, Cp>> start_cpp_statements_cp(Cp cp, Array<crate::lower::model::Do> dos);

Text unvexed(const Text& t);

Cp rebound(const Cp& cp, const crate::lower::model::Do& d);

prism_rtl::JobRef<Cp> start_rebound(Cp cp, crate::lower::model::Do d);

Array<Text> pat_names(const crate::lower::model::Pa& p_);

prism_rtl::JobRef<Array<Text>> start_pat_names(crate::lower::model::Pa p_);

Array<Text> arm_names(const crate::lower::model::XArm& a);

prism_rtl::JobRef<Array<Text>> start_arm_names(crate::lower::model::XArm a);

Array<Text> cond_names(const crate::lower::model::Cc& cc0);

prism_rtl::JobRef<Array<Text>> start_cond_names(crate::lower::model::Cc cc0);

Cp unbind(const Cp& cp, const Array<Text>& names);

Cp pointing(const Cp& cp, const Text& n);

Cp known_value(const Cp& cp, const crate::lower::model::Pa& p_, const Text& n);

bool is_pointer_let(const Cp& cp, const crate::lower::model::Pa& p_, const crate::lower::model::Ex& x);

Nat inc(const Nat& n);

std::optional<Text> let_name(const crate::lower::model::Pa& p_);

Text var_name(const Cp& cp, const Text& n);

bool cpp_mentions(const Text& t, const Text& n);

bool cpp_ends_ident(const Text& t);

bool cpp_starts_ident(const Text& t);

bool cpp_ident_char(const Text& c);

Text cpp_statement(const Cp& cp, const crate::lower::model::Do& d);

prism_rtl::JobRef<Text> start_cpp_statement(Cp cp, crate::lower::model::Do d);

Text cpp_inline(const Cp& cp, const Array<crate::lower::model::Do>& dos);

prism_rtl::JobRef<Text> start_cpp_inline(Cp cp, Array<crate::lower::model::Do> dos);

Text cpp_else(const Cp& cp, const Array<crate::lower::model::Do>& xs1);

prism_rtl::JobRef<Text> start_cpp_else(Cp cp, Array<crate::lower::model::Do> xs1);

Text cpp_let(const Cp& cp, const Cp& named, const crate::lower::model::Pa& p_, const crate::lower::model::Ex& x);

prism_rtl::JobRef<Text> start_cpp_let(Cp cp, Cp named, crate::lower::model::Pa p_, crate::lower::model::Ex x);

Text let_through(const Cp& cp, const crate::lower::model::Pa& p_, const crate::lower::model::Ex& x);

prism_rtl::JobRef<Text> start_let_through(Cp cp, crate::lower::model::Pa p_, crate::lower::model::Ex x);

std::optional<Text> first_binder(const crate::lower::model::Pa& p_);

prism_rtl::JobRef<std::optional<Text>> start_first_binder(crate::lower::model::Pa p_);

bool is_name(const crate::lower::model::Pa& pa0);

Text pat_name(const crate::lower::model::Pa& pa0);

Text cpp_if_let(const Cp& cp0, const crate::lower::model::Pa& p_, const crate::lower::model::Ex& x, const Array<crate::lower::model::Do>& t, const Array<crate::lower::model::Do>& e);

prism_rtl::JobRef<Text> start_cpp_if_let(Cp cp0, crate::lower::model::Pa p_, crate::lower::model::Ex x, Array<crate::lower::model::Do> t, Array<crate::lower::model::Do> e);

Text cpp_do_match(const Cp& cp, const crate::lower::model::Ex& x, const Array<std::tuple<crate::lower::model::Pa, Array<crate::lower::model::Do>>>& cases);

prism_rtl::JobRef<Text> start_cpp_do_match(Cp cp, crate::lower::model::Ex x, Array<std::tuple<crate::lower::model::Pa, Array<crate::lower::model::Do>>> cases_);

Text cpp_for(const Cp& cp0, const crate::lower::model::Pa& p_, const crate::lower::model::Ex& x, const Array<crate::lower::model::Do>& body);

prism_rtl::JobRef<Text> start_cpp_for(Cp cp0, crate::lower::model::Pa p_, crate::lower::model::Ex x, Array<crate::lower::model::Do> body);

Text cpp_for_in(const Cp& cp, const crate::lower::model::Pa& p_, const Text& xs, const Array<crate::lower::model::Do>& body);

prism_rtl::JobRef<Text> start_cpp_for_in(Cp cp, crate::lower::model::Pa p_, Text xs, Array<crate::lower::model::Do> body);

Text cpp_body(const Cp& cp, const crate::lower::model::Ex& ex1);

prism_rtl::JobRef<Text> start_cpp_body(Cp cp, crate::lower::model::Ex ex1);

Text cpp_template_head(const Array<Text>& xs0);

Array<Text> generic_names_of(const Array<std::tuple<Text, Array<Text>>>& gs);

Text head_of(const Text& name, const Array<Text>& xs1);

Text cpp_params(const Cp& cp, const Array<std::tuple<Text, crate::lower::model::OutTy>>& ps);

prism_rtl::JobRef<Text> start_cpp_params(Cp cp, Array<std::tuple<Text, crate::lower::model::OutTy>> ps);

Text fn_signature(const Cp& cp, const crate::lower::model::FnDef& f);

prism_rtl::JobRef<Text> start_fn_signature(Cp cp, crate::lower::model::FnDef f);

Text fn_definition(const Cp& cp, const crate::lower::model::FnDef& f);

prism_rtl::JobRef<Text> start_fn_definition(Cp cp, crate::lower::model::FnDef f);

Array<Text> value_deps(const Cp& cp, const crate::lower::model::OutTy& t);

prism_rtl::JobRef<Array<Text>> start_value_deps(Cp cp, crate::lower::model::OutTy t);

Parts no_parts();

Parts join_parts(const Parts& a, const Parts& b);

Parts item_parts(const Cp& cp, const crate::lower::model::Item& it);

prism_rtl::JobRef<Parts> start_item_parts(Cp cp, crate::lower::model::Item it);

Parts fn_parts(const Cp& cp, const crate::lower::model::FnDef& f);

prism_rtl::JobRef<Parts> start_fn_parts(Cp cp, crate::lower::model::FnDef f);

Text cpp_doc(const Text& text);

Text cpp_source_doc(const Text& lead, const Text& source);

Parts type_parts(const Cp& cp, const crate::lower::model::TyDef& t);

prism_rtl::JobRef<Parts> start_type_parts(Cp cp, crate::lower::model::TyDef t);

Text cases_accessor(const Text& gens, const Text& head);

Text members(const bool& shown, const bool& pod, const Text& head);

Text case_struct(const Cp& cp, const Text& gens, const Text& head, const crate::lower::model::CaseDef& c, const bool& eq, const bool& ord);

prism_rtl::JobRef<Text> start_case_struct(Cp cp, Text gens, Text head, crate::lower::model::CaseDef c, bool eq, bool ord);

Text type_defs(const Cp& cp, const crate::lower::model::TyDef& t, const Text& head);

prism_rtl::JobRef<Text> start_type_defs(Cp cp, crate::lower::model::TyDef t, Text head);

Text show_def(const Cp& cp, const crate::lower::model::TyDef& t, const Text& head, const Text& gens);

prism_rtl::JobRef<Text> start_show_def(Cp cp, crate::lower::model::TyDef t, Text head, Text gens);

Text show_case(const crate::lower::model::TyDef& t, const Nat& i);

Text first_case(const crate::lower::model::TyDef& t);

Nat first_arity(const crate::lower::model::TyDef& t);

Array<crate::lower::model::OutTy> field_types(const Array<std::tuple<Text, crate::lower::model::OutTy>>& fs);

Text positional_fields(const Cp& cp, const Array<std::tuple<Text, crate::lower::model::OutTy>>& fs);

prism_rtl::JobRef<Text> start_positional_fields(Cp cp, Array<std::tuple<Text, crate::lower::model::OutTy>> fs);

Text to_pod_def(const Cp& cp, const crate::lower::model::TyDef& t, const Text& head, const Text& gens);

prism_rtl::JobRef<Text> start_to_pod_def(Cp cp, crate::lower::model::TyDef t, Text head, Text gens);

Text choice_pod(const crate::lower::model::TyDef& t);

Text from_pod_def(const Cp& cp, const crate::lower::model::TyDef& t, const Text& head, const Text& gens);

prism_rtl::JobRef<Text> start_from_pod_def(Cp cp, crate::lower::model::TyDef t, Text head, Text gens);

Text prism_field(const Text& f);

Text indent_cpp(const Text& t);

Parts tag_parts(const Cp& cp, const crate::lower::model::TagDef& t);

prism_rtl::JobRef<Parts> start_tag_parts(Cp cp, crate::lower::model::TagDef t);

Parts row_parts(const Cp& cp, const Text& m, const crate::lower::model::RowDef& r);

prism_rtl::JobRef<Parts> start_row_parts(Cp cp, Text m, crate::lower::model::RowDef r);

Text row_struct(const Text& m, const Text& st);

Parts answer_parts(const Cp& cp, const crate::lower::model::AnswerDef& a);

prism_rtl::JobRef<Parts> start_answer_parts(Cp cp, crate::lower::model::AnswerDef a);

Parts job_parts(const Cp& cp, const crate::lower::model::JobDef& j);

prism_rtl::JobRef<Parts> start_job_parts(Cp cp, crate::lower::model::JobDef j);

Parts trait_parts(const Cp& cp, const crate::lower::model::TraitDef& t);

prism_rtl::JobRef<Parts> start_trait_parts(Cp cp, crate::lower::model::TraitDef t);

Parts impl_parts(const Cp& cp, const crate::lower::model::ImplDef& i);

prism_rtl::JobRef<Parts> start_impl_parts(Cp cp, crate::lower::model::ImplDef i);

crate::lower::model::FnDef with_generics(const crate::lower::model::FnDef& f, const Array<std::tuple<Text, Array<Text>>>& gs);

Parts generic_only(const Array<Text>& xs);

Parts protos_defs(const Array<Text>& ps, const Array<Text>& ds);

Parts node_parts(const Cp& cp, const crate::lower::model::NodeDef& n);

prism_rtl::JobRef<Parts> start_node_parts(Cp cp, crate::lower::model::NodeDef n);

Text method_sig(const Cp& cp, const crate::lower::model::MethDef& m, const Text& owner);

prism_rtl::JobRef<Text> start_method_sig(Cp cp, crate::lower::model::MethDef m, Text owner);

Text method_def(const Cp& cp, const Text& owner, const crate::lower::model::MethDef& m);

prism_rtl::JobRef<Text> start_method_def(Cp cp, Text owner, crate::lower::model::MethDef m);

Text hook_sig(const Text& text0, const Text& owner);

Text answer_def_cpp(const Cp& cp, const crate::lower::model::NodeDef& n);

prism_rtl::JobRef<Text> start_answer_def_cpp(Cp cp, crate::lower::model::NodeDef n);

Text row_leaving(const Cp& cp, const crate::lower::model::NodeDef& n);

prism_rtl::JobRef<Text> start_row_leaving(Cp cp, crate::lower::model::NodeDef n);

Text for_build_cpp(const Cp& cp, const Text& owner, const crate::lower::model::ForDef& b);

prism_rtl::JobRef<Text> start_for_build_cpp(Cp cp, Text owner, crate::lower::model::ForDef b);

Text gen_build_cpp(const Cp& cp, const Text& owner, const crate::lower::model::GenDef& gd);

prism_rtl::JobRef<Text> start_gen_build_cpp(Cp cp, Text owner, crate::lower::model::GenDef gd);

Text program_cpp(const Cp& cp, const crate::lower::model::ProgDef& p_, const bool& fallible);

prism_rtl::JobRef<Text> start_program_cpp(Cp cp, crate::lower::model::ProgDef p_, bool fallible);

Text decode_arg(const Cp& cp, const Array<std::tuple<Text, crate::lower::model::OutTy>>& ps, const Nat& i);

prism_rtl::JobRef<Text> start_decode_arg(Cp cp, Array<std::tuple<Text, crate::lower::model::OutTy>> ps, Nat i);

Parts module_parts(const Cp& cp, const crate::lower::model::ModDef& m);

prism_rtl::JobRef<Parts> start_module_parts(Cp cp, crate::lower::model::ModDef m);

ValueDecl in_ns_value(const Text& ns, const ValueDecl& v_);

Array<Text> in_ns(const Text& ns, const Array<Text>& xs1);

bool node_fallible_cpp(const crate::lower::model::Model& model, const Text& path_);

Array<std::tuple<Text, Text>> emit_cpp(const crate::lower::model::Model& model, const Text& runtime, const Array<Text>& scripts);

prism_rtl::JobRef<Array<std::tuple<Text, Text>>> start_emit_cpp(crate::lower::model::Model model, Text runtime, Array<Text> scripts);

crate::lower::model::ModDef no_mod();

std::tuple<Text, Text> group_types_file(const Array<std::tuple<crate::lower::model::ModDef, Parts>>& pairs, const Array<Text>& group);

prism_rtl::JobRef<std::tuple<Text, Text>> start_group_types_file(Array<std::tuple<crate::lower::model::ModDef, Parts>> pairs, Array<Text> group);

Text group_name(const Array<Text>& group);

Text mod_dir(const Text& m);

bool among(const Array<Text>& xs, const Text& x);

Text types_header(const Text& title, const Array<Text>& members_, const Array<Text>& declared_, const Array<Text>& complete, const Parts& p_);

prism_rtl::JobRef<Text> start_types_header(Text title, Array<Text> members_, Array<Text> declared_, Array<Text> complete, Parts p_);

Text includes(const Text& layer, const Array<Text>& ms);

Array<Array<Text>> chunks(const Array<Text>& defs);

Nat chunk_size();

Array<std::tuple<Text, Text>> module_files(const crate::lower::model::ModDef& m, const Parts& p_, const Array<Text>& generics);

prism_rtl::JobRef<Array<std::tuple<Text, Text>>> start_module_files(crate::lower::model::ModDef m, Parts p_, Array<Text> generics);

Text chunk_file(const Text& m, const Nat& k);

Array<crate::lower::model::ProgDef> all_programs_cpp(const crate::lower::model::Model& model);

Array<Text> order_values(const Array<ValueDecl>& left, const Map<Text, bool>& done, const Array<Text>& acc);

prism_rtl::JobRef<Array<Text>> start_order_values(Array<ValueDecl> left, Map<Text, bool> done, Array<Text> acc);

bool declared(const Map<Text, bool>& done, const Text& d);

}  // namespace emit::cpp


namespace emit::cpp {

/// The step machine of `CppType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppType: unbounded fn Cp, OutTy -> Text
struct CppType : prism_rtl::Job<Text> {
    Cp cp;
    crate::lower::model::OutTy t;
    CppType(Cp cp, crate::lower::model::OutTy t) : cp(std::move(cp)), t(std::move(t)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CppTypes`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppTypes: unbounded fn Cp, [OutTy] -> Text
struct CppTypes : prism_rtl::Job<Text> {
    Cp cp;
    Array<crate::lower::model::OutTy> ts;
    CppTypes(Cp cp, Array<crate::lower::model::OutTy> ts) : cp(std::move(cp)), ts(std::move(ts)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `ParamTypes`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParamTypes: unbounded fn Cp, [OutTy] -> Text
struct ParamTypes : prism_rtl::Job<Text> {
    Cp cp;
    Array<crate::lower::model::OutTy> ts;
    ParamTypes(Cp cp, Array<crate::lower::model::OutTy> ts) : cp(std::move(cp)), ts(std::move(ts)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CppTight`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppTight: unbounded fn Cp, Ex -> Text
struct CppTight : prism_rtl::Job<Text> {
    Cp cp;
    crate::lower::model::Ex x;
    CppTight(Cp cp, crate::lower::model::Ex x) : cp(std::move(cp)), x(std::move(x)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CppArgs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppArgs: unbounded fn Cp, [Ex] -> Text
struct CppArgs : prism_rtl::Job<Text> {
    Cp cp;
    Array<crate::lower::model::Ex> xs;
    CppArgs(Cp cp, Array<crate::lower::model::Ex> xs) : cp(std::move(cp)), xs(std::move(xs)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CppExpr`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppExpr: unbounded fn Cp, Ex -> Text
struct CppExpr : prism_rtl::Job<Text> {
    Cp cp;
    crate::lower::model::Ex x;
    CppExpr(Cp cp, crate::lower::model::Ex x) : cp(std::move(cp)), x(std::move(x)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CppFormat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppFormat: unbounded fn Cp, [Ex], Text -> Text
struct CppFormat : prism_rtl::Job<Text> {
    Cp cp;
    Array<crate::lower::model::Ex> parts;
    Text how;
    CppFormat(Cp cp, Array<crate::lower::model::Ex> parts, Text how) : cp(std::move(cp)), parts(std::move(parts)), how(std::move(how)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `FormatArg`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FormatArg: unbounded fn Cp, Ex -> Text
struct FormatArg : prism_rtl::Job<Text> {
    Cp cp;
    crate::lower::model::Ex ex1;
    FormatArg(Cp cp, crate::lower::model::Ex ex1) : cp(std::move(cp)), ex1(std::move(ex1)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CppField`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppField: unbounded fn Cp, Ex, Text -> Text
struct CppField : prism_rtl::Job<Text> {
    Cp cp;
    crate::lower::model::Ex ex1;
    Text f;
    CppField(Cp cp, crate::lower::model::Ex ex1, Text f) : cp(std::move(cp)), ex1(std::move(ex1)), f(std::move(f)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CppCtor`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppCtor: unbounded fn Cp, Text, [Ex] -> Text
struct CppCtor : prism_rtl::Job<Text> {
    Cp cp;
    Text p_;
    Array<crate::lower::model::Ex> args;
    CppCtor(Cp cp, Text p_, Array<crate::lower::model::Ex> args) : cp(std::move(cp)), p_(std::move(p_)), args(std::move(args)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CppRecord`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppRecord: unbounded fn Cp, Text, [((Text, Ex))] -> Text
struct CppRecord : prism_rtl::Job<Text> {
    Cp cp;
    Text p_;
    Array<std::tuple<Text, crate::lower::model::Ex>> fs;
    CppRecord(Cp cp, Text p_, Array<std::tuple<Text, crate::lower::model::Ex>> fs) : cp(std::move(cp)), p_(std::move(p_)), fs(std::move(fs)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CppCall`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppCall: unbounded fn Cp, Text, [Ex] -> Text
struct CppCall : prism_rtl::Job<Text> {
    Cp cp;
    Text f;
    Array<crate::lower::model::Ex> args;
    CppCall(Cp cp, Text f, Array<crate::lower::model::Ex> args) : cp(std::move(cp)), f(std::move(f)), args(std::move(args)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CppMethod`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppMethod: unbounded fn Cp, Ex, Text, [Ex] -> Text
struct CppMethod : prism_rtl::Job<Text> {
    Cp cp;
    crate::lower::model::Ex r;
    Text m;
    Array<crate::lower::model::Ex> args;
    CppMethod(Cp cp, crate::lower::model::Ex r, Text m, Array<crate::lower::model::Ex> args) : cp(std::move(cp)), r(std::move(r)), m(std::move(m)), args(std::move(args)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CppIf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppIf: unbounded fn Cp, Ex, Ex, Ex -> Text
struct CppIf : prism_rtl::Job<Text> {
    Cp cp;
    crate::lower::model::Ex c;
    crate::lower::model::Ex t;
    crate::lower::model::Ex e;
    CppIf(Cp cp, crate::lower::model::Ex c, crate::lower::model::Ex t, crate::lower::model::Ex e) : cp(std::move(cp)), c(std::move(c)), t(std::move(t)), e(std::move(e)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `OkBranch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// OkBranch: unbounded fn Cp, Ex, Ex -> Text
struct OkBranch : prism_rtl::Job<Text> {
    Cp cp;
    crate::lower::model::Ex x;
    crate::lower::model::Ex y;
    OkBranch(Cp cp, crate::lower::model::Ex x, crate::lower::model::Ex y) : cp(std::move(cp)), x(std::move(x)), y(std::move(y)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CppClosure`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppClosure: unbounded fn Cp, Bool, [Pa], Ex -> Text
struct CppClosure : prism_rtl::Job<Text> {
    Cp cp0;
    bool mv;
    Array<crate::lower::model::Pa> ps;
    crate::lower::model::Ex body;
    CppClosure(Cp cp0, bool mv, Array<crate::lower::model::Pa> ps, crate::lower::model::Ex body) : cp0(std::move(cp0)), mv(std::move(mv)), ps(std::move(ps)), body(std::move(body)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `ClosureParam`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ClosureParam: unbounded fn Cp, Pa, Nat -> Text
struct ClosureParam : prism_rtl::Job<Text> {
    Cp cp;
    crate::lower::model::Pa pa1;
    Nat i;
    ClosureParam(Cp cp, crate::lower::model::Pa pa1, Nat i) : cp(std::move(cp)), pa1(std::move(pa1)), i(std::move(i)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `ClosureBinds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ClosureBinds: unbounded fn Cp, Pa, Nat -> Text
struct ClosureBinds : prism_rtl::Job<Text> {
    Cp cp;
    crate::lower::model::Pa pa1;
    Nat i;
    ClosureBinds(Cp cp, crate::lower::model::Pa pa1, Nat i) : cp(std::move(cp)), pa1(std::move(pa1)), i(std::move(i)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `ParamType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParamType: unbounded fn Cp, OutTy -> Text
struct ParamType : prism_rtl::Job<Text> {
    Cp cp;
    crate::lower::model::OutTy t;
    ParamType(Cp cp, crate::lower::model::OutTy t) : cp(std::move(cp)), t(std::move(t)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `PatConds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PatConds: unbounded fn Cp, Pa, Text -> [Text]
struct PatConds : prism_rtl::Job<Array<Text>> {
    Cp cp;
    crate::lower::model::Pa p_;
    Text v_;
    PatConds(Cp cp, crate::lower::model::Pa p_, Text v_) : cp(std::move(cp)), p_(std::move(p_)), v_(std::move(v_)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `PatBinds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PatBinds: unbounded fn Cp, Pa, Text -> [Text]
struct PatBinds : prism_rtl::Job<Array<Text>> {
    Cp cp;
    crate::lower::model::Pa p_;
    Text v_;
    PatBinds(Cp cp, crate::lower::model::Pa p_, Text v_) : cp(std::move(cp)), p_(std::move(p_)), v_(std::move(v_)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `SliceBinds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SliceBinds: unbounded fn Cp, Pa, Text, Nat -> [Text]
struct SliceBinds : prism_rtl::Job<Array<Text>> {
    Cp cp;
    crate::lower::model::Pa pa1;
    Text v_;
    Nat i;
    SliceBinds(Cp cp, crate::lower::model::Pa pa1, Text v_, Nat i) : cp(std::move(cp)), pa1(std::move(pa1)), v_(std::move(v_)), i(std::move(i)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `CppMatch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppMatch: unbounded fn Cp, Ex, [XArm], OutTy -> Text
struct CppMatch : prism_rtl::Job<Text> {
    Cp cp;
    crate::lower::model::Ex s;
    Array<crate::lower::model::XArm> arms;
    crate::lower::model::OutTy out_ty3;
    CppMatch(Cp cp, crate::lower::model::Ex s, Array<crate::lower::model::XArm> arms, crate::lower::model::OutTy out_ty3) : cp(std::move(cp)), s(std::move(s)), arms(std::move(arms)), out_ty3(std::move(out_ty3)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `ReturnMatch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ReturnMatch: unbounded fn Cp, Ex, [XArm], OutTy -> Text
struct ReturnMatch : prism_rtl::Job<Text> {
    Cp cp;
    crate::lower::model::Ex s;
    Array<crate::lower::model::XArm> arms;
    crate::lower::model::OutTy out_ty3;
    ReturnMatch(Cp cp, crate::lower::model::Ex s, Array<crate::lower::model::XArm> arms, crate::lower::model::OutTy out_ty3) : cp(std::move(cp)), s(std::move(s)), arms(std::move(arms)), out_ty3(std::move(out_ty3)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `TernaryMatch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TernaryMatch: unbounded fn Cp, Ex, [XArm] -> Text
struct TernaryMatch : prism_rtl::Job<Text> {
    Cp cp;
    crate::lower::model::Ex s;
    Array<crate::lower::model::XArm> arms;
    TernaryMatch(Cp cp, crate::lower::model::Ex s, Array<crate::lower::model::XArm> arms) : cp(std::move(cp)), s(std::move(s)), arms(std::move(arms)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `TernaryArm`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TernaryArm: unbounded fn Cp, Text, XArm -> Text
struct TernaryArm : prism_rtl::Job<Text> {
    Cp cp0;
    Text subject;
    crate::lower::model::XArm a;
    TernaryArm(Cp cp0, Text subject, crate::lower::model::XArm a) : cp0(std::move(cp0)), subject(std::move(subject)), a(std::move(a)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CondBinds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CondBinds: unbounded fn Cp, Cc, Nat -> [Text]
struct CondBinds : prism_rtl::Job<Array<Text>> {
    Cp cp;
    crate::lower::model::Cc cc1;
    Nat k;
    CondBinds(Cp cp, crate::lower::model::Cc cc1, Nat k) : cp(std::move(cp)), cc1(std::move(cc1)), k(std::move(k)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `CondSubject`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CondSubject: unbounded fn Cp, Ex, Nat -> ((Text, [Text]))
struct CondSubject : prism_rtl::Job<std::tuple<Text, Array<Text>>> {
    Cp cp;
    crate::lower::model::Ex x;
    Nat k;
    CondSubject(Cp cp, crate::lower::model::Ex x, Nat k) : cp(std::move(cp)), x(std::move(x)), k(std::move(k)) {}
    prism_rtl::Turn<std::tuple<Text, Array<Text>>> cycle() const override;
};


/// The step machine of `GuardTest`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// GuardTest: unbounded fn Cp, [Cc] -> Text
struct GuardTest : prism_rtl::Job<Text> {
    Cp cp;
    Array<crate::lower::model::Cc> xs1;
    GuardTest(Cp cp, Array<crate::lower::model::Cc> xs1) : cp(std::move(cp)), xs1(std::move(xs1)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `MatchArm`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// MatchArm: unbounded fn Cp, Text, XArm, Bool -> Text
struct MatchArm : prism_rtl::Job<Text> {
    Cp cp0;
    Text subject;
    crate::lower::model::XArm a;
    bool returns;
    MatchArm(Cp cp0, Text subject, crate::lower::model::XArm a, bool returns) : cp0(std::move(cp0)), subject(std::move(subject)), a(std::move(a)), returns(std::move(returns)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `GuardedArm`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// GuardedArm: unbounded fn Cp, [Cc], Text -> Text
struct GuardedArm : prism_rtl::Job<Text> {
    Cp cp;
    Array<crate::lower::model::Cc> xs1;
    Text body;
    GuardedArm(Cp cp, Array<crate::lower::model::Cc> xs1, Text body) : cp(std::move(cp)), xs1(std::move(xs1)), body(std::move(body)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CppLabeled`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppLabeled: unbounded fn Cp, Text, [Do], Ex, OutTy -> Text
struct CppLabeled : prism_rtl::Job<Text> {
    Cp cp;
    Text label;
    Array<crate::lower::model::Do> dos;
    crate::lower::model::Ex e;
    crate::lower::model::OutTy t;
    CppLabeled(Cp cp, Text label, Array<crate::lower::model::Do> dos, crate::lower::model::Ex e, crate::lower::model::OutTy t) : cp(std::move(cp)), label(std::move(label)), dos(std::move(dos)), e(std::move(e)), t(std::move(t)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CppBreak`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppBreak: unbounded fn Cp, Text, Ex -> Text
struct CppBreak : prism_rtl::Job<Text> {
    Cp cp;
    Text l;
    crate::lower::model::Ex y;
    CppBreak(Cp cp, Text l, crate::lower::model::Ex y) : cp(std::move(cp)), l(std::move(l)), y(std::move(y)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CppStatements`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppStatements: unbounded fn Cp, [Do] -> Text
struct CppStatements : prism_rtl::Job<Text> {
    Cp cp;
    Array<crate::lower::model::Do> dos;
    CppStatements(Cp cp, Array<crate::lower::model::Do> dos) : cp(std::move(cp)), dos(std::move(dos)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CppStatementsCp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppStatementsCp: unbounded fn Cp, [Do] -> ((Text, Cp))
struct CppStatementsCp : prism_rtl::Job<std::tuple<Text, Cp>> {
    Cp cp;
    Array<crate::lower::model::Do> dos;
    CppStatementsCp(Cp cp, Array<crate::lower::model::Do> dos) : cp(std::move(cp)), dos(std::move(dos)) {}
    prism_rtl::Turn<std::tuple<Text, Cp>> cycle() const override;
};


/// The step machine of `Rebound`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Rebound: unbounded fn Cp, Do -> Cp
struct Rebound : prism_rtl::Job<Cp> {
    Cp cp;
    crate::lower::model::Do d;
    Rebound(Cp cp, crate::lower::model::Do d) : cp(std::move(cp)), d(std::move(d)) {}
    prism_rtl::Turn<Cp> cycle() const override;
};


/// The step machine of `PatNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PatNames: unbounded fn Pa -> [Text]
struct PatNames : prism_rtl::Job<Array<Text>> {
    crate::lower::model::Pa p_;
    PatNames(crate::lower::model::Pa p_) : p_(std::move(p_)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `ArmNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ArmNames: unbounded fn XArm -> [Text]
struct ArmNames : prism_rtl::Job<Array<Text>> {
    crate::lower::model::XArm a;
    ArmNames(crate::lower::model::XArm a) : a(std::move(a)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `CondNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CondNames: unbounded fn Cc -> [Text]
struct CondNames : prism_rtl::Job<Array<Text>> {
    crate::lower::model::Cc cc0;
    CondNames(crate::lower::model::Cc cc0) : cc0(std::move(cc0)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `CppStatement`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppStatement: unbounded fn Cp, Do -> Text
struct CppStatement : prism_rtl::Job<Text> {
    Cp cp;
    crate::lower::model::Do d;
    CppStatement(Cp cp, crate::lower::model::Do d) : cp(std::move(cp)), d(std::move(d)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CppInline`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppInline: unbounded fn Cp, [Do] -> Text
struct CppInline : prism_rtl::Job<Text> {
    Cp cp;
    Array<crate::lower::model::Do> dos;
    CppInline(Cp cp, Array<crate::lower::model::Do> dos) : cp(std::move(cp)), dos(std::move(dos)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CppElse`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppElse: unbounded fn Cp, [Do] -> Text
struct CppElse : prism_rtl::Job<Text> {
    Cp cp;
    Array<crate::lower::model::Do> xs1;
    CppElse(Cp cp, Array<crate::lower::model::Do> xs1) : cp(std::move(cp)), xs1(std::move(xs1)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CppLet`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppLet: unbounded fn Cp, Cp, Pa, Ex -> Text
struct CppLet : prism_rtl::Job<Text> {
    Cp cp;
    Cp named;
    crate::lower::model::Pa p_;
    crate::lower::model::Ex x;
    CppLet(Cp cp, Cp named, crate::lower::model::Pa p_, crate::lower::model::Ex x) : cp(std::move(cp)), named(std::move(named)), p_(std::move(p_)), x(std::move(x)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `LetThrough`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LetThrough: unbounded fn Cp, Pa, Ex -> Text
struct LetThrough : prism_rtl::Job<Text> {
    Cp cp;
    crate::lower::model::Pa p_;
    crate::lower::model::Ex x;
    LetThrough(Cp cp, crate::lower::model::Pa p_, crate::lower::model::Ex x) : cp(std::move(cp)), p_(std::move(p_)), x(std::move(x)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `FirstBinder`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ?FirstBinder: unbounded fn Pa -> ?Text
struct FirstBinder : prism_rtl::Job<std::optional<Text>> {
    crate::lower::model::Pa p_;
    FirstBinder(crate::lower::model::Pa p_) : p_(std::move(p_)) {}
    prism_rtl::Turn<std::optional<Text>> cycle() const override;
};


/// The step machine of `CppIfLet`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppIfLet: unbounded fn Cp, Pa, Ex, [Do], [Do] -> Text
struct CppIfLet : prism_rtl::Job<Text> {
    Cp cp0;
    crate::lower::model::Pa p_;
    crate::lower::model::Ex x;
    Array<crate::lower::model::Do> t;
    Array<crate::lower::model::Do> e;
    CppIfLet(Cp cp0, crate::lower::model::Pa p_, crate::lower::model::Ex x, Array<crate::lower::model::Do> t, Array<crate::lower::model::Do> e) : cp0(std::move(cp0)), p_(std::move(p_)), x(std::move(x)), t(std::move(t)), e(std::move(e)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CppDoMatch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppDoMatch: unbounded fn Cp, Ex, [((Pa, [Do]))] -> Text
struct CppDoMatch : prism_rtl::Job<Text> {
    Cp cp;
    crate::lower::model::Ex x;
    Array<std::tuple<crate::lower::model::Pa, Array<crate::lower::model::Do>>> cases_;
    CppDoMatch(Cp cp, crate::lower::model::Ex x, Array<std::tuple<crate::lower::model::Pa, Array<crate::lower::model::Do>>> cases_) : cp(std::move(cp)), x(std::move(x)), cases_(std::move(cases_)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CppFor`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppFor: unbounded fn Cp, Pa, Ex, [Do] -> Text
struct CppFor : prism_rtl::Job<Text> {
    Cp cp0;
    crate::lower::model::Pa p_;
    crate::lower::model::Ex x;
    Array<crate::lower::model::Do> body;
    CppFor(Cp cp0, crate::lower::model::Pa p_, crate::lower::model::Ex x, Array<crate::lower::model::Do> body) : cp0(std::move(cp0)), p_(std::move(p_)), x(std::move(x)), body(std::move(body)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CppForIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppForIn: unbounded fn Cp, Pa, Text, [Do] -> Text
struct CppForIn : prism_rtl::Job<Text> {
    Cp cp;
    crate::lower::model::Pa p_;
    Text xs;
    Array<crate::lower::model::Do> body;
    CppForIn(Cp cp, crate::lower::model::Pa p_, Text xs, Array<crate::lower::model::Do> body) : cp(std::move(cp)), p_(std::move(p_)), xs(std::move(xs)), body(std::move(body)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CppBody`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppBody: unbounded fn Cp, Ex -> Text
struct CppBody : prism_rtl::Job<Text> {
    Cp cp;
    crate::lower::model::Ex ex1;
    CppBody(Cp cp, crate::lower::model::Ex ex1) : cp(std::move(cp)), ex1(std::move(ex1)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CppParams`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppParams: unbounded fn Cp, [((Text, OutTy))] -> Text
struct CppParams : prism_rtl::Job<Text> {
    Cp cp;
    Array<std::tuple<Text, crate::lower::model::OutTy>> ps;
    CppParams(Cp cp, Array<std::tuple<Text, crate::lower::model::OutTy>> ps) : cp(std::move(cp)), ps(std::move(ps)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `FnSignature`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FnSignature: unbounded fn Cp, FnDef -> Text
struct FnSignature : prism_rtl::Job<Text> {
    Cp cp;
    crate::lower::model::FnDef f;
    FnSignature(Cp cp, crate::lower::model::FnDef f) : cp(std::move(cp)), f(std::move(f)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `FnDefinition`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FnDefinition: unbounded fn Cp, FnDef -> Text
struct FnDefinition : prism_rtl::Job<Text> {
    Cp cp;
    crate::lower::model::FnDef f;
    FnDefinition(Cp cp, crate::lower::model::FnDef f) : cp(std::move(cp)), f(std::move(f)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `ValueDeps`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ValueDeps: unbounded fn Cp, OutTy -> [Text]
struct ValueDeps : prism_rtl::Job<Array<Text>> {
    Cp cp;
    crate::lower::model::OutTy t;
    ValueDeps(Cp cp, crate::lower::model::OutTy t) : cp(std::move(cp)), t(std::move(t)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `ItemParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ItemParts: unbounded fn Cp, Item -> Parts
struct ItemParts : prism_rtl::Job<Parts> {
    Cp cp;
    crate::lower::model::Item it;
    ItemParts(Cp cp, crate::lower::model::Item it) : cp(std::move(cp)), it(std::move(it)) {}
    prism_rtl::Turn<Parts> cycle() const override;
};


/// The step machine of `FnParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FnParts: unbounded fn Cp, FnDef -> Parts
struct FnParts : prism_rtl::Job<Parts> {
    Cp cp;
    crate::lower::model::FnDef f;
    FnParts(Cp cp, crate::lower::model::FnDef f) : cp(std::move(cp)), f(std::move(f)) {}
    prism_rtl::Turn<Parts> cycle() const override;
};


/// The step machine of `TypeParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TypeParts: unbounded fn Cp, TyDef -> Parts
struct TypeParts : prism_rtl::Job<Parts> {
    Cp cp;
    crate::lower::model::TyDef t;
    TypeParts(Cp cp, crate::lower::model::TyDef t) : cp(std::move(cp)), t(std::move(t)) {}
    prism_rtl::Turn<Parts> cycle() const override;
};


/// The step machine of `CaseStruct`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CaseStruct: unbounded fn Cp, Text, Text, CaseDef, Bool, Bool -> Text
struct CaseStruct : prism_rtl::Job<Text> {
    Cp cp;
    Text gens;
    Text head;
    crate::lower::model::CaseDef c;
    bool eq;
    bool ord;
    CaseStruct(Cp cp, Text gens, Text head, crate::lower::model::CaseDef c, bool eq, bool ord) : cp(std::move(cp)), gens(std::move(gens)), head(std::move(head)), c(std::move(c)), eq(std::move(eq)), ord(std::move(ord)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `TypeDefs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TypeDefs: unbounded fn Cp, TyDef, Text -> Text
struct TypeDefs : prism_rtl::Job<Text> {
    Cp cp;
    crate::lower::model::TyDef t;
    Text head;
    TypeDefs(Cp cp, crate::lower::model::TyDef t, Text head) : cp(std::move(cp)), t(std::move(t)), head(std::move(head)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `ShowDef`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ShowDef: unbounded fn Cp, TyDef, Text, Text -> Text
struct ShowDef : prism_rtl::Job<Text> {
    Cp cp;
    crate::lower::model::TyDef t;
    Text head;
    Text gens;
    ShowDef(Cp cp, crate::lower::model::TyDef t, Text head, Text gens) : cp(std::move(cp)), t(std::move(t)), head(std::move(head)), gens(std::move(gens)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `PositionalFields`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PositionalFields: unbounded fn Cp, [((Text, OutTy))] -> Text
struct PositionalFields : prism_rtl::Job<Text> {
    Cp cp;
    Array<std::tuple<Text, crate::lower::model::OutTy>> fs;
    PositionalFields(Cp cp, Array<std::tuple<Text, crate::lower::model::OutTy>> fs) : cp(std::move(cp)), fs(std::move(fs)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `ToPodDef`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ToPodDef: unbounded fn Cp, TyDef, Text, Text -> Text
struct ToPodDef : prism_rtl::Job<Text> {
    Cp cp;
    crate::lower::model::TyDef t;
    Text head;
    Text gens;
    ToPodDef(Cp cp, crate::lower::model::TyDef t, Text head, Text gens) : cp(std::move(cp)), t(std::move(t)), head(std::move(head)), gens(std::move(gens)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `FromPodDef`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FromPodDef: unbounded fn Cp, TyDef, Text, Text -> Text
struct FromPodDef : prism_rtl::Job<Text> {
    Cp cp;
    crate::lower::model::TyDef t;
    Text head;
    Text gens;
    FromPodDef(Cp cp, crate::lower::model::TyDef t, Text head, Text gens) : cp(std::move(cp)), t(std::move(t)), head(std::move(head)), gens(std::move(gens)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `TagParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TagParts: unbounded fn Cp, TagDef -> Parts
struct TagParts : prism_rtl::Job<Parts> {
    Cp cp;
    crate::lower::model::TagDef t;
    TagParts(Cp cp, crate::lower::model::TagDef t) : cp(std::move(cp)), t(std::move(t)) {}
    prism_rtl::Turn<Parts> cycle() const override;
};


/// The step machine of `RowParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RowParts: unbounded fn Cp, Text, RowDef -> Parts
struct RowParts : prism_rtl::Job<Parts> {
    Cp cp;
    Text m;
    crate::lower::model::RowDef r;
    RowParts(Cp cp, Text m, crate::lower::model::RowDef r) : cp(std::move(cp)), m(std::move(m)), r(std::move(r)) {}
    prism_rtl::Turn<Parts> cycle() const override;
};


/// The step machine of `AnswerParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// AnswerParts: unbounded fn Cp, AnswerDef -> Parts
struct AnswerParts : prism_rtl::Job<Parts> {
    Cp cp;
    crate::lower::model::AnswerDef a;
    AnswerParts(Cp cp, crate::lower::model::AnswerDef a) : cp(std::move(cp)), a(std::move(a)) {}
    prism_rtl::Turn<Parts> cycle() const override;
};


/// The step machine of `JobParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// JobParts: unbounded fn Cp, JobDef -> Parts
struct JobParts : prism_rtl::Job<Parts> {
    Cp cp;
    crate::lower::model::JobDef j;
    JobParts(Cp cp, crate::lower::model::JobDef j) : cp(std::move(cp)), j(std::move(j)) {}
    prism_rtl::Turn<Parts> cycle() const override;
};


/// The step machine of `TraitParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TraitParts: unbounded fn Cp, TraitDef -> Parts
struct TraitParts : prism_rtl::Job<Parts> {
    Cp cp;
    crate::lower::model::TraitDef t;
    TraitParts(Cp cp, crate::lower::model::TraitDef t) : cp(std::move(cp)), t(std::move(t)) {}
    prism_rtl::Turn<Parts> cycle() const override;
};


/// The step machine of `ImplParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ImplParts: unbounded fn Cp, ImplDef -> Parts
struct ImplParts : prism_rtl::Job<Parts> {
    Cp cp;
    crate::lower::model::ImplDef i;
    ImplParts(Cp cp, crate::lower::model::ImplDef i) : cp(std::move(cp)), i(std::move(i)) {}
    prism_rtl::Turn<Parts> cycle() const override;
};


/// The step machine of `NodeParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// NodeParts: unbounded fn Cp, NodeDef -> Parts
struct NodeParts : prism_rtl::Job<Parts> {
    Cp cp;
    crate::lower::model::NodeDef n;
    NodeParts(Cp cp, crate::lower::model::NodeDef n) : cp(std::move(cp)), n(std::move(n)) {}
    prism_rtl::Turn<Parts> cycle() const override;
};


/// The step machine of `MethodSig`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// MethodSig: unbounded fn Cp, MethDef, Text -> Text
struct MethodSig : prism_rtl::Job<Text> {
    Cp cp;
    crate::lower::model::MethDef m;
    Text owner;
    MethodSig(Cp cp, crate::lower::model::MethDef m, Text owner) : cp(std::move(cp)), m(std::move(m)), owner(std::move(owner)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `MethodDef`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// MethodDef: unbounded fn Cp, Text, MethDef -> Text
struct MethodDef : prism_rtl::Job<Text> {
    Cp cp;
    Text owner;
    crate::lower::model::MethDef m;
    MethodDef(Cp cp, Text owner, crate::lower::model::MethDef m) : cp(std::move(cp)), owner(std::move(owner)), m(std::move(m)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `AnswerDefCpp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// AnswerDefCpp: unbounded fn Cp, NodeDef -> Text
struct AnswerDefCpp : prism_rtl::Job<Text> {
    Cp cp;
    crate::lower::model::NodeDef n;
    AnswerDefCpp(Cp cp, crate::lower::model::NodeDef n) : cp(std::move(cp)), n(std::move(n)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `RowLeaving`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RowLeaving: unbounded fn Cp, NodeDef -> Text
struct RowLeaving : prism_rtl::Job<Text> {
    Cp cp;
    crate::lower::model::NodeDef n;
    RowLeaving(Cp cp, crate::lower::model::NodeDef n) : cp(std::move(cp)), n(std::move(n)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `ForBuildCpp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ForBuildCpp: unbounded fn Cp, Text, ForDef -> Text
struct ForBuildCpp : prism_rtl::Job<Text> {
    Cp cp;
    Text owner;
    crate::lower::model::ForDef b;
    ForBuildCpp(Cp cp, Text owner, crate::lower::model::ForDef b) : cp(std::move(cp)), owner(std::move(owner)), b(std::move(b)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `GenBuildCpp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// GenBuildCpp: unbounded fn Cp, Text, GenDef -> Text
struct GenBuildCpp : prism_rtl::Job<Text> {
    Cp cp;
    Text owner;
    crate::lower::model::GenDef gd;
    GenBuildCpp(Cp cp, Text owner, crate::lower::model::GenDef gd) : cp(std::move(cp)), owner(std::move(owner)), gd(std::move(gd)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `ProgramCpp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ProgramCpp: unbounded fn Cp, ProgDef, Bool -> Text
struct ProgramCpp : prism_rtl::Job<Text> {
    Cp cp;
    crate::lower::model::ProgDef p_;
    bool fallible;
    ProgramCpp(Cp cp, crate::lower::model::ProgDef p_, bool fallible) : cp(std::move(cp)), p_(std::move(p_)), fallible(std::move(fallible)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `DecodeArg`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// DecodeArg: unbounded fn Cp, [((Text, OutTy))], Nat -> Text
struct DecodeArg : prism_rtl::Job<Text> {
    Cp cp;
    Array<std::tuple<Text, crate::lower::model::OutTy>> ps;
    Nat i;
    DecodeArg(Cp cp, Array<std::tuple<Text, crate::lower::model::OutTy>> ps, Nat i) : cp(std::move(cp)), ps(std::move(ps)), i(std::move(i)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `ModuleParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ModuleParts: unbounded fn Cp, ModDef -> Parts
struct ModuleParts : prism_rtl::Job<Parts> {
    Cp cp;
    crate::lower::model::ModDef m;
    ModuleParts(Cp cp, crate::lower::model::ModDef m) : cp(std::move(cp)), m(std::move(m)) {}
    prism_rtl::Turn<Parts> cycle() const override;
};


/// The step machine of `EmitCpp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// EmitCpp: unbounded fn Model, Text, [Text] -> [((Text, Text))]
struct EmitCpp : prism_rtl::Job<Array<std::tuple<Text, Text>>> {
    crate::lower::model::Model model;
    Text runtime;
    Array<Text> scripts;
    EmitCpp(crate::lower::model::Model model, Text runtime, Array<Text> scripts) : model(std::move(model)), runtime(std::move(runtime)), scripts(std::move(scripts)) {}
    prism_rtl::Turn<Array<std::tuple<Text, Text>>> cycle() const override;
};


/// The step machine of `GroupTypesFile`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// GroupTypesFile: unbounded fn [((ModDef, Parts))], [Text] -> ((Text, Text))
struct GroupTypesFile : prism_rtl::Job<std::tuple<Text, Text>> {
    Array<std::tuple<crate::lower::model::ModDef, Parts>> pairs;
    Array<Text> group;
    GroupTypesFile(Array<std::tuple<crate::lower::model::ModDef, Parts>> pairs, Array<Text> group) : pairs(std::move(pairs)), group(std::move(group)) {}
    prism_rtl::Turn<std::tuple<Text, Text>> cycle() const override;
};


/// The step machine of `TypesHeader`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TypesHeader: unbounded fn Text, [Text], [Text], [Text], Parts -> Text
struct TypesHeader : prism_rtl::Job<Text> {
    Text title;
    Array<Text> members_;
    Array<Text> declared_;
    Array<Text> complete;
    Parts p_;
    TypesHeader(Text title, Array<Text> members_, Array<Text> declared_, Array<Text> complete, Parts p_) : title(std::move(title)), members_(std::move(members_)), declared_(std::move(declared_)), complete(std::move(complete)), p_(std::move(p_)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `ModuleFiles`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ModuleFiles: unbounded fn ModDef, Parts, [Text] -> [((Text, Text))]
struct ModuleFiles : prism_rtl::Job<Array<std::tuple<Text, Text>>> {
    crate::lower::model::ModDef m;
    Parts p_;
    Array<Text> generics;
    ModuleFiles(crate::lower::model::ModDef m, Parts p_, Array<Text> generics) : m(std::move(m)), p_(std::move(p_)), generics(std::move(generics)) {}
    prism_rtl::Turn<Array<std::tuple<Text, Text>>> cycle() const override;
};


/// The step machine of `OrderValues`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// OrderValues: unbounded fn [ValueDecl], (Text ==> Bool), [Text] -> [Text]
struct OrderValues : prism_rtl::Job<Array<Text>> {
    Array<ValueDecl> left;
    Map<Text, bool> done;
    Array<Text> acc;
    OrderValues(Array<ValueDecl> left, Map<Text, bool> done, Array<Text> acc) : left(std::move(left)), done(std::move(done)), acc(std::move(acc)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


}  // namespace emit::cpp

}  // namespace crate
