// The module `Emit.Cpp`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <emit/cpp/types.hpp>
#include "elem.types.hpp"
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/regex/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <emit/cpp/expr/types.hpp>
#include <emit/cpp/items/types.hpp>
#include <emit/cpp/patterns/types.hpp>
#include <emit/cpp/prelude/types.hpp>
#include <emit/cpp/program/types.hpp>
#include <emit/cpp/stmts/types.hpp>
#include <emit/cpp/templates/types.hpp>
#include <emit/cpp/templates/items/types.hpp>
#include <lower/types.hpp>
#include <lower/expr/types.hpp>
#include <lower/functions/types.hpp>
#include <lower/jobs/types.hpp>
#include <lower/model/types.hpp>
#include <lower/node_/types.hpp>
#include <lower/node_/def/types.hpp>
#include <lower/node_/dynamics/types.hpp>
#include <lower/node_/elements/types.hpp>
#include <lower/node_/finish/types.hpp>
#include <lower/node_/keyed/types.hpp>
#include <lower/node_/static_/types.hpp>
#include <lower/node_/switch_/types.hpp>
#include <lower/patterns/types.hpp>
#include <lower/program/types.hpp>
#include <lower/templates/types.hpp>
#include <lower/types/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>

namespace crate {

using namespace prelude;

namespace emit::cpp {

Text cpp_id_f(const Text& n_p0);

Text field_id_f(const Text& f_p0);

Text cpp_path_id_f(const Text& p_p0);

bool in_list_f(const Array<Text>& xs_p0, const Text& x_p1);

Text absolute_f(const Cp& cp_p0, const Text& p_p1);

std::optional<TyInfo> type_of_o(const Cp& cp_p0, const Text& p_p1);

std::optional<Text> case_of_o(const Cp& cp_p0, const Text& p_p1);

Text parent_path_f(const Text& p_p0);

Text last_segment_f(const Text& p_p0);

Cp context_f(const crate::lower::model::Model& model_p0);

Map<Text, TyInfo> prelude_types_p();

Map<Text, Text> prelude_ctors_p();

Map<Text, bool> node_base_p();

Cp add_model_item_f(const Cp& cp_p0, const Text& m_p1, const crate::lower::model::Item& it_p2);

Cp add_ty_f(const Cp& cp_p0, const Text& path_p1, const TyInfo& info_p2);

Cp add_ctor_f(const Cp& cp_p0, const Text& path_p1, const Text& kind_p2);

Cp add_member_f(const Cp& cp_p0, const Text& name_p1);

Cp add_type_f(const Cp& cp_p0, const Text& m_p1, const crate::lower::model::TyDef& t_p2);

Cp add_row_f(const Cp& cp_p0, const Text& m_p1, const crate::lower::model::RowDef& r_p2);

Cp add_answer_f(const Cp& cp_p0, const crate::lower::model::AnswerDef& a_p1);

Cp add_node_f(const Cp& cp_p0, const Text& m_p1, const crate::lower::model::NodeDef& n_p2);

Cp in_home_f(const Cp& cp_p0, const Text& m_p1);

Cp with_fields_f(const Cp& cp_p0, const Array<std::tuple<Text, crate::lower::model::OutTy>>& fs_p1);

Text cpp_type_f(const Cp& cp_p0, const crate::lower::model::OutTy& t_p1);

prism_rtl::JobRef<Text> start_cpp_type_f(Cp cp_p0, crate::lower::model::OutTy t_p1);

Text cpp_types_f(const Cp& cp_p0, const Array<crate::lower::model::OutTy>& ts_p1);

prism_rtl::JobRef<Text> start_cpp_types_f(Cp cp_p0, Array<crate::lower::model::OutTy> ts_p1);

Text param_types_f(const Cp& cp_p0, const Array<crate::lower::model::OutTy>& ts_p1);

prism_rtl::JobRef<Text> start_param_types_f(Cp cp_p0, Array<crate::lower::model::OutTy> ts_p1);

Text own_type_path_f(const Cp& cp_p0, const Text& n_p1);

Text type_path_f(const Text& p_p0);

bool is_value_ty_f(const Cp& cp_p0, const crate::lower::model::OutTy& t_p1);

}  // namespace emit::cpp


namespace emit::cpp {

/// The step machine of `CppType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppType: unbounded fn Cp, OutTy -> Text
struct CppType : prism_rtl::Job<Text> {
    Cp cp_p0;
    crate::lower::model::OutTy t_p1;
    CppType(Cp cp_p0, crate::lower::model::OutTy t_p1) : cp_p0(std::move(cp_p0)), t_p1(std::move(t_p1)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CppTypes`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppTypes: unbounded fn Cp, [OutTy] -> Text
struct CppTypes : prism_rtl::Job<Text> {
    Cp cp_p0;
    Array<crate::lower::model::OutTy> ts_p1;
    CppTypes(Cp cp_p0, Array<crate::lower::model::OutTy> ts_p1) : cp_p0(std::move(cp_p0)), ts_p1(std::move(ts_p1)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `ParamTypes`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParamTypes: unbounded fn Cp, [OutTy] -> Text
struct ParamTypes : prism_rtl::Job<Text> {
    Cp cp_p0;
    Array<crate::lower::model::OutTy> ts_p1;
    ParamTypes(Cp cp_p0, Array<crate::lower::model::OutTy> ts_p1) : cp_p0(std::move(cp_p0)), ts_p1(std::move(ts_p1)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


}  // namespace emit::cpp

}  // namespace crate
