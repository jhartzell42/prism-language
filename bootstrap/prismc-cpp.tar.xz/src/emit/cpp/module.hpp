// The module `Emit.Cpp`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <emit/cpp/types.hpp>
#include "elem.types.hpp"
#include <program/types.hpp>
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/regex/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <checking/types.hpp>
#include <compile/types.hpp>
#include <emit/types.hpp>
#include <emit/cpp/expr/types.hpp>
#include <emit/cpp/items/types.hpp>
#include <emit/cpp/patterns/types.hpp>
#include <emit/cpp/prelude/types.hpp>
#include <emit/cpp/program/types.hpp>
#include <emit/cpp/stmts/types.hpp>
#include <emit/cpp/templates/types.hpp>
#include <emit/cpp/templates/items/types.hpp>
#include <emit/rust/types.hpp>
#include <emit/rust/items/types.hpp>
#include <emit/rust/prelude/types.hpp>
#include <emit/rust/templates/types.hpp>
#include <emit/rust/templates/items/types.hpp>
#include <fs/types.hpp>
#include <lower/types.hpp>
#include <lower/expr/types.hpp>
#include <lower/functions/types.hpp>
#include <lower/jobs/types.hpp>
#include <lower/model/types.hpp>
#include <lower/node_/types.hpp>
#include <lower/node_/def/types.hpp>
#include <lower/node_/dynamics/types.hpp>
#include <lower/node_/elements/types.hpp>
#include <lower/node_/finish/types.hpp>
#include <lower/node_/keyed/types.hpp>
#include <lower/node_/static_/types.hpp>
#include <lower/node_/switch_/types.hpp>
#include <lower/patterns/types.hpp>
#include <lower/program/types.hpp>
#include <lower/templates/types.hpp>
#include <lower/types/types.hpp>
#include <process/types.hpp>
#include <reading/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>
#include <syntax/parser/types.hpp>
#include <syntax/parser/blocks/types.hpp>
#include <syntax/parser/decls/types.hpp>
#include <syntax/parser/expr/types.hpp>
#include <syntax/parser/test_language/types.hpp>
#include <syntax/parser/types/types.hpp>
#include <syntax/sexp/types.hpp>

namespace crate {

using namespace prelude;

namespace emit::cpp {

Text cpp_id(const Text& n);

Text field_id(const Text& f);

Text cpp_path_id(const Text& p_);

bool in_list(const Array<Text>& xs, const Text& x);

Text absolute(const Cp& cp, const Text& p_);

std::optional<TyInfo> type_of(const Cp& cp, const Text& p_);

std::optional<Text> case_of(const Cp& cp, const Text& p_);

Text parent_path(const Text& p_);

Text last_segment(const Text& p_);

Cp context(const crate::lower::model::Model& model);

Map<Text, TyInfo> prelude_types();

Map<Text, Text> prelude_ctors();

Map<Text, bool> node_base();

Cp add_model_item(const Cp& cp, const Text& m, const crate::lower::model::Item& it);

Cp add_ty(const Cp& cp, const Text& path_, const TyInfo& info);

Cp add_ctor(const Cp& cp, const Text& path_, const Text& kind);

Cp add_member(const Cp& cp, const Text& name);

Cp add_type(const Cp& cp, const Text& m, const crate::lower::model::TyDef& t);

Cp add_row(const Cp& cp, const Text& m, const crate::lower::model::RowDef& r);

Cp add_answer(const Cp& cp, const crate::lower::model::AnswerDef& a);

Cp add_node(const Cp& cp, const Text& m, const crate::lower::model::NodeDef& n);

Cp in_home(const Cp& cp, const Text& m);

Cp with_fields(const Cp& cp, const Array<std::tuple<Text, crate::lower::model::OutTy>>& fs);

Text cpp_type(const Cp& cp, const crate::lower::model::OutTy& t);

prism_rtl::JobRef<Text> start_cpp_type(Cp cp, crate::lower::model::OutTy t);

Text cpp_types(const Cp& cp, const Array<crate::lower::model::OutTy>& ts);

prism_rtl::JobRef<Text> start_cpp_types(Cp cp, Array<crate::lower::model::OutTy> ts);

Text param_types(const Cp& cp, const Array<crate::lower::model::OutTy>& ts);

prism_rtl::JobRef<Text> start_param_types(Cp cp, Array<crate::lower::model::OutTy> ts);

Text own_type_path(const Cp& cp, const Text& n);

Text type_path(const Text& p_);

bool is_value_ty(const Cp& cp, const crate::lower::model::OutTy& t);

}  // namespace emit::cpp


namespace emit::cpp {

/// The step machine of `CppType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppType: unbounded fn Cp, OutTy -> Text
struct CppType : prism_rtl::Job<Text> {
    Cp cp;
    crate::lower::model::OutTy t;
    CppType(Cp cp, crate::lower::model::OutTy t) : cp(std::move(cp)), t(std::move(t)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CppTypes`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppTypes: unbounded fn Cp, [OutTy] -> Text
struct CppTypes : prism_rtl::Job<Text> {
    Cp cp;
    Array<crate::lower::model::OutTy> ts;
    CppTypes(Cp cp, Array<crate::lower::model::OutTy> ts) : cp(std::move(cp)), ts(std::move(ts)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `ParamTypes`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParamTypes: unbounded fn Cp, [OutTy] -> Text
struct ParamTypes : prism_rtl::Job<Text> {
    Cp cp;
    Array<crate::lower::model::OutTy> ts;
    ParamTypes(Cp cp, Array<crate::lower::model::OutTy> ts) : cp(std::move(cp)), ts(std::move(ts)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


}  // namespace emit::cpp

}  // namespace crate
