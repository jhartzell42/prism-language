// The module `Emit.Cpp.Items`, from `target/bootstrap/cpp-src/prismc/emit/cpp/items.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (claude/backend.md). Edit the Prism source, not this file.
#include <emit/cpp/items/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

namespace crate::emit::cpp::items {

void Parts::show(Printer& p) const {
    p.record("Parts", {{"forward", forward}, {"handles", handles}, {"values", values}, {"cases", cases_}, {"protos", protos}, {"classes", classes}, {"outer", outer}, {"generic", generic}, {"defs", defs}});
}

Pod Parts::to_pod() const {
    return Pod::record("Parts", {{"forward", prism_rtl::to_pod(forward)}, {"handles", prism_rtl::to_pod(handles)}, {"values", prism_rtl::to_pod(values)}, {"cases", prism_rtl::to_pod(cases_)}, {"protos", prism_rtl::to_pod(protos)}, {"classes", prism_rtl::to_pod(classes)}, {"outer", prism_rtl::to_pod(outer)}, {"generic", prism_rtl::to_pod(generic)}, {"defs", prism_rtl::to_pod(defs)}});
}

Result<Parts> Parts::from_pod(const Pod& whole) {
    return Parts{.forward = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "forward")))), .handles = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "handles")))), .values = TRY(prism_rtl::from_pod<Array<ValueDecl>>(TRY(crate::prelude::field(whole, "values")))), .cases_ = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "cases")))), .protos = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "protos")))), .classes = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "classes")))), .outer = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "outer")))), .generic = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "generic")))), .defs = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "defs"))))};
}


void ValueDecl::show(Printer& p) const {
    p.record("ValueDecl", {{"path", path_}, {"deps", deps}, {"text", text}});
}

Pod ValueDecl::to_pod() const {
    return Pod::record("ValueDecl", {{"path", prism_rtl::to_pod(path_)}, {"deps", prism_rtl::to_pod(deps)}, {"text", prism_rtl::to_pod(text)}});
}

Result<ValueDecl> ValueDecl::from_pod(const Pod& whole) {
    return ValueDecl{.path_ = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "path")))), .deps = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "deps")))), .text = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "text"))))};
}


/// CppTemplateHead: fn [Text] -> Text
Text cpp_template_head(const Array<Text>& xs0) {
    {
        auto&& c0_0 = xs0;
        if (c0_0.size() == 0u) {
            return Text::lit("");
        }
    }
    {
        auto&& ps = xs0;
        return prism_rtl::cat("template <", crate::syntax::lexer::chars::join(each(ps, [&](const Text& p_) { return prism_rtl::cat("class ", p_); }), Text::lit(", ")), ">\n");
    }
}


/// GenericNamesOf: fn [((Text, [Text]))] -> [Text]
Array<Text> generic_names_of(const Array<std::tuple<Text, Array<Text>>>& gs) {
    return each(gs, [&](const std::tuple<Text, Array<Text>>& _p0) {
        auto&& g = std::get<0>(_p0);
        return g;
    });
}


/// HeadOf: fn Text, [Text] -> Text
Text head_of(const Text& name, const Array<Text>& xs1) {
    {
        auto&& c0_1 = xs1;
        if (c0_1.size() == 0u) {
            return name;
        }
    }
    {
        auto&& ps = xs1;
        return prism_rtl::cat(name, "<", crate::syntax::lexer::chars::join(ps, Text::lit(", ")), ">");
    }
}


/// CppParams: unbounded fn Cp, [((Text, OutTy))] -> Text
Text cpp_params(const crate::emit::cpp::Cp& cp, const Array<std::tuple<Text, crate::lower::model::OutTy>>& ps) {
    return crate::syntax::lexer::chars::join(run_to_end(each_job(ps, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=]() {
            return ({
                auto [n, t] = p0;
                call_then(crate::emit::cpp::expr::start_param_type(cp_1_2, t), [=](Text param_type_1510) { return prism_rtl::finished(prism_rtl::cat(param_type_1510, " ", crate::emit::cpp::cpp_id(n))); });
            });
        }));
        });
    })));
    }))), Text::lit(", "));
}


prism_rtl::Turn<Text> CppParams::cycle() const {
    const auto& cp = this->cp;
    const auto& ps = this->ps;
    auto cp_1 = cp;
    auto ps_2 = ps;
    return call_value(each_job(ps_2, ({
        auto cp_1_3 = cp_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
        return ({
            auto cp_1_3_3 = cp_1_3;
            entered(once_job([=]() {
            return ({
                auto [n, t] = p0;
                call_then(crate::emit::cpp::expr::start_param_type(cp_1_3_3, t), [=](Text param_type_1510) { return prism_rtl::finished(prism_rtl::cat(param_type_1510, " ", crate::emit::cpp::cpp_id(n))); });
            });
        }));
        });
    })));
    })), [=](Array<Text> each_1487) { return prism_rtl::finished(crate::syntax::lexer::chars::join(each_1487, Text::lit(", "))); });
}


/// `Start CppParams, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_params(crate::emit::cpp::Cp cp, Array<std::tuple<Text, crate::lower::model::OutTy>> ps) {
    return prism_rtl::make_rc<CppParams>(cp, ps);
}


/// FnSignature: unbounded fn Cp, FnDef -> Text
Text fn_signature(const crate::emit::cpp::Cp& cp, const crate::lower::model::FnDef& f) {
    return prism_rtl::cat(cpp_template_head(generic_names_of(f.generics)), crate::emit::cpp::cpp_type(cp, f.ret), " ", crate::emit::cpp::cpp_id(f.name), "(", cpp_params(cp, f.params), ")");
}


prism_rtl::Turn<Text> FnSignature::cycle() const {
    const auto& cp = this->cp;
    const auto& f = this->f;
    auto cp_1 = cp;
    auto f_2 = f;
    return call_then(crate::emit::cpp::start_cpp_type(cp_1, f_2.ret), [=](Text cpp_type_1741) { return call_then(start_cpp_params(cp_1, f_2.params), [=](Text cpp_params_1776) { return prism_rtl::finished(prism_rtl::cat(cpp_template_head(generic_names_of(f_2.generics)), cpp_type_1741, " ", crate::emit::cpp::cpp_id(f_2.name), "(", cpp_params_1776, ")")); }); });
}


/// `Start FnSignature, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_fn_signature(crate::emit::cpp::Cp cp, crate::lower::model::FnDef f) {
    return prism_rtl::make_rc<FnSignature>(cp, f);
}


/// FnDefinition: unbounded fn Cp, FnDef -> Text
Text fn_definition(const crate::emit::cpp::Cp& cp, const crate::lower::model::FnDef& f) {
    return crate::emit::cpp::templates::items::cpp_function(cpp_doc(f.doc), fn_signature(cp, f), crate::emit::cpp::stmts::cpp_body(cp, f.body));
}


prism_rtl::Turn<Text> FnDefinition::cycle() const {
    const auto& cp = this->cp;
    const auto& f = this->f;
    auto cp_1 = cp;
    auto f_2 = f;
    return call_then(start_fn_signature(cp_1, f_2), [=](Text fn_signature_1901) { return call_then(crate::emit::cpp::stmts::start_cpp_body(cp_1, f_2.body), [=](Text cpp_body_1922) { return prism_rtl::finished(crate::emit::cpp::templates::items::cpp_function(cpp_doc(f_2.doc), fn_signature_1901, cpp_body_1922)); }); });
}


/// `Start FnDefinition, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_fn_definition(crate::emit::cpp::Cp cp, crate::lower::model::FnDef f) {
    return prism_rtl::make_rc<FnDefinition>(cp, f);
}


/// ValueDeps: unbounded fn Cp, OutTy -> [Text]
Array<Text> value_deps(const crate::emit::cpp::Cp& cp, const crate::lower::model::OutTy& t) {
    if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t)) {
        auto&& n = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t).a0;
        auto&& args = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t).a1;
        auto own = ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = crate::emit::cpp::type_of(cp, n);
            if (prism_rtl::is_some(_m)) {
                auto&& info = prism_rtl::some_of(_m);
                _v.set((((info.kind == Text::lit("record")) || (info.kind == Text::lit("newtype"))) || (info.kind == Text::lit("unit"))) || (info.kind == Text::lit("tag"))
                    ? Array(std::vector{crate::emit::cpp::absolute(cp, n)})
                    : Array<Text>{});
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(Array<Text>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        return append(own, crate::emit::cpp::patterns::concat2(run_to_end(each_job(args, ({
            auto cp_1 = cp;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(crate::lower::model::OutTy)>>(prism_rtl::rc([=](crate::lower::model::OutTy p0) {
            return ({
                auto cp_1_2 = cp_1;
                entered(once_job([=]() {
                return ({
                    auto a = p0;
                    (prism_rtl::more(prism_rtl::rc(ValueDeps(cp_1_2, a))));
                });
            }));
            });
        })));
        })))));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutOpt>(t)) {
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutOpt>(t).a0;
        return value_deps(cp, i);
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutRes>(t)) {
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutRes>(t).a0;
        return value_deps(cp, i);
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutRc>(t)) {
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutRc>(t).a0;
        return value_deps(cp, i);
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutCell>(t)) {
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutCell>(t).a0;
        return value_deps(cp, i);
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutTuple>(t)) {
        auto&& ts = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(t).a0;
        return crate::emit::cpp::patterns::concat2(run_to_end(each_job(ts, ({
            auto cp_1 = cp;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(crate::lower::model::OutTy)>>(prism_rtl::rc([=](crate::lower::model::OutTy p0) {
            return ({
                auto cp_1_2 = cp_1;
                entered(once_job([=]() {
                return ({
                    auto a = p0;
                    (prism_rtl::more(prism_rtl::rc(ValueDeps(cp_1_2, a))));
                });
            }));
            });
        })));
        }))));
    }
    {
        return Array<Text>{};
    }
}


prism_rtl::Turn<Array<Text>> ValueDeps::cycle() const {
    const auto& cp = this->cp;
    const auto& t = this->t;
    return ({
        prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t) ? ({
        auto&& n = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t).a0;
        auto&& args = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t).a1;
        ({
        auto own = ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = crate::emit::cpp::type_of(cp, n);
            if (prism_rtl::is_some(_m)) {
                auto&& info = prism_rtl::some_of(_m);
                _v.set((((info.kind == Text::lit("record")) || (info.kind == Text::lit("newtype"))) || (info.kind == Text::lit("unit"))) || (info.kind == Text::lit("tag"))
                    ? Array(std::vector{crate::emit::cpp::absolute(cp, n)})
                    : Array<Text>{});
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(Array<Text>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto args_1 = args;
        auto cp_2 = cp;
        call_value(each_job(args_1, ({
        auto cp_2_3 = cp_2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(crate::lower::model::OutTy)>>(prism_rtl::rc([=](crate::lower::model::OutTy p0) {
        return ({
            auto cp_2_3_3 = cp_2_3;
            entered(once_job([=]() {
            return ({
                auto a = p0;
                (prism_rtl::more(prism_rtl::rc(ValueDeps(cp_2_3_3, a))));
            });
        }));
        });
    })));
    })), [=](Array<Array<Text>> each_3037) { return prism_rtl::finished(append(own, crate::emit::cpp::patterns::concat2(each_3037))); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutOpt>(t) ? ({
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutOpt>(t).a0;
        prism_rtl::more(prism_rtl::rc(ValueDeps(cp, i)));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutRes>(t) ? ({
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutRes>(t).a0;
        prism_rtl::more(prism_rtl::rc(ValueDeps(cp, i)));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutRc>(t) ? ({
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutRc>(t).a0;
        prism_rtl::more(prism_rtl::rc(ValueDeps(cp, i)));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutCell>(t) ? ({
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutCell>(t).a0;
        prism_rtl::more(prism_rtl::rc(ValueDeps(cp, i)));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutTuple>(t) ? ({
        auto&& ts = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(t).a0;
        ({
        auto cp_1 = cp;
        auto ts_2 = ts;
        call_value(each_job(ts_2, ({
        auto cp_1_3 = cp_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(crate::lower::model::OutTy)>>(prism_rtl::rc([=](crate::lower::model::OutTy p0) {
        return ({
            auto cp_1_3_3 = cp_1_3;
            entered(once_job([=]() {
            return ({
                auto a = p0;
                (prism_rtl::more(prism_rtl::rc(ValueDeps(cp_1_3_3, a))));
            });
        }));
        });
    })));
    })), [=](Array<Array<Text>> each_3217) { return prism_rtl::finished(crate::emit::cpp::patterns::concat2(each_3217)); });
    });
    })
        : prism_rtl::finished(Array<Text>{});
    });
}


/// `Start ValueDeps, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_value_deps(crate::emit::cpp::Cp cp, crate::lower::model::OutTy t) {
    return prism_rtl::make_rc<ValueDeps>(cp, t);
}


/// let noParts
Parts no_parts() {
    return Parts{.forward = Array<Text>{}, .handles = Array<Text>{}, .values = Array<ValueDecl>{}, .cases_ = Array<Text>{}, .protos = Array<Text>{}, .classes = Array<Text>{}, .outer = Array<Text>{}, .generic = Array<Text>{}, .defs = Array<Text>{}};
}


/// JoinParts: fn Parts, Parts -> Parts
Parts join_parts(const Parts& a, const Parts& b) {
    return Parts{.forward = append(a.forward, b.forward), .handles = append(a.handles, b.handles), .values = append(a.values, b.values), .cases_ = append(a.cases_, b.cases_), .protos = append(a.protos, b.protos), .classes = append(a.classes, b.classes), .outer = append(a.outer, b.outer), .generic = append(a.generic, b.generic), .defs = append(a.defs, b.defs)};
}


/// ItemParts: unbounded fn Cp, Item -> Parts
Parts item_parts(const crate::emit::cpp::Cp& cp, const crate::lower::model::Item& it) {
    if (prism_rtl::is<crate::lower::model::Item::ItType>(it)) {
        auto&& t = prism_rtl::as<crate::lower::model::Item::ItType>(it).a0;
        return type_parts(cp, t);
    }
    if (prism_rtl::is<crate::lower::model::Item::ItTag>(it)) {
        auto&& t = prism_rtl::as<crate::lower::model::Item::ItTag>(it).a0;
        return tag_parts(cp, t);
    }
    if (prism_rtl::is<crate::lower::model::Item::ItRow>(it)) {
        auto&& r = prism_rtl::as<crate::lower::model::Item::ItRow>(it).a0;
        return row_parts(cp, cp.home, r);
    }
    if (prism_rtl::is<crate::lower::model::Item::ItFn>(it)) {
        auto&& f = prism_rtl::as<crate::lower::model::Item::ItFn>(it).a0;
        return fn_parts(cp, f);
    }
    if (prism_rtl::is<crate::lower::model::Item::ItJob>(it)) {
        auto&& j = prism_rtl::as<crate::lower::model::Item::ItJob>(it).a0;
        return job_parts(cp, j);
    }
    if (prism_rtl::is<crate::lower::model::Item::ItNode>(it)) {
        auto&& n = prism_rtl::as<crate::lower::model::Item::ItNode>(it).a0;
        return crate::emit::cpp::program::node_parts(cp, n);
    }
    if (prism_rtl::is<crate::lower::model::Item::ItTrait>(it)) {
        auto&& t = prism_rtl::as<crate::lower::model::Item::ItTrait>(it).a0;
        return trait_parts(cp, t);
    }
    if (prism_rtl::is<crate::lower::model::Item::ItImpl>(it)) {
        auto&& i = prism_rtl::as<crate::lower::model::Item::ItImpl>(it).a0;
        return impl_parts(cp, i);
    }
    if (prism_rtl::is<crate::lower::model::Item::ItNote>(it)) {
        auto&& t = prism_rtl::as<crate::lower::model::Item::ItNote>(it).a0;
        return protos_defs(Array<Text>{}, Array(std::vector{prism_rtl::cat("// ", t)}));
    }
    if (prism_rtl::is<crate::lower::model::Item::ItRefused>(it)) {
        auto&& t = prism_rtl::as<crate::lower::model::Item::ItRefused>(it).a0;
        return protos_defs(Array<Text>{}, Array(std::vector{prism_rtl::cat("compile_error!(\"", crate::lower::expr::lowering_refusal(), crate::lower::expr::escape(t), "\");")}));
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Parts> ItemParts::cycle() const {
    const auto& cp = this->cp;
    const auto& it = this->it;
    return ({
        prism_rtl::is<crate::lower::model::Item::ItType>(it) ? ({
        auto&& t = prism_rtl::as<crate::lower::model::Item::ItType>(it).a0;
        prism_rtl::more(prism_rtl::rc(TypeParts(cp, t)));
    })
        : prism_rtl::is<crate::lower::model::Item::ItTag>(it) ? ({
        auto&& t = prism_rtl::as<crate::lower::model::Item::ItTag>(it).a0;
        prism_rtl::more(prism_rtl::rc(TagParts(cp, t)));
    })
        : prism_rtl::is<crate::lower::model::Item::ItRow>(it) ? ({
        auto&& r = prism_rtl::as<crate::lower::model::Item::ItRow>(it).a0;
        prism_rtl::more(prism_rtl::rc(RowParts(cp, cp.home, r)));
    })
        : prism_rtl::is<crate::lower::model::Item::ItFn>(it) ? ({
        auto&& f = prism_rtl::as<crate::lower::model::Item::ItFn>(it).a0;
        prism_rtl::more(prism_rtl::rc(FnParts(cp, f)));
    })
        : prism_rtl::is<crate::lower::model::Item::ItJob>(it) ? ({
        auto&& j = prism_rtl::as<crate::lower::model::Item::ItJob>(it).a0;
        prism_rtl::more(prism_rtl::rc(JobParts(cp, j)));
    })
        : prism_rtl::is<crate::lower::model::Item::ItNode>(it) ? ({
        auto&& n = prism_rtl::as<crate::lower::model::Item::ItNode>(it).a0;
        prism_rtl::more(prism_rtl::rc(crate::emit::cpp::program::NodeParts(cp, n)));
    })
        : prism_rtl::is<crate::lower::model::Item::ItTrait>(it) ? ({
        auto&& t = prism_rtl::as<crate::lower::model::Item::ItTrait>(it).a0;
        prism_rtl::more(prism_rtl::rc(TraitParts(cp, t)));
    })
        : prism_rtl::is<crate::lower::model::Item::ItImpl>(it) ? ({
        auto&& i = prism_rtl::as<crate::lower::model::Item::ItImpl>(it).a0;
        prism_rtl::more(prism_rtl::rc(ImplParts(cp, i)));
    })
        : prism_rtl::is<crate::lower::model::Item::ItNote>(it) ? ({
        auto&& t = prism_rtl::as<crate::lower::model::Item::ItNote>(it).a0;
        prism_rtl::finished(protos_defs(Array<Text>{}, Array(std::vector{prism_rtl::cat("// ", t)})));
    })
        : prism_rtl::is<crate::lower::model::Item::ItRefused>(it) ? ({
        auto&& t = prism_rtl::as<crate::lower::model::Item::ItRefused>(it).a0;
        prism_rtl::finished(protos_defs(Array<Text>{}, Array(std::vector{prism_rtl::cat("compile_error!(\"", crate::lower::expr::lowering_refusal(), crate::lower::expr::escape(t), "\");")})));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ItemParts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Parts> start_item_parts(crate::emit::cpp::Cp cp, crate::lower::model::Item it) {
    return prism_rtl::make_rc<ItemParts>(cp, it);
}


/// FnParts: unbounded fn Cp, FnDef -> Parts
Parts fn_parts(const crate::emit::cpp::Cp& cp, const crate::lower::model::FnDef& f) {
    return len(f.generics) > Nat(0u)
        ? ({
        Parts this_ = generic_only(Array(std::vector{fn_definition(cp, f)}));
        this_.protos = Array(std::vector{prism_rtl::cat(fn_signature(cp, f), ";")});
        this_;
    })
        : protos_defs(Array(std::vector{prism_rtl::cat(fn_signature(cp, f), ";")}), Array(std::vector{fn_definition(cp, f)}));
}


prism_rtl::Turn<Parts> FnParts::cycle() const {
    const auto& cp = this->cp;
    const auto& f = this->f;
    return len(f.generics) > Nat(0u)
        ? prism_rtl::finished(({
        Parts this_ = generic_only(Array(std::vector{fn_definition(cp, f)}));
        this_.protos = Array(std::vector{prism_rtl::cat(fn_signature(cp, f), ";")});
        this_;
    }))
        : ({
        auto cp_1 = cp;
        auto f_2 = f;
        call_then(start_fn_signature(cp_1, f_2), [=](Text fn_signature_4451) { return call_then(start_fn_definition(cp_1, f_2), [=](Text fn_definition_4478) { return prism_rtl::finished(protos_defs(Array(std::vector{prism_rtl::cat(fn_signature_4451, ";")}), Array(std::vector{fn_definition_4478}))); }); });
    });
}


/// `Start FnParts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Parts> start_fn_parts(crate::emit::cpp::Cp cp, crate::lower::model::FnDef f) {
    return prism_rtl::make_rc<FnParts>(cp, f);
}


/// CppDoc: fn Text -> Text
Text cpp_doc(const Text& text) {
    return text == Text::lit("")
        ? Text::lit("")
        : concat(each(split(text, Text::lit("\n")), [&](const Text& l) { return l == Text::lit("") ? Text::lit("///\n") : prism_rtl::cat("/// ", l, "\n"); }));
}


/// CppSourceDoc: fn Text, Text -> Text
Text cpp_source_doc(const Text& lead, const Text& source) {
    auto quoted = concat(each(split(source, Text::lit("\n")), [&](const Text& l) { return l == Text::lit("") ? Text::lit("///\n") : prism_rtl::cat("/// ", l, "\n"); }));
    return source == Text::lit("")
        ? cpp_doc(lead)
        : lead == Text::lit("")
        ? prism_rtl::cat("/// ```prism\n", quoted, "/// ```\n")
        : prism_rtl::cat("/// ", lead, "\n///\n/// ```prism\n", quoted, "/// ```\n");
}


/// TypeParts: unbounded fn Cp, TyDef -> Parts
Parts type_parts(const crate::emit::cpp::Cp& cp, const crate::lower::model::TyDef& t) {
    auto eq = t.eq;
    auto ord = t.ord && (!t.floaty);
    auto gens = cpp_template_head(t.params);
    auto head = head_of(t.name, t.params);
    auto doc = cpp_source_doc(prism_rtl::cat("`", t.prism, "`:"), t.doc);
    auto members_ = members(t.show_ != crate::lower::model::Shown(crate::lower::model::Shown::NotShown{}), t.pod, head);
    auto generic = len(t.params) > Nat(0u);
    auto fwd = prism_rtl::cat(gens, t.shape == crate::lower::model::TyShape(crate::lower::model::TyShape::ShapeChoice{})
        ? Text::lit("class")
        : Text::lit("struct"), " ", t.name, ";");
    auto&& _m = t.shape;
    if (prism_rtl::is<crate::lower::model::TyShape::ShapeChoice>(_m)) {
        auto names = each(t.cases_, [&](const crate::lower::model::CaseDef& c) { return c.name; });
        auto friend_eq = eq && (!generic)
            ? prism_rtl::cat("\nfriend inline bool operator==(const ", head, "& a, const ", head, "& b);")
            : Text::lit("");
        auto handle = crate::emit::cpp::templates::items::choice_handle(doc, gens, t.name, crate::syntax::lexer::chars::join(each(names, [&](const Text& n) { return prism_rtl::cat("struct ", n, ";"); }), Text::lit("\n")), crate::syntax::lexer::chars::join(names, Text::lit(", ")), prism_rtl::cat(members_, friend_eq));
        auto cases = run_to_end(each_job(t.cases_, ({
            auto cp_1 = cp;
            auto gens_2 = gens;
            auto head_3 = head;
            auto eq_4 = eq;
            auto ord_5 = ord;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::CaseDef)>>(prism_rtl::rc([=](crate::lower::model::CaseDef p0) {
            return ({
                auto cp_1_6 = cp_1;
                auto gens_2_6 = gens_2;
                auto head_3_6 = head_3;
                auto eq_4_6 = eq_4;
                auto ord_5_6 = ord_5;
                entered(once_job([=]() {
                return ({
                    auto c = p0;
                    (prism_rtl::more(prism_rtl::rc(CaseStruct(cp_1_6, gens_2_6, head_3_6, c, eq_4_6, ord_5_6))));
                });
            }));
            });
        })));
        })));
        auto cmp = crate::syntax::lexer::chars::join(filter(Array(std::vector{eq
            ? prism_rtl::cat(gens, "inline bool operator==(const ", head, "& a, const ", head, "& b) { return a.cases() == b.cases(); }")
            : Text::lit(""), ord
            ? prism_rtl::cat(gens, "inline auto operator<=>(const ", head, "& a, const ", head, "& b) { return a.cases() <=> b.cases(); }")
            : Text::lit("")}), [&](const Text& s) { return s != Text::lit(""); }), Text::lit("\n"));
        auto defs = type_defs(cp, t, head);
        return Parts{.forward = Array(std::vector{fwd}), .handles = Array(std::vector{handle}), .values = Array<ValueDecl>{}, .cases_ = append(cases, Array(std::vector{cases_accessor(gens, head), cmp})), .protos = Array<Text>{}, .classes = Array<Text>{}, .outer = Array<Text>{}, .generic = generic ? Array(std::vector{defs}) : Array<Text>{}, .defs = generic ? Array<Text>{} : Array(std::vector{defs})};
    }
    {
        auto first_ = or_(index(t.cases_, Nat(0u)), crate::lower::model::CaseDef{.name = Text::lit(""), .prism = Text::lit(""), .fields = Array<std::tuple<Text, crate::lower::model::OutTy>>{}});
        auto fields = ({
            __label__ _done;
            prism_rtl::Slot<Text> _v;
            auto&& _m = t.shape;
            if (prism_rtl::is<crate::lower::model::TyShape::ShapeRecord>(_m)) {
                _v.set(crate::syntax::lexer::chars::join(run_to_end(each_job(first_.fields, ({
                    auto cp_1 = cp;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
                    return ({
                        auto cp_1_2 = cp_1;
                        entered(once_job([=]() {
                        return ({
                            auto [f, ft] = p0;
                            call_then(crate::emit::cpp::start_cpp_type(cp_1_2, ft), [=](Text cpp_type_7090) { return prism_rtl::finished(prism_rtl::cat(cpp_type_7090, " ", crate::emit::cpp::field_id(f), ";")); });
                        });
                    }));
                    });
                })));
                }))), Text::lit("\n")));
                goto _done;
            }
            if (prism_rtl::is<crate::lower::model::TyShape::ShapeNewtype>(_m)) {
                _v.set(positional_fields(cp, first_.fields));
                goto _done;
            }
            {
                _v.set(Text::lit(""));
                goto _done;
            }
        _done:
            _v.take();
        });
        auto cmps = crate::syntax::lexer::chars::join(filter(Array(std::vector{eq
            ? prism_rtl::cat("bool operator==(const ", t.name, "&) const = default;")
            : Text::lit(""), ord
            ? prism_rtl::cat("auto operator<=>(const ", t.name, "&) const = default;")
            : Text::lit("")}), [&](const Text& s) { return s != Text::lit(""); }), Text::lit("\n"));
        auto decl = crate::emit::cpp::templates::items::value_struct(doc, gens, t.name, fields, crate::syntax::lexer::chars::join(filter(Array(std::vector{cmps, members_}), [&](const Text& s) { return s != Text::lit(""); }), Text::lit("\n")));
        auto defs = type_defs(cp, t, head);
        auto deps = crate::emit::cpp::patterns::concat2(run_to_end(each_job(first_.fields, ({
            auto cp_1 = cp;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
            return ({
                auto cp_1_2 = cp_1;
                entered(once_job([=]() {
                return ({
                    auto&& _ft = p0;
                    auto&& ft = std::get<1>(_ft);
                    (prism_rtl::more(prism_rtl::rc(ValueDeps(cp_1_2, ft))));
                });
            }));
            });
        })));
        }))));
        return Parts{.forward = Array(std::vector{fwd}), .handles = Array<Text>{}, .values = Array(std::vector{ValueDecl{.path_ = prism_rtl::cat(cp.home, "::", t.name), .deps = deps, .text = decl}}), .cases_ = Array<Text>{}, .protos = Array<Text>{}, .classes = Array<Text>{}, .outer = Array<Text>{}, .generic = generic ? Array(std::vector{defs}) : Array<Text>{}, .defs = generic ? Array<Text>{} : Array(std::vector{defs})};
    }
}


prism_rtl::Turn<Parts> TypeParts::cycle() const {
    const auto& cp = this->cp;
    const auto& t = this->t;
    auto eq = t.eq;
    auto ord = t.ord && (!t.floaty);
    auto gens = cpp_template_head(t.params);
    auto head = head_of(t.name, t.params);
    auto doc = cpp_source_doc(prism_rtl::cat("`", t.prism, "`:"), t.doc);
    auto members_ = members(t.show_ != crate::lower::model::Shown(crate::lower::model::Shown::NotShown{}), t.pod, head);
    auto generic = len(t.params) > Nat(0u);
    auto fwd = prism_rtl::cat(gens, t.shape == crate::lower::model::TyShape(crate::lower::model::TyShape::ShapeChoice{})
        ? Text::lit("class")
        : Text::lit("struct"), " ", t.name, ";");
    return ({
        auto&& _m = t.shape;
        prism_rtl::is<crate::lower::model::TyShape::ShapeChoice>(_m) ? ({
        auto names = each(t.cases_, [&](const crate::lower::model::CaseDef& c) { return c.name; });
        auto friend_eq = eq && (!generic)
            ? prism_rtl::cat("\nfriend inline bool operator==(const ", head, "& a, const ", head, "& b);")
            : Text::lit("");
        auto handle = crate::emit::cpp::templates::items::choice_handle(doc, gens, t.name, crate::syntax::lexer::chars::join(each(names, [&](const Text& n) { return prism_rtl::cat("struct ", n, ";"); }), Text::lit("\n")), crate::syntax::lexer::chars::join(names, Text::lit(", ")), prism_rtl::cat(members_, friend_eq));
        auto cp_1 = cp;
        auto t_2 = t;
        call_value(each_job(t_2.cases_, ({
        auto cp_1_3 = cp_1;
        auto gens_3 = gens;
        auto head_4 = head;
        auto eq_5 = eq;
        auto ord_6 = ord;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::CaseDef)>>(prism_rtl::rc([=](crate::lower::model::CaseDef p0) {
        return ({
            auto cp_1_3_7 = cp_1_3;
            auto gens_3_7 = gens_3;
            auto head_4_7 = head_4;
            auto eq_5_7 = eq_5;
            auto ord_6_7 = ord_6;
            entered(once_job([=]() {
            return ({
                auto c = p0;
                (prism_rtl::more(prism_rtl::rc(CaseStruct(cp_1_3_7, gens_3_7, head_4_7, c, eq_5_7, ord_6_7))));
            });
        }));
        });
    })));
    })), [=](Array<Text> each_6227) {
        return ({
            auto cases = each_6227;
            auto cmp = crate::syntax::lexer::chars::join(filter(Array(std::vector{eq
                ? prism_rtl::cat(gens, "inline bool operator==(const ", head, "& a, const ", head, "& b) { return a.cases() == b.cases(); }")
                : Text::lit(""), ord
                ? prism_rtl::cat(gens, "inline auto operator<=>(const ", head, "& a, const ", head, "& b) { return a.cases() <=> b.cases(); }")
                : Text::lit("")}), [&](const Text& s) { return s != Text::lit(""); }), Text::lit("\n"));
            call_then(start_type_defs(cp_1, t_2, head), [=](Text type_defs_6611) {
            return ({
                auto defs = type_defs_6611;
                (prism_rtl::finished(Parts{.forward = Array(std::vector{fwd}), .handles = Array(std::vector{handle}), .values = Array<ValueDecl>{}, .cases_ = append(cases, Array(std::vector{cases_accessor(gens, head), cmp})), .protos = Array<Text>{}, .classes = Array<Text>{}, .outer = Array<Text>{}, .generic = generic ? Array(std::vector{defs}) : Array<Text>{}, .defs = generic ? Array<Text>{} : Array(std::vector{defs})}));
            });
        });
        });
    });
    })
        : ({
        auto first_ = or_(index(t.cases_, Nat(0u)), crate::lower::model::CaseDef{.name = Text::lit(""), .prism = Text::lit(""), .fields = Array<std::tuple<Text, crate::lower::model::OutTy>>{}});
        auto fields = ({
            __label__ _done;
            prism_rtl::Slot<Text> _v;
            auto&& _m = t.shape;
            if (prism_rtl::is<crate::lower::model::TyShape::ShapeRecord>(_m)) {
                _v.set(crate::syntax::lexer::chars::join(run_to_end(each_job(first_.fields, ({
                    auto cp_1 = cp;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
                    return ({
                        auto cp_1_2 = cp_1;
                        entered(once_job([=]() {
                        return ({
                            auto [f, ft] = p0;
                            call_then(crate::emit::cpp::start_cpp_type(cp_1_2, ft), [=](Text cpp_type_7090) { return prism_rtl::finished(prism_rtl::cat(cpp_type_7090, " ", crate::emit::cpp::field_id(f), ";")); });
                        });
                    }));
                    });
                })));
                }))), Text::lit("\n")));
                goto _done;
            }
            if (prism_rtl::is<crate::lower::model::TyShape::ShapeNewtype>(_m)) {
                _v.set(positional_fields(cp, first_.fields));
                goto _done;
            }
            {
                _v.set(Text::lit(""));
                goto _done;
            }
        _done:
            _v.take();
        });
        auto cmps = crate::syntax::lexer::chars::join(filter(Array(std::vector{eq
            ? prism_rtl::cat("bool operator==(const ", t.name, "&) const = default;")
            : Text::lit(""), ord
            ? prism_rtl::cat("auto operator<=>(const ", t.name, "&) const = default;")
            : Text::lit("")}), [&](const Text& s) { return s != Text::lit(""); }), Text::lit("\n"));
        auto decl = crate::emit::cpp::templates::items::value_struct(doc, gens, t.name, fields, crate::syntax::lexer::chars::join(filter(Array(std::vector{cmps, members_}), [&](const Text& s) { return s != Text::lit(""); }), Text::lit("\n")));
        auto cp_1 = cp;
        auto t_2 = t;
        call_then(start_type_defs(cp_1, t_2, head), [=](Text type_defs_7564) {
        return ({
            auto defs = type_defs_7564;
            call_value(each_job(first_.fields, ({
            auto cp_1_3 = cp_1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
            return ({
                auto cp_1_3_3 = cp_1_3;
                entered(once_job([=]() {
                return ({
                    auto&& _ft = p0;
                    auto&& ft = std::get<1>(_ft);
                    (prism_rtl::more(prism_rtl::rc(ValueDeps(cp_1_3_3, ft))));
                });
            }));
            });
        })));
        })), [=](Array<Array<Text>> each_7617) {
            return ({
                auto deps = crate::emit::cpp::patterns::concat2(each_7617);
                (prism_rtl::finished(Parts{.forward = Array(std::vector{fwd}), .handles = Array<Text>{}, .values = Array(std::vector{ValueDecl{.path_ = prism_rtl::cat(cp_1.home, "::", t_2.name), .deps = deps, .text = decl}}), .cases_ = Array<Text>{}, .protos = Array<Text>{}, .classes = Array<Text>{}, .outer = Array<Text>{}, .generic = generic ? Array(std::vector{defs}) : Array<Text>{}, .defs = generic ? Array<Text>{} : Array(std::vector{defs})}));
            });
        });
        });
    });
    });
    });
}


/// `Start TypeParts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Parts> start_type_parts(crate::emit::cpp::Cp cp, crate::lower::model::TyDef t) {
    return prism_rtl::make_rc<TypeParts>(cp, t);
}


/// CasesAccessor: fn Text, Text -> Text
Text cases_accessor(const Text& gens, const Text& head) {
    return prism_rtl::cat(gens, "inline const ", gens == Text::lit("") ? Text::lit("") : Text::lit("typename "), head, "::Cases& ", head, "::cases() const { return *cases_; }");
}


/// Members: fn Bool, Bool, Text -> Text
Text members(const bool& shown, const bool& pod, const Text& head) {
    auto s = shown
        ? Array(std::vector{Text::lit("void show(Printer& p) const;")})
        : Array<Text>{};
    auto d = pod
        ? Array(std::vector{Text::lit("Pod to_pod() const;"), prism_rtl::cat("static Result<", head, "> from_pod(const Pod& whole);")})
        : Array<Text>{};
    return crate::syntax::lexer::chars::join(append(s, d), Text::lit("\n"));
}


/// CaseStruct: unbounded fn Cp, Text, Text, CaseDef, Bool, Bool -> Text
Text case_struct(const crate::emit::cpp::Cp& cp, const Text& gens, const Text& head, const crate::lower::model::CaseDef& c, const bool& eq, const bool& ord) {
    auto fields = positional_fields(cp, c.fields);
    auto cmps = crate::syntax::lexer::chars::join(filter(Array(std::vector{eq
        ? prism_rtl::cat("bool operator==(const ", c.name, "&) const = default;")
        : Text::lit(""), ord
        ? prism_rtl::cat("auto operator<=>(const ", c.name, "&) const = default;")
        : Text::lit("")}), [&](const Text& s) { return s != Text::lit(""); }), Text::lit("\n"));
    return crate::emit::cpp::templates::items::case_decl(gens, prism_rtl::cat(head, "::", c.name), crate::syntax::lexer::chars::join(filter(Array(std::vector{fields, cmps}), [&](const Text& s) { return s != Text::lit(""); }), Text::lit("\n")));
}


prism_rtl::Turn<Text> CaseStruct::cycle() const {
    const auto& cp = this->cp;
    const auto& gens = this->gens;
    const auto& head = this->head;
    const auto& c = this->c;
    const auto& eq = this->eq;
    const auto& ord = this->ord;
    auto c_1 = c;
    auto cp_2 = cp;
    auto eq_3 = eq;
    auto gens_4 = gens;
    auto head_5 = head;
    auto ord_6 = ord;
    return call_then(start_positional_fields(cp_2, c_1.fields), [=](Text positional_fields_8644) {
        return ({
            auto fields = positional_fields_8644;
            auto cmps = crate::syntax::lexer::chars::join(filter(Array(std::vector{eq_3
                ? prism_rtl::cat("bool operator==(const ", c_1.name, "&) const = default;")
                : Text::lit(""), ord_6
                ? prism_rtl::cat("auto operator<=>(const ", c_1.name, "&) const = default;")
                : Text::lit("")}), [&](const Text& s) { return s != Text::lit(""); }), Text::lit("\n"));
            (prism_rtl::finished(crate::emit::cpp::templates::items::case_decl(gens_4, prism_rtl::cat(head_5, "::", c_1.name), crate::syntax::lexer::chars::join(filter(Array(std::vector{fields, cmps}), [&](const Text& s) { return s != Text::lit(""); }), Text::lit("\n")))));
        });
    });
}


/// `Start CaseStruct, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_case_struct(crate::emit::cpp::Cp cp, Text gens, Text head, crate::lower::model::CaseDef c, bool eq, bool ord) {
    return prism_rtl::make_rc<CaseStruct>(cp, gens, head, c, eq, ord);
}


/// TypeDefs: unbounded fn Cp, TyDef, Text -> Text
Text type_defs(const crate::emit::cpp::Cp& cp, const crate::lower::model::TyDef& t, const Text& head) {
    auto gens = cpp_template_head(t.params);
    auto show_ = t.show_ == crate::lower::model::Shown(crate::lower::model::Shown::ShownDerived{})
        ? Array(std::vector{show_def(cp, t, head, gens)})
        : Array<Text>{};
    auto pod = t.pod
        ? Array(std::vector{to_pod_def(cp, t, head, gens), from_pod_def(cp, t, head, gens)})
        : Array<Text>{};
    return crate::syntax::lexer::chars::join(append(show_, pod), Text::lit("\n"));
}


prism_rtl::Turn<Text> TypeDefs::cycle() const {
    const auto& cp = this->cp;
    const auto& t = this->t;
    const auto& head = this->head;
    auto gens = cpp_template_head(t.params);
    auto show_ = t.show_ == crate::lower::model::Shown(crate::lower::model::Shown::ShownDerived{})
        ? Array(std::vector{show_def(cp, t, head, gens)})
        : Array<Text>{};
    auto pod = t.pod
        ? Array(std::vector{to_pod_def(cp, t, head, gens), from_pod_def(cp, t, head, gens)})
        : Array<Text>{};
    return prism_rtl::finished(crate::syntax::lexer::chars::join(append(show_, pod), Text::lit("\n")));
}


/// `Start TypeDefs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_type_defs(crate::emit::cpp::Cp cp, crate::lower::model::TyDef t, Text head) {
    return prism_rtl::make_rc<TypeDefs>(cp, t, head);
}


/// ShowDef: unbounded fn Cp, TyDef, Text, Text -> Text
Text show_def(const crate::emit::cpp::Cp& cp, const crate::lower::model::TyDef& t, const Text& head, const Text& gens) {
    auto body = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = t.shape;
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeRecord>(_m)) {
            _v.set(({
                auto c = or_(index(t.cases_, Nat(0u)), crate::lower::model::CaseDef{.name = Text::lit(""), .prism = Text::lit(""), .fields = Array<std::tuple<Text, crate::lower::model::OutTy>>{}});
                (prism_rtl::cat("p.record(\"", t.prism, "\", {", crate::syntax::lexer::chars::join(each(c.fields, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
                auto&& f = std::get<0>(_p0);
                return prism_rtl::cat("{\"", prism_field(f), "\", ", crate::emit::cpp::field_id(f), "}");
            }), Text::lit(", ")), "});"));
            }));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeChoice>(_m)) {
            _v.set(crate::syntax::lexer::chars::join(each(crate::check::errors::range0(len(t.cases_)), [&](const Nat& i) { return show_case(t, i); }), Text::lit("\n")));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeNewtype>(_m)) {
            _v.set(prism_rtl::cat("p.choice(\"", first_case(t), "\", {", crate::syntax::lexer::chars::join(each(crate::check::errors::range0(first_arity(t)), [&](const Nat& k) { return prism_rtl::cat("a", k); }), Text::lit(", ")), "});"));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeUnit>(_m)) {
            _v.set(prism_rtl::cat("p.choice(\"", first_case(t), "\", {});"));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat(gens, "void ", head, "::show(Printer& p) const"), body);
}


prism_rtl::Turn<Text> ShowDef::cycle() const {
    const auto& cp = this->cp;
    const auto& t = this->t;
    const auto& head = this->head;
    const auto& gens = this->gens;
    auto body = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = t.shape;
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeRecord>(_m)) {
            _v.set(({
                auto c = or_(index(t.cases_, Nat(0u)), crate::lower::model::CaseDef{.name = Text::lit(""), .prism = Text::lit(""), .fields = Array<std::tuple<Text, crate::lower::model::OutTy>>{}});
                (prism_rtl::cat("p.record(\"", t.prism, "\", {", crate::syntax::lexer::chars::join(each(c.fields, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
                auto&& f = std::get<0>(_p0);
                return prism_rtl::cat("{\"", prism_field(f), "\", ", crate::emit::cpp::field_id(f), "}");
            }), Text::lit(", ")), "});"));
            }));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeChoice>(_m)) {
            _v.set(crate::syntax::lexer::chars::join(each(crate::check::errors::range0(len(t.cases_)), [&](const Nat& i) { return show_case(t, i); }), Text::lit("\n")));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeNewtype>(_m)) {
            _v.set(prism_rtl::cat("p.choice(\"", first_case(t), "\", {", crate::syntax::lexer::chars::join(each(crate::check::errors::range0(first_arity(t)), [&](const Nat& k) { return prism_rtl::cat("a", k); }), Text::lit(", ")), "});"));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeUnit>(_m)) {
            _v.set(prism_rtl::cat("p.choice(\"", first_case(t), "\", {});"));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return prism_rtl::finished(crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat(gens, "void ", head, "::show(Printer& p) const"), body));
}


/// `Start ShowDef, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_show_def(crate::emit::cpp::Cp cp, crate::lower::model::TyDef t, Text head, Text gens) {
    return prism_rtl::make_rc<ShowDef>(cp, t, head, gens);
}


/// ShowCase: fn TyDef, Nat -> Text
Text show_case(const crate::lower::model::TyDef& t, const Nat& i) {
    auto c = or_(index(t.cases_, i), crate::lower::model::CaseDef{.name = Text::lit(""), .prism = Text::lit(""), .fields = Array<std::tuple<Text, crate::lower::model::OutTy>>{}});
    auto head = prism_rtl::cat(i == Nat(0u) ? Text::lit("if") : Text::lit("else if"), " (auto c = std::get_if<", c.name, ">(&cases()))");
    return prism_rtl::cat(head, " p.choice(\"", c.prism, "\", {", crate::syntax::lexer::chars::join(each(crate::check::errors::range0(len(c.fields)), [&](const Nat& k) { return prism_rtl::cat("c->a", k); }), Text::lit(", ")), "});");
}


/// FirstCase: fn TyDef -> Text
Text first_case(const crate::lower::model::TyDef& t) {
    return or_(index(t.cases_, Nat(0u)), crate::lower::model::CaseDef{.name = Text::lit(""), .prism = t.prism, .fields = Array<std::tuple<Text, crate::lower::model::OutTy>>{}}).prism;
}


/// FirstArity: fn TyDef -> Nat
Nat first_arity(const crate::lower::model::TyDef& t) {
    return len(or_(index(t.cases_, Nat(0u)), crate::lower::model::CaseDef{.name = Text::lit(""), .prism = Text::lit(""), .fields = Array<std::tuple<Text, crate::lower::model::OutTy>>{}}).fields);
}


/// FieldTypes: fn [((Text, OutTy))] -> [OutTy]
Array<crate::lower::model::OutTy> field_types(const Array<std::tuple<Text, crate::lower::model::OutTy>>& fs) {
    return each(fs, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
        auto&& t = std::get<1>(_p0);
        return t;
    });
}


/// PositionalFields: unbounded fn Cp, [((Text, OutTy))] -> Text
Text positional_fields(const crate::emit::cpp::Cp& cp, const Array<std::tuple<Text, crate::lower::model::OutTy>>& fs) {
    auto tys = field_types(fs);
    return crate::syntax::lexer::chars::join(run_to_end(each_job(crate::check::errors::range0(len(tys)), ({
        auto cp_1 = cp;
        auto tys_2 = tys;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto cp_1_3 = cp_1;
            auto tys_2_3 = tys_2;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                call_then(crate::emit::cpp::start_cpp_type(cp_1_3, or_(index(tys_2_3, i), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}))), [=](Text cpp_type_10904) { return prism_rtl::finished(prism_rtl::cat(cpp_type_10904, " a", i, ";")); });
            });
        }));
        });
    })));
    }))), Text::lit("\n"));
}


prism_rtl::Turn<Text> PositionalFields::cycle() const {
    const auto& cp = this->cp;
    const auto& fs = this->fs;
    auto tys = field_types(fs);
    auto cp_1 = cp;
    return call_value(each_job(crate::check::errors::range0(len(tys)), ({
        auto cp_1_2 = cp_1;
        auto tys_2 = tys;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto cp_1_2_3 = cp_1_2;
            auto tys_2_3 = tys_2;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                call_then(crate::emit::cpp::start_cpp_type(cp_1_2_3, or_(index(tys_2_3, i), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}))), [=](Text cpp_type_10904) { return prism_rtl::finished(prism_rtl::cat(cpp_type_10904, " a", i, ";")); });
            });
        }));
        });
    })));
    })), [=](Array<Text> each_10872) { return prism_rtl::finished(crate::syntax::lexer::chars::join(each_10872, Text::lit("\n"))); });
}


/// `Start PositionalFields, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_positional_fields(crate::emit::cpp::Cp cp, Array<std::tuple<Text, crate::lower::model::OutTy>> fs) {
    return prism_rtl::make_rc<PositionalFields>(cp, fs);
}


/// ToPodDef: unbounded fn Cp, TyDef, Text, Text -> Text
Text to_pod_def(const crate::emit::cpp::Cp& cp, const crate::lower::model::TyDef& t, const Text& head, const Text& gens) {
    auto structure = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = t.shape;
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeRecord>(_m)) {
            _v.set(({
                auto c = or_(index(t.cases_, Nat(0u)), crate::lower::model::CaseDef{.name = Text::lit(""), .prism = Text::lit(""), .fields = Array<std::tuple<Text, crate::lower::model::OutTy>>{}});
                (prism_rtl::cat("Pod::record(\"", t.prism, "\", {", crate::syntax::lexer::chars::join(each(c.fields, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
                auto&& f = std::get<0>(_p0);
                return prism_rtl::cat("{\"", prism_field(f), "\", prism_rtl::to_pod(", crate::emit::cpp::field_id(f), ")}");
            }), Text::lit(", ")), "})"));
            }));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeChoice>(_m)) {
            _v.set(choice_pod(t));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeNewtype>(_m)) {
            _v.set(prism_rtl::cat("Pod::choice(\"", first_case(t), "\", {", crate::syntax::lexer::chars::join(each(crate::check::errors::range0(first_arity(t)), [&](const Nat& k) { return prism_rtl::cat("prism_rtl::to_pod(a", k, ")"); }), Text::lit(", ")), "})"));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeUnit>(_m)) {
            _v.set(prism_rtl::cat("Pod::choice(\"", first_case(t), "\", {})"));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto body = t.show_ == crate::lower::model::Shown(crate::lower::model::Shown::ShownOwn{})
        ? prism_rtl::cat("Pod structure = ", structure, ";\nreturn Pod::shown(prism_rtl::show(*this), structure);")
        : prism_rtl::cat("return ", structure, ";");
    return crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat(gens, "Pod ", head, "::to_pod() const"), body);
}


prism_rtl::Turn<Text> ToPodDef::cycle() const {
    const auto& cp = this->cp;
    const auto& t = this->t;
    const auto& head = this->head;
    const auto& gens = this->gens;
    auto structure = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = t.shape;
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeRecord>(_m)) {
            _v.set(({
                auto c = or_(index(t.cases_, Nat(0u)), crate::lower::model::CaseDef{.name = Text::lit(""), .prism = Text::lit(""), .fields = Array<std::tuple<Text, crate::lower::model::OutTy>>{}});
                (prism_rtl::cat("Pod::record(\"", t.prism, "\", {", crate::syntax::lexer::chars::join(each(c.fields, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
                auto&& f = std::get<0>(_p0);
                return prism_rtl::cat("{\"", prism_field(f), "\", prism_rtl::to_pod(", crate::emit::cpp::field_id(f), ")}");
            }), Text::lit(", ")), "})"));
            }));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeChoice>(_m)) {
            _v.set(choice_pod(t));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeNewtype>(_m)) {
            _v.set(prism_rtl::cat("Pod::choice(\"", first_case(t), "\", {", crate::syntax::lexer::chars::join(each(crate::check::errors::range0(first_arity(t)), [&](const Nat& k) { return prism_rtl::cat("prism_rtl::to_pod(a", k, ")"); }), Text::lit(", ")), "})"));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeUnit>(_m)) {
            _v.set(prism_rtl::cat("Pod::choice(\"", first_case(t), "\", {})"));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto body = t.show_ == crate::lower::model::Shown(crate::lower::model::Shown::ShownOwn{})
        ? prism_rtl::cat("Pod structure = ", structure, ";\nreturn Pod::shown(prism_rtl::show(*this), structure);")
        : prism_rtl::cat("return ", structure, ";");
    return prism_rtl::finished(crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat(gens, "Pod ", head, "::to_pod() const"), body));
}


/// `Start ToPodDef, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_to_pod_def(crate::emit::cpp::Cp cp, crate::lower::model::TyDef t, Text head, Text gens) {
    return prism_rtl::make_rc<ToPodDef>(cp, t, head, gens);
}


/// ChoicePod: fn TyDef -> Text
Text choice_pod(const crate::lower::model::TyDef& t) {
    auto arms = each(crate::check::errors::range0(len(t.cases_)), [&](const Nat& i) {
        return ({
            auto c = or_(index(t.cases_, i), crate::lower::model::CaseDef{.name = Text::lit(""), .prism = Text::lit(""), .fields = Array<std::tuple<Text, crate::lower::model::OutTy>>{}});
            (prism_rtl::cat("std::holds_alternative<", c.name, ">(cases()) ? Pod::choice(\"", c.prism, "\", {", crate::syntax::lexer::chars::join(each(crate::check::errors::range0(len(c.fields)), [&](const Nat& k) { return prism_rtl::cat("prism_rtl::to_pod(std::get<", c.name, ">(cases()).a", k, ")"); }), Text::lit(", ")), "})"));
        });
    });
    return prism_rtl::cat(crate::syntax::lexer::chars::join(arms, Text::lit("\n    : ")), "\n    : Pod()");
}


/// FromPodDef: unbounded fn Cp, TyDef, Text, Text -> Text
Text from_pod_def(const crate::emit::cpp::Cp& cp, const crate::lower::model::TyDef& t, const Text& head, const Text& gens) {
    auto body = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = t.shape;
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeRecord>(_m)) {
            _v.set(({
                auto c = or_(index(t.cases_, Nat(0u)), crate::lower::model::CaseDef{.name = Text::lit(""), .prism = Text::lit(""), .fields = Array<std::tuple<Text, crate::lower::model::OutTy>>{}});
                auto reads = crate::syntax::lexer::chars::join(run_to_end(each_job(c.fields, ({
                    auto cp_1 = cp;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
                    return ({
                        auto cp_1_2 = cp_1;
                        entered(once_job([=]() {
                        return ({
                            auto [f, ft] = p0;
                            call_then(crate::emit::cpp::start_cpp_type(cp_1_2, ft), [=](Text cpp_type_12476) { return prism_rtl::finished(prism_rtl::cat(".", crate::emit::cpp::field_id(f), " = TRY(prism_rtl::from_pod<", cpp_type_12476, ">(TRY(crate::prelude::field(whole, \"", prism_field(f), "\"))))")); });
                        });
                    }));
                    });
                })));
                }))), Text::lit(", "));
                (prism_rtl::cat("return ", head, "{", reads, "};"));
            }));
            goto _done;
        }
        {
            _v.set(({
                auto arms = run_to_end(each_job(t.cases_, ({
                    auto cp_1 = cp;
                    auto t_2 = t;
                    auto head_3 = head;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::CaseDef)>>(prism_rtl::rc([=](crate::lower::model::CaseDef p0) {
                    return ({
                        auto cp_1_4 = cp_1;
                        auto t_2_4 = t_2;
                        auto head_3_4 = head_3;
                        entered(once_job([=]() {
                        return ({
                            auto c = p0;
                            ({
                            auto n = len(c.fields);
                            auto tys = field_types(c.fields);
                            call_value(each_job(crate::check::errors::range0(n), ({
                            auto cp_1_4_4 = cp_1_4;
                            auto tys_4 = tys;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Nat)>>(prism_rtl::rc([=](Nat p0) {
                            return ({
                                auto cp_1_4_4_5 = cp_1_4_4;
                                auto tys_4_5 = tys_4;
                                entered(once_job([=]() {
                                return ({
                                    auto i = p0;
                                    call_then(crate::emit::cpp::start_cpp_type(cp_1_4_4_5, or_(index(tys_4_5, i), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}))), [=](Text cpp_type_12822) { return prism_rtl::finished(prism_rtl::cat("TRY(prism_rtl::from_pod<", cpp_type_12822, ">(c->args[", i, "]))")); });
                                });
                            }));
                            });
                        })));
                        })), [=](Array<Text> each_12774) {
                            return ({
                                auto args = crate::syntax::lexer::chars::join(each_12774, Text::lit(", "));
                                auto made = ({
                                    __label__ _done;
                                    prism_rtl::Slot<Text> _v;
                                    auto&& _m = t_2_4.shape;
                                    if (prism_rtl::is<crate::lower::model::TyShape::ShapeChoice>(_m)) {
                                        _v.set(prism_rtl::cat(head_3_4, "(", c.name, "{", args, "})"));
                                        goto _done;
                                    }
                                    {
                                        _v.set(prism_rtl::cat(head_3_4, "{", args, "}"));
                                        goto _done;
                                    }
                                _done:
                                    _v.take();
                                });
                                (prism_rtl::finished(prism_rtl::cat("if (c->ctor == \"", c.prism, "\" && c->args.size() == ", n, ") return ", made, ";")));
                            });
                        });
                        });
                        });
                    }));
                    });
                })));
                })));
                (prism_rtl::cat("const Pod& p = whole.structure();\nif (auto c = p.if_choice()) {\n", indent_cpp(crate::syntax::lexer::chars::join(arms, Text::lit("\n"))), "\n}\nreturn mismatch<", head, ">(\"a ", t.prism, "\", p);"));
            }));
            goto _done;
        }
    _done:
        _v.take();
    });
    return crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat(gens, "Result<", head, "> ", head, "::from_pod(const Pod& whole)"), body);
}


prism_rtl::Turn<Text> FromPodDef::cycle() const {
    const auto& cp = this->cp;
    const auto& t = this->t;
    const auto& head = this->head;
    const auto& gens = this->gens;
    auto body = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = t.shape;
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeRecord>(_m)) {
            _v.set(({
                auto c = or_(index(t.cases_, Nat(0u)), crate::lower::model::CaseDef{.name = Text::lit(""), .prism = Text::lit(""), .fields = Array<std::tuple<Text, crate::lower::model::OutTy>>{}});
                auto reads = crate::syntax::lexer::chars::join(run_to_end(each_job(c.fields, ({
                    auto cp_1 = cp;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
                    return ({
                        auto cp_1_2 = cp_1;
                        entered(once_job([=]() {
                        return ({
                            auto [f, ft] = p0;
                            call_then(crate::emit::cpp::start_cpp_type(cp_1_2, ft), [=](Text cpp_type_12476) { return prism_rtl::finished(prism_rtl::cat(".", crate::emit::cpp::field_id(f), " = TRY(prism_rtl::from_pod<", cpp_type_12476, ">(TRY(crate::prelude::field(whole, \"", prism_field(f), "\"))))")); });
                        });
                    }));
                    });
                })));
                }))), Text::lit(", "));
                (prism_rtl::cat("return ", head, "{", reads, "};"));
            }));
            goto _done;
        }
        {
            _v.set(({
                auto arms = run_to_end(each_job(t.cases_, ({
                    auto cp_1 = cp;
                    auto t_2 = t;
                    auto head_3 = head;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::CaseDef)>>(prism_rtl::rc([=](crate::lower::model::CaseDef p0) {
                    return ({
                        auto cp_1_4 = cp_1;
                        auto t_2_4 = t_2;
                        auto head_3_4 = head_3;
                        entered(once_job([=]() {
                        return ({
                            auto c = p0;
                            ({
                            auto n = len(c.fields);
                            auto tys = field_types(c.fields);
                            call_value(each_job(crate::check::errors::range0(n), ({
                            auto cp_1_4_4 = cp_1_4;
                            auto tys_4 = tys;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Nat)>>(prism_rtl::rc([=](Nat p0) {
                            return ({
                                auto cp_1_4_4_5 = cp_1_4_4;
                                auto tys_4_5 = tys_4;
                                entered(once_job([=]() {
                                return ({
                                    auto i = p0;
                                    call_then(crate::emit::cpp::start_cpp_type(cp_1_4_4_5, or_(index(tys_4_5, i), crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{}))), [=](Text cpp_type_12822) { return prism_rtl::finished(prism_rtl::cat("TRY(prism_rtl::from_pod<", cpp_type_12822, ">(c->args[", i, "]))")); });
                                });
                            }));
                            });
                        })));
                        })), [=](Array<Text> each_12774) {
                            return ({
                                auto args = crate::syntax::lexer::chars::join(each_12774, Text::lit(", "));
                                auto made = ({
                                    __label__ _done;
                                    prism_rtl::Slot<Text> _v;
                                    auto&& _m = t_2_4.shape;
                                    if (prism_rtl::is<crate::lower::model::TyShape::ShapeChoice>(_m)) {
                                        _v.set(prism_rtl::cat(head_3_4, "(", c.name, "{", args, "})"));
                                        goto _done;
                                    }
                                    {
                                        _v.set(prism_rtl::cat(head_3_4, "{", args, "}"));
                                        goto _done;
                                    }
                                _done:
                                    _v.take();
                                });
                                (prism_rtl::finished(prism_rtl::cat("if (c->ctor == \"", c.prism, "\" && c->args.size() == ", n, ") return ", made, ";")));
                            });
                        });
                        });
                        });
                    }));
                    });
                })));
                })));
                (prism_rtl::cat("const Pod& p = whole.structure();\nif (auto c = p.if_choice()) {\n", indent_cpp(crate::syntax::lexer::chars::join(arms, Text::lit("\n"))), "\n}\nreturn mismatch<", head, ">(\"a ", t.prism, "\", p);"));
            }));
            goto _done;
        }
    _done:
        _v.take();
    });
    return prism_rtl::finished(crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat(gens, "Result<", head, "> ", head, "::from_pod(const Pod& whole)"), body));
}


/// `Start FromPodDef, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_from_pod_def(crate::emit::cpp::Cp cp, crate::lower::model::TyDef t, Text head, Text gens) {
    return prism_rtl::make_rc<FromPodDef>(cp, t, head, gens);
}


/// PrismField: fn Text -> Text
Text prism_field(const Text& f) {
    return crate::syntax::lexer::chars::last_char(f) == Text::lit("_")
        ? crate::syntax::lexer::chars::before_last(f)
        : f;
}


/// IndentCpp: fn Text -> Text
Text indent_cpp(const Text& t) {
    return crate::syntax::lexer::chars::join(each(split(t, Text::lit("\n")), [&](const Text& l) { return l == Text::lit("") ? Text::lit("") : prism_rtl::cat("    ", l); }), Text::lit("\n"));
}


/// TagParts: unbounded fn Cp, TagDef -> Parts
Parts tag_parts(const crate::emit::cpp::Cp& cp, const crate::lower::model::TagDef& t) {
    auto fields = crate::syntax::lexer::chars::join(run_to_end(each_job(t.fields, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, Text, crate::lower::model::OutTy> p0) {
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=]() {
            return ({
                auto&& _f = p0;
                auto&& f = std::get<1>(_f);
                auto&& ft = std::get<2>(_f);
                call_then(crate::emit::cpp::start_cpp_type(cp_1_2, ft), [=](Text cpp_type_13848) { return prism_rtl::finished(prism_rtl::cat(cpp_type_13848, " ", crate::emit::cpp::field_id(f), ";")); });
            });
        }));
        });
    })));
    }))), Text::lit("\n"));
    auto pods = crate::syntax::lexer::chars::join(each(t.fields, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
        auto&& p_ = std::get<0>(_p0);
        auto&& f = std::get<1>(_p0);
        return prism_rtl::cat("{\"", p_, "\", prism_rtl::to_pod(", crate::emit::cpp::field_id(f), ")}");
    }), Text::lit(", "));
    auto reads = crate::syntax::lexer::chars::join(run_to_end(each_job(t.fields, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, Text, crate::lower::model::OutTy> p0) {
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=]() {
            return ({
                auto [p_, f, ft] = p0;
                call_then(crate::emit::cpp::start_cpp_type(cp_1_2, ft), [=](Text cpp_type_14088) { return prism_rtl::finished(prism_rtl::cat(".", crate::emit::cpp::field_id(f), " = TRY(prism_rtl::from_pod<", cpp_type_14088, ">(TRY(crate::prelude::field(p, \"", p_, "\"))))")); });
            });
        }));
        });
    })));
    }))), Text::lit(", "));
    auto eq = t.pod
        ? prism_rtl::cat("bool operator==(const ", t.name, "&) const = default;")
        : Text::lit("");
    auto back_ = t.pod
        ? prism_rtl::cat("static Result<", t.name, "> from_pod(const Pod& p);")
        : Text::lit("");
    auto decl = crate::emit::cpp::templates::items::cpp_tag_struct(cpp_source_doc(prism_rtl::cat("The `Level` of `", t.tag_name, "`:"), t.doc), t.name, fields, t.tag_name, crate::syntax::lexer::chars::join(filter(Array(std::vector{eq, back_}), [&](const Text& s) { return s != Text::lit(""); }), Text::lit("\n")));
    auto to_pod_1 = crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat("Pod ", t.name, "::to_pod() const"), prism_rtl::cat("return Pod::element(TAG, {", pods, "});"));
    auto show_ = crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat("void ", t.name, "::show(Printer& p) const"), Text::lit("prism_rtl::to_pod(*this).structure();\nShow<Pod>::show(prism_rtl::to_pod(*this), p);"));
    auto from_pod_2 = t.pod
        ? Array(std::vector{crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat("Result<", t.name, "> ", t.name, "::from_pod(const Pod& p)"), prism_rtl::cat("if (auto t = p.tag(); t && *t == TAG) return ", t.name, "{", reads, "};\nreturn mismatch<", t.name, ">(\"a ", t.tag_name, "\", p);"))})
        : Array<Text>{};
    auto deps = crate::emit::cpp::patterns::concat2(run_to_end(each_job(t.fields, ({
        auto cp_3 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Text, Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, Text, crate::lower::model::OutTy> p0) {
        return ({
            auto cp_3_4 = cp_3;
            entered(once_job([=]() {
            return ({
                auto&& _ft = p0;
                auto&& ft = std::get<2>(_ft);
                (prism_rtl::more(prism_rtl::rc(ValueDeps(cp_3_4, ft))));
            });
        }));
        });
    })));
    }))));
    return Parts{.forward = Array(std::vector{prism_rtl::cat("struct ", t.name, ";")}), .handles = Array<Text>{}, .values = Array(std::vector{ValueDecl{.path_ = prism_rtl::cat(cp.home, "::", t.name), .deps = deps, .text = decl}}), .cases_ = Array<Text>{}, .protos = Array<Text>{}, .classes = Array<Text>{}, .outer = Array<Text>{}, .generic = Array<Text>{}, .defs = append(Array(std::vector{to_pod_1, show_}), from_pod_2)};
}


prism_rtl::Turn<Parts> TagParts::cycle() const {
    const auto& cp = this->cp;
    const auto& t = this->t;
    auto cp_1 = cp;
    auto t_2 = t;
    return call_value(each_job(t_2.fields, ({
        auto cp_1_3 = cp_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, Text, crate::lower::model::OutTy> p0) {
        return ({
            auto cp_1_3_3 = cp_1_3;
            entered(once_job([=]() {
            return ({
                auto&& _f = p0;
                auto&& f = std::get<1>(_f);
                auto&& ft = std::get<2>(_f);
                call_then(crate::emit::cpp::start_cpp_type(cp_1_3_3, ft), [=](Text cpp_type_13848) { return prism_rtl::finished(prism_rtl::cat(cpp_type_13848, " ", crate::emit::cpp::field_id(f), ";")); });
            });
        }));
        });
    })));
    })), [=](Array<Text> each_13810) {
        return ({
            auto fields = crate::syntax::lexer::chars::join(each_13810, Text::lit("\n"));
            auto pods = crate::syntax::lexer::chars::join(each(t_2.fields, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
                auto&& p_ = std::get<0>(_p0);
                auto&& f = std::get<1>(_p0);
                return prism_rtl::cat("{\"", p_, "\", prism_rtl::to_pod(", crate::emit::cpp::field_id(f), ")}");
            }), Text::lit(", "));
            call_value(each_job(t_2.fields, ({
            auto cp_1_3 = cp_1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, Text, crate::lower::model::OutTy> p0) {
            return ({
                auto cp_1_3_3 = cp_1_3;
                entered(once_job([=]() {
                return ({
                    auto [p_, f, ft] = p0;
                    call_then(crate::emit::cpp::start_cpp_type(cp_1_3_3, ft), [=](Text cpp_type_14088) { return prism_rtl::finished(prism_rtl::cat(".", crate::emit::cpp::field_id(f), " = TRY(prism_rtl::from_pod<", cpp_type_14088, ">(TRY(crate::prelude::field(p, \"", p_, "\"))))")); });
                });
            }));
            });
        })));
        })), [=](Array<Text> each_14016) {
            return ({
                auto reads = crate::syntax::lexer::chars::join(each_14016, Text::lit(", "));
                auto eq = t_2.pod
                    ? prism_rtl::cat("bool operator==(const ", t_2.name, "&) const = default;")
                    : Text::lit("");
                auto back_ = t_2.pod
                    ? prism_rtl::cat("static Result<", t_2.name, "> from_pod(const Pod& p);")
                    : Text::lit("");
                auto decl = crate::emit::cpp::templates::items::cpp_tag_struct(cpp_source_doc(prism_rtl::cat("The `Level` of `", t_2.tag_name, "`:"), t_2.doc), t_2.name, fields, t_2.tag_name, crate::syntax::lexer::chars::join(filter(Array(std::vector{eq, back_}), [&](const Text& s) { return s != Text::lit(""); }), Text::lit("\n")));
                auto to_pod_3 = crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat("Pod ", t_2.name, "::to_pod() const"), prism_rtl::cat("return Pod::element(TAG, {", pods, "});"));
                auto show_ = crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat("void ", t_2.name, "::show(Printer& p) const"), Text::lit("prism_rtl::to_pod(*this).structure();\nShow<Pod>::show(prism_rtl::to_pod(*this), p);"));
                auto from_pod_4 = t_2.pod
                    ? Array(std::vector{crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat("Result<", t_2.name, "> ", t_2.name, "::from_pod(const Pod& p)"), prism_rtl::cat("if (auto t = p.tag(); t && *t == TAG) return ", t_2.name, "{", reads, "};\nreturn mismatch<", t_2.name, ">(\"a ", t_2.tag_name, "\", p);"))})
                    : Array<Text>{};
                call_value(each_job(t_2.fields, ({
                auto cp_1_5 = cp_1;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Text, Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, Text, crate::lower::model::OutTy> p0) {
                return ({
                    auto cp_1_5_5 = cp_1_5;
                    entered(once_job([=]() {
                    return ({
                        auto&& _ft = p0;
                        auto&& ft = std::get<2>(_ft);
                        (prism_rtl::more(prism_rtl::rc(ValueDeps(cp_1_5_5, ft))));
                    });
                }));
                });
            })));
            })), [=](Array<Array<Text>> each_15000) {
                return ({
                    auto deps = crate::emit::cpp::patterns::concat2(each_15000);
                    (prism_rtl::finished(Parts{.forward = Array(std::vector{prism_rtl::cat("struct ", t_2.name, ";")}), .handles = Array<Text>{}, .values = Array(std::vector{ValueDecl{.path_ = prism_rtl::cat(cp_1.home, "::", t_2.name), .deps = deps, .text = decl}}), .cases_ = Array<Text>{}, .protos = Array<Text>{}, .classes = Array<Text>{}, .outer = Array<Text>{}, .generic = Array<Text>{}, .defs = append(Array(std::vector{to_pod_3, show_}), from_pod_4)}));
                });
            });
            });
        });
        });
    });
}


/// `Start TagParts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Parts> start_tag_parts(crate::emit::cpp::Cp cp, crate::lower::model::TagDef t) {
    return prism_rtl::make_rc<TagParts>(cp, t);
}


/// RowParts: unbounded fn Cp, Text, RowDef -> Parts
Parts row_parts(const crate::emit::cpp::Cp& cp, const Text& m, const crate::lower::model::RowDef& r) {
    auto names = each(r.cases_, [&](const std::tuple<Text, Text>& _p0) {
        auto&& v_ = std::get<0>(_p0);
        return v_;
    });
    auto pod = prism_rtl::cat("Pod to_pod() const;\nvoid show(Printer& p) const;", r.pod
        ? prism_rtl::cat("\nstatic Result<", r.name, "> from_pod(const Pod& p);")
        : Text::lit(""));
    auto handle = crate::emit::cpp::templates::items::choice_handle(cpp_source_doc(prism_rtl::cat("`", r.prism, "`, a row kind's values:"), r.doc), Text::lit(""), r.name, crate::syntax::lexer::chars::join(each(names, [&](const Text& n) { return prism_rtl::cat("struct ", n, ";"); }), Text::lit("\n")), crate::syntax::lexer::chars::join(names, Text::lit(", ")), pod);
    auto cases = each(r.cases_, [&](const std::tuple<Text, Text>& _p0) {
        auto&& v_ = std::get<0>(_p0);
        auto&& st = std::get<1>(_p0);
        return crate::emit::cpp::templates::items::case_decl(Text::lit(""), prism_rtl::cat(r.name, "::", v_), prism_rtl::cat(row_struct(m, st), " a0;", r.pod
            ? prism_rtl::cat("\nbool operator==(const ", v_, "&) const = default;")
            : Text::lit("")));
    });
    auto eq = r.pod
        ? Array(std::vector{prism_rtl::cat("inline bool operator==(const ", r.name, "& a, const ", r.name, "& b) { return a.cases() == b.cases(); }")})
        : Array<Text>{};
    auto to_pod_1 = crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat("Pod ", r.name, "::to_pod() const"), Text::lit("return std::visit([](const auto& c) { return prism_rtl::to_pod(c.a0); }, cases());"));
    auto show_ = crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat("void ", r.name, "::show(Printer& p) const"), Text::lit("Show<Pod>::show(to_pod(), p);"));
    auto reads = crate::syntax::lexer::chars::join(each(r.cases_, [&](const std::tuple<Text, Text>& _p0) {
        auto&& v_ = std::get<0>(_p0);
        auto&& st = std::get<1>(_p0);
        return prism_rtl::cat("if (*t == ", row_struct(m, st), "::TAG) return ", r.name, "(", v_, "{TRY(prism_rtl::from_pod<", row_struct(m, st), ">(p))});");
    }), Text::lit("\n"));
    auto from_pod_2 = r.pod
        ? Array(std::vector{crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat("Result<", r.name, "> ", r.name, "::from_pod(const Pod& p)"), prism_rtl::cat("if (auto t = p.tag()) {\n", indent_cpp(reads), "\n}\nreturn mismatch<", r.name, ">(\"a ", r.name, "\", p);"))})
        : Array<Text>{};
    return Parts{.forward = Array(std::vector{prism_rtl::cat("class ", r.name, ";")}), .handles = Array(std::vector{handle}), .values = Array<ValueDecl>{}, .cases_ = append(crate::prelude::push(cases, cases_accessor(Text::lit(""), r.name)), eq), .protos = Array<Text>{}, .classes = Array<Text>{}, .outer = Array<Text>{}, .generic = Array<Text>{}, .defs = append(Array(std::vector{to_pod_1, show_}), from_pod_2)};
}


prism_rtl::Turn<Parts> RowParts::cycle() const {
    const auto& cp = this->cp;
    const auto& m = this->m;
    const auto& r = this->r;
    auto names = each(r.cases_, [&](const std::tuple<Text, Text>& _p0) {
        auto&& v_ = std::get<0>(_p0);
        return v_;
    });
    auto pod = prism_rtl::cat("Pod to_pod() const;\nvoid show(Printer& p) const;", r.pod
        ? prism_rtl::cat("\nstatic Result<", r.name, "> from_pod(const Pod& p);")
        : Text::lit(""));
    auto handle = crate::emit::cpp::templates::items::choice_handle(cpp_source_doc(prism_rtl::cat("`", r.prism, "`, a row kind's values:"), r.doc), Text::lit(""), r.name, crate::syntax::lexer::chars::join(each(names, [&](const Text& n) { return prism_rtl::cat("struct ", n, ";"); }), Text::lit("\n")), crate::syntax::lexer::chars::join(names, Text::lit(", ")), pod);
    auto cases = each(r.cases_, [&](const std::tuple<Text, Text>& _p0) {
        auto&& v_ = std::get<0>(_p0);
        auto&& st = std::get<1>(_p0);
        return crate::emit::cpp::templates::items::case_decl(Text::lit(""), prism_rtl::cat(r.name, "::", v_), prism_rtl::cat(row_struct(m, st), " a0;", r.pod
            ? prism_rtl::cat("\nbool operator==(const ", v_, "&) const = default;")
            : Text::lit("")));
    });
    auto eq = r.pod
        ? Array(std::vector{prism_rtl::cat("inline bool operator==(const ", r.name, "& a, const ", r.name, "& b) { return a.cases() == b.cases(); }")})
        : Array<Text>{};
    auto to_pod_1 = crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat("Pod ", r.name, "::to_pod() const"), Text::lit("return std::visit([](const auto& c) { return prism_rtl::to_pod(c.a0); }, cases());"));
    auto show_ = crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat("void ", r.name, "::show(Printer& p) const"), Text::lit("Show<Pod>::show(to_pod(), p);"));
    auto reads = crate::syntax::lexer::chars::join(each(r.cases_, [&](const std::tuple<Text, Text>& _p0) {
        auto&& v_ = std::get<0>(_p0);
        auto&& st = std::get<1>(_p0);
        return prism_rtl::cat("if (*t == ", row_struct(m, st), "::TAG) return ", r.name, "(", v_, "{TRY(prism_rtl::from_pod<", row_struct(m, st), ">(p))});");
    }), Text::lit("\n"));
    auto from_pod_2 = r.pod
        ? Array(std::vector{crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat("Result<", r.name, "> ", r.name, "::from_pod(const Pod& p)"), prism_rtl::cat("if (auto t = p.tag()) {\n", indent_cpp(reads), "\n}\nreturn mismatch<", r.name, ">(\"a ", r.name, "\", p);"))})
        : Array<Text>{};
    return prism_rtl::finished(Parts{.forward = Array(std::vector{prism_rtl::cat("class ", r.name, ";")}), .handles = Array(std::vector{handle}), .values = Array<ValueDecl>{}, .cases_ = append(crate::prelude::push(cases, cases_accessor(Text::lit(""), r.name)), eq), .protos = Array<Text>{}, .classes = Array<Text>{}, .outer = Array<Text>{}, .generic = Array<Text>{}, .defs = append(Array(std::vector{to_pod_1, show_}), from_pod_2)});
}


/// `Start RowParts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Parts> start_row_parts(crate::emit::cpp::Cp cp, Text m, crate::lower::model::RowDef r) {
    return prism_rtl::make_rc<RowParts>(cp, m, r);
}


/// RowStruct: fn Text, Text -> Text
Text row_struct(const Text& m, const Text& st) {
    return crate::syntax::lexer::chars::contains(st, Text::lit(":")) || (m == Text::lit(""))
        ? crate::emit::cpp::type_path(st)
        : prism_rtl::cat("crate::", m, "::", st);
}


/// AnswerParts: unbounded fn Cp, AnswerDef -> Parts
Parts answer_parts(const crate::emit::cpp::Cp& cp, const crate::lower::model::AnswerDef& a) {
    auto names = each(a.cases_, [&](const crate::lower::model::AnswerCase& c) { return c.variant; });
    auto accessors = crate::syntax::lexer::chars::join(run_to_end(each_job(a.cases_, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::AnswerCase)>>(prism_rtl::rc([=](crate::lower::model::AnswerCase p0) {
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=]() {
            return ({
                auto c = p0;
                call_then(crate::emit::cpp::start_cpp_type(cp_1_2, c.ty), [=](Text cpp_type_17537) { return prism_rtl::finished(prism_rtl::cat("Result<", cpp_type_17537, "> ", c.accessor, "() const;")); });
            });
        }));
        });
    })));
    }))), Text::lit("\n"));
    auto members_ = prism_rtl::cat("const char* tag() const;\n", accessors, "\nstatic Result<Answer> decode(const Elem& e, const Pod& v);");
    auto handle = crate::emit::cpp::templates::items::choice_handle(cpp_doc(Text::lit("`Answer c`: an answer to an element, typed by its tag (Semantics ch. 9): what a host's\nsupplier answers a child place with, and what a World's answer to a forwarded element\ndecodes to, carrying the tag's output.")), Text::lit(""), Text::lit("Answer"), crate::syntax::lexer::chars::join(each(names, [&](const Text& n) { return prism_rtl::cat("struct ", n, ";"); }), Text::lit("\n")), crate::syntax::lexer::chars::join(names, Text::lit(", ")), members_);
    auto cases = run_to_end(each_job(a.cases_, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::AnswerCase)>>(prism_rtl::rc([=](crate::lower::model::AnswerCase p0) {
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=]() {
            return ({
                auto c = p0;
                call_then(crate::emit::cpp::start_cpp_type(cp_1_2, c.ty), [=](Text cpp_type_18122) { return prism_rtl::finished(crate::emit::cpp::templates::items::case_decl(Text::lit(""), prism_rtl::cat("Answer::", c.variant), prism_rtl::cat(cpp_type_18122, " a0;"))); });
            });
        }));
        });
    })));
    })));
    auto tags = crate::syntax::lexer::chars::join(each(a.cases_, [&](const crate::lower::model::AnswerCase& c) { return prism_rtl::cat("if (std::holds_alternative<", c.variant, ">(cases())) return ", crate::emit::cpp::type_path(c.struct_path), "::TAG;"); }), Text::lit("\n"));
    auto tag_fn = crate::emit::cpp::templates::items::cpp_function(Text::lit(""), Text::lit("const char* Answer::tag() const"), prism_rtl::cat(tags, "\nprism_rtl::unreachable();"));
    auto getters = run_to_end(each_job(a.cases_, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::AnswerCase)>>(prism_rtl::rc([=](crate::lower::model::AnswerCase p0) {
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=]() {
            return ({
                auto c = p0;
                call_then(crate::emit::cpp::start_cpp_type(cp_1_2, c.ty), [=](Text cpp_type_18480) { return prism_rtl::finished(crate::emit::cpp::templates::items::cpp_function(cpp_doc(prism_rtl::cat("A `", c.tag_name, "`'s answer.")), prism_rtl::cat("Result<", cpp_type_18480, "> Answer::", c.accessor, "() const"), prism_rtl::cat("if (auto c = std::get_if<", c.variant, ">(&cases())) return c->a0;\nreturn unexpected(Fault::answer(str(\"an answer for \", tag(), \", where ", c.tag_name, "'s was expected\")));"))); });
            });
        }));
        });
    })));
    })));
    auto decodes = crate::syntax::lexer::chars::join(run_to_end(each_job(a.cases_, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::AnswerCase)>>(prism_rtl::rc([=](crate::lower::model::AnswerCase p0) {
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=]() {
            return ({
                auto c = p0;
                call_then(crate::emit::cpp::start_cpp_type(cp_1_2, c.ty), [=](Text cpp_type_18828) { return prism_rtl::finished(prism_rtl::cat("if (is<Elem::", c.variant, ">(e)) return Answer(", c.variant, "{TRY(prism_rtl::from_pod<", cpp_type_18828, ">(v))});")); });
            });
        }));
        });
    })));
    }))), Text::lit("\n"));
    auto decode_1 = crate::emit::cpp::templates::items::cpp_function(cpp_doc(Text::lit("A World's answer to the element `e`, decoded by its tag.")), Text::lit("Result<Answer> Answer::decode(const Elem& e, const Pod& v)"), prism_rtl::cat(decodes, "\nprism_rtl::unreachable();"));
    return Parts{.forward = Array(std::vector{Text::lit("class Answer;")}), .handles = Array(std::vector{handle}), .values = Array<ValueDecl>{}, .cases_ = crate::prelude::push(cases, cases_accessor(Text::lit(""), Text::lit("Answer"))), .protos = Array<Text>{}, .classes = Array<Text>{}, .outer = Array<Text>{}, .generic = Array<Text>{}, .defs = append(Array(std::vector{tag_fn}), crate::prelude::push(getters, decode_1))};
}


prism_rtl::Turn<Parts> AnswerParts::cycle() const {
    const auto& cp = this->cp;
    const auto& a = this->a;
    auto names = each(a.cases_, [&](const crate::lower::model::AnswerCase& c) { return c.variant; });
    auto a_1 = a;
    auto cp_2 = cp;
    return call_value(each_job(a_1.cases_, ({
        auto cp_2_3 = cp_2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::AnswerCase)>>(prism_rtl::rc([=](crate::lower::model::AnswerCase p0) {
        return ({
            auto cp_2_3_3 = cp_2_3;
            entered(once_job([=]() {
            return ({
                auto c = p0;
                call_then(crate::emit::cpp::start_cpp_type(cp_2_3_3, c.ty), [=](Text cpp_type_17537) { return prism_rtl::finished(prism_rtl::cat("Result<", cpp_type_17537, "> ", c.accessor, "() const;")); });
            });
        }));
        });
    })));
    })), [=](Array<Text> each_17509) {
        return ({
            auto accessors = crate::syntax::lexer::chars::join(each_17509, Text::lit("\n"));
            auto members_ = prism_rtl::cat("const char* tag() const;\n", accessors, "\nstatic Result<Answer> decode(const Elem& e, const Pod& v);");
            auto handle = crate::emit::cpp::templates::items::choice_handle(cpp_doc(Text::lit("`Answer c`: an answer to an element, typed by its tag (Semantics ch. 9): what a host's\nsupplier answers a child place with, and what a World's answer to a forwarded element\ndecodes to, carrying the tag's output.")), Text::lit(""), Text::lit("Answer"), crate::syntax::lexer::chars::join(each(names, [&](const Text& n) { return prism_rtl::cat("struct ", n, ";"); }), Text::lit("\n")), crate::syntax::lexer::chars::join(names, Text::lit(", ")), members_);
            call_value(each_job(a_1.cases_, ({
            auto cp_2_3 = cp_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::AnswerCase)>>(prism_rtl::rc([=](crate::lower::model::AnswerCase p0) {
            return ({
                auto cp_2_3_3 = cp_2_3;
                entered(once_job([=]() {
                return ({
                    auto c = p0;
                    call_then(crate::emit::cpp::start_cpp_type(cp_2_3_3, c.ty), [=](Text cpp_type_18122) { return prism_rtl::finished(crate::emit::cpp::templates::items::case_decl(Text::lit(""), prism_rtl::cat("Answer::", c.variant), prism_rtl::cat(cpp_type_18122, " a0;"))); });
                });
            }));
            });
        })));
        })), [=](Array<Text> each_18065) {
            return ({
                auto cases = each_18065;
                auto tags = crate::syntax::lexer::chars::join(each(a_1.cases_, [&](const crate::lower::model::AnswerCase& c) { return prism_rtl::cat("if (std::holds_alternative<", c.variant, ">(cases())) return ", crate::emit::cpp::type_path(c.struct_path), "::TAG;"); }), Text::lit("\n"));
                auto tag_fn = crate::emit::cpp::templates::items::cpp_function(Text::lit(""), Text::lit("const char* Answer::tag() const"), prism_rtl::cat(tags, "\nprism_rtl::unreachable();"));
                call_value(each_job(a_1.cases_, ({
                auto cp_2_3 = cp_2;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::AnswerCase)>>(prism_rtl::rc([=](crate::lower::model::AnswerCase p0) {
                return ({
                    auto cp_2_3_3 = cp_2_3;
                    entered(once_job([=]() {
                    return ({
                        auto c = p0;
                        call_then(crate::emit::cpp::start_cpp_type(cp_2_3_3, c.ty), [=](Text cpp_type_18480) { return prism_rtl::finished(crate::emit::cpp::templates::items::cpp_function(cpp_doc(prism_rtl::cat("A `", c.tag_name, "`'s answer.")), prism_rtl::cat("Result<", cpp_type_18480, "> Answer::", c.accessor, "() const"), prism_rtl::cat("if (auto c = std::get_if<", c.variant, ">(&cases())) return c->a0;\nreturn unexpected(Fault::answer(str(\"an answer for \", tag(), \", where ", c.tag_name, "'s was expected\")));"))); });
                    });
                }));
                });
            })));
            })), [=](Array<Text> each_18402) {
                return ({
                    auto getters = each_18402;
                    call_value(each_job(a_1.cases_, ({
                    auto cp_2_3 = cp_2;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::AnswerCase)>>(prism_rtl::rc([=](crate::lower::model::AnswerCase p0) {
                    return ({
                        auto cp_2_3_3 = cp_2_3;
                        entered(once_job([=]() {
                        return ({
                            auto c = p0;
                            call_then(crate::emit::cpp::start_cpp_type(cp_2_3_3, c.ty), [=](Text cpp_type_18828) { return prism_rtl::finished(prism_rtl::cat("if (is<Elem::", c.variant, ">(e)) return Answer(", c.variant, "{TRY(prism_rtl::from_pod<", cpp_type_18828, ">(v))});")); });
                        });
                    }));
                    });
                })));
                })), [=](Array<Text> each_18726) {
                    return ({
                        auto decodes = crate::syntax::lexer::chars::join(each_18726, Text::lit("\n"));
                        auto decode_3 = crate::emit::cpp::templates::items::cpp_function(cpp_doc(Text::lit("A World's answer to the element `e`, decoded by its tag.")), Text::lit("Result<Answer> Answer::decode(const Elem& e, const Pod& v)"), prism_rtl::cat(decodes, "\nprism_rtl::unreachable();"));
                        (prism_rtl::finished(Parts{.forward = Array(std::vector{Text::lit("class Answer;")}), .handles = Array(std::vector{handle}), .values = Array<ValueDecl>{}, .cases_ = crate::prelude::push(cases, cases_accessor(Text::lit(""), Text::lit("Answer"))), .protos = Array<Text>{}, .classes = Array<Text>{}, .outer = Array<Text>{}, .generic = Array<Text>{}, .defs = append(Array(std::vector{tag_fn}), crate::prelude::push(getters, decode_3))}));
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start AnswerParts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Parts> start_answer_parts(crate::emit::cpp::Cp cp, crate::lower::model::AnswerDef a) {
    return prism_rtl::make_rc<AnswerParts>(cp, a);
}


/// JobParts: unbounded fn Cp, JobDef -> Parts
Parts job_parts(const crate::emit::cpp::Cp& cp, const crate::lower::model::JobDef& j) {
    auto gens = cpp_template_head(generic_names_of(j.generics));
    auto head = head_of(j.name, generic_names_of(j.generics));
    auto jcp = crate::emit::cpp::with_fields(cp, j.fields);
    auto fields = crate::syntax::lexer::chars::join(run_to_end(each_job(j.fields, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=]() {
            return ({
                auto [n, t] = p0;
                call_then(crate::emit::cpp::start_cpp_type(cp_1_2, t), [=](Text cpp_type_19619) { return prism_rtl::finished(prism_rtl::cat(cpp_type_19619, " ", crate::emit::cpp::field_id(n), ";")); });
            });
        }));
        });
    })));
    }))), Text::lit("\n"));
    auto params = crate::syntax::lexer::chars::join(run_to_end(each_job(j.fields, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=]() {
            return ({
                auto [n, t] = p0;
                call_then(crate::emit::cpp::start_cpp_type(cp_1_2, t), [=](Text cpp_type_19707) { return prism_rtl::finished(prism_rtl::cat(cpp_type_19707, " ", crate::emit::cpp::field_id(n))); });
            });
        }));
        });
    })));
    }))), Text::lit(", "));
    auto inits = crate::syntax::lexer::chars::join(each(j.fields, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
        auto&& n = std::get<0>(_p0);
        return prism_rtl::cat(crate::emit::cpp::field_id(n), "(std::move(", crate::emit::cpp::field_id(n), "))");
    }), Text::lit(", "));
    auto ctor = len(j.fields) == Nat(0u)
        ? Text::lit("")
        : prism_rtl::cat(j.name, "(", params, ") : ", inits, " {}");
    auto ret = crate::emit::cpp::cpp_type(cp, j.ret);
    auto decl = crate::emit::cpp::templates::items::job_struct(cpp_doc(j.doc), gens, j.name, ret, fields, ctor);
    auto cycle_1 = crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat(gens, "prism_rtl::Turn<", ret, "> ", head, "::cycle() const"), crate::emit::cpp::stmts::cpp_body(jcp, j.body));
    auto start = crate::emit::cpp::templates::items::cpp_function(cpp_doc(prism_rtl::cat("`Start ", j.name, ", x`: what the function value is when passed to `@Run`.")), prism_rtl::cat(gens, "prism_rtl::JobRef<", ret, "> ", j.start, "(", params, ")"), prism_rtl::cat("return prism_rtl::make_rc<", head, ">(", crate::syntax::lexer::chars::join(each(j.fields, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
        auto&& n = std::get<0>(_p0);
        return crate::emit::cpp::field_id(n);
    }), Text::lit(", ")), ");"));
    auto generic = len(j.generics) > Nat(0u);
    return Parts{.forward = Array(std::vector{prism_rtl::cat(gens, "struct ", j.name, ";")}), .handles = Array<Text>{}, .values = Array<ValueDecl>{}, .cases_ = Array<Text>{}, .protos = Array(std::vector{prism_rtl::cat(gens, "prism_rtl::JobRef<", ret, "> ", j.start, "(", params, ");")}), .classes = Array(std::vector{decl}), .outer = Array<Text>{}, .generic = generic ? Array(std::vector{cycle_1, start}) : Array<Text>{}, .defs = generic ? Array<Text>{} : Array(std::vector{cycle_1, start})};
}


prism_rtl::Turn<Parts> JobParts::cycle() const {
    const auto& cp = this->cp;
    const auto& j = this->j;
    auto gens = cpp_template_head(generic_names_of(j.generics));
    auto head = head_of(j.name, generic_names_of(j.generics));
    auto jcp = crate::emit::cpp::with_fields(cp, j.fields);
    auto cp_1 = cp;
    auto j_2 = j;
    return call_value(each_job(j_2.fields, ({
        auto cp_1_3 = cp_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
        return ({
            auto cp_1_3_3 = cp_1_3;
            entered(once_job([=]() {
            return ({
                auto [n, t] = p0;
                call_then(crate::emit::cpp::start_cpp_type(cp_1_3_3, t), [=](Text cpp_type_19619) { return prism_rtl::finished(prism_rtl::cat(cpp_type_19619, " ", crate::emit::cpp::field_id(n), ";")); });
            });
        }));
        });
    })));
    })), [=](Array<Text> each_19590) {
        return ({
            auto fields = crate::syntax::lexer::chars::join(each_19590, Text::lit("\n"));
            call_value(each_job(j_2.fields, ({
            auto cp_1_3 = cp_1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
            return ({
                auto cp_1_3_3 = cp_1_3;
                entered(once_job([=]() {
                return ({
                    auto [n, t] = p0;
                    call_then(crate::emit::cpp::start_cpp_type(cp_1_3_3, t), [=](Text cpp_type_19707) { return prism_rtl::finished(prism_rtl::cat(cpp_type_19707, " ", crate::emit::cpp::field_id(n))); });
                });
            }));
            });
        })));
        })), [=](Array<Text> each_19678) {
            return ({
                auto params = crate::syntax::lexer::chars::join(each_19678, Text::lit(", "));
                auto inits = crate::syntax::lexer::chars::join(each(j_2.fields, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
                    auto&& n = std::get<0>(_p0);
                    return prism_rtl::cat(crate::emit::cpp::field_id(n), "(std::move(", crate::emit::cpp::field_id(n), "))");
                }), Text::lit(", "));
                auto ctor = len(j_2.fields) == Nat(0u)
                    ? Text::lit("")
                    : prism_rtl::cat(j_2.name, "(", params, ") : ", inits, " {}");
                call_then(crate::emit::cpp::start_cpp_type(cp_1, j_2.ret), [=](Text cpp_type_19939) {
                return ({
                    auto ret = cpp_type_19939;
                    auto decl = crate::emit::cpp::templates::items::job_struct(cpp_doc(j_2.doc), gens, j_2.name, ret, fields, ctor);
                    call_then(crate::emit::cpp::stmts::start_cpp_body(jcp, j_2.body), [=](Text cpp_body_20117) {
                    return ({
                        auto cycle_3 = crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat(gens, "prism_rtl::Turn<", ret, "> ", head, "::cycle() const"), cpp_body_20117);
                        auto start = crate::emit::cpp::templates::items::cpp_function(cpp_doc(prism_rtl::cat("`Start ", j_2.name, ", x`: what the function value is when passed to `@Run`.")), prism_rtl::cat(gens, "prism_rtl::JobRef<", ret, "> ", j_2.start, "(", params, ")"), prism_rtl::cat("return prism_rtl::make_rc<", head, ">(", crate::syntax::lexer::chars::join(each(j_2.fields, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
                            auto&& n = std::get<0>(_p0);
                            return crate::emit::cpp::field_id(n);
                        }), Text::lit(", ")), ");"));
                        auto generic = len(j_2.generics) > Nat(0u);
                        (prism_rtl::finished(Parts{.forward = Array(std::vector{prism_rtl::cat(gens, "struct ", j_2.name, ";")}), .handles = Array<Text>{}, .values = Array<ValueDecl>{}, .cases_ = Array<Text>{}, .protos = Array(std::vector{prism_rtl::cat(gens, "prism_rtl::JobRef<", ret, "> ", j_2.start, "(", params, ");")}), .classes = Array(std::vector{decl}), .outer = Array<Text>{}, .generic = generic ? Array(std::vector{cycle_3, start}) : Array<Text>{}, .defs = generic ? Array<Text>{} : Array(std::vector{cycle_3, start})}));
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start JobParts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Parts> start_job_parts(crate::emit::cpp::Cp cp, crate::lower::model::JobDef j) {
    return prism_rtl::make_rc<JobParts>(cp, j);
}


/// TraitParts: unbounded fn Cp, TraitDef -> Parts
Parts trait_parts(const crate::emit::cpp::Cp& cp, const crate::lower::model::TraitDef& t) {
    auto defaults = filter(t.methods, [&](const crate::lower::model::FnDef& f) { return f.public_; });
    auto defs = run_to_end(each_job(defaults, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::FnDef)>>(prism_rtl::rc([=](crate::lower::model::FnDef p0) {
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=]() {
            return ({
                auto f = p0;
                (prism_rtl::more(prism_rtl::rc(FnDefinition(cp_1_2, with_generics(f, Array(std::vector{std::tuple{Text::lit("Self"), Array<Text>{}}}))))));
            });
        }));
        });
    })));
    })));
    auto protos = run_to_end(each_job(t.methods, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::FnDef)>>(prism_rtl::rc([=](crate::lower::model::FnDef p0) {
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=]() {
            return ({
                auto f = p0;
                call_then(start_fn_signature(cp_1_2, with_generics(f, Array(std::vector{std::tuple{Text::lit("Self"), Array<Text>{}}}))), [=](Text fn_signature_21383) { return prism_rtl::finished(prism_rtl::cat(fn_signature_21383, f.public_ ? Text::lit("") : Text::lit(" = delete"), ";")); });
            });
        }));
        });
    })));
    })));
    auto generic = len(defaults) == Nat(0u)
        ? Array<Text>{}
        : Array(std::vector{crate::emit::cpp::templates::items::trait_namespace(t.name, crate::syntax::lexer::chars::join(defs, Text::lit("\n")))});
    Parts this_ = generic_only(generic);
    this_.protos = Array(std::vector{crate::emit::cpp::templates::items::trait_namespace(t.name, crate::syntax::lexer::chars::join(protos, Text::lit("\n")))});
    return this_;
}


prism_rtl::Turn<Parts> TraitParts::cycle() const {
    const auto& cp = this->cp;
    const auto& t = this->t;
    auto defaults = filter(t.methods, [&](const crate::lower::model::FnDef& f) { return f.public_; });
    auto cp_1 = cp;
    auto t_2 = t;
    return call_value(each_job(defaults, ({
        auto cp_1_3 = cp_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::FnDef)>>(prism_rtl::rc([=](crate::lower::model::FnDef p0) {
        return ({
            auto cp_1_3_3 = cp_1_3;
            entered(once_job([=]() {
            return ({
                auto f = p0;
                (prism_rtl::more(prism_rtl::rc(FnDefinition(cp_1_3_3, with_generics(f, Array(std::vector{std::tuple{Text::lit("Self"), Array<Text>{}}}))))));
            });
        }));
        });
    })));
    })), [=](Array<Text> each_21267) {
        return ({
            auto defs = each_21267;
            call_value(each_job(t_2.methods, ({
            auto cp_1_3 = cp_1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::FnDef)>>(prism_rtl::rc([=](crate::lower::model::FnDef p0) {
            return ({
                auto cp_1_3_3 = cp_1_3;
                entered(once_job([=]() {
                return ({
                    auto f = p0;
                    call_then(start_fn_signature(cp_1_3_3, with_generics(f, Array(std::vector{std::tuple{Text::lit("Self"), Array<Text>{}}}))), [=](Text fn_signature_21383) { return prism_rtl::finished(prism_rtl::cat(fn_signature_21383, f.public_ ? Text::lit("") : Text::lit(" = delete"), ";")); });
                });
            }));
            });
        })));
        })), [=](Array<Text> each_21360) {
            return ({
                auto protos = each_21360;
                auto generic = len(defaults) == Nat(0u)
                    ? Array<Text>{}
                    : Array(std::vector{crate::emit::cpp::templates::items::trait_namespace(t_2.name, crate::syntax::lexer::chars::join(defs, Text::lit("\n")))});
                (prism_rtl::finished(({
                Parts this_ = generic_only(generic);
                this_.protos = Array(std::vector{crate::emit::cpp::templates::items::trait_namespace(t_2.name, crate::syntax::lexer::chars::join(protos, Text::lit("\n")))});
                this_;
            })));
            });
        });
        });
    });
}


/// `Start TraitParts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Parts> start_trait_parts(crate::emit::cpp::Cp cp, crate::lower::model::TraitDef t) {
    return prism_rtl::make_rc<TraitParts>(cp, t);
}


/// ImplParts: unbounded fn Cp, ImplDef -> Parts
Parts impl_parts(const crate::emit::cpp::Cp& cp, const crate::lower::model::ImplDef& i) {
    auto head = crate::emit::cpp::cpp_type(cp, i.head);
    auto gens = cpp_template_head(generic_names_of(i.generics));
    auto fns = run_to_end(each_job(i.methods, ({
        auto cp_1 = cp;
        auto i_2 = i;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Parts>(crate::lower::model::FnDef)>>(prism_rtl::rc([=](crate::lower::model::FnDef p0) {
        return ({
            auto cp_1_3 = cp_1;
            auto i_2_3 = i_2;
            entered(once_job([=]() {
            return ({
                auto f = p0;
                (prism_rtl::more(prism_rtl::rc(FnParts(cp_1_3, with_generics(f, i_2_3.generics)))));
            });
        }));
        });
    })));
    })));
    auto own = fold(fns, no_parts(), [&](const Parts& acc, const Parts& p_) { return join_parts(acc, p_); });
    auto&& _m = i.cls;
    {
        auto&& m22370_0 = _m;
        if (m22370_0 == Text::lit("Prelude.Show")) {
            auto shown = or_(index(each(i.methods, [&](const crate::lower::model::FnDef& f) { return f.name; }), Nat(0u)), Text::lit("show"));
            return join_parts(own, protos_defs(Array<Text>{}, Array(std::vector{crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat(gens, "void ", head, "::show(Printer& p) const"), prism_rtl::cat("p.raw(", shown, "(*this).to_string());"))})));
        }
    }
    {
        auto&& m22370_1 = _m;
        if (m22370_1 == Text::lit("Prelude.Eq")) {
            auto eq = fold(i.methods, Text::lit(""), [&](const Text& acc, const crate::lower::model::FnDef& f) {
                return (!crate::syntax::lexer::chars::has_prefix(f.name, Text::lit("ne"))) && (acc == Text::lit(""))
                    ? f.name
                    : acc;
            });
            return join_parts(own, protos_defs(Array(std::vector{prism_rtl::cat(gens, "bool operator==(const ", head, "& a, const ", head, "& b);")}), Array(std::vector{crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat(gens, "bool operator==(const ", head, "& a, const ", head, "& b)"), prism_rtl::cat("return ", eq, "(a, b);"))})));
        }
    }
    {
        auto tr = crate::syntax::lexer::chars::drop_prefix(crate::emit::cpp::type_path(i.tr), Text::lit("crate::"));
        auto own = !crate::syntax::lexer::chars::contains(tr, Text::lit("::"));
        auto ns = own
            ? tr
            : prism_rtl::cat("impl_", crate::syntax::lexer::chars::join(split(tr, Text::lit("::")), Text::lit("_")));
        auto in_trait = run_to_end(each_job(i.methods, ({
            auto ns_1 = ns;
            auto cp_2 = cp;
            auto i_3 = i;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::FnDef)>>(prism_rtl::rc([=](crate::lower::model::FnDef p0) {
            return ({
                auto ns_1_4 = ns_1;
                auto cp_2_4 = cp_2;
                auto i_3_4 = i_3;
                entered(once_job([=]() {
                return ({
                    auto f = p0;
                    call_then(start_fn_definition(cp_2_4, with_generics(f, i_3_4.generics)), [=](Text fn_definition_23235) { return prism_rtl::finished(crate::emit::cpp::templates::items::trait_namespace(ns_1_4, fn_definition_23235)); });
                });
            }));
            });
        })));
        })));
        auto protos = run_to_end(each_job(i.methods, ({
            auto ns_1 = ns;
            auto cp_2 = cp;
            auto i_3 = i;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::FnDef)>>(prism_rtl::rc([=](crate::lower::model::FnDef p0) {
            return ({
                auto ns_1_4 = ns_1;
                auto cp_2_4 = cp_2;
                auto i_3_4 = i_3;
                entered(once_job([=]() {
                return ({
                    auto f = p0;
                    call_then(start_fn_signature(cp_2_4, with_generics(f, i_3_4.generics)), [=](Text fn_signature_23349) { return prism_rtl::finished(crate::emit::cpp::templates::items::trait_namespace(ns_1_4, prism_rtl::cat(fn_signature_23349, ";"))); });
                });
            }));
            });
        })));
        })));
        auto outer = own
            ? Array<Text>{}
            : Array(std::vector{crate::emit::cpp::templates::items::trait_namespace(tr, crate::syntax::lexer::chars::join(each(i.methods, [&](const crate::lower::model::FnDef& f) { return prism_rtl::cat("using ::crate::", cp.home, "::", ns, "::", crate::emit::cpp::cpp_id(f.name), ";"); }), Text::lit("\n")))});
        Parts this_ = protos_defs(protos, in_trait);
        this_.outer = outer;
        return this_;
    }
}


prism_rtl::Turn<Parts> ImplParts::cycle() const {
    const auto& cp = this->cp;
    const auto& i = this->i;
    auto cp_1 = cp;
    auto i_2 = i;
    return call_then(crate::emit::cpp::start_cpp_type(cp_1, i_2.head), [=](Text cpp_type_22152) {
        return ({
            auto head = cpp_type_22152;
            auto gens = cpp_template_head(generic_names_of(i_2.generics));
            call_value(each_job(i_2.methods, ({
            auto cp_1_3 = cp_1;
            auto i_2_3 = i_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Parts>(crate::lower::model::FnDef)>>(prism_rtl::rc([=](crate::lower::model::FnDef p0) {
            return ({
                auto cp_1_3_3 = cp_1_3;
                auto i_2_3_3 = i_2_3;
                entered(once_job([=]() {
                return ({
                    auto f = p0;
                    (prism_rtl::more(prism_rtl::rc(FnParts(cp_1_3_3, with_generics(f, i_2_3_3.generics)))));
                });
            }));
            });
        })));
        })), [=](Array<Parts> each_22244) {
            return ({
                auto fns = each_22244;
                auto own = fold(fns, no_parts(), [&](const Parts& acc, const Parts& p_) { return join_parts(acc, p_); });
                ({
                auto&& _m = i_2.cls;
                ({
                auto&& m22370_0 = _m;
                (m22370_0 == Text::lit("Prelude.Show"));
            }) ? ({
                auto&& m22370_0 = _m;
                ({
                auto shown = or_(index(each(i_2.methods, [&](const crate::lower::model::FnDef& f) { return f.name; }), Nat(0u)), Text::lit("show"));
                (prism_rtl::finished(join_parts(own, protos_defs(Array<Text>{}, Array(std::vector{crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat(gens, "void ", head, "::show(Printer& p) const"), prism_rtl::cat("p.raw(", shown, "(*this).to_string());"))})))));
            });
            })
                : ({
                auto&& m22370_1 = _m;
                (m22370_1 == Text::lit("Prelude.Eq"));
            }) ? ({
                auto&& m22370_1 = _m;
                ({
                auto eq = fold(i_2.methods, Text::lit(""), [&](const Text& acc, const crate::lower::model::FnDef& f) {
                    return (!crate::syntax::lexer::chars::has_prefix(f.name, Text::lit("ne"))) && (acc == Text::lit(""))
                        ? f.name
                        : acc;
                });
                (prism_rtl::finished(join_parts(own, protos_defs(Array(std::vector{prism_rtl::cat(gens, "bool operator==(const ", head, "& a, const ", head, "& b);")}), Array(std::vector{crate::emit::cpp::templates::items::cpp_function(Text::lit(""), prism_rtl::cat(gens, "bool operator==(const ", head, "& a, const ", head, "& b)"), prism_rtl::cat("return ", eq, "(a, b);"))})))));
            });
            })
                : ({
                auto tr = crate::syntax::lexer::chars::drop_prefix(crate::emit::cpp::type_path(i_2.tr), Text::lit("crate::"));
                auto own = !crate::syntax::lexer::chars::contains(tr, Text::lit("::"));
                auto ns = own
                    ? tr
                    : prism_rtl::cat("impl_", crate::syntax::lexer::chars::join(split(tr, Text::lit("::")), Text::lit("_")));
                call_value(each_job(i_2.methods, ({
                auto ns_3 = ns;
                auto cp_1_4 = cp_1;
                auto i_2_4 = i_2;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::FnDef)>>(prism_rtl::rc([=](crate::lower::model::FnDef p0) {
                return ({
                    auto ns_3_4 = ns_3;
                    auto cp_1_4_4 = cp_1_4;
                    auto i_2_4_4 = i_2_4;
                    entered(once_job([=]() {
                    return ({
                        auto f = p0;
                        call_then(start_fn_definition(cp_1_4_4, with_generics(f, i_2_4_4.generics)), [=](Text fn_definition_23235) { return prism_rtl::finished(crate::emit::cpp::templates::items::trait_namespace(ns_3_4, fn_definition_23235)); });
                    });
                }));
                });
            })));
            })), [=](Array<Text> each_23194) {
                return ({
                    auto in_trait = each_23194;
                    call_value(each_job(i_2.methods, ({
                    auto ns_3 = ns;
                    auto cp_1_4 = cp_1;
                    auto i_2_4 = i_2;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::FnDef)>>(prism_rtl::rc([=](crate::lower::model::FnDef p0) {
                    return ({
                        auto ns_3_4 = ns_3;
                        auto cp_1_4_4 = cp_1_4;
                        auto i_2_4_4 = i_2_4;
                        entered(once_job([=]() {
                        return ({
                            auto f = p0;
                            call_then(start_fn_signature(cp_1_4_4, with_generics(f, i_2_4_4.generics)), [=](Text fn_signature_23349) { return prism_rtl::finished(crate::emit::cpp::templates::items::trait_namespace(ns_3_4, prism_rtl::cat(fn_signature_23349, ";"))); });
                        });
                    }));
                    });
                })));
                })), [=](Array<Text> each_23307) {
                    return ({
                        auto protos = each_23307;
                        auto outer = own
                            ? Array<Text>{}
                            : Array(std::vector{crate::emit::cpp::templates::items::trait_namespace(tr, crate::syntax::lexer::chars::join(each(i_2.methods, [&](const crate::lower::model::FnDef& f) { return prism_rtl::cat("using ::crate::", cp_1.home, "::", ns, "::", crate::emit::cpp::cpp_id(f.name), ";"); }), Text::lit("\n")))});
                        (prism_rtl::finished(({
                        Parts this_ = protos_defs(protos, in_trait);
                        this_.outer = outer;
                        this_;
                    })));
                    });
                });
                });
            });
            });
            });
            });
        });
        });
    });
}


/// `Start ImplParts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Parts> start_impl_parts(crate::emit::cpp::Cp cp, crate::lower::model::ImplDef i) {
    return prism_rtl::make_rc<ImplParts>(cp, i);
}


/// WithGenerics: fn FnDef, [((Text, [Text]))] -> FnDef
crate::lower::model::FnDef with_generics(const crate::lower::model::FnDef& f, const Array<std::tuple<Text, Array<Text>>>& gs) {
    crate::lower::model::FnDef this_ = f;
    this_.generics = append(gs, this_.generics);
    return this_;
}


/// GenericOnly: fn [Text] -> Parts
Parts generic_only(const Array<Text>& xs) {
    Parts this_ = no_parts();
    this_.generic = xs;
    return this_;
}


/// ProtosDefs: fn [Text], [Text] -> Parts
Parts protos_defs(const Array<Text>& ps, const Array<Text>& ds) {
    Parts this_ = no_parts();
    this_.protos = ps;
    this_.defs = ds;
    return this_;
}

}  // namespace crate::emit::cpp::items
