// The module `Emit.Cpp.Items`: its types, nodes and jobs declared, emitted by prismc (claude/backend.md).
// Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace emit::cpp::items {

struct Parts;

struct ValueDecl;

struct CppParams;

struct FnSignature;

struct FnDefinition;

struct ValueDeps;

struct Behind;

struct NamesProgramType;

struct ItemParts;

struct FnParts;

struct TypeParts;

struct CaseStruct;

struct CaseCmpDefs;

struct CaseBehind;

struct TypeDefs;

struct ShowDef;

struct PositionalFields;

struct ToPodDef;

struct FromPodDef;

struct TagParts;

struct CppDeepField;

struct CppDeepPod;

struct CppDeepPorts;

struct RowParts;

struct AnswerParts;

struct JobParts;

struct TraitParts;

struct ImplParts;

}  // namespace emit::cpp::items

}  // namespace crate
